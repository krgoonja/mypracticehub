'use strict';
$(function() {

	//환율정보조회
	sorin.ajax.postSetDataType("/chart/getEhgtRltm", "", "json", false, function(result) {
		if(!sorin.validation.isEmpty(result)) {
			$("[rtlmEndPc]").html(addComma(result.ehgtRltm.toFixed(2)));
		}
	});

	titleWidth = $(".sum-title-wrap").width();
	if(sorin.chart.loginYn == 'N' || (sorinAccount.refndAcnutSttusCode !== "05" || sorinAccount.mberSttusCode !== "01")) {
	/*if(currentPage != 'main' && currentPage != '/main/') {*/
		//$('#btnModalStdrPrice').hide();

		//메인페이지 상품검색 버튼표시
		/*let btnContent = '<button type="button" class="btn-brd-gray" onclick="sorinModalAlarmIdSearch()" data-target="sorinModalAlarmSearch">알림설정</button>'
				   + '<button type="button" class="btn-bg-blue" id="btnBuy">상품검색</button>';*/
		let btnContent = '<button type="button" class="btn-bg-blue" id="btnBuy" style="width: 100%;">구매하기</button>';

		$("#btnsDiv").empty();
		$("#btnsDiv").html(btnContent);
		$("#btnModalAlarmIdSearch").show();
	} else {

		$("#btnModalAlarmIdSearch").hide();

		//검색페이지 구매하기 버튼표시
		//let btnContent = '<button type="button" class="btn-brd-gray" onclick="sorinModalAlarmIdMain();" data-target="modalnotiSetting">알림설정</button>'
		let btnContent = '<button type="button" class="btn-bg-blue" id="btnBuy" style="width: 100%;">구매하기</button>';

		$("#btnsDiv").empty();
		$("#btnsDiv").html(btnContent);

		requestGetSelMetalListAjax(function (result) {
			if(!sorin.validation.isEmpty(result.preminumSelInfoList)) {
				sorin.chart.preminumSelInfoList = result.preminumSelInfoList;
			}

			if(!sorin.validation.isEmpty(result.entrpsMetalItmStdrVO)) {
				sorin.chart.entrpsMetalItmStdr = result.entrpsMetalItmStdrVO;
			}
		});
	}

	var scopiInfoHtml; //차트 워터마크
	var chartTabAreaHtml; //차트탭
	var scopiHtml = ""; // 금속마크
	var headProdHtml;
	var headTickerHtml;
	var moChartTab ="";

	//차트탭 swiper 적용
	if(sorin.chart.liveList.length > 4) {
		$("#moChartTab").removeClass("tab tab-title tab-metal btm-line");
		$("#moChartTab").addClass("tab tab-metal btm-line tab-swiper");
		moChartTab += '<div class="slide-wrap swiper-container">'
		moChartTab += 	'<div class="slide-inner swiper-wrapper">'
	} else {
		$("#moChartTab").removeClass("tab tab-metal btm-line tab-swiper");
		$("#moChartTab").addClass("tab tab-title tab-metal btm-line");
	}

	for (var i = 0; i < sorin.chart.liveList.length; i++) {

		var liveInfo = sorin.chart.liveList[i];
		var codeDcone = liveInfo.codeDcone;
		var mainItmPrSearchGbn;
		var entrpsStdrGbn;

		//메인/상품검색 차트정보표시구분
		if (currentPage != 'main' && currentPage != '/main/') {
			mainItmPrSearchGbn = (sorin.chart.pageMetal == liveInfo.metalCode) ? true : false;
		} else {

			if (sorin.chart.loginYn == 'N') {
				mainItmPrSearchGbn = (i == 0) ? true : false;
			} else {
				mainItmPrSearchGbn = (sorin.chart.pageMetal == liveInfo.metalCode) ? true : false;

				if (Object.keys(sorin.chart.entrpsMetalItmStdr).length !== 0) {
					entrpsStdrGbn = (sorin.chart.entrpsMetalItmStdr.metalCode == liveInfo.metalCode) ? true : false;
					sorin.chart.metalNm = sorin.chart.entrpsMetalItmStdr.codeNm;
				} else {
					entrpsStdrGbn = (sorin.chart.pageMetal == liveInfo.metalCode) ? true : false;
				}
			}
		}


		if (mainItmPrSearchGbn) {
			scopiInfoHtml = '<span class="sc-info-' + liveInfo.codeNm + liveInfo.sleMthdCode + '"><span class="t-bold">SCOPI-</span>'
				+ '<strong>' + liveInfo.codeChrctrRefrntwo + '</strong>'
				+ '(<strong>S</strong>tandard <strong>C</strong>ommodity c<strong>O</strong>mposite <strong>P</strong>rice '
				+ '<strong>I</strong>ndex - <strong>' + codeDcone.substring(0, 1) + '</strong>' + codeDcone.substring(1, codeDcone.length) + ')</span>';
			//차트탭 swiper 적용
			if(sorin.chart.liveList.length > 4) {
				if (entrpsStdrGbn) {
					moChartTab += '<div class="swiper-slide btn-' + liveInfo.codeNm + liveInfo.sleMthdCode + ' active w-100">' + liveInfo.codeChrctrRefrnsix + '</div>';
				} else {
					moChartTab += '<div class="swiper-slide btn-' + liveInfo.codeNm + liveInfo.sleMthdCode + ' w-100">' + liveInfo.codeChrctrRefrnsix + '</div>';
				}
			} else {
				if (entrpsStdrGbn) {
					moChartTab += '<span type="button" class="swiper-slide btn-' + liveInfo.codeNm + liveInfo.sleMthdCode + ' active w-100">' + liveInfo.codeChrctrRefrnsix + '</span>';
				} else {
					moChartTab += '<span type="button" class="swiper-slide btn-' + liveInfo.codeNm + liveInfo.sleMthdCode + ' w-100">' + liveInfo.codeChrctrRefrnsix + '</span>';
				}
			}

			scopiHtml += '<span class="label-metal scopi scopi-AL" metalGroup="' + liveInfo.codeNm + liveInfo.sleMthdCode + '">SCOPI-' + liveInfo.codeChrctrRefrntwo + '</span>';

			scopiHtml += '<div class="item" id="t-' + liveInfo.codeNm + '" metalGroup="' + liveInfo.codeNm + liveInfo.sleMthdCode + '"></div>';
		}

		if ((currentPage == 'main' || currentPage == '/main/') && i > 0) {
			scopiInfoHtml += '<span class="sc-info-' + liveInfo.codeNm + liveInfo.sleMthdCode + '" style="display: none"><span class="t-bold">SCOPI-</span>'
				+ '<strong>' + liveInfo.codeChrctrRefrntwo + '</strong>'
				+ '(<strong>S</strong>tandard <strong>C</strong>ommodity c<strong>O</strong>mposite <strong>P</strong>rice '
				+ '<strong>I</strong>ndex - <strong>' + codeDcone.substring(0, 1) + '</strong>' + codeDcone.substring(1, codeDcone.length) + ')</span>';
			if(sorin.chart.liveList.length > 4) {
				if (entrpsStdrGbn) {
					moChartTab += '<div class="swiper-slide btn-' + liveInfo.codeNm + liveInfo.sleMthdCode + ' active w-100">' + liveInfo.codeChrctrRefrnsix + '</div>';
				} else {
					moChartTab += '<div class="swiper-slide btn-' + liveInfo.codeNm + liveInfo.sleMthdCode + ' w-100">' + liveInfo.codeChrctrRefrnsix + '</div>';
				}
			} else {
				if (entrpsStdrGbn) {
					moChartTab += '<span type="button" class="btn-' + liveInfo.codeNm + liveInfo.sleMthdCode + ' active w-100">' + liveInfo.codeChrctrRefrnsix + '</span>';
				} else {
					moChartTab += '<span type="button" class="btn-' + liveInfo.codeNm + liveInfo.sleMthdCode + ' w-100">' + liveInfo.codeChrctrRefrnsix + '</span>';
				}
			}
			scopiHtml += '<span class="label-metal scopi scopi-AL" metalGroup="' + liveInfo.codeNm + liveInfo.sleMthdCode + '" style="display: none">SCOPI-' + liveInfo.codeChrctrRefrntwo + '</span>';

			scopiHtml += '<div class="item" id="t-' + liveInfo.codeNm + '" style="display: none" metalGroup="' + liveInfo.codeNm + liveInfo.sleMthdCode + '"></div>';
		}
	}
	if(sorin.chart.liveList.length > 4) {
		moChartTab += '</div></div>';
	}
	$('#moChartTab').empty();
	$('#moChartTab').html(moChartTab);
	
	if(sorin.chart.loginYn == 'Y' && (sorinAccount.refndAcnutSttusCode == "05" && sorinAccount.mberSttusCode == "01")) {
		$('#scopi').empty();
		$('#scopi').html(scopiHtml);

		$('#scopi-info').empty();
		$('#scopi-info').html(scopiInfoHtml);
		
		$("#moChartTab .btn-"+sorin.chart.metalNm + sorin.chart.sleMthdCode).click();
		rMateStockInitCreate();

		//차트 노출
		//$("#chartModule").show();

	}
	$("#moChartTab .btn-" + sorin.chart.metalNm + sorin.chart.sleMthdCode).click();


	//비로그인시 차트 전일 종가 노출
	if(sorin.chart.loginYn == 'N' || (sorinAccount.refndAcnutSttusCode !== "05" || sorinAccount.mberSttusCode !== "01")) {
		$('#closingPcSection').show();
	} else {
		$("#chartModule").show();
	}
	if (headerOpenTimeCode == '40') {
		$('#msgAlOpening').addClass('msg-al-opening');
		$('#msgAlOpening').show();
	} else {
		$('#msgAlOpening').removeClass('msg-al-opening');
		$('#msgAlOpening').hide();
	}
});

function compareIds(a, b) {
    if (a.id === "") {
        return -1; // 선택 값은 첫 번째로 정렬
    }
    if (b.id === "") {
        return 1; // 선택 값은 첫 번째로 정렬
    }

    var numA = parseInt(a.id.replace(/\D/g, ''), 10);
    var numB = parseInt(b.id.replace(/\D/g, ''), 10);
    return numA - numB;
}

/*$(document).off('click', '.btn-chart-preview').on('click', '.btn-chart-preview', function(){
	$('.chart-preview-dim1').fadeOut(300);
});*/

function formatDate(date) {
	var year = date.getFullYear();
	var month = date.getMonth() + 1;
	var date = date.getDate();
	return year+"."+month+"."+date;
}

// 1-2. .chart-preview-dim2 > 30초 지나도 '로그인 하기' 버튼 클릭하지 않을 시 > .main-charts-wrap 영역 접힘
/*function chartPreviewDim2 () {
	var $chartPrevDim2 = $('.chart-preview-dim2');
	var $prevEndCount = $('.chart-preview-dim2 p.count-num')

	$chartPrevDim2.show();

	prevEndTimer = setInterval(function() {
		var sec = Number($prevEndCount.text());
		$prevEndCount.text(sec - 1);
	}, 1000);

	prevEndTimeout = setTimeout(function () {
		clearInterval(prevEndTimer);
		clearTimeout(prevEndTimeout);
		$chartPrevDim2.hide();
    	$("#chartModule").slideUp(300);
	}, 30 * 1000);
}*/

/*function chartPreviewDim1 () {
	var $chartPrevDim1 = $('.chart-preview-dim1');
	var $chartPrevCount = $('.chart-preview-dim1 p.count-time');

	$chartPrevDim1.show();

	var endTime = 5 * 60 * 1000;
	var chartPrevRemain = getCookie("chartPrevRemain");
	var cookieExpires = 24 * 60 * 60 * 1000;

	var chartPrevDt = getCookie("chartPrevDt");
	var today = formatDate(new Date());
	//자정마다 차트 미리보기 초기화를 위해 전날 등록된 쿠키 삭제
	if(!sorin.validation.isEmpty(chartPrevDt) && chartPrevDt < today) {
		setChartCookie("chartPrevDt", "", 0);
		setChartCookie("chartPrevRemain", "", 0);
	}

	var chartPrevRemain = getCookie("chartPrevRemain");
	if(chartPrevRemain) {
		$chartPrevCount.text(secToTimeFormat(chartPrevRemain));
		endTime -= endTime - chartPrevRemain * 1000;
		sorin.chart.setChartSumTitle("chartPrev", "케이지트레이딩 5분 미리보기가 <span class='col-yellow'>" + secToTimeFormat(chartPrevRemain) + "</span> 후에 종료됩니다. 케이지트레이딩 서비스를 이용하실 고객님께서는 <span class='col-yellow'>기업회원 로그인</span> 후 이용해주세요.");
	}

	chartPrevTimer = setInterval(function() {
		var sec = timeFormatToSec($chartPrevCount.text());
		sec--;

		$chartPrevCount.text(secToTimeFormat(sec));
		sorin.chart.setChartSumTitle("chartPrev", "케이지트레이딩 5분 미리보기가 <span class='col-yellow'>" + secToTimeFormat(sec) + "</span> 후에 종료됩니다. 케이지트레이딩 서비스를 이용하실 고객님께서는 <span class='col-yellow'>기업회원 로그인</span> 후 이용해주세요.");
		setChartCookie("chartPrevRemain", sec, cookieExpires);
	}, 1000);

	chartPrevTimeout = setTimeout(function() {
		clearInterval(chartPrevTimer);
		clearTimeout(chartPrevTimeout);

		$chartPrevDim1.hide();
		setChartCookie("chartPrevRemain", "", 0);
		setChartCookie("chartPrevDt", formatDate(new Date()), cookieExpires);

		chartPreviewDim2();

		sorin.chart.setChartSumTitle("chartPrev", "케이지트레이딩 <span class='col-yellow'>5분 미리보기가 종료</span>되었습니다. 서비스를 이용하실 고객님께서는 <span class='col-yellow'>기업회원 로그인</span> 후 사용해주세요.");
	}, endTime);
}*/

function timeFormatToSec(param) {
	var a = param.split(':');
	return Number(a[0]) * 60 + Number(a[1]);
}

function secToTimeFormat(param) {
	var min = Math.floor(param / 60);
	var sec = param % 60;
	return ('0' + min).slice('-2') + ':' + ('0' + sec).slice('-2')
}

// 차트상단 가격, 비율, Document 타이틀 변경
function titleChange() {
	if(sorin.chart.loginYn == 'Y' && sorinAccount.mberSttusCode == "01" && sorinAccount.refndAcnutSttusCode == "05") {
		
		let price = sorin.chart.selPcChartList.endPc;
		let rate = sorin.chart.selPcChartList.fluctuationRate;
		let upDown = rate >= 0 ? "▲" : "▼";
	
		$(document).prop('title', "[케이지트레이딩] LIVE AL " + addComma(price) + " " + upDown + " " + rate);	
	}
}

function addComma(value) {
	if (sorin.validation.isEmpty(value)) {
		return '0';
	}
    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

//전광판 내 문구 너비 저장을 위한 변수
var titleWidth = 0;
$(document).off('DOMNodeInserted', ".chart-sum-title .sum-title-wrap").on('DOMNodeInserted', ".chart-sum-title .sum-title-wrap", function(e) {
	var currDuration = ($(".sum-title-wrap").css("animationDuration")).slice(0, -1);
	var currDistance = titleWidth + $(".chart-title-area").width();

	var newWidth = $(".sum-title-wrap").width();
	var newDistance = newWidth + $(".chart-title-area").width();
	var newDuration = (currDuration/currDistance) * newDistance;

    $(".sum-title-wrap").css("animationDuration", newDuration + 's');
    e.preventDefault();
    titleWidth = newWidth;
});

//$(document).off('click','.chart-tab-area > button').on('click','.chart-tab-area > button', function(e) {
$(document).off('click','#moChartTab > span, #moChartTab .swiper-wrapper > div').on('click','#moChartTab > span, #moChartTab .swiper-wrapper > div', function(e) {
	e.preventDefault;
	let price;
	let rate;
	let upDown;
	let selMetal;

	if (sorin.chart.liveList.length > 0) {

		for(var i = 0; i < sorin.chart.liveList.length; i++) {
			var liveInfo = sorin.chart.liveList[i];

			if ( $(this).hasClass('btn-' + liveInfo.codeNm + liveInfo.sleMthdCode)) {
				$('#moChartTab .btn-' + liveInfo.codeNm + liveInfo.sleMthdCode).addClass('active').siblings().removeClass('active');
				$('#moChartTab .swiper-wrapper > btn-' + liveInfo.codeNm + liveInfo.sleMthdCode).addClass('swiper-slide-active').siblings().removeClass('swiper-slide-active');
				//$('#tbody' + liveInfo.codeNm + liveInfo.sleMthdCode).show().siblings('div[id^="tbody"]').hide();      // 테이블    --차트탭 변경
				//$('#headProd > .prod-' + liveInfo.codeNm + liveInfo.sleMthdCode).show().siblings().hide();             // 제품명   --차트타이틀 메탈명
				//$('.scopi >  [class*="' + liveInfo.codeNm + '"').show().siblings().hide();         // 제품명 > 기준가 설명  --아이템명
				//$('.scopi > #' + liveInfo.codeNm + liveInfo.sleMthdCode + '-ticker').show().siblings().hide();         // 제품명 > 기준가 설명  --아이템명
				//$('.scopi > .sc-' + liveInfo.codeNm + liveInfo.sleMthdCode).show().siblings().hide();                  // 제품명 > scopi  -- scopi
				$('.scopi-info > .sc-info-' + liveInfo.codeNm + liveInfo.sleMthdCode).show().siblings().hide();        // scopi 설명	-- 차트 밑에 scopi

				//$('[metalGroup=' + liveInfo.codeNm + liveInfo.sleMthdCode+']').show().siblings().not('#rCharts, #scopi-info').hide();

				$('[metalGroup=' + liveInfo.codeNm + liveInfo.sleMthdCode+']').show();
				$('[metalGroup]:not([metalGroup="' + liveInfo.codeNm + liveInfo.sleMthdCode + '"])').hide();


				if(currentPage != 'main' && currentPage != '/main/') {
					sorin.chart.metalCode = liveInfo.metalCode;
					sorin.chart.itmSn = liveInfo.itmSn;
					sorin.chart.dstrctLclsfCode = liveInfo.dstrctLclsfCode;
					sorin.chart.brandGroupCode = liveInfo.brandGroupCode;
					sorin.chart.brandCode = liveInfo.brandCode;
					sorin.chart.sleMthdCode = liveInfo.sleMthdCode;
					sorin.chart.metalNm = liveInfo.codeNm;

				} else {
					if(Object.keys(sorin.chart.entrpsMetalItmStdr).length !== 0 && liveInfo.metalCode == sorin.chart.entrpsMetalItmStdr.metalCode) {
						sorin.chart.metalCode = sorin.chart.entrpsMetalItmStdr.metalCode;
						sorin.chart.itmSn = sorin.chart.entrpsMetalItmStdr.itmSn;
						sorin.chart.dstrctLclsfCode = sorin.chart.entrpsMetalItmStdr.dstrctLclsfCode;
						sorin.chart.brandGroupCode = sorin.chart.entrpsMetalItmStdr.brandGroupCode;
						sorin.chart.brandCode = sorin.chart.entrpsMetalItmStdr.brandCode;
						sorin.chart.sleMthdCode = sorin.chart.entrpsMetalItmStdr.sleMthdCode;
						sorin.chart.metalNm = sorin.chart.entrpsMetalItmStdr.codeNm;
					} else {
						sorin.chart.metalCode = liveInfo.metalCode;
						sorin.chart.itmSn = liveInfo.itmSn;
						sorin.chart.dstrctLclsfCode = liveInfo.dstrctLclsfCode;
						sorin.chart.brandGroupCode = liveInfo.brandGroupCode;
						sorin.chart.brandCode = liveInfo.brandCode;
						sorin.chart.sleMthdCode = liveInfo.sleMthdCode;
						sorin.chart.metalNm = liveInfo.codeNm;
					}
				}

				sorin.chart.pageMetal = liveInfo.metalCode;
				sorin.chart.pageSleMthd = liveInfo.sleMthdCode;

				//메탈탭변경시 메탈운영정보 갱신
				for (var i = 0; i < restDataList.length; i++) {
					if (restDataList[i].metalCode == sorin.chart.pageMetal && restDataList[i].sleMthdCode == sorin.chart.pageSleMthd) {
						headerRestWaitTerm = restDataList[i].topWaitTerm; // 상단 시간차
						headerRestWaitNm = restDataList[i].topWaitNm; // 소켓 타이머 문구
						headerOpenTimeCode = restDataList[i].openTimeCode; //개장시간 범위 코드
						chartStTitleNm = restDataList[i].chartStTitle;
						chartEdTitleNm = restDataList[i].chartEdTitle;
					}
				}
				var tableListAreaHtml;
				requestGetSelPcChartListAjax(function (result) {
					if(!sorin.validation.isEmpty(result)) {

							sorin.chart.selPcChartList = result.selPcChartList;

							sorin.chart.chartTitleInfo.endPc = sorin.chart.selPcChartList.endPc;
							sorin.chart.chartTitleInfo.topPc = sorin.chart.selPcChartList.topPc;
							sorin.chart.chartTitleInfo.lwetPc = sorin.chart.selPcChartList.lwetPc;
							sorin.chart.chartTitleInfo.beginPc = sorin.chart.selPcChartList.beginPc;
							sorin.chart.chartTitleInfo.endPcAgo = sorin.chart.selPcChartList.endPcAgo;
							sorin.chart.chartTitleInfo.fluctuationRate = sorin.chart.selPcChartList.fluctuationRate;
							sorin.chart.chartTitleInfo.versusPc = sorin.chart.selPcChartList.versusPc;
							sorin.chart.chartTitleInfo.dstrctLclsfName = sorin.chart.selPcChartList.dstrctLclsfName;
							sorin.chart.chartTitleInfo.brandGroupNm = sorin.chart.selPcChartList.brandGroupNm;
							sorin.chart.chartTitleInfo.occrrncDe = sorin.chart.selPcChartList.occrrncDe;
							sorin.chart.chartTitleInfo.occrrncTime = sorin.chart.selPcChartList.occrrncTime;
							//아이템명
							$('#t-' + sorin.chart.metalNm).text(sorin.chart.selPcChartList.goodsNm);
							$('#goodsNm').text(sorin.chart.selPcChartList.goodsNm);

						//비로그인 전일 종가 조회
						if(sorin.chart.loginYn == 'N' || (sorinAccount.refndAcnutSttusCode !== "05" || sorinAccount.mberSttusCode !== "01")) {
							sorin.ajax.postSetDataType("/main/selectClosingPc", "", "json", false, function(result) {
								if(!sorin.validation.isEmpty(result)) {
									let closingPcList = result.closingPcList;

									let endPcPartArr = closingPcList.filter(item => item.part == '1' && item.metalCode == sorin.chart.pageMetal);
									let sarokPartArr = closingPcList.filter(item => item.part == '2' && item.metalCode == sorin.chart.pageMetal);
									let sorinPartArr = closingPcList.filter(item => item.part == '3' && item.metalCode == sorin.chart.pageMetal);

									//환율
									let closingRtlmendpc = parseFloat(endPcPartArr[0].etcAmount1).toFixed(2)
									//전일 종가
									let closingPrice = parseFloat(endPcPartArr[0].displayAmount).toFixed(0)

									$("[closingRtlmendpc]").html(addComma(closingRtlmendpc));
									$("#closingPrice").html(addComma(closingPrice));


									$("#closingDate").html(sarokPartArr[0].etcAmount2);
									$(".closingDate").show();

                                    /*let closingPrice = '<span class="num" id="' + sorin.chart.metalNm + sorin.chart.sleMthdCode + 'EndPc"> '
                                        + addComma(sorin.chart.chartTitleInfo.endPc) + '</span><span class="unit">KRW</span>';
                                    $("#closingPrice").html(closingPrice);*/
									let closingSarokTap = "";
									if(!sorin.validation.isEmpty(sarokPartArr) && !sorin.validation.isEmpty(sarokPartArr[0].displayNm)) {
										for (var i = 0; i < sarokPartArr.length; i++) {
											let sarokPart = sarokPartArr[i];
											let displayAmount = parseFloat(sarokPart.displayAmount).toFixed(0);
											let vatDisplayAmount = parseInt(Math.round(sarokPart.displayAmount * 1.1));

											closingSarokTap += '<li>'
											closingSarokTap += '<span class="title">' + sarokPart.displayNm + '</span>'
											closingSarokTap += '<span class="cont">'
											if (sarokPart.etcAmount1 > 0) {
												closingSarokTap += '<span class="price up" sarokPc="' + sorin.chart.metalNm + sorin.chart.sleMthdCode + '" style="display: none">' + addComma(vatDisplayAmount) + '</span>'
												closingSarokTap += '<span class="price up" nonVatSarokPc="' + sorin.chart.metalNm + sorin.chart.sleMthdCode + '">' + addComma(displayAmount) + '</span>'
												closingSarokTap += '<span class="rate up">+' + sarokPart.etcAmount1 + '%</span>'
											} else if (sarokPart.etcAmount1 < 0) {
												closingSarokTap += '<span class="price down" sarokPc="' + sorin.chart.metalNm + sorin.chart.sleMthdCode + '" style="display: none">' + addComma(vatDisplayAmount) + '</span>'
												closingSarokTap += '<span class="price down" nonVatSarokPc="' + sorin.chart.metalNm + sorin.chart.sleMthdCode + '">' + addComma(displayAmount) + '</span>'
												closingSarokTap += '<span class="rate down">' + sarokPart.etcAmount1 + '%</span>'
											} else if (sarokPart.etcAmount1 == 0 || sarokPart.etcAmount1 == 0.0) {
												closingSarokTap += '<span class="price" sarokPc="' + sorin.chart.metalNm + sorin.chart.sleMthdCode + '" style="display: none">' + addComma(vatDisplayAmount) + '</span>'
												closingSarokTap += '<span class="price" nonVatSarokPc="' + sorin.chart.metalNm + sorin.chart.sleMthdCode + '">' + addComma(displayAmount) + '</span>'
												closingSarokTap += '<span class="rate">' + sarokPart.etcAmount1 + '%</span>'
											}
											closingSarokTap += '</span>'
											closingSarokTap += '</li>'
										}
									} else {
										if(sorin.chart.pageMetal == '1') {
											closingSarokTap += '<li><span class="title">아연</span>'
											closingSarokTap += '<span className="cont">판매가격 제공 없음</span></li>'

										} else if (sorin.chart.pageMetal == '5') {

											closingSarokTap += '<li><span class="title">구리(99.99%이상)</span>'
											closingSarokTap += '<span className="cont">판매가격 제공 없음</span></li>'

										} else if(sorin.chart.pageMetal == '7') {
											closingSarokTap += '<li><span class="title">서구산</span>'
											closingSarokTap += '<span className="cont">판매가격 제공 없음</span></li>'
											closingSarokTap += '<li><span class="title">비서구산</span>'
											closingSarokTap += '<span className="cont">판매가격 제공 없음</span></li>'

										} else if(sorin.chart.pageMetal == '8') {

											closingSarokTap += '<li><span class="title">합금용</span>'
											closingSarokTap += '<span className="cont">판매가격 제공 없음</span></li>'
											closingSarokTap += '<li><span class="title">도금용</span>'
											closingSarokTap += '<span className="cont">판매가격 제공 없음</span></li>'
										}
									}
									$("#sarokTap").empty();
									$("#sarokTap").html(closingSarokTap);
									let chartTap = "";
									for(var i= 0; i < sorinPartArr.length; i++) {
										let sorinPart = sorinPartArr[i];
										chartTap += '<li><span class="title">' + sorinPart.displayNm + '</span>';
										chartTap += '<span class="cont">';
										if(sorinPart.etcAmount1 == 0 || sorinPart.etcAmount1 == 0.0) {
											chartTap +='<span class="price">';
										} else if(sorinPart.etcAmount1 > 0) {
											chartTap +='<span class="price up">';
										} else if(sorinPart.etcAmount1 < 0) {
											chartTap +='<span class="price down">';
										}

										//chartTap += 'id="' + sorin.chart.metalNm + sorin.chart.sleMthdCode + 'EndPc' + i + '">';
										chartTap += addComma(parseFloat(sorinPart.displayAmount).toFixed(0));
										chartTap += '</span>';
										if(sorinPart.etcAmount1 == 0 || sorinPart.etcAmount1 == 0.0) {
											chartTap +='<span class="rate">';
										} else if(sorinPart.etcAmount1 > 0) {
											chartTap +='<span class="rate up">+';
										} else if(sorinPart.etcAmount1 < 0) {
											chartTap +='<span class="rate down">';
										}
										//chartTap += 'id="' + sorin.chart.metalNm + sorin.chart.sleMthdCode + 'Rate' + i + '">';
										chartTap += parseFloat(sorinPart.etcAmount1).toFixed(2) + '%';
										chartTap += '</span></li>';

										$("#chartTap").empty();
										$("#chartTap").html(chartTap);

									}
								}
							});
							$("[id*='buttonVat']").each(function() {
								$(this).attr("id","buttonVat" + sorin.chart.metalNm + sorin.chart.sleMthdCode);
							});
						}

						if(sorin.chart.loginYn == 'Y') {
							//차트타이틀 화면표시부분
							var sumLiveVersusPc = sorin.chart.selPcChartList.endPc - sorin.chart.selPcChartList.endPcAgo; //전일자랑 가격비교

							if(sumLiveVersusPc == 0) {
								$(".realtime-info").removeClass("up");
								$(".realtime-info").removeClass("down");
							} else if(sumLiveVersusPc > 0) {
								$(".realtime-info").addClass("up");
								$(".realtime-info").removeClass("down");
							} else if(sumLiveVersusPc < 0) {
								$(".realtime-info").addClass("down");
								$(".realtime-info").removeClass("up");
							}
							let sumPrice ='<span class="num price" id="'+ sorin.chart.metalNm + sorin.chart.sleMthdCode +'-price"> '
							 +addComma(sorin.chart.chartTitleInfo.endPc) + '</span><span class="unit">KRW</span>'; // 차트타이틀 종가
							$("#sumPrice").html(sumPrice);

							let headDesc = '<span class="wrhous">' + sorin.chart.chartTitleInfo.dstrctLclsfName + '</span>'
							+ ' 보세창고 상차도 기준(<span class="brand-group">' + sorin.chart.chartTitleInfo.brandGroupNm + '</span>, 부가세 별도)';
							$("#headDesc").html(headDesc);

							let sumRate = "";
							if(sorin.chart.chartTitleInfo.fluctuationRate > 0) {
								sumRate = '<span class="rate" id="'+ sorin.chart.metalNm + sorin.chart.sleMthdCode +'-rate">+'
									+ sorin.chart.chartTitleInfo.fluctuationRate.toFixed(2) + '%</span>';
							} else {
								sumRate = '<span class="rate" id="'+ sorin.chart.metalNm + sorin.chart.sleMthdCode +'-rate">'
									+ sorin.chart.chartTitleInfo.fluctuationRate.toFixed(2) + '%</span>';
							}
							$("#sumRate").html(sumRate);

							let sumGap = '<span class="gap" id="'+ sorin.chart.metalNm + sorin.chart.sleMthdCode +'-gap">'
								+ addComma(sorin.chart.chartTitleInfo.versusPc) + '</span>';
							$("#sumGap").html(sumGap);

							let rChartsum = '<li>'	//차트타이틀 시고저종
								+ '<span class="title">시가</span> <span class="price" id="'+ sorin.chart.metalNm + sorin.chart.sleMthdCode +'-mprice"> '
								+ addComma(sorin.chart.chartTitleInfo.beginPc) + '</span></li><li>'
								+ '<span class="title">고가</span> <span class="price up" id="'+ sorin.chart.metalNm + sorin.chart.sleMthdCode +'-hprice">'
								+ addComma(sorin.chart.chartTitleInfo.topPc) + '</span></li><li>'
								+ '<span class="title">저가</span> <span class="price down" id="'+ sorin.chart.metalNm + sorin.chart.sleMthdCode +'-lprice">'
								+ addComma(sorin.chart.chartTitleInfo.lwetPc) + '</span></li><li>'
								+ '<span class="title">전일가</span> <span class="price prev" id="'+ sorin.chart.metalNm + sorin.chart.sleMthdCode +'-yprice">'
								+  addComma(sorin.chart.chartTitleInfo.endPcAgo) + '</li>';

							let chartTap = "";
							for(var i= 0; i < sorin.chart.selPcChartList.preminumSelListVO.length; i++) {
								var preminumSelVO = sorin.chart.selPcChartList.preminumSelListVO[i];
								chartTap += '<li><span class="title">' + preminumSelVO.dstrctLclsfNm + '/' + preminumSelVO.brandGroupNm + '</span>';
								chartTap += '<span class="cont">';
								if(preminumSelVO.versusPc == 0) {
									chartTap +='<span class="price"';
								} else if(preminumSelVO.versusPc > 0) {
									chartTap +='<span class="price up"';
								} else if(preminumSelVO.versusPc < 0) {
									chartTap +='<span class="price down"';
								}

								chartTap += 'id="' + sorin.chart.metalNm + sorin.chart.sleMthdCode + 'EndPc' + i + '">';
								chartTap += addComma(preminumSelVO.endPc);
								chartTap += '</span>';
								if(preminumSelVO.versusPc == 0) {
									chartTap +='<span class="rate"';
								} else if(preminumSelVO.versusPc > 0) {
									chartTap +='<span class="rate up"';
								} else if(preminumSelVO.versusPc < 0) {
									chartTap +='<span class="rate down"';
								}
								chartTap += 'id="' + sorin.chart.metalNm + sorin.chart.sleMthdCode + 'Rate' + i + '">';
								if (preminumSelVO.versusPc > 0) {
									chartTap += '+' + preminumSelVO.versusRate.toFixed(2) + '%';
								} else {
									chartTap += preminumSelVO.versusRate.toFixed(2) + '%';
								}
								chartTap += '</span></li>';

								$("#chartTap").empty();
								$("#chartTap").html(chartTap);

							}
						}
					}
					// 초기 타이틀 셋팅
					titleChange();
				});
				//비로그인 임시
				if(sorin.chart.loginYn == 'N' || (sorinAccount.refndAcnutSttusCode !== "05" || sorinAccount.mberSttusCode !== "01")) {

				} else {
					let sarokTap = "";
					var liveFoldPpsHtml = '<span class="tit">조달청 <span class="unit">(KRW/MT)</span></span>';
					sorin.ajax.postSetDataType("/chart/getRvcmpnList", sorin.chart.pageMetal, "json", false, function(result) {
						if(!sorin.validation.isEmpty(result)) {

							$("[id*='buttonVat']").each(function() {
								$(this).attr("id","buttonVat" + sorin.chart.metalNm + sorin.chart.sleMthdCode);
							});

							if(!sorin.validation.isEmpty(result.rvcmpnVOList)) {
								sorin.chart.rvcmpnVOList = result.rvcmpnVOList;
								for(var i = 0; i < sorin.chart.rvcmpnVOList.length; i++) {
									var rvcmpnVO = sorin.chart.rvcmpnVOList[i];

									sarokTap += '<li id="existSarok_' + rvcmpnVO.brandGroupCode + '_' +rvcmpnVO.metalCode + '">'
									sarokTap +=	'<span className="title">' + rvcmpnVO.brandGroupName + '</span>';
									sarokTap += '<span class="cont">';
									if(rvcmpnVO.sarokPc == rvcmpnVO.agoSarokPc) {
										sarokTap += '<span class="price" nonVatSarokPc="'+ sorin.chart.metalNm + sorin.chart.sleMthdCode +'">';
										sarokTap += addComma(rvcmpnVO.nonVatSarokPc) + '</span>';
										sarokTap += '<span class="price" sarokPc="'+ sorin.chart.metalNm + sorin.chart.sleMthdCode +'" style="display: none">';
										sarokTap += addComma(rvcmpnVO.sarokPc) + '</span>';
									} else if (rvcmpnVO.sarokPc > rvcmpnVO.agoSarokPc) {
										sarokTap += '<span class="price up" nonVatSarokPc="'+ sorin.chart.metalNm + sorin.chart.sleMthdCode +'">';
										sarokTap += addComma(rvcmpnVO.nonVatSarokPc) + '</span>';
										sarokTap += '<span class="price up" sarokPc="'+ sorin.chart.metalNm + sorin.chart.sleMthdCode +'" style="display: none">';
										sarokTap += addComma(rvcmpnVO.sarokPc) + '</span>';
									} else if (rvcmpnVO.sarokPc < rvcmpnVO.agoSarokPc) {
										sarokTap += '<span class="price down" nonVatSarokPc="'+ sorin.chart.metalNm + sorin.chart.sleMthdCode +'">';
										sarokTap += addComma(rvcmpnVO.nonVatSarokPc) + '</span>';
										sarokTap += '<span class="price down" sarokPc="'+ sorin.chart.metalNm + sorin.chart.sleMthdCode +'" style="display: none">';
										sarokTap += addComma(rvcmpnVO.sarokPc) + '</span>';
									}

									if(rvcmpnVO.sarokPc == rvcmpnVO.agoSarokPc) {
										sarokTap += '<span class="rate">'
									} else if (rvcmpnVO.sarokPc > rvcmpnVO.agoSarokPc) {
										sarokTap += '<span class="rate up">+'
									} else if (rvcmpnVO.sarokPc < rvcmpnVO.agoSarokPc) {
										sarokTap += '<span class="rate down">'
									}
									sarokTap += rvcmpnVO.sarokPcRate.toFixed(2) + '%</span>';
									sarokTap += '</span></li>';
								}
							} else {
								if(sorin.chart.pageMetal == '1') {
									sarokTap += '<li><span class="title">아연</span>'
									sarokTap += '<span className="cont">판매가격 제공 없음</span></li>'

								} else if (sorin.chart.pageMetal == '5') {

									sarokTap += '<li><span class="title">구리(99.99%이상)</span>'
									sarokTap += '<span className="cont">판매가격 제공 없음</span></li>'

								} else if(sorin.chart.pageMetal == '7') {
									sarokTap += '<li><span class="title">서구산</span>'
									sarokTap += '<span className="cont">판매가격 제공 없음</span></li>'
									sarokTap += '<li><span class="title">비서구산</span>'
									sarokTap += '<span className="cont">판매가격 제공 없음</span></li>'

								} else if(sorin.chart.pageMetal == '8') {

									sarokTap += '<li><span class="title">합금용</span>'
									sarokTap += '<span className="cont">판매가격 제공 없음</span></li>'
									sarokTap += '<li><span class="title">도금용</span>'
									sarokTap += '<span className="cont">판매가격 제공 없음</span></li>'
								}

								if(sorin.chart.pageMetal == '1') {
									tableListAreaHtml += '<div class="l-inner rvcmpn" id="sarok_31_' + sorin.chart.pageMetal + '">'
										+ '<div class="c-wrhous"><span class="brand-group">아연</span></div>'
										+ '<div class="c-rate" style="width: 50%" id="noSarok_31_' + sorin.chart.pageMetal + '">판매가격 제공 없음</div></div>';

										liveFoldPpsHtml += '<div class="price-box" id="foldSarok_31_' +sorin.chart.pageMetal + '">'
											+ '<span class="wrhous">아연&nbsp;</span>'
											+ '<div class="price" id="foldNoSarok_31_' +sorin.chart.pageMetal + '">판매가격 제공 없음</div>'
											+ '</div>'
											+ '<span class="ml5 fc-lgray fs12 hide" id="foldVatSarok_' +sorin.chart.pageMetal + '">(부가세 미포함)</span>';
								} else if (sorin.chart.pageMetal == '5') {
									tableListAreaHtml += '<div class="l-inner rvcmpn" id="sarok_11_' +sorin.chart.pageMetal + '">'
										+ '<div class="c-wrhous"><span class="brand-group">구리(99.99%이상)</span></div>'
										+ '<div class="c-rate" style="width: 50%" id="noSarok_11_' + sorin.chart.pageMetal + '">판매가격 제공 없음</div></div>';

									liveFoldPpsHtml += '<div class="price-box" id="foldSarok_11_' +sorin.chart.pageMetal + '">'
											+ '<span class="wrhous">구리(99.99%이상)&nbsp;</span>'
											+ '<div class="price" id="foldNoSarok_11_' +sorin.chart.pageMetal + '">판매가격 제공 없음</div>'
											+ '</div>'
											+ '<span class="ml5 fc-lgray fs12 hide" id="foldVatSarok_' +sorin.chart.pageMetal + '">(부가세 미포함)</span>';
								} else if(sorin.chart.pageMetal == '7') {
									tableListAreaHtml += '<div class="l-inner rvcmpn" id="sarok_01_' +sorin.chart.pageMetal + '">'
										+ '<div class="c-wrhous"><span class="brand-group">서구산</span></div>'
										+ '<div class="c-rate" style="width: 50%" id="noSarok_01_' + sorin.chart.pageMetal + '">판매가격 제공 없음</div></div>'
										+ '<div class="l-inner rvcmpn" id="sarok_02_' +sorin.chart.pageMetal + '">'
										+ '<div class="c-wrhous"><span class="brand-group">비서구산</span></div>'
										+ '<div class="c-rate" style="width: 50%" id="noSarok_02_' + sorin.chart.pageMetal + '">판매가격 제공 없음</div></div>';

									liveFoldPpsHtml += '<div class="price-box" id="foldSarok_01_' +sorin.chart.pageMetal + '">'
										+ '<span class="wrhous">서구산&nbsp;</span>'
										+ '<div class="price" id="foldNoSarok_01_' +sorin.chart.pageMetal + '">판매가격 제공 없음</div>'
										+ '</div>'
										+ '<span class="diver">/</span>'
										+ '<div class="price-box" id="foldSarok_02_' +sorin.chart.pageMetal + '">'
										+ '<span class="wrhous">비서구산&nbsp;</span>'
										+ '<div class="price" id="foldNoSarok_02_' +sorin.chart.pageMetal + '">판매가격 제공 없음</div>'
										+ '</div>'
										+ '<span class="ml5 fc-lgray fs12 hide" id="foldVatSarok_' +sorin.chart.pageMetal + '">(부가세 미포함)</span>';
								} else if(sorin.chart.pageMetal == '8') {
									tableListAreaHtml += '<div class="l-inner rvcmpn" id="sarok_51_' +sorin.chart.pageMetal + '">'
										+ '<div class="c-wrhous"><span class="brand-group">합금용</span></div>'
										+ '<div class="c-rate" style="width: 50%" id="noSarok_51_' + sorin.chart.pageMetal + '">판매가격 제공 없음</div></div>'
										+ '<div class="l-inner rvcmpn" id="sarok_52_' +sorin.chart.pageMetal + '">'
										+ '<div class="c-wrhous"><span class="brand-group">도금용</span></div>'
										+ '<div class="c-rate" style="width: 50%" id="noSarok_52_' + sorin.chart.pageMetal + '">판매가격 제공 없음</div></div>';

									liveFoldPpsHtml += '<div class="price-box" id="foldSarok_51_' +sorin.chart.pageMetal + '">'
										+ '<span class="wrhous">합금용&nbsp;</span>'
										+ '<div class="price" id="foldNoSarok_51_' +sorin.chart.pageMetal + '">판매가격 제공 없음</div>'
										+ '</div>'
										+ '<span class="diver">/</span>'
										+ '<div class="price-box" id="foldSarok_52_' +sorin.chart.pageMetal + '">'
										+ '<span class="wrhous">도금용&nbsp;</span>'
										+ '<div class="price" id="foldNoSarok_52_' +sorin.chart.pageMetal + '">판매가격 제공 없음</div>'
										+ '</div>'
										+ '<span class="ml5 fc-lgray fs12 hide" id="foldVatSarok_' +sorin.chart.pageMetal + '">(부가세 미포함)</span>';
								}
							}
						tableListAreaHtml += '</div></div>';
						}
					});

					$("#sarokTap").empty();
					$("#sarokTap").html(sarokTap);
				}

				$(document).off('click','#buttonVat' + liveInfo.codeNm + liveInfo.sleMthdCode).on('click','#buttonVat' + liveInfo.codeNm + liveInfo.sleMthdCode, function() {
					if (!$(this).hasClass('active') ) {
						$(this).removeClass('active');
						$(this).text("부가세 별도");
						$('[nonVatSarokPc=' + sorin.chart.metalNm + sorin.chart.sleMthdCode + ']').show();
						$('[sarokPc=' + sorin.chart.metalNm + sorin.chart.sleMthdCode + ']').hide();
					} else {
						$(this).addClass('active');
						$(this).text("부가세 포함");
						$('[nonVatSarokPc=' + sorin.chart.metalNm + sorin.chart.sleMthdCode + ']').hide();
						$('[sarokPc=' + sorin.chart.metalNm + liveInfo.sleMthdCode + ']').show();
					}
				});

				//알림설정 버튼
				if("02" == sorin.chart.pageSleMthd){
					$("#sorinModalAlarmId").hide();
				} else {
					$("#sorinModalAlarmId").show();
				}

				$(".rcharts-wrap.nodata").hide().siblings().show();

				if($("#chartHolder").is(":visible") & sorin.chart.metalCode == sorin.chart.pageMetal) {
					//차트 상단 시간 변경
					var dataType = $("#dataType").find("li.on").attr("value");
					var txt = $("#chart_type").find("li.selected.on").text();

					price	= addComma($("#"+ liveInfo.codeNm + liveInfo.sleMthdCode + "-price").html().replace(/[^0-9]/g,''));
					rate	= $("#"+ liveInfo.codeNm + liveInfo.sleMthdCode + "-rate").html();
					upDown	= rate > 0 ? "▲":"▼";
					selMetal = liveInfo.codeNm;
					$(document).prop('title', "[케이지트레이딩] LIVE "+selMetal+" "+price+" "+ upDown+" "+ rate);

					if(currentPage == "main" || currentPage == "/main/") {
						sorin.chart.type = dataType;
						setNewData(); //차트 호출
					}
				}


				if(headerOpenTimeCode == '40') {
					$('#msgAlOpening').addClass('msg-al-opening');
					$('#msgAlOpening').show();
				} else {
					$('#msgAlOpening').removeClass('msg-al-opening');
					$('#msgAlOpening').hide();
				}
				chartSumTitle1 = true;
				chartSumTitle2 = false;
				avgEndPcChange('chartTab');

			}
		}
	}
});

$(document).off('click', '.rChart-table .li:not(.thead, .close)').on('click', '.rChart-table .li:not(.thead, .close)', function(){
	let activeLine = $('.rChart-table .list > .li.active');
	let clipProd = activeLine.children().find('.c-prod strong').text();
	let clipTicker;
	let clipDesc;

    $(this).addClass('active').siblings().removeClass('active');
    clipProd = $(this).children().find('.c-prod strong').text();

	let metalName = $(this).children().find('.c-prod span').text();
    let headProd = $(this).parents('.charts-wrap').find('#headProd');
    let headTicker = $(this).parents('.charts-wrap').find('#headTicker');
    let headDesc = $(this).parents('.charts-wrap').find('#headDesc');

	let metalCode = $('.rChart-table .list > .li.active').find('input[name=metalCode]').val();
	let itmSn = $('.rChart-table .list > .li.active').find('input[name=itmSn]').val();
	let dstrctLclsfCode = $('.rChart-table .list > .li.active').find('input[name=dstrctLclsfCode]').val();
	let brandGroupCode = $('.rChart-table .list > .li.active').find('input[name=brandGroupCode]').val();
	let brandCode = $('.rChart-table .list > .li.active').find('input[name=brandCode]').val();
	let sleMthdCode = $('.rChart-table .list > .li.active').find('input[name=sleMthdCode]').val();

	clipTicker = $('.rChart-table .list > .li.active').find('input[name=clipTicker]').val();
	clipDesc = $('.rChart-table .list > .li.active').find('input[name=clipDesc]').val();
	// 차트 상단 가격 동기화
	$('#cPrice').text($('.rChart-table .list > .li.active').find('.c-price').html());
	$('#cRate').text($('.rChart-table .list > .li.active').find('.c-rate').html());
	$('#cGap').text($('.rChart-table .list > .li.active').find('.c-gap').html());

	let rate = $('.rChart-table .list > .li.active').find('.c-rate').html().replace("%",'');

	if(Number(rate) >= 0){
		$(".rChart-current").removeClass("down");
		$(".rChart-current").addClass("up");
	} else{
		$(".rChart-current").removeClass("up");
		$(".rChart-current").addClass("down");
	}

    headProd.text(clipProd);
    headTicker.text(clipTicker);
    headDesc.text(clipDesc);

});

/*
if(currentPage != 'main'){
	$("#btns").hide();
} else {
	$("#btns").show();
}*/

function  loginPage(){
	pageMove('/account/login','','','-1');
}

//차트 영역 접기
$("#btnChartFold").off("click").on("click", function(){
	let chartWrap = $(this).parents().closest('.charts-wrap.sub');

    if (chartWrap.hasClass('fold')) {
        chartWrap.removeClass('fold');
        $(this).text('접어보기');
    } else {
        chartWrap.addClass('fold');
        $(this).text('펼쳐보기');
    }
});

function setSarokPcList() {
	let stopInterval = 0;
	sorin.ajax.postJSON("/main/getSarokPcList", JSON.stringify(''), false, function(result) {
		if(!sorin.validation.isNull(result)) {
			for(var i = 0; i < result.length; i++) {
				//메인차트 시작
				if( $("#sarok_" + result[i].BRAND_GROUP_CODE + "_" + result[i].METAL_CODE ).length == 0 ){
					continue;
				}

				if($("#existSarok_" + result[i].BRAND_GROUP_CODE + "_" + result[i].METAL_CODE ).length > 0 ){
					continue;
				}else{
					let sleMthdCode = $("#sarok_" + result[i].BRAND_GROUP_CODE + "_" + result[i].METAL_CODE ).attr("sleMthdCode");
					let appendHtml = "<div class='c-price' nonvatsarokpc='"+result[i].METAL_NAME+sleMthdCode+"'>"+result[i].NON_VAT_SAROK_PC+"</div>" +
							  		 "<div class='c-price' sarokpc='"+result[i].METAL_NAME+sleMthdCode+"' style='display: none'>"+result[i].SAROK_PC+"</div>" +
							   		 "<div class='c-rate'>"+result[i].SAROK_PC_RATE+"%</div>"
					$("#noSarok_" + result[i].BRAND_GROUP_CODE + "_" + result[i].METAL_CODE ).remove();

					if( result[i].SAROK_PC_RATE > 0 ){
						$("#sarok_" + result[i].BRAND_GROUP_CODE + "_" + result[i].METAL_CODE ).addClass("up");
					}else if( result[i].SAROK_PC_RATE < 0 ){
						$("#sarok_" + result[i].BRAND_GROUP_CODE + "_" + result[i].METAL_CODE ).addClass("down");
					}
					$("#sarok_" + result[i].BRAND_GROUP_CODE + "_" + result[i].METAL_CODE ).append(appendHtml);
					$("#sarok_" + result[i].BRAND_GROUP_CODE + "_" + result[i].METAL_CODE ).attr("id","existSarok_" + result[i].BRAND_GROUP_CODE + "_" + result[i].METAL_CODE );

					stopInterval++;
				}
				//메인차트 종료
			}
			for(var i = 0; i < result.length; i++) {
				//접어보기 차트 시작
				if( $("#foldSarok_" + result[i].BRAND_GROUP_CODE + "_" + result[i].METAL_CODE ).length == 0 ){
					continue;
				}

				if($("#foldExistSarok_" + result[i].BRAND_GROUP_CODE + "_" + result[i].METAL_CODE ).length > 0 ){
					continue;
				}else{
					let appendHtml = "";
					$("#foldNoSarok_" + result[i].BRAND_GROUP_CODE + "_" + result[i].METAL_CODE ).remove();

					if( result[i].SAROK_PC_RATE > 0 ){
						appendHtml = "<div class='price up'>"+result[i].NON_VAT_SAROK_PC+"</div>"
					}else if( result[i].SAROK_PC_RATE < 0 ){
						appendHtml = "<div class='price down'>"+result[i].NON_VAT_SAROK_PC+"</div>"
					}else{
						appendHtml = "<div class='price'>"+result[i].NON_VAT_SAROK_PC+"</div>"
					}
					$("#foldSarok_" + result[i].BRAND_GROUP_CODE + "_" + result[i].METAL_CODE ).append(appendHtml);
					$("#foldSarok_" + result[i].BRAND_GROUP_CODE + "_" + result[i].METAL_CODE ).attr("id","foldExistSarok_" + result[i].BRAND_GROUP_CODE + "_" + result[i].METAL_CODE );
					$("#foldVatSarok_" + result[i].METAL_CODE ).removeClass("hide");

					stopInterval++;
				}
				//접어보기 차트 시작
			}
		}
	});

	if(stopInterval == 0){
		for (var i = 0 ; i <= setIntervalId ; i++) {
			clearInterval(i);
		}
	}
}

