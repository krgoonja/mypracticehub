'use strict';


$(function () {
	
	
		/* ::::: mobile height 100vh ::::: */
		let vh = window.innerHeight * 0.01;
		document.documentElement.style.setProperty("--vh", `${vh}px`);

		window.addEventListener("resize", () => {
		  let vh = window.innerHeight * 0.01;
		  document.documentElement.style.setProperty("--vh", `${vh}px`);
		});
		
		
		
		/* ::::: window scroll시 상단 fixed 영역 ::::: */
		const header = $('.header');
		const headerHt = $(header).height();
		const content = $('.content');
		const searchbar = $('.search-bar');
		//const mainContent = $('.main-content');
		
		$(window).on('scroll', function(){
			
			let winScrollTop = $(this).scrollTop();
			
			if (winScrollTop > headerHt) {
				$(header).addClass('fixed');
				$(content).addClass('fixed');
			} else {
				$(header).removeClass('fixed');
				$(content).removeClass('fixed');
			}
			
		});

	
		/* ::::: 메인 > .btn-menu > .sidebar show ::::: */
		let $btnMenu = $('.btn-menu');    	
		let $sideBar = $('.sidebar');    	
    	
		$btnMenu.on('click', () => {
			$('.sidebar').stop().animate({'left': '0'}, 300, 'swing');
		});

		/* ::::: Modal: 닫기 버튼 클릭 시 ::::: */
		$('.btn-pop-close').on('click', function () {
			$(this).parents('.modal').removeClass('active');
		});
		
		$('.modal-x').on('click', function () {	
			$(this).parents('.modal').removeClass('active');
		});
		
		$('.btn-pop-x').on('click', function () {
			$(this).parents('.modal').removeClass('active');
		});

		$('.btn-sb-close').on('click', function () {
			$('.sidebar').stop().animate({'left': '-100%'}, 100);
		});
		
		$('.arr').on('click', function () {	
			$(this).toggleClass('active');
		});
		
		/* ::::: bottom pop banner layout ::::: */
    	let $btmpopBtn = $('.btn-btm-pop');
    	let $btmPopWrap = $('.btm-pop-wrap');
    	let $btmPopCont = $('.btm-pop-wrap').find('.btm-pop-content');
    	let $btnPopClose = $('.btn-pop-close');

    	
    	// Function: bottom pop banner 나타남
		function btmPopAppear() {
			// 위치 초기화
			$btmPopCont.css({'bottom': '-15rem'});
				
			// bottom pop 활성화
			$btmPopWrap.addClass('active');	
			$btmPopCont.stop().animate({'bottom': '-0.2rem'}, 400);	
		}
		
		// Function: bottom pop banner 사라짐
		function btmPopDisappear() {
			$btmPopWrap.removeClass('active');	
			$btmPopCont.css({'bottom': '-15rem'});	
		}


		// window laod 시: 나타남
		$(window).on('load', () => {
			btmPopAppear()
		})
		
		// pop banner > 닫기 버튼 클릭시: 사라짐
		$btnPopClose.on('click', () => {
			btmPopDisappear()
		});
		



	    /* ::::: calendar(pignose.calendar plugin 사용) ::::: */
	    // calendar 영역 클릭 시
    	let $calendarBox = $('.calendar-field').find('.date-box');

		$calendarBox.each(function(){
			$(this).on('click', function(e){
				e.preventDefault()
		        $(this).parents('.calendar-field').addClass('active');
		        $(this).parents('.calendar-field').find('.calendar').stop().animate({'bottom':'0'}, 400);
		        $(this).parents('.calendar-field').find('.btm-btn-area').stop().animate({'bottom':'0'}, 400);
			});
			
			$('.btn-select-date').on('click', function(e){
				e.preventDefault()
		        $('.calendar-field').removeClass('active');
				$('.calendar').css({'bottom':'-15rem'});
		    	$('.btm-btn-area').css({'bottom':'-15rem'});
		    });
	    });

	    
	    // Function: calendar-single(1개)
        function selectDate1(date, obj) {

			let $calendar = obj.calendar;
            let $box = $calendar.parents('.calendar-field').find('.date-box');
            let text = '';
 
            if(date[0] !== null) {
                text += date[0].format('YYYY-MM-DD');
            } else if(date[0] === null && date[1] == null) {
                text += '날짜 선택';   //date 선택 안 했을때
            }
 
            $box.text(text);
            $box.addClass('active');
			
        }
	    // Function: calendar-single(1개)
        function selectDate4(date, obj) {

			let $calendar = obj.calendar;
            let $box = $calendar.parents('.calendar-field').find('.date-box1');
            let text = '';
 
            if(date[0] !== null) {
                text += date[0].format('YYYY-MM-DD');
            } else if(date[0] === null && date[1] == null) {
                text += '날짜 선택';   //date 선택 안 했을때
            }
 
            $box.text(text);
             $box.val(text);
            $box.addClass('active');
			
        }
	    // Function: calendar-single(1개)
        function selectDate5(date, obj) {

			let $calendar = obj.calendar;
            let $box = $calendar.parents('.calendar-field').find('.date-box2');
            let text = '';
 
            if(date[0] !== null) {
                text += date[0].format('YYYY-MM-DD');
            } else if(date[0] === null && date[1] == null) {
                text += '날짜 선택';   //date 선택 안 했을때
            }
 
            $box.text(text);
            $box.val(text);
            $box.addClass('active');
			
        }

		$('.calendar-single').pignoseCalendar({
            select: selectDate1,
            toggle: false,
	        multiple: false,
	        lang: 'ko',
	        minDate: moment().format("YYYY-MM-DD"),
            disabledDates: ['2024-04-25'],
            //disabledRanges: [['2023-12-01', '2023-12-09']],
        });

		$('.calendar-single1').pignoseCalendar({
            select: selectDate4,
            toggle: false,
	        multiple: false,
	        lang: 'ko',
	        maxDate: moment().format("YYYY-MM-DD")
            //disabledRanges: [['2023-12-01', '2023-12-09']],
        });
		$('.calendar-single2').pignoseCalendar({
            select: selectDate5,
            toggle: false,
	        multiple: false,
	        lang: 'ko',
 	        maxDate: moment().format("YYYY-MM-DD")
            //disabledRanges: [['2023-12-01', '2023-12-09']],
        });
        
	    // Function: calendar-double(2개)
       	function selectDate2(date, obj) {

            let $calendar = obj.calendar;
            let $box1 = $calendar.parents('.calendar-field').find('.date-box1');
            let $box2 = $calendar.parents('.calendar-field').find('.date-box2');
            let text1 = '';
            let text2 = '';
 
            if(date[0] !== null) {
                text1 += date[0].format('YYYY-MM-DD');
            }  // 첫 번째 날짜 선택
 
            if(date[0] !== null && date[1] !== null) {
                // text += ' ~ ';  날짜 두 개 선택
            } else if(date[0] === null && date[1] == null) {
                text1 += '날짜 선택';   //date1 선택 안 했을때
                text2 += '날짜 선택';   //date2 선택 안 했을때
            }
 
            if(date[1] !== null) {
            	text2 += date[1].format('YYYY-MM-DD');
            } // 두 번째 날짜 선택
            $box1.text(text1);
            $box2.text(text2);
            $box1.val(text1);
            $box2.val(text2);
            $box1.addClass('active');
            $box2.addClass('active');
        }
 	   
		//현재 날짜 이전 비활성화
 	    $('.calendar-double').pignoseCalendar({
            select: selectDate2,
            toggle: false,
	        multiple: true,
	        lang: 'ko',
	        minDate: moment().format("YYYY-MM-DD")
            //disabledDates: ['2023-12-26'],
            //disabledRanges: [['2023-12-01', '2023-12-09']],
        });
        
		//현재 날짜 이후 비활성화
 	    $('.calendar-double-prev').pignoseCalendar({
            select: selectDate2,
            toggle: false,
	        multiple: true,
	        lang: 'ko',
	        maxDate: moment().format("YYYY-MM-DD")
            //disabledDates: ['2023-12-26'],
            //disabledRanges: [['2023-12-01', '2023-12-09']],
        });




        /* ::::: 공통: .dim 클릭시 해당 영역 reset ::::: */            
        let $dimArea = $('.dim');
				
		$dimArea.on('click', () => {
			// 1. 메인 > bottom pop banner
			btmPopDisappear()
			
			// 2. .calendar-box 
			$('.calendar-field').removeClass('active');
			$('.calendar').css({'bottom':'-15rem'});
	    	$('.btm-btn-area').css({'bottom':'-15rem'});
	    	
	    	// 3. Modal
			$(this).parents('.modal').removeClass('active');
		});
        
        
        
        
		/* ::::: .tab 이벤트(.metal-tab/ .tab-raido/ .tab-checkbox) ::::: */
	    // .tab-title active
		$('.tab-title').each(function(){
			$(this).find('span').on('click', function(e){
				$(this).parents('.tab-title').find('span').removeClass('active');
				$(this).addClass('active');
			});
	    });
	    
	    
	    
		/* ::::: .select-field ::::: */
	    // 기사 정보 selectbox > 직접입력 option 선택시 modal(#modalOptionSelf) 활성화
	    $(".selbox-driver-info").change(function() {
	        let val = $(this).val();
	
	        if (val == '직접입력') {
	            $('#modalOptionSelf').addClass('active')
	        }
	    });
})

