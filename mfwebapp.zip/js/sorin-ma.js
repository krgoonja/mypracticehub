'use strict';
/********* MAIN */
$(function() {
	let today = getToday();
});

///////////// 0.기본 설정(타이틀, 팝업, 소켓 등) ////////////////
// 오늘날짜 yyyyMMdd 형식으로 가져오기
function getToday() {
	let now = new Date();
	let year = now.getFullYear();
	let month = now.getMonth() + 1;
	month = month < 10 ? "0" + month : month;
	let date = now.getDate();
	date = date < 10 ? "0" + date : date;
	return '' + year + month + date;
}

// 알림설정 팝업 : 희망가 알림 생성 내역, 원클릭 주문 알림
$('#sorinModalAlarm .toggle').off('click').on('click', function() {
	if ($(this).attr('data-value') == 'oneclick-order') {
		$('#sorinModalAlarm .tbl-oneclick').addClass('active');
	} else {
		$('#sorinModalAlarm .tbl-oneclick').removeClass('active');
	}
});

///////////// 헤더 설정 ////////////////

///////////// 1. 메인배너 ////////////////
// 메인 GRAB THE MOMENT Slider:: 23.06.23 신규생성
var mainSwiperGrap = new Swiper(".main-swiper", {
	slidesPerView: 1,
	effect: "fade",
	autoplay: {
		delay: 4000,
		disableOnInteration: false,
	},
	loop: true,
	initialSlide: 1,
	navigation: {
		nextEl: ".swiper-button-next",
		prevEl: ".swiper-button-prev",
	},
	pagination: {
		el: ".swiper-pagination",
		clickable: true,
		type: 'fraction'
	},
	on: {
		init: function() {
			// 정지 버튼 클릭시 슬라이더 멈춤
			$(".swiper-button-pause").click(function() {
				mainSwiperGrap.autoplay.stop();
				$('.player-btn').removeClass('on');
				$('.swiper-button-play').addClass('on');
			});

			// 재생 버튼 클릭시 슬라이더 재시작
			$(".swiper-button-play").click(function() {
				mainSwiperGrap.autoplay.start();
				$('.player-btn').removeClass('on');
				$('.swiper-button-pause').addClass('on');
			});

		}
		//init: grapSwiperHover,
		// slideChangeTransitionStart: grapSwiperBg,
	}
});


///////////// 2.차트- 가격 ////////////////
//차트 전광판 스와이퍼
var sumTitleSwiper = new Swiper('#sumTitleWrap', {
	direction: 'vertical',
	autoplay: {
      delay: 5000, // 시간 설정
      disableOnInteraction: false, // false-스와이프 후 자동 재생
    }, 
	loop: true,
	navigation: {  
		nextEl: ".swiper-button-next",
		prevEl: ".swiper-button-prev",
	}
});
///////////// 3.주요뉴스-메탈월드 ////////////////
//메탈월드
var metalWorldSwiper = new Swiper(".metal-world-swiper", {
	pagination: {
		// el: ".swiper-pagination",
		type: "fraction",
	},
	navigation: {
		nextEl: ".metal-world-next",
		prevEl: ".metal-world-prev",
	}
});
var holidayDays = [];

// 특정일 선택막기
function holidayAllTheseDays(date) {
	let m = date.getMonth();
	let d = date.getDate();
	let y = date.getFullYear();
	for (var i = 0; i < holidayDays.length; i++) {
		if ($.inArray(y + '-' + (("0" + (m + 1)).substr(-2)) + '-' + ("0" + d).substr(-2), holidayDays) != -1) {
			return [false];
		}
	}
	return [true];
}
///////////// 4.최신뉴스-원자재 캘린더 ////////////////

///////////// 5.케이지트레이딩 소개 ////////////////
// 메인 케이지트레이딩 소개 Slider
var mainSwiperSorin = new Swiper(".sorinWrapSwiper", {
	autoplay: {
		delay: 5000,
		disableOnInteration: false,
	},
	loop: true,
	navigation: {
		nextEl: ".swiper-button-next",
		prevEl: ".swiper-button-prev",
	},
	pagination: {
		el: ".swiper-pagination",
		clickable: true,
	},
});
///////////// 5.케이지트레이딩 소개 ////////////////


var liveEndPc = ""; //라이브 종료가격
var fixedEndPc = "";//고정가 종료가격

//알람설정 버튼 클릭 이벤트
function sorinModalAlarmIdMain() {
	if (!isBuyPossible("alarm")) {
		return;
	} else {
		if (sorin.chart.headerRestdeAt == "N") { // 영업시간 o
	
			resetPopUp();
	
			let returnSleType = setRealTimeSellPrice(); // 팝업 초기데이터 세팅 (함수)
	
			if (returnSleType != "") {

				// aceScriptPl('alarmSorin1', sorinAccount.entrpsnmKorean, sorinAccount.id);
				pageMove('/my/alarm/alarmList', '', 'application/json', function() {
					$("#modalnotiSetting").addClass('active');
				});

				let confirmTimeResult = confirmSocketAccessTime();

				if (confirmTimeResult) {
					alertPopup("현재 희망가 알림을 설정할 수 없습니다.", function() {
						return true;
					});
					return true;
				}
			} else {
				alertPopup("현재 희망가 알림을 설정할 수 없습니다.", function() {
					return true;
				});
				return;
			}
		} else if (headerRestdeAt == "Y") { // 영업시간 x
			alertPopup("현재 희망가 알림을 설정할 수 없습니다.", function() {
				return true;
			});
			return;
		}
	}
}


/* 팝업 초기데이터 세팅 (함수) return: live fixed */
function setRealTimeSellPrice() {
	let sleType = "";
	let data = {
		metalCode: sorin.chart.metalCode,
		itmSn: sorin.chart.itmSn,
		dstrctLclsfCode: sorin.chart.dstrctLclsfCode,
		brandGroupCode: sorin.chart.brandGroupCode,
		brandCode: sorin.chart.brandCode
	}

	/*
		최초에 세팅되는 endpc는 프리미엄 가격이 포함된 가격
		소켓에서 받아오는 가격(endpc)은 프리미엄 가격을 더해준 다음 세팅해줘야함 +premiumPc
	*/
	sorin.ajax.postSetAllType("/my/alarm/selectRealTimeSellHopePc", JSON.stringify(data), "json", "application/json", false,
		function(data) {

			if (!sorin.validation.isEmpty(data)) {
				liveEndPc = "";
				fixedEndPc = "";

				if (sorin.chart.pageSleMthd == "01") { // 실시간
					if (sorin.chart.headerRestDeLive == "N") { // 실시간 영업 O
						//    							 if(headerSideCarMetalCode == metalCode){
						//     			        		if(headerMotnAt == "Y"){ // 사이드카 O
						//     			        			return;
						//     			        		}
						//     			        		else if(headerMotnAt == "N"){  // 사이드카 x
						if (!sorin.validation.isEmpty(data.liveResultMap)) {
							sleType = "live";
							let liveResultData = data.liveResultMap;
							let versusRate = data.versusRate.toFixed(2);
							let versusPc = data.versusPc;

							liveEndPc = liveResultData.endPc;

							$("#hpPremiumPc").val(liveResultData.premiumPc); // 프리미엄 가격
							$("#currentPrice").text(liveResultData.endPc.toLocaleString());
							$("#ipTargetPrice").val(liveResultData.endPc.toLocaleString());
							
							if (Number(versusPc) > 0) {
								
								$("#currentPrice").removeClass("fc-blue"); //파랑
								$("#currentPrice").addClass("fc-red"); //빨강
								$("#currentPrice").next().text("+" + versusRate + "%");
								$("#currentPrice").next().removeClass("fc-blue"); //파랑
								$("#currentPrice").next().addClass("fc-red"); //빨강
							} else if (Number(versusPc) < 0) {
								
								$("#currentPrice").removeClass("fc-red");
								$("#currentPrice").addClass("fc-blue");
								$("#currentPrice").next().text(versusRate + "%");
								$("#currentPrice").next().removeClass("fc-red");
								$("#currentPrice").next().addClass("fc-blue");
							} else {
								
								$("#currentPrice").removeClass("fc-red");
								$("#currentPrice").removeClass("fc-blue");
								$("#currentPrice").next().removeClass("fc-blue"); //파랑
								$("#currentPrice").next().removeClass("fc-red");
							}
							
						}
						//     			        		}
						//     			        	}
					} else if (sorin.chart.headerRestDeLive == "Y") { //실시간 영업 X
						return;
					}

				} else if (sorin.chart.pageSleMthd == "02") { // 고정가

					if (sorin.chart.headerRestDeFixed == "N") { // 고정가 영업 여부 o

						if (!sorin.validation.isEmpty(data.fixedResultMap)) {
							sleType = "fixed";

							let fixedResultData = data.fixedResultMap;

							fixedEndPc = fixedResultData.sleStdrPc;

							$("#hpMetalCode").val(fixedResultData.metalCode);
							$("#currentPrice").text(fixedResultData.sleStdrPc.toLocaleString());
							$("#ipTargetPrice").val(fixedResultData.sleStdrPc.toLocaleString());

							if (Number(fixedResultData.versusPc) >= 0) {
								$("#currentPrice").next().removeClass("fc-blue"); //파랑
								$("#currentPrice").next().addClass("fc-red"); //빨강
							} else {
								$("#currentPrice").next().removeClass("fc-red");
								$("#currentPrice").next().addClass("fc-blue");
							}


							if (fixedResultData.sleStdrPcRate > 0) {
								$("#currentPrice").next().text("+" + fixedResultData.sleStdrPcRate.toFixed(2) + "%");
							} else if (fixedResultData.sleStdrPcRate < 0) {
								$("#currentPrice").next().text(fixedResultData.sleStdrPcRate.toFixed(2) + "%");
							}


						}

					} else if (sorin.chart.headerRestDeFixed == "Y") { // 고정가 영업 여부 x
						return;
					}
				}
			}

		});

	return sleType;

}

// 팝업 데이터 리셋
function resetPopUp() {
	$("#currentPrice").next().attr('class', '');
	$("#itemNm").val("");
	$("#currentPrice").text("");
	$("#currentPrice").next().text("");
	$("#ipTargetPrice").val("");
	$("#hpPremiumPc").val("");
	$(".target-price-set").find("button[class=btn-blue-md]").attr('class', 'btn-stroke-md');
}

///////////// 9.희망가 알림 설정 팝업 ////////////////
// 희망가 알림 설정 팝업-목표가 focusin 이벤트
$(document).off('focusin', '#ipTargetPrice').on('focusin', '#ipTargetPrice', function() {
	let targetPrice = $(this).val().replace(/[^\d]+/g, "");
	$(this).val(targetPrice);
});

// 희망가 알림 설정 팝업-목표가 keyup 이벤트
$(document).off('keyup', '#ipTargetPrice').on('keyup', '#ipTargetPrice', function() {
	let targetPrice = $(this).val().replace(/[^\d]+/g, "");
	$(this).val(targetPrice);
});

// 희망가 알림 설정 팝업-목표가 focusout 이벤트
$(document).off('focusout', '#ipTargetPrice').on('focusout', '#ipTargetPrice', function() {
	let targetPrice = $(this).val().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	$(this).val(targetPrice);
});

// 희망가 알림 설정 버튼 클릭 이벤트
$(document).off('click', 'button[id^=prcntBtn]').on('click', 'button[id^=prcntBtn]', function() {

	if ($(this).hasClass('btn-blue-md')) {

		$(this).removeClass('btn-blue-md').addClass('btn-stroke-md');
		$(this).siblings('button').removeClass('btn-blue-md').addClass('btn-stroke-md');

		// 판매 방식 코드 01 : live, 02 : 고정가
		if (sorin.chart.pageSleMthd == '01') {
			$(this).parents('.target-price-set').find('input').val(liveEndPc.toLocaleString());
		} else if (sorin.chart.pageSleMthd == '02') {
			$(this).parents('.target-price-set').find('input').val(fixedEndPc.toLocaleString());
		}

	}
	else if ($(this).hasClass('btn-stroke-md')) {
		$(this).addClass('btn-blue-md').removeClass('btn-stroke-md').siblings('button').addClass('btn-stroke-md').removeClass('btn-blue-md');
		let currentPrice = $('#currentPrice').text().replace(/[^\d]+/g, ""); // 숫자 외에 다른 문자는 모두 ""로 replace
		let targetValue = Math.abs($(this).attr('data-value'));
		let newPrice = String(parseInt(currentPrice - (currentPrice * targetValue / 100))).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		$(this).parents('.target-price-set').find('input').val(newPrice);
	}

});
///////////// 9.희망가 알림 설정 팝업 ////////////////

/* 구매 버튼 */
$(document).off("click", "#btnBuy").on("click", "#btnBuy", function() {

	if (!isBuyPossible("buy")) {
		return;
	}

	// aceScriptPl('purchSorin1', sorinAccount.entrpsnmKorean, sorinAccount.id);

	if (sorin.chart.pageSleMthd == "01") { // 실시간
		moveToItemPriceSearch();
	} else if (sorin.chart.pageSleMthd == "02") { // 고정가
		moveToItemPriceSearch();
	}

});

/* itemSeachPrice 페이지로 이동 */
function moveToItemPriceSearch() {
	let searchParam = {
		srhGubunCode: "02",
		metalCode: sorin.chart.metalCode,
		itmSn: sorin.chart.itmSn,
		dstrctLclsfCode: sorin.chart.dstrctLclsfCode,
		brandGroupCode: sorin.chart.brandGroupCode,
		brandCode: sorin.chart.brandCode,
		sleMthdCode: sorin.chart.sleMthdCode,
		metalClCode: sorin.chart.metalClCode,
	}
	
	//트래킹 파라미터 세팅
	searchParam.cnvrsCode = '0201';
	searchParam.cnvrsParam = {
		metalCode: sorin.chart.metalCode,
		itmSn: sorin.chart.itmSn,
		dstrctLclsfCode: sorin.chart.dstrctLclsfCode,
		brandGroupCode: sorin.chart.brandGroupCode,
		brandCode: sorin.chart.brandCode,
		sleMthdCode: sorin.chart.sleMthdCode,
		metalClCode: sorin.chart.metalClCode
	}

	pageMove('/pd/itemPriceSearch', JSON.stringify(searchParam), 'application/json', 'pditemPriceSearch7');

}

/* 알림 설정, 구매 버튼 접근 권한 여부 */
function confirmUserAccess() {

	let accessState = '0';

	if ('01' == sorinAccount.type) { // 회원사 회원 여부

		if (sorinAccount.mberSttusCode == '03') {	//임시회원 계좌상태별 팝업

			if (sorinAccount.refndAcnutSttusCode == '') {
				accessState = '1'; 						//하나은행 계좌 등록 중입니다.

			} else if (sorinAccount.refndAcnutSttusCode == '01') {		//임시회원&환불계좌전송완료
				accessState = '2';						//고객 전용 가상 계좌 준비중입니다.

			} else if (sorinAccount.refndAcnutSttusCode == '03') {		//임시회원&응답완료
				accessState = '3';						//선불금 관리대행 서비스 동의를 진행 중입니다.

			} else if (sorinAccount.refndAcnutSttusCode == '05') {		//임시회원&최종응답완료
				accessState = '4';						//거래회원 승인 대기 중 입니다.

			}
		} else if ('01' != sorinAccount.mberSttusCode) { // 정회원만 접근 가능
			accessState = '5';
		} else if ('' == sorinAccount.secode || '04' == sorinAccount.secode) { // 구분 코드 04 - 자금 담당은 구매 불가
			accessState = '5';
		}

	} else if ('02' == sorinAccount.type) { // 간편 회원 여부
		accessState = '5';
	}

	return accessState;
}

/* 소켓에서 들어온 데이터로 영업시간, 실시간(사이드카 발동 여부), 고정가 영업 여부 비교 */
function confirmSocketAccessTime() {
	let result = false;

	if (sorin.chart.headerRestdeAt == "N") { // 영업시간 O
		if ("01" == sorin.chart.pageSleMthd) { // 실시간
			if (sorin.chart.headerRestDeLive == "N") { // 실시간 영업 O
				if (sorin.chart.headerSideCarMetalCode == 7) {
					if (sorin.chart.headerMotnAt == "Y") { // 사이드카 O
						result = true;
					}
				}
			}
		} else if ("02" == sorin.chart.pageSleMthd) { //고정가
			if (sorin.chart.headerRestDeFixed == "Y") { // 고정가 영업 여부
				result = true;
			}
		}
	}

	return result;
}

