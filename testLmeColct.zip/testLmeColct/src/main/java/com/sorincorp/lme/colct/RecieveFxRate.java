package com.sorincorp.lme.colct;

import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.refinitiv.ema.access.AckMsg;
import com.refinitiv.ema.access.DataType;
import com.refinitiv.ema.access.EmaFactory;
import com.refinitiv.ema.access.FieldEntry;
import com.refinitiv.ema.access.FieldList;
import com.refinitiv.ema.access.GenericMsg;
import com.refinitiv.ema.access.Msg;
import com.refinitiv.ema.access.OmmConsumerClient;
import com.refinitiv.ema.access.OmmConsumerEvent;
import com.refinitiv.ema.access.RefreshMsg;
import com.refinitiv.ema.access.StatusMsg;
import com.refinitiv.ema.access.UpdateMsg;
import com.refinitiv.ema.domain.login.Login.LoginRefresh;
import com.refinitiv.ema.domain.login.Login.LoginStatus;
import com.refinitiv.ema.rdm.EmaRdm;
import com.sorincorp.lme.model.FxRateVo;
import com.sorincorp.lme.send.LmeMulticastSend;

import lombok.extern.slf4j.Slf4j;

/**
 * RecieveFxRate.java
 * @version
 * @since 2024. 8. 26.
 * @author srec0049
 */
@Slf4j
@Component
public class RecieveFxRate implements OmmConsumerClient {
	@Autowired
	LmeMulticastSend lmeMulticastSend;
	
	LoginRefresh _loginRefresh = EmaFactory.Domain.createLoginRefresh();
	LoginStatus _loginStatus = EmaFactory.Domain.createLoginStatus();
	
	public void onRefreshMsg(RefreshMsg refreshMsg, OmmConsumerEvent event) {
		log.info(">>>>>>>>>>> RecieveFxRate >>>>>>>>>>>>>>>>>>>>>>");
		log.info("Received Refresh. Item Handle: " + event.handle() + " Closure: " + event.closure());
		log.info("Item Name: " + (refreshMsg.hasName() ? refreshMsg.name() : "<not set>"));
		log.info("Service Name: " + (refreshMsg.hasServiceName() ? refreshMsg.serviceName() : "<not set>"));
		log.info("Item State: " + refreshMsg.state());
		log.info("refreshMsg.domainType(): " + refreshMsg.domainType() + ", EmaRdm.MMT_LOGIN : " + EmaRdm.MMT_LOGIN);
		
		// 로그인 세션 끊기는 것을 방지하기 위함, LoginRefresh clear
		if(refreshMsg.domainType() == EmaRdm.MMT_LOGIN) {   
		    _loginRefresh.clear();
		    log.info(">> clear : " + _loginRefresh.message(refreshMsg).toString());   
		} else {
			FxRateVo krw = new FxRateVo();
			FxRateVo cny = new FxRateVo();
			FxRateVo jpykrw = new FxRateVo();
			FxRateVo eurkrw = new FxRateVo();
			FxRateVo sgd = new FxRateVo();
			FxRateVo sgdusd = new FxRateVo();
			
			if(refreshMsg.name().contains("KRW=")) {
				krw.setGridDiv("krw");
				if (DataType.DataTypes.FIELD_LIST == refreshMsg.payload().dataType())
					decode(refreshMsg.payload().fieldList(),krw);			
			}else if(refreshMsg.name().contains("CNY=")) {
				cny.setGridDiv("cny");
				if (DataType.DataTypes.FIELD_LIST == refreshMsg.payload().dataType())
					decode(refreshMsg.payload().fieldList(),cny);			
			}else if(refreshMsg.name().contains("JPYKRW=R")) {
				jpykrw.setGridDiv("jpykrw");
				if (DataType.DataTypes.FIELD_LIST == refreshMsg.payload().dataType())
					decode(refreshMsg.payload().fieldList(),jpykrw);			
			}else if(refreshMsg.name().contains("EURKRW=R")) {
				eurkrw.setGridDiv("eurkrw");
				if (DataType.DataTypes.FIELD_LIST == refreshMsg.payload().dataType())
					decode(refreshMsg.payload().fieldList(),eurkrw);			
			}else if(refreshMsg.name().contains("SGD=")) {
				sgd.setGridDiv("sgd");
				if (DataType.DataTypes.FIELD_LIST == refreshMsg.payload().dataType())
					decode(refreshMsg.payload().fieldList(),sgd);			
			}else if(refreshMsg.name().contains("SGDUSD=R")) {
				sgdusd.setGridDiv("sgdusd");
				if (DataType.DataTypes.FIELD_LIST == refreshMsg.payload().dataType())
					decode(refreshMsg.payload().fieldList(),sgdusd);			
			}
		}
		
	}
	
	public void onUpdateMsg(UpdateMsg updateMsg, OmmConsumerEvent event) {
		FxRateVo krw = new FxRateVo();
		FxRateVo cny = new FxRateVo();
		FxRateVo jpykrw = new FxRateVo();
		FxRateVo eurkrw = new FxRateVo();
		FxRateVo sgd = new FxRateVo();
		FxRateVo sgdusd = new FxRateVo();
		//
//		FxRateVo krwndf = new FxRateVo();
		
		if(updateMsg.name().equals("KRW=")) {
			krw.setGridDiv("krw");
			if (DataType.DataTypes.FIELD_LIST == updateMsg.payload().dataType())
				decode(updateMsg.payload().fieldList(), krw);			
		}else if(updateMsg.name().equals("CNY=")) {
			cny.setGridDiv("cny");
			if (DataType.DataTypes.FIELD_LIST == updateMsg.payload().dataType())
				decode(updateMsg.payload().fieldList(), cny);			
		}else if(updateMsg.name().equals("JPYKRW=R")) {
			jpykrw.setGridDiv("jpykrw");
			if (DataType.DataTypes.FIELD_LIST == updateMsg.payload().dataType())
				decode(updateMsg.payload().fieldList(), jpykrw);			
		}else if(updateMsg.name().equals("EURKRW=R")) {
			eurkrw.setGridDiv("eurkrw");
			if (DataType.DataTypes.FIELD_LIST == updateMsg.payload().dataType())
				decode(updateMsg.payload().fieldList(), eurkrw);			
		}else if(updateMsg.name().equals("SGD=")) {
			sgd.setGridDiv("sgd");
			if (DataType.DataTypes.FIELD_LIST == updateMsg.payload().dataType())
				decode(updateMsg.payload().fieldList(), sgd);			
		}else if(updateMsg.name().equals("SGDUSD=R")) {
			sgdusd.setGridDiv("sgdusd");
			if (DataType.DataTypes.FIELD_LIST == updateMsg.payload().dataType())
				decode(updateMsg.payload().fieldList(), sgdusd);			
		}
	}
	
	public void onStatusMsg(StatusMsg statusMsg, OmmConsumerEvent event) {
		log.info(">>>>>>>>>>> RecieveFxRate >>>>>>>>>>>>>>>>>>>>>>");
		log.info("Received Status. Item Handle: " + event.handle() + " Closure: " + event.closure());
		log.info("Item Name: " + (statusMsg.hasName() ? statusMsg.name() : "<not set>"));
		log.info("Service Name: " + (statusMsg.hasServiceName() ? statusMsg.serviceName() : "<not set>"));
		log.info("onStatusMsg Item State: " + statusMsg);
		
		if (statusMsg.hasState()) {
			log.info("Item State: " +statusMsg.state());
		}
		
		// 로그인 세션 끊기는 것을 방지하기 위함, LoginStatus clear
        if (statusMsg.domainType() == EmaRdm.MMT_LOGIN) {
            _loginStatus.clear();
            log.info(">> clear : " + _loginStatus.message(statusMsg).toString());   
        }
		
	}
	
	public void onGenericMsg(GenericMsg genericMsg, OmmConsumerEvent consumerEvent){}
	public void onAckMsg(AckMsg ackMsg, OmmConsumerEvent consumerEvent){}
	public void onAllMsg(Msg msg, OmmConsumerEvent consumerEvent){}
	
	public void decode(FieldList fieldList, FxRateVo vo) {
		for (FieldEntry fieldEntry : fieldList) { 
			System.out.println("Fid: " +  fieldEntry.fieldId() + " Name: " + fieldEntry.name() + " value: " +  fieldEntry.load()); 
		}		
		boolean sendYN = false;
		Iterator<FieldEntry> iter = fieldList.iterator();
		FieldEntry fieldEntry;
		while (iter.hasNext()) {
			fieldEntry = iter.next();
//			System.out.println("fxRate_FIELD_ENTRY: " + fieldEntry.fieldId() + " /  " + fieldEntry.name() + ": " + fieldEntry.load() + " loadType: " + fieldEntry.loadType());
			if(fieldEntry.name().equals("VALUE_DT1")) { 
				sendYN = true;
				vo.setVALUE_DT1(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("VALUE_DT2")) { 
				sendYN = true;
				vo.setVALUE_DT2(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("VALUE_DT3")) { 
				sendYN = true;
				vo.setVALUE_DT3(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("BID")) { 
				sendYN = true;
				vo.setBID(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("BID_1")) { 
				sendYN = true;
				vo.setBID_1(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("BID_2")) { 
				sendYN = true;
				vo.setBID_2(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("ASK")) { 
				sendYN = true;
				vo.setASK(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("ASK_1")) { 
				sendYN = true;
				vo.setASK_1(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("ASK_2")) { 
				sendYN = true;
				vo.setASK_2(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("BID_HIGH_1")) { 
				sendYN = true;							
				vo.setBID_HIGH_1(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("BID_LOW_1")) { 
				sendYN = true;							
				vo.setBID_LOW_1(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("OPEN_BID")) { 
				sendYN = true;							
				vo.setOPEN_BID(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("OPEN_ASK")) { 
				sendYN = true;							
				vo.setOPEN_ASK(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("CLOSE_BID")) { 
				sendYN = true;							
				vo.setCLOSE_BID(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("CLOSE_ASK")) { 
				sendYN = true;							
				vo.setCLOSE_ASK(fieldEntry.load().toString());
			}
			
			if(sendYN) {
				try {
					ObjectMapper mapper = new ObjectMapper(); 
			    	String message = mapper.writeValueAsString(vo);
					
					// 이 부분에서 멀티캐스트(UDP 기반)로 소켓 통신 전송하고 LME는 이를 받는다.
			    	lmeMulticastSend.multicastSend(message);
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

}
