package com.sorincorp.lme.send;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

/**
 * LmeMulticastSend.java
 * @version
 * @since 2024. 8. 23.
 * @author srec0049
 */
@Slf4j
@Component
public class LmeMulticastSend {

	@Value("${spring.lme.udp.ip}")
	private String multicastIp;
	
	@Value("${spring.lme.udp.port}")
	private int multicastPort;
	
	private DatagramSocket socket;
	private InetAddress group;
	private byte[] buf;

	@Async("lmeThreadPoolExcuter")
    public void multicastSend(String message) throws Exception {
    	log.info("multicastSend 대상 전문: " + message);
    	
        socket = new DatagramSocket();
        group = InetAddress.getByName(multicastIp);
        buf = message.getBytes();

        DatagramPacket packet = new DatagramPacket(buf, buf.length, group, multicastPort);
        socket.send(packet);
        socket.close();
    }
}
