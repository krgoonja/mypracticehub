package com.sorincorp.lme.colct;

import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.refinitiv.ema.access.AckMsg;
import com.refinitiv.ema.access.DataType;
import com.refinitiv.ema.access.EmaFactory;
import com.refinitiv.ema.access.FieldEntry;
import com.refinitiv.ema.access.FieldList;
import com.refinitiv.ema.access.GenericMsg;
import com.refinitiv.ema.access.Msg;
import com.refinitiv.ema.access.OmmConsumerClient;
import com.refinitiv.ema.access.OmmConsumerEvent;
import com.refinitiv.ema.access.RefreshMsg;
import com.refinitiv.ema.access.StatusMsg;
import com.refinitiv.ema.access.UpdateMsg;
import com.refinitiv.ema.domain.login.Login.LoginRefresh;
import com.refinitiv.ema.domain.login.Login.LoginStatus;
import com.refinitiv.ema.rdm.EmaRdm;
import com.sorincorp.lme.model.DataVo;
import com.sorincorp.lme.send.LmeMulticastSend;

import lombok.extern.slf4j.Slf4j;

/**
 * RecieveLMERT.java
 * @version
 * @since 2024. 8. 7.
 * @author srec0049
 */
@Slf4j
@Component
public class RecieveLMERT implements OmmConsumerClient {
	@Autowired
	LmeMulticastSend lmeMulticastSend;
	
	LoginRefresh _loginRefresh = EmaFactory.Domain.createLoginRefresh();
	LoginStatus _loginStatus = EmaFactory.Domain.createLoginStatus();
	
	public void onRefreshMsg(RefreshMsg refreshMsg, OmmConsumerEvent event) {
		log.info(">>>>>>>>>>> RecieveLMERT >>>>>>>>>>>>>>>>>>>>>>");
		log.info("Received Refresh. Item Handle: " + event.handle() + " Closure: " + event.closure());
		log.info("Item Name: " + (refreshMsg.hasName() ? refreshMsg.name() : "<not set>"));
		log.info("Service Name: " + (refreshMsg.hasServiceName() ? refreshMsg.serviceName() : "<not set>"));
		log.info("Item State: " + refreshMsg.state());
		log.info("refreshMsg.domainType(): " + refreshMsg.domainType() + ", EmaRdm.MMT_LOGIN : " + EmaRdm.MMT_LOGIN);
		
		// 로그인 세션 끊기는 것을 방지하기 위함, LoginRefresh clear
		if(refreshMsg.domainType() == EmaRdm.MMT_LOGIN) {   
		    _loginRefresh.clear();
		    log.info(">> clear : " + _loginRefresh.message(refreshMsg).toString());   
		} else {
			DataVo zn = new DataVo();
			DataVo pb = new DataVo();
			DataVo al = new DataVo();
			DataVo cu = new DataVo();
			DataVo ni = new DataVo();
			
			if(refreshMsg.name().equals("CMZN3")) {
				zn.setRicCode("CMZN3");
				if (DataType.DataTypes.FIELD_LIST == refreshMsg.payload().dataType())
					decode(refreshMsg.payload().fieldList(), zn);			
			}else if(refreshMsg.name().equals("CMPB3")) {
				pb.setRicCode("CMPB3");
				if (DataType.DataTypes.FIELD_LIST == refreshMsg.payload().dataType())
					decode(refreshMsg.payload().fieldList(), pb);			
			}else if(refreshMsg.name().equals("CMAL3")) {
				al.setRicCode("CMAL3");
				if (DataType.DataTypes.FIELD_LIST == refreshMsg.payload().dataType())
					decode(refreshMsg.payload().fieldList(), al);			
			}else if(refreshMsg.name().equals("CMNI3")) {
				ni.setRicCode("CMNI3");
				if (DataType.DataTypes.FIELD_LIST == refreshMsg.payload().dataType())
					decode(refreshMsg.payload().fieldList(), ni);			
			}else if(refreshMsg.name().equals("CMCU3")) {
				cu.setRicCode("CMCU3");
				if (DataType.DataTypes.FIELD_LIST == refreshMsg.payload().dataType())
					decode(refreshMsg.payload().fieldList(), cu);			
			}
	    }
		
		
	}
	
	public void onUpdateMsg(UpdateMsg updateMsg, OmmConsumerEvent event) {
		DataVo zn = new DataVo();
		DataVo pb = new DataVo();
		DataVo al = new DataVo();
		DataVo cu = new DataVo();
		DataVo ni = new DataVo();
		
		if(updateMsg.name().equals("CMZN3")) {
			zn.setRicCode("CMZN3");
			if (DataType.DataTypes.FIELD_LIST == updateMsg.payload().dataType())
				decode(updateMsg.payload().fieldList(), zn);			
		}else if(updateMsg.name().equals("CMPB3")) {
			pb.setRicCode("CMPB3");
			if (DataType.DataTypes.FIELD_LIST == updateMsg.payload().dataType())
				decode(updateMsg.payload().fieldList(), pb);			
		}else if(updateMsg.name().equals("CMAL3")) {
			al.setRicCode("CMAL3");
			if (DataType.DataTypes.FIELD_LIST == updateMsg.payload().dataType())
				decode(updateMsg.payload().fieldList(), al);			
		}else if(updateMsg.name().equals("CMNI3")) {
			ni.setRicCode("CMNI3");
			if (DataType.DataTypes.FIELD_LIST == updateMsg.payload().dataType())
				decode(updateMsg.payload().fieldList(), ni);			
		}else if(updateMsg.name().equals("CMCU3")) {
			cu.setRicCode("CMCU3");
			if (DataType.DataTypes.FIELD_LIST == updateMsg.payload().dataType())
				decode(updateMsg.payload().fieldList(), cu);			
		}
	}
	
	public void onStatusMsg(StatusMsg statusMsg, OmmConsumerEvent event) {
		log.info(">>>>>>>>>>> RecieveLMERT >>>>>>>>>>>>>>>>>>>>>>");
		log.info("Received Status. Item Handle: " + event.handle() + " Closure: " + event.closure());
		log.info("Item Name: " + (statusMsg.hasName() ? statusMsg.name() : "<not set>"));
		log.info("Service Name: " + (statusMsg.hasServiceName() ? statusMsg.serviceName() : "<not set>"));
		log.info("onStatusMsg Item State: " + statusMsg);
		
		if (statusMsg.hasState()) {
			log.info("Item State: " +statusMsg.state());
		}
		
		// 로그인 세션 끊기는 것을 방지하기 위함, LoginStatus clear
        if (statusMsg.domainType() == EmaRdm.MMT_LOGIN) {
            _loginStatus.clear();
            log.info(">> clear : " + _loginStatus.message(statusMsg).toString());   
        }
		
	}
	
	public void onGenericMsg(GenericMsg genericMsg, OmmConsumerEvent consumerEvent){}
	public void onAckMsg(AckMsg ackMsg, OmmConsumerEvent consumerEvent){}
	public void onAllMsg(Msg msg, OmmConsumerEvent consumerEvent){}
	
	
	public void decode(FieldList fieldList, DataVo vo) {
		/*for (FieldEntry fieldEntry : fieldList) { 
			// System.out.println("Fid: " +  fieldEntry.fieldId() + " Name: " + fieldEntry.name() + " value: " +  fieldEntry.load()); 
		}*/		 
		
		// 뭐 하나라도 바뀐게 있으면 데이터는 풀로보낸다. 저장기능을 사용하지 않기때문에 메모리에 정보 저장을 계속 해두기 위함임.
		boolean sendYN = false;
		Iterator<FieldEntry> iter = fieldList.iterator();
		FieldEntry fieldEntry;
		while (iter.hasNext()) {
			fieldEntry = iter.next();
			// System.out.println("FIELD_ENTRY: " + fieldEntry.fieldId() + " /  " + fieldEntry.name() + ": " + fieldEntry.load() + " loadType: " + fieldEntry.loadType());
			if(fieldEntry.name().equals("TRDPRC_1")) { 
				sendYN = true;
				vo.setTRDPRC_1(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("NETCHNG_1")) { 
				//sendYN = true;
				vo.setNETCHNG_1(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("PCTCHNG")) { 
				//sendYN = true;
				vo.setPCTCHNG(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("BID")) { 
				sendYN = true;
				vo.setBID(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("ASK")) { 
				sendYN = true;
				vo.setASK(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("HIGH_1")) { 
				//sendYN = true;
				vo.setHIGH_1(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("LOW_1")) { 
				sendYN = true;
				vo.setLOW_1(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("OPEN_PRC")) { 
				sendYN = true;
				vo.setOPEN_PRC(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("HST_CLOSE")) { 
				sendYN = true;
				vo.setHST_CLOSE(fieldEntry.load().toString());
			}else if(fieldEntry.name().equals("ACVOL_1")) { 
				//sendYN = true;							
				//acvol_1 ,NETCHNG_1, pctchng는 한번에 두번세번씩 연달아 TRDPRC_1하고 호출되서 주석처리
				vo.setACVOL_1(fieldEntry.load().toString());
			}
			
			if(sendYN) {
				try {
					ObjectMapper mapper = new ObjectMapper(); 
			    	String message = mapper.writeValueAsString(vo);
					
					// 이 부분에서 멀티캐스트(UDP 기반)로 소켓 통신 전송하고 LME는 이를 받는다.
			    	lmeMulticastSend.multicastSend(message);
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
			sendYN = false;
		}		
	}
}
