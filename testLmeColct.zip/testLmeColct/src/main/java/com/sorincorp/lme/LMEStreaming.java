package com.sorincorp.lme;

import java.time.LocalTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.refinitiv.ema.access.EmaFactory;
import com.refinitiv.ema.access.OmmConsumer;
import com.refinitiv.ema.access.OmmException;
import com.refinitiv.ema.rdm.EmaRdm;
import com.sorincorp.lme.colct.RecieveLMERT;
import com.sorincorp.lme.config.TrepRsslConnection;

import lombok.extern.slf4j.Slf4j;

/**
 * LMEStreaming.java
 * @version
 * @since 2024. 8. 7.
 * @author srec0049
 */
@Slf4j
@Component
public class LMEStreaming {
	
	@Autowired
	TrepRsslConnection trepRsslConnection;
	
	@Autowired
	RecieveLMERT appClient;
	
	@Value("${refinitiv.trep.rssl.serviceName}")
	private String trepRsslServiceName;
	
	//실시간 data연동	
	/*
	 * consumer는 세션이기에 하나만 존재해야함. 
	 * appClient 객체는 복수생성이 가능하니 그리드 성격별로 객체생성해서 registerClient 처리할 예정
	 * registerClient는 갯수제한이 없다고 함.
	 */
	
	OmmConsumer consumer = null;
	
	public void Streaming() {
		try {
			// refinitiv trep 서버에 연결
			consumer = trepRsslConnection.rsslConsumer();	
			
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName(trepRsslServiceName).name("CMZN3"), appClient, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName(trepRsslServiceName).name("CMPB3"), appClient, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName(trepRsslServiceName).name("CMAL3"), appClient, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName(trepRsslServiceName).name("CMCU3"), appClient, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName(trepRsslServiceName).name("CMNI3"), appClient, 0);
			
			LocalTime now = LocalTime.now();
			while(now.getHour() + 18 > LocalTime.now().getHour()) {
				consumer.dispatch(10);
			}
			
		} catch(OmmException oe) {
			log.error(oe.getMessage(), oe);
		} catch(Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			if (consumer != null) consumer.uninitialize();
		}
	}
}
