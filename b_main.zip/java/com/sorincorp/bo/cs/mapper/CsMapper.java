package com.sorincorp.bo.cs.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sorincorp.bo.cs.model.ArrrgTrgterVO;
import com.sorincorp.bo.cs.model.BlInfoVO;
import com.sorincorp.bo.cs.model.CsInquiryVO;
import com.sorincorp.bo.cs.model.CsMemberVO;
import com.sorincorp.bo.cs.model.DlvyInfoVO;
import com.sorincorp.bo.cs.model.DlvyProgrsDtlsVO;
import com.sorincorp.bo.cs.model.VhcleInfoVO;
import com.sorincorp.bo.cs.model.VhcleInfoVO2;
//import com.sorincorp.bo.cs.service.OrderDtlsVO;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.model.CommonVO;

public interface CsMapper {
	List<CsInquiryVO> selectCsInquiryList(CsInquiryVO vo);
	int selectCsInquiryTotalCount(CsInquiryVO vo);
	int selectCsInquiryPagingTotalCount(CsInquiryVO vo);
	int selectNotResolvedCsInquiryCount(CsInquiryVO vo);
	List<CommonCodeVO> selectInqrySeDetailCode(@Param("inqrySeCode") String inqrySeCode) throws Exception;

	CsInquiryVO selectInquiry(@Param("inqrySn") long inqrySn) throws Exception;
	CsInquiryVO selectInquiryAnswer(CsInquiryVO vo) throws Exception;
	int insertInquiry(CsInquiryVO vo);
	int insertInquiryAnswer(CsInquiryVO vo);
	void updateInquiryAnswer(CsInquiryVO vo);
	void updateCsInquiry(CsInquiryVO vo);
	void deleteCsInquiry(CsInquiryVO vo);

	void insertCsInquiryHst(@Param("inqrySn")  long inqrySn);

	List<CsMemberVO> selectMemberList(CommonVO vo);
	int selectMemberTotalCount(CommonVO vo);
	List<FileDocVO> selectAttachFileNoList(@Param("inqrySn") long inqrySn);

	String getSntoEmail(@Param("emailTmplatNo") int emailTmplatNo);

	/**
	 * <pre>
	 * 주문 BL 정보 조회
	 * </pre>
	 * @author srec0051
	 * @param orderNo
	 * @return
	 */
	List<BlInfoVO> selectBlInfo(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 차량 정보 등록/수정
	 * </pre>
	 * @author srec0051
	 * @param vo
	 */
	void insertAndUpdateVhcleInfoList(VhcleInfoVO vo) throws Exception;

	/**
	 * 차량정보 등록 제한 여부 저장
	 * @param vo
	 * @return
	 */
	int updateOrderVhcleInfoRegistAt(VhcleInfoVO vo) throws Exception;
	int insertOrderVhcleInfoRegistAtHst(VhcleInfoVO vo) throws Exception;

	/**
	 * 자차 자량정보 등록 및 수정 api 오류 SMS 전송 수신자 추가 리스트 가져오기[SMS_SNDNG_GROUP_CODE:50]
	 */
	List<Map<String, String>> selectReceiverList(String smsSndngGroupCode) throws Exception;

	/**
	 * 자차 자량정보 등록 및 수정 고객 SMS 전송 수신자
	 */
	String selectSmsUserInfo(VhcleInfoVO vo) throws Exception;

	/**
	 * 오더 기본 정보 수정
	 */
	Map<String, String> updateOrderInfo(VhcleInfoVO vo) throws Exception;

	/**
	 *  업체배송메모수정
	 */
	int updateOrderMemo(VhcleInfoVO2 vo2) throws Exception;

	/**
	 * <pre>
	 * 차량종류 공통코드 조회
	 * </pre>
	 * @date 2022. 12. 15.
	 * @author srec0051
	 * @param sleMthdCode
	 * @return
	 */
	List<CommonCodeVO> selectVhcleGroupCodeList(DlvyProgrsDtlsVO vo) throws Exception;

	/**
	 * <pre>
	 * 이벤트 휴일에 포함되는지 조회
	 * </pre>
	 * @date 2023. 1. 13.
	 * @author srec0051
	 * @history
	 * @param vhcleInfoVO
	 * @return
	 */
	int checkHolidayYn(VhcleInfoVO vhcleInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 결제수단에 따른 계산할 영업일수를 조회한다.
	 * 		  담보보증 : 상환기간(담보_기본 테이블)
	 * 		  증거금  : -1 (바로 이전 영업을 조회를 위함)
	 *        그외    : 0
	 * </pre>
	 * @date 2023. 1. 13.
	 * @author srec0066
	 * @history
	 * @param vhcleInfoVO
	 * @return
	 */
	int selectDayCntBySetleMthd(VhcleInfoVO vhcleInfoVO) throws Exception;

	/**
	 * <pre>
	 * 기준일자, 일수를 받아 계산된 영업일을 리턴
	 * </pre>
	 * @date 2023. 1. 13.
	 * @author srec0066
	 * @param dlvyVO
	 * @return
	 * @throws Exception
	 */
	String getSettleSttusDe(VhcleInfoVO dlvyVO) throws Exception;

	/**
	 * 
	 * <pre>
	 * 처리내용: 알림톡 템플릿 목록을 조회한다.
	 * </pre>
	 * @date 2023. 7. 19.
	 * @author srec0083
	 * @param dlvyProgrsDtlsVO
	 * @return
	 * @throws Exception
	 */
	DlvyProgrsDtlsVO selectAlimTmplatList(DlvyProgrsDtlsVO dlvyProgrsDtlsVO) throws Exception;

	/**
	 * 
	 * <pre>
	 * 처리내용: 차량 등록 알림톡 발송 이력 데이터를 조회한다.
	 * </pre>
	 * @date 2023. 7. 21.
	 * @author srec0083
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 21.			srec0083			최초작성
	 * ------------------------------------------------
	 * @param dlvyProgrsDtlsVO
	 * @return
	 * @throws Exception
	 */
	List<ArrrgTrgterVO> selectVhcleAlimList(DlvyProgrsDtlsVO dlvyProgrsDtlsVO) throws Exception;

}
