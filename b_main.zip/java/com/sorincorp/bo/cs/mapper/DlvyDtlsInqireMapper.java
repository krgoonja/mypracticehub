package com.sorincorp.bo.cs.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sorincorp.bo.cs.model.DlivyVO;
import com.sorincorp.bo.cs.model.DlvyDetailDtlsVO;
import com.sorincorp.bo.cs.model.DlvyDtlsVO;
import com.sorincorp.bo.cs.model.OrderDtlsVO;
import com.sorincorp.bo.cs.model.VhcleInfoVO;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;

/**
 * DlvyDtlsInqireMapper.java
 * 배송 내역 조회 Mapper 인터페이스
 * 
 * @version
 * @since 2024. 6. 11.
 * @author srec0049
 */
public interface DlvyDtlsInqireMapper {

	/**
	 * <pre>
	 * 처리내용: 배송 내역 조회 목록 데이터를 가져온다.
	 * </pre>
	 * @date 2024. 6. 11.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 11.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param dlvyDtlsVO
	 * @return
	 * @throws Exception
	 */
	List<DlvyDtlsVO> getListDlvyDtls(DlvyDtlsVO dlvyDtlsVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 차량종류 공통코드를 조회한다.
	 * </pre>
	 * @date 2024. 6. 14.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 14.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param sleMthdCode
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	List<CommonCodeVO> selectVhcleGroupCodeList(@Param("sleMthdCode") String sleMthdCode, @Param("metalCode") String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 출고 정보 리스트를 조회한다.
	 * </pre>
	 * @date 2024. 6. 14.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 14.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param seachVo
	 * @return
	 * @throws Exception
	 */
	List<DlivyVO> selectDlivyList(String seachVo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 차량정보를 조회한다.
	 * </pre>
	 * @date 2024. 6. 14.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 14.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoVO
	 * @return
	 * @throws Exception
	 */
	List<VhcleInfoVO> selectVhcleInfoList(DlvyDtlsVO dlvyDtlsVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 배송 상세 내역을 조회한다.
	 * </pre>
	 * @date 2024. 6. 17.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 6. 17.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	List<DlvyDetailDtlsVO> selectDeliveryDetailDtlsList(String orderNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 기존 출고요청일 조회
	 * </pre>
	 * @date 2024. 6. 18.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 18.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	String selectDlivyRequstDe(String orderNo) throws Exception;
	
	int insertVhcleBas(VhcleInfoVO vo) throws Exception;
	
	void insertVhcleOrderDtl(VhcleInfoVO vhcleInfoVO) throws Exception;
	
	void updateDlivyRequstDe(VhcleInfoVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 자차 자량정보 등록 및 수정 고객 SMS 전송 수신자
	 * </pre>
	 * @date 2024. 6. 18.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 18.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	OrderDtlsVO selectSmsUserInfo(VhcleInfoVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 자차 자량정보 등록 및 수정 고객 SMS 전송 데이터
	 * </pre>
	 * @date 2024. 6. 18.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 18.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectSmsInfo(VhcleInfoVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문_차량 정보 기본 이력을 조회한다.
	 * </pre>
	 * @date 2024. 6. 18.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 18.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoVO
	 * @return
	 * @throws Exception
	 */
	VhcleInfoVO selectOrVhcleInfoHst(VhcleInfoVO vhcleInfoVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 자차 자량정보 등록 및 수정 기사 SMS 전송 데이터
	 * </pre>
	 * @date 2024. 6. 18.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 18.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectDriverSmsInfo(VhcleInfoVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 차량정보를 조회한다.
	 * </pre>
	 * @date 2024. 6. 14.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 14.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param
	 * @return
	 * @throws Exception
	 */
	VhcleInfoVO selectVhcleInfo(VhcleInfoVO vhcleInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지배송 차량정보 등록
	 * </pre>
	 * @date 2024. 6. 14.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 14.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoVO
	 * @return
	 * @throws Exception
	 */
	void insertOrDlvyOdrBas(VhcleInfoVO vhcleInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지배송 차량정보 등록
	 * </pre>
	 * @date 2024. 6. 14.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 14.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoVO
	 * @return
	 * @throws Exception
	 */
	void deleteOrDlvyOdrBas(VhcleInfoVO vhcleInfoVO) throws Exception;
	
}
