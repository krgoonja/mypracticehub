package com.sorincorp.bo.cs.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sorincorp.bo.cs.model.*;
import com.sorincorp.bo.cs.service.DlvyDtlsInqireService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.bo.cs.service.CsService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.model.CommonVO;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/cs")
public class CsController {

	@Autowired
	private CsService csService;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private ItemCodeService itemCodeService;

	@Autowired
	private FileDocService fileDocService;

	@Autowired
	private CustomValidator customValidator;


	@RequestMapping("/showCsList")
	public String viewCsList(ModelMap map) {
		try {
			String inqryCnsltSeCodeList = csService.getCommCodeListStr(commonCodeService.getSubCodes("INQRY_CNSLT_SE_CODE"));		//문의 상담 구분 코드
			String inqryProcessSttusCodeList = csService.getCommCodeListStr(commonCodeService.getSubCodes("INQRY_PROCESS_STTUS_CODE"));		//문의 처리 상태 코드
			String inqrySeCodeList = csService.getCommCodeListStr(commonCodeService.getSubCodes("INQRY_SE_CODE"));	//문의 구분 코드

			map.put("inqryCnsltSeCodeList", inqryCnsltSeCodeList);
			map.put("inqryProcessSttusCodeList", inqryProcessSttusCodeList);
			map.put("inqrySeCode", inqrySeCodeList);

			return "cs/csList";
		} catch (Exception e) {
			log.error(e.getMessage());
            HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
            return "error/503";
		}
	}

	@RequestMapping("/insertCs")
	public String insertCs(@RequestBody CsInquiryVO vo, ModelMap map) {
		try {
			String inqryCnsltSeCodeList = csService.getCommCodeListStr(commonCodeService.getSubCodes("INQRY_CNSLT_SE_CODE"));		//문의 상담 구분 코드
			String inqryProcessSttusCodeList = csService.getCommCodeListStr(commonCodeService.getSubCodes("INQRY_PROCESS_STTUS_CODE"));		//문의 처리 상태 코드
			String inqrySeCodeList = csService.getCommCodeListStr(commonCodeService.getSubCodes("INQRY_SE_CODE"));	//문의 구분 코드

			String itemCodeList = itemCodeService.getItemCodeListStr(itemCodeService.getItemCodeList(""), "선택");

			if(vo.getInqrySn() != 0) {		//문의 데이터 상세 조회인 경우
				vo = csService.selectInquiry(vo);
			}

			if("update".equals(vo.getGridRowStatus())) {	//답변 수정일 경우에만 답변 데이터 조회
				CsInquiryVO inquiryAnswer = csService.selectInquiryAnswer(vo);
				map.put("inquiryAnswerVO", inquiryAnswer);
			}

			map.put("inquiryVO", vo);
			map.put("inqryCnsltSeCodeList", inqryCnsltSeCodeList);
			map.put("inqryProcessSttusCodeList", inqryProcessSttusCodeList);
			map.put("inqrySeCodeList", inqrySeCodeList);
			map.put("itemCodeList", itemCodeList);

			return "cs/insertCsModal.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
            HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
            return "error/503";
		}

	}

	@RequestMapping("/getCsList")
	@ResponseBody
	public Map<String, Object> selectCsInquiryList(@RequestBody CsInquiryVO vo) throws Exception {
		List<CsInquiryVO> inquiryList = csService.selectCsInquiryList(vo);
		int totalDataCount = csService.selectCsInquiryPagingTotalCount(vo);
		int totalInquiryCount = csService.selectCsInquiryTotalCount(vo);
		int notResolvedInquiryCount = csService.selectNotResolvedCsInquiryCount(vo);

		Map<String, Object> map = new HashMap<>();

		map.put("dataList", inquiryList);
		map.put("totalDataCount", totalDataCount);		//For RealGrid Paging
		map.put("totalInquiryCount", totalInquiryCount);		//문의 건수
		map.put("notResolvedInquiryCount", notResolvedInquiryCount);	//미해결 건수

		return map;
	}

	@PostMapping("/insertAndUpdateGridDataList")
	@ResponseBody
	public ResponseEntity<?> insertAndUpdateGridDataList(@RequestBody List<CsInquiryVO> csList, BindingResult bindingResult) throws Exception {
		for (CsInquiryVO cs : csList) {
			if(cs.isValidation()) {
				customValidator.validate(cs, bindingResult);
			}
		}

		if (bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		csService.insertAndUpdateGridDataList(csList);

		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PostMapping("/deleteGridDataList")
	@ResponseBody
	public void deleteGridDataList(@RequestBody List<CsInquiryVO> csList) throws Exception{
		csService.deleteGridDataList(csList);
	}

	@GetMapping("/selectInqrySeDetailCode")
	@ResponseBody
	public Map<String, Object> selectInqrySeDetailCode(String inqrySeCode) throws Exception {
		Map<String, Object> map = new HashMap<>();

		List<CommonCodeVO> inqrySeDetailCode = csService.selectInqrySeDetailCode(inqrySeCode);

		// 문의 구분 중분류 코드
		map.put("inqrySeDetailCode", inqrySeDetailCode);

		return map;
	}

	@PostMapping("/searchMember")
	public String searchMember(@RequestBody CommonVO vo, ModelMap map) {
		map.put("searchVO", vo);

		try {
			return "cs/memberSearchModal.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
            HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
            return "error/503";
		}
	}

	@RequestMapping("/selectMemberList")
	@ResponseBody
	public Map<String, Object> searchMemberList(@RequestBody CommonVO vo) throws Exception{
		HashMap<String, Object> map = new HashMap<>();

		List<CsMemberVO> memberList = csService.selectMemberList(vo);
		int totalDataCount = csService.selectMemberTotalCount(vo);

		map.put("dataList", memberList);
		map.put("totalDataCount", totalDataCount);

		return map;
	}

	@RequestMapping("/fileDownload")
	public void attachFileDownLoad(int docNo, HttpServletRequest request, HttpServletResponse response) throws Exception {
		FileDocVO vo = fileDocService.selectDocInfo(docNo);

		fileDocService.fileDocDownload(request, response, vo);
	}

	@RequestMapping("/dlvyManage/viewDlvyProgrsDtlsList")
	public String viewDlvyProgrsDtlsList(ModelMap map) {
		try {
			return "cs/dlvyProgrsDtlsInqire";
		} catch (Exception e) {
			log.error(e.getMessage());
            HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
            return "error/503";
		}
	}

	/**
	 * <pre>
	 * CS관리 > 배송관리 > 배송진행내역조회 > 상세 (팝업)
	 * </pre>
	 * @date 2022. 10. 12.
	 * @param vo
	 * @param map
	 * @return
	 */
	@RequestMapping("/dlvyManage/viewVhcleInfoAcctoBL")
	public String viewVhcleInfoAcctoBL(@RequestBody DlvyProgrsDtlsVO vo, ModelMap map) {
		try {
			String orderNo = vo.getOrderNo();

			/** BL 정보 */
			List<BlInfoVO> blInfoVOList = csService.selectBlInfo(orderNo);
			/** 차량 목록 */
			List<VhcleInfoVO> vhcleInfoVOList = csService.selectVhcleInfoList(orderNo);
			/** 차량그룹 공통코드 */
			List<CommonCodeVO> vhcleGroupCode = csService.selectVhcleGroupCodeList(vo);
			/** 금일 날짜 조회 */
			String thisDate = csService.thisDate();

			/** 차량 자유 등록 여부 && oms접수번호 */
			String vhcleInfoRegistAt = "N";
			String omsRceptNo = null;
			if (!CollectionUtils.isEmpty(blInfoVOList)) {
				vhcleInfoRegistAt = blInfoVOList.get(0).getVhcleInfoRegistAt();
				omsRceptNo = blInfoVOList.get(0).getOmsRceptNo();
			}

			ObjectMapper objMapper = new ObjectMapper();
			String dlvyProgrsDtls = objMapper.writeValueAsString(vo);
			map.put("dlvyProgrsDtlsInfo", dlvyProgrsDtls);

			map.put("vhcleGroupCodeList", vhcleGroupCode);
			map.put("DlvyProgrsDtlsVO", vo);
			map.put("blInfoVOList", blInfoVOList);
			map.put("vhcleInfoVOList", vhcleInfoVOList);
			map.put("vhcleInfoRegistAt", vhcleInfoRegistAt);
			map.put("omsRceptNo", omsRceptNo);
			map.put("thisDate", thisDate);
			return "cs/vhcleInfoAcctoBL.modal";

		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * CS관리 > 배송관리 > 배송진행내역조회
	 * </pre>
	 * @date 2022. 10. 12.
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/dlvyManage/getDlvyProgrsDtlsList")
	@ResponseBody
	public Map<String, Object> selectDlvyProgrsDtlsList(@RequestBody DlvyProgrsDtlsVO vo) throws Exception {

		Map<String, Object> map = new HashMap<>();
		int totalDataCount = csService.selectDlvyProgrsDtlsPagingTotalCount(vo);
		if (totalDataCount < 1) {
			map.put("dataList", null);
			map.put("totalDataCount", totalDataCount);		//For RealGrid Paging
			return map;
		}

		List<DlvyProgrsDtlsVO> dataList = csService.selectDlvyProgrsDtlsList(vo);

		map.put("dataList", dataList);
		map.put("totalDataCount", totalDataCount);		//For RealGrid Paging

		return map;
	}
	
	/**
	 * <pre>
	 * CS관리 > 배송관리 > 배송진행내역조회 > 상세 (팝업) > 등록된 차량 정보 확인
	 * </pre>
	 * @date 2023. 03. 15.
	 * @param vo
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/dlvyManage/selectDlvyInfo")
	@ResponseBody
	public ResponseEntity<?> selectDlvyInfo(@RequestBody DlvyInfoVO vo, BindingResult bindingResult) throws Exception {
		try {
			if (bindingResult.hasErrors()) {
				return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
			}
			Map<String, Object> map = csService.selectDlvyInfo(vo);
			return ResponseEntity.status(HttpStatus.OK).body(map);
		} catch (Exception e) {
			log.error(e.getMessage());
			return ResponseEntity.status(HttpStatus.OK).body("error");
		}
	}

	/**
	 * <pre>
	 * CS관리 > 배송관리 > 배송진행내역조회 > 상세 (팝업) > 차량등록/수정
	 * </pre>
	 * @date 2022. 10. 12.
	 * @param voList
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/dlvyManage/insertAndUpdateVhcleInfoList")
	@ResponseBody
	public ResponseEntity<?> insertAndUpdateVhcleInfoList(@RequestBody VhcleInfoVO2 vo, BindingResult bindingResult) throws Exception {
		if (bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		csService.insertAndUpdateVhcleInfoList(vo);

		return ResponseEntity.status(HttpStatus.OK).body("Success");
	}

	/**
	 * <pre>
	 * CS관리 > 배송관리 > 배송진행내역조회 > 상세 (팝업) > 차량정보 등록 제한 여부 저장
	 * </pre>
	 * @date 2022. 10. 12.
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/dlvyManage/updateOrderVhcleInfoRegistAt")
	@ResponseBody
	public ResponseEntity<?> updateOrderVhcleInfoRegistAt(@RequestBody VhcleInfoVO vo) throws Exception {
		csService.updateOrderVhcleInfoRegistAt(vo);
		return ResponseEntity.status(HttpStatus.OK).body("Success");
	}

	/**
	 * <pre>
	 * CS관리 > 배송관리 > 배송진행내역조회 > excel 다운로드
	 * </pre>
	 * @date 2023. 1. 9.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 1. 9.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/dlvyManage/getDlvyProgrsDtlsListForExcel")
	public ResponseEntity<?> selectDlvyProgrsDtlsListForExcel(@RequestBody DlvyProgrsDtlsVO vo) throws Exception {
		Map<String,Object> map = new HashMap<>();
		vo.setRecordCountPerPage(10000000);
		List<DlvyProgrsDtlsVO> dataList = csService.selectDlvyProgrsDtlsList(vo);

		map.put("dataList", dataList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 이벤트 휴일에 포함되는지 조회
	 * </pre>
	 * @date 2023. 1. 13.
	 * @author srec0051
	 * @history
	 * @param vhcleInfoVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/dlvyManage/holidayCheck")
	@ResponseBody
	public Map<String, Object> holidayCheck(@RequestBody VhcleInfoVO vhcleInfoVO) throws Exception {
		Map<String, Object> map = new HashMap<>();
		map.put("yn", csService.checkHolidayYn(vhcleInfoVO));

		return map;
	}

	/**
	 * <pre>
	 * 기준일자, 일수를 받아 계산된 영업일과 날짜변경가능여부를 리턴
	 * </pre>
	 * @date 2023. 1. 13.
	 * @author srec0066
	 * @history
	 * @param vhcleInfoVO
	 * @return {yn : boolean, returnDe : yyyyMMMdd}
	 * @throws Exception
	 */
	@PostMapping("/dlvyManage/getSettleSttusDe")
	@ResponseBody
	public Map<String,Object> getSettleSttusDe(@RequestBody VhcleInfoVO vhcleInfoVO) throws Exception  {
		return csService.getSettleSttusDe(vhcleInfoVO);
	}
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 차량 등록 알림톡 보내기 팝업 화면을 조회한다.
	 * </pre>
	 * @date 2023. 7. 19.
	 * @author srec0083
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 19.			srec0083			최초작성
	 * ------------------------------------------------
	 * @param dlvyProgrsDtlsVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/dlvyManage/regVhcleSendAlimModal")
	public String regVhcleSendAlimModal(@RequestBody DlvyProgrsDtlsVO dlvyProgrsDtlsVO, ModelMap model) throws Exception{	
		try {
			model.put("dlvyProgrsDtlsVO", dlvyProgrsDtlsVO);
			return "cs/regVhcleSendAlimModal.modal";
		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
		
			return "error/503";
		}	
	}
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 알림톡 템플릿 목록을 조회한다.
	 * </pre>
	 * @date 2023. 7. 19.
	 * @author srec0083
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 19.			srec0083			최초작성
	 * ------------------------------------------------
	 * @param dlvyProgrsDtlsVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/dlvyManage/selectAlimTmplatList")
	@ResponseBody
	public DlvyProgrsDtlsVO selectAlimTmplatList(@RequestBody DlvyProgrsDtlsVO dlvyProgrsDtlsVO) throws Exception{
		return csService.selectAlimTmplatList(dlvyProgrsDtlsVO); 
	}
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 알림톡을 발송한다.
	 * </pre>
	 * @date 2023. 7. 19.
	 * @author srec0083
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 19.			srec0083			최초작성
	 * ------------------------------------------------
	 * @param dlvyProgrsDtlsVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/dlvyManage/insertAlim")
	@ResponseBody
	public ResponseEntity<?> insertAlim(@RequestBody DlvyProgrsDtlsVO dlvyProgrsDtlsVO, BindingResult bindingResult) throws Exception {
		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		Map<String, Object> map = new HashMap<>();
		switch(dlvyProgrsDtlsVO.getTmplatNo()) {
			case 119:
				map = csService.sendAlim(dlvyProgrsDtlsVO);
				break;
			case 153:
				map = csService.sendVhcleInfoAlim(dlvyProgrsDtlsVO);
				break;
			default:
				map.put("result", false);
				map.put("message", "알림톡 발송을 실패했습니다.");
				break;
		}
		return new ResponseEntity<>(map, HttpStatus.OK);
		
	}
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 차량 등록 알림톡 발송 이력 데이터를 조회한다.
	 * </pre>
	 * @date 2023. 7. 21.
	 * @author srec0083
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 21.			srec0083			최초작성
	 * ------------------------------------------------
	 * @param dlvyProgrsDtlsVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/dlvyManage/selectVhcleAlimList")
	@ResponseBody
	public Map<String, Object> selectVhcleAlimList(@RequestBody DlvyProgrsDtlsVO dlvyProgrsDtlsVO) throws Exception {
		
		Map<String, Object> map = new HashMap<>();
		List<ArrrgTrgterVO> vhcleAlimList = csService.selectVhcleAlimList(dlvyProgrsDtlsVO);
		map.put("dataList", vhcleAlimList);
		
		return map;
		
	}
}
