package com.sorincorp.bo.cs.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.sorincorp.bo.co.comm.OrPropertyConstant;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.cs.model.ArrrgTrgterVO;
import com.sorincorp.bo.cs.model.DlivyVO;
import com.sorincorp.bo.cs.model.DlvyDtlsVO;
import com.sorincorp.bo.cs.model.DlvyProgrsDtlsVO;
import com.sorincorp.bo.cs.model.VhcleInfoVO;
import com.sorincorp.bo.cs.service.DlvyDtlsInqireService;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.deliveryCarMng.model.DeliveryCarMngCommVO;
import com.sorincorp.comm.deliveryCarMng.service.DeliveryCarMngCommService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * DlvyDtlsInqireController.java
 * 배송 내역 조회 Controller 클래스
 * 
 * @version
 * @since 2024. 5. 30.
 * @author srec0049
 */
@Slf4j
@Controller
@RequestMapping("/bo/dlvyDtlsInqire")
public class DlvyDtlsInqireController {

	/**
	 * 사용자정의 유효성 검사
	 */
	@Autowired
	private CustomValidator customValidator;
	
	/**
	 * 로그인 정보 유틸
	 */
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	/**
	 * 공통 코드 Service
	 */
	@Autowired
	private CommonCodeService commonCodeService;

	/** 외부 연계 api 호출 모듈 **/
	@Autowired
	private HttpClientHelper httpClientHelper;

	/** 프로퍼티 상수 모음 **/
	@Autowired
	private OrPropertyConstant orProperty;
	
	@Autowired
    private DeliveryCarMngCommService deliveryCarMngCommService;
	
	/**
	 * 배송 내역 조회 Service
	 */
	@Autowired
	private DlvyDtlsInqireService dlvyDtlsInqireService;
	
	@Value("${dlvy.trace.url}")
	private String dlvyTraceUrl;
	
	/**
	 * <pre>
	 * 처리내용: 배송 내역 조회 페이지를 조회한다.
	 * </pre>
	 * @date 2024. 5. 30.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 30.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 */
	@RequestMapping("/viewDlvyDtlsInqire")
	public String viewDlvyDtlsInqire(ModelMap model) {
		log.debug(">> viewDlvyDtlsInqire in");
		
		try {
			// 2. 배송구분 목록
			Map<String, String> dlvyMnMap = commonCodeService.getSubCodes("DLVY_MN_CODE");
			log.debug(">> dlvyMnMap : " + dlvyMnMap.toString());
			
			model.put("dlvyMnMap", dlvyMnMap); // 배송구분 코드 목록
			model.put("dlvyTraceUrl", dlvyTraceUrl); // 배송추적 url
			
			return "cs/dlvyDtlsInqire";
		} catch(Exception e) {
			log.error(e.getMessage());
            HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
            
            return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 배송 내역 조회 목록 데이터를 가져온다.
	 * </pre>
	 * @date 2024. 6. 11.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 11.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param dlvyDtlsVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/getListDlvyDtlsInqire")
	public ResponseEntity<?> getListDlvyDtlsInqire(@RequestBody DlvyDtlsVO dlvyDtlsVO, BindingResult bindingResult) throws Exception {
		log.debug(">> getListDlvyDtlsInqire in : " + String.valueOf(dlvyDtlsVO));

		if(dlvyDtlsVO.isValidation()) { // 유효성 검사 분기 (필요할 경우)
			// validation을 수행한다, validation VO Class의 형식은 VO, List<Vo>, Map<VO> 가능
			// process별로 validation 수행 field 들을 나누고 싶다면 group interface class를 지정하여 사용한다. (VO에도 지정)
			customValidator.validate(dlvyDtlsVO, bindingResult, DlvyDtlsVO.Search.class);
		}

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		Map<String, Object> map = new HashMap<>();

		// 배송 내역 조회 목록 데이터를 가져온다.
		List<DlvyDtlsVO> getListDlvyDtls = dlvyDtlsInqireService.getListDlvyDtls(dlvyDtlsVO);
		map.put("dataList", getListDlvyDtls);
		
		// 그리드 또는 엑셀용인지 확인, 그리드일 경우만 보낸다.
		if(dlvyDtlsVO.getUseMode().equals("grid")) {
			int totalCnt = 0; // 총 건수
			if(getListDlvyDtls.size() > 0) {
				totalCnt = getListDlvyDtls.get(0).getTotalCnt(); // 총 건수
			}
			map.put("totalDataCount", totalCnt);
		}
		
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: BL별 차량정보(자차배송) 모달 html 가져오기
	 * </pre>
	 * @date 2024. 6. 13.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 13.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/viewVhcleInfoByBLModal")
	public String viewVhcleInfoByBLModal(ModelMap model) throws Exception {
		try {
			log.info("viewVhcleInfoByBLModal in~~");
			
			return "cs/vhcleInfoByBLModal.modal";
		} catch(Exception e) {
			log.error(e.getMessage());
            HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
            
            return "error/503";
		}
	}
	
	@PostMapping("/selectDeliveryCarMngInfo")
    @ResponseBody
    public Map<String, Object> selectDeliveryCarMngInfo(@RequestBody DlvyDtlsVO dlvyDtlsVO) throws Exception {
        Map<String, Object> map = new HashMap<>();
        
//        // 주문 정보 조회에 사용될 객체 생성 및 데이터 세팅
//        OrderDtlsVO searchVo = new OrderDtlsVO();
//        searchVo.setOrderNo(dlvyDtlsVO.getOrderNo());
//        searchVo.setEntrpsNo(userInfoUtil.getEntripsNo());
//        
//		// 주문 정보 조회
//        OrderDtlsVO orderInfo = Optional.ofNullable(orderDtlsDetailService.selectOrderDtlsDetail(searchVo))
//                .orElseThrow(()->{
//                    return new Exception("주문 정보를 확인할 수 없습니다.");
//                });
//
//        orderInfo.setWtChange(orderInfo.getWtChange().stripTrailingZeros());
        
//        // 주문 정보
//        map.put("orderInfo", orderInfo);
        
//        // 물류휴일정보
//        map.put("holidayList", orderDtlsDetailService.selectHolidayList(vhcleInfoVO.getOrderNo()));
//        
//        //금속코드에 대한 영업관리 (시간)
//        map.put("deliveryRequestDateList", itemPriceService.selectDeliveryRequestDate(orderInfo.getMetalCode()));
        
        // 차량종류 공통코드
        map.put("vhcleGroupCodeList", dlvyDtlsInqireService.selectVhcleGroupCodeList(null, null));
        // 업체 차량 정보 (최근 10개)
        map.put("carList", this.getMbVhcleListTen(dlvyDtlsVO.getEntrpsNo()));
        // 업체 기사 정보 (최근 10개)
        map.put("driverList", this.getMbDrvArticlListTen(dlvyDtlsVO.getEntrpsNo()));
        
        // 출고 정보
        List<DlivyVO> dlivyInfoList = dlvyDtlsInqireService.selectDlivyList(dlvyDtlsVO.getOrderNo());
        Map<String, DlivyVO> dlivyInfoGroupList = dlivyInfoList.stream()
        		.collect(Collectors.toMap(DlivyVO::getOrderSn, Function.identity(), (o1,o2) -> o1, LinkedHashMap::new));
        
        map.put("dlivyInfoList", dlivyInfoGroupList);

        // 모든 등록 차량 조회 (차수파악을 위함 - 고정가용)
        List<VhcleInfoVO> vhcleInfoList = dlvyDtlsInqireService.selectVhcleInfoList(dlvyDtlsVO);

        map.put("vhcleInfoList" , vhcleInfoList);

        return map;
    }
	
	/** 업체 차량 정보 (최근 10개) */
    private List<DeliveryCarMngCommVO> getMbVhcleListTen(String entrpsNo) throws Exception {
//    	String entrpsNo = userInfoUtil.getEntripsNo();
    	int maxCnt = 9;
        List<DeliveryCarMngCommVO> carList = new ArrayList<>();

        for (DeliveryCarMngCommVO vo : deliveryCarMngCommService.selectMbVhcleInfoBas(entrpsNo)) {
        	carList.add(vo);
        	if (maxCnt == 0) break;
        	maxCnt--;
        }

    	return carList;
    }
    
    /** 업체 기사 정보 (최근 10개) */
    private List<DeliveryCarMngCommVO> getMbDrvArticlListTen(String entrpsNo) throws Exception {
//    	String entrpsNo = userInfoUtil.getEntripsNo();
    	int maxCnt = 9;
    	List<DeliveryCarMngCommVO> driverList = new ArrayList<>();

        for (DeliveryCarMngCommVO vo : deliveryCarMngCommService.selectMbDrvArticlInfoBas(entrpsNo)) {
        	driverList.add(vo);
        	if (maxCnt == 0) break;
        	maxCnt--;
        }

        return driverList;
    }
    
    /**
	 * 
	 * <pre>
	 * 처리내용: 차량 등록 알림톡 보내기 팝업 화면을 조회한다.
	 * </pre>
	 * @date 2023. 7. 19.
	 * @author srec0083
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 19.			srec0083			최초작성
	 * ------------------------------------------------
	 * @param dlvyProgrsDtlsVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/regVhcleSendAlimModal")
	public String regVhcleSendAlimModal(@RequestBody DlvyProgrsDtlsVO dlvyProgrsDtlsVO, ModelMap model) throws Exception{	
		try {
			model.put("dlvyProgrsDtlsVO", dlvyProgrsDtlsVO);
			return "cs/regVhcleSendAlimModal.modal";
		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
		
			return "error/503";
		}	
	}
    
    /**
     * <pre>
     * 처리내용: 차량정보를 등록 및 수정한다.
     * </pre>
     * @date 2024. 6. 18.
     * @author srec0049
     * @history 
     * ------------------------------------------------
     * 변경일                 작성자          변경내용
     * ------------------------------------------------
     * 2024. 6. 18.          srec0049         최초작성
     * ------------------------------------------------
     * @param vhcleInfoArr
     * @return
     * @throws Exception
     */
    @PostMapping("/insertVhcleInfoList")
    @ResponseBody
    public Map<String, Object> insertVhcleInfoList(@RequestBody List<VhcleInfoVO> vhcleInfoArr) throws Exception {
    	String userId = "";
    	
    	Map<String, Object> rtnMap = new HashMap<>();
        
    	// 로그인 정보 확인
        Account account = userInfoUtil.getAccountInfo();
    	if(account == null) {
    		rtnMap.put("result", "F");
    		rtnMap.put("errorMsg", "로그인되지 않은 사용자입니다.");
			return rtnMap;
		}
    	
    	rtnMap.put("result", "E");
        rtnMap.put("resultMsg", "차량입고일을 확인해주세요.");
    	
        for (VhcleInfoVO vo : vhcleInfoArr) {
            vo.setMberId(userId);
            
            // 삭제일 때는 체크 안함
            if (StringUtils.equals("Y", vo.getDeleteAt())) {
                continue;
            }

            if (StringUtil.isEmpty(vo.getVhcleWrhousngDe())) {
            	return rtnMap;
            }

        }

        for (VhcleInfoVO vo : vhcleInfoArr) {
        	vo.setMberId(account.getId());
        }

        // 차량정보를 등록 및 수정
        try {
        	rtnMap = dlvyDtlsInqireService.modifyVhcleInfoList(vhcleInfoArr);
        } catch (Exception e) {
        	log.error(e.getMessage(), e);
        	return rtnMap;
		}

        return rtnMap;
    }

	@PostMapping("/vhcleWrhousngDeUpdt")
	@ResponseBody
	public Map<String, Object> vhcleWrhousngDeUpdt(@RequestBody VhcleInfoVO vhcleInfoVO) throws Exception {
		String userId = "";

		Map<String, Object> rtnMap = new HashMap<>();

		// 로그인 정보 확인
		Account account = userInfoUtil.getAccountInfo();
		if(account == null) {
			rtnMap.put("result", "F");
			rtnMap.put("errorMsg", "로그인되지 않은 사용자입니다.");
			return rtnMap;
		} else {
			vhcleInfoVO.setLastChangerNm(account.getName());
		}
		// 케이지 배송 정보 등록
		try {
			rtnMap = dlvyDtlsInqireService.vhcleWrhousngDeUpdt(vhcleInfoVO);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return rtnMap;
		}
		return rtnMap;
	}
    
}
