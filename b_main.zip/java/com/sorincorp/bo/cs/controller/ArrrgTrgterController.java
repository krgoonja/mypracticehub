package com.sorincorp.bo.cs.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.cs.model.ArrrgTrgterVO;
import com.sorincorp.bo.cs.service.ArrrgTrgterService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 미납대상자 관리 ArrrgTrgterController.java
 *
 * @version
 * @since 2022. 7. 11.
 * @author srec0066
 */
@Slf4j
@Controller
@RequestMapping("/bo/arrrgTrgter")
public class ArrrgTrgterController {

	@Autowired
	private ArrrgTrgterService arrrgTrgterService;

	/**
	 * <pre>
	 * 처리내용: 미납대상자 관리 페이지를 조회한다.
	 * </pre>
	 *
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 14.
	 *          srec0066 최초작성 ------------------------------------------------
	 * @return
	 */
	@RequestMapping("/viewArrrgTrgterList")
	public String viewArrrgTrgterList() {
		try {

			return "cs/arrrgTrgterList";
		} catch (Exception e) {

			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 미납대상자 목록 데이터를 조회한다.
	 * </pre>
	 *
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 14.
	 *          srec0066 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/searchArrrgTrgterList")
	@ResponseBody
	public Map<String, Object> searchArrrgTrgterList(@RequestBody ArrrgTrgterVO vo) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		List<ArrrgTrgterVO> dataList = arrrgTrgterService.searchArrrgTrgterList(vo);
		int totalDataCount = arrrgTrgterService.selectArrrgTrgterListTotCnt(vo);

		map.put("dataList", dataList);
		map.put("totalDataCount", totalDataCount);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 미납대상자 cs처리내역 목록 데이터를 조회한다.
	 * </pre>
	 *
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 14.
	 *          srec0066 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/searchNpyOrderManageList")
	@ResponseBody
	public Map<String, Object> searchNpyOrderManageList(@RequestBody ArrrgTrgterVO vo) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		List<ArrrgTrgterVO> dataList = arrrgTrgterService.selectNpyOrderManageList(vo);
		int totalDataCount = arrrgTrgterService.selectNpyOrderManageListTotCnt(vo);

		map.put("dataList", dataList);
		map.put("totalDataCount", totalDataCount);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: sms 발송 모달창을 조회한다.
	 * </pre>
	 *
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 14.
	 *          srec0066 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/arrrgTrgterModalSms")
	public String arrrgTrgterModalSms(@RequestBody ArrrgTrgterVO vo, ModelMap model) {
		try {
			model.put("vo", vo);

			return "cs/arrrgTrgterModalSms.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 이메일 발송 모달창을 조회한다.
	 * </pre>
	 *
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 14.
	 *          srec0066 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/arrrgTrgterModalEmail")
	public String arrrgTrgterModalEmail(@RequestBody ArrrgTrgterVO vo, ModelMap model) {
		try {
			model.put("vo", vo);

			return "cs/arrrgTrgterModalEmail.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 미납대상자 cs 처리 모달창을 조회한다.
	 * </pre>
	 *
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 14.
	 *          srec0066 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/arrrgTrgterModalOutbound")
	public String arrrgTrgterModalOutbound(@RequestBody ArrrgTrgterVO vo, ModelMap model) {
		try {
			model.put("vo", vo);

			return "cs/arrrgTrgterModalOutbound.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 미납대상자 cs 처리내역 모달창을 조회한다.
	 * </pre>
	 *
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 14.
	 *          srec0066 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/arrrgTrgterModalOutboundDtls")
	public String arrrgTrgterModalOutboundDtls(@RequestBody ArrrgTrgterVO vo, ModelMap model) {
		try {
			model.put("vo", vo);

			return "cs/arrrgTrgterModalOutboundDtls.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: sms 템플릿 목록을 조회한다.
	 * </pre>
	 *
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 14.
	 *          srec0066 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectSmsTmplatList")
	@ResponseBody
	public List<ArrrgTrgterVO> selectSmsTmplatList(@RequestBody ArrrgTrgterVO vo) throws Exception {
		return arrrgTrgterService.selectSmsTmplatList(vo);
	}

	/**
	 * <pre>
	 * 처리내용: 이메일 템플릿 목록을 조회한다.
	 * </pre>
	 *
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 14.
	 *          srec0066 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectEmailTmplatList")
	@ResponseBody
	public List<ArrrgTrgterVO> selectEmailTmplatList(@RequestBody ArrrgTrgterVO vo) throws Exception {
		return arrrgTrgterService.selectEmailTmplatList(vo);
	}

	/**
	 * <pre>
	 * 처리내용: sms를 발송한다.
	 * </pre>
	 *
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 14.
	 *          srec0066 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertSms")
	@ResponseBody
	public ResponseEntity<?> insertSms(@RequestBody ArrrgTrgterVO vo, BindingResult bindingResult) throws Exception {
		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		Map<String, Object> map = arrrgTrgterService.insertSms(vo);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 이메일을 발송한다.
	 * </pre>
	 *
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 14.
	 *          srec0066 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertEmail")
	@ResponseBody
	public ResponseEntity<?> insertEmail(@RequestBody ArrrgTrgterVO vo, BindingResult bindingResult) throws Exception {
		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		Map<String, Object> map = arrrgTrgterService.insertEmail(vo);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 미납 cs처리를 등록한다.
	 * </pre>
	 *
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 14.
	 *          srec0066 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertCs")
	@ResponseBody
	public ResponseEntity<?> insertCs(@RequestBody ArrrgTrgterVO vo, BindingResult bindingResult) throws Exception {
		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		Map<String, Object> map = arrrgTrgterService.insertCs(vo);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

}
