package com.sorincorp.bo.cs.model;

import java.util.List;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * OrderDtlsVO.java
 * 
 * 
 * @version
 * @since 2024. 6. 18.
 * @author srec0049
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class OrderDtlsVO extends CommonVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8258558801824735514L;
	/**
     * 권한 구분 코드
    */
    private String memberSecode;
    /**
     * 주문 번호
     */
    private String orderNo;
    /** 클레임 번호 */
    private String canclExchngRtngudNo;
    /** 지정가 주문 번호 */
    private String limitOrderNo;
    /**
     * 주문 일자
    */
    private String orderDe;
    /**
     * 주문 시각
     */
    private String orderTm;
    /**
     * 상품명
     */
    private String goodsNm;
    /**
     * 회원 번호
    */
    private String mberNo;
    /**
     * 회원 아이디
     */
    private String mberId;
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 사업자 등록 번호
     */
    private String bsnmRegistNo;
    /**
     * 업체 대표자 명
     */
    private String rprsntvNm;
    /**
     * 업체 등급 번호
    */
    private String entrpsGradNo;
    /**
     * 접수 매체 구분 코드
    */
    private String rceptMediaSeCode;
    /**
     * 판매 방식 코드
    */
    private String sleMthdCode;
    /** 판매 방식 상세 코드 */
    private String sleMthdDetailCode;
    /**
     * 판매 방식 명
     */
    private String sleMthdNm;
    /**
     * 주문자 명
    */
    private String ordrrNm;
    /**
     * 주문자 휴대폰 번호
    */
    private String ordrrMoblphonNo;
    /**
     * 주문자 이메일
    */
    private String ordrrEmail;
    /**
     * 주문 업체 명
    */
    private String orderEntrpsNm;
    /**
     * 주문 업체 전화번호
    */
    private String orderEntrpsTelno;
    /**
     * 주문 업체 우편번호
    */
    private String orderEntrpsZip;
    /**
     * 주문 업체 주소
    */
    private String orderEntrpsAdres;
    /**
     * 주문 업체 상세 주소
    */
    private String orderEntrpsDetailAdres;
    /**
     * 주문 업체 도로명 주소
    */
    private String orderEntrpsRnAdres;
    /**
     * 주문 업체 도로명 상세 주소
    */
    private String orderEntrpsRnDetailAdres;
    /**
     * 주문 상태 코드
    */
    private String orderSttusCode;
    /**
     * 주문 상태 코드
     */
    private String orderSttusNm;
    /**
     * 출고 요청 일자
    */
    private String dlivyRequstDe;
    /**
     * 주문 배송지 번호
    */
    private String orderDlvrgNo;
    /**
     * 주문 배송비 번호
    */
    private String orderDlvrfNo;
    /**
     * 문서 파일 경로
     */
    private String docFileCours;
    /**
     * 국기 이미지 URL
     */
    private String nationFlagImgUrl;
    /**
     * 금속 코드
     */
    private String metalCode;
    /**
     * 금속 명
     */
    private String metalNm;
    /**
     * 브랜드 명
     */
    private String brandNm;
    /**
     * 아이템 명
     */
    private String itmNm;
    /** 아이템 순번 */
    private int itmSn;
    /**
     * 브랜드 그룹명
     */
    private String brandGroupNm;
    /** 브랜드 그룹 코드 */
    private String brandGroupCode;
    /** 브랜드 코드 */
    private String brandCode;
    /** 권역 대분류 코드 */
    private String dstrctLclsfCode;
    /** 권역 대분류 코드 명 */
    private String dstrctLclsfNm;
    /**
     * 총 고객 주문 중량
     */
    private int totCstmrOrderWt;
    /**
     * 총 실제 주문 중량
    */
    private int totRealOrderWt;
    /**
     * 총 번들 수량
    */
    private int totBundleQy;
    /**
     * 총 확정 중량
    */
    private java.math.BigDecimal totDcsnWt;
    /**
     * 단위 명
     */
    private String sleUnitNm;
    /** 판매 단위 중량 */
    private int sleUnitWt;
    /**
     * 상품 단가
    */
    private java.math.BigDecimal goodsUntpc;
    /**
     * 원 상품 단가
     */
    private java.math.BigDecimal orgGoodsUntpc;
    /**
     * 상품가
     */
    private java.math.BigDecimal goodsPc;
    /**
     * 중량 변동금
    */
    private java.math.BigDecimal wtChangegld;
    /**
     * 중량 변동
     */
    private java.math.BigDecimal wtChange;
    /**
     * 공급가
    */
    private java.math.BigDecimal splpc;
    /**
     * 부가세
    */
    private java.math.BigDecimal vat;
    /**
     * 판매가
    */
    private java.math.BigDecimal slepc;
    /**
     * 예상 배송비
     */
    private java.math.BigDecimal expectDlvrf;
    /**
    /**
     * 정산 처리 여부
    */
    private String excclcProcessAt;
    /**
     * 정산 처리 일시
    */
    private java.sql.Timestamp excclcProcessDt;

    /* 결제 */
    /**
     * E-Wallet 결제 금액
     */
    private String ewalletAmount;
    /**
     * E-Wallet 결제 완료 일시
     */
    private java.sql.Timestamp ewalletSetleComptDt;
    /**
     * 총 확정 주문 가격(정산 금액)
     */
    private String totDcsnOrderPc;
    /**
     * 총 확정 일시(정산 일시)
     */
    private java.sql.Timestamp totDcsnDt;
    /**
     * 환불 금액 결제 완료 일시
     */
    private java.sql.Timestamp refndAmountSetleComptDt;

    /* 배송정보 */
    /**
     * 배송 수단 코드
     */
    private String dlvyMnCode;
    /**
     * 배송 수단 명
     */
    private String dlvyMnNm;
    /**
     * 배송지 명
     */
    private String dlvrgNm;
    /**
     * 수취 주소
     */
    private String receptAdres;

    /* 대표 정보 */
    /**
     * 대표 판매자
     */
    private String repSeler;
    /**
     * 대표 사업자등록번호
     */
    private String repSelerBsnmRegistNo;
    /**
     * 대표 이사
     */
    private String repSelerRprsntvNm;
    /**
     * 대표 소재지
     */
    private String repSelerAdres;

    /* 첨부파일 */
    /**
     * 문서 파일 실제 경로
    */
    private String docFileRealCours;

    /* 결제정보 영역 추가 관련 변수 */

    /**
     * 결제상태
     */
    private String setleSttus;
    /**
     * 결제 방식 코드
     */
    private String setleMthdCode;
    /**
     * 결제 방식 상세 코드
     */
    private String setleMthdDetailCode;
    /**
     * 결제 방식
     */
    private String setleMthd;
    /**
     * 결제예정일
     */
    private String setlePrearngeDe;
    /**
     * 결제예정액
     */
    private java.math.BigDecimal unSetleAmount;


    /* 추가(조회조건) */
    /** 기간조회 시작일 */
    private String searchDateFrom;

    /** 기간조회 종료일 */
    private String searchDateTo;

    /** 결제상태 목록 */
    private List<String> settleSttusList;

    /* 페이징(더보기) */
    /** startIndex */
    private int startIndex = 1;

    /** endIndex */
    private int endIndex = 2;

    /** 등록된 차량 수 */
    private int vhcleCnt;
    /** 전체 차량 수 */
    private int totVhcleCnt;

    /**
     * 증거금 사용 여부
     */
    private String wrtmUseAt;
    /**
     * 담보 보증 사용 여부
     */
    private String mrtggGrntyUseAt;
    /**
     * 대출 보증 사용 여부
     */
    private String lonGrntyUseAt;
    /**
     * 대출 상태 코드
     */
    private String lonSttusCode;
    /**
     * 결제 금액
     */
    private String setleAmount;
    /**
     * 결제 완료일
     */
    private String setleComptDt;
    /**
     * 상환 가능 여부
     */
    private String repyPossAt;
    /**
     * 환불 금액
     */
    private String refndAmount;
    /**
     * 취소주문 환불 금액
     */
    private String canclAmount;
    /**
     * 취소 일시
     */
    private String canclDt;
    /**
     * OMS 접수 번호
     */
    private String omsRceptNo;
    /**
     * 등급별 할인 금액
     */
    private long gradApplcAmount;
    /**
     * 자투리 할인
     */
    private long rmndrDscnt;

    /** 검색주문번호타입 (01: 주문번호, 02: 계약번호) */
    private String orderNoType;
    /** 계약번호 */
    private String cntrctNo;
    /** 계약년월 */
    private String cntrctYm;
    /** 계약 월 */
	private int cntrctMm;
    /** QP 코드 */
    private String qpCode;
    /** 단가 확정 일자 */
    private String untpcDcsnDe;
    /** 평균가 상품가 */
    private long avrgpcGoodsPc;
    /** 평균가 상품 단가 */
    private long avrgpcGoodsUntpc;
    /** 평균가 원 상품 단가 */
    private long orgAvrgpcGoodsUntpc;
    /** 평균가 중량변동금 */
    private long avrgpcWtChangegld;
    /** 평균가 공급가 */
    private long avrgpcSplpc;
    /** 평균가 부가세 */
    private long avrgpcVat;
    /** 평균가 판매가 */
    private long avrgpcSlepc;
    /** 배송완료일자 */
    private String dlvyComptDe;
    /** 쿠폰 할인 적용 금액 (배송비) */
    private long couponDlivyDscntAmount;
    /** 쿠폰 할인 적용 금액 (단가) */
    private long couponUntpcDscntAmount;
    
    /**
     * 추가 금액
     */
    private long aditAmount;
    /**
     * 담보 상태 코드
     */
    private String mrtggSttusCode;
}
