package com.sorincorp.bo.cs.model;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class VhcleInfoVO2 extends VhcleInfoVO {
	/**
	 * @Fields field:field:{todo}
	 */
	private static final long serialVersionUID = -8861901370412860677L;
	/**
	 * 주문 번호
	 */
	private String orderNo;
	/**
	 * 업체 배송 메모
	 */
	private String dlvyMemo;
	/**
	 * 차량정보 리스트
	 */
	private List<VhcleInfoVO> vhcleInfoList;

}
