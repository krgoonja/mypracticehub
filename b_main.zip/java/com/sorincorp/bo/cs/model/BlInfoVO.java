package com.sorincorp.bo.cs.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class BlInfoVO extends CommonVO{
	/**
	 *
	 */
	private static final long serialVersionUID = -1677353632656460111L;
	/**
	 * 주문 순번
	 */
	private String orderSn;
	/**
	 * 대분류 출고 권역명
	 */
	private String lclsfDlivyDstrctNm;
	/**
	 * 창고 명
	 */
	private String wrhousNm;
	/**
	 * 창고 주소
	 */
	private String wrhousAdres;
	/**
	 * 브랜드 코드
	 */
	private String brandCode;
	/**
	 * BL 번호
	 */
	private String blNo;
	/**
	 * 실제 주문 중량
	 */
	private String realOrderWt;
	/**
	 * 번들 수량
	 */
	private String bundleQy;
	/** 차량정보등록여부 */
    private String vhcleInfoRegistAt;
    /** 배송수단코드 */
    private String dlvyMnCode;
    /** 판매방식 */
    private String sleMthdCode;
    /** OMS 접수번호 */
    private String omsRceptNo;
}
