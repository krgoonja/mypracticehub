package com.sorincorp.bo.cs.model;

import java.util.List;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * DlvyDtlsVO.java
 * 배송 내역 VO 객체
 * 
 * @version
 * @since 2024. 6. 10.
 * @author srec0049
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class DlvyDtlsVO extends CommonVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5823314362146018923L;

	/**
	 * Search</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface Search {};
	
	/**
	 * 총 건수
	 */
	private int totalCnt;
	
	/**
	 * 순번
	 */
	private int seq;
	
	/**
	 * 주문 번호
	 */
	private String orderNo;
	
	/**
	 * 에이전트 아이디
	 */
	private String agentId;
	
	/**
	 * 배송 수단 코드
	 */
	private String dlvyMnCode;
	
	/**
	 * 배송 수단 명
	 */
	private String dlvyMnNm;
	
	/**
	 * 출고 상태
	 */
	private String dlvySttus;
	
	/**
	 * 주문 중량 (총 실제 주문 중량)
	 */
	private int totRealOrderWt;
	
	/**
	 * 확정 중량 (총 확정 중량)
	 * (소숫점 세 자리까지 표기하기 위해 String으로 선언)
	 */
	private float totDcsnWt;
	
	/**
	 * 번들 수량 (총 번들 수량)
	 */
	private int totBundleQy;
	
	/**
	 * 확정 번들 (총 확정 번들 수량)
	 */
	private int totDcsnBundleQy;
	
	/**
	 * 출고 진행율
	 */
	private float dlvyProgress;
	
	/**
	 * 브랜드 코드
	 */
	private String brandNm;
	
	/**
	 * 물류 센터 (창고 이름)
	 */
	private String wrhousNm;
	
	/**
	 * 배송 상세 내역 - 요청 정보 목록 (자차 배송일 시에만 사용)
	 */
	private List<DlvyDetailDtlsVO> deliveryDetailDtlsRequstList;
	
	/**
	 * 배송 상세 내역 - 확정 정보 목록 (케이지 배송일 때 단독 상세 내역으로도 사용)
	 */
	private List<DlvyDetailDtlsVO> deliveryDetailDtlsDcsnList;
	
	/**
	 * 그리드 또는 그리드엑셀 모드 설정 ( useMode가 엑셀일 경우 excel, 그리드일경우 null)
	 */
	private String useMode;
	
	/**
	 * 날짜 유형
	 */
	private String searchDateType;
	
	/**
	 * 검색 시작일
	 */
	private String searchDateFrom;
    
	/**
	 * 검색 종료일
	 */
	private String searchDateEnd;
	
	/**
     * 업체 번호
     */
    private String entrpsNo;
    
    /**
	 * 출고상태 (화면에서 선택된 값들)
	 */
	private List<String> dlvySttusList;
    
    /**
     * 차량 등록 상태
     */
    private String vhcleRegistSttus;
    
    /**
     * 사업자 등록 번호
     */
    private String bsnmRegistNo;
    
    /**
     * 주문 업체 명
     */
    private String orderEntrpsNm;
    
    /**
     * 출고 요청 일자(배송요청일)
     */
    private String dlivyRequstDe;
    
    /**
     * 주문자 명(주문담당자)
     */
    private String ordrrNm;
    
    /**
     * 주문자 휴대폰 번호
     */
    private String ordrrMoblphonNo;
    
    /**
     * 주문 업체 전화 번호
     */
    private String orderEntrpsTelno;
    
    /**
     * 주문 순번
     */
    private String orderSn;
    
    /**
     * 주문일자(YYYY-MM-DD), 차량등록 알림톡 보내기 전용
     */
    private String orderDe2;
    
    /**
     * 주문 상태명
     */
    private String orderSttusNm;
    
    /**
     * 인도지
     */
    private String receptAdres;
}
