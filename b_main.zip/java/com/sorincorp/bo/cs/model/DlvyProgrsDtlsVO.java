package com.sorincorp.bo.cs.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class DlvyProgrsDtlsVO extends CommonVO{

	private static final long serialVersionUID = 389868698476851133L;

	/******  JAVA VO CREATE : OR_ORDER_BAS(주문_주문 기본)                                                                                   ******/
    /**
     * 순서 번호
     */
    private String rownum;
	/**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 주문 상태명
     */
    private String orderSttusNm;
    /**
     * 주문자 이메일
     */
    private String ordrrEmail;
    /**
     * 출고 요청 일자(배송요청일)
     */
    private String dlivyRequstDe;
    /**
     * 차량 입고 일자
     */
    private String vhcleWrhousngDe1;
    private String vhcleWrhousngDe2;
    private String vhcleWrhousngDe3;
    private String vhcleWrhousngDe4;
    
    /**
     * 주문 업체 명
    */
    private String orderEntrpsNm;
    /**
     * 주문자 명
    */
    private String ordrrNm;
    
    /**
     * 회원 번호
    */
    private String mberNo;
    
    /**
     * 주문자 휴대폰 번호
    */
    private String ordrrMoblphonNo;
    /**
     * 주문 업체 전화번호
    */
    private String orderEntrpsTelno;
    /**
     * 브랜드 코드
     */
    private String brandCode;
    /**
     * 배송 수단 명
    */
    private String dlvyMnNm;
    /**
     * 물류센터
     */
    private String itemCenter;
    /**
     * 총 실제 주문 중량
    */
    private int totRealOrderWt;
    
    /**
     * 단위 중량
    */
    private int sleUnitWt;

    private String bundleQy;
    /**
     * 주문 일자
    */
    private String orderDe;
    
    private String orderDe2;
    
    private int vhcleCnt;
    
    private int vhcleCnt2;
    
    private int totVhcleCnt;
    
    /**
     * 사업자 등록 번호
     */
    private String bsnmRegistNo;
    /**
     * 금속 코드
     */
    private String metalCode;
    /**
     * 업체 배송 메모
     */
    private String dlvyMemo;

    /**
     * 검색조건 : 배송구분
     */
    private String dlvySe;
    /**
     * 검색조건 : CS대상여부
     */
    private String csTargetAt;
    /**
     * 검색조건 : 검색 날짜 구분
     */
    private String dateRadio;
    
    /**
     * 검색조건 : 날짜 유형
     */
    private String searchDateType;
    /**
     * 검색조건 : 검색 시작일
     */
    private String searchDateFrom;
    /**
     * 검색조건 : 검색 종료일
     */
    private String searchDateEnd;
    /** 판매방식코드 */
    private String sleMthdCode;
    /** 배송수단코드 */
    private String dlvyMnCode;
    /** 결제 방식 코드 */
    private String setleMthdCode;
    /** 미결재 금액 */
    private long unSetleAmount;
    
	/***	이메일/메세지 템플릿 관련		***/
	/**
     * 메시지 템플릿 번호
    */
    private int tmplatNo;
    /**
     * 발신자 전화번호
    */
    private String sntoTelno;
    /**
     * 발신자 이메일
    */
    private String sntoEmail;
    /**
     * 템플릿 제목
    */
    private String tmplatSj;
    /**
     * 템플릿 내용
    */
    private String tmplatCn;
    /**
     * 미납 처리 유형 코드
     */
    private String npyProcessTyCode;
    /**
     * 메시지 발송 이력 번호
     */
    private int mssageSndngHistNo;
    
    /**
     * 배송 차수
     */
    private int dlvyOdr;

    /**
     * AGENT ID
     */
    private String agentId;
    private String modalSeCode;
}
