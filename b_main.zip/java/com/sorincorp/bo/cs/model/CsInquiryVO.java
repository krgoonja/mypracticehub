package com.sorincorp.bo.cs.model;

import java.util.List;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class CsInquiryVO extends CommonVO {

	private static final long serialVersionUID = -4550336746602839598L;

	/******  JAVA VO CREATE : CS_INQRY_BAS(CS 문의 기본)                                                                                     ******/
	/**
	 * 순번 (화면 표시용도)
	 */
	private String rownum;
    /**
     * 문의 순번
    */
    private long inqrySn;
    /**
     * 문의 답변 구분 코드
    */
    private String inqryAnswerSeCode;
    /**
     * 문의 답변 회원 번호
    */
    private String inqryAnswerMberNo;
    /**
     * 회원이름(문의자)
     */
    private String inqryAnswerMan;
    /**
     * 문의 답변 자
    */
    private String answerMan;
    /**
     * 문의 전화번호
    */
    private String inqryTelno;
    /**
     * 문의 이메일
    */
    private String inqryEmail;
    /**
     * 문의 회사명
    */
    private String inqryCmpnynm;
    /**
     * 문의 회사 번호(업체 번호)
     */
    private String entrpsNo;
    /**
     * 문의 상담 구분 코드
    */
    private String inqryCnsltSeCode;
    /**
     * 문의 상담 구분
     */
    private String inqryCnsltSe;
    /**
     * 문의 구분 코드
    */
    private String inqrySeCode;
    /**
     * 문의 구분
     */
    private String inqrySe;
    /**
     * 문의 구분 상세 코드
    */
    private String inqrySeDetailCode;
    /**
     * 문의 구분 상세
     */
    private String inqrySeDetail;
    /**
     * 문의 주문 번호
    */
    private String inqryOrderNo;
    /**
     * 주문 번호
     */
    private String orderNo;
    /**
     * 문의 상품 코드
    */
    private String inqryGoodsCode;
    /**
     * 문의 답변 제목
    */
    private String inqryAnswerSj;
    /**
     * 문의 답변 내용
    */
    private String inqryAnswerCn;
    /**
     * 문의 처리 상태 코드
    */
    private String inqryProcessSttusCode;
    /**
     * 문의 처리 상태
     */
    private String inqryProcessSttus;
    /**
     * 문의 일시
    */
    private java.sql.Timestamp inqryAnswerDt;
    /**
     * 답변 일시
    */
    private java.sql.Timestamp answerDt;
    /**
     * 답변 메일 수신 동의 여부
    */
    private String answerEmailRecptnAgreAt;
    /**
     * 부모 문의 답변 순번
    */
    private int parntsInqryAnswerSn;
    /**
     * 문의 답변 깊이
    */
    private int inqryAnswerDp;
    /**
     * 문의 답변 순서
    */
    private int inqryAnswerOrdr;
    /**
     * 개인 정보 수집 동의 여부
    */
    private String indvdlInfoColctAgreAt;
    /**
     * 첨부파일 목록
     */
    private List<FileDocVO> attachFileList;
    /**
     * 회원 구분 코드
     */
    private String mberSeCode;
    /**
     * 디바이스 ID
     */
    private String deviceId;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;

    /**
     * 검색 시작일
     */
    private String searchDateFrom;
    /**
     * 검색 종료일
     */
    private String searchDateEnd;
    /**
     * 그리드 Row 상태
    */
    private String gridRowStatus;
    /**
     * 그리드 Row 상태
     */
    private String memo;
}
