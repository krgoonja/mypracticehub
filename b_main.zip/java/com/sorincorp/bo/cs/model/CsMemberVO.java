package com.sorincorp.bo.cs.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class CsMemberVO extends CommonVO{
	
	private static final long serialVersionUID = 6546371235414667184L;
	
	/******  JAVA VO CREATE : MB_MBER_INFO_BAS(회원_회원 정보 기본)                                                                          ******/
    /**
     * 회원 번호
    */
    private String mberNo;
    /**
     * 회원 아이디
    */
    private String mberId;
    /**
     * 회원 이름
    */
    private String mberNm;
    /**
     * 휴대전화 번호
    */
    private String moblphonNo;
    /**
     * 전화 번호
    */
    private String tlphonNo;
    /**
     * 회원 이메일
    */
    private String mberEmail;
    /**
     * 회사 이름
     */
    private String entrpsnmKorean;
}
