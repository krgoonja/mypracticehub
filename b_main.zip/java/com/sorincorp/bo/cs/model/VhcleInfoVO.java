package com.sorincorp.bo.cs.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class VhcleInfoVO extends CommonVO {
	private static final long serialVersionUID = 2690771060426912373L;
	/**
     * 주문 번호
    */
    private String orderNo;
    /**
     * EC주문 번호
     */
    private String ecOrderNo;
    /**
     * 주문 순번
    */
    private String orderSn;
    /**
     * 배송 차수
    */
    private int dlvyOdr;
    /**
     * 차량 순번
     */
    private int vhcleSn;
    /**
     * BL 번호
     */
    private String blNo;
    /**
     * 차량 그룹 코드
    */
    private String vhcleGroupCode;
    /**
     * 차량 입고 일자
    */
    private String vhcleWrhousngDe;
    /**
     * 차량 번호
    */
    private String vhcleNo;
    private String vhcleNoInput;
    /**
     * 운전자 명
    */
    private String drverNm;
    private String drverNmInput;
    /**
     * 운전자 전화 번호
    */
    private String drverTlphonNo;
    private String drverTlphonNoInput;
    /**
     * 인터페이스 구분
     */
    private String intrfcSe;
    /**
     * 차수 번들 수량
     */
    private int odrBundleQy;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /** 신규등록(new) or 수정등록(saved) */
    private String mode;
    /** 수정불가 차수 일 경우 (입고일 당일 오전 9시 지남) */
    private String mode2;
    /**
     * 등록,수정자
     */
    private String mberId;
    /** 실제 주문 중량 */
    private String realOrderWt;
    /** 금속 코드 */
    private String metalCode;
    
    /** 차량 등록 제한 여부 */
    private String vhcleInfoRegistAt;
    /** EC 배송 차수 */
    private int ecDlvyOdr;
    /** 물류 배송 진행 상태 코드 */
    private int lgistDlvyProgrsSttusCode;
    /** 마지막수정일 */
    private String lastChangeDt;
    /** 판매방식코드 */
    private String sleMthdCode;
    
    /** FO/BO 호출 구분 (1:FO, 2:BO) */
    private String sysSe;
    /**
     * 업체 배송 메모
    */
    private String dlvyMemo;
    /** 마지막 수정자명 */
    private String lastChangerNm;
    
    /**
     * 차량 입고 대수
     */
    private String vhcleWrhousngCnt;
    
    /**
     * 배송 상태 코드
     */
    private int dlvyProgrsSttusCode;
    
    /**
     * 메세지 내용 구성을 위한 임시 차수 정보
     */
    private int dlvyOdrForMsg;

    /**
     * 납기 일자
     */
    private String dedtPrearngeDe;

    /**
     * 배송지 담당자
     */
    private String dlvrgCharger;

    /**
     * 배송지 연락처
     */
    private String dlvrgCttpc;

    /**
     * 배송 요청일 (인터페이스 전송용)
     */
    private String dlvyRqestde;

    /**
     * 배송지
     */
    private String dlvrg;

    /**
     * 변경 요청 코드( I, U, D)
     */
    private String changeRequstCode;

    /**
     * 최종 변경자 아이디
     */
    private String lastChangeId;

    /**
     * 취소 교환 반품 번호
     */
    private String canclExchngRtngudNo;

    /**
     * rowId
     */
    private String rowId;
    
}
