package com.sorincorp.bo.cs.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class DlvyInfoVO extends CommonVO {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7598874121068589055L;
	/**
     * 주문 번호
    */
    private String orderNo;
    /**
	 * 등록 차량 수
	 */
	private int existDlvyOdr;
	/**
	 * 최대 등록 가능한 배송 차수
	 */
	private int totDlvyOdr;
}
