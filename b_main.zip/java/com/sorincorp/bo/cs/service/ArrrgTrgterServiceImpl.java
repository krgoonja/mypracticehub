package com.sorincorp.bo.cs.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.cs.mapper.ArrrgTrgterMapper;
import com.sorincorp.bo.cs.model.ArrrgTrgterVO;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.message.service.CdtlnMessageService;
import com.sorincorp.comm.util.CryptoUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 미납대상자 관리 ArrrgTrgterServiceImpl.java
 * @version
 * @since 2022. 7. 11.
 * @author srec0066
 */
@Slf4j
@Service
public class ArrrgTrgterServiceImpl implements ArrrgTrgterService {
	
	@Autowired
	private ArrrgTrgterMapper arrrgTrgterMapper;
	
	@Autowired
	private CdtlnMessageService cdtlnMessageService;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	/** 미납 처리 유형 코드 */
	private final String NPY_PROCESS_TY_CODE_TLPHON = "10";
	private final String NPY_PROCESS_TY_CODE_EMAIL= "20";
	private final String NPY_PROCESS_TY_CODE_SMS= "30";
	
	/**
	 * 미납대상자 목록을 조회한다.
	 */
	@Override
	public List<ArrrgTrgterVO> searchArrrgTrgterList(ArrrgTrgterVO vo) throws Exception {
		List<ArrrgTrgterVO> arrrgTrgterList = arrrgTrgterMapper.searchArrrgTrgterList(vo);
		
		for (ArrrgTrgterVO trgter : arrrgTrgterList) {
			if (StringUtils.isNotBlank(trgter.getOrdrrMoblphonNo())) {
				trgter.setOrdrrMoblphonNo(CryptoUtil.decryptAES256(trgter.getOrdrrMoblphonNo()));	//복호화
			}
		}
		
		return arrrgTrgterList;
	}

	/**
	 * 미납대상자 목록을 총 개수를 조회한다.
	 */
	@Override
	public int selectArrrgTrgterListTotCnt(ArrrgTrgterVO vo) throws Exception {
		return arrrgTrgterMapper.selectArrrgTrgterListTotCnt(vo);
	}

	/**
	 * sms를 발송한다.
	 */
	@Override
	public Map<String, Object> insertSms(ArrrgTrgterVO vo) throws Exception {
		String userId = userInfoUtil.getUserId();
		
		Map<String, Object> returnMap = new HashMap<String, Object>();
		try {
			int mssageSndngHistNo = cdtlnMessageService.insertCdtlnSmsReturnMssageNo(vo.getOrderNo(), -1L, String.valueOf(vo.getTmplatNo()), userId);
			
			if(mssageSndngHistNo > 0) {
//				if(!"".equals(vo.getTmplatNo())) { //미납이외의 sms 선택시에도 미납관리테이블 적재
//				//미납관리테이블 INSERT
//				vo.setMssageSndngHistNo(mssageSndngHistNo);
//				vo.setNpyProcessTyCode(NPY_PROCESS_TY_CODE_SMS); //SMS
//				insertNpyOrderManage(vo);
//				}				
				returnMap.put("result", true);
				returnMap.put("message", "SMS(LMS) 발송을 성공했습니다.");
			}
			
		} catch (Exception e) {
			log.debug(e.getMessage());
			returnMap.put("result", true);
			returnMap.put("message", "SMS(LMS) 발송을 실패했습니다.");
		}
		
		return returnMap;
	}

	/**
	 * 이메일을 발송한다.
	 */
	@Override
	public Map<String, Object> insertEmail(ArrrgTrgterVO vo) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		try {
			int mailNo = cdtlnMessageService.insertCdtlnMailSendReturnMailNo(vo.getOrderNo(), String.valueOf(vo.getTmplatNo()));
			
			if(mailNo > 0) {
				//미납관리테이블 INSERT
				vo.setEmailSndngHistNo(mailNo);
				vo.setNpyProcessTyCode(NPY_PROCESS_TY_CODE_EMAIL); //이메일
				insertNpyOrderManage(vo);
				
				returnMap.put("result", true);
				returnMap.put("message", "이메일 발송을 성공했습니다.");
			}
		} catch (Exception e) {
			log.debug(e.getMessage());
			returnMap.put("result", true);
			returnMap.put("message", "이메일 발송을 실패했습니다.");
		}
		
		return returnMap;
	}

	/**
	 * 미납 cs처리를 등록한다.
	 */
	@Override
	public Map<String, Object> insertCs(ArrrgTrgterVO vo) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		try {
			vo.setNpyProcessTyCode(NPY_PROCESS_TY_CODE_TLPHON); //전화
			insertNpyOrderManage(vo);
			
			returnMap.put("result", true);
			returnMap.put("message", "CS처리 등록에 성공했습니다.");
			
		} catch (Exception e) {
			log.debug(e.getMessage());
			returnMap.put("result", true);
			returnMap.put("message", "CS처리 등록에 실패했습니다.");
		}
		
		return returnMap;
	}

	/**
	 * sms 템플릿 목록을 조회한다.
	 */
	@Override
	public List<ArrrgTrgterVO> selectSmsTmplatList(ArrrgTrgterVO vo) throws Exception {
		return arrrgTrgterMapper.selectSmsTmplatList(vo);
	}

	/**
	 * 이메일 템플릿 목록을 조회한다.
	 */
	@Override
	public List<ArrrgTrgterVO> selectEmailTmplatList(ArrrgTrgterVO vo) throws Exception {
		return arrrgTrgterMapper.selectEmailTmplatList(vo);
	}

	/**
	 *	미납 cs처리를 등록한다.(미납 주문 관리 기본, 이력 tbl)
	 */
	@Override
	public void insertNpyOrderManage(ArrrgTrgterVO vo) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		String userId ="";
		if(account != null) {
			userId = account.getId();
		}
		//휴대폰번호 암호화
		if (StringUtils.isNotBlank(vo.getOrdrrMoblphonNo())) {
			vo.setOrdrrMoblphonNo(CryptoUtil.encryptAES256(vo.getOrdrrMoblphonNo()));// 암호화
		}
		
		vo.setCsChargerId(userId);
		vo.setFrstRegisterId(userId);
		vo.setLastChangerId(userId);
		
		arrrgTrgterMapper.insertNpyOrderManage(vo);
		arrrgTrgterMapper.insertNpyOrderManageHst(vo);
	}

	/**
	 * 미납 cs처리 목록을 조회한다.(미납 주문 관리 기본 tbl)
	 */
	@Override
	public List<ArrrgTrgterVO> selectNpyOrderManageList(ArrrgTrgterVO vo) throws Exception {
		List<ArrrgTrgterVO> arrrgTrgterList = arrrgTrgterMapper.selectNpyOrderManageList(vo);
		for (ArrrgTrgterVO trgter : arrrgTrgterList) {
			if (StringUtils.isNotBlank(trgter.getOrdrrMoblphonNo())) {
				trgter.setOrdrrMoblphonNo(CryptoUtil.decryptAES256(trgter.getOrdrrMoblphonNo()));	//복호화
				trgter.setOrdrrInfo(trgter.getOrdrrNm()+"("+trgter.getOrdrrMoblphonNo()+")");
			}
		}
		return arrrgTrgterList;
	}

	/**
	 *	미납 cs처리 목록 총 개수를 조회한다.(미납 주문 관리 기본 tbl)
	 */
	@Override
	public int selectNpyOrderManageListTotCnt(ArrrgTrgterVO vo) throws Exception {
		return arrrgTrgterMapper.selectNpyOrderManageListTotCnt(vo);
	}
}
