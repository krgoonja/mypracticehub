package com.sorincorp.bo.cs.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.cs.model.ArrrgTrgterVO;

/**
 * 미납대상자 관리 ArrrgTrgterService.java
 * @version
 * @since 2022. 7. 11.
 * @author srec0066
 */
public interface ArrrgTrgterService {

	/**
	 * <pre>
	 * 처리내용: 미납대상자 목록을 조회한다.
	 * </pre>
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<ArrrgTrgterVO> searchArrrgTrgterList(ArrrgTrgterVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 미납대상자 목록을 총 개수를 조회한다.
	 * </pre>
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int selectArrrgTrgterListTotCnt(ArrrgTrgterVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: sms를 발송한다.
	 * </pre>
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> insertSms(ArrrgTrgterVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이메일을 발송한다.
	 * </pre>
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> insertEmail(ArrrgTrgterVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 미납 cs처리를 등록한다.
	 * </pre>
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> insertCs(ArrrgTrgterVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: sms 템플릿 목록을 조회한다.
	 * </pre>
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<ArrrgTrgterVO> selectSmsTmplatList(ArrrgTrgterVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이메일 템플릿 목록을 조회한다.
	 * </pre>
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<ArrrgTrgterVO> selectEmailTmplatList(ArrrgTrgterVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 미납 cs처리를 등록한다.(미납 주문 관리 기본, 이력 tbl)
	 * </pre>
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	void insertNpyOrderManage(ArrrgTrgterVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 미납 cs처리 목록을 조회한다.(미납 주문 관리 기본 tbl)
	 * </pre>
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<ArrrgTrgterVO> selectNpyOrderManageList(ArrrgTrgterVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 미납 cs처리 목록 총 개수를 조회한다.(미납 주문 관리 기본 tbl)
	 * </pre>
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int selectNpyOrderManageListTotCnt(ArrrgTrgterVO vo) throws Exception;
}
