package com.sorincorp.bo.cs.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.cs.model.*;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;

/**
 * DlvyDtlsInqireService.java
 * 배송 내역 조회 Service 인터페이스
 * 
 * @version
 * @since 2024. 6. 11.
 * @author srec0049
 */
public interface DlvyDtlsInqireService {

	/**
	 * <pre>
	 * 처리내용: 배송 내역 조회 목록 데이터를 가져온다.
	 * </pre>
	 * @date 2024. 6. 11.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 11.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param dlvyDtlsVO
	 * @return
	 * @throws Exception
	 */
	public List<DlvyDtlsVO> getListDlvyDtls(DlvyDtlsVO dlvyDtlsVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 차량종류 공통코드를 조회한다.
	 * </pre>
	 * @date 2024. 6. 14.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 14.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param sleMthdCode
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	public List<CommonCodeVO> selectVhcleGroupCodeList(String sleMthdCode, String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 출고 정보 리스트를 조회한다.
	 * </pre>
	 * @date 2024. 6. 14.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 14.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param seachVo
	 * @return
	 * @throws Exception
	 */
	public List<DlivyVO> selectDlivyList(String seachVo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 차량정보를 조회한다.
	 * </pre>
	 * @date 2024. 6. 14.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 14.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoVO
	 * @return
	 * @throws Exception
	 */
	public List<VhcleInfoVO> selectVhcleInfoList(DlvyDtlsVO dlvyDtlsVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 차량정보를 등록 및 수정한다.
	 * </pre>
	 * @date 2024. 6. 18.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 6. 18.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoArr
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> modifyVhcleInfoList(List<VhcleInfoVO> vhcleInfoArr) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 차량정보를 등록 및 수정한다.
	 * </pre>
	 * @date 2024. 11. 5.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 5.          hamyoonsic         최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoArr
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> vhcleWrhousngDeUpdt(VhcleInfoVO vhcleInfoVO) throws Exception;
	
}
