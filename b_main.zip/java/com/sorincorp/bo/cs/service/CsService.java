package com.sorincorp.bo.cs.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.cs.model.*;
import org.springframework.web.bind.annotation.RequestBody;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.model.CommonVO;

public interface CsService {
	List<CsInquiryVO> selectCsInquiryList(CsInquiryVO vo) throws Exception;
	int selectCsInquiryTotalCount(CsInquiryVO vo) throws Exception;
	int selectCsInquiryPagingTotalCount(CsInquiryVO vo) throws Exception;
	int selectNotResolvedCsInquiryCount(CsInquiryVO vo) throws Exception;

	CsInquiryVO selectInquiry(CsInquiryVO vo) throws Exception;
	CsInquiryVO selectInquiryAnswer(CsInquiryVO vo) throws Exception;
	void insertInquiry(CsInquiryVO vo) throws Exception;
	void insertInquiryAnswer(CsInquiryVO vo) throws Exception;
	void updateInquiryAnswer(CsInquiryVO vo) throws Exception;

	void insertAndUpdateGridDataList(List<CsInquiryVO> vo) throws Exception;
	void deleteGridDataList(List<CsInquiryVO> vo) throws Exception;

	String getCommCodeListStr(Map<String, String> commonCodeList) throws Exception;
	String getCommCodeListStrNoAllOption(Map<String, String> commonCodeList) throws Exception;
	List<CommonCodeVO> selectInqrySeDetailCode(String inqrySeCode) throws Exception;

	List<CsMemberVO> selectMemberList(CommonVO vo) throws Exception;
	int selectMemberTotalCount(CommonVO vo) throws Exception;

	/**
	 * <pre>
	 * 배송진행내역 조회
	 * </pre>
	 * @date 2022. 10. 12.
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<DlvyProgrsDtlsVO> selectDlvyProgrsDtlsList(DlvyProgrsDtlsVO vo) throws Exception;

	/**
	 * <pre>
	 * 배송진행내역조회 카운트
	 * </pre>
	 * @date 2022. 10. 12.
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int selectDlvyProgrsDtlsPagingTotalCount(DlvyProgrsDtlsVO vo) throws Exception;

	/**
	 * <pre>
	 * 주문 BL 정보 조회
	 * </pre>
	 * @date 2022. 10. 12.
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	List<BlInfoVO> selectBlInfo(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 차량 정보 조회
	 * </pre>
	 * @author srec0051
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	List<VhcleInfoVO> selectVhcleInfoList(String orderNo) throws Exception;

	/**
	 * <pre>
	 * CS관리 > 배송관리 > 배송진행내역조회 > 상세 (팝업) > 차량등록/수정
	 * </pre>
	 * @date 2022. 10. 12.
	 * @param vo
	 * @throws Exception
	 */
	void insertAndUpdateVhcleInfoList(VhcleInfoVO2 vo) throws Exception;

	/**
	 * 차량정보 등록 제한 여부 저장
	 * @param vo
	 * @throws Exception
	 */
	int updateOrderVhcleInfoRegistAt(VhcleInfoVO vo) throws Exception;
	
	/**
	 * <pre>
	 * CS관리 > 배송관리 > 배송진행내역조회 > 상세 (팝업) > 등록된 차량 정보 확인
	 * </pre>
	 * @date 2023. 3. 15.
	 * @author srec0051
	 * @param DlvyInfoVO
	 * @return
	 */
	Map<String, Object> selectDlvyInfo(DlvyInfoVO vo) throws Exception;

	/**
	 * <pre>
	 * 차량종류 공통코드를 조회
	 * </pre>
	 * @date 2022. 12. 15.
	 * @author srec0051
	 * @param sleMthdCode
	 * @return
	 */
	List<CommonCodeVO> selectVhcleGroupCodeList(DlvyProgrsDtlsVO vo) throws Exception;

	/**
	 * <pre>
	 * 이벤트 휴일에 포함되는지 조회
	 * </pre>
	 * @date 2023. 1. 13.
	 * @author srec0051
	 * @param vhcleInfoVO
	 * @return
	 */
	Object checkHolidayYn(VhcleInfoVO vhcleInfoVO) throws Exception;

	/**
	 * <pre>
	 * 기준일자, 일수를 받아 계산된 영업일과 날짜변경가능여부를 리턴
	 * </pre>
	 * @date 2023. 1. 13.
	 * @author srec0051
	 * @param vhcleInfoVO
	 * @return
	 */
	Map<String, Object> getSettleSttusDe(VhcleInfoVO vhcleInfoVO) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 알림톡 템플릿 목록을 조회한다.
	 * </pre>
	 * @date 2023. 7. 19.
	 * @author srec0083
	 * @param dlvyProgrsDtlsVO
	 * @return 
	 */
	DlvyProgrsDtlsVO selectAlimTmplatList(DlvyProgrsDtlsVO dlvyProgrsDtlsVO) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 알림톡을 발송한다.
	 * </pre>
	 * @date 2023. 7. 19.
	 * @author srec0083
	 * @param dlvyProgrsDtlsVO
	 * @return
	 */
	Map<String, Object> sendAlim(DlvyProgrsDtlsVO dlvyProgrsDtlsVO) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 차량정보 안내 알림톡을 발송한다.
	 * </pre>
	 * @date 2024. 10. 23.
	 * @author hamyoonsic
	 * @param dlvyProgrsDtlsVO
	 * @return
	 */
	Map<String, Object> sendVhcleInfoAlim(DlvyProgrsDtlsVO dlvyProgrsDtlsVO) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 차량 등록 알림톡 발송 이력 데이터를 조회한다.
	 * </pre>
	 * @date 2023. 7. 21.
	 * @author srec0083
	 * @param dlvyProgrsDtlsVO
	 * @return
	 */
	List<ArrrgTrgterVO> selectVhcleAlimList(DlvyProgrsDtlsVO dlvyProgrsDtlsVO) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 금일 날짜 조회
	 * </pre>
	 * @date 2024. 4. 4.
	 * @author hyunjin0512
	 * @return
	 */
	String thisDate() throws Exception;
}
