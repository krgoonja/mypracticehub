package com.sorincorp.bo.cs.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.sorincorp.bo.co.comm.OrPropertyConstant;
import com.sorincorp.bo.cs.mapper.DlvyDtlsInqireMapper;
import com.sorincorp.bo.cs.model.ArrrgTrgterVO;
import com.sorincorp.bo.cs.model.DlivyVO;
import com.sorincorp.bo.cs.model.DlvyDetailDtlsVO;
import com.sorincorp.bo.cs.model.DlvyDtlsVO;
import com.sorincorp.bo.cs.model.OrderDtlsVO;
import com.sorincorp.bo.cs.model.VhcleInfoVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * DlvyDtlsInqireServiceImpl.java
 * 배송 내역 조회 Service 구현체 클래스
 * 
 * @version
 * @since 2024. 6. 11.
 * @author srec0049
 */
@Slf4j
@Service
public class DlvyDtlsInqireServiceImpl implements DlvyDtlsInqireService {

	/** 공통  **/
	@Autowired
	private CommonService commonService;
	
	/** 프로퍼티 상수 모음 **/
    @Autowired
    private OrPropertyConstant orProperty;
	
	/** 외부 연계 api 호출 모듈 **/
	@Autowired
	private HttpClientHelper httpClientHelper;
	
	/** SMS 발송 서비스 **/
	@Autowired
	private SMSService smsService;
	
	/**
	 * 배송 내역 조회 Mapper
	 */
	@Autowired
	DlvyDtlsInqireMapper dlvyDtlsInqireMapper;
	
	
	/**
	 * 배송 내역 조회 목록 데이터를 가져온다.
	 */
	@Override
	public List<DlvyDtlsVO> getListDlvyDtls(DlvyDtlsVO dlvyDtlsVO) throws Exception {
		
		// 배송 내역 조회 목록 데이터를 가져온다.
		List<DlvyDtlsVO> getListDlvyDtls = dlvyDtlsInqireMapper.getListDlvyDtls(dlvyDtlsVO);
		if (!CollectionUtils.isEmpty(getListDlvyDtls)) {
			getListDlvyDtls.stream().forEach(vo -> {
				// OR_ORDER_BAS(주문_주문 기본)-ORDRR_MOBLPHON_NO(주문자 휴대폰 번호) 복호화
				try {
					if(StringUtils.isNotEmpty(vo.getOrdrrMoblphonNo())) {
						log.debug("주문자 전화번호1 전 ==================>" + vo.getOrdrrMoblphonNo());
						String orderMoblphonNo = CryptoUtil.decryptAES256(vo.getOrdrrMoblphonNo());
						log.debug("주문자 전화번호1 후 ==================>" + orderMoblphonNo);
						/** 주문자 휴대폰 번호 번호 셋팅 **/
						vo.setOrdrrMoblphonNo(StringUtil.formatPhone(orderMoblphonNo));
					}
					
					// 배송 상세 내역 조회
					List<DlvyDetailDtlsVO> deliveryDetailDtlsList = dlvyDtlsInqireMapper.selectDeliveryDetailDtlsList(vo.getOrderNo());
					
					// 조회 결과가 없으면 다음 주문 건으로 진행
					if(deliveryDetailDtlsList.isEmpty()) return;
					
					// 자차배송 > 상세내역 > 요청 정보 세팅
					if(StringUtils.equals(vo.getDlvyMnCode(), "02")) {																	// 확정 정보 아님 == 요청 정보임
						vo.setDeliveryDetailDtlsRequstList(deliveryDetailDtlsList.stream().filter(dtls -> !dtls.isDcsnInfoAt()).collect(Collectors.toList()));
					}
					
					// 자차배송 > 상세내역 > 확정 정보 세팅
					// 케이지배송 > 상세내역 세팅																								확정 정보임
					vo.setDeliveryDetailDtlsDcsnList(deliveryDetailDtlsList.stream().filter(dtls -> dtls.isDcsnInfoAt()).collect(Collectors.toList()));
				} catch(Exception e) {
					log.error("CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
			});
		}
		
		return getListDlvyDtls;
	}
	
	/**
	 * 차량종류 공통코드를 조회한다.
	 */
	@Override
	public List<CommonCodeVO> selectVhcleGroupCodeList(String sleMthdCode, String metalCode) throws Exception {
		// 차량종류 공통코드를 조회한다.
		return dlvyDtlsInqireMapper.selectVhcleGroupCodeList(sleMthdCode, metalCode);
	}
	
	/**
	 * 출고 정보 리스트를 조회한다.
	 */
	@Override
	public List<DlivyVO> selectDlivyList(String seachVo) throws Exception {
		// 출고 정보 리스트를 조회한다.
		return dlvyDtlsInqireMapper.selectDlivyList(seachVo);
	}
	
	/**
	 * 차량정보를 조회한다.
	 */
	@Override
	public List<VhcleInfoVO> selectVhcleInfoList(DlvyDtlsVO dlvyDtlsVO) throws Exception {
		List<VhcleInfoVO> list = dlvyDtlsInqireMapper.selectVhcleInfoList(dlvyDtlsVO);
		if (!CollectionUtils.isEmpty(list)) {
			for (VhcleInfoVO vo : list) {
				if (StringUtils.isBlank(vo.getDrverTlphonNo())) continue;

				String drverTlpphonNo = CryptoUtil.decryptAES256(vo.getDrverTlphonNo());
				vo.setDrverTlphonNo(StringUtil.formatPhone(drverTlpphonNo)); // 복호화
			}
		}

		return list;
	}
	
	/**
	 * 차량정보를 등록 및 수정한다.
	 * 20230724 차량 고도화
	 */
	@Override
	public Map<String, Object> modifyVhcleInfoList(List<VhcleInfoVO> vhcleInfoArr) throws Exception {
	    Map<String, Object> rtnMap = new HashMap<>();
	    rtnMap.put("result", "E");
        rtnMap.put("resultMsg", "일부 통신장애가 발생하였습니다. 관리자에게 문의하세요.");

        String dlivyRequstDe = "";
	    int vhcleCnt = 0;
		for (VhcleInfoVO vo : vhcleInfoArr) {
			vhcleCnt++;

			// 기사연락처 암호화
			if (StringUtils.isNotBlank(vo.getDrverTlphonNo())) {
				vo.setDrverTlphonNo(CryptoUtil.encryptAES256(vo.getDrverTlphonNo().replace("-", "")));
			}

			//기존출고요청일 조회
			dlivyRequstDe = dlvyDtlsInqireMapper.selectDlivyRequstDe(vo.getOrderNo());
			// 차량정보 등록 및 수정
			try {
				
				// update 로직 대응을 위한 기존 key값 backup
				int originVhclOrderSn = vo.getDlvyOdr();
				int originVhcleSn = vo.getVhcleSn();
				
				dlvyDtlsInqireMapper.insertVhcleBas(vo);
				dlvyDtlsInqireMapper.insertVhcleOrderDtl(vo);
				
				// update 대상일 시, update 하면서 가져온 최신 key값을 기존 key값으로 대체
				if(StringUtils.equals(vo.getMode(), "saved")) {
					vo.setDlvyOdr(originVhclOrderSn);
					vo.setVhcleSn(originVhcleSn);
				}
				
				//히스토리 생성
				Map<String,String> keyValue = new HashMap<>();
				keyValue.put("VHCLE_SN",String.valueOf(vo.getVhcleSn()));
				commonService.insertTableHistory("OR_VHCLE_BAS", keyValue);
				
				keyValue = new HashMap<>();
				keyValue.put("VHCLE_ORDER_SN",String.valueOf(vo.getDlvyOdr()));
				commonService.insertTableHistory("OR_VHCLE_ORDER_DTL", keyValue);

				//기존 출고요청일과 업데이트하려는 차량입고일 비교
				int result = DateUtil.intervalDay(dlivyRequstDe,vo.getVhcleWrhousngDe());
				//하루이상 차이날 경우(result가 양수면 차량입고일이 미래, 음수면 과거)
				if(result != 0) {
					//출고요청일 업데이트
					dlvyDtlsInqireMapper.updateDlivyRequstDe(vo);
					dlivyRequstDe = vo.getVhcleWrhousngDe();
					//히스토리 생성
					keyValue = new HashMap<>();
					keyValue.put("ORDER_NO",vo.getOrderNo());
					commonService.insertTableHistory("OR_ORDER_BAS", keyValue);
				}
				
				// 24-06-04 변경사항 : 메세지에서 차수 정보를 기존의 차수 정보(1차수, 2차수..)와 동일하게 구성할 수 있도록 메세지 처리용 차수 데이터 세팅
				vo.setDlvyOdrForMsg(vhcleCnt);
			} catch (Exception e) {
				log.error(e.getMessage());
				return rtnMap;
			}
		}

		try {
			if (vhcleCnt < 1) {
				throw new Exception("등록할 차량정보가 없습니다.");
			}

			// 차량정보 등록 및 수정 고객 SMS
			sendMessageToCustomer(vhcleInfoArr, "50");
			// 배송기사 SMS 발송
			sendMessageToDriver(vhcleInfoArr, "107");

		    // 자차 자량정보 등록 및 수정 api
			// FO/BO 호출 구분 (1:FO, 2:BO)
			Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getLoOmsUrl() + "/sendDlvyVhcleInfo/1", vhcleInfoArr);
			if (resObj.isEmpty()) {
				throw new Exception("통신장애");
			}

        } catch (Exception e) {
            log.error("차량정보 API 실패 ===> ", e.getMessage());
			// 자차 자량정보 등록 및 수정 api 오류 SMS
			callSms(vhcleInfoArr.get(0));
            return rtnMap;
        }

		rtnMap.put("result", "S");
		rtnMap.put("resultMsg", "차량정보가 등록되었습니다.");
		rtnMap.put("dlivyRequstDe", dlivyRequstDe);

		return rtnMap;
	}
	
	/**
	 * 고객 대상 메세지 발송 메소드
	 */
	private void sendMessageToCustomer(List<VhcleInfoVO> vhcleInfoArr, String templateNum) throws Exception {
		log.warn("[OrderDtlsDetailServiceImpl][sendMessageToCustomer] IN");
		try {
			SMSVO smsVO = new SMSVO();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));

			Map<String, String> smsMap = new HashMap<>();
			VhcleInfoVO vo = null;
			String smsList = "";
			
			// 메세지 내용에 1부터 시작하는 차수를 생성하여 보여주도록 하기 위해 소스 변경
			// 임시배송차수 For 메세지
			int tempDlvyOdrForMsg = 1;

			for(VhcleInfoVO voInfoVO : vhcleInfoArr) {
				// 삭제 대상 차수 정보는 내용으로 포함되지 않도록 로직 skip 처리
				if(StringUtils.equals(voInfoVO.getDeleteAt(), "Y")) {
					continue;
				}
				
				smsList += tempDlvyOdrForMsg++ + "회차";	// db에 등록된 배송차수 말고, 임시배송차수로 내용 구성
				if(!String.valueOf(voInfoVO.getDlvyOdrForMsg()).isEmpty() && !voInfoVO.getVhcleWrhousngDe().isEmpty() && !voInfoVO.getDrverNm().isEmpty() && !voInfoVO.getVhcleNo().isEmpty() && !voInfoVO.getDrverTlphonNo().isEmpty()) {
					smsList += "(차량입고일: " + voInfoVO.getVhcleWrhousngDe() + ")" + "\n"
							+	voInfoVO.getDrverNm() + "-" + voInfoVO.getVhcleNo() + " (" + StringUtil.formatPhone(CryptoUtil.decryptAES256(voInfoVO.getDrverTlphonNo())) + ")" + "\n" + "\n";
				}else {
					smsList += "(미등록)" + "\n" + "\n";
				}
				vo = voInfoVO;
			}

			//고객 전화번호
			OrderDtlsVO orderDtlsVO = dlvyDtlsInqireMapper.selectSmsUserInfo(vo);

			// ORDRR_MOBLPHON_NO(주문자 휴대폰 번호) 복호화
			String ordrrMoblphonNo = String.valueOf(orderDtlsVO.getOrdrrMoblphonNo());
			if(StringUtils.isNotEmpty(ordrrMoblphonNo)) {
				try {
					log.debug("주문자 휴대폰 번호 복호화 전 ==================>" + ordrrMoblphonNo);
					ordrrMoblphonNo = CryptoUtil.decryptAES256(ordrrMoblphonNo);
					log.debug("주문자 휴대폰 번호 복호화 후 ==================>" + ordrrMoblphonNo);
					/** 주문자 휴대폰 번호 셋팅 **/
					orderDtlsVO.setOrdrrMoblphonNo((ordrrMoblphonNo));
				} catch (Exception e) {
					log.error("OrderDtlsDetailServiceImpl sendMessageToCustomer ORDRR_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
			}
			smsVO.setPhone(orderDtlsVO.getOrdrrMoblphonNo());
			smsVO.setCommerceNtcnAt("N"); // 커머스 알림 여부

			switch(templateNum) {
			case "50" :
				smsMap = dlvyDtlsInqireMapper.selectSmsInfo(vo);
				smsMap.put("smsList", smsList);

				break;
			}

			smsMap.put("templateNum", templateNum);

			log.debug(">> smsMap toString : " + smsMap.toString());

			smsService.insertSMS(smsVO, smsMap);

		} catch (Exception e) {
			log.error("[OrderDtlsDetailServiceImpl][sendMessageToCustomer] " + ExceptionUtils.getStackTrace(e));
		}
	}
	
	/**
	 * 배송기사 대상 메세지 발송 메소드
	 */
	private void sendMessageToDriver(List<VhcleInfoVO> vhcleInfoArr, String templateNum) throws Exception {
		log.warn("[OrderDtlsDetailServiceImpl][sendMessageToDriver] IN");
		try {
			for(VhcleInfoVO voInfoVO : vhcleInfoArr) {
				SMSVO smsVO = new SMSVO();
				smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
				smsVO.setCommerceNtcnAt("N"); // 커머스 알림 여부

				VhcleInfoVO vo = null;
				Map<String, String> smsMap = new HashMap<>();

				String status = "";
				String prevPhoneNo = "";

				String newSmsList = "";
				String prevSmsList = "";

				//내부사용자 전송용 메시지 내용 별도로 세팅
				String innerDepartmentSmsList = "";

				if(voInfoVO.getMode().equals("new")) {
					status = "등록";
				}else if(voInfoVO.getMode().equals("saved")) {
					if(voInfoVO.getDeleteAt().equals("Y")) {
						status = "삭제";
					}else if(voInfoVO.getDeleteAt().equals("N")) {
						VhcleInfoVO vhclHist = dlvyDtlsInqireMapper.selectOrVhcleInfoHst(voInfoVO);
						
						if(vhclHist == null)
							continue;
						
						//기저장되어있는 휴대폰 번호 하이픈 제거 후 재복호화
						vhclHist.setDrverTlphonNo(CryptoUtil.encryptAES256(CryptoUtil.decryptAES256(vhclHist.getDrverTlphonNo()).replace("-", "")));
						
						//배송완료된 차수 정보 문자 전송 제외
						if(vhclHist != null && vhclHist.getDlvyProgrsSttusCode() < 30
								&& (!vhclHist.getDrverNm().equals(voInfoVO.getDrverNm())
								|| !vhclHist.getDrverTlphonNo().equals(voInfoVO.getDrverTlphonNo())
								|| !vhclHist.getVhcleNo().equals(voInfoVO.getVhcleNo())
								|| !vhclHist.getVhcleWrhousngDe().equals(voInfoVO.getVhcleWrhousngDe()))) {//배송정보 변경된 경우
							status = "변경";

							//변경전 폰번호
							prevPhoneNo = vhclHist.getDrverTlphonNo();

							//변경전 차량등록정보
							prevSmsList += voInfoVO.getDlvyOdrForMsg() + "회차";
							prevSmsList += "(차량입고일: " + vhclHist.getVhcleWrhousngDe() + ")" + "\n"
										+	vhclHist.getDrverNm() + "-" + vhclHist.getVhcleNo() + " (" + StringUtil.formatPhone(CryptoUtil.decryptAES256(vhclHist.getDrverTlphonNo())) + ")" + "\n" + "\n";
						}else {
							continue;
						}
					}
				}
				//변경된 차량등록정보
				newSmsList += voInfoVO.getDlvyOdrForMsg() + "회차";
				newSmsList += "(차량입고일: " + voInfoVO.getVhcleWrhousngDe() + ")" + "\n"
						   +	voInfoVO.getDrverNm() + "-" + voInfoVO.getVhcleNo() + " (" + StringUtil.formatPhone(CryptoUtil.decryptAES256(voInfoVO.getDrverTlphonNo())) + ")" + "\n" + "\n";

				vo = voInfoVO;

				String phoneNo = String.valueOf(voInfoVO.getDrverTlphonNo());
				if(StringUtils.isNotEmpty(phoneNo)) {
					try {
						phoneNo = CryptoUtil.decryptAES256(phoneNo);
						voInfoVO.setDrverTlphonNo((phoneNo));
						if(StringUtils.isNotEmpty(prevPhoneNo)) prevPhoneNo = CryptoUtil.decryptAES256(prevPhoneNo);
					} catch (Exception e) {
						log.error("OrderDtlsDetailServiceImpl sendMessageToDriver DRVER_TLPHON_NO CryptoUtil.decryptAES256 ERROR " + ExceptionUtils.getStackTrace(e));
					}
				}

				smsMap = dlvyDtlsInqireMapper.selectDriverSmsInfo(vo);
				smsMap.put("templateNum", templateNum);
				smsMap.put("excpSndngOptnAt", "N"); // 예외 발송 옵션 여부, N일 경우 SMS 수신자만 발송한다.

				//배송기사 메시지 전송
				if(status.equals("변경")) {
					if(StringUtils.isNotEmpty(prevPhoneNo)) {
						smsMap.put("smsList", prevSmsList);
						smsMap.put("status", "삭제");
						smsVO.setPhone(prevPhoneNo);

						smsService.insertSMS(smsVO, smsMap);
					}

					if(StringUtils.isNotEmpty(voInfoVO.getDrverTlphonNo())) {
						smsVO = new SMSVO();
						smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
						smsVO.setCommerceNtcnAt("N");

						smsMap.put("smsList", newSmsList);
						smsMap.put("status", "등록");
						smsVO.setPhone(voInfoVO.getDrverTlphonNo());

						smsService.insertSMS(smsVO, smsMap);
					}

					innerDepartmentSmsList = StringUtils.removeEnd(prevSmsList, "\n") + "[변경]" + "\n" + newSmsList;
				}else {
					if(StringUtils.isNotEmpty(voInfoVO.getDrverTlphonNo())) {
						smsMap.put("smsList", newSmsList);
						smsMap.put("status", status);
						smsVO.setPhone(voInfoVO.getDrverTlphonNo());

						smsService.insertSMS(smsVO, smsMap);
					}

					innerDepartmentSmsList = newSmsList;
				}

				log.debug(">> smsMap toString : " + smsMap.toString());

				// 내부사용자 별도 전송
				smsMap.put("smsList", innerDepartmentSmsList);
				smsMap.put("status", status);
				smsMap.put("commerceNtcnAt", "N"); // 추가 수신사 커머스 알림 여부 따로 설정
				smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
				smsService.insertSMS(null, smsMap);
			}
		} catch (Exception e) {
			log.error("[OrderDtlsDetailServiceImpl][sendMessageToDriver] " + ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 * SMS 서비스를 호출
	 */
	private synchronized void callSms(VhcleInfoVO vhcleInfoVO) {
		log.warn("[OrderDtlsDetailServiceImpl][callSms] IN");
		// 템플릿에 따라 SMS 전송을 처리한다.
		procSms(vhcleInfoVO, "49", "자차 자량정보 등록 및 수정 api 실패");
	}
	
	/**
	 * 템플릿에 따라 SMS 전송 처리. (내부 사용자 SMS)
	 */
	private void procSms(VhcleInfoVO vhcleInfoVO, String templateNum, String addStr) {
		log.warn("[OrderDtlsDetailServiceImpl][procSms] IN");

		try {
			Map<String, String> smsMap = new HashMap<>();

			switch (templateNum) {
				case "49":
					smsMap.put("orderNo", vhcleInfoVO.getOrderNo()); // 주문번호
					smsMap.put("returnMsg", addStr); // 자차 자량정보 등록 및 수정 IF시 오류발생
					break;
			}

			smsMap.put("templateNum", templateNum);

			// 자차 자량정보 등록 및 수정 api 오류 SMS 전송
			smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
			smsService.insertSMS(null, smsMap);
		} catch (Exception e) {
			log.error("[OrderDtlsDetailServiceImpl][procSms] " + ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 * 인터페이스 SOREC-IF-115 요청
	 */
	public Map<String, Object> vhcleWrhousngDeUpdt(VhcleInfoVO vhcleInfoVO) {
		// 케이지배송 변경 API 호출[SOREC-IF-115]
		log.debug("DlvyDtlsInqireServiceImpl :: vhcleWrhousngDeUpdt SOREC-IF-115 vhcleInfoVO {}",vhcleInfoVO);
		VhcleInfoVO dispatChangeVO = new VhcleInfoVO();
		Map<String, Object> resObj = null;
		Map<String, Object> dispatChangeMap = null;
		try {
			//물류 전송 정보 셋팅
			dispatChangeVO = dlvyDtlsInqireMapper.selectVhcleInfo(vhcleInfoVO);
			dispatChangeVO.setEcOrderNo(vhcleInfoVO.getOrderNo());//EC_ORDER_NO
			dispatChangeVO.setDlvyRqestde(vhcleInfoVO.getDedtPrearngeDe());//납기 예정 일자 (변경 요청일)
			dispatChangeVO.setChangeRequstCode("U"); //* I 추가 U 수정 D 삭제*//*
			dispatChangeVO.setLastChangerNm(vhcleInfoVO.getLastChangerNm());// 마지막 수정자 이름 (요청자 이름)
			dispatChangeVO.setCanclExchngRtngudNo(vhcleInfoVO.getCanclExchngRtngudNo());// 취소 교환 반품 번호 
			dispatChangeVO.setDedtPrearngeDe(vhcleInfoVO.getDedtPrearngeDe());// 취소 교환 반품 번호

			resObj = httpClientHelper.postCallApi(orProperty.getLoOmsUrl() + "/dispatChange", dispatChangeVO);
			log.debug("vhcleWrhousngDeUpdt SOREC-IF-115 : " + resObj);
			if (StringUtils.equals(String.valueOf(resObj.get("rspnsCode")), "200")) {
				log.debug("vhcleWrhousngDeUpdt SOREC-IF-115 success");
				//주문_배송 차수 기본 기존 차량 정보 삭제
				dlvyDtlsInqireMapper.deleteOrDlvyOdrBas(dispatChangeVO);
				//주문_배송 차수 기본 임의 차량 정보 등록 (실제 배차 정보는 090인터페이스 INSERT)
				dlvyDtlsInqireMapper.insertOrDlvyOdrBas(dispatChangeVO);
				commonService.insertTableHistory("OR_DLVY_ODR_BAS", dispatChangeVO);
			} else {
				log.debug("vhcleWrhousngDeUpdt SOREC-IF-115 error >> \" + resObj.get(\"rspnsMssage\")");
				throw new Exception("vhcleWrhousngDeUpdt SOREC-IF-115 error >> " + resObj.get("rspnsMssage"));
			}
		} catch (Exception e) {
			log.error("vhcleWrhousngDeUpdt SOREC-IF-115 fail ===> ", e.getMessage());
		} finally {
			return resObj;
		}
	}
	
}
