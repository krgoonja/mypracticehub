package com.sorincorp.bo.cs.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sorincorp.bo.cs.mapper.DlvyDtlsInqireMapper;
import com.sorincorp.bo.cs.model.*;
import com.sorincorp.comm.common.service.CommonService;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.cs.mapper.CsMapper;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.message.model.AppPushQueueVO;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.CdtlnMessageService;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.model.CommonVO;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CsServiceImpl implements CsService {

	@Autowired
	private CsMapper csMapper;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private MailService mailService;

	@Autowired
	private SMSService smsService;

	@Autowired
    private CdtlnMessageService cdtlnMessageService;

	@Autowired
	private CommonService commonService;

	@Autowired
	DlvyDtlsInqireMapper dlvyDtlsInqireMapper;

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Value("${order.api.lo.oms.url}")
	private String apiDomain;

	@Value("${mo.url.vhcleRegist}")
	private String vhcleRegistUrl;


	@Override
	public List<CsInquiryVO> selectCsInquiryList(CsInquiryVO vo) throws Exception{
		List<CsInquiryVO> inquiryList = csMapper.selectCsInquiryList(vo);

		for (CsInquiryVO csInquiryVO : inquiryList) {
			if(StringUtils.isNotBlank(csInquiryVO.getInqryTelno())) {
				csInquiryVO.setInqryTelno(CryptoUtil.decryptAES256(csInquiryVO.getInqryTelno()).replace("", ""));	//복호화
			}
		}

		return inquiryList;
	}

	@Override
	public int selectCsInquiryTotalCount(CsInquiryVO vo) throws Exception {
		return csMapper.selectCsInquiryTotalCount(vo);
	}

	@Override
	public int selectCsInquiryPagingTotalCount(CsInquiryVO vo) throws Exception{
		return csMapper.selectCsInquiryPagingTotalCount(vo);
	}

	@Override
	public int selectNotResolvedCsInquiryCount(CsInquiryVO vo) throws Exception{
		return csMapper.selectNotResolvedCsInquiryCount(vo);
	}

	@Override
	public CsInquiryVO selectInquiry(CsInquiryVO vo) throws Exception {
		CsInquiryVO result = csMapper.selectInquiry(vo.getInqrySn());
		List<FileDocVO> attachFileList = csMapper.selectAttachFileNoList(vo.getInqrySn());

		if(!attachFileList.isEmpty()) {		//첨부된 파일이 있다면, 첨부 파일 목록을 추가
			result.setAttachFileList(attachFileList);
		}

		if("update".equals(vo.getGridRowStatus())) {
			result.setGridRowStatus("update");
		}

		if(StringUtils.isNotBlank(result.getInqryTelno())) {
			result.setInqryTelno(CryptoUtil.decryptAES256(result.getInqryTelno()).replace("-", ""));	//복호화
		}

		return result;
	}

	@Override
	public CsInquiryVO selectInquiryAnswer(CsInquiryVO vo) throws Exception {
		CsInquiryVO inquiryAnswer = csMapper.selectInquiryAnswer(vo);

		if(inquiryAnswer != null) {
			inquiryAnswer.setGridRowStatus("update");
		}else {
			inquiryAnswer = new CsInquiryVO();
			inquiryAnswer.setGridRowStatus("insert");
		}
		return inquiryAnswer;
	}

	@Override
	public void insertAndUpdateGridDataList(List<CsInquiryVO> vo) throws Exception{
		//세션 정보
		Account account = userInfoUtil.getAccountInfo();

		String id = account.getId();
		String name = account.getName();

		CsInquiryVO inquiry = null;		//문의 데이터
		CsInquiryVO answer = null;		//답변 데이터


		//데이터 종류 구분 로직 start
		for (CsInquiryVO iterator : vo) {
			iterator.setFrstRegisterId(id);
			iterator.setLastChangerId(id);

			if("01".equals(iterator.getInqryAnswerSeCode()) && "insert".equals(iterator.getGridRowStatus())) {		//문의 데이터
				inquiry = iterator;
			}else {											//답변 데이터
				answer = iterator;
			}
		}//데이터 종류 구분 로직 end

		if(inquiry != null) {		//문의 데이터 관련 로직 수행
			this.insertInquiry(inquiry);
		}

		if(answer != null) {		//답변 데이터 관련 로직 수행
			answer.setInqryAnswerMan(name);		//세션 정보를 통해, 접속한 유저의 이름을 답변자 데이터로 세팅

			if(inquiry != null) {	//문의 데이터가 있다면, "부모 문의 답변 순번"을 세팅해줌
				answer.setParntsInqryAnswerSn((int)inquiry.getInqrySn());
			}

			if("insert".equals(answer.getGridRowStatus())) {	//1. 답변 데이터 최초 등록 시 insert 처리 2. 메일 발송
				this.insertInquiryAnswer(answer);

				this.sendMessageToCustomer(answer);
			}else {							//답변 데이터 수정 시 update 처리
				this.updateInquiryAnswer(answer);
			}
		}
	}

	@Override
	public void insertInquiry(CsInquiryVO vo) throws Exception{
		if(StringUtils.isNotBlank(vo.getInqryTelno())) {
			vo.setInqryTelno(CryptoUtil.encryptAES256(vo.getInqryTelno().replace("-", "")));	//암호화
		}

		//문의 데이터 insert
		csMapper.insertInquiry(vo);
		//csMapper.insertCsInquiryHst(vo.getInqrySn());
		commonService.insertTableHistory("CS_INQRY_BAS", vo);
	}

	@Override
	public void insertInquiryAnswer(CsInquiryVO vo) throws Exception{
		//답변 데이터 insert
		csMapper.insertInquiryAnswer(vo);
		//csMapper.insertCsInquiryHst(vo.getInqrySn());
		commonService.insertTableHistory("CS_INQRY_BAS", vo);

		//문의 데이터 update
		csMapper.updateCsInquiry(vo);
		//csMapper.insertCsInquiryHst(vo.getParntsInqryAnswerSn());
		commonService.insertTableHistory("CS_INQRY_BAS", vo);
	}

	@Override
	public void updateInquiryAnswer(CsInquiryVO vo) throws Exception{
		//답변 데이터 update
		csMapper.updateInquiryAnswer(vo);
		//csMapper.insertCsInquiryHst(vo.getInqrySn());
		commonService.insertTableHistory("CS_INQRY_BAS", vo);

		//문의 데이터 update
		csMapper.updateCsInquiry(vo);
		//csMapper.insertCsInquiryHst(vo.getParntsInqryAnswerSn());
		commonService.insertTableHistory("CS_INQRY_BAS", vo);
	}

	@Override
	public void deleteGridDataList(List<CsInquiryVO> vo) throws Exception {
		for (CsInquiryVO inquiry : vo) {
			csMapper.deleteCsInquiry(inquiry);
			//csMapper.insertCsInquiryHst(inquiry.getInqrySn());
			commonService.insertTableHistory("CS_INQRY_BAS", inquiry);
		}
	}

	@Override
	public String getCommCodeListStr(Map<String, String> commonCodeList) throws Exception {

		StringBuilder codeTaglibStr = new StringBuilder(StringUtils.EMPTY);

		codeTaglibStr.append("");
		codeTaglibStr.append(CommonConstants.COLONE);
		codeTaglibStr.append("전체");
		codeTaglibStr.append(CommonConstants.SEMI_COLONE);

		for( String code : commonCodeList.keySet() ) {
			codeTaglibStr.append(code);
			codeTaglibStr.append(CommonConstants.COLONE);
			codeTaglibStr.append(commonCodeList.get(code));
			codeTaglibStr.append(CommonConstants.SEMI_COLONE);
		}

		return codeTaglibStr.toString();
	}

	@Override
	public String getCommCodeListStrNoAllOption(Map<String, String> commonCodeList) throws Exception {

		StringBuilder codeTaglibStr = new StringBuilder(StringUtils.EMPTY);

		codeTaglibStr.append("");
		codeTaglibStr.append(CommonConstants.COLONE);
		codeTaglibStr.append("선택");
		codeTaglibStr.append(CommonConstants.SEMI_COLONE);

		for( String code : commonCodeList.keySet() ) {
			codeTaglibStr.append(code);
			codeTaglibStr.append(CommonConstants.COLONE);
			codeTaglibStr.append(commonCodeList.get(code));
			codeTaglibStr.append(CommonConstants.SEMI_COLONE);
		}

		return codeTaglibStr.toString();
	}

	@Override
	public List<CommonCodeVO> selectInqrySeDetailCode(String inqrySeCode) throws Exception {
		return csMapper.selectInqrySeDetailCode(inqrySeCode);
	}

	@Override
	public List<CsMemberVO> selectMemberList(CommonVO vo) throws Exception {
		List<CsMemberVO> memberList = csMapper.selectMemberList(vo);

		for (CsMemberVO csMemberVO : memberList) {
			if(StringUtils.isNotBlank(csMemberVO.getMoblphonNo())) {
				csMemberVO.setMoblphonNo(CryptoUtil.decryptAES256(csMemberVO.getMoblphonNo()).replace("-", ""));	//복호화
			}
		}

		return memberList;
	}

	@Override
	public int selectMemberTotalCount(CommonVO vo) throws Exception {
		return csMapper.selectMemberTotalCount(vo);
	}

	private void sendMessageToCustomer(CsInquiryVO answerData) throws Exception {
		Map<String, String> mailData = new HashMap<>();
		Map<String, String> smsData = new HashMap<>();
		CsInquiryVO inqryData = csMapper.selectInquiry(answerData.getParntsInqryAnswerSn());

		if(StringUtils.isNotBlank(inqryData.getInqryTelno())) {
			inqryData.setInqryTelno(CryptoUtil.decryptAES256(inqryData.getInqryTelno()).replace("-", ""));	//복호화
		}

		LocalDateTime inqryDt = inqryData.getInqryAnswerDt().toLocalDateTime();
		String inqryYear = Integer.toString(inqryDt.getYear());
		String inqryMonth = Integer.toString(inqryDt.getMonthValue());
		String inqryDay = Integer.toString(inqryDt.getDayOfMonth());

		mailData.put("inqryYear", inqryYear);
		mailData.put("inqryMonth", inqryMonth);
		mailData.put("inqryDay", inqryDay);
		mailData.put("inqryCn", inqryData.getInqryAnswerCn());
		mailData.put("answerCn", answerData.getInqryAnswerCn());
		mailData.put("Servicedomain", "https://www.kztraders.com");

		MailVO mailVo = new MailVO();
		mailVo.setMailTmptSeq(14);
		mailVo.setMailSendUserId("SYSTEM");
		mailVo.setEmail(inqryData.getInqryEmail());
		mailVo.setMailSendEmail(csMapper.getSntoEmail(14));

		mailService.insertMailSend(mailVo, mailData);

		SMSVO smsVo = new SMSVO();
		smsVo.setPhone(inqryData.getInqryTelno());
		smsVo.setMberNo(inqryData.getInqryAnswerMberNo());
		smsVo.setMberKndSeCode(inqryData.getMberSeCode());
		smsVo.setCommerceNtcnAt("Y");

		smsData.put("templateNum", "14");
		smsData.put("questionDate", inqryYear + "년 " + inqryMonth + "월 " + inqryDay +"일");
		smsData.put("questionSubject", inqryData.getInqryAnswerCn());
		smsData.put("answerDetail", answerData.getInqryAnswerCn());
		smsData.put("Servicedomain", "https://www.kztraders.com");
		smsData.put("commerceNtcnCn", "[케이지트레이딩] 문의주신 내용에 대한 답변이 등록되었습니다.");

		smsService.insertSMS(smsVo, smsData);

		if(StringUtils.isNotEmpty(inqryData.getDeviceId())){
			AppPushQueueVO pushVo = new AppPushQueueVO();

			pushVo.setCallback(inqryData.getInqryTelno());
			pushVo.setMberNo(inqryData.getInqryAnswerMberNo());
			pushVo.setIdentify(inqryData.getDeviceId());
			pushVo.setMsgTitle("[케이지트레이딩] 답글 등록 알림");
			pushVo.setType("0");	//주문 후 process
			pushVo.setUrl("https://m.kztraders.com/my/alarm/alarmList");	// push 메세지를 눌렀을 때, mapping되는 url

			smsService.insertAppPush(pushVo, smsData);
		}

	}

	@Override
	public List<DlvyProgrsDtlsVO> selectDlvyProgrsDtlsList(DlvyProgrsDtlsVO paramVo) throws Exception {

		List<DlvyProgrsDtlsVO> selectDlvyProgrsDtlsList = new ArrayList<DlvyProgrsDtlsVO>(); //csMapper.selectDlvyProgrsDtlsList(paramVo);

		if (!CollectionUtils.isEmpty(selectDlvyProgrsDtlsList)) {
			selectDlvyProgrsDtlsList.stream().forEach(vo -> {
				// OR_ORDER_BAS(주문_주문 기본)-ORDRR_MOBLPHON_NO(주문자 휴대폰 번호) 복호화
				try {
					if (StringUtils.isNotEmpty(vo.getOrdrrMoblphonNo())) {
						log.debug("주문자 전화번호1 전 ==================>" + vo.getOrdrrMoblphonNo());
						String orderMoblphonNo = CryptoUtil.decryptAES256(vo.getOrdrrMoblphonNo());
						log.debug("주문자 전화번호1 후 ==================>" + orderMoblphonNo);
						/** 주문자 휴대폰 번호 번호 셋팅 **/
						vo.setOrdrrMoblphonNo(StringUtil.formatPhone(orderMoblphonNo));
					}
				} catch(Exception e) {
					log.error("CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
			});
		}

		return selectDlvyProgrsDtlsList;
	}

	@Override
	public int selectDlvyProgrsDtlsPagingTotalCount(DlvyProgrsDtlsVO vo) throws Exception {
		return 0; //csMapper.selectDlvyProgrsDtlsPagingTotalCount(vo);
	}

	@Override
	public List<BlInfoVO> selectBlInfo(String orderNo) throws Exception {
		return csMapper.selectBlInfo(orderNo);
	}

	@Override
	public List<VhcleInfoVO> selectVhcleInfoList(String orderNo) throws Exception {
		List<VhcleInfoVO> vhcleInfoVOList = new ArrayList<VhcleInfoVO>(); //csMapper.selectVhcleInfoList(orderNo);

		if (!CollectionUtils.isEmpty(vhcleInfoVOList)) {
			for (VhcleInfoVO vo : vhcleInfoVOList) {
				if (StringUtils.isNotBlank(vo.getDrverTlphonNo())) {
					String drverTlphonNo = StringUtil.formatPhone(CryptoUtil.decryptAES256(vo.getDrverTlphonNo()));
					vo.setDrverTlphonNo(drverTlphonNo); // 복호화
				}
			}
		}

		return vhcleInfoVOList;
	}

	@Override
	public void insertAndUpdateVhcleInfoList(VhcleInfoVO2 vhcleInfoVO2) throws Exception {
		Account account = userInfoUtil.getAccountInfo();

		//가져온 차량정보 리스트
		List<VhcleInfoVO> newVhclList = vhcleInfoVO2.getVhcleInfoList();

		int updateCnt = 0;

		for (VhcleInfoVO newVhcleVo : newVhclList) { // 입력된 차량정보

			if (!(StringUtils.equals("Y", newVhcleVo.getDeleteAt()) && StringUtils.equals("new", newVhcleVo.getMode()))) {
				if (StringUtils.isNotBlank(newVhcleVo.getDrverTlphonNo())) {
					// 휴대전화 번호 하이픈 제거 후 암호화
					newVhcleVo.setDrverTlphonNo(CryptoUtil.encryptAES256(newVhcleVo.getDrverTlphonNo().replace("-", ""))); // 암호화
				}
				newVhcleVo.setMberId(account.getId());

				//csMapper.insertVhcleInfoList(newVhcleVo);
				// 주문_차량 정보 기본 이력 등록
				//csMapper.insertVhcleInfoHst(newVhcleVo);
				
				updateCnt++;
			}
		} // end for

		// 차량정보 등록 및 수정 고객 SMS
		if (updateCnt > 0) {
			sendMessageToCustomerForVhcleInfoVO(vhcleInfoVO2.getVhcleInfoList(), "50");
		}
		// 배송기사 SMS 발송
		sendMessageToDriver(vhcleInfoVO2.getVhcleInfoList(), "107");

		// 메모 머지 비교 후 업데이트
		// csMapper.updateOrderMemo(vhcleInfoVO2);

		Map<String, Object> resObj = null;
		try {
			// 자차 자량정보 등록 및 수정 api
			// FO/BO 호출 구분 (1:FO, 2:BO

			resObj = httpClientHelper.postCallApi(apiDomain + "/sendDlvyVhcleInfo/2", vhcleInfoVO2.getVhcleInfoList());

			if (resObj.isEmpty()) {
					throw new Exception("통신장애");
				}
		} catch (Exception e) {
			log.error("자량정보 등록 및 수정 api resObj :::   + resObj");
				log.error("차량정보 API 실패 ===> ", e.getMessage());

				// 자차 자량정보 등록 및 수정 api 오류 SM
				if (!newVhclList.isEmpty()) {
					callSms(newVhclList.get(0));
				}
		}
	}

	@Override
	public int updateOrderVhcleInfoRegistAt(VhcleInfoVO vo) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		if (account == null || StringUtils.isBlank(account.getId())) {
			throw new Exception("로그인 정보를 확인해주세요.");
		}
		vo.setMberId(account.getId());

		int result = csMapper.updateOrderVhcleInfoRegistAt(vo);
		//csMapper.insertOrderVhcleInfoRegistAtHst(vo);
		commonService.insertTableHistory("OR_ORDER_BAS", vo);
		return result;
	}

	/**
	 * 템플릿에 따라 SMS 전송 처리.
	 */
	private void procSms(VhcleInfoVO vhcleInfoVO, String templateNum, String addStr) {
		log.debug("[CsServiceImpl][procSms] IN");

		try {
			Map<String, String> smsMap = null;

			switch (templateNum) {
				case "49":
					smsMap = new HashMap<String, String>();
					smsMap.put("orderNo", vhcleInfoVO.getOrderNo()); // 주문번호
					smsMap.put("returnMsg", addStr); // 자차 자량정보 등록 및 수정 api시 오류발생
					break;
			}

			smsMap.put("templateNum", templateNum);

			smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
			smsService.insertSMS(null, smsMap);
		} catch (Exception e) {
			log.error("[CsServiceImpl][procSms] " + ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 * 고객 대상 메세지 발송 메소드
	 */
	private void sendMessageToCustomerForVhcleInfoVO(List<VhcleInfoVO> vhcleInfoArr, String templateNum) throws Exception {
		log.debug("[CsServiceImpl][sendMessageToCustomer] IN");
		try {
			SMSVO smsVO = new SMSVO();
//			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
//
//			Map<String, String> smsMap = null;
//			VhcleInfoVO vo = null;
//			String smsList = "";
//
//			for(VhcleInfoVO voInfoVO : vhcleInfoArr) {
//				smsList += voInfoVO.getDlvyOdr() + "회차";
//				if(!String.valueOf(voInfoVO.getDlvyOdr()).isEmpty() && !voInfoVO.getVhcleWrhousngDe().isEmpty() && !voInfoVO.getDrverNm().isEmpty() && !voInfoVO.getVhcleNo().isEmpty() && !voInfoVO.getDrverTlphonNo().isEmpty()) {
//					smsList += "(차량입고일: " + voInfoVO.getVhcleWrhousngDe() + ")" + "\n"
//							+	voInfoVO.getDrverNm() + "-" + voInfoVO.getVhcleNo() + " (" + StringUtil.formatPhone(CryptoUtil.decryptAES256(voInfoVO.getDrverTlphonNo())) + ")" + "\n" + "\n";
//				}else {
//					smsList += "(미등록)" + "\n" + "\n";
//				}
//				vo = voInfoVO;
//			}
//
//			// 자차 자량정보 등록 및 수정 고객 SMS 전송 수신자
//			String phone = csMapper.selectSmsUserInfo(vo);
//
//			// ORDRR_MOBLPHON_NO(주문자 휴대폰 번호) 복호화
//			String ordrrMoblphonNo = String.valueOf(phone);
//			if(StringUtils.isNotEmpty(ordrrMoblphonNo)) {
//				try {
//					log.debug("주문자 휴대폰 번호 복호화 전 ==================>" + ordrrMoblphonNo);
//					ordrrMoblphonNo = CryptoUtil.decryptAES256(ordrrMoblphonNo);
//					log.debug("주문자 휴대폰 번호 복호화 후 ==================>" + ordrrMoblphonNo);
//					/** 주문자 휴대폰 번호 셋팅 **/
//					phone = ordrrMoblphonNo;
//				} catch (Exception e) {
//					log.error("CsServiceImpl sendMessageToCustomer ORDRR_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
//				}
//			}
//			smsVO.setPhone(phone);
//			smsVO.setCommerceNtcnAt("N"); // 커머스 알림 여부
//
//			switch(templateNum) {
//			case "50" :
//				smsMap = csMapper.selectSmsInfo(vo);
//				smsMap.put("smsList", smsList);
//
//				break;
//			}
//
//			smsMap.put("templateNum", templateNum);
//
//			log.debug(">> smsMap toString : " + smsMap.toString());
//
//			smsService.insertSMS(smsVO, smsMap);

		} catch (Exception e) {
			log.error("[CsServiceImpl][sendMessageToCustomer] " + ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 * 배송기사 대상 메세지 발송 메소드
	 */
	private void sendMessageToDriver(List<VhcleInfoVO> vhcleInfoArr, String templateNum) throws Exception {
		log.warn("[OrderDtlsDetailServiceImpl][sendMessageToDriver] IN");
		try {
			for(VhcleInfoVO voInfoVO : vhcleInfoArr) {
				SMSVO smsVO = new SMSVO();
				smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
				smsVO.setCommerceNtcnAt("N"); // 커머스 알림 여부

				VhcleInfoVO vo = null;
				Map<String, String> smsMap = new HashMap<>();

				String status = "";
				String prevPhoneNo = "";

				String newSmsList = "";
				String prevSmsList = "";

				//내부사용자 전송용 메시지 내용 별도로 세팅
				String innerDepartmentSmsList = "";

				if(voInfoVO.getMode().equals("new")) {
					status = "등록";
				}else if(voInfoVO.getMode().equals("saved")) {
					if(voInfoVO.getDeleteAt().equals("Y")) {
						status = "삭제";
					}else if(voInfoVO.getDeleteAt().equals("N")) {
//						VhcleInfoVO vhclHist = csMapper.selectOrVhcleInfoHst(voInfoVO);
//						
//						//기저장되어있는 휴대폰 번호 하이픈 제거 후 재복호화
//						vhclHist.setDrverTlphonNo(CryptoUtil.encryptAES256(CryptoUtil.decryptAES256(vhclHist.getDrverTlphonNo()).replace("-", "")));
//						
//						//배송완료된 차수 정보 문자 전송 제외
//						if(vhclHist != null && vhclHist.getDlvyProgrsSttusCode() < 30
//								&& (!vhclHist.getDrverNm().equals(voInfoVO.getDrverNm())
//								|| !vhclHist.getDrverTlphonNo().equals(voInfoVO.getDrverTlphonNo())
//								|| !vhclHist.getVhcleNo().equals(voInfoVO.getVhcleNo())
//								|| !vhclHist.getVhcleWrhousngDe().equals(voInfoVO.getVhcleWrhousngDe()))) {//배송정보 변경된 경우
//							status = "변경";
//
//							//변경전 폰번호
//							prevPhoneNo = vhclHist.getDrverTlphonNo();
//
//							//변경전 차량등록정보
//							prevSmsList += vhclHist.getDlvyOdr() + "회차";
//							prevSmsList += "(차량입고일: " + vhclHist.getVhcleWrhousngDe() + ")" + "\n"
//										+	vhclHist.getDrverNm() + "-" + vhclHist.getVhcleNo() + " (" + StringUtil.formatPhone(CryptoUtil.decryptAES256(vhclHist.getDrverTlphonNo())) + ")" + "\n" + "\n";
//						}else {
//							continue;
//						}
					}
				}
				//변경된 차량등록정보
				newSmsList += voInfoVO.getDlvyOdr() + "회차";
				newSmsList += "(차량입고일: " + voInfoVO.getVhcleWrhousngDe() + ")" + "\n"
						   +	voInfoVO.getDrverNm() + "-" + voInfoVO.getVhcleNo() + " (" + StringUtil.formatPhone(CryptoUtil.decryptAES256(voInfoVO.getDrverTlphonNo())) + ")" + "\n" + "\n";

				vo = voInfoVO;

				String phoneNo = String.valueOf(voInfoVO.getDrverTlphonNo());
				if(StringUtils.isNotEmpty(phoneNo)) {
					try {
						phoneNo = CryptoUtil.decryptAES256(phoneNo);
						voInfoVO.setDrverTlphonNo((phoneNo));
						if(StringUtils.isNotEmpty(prevPhoneNo)) prevPhoneNo = CryptoUtil.decryptAES256(prevPhoneNo);
					} catch (Exception e) {
						log.error("OrderDtlsDetailServiceImpl sendMessageToDriver DRVER_TLPHON_NO CryptoUtil.decryptAES256 ERROR " + ExceptionUtils.getStackTrace(e));
					}
				}

//				smsMap = csMapper.selectDriverSmsInfo(vo);
//				smsMap.put("templateNum", templateNum);
//				smsMap.put("excpSndngOptnAt", "N"); // 예외 발송 옵션 여부, N일 경우 SMS 수신자만 발송한다.
//
//				//배송기사 메시지 전송
//				if(status.equals("변경")) {
//					if(StringUtils.isNotEmpty(prevPhoneNo)) {
//						smsMap.put("smsList", prevSmsList);
//						smsMap.put("status", "삭제");
//						smsVO.setPhone(prevPhoneNo);
//
//						log.debug(">> smsMap toString : " + smsMap.toString());
//						smsService.insertSMS(smsVO, smsMap);
//					}
//
//					if(StringUtils.isNotEmpty(voInfoVO.getDrverTlphonNo())) {
//						smsVO = new SMSVO();
//						smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
//						smsVO.setCommerceNtcnAt("N");
//
//						smsMap.put("smsList", newSmsList);
//						smsMap.put("status", "등록");
//						smsVO.setPhone(voInfoVO.getDrverTlphonNo());
//
//						log.debug(">> smsMap toString : " + smsMap.toString());
//						smsService.insertSMS(smsVO, smsMap);
//					}
//
//					innerDepartmentSmsList = StringUtils.removeEnd(prevSmsList, "\n") + "[변경]" + "\n" + newSmsList;
//				}else {
//					if(StringUtils.isNotEmpty(voInfoVO.getDrverTlphonNo())) {
//						smsMap.put("smsList", newSmsList);
//						smsMap.put("status", status);
//						smsVO.setPhone(voInfoVO.getDrverTlphonNo());
//
//						log.debug(">> smsMap toString : " + smsMap.toString());
//						smsService.insertSMS(smsVO, smsMap);
//					}
//
//					innerDepartmentSmsList = newSmsList;
//				}
//
//				// 내부사용자 별도 전송
//				smsMap.put("smsList", innerDepartmentSmsList);
//				smsMap.put("status", status);
//				smsMap.put("commerceNtcnAt", "N"); // 추가 수신사 커머스 알림 여부 따로 설정
//				smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
//				smsService.insertSMS(null, smsMap);
			}
		} catch (Exception e) {
			log.error("[OrderDtlsDetailServiceImpl][sendMessageToDriver] " + ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 * SMS 서비스를 호출
	 */
	private synchronized void callSms(VhcleInfoVO vhcleInfoVO) {
		log.debug("[CsServiceImpl][callSms] IN");
		// 템플릿에 따라 SMS 전송을 처리한다.
		procSms(vhcleInfoVO, "49", "자차 자량정보 등록 및 수정 api 실패");
	}

	@Override
	public List<CommonCodeVO> selectVhcleGroupCodeList(DlvyProgrsDtlsVO vo) throws Exception {
		return csMapper.selectVhcleGroupCodeList(vo);
	}

	@Override
	public Object checkHolidayYn(VhcleInfoVO vhcleInfoVO) throws Exception {
		return csMapper.checkHolidayYn(vhcleInfoVO);
	}

	/**
	 * 기준일자, 일수를 받아 계산된 영업일과 날짜변경가능여부를 리턴
		yn : 변경 가능여부
	 	returnDe : 고객이 변경하려는 출고요청일 기준으로 계산한 예상 결제예정일
	 				- 담보보증 : 변경출고요청일(미포함) + 담보상환기간
				    - 증거금  : 변경출고요청일 -1 (바로 이전 영업일)
	 */
	@Override
	public Map<String, Object> getSettleSttusDe(VhcleInfoVO vhcleInfoVO) throws Exception {
		Map<String, Object> map = new HashMap<>();
		boolean result = false;	//변경 결제예정일이 현재보다 뒤 여야 true

		String strToday = DateUtil.getNowDate();
		vhcleInfoVO.setDlvyOdr(csMapper.selectDayCntBySetleMthd(vhcleInfoVO)); 	//반환날짜 계산을 위한 계산일수 조회
		String bsnDe = csMapper.getSettleSttusDe(vhcleInfoVO); 			 		//계산된 반환날짜 = 변경될 결제예정일
		log.debug("변경예정 결제일 >>> " + bsnDe);

        int compare = DateUtil.compareToCalerdar(bsnDe, strToday);
		if(compare > 0) { //결제예정일(예상) > 현재
			result = true;
		}

		map.put("yn", result);
        map.put("returnDe", bsnDe);

		return map;
	}

	/* CS관리 > 배송관리 > 배송진행내역조회 > 상세 (팝업) > 등록된 차량 정보 확인 */
	@Override
	public Map<String, Object> selectDlvyInfo(DlvyInfoVO vo) throws Exception {
		try {
			Map<String, Object> map = new HashMap<>();
			String result = "";
			String orderNo = vo.getOrderNo();
//			/** 주문번호, 현재 등록된 차량 수(OR_VHCLE_INFO_BAS), 배송차수(ODOB.DLVY_ODR 데이터 없을 경우 =총 실제 주문 중량 / 25 ) */
//			DlvyInfoVO dlvyInfoVO = csMapper.selectDlvyInfo(vo);
//			/* 등록된 차량 목록 */
//			List<VhcleInfoVO> vhcleInfoVOList = csMapper.selectVhcleInfoList(orderNo);
			/** 등록하려는 차량 수 */
			int existDlvyOdr = vo.getExistDlvyOdr();
//			/** 등록된 차량 수 */
//			int dlvyOdr = vhcleInfoVOList.size();
//			/** 최대 등록가능한 차량 수 */
//			int totDlvyOdr = dlvyInfoVO.getTotDlvyOdr();

//			if (existDlvyOdr >= totDlvyOdr || dlvyOdr >= totDlvyOdr) {
//				result = "fail";
//			} else {
//				result = "Success";
//			}
	        map.put("result", result);
			return map;
		} catch (Exception e) {
			log.error("[CsServiceImpl][selectDlvyInfo] " + ExceptionUtils.getStackTrace(e));
			Map<String, Object> map = new HashMap<>();
			map.put("result", "error");
			return map;
		}
	}

	/**
	 * 알림톡 템플릿 목록을 조회한다.
	 */
	@Override
	public DlvyProgrsDtlsVO selectAlimTmplatList(DlvyProgrsDtlsVO dlvyProgrsDtlsVO) throws Exception {
		return csMapper.selectAlimTmplatList(dlvyProgrsDtlsVO);

	}


	/**
	 * 알림톡을 발송한다.
	 */
	@Override
	public Map<String, Object> sendAlim(DlvyProgrsDtlsVO dlvyProgrsDtlsVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		try {

			SMSVO smsVO = new SMSVO();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));

			String ordrrMoblphonNo = dlvyProgrsDtlsVO.getOrdrrMoblphonNo();
			smsVO.setPhone(ordrrMoblphonNo);

			Map<String, String> smsMap = new HashMap<String, String>();

			smsMap.put("orderNo", dlvyProgrsDtlsVO.getOrderNo());
			smsMap.put("orderDate", dlvyProgrsDtlsVO.getOrderDe());
			smsMap.put("vhcleURL", vhcleRegistUrl+"/vhcleInfoRegist/selectVhcleInfoRegist?orderNo="+dlvyProgrsDtlsVO.getOrderNo());
			smsMap.put("templateNum", String.valueOf(dlvyProgrsDtlsVO.getTmplatNo()));
			smsMap.put("excpSndngOptnAt", "N"); // 예외 발송 옵션 여부, N일 경우 SMS 수신자만 발송한다.
			String mssageSndngHistNo = smsService.insertSMSByReturnMssageSndngHistNo(smsVO, smsMap);


			//내부 사용자 그룹에게도 SMS전송한다.
			 smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
			 smsService.insertSMS(null, smsMap);

			/* 주문_미납 주문 관리 기본 테이블 등록 (20: 이메일, 30: SMS, 90: 알림톡) */
			Map<String, String> npyOrderManageMap = new HashMap<String, String>();
			npyOrderManageMap.put("orderNo", dlvyProgrsDtlsVO.getOrderNo());						// 주문 번호
			npyOrderManageMap.put("npyProcessTyCode", "90");		// 미납 처리 유형 코드
			npyOrderManageMap.put("mssageSndngHistNo", mssageSndngHistNo);   	// 메시지 발송 이력 번호
			npyOrderManageMap.put("emailSndngHistNo", "0");    	// 이메일 발송 이력 번호
			npyOrderManageMap.put("ordrrNm", dlvyProgrsDtlsVO.getOrdrrNm());             			// 주문자 명
			npyOrderManageMap.put("moblphonNo", ordrrMoblphonNo);          	// 주문자 휴대폰 번호
			npyOrderManageMap.put("ordrrEmail", null);          		// 주문자 이메일
			npyOrderManageMap.put("userId", "SYSTEM");          							// CS 담당자 ID
			npyOrderManageMap.put("processCn", null);           			// 처리 내용

			cdtlnMessageService.insertNpyOrderManage(npyOrderManageMap);

			returnMap.put("result", true);
			returnMap.put("message", "알림톡 발송을 성공했습니다.");



		 }catch(Exception e) {
			 log.debug(e.getMessage());
			 returnMap.put("result", false);
			 returnMap.put("message", "알림톡 발송을 실패했습니다.");
		 }

		return returnMap;
	}

	/**
	 * 차량정보 안내 알림톡을 발송한다.
	 */
	@Override
	public Map<String, Object> sendVhcleInfoAlim(DlvyProgrsDtlsVO dlvyProgrsDtlsVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		try {

			SMSVO smsVO = new SMSVO();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));

			String ordrrMoblphonNo = dlvyProgrsDtlsVO.getOrdrrMoblphonNo();
			smsVO.setPhone(ordrrMoblphonNo);

			Map<String, String> smsMap = new HashMap<String, String>();

			smsMap.put("orderNo", dlvyProgrsDtlsVO.getOrderNo());
			smsMap.put("orderDe", dlvyProgrsDtlsVO.getOrderDe());

			// 모든 등록 차량 조회
			DlvyDtlsVO dlvyDtlsVO = new DlvyDtlsVO();
			dlvyDtlsVO.setOrderNo(dlvyProgrsDtlsVO.getOrderNo());
			List<VhcleInfoVO> list = dlvyDtlsInqireMapper.selectVhcleInfoList(dlvyDtlsVO);
			StringBuilder vhcleInfo = new StringBuilder();
			if (!CollectionUtils.isEmpty(list)) {
				for (VhcleInfoVO vo : list) {
					if (StringUtils.isBlank(vo.getDrverTlphonNo())) continue;

					String drverTlpphonNo = CryptoUtil.decryptAES256(vo.getDrverTlphonNo());
					vo.setDrverTlphonNo(StringUtil.formatPhone(drverTlpphonNo)); // 복호화

					vhcleInfo.append("출고번들수 : ").append(vo.getOdrBundleQy()).append("\n");
					vhcleInfo.append("차량입고일 : ").append(vo.getVhcleWrhousngDe()).append("\n");
					vhcleInfo.append("차량번호 : ").append(vo.getVhcleNo()).append("\n");
					vhcleInfo.append("기사정보 : ").append(vo.getDrverNm()).append(" ").append(drverTlpphonNo).append("\n\n");
				}
			}
			smsMap.put("vhcleInfo", String.valueOf(vhcleInfo));
			smsMap.put("templateNum", String.valueOf(dlvyProgrsDtlsVO.getTmplatNo()));
			smsMap.put("excpSndngOptnAt", "N"); // 예외 발송 옵션 여부, N일 경우 SMS 수신자만 발송한다. Y일 경우 내부사용자만 발송한다.
			//고객 발송
			smsService.insertSMS(smsVO, smsMap);

			//내부 사용자 그룹 SMS전송
			smsMap.put("excpSndngOptnAt", "Y");// 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
			smsService.insertSMS(null, smsMap);

			returnMap.put("result", true);
			returnMap.put("message", "알림톡 발송을 성공했습니다.");

		}catch(Exception e) {
			log.debug(e.getMessage());
			returnMap.put("result", false);
			returnMap.put("message", "알림톡 발송을 실패했습니다.");
		}

		return returnMap;
	}

	/**
	 * 차량 등록 알림톡 발송 이력 데이터를 조회한다.
	 */
	@Override
	public List<ArrrgTrgterVO> selectVhcleAlimList(DlvyProgrsDtlsVO dlvyProgrsDtlsVO) throws Exception {

		List<ArrrgTrgterVO> vhcleAlimList = csMapper.selectVhcleAlimList(dlvyProgrsDtlsVO);
		if (!CollectionUtils.isEmpty(vhcleAlimList)) {
			vhcleAlimList.stream().forEach(vo -> {
				//ORDRR_MOBLPHON_NO(주문자 휴대폰 번호) 복호화
				try {
					if (StringUtils.isNotEmpty(vo.getOrdrrMoblphonNo())) {
						log.debug("주문자 전화번호2 전 ==================>" + vo.getOrdrrMoblphonNo());
						String orderMoblphonNo = CryptoUtil.decryptAES256(vo.getOrdrrMoblphonNo());
						log.debug("주문자 전화번호2 후 ==================>" + orderMoblphonNo);
						/** 주문자 휴대폰 번호 번호 셋팅 **/
						vo.setOrdrrMoblphonNo(StringUtil.formatPhone(orderMoblphonNo));
					}
				} catch(Exception e) {
					log.error("CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
			});
		}

		return vhcleAlimList;
	}

	/**
	 * 금일 날짜 조회
	 */
	@Override
	public String thisDate() throws Exception {
		
		// 현재 날짜를 구함
		LocalDate today = LocalDate.now();
		
		return today.toString();
	}



}