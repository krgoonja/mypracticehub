package com.sorincorp.bo.ev.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.ev.mapper.CouponPolicyMapper;
import com.sorincorp.bo.ev.model.CouponPolicyVO;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CouponPolicyServiceImpl implements CouponPolicyService {

	@Autowired
	private CouponPolicyMapper couponPolicyMapper;

	@Autowired
	private UserInfoUtil userInfoUtil;

	/** 공통 채번 서비스 */
	@Autowired
	private AssignService assignService;

	@Autowired
	private CommonService commonService;

	@Override
	public List<CouponPolicyVO> getCouponPolicyList(CouponPolicyVO couponPolicyVO) throws Exception {
		List<CouponPolicyVO> list = new ArrayList<CouponPolicyVO>();

		try {
			list = couponPolicyMapper.getCouponPolicyList(couponPolicyVO);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return list;
	}

	@Override
	public Integer getCouponPolicyListTotCnt(CouponPolicyVO couponPolicyVO) throws Exception {

		return couponPolicyMapper.getCouponPolicyListTotCnt(couponPolicyVO);
	}
	
	@Override
	public CouponPolicyVO getTotalCouponPolicyList(CouponPolicyVO couponPolicyVO) throws Exception {

		return couponPolicyMapper.getTotalCouponPolicyList(couponPolicyVO); 
	}

	@Override
	public List<CouponPolicyVO> getCouponPolicyExcelList(CouponPolicyVO couponPolicyVO) throws Exception {
		return couponPolicyMapper.getCouponPolicyExcelList(couponPolicyVO);

	}

	//쿠폰 정책 생성
	@Override
	public boolean insertAndUpdateCouponPolicy(CouponPolicyVO couponPolicyVO) throws Exception {
		boolean result;
		
		try {
			if(couponPolicyVO.getIsuLmttAmount() != null) {
				couponPolicyVO.setIsuLmttAmount(couponPolicyVO.getIsuLmttAmount().replaceAll("[^0-9]", ""));
			}else if(couponPolicyVO.getIsuLmttQuantity() != null){
				couponPolicyVO.setIsuLmttQuantity(couponPolicyVO.getIsuLmttQuantity().replaceAll("[^0-9]", ""));
			}
			
			if (couponPolicyVO.getState().equals("N")) {
				//데이터 변경 없음
			} else if (couponPolicyVO.getState().equals("U")) {
				//데이터 수정
				couponPolicyVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
				couponPolicyMapper.updateCouponPolicy(couponPolicyVO);
			} else if (couponPolicyVO.getState().equals("I")) {
				//데이터 생성
				couponPolicyVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
				//쿠폰 번호 채번 규칙
				//YYYYMMDD-P00001
				couponPolicyVO.setCouponNo(DateUtil.getNowDate() + "-P" + assignService.selectAssignValue("CP", "COUPON_NO", DateUtil.calDate("yyyy"), couponPolicyVO.getFrstRegisterId(), 5));
				couponPolicyMapper.insertCouponPolicy(couponPolicyVO);
			}
			result = commonService.insertTableHistory("CP_COUPON_INFO_BAS", couponPolicyVO);

		} catch (Exception e) {
			log.info("[CouponServiceImpl.insertCouponPolicy Error]" + e.getMessage());
			result = false;
			// TODO: handle exception
		}
		return result;
	}

	//쿠폰 정책 삭제
	@Override
	public Map<String, Integer> deleteChkCouponPolicy(CouponPolicyVO couponPolicyVO) throws Exception {
		Map<String, Integer> returnData = new HashMap<String, Integer>();
		int chkPromntCnt;
		int chkCouponUseCnt;
		try {
			chkPromntCnt = couponPolicyMapper.getChkPromnt(couponPolicyVO);
			if (chkPromntCnt > 0) {
				returnData.put("chkPromntCnt", chkPromntCnt);
				chkCouponUseCnt = couponPolicyMapper.chkCouponUse(couponPolicyVO);
				if (chkCouponUseCnt > 0) {
					returnData.put("chkCouponUseCnt", chkCouponUseCnt);
					//					return returnData;
				}
			} else {
				returnData.put("chkPromntCnt", chkPromntCnt);
			}
			//			return returnData;
		} catch (Exception e) {
			log.info("[CouponServiceImpl.deleteChkCouponPolicy Error] " + e.getMessage());
		}
		return returnData;
	}

	@Override
	public boolean deleteCouponPolicy(CouponPolicyVO couponPolicyVO) throws Exception {
		boolean result;
		try {
			couponPolicyMapper.deleteCouponPolicy(couponPolicyVO);
			result = commonService.insertTableHistory("CP_COUPON_INFO_BAS", couponPolicyVO);
		} catch (Exception e) {
			// TODO: handle exception
			log.info("[CouponServiceImpl.deleteCouponPolicy Error]" + e.getMessage());
			result = false;
		}
		return result;
	}

	@Override
	public CouponPolicyVO getCouponPolicyDtl(CouponPolicyVO couponPolicyVO) throws Exception {
		return couponPolicyMapper.getCouponPolicyDtl(couponPolicyVO);
	}

	@Override
	public List<CouponPolicyVO> getCouponDtlIsuList(CouponPolicyVO couponPolicyVO) throws Exception {
		List<CouponPolicyVO> list = new ArrayList<CouponPolicyVO>();
		try {
			list = couponPolicyMapper.getCouponDtlIsuList(couponPolicyVO);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return list;
	}

	@Override
	public Integer getCouponDtlIsuListTotCnt(CouponPolicyVO couponPolicyVO) throws Exception {
		return couponPolicyMapper.getCouponDtlIsuListTotCnt(couponPolicyVO);
	}

	@Override
	public List<CouponPolicyVO> getCouponPolicyHstList(CouponPolicyVO couponPolicyVO) throws Exception {
		List<CouponPolicyVO> list = new ArrayList<CouponPolicyVO>();
		try {
			list = couponPolicyMapper.getCouponPolicyHstList(couponPolicyVO);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return list;
	}

	@Override
	public Integer getCouponPolicyHstListCnt(CouponPolicyVO couponPolicyVO) throws Exception {
		return couponPolicyMapper.getCouponPolicyHstListCnt(couponPolicyVO);
	}

	@Override
	public Map<String, Object> getChkCouponPolicy(CouponPolicyVO couponPolicyVO) throws Exception {
		Map<String, Object> returnData = new HashMap<String, Object>();
		CouponPolicyVO returnVo = new CouponPolicyVO();
		int chkPromntCnt;
		try {
			chkPromntCnt = couponPolicyMapper.getChkPromnt(couponPolicyVO);
			//해당 프로모션으로 생성된 쿠폰 정책이 유무 판단
			returnData.put("chkPromntCnt", chkPromntCnt);
			if (chkPromntCnt > 0) {
				//정책 존재 시 - 해당 정책으로 발행된 쿠폰 여부 확인
				returnVo = couponPolicyMapper.getChkCouponDtl(couponPolicyVO);
				returnData.put("chkCouponDtlDt", returnVo.getCouponBgnde());
			} 
		} catch (Exception e) {
			log.info("[CouponServiceImpl.getChkCouponPolicy Error] " + e.getMessage());
		}
		return returnData;
	}
	
	@Override
	public Integer getChkCouponUseCnt(CouponPolicyVO couponPolicyVO) throws Exception {
		return couponPolicyMapper.getChkCouponUseCnt(couponPolicyVO);
	}

	@Override
	public boolean deleteAllCoupon(CouponPolicyVO couponPolicyVO) throws Exception {
		boolean result = false;
		int getChkPromnt;
		int getChkDtl;
		List<CouponPolicyVO> reChkPoliyist = new ArrayList<>();
		List<CouponPolicyVO> reChkDtlList = new ArrayList<>();
		CouponPolicyVO reChkVo = new CouponPolicyVO();
		CouponPolicyVO reChkDtlVo = new CouponPolicyVO();
		try {
			getChkPromnt = couponPolicyMapper.getChkPromnt(couponPolicyVO);
			if(getChkPromnt>0) {
				reChkPoliyist = couponPolicyMapper.getReChkCouponPolicy(couponPolicyVO);
				for(int i = 0; i < reChkPoliyist.size() ; i++) {
					reChkVo = reChkPoliyist.get(i);
					couponPolicyMapper.deleteCouponPolicy(reChkVo);
					result = commonService.insertTableHistory("CP_COUPON_INFO_BAS", reChkVo);
					getChkDtl = couponPolicyMapper.getChkDtl(reChkVo);
					if(getChkDtl > 0){
						reChkDtlList = couponPolicyMapper.getCouponDtlList(reChkVo);
						for(int j = 0; j <reChkDtlList.size(); j++ ) {
							reChkDtlVo = reChkDtlList.get(j);
							couponPolicyMapper.deleteCouponDtl(reChkDtlVo);
							commonService.insertTableHistory("CP_COUPON_INFO_DTL", reChkDtlVo);
						}
					}
				}
			}else {
				result = true;
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			log.info("[CouponServiceImpl.deleteAllCoupon Error]" + e.getMessage());
			result = false;
		}
		return result;
	}
}