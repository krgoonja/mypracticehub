package com.sorincorp.bo.ev.service;

import java.util.List;

import com.sorincorp.bo.ev.model.CouponEntrpsAppnVO;

public interface CouponEntrpsAppnService {
	
	//로우수
	public int getCouponEntrpsAppnListTotcnt(CouponEntrpsAppnVO couponEntrpsAppnVO) throws Exception;
	
	//프로모션 목록 조회
	public List<CouponEntrpsAppnVO> getCouponEntrpsAppnList(CouponEntrpsAppnVO couponEntrpsAppnVO) throws Exception;
	
	public int insertCouponEntrps(List<CouponEntrpsAppnVO> CouponEntrpsAppnVO) throws Exception;
	
	public int deleteCouponEntrps(List<CouponEntrpsAppnVO> CouponEntrpsAppnVO) throws Exception;
}