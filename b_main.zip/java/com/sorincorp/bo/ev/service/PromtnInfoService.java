package com.sorincorp.bo.ev.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.bo.co.model.CmmnCodeVO;
import com.sorincorp.bo.ev.model.PromtnInfoVO;
import com.sorincorp.bo.ev.model.PromtnNewYearVO;
import com.sorincorp.comm.filedoc.model.FileDocVO;

public interface PromtnInfoService {

	public List<CmmnCodeVO> selectPromtnSeCodeList() throws Exception;

	//쿠폰 타입 리스트 조회
	public List<CmmnCodeVO> selectCouponTyCodeList() throws Exception;

	//프로모션 목록 조회
	public List<PromtnInfoVO> getPromtnInfoList(PromtnInfoVO promtnInfoVO) throws Exception;

	public int getPromtnInfoListTotcnt(PromtnInfoVO promtnInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 프로모션 정보를 조회한다.
	 * </pre>
	 * @date 2023. 03. 30.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 03. 30.			sein					최초작성
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return PromtnInfoVO
	 * @throws Exception
	 */
	public PromtnInfoVO selectPromtnInfo(PromtnInfoVO promtnInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 프로모션 추가및 수정한다.
	 * </pre>
	 * @date 2023. 03. 30.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 03. 30.			sein					최초작성
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return int
	 * @throws Exception
	 */
	public int insertAndUpdatePromtnInfo(PromtnInfoVO promtnInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 프로모션 정보를 삭제한다.
	 * </pre>
	 * @date 2023. 04. 03.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 04. 03.			sein					최초작성
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return
	 * @throws Exception
	 */
	public void deletePromtnInfo(PromtnInfoVO promtnInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 프로모션 시작,종료 썸네일 이미지파일을 조회한다.
	 * </pre>
	 * @date 2023. 03. 27.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 03. 27.		sein					최초작성
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return
	 * @throws Exception
	 */
	public Map<String, FileDocVO> selectBeginEndImage(PromtnInfoVO promtnInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 첨부파일을 등록한다.
	 * </pre>
     * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param mrequest
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> uploadFileDoc(MultipartHttpServletRequest mrequest) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 첨부파일을 삭제한다.
	 * </pre>
	 * @date 2023. 03. 27.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 03. 27.			sein					최초작성
	 * ------------------------------------------------
	 * @param fileVO
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> deleteFileDoc(FileDocVO fileVO) throws Exception;


	/**
	 * <pre>
	 * 처리내용: 복주머니 당첨자 목록을 조회한다.
	 * 		 : 복주머니 당첨자의 상품권 전송 여부 상태를 변경한다.
	 * </pre>
	 * @date 2024. 01. 29.
	 * @author cuko
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 29.		cuko				최초작성
	 * 2024. 01. 29.		hyunjin05			조회, 변경 추가
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return
	 * @throws Exception
	 */
	public List<PromtnNewYearVO> getPrizeWinnerList(PromtnNewYearVO vo) throws Exception;
	public int getPrizeWinnerListTotCnt(PromtnNewYearVO vo) throws Exception;
	public int insertUpateprizeWinnerListData(PromtnNewYearVO vo) throws Exception;
}
