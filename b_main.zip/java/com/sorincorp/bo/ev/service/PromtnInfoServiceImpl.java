package com.sorincorp.bo.ev.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.bo.co.model.CmmnCodeVO;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.bo.ev.mapper.PromtnInfoMapper;
import com.sorincorp.bo.ev.model.PromtnInfoVO;
import com.sorincorp.bo.ev.model.PromtnNewYearVO;
import com.sorincorp.bo.it.model.DisplayCtgryMgrVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PromtnInfoServiceImpl implements PromtnInfoService{

	@Autowired
	private PromtnInfoMapper promtnInfoMapper;

	@Autowired
	private FileDocService fileDocService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private CommonService commonService;

	@Override
	public List<CmmnCodeVO> selectPromtnSeCodeList() {
		return promtnInfoMapper.selectPromtnSeCodeList();
	}

	@Override
	public List<CmmnCodeVO> selectCouponTyCodeList() {
		return promtnInfoMapper.selectCouponTyCodeList();
	}
	
	@Override
	public List<PromtnInfoVO> getPromtnInfoList(PromtnInfoVO promtnInfoVO) {
		return promtnInfoMapper.getPromtnInfoList(promtnInfoVO);
	}

	@Override
	public int getPromtnInfoListTotcnt(PromtnInfoVO promtnInfoVO) {
		return promtnInfoMapper.getPromtnInfoListTotCnt(promtnInfoVO);
	}

	/**
	 *	프로모션 정보를 조회한다.
	 */
	@Override
	public PromtnInfoVO selectPromtnInfo(PromtnInfoVO promtnInfoVO) throws Exception {
		return promtnInfoMapper.selectPromtnInfo(promtnInfoVO);
	}

	/**
	 *	프로모션 등록 및 수정을 한다.
	 */
	@Override
	public int insertAndUpdatePromtnInfo(PromtnInfoVO promtnInfoVO) throws Exception {
		try {

		int result = 0;

		Account account = userInfoUtil.getAccountInfo();
		String userId ="";
		if(account != null) {
			userId = account.getId();
		}

		promtnInfoVO.setFrstRegisterId(userId);
		promtnInfoVO.setLastChangerId(userId);
		promtnInfoVO.setPromtnBeginDe(promtnInfoVO.getPromtnBeginDe().replaceAll("-", "")+"00"); //초 단위는 00 고정
		promtnInfoVO.setPromtnEndDe(promtnInfoVO.getPromtnEndDe().replaceAll("-", "")+"00");

		if( promtnInfoVO.getGridRowStatus().equals("insert")){
			promtnInfoMapper.insertPromtnInfo(promtnInfoVO);
			commonService.insertTableHistory("EV_PROMTN_INFO_BAS", promtnInfoVO);
		}else {

			promtnInfoMapper.updatePromtnInfo(promtnInfoVO);
			commonService.insertTableHistory("EV_PROMTN_INFO_BAS", promtnInfoVO);
		}

		return result;

		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 *	사용여부를 'N'로 업데이트 한다.
	 */
	@Override
	public void deletePromtnInfo(PromtnInfoVO promtnInfoVO) throws Exception {
		try {
			Account account = userInfoUtil.getAccountInfo();
			String userId ="";

			if(account != null) {
				userId = account.getId();
			}

			promtnInfoVO.setLastChangerId(userId);

			promtnInfoMapper.deletePromtnInfo(promtnInfoVO);
			commonService.insertTableHistory("EV_PROMTN_INFO_BAS", promtnInfoVO);

		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 *	프로모션 시작,종료 썸네일 이미지파일을 조회한다.
	 */
	@Override
	public Map<String, FileDocVO> selectBeginEndImage(PromtnInfoVO promtnInfoVO) throws Exception {
		try {
		Map<String, FileDocVO> filelist = new HashMap<>();

			if(promtnInfoVO.getModalPageStatus().equals("insert")) {
				return filelist;
			} else if(promtnInfoVO.getModalPageStatus().equals("update")) {
				FileDocVO beginImageFile;
				if(promtnInfoVO.getBeginThumbDocNo() != null) {
					beginImageFile = fileDocService.selectDocInfo(promtnInfoVO.getBeginThumbDocNo());
					filelist.put("beginImageFile", beginImageFile);
				}
				FileDocVO endImageFile;
				if(promtnInfoVO.getEndThumbDocNo() != null) {
					endImageFile = fileDocService.selectDocInfo(promtnInfoVO.getEndThumbDocNo());
					filelist.put("endImageFile", endImageFile);
				}
			}
			return filelist;

		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 *	첨부파일을 등록한다.
	 */
	@Override
	public Map<String, Object> uploadFileDoc(MultipartHttpServletRequest mrequest) throws Exception {
		try {

			Map<String,Object> map = new HashMap<String,Object>();
			List<FileDocVO> fileList = fileDocService.uploadPublicAttachFilesVoList("ev", mrequest);
			map.put("list", fileList);

			return map;

		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 *	첨부파일을 삭제한다.
	 */
	@Override
	public Map<String, Object> deleteFileDoc(FileDocVO fileVO) throws Exception {
		try {
			Map<String,Object> map = new HashMap<String,Object>();

			fileDocService.deleteCommonDoc(fileVO.getDocNo());
			map.put("docNo", fileVO.getDocNo());
			map.put("result","success");

			return map;
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * <pre>
	 * 처리내용: 복주머니 당첨자 목록을 조회한다.
	 * </pre>
	 * @date 2024. 01. 29.
	 * @author cuko
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 29.		cuko				최초작성
	 * 2024. 01. 29.		hyunjin05			조회, 변경 추가
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<PromtnNewYearVO> getPrizeWinnerList(PromtnNewYearVO promtnNewYearVO) {
		List<PromtnNewYearVO> getPrizeWinnerList = new ArrayList<PromtnNewYearVO>();
		List<PromtnNewYearVO> returnList = new ArrayList<PromtnNewYearVO>();
		try {
			getPrizeWinnerList = promtnInfoMapper.getPrizeWinnerList(promtnNewYearVO);
			for(PromtnNewYearVO vo : getPrizeWinnerList ) {
				//휴대번호 복호화
				vo.setPrzwnerMoblphonNo(CryptoUtil.decryptAES256(vo.getPrzwnerMoblphonNo()));
				returnList.add(vo);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return returnList;
	}
	@Override
	public int getPrizeWinnerListTotCnt(PromtnNewYearVO promtnNewYearVO) {
		return promtnInfoMapper.getPrizeWinnerListTotCnt(promtnNewYearVO);
	}
	
	/**
	 * <pre>
	 * 처리내용: 복주머니 당첨자의 상품권 전송 여부 상태를 변경한다.
	 * </pre>
	 * @date 2024. 01. 29.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 29.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int insertUpateprizeWinnerListData(PromtnNewYearVO promtnNewYearVO) throws Exception {
		// TODO Auto-generated method stub
		int result = 0;
		int evPromtnGdlBsktIdx = 0;
		PromtnNewYearVO vo = new PromtnNewYearVO();
		
		for(int i = 0; i < promtnNewYearVO.getInsertArray().length; i++) {
			evPromtnGdlBsktIdx = promtnNewYearVO.getInsertArray()[i];
			vo.setEvPromtnGdlBsktIdx(evPromtnGdlBsktIdx);
			vo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			vo.setSendAt(promtnInfoMapper.selectPromtnIdxInfo(vo));
			
			if(vo.getSendAt().equals("N")) {
				vo.setSendAt("Y");
			}else {
				vo.setSendAt("N");
			}
			
			vo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			
			result = promtnInfoMapper.insertUpateprizeWinnerListData(vo);
			if(result > 0) {
				result++;
			}
		}
		return result;
	}

}
