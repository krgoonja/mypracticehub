package com.sorincorp.bo.ev.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.apache.commons.lang3.StringUtils;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.ev.mapper.CouponMapper;
import com.sorincorp.bo.ev.model.CouponVO;
import com.sorincorp.comm.common.service.CommonService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
public class CouponServiceImpl implements CouponService {

	@Autowired
	private CouponMapper couponMapper;

	@Autowired
	private UserInfoUtil usertInfoUtil;

	@Autowired
	private CommonService commonService;

	/**
	 * <pre>
	 * 처리내용: 쿠폰 발행 내역 리스트 조회
	 * </pre>
	 *
	 * @param couponVO
	 * @return
	 * @throws Exception
	 * @date 2023. 05. 08.
	 * @author hamyoonsic
	 * @history ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 8.			   hamyoonsic			최초작성
	 * ------------------------------------------------
	 */
	@Override
	public List<CouponVO> getCouponIsuDataList(CouponVO couponVO) throws Exception {
		List<CouponVO> couponIsuList = couponMapper.getCouponIsuDataList(couponVO);
		for(CouponVO vo : couponIsuList){
			//메탈코드 0 일 경우 '전체'로 표기
			if (StringUtils.equals("0", vo.getMetalNm())) {
				vo.setMetalNm("전체");
			}
		}
		return couponIsuList;
	}

	/**
	 * <pre>
	 * 처리내용: 쿠폰 발행 내역 리스트 갯수 조회
	 * </pre>
	 *
	 * @param couponVO
	 * @return
	 * @throws Exception
	 * @date 2023. 05. 08.
	 * @author hamyoonsic
	 * @history ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 8.			   hamyoonsic			최초작성
	 * ------------------------------------------------
	 */
	@Override
	public int getCouponIsuDataListTotCnt(CouponVO couponVO) throws Exception {
		return couponMapper.getCouponIsuDataListTotCnt(couponVO);
	}

	/**
	 * <pre>
	 * 처리내용: 발행 쿠폰 삭제.
	 * </pre>
	 *
	 * @param couponVO
	 * @throws Exception
	 * @date 2023. 05. 08.
	 * @author hamyoonsic
	 * @history ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 05. 08.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public void deleteCouponIsuData(CouponVO couponVO) throws Exception {
		try {
			couponVO.setLastChangerId(Optional.ofNullable(usertInfoUtil.getUserId()).orElse(""));
			//쿠폰 삭제
			couponMapper.deleteCouponIsuData(couponVO);
			//couponMapper.insertCouponIsuBasHst(couponVO);
			commonService.insertTableHistory("CP_COUPON_ISU_BAS", couponVO);
			
			//쿠폰마스터번호 조회
			CouponVO responseCouponVO = couponMapper.getCouponNo(couponVO);
			//쿠폰 마스터 데이터 업데이트
			responseCouponVO.setLastChangerId(couponVO.getLastChangerId());
			couponMapper.updateCouponPolicyInfo(responseCouponVO);

			//히스토리 생성
			Map<String,String> keyValue = new HashMap<>();
			keyValue.put("COUPON_NO",responseCouponVO.getCouponNo());
			commonService.insertTableHistory("CP_COUPON_INFO_BAS", keyValue);
		} catch (Exception e) {
			log.info("[CouponServiceImpl.deleteCouponIsuData Error]" + e.getMessage());
			throw e;
		}
	}
}