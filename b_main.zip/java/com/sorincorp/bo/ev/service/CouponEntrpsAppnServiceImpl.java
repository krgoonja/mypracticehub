package com.sorincorp.bo.ev.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.ev.mapper.CouponInfoMapper;
import com.sorincorp.bo.ev.model.CouponEntrpsAppnVO;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.common.service.CommonService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CouponEntrpsAppnServiceImpl implements CouponEntrpsAppnService{
		
	@Autowired
	private CouponInfoMapper couponInfoMapper;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Autowired
	private CommonService commonService;
		
	@Override
	public int getCouponEntrpsAppnListTotcnt(CouponEntrpsAppnVO couponEntrpsAppnVO) {
		return couponInfoMapper.getCouponEntrpsAppnListTotcnt(couponEntrpsAppnVO);
	}
	
	@Override
	public List<CouponEntrpsAppnVO> getCouponEntrpsAppnList(CouponEntrpsAppnVO couponEntrpsAppnVO) {
		return couponInfoMapper.getCouponEntrpsAppnList(couponEntrpsAppnVO);
	}	
	
	@Override
	public int insertCouponEntrps(List<CouponEntrpsAppnVO> CouponEntrpsAppnVOList) throws Exception {
		int result = 0;
		
		Account account = userInfoUtil.getAccountInfo();

		String userId ="";

		if(account != null) {
			userId = account.getId();
		}
		
		for(CouponEntrpsAppnVO couponEntrpsAppnVO :  CouponEntrpsAppnVOList) {
			log.debug("insertCouponEntrps insert: " + couponEntrpsAppnVO);

			couponEntrpsAppnVO.setFrstRegisterId(userId);

			result = couponInfoMapper.insertCouponEntrps(couponEntrpsAppnVO);
			commonService.insertTableHistory("COUPON_ENTRPS_APPN_BAS", couponEntrpsAppnVO);
		}
		return result;
	}
	
	@SuppressWarnings("unused")
	@Override
	public int deleteCouponEntrps(List<CouponEntrpsAppnVO> CouponEntrpsAppnVOList) throws Exception {
		int result = 0;
		
		Account account = userInfoUtil.getAccountInfo();

		String userId ="";

		if(account != null) {
			userId = account.getId();
		}
		
		for(CouponEntrpsAppnVO couponEntrpsAppnVO :  CouponEntrpsAppnVOList) {
			log.debug("deleteCouponEntrpsApp delete: " + couponEntrpsAppnVO);

			result = couponInfoMapper.deleteCouponEntrps(couponEntrpsAppnVO);
			commonService.insertTableHistory("COUPON_ENTRPS_APPN_BAS", couponEntrpsAppnVO);
		}
		return result;
	}	
}