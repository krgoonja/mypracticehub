package com.sorincorp.bo.ev.service;

import java.util.List;

import com.sorincorp.bo.ev.model.CouponEntrpsAppnVO;
import com.sorincorp.bo.ev.model.OrdtmDscntCouponVO;

public interface OrdtmDscntCouponService {
	
	/**
	 * <pre>
	 * 처리내용: 회원_업체 등급 기준 구매 수량 리스트 조회
	 * </pre>
	 * @date 2024. 5. 23.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 23.				hyunjin0512			연결수정
	 * ------------------------------------------------
	 * @param OrdtmDscntCouponVO
	 * @return
	 * @throws Exception
	 */
	public List<OrdtmDscntCouponVO> OrdtmDscntCouponList(OrdtmDscntCouponVO ordtmDscntCouponVO) throws Exception;
	
	
	/**
	 * <pre>
	 * 처리내용: 회원_업체 등급 기준 구매 수량 리스트 카운트
	 * </pre>
	 * @date 2024. 5. 23.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 23.				hyunjin0512			연결수정
	 * ------------------------------------------------
	 * @param OrdtmDscntCouponVO
	 * @return
	 * @throws Exception
	 */
	public Integer ordtmDscntCouponListCnt(OrdtmDscntCouponVO ordtmDscntCouponVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 회원_업체 등급 기준 구매 수량 수정
	 * </pre>
	 * @date 2024. 5. 23.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 23.				hyunjin0512			연결수정
	 * ------------------------------------------------
	 * @param OrdtmDscntCouponVO
	 * @return
	 * @throws Exception
	 */
	public boolean insertAndUpdateOrdtmDscntCouponPolicy(OrdtmDscntCouponVO ordtmDscntCouponVO) throws Exception;
	
}