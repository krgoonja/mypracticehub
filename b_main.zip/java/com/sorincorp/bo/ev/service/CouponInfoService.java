package com.sorincorp.bo.ev.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.co.model.CmmnCodeVO;
import com.sorincorp.bo.ev.model.CouponInfoVO;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;

public interface CouponInfoService {
	
	public List<CommonCodeVO> selectPromtnNoList()throws Exception;
	
	public List<CommonCodeVO> selectPromtnNoList(CouponInfoVO couponInfoVO) throws Exception;
	
	public List<CouponInfoVO> getCouponInfoList(CouponInfoVO couponInfoVO) throws Exception;
	
	public int getCouponInfoListTotCnt(CouponInfoVO couponInfoVO) throws Exception;
	
	public int insertAndUpdateCouponInfoBas(List<CouponInfoVO> couponInfoVO) throws Exception;	
	
	public int deleteCouponInfo(List<CouponInfoVO> couponInfoVO) throws Exception;	
	
	/**
	 * <pre>
	 * 처리내용: 메탈코드에 따른 적용 브랜드 리스트.
	 * </pre>
	 * @date 2022. 07. 18.
	 * @author jhcha
	 * @history 
	 * @param couponInfoVO
	 * @return
	 * @throws Exception
	 */
	public List<CmmnCodeVO> selectBrandCode(CouponInfoVO couponInfoVO) throws Exception;
	
	
	public List<CommonCodeVO> selectCouponEventNoList(CouponInfoVO couponInfoVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 쿠폰 발행난수생성
	 * </pre>
	 * @date 2022. 08. 11.
	 * @author sumin95
	 * @history 
	 * @param couponInfoVO
	 * @return
	 * @throws Exception
	 */
	public String createCouponIsuRnno(CouponInfoVO couponInfoVO) throws Exception;
	

	public List<CommonCodeVO> selectCouponNoList() throws Exception;

}