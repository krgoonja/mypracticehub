package com.sorincorp.bo.ev.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.ev.model.EntrpsCouponVO;
import com.sorincorp.bo.ev.model.EntrpsIsuVO;

public interface EntrpsCouponService {
	
	/**
	 * <pre>
	 * 처리내용: 업체쿠폰 발행페이지를 조회한다.
	 * </pre>
	 * @date 2023. 5. 1.
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 1.				sumin				최초작성
	 * ------------------------------------------------
	 * @param entrpsCouponVO
	 * @return
	 * @throws Exception
	 */
	List<EntrpsCouponVO> searchEntrpsCouponList(EntrpsCouponVO entrpsCouponVO) throws Exception;
	Integer selectEntrpsCouponListTotCnt(EntrpsCouponVO entrpsCouponVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 업체 지정 페이지 - 지정기업리스트를 조회한다
	 * </pre>
	 * @date 2023. 5. 8.
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 8.				sumin				최초작성
	 * ------------------------------------------------
	 * @param entrpsCouponVO
	 * @return
	 * @throws Exception
	 */
	List<EntrpsCouponVO> selectAppnEntrpsList(EntrpsCouponVO entrpsCouponVO) throws Exception;
	int selectAppnEntrpsListCnt(EntrpsCouponVO entrpsCouponVO) throws Exception;
	/**
	 * <pre>
	 * 처리내용: 업체 지정 페이지 - 쿠폰 정보 조회
	 * </pre>
	 * @date 2023. 5. 15.
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 *  2023. 5. 15.			sumin				최초작성
	 * ------------------------------------------------
	 * @param entrpsCouponVO
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> selectCouponInfo(EntrpsCouponVO entrpsCouponVO) throws Exception; 
	/**
	 * <pre>
	 * 처리내용: 업체 지정 페이지 - 쿠폰발행 업체 조회
	 * </pre>
	 * @date 2023. 5. 15.
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 *  2023. 5. 15.			sumin				최초작성
	 * ------------------------------------------------
	 * @param entrpsCouponVO
	 * @return
	 * @throws Exception
	 */
	List<EntrpsCouponVO> getCouponAppnEntrps(EntrpsCouponVO entrpsCouponVO) throws Exception; 
	int getCouponAppnEntrpsCnt(EntrpsCouponVO entrpsCouponVO) throws Exception; 
	
	/**
	 * <pre>
	 * 처리내용: 업체 지정 페이지 - 쿠폰 정보 저장
	 * </pre>
	 * @date 2023. 5. 15.
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 *  2023. 5. 15.			sumin				최초작성
	 * ------------------------------------------------
	 * @param entrpsCouponVO
	 * @return
	 * @throws Exception
	 */
	void saveCouponDtl(EntrpsIsuVO entrpsIsuVO) throws Exception; 
	
	/**
	 * <pre>
	 * 처리내용: 쿠폰관리 > 업체쿠폰발행하기 > 쿠폰 정보 수정
	 * </pre>
	 * @date 2023. 8. 23.
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 23.				sumin				최초작성
	 * ------------------------------------------------
	 * @param entrpsCouponVO
	 * @return
	 * @throws Exception
	 */
	void updateCouponDtl(EntrpsIsuVO entrpsIsuVO) throws Exception; 
	
	/**
	 * <pre>
	 * 처리내용: 업체 지정 쿠폰목록 - 쿠폰 상세정보 삭제
	 * </pre>
	 * @date 2023. 5. 26
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 *  2023. 5. 26			sumin				최초작성
	 * ------------------------------------------------
	 * @param entrpsCouponVO
	 * @return
	 * @throws Exception
	 */
	int deleteCouponDtl(EntrpsCouponVO entrpsCouponVO) throws Exception; 


}
