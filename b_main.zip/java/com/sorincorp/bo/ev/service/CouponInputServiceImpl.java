package com.sorincorp.bo.ev.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.ev.mapper.CouponInfoMapper;
import com.sorincorp.bo.ev.model.CouponInputVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CouponInputServiceImpl implements CouponInputService{
		
	@Autowired
	private CouponInfoMapper CouponInfoMapper;
	
	@Override
	public List<CouponInputVO> getCouponInputList(CouponInputVO couponInputVO) {
		return CouponInfoMapper.getCouponInputList(couponInputVO);
	}
	
	@Override
	public int getCouponInputListTotCnt(CouponInputVO couponInputVO) {
		return CouponInfoMapper.getCouponInputListTotCnt(couponInputVO);
	}
	
}