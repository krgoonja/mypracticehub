package com.sorincorp.bo.ev.service;

import java.util.List;

import com.sorincorp.bo.ev.model.CouponVO;

public interface CouponService {

	/**
	 * <pre>
	 * 처리내용: 쿠폰 발행 내역 리스트 조회
	 * </pre>
	 * @date 2022. 07. 18.
	 * @author jhcha
	 * @history
	 * * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 07. 18.			jhcha				최초작성
	 * 2023. 05. 08.			hamyoonsic			수정
	 * ------------------------------------------------
	 * @param couponVO
	 * @return
	 * @throws Exception
	 */
	public List<CouponVO> getCouponIsuDataList(CouponVO couponVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 쿠폰 발행 내역 리스트 갯수 조회
	 * </pre>
	 * @date 2023. 05. 08.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 8.			   hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param couponVO
	 * @return
	 * @throws Exception
	 */
	public int getCouponIsuDataListTotCnt(CouponVO couponVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 발행 쿠폰 삭제.
	 * </pre>
	 * @date 2021. 05. 08.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 05. 28.			srec0031		  	최초작성
	 * 2023. 05. 08.			hamyoonsic			수정
	 * ------------------------------------------------
	 * @param couponVO
	 * @throws Exception
	 */
	public void deleteCouponIsuData(CouponVO couponVO)  throws Exception;
}