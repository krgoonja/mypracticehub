package com.sorincorp.bo.ev.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.ev.model.CouponPolicyVO;

public interface CouponPolicyService {

	//생성 쿠폰 목록 리스트 조회
	public List<CouponPolicyVO> getCouponPolicyList(CouponPolicyVO couponPolicyVO) throws Exception;

	//생성 쿠폰 목록 리스트 카운트
	public Integer getCouponPolicyListTotCnt(CouponPolicyVO couponPolicyVO) throws Exception;

	//생성 쿠폰 목록 리스트 총 합
	public CouponPolicyVO getTotalCouponPolicyList(CouponPolicyVO couponPolicyVO) throws Exception;

	//생성 쿠폰 목록 엑셀 리스트 조회
	public List<CouponPolicyVO> getCouponPolicyExcelList(CouponPolicyVO couponPolicyVO) throws Exception;

	// 쿠폰 정책 생성 및 수정
	boolean insertAndUpdateCouponPolicy(CouponPolicyVO couponPolicyVO) throws Exception;

	//프로모션에 대한 쿠폰 정책 발행 여부 확인, 상세 쿠폰 - 발행 상태(임시 발행) 확인, 업체 발행 쿠폰 - 쿠폰 상태(미사용) 확인
	public Map<String, Integer> deleteChkCouponPolicy(CouponPolicyVO couponPolicyVO) throws Exception;

	//쿠폰 정책 삭제
	public boolean deleteCouponPolicy(CouponPolicyVO couponPolicyVO) throws Exception;

	// 쿠폰 상세 - 발행 목록
	public CouponPolicyVO getCouponPolicyDtl(CouponPolicyVO couponPolicyVO) throws Exception;

	// 쿠폰 상세 - 상세 발행 내역
	public List<CouponPolicyVO> getCouponDtlIsuList(CouponPolicyVO couponPolicyVO) throws Exception;

	//쿠폰 상세 - 상세 발행 내역 카운트
	public Integer getCouponDtlIsuListTotCnt(CouponPolicyVO couponPolicyVO) throws Exception;

	// 쿠폰 수정 이력
	public List<CouponPolicyVO> getCouponPolicyHstList(CouponPolicyVO couponPolicyVO) throws Exception;

	// 쿠폰 수정 이력 카운트
	public Integer getCouponPolicyHstListCnt(CouponPolicyVO couponPolicyVO) throws Exception;
	
	// 프로모션 수정 - 해당 프로모션 번호로 발행된 정책 데이터 유무 확인
	public Map<String, Object> getChkCouponPolicy(CouponPolicyVO couponPolicyVO) throws Exception;
	
	// 프로모션 삭제 - 해당 프로모션 번호로 업체에게 발행된 쿠폰 상태 확인 (01:미사용, 05:사용중)
	public Integer getChkCouponUseCnt(CouponPolicyVO couponPolicyVO) throws Exception;

	// 프로모션 삭제 - 해당 프로모션 번호로 발행된 정책, 디테일 쿠폰 삭제처리
	public boolean deleteAllCoupon(CouponPolicyVO couponPolicyVO) throws Exception;
	

}