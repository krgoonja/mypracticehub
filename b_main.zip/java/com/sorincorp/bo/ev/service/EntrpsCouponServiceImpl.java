package com.sorincorp.bo.ev.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.ev.mapper.EntrpsCouponMapper;
import com.sorincorp.bo.ev.model.EntrpsCouponVO;
import com.sorincorp.bo.ev.model.EntrpsIsuVO;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EntrpsCouponServiceImpl implements EntrpsCouponService{

	@Autowired
	EntrpsCouponMapper entrpsCouponMapper;
	@Autowired
	AssignService assignService;
	@Autowired
	UserInfoUtil userInfoUtil;
	@Autowired
	CommonService commonService;
	/** SMS 발송 서비스 */
	@Autowired
	private SMSService smsService;
	
	/** 프로모션관리 > 쿠폰관리 > 업체쿠폰발행하기 : 목록조회*/
	@Override
	public List<EntrpsCouponVO> searchEntrpsCouponList(EntrpsCouponVO entrpsCouponVO) throws Exception{
		log.debug("EntrpsCouponServiceImpl::selectEntrpsCouponList 업체쿠폰발행 : 목록조회 Start");
		List<EntrpsCouponVO> entrpsCouponList = new ArrayList<>();
		
		try {
			entrpsCouponList = entrpsCouponMapper.selectEntrpsCouponList(entrpsCouponVO);
		} catch (Exception e) {
			log.debug("EntrpsCouponServiceImpl::selectEntrpsCouponList exception = " + e.getMessage());
		}
		return entrpsCouponList;
	}
	
	@Override
	public Integer selectEntrpsCouponListTotCnt(EntrpsCouponVO entrpsCouponVO) throws Exception {

		return entrpsCouponMapper.selectEntrpsCouponListTotCnt(entrpsCouponVO);
	}
	
	/** 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리/업체쿠폰발행하기 > 모달 : 발행가능 기업 목록조회*/
	@Override
	public List<EntrpsCouponVO> selectAppnEntrpsList(EntrpsCouponVO entrpsCouponVO) throws Exception {
		log.debug("EntrpsCouponServiceImpl::selectAppnEntrpsList 업체쿠폰발행 : 발행가능 기업 목록조회 Start");
		List<EntrpsCouponVO> entrpsList  = new ArrayList<>();
		
		try {
			 entrpsList = entrpsCouponMapper.selectAppnEntrpsList(entrpsCouponVO);
		} catch (Exception e) {
			log.debug("EntrpsCouponServiceImpl::selectAppnEntrpsList exception = " + e.getMessage());
		}
		return entrpsList;
	}	
	/** 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리/업체쿠폰발행하기 > 모달 : 발행가능 기업 목록조회*/
	@Override
	public int selectAppnEntrpsListCnt(EntrpsCouponVO entrpsCouponVO) throws Exception {
		log.debug("EntrpsCouponServiceImpl::selectAppnEntrpsListCnt 업체쿠폰발행 : 발행가능 기업 수 Start");
		int cnt =0;
		
		try {
			cnt = entrpsCouponMapper.selectAppnEntrpsListCnt(entrpsCouponVO);
		} catch (Exception e) {
			log.debug("EntrpsCouponServiceImpl::selectAppnEntrpsListCnt exception = " + e.getMessage());
		}
		return cnt;
	}	
	
	/** 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리/업체쿠폰발행하기 > 모달 : 페이지로드 */
	@Override
	public Map<String, Object> selectCouponInfo(EntrpsCouponVO entrpsCouponVO) throws Exception {
		log.debug("EntrpsCouponServiceImpl::selectCouponInfo 업체쿠폰발행 : 쿠폰 정책 데이터 조회 Start");
		EntrpsCouponVO couponInfoVo = new EntrpsCouponVO();
		List<EntrpsCouponVO> entrpsList = new ArrayList<>();
		Map<String, Object> resultMap = new HashMap<>();
		int couponUseCount = 0;
		
		try {
			if(entrpsCouponVO.getModalPageStatus().equals("update")) {
				/** 수정 모달 **/	
				couponInfoVo = entrpsCouponMapper.selectCouponDtl(entrpsCouponVO); 			//기 발행 된 쿠폰 정보
				entrpsList = entrpsCouponMapper.getCouponIsuCount(entrpsCouponVO); 			//기 발행 된 업체리스트
				couponUseCount = entrpsCouponMapper.getCouponCount(entrpsCouponVO.getCouponDtlNo(), "02");	//사용중인 쿠폰 리스트
				//단가,배송비 구분
				if(entrpsCouponVO.getCouponTyCode().equals("01")) {
					entrpsCouponVO.setActiveTabVal("UntPcCoupon");
				} else {
					entrpsCouponVO.setActiveTabVal("DlvyCoupon") ;
				}
			} else { 													
				/** 등록 모달 **/	 
				couponInfoVo = entrpsCouponMapper.selectCouponInfo(entrpsCouponVO);
			}
			resultMap.put("couponInfoVo", couponInfoVo);
			resultMap.put("entrpsList", entrpsList);
			resultMap.put("couponUseCount", couponUseCount);
		} catch (Exception e) {
			log.debug("EntrpsCouponServiceImpl::selectCouponInfo exception = " + e.getMessage());
		}
		return resultMap;
	}
	
	/** 프로모션관리 > 쿠폰관리 > 업체쿠폰발행하기 > 쿠폰상세번호 : 모달로드 */
	@Override
	public List<EntrpsCouponVO> getCouponAppnEntrps(EntrpsCouponVO entrpsCouponVO) throws Exception {
		log.debug("EntrpsCouponServiceImpl::getCouponAppnEntrps 업체쿠폰발행 : 쿠폰 발행 업제 조회 Start");
		List<EntrpsCouponVO> vo = new ArrayList<>();
		
		try {
			vo = entrpsCouponMapper.getCouponAppnEntrps(entrpsCouponVO);
		} catch (Exception e) {
			log.debug("EntrpsCouponServiceImpl::getCouponAppnEntrps exception = " + e.getMessage());
		}
		
		return vo;
	}		
	/** 프로모션관리 > 쿠폰관리 > 업체쿠폰발행하기 > 쿠폰상세번호 : 모달로드 Cnt*/
	@Override
	public int getCouponAppnEntrpsCnt(EntrpsCouponVO entrpsCouponVO) throws Exception {
		log.debug("EntrpsCouponServiceImpl::getCouponAppnEntrpsCnt 업체쿠폰발행 : 쿠폰 발행 업제 조회 Start");
		int cnt=0;
		try {
			cnt = entrpsCouponMapper.getCouponAppnEntrpsCnt(entrpsCouponVO);
		} catch (Exception e) {
			log.debug("EntrpsCouponServiceImpl::getCouponAppnEntrpsCnt exception = " + e.getMessage());
		}
		
		return cnt;
	}		
	
	/** 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리/업체쿠폰발행하기 > 모달 > 쿠폰발행 */
	@Override
	public void saveCouponDtl(EntrpsIsuVO entrpsIsuVO) throws Exception {
		log.debug("EntrpsCouponServiceImpl::saveCouponDtl 업체 지정 쿠폰 : 업제 지정 발행 / 수정 Start");
		try {
			List<EntrpsCouponVO> entprsIsuVoList = entrpsIsuVO.getEntprsIsuList();
			int[] dscntAmountArray;
			//단가
			if(entrpsIsuVO.getCouponTyCode().equals("01")) {
				dscntAmountArray = Arrays.stream(entrpsIsuVO.getUntpcDscntAmount().split(",")).mapToInt(Integer::parseInt).toArray();		//단가쿠폰 발행 금액
			//배송비
			}else {
				dscntAmountArray = new int[] {0};
			}
			
			//쿠폰 기본 테이블 update
			entrpsIsuVO.setIsuId(userInfoUtil.getAccountInfo().getId());
			entrpsIsuVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
			entrpsIsuVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			entrpsCouponMapper.updateCouponInfo(entrpsIsuVO);
			commonService.insertTableHistory("CP_COUPON_INFO_BAS", entrpsIsuVO);
			
			//쿠폰 상세 테이블 insert
			for( int i = 0; i < dscntAmountArray.length; i ++ ) {
				entrpsIsuVO.setCouponDtlNo(DateUtil.getNowDate()+ "-C" + assignService.selectAssignValue("CP", "COUPON_DTL_NO", DateUtil.calDate("yyyy"), entrpsIsuVO.getIsuId(), 5));
				entrpsIsuVO.setUntpcDscntAmount(Integer.toString(dscntAmountArray[i]));
				//단가 톤 수 제한없음 시 mt : 0->100으로 계산 배송비 로직으로 mt:0 이 들어올 경우 배열[0]이 0이므로 상관없음
				if(entrpsIsuVO.getMt() == 0) {
					entrpsIsuVO.setUntpcCouponTotalAmount(dscntAmountArray[i] * 100);
				}else {
					entrpsIsuVO.setUntpcCouponTotalAmount(dscntAmountArray[i] * entrpsIsuVO.getMt());
				}
				entrpsCouponMapper.insertCouponDtl(entrpsIsuVO);
				commonService.insertTableHistory("CP_COUPON_INFO_DTL", entrpsIsuVO);
				
				for ( EntrpsCouponVO entprsIsu : entprsIsuVoList) {
					for( int k = 0; k < entprsIsu.getEntrpsIsuCount(); k ++ ) {
						//쿠폰 일련번호 채번
						entprsIsu.setCouponSn("CP-"+DateUtil.getNowDateTime("yyyyMM")+"-"+ assignService.selectAssignValue("CP", "COUPON_SN", DateUtil.calDate("yyyy"), entrpsIsuVO.getIsuId(), 5));
						entprsIsu.setCouponDtlNo(entrpsIsuVO.getCouponDtlNo());
						entprsIsu.setCouponDscntApplcAmount(entrpsIsuVO.getUntpcCouponTotalAmount());
						entprsIsu.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
						entprsIsu.setLastChangerId(userInfoUtil.getAccountInfo().getId());
						entrpsCouponMapper.insertCouponIsu(entprsIsu);

						EntrpsCouponVO couponSmsVO = entrpsCouponMapper.getCouponSmsInfo(entprsIsu);
						String templateNum = ""; // 템플릿 번호
						// 쿠폰 타입에 따라 템플릿 번호를 결정 [01:단가할인쿠폰 02:총액할인쿠폰 03:배송비쿠폰]
						switch(entrpsIsuVO.getCouponTyCode()) {
							case "01": templateNum = "122"; break;
							//case "02": templateNum = ""; break;
							case "03": templateNum = "121"; break;
						}
						if(!StringUtils.isEmpty(templateNum)) {
							procSms(couponSmsVO, templateNum);
						}
					}
				}
				List<String> primaryKeyList = new ArrayList<>();
				primaryKeyList.add("COUPON_DTL_NO");
				commonService.insertTableHistory("CP_COUPON_ISU_BAS", entrpsIsuVO, primaryKeyList);
			}
		
		} catch (Exception e) {
			log.debug("EntrpsCouponServiceImpl::saveCouponDtl exception = " + e.getMessage());
		}
	}	
	
	
	/** 프로모션관리 > 쿠폰관리 > 업체쿠폰발행하기 > 수정 */
	@Override
	public void updateCouponDtl(EntrpsIsuVO paramVo) throws Exception {
		//int result = 0;
		try {
			List<EntrpsCouponVO> entprsIsuVoList = paramVo.getEntprsIsuList();

			paramVo.setIsuId(userInfoUtil.getAccountInfo().getId());
			paramVo.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
			paramVo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			
			//01.기업추가 / 02.기업추가,.적용일자, 임시저장여부 변경 / 03.적용일자, 임시저장여부
			if (entprsIsuVoList.size() > 0 && !(paramVo.isCouponChgAt())) {			// 01.기업만 추가 
				
				entrpsCouponMapper.updateCouponInfo(paramVo);
				commonService.insertTableHistory("CP_COUPON_INFO_BAS", paramVo);
				
				for ( EntrpsCouponVO entprsIsu : entprsIsuVoList) {
					for( int k = 0; k < entprsIsu.getEntrpsIsuCount(); k ++ ) {
						//쿠폰 일련번호 채번
						entprsIsu.setCouponSn("CP-"+DateUtil.getNowDateTime("yyyyMM")+"-"+ assignService.selectAssignValue("CP", "COUPON_SN", DateUtil.calDate("yyyy"), paramVo.getIsuId(), 5));
						entprsIsu.setCouponDtlNo(paramVo.getCouponDtlNo());
						//단가
						if(paramVo.getCouponTyCode().equals("01")) {
							entprsIsu.setCouponDscntApplcAmount(Integer.parseInt(paramVo.getUntpcDscntAmount()) * paramVo.getMt());
						//배송비
						}else {
							entprsIsu.setCouponDscntApplcAmount(0);
						}
						entprsIsu.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
						entprsIsu.setLastChangerId(userInfoUtil.getAccountInfo().getId());
						entrpsCouponMapper.insertCouponIsu(entprsIsu);

						EntrpsCouponVO couponSmsVO = entrpsCouponMapper.getCouponSmsInfo(entprsIsu);
						String templateNum = ""; // 템플릿 번호
						// 쿠폰 타입에 따라 템플릿 번호를 결정 [01:단가할인쿠폰 02:총액할인쿠폰 03:배송비쿠폰]
						switch(paramVo.getCouponTyCode()) {
							case "01": templateNum = "122"; break;
							case "03": templateNum = "121"; break;
						}
						if(!StringUtils.isEmpty(templateNum)) {
							procSms(couponSmsVO, templateNum);
						}
					}
				}
				
				List<String> primaryKeyList = new ArrayList<>();
				primaryKeyList.add("COUPON_DTL_NO");
				commonService.insertTableHistory("CP_COUPON_ISU_BAS", paramVo, primaryKeyList);

			} else if (entprsIsuVoList.size() > 0 && paramVo.isCouponChgAt()) {			// 02.기업추가, 적용일자, 임시저장여부 변경
				//사용쿠폰 (COUPON_STTUS_CODE : 02)  존재 여부 확인
				if( entrpsCouponMapper.getCouponCount(paramVo.getCouponDtlNo(), "02") > 0){	return;	};
				
					entrpsCouponMapper.updateCouponDtl(paramVo);
					commonService.insertTableHistory("CP_COUPON_INFO_DTL", paramVo);
				
				for ( EntrpsCouponVO entprsIsu : entprsIsuVoList) {
					for( int k = 0; k < entprsIsu.getEntrpsIsuCount(); k ++ ) {
						//쿠폰 일련번호 채번
						entprsIsu.setCouponSn("CP-"+DateUtil.getNowDateTime("yyyyMM")+"-"+ assignService.selectAssignValue("CP", "COUPON_SN", DateUtil.calDate("yyyy"), paramVo.getIsuId(), 5));
						entprsIsu.setCouponDtlNo(paramVo.getCouponDtlNo());
						entprsIsu.setCouponDscntApplcAmount(Integer.parseInt(paramVo.getUntpcDscntAmount()) * paramVo.getMt());
						entprsIsu.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
						entprsIsu.setLastChangerId(userInfoUtil.getAccountInfo().getId());
						entrpsCouponMapper.insertCouponIsu(entprsIsu);

						EntrpsCouponVO couponSmsVO = entrpsCouponMapper.getCouponSmsInfo(entprsIsu);
						String templateNum = ""; // 템플릿 번호
						// 쿠폰 타입에 따라 템플릿 번호를 결정 [01:단가할인쿠폰 02:총액할인쿠폰 03:배송비쿠폰]
						switch(paramVo.getCouponTyCode()) {
							case "01": templateNum = "122"; break;
							case "03": templateNum = "121"; break;
						}
						if(!StringUtils.isEmpty(templateNum)) {
							procSms(couponSmsVO, templateNum);
						}
					}
				} 
				
				List<String> primaryKeyList = new ArrayList<>();
				primaryKeyList.add("COUPON_DTL_NO");
				commonService.insertTableHistory("CP_COUPON_ISU_BAS", paramVo, primaryKeyList);
			
			} else if (entprsIsuVoList.size() <= 0 && paramVo.isCouponChgAt()) {			// 03.적용일자, 임시저장여부 변경
				//사용완료 쿠폰 (COUPON_STTUS_CODE : 02)  존재 여부 확인
				if( entrpsCouponMapper.getCouponCount(paramVo.getCouponDtlNo(), "02") > 0){	return;	};
				
				entrpsCouponMapper.updateCouponDtl(paramVo);
				commonService.insertTableHistory("CP_COUPON_INFO_DTL", paramVo);	
			}
	
		} catch(Exception e) {
			log.debug("EntrpsCouponServiceImpl::updateCouponDtl exception = " + e.getMessage());
		}
	}
	
	
	/** 프로모션관리 > 쿠폰관리 > 쿠폰발행정책/업체쿠폰발행하기 > 모달 > 쿠폰삭제 */
	@Override
	public int deleteCouponDtl(EntrpsCouponVO vo) throws Exception {
		int result = 0;
		EntrpsIsuVO isuVo = new EntrpsIsuVO();
		
		log.debug("EntrpsCouponServiceImpl::deleteCouponDtl 업체 지정 쿠폰 : 쿠폰 삭제 Start");
		try {
			
			//모두 미사용쿠폰(COUPON_STTUS_CODE : 01)인지 확인 
			if(entrpsCouponMapper.getUseCouponCount(vo.getCouponDtlNo()) > 0) {
				return -99;
			}
		
			//쿠폰 기본 테이블- 쿠폰 총액, 수량 차감
			isuVo.setCouponNo(vo.getCouponNo());
			isuVo.setTotalQuantity(vo.getEntrpsIsuCount() * -1);
			isuVo.setTotalAmount(vo.getUntpcCouponTotalAmount() * -1);
			isuVo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			result = entrpsCouponMapper.updateCouponInfo(isuVo);
			commonService.insertTableHistory("CP_COUPON_INFO_BAS", vo);
			
			//쿠폰 상세 테이블 DELETE Y/N 업데이트
			vo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			result = entrpsCouponMapper.deleteCouponDtl(vo);
			commonService.insertTableHistory("CP_COUPON_INFO_DTL", vo);
			
			//쿠폰 발행 테이블 DELETE Y/N 업데이트
			vo.setDeleteResn("관리자 삭제");
			result = entrpsCouponMapper.deleteCouponIsuBas(vo);
			List<String> primaryKeyList = new ArrayList<>();
			primaryKeyList.add("COUPON_DTL_NO");
			commonService.insertTableHistory("CP_COUPON_ISU_BAS", vo, primaryKeyList);
			
		} catch (Exception e) {
			log.debug("EntrpsCouponServiceImpl::deleteCouponDtl exception = " + e.getMessage());
		}	
			
		return result;
	}

	/** 쿠폰발행 알림톡 발송 */
	private void procSms(EntrpsCouponVO couponSmsVO, String templateNum) throws Exception {

		log.debug("EntrpsCouponServiceImpl::procSms 업체 지정 쿠폰 : 쿠폰 발행 알림톡 발송 Start");
		try {
			SMSVO smsVO = new SMSVO();
			String entrpsNo = couponSmsVO.getEntrpsNo();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
			smsVO.setCommerceNtcnAt("Y"); //커머스 전송 여부
			List<EntrpsCouponVO> mberList = entrpsCouponMapper.getMoblphonNo(couponSmsVO);

			//같은 업체명을 가진 모든 회원에게 알림톡 전송
			for(EntrpsCouponVO vo : mberList){
				smsVO.setMberNo(vo.getMberNo());
				smsVO.setPhone(vo.getMoblphonNo());
				// MB_MBER_INFO_BAS(회원_회원 정보 기본) - MOBLPHON_NO(휴대전화 번호) 복호화
				String phone = String.valueOf(smsVO.getPhone());
				if(StringUtils.isNotEmpty(phone) && !phone.equals("null")) {
					try {
						log.debug("휴대전화 번호 복호화 전 ==================>" + phone);
						phone = CryptoUtil.decryptAES256(phone);
						log.debug("휴대전화 번호 복호화 후 ==================>" + phone);
						/** 휴대전화 번호 셋팅 **/
						smsVO.setPhone(phone);
					} catch(Exception e) {
						log.error("EntrpsCouponServiceImpl procSms MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
					}
				}

				Map<String, String> smsMap = new HashMap<>();
				//EntrpsCouponVO dataVO = entrpsCouponMapper.getSmsInfo(entprsIsu); //쿠폰 SMS발송을 위한 데이터 조회

				smsMap.put("couponNm",couponSmsVO.getCouponNm());		//쿠폰명
				smsMap.put("metalName",couponSmsVO.getMetalName());				//메탈명
				smsMap.put("mt", String.valueOf(couponSmsVO.getMt()));	//톤수
				smsMap.put("couponTyName",couponSmsVO.getCouponTyName());			//쿠폰타입
				smsMap.put("orderTyName",couponSmsVO.getOrderTyName());			//쿠폰타입
				smsMap.put("couponBgnde",couponSmsVO.getCouponBgnde());	//쿠폰시작일자
				smsMap.put("couponEndde",couponSmsVO.getCouponEndde());	//쿠폰마감일자
				smsMap.put("dlvrfApplcOdr", "1");											//차수 : 1 고정
				smsMap.put("dlvrfDstrctInfo", "전체");										//구간 : 전체
				smsMap.put("templateNum", templateNum); 		// 템플릿 번호
				smsMap.put("excpSndngOptnAt","N");			//예외 발송 여부
				smsService.insertSMS(smsVO, smsMap);
			}
		} catch (Exception e) {
			log.debug("EntrpsCouponServiceImpl::procSms exception = " + e.getMessage());
		}


	}
}
