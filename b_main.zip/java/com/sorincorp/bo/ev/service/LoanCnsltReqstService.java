package com.sorincorp.bo.ev.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.ev.model.LoanCnsltReqstVO;

import lombok.extern.slf4j.Slf4j;


/**
 * LoanCnsltReqstService.java
 * @version
 * @since 2022. 9. 14.
 * @author jaylee
 */
public interface LoanCnsltReqstService {
	
	/**
	 * <pre>
	 * 처리내용: 대출 상담신청 사용자를 조회한다.
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author jaylee
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			jaylee			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@Autowired

	public List<LoanCnsltReqstVO> selectLoanCnsltReqst(LoanCnsltReqstVO vo) throws Exception;

	void updateLoanCnsltReqst(List<LoanCnsltReqstVO> loanCnsltReqstVO)throws Exception;

	//public int deleteLoanCnsltReqst(List<LoanCnsltReqstVO> loanCnsltReqstVO) throws Exception;

	void deleteLoanCnsltReqst(List<LoanCnsltReqstVO> loanCnsltReqstVO)throws Exception;
	
	
}