package com.sorincorp.bo.ev.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.ev.mapper.CouponInfoMapper;
import com.sorincorp.bo.ev.mapper.OrdtmDscntCouponMapper;
import com.sorincorp.bo.ev.model.CouponEntrpsAppnVO;
import com.sorincorp.bo.ev.model.OrdtmDscntCouponVO;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.common.service.CommonService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OrdtmDscntCouponServiceImple implements OrdtmDscntCouponService{
	
	@Autowired
	OrdtmDscntCouponMapper ordtmDscntCouponMapper;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	//회원_업체 등급 기준 구매 수량 리스트 조회
	@Override
	public List<OrdtmDscntCouponVO> OrdtmDscntCouponList(OrdtmDscntCouponVO ordtmDscntCouponVO) throws Exception {
		List<OrdtmDscntCouponVO> OrdtmDscntCouponList = new ArrayList<OrdtmDscntCouponVO>();
		try {
			OrdtmDscntCouponList = ordtmDscntCouponMapper.OrdtmDscntCouponList(ordtmDscntCouponVO);
		} catch (Exception e) {
			// TODO: handle exception
			log.info("[OrdtmDscntCouponServiceImple.OrdtmDscntCouponList Error] " + e.getMessage());
		}
		
		return OrdtmDscntCouponList;
	}
	
	//회원_업체 등급 기준 구매 수량 리스트 카운트
	@Override
	public Integer ordtmDscntCouponListCnt(OrdtmDscntCouponVO ordtmDscntCouponVO) throws Exception {
		int ordtmDscntCouponListCnt = 0;
		
		try {
			ordtmDscntCouponListCnt = ordtmDscntCouponMapper.OrdtmDscntCouponListCnt(ordtmDscntCouponVO);
		} catch (Exception e) {
			// TODO: handle exception
			log.info("[OrdtmDscntCouponServiceImple.OrdtmDscntCouponList Error] " + e.getMessage());
		}
		
		return ordtmDscntCouponListCnt;
	}
	
	/*
	 * 회원_업체 등급 기준 구매 수량 신규 생성
	 * 회원_업체 등급 기준 구매 수량 이전 데이터 삭제
	 * 프로모션_자동발행 쿠폰 정보 기본 신규 생성
	 * 프로모션_자동발행 쿠폰 정보 기본 이전 데이터 삭제
	 */
	@Override
	public boolean insertAndUpdateOrdtmDscntCouponPolicy(OrdtmDscntCouponVO ordtmDscntCouponVO) throws Exception {
		OrdtmDscntCouponVO vo = new OrdtmDscntCouponVO();
		boolean returnData = false;
		int ordtmDsCnt = 0;
		int agoOrdtmDsCnt = 0;
		int atmcIsu = 0;
		int agoAtmcIsu = 0;
		String atmcIsuCndCode = "";
		try {
			// 로그인 유저 아이디
			ordtmDscntCouponVO.setLastChangerId(userInfoUtil.getUserId());
			
			// 회원_업체 등급 기준 구매 수량 신규 생성
			ordtmDsCnt = ordtmDscntCouponMapper.insertOrdtmDscntCouponVO(ordtmDscntCouponVO);
			// 회원_업체 등급 기준 구매 수량 이전 데이터 삭제
			agoOrdtmDsCnt = ordtmDscntCouponMapper.updatetOrdtmDscntCouponVO(ordtmDscntCouponVO);
			
			for(int i = 1 ; i < 4 ; i++){
				atmcIsuCndCode = Integer.toString(i);
				// 프로모션_자동발행 쿠폰 정보 기본 이전 데이터 조회
				vo = ordtmDscntCouponMapper.getAtmcIsuCouponCouponVO(atmcIsuCndCode);
				ordtmDscntCouponVO.setRegistSn(vo.getRegistSn());
				ordtmDscntCouponVO.setAtmcIsuCndNm(vo.getAtmcIsuCndNm());
				ordtmDscntCouponVO.setPromtnNo(vo.getPromtnNo());
				ordtmDscntCouponVO.setCouponNo(vo.getCouponNo());
				ordtmDscntCouponVO.setCouponValidMth(vo.getCouponValidMth());
				ordtmDscntCouponVO.setAtmcIsuCndCode(vo.getAtmcIsuCndCode());
				
				// 프로모션_자동발행 쿠폰 정보 기본 이전 데이터 삭제
				agoAtmcIsu  += ordtmDscntCouponMapper.updateAtmcIsuCouponCouponVO(ordtmDscntCouponVO);
				
				// 프로모션_자동발행 쿠폰 정보 기본 신규 생성
				atmcIsu += ordtmDscntCouponMapper.insertAtmcIsuCouponCouponVO(ordtmDscntCouponVO);
			}
			
			if(ordtmDsCnt > 0 && agoOrdtmDsCnt  > 0 && atmcIsu == 3 && agoAtmcIsu == 3){
				returnData = true;
			}else {
				returnData = false;
			}
			
		} catch (Exception e) {
			returnData = false;
		}
		return returnData;
	}

}