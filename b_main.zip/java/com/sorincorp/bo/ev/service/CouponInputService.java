package com.sorincorp.bo.ev.service;

import java.util.List;

import com.sorincorp.bo.co.model.CmmnCodeVO;
import com.sorincorp.bo.ev.model.CouponInfoVO;
import com.sorincorp.bo.ev.model.CouponInputVO;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;

public interface CouponInputService {
    
	//쿠폰등록리스트 조회
	public List<CouponInputVO> getCouponInputList(CouponInputVO couponInputVO) throws Exception;
	
	public int getCouponInputListTotCnt(CouponInputVO couponInputVO) throws Exception;
	
}