package com.sorincorp.bo.ev.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.co.model.CmmnCodeVO;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.ev.mapper.CouponInfoMapper;
import com.sorincorp.bo.ev.model.CouponInfoVO;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CouponInfoServiceImpl implements CouponInfoService{
		
	@Autowired
	private CouponInfoMapper couponInfoMapper;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Autowired
	private CommonService commonService;
	
	@Override
	public List<CouponInfoVO> getCouponInfoList(CouponInfoVO couponInfoVO) {
		return couponInfoMapper.getCouponInfoList(couponInfoVO);
	}	
	
	@Override
	public int getCouponInfoListTotCnt(CouponInfoVO couponInfoVO) {
		return couponInfoMapper.getCouponInfoListTotCnt(couponInfoVO);
	}
	
	@Override
	public int insertAndUpdateCouponInfoBas(List<CouponInfoVO> couponInfoVOList) throws Exception {
		int result = 0;
		
		for(CouponInfoVO couponInfoVO : couponInfoVOList) {
			Account account = userInfoUtil.getAccountInfo();
			String userId ="";
				
			if(account != null) {
				userId = account.getId();
			}
			
			//int isuRnnoAt= couponInfoMapper.couponIsuRnnoCount(couponInfoVO);
			
			//if(isuRnnoAt == 0) {
			    couponInfoVO.setFrstRegisterId(userId);
			    couponInfoVO.setLastChangerId(userId);
			    couponInfoVO.setCouponBeginDe(couponInfoVO.getCouponBeginDe().replaceAll("-", ""));
			    couponInfoVO.setCouponEndDe(couponInfoVO.getCouponEndDe().replaceAll("-", ""));
			    
			    if("I".equals(couponInfoVO.getEditMode())){
			    	if(couponInfoMapper.couponIsuRnnoCount(couponInfoVO) == 0) {
			    		log.debug("insertCouponInfo insert: " + couponInfoVO);
			    		couponInfoMapper.insertCouponInfoBas(couponInfoVO);
			    		commonService.insertTableHistory("PROMTN_COUPON_INFO_BAS", couponInfoVO);
			    	}else {
			    		result = -99;
			    	}
				
			    }else if("U".equals(couponInfoVO.getEditMode())) {
			    	if(couponInfoMapper.couponIsuRnnoCount(couponInfoVO) == 0) {
						log.debug("updatetCouponInfo update: " + couponInfoVO);
						couponInfoMapper.updateCouponInfoBas(couponInfoVO);
						commonService.insertTableHistory("PROMTN_COUPON_INFO_BAS", couponInfoVO);
			    	}else {
			    		result = -99;
			    	}
			    }
			    result = 1;
			//} else {
			//    result = -99;
			//}
		}
		return result;
	}
	
	@Override
	public int deleteCouponInfo(List<CouponInfoVO> couponInfoVOList) throws Exception {
		int result = 0;
		
		try {
			for(CouponInfoVO couponInfoVO : couponInfoVOList) {
				
				Account account = userInfoUtil.getAccountInfo();
				String userId ="";
				
				if(account != null) {
					userId = account.getId();
				}
				
				couponInfoVO.setFrstRegisterId(userId);
				couponInfoVO.setLastChangerId(userId);
				couponInfoVO.setCouponBeginDe(couponInfoVO.getCouponBeginDe().replaceAll("-", ""));
				couponInfoVO.setCouponEndDe(couponInfoVO.getCouponEndDe().replaceAll("-", ""));
				couponInfoVO.setPromtnCouponUseAt("N");
				
				// 만약 사용여부를 'N' 로 업데이트면 연관된 하위 테이블이 사용 기간이 지났거나 사용여부가 'Y' 로 되어있는지 체크 해라 
				if("N".equals(couponInfoVO.getPromtnCouponUseAt())) {
					int cntResult = couponInfoMapper.checkPromtnCouponInfoBas(couponInfoVO);
					
					if(cntResult > 0) {
						throw new Exception("현재 진행중인 쿠폰입니다.");				
					}
				}
				
				log.debug("deleteCouponInfo Delete: " + couponInfoVO);
				couponInfoMapper.deleteCouponInfoBas(couponInfoVO);
			
			}
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
		
		return result;
	}	
	
	@Override
	public List<CmmnCodeVO> selectBrandCode(CouponInfoVO couponInfoVO) throws Exception {
		return couponInfoMapper.selectBrandCode(couponInfoVO);
	}
	
	@Override
	public List<CommonCodeVO> selectPromtnNoList(CouponInfoVO couponInfoVO) throws Exception {
		return couponInfoMapper.selectPromtnNoList();
	}
	
	@Override
	public List<CommonCodeVO> selectPromtnNoList() throws Exception {
		return couponInfoMapper.selectPromtnNoList();
	}
	
	@Override
	public List<CommonCodeVO> selectCouponEventNoList(CouponInfoVO couponInfoVO) throws Exception {
		return couponInfoMapper.selectCouponEventNoList(couponInfoVO);
	}
	
	@Override
	public String createCouponIsuRnno(CouponInfoVO couponInfoVO) throws Exception {
	    int n = 16;				//난수길이
	    char[] isuRnno = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
			'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 
			'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
	    //String isuRnno ="";
	    
	    Random rd = new Random();
	    StringBuffer sb = new StringBuffer();

	    for(int i=0; i<n; i++) {				
		char ch = isuRnno[rd.nextInt(isuRnno.length)];
		sb.append(ch);
	    }
	    	return sb.toString();
	}
	
	@Override
	public List<CommonCodeVO> selectCouponNoList() throws Exception {
		return couponInfoMapper.selectCouponNoList();
	}

}