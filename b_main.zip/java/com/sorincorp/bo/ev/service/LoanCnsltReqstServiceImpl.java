package com.sorincorp.bo.ev.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.ev.mapper.LoanCnsltReqstMapper;
import com.sorincorp.bo.ev.model.LoanCnsltReqstVO;
import com.sorincorp.comm.util.CryptoUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * LoanCnsltReqstServiceImpl.java
 * @version
 * @since 2022. 9. 14.
 * @author jaylee
 */
@Slf4j
@Service
public class LoanCnsltReqstServiceImpl implements LoanCnsltReqstService{
	
	@Autowired
	private LoanCnsltReqstMapper loanCnsltReqstMapper;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	

	@Override
	public List<LoanCnsltReqstVO> selectLoanCnsltReqst(LoanCnsltReqstVO vo) throws Exception {
		// TODO Auto-generated method stub
		List<LoanCnsltReqstVO> loanCnsltReqstList = loanCnsltReqstMapper.selectLoanCnsltReqst(vo);
		String loanRequstTlphonNo = ""; 
		
		for (int pos= 0; pos < loanCnsltReqstList.size(); pos++) {
			//log.debug("신청자 전화번호 암호화 해제 전 ============>" + loanRequstTlphonNo);
			loanRequstTlphonNo = CryptoUtil.decryptAES256(loanCnsltReqstList.get(pos).getLoanRequstTlphonNo());
			//log.debug("신청자 암호화 암호화 해제 후 ============>" + loanRequstTlphonNo);
			loanCnsltReqstList.get(pos).setLoanRequstTlphonNo(loanRequstTlphonNo);
			
			
		}
		
		return loanCnsltReqstList;
	}


	@Override
	public void updateLoanCnsltReqst(List<LoanCnsltReqstVO> loanCnsltReqstVO) {
		// TODO Auto-generated method stub
		for (int pos= 0; pos < loanCnsltReqstVO.size(); pos++) {
			loanCnsltReqstVO.get(pos).setLastChangerId(userInfoUtil.getAccountInfo().getId());
			loanCnsltReqstMapper.updateLoanCnsltReqst(loanCnsltReqstVO.get(pos));
		}
	}


	@Override
	public void deleteLoanCnsltReqst(List<LoanCnsltReqstVO> loanCnsltReqstVO) {
		// TODO Auto-generated method stub
		for (int pos= 0; pos < loanCnsltReqstVO.size(); pos++) {
			loanCnsltReqstVO.get(pos).setLastChangerId(userInfoUtil.getAccountInfo().getId());
			loanCnsltReqstMapper.deleteLoanCnsltReqst(loanCnsltReqstVO.get(pos));
		}
		
		
	}
	
	

}