package com.sorincorp.bo.ev.model;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class EntrpsIsuVO extends EntrpsCouponVO {
	private static final long serialVersionUID = 1L;

	/**
	 * 쿠폰 상세 번호
	 */
	private String couponDtlNo;  
	/**
	 * 업체 번호
	 */
	private String entrpsNo;  
	/**
	 * 회원 번호
	 */
	private String mberNo;  
	/**
	 * 쿠폰 상태 코드
	 */
	private String couponSttusCode;  
	/**
	 * 쿠폰 적용 주문 번호
	 */
	private String couponApplcOrderNo;  
	/**
	 * 쿠폰 할인 적용 금액
	 */
	private int couponDscntApplcAmount;  
	/**
	 * 쿠폰 발급 코드
	 */
	private String couponIssuCode;  
	/**
	 * 배송비 권역 정보
	 */
	private String dlvrfDstrctInfo;  
	/**
	 * 삭제 일시
	 */
	private java.sql.Timestamp deleteDt;  
	/**
	 * 삭제 사유
	 */
	private String deleteResn;  
	/**
	 * 적용 주문 타입 코드
	 */
	private String orderTyCode;
	/**
	 * 쿠폰 타입 코드
	 */
	private String couponTyCode;
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 쿠폰 발행 업체 내역
	 */
	private List<EntrpsCouponVO> entprsIsuList;

	/**
	 * 적용기간, 임시저장 변경 여부
	 */
	boolean couponChgAt;
	/**
	 * 모달 상태 (insert/update)
	 */
	private String modalPageStatus;
	
	
}