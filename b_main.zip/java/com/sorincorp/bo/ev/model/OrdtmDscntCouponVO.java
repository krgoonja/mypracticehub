package com.sorincorp.bo.ev.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class OrdtmDscntCouponVO extends CommonVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4412678802450029492L;

	/******  JAVA VO CREATE : MB_ENTRPS_GRAD_STDR_PURCHS_QY()                                                                                ******/
	/**
	 * 구매수량 순번
	*/
	private String purchsQySn;
	
	/**
	 * 첫번째 등급 구매 수량
	*/
	private String firstGradPurchsQy;
	
	/**
	 * 두번째 등급 구매 수량
	*/
	private String scndGradPurchsQy;
	
	/**
	 * 세번째 등급 구매 수량
	*/
	private String thirdGradPurchsQy;
	
	/**
	 * 네번째 등급 구매 수량
	*/
	private String fourthGradPurchsQy;
	
	/**
	 * 삭제 여부
	*/
	private String deleteAt;
	
	/**
	 * 삭제 일시
	*/
	private String deleteDt;
	
	/**
	 * 최초 등록자 아이디
	*/
	private String frstRegisterId;
	
	/**
	 * 최초 등록 일시
	*/
	private String frstRegistDt;
	
	/**
	 * 최종 변경자 아이디
	*/
	private String lastChangerId;
	
	/**
	 * 최종 변경 일시
	*/
	private String lastChangeDt;
	
	/******  JAVA VO CREATE : CP_ATMC_ISU_COUPON_INFO_BAS()                                                                                  ******/

	/**
	 * 등록 순번
	*/
	private String registSn; 
	
	/**
	 * 자동발행 조건 명
	*/
	private String atmcIsuCndNm; 
	
	/**
	 * 프로모션 번호
	*/
	private int promtnNo; 
	
	/**
	 * 쿠폰 번호
	*/
	private String couponNo; 
	
	/**
	 * 적용 주문 타입 코드
	*/
	private String orderTyCode; 
	
	/**
	 * 쿠폰 타입 코드
	*/
	private String couponTyCode; 
	
	/**
	 * 금속 코드
	*/
	private String metalCode; 
	
	/**
	 * 브랜드 코드
	*/
	private String brandCode; 
	
	/**
	 * 톤수
	*/
	private int mt; 
	
	/**
	 * 단가 할인 금액 1
	*/
	private int untpcDscntAmountFst; 
	
	/**
	 * 단가 할인 금액 2
	 */
	private int untpcDscntAmountSnd; 
	
	/**
	 * 단가 할인 금액 3
	 */
	private int untpcDscntAmountTrd; 
	
	/**
	 * 쿠폰 유효월
	*/
	private String couponValidMth; 

	/**
	 * 자동발행 조건 코드
	*/
	private String atmcIsuCndCode; 


}