package com.sorincorp.bo.ev.model;
import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

/**
 * LoanCnsltReqstVO.java
 * @version
 * @since 2022. 9. 14.
 * @author jaylee
 */
@Data
public class LoanCnsltReqstVO extends CommonVO {
	
    /**
     * 사업자 등록 번호
    */
    private String bsnmRegistNo;
    /**
     * 업체명 한글
    */
    private String entrpsnmKorean;
    /**
     * 개인 정보 수집 이용 동의 여부
    */
    private String indvdlInfoColctUseAgreAt;
    /**
     * 개인 정보 수집 이용 동의 일시
    */
    private java.sql.Timestamp indvdlInfoColctUseAgreDt;
    /**
     * 대출 요청 이름
    */
    private String loanRequstNm;
    /**
     * 대출 요청 전화번호
    */
    private String loanRequstTlphonNo;
    /**
     * 대출 상담 등록일
    */
    private java.sql.Timestamp loanRequstRegistDt;
    /**
     * 대출 상담 완료 여부
    */
    private String loanCnsltComptAt;
    /**
     * 대출 상담 담당자
    */
    private String loanCnsltNm;
    /**
     * 대출 상담 담당자 메모
    */
    private String loanCnsltNmMemo;
    /**
     * 대출 상담 완료 일시
    */
    private java.sql.Timestamp loanCnsltComptDt;
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 회원 번호
    */
    private String mberNo;
    /**
     * 로그인 요청 여부
    */
    private String loginRequstAt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경자 일시
    */
    private java.sql.Timestamp lastChangeDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    
    /**
     * 검색조건 : 검색 시작일
     */
    private String searchDateFrom;
    /**
     * 검색조건 : 검색 종료일
     */
    private String searchDateEnd;
    
    /**
     * 검색조건 : 대출 상담 완료 여부
     */
    private String searchLoanCnsltComptAt;
    
}