package com.sorincorp.bo.ev.model;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class CouponInfoVO extends CommonVO {
	
	/**
	 * InsertAndUpdate</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface InsertAndUpdate {};

	private static final long serialVersionUID = -8844195686045139146L;
	
	/** 서치 파라미터*/
	private String searchPromtnNm;			//프로모션 명
	private String searchCouponNm;			//쿠폰 명
	private String searchDateFrom;			//시작일
	private String searchDateEnd;			//종료일
	private String searchUseYn;			//사용여부
	private String searchCouponSeCode;		//쿠폰구분코드
	private String searchMetalCode;			//메탈코드
	
	/** 셋팅 파라미터*/
	private String setCouponType;
	
	/** 순번 */    
    private int rownum;
    
    /** 쿠폰 이벤트 번호 */
    private int couponEventNo; 

    /** 프로모션 번호 */
    private String promtnNo; 
    
    /** 프로모션 명 */
    private String promtnNm; 
    
    /** 쿠폰 명 */
    @NotBlank(groups=InsertAndUpdate.class, message = "쿠폰 명을 입력해 주세요.")
    @Size(groups=InsertAndUpdate.class, min=0, max=30, message = "쿠폰 명은 100자 이하로 입력해 주세요.")
    private String couponNm;
    
    /** 쿠폰 타입 */
    private String couponType;
    
    /** 쿠폰 구분 코드*/
    private String couponSeCode;
    
    /** 쿠폰 발행난수*/
    private String couponIsuRnno;
    
    /** 쿠폰 적용 메탈 코드 */
    private String couponApplcMetalCode;
    
    /** 쿠폰 적용 브랜드 코드 */
    private String couponApplcBrandCode;
    
    private String couponApplcBrandCd;
    
    /** 쿠폰 할인 금액 */
    private String couponDscntAmount;
    
    /** 쿠폰 할인 율 */
    private String couponDscntRt;
    
    /** 쿠폰 발급 제한 수량 여부 */
    private String couponIssuLmttQyAt;
    
    /** 쿠폰 발급 제한 수량 */
    private String couponIssuLmttQy;
        
    /** 쿠폰 중복 사용 제한 수량 */
    private String couponDplctUseLmttQyAt;
    
    /** 쿠폰 중복 사용 제한 수량 */
    private String couponDplctUseLmttQy;
        
    /** 할인 최대 금액 제한 */
    private String dscntMxmmAmountLmtt;
    
    /** 배송비 쿠폰일 경우 적용차수 */
    private String dlvrfCouponApplcOdr;
    
    /** 쿠폰의 중복가능 여부(배송비+상품) */
    private String couponDplctPossAt;
    
    /** 쿠폰 시작 날짜 */
    private String couponBeginDe;
    
    /** 쿠폰 종료 날짜 */
    private String couponEndDe;
    
    /** 최초 등록자 아이디 */
    private String frstRegisterId;

    /** 최초 등록 일시 */
    private String frstRegistDt;

    /** 최종 변경자 아이디 */
    private String lastChangerId;

    /** 최종 변경 일시 */
    private String lastChangeDt;
    
    /** 쿠폰 사용 여부*/
    private String promtnCouponUseAt;
    
    /** 저장 모드 : A:인서트 U:업데이트 */
    private String modalPageStatus;
    
    /** 저장 모드 : I:인서트 U:업데이트 D:델레트*/
    private String editMode;
    
    private String noticeUpendexpsrBgnde;
    
}