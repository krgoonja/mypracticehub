package com.sorincorp.bo.ev.model;

import com.sorincorp.comm.model.CommonVO;
import lombok.Data;

@Data
public class CouponVO extends CommonVO  {
    /**
     * InsertAndUpdate</br>
     * validation groups를 지정하기 위한 빈 interface
     */
    public interface InsertAndUpdate {};

    private static final long serialVersionUID = -4327903983658959496L;
    /* JAVA VO CREATE : COUPON_INFO_BAS()  */
    /**
     * 순번
     */
    public int rownum;
    /**
     * 쿠폰번호
     */
    private String couponNo;
    /**
     * 쿠폰일련번호
     */
    private String couponSn;
    /**
     *  기업명
     */
    private String entrpsNm;
    /**
     * 쿠폰 구분 코드
     */
    private String couponTyCode;
    /**
     * 쿠폰 구분명
     */
    private String couponTyNm;
    /**
     * 주문 구분 코드
     */
    private String sleMthdCode;
    /**
     * 주문 구분명
     */
    private String sleMthdNm;
    /**
     * 쿠폰 명
     */
    private String couponNm;
    /**
     * 메탈 코드
     */
    private String metalCode;
    /**
     * 메탈 명
     */
    private String metalNm;
    /**
     * 브랜드 코드
     */
    private String brandCode;
    /**
     * 배송지 권역
     */
    private String dlvrfDstrctInfo;
    /**
     * 배송지 권역 이름
     */
    private String dlvrfDstrctNm;
    /**
     * 발행내역
     */
    private String isuCouponNm;
    /**
     * 임시 저장 여부
     */
    private String tmprStreAt;
    /**
     * 배송지
     */
    private String dlvrfInfo;
    /**
     * 중복 사용 여부
     */
    private String dplctAt;
    /**
     * 쿠폰 시작 일자
     */
    private String couponBgnde;
    /**
     * 쿠폰 종료 일자
     */
    private String couponEndde;
    /**
     * 쿠폰 적용 일자
     */
    private String couponPd;
    /**
     * 발행일자
     */
    private String isuDt;
    /**
     * 발행자 아이디
     */
    private String isuId;
    /**
     * 쿠폰 상태 코드
     */
    private String couponSttusCode;
    /**
     * 쿠폰 상태명
     */
    private String couponSttusNm;
    /**
     * 쿠폰 적용 주문 번호
     */
    private String couponApplcOrderNo;
    /**
     * 판매가
     */
    private String slepc;
    /**
     * 쿠폰 할인 적용 금액
     */
    private String couponDscntApplcAmount;
    /**
     * 검색 조건 : 쿠폰 타입
     */
    private String searchCouponType;
    /**
     * 검색 조건 : 사용 여부
     */
    private String searchUseAt;
    /**
     * 검색 조건 : 정렬 조건
     */
    private String searchSortCondition;
    /**
     *  최종변경자 아이디
     */
    private String lastChangerId;
    /**
     *  삭제 사유
     */
    private String deleteResn;

    /****** JAVA VO CREATE : CP_COUPON_INFO_BAS() ******/

    /**
     * 톤수
     */
    private String mt;

    /**
     * 발행 제한 금액
     */
    private String isuLmttAmount;

    /**
     * 발행 제한 수량
     */
    private String isuLmttQuantity;

    /**
     * 사용 금액
     */
    private String totalAmount;

    /**
     * 사용 수량
     */
    private String totalQuantity;

    /**
     * 최초 등록자 아이디
     */
    private String frstRegisterId;

    /**
     * 최초 등록 일시
     */
    private String frstRegistDt;

    /**
     * 최종 변경 일시
     */
    private String lastChangeDt;

    /**
     * 삭제 일시
     */
    private String deleteDt;

    /**
     * 삭제 여부
     */
    private String deleteAt;

    /**
     * 사용 완료 수량
     */
    private String usedTotalQuantity;		// 실 주문에 사용된 쿠폰 수량 (쿠폰 상태 코드 / 02 : 사용완료, 05 : 사용중 )

    /**
     * 발행 가능 잔액
     */
    private String isuPossBlce;				// 발행 제한 금액 - 사용 금액 ( isuLmttAmount - totalAmount )

    /**
     * 사용 완료 총액
     */
    private String usedTotalAmount;			// 실 주문에 사용된 쿠폰 총액 (쿠폰 상태 코드 / 02 : 사용완료, 05 : 사용중 )


    /** CP_COUPON_INFO_DTL*/
    /**
     * 단가 쿠폰 총 할인 금액
     */
    private int untpcCouponTotalAmount;

    /**
     * 단가 쿠폰 발행 단가
     */
    private int untpcDscntAmount;

}
