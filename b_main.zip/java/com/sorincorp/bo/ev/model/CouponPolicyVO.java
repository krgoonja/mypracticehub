package com.sorincorp.bo.ev.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class CouponPolicyVO extends CommonVO {

	private static final long serialVersionUID = 5150182438259377314L;

	/**
	 * InsertAndUpdate</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface InsertAndUpdate {
	};
	
	
	/******  JAVA VO CREATE : EV_PROMTN_INFO_BAS() ******/	
	
	/**
	 * 프로모션 번호
	 */
	private int promtnNo;
	
	/**
	 * 프로모션 명
	 */
	private String promtnNm;
	
	/**
	 * 프로모션 구분코드
	 */
	private String promtnSeCode;
	
	/**
	 * 프로모션 시작날짜
	 */
	private String promtnBeginDe;
	
	/**
	 * 프로모션 종료날짜
	 */
	private String promtnEndDe;
	
	/**
	 * 쿠폰 타입 코드
	 */
	private String couponTyCode;

	
	/****** JAVA VO CREATE : CP_COUPON_INFO_BAS() ******/
	
	/**
	 * 순서
	 */
	private String rowNum;				//리얼그리드 순번

	/**
	 * 쿠폰번호
	 */
	private String couponNo;

	/**
	 * 쿠폰명
	 */
	private String couponNm;

	/**
	 * 톤수
	 */
	private String mt;

	/**
	 * 톤수
	 */
	private String test;
	
	/**
	 * 발행 제한 금액
	 */
	private String isuLmttAmount;

	/**
	 * 발행 제한 수량
	 */
	private String isuLmttQuantity;

	/**
	 * 사용 금액
	 */
	private String totalAmount;

	/**
	 * 사용 수량
	 */
	private String totalQuantity;

	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;

	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;

	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;

	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;

	/**
	 * 삭제 일시
	 */
	private String deleteDt;

	/**
	 * 삭제 여부
	 */
	private String deleteAt;

	/**
	 * 사용 완료 수량
	 */
	private String usedTotalQuantity;		// 실 주문에 사용된 쿠폰 수량 (쿠폰 상태 코드 / 02 : 사용완료, 05 : 사용중 )

	/**
	 * 발행 가능 잔액
	 */
	private String isuPossBlce;				// 발행 제한 금액 - 사용 금액 ( isuLmttAmount - totalAmount )

	/**
	 * 사용 완료 총액
	 */
	private String usedTotalAmount;			// 실 주문에 사용된 쿠폰 총액 (쿠폰 상태 코드 / 02 : 사용완료, 05 : 사용중 )

	
	/****** JAVA VO CREATE : CP_COUPON_INFO_DTL() ******/

	/**
	 * 쿠폰 상세 번호
	 */
	private String couponDtlNo;

	/**
	 * 적용 주문 타입 코드
	 */
	private String orderTyCode;

	/**
	 * 지정 BL 번호
	 */
	private String appnBlNo;

	/**
	 * 단가 할인 금액
	 */
	private String untpcDscntAmount;

	/**
	 * 단가 쿠폰 총 할인 금액
	 */
	private String untpcCouponTotalAmount;

	/**
	 * 총액 할인 금액
	 */
	private String totalUntpcAmount;

	/**
	 * 쿠폰 시작 일시
	 */
	private String couponBgnde;

	/**
	 * 쿠폰 종료 일시
	 */
	private String couponEndde;

	/**
	 * 중복 사용 여부
	 */
	private String dplctAt;

	/**
	 * 임시 저장 여부
	 */
	private String tmprStreAt;

	/**
	 * 발행 일시
	 */
	private String isuDt;

	/**
	 * 발행자 아이디
	 */
	private String isuId;

	/**
	 * 배송비 적용 차수
	 */
	private String dlvrfApplcOdr;

	/**
	 * 배송비 권역 정보
	 */
	private String dlvrfDstrctInfo;

	/**
	 * 주문 일
	 */
	private String orderDe;

	/**
	 * 업체 명
	 */
	private String entrpsnmkorean;

	/**
	 * 쿠폰 일련 번호
	 */
	private String couponSn;

	/**
	 * 쿠폰 할인 적용 금액
	 */
	private String couponDscntApplcAmount;

	/**
	 * 쿠폰 상태 코드 명
	 */
	private String couponSttusCodeNm;

	/**
	 * 쿠폰 상태 코드
	 */
	private String couponSttusCode;

	/**
	 * 상태 (저장 : 'I', 수정 : 'U', 삭제 : 'D', 변경 없음 : 'N')
	 */
	private String state;

	/**
	 * 단가(UntPcCoupon), 배송비(DlvyCoupon) 상태 
	 */
	private String activeTabVal;

}