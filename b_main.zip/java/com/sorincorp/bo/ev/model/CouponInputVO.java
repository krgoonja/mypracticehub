package com.sorincorp.bo.ev.model;

import java.util.Date;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class CouponInputVO extends CommonVO {

	private static final long serialVersionUID = -8844195686045139146L;
	
	/** 서치 파라미터*/
	private String searchKeyword;			//쿠폰 명
	private String searchEntrpsNm;			//업체 명
	private String searchPromtnNm;			//프로모션 명
	private String searchCouponNm;			//쿠폰 명
	private String searchDateFrom;			//시작일
	private String searchDateEnd;			//종료일
	private String searchUseYn;			//사용여부
	private String searchCouponSeCode;		//쿠폰구분코드
	private String searchMetalCode;			//메탈코드

    /** 순번 */    
    private int rownum;	
	
    /** 쿠폰 일련번호 */
    private int couponSeqNo;	
    
    /** 쿠폰이벤트 번호 */
    private int couponEventNo;
    
    /** 쿠폰 사용여부 */
    private String couponUseAt;
    
    /** 업체 번호 */
    private String entrpsNo;    
    
    /** 회원 번호 */
    private String mberNo;    
    
    /** 쿠폰 적용 주문번호 */
    private String couponApplcOrderNo;
    
    /** 쿠폰 적용 금액 */
    private int couponDscntApplcAmount;
    
    /** 쿠폰 사용자 아이디 */
    private String couponUseId;
    
    /** 쿠폰 사용 일시 */
    private Date couponUseDt;
    
    /** 프로모션  번호 */
    private int promtnNo;
    
    /** 쿠폰 이름 */
    private String couponNm;
    
    /** 쿠폰 타입 */
    private String couponType;
    
    /** 쿠폰 구분 코드*/
    private String couponSeCode;
    
    /** 쿠폰 적용 브랜드코드 */  
    private String couponApplcBrandCode;

    /** 쿠폰 할인 금액    */  
    private int couponDscntAmount;
    
    /** 쿠폰 할인율      */  
    private int couponDscntRt;
    
    /** 쿠폰 발급 제한 수량 여부   */  
    private String couponIssuLmttQyAt;
    
    /** 쿠폰 발급 제한 수량      */  
    private int couponIssuLmttQy;
    
    /** 쿠폰 중복 제한 수량      */  
    private int couponDplctUseLmttQy;
    
    /** 쿠폰 적용 메탈코드 */  
    private String couponApplcMetalCode;
    
    /** 할인 최대 금액 제한 */  
    private int dscntMxmmAmountLmtt;
    
    /** 배송비 쿠폰 적용차수 */  
    private String dlvrfCouponApplcOdr;
    
    /** 쿠폰 중복 가능 여부 */  
    private String couponDplctUseLmttQyAt;
    
    /** 쿠폰 등록 여부 */
    private String RegistAt;
    
    /** 쿠폰 등록 일시 */
    private String RegistDt;
    
    /** 최종 등록자 아이디 */
    private String FrstRegisterId;
    
    /** 최종 등록 일시 */
    private Date FrstRegistDt;
    
    /** 최초 변경자 아이디 */  
    private String lastChangerId;
    
    /** 최초 변경 일시 */  
    private Date lastChangeDt;
    
    /** 사용 여부 */  
    private String promtnCouponUseAt;
    
    /** 발행 난수 */  
    private String couponIsuRnno;
 
    /** 업체 이름 */
    private String entrpsnmKorean;
    
    /** 프로모션 이름 */
    private String promtnNm;
    
    /** 저장 모드 : I:인서트 U:업데이트 */
    private String editMode;
    
}