package com.sorincorp.bo.ev.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class EntrpsCouponVO extends CommonVO {
	
	/** 서치 파라미터*/
	private String searchCouponTyCode;				//프로모션 명
	private String searchMetalCode;					//쿠폰 명
	private String searchBrandCode;					//시작일
	private String searchTmprStreAt;				//종료일
	private String searchCouponSttusCode;			//사용여부
	private String searchDateFrom;					//쿠폰구분코드
	private String searchDateEnd;					//메탈코드
	private String searchEntrpsnmKorean;			//업체명
	private String searchCouponNo;					//쿠폰번호
	private String searchOrderNo;					//주문번호
	private String searchCondition;

/** CP_COUPON_INFO_DTL*/
	/**
	 * 쿠폰 상세 번호
	 */
	private String couponDtlNo; 
	/**
	 * 쿠폰 번호
	 */
	private String couponNo; 
	/**
	 * 적용 주문 타입 코드
	 */
	private String orderTyCode;
	/**
	 * 적용 주문 타입 코드 명
	 */
	private String orderTyName;
	/**
	 * 쿠폰 타입 코드
	 */
	private String couponTyCode;
	/**
	 * 쿠폰 타입 코드
	 */
	private String couponTyCodeNm;
	/**
	 * 쿠폰 타입 코드 명
	 */
	private String couponTyName;
	/**
	 * 금속
	 */
	private String metalCode;
	/**
	 * 금속명
	 */
	private String metalName;
	/**
	 * 브랜드코드
	 */
	private String brandCode;  
	/**
	 * 톤수
	 */
	private int mt;  
	/**
	 * 지정 BL 번호
	 */
	private String appnBlNo;  
	/**
	 * 단가 할인 금액
	 */
	private String untpcDscntAmount;
	/**
	 * 단가 쿠폰 총 할인 금액
	 */
	private int untpcCouponTotalAmount;
	/**
	 * 총액 할인 금액
	 */
	private int totalUntpcAmount;
	/**
	 * 쿠폰 시작 일시
	 */
	private String couponBgnde;
	/**
	 * 쿠폰 종료 일시
	 */
	private String couponEndde;
	/**
	 * 중복 사용 여부
	 */
	private String dplctAt; 
	/**
	 * 임시 저장 여부
	 */
	private String tmprStreAt; 
	/**
	 * 발행 일자
	 */
	private String isuDt; 
	/**
	 * 발행자 아이디
	 */
	private String isuId; 
	/**
	 * 배송비 적용 차수
	 */
	private int dlvrfApplcOdr; 
	/**
	 * 배송비 권역 정보
	 */
	private String dlvrfDstrctInfo; 
	/**
	 * 삭제 여부
	 */
	private String deleteAt;  
	/**
	 * 삭제 일시
	 */
	private java.sql.Timestamp deleteDt;  
	/**
	 * 쿠폰명
	 */
	private String couponNm;  
	
/** CP_COUPON_ISU_BAS*/
	/**
	 * 쿠폰 일련 번호
	 */
	private String couponSn;  
    /**
    * 업체 번호
   */
   private String entrpsNo; 
    /**
    * 쿠폰 적용 주문 번호
   */
   private String couponApplcOrderNo; 
   /**
	 * 쿠폰 할인 적용 금액
	 */
	private int couponDscntApplcAmount;
	/**
	 * 쿠폰 발급 코드
	 */
   private String couponIssuCode;    
   
   /**
    * 자동 재발행 여부
    */
   private String atmIsgnAt;    
   

/** EV_PROMTN_INFO_BAS*/	
	/**
	 * 프로모션 명
	 */
	private String promtnNm; 
	/**
	 * 프로모션 시작날짜
	 */
	private String promtnBeginDe; 
	
	
/** 공통VO*/
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId; 
	/**
	 * 최초 등록 일시
	 */
	private java.sql.Timestamp frstRegistDt; 
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId; 
	/**
	 * 최종 변경 일시
	 */
	private java.sql.Timestamp lastChangeDt; 
	/**
	 * 최종 변경자 아이디
	 */
	private String fieldName; 
    /**
    * 쿠폰 사용 여부
   */
   private String couponUseAt; 
    /**
    * 쿠폰 사용자 아이디
   */
   private String couponUseId; 
    /**
    * 쿠폰 사용 일시
   */
   private java.sql.Timestamp couponUseDt; 
   /**
   * 업체명 한글
   */
   private String entrpsnmKorean;
   /**
   * 배송지
   */
   private String receptEntrpsAdres;     
   /**
   * 쿠폰 상태 코드
   */
   private String couponSttusCode; 
   /**
   * 주문 일자
   */
   private String orderDe;    
   /**
   * 쿠폰 적용 기간
   */
   private String couponPeriod;   
   /**
   * 발행 제한 금액
   */
   private String isuLmttAmount;
   /**
   * 발행 제한 수량
   */
   private String isuLmttQuantity;
   /**
   * 사용 금액
   */
   private int totalAmount;
   /**
   * 사용 수량
   */
   private int totalQuantity;
   /**
    * 발행 가능 잔액
    */
   private String isPossBlce;
	/**
	 * 발행 가능 수량
	 */
	private String isPossPrchas;
   /**
	 * 발행 쿠폰명
	 */
   private String isuCouponNm; 
	/**
	 * 업체 발행수량
	 */
	private int entrpsIsuCount; 
	/**
	 * 모달 상태 (insert/update)
	 */
	private String modalPageStatus;
	/**
	 * 사용중인 쿠폰 수
	 */
	private String couponUseCount;
	/**
	 * 회원번호
	 */
	private String mberNo;
	/**
	 * 휴대전화 번호
	 */
	private String moblphonNo;
	/**
	 * 삭제 이유
	 */
	private String deleteResn;

	
	/**
	 * 단가(UntPcCoupon), 배송비(UntPcCoupon) 상태 
	 */
	private String activeTabVal;


}