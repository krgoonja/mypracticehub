package com.sorincorp.bo.ev.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class CouponEntrpsAppnVO extends CommonVO {
	
	/**
	 * InsertAndUpdate</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface InsertAndUpdate {};

	private static final long serialVersionUID = -8844195686045139146L;
	
	/** 서치 파라미터*/
	private String searchCouponNm;
	private String searchDateFrom;
	private String searchDateEnd;
	private String searchUseYn;
	private String setCouponType;
	private String searchPromtnNm;
	
	/** 순번 */
	private int rownum;
	
	/** 프로모션 번호 */
    private int promtnNo;
	
	/** 업체 지정 쿠폰 번호 */    
    private int couponEntrpsAppnNo;

    /** 쿠폰 이벤트 번호 */  
    private int couponEventNo;
    
    /** 업체 번호 */  
    private String entrpsNo;
    
    /** 업체 명 한글 */  
    private String entrpsnmKorean;
	
    /** 업체 명 영어 */  
    private String entrpsnmEng;
    
    /** 쿠폰 등록 여부 */  
    private String registAt;
    
    /** 쿠폰 등록 일시 */  
    private String registDt;
    
    /** 최초 등록자 아이디 */  
    private String frstRegisterId;
    
    /** 최초 등록 일시 */  
    private String frstRegistDt;
}