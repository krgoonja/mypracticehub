package com.sorincorp.bo.ev.mapper;

import com.sorincorp.bo.ev.model.CouponVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CouponMapper {

	List<CouponVO> getCouponIsuDataList(CouponVO couponVO);

	int getCouponIsuDataListTotCnt(CouponVO couponVO);

	public void deleteCouponIsuData(CouponVO couponVO) throws Exception;

	public void insertCouponIsuBasHst(CouponVO couponVO) throws Exception;

	public void updateCouponPolicyInfo(CouponVO couponVO) throws Exception;

	CouponVO getCouponNo(CouponVO couponVO) throws Exception;
}