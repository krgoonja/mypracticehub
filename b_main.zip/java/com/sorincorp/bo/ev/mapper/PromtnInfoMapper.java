package com.sorincorp.bo.ev.mapper;

import java.util.List;

import com.sorincorp.bo.co.model.CmmnCodeVO;
import com.sorincorp.bo.ev.model.PromtnInfoVO;
import com.sorincorp.bo.ev.model.PromtnNewYearVO;

public interface PromtnInfoMapper {

	List<CmmnCodeVO> selectPromtnSeCodeList();
	
	List<CmmnCodeVO> selectCouponTyCodeList();

	List<PromtnInfoVO> getPromtnInfoList(PromtnInfoVO promtnInfoVO);

	int getPromtnInfoListTotCnt(PromtnInfoVO promtnInfoVO);

	/**
	 * <pre>
	 * 처리내용: 프로모션을 추가한다.
	 * </pre>
	 * @date 2023. 03. 30.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 03. 30.			sein					최초작성
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return int
	 * @throws Exception
	 */
	int insertPromtnInfo(PromtnInfoVO promtnInfoVO);

	/**
	 * <pre>
	 * 처리내용: 프로모션을 수정한다.
	 * </pre>
	 * @date 2023. 03. 30.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 03. 30.			sein					최초작성
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return int
	 * @throws Exception
	 */
	int updatePromtnInfo(PromtnInfoVO promtnInfoVO);

	/**
	 * <pre>
	 * 처리내용: 프로모션 정보를 조회한다.
	 * </pre>
	 * @date 2023. 03. 30.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 03. 30.			sein					최초작성
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return PromtnInfoVO
	 * @throws Exception
	 */
	PromtnInfoVO selectPromtnInfo(PromtnInfoVO promtnInfoVO);


	/**
	 * <pre>
	 * 처리내용: 프로모션 정보를 삭제한다.
	 * </pre>
	 * @date 2023. 04. 03.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 04. 03.			sein					최초작성
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return int
	 * @throws Exception
	 */
	int deletePromtnInfo(PromtnInfoVO promtnInfoVO);

	/**
	 * <pre>
	 * 처리내용: getPrizeWinnerList
	 * 		: 복주머니 당첨자 목록을 조회한다.
	 * </pre>
	 * @date 2024. 01. 29.
	 * @author cuko
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 29.		cuko				최초작성
	 * 2024. 01. 29.		hyunjin05			조회, 변경 추가
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return
	 * @throws Exception
	 */
	List<PromtnNewYearVO> getPrizeWinnerList(PromtnNewYearVO promtnNewYearVO);
	int getPrizeWinnerListTotCnt(PromtnNewYearVO promtnNewYearVO);
	String selectPromtnIdxInfo(PromtnNewYearVO promtnNewYearVO);
	
	/**
	 * <pre>
	 * 처리내용: 
	 * 		: 복주머니 당첨자의 상품권 전송 여부 상태를 변경한다.
	 * </pre>
	 * @date 2024. 01. 29.
	 * @author cuko
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 29.		cuko			최초작성
	 * 2024. 01. 29.		hyunjin05			조회, 변경 추가
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return
	 * @throws Exception
	 */
	int insertUpateprizeWinnerListData(PromtnNewYearVO promtnNewYearVO);
}
