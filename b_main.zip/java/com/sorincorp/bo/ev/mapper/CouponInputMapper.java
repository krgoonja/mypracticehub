package com.sorincorp.bo.ev.mapper;

import java.util.List;

import com.sorincorp.bo.ev.model.CouponInputVO;

public interface CouponInputMapper {
    
    List<CouponInputVO> getCouponInputList(CouponInputVO couponInputVO);
    
    int getCouponInputDetailList(CouponInputVO couponInputVO);
	
}