package com.sorincorp.bo.ev.mapper;

import java.util.List;

import com.sorincorp.bo.ev.model.EntrpsCouponVO;
import com.sorincorp.bo.ev.model.EntrpsIsuVO;

/**
*
* EntrpsCouponMapper.java
* 쿠폰관리 > 업체쿠폰발행 Mapper Class
*
* @version
* @since 2021. 9. 29.
* @author sumin
*/
public interface EntrpsCouponMapper {

	/**
	 *
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 업체쿠폰발행하기 : 목록조회
	 * </pre>
	 * @date 2023. 5. 1.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 1.				sumin				최초작성
	 * ------------------------------------------------
	 * @param 	EntrpsCouponVO
	 * @return	List<EntrpsCouponVO>
	 */
	List<EntrpsCouponVO> selectEntrpsCouponList(EntrpsCouponVO entrpsCouponVO);
	int selectAppnEntrpsListCnt(EntrpsCouponVO entrpsCouponVO);
	Integer selectEntrpsCouponListTotCnt(EntrpsCouponVO entrpsCouponVO);
	
	/**
	 *
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리/업체쿠폰발행하기 : 모달 : 발행가능 기업 목록조회
	 * </pre>
	 * @date 2023. 5. 1.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 1.				sumin				최초작성
	 * ------------------------------------------------
	 * @param 	EntrpsCouponVO
	 * @return	List<EntrpsCouponVO>
	 */
	List<EntrpsCouponVO> selectAppnEntrpsList(EntrpsCouponVO entrpsCouponVO);
	
	/**
	 *
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리/업체쿠폰발행하기 > 모달 : 쿠폰 정책 데이터 조회
	 * </pre>
	 * @date  2023. 5. 8.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 *  2023. 5. 8.				sumin				최초작성
	 * ------------------------------------------------
	 * @param 	EntrpsCouponVO
	 * @return	EntrpsCouponVO
	 */
	EntrpsCouponVO selectCouponInfo(EntrpsCouponVO entrpsCouponVO);
	
	/**
	 *
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리/업체쿠폰발행하기
	 * </pre>
	 * @date  2023. 5. 8.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 *  2023. 5. 8.				sumin				최초작성
	 * ------------------------------------------------
	 * @param 	EntrpsCouponVO
	 * @return	EntrpsCouponVO
	 */
	EntrpsCouponVO selectCouponDtl(EntrpsCouponVO entrpsCouponVO);	
	
	/**
	 *
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리/업체쿠폰발행하기 > 쿠폰 상세데이터 조회
	 * </pre>
	 * @date 2023. 5. 15.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 15.				sumin				최초작성
	 * ------------------------------------------------
	 * @param 	EntrpsCouponVO
	 * @return	List<EntrpsCouponVO>
	 */
	List<EntrpsCouponVO> getCouponAppnEntrps(EntrpsCouponVO entrpsCouponVO);
	int getCouponAppnEntrpsCnt(EntrpsCouponVO entrpsCouponVO); 
	
	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리 > 모달 > 쿠폰발행 :  쿠폰 디테일 테이블 insert
	 * </pre>
	 * @date 2023. 5. 19.
	 * @author 
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 *  2023. 5. 19.			sumin				최초작성
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return EntrpsCouponVO
	 * @throws Exception
	 */
	int insertCouponDtl(EntrpsIsuVO entrpsIsuVO);
	
	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리/업체쿠폰발행하기 > 모달 > 쿠폰발행 :  쿠폰발행테이블 insert
	 * </pre>
	 * @date  2023. 5. 19..
	 * @author 
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 *  2023. 5. 19.			sumin				최초작성
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return int
	 * @throws Exception
	 */
	int insertCouponIsu(EntrpsCouponVO entrpsCouponVO);
	
	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리/업체쿠폰발행하기 > 모달 > 기 발행된 업체 목록 조회
	 * </pre>
	 * @date  2023. 5. 19.
	 * @author 
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 *  2023. 5. 19.			sumin				최초작성
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return List<EntrpsCouponVO>
	 * @throws Exception
	 */
	List<EntrpsCouponVO> getCouponIsuCount(EntrpsCouponVO entrpsCouponVO);	
	
	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리/업체쿠폰발행하기 > 모달 > 쿠폰 마스터 테이블 update
	 * </pre>
	 * @date  2023. 5. 19.
	 * @author 
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 *  2023. 5. 19.			sumin				최초작성
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return int
	 * @throws Exception
	 */
	int updateCouponInfo(EntrpsIsuVO entrpsIsuVO);	
	
	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰발행정책/업체쿠폰발행하기 > 모달 > 쿠폰삭제
	 * </pre>
	 * @date 2023. 5. 26
	 * @author 
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 26				sumin				최초작성
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return int
	 * @throws Exception
	 */
	int deleteCouponDtl(EntrpsCouponVO entrpsCouponVO);
	
	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰발행정책/업체쿠폰발행하기 > 모달 > 쿠폰삭제
	 * </pre>
	 * @date 2023. 5. 26
	 * @author 
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 26				sumin				최초작성
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return int
	 * @throws Exception
	 */
	int deleteCouponIsuBas(EntrpsCouponVO entrpsCouponVO);

	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰상태코드에 따른 쿠폰 개수 조회 
	 * </pre>
	 * @date 2023. 5. 26
	 * @author 
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 26				sumin				최초작성
	 * ------------------------------------------------
	 * @param string
	 * @return int
	 * @throws Exception
	 */
	int getCouponCount(String couponDtlNo, String couponSttusCode);
	
	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰상태코드에 따른 사용쿠폰 개수 조회 
	 * </pre>
	 * @date 2023. 5. 26
	 * @author 
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 26				sumin				최초작성
	 * ------------------------------------------------
	 * @param string
	 * @return int
	 * @throws Exception
	 */
	int getUseCouponCount(String couponDtlNo);


	/**
	 * <pre>
	 * 쿠폰 발행 기업의 멤버 휴대전호번호 조회
	 * </pre>
	 * @date 2023. 8. 16
	 * @author
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 16				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return List<EntrpsCouponVO>
	 *
	 */
	List<EntrpsCouponVO> getMoblphonNo(EntrpsCouponVO entrpsCouponVO);

	/**
	 * <pre>
	 * 쿠폰발행 알림톡 발송을 위한 정보조회
	 * </pre>
	 * @date 2023. 8. 16
	 * @author
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 16				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return EntrpsCouponVO
	 *
	*/
	EntrpsCouponVO getCouponSmsInfo(EntrpsCouponVO entrpsCouponVO);
	
	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 업체쿠폰발행하기 > 업체쿠폰 수정하기
	 * </pre>
	 * @date 2023. 8. 23.
	 * @author 
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 *  2023. 8. 23.			sumin				최초작성
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return EntrpsCouponVO
	 * @throws Exception
	 */
	int updateCouponDtl(EntrpsIsuVO entrpsIsuVO);
	
}
