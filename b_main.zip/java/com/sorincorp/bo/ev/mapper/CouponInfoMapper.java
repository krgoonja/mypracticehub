package com.sorincorp.bo.ev.mapper;

import java.util.List;

import com.sorincorp.bo.co.model.CmmnCodeVO;
import com.sorincorp.bo.ev.model.CouponInfoVO;
import com.sorincorp.bo.ev.model.CouponInputVO;
import com.sorincorp.bo.ev.model.CouponEntrpsAppnVO;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;

public interface CouponInfoMapper {

	List<CouponInfoVO> getCouponInfoList(CouponInfoVO couponInfoVO);
	
	int getCouponInfoListTotCnt(CouponInfoVO couponInfoVO);
	
	int insertCouponInfoBas(CouponInfoVO couponInfoVO);
	
	int updateCouponInfoBas(CouponInfoVO couponInfoVO);
		
	int deleteCouponInfoBas(CouponInfoVO couponInfoVO);	
	
	List<CmmnCodeVO> selectBrandCode(CouponInfoVO couponInfoVO);
	
	List<CommonCodeVO> selectPromtnNoList(CouponInfoVO couponInfoVO);

	List<CommonCodeVO> selectPromtnNoList();
	
	int checkPromtnCouponInfoBas(CouponInfoVO couponInfoVO);	
	
	//업체지정 쿠폰 	
	int getCouponEntrpsAppnListTotcnt(CouponEntrpsAppnVO couponEntrpsAppnVO);
	
	List<CouponEntrpsAppnVO> getCouponEntrpsAppnList(CouponEntrpsAppnVO couponEntrpsAppnVO);
	
	List<CommonCodeVO> selectCouponEventNoList(CouponInfoVO couponInfoVO);	
	
	int getCouponEntrpsAppnListTotcnt(CouponInputVO couponInputVO);
	
	List<CouponInputVO> getCouponEntrpsAppnList(CouponInputVO couponInputVO);
		
	int insertCouponEntrps(CouponEntrpsAppnVO couponEntrpsAppnVO);
	
	int deleteCouponEntrps(CouponEntrpsAppnVO couponEntrpsAppnVO);	
	
	int couponIsuRnnoCount(CouponInfoVO couponInfoVO);
	
	List<CouponInputVO> getCouponInputList(CouponInputVO couponInputVO);
	
	int getCouponInputListTotCnt(CouponInputVO couponInputVO);
	
	CouponInputVO getCouponDetailList(CouponInputVO couponInputVO);
	
	List<CommonCodeVO> selectCouponNoList();
}