package com.sorincorp.bo.ev.mapper;

import java.util.List;

import com.sorincorp.bo.ev.model.OrdtmDscntCouponVO;

public interface OrdtmDscntCouponMapper {

	// 회원_업체 등급 기준 구매 수량 리스트 조회
	List<OrdtmDscntCouponVO> OrdtmDscntCouponList(OrdtmDscntCouponVO ordtmDscntCouponVO) throws Exception;
	
	// 회원_업체 등급 기준 구매 수량 리스트 카운트
	Integer OrdtmDscntCouponListCnt(OrdtmDscntCouponVO ordtmDscntCouponVO) throws Exception;
	
	// 회원_업체 등급 기준 구매 수량 신규 생성
	Integer insertOrdtmDscntCouponVO(OrdtmDscntCouponVO ordtmDscntCouponVO) throws Exception;
	
	// 회원_업체 등급 기준 구매 수량 수정(삭제)
	Integer updatetOrdtmDscntCouponVO(OrdtmDscntCouponVO ordtmDscntCouponVO) throws Exception;
	
	// 프로모션_자동발행 쿠폰 정보 기본 이전 데이터 조회
	OrdtmDscntCouponVO getAtmcIsuCouponCouponVO(String atmcIsuCndCode) throws Exception;

	// 프로모션_자동발행 쿠폰 정보 기본 이전 데이터 수정(삭제)
	Integer updateAtmcIsuCouponCouponVO(OrdtmDscntCouponVO ordtmDscntCouponVO) throws Exception;
	
	// 프로모션_자동발행 쿠폰 정보 기본 신규 생성
	Integer insertAtmcIsuCouponCouponVO(OrdtmDscntCouponVO ordtmDscntCouponVO) throws Exception;
}