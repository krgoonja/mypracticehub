package com.sorincorp.bo.ev.mapper;

import java.util.List;

import com.sorincorp.bo.ev.model.CouponPolicyVO;

public interface CouponPolicyMapper {

	//생성 쿠폰 목록 리스트 조회
	List<CouponPolicyVO> getCouponPolicyList(CouponPolicyVO couponPolicyVO) throws Exception;

	//생성 쿠폰 목록 리스트 카운트
	Integer getCouponPolicyListTotCnt(CouponPolicyVO couponPolicyVO) throws Exception;

	//생성 쿠폰 목록 리스트 총 합
	CouponPolicyVO getTotalCouponPolicyList(CouponPolicyVO couponPolicyVO) throws Exception;

	//생성 쿠폰 목록 엑셀 리스트 조회
	List<CouponPolicyVO> getCouponPolicyExcelList(CouponPolicyVO couponPolicyVO) throws Exception;

	// 쿠폰 정책 생성
	Integer insertCouponPolicy(CouponPolicyVO couponPolicyVO) throws Exception;

	// 쿠폰 정책 수정
	Integer updateCouponPolicy(CouponPolicyVO couponPolicyVO) throws Exception;

	//프로모션에 대한 쿠폰 정책 발행 여부 확인
	Integer getChkPromnt(CouponPolicyVO couponPolicyVO) throws Exception;
	
	//쿠폰 정책에 대한 디테일 쿠폰 존재여부 확인
	Integer getChkDtl(CouponPolicyVO couponPolicyVO) throws Exception;

	//상세 쿠폰 - 발행 상태(임시 발행) 확인, 업체 발행 쿠폰 - 쿠폰 상태(미사용) 확인
	Integer chkCouponUse(CouponPolicyVO couponPolicyVO) throws Exception;

	//쿠폰 정책 삭제
	Integer deleteCouponPolicy(CouponPolicyVO couponPolicyVO) throws Exception;

	// 쿠폰 상세 - 발행 목록
	CouponPolicyVO getCouponPolicyDtl(CouponPolicyVO couponPolicyVO) throws Exception;

	// 쿠폰 상세 - 상세 발행 내역
	List<CouponPolicyVO> getCouponDtlIsuList(CouponPolicyVO couponPolicyVO) throws Exception;

	//쿠폰 상세 - 상세 발행 내역 카운트
	Integer getCouponDtlIsuListTotCnt(CouponPolicyVO couponPolicyVO) throws Exception;

	// 쿠폰 수정 이력
	List<CouponPolicyVO> getCouponPolicyHstList(CouponPolicyVO couponPolicyVO) throws Exception;

	// 쿠폰 수정 이력 카운트
	Integer getCouponPolicyHstListCnt(CouponPolicyVO couponPolicyVO) throws Exception;
	
	// 프로모션 - 발행 쿠폰 정보 조회
	CouponPolicyVO getChkCouponDtl(CouponPolicyVO couponPolicyVO) throws Exception;
	
	// 프로모션 수정 - 해당 프로모션 번호로 업체에게 발행된 쿠폰 상태 확인 (01:미사용, 05:사용중)
	Integer getChkCouponUseCnt(CouponPolicyVO couponPolicyVO) throws Exception;
	
	//프로모션에 대한 쿠폰 정책 조회
	List<CouponPolicyVO> getReChkCouponPolicy(CouponPolicyVO couponPolicyVO) throws Exception;
	
	List<CouponPolicyVO> getCouponDtlList(CouponPolicyVO couponPolicyVO) throws Exception;
	
	//디테일 쿠폰 삭제
	Integer deleteCouponDtl(CouponPolicyVO couponPolicyVO) throws Exception;
	
}