package com.sorincorp.bo.ev.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.cs.model.CsMemberVO;
import com.sorincorp.bo.ev.model.LoanCnsltReqstVO;
import com.sorincorp.comm.model.CommonVO;

/**
 * LoanCnsltReqstMapper.java
 * @version
 * @since 2022. 9. 14.
 * @author jaylee
 */
public interface LoanCnsltReqstMapper {
	
	/**
	 * <pre>
	 * 처리내용: 대출 상담신청 사용자를 조회한다.
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author jaylee
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			jaylee				최초작성
	 * ------------------------------------------------
	 * @param 
	 * @return
	 * @throws Exception
	 */
	List<LoanCnsltReqstVO> selectLoanCnsltReqst(LoanCnsltReqstVO vo);
	
	
	/**
	 * 상담자, 상담내용, 상담일시 업데이트
	 */
	int updateLoanCnsltReqst(LoanCnsltReqstVO vo);
	
	/**
	 * 삭제여부 업데이트
	 */
	void deleteLoanCnsltReqst(LoanCnsltReqstVO loanCnsltReqstVO);
}