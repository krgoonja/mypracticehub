package com.sorincorp.bo.ev.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.ev.model.CouponVO;
import com.sorincorp.bo.ev.service.CouponService;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * CouponContoller.java
 * @version
 * @since 2023. 5. 2.
 * @author hamyoonsic
 */
@Slf4j
@Controller
@RequestMapping("/ev/coupon")
public class CouponController {

	@Autowired
	private CouponService couponService;

	@Autowired
	private CustomValidator customValidator;

	@Autowired
	private ItCmnCodeService itCmnCodeService;

	/**
	 * <pre>
	 * 처리내용: 발행된 쿠폰 내역을 조회한다
	 * </pre>
	 * @date 2023. 5. 2.
	 * @author hamyoonsic
	 * @history
	 * @param
	 * @return
	 * @throws Exception
	 */
    @RequestMapping(value="/couponIsuDataList")
    public ResponseEntity<?> couponIsuList(@RequestBody CouponVO couponVO, ModelMap model, BindingResult bindingResult) throws Exception {

        if(couponVO.isValidation()) {
            customValidator.validate(couponVO, bindingResult);
        }

        if(bindingResult.hasErrors()) {
            return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
        }

        Map<String,Object> map = new HashMap<String, Object>();
        int totalCount =  couponService.getCouponIsuDataListTotCnt(couponVO);
        List<CouponVO> couponList = couponService.getCouponIsuDataList(couponVO);

        map.put("totalDataCount", totalCount);
        map.put("dataList", couponList);

        return new ResponseEntity<>(map, HttpStatus.OK);
    }

	/**
	 * <pre>
	 * 처리내용: 발행된 쿠폰 목록 페이지 이동
	 * </pre>
	 * @date 2023. 5. 2.
	 * @author hamyoonsic
	 * @history
	 * @param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/couponIsuList")
	public String viewPaytEsamtMngList(Model model) throws Exception {
		try {

			ItCmnCodeVO vo = new ItCmnCodeVO();
			// 쿠폰타입코드 리스트
			vo.setMainCode("COUPON_TY_CODE");
			vo.setCodeDctwo("");
			vo.setUseAt("Y");
			List<ItCmnCodeVO> couponTyList = itCmnCodeService.selectCmnCodeList(vo);

			// 쿠폰상태코드
			vo.setMainCode("COUPON_STTUS_CODE");
			List<ItCmnCodeVO> couponSttusList = itCmnCodeService.selectCmnCodeList(vo);
			model.addAttribute("couponTyList", couponTyList);
			model.addAttribute("couponSttusList", couponSttusList);
			return "ev/couponIsuList";
		} catch ( Exception e ){
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 발행 쿠폰 삭제
	 * </pre>
	 * @date 2023. 5. 2.
	 * @author hamyoonsic
	 * @history
	 * @param
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/deleteAjax")
	@ResponseBody
	public ResponseEntity<?> deleteCouponIsuData(@RequestBody CouponVO couponVO) throws Exception {
		Map<String, Object> retVal = new HashMap<>();
		try {
			couponService.deleteCouponIsuData(couponVO);
			retVal.put("code", "S");
			retVal.put("msg", "삭제가 완료되었습니다");
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		} catch (Exception e) {
			retVal.put("code", "F");
			retVal.put("msg", "삭제 과정 중 오류가 발생하였습니다");
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 쿠폰 발행 내역 엑셀 다운로드
	 * </pre>
	 * @date 2023. 5. 3.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 3.		hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param couponVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/couponIsuDataListForExcel")
	public ResponseEntity<?> selectFaqForExcel(@RequestBody CouponVO couponVO) throws Exception {
		couponVO.setRecordCountPerPage(10000000);
		List<CouponVO> dataList = couponService.getCouponIsuDataList(couponVO);

		Map<String,Object> map = new HashMap<String, Object>();
		map.put("dataList", dataList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}
}
