package com.sorincorp.bo.ev.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.bo.co.comm.BoCoConstants;
import com.sorincorp.bo.co.comm.CoResponseEntity;
import com.sorincorp.bo.co.model.CmmnCodeVO;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.ev.model.CouponPolicyVO;
import com.sorincorp.bo.ev.model.PromtnInfoVO;
import com.sorincorp.bo.ev.model.PromtnNewYearVO;
import com.sorincorp.bo.ev.service.CouponPolicyService;
import com.sorincorp.bo.ev.service.PromtnInfoService;
import com.sorincorp.bo.it.model.DisplayCtgryMgrVO;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * PromtInfoContoller.java
 * @version
 * @since 2023. 4. 24.
 * @author sein
 */
@Slf4j
@Controller
@RequestMapping("/ev/promtn")
public class PromtnInfoContoller {

	@Autowired
	private PromtnInfoService promtnInfoService;
	
	@Autowired
	private CouponPolicyService couponPolicyService;
	
	@Autowired
	private CustomValidator customValidator;

	@Autowired
	private UserInfoUtil userInfoUtil;
	
	private static String RESULT = "result";
	private static String CATEGORYNO = "categoryNo";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";
	
	/**
	 * <pre>
	 * 처리내용: 프로모션 목록 페이지를 조회한다.
	 * </pre>
	 * @date 2022. 7. 12.
	 * @author jhcha
	 * @history
	 * @param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/promtnInfoList")
	public String promtnInfoList(Model model) {
		try {
			List<CmmnCodeVO> jobSeCodeList = promtnInfoService.selectPromtnSeCodeList();
			StringBuilder codeTaglibStr = new StringBuilder(StringUtils.EMPTY);
			codeTaglibStr.append("");
			codeTaglibStr.append(CommonConstants.COLONE);
			codeTaglibStr.append("전체");
			codeTaglibStr.append(CommonConstants.SEMI_COLONE);

			for(CmmnCodeVO jobSeCode : jobSeCodeList) {
				codeTaglibStr.append(jobSeCode.getSubCode());
				codeTaglibStr.append(CommonConstants.COLONE);
				codeTaglibStr.append(jobSeCode.getCodeNm());
				codeTaglibStr.append(CommonConstants.SEMI_COLONE);
			}

			model.addAttribute("jobSeCodeList", codeTaglibStr.toString());

			return "ev/promtnRegistn";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 프로모션 정보 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 7. 12.
	 * @author jhcha
	 * @history
	 * @param PromtnInfoVO
	 * @param BindingResult
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@RequestMapping("/promtnInfoListData")
	public ResponseEntity<?> promtnInfoList(@RequestBody PromtnInfoVO searchVO, BindingResult bindingResult) throws Exception {

		Map<String,Object> map = new HashMap<String, Object>();

		try {
			int totalCount =  promtnInfoService.getPromtnInfoListTotcnt(searchVO);
			List<PromtnInfoVO> promtnList = promtnInfoService.getPromtnInfoList(searchVO);

			map.put("totalDataCount", totalCount);
			map.put("dataList", promtnList);

		}catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 프로모션 등록 수정 팝업을 오픈한다.
	 * </pre>
	 * @date 2023. 03. 21.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 03. 21.			sein				최초작성
	 * 2023. 05. 21.			huynjin05			쿠폰타입코드 추가
	 * 2023. 06. 14.			huynjin05			쿠폰정책확인 추가
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertPromtnView")
	public String insertPromtnView(@RequestBody PromtnInfoVO promtnInfoVO, ModelMap model) {
		Map<String, Object> getChkCouponPolicy =  new HashMap<String, Object>();
		CouponPolicyVO couponPolicyVO = new CouponPolicyVO();
		
		try {
			if(promtnInfoVO.getModalPageStatus().equals("insert")) {

			}else {
				promtnInfoVO = promtnInfoService.selectPromtnInfo(promtnInfoVO);
				promtnInfoVO.setModalPageStatus("update");
				
				Integer promtnNo = Integer.valueOf(promtnInfoVO.getPromtnNo());
				if(!promtnNo.equals(null)) {
					couponPolicyVO.setPromtnNo(promtnInfoVO.getPromtnNo());
					getChkCouponPolicy = couponPolicyService.getChkCouponPolicy(couponPolicyVO);
					model.addAttribute("getChkCouponPolicy", getChkCouponPolicy);
				}
			}
			model.addAttribute("promtnInfoVO", promtnInfoVO);
			Map<String, FileDocVO> beginEndImageFile = promtnInfoService.selectBeginEndImage(promtnInfoVO);
			List<CmmnCodeVO> promtnSeCodeList = promtnInfoService.selectPromtnSeCodeList();
			List<CmmnCodeVO> couponTyCodeList = promtnInfoService.selectCouponTyCodeList();

			model.addAttribute("promtnSeCodeList", promtnSeCodeList);
			model.addAttribute("couponTyCodeList", couponTyCodeList);
			model.addAttribute("beginEndImageFile", beginEndImageFile);

			return "ev/promtnPopRegistn.modal";

		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}


	/**
	 * <pre>
	 * 처리내용: 첨부파일을 업로드한다.
	 * </pre>
	 * @date 2021. 7. 27.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param mRequest
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertFile")
	@ResponseBody
	public ResponseEntity<?> insertFile(MultipartHttpServletRequest mrequest) throws Exception {
		Map<String,Object> fileMap = new HashMap<>();

		try {
			fileMap = promtnInfoService.uploadFileDoc(mrequest);

		}catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<>(fileMap, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 프로모션 정보 화면을 등록 및 수정 한다.
	 * </pre>
	 * @date 2023. 03. 31.
	 * @author sein
	 * @history
	 * @param promtnInfoVO
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@RequestMapping("/insertAndUpdatePromtnInfo")
	@ResponseBody
	public ResponseEntity<?> insertAndUpdatePromtnInfo(@Valid @RequestBody PromtnInfoVO promtnInfoVO, BindingResult bindingResult) throws Exception {
		try {

			if(bindingResult.hasErrors()) {
				return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
			}
			promtnInfoService.insertAndUpdatePromtnInfo(promtnInfoVO);
		}catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG), HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 첨부파일을 삭제한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/deleteFile")
	@ResponseBody
	public ResponseEntity<?> deleteFile(@RequestBody FileDocVO vo) throws Exception {
		Map<String,Object> map = new HashMap<>();

		try {
			 map = promtnInfoService.deleteFileDoc(vo);
		}catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 사용여부를 'N'로 업데이트 한다..
	 * </pre>
	 * @date 2023. 04. 03.
	 * @author sein
	 * @history
	 * @param promtnInfoVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/deletePromtnInfo")
	@ResponseBody
	public ResponseEntity<?> deletePromtnInfo(@RequestBody PromtnInfoVO promtnInfoVO) throws Exception {
		try {
			promtnInfoVO = promtnInfoService.selectPromtnInfo(promtnInfoVO);
			promtnInfoService.deletePromtnInfo(promtnInfoVO);
		} catch (Exception e) {
			return new ResponseEntity<>(false, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(true , HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 복주머니 당첨자 목록 페이지를 조회한다.
	 * </pre>
	 * @date 2024. 1. 29.
	 * @author cuko
	 * @history
	 * @param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/prizeWinnerList")
	public String prizeWinnerList(Model model) {

		try {
			PromtnInfoVO promtnInfoVO = new PromtnInfoVO();
//			model.addAttribute("prizeWinnerList", promtnInfoService.getPrizeWinnerList(promtnInfoVO));

			return "ev/prizeWinnerList";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 복주머니 당첨자 목록 페이지를 조회한다.
	 * </pre>
	 * @date 2024. 1. 29.
	 * @author cuko
	 * @history
	 * @param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/prizeWinnerListData")
	public ResponseEntity<?>  prizeWinnerListData(@RequestBody PromtnNewYearVO searchVO) {
		Map<String,Object> map = new HashMap<String, Object>();
		List<PromtnNewYearVO> promtnNewYearVOList = new ArrayList<PromtnNewYearVO>();
		
		try {
			promtnNewYearVOList = promtnInfoService.getPrizeWinnerList(searchVO);
			
			map.put("dataList", promtnNewYearVOList);
			map.put("totalDataCount", promtnInfoService.getPrizeWinnerListTotCnt(searchVO));
//			promtnNewYearVOList = promtnInfoService.getPrizeWinnerList(promtnInfoVO);
		} catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 복주머니 당첨자 상품권 전송 여부 변경
	 * </pre>
	 * @date 2024. 1. 29.
	 * @author cuko
	 * @history
	 * @param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertUpateprizeWinnerListData")
	public ResponseEntity<?>  insertUpateprizeWinnerListData(@RequestBody PromtnNewYearVO vo, Model model, BindingResult bindingResult) {
		Map<String,Object> retVal = new HashMap<String, Object>();
		
		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(vo, bindingResult, DisplayCtgryMgrVO.InsertAndUpdate.class);
		
		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			//return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		int result = 0;
		
		try {
			
			result = promtnInfoService.insertUpateprizeWinnerListData(vo);
			
			if (result > 0) {
				retVal.put(RESULT, SUCCESS);
				retVal.put(ERRMSG, "");
			} else {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "이미 추가된 아이템입니다.");
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			return new ResponseEntity<>(retVal, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
}
