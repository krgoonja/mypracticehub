package com.sorincorp.bo.ev.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.co.model.CmmnCodeVO;
import com.sorincorp.bo.comm.util.CommConstants;
import com.sorincorp.bo.comm.util.CommResponseEntity;
import com.sorincorp.bo.ev.model.CouponInfoVO;
import com.sorincorp.bo.ev.service.CouponInfoService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * PromtInfoContoller.java
 * @version
 * @since 2022. 7. 12.
 * @author jhcha
 */
@Slf4j
@Controller
@RequestMapping("/ev/coupon")
public class CouponInfoController {
	
	@Autowired
	private CouponInfoService coupponInfoService;
	
	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired
	private CustomValidator customValidator;

	/**
	 * <pre>
	 * 처리내용: 쿠폰 목록 페이지를 조회한다.
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author jhcha
	 * @history
	 * @param 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/couponInfoList")
	public String couponInfoList(ModelMap model) {
		try {
			Map<String, String> map = new HashMap<String, String>();
			CouponInfoVO couponInfoVO = new CouponInfoVO();
			
			map.put("", "전체");
						
			model.addAttribute("promtnNoList", commonCodeService.getCmmnCodeListStr(coupponInfoService.selectPromtnNoList(), map));
			model.addAttribute("couponTyCode", commonCodeService.getCmmnCodeListStr(
					commonCodeService.getSubCodesToCommonCode("COUPON_TYPE"), map));				
			model.addAttribute("couponSeCode", commonCodeService.getCmmnCodeListStr(
					commonCodeService.getSubCodesToCommonCode("COUPON_SE_CODE"), map));
			model.addAttribute("metalCode", commonCodeService.getCmmnCodeListStr(
					commonCodeService.getSubCodesToCommonCode("METAL_CODE"), map));			

			return "ev/couponRegistn";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}	
	
	/**
	 * <pre>
	 * 처리내용: 쿠폰 정보 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author jhcha
	 * @history 
	 * @param 
	 * @return 
	 * @throws Exception
	 */
	@RequestMapping(value="/couponInfoListData")
	public ResponseEntity<?> couponInfoListData(@RequestBody CouponInfoVO searchVO, ModelMap model, BindingResult bindingResult) throws Exception {

		if(searchVO.isValidation()) {
			customValidator.validate(searchVO, bindingResult); 
		}
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		
		Map<String,Object> map = new HashMap<String, Object>();
		int totalCount =  coupponInfoService.getCouponInfoListTotCnt(searchVO);
		List<CouponInfoVO> couponList = coupponInfoService.getCouponInfoList(searchVO);

		
		map.put("totalDataCount", totalCount);
		map.put("dataList", couponList);	
		
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 쿠폰 등록 수정 팝업을 오픈한다.
	 * </pre>
	 * @date 2022. 7. 12.
	 * @author jhcha
	 * @history
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertCouponView")
	public String insertCouponView(@RequestBody CouponInfoVO couponInfoVO, ModelMap model) {
		try {

			model.addAttribute("couponInfoVO", couponInfoVO);
			
			Map<String, String> map = new HashMap<String, String>();
			
			model.addAttribute("promtnNoList", commonCodeService.getCmmnCodeListStr(
				coupponInfoService.selectPromtnNoList(), map));
			
			map.put("","선택");
			model.addAttribute("couponTyCode", commonCodeService.getCmmnCodeListStr(
				commonCodeService.getSubCodesToCommonCode("COUPON_TYPE"), map));					
			model.addAttribute("couponSeCode", commonCodeService.getCmmnCodeListStr(
				commonCodeService.getSubCodesToCommonCode("COUPON_SE_CODE"), map));
			model.addAttribute("metalCode", commonCodeService.getCmmnCodeListStr(
				commonCodeService.getSubCodesToCommonCode("METAL_CODE"), map));			
			
			return "ev/couponPopRegistn.modal";
			
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 신규등록, 업데이트 한다.
	 * </pre>
	 * @date 2022. 7. 12.
	 * @history
	 * @param model
	 * @return String
	 * @throws Exception
	 */
	@PostMapping("/insertAndUpdateCouponInfo")
	@ResponseBody
	public ResponseEntity<?> insertAndUpdateCouponInfo(@RequestBody List<CouponInfoVO> couponInfoVO) throws Exception {
	    
		int result = 0;
	    Map<String, Object> retVal = new HashMap<String, Object>();
	    
	    CommResponseEntity commResponseEntity = new CommResponseEntity(result, retVal);
	    
	    try {
	    	result = coupponInfoService.insertAndUpdateCouponInfoBas(couponInfoVO);
	    	
			if(result > 0) {
				
			    retVal.put(CommConstants.RESULT, CommConstants.SUCCESS);
			    retVal.put(CommConstants.ERRMSG, CommConstants.SUCCESS_MSG);
			    
			    commResponseEntity.setResponseCode(CommConstants.SUCCESS_CODE);
			    commResponseEntity.setData(retVal);			    
			    
			} else if(result == -99) {
			
				retVal.put(CommConstants.RESULT, CommConstants.FAIL);
			    retVal.put(CommConstants.ERRMSG, "난수는 중복 불가합니다.");
			    
			    commResponseEntity.setResponseCode(CommConstants.ERROR_CODE);
			    commResponseEntity.setData(retVal);			    
			} 
			
			
	    }catch (Exception e) {
	    	
		     log.error(e.getMessage());

		     retVal.put(CommConstants.RESULT, CommConstants.FAIL);
		     retVal.put(CommConstants.ERRMSG, e.getMessage());
		     
		     commResponseEntity.setData(retVal);
			 commResponseEntity.setResponseCode(CommConstants.ERROR_CODE);
			 
		     return new ResponseEntity<>(commResponseEntity, HttpStatus.OK);
	    }
		return new ResponseEntity<>(commResponseEntity, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 사용여부를 'N'로 업데이트 한다..
	 * </pre>
	 * @date 2022. 7. 12.
	 * @author jhcha
	 * @history
	 * @param model
	 * @return String
	 * @throws Exception
	 */
	@PostMapping("/deleteCouponInfo")
	@ResponseBody
	public ResponseEntity<?> deleteCouponInfo(@RequestBody List<CouponInfoVO> searchVO) throws Exception {

		coupponInfoService.deleteCouponInfo(searchVO);
		
		return new ResponseEntity<>(new CommResponseEntity(CommConstants.SUCCESS_CODE, CommConstants.SUCCESS_MSG), HttpStatus.OK);
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 메탈코드에 따른 브랜드 코드를 조회한다.
	 * </pre>
	 * @date 2022. 7. 12.
	 * @author jhcha
	 * @history
	 * @param model
	 * @return String
	 * @throws Exception
	 */
	@PostMapping("/selectBrandCode")
	@ResponseBody
	public Map<String, Object> selectBrandCode(@RequestBody CouponInfoVO searchVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		List<CmmnCodeVO> returnCode = coupponInfoService.selectBrandCode(searchVO);

		returnMap.put("couponApplcBrandCodeList", returnCode);

		return returnMap;
	}
}