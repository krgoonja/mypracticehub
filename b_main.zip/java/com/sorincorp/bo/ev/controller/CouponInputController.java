package com.sorincorp.bo.ev.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.co.comm.BoCoConstants;
import com.sorincorp.bo.co.comm.CoResponseEntity;
import com.sorincorp.bo.ev.model.CouponEntrpsAppnVO;
import com.sorincorp.bo.ev.model.CouponInputVO;
import com.sorincorp.bo.ev.service.CouponInfoService;
import com.sorincorp.bo.ev.service.CouponInputService;
import com.sorincorp.bo.ev.service.PromtnInfoService;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.bo.st.service.StatsService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * CouponEntrpsAppnController.java
 * @version
 * @since 2022. 8. 4.
 * @author jhcha
 */
@Slf4j
@Controller
@RequestMapping("/ev/couponInput")
public class CouponInputController {

	@Autowired
	private CouponInfoService couponInfoService;

	@Autowired
	private CouponInputService couponInputService;
	
	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired
	private CustomValidator customValidator;
	
	/**
	 * <pre>
	 * 처리내용: 쿠폰등록관리
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author sumin95
	 * @history
	 * @param 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/couponInputList")
	public String couponInputList(Model model) {
		try {
			
			Map<String, String> map = new HashMap<String, String>();
			map.put("", "전체");
			
			model.addAttribute("promtnNoList", commonCodeService.getCmmnCodeListStr(couponInfoService.selectPromtnNoList(), map));
			model.addAttribute("couponNoList", commonCodeService.getCmmnCodeListStr(couponInfoService.selectCouponNoList(), map));
			model.addAttribute("couponSeCode", commonCodeService.getCmmnCodeListStr(
				commonCodeService.getSubCodesToCommonCode("COUPON_SE_CODE"), map));
			model.addAttribute("couponTyCode", commonCodeService.getCmmnCodeListStr(
				commonCodeService.getSubCodesToCommonCode("COUPON_TYPE"), map));	
			model.addAttribute("metalCode", commonCodeService.getCmmnCodeListStr(
				commonCodeService.getSubCodesToCommonCode("METAL_CODE"), map));			

			return "ev/couponInputRegistn";
			
		}catch (Exception e) {
			log.error(e.getMessage());	
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}	
	
	
	/**
	 * <pre>
	 * 처리내용: 쿠폰등록데이터조회
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author sumin95
	 * @history
	 * @param 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/couponInputListData")
	public ResponseEntity<?> couponInputListData(@RequestBody CouponInputVO couponInputVO, ModelMap model, BindingResult bindingResult) throws Exception{
	
	    if(couponInputVO.isValidation()) {
	    	customValidator.validate(couponInputVO, bindingResult); 
	    }
	    
	    if(bindingResult.hasErrors()) {
	    	return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
	    }
	    
	    Map<String,Object> map = new HashMap<>();
	    int totalCount =  couponInputService.getCouponInputListTotCnt(couponInputVO);
	    List<CouponInputVO> couponInputList = couponInputService.getCouponInputList(couponInputVO);
	    
	    map.put("totalDataCount", totalCount);
	    map.put("dataList", couponInputList);
	    
	    return new ResponseEntity<>(map, HttpStatus.OK); 
	}	
	
	
}