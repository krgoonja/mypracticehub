package com.sorincorp.bo.ev.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.ev.model.CouponPolicyVO;
import com.sorincorp.bo.ev.model.EntrpsCouponVO;
import com.sorincorp.bo.ev.model.EntrpsIsuVO;
import com.sorincorp.bo.ev.service.EntrpsCouponService;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.brandcode.service.BrandCodeService;
import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;
import com.sorincorp.comm.brandgroupcode.service.BrandGroupCodeService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * EntrpsCouponController.java
 * @version
 * @since 2023. 5. 1.
 * @author sumin
 */
@Slf4j
@Controller
@RequestMapping("/ev/entrpsCoupon")
public class EntrpsCouponController {

	@Autowired
	private ItCmnCodeService itCmnCodeService;
	@Autowired
	private BrandCodeService brandCodeService;
	@Autowired
	private BrandGroupCodeService brandGroupCodeService;
	@Autowired
	private ItemCodeService itemCodeService;
	@Autowired
	private EntrpsCouponService entrpsCouponService;
	@Autowired
	private CommonCodeService commonCodeService;
	@Autowired
	private UserInfoUtil userInfoUtil;
	@Autowired
	private CustomValidator customValidator;


	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";


	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 업체쿠폰발행하기 : 페이지로드
	 * </pre>
	 * @date 2023. 5. 1.
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 1.				sumin				최초작성
	 * 2024. 6. 13.				hyunjin0512			쿠폰 적용 주문 타입 공통으로 변경
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return EntrpsCouponVO
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsCouponList")
	public String entrpsCouponList(Model model) throws Exception {
		try {
			ItCmnCodeVO vo = new ItCmnCodeVO();
			Map<String, String> map = new HashMap<>();

			// 쿠폰타입코드 리스트
			vo.setMainCode("COUPON_TY_CODE");
			vo.setCodeDctwo("");
			vo.setUseAt("Y");
			List<ItCmnCodeVO> couponTyList = itCmnCodeService.selectCmnCodeList(vo);
			// 메탈코드 리스트
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);
			// 아이템 리스트
			List<ItemCodeVO> itemCodeList = itemCodeService.getItemFtrsProcessAtCodeList("", "");
			// 브랜드 그룹코드 리스트
			List<BrandGroupCodeVO> brandGroupCodeList = brandGroupCodeService.getBrandGroupCodeList("");
			// 브랜드코드 리스트
			List<BrandCodeVO> brandCodeList = brandCodeService.getBrandCodeList("");
			// 쿠폰상태코드
			vo.setMainCode("COUPON_STTUS_CODE");
			vo.setCodeDctwo("");
			List<ItCmnCodeVO> couponSttusList = itCmnCodeService.selectCmnCodeList(vo);
			
			// 쿠폰 적용 타입 (주문 방식 코드)
			vo.setMainCode("SLE_MTHD_CODE");
			vo.setCodeDctwo("Y");
			List<ItCmnCodeVO> sleMthdCodeList = itCmnCodeService.selectCmnCodeList(vo);
		

			model.addAttribute("couponTyList", couponTyList);
			model.addAttribute("metalCodeList", metalCodeList);
			model.addAttribute("itemCodeList", itemCodeList);
			model.addAttribute("brandGroupCodeList", brandGroupCodeList);
			model.addAttribute("brandCodeList", brandCodeList);
			model.addAttribute("couponSttusList", couponSttusList);
			model.addAttribute("sleMthdCodeList", sleMthdCodeList);
			
			return "ev/entrpsCouponList";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 업체쿠폰발행하기 : 목록조회
	 * </pre>
	 * @date 2023. 5. 1.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 1.				sumin				최초작성
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return EntrpsCouponVO
	 * @throws Exception
	 */
	@RequestMapping("/searchEntrpsCouponList")
	@ResponseBody
	public Map<String, Object> entrpsCouponDataList(@RequestBody EntrpsCouponVO entrpsCouponVO) throws Exception {

		Map<String,Object> map = new HashMap<String, Object>();

			List<EntrpsCouponVO> entrpsCouponList = entrpsCouponService.searchEntrpsCouponList(entrpsCouponVO);

			map.put("dataList", entrpsCouponList);
			map.put("totalDataCount", entrpsCouponService.selectEntrpsCouponListTotCnt(entrpsCouponVO));
		return map;
	}

	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 업체쿠폰발행하기 > 쿠폰상세번호 > 모달 : 페이지로드
	 * </pre>
	 * @date 2023. 5. 15.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 15.				sumin				최초작성
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return String
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsCouponDtlList")
	public String entrpsCouponDtl(@RequestBody EntrpsCouponVO entrpsCouponVO, ModelMap model) throws Exception {
		try {
			//쿠폰발행 업체리스트 조회
			model.addAttribute("couponDtlNo", entrpsCouponVO.getCouponDtlNo());
			model.addAttribute("couponTyCode", entrpsCouponVO.getCouponTyCode());
			return "ev/entrpsAppnDtlList.modal";
		} catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}


	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 업체쿠폰발행하기 > 쿠폰상세번호 > 모달 : 목록조회
	 * </pre>
	 * @date 2023. 5. 15.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 15.				sumin				최초작성
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return map
	 * @throws Exception
	 */
	@RequestMapping("/getCouponAppnEntrpsList")
	@ResponseBody
	public ResponseEntity<?> getCouponAppnEntrpsList(@RequestBody EntrpsCouponVO entrpsCouponVO) throws Exception {

		List<EntrpsCouponVO> voList = entrpsCouponService.getCouponAppnEntrps(entrpsCouponVO);

		Map<String, Object> map = new HashMap<String, Object>();

		map.put("dataList", voList);
		map.put("totalDataCount", entrpsCouponService.getCouponAppnEntrpsCnt(entrpsCouponVO));

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리/업체쿠폰발행하기 > 모달 : 페이지로드
	 * </pre>
	 * @date 2023. 5. 3.
	 * @author
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 3.				sumin				최초작성
	 * 2024. 6. 13.				hyunjin0512			쿠폰 적용 주문 타입 공통으로 변경
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return EntrpsCouponVO
	 * @throws Exception
	 */
	@RequestMapping("/entrpsAppnCouponIsu")
	public String entrpsAppnIsu(@RequestBody EntrpsCouponVO entrpsCouponVO, Model model) throws Exception {

		try {
			ItCmnCodeVO vo = new ItCmnCodeVO();
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			// 메탈코드 리스트
			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);
			// 브랜드코드 리스트
			List<BrandCodeVO> brandCodeList = brandCodeService.getBrandCodeList("");
			//단가 할인 쿠폰 금액 코드
			vo.setMainCode("COUPON_DSCNT_AMOUNT");
			vo.setCodeDctwo("");
			List<ItCmnCodeVO> dscntAmountCode = itCmnCodeService.selectCmnCodeList(vo);
			

			// 쿠폰 적용 타입 (주문 방식 코드)
			vo.setMainCode("SLE_MTHD_CODE");
			vo.setCodeDctwo("");
			List<ItCmnCodeVO> sleMthdCodeList = itCmnCodeService.selectCmnCodeList(vo);

			//쿠폰 정책 데이터 조회
			Map<String, Object> resultMap  = entrpsCouponService.selectCouponInfo(entrpsCouponVO);


			/**
			 * 검색조건
			 */
			model.addAttribute("couponNo", entrpsCouponVO.getCouponNo());
			model.addAttribute("metalCodeList", metalCodeList);
			model.addAttribute("brandCodeList", brandCodeList);
			model.addAttribute("dscntAmountCode", dscntAmountCode);
			model.addAttribute("resultMap", resultMap);
			model.addAttribute("modalPageStatus", entrpsCouponVO.getModalPageStatus());
			model.addAttribute("couponDtlNo", entrpsCouponVO.getCouponDtlNo());
			model.addAttribute("activeTabVal", entrpsCouponVO.getActiveTabVal());
			model.addAttribute("sleMthdCodeList", sleMthdCodeList);
			
			return "ev/entrpsAppnCouponIsu.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}


	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리/업체쿠폰발행하기 > 모달 : 목록조회
	 * </pre>
	 * @date 2023. 5. 8.
	 * @author
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 8.				sumin				최초작성
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return EntrpsCouponVO
	 * @throws Exception
	 */
	@RequestMapping("/appnEntrpsList")
	public ResponseEntity<?> appnEntrpsList(@RequestBody EntrpsCouponVO entrpsCouponVO) throws Exception {
		Map<String, Object> map = new HashMap<>();

		//업체리스트 조회
		List<EntrpsCouponVO> entrpsList = entrpsCouponService.selectAppnEntrpsList(entrpsCouponVO);
		map.put("totalDataCount", entrpsCouponService.selectAppnEntrpsListCnt(entrpsCouponVO));
		map.put("dataList", entrpsList);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}


	/**
	 *
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리/업체쿠폰발행하기 > 등록모달 > 브랜드조회
	 * </pre>
	 * @date 2023. 6. 13.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 *  2023. 6. 13.			 sumin				최초작성
	 * ------------------------------------------------
	 * @param   String metalCode
	 * @param   BindingResult bindingResult
	 * @return  ResponseEntity<?>
	 * @throws  Exception
	 */
	@RequestMapping("/ajaxBrandCodeList")
	public ResponseEntity<?> ajaxBrandCodeList(@RequestParam(value = "metalCode") String metalCode) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		ArrayList<BrandCodeVO> brandList = new ArrayList<BrandCodeVO>();

		try {
			List<BrandCodeVO> brandTmpList = brandCodeService.getBrandCodeList("");
			if ("".equals(metalCode) || metalCode == null) {
				map.put("brandCodeList", brandTmpList);
			} else {
				for (BrandCodeVO brandCodeVO : brandTmpList) {
					if (brandCodeVO.getMetalCode().equals(metalCode)) {
						brandList.add(brandCodeVO);
					}
				}
				map.put("brandCodeList", brandList);
			}

			return new ResponseEntity<>(map, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}


	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰발행정책관리/업체쿠폰발행하기 > 모달 > 쿠폰발행
	 * </pre>
	 * @date  2023. 5. 19.
	 * @author
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 19.				sumin				최초작성
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return EntrpsCouponVO
	 * @throws Exception
	 */
	@RequestMapping("/saveCouponDtl")
	@ResponseBody
	public ResponseEntity<?> saveCouponDtl(@RequestBody EntrpsIsuVO vo, BindingResult bindingResult) throws Exception {
		if (bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		if(vo.getModalPageStatus().equals("insert")) {
			entrpsCouponService.saveCouponDtl(vo);
		} else if (vo.getModalPageStatus().equals("update")) {
			entrpsCouponService.updateCouponDtl(vo);
		}

			return ResponseEntity.status(HttpStatus.OK).body("Success");
		}


	/**
	 * <pre>
	 * 프로모션관리 > 쿠폰관리 > 쿠폰발행정책/업체쿠폰발행하기 > 모달 > 쿠폰삭제
	 * </pre>
	 * @date 2023. 5. 26
	 * @author
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 26				sumin				최초작성
	 * ------------------------------------------------
	 * @param EntrpsCouponVO
	 * @return EntrpsCouponVO
	 * @throws Exception
	 */
	@RequestMapping("/deleteCouponDtl")
	@ResponseBody
	public ResponseEntity<?> deleteCouponDtl(@RequestBody EntrpsCouponVO vo) throws Exception {
			Map<String, Object> retVal = new HashMap<String, Object>();
			int result = 0;
			result = entrpsCouponService.deleteCouponDtl(vo);

			if (result == -99 ) {
				retVal.put(ERRMSG, "쿠폰 삭제는 미사용 상태만 가능합니다.");
			} else if (result > 0 ) {
				retVal.put(RESULT, SUCCESS);
				retVal.put(ERRMSG, "");
			} else {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "");
			}

			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

}

