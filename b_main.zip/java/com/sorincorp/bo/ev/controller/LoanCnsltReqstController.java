package com.sorincorp.bo.ev.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.cs.model.CsInquiryVO;
import com.sorincorp.bo.ev.model.LoanCnsltReqstVO;
import com.sorincorp.bo.ev.service.LoanCnsltReqstService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/ev/loan")
public class LoanCnsltReqstController {
	
	@Autowired
	private LoanCnsltReqstService loanCnsltReqstService;
	
	@Autowired
	private CommonCodeService commonCodeService;
	

	/**
	 * <pre>
	 * 처리내용: 사전 상담 신청자 조회
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author jaylee
	 * @history
	 * @param 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/loanCnsltReqstList")
	public String loanCnsltReqstList(ModelMap model) {
		try {
			//Map<String, String> map = new HashMap<String, String>();
			
			return "ev/loanCnsltReqstList";
			
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}	
	
	
	
	/**
	 * <pre>
	 * 처리내용: 상담 요청자 리스트를 가져온다.
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author jaylee
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			jaylee			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 */
	@RequestMapping("/selectLoanCnsltReqstList")
	@ResponseBody
	public Map<String, Object> selectLoanCnsltReqstList(@RequestBody LoanCnsltReqstVO loanCnsltReqstVO) throws Exception {
		
		 
		List<LoanCnsltReqstVO> loanCnsltReqstList = loanCnsltReqstService.selectLoanCnsltReqst(loanCnsltReqstVO);
		Map<String, Object> map = new HashMap<>();
		map.put("dataList", loanCnsltReqstList);
		return map;
	}
	
	@RequestMapping("/updateLoanCnsltReqstList")
	@ResponseBody
	public ResponseEntity<?> updateLoanCnsltReqstList(@RequestBody List<LoanCnsltReqstVO> loanCnsltReqstVO, BindingResult bindingResult) throws Exception {
		
		loanCnsltReqstService.updateLoanCnsltReqst(loanCnsltReqstVO);
		return ResponseEntity.status(HttpStatus.OK).body("Success");
	}
	
	
	@RequestMapping("/deleteLoanCnsltReqstList")
	@ResponseBody
	public ResponseEntity<?> deleteLoanCnsltReqstList(@RequestBody List<LoanCnsltReqstVO> loanCnsltReqstVO, BindingResult bindingResult) throws Exception {
		
		loanCnsltReqstService.deleteLoanCnsltReqst(loanCnsltReqstVO);
		
		return ResponseEntity.status(HttpStatus.OK).body("Success");
	}
	
	
	
}