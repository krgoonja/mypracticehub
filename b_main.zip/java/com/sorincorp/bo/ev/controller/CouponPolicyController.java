package com.sorincorp.bo.ev.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.ev.model.CouponPolicyVO;
import com.sorincorp.bo.ev.service.CouponPolicyService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * CouponContoller.java
 * 
 * @version
 * @since 2023. 4. 28.
 * @author cuko
 */
@Slf4j
@Controller
@RequestMapping("/ev/coupon")
public class CouponPolicyController {

	@Autowired
	private CouponPolicyService couponPolicyService;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	private static String RESULT = "result";
	private static String CATEGORYNO = "categoryNo";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	/**
	 * <pre>
	 * 처리내용: 쿠폰 발행 정책 관리 페이지 조회
	 * </pre>
	 * @date 2023. 4. 28.
	 * @author cuko
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 28.			cuko				최초작성
	 * 2023. 5. 02.			hyunjin05			연결수정
	 * ------------------------------------------------
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/couponPolicyList")
	public String couponPolicy() throws Exception {
		try {
			return "ev/couponPolicyList";
		} catch (Exception e) {
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 쿠폰 정책 그리드를 조회한다.
	 * </pre>
	 * @date 2023. 5. 02.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 02.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param couponPolicyVO
	 * @return map
	 * @throws Exception
	 */
	@RequestMapping("/getCouponPolicyList")
	public ResponseEntity<?> getCouponPolicyList(@RequestBody CouponPolicyVO couponPolicyVO) throws Exception {
		List<CouponPolicyVO> couponPolicyList = couponPolicyService.getCouponPolicyList(couponPolicyVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalDataCount", couponPolicyService.getCouponPolicyListTotCnt(couponPolicyVO));
		map.put("dataList", couponPolicyList);
		map.put("summaryList", couponPolicyService.getTotalCouponPolicyList(couponPolicyVO)); 

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 쿠폰 정책 엑셀 그리드를 조회한다.
	 * </pre>
	 * @date 2023. 5. 02.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 02.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param couponPolicyVO
	 * @return map
	 * @throws Exception
	 */
	@RequestMapping("/getCouponPolicyExcelList")
	public ResponseEntity<?> getCouponPolicyExcelList(@RequestBody CouponPolicyVO couponPolicyVO) throws Exception {
		List<CouponPolicyVO> couponPolicyList = couponPolicyService.getCouponPolicyExcelList(couponPolicyVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("dataList", couponPolicyList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 쿠폰 정책 그리드의 정보를 저장, 수정한다.
	 * </pre>
	 * @date 2023. 5. 04.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 04.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param couponPolicyVO
	 * @return map
	 * @throws Exception
	 */
	@RequestMapping("/insertAndUpdateCouponPolicy")
	@ResponseBody
	public ResponseEntity<Object> insertAndUpdateCouponPolicy(@RequestBody CouponPolicyVO couponPolicyVO) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		boolean result = false;
		try {
			if (userInfoUtil.getAccountInfo() == null) {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
				retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
				return new ResponseEntity<>(retVal, HttpStatus.OK);
			}
			result = couponPolicyService.insertAndUpdateCouponPolicy(couponPolicyVO);

			if (result == true) {
				retVal.put(RESULT, SUCCESS);
				retVal.put(ERRMSG, "");
			} else if (result == false) {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "");
			}
		} catch (Exception e) {
			// TODO: handle exception
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 쿠폰 정책 그리드의 정보를 삭제하기 위한 데이터 확인
	 * </pre>
	 * @date 2023. 5. 04.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 04.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param couponPolicyVO
	 * @return map
	 * @throws Exception
	 */
	@RequestMapping("/deleteChkCouponPolicy")
	@ResponseBody
	//		public Map<String, Object> deleteChkCouponPolicy(@RequestBody CouponPolicyVO CouponPolicyVO) throws Exception {
	public ResponseEntity<Object> deleteChkCouponPolicy(@RequestBody CouponPolicyVO couponPolicyVO) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		Map<String, Integer> returnData = new HashMap<String, Integer>();
		int chkPromntCnt = 0;
		int chkCouponUseCnt = 0;
		try {
			if (userInfoUtil.getAccountInfo() == null) {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
				retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
				return new ResponseEntity<>(retVal, HttpStatus.OK);
			}
			returnData = couponPolicyService.deleteChkCouponPolicy(couponPolicyVO);
			chkPromntCnt = returnData.get("chkPromntCnt");

			if (chkPromntCnt > 0) {
				if (returnData.containsKey("chkCouponUseCnt")) {
					chkCouponUseCnt = returnData.get("chkCouponUseCnt");
					retVal.put("chkPromntCnt", chkPromntCnt);
					retVal.put("chkCouponUseCnt", chkCouponUseCnt);
				} else {
					retVal.put("chkPromntCnt", chkPromntCnt);
				}
			} else {
				retVal.put("chkPromntCnt", chkPromntCnt);
			}

		} catch (Exception e) {
			// TODO: handle exception
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 쿠폰 정책 그리드의 정보를 삭제한다.
	 * </pre>
	 * @date 2023. 5. 08.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 08.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param couponPolicyVO
	 * @return map
	 * @throws Exception
	 */
	@RequestMapping("/deleteCouponPolicy")
	@ResponseBody
	public ResponseEntity<Object> deleteCouponPolicy(@RequestBody CouponPolicyVO couponPolicyVO) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		boolean result = false;
		try {
			if (userInfoUtil.getAccountInfo() == null) {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
				retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
				return new ResponseEntity<>(retVal, HttpStatus.OK);
			}

			couponPolicyVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			result = couponPolicyService.deleteCouponPolicy(couponPolicyVO);

			if (result == true) {
				retVal.put(RESULT, SUCCESS);
				retVal.put(ERRMSG, "");
			} else if (result == false) {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "");
			}

		} catch (Exception e) {
			// TODO: handle exception
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 쿠폰 상세 - 상세 발행 내역 모달창을 조회한다. (+발행목록)
	 * </pre>
	 * @date 2023. 5. 08.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 08.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param couponPolicyVO
	 * @return couponPolicyVO
	 * @throws Exception
	 */
	@RequestMapping(value = "/couponPolicyDtl")
	public String couponPolicyDtl(@RequestBody CouponPolicyVO couponPolicyVO, ModelMap model) throws Exception {
		CouponPolicyVO vo = new CouponPolicyVO();
		try {
			vo = couponPolicyService.getCouponPolicyDtl(couponPolicyVO);
			vo.setActiveTabVal(couponPolicyVO.getActiveTabVal());
			model.put("couponPolicyVO", vo);

			return "ev/couponPolicyDtlList.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 쿠폰 상세 - 상세 발행 내역 그리드를 조회한다.
	 * </pre>
	 * @date 2023. 5. 08.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 08.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param couponPolicyVO
	 * @return map
	 * @throws Exception
	 */
	@RequestMapping("/getCouponDtlIsuList")
	@ResponseBody
	public ResponseEntity<?> getCouponDtlIsuList(@RequestBody CouponPolicyVO couponPolicyVO) throws Exception {
//	public Map<String, Object> getCouponDtlIsuList(@RequestBody CouponPolicyVO couponPolicyVO) throws Exception {
		List<CouponPolicyVO> couponDtlIsuList = couponPolicyService.getCouponDtlIsuList(couponPolicyVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalDataCount", couponPolicyService.getCouponDtlIsuListTotCnt(couponPolicyVO));
		map.put("dataList", couponDtlIsuList);

//		return map;
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 쿠폰 정책의 수정 이력 모달창을 조회한다.
	 * </pre>
	 * @date 2023. 5. 11.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 11.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param couponPolicyVO
	 * @return couponPolicyVO
	 * @throws Exception
	 */
	@RequestMapping(value = "/couponPolicyHistory")
	public String couponPolicyHistory(@RequestBody CouponPolicyVO couponPolicyVO, ModelMap model) throws Exception {

		//		Map<String, Object> map = new HashMap<String, Object>();
		try {
			model.put("couponPolicyVO", couponPolicyVO);
			return "ev/couponPolicyHistory.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
		//		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 쿠폰 정책의 수정 이력 그리드를 조회한다.
	 * </pre>
	 * @date 2023. 5. 11.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 11.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param couponPolicyVO
	 * @return map
	 * @throws Exception
	 */
	@RequestMapping("/getCouponPolicyHstList")
	public ResponseEntity<?> getCouponPolicyHstList(@RequestBody CouponPolicyVO couponPolicyVO) throws Exception {
	//public Map<String, Object> getCouponPolicyHstList(@RequestBody CouponPolicyVO couponPolicyVO) throws Exception {
		
		List<CouponPolicyVO> couponDtlIsuList = couponPolicyService.getCouponPolicyHstList(couponPolicyVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalDataCount", couponPolicyService.getCouponPolicyHstListCnt(couponPolicyVO));
		map.put("dataList", couponDtlIsuList);

//		return map;
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	
	/**
	 * <pre>
	 * 처리내용: 프로모션번호로 생성된 쿠폰 정책으로 발행된 쿠폰 데이터 확인
	 * </pre>
	 * @date 2023. 6. 15.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 15.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param couponPolicyVO
	 * @return map
	 * @throws Exception
	 */
	@RequestMapping("/getChkCouponUseCnt")
	@ResponseBody
	public ResponseEntity<?> getChkCouponUseCnt(@RequestBody CouponPolicyVO couponPolicyVO) throws Exception {
		
		Map<String, Object> retVal = new HashMap<String, Object>();
		int chkCouponUseCnt = 0;
		try {
			if (userInfoUtil.getAccountInfo() == null) {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
				retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
				return new ResponseEntity<>(retVal, HttpStatus.OK);
			}
			chkCouponUseCnt = couponPolicyService.getChkCouponUseCnt(couponPolicyVO);
			retVal.put("chkCouponUseCnt", chkCouponUseCnt);

		} catch (Exception e) {
			// TODO: handle exception
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 선택한 프로모션으로 발행된 정책, 디테일 쿠폰 삭제처리
	 * </pre>
	 * @date 2023. 6. 15.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 15.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param couponPolicyVO
	 * @return map
	 * @throws Exception
	 */
	@RequestMapping("/deleteAllCoupon")
	@ResponseBody
	public ResponseEntity<?> deleteAllCoupon(@RequestBody CouponPolicyVO couponPolicyVO) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		boolean result = false;
		try {
			if (userInfoUtil.getAccountInfo() == null) {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
				retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
				return new ResponseEntity<>(retVal, HttpStatus.OK);
			}

			couponPolicyVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			result = couponPolicyService.deleteAllCoupon(couponPolicyVO);
			
			if (result == true) {
				retVal.put(RESULT, SUCCESS);
				retVal.put(ERRMSG, "");
			} else if (result == false) {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "");
			}

		} catch (Exception e) {
			// TODO: handle exception
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
}