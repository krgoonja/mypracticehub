package com.sorincorp.bo.ev.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sorincorp.bo.co.comm.BoCoConstants;
import com.sorincorp.bo.co.comm.CoResponseEntity;
import com.sorincorp.bo.ev.model.CouponEntrpsAppnVO;
import com.sorincorp.bo.ev.model.CouponInfoVO;
import com.sorincorp.bo.ev.service.CouponEntrpsAppnService;
import com.sorincorp.bo.ev.service.CouponInfoService;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * CouponEntrpsAppnController.java
 * @version
 * @since 2022. 8. 4.
 * @author jhcha
 */
@Slf4j
@Controller
@RequestMapping("/ev/couponEntrps")
public class CouponEntrpsAppnController {
	
	@Autowired
	private CouponEntrpsAppnService couponEntrpsAppnService;
		
	@Autowired
	private CouponInfoService couponInfoService;
	
	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired
	private EntrpsMbService entrpsMbService;
	

	@Autowired
	private CustomValidator customValidator;
	
	/**
	 * <pre>
	 * 처리내용: 업체지정쿠폰 목록 페이지를 조회한다.
	 * </pre>
	 * @date 2022. 8. 4.
	 * @author jhcha
	 * @history
	 * @param 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/couponEntrpsAppnList")
	public String couponEntrpsAppnList(Model model) {
		try {
			
			Map<String, String> map = new HashMap<String, String>();
			map.put("", "전체");
			
			CouponInfoVO couponInfoVo = new CouponInfoVO();
			couponInfoVo.setCouponType("03");//업체지정쿠폰
			model.addAttribute("couponEventCode", commonCodeService.getCmmnCodeListStr(
					couponInfoService.selectCouponEventNoList(couponInfoVo), map));
			
			// 빈값 지우기
			//map.remove("");
						
			model.addAttribute("promtnNoList", commonCodeService.getCmmnCodeListStr(
					couponInfoService.selectPromtnNoList(), map));
			model.addAttribute("couponTyCode", commonCodeService.getCmmnCodeListStr(
					commonCodeService.getSubCodesToCommonCode("COUPON_TYPE"), map));					
			model.addAttribute("couponSeCode", commonCodeService.getCmmnCodeListStr(
					commonCodeService.getSubCodesToCommonCode("COUPON_SE_CODE"), map));
			model.addAttribute("metalCode", commonCodeService.getCmmnCodeListStr(
					commonCodeService.getSubCodesToCommonCode("METAL_CODE"), map));	

			return "ev/couponEntrpsAppnRegistn";
			
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}	
	
	/**
	 * <pre>
	 * 처리내용: 업체지정쿠폰 정보 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 8. 4.
	 * @author jhcha
	 * @history 
	 * @param CouponEntrpsAppnVO
	 * @param BindingResult
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@RequestMapping(value="/couponEntrpsAppnListData")
	public ResponseEntity<?> couponEntrpsAppnListData(@RequestBody CouponEntrpsAppnVO searchVO, BindingResult bindingResult) throws Exception {

		if(searchVO.isValidation()) {
			customValidator.validate(searchVO, bindingResult);
		}
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		Map<String,Object> map = new HashMap<String, Object>();
		int totalCount =  couponEntrpsAppnService.getCouponEntrpsAppnListTotcnt(searchVO);
		List<CouponEntrpsAppnVO> couponEntrpsList = couponEntrpsAppnService.getCouponEntrpsAppnList(searchVO);
		
		CouponInfoVO couponInfoVo = new CouponInfoVO();
		couponInfoVo.setCouponType("03");//업체지정쿠폰
		
		map.put("totalDataCount", totalCount);
		map.put("dataList", couponEntrpsList);
	
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 쿠폰 상세정보 조회
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author sumin95
	 * @history 
	 * @param promtn
	 * @return resultVO
	 * @throws Exception
	 */
	@PostMapping("/addCouponEntrps")
	public String addCouponEntrps(@RequestBody CouponEntrpsAppnVO searchVO, ModelMap model) throws Exception {
		
		try {
			Map<String, String> map = new HashMap<String, String>();
			
			//db 등급
			List<MbEntrpsMbVO> entrpsGrad = entrpsMbService.selectEntrpsGrad();
			model.addAttribute("entrpsGrad", entrpsGrad);	
			
			return "ev/couponEntrpsPop.modal";
			
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
				return "error/503";
		}
	}
	/**
	 * <pre>
	 * 처리내용: 직원과 쿠폰을 매핑시킨다.
	 * </pre>
	 * @date 2022. 8. 8.
	 * @author jhcha
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 8.			jhcha			최초작성
	 * ------------------------------------------------
	 * @param authorNo
	 * @param empList
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertCouponEntrps")
	public ResponseEntity<?> insertCouponEntrps(@RequestBody List<CouponEntrpsAppnVO> CouponEntrpsAppnVO) throws Exception{

		couponEntrpsAppnService.insertCouponEntrps(CouponEntrpsAppnVO);
			
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 직원과 쿠폰을 매핑시킨다.
	 * </pre>
	 * @date 2022. 8. 8.
	 * @author jhcha
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 8.			jhcha			최초작성
	 * ------------------------------------------------
	 * @param authorNo
	 * @param empList
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/deleteCouponEntrps")
	public ResponseEntity<?> deleteCouponEntrps(@RequestBody List<CouponEntrpsAppnVO> searchVOList) throws Exception{

		couponEntrpsAppnService.deleteCouponEntrps(searchVOList);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG), HttpStatus.OK);
	}
}