package com.sorincorp.bo.ev.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.ev.model.CouponPolicyVO;
import com.sorincorp.bo.ev.model.OrdtmDscntCouponVO;
import com.sorincorp.bo.ev.service.CouponPolicyService;
import com.sorincorp.bo.ev.service.OrdtmDscntCouponService;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.brandcode.service.BrandCodeService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * OrdtmDscntCouponContoller.java
 * 
 * @version
 * @since 2024. 5. 22.
 * @author huynjin0512
 */
@Slf4j
@Controller
@RequestMapping("/ev/ordtmDscnt")
public class OrdtmDscntCouponContoller {

	@Autowired
	private CouponPolicyService couponPolicyService;

	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Autowired
	private OrdtmDscntCouponService ordtmDscntCouponService;

	@Autowired
	private ItCmnCodeService itCmnCodeService;
	
	@Autowired
	private BrandCodeService brandCodeService;
	
	private static String RESULT = "result";
	private static String CATEGORYNO = "categoryNo";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	/**
	 * <pre>
	 * 처리내용: 월 별 자동 생성 쿠폰 관리 페이지 조회
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.				hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/ordtmDscntCouponList")
	public String ordtmDscntCoupon() throws Exception {
		try {
			return "ev/ordtmDscntCoupon";
		} catch (Exception e) {
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 회원_업체 등급 기준 구매 수량 그리드를 조회한다.
	 * </pre>
	 *  * @date 2024. 5. 23.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.				hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param OrdtmDscntCouponVO
	 * @retur nmap
	 * @throws Exception
	 */
	@RequestMapping("/getOrdtmDscntCouponList")
	public ResponseEntity<?> getCouponPolicyList(@RequestBody OrdtmDscntCouponVO ordtmDscntCouponVO) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();
		List<OrdtmDscntCouponVO> OrdtmDscntCouponList = new ArrayList<OrdtmDscntCouponVO>();
		int totalDataCount = 0;
		
		try {
			OrdtmDscntCouponList = ordtmDscntCouponService.OrdtmDscntCouponList(ordtmDscntCouponVO);
			totalDataCount = ordtmDscntCouponService.ordtmDscntCouponListCnt(ordtmDscntCouponVO);
		} catch (Exception e) {
			// TODO: handle exception
			log.info("[OrdtmDscntCouponContoller.OrdtmDscntCouponList Error] " + e.getMessage());
		}

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", OrdtmDscntCouponList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 월 별 자동 생성 쿠폰 관리 상세 페이지 조회
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.				hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/ordtmDscntCouponDtl")
	public String ordtmDscntCouponDtl(Model model) throws Exception {
		try {
			ItCmnCodeVO vo = new ItCmnCodeVO();
			/*
			 *  주문방식	-2024.05.24 : 현재 쿠폰의 주문타입은 공통(SLE_MTHD_CODE) 과 다름
			 *  orderTyCode - 00(전체), 01(LIVE), 02(지정가) 로 설정되어있음
			 *  추후 수정 필요
			 */
			// 쿠폰 적용 타입 (주문 방식 코드)
			vo.setMainCode("SLE_MTHD_CODE");
			vo.setUseAt("Y");
			List<ItCmnCodeVO> sleMthdCodeList = itCmnCodeService.selectCmnCodeList(vo);
			
			// 메탈코드 리스트
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);
			// 브랜드코드 리스트
			List<BrandCodeVO> brandCodeList = brandCodeService.getBrandCodeList("");
			
			model.addAttribute("sleMthdCodeList", sleMthdCodeList);
			model.addAttribute("metalCodeList", metalCodeList);
			model.addAttribute("brandCodeList", brandCodeList);
			
			return "ev/ordtmDscntCouponDtl.modal";
		} catch (Exception e) {
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503.modal";
		}
	}

	//메탈 선택 시 브랜드 재조회
	@RequestMapping("/ajaxBrandCodeList")
	public ResponseEntity<?> ajaxBrandCodeList(@RequestParam(value = "metalCode") String metalCode) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		ArrayList<BrandCodeVO> brandList = new ArrayList<BrandCodeVO>();

		try {
			List<BrandCodeVO> brandTmpList = brandCodeService.getBrandCodeList("");
			if ("".equals(metalCode) || metalCode == null) {
				map.put("brandCodeList", brandTmpList);
			} else {
				for (BrandCodeVO brandCodeVO : brandTmpList) {
					if (brandCodeVO.getMetalCode().equals(metalCode)) {
						brandList.add(brandCodeVO);
					}
				}
				map.put("brandCodeList", brandList);
			}

			return new ResponseEntity<>(map, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 쿠폰 정책 엑셀 그리드를 조회한다.
	 * </pre>
	 * @date 2023. 5. 02.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 02.			hyunjin05				최초작성
	 * ------------------------------------------------
	 * @param couponPolicyVO
	 * @return map
	 * @throws Exception
	 */
	@RequestMapping("/getCouponPolicyExcelList")
	public ResponseEntity<?> getCouponPolicyExcelList(@RequestBody CouponPolicyVO couponPolicyVO) throws Exception {
		List<CouponPolicyVO> couponPolicyList = couponPolicyService.getCouponPolicyExcelList(couponPolicyVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("dataList", couponPolicyList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	
	/**
	 * <pre>
	 * 처리내용: 월 별 자동 생성 쿠폰 정보를 저장, 삭제한다.
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.				hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param ordtmDscntCouponVO
	 * @return map
	 * @throws Exception
	 */
	@RequestMapping("/insertAndUpdateOrdtmDscntCouponPolicy")
	@ResponseBody
	public ResponseEntity<Object> insertAndUpdateOrdtmDscntCouponPolicy(@RequestBody OrdtmDscntCouponVO ordtmDscntCouponVO) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		boolean result = false;
		try {
			if (userInfoUtil.getAccountInfo() == null) {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
				retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
				return new ResponseEntity<>(retVal, HttpStatus.OK);
			}
			result = ordtmDscntCouponService.insertAndUpdateOrdtmDscntCouponPolicy(ordtmDscntCouponVO);

			if (result == true) {
				retVal.put(RESULT, SUCCESS);
				retVal.put(ERRMSG, "");
			} else if (result == false) {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "");
			}
		} catch (Exception e) {
			// TODO: handle exception
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

}