package com.sorincorp.bo.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import com.sorincorp.bo.login.model.Account;
import com.sorincorp.bo.login.service.AccountServiceImpl;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.util.RedisUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public class LoginAuthenticationFilter extends OncePerRequestFilter {
	private final LoginTokenProvider jwtTokenProvider;
	private final AccountServiceImpl accountService;
	private final RedisUtil redisUtil;
	private final InitConfig initConfig;
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
		// 헤더에서 JWT 정보를 받아온다
		//String token = jwtTokenProvider.resolveToken((HttpServletRequest) request);
		final Cookie accessToken = jwtTokenProvider.getCookie(request, CommonConstants.BO_ACCESS_TOKEN_NAME);
		Account account = (Account) request.getSession().getAttribute("USER");
		
		if(!request.getServletPath().equals("/Common/getUserInfo")) {
			request.getSession().setAttribute(CommonConstants.BO_ACCESS_PATH,request.getServletPath());
		}
		
		if (!redisUtil.hasKey(CommonConstants.REDIS_KEY_BO_MENULIST)) {
			try {
				initConfig.InitSettings();
			} catch (Exception e) {
				log.error(e.getMessage());
				HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			}
		}
		
	//	List<MenuAuthVO> menuAhthList = (List<MenuAuthVO>) redisUtil.getData("bomenukey:bo:"+request.getServletPath());
		
		if (null!=account) {
			if (null!=accessToken) {
				String token = accessToken.getValue();
				
				// 유효한 토큰인지 확인
				if ( token != null && jwtTokenProvider.validateToken(token) ) {
					// 토큰이 유효하면 토큰으로 부터 유저정보를 받아옴
					Authentication authentication = jwtTokenProvider.getAuthentication(token);
					// SecurityContext에 Authentication 객체를 저장
					SecurityContextHolder.getContext().setAuthentication(authentication);
				} else {
					//log.debug("token expired");
					//log.debug(account.toString());
					
					UserDetails userDetails = accountService.loadUserByUsername(account.getId());
					
					UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
					usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
					SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
				}
				
			}
			else {
				UserDetails userDetails = accountService.loadUserByUsername(account.getId());
				
				UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
				usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
				
				String loginToken = jwtTokenProvider.createToken(account.getId());
				ResponseCookie loginCookie = jwtTokenProvider.createSecureCookie(CommonConstants.BO_ACCESS_TOKEN_NAME,  loginToken, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);
			}
			
		}
		else {
			ResponseCookie responseAccesstoken = jwtTokenProvider.createSecureCookie(CommonConstants.BO_ACCESS_TOKEN_NAME,null,0);
			response.addHeader(HttpHeaders.SET_COOKIE, responseAccesstoken.toString());
		}
/*		
 *     BO 접근시 권한 체크하여 없으면 처리 부분
		boolean isAuth = false;
		if (null==menuAhthList) {
			isAuth =true;
		}
		else if (menuAhthList.size()==0) {
			isAuth =true;
		}
		else {
			if (null!=account) {
				for(MenuAuthVO menuAuth : menuAhthList) {
					if (account.getAuthorNo().equals(String.valueOf(menuAuth.getAuthorNo()))){
						if (menuAuth.isInqireAuthorAtBool()) {
							isAuth =true;
						}
						break;
					}
				}
			}
		}
		
		if (!isAuth) {
			throw new ServletException("권한이 없습니다.");
		}
*/
		filterChain.doFilter(request, response);
	}
}
