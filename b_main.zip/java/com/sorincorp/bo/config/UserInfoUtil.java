package com.sorincorp.bo.config;

import java.util.Optional;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.sorincorp.bo.login.model.Account;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@RequiredArgsConstructor
public class UserInfoUtil {

	Authentication auth = null;
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 정보를 얻는다.
	 * </pre>
	 * @date 2021. 8. 13.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @throws Exception
	 */
	public Account getAccountInfo() {
		Account account = null;
		auth = SecurityContextHolder.getContext().getAuthentication();
		if ( !"anonymousUser".equals(auth.getPrincipal()) ) account = (Account)auth.getPrincipal();
		return account;
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 직원명을 구한다.
	 * </pre>
	 * @date 2021. 8. 13.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param 
	 */
	public String getUserName() {
		return Optional.ofNullable(getAccountInfo())
				.map(Account::getName)
				.orElse(null);
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 직원의 id를 구한다.
	 * </pre>
	 * @date 2021. 8. 13.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param 
	 */
	public String getUserId() {
		return Optional.ofNullable(getAccountInfo())
				.map(Account::getId)
				.orElse(null);
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 직원번호를 구한다.
	 * </pre>
	 * @date 2021. 8. 13.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param 
	 */
	public String getEmplNo() {
		return Optional.ofNullable(getAccountInfo())
				.map(Account::getEmplNo)
				.orElse(null);
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 모바일번호를 구한다.
	 * </pre>
	 * @date 2021. 8. 13.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param 
	 */
	public String getMobileNo() {
		return Optional.ofNullable(getAccountInfo())
				.map(Account::getMobileNo)
				.orElse(null);
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 회사 전화번호를 구한다.
	 * </pre>
	 * @date 2021. 8. 13.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param 
	 */
	public String getTelNo() {
		return Optional.ofNullable(getAccountInfo())
				.map(Account::getTelNo)
				.orElse(null);
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 회사 이메일를 구한다.
	 * </pre>
	 * @date 2021. 8. 13.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param 
	 */
	public String getEmail() {
		return Optional.ofNullable(getAccountInfo())
				.map(Account::getEmail)
				.orElse(null);
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 권한번호를 구한다.
	 * </pre>
	 * @date 2021. 8. 13.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param 
	 */
	public String getAuthorNo() {
		return Optional.ofNullable(getAccountInfo())
				.map(Account::getAuthorNo)
				.orElse(null);
	}

	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 부서명를 구한다.
	 * </pre>
	 * @date 2024. 8. 8.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 8. 8.			sein					최초작성
	 * ------------------------------------------------
	 * @param 
	 */
	public String getKoreaDeptNm() {
		return Optional.ofNullable(getAccountInfo())
				.map(Account::getKoreanDeptNm)
				.orElse(null);
	}
	
}