package com.sorincorp.bo.config;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.maven.shared.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.co.model.MenuAuthVO;
import com.sorincorp.bo.co.model.MenuVO;
import com.sorincorp.bo.co.service.MenuService;
import com.sorincorp.bo.co.service.RedisSubscriberBo;
import com.sorincorp.bo.it.service.PrimiumPriceMngService;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.RedisUtil;


@Service
public class InitConfig {

	@Autowired
	MenuService menuService;

	@Autowired
	RedisUtil redisUtil;

	@Autowired
	RedisPubSubService redisPubSubService;

	@Autowired
	RedisSubscriberBo redisSubscriberBo;

	@Autowired
	PrimiumPriceMngService primiumPriceMngService;

	@Value("${metalCode.list}")
	private List<String> metalCodeList;

	@Value("${redisPubsub.uri.sel}")
	private String selPcUri;

	@Value("${redisPubsub.uri.lme}")
	private String lmePcUri;

	@Value("${redisPubsub.uri.wishAlram}")
	private String wishAlram;

	@Value("${redisPubsub.uri.fx}")
	private String fxpcUri;

	@Value("${redisPubsub.crncyCode.KRW}")
	private String fxpcKRW;

	@Value("${redisPubsub.uri.sidecar}")
	private String sidecarUri;

	@Value("${redisPubsub.uri.restTime}")
	private String restTimeUri;

	@Value("${redisPubsub.uri.startLmeData}")
	private String startLmeDataUri;
	
	@Value("${redisPubsub.uri.limit}")
	private String limitUri;
	
	@Value("${redisPubsub.uri.premium}")
	private String premiumUri;
	
	@Value("${redisPubsub.uri.track}")
	private String trackUri;

	@Value("${redisPubsub.uri.invntry}")
	private String invntryUri;

	@Value("${redisPubsub.uri.selpcAll}")
	private String selpcAllUri;

	@Value("${redisPubsub.uri.properties}")
	private String propertiesUri;


	@Bean(initMethod="init")
	public void InitSettings() throws Exception{

		List<MenuVO> menuList = menuService.getSideBarMenu("");
		redisUtil.setData(CommonConstants.REDIS_KEY_BO_MENULIST, menuList);

		List<MenuVO> urlMenuList = menuList.stream()
									.filter(menu->StringUtils.isNotEmpty(menu.getMenuUrl()))
									.collect(Collectors.toList());


		List<MenuAuthVO> menuAuthInfoList = menuService.getMenuAuthInfoList(urlMenuList.stream().map(MenuVO::getMenuNo).collect(Collectors.toList()));

		for (MenuVO menu : urlMenuList) {
			redisUtil.setData(CommonConstants.REDIS_KEY_BO_MENU_URL_PREFIX + menu.getMenuUrl(),
					menuAuthInfoList.stream().filter(menuAuthInfo -> menuAuthInfo.getMenuNo() == menu.getMenuNo())
							.collect(Collectors.toList()));
		}

		// 실시간 환율
		if(!redisPubSubService.isExistChannel(fxpcUri + "/" + fxpcKRW)) {
			redisPubSubService.createChannel(fxpcUri + "/" + fxpcKRW, redisSubscriberBo);
		}
		if(!redisPubSubService.isExistChannel(fxpcUri + "/" + fxpcKRW + "/01")) {
			redisPubSubService.createChannel(fxpcUri + "/" + fxpcKRW + "/01", redisSubscriberBo);
		}
		if(!redisPubSubService.isExistChannel(fxpcUri + "/" + fxpcKRW + "/30")) {
			redisPubSubService.createChannel(fxpcUri + "/" + fxpcKRW + "/30", redisSubscriberBo);
		}
		if(!redisPubSubService.isExistChannel(fxpcUri + "/" + fxpcKRW + "/60")) {
			redisPubSubService.createChannel(fxpcUri + "/" + fxpcKRW + "/60", redisSubscriberBo);
		}
		if(!redisPubSubService.isExistChannel(fxpcUri + "/" + fxpcKRW + "/DE")) {
			redisPubSubService.createChannel(fxpcUri + "/" + fxpcKRW + "/DE", redisSubscriberBo);
		}
		if(!redisPubSubService.isExistChannel(fxpcUri + "/" + fxpcKRW + "/MT")) {
			redisPubSubService.createChannel(fxpcUri + "/" + fxpcKRW + "/MT", redisSubscriberBo);
		}
		// 희망가
		if(!redisPubSubService.isExistChannel(wishAlram)) {
			redisPubSubService.createChannel(wishAlram, redisSubscriberBo);
		}
		if(!redisPubSubService.isExistChannel(limitUri)) {
			redisPubSubService.createChannel(limitUri, redisSubscriberBo);
		}
		// 트랙
		if(!redisPubSubService.isExistChannel(trackUri)) {
			redisPubSubService.createChannel(trackUri, redisSubscriberBo);
		}

		//금속코드별 판매가격 수신
		for (String metalCode : metalCodeList) {
			// 실시간 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode)) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode, redisSubscriberBo);
			}
			// 1분 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/01")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/01", redisSubscriberBo);
			}
			// 30분 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/30")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/30", redisSubscriberBo);
			}
			// 60분 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/60")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/60", redisSubscriberBo);
			}
			// 일 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/DE")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/DE", redisSubscriberBo);
			}
			// 주 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/WK")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/WK", redisSubscriberBo);
			}
			// 월 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/MT")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/MT", redisSubscriberBo);
			}
			// 분기 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/QU")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/QU", redisSubscriberBo);
			}
			// 년 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/YY")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/YY", redisSubscriberBo);
			}
			
			if(!redisPubSubService.isExistChannel(selpcAllUri + "/" + metalCode)) {
 				redisPubSubService.createChannel(selpcAllUri + "/" + metalCode, redisSubscriberBo);
			}
		}

		//금속코드별 판매가격 수신
		for (String metalCode : metalCodeList) {
			// 실시간 판매 가격
			if(!redisPubSubService.isExistChannel(lmePcUri + "/" + metalCode)) {
				redisPubSubService.createChannel(lmePcUri + "/" + metalCode, redisSubscriberBo);
			}
			// 1분 판매 가격
			if(!redisPubSubService.isExistChannel(lmePcUri + "/" + metalCode + "/01")) {
				redisPubSubService.createChannel(lmePcUri + "/" + metalCode + "/01", redisSubscriberBo);
			}
			// 30분 판매 가격
			if(!redisPubSubService.isExistChannel(lmePcUri + "/" + metalCode + "/30")) {
				redisPubSubService.createChannel(lmePcUri + "/" + metalCode + "/30", redisSubscriberBo);
			}
			// 60분 판매 가격
			if(!redisPubSubService.isExistChannel(lmePcUri + "/" + metalCode + "/60")) {
				redisPubSubService.createChannel(lmePcUri + "/" + metalCode + "/60", redisSubscriberBo);
			}
			// 일 판매 가격
			if(!redisPubSubService.isExistChannel(lmePcUri + "/" + metalCode + "/DE")) {
				redisPubSubService.createChannel(lmePcUri + "/" + metalCode + "/DE", redisSubscriberBo);
			}
			// 주 판매 가격
			if(!redisPubSubService.isExistChannel(lmePcUri + "/" + metalCode + "/WK")) {
				redisPubSubService.createChannel(lmePcUri + "/" + metalCode + "/WK", redisSubscriberBo);
			}
			// 월 판매 가격
			if(!redisPubSubService.isExistChannel(lmePcUri + "/" + metalCode + "/MT")) {
				redisPubSubService.createChannel(lmePcUri + "/" + metalCode + "/MT", redisSubscriberBo);
			}
			// 분기 판매 가격
			if(!redisPubSubService.isExistChannel(lmePcUri + "/" + metalCode + "/QU")) {
				redisPubSubService.createChannel(lmePcUri + "/" + metalCode + "/QU", redisSubscriberBo);
			}
			// 년 판매 가격
			if(!redisPubSubService.isExistChannel(lmePcUri + "/" + metalCode + "/YY")) {
				redisPubSubService.createChannel(lmePcUri + "/" + metalCode + "/YY", redisSubscriberBo);
			}
		}

		// 사이드카
		if(!redisPubSubService.isExistChannel(sidecarUri)) {
			redisPubSubService.createChannel(sidecarUri, redisSubscriberBo);
		}
		// lme 시작
		if(!redisPubSubService.isExistChannel(startLmeDataUri)) {
			redisPubSubService.createChannel(startLmeDataUri, redisSubscriberBo);
		}
		// selPc
		if(!redisPubSubService.isExistChannel(selPcUri)) {
			redisPubSubService.createChannel(selPcUri, redisSubscriberBo);
		}
		// lme 휴무시간 실시간 적용
		if(!redisPubSubService.isExistChannel(restTimeUri)) {
			redisPubSubService.createChannel(restTimeUri, redisSubscriberBo);
		}
		// 프리미엄 가격정보
		if(!redisPubSubService.isExistChannel(premiumUri)) {
			redisPubSubService.createChannel(premiumUri, redisSubscriberBo);
		}

		//금속코드별 재고데이터 수신
		for (String metalCode : metalCodeList) {
			if(!redisPubSubService.isExistChannel(invntryUri + "/" + metalCode)) {
				redisPubSubService.createChannel(invntryUri + "/" + metalCode, redisSubscriberBo);
			}
		}

		// COMM 설정 값 변경 요청 (다이버 임시 사용)
		if(!redisPubSubService.isExistChannel(propertiesUri)) {
			redisPubSubService.createChannel(propertiesUri, redisSubscriberBo);
		}

	}

	@Value("${spring.bo.domain}")
	private void setServerDomain(String domain) {
		//System.out.println("---------------------------------------------------------------------------------------------------------"+domain);
		CommonConstants.SERVER_DOMAIN = domain;
	}

	public void InitMenuSettings() throws Exception{
		List<MenuVO> menuList = menuService.getSideBarMenu("");
		redisUtil.setData(CommonConstants.REDIS_KEY_BO_MENULIST, menuList);

		List<MenuVO> urlMenuList = menuList.stream()
									.filter(menu->StringUtils.isNotEmpty(menu.getMenuUrl()))
									.collect(Collectors.toList());

		// 메뉴 권한 리스트 한 번에 조회
		List<MenuAuthVO> menuAuthInfoList = menuService.getMenuAuthInfoList(urlMenuList.stream().map(MenuVO::getMenuNo).collect(Collectors.toList()));

		// 메뉴 번호 별 권한 설정
		for (MenuVO menu : urlMenuList) {
			redisUtil.setData(CommonConstants.REDIS_KEY_BO_MENU_URL_PREFIX + menu.getMenuUrl(),
					menuAuthInfoList.stream().filter(menuAuthInfo -> menuAuthInfo.getMenuNo() == menu.getMenuNo())
							.collect(Collectors.toList()));
		}
	}

}
