package com.sorincorp.bo.config;



import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.sorincorp.bo.login.service.AccountServiceImpl;
import com.sorincorp.comm.util.RedisUtil;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	private final LoginTokenProvider jwtTokenProvider;
	private final AccountServiceImpl accountService;

	private final RedisUtil redisUtil;
	private final InitConfig initConfig;
	
	/**
	 * 로그인 체크가 필요없는 URL 지정
	 */
	private static final String[] IGNORE_LIST = {
			"/images/**", 
			"/css/**", 
			"/js/**",
			"/fonts/*",
			"/guide/*",
			"/error/*",
			"/properties/*"
	};
	
	/**
	 * <pre>
	 * 암호화에 필요한 PasswordEncoder를 Bean 등록
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@Bean
	public PasswordEncoder passwordEncoder() {
		return PasswordEncoderFactories.createDelegatingPasswordEncoder();
	}
	
	/**
	 * authenticationMannger를 Bean 등록
	 */
	@Bean
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}
	
	/**
	 * Spring Security Configuration 설정. 로그인이 필요한 경우 JWT Token 체크를 위한 Filter를 거치도록 지정
	 */
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.headers().frameOptions().sameOrigin().and()
			.httpBasic().disable()
		//	.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
		//	.and()
			.authorizeRequests()
			/* ROLE을 사용하는 경우만 처리
			.antMatchers("/admin/**").hasRole("ADMIN") 
			*/		
//			.antMatchers("/**").permitAll()
			.antMatchers("/").authenticated()
			.anyRequest().permitAll()
			.and().formLogin().loginPage("/login/loginView")
			.and().logout().logoutUrl("/login/logout").logoutSuccessUrl("/login/loginView").deleteCookies("boaccessToken")
			.and().csrf().disable()
			.addFilterBefore(new LoginAuthenticationFilter(jwtTokenProvider,accountService, redisUtil, initConfig), UsernamePasswordAuthenticationFilter.class);
	}
	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers(IGNORE_LIST);
	}
	
	
}




