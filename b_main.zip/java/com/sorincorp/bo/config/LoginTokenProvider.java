package com.sorincorp.bo.config;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.crypto.SecretKey;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseCookie;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;

import com.sorincorp.bo.login.service.AccountServiceImpl;
import com.sorincorp.comm.constants.CommonConstants;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Component
@Slf4j
public class LoginTokenProvider {
	private String secretKey = "sorinec"+"commerce"+"12345678901234567890";
	
	
	private SecretKey sorinScretKey;
	// 토큰 유효시간 30분
	private long tokenValidTime = CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND;
	
	private final UserDetailsService userDetailsService;
	
	private final AccountServiceImpl accountService;
	
	
	// 객체 초기환. securetKey를 Base64로 인코딩 한다.
	@PostConstruct
	protected void init() {
		sorinScretKey = Keys.hmacShaKeyFor(secretKey.getBytes(StandardCharsets.UTF_8));
		secretKey = Base64.getEncoder().encodeToString(secretKey.getBytes());
	}
	
	// JWT 토큰 생성(ROLE을 사용하지 않는 경우)
	public String createToken(String userPk) {
		Claims claims = Jwts.claims();	// JWT payload에 저장되는 정보 단위
	//	Claims claims = Jwts.claims().setSubject(userPk);	// JWT payload에 저장되는 정보 단위
		claims.put("userId", userPk);
		Date now = new Date();
		
		return Jwts.builder()
				   .setClaims(claims)	// 정보 저장
				   .setIssuedAt(now)	// 토큰 발행시간 정보
				   .setExpiration(new Date(now.getTime() + tokenValidTime))	// set Expire Time
				   .signWith(sorinScretKey,SignatureAlgorithm.HS256)
//				   .signWith(SignatureAlgorithm.HS256, secretKey)	// 사용할 암호화 알고리즘과 signature에 들어갈 secret 값 세틴
				   .compact();
	}

	/*
	// JWT 토큰 생성(ROLE을 사용하는 경우)
	public String createToken(String userPk, List<String> roles) {
		Claims claims = Jwts.claims().setSubject(userPk);	// JWT payload에 저장되는 정보 단위
		claims.put("roles", roles);							// 정보는 key / value 쌍으로 저장된다.
		
		Date now = new Date();
		
		return Jwts.builder()
				   .setClaims(claims)	// 정보 저장
				   .setIssuedAt(now)	// 토큰 발행시간 정보
				   .setExpiration(new Date(now.getTime() + tokenValidTime))	// set Expire Time
				   .signWith(SignatureAlgorithm.HS256, secretKey)	// 사용할 암호화 알고리즘과 signature에 들어갈 secret 값 세틴
				   .compact();
	}
	*/
	
	// JWT 토큰에서 인증정보 조회
	public Authentication getAuthentication(String token) {
		UserDetails userDetails = accountService.loadUserByUsername(this.getUserPk(token));
		
		return new UsernamePasswordAuthenticationToken(userDetails, "", userDetails.getAuthorities());
	}
	
	// 토큰에서 회원정보 추출
	public String getUserPk(String token) {
	//	Claims clime = extractAllClaims(token);
		return extractAllClaims(token).get("userId", String.class);
	//	return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody().getSubject();
	}
	
	/**
	 * <pre>
	 * JWT Token에 등록되어 있는 Payload 정보(Claims)를 모두 읽어온다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param token
	 * @return
	 * @throws ExpiredJwtException
	 */
	public Claims extractAllClaims(String token) throws ExpiredJwtException {
		return Jwts.parserBuilder()
				.setSigningKey(sorinScretKey)
				.build()
				.parseClaimsJws(token)
				.getBody();
	}
	
	
	// Request의 Cookie에서 token 값을 가져온다. "X-AUTH-TOKEN" : "TOKEN 값"
//	public String resolveToken(HttpServletRequest request) {
//		String token = null;
//		
//		Cookie[] cookies = request.getCookies();
//		if ( cookies != null ) {
//			for ( Cookie cookie : cookies ) {
//				String name = cookie.getName();
//				if ( "loginToken".equals(name) ) {
//					token = cookie.getValue();
//					break;
//				}
//			}
//		}
//
//		return token;
//	}
	
	/**
	 * <pre>
	 * Cookie에서 Token 값을 읽어온다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param cookieName
	 * @return
	 */
	public Cookie getCookie(HttpServletRequest request, String cookieName) {
		final Cookie[] cookies = request.getCookies();
		if ( cookies == null ) return null;
		
		for ( Cookie cookie : cookies ) {
			if ( cookie.getName().equals(cookieName) ) {
				return cookie;
			}
		}
		
		return null;
	}
	
	// 토큰 유효성 + 만료일자 확인
	public boolean validateToken(String jwtToken) {
		try {
			Jws<Claims> claims = Jwts.parser().setSigningKey(secretKey).parseClaimsJws(jwtToken);
			
			return !claims.getBody().getExpiration().before(new Date());
		} catch (Exception e) {
			return false;
		}
	}
	
	/**
	 * <pre>
	 * Cookie에 값을 저장하여 생성한다..(sameSite,secure 설정)
	 * </pre>
	 * @date 2021. 8. 4.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 4.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param cookieName
	 * @param value
	 * @param expireTime
	 * @return
	 */
	public ResponseCookie createSecureCookie(String cookieName, String value, long expireTime) {
		ResponseCookie cookie = ResponseCookie.from(cookieName, value) // key & value
				.httpOnly(true)		// prohibit js reading
//				.secure(true)		// also transmit under http
//				.domain(CommonConstants.SERVER_DOMAIN)// domain name
				.path("/")			// path
				.maxAge(Duration.ofMillis(expireTime))	// Expires in 1 hour
//				.sameSite("Lax")	// In most cases, third-party cookies are not sent, except for Get requests that navigate to the target URL
				.build()
				;
		log.debug("CommonConstants.SERVER_DOMAIN: " + CommonConstants.SERVER_DOMAIN);
		return cookie;
	}
}
