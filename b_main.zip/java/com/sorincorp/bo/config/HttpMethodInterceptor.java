package com.sorincorp.bo.config;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.apache.maven.artifact.repository.Authentication;
import org.apache.poi.util.SystemOutLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndViewDefiningException;
import org.springframework.web.servlet.mvc.WebContentInterceptor;
import org.springframework.web.util.UrlPathHelper;

import com.sorincorp.comm.constants.ExceptionConstants;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.util.JsonUtil;
import com.sorincorp.comm.util.MessageUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HttpMethodInterceptor extends WebContentInterceptor {
	@Autowired
	MessageSource message;


	/*
	 * @Title: preHandle
	 * @Description:
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 13.		chajeeman			/bo/ma/dashboard/order 호출의 경우 제외
	 * 2023. 05. 09. 		srec0066			/bo/ma/dashboard/limitOrder 호출의 경우 제외
	 * 2023. 07. 04.		srec0049			/bo/ma/callTest 호출의 경우 제외
	 * 2023. 07. 04.		srec0049			/bo/ma/foCallTest 호출의 경우 제외
	 * ------------------------------------------------
	 * @param request
	 * @param response
	 * @param handler
	 * @return
	 * @throws ServletException
	 * @see org.springframework.web.servlet.mvc.WebContentInterceptor#preHandle(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object)
	 */
	@Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws ServletException{
		try {
			StringBuilder errorStr = new StringBuilder(StringUtils.EMPTY);
			String forwardUrl = "/login/sessionExpired";
			if(request.getRequestURI().contains("/login/getToken") || request.getRequestURI().contains("/login/loginView") || request.getRequestURI().contains("/Common/getUserInfo")
					|| request.getRequestURI().contains("/bo/ma/dashboard/order") || request.getRequestURI().contains("/bo/ma/dashboard/limitOrder") || request.getRequestURI().contains("/bo/trckDashboard/viewTrckDashboard")
					|| request.getRequestURI().contains("/bo/ma/dashboard/diverRunning") || request.getRequestURI().contains("/bo/ma/dashboard/rcpmny")
					|| request.getRequestURI().contains("/bo/ma/callTest") || request.getRequestURI().contains("/bo/ma/foCallTest")
					|| request.getRequestURI().contains("/bo/orderDashboard/") || request.getRequestURI().contains("/chart/pcMngtrngSelList") || request.getRequestURI().contains("/pr/pcMntrng/getPremiumInfoMap") || request.getRequestURI().contains("/bo/dashboard/getSarokPcList")
					|| request.getRequestURI().contains("/chart/headerRestInfo") || request.getRequestURI().contains("/chart/restDtTimeSet") || request.getRequestURI().contains("/bo/trckDashboard/") )
				return true;
			if(request.getSession().getAttribute("USER") == null && !request.getRequestURI().contains("/login/sessionExpired") && request.getRequestURI().indexOf(".") == -1) {
				if(isAjaxRequest(request)) {
					//response.setStatus(HttpServletResponse.SC_FORBIDDEN);
					response.setStatus(999);
					response.setContentType("application/json;charset=UTF-8");
					response.getWriter().write("서버와의 연결이 종료되어 time초 후 새로고침합니다.&" + request.getRequestURI().toString());
					response.getWriter().write(errorStr.toString());
					response.getWriter().flush();

					return false;
				}
 				response.addHeader("url", request.getRequestURI());
				request.getServletContext().getRequestDispatcher(forwardUrl).forward(request, response);

				return false;
			}
			return true;
		} catch (IOException e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
		}
		return true;
	}

	private boolean isAjaxRequest(HttpServletRequest request) {
		String header = request.getHeader("X-Requested-With");
		return "XMLHttpRequest".equals(header);
	}
}
