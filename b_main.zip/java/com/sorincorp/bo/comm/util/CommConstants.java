package com.sorincorp.bo.comm.util;

public final class CommConstants {
	
	private CommConstants(){}
	
	public static final int SUCCESS_CODE = 200;
	public static final int ERROR_CODE = 400;
	
	public static final String RESULT = "result";
	public static final String ERRMSG = "errMsg";
	
	public static final String SUCCESS = "Success";
	public static final String FAIL = "Error";
	
	public static final String SUCCESS_MSG = "Success";
	public static final String ERROR_MSG= "Error";
	
}