package com.sorincorp.bo.comm.util;

import lombok.Data;

@Data
public class CommResponseEntity {
	
	private int responseCode;
	private String msg;
	private Object data;
	private Object dataList;
	
	private int totalDataCount;
	
	public CommResponseEntity(int responseCode, String msg) {
		this.responseCode = responseCode;
		this.msg = msg;
	}
	
	public CommResponseEntity(int responseCode, Object data) {
		this.responseCode = responseCode;
		this.data = data;
	}
	
	public CommResponseEntity(int responseCode, String msg, Object dataList) {
		this.responseCode = responseCode;
		this.msg = msg;
		this.dataList = dataList;
	}
	
	public CommResponseEntity(int responseCode, String msg, Object data, Object dataList) {
		this.responseCode = responseCode;
		this.msg = msg;
		this.data = data;
		this.dataList = dataList;
	}
	
	public CommResponseEntity(int responseCode, String msg, Object dataList, int totalDataCount) {
		this.responseCode = responseCode;
		this.msg = msg;
		this.dataList = dataList;
		this.totalDataCount = totalDataCount;
	}

}
