package com.sorincorp.bo.comm.tags;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.sorincorp.bo.co.model.MenuAuthVO;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.RedisUtil;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
@Data
public class comIconBtn extends SimpleTagSupport{
	private String id; // 엘리먼트 아이디
	private String btnClass; // 아이콘 버튼의 class
	private String onclick; // 클릭 이벤트
	private boolean disabled = false; // 아이콘 버튼 비활성화 true/false
	private String type; // 아이콘 버튼 타입
	private String iconMessage; // 아이콘 버튼에 표시될 메시지
	private String iconClass; // 아이콘 버튼에 표시될 클래스
	private String desc; // validation desc
	private String name; // 아이콘 버튼 name
	private String uri;  // 팝업 페이지일 시 권한 처리를 위한 부모 페이지 uri
	private String style;  // inline style

	RedisUtil redisUtil;

	@Autowired(required = true)
	private HttpServletRequest request;

	@Override
	public void doTag() throws JspException, IOException {
		PageContext pageContext = (PageContext)this.getJspContext();
		request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		WebApplicationContext context = WebApplicationContextUtils.getRequiredWebApplicationContext(pageContext.getServletContext());

		redisUtil = context.getBean(RedisUtil.class);

		boolean inquire = false; // 조회 권한 여부
		boolean input = false;  // 입력 권한 여부
		boolean update = false; // 수정 권한 여부
		boolean delete = false; // 삭제 권한 여부
		boolean excel = false;  // 엑셀 권한 여부
		boolean isAuth = false; // 권한 여부

		Account account = (Account) request.getSession().getAttribute("USER");
		List<MenuAuthVO> menuAhthList = new ArrayList<MenuAuthVO>();

		if(account != null) {

			menuAhthList = (List<MenuAuthVO>) redisUtil.getData("bomenukey:bo:"+request.getAttribute("javax.servlet.forward.request_uri"));

			if(menuAhthList == null && !"".equals(uri)) {
				menuAhthList= (List<MenuAuthVO>) redisUtil.getData("bomenukey:bo:"+ uri);
			}

			List<String> userAuthList = Arrays.asList(account.getAuthorNo().split(","));

			if(null == menuAhthList || null == userAuthList) {
				isAuth = false;
			}
			else if(menuAhthList.size() == 0 || userAuthList.size() == 0) {
				isAuth = false;
			}
			else {
				System.out.println("type:"+type);
				for (MenuAuthVO authNo : menuAhthList) {

				    if (userAuthList.indexOf(String.valueOf(authNo.getAuthorNo())) != -1){

						if (authNo.isInqireAuthorAtBool() && type.equals("inquire") ) { // 조회 권한 여부
							//inquire = true;
							isAuth =true;
						}
						if (authNo.isInputAuthorAtBool() && type.equals("input")) {  // 입력 권한 여부
							//input= true;
							isAuth =true;
						}
						if (authNo.isUpdtAuthorAtBool() && type.equals("update")) {   // 수정 권한 여부
							//update = true;
							isAuth =true;
						}
						if (authNo.isDeleteAuthorAtBool() && type.equals("delete") ) {	// 삭제 권한 여부
							//delete = true;
							isAuth =true;
						}
						if (authNo.isExcelAuthorAtBool() && type.equals("excel")) {   // 엑셀 권한 여부
							//excel = true;
							isAuth =true;
						}
						break;
					}
				}
			}

			if (isAuth) {
				StringBuilder sb = new StringBuilder("");
				sb.append("<button type='button'")
				  .append(" id='" + id + "'")
				  .append(" class='" + btnClass + "'");

				if(onclick != null && !onclick.equals("")) {
					onclick = onclick.replaceAll("\"", "\'");
					sb.append(" onclick=\"" + onclick + "\"");
				}

				if(desc != null && !desc.equals("") ) {
					sb.append(" desc='" + desc + "'");
				}

				if(style != null && !style.equals("") ) {
					sb.append(" style='" + style + "'");
				}

				if(disabled) {
					sb.append(" disabled");
				}
				sb.append(">");

				if(iconClass != null && !iconClass.equals("")) {
					sb.append("<i class='" + iconClass + "'>")
					  .append(iconMessage+"</i>");
				}

				sb.append("</button>");

				JspWriter out = getJspContext().getOut();
				out.print(sb.toString());

				super.doTag();
			}
		}
	}

}
