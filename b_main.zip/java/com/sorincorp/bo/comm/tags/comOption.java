package com.sorincorp.bo.comm.tags;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.sorincorp.bo.co.model.MenuAuthVO;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.util.RedisUtil;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@RequiredArgsConstructor
@Component
@Data
public class comOption extends SimpleTagSupport{

	private String id; // 엘리먼트 id
	private String codeStr; // 코드 데이터 문자열 예) ':전체;Y:동의;N:거부’ option 태그 value : option 텍스트 형태로 제공
	private String value; // option 태그의 초기 선택 설정 값
	private String optClass; // 셀렉트 박스의 class
	private boolean disabled = false; // 셀렉트 박스 비활성화 true/false
	private String getCodes; // 공통 메인 코드 - 공통코드 값(codeValue)을 가져옴
	private String onChange; // onChange 이벤트
	private String desc; // validation desc
	private String name; // 셀렉트 박스의 name
	private String uri;  // 팝업 페이지일 시 권한 처리를 위한 부모 페이지 uri
	private String style;  // inline style

	RedisUtil redisUtil;

	@Autowired(required = true)
	private HttpServletRequest request;

	CommonCodeService commonCodeService;

	@Override
	public void doTag() throws JspException, IOException {

		PageContext pageContext = (PageContext)this.getJspContext();
		request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		WebApplicationContext context = WebApplicationContextUtils.getRequiredWebApplicationContext(pageContext.getServletContext());

		redisUtil = context.getBean(RedisUtil.class);
		commonCodeService = context.getBean(CommonCodeService.class);

		Account account = (Account) request.getSession().getAttribute("USER");

		boolean inquire = false; // 조회 권한 여부
		boolean input = false;  // 입력 권한 여부
		boolean update = false; // 수정 권한 여부
		boolean isAuth = false; // 권한 여부

		List<MenuAuthVO> menuAhthList = new ArrayList<MenuAuthVO>();

		if(null!=account) {

			menuAhthList = (List<MenuAuthVO>) redisUtil.getData("bomenukey:bo:"+request.getAttribute("javax.servlet.forward.request_uri"));

			if(menuAhthList == null && !"".equals(uri)) {
				menuAhthList= (List<MenuAuthVO>) redisUtil.getData("bomenukey:bo:"+ uri);
			}

			List<String> userAuthList = Arrays.asList(account.getAuthorNo().split(","));

			if(null == menuAhthList || null == userAuthList) {
				isAuth = false;
			}
			else if(menuAhthList.size() == 0 || userAuthList.size() == 0) {
				isAuth = false;
			}
			else {

				for(MenuAuthVO authNo : menuAhthList) {

					if (userAuthList.indexOf(String.valueOf(authNo.getAuthorNo())) != -1){
							if (authNo.isInqireAuthorAtBool()) {
								inquire= true;
								isAuth = true;
							}

							if (authNo.isInputAuthorAtBool()) {
								input= true;
								isAuth = true;
							}

							if (authNo.isUpdtAuthorAtBool()) {
								update = true;
								isAuth = true;
							}

							break;
					}

			  }

		 }

		if (!input || !update || !inquire) {
			 isAuth = false;
		}

		if (isAuth) {
		StringBuilder sb = new StringBuilder("");
		StringTokenizer codeListToken = new StringTokenizer(codeStr, CommonConstants.SEMI_COLONE);
		String token;
		String selected;
		String code[];
		String inputTag = "";
		int index = 0;

				inputTag += "<select";

				if(id != null && !id.equals("")) {
					inputTag += " id = '" + id + "'";
				}

				if(optClass != null && !optClass.equals("")) {
					inputTag += " class = '"+ optClass +"'";
				}

				if(onChange != null && !onChange.equals("")) {
					inputTag += " onChange = '"+ onChange +"'";
				}

				if(desc != null && !desc.equals("") ) {
					inputTag += " desc='" + desc + "'";
				}

				if(name != null && !name.equals("") ) {
					inputTag += " name='" + name + "'";
				}

				if(style != null && !style.equals("") ) {
					inputTag += " style='" + style + "'";
				}

				if(!isAuth){
					inputTag += " style='visibility: hidden;'";
				}

				if(disabled) {
					inputTag += " disabled";
				}

				inputTag += ">";

				sb.append(inputTag);

				if(getCodes != null && !getCodes.equals("")) { // 공통 코드 불러오는 경우

					Map<String,String> map = new HashMap<>();

					try {
						map = commonCodeService.getSubCodes(getCodes);
					} catch (Exception e) {
						log.error(e.getMessage());
						HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
					}

					for(Entry<String, String> key : map.entrySet()) {

						if(!key.getValue().equals(map.get(map.keySet().toArray()[0]))) {

							sb.append(" <option value='"+ key.getKey() +"'");

							   if(key.getValue().equals(map.get(map.keySet().toArray()[0]))) {
								   selected = " selected";
							   }
							   else {
								   selected = "";
							   }

							  sb.append( selected + ">")
							    .append(key.getValue()+"</option>");

							index++;
						}
					}
				}

				else { // 일반 셀렉트 박스

					while(codeListToken.hasMoreTokens()) {
							token = codeListToken.nextToken();
							code = token.split(CommonConstants.COLONE);

							if(value == null && index == 0 || code[0].equals(value)) {
								selected = "selected= selected";
							}else {
								selected = "";
							}

							sb.append(" <option value='"+code[0]+"'")
							  .append(selected+">")
							  .append(code[1]+"</option>");

							index++;

					}
				}

				sb.append("</select>");


				JspWriter out = getJspContext().getOut();
				out.print(sb.toString());
				super.doTag();
			}

		}

	}

}
