package com.sorincorp.bo.comm.tags;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.sorincorp.bo.co.model.MenuAuthVO;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.RedisUtil;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
@Data
public class comChkBox extends SimpleTagSupport{
	private String id; // 엘리먼트 id
	private String name; // 엘리먼트 name
	private String value; // 엘리먼트 value
	private boolean checkYn = false; // 초기 체크 여부
	private boolean disabled = false; // 체크박스 비활성화 true/false
	private String text; // 체크박스 텍스트
	private String chkClass; // 체크박스의 class
	private String desc; // validation desc
	private String uri;  // 팝업 페이지일 시 권한 처리를 위한 부모 페이지 uri
	private String style;  // inline style

	RedisUtil redisUtil;

	@Autowired(required = true)
	private HttpServletRequest request;

	@Override
	public void doTag() throws JspException, IOException {

		PageContext pageContext = (PageContext)this.getJspContext();

		request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();

		WebApplicationContext context = WebApplicationContextUtils.getRequiredWebApplicationContext(pageContext.getServletContext());

		redisUtil = context.getBean(RedisUtil.class);

		boolean input = false;	// 입력 권한 여부
		boolean update = false;	// 수정 권한 여부
		boolean isAuth = false; // 권한 여부

		Account account = (Account) request.getSession().getAttribute("USER");
		List<MenuAuthVO> menuAhthList = new ArrayList<MenuAuthVO>();

		if(account != null) {

			menuAhthList = (List<MenuAuthVO>) redisUtil.getData("bomenukey:bo:"+request.getAttribute("javax.servlet.forward.request_uri"));

			if(menuAhthList == null && !"".equals(uri)) {
				menuAhthList= (List<MenuAuthVO>) redisUtil.getData("bomenukey:bo:"+ uri);
			}

			List<String> userAuthList = Arrays.asList(account.getAuthorNo().split(","));

			if(null == menuAhthList || null == userAuthList) {
				isAuth = false;
			}
			else if(menuAhthList.size() == 0 || userAuthList.size() == 0) {
				isAuth = false;
			}
			else{

					for(MenuAuthVO authNo : menuAhthList) {

						if (userAuthList.indexOf(String.valueOf(authNo.getAuthorNo())) != -1){
							if (authNo.isInputAuthorAtBool()) {	// 입력 권한 여부
								isAuth = true;
								input= true;
							}

							if (authNo.isUpdtAuthorAtBool()) {	// 수정 권한 여부
								isAuth = true;
								update = true;
							}

							break;
						}


					}
			}

			if(!input || !update) {
				isAuth = false;
			}

			if(isAuth) {
					StringBuilder sb = new StringBuilder("");


					sb.append("<input type='checkbox'")
			      	  .append(" name='" + name + "'")
			      	  .append(" id='" + id + "'")
			      	  .append(" value='" + value + "'");

					if(checkYn) {
				      sb.append("checked = 'checked'");
				    }

				    if(chkClass != null && !chkClass.equals("")) {
				    	sb.append(" class='" +  chkClass + "'");
				    }

					if(desc != null && !desc.equals("") ) {
						sb.append(" desc='" + desc + "'");
					}

					if(disabled) {
						sb.append(" disabled");
					}

//					if(!isAuth){
//						sb.append(" style='visibility: hidden;'");
//					}

				    if(style != null && !style.equals("")) {
				    	sb.append(" style='" +  style + "'");
				    }

				  sb.append("/>")
			      	.append("<label for='" + id + "'>")
			      	.append("<span>"+ text +"<span>")
			      	.append("</label>");


				  JspWriter out = getJspContext().getOut();
				  out.print(sb.toString());
				  super.doTag();

			}
		}

	}

}
