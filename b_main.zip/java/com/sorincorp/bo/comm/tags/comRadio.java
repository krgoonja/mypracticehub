package com.sorincorp.bo.comm.tags;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.sorincorp.bo.co.model.MenuAuthVO;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.RedisUtil;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
@Data
public class comRadio extends SimpleTagSupport{

	private String codeStr; // 코드 데이터 문자열 예) ':전체;Y:동의;N:거부’ input 태그 value : label span 태그 텍스트 형태로 제공
	private String name; // 엘리먼트 name
	private String idPrefix; // 엘리먼트 id 접두어
	private String compareValue; // 초기 체크 여부 결정을 위한 값
	private String radioClass; // 라디오 버튼의 class
	private boolean disabled = false; // 라디오 버튼 비활성화 true/false
	private String desc; // validation desc
	private String uri;  // 팝업 페이지일 시 권한 처리를 위한 부모 페이지 uri
	private String style;  // inline style

	RedisUtil redisUtil;

	@Autowired(required = true)
	private HttpServletRequest request;

	@Override
	public void doTag() throws JspException, IOException {

		PageContext pageContext = (PageContext)this.getJspContext();

		request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();

		WebApplicationContext context = WebApplicationContextUtils.getRequiredWebApplicationContext(pageContext.getServletContext());

		redisUtil = context.getBean(RedisUtil.class);

		Account account = (Account) request.getSession().getAttribute("USER");

		boolean input = false;  // 조회 권한 여부
		boolean update = false; // 수정 권한 여부
		boolean isAuth = false; // 권한 여부


		List<MenuAuthVO> menuAhthList = new ArrayList<MenuAuthVO>();

		if(account != null) {

			menuAhthList = (List<MenuAuthVO>) redisUtil.getData("bomenukey:bo:"+request.getAttribute("javax.servlet.forward.request_uri"));

			if(menuAhthList == null && !"".equals(uri)) {
				menuAhthList= (List<MenuAuthVO>) redisUtil.getData("bomenukey:bo:"+ uri);
			}

			List<String> userAuthList = Arrays.asList(account.getAuthorNo().split(","));

			if(null == menuAhthList || null == userAuthList) {
				isAuth = false;
			}
			else if(menuAhthList.size() == 0 || userAuthList.size() == 0) {
				isAuth = false;
			}
			else {
					for(MenuAuthVO authNo : menuAhthList) {

						if (userAuthList.indexOf(String.valueOf(authNo.getAuthorNo())) != -1){
							if (authNo.isInputAuthorAtBool()) {
								input= true;
								isAuth = true;
							}

							if (authNo.isUpdtAuthorAtBool()) {
								update = true;
								isAuth = true;
							}

							break;
						}

					}
			}

			if(!input || !update) {
				isAuth =false;
			}

			if (!isAuth) {
				disabled = true;
			}

			if (isAuth) {
			StringBuilder sb  = new StringBuilder("");
		    StringTokenizer codeListToken = new StringTokenizer(codeStr, CommonConstants.SEMI_COLONE);
		    String token;
		    String code[];
			String id;
			int index = 1;

			    while(codeListToken.hasMoreTokens()) {
			        token = codeListToken.nextToken();
			        code = token.split(CommonConstants.COLONE);
			        id = idPrefix + "-" + index++;

					sb.append("<div class='form-radio'>")
			          .append("<input type=\"radio\"")
				      .append(" name=\"" + name + "\"")
				      .append(" id=\"" + id + "\"")
				      .append(" value=\"" + code[0] + "\"");

			        if(code[0].equals(compareValue)) {
			            sb.append(" checked");
			        }

			        if(radioClass != null && !radioClass.equals("")) {
			        	 sb.append(" class='"+ radioClass+"'");
			        }

					if(desc != null && !desc.equals("") ) {
						sb.append(" desc='" + desc + "'");
					}

			        if(disabled) {
						sb.append(" disabled");
					}

			        if(style != null && !style.equals("")) {
				    	sb.append(" style='" +  style + "'");
				    }

			        sb.append(" />")
			          .append("<label for='"+ id+"'>")
			          .append("<span>"+code[1]+"</span>")
			          .append("</label>")
			          .append("</div>");

			        index++;
			    }

			    JspWriter out = getJspContext().getOut();
				out.print(sb.toString());
				super.doTag();
			}
		}
	}

}