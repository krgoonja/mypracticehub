package com.sorincorp.bo.comm.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class I18nMessageController {
	
	@RequestMapping("/properties/{propertiesName}")
    public void getProperties(@PathVariable String propertiesName, HttpServletResponse response) throws IOException {
           OutputStream outputStream = response.getOutputStream();
           
           Resource resource = new ClassPathResource("/message/message-comm_"+LocaleContextHolder.getLocale().getLanguage()+".properties");
           InputStream inputStream = resource.getInputStream();
           List<String> readLines = IOUtils.readLines(inputStream,"UTF-8");
           IOUtils.writeLines(readLines, null, outputStream,"UTF-8");
           inputStream.close();
           outputStream.close();
    }
}
