package com.sorincorp.bo.comm.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpStatus;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BoErrorController implements ErrorController {

	@RequestMapping("/error") 
	public String handleError(HttpServletRequest request, HttpServletResponse response) {
		Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
		if (null!=status) {
			int statusCode = Integer.valueOf(status.toString());
			switch(statusCode) {
				case HttpStatus.SC_NOT_FOUND:
					return "error/404";
			}
		}
		return "error/503";
	}
	
	
	@Override
	public String getErrorPath() {
		return null;
	}
}
