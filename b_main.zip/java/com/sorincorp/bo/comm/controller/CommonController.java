package com.sorincorp.bo.comm.controller;

import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.util.JsonUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class CommonController {
	
	@Autowired
	CommonCodeService commonCodeService;
	
	@Autowired
	FileDocService fileDocService;
	
	/**
	 * <pre>
	 * 처리내용: 공통코드 메인코드를 조회한다
	 * </pre>
	 * @date 2021. 8. 5.
	 * @author srec0041
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 5.			srec0041			최초작성
	 * ------------------------------------------------
	 * @return 공통코드 map
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/Common/getMainCodes")
	public Map<String, String> getMainCodes() throws Exception {
		return commonCodeService.getMainCodes();
	}
	
	/**
	 * <pre>
	 * 처리내용: 공통코드 서브코드를 조회한다.
	 * </pre>
	 * @date 2021. 8. 5.
	 * @author srec0041
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 5.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @return 공통코드 서브 map
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/Common/getSubCodes")
	public Map<String, String> getSubCodes(String mainCode) throws Exception {
		return commonCodeService.getSubCodes(mainCode);
	}
	
	/**
	 * <pre>
	 * 처리내용: 공통코드 값을 조회한다.
	 * </pre>
	 * @date 2021. 8. 5.
	 * @author srec0041
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 5.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @param 공통코드 서브 map
	 * @return 공통코드 값
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/Common/getCodeValue")
	public String getCodeValue(String mainCode, String subCode) throws Exception {
		return commonCodeService.getCodeValue(mainCode, subCode);
	}
	
	/**
	 * <pre>
	 * 처리내용: 로그인한 유저의 정보를 조회한다.
	 * </pre>
	 * @date 2021. 8. 19.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 19.			srec0019			최초작성
	 * ------------------------------------------------
	 */
	@ResponseBody
	@RequestMapping("/Common/getUserInfo")
	public Account getUserInfo(HttpServletRequest request) {
		return (Account) Optional.ofNullable(request.getSession().getAttribute("USER"))
								 .orElse(null);		
	}
	
	/**
	 * <pre>
	 * 입력한 Parameter로 Oz Report를 설정하고 결과를 리턴한다.
	 * </pre>
	 * @date 2021. 6. 3.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 3.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param param : Oz Report 설정 Parameter
	 * @return : Oz Report 설정 결과 Map
	 * @throws Exception
	 */
	@RequestMapping("/Common/ozReport")
	public String ozReportView(@RequestParam Map<String, Object> param, ModelMap modelMap) throws Exception {
		log.debug("start ozReport Setting");
		
		try {
			String ozAlias = "SLS_REAL";
			
			String FileName = "";
			if ( param.get("FileName") != null ) {
				FileName= param.get("FileName").toString();
			} else {
				FileName = "noname";
			}
			
			String childFlag = "";
			if ( param.get("childFlag") != null ) {
				childFlag= param.get("childFlag").toString();
			} else {
				childFlag = "N";
			}
			
			if ( !childFlag.equalsIgnoreCase("Y") ) {
				modelMap.addAttribute("OrderNo",            param.get("OrderNo"));
				modelMap.addAttribute("OrderTp",            param.get("OrderTp"));
				modelMap.addAttribute("OrderSeq",           param.get("OrderSeq"));
				modelMap.addAttribute("LineId",             param.get("LineId"));
				modelMap.addAttribute("ShipNo",             param.get("ShipNo"));
				modelMap.addAttribute("Seq1",               param.get("Seq1"));
				modelMap.addAttribute("Seq2",               param.get("Seq2"));
				modelMap.addAttribute("DOCU1",              param.get("DOCU1"));
				modelMap.addAttribute("ITEM",               param.get("ITEM"));
				modelMap.addAttribute("DATE",               param.get("DATE"));
				modelMap.addAttribute("PA1",                param.get("PA1"));
				modelMap.addAttribute("OzFileNm",           param.get("OzFileNm"));
				modelMap.addAttribute("imgFlag",            param.get("imgFlag"));
				modelMap.addAttribute("pa1",                param.get("pa1")); // OZ550401(선급금) 출력으로 추가 2020-01-04 PWY
				modelMap.addAttribute("pa2",                param.get("pa2")); // OZ550403_1(AR) 출력으로 추가 2020-01-07
				modelMap.addAttribute("__UserId",           param.get("__UserId")); // OZ550401(선급금) 출력으로 추가 2020-01-04 PWY
				modelMap.addAttribute("OzAlias",            ozAlias);
				modelMap.addAttribute("FileName",           FileName);
			} else {
				String arrChildNm[] = param.get("arrChildNm").toString().split(",");
				
				JSONObject mainJson = new JSONObject(param.get("mainParam").toString());
				Map<String, Object> mainParam = JsonUtil.getMapFromJsonObject(mainJson);
				
				modelMap.addAttribute("childFlag",          "Y");
				modelMap.addAttribute("childCount",         param.get("childCount"));
				
				if ( mainParam.get("OrderNo") != null && !"".equals(mainParam.get("OrderNo")) ) {
					modelMap.addAttribute("OrderNo",             mainParam.get("OrderNo"));
				} else {
					modelMap.addAttribute("OrderNo",             param.get("OrderNo"));
				}
				
				if ( mainParam.get("OrderTp") != null && !"".equals(mainParam.get("OrderTp")) ) {
					modelMap.addAttribute("OrderTp",             mainParam.get("OrderTp"));
				} else {
					modelMap.addAttribute("OrderTp",             param.get("OrderTp"));
				}
				
				if ( mainParam.get("OrderSeq") != null && !"".equals(mainParam.get("OrderSeq")) ) {
					modelMap.addAttribute("OrderSeq",           mainParam.get("OrderSeq"));
				} else {
					modelMap.addAttribute("OrderSeq",           param.get("OrderSeq"));
				}
				
				if ( mainParam.get("LineId") != null && !"".equals(mainParam.get("LineId")) ) {
					modelMap.addAttribute("LineId",              mainParam.get("LineId"));
				} else {
					modelMap.addAttribute("LineId",              param.get("LineId"));
				}

				if ( mainParam.get("ShipNo") != null && !"".equals(mainParam.get("ShipNo")) ) {
					modelMap.addAttribute("ShipNo",              mainParam.get("ShipNo"));
				} else {
					modelMap.addAttribute("ShipNo",              param.get("ShipNo"));
				}
				
				if ( mainParam.get("Seq1") != null && !"".equals(mainParam.get("Seq1")) ) {
					modelMap.addAttribute("Seq1",                   mainParam.get("Seq1"));
				} else {
					modelMap.addAttribute("Seq1",                   param.get("Seq1"));
				}
				
				if ( mainParam.get("Seq2") != null && !"".equals(mainParam.get("Seq2")) ) {
					modelMap.addAttribute("Seq2",                   mainParam.get("Seq2"));
				} else {
					modelMap.addAttribute("Seq2",                   param.get("Seq2"));
				}
				
				if ( mainParam.get("DOCU1") != null && !"".equals(mainParam.get("DOCU1")) ) {
					modelMap.addAttribute("DOCU1",                  mainParam.get("DOCU1"));
				} else {
					modelMap.addAttribute("DOCU1",                  param.get("DOCU1"));
				}
				
				if ( mainParam.get("ITEM") != null && !"".equals(mainParam.get("ITEM")) ) {
					modelMap.addAttribute("ITEM",                   mainParam.get("ITEM"));
				} else {
					modelMap.addAttribute("ITEM",                   param.get("ITEM"));
				}
				
				if ( mainParam.get("DATE") != null && !"".equals(mainParam.get("DATE")) ) {
					modelMap.addAttribute("DATE",                   mainParam.get("DATE"));
				} else {
					modelMap.addAttribute("DATE",                   param.get("DATE"));
				}
				
				if ( mainParam.get("PA1") != null && !"".equals(mainParam.get("PA1")) ) {
					modelMap.addAttribute("PA1",             mainParam.get("PA1"));
				} else {
					modelMap.addAttribute("PA1",             param.get("PA1"));
				}
				
				if ( mainParam.get("imgFlag") != null && !"".equals(mainParam.get("imgFlag")) ) {
					modelMap.addAttribute("imgFlag",             mainParam.get("imgFlag"));
				} else {
					modelMap.addAttribute("imgFlag",             param.get("imgFlag"));
				}
				
				if ( mainParam.get("DOCU1") != null && !"".equals(mainParam.get("DOCU1")) ) {
					modelMap.addAttribute("DOCU1",                  mainParam.get("DOCU1"));
				} else {
					modelMap.addAttribute("DOCU1",                  param.get("DOCU1"));
				}
				
				modelMap.addAttribute("OzFileNm",           arrChildNm[0]);
				modelMap.addAttribute("arrChildNm",         param.get("arrChildNm"));
				modelMap.addAttribute("OzAlias",            ozAlias);
				modelMap.addAttribute("FileName",           FileName);
				
				int childCount = Integer.parseInt(param.get("childCount").toString());
				JSONArray jArray = new JSONArray();
				
				if ( childCount > 0 ) {
					jArray = new JSONArray(param.get("childParam").toString());
				}
				
				int childIndex = 0;
				for ( int i = 0; i < jArray.length(); i++ ) {
					childIndex = childIndex + 1;
					JSONObject childJson = new JSONObject(jArray.get(i).toString());
					Map<String, Object> childParam = JsonUtil.getMapFromJsonObject(childJson);
					
					if ( childParam.get("OrderNo") != null && !"".equals(childParam.get("OrderNo")) ) {
						modelMap.addAttribute("child" + childIndex + "OrderNo",            childParam.get("OrderNo"));
					} else {
						modelMap.addAttribute("child" + childIndex + "OrderNo",            param.get("OrderNo"));
					}
					
					if ( childParam.get("OrderTp") != null && !"".equals(childParam.get("OrderTp")) ) {
						modelMap.addAttribute("child" + childIndex + "OrderTp",            childParam.get("OrderTp"));
					} else {
						modelMap.addAttribute("child" + childIndex + "OrderTp",            param.get("OrderTp"));
					}
					
					if ( childParam.get("OrderSeq") != null && !"".equals(childParam.get("OrderSeq")) ) {
						modelMap.addAttribute("child" + childIndex + "OrderSeq",           childParam.get("OrderSeq"));
					} else {
						modelMap.addAttribute("child" + childIndex + "OrderSeq",           param.get("OrderSeq"));
					}
					
					if ( childParam.get("OrderSeq") != null && !"".equals(childParam.get("OrderSeq")) ) {
						modelMap.addAttribute("child" + childIndex + "LineId",             childParam.get("LineId"));
					} else {
						modelMap.addAttribute("child" + childIndex + "LineId",             param.get("LineId"));
					}
					
					if ( childParam.get("ShipNo") != null && !"".equals(childParam.get("ShipNo")) ) {
						modelMap.addAttribute("child" + childIndex + "ShipNo",             childParam.get("ShipNo"));
					} else {
						modelMap.addAttribute("child" + childIndex + "ShipNo",             param.get("ShipNo"));
					}
					
					if ( childParam.get("Seq1") != null && !"".equals(childParam.get("Seq1")) ) {
						modelMap.addAttribute("child" + childIndex + "Seq1",                    childParam.get("Seq1"));
					} else {
						modelMap.addAttribute("child" + childIndex + "Seq1",                    param.get("Seq1"));
					}
					
					if ( childParam.get("Seq2") != null && !"".equals(childParam.get("Seq2")) ) {
						modelMap.addAttribute("child" + childIndex + "Seq2",                    childParam.get("Seq2"));
					} else {
						modelMap.addAttribute("child" + childIndex + "Seq2",                    param.get("Seq2"));
					}
					
					if ( childParam.get("DOCU1") != null && !"".equals(childParam.get("DOCU1")) ) {
						modelMap.addAttribute("child" + childIndex + "DOCU1",                   childParam.get("DOCU1"));
					} else {
						modelMap.addAttribute("child" + childIndex + "DOCU1",                   param.get("DOCU1"));
					}
					
					if ( childParam.get("ITEM") != null && !"".equals(childParam.get("ITEM")) ) {
						modelMap.addAttribute("child" + childIndex + "ITEM",                    childParam.get("ITEM"));
					} else {
						modelMap.addAttribute("child" + childIndex + "ITEM",                    param.get("ITEM"));
					}
					
					if ( childParam.get("DATE") != null && !"".equals(childParam.get("DATE")) ) {
						modelMap.addAttribute("child" + childIndex + "DATE",                    childParam.get("DATE"));
					} else {
						modelMap.addAttribute("child" + childIndex + "DATE",                    param.get("DATE"));
					}
					
					if ( childParam.get("PA1") != null && !"".equals(childParam.get("PA1")) ) {
						modelMap.addAttribute("child" + childIndex + "PA1",                    childParam.get("PA1"));
					}else {
						modelMap.addAttribute("child" + childIndex + "PA1",                    param.get("PA1"));
					}
					
					if ( childParam.get("imgFlag") != null && !"".equals(childParam.get("imgFlag")) ) {
						modelMap.addAttribute("child" + childIndex + "imgFlag",            childParam.get("imgFlag"));
					} else {
						modelMap.addAttribute("child" + childIndex + "imgFlag",            param.get("imgFlag"));
					}
					
					if ( childParam.get("DOCU1") != null && !"".equals(childParam.get("DOCU1")) ) {
						modelMap.addAttribute("child" + childIndex + "DOCU1",                   childParam.get("DOCU1"));
					} else {
						modelMap.addAttribute("child" + childIndex + "DOCU1",                   param.get("DOCU1"));
					}
				}
			}
		} catch (Exception e) {
			log.error(e.toString()+ ":::" + param);
		}

        log.debug("end ozReport Setting");
		
		return "common/ozreport/ozReport";
	}
	
	/**
	 * 
	 * <pre>
	 * 처리내용: BlobStorage에 있는 파이를 다운로드 한다.
	 * </pre>
	 * @date 2021. 9. 3.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 3.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param request
	 * @param response
	 * @throws Exception 
	 */
	@RequestMapping("/Common/commonDownLoad")
	public void commonDownLoad(FileDocVO vo, HttpServletRequest request, HttpServletResponse response) throws Exception {
		fileDocService.fileDocDownload(request, response, vo);
//		System.out.println(vo.toString());
//		System.out.println(vo.getDocFileRealCours());
	}
}
