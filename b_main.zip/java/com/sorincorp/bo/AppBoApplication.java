package com.sorincorp.bo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppBoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppBoApplication.class, args);
	}

}
