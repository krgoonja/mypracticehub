package com.sorincorp.bo.login.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class LoginVO implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -5698846760103762738L;

	/** 아이디 */
	private String id = "";
	
	/** 비밀번호 */
	private String password = "";
	
	private boolean idSave;

}
