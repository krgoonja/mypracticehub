package com.sorincorp.bo.login.mapper;

import com.sorincorp.bo.login.model.Account;

public interface AccountMapper {
	/**
	 * <pre>
	 * User ID로 사용자의 정보를 가져온다.
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 21.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param id
	 * @return
	 * @throws Exception
	 */
	Account selectAccount(String id) throws Exception;
}
