package com.sorincorp.bo.login.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONException;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sorincorp.bo.config.LoginTokenProvider;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.bo.login.model.LoginVO;
import com.sorincorp.bo.login.service.AccountServiceImpl;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.MessageUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Controller
@RequestMapping(value = "/login")
public class LoginController {
	private final PasswordEncoder passwordEncoder;
	private final LoginTokenProvider jwtTokenProvider;
	private final AccountServiceImpl accountService;
	private final MessageUtil messageUtil;
	
	@Autowired
	private final DateUtil dateUtil;
	
	@Autowired
	Environment env;

	
	@RequestMapping(value = "/loginView")
	public String login() {
//		return "sample/sampleLogin";
		return "ma/login";
	}
	
	@RequestMapping(value = "/sessionExpired")
	public String sessionExpired(HttpServletRequest request, HttpServletResponse response, ModelMap model) {

		log.debug(response.getHeader("url"));
		model.addAttribute("url", response.getHeader("url"));
		return "error/sessionExpired";
	}
	
	// 로그인
	@PostMapping("/getToken")
	//public void login(@RequestParam("id") String id, @RequestParam("password") String password, HttpServletRequest request,HttpServletResponse response) throws JSONException, IOException {
	public ResponseEntity<?> login(LoginVO vo, HttpServletRequest request,HttpServletResponse response) throws JSONException, IOException, ParseException {
		

		Account account = (Account)accountService.loadUserByUsername(vo.getId());
		if ( account == null ) {
			return new ResponseEntity<>(messageUtil.getMessage("co.login.invalid.user"), HttpStatus.BAD_REQUEST);
		//	throw new IllegalArgumentException(messageUtil.getMessage("co.login.invalid.user"));
		}

		String[] nowProfiles = env.getActiveProfiles();
		String nowProfile = nowProfiles[0];

		// BO LOGIN AT 확인
		if(StringUtils.equals("N", Optional.ofNullable(account.getBoLoginAt()).orElse("N"))) {
			return new ResponseEntity<>("로그인 권한이 없는 계정입니다.", HttpStatus.BAD_REQUEST);
		}

		// 로컬과 개발은 BO부분 패스 워드 체크 부분 제외요청(2021-09-23) AD로 비번 변경시 계속 변동되어
		if (!("local".equals(nowProfile) || "dev".equals(nowProfile))) {
			if ( !passwordEncoder.matches(CryptoUtil.encryptSHA256(vo.getPassword()), "{noop}" + account.getPassword()) ) {
				//throw new IllegalArgumentException(messageUtil.getMessage("co.login.invalid.password"));
				return new ResponseEntity<>(messageUtil.getMessage("co.login.invalid.user"), HttpStatus.BAD_REQUEST);
			}
		}
		
//		if ( !passwordEncoder.matches(vo.getPassword(), "{noop}" + account.getPassword()) ) {
//			throw new IllegalArgumentException(messageUtil.getMessage("co.login.invalid.password"));
//		}
	
		account.setPassword(null);
//		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); //원하는 데이터 포맷 지정
		
		account.setRecentLoginDt(dateUtil.calDate("yyyy-MM-dd kk:mm:ss"));
		
		/* ROLE을 사용하는 경우
		String loginToken = jwtTokenProvider.createToken(account.getId(), account.getRoles());
		*/
		String loginToken = jwtTokenProvider.createToken(account.getId());
		
//		Cookie loginCookie = new Cookie("loginToken", loginToken);
//		loginCookie.setPath("/");
//		response.addCookie(loginCookie);
		ResponseCookie loginCookie = jwtTokenProvider.createSecureCookie(CommonConstants.BO_ACCESS_TOKEN_NAME,  loginToken, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);
		
		if (vo.isIdSave()) {
			Cookie saveIdCookie = new Cookie("saveId", account.getId());
			saveIdCookie.setPath("/");
			saveIdCookie.setMaxAge(60*60*24*1000);
			saveIdCookie.setSecure(true);
			saveIdCookie.setHttpOnly(false);
			response.addCookie(saveIdCookie);
		}
		else {
			Cookie saveIdCookie = new Cookie("saveId", null);
			saveIdCookie.setPath("/");
			saveIdCookie.setMaxAge(0);
			saveIdCookie.setSecure(true);
			saveIdCookie.setHttpOnly(false);
			response.addCookie(saveIdCookie);
		}
		//BO는 Scaling 등이 없으므로 세션사용, 세션시간을 토큰 라이브 시간과 같이 설정
		HttpSession httpSession = request.getSession();
		httpSession.setMaxInactiveInterval((int) CommonConstants.SESSION_VALIDATION_SECOND);
		
		//log.debug("httpSession : " + httpSession.getMaxInactiveInterval() + " : " + httpSession.getId());
		// "USER"로 Account를 세션에 바인딩한다.
        httpSession.setAttribute("USER", account);
		response.addHeader(HttpHeaders.SET_COOKIE, loginCookie.toString());
		
		//log.debug("httpSession2 : " + httpSession.getMaxInactiveInterval() + " : " + httpSession.getId());
		
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("result", "inActive");
		map.put("account", account);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
}
