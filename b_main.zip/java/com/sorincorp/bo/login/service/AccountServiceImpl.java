package com.sorincorp.bo.login.service;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.login.mapper.AccountMapper;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.util.CryptoUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Service
public class AccountServiceImpl implements UserDetailsService {
	@Autowired
	AccountMapper accountMapper;

	@Override
	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
		Account account = null;

		try {
			account = accountMapper.selectAccount(userId);

			if (StringUtils.isNotBlank(account.getMobileNo())) {
				account.setMobileNo(CryptoUtil.decryptAES256(account.getMobileNo()));	//복호화
			}

			/* ROLE을 사용하는 경우
			String[] accountRoles = account.getRole().split(",");
			List<String> roles = new ArrayList<String>();
			for ( String role : accountRoles ) {
				roles.add(role);
			}
			account.setRoles(roles);
			*/
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		}

		return account;
	}
}
