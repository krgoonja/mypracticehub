package com.sorincorp.bo.login.service;

import com.sorincorp.bo.login.model.Account;

/**
 * 로그인 Token 값에 맞는 Authentication 정보를 조회하는 Service 
 * LoginInfoService.java
 * @version
 * @since 2021. 6. 24.
 * @author srec0012
 */
public interface LoginInfoService {
	/**
	 * <pre>
	 * Login Token으로 인증된 Authentication 정보 전체를 AccountVO에 담아서 반환한다.
	 * </pre>
	 * @date 2021. 6. 24.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 24.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return : Authentication 정보
	 * @throws Exception
	 */
	public Account getAccount() throws Exception;
	
	/**
	 * <pre>
	 * Login Token으로 인증된 Authentication 정보 중에서 직원 이름을 반환한다.
	 * </pre>
	 * @date 2021. 6. 24.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 24.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public String getUserName() throws Exception;
	
	/**
	 * <pre>
	 * Login Token으로 인증된 Authentication 정보 중에서 직원 직위명을 반환한다.
	 * </pre>
	 * @date 2021. 6. 28.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public String getOpsps() throws Exception;
	
	/**
	 * <pre>
	 * Login Token으로 인증된 Authentication 정보 중에서 직원 부서명을 반환한다.
	 * </pre>
	 * @date 2021. 6. 28.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public String getDeptNm() throws Exception;
	
	/**
	 * <pre>
	 * Login Token으로 인증된 Authentication 정보 중에서 직원의 휴대폰 번호를 반환한다.
	 * </pre>
	 * @date 2021. 6. 28.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public String getMobileNo() throws Exception;
	
	/**
	 * <pre>
	 * Login Token으로 인증된 Authentication 정보 중에서 직원의 회사 전화번호를 반환한다.
	 * </pre>
	 * @date 2021. 6. 28.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public String getTleNo() throws Exception;
	
	/**
	 * <pre>
	 * Login Token으로 인증된 Authentication 정보 중에서 직원 회사 E-mail을 반환한다.
	 * </pre>
	 * @date 2021. 6. 24.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 24.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public String getEmail() throws Exception;
}
