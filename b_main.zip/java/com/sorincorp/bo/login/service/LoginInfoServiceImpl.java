package com.sorincorp.bo.login.service;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.login.model.Account;

@Service
public class LoginInfoServiceImpl implements LoginInfoService {
	
	@Override
	public Account getAccount() throws Exception {
		Account account = new Account();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if ( auth != null ) account = (Account)auth.getPrincipal();

		return account;
	}

	@Override
	public String getUserName() throws Exception {
		Account account = new Account();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if ( auth != null ) account = (Account)auth.getPrincipal();

		return account.getName();
	}

	@Override
	public String getOpsps() throws Exception {
		Account account = new Account();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if ( auth != null ) account = (Account)auth.getPrincipal();

		return account.getOfcps();
	}

	@Override
	public String getDeptNm() throws Exception {
		Account account = new Account();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if ( auth != null ) account = (Account)auth.getPrincipal();

		return account.getDeptNm();
	}

	@Override
	public String getMobileNo() throws Exception {
		Account account = new Account();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if ( auth != null ) account = (Account)auth.getPrincipal();

		return account.getMobileNo();
	}

	@Override
	public String getTleNo() throws Exception {
		Account account = new Account();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if ( auth != null ) account = (Account)auth.getPrincipal();

		return account.getTelNo();
	}

	@Override
	public String getEmail() throws Exception {
		Account account = new Account();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if ( auth != null ) account = (Account)auth.getPrincipal();

		return account.getEmail();
	}
}
