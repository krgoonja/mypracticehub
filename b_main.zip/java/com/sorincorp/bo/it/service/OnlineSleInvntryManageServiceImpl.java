package com.sorincorp.bo.it.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.it.mapper.OnlineSleInvntryManageMapper;
import com.sorincorp.bo.it.model.OnlineSleInvntryManageVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OnlineSleInvntryManageServiceImpl implements OnlineSleInvntryManageService {

	@Autowired
	private OnlineSleInvntryManageMapper onlineSleInvntryManageMapper;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 8. 4.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 4.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param onlineSleInvntryManageVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<OnlineSleInvntryManageVO> selectLogisticsCenterList(OnlineSleInvntryManageVO onlineSleInvntryManageVO)
			throws Exception {
		// TODO Auto-generated method stub

		Map<String, Object> param = new HashMap<String, Object>();

		param.put("metalCode", onlineSleInvntryManageVO.getMetalCode());
		param.put("itmSn", onlineSleInvntryManageVO.getItmSn());
		param.put("ftrsProcessAt", onlineSleInvntryManageVO.getFtrsProcessAt());
		param.put("brandGroupCode", onlineSleInvntryManageVO.getBrandGroupCode());
		param.put("brandCode", onlineSleInvntryManageVO.getBrandCode());
		param.put("dstrctLclsfCode", onlineSleInvntryManageVO.getDstrctLclsfCode());
		param.put("blNo", onlineSleInvntryManageVO.getBlNo());

//		List<String> dstrctMlsfcCodeList = new ArrayList<String>();
//
//		for(int i=0;i<onlineSleInvntryManageVO.getDstrctMlsfcCodeArray().length;i++) {
//			dstrctMlsfcCodeList.add(onlineSleInvntryManageVO.getDstrctMlsfcCodeArray()[i]);
//		}
//
//		param.put("dstrctMlsfcCodeList", dstrctMlsfcCodeList);

		return onlineSleInvntryManageMapper.selectLogisticsCenterList(param);
	}

	@Override
	public List<OnlineSleInvntryManageVO> selectBlInfoBasList(OnlineSleInvntryManageVO onlineSleInvntryManageVO)
			throws Exception {
		// TODO Auto-generated method stub
		Map<String, Object> param = new HashMap<String, Object>();
		String gubun = onlineSleInvntryManageVO.getGubun();
		List<OnlineSleInvntryManageVO> blInfoBasList = new ArrayList<>();
		List<OnlineSleInvntryManageVO> blInfoBasTempList = new ArrayList<>();

		try {
			if("all".equals(gubun)) {

				param.put("metalCode", onlineSleInvntryManageVO.getMetalCode());
				param.put("itmSn", onlineSleInvntryManageVO.getItmSn());
				param.put("ftrsProcessAt", onlineSleInvntryManageVO.getFtrsProcessAt());
				param.put("brandGroupCode", onlineSleInvntryManageVO.getBrandGroupCode());
				param.put("brandCode", onlineSleInvntryManageVO.getBrandCode());
				param.put("blNo", onlineSleInvntryManageVO.getBlNo());
				//param.put("dstrctLclsfCode", onlineSleInvntryManageVO.getDstrctLclsfCode());

				List<String> wrhousCodeList = new ArrayList<String>();
				String[] wrhousCodeArray = onlineSleInvntryManageVO.getWrhousCodeArray();

				if(wrhousCodeArray.length > 0) {
					for(int i=0;i<wrhousCodeArray.length;i++) {
						wrhousCodeList.add(wrhousCodeArray[i]);
					}
				}

				param.put("wrhousCodeList", wrhousCodeList);

				List<String> dstrctLclsfCodeList = new ArrayList<String>();
				String[] dstrctLclsfCodeArray = onlineSleInvntryManageVO.getDstrctLclsfCodeArray();

				if(dstrctLclsfCodeArray.length > 0) {
					for(int i=0;i<dstrctLclsfCodeArray.length;i++) {
						dstrctLclsfCodeList.add(dstrctLclsfCodeArray[i]);
					}

					param.put("dstrctLclsfCodeList", dstrctLclsfCodeList);
				}
				//log.debug("param : " + param.toString());
				blInfoBasList = onlineSleInvntryManageMapper.selectBlInfoBasList(param);
				//log.debug("blInfoBasList.size() : " + blInfoBasList.size());
			} else {

				param.put("itmSn", onlineSleInvntryManageVO.getItmSn());
				param.put("ftrsProcessAt", onlineSleInvntryManageVO.getFtrsProcessAt());
				param.put("brandGroupCode", onlineSleInvntryManageVO.getBrandGroupCode());
				param.put("brandCode", onlineSleInvntryManageVO.getBrandCode());
				param.put("blNo", onlineSleInvntryManageVO.getBlNo());
				//param.put("dstrctLclsfCode", onlineSleInvntryManageVO.getDstrctLclsfCode());

				List<String> wrhousCodeList = new ArrayList<String>();
				List<String> dstrctLclsfCodeList = new ArrayList<String>();
				String[] metalCodeArray = onlineSleInvntryManageVO.getMetalCodeArray();
				String[] wrhousCodeArray = onlineSleInvntryManageVO.getWrhousCodeArray();
				String[] dstrctLclsfCodeArray = onlineSleInvntryManageVO.getDstrctLclsfCodeArray();

				if(metalCodeArray.length > 0) {
					for(int i=0;i<metalCodeArray.length;i++) {

						param.put("metalCode", metalCodeArray[i]);

						//wrhousCodeList = new ArrayList<String>();
						wrhousCodeList.clear();
						wrhousCodeList.add(wrhousCodeArray[i]);
						param.put("wrhousCodeList", wrhousCodeList);
						//dstrctLclsfCodeList = new ArrayList<String>();
						dstrctLclsfCodeList.clear();
						dstrctLclsfCodeList.add(dstrctLclsfCodeArray[i]);
						param.put("dstrctLclsfCodeList", dstrctLclsfCodeList);

						blInfoBasTempList = onlineSleInvntryManageMapper.selectBlInfoBasList(param);

						for(int j=0;j<blInfoBasTempList.size();j++) {
							blInfoBasList.add(blInfoBasTempList.get(j));
						}
					}
				} else {

					param.put("metalCode", "");
					wrhousCodeList.add(null);
					param.put("wrhousCodeList", wrhousCodeList);

					blInfoBasList = onlineSleInvntryManageMapper.selectBlInfoBasList(param);
//					blInfoBasTempList = onlineSleInvntryManageMapper.selectBlInfoBasList(param);
//					//blInfoBasList.add(blInfoBasTempList);
//					for(int j=0;j<blInfoBasTempList.size();j++) {
//						blInfoBasList.add(blInfoBasTempList.get(j));
//					}
				}

			}
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
		}

		return blInfoBasList;
	}

}
