package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.LqdIntDatResVO;

public interface FtrsApiMgrService {

	/**
	 * <pre>
	 * 목록 카운트 조회
	 * </pre>
	 * @date 2022. 1. 25.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 25.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param lqdIntDatResVO
	 * @return
	 */
	int getDataCount(LqdIntDatResVO lqdIntDatResVO) throws Exception;

	/**
	 * <pre>
	 * 목록 조회
	 * </pre>
	 * @date 2022. 1. 25.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 25.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param lqdIntDatResVO
	 * @return
	 */
	List<LqdIntDatResVO> getDataList(LqdIntDatResVO lqdIntDatResVO) throws Exception;

}
