package com.sorincorp.bo.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.it.mapper.FtrsApiMgrMapper;
import com.sorincorp.bo.it.model.LqdIntDatResVO;

@Service
public class FtrsApiMgrServiceImpl implements FtrsApiMgrService {

	@Autowired
	private FtrsApiMgrMapper ftrsApiMgrMapper;

	@Override
	public int getDataCount(LqdIntDatResVO lqdIntDatResVO) throws Exception {
		return ftrsApiMgrMapper.getDataCount(lqdIntDatResVO);
	}

	@Override
	public List<LqdIntDatResVO> getDataList(LqdIntDatResVO lqdIntDatResVO) throws Exception {
		return ftrsApiMgrMapper.getDataList(lqdIntDatResVO);
	}

}
