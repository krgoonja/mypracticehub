package com.sorincorp.bo.it.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.SidecarMapper;
import com.sorincorp.bo.it.model.SidecarVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SidecarImpl implements SidecarService{
	
	@Autowired
	private SidecarMapper sidecarMapper;

	@Autowired
	private UserInfoUtil usertInfoUtil;
	/**
	 * 사이드카 목록을 조회한다.
	 * @param SidecarVO - 조회할 정보가 담긴 VO
	 * @return 사이드카 리스트
	 * @exception Exception
	 */
	public List<SidecarVO> searchSidecarList(SidecarVO sidecarVO) throws Exception{
		sidecarMapper.selectUpdateMotnAtN(sidecarVO);
		return sidecarMapper.searchSidecarList(sidecarVO);
	}

	@Override
	public void insertAndUpdateSidecar(List<SidecarVO> sidecarVOList) {
		for(int i = 0; i < sidecarVOList.size(); i++) {
			sidecarVOList.get(i).setFrstRegisterId(Optional.ofNullable(usertInfoUtil.getUserId()).orElse(""));
			sidecarVOList.get(i).setLastChangerId(Optional.ofNullable(usertInfoUtil.getUserId()).orElse(""));
			String status = sidecarVOList.get(i).getGridRowStatus();
			if(status.equals("created")) {
				/* 
				 * 동일[날짜, 품목대분류코드] 등록 삭제 후 재등록 불가능(무결성) / 동일 키값의 데이터 존재 확인 -> 기존의 삭제 되었던 데이터 UPDATE
				 * 
				 * 1. 동일[날짜, 품목대분류코드] 존재 확인
				 * 2. 존재할때 -> update, 존재하지 않을떄-> insert
				 */
				SidecarVO sVo = new SidecarVO();
				sVo = sidecarMapper.searchOneSidecar(sidecarVOList.get(i));
				if(sVo != null && "Y".equals(sVo.getDeleteAt())) { //동일 key값으로 데이터가 있을때
					sidecarVOList.get(i).setDeleteAt("N");
					sidecarMapper.updateSidecar(sidecarVOList.get(i));
				}else if (sVo == null) {
					sidecarVOList.get(i).setDeleteAt("N");
					sidecarMapper.insertSidecar(sidecarVOList.get(i));
				}
				sidecarMapper.insertSidecarHst(sidecarVOList.get(i));
				sidecarMapper.updateMotnAt(sidecarVOList.get(i));
				
			} else if (status.equals("updated")) {
				sidecarVOList.get(i).setDeleteAt("N");
				sidecarMapper.updateSidecar(sidecarVOList.get(i));
				sidecarMapper.insertSidecarHst(sidecarVOList.get(i));
			}
		}
		
	}
	
	@Override
	public void deleteSidecar(List<SidecarVO> sidecarVOList) throws Exception {
		for(int i = 0; i < sidecarVOList.size(); i++) {
			sidecarVOList.get(i).setFrstRegisterId(Optional.ofNullable(usertInfoUtil.getUserId()).orElse(""));
			sidecarVOList.get(i).setLastChangerId(Optional.ofNullable(usertInfoUtil.getUserId()).orElse(""));
			sidecarMapper.deleteSidecar(sidecarVOList.get(i));
			sidecarMapper.insertSidecarHst(sidecarVOList.get(i));
		}
	}

	@Override
	public int searchSidecarTotalCnt(SidecarVO sidecarVO) {
		return sidecarMapper.searchSidecarTotalCnt(sidecarVO);
	}

	@Override
	public int selectDupSidecar(SidecarVO vo) {
		return sidecarMapper.selectDupSidecar(vo);
	}

	
	
	@Override
	public List<SidecarVO> searchSidecarDtlList(SidecarVO sidecarVO) {
		return sidecarMapper.searchSidecarDtlList(sidecarVO);
	}

	@Override
	public int searchSidecarDtlTotalCnt(SidecarVO sidecarVO) {
		return sidecarMapper.searchSidecarTotalDtlCnt(sidecarVO);
	}

}
