package com.sorincorp.bo.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.it.mapper.ItCmnCodeMapper;
import com.sorincorp.bo.it.model.ItCmnCodeVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ItCmnCodeServiceImpl implements ItCmnCodeService {


	@Autowired
	private ItCmnCodeMapper itCmnCodeMapper;

	@Override
	public List<ItCmnCodeVO> selectCmnCodeList(ItCmnCodeVO vo) throws Exception {
		// TODO Auto-generated method stub
		return itCmnCodeMapper.selectCmnCodeList(vo);
	}

}
