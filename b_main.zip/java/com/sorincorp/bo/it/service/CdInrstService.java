package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.CdInrstVO;

/**Cd금리 Service*/
public interface CdInrstService {

	/**
	 * <pre>
	 * 처리내용: cd금리 목록을 조회한다.
	 * </pre>
	 * @date 2022. 9. 16.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 16.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param civo
	 * @return
	 */
	List<CdInrstVO> selectCdInrstListData(CdInrstVO civo);

	/**
	 * <pre>
	 * 처리내용: cd금리 목록의 수를 카운트한다.
	 * </pre>
	 * @date 2022. 9. 16.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 16.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param civo
	 * @return
	 */
	int selectCntCdInrstListData(CdInrstVO civo);

	/**
	 * <pre>
	 * 처리내용: 차트를 위해 cd금리 목록을 조회한다.
	 * </pre>
	 * @date 2022. 10. 4.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 4.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param civo
	 * @return
	 */
	List<CdInrstVO> selectForChartCdListData(CdInrstVO civo);

}
