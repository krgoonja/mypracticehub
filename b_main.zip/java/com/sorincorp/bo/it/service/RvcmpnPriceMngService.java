package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.BsnManageBasVO;
import com.sorincorp.bo.it.model.RvcmpnPriceMngVO;


public interface RvcmpnPriceMngService {
	
	/**
	 * 경쟁사 가격 관리 조회한다.
	 * @param rvcmpnPriceMngVO 
	 * @param RvcmpnPriceMngVO - 조회할 정보가 담긴 VO
	 * @return 경쟁사 가격관리 리스트
	 * @exception Exception
	 */
	public List<RvcmpnPriceMngVO> searchRvcmpnPriceMngList(RvcmpnPriceMngVO rvcmpnPriceMngVO) throws Exception;

	public void insertAndUpdateRvcmpnPriceMngList(List<RvcmpnPriceMngVO> rvcmpnPriceMngVOList);

	public int searchRvcmpnPriceMngTotalCnt(RvcmpnPriceMngVO rvcmpnPriceMngVO);

	public void deleteRvcmpnPrice(List<RvcmpnPriceMngVO> rvcmpnPriceMngVOList);

	public List<BsnManageBasVO> beginValidation(RvcmpnPriceMngVO vo);

	public int selectDupRvcmpnPrice(RvcmpnPriceMngVO vo);
}