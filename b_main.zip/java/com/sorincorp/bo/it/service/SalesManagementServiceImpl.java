/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sorincorp.bo.it.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.redis.config.RedisPubSubService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.SalesManagementMapper;
import com.sorincorp.bo.it.model.SalesDlvyManagementVO;
import com.sorincorp.bo.it.model.SalesManagementVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SalesManagementServiceImpl implements SalesManagementService {

	@Autowired
	private SalesManagementMapper salesManagementMapper;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private CommonService commonService;

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Value("${order.api.lme.url}")
	private String apiDomain;

	@Autowired
	private RedisPubSubService redisPubSubService;
	
	@Value("${redisPubsub.uri.restTime}")
	private String restTimeUri;

	@Override
	public List<SalesManagementVO> getListSalesManagement(SalesManagementVO salesManagementVO) throws Exception {
		return salesManagementMapper.getListSalesManagement(salesManagementVO);
	}

	@Override
	public int getListSalesManagementCnt(SalesManagementVO salesManagementVO) throws Exception {
		return salesManagementMapper.getListSalesManagementCnt(salesManagementVO);
	}

	@Override
	public SalesManagementVO getSalesManagement(SalesManagementVO salesManagementVO) throws Exception {
		// 영업관리 기본
		SalesManagementVO returnVO = new SalesManagementVO();
		salesManagementVO.setApplcDe(salesManagementVO.getApplcDe().replace("-", ""));
		returnVO = salesManagementMapper.getSalesManagement(salesManagementVO);
		// 영업배송관리 기본
		SalesDlvyManagementVO paramVO = new SalesDlvyManagementVO();
		paramVO.setApplcDe(salesManagementVO.getApplcDe().replace("-", ""));
		returnVO.setSalesDlvyManagementVOList(salesManagementMapper.getSalesDlvyManagement(paramVO));

		return returnVO;
	}

	@Override
	public void insertSalesManagement(SalesManagementVO salesManagementVO) throws Exception {
		SalesManagementVO deleteCheckVO = new SalesManagementVO();
		deleteCheckVO = salesManagementMapper.getSalesManagement(salesManagementVO);
		salesManagementVO.setApplcDe(salesManagementVO.getApplcDe().replace("-", ""));
		salesManagementVO.setHghnetprcBeginTime(salesManagementVO.getHghnetprcBeginTime().replace(":", "") + "00");
		salesManagementVO.setHghnetprcEndTime(salesManagementVO.getHghnetprcEndTime().replace(":", "") + "00");
		salesManagementVO.setRltmBeginTime(salesManagementVO.getRltmBeginTime().replace(":", "") + "00");
		salesManagementVO.setRltmEndTime(salesManagementVO.getRltmEndTime().replace(":", "") + "00");
		salesManagementVO.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		salesManagementVO.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));

		if ("Y".equals(salesManagementVO.getChangeAt())) {
			lmeRestDateTimeInit();
		}

		if (deleteCheckVO == null) {

			// 영업 관리 등록
			salesManagementMapper.insertSalesManagement(salesManagementVO);
			salesManagementMapper.insertSalesManagementHist(salesManagementVO);

			// 영업 배송 관리 등록
			for (SalesDlvyManagementVO vo : salesManagementVO.getSalesDlvyManagementVOList()) {
				vo.setApplcDe(salesManagementVO.getApplcDe().replace("-", ""));
				vo.setManatmbTodayDlivyClosTime(vo.getManatmbTodayDlivyClosTime().replace(":", "") + "00");
				vo.setSorinTodayDlivyClosTime(vo.getSorinTodayDlivyClosTime().replace(":", "") + "00");
				vo.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				vo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				salesManagementMapper.insertSalesDlvyManagement(vo);
				salesManagementMapper.insertSalesDlvyManagementHist(vo);
			}

		} else if (deleteCheckVO != null && "Y".equals(deleteCheckVO.getDeleteAt())) {
			salesManagementVO.setDeleteAt("N");
			salesManagementVO.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			salesManagementMapper.updateSalesManagement(salesManagementVO);
			salesManagementMapper.insertSalesManagementHist(salesManagementVO);

			for (SalesDlvyManagementVO vo : salesManagementVO.getSalesDlvyManagementVOList()) {
				vo.setApplcDe(salesManagementVO.getApplcDe().replace("-", ""));
				vo.setManatmbTodayDlivyClosTime(vo.getManatmbTodayDlivyClosTime().replace(":", "") + "00");
				vo.setSorinTodayDlivyClosTime(vo.getSorinTodayDlivyClosTime().replace(":", "") + "00");
				vo.setApplcDe(salesManagementVO.getApplcDe().replace("-", ""));
				vo.setDeleteAt("N");
				vo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				salesManagementMapper.updateSalesDlvyManagement(vo);
				salesManagementMapper.insertSalesDlvyManagementHist(vo);
			}

		}
		
		redisPubSubService.publishMessage(restTimeUri, restTimeUri, "setSalesDt");

	}

	@Override
	public void updateSalesManagement(SalesManagementVO salesManagementVO) throws Exception {
		salesManagementVO.setApplcDe(salesManagementVO.getApplcDe().replace("-", ""));
		salesManagementVO.setHghnetprcBeginTime(salesManagementVO.getHghnetprcBeginTime().replace(":", "") + "00");
		salesManagementVO.setHghnetprcEndTime(salesManagementVO.getHghnetprcEndTime().replace(":", "") + "00");
		salesManagementVO.setRltmBeginTime(salesManagementVO.getRltmBeginTime().replace(":", "") + "00");
		salesManagementVO.setRltmEndTime(salesManagementVO.getRltmEndTime().replace(":", "") + "00");
		salesManagementVO.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));

		if ("Y".equals(salesManagementVO.getChangeAt())) {
			lmeRestDateTimeInit();
		}

		salesManagementMapper.updateSalesManagement(salesManagementVO);
		salesManagementMapper.insertSalesManagementHist(salesManagementVO);

		for (SalesDlvyManagementVO vo : salesManagementVO.getSalesDlvyManagementVOList()) {
			vo.setApplcDe(salesManagementVO.getApplcDe().replace("-", ""));
			vo.setManatmbTodayDlivyClosTime(vo.getManatmbTodayDlivyClosTime().replace(":", "") + "00");
			vo.setSorinTodayDlivyClosTime(vo.getSorinTodayDlivyClosTime().replace(":", "") + "00");
			vo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			salesManagementMapper.updateSalesDlvyManagement(vo);
			salesManagementMapper.insertSalesDlvyManagementHist(vo);
		}

	}

	/**
	 * <pre>
	 * 처리내용: LME 초기화 API
	 * </pre>
	 * @date 2023. 4. 20.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 4. 20.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @throws Exception
	 */
	private void lmeRestDateTimeInit() throws Exception {
		Map<String, Object> resObj = null;
		try {
			// 영업 관리 등록 및 수정 api
			resObj = httpClientHelper.postCallApi(apiDomain, null);

			if (resObj.isEmpty()) {
				throw new Exception("통신장애");
			}
		} catch (Exception e) {
			log.error("영업 관리 등록 및 수정 api resObj :::  + resObj");
			log.error("영업 관리 API 실패 ===> ", e.getMessage());
			// 추가
		}
	}

	@Override
	public void deleteSalesManagement(SalesManagementVO salesManagementVO) throws Exception {
		salesManagementVO.setApplcDe(salesManagementVO.getApplcDe().replace("-", ""));
		salesManagementVO.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		salesManagementMapper.deleteSalesManagement(salesManagementVO);
		salesManagementMapper.insertSalesManagementHist(salesManagementVO);

		SalesDlvyManagementVO param = new SalesDlvyManagementVO();
		param.setApplcDe(salesManagementVO.getApplcDe().replace("-", ""));
		param.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		salesManagementMapper.deleteSalesDlvyManagement(param);
		salesManagementMapper.insertSalesDlvyManagementHist(param);
	}

	@Override
	public SalesManagementVO selectManagementTime() throws Exception {
		return salesManagementMapper.selectManagementTime();
	}

	@Override
	public int getSalesManagementCnt(SalesManagementVO salesManagementVO) throws Exception {
		return salesManagementMapper.getSalesManagementCnt(salesManagementVO);
	}

	@Override
	public List<SalesManagementVO> getTopListSalesManagement(SalesManagementVO salesManagementVO) throws Exception {
		return salesManagementMapper.getTopListSalesManagement(salesManagementVO);
	}
	
	@Override
	public SalesManagementVO selectTopListSalesManagement() throws Exception {
		SalesManagementVO topSalesManagementVO = salesManagementMapper.selectTopListSalesManagement();
		return topSalesManagementVO;
	}
	
	@Override
	public void updateSalesTime(SalesManagementVO salesManagementVO) throws Exception {
		salesManagementVO.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		salesManagementVO.setApplcDe(salesManagementVO.getApplcDe().replace("-", ""));
		salesManagementVO.setRltmBeginTime(salesManagementVO.getRltmBeginTime().replace(":", "") + "00");
		salesManagementVO.setRltmEndTime(salesManagementVO.getRltmEndTime().replace(":", "") + "00");
		
		salesManagementMapper.updateSalesTime(salesManagementVO);
		salesManagementMapper.insertSalesManagementHist(salesManagementVO);
		
		redisPubSubService.publishMessage(restTimeUri, restTimeUri, "setSalesDt");
	}
}
