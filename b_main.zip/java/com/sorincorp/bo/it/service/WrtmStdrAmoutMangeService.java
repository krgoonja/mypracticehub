package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.WrtmStdrAmoutMangeVO;

public interface WrtmStdrAmoutMangeService {
	/**
	 * <pre>
	 * 처리내용: 증거금 기준금액 목록을 조회한다
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public List<WrtmStdrAmoutMangeVO> getWrtmStdrAmoutMangeList(WrtmStdrAmoutMangeVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 증거금 기준금액 목록 카운트를 조회한다
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public int selectWrtmStdrAmoutMangeCnt(WrtmStdrAmoutMangeVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 증거금 기준금액 테이블의 중복을 체크한다
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public int duplicateCheckAjax(WrtmStdrAmoutMangeVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 증거금 기준 금액 관리 정보를 저장하고 이력을 저장한다
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	public String insertAndUpdateWrtmStdrAjaxList(WrtmStdrAmoutMangeVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 상품_증거금 기준 금액 관리 상세 테이블을 조회한다
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public List<WrtmStdrAmoutMangeVO> getItWrtmStdrAmoutMangeDtlList(WrtmStdrAmoutMangeVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 상품_증거금 기준 금액 관리 기본 테이블을 조회한다
	 * </pre>-
	 * @date 2022. 7. 14.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 14.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public WrtmStdrAmoutMangeVO getItWrtmStdrAmoutMangeBas(WrtmStdrAmoutMangeVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 증거금 기준 금액 관리 정보를 수정하고 이력을 저장한다
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	public void updateWrtmStdrAjaxList(WrtmStdrAmoutMangeVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 증거금 기준 금액 관리 정보를 삭제하고 이력을 저장한다
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	public void deleteWrtmStdrAmoutAjax(WrtmStdrAmoutMangeVO vo) throws Exception;
}
