package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.FixingPcItmacctoVO;

/**
 * FixingPcItmacctoService.java
 * @version
 * @since 2023. 3. 7.
 * @author srec0064
 */
public interface FixingPcItmacctoService {

	/**
	 * <pre>
	 * 처리내용: 구매제한/가격관리 리스트 조회
	 * </pre>
	 * @date 2023. 3. 6.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 6.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	List<FixingPcItmacctoVO> selectPurchsLmttPcManageList(FixingPcItmacctoVO vo);

	/**
	 * <pre>
	 * 처리내용: 구매제한/가격관리 업데이트
	 * </pre>
	 * @date 2023. 3. 7.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 7.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param list
	 * @return
	 */
	int updatePurchsLmttPcManage(List<FixingPcItmacctoVO> list);

	/**
	 * <pre>
	 * 처리내용: 구매제한/가격관리 삭제 (삭제컬럼 Y 업데이트)
	 * </pre>
	 * @date 2023. 3. 8.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 8.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	int deletePurchsLmttPcManage(FixingPcItmacctoVO vo);

	/**
	 * <pre>
	 * 처리내용: 전월 데이터를 읽어와서 현재월에 저장한다.
	 * </pre>
	 * @date 2023. 3. 8.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 8.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param applcYm
	 * @return
	 */
	int copyPreMonthData(FixingPcItmacctoVO vo);

	/**
	 * <pre>
	 * 처리내용: 고정가 구매원가 관리 리스트 조회
	 * </pre>
	 * @date 2023. 3. 7.
	 * @author srec0064
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 7.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	List<FixingPcItmacctoVO> geFixingPcItmacctoPrmpcList(FixingPcItmacctoVO fixingPcItmacctoVO);

	/**
	 * <pre>
	 * 처리내용: 고정가 구매원가 관리 수정
	 * </pre>
	 * @date 2023. 3. 9.
	 * @author srec0064
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 9.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param fixingPcItmacctoVO
	 */
	void updateFixingPcItmacctoPrmpcAjax(FixingPcItmacctoVO fixingPcItmacctoVO);


	/**
	 * <pre>
	 * 처리내용: 상품_고정가 아이템별 원가 기본을 조회한다.
	 * </pre>
	 * @date 2023. 3. 9.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 9.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param fixingPcItmacctoVO
	 * @return
	 */
	List<FixingPcItmacctoVO> selectItFixingPcItmacctoPrmpcBasList(FixingPcItmacctoVO fixingPcItmacctoVO);


	/**
	 * <pre>
	 * 처리내용: 구매제한/가격관리 insert or update
	 * </pre>
	 * @date 2023. 3. 10.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 10.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param list
	 * @return
	 */
	int insertAndUpdatePurchsLmttPcManage(List<FixingPcItmacctoVO> list);


	/**
	 * <pre>
	 * 처리내용: 구매원가관리에서 수정된, 당월고시가격, 단위기간, 사용여부값을 원가상세테이블에 업데이트한다.
	 * </pre>
	 * @date 2023. 3. 13.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 13.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param list
	 * @return
	 */
	int updatePurchsLmttPcByPrmPc(List<FixingPcItmacctoVO> paramList);

	/**
	 * <pre>
	 * 처리내용: 구매제한, 가격관리 테이블 적용년월 , 권역 별 count 조회
	 * </pre>
	 * @date 2023. 3. 13.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 13.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param fixingPcItmacctoVO
	 * @return
	 */
	int selectPurchsLmttPcCount(FixingPcItmacctoVO fixingPcItmacctoVO);
}
