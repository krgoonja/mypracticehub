package com.sorincorp.bo.it.service;

import java.util.ArrayList;
import java.util.List;

import com.sorincorp.comm.common.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.BrandMgrMapper;
import com.sorincorp.bo.it.model.BrandMgrVO;
import com.sorincorp.comm.brandcode.mapper.BrandCodeMapper;
import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.brandgroupcode.mapper.BrandGroupCodeMapper;
import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;
import com.sorincorp.comm.util.CacheUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BrandMgrServiceImpl implements BrandMgrService {

	@Autowired
	private BrandMgrMapper brandMgrMapper;
	@Autowired
	private UserInfoUtil userInfoUtil;
	@Autowired
	private BrandCodeMapper brandCodeMapper;
	@Autowired
	private BrandGroupCodeMapper brandGroupCodeMapper;
	@Autowired
	private CacheUtil cacheUtil;
	@Autowired
	private CommonService commonService;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<BrandMgrVO> selectBrandMgrList(BrandMgrVO brandMgrVO) throws Exception {
		// TODO Auto-generated method stub
		return brandMgrMapper.selectBrandMgrList(brandMgrVO);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int selectBrandMgrTotalCnt(BrandMgrVO brandMgrVO) throws Exception {
		// TODO Auto-generated method stub
		return brandMgrMapper.selectBrandMgrTotalCnt(brandMgrVO);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<BrandMgrVO> selectSpecDetailList(BrandMgrVO brandMgrVO) throws Exception {
		// TODO Auto-generated method stub
		return brandMgrMapper.selectSpecDetailList(brandMgrVO);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandSaveList
	 * @return
	 * @throws Exception
	 */
	@Override
	public int updateBrandData(ArrayList<BrandMgrVO> brandSaveList) throws Exception {
		// TODO Auto-generated method stub
		BrandMgrVO brandMgrVO;
		int result = 0;

		for(int i=0;i<brandSaveList.size();i++) {
			brandMgrVO = brandSaveList.get(i);

			brandMgrVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			result = brandMgrMapper.updateBrandData(brandMgrVO);
			//brandMgrMapper.insertItBrandInfoBasHst(brandMgrVO);
			commonService.insertTableHistory("IT_BRAND_INFO_BAS", brandMgrVO);

		}

		BrandCodeVO brandCodeVO = new BrandCodeVO();
		List<BrandCodeVO> brandCodeList = brandCodeMapper.getBrandCode(brandCodeVO);
		cacheUtil.put("brandCodeList", brandCodeList);

		BrandGroupCodeVO brandGroupCodeVO = new BrandGroupCodeVO();
		List<BrandGroupCodeVO> brandGroupCodeList = brandGroupCodeMapper.getBrandGroupCode(brandGroupCodeVO);
		cacheUtil.put("brandGroupCodeList", brandGroupCodeList);

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandSpecSaveList
	 * @return
	 * @throws Exception
	 */
	@Override
	public int saveBrandSpecMgr(ArrayList<BrandMgrVO> brandSpecSaveList) throws Exception {
		// TODO Auto-generated method stub
		BrandMgrVO brandMgrVO;
		int result = 0;
		int brandStdSpecDetailSn = 0;

		for(int i=0;i<brandSpecSaveList.size();i++) {
			brandMgrVO = brandSpecSaveList.get(i);
			brandMgrVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

			brandStdSpecDetailSn = brandMgrVO.getBrandStdSpecDetailSn();

			if(brandStdSpecDetailSn > 0) {
				//브랜드 스펙 UPDATE
				result = brandMgrMapper.updateBrandSpecData(brandMgrVO);
			} else {
				//브랜드 스펙 INSERT
				result = brandMgrMapper.insertBrandSpecData(brandMgrVO);
			}
			//brandMgrMapper.insertItBrandStdSpecDtlHst(brandMgrVO);
			commonService.insertTableHistory("IT_BRAND_STD_SPEC_DTL", brandMgrVO);
		}
		return result;
	}

}
