package com.sorincorp.bo.it.service;

import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;
import com.sorincorp.bo.it.model.AvrgPcLiveGradInfoVO;
import com.sorincorp.bo.it.model.AvrgPcLiveRateDtlVO;
import com.sorincorp.bo.it.model.AvrgPcLiveRateMngVO;

/**
 * AvrgPcLiveRateMngService.java
 * 평균가 라이브 비율 관리 Service 인터페이스
 * 
 * @version
 * @since 2023. 8. 16.
 * @author srec0049
 */
public interface AvrgPcLiveRateMngService {
	
	/**
	 * <pre>
	 * 처리내용: 평균가 라이브 비율 관리 목록(총 건수 포함)을 가져온다.
	 * </pre>
	 * @date 2023. 8. 16.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 16.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @return
	 * @throws Exception
	 */
	public List<AvrgPcLiveRateMngVO> getListAvrgPcLiveRate(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 금속코드와 적용일자에 대한 평균가 라이브 비율 관리 목록(상품_평균가 LIVE 기준 중량 관리 기본) 중복 건수를 가져온다.
	 * </pre>
	 * @date 2023. 8. 24.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 24.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @return
	 * @throws Exception
	 */
	public Integer getAvrgPcLiveRateDuplCnt(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 상품_평균가 LIVE 기준 중량 관리 기본 정보를 가져온다.
	 * </pre>
	 * @date 2023. 8. 29.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 29.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @return
	 * @throws Exception
	 */
	public AvrgPcLiveRateMngVO getAvrgPcLiveRate(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 톤당 구매 비율 리스트 구조 가져오기
	 * </pre>
	 * @date 2023. 9. 21.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 9. 21.          srec0049         최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public List<AvrgPcLiveRateMngVO> getPurchsRateStructurePerTonList() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 금속 코드에 해당하는 톤당 구매 비율 리스트를 가져온다.
	 * </pre>
	 * @date 2023. 10. 16.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 10. 16.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	public List<AvrgPcLiveGradInfoVO> getPurchsRateValuePerTonListByMetalCode(String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 톤당 구매 비율 리스트 - 상품_평균가 LIVE 기준 중량 관리의 단계 비율 데이터로 [평균가 LIVE 등급 관리 데이터(selectMbAvrgPcLiveGradMngList 메소드)] 리스트를 생성한다.
	 * </pre>
	 * @date 2023. 8. 30.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 30.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateJson
	 * @param avrgPcLiveRateMngVO
	 * @return
	 * @throws Exception
	 */
	public List<AvrgPcLiveRateMngVO> getPurchsRatePerTonList(JsonNode avrgPcLiveRateJson, AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 상품_평균가 LIVE 기준 중량 관리 상세에 평균 라이브 비율 기준 톤수 데이터 리스트를 가져온다.
	 * </pre>
	 * @date 2023. 9. 4.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 9. 4.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @return
	 * @throws Exception
	 */
	public List<AvrgPcLiveRateDtlVO> getAvrgPcLiveRateDtlList(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 평균 라이브 비율 데이터를 등록한다.
	 * </pre>
	 * @date 2023. 8. 28.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 28.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @throws Exception
	 */
	public void insertAvrgPcLiveRate(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 평균 라이브 비율 데이터를 수정한다.
	 * </pre>
	 * @date 2023. 9. 4.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 9. 4.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @throws Exception
	 */
	public void updateAvrgPcLiveRate(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 평균 라이브 비율 데이터를 삭제한다.
	 * </pre>
	 * @date 2023. 9. 4.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 9. 4.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @throws Exception
	 */
	public void deleteAvrgPcLiveRate(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
}
