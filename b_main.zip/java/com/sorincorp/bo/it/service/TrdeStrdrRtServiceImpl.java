package com.sorincorp.bo.it.service;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.it.mapper.TrdeStdrRtMapper;
import com.sorincorp.bo.it.model.TrdeStrdrRtVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TrdeStrdrRtServiceImpl implements TrdeStrdrRtService {
	
	
	@Autowired
	private TrdeStdrRtMapper trdeStdrRtMapper;
	
	@Override
	public List<TrdeStrdrRtVO> selectTrdeStdrRtListData(TrdeStrdrRtVO searchVO) {
		// TODO Auto-generated method stub
		return trdeStdrRtMapper.selectTrdeStdrRtListData(searchVO);
	}

	@Override
	public int selectCntTrdeStdrRtList(TrdeStrdrRtVO searchVO) {
		// TODO Auto-generated method stub
		return trdeStdrRtMapper.selectCntTrdeStdrRtList(searchVO);
	}

	@Override
	public Map<String, Object> selectCurrCd() {
		// 통화 기준코드를 map 형태로 자동정렬하기 위해 TreeMap사용한다.
		Map<String,Object> map = new TreeMap<String, Object>();
		
		//Map<String,Object> map = new TreeMap<String, Object>(Collections.reverseOrder()); /*내림차순으로 정렬시*/
		
		List<TrdeStrdrRtVO> cdList = trdeStdrRtMapper.selectCurrCd();
	
		//매매기준율 테이블의 기준 통화코드 목록을 가져와 Map형태로 변환한다.
		for(TrdeStrdrRtVO list : cdList) {
			String currCode = list.getCurrCd();
			map.put(currCode, currCode);
		}
	
		return map;
	}

}
