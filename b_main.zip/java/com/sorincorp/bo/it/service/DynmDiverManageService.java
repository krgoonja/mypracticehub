package com.sorincorp.bo.it.service;

import java.util.Map;

import com.sorincorp.bo.it.model.DynmDiverMangeVO;
import com.sorincorp.comm.dynmDiver.model.DynmDiverCommVO;


public interface DynmDiverManageService {


	DynmDiverMangeVO selectGtxApiFxrate() throws Exception;

	Long selectSlePc() throws Exception;

	DynmDiverMangeVO selectDiverAt() throws Exception;

	void updateDiverAt(DynmDiverMangeVO diverVo) throws Exception;

	String selectDiverPremiumId() throws Exception;

	DynmDiverMangeVO selectDiverPremium(String premiumId) throws Exception;

	Map<String, String> diverAt(DynmDiverMangeVO dynmDiverMangeVO) throws Exception;

	DynmDiverCommVO selectPremiumDiverInfo() throws Exception;

}
