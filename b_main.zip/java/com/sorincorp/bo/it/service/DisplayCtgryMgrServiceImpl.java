package com.sorincorp.bo.it.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sorincorp.comm.common.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.DisplayCtgryMgrMapper;
import com.sorincorp.bo.it.mapper.ItemMgrMapper;
import com.sorincorp.bo.it.model.DisplayCtgryMgrVO;
import com.sorincorp.bo.it.model.ItemMgrVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DisplayCtgryMgrServiceImpl implements DisplayCtgryMgrService {

	@Autowired
	private DisplayCtgryMgrMapper displayCtgryMgrMapper;
	@Autowired
	private ItemMgrMapper itemMgrMapper;
	@Autowired
	private UserInfoUtil userInfoUtil;
	@Autowired
	private CommonService commonService;

	/**
	 * <pre>
	 * 처리내용: 카테고리 리스트 정보를 조회한다.
	 * </pre>
	 * @date 2021. 7. 1.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 1.			srec0030			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<DisplayCtgryMgrVO> selectDisplayCtgryList(int ctgryLevel) throws Exception {
		// TODO Auto-generated method stub
		return displayCtgryMgrMapper.selectDisplayCtgryList(ctgryLevel);
	}

	/**
	 * <pre>
	 * 처리내용: 카테고리 정보를 등록하거나 업데이트한다.
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int updateDisplayCtgryMgr(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception {
		// TODO Auto-generated method stub
		int result = 0;
		int ctgryNo = 0;

		DisplayCtgryMgrVO vo;
		DisplayCtgryMgrVO lv1Vo;
		DisplayCtgryMgrVO lv2Vo;
		DisplayCtgryMgrVO lv3Vo;
		//카테고리 저장 전체리스트
		ArrayList<DisplayCtgryMgrVO> ctgrySaveList = displayCtgryMgrVO.getCtgrySaveList();
		//카테고리 레벨1
		ArrayList<DisplayCtgryMgrVO> ctgryLv1List = new ArrayList<DisplayCtgryMgrVO>();
		//카테고리 레벨2
		ArrayList<DisplayCtgryMgrVO> ctgryLv2List = new ArrayList<DisplayCtgryMgrVO>();
		//카테고리 레벨3
		ArrayList<DisplayCtgryMgrVO> ctgryLv3List = new ArrayList<DisplayCtgryMgrVO>();

		if(ctgrySaveList != null && ctgrySaveList.size() > 0) {

			for(int i=0;i<ctgrySaveList.size();i++) {
				vo = ctgrySaveList.get(i);

				if("1".equals(vo.getCtgryLevel())) {
					//카테고리 레벨1 리스트 분리
					ctgryLv1List.add(vo);
				} else if("2".equals(vo.getCtgryLevel())) {
					//카테고리 레벨2 리스트 분리
					ctgryLv2List.add(vo);
				} else if("3".equals(vo.getCtgryLevel())) {
					//카테고리 레벨3 리스트 분리
					ctgryLv3List.add(vo);
				}
			}

			for(int i=0;i<ctgryLv1List.size();i++) {

				lv1Vo = ctgryLv1List.get(i);
				lv1Vo.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
				lv1Vo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
				ctgryNo = lv1Vo.getCtgryNo();

				if(ctgryNo > 0) {
					//카테고리번호가 이미 있을 경우 UPDATE
					displayCtgryMgrMapper.updateDisplayCtgryMgr(lv1Vo);
					//displayCtgryMgrMapper.insertItItmCtgryBasHst(lv1Vo);
					commonService.insertTableHistory("IT_ITM_CTGRY_BAS", lv1Vo);
					result = lv1Vo.getCtgryNo();

				} else {
					//카테고리번호가 없을 경우 INSERT
					displayCtgryMgrMapper.insertDisplayCtgryMgr(lv1Vo);
					//displayCtgryMgrMapper.insertItItmCtgryBasHst(lv1Vo);
					commonService.insertTableHistory("IT_ITM_CTGRY_BAS", lv1Vo);

					if(lv1Vo.getCtgryNo() > 0) {
						//레벨1 카테고리 INSERT 한 후에 생성된 카테고리 번호를 리턴 받음
						result = lv1Vo.getCtgryNo();

						for(int j=0;j<ctgryLv2List.size();j++) {
							lv2Vo = ctgryLv2List.get(j);

							if(lv2Vo.getCtgryNo() < 1  && lv2Vo.getCtgryUpperNodeId() != null && lv2Vo.getCtgryUpperNodeId().equals(lv1Vo.getCtgryNodeId())) {
								//레벨2 카테고리 번호가 없고(신규) 레벨1카테고리와 부모자식 관계일 경우 레벨1 카테고리번호를 레벨2상위카테고리번호로 세팅
								//if(lv2Vo.getCtgryUpperNodeId().equals(lv1Vo.getCtgryNodeId())) {
								ctgryLv2List.get(j).setUpperCtgryNo(lv1Vo.getCtgryNo());
								//}
							}
						}
					}
				}
			}

			for(int i=0;i<ctgryLv2List.size();i++) {

				lv2Vo = ctgryLv2List.get(i);
				lv2Vo.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
				lv2Vo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
				ctgryNo = lv2Vo.getCtgryNo();

				if(ctgryNo > 0) {
					//카테고리번호가 이미 있을 경우 UPDATE
					displayCtgryMgrMapper.updateDisplayCtgryMgr(lv2Vo);
					//displayCtgryMgrMapper.insertItItmCtgryBasHst(lv2Vo);
					commonService.insertTableHistory("IT_ITM_CTGRY_BAS", lv2Vo);
					result = lv2Vo.getCtgryNo();
				} else {
					//카테고리번호가 없을 경우 INSERT
					displayCtgryMgrMapper.insertDisplayCtgryMgr(lv2Vo);
					//displayCtgryMgrMapper.insertItItmCtgryBasHst(lv2Vo);
					commonService.insertTableHistory("IT_ITM_CTGRY_BAS", lv2Vo);

					if(lv2Vo.getCtgryNo() > 0) {
						//레벨2 카테고리 INSERT 한 후에 생성된 카테고리 번호를 리턴 받음
						result = lv2Vo.getCtgryNo();

						for(int j=0;j<ctgryLv3List.size();j++) {
							lv3Vo = ctgryLv3List.get(j);

							if(lv3Vo.getCtgryNo() < 1 && lv3Vo.getCtgryUpperNodeId() != null && lv3Vo.getCtgryUpperNodeId().equals(lv2Vo.getCtgryNodeId())) {
								//레벨3 카테고리 번호가 없고(신규) 레벨2카테고리와 부모자식 관계일 경우 레벨2카테고리번호를 레벨3상위카테고리번호로 세팅
								//if(lv3Vo.getCtgryUpperNodeId().equals(lv2Vo.getCtgryNodeId())) {
								ctgryLv3List.get(j).setUpperCtgryNo(lv2Vo.getCtgryNo());
								//}
							}
						}
					}
				}
			}

			for(int i=0;i<ctgryLv3List.size();i++) {

				lv3Vo = ctgryLv3List.get(i);
				lv3Vo.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
				lv3Vo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
				ctgryNo = lv3Vo.getCtgryNo();

				if(ctgryNo > 0) {
					//카테고리번호가 이미 있을 경우 UPDATE
					displayCtgryMgrMapper.updateDisplayCtgryMgr(lv3Vo);
					//displayCtgryMgrMapper.insertItItmCtgryBasHst(lv3Vo);
					commonService.insertTableHistory("IT_ITM_CTGRY_BAS", lv3Vo);
					result = lv3Vo.getCtgryNo();
				} else {
					//카테고리번호가 없을 경우 INSERT
					displayCtgryMgrMapper.insertDisplayCtgryMgr(lv3Vo);
					//displayCtgryMgrMapper.insertItItmCtgryBasHst(lv3Vo);
					commonService.insertTableHistory("IT_ITM_CTGRY_BAS", lv3Vo);

					if(lv3Vo.getCtgryNo() > 0) {
						result = lv3Vo.getCtgryNo();
					}
				}
			}
		}
		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 카테고리정보에 아이템 순번을 매핑한다.
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int insertCtgryRls(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception {
		// TODO Auto-generated method stub
		int result = 0;
		int itmSn = 0;
		int cnt = 0;

		displayCtgryMgrVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
		displayCtgryMgrVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

		for(int i=0;i<displayCtgryMgrVO.getItmSnArray().length;i++) {
			itmSn = displayCtgryMgrVO.getItmSnArray()[i];
			log.debug("itmSn : "+itmSn);
			displayCtgryMgrVO.setItmSn(itmSn);

			cnt = displayCtgryMgrMapper.selectCtgryRlsCnt(displayCtgryMgrVO);

			if(cnt < 1) {
				displayCtgryMgrMapper.insertCtgryRls(displayCtgryMgrVO);

				//log.debug("displayCtgryMg rVO.getCtgrySn() ========>"+displayCtgryMgrVO.getCtgrySn());

				if(displayCtgryMgrVO.getCtgrySn() > 0) {
					//itemMgrMapper.insertItemCtgryRlsHst(displayCtgryMgrVO.getCtgrySn());
					commonService.insertTableHistory("IT_ITM_CTGRY_RLS", displayCtgryMgrVO);
					result++;
				}
			}
		}

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 카테고리 정보에 매핑된 아이템순번의 매핑을 삭제한다.
	 * </pre>
	 * @date 2021. 7. 6.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 6.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int deleteCtgryRls(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception {
		// TODO Auto-generated method stub
		int result = 0;
		int itmSn = 0;
		int cnt = 0;
		int ctgrySn = 0;

		displayCtgryMgrVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
		displayCtgryMgrVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

		for(int i=0;i<displayCtgryMgrVO.getItmSnArray().length;i++) {
			itmSn = displayCtgryMgrVO.getItmSnArray()[i];
			displayCtgryMgrVO.setItmSn(itmSn);

			cnt = displayCtgryMgrMapper.selectCtgryRlsCnt(displayCtgryMgrVO);

			if(cnt > 0) {
				ctgrySn = displayCtgryMgrMapper.selectCtgryRlsCtgrySn(displayCtgryMgrVO);
				log.debug("ctgrySn : "+ctgrySn);
				if(ctgrySn > 0) {
					displayCtgryMgrVO.setCtgrySn(ctgrySn);
					displayCtgryMgrMapper.deleteCtgryRls(displayCtgryMgrVO);
					//itemMgrMapper.insertItemCtgryRlsHst(displayCtgryMgrVO.getCtgrySn());
					commonService.insertTableHistory("IT_ITM_CTGRY_RLS", displayCtgryMgrVO);
					result++;
				}
			}
		}

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<ItemMgrVO> selectCtgryItemList(ItemMgrVO itemMgrVO) throws Exception {
		// TODO Auto-generated method stub
		return displayCtgryMgrMapper.selectCtgryItemList(itemMgrVO);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int deleteDisplayCtgryMgr(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception {
		// TODO Auto-generated method stub
		int result = 0;
		int ctgryNo = displayCtgryMgrVO.getCtgryNo();
		int ctgrySn = 0;
		DisplayCtgryMgrVO vo;
		DisplayCtgryMgrVO lv2;
		DisplayCtgryMgrVO lv3;
		DisplayCtgryMgrVO rlsVo;
		List<DisplayCtgryMgrVO> lv2List;
		List<DisplayCtgryMgrVO> lv3List;
		List<DisplayCtgryMgrVO> ctgryRlsList;
		Map<String, Object> param = new HashMap<String, Object>();

		vo = new DisplayCtgryMgrVO();
		vo.setCtgryNo(ctgryNo);
		vo.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
		vo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		result = displayCtgryMgrMapper.deleteDisplayCtgryMgr(vo);
		//displayCtgryMgrMapper.insertItItmCtgryBasHst(vo);
		commonService.insertTableHistory("IT_ITM_CTGRY_BAS", vo);

		ctgryRlsList = displayCtgryMgrMapper.selectCtgryRlsCtgrySnList(vo);

		if(ctgryRlsList.size() > 0) {
			for(int i=0;i<ctgryRlsList.size();i++) {
				rlsVo = ctgryRlsList.get(i);
				rlsVo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
				displayCtgryMgrMapper.deleteCtgryRls(rlsVo);
				ctgrySn = rlsVo.getCtgrySn();
				//itemMgrMapper.insertItemCtgryRlsHst(ctgrySn);
				commonService.insertTableHistory("IT_ITM_CTGRY_RLS", ctgrySn);
			}
		}

		String ctgryLevel = "";

		vo = displayCtgryMgrMapper.selectCtgryInfo(ctgryNo);
		ctgryLevel = vo.getCtgryLevel();

		if("1".equals(ctgryLevel)) {
			param.put("upperCtgryNo", vo.getCtgryNo());

			lv2List = displayCtgryMgrMapper.selectCtgryInfoList(param);

			if(lv2List.size() > 0) {
				for(int i=0;i<lv2List.size();i++) {
					lv2 = lv2List.get(i);
					lv2.setLastChangerId(userInfoUtil.getAccountInfo().getId());

					lv2 = displayCtgryMgrMapper.selectCtgryInfo(lv2.getCtgryNo());

					param.put("upperCtgryNo", lv2.getCtgryNo());

					result = displayCtgryMgrMapper.deleteDisplayCtgryMgr(lv2);
					//displayCtgryMgrMapper.insertItItmCtgryBasHst(lv2);
					commonService.insertTableHistory("IT_ITM_CTGRY_BAS", lv2);

					ctgryRlsList = displayCtgryMgrMapper.selectCtgryRlsCtgrySnList(lv2);

					if(ctgryRlsList.size() > 0) {
						for(int j=0;j<ctgryRlsList.size();j++) {
							rlsVo = ctgryRlsList.get(j);
							rlsVo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
							displayCtgryMgrMapper.deleteCtgryRls(rlsVo);
							ctgrySn = rlsVo.getCtgrySn();
							//itemMgrMapper.insertItemCtgryRlsHst(ctgrySn);
							commonService.insertTableHistory("IT_ITM_CTGRY_RLS", ctgrySn);
						}
					}

					lv3List = displayCtgryMgrMapper.selectCtgryInfoList(param);

					if(lv3List.size() > 0) {
						for(int k=0;k<lv3List.size();k++) {
							lv3 = lv3List.get(k);
							lv3.setLastChangerId(userInfoUtil.getAccountInfo().getId());

							result = displayCtgryMgrMapper.deleteDisplayCtgryMgr(lv3);
							//displayCtgryMgrMapper.insertItItmCtgryBasHst(lv3);
							commonService.insertTableHistory("IT_ITM_CTGRY_BAS", lv3);

							ctgryRlsList = displayCtgryMgrMapper.selectCtgryRlsCtgrySnList(lv3);

							if(ctgryRlsList.size() > 0) {
								for(int l=0;l<ctgryRlsList.size();l++) {
									rlsVo = ctgryRlsList.get(l);
									rlsVo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
									displayCtgryMgrMapper.deleteCtgryRls(rlsVo);
									ctgrySn = rlsVo.getCtgrySn();
									//itemMgrMapper.insertItemCtgryRlsHst(ctgrySn);
									commonService.insertTableHistory("IT_ITM_CTGRY_RLS", ctgrySn);
								}
							}
						}
					}
				}
			}
		} else if("2".equals(ctgryLevel)) {

			param.put("upperCtgryNo", vo.getCtgryNo());

			lv3List = displayCtgryMgrMapper.selectCtgryInfoList(param);

			if(lv3List.size() > 0) {
				for(int j=0;j<lv3List.size();j++) {
					//lv3 = new DisplayCtgryMgrVO();
					lv3 = lv3List.get(j);
					lv3.setLastChangerId(userInfoUtil.getAccountInfo().getId());

					result = displayCtgryMgrMapper.deleteDisplayCtgryMgr(lv3);
					//displayCtgryMgrMapper.insertItItmCtgryBasHst(lv3);
					commonService.insertTableHistory("IT_ITM_CTGRY_BAS", lv3);

					ctgryRlsList = displayCtgryMgrMapper.selectCtgryRlsCtgrySnList(lv3);

					if(ctgryRlsList.size() > 0) {
						for(int k=0;k<ctgryRlsList.size();k++) {
							//rlsVo = new DisplayCtgryMgrVO();
							rlsVo = ctgryRlsList.get(k);
							rlsVo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
							displayCtgryMgrMapper.deleteCtgryRls(rlsVo);
							ctgrySn = rlsVo.getCtgrySn();
							//itemMgrMapper.insertItemCtgryRlsHst(ctgrySn);
							commonService.insertTableHistory("IT_ITM_CTGRY_RLS", ctgrySn);
						}
					}
				}
			}
		}

		return result;
	}

	@Override
	public boolean isAlreadyRegisteredCtgry(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception {
		int ctgryOrdr = displayCtgryMgrVO.getCtgryOrdr();
		String ctgryLevel = displayCtgryMgrVO.getCtgryLevel();
		int upperCtgryNo = displayCtgryMgrVO.getUpperCtgryNo();
		int ctgryNo = displayCtgryMgrVO.getCtgryNo();
		
		displayCtgryMgrVO.setCtgryOrdr(ctgryOrdr);
		displayCtgryMgrVO.setCtgryLevel(ctgryLevel);
		displayCtgryMgrVO.setUpperCtgryNo(upperCtgryNo);
		displayCtgryMgrVO.setCtgryNo(ctgryNo);
		
		int cnt = displayCtgryMgrMapper.isAlreadyRegisteredCtgry(displayCtgryMgrVO);
		if(cnt > 0) {
			return true;
		} 
		return false;
	}

}
