package com.sorincorp.bo.it.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.CdtlnManagementMapper;
import com.sorincorp.bo.it.model.CdtlnManagementVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdtlnManagementServiceImpl implements CdtlnManagementService {

	@Autowired
	private CdtlnManagementMapper cdtlnManagementMapper;

    @Autowired
    private UserInfoUtil userInfoUtil;

	@Override
	public List<CdtlnManagementVO> getListCdtlnManagement(CdtlnManagementVO cdtlnManagementVO) throws Exception {
		return cdtlnManagementMapper.getListCdtlnManagement(cdtlnManagementVO);
	}

	@Override
	public int getListCdtlnManagementCnt(CdtlnManagementVO cdtlnManagementVO) throws Exception {
		return cdtlnManagementMapper.getListCdtlnManagementCnt(cdtlnManagementVO);
	}

	@Override
	public void insertCdtlnManagement(CdtlnManagementVO cdtlnManagementVO) throws Exception {
		cdtlnManagementVO.setApplcDe(cdtlnManagementVO.getApplcDe().replace("-", ""));
		cdtlnManagementVO.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		cdtlnManagementVO.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		
		cdtlnManagementVO.setMrtgggrntyScritsissuFeeCmpnstnRate(cdtlnManagementVO.getMrtgggrntyScritsissuFeeCmpnstnRate() / 100);
		cdtlnManagementVO.setMrtgggrntyScritsissuFeeCmpnstnCsbyRate(cdtlnManagementVO.getMrtgggrntyScritsissuFeeCmpnstnCsbyRate() / 100);
		cdtlnManagementVO.setMrtgggrntySorinsuprrAddiInrst(cdtlnManagementVO.getMrtgggrntySorinsuprrAddiInrst() / 100);
		cdtlnManagementVO.setMrtgggrntyMpfeeRate(cdtlnManagementVO.getMrtgggrntyMpfeeRate() / 100);
		cdtlnManagementVO.setLongrntyMpfeeRate(cdtlnManagementVO.getLongrntyMpfeeRate() / 100);
		cdtlnManagementVO.setMrtgggrntyArrgIntrRate(cdtlnManagementVO.getMrtgggrntyArrgIntrRate() / 100);

		if("created".equals(cdtlnManagementVO.getGridRowStatus()))
			cdtlnManagementMapper.insertCdtlnManagement(cdtlnManagementVO);
		else if("updated".equals(cdtlnManagementVO.getGridRowStatus()))
			cdtlnManagementMapper.updateCdtlnManagement(cdtlnManagementVO);
		
		cdtlnManagementMapper.insertCdtlnManagementHist(cdtlnManagementVO);
	}

	@Override
	public void updateCdtlnManagement(CdtlnManagementVO cdtlnManagementVO) throws Exception {
		cdtlnManagementVO.setApplcDe(cdtlnManagementVO.getApplcDe().replace("-", ""));
		cdtlnManagementVO.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));

		cdtlnManagementMapper.updateCdtlnManagement(cdtlnManagementVO);
		cdtlnManagementMapper.insertCdtlnManagementHist(cdtlnManagementVO);


	}

	@Override
	public CdtlnManagementVO getCdtlnManagement(CdtlnManagementVO cdtlnManagementVO) throws Exception {
		//여신관리 기본
		CdtlnManagementVO returnVO = new CdtlnManagementVO();
		cdtlnManagementVO.setApplcDe(cdtlnManagementVO.getApplcDe().replace("-", ""));
		returnVO = cdtlnManagementMapper.getCdtlnManagement(cdtlnManagementVO);

		return returnVO;
	}

	@Override
	public void deleteCdtlnManagement(CdtlnManagementVO cdtlnManagementVO) throws Exception {
		cdtlnManagementVO.setApplcDe(cdtlnManagementVO.getApplcDe().replace("-", ""));
		cdtlnManagementVO.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		cdtlnManagementMapper.deleteCdtlnManagement(cdtlnManagementVO);
		cdtlnManagementMapper.insertCdtlnManagementHist(cdtlnManagementVO);

	}
	
	/**
	 *	데이터 등록여부를 확인한다.
	 */
	@Override
	public boolean isAlreadyRegistered(CdtlnManagementVO vo) throws Exception {
		String applcDe = vo.getApplcDe().replaceAll("-", "");
		vo.setApplcDe(applcDe);
		
		int cnt = cdtlnManagementMapper.isAlreadyRegistered(vo);
		if(cnt > 0) {
			return true;
		} 
		return false;
	}

}
