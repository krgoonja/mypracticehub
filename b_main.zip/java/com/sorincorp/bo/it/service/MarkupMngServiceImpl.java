package com.sorincorp.bo.it.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.it.mapper.MarkupMngMapper;
import com.sorincorp.bo.it.model.MarkupMngVO;
import com.sorincorp.bo.it.model.SpreadVO;
import com.sorincorp.bo.or.model.UnityOrderFtrsVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MarkupMngServiceImpl implements MarkupMngService {
	
	@Autowired
	private MarkupMngMapper markupMngMapper;
	
	@Override
	public List<MarkupMngVO> selectMarkUpFtrsList() {
		return markupMngMapper.selectMarkUpFtrsList();
	}
	
	@Override
	public int selectMarkUpFtrsCnt() {
		return markupMngMapper.selectMarkUpFtrsCnt();
	}
	
	@Override
	public List<MarkupMngVO> selectMarkUpFtrsCompList() {
		return markupMngMapper.selectMarkUpFtrsCompList();
	}
	
	@Override
	public int selectMarkUpFtrsCompCnt() {
		return markupMngMapper.selectMarkUpFtrsCompCnt();
	}
	
	@Override
	public BigDecimal getTodaySpread(SpreadVO todayVO) throws Exception {
		return markupMngMapper.getTodaySpread(todayVO);
	}
	
	@Override
	public void updateMarkUpTbl(UnityOrderFtrsVO unitVO) throws Exception {
		markupMngMapper.updateMarkUpTbl(unitVO);
	}
	
	@Override
	public int updateMarkupInfo(MarkupMngVO markupVO) {
		return markupMngMapper.updateMarkupInfo(markupVO);
	}
	
	@Override
	public MarkupMngVO selectMarkupInfo() {
		return markupMngMapper.selectMarkupInfo();
	}

}
