package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.SidecarVO;

public interface SidecarService {
	
	/**
	 * <pre>
	 * 처리내용: 사이드카 목록을 조회한다.
	 * </pre>
	 * @date 2021. 5. 28.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 28.      		srec0031			최초작성
	 * ------------------------------------------------
	 * @param sidecarVO
	 * @return
	 * @throws Exception
	 */
	public List<SidecarVO> searchSidecarList(SidecarVO sidecarVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 사이드카 목록을 삭제한다.
	 * </pre>
	 * @date 2021. 5. 28.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 28.			   srec0031		  	    최초작성
	 * ------------------------------------------------
	 * @param sidecarVO
	 * @throws Exception
	 */
	public void deleteSidecar(List<SidecarVO> sidecarVO)  throws Exception;

	/**
	 * <pre>
	 * 처리내용: 사이드카 목록을 저장 수정한다.
	 * </pre>
	 * @date 2021. 5. 28.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 28.			   srec0031		   	    최초작성
	 * ------------------------------------------------
	 * @param sidecarVOList
	 */
	public void insertAndUpdateSidecar(List<SidecarVO> sidecarVOList);

	/**
	 * <pre>
	 * 처리내용: 사이드카 총 카운트 구한다.
	 * </pre>
	 * @date 2021. 7. 5.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 5.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param sidecarVO
	 * @return
	 */
	public int searchSidecarTotalCnt(SidecarVO sidecarVO);

	public int selectDupSidecar(SidecarVO vo);

	/**
	 * <pre>
	 * 처리내용: 사이드카 내역 목록 조회
	 * </pre>
	 * @date 2022. 9. 7.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 7.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param sidecarVO
	 * @return
	 */
	public List<SidecarVO> searchSidecarDtlList(SidecarVO sidecarVO);

	public int searchSidecarDtlTotalCnt(SidecarVO sidecarVO);
	
}
