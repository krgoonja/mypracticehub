package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.CdtlnManagementVO;
import com.sorincorp.bo.it.model.FtrsFshgVO;


/**
 * CdtlnManagementService.java
 * @version
 * @since 2022. 7. 18.
 * @author srec0061
 */
public interface CdtlnManagementService {

	/**
	 * <pre>
	 * 처리내용: 여신관리 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param cdtlnManagementVO
	 * @return
	 * @throws Exception
	 */
	public List<CdtlnManagementVO> getListCdtlnManagement(CdtlnManagementVO cdtlnManagementVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 여신관리 리스트 카운트를 조회한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param cdtlnManagementVO
	 * @return
	 * @throws Exception
	 */
	public int getListCdtlnManagementCnt(CdtlnManagementVO cdtlnManagementVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 여신관리를 등록한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param cdtlnManagementVO
	 * @throws Exception
	 */
	public void insertCdtlnManagement(CdtlnManagementVO cdtlnManagementVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 여신관리를 수정한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param cdtlnManagementVO
	 * @throws Exception
	 */
	public void updateCdtlnManagement(CdtlnManagementVO cdtlnManagementVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 여신관리 단건을 조회한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param cdtlnManagementVO
	 * @return
	 * @throws Exception
	 */
	public CdtlnManagementVO getCdtlnManagement(CdtlnManagementVO cdtlnManagementVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 여신관리를 삭제한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param cdtlnManagementVO
	 * @throws Exception
	 */
	void deleteCdtlnManagement(CdtlnManagementVO cdtlnManagementVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 데이터 등록여부를 확인한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	boolean isAlreadyRegistered(CdtlnManagementVO vo) throws Exception;

}
