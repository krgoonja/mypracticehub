package com.sorincorp.bo.it.service;

import java.util.ArrayList;
import java.util.List;

import com.sorincorp.bo.it.model.BrandMgrVO;
import com.sorincorp.bo.mb.model.ApprovalReqMbCorpMgrVO;

public interface BrandMgrService {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandMgrVO
	 * @return
	 * @throws Exception
	 */
	List<BrandMgrVO> selectBrandMgrList(BrandMgrVO brandMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandMgrVO
	 * @return
	 * @throws Exception
	 */
	int selectBrandMgrTotalCnt(BrandMgrVO brandMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandMgrVO
	 * @return
	 * @throws Exception
	 */
	List<BrandMgrVO> selectSpecDetailList(BrandMgrVO brandMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandSaveList
	 * @return
	 * @throws Exception
	 */
	int updateBrandData(ArrayList<BrandMgrVO> brandSaveList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 8.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 8.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandSpecSaveList
	 * @return
	 * @throws Exception
	 */
	int saveBrandSpecMgr(ArrayList<BrandMgrVO> brandSpecSaveList) throws Exception;


}
