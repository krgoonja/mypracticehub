package com.sorincorp.bo.it.service;

import java.math.BigDecimal;
import java.util.List;

import com.sorincorp.bo.it.model.MarkupMngVO;
import com.sorincorp.bo.it.model.SpreadVO;
import com.sorincorp.bo.or.model.UnityOrderFtrsVO;

public interface MarkupMngService {
	
	public List<MarkupMngVO> selectMarkUpFtrsList();
	
	public int selectMarkUpFtrsCnt();
	
	public List<MarkupMngVO> selectMarkUpFtrsCompList();
	
	public int selectMarkUpFtrsCompCnt();

	public BigDecimal getTodaySpread(SpreadVO todayVO) throws Exception;
	
	public void updateMarkUpTbl(UnityOrderFtrsVO unitVO) throws Exception;
	
	public int updateMarkupInfo(MarkupMngVO markupVO) throws Exception;
	
	public MarkupMngVO selectMarkupInfo();
	
}
