package com.sorincorp.bo.it.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.ItemMgrMapper;
import com.sorincorp.bo.it.model.ItemMgrVO;
import com.sorincorp.bo.sample.service.SampleService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.itemcode.mapper.ItemCodeMapper;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemweight.mapper.ItemWeightMapper;
import com.sorincorp.comm.itemweight.model.ItemWeightVO;
import com.sorincorp.comm.util.CacheUtil;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.MessageUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ItemMgrServiceImpl implements ItemMgrService {

	@Autowired
	private ItemMgrMapper itemMgrMapper;
	@Autowired
	public FileDocService fileDocService;
	@Autowired
	SampleService sampleService;
	@Autowired
	MessageUtil messageUtil;
	@Autowired
	private UserInfoUtil userInfoUtil;
	@Autowired
	private ItemCodeMapper itemCodeMapper;
	@Autowired
	private ItemWeightMapper itemWeightMapper;
	@Autowired
	private CacheUtil cacheUtil;
	@Autowired
	private CommonService commonService;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 17.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 17.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<ItemMgrVO> selectItemMgrList(ItemMgrVO itemMgrVO) throws Exception {
		// TODO Auto-generated method stub
		return itemMgrMapper.selectItemMgrList(itemMgrVO);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 17.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 17.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int selectItemMgrTotalCnt(ItemMgrVO itemMgrVO) throws Exception {
		// TODO Auto-generated method stub
		return itemMgrMapper.selectItemMgrTotalCnt(itemMgrVO);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 18.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 18.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public ItemMgrVO selectItemMgrDetail(ItemMgrVO itemMgrVO) throws Exception {
		// TODO Auto-generated method stub
		ItemMgrVO vo = itemMgrMapper.selectItemMgrDetail(itemMgrVO);
		String chargerMoblphon = vo.getChargerMoblphon();
		String chargerCttpc = vo.getChargerCttpc();
		String regEx = "(\\d{3})(\\d{3,4})(\\d{4})";
		String regEx2 = "(\\d{2})(\\d{3,4})(\\d{4})";

		//담당자 휴대폰번호 복호화 20220117 srec0030
		if(chargerMoblphon != null && !"".equals(chargerMoblphon)) {
			try {
				log.debug("담당자 휴대폰 복호화 전 =====>" + chargerMoblphon);
				chargerMoblphon = CryptoUtil.decryptAES256(chargerMoblphon);
				log.debug("담당자 휴대폰 복호화 후 =====>" + chargerMoblphon);
				vo.setChargerMoblphon(chargerMoblphon.replaceAll(regEx, "$1-$2-$3"));
			} catch (Exception e) {
				// TODO: handle exception
				log.error("selectItemMgrDetail CHARGER_MOBLPHON CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}

		//담당자 연락처 복호화 20220221 srec0030
		if(chargerCttpc != null && !"".equals(chargerCttpc)) {
			try {
				log.debug("담당자 연락처 복호화 전 =====>" + chargerCttpc);
				chargerCttpc = CryptoUtil.decryptAES256(chargerCttpc);
				log.debug("담당자 연락처 복호화 후 =====>" + chargerCttpc);

				if("02".equals(chargerCttpc.substring(0, 2))) {
					vo.setChargerCttpc(chargerCttpc.replaceAll(regEx2, "$1-$2-$3"));
				} else {
					vo.setChargerCttpc(chargerCttpc.replaceAll(regEx, "$1-$2-$3"));
				}
			} catch (Exception e) {
				// TODO: handle exception
				log.error("selectItemMgrDetail CHARGER_CTTPC CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}

		return vo;
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 18.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 18.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<ItemMgrVO> selectStdSpecList(ItemMgrVO itemMgrVO) throws Exception {
		// TODO Auto-generated method stub
		return itemMgrMapper.selectStdSpecList(itemMgrVO);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 18.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 18.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public ItemMgrVO selectItemCtgry(ItemMgrVO itemMgrVO) throws Exception {
		// TODO Auto-generated method stub
		return itemMgrMapper.selectItemCtgry(itemMgrVO);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 21.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param mRequest
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("finally")
	@Override
	public Map<String, Object> saveAttachFile(MultipartHttpServletRequest mRequest) throws Exception {

		HashMap<String, Object> fileMap = new HashMap<>();
		String errMsg = "";

		try {

			List<FileDocVO> list = new ArrayList<FileDocVO>();
			//list = fileDocService.uploadAttachFilesVoList("IT", mRequest);// 파일 저장
			list = fileDocService.uploadPublicAttachFilesVoList("IT", mRequest);// 파일 저장
			fileMap.put("result", "S");
			fileMap.put("list", list);

		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.toString());
			errMsg = messageUtil.getMessage(e.getMessage());
			fileMap.put("result", "F");
		} finally {
			fileMap.put("errMsg", errMsg);
			return fileMap;
		}
	}

	@SuppressWarnings("finally")
	@Override
	public Map<String, Object> saveAttachFile2(MultipartHttpServletRequest mRequest) throws Exception {

		HashMap<String, Object> fileMap = new HashMap<>();

		List<FileDocVO> list = new ArrayList<FileDocVO>();
		//list = fileDocService.uploadAttachFilesVoList("IT", mRequest);// 파일 저장
		list = fileDocService.uploadPublicAttachFilesVoList("IT", mRequest);// 파일 저장
		fileMap.put("result", "S");
		fileMap.put("fileName", list.get(0).getDocFileNm());
		fileMap.put("fileUrl", list.get(0).getDocFileRealCours());

		return fileMap;
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * 2022. 09. 20.		hyunjin05			구간별 중량 변동금 설정
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int updateItemMgr(ItemMgrVO itemMgrVO) throws Exception {
		// TODO Auto-generated method stub
		ItemMgrVO ctgryVO;
		int result = 0;
		itemMgrVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

		String ctgryNo[] = null;
		String ctgrySn[] = null;

		if(itemMgrVO.getDelCtgrySn() != null && !"".equals(itemMgrVO.getDelCtgrySn())) {
			ctgrySn = itemMgrVO.getDelCtgrySn().split("\\|");

			if(ctgrySn.length > 0) {

				for(int i=0;i<ctgrySn.length;i++) {
					ctgryVO = new ItemMgrVO();

					ctgryVO.setItmSn(itemMgrVO.getItmSn());
					ctgryVO.setCtgrySn(Integer.parseInt(ctgrySn[i]));
					ctgryVO.setFrstRegisterId(itemMgrVO.getLastChangerId());
					ctgryVO.setLastChangerId(itemMgrVO.getLastChangerId());

					itemMgrMapper.deleteItemCtgryRls(ctgryVO);
					//itemMgrMapper.insertItemCtgryRlsHst(ctgryVO.getCtgrySn());
					commonService.insertTableHistory("IT_ITM_CTGRY_RLS", ctgryVO);
				}
			}
		}

		if(itemMgrVO.getRegCtgryNo() != null && !"".equals(itemMgrVO.getRegCtgryNo())) {
			ctgryNo = itemMgrVO.getRegCtgryNo().split("\\|");

			if(ctgryNo.length > 0) {

				for(int i=0;i<ctgryNo.length;i++) {
					ctgryVO = new ItemMgrVO();

					ctgryVO.setItmSn(itemMgrVO.getItmSn());
					ctgryVO.setCtgryNo(ctgryNo[i]);
					ctgryVO.setFrstRegisterId(itemMgrVO.getLastChangerId());
					ctgryVO.setLastChangerId(itemMgrVO.getLastChangerId());

					itemMgrMapper.insertItemCtgryRls(ctgryVO);

					if(ctgryVO.getCtgrySn() > 0) {
						//itemMgrMapper.insertItemCtgryRlsHst(ctgryVO.getCtgrySn());
						commonService.insertTableHistory("IT_ITM_CTGRY_RLS", ctgryVO);
					}
				}
			}
		}

		if("".equals(itemMgrVO.getPcImageOneSn())) {
			itemMgrVO.setPcImageOneSn(null);
		}

		if("".equals(itemMgrVO.getPcImageTwoSn())) {
			itemMgrVO.setPcImageTwoSn(null);
		}

		if("".equals(itemMgrVO.getPcImageThreeSn())) {
			itemMgrVO.setPcImageThreeSn(null);
		}

		if("".equals(itemMgrVO.getPcImageFourSn())) {
			itemMgrVO.setPcImageFourSn(null);
		}

		if("".equals(itemMgrVO.getPcImageFiveSn())) {
			itemMgrVO.setPcImageFiveSn(null);
		}

		itemMgrVO.setChargerCttpc(itemMgrVO.getChargerCttpc().replaceAll("-", ""));;
		itemMgrVO.setChargerMoblphon(itemMgrVO.getChargerMoblphon().replaceAll("-", ""));
		itemMgrVO.setCnsmrCnsltTelno(itemMgrVO.getCnsmrCnsltTelno().replaceAll("-", ""));

		//담당자 휴대폰,연락처 번호 암호화 20220117 srec0030
		String chargerMoblphon = itemMgrVO.getChargerMoblphon();
		String chargerCttpc = itemMgrVO.getChargerCttpc();

		if(chargerMoblphon != null && !"".equals(chargerMoblphon)) {
			try {
				log.debug("담당자 휴대폰 암호화 전 ========> " + chargerMoblphon);
				chargerMoblphon = CryptoUtil.encryptAES256(chargerMoblphon);
				log.debug("담당자 휴대폰 암호화 후 ======> " + chargerMoblphon);
				itemMgrVO.setChargerMoblphon(chargerMoblphon);
			} catch (Exception e) {
				// TODO: handle exception
				log.error("updateItemMgr CHARGER_MOBLPHON CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}

		if(chargerCttpc != null && !"".equals(chargerCttpc)) {
			try {
				log.debug("담당자 연락처 암호화 전 ========> " + chargerCttpc);
				chargerCttpc = CryptoUtil.encryptAES256(chargerCttpc);
				log.debug("담당자 연락처 암호화 후 ======> " + chargerCttpc);
				itemMgrVO.setChargerCttpc(chargerCttpc);
			} catch (Exception e) {
				// TODO: handle exception
				log.error("updateItemMgr CHARGER_CTTPC CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}

		result = itemMgrMapper.updateItemInfoBas(itemMgrVO);
		commonService.insertTableHistory("IT_ITM_INFO_BAS", itemMgrVO);

		ItemCodeVO itemCodeVO = new ItemCodeVO();
		List<ItemCodeVO> itemCodeList = itemCodeMapper.getItemCode(itemCodeVO);
		cacheUtil.put("itemCodeList", itemCodeList);

		ItemWeightVO itemWeightVO = new ItemWeightVO();
		List<ItemWeightVO> itemWeightCodeList = itemWeightMapper.getItemWeightCode(itemWeightVO);
		cacheUtil.put("itemWeightCodeList", itemWeightCodeList);

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param map
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<ItemMgrVO> selectItemCtgryBas(Map<String, Object> map) throws Exception {
		// TODO Auto-generated method stub
		return itemMgrMapper.selectItemCtgryBas(map);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itmSn
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<ItemMgrVO> selectitemCtgryList(int itmSn) throws Exception {
		// TODO Auto-generated method stub
		return itemMgrMapper.selectitemCtgryList(itmSn);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itmSn
	 * @param docNo
	 * @param gubun
	 * @return
	 * @throws Exception
	 */
	@Override
	public int deleteImgFile(int itmSn, String docNo, String gubun) throws Exception {
		// TODO Auto-generated method stub

		int result = 0;
		ItemMgrVO vo = new ItemMgrVO();
		vo.setItmSn(itmSn);
		vo.setLastChangerId(userInfoUtil.getAccountInfo().getId());

		if("PC1".equals(gubun)) {
			vo.setPcImageOneSn(docNo);
		} else if("PC2".equals(gubun)) {
			vo.setPcImageTwoSn(docNo);
		} else if("PC3".equals(gubun)) {
			vo.setPcImageThreeSn(docNo);
		} else if("PC4".equals(gubun)) {
			vo.setPcImageFourSn(docNo);
		} else if("PC5".equals(gubun)) {
			vo.setPcImageFiveSn(docNo);
		}

		fileDocService.deleteCommonDoc(Integer.parseInt(docNo));

		result = itemMgrMapper.deleteImgFile(vo);
		commonService.insertTableHistory("IT_ITM_INFO_BAS", vo);

		return result;
	}

	@Override
	public int updateItemPriorRank(ArrayList<ItemMgrVO> itemSaveList) throws Exception {
		// TODO Auto-generated method stub

		ItemMgrVO itemMgrVO;
		int result = 0;

		for(int i=0;i<itemSaveList.size();i++) {
			itemMgrVO = itemSaveList.get(i);
			itemMgrVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

			result = itemMgrMapper.updateItemPriorRank(itemMgrVO);
			commonService.insertTableHistory("IT_ITM_INFO_BAS", itemMgrVO);
		}

		ItemCodeVO itemCodeVO = new ItemCodeVO();
		List<ItemCodeVO> itemCodeList = itemCodeMapper.getItemCode(itemCodeVO);
		cacheUtil.put("itemCodeList", itemCodeList);

		return result;
	}

}
