package com.sorincorp.bo.it.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.ApplBlSaleManageMapper;
import com.sorincorp.bo.it.model.ApplBlSaleVO;
import com.sorincorp.bo.it.model.ItemInvntrySetupVO;
import com.sorincorp.comm.common.mapper.CommonMapper;
import com.sorincorp.comm.common.service.CommonService;

/**
 * <pre>
 * 처리내용: 지정 BL 판매 데이터를 조회한다.
 * </pre>
 *
 * @date 2022. 12. 1.
 * @auther chajeeman
 * @history ----------------------------------------------- 변경일 작성자 변경내용
 *          ----------------------------------------------- 2022. 12. 1.
 *          chajeeman 최초작성 -----------------------------------------------
 * @param applBlSaleVO
 * @return
 * @throws Exception
 */
@Service
public class ApplBlSaleManageSeviceImpl implements ApplBlSaleManageService {

	@Autowired
	private ApplBlSaleManageMapper applBlSaleManageMapper;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	CommonService commonService;

	@Autowired
	CommonMapper commonMapper;

	@Autowired
	ItemInvntrySetupService itemInvntrySetupService;

	/**
	 * <pre>
	 * 처리내용: 조회조건의 총 카운트 수를 조회한다.
	 * </pre>
	 *
	 * app
	 *
	 * @date 2022. 12. 1.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 1.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param applBlSaleVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int getApplBlSaleManageListTotCnt(ApplBlSaleVO applBlSaleVO) throws Exception {
		return applBlSaleManageMapper.getApplBlSaleManageListTotCnt(applBlSaleVO);
	}

	/**
	 * <pre>
	 * 처리내용: 지정 BL 판매 데이터를 조회한다.
	 * </pre>
	 *
	 * @date 2022. 12. 1.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 1.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param applBlSaleVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<ApplBlSaleVO> getApplBlSaleManageList(ApplBlSaleVO applBlSaleVO) throws Exception {
		return applBlSaleManageMapper.getApplBlSaleManageList(applBlSaleVO);
	}

	@Override
	public ApplBlSaleVO selectApplBlSaleManageData(ApplBlSaleVO searchVO) throws Exception {
		return applBlSaleManageMapper.selectApplBlSaleManageData(searchVO);
	}

	/**
	 * <pre>
	 * 처리내용: 지정 BL 판매 데이터 로우수를 죄회한다.
	 * </pre>
	 *
	 * @date 2022. 12. 1.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 1.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param applBlSaleVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int insertApplBlSaleManageListTotCnt(List<ApplBlSaleVO> applBlSaleVOList) throws Exception {
		int result = 0;
		for (int i = 0; i < applBlSaleVOList.size(); i++) {
			applBlSaleVOList.get(i).setLastChangerId(userInfoUtil.getAccountInfo().getId());
			result += applBlSaleManageMapper.insertApplBlSaleManage(applBlSaleVOList.get(i));
		}
		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 지정 BL 판매 UPDATE 조회한다.(I, D)
	 * </pre>
	 *
	 * @date 2022. 12. 1.
	 * @auther chajeeman
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 1.			chajeeman			최초작성
	 * 2023. 5. 8.			srec0051		지정BL 등록시 체크 로직 추가
	 * -----------------------------------------------
	 * @param applBlSaleVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int updateApplBlSaleManageListTotCnt(List<ApplBlSaleVO> applBlSaleVOList) throws Exception {
		int result = 0;

		for (int i = 0; i < applBlSaleVOList.size(); i++) {
			ApplBlSaleVO applBlSaleVO = applBlSaleVOList.get(i);

			if ("I".equals(applBlSaleVO.getStatus())) {
				// 최초 루프시 잘못된 BL 체크 및 BL 판매중 설정
				if (i == 0) {
					ApplBlSaleVO vo = applBlSaleManageMapper.selectBlInfoBas(applBlSaleVO);
					// 조회 되지 않으면 "없는 BL 번호 입니다"
					if (null == vo) {
						return -99;
					}

					// 지정가 주문 T 미체결 건이 존재하면 등록 불가 (지정 BL 예외 재고 여부 체크 함수에서 정상 BL 일때만 체크)
					if (0 < applBlSaleManageMapper.getCntUnSelLimitOrder(applBlSaleVO)) {
						return -97;
					}

					applBlSaleVO.setSleSttusCode(vo.getSleSttusCode());

					// 판매중(02)가 아닌 경우 판매중 설정
					if (false == applBlSaleVO.getSleSttusCode().equals("02")) {
						ArrayList<ItemInvntrySetupVO> sleSttusCodeList = new ArrayList<>();
						ItemInvntrySetupVO itemInvntrySetupVO = new ItemInvntrySetupVO();

						itemInvntrySetupVO.setBlNo(applBlSaleVO.getBlNo());
						itemInvntrySetupVO.setSleSttusCode("02");
						itemInvntrySetupVO.setSmsAt(applBlSaleVO.getSmsAt());

						sleSttusCodeList.add(itemInvntrySetupVO);

						Map<String, Object> resultMap = itemInvntrySetupService.updateSleSttusCode(sleSttusCodeList);
						int sleImprtyCnt = (int) resultMap.get("sleImprtyCnt");

						if (sleImprtyCnt > 0) {
							// 판매중 설정 실패
							return -98;
						}
					}
				}// end if i == 0

				applBlSaleVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
				result = applBlSaleManageMapper.insertApplBlSaleManage(applBlSaleVO);
				commonService.insertTableHistory("MB_ENTRPS_SPCIFY_BRAND_RLS", applBlSaleVO);

			} else if ("D".equals(applBlSaleVO.getStatus())) {
				applBlSaleVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
				result = applBlSaleManageMapper.updateApplBlSaleManage(applBlSaleVO);
				commonService.insertTableHistory("MB_ENTRPS_SPCIFY_BRAND_RLS", applBlSaleVO);

			} else {
				applBlSaleVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
				// result += applBlSaleManageMapper.deleteApplBlSaleManage(applBlSaleVO);
				// commonService.insertTableHistory("MB_ENTRPS_SPCIFY_BRAND_RLS", applBlSaleVO);
			}
		}// end for

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 지정 BL 판매 DELETE 조회한다.(I, D)
	 * </pre>
	 *
	 * @date 2022. 12. 1.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 1.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param applBlSaleVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int deleteApplBlSaleManageListTotCnt(List<ApplBlSaleVO> applBlSaleVOList) throws Exception {
		int result = 0;
		for (int i = 0; i < applBlSaleVOList.size(); i++) {
			applBlSaleVOList.get(i).setLastChangerId(userInfoUtil.getAccountInfo().getId());
			result += applBlSaleManageMapper.deleteApplBlSaleManage(applBlSaleVOList.get(i));
		}
		return result;
	}

}