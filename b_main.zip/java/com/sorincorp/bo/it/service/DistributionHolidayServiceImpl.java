/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sorincorp.bo.it.service;

import java.util.List;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.it.mapper.DistributionHolidayMapper;
import com.sorincorp.bo.it.mapper.EventHolidayMapper;
import com.sorincorp.bo.it.model.DistributionHolidayVO;
import com.sorincorp.bo.it.model.EventHolidayVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DistributionHolidayServiceImpl implements DistributionHolidayService {

	@Autowired
	private DistributionHolidayMapper distributionHolidayMapper;

	@Override
	public JSONArray getDistributionHolidayList(DistributionHolidayVO distributionHolidayVO) throws Exception {
		List<DistributionHolidayVO> resultList = distributionHolidayMapper.getDistributionHolidayList(distributionHolidayVO);
		JSONArray eventSourcesList = new JSONArray();
		
		for (int i = 0; i < resultList.size(); i++) {
			JSONObject eventData = new JSONObject();
			// 캘린더 데이터
			eventData.put("title", resultList.get(i).getRestdeNm());
			eventData.put("start", resultList.get(i).getApplcDe());
			eventData.put("end", resultList.get(i).getApplcDe());
			
			// 휴일 색상
			eventData.put("backgroundColor", "#F85E38");
			eventData.put("borderColor", "#F85E38");
			eventData.put("textColor", "#fff");
			
			// 이벤트 휴일 데이터
			eventData.put("dstrctNm", resultList.get(i).getDstrctNm());
			eventData.put("wrhousNm", resultList.get(i).getWrhousNm());
			eventData.put("applcDe", resultList.get(i).getApplcDe());
			eventData.put("restedNm", resultList.get(i).getRestdeNm());
			eventData.put("wrhousCode", resultList.get(i).getWrhousCode());
			eventData.put("rm", resultList.get(i).getRm());

			eventSourcesList.put(eventData);
		}
		
		return eventSourcesList;
	}

	@Override
	public List<Map<String, Object>> getDstrctCodeList(DistributionHolidayVO distributionHolidayVO) throws Exception {

		return distributionHolidayMapper.getDstrctCodeList(distributionHolidayVO);
	}

	
}
