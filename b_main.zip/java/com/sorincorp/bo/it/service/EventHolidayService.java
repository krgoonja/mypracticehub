/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sorincorp.bo.it.service;

import java.util.List;

import org.codehaus.jettison.json.JSONArray;

import com.sorincorp.bo.it.model.EventHolidayVO;
import com.sorincorp.bo.it.model.LmeHolidayVO;

/**
 * EventHolidayService.java
 * @version
 * @since 2021. 6. 15.
 * @author srec0008
 */
public interface EventHolidayService {

	/**
	 * <pre>
	 * 이벤트 휴일 목록을 조회한다.
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 15.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param closedHoursVO
	 * @return
	 * @throws Exception
	 */
	public JSONArray getEventHolidayList(EventHolidayVO closedHoursVO) throws Exception;

	/**
	 * <pre>
	 * 이벤트 휴일 관리를 등록한다
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 15.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertEventHoliday(EventHolidayVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 이벤트 휴일 관리를 수정한다.
	 * </pre>
	 * @date 2021. 7. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void updateEventHoliday(EventHolidayVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 이벤트 휴일을 삭제한다
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 15.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void deleteEventHoliday(EventHolidayVO vo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * Nation(국가) 코드 리스트 조회
	 * </pre>
	 * @date 2022. 1. 7.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 7.			srec0054			최초작성
	 * ------------------------------------------------
	 * @return	List<EventHolidayVO>
	 * @throws 	Exception
	 */
	List<EventHolidayVO> getNationCodeList() throws Exception;
	
}
