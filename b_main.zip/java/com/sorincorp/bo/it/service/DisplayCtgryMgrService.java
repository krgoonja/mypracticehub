package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.DisplayCtgryMgrVO;
import com.sorincorp.bo.it.model.ItemMgrVO;

public interface DisplayCtgryMgrService {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 1.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 1.			srec0030			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<DisplayCtgryMgrVO> selectDisplayCtgryList(int ctgryLevel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @return
	 * @throws Exception
	 */
	int updateDisplayCtgryMgr(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @return
	 * @throws Exception
	 */
	int insertCtgryRls(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @return
	 * @throws Exception
	 */
	int deleteCtgryRls(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	List<ItemMgrVO> selectCtgryItemList(ItemMgrVO itemMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @return
	 * @throws Exception
	 */
	int deleteDisplayCtgryMgr(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception;

	boolean isAlreadyRegisteredCtgry(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception ;


}
