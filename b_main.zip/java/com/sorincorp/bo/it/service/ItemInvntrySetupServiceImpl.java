package com.sorincorp.bo.it.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.pcInfo.model.LmePcVO;
import com.sorincorp.comm.pcInfo.model.PrEhgtStdrVO;
import com.sorincorp.comm.pcInfo.model.PrPremiumSelVO;
import com.sorincorp.comm.pcInfo.model.PreminumSelInfoVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.StringUtil;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hpsf.Decimal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.ItemInvntrySetupMapper;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.model.ItemInvntrySetupVO;
import com.sorincorp.bo.it.model.ItemInvntrySmsVO;
import com.sorincorp.bo.or.model.OrOrderBasVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.common.mapper.CommonMapper;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.invntry.service.InvntrySttusService;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.service.CommLimitOrderService;
import com.sorincorp.comm.util.CryptoUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ItemInvntrySetupServiceImpl implements ItemInvntrySetupService {

	@Autowired
	private ItemInvntrySetupMapper itemInvntrySetupMapper;
	@Autowired
	private UserInfoUtil userInfoUtil;
	@Autowired
	private SMSService smsService;
	@Autowired
	private CommLimitOrderService commLimitOrderService;
	@Autowired
	private CommonMapper commonMapper;
	@Autowired
	InvntrySttusService invntrySttusService;
	@Autowired
	private CommonService commonService;
	@Autowired
	private PcInfoService pcInfoService;


	/** 외부 연계 api 호출 모듈 **/
	@Autowired
	private HttpClientHelper httpClientHelper;

	@Value("${erp.url.server}")
	private String erpUrl;

	/** 대쉬드 호출 url **/
	@Value("${order.api.dashboard.url}")
	private String dashboardUrl;

	@Override
	public List<ItemInvntrySetupVO> selectItemInvntrySetupList(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception {
		Map<String, Object> param = new HashMap<>();

		List<String> dstrctMlsfcCodeList = new ArrayList<String>();
		List<String> wrhousCellLcCodeList = new ArrayList<String>();

		if (itemInvntrySetupVO.getDstrctMlsfcCodeArray() != null) {
			for (int i = 0; i < itemInvntrySetupVO.getDstrctMlsfcCodeArray().length; i++) {
				dstrctMlsfcCodeList.add(itemInvntrySetupVO.getDstrctMlsfcCodeArray()[i]);
			}
		}

		if (itemInvntrySetupVO.getWrhousCellLcCodeArray() != null) {
			for (int i = 0; i < itemInvntrySetupVO.getWrhousCellLcCodeArray().length; i++) {
				wrhousCellLcCodeList.add(itemInvntrySetupVO.getWrhousCellLcCodeArray()[i]);
			}
		}

		// 메탈
		param.put("metalCode", itemInvntrySetupVO.getMetalCode());
		// 아이템
		param.put("itmSn", itemInvntrySetupVO.getItmSn());
		// 대분류권역
		param.put("dstrctLclsfCode", itemInvntrySetupVO.getDstrctLclsfCode());
		// 중분류권역
		param.put("dstrctMlsfcCodeList", dstrctMlsfcCodeList);
		// 물류센터
		param.put("wrhousCode", itemInvntrySetupVO.getWrhousCode());
		// 물류센터위치
		param.put("wrhousCellLcCodeList", wrhousCellLcCodeList);
		// 브랜드그룹
		param.put("brandGroupCode", itemInvntrySetupVO.getBrandGroupCode());
		// 브랜드
		param.put("brandCode", itemInvntrySetupVO.getBrandCode());
		// 선물처리여부
		param.put("ftrsProcessAt", itemInvntrySetupVO.getFtrsProcessAt());
		// 판매상태
		param.put("sleSttusCode", itemInvntrySetupVO.getSleSttusCode());
		// B/L NO
		param.put("blNo", itemInvntrySetupVO.getBlNo());
		// 입고구분코드
		param.put("wrhousngSeCode", itemInvntrySetupVO.getWrhousngSeCode());
		// 상품탐색 노출 여부
		param.put("itmSearchShowAt", itemInvntrySetupVO.getItmSearchShowAt());

		return itemInvntrySetupMapper.selectItemInvntrySetupList(param);
	}

	@Override
	public List<ItemInvntrySetupVO> selectEntrpsList(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception {
		List<ItemInvntrySetupVO> entrpsList = itemInvntrySetupMapper.selectEntrpsList(itemInvntrySetupVO);
		return entrpsList;
	}

	@Override
	public ItemInvntrySetupVO saveDummyOrder(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception {
		itemInvntrySetupVO.setOffResultCode("200"); // 정상

		// 미판잔량확인
		ItemInvntrySetupVO nowItemInvntrySetupVO = itemInvntrySetupMapper.selectBlSleInvntryUnsle(itemInvntrySetupVO);

		double offNW = Double.parseDouble(itemInvntrySetupVO.getOffNW());
		double offBD = Double.parseDouble(itemInvntrySetupVO.getOffBD());

		// 주문수량 확인 +-5% 오차범위 허용
		/*
		 * if (offNW > (nowItemInvntrySetupVO.getSleInvntryUnsleBnt() +
		 * (nowItemInvntrySetupVO.getSleInvntryUnsleBnt() * 0.05))) {
		 * itemInvntrySetupVO.setOffResultCode("997"); // 주문수량 부족 return
		 * itemInvntrySetupVO; }
		 * 
		 * if (offBD > nowItemInvntrySetupVO.getSleInvntryUnsleBundleBnt()) {
		 * itemInvntrySetupVO.setOffResultCode("996"); // 주문수량(번들) 부족 return
		 * itemInvntrySetupVO; }
		 */

		// 가상주문 생성
		itemInvntrySetupMapper.callSpEcDummyOrder(itemInvntrySetupVO);

		if (itemInvntrySetupVO.getOffOrderNo() == null) {
			itemInvntrySetupVO.setOffResultCode("999"); // 주문번호 생성 안됨
			return itemInvntrySetupVO;
		} else {// 대시보드 호출
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			Calendar cal = Calendar.getInstance();
			// off 생성주문 날짜가 오늘인 경우
			if (StringUtils.equals((itemInvntrySetupVO.getOffOrderNo()).substring(0, 8), sdf.format(cal.getTime()))) {
				httpClientHelper.getCallApi(dashboardUrl + "/" + itemInvntrySetupVO.getOffOrderNo());
			}
		}

		// 재고차감
		itemInvntrySetupMapper.callSpEcInvntryDdctProcess(itemInvntrySetupVO);

		if (itemInvntrySetupVO.getOffResultCode() == null) {
			itemInvntrySetupVO.setOffResultCode("998"); // 재고 코드 에러
			return itemInvntrySetupVO;
		}

		OrOrderBasVO orOrderBasVO = new OrOrderBasVO();

		// ERP생성
		orOrderBasVO.setCanclExchngRtngudNo(""); // 이커머스 취소교환반품번호
		orOrderBasVO.setTaxBillIsuSeCode("01"); /// 세금 계산서 발행 구분 코드 리스트 01주문 02중량
		orOrderBasVO.setOrderNo(itemInvntrySetupVO.getOffOrderNo()); // 주문번호

		Map<String, Object> responseMap = httpClientHelper.postCallApi(erpUrl + "/ErpGoodsSelng", orOrderBasVO);

		if (responseMap == null) {
			itemInvntrySetupVO.setOffResultCode("995"); // 오프라인 ERP 생성 오류
			return itemInvntrySetupVO;
		}

		return itemInvntrySetupVO;
	}

	@Override
	public ItemInvntrySetupVO selectNewestDummyOrder(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception {

		ItemInvntrySetupVO returnItemInvntrySetupVO = itemInvntrySetupMapper.selectNewestDummyOrder(itemInvntrySetupVO);

		return returnItemInvntrySetupVO;
	}

	@Override
	public List<ItemInvntrySetupVO> selectPopItemInvntrySetupList(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception {
		Map<String, Object> param = new HashMap<>();

		List<String> dstrctMlsfcCodeList = new ArrayList<String>();
		List<String> wrhousCellLcCodeList = new ArrayList<String>();

		if (itemInvntrySetupVO.getDstrctMlsfcCodeArray() != null) {
			for (int i = 0; i < itemInvntrySetupVO.getDstrctMlsfcCodeArray().length; i++) {
				dstrctMlsfcCodeList.add(itemInvntrySetupVO.getDstrctMlsfcCodeArray()[i]);
			}
		}

		if (itemInvntrySetupVO.getWrhousCellLcCodeArray() != null) {
			for (int i = 0; i < itemInvntrySetupVO.getWrhousCellLcCodeArray().length; i++) {
				wrhousCellLcCodeList.add(itemInvntrySetupVO.getWrhousCellLcCodeArray()[i]);
			}
		}

		// 메탈
		param.put("metalCode", itemInvntrySetupVO.getMetalCode());
		// 아이템
		param.put("itmSn", itemInvntrySetupVO.getItmSn());
		// 대분류권역
		param.put("dstrctLclsfCode", itemInvntrySetupVO.getDstrctLclsfCode());
		// 중분류권역
		param.put("dstrctMlsfcCodeList", dstrctMlsfcCodeList);
		// 물류센터
		param.put("wrhousCode", itemInvntrySetupVO.getWrhousCode());
		// 물류센터위치
		param.put("wrhousCellLcCodeList", wrhousCellLcCodeList);
		// 브랜드그룹
		param.put("brandGroupCode", itemInvntrySetupVO.getBrandGroupCode());
		// 브랜드
		param.put("brandCode", itemInvntrySetupVO.getBrandCode());
		// 선물처리여부
		param.put("ftrsProcessAt", itemInvntrySetupVO.getFtrsProcessAt());
		// 판매상태
		param.put("sleSttusCode", itemInvntrySetupVO.getSleSttusCode());
		// B/L NO
		param.put("blNo", itemInvntrySetupVO.getBlNo());

		return itemInvntrySetupMapper.selectPopItemInvntrySetupList(itemInvntrySetupVO);
	}

	/**
	 * <pre>
	 * 처리내용:
	 * </pre>
	 *
	 * @date 2022. 12. 20.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 20.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param itemInvntrySetupVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int selectPopItemInvntrySetupListTotCnt(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception {
		return itemInvntrySetupMapper.selectPopItemInvntrySetupListTotCnt(itemInvntrySetupVO);
	}

	@Override
	public List<ItCmnCodeVO> getWrhousCellLcList(String WrhousCode) throws Exception {
		return itemInvntrySetupMapper.getWrhousCellLcList(WrhousCode);
	}

	@Override
	public Map<String, Object> updateSleSttusCode(ArrayList<ItemInvntrySetupVO> sleSttusCodeList) throws Exception {
		Map<String, Object> resultMap = new HashMap<>();
		ItemInvntrySetupVO itemInvntrySetupVO;
		List<String> itemInvntryList = new ArrayList<String>();

		int result = 0;

		String blNo = "";
		// BL만기경과여부
		String blExpiryYn = "";
		// 선물 만기 -1 여부
		String ftrsExpiryYn = "";
		// 선물환 만기일-2 여부
		String fshgExpiryYn = "";
		// 소수점여부
		String decimalYn = "";
		// 판매상태코드
		String sleSttusCode = "";
		// 선물환 관리번호
//		String fshgManageNo = "";
		// 삼성선물계약번호
//		String ftrsThsexCntrctNo = "";
		// 선물환 관리번호 카운트
//		int fshgManageNoCnt = 0;
		// 통관여부
		String entrAt = "";
		// 판매불가 사유코드
		String sleImprtyResn = "";
		// 선물 최초 수량
		String ftrsDelngLotOrgQy = "";
		// 선물 최초 중량
		String fshgDlryOrgWt = "";
		// 선물환 최초 체결 금액
		String fshgDelngDollarOrgAmount = "";
		// PO BL번호
		String poBlNo = "";
		// 선물사 구분 코드
		String ftrsprofsSeCode = "";
		// 판매불가 건수
		int sleImprtyCnt = 0;
		ItemInvntrySetupVO blSleSttusCodeChgVO;

		int blUpdCnt = 0;

		String smsAt = "";
		String updateFlag = "";
		
		List<String> blNoArr = new ArrayList<>();

		for (int i = 0; i < sleSttusCodeList.size(); i++) {			
			//common 으로 통합, BL 리스트 넘겨서 common 에서 알아서 판매중 처리
			itemInvntrySetupVO = sleSttusCodeList.get(i);
			
			blNo = itemInvntrySetupVO.getBlNo();
			sleSttusCode = itemInvntrySetupVO.getSleSttusCode();
			
			blNoArr.add(blNo);
			
			smsAt = itemInvntrySetupVO.getSmsAt();
			// 기존 판매중 처리 코드 start
//			itemInvntrySetupVO = sleSttusCodeList.get(i);
//
//			blNo = itemInvntrySetupVO.getBlNo();
//			sleSttusCode = itemInvntrySetupVO.getSleSttusCode();
//
//			if ("02".equals(sleSttusCode)) {
//				// 판매중으로 변경일때 판매불가 조건 체크
//				blSleSttusCodeChgVO = itemInvntrySetupMapper.selectBlSleSttusCodeChgData(blNo);
//
//				if (blSleSttusCodeChgVO != null && !"".equals(blSleSttusCodeChgVO.getBlNo())) {
//
//					blNo = blSleSttusCodeChgVO.getBlNo();
//					blExpiryYn = blSleSttusCodeChgVO.getBlExpiryYn();
//					ftrsExpiryYn = blSleSttusCodeChgVO.getFtrsExpiryYn();
//					fshgExpiryYn = blSleSttusCodeChgVO.getFshgExpiryYn();
//					decimalYn = blSleSttusCodeChgVO.getDecimalYn();
//					sleSttusCode = blSleSttusCodeChgVO.getSleSttusCode();
//					entrAt = blSleSttusCodeChgVO.getEntrAt();
//					ftrsDelngLotOrgQy = blSleSttusCodeChgVO.getFtrsDelngLotOrgQy();
//					fshgDlryOrgWt = blSleSttusCodeChgVO.getFshgDlryOrgWt();
//					fshgDelngDollarOrgAmount = blSleSttusCodeChgVO.getFshgDelngDollarOrgAmount();
//					poBlNo = blSleSttusCodeChgVO.getPoBlNo();
//					ftrsprofsSeCode = blSleSttusCodeChgVO.getFtrsprofsSeCode();
//					sleImprtyResn = "";
//
//					// PO 정보 없을 경우 판매불가
//					if (poBlNo == null || "".equals(poBlNo)) {
//						sleImprtyResn = "매입정보 미존재";
//						sleImprtyCnt++;
//						itemInvntrySetupVO.setSleSttusCode("04");
//						itemInvntrySetupVO.setSleImprtyResn(sleImprtyResn);
//					} else {
//						// BL 판매상태코드 04(판매불가)로 업데이트
//						if ("Y".equals(blExpiryYn) || "Y".equals(decimalYn) || !"Y".equals(entrAt) || ftrsDelngLotOrgQy == null || fshgDlryOrgWt == null || fshgDelngDollarOrgAmount == null
//								|| ftrsprofsSeCode == null) {
//							// 만기경과(판매중지) 상태가 아닌 BL만 업데이트
////							if ("Y".equals(blExpiryYn)) {
////								// 만기경과
////								sleImprtyResn += "만기경과";
////							}
//
//							if ("Y".equals(fshgExpiryYn) && "N".equals(ftrsExpiryYn)) {
//								sleImprtyResn += "선물환 만기 도래예정";
//							} else if ("N".equals(fshgExpiryYn) && "Y".equals(ftrsExpiryYn)) {
//								sleImprtyResn += "선물 만기 도래예정";
//							} else if ("Y".equals(ftrsExpiryYn) && "Y".equals(fshgExpiryYn)) {
//								sleImprtyResn += "선물 선물환 만기 도래예정";
//							} else if (ftrsprofsSeCode == null) {
//								sleImprtyResn += "선물사 구분코드 미존재";
//							} else {
//								sleImprtyResn += "강제청산"; // 만기경과
//							}
//
//							if (!"Y".equals(entrAt)) {
//								// 미통관
//								if (!"".equals(sleImprtyResn)) {
//									sleImprtyResn += ",";
//								}
//								sleImprtyResn += "미통관";
//							}
//
//							if ("Y".equals(decimalYn)) {
//								if (!"".equals(sleImprtyResn)) {
//									sleImprtyResn += ",";
//								}
//								// 선물환달러금액/선물환배부중량 나머지 소수점
//								sleImprtyResn += "선물환달러금액/선물환배부중량 나머지 소수점";
//							}
//
//							if ("".equals(ftrsDelngLotOrgQy) || ftrsDelngLotOrgQy == null) {
//								if (!"".equals(sleImprtyResn)) {
//									sleImprtyResn += ",";
//								}
//								sleImprtyResn += "선물 최초 수량정보 미존재";
//							}
//
//							if ("".equals(fshgDlryOrgWt) || fshgDlryOrgWt == null) {
//								if (!"".equals(sleImprtyResn)) {
//									sleImprtyResn += ",";
//								}
//								sleImprtyResn += "선물 최초 중량정보 미존재";
//							}
//
//							if ("".equals(fshgDelngDollarOrgAmount) || fshgDelngDollarOrgAmount == null) {
//								if (!"".equals(sleImprtyResn)) {
//									sleImprtyResn += ",";
//								}
//								sleImprtyResn += "선물환 최초 체결 금액정보 미존재";
//							}
//
//							sleImprtyCnt++;
//							itemInvntrySetupVO.setSleSttusCode("04");
//							itemInvntrySetupVO.setSleImprtyResn(sleImprtyResn);
//						}
//					}
//				}
//			} else if (!"05".equals(sleSttusCode)) {
//				itemInvntrySetupVO.setSleImprtyResn(null);
//			}
//
//			itemInvntrySetupVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
//			result = itemInvntrySetupMapper.updateSleSttusCode(itemInvntrySetupVO);
//			blUpdCnt += result;
////			itemInvntrySetupMapper.insertItBlInfoBasHst(itemInvntrySetupVO);
//			//commonMapper.insertItBlInfoBasHst(itemInvntrySetupVO.getBlNo());
//			commonService.insertTableHistory("IT_BL_INFO_BAS", itemInvntrySetupVO);
//
//			smsAt = itemInvntrySetupVO.getSmsAt();
//			// BL기준 데이터를 조회해서 List에 넣기
//			updateFlag = itemInvntrySetupVO.getSleSttusCode();
//
//			if (updateFlag.equals("02")) {
//				if (smsAt.equals("Y")) {
//					itemInvntryList.add(itemInvntrySetupVO.getBlNo());
//				}
//			}
//			
//			//BL 판매상태(판매중)이 아닐 경우 지정가 주문 취소 처리 - 2023-10-26
//			if(!itemInvntrySetupVO.getSleSttusCode().equals("02")) {
//				ItemInvntrySetupVO vo = new ItemInvntrySetupVO();
//				//blNo로 정보 조회
//				vo = itemInvntrySetupMapper.selectItemInvntrySetupInfo(itemInvntrySetupVO);
//				//최적BL 탐색 후 지정가 주문 취소처리
//				commLimitOrderService.getBlInvtry(vo.getMetalCode(), vo.getDstrctLclsfCode(), Integer.parseInt(vo.getItmSn()), vo.getBrandGroupCode()
//											, vo.getBrandCode(), "01", vo.getSleUnitWt()/1000, vo.getSleUnitWt()/1000, vo.getOnceSlePossWt()
//											, "", "Y");
//			}
			
		}
		
		// common 에 list 보내기
		itemInvntryList = commonService.blSleSttusCodeChgSel(blNoArr, sleSttusCode, userInfoUtil.getAccountInfo().getId());

//		if (blUpdCnt > 0) {
//			// 20230710 srec0030 실시간 재고잔량 체크 메소드 호출
//			invntrySttusService.invntrySttusMsgPublish();
//		}

		// BL기준 조회된 데이터 List를 넘기기
		log.debug("updateFlag ========>" + updateFlag);
		log.debug("smsAt      ========>" + smsAt);
		if (updateFlag.equals("02")) {
			if (smsAt.equals("Y")) {
				itemInvntrySmsSndng(itemInvntryList);
			}
		}
		
		if (itemInvntryList.size() > 0) {
			sleImprtyCnt = (blNoArr.size() - itemInvntryList.size()); 
		}
		
		resultMap.put("result", itemInvntryList.size());
		resultMap.put("sleImprtyCnt", sleImprtyCnt);
		return resultMap;
	}

	@Override
	public void itemInvntrySmsSndng(List<String> blList) throws Exception {
		// 입고알림템플릿 번호
		int msgTmplat = 58; // 메세지템플릿 번호

		// 조회 param
		Map<String, Object> param = new HashMap<>();
		param.put("blList", blList);

		// 판매품목 정보 조회
		List<ItemInvntrySmsVO> itemInvntrySmsList = itemInvntrySetupMapper.selectItemInvntrySmsList(param);

		// 문자메시지 대상리스트
		List<ItemInvntrySmsVO> memberList = itemInvntrySetupMapper.selectMetalSmsMberList(); // 마케팅 동의 회원의 관심금속 별 발송 목록

		Map<String, String> map = new HashedMap<>();
		map.put("templateNum", String.valueOf(msgTmplat)); // 템플릿 seq
		map.put("mainPageUrl", CommonConstants.MAIN_SALES_PAGE_URL); // 케이지트레이딩 사이트 링크

		SMSVO sms = new SMSVO();
		for (ItemInvntrySmsVO itemInvntrySms : itemInvntrySmsList) {
			for (ItemInvntrySmsVO member : memberList) {
				if (itemInvntrySms.getMetalCode().equals(member.getMetalCode())) {

//					map.put("METAL", itemInvntrySms.getMetalName());
//					map.put("BRAND", itemInvntrySms.getMetalBrand());
//
//					sms.setPhone(CryptoUtil.decryptAES256(member.getMoblphonNo()));
//					log.debug("sms.getPhone =========>" + sms.getPhone());
//					smsService.insertSMS(sms, map);

					// 20221215 srec0030 판매방식 적용
					if ("Y".equals(itemInvntrySms.getFixingPcAt()) && "Y".equals(member.getFixingPcAt())) {
						// BL Item 판매방식 고정가이고 업체 금속설정의 판매방식이 고정가 Y
						map.put("METAL", itemInvntrySms.getMetalName());
						map.put("BRAND", itemInvntrySms.getMetalBrand());

						sms.setPhone(CryptoUtil.decryptAES256(member.getMoblphonNo()));
						log.debug("FixingPcAt sms.getPhone =========>" + sms.getPhone());
						smsService.insertSMS(sms, map);
					} else if ("Y".equals(itemInvntrySms.getLivePcAt()) && "Y".equals(member.getLivePcAt())) {
						// BL Item 판매방식 실시간이고 업체 금속설정의 판매방식이 실시간 Y
						map.put("METAL", itemInvntrySms.getMetalName());
						map.put("BRAND", itemInvntrySms.getMetalBrand());

						sms.setPhone(CryptoUtil.decryptAES256(member.getMoblphonNo()));
						log.debug("LivePcAt sms.getPhone =========>" + sms.getPhone());
						smsService.insertSMS(sms, map);
					}
				}
			}
		}
	}

	@Override
	public int updateSleSetupBundleCo(ArrayList<ItemInvntrySetupVO> sleSetupBundleCoSaveList) throws Exception {
		ItemInvntrySetupVO itemInvntrySetupVO;
		int result = 0;

		String blNo = "";
		int sleSetupBundleCo = 0;
		double avrgWt = 0;
		double sleSetupWt = 0;
		double sleInvntryUnsleBnt = 0;
		int sleInvntryUnsleBundleBnt = 0;
		double ecAsgnBntInvntry = 0; // 할당잔량
		int ecAsgnBntBundleInvntry = 0; // 할당잔량(번들)
		double ecSleComptInvntry = 0;
		int ecSleComptBundleInvntry = 0;
		
		int smlqySleSetupBundleCo = 0; // 소량 판매 설정 번들 수
		double smlqySleSetupWt = 0; // 소량 판매 설정 중량
	    double smlqySleInvntryUnsleBnt = 0; // 소량 판매 재고 미판매 잔량
	    int smlqySleInvntryUnsleBundleBnt = 0; // 소량 판매 재고 미판매 번들 잔량
	    double smlqyEcSleComptInvntry = 0; // 소량 EC 판매 완료 재고
	    int smlqyEcSleComptBundleInvntry = 0; // 소량 EC 판매 완료 번들 재고
	    String smlqySleFtrsAt = ""; // 소량 판매 선물 여부
		
	    double bsisWrhousngInvntry = 0; // 기초 입고 재고
	    int bsisWrhousngBundleInvntry = 0; // 기초 입고 번들 재고
	    double bsisMaliciousBadnInvntry = 0; // 기초 악성 불량 재고
	    int bsisMaliciousBadnBundleInvntry = 0; // 기초 악성 불량 번들 재고
	    
		double wrhousSleUnsetupInvntry = 0;
		int wrhousSleUnsetupBundleInvntry = 0;
		//double wrhousNootgInvntry = 0;
		//int wrhousNootgBundleInvntry = 0;
		//double ecNootgInvntry = 0;
		//int ecNootgBundleInvntry = 0;
		double trmendInvntry = 0;
		int trmendBundleInvntry = 0;

		int blSleSetupChgCnt = 0;
		int blUpdCnt = 0;

		for (int i = 0; i < sleSetupBundleCoSaveList.size(); i++) {
			itemInvntrySetupVO = sleSetupBundleCoSaveList.get(i);

			blNo = itemInvntrySetupVO.getBlNo();
			sleSetupBundleCo = itemInvntrySetupVO.getSleSetupBundleCo();
			smlqySleSetupBundleCo = itemInvntrySetupVO.getSmlqySleSetupBundleCo(); // 소량 판매 설정 번들 수
			smlqySleFtrsAt = itemInvntrySetupVO.getSmlqySleFtrsAt(); // 소량 판매 선물 여부

			itemInvntrySetupVO = itemInvntrySetupMapper.selectBlInfoBas(blNo);

			// sleSetupWt = itemInvntrySetupVO.getSleSetupWt();
			avrgWt = itemInvntrySetupVO.getNetAvrgWt();
			// 판매설정중량 = 평균중량 * 판매설정 번들 수
			sleSetupWt = avrgWt * sleSetupBundleCo;
			// 미판매잔량 = 판매설정중량 - (할당잔량 + 판매완료)
			ecAsgnBntInvntry = itemInvntrySetupVO.getEcAsgnBntInvntry(); // 할당잔량
			ecSleComptInvntry = itemInvntrySetupVO.getEcSleComptInvntry();
			sleInvntryUnsleBnt = sleSetupWt - (ecAsgnBntInvntry + ecSleComptInvntry);
			ecAsgnBntBundleInvntry = itemInvntrySetupVO.getEcAsgnBntBundleInvntry(); // 할당잔량(번들)
			ecSleComptBundleInvntry = itemInvntrySetupVO.getEcSleComptBundleInvntry();
			sleInvntryUnsleBundleBnt = sleSetupBundleCo - (ecAsgnBntBundleInvntry + ecSleComptBundleInvntry);
			
			bsisWrhousngInvntry = itemInvntrySetupVO.getBsisWrhousngInvntry(); // 기초 입고 재고
			bsisWrhousngBundleInvntry = itemInvntrySetupVO.getBsisWrhousngBundleInvntry(); // 기초 입고 번들 재고
			bsisMaliciousBadnInvntry = itemInvntrySetupVO.getBsisMaliciousBadnInvntry(); // 기초 악성 불량 재고
			bsisMaliciousBadnBundleInvntry = itemInvntrySetupVO.getBsisMaliciousBadnBundleInvntry(); // 기초 악성 불량 번들 재고
			
			// 소량구매 판매 관련 start
			smlqySleSetupWt = avrgWt * smlqySleSetupBundleCo; // 소량 판매 설정 중량 (평균중량 * 소량 판매 설정 번들 수)
			smlqyEcSleComptInvntry = itemInvntrySetupVO.getSmlqyEcSleComptInvntry(); // 소량 EC 판매 완료 재고
			smlqyEcSleComptBundleInvntry = itemInvntrySetupVO.getSmlqyEcSleComptBundleInvntry(); // 소량 EC 판매 완료 번들 재고
			smlqySleInvntryUnsleBnt = smlqySleSetupWt - smlqyEcSleComptInvntry; // 소량 판매 재고 미판매 잔량 (소량 판매 설정 중량 - 소량 EC 판매 완료 재고)
		    smlqySleInvntryUnsleBundleBnt = smlqySleSetupBundleCo - smlqyEcSleComptBundleInvntry; // 소량 판매 재고 미판매 번들 잔량 (소량 판매 설정 번들 수 - 소량 EC 판매 완료 번들 재고)
			// 소량구매 판매 관련 end

			// 물류판매미설정재고 = 미출고재고 - 미판매잔량 - 미출고, 2024-06-10 계산식 폐기, 재고 설정에서만 잘못 계산하고 있음
			//wrhousNootgInvntry = itemInvntrySetupVO.getWrhousNootgInvntry();
			//ecNootgInvntry = itemInvntrySetupVO.getEcNootgInvntry();
			//wrhousSleUnsetupInvntry = wrhousNootgInvntry - sleInvntryUnsleBnt - smlqySleInvntryUnsleBnt - ecNootgInvntry; // 물류센터 미출고 재고 - 미판잔량 중량 - 소량 판매 재고 미판매 잔량 - 미출고/배송 잔량, 2024-06-10 계산식 폐기, 재고 설정에서만 잘못 계산하고 있음
		    
		    wrhousSleUnsetupInvntry = bsisWrhousngInvntry - bsisMaliciousBadnInvntry - sleSetupWt - smlqySleSetupWt; // 물류판매미설정재고 = 기초 입고 재고 - 기초 악성 불량 재고 - 판매설정중량 - 소량 판매 설정 중량
			
		    //wrhousNootgBundleInvntry = itemInvntrySetupVO.getWrhousNootgBundleInvntry();
			// wrhousSleUnsetupInvntry = Math.round(wrhousSleUnsetupInvntry*1000)/1000.0;
			//ecNootgBundleInvntry = itemInvntrySetupVO.getEcNootgBundleInvntry();
			//wrhousSleUnsetupBundleInvntry = wrhousNootgBundleInvntry - sleInvntryUnsleBundleBnt - smlqySleInvntryUnsleBundleBnt - ecNootgBundleInvntry; // 물류센터 미출고 번들 재고 - 미판잔량 번들 - 소량 판매 재고 미판매 번들 잔량 - 미출고/배송 번들 잔량, 2024-06-10 계산식 폐기, 재고 설정에서만 잘못 계산하고 있음
			
		    wrhousSleUnsetupBundleInvntry = bsisWrhousngBundleInvntry - bsisMaliciousBadnBundleInvntry - sleSetupBundleCo - smlqySleSetupBundleCo; // 물류판매미설정번들재고 = 기초 입고 번들 재고 - 기초 악성 불량 번들 재고 - 판매 설정 번들 수 - 소량 판매 설정 번들 수

			// 기말재고 중량 = 미판잔량 중량 + 소량 판매 재고 미판매 잔량 + 물류센터 판매 미설정재고 중량
			trmendInvntry = sleInvntryUnsleBnt + smlqySleInvntryUnsleBnt + wrhousSleUnsetupInvntry;
			// 기말재고 번들 = 미판잔량 번들 + 소량 판매 재고 미판매 번들 잔량 + 물류센터 판매 미설정재고 번들
			trmendBundleInvntry = sleInvntryUnsleBundleBnt + smlqySleInvntryUnsleBundleBnt + wrhousSleUnsetupBundleInvntry;

			// 판매설정 번들수
			itemInvntrySetupVO.setSleSetupBundleCo(sleSetupBundleCo);
			// 판매설정중량
			itemInvntrySetupVO.setSleSetupWt(sleSetupWt);
			// 미판잔량 중량
			itemInvntrySetupVO.setSleInvntryUnsleBnt(sleInvntryUnsleBnt);
			// 미판잔량 번들
			itemInvntrySetupVO.setSleInvntryUnsleBundleBnt(sleInvntryUnsleBundleBnt);
			
			// 소량 판매 설정 번들 수
			itemInvntrySetupVO.setSmlqySleSetupBundleCo(smlqySleSetupBundleCo);
			// 소량 판매 설정 중량
			itemInvntrySetupVO.setSmlqySleSetupWt(smlqySleSetupWt);
			// 소량 판매 재고 미판매 잔량
			itemInvntrySetupVO.setSmlqySleInvntryUnsleBnt(smlqySleInvntryUnsleBnt);
			// 소량 판매 재고 미판매 번들 잔량
			itemInvntrySetupVO.setSmlqySleInvntryUnsleBundleBnt(smlqySleInvntryUnsleBundleBnt);
			// 소량 판매 선물 여부
			itemInvntrySetupVO.setSmlqySleFtrsAt(smlqySleFtrsAt);
			
			// 물류센터 판매 미설정재고 중량
			itemInvntrySetupVO.setWrhousSleUnsetupInvntry(wrhousSleUnsetupInvntry);
			// 물류센터 판매 미설정재고 번들
			itemInvntrySetupVO.setWrhousSleUnsetupBundleInvntry(wrhousSleUnsetupBundleInvntry);
			// 기말재고 중량
			itemInvntrySetupVO.setTrmendInvntry(trmendInvntry);
			// 기말재고 번들
			itemInvntrySetupVO.setTrmendBundleInvntry(trmendBundleInvntry);
			// 변경자 아이디
			itemInvntrySetupVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

			Map<String, Object> param = new HashMap<>();

			param.put("blNo", blNo);
			param.put("sleSetupBundleCo", sleSetupBundleCo);
			param.put("sleSetupWt", sleSetupWt);
			param.put("sleInvntryUnsleBnt", sleInvntryUnsleBnt);
			param.put("sleInvntryUnsleBundleBnt", sleInvntryUnsleBundleBnt);
			
			param.put("smlqySleSetupBundleCo", smlqySleSetupBundleCo);
			param.put("smlqySleSetupWt", smlqySleSetupWt);
			param.put("smlqySleInvntryUnsleBnt", smlqySleInvntryUnsleBnt);
			param.put("smlqySleInvntryUnsleBundleBnt", smlqySleInvntryUnsleBundleBnt);
			param.put("smlqySleFtrsAt", smlqySleFtrsAt);
			
			param.put("wrhousSleUnsetupInvntry", wrhousSleUnsetupInvntry);
			param.put("wrhousSleUnsetupBundleInvntry", wrhousSleUnsetupBundleInvntry);
			param.put("trmendInvntry", trmendInvntry);
			param.put("trmendBundleInvntry", trmendBundleInvntry);
			param.put("lastChangerId", userInfoUtil.getAccountInfo().getId());
			// log.debug(param.toString());
			// BL 정보 update
			result = itemInvntrySetupMapper.updateSleSetupBundleCo(param);
			blUpdCnt += result;
			// BL 이력
//			itemInvntrySetupMapper.insertItBlInfoBasHst(itemInvntrySetupVO);
			//commonMapper.insertItBlInfoBasHst(itemInvntrySetupVO.getBlNo());
			commonService.insertTableHistory("IT_BL_INFO_BAS", itemInvntrySetupVO);
			// BL 이력 이벤트 유형 코드 05: 판매설정, 06: 판매설정변경
			blSleSetupChgCnt = itemInvntrySetupMapper.selectBlSleSetupChgCnt(itemInvntrySetupVO);

			if (blSleSetupChgCnt < 1) {
				// 이벤트유형 05(판매설정)이 없는 경우 05(판매설정으로 세팅)
				itemInvntrySetupVO.setBlHistEventTyCode("05");
			} else {
				// 이벤트유형 05(판매설정)이 있는 경우 06(판매설정변경으로 세팅)
				itemInvntrySetupVO.setBlHistEventTyCode("06");
			}
			itemInvntrySetupMapper.insertItBlInfoHistDtl(itemInvntrySetupVO);
		}

		if (blUpdCnt > 0) {
			// 20230710 srec0030 실시간 재고잔량 체크 메소드 호출
			invntrySttusService.invntrySttusMsgPublish();
		}

		return result;
	}

	@Override
	public List<ItemInvntrySetupVO> calcSetupData(ArrayList<ItemInvntrySetupVO> sleSetupBundleCoSaveList) throws Exception {
		ItemInvntrySetupVO itemInvntrySetupVO;
		List<ItemInvntrySetupVO> calcDataList = new ArrayList<>();

		String blNo = "";
		double avrgWt = 0;
		
		int sleSetupBundleCo = 0;
		double sleSetupWt = 0;
		double sleInvntryUnsleBnt = 0;
		int sleInvntryUnsleBundleBnt = 0;
		double ecAsgnBntInvntry = 0; // 할당잔량
		int ecAsgnBntBundleInvntry = 0; // 할당잔량(번들)
		double ecSleComptInvntry = 0;
		int ecSleComptBundleInvntry = 0;
		
		int smlqySleSetupBundleCo = 0; // 소량 판매 설정 번들 수
		double smlqySleSetupWt = 0; // 소량 판매 설정 중량
	    double smlqySleInvntryUnsleBnt = 0; // 소량 판매 재고 미판매 잔량
	    int smlqySleInvntryUnsleBundleBnt = 0; // 소량 판매 재고 미판매 번들 잔량
	    double smlqyEcSleComptInvntry = 0; // 소량 EC 판매 완료 재고
	    int smlqyEcSleComptBundleInvntry = 0; // 소량 EC 판매 완료 번들 재고
		
	    double bsisWrhousngInvntry = 0; // 기초 입고 재고
	    int bsisWrhousngBundleInvntry = 0; // 기초 입고 번들 재고
	    double bsisMaliciousBadnInvntry = 0; // 기초 악성 불량 재고
	    int bsisMaliciousBadnBundleInvntry = 0; // 기초 악성 불량 번들 재고
	    
		double wrhousSleUnsetupInvntry = 0;
		int wrhousSleUnsetupBundleInvntry = 0;
		//double wrhousNootgInvntry = 0;
		//int wrhousNootgBundleInvntry = 0;
		//double ecNootgInvntry = 0;
		//int ecNootgBundleInvntry = 0;
		double trmendInvntry = 0;
		int trmendBundleInvntry = 0;

		for (int i = 0; i < sleSetupBundleCoSaveList.size(); i++) {
			itemInvntrySetupVO = sleSetupBundleCoSaveList.get(i);

			blNo = itemInvntrySetupVO.getBlNo();
			sleSetupBundleCo = itemInvntrySetupVO.getSleSetupBundleCo();
			smlqySleSetupBundleCo = itemInvntrySetupVO.getSmlqySleSetupBundleCo(); // 소량 판매 설정 번들 수

			itemInvntrySetupVO = itemInvntrySetupMapper.selectBlInfoBas(blNo);

			// sleSetupWt = itemInvntrySetupVO.getSleSetupWt();
			avrgWt = itemInvntrySetupVO.getNetAvrgWt();
			
			// 판매설정중량 = 평균중량 * 판매설정 번들 수
			sleSetupWt = avrgWt * sleSetupBundleCo;
			// 미판매잔량 = 판매설정중량 - (할당잔량 + 판매완료)
			ecAsgnBntInvntry = itemInvntrySetupVO.getEcAsgnBntInvntry(); // 할당잔량
			ecSleComptInvntry = itemInvntrySetupVO.getEcSleComptInvntry();
			sleInvntryUnsleBnt = sleSetupWt - (ecAsgnBntInvntry + ecSleComptInvntry); // 미판잔량 중량
			ecAsgnBntBundleInvntry = itemInvntrySetupVO.getEcAsgnBntBundleInvntry(); // 할당잔량(번들)
			ecSleComptBundleInvntry = itemInvntrySetupVO.getEcSleComptBundleInvntry();
			sleInvntryUnsleBundleBnt = sleSetupBundleCo - (ecAsgnBntBundleInvntry + ecSleComptBundleInvntry); // 미판잔량 번들
			
			bsisWrhousngInvntry = itemInvntrySetupVO.getBsisWrhousngInvntry(); // 기초 입고 재고
			bsisWrhousngBundleInvntry = itemInvntrySetupVO.getBsisWrhousngBundleInvntry(); // 기초 입고 번들 재고
			bsisMaliciousBadnInvntry = itemInvntrySetupVO.getBsisMaliciousBadnInvntry(); // 기초 악성 불량 재고
			bsisMaliciousBadnBundleInvntry = itemInvntrySetupVO.getBsisMaliciousBadnBundleInvntry(); // 기초 악성 불량 번들 재고
			
			// 소량구매 판매 관련 start
			smlqySleSetupWt = avrgWt * smlqySleSetupBundleCo; // 소량 판매 설정 중량 (평균중량 * 소량 판매 설정 번들 수)
			smlqyEcSleComptInvntry = itemInvntrySetupVO.getSmlqyEcSleComptInvntry(); // 소량 EC 판매 완료 재고
			smlqyEcSleComptBundleInvntry = itemInvntrySetupVO.getSmlqyEcSleComptBundleInvntry(); // 소량 EC 판매 완료 번들 재고
			smlqySleInvntryUnsleBnt = smlqySleSetupWt - smlqyEcSleComptInvntry; // 소량 판매 재고 미판매 잔량 (소량 판매 설정 중량 - 소량 EC 판매 완료 재고)
		    smlqySleInvntryUnsleBundleBnt = smlqySleSetupBundleCo - smlqyEcSleComptBundleInvntry; // 소량 판매 재고 미판매 번들 잔량 (소량 판매 설정 번들 수 - 소량 EC 판매 완료 번들 재고)
			// 소량구매 판매 관련 end

			// 물류판매미설정재고 = 미출고재고 - 미판매잔량 - 미출고, 2024-06-10 계산식 폐기, 재고 설정에서만 잘못 계산하고 있음
			//wrhousNootgInvntry = itemInvntrySetupVO.getWrhousNootgInvntry(); // 물류센터 미출고 재고
			//ecNootgInvntry = itemInvntrySetupVO.getEcNootgInvntry(); // 미출고/배송 잔량
			//wrhousSleUnsetupInvntry = wrhousNootgInvntry - sleInvntryUnsleBnt - smlqySleInvntryUnsleBnt - ecNootgInvntry; // 물류센터 미출고 재고 - 미판잔량 중량 - 소량 판매 재고 미판매 잔량 - 미출고/배송 잔량, 2024-06-10 계산식 폐기, 재고 설정에서만 잘못 계산하고 있음
			
			wrhousSleUnsetupInvntry = bsisWrhousngInvntry - bsisMaliciousBadnInvntry - sleSetupWt - smlqySleSetupWt; // 물류판매미설정재고 = 기초 입고 재고 - 기초 악성 불량 재고 - 판매설정중량 - 소량 판매 설정 중량
			
			//wrhousNootgBundleInvntry = itemInvntrySetupVO.getWrhousNootgBundleInvntry(); // 물류센터 미출고 번들 재고
			//ecNootgBundleInvntry = itemInvntrySetupVO.getEcNootgBundleInvntry(); // 미출고/배송 번들 잔량
			//wrhousSleUnsetupBundleInvntry = wrhousNootgBundleInvntry - sleInvntryUnsleBundleBnt - smlqySleInvntryUnsleBundleBnt - ecNootgBundleInvntry; // 물류센터 미출고 번들 재고 - 미판잔량 번들 - 소량 판매 재고 미판매 번들 잔량 - 미출고/배송 번들 잔량, 2024-06-10 계산식 폐기, 재고 설정에서만 잘못 계산하고 있음
			
			wrhousSleUnsetupBundleInvntry = bsisWrhousngBundleInvntry - bsisMaliciousBadnBundleInvntry - sleSetupBundleCo - smlqySleSetupBundleCo; // 물류판매미설정번들재고 = 기초 입고 번들 재고 - 기초 악성 불량 번들 재고 - 판매 설정 번들 수 - 소량 판매 설정 번들 수

			// 기말재고 중량 = 미판잔량 중량 + 소량 판매 재고 미판매 잔량 + 물류센터 판매 미설정재고 중량
			trmendInvntry = sleInvntryUnsleBnt + smlqySleInvntryUnsleBnt + wrhousSleUnsetupInvntry;
			// 기말재고 번들 = 미판잔량 번들 + 소량 판매 재고 미판매 번들 잔량 + 물류센터 판매 미설정재고 번들
			trmendBundleInvntry = sleInvntryUnsleBundleBnt + smlqySleInvntryUnsleBundleBnt + wrhousSleUnsetupBundleInvntry;

			// 판매설정 번들수
			itemInvntrySetupVO.setSleSetupBundleCo(sleSetupBundleCo);
			// 판매설정중량
			itemInvntrySetupVO.setSleSetupWt(sleSetupWt);
			// 미판잔량 중량
			itemInvntrySetupVO.setSleInvntryUnsleBnt(sleInvntryUnsleBnt);
			// 미판잔량 번들
			itemInvntrySetupVO.setSleInvntryUnsleBundleBnt(sleInvntryUnsleBundleBnt);
			
			// 소량 판매 설정 번들 수
			itemInvntrySetupVO.setSmlqySleSetupBundleCo(smlqySleSetupBundleCo);
			// 소량 판매 설정 중량
			itemInvntrySetupVO.setSmlqySleSetupWt(smlqySleSetupWt);
			// 소량 판매 설정 중량
			itemInvntrySetupVO.setSmlqySleInvntryUnsleBnt(smlqySleInvntryUnsleBnt);
			// 소량 판매 재고 미판매 번들 잔량
			itemInvntrySetupVO.setSmlqySleInvntryUnsleBundleBnt(smlqySleInvntryUnsleBundleBnt);
			
			// 물류센터 판매 미설정재고 중량
			itemInvntrySetupVO.setWrhousSleUnsetupInvntry(wrhousSleUnsetupInvntry);
			// 물류센터 판매 미설정재고 번들
			itemInvntrySetupVO.setWrhousSleUnsetupBundleInvntry(wrhousSleUnsetupBundleInvntry);
			// 기말재고 중량
			itemInvntrySetupVO.setTrmendInvntry(trmendInvntry);
			// 기말재고 번들
			itemInvntrySetupVO.setTrmendBundleInvntry(trmendBundleInvntry);

			calcDataList.add(itemInvntrySetupVO);
		}

		return calcDataList;
	}

	@Override
	public List<ItemInvntrySetupVO> selectItemSclptrList(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception {
		Map<String, Object> param = new HashMap<>();
		Map<String, Object> lmeCashList = new HashMap<>();	//메탈별 lme가격
		List<PrPremiumSelVO> chartTitleInfoByRedisDataList = new ArrayList<>();//차트 판매 가격
		List<PrPremiumSelVO> selPcList = new ArrayList<>();	//메탈,브랜드,브랜드그룹별 판매가격

		BigDecimal redisEhgtEndPc = null;	// 실시간 거래용 환율
		List<String> metalCodeList = null;	// 판매 메탈 코드 리스트

		List<String> dstrctMlsfcCodeList = new ArrayList<String>();
		List<String> wrhousCellLcCodeList = new ArrayList<String>();

		if (itemInvntrySetupVO.getDstrctMlsfcCodeArray() != null) {
			for (int i = 0; i < itemInvntrySetupVO.getDstrctMlsfcCodeArray().length; i++) {
				dstrctMlsfcCodeList.add(itemInvntrySetupVO.getDstrctMlsfcCodeArray()[i]);
			}
		}

		if (itemInvntrySetupVO.getWrhousCellLcCodeArray() != null) {
			for (int i = 0; i < itemInvntrySetupVO.getWrhousCellLcCodeArray().length; i++) {
				wrhousCellLcCodeList.add(itemInvntrySetupVO.getWrhousCellLcCodeArray()[i]);
			}
		}

		// 메탈별 실시간 lme cash
		lmeCashList = itemInvntrySetupVO.getRedisLmeEndPc();
		metalCodeList = itemInvntrySetupVO.getMetalCodeList();

		if(lmeCashList.isEmpty() || lmeCashList.size() !=  metalCodeList.size()){
			for (String metalCode : metalCodeList) {
				// 메탈별 실시간 LME 가격이 없을 경우 전일 종가 조회
				if (!lmeCashList.containsKey(metalCode)) {
					LmePcVO lmeVo = pcInfoService.getPrLmeAgo(metalCode);
					lmeCashList.put(metalCode, lmeVo.getEndPc());
				}
			}
		}
		for (String metalCode : metalCodeList) {
			chartTitleInfoByRedisDataList = new ArrayList<>();
			// 메탈별 실시간 판매가격 조회
			chartTitleInfoByRedisDataList = (List<PrPremiumSelVO>) pcInfoService.getChartTitleInfoByRedisData(metalCode);
			selPcList.addAll(chartTitleInfoByRedisDataList);
		}
		//실시간 환율 정보가 없을 경우 전일 종가 조회
		if(redisEhgtEndPc == null || redisEhgtEndPc.compareTo(BigDecimal.ZERO) == 0) {
			PrEhgtStdrVO prEhgtRltmVO = pcInfoService.getPrEhgtAgo();
			redisEhgtEndPc = prEhgtRltmVO.getEndPc();
		}

		// 메탈
		param.put("metalCode", itemInvntrySetupVO.getMetalCode());
		// 아이템
		param.put("itmSn", itemInvntrySetupVO.getItmSn());
		// 대분류권역
		param.put("dstrctLclsfCode", itemInvntrySetupVO.getDstrctLclsfCode());
		// 중분류권역
		param.put("dstrctMlsfcCodeList", dstrctMlsfcCodeList);
		// 물류센터
		param.put("wrhousCode", itemInvntrySetupVO.getWrhousCode());
		// 물류센터위치
		param.put("wrhousCellLcCodeList", wrhousCellLcCodeList);
		// 브랜드그룹
		param.put("brandGroupCode", itemInvntrySetupVO.getBrandGroupCode());
		// 브랜드
		param.put("brandCode", itemInvntrySetupVO.getBrandCode());
		// 선물처리여부
		param.put("ftrsProcessAt", itemInvntrySetupVO.getFtrsProcessAt());
		// 판매상태
		param.put("sleSttusCode", itemInvntrySetupVO.getSleSttusCode());
		// B/L NO
		param.put("blNo", itemInvntrySetupVO.getBlNo());
		// 입고구분코드
		param.put("wrhousngSeCode", itemInvntrySetupVO.getWrhousngSeCode());
		// 실시간 환율
		param.put("redisEhgtEndPc", itemInvntrySetupVO.getRedisEhgtEndPc());
		// 판매가격
		param.put("selPcList",selPcList);
		// 실시간 lme cash
		param.put("redisLmeEndPc", lmeCashList);
		// 실시간 환율
		param.put("redisEhgtEndPc", redisEhgtEndPc);

		return itemInvntrySetupMapper.selectItemSclptrList(param);
	}
	
	/**
	 * 판매설정 번들수 유효성 검사 [(할당잔량 + 판매완료) 미만 설정 불가 유효성 검사] 후 실패된 BL번호들을 반환한다.
	 */
	@Override
	public String chkSleSetupBundleCo(ArrayList<ItemInvntrySetupVO> sleSetupBundleCoSaveList) throws Exception {
		StringBuilder chkFailStr = new StringBuilder(); // 유효성 검사 실패 BL 번호(복수), 구분자[,]로 나열
		
		log.info(">> chkSleSetupBundleCo : " + String.valueOf(sleSetupBundleCoSaveList));
		
		// BL 번호 리스트
		List<String> blNoList = sleSetupBundleCoSaveList.stream()
				.map(ItemInvntrySetupVO::getBlNo).collect(Collectors.toList());
		
		log.info(">> blNoList : " + String.valueOf(blNoList));
		
		// key : BL 번호, value : 판매설정 - 번들수(화면) 맵
		Map<String, Integer> selSetupBundleCoByBlNo = sleSetupBundleCoSaveList.stream()
				.collect(Collectors.toMap(ItemInvntrySetupVO::getBlNo, ItemInvntrySetupVO::getSleSetupBundleCo, (o1, o2) -> o1, LinkedHashMap::new));
		
		log.info(">> selSetupBundleCoByBlNo : " + String.valueOf(selSetupBundleCoByBlNo));
		
		// BL 번호(복수) 조건으로 BL 정보를 리스트로 가져온다.
		List<ItemInvntrySetupVO> getListBlInfoBas = itemInvntrySetupMapper.getListBlInfoBas(blNoList);
		
		String blNo = ""; // BL 번호
		int sleSetupBundleCo = 0; // 판매설정 - 번들수(화면)
		int ecAsgnBntBundleInvntry = 0; // 할당잔량(번들)
		int ecSleComptBundleInvntry = 0; // 판매완료(번들)
		
		for(ItemInvntrySetupVO itemInvntrySetupVO : getListBlInfoBas) {
			blNo = itemInvntrySetupVO.getBlNo(); // BL 번호
			sleSetupBundleCo = selSetupBundleCoByBlNo.get(blNo); // 판매설정 - 번들수(화면)
			ecAsgnBntBundleInvntry = itemInvntrySetupVO.getEcAsgnBntBundleInvntry(); // 할당잔량(번들)
			ecSleComptBundleInvntry = itemInvntrySetupVO.getEcSleComptBundleInvntry(); // 판매완료(번들)
			
			// 입력된 판매설정 - 번들수(화면) 값은 (할당잔량(번들) + 판매완료(번들)) 값보다 크거나 같아야 한다, 작으면 처리 불가
			if(sleSetupBundleCo < (ecAsgnBntBundleInvntry + ecSleComptBundleInvntry)) {
				chkFailStr.append(blNo).append(","); // 처리 불가 BL 번호
			}
		}
		
		if(chkFailStr.length() > 0) {
			chkFailStr.setLength(chkFailStr.length() - 1);
		}
		
		return chkFailStr.toString();
	}

	@Override
	public List<ItemInvntrySetupVO> selectBlList(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception {
		Map<String, Object> param = new HashMap<>();
		List<String> dstrctMlsfcCodeList = new ArrayList<String>();
		List<String> wrhousCellLcCodeList = new ArrayList<String>();
		if (itemInvntrySetupVO.getDstrctMlsfcCodeArray() != null) {
			for (int i = 0; i < itemInvntrySetupVO.getDstrctMlsfcCodeArray().length; i++) {
				dstrctMlsfcCodeList.add(itemInvntrySetupVO.getDstrctMlsfcCodeArray()[i]);
			}
		}
		if (itemInvntrySetupVO.getWrhousCellLcCodeArray() != null) {
			for (int i = 0; i < itemInvntrySetupVO.getWrhousCellLcCodeArray().length; i++) {
				wrhousCellLcCodeList.add(itemInvntrySetupVO.getWrhousCellLcCodeArray()[i]);
			}
		}
		// 메탈
		param.put("metalCode", itemInvntrySetupVO.getMetalCode());
		// 아이템
		param.put("itmSn", itemInvntrySetupVO.getItmSn());
		// 대분류권역
		param.put("dstrctLclsfCode", itemInvntrySetupVO.getDstrctLclsfCode());
		// 중분류권역
		param.put("dstrctMlsfcCodeList", dstrctMlsfcCodeList);
		// 물류센터
		param.put("wrhousCode", itemInvntrySetupVO.getWrhousCode());
		// 물류센터위치
		param.put("wrhousCellLcCodeList", wrhousCellLcCodeList);
		// 브랜드그룹
		param.put("brandGroupCode", itemInvntrySetupVO.getBrandGroupCode());
		// 브랜드
		param.put("brandCode", itemInvntrySetupVO.getBrandCode());
		// 선물처리여부
		param.put("ftrsProcessAt", itemInvntrySetupVO.getFtrsProcessAt());
		// 판매상태
		param.put("sleSttusCode", itemInvntrySetupVO.getSleSttusCode());
		// B/L NO
		param.put("blNo", itemInvntrySetupVO.getBlNo());
		// 입고구분코드
		param.put("wrhousngSeCode", itemInvntrySetupVO.getWrhousngSeCode());
		return itemInvntrySetupMapper.selectBlList(param);
	}

	@Override
	public int updateRmndrDscnt(ArrayList<ItemInvntrySetupVO> rmndrDscntList) throws Exception {
		ItemInvntrySetupVO itemInvntrySetupVO;
		int result = 0;
		for (int i = 0; i < rmndrDscntList.size(); i++) {
			try {
				itemInvntrySetupVO = rmndrDscntList.get(i);
				itemInvntrySetupVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
				// BL 정보 update
				result = itemInvntrySetupMapper.updateRmndrDscnt(itemInvntrySetupVO);
				commonService.insertTableHistory("IT_BL_INFO_BAS", itemInvntrySetupVO);
			} catch (Exception e) {
				log.error("ItemInvntrySetupServiceImpl updateRmndrDscnt error {}", e.getMessage());
			}
		}
		return result;
	}

}