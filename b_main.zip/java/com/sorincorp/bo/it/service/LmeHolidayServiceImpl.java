/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sorincorp.bo.it.service;

import java.util.HashMap;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.it.mapper.LmeHolidayMapper;
import com.sorincorp.bo.it.model.LmeHolidayVO;
import com.sorincorp.bo.sample.mapper.SampleMapper;
import com.sorincorp.bo.sample.model.SampleVO;

import lombok.extern.slf4j.Slf4j;
import net.bytebuddy.utility.RandomString;

@Slf4j
@Service
public class LmeHolidayServiceImpl implements LmeHolidayService {

	@Autowired
	private LmeHolidayMapper lmeHolidayMapper;
	
	
	/**
	 * 현재 년월 조회
	 * @param LmeHolidayVO - 조회할 정보가 담긴 VO
	 * @return 글 목록
	 * @exception Exception
	 */
	@Override
	public LmeHolidayVO getLmeCurrentDate(LmeHolidayVO restedVO) throws Exception {
		// TODO Auto-generated method stub
		return lmeHolidayMapper.getLmeCurrentDate(restedVO);
	}


	/**
	 * lme 휴일 리스트 조회
	 * @param LmeHolidayVO - 조회할 정보가 담긴 VO
	 * @return 글 목록
	 * @exception Exception
	 */
	@Override
	public JSONArray getLmeClndrList(LmeHolidayVO lmeHolidayVO) throws Exception {
		List<LmeHolidayVO> lmeClndrList = lmeHolidayMapper.getLmeClndrList(lmeHolidayVO);
		JSONArray eventSourcesList = new JSONArray();
		System.out.println("yoon");
		System.out.println(lmeClndrList);
		
		for (int i = 0; i < lmeClndrList.size(); i++) {
			JSONObject eventData = new JSONObject();
			// 캘린더 데이터
			eventData.put("title", lmeClndrList.get(i).getLmeCldrTyCode());
			eventData.put("start", lmeClndrList.get(i).getApplcDe());
			eventData.put("end", lmeClndrList.get(i).getApplcDe());
			
			if("O".equals(lmeClndrList.get(i).getHolidayAt())) {
				// 휴일 색상
				eventData.put("backgroundColor", "#F85E38");
				eventData.put("borderColor", "#F85E38");
				eventData.put("textColor", "#fff");
			}
			if("X".equals(lmeClndrList.get(i).getHolidayAt()) && (lmeClndrList.get(i).getLmeCldrTyCode() == null || "".equals(lmeClndrList.get(i).getLmeCldrTyCode()))) {
				// 휴일이지만 이벤트명 없을경우
				eventData.put("backgroundColor", "#bfbfbf");
				eventData.put("borderColor", "#bfbfbf");
				eventData.put("textColor", "#fff");
				
			}else if("X".equals(lmeClndrList.get(i).getHolidayAt()) && !"".equals(lmeClndrList.get(i).getLmeCldrTyCode())) {
				// 휴일 아닐때 색상
				eventData.put("backgroundColor", "#1E60D1");
				eventData.put("borderColor", "#1E60D1");
				eventData.put("textColor", "#fff");
			}
			
			// 이벤트 휴일 데이터
			eventData.put("nowDe", lmeClndrList.get(i).getApplcDe());
			eventData.put("eventRestdeNm", lmeClndrList.get(i).getLmeCldrTyCode());
			eventData.put("rm", lmeClndrList.get(i).getRm());
			eventData.put("restdeAt", lmeClndrList.get(i).getHolidayAt());
			eventData.put("lastChangeDt", lmeClndrList.get(i).getLastChangeDt());
			
			eventSourcesList.put(eventData);
		}
		
		return eventSourcesList;
	}
	
	
}
