package com.sorincorp.bo.it.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.FixingPcItmacctoMapper;
import com.sorincorp.bo.it.model.FixingPcItmacctoVO;

import io.jsonwebtoken.lang.Collections;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FixingPcItmacctoServiceImpl implements FixingPcItmacctoService {

	@Autowired
	private FixingPcItmacctoMapper fixingPcItmacctoMapper;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Override
	public List<FixingPcItmacctoVO> selectPurchsLmttPcManageList(FixingPcItmacctoVO vo) {
		return fixingPcItmacctoMapper.selectPurchsLmttPcManageList(vo);
	}

	@Override
	public int updatePurchsLmttPcManage(List<FixingPcItmacctoVO> list) {
		int resultCnt = 0;
		for (FixingPcItmacctoVO fixingPcItmacctoVO : list) {
			fixingPcItmacctoVO.setLastChangerId(userInfoUtil.getUserId());
			resultCnt += fixingPcItmacctoMapper.updatePurchsLmttPcManage(fixingPcItmacctoVO);
			fixingPcItmacctoMapper.insertPurchsLmttPcManageHst(fixingPcItmacctoVO);
		}
		return resultCnt;
	}

	@Override
	public int deletePurchsLmttPcManage(FixingPcItmacctoVO vo) {
		int resultCnt = 0;
		vo.setLastChangerId(userInfoUtil.getUserId());
		resultCnt += fixingPcItmacctoMapper.deletePurchsLmttPcManage(vo);
		fixingPcItmacctoMapper.insertPurchsLmttPcManageHst(vo);
		return resultCnt;
	}

	@Override
	@Transactional(rollbackFor =Exception.class)
	public int copyPreMonthData(FixingPcItmacctoVO param) {
		String applcYm = param.getApplcYm();
		String dstrctLclsfCode = param.getDstrctLclsfCode();

		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR,Integer.parseInt(applcYm.substring(0, 4)));
		calendar.set(Calendar.MONTH,Integer.parseInt(applcYm.substring(4, 6))-1);
		calendar.add(Calendar.MONTH, -1);

		SimpleDateFormat sdf = new SimpleDateFormat("YYYYMM");

		String preApplcYm = sdf.format(calendar.getTime());

		List<FixingPcItmacctoVO> list = fixingPcItmacctoMapper.selectPreMonthData(preApplcYm, applcYm,dstrctLclsfCode);

		if (Collections.isEmpty(list)) {
			return 0;
		}
		int resultCnt = 0;
		for (FixingPcItmacctoVO vo : list) {
			vo.setFrstRegisterId(userInfoUtil.getUserId());
			vo.setLastChangerId(userInfoUtil.getUserId());
			resultCnt += fixingPcItmacctoMapper.insertAndUpdatePurchsLmttPcManage(vo);
			fixingPcItmacctoMapper.insertPurchsLmttPcManageHst(vo);
		}

		return resultCnt;
	}

	@Override
	public List<FixingPcItmacctoVO> geFixingPcItmacctoPrmpcList(FixingPcItmacctoVO fixingPcItmacctoVO) {
		return fixingPcItmacctoMapper.geFixingPcItmacctoPrmpcList(fixingPcItmacctoVO);
	}

	@Override
	public List<FixingPcItmacctoVO> selectItFixingPcItmacctoPrmpcBasList(FixingPcItmacctoVO fixingPcItmacctoVO) {
		return fixingPcItmacctoMapper.selectItFixingPcItmacctoPrmpcBasList(fixingPcItmacctoVO);
	}
	public void updateFixingPcItmacctoPrmpcAjax(FixingPcItmacctoVO fixingPcItmacctoVO) {

		for(FixingPcItmacctoVO vo : fixingPcItmacctoVO.getGridList()) {
			vo.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			vo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		}

		fixingPcItmacctoMapper.insertAndUpdateItFixingPcItmacctoPrmpcBas(fixingPcItmacctoVO);
		fixingPcItmacctoMapper.insertItFixingPcItmacctoPrmpcBasHst(fixingPcItmacctoVO);

	}

	@Override
	public int insertAndUpdatePurchsLmttPcManage(List<FixingPcItmacctoVO> list) {
		int resultCnt = 0;
		for (FixingPcItmacctoVO vo : list) {
			vo.setFrstRegisterId(userInfoUtil.getUserId());
			vo.setLastChangerId(userInfoUtil.getUserId());
			resultCnt += fixingPcItmacctoMapper.insertAndUpdatePurchsLmttPcManage(vo);
			fixingPcItmacctoMapper.insertPurchsLmttPcManageHst(vo);
		}
		return resultCnt;
	}

	@Override
	public int updatePurchsLmttPcByPrmPc(List<FixingPcItmacctoVO> paramList) {
		int resultCnt = 0;
		for (FixingPcItmacctoVO paramVo : paramList) {
			paramVo.setDstrctLclsfCode(null);
			paramVo.setEntrpsNo(null);
			resultCnt += fixingPcItmacctoMapper.updatePurchsLmttPcManageByPrmPc(paramVo);
			fixingPcItmacctoMapper.insertPurchsLmttPcManageHst(paramVo);
		}
		return resultCnt;
	}

	@Override
	public int selectPurchsLmttPcCount(FixingPcItmacctoVO fixingPcItmacctoVO) {
		return fixingPcItmacctoMapper.selectPurchsLmttPcCount(fixingPcItmacctoVO);
	}

}
