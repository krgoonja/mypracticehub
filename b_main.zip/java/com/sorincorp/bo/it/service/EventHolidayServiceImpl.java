/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sorincorp.bo.it.service;

import java.util.List;
import java.util.Optional;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.EventHolidayMapper;
import com.sorincorp.bo.it.model.EventHolidayVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EventHolidayServiceImpl implements EventHolidayService {

	@Autowired
	private EventHolidayMapper eventHolidayMapper;

    @Autowired
    private UserInfoUtil userInfoUtil;
	
	/**
	 * 이벤트 휴일 목록을 조회한다.
	 * @param LmeHolidayVO - 조회할 정보가 담긴 VO
	 * @return 글 목록
	 * @exception Exception
	 */
	@Override
	public JSONArray getEventHolidayList(EventHolidayVO eventHolidayVO) throws Exception {
		
		List<EventHolidayVO> resultList = eventHolidayMapper.getEventHolidayList(eventHolidayVO);
		JSONArray eventSourcesList = new JSONArray();
		
		for (int i = 0; i < resultList.size(); i++) {
			JSONObject eventData = new JSONObject();
			// 캘린더 데이터
			eventData.put("title", resultList.get(i).getEventRestdeNm());
			eventData.put("start", resultList.get(i).getApplcBeginDe());
			// 캘린더 표기 수정
			if(resultList.get(i).getApplcBeginDe().equals(resultList.get(i).getApplcEndDe())) {
				// 시작일과 종료일이 같으면 날짜만
				eventData.put("end", resultList.get(i).getApplcEndDe());
			} else {
				// 시작일과 종료일이 다르면 종료일에 시간 추가
				eventData.put("end", resultList.get(i).getApplcEndDe()+"T23:59:00");
			}
			
			if("Y".equals(resultList.get(i).getRestdeAt())) {
				// 휴일 색상
				eventData.put("backgroundColor", "#F85E38");
				eventData.put("borderColor", "#F85E38");
				eventData.put("textColor", "#fff");
			}
			if("N".equals(resultList.get(i).getRestdeAt())) {
				// 휴일 아닐때 색상
				eventData.put("backgroundColor", "#1E60D1");
				eventData.put("borderColor", "#1E60D1");
				eventData.put("textColor", "#fff");
			}
			
			// 이벤트 휴일 데이터
			eventData.put("nowDe", resultList.get(i).getNowDe());
			eventData.put("applcBeginDe", resultList.get(i).getApplcBeginDe());
			eventData.put("applcEndDe", resultList.get(i).getApplcEndDe());
			eventData.put("eventRestdeNm", resultList.get(i).getEventRestdeNm());
			eventData.put("eventRestdeSeCode", resultList.get(i).getEventRestdeSeCode());
			eventData.put("rm", resultList.get(i).getRm());
			eventData.put("restdeAt", resultList.get(i).getRestdeAt());
			eventData.put("expsrAt", resultList.get(i).getExpsrAt());
			eventData.put("eventRestdeSn", resultList.get(i).getEventRestdeSn());
			eventData.put("changeYN", resultList.get(i).getChangeYN());
			eventData.put("nationCode", resultList.get(i).getNationCode());
			
			
			eventSourcesList.put(eventData);
		}
		
		return eventSourcesList;
	}

	/**
	 * 이벤트 휴일 관리를 등록한다
	 * @param vo - 조회할 정보가 담긴 EventHolidayVO
	 * @return 조회한 글
	 * @exception Exception
	 */
	@Override
	public void insertEventHoliday(EventHolidayVO vo) throws Exception {
		vo.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		vo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		eventHolidayMapper.insertEventHoliday(vo);
		eventHolidayMapper.insertEventHolidayHistory(vo);
	}

	
	
	@Override
	public void updateEventHoliday(EventHolidayVO vo) throws Exception {
		vo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		eventHolidayMapper.updateEventHoliday(vo);
		eventHolidayMapper.insertEventHolidayHistory(vo);
	}

	/**
	 * 이벤트 휴일을 삭제한다
	 * @param vo - 조회할 정보가 담긴 EventHolidayVO
	 * @return
	 * @exception Exception
	 */	
	@Override
	public void deleteEventHoliday(EventHolidayVO vo) throws Exception {
		vo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		eventHolidayMapper.deleteEventHoliday(vo);
		eventHolidayMapper.insertEventHolidayHistory(vo);
	}

	/**
	 * Nation(국가) 코드 리스트 조회
	 * @return		List<EventHolidayVO> - 국가 코드 리스트
	 * @exception 	Exception
	 */
	@Override
	public List<EventHolidayVO> getNationCodeList() throws Exception {
		List<EventHolidayVO> nationCode = eventHolidayMapper.getNationCodeList();
		return nationCode;
	}//end getNationCodeList()

}
