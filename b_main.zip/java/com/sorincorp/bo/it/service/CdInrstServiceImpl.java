package com.sorincorp.bo.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.it.mapper.CdInrstMapper;
import com.sorincorp.bo.it.model.CdInrstVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdInrstServiceImpl implements CdInrstService{
	
	
	@Autowired
	CdInrstMapper cdInrstMapper;
	
	@Override
	public List<CdInrstVO> selectCdInrstListData(CdInrstVO civo) {
		// TODO Auto-generated method stub
		return cdInrstMapper.selectCdInrstListData(civo);
	}

	@Override
	public int selectCntCdInrstListData(CdInrstVO civo) {
		// TODO Auto-generated method stub
		return cdInrstMapper.selectCntCdInrstListData(civo);
	}

	@Override
	public List<CdInrstVO> selectForChartCdListData(CdInrstVO civo) {
		// TODO Auto-generated method stub
		return cdInrstMapper.selectForChartCdListData(civo);
	}

}
