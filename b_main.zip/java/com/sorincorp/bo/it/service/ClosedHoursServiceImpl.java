/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sorincorp.bo.it.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.ClosedHoursMapper;
import com.sorincorp.bo.it.model.ClosedHoursVO;
import com.sorincorp.comm.redis.config.RedisPubSubService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@ComponentScan({"com.sorincorp.comm.*"})
public class ClosedHoursServiceImpl implements ClosedHoursService {

	@Autowired
	private ClosedHoursMapper closedHoursMapper;

    @Autowired
    private UserInfoUtil userInfoUtil;
	
	@Autowired
	private SimpMessagingTemplate simpMessagingTemplate;
	
	@Autowired
	private RedisPubSubService redisPubSubService;
	
	@Value("${redisPubsub.uri.restTime}")
	private String restTimeUri;
    
	/**
	 * 글 목록을 조회한다.
	 * @param LmeHolidayVO - 조회할 정보가 담긴 VO
	 * @return 글 목록
	 * @exception Exception
	 */

	@Override
	public List<ClosedHoursVO> getClosedHoursList(ClosedHoursVO closedHoursVO) throws Exception {
		// TODO Auto-generated method stub
		return closedHoursMapper.getClosedHoursList(closedHoursVO);
	}
	
	

	/**
	 * 글 목록을 조회한다.
	 * @param LmeHolidayVO - 조회할 정보가 담긴 VO
	 * @return 글 목록
	 * @exception Exception
	 */
	@Override
	public int getClosedHoursListCnt(ClosedHoursVO closedHoursVO) throws Exception {
		// TODO Auto-generated method stub
		return closedHoursMapper.getClosedHoursListCnt(closedHoursVO);
	}


	/**
	 * 휴무 시간을 등록한다.
	 * @param closedHoursVO - 조회할 정보가 담긴 List VO
	 * @return 글 목록
	 * @exception Exception
	 */

	@Override
	public void insertAndUpdateClosedHoursList(List<ClosedHoursVO> closedHoursVOList) throws Exception {
		
		for (int i = 0; i < closedHoursVOList.size(); i++) {
			closedHoursVOList.get(i).getApplcBeginTime().replace(":", "");
			closedHoursVOList.get(i).getApplcEndTime().replace(":", "");
			closedHoursVOList.get(i).setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			closedHoursVOList.get(i).setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			
			if ("created".equals(closedHoursVOList.get(i).getGridRowStatus())) {
				ClosedHoursVO deleteCheckVO = new ClosedHoursVO();
				deleteCheckVO = closedHoursMapper.getClosedHours(closedHoursVOList.get(i));

				// 사이즈가 1이면 업데이트, 0이면 생성
				if(deleteCheckVO == null) {	// 신규 등록
						
					closedHoursMapper.insertClosedHoursList(closedHoursVOList.get(i));
					closedHoursMapper.insertClosedHoursHist(closedHoursVOList.get(i));
					
				} else if(deleteCheckVO != null && "Y".equals(deleteCheckVO.getDeleteAt())){  // 삭제 했다가 다시 등록

					closedHoursVOList.get(i).setDeleteAt("N");
					closedHoursMapper.updateClosedHoursList(closedHoursVOList.get(i));
					closedHoursMapper.insertClosedHoursHist(closedHoursVOList.get(i));
					
				} else if(deleteCheckVO != null && "N".equals(deleteCheckVO.getDeleteAt())) { // 중복 체크
					closedHoursMapper.updateClosedHoursList(closedHoursVOList.get(i));
				}

			}else if("updated".equals(closedHoursVOList.get(i).getGridRowStatus())) {

				closedHoursMapper.updateClosedHoursList(closedHoursVOList.get(i));
				closedHoursMapper.insertClosedHoursHist(closedHoursVOList.get(i));
			}
			
			redisPubSubService.publishMessage(restTimeUri, restTimeUri, "setRestTime");
		}
	}

	/**
	 * 휴무 시간을 삭제(update)한다.
	 * @param closedHoursVO - 조회할 정보가 담긴 List VO
	 * @return 글 목록
	 * @exception Exception
	 */
	@Override
	public void deleteClosedHoursList(List<ClosedHoursVO> closedHoursVO) throws Exception {
		for (int i = 0; i < closedHoursVO.size(); i++) {
			closedHoursVO.get(i).setDeleteAt("Y");
			closedHoursVO.get(i).setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			closedHoursMapper.deleteClosedHoursList(closedHoursVO.get(i));
			closedHoursMapper.insertClosedHoursHist(closedHoursVO.get(i));
			
			redisPubSubService.publishMessage(restTimeUri, restTimeUri, "setRestTime");
		}
	}

}
