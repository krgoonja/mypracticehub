package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.ClosedHoursVO;

/**
 * ClosedHoursService.java
 * @version
 * @since 2021. 5. 17.
 * @author srec0008
 */
public interface ClosedHoursService {

	/**
	 * <pre>
	 * 휴무 시간을 조회한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 17.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param closedHoursVO
	 * @return
	 * @throws Exception
	 */
	public List<ClosedHoursVO> getClosedHoursList(ClosedHoursVO closedHoursVO) throws Exception;
	
	/**
	 * <pre>
	 * 휴무 시간 리스트 카운트를 조회한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 17.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param closedHoursVO
	 * @return
	 * @throws Exception
	 */
	public int getClosedHoursListCnt(ClosedHoursVO closedHoursVO) throws Exception;


	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 17.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param closedHoursVO
	 * @throws Exception
	 */
	void insertAndUpdateClosedHoursList(List<ClosedHoursVO> closedHoursVO) throws Exception;


	/**
	 * <pre>
	 * 휴무 시간을 삭제(update)한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 17.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param closedHoursVO
	 * @throws Exception
	 */
	void deleteClosedHoursList(List<ClosedHoursVO> closedHoursVO) throws Exception;


}
