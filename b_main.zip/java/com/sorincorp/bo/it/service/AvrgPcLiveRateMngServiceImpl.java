package com.sorincorp.bo.it.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.sorincorp.comm.common.service.CommonService;
import org.codehaus.plexus.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.sorincorp.bo.it.mapper.AvrgPcLiveRateMngMapper;
import com.sorincorp.bo.it.model.AvrgPcLiveGradInfoVO;
import com.sorincorp.bo.it.model.AvrgPcLiveRateDtlVO;
import com.sorincorp.bo.it.model.AvrgPcLiveRateMngVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;

import lombok.extern.slf4j.Slf4j;

/**
 * AvrgPcLiveRateMngServiceImpl.java
 * 평균가 라이브 비율 관리 Service 구현체 클래스
 * 
 * @version
 * @since 2023. 8. 16.
 * @author srec0049
 */
@Slf4j
@Service
public class AvrgPcLiveRateMngServiceImpl implements AvrgPcLiveRateMngService {
	
	/**
	 * 공통 코드 Service
	 */
	@Autowired
	private CommonCodeService commonCodeService;
	
	/**
	 * 평균가 라이브 비율 관리 Mapper
	 */
	@Autowired
	private AvrgPcLiveRateMngMapper avrgPcLiveRateMngMapper;

	/**
	 * 공통 Service
	 */
	@Autowired
	private CommonService commonService;
	
	
	/**
	 * 평균가 라이브 비율 관리 목록(총 건수 포함)을 가져온다.
	 */
	@Override
	public List<AvrgPcLiveRateMngVO> getListAvrgPcLiveRate(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception {
		// 평균가 라이브 비율 관리 목록(총 건수 포함)을 가져온다.
		List<AvrgPcLiveRateMngVO> getListAvrgPcLiveRate = avrgPcLiveRateMngMapper.getListAvrgPcLiveRate(avrgPcLiveRateMngVO);
		
		return getListAvrgPcLiveRate;
	}
	
	/**
	 * 금속코드와 적용일자에 대한 평균가 라이브 비율 관리 목록(상품_평균가 LIVE 기준 중량 관리 기본) 중복 건수를 가져온다.
	 */
	@Override
	public Integer getAvrgPcLiveRateDuplCnt(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception {
		// 금속코드와 적용일자에 대한 평균가 라이브 비율 관리 목록(상품_평균가 LIVE 기준 중량 관리 기본) 중복 건수를 가져온다.
		Integer getAvrgPcLiveRateDuplCnt = avrgPcLiveRateMngMapper.getAvrgPcLiveRateDuplCnt(avrgPcLiveRateMngVO);
		
		return getAvrgPcLiveRateDuplCnt;
	}
	
	/**
	 * 상품_평균가 LIVE 기준 중량 관리 기본 정보를 가져온다.
	 */
	@Override
	public AvrgPcLiveRateMngVO getAvrgPcLiveRate(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception {
		
		// 상품_평균가 LIVE 기준 중량 관리 기본 정보를 가져온다.
		AvrgPcLiveRateMngVO getAvrgPcLiveRate = avrgPcLiveRateMngMapper.getAvrgPcLiveRate(avrgPcLiveRateMngVO);
		
		return getAvrgPcLiveRate;
	}
	
	/**
	 * 톤당 구매 비율 리스트 구조 가져오기
	 */
	@Override
	public List<AvrgPcLiveRateMngVO> getPurchsRateStructurePerTonList() throws Exception {
		// 톤당 구매 비율 리스트
		List<AvrgPcLiveRateMngVO> purchsRateStructurePerTonList = new ArrayList<AvrgPcLiveRateMngVO>();
		
		// 공통코드 [평균가 LIVE 구매 등급 코드]
		Map<String, String> commAvrgpcLivePurchsGradCode = commonCodeService.getSubCodes("ENTRPS_GRAD_CODE");
		log.debug(">> getPurchsRateStructurePerTonList commAvrgpcLivePurchsGradCode : " + commAvrgpcLivePurchsGradCode.toString());
		
		int commAvrgpcLivePurchsGradCodeSize = commAvrgpcLivePurchsGradCode.size(); // 공통코드 [평균가 LIVE 구매 등급 코드] 사이즈
		
		// 리스트 생성
		for(int i=0; i<commAvrgpcLivePurchsGradCodeSize; i++) {
			String gradCode = commAvrgpcLivePurchsGradCode.get("0"+String.valueOf(commAvrgpcLivePurchsGradCodeSize-i));
			
			AvrgPcLiveRateMngVO avrgPcLiveGradMngVO = new AvrgPcLiveRateMngVO();
			avrgPcLiveGradMngVO.setAvrgpcLivePurchsGradCodeNm(gradCode);
			
			purchsRateStructurePerTonList.add(avrgPcLiveGradMngVO);
		}
		
		return purchsRateStructurePerTonList;
	}
	
	/**
	 * 금속 코드에 해당하는 톤당 구매 비율 리스트를 가져온다.
	 */
	@Override
	public List<AvrgPcLiveGradInfoVO> getPurchsRateValuePerTonListByMetalCode(String metalCode) throws Exception {
		List<AvrgPcLiveGradInfoVO> getPurchsRateValuePerTonListByMetalCode = avrgPcLiveRateMngMapper.getPurchsRateValuePerTonListByMetalCode(metalCode);
		
		return getPurchsRateValuePerTonListByMetalCode;
	}
	
	/**
	 * 톤당 구매 비율 리스트 - 상품_평균가 LIVE 기준 중량 관리의 단계 비율 데이터로 [평균가 LIVE 등급 관리 데이터(selectMbAvrgPcLiveGradMngList 메소드)] 리스트를 생성한다.
	 */
	@Override
	public List<AvrgPcLiveRateMngVO> getPurchsRatePerTonList(JsonNode avrgPcLiveRateJson, AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception {
		// 톤당 구매 비율 리스트
		List<AvrgPcLiveRateMngVO> avrgPcLiveGradMngList = new ArrayList<AvrgPcLiveRateMngVO>();
		
		String[] STEP_RATE_ARR = {"oneStepRate", "twoStepRate", "threeStepRate", "fourStepRate", "fiveStepRate"}; // 다이아몬드, 플래티넘, 골드, 실버, 브론즈 단계 비율 키 값
		
		log.debug(">> avrgPcLiveRateJson : " + avrgPcLiveRateJson);
		
		// 공통코드 [평균가 LIVE 구매 등급 코드]
		Map<String, String> commAvrgpcLivePurchsGradCode = commonCodeService.getSubCodes("ENTRPS_GRAD_CODE");
		log.debug(">> getPurchsRatePerTonList commAvrgpcLivePurchsGradCode : " + commAvrgpcLivePurchsGradCode.toString());
		
		int commAvrgpcLivePurchsGradCodeSize = commAvrgpcLivePurchsGradCode.size(); // 공통코드 [평균가 LIVE 구매 등급 코드] 사이즈
		
		// 리스트 생성
		for(int i=0; i<commAvrgpcLivePurchsGradCodeSize; i++) {
			String gradCode = commAvrgpcLivePurchsGradCode.get("0"+String.valueOf(commAvrgpcLivePurchsGradCodeSize-i)); // ENTRPS_GRAD_CODE 번호는 역순... 05가 다이아몬드, 01이 브론즈
			double tempStepRate = Double.parseDouble( Optional.ofNullable(String.valueOf(avrgPcLiveRateJson.get(STEP_RATE_ARR[i]))).orElse("0") );
			int stepRate = (int)tempStepRate;
			
			AvrgPcLiveRateMngVO avrgPcLiveGradMngVO = new AvrgPcLiveRateMngVO();
			avrgPcLiveGradMngVO.setAvrgpcLivePurchsGradCodeNm(gradCode);
			avrgPcLiveGradMngVO.setPurchsRate(stepRate);
			
			avrgPcLiveGradMngList.add(avrgPcLiveGradMngVO);
		}
		
		return avrgPcLiveGradMngList;
	}
	
	/**
	 * 상품_평균가 LIVE 기준 중량 관리 상세에 평균 라이브 비율 기준 톤수 데이터 리스트를 가져온다.
	 */
	@Override
	public List<AvrgPcLiveRateDtlVO> getAvrgPcLiveRateDtlList(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception {
		// 상품_평균가 LIVE 기준 중량 관리 상세에 평균 라이브 비율 기준 톤수 데이터 리스트를 가져온다.
		List<AvrgPcLiveRateDtlVO> getAvrgPcLiveRateDtlList = avrgPcLiveRateMngMapper.getAvrgPcLiveRateDtlList(avrgPcLiveRateMngVO);
		
		return getAvrgPcLiveRateDtlList;
	}
	
	/**
	 * 평균 라이브 비율 데이터를 등록한다.
	 */
	@Override
	public void insertAvrgPcLiveRate(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception {
		// 상품_평균가 LIVE 기준 중량 관리 기본에 평균 라이브 비율 데이터를 등록한다.
		int insertItAvrgpcLiveStdrWtManageBas = avrgPcLiveRateMngMapper.insertItAvrgpcLiveStdrWtManageBas(avrgPcLiveRateMngVO);
		log.debug(">> insertItAvrgpcLiveStdrWtManageBas status : " + insertItAvrgpcLiveStdrWtManageBas);
		
		// 상품_평균가 LIVE 기준 중량 관리 기본에 대한 이력을 등록한다.
		//int insertItAvrgpcLiveStdrWtManageBasHst = avrgPcLiveRateMngMapper.insertItAvrgpcLiveStdrWtManageBasHst(avrgPcLiveRateMngVO);
		boolean insertItAvrgpcLiveStdrWtManageBasHst = commonService.insertTableHistory("IT_AVRGPC_LIVE_STDR_WT_MANAGE_BAS", avrgPcLiveRateMngVO);
		log.debug(">> insertItAvrgpcLiveStdrWtManageBasHst status : " + insertItAvrgpcLiveStdrWtManageBasHst);
		
		String stdrSn = avrgPcLiveRateMngVO.getStdrSn(); // 생성된 기준 순번 가져오기
		log.debug(">> insertAvrgPcLiveRate stdrSn : " + avrgPcLiveRateMngVO.getStdrSn());
		
		if(StringUtils.isNotBlank(stdrSn)) {
			// 상품_평균가 LIVE 기준 중량 관리 상세에 평균 라이브 비율 기준 톤수 데이터를 등록 또는 수정한다.
			insertAndUpdateAvrgPcLiveRateDtl(avrgPcLiveRateMngVO);
		}
	}
	
	/**
	 * 평균 라이브 비율 데이터를 수정한다.
	 */
	@Override
	public void updateAvrgPcLiveRate(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception {
		// 상품_평균가 LIVE 기준 중량 관리 기본에 평균 라이브 비율 데이터를 수정한다.
		int updateItAvrgpcLiveStdrWtManageBas = avrgPcLiveRateMngMapper.updateItAvrgpcLiveStdrWtManageBas(avrgPcLiveRateMngVO);
		log.debug(">> updateItAvrgpcLiveStdrWtManageBas status : " + updateItAvrgpcLiveStdrWtManageBas);
		
		// 상품_평균가 LIVE 기준 중량 관리 기본에 대한 이력을 등록한다.
		//int insertItAvrgpcLiveStdrWtManageBasHst = avrgPcLiveRateMngMapper.insertItAvrgpcLiveStdrWtManageBasHst(avrgPcLiveRateMngVO);
		boolean insertItAvrgpcLiveStdrWtManageBasHst = commonService.insertTableHistory("IT_AVRGPC_LIVE_STDR_WT_MANAGE_BAS", avrgPcLiveRateMngVO);
		log.debug(">> insertItAvrgpcLiveStdrWtManageBasHst status : " + insertItAvrgpcLiveStdrWtManageBasHst);
		
		// 상품_평균가 LIVE 기준 중량 관리 상세에 평균 라이브 비율 기준 톤수 데이터를 등록 또는 수정한다.
		insertAndUpdateAvrgPcLiveRateDtl(avrgPcLiveRateMngVO);
	}
	
	/**
	 * <pre>
	 * 처리내용: 상품_평균가 LIVE 기준 중량 관리 상세에 평균 라이브 비율 기준 톤수 데이터를 등록 또는 수정한다.
	 * </pre>
	 * @date 2023. 9. 4.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 9. 4.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @throws Exception
	 */
	public void insertAndUpdateAvrgPcLiveRateDtl(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception {
		// 상품_평균가 LIVE 기준 중량 관리 상세에 평균 라이브 비율 기준 톤수 데이터를 등록 또는 수정한다.
		int insertAndUpdateItAvrgpcLiveStdrWtManageDtl = avrgPcLiveRateMngMapper.insertAndUpdateItAvrgpcLiveStdrWtManageDtl(avrgPcLiveRateMngVO);
		log.debug(">> insertAndUpdateItAvrgpcLiveStdrWtManageDtl status : " + insertAndUpdateItAvrgpcLiveStdrWtManageDtl);
		
		// 상품_평균가 LIVE 기준 중량 관리 상세에 대한 이력을 등록한다.
		//int insertItAvrgpcLiveStdrWtManageDtlHst = avrgPcLiveRateMngMapper.insertItAvrgpcLiveStdrWtManageDtlHst(avrgPcLiveRateMngVO);
		List<String> primaryKeyList = new ArrayList<>();
		primaryKeyList.add("STDR_SN");
		boolean insertItAvrgpcLiveStdrWtManageDtlHst = commonService.insertTableHistory("IT_AVRGPC_LIVE_STDR_WT_MANAGE_DTL", avrgPcLiveRateMngVO,primaryKeyList);
		log.debug(">> insertItAvrgpcLiveStdrWtManageDtlHst status : " + insertItAvrgpcLiveStdrWtManageDtlHst);
	}
	
	/**
	 * 평균 라이브 비율 데이터를 삭제한다.
	 */
	@Override
	public void deleteAvrgPcLiveRate(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception {
		// 상품_평균가 LIVE 기준 중량 관리 기본에 평균 라이브 비율 데이터를 삭제한다.
		int deleteItAvrgpcLiveStdrWtManageBas = avrgPcLiveRateMngMapper.deleteItAvrgpcLiveStdrWtManageBas(avrgPcLiveRateMngVO);
		log.debug(">> deleteItAvrgpcLiveStdrWtManageBas status : " + deleteItAvrgpcLiveStdrWtManageBas);
		
		// 상품_평균가 LIVE 기준 중량 관리 기본에 대한 이력을 등록한다.
		//int insertItAvrgpcLiveStdrWtManageBasHst = avrgPcLiveRateMngMapper.insertItAvrgpcLiveStdrWtManageBasHst(avrgPcLiveRateMngVO);
		boolean insertItAvrgpcLiveStdrWtManageBasHst = commonService.insertTableHistory("IT_AVRGPC_LIVE_STDR_WT_MANAGE_BAS", avrgPcLiveRateMngVO);
		log.debug(">> insertItAvrgpcLiveStdrWtManageBasHst status : " + insertItAvrgpcLiveStdrWtManageBasHst);
		
		// 상품_평균가 LIVE 기준 중량 관리 상세에 평균 라이브 비율 기준 톤수 데이터를 삭제한다.
		int deleteItAvrgpcLiveStdrWtManageDtl = avrgPcLiveRateMngMapper.deleteItAvrgpcLiveStdrWtManageDtl(avrgPcLiveRateMngVO);
		log.debug(">> deleteItAvrgpcLiveStdrWtManageDtl status : " + deleteItAvrgpcLiveStdrWtManageDtl);
		
		// 상품_평균가 LIVE 기준 중량 관리 상세에 대한 이력을 등록한다.
		//int insertItAvrgpcLiveStdrWtManageDtlHst = avrgPcLiveRateMngMapper.insertItAvrgpcLiveStdrWtManageDtlHst(avrgPcLiveRateMngVO);
		List<String> primaryKeyList = new ArrayList<>();
		primaryKeyList.add("STDR_SN");
		boolean insertItAvrgpcLiveStdrWtManageDtlHst = commonService.insertTableHistory("IT_AVRGPC_LIVE_STDR_WT_MANAGE_DTL", avrgPcLiveRateMngVO,primaryKeyList);
		log.debug(">> insertItAvrgpcLiveStdrWtManageDtlHst status : " + insertItAvrgpcLiveStdrWtManageDtlHst);
	}
}
