package com.sorincorp.bo.it.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.model.ItemInvntrySetupVO;

public interface ItemInvntrySetupService {

	List<ItemInvntrySetupVO> selectItemInvntrySetupList(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체 리스트 
	 * </pre>
	 * @date 2023. 01. 13.
	 * @auther jdrttl
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 01. 13.		jdrttl				최초작성
	 * -----------------------------------------------
	 * @param itemInvntrySetupVO
	 * @return List<ItemInvntrySetupVO>
	 * @throws Exception
	 */
	List<ItemInvntrySetupVO> selectEntrpsList(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 더미오더 생성 
	 * </pre>
	 * @date 2023. 01. 13.
	 * @auther jdrttl
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 01. 13.		jdrttl				최초작성
	 * -----------------------------------------------
	 * @param ItemInvntrySetupVO
	 * @return ItemInvntrySetupVO
	 * @throws Exception
	 */
	ItemInvntrySetupVO saveDummyOrder(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 최신 더미오더 생성 내역 가져오기 
	 * </pre>
	 * @date 2023. 01. 16.
	 * @auther jdrttl
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 01. 16.		jdrttl				최초작성
	 * -----------------------------------------------
	 * @param ItemInvntrySetupVO
	 * @return ItemInvntrySetupVO
	 * @throws Exception
	 */
	ItemInvntrySetupVO selectNewestDummyOrder(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: BL 검색 팝업에서 
	 * </pre>
	 * @date 2022. 12. 20.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 20.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param itemInvntrySetupVO
	 * @return
	 * @throws Exception
	 */
	int selectPopItemInvntrySetupListTotCnt(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: BL검색 팝업에서 데이터 조회 
	 * </pre>
	 * @date 2022. 12. 20.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 20.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param itemInvntrySetupVO
	 * @return
	 * @throws Exception
	 */
	List<ItemInvntrySetupVO> selectPopItemInvntrySetupList(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;
	
	List<ItCmnCodeVO> getWrhousCellLcList(String WrhousCode) throws Exception;

	Map<String, Object> updateSleSttusCode(ArrayList<ItemInvntrySetupVO> sleSttusCodeList) throws Exception;

	int updateSleSetupBundleCo(ArrayList<ItemInvntrySetupVO> sleSetupBundleCoSaveList) throws Exception;

	int updateRmndrDscnt(ArrayList<ItemInvntrySetupVO> rmndrDscntList) throws Exception;
	List<ItemInvntrySetupVO> calcSetupData(ArrayList<ItemInvntrySetupVO> sleSetupBundleCoSaveList) throws Exception;

	void itemInvntrySmsSndng(List<String> blno) throws Exception;

    List<ItemInvntrySetupVO> selectItemSclptrList(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;
    
    /**
     * <pre>
     * 처리내용: 판매설정 번들수 유효성 검사 [(할당잔량 + 판매완료) 미만 설정 불가 유효성 검사] 후 실패된 BL번호들을 반환한다.
     * </pre>
     * @date 2024. 1. 17.
     * @author srec0049
     * @history 
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2024. 1. 17.			srec0049			최초작성
     * ------------------------------------------------
     * @param sleSetupBundleCoSaveList
     * @return
     * @throws Exception
     */
    public String chkSleSetupBundleCo(ArrayList<ItemInvntrySetupVO> sleSetupBundleCoSaveList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: BL 조회
	 * </pre>
	 * @date 2024. 04. 01.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 04. 01.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param itemInvntrySetupVO
	 * @return
	 * @throws Exception
	 */
	public List<ItemInvntrySetupVO> selectBlList(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;

}
