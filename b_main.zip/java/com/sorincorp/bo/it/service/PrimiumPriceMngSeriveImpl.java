package com.sorincorp.bo.it.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.dynmDiver.mapper.DynmDiverMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.PremiumPriceMngMapper;
import com.sorincorp.bo.it.model.LmeEvalCashVO;
import com.sorincorp.bo.it.model.PrEhgtPcRltmBasVO;
import com.sorincorp.bo.it.model.PremiumAvrgPurchsPrmpcVO;
import com.sorincorp.bo.it.model.PremiumBrandBasVO;
import com.sorincorp.bo.it.model.PremiumBrandGroupBasVO;
import com.sorincorp.bo.it.model.PremiumDetailProfitAndLoseVO;
import com.sorincorp.bo.it.model.PremiumDstrctBasVO;
import com.sorincorp.bo.it.model.PremiumMonFxEvaluationCashVO;
import com.sorincorp.bo.it.model.PremiumSetPriceVO;
import com.sorincorp.bo.it.model.PremiumStdrBasVO;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PrimiumPriceMngSeriveImpl implements PrimiumPriceMngService {
	
	public final static String PREMIUM_INFO_LIST = "premiumInfoList";	// 프리미엄 가격 (레디스에 저장할 이름)
	
	@Autowired
	private PremiumPriceMngMapper ppmMapper;
	
	@Autowired
	private AssignService assignService;

	@Autowired
	private RedisPubSubService redisPubSubService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private SimpMessagingTemplate simpMessagingTemplate;

	@Value("${redisPubsub.uri.premium}")
	private String premiumUri;
	
	@Autowired
	private PcInfoService pcInfoService;
	
	@Autowired
	private CommonService commonService;

	@Autowired
	private DynmDiverMapper dynmDiverMapper;

	@Value("${lme.api.diver.url}")
	private String lmeDiverUrl;

	@Autowired
	private HttpClientHelper httpClientHelper;
	
	@Override
	public void updatePremiumPriceValidation(PremiumStdrBasVO vo) {
		ppmMapper.updatePremiumPriceValidation(vo);
	}

	@Override
	public void insertPremiumPriceValidationHst(PremiumStdrBasVO vo) {
		ppmMapper.insertPremiumPriceValidationHst(vo);
	}

	@Override
	public void insertAndUpdatePremiumStdrPrice(PremiumStdrBasVO vo) {
		ppmMapper.insertAndUpdatePremiumStdrPrice(vo);
	}

	@Override
	public void insertAndUpdatePremiumDstrctPrice(List<PremiumDstrctBasVO> list) {
		int count = list.size();
		for(int i = 0; i < count; i++) {
			ppmMapper.insertAndUpdatePremiumDstrctPrice(list.get(i));
		}
	}

	@Override
	public void insertAndUpdatePremiumDstrctPriceHst(List<PremiumDstrctBasVO> list) {
		int count = list.size();
		for(int i = 0; i < count; i++) {
			ppmMapper.insertAndUpdatePremiumDstrctPriceHst(list.get(i));
		}
	}

	@Override
	public void insertAndUpdatePremiumBrandGroupPrice(List<PremiumBrandGroupBasVO> list) {
		int count = list.size();
		for(int i = 0; i < count; i++) {
			ppmMapper.insertAndUpdatePremiumBrandGroupPrice(list.get(i));
		}
	}

	@Override
	public void insertAndUpdatePremiumBrandGroupPriceHst(List<PremiumBrandGroupBasVO> list) {
		int count = list.size();
		for(int i = 0; i < count; i++) {
			ppmMapper.insertAndUpdatePremiumBrandGroupPriceHst(list.get(i));
		}
	}


	@Override
	public void insertAndUpdatePremiumBrandPrice(List<PremiumBrandBasVO> list) {
		int count = list.size();
		for(int i = 0; i < count; i++) {
			ppmMapper.insertAndUpdatePremiumBrandPrice(list.get(i));
		}
	}


	@Override
	public void insertAndUpdatePremiumBrandPriceHst(List<PremiumBrandBasVO> list) {
		int count = list.size();
		for(int i = 0; i < count; i++) {
			ppmMapper.insertAndUpdatePremiumBrandPriceHst(list.get(i));
		}
	}

	@Override
	public void insertAndUpdatePremiumBrandDtlPrice(PremiumStdrBasVO vo) {
		ppmMapper.insertAndUpdatePremiumBrandDtlPrice(vo);
	}

	@Override
	public void insertAndUpdatePremiumBrandDtlPriceHst(PremiumStdrBasVO vo) {
		ppmMapper.insertAndUpdatePremiumBrandDtlPriceHst(vo);
	}


	@Override
	public List<PremiumStdrBasVO> selectPremiumList(PremiumStdrBasVO vo) {
		return ppmMapper.selectPremiumList(vo);
	}
	@Override
	public int selectPremiumCnt(PremiumStdrBasVO vo) {
		return ppmMapper.selectPremiumCnt(vo);
	}
	@Override
	public PremiumStdrBasVO getPremiumStdInfoByPremiumId(String premiumId) {
		return ppmMapper.getPremiumStdInfoByPremiumId(premiumId);
	}
	@Override
	public PrEhgtPcRltmBasVO getprEhgtPcFirstByToday() {
		return ppmMapper.getprEhgtPcFirstByToday();
	}

	@Override
	public List<PremiumSetPriceVO> getPrimiumLivePriceList(PremiumSetPriceVO vo) {
		return ppmMapper.getPrimiumLivePriceList(vo);
	}


	@Override
	public void insertAndUpdatePremiumBrandDtlLotDtlRls(String premiumId) {
		ppmMapper.insertAndUpdatePremiumBrandDtlLotDtlRls(premiumId);
	}


	@Override
	public int getPremiumDuplicateCnt(PremiumStdrBasVO vo) {
		return ppmMapper.getPremiumDuplicateCnt(vo);
	}

	@Override
	public List<PremiumSetPriceVO> getSetPrimiumFixPriceList(PremiumSetPriceVO psVO) {
		return ppmMapper.getSetPrimiumFixPriceList(psVO);
	}

	@Override
	public String getAvrgPurchsPrmpc(PremiumSetPriceVO vo) {
		PremiumAvrgPurchsPrmpcVO retVO = ppmMapper.getAvrgPurchsPrmpc(vo);
		if(retVO == null) {
			return null;
		} else {
			return retVO.getHghnetprcAvrgPurchsPrmpc().toString();
		}
	}

	@Override
	public void deletePremiumPrice(List<PremiumStdrBasVO> vo) throws Exception {
		PremiumStdrBasVO premiumStdrBasVO = null;
		for(int i = 0; i < vo.size(); i++) {
			premiumStdrBasVO = vo.get(i);
			premiumStdrBasVO.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			premiumStdrBasVO.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			ppmMapper.deletePremiumPrice(premiumStdrBasVO);
			ppmMapper.insertPremiumPriceValidationHst(premiumStdrBasVO);
			
			PremiumStdrBasVO updateVO = ppmMapper.getPastEndDateInfo(premiumStdrBasVO);
			
			if(updateVO != null) {
				//validEndDt
				updateVO.setValidEndDt(premiumStdrBasVO.getValidEndDt());
				updateVO.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				ppmMapper.updatePastDt(updateVO);
			}
		}
		redisPubSubService.publishMessage(premiumUri, premiumUri, "U");
		pcInfoService.setPremiumInfoListByRedisData();
	}

	@Override
	public List<PremiumMonFxEvaluationCashVO> get6FxMonEvalutaion() {
		return ppmMapper.get6FxMonEvalutaion();
	}
	@Override
	public List<PremiumDetailProfitAndLoseVO> getPremiumDetailProfitAndLoseUpdate(PremiumDetailProfitAndLoseVO vo) {
		return ppmMapper.getPremiumDetailProfitAndLoseUpdate(vo);
	}
	@Override
	public void updatePremiumStdrItmAt(PremiumStdrBasVO vo) {
		int tmp = ppmMapper.selectPremiumStdrItmAt(vo);
		if(tmp > 0) {
			ppmMapper.updatePremiumStdrItmAt(vo);
		}
	}

	@Override
	public PremiumStdrBasVO getPremiumDuplicatePremiumId(PremiumStdrBasVO vo) {
		return ppmMapper.getPremiumDuplicatePremiumId(vo);
	}	

	@Override
	public List<PremiumSetPriceVO> getSetPrimiumLivePriceDetailList(PremiumSetPriceVO psVO) {
		return ppmMapper.getSetPrimiumLivePriceDetailList(psVO);
	}
	@Override
	public int getHghnetprcCount(PremiumStdrBasVO vo) {
		return ppmMapper.getHghnetprcCount(vo);
	}
	@Override
	public List<PremiumSetPriceVO> getSetPrimiumFixPriceDetailList(PremiumSetPriceVO vo) {
		return ppmMapper.getSetPrimiumFixPriceDetailList(vo);
	}
	@Override
	public PremiumStdrBasVO getPremiumDuplicatePremiumId2(PremiumStdrBasVO vo) {
		return ppmMapper.getPremiumDuplicatePremiumId2(vo);
	}
	@Override
	public LmeEvalCashVO getOneDayAgoLmeEvalCash() {
		return ppmMapper.getOneDayAgoLmeEvalCash();

	}

	@Override
	public PremiumStdrBasVO getMetalItmStdr(PremiumSetPriceVO vo) {
		PremiumStdrBasVO retVo = ppmMapper.getMetalItmStdr(vo);

		if(retVo != null) {
			retVo.setRpsItmAt("Y");
		}

		return retVo;
	}

	@Override
	public int duplicateCheckAjax(PremiumSetPriceVO vo) throws Exception {
		return ppmMapper.getDuplicateCnt(vo);
	}

	@Override
	public String premiumdDuplicateCheck(PremiumStdrBasVO vo) throws Exception {
		String result = null;
		PremiumStdrBasVO checker = ppmMapper.getPremiumDuplicatePremiumId(vo);
		if(checker != null) {
			result = checker.getValidEndDt();
		}else {
			checker = ppmMapper.getPremiumDuplicatePremiumId2(vo);
			if(checker != null) {
				result = checker.getValidBeginDt();
				SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
				Date parsedDate = formatter.parse(result);
				Calendar cal = Calendar.getInstance();
				cal.setTime(parsedDate);
				cal.add(Calendar.HOUR_OF_DAY, -1);
				result = formatter.format(cal.getTime());
			}
		}
		return result;
	}
	/***
	 * 프리미엄가격 등록
	 *  1. 신규 등록
	 *     # 신규적용일 ~ 9999년 12월 31일 23시 59분 59초
	 *  2. 기존등록 프리미엄 시작일 - 신규적용일 - 기존등록 프리미엄 종료일
	 *      # 신규적용일 > 오늘날짜 일때
	 *           : 신규적용일 기준으로 등록되기때문에 오늘날짜보다 이후로 판단 (영업시간 이전)
	 *           : 기존 프리미엄 종료일 > 신규적용일 일떄
	 *               '기존등록 프리미엄 시작일 - 신규적용일 - 기존등록 프리미엄 종료일' 의 형태
	 *                    => 기존 등록된 프리미엄의 종료일시를 신규적용일 -1초
	 *                    => 신규프리미엄은 신규적용일시 ~ 9999년12월31일23시59분59초
	 *      # 신규적용일 = 오늘날짜 일때
	 *           :영업시간 전, 영업시간 후로 구분
	 *               ;영업시간 전
	 *                    => 기존 프리미엄 종료 시간을 신규적용일(오늘날짜) + 현재시분초
	 *                    => 신규 프리미엄 신규적용일(오늘날짜) + 현재시분초 + 1초 ~ 9999년12월31일23시59분59초
	 *               ;영업시간 후 : 적용 불가
	 *      # 신규적용일 < 오늘날짜 일때
	 *          : 영업시간이 지났기 떄문에 불가능
	 *  3. 신규적용일 - 기존등록 프리미엄 시작일 -기존등록 프리미엄 종료일
	 *      # 2030년 9월14일 ~ 9999년 12월31일 데이터만 있을때,  적용시작일을 2030년 9월 14일 이전으로 설정 한 경우
	 *          : 신규적용일 시작일 ~ 기존등록된 프리미엄 시작일 - 1 일(신규등록시작일의 END_DT)
	 */
	@Override
	public String insertPremiumPrice(PremiumStdrBasVO vo) throws Exception {
		//[시작일 ~ 종료일]구간의 적용일자가 포함된 유효데이터 확인 (신규등록인지, 업데이트인지 확인)
		PremiumStdrBasVO stdrVo = ppmMapper.getPremiumDuplicatePremiumId(vo);
		if(stdrVo != null) {  //신규 등록 아닐때
			//신규 적용시작일 >= 기등록된 시작일
			if (DateUtil.compareToCalerdar(vo.getValidBeginDt().replace("-", "").substring(0,8), stdrVo.getValidBeginDt().substring(0,8)) >= 0) {
				//오늘날짜 < 신규 적용 시작일
				if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), vo.getValidBeginDt().replace("-", "").substring(0,8)) < 0) {
					//등록되어있는 프리미엄의 종료일자가 신규적용일자보다 큰지 확인
					PremiumStdrBasVO stdrVo2 = ppmMapper.getPremiumDuplicatePremiumId3(vo);
		        	if(stdrVo2 != null) {  //기존 프리미엄 종료일 > 신규적용일
			        	vo.setDmlType("UPDATE_INSERT2");
		        		PremiumStdrBasVO tmpVo = new PremiumStdrBasVO();
		        		//프리미엄 아이디 설정
			        	vo.setPremiumId(stdrVo.getPremiumId());
			        	//vo => tmpVo 복사 (vo는 추후 저장을 위해 임시변수 tmpVo에 복사)
			        	BeanUtils.copyProperties(vo, tmpVo);
			        	//기존 프리미엄 종료일을 적용일로 업데이트 하기 위함
			        	tmpVo.setValidEndDt(vo.getValidBeginDt());
			        	//기존 프리미엄종료일을 신규적용일로 변경을 위한 update
			        	tmpVo.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			        	tmpVo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			        	ppmMapper.updatePremiumPriceValidation(tmpVo);
			        	ppmMapper.insertPremiumPriceValidationHst(tmpVo);
			        	//신규 채번을 위한 프리미엄 번호 null 처리
			        	vo.setPremiumId(null);
		        	} else {
		        		return "적용이 불가능 합니다.";
		        	}
				} else if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), vo.getValidBeginDt().replace("-", "").substring(0,8)) == 0) { //오늘 날짜랑 같을때
					PremiumStdrBasVO stdrVo2 = ppmMapper.getPremiumDuplicatePremiumId2(vo);		//기존에 등록된 프리미엄 가격설정 조회
					
					if(stdrVo2 == null) {
						PremiumStdrBasVO copiedVo = new PremiumStdrBasVO();
						BeanUtils.copyProperties(vo, copiedVo);
						copiedVo.setDmlType("UPDATE_INSERT6");
						
						copiedVo.setValidEndDt(vo.getValidBeginDt());
						copiedVo.setPremiumId(stdrVo.getPremiumId());
						
						copiedVo.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
						copiedVo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
						
						ppmMapper.updatePremiumPriceValidation(copiedVo);
						ppmMapper.insertPremiumPriceValidationHst(copiedVo);
						
						vo.setDmlType("UPDATE_INSERT6");
						vo.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
						vo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
						//신규 등록을 위한 프리미엄 아이디 NULL
						vo.setPremiumId(null);
						vo.setValidEndDt(vo.getValidEndDt());  //종료시간은 기존 종료시간
					}
					//오늘날짜 = 신규 적용일
					//기존 프리미엄 설정 종료일은 현재시간, 신규프리미엄 시작일은 현재시간 + 1초
					//22-04-18 : 설정 항목으로 "적용시작시간" 추가
					else {
						String validBeginTime = vo.getValidBeginDt().replace("-", "").replace(" ", "").substring(0, 10);
						if(StringUtils.equals(stdrVo2.getValidBeginDt().substring(0, 10), validBeginTime)) {
							return "동일한 적용시작시간의 데이터가 존재합니다.";
						} else {
							PremiumStdrBasVO copiedVo = new PremiumStdrBasVO();
							BeanUtils.copyProperties(vo, copiedVo);
							copiedVo.setDmlType("UPDATE_INSERT6");
							
							String copyValidBeginDt = vo.getValidBeginDt();
							
							copiedVo.setValidEndDt(copyValidBeginDt);	//기등록된 프리미엄 가격설정의 종료시간을 신규 프리미엄 가격설정의 "시작시간 -1초"로 업데이트 하기위한 값세팅(쿼리문에서 -1초 처리)
							copiedVo.setPremiumId(stdrVo.getPremiumId());
							
							copiedVo.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
							copiedVo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
							
							ppmMapper.updatePremiumPriceValidation(copiedVo);
							ppmMapper.insertPremiumPriceValidationHst(copiedVo);
							
							vo.setDmlType("UPDATE_INSERT6");
							vo.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
							vo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
							//신규 등록을 위한 프리미엄 아이디 NULL
							vo.setPremiumId(null);
							SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
							Date parsedDate = formatter.parse(stdrVo2.getValidBeginDt());
							formatter.applyPattern("yyyyMMdd HH:mm:ss");
							String validEndDt = formatter.format(parsedDate);	//기등록된 프리미엄 가격설정의 종료시간을 포메팅
							vo.setValidEndDt(validEndDt);  //종료시간은 기존 종료시간
						}
					}
				} else if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), vo.getValidBeginDt().replace("-", "")) > 0) { //오늘날짜보다 작을때
					return "적용일자는 오늘 날짜 이후만 가능합니다.";
				}
			}
        } else {   //신규 등록O
	       	PremiumStdrBasVO stdrVo2 = ppmMapper.getPremiumDuplicatePremiumId2(vo);
	       	if(stdrVo2 != null) {
	       		//적용일자가 시작일자보다 작을때
	       		//예) 2030년 9월14일 ~ 9999년 12월31일 데이터만 있을때, 현재 날짜로 등록시 현재날짜~ 2030년9월 13일까지 등록
	       		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
				Date parsedDate = formatter.parse(stdrVo2.getValidBeginDt());
				formatter.applyPattern("yyyyMMdd HH:mm:ss");
				String validBeginDt = formatter.format(parsedDate);	//기등록된 프리미엄 가격설정의 시작시간을 포메팅
				
	       		vo.setDmlType("BEFORE_INSERT2");
	       		vo.setValidEndDt(validBeginDt);
	       	} else {
	       		vo.setDmlType("BEFORE_INSERT");
	       	}
		}
		//프리미엄 ID채번
		String metal = String.format("%02d", Integer.parseInt(vo.getMetalCode()));
		String premiumId = (vo.getPremiumId() == null || "".equals(vo.getPremiumId()) ) ? "PI" + metal + assignService.selectAssignValue("IT", "PREMIUM", "999999", "premiumNo", 6) : vo.getPremiumId();
		vo.setPremiumId(premiumId);
		insertAndUpdatePremimunPrice(vo);

		return "저장 되었습니다.";
	}
	
	@Override
	public String updatePremiumPrice(PremiumStdrBasVO vo) throws Exception {
		vo.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		vo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));

		/*********************************************************
		 * 1. 프리미엄 가격등록 (현시점 프리미엄유효데이터 존재할때 VS 유효데이터 존재X OR 신규입력일경우)
		 *   [유효데이터 존재시]
		 *      유효시작 종료일구간의 적용일자가 포함된 유효데이터 확인
		 *        개장 전 : UPDATE 진행
		 *        개장 후 : 유효종료일자 23시 59분 업데이트
                            프리미엄 ID 채번
                            INSERT 진행
		 *      프리미엄 업데이트 진행
		 *   [유효데이터X OR 신규입력]
		 *      프리미엄 아아디 채번 후 프리미엄 INSERT 진행
		 *********************************************************/
		//유효데이터 확인
		PremiumStdrBasVO stdrVo = ppmMapper.getPremiumDuplicatePremiumId(vo);
		if(stdrVo != null) {
			if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), stdrVo.getValidBeginDt().substring(0,8)) > 0) { //오늘날짜보다 작을때
				return "시작일이 오늘날짜 이후만 업데이트 가능합니다.";
			} else if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), vo.getValidBeginDt().replace("-", "").substring(0,8)) == 0) { //오늘 날짜랑 같을때
				if("N".equals(chekBeginTime(vo))){	//영업시간 후
					return "영업시간 후에는 업데이트가 불가능 합니다.";
				}
			}
			//단순업데이트
		    vo.setDmlType("UPDATE");
		    vo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		    insertAndUpdatePremimunPrice(vo);

        } else {
        	return "해당데이터가 존재 하지 않아 업데이트 불가능 합니다.";
		}
		return "저장 되었습니다.";
	}
	
	public String chekBeginTime(PremiumStdrBasVO vo) throws Exception {
		return "Y";
	}
	
	public void insertAndUpdatePremimunPrice(PremiumStdrBasVO vo) throws Exception {
		/**
		 *********************************************************
		 * 1. 상품 기준 프리미엄 기본 저장
		 * 2. 상품 권역 프리미엄 기본 저장
		 * 3. 상품 브랜드그룹 프리미엄 기본 저장
		 * 4. 상품 브랜드 프리미엄 기본 저장
		 * 5. 상품 프리미엄 브랜드 상세 저장
		 * 6. 상품 프리미엄 B/L 상세 저장
		 *********************************************************
		 * */
		//String ftrsProcessAt = vo.getFtrsprocessat();
		String ftrsProcessAt = vo.getFtrsprocessat() == null ? "N" : vo.getFtrsprocessat();

		/*********************************************************
		 * 1. 상품 기준 프리미엄 기본
		 *   파리미터로 받은 기준 정보 저장
		 *   상품 프리미엄 기준 정보 저장 (MERGE)
		 *      : 데이터가 존재시 UPDATE, 데이터 미존재시 INSERT
		 *********************************************************/
		//vo null값 변경 수정 (xml에서 ISNULL 함수 작동하지 않는 이슈로 자바에서 처리)
		if(vo.getSleMthdCode() == null) vo.setSleMthdCode("01");  // 01: Live   02:고정가
		if(vo.getStdrEhgtPc() == null) vo.setStdrEhgtPc(new BigDecimal("0"));
		if(vo.getPremiumStdrAmountKrw() == null) vo.setPremiumStdrAmountKrw(new BigDecimal("0"));
		if(vo.getStdrItmAt() == null) vo.setStdrItmAt("N");
		if(vo.getPremiumStdrDstrctLclsfCode() == null) vo.setPremiumStdrDstrctLclsfCode("");
		if(vo.getPremiumStdrBrandGroupCode() == null) vo.setPremiumStdrBrandGroupCode("");
		if(vo.getHghnetprcAvrgPurchsPrmpc()== null) vo.setHghnetprcAvrgPurchsPrmpc(new BigDecimal("0"));
		vo.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		vo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));

		//상품_프리미엄 기준 기본정보
		//데이터가 존재시 UPDATE, 데이터 미존재시 INSERT
		//기준 아이템여부 'Y' 일때 업데이트
//		if("Y".equals(vo.getStdrItmAt())) {
//			//설정되어 있던 기준아이템 여부 'N' 처리
//			this.updatePremiumStdrItmAt(vo);
//		}
//		this.insertAndUpdatePremiumStdrPrice(vo);
//		this.insertPremiumPriceValidationHst(vo);
		ppmMapper.insertAndUpdatePremiumStdrPrice(vo);
		ppmMapper.insertPremiumPriceValidationHst(vo);
		redisPubSubService.publishMessage(premiumUri, premiumUri, "U");
		pcInfoService.setPremiumInfoListByRedisData();
		
		//그리드 ROW수 체크
		int count = vo.getGridList().size();
		/*********************************************************
		 * 2. 상품 권역 프리미엄 기본
		 *   권역 코드 기준으로 저장을 위해 리스트 생성
		 *   그리드데이터 리스트를 다른 리스트에 복사 (권역 기준)
		 *      : 권역값이 존재할때 리스트 ADD
		 *        ( 고정가, LIVE 에 따른 VO 각각 지정 / LIVE : dstrctChangeAmount, 고정가 : hghnetprcDstrctChangeAmount)
		 *   복사된 권역기준의 그리드리스트에서 중복 제거
		 *   상품 프리미엄 권역 기본 저장
		 *********************************************************/
		//그리드 복사 (권역대분류 기준)
		PremiumDstrctBasVO premiumDstrctBasVO = null;
		//권역 코드 기준으로 저장을 위해 리스트 생성
		List<PremiumDstrctBasVO> premiumDstrctBasList = new ArrayList<PremiumDstrctBasVO>();
		//그리드데이터 리스트를 다른 리스트에 복사 (권역 기준)
		for(int i = 0; i < count; i++) {
			if(vo.getGridList().get(i).getDstrctLclsfCode() != null) {
				premiumDstrctBasVO = new PremiumDstrctBasVO();
				premiumDstrctBasVO.setPremiumId(vo.getPremiumId());
				premiumDstrctBasVO.setDstrctLclsfCode(vo.getGridList().get(i).getDstrctLclsfCode());
				premiumDstrctBasVO.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				premiumDstrctBasVO.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));

				 if("N".equals(ftrsProcessAt)) premiumDstrctBasVO.setHghnetprcDstrctChangeAmount(vo.getGridList().get(i).getDstrctChangeAmount());
				 else premiumDstrctBasVO.setDstrctChangeAmount(vo.getGridList().get(i).getDstrctChangeAmount());

				premiumDstrctBasList.add(premiumDstrctBasVO);
			}
		}
		if(premiumDstrctBasList != null && premiumDstrctBasList.size() > 0) {
			//복사된 권역기준의 그리드리스트에서 중복 제거
			premiumDstrctBasList = premiumDstrctBasList.stream().distinct().collect(Collectors.toList());
			//상품 프리미엄 권역 기본 저장
//			this.insertAndUpdatePremiumDstrctPrice(premiumDstrctBasList);
//			this.insertAndUpdatePremiumDstrctPriceHst(premiumDstrctBasList);
			for (PremiumDstrctBasVO premiumDstrctBasVO2 : premiumDstrctBasList) {
				ppmMapper.insertAndUpdatePremiumDstrctPrice(premiumDstrctBasVO2);
				ppmMapper.insertAndUpdatePremiumDstrctPriceHst(premiumDstrctBasVO2);
			}
		}


		/*********************************************************
		 * 4. 상품 브랜드 그룹 프리미엄 기본
		 *   브랜드 그룹 코드 기준으로 저장을 위해 리스트 생성
		 *   그리드데이터 리스트를 다른 리스트에 복사 (브랜드 그룹 기준)
		 *      : 브랜드 그룹값이 존재할때 리스트 ADD
		 *        ( 고정가, LIVE 에 따른 VO 각각 지정 / LIVE : brandGroupChangeAmount, 고정가 : hghnetprcBrandGroupChangeAmount)
		 *   복사된 브랜드그룹 그리드리스트에서 중복 제거
		 *   상품 프리미엄 브랜드 그룹 기본 저장 (MERGE)
		 *********************************************************/
		PremiumBrandGroupBasVO premiumBrandGroupBasVO = null;
		//브랜드 그룹 코드 기준으로 저장을 위해 리스트 생성
		List<PremiumBrandGroupBasVO> premiumBrandGroupBasList = new ArrayList<PremiumBrandGroupBasVO>();
		for(int i = 0; i < count; i++) {
			if(vo.getGridList().get(i).getBrandGroupCode() != null) {
				premiumBrandGroupBasVO = new PremiumBrandGroupBasVO();
				premiumBrandGroupBasVO.setPremiumId(vo.getPremiumId());
				premiumBrandGroupBasVO.setDstrctLclsfCode(vo.getGridList().get(i).getDstrctLclsfCode());
				premiumBrandGroupBasVO.setBrandGroupCode(vo.getGridList().get(i).getBrandGroupCode());
				premiumBrandGroupBasVO.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				premiumBrandGroupBasVO.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));

				if("N".equals(ftrsProcessAt)) premiumBrandGroupBasVO.setHghnetprcBrandGroupChangeAmount(vo.getGridList().get(i).getBrandGroupChangeAmount());
				else premiumBrandGroupBasVO.setBrandGroupChangeAmount(vo.getGridList().get(i).getBrandGroupChangeAmount());

				premiumBrandGroupBasList.add(premiumBrandGroupBasVO);
			}
		}
		if(premiumBrandGroupBasList != null && premiumBrandGroupBasList.size() > 0) {
			//중복 제거
			premiumBrandGroupBasList = premiumBrandGroupBasList.stream().distinct().collect(Collectors.toList());
			//상품 프리미엄 브랜드 그룹 기본 저장
//			this.insertAndUpdatePremiumBrandGroupPrice(premiumBrandGroupBasList);
//			this.insertAndUpdatePremiumBrandGroupPriceHst(premiumBrandGroupBasList);
			for (PremiumBrandGroupBasVO premiumBrandGroupBasVO2 : premiumBrandGroupBasList) {
				ppmMapper.insertAndUpdatePremiumBrandGroupPrice(premiumBrandGroupBasVO2);
				ppmMapper.insertAndUpdatePremiumBrandGroupPriceHst(premiumBrandGroupBasVO2);
			}
		}

		/*********************************************************
		 * 5. 상품 브랜드 프리미엄 기본
		 *   0000000000의 코드로 권역/브랜드그룹 당 1개의 브랜드 코드 저장 (FO 메인차트의 판매가격)
		 *      : 중복제거된 프리미엄 브랜드그룹 코드에 대한 각각 1개의 데이터 저장
		 *   브랜드 코드 기준으로 저장을 위해 리스트 생성
		 *   그리드데이터 리스트를 다른 리스트에 복사 (브랜드 기준)
		 *      : 브랜드 그룹값이 존재할때 리스트 ADD
		 *        ( 고정가, LIVE 에 따른 VO 각각 지정)
		 *      : 판매프리미엄 가격 = 프리미엄 기준금액 + 권역 변동금 + 브랜드그룹 변동금 + 브랜드 변동금
		 *   복사된 리스트에서 중복 제거
		 *      : 프리미엄 번호 채번 (브랜드 코드가 유효할때)
		 *      : 상품 프리미엄 브랜드 기본 저장 (MERGE)
		 *********************************************************/
		//브랜드 권역/그룹별로 무관의 브랜드 코드 '0000000000' 생성 필요
		List<PremiumBrandBasVO> premiumBrandList2 = new ArrayList<>();
		if(premiumBrandGroupBasList !=null &&premiumBrandGroupBasList.size() > 0) {
			//권역, 브랜드별 ROW수만큼 무관 저장을 위한 리스트 데이터 'premiumBrandList2'에 추가
			for(int i = 0; i < premiumBrandGroupBasList.size(); i++) {
				PremiumBrandBasVO tmpVo = new PremiumBrandBasVO();
				tmpVo.setPremiumId(premiumBrandGroupBasList.get(i).getPremiumId());
				tmpVo.setDstrctLclsfCode(premiumBrandGroupBasList.get(i).getDstrctLclsfCode());
				tmpVo.setBrandGroupCode(premiumBrandGroupBasList.get(i).getBrandGroupCode());
//				tmpVo.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
//				tmpVo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				//기존 브랜드 그룹과 동일한 데이터 복사
				//기존 브랜드그룹과 무관 브랜드 그룹 별개 저장
				premiumBrandList2.add(tmpVo);
			}
			//브랜드 무관에 대한 프리미엄번호 채번, 브랜드코드 '0000000000' 설정
			//22-04-25 변경점 : 브랜드코드만 설정하도록 변경
			if(premiumBrandList2 != null) {
				for(int i = 0; i < premiumBrandList2.size(); i++) {
//					SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//			        Calendar c1 = Calendar.getInstance();
//			        String strToday = sdf.format(c1.getTime());
//
//					String metal = String.format("%02d", Integer.parseInt(vo.getMetalCode()));
			        //프리미엄 번호 : PN + 메탈코드 + 오늘날짜 + 순번(6자리)
//			        String premiumNo = "PN" + metal + strToday + assignService.selectAssignValue("IT", "PREMIUMNO", "999999", "premiumNo", 6);
//			        premiumBrandList2.get(i).setPremiumNo(premiumNo);
			        premiumBrandList2.get(i).setBrandCode("0000000000");
				}
				//this.insertAndUpdatePremiumBrandPrice(premiumBrandList2);
			}
		}

		PremiumBrandBasVO premiumBrandBasVO = null;
		//브랜드 코드 기준으로 저장을 위해 리스트 생성
		List<PremiumBrandBasVO> premiumBrandBasList = new ArrayList<PremiumBrandBasVO>();
		//그리드데이터 리스트를 다른 리스트에 복사 (브랜드 기준)
		for(int i = 0; i < count; i++) {
			if(vo.getGridList().get(i).getBrandCode() != null) {
				//판매프리미엄 가격 = 프리미엄 기준금액 + 권역 변동금 + 브랜드그룹 변동금 + 브랜드 변동금
				BigDecimal dstrctChangeAmount = vo.getGridList().get(i).getDstrctChangeAmount() == null ? new BigDecimal(0) : vo.getGridList().get(i).getDstrctChangeAmount();
				BigDecimal brandGroupChangeAmount = vo.getGridList().get(i).getBrandGroupChangeAmount() == null ? new BigDecimal(0) : vo.getGridList().get(i).getBrandGroupChangeAmount();

				premiumBrandBasVO = new PremiumBrandBasVO();
				premiumBrandBasVO.setPremiumId(vo.getPremiumId());
				premiumBrandBasVO.setDstrctLclsfCode(vo.getGridList().get(i).getDstrctLclsfCode());
				premiumBrandBasVO.setBrandGroupCode(vo.getGridList().get(i).getBrandGroupCode());
				premiumBrandBasVO.setBrandCode(vo.getGridList().get(i).getBrandCode());
				premiumBrandBasVO.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				premiumBrandBasVO.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));

				BigDecimal brandChangeAmount =  null;
				brandChangeAmount = vo.getGridList().get(i).getBrandChangeAmount() == null ? new BigDecimal(0) : vo.getGridList().get(i).getBrandChangeAmount();

				if("Y".equals(ftrsProcessAt)) { //LIVE
					BigDecimal premiumStdrAmountKRW = vo.getPremiumStdrAmountKrw() == null ? new BigDecimal(0) : vo.getPremiumStdrAmountKrw();
					BigDecimal slePremiumAmount = dstrctChangeAmount.add(brandGroupChangeAmount).add(brandChangeAmount).add(premiumStdrAmountKRW);  //판매 프리미엄 가격
					premiumBrandBasVO.setSlePremiumAmount(slePremiumAmount);
					premiumBrandBasVO.setBrandChangeAmount(brandChangeAmount);
				} else { //고정가
					BigDecimal ghnetprcAvrgPurchsPrmpc = vo.getHghnetprcAvrgPurchsPrmpc();
					BigDecimal hghnetprcSleAmount = dstrctChangeAmount.add(brandGroupChangeAmount).add(brandChangeAmount).add(ghnetprcAvrgPurchsPrmpc);
					premiumBrandBasVO.setHghnetprcSleAmount(hghnetprcSleAmount);
					premiumBrandBasVO.setHghnetprcBrandChangeAmount(brandChangeAmount);
				}
				premiumBrandBasList.add(premiumBrandBasVO);
			}
		}


		//브랜드 무관 가격 판매 가격 설정
		for(int j = 0; j < premiumBrandList2.size(); j++) {
			for(int i = 0; i < count; i++) {
				if(vo.getGridList().get(i).getBrandCode() != null) {
					//브랜드 무관에 대한 리스트의 권역, 브랜드 그룹코드를 계산을 위해 그리드의 권역 브랜드그룹과 동일한 ROW 검색
					if(premiumBrandList2.get(j).getDstrctLclsfCode().equals(vo.getGridList().get(i).getDstrctLclsfCode())
							&& premiumBrandList2.get(j).getBrandGroupCode().equals(vo.getGridList().get(i).getBrandGroupCode())) {
							BigDecimal dstrctChangeAmount = vo.getGridList().get(i).getDstrctChangeAmount() == null ? new BigDecimal(0) : vo.getGridList().get(i).getDstrctChangeAmount();
							BigDecimal brandGroupChangeAmount = vo.getGridList().get(i).getBrandGroupChangeAmount() == null ? new BigDecimal(0) : vo.getGridList().get(i).getBrandGroupChangeAmount();

							premiumBrandBasVO = new PremiumBrandBasVO();
							premiumBrandBasVO.setPremiumId(vo.getPremiumId());
							premiumBrandBasVO.setDstrctLclsfCode(vo.getGridList().get(i).getDstrctLclsfCode());
							premiumBrandBasVO.setBrandGroupCode(vo.getGridList().get(i).getBrandGroupCode());
							premiumBrandBasVO.setBrandCode(premiumBrandList2.get(j).getBrandCode());

							if("Y".equals(ftrsProcessAt)) { //LIVE
								//프리미엄 원화 가격
								BigDecimal premiumStdrAmountKRW = vo.getPremiumStdrAmountKrw() == null ? new BigDecimal(0) : vo.getPremiumStdrAmountKrw();
								//판매가격 = 프리미엄 원화 가격 + 권역 변동금 원화 가격 +브랜드 그룹 변동금 원화 가격
								BigDecimal slePremiumAmount = dstrctChangeAmount.add(brandGroupChangeAmount).add(premiumStdrAmountKRW);  //판매 프리미엄 가격
								premiumBrandBasVO.setSlePremiumAmount(slePremiumAmount);

							} else { //고정가
								BigDecimal ghnetprcAvrgPurchsPrmpc = vo.getHghnetprcAvrgPurchsPrmpc();
								BigDecimal hghnetprcSleAmount = dstrctChangeAmount.add(brandGroupChangeAmount).add(ghnetprcAvrgPurchsPrmpc);
								premiumBrandBasVO.setHghnetprcSleAmount(hghnetprcSleAmount);
							}
							//브랜드 무관이 아닌 리스트에 브랜드 무관 데이터 추가
							premiumBrandBasList.add(premiumBrandBasVO);
							break;
					}
				}
			}
		}

		//중복 제거
		premiumBrandBasList = premiumBrandBasList.stream().distinct().collect(Collectors.toList());
		if(premiumBrandBasList != null ) {
			int brandCount = premiumBrandBasList.size();
			for(int i = 0; i < brandCount; i++) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		        Calendar c1 = Calendar.getInstance();
		        String strToday = sdf.format(c1.getTime());

		        String metal = String.format("%02d", Integer.parseInt(vo.getMetalCode()));
		        //프리미엄 번호 : PN + 메탈코드 + 오늘날짜 + 순번(6자리)
		        String premiumNo = "PN" + metal + strToday + assignService.selectAssignValue("IT", "PREMIUMNO", "999999", "premiumNo", 6);
				premiumBrandBasList.get(i).setPremiumNo(premiumNo);

				premiumBrandBasList.get(i).setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				premiumBrandBasList.get(i).setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				
				ppmMapper.insertAndUpdatePremiumBrandPrice(premiumBrandBasList.get(i));
				ppmMapper.insertAndUpdatePremiumBrandPriceHst(premiumBrandBasList.get(i));
			}
			redisPubSubService.publishMessage(premiumUri, premiumUri, "U");
			pcInfoService.setPremiumInfoListByRedisData();
//			this.insertAndUpdatePremiumBrandPrice(premiumBrandBasList);
//			this.insertAndUpdatePremiumBrandPriceHst(premiumBrandBasList);
		}

		/*********************************************************
		 * 6. 상품 프리미엄 브랜드 상세
		 *   프리미엄 아이디를 통해, 프리미엄 번호 리스트 및 브랜드 정보를 조회한다.
		 *   조회된 프리미엄 번호, 브랜드 정보에 대한 각각의 정보 조회
		 *********************************************************/
		if("Y".equals(ftrsProcessAt)) {
//			this.insertAndUpdatePremiumBrandDtlPrice(vo);
//			this.insertAndUpdatePremiumBrandDtlPriceHst(vo);
			ppmMapper.insertAndUpdatePremiumBrandDtlPrice(vo);
			ppmMapper.insertAndUpdatePremiumBrandDtlPriceHst(vo);
		}


		/*********************************************************
		 * 7. B/L 프리미엄 상세
		 *   프리미언 기준 기본 테이블의 ITM_SN, PREMIUN_ID를 이용해
		 *  상품테이이블,PO테이블 정보 조회 후 INSERT
		 *********************************************************/
		//this.insertAndUpdatePremiumBlDtlPrice(vo.getPremiumId());

		/*********************************************************
		 * 9. 상품_프리미엄 브랜드 상세 BL 상세 관계
		 *   INSERT된 프리미엄상품의 PREMIUM_ID 기준으로
		 *   프리미엄 상품 테이블과 상품,PO테이블의 BL번호와 관계 설정
		 *********************************************************/
		//this.insertAndUpdatePremiumBrandDtlBlDtlRls(vo);

		/*********************************************************
		 * 8. 상품_프리미엄 브랜드 상세 LOT 상세 관계
		 *   INSERT된 프리미엄상품의 PREMIUM_ID 기준으로
		 *   상품테이블, B/L테이블, 브랜드 테이블에 대한 LOT정보 조회
		 *********************************************************/
		//this.insertAndUpdatePremiumBrandDtlLotDtlRls(vo.getPremiumId());

		/*********************************************************
		 * 10. 상품_프리미엄 LOT 상세
		 *   INSERT된 프리미엄상품의 PREMIUM_ID 기준으로
		 *
		 *********************************************************/
		//this.insertAndUpdatePremiumLotDtlPrice(vo.getPremiumId());
	}	

	@Override
	public PremiumStdrBasVO getSelectedPremium(PremiumStdrBasVO vo) {	
		return ppmMapper.getSelectedPremium(vo);
	}

	@Override
	public String getEhgtPcRltm() {
		return ppmMapper.getEhgtPcRltm();
	}
	
	/**
	 * <pre>
	 * 처리내용: 다이나믹 프리미엄 저장
	 * </pre>
	 *
	 * @date 2023. 10. 17.
	 * @author jdrttl
	 * @history
	 * ------------------------------------------------
	 * 변경일           작성자        변경내용
	 * ------------------------------------------------
	 * 2023. 10. 17.  jdrttl       최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */	
	@Override
	public String savePremiumDynmPrice(PremiumStdrBasVO vo) throws Exception {

		PremiumStdrBasVO premiumStdrBasVO = ppmMapper.getSelectedPremium(vo);
		
		String nowPremiumId = premiumStdrBasVO.getPremiumId(); //현재 프리미엄 ID
		
		//현재프리미엄 - 변경프리미엄 차액
		BigDecimal dfnntPremiumStdrAmount = vo.getPremiumStdrAmount().subtract(premiumStdrBasVO.getPremiumStdrAmount());
		
		//현재 프리미엄 ID 세팅
		vo.setNowPremiumId(nowPremiumId);
		vo.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		
		//프리미엄 ID채번
		String metal = String.format("%02d", Integer.parseInt(vo.getMetalCode()));
		String premiumId =  "PI" + metal + assignService.selectAssignValue("IT", "PREMIUM", "999999", "premiumNo", 6);
		vo.setPremiumId(premiumId);
		
		//현재 적용되고 있는 프리미엄 기준 테이블 복사
		ppmMapper.insertSelectPremiumStrdBas(vo);

		//현재 적용되고 있는 프리미엄 기준으로 권역,브랜드그룹,브랜드 테이블 복사
		ppmMapper.insertSelectPremiumDstrctBas(vo);
		ppmMapper.insertSelectPremiumBrandGroupBas(vo);
		
        //프리미엄 번호 : PN + 메탈코드 + 오늘날짜 + 순번(6자리)
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Calendar c1 = Calendar.getInstance();
        String strToday = sdf.format(c1.getTime());

        //현재 적용되고 있는 프리미엄 브랜드 테이블 조회
        List<PremiumBrandBasVO> PremiumBrandBasVoList = ppmMapper.getSelectedPremiumBrand(vo);
        
        for( PremiumBrandBasVO PremiumBrandBasVo : PremiumBrandBasVoList ) {
            String premiumNo = "PN" + metal + strToday + assignService.selectAssignValue("IT", "PREMIUMNO", "999999", "premiumNo", 6);
            vo.setPremiumNo(premiumNo);
            vo.setNowPremiumNo(PremiumBrandBasVo.getPremiumNo());
            vo.setDfnntPremiumStdrAmount(PremiumBrandBasVo.getSlePremiumAmount().add(dfnntPremiumStdrAmount));
            
    		ppmMapper.insertSelectPremiumBrandBas(vo);
        }
		
		//현재 적용되고 있는 프리미엄 종료일자 수정
		ppmMapper.updateEndDtPremiumStrdBas(vo);
		
		//레디스
		redisPubSubService.publishMessage(premiumUri, premiumUri, "U");
		pcInfoService.setPremiumInfoListByRedisData();
		
		//========다른 _HST 테이블들과 달리 HIST_SN를 생성일시로 사용하고 있어 임시 주석처리=========
		/*
		//현재 적용되고 있는 프리미엄 히스토리 저장
		commonService.insertTableHistory("IT_PREMIUM_STDR_BAS", vo);
		
		//새로 복사된 프리미엄 히스토리 저장
		vo.setPremiumId(nowPremiumId);
		commonService.insertTableHistory("IT_PREMIUM_STDR_BAS", vo);
		
		List<String> primaryKeyList = new ArrayList<>();
		primaryKeyList.add("PREMIUM_ID");
		commonService.insertTableHistory("IT_PREMIUM_DSTRCT_BAS", vo, primaryKeyList);
		commonService.insertTableHistory("IT_PREMIUM_BRAND_GROUP_BAS", vo, primaryKeyList);
		commonService.insertTableHistory("IT_PREMIUM_BRAND_BAS", vo, primaryKeyList);
		*/
		//========다른 _HST 테이블들과 달리 HIST_SN를 생성일시로 사용하고 있어 임시 주석처리=========
		
		return "적용 되었습니다.";
	}

}
