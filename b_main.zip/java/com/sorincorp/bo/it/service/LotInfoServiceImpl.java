package com.sorincorp.bo.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.it.mapper.LotInfoMapper;
import com.sorincorp.bo.it.model.LotInfoVO;

@Service
public class LotInfoServiceImpl implements LotInfoService {

	@Autowired
	private LotInfoMapper lotInfoMapper;

	@Override
	public List<LotInfoVO> selectLotInfoList(LotInfoVO lotInfoVO) throws Exception {
		// TODO Auto-generated method stub
		return lotInfoMapper.selectLotInfoList(lotInfoVO);
	}

	@Override
	public List<LotInfoVO> selectWrhousngList(LotInfoVO lotInfoVO) throws Exception {
		// TODO Auto-generated method stub
		return lotInfoMapper.selectWrhousngList(lotInfoVO);
	}

	@Override
	public List<LotInfoVO> selectOvsiteList(LotInfoVO lotInfoVO) throws Exception {
		// TODO Auto-generated method stub
		return lotInfoMapper.selectOvsiteList(lotInfoVO);
	}
}
