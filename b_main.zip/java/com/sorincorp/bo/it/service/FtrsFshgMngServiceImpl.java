
package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.comm.common.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.FtrsFshgMngMapper;
import com.sorincorp.bo.it.model.FtrsFshgVO;
import com.sorincorp.bo.login.model.Account;

import lombok.extern.slf4j.Slf4j;

/**
 * FtrsFshgMngServiceImpl.java
 * @version
 * @since 2022. 5. 27.
 * @author srec0066
 */
@Slf4j
@Service
public class FtrsFshgMngServiceImpl implements FtrsFshgMngService {

	@Autowired
	private FtrsFshgMngMapper ftrsFshgMngMapper;
	@Autowired
    private UserInfoUtil userInfoUtil;
	@Autowired
	private CommonService commonService;

	/**
	 *	선물/선물환 관리 목록을 조회한다.
	 */
	@Override
	public List<FtrsFshgVO> searchFtrsFshgList(FtrsFshgVO vo) throws Exception {
		return ftrsFshgMngMapper.searchFtrsFshgList(vo);
	}

	/**
	 *	선물/선물환 관리 목록 총 개수를 조회한다.
	 */
	@Override
	public int selectFtrsFshgListTotCnt(FtrsFshgVO vo) throws Exception {
		return ftrsFshgMngMapper.selectFtrsFshgListTotCnt(vo);
	}
	
	/**
	 *	선물/선물환 관리를 등록, 수정 한다.
	 */
	@Override
	public void insertUpdateFtrsFshg(List<FtrsFshgVO> vo) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		String userId ="";
		if(account != null) {
			userId = account.getId();
		}
		String applcDe = vo.get(0).getApplcDe().replaceAll("-", "");
		String postnCode = vo.get(0).getPostnCode();
		List<FtrsFshgVO> dataList = vo.get(0).getFtrsFshgList();
		
		if(dataList.size() > 0) {
			for (FtrsFshgVO data : dataList) {
				data.setApplcDe(applcDe);
				data.setPostnCode(postnCode);
				data.setFrstRegisterId(userId);
				data.setLastChangerId(userId);
				
				FtrsFshgVO deleteAtCheck = ftrsFshgMngMapper.checkFtrsFshgDeleteAt(data);
				if(deleteAtCheck != null && "Y".equals(deleteAtCheck.getDeleteAt())) {
					data.setDeleteAt("N");
				}

				ftrsFshgMngMapper.insertUpdateFtrsFshg(data);
				//ftrsFshgMngMapper.insertFtrsFshgDtlHst(data);
				commonService.insertTableHistory("IT_FTRS_FSHG_MANAGE_DTL", data);
			}
		}
	}
	
	/**
	 *	선물/선물환 관리를 삭제한다.
	 */
	@Override
	public void deleteFtrsFshg(List<FtrsFshgVO> vo) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		String userId ="";
		if(account != null) {
			userId = account.getId();
		}
		String applcDe = vo.get(0).getApplcDe().replaceAll("-", "");
		String postnCode = vo.get(0).getPostnCode();
		List<FtrsFshgVO> dataList = vo.get(0).getFtrsFshgList();
		
		if(dataList.size() > 0) {
			for (FtrsFshgVO data : dataList) {
				data.setApplcDe(applcDe);
				data.setPostnCode(postnCode);
				data.setLastChangerId(userId);
				
				ftrsFshgMngMapper.deleteFtrsFshg(data);
				//ftrsFshgMngMapper.insertFtrsFshgDtlHst(data);
				commonService.insertTableHistory("IT_FTRS_FSHG_MANAGE_DTL", data);
			}
		}
	}

	/**
	 * 등록, 수정, 삭제 대상 데이터 목록을 조회한 vo를 리턴한다.
	 */
	@Override
	public FtrsFshgVO selectFtrsFshg(FtrsFshgVO vo) throws Exception {
		vo.setSearchUseYn(vo.getApplcDe());
		vo.setSearchCondition(vo.getPostnCode());
		vo.setRecordCountPerPage(1000);
		
		List<FtrsFshgVO> dataList = searchFtrsFshgList(vo);
		if(dataList != null) {
			vo.setFtrsFshgList(dataList);
		}
				
		return vo;
	}

	/**
	 *	데이터 등록여부를 확인한다.
	 */
	@Override
	public boolean isAlreadyRegistered(FtrsFshgVO vo) throws Exception {
		String applcDe = vo.getApplcDe().replaceAll("-", "");
		vo.setApplcDe(applcDe);
		
		int cnt = ftrsFshgMngMapper.isAlreadyRegistered(vo);
		if(cnt > 0) {
			return true;
		} 
		return false;
	}
   	
}
