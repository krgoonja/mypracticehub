package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.FixvaleWtTotAmtTariffMgrVO;

public interface FixvaleWtTotAmtTariffMgrService {

	List<FixvaleWtTotAmtTariffMgrVO> selectFixvaleWtTotAmtTariffMgrList(FixvaleWtTotAmtTariffMgrVO fixvaleWtTotAmtTariffMgrVO) throws Exception;

	int selectFixvaleWtTotAmtTariffMgrTotCnt(FixvaleWtTotAmtTariffMgrVO fixvaleWtTotAmtTariffMgrVO) throws Exception;

	int deleteFixvaleWtTotAmtTariffMgr(FixvaleWtTotAmtTariffMgrVO fixvaleWtTotAmtTariffMgrVO) throws Exception;

	List<FixvaleWtTotAmtTariffMgrVO> selectFixvaleWtTotAmtTariffDtlList(FixvaleWtTotAmtTariffMgrVO fixvaleWtTotAmtTariffMgrVO) throws Exception;

	int fixvaleWtTotAmtTariffMgrSave(List<FixvaleWtTotAmtTariffMgrVO> saveList) throws Exception;

}
