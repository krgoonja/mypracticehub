package com.sorincorp.bo.it.service;

import java.util.*;

import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.dynmDiver.model.DynmDiverCommVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.DynmDiverManageMapper;
import com.sorincorp.bo.it.model.DynmDiverMangeVO;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.constants.ExceptionConstants;
import com.sorincorp.comm.dynmDiver.mapper.DynmDiverMapper;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DynmDiverManageSeviceImpl implements DynmDiverManageService {

	@Autowired
	private DynmDiverManageMapper dynmDiverManageMapper;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	MessageUtil messageUtil;

	@Autowired
	private DynmDiverMapper dynmDiverMapper;

	@Autowired
	private RedisPubSubService redisPubSubService;

	@Value("${redisPubsub.uri.properties}")
	private String propertiesUri;

	@Value("${lme.api.diver.url}")
	private String lmeDiverUrl;

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private CommonService commonService;


	public DynmDiverMangeVO selectGtxApiFxrate() throws Exception {
		return dynmDiverManageMapper.selectGtxApiFxrate();
	}

	public Long selectSlePc() throws Exception {
		Long result = dynmDiverMapper.selectNowPc();
		
		if(result== null) {
			return 0L;
		}
		
		return result;
	}

	public DynmDiverMangeVO selectDiverAt() throws Exception {
		return dynmDiverManageMapper.selectDiverAt();
	}

	public void updateDiverAt(DynmDiverMangeVO diverVo) throws Exception {
		dynmDiverManageMapper.updateDiverAt(diverVo);
	}

	public String selectDiverPremiumId() throws Exception {
		return dynmDiverManageMapper.selectDiverPremiumId();
	}

	public DynmDiverMangeVO selectDiverPremium(String premiumId) throws Exception {
		return dynmDiverManageMapper.selectDiverPremium(premiumId);
	}

	public Map<String, String> diverAt(DynmDiverMangeVO dynmDiverMangeVO) throws Exception {
		Map<String,String> resMap = new HashMap<>();
		try {
			Account account = userInfoUtil.getAccountInfo();
			if (null == account || StringUtil.isBlank(account.getId())) {
				throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_LOGIN_REQUIRED));
			} else {
				dynmDiverMangeVO.setLastChangerId(account.getId());
			}

			Map<String, Object> resObj = Optional
			.ofNullable(httpClientHelper.postCallApi(lmeDiverUrl, null))
			.orElseThrow(() -> {
				log.error("httpClientHelper postCallApi lmeDiverMotnCndCnfirm 호출 실패 url : {}", lmeDiverUrl);
				return new Exception("다이버 발동 상태 확인 중 오류가 발생하였습니다. ");
			});

			String diverOption =  String.valueOf(Optional.of(resObj.get("diverAt")).orElse("N"));
			//int diverStatusCode = Integer.parseInt(String.valueOf(Optional.of(resObj.get("diverStatusCode")).orElse(0)));

			if (diverOption.equals("Y")) {

				dynmDiverMangeVO.setDiverAt("N");
				dynmDiverManageMapper.updateDiverAt(dynmDiverMangeVO);
				//히스토리
				List<String> primaryKeyList = new ArrayList<>();
				primaryKeyList.add("DIVER_AT");
				commonService.insertTableHistory("IT_PREMIUM_DIVER_INFO_BAS", dynmDiverMangeVO, primaryKeyList);

				redisPubSubService.publishMessage(propertiesUri, propertiesUri, "I");
				resMap.put("result","다이버 OFF");
				resMap.put("res","S");
				log.debug("다이버 전원 변경 ON > OFF");
				return resMap;

			} else if (diverOption.equals("N")) {//다이버 OFF 상태

				try {

					dynmDiverMangeVO.setDiverAt("Y");
					dynmDiverManageMapper.updateDiverAt(dynmDiverMangeVO);
					//히스토리
					List<String> primaryKeyList = new ArrayList<>();
					primaryKeyList.add("DIVER_AT");
					commonService.insertTableHistory("IT_PREMIUM_DIVER_INFO_BAS", dynmDiverMangeVO, primaryKeyList);

					//Diver 값 초기화
					redisPubSubService.publishMessage(propertiesUri, propertiesUri, "I");
				} catch (Exception e) {
					log.error("initialize COMM 초기화 오류 다이버 발동 조건 없음");
					resMap.put("result","초기화 오류 다이버 발동 조건 없음");
					return resMap;
				}
				log.debug("다이버 작동상태 변경 OFF > ON");

				resMap.put("result","다이버 ON");
				resMap.put("res","S");
				return resMap;
			}
		} catch (Exception e) {
			resMap.put("result","다이버 전원 ON/OFF ERROR \n" + e.getMessage());
			log.error(e.getMessage());
			return resMap;
		}
		resMap.put("result","다이버 전원 ON/OFF 작업 중 오류가 발생했습니다.");
		return resMap;
	}

	public DynmDiverCommVO selectPremiumDiverInfo() throws Exception {
		return dynmDiverMapper.selectPremiumDiverInfo();
	}

}