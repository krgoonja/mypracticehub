package com.sorincorp.bo.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.FixvaleWtTotAmtTariffMgrMapper;
import com.sorincorp.bo.it.model.FixvaleWtTotAmtTariffMgrVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FixvaleWtTotAmtTariffMgrServiceImpl implements FixvaleWtTotAmtTariffMgrService {

	@Autowired
	private FixvaleWtTotAmtTariffMgrMapper fixvaleWtTotAmtTariffMgrMapper;
	@Autowired
	private UserInfoUtil userInfoUtil;

	@Override
	public List<FixvaleWtTotAmtTariffMgrVO> selectFixvaleWtTotAmtTariffMgrList(
			FixvaleWtTotAmtTariffMgrVO fixvaleWtTotAmtTariffMgrVO) throws Exception {
		// TODO Auto-generated method stub
		return fixvaleWtTotAmtTariffMgrMapper.selectFixvaleWtTotAmtTariffMgrList(fixvaleWtTotAmtTariffMgrVO);
	}

	@Override
	public int selectFixvaleWtTotAmtTariffMgrTotCnt(FixvaleWtTotAmtTariffMgrVO fixvaleWtTotAmtTariffMgrVO)
			throws Exception {
		// TODO Auto-generated method stub
		return fixvaleWtTotAmtTariffMgrMapper.selectFixvaleWtTotAmtTariffMgrTotCnt(fixvaleWtTotAmtTariffMgrVO);
	}

	@Override
	public int deleteFixvaleWtTotAmtTariffMgr(FixvaleWtTotAmtTariffMgrVO fixvaleWtTotAmtTariffMgrVO) throws Exception {
		// TODO Auto-generated method stub
		int result = 0;

		int tariffManageDetailSn = 0;
		FixvaleWtTotAmtTariffMgrVO delDtlVO = new FixvaleWtTotAmtTariffMgrVO();
		delDtlVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

		int dtlDelCnt = 0;
		for(int i=0;i<fixvaleWtTotAmtTariffMgrVO.getDtlDelArr().length;i++) {
			tariffManageDetailSn = fixvaleWtTotAmtTariffMgrVO.getDtlDelArr()[i];
			delDtlVO.setTariffManageDetailSn(tariffManageDetailSn);
			//log.debug("tariffManageDetailSn =========>" + tariffManageDetailSn);
			result = fixvaleWtTotAmtTariffMgrMapper.deleteItFixingPcWtTotAmtTariffManageDtl(delDtlVO);
			fixvaleWtTotAmtTariffMgrMapper.insertItFixingPcWtTotAmtTariffManageDtlHst(delDtlVO);

			dtlDelCnt += result;
		}
		//log.debug("dtlDelCnt :" + dtlDelCnt);
		//log.debug("totCnt :" + fixvaleWtTotAmtTariffMgrVO.getDtlDelArr().length);
		if(dtlDelCnt != fixvaleWtTotAmtTariffMgrVO.getDtlDelArr().length) {
			return -1;
		}

		String applcDe = "";
		String itmSn = "";
		FixvaleWtTotAmtTariffMgrVO delBasVO = new FixvaleWtTotAmtTariffMgrVO();
		delBasVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

		int basDelCnt = 0;
		for(int i=0;i<fixvaleWtTotAmtTariffMgrVO.getBasDelArr().length;i++) {
			applcDe = fixvaleWtTotAmtTariffMgrVO.getBasDelArr()[i].split("\\|")[0];
			itmSn = fixvaleWtTotAmtTariffMgrVO.getBasDelArr()[i].split("\\|")[1];

			delBasVO.setApplcDe(applcDe);
			delBasVO.setItmSn(Integer.parseInt(itmSn));
			//log.debug("applcDe =========>" + applcDe);
			//log.debug("itmSn =========>" + itmSn);
			result = fixvaleWtTotAmtTariffMgrMapper.deleteItFixingPcWtTotAmtTariffManageBas(delBasVO);
			fixvaleWtTotAmtTariffMgrMapper.insertItFixingPcWtTotAmtTariffManageBasHst(delBasVO);

			basDelCnt += result;
		}
		//log.debug("basDelCnt :" + basDelCnt);
		//log.debug("totCnt :" + fixvaleWtTotAmtTariffMgrVO.getBasDelArr().length);
		if(basDelCnt != fixvaleWtTotAmtTariffMgrVO.getBasDelArr().length) {
			return -1;
		}

		result = basDelCnt + dtlDelCnt;

		return result;
	}

	@Override
	public List<FixvaleWtTotAmtTariffMgrVO> selectFixvaleWtTotAmtTariffDtlList(FixvaleWtTotAmtTariffMgrVO fixvaleWtTotAmtTariffMgrVO) throws Exception {
		// TODO Auto-generated method stub
		return fixvaleWtTotAmtTariffMgrMapper.selectFixvaleWtTotAmtTariffDtlList(fixvaleWtTotAmtTariffMgrVO);
	}

	@Override
	public int fixvaleWtTotAmtTariffMgrSave(List<FixvaleWtTotAmtTariffMgrVO> saveList) throws Exception {
		// TODO Auto-generated method stub
		int result = 0;
		FixvaleWtTotAmtTariffMgrVO saveVO;
		String applcDe = saveList.get(0).getApplcDe();
		int itmSn = saveList.get(0).getItmSn();
		String gubun = saveList.get(0).getGubun();

		FixvaleWtTotAmtTariffMgrVO delVO = new FixvaleWtTotAmtTariffMgrVO();
		delVO.setApplcDe(applcDe);
		delVO.setItmSn(itmSn);

		List<FixvaleWtTotAmtTariffMgrVO> dtlList = fixvaleWtTotAmtTariffMgrMapper.selectFixvaleWtTotAmtTariffDtlList(delVO);

		//등록이고 기존 데이터가 존재할 경우
		if("I".equals(gubun) && dtlList.size() > 0) {
			return -1;
		}

		//DTL 전체삭제
		for(int i=0;i<dtlList.size();i++) {
			delVO = dtlList.get(i);
			delVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			result = fixvaleWtTotAmtTariffMgrMapper.deleteItFixingPcWtTotAmtTariffManageDtl(delVO);
			fixvaleWtTotAmtTariffMgrMapper.insertItFixingPcWtTotAmtTariffManageDtlHst(delVO);
		}

		//DTL 신규등록
		for(int i=0;i<saveList.size();i++) {
			saveVO = saveList.get(i);
			saveVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			//최초 한번만 BAS테이블에 insert or update 한다.
			if(i == 0) {
				if("I".equals(gubun)) {
					result = fixvaleWtTotAmtTariffMgrMapper.insertItFixingPcWtTotAmtTariffManageBas(saveVO);
				} else if("U".equals(gubun)) {
					result = fixvaleWtTotAmtTariffMgrMapper.updateItFixingPcWtTotAmtTariffManageBas(saveVO);
				}

				fixvaleWtTotAmtTariffMgrMapper.insertItFixingPcWtTotAmtTariffManageBasHst(saveVO);

			}
			result = fixvaleWtTotAmtTariffMgrMapper.insertItFixingPcWtTotAmtTariffManageDtl(saveVO);
			fixvaleWtTotAmtTariffMgrMapper.insertItFixingPcWtTotAmtTariffManageDtlHst(saveVO);
		}

		return result;
	}

}
