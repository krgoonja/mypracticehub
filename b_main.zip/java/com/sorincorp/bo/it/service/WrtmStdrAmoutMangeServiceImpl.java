package com.sorincorp.bo.it.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.WrtmStdrAmoutMangeMapper;
import com.sorincorp.bo.it.model.WrtmStdrAmoutMangeVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class WrtmStdrAmoutMangeServiceImpl implements WrtmStdrAmoutMangeService {
	
	@Autowired
	private WrtmStdrAmoutMangeMapper wrtmStdrAmoutMangeMapper;
	
	@Autowired
	private UserInfoUtil userInfoUtil;

	@Override
	public List<WrtmStdrAmoutMangeVO> getWrtmStdrAmoutMangeList(WrtmStdrAmoutMangeVO vo) throws Exception {
		return wrtmStdrAmoutMangeMapper.getWrtmStdrAmoutMangeList(vo);
	}

	@Override
	public int selectWrtmStdrAmoutMangeCnt(WrtmStdrAmoutMangeVO vo) throws Exception {
		return wrtmStdrAmoutMangeMapper.selectWrtmStdrAmoutMangeCnt(vo);
	}

	@Override
	public int duplicateCheckAjax(WrtmStdrAmoutMangeVO vo) throws Exception {
		return wrtmStdrAmoutMangeMapper.getWrtmStdrDuplicateCnt(vo);
	}

	@Override
	public String insertAndUpdateWrtmStdrAjaxList(WrtmStdrAmoutMangeVO vo) throws Exception {
		String wrtmStdrSn = "";
		
		vo.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		vo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		
		if("insert".equals(vo.getStatus())) {
			wrtmStdrAmoutMangeMapper.insertAndUpdateItWrtmStdrAmoutMangeBas(vo);
			wrtmStdrAmoutMangeMapper.insertItWrtmStdrAmoutMangeBasHst(vo);
			
			wrtmStdrSn = vo.getWrtmStdrSn();

			//최초 등록자 아이디, 최종 변경자 아이디, 순번 세팅
			vo.getGridList().stream().forEach(grid -> {
				grid.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				grid.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				grid.setWrtmStdrSn(vo.getWrtmStdrSn());
			});
			
			int insertCount = 0;
			
			List<WrtmStdrAmoutMangeVO> divHisList = new ArrayList<WrtmStdrAmoutMangeVO>();
			WrtmStdrAmoutMangeVO vo2 = new WrtmStdrAmoutMangeVO();
			
			for(int hisCount = 0, hisSize = vo.getGridList().size(); hisCount < hisSize; hisCount++) {
				WrtmStdrAmoutMangeVO _tempData = new WrtmStdrAmoutMangeVO();
				_tempData = vo.getGridList().get(hisCount);

				divHisList.add(_tempData);
				
				if(insertCount == 200 || hisSize-1 == hisCount) {
					vo2.setGridList((ArrayList<WrtmStdrAmoutMangeVO>) divHisList);
					wrtmStdrAmoutMangeMapper.insertAndUpdateItWrtmStdrAmoutMangeDtl(vo2);
					wrtmStdrAmoutMangeMapper.insertItWrtmStdrAmoutMangeDtlHst(vo2);
					divHisList.clear();
					insertCount = 0;
				} else
					insertCount++;
			}
		}
		
		return wrtmStdrSn;
	}

	@Override
	public List<WrtmStdrAmoutMangeVO> getItWrtmStdrAmoutMangeDtlList(WrtmStdrAmoutMangeVO vo) throws Exception {
		return wrtmStdrAmoutMangeMapper.getItWrtmStdrAmoutMangeDtlList(vo);
	}

	@Override
	public WrtmStdrAmoutMangeVO getItWrtmStdrAmoutMangeBas(WrtmStdrAmoutMangeVO vo) throws Exception {
		return wrtmStdrAmoutMangeMapper.getItWrtmStdrAmoutMangeBas(vo);
	}

	@Override
	public void updateWrtmStdrAjaxList(WrtmStdrAmoutMangeVO vo) throws Exception {
		vo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		
		wrtmStdrAmoutMangeMapper.updateItWrtmStdrAmoutMangeBas(vo);
		wrtmStdrAmoutMangeMapper.insertItWrtmStdrAmoutMangeBasHst(vo);
		
		//최초 등록자 아이디, 최종 변경자 아이디, 순번 세팅
		vo.getGridList().stream().forEach(grid -> {
			grid.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			grid.setWrtmStdrSn(vo.getWrtmStdrSn());
		});
		
		int insertCount = 0;
		
		List<WrtmStdrAmoutMangeVO> divHisList = new ArrayList<WrtmStdrAmoutMangeVO>();
		WrtmStdrAmoutMangeVO vo2 = new WrtmStdrAmoutMangeVO();
		
		for(int hisCount = 0, hisSize = vo.getGridList().size(); hisCount < hisSize; hisCount++) {
			WrtmStdrAmoutMangeVO _tempData = new WrtmStdrAmoutMangeVO();
			_tempData = vo.getGridList().get(hisCount);
			
			if(_tempData.isEditAt())
				divHisList.add(_tempData);
			
			if(insertCount == 200 || hisSize-1 == hisCount) {
				if(divHisList.isEmpty())
					continue;
				vo2.setGridList((ArrayList<WrtmStdrAmoutMangeVO>) divHisList);
				wrtmStdrAmoutMangeMapper.updateItWrtmStdrAmoutMangeDtl(vo2);
				wrtmStdrAmoutMangeMapper.insertItWrtmStdrAmoutMangeDtlHst(vo2);
				divHisList.clear();
				insertCount = 0;
			} else
				insertCount++;
		}

		/*
		for(WrtmStdrAmoutMangeVO data : vo.getGridList()) {
			if(!data.isEditAt())
				continue;
			
			data.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			
			wrtmStdrAmoutMangeMapper.updateItWrtmStdrAmoutMangeDtl(data);
			wrtmStdrAmoutMangeMapper.insertItWrtmStdrAmoutMangeDtlHst(data);
		}
		*/
	}

	@Override
	public void deleteWrtmStdrAmoutAjax(WrtmStdrAmoutMangeVO vo) throws Exception {
		vo.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
		wrtmStdrAmoutMangeMapper.deleteItWrtmStdrAmoutMangeBas(vo);
		wrtmStdrAmoutMangeMapper.insertItWrtmStdrAmoutMangeBasHst(vo);
		
		int insertCount = 0;
		
		List<WrtmStdrAmoutMangeVO> divHisList = new ArrayList<WrtmStdrAmoutMangeVO>();
		WrtmStdrAmoutMangeVO vo2 = new WrtmStdrAmoutMangeVO();
		
		for(int hisCount = 0, hisSize = vo.getGridList().size(); hisCount < hisSize; hisCount++) {
			WrtmStdrAmoutMangeVO _tempData = new WrtmStdrAmoutMangeVO();
			_tempData = vo.getGridList().get(hisCount);
			
			divHisList.add(_tempData);
			
			if(insertCount == 200 || hisSize-1 == hisCount) {
				vo2.setGridList((ArrayList<WrtmStdrAmoutMangeVO>) divHisList);
				wrtmStdrAmoutMangeMapper.deleteItWrtmStdrAmoutMangeDtl(vo2);
				wrtmStdrAmoutMangeMapper.insertItWrtmStdrAmoutMangeDtlHst(vo2);
				divHisList.clear();
				insertCount = 0;
			} else
				insertCount++;
		}

		/*
		for(WrtmStdrAmoutMangeVO data : vo.getGridList()) {
			data.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			 
			wrtmStdrAmoutMangeMapper.deleteItWrtmStdrAmoutMangeDtl(data);
			wrtmStdrAmoutMangeMapper.insertItWrtmStdrAmoutMangeDtlHst(data);
		}
		*/
	}

}
