package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.comm.common.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.FixPriceMapper;
import com.sorincorp.bo.it.model.BsnManageBasVO;
import com.sorincorp.bo.it.model.FixPriceVO;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

@Service
public class FixPriceServiceImpl implements FixPriceService{

	@Autowired
	private FixPriceMapper fixPriceMapper;
	@Autowired
	private UserInfoUtil userInfoUtil;
	@Autowired
	private CommonService commonService;

	/**
	 * 고정가 구매 원가 기본 이력을 조회한다.
	 * @param FixPriceVO - 조회할 정보가 담긴 VO
	 * @return 고정가 구매 원가 리스트
	 * @exception Exception
	 */
	public List<FixPriceVO> selectListFixPrice(FixPriceVO fixPriceVO) throws Exception{
		return fixPriceMapper.selectListFixPrice(fixPriceVO);
	}
	@Override
	public List<FixPriceVO> selectFixPriceSubCodeList(FixPriceVO fixPriceVO) throws Exception {
		//현재 이전의 과거 월 조회시 등록된 데이터만 출력한다.
		//현재 포함 미래일 경우 신규 아이템 포함하여 출력한다.
		if(Integer.parseInt(fixPriceVO.getApplcYm()) < Integer.parseInt(DateUtil.getNowDateTime("yyyyMM"))) {
			fixPriceVO.setPastAt("Y");
		}else {
			fixPriceVO.setPastAt("N");
		}
		return fixPriceMapper.selectFixPriceSubCodeList(fixPriceVO);
	
	}

	@Override
	public List<BsnManageBasVO> beginValidation() {
		return fixPriceMapper.beginValidation();
	}

	@Override
	public void insertAndUpdateCodeAndSubCodeList(List<FixPriceVO> fixPriceVOList) {
		String mberId = userInfoUtil.getAccountInfo().getId();
		FixPriceVO fixPriceVO;

		for(int i = 0; i < fixPriceVOList.size(); i++) {

			fixPriceVO = fixPriceVOList.get(i);
			//최초등록자, 최종수정자 id 세팅
			fixPriceVO.setFrstRegisterId(mberId);
			fixPriceVO.setLastChangerId(mberId);
			
			// 삭제대상이 "Y" 일경우 저장 시 해당 아이템 DELETE_AT = "Y"로 저장.
			if("1".equals(fixPriceVO.getGridNum())) {
				fixPriceMapper.insertAndUpdateFixPriceMng(fixPriceVO);
				fixPriceMapper.insertAndUpdateFixPriceMngHst(fixPriceVO);
			}else if("2".equals(fixPriceVO.getGridNum() )) {
				fixPriceMapper.insertAndUpdateFixPriceSubMng(fixPriceVO);
				fixPriceMapper.insertAndUpdateFixPriceSubMngHst(fixPriceVO);
			}
		}
	}
	@Override
	public void deleteMon(List<FixPriceVO> fixPriceVOList) throws Exception {
		Account account= userInfoUtil.getAccountInfo();
		String userId = account.getId();
		
		for(int i = 0; i < fixPriceVOList.size(); i++) {
			fixPriceVOList.get(i).setLastChangerId(userId);
			fixPriceMapper.deleteMon(fixPriceVOList.get(i));
			fixPriceMapper.deleteMonDtl(fixPriceVOList.get(i));
		}	
	}

}