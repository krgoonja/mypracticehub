package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.PcChangegldMgrVO;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;

public interface PcChangegldMgrService {

	List<PcChangegldMgrVO> selectPcChangegldMgrGridList(PcChangegldMgrVO pcChangegldMgrVO) throws Exception;
	
	int selectPcChangegldMgrGridCount(PcChangegldMgrVO pcChangegldMgrVO) throws Exception;
	
	List<ItemCodeVO> getItemCodeList(String metalCode) throws Exception;
	
	List<PcChangegldMgrVO> selectPcChangegldMgrDtlList(PcChangegldMgrVO pcChangegldMgrVO) throws Exception;
	
	int updatePcChangegldMgrSave(List<PcChangegldMgrVO> pcChangegldMgrsaveList) throws Exception;
	
	int deletePcChangegldMgr(PcChangegldMgrVO pcChangegldMgrVO) throws Exception;
}
