package com.sorincorp.bo.it.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.bo.it.model.ItemMgrVO;
import com.sorincorp.bo.mb.model.ApprovalReqMbCorpMgrVO;

public interface ItemMgrService {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 17.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 17.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	List<ItemMgrVO> selectItemMgrList(ItemMgrVO itemMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 17.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 17.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	int selectItemMgrTotalCnt(ItemMgrVO itemMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 18.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 18.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	ItemMgrVO selectItemMgrDetail(ItemMgrVO itemMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 18.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 18.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	List<ItemMgrVO> selectStdSpecList(ItemMgrVO itemMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 18.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 18.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	ItemMgrVO selectItemCtgry(ItemMgrVO itemMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 21.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param mRequest
	 * @return
	 * @throws Exception
	 */
	Map<String,Object> saveAttachFile(MultipartHttpServletRequest mRequest) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 22.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 22.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	int updateItemMgr(ItemMgrVO itemMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param map
	 * @return
	 * @throws Exception
	 */
	List<ItemMgrVO> selectItemCtgryBas(Map<String, Object> map) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itmSn
	 * @return
	 * @throws Exception
	 */
	List<ItemMgrVO> selectitemCtgryList(int itmSn) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itmSn
	 * @param docNo
	 * @param gubun
	 * @return
	 * @throws Exception
	 */
	int deleteImgFile(int itmSn, String docNo, String gubun) throws Exception;

	Map<String, Object> saveAttachFile2(MultipartHttpServletRequest mRequest) throws Exception;

	int updateItemPriorRank(ArrayList<ItemMgrVO> itemSaveList) throws Exception;

}
