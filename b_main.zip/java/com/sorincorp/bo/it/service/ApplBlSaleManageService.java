package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.ApplBlSaleVO;


/**
 * <pre>
 * 처리내용: 지정 BL 판매 데이터를 조회한다.
 * </pre>
 * @date 2022. 12. 1.
 * @auther chajeeman
 * @history
 * -----------------------------------------------
 * 변경일					작성자				변경내용
 * -----------------------------------------------
 * 2022. 12. 1.			chajeeman			최초작성
 * -----------------------------------------------
 * @param applBlSaleVO
 * @return
 * @throws Exception
 */
public interface ApplBlSaleManageService {
	
	/**
	 * <pre>
	 * 처리내용: 조회조건의 총 카운트 수를 조회한다.
	 * </pre>
	 * @date 2022. 12. 1.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 1.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param applBlSaleVO
	 * @return
	 * @throws Exception
	 */
	int getApplBlSaleManageListTotCnt(ApplBlSaleVO applBlSaleVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 지정 BL 판매 데이터를 조회한다. 
	 * </pre>
	 * @date 2022. 12. 1.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 1.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param applBlSaleVO
	 * @return
	 * @throws Exception
	 */
	List<ApplBlSaleVO> getApplBlSaleManageList(ApplBlSaleVO applBlSaleVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 지정 BL 판매 데이터를 추가한다. 
	 * </pre>
	 * @date 2022. 12. 2.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 1.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param List<ApplBlSaleVO>
	 * @return
	 * @throws Exception
	 */
	int insertApplBlSaleManageListTotCnt(List<ApplBlSaleVO> applBlSaleVOList) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 지정 BL 판매 데이터를 수정한다. 
	 * </pre>
	 * @date 2022. 12. 2.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 1.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param List<ApplBlSaleVO>
	 * @return
	 * @throws Exception
	 */
	int updateApplBlSaleManageListTotCnt(List<ApplBlSaleVO> applBlSaleVOList) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 지정 BL 판매 데이터를 삭제한다. 
	 * </pre>
	 * @date 2022. 12. 2.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 1.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param List<ApplBlSaleVO>
	 * @return
	 * @throws Exception
	 */
	int deleteApplBlSaleManageListTotCnt(List<ApplBlSaleVO> applBlSaleVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 지정 BL 상세.
	 * </pre>
	 * @date 2022. 12. 5.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 5.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param searchVO
	 */
	ApplBlSaleVO selectApplBlSaleManageData(ApplBlSaleVO searchVO) throws Exception;
}
