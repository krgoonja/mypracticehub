package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.MetalItmStdrVO;


public interface MetalItmStdrService {
	
	/**
	 * <pre>
	 * 상품 금속 아이템 기준 리스트를 불러온다
	 * </pre>
	 * @date 2022. 5. 3.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 3.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param rvcmpnPriceMngVO
	 * @return
	 * @throws Exception
	 */
	public List<MetalItmStdrVO> selectMetalItmStdrList(MetalItmStdrVO rvcmpnPriceMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 상품 금속 아이템 기준 페이징 처리를 위한 카운트를 불러온다
	 * </pre>
	 * @date 2022. 5. 3.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 3.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param rvcmpnPriceMngVO
	 * @return
	 * @throws Exception
	 */
	public int selectMetalItmStdrCnt(MetalItmStdrVO rvcmpnPriceMngVO) throws Exception;

	/**
	 * <pre>
	 * 상품 금속 아이템 기준 리스트를 저장 및 수정한다.
	 * </pre>
	 * @date 2022. 5. 9.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 9.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalItmStdrVO
	 * @return
	 * @throws Exception
	 */
	public void insertAndUpdateMetalItmStdrList(MetalItmStdrVO metalItmStdrVO) throws Exception;
	
	/**
	 * <pre>
	 * 상품 금속 아이템 기준을 삭제한다.
	 * </pre>
	 * @date 2022. 5. 9.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 9.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalItmStdrVO
	 */
	public void deleteMetalItmStdr(List<MetalItmStdrVO> metalItmStdrVO) throws Exception;
}