
package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.FtrsFshgVO;

/**
 * FtrsFshgMngService.java
 * @version
 * @since 2022. 5. 27.
 * @author srec0066
 */
public interface FtrsFshgMngService {
	
	/**
	 *	선물/선물환 관리 목록을 조회한다.
	 */
	List<FtrsFshgVO> searchFtrsFshgList(FtrsFshgVO vo) throws Exception;
	
	/**
	 *	선물/선물환 관리 목록 총 개수를 조회한다.
	 */
	int selectFtrsFshgListTotCnt(FtrsFshgVO vo) throws Exception;
	
	/**
	 *	선물/선물환 관리를 등록, 수정 한다.
	 */
	void insertUpdateFtrsFshg(List<FtrsFshgVO> vo) throws Exception;
	
	/**
	 *	선물/선물환 관리를 삭제한다.
	 */
	void deleteFtrsFshg(List<FtrsFshgVO> vo) throws Exception;

	/**
	 * 등록, 수정, 삭제 대상 데이터 목록을 조회한 vo를 리턴한다.
	 */
	FtrsFshgVO selectFtrsFshg(FtrsFshgVO vo) throws Exception;

	/**
	 *	데이터 등록여부를 확인한다.
	 */
	boolean isAlreadyRegistered(FtrsFshgVO vo) throws Exception;
}
