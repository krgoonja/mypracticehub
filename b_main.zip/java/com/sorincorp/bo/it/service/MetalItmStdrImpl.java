package com.sorincorp.bo.it.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.MetalItmStdrMapper;
import com.sorincorp.bo.it.model.MetalItmStdrVO;

@Service
public class MetalItmStdrImpl implements MetalItmStdrService{
	
	@Autowired
	private MetalItmStdrMapper metalItmStdrMapper;
    @Autowired
    private UserInfoUtil userInfoUtil;
	
	@Override
	public List<MetalItmStdrVO> selectMetalItmStdrList(MetalItmStdrVO metalItmStdrVO) throws Exception {
		return metalItmStdrMapper.selectMetalItmStdrList(metalItmStdrVO);
	}

	@Override
	public int selectMetalItmStdrCnt(MetalItmStdrVO metalItmStdrVO) throws Exception {
		
		return metalItmStdrMapper.selectMetalItmStdrCnt(metalItmStdrVO);
	}

	@Override
	public void insertAndUpdateMetalItmStdrList(MetalItmStdrVO metalItmStdrVO) throws Exception {
		
			metalItmStdrVO.setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			metalItmStdrVO.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			metalItmStdrMapper.insertAndUpdateMetalItmStdrList(metalItmStdrVO);
			metalItmStdrMapper.insertItMetalItmStdrBasHst(metalItmStdrVO);
	}

	@Override
	public void deleteMetalItmStdr(List<MetalItmStdrVO> metalItmStdrVOList) throws Exception{
		for (MetalItmStdrVO metalItmStdrVO : metalItmStdrVOList) {
			metalItmStdrVO.setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			metalItmStdrMapper.deleteMetalItmStdr(metalItmStdrVO);
			metalItmStdrMapper.insertItMetalItmStdrBasHst(metalItmStdrVO);
		}
	}
	
}
