package com.sorincorp.bo.it.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.bo.it.model.BlNoInqireVO;
import com.sorincorp.bo.it.model.LqdIntDatResVO;

public interface BlNoInqireService {

	List<BlNoInqireVO> selectBlNoInqireList(BlNoInqireVO blNoInqireVO) throws Exception;

	BlNoInqireVO selectBlNoInqireDetail(String blNo) throws Exception;

	int updateItPurchsInfoBas(BlNoInqireVO blNoInqireVO) throws Exception;

	int updateFtrsProfsSeCode(BlNoInqireVO blNoInqireVO) throws Exception;

	BlNoInqireVO selectVwEpoFileUrl(String blNo) throws Exception;

	int retryIsecoSleClBas() throws Exception;

	List<BlNoInqireVO> selectBlNoInqireDetailHst(BlNoInqireVO blNoInqireVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업로드된 파일 경로 저장
	 * </pre>
	 * 
	 * @date 2022. 12. 23.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 23.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param blNoInqireVO
	 * @return
	 */
	int updateBlNoInqireFile(BlNoInqireVO blNoInqireVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 파일 업로드
	 * </pre>
	 *
	 * @date 2022. 12. 23.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 23.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param blNoInqireVO
	 * @return
	 */
	Map<String, Object> saveAttachFile(MultipartHttpServletRequest mRequest, String idx) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 파일 삭제
	 * </pre>
	 *
	 * @date 2022. 12. 26.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 26.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param blNoInqireVO
	 */
	void deleteBlNoInqireFile(BlNoInqireVO blNoInqireVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 브랜드 리스트 
	 * </pre>
	 *
	 * @date 2024.03.12
	 * @author sumin
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.03.12				sumin				최초작성
	 * -----------------------------------------------
	 * @param blNoInqireVO
	 * @return
	 * @throws Exception
	 */
	List<BlNoInqireVO> selectBrandInfoList(BlNoInqireVO blNoInqireVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 선물환정보 매핑
	 * </pre>
	 *
	 * @date 2024.03.27
	 * @author sumin
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.03.27				sumin				최초작성
	 * -----------------------------------------------
	 * @param LqdIntDatResVO
	 * @return
	 * @throws Exception
	 */
	List<LqdIntDatResVO> selectFshgInfoList(LqdIntDatResVO lqdIntDatResVO) throws Exception;
	

	/**
	 * <pre>
	 * 처리내용: bl 주문내역 조회
	 * </pre>
	 *
	 * @date 2024.04.03
	 * @author sumin
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.04.03				sumin				최초작성
	 * -----------------------------------------------
	 * @param String
	 * @return
	 * @throws Exception
	 */
	int getBlOrderCnt(String blNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: BL 정보/ PO 정보 수정
	 * </pre>
	 *
	 * @date 2024.04.03
	 * @author sumin
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.04.03				sumin				최초작성
	 * -----------------------------------------------
	 * @param String
	 * @return
	 * @throws Exception
	 */
	int updateBlPoInfo(BlNoInqireVO blNoInqireVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: bl정보 등록 (엑셀 업로드)
	 * </pre>
	 *
	 * @date 2024.04.03
	 * @author sumin
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.04.03				sumin				최초작성
	 * -----------------------------------------------
	 * @param String
	 * @return
	 * @throws Exception
	 */
	int xlsBlInfoRegst(BlNoInqireVO blNoInqireVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: BL번호 변경
	 * </pre>
	 *
	 * @date 2024.04.03
	 * @author sumin
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.04.03				sumin				최초작성
	 * -----------------------------------------------
	 * @param String
	 * @return
	 * @throws Exception
	 */
	boolean updateBlNo(BlNoInqireVO blNoInqireVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: BL 선물/선물환 만기일자 수정
	 * </pre>
	 *
	 * @date 2024.05.14
	 * @author sumin
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.05.14				sumin				최초작성
	 * -----------------------------------------------
	 * @param String
	 * @return
	 * @throws Exception
	 */
	int updateBlExprtnDe(BlNoInqireVO blNoInqireVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: STS AP UPDATE
	 * </pre>
	 * @date 2024.07.31
	 * @auther hamyoonsic
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.07.31				hamyoonsic			최초작성
	 * -----------------------------------------------
	 * @param String
	 * @return Int
	 * @throws Exception
	 */
	int stsApIf(BlNoInqireVO blNoInqireVO) throws Exception;
}
