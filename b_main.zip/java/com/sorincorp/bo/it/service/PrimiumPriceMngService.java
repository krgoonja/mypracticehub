package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.LmeEvalCashVO;
import com.sorincorp.bo.it.model.PrEhgtPcRltmBasVO;
import com.sorincorp.bo.it.model.PremiumBrandBasVO;
import com.sorincorp.bo.it.model.PremiumBrandGroupBasVO;
import com.sorincorp.bo.it.model.PremiumDetailProfitAndLoseVO;
import com.sorincorp.bo.it.model.PremiumDstrctBasVO;
import com.sorincorp.bo.it.model.PremiumMonFxEvaluationCashVO;
import com.sorincorp.bo.it.model.PremiumSetPriceVO;
import com.sorincorp.bo.it.model.PremiumStdrBasVO;
import com.sorincorp.bo.it.model.WrtmStdrAmoutMangeVO;

public interface PrimiumPriceMngService {


	/**
	 * <pre>
	 * 처리내용: 현재 아이템코드에 관한 프리미엄가격의 유효일을 오늘날짜로 업데이트
	 * </pre>
	 * @date 2021. 7. 28.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 28.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ppdVO
	 * @return
	 */
	public void updatePremiumPriceValidation(PremiumStdrBasVO vo);
	public void insertPremiumPriceValidationHst(PremiumStdrBasVO vo);

	/**
	 * <pre>
	 * 처리내용: 상품 프리미엄 권역 기본 저장
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 20.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ppdVO
	 * @return
	*/
	public void insertAndUpdatePremiumDstrctPrice(List<PremiumDstrctBasVO> vo);
	public void insertAndUpdatePremiumDstrctPriceHst(List<PremiumDstrctBasVO> vo);


	/**
	 * <pre>
	 * 처리내용: 상품 프리미엄 브랜드 그룹 정보 저장
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 20.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ppdVO
	 * @return
	*/
	public void insertAndUpdatePremiumBrandGroupPrice(List<PremiumBrandGroupBasVO> list);
	public void insertAndUpdatePremiumBrandGroupPriceHst(List<PremiumBrandGroupBasVO> list);


	/**
	 * <pre>
	 * 처리내용: 상품 프리미엄 브랜드 정보 저장
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 20.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ppdVO
	 * @return
	 */
	public void insertAndUpdatePremiumBrandPrice(List<PremiumBrandBasVO> list);
	public void insertAndUpdatePremiumBrandPriceHst(List<PremiumBrandBasVO> list);

	/**
	 * <pre>
	 * 처리내용: 아이템 코드로 상품 검색 후 프리미엄 브랜드 상세 정보 저장
	 * </pre>
	 * @date 2021. 7. 28.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 28.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ppdVO
	 * @return
	 */
	public void insertAndUpdatePremiumBrandDtlPrice(PremiumStdrBasVO vo);
	public void insertAndUpdatePremiumBrandDtlPriceHst(PremiumStdrBasVO vo);



	/**
	 * <pre>
	 * 처리내용: 프리미엄 가격 건수 조회 한다.
	 * </pre>
	 * @date 2022. 3. 10.
	 * @author srec0004
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 3. 10.			srec0004			최초작성
	 * ------------------------------------------------
	 * @param ppmVO
	 * @return
	 */
	public int selectPremiumCnt(PremiumStdrBasVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 프리미엄 가격 조회 한다.
	 * </pre>
	 * @date 2021. 6. 17.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 17.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ppmVO
	 * @return
	 */
	public List<PremiumStdrBasVO> selectPremiumList(PremiumStdrBasVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 프리미엄아이디로 프리미엄 기준정보 가져온다
	 * </pre>
	 * @date 2021. 8. 2.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param lotDtlVOList
	 * @return
	 * @throws Exception
	 */
	public PremiumStdrBasVO getPremiumStdInfoByPremiumId(String premiumId);

	/**
	 * <pre>
	 * 처리내용: 당일 최초 환율 구한다.
	 * </pre>
	 * @date 2021. 8. 5.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 5.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param
	 * @return
	 * @throws Exception
	 */
	public PrEhgtPcRltmBasVO getprEhgtPcFirstByToday();
	/**
	 * <pre>
	 * 처리내용: 프리미엄가격관리 설정 그리드 불러온다
	 * </pre>
	 * @date 2021. 6. 28.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param psbVO
	 * @return
	 */
	public List<PremiumSetPriceVO> getPrimiumLivePriceList(PremiumSetPriceVO vo);
	/**
	 * <pre>
	 * 처리내용: 상품 프리미엄 기준 기본 저장
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 20.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ppdVO
	 * @return
	 */
	public void insertAndUpdatePremiumStdrPrice(PremiumStdrBasVO vo);
	/**
	 * <pre>
	 * 처리내용: 프리미엄 브랜드 상세 lot상세 관계
	 * </pre>
	 * @date 2021. 8. 2.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param lotDtlVOList
	 * @return
	 * @throws Exception
	 */
	public void insertAndUpdatePremiumBrandDtlLotDtlRls(String premiumId);
	/**
	 * <pre>
	 * 처리내용: 프리미엄 가격정보 저장 하기전, 유효한 프리미엄가격으로 설정되어 있는 동일 아이템이 있는지 확인
	 * </pre>
	 * @date 2021. 7. 28.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 28.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ppdVO
	 * @return
	 */
	public int getPremiumDuplicateCnt(PremiumStdrBasVO vo);

	public List<PremiumSetPriceVO> getSetPrimiumFixPriceList(PremiumSetPriceVO psVO);

	public String getAvrgPurchsPrmpc(PremiumSetPriceVO psVO);

	public void deletePremiumPrice(List<PremiumStdrBasVO> vo) throws Exception;
	/**
	 * <pre>
	 * 처리내용: 하나 FX 선물환 6개월
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	public List<PremiumMonFxEvaluationCashVO> get6FxMonEvalutaion();
	/**
	 * <pre>
	 * 처리내용: 프리미엄 세부 손익
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	public List<PremiumDetailProfitAndLoseVO> getPremiumDetailProfitAndLoseUpdate(PremiumDetailProfitAndLoseVO vo);

	public void updatePremiumStdrItmAt(PremiumStdrBasVO vo);

	public PremiumStdrBasVO getPremiumDuplicatePremiumId(PremiumStdrBasVO vo);

	public List<PremiumSetPriceVO> getSetPrimiumLivePriceDetailList(PremiumSetPriceVO psVO);

	public int getHghnetprcCount(PremiumStdrBasVO vo);

	public List<PremiumSetPriceVO> getSetPrimiumFixPriceDetailList(PremiumSetPriceVO psVO);

	public PremiumStdrBasVO getPremiumDuplicatePremiumId2(PremiumStdrBasVO vo);

	public LmeEvalCashVO getOneDayAgoLmeEvalCash();

	public PremiumStdrBasVO getMetalItmStdr(PremiumSetPriceVO vo);
	
	public String premiumdDuplicateCheck(PremiumStdrBasVO vo) throws Exception;
	
	public String insertPremiumPrice(PremiumStdrBasVO vo) throws Exception;
	
	public String updatePremiumPrice(PremiumStdrBasVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 중복된 적용일시를 체크한다
	 * </pre>
	 * @date 2022. 8. 9.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 9.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public int duplicateCheckAjax(PremiumSetPriceVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 선택된 조건에 맞는 기준 프리미엄을 불러온다.
	 * </pre>
	 * @date 2023. 10. 18.
	 * @author hanjook
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 18.		hanjook				최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public PremiumStdrBasVO getSelectedPremium(PremiumStdrBasVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 다이나믹 프리미엄 저장
	 * </pre>
	 *
	 * @date 2023. 10. 17.
	 * @author jdrttl
	 * @history
	 * ------------------------------------------------
	 * 변경일           작성자        변경내용
	 * ------------------------------------------------
	 * 2023. 10. 17.  jdrttl       최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */	
	public String savePremiumDynmPrice(PremiumStdrBasVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 현재 실시간 환율 조회
	 * </pre>
	 *
	 * @date 2023. 11. 1.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일           작성자        변경내용
	 * ------------------------------------------------
	 * 2023. 11. 1.  hamyoonsic       최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public String getEhgtPcRltm() throws Exception;
	
}
