/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.SalesManagementVO;


/**
 * SalesManagementService.java
 * @version
 * @since 2021. 6. 10.
 * @author srec0008
 */
/**
 * SalesManagementService.java
 * @version
 * @since 2021. 6. 10.
 * @author srec0008
 */
public interface SalesManagementService {

	/**
	 * <pre>
	 * 영업관리 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0008
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @return
	 * @throws Exception
	 */
	public List<SalesManagementVO> getListSalesManagement(SalesManagementVO salesManagementVO) throws Exception;
	
	/**
	 * <pre>
	 * 영업관리 리스트 카운트를 조회한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0008
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @return
	 * @throws Exception
	 */
	public int getListSalesManagementCnt(SalesManagementVO salesManagementVO) throws Exception;
	
	/**
	 * <pre>
	 * 영업관리 단건을 조회한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0008
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @return
	 * @throws Exception
	 */
	public SalesManagementVO getSalesManagement(SalesManagementVO salesManagementVO) throws Exception;
	
	/**
	 * <pre>
	 * 영업관리를 등록한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0008
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @throws Exception
	 */
	void insertSalesManagement(SalesManagementVO salesManagementVO) throws Exception;
	
	/**
	 * <pre>
	 * 영업관리를 수정한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0008
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @throws Exception
	 */
	void updateSalesManagement(SalesManagementVO salesManagementVO) throws Exception;
	
	/**
	 * <pre>
	 * 영업관리를 삭제한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0008
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @throws Exception
	 */
	void deleteSalesManagement(SalesManagementVO salesManagementVO) throws Exception;

	/**
	 * <pre>
	 * 현재 적용되어 있는 영업 시간을 가져온다.
	 * </pre>
	 * @date 2022. 5. 11.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 11.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	public SalesManagementVO selectManagementTime() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 해당 영업일자로 등록된 데이터의 개수를 조회한다
	 * </pre>
	 * @date 2022. 8. 3.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 3.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @return
	 * @throws Exception
	 */
	public int getSalesManagementCnt(SalesManagementVO salesManagementVO) throws Exception;
	
	/**
	 * <pre>
	 * 가장 최근 영업관리 리스트 1개 조회
	 * </pre>
	 * @date 2023. 4. 13.
	 * @author bok3117
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 4. 13.		bok3117		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public List<SalesManagementVO> getTopListSalesManagement(SalesManagementVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 최근 영업 리스트 조회
	 * </pre>
	 * @date 2023. 11. 13.
	 * @author bok3117
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일				작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 11. 13.	bok3117			최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param 
	 * @return
	 * @throws Exception
	 */
	public SalesManagementVO selectTopListSalesManagement() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 영업시간 수정
	 * </pre>
	 * @date 2024. 07. 17.
	 * @author sumin
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일				작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 07. 17.		sumin			최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param 
	 * @return
	 * @throws Exception
	 */
	public void updateSalesTime(SalesManagementVO salesManagementVO) throws Exception;
}
