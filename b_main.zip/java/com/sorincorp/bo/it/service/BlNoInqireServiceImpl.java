package com.sorincorp.bo.it.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import com.sorincorp.comm.btb.comm.HttpClientHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.BlNoInqireMapper;
import com.sorincorp.bo.it.model.BlNoInqireVO;
import com.sorincorp.bo.it.model.LqdIntDatResVO;
import com.sorincorp.comm.common.mapper.CommonMapper;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.invntry.service.InvntrySttusService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BlNoInqireServiceImpl implements BlNoInqireService {

	@Autowired
	private BlNoInqireMapper blNoInqireMapper;

	@Autowired
	private FileDocService fileDocService;

	@Autowired
	MessageUtil messageUtil;
	// https://sorincorp.blob.core.windows.net/sts-pr/AOC/AOC_202202/c626d48f-cfb9-4a6c-ba0e-cafcba1342d4.pdf
	// https://sorincorp.blob.core.windows.net/sts-pr/COL/COL_202202/74c320c9-dbed-47f4-b2d3-368c643badc8.xlsx

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Value("${spring.profiles}")
	private String profiles;

	@Value("${dblink.sts.name}")
	private String dblinkStsName;
	@Autowired
	private CommonService commonService;

	@Autowired
	InvntrySttusService invntrySttusService;

	@Autowired
	private CommonMapper commonMapper;

	/** 외부 연계 api 호출 모듈 **/
	@Autowired
	private HttpClientHelper httpClientHelper;

	@Value("${spring.sts.api.stsApRecptn-url}")
	private String stsApRecptnUrl;


	@Override
	public List<BlNoInqireVO> selectBlNoInqireList(BlNoInqireVO blNoInqireVO) throws Exception {
		// TODO Auto-generated method stub
		return blNoInqireMapper.selectBlNoInqireList(blNoInqireVO);
	}

	@Override
	public BlNoInqireVO selectBlNoInqireDetail(String blNo) throws Exception {
		// TODO Auto-generated method stub
		return blNoInqireMapper.selectBlNoInqireDetail(blNo);
	}

	@Override
	public int updateFtrsProfsSeCode(BlNoInqireVO blNoInqireVO) throws Exception {
		blNoInqireVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		blNoInqireVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
		
		int result = blNoInqireMapper.updateFtrsProfsSeCode(blNoInqireVO);
		
		if (result > 0) {
			//선물 달러 수수료 계산 후 히스토리 저장
			blNoInqireMapper.insertItPurchsInfoBasHst(blNoInqireVO);
		}
		return result;
	}

	@Override
	public int updateItPurchsInfoBas(BlNoInqireVO blNoInqireVO) throws Exception {
		// TODO Auto-generated method stub
		String blNo = blNoInqireVO.getBlNo();
		int result = 0;

		// 운영, 개발 DBLINK
		blNoInqireVO.setDblinkStsName(dblinkStsName);

		String ftrsExprtnDe = blNoInqireVO.getFtrsExprtnDe().replaceAll("-", "");
		blNoInqireVO.setFtrsExprtnDe(ftrsExprtnDe);
		String fshgExprtnDe = blNoInqireVO.getFshgExprtnDe().replaceAll("-", "");
		blNoInqireVO.setFshgExprtnDe(fshgExprtnDe);

		int blSleSetupChgCnt = blNoInqireMapper.selectBlSleSetupChgCnt(blNoInqireVO);
		
		blNoInqireVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
		blNoInqireVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		
		result = blNoInqireMapper.mergeBlInfoBas(blNoInqireVO);
		commonService.insertTableHistory("IT_BL_INFO_BAS", blNoInqireVO);
		
		//최초 등록시에만 실행
		if (result == 1 && blSleSetupChgCnt == 0) {
			result = blNoInqireMapper.updateBlInfoBasInvntryAtmcCalc(blNoInqireVO);
			blNoInqireMapper.insertItBlInfoHistDtl(blNoInqireVO);
			
			invntrySttusService.invntrySttusMsgPublish();
		}
		
		result = 0;	
		result = blNoInqireMapper.mergePrchsInfoBas(blNoInqireVO);
		commonService.insertTableHistory("IT_PURCHS_INFO_BAS", blNoInqireVO);
		
		int blCnt = blNoInqireMapper.selectItBlInfoBasCnt(blNo);

		// IT_BL_INFO_BAS 데이터가 있을 경우만 판매상태 변경 로직 적용
		if (blCnt > 0) {

			BlNoInqireVO blSleSttusCodeChgVO = blNoInqireMapper.selectBlSleSttusCodeChgData(blNo);
			
			// 20230710 srec0030 공통 메소드로 변경
			if (blSleSttusCodeChgVO != null && !"".equals(blSleSttusCodeChgVO.getBlNo())) {
				commonService.blSleSttusCodeChg(blSleSttusCodeChgVO.getBlNo(), userInfoUtil.getAccountInfo().getId());
			}
		}

		return result;

	}

	@Override
	public BlNoInqireVO selectVwEpoFileUrl(String blNo) throws Exception {
		// TODO Auto-generated method stub
		BlNoInqireVO blNoInqireVO = new BlNoInqireVO();

		blNoInqireVO.setBlNo(blNo);
		// 운영, 개발 DBLINK
		blNoInqireVO.setDblinkStsName(dblinkStsName);

		blNoInqireVO.setFileType("COA");
		String screofeFileCours = blNoInqireMapper.selectVwEpoFileUrl(blNoInqireVO);
		if (screofeFileCours != null && !"".equals(screofeFileCours)) {
			blNoInqireVO.setScreofeFileCours(screofeFileCours);
		} else {
			blNoInqireVO.setScreofeFileCours("");
		}
		blNoInqireVO.setFileType("PL");
		String packngListFileCours = blNoInqireMapper.selectVwEpoFileUrl(blNoInqireVO);
		if (packngListFileCours != null && !"".equals(packngListFileCours)) {
			blNoInqireVO.setPackngListFileCours(packngListFileCours);
		} else {
			blNoInqireVO.setPackngListFileCours("");
		}
//		sts인터페이스 수정 후 적용
//		blNoInqireVO.setFileType("BL");
//		String blFileCours = blNoInqireMapper.selectVwEpoFileUrl(blNoInqireVO);
//		if (blFileCours != null && !"".equals(blFileCours)) {
//			blNoInqireVO.setBlFileCours(blFileCours);
//		} else {
//			blNoInqireVO.setBlFileCours("");
//		}

		return blNoInqireVO;
	}

	@Override
	public int retryIsecoSleClBas() throws Exception {
		int result = 0;
		String nowDtm = DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss.SSS");

		List<BlNoInqireVO> blinfoBasList = blNoInqireMapper.selectItBlInfoBasList();

		if (blinfoBasList.size() > 0) {
			blNoInqireMapper.deletetIsecoSleClBas(nowDtm);

			for (BlNoInqireVO blNoInqireVO : blinfoBasList) {
				blNoInqireVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
				blNoInqireMapper.insertIsecoSleClBas(blNoInqireVO);
				//blNoInqireMapper.insertIsecoSleClBasHst(blNoInqireVO);
				commonService.insertTableHistory("ISECO_SLE_CL_BAS", blNoInqireVO);

				result++;
			}
		}

		return result;
	}

	public List<BlNoInqireVO> selectBlNoInqireDetailHst(BlNoInqireVO blNoInqireVO) throws Exception {
		// TODO Auto-generated method stub
		return blNoInqireMapper.selectBlNoInqireDetailHst(blNoInqireVO);
	}

	/**
	 * <pre>
	 * 처리내용: 업로드된 파일 경로 저장
	 * </pre>
	 *
	 * @date 2022. 12. 23.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 23.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param blNoInqireVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int updateBlNoInqireFile(BlNoInqireVO blNoInqireVO) throws Exception {

		int result = 0;
		int poCnt = 0;

		poCnt = blNoInqireMapper.selectItPurchsInfoBasCnt(blNoInqireVO.getBlNo());

		blNoInqireVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
		blNoInqireVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

		if (poCnt > 0) {
			// IT_PURCHS_INFO_BAS UPDATE
			result = blNoInqireMapper.updateBlNoInqireFile(blNoInqireVO);
			blNoInqireMapper.insertItPurchsInfoBasHst(blNoInqireVO);
		} else {
			// IT_PURCHS_INFO_BAS INSERT
			result = blNoInqireMapper.insertlNoInqireItPurchsInfoBas(blNoInqireVO);
			blNoInqireMapper.insertItPurchsInfoBasHst(blNoInqireVO);
		}

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 파일 업로드
	 * </pre>
	 *
	 * @date 2022. 12. 23.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 23.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param blNoInqireVO
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("finally")
	@Override
	public Map<String, Object> saveAttachFile(MultipartHttpServletRequest mRequest, String uploadFolder) throws Exception {

		HashMap<String, Object> fileMap = new HashMap<>();
		String errMsg = "";

		try {
			List<FileDocVO> list = new ArrayList<FileDocVO>();

			list = fileDocService.uploadAttachFilesVoList("IT", uploadFolder, mRequest);// 파일 저장
			// list = fileDocService.uploadPublicAttachFilesVoList(jobSeCode, mRequest);//
			// 파일 저장

			fileMap.put("result", "S");
			fileMap.put("list", list);

		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.toString());
			errMsg = messageUtil.getMessage(e.getMessage());
			fileMap.put("result", "F");
		} finally {
			fileMap.put("errMsg", errMsg);
			return fileMap;
		}
	}

	/**
	 * <pre>
	 * 처리내용: 이전 파일 삭제(BLOB 삭제 추가)
	 * </pre>
	 *
	 * @date 2022. 12. 27.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 23.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param blNoInqireVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public void deleteBlNoInqireFile(BlNoInqireVO blNoInqireVO) throws Exception {
		//blNoInqireVO : null X
		if(blNoInqireVO.getFileUri() != null) {
			
			BlNoInqireVO fileBlNoInqireVO = new BlNoInqireVO();
			//CO_DOC_BASuri로 필요 값 가져오기
			fileBlNoInqireVO = blNoInqireMapper.selectCoDocBas(blNoInqireVO);
			//존재하면 BLOB, CO_DOC_BAS 삭제
			if (fileBlNoInqireVO != null) {
				fileDocService.deleteCommonDoc(Integer.parseInt(fileBlNoInqireVO.getDocNo()));
			} 
				
			blNoInqireVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			blNoInqireMapper.updateItPurchInfoBas(blNoInqireVO);
		}
	}


	/**
	 * <pre>
	 * 처리내용: 브랜드 리스트 
	 * </pre>
	 *
	 * @date 2024.03.12
	 * @author sumin
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.03.12				sumin				최초작성
	 * -----------------------------------------------
	 * @param blNoInqireVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<BlNoInqireVO> selectBrandInfoList(BlNoInqireVO blNoInqireVO) throws Exception {
		List<BlNoInqireVO> brandList = blNoInqireMapper.selectBrandInfoList(blNoInqireVO);
		return brandList;
	}
	
	/**
	 * <pre>
	 * 처리내용: 선물환 정보 매핑
	 * </pre>
	 *
	 * @date 2024.03.27
	 * @author sumin
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.03.27				sumin				최초작성
	 * -----------------------------------------------
	 * @param blNoInqireVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<LqdIntDatResVO> selectFshgInfoList(LqdIntDatResVO lqdIntDatResVO) throws Exception {
		List<LqdIntDatResVO> fshgInfoList = blNoInqireMapper.selectFshgInfoList(lqdIntDatResVO);
		return fshgInfoList;
	}
	
	/**
	 * <pre>
	 * 처리내용: BL 주문내역 조회
	 * </pre>
	 *
	 * @date 2024.03.27
	 * @author sumin
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.03.27				sumin				최초작성
	 * -----------------------------------------------
	 * @param blNoInqireVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int getBlOrderCnt(String blNo) throws Exception {
		return blNoInqireMapper.getBlOrderCnt(blNo);
	}
	
	/**
	 * <pre>
	 * 처리내용: BL 정보/ PO 정보 수정
	 * </pre>
	 *
	 * @date 2024.03.27
	 * @author sumin
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.03.27				sumin				최초작성
	 * -----------------------------------------------
	 * @param String
	 * @return
	 * @throws Exception
	 */
	@Override
	public int updateBlPoInfo(BlNoInqireVO blNoInqireVO)  throws Exception {
		int result = 0;
		
		blNoInqireVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		
		result = blNoInqireMapper.updateBlInfoDel(blNoInqireVO);
		blNoInqireMapper.updatePurchsInfoDel(blNoInqireVO);
		
		return result;
	}
	
	/**
	 * <pre>
	 * 처리내용: bl정보 등록 (엑셀 업로드)
	 * </pre>
	 *
	 * @date 2024.04.03
	 * @author sumin
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.04.03				sumin				최초작성
	 * -----------------------------------------------
	 * @param BlNoInqireVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int xlsBlInfoRegst(BlNoInqireVO blNoInqireVO) throws Exception {
		
		int result = 0;
		int regstCount = 0;
		
			for(BlNoInqireVO vo : blNoInqireVO.getBlInfoSaveList()) {
				int blCount = blNoInqireMapper.selectItBlInfoBasCnt(vo.getBlNo());
				int blSleSetupChgCnt = blNoInqireMapper.selectBlSleSetupChgCnt(vo);
				
				if(blCount > 0) {
				} else {
						List<BlNoInqireVO> brandList = blNoInqireMapper.selectBrandInfoList(vo);
						
						for(BlNoInqireVO  brandVo : brandList) {
							vo.setMetalCode(brandVo.getMetalCode());	
							vo.setPrductNm(brandVo.getDspyGoodsNm());	
							vo.setBrandCode(brandVo.getBrandCode());
							vo.setItmCode(brandVo.getItmCode());
						}
						
						vo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
						vo.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
						
						result = blNoInqireMapper.insertXlsBlInfoBas(vo);		//BL 정보 등록
						blNoInqireMapper.insertXlsPurchsInfoBas(vo);			//PO 정보 등록
						
					//최초 등록시에만 실행	
					if (result == 1 && blSleSetupChgCnt == 0) {
						result = blNoInqireMapper.updateBlInfoBasInvntryAtmcCalc(vo);
						blNoInqireMapper.insertItBlInfoHistDtl(vo);
						
						invntrySttusService.invntrySttusMsgPublish();
					}
					
					commonService.insertTableHistory("IT_BL_INFO_BAS", vo);
					commonService.insertTableHistory("IT_PURCHS_INFO_BAS", vo);
					
					++regstCount;
				}
			}
			
			result = regstCount;
			
		return result;
	}
	
	/**
	 * <pre>
	 * 처리내용: BL번호 변경
	 * </pre>
	 *
	 * @date 2024.04.03
	 * @author sumin
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.03.27				sumin				최초작성
	 * -----------------------------------------------
	 * @param String
	 * @return
	 * @throws Exception
	 */
	@Override
	public boolean updateBlNo(BlNoInqireVO blNoInqireVO) throws Exception {
		boolean result = false;
		
		List<String> chgKeyList = new ArrayList<>();
		chgKeyList.add("BL_NO");
		
		List<String> newValueList = new ArrayList<>();
		newValueList.add(blNoInqireVO.getChgBlNo());
		
		List<String> oldValueList = new ArrayList<>();
		oldValueList.add(blNoInqireVO.getBlNo());
		
		result = commonService.insertTableCopy("IT_BL_INFO_BAS", chgKeyList, oldValueList, newValueList);
		result = commonService.insertTableCopy("IT_PURCHS_INFO_BAS", chgKeyList, oldValueList ,newValueList);
		result = commonService.insertTableCopy("IT_BL_INFO_HIST_DTL", chgKeyList, oldValueList, newValueList);
		
		return result;
	}
	
	/**
	 * <pre>
	 * 처리내용: BL 선물/선물환 만기일자 조회
	 * </pre>
	 *
	 * @date 2024.05.14
	 * @author sumin
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.05.14				sumin				최초작성
	 * -----------------------------------------------
	 * @param String
	 * @return
	 * @throws Exception
	 */
	@Override
	public int updateBlExprtnDe(BlNoInqireVO blNoInqireVO) throws Exception {

		int result = 0;
		blNoInqireVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		
		//선물 선물환 만기일자, FCM 변경
		result = blNoInqireMapper.updateBlExprtnDe(blNoInqireVO);
		
		// BlNO 배열의 각 요소를 엔터로 잘라서 새로운 배열에 담는다 (히스토리 테이블 인서트)
		String[] getBlNo = blNoInqireVO.getBlNoArr();
		
		if (getBlNo != null && getBlNo.length > 0) {
			List<String> blNoList = new ArrayList<>();
			for (String blNo : getBlNo) {
				String[] splitBlNo = blNo.split("\\s*,\\s*");
				for (String bl : splitBlNo) {
					if (!bl.trim().isEmpty()) { // 빈 문자열 제외
						blNoList.add(bl.trim());
					}
					blNoInqireVO.setBlNo(bl);
					commonService.insertTableHistory("IT_PURCHS_INFO_BAS", blNoInqireVO);
				}
			}
		}
			
		return result;
	}

	/**
	 * <pre>
	 * 처리내용: STS AP UPDATE
	 * </pre>
	 * @date 2024.07.31
	 * @auther hamyoonsic
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.07.31				hamyoonsic			최초작성
	 * -----------------------------------------------
	 * @param blNoInqireVO
	 * @return Int
	 * @throws Exception
	 */
	@Override
	public int stsApIf(BlNoInqireVO blNoInqireVO) throws Exception {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		int result = 0;
		paramMap.put("blList",blNoInqireVO.getBlList());
		Map<String, Object> responseMap = httpClientHelper.postCallApi(stsApRecptnUrl, paramMap);
		if (responseMap == null) {
			// 응답 없음
			log.error("ERROR BlNoInqireServiceImpl stsApIf :: api response null");
			return result;
		} else {
			// 응답코드 확인
			Object resultCode = responseMap.get("rspnsCode");
			if (Objects.toString(resultCode, "").equals("500")) {
				log.error("ERROR BlNoInqireServiceImpl stsApIf :: api response Error resultCode : {}", resultCode);
				return result;
			} else {
				result = 1;
			}
		}
		return result;
	}
	
}