package com.sorincorp.bo.it.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.sorincorp.comm.common.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.RvcmpnPriceMngMapper;
import com.sorincorp.bo.it.model.BsnManageBasVO;
import com.sorincorp.bo.it.model.RvcmpnPriceMngVO;

@Service
public class RvcmpnPriceMngImpl implements RvcmpnPriceMngService{
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Autowired
	private RvcmpnPriceMngMapper rpmMapper;

	@Autowired
	private CommonService commonService;
	
	/**
	 * 사이드카 목록을 조회한다.
	 * @param SidecarVO - 조회할 정보가 담긴 VO
	 * @return 사이드카 리스트
	 * @exception Exception
	 */
	public List<RvcmpnPriceMngVO> searchRvcmpnPriceMngList(RvcmpnPriceMngVO rvcmpnPriceMngVO) throws Exception{
		return rpmMapper.searchRvcmpnPriceMngList(rvcmpnPriceMngVO);
	}
	
	@Override
	public void insertAndUpdateRvcmpnPriceMngList(List<RvcmpnPriceMngVO> rvcmpnPriceMngVOList) {
		for(int i = 0; i < rvcmpnPriceMngVOList.size(); i++) {
			String status = rvcmpnPriceMngVOList.get(i).getGridRowStatus();
			if(status.equals("created")) {
				/* 
				 * 동일[날짜, 품목대분류코드] 등록 삭제 후 재등록 불가능(무결성) / 동일 키값의 데이터 존재 확인 -> 기존의 삭제 되었던 데이터 UPDATE
				 * 
				 * 1. 동일[날짜, 품목대분류코드] 존재 확인
				 * 2. 존재할때 -> update, 존재하지 않을떄-> insert
				 */
				RvcmpnPriceMngVO rvcVo = new RvcmpnPriceMngVO();
				rvcmpnPriceMngVOList.get(i).setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				rvcmpnPriceMngVOList.get(i).setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				rvcVo = rpmMapper.searchOneRvcmpnPriceMng(rvcmpnPriceMngVOList.get(i));
				if(rvcVo != null && "Y".equals(rvcVo.getDeleteAt())) { //동일 key값으로 데이터가 있을때
					rvcmpnPriceMngVOList.get(i).setDeleteAt("N");
					rpmMapper.updateRvcmpnPriceMng(rvcmpnPriceMngVOList.get(i));
					rpmMapper.insertRvcmpnPriceMngHST(rvcmpnPriceMngVOList.get(i));
				}else if (rvcVo == null) {
					rvcmpnPriceMngVOList.get(i).setDeleteAt("N");
					rpmMapper.insertRvcmpnPriceMng(rvcmpnPriceMngVOList.get(i));
					rpmMapper.insertRvcmpnPriceMngHST(rvcmpnPriceMngVOList.get(i));
				} else if (rvcVo != null && "Y".equals(rvcVo.getDeleteAt())){  //삭제 상태가 아닌 동일 키값으로 insert시도 했을때
					
				}
				
			} else if (status.equals("updated")) {
				rvcmpnPriceMngVOList.get(i).setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				rvcmpnPriceMngVOList.get(i).setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
				rvcmpnPriceMngVOList.get(i).setDeleteAt("N");
				rpmMapper.updateRvcmpnPriceMng(rvcmpnPriceMngVOList.get(i));
				rpmMapper.insertRvcmpnPriceMngHST(rvcmpnPriceMngVOList.get(i));
			}
		}
	}

	@Override
	public int searchRvcmpnPriceMngTotalCnt(RvcmpnPriceMngVO rvcmpnPriceMngVO) {
		return rpmMapper.searchRvcmpnPriceMngTotalCnt(rvcmpnPriceMngVO);
	}

	@Override
	public void deleteRvcmpnPrice(List<RvcmpnPriceMngVO> rvcmpnPriceMngVOList) {
		for(int i = 0; i < rvcmpnPriceMngVOList.size(); i++) {
			rvcmpnPriceMngVOList.get(i).setFrstRegisterId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			rvcmpnPriceMngVOList.get(i).setLastChangerId(Optional.ofNullable(userInfoUtil.getUserId()).orElse(""));
			rpmMapper.deleteRvcmpnPrice(rvcmpnPriceMngVOList.get(i));
			rpmMapper.insertRvcmpnPriceMngHST(rvcmpnPriceMngVOList.get(i));
		}
	}

	@Override
	public List<BsnManageBasVO> beginValidation(RvcmpnPriceMngVO vo) {
		return rpmMapper.beginValidation(vo);
	}

	@Override
	public int selectDupRvcmpnPrice(RvcmpnPriceMngVO vo) {
		return rpmMapper.selectDupRvcmpnPrice(vo);
	}
	
}
