package com.sorincorp.bo.it.service;

import java.util.List;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;

import com.sorincorp.bo.it.model.DistributionHolidayVO;

/**
 * DistributionHolidayService.java
 * @version
 * @since 2021. 6. 07.
 * @author srec0008
 */
public interface DistributionHolidayService {

	/**
	 * <pre>
	 * 물류 휴일 목록을 조회한다.
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 15.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param distributionHolidayVO
	 * @return
	 * @throws Exception
	 */
	public JSONArray getDistributionHolidayList(DistributionHolidayVO distributionHolidayVO) throws Exception;

	/**
	 * <pre>
	 * 공통 코드 조회
	 * </pre>
	 * @date 2021. 7. 26.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 26.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param distributionHolidayVO
	 * @return
	 * @throws Exception
	 */
	public List<Map<String, Object>> getDstrctCodeList(DistributionHolidayVO distributionHolidayVO) throws Exception;
	
}
