package com.sorincorp.bo.it.service;

import java.util.List;


import com.sorincorp.bo.it.model.ItmWtChangeAmountMgrVO;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;

/**
 * ItmWtChangeAmountMgrService.java
 * @version
 * @since 2023. 6. 1.
 * @author srec0083
 */
public interface ItmWtChangeAmountMgrService {

	
	/**
	 * 
	 * <pre>
	 * 처리내용: 아이템별 중량변동금 관리 그리드 데이터를 가져온다.
	 * </pre>
	 * @date 2023. 6. 1.
	 * @author srec0083
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 1.			srec0083			최초작성
	 * ------------------------------------------------
	 * @param itmWtChangeAmountMgrVO
	 * @return
	 * @throws Exception
	 */
	List<ItmWtChangeAmountMgrVO> selectItmWtChangeAmountMgrGridList(ItmWtChangeAmountMgrVO itmWtChangeAmountMgrVO) throws Exception;
	
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 아이템별 중량변동금 관리 그리드 데이터 총 건수를 가져온다.
	 * </pre>
	 * @date 2023. 6. 1.
	 * @author srec0083
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 1.			srec0083			최초작성
	 * ------------------------------------------------
	 * @param itmWtChangeAmountMgrVO
	 * @return
	 * @throws Exception
	 */
	int selectItmWtChangeAmountMgrGridCount(ItmWtChangeAmountMgrVO itmWtChangeAmountMgrVO) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 메탈 선택에 따른 아이템 리스트를 조회한다.
	 * </pre>
	 * @date 2023. 6. 1.
	 * @author srec0083
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 1.			srec0083			최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	List<ItemCodeVO> getItemCodeList(String metalCode) throws Exception;
	
	
	 /**
	  * 
	  * <pre>
	  * 처리내용: 아이템별 중량 변동금 수정 시 메탈, 아이템에 해당하는 데이터를 조회한다.
	  * </pre>
	  * @date 2023. 6. 2.
	  * @author srec0083
	  * @history 
	  * ------------------------------------------------
	  * 변경일					작성자				변경내용
	  * ------------------------------------------------
	  * 2023. 6. 2.			srec0083			최초작성
	  * ------------------------------------------------
	  * @param itmWtChangeAmountMgrVO
	  * @return
	  * @throws Exception
	  */
	List<ItmWtChangeAmountMgrVO> selectItmWtChangeAmountMgrDtlList(ItmWtChangeAmountMgrVO itmWtChangeAmountMgrVO) throws Exception;
	
	 /**
	  * 
	  * <pre>
	  * 처리내용: 아이템별 중량 변동금을 저장한다.
	  * </pre>
	  * @date 2023. 6. 7.
	  * @author srec0083
	  * @history 
	  * ------------------------------------------------
	  * 변경일					작성자				변경내용
	  * ------------------------------------------------
	  * 2023. 6. 7.			srec0083			최초작성
	  * ------------------------------------------------
	  * @param itmWtChangeAmountMgrsaveList
	  * @return
	  * @throws Exception
	  */
	 int updateItmWtChangeAmountMgrSave(List<ItmWtChangeAmountMgrVO> itmWtChangeAmountMgrsaveList) throws Exception;
	 
	 /**
	  * 
	  * <pre>
	  * 처리내용: 아이템별 중량 변동금을 삭제한다.
	  * </pre>
	  * @date 2023. 6. 8.
	  * @author srec0083
	  * @history 
	  * ------------------------------------------------
	  * 변경일					작성자				변경내용
	  * ------------------------------------------------
	  * 2023. 6. 8.			srec0083			최초작성
	  * ------------------------------------------------
	  * @param itmWtChangeAmountMgrVO
	  * @return
	  * @throws Exception
	  */
	 int deleteItmWtChangeAmountMgr(ItmWtChangeAmountMgrVO itmWtChangeAmountMgrVO) throws Exception;
}
