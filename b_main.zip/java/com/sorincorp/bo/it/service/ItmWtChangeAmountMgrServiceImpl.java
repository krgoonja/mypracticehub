package com.sorincorp.bo.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.ItmWtChangeAmountMgrMapper;
import com.sorincorp.bo.it.model.ItmWtChangeAmountMgrVO;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;

import lombok.extern.slf4j.Slf4j;
/**
 * 
 * ItmWtChangeAmountMgrServiceImpl.java
 * 아이템별 중량변동금 관리 Service 구현체 클래스
 * @version
 * @since 2023. 6. 1.
 * @author srec0083
 */
@Slf4j
@Service
public class ItmWtChangeAmountMgrServiceImpl implements ItmWtChangeAmountMgrService {

	@Autowired
	private ItmWtChangeAmountMgrMapper itmWtChangeAmountMgrMapper;
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	/**
	 * 아이템별 중량변동금 관리 그리드 데이터를 가져온다.
	 * @param ItmWtChangeAmountMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<ItmWtChangeAmountMgrVO> selectItmWtChangeAmountMgrGridList(ItmWtChangeAmountMgrVO itmWtChangeAmountMgrVO) throws Exception {
		
		return itmWtChangeAmountMgrMapper.selectItmWtChangeAmountMgrGridList(itmWtChangeAmountMgrVO);
	}

	/**
	 * 메탈 선택에 따른 아이템 리스트를 조회한다.
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<ItemCodeVO> getItemCodeList(String metalCode) throws Exception {
		
		return itmWtChangeAmountMgrMapper.getItemCodeList(metalCode);
	}

	/**
	 * 아이템별 중량변동금 관리 그리드 데이터 총 건수를 가져온다.
	 * @param ItmWtChangeAmountMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int selectItmWtChangeAmountMgrGridCount(ItmWtChangeAmountMgrVO itmWtChangeAmountMgrVO) throws Exception {
		
		return itmWtChangeAmountMgrMapper.selectItmWtChangeAmountMgrGridCount(itmWtChangeAmountMgrVO);
	}

	/**
	 * 아이템별 중량 변동금 수정 시 메탈, 아이템에 해당하는 데이터를 조회한다.
	 * @param ItmWtChangeAmountMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<ItmWtChangeAmountMgrVO> selectItmWtChangeAmountMgrDtlList(ItmWtChangeAmountMgrVO itmWtChangeAmountMgrVO) throws Exception {

		return itmWtChangeAmountMgrMapper.selectItmWtChangeAmountMgrDtlList(itmWtChangeAmountMgrVO);
	}

	
	/**
	 * 아이템별 중량 변동금을 저장한다.
	 * @param itmWtChangeAmountMgrsaveList
	 * @return
	 * @throws Exception
	 */
	@Override
	public int updateItmWtChangeAmountMgrSave(List<ItmWtChangeAmountMgrVO> itmWtChangeAmountMgrsaveList) throws Exception {
		
		int result = 0;
		String gubun = itmWtChangeAmountMgrsaveList.get(0).getGubun();
		String metalCode = itmWtChangeAmountMgrsaveList.get(0).getMetalCode();
		int itmSn = itmWtChangeAmountMgrsaveList.get(0).getItmSn();
		
		ItmWtChangeAmountMgrVO dtlVO = new ItmWtChangeAmountMgrVO();
		dtlVO.setMetalCode(metalCode);
		dtlVO.setItmSn(itmSn);
		
		List<ItmWtChangeAmountMgrVO> dtlList = itmWtChangeAmountMgrMapper.selectItmWtChangeAmountMgrDtlList(dtlVO);
		
		
		//등록이고 기존 데이터가 존재할 경우
		if("I".equals(gubun) && dtlList.size()>0) {
			return -1;
		}
		
		for(ItmWtChangeAmountMgrVO vo: itmWtChangeAmountMgrsaveList) {
			
			vo.setFrstRegisterId(userInfoUtil.getUserId());
			vo.setLastChangerId(userInfoUtil.getUserId());
			
			//삭제된 행일 경우
			if(vo.getDeleteAt().equals("deleted")) {
				result += itmWtChangeAmountMgrMapper.deleteItmWtChange(vo);
			}else if(!vo.getDeleteAt().equals("createAndDeleted")){
				//log.debug("vo : " + vo);
				result += itmWtChangeAmountMgrMapper.updateItmWtChangeAmountMgrSave(vo);
			}else {
				result += 1;
			}
		}
		
		if(result!=itmWtChangeAmountMgrsaveList.size()) {
			result = -1;
		}
		
		return result;
	}

	
	
	/**
	 * 아이템별 중량 변동금을 삭제한다.
	 * @param ItmWtChangeAmountMgrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int deleteItmWtChangeAmountMgr(ItmWtChangeAmountMgrVO itmWtChangeAmountMgrVO) throws Exception {
		
		itmWtChangeAmountMgrVO.setLastChangerId(userInfoUtil.getUserId());
		return itmWtChangeAmountMgrMapper. deleteItmWtChangeAmountMgr(itmWtChangeAmountMgrVO);
	}
	
	
	

}
