package com.sorincorp.bo.it.service;

import java.util.List;

import com.sorincorp.bo.it.model.BsnManageBasVO;
import com.sorincorp.bo.it.model.FixPriceVO;


public interface FixPriceService {
	
	/**
	 * 고정가 구매원가 관리
	 * @param FixPriceVO 
	 * @param FixPriceVO - 조회할 정보가 담긴 VO
	 * @return 고정가 구매원가 리스트
	 * @exception Exception
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 19.			thjeong 			최초작성
	 * ------------------------------------------------
	 */
	
	
	//public void insertAndUpdateFixPriceMng(List<FixPriceVO> fixPriceVOList);

	public List<FixPriceVO> selectListFixPrice(FixPriceVO fixPriceVO) throws Exception;

	public List<FixPriceVO> selectFixPriceSubCodeList(FixPriceVO fixPriceVO) throws Exception;

	//public void insertAndUpdateFixPriceSubMng(List<FixPriceVO> fixPriceVOList);

	public List<BsnManageBasVO> beginValidation();

	public void insertAndUpdateCodeAndSubCodeList(List<FixPriceVO> fixPriceVOList);

	public void deleteMon(List<FixPriceVO> fixPriceVOList) throws Exception;

}
