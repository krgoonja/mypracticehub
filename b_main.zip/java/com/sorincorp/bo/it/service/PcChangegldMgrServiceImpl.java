package com.sorincorp.bo.it.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.mapper.PcChangegldMgrMapper;
import com.sorincorp.bo.it.model.PcChangegldMgrVO;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;

@Service
public class PcChangegldMgrServiceImpl implements PcChangegldMgrService {
	
	@Autowired
	private CommonService commonService;
	@Autowired
	private PcChangegldMgrMapper pcChangegldMgrMapper;
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Override
	public List<PcChangegldMgrVO> selectPcChangegldMgrGridList(PcChangegldMgrVO pcChangegldMgrVO) throws Exception {
		
		return pcChangegldMgrMapper.selectPcChangegldMgrGridList(pcChangegldMgrVO);
	}

	@Override
	public List<ItemCodeVO> getItemCodeList(String metalCode) throws Exception {
		
		return pcChangegldMgrMapper.getItemCodeList(metalCode);
	}

	@Override
	public int selectPcChangegldMgrGridCount(PcChangegldMgrVO pcChangegldMgrVO) throws Exception {
		
		return pcChangegldMgrMapper.selectPcChangegldMgrGridCount(pcChangegldMgrVO);
	}

	@Override
	public List<PcChangegldMgrVO> selectPcChangegldMgrDtlList(PcChangegldMgrVO pcChangegldMgrVO) throws Exception {

		return pcChangegldMgrMapper.selectPcChangegldMgrDtlList(pcChangegldMgrVO);
	}

	@Override
	public int updatePcChangegldMgrSave(List<PcChangegldMgrVO> pcChangegldMgrsaveList) throws Exception {
		
		int result = 0;
		String gubun = pcChangegldMgrsaveList.get(0).getGubun();
		String metalCode = pcChangegldMgrsaveList.get(0).getMetalCode();
		String applcDe = pcChangegldMgrsaveList.get(0).getApplcDe();
		
		int itmSn = pcChangegldMgrsaveList.get(0).getItmSn();
		
		PcChangegldMgrVO dtlVO = new PcChangegldMgrVO();
		dtlVO.setApplcDe(applcDe);
		dtlVO.setMetalCode(metalCode);
		dtlVO.setItmSn(itmSn);
		
		List<PcChangegldMgrVO> dtlList = pcChangegldMgrMapper.selectPcChangegldMgrDtlList(dtlVO);
		
		//등록이고 기존 데이터가 존재할 경우
		if("I".equals(gubun) && dtlList.size()>0) {
			throw new Exception("동일한 적용일자의 동일한 아이템 설정이 존재합니다.\r\n\r\n다른 적용일자 또는 아이템을 선택해주세요.");
		}
		
		Map<String, String> keyMap = new HashMap<>();
		
		for(PcChangegldMgrVO vo: pcChangegldMgrsaveList) {
			
			vo.setFrstRegisterId(userInfoUtil.getUserId());
			vo.setLastChangerId(userInfoUtil.getUserId());
			
			//삭제된 행일 경우
			if(vo.getDeleteAt().equals("deleted")) {
				result += pcChangegldMgrMapper.deletePcChangegld(vo);
			}else if(!vo.getDeleteAt().equals("createAndDeleted")){
				//log.debug("vo : " + vo);
				result += pcChangegldMgrMapper.updatePcChangegldMgrSave(vo);
			}else {
				result += 1;
			}
			
			keyMap.put("PC_CHANGEGLD_MANAGE_BASS_SN", Long.toString(vo.getPcChangegldManageBassSn()));
			
			commonService.insertTableHistory("IT_PC_CHANGEGLD_MANAGE_BAS", keyMap);
		}
		
		if(result!=pcChangegldMgrsaveList.size()) {
			result = -1;
		}
		
		return result;
	}

	@Override
	public int deletePcChangegldMgr(PcChangegldMgrVO pcChangegldMgrVO) throws Exception {
		pcChangegldMgrVO.setLastChangerId(userInfoUtil.getUserId());
		
		int result = pcChangegldMgrMapper.deletePcChangegldMgr(pcChangegldMgrVO);
		
		Map<String, String> keyMap = new HashMap<>();
		
		int[] keyArr = pcChangegldMgrVO.getPcChangegldManageBassSnArr();
		
		for(int key : keyArr) {
			keyMap.put("PC_CHANGEGLD_MANAGE_BASS_SN", Integer.toString(key));
			
			commonService.insertTableHistory("IT_PC_CHANGEGLD_MANAGE_BAS", keyMap);
		}
		
		return result;
	}

}
