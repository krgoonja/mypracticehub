package com.sorincorp.bo.it.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.it.model.TrdeStrdrRtVO;

public interface TrdeStrdrRtService {


	/**
	 * <pre>
	 * 처리내용: 매매기준율 목록을 조회한다. 
	 * </pre>
	 * @date 2022. 9. 16.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 16.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @return
	 */
	List<TrdeStrdrRtVO> selectTrdeStdrRtListData(TrdeStrdrRtVO searchVO);
	
	/**
	 * <pre>
	 * 처리내용: 매매기준율 목록의 수를 조회한다.
	 * </pre>
	 * @date 2022. 9. 16.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 16.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @return
	 */
	int selectCntTrdeStdrRtList(TrdeStrdrRtVO searchVO);
	
	 /**
	 * <pre>
	 * 처리내용: 매매기준율 테이블의 기준 통화 코드를 조회한다.
	 * </pre>
	 * @date 2022. 9. 19.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 19.			srec0072			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	Map<String, Object> selectCurrCd();
}
