package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.FtrsFshgVO;

/**
 * FtrsFshgMngMapper.java
 * @version
 * @since 2022. 5. 27.
 * @author srec0066
 */
public interface FtrsFshgMngMapper {
	
	/**
	 *	선물/선물환 관리 목록을 조회한다.
	 */
	List<FtrsFshgVO> searchFtrsFshgList(FtrsFshgVO vo) throws Exception;
	
	/**
	 *	선물/선물환 관리 목록 총 개수를 조회한다.
	 */
	int selectFtrsFshgListTotCnt(FtrsFshgVO vo) throws Exception;
	
	/**
	 *	선물/선물환 관리를 등록, 수정 한다.
	 */
	void insertUpdateFtrsFshg(FtrsFshgVO vo) throws Exception;
	
	/**
	 *	키값을 가진 선물/선물환 관리 삭제데이터 유무를 확인한다.
	 */
	FtrsFshgVO checkFtrsFshgDeleteAt(FtrsFshgVO vo) throws Exception;
	
	/**
	 *	선물/선물환 관리를 삭제한다.
	 */
	void deleteFtrsFshg(FtrsFshgVO vo) throws Exception;
	
	/**
	 *	선물/선물환 관리 이력를 등록한다.
	 */
	void insertFtrsFshgDtlHst(FtrsFshgVO vo) throws Exception;
	
	/**
	 *	데이터 등록여부를 확인한다.
	 */
	int isAlreadyRegistered(FtrsFshgVO vo) throws Exception;
}
