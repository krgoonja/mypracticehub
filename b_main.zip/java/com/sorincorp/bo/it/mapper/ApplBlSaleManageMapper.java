package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.ApplBlSaleVO;


/**
 * <pre>
 * 처리내용: 지정 BL 판매 데이터를 조회한다.
 * </pre>
 * @date 2022. 12. 1.
 * @auther chajeeman
 * @history
 * -----------------------------------------------
 * 변경일					작성자				변경내용
 * -----------------------------------------------
 * 2022. 12. 1.			chajeeman			최초작성
 * -----------------------------------------------
 * @param applBlSaleVO
 * @return
 * @throws Exception
 */
public interface ApplBlSaleManageMapper {

	/**
	 * <pre>
	 * 처리내용: 조회조건의 총 카운트 수를 조회한다.
	 * </pre>
	 * @date 2022. 12. 1.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 1.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param applBlSaleVO
	 * @return
	 * @throws Exception
	 */
	public int getApplBlSaleManageListTotCnt(ApplBlSaleVO applBlSaleVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 지정 BL 판매 데이터를 조회한다.
	 * </pre>
	 * @date 2022. 12. 1.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 1.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param applBlSaleVO
	 * @return
	 * @throws Exception
	 */
	public List<ApplBlSaleVO> getApplBlSaleManageList(ApplBlSaleVO applBlSaleVO) throws Exception;


	public int insertApplBlSaleManage(ApplBlSaleVO applBlSaleVO) throws Exception;

	public int updateApplBlSaleManage(ApplBlSaleVO applBlSaleVO) throws Exception;

	public int deleteApplBlSaleManage(ApplBlSaleVO applBlSaleVO) throws Exception;

	public ApplBlSaleVO selectApplBlSaleManageData(ApplBlSaleVO searchVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 존재하는 BL 인지 체크
	 * </pre>
	 * @date 2023. 1. 13.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 1. 13.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param searchVO
	 * @return
	 * @throws Exception
	 */
	public int selectCntBlInfoBas(ApplBlSaleVO searchVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 해당 BL의 판매상태 체크
	 * </pre>
	 * @date 2023. 1. 16.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 1. 16.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param searchVO
	 * @return
	 * @throws Exception
	 */
	public ApplBlSaleVO selectBlInfoBas(ApplBlSaleVO searchVO) throws Exception;

	/**
	 * <pre>
	 * 지정가 주문 테이블에 미체결 건 조회 + 지정 BL 예외 재고 여부 체크 함수
	 * </pre>
	 * @date 2023. 5. 8.
	 * @author srec0051
	 * @param applBlSaleVO
	 * @return
	 * @throws Exception
	 */
	public int getCntUnSelLimitOrder(ApplBlSaleVO applBlSaleVO) throws Exception;
}
