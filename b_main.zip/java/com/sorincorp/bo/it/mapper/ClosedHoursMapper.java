package com.sorincorp.bo.it.mapper;

import java.util.HashMap;
import java.util.List;

import com.sorincorp.bo.it.model.ClosedHoursVO;
import com.sorincorp.bo.it.model.LmeHolidayVO;

public interface ClosedHoursMapper {

	/**
	 * <pre>
	 * 휴무 시간리스트를 조회한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 17.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<ClosedHoursVO> getClosedHoursList(ClosedHoursVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 휴무 시간리스트 카운트를 조회한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 17.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int getClosedHoursListCnt(ClosedHoursVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 휴무 시간 단건을 조회한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 17.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	ClosedHoursVO getClosedHours(ClosedHoursVO vo) throws Exception;

	/**
	 * <pre>
	 * 휴무 시간을 등록한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 17.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertClosedHoursList(ClosedHoursVO vo) throws Exception;

	/**
	 * <pre>
	 * 휴무 시간 히스토리를 등록한다
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 17.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertClosedHoursListHist(ClosedHoursVO vo) throws Exception;

	/**
	 * <pre>
	 * 휴무 시간을 수정한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 17.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void updateClosedHoursList(ClosedHoursVO vo) throws Exception;

	/**
	 * <pre>
	 * 휴무 시간을 삭제한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 17.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void deleteClosedHoursList(ClosedHoursVO vo) throws Exception;

	/**
	 * <pre>
	 * 히스토리를 저장한다.
	 * </pre>
	 * @date 2021. 7. 26.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 26.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertClosedHoursHist(ClosedHoursVO vo) throws Exception;
}
