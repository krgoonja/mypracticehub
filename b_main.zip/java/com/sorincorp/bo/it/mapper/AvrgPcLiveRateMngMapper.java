package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.AvrgPcLiveGradInfoVO;
import com.sorincorp.bo.it.model.AvrgPcLiveRateDtlVO;
import com.sorincorp.bo.it.model.AvrgPcLiveRateMngVO;

/**
 * AvrgPcLiveRateMngMapper.java
 * 평균가 라이브 비율 관리 Mapper 인터페이스
 * 
 * @version
 * @since 2023. 8. 16.
 * @author srec0049
 */
public interface AvrgPcLiveRateMngMapper {
	
	/**
	 * <pre>
	 * 처리내용: 평균가 라이브 비율 관리 목록(총 건수 포함)을 가져온다.
	 * </pre>
	 * @date 2023. 8. 16.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 16.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @return
	 * @throws Exception
	 */
	public List<AvrgPcLiveRateMngVO> getListAvrgPcLiveRate(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 금속코드와 적용일자에 대한 평균가 라이브 비율 관리 목록(상품_평균가 LIVE 기준 중량 관리 기본) 중복 건수를 가져온다.
	 * </pre>
	 * @date 2023. 8. 24.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 24.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @return
	 * @throws Exception
	 */
	public Integer getAvrgPcLiveRateDuplCnt(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 상품_평균가 LIVE 기준 중량 관리 기본 정보를 가져온다.
	 * </pre>
	 * @date 2023. 8. 29.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 29.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @return
	 * @throws Exception
	 */
	public AvrgPcLiveRateMngVO getAvrgPcLiveRate(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 금속 코드에 해당하는 톤당 구매 비율 리스트를 가져온다.
	 * </pre>
	 * @date 2023. 10. 16.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 10. 16.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateJson
	 * @param avrgPcLiveRateMngVO
	 * @return
	 * @throws Exception
	 */
	public List<AvrgPcLiveGradInfoVO> getPurchsRateValuePerTonListByMetalCode(String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 상품_평균가 LIVE 기준 중량 관리 상세에 평균 라이브 비율 기준 톤수 데이터 리스트를 가져온다.
	 * </pre>
	 * @date 2023. 9. 4.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 9. 4.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @return
	 * @throws Exception
	 */
	public List<AvrgPcLiveRateDtlVO> getAvrgPcLiveRateDtlList(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 상품_평균가 LIVE 기준 중량 관리 기본에 평균 라이브 비율 데이터를 등록한다.
	 * </pre>
	 * @date 2023. 8. 28.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 28.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @return
	 */
	public int insertItAvrgpcLiveStdrWtManageBas(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 상품_평균가 LIVE 기준 중량 관리 기본에 평균 라이브 비율 데이터를 수정한다.
	 * </pre>
	 * @date 2023. 9. 4.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 9. 4.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @return
	 * @throws Exception
	 */
	public int updateItAvrgpcLiveStdrWtManageBas(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 상품_평균가 LIVE 기준 중량 관리 기본에 평균 라이브 비율 데이터를 삭제한다.
	 * </pre>
	 * @date 2023. 9. 4.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 9. 4.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @return
	 * @throws Exception
	 */
	public int deleteItAvrgpcLiveStdrWtManageBas(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 상품_평균가 LIVE 기준 중량 관리 기본에 대한 이력을 등록한다.
	 * </pre>
	 * @date 2023. 8. 28.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 28.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @return
	 */
	public int insertItAvrgpcLiveStdrWtManageBasHst(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 상품_평균가 LIVE 기준 중량 관리 상세에 평균 라이브 비율 기준 톤수 데이터를 등록 또는 수정한다.
	 * </pre>
	 * @date 2023. 8. 28.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 28.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @return
	 * @throws Exception
	 */
	public int insertAndUpdateItAvrgpcLiveStdrWtManageDtl(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 상품_평균가 LIVE 기준 중량 관리 상세에 평균 라이브 비율 기준 톤수 데이터를 삭제한다.
	 * </pre>
	 * @date 2023. 9. 4.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 9. 4.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @return
	 * @throws Exception
	 */
	public int deleteItAvrgpcLiveStdrWtManageDtl(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 상품_평균가 LIVE 기준 중량 관리 상세에 대한 이력을 등록한다.
	 * </pre>
	 * @date 2023. 8. 28.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 28.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @return
	 * @throws Exception
	 */
	public int insertItAvrgpcLiveStdrWtManageDtlHst(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO) throws Exception;
}
