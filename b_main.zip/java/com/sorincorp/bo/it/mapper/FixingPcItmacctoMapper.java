package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.FixingPcItmacctoVO;

/**
 * FixingPcItmacctoMapper.java
 * @version
 * @since 2023. 3. 7.
 * @author srec0064
 */
public interface FixingPcItmacctoMapper {

	/**
	 * <pre>
	 * 처리내용: 구매제한/가격관리 리스트 조회
	 * </pre>
	 * @date 2023. 3. 6.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 6.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	List<FixingPcItmacctoVO> selectPurchsLmttPcManageList(FixingPcItmacctoVO vo);

	/**
	 * <pre>
	 * 처리내용: 구매제한/가격관리 정보 업데이트
	 * </pre>
	 * @date 2023. 3. 7.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 7.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	int updatePurchsLmttPcManage(FixingPcItmacctoVO vo);

	/**
	 * <pre>
	 * 처리내용: 구매제한/가격관리 정보 이력 테이블 insert
	 * </pre>
	 * @date 2023. 3. 7.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 7.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	int insertPurchsLmttPcManageHst(FixingPcItmacctoVO vo);

	/**
	 * <pre>
	 * 처리내용: 구매제한/가격관리삭제
	 * </pre>
	 * @date 2023. 3. 8.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 8.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	int deletePurchsLmttPcManage(FixingPcItmacctoVO vo);

	/**
	 * <pre>
	 * 처리내용: 구매제한/가격관리 전월 데이터를 읽어온다. 현재월에 등록되어있지 않은 아이템은 제외
	 * </pre>
	 * @date 2023. 3. 8.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 8.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param preApplcYm
	 * @param applcYm
	 * @param dstrctLclsfCode
	 * @return
	 */
	List<FixingPcItmacctoVO> selectPreMonthData(String preApplcYm, String applcYm, String dstrctLclsfCode);

	/**
	 * <pre>
	 * 처리내용: 구매제한/가격관리 저장
	 * </pre>
	 * @date 2023. 3. 8.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 8.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	int insertPurchsLmttPcManage(FixingPcItmacctoVO vo);

	/**
	 * <pre>
	 * 처리내용: 고정가 구매원가 관리 리스트 조회
	 * </pre>
	 * @date 2023. 3. 7.
	 * @author srec0064
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 7.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	public List<FixingPcItmacctoVO> geFixingPcItmacctoPrmpcList(FixingPcItmacctoVO vo);

	/**
	 * <pre>
	 * 처리내용: 상품_고정가 아이템별 원가 기본 테이블 merge
	 * </pre>
	 * @date 2023. 3. 9.
	 * @author srec0064
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 9.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	public void insertAndUpdateItFixingPcItmacctoPrmpcBas(FixingPcItmacctoVO vo);

	/**
	 * <pre>
	 * 처리내용: 상품_고정가 아이템별 원가 기본 이력 테이블 insert
	 * </pre>
	 * @date 2023. 3. 9.
	 * @author srec0064
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 9.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	public void insertItFixingPcItmacctoPrmpcBasHst(FixingPcItmacctoVO vo);

	/**
	 * <pre>
	 * 처리내용: 상품_고정가 아이템별 원가 기본을 조회한다.
	 * </pre>
	 * @date 2023. 3. 9.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 9.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param fixingPcItmacctoVO
	 * @return
	 */
	List<FixingPcItmacctoVO> selectItFixingPcItmacctoPrmpcBasList(FixingPcItmacctoVO fixingPcItmacctoVO);

	/**
	 * <pre>
	 * 처리내용: 구매제한/가격관리 insert or update
	 * </pre>
	 * @date 2023. 3. 10.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 10.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param fixingPcItmacctoVO
	 * @return
	 */
	int insertAndUpdatePurchsLmttPcManage(FixingPcItmacctoVO fixingPcItmacctoVO);


	/**
	 * <pre>
	 * 처리내용: 수정해야할 구매 원가 상세테이블을 조회한다.
	 * </pre>
	 * @date 2023. 3. 13.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 13.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param fixingPcItmacctoVO
	 * @return
	 */
	List<FixingPcItmacctoVO> selectPurchsLmttPcManageListByPrmPc(FixingPcItmacctoVO fixingPcItmacctoVO);

	/**
	 * <pre>
	 * 처리내용: 구매원가에서 변경된 데이터를 구매원가 상세 테이블에 반영한다.
	 * </pre>
	 * @date 2023. 3. 13.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 13.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param fixingPcItmacctoVO
	 * @return
	 */
	int updatePurchsLmttPcManageByPrmPc(FixingPcItmacctoVO fixingPcItmacctoVO);

	/**
	 * <pre>
	 * 처리내용: 구매제한, 가격관리 테이블 적용년월 , 권역 별 count 조회
	 * </pre>
	 * @date 2023. 3. 13.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 13.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param fixingPcItmacctoVO
	 * @return
	 */
	int selectPurchsLmttPcCount(FixingPcItmacctoVO fixingPcItmacctoVO);

}
