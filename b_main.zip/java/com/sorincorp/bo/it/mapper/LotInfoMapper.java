package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.LotInfoVO;

public interface LotInfoMapper {

	List<LotInfoVO> selectLotInfoList(LotInfoVO lotInfoVO) throws Exception;

	List<LotInfoVO> selectWrhousngList(LotInfoVO lotInfoVO) throws Exception;

	List<LotInfoVO> selectOvsiteList(LotInfoVO lotInfoVO) throws Exception;

}
