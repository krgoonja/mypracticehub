package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.BlInfoDtlVO;
import com.sorincorp.bo.it.model.BlNoInqireVO;
import com.sorincorp.bo.it.model.LqdIntDatResVO;

public interface BlNoInqireMapper {

	List<BlNoInqireVO> selectBlNoInqireList(BlNoInqireVO blNoInqireVO) throws Exception;

	BlNoInqireVO selectBlNoInqireDetail(String blNo) throws Exception;

	int selectItPurchsInfoBasCnt(String blNo) throws Exception;

	int selectItBlInfoBasCnt(String blNo) throws Exception;

	int updateItPurchsInfoBas(BlNoInqireVO blNoInqireVO) throws Exception;

	int updateFtrsProfsSeCode(BlNoInqireVO blNoInqireVO) throws Exception;

	int insertItPurchsInfoBas(BlNoInqireVO blNoInqireVO) throws Exception;

	void insertItPurchsInfoBasHst(BlNoInqireVO blNoInqireVO) throws Exception;

	BlNoInqireVO selectBlSleSttusCodeChgData(String blNo) throws Exception;

	int updateItBlSleSttus(BlNoInqireVO blSleSttusCodeChgVO) throws Exception;

	int insertItBlInfoBasHst(String blNo) throws Exception;

	String selectVwEpoFileUrl(BlNoInqireVO blNoInqireVO) throws Exception;

	List<BlNoInqireVO> selectItBlInfoBasList();

	int deletetIsecoSleClBas(String getDateTime);

	int insertIsecoSleClBas(BlNoInqireVO blNoInqireVO);

	int insertIsecoSleClBasHst(BlNoInqireVO blNoInqireVO);

	List<BlNoInqireVO> selectBlNoInqireDetailHst(BlNoInqireVO blNoInqireVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 파일 업로드
	 * </pre>
	 *
	 * @date 2022. 12. 23.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 23.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param blNoInqireVO
	 * @return
	 */
	int updateBlNoInqireFile(BlNoInqireVO blNoInqireVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: PO정보 없을때 insert
	 * </pre>
	 *
	 * @date 2022. 12. 29.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 29.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param blNoInqireVO
	 * @return
	 */
	int insertlNoInqireItPurchsInfoBas(BlNoInqireVO blNoInqireVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: del버튼 클릭시 마다 해당 BL 업데이트
	 * </pre>
	 *
	 * @date 2023. 1. 11.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2023. 1. 11.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param blNoInqireVO
	 */
	int updateItPurchInfoBas(BlNoInqireVO blNoInqireVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2023. 11. 6.
	 * @author srec0030
	 * @history 변경일:2023. 11. 6., 작성자:srec0030, 변경내용:최초작성
	 * @param blInfoDtlVO
	 * @return
	 */
	int selectBlSleSetupChgCnt(BlNoInqireVO blNoInqireVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2023. 11. 6.
	 * @author srec0030
	 * @history 변경일:2023. 11. 6., 작성자:srec0030, 변경내용:최초작성
	 * @param blInfoDtlVO
	 * @return
	 */
	int insertBlInfoBas(BlInfoDtlVO blInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2023. 11. 6.
	 * @author srec0030
	 * @history 변경일:2023. 11. 6., 작성자:srec0030, 변경내용:최초작성
	 * @param blInfoDtlVO
	 * @return
	 */
	int updateBlInfoBasInvntryAtmcCalc(BlNoInqireVO blNoInqireVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2023. 11. 6.
	 * @author srec0030
	 * @history 변경일:2023. 11. 6., 작성자:srec0030, 변경내용:최초작성
	 * @param blInfoDtlVO
	 * @return
	 */
	int insertItBlInfoHistDtl(BlNoInqireVO blNoInqireVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * 
	 * @date 2023. 11. 6.
	 * @author srec0030
	 * @history 변경일:2023. 11. 6., 작성자:srec0030, 변경내용:최초작성
	 * @param blInfoDtlVO
	 * @return
	 */
	int mergePoInfoBas(BlInfoDtlVO blInfoDtlVO) throws Exception;


	/**
	 * <pre>
	 * 처리내용: BL정보 입력/수정
	 * </pre>
	 * 
	 * @date 2024.02.06
	 * @author sumin
	 * @history 최초작성
	 * @param blInfoDtlVO
	 * @return
	 */
	int mergeBlInfoBas(BlNoInqireVO blNoInqireVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 선물/선물환 정보 입력/수정
	 * </pre>
	 * 
	 * @date 2024.02.06
	 * @author sumin
	 * @history 최초작성
	 * @param blInfoDtlVO
	 * @return
	 */
	int mergePrchsInfoBas(BlNoInqireVO blNoInqireVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: BL정보수정
	 * </pre>
	 * 
	 * @date 2024.02.06
	 * @author sumin
	 * @history 최초작성
	 * @param blInfoDtlVO
	 * @return
	 */
	int updateBlInfoBas(BlNoInqireVO blNoInqireVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 브랜드 리스트 
	 * </pre>
	 * 
	 * @date 2024.03.12
	 * @author sumin
	 * @history 최초작성
	 * @param BlNoInqireVO
	 * @return
	 */
	List<BlNoInqireVO> selectBrandInfoList(BlNoInqireVO blNoInqireVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 선물환 정보 매핑 
	 * </pre>
	 * 
	 * @date 2024.03.27
	 * @author sumin
	 * @history 최초작성
	 * @param LqdIntDatResVO
	 * @return
	 */
	List<LqdIntDatResVO> selectFshgInfoList(LqdIntDatResVO lqdIntDatResVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: BL 주문내역 조회
	 * </pre>
	 * 
	 * @date 2024.04.03
	 * @author sumin
	 * @history 최초작성
	 * @param String
	 * @return
	 */
	int getBlOrderCnt(String blNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: BL 정보 수정
	 * </pre>
	 * 
	 * @date 2024.04.03
	 * @author sumin
	 * @history 최초작성
	 * @param String
	 * @return
	 */
	int updateBlInfoDel(BlNoInqireVO blNoInqireVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: PO 정보 수정
	 * </pre>
	 * 
	 * @date 2024.04.03
	 * @author sumin
	 * @history 최초작성
	 * @param String
	 * @return
	 */
	int updatePurchsInfoDel(BlNoInqireVO blNoInqireVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: BL 정보 등록 (엑셀 업로드)
	 * </pre>
	 * 
	 * @date 2024.04.03
	 * @author sumin
	 * @history 최초작성
	 * @param BlNoInqireVO
	 * @return
	 */
	int insertXlsBlInfoBas(BlNoInqireVO blNoInqireVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: PO 정보 등록 (엑셀 업로드)
	 * </pre>
	 * 
	 * @date 2024.04.03
	 * @author sumin
	 * @history 최초작성
	 * @param BlNoInqireVO
	 * @return
	 */
	int insertXlsPurchsInfoBas(BlNoInqireVO blNoInqireVO) throws Exception;

	
	/**
	 * <pre>
	 * 처리내용: 선물 선물환 만기일자, FCM 변경
	 * </pre>
	 * 
	 * @date 2024.05.17
	 * @author sumin
	 * @history 최초작성
	 * @param BlNoInqireVO
	 * @return
	 */
	int updateBlExprtnDe(BlNoInqireVO blNoInqireVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: fileUri로 DOC_NO,JSO_SE_CODE,DOC_FILE_REAL_COURS 가져오기
	 * </pre>
	 * 
	 * @date 2024.07.15
	 * @author sein
	 * @history 최초작성
	 * @param BlNoInqireVO
	 * @return
	 */
	BlNoInqireVO selectCoDocBas(BlNoInqireVO blNoInqireVO) throws Exception;
}
