package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.LmeHolidayVO;
import com.sorincorp.bo.it.model.SalesDlvyManagementVO;
import com.sorincorp.bo.it.model.SalesManagementVO;

/**
 * SalesManagementMapper.java
 * @version
 * @since 2021. 5. 24.
 * @author srec0008
 */
public interface SalesManagementMapper {

	/**
	 * <pre>
	 * 영업관리 리스트 조회
	 * </pre>
	 * @date 2021. 5. 24.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 24.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<SalesManagementVO> getListSalesManagement(SalesManagementVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 영업관리 리스트 카운트 조회
	 * </pre>
	 * @date 2021. 5. 24.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 24.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int getListSalesManagementCnt(SalesManagementVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 영업관리 단건 조회
	 * </pre>
	 * @date 2021. 5. 24.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 24.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	SalesManagementVO getSalesManagement(SalesManagementVO vo) throws Exception;
	
	List<SalesDlvyManagementVO> getSalesDlvyManagement(SalesDlvyManagementVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 영업관리 등록
	 * </pre>
	 * @date 2021. 5. 24.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 24.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertSalesManagement(SalesManagementVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 영업 배송 관리 등록
	 * </pre>
	 * @date 2021. 7. 26.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 26.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertSalesDlvyManagement(SalesDlvyManagementVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 영업관리 수정
	 * </pre>
	 * @date 2021. 5. 24.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 24.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void updateSalesManagement(SalesManagementVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 영업관리 배송 수정
	 * </pre>
	 * @date 2021. 7. 26.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 26.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void updateSalesDlvyManagement(SalesDlvyManagementVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 영업관리 삭제(update)
	 * </pre>
	 * @date 2021. 5. 24.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 24.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void deleteSalesManagement(SalesManagementVO vo) throws Exception;

	/**
	 * <pre>
	 * 영업관리배송 삭제(update)
	 * </pre>
	 * @date 2021. 7. 26.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 26.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void deleteSalesDlvyManagement(SalesDlvyManagementVO vo) throws Exception;

	/**
	 * <pre>
	 * 영업관리 히스토리 저장
	 * </pre>
	 * @date 2021. 7. 27.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 27.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertSalesManagementHist(SalesManagementVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 영업배송관리 히스토리 저장
	 * </pre>
	 * @date 2021. 7. 27.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 27.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertSalesDlvyManagementHist(SalesDlvyManagementVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 현재 적용되어 있는 영업 시간을 가져온다.
	 * </pre>
	 * @date 2022. 5. 11.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 11.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	SalesManagementVO selectManagementTime() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 해당 영업일자로 등록된 데이터의 개수를 조회한다
	 * </pre>
	 * @date 2022. 8. 3.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 3.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int getSalesManagementCnt(SalesManagementVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 가장 최근 영업관리 리스트 1개 조회
	 * </pre>
	 * @date 2023. 4. 13.
	 * @author bok3117
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 4. 13.		bok3117		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<SalesManagementVO> getTopListSalesManagement(SalesManagementVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 최근 영업 리스트 조회
	 * </pre>
	 * @date 2023. 11. 13.
	 * @author bok3117
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일				작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 11. 13.	bok3117			최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param 
	 * @return
	 * @throws Exception
	 */
	SalesManagementVO selectTopListSalesManagement() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 영업시간 변경
	 * </pre>
	 * @date 2024.07. 17
	 * @author sumin
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일				작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024.07. 17.			sumin			최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param 
	 * @return
	 * @throws Exception
	 */
	int updateSalesTime(SalesManagementVO salesManagementVO) throws Exception;
}
