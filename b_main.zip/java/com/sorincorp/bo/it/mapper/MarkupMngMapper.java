package com.sorincorp.bo.it.mapper;

import java.math.BigDecimal;
import java.util.List;

import com.sorincorp.bo.it.model.MarkupMngVO;
import com.sorincorp.bo.it.model.SpreadVO;
import com.sorincorp.bo.or.model.UnityOrderFtrsVO;

public interface MarkupMngMapper {

	public List<MarkupMngVO> selectMarkUpFtrsList();
	
	public int selectMarkUpFtrsCnt();
	
	public List<MarkupMngVO> selectMarkUpFtrsCompList();
	
	public int selectMarkUpFtrsCompCnt();

	public BigDecimal getTodaySpread(SpreadVO todayVO);
	
	public void updateMarkUpTbl(UnityOrderFtrsVO unitVO);
	
	public int updateMarkupInfo(MarkupMngVO markupVO);
	
	public MarkupMngVO selectMarkupInfo();
	
}
