package com.sorincorp.bo.it.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.it.model.DisplayCtgryMgrVO;
import com.sorincorp.bo.it.model.ItemMgrVO;

public interface DisplayCtgryMgrMapper {

	/**
	 * <pre>
	 * 처리내용: 카테고리 리스트 정보를 조회한다.
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param ctgryLevel
	 * @return
	 * @throws Exception
	 */
	List<DisplayCtgryMgrVO> selectDisplayCtgryList(int ctgryLevel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 카테고리 정보를 등록하거나 업데이트한다.
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @return
	 * @throws Exception
	 */
	int updateDisplayCtgryMgr(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 카테고리정보에 아이템 순번을 카테고리 관계테이블에 매핑한다.
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @return
	 * @throws Exception
	 */
	int insertDisplayCtgryMgr(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 카테고리 정보에 아이템 매핑정보를 카테고리 관계테이블에 등록한다.
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @return
	 * @throws Exception
	 */
	int insertCtgryRls(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 카테고리 정보에 아이템 매핑정보를 카테고리 관계테이블에서 삭제한다
	 * </pre>
	 * @date 2021. 7. 6.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 6.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @return
	 * @throws Exception
	 */
	int selectCtgryRlsCnt(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 카테고리 정보에 매핑된 카테고리 관계테이블의 정보를 삭제한다.
	 * </pre>
	 * @date 2021. 7. 6.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 6.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param rlsVo
	 * @return
	 * @throws Exception
	 */
	int deleteCtgryRls(DisplayCtgryMgrVO rlsVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 카테고리 정보에 매핑된 카테고리 관계테이블의 카테고리순번을 조회한다.
	 * </pre>
	 * @date 2021. 7. 6.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 6.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @return
	 * @throws Exception
	 */
	int selectCtgryRlsCtgrySn(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception;

	List<ItemMgrVO> selectCtgryItemList(ItemMgrVO itemMgrVO) throws Exception;

	DisplayCtgryMgrVO selectCtgryInfo(int ctgryNo) throws Exception;

	int deleteDisplayCtgryMgr(DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception;

	List<DisplayCtgryMgrVO> selectCtgryInfoList(Map<String, Object> param) throws Exception;

	void insertItItmCtgryBasHst(DisplayCtgryMgrVO vo) throws Exception;

	List<DisplayCtgryMgrVO> selectCtgryRlsCtgrySnList(DisplayCtgryMgrVO vo) throws Exception;

	int isAlreadyRegisteredCtgry(DisplayCtgryMgrVO displayCtgryMgrVO);



}
