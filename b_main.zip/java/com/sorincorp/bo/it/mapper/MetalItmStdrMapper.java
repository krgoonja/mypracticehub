package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.BsnManageBasVO;
import com.sorincorp.bo.it.model.MetalItmStdrVO;
import com.sorincorp.bo.it.model.RvcmpnPriceMngVO;

public interface MetalItmStdrMapper {
	
	public List<MetalItmStdrVO> selectMetalItmStdrList(MetalItmStdrVO metalItmStdrVO) throws Exception;
	
	public int selectMetalItmStdrCnt(MetalItmStdrVO metalItmStdrVO) throws Exception;

	public void insertAndUpdateMetalItmStdrList(MetalItmStdrVO metalItmStdrVO) throws Exception;
	
	public void updateMetalItmStdrItmAt() throws Exception;
	
	public void deleteMetalItmStdr(MetalItmStdrVO metalItmStdrVO) throws Exception;
	
	public void insertItMetalItmStdrBasHst(MetalItmStdrVO metalItmStdrVO) throws Exception;
}
