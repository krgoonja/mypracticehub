package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.BsnManageBasVO;
import com.sorincorp.bo.it.model.RvcmpnPriceMngVO;

public interface RvcmpnPriceMngMapper {
	
	/**
	 * 경쟁사 가격 목록을 조회한다.
	 * @param SidecarVO - 조회할 정보가 담긴 VO
	 * @return 사이드카 리스트
	 * @exception Exception
	 */
	public List<RvcmpnPriceMngVO> searchRvcmpnPriceMngList(RvcmpnPriceMngVO rvcmpnPriceMngVO) throws Exception;

	public void insertRvcmpnPriceMng(RvcmpnPriceMngVO rvcmpnPriceMngVO);
	
	public void updateRvcmpnPriceMng(RvcmpnPriceMngVO rvcmpnPriceMngVO);

	public RvcmpnPriceMngVO searchOneRvcmpnPriceMng(RvcmpnPriceMngVO rvcmpnPriceMngVO);

	public int searchRvcmpnPriceMngTotalCnt(RvcmpnPriceMngVO rvcmpnPriceMngVO);

	public void deleteRvcmpnPrice(RvcmpnPriceMngVO rvcmpnPriceMngVO);

	public List<BsnManageBasVO> beginValidation(RvcmpnPriceMngVO vo);

	public int selectDupRvcmpnPrice(RvcmpnPriceMngVO vo);

	/**
	 * <pre>
	 * 경쟁사 가겨 관리 히스토리 등록
	 * </pre>
	 * @date 2022. 1. 15.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 15.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 */
	public void insertRvcmpnPriceMngHST(RvcmpnPriceMngVO vo);
}
