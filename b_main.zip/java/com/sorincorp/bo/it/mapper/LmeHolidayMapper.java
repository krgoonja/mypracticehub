package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.LmeHolidayVO;

/**
 * LmeHolidayMapper.java
 * @version
 * @since 2021. 5. 10.
 * @author srec0008
 */
public interface LmeHolidayMapper {

	/**
	 * <pre>
	 * 현재 년월 조회
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 15.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	LmeHolidayVO getLmeCurrentDate(LmeHolidayVO vo) throws Exception;

	/**
	 * <pre>
	 * 휴일 리스트 조회
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 15.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<LmeHolidayVO> getLmeClndrList(LmeHolidayVO vo) throws Exception;

	

}
