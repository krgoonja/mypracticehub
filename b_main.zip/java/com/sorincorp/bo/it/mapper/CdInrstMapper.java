package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.CdInrstVO;

public interface CdInrstMapper {

	/**
	 * <pre>
	 * 처리내용: cd금리 목록을 조회한다.
	 * </pre>
	 * @date 2022. 9. 19.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 19.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param civo
	 * @return
	 */
	List<CdInrstVO> selectCdInrstListData(CdInrstVO civo);
	
	/**
	 * <pre>
	 * 처리내용: cd금리 목록의 수를 카운트 한다.
	 * </pre>
	 * @date 2022. 9. 19.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 19.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param civo
	 * @return
	 */
	int selectCntCdInrstListData(CdInrstVO civo);

	/**
	 * <pre>
	 * 처리내용: 차트를 위해 cd금리 목록을 조회한다.
	 * </pre>
	 * @date 2022. 10. 4.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 4.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param civo
	 * @return
	 */
	List<CdInrstVO> selectForChartCdListData(CdInrstVO civo);

}
