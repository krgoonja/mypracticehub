package com.sorincorp.bo.it.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.it.model.ItemMgrVO;

public interface ItemMgrMapper {


	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 14.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 14.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	List<ItemMgrVO> selectItemMgrList(ItemMgrVO itemMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 14.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 14.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	int selectItemMgrTotalCnt(ItemMgrVO itemMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 18.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 18.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 */
	ItemMgrVO selectItemMgrDetail(ItemMgrVO itemMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 18.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 18.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 */
	List<ItemMgrVO> selectStdSpecList(ItemMgrVO itemMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 18.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 18.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 */
	ItemMgrVO selectItemCtgry(ItemMgrVO itemMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 6. 22.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 22.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 */
	int updateItemInfoBas(ItemMgrVO itemMgrVO) throws Exception;

	List<ItemMgrVO> selectItemCtgryBas(Map<String, Object> map) throws Exception;

	int deleteItemCtgryRls(ItemMgrVO ctgryVO) throws Exception;

	int insertItemCtgryRls(ItemMgrVO ctgryVO) throws Exception;

	List<ItemMgrVO> selectitemCtgryList(int itmSn) throws Exception;

	void insertItemCtgryRlsHst(int ctgrySn) throws Exception;

	int deleteImgFile(ItemMgrVO vo) throws Exception;

	int updateItemPriorRank(ItemMgrVO itemMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2022. 09. 20.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 09. 20.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	void updateitMetalItmWtChangeBas(ItemMgrVO itemMgrVO) throws Exception;

}
