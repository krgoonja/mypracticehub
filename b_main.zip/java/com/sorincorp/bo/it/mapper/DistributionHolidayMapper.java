package com.sorincorp.bo.it.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.it.model.DistributionHolidayVO;


/**
 * DistributionHolidayMapper.java
 * @version
 * @since 2021. 6. 07.
 * @author srec0008
 */
public interface DistributionHolidayMapper {

	/**
	 * <pre>
	 * 물류 휴일 목록을 조회한다.
	 * </pre>
	 * @date 2021. 6. 07.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 07.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<DistributionHolidayVO> getDistributionHolidayList(DistributionHolidayVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 공통 코드 조회
	 * </pre>
	 * @date 2021. 7. 26.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 26.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<Map<String, Object>> getDstrctCodeList(DistributionHolidayVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 창고 코드를 가져온다.
	 * </pre>
	 * @date 2021. 8. 2.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 2.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<Map<String, Object>> getWrhousCode(DistributionHolidayVO vo) throws Exception;
}
