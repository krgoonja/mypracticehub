package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.BsnManageBasVO;
import com.sorincorp.bo.it.model.FixPriceVO;

public interface FixPriceMapper {
	
	/**
	 * 고정가 구매 원가 기본 이력을 조회한다.
	 * @param FixPriceVO - 조회할 정보가 담긴 VO
	 * @return 고정가 리스트
	 * @exception Exception
	 */
	public List<FixPriceVO> selectListFixPrice(FixPriceVO fixPriceVO) throws Exception;

	List<FixPriceVO> selectFixPriceSubCodeList(FixPriceVO fixPriceVO) throws Exception;
	
	public List<BsnManageBasVO> beginValidation();
	
	public void insertAndUpdateFixPriceMng(FixPriceVO fixPriceVO);
	public void insertAndUpdateFixPriceMngHst(FixPriceVO fixPriceVO);
	
	public void insertAndUpdateFixPriceSubMng(FixPriceVO fixPriceVO);
	public void insertAndUpdateFixPriceSubMngHst(FixPriceVO fixPriceVO);

	public void deleteMon(FixPriceVO fixPriceVOList);
	
	public void deleteMonDtl(FixPriceVO fixPriceVOList);

	

}