package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.EventHolidayVO;
import com.sorincorp.bo.it.model.LmeHolidayVO;

/**
 * EventHolidayMapper.java
 * @version
 * @since 2021. 6. 15.
 * @author srec0008
 */
public interface EventHolidayMapper {

	/**
	 * <pre>
	 * 이벤트 휴일 목록을 조회한다.
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 15.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<EventHolidayVO> getEventHolidayList(EventHolidayVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 이벤트 휴일 관리를 등록한다
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 15.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertEventHoliday(EventHolidayVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 이벤트 휴일 관리를 수정한다.
	 * </pre>
	 * @date 2021. 7. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void updateEventHoliday(EventHolidayVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 이벤트 휴일을 삭제한다
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 15.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void deleteEventHoliday(EventHolidayVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 이벤트 휴일 히스토리 저장
	 * </pre>
	 * @date 2021. 7. 26.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 26.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertEventHolidayHistory(EventHolidayVO vo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * Nation(국가) 코드 리스트 조회
	 * </pre>
	 * @date 2022. 1. 7.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 7.			srec0054			최초작성
	 * ------------------------------------------------
	 * @return	List<EventHolidayVO>
	 * @throws 	Exception
	 */
	List<EventHolidayVO> getNationCodeList() throws Exception;
}
