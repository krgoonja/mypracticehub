package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.PcChangegldMgrVO;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;

public interface PcChangegldMgrMapper {
	List<PcChangegldMgrVO> selectPcChangegldMgrGridList(PcChangegldMgrVO pcChangegldMgrVO) throws Exception;
	
	List<ItemCodeVO> getItemCodeList(String metalCode) throws Exception;
	
	int selectPcChangegldMgrGridCount(PcChangegldMgrVO pcChangegldMgrVO) throws Exception;
	
	List<PcChangegldMgrVO> selectPcChangegldMgrDtlList(PcChangegldMgrVO pcChangegldMgrVO) throws Exception;
	
	int updatePcChangegldMgrSave(PcChangegldMgrVO pcChangegldMgrVO) throws Exception;
	
	int deletePcChangegld(PcChangegldMgrVO pcChangegldMgrVO) throws Exception;
	
	int deletePcChangegldMgr(PcChangegldMgrVO pcChangegldMgrVO) throws Exception;
}
