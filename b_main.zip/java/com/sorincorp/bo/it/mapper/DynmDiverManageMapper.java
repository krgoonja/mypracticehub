package com.sorincorp.bo.it.mapper;

import com.sorincorp.bo.it.model.DynmDiverMangeVO;

public interface DynmDiverManageMapper {

	DynmDiverMangeVO selectGtxApiFxrate() throws Exception;

	DynmDiverMangeVO selectSlePc() throws Exception;

	DynmDiverMangeVO selectDiverAt() throws Exception;

	void updateDiverAt(DynmDiverMangeVO diverVo) throws Exception;

	String selectDiverPremiumId() throws Exception;

	DynmDiverMangeVO selectDiverPremium(String premiumId) throws Exception;
	
}
