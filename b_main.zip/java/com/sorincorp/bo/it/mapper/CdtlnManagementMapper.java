package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.CdtlnManagementVO;


/**
 * CdtlnManagementMapper.java
 * @version
 * @since 2022. 7. 18.
 * @author srec0061
 */
public interface CdtlnManagementMapper {


	/**
	 * <pre>
	 * 처리내용: 여신관리 리스트 조회
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<CdtlnManagementVO> getListCdtlnManagement(CdtlnManagementVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 여신관리 리스트 카운트 조회
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int getListCdtlnManagementCnt(CdtlnManagementVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 여신관리 등록
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertCdtlnManagement(CdtlnManagementVO vo)throws Exception;

	/**
	 * <pre>
	 * 처리내용: 여신관리 히스토리 저장
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertCdtlnManagementHist(CdtlnManagementVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 여신관리 수정
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void updateCdtlnManagement(CdtlnManagementVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 여신관리 단건 조회
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	CdtlnManagementVO getCdtlnManagement(CdtlnManagementVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 여신관리 삭제(update)
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void deleteCdtlnManagement(CdtlnManagementVO vo)throws Exception;

	/**
	 * <pre>
	 * 처리내용: 데이터 등록여부를 확인한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int isAlreadyRegistered(CdtlnManagementVO vo)throws Exception;



	
}
