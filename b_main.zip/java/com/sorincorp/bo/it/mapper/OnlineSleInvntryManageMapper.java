package com.sorincorp.bo.it.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.it.model.OnlineSleInvntryManageVO;

public interface OnlineSleInvntryManageMapper {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 8. 4.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 4.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	List<OnlineSleInvntryManageVO> selectLogisticsCenterList(Map<String, Object> param) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 8. 4.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 4.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	List<OnlineSleInvntryManageVO> selectBlInfoBasList(Map<String, Object> param) throws Exception;

}
