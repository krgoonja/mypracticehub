package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.SidecarVO;

public interface SidecarMapper {
	
	/**
	 * 사이드카 목록을 조회한다.
	 * @param SidecarVO - 조회할 정보가 담긴 VO
	 * @return 사이드카 리스트
	 * @exception Exception
	 */
	public List<SidecarVO> searchSidecarList(SidecarVO sidecarVO) throws Exception;

	public void deleteSidecar(SidecarVO sidecarVO) throws Exception;


	public void insertSidecar(SidecarVO sidecarVO);


	public void updateSidecar(SidecarVO sidecarVO);


	public SidecarVO searchOneSidecar(SidecarVO sidecarVO);

	public int searchSidecarTotalCnt(SidecarVO sidecarVO);

	public int selectDupSidecar(SidecarVO vo);
	
	public void insertSidecarHst(SidecarVO vo);

	
	public List<SidecarVO> searchSidecarDtlList(SidecarVO sidecarVO);

	public int searchSidecarTotalDtlCnt(SidecarVO sidecarVO);

	public void updateMotnAt(SidecarVO sidecarVO);

	public void selectUpdateMotnAtN(SidecarVO sidecarVO);

}
