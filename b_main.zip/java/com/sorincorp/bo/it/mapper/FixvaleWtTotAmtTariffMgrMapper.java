package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.FixvaleWtTotAmtTariffMgrVO;

public interface FixvaleWtTotAmtTariffMgrMapper {

	List<FixvaleWtTotAmtTariffMgrVO> selectFixvaleWtTotAmtTariffMgrList(FixvaleWtTotAmtTariffMgrVO fixvaleWtTotAmtTariffMgrVO) throws Exception;

	int selectFixvaleWtTotAmtTariffMgrTotCnt(FixvaleWtTotAmtTariffMgrVO fixvaleWtTotAmtTariffMgrVO) throws Exception;

	int deleteItFixingPcWtTotAmtTariffManageDtl(FixvaleWtTotAmtTariffMgrVO delDtlVO) throws Exception;

	int insertItFixingPcWtTotAmtTariffManageDtlHst(FixvaleWtTotAmtTariffMgrVO delDtlVO) throws Exception;

	int deleteItFixingPcWtTotAmtTariffManageBas(FixvaleWtTotAmtTariffMgrVO delDtlVO) throws Exception;

	int insertItFixingPcWtTotAmtTariffManageBasHst(FixvaleWtTotAmtTariffMgrVO delDtlVO) throws Exception;

	List<FixvaleWtTotAmtTariffMgrVO> selectFixvaleWtTotAmtTariffDtlList(FixvaleWtTotAmtTariffMgrVO fixvaleWtTotAmtTariffMgrVO) throws Exception;

	int insertItFixingPcWtTotAmtTariffManageDtl(FixvaleWtTotAmtTariffMgrVO saveVO) throws Exception;

	int insertItFixingPcWtTotAmtTariffManageBas(FixvaleWtTotAmtTariffMgrVO saveVO) throws Exception;

	int updateItFixingPcWtTotAmtTariffManageBas(FixvaleWtTotAmtTariffMgrVO saveVO) throws Exception;


}
