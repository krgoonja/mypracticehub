package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.LqdIntDatResVO;

public interface FtrsApiMgrMapper {

	/**
	 * <pre>
	 * 목록 조회 카운트
	 * </pre>
	 * @date 2022. 1. 25.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 25.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param lqdIntDatResVO
	 * @return
	 */
	int getDataCount(LqdIntDatResVO lqdIntDatResVO);

	/**
	 * <pre>
	 * 목록 조회
	 * </pre>
	 * @date 2022. 1. 25.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 25.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param lqdIntDatResVO
	 * @return
	 */
	List<LqdIntDatResVO> getDataList(LqdIntDatResVO lqdIntDatResVO);

}
