package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.BsnManageBasVO;
import com.sorincorp.bo.it.model.CommCodeTmpVO;
import com.sorincorp.bo.it.model.ItHghnetprcPurchsPrmpcBasVO;
import com.sorincorp.bo.it.model.LmeEvalCashVO;
import com.sorincorp.bo.it.model.PrEhgtPcRltmBasVO;
import com.sorincorp.bo.it.model.PremiumAvrgPurchsPrmpcVO;
import com.sorincorp.bo.it.model.PremiumBrandBasVO;
import com.sorincorp.bo.it.model.PremiumBrandGroupBasVO;
import com.sorincorp.bo.it.model.PremiumDetailProfitAndLoseVO;
import com.sorincorp.bo.it.model.PremiumDstrctBasVO;
import com.sorincorp.bo.it.model.PremiumEntrpsGradBasVO;
import com.sorincorp.bo.it.model.PremiumMonFxEvaluationCashVO;
import com.sorincorp.bo.it.model.PremiumSetPriceVO;
import com.sorincorp.bo.it.model.PremiumStdrBasVO;
import com.sorincorp.bo.it.model.WrtmStdrAmoutMangeVO;

public interface PremiumPriceMngMapper {

	public void updatePremiumPriceValidation(PremiumStdrBasVO vo);
	public void insertPremiumPriceValidationHst(PremiumStdrBasVO vo);

	public void insertAndUpdatePremiumStdrPrice(PremiumStdrBasVO psVO);

	public void insertAndUpdatePremiumDstrctPrice(PremiumDstrctBasVO premiumDstrctBasVO);
	public void insertAndUpdatePremiumDstrctPriceHst(PremiumDstrctBasVO premiumDstrctBasVO);


	public void insertAndUpdatePremiumBrandGroupPrice(PremiumBrandGroupBasVO vo);
	public void insertAndUpdatePremiumBrandGroupPriceHst(PremiumBrandGroupBasVO vo);


	public void insertAndUpdatePremiumBrandPrice(PremiumBrandBasVO vo);
	public void insertAndUpdatePremiumBrandPriceHst(PremiumBrandBasVO vo);

	public void insertAndUpdatePremiumBrandDtlPrice(PremiumStdrBasVO vo);
	public void insertAndUpdatePremiumBrandDtlPriceHst(PremiumStdrBasVO vo);


	public List<PremiumStdrBasVO> selectPremiumList(PremiumStdrBasVO psbVO);

	public int selectPremiumCnt(PremiumStdrBasVO psbVO);

	public PremiumStdrBasVO getPremiumStdInfoByPremiumId(String premiumId);

	public List<PremiumSetPriceVO> getPrimiumLivePriceList(PremiumSetPriceVO psVO);

	public PrEhgtPcRltmBasVO getprEhgtPcFirstByToday();

	public void insertAndUpdatePremiumBrandDtlLotDtlRls(String premiumId);

	public int getPremiumDuplicateCnt(PremiumStdrBasVO vo);

	public List<PremiumSetPriceVO> getSetPrimiumFixPriceList(PremiumSetPriceVO psVO);

	public PremiumAvrgPurchsPrmpcVO getAvrgPurchsPrmpc(PremiumSetPriceVO vo);

	public int getPremiumBrandBasCnt(String premiumId);

	public void deletePremiumPrice(PremiumStdrBasVO vo);

	public List<PremiumMonFxEvaluationCashVO> get6FxMonEvalutaion();

	public List<PremiumDetailProfitAndLoseVO> getPremiumDetailProfitAndLoseUpdate(PremiumDetailProfitAndLoseVO vo);

	public int selectPremiumStdrItmAt(PremiumStdrBasVO vo);

	public void updatePremiumStdrItmAt(PremiumStdrBasVO vo);

	public void savePremiumStdrItmAt(PremiumStdrBasVO vo);

	public PremiumStdrBasVO getPremiumDuplicatePremiumId(PremiumStdrBasVO vo);

	public List<PremiumSetPriceVO> getSetPrimiumLivePriceDetailList(PremiumSetPriceVO psVO);

	public int getHghnetprcCount(PremiumStdrBasVO vo);

	public List<PremiumSetPriceVO> getSetPrimiumFixPriceDetailList(PremiumSetPriceVO vo);

	public PremiumStdrBasVO getPremiumDuplicatePremiumId2(PremiumStdrBasVO vo);

	public LmeEvalCashVO getOneDayAgoLmeEvalCash();

	public PremiumStdrBasVO getMetalItmStdr(PremiumSetPriceVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 삭제할 시작일자보다 과거의 종료일자 정보 조회
	 * </pre>
	 * @date 2022. 8. 5.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 5.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	public PremiumStdrBasVO getPastEndDateInfo(PremiumStdrBasVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 과거의 종료일자 업데이트
	 * </pre>
	 * @date 2022. 8. 8.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 8.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	public void updatePastDt(PremiumStdrBasVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 적용일시(시작일시) 중복 조회
	 * </pre>
	 * @date 2022. 8. 9.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 9.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	public int getDuplicateCnt(PremiumSetPriceVO vo);
	
	public PremiumStdrBasVO getPremiumDuplicatePremiumId3(PremiumStdrBasVO vo);
	
	public PremiumStdrBasVO getSelectedPremium(PremiumStdrBasVO vo);

	public String getEhgtPcRltm();
	
	public List<PremiumBrandBasVO> getSelectedPremiumBrand(PremiumStdrBasVO vo);

	//프리미엄 기준 테이블 복사
	public void insertSelectPremiumStrdBas(PremiumStdrBasVO vo);
	
	//프리미엄 권역 테이블 복사
	public void insertSelectPremiumDstrctBas(PremiumStdrBasVO vo);
	
	//프리미엄 브랜드그룹 테이블 복사
	public void insertSelectPremiumBrandGroupBas(PremiumStdrBasVO vo);
	
	//프리미엄 브랜드 테이블 복사
	public void insertSelectPremiumBrandBas(PremiumStdrBasVO vo);

	//프리미엄 기준 테이블 수정
	public void updateEndDtPremiumStrdBas(PremiumStdrBasVO vo);
	
}
