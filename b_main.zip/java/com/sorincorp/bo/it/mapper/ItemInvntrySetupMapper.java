package com.sorincorp.bo.it.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.model.ItemInvntrySetupVO;
import com.sorincorp.bo.it.model.ItemInvntrySmsVO;

public interface ItemInvntrySetupMapper {
	
	/**
	 * <pre>
	 * 처리내용: 
	 * </pre>
	 * @date 2022. 12. 20.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 20.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param itemInvntrySetupVO
	 * @return
	 * @throws Exception
	 */
	int selectPopItemInvntrySetupListTotCnt(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 
	 * </pre>
	 * @date 2022. 12. 20.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 20.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param itemInvntrySetupVO
	 * @return
	 * @throws Exception
	 */
	List<ItemInvntrySetupVO> selectPopItemInvntrySetupList(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;

	List<ItemInvntrySetupVO> selectItemInvntrySetupList(Map<String, Object> param) throws Exception;
	
	List<ItemInvntrySetupVO> selectEntrpsList(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;

	ItemInvntrySetupVO callSpEcInvntryDdctProcess(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;
	
	ItemInvntrySetupVO callSpEcDummyOrder(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;
	
	ItemInvntrySetupVO selectNewestDummyOrder(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;
	
	ItemInvntrySetupVO selectBlSleInvntryUnsle(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;
	
	List<ItCmnCodeVO> getWrhousCellLcList(String wrhousCode) throws Exception;

	int updateSleSttusCode(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;

	void insertItBlInfoBasHst(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;

	ItemInvntrySetupVO selectBlInfoBas(String blNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: BL 번호(복수) 조건으로 BL 정보를 리스트로 가져온다.
	 * </pre>
	 * @date 2024. 1. 17.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 1. 17.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param blNoList
	 * @return
	 * @throws Exception
	 */
	List<ItemInvntrySetupVO> getListBlInfoBas(@Param("blNoList") List<String> blNoList) throws Exception;

	int updateSleSetupBundleCo(Map<String, Object> param) throws Exception;

	int updateRmndrDscnt(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;

	void insertItBlInfoHistDtl(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;

	int selectBlSleSetupChgCnt(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;
	
	List<ItemInvntrySmsVO> selectItemInvntrySmsList(Map<String, Object> param) throws Exception;

	List<ItemInvntrySmsVO> selectMetalList() throws Exception;

	List<ItemInvntrySmsVO> selectMetalSmsMberList() throws Exception;

	List<ItemInvntrySmsVO> selectCustomerCaseList() throws Exception;

	ItemInvntrySetupVO selectBlSleSttusCodeChgData(String blNo) throws Exception;
	
	/**
	 * 자투리보기 목록
	 * @param itemInvntrySetupVO
	 * @return
	 * @throws Exception
	 */
    List<ItemInvntrySetupVO> selectItemSclptrList(Map<String, Object> param) throws Exception;
    

	/**
	 * <pre>
	 * 처리내용: BL 정보 조회
	 * </pre>
	 * @date 2023. 10. 26.
	 * @auther hyunjin0512
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 10. 26.		hyunjin0512			최초작성
	 * -----------------------------------------------
	 * @param ItemInvntrySetupVO
	 * @return
	 * @throws Exception
	 */
	ItemInvntrySetupVO selectItemInvntrySetupInfo(ItemInvntrySetupVO itemInvntrySetupVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: BL 정보 조회
	 * </pre>
	 * @date 2024. 04. 01.
	 * @auther hamyoonsic
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024. 04. 01.		hamyoonsic			최초작성
	 * -----------------------------------------------
	 * @param itemInvntrySetupVO
	 * @return
	 * @throws Exception
	 */
	List<ItemInvntrySetupVO> selectBlList(Map<String, Object> param) throws Exception;

}
