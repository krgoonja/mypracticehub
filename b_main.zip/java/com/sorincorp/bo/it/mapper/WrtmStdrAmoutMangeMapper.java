package com.sorincorp.bo.it.mapper;

import java.util.List;

import com.sorincorp.bo.it.model.WrtmStdrAmoutMangeVO;

public interface WrtmStdrAmoutMangeMapper {
	
	/**
	 * <pre>
	 * 처리내용: 증거금 기준금액 목록을 조회한다
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	public List<WrtmStdrAmoutMangeVO> getWrtmStdrAmoutMangeList(WrtmStdrAmoutMangeVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 증거금 기준금액 목록 카운트를 조회한다
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	public int selectWrtmStdrAmoutMangeCnt(WrtmStdrAmoutMangeVO vo);

	/**
	 * <pre>
	 * 처리내용: 증거금 기준금액 테이블의 중복을 체크한다
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	public int getWrtmStdrDuplicateCnt(WrtmStdrAmoutMangeVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 상품_증거금 기준 금액 관리 기본 테이블 merge
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	public void insertAndUpdateItWrtmStdrAmoutMangeBas(WrtmStdrAmoutMangeVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 상품_증거금 기준 금액 관리 기본 이력 테이블 insert
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	public void insertItWrtmStdrAmoutMangeBasHst(WrtmStdrAmoutMangeVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 상품_증거금 기준 금액 관리 상세 테이블 merge
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	public void insertAndUpdateItWrtmStdrAmoutMangeDtl(WrtmStdrAmoutMangeVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 상품_증거금 기준 금액 관리 상세 이력 테이블 insert
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	public void insertItWrtmStdrAmoutMangeDtlHst(WrtmStdrAmoutMangeVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 상품_증거금 기준 금액 관리 상세 테이블을 조회한다
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	public List<WrtmStdrAmoutMangeVO> getItWrtmStdrAmoutMangeDtlList(WrtmStdrAmoutMangeVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 상품_증거금 기준 금액 관리 기본 테이블을 조회한다
	 * </pre>
	 * @date 2022. 7. 14.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 14.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	public WrtmStdrAmoutMangeVO getItWrtmStdrAmoutMangeBas(WrtmStdrAmoutMangeVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 상품_증거금 기준 금액 관리 기본 테이블 update
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	public void updateItWrtmStdrAmoutMangeBas(WrtmStdrAmoutMangeVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 상품_증거금 기준 금액 관리 상세 테이블 update
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	public void updateItWrtmStdrAmoutMangeDtl(WrtmStdrAmoutMangeVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 상품_증거금 기준 금액 관리 기본 테이블 delete
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	public void deleteItWrtmStdrAmoutMangeBas(WrtmStdrAmoutMangeVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 상품_증거금 기준 금액 관리 상세 테이블 delete
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	public void deleteItWrtmStdrAmoutMangeDtl(WrtmStdrAmoutMangeVO vo);
}
