package com.sorincorp.bo.it.model;

import lombok.Data;

@Data
public class PremiumSetPriceVO {

	private int itmSn;
	private String itmCode;
	private String sleMthdCode;
	private String metalCode;
	private String premiumId;

	/**
	 * 권역 대분류 코드
	 */
	private String dstrctLclsfCode;
	/**
	 * 권역 대분류 변동금
	 */
	private String dstrctChangeAmount;
	/**
	 * 권역 대분류 명
	 */
	private String dstrctLclsfNm;
	/**
	 * 브랜드 그룹 코드
	 */
	private String brandGroupCode;
	/**
	 * 브랜드 그룹 변동금
	 */
	private String brandGroupChangeAmount;
	/**
	 * 브랜드 그룹 명
	 */
	private String brandGroupNm;
	/**
	 * 브랜드 코드
	 */
	private String brandCode;
	/**
	 * 브랜드 변동금
	 */
	private String brandChangeAmount;
	/**
	 * 브랜드 명
	 */
	private String brandNm;
	/**
	 * 구매 프리미엄 (달러)
	 */
	private java.math.BigDecimal purchsPremiumDollarAmount;
	/**
	 * 구매 프리미엄 (원화)
	 */
	private String purchsPremiumWonAmount;
	/**
	 * 구매 평균 비용
	 */
	private String avgPurchs;
	/**
	 * 구매 원가
	 */
	private String purchsWonAmount;


	/**
	 * 프리미엄 (KRW)
	 * */
	private String premiumPriceKrw;
	/**
	 * 프리미엄 (USD)
	 * */
	private java.math.BigDecimal premiumPriceUsd;
	private String premiumStdrAmount;
	/**
	 * 입고
	 * */
	private String netWt;
	/**
	 * 판매 설정
	 * */
	private String sleSetupWt;
	/**
	 * 판매설정 B/L 수
	 * */
	private String sleSetupBlCo;
	/**
	 * 판매설정 번들 수
	 * */
	private String sleSetupBundleCo;
	/**
	 * 미판매 잔량
	 * */
	private int sleInvntryUnsleBnt;
	/**
	 * 판매 미설정
	 */
	private int wrhousSleUnsetupInvntry;
	/**
	 * 판매 완료
	 */
	private int ecSleComptInvntry;
	/**
	 * 마진
	 */
	private java.math.BigDecimal margin;
	/**
	 * 환율
	 */
	private java.math.BigDecimal stdrEhgtPc;



	private String purchsCtAvrgDollarAmount;
	private String purchsCtAvrgWonAmount;
	private String purchsDollarPrmpc;
	private String purchsWonPrmpc;
	private String avrgWt;
	private String lotQy;

	private String entrpsGradCode;
	private String entrpsGradNm;

	private java.math.BigDecimal gradChangeAmount;  //등급변동금
	private java.math.BigDecimal slePc; //판매가격
	private java.math.BigDecimal puchasPc; //매입가격
	private java.math.BigDecimal avrgProfitAmount;  //평균이익금
	private java.math.BigDecimal hghnetprcAvrgPurchsPrmpc;  //기준판매가

	private String ftrsprocessat; //선물처리여부

	private String validBeginDt;	//적용 시작 일시
	
	private String temp;

}