package com.sorincorp.bo.it.model;

import lombok.Data;

@Data
public class PremiumBlDtlVO {
	private String premiumId;
	private String brandGroupCode;
	private String brandCode;
}
