package com.sorincorp.bo.it.model;

import javax.validation.constraints.NotEmpty;

import com.sorincorp.bo.it.model.SalesManagementVO.InsertAndUpdate;
import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class RvcmpnPriceMngVO extends CommonVO {
	
	private static final long serialVersionUID = 1L;
	
	/******  JAVA VO CREATE : IT_RVCMPN_PC_MANAGE_BAS(상품_경쟁사 가격 관리 기본)                                                            ******/
    /**
     * 적용 일자
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String applcDe;
    /**
     * 브랜드 그룹 코드
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String brandGroupCode;
	/**
     * 브랜드 그룹명
    */
    private String brandGroupNm;
    /**
     * 조달청 가격
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private java.math.BigDecimal sarokPc;
    /**
     * PLATTS 가격
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private java.math.BigDecimal plattsPc;
    /**
     * MB 가격
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private java.math.BigDecimal mbPc;
	/**
	 * 기준 시작일자
	 * */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
	private String fromApplcDe;
	/**
	 * 기준 종료일자
	 * */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
	private String toApplcDe;
	/**
	 * 메탈코드
	 */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
	private String metalCode;
	/**
	 * 메탈명
	 */
	private String metalNm;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    /**
     * 그리드 상태값
    */
    String gridRowStatus;
}
