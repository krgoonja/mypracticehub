package com.sorincorp.bo.it.model;

import lombok.Data;

@Data
public class PremiumDetailProfitAndLoseVO {
	/**
     * 환율 가격
    */
    private java.math.BigDecimal ehgtPc;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 1일전 lme 종가
    */
    private java.math.BigDecimal lmeEvalCash;
    /**
	 * 금속 코드
	 */
	private String metalCode;
    /**
	 * 프리미엄 아이디
	 */
	private String premiumId;
	/**
     * 프리미엄 기준 금액(KRW)
    */
	private java.math.BigDecimal premiumStdrAmountKrw;
	/**
     * 프리미엄 기준 금액(USD)
    */
	private java.math.BigDecimal premiumStdrAmountUsd;
	
	/**
	 * 권역 이름
	 */
	private String dstrctLclsfNm;
	/**
	 * 브랜드 그룹 이름
	 */
	private String brandGroupNm;
	/**
	 * 브랜드 그룹 이름
	 */
	private String brandNm;
	/**
	 * 브랜드 그룹 이름
	 */
	private String blNo;
	/**
	 * 브랜드 그룹 이름
	 */
	private double sleSetupWt;
	
	
	/**
	 * U_PRICE
	 */
	private java.math.BigDecimal uprice;
	/**
	 * 구매 프리미엄
	 */
	private java.math.BigDecimal purchsPremiumDollarAmount;
	/**
	 * 구매 총비용
	 */
	private java.math.BigDecimal ctSmWonCt;
	/**
	 * LME_FS
	 */
	private java.math.BigDecimal ftrsLmeDollarPc;
	/**
	 * LME_FB
	 */
	private java.math.BigDecimal purchsLmeDollarPc;
	
	/**
	 * FX SPREAD - FXS
	 */
	private java.math.BigDecimal ftrsSpreadWonPc;
	/**
	 * FX SPREAD - FXB
	 */
	private java.math.BigDecimal purchsSpreadDollarPc;
	
	/**
	 * THC(터미널)
	 */
	private long lgistTrminlUseWonCt;
	/**
	 * 셔틀비
	 */
	private long lgistLandTrnsprtWonCt;
	/**
	 * 하역비
	 */
	private long lgistLnlWonCt;
	/**
	 * 보관료
	 */
	private long chcy;
	/**
	 * 기타비용
	 */
	private long lgistEtcWonCt;
	/**
	 * 통관 수수료
	 */
	private long entrFeeWonCt;
	/**
	 * 금융비용 - 이자비용
	 */
	private long fnncIntrWonCt;
	/**
	 * 금융비용 - 기타비용
	 */
	private long fnncEtcWonCt;
	
	/**
	 * 선물 만기일
	 */
	private String ftrsExprtnDe;
	/**
	 * 선물 만기일
	 */
	private long ftrsExprtnPr;
	
	/**
	 * 선물 수수료 FS
	 */
	private java.math.BigDecimal ftrsDollarFee;

	/**
	 * 선물 수수료 FB
	 */
	private java.math.BigDecimal purchsDollarFee;
	
}

