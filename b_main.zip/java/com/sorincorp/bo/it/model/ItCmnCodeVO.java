package com.sorincorp.bo.it.model;

import com.sorincorp.bo.sample.model.SampleDefaultVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ItCmnCodeVO extends SampleDefaultVO {

	/**
	 *
	 */
	private static final long serialVersionUID = 288966383862492291L;
	/**
     * 메인 코드
    */
    private String mainCode;
    /**
     * 서브 코드
    */
    private String subCode;
    /**
     * 코드 명
    */
    private String codeNm;
    /**
     * 서브코드 + 코드 명
     */
    private String codeNm2;
    /**
     * 코드 길이
    */
    private int codeLt;
    /**
     * 코드 순서
    */
    private int codeOrdr;
    /**
     * 코드 설명1
    */
    private String codeDcone;
    /**
     * 코드 설명2
    */
    private String codeDctwo;
    /**
     * 코드 참조1
    */
    private String codeRefrnone;
    /**
     * 코드 참조2
    */
    private String codeRefrntwo;
    /**
     * 코드 참조3
    */
    private String codeRefrnthree;
    /**
     * 코드 문자 참조1
    */
    private String codeChrctrRefrnone;
    /**
     * 코드 문자 참조2
    */
    private String codeChrctrRefrntwo;
    /**
     * 코드 문자 참조3
    */
    private String codeChrctrRefrnthree;
    /**
     * 코드 문자 참조4
    */
    private String codeChrctrRefrnfour;
    /**
     * 코드 문자 참조5
    */
    private String codeChrctrRefrnfive;
    /**
     * 코드 문자 참조6
    */
    private String codeChrctrRefrnsix;
    /**
     * 코드 숫자 참조1
    */
    private int codeNumberRefrnone;
    /**
     * 코드 숫자 참조2
    */
    private int codeNumberRefrntwo;
    /**
     * 코드 숫자 참조3
    */
    private int codeNumberRefrnthree;
    /**
     * 코드 숫자 참조4
    */
    private int codeNumberRefrnfour;
    /**
     * 시스템 여부
    */
    private String sysAt;
    /**
     * 트레이딩 사용 여부
    */
    private String extrlSysUseAt;
    /**
     * 사용 여부
    */
    private String useAt;
    /**
     * 트레이딩 연동 여부
    */
    private String extrlSysIntrlckAt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    /**
     *
    */
    private String extrlSysMainCode;
}
