package com.sorincorp.bo.it.model;

import javax.validation.constraints.NotEmpty;

import com.sorincorp.bo.it.model.SalesManagementVO.InsertAndUpdate;
import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class SidecarVO extends CommonVO{
	
	private static final long serialVersionUID = 1L;
	
    /**
     * 적용 일자
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    String applcDe;
    /**
     * 품목 대분류 코드
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    String metalCode;
    /**
     * 발동 여부
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    String motnAt;
    /**
     * 전일 대비 비율
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    String bfrtVersusRate;
    /**
     * 지속 시간
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    String cntncTime;
    /**
     * 가격 표시 불가 시간
    */
    String pcIndictImprtyTime;
    /**
     * 삭제 일시
    */
    String deleteDt;
    /**
     * 삭제 여부
    */
    String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    String frstRegistDt;
    /**
     * 최초 변경자 아이디
    */
    String lastChangerId;
    /**
     * 최초 변경 일시
    */
    String lastChangeDt;
    /**
     * 그리드 상태값
    */
    String gridRowStatus;
    
    
    
    /**
     * 발동 일자
    */
    String motnDe;
    /**
     * 발동 시작 일시
     */
    String motnBeginDt;
    /**
     * 발동 종료 일시
     */
    String motnEndDt;
    /**
     * 전일 가격
     */
    String bfrtPc;
    /**
     * 당일 가격
     */
    String todayPc;
    /**
     * 검색 기준
     */
    String dateGubun;
}