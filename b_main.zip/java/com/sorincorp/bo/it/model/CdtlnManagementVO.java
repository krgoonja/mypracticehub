package com.sorincorp.bo.it.model;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;


@Data
@EqualsAndHashCode(callSuper=true)
@Validated
public class CdtlnManagementVO extends CommonVO{
	
	private static final long serialVersionUID = 6827737465738953497L;
	
	public interface Search {
	};

	public interface InsertAndUpdate {
	};
	
	/**
     * 순번
     */
    private int seq;
    /**
     * 적용 일자
     */
    @NotEmpty(groups = InsertAndUpdate.class, message = "적용일자는 필수 입력입니다.")
    private String applcDe; 
    /**
     * 전자상거래보증 증권발급 수수료 보상 비율 (지원비율)
     */
    @DecimalMin(groups = InsertAndUpdate.class, value = "0", message = "지원비율은 0~100사이로 입력해주세요.")
    @DecimalMax(groups = InsertAndUpdate.class, value = "100", message = "지원비율은 0~100사이로 입력해주세요.")
    private double mrtgggrntyScritsissuFeeCmpnstnRate; 
    /**
     * 전자상거래보증 증권발급 수수료 보상 건당 인정 비율
     */
    @DecimalMin(groups = InsertAndUpdate.class, value = "0", message = "건당인정비율은 0~9999사이로 입력해주세요.")
    @DecimalMax(groups = InsertAndUpdate.class, value = "10000", message = "건당인정비율은 0~9999사이로 입력해주세요.")
    private double mrtgggrntyScritsissuFeeCmpnstnCsbyRate; 
    /**
     * 전자상거래보증 적용 일수
     */
    @Min(groups = InsertAndUpdate.class, value = 0, message = "적용일수는 0~999사이로 입력해주세요.")
    @Max(groups = InsertAndUpdate.class, value = 1000, message = "적용일수는 0~999사이로 입력해주세요.")
    private int mrtgggrntyApplcDaycnt; 
    /**
     * 전자상거래보증 연간 뱅킹 일수
     */
    @Min(groups = InsertAndUpdate.class, value = 0, message = "연간뱅킹데이는 0~999사이로 입력해주세요.")
    @Max(groups = InsertAndUpdate.class, value = 1000, message = "연간뱅킹데이는 0~999사이로 입력해주세요.")
    private int mrtgggrntyFyerBankingDaycnt; 
    /**
     * 전자상거래보증 케이지트레이딩 가산 금리
     */
    @DecimalMin(groups = InsertAndUpdate.class, value = "0", message = "케이지트레이딩가산금리는 0~9999사이로 입력해주세요.")
    @DecimalMax(groups = InsertAndUpdate.class, value = "10000", message = "케이지트레이딩가산금리는 0~9999사이로 입력해주세요.")
    private double mrtgggrntySorinsuprrAddiInrst; 
    /**
     * 전자상거래보증 연체 이자 비율
     */
    @DecimalMin(groups = InsertAndUpdate.class, value = "0", message = "연체이자는 0~100사이로 입력해주세요.")
    @DecimalMax(groups = InsertAndUpdate.class, value = "10000", message = "연체이자는 0~9999사이로 입력해주세요.")
    private double mrtgggrntyArrgIntrRate; 
    /**
     * CD금리 사용 여부
     */
    @NotEmpty(groups = InsertAndUpdate.class, message = "CD금리 사용여부는 필수 입력입니다.")
    private String cdInrstUseAt; 
    /**
     * 담보보증 무이자 일수
     */
    @Min(groups = InsertAndUpdate.class, value = 0, message = "무이자일수는 0~999사이로 입력해주세요.")
    @Max(groups = InsertAndUpdate.class, value = 1000, message = "무이자일수는 0~999사이로 입력해주세요.")
    private int mrtgggrntyNintrDaycnt;
    /**
     * 전자상거래보증 MP수수료 비율
     */
    @DecimalMin(groups = InsertAndUpdate.class, value = "0", message = "전자상거래보증수수료는 0~100사이로 입력해주세요.")
    @DecimalMax(groups = InsertAndUpdate.class, value = "10000", message = "전자상거래보증수수료는 0~100사이로 입력해주세요.")
    private double mrtgggrntyMpfeeRate; 
    /**
     * 대출보증 MP수수료 비율
     */
    @DecimalMin(groups = InsertAndUpdate.class, value = "0", message = "구매자금수수료는 0~100사이로 입력해주세요.")
    @DecimalMax(groups = InsertAndUpdate.class, value = "10000", message = "구매자금수수료는 0~100사이로 입력해주세요.")
    private double longrntyMpfeeRate; 
    /**
     * 여신관리 패널티 연체 건수
     */
    @Min(groups = InsertAndUpdate.class, value = 0, message = "연체건수는 0~100사이로 입력해주세요.")
    @Max(groups = InsertAndUpdate.class, value = 100, message = "연체건수는 0~100사이로 입력해주세요.")
    private int cdtlnManagePntArrrgCo; 
    /**
     * 여신관리 패널티 사고 건수
     */
    @Min(groups = InsertAndUpdate.class, value = 0, message = "사고건수는 0~100사이로 입력해주세요.")
    @Max(groups = InsertAndUpdate.class, value = 100, message = "사고건수는 0~100사이로 입력해주세요.")
    private int cdtlnManagePntAcdntCo; 
    /**
     * 삭제 일시
     */
    private String deleteDt; 
    /**
     * 삭제 여부
     */
    private String deleteAt; 
    /**
     * 최초 등록자 아이디
     */
    private String frstRegisterId; 
    /**
     * 최초 등록 일시
     */
    private String frstRegistDt; 
    /**
     * 최종 변경자 아이디
     */
    private String lastChangerId; 
    /**
     * 최종 변경 일시
     */
    private String lastChangeDt; 
    /**
     * 오늘날짜
     */
    private int nowDe;
    /**
     * 삭제 기준일 
     */
    private int deleteDe;


	/** Grid 상태 */
	private String gridRowStatus;

}