package com.sorincorp.bo.it.model;

import java.util.List;

import javax.validation.constraints.Size;

import org.springframework.validation.annotation.Validated;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@Validated
public class OnlineSleInvntryManageVO {

	public interface Search {};
	public interface InsertAndUpdate {};

	/******  JAVA VO CREATE : IT_BL_INFO_BAS(상품_BL 정보 기본)                                                                              ******/
    /**
     * BL 번호
    */
    private String blNo;
    /**
     * 창고 코드
    */
    private String wrhousCode;
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    /**
     * 금속 코드
    */
    @Size(max=1, message="{itemInfoDtlVO.materialCode.maxSizeOver}")
    private String metalCode;
    /**
     * 아이템 코드
    */
    private String itmCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 기초 입고 재고
    */
    private double bsisWrhousngInvntry;
    /**
     * 기초 입고 번들 재고
    */
    private int bsisWrhousngBundleInvntry;
    /**
     * 기초 악성 불량 재고
    */
    private double bsisMaliciousBadnInvntry;
    /**
     * 기초 악성 불량 번들 재고
    */
    private int bsisMaliciousBadnBundleInvntry;
    /**
     * 기초 악성 반출 재고
    */
    private double bsisMaliciousTkoutInvntry;
    /**
     * 기초 악성 반출 번들 재고
    */
    private int bsisMaliciousTkoutBundleInvntry;
    /**
     * 기초 가용 재고
    */
    private double bsisUsefulInvntry;
    /**
     * 기초 가용 번들 재고
    */
    private int bsisUsefulBundleInvntry;
    /**
     * 판매 설정 번들 수
    */
    private int sleSetupBundleCo;
    /**
     * 판매 설정 중량
    */
    private double sleSetupWt;
    /**
     * 판매 재고 미판매 잔량
    */
    private double sleInvntryUnsleBnt;
    /**
     * 판매 재고 미판매 번들 잔량
    */
    private int sleInvntryUnsleBundleBnt;
    /**
     * EC 판매 완료 재고
    */
    private double ecSleComptInvntry;
    /**
     * EC 판매 완료 번들 재고
    */
    private int ecSleComptBundleInvntry;
    /**
     * EC 교환 주문 재고
    */
    private double ecExchngOrderInvntry;
    /**
     * EC 교환 주문 번들 재고
    */
    private int ecExchngOrderBundleInvntry;
    /**
     * EC 출고 재고
    */
    private double ecDlivyInvntry;
    /**
     * EC 출고 번들 재고
    */
    private int ecDlivyBundleInvntry;
    /**
     * EC 미출고 재고
    */
    private double ecNootgInvntry;
    /**
     * EC 미출고 번들 재고
    */
    private int ecNootgBundleInvntry;
    /**
     * 창고 미출고 재고
    */
    private double wrhousNootgInvntry;
    /**
     * 창고 미출고 번들 재고
    */
    private int wrhousNootgBundleInvntry;
    /**
     * 창고 판매 미설정 재고
    */
    private double wrhousSleUnsetupInvntry;
    /**
     * 창고 판매 미설정 번들 재고
    */
    private int wrhousSleUnsetupBundleInvntry;
    /**
     * 기말 재고
    */
    private double trmendInvntry;
    /**
     * 기말 번들 재고
    */
    private int trmendBundleInvntry;
    /**
     * 입고 일자
    */
    private String wrhousngDe;
    /**
     * 통관 일자
    */
    private String entrDe;
    /**
     * 도착 예정 일시
    */
    private String arvlPrearngeDt;
    /**
     * NET 중량
    */
    private double netWt;
    /**
     * GROSS 중량
    */
    private double grossWt;
    /**
     * 판매 상태 코드
    */
    private String sleSttusCode;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
	/**
	 *
	 */
	private int itmSn;
	/**
	 *
	 */
	private String brandGroupCode;
	/**
	 *
	 */
	private String[] metalCodeArray;
	private String[] wrhousCodeArray;
	private String[] dstrctLclsfCodeArray;
	/**
	 *
	 */
	private String wrhousNm;
	/**
	 *
	 */
	private String metalCodeNm;
	/**
	 *
	 */
	private String ecUseAt;
	/**
	 *
	 */
	private String sleSetupWtTot;
	/**
	 *
	 */
	private int blTot;
	/**
	 *
	 */
	private String brandGroupCodeNm;
	/**
	 *
	 */
	private String brandNm;


	/**
	 *
	 */
	private int blCnt;
	/**
	 *
	 */
	private int invntryBundleTot;
	/**
	 *
	 */
	private double invntryWtTot;
	/**
	 *
	 */
	private String dstrctLclsfCodeNm;
	/**
	 *
	 */
	private int bundleQy;

	private String gubun;

	private String ftrsProcessAt;
}
