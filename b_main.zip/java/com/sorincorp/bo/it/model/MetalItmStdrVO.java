package com.sorincorp.bo.it.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;

// import com.sorincorp.bo.it.model.ClosedHoursVO.InsertAndUpdate;
import com.sorincorp.comm.model.CommonVO;
import com.sorincorp.comm.util.MessageUtil;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@Validated
public class MetalItmStdrVO extends CommonVO {
	
	private static final long serialVersionUID = 1L;
	
	public interface InsertAndUpdate {
	};
	
	public interface Delete {
	};
	
	@Autowired
	MessageUtil mesasgeUtil;
	
    /**
     * 금속 코드
    */
	@NotBlank(groups = Delete.class, message = "{bo.it.validation.required.metalCode}")
	@NotBlank(groups = InsertAndUpdate.class, message = "{bo.it.validation.required.metalCode}")
    private String metalCode;
	/**
     * 금속명
    */
    private String metalNm;  
    /**
     * 금속 분류 코드
     */
    @NotBlank(groups = Delete.class, message ="{bo.it.validation.required.metalClCode}")
    @NotBlank(groups = InsertAndUpdate.class, message ="{bo.it.validation.required.metalClCode}")
    private String metalClCode;
    /**
     * 금속 분류명
     */
    private String metalClNm;
    /**
     * 판매 방식 코드
    */
    @NotBlank(groups = Delete.class, message ="{bo.it.validation.required.sleMthdCode}")
    @NotBlank(groups = InsertAndUpdate.class, message ="{bo.it.validation.required.sleMthdCode}")
    private String sleMthdCode;
	
	/**
	 * 판매 방식 이름
	 */
	private String sleMthdNm;
    /**
     * 기준 아이템 여부
    */
	@NotBlank(groups = InsertAndUpdate.class, message ="{bo.it.validation.required.stdrItmAt}")
    private String stdrItmAt;
    /**
     * 아이템 순번
    */
    @NotBlank(groups = InsertAndUpdate.class, message ="{bo.it.validation.required.itmSn}")
    private String itmSn;
	/**
	 * 아이템명
	 */
	private String itmNm;
    /**
     * 권역 대분류 코드
    */
	@NotBlank(groups = InsertAndUpdate.class, message ="{bo.it.validation.required.dstrctLclsfCode}")
    private String dstrctLclsfCode;
	/**
	 * 권역 대분류명
	 */
	private String dstrctLclsfNm;
    /**
     * 브랜드 그룹 코드
    */
	@NotBlank(groups = InsertAndUpdate.class, message ="{bo.it.validation.required.brandGroupCode}")
    private String brandGroupCode;
	/**
	 * 브랜드 그룹명
	 */
	private String brandGroupNm;
    /**
     * 브랜드 코드
    */
	@NotBlank(groups = InsertAndUpdate.class, message ="{bo.it.validation.required.brandCode}")
    private String brandCode;
	/**
	 * 브랜드명
	 */
	private String brandNm;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
    /**
     * 그리드 상태
     */
    private String gridrowstatus;
}
