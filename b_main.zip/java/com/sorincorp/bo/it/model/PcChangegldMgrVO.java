package com.sorincorp.bo.it.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class PcChangegldMgrVO extends CommonVO{
	private static final long serialVersionUID = -9132260116511230036L;
	
	/******  JAVA VO CREATE : IT_PC_CHANGEGLD_MANAGE_BAS(상품_가격 변동금 관리 기본)                                                         ******/
    /**
     * 가격 변동금 관리 기본 순번
    */
    private long pcChangegldManageBassSn;
    /**
     * 적용 일자
    */
    private String applcDe;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 금속명
     */
    private String metalNm;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 아이템 명
     */
    private String itmNm;
    /**
     * 잠정 단가 구간 시작 금액
    */
    private long prvsnlUntpcSctnBeginAmount;
    /**
     * 잠정 단가 구간 종료 금액
    */
    private long prvsnlUntpcSctnEndAmount;
    /**
     * 최초 변동 금액
    */
    private Long frstChangeAmount;
    /**
     * 유지 변동 금액
    */
    private Long mntncChangeAmount;
    /**
     * 거래 불가 여부
    */
    private String delngImprtyAt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
 
	
    /**
     * 모달창 상태
     */
    private String modalPageStatus;

	private String gubun;
	
	private int[] pcChangegldManageBassSnArr;
}
