package com.sorincorp.bo.it.model;

import lombok.Data;

@Data
public class PremiumBrandBasVO {
	/******  JAVA VO CREATE : IT_PREMIUM_BRAND_BAS(상품_프리미엄 브랜드 기본)                                                                ******/
	    /**
	     * 프리미엄 번호
	    */
	    private String premiumNo;
	    /**
	     * 프리미엄 아이디
	    */
	    private String premiumId;
	    /**
	     * 권역 대분류 코드
	    */
	    private String dstrctLclsfCode;
	    /**
	     * 브랜드 그룹 코드
	    */
	    private String brandGroupCode;
	    /**
	     * 브랜드 코드
	    */
	    private String brandCode;
	    /**
	     * 브랜드 변동 금액
	    */
	    private java.math.BigDecimal brandChangeAmount;
	    /**
	     * 고정가 브랜드 변동 금액
	    */
	    private java.math.BigDecimal hghnetprcBrandChangeAmount;
	    /**
	     * 고정가 평균 구매 원가
	     */
	    private java.math.BigDecimal HghnetprcAvrgPurchsPrmpc;
	    /**
	     * 판매 프리미엄 금액
	    */
	    private java.math.BigDecimal slePremiumAmount;
	    /**
	     * 고정가 판매 금액
	    */
	    private java.math.BigDecimal hghnetprcSleAmount;
	    /**
	     * 삭제 일시
	    */
	    private java.sql.Timestamp deleteDt;
	    /**
	     * 삭제 여부
	    */
	    private String deleteAt;
	    /**
	     * 최초 등록자 아이디
	    */
	    private String frstRegisterId;
	    /**
	     * 최초 등록 일시
	    */
	    private java.sql.Timestamp frstRegistDt;
	    /**
	     * 최종 변경자 아이디
	    */
	    private String lastChangerId;
	    /**
	     * 최종 변경 일시
	    */
	    private java.sql.Timestamp lastChangeDt;
	    
	    

	 
}
