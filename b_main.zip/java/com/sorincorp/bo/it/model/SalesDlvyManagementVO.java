package com.sorincorp.bo.it.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.sorincorp.bo.it.model.SalesManagementVO.InsertAndUpdate;
import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * SalesManagementVO.java
 * @version
 * @since 2021. 5. 24.
 * @author srec0008
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class SalesDlvyManagementVO extends CommonVO{

	private static final long serialVersionUID = 6882956165304862133L;

	/**
     * 적용 일자
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String applcDe;
    /**
     * 금속 코드
    */
	@NotNull(message="{it.validaion.required}")
    private String metalCode;
	/**
	 * 금속 이름
	 */
	@NotNull(message="{it.validaion.required}")
	private String metalName;
    /**
     * 자차 출고 요청 시작 일
    */
	@NotNull(message="{it.validaion.required}")
    private int manatmbDlivyRequstBeginDe;
    /**
     * 자차 출고 요청 종료 일
    */
	@NotNull(message="{it.validaion.required}")
    private int manatmbDlivyRequstEndDe;
    /**
     * 자차 당일 출고 마감 시간
    */
	@NotNull(message="{it.validaion.required}")
    private String manatmbTodayDlivyClosTime;
    /**
     * 케이지배송 출고 요청 시작 일
    */
	@NotNull(message="{it.validaion.required}")
    private int sorinDlivyRequstBeginDe;
    /**
     * 케이지배송 출고 요청 종료 일
    */
	@NotNull(message="{it.validaion.required}")
    private int sorinDlivyRequstEndDe;
    /**
     * 케이지배송 당일 출고 마감 시간
    */
	@NotNull(message="{it.validaion.required}")
    private String sorinTodayDlivyClosTime;
	/**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
}