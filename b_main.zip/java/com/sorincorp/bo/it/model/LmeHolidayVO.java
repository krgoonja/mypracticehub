package com.sorincorp.bo.it.model;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * LmeHolidayVO.java
 * @version
 * @since 2021. 5. 10.
 * @author srec0008
 */
@Data
@EqualsAndHashCode(callSuper=false)
@Validated
public class LmeHolidayVO extends CommonVO {

	private static final long serialVersionUID = 6882956165304862133L;

    /**
     * 회사 코드
    */
    private String cmpnyCode;
    /**
     * 적용 일자
    */
    private String applcDe;
    /**
     * 요일
    */
    private String day;
    /**
     * 휴뮤 여부
     */
    private String holidayAt;
    /**
     * LME 달력 유형 코드
    */
    private String lmeCldrTyCode;
    /**
     * 비고
    */
    private String rm;
    /**
     * 등록 일시
    */
    private String registDt;
    /**
     * 등록자 아이디
    */
    private String registerId;
    /**
     * 수정 일시
    */
    private String updtDt;
    /**
     * 수정자 아이디
    */
    private String updusrId;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    
    /**
     * 최종 변경 일시
     */
    private String currentDate;
    

}