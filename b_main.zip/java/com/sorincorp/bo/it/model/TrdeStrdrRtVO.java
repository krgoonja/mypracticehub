package com.sorincorp.bo.it.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**매매기준율 관리*/
@Data
@EqualsAndHashCode(callSuper=false)
public class TrdeStrdrRtVO extends CommonVO {

    /**
     * 고시일자
    */
    private String valueDate;
    /**
     * 기준통화 코드
    */
    private String currCd;
    /**
     * 원화환산율
    */
    private java.math.BigDecimal korCvtrate;
    /**
     * 달러환산율
    */
    private java.math.BigDecimal usdCvtrate;
    /**
     * 업데이트 시간
    */
    private String updTime;
    
	/**
	 * 검색 날짜 시작일
	 */
	private String searchDateFrom;

	/**
	 * 검색 날짜 종료일
	 */
	private String searchDateEnd;
	
	/**
	 * 셀렉트 박스 검색기준1
	 */
	private String searchSelect1;
 

}
