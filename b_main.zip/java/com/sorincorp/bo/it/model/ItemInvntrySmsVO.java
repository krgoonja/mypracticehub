package com.sorincorp.bo.it.model;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Validated
public class ItemInvntrySmsVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -3108282541999820606L;

	private String metalCode;
	private String metalInfo;
	private String metalName;
	private String metalBrand;

	// 사용자 금속 케이스 및 번호
	private String caseNum;
	private String caseBit;

	// 수신자 연락처
	private String moblphonNo;

	/**
	 * 판매방식 고정 가 여부
	 */
	private String fixingPcAt;
	/**
	 * 판매방식 라이브 가 여부
	 */
	private String livePcAt;

}
