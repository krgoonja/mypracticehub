package com.sorincorp.bo.it.model;

import lombok.Data;

@Data
public class PremiumEntrpsGradBasVO {
	/******  JAVA VO CREATE : IT_PREMIUM_ENTRPS_GRAD_BAS(상품_프리미엄 업체 등급 기본)                                                       ******/
	/**
     * 프리미엄 아이디
    */
    private String premiumId;
	    /**
	     * 프리미엄 번호
	    */
	    private String premiumNo;
	    /**
	     *  권역 대분류 코드
	     */
	    private String dstrctLclsfCode;
	    /**
	     *  브랜드 그룹코드
	     */
	    private String brandGroupCode;
	    /**
	     * 업체 등급 코드
	    */
	    private String entrpsGradCode;
	    /**
	     * 등급 변동 금액
	    */
	    private long gradChangeAmount;
	    /**
	     * 판매 가격
	    */
	    private long slePc;
	    /**
	     * 평균 이익 금액
	    */
	    private long avrgProfitAmount;
	    /**
	     * 삭제 일시
	    */
	    private java.sql.Timestamp deleteDt;
	    /**
	     * 삭제 여부
	    */
	    private String deleteAt;
	    /**
	     * 최초 등록자 아이디
	    */
	    private String frstRegisterId;
	    /**
	     * 최초 등록 일시
	    */
	    private java.sql.Timestamp frstRegistDt;
	    /**
	     * 최종 변경자 아이디
	    */
	    private String lastChangerId;
	    /**
	     * 최종 변경 일시
	    */
	    private java.sql.Timestamp lastChangeDt;
	    
}
