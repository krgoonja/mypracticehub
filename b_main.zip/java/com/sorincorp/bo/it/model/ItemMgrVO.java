package com.sorincorp.bo.it.model;

import java.util.ArrayList;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.PositiveOrZero;
import javax.validation.constraints.Size;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.bo.sample.model.SampleDefaultVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Validated
public class ItemMgrVO extends SampleDefaultVO {
	/**
	 *
	 */
	private static final long serialVersionUID = -6792075936042823631L;

	public interface Search {
	};

	public interface InsertAndUpdate {
	};

	/**
	 * 아이템 순번
	 */
	@Min(groups = InsertAndUpdate.class, value = 0, message = "아이템순번은 필수 입력입니다.")
	private int itmSn;

	/**
	 * 우선순위
	 */
	private int priorRank;
	/**
	 * 금속 코드
	 */
	private String metalCode;
	/**
	 * 화학물질 1 코드
	 */
	private String chmclsOneCode;
	/**
	 * 화학물질 2 코드
	 */
	private String chmclsTwoCode;
	/**
	 * 모양 코드
	 */
	private String shapeCode;
	/**
	 * 모양 코드명
	 */
	private String shapeCodeNm;
	/**
	 * 아이템 코드
	 */
	private String itmCode;
	/**
	 * 아이템 품목 한글
	 */
	private String itmPrdlstKorean;
	/**
	 * 아이템 품목 영문
	 */
	private String itmPrdlstEng;
	/**
	 * 포장 코드
	 */
	private String packngCode;
	/**
	 * 포장 코드명
	 */
	private String packngCodeNm;
	/**
	 * ERP 품목 코드
	 */
	private String erpPrdlstCode;
	/**
	 * 세번 코드
	 */
	private String hsCode;
	/**
	 * 유효 시작 일자
	 */
	private String validBeginDe;
	/**
	 * 유효 종료 일자
	 */
	private String validEndDe;
	/**
	 * 사용 여부
	 */
	private String useAt;
	/**
	 * 등록 일시
	 */
	private String registDt;
	/**
	 * 등록자 아이디
	 */
	private String registerId;
	/**
	 * 수정 일시
	 */
	private String updtDt;
	/**
	 * 수정자 아이디
	 */
	private String updusrId;
	/**
	 * 상품 명
	 */
	@Size(groups = InsertAndUpdate.class, max = 200, message = "상품명은 최대200자까지 입력가능합니다.")
	@NotEmpty(groups = InsertAndUpdate.class, message = "상품명은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String goodsNm;

	/**
	 * 전시상품명
	 */
	private String dspyGoodsNm;
	/**
	 * 선물 처리 여부
	 */
	private String ftrsProcessAt;
	private String ftrsProcessAtChgYn;
	/**
	 * 판매 여부
	 */
	private String sleAt;
	/**
	 * 판매 단위 코드
	 */
	private String sleUnitCode;
	/**
	 * 판매 단위 중량
	 */
	@PositiveOrZero(groups = InsertAndUpdate.class, message = "판매 단위 중량은 숫자만 입력 가능합니다.")
	@Min(groups = InsertAndUpdate.class, value = 0, message = "판매 단위 중량은 0kg이상 입력 가능합니다.")
	@Max(groups = InsertAndUpdate.class, value = (long) 10000000, message = "판매 단위 중량은 9,999,999.999kg 까지 입력 가능합니다.")
	private java.math.BigDecimal sleUnitWt;
	/**
	 * 계약서 시작 허용 중량 비율
	 */
	@Min(groups = InsertAndUpdate.class, value = 0, message = "계약서 시작 허용 중량 비율은 0%이상 입력 가능합니다.")
	@Max(groups = InsertAndUpdate.class, value = 100, message = "계약서 시작 허용 중량 비율 100% 까지 입력 가능합니다.")
	private int ctrtcBeginPermWtRate;
	/**
	 * 계약서 종료 혀용 중량 비율
	 */
	@Min(groups = InsertAndUpdate.class, value = 0, message = "계약서 종료 혀용 중량 비율 0%이상 입력 가능합니다.")
	@Max(groups = InsertAndUpdate.class, value = 100, message = "계약서 종료 혀용 중량 비율은 100% 까지 입력 가능합니다.")
	private int ctrtcEndPermWtRate;
	/**
	 * BL 판매 최소 중량
	 */
	@Min(groups = InsertAndUpdate.class, value = 0, message = "BL 판매 최소 중량은 0kg이상 입력 가능합니다.")
	@Max(groups = InsertAndUpdate.class, value = (long) 10000000, message = "BL 판매 최소 중량은 9,999,999.999kg 까지 입력 가능합니다.")
	private java.math.BigDecimal blSleMummWt;
	/**
	 * 1회 판매 가능 중량
	 */
	@Min(groups = InsertAndUpdate.class, value = 0, message = "1회 판매 가능 중량은 0kg이상 입력 가능합니다.")
	@Max(groups = InsertAndUpdate.class, value = (long) 10000000, message = "1회 판매 가능 중량은 9,999,999.999kg 까지 입력 가능합니다.")
	private java.math.BigDecimal onceSlePossWt;
	/**
	 * 최대 구매 가능 중량
	 */
	@Min(groups = InsertAndUpdate.class, value = 0, message = "최대 구매 가능 중량은 0kg이상 입력 가능합니다.")
	@Max(groups = InsertAndUpdate.class, value = (long) 10000000, message = "최대 구매 가능 중량은 9,999,999.999kg 까지 입력 가능합니다.")
	private java.math.BigDecimal mxmmPurchsPossWt;

	/**
	 * 중량 변동
	 */
//    @NotNull(groups=InsertAndUpdate.class, message="중량변동금은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private java.math.BigDecimal wtChange;
	
	private int orderWt;
	/**
	 * 등록 여부
	 */
	private String registAt;
	/**
	 * 상품 설명 내용 PC
	 */
	private String goodsDcCnPc;
	/**
	 * 상품 설명 내용 모바일
	 */
	private String goodsDcCnMobile;
	/**
	 * PC 이미지 1 순번
	 */
	private String pcImageOneSn;
	private String pcImageOneNm;
	/**
	 * PC 이미지 2 순번
	 */
	private String pcImageTwoSn;
	private String pcImageTwoNm;
	/**
	 * PC 이미지 3 순번
	 */
	private String pcImageThreeSn;
	private String pcImageThreeNm;
	/**
	 * PC 이미지 4 순번
	 */
	private String pcImageFourSn;
	private String pcImageFourNm;
	/**
	 * PC 이미지 5 순번
	 */
	private String pcImageFiveSn;
	private String pcImageFiveNm;
	/**
	 * 모바일 이미지 1 순번
	 */
	private String mobileImageOneSn;
	private String mobileImageOneNm;
	/**
	 * 모바일 이미지 2 순번
	 */
	private String mobileImageTwoSn;
	private String mobileImageTwoNm;
	/**
	 * 모바일 이미지 3 순번
	 */
	private String mobileImageThreeSn;
	private String mobileImageThreeNm;
	/**
	 * 모바일 이미지 4 순번
	 */
	private String mobileImageFourSn;
	private String mobileImageFourNm;
	/**
	 * 모바일 이미지 5 순번
	 */
	private String mobileImageFiveSn;
	private String mobileImageFiveNm;
	/**
	 * 총 재고 중량
	 */
	private java.math.BigDecimal totInvntryWt;
	/**
	 * 판매 가능 재고 중량
	 */
	private java.math.BigDecimal slePossInvntryWt;

	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;

	/**
	 * 담당자 명
	 */
	@Size(groups = InsertAndUpdate.class, max = 10, message = "담당자명은 최대10자까지 입력가능합니다.")
	@NotEmpty(groups = InsertAndUpdate.class, message = "담당자명은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String chargerNm;
	/**
	 * 담당자 연락처
	 */
	@Size(groups = InsertAndUpdate.class, max = 30, message = "담당자연락처는 최대30자까지 입력가능합니다.")
	@NotEmpty(groups = InsertAndUpdate.class, message = "담당자연락처는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String chargerCttpc;
	/**
	 * 담당자 핸드폰
	 */
	@Size(groups = InsertAndUpdate.class, max = 30, message = "담당자휴대폰번호는 최대30자까지 입력가능합니다.")
	@NotEmpty(groups = InsertAndUpdate.class, message = "담당자휴대폰번호는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String chargerMoblphon;
	/**
	 * 담당자 이메일
	 */
	@Size(groups = InsertAndUpdate.class, max = 300, message = "담당자 이메일은 최대300자까지 입력가능합니다.")
	@NotEmpty(groups = InsertAndUpdate.class, message = "담당자 이메일은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@Pattern(groups = InsertAndUpdate.class, message = "이메일 형식이 아닙니다.", regexp = "[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+")
	private String chargerEmail;
	/**
	 * AS 책임자
	 */
	@Size(groups = InsertAndUpdate.class, max = 10, message = "A/S 책임자는  최대10자까지 입력가능합니다.")
	@NotEmpty(groups = InsertAndUpdate.class, message = "A/S 책임자는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String asRspnber;
	/**
	 * 소비자 상담 전화번호
	 */
	@Size(groups = InsertAndUpdate.class, max = 30, message = "소비자 상담 전화번호는  최대30자까지 입력가능합니다.")
	@NotEmpty(groups = InsertAndUpdate.class, message = "소비자 상담 전화번호는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String cnsmrCnsltTelno;

	/****** 표준SPEC ******/
	/**
	 *
	 */
	private String metalCodeNm;
	/**
	 *
	 */
	private String optnCode;
	/**
	 *
	 */
	private String optnCodeNm;
	/**
	 *
	 */
	private String specOneCode;
	/**
	 *
	 */
	private String specTwoCode;

	/****** 품목분류 ******/

	/**
	 *
	 */
	private String ctgryId;
	/**
	 *
	 */
	private String ctgryCodeLv1;
	/**
	 *
	 */
	private String ctgryCodeLv2;
	/**
	 *
	 */
	private String ctgryCodeLv3;
	/**
	 *
	 */
	private String ctgryCodeLv4;

	private String ctgryNo;
	private int ctgrySn;
	private String regCtgryNo;
	private String delCtgryNo;
	private String delCtgrySn;
	private String ctgryNm;
	private String upperCtgryNo;
	private String ctgryLevel;

	private String ctgryLv1No;
	private String ctgryLv2No;
	private String ctgryLv3No;
	private String ctgryLv1Nm;
	private String ctgryLv2Nm;
	private String ctgryLv3Nm;

	private String pcImageOnePath;
	private String pcImageTwoPath;
	private String pcImageThreePath;
	private String pcImageFourPath;
	private String pcImageFivePath;

	private int pcImageOneSize;
	private int pcImageTwoSize;
	private int pcImageThreeSize;
	private int pcImageFourSize;
	private int pcImageFiveSize;

	private String metalClCode;
	private String avrgpcUseAt;
	/****** 아이템 관리 검색조건 ******/
	private String srhTxt;
	private String srhGubun;
	private String excelYn;
	private String mappingYn;
	private String gubun;
	private String docNo;

	private ArrayList<ItemMgrVO> itemSaveList;
	
	/**
	 * 전지 상품 명 제목(첫줄, 아랫줄)
	 */	
	private String dspyGoodsNmLineH;
	private String dspyGoodsNmLineD;

}
