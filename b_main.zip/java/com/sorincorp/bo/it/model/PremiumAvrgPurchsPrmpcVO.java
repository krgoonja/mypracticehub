package com.sorincorp.bo.it.model;

import lombok.Data;

@Data
public class PremiumAvrgPurchsPrmpcVO {
	private int itmSn;
	
	private java.math.BigDecimal hghnetprcAvrgPurchsPrmpc;
	//private java.math.BigDecimal avrgPurchsPrmpc; 
	private java.math.BigDecimal itmChangeAmount;
	private java.math.BigDecimal trnsprtct;
	private java.math.BigDecimal isecoNtfcPc;
	private java.math.BigDecimal puchasPc;
	
}
