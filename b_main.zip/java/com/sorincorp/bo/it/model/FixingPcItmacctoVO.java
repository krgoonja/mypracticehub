package com.sorincorp.bo.it.model;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Calendar;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Payload;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.PositiveOrZero;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class FixingPcItmacctoVO extends CommonVO {

	/**
	 *
	 */
	private static final long serialVersionUID = -472055831806055443L;

	/**
	 * Search</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface Search {};
	/**
	 * InsertAndUpdate</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface InsertAndUpdate {};

	public interface InsertAndUpdateDtl {};

	public interface DeleteDtl {};

	public interface CopyDtl {};

	/**
     * 적용 년월
    */
	@NotEmpty(groups=InsertAndUpdate.class, message = "적용 년월은 필수 입력입니다.")
	@NotEmpty(groups=InsertAndUpdateDtl.class, message = "적용 년월은 필수 입력입니다.")
	@NotEmpty(groups=DeleteDtl.class, message = "적용 년월은 필수 입력입니다.")
	@NotEmpty(groups=InsertAndUpdate.class, message = "적용 년월은 필수 입력입니다.")
	@Pattern(groups=InsertAndUpdate.class, regexp = "^\\d{4}(0[1-9]|1[0-2])$", message = "yyyyMM 형식의 유효한 날짜를 입력하세요.")
	@YearRange(groups=InsertAndUpdate.class, min = 2023, max = 1, message = "적용 년월 범위를 벗어났습니다.")
    private String applcYm;
    /**
     * 권역 대분류 코드
    */
    @NotEmpty(groups=Search.class, message = "권역을 선택해주세요.")
    @NotEmpty(groups=InsertAndUpdateDtl.class, message = "권역은 필수 입력입니다.")
    @NotEmpty(groups=DeleteDtl.class, message = "권역은 필수 입력입니다.")
    private String dstrctLclsfCode;
    /**
     * 아이템 순번
    */
    @NotEmpty(groups = InsertAndUpdate.class,message = "아이템순번은 필수 입력입니다.")
    @NotEmpty(groups = InsertAndUpdateDtl.class,message = "아이템순번은 필수 입력입니다.")
    @NotEmpty(groups = DeleteDtl.class,message = "아이템순번은 필수 입력입니다.")
    @Digits(integer=10, fraction=0, groups=InsertAndUpdate.class, message = "아이템 순번은 숫자 형식이어야 합니다.")
    private String itmSn;

    /**
     * 아이템명
     */
    private String itmPrdlstKorean;
    /**
     * 아이템명
     */
    private String dspyGoodsNm;
    /**
     * 업체 번호
    */
    @NotEmpty(groups=InsertAndUpdateDtl.class, message = "업체번호는 필수 입력입니다.")
    @NotEmpty(groups=DeleteDtl.class, message = "업체번호는 필수 입력입니다.")
    private String entrpsNo;

    /**
     * 업체명
     */
    private String entrpsnmKorean;
    /**
     * 케이지몰 단위 기간 코드
    */
    @NotEmpty(groups=InsertAndUpdate.class, message = "케이지몰 단위 기간 코드는 필수 입력입니다.")
    private String sorinmallUnitPdCode;

    /**
     * 케이지몰 단위 기간코드 명
     */
    private String sorinmallUnitPdCodeNm;
    /**
     * 제한 중량
    */
    private java.math.BigDecimal lmttWt;
    /**
     * 고시 금액
    */
    @PositiveOrZero(groups=InsertAndUpdate.class, message = "당월 고시 금액은 0 또는 양수여야 합니다.")
    @NotEmpty(groups=InsertAndUpdate.class, message = "당월 고시 금액은 필수 입력입니다.")
    private String ntfcAmount;
    /**
     * 전월 고시 금액
     */
    private String bforNtfcAmount;
    /**
     * 변동폭
     */
    @Digits(integer=10, fraction=0, groups=InsertAndUpdate.class, message = "변동폭은 숫자 형식이어야 합니다.")
    private String changeAmount;
    /**
     * 대운송비 금액
    */
    private long lrgetrnsprtctAmount;
    /**
     * 마진 금액
    */
    private long marginAmount;
    /**
     * 판매 가격
    */
    @Min(value=1,groups=InsertAndUpdateDtl.class, message = "판매금액은 필수 입력입니다.")
    private String slePc;
    /**
     * 사용 여부
    */
    @NotEmpty(groups=InsertAndUpdate.class, message = "사용 여부는 필수 입력입니다.")
    @Pattern(groups=InsertAndUpdate.class, regexp = "[YN]", message = "사용여부는 'Y' 또는 'N' 값만 입력 가능합니다.")
    private String useAt;
    /**
     * 등록 업체수
     */
    private String entrpsCnt;
    /**
     * 이전 날짜 여부
     */
    private String pastAt;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록자명
     */
    private String frstRegisterNm;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;


    @NotEmpty(groups=Search.class, message = "년도를 선택해주세요.")
    private String applcYear;

    @NotEmpty(groups=Search.class, message = "월을 선택해주세요.")
    private String applcMonth;


    /**
     * 01 : 아이템명, 02 : 기업명
     */
    private String searchCondition;

    private String searchKeyword;

    // 그리드값
    private ArrayList<FixingPcItmacctoVO> gridList;

    /**
     * 대운송비 sub code
     * 01 : 부산, 02 : 인천
     */
    private String subCode;

    /**
     * 리스트화면에서 선택한 ITM 번호
     */
    private String selectedItmSn;
    
    /**
     * 수정여부
     */
    private String editAt;
    
    /**
     * 등록:C, 수정:U
     */
    private String type;
    
    private static class YearRangeValidator implements ConstraintValidator<YearRange, String> {
    	private int minYear;
        private int maxYear;

        @Override
        public void initialize(YearRange constraintAnnotation) {
            minYear = constraintAnnotation.min();
            maxYear = constraintAnnotation.max();
        }

        @Override
        public boolean isValid(String yyyyMM, ConstraintValidatorContext context) {	        	
        	if(yyyyMM == null || !yyyyMM.matches("^[0-9]{6}$")) {
        		return false;
        	}

            int currentYear = Calendar.getInstance().get(Calendar.YEAR);
            int currentMonth = Calendar.getInstance().get(Calendar.MONTH) + 1;
            int minYyyyMm = Integer.parseInt("" + minYear + String.format("%02d", currentMonth));
            int maxYyyy = currentYear + maxYear;
            int maxYyyyMm =  Integer.parseInt("" + maxYyyy + "12");

            return Integer.parseInt(yyyyMM) >= minYyyyMm && Integer.parseInt(yyyyMM) <= maxYyyyMm;
        }
    }

    // @YearRange 어노테이션
    @Documented
    @Retention(RetentionPolicy.RUNTIME)
    @Target({ElementType.METHOD, ElementType.FIELD})
    @Constraint(validatedBy = YearRangeValidator.class)
    public @interface YearRange {
        String message() default "유효한 연도가 아닙니다.";
        Class<?>[] groups() default {};
        Class<? extends Payload>[] payload() default {};
        int min();
        int max();
    }

}
