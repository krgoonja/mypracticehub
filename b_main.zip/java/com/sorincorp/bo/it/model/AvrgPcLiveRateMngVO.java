package com.sorincorp.bo.it.model;

import java.math.BigDecimal;
import java.util.ArrayList;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PositiveOrZero;
import javax.validation.constraints.Size;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * AvrgPcLiveRateMngVO.java
 * 평균가 라이브 비율 관리 VO 객체
 * 
 * @version
 * @since 2023. 8. 16.
 * @author srec0049
 */
@Data
@EqualsAndHashCode(callSuper = false) 
public class AvrgPcLiveRateMngVO extends CommonVO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1045275739548778686L;

	/**
	 * Search</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface Search {};
	
	/**
	 * 이동 모드 (insert(등록), dtl(상세))
	 */
	private String mvMode;
	
	/**
	 * 총 건수
	 */
	private int totalCnt;
	
	/**
     * 기준 순번
     */
    private String stdrSn;
    
    /**
     * 금속 코드
     */
    @NotEmpty(message = "메탈 미존재")
    private String metalCode;
    
    /**
     * 금속 명
     */
    private String metalNm;
    
    /**
     * 적용 일자
     */
    @NotEmpty(message = "적용일자 미존재")
    private String applcDe;
    
    /**
     * 기준 시작 중량
     */
    @NotNull(message = "시작톤수 미존재")
    @PositiveOrZero(message = "시작톤수 0미만 값 입력 불가")
    private Integer stdrBeginWt;
    
    /**
     * 기준 종료 중량
     */
    @NotNull(message = "종료톤수 미존재")
    @PositiveOrZero(message = "종료톤수 0미만 값 입력 불가")
    private Integer stdrEndWt;
    
    /**
     * 기준 증가 중량
     */
    @NotNull(message = "구간갭 미존재")
    @PositiveOrZero(message = "구간갭 0미만 값 입력 불가")
    private Integer stdrIncrsWt;
    
    /**
     * 1 단계 비율 (다이아몬드)
     */
    @NotNull(message = "1등급 미존재")
    @PositiveOrZero(message = "1등급 0미만 값 입력 불가")
    private BigDecimal oneStepRate;
    
    /**
     * 2 단계 비율 (플래티넘)
     */
    @NotNull(message = "2등급 미존재")
    @PositiveOrZero(message = "2등급 0미만 값 입력 불가")
    private BigDecimal twoStepRate;
    
    /**
     * 3 단계 비율 (골드)
    */
    @NotNull(message = "3등급 미존재")
    @PositiveOrZero(message = "3등급 0미만 값 입력 불가")
    private BigDecimal threeStepRate;
    
    /**
     * 4 단계 비율 (실버)
    */
    @NotNull(message = "4등급 미존재")
    @PositiveOrZero(message = "4등급 0미만 값 입력 불가")
    private BigDecimal fourStepRate;
    
    /**
     * 5 단계 비율 (브론즈)
    */
    @NotNull(message = "5등급 미존재")
    @PositiveOrZero(message = "5등급 0미만 값 입력 불가")
    private BigDecimal fiveStepRate;
    
    /**
	 * 비고
	 */
	@Size(max=4000)
	private String rm;
	
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;

	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;
	
	/**
	 * 평균가 라이브 비율 그리드 리스트
	 */
	@NotEmpty(message = "기준 톤수 목록 미존재")
	private ArrayList<AvrgPcLiveRateDtlVO> gridList;
    
	
	
	
	/**
	 * [평균가 LIVE 등급 관리] 신규 추가소스 제거: 기존 회원등급별혜택 소스를 수정하는 것으로 변경됨에 따른 변수
	 */
	private long gradSn;
	/**
	 * [평균가 LIVE 등급 관리] 신규 추가소스 제거: 기존 회원등급별혜택 소스를 수정하는 것으로 변경됨에 따른 변수
	 */
	private Integer purchsRate;
    /**
     * [평균가 LIVE 등급 관리] 신규 추가소스 제거: 기존 회원등급별혜택 소스를 수정하는 것으로 변경됨에 따른 변수
     */
    private String avrgpcLivePurchsGradCodeNm;
}
