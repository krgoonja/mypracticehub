package com.sorincorp.bo.it.model;

import java.util.List;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * FtrsFshgVO.java
 * @version
 * @since 2022. 5. 27.
 * @author srec0066
 */
/**
 * FtrsFshgVO.java
 * @version
 * @since 2022. 5. 30.
 * @author srec0066
 */
@Data
@EqualsAndHashCode(callSuper=true)
public class FtrsFshgVO extends CommonVO{

	private static final long serialVersionUID = 6882956165304862133L;
	
	/**
	 * Search</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface Search {};
	
	/**
	 * InsertAndUpdate</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface InsertAndUpdate {};
	
	/**
     * 적용 일자
    */
    private String applcDe;
   /**
     * 포지션 코드
    */
    private String postnCode;
   /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 금속 코드명
    */
    private String metalCodeNm;
   /**
     * 선물 스킵 미만 여부
    */
    private String ftrsSkipBeloAt;
   /**
     * 선물 스킵 미만 금액
    */
    private java.math.BigDecimal ftrsSkipBeloAmount;
   /**
     * 선물 스킵 초과 여부
    */
    private String ftrsSkipExcessAt;
   /**
     * 선물 스킵 초과 금액
    */
    private java.math.BigDecimal ftrsSkipExcessAmount;
   /**
     * 선물 틱
    */
    private int ftrsTick;
    
    /**
     * 선물 지정가 틱
     */
    private int ftrsLimitTick;
    
   /**
     * LME 조정 계수 금액
    */
    private java.math.BigDecimal lmeMdatCffcntAmount;
   /**
     * 환율 조정 계수 금액
    */
    private java.math.BigDecimal ehgtMdatCffcntAmount;
   /**
     * 삭제 일시
    */
    private String deleteDt;
   /**
     * 삭제 여부
    */
    private String deleteAt;
   /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
   /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
   /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
   /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    /**
     * 등록/수정할 데이터리스트
    */ 
    private List<FtrsFshgVO> ftrsFshgList;
    /** 
     * Grid 상태 
     */
	private String gridRowStatus;
	/** 
	 * modalPageStatus 상태
	 */
	private String status;
	/** 
	 * 호가 단위
	 */
	private String quotedPriceUnit;
}