package com.sorincorp.bo.it.model;

import lombok.Data;

@Data
public class CommCodeTmpVO {
	/*
	 * 아이템 순번
	 * */
	String itmSn;
	/*
	 * 선물처리여부
	 * */
    String ftrsProcessAt;
    /*
     * 카테고리 코드
     * */
	String parKey;
	/*
	 * 아이템 코드
	 * */
	String subKey;
	/*
	 * 아이템 품목 한글명
	 * */
	String value;
}