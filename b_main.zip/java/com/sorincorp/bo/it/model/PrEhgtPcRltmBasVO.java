package com.sorincorp.bo.it.model;

import lombok.Data;

@Data
public class PrEhgtPcRltmBasVO {
	/******  JAVA VO CREATE : PR_EHGT_PC_RLTM_BAS(가격_환율 가격 실시간 기본)                                                                ******/
	    /**
	     * 환율 거래 통화 코드
	    */
	    private String ehgtDelngCrncyCode;
	    /**
	     * 발생 일자
	    */
	    private String occrrncDe;
	    /**
	     * 발생 시간
	    */
	    private String occrrncTime;
	    /**
	     * 발생 순번
	    */
	    private String occrrncSn;
	    /**
	     * 환율 가격 실시간 순번
	    */
	    private String ehgtPcRltmSn;
	    /**
	     * 시작 가격
	    */
	    private java.math.BigDecimal beginPc;
	    /**
	     * 종료 가격
	    */
	    private java.math.BigDecimal endPc;
	    /**
	     * 최고 가격
	    */
	    private java.math.BigDecimal topPc;
	    /**
	     * 최저 가격
	    */
	    private java.math.BigDecimal lwetPc;
	    /**
	     * 대비 가격
	    */
	    private java.math.BigDecimal versusPc;
	    /**
	     * 대비 등락 코드
	    */
	    private String versusFlctsCode;
	    /**
	     * 삭제 일시
	    */
	    private java.sql.Timestamp deleteDt;
	    /**
	     * 삭제 여부
	    */
	    private String deleteAt;
	    /**
	     * 최초 등록자 아이디
	    */
	    private String frstRegisterId;
	    /**
	     * 최초 등록 일시
	    */
	    private java.sql.Timestamp frstRegistDt;
	    /**
	     * 최종 변경 일시
	    */
	    private java.sql.Timestamp lastChangeDt;
	    /**
	     * 최종 변경자 아이디
	    */
	    private String lastChangerId;
	 
}
