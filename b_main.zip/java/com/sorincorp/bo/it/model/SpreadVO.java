package com.sorincorp.bo.it.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * TodaySpreadVo.java
 * @version
 * @since 2022. 11. 03.
 * @author jdrttl
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class SpreadVO extends CommonVO {

	/**
	 *
	 */
	private static final long serialVersionUID = -4373441254500033966L;

    /**
     * currentDate
    */
    private String currentDate;

    /**
     * gicName
    */
    private String gicName;

    /**
     * MetalCode
    */
    private String metalCode;

    /**
     * Spread
    */
    private String spread;

    /**
     * tradeDate
     */
    private String tradeDate;
}