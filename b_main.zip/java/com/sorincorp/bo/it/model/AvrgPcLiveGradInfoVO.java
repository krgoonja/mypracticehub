package com.sorincorp.bo.it.model;

import java.math.BigDecimal;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * AvrgPcLiveGradInfoVO.java
 * 평균가 라이브 등급 정보 VO 객체
 * 
 * @version
 * @since 2023. 10. 16.
 * @author srec0049
 */
@Data
@EqualsAndHashCode(callSuper = false) 
public class AvrgPcLiveGradInfoVO extends CommonVO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8219866886187025840L;

	/**
	 * 등급 순서
	 */
	private int gradOrder;
	
	/**
     * 업체 등급 순번
     */
	private int entrpsGradSn;
	
	/**
     * 업체 등급
     */
	private String entrpsGrad;
	
	/**
     * 업체 등급 명
     */
	private String entrpsGradNm;
	
	/**
     * 시행 일자
     */
	private String opertnDe;
	
	/**
     * 금속 코드
     */
	private String metalCode;
	
	/**
	 * 평균가 비율
	 */
	private BigDecimal avrgpcRate;
}
