package com.sorincorp.bo.it.model;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import com.sorincorp.bo.it.model.SalesManagementVO.InsertAndUpdate;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class FixPriceVO extends CommonVO {
	
	private static final long serialVersionUID = 1L;
	
	/******  JAVA VO CREATE : IT_HGHNETPRC_PURCHS_PRMPC_BAS(상품_경쟁사 가격 관리 기본)                                                            ******/
    /**
     * 적용 년월
    */
	@NotBlank(message = "적용 년월를 선택해 주세요.")
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String applcYm;
	/**
     * 적용 년월(변환타입)
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String applcYmNm;
    /**
     * 금속 코드
    */
	@NotBlank(message = "메탈 구분을 선택해 주세요.")
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String metalCode;
    /**
     * 내수 고시 가격
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private Long isecoNtfcPc;
	/**
     * 전달 내수 고시 가격
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private Long befIsecoNtfcPc;
    /**
     * 할인 금액
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private Long dsCntAmt;
    /**
     * 매입 가격
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private Long puchasPc;
	/**
	 * 전일 대비 변동 가격
	 * */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
	private Long bfrtVersusChangePc;
	/**
	 * 비고
	 * */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
	private String rm;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;

    /**
     * 이력순번
    */
    private String histSn;
    /**
     * 아이템순번
    */
    private String itmSn;
    /**
     * 아이템 변동 금액
    */
    private Long itmChangeAmount;
    /**
     * 운송비
    */
    private Long trnsprtct;
    /**
     * 평균 구매 원가
    */
    private String avrgPurchsPrmpc;
    /**
     * 아이템 한글명
    */
    private String itmPrdlstKorean;
    /**
     * 아이템 영문명
    */
    private String itmPrdlstEng;
    /**
     * 할인 금액
    */
    private Long dscntAmount;
    /**
     * 그리드 상태값
    */
    private String gridRowStatus;
    
    private String gridNum;
    
    /**
     * 판매여부
    */
    private String sleAt;
    /**
     * 등록여부
    */
    private String registAt;
    /**
     * 삭제대상
    */
    private String sleRegistAt;
    /**
     * 아이템순번 
     * (선물처리 여부 'N' 의 상품으로 공통코드에서 불러온 아이템 코드로
     * 아이템 변동금 리스트 조회) 
    */
    private List<ItemCodeVO> itmSnList;
    /**
     * 과거구분
    */
    private String pastAt;
    /**
     * 아이템 상품명
    */
    private String dspyGoodsNm;
    
}

