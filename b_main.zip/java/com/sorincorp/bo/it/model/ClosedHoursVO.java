package com.sorincorp.bo.it.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * ClosedHoursVO.java
 * @version
 * @since 2021. 5. 17.
 * @author srec0008
 */
@Data
@EqualsAndHashCode(callSuper=false)
@Validated
public class ClosedHoursVO extends CommonVO {

	private static final long serialVersionUID = 6882956165304862133L;

	/**
	 * Search</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface Search {};
	
	/**
	 * InsertAndUpdate</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface InsertAndUpdate {};
	
	/**
     * 적용 일자
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{sampleVO.id.isEmpty}") // /message/validation.properties 에 등록된 메시지
    private String applcDe;
    /**
     * 적용 시작 시간
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{sampleVO.id.isEmpty}")
	@Positive(groups=InsertAndUpdate.class, message="{it.validaion.num_val_chk}")
    private String applcBeginTime;
    /**
     * 적용 종료 시간
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{sampleVO.id.isEmpty}") // /message/validation.properties 에 등록된 메시지
	@Positive(groups=InsertAndUpdate.class, message="{it.validaion.num_val_chk}")
    private String applcEndTime;
    /**
     * 휴무 유형 코드
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{sampleVO.id.isEmpty}") // /message/validation.properties 에 등록된 메시지
    private String hvofTyCode;
    /**
     * 비고
    */
    private String rm;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;

    /**
     * 상태값
    */
    private String gridRowStatus;

    /**
     * 날짜 검색값1
     */
    private String searchApplcDe1;

    /**
     * 날짜 검색값2
     */
    private String searchApplcDe2;

    /**
     * 구분 검색값
     */
    private String searchHvofTyCode;

	/**
	 * 변경값 리스트
	*/
	private List<ClosedHoursVO> closedHoursList;
}