package com.sorincorp.bo.it.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.bo.it.model.SalesManagementVO.InsertAndUpdate;
import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * EventHolidayVO.java
 * @version
 * @since 2021. 6. 15.
 * @author srec0008
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class EventHolidayVO extends CommonVO {

	private static final long serialVersionUID = 6882956165304862133L;

    /**
     * 이벤트 휴일 순번
    */
    private long eventRestdeSn;
    /**
     * 이벤트 휴일 명칭
    */
    @NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String eventRestdeNm;
    /**
     * 이벤트 휴일 구분 코드
    */
    @NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String eventRestdeSeCode;
    /**
     * 휴일 여부
    */
    @NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String restdeAt;
    /**
     * 노출 여부
     */
    @NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String expsrAt;
    /**
     * 적용 시작 일자
    */
    @NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String applcBeginDe;
    /**
     * 적용 종료 일자
    */
    @NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String applcEndDe;
    
    /**
     * Nation(국가) 코드 
     */
    @NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String nationCode;
    
    /**
     * 비고
    */
    private String rm;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
    /**
     * 이벤트 구문 검색
     */
    private String searchEventRestdeSeCode;
    /**
     * 자동증가 키값
     */
    private int seq;
    /**
     * 수정 가능 유무
     */
    private String changeYN;
    /**
     * 현재 날짜
     */
    private String nowDe;
    
    /**
     * 메인 코드
     */
    private String mainCode;
    
    /**
     * 서브 코드
     */
    private String subCode;
    
    /**
     * 코드 명
     */
    private String codeNm;
    
    /**
     * 코드 참조1
     */
    private String codeRefrnone;
    
    /**
     * 코드 참조2
     */
    private String codeRefrntwo;
    
}