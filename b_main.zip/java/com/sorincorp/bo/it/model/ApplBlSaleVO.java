package com.sorincorp.bo.it.model;

import java.io.Serializable;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class ApplBlSaleVO extends CommonVO implements Serializable {
	
	/**
	 * InsertAndUpdate</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	private static final long serialVersionUID = 4523658766127714789L;
	
	/** 서치 파라미터*/
	private String searchEntprsNm;			//서치업체명
	private String searchBlNo;			//서치BL번호
	private String searchDeleteAt;			//서서치용여부
	
	
	/** 업체 번호 */
	private String status;
		
	/** seq */
	private int seqNo;
	
	/** 업체 번호 */
	private String entrpsNo;

	/** 브랜드 코드 */
	private String brandCode;
	
	/** 삭제 여부 */
	private String deleteAt;
	
	/** 삭제 일시	*/
	private String deleteDt;
	
	/** 최초 등록자 아이디 */
	private String frstRegisterId;
	
	/** 최초 등록 일시	*/
	private String frstRegistDt;
	
	 /** 최종 변경자 아이디	*/
	private String lastChangerId;
	
	/** 최종 변경 일시	*/
	private String lastChangeDt;

	/** BL_NO */
	private String blNo;
	
	/** 판매 상태 코드 */
	private String sleSttusCode;
	
	/** SMS 전송여부 */
	private String smsAt;
	
	/** 업체명 */
	private String entrpsnmKorean;
}