package com.sorincorp.bo.it.model;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Max;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.bo.it.model.ItemMgrVO.InsertAndUpdate;
import com.sorincorp.bo.sample.model.SampleDefaultVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@Validated
public class BrandMgrVO extends SampleDefaultVO {

	private static final long serialVersionUID = -6463049817938341285L;

	public interface Search {};
	public interface InsertAndUpdate {};

	/******  JAVA VO CREATE : IT_BRAND_INFO_BAS(상품_브랜드 정보 기본)                                                                       ******/
	/**
	 * 순번
	 */
	private int seq;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 브랜드 명
    */
    private String brandNm;
    /**
     * 주소
    */
    private String adres;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 금속 코드명
     */
    private String metalCodeNm;

    /**
     * 생산자 명
    */
    private String mkerNm;
    /**
     * 국가 코드
    */
    private String nationCode;
    /**
     * 국가 코드명
     */
    private String nationCodeNm;
    /**
     * 사용 여부
    */
    private String useAt;
    /**
     * 브랜드 소스
    */
    private String brandSourc;
    private String brandSourcNm;
    /**
     * 등록 일시
    */
    private String registDt;
    /**
     * 등록자 아이디
    */
    private String registerId;
    /**
     * 수정 일시
    */
    private String updtDt;
    /**
     * 수정자 아이디
    */
    private String updusrId;
    /**
     * 관세 비율
    */
    @Max(groups=InsertAndUpdate.class, value = 100, message = "관세 비율은 100% 까지 입력 가능합니다.")
    private java.math.BigDecimal cstmsRate;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    private String brandGroupCodeNm;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    /**
     * EC 사영 여부
    */
    private String ecUseAt;
    /**
     * 입찰사용 여부
    */
    private String bidUseAt;

    /******  JAVA VO CREATE : IT_BRAND_STD_SPEC_DTL()                                                                                        ******/
    /**
     *
    */
    private int brandStdSpecDetailSn;
    /**
     *
    */
    private String optnCode;
    /**
     *
    */
    private String specOneCode;
    /**
     *
    */
    private String specTwoCode;
    /**
     * 우선순위
     */
    private String priorRank;

    /**
     *
     */
    private String excelYn;

    private ArrayList<BrandMgrVO> brandSaveList;

    private ArrayList<BrandMgrVO> brandSpecSaveList;

    private String brandGroupCdArr;
    private String brandGroupCdNmArr;


}
