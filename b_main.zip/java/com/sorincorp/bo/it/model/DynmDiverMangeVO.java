package com.sorincorp.bo.it.model;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
@Validated
public class DynmDiverMangeVO extends CommonVO {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	
	public interface InsertAndUpdate {};
	
	private String insertType;
	/**
     * 순번
    */
    private String rowNum;
    /**
     * 프리미엄 아이디
    */
    private String premiumId;
    /**
     * 구매 프리미엄
     */
    private String purchsPremiumDollarAmount;
    /**
     * 판매 프리미엄
     */
    private String premiumPriceUsd;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 아이템 코드
     */
    private String itmCode;

    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;

    /**
     * 원화환산율
     */
    private String korCvtrate;

    /**
     * 실시간 판매 가격 endPc
     */
    private String endPc;

    /**
     * 실시간 판매 가격 발생일자
     */
    private String occrrncDeTime;

    /**
     * 다이버_ON/OFF
     */
    private String diverAt;

    /**
     * 다이버 마진
     */
    private String diverMarginMin;

    /**
     * 다이버 발동 톤수(MT)
     */
    private String diverMotnTon;

    /**
     * 다이버 발동 시간 범위(초)
     */
    private String diverMotnTimeScope;

    /**
     * 다이버 발동 가격 범위 (KRW)
     */
    private int diverScopekrw;

    /**
     * 재고 평균 마진
     */
    private String invntryAvgMargin;

    /**
     * 환율
     */
    private String spex;

    /**
     * 환율 업데이트 시각
     */
    private String updTime;

    /**
     * 다이버 분봉 조정 값
     */
    private String diverMdatVal;


}