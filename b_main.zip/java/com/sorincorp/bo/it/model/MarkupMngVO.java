package com.sorincorp.bo.it.model;

import java.math.BigDecimal;
import java.util.ArrayList;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
@Validatedpublic class MarkupMngVO  extends CommonVO {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	/**
     * 순번
    */
    private String rowNum;
    private String orderNo;
    private String ftrsRequstOrderNo;
    private BigDecimal gainValue;
    private String orderDe;
    private BigDecimal orCashPc;
    private BigDecimal orSpread;
    private BigDecimal orThreemonthEndPc;
    private int orFtrsTick;
    private BigDecimal orRequstUntpc;
    private String requstTime;
    private BigDecimal requstOrderCash;
    private BigDecimal requstSpread;
    private String requstOrderUntpc;
    private String requstThreemonthEndpc; 
    private String rspnsFtrsSttusCode;
    private String cnclsTime;
    private String metalCode;
    private String requstFtrsCmpnySeCode;
    private String requstFtrsCmpnyTrgetCode;
    private String blNo;
    private String sttusCode;
    private BigDecimal rspnsUntpc;
    private int orderQty;
    private String promptDate;
    
    // IT_LME_MARK_UP_INFO_BAS 정보 업데이트 용
    
    private String lmeMarkUpAt;
    private BigDecimal gainTblValue;
    private String frstRegisterId;

}