package com.sorincorp.bo.it.model;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Validated
public class FixvaleWtTotAmtTariffMgrVO extends CommonVO implements Serializable {

	/**
	 * tariffManageDetailSn
	 */
	private static final long serialVersionUID = 1464229441769499779L;
	/**
	 * 적용 일자
	 */
	private String applcDe;
	/**
	 *
	 */
	private String metalCodeNm;
	/**
	 *
	 */
	private String metalCode;
	/**
	 *
	 */
	private String itmPrdlstEng;
	/**
	 * 아이템 순번
	 */
	private int itmSn;
	/**
	 * 요율 관리 상세 순번
	 */
	private int tariffManageDetailSn;
	/**
	 * 중량 할증 시작
	 */
	private int wtTotAmtBegin;
	/**
	 * 중량 할증 종료
	 */
	private int wtTotAmtEnd;
	/**
	 * 할증 요율
	 */
	private double totAmtTariff;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;

	private String[] basDelArr;
	private int[] dtlDelArr;
	private String gubun;
	private String ftrsProcessAt;
	private String itmNm;

}
