package com.sorincorp.bo.it.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * AvrgPcLiveRateDtlVO.java
 * 평균가 라이브 비율 상세 VO 객체
 * 
 * @version
 * @since 2023. 8. 24.
 * @author srec0049
 */
@Data
@EqualsAndHashCode(callSuper = false) 
public class AvrgPcLiveRateDtlVO extends CommonVO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7124951279441259013L;

	/**
	 * Search</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface Search {};
	
	/**
     * 기준 순번
     */
    private String stdrSn;
    
    /**
     * 기준 중량
     */
    private int stdrWt;
    
    /**
     * 1 단계 중량 (다이아몬드)
     */
    private int oneStepWt;
    
    /**
     * 2 단계 중량 (플래티넘)
     */
    private int twoStepWt;
    
    /**
     * 3 단계 중량 (골드)
     */
    private int threeStepWt;
    
    /**
     * 4 단계 중량 (실버)
     */
    private int fourStepWt;
    
    /**
     * 5 단계 중량 (브론즈)
     */
    private int fiveStepWt;
    
    /**
	 * 삭제 여부
	 */
	private String deleteAt;

	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;
}
