package com.sorincorp.bo.it.model;

import java.util.ArrayList;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
@Validatedpublic class PremiumStdrBasVO  extends CommonVO {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	
	public interface InsertAndUpdate {};
	
	private String insertType;
	/**
     * 순번
    */
    private String rowNum;
    /**
     * 프리미엄 아이디
    */
    private String premiumId;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 아이템 코드
     */
    private String itmCode;
    /**
     * 아이템 한글명
    */
    private String itmPrdlstKorean;
    /**
     * 아이템 영문명
    */
    private String itmPrdlstEng;

    /**
     * 판매 방식명
     */
    private String sleMthdNm;
    /**
     * 금속이름
     */
    private String metalNm;
    /**
     * 권역 대분류 이름
     */
    private String premiumStdrDstrctLclsfNm;
    /**
     * 브랜드 코드 이름
     */
    private String premiumStdrBrandGroupNm;
    /**
     * 유효 시작 일시
    */
    private String validBeginDt;
    /**
     * 유효 종료 일시
    */
    private String validEndDt;
    /**
     * 판매 방식 코드
    */
    private String sleMthdCode;
    /**
     * 기준 환율 가격
    */
    @DecimalMin(groups = InsertAndUpdate.class, value = "0", message = "0 이상 입력해주세요.")
    private java.math.BigDecimal stdrEhgtPc;
    /**
     * 프리미엄 기준 금액
    */
    private java.math.BigDecimal premiumStdrAmount;
    @DecimalMin(groups = InsertAndUpdate.class, value = "0", message = "0 이상 입력해주세요.")
    private java.math.BigDecimal premiumStdrAmountKrw;
    private java.math.BigDecimal premiumStdrAmountUsd;

    //그리드 판매 프리미엄 금액
    private java.math.BigDecimal premiumPriceKrw;
    private java.math.BigDecimal premiumPriceUsd;

    /**
     * 기준 아이템 여부
    */
    private String stdrItmAt;
    /**
     * 대표 아이템 여부
     */
    private String rpsItmAt;
    /**
     * 프리미엄 기준 권역 대분류 코드
    */
    private String premiumStdrDstrctLclsfCode;
    /**
     * 프리미엄 기준 브랜드 그룹 코드
    */
    private String premiumStdrBrandGroupCode;
    /**
     *  구매 원가 원화 금액
    */
    private java.math.BigDecimal purchsWonPrmpc;
    /**
     *  구매 원가 달러 금액
    */
    private java.math.BigDecimal purchsDollarPrmpc;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 등록 일자
     */
    private String registDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    /**
     * 권역 변동 금액
    */
    @DecimalMin(groups = InsertAndUpdate.class, value = "0", message = "0 이상 입력해주세요.")
    private java.math.BigDecimal dstrctChangeAmount;

    /**
     * 브랜드 그룹 변동 금액
    */
    @DecimalMin(groups = InsertAndUpdate.class, value = "0", message = "0 이상 입력해주세요.")
    private java.math.BigDecimal brandGroupChangeAmount;

    /**
     * 브랜드 변동 금액
    */
    @DecimalMin(groups = InsertAndUpdate.class, value = "0", message = "0 이상 입력해주세요.")
    private java.math.BigDecimal brandChangeAmount;
    @DecimalMin(groups = InsertAndUpdate.class, value = "0", message = "0 이상 입력해주세요.")
    private java.math.BigDecimal hghnetprcAvrgPurchsPrmpc;

    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    /**
     * 권역 대분류 이름
    */
    private String dstrctLclsfNm;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 그룹 이름
    */
    private String brandGroupNm;

    /**
     * 브랜드 코드
    */
    private String brandCode;

    /**
     * LIVE 고정가 구분
     */
    private String ftrsprocessat;

    /**
     * 프리미엄 번호
    */
    private String premiumNo;
    /**
     * 업체 등급 코드
    */
    private String entrpsGradCode;
    /**
     * 등급 변동 금액
    */
    private long gradChangeAmount;
    /**
     * 판매 가격
    */
    private long slePc;
    /**
     * 평균 이익 금액
    */
    private long avrgProfitAmount;

    private String gradeCode;
    /**
     * 개장시간 타입 ( Y : 개장 전, N : 개장 후 )
    */
    private String dmlType;
    /**
     * 그리드 값
     */
    private ArrayList<PremiumStdrBasVO> gridList;
    /**
     * 검색 기준
     */
    private String dateGubun;
    /**
     * 아이템 전시 상품명
    */
    private String dspyGoodsNm;
    
    /**
     * 현재 프리미엄 아이디
    */
    private String nowPremiumId;
    
    /**
     * 현재 프리미엄 번호
    */
    private String nowPremiumNo;
    
    /**
     * 프리미엄 차액
    */
    private java.math.BigDecimal dfnntPremiumStdrAmount;

}