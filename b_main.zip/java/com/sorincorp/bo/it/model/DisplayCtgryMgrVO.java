package com.sorincorp.bo.it.model;

import java.util.ArrayList;

import javax.validation.constraints.Min;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.bo.sample.model.SampleDefaultVO;
//import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@Validated
public class DisplayCtgryMgrVO extends SampleDefaultVO {

	private static final long serialVersionUID = -3164612684246792933L;

	public interface InsertAndUpdate {};
	public interface Update {};
	public interface Delete {};

	/******  JAVA VO CREATE : IT_ITM_CTGRY_BAS(상품_아이템 카테고리 기본)                                                                    ******/
    /**
     * 카테고리 번호
    */
	@Min(groups=Update.class, value = 0, message = "카테고리번호는 필수 입력입니다.")
	@Min(groups=Delete.class, value = 0, message = "카테고리번호가 유효하지 않습니다.")
    private int ctgryNo;
    /**
     * 상위 카테고리 번호
    */
    private int upperCtgryNo;
    /**
     * 카테고리 레벨
    */
    private String ctgryLevel;
    /**
     * 카테고리 순서
    */
    private int ctgryOrdr;
    /**
     * 카테고리 명
    */
    private String ctgryNm;
    /**
     * 카테고리 사용 여부
    */
    private String ctgryUseAt;
    /**
     * 카테고리 전시 여부
    */
    private String ctgryDspyAt;
    /**
     * 라이브 판매 여부
    */
    private String liveSleAt;
    /**
     * 고정가 판매 여부
    */
    private String hghnetprcSleAt;
    /**
     * 지정가 판매 여부
    */
    private String limitsSleAt;
    /**
     * 평균가 판매 여부
     */
    private String avrgpcSleAt;
    /**
     * 사용 여부
    */
    private String useAt;
    /**
     * 전시 여부
    */
    private String dspyAt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;

    /**
     * 아이템순번
     */
    private int itmSn;

    /**
     * 카테고리순번
     */
    private int ctgrySn;

    /**
     * 아이템순번 배열
     */
    private int[] itmSnArray;

    /**
     * 카테고리 저장 배열
     */
    private ArrayList<DisplayCtgryMgrVO> ctgrySaveList;

    /**
     * 신규카테고리 node 아이디
     */
    private String ctgryNodeId;

    /**
     * 신규카테고리 상위 node 아이디
     */
    private String ctgryUpperNodeId;

    private String metalCode;
    /**
     * 금속분류코드
     */
    private String metalClCode;
    /**
     * 메뉴URL
     */
    private String menuUrl;


}
