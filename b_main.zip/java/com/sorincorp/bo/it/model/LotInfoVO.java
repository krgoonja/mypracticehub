package com.sorincorp.bo.it.model;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@Validated
public class LotInfoVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -8980494251356419094L;

	private String blNo;
	/**
	 *
	 */
	private String entrDe;
	/**
	 *
	 */
	private String shipngDe;
	/**
	 *
	 */
	private String prloadNm;
	/**
	 *
	 */
	private String arvlhangNm;
	/**
	 *
	 */
	private String crncyCode;
	/**
	 *
	 */
	private String metalCode;
	/**
	 *
	 */
	private String metalCodeNm;
	/**
	 *
	 */
	private String itmCode;
	/**
	 *
	 */
	private String wrhousCode;
	/**
	 *
	 */
	private String wrhousNm;
	/**
	 *
	 */
	private String wrhousngDe;
	/**
	 *
	 */
	private String dstrctLclsfCode;
	/**
	 *
	 */
	private String dstrctLclsfCodeNm;
	/**
	 *
	 */
	private String brandCode;
	/**
	 *
	 */
	private String brandNm;
	/**
	 *
	 */
	private double netWt;
	/**
	 *
	 */
	private double grossWt;
	/**
	 *
	 */
	private int bundleQy;
    /**
     *
     */
    private int sleSetupBundleCo;
    /**
     *
     */
    private double sleSetupWt;
    /**
     *
     */
    private double ecSleComptInvntry;
    /**
     *
     */
    private int ecSleComptBundleInvntry;
    /**
     *
     */
    private double sleInvntryUnsleBnt;
    /**
     *
     */
    private int sleInvntryUnsleBundleBnt;
    /**
     *
     */
    private double wrhousSleUnsetupInvntry;
    /**
     *
     */
    private int wrhousSleUnsetupBundleInvntry;

    /**
     *
     */
    private int tariffVal;
    /**
     *
     */
    private int freeTime;

    private String lotNo; // "LOT 번호"
    private String orderNo; // "주문번호"
    private String orderDe; // "주문일자"
    private String dlivyDe; // "출고일자"
    private String premiumNo; // "프리미엄 번호"
    private String frstRegistDt; // "프리미엄 설정일자"
    private double purchs; // "프리미엄 비용원가(구매)"
    private double margin; // "프리미엄 비용원가(마진)"
    private double sle; // "프리미엄 비용원가(판매)"
    private String validBeginDt; //  "유효시작기간"
    private String validEndDt; // "유효종료기간"
    private String packngListFileCours;

}
