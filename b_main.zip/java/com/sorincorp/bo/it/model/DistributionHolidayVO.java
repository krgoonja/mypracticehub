package com.sorincorp.bo.it.model;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * DistributionHolidayVO.java
 * @version
 * @since 2021. 6. 10.
 * @author srec0008
 */
/**
 * DistributionHolidayVO.java
 * @version
 * @since 2021. 7. 21.
 * @author srec0008
 */
@Data
@EqualsAndHashCode(callSuper=false)
@Validated
public class DistributionHolidayVO extends CommonVO {

	private static final long serialVersionUID = 6882956165304862133L;

    /**
     * 적용 일자
    */
    private String applcDe;
    /**
     * 창고 코드
    */
    private String wrhousCode;
    /**
     * 권역 명칭
     */
    private String dstrctNm;
    /**
     * 휴일 명칭
    */
    private String restdeNm;
    /**
     * 비고
    */
    private String rm;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    /**
     * 권역 코드
     */
    private String searchTerritoriesCode;
    /**
     * 창고 코드
     */
    private String searchWrhousCode;
    /**
     * 창고명
     */
    private String wrhousNm;
    /**
     * 공통 메인코드명
     */
    private String mainCode;
    /**
     * 권역 대분류 코드
     */
    private String dstrctLclsfCode;
    /**
     * 권역 중분류 코드
     */
    private String dstrctMlsfcCode;
}