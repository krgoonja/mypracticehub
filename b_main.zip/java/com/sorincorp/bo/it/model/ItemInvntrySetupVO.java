package com.sorincorp.bo.it.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Validated
public class ItemInvntrySetupVO extends CommonVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -3108282541999820606L;

	public interface Search {
	};

	public interface InsertAndUpdate {
	};

	/**
	 * 입고일
	 */
	private String wrhousngDe;
	/**
	 * 보관일수
	 */
	private int cstdyDeCo;
	/**
	 * BL번호
	 */
	private String blNo;
	/**
	 * NET중량
	 */
	private double netWt;
	/**
	 * 번들수량
	 */
	private int bundleQy;
	/**
	 * 평균중량
	 */
	private double netAvrgWt;
	/**
	 * 대분류 권역명
	 */
	private String dstrctLclsfCodeNm;
	/**
	 * 중분류 권역명
	 */
	private String dstrctMlsfcCodeNm;
	/**
	 * 창고명
	 */
	private String wrhousNm;
	/**
	 * 창고위치
	 */
	private String wrhousCellLc;
	/**
	 * 판매상태코드
	 */
	private String sleSttusCode;
	/**
	 * 판매상태코드명
	 */
	private String sleSttusCodeNm;
	/**
	 * 브랜드코드
	 */
	private String brandCode;
	/**
	 * 구매프리미엄달러금액
	 */
	private int purchsPremiumDollarAmount;
	/**
	 * 판매프리미엄금액
	 */
	private int slePremiumAmount;
	/**
	 * 마진
	 */
	private int margin;
	/**
	 * 기초재고
	 */
	private double bsisWrhousngInvntry;
	private int bsisWrhousngBundleInvntry;
	/**
	 * 기초재고 악성 불량 재고
	 */
	private double bsisMaliciousBadnInvntry;
	private int bsisMaliciousBadnBundleInvntry;
	/**
	 * 기초재고
	 */
	private double bsisInvntry;
	private int bsisBundleInvntry;
	/**
	 * 판매설정번들수
	 */
	private int sleSetupBundleCo;
	/**
	 * 판매설정중량
	 */
	private double sleSetupWt;
	/**
	 * 미판매잔량
	 */
	private double sleInvntryUnsleBnt;
	private int sleInvntryUnsleBundleBnt;
	/**
	 * 판매완료
	 */
	private double ecSleComptInvntry;
	private int ecSleComptBundleInvntry;
	
	/**
	 * 소량 판매 설정 번들 수
	 */
	private int smlqySleSetupBundleCo;
	/**
	 * 소량 판매 설정 중량
	 */
	private double smlqySleSetupWt;
    /**
     * 소량 EC 판매 완료 재고
     */
    private double smlqyEcSleComptInvntry;
    /**
     * 소량 EC 판매 완료 번들 재고
     */
    private int smlqyEcSleComptBundleInvntry;
    
    /**
     * 소량 판매 재고 미판매 잔량
     */
    private double smlqySleInvntryUnsleBnt;
    /**
     * 소량 판매 재고 미판매 번들 잔량
     */
    private int smlqySleInvntryUnsleBundleBnt;	
	
	/**
	 * 출고/배송완료
	 */
	private double ecDlivyInvntry;
	private int ecDlivyBundleInvntry;
	/**
	 * 미출고/배송잔량
	 */
	private double ecNootgInvntry;
	private int ecNootgBundleInvntry;
	/**
	 * 물류센터 미출고 재고
	 */
	private double wrhousNootgInvntry;
	private int wrhousNootgBundleInvntry;
	/**
	 * 물류센터 판매 미설정 재고
	 */
	private double wrhousSleUnsetupInvntry;
	private int wrhousSleUnsetupBundleInvntry;

	/**
	 * 조정재고
	 */
	private double adjstInvntry;
	private double adjstInvntryBundle;

	/**
	 * EC 할당 완료 재고
	 */
	private double ecAsgnComptInvntry;
	/**
	 * EC 할당 완료 번들 재고
	 */
	private int ecAsgnComptBundleInvntry;
	/**
	 * EC 할당 잔량 재고
	 */
	private double ecAsgnBntInvntry;
	/**
	 * EC 할당 잔량 번들 재고
	 */
	private int ecAsgnBntBundleInvntry;

	/**
	 * 기말재고
	 */
	private double trmendInvntry;
	private double trmendBundleInvntry;

	private String metalCode;
	private String metalCodeNm;
	private String grossWt;
	private String sleSttusEnd;

	private String itmSn;
	private String dstrctLclsfCode;
	private String dstrctMlsfcCode;
	private String brandGroupCode;
	private String wrhousCode;
	private String[] dstrctMlsfcCodeArray;
	private String[] wrhousCellLcCodeArray;

	private ArrayList<ItemInvntrySetupVO> sleSttusCodeList;
	private ArrayList<ItemInvntrySetupVO> sleSetupBundleCoSaveList;
	private String lastChangerId;
	private String blHistEventTyCode;

	private String entrDe;
	private String entrAt;
	private String ftrsProcessAt;

	// BL판매상태변경
	private String blExpiryYn;
	private String ftrsExpiryYn;
	private String fshgExpiryYn;
	private String decimalYn;
	private int fshgManageNoCnt;
	private String fshgManageNo;
	private String ftrsThsexCntrctNo;
	private String tktAmtSameYn;
	private String sleImprtyResn;
	private String ftrsDelngLotOrgQy;
	private String fshgDlryOrgWt;
	private String fshgDelngDollarOrgAmount;
	private String poBlNo;

	private String smsAt;
	private String slePossde;
	private String wrhousngSeCode;
	private String wrhousngSeCodeNm;

	/* 25번들 이하 */
	private String under25;

	/**
	 * 업체명
	 */
	private String entrpsnmKorean;

	/**
	 * 업체코드
	 */
	private String entrpsNo;

	/**
	 * 오프라인 BL NO
	 */
	private String offBlNo;
	/**
	 * 오프라인 주문 일자
	 */
	private String offOrderDe;
	/**
	 * 오프라인 업체코드
	 */
	private String offEntrpsNo;
	/**
	 * 오프라인 업체명
	 */
	private String offEntrpsnmKorean;
	/**
	 * 오프라인 N.W
	 */
	private String offNW;
	/**
	 * 오프라인 번들
	 */
	private String offBD;
	/**
	 * 총 고객 주문 중량
	 */
	private String totCstmrOrderWt;
	
	/**
	 * 오프라인 LME
	 */
	private String offLme;
	/**
	 * 오프라인 환율
	 */
	private String offEhgt;
	/**
	 * 오프라인 단가
	 */
	private String offGoodsUntpc;
	/**
	 * 프리미엄 가격
	 */
	private String offPremiumPc;
	/**
	 * 오프라인 공급가액
	 */
	private String offSplpc;
	/**
	 * 오프라인 부가세
	 */
	private String offVat;
	/**
	 * 오프라인 판매가액
	 */
	private String offSlepc;
	/**
	 * 오프라인 주문번호
	 */
	private String offOrderNo;
	/**
	 * 오프라인 재고 결과 코드
	 */
	private String offResultCode;

	/**
	 * 선물 거래 LOT 수량
	 */
	private int ftrsDelngLotQy;

	/**
	 * 체결수량
	 */
	private int cnclsQy;

	/**
	 * 반대매매 체결 수량
	 */
	private int cnclsQySell;
	
	/**
	 * 예상 체결 수량
	 */
	private int prearngeCnclsQy;
	
	/**
	 * 선물 잔량
	 */
	private int remainQy;

	/**
	 * 선물 만기 일자
	 */
	private String ftrsExprtnDe;
	
	/**
	 * 예상 체결 금액
	 */
	private int prearngeCnclsAmount;
	
	/**
	 * 선물환 잔액
	 */
	private int remainAmount;

	/**
	 * 선물환 만기 일자
	 */
	private String fshgExprtnDe;

	/**
	 * 구매 원화 총액
	 */
	private double purchsWonAmount;

	/**
	 * TOLERANCE
	 */
	private double tolerance;

	/**
	 * 선물사 구분 코드
	 */
	private String ftrsprofsSeCode;
	
	/**
	 * 판매 단위 중량
	 */
	private int sleUnitWt;
	
	/**
	 * 1회 판매 가능 중량
	 */
	private int onceSlePossWt;

	/**
	 * 자투리 할인
	 */
	private int rmndrDscnt;

	/**
	 * 자투리 할인 bl 리스트
	 */
	private ArrayList<ItemInvntrySetupVO> rmndrDscntList;
	
	/**
	 * TOLERANCE 최소 번들(소량구매 판매설정 MAX값)
	 */
	private int toleranceMinBundle;
	
	/**
	 * 선물체결여부
	 */
	private String smlqySleFtrsAt;
	
	/**
	 * 에이전트 아이디
	 */
	private String agentId;
	
	/**
	 * 상품탐색 노출 여부
	 */
	private String itmSearchShowAt;

	/**
	 * 소량판매 미판잔량 손익 USD
	 */
	private String usdPrflos;

	/**
	 * 소량판매 미판잔량 손익 KRW
	 */
	private String krwPrflos;

	/**
	 * 소량판매 미판잔량 LME 보정
	 */
	private String lmeRevisn;

	/**
	 * 소량판매 미판잔량 SPREAD
	 */
	private String spread;

	/**
	 * 소량판매 미판잔량 PREM (판매프리미엄 - 구매프리미엄)
	 */
	private String prem;

	/**
	 * 실시간 환율
	 */
	private String redisEhgtEndPc;

	/**
	 * 실시간 lme cash
	 */
	private Map<String, Object> redisLmeEndPc;

	/**
	 * 메탈코드 리스트
	 */
	private List<String> metalCodeList;

	/**
	 * 실시간 환율
	 */
	private String spotAsk;

	/**
	 * 해당 BL 선물 스프레드
	 */
	private String ftrsSpreadDollarPc;

	/**
	 * PO LME (선물 LME 정보 대체 )
	 */
	private String purchsLmeDollarPc;

	/**
	 * 실시간 LME CASH
	 */
	private String plprbEndPc;

	/**
	 * 실시간 판매 가격
	 */
	private String psprbEndPc;

	/**
	 * 전일자 평가가격 CASH LME
	 */
	private String cashSettle;

	/**
	 * 전일자 평가가격 BL만기일자 LME
	 */
	private String exprtnDeSettle;

	/**
	 * EVALUATION SPREAD (BL만기일자 - CASH)
	 */
	private String evaluationSpread;

	/**
	 *  코드 참조
	 */
	private String codeNumberRefrnone;





	
}
