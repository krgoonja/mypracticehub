package com.sorincorp.bo.it.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotEmpty;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.bo.it.model.BlInfoDtlVO.InsertAndUpdate;
import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Validated
public class BlNoInqireVO extends CommonVO implements Serializable {

	private static final long serialVersionUID = 9217087002507625605L;

	public interface Search {
	};

	public interface UpdateFtrsProfsSeCode {
	};

	/**
	 * BL번호 purchsQuota purchsLmtQy
	 */
	@NotEmpty(groups = UpdateFtrsProfsSeCode.class, message = "BL 번호는 필수 입력입니다.")
	private String blNo;

	/**
	 * 선물사 fcm
	 */
	private String ftrsProfsFcm;

	/**
	 * 선물사 tcode
	 */
	private String ftrsProfsTCode;

	/**
	 * 선물사 company
	 */
	private String ftrsProfsCompany;

	/**
	 * 선물사 ib
	 */
	private String ftrsProfsIb;

	/**
	 * 선물사 name
	 */
	private String ftrsProfsName;

	/**
	 * 선물사 구분 코드
	 */
	@NotEmpty(groups = UpdateFtrsProfsSeCode.class, message = "선물사 구분 코드는 필수 입력입니다.")
	private String ftrsprofsSeCode;

	/**
	 * 선착항명
	 */
	private String prloadNm;
	/**
	 * 도착항명
	 */
	private String arvlhangNm;
	/**
	 * 입고일자
	 */
	private String entrDe;
	/**
	 * 선적일자
	 */
	private String shipngDe;
	/**
	 * 구매라인번호
	 */
	private String purchsLineNo;
	/**
	 * 구매주문번호
	 */
	private String purchsOrderNo;
	/**
	 * 메탈코드
	 */
	private String metalCode;
	/**
	 * 메탈코드명
	 */
	private String metalCodeNm;
	/**
	 * 아이템코드
	 */
	private String itmCode;
	/**
	 * 물류센터코드
	 */
	private String wrhousCode;
	/**
	 * 창고 cell 위치
	 */
	private String wrhousCellLc;
	/**
	 * 물류센터명
	 */
	private String wrhousNm;
	/**
	 * 입고일자
	 */
	private String wrhousngDe;
	/**
	 * 보관일수
	 */
	private String keepDe;
	/**
	 * 권역 대분류 코드
	 */
	private String dstrctLclsfCode;
	/**
	 * 권역 중분류 코드
	 */
	private String dstrctMlsfcCode;
	/**
	 * 권역명
	 */
	private String dstrctLclsfCodeNm;
	/**
	 * 브랜드코드
	 */
	private String brandCode;
	/**
	 * 브랜드이름
	 */
	private String brandNm;
	/**
	 * 브랜드이름
	 */
	private String exBrandNm;
	/**
	 * 제품 명
	 */
	private String dspyGoodsNm;
	/**
	 * net중량
	 */
	private double netWt;
	/**
	 * gross중량
	 */
	private double grossWt;
	/**
	 * 번들수량
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "번들 수량 필수 입력입니다.")
	private String bundleQy;
	/**
	 * 판매설정번들
	 */
	private int sleSetupBundleCo;
	/**
	 * 판매설정중량
	 */
	private double sleSetupWt;
	/**
	 * ec판매완료재고중량
	 */
	private double ecSleComptInvntry;
	/**
	 * ec판매완료번들재고
	 */
	private int ecSleComptBundleInvntry;
	/**
	 * 미판매재고중량
	 */
	private double sleInvntryUnsleBnt;
	/**
	 * 미판매재고번들수
	 */
	private int sleInvntryUnsleBundleBnt;
	/**
	 * 물류창고 판매설정 재고중량
	 */
	private double wrhousSleUnsetupInvntry;
	/**
	 * 물류창고 판매설정 번들
	 */
	private int wrhousSleUnsetupBundleInvntry;

	/**
	 * 구매사업자
	 */
	private String purchsBsnm;
	/**
	 * 구매무역조건
	 */
	private String purchsCmmrcCnd;
	/**
	 * 구매위치명
	 */
	private String purchsLcNm;
	/**
	 * 구매수량
	 */
	private double purchsQy;
	/**
	 * 구매LME달러가격
	 */
	private double purchsLmeDollarPc;
	/**
	 * 구매 프리미엄 달러 금액
	 */
	private double purchsPremiumDollarAmount;
	/**
	 * 구매 단위 달러 가격
	 */
	private double purchsUnitDollarPc;
	/**
	 * 구매 달러 총액
	 */
	private double purchsDollarAmount;
	/**
	 * 구매 원화 총액
	 */
	private double purchsWonAmount;

	/**
	 * 성적서 pdf파일 경로
	 */
	private String screofeFileCours;

	/**
	 * 패킹리스트 pdf파일 경로
	 */
	private String packngListFileCours;

	/**
	 * BL pdf파일 경로
	 */
	private String blFileCours;

	/**
	 * 선물 계약 번호
	 */
	private String ftrsCntrctNo;
	/**
	 * 선물 삼성 계약 번호
	 */
	private String ftrsThsexCntrctNo;
	/**
	 * 선물 거래 일시
	 */
	private String ftrsDelngDt;
	/**
	 * 선물 거래 LOT 수량
	 */
	private int ftrsDelngLotQy;
	/**
	 * 선물 거래 옵션
	 */
	private String ftrsDelngOptn;
	/**
	 * 선물 거래 시작 일자
	 */
	private String ftrsDelngBeginDe;
	/**
	 * 선물 거래 종료 일자
	 */
	private String ftrsDelngEndDe;
	/**
	 * 선물 종료 달러 가격
	 */
	private double ftrsLmeDollarPc;
	/**
	 * 선물 스프레드 달러 가격
	 */
	private double ftrsSpreadDollarPc;
	/**
	 * 선물 종료 달러 가격
	 */
	private double ftrsEndDollarPc;
	/**
	 * 선물 달러 수수료
	 */
	private double ftrsDollarFee;
	/**
	 * 선물 만기 일자
	 */
	private String ftrsExprtnDe;

	/**
	 * 선물환 계약 번호
	 */
	private String fshgCntrctNo;
	/**
	 * 선물환 거래 일시
	 */
	private String fshgDelngDt;
	/**
	 * 선물환 배부 중량
	 */
	private double fshgDlryWt;
	private int fshgDlryWt2;
	/**
	 * 선물환 거래 통화
	 */
	private String fshgDelngCrncy;
	/**
	 * 선물환 거래 달러 금액
	 */
	private String fshgDelngDollarAmount;
	/**
	 * 선물환 원화 환율
	 */
	private double fshgWonEhgt;
	/**
	 * 선물환 원화 스프레드
	 */
	private double fshgWonSpread;
	/**
	 * 선물환 종료 원화 가격
	 */
	private double fshgEndWonPc;
	/**
	 * 선물환 매수 원화 가격
	 */
	private double fshgPrchasWonPc;
	/**
	 * 선물환 만기 일자
	 */
	private String fshgExprtnDe;

	/**
	 * 아이템순번
	 */
	private int itmSn;
	/**
	 * 브랜드그룹코드
	 */
	private String brandGroupCode;
	/**
	 * 브랜드그룹코드
	 */
	private String brandGroupCodeNm;
	/**
	 * 요율 값
	 */
	private int tariffVal;
	/**
	 * 물류 터미널 사용 원화 비용
	 */
	private int lgistTrminlUseWonCt;
	/**
	 * 물류 해상 운송 원화 비용
	 */
	private int lgistSeaTrnsprtWonCt;
	/**
	 * 물류 내륙 운송 원화 비용
	 */
	private int lgistLandTrnsprtWonCt;
	/**
	 * 물류 하역 원화 비용
	 */
	private int lgistLnlWonCt;
	/**
	 * 물류 보관 원화 비용
	 */
	private int lgistCstdyWonCt;
	/**
	 * 물류 기타 원화 비용
	 */
	private int lgistEtcWonCt;
	/**
	 * 물류 합계 원화 비용
	 */
	private int lgistSmWonCt;
	/**
	 * 통관 관세 원화 비용
	 */
	private int entrCstmsWonCt;
	/**
	 * 통관 수수료 원화 비용
	 */
	private int entrFeeWonCt;
	/**
	 * 금융 이자 원화 비용
	 */
	private int fnncIntrWonCt;
	/**
	 * 금융 기타 원화 비용
	 */
	private int fnncEtcWonCt;
	/**
	 * 비용 합계 원화 비용
	 */
	private int ctSmWonCt;

	/**
	 * 통화코드
	 */
	private String crncyCode;

	/**
	 * QUOTA
	 */
	private String purchsQuota;

	/**
	 * 프리 타임
	 */
	private int freeTime;

	/**
	 * 선물 라인 번호
	 */
	private String ftrsLineNo;

	/**
	 * LOT 수량
	 */
	private int lotQy;
	private String chgYn;
	
	/**
	 * 고객사 주문번호
	 */
	private String fshgManageNo;

	/**
	 * 체결수량_LIVE_BUY
	 */
	private int cnclsQy;
	/**
	 * 체결수량_평균가
	 */
	private int avrgPcCnclsQy;
	/**
	 * 체결수량_SELL
	 */
	private int cnclsQySell;
	/**
	 * 예상 체결 수량
	 */
	private int prearngeCnclsQy;
	/**
	 * 잔량
	 */
	private int remainQy;

	/**
	 * 체결금액_LIVE_BUY
	 */
	private int rspnsCnclsAmount;
	/**
	 * 체결금액_평균가
	 */
	private int avrgPcCnclsAmount;
	/**
	 * 체결금액_SELL
	 */
	private int rspnsCnclsAmountSell;
	/**
	 * 예상 체결 금액
	 */
	private int prearngeCnclsAmount;
	/**
	 * 잔액
	 */
	private int remainAmount;

	// 2022-08-30 항목 추가
	// start----------------------------------------------------------

	/**
	 * 선물 최초 수량
	 */
	private String ftrsDelngLotOrgQy;

	/**
	 * 선물환 최초 중량
	 */
	private String fshgDlryOrgWt;

	/**
	 * 선물환 최초 체결 금액
	 */
	private String fshgDelngDollarOrgAmount;

	/* 파일 문서 번호 */
	private String docNo;
	/* 업무 구분 코드 */
	private String jobSeCode;
	/* 업로드 파일 Uri */
	private String fileUri;

	// 2022-08-30 항목 추가
	// end-------------------------------------------------------------------------------

	private String entrAt;

	private String sleInvntryUnsleBundleBntChk;
	private String ftrsExprtnDeChk;
	private String fshgExprtnDeChk;
	private String wrhousngPrearngeInvntryAtChk;
	private String ftrsProcessAt;

	private String blNo2;
	private String blNo3;
	private String frstRegisterId;
	private String frstRegistDt;
	private String lastChangerId;
	private String lastChangeDt;
	private int seq;

	// BL판매상태변경
	private String blExpiryYn;
	private String decimalYn;
	private int fshgManageNoCnt;
	private String tktAmtSameYn;
	private String sleSttusCode;
	private String sleImprtyResn;
	private String poBlNo;

	private String scSts;
	private String fileType;

	private String wrhousArvlde;

	private String slePossde;

	private String wrhousngPrearngeInvntryAt;
	private String wrhousngSeCode;

	private int ftrsDelngWt;

	private String modalPageStatus;

	/**
	 * 화물 관리 번호
	 */
	private String frghtManageNo;
	/**
	 * 도착일자
	 */
	private String arvlPrearngeDt;
	/**
	 * 도착일자
	 */
	private String entrDt;

	/**
	 * 도착 예정 일시
	 */
	private String arvlPrearngeTime;
	/**
	 * 입고 일자
	 */
	private String wrhousngDt;

	/**
	 * 비고
	 */
	private String blRmrk;

	private String prductNm;

	/**
	 *
	 */
	private int isecoSleClSn;
	/**
	 * 판매방식코드
	 */
	private String sleMthdCode;
	/**
	 * 금속분류코드
	 */
	private String metalClCode;

	private String hstSrhType;

	private String screofeDoc;
	private String packngDoc;
	private String blDoc;

	private String objId;

	/**
	 * EC 할당 완료 재고
	 */
	private double ecAsgnComptInvntry;
	/**
	 * EC 할당 완료 번들 재고
	 */
	private int ecAsgnComptBundleInvntry;
	/**
	 * 배송요청일 조정 일자
	 */
	private String dlvyRqestdeAdjust;

	private String lclsfDlivyDstrctCode;

	private String mlsfcDlivyDstrctCode;

	private String blGrossWt;
	
	@NotEmpty(groups = InsertAndUpdate.class, message = "BL WT(N.W) 필수 입력입니다.")
	private String blNetWt;

	private String orderId;

	private String orderDetailNo;
	
	private int regstCount;
	
	private String chgBlNo;
	
	private ArrayList<BlNoInqireVO> blInfoSaveList;
	
	private String[] blNoArr;
	
	private String saveTy;
	
	private String agentId;

	private List<Object> blList;
}
