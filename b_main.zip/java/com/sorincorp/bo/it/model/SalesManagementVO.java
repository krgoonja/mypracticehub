package com.sorincorp.bo.it.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * SalesManagementVO.java
 * @version
 * @since 2021. 5. 24.
 * @author srec0008
 */
@Data
@EqualsAndHashCode(callSuper=true)
public class SalesManagementVO extends CommonVO{

	private static final long serialVersionUID = 6882956165304862133L;

	
	/**
	 * Search</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface Search {};
	
	/**
	 * InsertAndUpdate</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface InsertAndUpdate {};
    /**
     * 적용 일자
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String applcDe;
    /**
     * 실시간 영업 여부
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String rltmBsnAt;
    /**
     * 고정가 영업 여부
    */
	@NotEmpty(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String hghnetprcBsnAt;
    /**
     * 실시간 시작 시간
    */
    private String rltmBeginTime;
    /**
     * 실시간 종료 시간
    */
    private String rltmEndTime;
    /**
     * 고정가 시작 시간
    */
    private String hghnetprcBeginTime;
    /**
     * 고정가 종료 시간
    */
    private String hghnetprcEndTime;
    /**
     * 사이트 일요일 영업 여부
    */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String siteSunBsnAt;
    /**
     * 사이트 월요일 영업 여부
    */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String siteMonBsnAt;
    /**
     * 사이트 화요일 영업 여부
    */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String siteTuesBsnAt;
    /**
     * 사이트 수요일 영업 여부
    */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String siteWedBsnAt;
    /**
     * 사이트 목요일 영업 여부
    */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String siteThurBsnAt;
    /**
     * 사이트 금요일 영업 여부
    */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String siteFriBsnAt;
    /**
     * 사이트 토요일 영업 여부
    */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String siteSatBsnAt;
    /**
     * 물류 일요일 영업 여부
    */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String lgistSunBsnAt;
    /**
     * 물류 월요일 영업 여부
    */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String lgistMonBsnAt;
    /**
     * 물류 화요일 영업 여부
    */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String lgistTuesBsnAt;
    /**
     * 물류 수요일 영업 여부
    */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String lgistWedBsnAt;
    /**
     * 물류 목요일 영업 여부
    */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String lgistThurBsnAt;
    /**
     * 물류 금요일 영업 여부
    */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String lgistFriBsnAt;
    /**
     * 물류 토요일 영업 여부
    */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String lgistSatBsnAt;
    /**
     * 선물 수수료 비용 비율
     */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String ftrsFeeCtRate;
    /**
     * 선물 수수료 비용 비율
     */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    @Positive(groups=InsertAndUpdate.class, message="{it.validaion.num_val_chk}")
    private java.math.BigDecimal ftrsFeeCtRateDeciaml;
    /**
     * 이월렛 입금 수수료
     */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String ewalletRcpmnyFee;
    /**
     * 이월렛 입금 수수료
     */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    @Positive(groups=InsertAndUpdate.class, message="{it.validaion.num_val_chk}")
    private long ewalletRcpmnyFeeLong;
    /**
     * 이월렛 출금 수수료
     */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    private String ewalletDefrayFee;
    /**
     * 이월렛 출금 수수료
     */
    @NotNull(groups=InsertAndUpdate.class, message="{it.validaion.required}")
    @Positive(groups=InsertAndUpdate.class, message="{it.validaion.num_val_chk}")
    private long ewalletDefrayFeeLong;

    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
    /**
     * 영업 요일
     */
    private String businessDays;
    /**
     * 물류 영업 요일
     */
    private String logisticsBusinessDays;
    /**
     * 물류 영업 요일 LIST VO 
     *
     */
    private List<SalesDlvyManagementVO> salesDlvyManagementVOList;
    /**
     * 오늘날짜
     */
    private int nowDe;
    /**
     * 삭제 기준일 
     */
    private int deleteDe;
    /**
     * 오픈시간 변경 여부
    */
    private String changeAt;
}