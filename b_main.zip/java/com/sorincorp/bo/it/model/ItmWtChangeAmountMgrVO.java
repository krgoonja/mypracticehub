package com.sorincorp.bo.it.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ItmWtChangeAmountMgrVO extends CommonVO{
	
	
	private static final long serialVersionUID = 8458549233020120384L;
	                                                                                
    /**
     * 중량 변동금 관리 기본 순번
    */
    private int itMetalItmWtChangeSn;
    /**
     * 금속 코드
    */
    private String metalCode;
    
    /**
     * 금속명
     */
    private String metalNm;
    
    /**
     * 아이템명
     */
    private String itmNm;
    
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 주문 톤수
    */
    private int orderWt;
    /**
     * 중량 변동
    */
    private java.math.BigDecimal wtChange;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
 
    /**
     * 모달창 상태
     */
    private String modalPageStatus;
    
    private String excelYn;

	private String gubun;
	
	private int[] itMetalItmWtChangeSnArr;
	
	
}
