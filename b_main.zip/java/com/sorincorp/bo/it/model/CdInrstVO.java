package com.sorincorp.bo.it.model;

import com.sorincorp.comm.model.CommonVO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/****** cd금리 관리 ******/
@Data
@EqualsAndHashCode(callSuper=false)
public class CdInrstVO extends CommonVO{
	
    /**
     * 요청일자
    */
    private String refDate;
    
    /**
     * 만기코드
    */
    private String tenor;
    
    /**
     * 기준통화 코드
    */
    private String currCd;
    
    /**
     * 매수
    */
    private java.math.BigDecimal intRateBuy;
    
    /**
     * 매도
    */
    private java.math.BigDecimal intRateSell;
    
    /**
     * 업데이트 시간
    */
    private String updTime;
    
    /**
	 * 검색 날짜 시작일
	 */
	private String searchDateFrom;

	/**
	 * 검색 날짜 종료일
	 */
	private String searchDateEnd;
 

}
