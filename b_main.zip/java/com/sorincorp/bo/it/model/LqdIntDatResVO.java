package com.sorincorp.bo.it.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class LqdIntDatResVO extends CommonVO {

	private static final long serialVersionUID = 3446893694978696864L;

	private String useMode; // 그리드 또는 그리드엑셀 모드 설정 ( useMode가 엑셀일 경우 excel, 그리드일경우 null)

	/******  JAVA VO CREATE : LQD_INT_DAT_RES(청산 주문 응답)                                                                                ******/
    /**
     * 인터페이스 순번
    */
    private long intrfcSn;
    /**
     * 서비스 명
    */
    private String intId;
    /**
     * 최종 요청 순번
    */
    private int reqSeq;
    /**
     * MSG 유형
    */
    private String msgTp;
    /**
     * 고객사 주문번호
    */
    private String cliOrdNo;
    /**
     * 고객사 원주문번호
    */
    private String cliOrgOrdNo;
    /**
     * 은행  주문 번호
    */
    private String ordNo;
    /**
     * 주문 구분
    */
    private String ordTp;
    /**
     * 상품코드
    */
    private String prodCd;
    /**
     * 거래 통화 코드
    */
    private String pairId;
    /**
     * NEAR 결제일
    */
    private String valDt;
    /**
     * FAR 결제일
    */
    private String matDt;
    /**
     * 거래통화
    */
    private String currCd;
    /**
     * 고객사 딜러 ID
    */
    private String custId;
    /**
     * 매수/매도 구분
    */
    private String bsTp;
    /**
     * 주문 조건
    */
    private String condTp;
    /**
     * 주문 가격
    */
    private String limPx;
    /**
     * 주문 보조 조건
    */
    private String tif;
    /**
     * 주문 금액
    */
    private java.math.BigDecimal ordAmt;
    /**
     * 체결 금액
    */
    private java.math.BigDecimal tktAmt;
    /**
     * 미체결 금액
    */
    private java.math.BigDecimal remAmt;
    /**
     * 접수 상태
    */
    private String acptTp;
    /**
     * TICKET 번호
    */
    private String tktNo;
    /**
     * NEAR 환율
    */
    private java.math.BigDecimal nearRate;
    /**
     * NEAR 금액
    */
    private java.math.BigDecimal nearAmt;
    /**
     * FAR 환율
    */
    private java.math.BigDecimal farRate;
    /**
     * FAR 금액
    */
    private java.math.BigDecimal farAmt;
    /**
     * 응답 MSG
    */
    private String retText;
    /**
     * 응답 전문
    */
    private String rspnsSpclty;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최초 매매 기준 환율
    */
    private java.math.BigDecimal frstTrdeStdrEhgt;
    /**
     * SWAP POINT
    */
    private java.math.BigDecimal swapPoint;

    /**
     * custom
     */
	/** 계약년월 검색 시작 */
	private String registDtFrom;
	/** 계약년월 검색 끝 */
	private String registDtTo;
	/** 회원 ID */
	private String mberId;
	/** 평균가 선물 체결 요청 번호 */
	private String avrgpcFshgRequstNo;
	/** 검색 체결 금액 */
	private String searchTktAmt;
	/** 저장 데이터 여부 */
	private int isSaved = 0;

   /**
     * 조회 주문 시작 일자
    */
	private String stOrderDe;
	
   /**
     * 조회 주문 종료 일자
    */
	private String edOrderDe;
}
