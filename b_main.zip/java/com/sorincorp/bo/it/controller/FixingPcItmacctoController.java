package com.sorincorp.bo.it.controller;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.FixingPcItmacctoVO;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.service.FixingPcItmacctoService;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * FixingPcItmacctoController.java
 * @version
 * @since 2023. 3. 7.
 * @author srec0064
 */
@Slf4j
@Controller
@RequestMapping("/it/fixingPcItmaccto")
public class FixingPcItmacctoController {

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private FixingPcItmacctoService fixingPcItmacctoService;

	@Autowired
	private CustomValidator customValidator;

	@Autowired
	private UserInfoUtil userInfoUtil;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	/**
	 * <pre>
	 * 처리내용: 구매제한/가격관리 화면 호출
	 * </pre>
	 * @date 2023. 3. 3.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 3.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 */
	@RequestMapping("/selectPurchsLmttPcManageList")
	public String selectPurchaseLimitPriceList(ModelMap model, FixingPcItmacctoVO vo) {
		try {
			//권역 분류
			model.addAttribute("dstrctLclsfCodeList", commonCodeService.getFilterCode("DSTRCT_LCLSF_CODE", null, "CODE_REFRNTWO", "Y"));

			//원가관리에서 업체수를 찍고 들어왔을때 사용
			//조회 적용년월
			String applcYm = vo.getApplcYm();
			if (StringUtils.isNotBlank(applcYm)) {
				model.addAttribute("thisYear", applcYm.substring(0, 4));
				model.addAttribute("thisMonth", applcYm.substring(4, 6));
			} else {
				Calendar today = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat("YYYYMM");
				model.addAttribute("thisYear", sdf.format(today.getTime()).substring(0, 4));
				model.addAttribute("thisMonth", sdf.format(today.getTime()).substring(4, 6));
			}
			//조회 ITM SN
			String itmSn = vo.getItmSn();
			model.addAttribute("selectedItmSn", itmSn);

			return "it/purchsLmttPcManageList";
		} catch(Exception e){
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 구매제한/가격관리 데이터 호출
	 * </pre>
	 * @date 2023. 3. 7.
	 * @author srec0081
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 7.			srec0081			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectPurchsLmttPcManageListAjax")
	@ResponseBody
	public ResponseEntity<?> selectPurchsLmttPcManageListAjax(@RequestBody FixingPcItmacctoVO vo, BindingResult bindingResult)
			throws Exception {

		customValidator.validate(vo, bindingResult, FixingPcItmacctoVO.Search.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		List<FixingPcItmacctoVO> list = fixingPcItmacctoService.selectPurchsLmttPcManageList(vo);

		Map<String, Object> map = new HashMap<String, Object>();
		//페이징 처리를 안해서 그냥 size 읽어옴.
		map.put("totalDataCount", list.size());
		map.put("dataList", list);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@RequestMapping("/updatePurchsLmttPcManage")
	@ResponseBody
	public ResponseEntity<Object> updatePurchsLmttPcManage(@RequestBody List<FixingPcItmacctoVO> list, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(list, bindingResult, FixingPcItmacctoVO.InsertAndUpdateDtl.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = 0;
		result = fixingPcItmacctoService.updatePurchsLmttPcManage(list);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/insertAndUpdatePurchsLmttPcManage")
	@ResponseBody
	public ResponseEntity<Object> insertAndUpdatePurchsLmttPcManage(@RequestBody List<FixingPcItmacctoVO> list, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(list, bindingResult, FixingPcItmacctoVO.InsertAndUpdateDtl.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = 0;
		result = fixingPcItmacctoService.insertAndUpdatePurchsLmttPcManage(list);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/deletePurchsLmttPcManage")
	@ResponseBody
	public ResponseEntity<Object> deletePurchsLmttPcManage(@RequestBody FixingPcItmacctoVO vo, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(vo, bindingResult, FixingPcItmacctoVO.DeleteDtl.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = 0;
		result = fixingPcItmacctoService.deletePurchsLmttPcManage(vo);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/copyPreMonthData")
	@ResponseBody
	public ResponseEntity<Object> copyPreMonthData(@RequestBody FixingPcItmacctoVO vo, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(vo, bindingResult, FixingPcItmacctoVO.CopyDtl.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int count = fixingPcItmacctoService.selectPurchsLmttPcCount(vo);

		if (count > 0) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "이미 등록하신 이력이 존재합니다.\n업체등록을 통해 등록해주세요.");
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result = 0;
		result = fixingPcItmacctoService.copyPreMonthData(vo);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "전월 데이터가 존재하지 않거나\n해당월에 설정된 아이템이 존재하지 않습니다.");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 구매 원가 관리 화면 호출
	 * </pre>
	 * @date 2023. 3. 7.
	 * @author srec0064
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 7.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 */
	@RequestMapping("/selectFixingPcItmacctoPrmpc")
	public String selectFixingPcItmacctoPrmpcList(ModelMap model) {
		try {
			Calendar now = Calendar.getInstance();
			int endYear = now.get(Calendar.YEAR) + 1;

			model.addAttribute("endYear", endYear);
			return "it/fixingPcItmacctoPrmpc";
		} catch(Exception e){
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 고정가 구매원가 관리 리스트 조회
	 * </pre>
	 * @date 2023. 3. 7.
	 * @author srec0064
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 7.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param fixingPcItmacctoVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/geFixingPcItmacctoPrmpcList", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> geFixingPcItmacctoPrmpcList(@RequestBody FixingPcItmacctoVO fixingPcItmacctoVO) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		List<FixingPcItmacctoVO> geFixingPcItmacctoPrmpcList = fixingPcItmacctoService.geFixingPcItmacctoPrmpcList(fixingPcItmacctoVO);

		map.put("dataList", geFixingPcItmacctoPrmpcList);
		map.put("totalDataCount", geFixingPcItmacctoPrmpcList.size());
		return map;
	}

	@RequestMapping("/purchsLmttPcRegister")
	public String purchsLmttPcRegister(@RequestBody FixingPcItmacctoVO fixingPcItmacctoVO, ModelMap model) throws Exception {
		try {
			//권역
			String dstrctLclsfCode = fixingPcItmacctoVO.getDstrctLclsfCode();
			String subCode = "01";
			if ("10".equals(dstrctLclsfCode)) {
				//10번 인천
				subCode = "02";

			} else if ("20".equals(dstrctLclsfCode)) {
				//20번 부산
				subCode = "01";
			}

			fixingPcItmacctoVO.setSubCode(subCode);

			List<FixingPcItmacctoVO> itmList = fixingPcItmacctoService.selectItFixingPcItmacctoPrmpcBasList(fixingPcItmacctoVO);

			model.addAttribute("paramInfo", fixingPcItmacctoVO);
			model.addAttribute("itmList", itmList);

			return "it/purchsLmttPcRegister.modal";
		} catch(Exception e){
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectPurchsLmttPcManageDetailList")
	@ResponseBody
	public ResponseEntity<?> selectPurchsLmttPcManageDetailList(@RequestBody FixingPcItmacctoVO vo, BindingResult bindingResult)
			throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		customValidator.validate(vo, bindingResult, FixingPcItmacctoVO.Search.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		//아이템을 선택하지 않은경우 빈값으로 넘김.
		if (StringUtils.isBlank(vo.getItmSn())) {
			map.put("totalDataCount", 0);
			map.put("dataList", null);
		} else {
			List<FixingPcItmacctoVO> list = fixingPcItmacctoService.selectPurchsLmttPcManageList(vo);
			//아이템을 선택했으나 데이터가 없는경우. 원가 BASE 테이블 조회해서 뿌려줌.
			if (CollectionUtils.isEmpty(list)) {
				//권역
				String dstrctLclsfCode = vo.getDstrctLclsfCode();
				String subCode = "01";
				if ("10".equals(dstrctLclsfCode)) {
					//10번 인천
					subCode = "02";
				} else if ("20".equals(dstrctLclsfCode)) {
					//20번 부산
					subCode = "01";
				}
				vo.setSubCode(subCode);
				list = fixingPcItmacctoService.selectItFixingPcItmacctoPrmpcBasList(vo);
				map.put("totalDataCount", list.size());
				map.put("dataList", list);
			} else {
				//페이징 처리를 안해서 그냥 size 읽어옴.
				map.put("totalDataCount", list.size());
				map.put("dataList", list);
			}
		}

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 고정가 구매원가 관리 수정
	 * </pre>
	 * @date 2023. 3. 9.
	 * @author srec0064
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 9.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param fixingPcItmacctoVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/updateFixingPcItmacctoPrmpcAjax", method = { RequestMethod.POST })
	@ResponseBody
	public ResponseEntity<?> updateFixingPcItmacctoPrmpcAjax(@RequestBody FixingPcItmacctoVO fixingPcItmacctoVO, BindingResult bindingResult) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();

		//밸리데이션 체크
		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		for(FixingPcItmacctoVO vo : fixingPcItmacctoVO.getGridList()) {
			customValidator.validate(vo, bindingResult, FixingPcItmacctoVO.InsertAndUpdate.class);
			if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
				return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
			}
		}

		fixingPcItmacctoService.updateFixingPcItmacctoPrmpcAjax(fixingPcItmacctoVO);
		fixingPcItmacctoService.updatePurchsLmttPcByPrmPc(fixingPcItmacctoVO.getGridList());

		retVal.put(RESULT, SUCCESS);
		retVal.put(ERRMSG, "");
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
}
