package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.it.model.LmeHolidayVO;
import com.sorincorp.bo.it.service.LmeHolidayService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;


/**
 * LmeHolidayController.java
 * @version
 * @since 2021. 5. 10.
 * @author srec0008
 */
@Slf4j
@Controller
@RequestMapping("/it/lmeHoliday")
public class LmeHolidayController {

	@Autowired
	private LmeHolidayService lmeHolidayService;

	/**
	 * <pre>
	 * LME 휴일 페이지 이동
	 * </pre>
	 * @date 2021. 5. 10.
	 * @author srec0008
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 10.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param lmeHolidayVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/getLmeHolidayPage")
	public String getLmeHolidayPage2(@ModelAttribute("restdeVO") LmeHolidayVO lmeHolidayVO, ModelMap model){
		try {
			lmeHolidayVO = lmeHolidayService.getLmeCurrentDate(lmeHolidayVO);
			
			model.put("currentDay", lmeHolidayVO.getCurrentDate());
			
			return "it/lmeHolidayListCalendar";
			
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * LME 휴일 리스트 조회
	 * </pre>
	 * @date 2021. 11. 22.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 22.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param lmeHolidayVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/getLmeHolidayList")
	@ResponseBody
	public String getLmeHolidayList(@RequestBody LmeHolidayVO lmeHolidayVO) throws Exception {

		JSONArray resultList = lmeHolidayService.getLmeClndrList(lmeHolidayVO);

		return resultList.toString();
	}

	
}
