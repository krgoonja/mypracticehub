package com.sorincorp.bo.it.controller;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.it.model.SalesDlvyManagementVO;
import com.sorincorp.bo.it.model.SalesManagementVO;
import com.sorincorp.bo.it.service.SalesManagementService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * SalesManagementController.java
 * @version
 * @since 2021. 6. 9.
 * @author srec0008
 */
@Slf4j
@Controller
@RequestMapping("/it/salesManagement")
public class SalesManagementController {

	@Autowired
	private SalesManagementService salesManagementService;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private CustomValidator customValidator;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	/**
	 * <pre>
	 * 영업 관리 페이지로 이동한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author srec0008
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			srec0008			최초작성
	 * 2023. 4. 13.			bok3117				최종수정
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/getListSalesManagementPage")
	public String getListSalesManagementPage(@ModelAttribute("salesManagementVO") SalesManagementVO salesManagementVO, ModelMap model){

		try {

			return "it/salesManagementList";

		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}


	/**
	 * <pre>
	 * 영업관리 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author srec0008
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/getListSalesManagement")
	@ResponseBody
	public Map<String, Object> getListSalesManagement(@RequestBody SalesManagementVO salesManagementVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();

		List<SalesManagementVO> sampleList = salesManagementService.getListSalesManagement(salesManagementVO);
		int totalDataCount = salesManagementService.getListSalesManagementCnt(salesManagementVO);
		returnMap.put("dataList", sampleList);
		returnMap.put("totalDataCount", totalDataCount);
		return returnMap;
	}


	/**
	 * <pre>
	 * 영업 관리를 등록한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author srec0008
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertSalesManagement")
	@ResponseBody
	public ResponseEntity<?> insertSalesManagement(@RequestBody SalesManagementVO salesManagementVO, BindingResult bindingResult) throws Exception {
        Map<String, Object> returnMap = new HashMap<String, Object>();
        salesManagementVO.setFtrsFeeCtRateDeciaml(StringToBigDecimal(salesManagementVO.getFtrsFeeCtRate().replace(",", "")));
        salesManagementVO.setEwalletRcpmnyFeeLong(StringToBigDecimal(salesManagementVO.getEwalletRcpmnyFee().replace(",", "")).longValue());
        salesManagementVO.setEwalletDefrayFeeLong(StringToBigDecimal(salesManagementVO.getEwalletDefrayFee().replace(",", "")).longValue());

        if(!salesManagementVO.isValidation()) { // 유효성 검사 분기 (필요할 경우)
            // validation을 수행한다, validation VO Class의 형식은 VO, List<Vo>, Map<VO> 가능
            // process별로 validation 수행 field 들을 나누고 싶다면 group interface class를 지정하여 사용한다. (VO에도 지정)
            customValidator.validate(salesManagementVO, bindingResult, SalesManagementVO.InsertAndUpdate.class);
        }

        if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
            return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
        }

        if("Y".equals(salesManagementVO.getRltmBsnAt())) {
            if(Integer.parseInt(salesManagementVO.getRltmBeginTime().replace(":", "")) > Integer.parseInt(salesManagementVO.getRltmEndTime().replace(":", ""))) {
                return new ResponseEntity<>("영업 시작시간은 종료시간보다 클 수 없습니다.", HttpStatus.BAD_REQUEST);
            }
        }

        if ("Y".equals(salesManagementVO.getHghnetprcBsnAt())) {
            if(Integer.parseInt(salesManagementVO.getHghnetprcBeginTime().replace(":", "")) > Integer.parseInt(salesManagementVO.getHghnetprcEndTime().replace(":", ""))) {
                return new ResponseEntity<>("영업 시작시간은 종료시간보다 클 수 없습니다.", HttpStatus.BAD_REQUEST);
            }
        }

        for (SalesDlvyManagementVO vo : salesManagementVO.getSalesDlvyManagementVOList()) {
            if(vo.getManatmbDlivyRequstBeginDe() > vo.getManatmbDlivyRequstEndDe()) {
                return new ResponseEntity<>("배송 시작일이 종료일 보다 클 수 없습니다.", HttpStatus.BAD_REQUEST);
            }
            if(vo.getSorinDlivyRequstBeginDe() > vo.getSorinDlivyRequstEndDe()) {
                return new ResponseEntity<>("배송 시작일이 종료일 보다 클 수 없습니다.", HttpStatus.BAD_REQUEST);
            }
        }

		salesManagementService.insertSalesManagement(salesManagementVO);


		return new ResponseEntity<>(returnMap, HttpStatus.OK);
	}


	/**
	 * <pre>
	 * 영업관리를 수정한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author srec0008
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/updateSalesManagement")
	@ResponseBody
	public ResponseEntity<?> updateSalesManagement(@RequestBody SalesManagementVO salesManagementVO, BindingResult bindingResult) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		salesManagementVO.setFtrsFeeCtRateDeciaml(StringToBigDecimal(salesManagementVO.getFtrsFeeCtRate().replace(",", "")));
		salesManagementVO.setEwalletRcpmnyFeeLong(StringToBigDecimal(salesManagementVO.getEwalletRcpmnyFee().replace(",", "")).longValue());
		salesManagementVO.setEwalletDefrayFeeLong(StringToBigDecimal(salesManagementVO.getEwalletDefrayFee().replace(",", "")).longValue());


		if(salesManagementVO.isValidation()) { // 유효성 검사 분기 (필요할 경우)
			// validation을 수행한다, validation VO Class의 형식은 VO, List<Vo>, Map<VO> 가능
			// process별로 validation 수행 field 들을 나누고 싶다면 group interface class를 지정하여 사용한다. (VO에도 지정)
			customValidator.validate(salesManagementVO, bindingResult, SalesManagementVO.Search.class);

			//customValidator.validate(sampleVO, bindingResult);
			//customValidator.validate(sampleVO, bindingResult, SampleVO.Search.class, SampleVO.insertAndUpdate.class);
		}

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		if("Y".equals(salesManagementVO.getRltmBsnAt())) {
			if(Integer.parseInt(salesManagementVO.getRltmBeginTime().replace(":", "")) > Integer.parseInt(salesManagementVO.getRltmEndTime().replace(":", ""))) {
				return new ResponseEntity<>("시작시간은 종료시간보다 클 수 없습니다.", HttpStatus.BAD_REQUEST);
			}
		}

		if ("Y".equals(salesManagementVO.getHghnetprcBsnAt())) {
			if(Integer.parseInt(salesManagementVO.getHghnetprcBeginTime().replace(":", "")) > Integer.parseInt(salesManagementVO.getHghnetprcEndTime().replace(":", ""))) {
				return new ResponseEntity<>("시작시간은 종료시간보다 클 수 없습니다.", HttpStatus.BAD_REQUEST);
			}
		}

		for (SalesDlvyManagementVO vo : salesManagementVO.getSalesDlvyManagementVOList()) {
			if(vo.getManatmbDlivyRequstBeginDe() > vo.getManatmbDlivyRequstEndDe()) {
				return new ResponseEntity<>("시작일이 종료일 보다 클 수 없습니다.", HttpStatus.BAD_REQUEST);
			}
			if(vo.getSorinDlivyRequstBeginDe() > vo.getSorinDlivyRequstEndDe()) {
				return new ResponseEntity<>("시작일이 종료일 보다 클 수 없습니다.", HttpStatus.BAD_REQUEST);
			}
		}

		salesManagementService.updateSalesManagement(salesManagementVO);

		return new ResponseEntity<>(returnMap, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 영업관리를 삭제한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0008
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/deleteSalesManagement")
	@ResponseBody
	public Map<String, Object> deleteSalesManagement(@RequestBody SalesManagementVO salesManagementVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		salesManagementService.deleteSalesManagement(salesManagementVO);

		return returnMap;
	}



	/**
	 * <pre>
	 * 영업관리 등록 모달팝업을 호출한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author srec0008
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/getSalesManagementInsertModal")
	public String popUpModal(@RequestBody SalesManagementVO salesManagementVO, ModelMap model){

		try {
			Map<String, CommonCodeVO> metalCodeList = commonCodeService.getFilterCodeRetVo("METAL_CODE", null, "CODE_DCTWO", "Y");

			List<SalesDlvyManagementVO> resultDlvy = metalCodeList.values().stream().map(commonCodeVO -> {
						SalesDlvyManagementVO salesDlvyManagementVO = new SalesDlvyManagementVO();
						salesDlvyManagementVO.setMetalCode(commonCodeVO.getSubCode());
						salesDlvyManagementVO.setMetalName(commonCodeVO.getCodeChrctrRefrnsix());

						return salesDlvyManagementVO;
			}).collect(Collectors.toList());

			model.put("status", "insert");
			model.put("resultDlvy", resultDlvy);

			//영업시간 판단 여부
			SalesManagementVO manageTimeVO = salesManagementService.selectManagementTime();

			if(Integer.parseInt(DateUtil.getNowDateTime("HHmm")) < Integer.parseInt(manageTimeVO.getRltmBeginTime())) {
				model.put("todayInsert",  "Y");
			} else {
				model.put("todayInsert",  "N");
			}
			// 추가
			List<SalesManagementVO> topDataList = salesManagementService.getTopListSalesManagement(salesManagementVO);
			model.addAttribute("topDataList", topDataList);
			return "it/salesManagementModal.modal";

		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}

	}

	/**
	 * <pre>
	 * 영업관리 수정 모달페이지로 이동한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author srec0008
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/getUpdateSalesManagementModal")
	public String getUpdateSalesManagementFormPage(@RequestBody SalesManagementVO salesManagementVO, ModelMap model){
		try {

			SalesManagementVO resultData = salesManagementService.getSalesManagement(salesManagementVO);
			model.put("status", "update");
			model.put("result", resultData);
			model.put("resultDlvy", resultData.getSalesDlvyManagementVOList());

			// 추가
			List<SalesManagementVO> topDataList = salesManagementService.getTopListSalesManagement(salesManagementVO);
			model.addAttribute("topDataList", topDataList);

			return "it/salesManagementModal";

		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}

	}


	/**
	 * <pre>
	 * String to BigDecimal
	 * </pre>
	 * @date 2021. 8. 9.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 9.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param decimalStr
	 * @return
	 */
	BigDecimal StringToBigDecimal(String decimalStr) {
		BigDecimal decimal = new BigDecimal(decimalStr);

		return decimal;
	}

	/**
	 * <pre>
	 * 시분을 분으로 환산한다
	 * </pre>
	 * @date 2022. 5. 11.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 11.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param time
	 * @return
	 */
	int TimeToMinute(String time) {
		int hour = Integer.parseInt(time.substring(0,2)) * 60;
		int minute = Integer.parseInt(time.substring(2, 4));

		return hour + minute;
	}

	/**
	 * <pre>
	 * 처리내용: 영업일자가 중복으로 등록되어있는지 체크한다
	 * </pre>
	 * @date 2022. 8. 3.
	 * @author srec0064
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 3.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value = "/duplicateCheckAjax")
	@ResponseBody
	public int duplicateCheckAjax(@RequestBody SalesManagementVO salesManagementVO) throws Exception {
		return salesManagementService.getSalesManagementCnt(salesManagementVO);

	}
	
	/**
	 * <pre>
	 * 처리내용: 최신 영업 리스트 가져오기
	 * </pre>
	 * @date 2023. 11. 13.
	 * @auther bok3117
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 11. 13.		bok3117				최초작성
	 * -----------------------------------------------
	 * @param 
	 * @return Object
	 * @throws Exception
	 */
	@PostMapping("/selectTopListSalesManagement")
	@ResponseBody
	public ResponseEntity<Object> selectTopListSalesManagement() throws Exception {
		Map<String,Object> map = new HashMap<>();
		try {
			SalesManagementVO topSalesManagementVO = salesManagementService.selectTopListSalesManagement();
			SalesManagementVO topSalesDlvyManagementVO = salesManagementService.getSalesManagement(topSalesManagementVO);
			
			map.put("resultVO", topSalesManagementVO);
			map.put("resultDlvyVO", topSalesDlvyManagementVO);
			
			return new ResponseEntity<>(map, HttpStatus.OK);
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>("조건에 맞는 영업 리스트가 없습니다.", HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * <pre>
	 * 영업 시간을 수정한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author sumin95
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/updateSalesTime")
	@ResponseBody
	public ResponseEntity<?> updateSalesTime(@RequestBody SalesManagementVO salesManagementVO, BindingResult bindingResult) throws Exception {
	
		Map<String, Object> returnMap = new HashMap<String, Object>();
	
		salesManagementService.updateSalesTime(salesManagementVO);

		return new ResponseEntity<>(returnMap, HttpStatus.OK);
	}
}
