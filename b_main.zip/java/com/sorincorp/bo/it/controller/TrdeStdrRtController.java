package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.bd.model.BdFaqManageVO;
import com.sorincorp.bo.it.model.CdInrstVO;
import com.sorincorp.bo.it.model.TrdeStrdrRtVO;
import com.sorincorp.bo.it.service.TrdeStrdrRtService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/it/trdeStdrRt")
public class TrdeStdrRtController {
	
	@Autowired
	TrdeStrdrRtService trdeStrdrRtService;
	
	/**
	 * <pre>
	 * 처리내용: 매매 기준율 조회목록을 화면으로 보여준다.
	 * </pre>
	 * @date 2022. 9. 16.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 16.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectTrdeStdrList")
	public String selectTrdeStdrList(ModelMap model) throws Exception {
		try {
			//매매 기준율 테이블의 기준 통화 목록을 가져온다.
			Map<String, Object>  mainGubunCodeMap= trdeStrdrRtService.selectCurrCd();
			model.addAttribute("mainGubunCodeMap", mainGubunCodeMap);
			
			return "it/trdeStdrRtList";
		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 매매 기준율 목록을 가져온다.
	 * </pre>
	 * @date 2022. 9. 16.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 16.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param civo
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/selectTrdeStdrRtListData")
	public Map<String,Object> selectTrdeStdrRtListData(@RequestBody TrdeStrdrRtVO civo) throws Exception {
		Map<String,Object> map = new HashMap<String, Object>();
		int totalDataCount        = trdeStrdrRtService.selectCntTrdeStdrRtList(civo);
		List<TrdeStrdrRtVO> dataList = trdeStrdrRtService.selectTrdeStdrRtListData(civo);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", dataList);
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 매매 기준율을 엑셀로 다운한다.
	 * </pre>
	 * @date 2022. 9. 16.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 16.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectTrdeStdrRtListDataForExcel")
	public ResponseEntity<?> selectFaqForExcel(@RequestBody TrdeStrdrRtVO searchVO) throws Exception {
		searchVO.setRecordCountPerPage(10000000);
		List<TrdeStrdrRtVO> dataList = trdeStrdrRtService.selectTrdeStdrRtListData(searchVO);

		Map<String,Object> map = new HashMap<String, Object>();
		map.put("dataList", dataList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	

}
