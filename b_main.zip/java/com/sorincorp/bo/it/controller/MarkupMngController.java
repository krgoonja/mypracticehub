package com.sorincorp.bo.it.controller;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.MarkupMngVO;
import com.sorincorp.bo.it.model.PremiumStdrBasVO;
import com.sorincorp.bo.it.model.SpreadVO;
import com.sorincorp.bo.it.service.MarkupMngService;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.bo.or.model.UnityOrderFtrsVO;
import com.sorincorp.bo.or.service.UnityOrderDetailService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.constants.ExceptionConstants;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * MarkupMngController.java
 *
 * @version
 * @since 2024. 02. 22.
 * @author hanjook
 */
@Slf4j
@Controller
@RequestMapping("/it/markup")
public class MarkupMngController {
	
	@Autowired	
	private MarkupMngService markupMngService;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private ItemCodeService itemCodeService;
	
	@Autowired
	private UnityOrderDetailService unityOrderDetailService;
	
	@Autowired
	private PcInfoService pcInfoService;
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	UserInfoUtil userInfoUtil;
	
	@Autowired
	MessageUtil messageUtil;
	

    private static String RESULT = "result";
    private static String ERRMSG = "errorMsg";
    private static String SUCCESS = "S";
    private static String FAIL = "F";


	/**
	 * <pre>
	 * 처리내용: 마크업 리스트 페이지를 불러온다.
	 * </pre>
	 *
	 * @date 2024. 2. 26.
	 * @author hanjook
	 * @history
	 * ------------------------------------------------
	 * 변경일           작성자        변경내용
	 * ------------------------------------------------
	 * 2024. 2. 26.    hanjook       최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/selectList", method = RequestMethod.GET)
	public String markupList(ModelMap model) {
		try {
			// 아이템 코드
			List<ItemCodeVO> itmSn = itemCodeService.getItemCodeList("");
			Map<String, String> sleMthdCode = commonCodeService.getFilterCode("SLE_MTHD_CODE", "01", null, null); //Live
			Map<String, String> fixMthdCode = commonCodeService.getFilterCode("SLE_MTHD_CODE", "02", null, null); //케이지몰
			sleMthdCode.putAll(fixMthdCode);
			
			model.put("metalCode", commonCodeService.getFilterCode("METAL_CODE",null,"CODE_DCTWO","Y"));  //메탈구분
			model.put("itmSn", itmSn);
			model.put("sleMthdCode", sleMthdCode); // 아이템구분
			model.put("compCnt", markupMngService.selectMarkUpFtrsCompCnt());
			model.put("markupCnt", markupMngService.selectMarkUpFtrsCnt());
			model.put("lmeMarkUpAt", markupMngService.selectMarkupInfo().getLmeMarkUpAt());
			model.put("gainTblValue", markupMngService.selectMarkupInfo().getGainTblValue());
						
			return "it/MarkupMngList";
		} catch(Exception e){
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 마크업 선물 주문 리스트 ajax 를 반환한다.
	 * </pre>
	 *
	 * @date 2024. 2. 26.
	 * @author hanjook
	 * @history
	 * ------------------------------------------------
	 * 변경일                작성자             변경내용
	 * ------------------------------------------------
	 * 2024. 2. 26.         hanjook            최초작성
	 * ------------------------------------------------
	 * @param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/selectMarkupAjaxList", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> selectMarkupAjaxList(@RequestBody PremiumStdrBasVO psbVO) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		List<MarkupMngVO> MarkUpList = markupMngService.selectMarkUpFtrsList();
		int totalCnt = markupMngService.selectMarkUpFtrsCnt();

		map.put("dataList", MarkUpList);
		map.put("totalDataCount", totalCnt);
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 마크업 선물 주문 리스트 ajax 를 반환한다.
	 * </pre>
	 *
	 * @date 2024. 2. 26.
	 * @author hanjook
	 * @history
	 * ------------------------------------------------
	 * 변경일                작성자             변경내용
	 * ------------------------------------------------
	 * 2024. 2. 26.         hanjook            최초작성
	 * ------------------------------------------------
	 * @param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/selectMarkupCompAjaxList", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> selectMarkupCompAjaxList(@RequestBody PremiumStdrBasVO psbVO) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		List<MarkupMngVO> MarkUpList = markupMngService.selectMarkUpFtrsCompList();
		int totalCnt = markupMngService.selectMarkUpFtrsCompCnt();

		map.put("dataList", MarkUpList);
		map.put("totalDataCount", totalCnt);
		return map;
	}
	
	/**
	 *
	 * <pre>
	 * 선물주문 전송 (재처리) 전체
	 * </pre>
	 * @date 2024. 2. 27.
	 * @author hanjook
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 2. 27.			hanjook			최초작성
	 * ------------------------------------------------
	 * @param 	UnityOrderFtrsVO paramVo
	 * @param 	BindingResult bindingResult
	 * @return	ResponseEntity<?>
	 * @throws 	Exception
	 */
	@PostMapping("/ftrsOrderTrnsmisAll")
	public ResponseEntity<?> ftrsOrderTrnsmisAll(@RequestBody UnityOrderFtrsVO paramVo, BindingResult bindingResult) throws Exception {
//		log.debug("ftrsOrderTrnsmis paramVo = " + paramVo.toString());
//		paramVo.setFrstRegisterId(getAccountInfo().getId());
		
		List<MarkupMngVO> MarkUpList = markupMngService.selectMarkUpFtrsList();
		SpreadVO todayVO = new SpreadVO();
		todayVO.setCurrentDate(DateUtil.getNowDate());
		
		//String metalCode, Integer itemSn, String dstrcLclsfCode, String brandGroupCode, String brandCode, String occrrncDe
		PrSelVO priceVO = pcInfoService.getNewestPrSelRltm("7",434,"00","00","0000000000",DateUtil.getNowDate().toString());
		
		Map<String, Object> responseEntity = new HashMap<>();
		// 마크업 선물 주문 당 loop 시작
		if (MarkUpList.size() > 0) {
			
			for (final MarkupMngVO ftrsVO : MarkUpList) {
				// 취소 완료 50 코드 일 때만 선물 재처리 가능.
				if (ftrsVO.getSttusCode().equals("50") || ftrsVO.getSttusCode().equals("60")) {
					// 마크업 주문 당 개별 unitVO 생성
					boolean result = false;
					
					UnityOrderFtrsVO unitVO = new UnityOrderFtrsVO();
					unitVO.setFrstRegisterId(getAccountInfo().getId());
					
					CommonCodeVO gicCode = commonCodeService.getCodeValueRetVo("METAL_CODE", ftrsVO.getMetalCode());
					todayVO.setGicName(gicCode.getCodeRefrnone());
					log.debug("gicName : " + todayVO.getGicName());
					try {
	//					// 재처리 가격 구하기
	//					BigDecimal orCash = ftrsVO.getOrCashPc().setScale(2, BigDecimal.ROUND_HALF_UP);	//원주문 cash
	//					BigDecimal todaySpread = markupMngService.getTodaySpread(todayVO).setScale(2, BigDecimal.ROUND_HALF_UP);
						
						BigDecimal requstOrderUntpc = ftrsVO.getOrCashPc().setScale(2, BigDecimal.ROUND_HALF_UP).subtract(
										markupMngService.getTodaySpread(todayVO).setScale(2, BigDecimal.ROUND_HALF_UP)).subtract(
										ftrsVO.getGainValue());	//두자리수로 바꿔야함!! // 0.5 단위로 주문해야함 // 빼야함... // cash - spread(-) - gain
						String roundOrderUntpc = round(requstOrderUntpc, new BigDecimal(0.5), RoundingMode.HALF_UP).toString();
						// paramVO 값 마크업vo 로 채우기.
						unitVO.setBlNo(ftrsVO.getBlNo());
						unitVO.setFtrsRequstOrderNo(ftrsVO.getFtrsRequstOrderNo());	//선물주문번호
						unitVO.setMetalCode(ftrsVO.getMetalCode());	//메탈코드
						unitVO.setRehndlOrderMthd("appnPc");	//지정가 코드 appnPc
						unitVO.setRehndlAppnPc(roundOrderUntpc);	//재처리 지정가격
						unitVO.setRequstFtrsCmpnyTrgetCode(ftrsVO.getRequstFtrsCmpnyTrgetCode());	//대상 선물사
						unitVO.setRequstFtrsCmpnySeCode(ftrsVO.getRequstFtrsCmpnySeCode());	//대상 선물사 코드
						log.debug("ftrsOrderTrnsmisProcess unitVO = " + unitVO.toString());
						// 선물 주문 인터페이스 작동.
						result = unityOrderDetailService.ftrsOrderTrnsmisProcess(unitVO);
//						result = true;
						
						// 마크업 정보 테이블 업데이트
						unitVO.setSpread3mOnBuy(markupMngService.getTodaySpread(todayVO).setScale(2, BigDecimal.ROUND_HALF_UP));
						unitVO.setLme3m(priceVO.getThreemonthLmePc());
						unitVO.setLmeCash(priceVO.getLmePc());
						
						markupMngService.updateMarkUpTbl(unitVO);
						
						/* 히스토리 insert */
						Map<String, String> keyValues = new HashMap<String, String>();
						keyValues.put("MARK_UP_SN", String.valueOf(unitVO.getMarkUpSn()));
						commonService.insertTableHistory("OR_ORDER_LME_MARK_UP", keyValues);
						
					} catch (Exception e) {
						Map<String, Object> errorResultMap = new HashMap<>();
						errorResultMap.put("responseCode", 400);
						errorResultMap.put("defaultMessage", e.getMessage().replace(e.getClass().getName(), "").replace(": ", ""));
	
						return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.singletonList(errorResultMap));
					}
	
					if (result) {
						responseEntity.put("resultMsg", "선물 주문이 정상적으로 처리되었습니다.");
					} else {
						responseEntity.put("resultMsg", "선물 주문이 처리에 실패하였습니다.");
					}
					
					//2022-06-21 : 재처리 결과에 따른 후처리를 위한 결과 boolean 값 추가
					responseEntity.put("result", result);
				}
			}
		}
		return new ResponseEntity<>(responseEntity, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 마크업 테이블 정보를 업데이트
	 * </pre>
	 * @date 2024. 3. 08.
	 * @author hanjook
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 3. 08.			hanjook			최초작성
	 * ------------------------------------------------
	 * @param MarkupMngVO
	 * @param model
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/updateMarkupInfo")
	@ResponseBody
	public ResponseEntity<Object> updateMarkupInfo(@RequestBody MarkupMngVO markupVO, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if(getAccountInfo().getId() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			markupVO.setFrstRegisterId(userInfoUtil.getUserId());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}
		
		markupVO.setFrstRegisterId(getAccountInfo().getId());

//		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
//			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
//		}
		
		int result = 0;
		
		try {
			//log.debug(brandMgrVO.toString());
			//브랜드관리 update
			result = markupMngService.updateMarkupInfo(markupVO);
	
			 // history
	        List<String> primaryKeyList = new ArrayList<>();
	        primaryKeyList.add("LME_MARK_UP_AT");
	        commonService.insertTableHistory("IT_LME_MARK_UP_INFO_BAS", markupVO, primaryKeyList);
		} catch (Exception e) {
			log.info("[Mark Up Info Err]" + e.getMessage());
		}

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 로그인 정보 조회
	 * </pre>
	 * @date 2022. 1. 12.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 2. 28.			hanjook			ctrl c v
	 * 2022. 1. 12.			srec0051			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	private Account getAccountInfo() throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		if (null == account || StringUtil.isBlank(account.getId())) {
			throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_LOGIN_REQUIRED));
		}
		return account;
	}
	
	public static BigDecimal round(BigDecimal value, BigDecimal increment, RoundingMode roundingMode) {
		if (increment.signum() == 0) {
			return value;
		} else {
			BigDecimal divided = value.divide(increment, 0, roundingMode);
			BigDecimal result = divided.multiply(increment);
			return result;
		}
	}
}
