package com.sorincorp.bo.it.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.model.OnlineSleInvntryManageVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.bo.it.service.OnlineSleInvntryManageService;
import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.brandcode.service.BrandCodeService;
import com.sorincorp.comm.brandgroupcode.service.BrandGroupCodeService;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/it")
public class OnlineSleInvntryManageController {

	@Autowired
	private ItCmnCodeService itCmnCodeService;
	@Autowired
	private ItemCodeService itemCodeService;
	@Autowired
	private BrandGroupCodeService brandGroupCodeService;
	@Autowired
	private BrandCodeService brandCodeService;
	@Autowired
	private OnlineSleInvntryManageService onlineSleInvntryManageService;
	@Autowired
	private CustomValidator customValidator;

	@RequestMapping("/onlineSleInvntryManage")
	public String onlineSleInvntryManage(ModelMap model) {
		try {
			ItCmnCodeVO vo = new ItCmnCodeVO();
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);

			vo.setMainCode("DSTRCT_LCLSF_CODE");
			vo.setCodeDctwo("");
			vo.setUseAt("Y");
			List<ItCmnCodeVO> dstrctLclsfCodeList = itCmnCodeService.selectCmnCodeList(vo);

			vo.setMainCode("DSTRCT_MLSFC_CODE");
			vo.setCodeDctwo("");
			vo.setUseAt("Y");
			List<ItCmnCodeVO> dstrctMlsfcCodeList = itCmnCodeService.selectCmnCodeList(vo);

			model.addAttribute("metalCodeList", metalCodeList);
			model.addAttribute("dstrctLclsfCodeList", dstrctLclsfCodeList);
			model.addAttribute("dstrctMlsfcCodeList", dstrctMlsfcCodeList);

			return "it/onlineSleInvntryManage";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/onlineSleInvntryManageGetCodeList")
	@ResponseBody
	public ResponseEntity<Object> onlineSalesStockMgrGetCodeList(@RequestParam(value = "metalCode") String metalCode, @RequestParam(value = "brandGroupCode") String brandGroupCode,
			@RequestParam(value = "ftrsProcessAt") String ftrsProcessAt) throws Exception {

		String sleMthdCode = "";

		if ("Y".equals(ftrsProcessAt)) {
			sleMthdCode = "01";
		} else if ("N".equals(ftrsProcessAt)) {
			sleMthdCode = "02";
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("itemCodeList", itemCodeService.getItemFtrsProcessAtCodeList(metalCode, ftrsProcessAt));
		map.put("brandGroupCodeList", brandGroupCodeService.getBrandGroupSleMthdCodeList(metalCode, sleMthdCode));

		List<BrandCodeVO> brandTmpList = brandCodeService.getBrandCodeList(brandGroupCode);
		ArrayList<BrandCodeVO> brandList = new ArrayList<BrandCodeVO>();

		if ("".equals(metalCode) || metalCode == null) {
			map.put("brandCodeList", brandTmpList);
		} else {
			for (BrandCodeVO brandCodeVO : brandTmpList) {
				if (brandCodeVO.getMetalCode().equals(metalCode)) {
					brandList.add(brandCodeVO);
				}
			}

			map.put("brandCodeList", brandList);
		}

		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	@RequestMapping("/onlineSleInvntryManageGetCodeAndOthersList")
	@ResponseBody
	public ResponseEntity<Object> onlineSleInvntryManageGetCodeAndOthersList(@RequestParam(value = "metalCode") String metalCode, @RequestParam(value = "brandGroupCode") String brandGroupCode,
			@RequestParam(value = "ftrsProcessAt") String ftrsProcessAt) throws Exception {

		String sleMthdCode = "";

		if ("Y".equals(ftrsProcessAt)) {
			sleMthdCode = "01";
		} else if ("N".equals(ftrsProcessAt)) {
			sleMthdCode = "02";
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("itemCodeList", itemCodeService.getItemFtrsProcessAtCodeList(metalCode, ftrsProcessAt));
		map.put("brandGroupCodeList", brandGroupCodeService.getBrandGroupSleMthdCodeList(metalCode, sleMthdCode));

		
		List<BrandCodeVO> brandTmpList = brandCodeService.getBrandCodeList(brandGroupCode);
		List<BrandCodeVO> brandOthersTmpList = brandCodeService.getBrandOthersCodeList(brandGroupCode);
		
		ArrayList<BrandCodeVO> brandList = new ArrayList<BrandCodeVO>();

		if ("".equals(metalCode) || metalCode == null) {
			for (BrandCodeVO brandCodeVO : brandOthersTmpList) {
				brandTmpList.add(brandCodeVO);
			}
			
			map.put("brandCodeList", brandTmpList);
		} else {
			for (BrandCodeVO brandCodeVO : brandTmpList) {
				if (brandCodeVO.getMetalCode().equals(metalCode)) {
					brandList.add(brandCodeVO);
				}
			}
			
			for (BrandCodeVO brandCodeVO : brandOthersTmpList) {
				if (brandCodeVO.getMetalCode().equals(metalCode)) {
					brandList.add(brandCodeVO);
				}
			}

			map.put("brandCodeList", brandList);
		}

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 23.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param onlineSalesStockMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectLogisticsCenterListAjax")
	@ResponseBody
	public ResponseEntity<Object> selectLogisticsCenterListAjax(@RequestBody OnlineSleInvntryManageVO onlineSleInvntryManageVO, BindingResult bindingResult) throws Exception {

		customValidator.validate(onlineSleInvntryManageVO, bindingResult, OnlineSleInvntryManageVO.Search.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
//			log.error("vaildation error : " + bindingResult.getAllErrors().toString());
//			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		List<OnlineSleInvntryManageVO> logisticsCenterList = onlineSleInvntryManageService.selectLogisticsCenterList(onlineSleInvntryManageVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("logisticsCenterList", logisticsCenterList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 8. 4.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 8. 4.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param onlineSleInvntryManageVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectBlInfoListAjax")
	@ResponseBody
	public ResponseEntity<Object> selectBlInfoListAjax(@RequestBody OnlineSleInvntryManageVO onlineSleInvntryManageVO, BindingResult bindingResult) throws Exception {

		customValidator.validate(onlineSleInvntryManageVO, bindingResult, OnlineSleInvntryManageVO.Search.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
//			log.error("vaildation error : " + bindingResult.getAllErrors().toString());
//			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		// log.debug("==========onlineSleInvntryManageVO.getDstrctLclsfCode()==================="
		// + onlineSleInvntryManageVO.getDstrctLclsfCode());
		List<OnlineSleInvntryManageVO> blInfoBasList = onlineSleInvntryManageService.selectBlInfoBasList(onlineSleInvntryManageVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("blInfoBasList", blInfoBasList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

}
