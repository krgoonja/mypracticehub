package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.co.model.MenuVO;
import com.sorincorp.bo.co.service.MenuService;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.model.ItemInvntrySetupVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.bo.it.service.ItemInvntrySetupService;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.brandcode.service.BrandCodeService;
import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;
import com.sorincorp.comm.brandgroupcode.service.BrandGroupCodeService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.comm.wrhouscode.model.WrhousCodeVO;
import com.sorincorp.comm.wrhouscode.service.WrhousCodeService;

import lombok.extern.slf4j.Slf4j;

/**
 * ItemInvntrySetupController.java
 *
 * @version
 * @since 2021. 7. 29.
 * @author srec0030
 */
@Slf4j
@Controller
@RequestMapping("/bo/it")
public class ItemInvntrySetupController {

	@Autowired
	private ItemInvntrySetupService itemInvntrySetupService;
	@Autowired
	private ItCmnCodeService itCmnCodeService;
	@Autowired
	private ItemCodeService itemCodeService;
	@Autowired
	private BrandGroupCodeService brandGroupCodeService;
	@Autowired
	private BrandCodeService brandCodeService;
	@Autowired
	private WrhousCodeService wrhousCodeService;
	@Autowired
	private MenuService menuService;
	@Autowired
	private CustomValidator customValidator;
	@Autowired
	private UserInfoUtil userInfoUtil;
	@Autowired
	private CommonService commonService;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	@RequestMapping("/selectItemInvntrySetupList")
	public String selectItemInvntrySetupList(ModelMap model, HttpServletRequest request) {
		try {
			Account account = (Account) request.getSession().getAttribute("USER");

			ItCmnCodeVO vo = new ItCmnCodeVO();
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			// 메탈코드 리스트
			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);

			vo.setMainCode("DSTRCT_LCLSF_CODE");
			vo.setCodeDctwo("");
			vo.setUseAt("Y");
			// 권역 대분류 리스트
			List<ItCmnCodeVO> dstrctLclsfCodeList = itCmnCodeService.selectCmnCodeList(vo);

			vo.setMainCode("DSTRCT_MLSFC_CODE");
			vo.setCodeDctwo("");
			vo.setUseAt("Y");
			// 권역 중분류 리스트
			List<ItCmnCodeVO> dstrctMlsfcCodeList = itCmnCodeService.selectCmnCodeList(vo);

			// 판매상태 코드 리스트 조회
			vo.setMainCode("SLE_STTUS_CODE");
			vo.setCodeDctwo("");
			vo.setUseAt("Y");
			// 권역 중분류 리스트
			List<ItCmnCodeVO> goodsSleSttusCodeList = itCmnCodeService.selectCmnCodeList(vo);

			// 아이템 리스트
			List<ItemCodeVO> itemCodeList = itemCodeService.getItemFtrsProcessAtCodeList("", "");
			// 브랜드 그룹코드 리스트
			List<BrandGroupCodeVO> brandGroupCodeList = brandGroupCodeService.getBrandGroupCodeList("");
			// 브랜드코드 리스트
			List<BrandCodeVO> brandCodeList = brandCodeService.getBrandCodeList("");
			// 물류센터 리스트 조회
			List<WrhousCodeVO> wrhousCodeList = wrhousCodeService.getWrhousCode();
//			for(int i=0;i<wrhousCodeList.size();i++) {
//				log.debug("wrhousCodeList ==========>" + wrhousCodeList.get(i).toString());
//			}
			// 물류센터 위치 리스트 조회
			List<ItCmnCodeVO> wrhousCellLcList = itemInvntrySetupService.getWrhousCellLcList("");

			// 입고구분코드 리스트
			vo.setMainCode("WRHOUSNG_SE_CODE");
			vo.setUseAt("Y");
			List<ItCmnCodeVO> wrhousngSeCodeList = itCmnCodeService.selectCmnCodeList(vo);

			model.addAttribute("metalCodeList", metalCodeList);
			model.addAttribute("itemCodeList", itemCodeList);
			model.addAttribute("dstrctLclsfCodeList", dstrctLclsfCodeList);
			model.addAttribute("dstrctMlsfcCodeList", dstrctMlsfcCodeList);

			model.addAttribute("brandGroupCodeList", brandGroupCodeList);
			model.addAttribute("brandCodeList", brandCodeList);
			model.addAttribute("wrhousCodeList", wrhousCodeList);
			model.addAttribute("goodsSleSttusCodeList", goodsSleSttusCodeList);
			model.addAttribute("wrhousCellLcList", wrhousCellLcList);
			model.addAttribute("wrhousngSeCodeList", wrhousngSeCodeList);

			List<MenuVO> menuList = menuService.getSideBarMenu(account.getId()); // 권한 없이 사이드 메뉴 모두 조회
			for (MenuVO menu : menuList) {
				if ("/bo/it/selectBlNoInqireList".equals(menu.getMenuUrl())) {
					model.addAttribute("menuNo", Integer.toString(menu.getMenuNo()));
				}
			}

			model.addAttribute("authorNo", userInfoUtil.getAuthorNo());

			return "it/itemInvntrySetupList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectItemInvntrySetupListAjax")
	@ResponseBody
	public ResponseEntity<Object> selectItemInvntrySetupListAjax(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO, BindingResult bindingResult) throws Exception {

		customValidator.validate(itemInvntrySetupVO, bindingResult, ItemInvntrySetupVO.Search.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
//			log.error("vaildation error : " + bindingResult.getAllErrors().toString());
//			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		List<ItemInvntrySetupVO> itemInvntrySetupList = itemInvntrySetupService.selectItemInvntrySetupList(itemInvntrySetupVO);
		// log.debug(itemInvntrySetupList.toString());
		Map<String, Object> map = new HashMap<>();
		map.put("itemInvntrySetupList", itemInvntrySetupList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@RequestMapping("/selectItemInvntrySetupModal")
	public String selectItemInvntrySetupModal(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO, ModelMap model) throws Exception {
		model.put("offBlNo", itemInvntrySetupVO.getBlNo());
		return "it/itemInvntrySetupModal.modal";
	}
	
	/**
	 * <pre>
	 * 처리내용: 업체 리스트 
	 * </pre>
	 * @date 2023. 01. 13.
	 * @auther jdrttl
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 01. 13.		jdrttl				최초작성
	 * -----------------------------------------------
	 * @param itemInvntrySetupVO
	 * @return Map
	 * @throws Exception
	 */
	@PostMapping("/selectEntrpsList")
	@ResponseBody
	public ResponseEntity<Object> selectEntrpsList(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO) throws Exception {
		Map<String,Object> map = new HashMap<>();
		try {
			List<ItemInvntrySetupVO> entrpsList = itemInvntrySetupService.selectEntrpsList(itemInvntrySetupVO);
			map.put("entrpsList", entrpsList);
			
			return new ResponseEntity<>(map, HttpStatus.OK);
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>("조건에 맞는 브랜드 그룹이 없습니다.", HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 더미오더 생성 
	 * </pre>
	 * @date 2023. 01. 13.
	 * @auther jdrttl
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 01. 13.		jdrttl				최초작성
	 * -----------------------------------------------
	 * @param ItemInvntrySetupVO
	 * @return ItemInvntrySetupVO
	 * @throws Exception
	 */
	@PostMapping("/saveDummyOrder")
	@ResponseBody
	public ResponseEntity<Object> saveDummyOrder(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO) throws Exception {
		Map<String,Object> map = new HashMap<>();
		try {
			ItemInvntrySetupVO returnItemInvntrySetupVO = itemInvntrySetupService.saveDummyOrder(itemInvntrySetupVO);
			map.put("resultVO", returnItemInvntrySetupVO);
			
			return new ResponseEntity<>(map, HttpStatus.OK);
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>("가상오더 생성도중 오류가 발생했습니다. 관리자에게 문의하십시오.", HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 최신 더미오더 생성 내역 가져오기 
	 * </pre>
	 * @date 2023. 01. 16.
	 * @auther jdrttl
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 01. 16.		jdrttl				최초작성
	 * -----------------------------------------------
	 * @param itemInvntrySetupVO
	 * @return Object
	 * @throws Exception
	 */
	@PostMapping("/selectNewestDummyOrder")
	@ResponseBody
	public ResponseEntity<Object> selectNewestDummyOrder(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO) throws Exception {
		Map<String,Object> map = new HashMap<>();
		try {
			ItemInvntrySetupVO returnItemInvntrySetupVO = itemInvntrySetupService.selectNewestDummyOrder(itemInvntrySetupVO);
			map.put("resultVO", returnItemInvntrySetupVO);
			
			return new ResponseEntity<>(map, HttpStatus.OK);
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>("조건에 맞는 브랜드 그룹이 없습니다.", HttpStatus.BAD_REQUEST);
		}
	}
	
	@Transactional
	@RequestMapping("/saveOflneOrder")
	@ResponseBody
	public ResponseEntity<Object> saveOflneOrder(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(itemInvntrySetupVO, bindingResult, ItemInvntrySetupVO.InsertAndUpdate.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = 0;
		int sleImprtyCnt = 0;
		String msg = "";
		//log.info(itemInvntrySetupVO.toString());
		Map<String, Object> resultMap = new HashMap<>();
		//BL 판매상태 수정
		resultMap = itemInvntrySetupService.updateSleSttusCode(itemInvntrySetupVO.getSleSttusCodeList());
		result = (int) resultMap.get("result");
		sleImprtyCnt = (int) resultMap.get("sleImprtyCnt");

		if(sleImprtyCnt > 0) {
			msg = "판매불가 BL건수 : " + Integer.toString(result);
		}

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, msg);
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
	
	@Transactional
	@RequestMapping("/updateSleSttusCode")
	@ResponseBody
	public ResponseEntity<Object> updateSleSttusCode(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(itemInvntrySetupVO, bindingResult, ItemInvntrySetupVO.InsertAndUpdate.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = 0;
		int sleImprtyCnt = 0;
		String msg = "";
		// log.debug(itemInvntrySetupVO.toString());
		Map<String, Object> resultMap = new HashMap<>();
		// BL 판매상태 수정
		resultMap = itemInvntrySetupService.updateSleSttusCode(itemInvntrySetupVO.getSleSttusCodeList());
		result = (int) resultMap.get("result");
		sleImprtyCnt = (int) resultMap.get("sleImprtyCnt");

		if (sleImprtyCnt > 0) {
			msg = "판매불가 BL건수 : " + Integer.toString(result);
		}

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, msg);
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@Transactional
	@RequestMapping("/updateSleSetupBundleCo")
	@ResponseBody
	public ResponseEntity<Object> updateSleSetupBundleCo(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(itemInvntrySetupVO, bindingResult, ItemInvntrySetupVO.InsertAndUpdate.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = 0;
		// log.debug(itemInvntrySetupVO.toString());
		// BL 판매상태 수정
		result = itemInvntrySetupService.updateSleSetupBundleCo(itemInvntrySetupVO.getSleSetupBundleCoSaveList());

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/calcSetupData")
	@ResponseBody
	public ResponseEntity<Object> calcSetupData(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO, Model model, BindingResult bindingResult) throws Exception {

		customValidator.validate(itemInvntrySetupVO, bindingResult, ItemInvntrySetupVO.InsertAndUpdate.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		// log.debug(itemInvntrySetupVO.toString());
		// BL 판매상태 수정
		List<ItemInvntrySetupVO> calcDataList = itemInvntrySetupService.calcSetupData(itemInvntrySetupVO.getSleSetupBundleCoSaveList());

		Map<String, Object> retVal = new HashMap<>();

		retVal.put("calcData", calcDataList);

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/retryBlSleSttusCodeChg")
	@ResponseBody
	public ResponseEntity<Object> blSleSttusCodeChg(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO) throws Exception {
		// 재고설정 blSleSttusCodeChgJob 수동Batch 실행
		log.debug("RetryBlSleSttusCodeChg execute method");

		int result = 0;
		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		try {
			for (ItemInvntrySetupVO vo : itemInvntrySetupVO.getSleSttusCodeList()) {
				commonService.blSleSttusCodeChg(vo.getBlNo(), userInfoUtil.getAccountInfo().getId());
				result = 1;
			}
		} catch (Exception e) {
			log.error("RetryBlSleSttusCodeChg error - " + e.getMessage());
			result = 0;
		}

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

    /**
     * <pre>
     * 처리내용: 자투리재고 리스트
     * </pre>
     * @date 2023. 05. 10.
     * @auther srec0077
     * @history
     * -----------------------------------------------
     * 변경일                  작성자             변경내용
     * -----------------------------------------------
     * 2023. 05. 10.        srec0077              최초작성
     * -----------------------------------------------
     * @param itemInvntrySetupVO
     * @return Map
     * @throws Exception
     */
    @RequestMapping("/selectItemSclptrListAjax")
    @ResponseBody
    public ResponseEntity<Object> selectItemSclptrListAjax(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO, BindingResult bindingResult) throws Exception {

        customValidator.validate(itemInvntrySetupVO, bindingResult, ItemInvntrySetupVO.Search.class);

        if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
   //       log.error("vaildation error : " + bindingResult.getAllErrors().toString());
   //       return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
        }

        List<ItemInvntrySetupVO> selectItemSclptrList = itemInvntrySetupService.selectItemSclptrList(itemInvntrySetupVO);
        Map<String, Object> map = new HashMap<>();
        map.put("selectItemSclptrList", selectItemSclptrList);

        return new ResponseEntity<>(map, HttpStatus.OK);
    }
    
    /**
	 * <pre>
	 * 처리내용: 판매설정 번들수 유효성 검사 [(할당잔량 + 판매완료) 미만 설정 불가 유효성 검사] 후 실패된 BL번호들을 반환한다.
	 * </pre>
	 * @date 2024. 1. 17.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 1. 17.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param itemInvntrySetupVO
	 * @param model
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/chkSleSetupBundleCo")
	@ResponseBody
	public ResponseEntity<Object> chkSleSetupBundleCo(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO, Model model, BindingResult bindingResult) throws Exception {

		customValidator.validate(itemInvntrySetupVO, bindingResult, ItemInvntrySetupVO.InsertAndUpdate.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		// 판매설정 번들수 유효성 검사 [(할당잔량 + 판매완료) 미만 설정 불가 유효성 검사] 후 실패된 BL번호들을 반환한다.
		String chkFailStr = itemInvntrySetupService.chkSleSetupBundleCo(itemInvntrySetupVO.getSleSetupBundleCoSaveList());

		Map<String, String> retVal = new HashMap<>();

		retVal.put("chkFailStr", chkFailStr);

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}


	@RequestMapping("/selectBlList")
	@ResponseBody
	public ResponseEntity<Object> selectBlList(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO, BindingResult bindingResult) throws Exception {
		List<ItemInvntrySetupVO> BlList = itemInvntrySetupService.selectBlList(itemInvntrySetupVO);
		Map<String, Object> map = new HashMap<>();
		map.put("BlList", BlList);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@Transactional
	@RequestMapping("/updateRmndrDscnt")
	@ResponseBody
	public ResponseEntity<Object> updateRmndrDscnt(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(itemInvntrySetupVO, bindingResult, ItemInvntrySetupVO.InsertAndUpdate.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = 0;
		// 자투리 할인 수정
		result = itemInvntrySetupService.updateRmndrDscnt(itemInvntrySetupVO.getRmndrDscntList());

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
}
