package com.sorincorp.bo.it.controller;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.co.service.CmmnCodeService;
import com.sorincorp.bo.it.model.ClosedHoursVO;
import com.sorincorp.bo.it.service.ClosedHoursService;
import com.sorincorp.bo.sample.model.SampleVO;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;


/**
 * ClosedHoursController.java
 * @version
 * @since 2021. 5. 17.
 * @author srec0008
 */
@Slf4j
@Controller
@RequestMapping("/it/closedHours")
public class ClosedHoursController {

	@Autowired
	private ClosedHoursService closedHoursService;

	@Autowired
	private CustomValidator customValidator;
	
	@Autowired
	private CommonCodeService commonCodeService;
	
	/**
	 * <pre>
	 * 휴무일 리스트 페이지 (pageing)
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0008
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 17.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param closedHoursVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/closedHoursPage")
	public String getLmeClndrPage(@ModelAttribute("closedHoursVO") ClosedHoursVO closedHoursVO, ModelMap model){
		try {
			model.put("hvofTyCode", commonCodeService.getSubCodes("HVOF_TY_CODE"));
			
			return "it/closedHoursList";
			
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			
			return "error/503";
		}
	
	}

	
	/**
	 * <pre>
	 * 휴무 시간 관리 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0008
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 17.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param closedHoursVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/getListClosedHours")
	@ResponseBody
	public Map<String, Object> getListClosedHours(@RequestBody ClosedHoursVO closedHoursVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		List<ClosedHoursVO> sampleList = closedHoursService.getClosedHoursList(closedHoursVO);
		int totalDataCount = closedHoursService.getClosedHoursListCnt(closedHoursVO);
		returnMap.put("totalDataCount", totalDataCount);
		returnMap.put("dataList", sampleList);

		return returnMap;
	}

	/**
	 * <pre>
	 * 휴무일 추가 및 수정
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 17.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param closedHoursVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertAndUpdateClosedHoursList")
	@ResponseBody
	public ResponseEntity<?> insertAndUpdateClosedHoursList(@RequestBody List<ClosedHoursVO> closedHoursVO, BindingResult bindingResult) throws Exception {
		
		for(ClosedHoursVO vo : closedHoursVO) {
			if(vo.isValidation()) { // 유효성 검사 분기 (필요할 경우)
				// validation을 수행한다, validation VO Class의 형식은 VO, List<Vo>, Map<VO> 가능
				// process별로 validation 수행 field 들을 나누고 싶다면 group interface class를 지정하여 사용한다. (VO에도 지정)  
				customValidator.validate(vo, bindingResult, ClosedHoursVO.InsertAndUpdate.class);
			}
			
			if(Integer.parseInt(vo.getApplcBeginTime().replace(":", "")) > Integer.parseInt( vo.getApplcEndTime().replace(":", ""))) {
				return new ResponseEntity<>("시작시간은 종료시간보다 클 수 없습니다.", HttpStatus.BAD_REQUEST);
			}
			
			if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), vo.getApplcDe().replace("-", "")) == 1) {
				return new ResponseEntity<>("과거의 영업 시간은 등록 및 수정할 수 없습니다.", HttpStatus.BAD_REQUEST);
			}
		}
		
		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		closedHoursService.insertAndUpdateClosedHoursList(closedHoursVO);

		return new ResponseEntity<>(HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 휴무일 삭제
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 5. 17.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param closedHoursVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/deleteClosedHoursList")
	@ResponseBody
	public ResponseEntity<?> deleteClosedHoursList(@RequestBody List<ClosedHoursVO> closedHoursVO, BindingResult bindingResult) throws Exception {
		
		for(ClosedHoursVO vo : closedHoursVO) {
			if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), vo.getApplcDe().replace("-", "")) > 0) {
				return new ResponseEntity<>("과거의 영업 관리 일정은 삭제할 수 없습니다.", HttpStatus.BAD_REQUEST);
			}
		}
		
		closedHoursService.deleteClosedHoursList(closedHoursVO);

		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	/*
	@RequestMapping(value = "/selectHvofTyCodeList", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> selectHvofTyCodeList(@RequestBody ClosedHoursVO closedHoursVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		Map<String, CommonCodeVO> hvofTyCodeVo = commonCodeService.getSubCodesRetVo("HVOF_TY_CODE");
		
		List<CommonCodeVO> hvofTyCodeVoList = commonCodeService.getSubCodesToCommonCode("HVOF_TY_CODE");
		
		List<Map<String, String>> hvofTyCodeList = new ArrayList<>();
		for(Entry<String, CommonCodeVO> map : hvofTyCodeVo.entrySet()) {
			Map<String, String> hvofTyCodeMap = new HashMap<>();
			hvofTyCodeMap.put("hvofTyCode", map.getKey());
			hvofTyCodeMap.put("hvofTyNm", map.getValue().getCodeNm());
			hvofTyCodeList.add(hvofTyCodeMap);
		}
		
		returnMap.put("hvofTyCodeList", hvofTyCodeList);
		returnMap.put("hvofTyCodeVoList", hvofTyCodeVoList);
			
		return returnMap;
	}
	*/
	
}
