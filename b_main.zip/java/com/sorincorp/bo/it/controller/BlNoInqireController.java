package com.sorincorp.bo.it.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.BlNoInqireVO;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.model.LqdIntDatResVO;
import com.sorincorp.bo.it.service.BlNoInqireService;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.bo.it.service.ItemInvntrySetupService;
import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.brandcode.service.BrandCodeService;
import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;
import com.sorincorp.comm.brandgroupcode.service.BrandGroupCodeService;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.comm.wrhouscode.model.WrhousCodeVO;
import com.sorincorp.comm.wrhouscode.service.WrhousCodeService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/it")
@ComponentScan("com.sorincorp.comm.*")
public class BlNoInqireController {

	@Autowired
	private BlNoInqireService blNoInqireService;
	@Autowired
	private ItCmnCodeService itCmnCodeService;
	@Autowired
	private ItemCodeService itemCodeService;
	@Autowired
	private BrandGroupCodeService brandGroupCodeService;
	@Autowired
	private BrandCodeService brandCodeService;
	@Autowired
	private WrhousCodeService wrhousCodeService;
	@Autowired
	private ItemInvntrySetupService itemInvntrySetupService;
	@Autowired
	private CustomValidator customValidator;
	@Autowired
	private UserInfoUtil userInfoUtil;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	@RequestMapping("/selectBlNoInqireList")
	public String selectItemInvntrySetupList(String blNo, ModelMap model) {
		try {
			ItCmnCodeVO vo = new ItCmnCodeVO();
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			// 메탈코드 리스트
			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);

			vo.setMainCode("DSTRCT_LCLSF_CODE");
			vo.setCodeDctwo("");
			vo.setUseAt("Y");
			// 권역 대분류 리스트
			List<ItCmnCodeVO> dstrctLclsfCodeList = itCmnCodeService.selectCmnCodeList(vo);

			// 아이템 리스트
			List<ItemCodeVO> itemCodeList = itemCodeService.getItemFtrsProcessAtCodeList("", "");
			// 브랜드 그룹코드 리스트
			List<BrandGroupCodeVO> brandGroupCodeList = brandGroupCodeService.getBrandGroupCodeList("");
			// 브랜드코드 리스트
			List<BrandCodeVO> brandCodeList = brandCodeService.getBrandCodeList("");

			model.addAttribute("metalCodeList", metalCodeList);
			model.addAttribute("itemCodeList", itemCodeList);
			model.addAttribute("dstrctLclsfCodeList", dstrctLclsfCodeList);
			model.addAttribute("brandGroupCodeList", brandGroupCodeList);
			model.addAttribute("brandCodeList", brandCodeList);
			model.addAttribute("blNo", blNo);
			model.addAttribute("authorNo", userInfoUtil.getAuthorNo());

			return "it/blNoInqireList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	// selectBlNoInqireListAjax
	@RequestMapping("/selectBlNoInqireListAjax")
	@ResponseBody
	public ResponseEntity<Object> selectBlNoInqireListAjax(@RequestBody BlNoInqireVO blNoInqireVO, BindingResult bindingResult) throws Exception {

		customValidator.validate(blNoInqireVO, bindingResult, BlNoInqireVO.Search.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
//			log.error("vaildation error : " + bindingResult.getAllErrors().toString());
//			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		// BlNO를 공백 제거 후 배열에 담는다
		String getBlNo = blNoInqireVO.getBlNo();
		if (getBlNo.length() > 0) {
			String[] blNoArr = getBlNo.split("\\s*,\\s*");
			blNoInqireVO.setBlNoArr(blNoArr);
		}
		
		List<BlNoInqireVO> blNoInqireList = blNoInqireService.selectBlNoInqireList(blNoInqireVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("blNoInqireList", blNoInqireList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@RequestMapping("/selectBlNoInqireDetail")
	public String selectBlNoInqireDetail(@RequestBody BlNoInqireVO blNoInqireVO, ModelMap model) throws Exception {

		BlNoInqireVO vo = blNoInqireService.selectBlNoInqireDetail(blNoInqireVO.getBlNo());

		model.put("blNoInqireVO", vo);
		return "it/blNoInqireDetail.modal";
	}

	@RequestMapping("/selectBlNoInqireDetailAjax")
	@ResponseBody
	public ResponseEntity<Object> selectBlNoInqireDetailAjax(@RequestBody BlNoInqireVO blNoInqireVO, ModelMap model) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		BlNoInqireVO vo = blNoInqireService.selectBlNoInqireDetail(blNoInqireVO.getBlNo());

		retVal.put(RESULT, vo);
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/selectBlNoInqireDetailHstAjax")
	@ResponseBody
	public ResponseEntity<Object> selectBlNoInqireDetailHstAjax(@RequestBody BlNoInqireVO blNoInqireVO, ModelMap model) throws Exception {
		blNoInqireVO.setHstSrhType("FTRS_DELNG_LOT_QY");
		List<BlNoInqireVO> blNoInqireHstList1 = blNoInqireService.selectBlNoInqireDetailHst(blNoInqireVO);
		blNoInqireVO.setHstSrhType("FSHG_DELNG_DOLLAR_AMOUNT");
		List<BlNoInqireVO> blNoInqireHstList2 = blNoInqireService.selectBlNoInqireDetailHst(blNoInqireVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("blNoInqireHstList1", blNoInqireHstList1);
		map.put("blNoInqireHstList2", blNoInqireHstList2);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@RequestMapping("/selectVwEpoFileUrl")
	@ResponseBody
	public ResponseEntity<Object> selectVwEpoFileUrl(@RequestBody BlNoInqireVO blNoInqireVO, ModelMap model) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		BlNoInqireVO vo = blNoInqireService.selectVwEpoFileUrl(blNoInqireVO.getBlNo());

		retVal.put(RESULT, vo);
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/updateItPurchsInfoBas")
	@ResponseBody
	public ResponseEntity<Object> updateItPurchsInfoBas(@RequestBody BlNoInqireVO blNoInqireVO, Model model, BindingResult bindingResult) throws Exception {
		log.debug("blNoInqireVO ================>" + blNoInqireVO);
		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result = blNoInqireService.updateItPurchsInfoBas(blNoInqireVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
		} else {
			retVal.put(RESULT, FAIL);
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 파일 업로드 팝업 호출
	 * </pre>
	 *
	 * @date 2022. 12. 13.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 13.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param blInvntry
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/upLoadFile")
	public String popUpLoadFileModal(@RequestBody BlNoInqireVO blNoInqireVO, ModelMap model) throws Exception {
		BlNoInqireVO vo = new BlNoInqireVO();

		vo.setBlNo(blNoInqireVO.getBlNo());
		vo.setBrandCode(blNoInqireVO.getBrandCode());

		vo.setScreofeFileCours(blNoInqireVO.getScreofeFileCours());

		if (!StringUtil.isEmpty(vo.getScreofeFileCours())) {
			String[] screofeSplit = blNoInqireVO.getScreofeFileCours().split("/");
			vo.setScreofeDoc(screofeSplit[screofeSplit.length - 1]);
		}

		vo.setPackngListFileCours(blNoInqireVO.getPackngListFileCours());

		if (!StringUtil.isEmpty(vo.getPackngListFileCours())) {
			String[] packingSplit = blNoInqireVO.getPackngListFileCours().split("/");
			vo.setPackngDoc(packingSplit[packingSplit.length - 1]);
		}

		vo.setBlFileCours(blNoInqireVO.getBlFileCours());

		if (!StringUtil.isEmpty(vo.getBlFileCours())) {
			String[] blSplit = blNoInqireVO.getBlFileCours().split("/");
			vo.setBlDoc(blSplit[blSplit.length - 1]);
		}

		model.put("blNoInqireVO", vo);
		return "it/blUplLoadFile.modal";
	}

	@RequestMapping("/retryIsecoSleClBas")
	public ResponseEntity<Object> retryIsecoSleClBas() throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result = blNoInqireService.retryIsecoSleClBas();

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "고정가 재분류 생성 대상 데이터가 존재 하지 않습니다.");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 파일 업로드
	 * </pre>
	 *
	 * @date 2022. 12. 23.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 23.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param blNoInqireVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/fileUploadBlNoFile/{uploadFolder}")
	@ResponseBody
	public ResponseEntity<Object> fileUploadBlNoFile(@PathVariable("uploadFolder") String uploadFolder, MultipartHttpServletRequest mRequest) throws Exception {
		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		Map<String, Object> fileMap = blNoInqireService.saveAttachFile(mRequest, uploadFolder);
		// fileMap.put(uploadFolder,"");
		if ("COA".equals(uploadFolder)) {
			fileMap.put(uploadFolder, "COA");
		} else if ("PL".equals(uploadFolder)) {
			fileMap.put(uploadFolder, "PL");
		} else {
			fileMap.put(uploadFolder, "BL");
		}

		// log.info(fileMap.toString());
		String result = (String) fileMap.get(RESULT);

		if (SUCCESS.equals(result)) {
			retVal.put(RESULT, SUCCESS);
			retVal.put("fileMap", fileMap);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, (String) fileMap.get("errMsg"));
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 업로드된 파일 경로 저장
	 * </pre>
	 *
	 * @date 2022. 12. 23.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 23.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param blNoInqireVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/fileUploadBlNoInqire")
	@ResponseBody
	public ResponseEntity<Object> fileUploadBlNoInqire(@RequestBody BlNoInqireVO blNoInqireVO) throws Exception {
		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		blNoInqireService.updateBlNoInqireFile(blNoInqireVO);
		// log.info(fileMap.toString());

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 업로드된 파일 경로 저장
	 * </pre>
	 *
	 * @date 2022. 12. 23.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2022. 12. 23.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param blNoInqireVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/fileDeleteBlNoInqire")
	@ResponseBody
	public ResponseEntity<Object> fileDeleteBlNoInqire(@RequestBody BlNoInqireVO blNoInqireVO, Model model, BindingResult bindingResult) throws Exception {
		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result = 1;

		blNoInqireService.deleteBlNoInqireFile(blNoInqireVO);
		// log.info(fileMap.toString());

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/selectFtrsProfsDetail")
	public String selectFtrsProfsDetail(@RequestBody BlNoInqireVO blNoInqireVO, ModelMap model) throws Exception {

		BlNoInqireVO vo = blNoInqireService.selectBlNoInqireDetail(blNoInqireVO.getBlNo());

		model.put("blNoInqireVO", vo);
		return "it/ftrsProfsDetail.modal";
	}

	@RequestMapping("/selectFtrsProfsListAjax")
	@ResponseBody
	public ResponseEntity<Object> selectFtrsProfsListAjax(ModelMap model) throws Exception {

		ItCmnCodeVO vo = new ItCmnCodeVO();
		vo.setMainCode("FTRS_CMPNY_SE_CODE");
		vo.setUseAt("Y");
		// 선물사 리스트
		List<ItCmnCodeVO> ftrsProfsList = itCmnCodeService.selectCmnCodeList(vo);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("ftrsProfsList", ftrsProfsList);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@RequestMapping("/updateFtrsProfsSeCode")
	@ResponseBody
	public ResponseEntity<Object> updateFtrsProfsSeCode(@RequestBody BlNoInqireVO blNoInqireVO, Model model, BindingResult bindingResult) throws Exception {
		log.debug("blNoInqireVO ================>" + blNoInqireVO);
		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(blNoInqireVO, bindingResult, BlNoInqireVO.UpdateFtrsProfsSeCode.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = blNoInqireService.updateFtrsProfsSeCode(blNoInqireVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
		} else {
			retVal.put(RESULT, FAIL);
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/blInfoRegisterPop")
	public String blInfoRegisterPop(@RequestBody BlNoInqireVO blNoInqireVO, ModelMap model) throws Exception {
		
		ItCmnCodeVO vo = new ItCmnCodeVO();
		vo.setMainCode("METAL_CODE");
		vo.setCodeDctwo("Y");
		vo.setUseAt("Y");
		// 메탈코드 리스트
		List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);

		vo.setMainCode("DSTRCT_LCLSF_CODE");
		vo.setCodeDctwo("");
		vo.setUseAt("Y");
		// 권역 대분류 리스트
		List<ItCmnCodeVO> dstrctLclsfCodeList = itCmnCodeService.selectCmnCodeList(vo);

		vo.setMainCode("DSTRCT_MLSFC_CODE");
		vo.setCodeDctwo("");
		vo.setUseAt("Y");
		// 권역 중분류 리스트
		List<ItCmnCodeVO> dstrctMlsfcCodeList = itCmnCodeService.selectCmnCodeList(vo);

		// 아이템 리스트
		List<ItemCodeVO> itemCodeList = itemCodeService.getItemFtrsProcessAtCodeList("", "");
		// 브랜드코드 리스트
		List<BrandCodeVO> brandCodeList = brandCodeService.getBrandCodeList("");
		// 물류센터 리스트 조회
		List<WrhousCodeVO> wrhousCodeList = wrhousCodeService.getWrhousCode();
		// 물류센터 위치 리스트 조회
		List<ItCmnCodeVO> wrhousCellLcList = itemInvntrySetupService.getWrhousCellLcList("");
		
		if(blNoInqireVO.getModalPageStatus().equals("update") || blNoInqireVO.getModalPageStatus().equals("blUpdate")) {
			BlNoInqireVO blInquireVo = blNoInqireService.selectBlNoInqireDetail(blNoInqireVO.getBlNo());
			blInquireVo.setRemainQy(blNoInqireVO.getRemainQy());			//선물잔량
			blInquireVo.setRemainAmount(blNoInqireVO.getRemainAmount()); 	//선물환잔액
			
			model.put("blNoInqireVO", blInquireVo);
		}
		
		model.addAttribute("metalCodeList", metalCodeList);
		model.addAttribute("itemCodeList", itemCodeList);
		model.addAttribute("dstrctLclsfCodeList", dstrctLclsfCodeList);
		model.addAttribute("dstrctMlsfcCodeList", dstrctMlsfcCodeList);
		model.addAttribute("brandCodeList", brandCodeList);
		model.addAttribute("wrhousCodeList", wrhousCodeList);
		model.addAttribute("wrhousCellLcList", wrhousCellLcList);
		model.addAttribute("modalPageStatus", blNoInqireVO.getModalPageStatus());
		
		return "it/blInfoRegisterPop.modal";
	}

	/**
	 * <pre>
	 * 처리내용: 브랜드 리스트 
	 * </pre>
	 * @date 2024.03.12
	 * @auther sumin
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.03.12				sumin				최초작성
	 * -----------------------------------------------
	 * @param itemInvntrySetupVO
	 * @return Map
	 * @throws Exception
	 */
	@PostMapping("/selectBrandInfoList")
	@ResponseBody
	public ResponseEntity<Object> selectBrandInfoList(@RequestBody BlNoInqireVO blNoInqireVO) throws Exception {
		Map<String,Object> map = new HashMap<>();
		try {
			List<BlNoInqireVO> brandList = blNoInqireService.selectBrandInfoList(blNoInqireVO);
			map.put("brandList", brandList);
			
			return new ResponseEntity<>(map, HttpStatus.OK);
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>("조건에 맞는 브랜드 그룹이 없습니다.", HttpStatus.BAD_REQUEST);
		}
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 선물환 API 정보 조회
	 * </pre>
	 * @date 2024.03.27
	 * @auther sumin
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.03.27				sumin				최초작성
	 * -----------------------------------------------
	 * @param itemInvntrySetupVO
	 * @return Map
	 * @throws Exception
	 */
	@RequestMapping("/selectFshgInfoList")
	public String selectFshgInfoList(@RequestBody LqdIntDatResVO lqdIntDatResVO, ModelMap model) throws Exception {
		return "it/fshgInfoMappingPop.modal";
	}
	
	/**
	 * <pre>
	 * 처리내용: 선물환정보 매핑
	 * </pre>
	 * @date 2024.03.27
	 * @auther sumin
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.03.27				sumin				최초작성
	 * -----------------------------------------------
	 * @param itemInvntrySetupVO
	 * @return Map
	 * @throws Exception
	 */
	@RequestMapping("/selectFshgInfoListAjax")
	@ResponseBody
	public ResponseEntity<Object> selectFshgInfoListAjax(@RequestBody LqdIntDatResVO lqdIntDatResVO, ModelMap model) throws Exception {

		List<LqdIntDatResVO> fshgInfoList = blNoInqireService.selectFshgInfoList(lqdIntDatResVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("fshgInfoList", fshgInfoList);
		
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	
	/**
	 * <pre>
	 * 처리내용: bl정보 등록 (엑셀 업로드)
	 * </pre>
	 * @date 2024.04.03
	 * @auther sumin
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.04.03				sumin				최초작성
	 * -----------------------------------------------
	 * @param String
	 * @return Int
	 * @throws Exception
	*/
	@RequestMapping(value="/xlsBlInfoRegst", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> xlsBlInfoRegst(@RequestParam("excelFile") MultipartFile multipartFile) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		BlNoInqireVO blInfoVo = new BlNoInqireVO();
		
		ArrayList<BlNoInqireVO> blInfoSaveList = new ArrayList<>();
		
		try {
			XSSFWorkbook workbook = new XSSFWorkbook(multipartFile.getInputStream());
			XSSFSheet sheet = workbook.getSheetAt(0);	//첫번째 시트 내용만 가져옴.

			Row row = null;
			
			int lastRowNum = sheet.getPhysicalNumberOfRows() - 1;
		
				for(int i=1; i<lastRowNum + 1; i++) {
					DataFormatter formatter = new DataFormatter();		        
					row = sheet.getRow(i);
					
					if(row != null && row.getCell(1) != null) {	
				
						blInfoVo = new BlNoInqireVO();
						blInfoVo.setBlNo(formatter.formatCellValue(row.getCell(1)));
						blInfoVo.setFrghtManageNo(formatter.formatCellValue(row.getCell(2)));
						blInfoVo.setLclsfDlivyDstrctCode(formatter.formatCellValue(row.getCell(3)));
						blInfoVo.setMlsfcDlivyDstrctCode(formatter.formatCellValue(row.getCell(4)));
						blInfoVo.setWrhousCode(formatter.formatCellValue(row.getCell(5)));
						blInfoVo.setWrhousCellLc(formatter.formatCellValue(row.getCell(6)));
						blInfoVo.setExBrandNm(formatter.formatCellValue(row.getCell(7)));
						blInfoVo.setBlNetWt(formatter.formatCellValue(row.getCell(8)));
						blInfoVo.setBlGrossWt(formatter.formatCellValue(row.getCell(9)));
						blInfoVo.setBundleQy(formatter.formatCellValue(row.getCell(10)));
						blInfoVo.setEntrAt(formatter.formatCellValue(row.getCell(11)));
						blInfoVo.setOrderId(formatter.formatCellValue(row.getCell(12)));
						blInfoVo.setOrderDetailNo(formatter.formatCellValue(row.getCell(13)));
						blInfoVo.setEntrDt(formatter.formatCellValue(row.getCell(14)));
						blInfoVo.setWrhousngDt(formatter.formatCellValue(row.getCell(15)));
						blInfoVo.setSlePossde(formatter.formatCellValue(row.getCell(16)));
						blInfoVo.setBlRmrk(formatter.formatCellValue(row.getCell(17)));
	
						blInfoSaveList.add(blInfoVo);
						
					} else { //BL이 없거나, 데이터가 없는 경우
					
					}
				}
				
				blInfoVo.setBlInfoSaveList(blInfoSaveList);
				
				int result = blNoInqireService.xlsBlInfoRegst(blInfoVo);
				
				if(result == 0) {
					retVal.put(RESULT, FAIL);
					retVal.put(ERRMSG, "모두 중복 BL이므로 저장 불가합니다." );
				} else if (result > 0) {
					retVal.put(RESULT, SUCCESS);
					retVal.put(ERRMSG, result +" 건 저장완료하였습니다." );
				} else {
					retVal.put(RESULT, FAIL);
					retVal.put(ERRMSG, "저장에 실패하였습니다.");
				}
				
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>("조건에 맞는 데이터가 없습니다.", HttpStatus.BAD_REQUEST);
		}
		
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: BL정보 삭제
	 * </pre>
	 * @date 2024.04.03
	 * @auther sumin
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.04.03				sumin				최초작성
	 * -----------------------------------------------
	 * @param String
	 * @return Int
	 * @throws Exception
	 */
	@RequestMapping("/deleteBlInfo")
	@ResponseBody
	public ResponseEntity<Object> deleteBlInfo(@RequestBody BlNoInqireVO blNoInqireVO, Model model, BindingResult bindingResult) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		
		int orderCount = blNoInqireService.getBlOrderCnt(blNoInqireVO.getBlNo());
		int result = 0;
		
		// 주문내역이 존재 하는 B/L 은 삭제 불가능.
		if(orderCount >= 1) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "주문내역이 존재하여 삭제가 불가능합니다.");
		} else {
			result = blNoInqireService.updateBlPoInfo(blNoInqireVO);
			
			if (result >= 1) {
				retVal.put(RESULT, SUCCESS);
				retVal.put(ERRMSG, "삭제 완료되었습니다.");
			} else {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "삭제에 실패했습니다.");
			}
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
	

	/**
	 * <pre>
	 * 처리내용: BL번호 변경 모달 조회
	 * </pre>
	 * @date 2024.04.03
	 * @auther sumin
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.04.03				sumin				최초작성
	 * -----------------------------------------------
	 * @param String
	 * @return Int
	 * @throws Exception
	 */
	@RequestMapping("/selectBlNoPop")
	public String selectBlNoPop(@RequestBody BlNoInqireVO blNoInqireVO, ModelMap model) throws Exception {
	
		return "it/updateBlNoPop.modal";
	}
	
	/**
	 * <pre>
	 * 처리내용: BL번호 변경
	 * </pre>
	 * @date 2024.04.03
	 * @auther sumin
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.04.03				sumin				최초작성
	 * -----------------------------------------------
	 * @param String
	 * @return Int
	 * @throws Exception
	 */
	@RequestMapping("/updateBlNoAjax")
	@ResponseBody
	public ResponseEntity<Object> updateBlNoAjax(@RequestBody BlNoInqireVO blNoInqireVO, Model model, BindingResult bindingResult) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		
		//boolean isBlupdate = blNoInqireService.updateBlNo(blNoInqireVO);
		int result = 0;
		
			blNoInqireService.updateBlNo(blNoInqireVO);
			result = blNoInqireService.updateBlPoInfo(blNoInqireVO);
			
			if (result >= 1) {
				retVal.put(RESULT, SUCCESS);
				retVal.put(ERRMSG, "수정 완료되었습니다.");
			} else {
				retVal.put(RESULT, FAIL);

			}
		//}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	
	/**
	 * <pre>
	 * 처리내용: 만기일자, FCM 변경 모달 조회
	 * </pre>
	 * @date 2024.05.14
	 * @auther sumin
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.05.14				sumin				최초작성
	 * -----------------------------------------------
	 * @param BlNoInqireVO
	 * @return String
	 * @throws Exception
	 */
	@RequestMapping("/selectblExprtnPop")
	public String selectblExprtnPop(@RequestBody BlNoInqireVO blNoInqireVO, ModelMap model) throws Exception {
		
		ItCmnCodeVO vo = new ItCmnCodeVO();
		vo.setMainCode("FTRS_CMPNY_SE_CODE");
		vo.setUseAt("Y");
		// 선물사 리스트
		List<ItCmnCodeVO> ftrsProfsList = itCmnCodeService.selectCmnCodeList(vo);

		model.addAttribute("ftrsProfsList", ftrsProfsList);
		return "it/blExprtnExtnPop.modal";
	}
	
	/**
	 * <pre>
	 * 처리내용: 만기일자, FCM 변경
	 * </pre>
	 * @date 2024.04.03
	 * @auther sumin
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.04.03				sumin				최초작성
	 * -----------------------------------------------
	 * @param String
	 * @return Int
	 * @throws Exception
	 */
	@RequestMapping("/updateExprtnDe")
	@ResponseBody
	public ResponseEntity<Object> updateBlExprtnDe(@RequestBody BlNoInqireVO blNoInqireVO, Model model, BindingResult bindingResult) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		int result = 0;
		
			result = blNoInqireService.updateBlExprtnDe(blNoInqireVO);
			
			if (result >= 1) {
				retVal.put(RESULT, SUCCESS);
				retVal.put(ERRMSG, "수정 완료되었습니다.");
			} else {
				retVal.put(RESULT, FAIL);

			}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**

	 * <pre>
	 * 처리내용: STS AP UPDATE
	 * </pre>
	 * @date 2024.07.31
	 * @auther hamyoonsic
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.07.31				hamyoonsic			최초작성
	 * -----------------------------------------------
	 * @param blNoInqireVO
	 * @return Int
	 * @throws Exception
	 */
	@RequestMapping("/stsApIf")
	@ResponseBody
	public ResponseEntity<Object> stsApIf(@RequestBody BlNoInqireVO blNoInqireVO) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		int result = 0;

		result = blNoInqireService.stsApIf(blNoInqireVO);

		if (result >= 1) {
			retVal.put(RESULT, SUCCESS);
		} else {
			retVal.put(RESULT, FAIL);
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 선물환 정보 반영 팝업창
	 * </pre>
	 * @date 2024.9.19
	 * @auther hamyoonsic
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.9.19				hamyoonsic			최초작성
	 * -----------------------------------------------
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectFshgInfo")
	public String selectFshgInfo(@RequestBody Map<String,Object> paramMap, Model model) throws Exception {
		return "it/fshgConfirmPop.modal";
	}
}
