package com.sorincorp.bo.it.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;

import com.sorincorp.bo.it.model.SidecarVO;
import com.sorincorp.bo.it.service.PrimiumPriceMngService;
import com.sorincorp.bo.it.service.SidecarService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/it/sidecar")
public class SidecarController {
	@Autowired
	private SidecarService sidecarService;
	@Autowired
	private PrimiumPriceMngService ppms;
	@Autowired
	private CommonCodeService commonCodeService;
	/**
	 * <pre>
	 * 처리내용: 사이드카 화면 보여준다.
	 * </pre>
	 * @date 2021. 5. 28.
	 * @author Cho han yong
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 28.			Cho han yong		최초작성
	 * ------------------------------------------------
	 * @return "it/sidecar.tiles"
	 * @throws Exception
	 */
	@RequestMapping("/selectList")
	public String selectSidecarList(ModelMap model) {
		try {
			/*Map<String, CommonCodeVO> metalCodeVo = commonCodeService.getMultiFilterCodeRetVo("METAL_CODE",null,	//MAIN_CODE가 "METAL_CODE"인 공통 코드
					  "CODE_DCTWO","Y", null, null	//CODE_DCTWO(코드 설명2, EC 판매 대상 여부)가 Y인 METAL_CODE
					, "CODE_CHRCTR_REFRNTHREE", "1", "0", "1");	//CODE_CHRCTR_REFRNTHREE(코드 문자 참조3, 판매비트)의 첫번째 값(LIVE)이 1(TRUE)인 METAL_CODE

			List<CommonCodeVO> metalCodeList = new ArrayList<CommonCodeVO>();

			// 환율 관련 code 0부여, 20220215 추가
//			CommonCodeVO customMeteCodeVO = new CommonCodeVO();
//			customMeteCodeVO.setSubCode("0");
//			customMeteCodeVO.setCodeNm("환율");
//			metalCodeList.add(customMeteCodeVO);

			metalCodeList.addAll(metalCodeVo.values().stream().collect(Collectors.toList()));

			model.put("metalCode", metalCodeList);*/
			
			Map<String, String> metalCode = commonCodeService.getFilterCode("METAL_CODE", null, "CODE_DCTWO", "Y");
			model.put("metalCode", metalCode);

			return "it/sidecar";
		} catch(Exception e){
				log.error(e.getMessage());
				HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
				return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 사이드카 목록을 조회한다.
	 * </pre>
	 * @date 2021. 5. 28.
	 * @author Cho han yong
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 28.			Cho han yong		최초작성
	 * ------------------------------------------------
	 * @param  sidecarVO
	 * @return "it/sidecar.tiles"
	 * @throws Exception
	 */
	@RequestMapping(value="/selectAjaxList", method={RequestMethod.POST})
	@ResponseBody
	public Map<String,Object> selectSidecarAjaxList(@RequestBody SidecarVO sidecarVO) throws Exception {

		int totalCnt = sidecarService.searchSidecarTotalCnt(sidecarVO);
		//등록된 사이드카 조회
		Map<String,Object> map = new HashMap<String, Object>();
		List<SidecarVO> sidecarList = null;
		if(totalCnt > 0) {
			sidecarList = sidecarService.searchSidecarList(sidecarVO);
		}
		map.put("dataList", sidecarList);
		map.put("totalDataCount", totalCnt);
		return map;
	}


	/**
	 * <pre>
	 * 처리내용: 사이드카 목록을 저장, 업데이트 한다.
	 * </pre>
	 * @date 2021. 5. 28.
	 * @author Cho han yong
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 28.			Cho han yong		최초작성
	 * ------------------------------------------------
	 * @param  sidecarVOList
	 * @return "it/sidecar.tiles"
	 * @throws Exception
	 */
	@PostMapping("/insertAndUpdateAjaxList")
	@ResponseBody
	public ResponseEntity<?> insertAndUpdateSidecarAjaxList(@RequestBody List<SidecarVO> sidecarVOList, BindingResult bindingResult, SessionStatus status) throws Exception {

		for(SidecarVO vo : sidecarVOList) {
			//데이터 중복 체크

			if("created".equals(vo.getGridRowStatus())) {
				int dupCnt = sidecarService.selectDupSidecar(vo);
				if(dupCnt > 0) {
					return new ResponseEntity<>("중복된 데이터가 존재 합니다.", HttpStatus.BAD_REQUEST);
				}
			}
			//날짜1이 날짜2와 동일하다면 0, 날짜1이 크다면 음수, 날짜2가 크다면 양수
			//이전날짜도 전부 수정 삭제 되도록 변경 (2021.09.08)
			if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), vo.getApplcDe().replace("-", "")) > 0) {
				return new ResponseEntity<>("적용일이 오늘날짜 이후일 경우에만 수정가능합니다.", HttpStatus.BAD_REQUEST);
			}
		}

		sidecarService.insertAndUpdateSidecar(sidecarVOList);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PostMapping("/deleteAjax")
	@ResponseBody
	public ResponseEntity<?> deleteSidecar(@RequestBody List<SidecarVO> sidecarVO, SessionStatus status) throws Exception {
		for(SidecarVO vo : sidecarVO) {
			//날짜1이 날짜2와 동일하다면 0, 날짜1이 크다면 음수, 날짜2가 크다면 양수
            if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), vo.getApplcDe().replace("-", "")) > 0) {
            	return new ResponseEntity<>("적용일은 오늘날짜보다 이후에만 가능합니다.", HttpStatus.BAD_REQUEST);
            }
		}

		sidecarService.deleteSidecar(sidecarVO);
		status.setComplete();
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 사이드카 내역 화면을 보여준다 
	 * </pre>
	 * @date 2022. 9. 7.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 7.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 */
	@RequestMapping("/selectDtlList")
	public String selectSidecarDtlList(ModelMap model) {
		
		try {
			/*Map<String, String> metalCode = commonCodeService.getFilterCode("METAL_CODE", null, "CODE_DCTWO", "Y");
			model.put("metalCode", metalCode);
			*/
			
			Map<String, String> metalCode = commonCodeService.getFilterCode("METAL_CODE", null, "CODE_DCTWO", "Y");
			model.put("metalCode", metalCode);
			
			return "it/sidecarDtl";
		} catch(Exception e){
				log.error(e.getMessage());
				HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
				return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 사이드카 내역 목록을 조회한다
	 * </pre>
	 * @date 2022. 9. 7.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 7.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param sidecarVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/selectAjaxDtlList", method={RequestMethod.POST})
	@ResponseBody
	public Map<String,Object> selectSidecarDtlAjaxList(@RequestBody SidecarVO sidecarVO) throws Exception {

		int totalDtlCnt = sidecarService.searchSidecarDtlTotalCnt(sidecarVO);
		
		Map<String,Object> map = new HashMap<String, Object>();
		List<SidecarVO> sidecarDtlList = null;
		if(totalDtlCnt > 0) {
			sidecarDtlList = sidecarService.searchSidecarDtlList(sidecarVO);
		}
		map.put("dataList", sidecarDtlList);
		map.put("totalDataCount", totalDtlCnt);
		return map;
	}

}
