package com.sorincorp.bo.it.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;

import com.sorincorp.bo.it.model.PrEhgtPcRltmBasVO;
import com.sorincorp.bo.it.model.PremiumDetailProfitAndLoseVO;
import com.sorincorp.bo.it.model.PremiumMonFxEvaluationCashVO;
import com.sorincorp.bo.it.model.PremiumSetPriceVO;
import com.sorincorp.bo.it.model.PremiumStdrBasVO;
import com.sorincorp.bo.it.service.PrimiumPriceMngService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.pcInfo.model.LmePcVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * PremierePriceMng.java
 *
 * @version
 * @since 2021. 6. 17.
 * @author srec0031
 */
@Slf4j
@Controller
@RequestMapping("/it/premium")
public class PremiumPriceMngController {
	@Autowired
	private PrimiumPriceMngService ppms;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private ItemCodeService itemCodeService;

	@Autowired
	private PcInfoService pcInfoService;
	
	@Autowired
	private CustomValidator customValidator;

	/**
	 * <pre>
	 * 처리내용: 프리미어 가격 관리 페이지 로드 하다.
	 * </pre>
	 *
	 * @date 2021. 6. 17.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일           작성자        변경내용
	 * ------------------------------------------------
	 * 2021. 6. 17.    srec0031       최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(value = "/selectList", method = RequestMethod.GET)
	public String premiumPrice(ModelMap model) {
		try {
			// 아이템 코드
			List<ItemCodeVO> itmSn = itemCodeService.getItemCodeList("");
			Map<String, String> sleMthdCode = commonCodeService.getFilterCode("SLE_MTHD_CODE", "01", null, null); //Live
			Map<String, String> fixMthdCode = commonCodeService.getFilterCode("SLE_MTHD_CODE", "02", null, null); //케이지몰
			sleMthdCode.putAll(fixMthdCode);
			
			model.put("metalCode", commonCodeService.getFilterCode("METAL_CODE",null,"CODE_DCTWO","Y"));  //메탈구분
			model.put("itmSn", itmSn);
			model.put("sleMthdCode", sleMthdCode); // 아이템구분
			
			return "it/premiumPriceMngList";
		} catch(Exception e){
				log.error(e.getMessage());
				HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
				return "error/503";
		}
	}

	/**
	 * <pre>
	 * 메탈코드를 기준으로 아이템 목록을 가져온다
	 * </pre>
	 * @date 2022. 3. 15.
	 * @author srec0004
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 3. 15.		srec0004		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param premiumStdrBasVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value="/getItmSn")
	@ResponseBody
	public Map<String, Object> getBrandGroupItmSn(@RequestBody PremiumStdrBasVO premiumStdrBasVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		// 아이템 코드
		List<ItemCodeVO> itmSn = itemCodeService.getItemCodeList(premiumStdrBasVO.getMetalCode());

		returnMap.put("itmSn", itmSn);

		return returnMap;
	}

	/**
	 * <pre>
	 * 처리내용: 등록된 프리미어가격 목록 조회 한다.
	 * </pre>
	 *
	 * @date 2021. 6. 17.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일                작성자             변경내용
	 * ------------------------------------------------
	 * 2021. 6. 17.         srec0031            최초작성
	 * ------------------------------------------------
	 * @param sidecarVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/selectPremiumPriceAjaxList", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> selectPremiumAjaxList(@RequestBody PremiumStdrBasVO psbVO) throws Exception {
		// 등록된 프리미어 가격 조회
		Map<String, Object> map = new HashMap<String, Object>();
		//기준 테이블(IT_PREMIUM_STDR_BAS)에서
		//아이템 기본 테이블에서 유효한 아이템
		//공통코드의 메탈, 권역, 브랜드그룹, 브랜드에서 유효한 데이터
		List<PremiumStdrBasVO> PrimiumPriceList = ppms.selectPremiumList(psbVO);
		int totalCnt = ppms.selectPremiumCnt(psbVO);

		map.put("dataList", PrimiumPriceList);
		map.put("totalDataCount", totalCnt);
		return map;
	}
	/**
	 * <pre>
	 * 처리내용: 선택된 프리미어가격 목록 삭제 한다.
	 * </pre>
	 *
	 * @date 2021. 6. 17.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일                작성자             변경내용
	 * ------------------------------------------------
	 * 2021. 6. 17.         srec0031            최초작성
	 * ------------------------------------------------
	 * @param sidecarVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/deleteAjax")
	@ResponseBody
	public String deleteAjax(@RequestBody List<PremiumStdrBasVO> vo, SessionStatus status) throws Exception {
		ppms.deletePremiumPrice(vo);
		status.setComplete();
		return "success";
	}

	/**
	 * <pre>
	 * 처리내용: 프리미엄 설정 그리드 데이터 불러온다. (LIVE)
	 *         : 라이브 프리미엄 가격 신규등록 및 라이브 프리미엄 가격 업데이트시 호출
	 * </pre>
	 * @date 2021. 6. 28.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param psVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getPremiummPrice", method = { RequestMethod.GET, RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> getPremiummPrice(@RequestBody PremiumSetPriceVO psVO, ModelMap model) throws Exception {
		//오늘자 1회차 환율 END_PC 추가
		PrEhgtPcRltmBasVO prEhgtPcRltmBasVO = new PrEhgtPcRltmBasVO();
		prEhgtPcRltmBasVO = ppms.getprEhgtPcFirstByToday();

		//프리미엄 기준 정보
//		PremiumStdrBasVO premiumStdrBasVO = ppms.getPremiumStdInfoByPremiumId(psVO.getPremiumId());
		PremiumStdrBasVO premiumStdrBasVO = ppms.getMetalItmStdr(psVO);
		psVO.setStdrEhgtPc(prEhgtPcRltmBasVO.getEndPc());
		//권역, 브랜드그룹, 브랜드별 프리미엄 가격 리스트 정보
		List<PremiumSetPriceVO> setPrimiumlist = ppms.getPrimiumLivePriceList(psVO);
		//신규 프리니엄 설정 항목 : 기준 권역(LIVE or 고정가 권역여부), 브랜드 그룹 코드(
//		String ftrsprocessat = psVO.getFtrsprocessat();	//선물처리여부 : "Y"일 시 LIVE, "N"일 시 고정가
//		String dstrctLclsfCodeRefColumn = null;	//권역 대분류 코드 참조 Column
//		if(StringUtils.equals(ftrsprocessat, "Y")) {	//LIVE일 경우
//			dstrctLclsfCodeRefColumn = "CODE_REFRNONE";
//		}else {	//고정가일 경우
//			dstrctLclsfCodeRefColumn = "CODE_REFRNTWO";
//		}
//		Map<String, String> dstrctLclsfCode = commonCodeService.getFilterCode("DSTRCT_LCLSF_CODE", null, dstrctLclsfCodeRefColumn, "Y"); // 권역 대분류 코드 - LIVE 또는 고정가 권역 여부가 "Y"인 항목
//		Map<String, String> brandGroupCode = commonCodeService.getFilterCode("BRAND_GROUP_CODE", null, "CODE_REFRNONE", psVO.getMetalCode()); // 브랜드 그룹 코드 - 품목 대분류 코드와 메탈 코드가 같은 항목으로 필터링
		PremiumStdrBasVO paramVO = new PremiumStdrBasVO();
		paramVO.setMetalCode(psVO.getMetalCode());
		paramVO.setItmSn(psVO.getItmSn());
		paramVO.setSleMthdCode(psVO.getSleMthdCode());
		paramVO.setValidBeginDt(psVO.getValidBeginDt());
		
		String lastValidEndDt = ppms.premiumdDuplicateCheck(paramVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("premiumStdrBasVO", premiumStdrBasVO);
		map.put("dataList", setPrimiumlist);
		map.put("endPc", prEhgtPcRltmBasVO.getEndPc() == null ? new BigDecimal("0").toString() : prEhgtPcRltmBasVO.getEndPc().toString());
		map.put("lastValidEndDt", lastValidEndDt);
//		map.put("dstrctLclsfCode", dstrctLclsfCode);
//		map.put("brandGroupCode", brandGroupCode);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 프리미엄 설정 그리드 데이터 불러온다. (고정가)
	 *         : 고정가 프리미엄 가격 신규등록 및 고정가 프리미엄 가격 업데이트시 호출
	 * </pre>
	 * @date 2021. 6. 28.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param psVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getPremiummFixPrice", method = { RequestMethod.GET, RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> getPremiummFixPrice(@RequestBody PremiumSetPriceVO psVO, ModelMap model) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();
		String hghnetprcAvrgPurchsPrmpc = ppms.getAvrgPurchsPrmpc(psVO);
		
		// 고정가 구매원가 관리가 없을 경우 에러 리턴
		if(hghnetprcAvrgPurchsPrmpc != null) {
			map.put("hghnetprcAvrgPurchsPrmpc", hghnetprcAvrgPurchsPrmpc);

			PremiumStdrBasVO premiumStdrBasVO = ppms.getMetalItmStdr(psVO);
			map.put("premiumStdrBasVO", premiumStdrBasVO);

			List<PremiumSetPriceVO> dataList = ppms.getSetPrimiumFixPriceList(psVO);
			map.put("dataList", dataList);
			
			PremiumStdrBasVO paramVo = new PremiumStdrBasVO();
			BeanUtils.copyProperties(psVO, paramVo);
			String lastValidEndDt = ppms.premiumdDuplicateCheck(paramVo);
			map.put("lastValidEndDt", lastValidEndDt);
		}
		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 프리미엄 가격관리 추가 화면 불러온다.
	 * </pre>
	 * @date 2021. 6. 28.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28. 		srec0031			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/insertPremiumPrice", method = { RequestMethod.GET, RequestMethod.POST })
	public String insertPremiumPrice(ModelMap model) {
		try {
			Map<String, String> dstrctLclsfCode = commonCodeService.getSubCodes("DSTRCT_LCLSF_CODE"); // 권역 대분류 코드
			Map<String, String> brandGroupCode = commonCodeService.getSubCodes("BRAND_GROUP_CODE"); // 권역 중분류 코드

			List<ItemCodeVO> itmCodeList = itemCodeService.getItemFtrsProcessAtCodeList("", "Y");    //아이템코드 Live만 불러다다
			model.put("itmCode", itmCodeList); // 아이템구분
			model.put("metalCode", commonCodeService.getFilterCode("METAL_CODE",null,"CODE_DCTWO","Y"));  //메탈구분
			model.put("dstrctLclsfCode", dstrctLclsfCode); // 아이템구분
			model.put("brandGroupCode", brandGroupCode); // 아이템구분

			return "it/insertPremiumPrice";
		} catch(Exception e){
				log.error(e.getMessage());
				HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
				return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 프리미어 가격설정 업데이트 페이지 호출
	 * </pre>
	 *
	 * @date 2021. 6. 28.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일          작성자          변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28.    srec0031        최초작성
	 * ------------------------------------------------
	 * @param psbVo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/updatePremiumPrice", method = { RequestMethod.GET, RequestMethod.POST })
	public String updatePremiumPrice(PremiumStdrBasVO psbVo, ModelMap model) {
		try {
			Map<String, String> dstrctLclsfCode = commonCodeService.getSubCodes("DSTRCT_LCLSF_CODE"); // 권역 대분류 코드
			Map<String, String> brandGroupCode = commonCodeService.getSubCodes("BRAND_GROUP_CODE"); // 권역 중분류 코드

			//List<CommCodeTmpVO> itmCodeList = ppms.getItemCodeList(metalCodeList); // 아이템 리스트(메탈 상세)
			List<ItemCodeVO> itmCodeList = itemCodeService.getItemCodeList("");    //아이템코드 전체 불러 온다

			model.put("itmCode", itmCodeList); // 아이템구분
			model.put("metalCode", commonCodeService.getFilterCode("METAL_CODE",null,"CODE_DCTWO","Y"));  //메탈구분
			model.put("dstrctLclsfCode", dstrctLclsfCode); //권역 구분
			model.put("brandGroupCode", brandGroupCode); // 브랜드 그룹 구분

			psbVo = ppms.getPremiumStdInfoByPremiumId(psbVo.getPremiumId());
			model.put("psbVo", psbVo);  //프리미엄 기준정보

			return "it/updatePremiumPrice";
		} catch(Exception e){
				log.error(e.getMessage());
				HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
				return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 프리미엄 가격관리 상세 화면 불러온다.
	 * </pre>
	 * @date 2021. 6. 28.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28.		srec0031			최초작성
	 * ------------------------------------------------
	 * @param psbVo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/detailPremiumPrice", method = { RequestMethod.GET, RequestMethod.POST })
	public String detailPremiumPrice(PremiumStdrBasVO psbVo, ModelMap model) {
		try {
			Map<String, String> dstrctLclsfCode = commonCodeService.getSubCodes("DSTRCT_LCLSF_CODE"); // 권역 대분류 코드
			Map<String, String> brandGroupCode = commonCodeService.getSubCodes("BRAND_GROUP_CODE"); // 권역 중분류 코드

			List<ItemCodeVO> itmCodeList = itemCodeService.getItemCodeList("");    //아이템코드 전체 불러 온다
			model.put("itmCode", itmCodeList); // 아이템구분
			model.put("metalCode", commonCodeService.getFilterCode("METAL_CODE",null,"CODE_DCTWO","Y")); // 아이템구분
			model.put("dstrctLclsfCode", dstrctLclsfCode); // 아이템구분
			model.put("brandGroupCode", brandGroupCode); // 아이템구분

			psbVo = ppms.getPremiumStdInfoByPremiumId(psbVo.getPremiumId());
			model.put("psbVo", psbVo);  //프리미엄 기준정보

			return "it/detailPremiumPrice";
		} catch(Exception e){
				log.error(e.getMessage());
				HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
				return "error/503";
		}
	}

	@RequestMapping(value = "/getPremiummPriceDetail", method = { RequestMethod.GET, RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> getPremiummPriceDetail(@RequestBody PremiumSetPriceVO psVO, ModelMap model) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		//프리미엄 기준 정보
		PremiumStdrBasVO premiumStdrBasVO = ppms.getPremiumStdInfoByPremiumId(psVO.getPremiumId());
		map.put("premiumStdrBasVO", premiumStdrBasVO);

		List<PremiumSetPriceVO> getPrimiumlist = ppms.getSetPrimiumLivePriceDetailList(psVO);
		map.put("dataList", getPrimiumlist);

		return map;
	}

	@RequestMapping(value = "/getPremiummFixPriceDetail", method = { RequestMethod.GET, RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> getPremiummFixPriceDetail(@RequestBody PremiumSetPriceVO psVO, ModelMap model) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		//프리미엄 기준 정보
		PremiumStdrBasVO premiumStdrBasVO = ppms.getPremiumStdInfoByPremiumId(psVO.getPremiumId());
		map.put("premiumStdrBasVO", premiumStdrBasVO);  //프리미엄 기준정보
		
		psVO.setValidBeginDt(premiumStdrBasVO.getValidBeginDt());
		List<PremiumSetPriceVO> dataList = ppms.getSetPrimiumFixPriceDetailList(psVO);
		map.put("dataList", dataList);

		return map;
	}
	@PostMapping(value = "/duplicateCheckAjax")
	@ResponseBody
	public int duplicateCheckAjax(@RequestBody PremiumSetPriceVO vo) throws Exception {
		return ppms.duplicateCheckAjax(vo);
	}
	
	/*
	 * @PostMapping(value = "/insertAndUpdateAjaxList")
	 * 
	 * @ResponseBody public ResponseEntity<?>
	 * insertAndUpdateWrtmStdrAjaxList(@RequestBody PremiumSetPriceVO vo,
	 * BindingResult bindingResult) throws Exception { Map<String, Object> retVal =
	 * new HashMap<String, Object>();
	 * 
	 * int dupCnt = ppms.duplicateCheckAjax(vo); if(dupCnt > 0) { return new
	 * ResponseEntity<>(retVal, HttpStatus.BAD_REQUEST); } return new
	 * ResponseEntity<>(retVal, HttpStatus.OK); }
	 */

	/**
	 * <pre>
	 * 처리내용: 프리미엄에 대한 중복 체크
	 * </pre>
	 * @date 2021. 6. 28.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param psVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/premiumdDuplicateCheckAjax", method = { RequestMethod.POST })
	@ResponseBody
	public String PremiumdDuplicateCheckAjax(@RequestBody PremiumStdrBasVO vo) throws Exception {
		//return new ResponseEntity<>(map, HttpStatus.OK);
		return ppms.premiumdDuplicateCheck(vo);
	}


	/**
	 * <pre>
	 * 처리내용: 프리미엄가격 추가
	 * </pre>
	 * @date 2021. 6. 28.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param psVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/insertPremiumAjax", method = { RequestMethod.POST })
	@ResponseBody
	public ResponseEntity<?> insertPremiumAjax(@RequestBody PremiumStdrBasVO vo, BindingResult bindingResult) throws Exception {
		customValidator.validate(vo, bindingResult, PremiumStdrBasVO.InsertAndUpdate.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			 return new ResponseEntity<>(bindingResult.getAllErrors(),
			 HttpStatus.BAD_REQUEST);
		}
		
		String result = ppms.insertPremiumPrice(vo);
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 프리미엄가격 업데이트
	 * </pre>
	 * @date 2021. 6. 28.
	 * @author srec0031
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param psVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/updatePremiumAjax", method = { RequestMethod.POST })
	@ResponseBody
	public ResponseEntity<?> updatePremiumAjax(@RequestBody PremiumStdrBasVO vo, BindingResult bindingResult) throws Exception {
		customValidator.validate(vo, bindingResult, PremiumStdrBasVO.InsertAndUpdate.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			 return new ResponseEntity<>(bindingResult.getAllErrors(),
			 HttpStatus.BAD_REQUEST);
		}
		String result = ppms.updatePremiumPrice(vo);
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	@RequestMapping(value = "/selectPremiumDetailProfitAndLoseAjax", method = { RequestMethod.POST })
	public String selectPremiumDetailProfitAndLoseAjax(@RequestBody PremiumStdrBasVO vo,  ModelMap model) {
		try {
			//Map<String, String> metalCode = commonCodeService.getFilterCode("METAL_CODE",null,"CODE_DCTWO","Y").get;
			String metalNm = commonCodeService.getCodeValue("METAL_CODE", vo.getMetalCode());

			model.put("itmSn", vo.getItmSn());
			model.put("dspyGoodsNm", vo.getDspyGoodsNm());                   //아이템 전시상품명
			model.put("metalNm", metalNm);                                    //금속 이름
			model.put("metalCode", vo.getMetalCode());                                    //금속 코드
			model.put("ehgtPc", vo.getStdrEhgtPc());                                    //환율
			model.put("premiumStdrAmountKrw", vo.getPremiumStdrAmountKrw());  //프리미엄 기준금액 (KRW)
			model.put("lmeEvalCash", ppms.getOneDayAgoLmeEvalCash().getEndPc());                        //전일 LME_EVAL_CASH
			model.put("premiumId", vo.getPremiumId());                        //프리미엄 아이디
			return "it/premiumPriceModal.modal";
		} catch(Exception e){
				log.error(e.getMessage());
				HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
				return "error/503";
		}
	}


	@RequestMapping(value = "/selectPremiumDetailProfitAndLoseAjax2", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> selectPremiumDetailProfitAndLoseAjax2(@RequestBody PremiumDetailProfitAndLoseVO vo,  ModelMap model) throws Exception {

		Map<String, Object> map = new HashMap<>();
		List<PremiumMonFxEvaluationCashVO> evaluationCash6MonList = ppms.get6FxMonEvalutaion();  //하나 FX 선물환 6개월
		List<PremiumDetailProfitAndLoseVO> profitAndLoseList = ppms.getPremiumDetailProfitAndLoseUpdate(vo);  //BL정보 조회

		Calendar c1 = new GregorianCalendar();
		c1.add(Calendar.DATE, -1); // 오늘날짜로부터 -1
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd"); // 날짜 포맷
		String yesterDay = sdf.format(c1.getTime()); // String으로 저장
		LmePcVO lmePcVO = pcInfoService.getPrLme(vo.getMetalCode(), yesterDay, "DD");  //LME정보 조회

		//PO 선물환 만기 일자, 하나 FX선물환 날짜 비교후 값 설정
		for(int i = 0; i <profitAndLoseList.size(); i++) {
			for(int j = 0; j < evaluationCash6MonList.size(); j++) {
				if(profitAndLoseList.get(i).getFtrsExprtnDe() != null && evaluationCash6MonList.get(j).getValDt() != null) {
					String from = profitAndLoseList.get(i).getFtrsExprtnDe();
					SimpleDateFormat transFormat = new SimpleDateFormat("yyyyMMdd");
					Date exprtnDe = transFormat.parse(from);  //만기일

					Calendar calendar= Calendar.getInstance();
					calendar.setTime(exprtnDe);
					int dayOfMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
					calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

					BigDecimal askPrRatio1 = evaluationCash6MonList.get(j).getFarAsk() == null ? new BigDecimal("0") : evaluationCash6MonList.get(j).getFarAsk();
					BigDecimal askPrRatio2 = profitAndLoseList.get(i).getEhgtPc() == null ? new BigDecimal("0") : profitAndLoseList.get(i).getEhgtPc();

					if(askPrRatio2 != new BigDecimal("0")) {
						profitAndLoseList.get(i).setPurchsSpreadDollarPc(askPrRatio1.divide(askPrRatio2));   	 //워드문서 0.27의 값
					}
					break;
				} else {
					profitAndLoseList.get(i).setPurchsSpreadDollarPc(new BigDecimal("0"));
				}
			}

			if(profitAndLoseList.get(i).getFtrsDollarFee() != null) {
				BigDecimal purchsDollarFee;
				if(lmePcVO != null ) {
					purchsDollarFee = lmePcVO.getThreemonthEndPc().multiply(new BigDecimal("4")).divide(new BigDecimal("6400"));
					profitAndLoseList.get(i).setPurchsDollarFee(purchsDollarFee);
				}
			} else {
				profitAndLoseList.get(i).setPurchsDollarFee(new BigDecimal("0"));
			}

		}
		map.put("profitAndLoseList", profitAndLoseList);
		return map;

	}

	public String currentAddSecondDate(int Second) {


		String retDt = null;
		Date date = new Date();
		// 포맷변경 ( 년월일 시분초)
		SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		//초 더하기
		cal.add(Calendar.SECOND, Second);

		retDt = sdFormat.format(cal.getTime());
		return retDt;
	}

	@RequestMapping(value = "/getEndPc", method = { RequestMethod.POST })
	@ResponseBody
	public String getEndPcAjax(PremiumStdrBasVO vo, ModelMap model) throws Exception {
		//당일 최초 환율
		PrEhgtPcRltmBasVO prEhgtPcRltmBasVO = new PrEhgtPcRltmBasVO();
		prEhgtPcRltmBasVO = ppms.getprEhgtPcFirstByToday();
		return prEhgtPcRltmBasVO.getEndPc() == null ? new BigDecimal("0").toString() : prEhgtPcRltmBasVO.getEndPc().toString();
	}
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 다이나믹 핸들링 화면을 조회한다.
	 * </pre>
	 * @date 2023. 10. 16.
	 * @author hanjook
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 16.		hanjook				최초작성
	 * ------------------------------------------------
	 * @param PremiumStdrBasVO
	 * @param model
	 * @return
	 * @throws Exception
	*/
	@RequestMapping("/selectDynamicHandle")
	public String selectDynamicHandle(@RequestBody PremiumStdrBasVO premiumStdrBasVO, ModelMap model) throws Exception {
		PremiumStdrBasVO premList = ppms.getSelectedPremium(premiumStdrBasVO);
		String endPc = ppms.getEhgtPcRltm();
		model.addAttribute("premList",premList);
		model.addAttribute("endPc",endPc);
		return "it/premiumPriceMngDynmModal.modal";
	}
	

	/**
	 * <pre>
	 * 처리내용: 다이나믹 프리미엄 저장
	 * </pre>
	 *
	 * @date 2023. 10. 17.
	 * @author jdrttl
	 * @history
	 * ------------------------------------------------
	 * 변경일           작성자        변경내용
	 * ------------------------------------------------
	 * 2023. 10. 17.  jdrttl       최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */	
	@PostMapping("/savePremiumDynmPrice")
	@ResponseBody
	public ResponseEntity<Object> savePremiumDynmPrice(@RequestBody PremiumStdrBasVO premiumStdrBasVO) throws Exception {
		String result = "";
		try {
			result = ppms.savePremiumDynmPrice(premiumStdrBasVO);
			
			return new ResponseEntity<>(result, HttpStatus.OK);
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>("다이나믹 프라이싱 적용중 오류가 발생했습니다. 관리자에게 문의하십시오.", HttpStatus.BAD_REQUEST);
		}
	}


}
