package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;

import com.sorincorp.bo.it.model.FixPriceVO;
import com.sorincorp.bo.it.service.FixPriceService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;


/**
 * FixPriceMngController.java
 * @version
 * @since 2021. 7. 19.
 * @author thjeong
 */
@Slf4j
@Controller
@RequestMapping("/it/fixPriceMng")
public class FixPriceMngController {
	@Autowired
	FixPriceService fixService;
	@Autowired
	private CommonCodeService ccs;
	@Autowired
	private ItemCodeService itemCodeService;


	/**
	 * <pre>
	 * 처리내용: 고정가 구매원가 관리 화면 보여준다.
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author thjeong
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 19.			thjeong				최초작성
	 * ------------------------------------------------
	 * @return "it/FixPrice.tiles"
	 * @throws Exception
	 */
	@RequestMapping(value="/selectList")
	public String selectFixPriceList(ModelMap model) {
		try {
			Map<String, CommonCodeVO> metalCodeVo = ccs.getMultiFilterCodeRetVo("METAL_CODE",null,	//MAIN_CODE가 "METAL_CODE"인 공통 코드
					  "CODE_DCTWO","Y", null, null	//CODE_DCTWO(코드 설명2, EC 판매 대상 여부)가 Y인 METAL_CODE
					, "CODE_CHRCTR_REFRNTHREE", "1", "1", "2");	//CODE_CHRCTR_REFRNTHREE(코드 문자 참조3, 판매비트)의 두번째 값(고정가)이 1(TRUE)인 METAL_CODE

			List<CommonCodeVO> metalCodeList = metalCodeVo.values().stream().collect(Collectors.toList());

			model.put("metalCode", metalCodeList);
			return "it/fixPriceMng";
		} catch(Exception e){
				log.error(e.getMessage());
				HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
				return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 고정가 구매원가 관리 목록을 조회한다.
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author thjeong
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 19.			thjeong			최초작성
	 * ------------------------------------------------
	 * @param  fixPriceVo
	 * @throws Exception
	 */
	@RequestMapping(value="/selectAjaxList")
	@ResponseBody
	public Map<String,Object> selectSidecarAjaxList(@RequestBody FixPriceVO FixPriceVO) throws Exception {
		Map<String,Object> map = new HashMap<String, Object>();
		List<FixPriceVO> FixPriceList = fixService.selectListFixPrice(FixPriceVO);
		map.put("dataList", FixPriceList);
		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 서브코드 그리드의 정보를 조회한다.
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author thjeong
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 19.			thjeong 			최초작성
	 * ------------------------------------------------
	 * @param fixPriceVo
	 * @return map
	 * @throws Exception
	 */
	@PostMapping("/selectSubcodeList")
	@ResponseBody
	public Map<String,Object> selectSubcodeList(@RequestBody FixPriceVO fixPriceVO) throws Exception {

		Map<String,Object> map = new HashMap<String, Object>();

		//선물처리 여부 'N'인 메탈 불러온다.
		fixPriceVO.setItmSnList(itemCodeService.getItemFtrsProcessAtCodeList(fixPriceVO.getMetalCode(), "N"));

		//선물처리 여부 N인 메탈에대한 고정가 불러온다.
		//if(fixPriceVO.getItmSnList().size() > 0) {
			List<FixPriceVO> codeList = fixService.selectFixPriceSubCodeList(fixPriceVO);
			map.put("dataList", codeList);
		//}

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 그리드 목록을 저장한다.
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author thjeong
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 19.			thjeong				최초작성
	 * ------------------------------------------------
	 * @param  fixPriceVo
	 * @throws Exception
	 */
	/*
	@PostMapping(value="/insertAndUpdateCodeList")
	@ResponseBody
	public ResponseEntity<?> insertAndUpdateCodeList(@RequestBody List<FixPriceVO> FixPriceVOList, BindingResult bindingResult, SessionStatus status) throws Exception {
		//개장시간 체크
		for(FixPriceVO vo : FixPriceVOList) {
			//유효성 검사
			//매달 첫날짜의 개장일 전인지 체크
			List<BsnManageBasVO> bsnManageBas = fixService.beginValidation();
//			if(bsnManageBas != null && bsnManageBas.size() > 0) {
//				if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), bsnManageBas.get(0).getApplcDe()) > 0){
//					return new ResponseEntity<>("매월 첫영업일 개장시간 전의 데이터만 수정/등록 가능합니다.", HttpStatus.BAD_REQUEST);
//				}
//			}
			//날짜1이 날짜2와 동일하다면 0, 날짜1이 크다면 음수, 날짜2가 크다면 양수
			//이전달 수정 불가
            if (Integer.parseInt(DateUtil.getNowDate().toString().substring(0,6)) > Integer.parseInt(vo.getApplcYm())) {
            	return new ResponseEntity<>("이전달은 수정/등록 불가능 합니다.", HttpStatus.BAD_REQUEST);
            }
		}

		fixService.insertAndUpdateFixPriceMng(FixPriceVOList);
		status.setComplete();
		return new ResponseEntity<>(HttpStatus.OK);

	}
	*/

	/**
	 * <pre>
	 * 처리내용: 그리드 목록을 저장한다.
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author thjeong
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 19.			thjeong				최초작성
	 * 2021. 7. 22.			thjeong				추가수정
	 * ------------------------------------------------
	 * @param  fixPriceVo
	 * @throws Exception
	 */
	/*
	@PostMapping(value="/insertAndUpdateSubCodeList")
	@ResponseBody
	public ResponseEntity<?> insertAndUpdateSubCodeList(@RequestBody List<FixPriceVO> FixPriceVOList, BindingResult bindingResult, SessionStatus status) throws Exception {
		//개장시간 체크
		for(FixPriceVO vo : FixPriceVOList) {
			//유효성 검사
			//매달 첫날짜의 개장일 전인지 체크
			List<BsnManageBasVO> bsnManageBas = fixService.beginValidation();
//			if(bsnManageBas != null && bsnManageBas.size() > 0) {
//				if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), bsnManageBas.get(0).getApplcDe()) > 0){
//					return new ResponseEntity<>("매월 첫영업일 개장시간 전의 데이터만 수정/등록 가능합니다.", HttpStatus.BAD_REQUEST);
//				}
//			}
			//날짜1이 날짜2와 동일하다면 0, 날짜1이 크다면 음수, 날짜2가 크다면 양수
			//이전달 수정 불가
            if (Integer.parseInt(DateUtil.getNowDate().toString().substring(0,6)) > Integer.parseInt(vo.getApplcYm())) {
            	return new ResponseEntity<>("이전달은 수정/등록 불가능 합니다.", HttpStatus.BAD_REQUEST);
            }
		}

		fixService.insertAndUpdateFixPriceSubMng(FixPriceVOList);
		status.setComplete();
		return new ResponseEntity<>(HttpStatus.OK);

	}
	*/


	@PostMapping(value="/insertAndUpdateCodeAndSubCodeList")
	@ResponseBody
	public String insertAndUpdateCodeAndSubCodeList(@RequestBody List<FixPriceVO> fixPriceVOList, BindingResult bindingResult, SessionStatus status) throws Exception {
		//개장시간 체크
		for(FixPriceVO vo : fixPriceVOList) {
			//유효성 검사
			//매달 첫날짜의 개장일 전인지 체크
//			List<BsnManageBasVO> bsnManageBas = fixService.beginValidation();
//			if(bsnManageBas != null && bsnManageBas.size() > 0) {
//				if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), bsnManageBas.get(0).getApplcDe()) > 0){
//					return new ResponseEntity<>("매월 첫영업일 개장시간 전의 데이터만 수정/등록 가능합니다.", HttpStatus.BAD_REQUEST);
//				}
//			}
			//날짜1이 날짜2와 동일하다면 0, 날짜1이 크다면 음수, 날짜2가 크다면 양수
			//이전달 수정 불가
            if (Integer.parseInt(DateUtil.getNowDate().toString().substring(0,6)) > Integer.parseInt(vo.getApplcYm())) {
            	return "이전달은 수정/등록 불가능 합니다.";
            }
		}
		fixService.insertAndUpdateCodeAndSubCodeList(fixPriceVOList);
		return "저장되었습니다.";
	}
	
	/**
	 * <pre>
	 * 처리내용: 선택한 월을 삭제한다.
	 * </pre>
	 * @date 2022. 10. 28.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 28.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param fixPriceVo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/deleteMon")
	public String deleteMon(@RequestBody List<FixPriceVO> fixPriceVOList) throws Exception {
		try {
			fixService.deleteMon(fixPriceVOList);
			return "it/fixPriceMng";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}		
	}
	
}
