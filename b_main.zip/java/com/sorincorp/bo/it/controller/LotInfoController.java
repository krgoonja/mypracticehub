package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.it.model.LotInfoVO;
import com.sorincorp.bo.it.service.LotInfoService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/it")
public class LotInfoController {

	@Autowired
	private LotInfoService lotInfoService;

	@RequestMapping("/selectLotInfo")
	public String selectLotInfo(@RequestBody LotInfoVO lotInfoVO, ModelMap model) throws Exception {
		try {
			log.debug("blNo ==================>" + lotInfoVO.getBlNo());

//			List<LotInfoVO> lotInfoList = lotInfoService.selectLotInfoList(lotInfoVO);
//			model.addAttribute("lotInfoList", lotInfoList);

			model.addAttribute("blNo", lotInfoVO.getBlNo());

			return "it/lotInfo.modal";
		} catch(Exception e){
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectLotInfoListAjax")
	@ResponseBody
	public ResponseEntity<Object> selectLotInfoListAjax(@RequestBody LotInfoVO lotInfoVO, BindingResult bindingResult)
			throws Exception {

		List<LotInfoVO> lotInfoList = lotInfoService.selectLotInfoList(lotInfoVO);
		List<LotInfoVO> wrhousngList = lotInfoService.selectWrhousngList(lotInfoVO);
		List<LotInfoVO> ovsiteList = lotInfoService.selectOvsiteList(lotInfoVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("lotInfoList", lotInfoList);
		map.put("wrhousngList", wrhousngList);
		map.put("ovsiteList", ovsiteList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}
}
