package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.BrandMgrVO;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.service.BrandMgrService;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;


/**
 * ItemMgrController.java
 * @version
 * @since 2021. 6. 14.
 * @author srec0030
 */
@Slf4j
@Controller
@RequestMapping("/bo/it")
public class BrandMgrController {

	@Autowired
	private BrandMgrService brandMgrService;
	@Autowired
	private ItCmnCodeService itCmnCodeService;
	@Autowired
	private CustomValidator customValidator;
	@Autowired
	private UserInfoUtil userInfoUtil;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	/** ITEM_INVNTRY_SETUP
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectBrandMgrList")
	public String selectBrandMgrList(ModelMap model) {
		try {
			ItCmnCodeVO vo = new ItCmnCodeVO();
			vo.setMainCode("METAL_CODE");
//			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);

			vo.setMainCode("NATION_CODE");
//			vo.setCodeDctwo(null);
			vo.setUseAt("Y");
			List<ItCmnCodeVO> nationCodeList = itCmnCodeService.selectCmnCodeList(vo);

			vo.setMainCode("BRAND_GROUP_CODE");
//			vo.setCodeDctwo(null);
			vo.setUseAt("Y");
			List<ItCmnCodeVO> brandGroupCodeList = itCmnCodeService.selectCmnCodeList(vo);

			model.addAttribute("metalCodeList", metalCodeList);
			model.addAttribute("nationCodeList", nationCodeList);
			model.addAttribute("brandGroupCodeList", brandGroupCodeList);

			return "it/brandMgrList";
		} catch(Exception e){
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectBrandMgrListAjax")
	@ResponseBody
	public ResponseEntity<Object> selectBrandMgrListAjax(@RequestBody BrandMgrVO brandMgrVO, BindingResult bindingResult)
			throws Exception {

		customValidator.validate(brandMgrVO, bindingResult, BrandMgrVO.Search.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			//return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		List<BrandMgrVO> itemMgrList = brandMgrService.selectBrandMgrList(brandMgrVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalDataCount", brandMgrService.selectBrandMgrTotalCnt(brandMgrVO));
		map.put("dataList", itemMgrList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}


	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandMgrVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/brandMgrSpecDetail")
	public String selectBrandMgrSpecDetail(@RequestBody BrandMgrVO brandMgrVO, ModelMap model)
			throws Exception {

		ItCmnCodeVO vo = new ItCmnCodeVO();

		vo.setMainCode("METAL_CODE");
		vo.setUseAt("Y");
		List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);
		vo.setMainCode("ITM_SPEC_OPTN_CODE");
		vo.setUseAt("Y");
		List<ItCmnCodeVO> specOtpnList = itCmnCodeService.selectCmnCodeList(vo);

		model.addAttribute("metalCodeList", metalCodeList);
		model.addAttribute("specOtpnList", specOtpnList);
		model.addAttribute("brandCode", brandMgrVO.getBrandCode());

		return "it/brandMgrSpecDetail.modal";
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectSpecDetailListAjax")
	@ResponseBody
	public ResponseEntity<Object> selectSpecDetailListAjax(@RequestBody BrandMgrVO brandMgrVO, BindingResult bindingResult)
			throws Exception {

		customValidator.validate(brandMgrVO, bindingResult, BrandMgrVO.Search.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			//return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		List<BrandMgrVO> specDetailList = brandMgrService.selectSpecDetailList(brandMgrVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("dataList", specDetailList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandMgrVO
	 * @param model
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/updateBrandMgr")
	@ResponseBody
	public ResponseEntity<Object> updateBrandMgr(@RequestBody BrandMgrVO brandMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(brandMgrVO, bindingResult, BrandMgrVO.InsertAndUpdate.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = 0;
		//log.debug(brandMgrVO.toString());
		//브랜드관리 update
		result = brandMgrService.updateBrandData(brandMgrVO.getBrandSaveList());

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandMgrVO
	 * @param model
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/saveBrandSpecMgr")
	@ResponseBody
	public ResponseEntity<Object> saveBrandSpecMgr(@RequestBody BrandMgrVO brandMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result = 0;

		//브랜드스펙 상세 update
		result = brandMgrService.saveBrandSpecMgr(brandMgrVO.getBrandSpecSaveList());

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
}
