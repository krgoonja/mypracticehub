package com.sorincorp.bo.it.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.bd.model.BdFaqManageVO;
import com.sorincorp.bo.it.model.CdInrstVO;
import com.sorincorp.bo.it.model.TrdeStrdrRtVO;
import com.sorincorp.bo.it.service.CdInrstService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/it/cdInrst")
public class CdInrstController {
	
	@Autowired
	CdInrstService cdInrstService;
	
	/**
	 * <pre>
	 * 처리내용: cd금리 조회화면을 보여준다.
	 * </pre>
	 * @date 2022. 9. 16.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 16.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectCdInrstList")
	public String selectCdInrstList(ModelMap model) throws Exception {
		try {
			return "it/cdInrstList";
		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: cd금리 목록을 조회한다.
	 * </pre>
	 * @date 2022. 9. 16.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 16.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param civo
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/selectCdInrstListData")
	public Map<String,Object> selectCdInrstListData(@RequestBody CdInrstVO civo) throws Exception {
		Map<String,Object> map = new HashMap<String, Object>();
		int totalDataCount        = cdInrstService.selectCntCdInrstListData(civo);
		List<CdInrstVO> dataList = cdInrstService.selectCdInrstListData(civo);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", dataList);
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: cd금리 목록을 엑셀로 다운한다.
	 * </pre>
	 * @date 2022. 9. 16.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 16.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectCdInrstListDataForExcel")
	public ResponseEntity<?> selectCdInrstListDataForExcel(@RequestBody CdInrstVO searchVO) throws Exception {
		searchVO.setRecordCountPerPage(10000000);
		List<CdInrstVO> dataList = cdInrstService.selectCdInrstListData(searchVO);

		Map<String,Object> map = new HashMap<String, Object>();
		map.put("dataList", dataList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 차트를 위해 cd금리 목록을 조회한다.
	 * </pre>
	 * @date 2022. 10. 4.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 4.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param civo
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/selectForChartCdListData")
	public Map<String,Object> selectForChartCdListData(@RequestBody CdInrstVO civo) throws Exception {
		Map<String,Object> map = new HashMap<String, Object>();
		int totalDataCount        = cdInrstService.selectCntCdInrstListData(civo);
		List<CdInrstVO> dataList = cdInrstService.selectForChartCdListData(civo);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", dataList);
		return map;
	}
	

}
