package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.it.model.WrtmStdrAmoutMangeVO;
import com.sorincorp.bo.it.service.WrtmStdrAmoutMangeService;
import com.sorincorp.bo.mb.service.MbInvtInclnGradMngService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * WrtmStdrAmoutMangeController.java
 * @version
 * @since 2022. 7. 5.
 * @author srec0064
 */
@Slf4j
@Controller
@RequestMapping("/it/wrtmStdrAmout")
public class WrtmStdrAmoutMangeController {
	
	@Autowired
	private WrtmStdrAmoutMangeService wrtmStdrAmoutMangeService;
	
	@Autowired
	private MbInvtInclnGradMngService mbInvtInclnGradMngService;
	
	@Autowired
	private CustomValidator customValidator;
	
	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";
	
	
	/**
	 * <pre>
	 * 처리내용: 증거금 기준금액 관리 페이지를 로드한다.
	 * </pre>
	 * @date 2022. 7. 6.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 6.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/selectList", method = RequestMethod.GET)
	public String wrtmStdrAmoutMange(ModelMap model) {
		try {			
			return "it/wrtmStdrAmoutMangeList";
		} catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 증거금 기준금액 관리 목록을 조회한다.
	 * </pre>
	 * @date 2022. 7. 6.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 6.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param wrtmStdrAmoutMangeVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getWrtmStdrAmoutMangeList", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> getWrtmStdrAmoutMangeList(@RequestBody WrtmStdrAmoutMangeVO wrtmStdrAmoutMangeVO) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		List<WrtmStdrAmoutMangeVO> wrtmStdrAmoutMangeList = wrtmStdrAmoutMangeService.getWrtmStdrAmoutMangeList(wrtmStdrAmoutMangeVO);
		int totalCnt = wrtmStdrAmoutMangeService.selectWrtmStdrAmoutMangeCnt(wrtmStdrAmoutMangeVO);

		map.put("dataList", wrtmStdrAmoutMangeList);
		map.put("totalDataCount", totalCnt);
		return map;
	}
	
	@RequestMapping(value = "/insertWrtmStdrAmoutMange", method = { RequestMethod.GET, RequestMethod.POST })
	public String insertWrtmStdrAmoutMange(ModelMap model) {
		try {
			model.addAttribute("mbInvtInclnGradMngList", mbInvtInclnGradMngService.selectMbInvtInclnGradMngList());
			model.addAttribute("status", "insert");
			
			return "it/insertWrtmStdrAmoutMange";
		} catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	
	
	@RequestMapping(value = "/updateWrtmStdrAmoutPage", method = { RequestMethod.GET, RequestMethod.POST })
	public String updateWrtmStdrAmoutPage(WrtmStdrAmoutMangeVO wrtmStdrAmoutMangeVO, ModelMap model) {
		try {
			model.addAttribute("wrtmStdrSn", wrtmStdrAmoutMangeVO.getWrtmStdrSn());
			model.addAttribute("mbInvtInclnGradMngList", wrtmStdrAmoutMangeService.getItWrtmStdrAmoutMangeBas(wrtmStdrAmoutMangeVO));
			model.addAttribute("status", "update");
			
			return "it/updateWrtmStdrAmoutMange";
		} catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	
	@PostMapping(value = "/duplicateCheckAjax")
	@ResponseBody
	public int duplicateCheckAjax(@RequestBody WrtmStdrAmoutMangeVO wrtmStdrAmoutMangeVO) throws Exception {
		return wrtmStdrAmoutMangeService.duplicateCheckAjax(wrtmStdrAmoutMangeVO);
	}

	@PostMapping(value = "/insertAndUpdateAjaxList")
	@ResponseBody
	public ResponseEntity<?> insertAndUpdateWrtmStdrAjaxList(@RequestBody WrtmStdrAmoutMangeVO wrtmStdrAmoutMangeVO, BindingResult bindingResult) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		
		if("insert".equals(wrtmStdrAmoutMangeVO.getStatus())) {
			int dupCnt = wrtmStdrAmoutMangeService.duplicateCheckAjax(wrtmStdrAmoutMangeVO);
			if(dupCnt > 0) {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "중복된 데이터가 존재 합니다.");
				return new ResponseEntity<>(retVal, HttpStatus.BAD_REQUEST);
			}
		}
		
		if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), wrtmStdrAmoutMangeVO.getApplcDe().replace("-", "")) > 0) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "적용일자는 오늘 이후로만 설정할 수 있습니다.");
        	return new ResponseEntity<>(retVal, HttpStatus.BAD_REQUEST);
        }
		
		customValidator.validate(wrtmStdrAmoutMangeVO, bindingResult);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		String wrtmStdrSn = wrtmStdrAmoutMangeService.insertAndUpdateWrtmStdrAjaxList(wrtmStdrAmoutMangeVO);
		
		retVal.put("wrtmStdrSn", wrtmStdrSn);
		retVal.put(RESULT, SUCCESS);
		retVal.put(ERRMSG, "");
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
	
	@PostMapping(value = "/updateWrtmStdrAmoutAjax")
	@ResponseBody
	public ResponseEntity<?> updateWrtmStdrAmoutAjax(@RequestBody WrtmStdrAmoutMangeVO wrtmStdrAmoutMangeVO) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		
		if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), wrtmStdrAmoutMangeVO.getApplcDe().replace("-", "")) > 0) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "적용일자는 오늘 이후로만 설정할 수 있습니다.");
        	return new ResponseEntity<>(retVal, HttpStatus.BAD_REQUEST);
        }
		
		wrtmStdrAmoutMangeService.updateWrtmStdrAjaxList(wrtmStdrAmoutMangeVO);
		
		retVal.put(RESULT, SUCCESS);
		retVal.put(ERRMSG, "");
		
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getItWrtmStdrAmoutMangeDtlList", method = { RequestMethod.POST })
	@ResponseBody
	public Map<String, Object> getItWrtmStdrAmoutMangeDtlList(@RequestBody WrtmStdrAmoutMangeVO wrtmStdrAmoutMangeVO) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("wrtmStdrAmoutMangeBasData", wrtmStdrAmoutMangeService.getItWrtmStdrAmoutMangeBas(wrtmStdrAmoutMangeVO));
		map.put("wrtmStdrAmoutMangeDtlList", wrtmStdrAmoutMangeService.getItWrtmStdrAmoutMangeDtlList(wrtmStdrAmoutMangeVO));
		return map;
	}
	
	@PostMapping(value = "/deleteWrtmStdrAmoutAjax")
	@ResponseBody
	public ResponseEntity<?> deleteWrtmStdrAmoutAjax(@RequestBody WrtmStdrAmoutMangeVO wrtmStdrAmoutMangeVO) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();

		wrtmStdrAmoutMangeService.deleteWrtmStdrAmoutAjax(wrtmStdrAmoutMangeVO);
		
		retVal.put(RESULT, SUCCESS);
		retVal.put(ERRMSG, "");
		
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
	
}



