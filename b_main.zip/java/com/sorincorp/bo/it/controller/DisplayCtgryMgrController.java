package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.DisplayCtgryMgrVO;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.model.ItemMgrVO;
import com.sorincorp.bo.it.service.DisplayCtgryMgrService;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/it")
public class DisplayCtgryMgrController {

	@Autowired
	private ItCmnCodeService itCmnCodeService;
	@Autowired
	private DisplayCtgryMgrService displayCtgryMgrService;
	@Autowired
	private CustomValidator customValidator;
	@Autowired
	private UserInfoUtil userInfoUtil;
	@Autowired
	CommonCodeService commonCodeService;

	private static String RESULT = "result";
	private static String CATEGORYNO = "categoryNo";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	/**
	 * <pre>
	 * 처리내용: 전시카테고리 관리화면으로 이동한다.
	 * </pre>
	 * @date 2021. 7. 6.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 6.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectDisplayCtgryMgr")
	public String selectDisplayCtgryMgr(ModelMap model) {
		try {
			ItCmnCodeVO vo = new ItCmnCodeVO();
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			//공통코드 메탈코드 리스트를 조회한다.
			List<ItCmnCodeVO> itemCodeLIst = itCmnCodeService.selectCmnCodeList(vo);
			Map<String, String> sleMthdCode = commonCodeService.getSubCodes("SLE_MTHD_CODE"); // 판매코드
			sleMthdCode.remove("03"); //지정가 제외
			sleMthdCode.remove("05"); //가단가 제외
			model.addAttribute("selMthdCode", sleMthdCode); // 판매방식코드
			model.addAttribute("itemCodeLIst", itemCodeLIst); //메탈구분
			model.addAttribute("metalCodeLIst", itemCodeLIst);//금속분류코드
			model.addAttribute("metalClCodeList", commonCodeService.getSubCodesRetVo("METAL_CL_CODE"));
			return "it/displayCtrgryMgr";
		} catch(Exception e){
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 카테고리 정보를 조회한다.
	 * </pre>
	 * @date 2021. 7. 6.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 6.			srec0030			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectDisplayCtgryMgrAjax")
	@ResponseBody
	public ResponseEntity<Object> selectDisplayCtgryMgrAjax()
			throws Exception {
		//레벨1 카테고리 리스트 조회
		List<DisplayCtgryMgrVO> ctgryLv1List = displayCtgryMgrService.selectDisplayCtgryList(1);
		//레벨2 카테고리 리스트 조회
		List<DisplayCtgryMgrVO> ctgryLv2List = displayCtgryMgrService.selectDisplayCtgryList(2);
		//레벨3 카테고리 리스트 조회
		List<DisplayCtgryMgrVO> ctgryLv3List = displayCtgryMgrService.selectDisplayCtgryList(3);
//		List<DisplayCtgryMgrVO> ctgryLv4List = displayCtgryMgrService.selectDisplayCtgryList(4);


		Map<String, Object> map = new HashMap<String, Object>();
		map.put("ctgryLv1List", ctgryLv1List);
		map.put("ctgryLv2List", ctgryLv2List);
		map.put("ctgryLv3List", ctgryLv3List);
		//map.put("ctgryLv4List", ctgryLv4List);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectCtgryItemAjax")
	@ResponseBody
	public ResponseEntity<Object> selectCtgryItemAjax(@RequestBody ItemMgrVO itemMgrVO, BindingResult bindingResult)
			throws Exception {

		customValidator.validate(itemMgrVO, bindingResult, ItemMgrVO.Search.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		//log.debug("itemMgrVO.getCtgryNo() ====>" + itemMgrVO.getCtgryNo());
		List<ItemMgrVO> itemMgrList = displayCtgryMgrService.selectCtgryItemList(itemMgrVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalDataCount", itemMgrList.size());
		map.put("dataList", itemMgrList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 카테고리 정보를 수정하거나 신규등록한다.
	 * </pre>
	 * @date 2021. 7. 6.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 6.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @param model
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/updateDisplayCtgryMgr")
	@ResponseBody
	public ResponseEntity<Object> updateDisplayCtgryMgr(@RequestBody DisplayCtgryMgrVO displayCtgryMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(displayCtgryMgrVO, bindingResult, DisplayCtgryMgrVO.Update.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = 0;

		//log.debug(displayCtgryMgrVO.toString());
		//카테고리 insert and update
		result = displayCtgryMgrService.updateDisplayCtgryMgr(displayCtgryMgrVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(CATEGORYNO, result);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@Transactional
	@RequestMapping("/deleteDisplayCtgryMgr")
	@ResponseBody
	public ResponseEntity<Object> deleteDisplayCtgryMgr(@RequestBody DisplayCtgryMgrVO displayCtgryMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(displayCtgryMgrVO, bindingResult, DisplayCtgryMgrVO.Delete.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = 0;

		//log.debug(displayCtgryMgrVO.toString());
		//카테고리 insert and update
		result = displayCtgryMgrService.deleteDisplayCtgryMgr(displayCtgryMgrVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 카테고리 정보에 아이템순번을 매핑한다.
	 * </pre>
	 * @date 2021. 7. 6.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 6.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @param model
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/insertCtgryRls")
	@ResponseBody
	public ResponseEntity<Object> insertCtgryRls(@RequestBody DisplayCtgryMgrVO displayCtgryMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(displayCtgryMgrVO, bindingResult, DisplayCtgryMgrVO.InsertAndUpdate.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			//return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = 0;

		//log.debug(displayCtgryMgrVO.toString());

		result = displayCtgryMgrService.insertCtgryRls(displayCtgryMgrVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "이미 추가된 아이템입니다.");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 카테고리정보에 매핑된 아이템순번의 매핑을 삭제한다.
	 * </pre>
	 * @date 2021. 7. 6.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 6.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @param model
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/deleteCtgryRls")
	@ResponseBody
	public ResponseEntity<Object> deleteCtgryRls(@RequestBody DisplayCtgryMgrVO displayCtgryMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(displayCtgryMgrVO, bindingResult, DisplayCtgryMgrVO.InsertAndUpdate.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			//return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = 0;

		//log.debug(displayCtgryMgrVO.toString());

		result = displayCtgryMgrService.deleteCtgryRls(displayCtgryMgrVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "삭제할 아이템이 없습니다.");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param displayCtgryMgrVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/displayCtgryMgrSearchItem")
	public String displayCtgryMgrSearchItem(@RequestBody DisplayCtgryMgrVO displayCtgryMgrVO, ModelMap model)
			throws Exception {
		//log.debug("displayCtgryMgrVO.getCtgryNo() =====>" + displayCtgryMgrVO.getCtgryNo());

		ItCmnCodeVO vo = new ItCmnCodeVO();
		vo.setMainCode("METAL_CODE");
		vo.setCodeDctwo("Y");
		vo.setUseAt("Y");
		//공통코드 메탈코드 리스트를 조회한다.
		List<ItCmnCodeVO> itemCodeLIst = itCmnCodeService.selectCmnCodeList(vo);
		model.addAttribute("itemCodeLIst", itemCodeLIst);
		model.addAttribute("ctgryNo", displayCtgryMgrVO.getCtgryNo());

		return "it/displayCtgryMgrSearchItem";
	}
	
	/**
	 * <pre>
	 * 처리내용: 전시카테고리괸리 모달 호출
	 * </pre>
	 * @date 2022. 11. 21.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 21.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param itemMgrVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/getDisplayCtgryMgrModal")
	public String popUpModal(@RequestBody DisplayCtgryMgrVO displayCtgryMgrVO, ModelMap model) throws Exception {
		try {
			ItCmnCodeVO vo = new ItCmnCodeVO();
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			//공통코드 메탈코드 리스트를 조회한다.
			List<ItCmnCodeVO> itemCodeLIst = itCmnCodeService.selectCmnCodeList(vo);
			model.addAttribute("itemCodeLIst", itemCodeLIst);
			model.addAttribute("ctgryNo", displayCtgryMgrVO.getCtgryNo());
			
		return "it/displayCtrgryMgrModal.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}
	@PostMapping("/isAlreadyRegisteredCtgry")
	@ResponseBody
	public boolean isAlreadyRegisteredCtgry(@RequestBody DisplayCtgryMgrVO displayCtgryMgrVO) throws Exception {
		return displayCtgryMgrService.isAlreadyRegisteredCtgry(displayCtgryMgrVO);
	}
}
