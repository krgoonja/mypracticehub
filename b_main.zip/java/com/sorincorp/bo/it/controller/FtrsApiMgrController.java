package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.LqdIntDatResVO;
import com.sorincorp.bo.it.service.FtrsApiMgrService;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.bo.pr.model.LmePriceInquiryVO;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 상품/전시관리 > 상품관리 > 선물환 API 관리
 * FtrsApiMgrController.java
 * @version
 * @since 2022. 1. 25.
 * @author srec0051
 */
@Slf4j
@Controller
@RequestMapping("/bo/it")
public class FtrsApiMgrController {

	@Autowired
	private FtrsApiMgrService ftrsApiMgrService;

	@Autowired
	private UserInfoUtil userInfoUtil;


	private Account getAccountInfo() throws Exception {
		Account account = Optional.ofNullable(userInfoUtil.getAccountInfo()).orElseThrow(() -> {
			return new Exception("로그인 정보를 확인해주세요");
		});
		return account;
	}

	/**
	 * <pre>
	 * 선물환 API 관리 페이지 조회
	 * </pre>
	 * @date 2022. 1. 25.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 25.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectFtrsApiMgrList")
	public String selectFtrsApiMgrList(ModelMap model) throws Exception {
//		log.debug("::: selectFtrsApiMgrList ");

		try {
			getAccountInfo();

			return "it/ftrsApiMgrList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 선물환 API 목록 조회
	 * </pre>
	 * @date 2022. 1. 25.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 25.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param unityOrderInqireVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectFtrsApiMgrListAjax")
	public ResponseEntity<?> selectFtrsApiMgrListAjax(@RequestBody LqdIntDatResVO lqdIntDatResVO) throws Exception {
//		log.debug("::: selectFtrsApiMgrListAjax");

		Map<String, Object> map = new HashMap<String, Object>();

		int totalDataCount = ftrsApiMgrService.getDataCount(lqdIntDatResVO);
		List<LqdIntDatResVO> dataList = ftrsApiMgrService.getDataList(lqdIntDatResVO);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", dataList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 선물환 관리페이지 다운로드 조회
	 * </pre>
	 * @date 2022. 09. 02.
	 * @author sumin95
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 09. 02.		sumin95			최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param LqdIntDatResVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value="/downloadFtrsApiMgrList")
	@ResponseBody
	public Map<String,Object> downloadFtrsApiMgrList(@RequestBody LqdIntDatResVO lqdIntDatResVO) throws Exception {
		
		Map<String,Object> map = new HashMap<String, Object>();
		
		List<LqdIntDatResVO> dataList = ftrsApiMgrService.getDataList(lqdIntDatResVO);

		map.put("dataList", dataList);

		return map;
	}


	
}
