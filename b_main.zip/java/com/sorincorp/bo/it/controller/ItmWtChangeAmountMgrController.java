package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.model.ItmWtChangeAmountMgrVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.bo.it.service.ItmWtChangeAmountMgrService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * ItmWtChangeAmountMgrController.java
 * 
 * @version
 * @since 2023. 6. 1.
 * @author srec0083
 */

@Slf4j
@Controller
@RequestMapping("/bo/it")
public class ItmWtChangeAmountMgrController {

	@Autowired
	private ItCmnCodeService itCmnCodeService;
	@Autowired
	private ItmWtChangeAmountMgrService itmWtChangeAmountMgrService;
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	/**
	 * 
	 * <pre>
	 * 처리내용: 아이템별 중량변동금 관리 목록을 조회한다.
	 * </pre>
	 * 
	 * @date 2023. 6. 1.
	 * @author srec0083
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 6. 1.
	 *          srec0083 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 */
	@RequestMapping("/selectItmWtChangeAmountMgrList")
	public String selectItmWtChangeAmountMgrList(ModelMap model) {
		try {

			ItCmnCodeVO vo = new ItCmnCodeVO();
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);

			model.addAttribute("metalCodeList", metalCodeList);

			return "it/itmWtChangeAmountMgrList";

		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}

	}

	/**
	 * 
	 * <pre>
	 * 처리내용: 아이템별 중량변동금 관리 그리드 데이터를 가져온다.
	 * </pre>
	 * 
	 * @date 2023. 6. 1.
	 * @author srec0083
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 6. 1.
	 *          srec0083 최초작성 ------------------------------------------------
	 * @param itmWtChangeAmountMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectItmWtChangeAmountMgrGridList")
	@ResponseBody
	public ResponseEntity<Object> selectItmWtChangeAmountMgrGridList(
			@RequestBody ItmWtChangeAmountMgrVO itmWtChangeAmountMgrVO) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();

		int itmWtChangeAmountMgrGridCount = itmWtChangeAmountMgrService
				.selectItmWtChangeAmountMgrGridCount(itmWtChangeAmountMgrVO);
		map.put("totalDataCount", itmWtChangeAmountMgrGridCount);

		if (itmWtChangeAmountMgrGridCount != 0) {
			log.debug("vo : " + itmWtChangeAmountMgrVO);
			List<ItmWtChangeAmountMgrVO> itmWtChangeAmount = itmWtChangeAmountMgrService
					.selectItmWtChangeAmountMgrGridList(itmWtChangeAmountMgrVO);
			map.put("dataList", itmWtChangeAmount);
		}

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * 
	 * <pre>
	 * 처리내용: 메탈 선택에 따른 아이템 리스트를 조회한다.
	 * </pre>
	 * 
	 * @date 2023. 6. 1.
	 * @author srec0083
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 6. 1.
	 *          srec0083 최초작성 ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/itmWtChangeAmountMgrGetCodeList")
	@ResponseBody
	public ResponseEntity<Object> itmWtChangeAmountMgrGetCodeList(@RequestParam(value = "metalCode") String metalCode) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("itemCodeList", itmWtChangeAmountMgrService.getItemCodeList(metalCode));

		return new ResponseEntity<>(map, HttpStatus.OK);

	
	}

	/**
	 * 
	 * <pre>
	 * 처리내용: 아이템별 중량 변동금 등록/수정 화면을 조회한다.
	 * </pre>
	 * @date 2023. 6. 2.
	 * @author srec0083
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 2.			srec0083			최초작성
	 * ------------------------------------------------
	 * @param itmWtChangeAmountMgrVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	 @RequestMapping("/selectItmWtChangeAmountMgrDetail") 
	 public String selectItmWtChangeAmountMgrDetail(@RequestBody ItmWtChangeAmountMgrVO itmWtChangeAmountMgrVO, ModelMap model) throws Exception {
	 
		 try {
			 ItCmnCodeVO vo = new ItCmnCodeVO();
			 vo.setMainCode("METAL_CODE");
			 vo.setCodeDctwo("Y");
			 vo.setUseAt("Y");
			 List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);
			 
			 model.addAttribute("metalCodeList", metalCodeList);
			 model.addAttribute("itmSn", itmWtChangeAmountMgrVO.getItmSn());
			 model.addAttribute("metalCode", itmWtChangeAmountMgrVO.getMetalCode());
			 
			 if(itmWtChangeAmountMgrVO.getModalPageStatus().equals("update")) {
				 model.addAttribute("gubun", "U");
			 }else {
				 model.addAttribute("gubun", "I"); 
			 }
			 
			 return "it/itmWtChangeAmountMgrDetail.modal";
			 
		 }catch (Exception e) {
				log.error(e.getMessage());
				HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
				return "error/503";
			}
	  }
	 
	 /**
	  * 
	  * <pre>
	  * 처리내용: 아이템별 중량 변동금 수정 시 메탈, 아이템에 해당하는 데이터를 조회한다.
	  * </pre>
	  * @date 2023. 6. 2.
	  * @author srec0083
	  * @history 
	  * ------------------------------------------------
	  * 변경일					작성자				변경내용
	  * ------------------------------------------------
	  * 2023. 6. 2.			srec0083			최초작성
	  * ------------------------------------------------
	  * @param itmWtChangeAmountMgrVO
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping("/selectItmWtChangeAmountMgrDtlList")
	 @ResponseBody
	 public ResponseEntity<Object> selectItmWtChangeAmountMgrDtlList(@RequestBody ItmWtChangeAmountMgrVO itmWtChangeAmountMgrVO) throws Exception{
		 
		 List<ItmWtChangeAmountMgrVO> itmWtChangeAmountMgrList =  itmWtChangeAmountMgrService.selectItmWtChangeAmountMgrDtlList(itmWtChangeAmountMgrVO);
		 Map<String, Object> map = new HashMap<String, Object>();
		 map.put("dataList", itmWtChangeAmountMgrList);
		 
		 return new ResponseEntity<>(map, HttpStatus.OK);
		 
		 
	 }
	 
	 /**
	  * 
	  * <pre>
	  * 처리내용: 아이템별 중량 변동금을 저장한다.
	  * </pre>
	  * @date 2023. 6. 7.
	  * @author srec0083
	  * @history 
	  * ------------------------------------------------
	  * 변경일					작성자				변경내용
	  * ------------------------------------------------
	  * 2023. 6. 7.			srec0083			최초작성
	  * ------------------------------------------------
	  * @param itmWtChangeAmountMgrsaveList
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping("/updateItmWtChangeAmountMgrSave")
	 @ResponseBody
	 public ResponseEntity<Object> updateItmWtChangeAmountMgrSave(@RequestBody List<ItmWtChangeAmountMgrVO> itmWtChangeAmountMgrsaveList) throws Exception{
		 
			Map<String, Object> map = new HashMap<String, Object>();

			if (userInfoUtil.getAccountInfo() == null) {
				map.put(RESULT, FAIL);
				map.put(ERRMSG, "로그인되지 않은 사용자입니다.");
				map.put("userInfoUtil", userInfoUtil.getAccountInfo());
				return new ResponseEntity<>(map, HttpStatus.OK);
			}
		 
			int result = itmWtChangeAmountMgrService.updateItmWtChangeAmountMgrSave(itmWtChangeAmountMgrsaveList);
		 
			if (result > 0) {
				map.put(RESULT, SUCCESS);
			} else {
				map.put(RESULT, FAIL);
				map.put(ERRMSG, "오류가 발생하였습니다.");
			}

			return new ResponseEntity<>(map, HttpStatus.OK);
			
	 }
	 
	 /**
	  * 
	  * <pre>
	  * 처리내용: 아이템별 중량 변동금을 삭제한다.
	  * </pre>
	  * @date 2023. 6. 8.
	  * @author srec0083
	  * @history 
	  * ------------------------------------------------
	  * 변경일					작성자				변경내용
	  * ------------------------------------------------
	  * 2023. 6. 8.			srec0083			최초작성
	  * ------------------------------------------------
	  * @param itmWtChangeAmountMgrVO
	  * @return
	  * @throws Exception
	  */
	 @RequestMapping("/deleteItmWtChangeAmountMgr")
	 @ResponseBody
	 public ResponseEntity<Object> deleteItmWtChangeAmountMgr(@RequestBody ItmWtChangeAmountMgrVO itmWtChangeAmountMgrVO) throws Exception{
		 
		Map<String, Object> map = new HashMap<String, Object>();
		 
		if (userInfoUtil.getAccountInfo() == null) {
			map.put(RESULT, FAIL);
			map.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			map.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(map, HttpStatus.OK);
		}
			
		int result = itmWtChangeAmountMgrService.deleteItmWtChangeAmountMgr(itmWtChangeAmountMgrVO);
		
		if (result > 0) {
			map.put(RESULT, SUCCESS);
		} else {
			map.put(RESULT, FAIL);
			map.put(ERRMSG, "오류가 발생하였습니다.");
		}

		return new ResponseEntity<>(map, HttpStatus.OK);
		 
		 
		 
	 }

}
