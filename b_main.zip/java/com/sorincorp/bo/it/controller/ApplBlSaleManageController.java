package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.co.comm.BoCoConstants;
import com.sorincorp.bo.co.comm.CoResponseEntity;
import com.sorincorp.bo.comm.util.CommConstants;
import com.sorincorp.bo.it.model.ApplBlSaleVO;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.model.ItemInvntrySetupVO;
import com.sorincorp.bo.it.service.ApplBlSaleManageService;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.bo.it.service.ItemInvntrySetupService;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.comm.invntry.service.InvntrySttusService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * <pre>
 * 처리내용: 지정 BL 판매를 위한 데이터 조회
 * </pre>
 * @date 2022. 12. 1.
 * @auther chajeeman
 * @history
 * -----------------------------------------------
 * 변경일					작성자				변경내용
 * -----------------------------------------------
 * 2022. 12. 1.			chajeeman			최초작성
 * -----------------------------------------------
 * @param model
 * @return
 */
/**
* @ClassName: ApplBlSaleManageController
 * @Author: chajeeman
 * @Date: 2022. 12. 2.
 */
@Slf4j
@Controller
@RequestMapping("/bo/it")
public class ApplBlSaleManageController {

	@Autowired
	private ApplBlSaleManageService ApplBlSaleManageService;

	@Autowired
	private EntrpsMbService entrpsMbService;

	@Autowired
	private ItCmnCodeService itCmnCodeService;

	@Autowired
	private ItemInvntrySetupService itemInvntrySetupService;

	@Autowired
	private CustomValidator customValidator;

	/** 재고 현황 공통 서비스 */
	@Autowired
	private InvntrySttusService invntrySttusService;


	/**
	 * <pre>
	 * 처리내용: 지정 BL 판매 데이터를 조회한다.
	 * </pre>
	 * @date 2022. 12. 1.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 1.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param model
	 * @return
	 */
	@RequestMapping("/applBlSaleManageList")
	public String selectrApplBlSaleManageList(ModelMap model) {
		try {

			return "it/applBlSaleManage";

		} catch(Exception e){
				log.error(e.getMessage());
				HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

				return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 지정 BL 판매 데이터를 조회한다.
	 * </pre>
	 * @date 2022. 12. 1.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 1.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/selectApplBlSaleManageList")
	public ResponseEntity<?> selectApplBlSaleManageListData(@RequestBody ApplBlSaleVO searchVO, ModelMap model, BindingResult bindingResult) throws Exception {

		if(searchVO.isValidation()) {
			customValidator.validate(searchVO, bindingResult);
		}

		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}


		Map<String,Object> map = new HashMap<String, Object>();
		int totalCount =  ApplBlSaleManageService.getApplBlSaleManageListTotCnt(searchVO);
		List<ApplBlSaleVO> dataList = ApplBlSaleManageService.getApplBlSaleManageList(searchVO);

		map.put("totalDataCount", totalCount);
		map.put("dataList", dataList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@RequestMapping(value="/selectApplBlSaleManageData")
	public ResponseEntity<?> selectApplBlSaleManageData(@RequestBody ApplBlSaleVO searchVO, ModelMap model, BindingResult bindingResult) throws Exception {
		ApplBlSaleVO resultVO =  ApplBlSaleManageService.selectApplBlSaleManageData(searchVO);
		return ResponseEntity.status(HttpStatus.OK).body(resultVO);
	}


	/**
	 * <pre>
	 * 처리내용:
	 * </pre>
	 * @date 2022. 12. 6.
	 * @auther 판매업체 팝업 호출
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 6.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param searchVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/addEntrps")
	public String addEntrps(@RequestBody ApplBlSaleVO searchVO, ModelMap model) throws Exception {

		try {
			//db 등급
			List<MbEntrpsMbVO> entrpsGrad = entrpsMbService.selectEntrpsGrad();
			model.addAttribute("entrpsGrad", entrpsGrad);

			return "it/entrpsPop.modal";

		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@PostMapping("/addApplBl")
	public String addApplBl(@RequestBody ApplBlSaleVO searchVO, ModelMap model) throws Exception {

		try {
			ItCmnCodeVO vo = new ItCmnCodeVO();
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			//메탈코드 리스트
			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);
			model.addAttribute("metalCodeList", metalCodeList);

			vo.setCodeDctwo(null);
			vo.setMainCode("DSTRCT_LCLSF_CODE");
			vo.setCodeRefrnone("Y");

			//권역 분류
			List<ItCmnCodeVO> dstrctLclsfCodeList = itCmnCodeService.selectCmnCodeList(vo);
			model.addAttribute("dstrctLclsfCodeList", dstrctLclsfCodeList);

			return "it/applBlPop.modal";

		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	@PostMapping("/selectBlbList")
	@ResponseBody
	public Map<String, Object> selectBlbList(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();

		//int totalDataCount = itemInvntrySetupService.selectPopItemInvntrySetupListTotCnt(itemInvntrySetupVO);
		List<ItemInvntrySetupVO> itemInvntrySetupList = itemInvntrySetupService.selectPopItemInvntrySetupList(itemInvntrySetupVO);
		//log.info("selectEntrpsMbListTotCnt ::" + totalDataCount);

		if(itemInvntrySetupList.size() == 0) {
			map.put("totalDataCount", 0);
		}else {
			map.put("totalDataCount", itemInvntrySetupList.get(0).getTotalRowCount());
		}

		map.put("dataList", itemInvntrySetupList);

		return map;
	}

	@PostMapping("/selectMetal")
	@ResponseBody
	public Map<String, Object> selectMetalCode(@RequestBody ItemInvntrySetupVO itemInvntrySetupVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();

		ItCmnCodeVO vo = new ItCmnCodeVO();
		vo.setMainCode("BRAND_GROUP_CODE");
		vo.setUseAt("Y");
		vo.setCodeRefrnone(itemInvntrySetupVO.getMetalCode());
		//서구/비서구산 리스트

		List<ItCmnCodeVO> brandGroupCodeList = itCmnCodeService.selectCmnCodeList(vo);
		returnMap.put("brandGroupList", brandGroupCodeList);

		return returnMap;
	}


	/**
	 * <pre>
	 * 처리내용: 지정 BL 판매 데이터를 추가한다.
	 * </pre>
	 * @date 2022. 12. 2.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 2.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param searchVOList
	 * @param model
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/insertApplBlSaleManageList")
	public ResponseEntity<?> insertApplBlSaleManageList(@RequestBody List<ApplBlSaleVO> searchVOList, ModelMap model, BindingResult bindingResult) throws Exception {
		ApplBlSaleManageService.insertApplBlSaleManageListTotCnt(searchVOList);
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG), HttpStatus.OK);
	}


	/**
	 * <pre>
	 * 처리내용: 지정 BL 판매 데이터를 수정한다.
	 * </pre>
	 * @date 2022. 12. 2.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 2.			chajeeman			최초작성
	 * 2023. 5. 8.			srec0051		지정BL 등록시 체크 로직 추가 & 소스정리
	 * -----------------------------------------------
	 * @param searchVOList
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/updateApplBlSaleManageList")
	public ResponseEntity<?> updateApplBlSaleManageList(@RequestBody List<ApplBlSaleVO> searchVOList) throws Exception {
		int result = 0;
		Map<String, Object> retVal = new HashMap<>();

		try {
			result = ApplBlSaleManageService.updateApplBlSaleManageListTotCnt(searchVOList);

			if (result > 0) {
				retVal.put(CommConstants.RESULT, CommConstants.SUCCESS);
				retVal.put(CommConstants.ERRMSG, CommConstants.SUCCESS_MSG);

				/** 실시간 재고 Redis Publish */
				invntrySttusService.invntrySttusMsgPublish();

			} else if (result == -99) {
				retVal.put(CommConstants.RESULT, CommConstants.FAIL);
				retVal.put(CommConstants.ERRMSG, "존재하지 않는 B/L 번호 입니다.");

			} else if (result == -98) {
				retVal.put(CommConstants.RESULT, CommConstants.FAIL);
				retVal.put(CommConstants.ERRMSG, "지정B/L 판매목록에 추가할수 없습니다.\n해당 B/L 판매중 설정에 실패 하였습니다.");

			} else if (result == -97) {
				retVal.put(CommConstants.RESULT, CommConstants.FAIL);
				retVal.put(CommConstants.ERRMSG, "지정B/L 판매목록에 추가할수 없습니다.\n예외 대상 B/L 이거나, 지정가 주문 미체결 B/L이 존재합니다.");
			}

		} catch (Exception e) {
			log.error(e.getMessage());
			result = -1;
			retVal.put(CommConstants.RESULT, CommConstants.FAIL);
			retVal.put(CommConstants.ERRMSG, e.getMessage());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 지정 BL 판매 데이터를 삭제한다.
	 * </pre>
	 * @date 2022. 12. 2.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 2.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param searchVOList
	 * @param model
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/deleteApplBlSaleManageList")
	public ResponseEntity<?> deleteApplBlSaleManageList(@RequestBody List<ApplBlSaleVO> searchVOList, ModelMap model, BindingResult bindingResult) throws Exception {
		ApplBlSaleManageService.deleteApplBlSaleManageListTotCnt(searchVOList);
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG), HttpStatus.OK);
	}
}