package com.sorincorp.bo.it.controller;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.model.ItemMgrVO;
import com.sorincorp.bo.it.model.ItmWtChangeAmountMgrVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.bo.it.service.ItemMgrService;
import com.sorincorp.bo.it.service.ItmWtChangeAmountMgrService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * ItemMgrController.java
 *
 * @version
 * @since 2021. 6. 14.
 * @author srec0030
 */
@Slf4j
@Controller
@RequestMapping("/bo/it")
public class ItemMgrController {

	@Autowired
	private ItemMgrService itemMgrService;
	@Autowired
	private ItCmnCodeService itCmnCodeService;
	@Autowired
	private CustomValidator customValidator;
//	@Autowired
//	private BrandCodeService brandCodeService;
//	@Autowired
//	private ItemCodeService itemCodeService;
	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired
	private ItmWtChangeAmountMgrService itmWtChangeAmountMgrService;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 23.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectItemMgrList")
	public String selectItemMgrList(ModelMap model) {
		try {
			ItCmnCodeVO vo = new ItCmnCodeVO();
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			List<ItCmnCodeVO> itemCodeLIst = itCmnCodeService.selectCmnCodeList(vo);

//			List<ItCmnCodeVO> itemCodeLIst2 = new ArrayList<ItCmnCodeVO>();
//			ItCmnCodeVO itCmnCodeVO = null;
//			ItCmnCodeVO itCmnCodeVO2 = null;
//			String sleBit = "";
//			String sleBit01 = "";
//			String sleBit02 = "";
//			String sleBit03 = "";
//			String subCode = "";
//			String codeChrctrRefrnsix = "";
//
//			for(int i=0;i<itemCodeLIst.size();i++) {
//				itCmnCodeVO = itemCodeLIst.get(i);
//				sleBit = itCmnCodeVO.getCodeChrctrRefrnthree();
//				subCode = itCmnCodeVO.getSubCode();
//				codeChrctrRefrnsix = itCmnCodeVO.getCodeChrctrRefrnsix();
//
//				if(sleBit != null && !"".equals(sleBit)) {
//					sleBit = sleBit.substring(0, 3);
//					sleBit01 = sleBit.substring(0, 1);
//					sleBit02 = sleBit.substring(1, 2);
//					sleBit03 = sleBit.substring(2, 3);
//
//					if("1".equals(sleBit01)) {
//						itCmnCodeVO2 = new ItCmnCodeVO();
//						itCmnCodeVO2.setSubCode(subCode + "_1");
//						itCmnCodeVO2.setCodeChrctrRefrnsix(codeChrctrRefrnsix + " LIVE");
//						itemCodeLIst2.add(itCmnCodeVO2);
//					}
//
//					if("1".equals(sleBit02)) {
//						itCmnCodeVO2 = new ItCmnCodeVO();
//						itCmnCodeVO2.setSubCode(subCode + "_2");
//						itCmnCodeVO2.setCodeChrctrRefrnsix(codeChrctrRefrnsix + " 고정가");
//						itemCodeLIst2.add(itCmnCodeVO2);
//					}
//
//					if("1".equals(sleBit03)) {
//						itCmnCodeVO2 = new ItCmnCodeVO();
//						itCmnCodeVO2.setSubCode(subCode + "_3");
//						itCmnCodeVO2.setCodeChrctrRefrnsix(codeChrctrRefrnsix + " 지정가");
//						itemCodeLIst2.add(itCmnCodeVO2);
//					}
//
//				} else {
//					itemCodeLIst2.add(itCmnCodeVO);
//				}
//			}

			vo = new ItCmnCodeVO();
			vo.setMainCode("PACKNG_CODE");
			vo.setCodeDctwo("");
			List<ItCmnCodeVO> packngCodeList = itCmnCodeService.selectCmnCodeList(vo);

			vo = new ItCmnCodeVO();
			vo.setMainCode("SHAPE_CODE");
			vo.setCodeDctwo("");
			List<ItCmnCodeVO> shapeCodeList = itCmnCodeService.selectCmnCodeList(vo);

//			model.addAttribute("itemCodeLIst", itemCodeLIst2);
			model.addAttribute("itemCodeLIst", itemCodeLIst);
			model.addAttribute("packngCodeList", packngCodeList);
			model.addAttribute("shapeCodeList", shapeCodeList);

//			List<ItemCodeVO> list1 = itemCodeService.getItemFtrsProcessAtCodeList("1","Y");
//			List<ItemCodeVO> list2 = itemCodeService.getItemFtrsProcessAtCodeList("1","N");
//			List<ItemCodeVO> list3 = itemCodeService.getItemFtrsProcessAtCodeList("1","");
			//
//			List<ItemCodeVO> list4 = itemCodeService.getItemFtrsProcessAtCodeList("","Y");
//			List<ItemCodeVO> list5 = itemCodeService.getItemFtrsProcessAtCodeList("","N");
//			List<ItemCodeVO> list6 = itemCodeService.getItemFtrsProcessAtCodeList("","");
			//
//			log.debug("list1 : " + list1.toString());
//			log.debug("list2 : " + list2.toString());
//			log.debug("list3 : " + list3.toString());
//			log.debug("list4 : " + list4.toString());
//			log.debug("list5 : " + list5.toString());
//			log.debug("list6 : " + list6.toString());

			// getItemFtrsProcessAtCodeList

//			List<BrandCodeVO> brandList = brandCodeService.getTopPriorRankBrandCodeList("");
//			List<BrandCodeVO> brandList2 = brandCodeService.getTopPriorRankBrandCodeList("01");
//			List<BrandCodeVO> brandList3 = brandCodeService.getTopPriorRankBrandCodeList("02");
			//
//			log.debug("brandList : " + brandList.toString());
//			log.debug("brandList2 : " + brandList2.toString());
//			log.debug("brandList3 : " + brandList3.toString());

			return "it/itemMgrList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 23.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectItemMgrListAjax")
	@ResponseBody
	public ResponseEntity<Object> selectItemMgrListAjax(@RequestBody ItemMgrVO itemMgrVO, BindingResult bindingResult) throws Exception {

		customValidator.validate(itemMgrVO, bindingResult, ItemMgrVO.Search.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			// return new ResponseEntity<>(bindingResult.getAllErrors(),
			// HttpStatus.BAD_REQUEST);
		}

		List<ItemMgrVO> itemMgrList = itemMgrService.selectItemMgrList(itemMgrVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalDataCount", itemMgrService.selectItemMgrTotalCnt(itemMgrVO));
		map.put("dataList", itemMgrList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 6. 18.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 18.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param itemMgrVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/itemMgrDetail")
	public String selectItemMgrDetail(@RequestBody ItemMgrVO itemMgrVO, ModelMap model) throws Exception {

		ItemMgrVO detailVO = itemMgrService.selectItemMgrDetail(itemMgrVO);
		List<ItemMgrVO> stdSpecList = itemMgrService.selectStdSpecList(itemMgrVO);
		ItemMgrVO itemCtgryVO = itemMgrService.selectItemCtgry(itemMgrVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("ctgryLevel", "1");
		map.put("upperCtgryNo", null);
		List<ItemMgrVO> itemCtgryLv1List = itemMgrService.selectItemCtgryBas(map);

		ItCmnCodeVO vo = new ItCmnCodeVO();
		vo.setMainCode("GOODS_SLE_UNIT_CODE");
		vo.setUseAt("Y");
		List<ItCmnCodeVO> sleUnitList = itCmnCodeService.selectCmnCodeList(vo);

		vo.setMainCode("METAL_CL_CODE");
		vo.setUseAt("Y");
		vo.setCodeDctwo("Y");
		List<ItCmnCodeVO> metalClCodeList = itCmnCodeService.selectCmnCodeList(vo);

		List<ItemMgrVO> itemCtgryList = itemMgrService.selectitemCtgryList(itemMgrVO.getItmSn());

		model.addAttribute("detailVO", detailVO);
		model.addAttribute("stdSpecList", stdSpecList);
		model.addAttribute("sleUnitList", sleUnitList);
		model.addAttribute("metalClCodeList", metalClCodeList);
		model.addAttribute("itemCtgryLv1List", itemCtgryLv1List);
		model.addAttribute("itemCtgryList", itemCtgryList);
		model.addAttribute("itemCtgryVO", itemCtgryVO);
		model.addAttribute("itmSn", detailVO.getItmSn());

		return "it/itemMgrDetail.modal";
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 23.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param mRequest
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/fileUploadItemMgr")
	@ResponseBody
	public ResponseEntity<Object> fileUploadItemMgr(MultipartHttpServletRequest mRequest) throws Exception {
		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		Map<String, Object> fileMap = itemMgrService.saveAttachFile(mRequest);
		// log.debug(fileMap.toString());
		String result = (String) fileMap.get(RESULT);

		if (SUCCESS.equals(result)) {
			retVal.put(RESULT, SUCCESS);
			retVal.put("fileMap", fileMap);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, (String) fileMap.get("errMsg"));
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 23.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param itemMgrVO
	 * @param model
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/updateItemMgr")
	@ResponseBody
	public ResponseEntity<Object> updateItemMgr(@RequestBody ItemMgrVO itemMgrVO, Model model, BindingResult bindingResult) throws Exception {
		// log.debug(itemMgrVO.toString());
		// 리턴값
		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		if (itemMgrVO.isValidation()) {
			customValidator.validate(itemMgrVO, bindingResult, ItemMgrVO.InsertAndUpdate.class);
		}

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		ItmWtChangeAmountMgrVO itmWtChangeAmountMgrParam = new ItmWtChangeAmountMgrVO();
		itmWtChangeAmountMgrParam.setMetalCode(itemMgrVO.getMetalCode());
		itmWtChangeAmountMgrParam.setItmSn(itemMgrVO.getItmSn());
		int itmWtChangeAmountCount = itmWtChangeAmountMgrService.selectItmWtChangeAmountMgrGridCount(itmWtChangeAmountMgrParam);
		if (itmWtChangeAmountCount > 0) {
			int result = itemMgrService.updateItemMgr(itemMgrVO);
			if (result > 0) {
				retVal.put(RESULT, SUCCESS);
				retVal.put(ERRMSG, "");
			} else {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "");
			}
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "중량 변동금을 등록해주세요.");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 23.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param itemMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("selectCtgryList")
	@ResponseBody
	public ResponseEntity<Object> selectCtgryList(@RequestBody ItemMgrVO itemMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> result = new HashMap<String, Object>();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("ctgryLevel", itemMgrVO.getCtgryLevel());
		map.put("upperCtgryNo", itemMgrVO.getUpperCtgryNo());
		List<ItemMgrVO> itemCtgryLv1List = itemMgrService.selectItemCtgryBas(map);

		// 응답 데이터 셋팅
		result.put("itemCtgryList", itemCtgryLv1List);

		return new ResponseEntity<>(result, HttpStatus.OK);

	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 23.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 23.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param itmSn
	 * @param docNo
	 * @param gubun
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/deleteImgFileItemMgrDetail")
	@ResponseBody
	public ResponseEntity<Object> deleteImgFileItemMgrDetail(@RequestBody ItemMgrVO itemMgrVO, Model model, BindingResult bindingResult) throws Exception {
		// 리턴값
		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result = 1;

		result = itemMgrService.deleteImgFile(itemMgrVO.getItmSn(), itemMgrVO.getDocNo(), itemMgrVO.getGubun());

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);

	}

	@RequestMapping("/goodsDcCnImgUpload")
	@ResponseBody
	public String goodsDcCnImgUpload(HttpServletRequest req, HttpServletResponse resp, MultipartHttpServletRequest mRequest) throws Exception {

		String json = "";
		PrintWriter printWriter = null;
		OutputStream out = null;
		printWriter = resp.getWriter();
		resp.setContentType("text/html");

		try {
			Map<String, Object> fileMap = itemMgrService.saveAttachFile2(mRequest);
			json = "{\"fileName\" : \"" + fileMap.get("fileName") + "\", \"uploaded\" : 1, \"url\":\"" + fileMap.get("fileUrl") + "\"}";
			// log.debug("json ====================>" + json);
			printWriter.println(json);

		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
		} finally {
			if (out != null) {
				out.close();
			}
			if (printWriter != null) {
				printWriter.close();
			}
		}
		return "S";
	}

	// updateItemPriorRank
	@RequestMapping("/updateItemPriorRank")
	@ResponseBody
	public ResponseEntity<Object> updateItemPriorRank(@RequestBody ItemMgrVO itemMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result = 0;
		// log.debug(brandMgrVO.toString());
		// 브랜드관리 update
		result = itemMgrService.updateItemPriorRank(itemMgrVO.getItemSaveList());

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

}
