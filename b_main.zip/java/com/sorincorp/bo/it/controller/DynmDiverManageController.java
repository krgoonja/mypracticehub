package com.sorincorp.bo.it.controller;

import java.util.Map;
import java.util.Optional;

import com.sorincorp.comm.dynmDiver.model.DynmDiverCommVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sorincorp.bo.it.model.DynmDiverMangeVO;
import com.sorincorp.bo.it.service.DynmDiverManageService;


@Controller
@RequestMapping("/bo/it/diver")
public class DynmDiverManageController {

    @Autowired
    private DynmDiverManageService dynmDiverManageService;

    /**
     * <pre>
     * 처리내용: 다이버 관리 페이지를 호출한다.
     * </pre>
     * @date 2024. 1. 15.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일                 작성자          변경내용
     * ------------------------------------------------
     * 2024. 1. 15.          hamyoonsic      최초작성
     * ------------------------------------------------
     * @param model
     * @return
     * @throws Exception
     */
    @RequestMapping("/viewDiverMange")
    public String viewDiverMange(ModelMap model) throws Exception {

        model.addAttribute("purchsPremium", 130);//구매 프리미엄
        model.addAttribute("slePremium", 150);//판매 프리미엄

        DynmDiverMangeVO diverVO = dynmDiverManageService.selectGtxApiFxrate();
        long nowPc = dynmDiverManageService.selectSlePc();
        DynmDiverMangeVO diverAtVO = dynmDiverManageService.selectDiverAt();

        String premiumId = dynmDiverManageService.selectDiverPremiumId();
        //DynmDiverMangeVO premiumVo = dynmDiverManageService.selectDiverPremium(premiumId); //구매,판매 프리미엄 조회

        String korCvtrate = Optional.ofNullable(diverVO).map(vo -> vo.getKorCvtrate()).orElse("");
        long endPc= Optional.ofNullable(nowPc).orElse(0L);
        String diverAt = Optional.ofNullable(diverAtVO).map(vo -> vo.getDiverAt()).orElse("");
        String updTime = Optional.ofNullable(diverVO).map(vo -> vo.getUpdTime()).orElse("");

        DynmDiverCommVO DiverInfo = dynmDiverManageService.selectPremiumDiverInfo();

        model.addAttribute("premiumMdat",DiverInfo.getDiverMotnKrwScope());
        model.addAttribute("diverMt",DiverInfo.getDiverMotnTon());
        model.addAttribute("diverTime",DiverInfo.getDiverMotnTimeScope());
        model.addAttribute("diverMdatVal",DiverInfo.getDiverMdatVal());

        model.addAttribute("korCvtrate",korCvtrate);
        model.addAttribute("endPc",endPc);
        model.addAttribute("updTime",updTime);
        model.addAttribute("diverAt",diverAt);

        return "it/dynmDiverManage";
    }

    @RequestMapping("/diverAt")
    public ResponseEntity<?> diverAt(@RequestBody DynmDiverMangeVO dynmDiverMangeVO) throws Exception {
        try{
            Map<String,String> map = dynmDiverManageService.diverAt(dynmDiverMangeVO);
            return new ResponseEntity<>(map, HttpStatus.OK);
        }catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

}
