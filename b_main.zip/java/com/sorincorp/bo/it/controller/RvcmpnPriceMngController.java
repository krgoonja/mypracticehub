package com.sorincorp.bo.it.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;

import com.sorincorp.bo.it.model.RvcmpnPriceMngVO;
import com.sorincorp.bo.it.service.PrimiumPriceMngService;
import com.sorincorp.bo.it.service.RvcmpnPriceMngService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/it/rvcmpnPriceMng")
public class RvcmpnPriceMngController {
	@Autowired
	private PrimiumPriceMngService ppms;
	@Autowired
	RvcmpnPriceMngService rpmService;
	@Autowired
	private CommonCodeService commonCodeService;

	/**
	 * <pre>
	 * 처리내용: 경쟁사가격관리 화면 보여준다.
	 * </pre>
	 * 
	 * @date 2021. 5. 28.
	 * @author Cho han yong
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 03. Cho
	 *          han yong 최초작성 ------------------------------------------------
	 * @return "it/rvcmpnPriceMng.tiles"
	 * @throws Exception
	 */
	@RequestMapping("/selectList")
	public String selectRvcmpnPriceMngList(ModelMap model) {
		try {
			model.put("metalCode", commonCodeService.getFilterCode("METAL_CODE", null, "CODE_DCTWO", "Y"));
			model.put("brandGroupCode", commonCodeService.getSubCodesRetVo("BRAND_GROUP_CODE"));
			return "it/rvcmpnPriceMng";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 경쟁사 가격관리 목록을 조회한다.
	 * </pre>
	 * 
	 * @date 2021. 5. 28.
	 * @author Cho han yong
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 03. Cho
	 *          han yong 최초작성 ------------------------------------------------
	 * @param sidecarVO
	 * @throws Exception
	 */
	@RequestMapping(value = "/selectAjaxList", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> selectSidecarAjaxList(@RequestBody RvcmpnPriceMngVO rvcmpnPriceMngVO) throws Exception {
		int totalCnt = rpmService.searchRvcmpnPriceMngTotalCnt(rvcmpnPriceMngVO);
		Map<String, Object> map = new HashMap<String, Object>();
		List<RvcmpnPriceMngVO> rvcmpnPriceMngList = rpmService.searchRvcmpnPriceMngList(rvcmpnPriceMngVO);
		map.put("dataList", rvcmpnPriceMngList);
		map.put("totalDataCount", totalCnt);

		return map;
	}
	
	@RequestMapping(value = "/selectRvcmpnPriceMetalBrandGroupCodeList", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> selectRvcmpnPriceMetalBrandGroupCodeList(@RequestBody RvcmpnPriceMngVO rvcmpnPriceMngVO) throws Exception {
		
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		//금속 코드
		Map<String, CommonCodeVO> metalCodeVo = commonCodeService.getMultiFilterCodeRetVo("METAL_CODE",null,	//MAIN_CODE가 "METAL_CODE"인 공통 코드
				  "CODE_DCTWO","Y", null, null);	//CODE_DCTWO(코드 설명2, EC 판매 대상 여부)가 Y인 METAL_CODE
		
		List<Map<String,String>> metalCode = new ArrayList<>();
		for (Entry<String, CommonCodeVO> map : metalCodeVo.entrySet()) {
			Map<String, String> metalCodeMap = new HashMap<>();
			metalCodeMap.put("metalCode", map.getKey());
			metalCodeMap.put("metalNm", map.getValue().getCodeNm());
			metalCode.add(metalCodeMap);
		}
		
		// 브랜드그룹코드
		Map<String, CommonCodeVO> brandGroupCodeVo = commonCodeService.getSubCodesRetVo("BRAND_GROUP_CODE"); // 권역 중분류 코드
		
		List<Map<String,String>> brandGroupCode = new ArrayList<>();
		for (Entry<String, CommonCodeVO> map : brandGroupCodeVo.entrySet()) {
			Map<String, String> brandGroupCodeMap = new HashMap<>();
			brandGroupCodeMap.put("brandGroupCode", map.getKey());
			brandGroupCodeMap.put("brandGroupNm", map.getValue().getCodeNm());
			brandGroupCodeMap.put("codeRefrnone", map.getValue().getCodeRefrnone());
			
			brandGroupCode.add(brandGroupCodeMap);
		}
				
		returnMap.put("metalCodeList", metalCode);
		returnMap.put("brandGroupCodeList", brandGroupCode);

		return returnMap;
	}

	/**
	 * <pre>
	 * 처리내용: 경쟁사 가격관리 목록을 저장한다.
	 * </pre>
	 * 
	 * @date 2021. 5. 28.
	 * @author Cho han yong
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 03. Cho
	 *          han yong 최초작성 ------------------------------------------------
	 * @param sidecarVO
	 * @throws Exception
	 */
	@PostMapping(value = "/insertAndUpdateAjax")
	@ResponseBody
	public ResponseEntity<?> insertAndUpdateRvcmpnPriceMngAjax(@RequestBody List<RvcmpnPriceMngVO> rvcmpnPriceMngVOList,
			BindingResult bindingResult, SessionStatus status) throws Exception {

		// 개장시간 체크
		for (RvcmpnPriceMngVO vo : rvcmpnPriceMngVOList) {
			// 유효성 검사
			// 데이터 중복 체크
			if ("created".equals(vo.getGridRowStatus())) {
				int dupCnt = rpmService.selectDupRvcmpnPrice(vo);
				if (dupCnt > 0) {
					return new ResponseEntity<>("중복된 데이터가 존재 합니다.", HttpStatus.BAD_REQUEST);
				}
				if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), vo.getApplcDe().replace("-", "")) > 0) {
					return new ResponseEntity<>("추가는 오늘날짜보다 이후에만 가능합니다.", HttpStatus.BAD_REQUEST);
				}
			}
			// 날짜1이 날짜2와 동일하다면 0, 날짜1이 크다면 음수, 날짜2가 크다면 양수
			// 이전날짜도 전부 수정 삭제 되도록 변경 (2021.09.08)
//            if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), vo.getApplcDe().replace("-", "")) > 0) {
//            	return new ResponseEntity<>("적용은 오늘날짜보다 이후에만 가능합니다.", HttpStatus.BAD_REQUEST);
//            }
		}
		rpmService.insertAndUpdateRvcmpnPriceMngList(rvcmpnPriceMngVOList);

		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PostMapping(value = "/deleteAjax")
	@ResponseBody
	public ResponseEntity<?> deleteAjax(@RequestBody List<RvcmpnPriceMngVO> rvcmpnPriceMngVOList, SessionStatus status)
			throws Exception {
		for (RvcmpnPriceMngVO vo : rvcmpnPriceMngVOList) {
			// 날짜1이 날짜2와 동일하다면 0, 날짜1이 크다면 음수, 날짜2가 크다면 양수
			// 이전날짜도 전부 수정 삭제 되도록 변경 (2021.09.08)
//            if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), vo.getApplcDe().replace("-", "")) > 0) {
//            	return new ResponseEntity<>("삭제는 오늘날짜보다 이후에만 가능합니다.", HttpStatus.BAD_REQUEST);
//            }
		}
		rpmService.deleteRvcmpnPrice(rvcmpnPriceMngVOList);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
