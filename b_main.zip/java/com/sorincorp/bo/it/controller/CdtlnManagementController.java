package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.it.model.CdtlnManagementVO;
import com.sorincorp.bo.it.service.CdtlnManagementService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;


/**
 * CdtlnManagementController.java
 * @version
 * @since 2022. 7. 18.
 * @author srec0061
 */
@Slf4j
@Controller
@RequestMapping("/it/cdtlnManagement")
public class CdtlnManagementController {

	@Autowired
	private CdtlnManagementService cdtlnManagementService;
	@Autowired
	private CustomValidator customValidator;

	/**
	 * <pre>
	 * 처리내용: 여신 관리 페이지로 이동한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param cdtlnManagementVO
	 * @param model
	 * @return
	 */
	@GetMapping("/getListCdtlnManagementPage")
	public String getListCdtlnManagementPage(@ModelAttribute("cdtlnManagementVO") CdtlnManagementVO cdtlnManagementVO, ModelMap model){

		try {
			return "it/cdtlnManagementList";

		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}


	/**
	 * <pre>
	 * 처리내용: 여신관리 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param cdtlnManagementVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/getListCdtlnManagement")
	@ResponseBody
	public Map<String, Object> getListCdtlnManagement(@RequestBody CdtlnManagementVO cdtlnManagementVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();

		List<CdtlnManagementVO> sampleList = cdtlnManagementService.getListCdtlnManagement(cdtlnManagementVO);
		int totalDataCount = cdtlnManagementService.getListCdtlnManagementCnt(cdtlnManagementVO);

		returnMap.put("dataList", sampleList);
		returnMap.put("totalDataCount", totalDataCount);

		return returnMap;
	}

	/**
	 * <pre>
	 * 처리내용: 여신관리 등록 모달팝업을 호출한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param cdtlnManagementVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/getCdtlnManagementInsertModal")
	public String popUpModal(@RequestBody CdtlnManagementVO cdtlnManagementVO, ModelMap model) throws Exception {
		try {
		model.addAttribute("status", "insert");
				
				
		return "it/cdtlnManagementModal.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 여신 관리를 등록한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param cdtlnManagementVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertAndUpdateCdtlnManagement")
	@ResponseBody
	public ResponseEntity<?> insertCdtlnManagement(@RequestBody CdtlnManagementVO cdtlnManagementVO, BindingResult bindingResult) throws Exception {
		
		customValidator.validate(cdtlnManagementVO, bindingResult, CdtlnManagementVO.InsertAndUpdate.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			 return new ResponseEntity<>(bindingResult.getAllErrors(),
			 HttpStatus.BAD_REQUEST);
		}
		
		Map<String, Object> returnMap = new HashMap<String, Object>();

		cdtlnManagementService.insertCdtlnManagement(cdtlnManagementVO);

		return new ResponseEntity<>(returnMap, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 여신관리 수정 모달페이지로 이동한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param cdtlnManagementVO
	 * @param model
	 * @return
	 */
	@RequestMapping("/getUpdateCdtlnManagementModal")
	public String getUpdateCdtlnManagementFormPage(@RequestBody CdtlnManagementVO cdtlnManagementVO, ModelMap model){
		try {

			CdtlnManagementVO resultData = cdtlnManagementService.getCdtlnManagement(cdtlnManagementVO);
			model.put("status", "update");
			model.put("result", resultData);

			return "it/cdtlnManagementModal";

		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}

	}
	
	/**
	 * <pre>
	 * 처리내용: 여신관리를 수정한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param cdtlnManagementVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/updateCdtlnManagement")
	@ResponseBody
	public ResponseEntity<?> updateCdtlnManagement(@RequestBody CdtlnManagementVO cdtlnManagementVO, BindingResult bindingResult) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();

		customValidator.validate(cdtlnManagementVO, bindingResult, CdtlnManagementVO.InsertAndUpdate.class);
		
		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		cdtlnManagementService.updateCdtlnManagement(cdtlnManagementVO);

		return new ResponseEntity<>(returnMap, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 여신관리를 삭제한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param cdtlnManagementVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/deleteCdtlnManagement")
	@ResponseBody
	public Map<String, Object> deleteCdtlnManagement(@RequestBody CdtlnManagementVO cdtlnManagementVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		cdtlnManagementService.deleteCdtlnManagement(cdtlnManagementVO);

		return returnMap;
	}

	/**
	 * <pre>
	 * 처리내용: 데이터 등록여부를 확인한다.
	 * </pre>
	 * @date 2022. 7. 18.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 18.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/isAlreadyRegistered")
	@ResponseBody
	public boolean isAlreadyRegistered(@RequestBody CdtlnManagementVO vo) throws Exception {
		return cdtlnManagementService.isAlreadyRegistered(vo);
	}

}
