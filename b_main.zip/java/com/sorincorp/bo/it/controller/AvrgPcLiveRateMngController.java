package com.sorincorp.bo.it.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.sorincorp.bo.comm.util.CommConstants;
import com.sorincorp.bo.comm.util.CommResponseEntity;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.AvrgPcLiveGradInfoVO;
import com.sorincorp.bo.it.model.AvrgPcLiveRateDtlVO;
import com.sorincorp.bo.it.model.AvrgPcLiveRateMngVO;
import com.sorincorp.bo.it.service.AvrgPcLiveRateMngService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * AvrgPcLiveRateMngController.java
 * 평균가 라이브 비율 관리 Controller 클래스
 * 
 * @version
 * @since 2023. 8. 16.
 * @author srec0049
 */
@Slf4j
@Controller
@RequestMapping("/it/avrgPcLiveRate")
public class AvrgPcLiveRateMngController {
	
	/**
	 * 사용자정의 유효성 검사
	 */
	@Autowired
	private CustomValidator customValidator;
	
	/**
	 * 평균가 라이브 비율 관리 Service
	 */
	@Autowired
	private AvrgPcLiveRateMngService avrgPcLiveRateMngService;
	
	/**
	 * 공통 코드 Service
	 */
	@Autowired
	private CommonCodeService commonCodeService;
	
	/**
	 * 로그인 정보 유틸
	 */
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	
	/**
	 * <pre>
	 * 처리내용: 평균 라이브 비율 관리 목록 페이지를 호출한다.
	 * </pre>
	 * @date 2023. 8. 16.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 16.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/viewAvrgPcLiveRateMngList")
	public String viewAvrgPcLiveRateMngList(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO, ModelMap model) throws Exception {
		log.debug(">> viewAvrgPcLiveRateMngList in");
		
		log.debug(">> getApplcDe : " + avrgPcLiveRateMngVO.getApplcDe());
		log.debug(">> getMetalCode : " + avrgPcLiveRateMngVO.getMetalCode());
		
		model.put("applcDe", avrgPcLiveRateMngVO.getApplcDe()); // 검색조건 - 적용 일자
		model.put("metalCode", avrgPcLiveRateMngVO.getMetalCode()); // 검색조건 - 금속 코드
		
		return "it/avrgPcLiveRateMngList";
	}
	
	/**
	 * <pre>
	 * 처리내용: 평균 라이브 비율 관리 그리드 데이터를 가져온다.
	 * </pre>
	 * @date 2023. 8. 16.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 16.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/getListAvrgPcLiveRate")
	public ResponseEntity<?> getListAvrgPcLiveRate(@RequestBody AvrgPcLiveRateMngVO avrgPcLiveRateMngVO, BindingResult bindingResult) throws Exception {
		if(avrgPcLiveRateMngVO.isValidation()) { // 유효성 검사 분기 (필요할 경우)
			// validation을 수행한다, validation VO Class의 형식은 VO, List<Vo>, Map<VO> 가능
			// process별로 validation 수행 field 들을 나누고 싶다면 group interface class를 지정하여 사용한다. (VO에도 지정)
			customValidator.validate(avrgPcLiveRateMngVO, bindingResult, AvrgPcLiveRateMngVO.Search.class);
		}

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		Map<String, Object> map = new HashMap<String, Object>();
		int totalCnt = 0; // 총 건수
		
		// 평균가 라이브 비율 관리 목록(총 건수 포함)을 가져온다.
		List<AvrgPcLiveRateMngVO> getListAvrgPcLiveRate = avrgPcLiveRateMngService.getListAvrgPcLiveRate(avrgPcLiveRateMngVO);
		
		if(getListAvrgPcLiveRate.size() > 0) {
			totalCnt = getListAvrgPcLiveRate.get(0).getTotalCnt(); // 총 건수
		}
		
		map.put("totalDataCount", totalCnt);
		map.put("dataList", getListAvrgPcLiveRate);
		
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 평균 라이브 비율 관리 (등록 또는 상세(수정)) 페이지로 이동한다.
	 * </pre>
	 * @date 2023. 8. 18.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 18.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/viewAvrgPcLiveRateMng")
	public String viewAvrgPcLiveRateMng(AvrgPcLiveRateMngVO avrgPcLiveRateMngVO, ModelMap model) throws Exception {
		log.debug(">> viewAvrgPcLiveRateMng in");
		
		// 톤당 구매 비율 리스트
		List<AvrgPcLiveRateMngVO> avrgPcLiveGradMngList = new ArrayList<AvrgPcLiveRateMngVO>();
		
		// 이동 모드 (insert(등록), dtl(상세))
		String mvMode = avrgPcLiveRateMngVO.getMvMode();
		
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode avrgPcLiveRateJson = objectMapper.createObjectNode();
		ArrayNode avrgPcLiveGradMngListJsonArr = objectMapper.createArrayNode();
		
		if(StringUtils.isEmpty(mvMode)) {
			return "error/404";
		} else {
			String titleKeyword = "";
			switch(mvMode) {
				case "insert" : 
					titleKeyword = "등록";
					
					// 톤당 구매 비율 리스트 구조 가져오기
					avrgPcLiveGradMngList = avrgPcLiveRateMngService.getPurchsRateStructurePerTonList();
					
					break;
				case "dtl" : 
					titleKeyword = "상세";
					
					// 상품_평균가 LIVE 기준 중량 관리 기본 정보를 가져온다.
					AvrgPcLiveRateMngVO avrgPcLiveRate = avrgPcLiveRateMngService.getAvrgPcLiveRate(avrgPcLiveRateMngVO);
					log.debug(">> avrgPcLiveRate : " + avrgPcLiveRate);
					
					String avrgPcLiveRateJsonStr = objectMapper.writeValueAsString(avrgPcLiveRate); // avrgPcLiveRate 정보를 String으로 변경
					avrgPcLiveRateJson = objectMapper.readValue(avrgPcLiveRateJsonStr, JsonNode.class); // String을 JSON 데이터로 변형
					
					// 톤당 구매 비율 리스트 - 상품_평균가 LIVE 기준 중량 관리의 단계 비율 데이터로 [평균가 LIVE 등급 관리 데이터(selectMbAvrgPcLiveGradMngList 메소드)] 리스트를 생성한다.
					avrgPcLiveGradMngList = avrgPcLiveRateMngService.getPurchsRatePerTonList(avrgPcLiveRateJson, avrgPcLiveRateMngVO);
					
					// 상품_평균가 LIVE 기준 중량 관리 상세에 평균 라이브 비율 기준 톤수 데이터 리스트를 가져온다.
					List<AvrgPcLiveRateDtlVO> avrgPcLiveRateDtlList = avrgPcLiveRateMngService.getAvrgPcLiveRateDtlList(avrgPcLiveRateMngVO);
					String avrgPcLiveRateDtlListStr = objectMapper.writeValueAsString(avrgPcLiveRateDtlList); // avrgPcLiveRateDtlList 정보를 String으로 변경
					avrgPcLiveGradMngListJsonArr = objectMapper.readValue(avrgPcLiveRateDtlListStr, ArrayNode.class); // String을 JSON 데이터로 변경
					
					break;
			}
			model.put("mvMode", mvMode); // 이동 모드 (insert(등록), dtl(상세))
			model.put("titleKeyword", titleKeyword); // 이동 모드에 따른 타이틀 키워드
			
			model.put("avrgPcLiveRateJson", avrgPcLiveRateJson); // 상품_평균가 LIVE 기준 중량 관리 기본 정보 JSON 데이터
			
			log.debug("[" + mvMode + "] >> avrgPcLiveGradMngList : " + avrgPcLiveGradMngList);
			model.put("purchsRatePerTonList", avrgPcLiveGradMngList); // 톤당 구매 비율 리스트
			
			model.put("avrgPcLiveGradMngListJsonArr", avrgPcLiveGradMngListJsonArr); // 상품_평균가 LIVE 기준 중량 관리 상세에 평균 라이브 비율 기준 톤수 데이터 리스트 JSON 데이터
		}
		
		log.debug(">> getApplcDe : " + avrgPcLiveRateMngVO.getApplcDe());
		log.debug(">> getMetalCode : " + avrgPcLiveRateMngVO.getMetalCode());
		
		model.put("applcDe", avrgPcLiveRateMngVO.getApplcDe()); // 검색조건 - 적용 일자
		model.put("metalCode", avrgPcLiveRateMngVO.getMetalCode()); // 검색조건 - 금속 코드
		
		if(StringUtils.equals("dtl", mvMode)) {
			String stdrSn = avrgPcLiveRateMngVO.getStdrSn(); // 기준 순번
			if(StringUtils.isEmpty(stdrSn)) {
				return "error/404";
			} else {
				model.put("stdrSn", stdrSn); // 기준 순번
			}
		}
		
		return "it/avrgPcLiveRateMng";
	}
	
	/**
	 * <pre>
	 * 처리내용: 금속 코드에 해당하는 삼성선물 주문 단위 중량(선물 단위)를 찾아 반환한다.
	 * </pre>
	 * @date 2023. 8. 21.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 21.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/getStdrIncrsWtByMetalCode")
	public ResponseEntity<String> getStdrIncrsWtByMetalCode(@RequestBody String metalCode) throws Exception {
		CommonCodeVO metalCodeInfo = Optional.ofNullable(commonCodeService.getCodeValueRetVo("METAL_CODE", metalCode)).orElse(new CommonCodeVO());
		
		return new ResponseEntity<String>(String.valueOf(metalCodeInfo.getCodeNumberRefrnone()), HttpStatus.OK); // 삼성선물 주문 단위 중량
	}
	
	/**
	 * <pre>
	 * 처리내용: 금속 코드에 해당하는 톤당 구매 비율 리스트를 가져온다.
	 * </pre>
	 * @date 2023. 9. 21.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 9. 21.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/getPurchsRateValuePerTonListByMetalCode")
	public ResponseEntity<List<AvrgPcLiveGradInfoVO>> getPurchsRateValuePerTonListByMetalCode(@RequestBody String metalCode) throws Exception {
		// 금속 코드에 해당하는 톤당 구매 비율 리스트를 가져온다.
		List<AvrgPcLiveGradInfoVO> getPurchsRateValuePerTonListByMetalCode = avrgPcLiveRateMngService.getPurchsRateValuePerTonListByMetalCode(metalCode);
		
		return new ResponseEntity<List<AvrgPcLiveGradInfoVO>>(getPurchsRateValuePerTonListByMetalCode, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 평균 라이브 비율 데이터를 등록 또는 수정한다.
	 * </pre>
	 * @date 2023. 8. 28.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 8. 28.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 * @throws CommCustomException
	 */
	@PostMapping(value = "/saveAvrgPcLiveRate")
	public ResponseEntity<?> saveAvrgPcLiveRate(@RequestBody AvrgPcLiveRateMngVO avrgPcLiveRateMngVO, BindingResult bindingResult) throws Exception {
		// 로그인 정보 확인
		if(userInfoUtil.getAccountInfo() == null) {
			return ResponseEntity.status(HttpStatus.OK).body(new CommResponseEntity(CommConstants.ERROR_CODE, "로그인 정보가 없습니다."));
		} else {
			String userId = Optional.ofNullable(userInfoUtil.getUserId()).orElse(""); // 유저 아이디
			avrgPcLiveRateMngVO.setFrstRegisterId(userId);
			avrgPcLiveRateMngVO.setLastChangerId(userId);
		}
		
		String mvMode = avrgPcLiveRateMngVO.getMvMode(); // 이동 모드 (insert(등록), dtl(상세))
		switch(mvMode) {
			case "insert" : 
				// 파라미터 유효성 검사
				customValidator.validate(avrgPcLiveRateMngVO, bindingResult);

				if(bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
					return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
				}
				
				if(DateUtil.compareToCalerdar(DateUtil.getNowDate(), avrgPcLiveRateMngVO.getApplcDe()) > 0) {
					return ResponseEntity.status(HttpStatus.OK).body(new CommResponseEntity(CommConstants.ERROR_CODE, "적용일자는 오늘 이후로만 설정할 수 있습니다."));
		        }
				
				// 금속코드와 적용일자에 대한 평균가 라이브 비율 관리 목록(상품_평균가 LIVE 기준 중량 관리 기본) 중복 건수를 가져온다.
				Integer getAvrgPcLiveRateDuplCnt = avrgPcLiveRateMngService.getAvrgPcLiveRateDuplCnt(avrgPcLiveRateMngVO);
				// 중복 체크, 중복된 건수가 존재할 때
				if(getAvrgPcLiveRateDuplCnt > 0) {
					return ResponseEntity.status(HttpStatus.OK).body(new CommResponseEntity(CommConstants.ERROR_CODE, "중복된 평균가 라이브 비율 기준 설정이 있습니다."));
				}
				
				// 평균 라이브 비율 데이터를 등록한다.
				avrgPcLiveRateMngService.insertAvrgPcLiveRate(avrgPcLiveRateMngVO);
				
				break;
			case "dtl" : 
				// 평균 라이브 비율 데이터를 수정한다.
				avrgPcLiveRateMngService.updateAvrgPcLiveRate(avrgPcLiveRateMngVO);
				break;
		}
		
		return ResponseEntity.status(HttpStatus.OK).body(new CommResponseEntity(CommConstants.SUCCESS_CODE, CommConstants.SUCCESS_MSG));
	}
	
	/**
	 * <pre>
	 * 처리내용: 평균 라이브 비율 데이터를 삭제한다.
	 * </pre>
	 * @date 2023. 9. 4.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 9. 4.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgPcLiveRateMngVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value = "/deleteAvrgPcLiveRate")
	public ResponseEntity<?> deleteAvrgPcLiveRate(@RequestBody AvrgPcLiveRateMngVO avrgPcLiveRateMngVO, BindingResult bindingResult) throws Exception {
		// 로그인 정보 확인
		if(userInfoUtil.getAccountInfo() == null) {
			return ResponseEntity.status(HttpStatus.OK).body(new CommResponseEntity(CommConstants.ERROR_CODE, "로그인 정보가 없습니다."));
		} else {
			String userId = Optional.ofNullable(userInfoUtil.getUserId()).orElse(""); // 유저 아이디
			avrgPcLiveRateMngVO.setLastChangerId(userId);
		}
		
		// 기준 순번 확인
		if(StringUtils.isBlank(avrgPcLiveRateMngVO.getStdrSn())) {
			return ResponseEntity.status(HttpStatus.OK).body(new CommResponseEntity(CommConstants.ERROR_CODE, "기준 순번 정보가 없습니다."));
		}
		
		// 평균 라이브 비율 데이터를 삭제한다.
		avrgPcLiveRateMngService.deleteAvrgPcLiveRate(avrgPcLiveRateMngVO);
		
		return ResponseEntity.status(HttpStatus.OK).body(new CommResponseEntity(CommConstants.SUCCESS_CODE, CommConstants.SUCCESS_MSG));
	}
	
}
