package com.sorincorp.bo.it.controller;

import lombok.Data;

@Data
public class PremiumPriceBlDtlVO {
	String dstrctLclsfCode;
	String brandGroupCode;
	String brandCode;
}
