package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.it.model.ClosedHoursVO;
import com.sorincorp.bo.it.model.EventHolidayVO;
import com.sorincorp.bo.it.model.LmeHolidayVO;
import com.sorincorp.bo.it.service.EventHolidayService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;


/**
 * EventHolidayController.java
 * @version
 * @since 2021. 6. 15.
 * @author srec0008
 */
@Slf4j
@Controller
@RequestMapping("/it/eventHoliday")
public class EventHolidayController {

	@Autowired
	private EventHolidayService eventHolidayService;

	@Autowired
	private CustomValidator customValidator;
	
	@Autowired
	private CommonCodeService commonCodeService;
	
	/**
	 * <pre>
	 * 이벤트 휴일관리 페이지 이동
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 15.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param lmeHolidayVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/getEventHolidayPage")
	public String getLmeClndrPage(@ModelAttribute("restdeVO") LmeHolidayVO lmeHolidayVO, ModelMap model){
		
		try {
			
			List<EventHolidayVO> nationCode = eventHolidayService.getNationCodeList();
			
			model.put("eventRestdeSeCode"	, commonCodeService.getSubCodes("EVENT_RESTDE_SE_CODE"));	//이벤트 휴일 구분 코드
			model.put("nationCode"			, nationCode);												//Nation(국가) 코드
			return "it/eventHolidayCalendar";
			
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 이벤트 휴일 관리 등록
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 15.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param eventHolidayVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/getListEventHoliday")
	@ResponseBody
	public String getEventHolidayList(@RequestBody EventHolidayVO eventHolidayVO) throws Exception {
		
		JSONArray resultList = eventHolidayService.getEventHolidayList(eventHolidayVO);
		
		return resultList.toString();
	}

	/**
	 * <pre>
	 * 이벤트 휴일 관리 등록
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 15.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param eventHolidayVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertEventHoliday")
	@ResponseBody
	public ResponseEntity<Object> insertEventHoliday(@RequestBody EventHolidayVO eventHolidayVO, BindingResult bindingResult) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		log.debug("eventHolidayVO ============================================================");
		log.debug(eventHolidayVO.toString());
		log.debug("eventHolidayVO ============================================================");
		
		// validation을 수행한다, validation VO Class의 형식은 VO, List<Vo>, Map<VO> 가능
		// process별로 validation 수행 field 들을 나누고 싶다면 group interface class를 지정하여 사용한다. (VO에도 지정)  
		customValidator.validate(eventHolidayVO, bindingResult, ClosedHoursVO.InsertAndUpdate.class);
		
		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		eventHolidayService.insertEventHoliday(eventHolidayVO);

		return new ResponseEntity<>(returnMap, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 이벤트 휴일관리 수정
	 * </pre>
	 * @date 2021. 7. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param eventHolidayVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/updateEventHoliday")
	@ResponseBody
	public ResponseEntity<Object> updateEventHoliday(@RequestBody EventHolidayVO eventHolidayVO, BindingResult bindingResult) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		// validation을 수행한다, validation VO Class의 형식은 VO, List<Vo>, Map<VO> 가능
		// process별로 validation 수행 field 들을 나누고 싶다면 group interface class를 지정하여 사용한다. (VO에도 지정)  
		customValidator.validate(eventHolidayVO, bindingResult, ClosedHoursVO.InsertAndUpdate.class);
		
		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		eventHolidayService.updateEventHoliday(eventHolidayVO);

		return new ResponseEntity<>(HttpStatus.ACCEPTED);
	}
	
	/**
	 * <pre>
	 * 이벤트 휴일 관리 삭제
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 15.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param eventHolidayVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/deleteEventHoliday")
	@ResponseBody
	public Map<String, Object> deleteEventHoliday(@RequestBody EventHolidayVO eventHolidayVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		eventHolidayService.deleteEventHoliday(eventHolidayVO);
		
		return returnMap;
	}
}
