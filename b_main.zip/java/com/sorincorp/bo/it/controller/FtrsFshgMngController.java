package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.it.model.FtrsFshgVO;
import com.sorincorp.bo.it.service.FtrsFshgMngService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * FtrsFshgMngController.java
 * @version
 * @since 2022. 5. 27.
 * @author srec0066
 */
@Slf4j
@Controller
@RequestMapping("/it/ftrsFshg")
public class FtrsFshgMngController {

	@Autowired
	private FtrsFshgMngService ftrsFshgMngService;
	@Autowired
	private CommonCodeService commonCodeService;
	@Autowired
	private CustomValidator customValidator;

	/**
	 * <pre>
	 * 처리내용: 선물/선물환 관리 페이지를 조회한다.
	 * </pre>
	 * @date 2022. 5. 30.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 5. 30.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@GetMapping("/ftrsFshgMngPage")
	public String getListSalesManagementPage(ModelMap model){

		try {
			model.addAttribute("postnCodeList", commonCodeService.getSubCodesRetVo("POSTN_CODE"));
			
			return "it/ftrsFshgMngList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 선물/선물환 관리 등록 모달팝업창을 조회한다.
	 * </pre>
	 * @date 2022. 5. 30.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 5. 30.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @param model
	 * @return
	 */
	@RequestMapping("/ftrsFshgMngInsertModal")
	public String ftrsFshgMngInsertModal(@RequestBody FtrsFshgVO vo, ModelMap model){
		try {
			
			Map<String, CommonCodeVO> metalCodeVo = commonCodeService.getMultiFilterCodeRetVo("METAL_CODE", null, 
					 "CODE_DCTWO","Y", null, null	//CODE_DCTWO(코드 설명2, EC 판매 대상 여부)가 Y인 METAL_CODE
						, "CODE_CHRCTR_REFRNTHREE", "1", "0", "1");	//CODE_CHRCTR_REFRNTHREE(코드 문자 참조3, 판매비트)의 첫번째 값(LIVE)이 1(TRUE)인 METAL_CODE
			List<CommonCodeVO> metalCodeList = metalCodeVo.values().stream().collect(Collectors.toList());
			model.addAttribute("status", "insert");
			model.addAttribute("metalCodeList", metalCodeList);
			model.addAttribute("postnCodeList", commonCodeService.getSubCodesRetVo("POSTN_CODE"));
			
			return "it/ftrsFshgMngModal.modal";
			
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 선물/선물환 관리 수정 모달팝업창을 조회한다.
	 * </pre>
	 * @date 2022. 5. 30.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 5. 30.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @param model
	 * @return
	 */
	@RequestMapping("/ftrsFshgMngUpdateModal")
	public String ftrsFshgMngUpdateModal(@RequestBody FtrsFshgVO vo, ModelMap model){
		try {
			
			FtrsFshgVO result = ftrsFshgMngService.selectFtrsFshg(vo);
			model.addAttribute("status", "update");
			model.addAttribute("ftrsFshgVO", result);
			model.addAttribute("deleteYn", DateUtil.compareToCalerdar(result.getApplcDe().replaceAll("-", ""), DateUtil.getNowDate()) > 0 ? true : false);
			model.addAttribute("dataList", result.getFtrsFshgList());
			model.addAttribute("postnCodeList", commonCodeService.getSubCodesRetVo("POSTN_CODE"));
			
			return "it/ftrsFshgMngModal.modal";
			
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 선물/선물환 관리 데이터 목록을 조회한다.
	 * </pre>
	 * @date 2022. 5. 30.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 5. 30.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @param model
	 * @return
	 */
	@PostMapping("/searchFtrsFshgList")
	@ResponseBody
	public Map<String, Object> searchFtrsFshgList(@RequestBody FtrsFshgVO vo) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		List<FtrsFshgVO> newsList = ftrsFshgMngService.searchFtrsFshgList(vo);
		int totalDataCount = ftrsFshgMngService.selectFtrsFshgListTotCnt(vo);
		
		map.put("dataList", newsList);
		map.put("totalDataCount", totalDataCount);
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 선물/선물환 관리를 등록,수정한다.
	 * </pre>
	 * @date 2022. 5. 30.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 5. 30.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @param model
	 * @return
	 */
	@PostMapping("/insertUpdateFtrsFshg")
	@ResponseBody
	public ResponseEntity<?> insertUpdateFtrsFshg(@RequestBody List<FtrsFshgVO> vo, BindingResult bindingResult) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		ftrsFshgMngService.insertUpdateFtrsFshg(vo);
		
		return new ResponseEntity<>(returnMap, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 선물/선물환 관리를 삭제한다.
	 * </pre>
	 * @date 2022. 5. 30.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 5. 30.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param salesManagementVO
	 * @param model
	 * @return
	 */
	@PostMapping("/deleteFtrsFshg")
	@ResponseBody
	public ResponseEntity<?> deleteFtrsFshg(@RequestBody List<FtrsFshgVO> vo, BindingResult bindingResult) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		ftrsFshgMngService.deleteFtrsFshg(vo);
		
		return new ResponseEntity<>(returnMap, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 데이터 등록여부를 확인한다.
	 * </pre>
	 * @date 2022. 6. 15.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 15.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/isAlreadyRegistered")
	@ResponseBody
	public boolean isAlreadyRegistered(@RequestBody FtrsFshgVO vo) throws Exception {
		return ftrsFshgMngService.isAlreadyRegistered(vo);
	}
}
