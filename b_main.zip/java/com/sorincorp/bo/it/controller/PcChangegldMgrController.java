package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.model.PcChangegldMgrVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.bo.it.service.PcChangegldMgrService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/it")
public class PcChangegldMgrController {

	@Autowired
	private ItCmnCodeService itCmnCodeService;
	
	@Autowired
	private PcChangegldMgrService pcChangegldMgrService;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";
	
	@RequestMapping("/selectPcChangegldMgrList")
	public String selectPcChangegldMgrList(ModelMap model) {
		try {

			ItCmnCodeVO vo = new ItCmnCodeVO();
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);

			model.addAttribute("metalCodeList", metalCodeList);

			return "it/pcChangegldMgrList";

		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}

	}
	
	@RequestMapping("/selectPcChangegldMgrGridList")
	@ResponseBody
	public ResponseEntity<Object> selectPcChangegldMgrGridList(
			@RequestBody PcChangegldMgrVO pcChangegldMgrVO) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();

		int pcChangegldMgrGridCount = pcChangegldMgrService
				.selectPcChangegldMgrGridCount(pcChangegldMgrVO);
		map.put("totalDataCount", pcChangegldMgrGridCount);

		if (pcChangegldMgrGridCount != 0) {
			log.debug("vo : " + pcChangegldMgrVO);
			List<PcChangegldMgrVO> itmWtChangeAmount = pcChangegldMgrService
					.selectPcChangegldMgrGridList(pcChangegldMgrVO);
			map.put("dataList", itmWtChangeAmount);
		}

		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	@RequestMapping("/pcChangegldMgrGetCodeList")
	@ResponseBody
	public ResponseEntity<Object> pcChangegldMgrGetCodeList(@RequestParam(value = "metalCode") String metalCode) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("itemCodeList", pcChangegldMgrService.getItemCodeList(metalCode));

		return new ResponseEntity<>(map, HttpStatus.OK);

	
	}
	
	@RequestMapping("/selectPcChangegldMgrDetail")
	public String selectPcChangegldMgrDetail(@RequestBody PcChangegldMgrVO pcChangegldMgrVO, ModelMap model) throws Exception {
		try {
			ItCmnCodeVO vo = new ItCmnCodeVO();
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);

			model.addAttribute("metalCodeList", metalCodeList);
			model.addAttribute("applcDe", pcChangegldMgrVO.getApplcDe());
			model.addAttribute("itmSn", pcChangegldMgrVO.getItmSn());
			model.addAttribute("metalCode", pcChangegldMgrVO.getMetalCode());

			if (pcChangegldMgrVO.getModalPageStatus().equals("update")) {
				model.addAttribute("gubun", "U");
			} else {
				model.addAttribute("gubun", "I");
			}

			return "it/pcChangegldMgrDetail.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	
	@RequestMapping("/selectPcChangegldMgrDtlList")
	@ResponseBody
	public ResponseEntity<Object> selectPcChangegldMgrDtlList(
			@RequestBody PcChangegldMgrVO pcChangegldMgrVO) throws Exception {

		List<PcChangegldMgrVO> pcChangegldMgrList = pcChangegldMgrService
				.selectPcChangegldMgrDtlList(pcChangegldMgrVO);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("dataList", pcChangegldMgrList);

		return new ResponseEntity<>(map, HttpStatus.OK);

	}
	
	 @RequestMapping("/updatePcChangegldMgrSave")
	 @ResponseBody
	 public ResponseEntity<Object> updatePcChangegldMgrSave(@RequestBody List<PcChangegldMgrVO> pcChangegldMgrsaveList) throws Exception{
		 
			Map<String, Object> map = new HashMap<String, Object>();

			if (userInfoUtil.getAccountInfo() == null) {
				map.put(RESULT, FAIL);
				map.put(ERRMSG, "로그인되지 않은 사용자입니다.");
				map.put("userInfoUtil", userInfoUtil.getAccountInfo());
				return new ResponseEntity<>(map, HttpStatus.OK);
			}
		 
			int result = pcChangegldMgrService.updatePcChangegldMgrSave(pcChangegldMgrsaveList);
		 
			if (result > 0) {
				map.put(RESULT, SUCCESS);
			} else {
				map.put(RESULT, FAIL);
				map.put(ERRMSG, "오류가 발생하였습니다.");
			}

			return new ResponseEntity<>(map, HttpStatus.OK);
			
	 }
	 
	 @RequestMapping("/deletePcChangegldMgr")
	 @ResponseBody
	 public ResponseEntity<Object> deletePcChangegldMgr(@RequestBody PcChangegldMgrVO pcChangegldMgrVO) throws Exception{
		 
		Map<String, Object> map = new HashMap<String, Object>();
		 
		if (userInfoUtil.getAccountInfo() == null) {
			map.put(RESULT, FAIL);
			map.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			map.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(map, HttpStatus.OK);
		}
			
		int result = pcChangegldMgrService.deletePcChangegldMgr(pcChangegldMgrVO);
		
		if (result > 0) {
			map.put(RESULT, SUCCESS);
		} else {
			map.put(RESULT, FAIL);
			map.put(ERRMSG, "오류가 발생하였습니다.");
		}

		return new ResponseEntity<>(map, HttpStatus.OK);
		 
		 
		 
	 }
}

