package com.sorincorp.bo.it.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.ClosedHoursVO;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.model.MetalItmStdrVO;
import com.sorincorp.bo.it.model.RvcmpnPriceMngVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.bo.it.service.MetalItmStdrService;
import com.sorincorp.bo.it.service.PrimiumPriceMngService;
import com.sorincorp.bo.it.service.RvcmpnPriceMngService;
import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.brandcode.service.BrandCodeService;
import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;
import com.sorincorp.comm.brandgroupcode.service.BrandGroupCodeService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/it/metalItmStdrBas")
public class MetalItmStdrController {
	@Autowired
	private PrimiumPriceMngService ppms;
	@Autowired
	private MetalItmStdrService metalItmstdrService;
	@Autowired
	private CommonCodeService commonCodeService;
	@Autowired
	private ItemCodeService itemCodeService;
	@Autowired
	private BrandCodeService brandCodeService;
	@Autowired 
	private BrandGroupCodeService brandGroupCodeService;
	@Autowired
	private CustomValidator customValidator;
	@Autowired
	private ItCmnCodeService itCmnCodeService;
    
	/**
	 * <pre>
	 * 처리내용: 상품 금속 아이템 기준 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 5. 2.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 2.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param model
	 * @return
	 */
	@RequestMapping("/selectList")
	public String selectMetalItmStdrBasList(ModelMap model) {
		try {
			ItCmnCodeVO vo = new ItCmnCodeVO();
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			//공통코드 메탈코드 리스트를 조회한다.
			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);
			Map<String, CommonCodeVO> dstrctLclsfCodeVo = commonCodeService.getMultiFilterCodeRetVo("DSTRCT_LCLSF_CODE",null,	
					  "","Y", null, null);
			Map<String, String> selMthdCode = commonCodeService.getSubCodes("SLE_MTHD_CODE"); // 판매코드
			model.addAttribute("selMthdCode", selMthdCode); // 판매방식코드
			model.addAttribute("itemCodeList", itemCodeService.getItemFtrsProcessAtCodeList("", ""));
			model.addAttribute("metalCodeList", metalCodeList);
			model.addAttribute("metalClCodeList", commonCodeService.getSubCodesRetVo("METAL_CL_CODE"));
			model.addAttribute("brandGroupCodeList", brandGroupCodeService.getBrandGroupCodeList(""));
			model.addAttribute("brandCodeList", brandCodeService.getBrandCodeList(""));
			model.addAttribute("dstrctLclsfCodeList", dstrctLclsfCodeVo.values().stream().collect(Collectors.toList()));
			return "it/metalItmStdrList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	

	@RequestMapping(value = "/selectMetalItmStdrList", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> selectMetalItmStdrList(@RequestBody MetalItmStdrVO metalItmStdrVO) throws Exception {
		
		int totalCnt = metalItmstdrService.selectMetalItmStdrCnt(metalItmStdrVO);
		
		Map<String, Object> map = new HashMap<String, Object>();
		List<MetalItmStdrVO> metalItmStdrList = metalItmstdrService.selectMetalItmStdrList(metalItmStdrVO);
		
		map.put("dataList", metalItmStdrList);
		map.put("totalDataCount", totalCnt);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 경쟁사 가격관리 목록을 저장한다.
	 * </pre>
	 * 
	 * @date 2021. 5. 28.
	 * @author Cho han yong
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 03. Cho
	 *          han yong 최초작성 ------------------------------------------------
	 * @param sidecarVO
	 * @throws Exception
	 */
	@PostMapping(value = "/insertAndUpdateAjax")
	@ResponseBody
	public ResponseEntity<?> insertAndUpdateMetalItmStdrAjax(@RequestBody MetalItmStdrVO metalItmStdrVO,
			BindingResult bindingResult, SessionStatus status) throws Exception {

		// 유효성 검사
		// validation을 수행한다, validation VO Class의 형식은 VO, List<Vo>, Map<VO> 가능
		// process별로 validation 수행 field 들을 나누고 싶다면 group interface class를 지정하여 사용한다. (VO에도 지정)  
		customValidator.validate(metalItmStdrVO, bindingResult, MetalItmStdrVO.InsertAndUpdate.class);
		
		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		metalItmstdrService.insertAndUpdateMetalItmStdrList(metalItmStdrVO);

		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PostMapping(value = "/deleteMetalItmStdr")
	@ResponseBody
	public ResponseEntity<?> deleteMetalItmStdr(@RequestBody List<MetalItmStdrVO> metalItmStdrVO, SessionStatus status)
			throws Exception {
		metalItmstdrService.deleteMetalItmStdr(metalItmStdrVO);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/selectMetalCodeList", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> selectMetalCodeList(@RequestBody MetalItmStdrVO metalItmStdrVO) throws Exception {
		
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		//아이템코드
		Map<String, CommonCodeVO> metalCodeVo = commonCodeService.getMultiFilterCodeRetVo("METAL_CODE",null,	//MAIN_CODE가 "METAL_CODE"인 공통 코드
				  "CODE_DCTWO","Y", null, null);	//CODE_DCTWO(코드 설명2, EC 판매 대상 여부)가 Y인 METAL_CODE
		
		//금속 코드
		List<Map<String,String>> metalCode2 = new ArrayList<>();
		for (Entry<String, CommonCodeVO> map : metalCodeVo.entrySet()) {
			
			if("01".equals(metalItmStdrVO.getSleMthdCode())) {
				if("1".equals(map.getValue().getCodeChrctrRefrnthree().substring(0, 1))) {
					Map<String, String> metalCodeMap = new HashMap<>();
					metalCodeMap.put("sleMthdCode", "01");
					metalCodeMap.put("metalCdoe", map.getKey());
					metalCodeMap.put("codeNm", map.getValue().getCodeNm());
					metalCode2.add(metalCodeMap);
				}				
			}

			if("02".equals(metalItmStdrVO.getSleMthdCode())) {
				if("1".equals(map.getValue().getCodeChrctrRefrnthree().substring(1, 2))) {
					Map<String, String> metalCodeMap = new HashMap<>();
					metalCodeMap.put("sleMthdCode", "02");
					metalCodeMap.put("metalCdoe", map.getKey());
					metalCodeMap.put("codeNm", map.getValue().getCodeNm());
					metalCode2.add(metalCodeMap);
				}				
			}
			
		}
		
		returnMap.put("metalCodeList", metalCode2);

		return returnMap;
	}
	
	@RequestMapping(value = "/selectItmCodeList", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> selectItmCodeList(@RequestBody MetalItmStdrVO metalItmStdrVO) throws Exception {
		
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		List<ItemCodeVO> itemCodeList = new ArrayList<>();
		
		if("01".equals(metalItmStdrVO.getSleMthdCode())){ // 라이브
			//아이템 리스트
			List<ItemCodeVO> itemCodeLiveList = itemCodeService.getItemFtrsProcessAtCodeList(metalItmStdrVO.getMetalCode(), "Y");
			returnMap.put("itmCodeList", itemCodeLiveList);
			
			//권역코드
			Map<String, CommonCodeVO> dstrctLclsfCodeVo = commonCodeService.getMultiFilterCodeRetVo("DSTRCT_LCLSF_CODE",null,	
					  "CODE_REFRNONE","Y", null, null);

			List<CommonCodeVO> dstrctLclsfCodeList = dstrctLclsfCodeVo.values().stream().collect(Collectors.toList());
			returnMap.put("dstrctLclsfCode", dstrctLclsfCodeList);
			
		} else if("02".equals(metalItmStdrVO.getSleMthdCode())){
			//아이템 리스트
			List<ItemCodeVO> itemCodeFixList = itemCodeService.getItemFtrsProcessAtCodeList(metalItmStdrVO.getMetalCode(), "N");
			returnMap.put("itmCodeList", itemCodeFixList);
			
			//권역코드
			Map<String, CommonCodeVO> dstrctLclsfCodeVo = commonCodeService.getMultiFilterCodeRetVo("DSTRCT_LCLSF_CODE",null,	
					  "CODE_REFRNTWO","Y", null, null);

			List<CommonCodeVO> dstrctLclsfCodeList = dstrctLclsfCodeVo.values().stream().collect(Collectors.toList());
			returnMap.put("dstrctLclsfCode", dstrctLclsfCodeList);
		}
		
		return returnMap;
	}
	
	@RequestMapping(value = "/selectBrandGroupCodeList", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> selectBrandGroupCodeList(@RequestBody MetalItmStdrVO metalItmStdrVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		// 브랜드그룹코드
		List<BrandGroupCodeVO> brandGroupCodeList = brandGroupCodeService.getBrandGroupCodeList(metalItmStdrVO.getMetalCode());
		
		returnMap.put("brandGroupCode", brandGroupCodeList);
		
		return returnMap;
	}
	
	@RequestMapping(value = "/selectMetalClCodeList", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> selectMetalClCodeList(@RequestBody MetalItmStdrVO metalItmStdrVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		//아이템코드
		Map<String, CommonCodeVO> metalCodeVo = commonCodeService.getMultiFilterCodeRetVo("METAL_CL_CODE",null,	//MAIN_CODE가 "METAL_CODE"인 공통 코드
				  "CODE_DCTWO","Y", null, null);	//CODE_DCTWO(코드 설명2, EC 판매 대상 여부)가 Y인 METAL_CODE
		
		//금속 코드
		List<Map<String,String>> metalClCode = new ArrayList<>();
		for (Entry<String, CommonCodeVO> map : metalCodeVo.entrySet()) {
			
			if("01".equals(metalItmStdrVO.getSleMthdCode())) {
				if("01".equals(map.getValue().getCodeRefrntwo())) {
					Map<String, String> metalClCodeMap = new HashMap<>();
					metalClCodeMap.put("sleMthdCode", "01");
					metalClCodeMap.put("metalClCdoe", map.getKey());
					metalClCodeMap.put("codeNm", map.getValue().getCodeNm());
					metalClCode.add(metalClCodeMap);
				}				
			}

			if("02".equals(metalItmStdrVO.getSleMthdCode())) {
				if("02".equals(map.getValue().getCodeRefrntwo())) {
					Map<String, String> metalCodeMap = new HashMap<>();
					metalCodeMap.put("sleMthdCode", "02");
					metalCodeMap.put("metalClCdoe", map.getKey());
					metalCodeMap.put("codeNm", map.getValue().getCodeNm());
					metalClCode.add(metalCodeMap);
				}				
			}
			
		}
		returnMap.put("metalClCodeList", metalClCode);
		return returnMap;
	}
	
	
}
