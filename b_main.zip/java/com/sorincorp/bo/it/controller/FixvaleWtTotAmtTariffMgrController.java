package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.FixvaleWtTotAmtTariffMgrVO;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.service.FixvaleWtTotAmtTariffMgrService;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/it")
public class FixvaleWtTotAmtTariffMgrController {

	@Autowired
	private ItCmnCodeService itCmnCodeService;
	@Autowired
	private ItemCodeService itemCodeService;
	@Autowired
	private CustomValidator customValidator;
	@Autowired
	private FixvaleWtTotAmtTariffMgrService fixvaleWtTotAmtTariffMgrService;
	@Autowired
	private UserInfoUtil userInfoUtil;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	@RequestMapping("/selectFixvaleWtTotAmtTariffMgrList")
	public String selectFixvaleWtTotAmtTariffMgrList(ModelMap model) throws Exception {
		try {
			ItCmnCodeVO vo = new ItCmnCodeVO();
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);
			List<ItemCodeVO> itemCodeList = itemCodeService.getItemFtrsProcessAtCodeList("", "N");

			model.addAttribute("metalCodeList", metalCodeList);
			model.addAttribute("itemCodeList", itemCodeList);

			return "it/fixvaleWtTotAmtTariffMgrList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectFixvaleWtTotAmtTariffMgrListAjax")
	@ResponseBody
	public ResponseEntity<Object> selectFixvaleWtTotAmtTariffMgrListAjax(@RequestBody FixvaleWtTotAmtTariffMgrVO fixvaleWtTotAmtTariffMgrVO, BindingResult bindingResult) throws Exception {

		List<FixvaleWtTotAmtTariffMgrVO> fixvaleWtTotAmtTariffMgrList = fixvaleWtTotAmtTariffMgrService.selectFixvaleWtTotAmtTariffMgrList(fixvaleWtTotAmtTariffMgrVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("dataList", fixvaleWtTotAmtTariffMgrList);
		map.put("totalDataCount", fixvaleWtTotAmtTariffMgrService.selectFixvaleWtTotAmtTariffMgrTotCnt(fixvaleWtTotAmtTariffMgrVO));

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@RequestMapping("/fixvaleWtTotAmtTariffMgrGetItemList")
	@ResponseBody
	public ResponseEntity<Object> getItemList(@RequestParam(value = "metalCode") String metalCode, @RequestParam(value = "ftrsProcessAt") String ftrsProcessAt) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("itemCodeList", itemCodeService.getItemFtrsProcessAtCodeList(metalCode, ftrsProcessAt));

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	// deleteFixvaleWtTotAmtTariffMgr
	@RequestMapping("/deleteFixvaleWtTotAmtTariffMgr")
	@ResponseBody
	public ResponseEntity<Object> deleteFixvaleWtTotAmtTariffMgr(@RequestBody FixvaleWtTotAmtTariffMgrVO fixvaleWtTotAmtTariffMgrVO, BindingResult bindingResult) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			map.put(RESULT, FAIL);
			map.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			map.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(map, HttpStatus.OK);
		}

		int result = fixvaleWtTotAmtTariffMgrService.deleteFixvaleWtTotAmtTariffMgr(fixvaleWtTotAmtTariffMgrVO);

		if (result > 0) {
			map.put(RESULT, SUCCESS);
		} else {
			map.put(RESULT, FAIL);
			map.put(ERRMSG, "오류가 발생하였습니다.");
		}

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	// deliveryRegionMngDetail
	@RequestMapping("/selectFixvaleWtTotAmtTariffMgrDetail")
	public String selectFixvaleWtTotAmtTariffMgrDetail(@RequestBody FixvaleWtTotAmtTariffMgrVO fixvaleWtTotAmtTariffMgrVO, ModelMap model) throws Exception {
		// @RequestParam("entrpsNo") String entrpsNo,
		// log.debug("fixvaleWtTotAmtTariffMgrVO ===========>" +
		// fixvaleWtTotAmtTariffMgrVO.toString());

//		List<FixvaleWtTotAmtTariffMgrVO> detailList = null;
//		if (fixvaleWtTotAmtTariffMgrVO.getApplcDe() != null && !"".equals(fixvaleWtTotAmtTariffMgrVO.getApplcDe()) && fixvaleWtTotAmtTariffMgrVO.getItmSn() > 0) {
//			detailList = fixvaleWtTotAmtTariffMgrService.selectFixvaleWtTotAmtTariffDtlList(fixvaleWtTotAmtTariffMgrVO);
//		}

		ItCmnCodeVO vo = new ItCmnCodeVO();
		vo.setMainCode("METAL_CODE");
		vo.setCodeDctwo("Y");
		vo.setUseAt("Y");
		List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);
		List<ItemCodeVO> itemCodeList = itemCodeService.getItemFtrsProcessAtCodeList("", "N");

		model.addAttribute("metalCodeList", metalCodeList);
		model.addAttribute("itemCodeList", itemCodeList);
		model.addAttribute("applcDe", fixvaleWtTotAmtTariffMgrVO.getApplcDe());
		model.addAttribute("itmSn", fixvaleWtTotAmtTariffMgrVO.getItmSn());
		model.addAttribute("metalCode", fixvaleWtTotAmtTariffMgrVO.getMetalCode());

		if (fixvaleWtTotAmtTariffMgrVO.getApplcDe() != null && !"".equals(fixvaleWtTotAmtTariffMgrVO.getApplcDe())) {
			model.addAttribute("gubun", "U");
		} else {
			model.addAttribute("gubun", "I");
		}

		return "it/fixvaleWtTotAmtTariffMgrDetail.modal";
	}

	@RequestMapping("/selectFixvaleWtTotAmtTariffMgrDtlList")
	@ResponseBody
	public ResponseEntity<Object> selectFixvaleWtTotAmtTariffMgrDtlList(@RequestBody FixvaleWtTotAmtTariffMgrVO fixvaleWtTotAmtTariffMgrVO, BindingResult bindingResult) throws Exception {

		List<FixvaleWtTotAmtTariffMgrVO> fixvaleWtTotAmtTariffMgrList = fixvaleWtTotAmtTariffMgrService.selectFixvaleWtTotAmtTariffDtlList(fixvaleWtTotAmtTariffMgrVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("dataList", fixvaleWtTotAmtTariffMgrList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	// fixvaleWtTotAmtTariffMgrSave
	@RequestMapping("/fixvaleWtTotAmtTariffMgrSave")
	@ResponseBody
	public ResponseEntity<Object> fixvaleWtTotAmtTariffMgrSave(@RequestBody List<FixvaleWtTotAmtTariffMgrVO> saveList, BindingResult bindingResult) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			map.put(RESULT, FAIL);
			map.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			map.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(map, HttpStatus.OK);
		}
//		for(int i=0;i<saveList.size();i++) {
//			log.debug(saveList.get(i).toString());
//		}
		int result = fixvaleWtTotAmtTariffMgrService.fixvaleWtTotAmtTariffMgrSave(saveList);

		if (result > 0) {
			map.put(RESULT, SUCCESS);
		} else {
			map.put(RESULT, FAIL);
			map.put(ERRMSG, "이미 존재 하는 고정가 중량 할증 요율입니다.");
		}

		return new ResponseEntity<>(map, HttpStatus.OK);
	}
}
