package com.sorincorp.bo.it.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.it.model.DistributionHolidayVO;
import com.sorincorp.bo.it.service.DistributionHolidayService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.wrhouscode.model.WrhousCodeVO;
import com.sorincorp.comm.wrhouscode.service.WrhousCodeService;

import lombok.extern.slf4j.Slf4j;


/**
 * DistributionHolidayController.java
 * @version
 * @since 2021. 6. 10.
 * @author srec0008
 */
@Slf4j
@Controller
@RequestMapping("/it/distributionHoliday")
public class DistributionHolidayController {

	@Autowired
	private DistributionHolidayService distributionHolidayService;
	
	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired
	private WrhousCodeService wrhousCodeService;
	
	/**
	 * <pre>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
	 * 물류 휴일 관리 페이지 이동
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0008
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param lmeHolidayVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/getdistributionHolidayPage")
	public String getLmeClndrPage(@ModelAttribute("distributionHolidayVO") DistributionHolidayVO distributionHolidayVO, ModelMap model) throws Exception {
		try {
			model.put("dstrctLclsfCode", commonCodeService.getSubCodes("DSTRCT_LCLSF_CODE"));
			
			return "it/distributionHolidayCalendar";
			
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 상품 물류 휴일 리스트 조회
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0008
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0008			최초작성
	 * ------------------------------------------------
	 * @param distributionHolidayVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/getListDistributionHoliday")
	@ResponseBody
	public String getListDistributionHoliday(@RequestBody DistributionHolidayVO distributionHolidayVO) throws Exception {
		
		JSONArray resultList = distributionHolidayService.getDistributionHolidayList(distributionHolidayVO);
		
		return resultList.toString();
	}

	
	/**
	 * <pre>
	 * 대분류 코드로 창고 코드를 가져온다.
	 * </pre>
	 * @date 2021. 8. 2.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 2.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param distributionHolidayVO
	 * @return
	 */
	@PostMapping("/getWrhousCode")
	@ResponseBody
	public Map<String, Object> getWrhousCode(@RequestBody DistributionHolidayVO distributionHolidayVO){
		Map<String, Object> returnMap = new HashMap<String, Object>();
		List<Map<String, Object>> resultMap;
		try {
			
			List<WrhousCodeVO> returnVO =  wrhousCodeService.getDetailWrhousCode(distributionHolidayVO.getDstrctLclsfCode(), null);
			returnMap.put("returnVO", returnVO);
			
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			
		}
		
		return returnMap;
	}
	
	
}
