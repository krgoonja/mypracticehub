package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.model.MbLonGrntyVO;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.bo.mb.service.MbLonGrntyService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/Member")
public class MbLonGrntyController {

	@Autowired
	private MbCmnCodeService mbCmnCodeService;
	@Autowired
	private MbLonGrntyService mbLonGrntyService;
	@Autowired
	private EntrpsMbService entrpsMbService;

	@RequestMapping("/selectMbLonGrntyList")
	public String selectMbLonGrntyList(String entrpsNo, ModelMap model) {

		try {

			List<MbCmnCodeVO> bankCodeList = mbCmnCodeService.selectCmnCodeList("BANK_CODE");
			model.addAttribute("bankCodeList", bankCodeList);

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			String oneWeek = DateUtil.addDays(today.replaceAll("-", ""), -7);
			String oneMonth = DateUtil.addMonths(today.replaceAll("-", ""), -1);
			String sixMonth = DateUtil.addMonths(today.replaceAll("-", ""), -6);
			String oneYear = DateUtil.addYears(today.replaceAll("-", ""), -1);

			model.addAttribute("today", today);
			model.addAttribute("oneWeek", oneWeek);
			model.addAttribute("oneMonth", oneMonth);
			model.addAttribute("sixMonth", sixMonth);
			model.addAttribute("oneYear", oneYear);

			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);

			model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
			model.addAttribute("entrpsNo", entrpsNo);

			return "mb/mbLonGrntyList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectMbLonGrntyDtlListAjax")
	@ResponseBody
	public Map<String, Object> selectMbLonGrntyDtlListAjax(@RequestBody MbLonGrntyVO mbLonGrntyVO) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		List<MbLonGrntyVO> mbMrtggGrntyList = mbLonGrntyService.selectMbLonGrntyList(mbLonGrntyVO);

		map.put("totalDataCount", mbLonGrntyService.selectMbLonGrntyTotalCnt(mbLonGrntyVO));
		map.put("dataList", mbMrtggGrntyList);

		return map;
	}
}
