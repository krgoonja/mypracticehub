/**
 *
 */
package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.mb.model.EntrpsSendMsgVO;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.bo.mb.service.EntrpsSendMsgService;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/Member")
@ComponentScan({ "com.sorincorp.comm.*" })
public class EntrpsSendMsgController {

	@Autowired
	private EntrpsSendMsgService entrpsSendMsgService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	@Autowired
	private EntrpsMbService entrpsMbService;

	@Autowired
	private CustomValidator customValidator;

	/**
	 * <pre>
	 * 처리내용: 기업회원조회 > 메시지발송 조회
	 * </pre>
	 *
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsSendMsg")
	public String selectEntrpsSendMsg(String entrpsNo, ModelMap model) {
		try {
			List<MbCmnCodeVO> msgSeCodeList = mbCmnCodeService.selectCmnCodeList("MSSAGE_SE_CODE");
			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);

			model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
			model.addAttribute("entrpsNo", entrpsNo);
			model.addAttribute("msgSeCodeList", msgSeCodeList);

			return "mb/entrpsSendMsgList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 기업회원조회 > 메시지발송 조회
	 * </pre>
	 *
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsSendMsgVO
	 * @param entrpsNo
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsSendMsgList")
	@ResponseBody
	public ResponseEntity<Object> selectEntrpsSendMsgList(@RequestBody EntrpsSendMsgVO entrpsSendMsgVO, String entrpsNo, BindingResult bindingResult) throws Exception {

		customValidator.validate(entrpsSendMsgVO, bindingResult, EntrpsSendMsgVO.Search.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		Map<String, Object> map = new HashMap<String, Object>();
		entrpsSendMsgVO.setEntrpsNo(entrpsNo);
		List<EntrpsSendMsgVO> entrpsSendMsgList = entrpsSendMsgService.selectEntrpsSendMsgList(entrpsSendMsgVO);
		int totalDataCount = entrpsSendMsgService.selectEntrpsSendMsgListToCnt(entrpsSendMsgVO);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", entrpsSendMsgList);

		log.info("selectSampleList log Sample 2 : " + entrpsSendMsgVO.getRowCountPerPage());
		log.info("selectSampleList log Sample 2 : " + entrpsSendMsgVO.getRecordCountPerPage());
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 기업회원조회 > 메시지발송 상세 조회
	 * </pre>
	 *
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @param entrpsSendMsgVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsSendMsgDtl")
	public String selectEntrpsSendMsgDtl(ModelMap model, @RequestBody EntrpsSendMsgVO entrpsSendMsgVO) {
		try {
			log.debug("entrpsSendMsgVO ::", entrpsSendMsgVO.toString());
			log.debug("model :: ", model);
			EntrpsSendMsgVO vo = entrpsSendMsgService.selectEntrpsSendMsgDtl(entrpsSendMsgVO);
			// 핸드폰 번호 형식 세팅
			String tel = vo.getRcverTlphonNo();

			if (tel != null && !"".equals(tel)) {
				try {
					log.debug("휴대폰번호 복호화 전 =============>" + tel);
					tel = CryptoUtil.decryptAES256(tel);
					log.debug("휴대폰번호 복호화 후 =============>" + tel);
				} catch (Exception e) {
					// TODO: handle exception
					log.error("selectEntrpsSendMsgDtl RECVER_TLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
			}
			String formatNum = "";
			formatNum = tel.replaceAll("(\\d{3})(\\d{3,4})(\\d{4})", "$1-$2-$3");
			vo.setRcverTlphonNo(formatNum);

			model.addAttribute("entrpsSendMsgVO", vo);
			return "mb/entrpsSendMsgDtlModal.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
}
