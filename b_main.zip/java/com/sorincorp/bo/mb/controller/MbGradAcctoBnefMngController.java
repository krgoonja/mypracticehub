package com.sorincorp.bo.mb.controller;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbGradAcctoBnefMngVO;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.bo.mb.service.MbGradAcctoBnefMngService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/mb")
public class MbGradAcctoBnefMngController {

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	@Autowired
	private MbGradAcctoBnefMngService mbGradAcctoBnefMngService;

	@Autowired
	private CommonCodeService commonCodeService;


	@Autowired
	private UserInfoUtil userInfoUtil;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";


	@RequestMapping("/selectMbGradAcctoBnefMng")
	public String selectMbGradAcctoBnefMng(ModelMap model,MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) {

		try {
			MbGradAcctoBnefMngVO mbGradList = mbGradAcctoBnefMngService.selectMbGradAcctoBnefMngGradList();
			int totalDataCnt = mbGradAcctoBnefMngService.selectMbGradAcctoBnefMngListCnt(mbGradAcctoBnefMngVO);

			model.addAttribute("mbGradList",mbGradList);
			model.addAttribute("totalDataCnt",totalDataCnt);
			return "mb/mbGradAcctoBnefMngList";

		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg",e);
			return "error/503";
		}
	}

	@RequestMapping("/selectMbGradAcctoBnefMngList")
	@ResponseBody
	public ResponseEntity<?> selectMbGradAcctoBnefMngList(@RequestBody MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception {

		Map<String,Object> map = new HashMap<String, Object>();
		List<MbGradAcctoBnefMngVO> dataList = mbGradAcctoBnefMngService.selectMbGradAcctoBnefMngList(mbGradAcctoBnefMngVO);
		int totalDataCnt = mbGradAcctoBnefMngService.selectMbGradAcctoBnefMngListCnt(mbGradAcctoBnefMngVO);

		map.put("dataList", dataList);
		map.put("totalDataCount",totalDataCnt);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@RequestMapping("/insertMbGradAcctoBnefMngView")
	public String insertMbGradAcctoBnefMngView(Model model){
		try {

			List<MbCmnCodeVO> entrpsGradList = mbCmnCodeService.selectCmnCodeList("ENTRPS_GRAD_CODE");
			Map<String, String> metalCodeMap = new LinkedHashMap<String, String>();
			Map<String, CommonCodeVO> metalCodeVo = commonCodeService.getFilterCodeRetVo("METAL_CODE",null,"CODE_DCTWO", "Y");
			metalCodeVo.forEach((key, value) -> {
				metalCodeMap.put(value.getSubCode(), value.getCodeChrctrRefrnsix());
			});

			model.addAttribute("entrpsGradList",entrpsGradList);
			model.addAttribute("metalCodeMap",metalCodeMap);
			return "mb/mbGradAcctoBnefMngInsModal.modal";

		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@PostMapping("/insertMbGradAcctoBnefMng")
	@ResponseBody
	public ResponseEntity<Object> insertMbGradAcctoBnefMng(@RequestBody MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception {
		Map<String,Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result =  mbGradAcctoBnefMngService.insertMbGradAcctoBnefMng(mbGradAcctoBnefMngVO);

		if(result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		}else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal,HttpStatus.OK);
	}

	@RequestMapping("/updateMbGradAcctoBnefMngView")
	public String updateMbGradAcctoBnefMngView(@RequestBody MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO,Model model){

		try {
			List<MbGradAcctoBnefMngVO> mbGradAcctoBnefMngBBList = mbGradAcctoBnefMngService.selectMbGradAcctoBnefMngBBList(mbGradAcctoBnefMngVO);
			List<MbCmnCodeVO> entrpsGradList = mbCmnCodeService.selectCmnCodeList("ENTRPS_GRAD_CODE");
			Map<String, String> metalCodeMap = new LinkedHashMap<String, String>();
			Map<String, CommonCodeVO> metalCodeVo = commonCodeService.getFilterCodeRetVo("METAL_CODE",null,"CODE_DCTWO", "Y");
			metalCodeVo.forEach((key, value) -> {
				metalCodeMap.put(value.getSubCode(), value.getCodeChrctrRefrnsix());
			});

			model.addAttribute("opertnDe",mbGradAcctoBnefMngVO.getOpertnDe());
			model.addAttribute("mbGradAcctoBnefMngBBList",mbGradAcctoBnefMngBBList);
			model.addAttribute("entrpsGradList",entrpsGradList);
			model.addAttribute("metalCodeMap",metalCodeMap);

			return "mb/mbGradAcctoBnefMngModify.modal";

		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg",e);
			return "error/503";
		}

	}

	@RequestMapping("/updateMbGradAcctoBnefMngListAjax")
	@ResponseBody
	public ResponseEntity<?> updateMbGradAcctoBnefMngListAjax(@RequestBody MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception {

		Map<String,Object> map = new HashMap<String, Object>();
		List<MbGradAcctoBnefMngVO> dataList = mbGradAcctoBnefMngService.selectMbGradAcctoBnefMngMDtlList(mbGradAcctoBnefMngVO);
		//int totalDataCnt = mbGradAcctoBnefMngService.selectMbGradAcctoBnefMngListCnt(mbGradAcctoBnefMngVO);

		map.put("dataList", dataList);
		//map.put("totalDataCount",totalDataCnt);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@PostMapping("/updateMbGradAcctoBnefMng")
	@ResponseBody
	public ResponseEntity<Object> updateMbGradAcctoBnefMng(@RequestBody MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO,Model model) throws Exception {

		Map<String,Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result =  mbGradAcctoBnefMngService.updateMbGradAcctoBnefMng(mbGradAcctoBnefMngVO);

		if(result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		}else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal,HttpStatus.OK);

	}

	@PostMapping("/deleteMbGradAcctoBnefMng")
	@ResponseBody
	public ResponseEntity<Object> deleteMbGradAcctoBnefMng(@RequestBody MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO ) throws Exception {

		Map<String,Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result = mbGradAcctoBnefMngService.deleteMbGradAcctoBnefMng(mbGradAcctoBnefMngVO);

		if(result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		}else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal,HttpStatus.OK);
	}

	@RequestMapping("/opertnDeDuplicateCheck")
	@ResponseBody
	public int opertnDeDuplicateCheck(@RequestBody MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception {
		return mbGradAcctoBnefMngService.opertnDeDuplicateCheck(mbGradAcctoBnefMngVO);
	}

}
