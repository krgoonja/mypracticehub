package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.mb.model.EntrpsSendEmailVO;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.bo.mb.service.EntrpsSendEmailService;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/Member")
@ComponentScan({ "com.sorincorp.comm.*" })
public class EntrpsSendEmailController {

	@Autowired
	private EntrpsSendEmailService entrpsSendEmailService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	@Autowired
	private EntrpsMbService entrpsMbService;

	/**
	 * <pre>
	 * 처리내용: 기업회원조회 > 메일발송 조회
	 * </pre>
	 * 
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsSendEmail")
	public String selectEntrpsSendEmailList(ModelMap model, String entrpsNo) {
		try {
			List<MbCmnCodeVO> jobSeCode = mbCmnCodeService.selectCmnCodeList("JOB_SE_CODE");
			model.addAttribute("jobSeCode", jobSeCode);

			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);

			model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
			model.addAttribute("entrpsNo", entrpsNo);

			return "mb/entrpsSendEmailList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 기업회원조회 > 메일발송 조회
	 * </pre>
	 * 
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsSendEmailVO
	 * @param entrpsNo
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsSendEmailList")
	@ResponseBody
	public ResponseEntity<Object> selectEntrpsSendEmailList(@RequestBody EntrpsSendEmailVO entrpsSendEmailVO, String entrpsNo, BindingResult bindingResult) throws Exception {

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		Map<String, Object> map = new HashMap<String, Object>();

		log.debug("entrpsSendEmailVO.getJobSeCode() ============" + entrpsSendEmailVO.getJobSeCode());

		entrpsSendEmailVO.setEntrpsNo(entrpsNo);
		int totalDataCount = entrpsSendEmailService.selectEntrpsSendEmailListToCnt(entrpsSendEmailVO);
		List<EntrpsSendEmailVO> entrpsSendEmailList = entrpsSendEmailService.selectEntrpsSendEmailList(entrpsSendEmailVO);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", entrpsSendEmailList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 기업회원조회 > 메일발송 상세 조회
	 * </pre>
	 * 
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @param entrpsSendEmailVO
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsSendEmailDtl")
	public String selectEntrpsSendEmailDtl(Model model, @RequestBody EntrpsSendEmailVO entrpsSendEmailVO) {
		try {
			entrpsSendEmailVO.setEntrpsNo(entrpsSendEmailVO.getEntrpsNo());
			String[] logTableDt = entrpsSendEmailVO.getLogTableDt().split("-");
			entrpsSendEmailVO.setLogTableDt(logTableDt[0] + logTableDt[1]);
			EntrpsSendEmailVO vo = entrpsSendEmailService.selectEntrpsSendEmailDtl(entrpsSendEmailVO);
			model.addAttribute("entrpsSendEmailVO", vo);
			return "mb/entrpsSendEmailDtlModal.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
}
