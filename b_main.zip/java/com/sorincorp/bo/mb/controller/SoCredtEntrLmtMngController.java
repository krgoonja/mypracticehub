package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.bo.mb.model.SoCredtEntrLmtMngVO;
import com.sorincorp.bo.mb.service.SoCredtEntrLmtMngService;
import com.sorincorp.comm.constants.ExceptionConstants;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/SorinCredt")
public class SoCredtEntrLmtMngController {
	
	@Autowired
	SoCredtEntrLmtMngService soCredService;

	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Autowired
	MessageUtil messageUtil;
	
	@Autowired
	private CustomValidator customValidator;
	
	private Account getAccountInfo() throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		if (null == account || StringUtil.isBlank(account.getId())) {
			throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_LOGIN_REQUIRED));
		}
		return account;
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 고객사 별 한도 설정 화면으로 이동
	 * </pre>
	 * @date 2022. 11. 16.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 16.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	
	@RequestMapping("/selectEntrprsLmtMng")
	public String selectEntrprsLmtMng() {
		try {
			return "mb/sorinCredtEntrprsLmtMngList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약 목록 조회
	 * </pre>
	 * @date 2022. 11. 16.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 16.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	
	@PostMapping("/selectEntrprsLmtMngList")
	public ResponseEntity<Object> selectEntrprsLmtMngList() throws Exception{
		
		//Marsh 계약 목록 가져오기
		Map<String, Object> map = soCredService.selectEntrprsLmtMngList();
		return new ResponseEntity<>(map, HttpStatus.OK);

	}
	
	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약 등록/수정 팝업
	 * </pre>
	 * @date 2022. 11. 16.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 16.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertAndUpdateEntrprsLmtMngPopup")
	public String insertAndUpdatePopup(@RequestBody SoCredtEntrLmtMngVO vo, ModelMap model) {
		try {
			model.addAttribute("SoCredtEntrLmtMngVO", vo);
			return "mb/sorinCredtEntrprsMngDetail.modal";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약 한도 등록/수정/삭제 팝업
	 * </pre>
	 * @date 2022. 11. 17.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 17.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertAndUpdateEntrprsLmtMngSubPopup")
	public String insertAndUpdateLmtPopup(@RequestBody SoCredtEntrLmtMngVO vo, ModelMap model) {
		try {
			model.addAttribute("SoCredtEntrLmtMngVO", vo);	
			return "mb/sorinCredtEntrprsLmtMngDetail.modal";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}
	


	
	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약 등록/수정 
	 * </pre>
	 * @date 2022. 11. 16.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 16.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @param soCredList
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertAndUpdateEntrprsLmtMng")
	public ResponseEntity<?> insertAndUpdateEntrprsLmtMng(@RequestBody SoCredtEntrLmtMngVO data, BindingResult bindingResult) throws Exception {
			
		// userInfo
		Account account = getAccountInfo();
	
		// dataCheck
		if(data.isValidation()) { // 유효성 검사 분기 (필요할 경우)
			customValidator.validate(data, bindingResult);
		}
		
		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		data.setFrstRegisterId(account.getId());
		data.setLastChangerId(account.getId());
		
		
		String result = soCredService.insertAndUpdateEntrprsLmtMng(data);
		
		return new ResponseEntity<>(result , HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약 삭제 
	 * </pre>
	 * @date 2022. 11. 22.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 22.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/deleteEntrprsLmtMng")
	@ResponseBody
	public String deleteEntrprsLmtMng(@RequestBody SoCredtEntrLmtMngVO vo) throws Exception {
		// userInfo
		Account account = getAccountInfo();
		
		vo.setLastChangerId(account.getId());
		String result = soCredService.deleteEntrprsLmtMng(vo);
		
		return result;
	}
	
	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약에 대한 기업 매핑 목록 및 한도 설정 조회 
	 * </pre>
	 * @date 2022. 11. 22.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 22.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrprsLmtMngSubList")
	public ResponseEntity<?> selectEntrprsLmtMngSubList(@RequestBody SoCredtEntrLmtMngVO vo) throws Exception {
			Map<String, Object> map = new HashMap<String, Object>();
			map = soCredService.selectEntrprsLmtMngSubList(vo);

			return new ResponseEntity<>(map, HttpStatus.OK);
			
	}
	

	
	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약에 대한 한도 설정 등록 및 수정
	 * </pre>
	 * @date 2022. 11. 23.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 23.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @parambindingResult
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertAndUpdateSubLmtList")
	public ResponseEntity<?> insertAndUpdateSubLmtList(@RequestBody SoCredtEntrLmtMngVO vo, BindingResult bindingResult) throws Exception {
		
		// userInfo
		Account account = getAccountInfo();
	
		// dataCheck
		if(vo.isValidation()) { // 유효성 검사 분기 (필요할 경우)
			customValidator.validate(vo, bindingResult);
		}
		
		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		vo.setFrstRegisterId(account.getId());
		vo.setLastChangerId(account.getId());
		
		Map<String, Object> map = soCredService.insertAndUpdateEntrprsLmtMngSubList(vo);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약에 대한 한도 설정 삭제
	 * </pre>
	 * @date 2022. 11. 23.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 23.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @parambindingResult
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/deleteSubLmtList")
	public ResponseEntity<?> deleteSubLmtList(@RequestBody SoCredtEntrLmtMngVO vo) throws Exception {
		
		// userInfo
		Account account = getAccountInfo();
		
		vo.setLastChangerId(account.getId());
		Map<String, Object> map  = soCredService.deleteEntrprsLmtMngSubList(vo);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
}
