/**
 *
 */
package com.sorincorp.bo.mb.controller;

import java.security.SecureRandom;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.mb.model.EntrpsSendMsgVO;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.SimpleMberInfoVO;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.bo.mb.service.SimpleMberService;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * SimpleMberController.java
 *
 * @version
 * @since 2021. 9. 28.
 * @author srec0009
 */
@Slf4j
@Controller
@RequestMapping("/bo/Member")
@ComponentScan({ "com.sorincorp.comm.*" })
public class SimpleMberController {

	@Autowired
	private SimpleMberService simpleMberService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	@Autowired
	private SMSService smsService;

	/**
	 * <pre>
	 * 처리내용: 간편회원 리스트 조회
	 * </pre>
	 *
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectSimpleMberInfo")
	public String selectSimpleMberInfo(Model model) {
		try {
			List<MbCmnCodeVO> mberConfmSttusCodeList = mbCmnCodeService.selectCmnCodeList("SIMPL_MBER_STTUS_CODE");
			model.addAttribute("mberSttusCode", mberConfmSttusCodeList);
			return "mb/simpleMberInfoList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 간편회원 리스트 조회
	 * </pre>
	 *
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param simpleMberInfoVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectSimpleMberInfoList")
	public ResponseEntity<Object> selectSimpleMberInfoList(@RequestBody SimpleMberInfoVO simpleMberInfoVO, BindingResult bindingResult) throws Exception {

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		Map<String, Object> map = new HashMap<String, Object>();

		int totalDataCount = simpleMberService.selectSimpleMberInfoListTotCnt(simpleMberInfoVO);
		List<SimpleMberInfoVO> simpleMberInfoList = simpleMberService.selectSimpleMberInfoList(simpleMberInfoVO);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", simpleMberInfoList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@PostMapping("/selectSimpleMberInfoListForExcel")
	public ResponseEntity<?> selectSimpleMberInfoListForExcel(@RequestBody SimpleMberInfoVO simpleMberInfoVO, BindingResult bindingResult) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		simpleMberInfoVO.setRecordCountPerPage(10000000); // Excel Export 전용 Query를 만들경우 작정 안해도 됨
		List<SimpleMberInfoVO> excelList = simpleMberService.selectSimpleMberInfoList(simpleMberInfoVO);
		map.put("dataList", excelList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 간편회원 상세정보
	 * </pre>
	 *
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @param simpleMberInfoVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectSimpleMberInfoDetail")
	public String selectSimpleMberInfoDetail(ModelMap model, SimpleMberInfoVO simpleMberInfoVO) {
		try {
			SimpleMberInfoVO simpleMberInfoDetail = simpleMberService.selectSimpleMberInfoDetail(simpleMberInfoVO);
			model.addAttribute("simpleMberInfoDetail", simpleMberInfoDetail);
			model.addAttribute("simplMberNo", simpleMberInfoVO.getSimplMberNo());
			return "mb/simpleMberDtl";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 간편회원 접속 이력 조회
	 * </pre>
	 *
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param simpleMberInfoVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectSimpleMberConectHstList")
	public ResponseEntity<Object> selectSimpleMberConectHstList(@RequestBody SimpleMberInfoVO simpleMberInfoVO, BindingResult bindingResult) throws Exception {

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		Map<String, Object> map = new HashMap<String, Object>();

		int totalDataCount = simpleMberService.selectSimpleMberConectHstListTotCnt(simpleMberInfoVO);
		List<SimpleMberInfoVO> simpleMberInfoList = simpleMberService.selectSimpleMberConectHstList(simpleMberInfoVO);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", simpleMberInfoList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 간편 회원 알람 이력 조회
	 * </pre>
	 *
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsSendMsgVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectSimpleMberAlertHstList")
	public ResponseEntity<Object> selectSimpleMberAlertHstList(@RequestBody EntrpsSendMsgVO entrpsSendMsgVO, BindingResult bindingResult) throws Exception {

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		Map<String, Object> map = new HashMap<String, Object>();

		int totalDataCount = simpleMberService.selectSimpleMberAlertHstListTotCnt(entrpsSendMsgVO);
		List<SimpleMberInfoVO> simpleMberInfoList = simpleMberService.selectSimpleMberAlertHstList(entrpsSendMsgVO);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", simpleMberInfoList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 메세지 알람 상세조회
	 * </pre>
	 *
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @param entrpsSendMsgVO
	 * @return
	 * @throws Exception
	 */

	@RequestMapping("/selectAlertInfoDtlModal")
	public String selectAlertInfoDtlModal(Model model, @RequestBody EntrpsSendMsgVO entrpsSendMsgVO) {
		try {
			String tableSeCode = entrpsSendMsgVO.getTableSeCode();
			String[] logTableDt = entrpsSendMsgVO.getLogTableDt().split("-");
			entrpsSendMsgVO.setLogTableDt(logTableDt[0] + logTableDt[1]);

			// 푸시
			if (("01").equals(tableSeCode)) {
				EntrpsSendMsgVO msgAlertDtl = simpleMberService.selectPushAlertDtl(entrpsSendMsgVO);
				model.addAttribute("msgAlertDtl", msgAlertDtl);
				model.addAttribute("tableSeCode", tableSeCode);
			}
			// SMS
			else if (("03").equals(tableSeCode)) {
				EntrpsSendMsgVO msgAlertDtl = simpleMberService.selectSmsAlertDtl(entrpsSendMsgVO);
				String rcverTlphonNo = msgAlertDtl.getRcverTlphonNo();
				try {
					log.debug("휴대폰번호 복호화 전 =============>" + rcverTlphonNo);
					rcverTlphonNo = CryptoUtil.decryptAES256(rcverTlphonNo);
					log.debug("휴대폰번호 복호화 후 =============>" + rcverTlphonNo);
					msgAlertDtl.setRcverTlphonNo(rcverTlphonNo);
				} catch (Exception e) {
					// TODO: handle exception
					log.error("selectAlertInfoDtlModal RECVER_TLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
				model.addAttribute("msgAlertDtl", msgAlertDtl);
				model.addAttribute("tableSeCode", tableSeCode);
			}
			// LMS
			else if (("04").equals(tableSeCode)) {
				EntrpsSendMsgVO msgAlertDtl = simpleMberService.selectLmsAlertDtl(entrpsSendMsgVO);
				String rcverTlphonNo = msgAlertDtl.getRcverTlphonNo();
				try {
					log.debug("휴대폰번호 복호화 전 =============>" + rcverTlphonNo);
					rcverTlphonNo = CryptoUtil.decryptAES256(rcverTlphonNo);
					log.debug("휴대폰번호 복호화 후 =============>" + rcverTlphonNo);
					msgAlertDtl.setRcverTlphonNo(rcverTlphonNo);
				} catch (Exception e) {
					// TODO: handle exception
					log.error("selectAlertInfoDtlModal RECVER_TLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
				model.addAttribute("msgAlertDtl", msgAlertDtl);
				model.addAttribute("tableSeCode", tableSeCode);
			} else if (("05").equals(tableSeCode)) {
				EntrpsSendMsgVO emailAlertDtl = simpleMberService.selectEmailAlertDtl(entrpsSendMsgVO);
				model.addAttribute("emailAlertDtl", emailAlertDtl);
				model.addAttribute("tableSeCode", tableSeCode);
				log.debug(emailAlertDtl.toString());
			}
			return "mb/alertInfoDtlModal.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 간편 회원 비밀번호 초기화
	 * </pre>
	 *
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param simpleMberInfoVO
	 * @return
	 * @throws Exception
	 */

	@ResponseBody
	@RequestMapping("/updateSimplPwdInit")
	public ResponseEntity<Object> updateSimplPwdInit(@RequestBody SimpleMberInfoVO simpleMberInfoVO) throws Exception {
		int result = 0;
		Map<String, Object> retVal = new HashMap<String, Object>();

		String randomPwd = getRamdomPassword();
		simpleMberInfoVO.setSimplMberSecretNo(randomPwd);
		String templateNum = "28";
		String title = mbCmnCodeService.selectMssageSj(templateNum);
		result = simpleMberService.updateSimplPwdInit(simpleMberInfoVO);

//		// update 성공시 알림톡, 문자 발송
		if (result > 0) {
			// 핸드폰 번호 하이픈 제거
			String mobNo = (simpleMberInfoVO.getMoblphonNo()).replaceAll("[^0-9]", "");
			String mberNo = simpleMberInfoVO.getSimplMberNo();
			String mberNm = simpleMberInfoVO.getSimplMberNm();

			// 비밀번호 초기화 시 알림 톡 발송
			Map<String, String> msgMap = new HashMap<>();
			SMSVO smsVO = new SMSVO();
			msgMap.put("templateNum", templateNum);
			msgMap.put("password", randomPwd);// 메시지 템플릿 번호
			msgMap.put("ordrrNm", mberNm);
			smsVO.setPhone(mobNo); // 받는사람 번호
			smsVO.setMberNo(mberNo);
			smsVO.setMsgTitle(title);
			smsService.insertSMS(smsVO, msgMap); // 메소드 호출

			retVal.put("code", "S");
			retVal.put("msg", "");
		} else {
			retVal.put("code", "F");
			retVal.put("msg", "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용:
	 * </pre>
	 *
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @return
	 */
	public String getRamdomPassword() {
		char[] char_set = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
				'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '!', '@' };
		StringBuilder sb = new StringBuilder();
		SecureRandom sr = new SecureRandom();
		sr.setSeed(new Date().getTime());
		int idx = 0;
		int len = char_set.length;
		for (int i = 0; i < 10; i++) { // idx = (int) (len * Math.random());
			idx = sr.nextInt(len); // 강력한 난수를 발생시키기 위해 Secure_random을 사용한다.
			sb.append(char_set[idx]);
		}
		return sb.toString();
	}
}
