package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.bo.mb.model.MbEntrpsMrtggCntrctBasVO;
import com.sorincorp.bo.mb.model.SoCredtEntrLmtHistVO;
import com.sorincorp.bo.mb.service.MbEntrpsMrtggCntrctBasService;
import com.sorincorp.bo.mb.service.SoCredtEntrLmtHistService;
import com.sorincorp.comm.constants.ExceptionConstants;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/SorinCredt")
public class SoCredtEntrLmtHistController {

	@Autowired
	UserInfoUtil userInfoUtil;
	@Autowired
	MessageUtil messageUtil;
	@Autowired
	SoCredtEntrLmtHistService defaultService;
	@Autowired
	MbEntrpsMrtggCntrctBasService mbEntrpsMrtggCntrctBasService;


	private Account getAccountInfo() throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		if (null == account || StringUtil.isBlank(account.getId())) {
			throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_LOGIN_REQUIRED));
		}
		return account;
	}

	/**
	 * <pre>
	 * 처리내용: 검색조건 구성을 위한 distinct 여신 계약 번호 조회
	 * </pre>
	 *
	 * @date 2022. 11. 16.
	 * @author srec0070
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 16.
	 *          srec0070 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrprsLmtHist")
	public String selectEntrpsMb(Model model) {
		try {
			// 여신 계약 번호 List
			List<String> cdtlnCntrctNoList = defaultService.selectCdtlnCntrctNoList();

			model.addAttribute("cdtlnCntrctNoList", cdtlnCntrctNoList);

			return "mb/sorinCredtEntrprsLmtHistList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 기업 한도 관리 이력 조회
	 * </pre>
	 *
	 * @date 2022. 11. 16.
	 * @author srec0070
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 16.
	 *          srec0070 최초작성 ------------------------------------------------
	 * @param lmtMngVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectEntrprsLmtHistList")
	@ResponseBody
	public Map<String, Object> selectEntrprsLmtHistList(@RequestBody SoCredtEntrLmtHistVO lmtMngVO) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();

		int totalDataCount = defaultService.selectEntrprsLmtHistListTotCnt(lmtMngVO);
		List<SoCredtEntrLmtHistVO> selectEntrpsMbList = defaultService.selectEntrprsLmtHistList(lmtMngVO);
		log.debug("selectEntrprsLmtHistList ::" + totalDataCount);
		map.put("totalDataCount", totalDataCount);
		map.put("dataList", selectEntrpsMbList);
		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 on-off line 사용 정보 조회
	 * </pre>
	 *
	 * @date 2022. 11. 16.
	 * @author srec0070
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 16.
	 *          srec0070 최초작성 ------------------------------------------------
	 * @param lmtMngVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectOn_OffUseAmountInfo")
	@ResponseBody
	public Map<String, Object> selectOn_OffUseAmountInfo(@RequestBody SoCredtEntrLmtHistVO lmtMngVO) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();

		SoCredtEntrLmtHistVO offUseAmountInfo = defaultService.selectOn_OffUseAmountInfo(lmtMngVO);

		map.put("result", offUseAmountInfo);
		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 보증번호 기준으로 케이지 크레딧을 사용한 주문번호를 조회
	 * </pre>
	 *
	 * @date 2022. 11. 16.
	 * @author srec0070
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 16.
	 *          srec0070 최초작성 ------------------------------------------------
	 * @param lmtMngVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectOrderNoInfo")
	@ResponseBody
	public Map<String, Object> selectOrderNoInfo(@RequestBody SoCredtEntrLmtHistVO lmtMngVO) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();

		SoCredtEntrLmtHistVO orderNoInfo = defaultService.selectOrderNoInfo(lmtMngVO);

		map.put("result", orderNoInfo);
		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 계약번호별 이력조회 모달창 호출
	 * </pre>
	 * @date 2022. 11. 23.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 23.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param lmtMngVO
	 * @param model
	 * @return
	 */
	@RequestMapping("/cdtlnCntrctDtlsModal")
	public String cdtlnCntrctDtlsModal(@RequestBody SoCredtEntrLmtHistVO lmtMngVO, ModelMap model) {
		try {
			log.debug("lmtMngVO >> " + lmtMngVO);
			model.put("vo", lmtMngVO);

			return "mb/sorinCredtEntrprsLmtHistCntrctDetail.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 계약이력 조회
	 * </pre>
	 * @date 2022. 11. 23.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 23.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param lmtMngVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectEntrprsSoCredtCntrctHstList")
	@ResponseBody
	public Map<String, Object> selectEntrprsSoCredtCntrctHstList(@RequestBody SoCredtEntrLmtHistVO lmtMngVO) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();

		List<SoCredtEntrLmtHistVO> dataList = defaultService.selectEntrprsSoCredtCntrctHstList(lmtMngVO);
		int totalDataCount = dataList.size();
		log.debug("selectEntrprsSoCredtCntrctHstList ::" + totalDataCount);
		map.put("dataList", dataList);
		map.put("totalDataCount", totalDataCount);
		return map;
	}

	/**
	 * <pre>
	 * 케이지크레딧 부보금액 변경
	 * </pre>
	 * @date 2022. 11. 23.
	 * @author srec0051
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/updateMbEntrpsMrtggCntrctPros")
	@ResponseBody
	public Map<String, Object> updateMbEntrpsMrtggCntrctPros(@RequestBody MbEntrpsMrtggCntrctBasVO paramVo) throws Exception {
		log.debug("paramVo = {}", paramVo);

		Account account = getAccountInfo();
		paramVo.setLastChangerId(account.getId());

		Map<String, Object> map = new HashMap<>();

		mbEntrpsMrtggCntrctBasService.updateMbEntrpsMrtggCntrctPros(paramVo);

		map.put("result", 1);
		return map;
	}
}
