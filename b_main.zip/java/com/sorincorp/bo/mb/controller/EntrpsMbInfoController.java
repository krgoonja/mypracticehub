/**
 *
 */
package com.sorincorp.bo.mb.controller;

import java.security.SecureRandom;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nimbusds.oauth2.sdk.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.mb.model.EntrpsMbInfoVO;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.EntrpsMbInfoService;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.comm.message.model.AppPushQueueVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;
//import com.sorincorp.fo.login.model.Account;
//import com.sorincorp.fo.login.model.LoginVO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/Member")
@ComponentScan(basePackages = { "com.sorincorp.comm.*.service", "com.sorincorp.comm.util" })
public class EntrpsMbInfoController {
    @Autowired
    private EntrpsMbInfoService entrpsMbInfoService;

    @Autowired
    private MbCmnCodeService mbCmnCodeService;

    @Autowired
    private EntrpsMbService entrpsMbService;

    @Autowired
    private CustomValidator customValidator;

    @Autowired
    private SMSService smsService;

    @Autowired
    private UserInfoUtil userInfoUtil;

    @Value("${spring.profiles}")
    private String profiles;

    @Value("${spring.fo.domain}")
    private String foDomain;

    /**
     * <pre>
     * 처리내용: 기업 회원 화면 조회
     * </pre>
     *
     * @date 2021. 6. 16.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 6. 16.
     *          srec0009 최초작성 ------------------------------------------------
     * @param model
     * @return
     * @throws Exception
     */
    @RequestMapping("/selectEntrpsMbInfo")
    public String selectEntrpsMbInfo(String entrpsNo, Model model) {
        try {
            // model.addAttribute("vo", entrpsMbService.selectEntrpsGrad());
            // .멤버 상태 코드
            List<MbCmnCodeVO> mberSttusCode = mbCmnCodeService.selectCmnCodeList("MBER_STTUS_CODE");
            // 회원 구분 코드
            List<MbCmnCodeVO> mberSeCode = mbCmnCodeService.selectCmnCodeList("MBER_SE_CODE");

            MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);

            model.addAttribute("mberSttusCode", mberSttusCode);
            model.addAttribute("mberSeCode", mberSeCode);
            model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
            model.addAttribute("entrpsNo", entrpsNo);

            return "mb/entrpsMbInfoList";
        } catch (Exception e) {
            log.error(e.getMessage());
            HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
            return "error/503";
        }
    }

    /**
     * <pre>
     * 처리내용: 기업 회원 리스트 조회
     * </pre>
     *
     * @date 2021. 6. 16.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 6. 16.
     *          srec0009 최초작성 ------------------------------------------------
     * @param entrpsMbInfoVO
     * @return
     * @throws Exception
     */
    @RequestMapping("/selectEntrpsMbInfoList")
    @ResponseBody
    public Map<String, Object> selectEntrpsMbInfoList(@RequestBody EntrpsMbInfoVO entrpsMbInfoVO, String entrpsNo, Model model, HttpServletRequest request) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();

        entrpsMbInfoVO.setEntrpsNo(entrpsNo);
        List<EntrpsMbInfoVO> selectEntrpsMbInfoList = entrpsMbInfoService.selectEntrpsMbInfoList(entrpsMbInfoVO);
        int totalDataCount = entrpsMbInfoService.selectEntrpsMbInfoListTotCnt(entrpsMbInfoVO);

        map.put("totalDataCount", totalDataCount);
        map.put("dataList", selectEntrpsMbInfoList);
        return map;
    }

    /**
     * <pre>
     * 처리내용: 기업 회원 삭제
     * </pre>
     *
     * @date 2021. 6. 16.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 6. 16.
     *          srec0009 최초작성 ------------------------------------------------
     * @param entrpsMbInfoVO
     * @param status
     * @return
     * @throws Exception
     */
    @ResponseBody
    @PostMapping("/deleteEntrpsMbInfoList")
    public ResponseEntity<Object> deleteEntrpsMbInfoList(@RequestBody List<EntrpsMbInfoVO> entrpsMbInfoVO, SessionStatus status) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();
        String result = "F";

        if (userInfoUtil.getAccountInfo() != null) {
            result = entrpsMbInfoService.deleteEntrpsMbInfoList(entrpsMbInfoVO);
        }

        map.put("result", result);
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    /**
     * <pre>
     * 처리내용: 기업 회원 입력 모달
     * </pre>
     *
     * @date 2021. 6. 16.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 6. 16.
     *          srec0009 최초작성 ------------------------------------------------
     * @param entrpsMbInfoVO
     * @param model
     * @return
     * @throws Exception
     */

    @PostMapping("/insertMbInfoModalView")
    public String insertMbInfoModalView(@RequestBody EntrpsMbInfoVO entrpsMbInfoVO, ModelMap model) throws Exception {
        List<MbCmnCodeVO> mberSeCode = mbCmnCodeService.selectCmnCodeList("MBER_SE_CODE");
        List<MbCmnCodeVO> mberSttusCode = mbCmnCodeService.selectCmnCodeList("MBER_STTUS_CODE");
        List<MbCmnCodeVO> domainList = mbCmnCodeService.selectCmnCodeList("EMAIL_DOMAIN");
        model.addAttribute("mberSeCode", mberSeCode);
        model.addAttribute("mberSttusCode", mberSttusCode);
        model.addAttribute("domainList", domainList);
        return "mb/mbInfoInsModal.modal";
    }

    /**
     * <pre>
     * 처리내용: 회원 정보 입력 모달
     * </pre>
     *
     * @date 2021. 9. 28.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 9. 28.
     *          srec0009 최초작성 ------------------------------------------------
     * @param entrpsMbInfoVO
     * @param bindingResult
     * @param model
     * @return
     * @throws Exception
     */

    @PostMapping("/insertMbInfoModal")
    @ResponseBody
    public ResponseEntity<Object> insertMbInfo(@RequestBody EntrpsMbInfoVO entrpsMbInfoVO, BindingResult bindingResult, Model model) throws Exception {
        customValidator.validate(entrpsMbInfoVO, bindingResult, EntrpsMbInfoVO.Insert.class);
        int result = 0;
        Map<String, Object> map = new HashMap<String, Object>();

        if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
            return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
        }
        result = entrpsMbInfoService.insertMbInfo(entrpsMbInfoVO);

        map.put("result", result);
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    /**
     * <pre>
     * 처리내용: 회원 정보 수정 (모달)
     * </pre>
     *
     * @date 2021. 6. 28.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 6. 28.
     *          srec0009 최초작성 ------------------------------------------------
     * @param entrpsMbInfoVO
     * @param bindingResult
     * @param model
     * @return
     * @throws Exception
     */

    @PostMapping("/updateMbInfoDtlModal")
    @ResponseBody
    public ResponseEntity<Object> updateMbInfoDtlModal(@RequestBody EntrpsMbInfoVO entrpsMbInfoVO, BindingResult bindingResult, Model model) throws Exception {

        int result = 0;
        Map<String, Object> map = new HashMap<String, Object>();

        if (userInfoUtil.getAccountInfo() == null) {
            map.put("result", result);
            return new ResponseEntity<>(map, HttpStatus.OK);
        }

        customValidator.validate(entrpsMbInfoVO, bindingResult, EntrpsMbInfoVO.Update.class);

        if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
            return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
        }
        entrpsMbInfoVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
        // 마스터회원 변경하는 경우
        if (entrpsMbInfoVO.getMberSeCode().equals("01")) {
            // 기존 마스터 회원 코드 변경
            result = entrpsMbInfoService.deleteMbMaster(entrpsMbInfoVO);
        }
        result = entrpsMbInfoService.updateMbInfoDtlModal(entrpsMbInfoVO);
        map.put("result", result);
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    /**
     * <pre>
     * 처리내용: 기업 회원 로그인 이력 조회 모달
     * </pre>
     *
     * @date 2021. 6. 16.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 6. 16.
     *          srec0009 최초작성 ------------------------------------------------
     * @param entrpsMbInfoVO
     * @param modelMap
     * @param model
     * @return
     * @throws Exception
     */
    @RequestMapping("/selectLoginHstModal")
    public String selectLoginHstModal(@RequestBody EntrpsMbInfoVO entrpsMbInfoVO, ModelMap modelMap, Model model) {
        try {
            model.addAttribute("mberNo", entrpsMbInfoVO.getMberNo());
            return "mb/loginHstModal.modal";
        } catch (Exception e) {
            log.error(e.getMessage());
            HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
            return "error/503";
        }
    }

    /**
     * <pre>
     * 처리내용: 기업 회원 로그인 이력 조회
     * </pre>
     *
     * @date 2021. 6. 16.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 6. 16.
     *          srec0009 최초작성 ------------------------------------------------
     * @param entrpsMbInfoVO
     * @return
     * @throws Exception
     */
    @PostMapping("/selectMbLoginHstList")
    @ResponseBody
    public Map<String, Object> selectMbLoginHstList(@RequestBody EntrpsMbInfoVO entrpsMbInfoVO) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();

        List<EntrpsMbInfoVO> selectMbLoginHstList = entrpsMbInfoService.selectMbLoginHstList(entrpsMbInfoVO);
        int totalDataCount = entrpsMbInfoService.selectMbLoginHstListTotCnt(entrpsMbInfoVO);
        log.debug("totalDataCount" + totalDataCount);
        map.put("totalDataCount", totalDataCount);
        map.put("dataList", selectMbLoginHstList);

        return map;
    }

    /**
     * <pre>
     * 처리내용: 아이디 중복 검사
     * </pre>
     *
     * @date 2021. 6. 16.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 6. 16.
     *          srec0009 최초작성 ------------------------------------------------
     * @param mberId
     * @return
     */
    @PostMapping("/selectMberId")
    @ResponseBody
    public int selectMberId(@RequestBody String mberId) {
        int result = 0;
        result = entrpsMbInfoService.selectMberId(mberId);
        return result;
    }

    /**
     * <pre>
     * 처리내용: 중복 가입 회원 여부 확인
     * </pre>
     *
     * @date 2021. 6. 16.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 6. 16.
     *          srec0009 최초작성 ------------------------------------------------
     * @param mberId
     * @return
     * @throws Exception
     */
    @PostMapping("/selectSigninAt")
    @ResponseBody
    public int selectSigninAt(@RequestBody EntrpsMbInfoVO entrpsMbInfoVO) throws Exception {
        int result = 0;
        result = entrpsMbInfoService.selectSigninAt(entrpsMbInfoVO);
        return result;
    }

    /**
     * <pre>
     * 처리내용: 회원 정보 상세 조회
     * </pre>
     *
     * @date 2021. 6. 28.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 6. 28.
     *          srec0009 최초작성 ------------------------------------------------
     * @param entrpsMbInfoVO
     * @param modelMap
     * @param model
     * @return
     * @throws Exception
     */
    @PostMapping("/selectMbInfoDtlModal")
    public String selectMbInfoDtlModal(@RequestBody EntrpsMbInfoVO entrpsMbInfoVO, ModelMap modelMap, Model model) throws Exception {
        // model.addAttribute("mberNo", entrpsMbInfoVO.getMberNo());
        String mberNo = entrpsMbInfoVO.getMberNo();

        EntrpsMbInfoVO vo = entrpsMbInfoService.selectMbInfoDtlModal(mberNo);
        model.addAttribute("vo", vo);
        List<MbCmnCodeVO> mberSeCode = mbCmnCodeService.selectCmnCodeList("MBER_SE_CODE");
        List<MbCmnCodeVO> mberSttusCode = mbCmnCodeService.selectCmnCodeList("MBER_STTUS_CODE");
        List<MbCmnCodeVO> domainList = mbCmnCodeService.selectCmnCodeList("EMAIL_DOMAIN");
        model.addAttribute("mberSeCode", mberSeCode);
        model.addAttribute("mberSttusCode", mberSttusCode);
        model.addAttribute("domainList", domainList);
        return "mb/mbInfoDtlModal.modal";
    }

    /**
     * <pre>
     * 처리내용: 계정 잠금 해제
     * </pre>
     *
     * @date 2021. 6. 28.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 6. 28.
     *          srec0009 최초작성 ------------------------------------------------
     * @param mberId
     * @param model
     * @return
     * @throws Exception
     */

    @ResponseBody
    @PostMapping("/updateMberLockSttus")
    public String updateMberLockSttus(@RequestBody EntrpsMbInfoVO entrpsMbInfoVO) throws Exception {
        int no = 0;
        String result = "";

        if (userInfoUtil.getAccountInfo() != null) {
            entrpsMbInfoVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
            no = entrpsMbInfoService.updateMberLockSttus(entrpsMbInfoVO);
        }

        if (no == 1) {
            result = "S";
        } else if (no == 0) {
            result = "F";
        }
        return result;
    }

    /**
     * <pre>
     * 처리내용: 회원 삭제(모달)
     * </pre>
     *
     * @date 2021. 6. 28.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 6. 28.
     *          srec0009 최초작성 ------------------------------------------------
     * @param entrpsMbInfoVO
     * @param bindingResult
     * @param model
     * @return
     * @throws Exception
     */
    @ResponseBody
    @PostMapping("/deleteMbInfoDtlModal")
    public String deleteMbInfoDtlModal(@RequestBody EntrpsMbInfoVO entrpsMbInfoVO, BindingResult bindingResult, Model model) throws Exception {
        customValidator.validate(entrpsMbInfoVO, bindingResult);
        int no = 0;
        String result = "";

        if (bindingResult.hasErrors()) {
            model.addAttribute("entrpsMbInfoVO", entrpsMbInfoVO);
            return "mb/mbInfoDtlModal";
        }

        entrpsMbInfoVO.setLastChangerId(userInfoUtil.getUserId());
        no = entrpsMbInfoService.deleteMbInfoDtlModal(entrpsMbInfoVO);

        if (no == 1) {
            result = "S";
        } else if (no == 0) {
            result = "F";
        }

        return result;
    }

    /**
     * <pre>
     * 처리내용: 마스터회원 유무 체크
     * </pre>
     *
     * @date 2021. 6. 23.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 6. 23.
     *          srec0009 최초작성 ------------------------------------------------
     * @param mberSeCode
     * @return
     */
    @PostMapping("/selectMberMaster")
    @ResponseBody
    public String selectMberMaster(@RequestBody String entrpsNo) {
        String result = "";
        result = entrpsMbInfoService.selectMberMaster(entrpsNo);
        return result;
    }

    /**
     * <pre>
     * 처리내용: 비밀번호 초기화
     * </pre>
     *
     * @date 2021. 6. 28.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 6. 28.
     *          srec0009 최초작성 ------------------------------------------------
     * @param mberId
     * @param model
     * @return
     * @throws Exception
     */

    @ResponseBody
    @PostMapping("/updatePwdInit")
    public String updatePwdInit(@RequestBody EntrpsMbInfoVO entrpsMbInfoVO) throws Exception {
        String result = "";
        try {
            int no = 0;
            String templateNum = "28";
            String title = mbCmnCodeService.selectMssageSj(templateNum);
            title = "[케이지트레이딩] 비밀번호 변경 알림";
            String randomPwd = getRamdomPassword();
            entrpsMbInfoVO.setRandomPwd(CryptoUtil.encryptSHA256(randomPwd));
            entrpsMbInfoVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

            no = entrpsMbInfoService.updatePwdInit(entrpsMbInfoVO);

            if (no == 1) {
                // 핸드폰 번호 하이픈 제거
                String mobNo = (entrpsMbInfoVO.getMoblphonNo()).replaceAll("[^0-9]", "");
                String mberNo = entrpsMbInfoVO.getMberNo();
                String deviceId = entrpsMbInfoVO.getDeviceId();
                String mberNm = entrpsMbInfoVO.getMberNm();

                // 비밀번호 초기화 시 알림 톡 발송
                Map<String, String> msgMap = new HashMap<>();
                SMSVO smsVO = new SMSVO();
                msgMap.put("templateNum", templateNum); // 메시지 템플릿 번호
                msgMap.put("password", randomPwd);
                msgMap.put("ordrrNm", mberNm);
                // smsVO.setReqDate(null); // 예약발송 시간
                smsVO.setPhone(mobNo); // 받는사람 번호
                smsVO.setMsgTitle(title);
                smsVO.setMberNo(mberNo);
                smsService.insertSMS(smsVO, msgMap); // 메소드 호출

                if (deviceId != null && !"".equals(deviceId)) {
                    AppPushQueueVO pushVo = new AppPushQueueVO();
                    pushVo.setMsgTitle(title);
                    pushVo.setCallback(mobNo);
                    pushVo.setMberNo(mberNo);
                    pushVo.setIdentify(deviceId);

                    String mDomainUrl = "";

                    if ("prd".equals(profiles)) {
                        mDomainUrl = "https://m.kztraders.com";
                    } else {
                        // 로컬 또는 스테이징
                        mDomainUrl = "http://stm.kztraders.com:28086";
                    }

                    pushVo.setUrl(mDomainUrl);
                    // app push
                    smsService.insertAppPush(pushVo, msgMap);
                }

                result = "S";
            } else if (no == 0) {
                result = "F";
            }

        } catch (Exception e) {
            log.error(e.getMessage());
        }
        return result;
    }

    /**
     * <pre>
     * 처리내용: 랜덤 패스워드 생성 메소드
     * </pre>
     *
     * @date 2021. 9. 28.
     * @author srec0009
     * @history ------------------------------------------------ 변경일 작성자 변경내용
     *          ------------------------------------------------ 2021. 9. 28.
     *          srec0009 최초작성 ------------------------------------------------
     * @return
     */
    public String getRamdomPassword() {
        char[] char_set = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
                'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '!', '@' };
        StringBuilder sb = new StringBuilder();
        SecureRandom sr = new SecureRandom();
        sr.setSeed(new Date().getTime());
        int idx = 0;
        int len = char_set.length;
        for (int i = 0; i < 10; i++) { // idx = (int) (len * Math.random());
            idx = sr.nextInt(len); // 강력한 난수를 발생시키기 위해 Secure_random을 사용한다.
            sb.append(char_set[idx]);
        }
        return sb.toString();
    }

    /**
     * <pre>
     * 처리내용: 대행업무 팝업 호출
     * </pre>
     *
     * @date 2024. 3. 7.
     * @author cuko
     * @history
     * ------------------------------------------------
     * 변경일				작성자				변경내용
     * ------------------------------------------------
     * 2024. 3. 07.			cuko			2024. 3. 7.
     * ------------------------------------------------
     * @param model
     * @return
     * @throws Exception
     */
    @RequestMapping("/mberIdForVrsc")
    public ResponseEntity<Object> mberIdForVrsc(@RequestBody EntrpsMbInfoVO entrpsMbInfoVO, Model model) {
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            map.put("mberId", CryptoUtil.encryptAES256(entrpsMbInfoVO.getMberId()));
            return new ResponseEntity<>(map, HttpStatus.OK);
        } catch (Exception e) {
            log.error(e.getMessage());
            HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
            return new ResponseEntity<>(map, HttpStatus.BAD_REQUEST);
        }
    }
}