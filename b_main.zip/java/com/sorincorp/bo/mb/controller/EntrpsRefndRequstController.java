/**
 *
 */
package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.mb.model.EntrpsMbInfoVO;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEwalletVO;
import com.sorincorp.bo.mb.service.EntrpsRefndRequstService;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/Member")
@ComponentScan(basePackages= {"com.sorincorp.comm.*.service", "com.sorincorp.comm.util"})
public class EntrpsRefndRequstController{

	@Autowired
	private EntrpsRefndRequstService entrpsRefndRequstService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	/**
	 * <pre>
	 * 처리내용: 회원사 환불 요청 내역 조회
	 * </pre>
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 28.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsRefndRequst")
	public String selectEntrpsRefndRequst(ModelMap model){
		try {
			List<MbCmnCodeVO> refndRequstSttusCodeList  = mbCmnCodeService.selectCmnCodeList("REFND_REQUST_STTUS_CODE");
			List<MbCmnCodeVO> refndRequstMbyCode  = mbCmnCodeService.selectCmnCodeList("REFND_REQUST_MBY_CODE");
			model.addAttribute("refndRequstSttusCodeList", refndRequstSttusCodeList);
			model.addAttribute("refndRequstMbyCode", refndRequstMbyCode);
			return "mb/entrpsRefndRequstList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 회원사 환불 요청 내역 조회
	 * </pre>
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 28.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mbEwalletVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectEntrpsRefndRequstList")
	@ResponseBody
	public Map<String,Object> selectEntrpsRefndRequstList(@RequestBody MbEwalletVO mbEwalletVO) throws Exception {
		String sDate = mbEwalletVO.getStartDate();
		String eDate = mbEwalletVO.getEndDate();

		if(eDate == null) {
			eDate = DateUtil.getNowDate();
		}

		if(sDate == null) {
			sDate = DateUtil.addDays(eDate, -7);
		}

		mbEwalletVO.setStartDate(sDate.replaceAll("-", ""));
		mbEwalletVO.setEndDate(eDate.replaceAll("-", ""));

		Map<String,Object> map = new HashMap<String, Object>();
		List<MbEwalletVO> selectEntrpsMbInfoList = entrpsRefndRequstService.selectEntrpsRefndRequstList(mbEwalletVO);
		int totalDataCount = entrpsRefndRequstService.selectEntrpsRefndRequstListToCnt(mbEwalletVO);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", selectEntrpsMbInfoList);
		return map;
	}


}
