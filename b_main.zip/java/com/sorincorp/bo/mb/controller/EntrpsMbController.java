/**
 *
 */
package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.bo.mb.model.ApprovalReqMbCorpMgrVO;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEntrpsDscntExclVO;
import com.sorincorp.bo.mb.model.MbEntrpsGradMngVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.ApprovalReqMbCorpMgrService;
import com.sorincorp.bo.mb.service.EntrpsInfoSearchPopService;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.bo.mb.service.MbEntrpsDscntExclService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/Member")
public class EntrpsMbController {

	@Autowired
	private EntrpsMbService entrpsMbService;

	@Autowired
	private EntrpsInfoSearchPopService entrpsInfoSearchPopService;

	@Autowired
	private ApprovalReqMbCorpMgrService approvalReqMbCorpMgrService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private ItCmnCodeService itCmnCodeService;
	
	@Autowired
	private MbEntrpsDscntExclService mbEntrpsDscntExclService;

	/**
	 * <pre>
	 * 처리내용: 기업 회원 목록
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsMb")
	public String selectEntrpsMb(Model model) {
		try {
			// 공통코드

			// 승인상태코드
			List<MbCmnCodeVO> mberConfmSttusCode = mbCmnCodeService.selectCmnCodeList("MBER_CONFM_STTUS_CODE");
			model.addAttribute("mberConfmSttusCode", mberConfmSttusCode);

			// 사업자유형코드
			List<MbCmnCodeVO> bsnmTyCode = mbCmnCodeService.selectCmnCodeList("BSNM_TY_CODE");
			model.addAttribute("bsnmTyCode", bsnmTyCode);

			// 등급코드
			List<MbCmnCodeVO> mberGradCode = mbCmnCodeService.selectCmnCodeList("ENTRPS_GRAD_CODE");
			model.addAttribute("entrpsGradCode", mberGradCode);

			// 평가등급코드
			List<MbCmnCodeVO> entrpsEvlGradCode = mbCmnCodeService.selectCmnCodeList("ENTRPS_EVL_GRAD_CODE");
			model.addAttribute("entrpsEvlGradCode", entrpsEvlGradCode);

			ItCmnCodeVO vo = new ItCmnCodeVO();

			// 메탈코드 리스트
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");

			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);
			model.addAttribute("metalCodeList", metalCodeList);

//			//db 등급
//			List<MbEntrpsMbVO> entrpsGrad = entrpsMbService.selectEntrpsGrad();
//			model.addAttribute("entrpsGrad", entrpsGrad);

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			String oneWeek = DateUtil.addDays(today.replaceAll("-", ""), -7);
			String oneMonth = DateUtil.addMonths(today.replaceAll("-", ""), -1);
			String sixMonth = DateUtil.addMonths(today.replaceAll("-", ""), -6);
			String oneYear = DateUtil.addYears(today.replaceAll("-", ""), -1);
			String twoYear = DateUtil.addYears(today.replaceAll("-", ""), -2);

			model.addAttribute("today", today);
			model.addAttribute("oneWeek", oneWeek);
			model.addAttribute("oneMonth", oneMonth);
			model.addAttribute("sixMonth", sixMonth);
			model.addAttribute("oneYear", oneYear);
			model.addAttribute("twoYear", twoYear);

			return "mb/entrpsMbList";

		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 기업 회원 목록
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsMbVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectEntrpsMbList")
	@ResponseBody
	public Map<String, Object> selectEntrpsMbList(@RequestBody MbEntrpsMbVO entrpsMbVO) throws Exception {

		Map<String, Object> map = new HashMap<>();

		int totalDataCount = entrpsMbService.selectEntrpsMbListTotCnt(entrpsMbVO);
		List<MbEntrpsMbVO> selectEntrpsMbList = entrpsMbService.selectEntrpsMbList(entrpsMbVO);

		log.debug("selectEntrpsMbListTotCnt ::" + totalDataCount);
		map.put("totalDataCount", totalDataCount);
		map.put("dataList", selectEntrpsMbList);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 기업 회원 등급 일괄 변경.
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsMbList
	 * @return
	 */
	@PostMapping("/updateEntrpsGradLevelAll")
	@ResponseBody
	public ResponseEntity<Object> updateEntrpsGradLevelAll(@RequestBody List<MbEntrpsMbVO> entrpsMbList) throws Exception {
		int result = 0;
		Map<String, Object> map = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			map.put("result", result);
			return new ResponseEntity<>(map, HttpStatus.OK);
		} else {
			result = entrpsMbService.updateEntrpsGradLevelAll(entrpsMbList);
		}

		map.put("result", result);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@PostMapping("/updateEntrpsGradList")
	@ResponseBody
	public ResponseEntity<Object> updateEntrpsGradList(@RequestBody List<MbEntrpsMbVO> entrpsMbList) throws Exception {
		int result = 0;
		Map<String, Object> map = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			map.put("result", result);
			return new ResponseEntity<>(map, HttpStatus.OK);
		} else {
			result = entrpsMbService.updateEntrpsGradList(entrpsMbList);
		}

		map.put("result", result);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 기업 회원 상세 조회
	 * </pre>
	 *
	 * @date 2021. 6. 9.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 9.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @param approvalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsMbDetail")
	public String selectEntrpsMbDetail(ModelMap model, ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO, String entrpsNo) {

		// String entrpsNo = approvalReqMbCorpMgrVO.getEntrpsNo();

		try {

			log.debug("entrpsNo :: " + entrpsNo);
			approvalReqMbCorpMgrVO.setEntrpsNo(entrpsNo);
			List<ApprovalReqMbCorpMgrVO> attachFileList = approvalReqMbCorpMgrService.selectAttachFileList(approvalReqMbCorpMgrVO);
			List<MbCmnCodeVO> mberConfmSttusCodeList = mbCmnCodeService.selectCmnCodeList("MBER_CONFM_STTUS_CODE");
			List<MbCmnCodeVO> bsnmTyCodeList = mbCmnCodeService.selectCmnCodeList("BSNM_TY_CODE");
			List<MbCmnCodeVO> bsnmRegistSttusCodeList = mbCmnCodeService.selectCmnCodeList("BSNM_REGIST_STTUS_CODE");
			List<MbCmnCodeVO> credtGradCodeList = mbCmnCodeService.selectCmnCodeList("CREDT_GRAD_CODE");
			List<MbCmnCodeVO> entrpsGradCodeList = mbCmnCodeService.selectCmnCodeList("ENTRPS_GRAD_CODE");
			List<MbCmnCodeVO> entrpsEvlGradCodeList = mbCmnCodeService.selectCmnCodeList("ENTRPS_EVL_GRAD_CODE");
			List<MbCmnCodeVO> entrpsPurchsInclnGradCodeList = mbCmnCodeService.selectCmnCodeList("ENTRPS_PURCHS_INCLN_GRAD_CODE");
			List<MbCmnCodeVO> entrprsIndutySeCodeList = mbCmnCodeService.selectCmnCodeList("ENTRPRS_INDUTY_SE_CODE");
			List<MbCmnCodeVO> avrgpcLivePurchsGradCodeList = mbCmnCodeService.selectCmnCodeList("AVRGPC_DELNG_AMOUNT_RATE_CODE"); // 평균가 LIVE 구매 등급 코드
			List<MbCmnCodeVO> avrgpcTaxBillIsuPnttmCodeList = mbCmnCodeService.selectCmnCodeList("AVRGPC_TAX_BILL_ISU_PNTTM_CODE"); // 평균가 세금계산서 발행시점
			List<MbEntrpsDscntExclVO> mbEntrpsDscntExclVOList = mbEntrpsDscntExclService.getMbEntrpsDscntExclVOList(approvalReqMbCorpMgrVO.getEntrpsNo()); // 평균가 세금계산서 발행시점
			List<MbCmnCodeVO> untpcDcsnMxmmPdCodeList = mbCmnCodeService.selectCmnCodeList("UNTPC_DCSN_MXMM_PD_CODE"); // 단가 확정 최대 기간 코드

			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);
			// 금속 권한 리스트 조회
			List<ApprovalReqMbCorpMgrVO> metalAuthList = approvalReqMbCorpMgrService.selectMbEntrpsMetalAcctoAuthorSetupBas(entrpsNo);
			// 대출은행 리스트 조회
			List<ApprovalReqMbCorpMgrVO> lonGrntyBankUseAtList = approvalReqMbCorpMgrService.selectLonGrntyBankUseAtList(entrpsNo);

			String bankStr = "";
			String useAt = "";
			int cnt = 0;

			if (lonGrntyBankUseAtList != null) {
				for (int i = 0; i < lonGrntyBankUseAtList.size(); i++) {
					useAt = lonGrntyBankUseAtList.get(i).getUseAt();

					if ("Y".equals(useAt)) {
						if (cnt == 0) {
							bankStr += lonGrntyBankUseAtList.get(i).getBankCodeNm();
						} else {
							bankStr += ", " + lonGrntyBankUseAtList.get(i).getBankCodeNm();
						}
						cnt++;
					}
				}
			}
			
			

			model.addAttribute("approvalReqMbCorpMgrVO", approvalReqMbCorpMgrService.selectCorpInfoDetail(entrpsNo));
			model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
			model.addAttribute("mberConfmSttusCodeList", mberConfmSttusCodeList);
			model.addAttribute("bsnmTyCodeList", bsnmTyCodeList);
			model.addAttribute("credtGradCodeList", credtGradCodeList);
			model.addAttribute("entrpsGradCodeList", entrpsGradCodeList);
			model.addAttribute("entrpsEvlGradCodeList", entrpsEvlGradCodeList);
			model.addAttribute("entrpsPurchsInclnGradCodeList", entrpsPurchsInclnGradCodeList);
			model.addAttribute("attachFileList", attachFileList);
			model.addAttribute("bsnmRegistSttusCodeList", bsnmRegistSttusCodeList);
			model.addAttribute("metalAuthList", metalAuthList);
			model.addAttribute("lonGrntyBankUseAtList", lonGrntyBankUseAtList);
			model.addAttribute("entrprsIndutySeCodeList", entrprsIndutySeCodeList);
			model.addAttribute("avrgpcLivePurchsGradCodeList", avrgpcLivePurchsGradCodeList);
			model.addAttribute("avrgpcTaxBillIsuPnttmCodeList", avrgpcTaxBillIsuPnttmCodeList);
			model.addAttribute("mbEntrpsDscntExclVOList", mbEntrpsDscntExclVOList);
			model.addAttribute("untpcDcsnMxmmPdCodeList", untpcDcsnMxmmPdCodeList);

			model.addAttribute("bankStr", bankStr);

			return "mb/entrpsMbDetail";

		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 기업 회원 상세 수정
	 * </pre>
	 *
	 * @date 2021. 6. 9.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 9.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param approvalReqMbCorpMgrVO
	 * @param model
	 * @param status
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/updateMbEntrpsInfoBas")
	@ResponseBody
	public String updateCorpInfoMgr(@RequestBody ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO, Model model, SessionStatus status) throws Exception {

		int result = 0;
		String rtnCode = "";

		if (userInfoUtil.getAccountInfo() == null) {
			status.setComplete();
			return rtnCode;
		} else {
			result = entrpsMbService.updateCorpInfoMgr(approvalReqMbCorpMgrVO);
		}

		if (result == 1) {
			rtnCode = "S";
		} else if (result == 0) {
			rtnCode = "F";
		}
		status.setComplete();
		return rtnCode;
	}

	@PostMapping("/selectListGridDataForExcel")
	public ResponseEntity<?> selectListGridDataForExcel(@RequestBody MbEntrpsMbVO mbEntrpsMbVO, BindingResult bindingResult) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		mbEntrpsMbVO.setRecordCountPerPage(10000000); // Excel Export 전용 Query를 만들경우 작정 안해도 됨
		List<MbEntrpsMbVO> excelList = entrpsMbService.selectEntrpsMbList(mbEntrpsMbVO);

		map.put("dataList", excelList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 등급기여팝업
	 * </pre>
	 *
	 * @date 2022. 8. 11.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 8. 11.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param mbEntrpsMbVO
	 * @param model
	 * @return
	 */
	@RequestMapping("/selectEntrpsGradCntrbtDtls")
	public String selectEntrpsGradCntrbtDtls(@RequestBody MbEntrpsMbVO mbEntrpsMbVO, ModelMap model) {

		String entrpsNo = mbEntrpsMbVO.getEntrpsNo();

		try {
			ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO = approvalReqMbCorpMgrService.selectCorpInfoDetail(entrpsNo);

			// 회원 퍼포먼스등급 산정 조회
			MbEntrpsGradMngVO mbEntrpsGradMngVO = entrpsMbService.selectMbEntrpsGradCalcDtl(entrpsNo);

			model.addAttribute("entrpsNo", entrpsNo);
			model.addAttribute("entrpsInfo", approvalReqMbCorpMgrVO);
			model.addAttribute("mbEntrpsGradMngVO", mbEntrpsGradMngVO);
			return "mb/entrpsGradCntrbtDtls.modal";

		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectEntrpsInfo")
	public String selectEntrpsInfo(@RequestBody MbEntrpsMbVO mbEntrpsMbVO, ModelMap model) {

		try {
//			model.addAttribute("pageCode", mbEntrpsMbVO.getPageCode());
			model.addAttribute("mbEntrpsMbVO", mbEntrpsMbVO);

			return "mb/entrpsInfoSearchPop.modal";

		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@PostMapping("/selectEntrpsInfoAjax")
	@ResponseBody
	public ResponseEntity<Object> selectEntrpsInfoAjax(@RequestBody MbEntrpsMbVO mbEntrpsMbVO) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		List<MbEntrpsMbVO> dataList = entrpsInfoSearchPopService.selectEntrpsInfoList(mbEntrpsMbVO);
		int totalDataCount = entrpsInfoSearchPopService.selectEntrpsInfoListCnt(mbEntrpsMbVO);

		map.put("dataList", dataList);
		map.put("totalDataCount", totalDataCount);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

}
