package com.sorincorp.bo.mb.controller;

import java.util.*;

import com.sorincorp.bo.cs.model.ArrrgTrgterVO;
import com.sorincorp.bo.mb.model.EntrpsMbInfoVO;
import com.sorincorp.bo.mb.service.EntrpsMbInfoService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MrtggGrntyCntrctManageVO;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.bo.mb.service.MrtggGrntyCntrctManageService;
import com.sorincorp.comm.bsnInfo.model.CdtlnInfoVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

import javax.servlet.http.HttpServletRequest;

@Slf4j
@Controller
@RequestMapping("/bo/Member")
public class MrtggGrntyCntrctManageController {

	@Autowired
	private MbCmnCodeService mbCmnCodeService;
	@Autowired
	private MrtggGrntyCntrctManageService mrtggGrntyCntrctManageService;
	@Autowired
	private BsnInfoService bsnInfoService;
	@Autowired
	private EntrpsMbInfoService entrpsMbInfoService;


	@RequestMapping("/selectMrtggGrntyCntrctManageList")
	public String selectMrtggGrntyCntrctManageList(ModelMap model) {

		try {
			// 전자상거래보증 진행상태 코드
			List<MbCmnCodeVO> mrtggGrntyProgrsSttusCodeList = mbCmnCodeService.selectCmnCodeList("MRTGG_GRNTY_PROGRS_STTUS_CODE");
			model.addAttribute("mrtggGrntyProgrsSttusCodeList", mrtggGrntyProgrsSttusCodeList);

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			String oneWeek = DateUtil.addDays(today.replaceAll("-", ""), -7);
			String oneMonth = DateUtil.addMonths(today.replaceAll("-", ""), -1);
			String sixMonth = DateUtil.addMonths(today.replaceAll("-", ""), -6);
			String oneYear = DateUtil.addYears(today.replaceAll("-", ""), -1);
			String twoYear = DateUtil.addYears(today.replaceAll("-", ""), -2);

			model.addAttribute("today", today);
			model.addAttribute("oneWeek", oneWeek);
			model.addAttribute("oneMonth", oneMonth);
			model.addAttribute("sixMonth", sixMonth);
			model.addAttribute("oneYear", oneYear);
			model.addAttribute("twoYear", twoYear);

			return "mb/mrtggGrntyCntrctManageList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectMrtggGrntyCntrctManageListAjax")
	@ResponseBody
	public Map<String, Object> selectMrtggGrntyCntrctManageListAjax(@RequestBody MrtggGrntyCntrctManageVO mrtggGrntyCntrctManageVO) throws Exception {

		String startDtm = mrtggGrntyCntrctManageVO.getStartDate();
		String endtDtm = mrtggGrntyCntrctManageVO.getEndDate();

		if (startDtm != null && !"".equals(startDtm)) {
			startDtm = startDtm + " 00:00:00";
			mrtggGrntyCntrctManageVO.setStartDate(startDtm);
		}

		if (endtDtm != null && !"".equals(endtDtm)) {
			endtDtm = endtDtm + " 23:59:59";
			mrtggGrntyCntrctManageVO.setEndDate(endtDtm);
		}
		List<MrtggGrntyCntrctManageVO> mrtggGrntyCntrctManageList = mrtggGrntyCntrctManageService.selectCredtGrntyRequstManageList(mrtggGrntyCntrctManageVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalDataCount", mrtggGrntyCntrctManageService.selectCredtGrntyRequstManageTotCnt(mrtggGrntyCntrctManageVO));
		map.put("dataList", mrtggGrntyCntrctManageList);
		return map;
	}

	@RequestMapping("/selectMrtggGrntyCntrctManageDetail")
	public String selectMrtggGrntyCntrctManageDetail(ModelMap model, MrtggGrntyCntrctManageVO mrtggGrntyCntrctManageVO) {

		try {

			model.addAttribute("mrtggGrntyCntrctManageVO", mrtggGrntyCntrctManageVO);

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			CdtlnInfoVO cdtlnInfoVO = bsnInfoService.getCdtlnInfo(today);
			model.addAttribute("cdtlnInfoVO", cdtlnInfoVO);

			return "mb/mrtggGrntyCntrctManageDetail";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectMbEntrpsMrtggLmtDtlListAjax")
	@ResponseBody
	public Map<String, Object> selectMbEntrpsMrtggLmtDtlListAjax(@RequestBody MrtggGrntyCntrctManageVO mrtggGrntyCntrctManageVO) throws Exception {

		List<MrtggGrntyCntrctManageVO> mbEntrpsMrtggLmtDtlList = mrtggGrntyCntrctManageService.selectMbEntrpsMrtggLmtDtlList(mrtggGrntyCntrctManageVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalDataCount", mrtggGrntyCntrctManageService.selectMbEntrpsMrtggLmtDtlTotCnt(mrtggGrntyCntrctManageVO));
		map.put("dataList", mbEntrpsMrtggLmtDtlList);
		return map;
	}

	@RequestMapping("/selectMrtggGrntyCntrctManageOrderList")
	public String selectMrtggGrntyCntrctManageOrderList(@RequestBody MrtggGrntyCntrctManageVO mrtggGrntyCntrctManageVO, ModelMap model) {

		try {

			// List<MrtggGrntyCntrctManageVO> mrtggGrntyCntrctManageOrderList =
			// mrtggGrntyCntrctManageService.selectMrtggGrntyCntrctManageOrderList(mrtggGrntyCntrctManageVO);
			// model.addAttribute("mrtggGrntyCntrctManageOrderList",
			// mrtggGrntyCntrctManageOrderList);

			model.addAttribute("entrpsNo", mrtggGrntyCntrctManageVO.getEntrpsNo());
			model.addAttribute("grntyNo", mrtggGrntyCntrctManageVO.getGrntyNo());
			model.addAttribute("cdtlnSvcSeCode", mrtggGrntyCntrctManageVO.getCdtlnSvcSeCode());

			return "mb/mrtggGrntyCntrctManageOrderList.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectMrtggGrntyCntrctManageOrderListAjax")
	@ResponseBody
	public Map<String, Object> selectMrtggGrntyCntrctManageOrderListAjax(@RequestBody MrtggGrntyCntrctManageVO mrtggGrntyCntrctManageVO) throws Exception {

		List<MrtggGrntyCntrctManageVO> mrtggGrntyCntrctManageOrderList = mrtggGrntyCntrctManageService.selectMrtggGrntyCntrctManageOrderList(mrtggGrntyCntrctManageVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("dataList", mrtggGrntyCntrctManageOrderList);
		return map;
	}

	@RequestMapping("/selectSorinCredtCntrctManageList")
	public String selectSorinCredtCntrctManageList(ModelMap model) {

		try {
			// 보증 진행상태 코드
			List<MbCmnCodeVO> sorinCredtProgrsSttusCodeList = mbCmnCodeService.selectCmnCodeList("MRTGG_GRNTY_PROGRS_STTUS_CODE");
			model.addAttribute("sorinCredtProgrsSttusCodeList", sorinCredtProgrsSttusCodeList);

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			String oneWeek = DateUtil.addDays(today.replaceAll("-", ""), -7);
			String oneMonth = DateUtil.addMonths(today.replaceAll("-", ""), -1);
			String sixMonth = DateUtil.addMonths(today.replaceAll("-", ""), -6);
			String oneYear = DateUtil.addYears(today.replaceAll("-", ""), -1);
			String twoYear = DateUtil.addYears(today.replaceAll("-", ""), -2);

			model.addAttribute("today", today);
			model.addAttribute("oneWeek", oneWeek);
			model.addAttribute("oneMonth", oneMonth);
			model.addAttribute("sixMonth", sixMonth);
			model.addAttribute("oneYear", oneYear);
			model.addAttribute("twoYear", twoYear);

			return "mb/sorinCredtCntrctManageList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectSorinCredtCntrctManageListAjax")
	@ResponseBody
	public Map<String, Object> selectSorinCredtCntrctManageListAjax(@RequestBody MrtggGrntyCntrctManageVO mrtggGrntyCntrctManageVO) throws Exception {

		String startDtm = mrtggGrntyCntrctManageVO.getStartDate();
		String endtDtm = mrtggGrntyCntrctManageVO.getEndDate();

		if (startDtm != null && !"".equals(startDtm)) {
			startDtm = startDtm + " 00:00:00";
			mrtggGrntyCntrctManageVO.setStartDate(startDtm);
		}

		if (endtDtm != null && !"".equals(endtDtm)) {
			endtDtm = endtDtm + " 23:59:59";
			mrtggGrntyCntrctManageVO.setEndDate(endtDtm);
		}
		List<MrtggGrntyCntrctManageVO> mrtggGrntyCntrctManageList = mrtggGrntyCntrctManageService.selectCredtGrntyRequstManageList(mrtggGrntyCntrctManageVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalDataCount", mrtggGrntyCntrctManageService.selectCredtGrntyRequstManageTotCnt(mrtggGrntyCntrctManageVO));
		map.put("dataList", mrtggGrntyCntrctManageList);
		return map;
	}

	@RequestMapping("/selectSorinCredtCntrctManageDetail")
	public String selectSorinCredtCntrctManageDetail(ModelMap model, MrtggGrntyCntrctManageVO sorinCredtCntrctManageVO) {

		try {
			model.addAttribute("sorinCredtCntrctManageVO", sorinCredtCntrctManageVO);
			return "mb/sorinCredtCntrctManageDetail";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}


	/**
	 * <pre>
	 * 처리내용: 이메일 발송 모달창을 조회한다.
	 * </pre>
	 *
	 * @date 2023. 12. 11.
	 * @author hamyoonsic
	 * ------------------------------------------------
	 * 변경일                  작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 12. 11.         hamyoonsic      최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/sorinCredtModalEmail")
	public String sorinCredtModalEmail(@RequestBody ArrayList<MrtggGrntyCntrctManageVO> entrpsInfolist, ModelMap model) {
		try {
			Map<String,Object> resMap = new HashMap<>();
			List<String> entrpsEmailList = new ArrayList<>();
			List<String> entrpsnmKoreanList = new ArrayList<>();
			//기업의 모든 멤버이메일 조회
			if(entrpsInfolist.size() > 0 ){
				for(MrtggGrntyCntrctManageVO entrpsInfo : entrpsInfolist) {
					List<MrtggGrntyCntrctManageVO> selectEntrpsMbInfoList = mrtggGrntyCntrctManageService.selectEntrpsMbInfoList(entrpsInfo);

					if(selectEntrpsMbInfoList.size() > 0){
						for(MrtggGrntyCntrctManageVO entrpsMbInfoVO : selectEntrpsMbInfoList) {
							if(StringUtils.isEmpty(entrpsMbInfoVO.getMberEmail())){
								continue;
							}
							entrpsEmailList.add(entrpsMbInfoVO.getMberEmail());
						}
						entrpsInfo.setEntrpsEmailList(entrpsEmailList);
					} else {
						log.debug("sorinCredtModalEmail 발송대상 없음 selectEntrpsMbInfoList {}",selectEntrpsMbInfoList);
					}
					entrpsnmKoreanList.add(entrpsInfo.getEntrpsnmKorean());
					resMap.put(entrpsInfo.getEntrpsNo(),entrpsInfo.getEntrpsEmailList());
				}
			} else {
				log.debug("sorinCredtModalEmail param null entrpsInfolist {}",entrpsInfolist);
			}
			model.put("resMap", resMap);
			model.put("entrpsnmKoreanList", entrpsnmKoreanList);
			model.put("entrpsEmailList", entrpsEmailList);
			return "mb/sorinCredtCntrcManageEmailModal.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	@RequestMapping("/sorinCredtSendEmail")
	public ResponseEntity<?> sorinCredtSendEmail(@RequestBody List<MrtggGrntyCntrctManageVO> entrpsInfoList) throws Exception {
		Map<String,String> map = new HashMap<>();
		log.debug("sorinCredtSendEmail start");
		map.put("result","S");
		try{
			mrtggGrntyCntrctManageService.sorinCredtSendEmail(entrpsInfoList);
			map.put("message","전송되었습니다");
		} catch (Exception e) {
			map.put("message","ERROR 전송 실패\n관리자에게 문의바랍니다.");
		}
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 이메일 템플릿 목록을 조회한다.
	 * </pre>
	 *
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 14.
	 *          srec0066 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectEmailTmplatList")
	@ResponseBody
	public List<MrtggGrntyCntrctManageVO> selectEmailTmplatList(@RequestBody MrtggGrntyCntrctManageVO vo) throws Exception {
		return mrtggGrntyCntrctManageService.selectEmailTmplatList(vo);
	}

}
