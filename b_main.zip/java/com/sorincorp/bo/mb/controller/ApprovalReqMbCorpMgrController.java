package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.bo.mb.model.ApprovalReqMbCorpMgrVO;
import com.sorincorp.bo.mb.model.ApprovalReqOrCdtlnMgrVO;
import com.sorincorp.bo.mb.model.CredtRepyVO;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.service.ApprovalReqMbCorpMgrService;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * DetailCorpInfo.java
 *
 * @version
 * @since 2021. 5. 24.
 * @author srec0030 (김영웅)
 */
@Slf4j
@Controller
@RequestMapping("/bo/mb")
@ComponentScan(basePackages = { "com.sorincorp.api.mb.service", "com.sorincorp.comm.util" })
public class ApprovalReqMbCorpMgrController {

	@Autowired
	private ApprovalReqMbCorpMgrService approvalReqMbCorpMgrService;
	@Autowired
	private MbCmnCodeService mbCmnCodeService;
	@Autowired
	private CustomValidator customValidator;
	@Autowired
	private UserInfoUtil userInfoUtil;
	@Autowired
	private ItCmnCodeService itCmnCodeService;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	final String RESPONSE_CODE = "rspnsCode";
	final String RESPONSE_MESSAGE = "rspnsMssage";

	/*
	 * @Autowired private EntrpsMberInfoService entrpsMberInfoService;
	 */

	/**
	 * <pre>
	 * 승인업체 화면으로 이동한다.
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectApprovalReqMbCorpList")
	public String selectCorpInfoList(ModelMap model, ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO, String entrpsNo) {

		try {
			List<MbCmnCodeVO> mberConfmSttusCodeList = mbCmnCodeService.selectCmnCodeList("MBER_CONFM_STTUS_CODE");
			model.addAttribute("mberConfmSttusCodeList", mberConfmSttusCodeList);

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			String oneWeek = DateUtil.addDays(today.replaceAll("-", ""), -7);
			String oneMonth = DateUtil.addMonths(today.replaceAll("-", ""), -1);
			String sixMonth = DateUtil.addMonths(today.replaceAll("-", ""), -6);
			String oneYear = DateUtil.addYears(today.replaceAll("-", ""), -1);
			String twoYear = DateUtil.addYears(today.replaceAll("-", ""), -2);

			model.addAttribute("today", today);
			model.addAttribute("oneWeek", oneWeek);
			model.addAttribute("oneMonth", oneMonth);
			model.addAttribute("sixMonth", sixMonth);
			model.addAttribute("oneYear", oneYear);
			model.addAttribute("twoYear", twoYear);

			// SLE_METAL_LIST 운영반영전에 삭제해야함
			ItCmnCodeVO vo = new ItCmnCodeVO();

			// 메탈코드 리스트
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");

			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);
			model.addAttribute("metalCodeList", metalCodeList);
			model.addAttribute("entrpsNo", entrpsNo);

			return "mb/approvalReqMbCorpList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 승인업체 리스트를 비동기 ajax로 조회한다.
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param approvalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectApprovalReqMbCorpListAjax")
	@ResponseBody
	public Map<String, Object> selectCorpInfoListAjax(@RequestBody ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception {
		// log.debug("approvalReqMbCorpMgrVO =======>" +
		// approvalReqMbCorpMgrVO.toString());
		List<ApprovalReqMbCorpMgrVO> approvalReqMbCorpList = approvalReqMbCorpMgrService.selectCorpInfoList(approvalReqMbCorpMgrVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalDataCount", approvalReqMbCorpMgrService.approvalReqMbCorpTotalList(approvalReqMbCorpMgrVO));
		map.put("dataList", approvalReqMbCorpList);
		return map;
	}

	/**
	 * <pre>
	 * 승인업체 정보를 상세조회한다.
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param approvalReqMbCorpMgrVO
	 * @param model
	 * @return 승인업체 상세정보
	 * @throws Exception
	 */
	@RequestMapping("/approvalReqMbCorpDetail")
	public String selectCorpInfoDetail(@RequestBody ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO, ModelMap model) throws Exception {

		String today = DateUtil.getNowDateTime("yyyy-MM-dd");

		List<MbCmnCodeVO> mberConfmSttusCodeList = mbCmnCodeService.selectCmnCodeList("MBER_CONFM_STTUS_CODE");
		List<MbCmnCodeVO> bsnmTyCodeList = mbCmnCodeService.selectCmnCodeList("BSNM_TY_CODE");
		List<MbCmnCodeVO> bsnmRegistSttusCodeList = mbCmnCodeService.selectCmnCodeList("BSNM_REGIST_STTUS_CODE");

		List<MbCmnCodeVO> credtGradCodeList = mbCmnCodeService.selectCmnCodeList("CREDT_GRAD_CODE");
		List<MbCmnCodeVO> entrpsGradCodeList = mbCmnCodeService.selectCmnCodeList("ENTRPS_GRAD_CODE");
		List<MbCmnCodeVO> entrpsEvlGradCodeList = mbCmnCodeService.selectCmnCodeList("ENTRPS_EVL_GRAD_CODE");
		List<MbCmnCodeVO> entrpsPurchsInclnGradCodeList = mbCmnCodeService.selectCmnCodeList("ENTRPS_PURCHS_INCLN_GRAD_CODE");
		List<MbCmnCodeVO> entrprsIndutySeCodeList = mbCmnCodeService.selectCmnCodeList("ENTRPRS_INDUTY_SE_CODE");

		List<ApprovalReqMbCorpMgrVO> attachFileList = approvalReqMbCorpMgrService.selectAttachFileList(approvalReqMbCorpMgrVO);
		ApprovalReqMbCorpMgrVO detailVO = approvalReqMbCorpMgrService.selectCorpInfoDetail(approvalReqMbCorpMgrVO.getEntrpsNo());
		detailVO.setConfmerNm(userInfoUtil.getUserName());

		// 금속 권한 리스트 조회
		List<ApprovalReqMbCorpMgrVO> metalAuthList = approvalReqMbCorpMgrService.selectMbEntrpsMetalAcctoAuthorSetupBas(approvalReqMbCorpMgrVO.getEntrpsNo());
		// 대출은행 리스트 조회
		List<ApprovalReqMbCorpMgrVO> lonGrntyBankUseAtList = approvalReqMbCorpMgrService.selectLonGrntyBankUseAtList(approvalReqMbCorpMgrVO.getEntrpsNo());
		// 주문 여신 기본 조회
		ApprovalReqOrCdtlnMgrVO orCdtlnMgrVO = approvalReqMbCorpMgrService.selectOrCdtlnBas();

		// 오늘이 여신 시작일보다 작을경우 여신 시작일로 셋팅.
		if (orCdtlnMgrVO != null) {
			if (orCdtlnMgrVO.getCdtlnBeginDe().compareTo(today) > 0) {
				today = orCdtlnMgrVO.getCdtlnBeginDe();
			}
		}

		String bankStr = "";
		String useAt = "";
		int cnt = 0;

		if (lonGrntyBankUseAtList != null) {
			for (int i = 0; i < lonGrntyBankUseAtList.size(); i++) {
				useAt = lonGrntyBankUseAtList.get(i).getUseAt();

				if ("Y".equals(useAt)) {
					if (cnt == 0) {
						bankStr += lonGrntyBankUseAtList.get(i).getBankCodeNm();
					} else {
						bankStr += ", " + lonGrntyBankUseAtList.get(i).getBankCodeNm();
					}
					cnt++;
				}
			}
		}

		model.addAttribute("today", today);
		model.addAttribute("mberConfmSttusCodeList", mberConfmSttusCodeList);
		model.addAttribute("bsnmTyCodeList", bsnmTyCodeList);
		model.addAttribute("bsnmRegistSttusCodeList", bsnmRegistSttusCodeList);
		model.addAttribute("credtGradCodeList", credtGradCodeList);
		model.addAttribute("entrpsGradCodeList", entrpsGradCodeList);
		model.addAttribute("entrpsEvlGradCodeList", entrpsEvlGradCodeList);
		model.addAttribute("entrpsPurchsInclnGradCodeList", entrpsPurchsInclnGradCodeList);
		model.addAttribute("entrprsIndutySeCodeList", entrprsIndutySeCodeList);
		model.addAttribute("attachFileList", attachFileList);
		model.addAttribute("approvalReqMbCorpMgrVO", detailVO);
		model.addAttribute("metalAuthList", metalAuthList);
		model.addAttribute("lonGrntyBankUseAtList", lonGrntyBankUseAtList);
		model.addAttribute("orCdtlnMgrVO", orCdtlnMgrVO);
		model.addAttribute("bankStr", bankStr);

		// SLE_METAL_LIST 운영반영전에 삭제해야함
		ItCmnCodeVO vo = new ItCmnCodeVO();
		vo.setMainCode("METAL_CODE");
		vo.setCodeDctwo("Y");
		vo.setUseAt("Y");
		List<ItCmnCodeVO> itemCodeList = itCmnCodeService.selectCmnCodeList(vo);
		model.addAttribute("itemCodeList", itemCodeList);

//		String entrpsNo = approvalReqMbCorpMgrVO.getEntrpsNo();
//		//업체 등급별 혜택 메탈 별 리스트
//		List<EntrpsGradeVO> entrpsGradeList = entrpsGradeService.getEntrpsGradeBnefInfoList(entrpsNo);
//		//업체 평가등급 정보
//		EntrpsGradeVO entrpsEvlGradeVO = entrpsGradeService.getEntrpsEvlGradeInfo(entrpsNo);
//		//업체별 구매성향등급 정보
		// EntrpsGradeVO entrpsPurchsInclnGradeVO =
		// entrpsGradeService.getEntrpsPurchsInclnGradeInfo(entrpsNo);
//		//구매성향등급 전체 리스트
		// List<EntrpsGradeVO> entrpsPurchsInclnGradeAllList =
		// entrpsGradeService.getEntrpsPurchsInclnGradeInfoAllList();
//
//
//		log.debug("entrpsGradeList ======>" + entrpsGradeList.toString());
//		log.debug("entrpsEvlGradeVO ======>" + entrpsEvlGradeVO.toString());
//		log.debug("entrpsPurchsInclnGradeVO ======>" + entrpsPurchsInclnGradeVO.toString());
//		log.debug("entrpsPurchsInclnGradeAllList ======>" + entrpsPurchsInclnGradeAllList.toString());

		return "mb/approvalReqMbCorpDetail.modal";
	}

	/**
	 * <pre>
	 * 승인업체 정보를 수정한다.
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param approvalReqMbCorpMgrVO
	 * @param model
	 * @param status
	 * @return 수정결과값
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/updateApprovalReqMbCorpr")
	@ResponseBody
	public ResponseEntity<Object> updateCorpInfoMgr(@RequestBody ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO, Model model, BindingResult bindingResult) {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}
		// log.debug("update vo :: "+approvalReqMbCorpMgrVO.toString());
		approvalReqMbCorpMgrVO.setTCode(approvalReqMbCorpMgrVO.getTeCode());
		if (approvalReqMbCorpMgrVO.isValidation()) {
			customValidator.validate(approvalReqMbCorpMgrVO, bindingResult, ApprovalReqMbCorpMgrVO.InsertAndUpdate.class);
		}

//		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
//			log.debug("bindingResult.hasErrors() =============>" + bindingResult.getAllErrors());
//			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
//		}

		int result = 0;
//		String mberConfmSttusCode = approvalReqMbCorpMgrVO.getMberConfmSttusCode();
//		log.debug("mberConfmSttusCode:: " + mberConfmSttusCode);
//		// TODO 변경승인인 "05" 도 api 해야되나?
//		// 승인인 경우 트레이딩에 정보 송신
//		if ("01".equals(mberConfmSttusCode)) {
//		    result = approvalReqMbCorpMgrService.updateCorpInfoMgr(approvalReqMbCorpMgrVO);
//
//		} else {
//			result = approvalReqMbCorpMgrService.updateCorpInfoMgr(approvalReqMbCorpMgrVO);
//		}
		try {
			result = approvalReqMbCorpMgrService.updateCorpInfoMgr(approvalReqMbCorpMgrVO);

			if (result > 0) {
				retVal.put(RESULT, SUCCESS);
				retVal.put(ERRMSG, "");
			} else {
				retVal.put(RESULT, FAIL);

				if (result == -99) {
					// 탈퇴승인
					retVal.put(ERRMSG, "주문진행건이 존재하여 탈퇴가 불가능한 업체입니다.");
				} else if (result == -98) {
					// 탈퇴승인
					retVal.put(ERRMSG, "가상계좌 잔액이 존재하여 탈퇴가 불가능한 업체입니다.");
				} else if (result == -97) {
					// 탈퇴승인
					retVal.put(ERRMSG, "계좌해지 중 오류가 발생하였습니다.");
				} else if (result == -96) {
					// 가입승인
					retVal.put(ERRMSG, "[STS] 시스템과 통신 장애가 발생하였습니다.\r\n케이지트레이딩 관리자에게 문의하세요.");
				} else if (result == -95) {
					// 가입승인
					retVal.put(ERRMSG, "[STS] T-CODE 생성 실패하였습니다.\r\n케이지트레이딩 관리자에게 문의하세요.");
				} else if (result == -94) {
					// 가입승인
					retVal.put(ERRMSG, "[ERP] ERP 업체코드 생성 실패하였습니다.\r\n케이지트레이딩 관리자에게 문의하세요.");
				} else {
					retVal.put(ERRMSG, "");
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);

	}

	@RequestMapping("/fileUploadApprovalReqMbCorpr")
	@ResponseBody
	public ResponseEntity<Object> fileUploadApprovalReqMbCorpr(MultipartHttpServletRequest mRequest) throws Exception {

		HashMap<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		HashMap<String, Object> fileMap = approvalReqMbCorpMgrService.saveAttachFile(mRequest);
		String result = (String) fileMap.get(RESULT);

		if (SUCCESS.equals(result)) {
			retVal.put(RESULT, SUCCESS);
			retVal.put("fileMap", fileMap);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, (String) fileMap.get("errMsg"));
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping(value = "/fileDeleteApprovalReqMbCorpr", method = RequestMethod.POST)
	@ResponseBody
	public Object fileDeleteApprovalReqMbCorpr(@RequestBody ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result = 1;
		String entrpsNo = approvalReqMbCorpMgrVO.getEntrpsNo();
		int docNo = approvalReqMbCorpMgrVO.getDocNo();
		// log.debug("entrpsNo ============>" + approvalReqMbCorpMgrVO.getEntrpsNo());
		// log.debug("docNo ============>" + approvalReqMbCorpMgrVO.getDocNo());

		result = approvalReqMbCorpMgrService.deleteAttachFile(entrpsNo, docNo);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return retVal;

	}

	@RequestMapping("/refundAccountReg")
	@ResponseBody
	public ResponseEntity<Object> refundAccountReg(@RequestBody ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		// log.debug("approvalReqMbCorpMgrVO.toString() ========> " +
		// approvalReqMbCorpMgrVO.toString());
		Map<Object, Object> rtn = approvalReqMbCorpMgrService.refundAccountReg(approvalReqMbCorpMgrVO);

		int result = (int) rtn.get(RESULT);
		String ewalletAcnutNo = (String) rtn.get("ewalletAcnutNo");

		if (result == 1) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
			retVal.put("ewalletAcnutNo", ewalletAcnutNo);
		} else {
			retVal.put(RESULT, FAIL);

			if (rtn.get("errMsg") != null && !"".equals(rtn.get("errMsg"))) {
				retVal.put(ERRMSG, rtn.get("errMsg"));
			} else {
				if (result == -1) {
					retVal.put(ERRMSG, "환불계좌 등록 전문통신 전송 실패");
				} else if (result == -2) {
					retVal.put(ERRMSG, "환불계좌 등록 전문통신 응답 실패");
				} else if (result == -3) {
					retVal.put(ERRMSG, "가상계좌 사용등록 승인 통보 실패");
				} else if (result == -4) {
					retVal.put(ERRMSG, "사용가능한 가상계좌번호가 없습니다.");
				}
			}

		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/updateMbEntrpsCrtfcInfoDtl")
	@ResponseBody
	public ResponseEntity<Object> updateMbEntrpsCrtfcInfoDtl(@RequestBody ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}
		// log.debug("approvalReqMbCorpMgrVO.toString() ========> " +
		// approvalReqMbCorpMgrVO.toString());
		int result = approvalReqMbCorpMgrService.updateMbEntrpsCrtfcInfoDtl(approvalReqMbCorpMgrVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/selectWrtmAuthorRate")
	@ResponseBody
	public ResponseEntity<Object> selectWrtmAuthorRate(@RequestBody ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();
		int wrtmAuthorRate = approvalReqMbCorpMgrService.selectWrtmAuthorRate(approvalReqMbCorpMgrVO.getEntrpsPurchsInclnGrad());

		if (wrtmAuthorRate > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put("wrtmAuthorRate", wrtmAuthorRate);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@PostMapping("/getBankLonLmtAm")
	@ResponseBody
	public ResponseEntity<Object> getBankLonLmtAm(@RequestBody CredtRepyVO credtRepyVO, Model model, BindingResult bindingResult) {

		log.debug("credtRepyVO =======>" + credtRepyVO.toString());
		Map<String, Object> resObj = new HashMap<>();
//		Map<String, Object> retVal = new HashMap<String, Object>();

		try {
			resObj = approvalReqMbCorpMgrService.getLonLmt(credtRepyVO);

			log.debug("respopnse " + resObj.toString());
			resObj.put(RESULT, SUCCESS);
			resObj.put(ERRMSG, "");

		} catch (Exception e) {
			log.error(e.getMessage());
			resObj.put(RESULT, FAIL);
			if (e.getMessage() != null && !"null".equals(e.getMessage()) && !"".equals(e.getMessage())) {
				resObj.put(ERRMSG, e.getMessage());
			} else {
				resObj.put(ERRMSG, "오류가 발생하였습니다. 관리자에게 문의해주세요.");
			}

			return ResponseEntity.status(HttpStatus.OK).body(resObj);
		}

		return ResponseEntity.status(HttpStatus.OK).body(resObj);
	}

	/**
	 * <pre>
	 * 케이지크레딧 보험번호 중복조회 ajax.
	 * </pre>
	 *
	 * @date 2022. 11. 14.
	 * @author srec0073
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 14.
	 *          srec0073 최초작성 ------------------------------------------------
	 * @param approvalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/checkSorinCreditPeurNoAjax")
	@ResponseBody
	public int checkSorinCreditPeurNoAjax(@RequestBody ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception {
		return approvalReqMbCorpMgrService.checkSorinCreditPeurNoAjax(approvalReqMbCorpMgrVO);
	}

	/**
	 * <pre>
	 * 평균가 LIVE 구매 등급 코드에 맞는 구매 비율 값 조회
	 * </pre>
	 * @date 2023. 8. 17.
	 * @author srec0051
	 * @param avrgpcLivePurchsGradCode
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/getAvrgpcPurchsRate")
	@ResponseBody
	public ResponseEntity<?> getAvrgpcPurchsRate(@RequestBody String avrgpcLivePurchsGradCode) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		try {
			double avrgpcPurchsRate = 0;
					//approvalReqMbCorpMgrService.getAvrgpcPurchsRate(avrgpcLivePurchsGradCode);
			retVal.put(RESULT, SUCCESS);
			retVal.put("avrgpcPurchsRate", avrgpcPurchsRate);
		} catch (Exception e) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "오류가 발생하였습니다. 관리자에게 문의하세요.");
		}

		return ResponseEntity.status(HttpStatus.OK).body(retVal);
	}

}
