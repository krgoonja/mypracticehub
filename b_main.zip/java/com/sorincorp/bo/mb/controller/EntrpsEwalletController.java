/**
 *
 */
package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.mb.model.EntrpsEwalletVO;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.EntrpsEwalletService;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * EntrpsDtlEwalletController.java
 * @version
 * @since 2021. 6. 9.
 * @author srec0009
 */
@Slf4j
@Controller
@RequestMapping("/bo/Member")
public class EntrpsEwalletController {


	@Autowired
	private EntrpsEwalletService entrpsEwalletService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;


	/**
	 * <pre>
	 * 처리내용: 고객사별 e-Wallet 내역조회
	 * </pre>
	 * @date 2021. 12. 3.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 3.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */


	/*
	 *   grid 1 : /bo/Member/selectEntrpsEwallet
	 *   grid 2 : /bo/Member/selectMbEwalletList
	 */
	@RequestMapping("/selectEntrpsEwallet")
	public String selectEntrpsEwallet(ModelMap model){
		try {
			List<MbCmnCodeVO> ewalletDelngSeCode = mbCmnCodeService.selectCmnCodeList("EWALLET_DELNG_SE_CODE");
			List<MbCmnCodeVO> ewalletExcclcTyCode = mbCmnCodeService.selectCmnCodeList("EWALLET_EXCCLC_TY_CODE");
			List<MbCmnCodeVO> bsnmTyCode = mbCmnCodeService.selectCmnCodeList("BSNM_TY_CODE");
			model.addAttribute("ewalletDelngSeCode", ewalletDelngSeCode);
			model.addAttribute("ewalletExcclcTyCode", ewalletExcclcTyCode);
			model.addAttribute("bsnmTyCode", bsnmTyCode);
			return "mb/entrpsEwalletList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	/**
	 * <pre>
	 * 처리내용: 이월렛 목록 조회
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param sampleVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsEwalletList")
	@ResponseBody
	public Map<String,Object> selectEntrpsEwalletList(@RequestBody EntrpsEwalletVO entrpsEwalletVO) throws Exception {

		Map<String,Object> map = new HashMap<String, Object>();
		List<MbEntrpsMbVO> selectEntrpsEwalletList = entrpsEwalletService.selectEntrpsEwalletList(entrpsEwalletVO);
		int totalDataCount = entrpsEwalletService.selectEntrpsEwalletListTotCnt(entrpsEwalletVO);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", selectEntrpsEwalletList);

		return map;
	}



}
