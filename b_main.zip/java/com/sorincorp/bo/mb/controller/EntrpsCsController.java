/**
 *
 */
package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.mb.model.EntrpsCsVO;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.EntrpsCsService;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * EntrpsOrderHstController.java
 * 
 * @version
 * @since 2021. 6. 28.
 * @author srec0009
 */
@Slf4j
@Controller
@RequestMapping("/bo/Member")
@ComponentScan({ "com.sorincorp.comm.*" })
public class EntrpsCsController {

	@Autowired
	private EntrpsCsService entrpsCsService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	@Autowired
	private EntrpsMbService entrpsMbService;

	/**
	 * <pre>
	 * 처리내용: 기업회원 > 상담/문의
	 * </pre>
	 * 
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsCs")
	public String selectEntrpsCs(Model model, String entrpsNo) {
		try {
			// 상담구분
			List<MbCmnCodeVO> inqryCnsltSeCode = mbCmnCodeService.selectCmnCodeList("INQRY_CNSLT_SE_CODE");
			// 문의 구분 - 대분류
			List<MbCmnCodeVO> inqrySeCode = mbCmnCodeService.selectCmnCodeList("INQRY_SE_CODE");
			// 처리 상태
			List<MbCmnCodeVO> inqryProcessSttusCode = mbCmnCodeService.selectCmnCodeList("INQRY_PROCESS_STTUS_CODE");

			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);

			model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
			model.addAttribute("entrpsNo", entrpsNo);

			model.addAttribute("inqryCnsltSeCode", inqryCnsltSeCode);
			model.addAttribute("inqrySeCode", inqrySeCode);
			model.addAttribute("inqryProcessSttusCode", inqryProcessSttusCode);

			return "mb/entrpsCsList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 기업회원 > 상담/문의 리스트 조회
	 * </pre>
	 * 
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsCsVO
	 * @param entrpsNo
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectEntrpsCsList")
	@ResponseBody
	public ResponseEntity<Object> selectEntrpsCsList(@RequestBody EntrpsCsVO entrpsCsVO, String entrpsNo, BindingResult bindingResult) throws Exception {
		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<Object>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		List<EntrpsCsVO> entrpsCsList = entrpsCsService.selectEntrpsCsList(entrpsCsVO);
		int totalDataCount = entrpsCsService.selectEntrpsCsListTotCnt(entrpsCsVO);
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", entrpsCsList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 기업회원 > 상담/문의 - 대분류에 따른 중분류 검색
	 * </pre>
	 * 
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param inqrySeCode
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectInqrySeDetailCode")
	@ResponseBody
	public List<MbCmnCodeVO> selectInqrySeDetailCode(@RequestBody int inqrySeCode, Model model) throws Exception {
		// 문의 구분 - 중분류
		List<MbCmnCodeVO> inqrySeDetailCode = entrpsCsService.selectInqrySeDetailCode(inqrySeCode);
		return inqrySeDetailCode;
	}

}
