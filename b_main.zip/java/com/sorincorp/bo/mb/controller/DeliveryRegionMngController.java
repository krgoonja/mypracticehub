package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.mb.model.DeliveryRegionMngVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.DeliveryRegionMngService;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * DeliveryRegionMngController.java
 *
 * @version
 * @since 2021. 6. 7.
 * @author srec0030
 */
@Slf4j
@Controller
@RequestMapping("/bo/mb")
public class DeliveryRegionMngController {

	@Autowired
	private DeliveryRegionMngService deliveryRegionMngService;
	@Autowired
	private EntrpsMbService entrpsMbService;
	@Autowired
	private CustomValidator customValidator;
	@Autowired
	private UserInfoUtil userInfoUtil;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	/**
	 * <pre>
	 * 배송지 리스트화면으로 이동한다.
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param model
	 * @return 배송지 구분 상세리스트
	 * @throws Exception
	 */
	@RequestMapping("/selectDeliveryRegionMngList")
	public String selectDeliveryRegionMngList(String entrpsNo, ModelMap model) {
		// log.debug("entrpsNo ==========>"+entrpsNo);
		try {
			List<DeliveryRegionMngVO> mbDlvrgSeDtlList = deliveryRegionMngService.selectMbDlvrgSeDtlListList(entrpsNo);
			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);

			model.addAttribute("mbDlvrgSeDtlList", mbDlvrgSeDtlList);
			model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
			model.addAttribute("entrpsNo", entrpsNo);

			return "mb/deliveryRegionMngList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 배송지 리스트를 조회한다.
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return 배송지 리스트
	 * @throws Exception
	 */
	@RequestMapping("/selectDeliveryRegionMngListAjax")
	@ResponseBody
	public Map<String, Object> selectDeliveryRegionMngListAjax(@RequestBody DeliveryRegionMngVO deliveryRegionMngVO) throws Exception {
		// log.debug("deliveryRegionMngVO =======>" + deliveryRegionMngVO.toString());
		List<DeliveryRegionMngVO> deliveryRegionMngList = deliveryRegionMngService.selectDeliveryRegionMngList(deliveryRegionMngVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalDataCount", deliveryRegionMngService.selectDeliveryRegionMngTotCnt(deliveryRegionMngVO));
		map.put("dataList", deliveryRegionMngList);

		return map;
	}

	/**
	 * <pre>
	 * 배송지를 삭제한다.
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deleteArray
	 * @return 삭제결과값
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping(value = "/deleteDeliveryRegion", method = RequestMethod.POST)
	@ResponseBody
	public Object deleteDeliveryRegion(@RequestParam(value = "deleteArray[]") List<String> deleteArray) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result = deliveryRegionMngService.deleteMbDlvrgBas(deleteArray);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return retVal;

	}

	/**
	 * <pre>
	 * 배송지 상세정보를 조회한다.
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @param model
	 * @return 배송지 상세정보
	 * @throws Exception
	 */
	@RequestMapping("/deliveryRegionMngDetail")
	public String selectDeliveryRegionMngDetail(@RequestBody DeliveryRegionMngVO deliveryRegionMngVO, ModelMap model) throws Exception {
		// @RequestParam("entrpsNo") String entrpsNo,
		// log.debug("deliveryRegionMngVO ===========>" +
		// deliveryRegionMngVO.toString());
		if ("".equals(deliveryRegionMngVO.getDlvrgNo()) || deliveryRegionMngVO.getDlvrgNo() == null) {
			deliveryRegionMngVO.setDlvrgNo("");
			model.addAttribute("deliveryRegionMngVO", deliveryRegionMngVO);
		} else {
			model.addAttribute("deliveryRegionMngVO", deliveryRegionMngService.selectDeliveryRegionMngDetail(deliveryRegionMngVO));
		}

		List<DeliveryRegionMngVO> mbDlvrgSeDtlList = deliveryRegionMngService.selectMbDlvrgSeDtlListList("all");
		model.addAttribute("mbDlvrgSeDtlList", mbDlvrgSeDtlList);

		return "mb/deliveryRegionMngDetail.modal";
	}

	/**
	 * <pre>
	 * 배송지 정보를 신규등록한다.
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @param model
	 * @param status
	 * @return 등록 결과값
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/insertDeliveryRegion")
	@ResponseBody
	public ResponseEntity<Object> insertDeliveryRegion(@RequestBody DeliveryRegionMngVO deliveryRegionMngVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}
		// log.debug(deliveryRegionMngVO.toString());
		customValidator.validate(deliveryRegionMngVO, bindingResult, DeliveryRegionMngVO.Insert.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			// log.debug("bindingResult.hasErrors() =============>" +
			// bindingResult.getAllErrors());
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = deliveryRegionMngService.insertDeliveryRegion(deliveryRegionMngVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 배송지 정보를 수정한다.
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @param model
	 * @param status
	 * @return 수정결과값
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/updateDeliveryRegion")
	@ResponseBody
	public ResponseEntity<Object> updateDeliveryRegion(@RequestBody DeliveryRegionMngVO deliveryRegionMngVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}
		// log.debug(deliveryRegionMngVO.toString());
		customValidator.validate(deliveryRegionMngVO, bindingResult, DeliveryRegionMngVO.Update.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			// log.debug("bindingResult.hasErrors() =============>" +
			// bindingResult.getAllErrors());
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = deliveryRegionMngService.updateDeliveryRegion(deliveryRegionMngVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
}
