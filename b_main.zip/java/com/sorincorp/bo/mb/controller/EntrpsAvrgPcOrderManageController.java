package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.bo.or.model.AvrgPcOrderManageVO;
import com.sorincorp.bo.or.service.AvrgPcOrderManageService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/Member")
public class EntrpsAvrgPcOrderManageController {

	@Autowired
	private EntrpsMbService entrpsMbService;

	@Autowired
	private ItCmnCodeService itCmnCodeService;

	@Autowired
	private AvrgPcOrderManageService avrgPcOrderManageService;


	@RequestMapping("/selectEntrpsAvrgPcOrderManage")
	public String selectEntrpsAvrgPcOrderManage(ModelMap model,String entrpsNo) throws Exception{
		try {
			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);

			//메탈코드
			ItCmnCodeVO vo = new ItCmnCodeVO();
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");
			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);

			model.put("entrpsNo", entrpsNo);
			model.put("totalSlepcEtcList", totalSlepcEtcList);
			model.put("itemCodeList", metalCodeList);

			return "mb/entrpsAvrgPcOrderManageList";
		}catch(Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	@RequestMapping("/selectEntrpsAvrgPcOrderManageList")
	@ResponseBody
	public Map<String, Object> selectEntrpsAvrgPcOrderManageList(@RequestBody AvrgPcOrderManageVO vo) throws Exception{
		Map<String, Object> map = new HashMap<String, Object>();

		int totalDataCount =  avrgPcOrderManageService.selectAvrgPcOrderManageCount(vo);
		map.put("totalDataCount", totalDataCount);
		if(totalDataCount!=0) {
			List<AvrgPcOrderManageVO> dataList = avrgPcOrderManageService.selectAvrgPcOrderManageList(vo);
			map.put("dataList", dataList);
		}
		return map;
	}

}
