/**
 *
 */
package com.sorincorp.bo.mb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.mb.model.EntrpsCsCommentVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.EntrpsCsCommentService;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/Member")
public class EntrpsCsCommentController {

	@Autowired
	private EntrpsMbService entrpsMbService;

	@Autowired
	private EntrpsCsCommentService entrpsCsCommentService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	/**
	 * <pre>
	 * 처리내용: 기업회원 > CS코멘트 : 조회
	 * </pre>
	 *
	 * @date 2022. 02. 25.
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 2. 25.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsCsComment")
	public String selectEntrpsCs(Model model, EntrpsCsCommentVO entrpsCsCommentVO, String entrpsNo) {
		try {
			log.debug("entrpsNo :: " + entrpsNo);
			entrpsCsCommentVO.setEntrpsNo(entrpsNo);

			// 총 주문 금액, 총 주문 건수, 총 VOC 건수
			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);
			model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
			model.addAttribute("entrpsNo", entrpsNo);

			// Cs 코멘트
			entrpsCsCommentVO = entrpsCsCommentService.selectEntrpsCsComment(entrpsNo);
			model.addAttribute("entrpsCsCommentVO", entrpsCsCommentVO);

			return "mb/entrpsCsComment";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 기업회원 > CS코멘트 : 수정
	 * </pre>
	 *
	 * @date 2022. 2. 25.
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 2. 25.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param entrpsCsCommentVO
	 * @param model
	 * @param status
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/updateEntrpsCsComment")
	@ResponseBody
	public String updateEntrpsCsComment(@RequestBody EntrpsCsCommentVO entrpsCsCommentVO, Model model, SessionStatus status) throws Exception {

		int result = 0;
		String rtnCode = "";

		if (userInfoUtil.getAccountInfo() == null) {
			result = 0;
		} else {
			result = entrpsCsCommentService.updateEntrpsCsComment(entrpsCsCommentVO);
		}

		if (result == 1) {
			rtnCode = "S";
		} else if (result == 0) {
			rtnCode = "F";
		}
		status.setComplete();
		return rtnCode;
	}

}
