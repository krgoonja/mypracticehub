package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEntrpsGradMngVO;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.bo.mb.service.MbEntrpsGradMngService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/mb")
public class MbEntrpsGradMngController {

	@Autowired
	private MbEntrpsGradMngService mbEntrpsGradMngService;
	@Autowired
	private MbCmnCodeService mbCmnCodeService;
	@Autowired
	private CustomValidator customValidator;
	@Autowired
	private UserInfoUtil userInfoUtil;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	@RequestMapping("/selectMbEntrpsGradMngList")
	public String selectMbEntrpsGradMngList(ModelMap model) {

		try {

			String gubun = "insert";

			MbEntrpsGradMngVO mbEntrpsGradMngVO = mbEntrpsGradMngService.selectMbEntrpsGradMngInfo();
			List<MbEntrpsGradMngVO> mbEntrpsGradMngList = mbEntrpsGradMngService.selectMbEntrpsGradMngList();
			List<MbCmnCodeVO> entrpsGradCodeList = mbCmnCodeService.selectCmnCodeList("ENTRPS_GRAD_CODE");
			List<MbCmnCodeVO> entrpsGradEvlMthCodeList = mbCmnCodeService.selectCmnCodeList("GRAD_EVL_MTH_CODE");

			if (mbEntrpsGradMngList != null && mbEntrpsGradMngList.size() > 0) {
				gubun = "update";
			}

			model.addAttribute("mbEntrpsGradMngInfo", mbEntrpsGradMngVO);
			model.addAttribute("mbEntrpsGradMngList", mbEntrpsGradMngList);
			model.addAttribute("entrpsGradCodeList", entrpsGradCodeList);
			model.addAttribute("entrpsGradEvlMthCodeList", entrpsGradEvlMthCodeList);
			model.addAttribute("gubun", gubun);

			return "mb/mbEntrpsGradMng";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/updateMbEntrpsGradMng")
	@ResponseBody
	public ResponseEntity<Object> updateMbEntrpsGradMng(@RequestBody MbEntrpsGradMngVO mbEntrpsGradMngVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		MbEntrpsGradMngVO mbEntrpsGradMngVOTmp = null;

		for (int i = 0; i < mbEntrpsGradMngVO.getMbEntrpsGradMngSaveList().size(); i++) {

			mbEntrpsGradMngVOTmp = mbEntrpsGradMngVO.getMbEntrpsGradMngSaveList().get(i);

			if ("update".equals(mbEntrpsGradMngVOTmp.getGubun())) {
				customValidator.validate(mbEntrpsGradMngVOTmp, bindingResult, MbEntrpsGradMngVO.Update.class);
			} else {
				customValidator.validate(mbEntrpsGradMngVOTmp, bindingResult, MbEntrpsGradMngVO.Insert.class);
			}

			if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
				log.debug("bindingResult.hasErrors() =>" + bindingResult.getAllErrors());
				return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
			}
		}

		int result = 0;
		String gubun = mbEntrpsGradMngVO.getGubun();
		int updateCnt = 0;

		if ("update".equals(gubun)) {
			updateCnt = mbEntrpsGradMngService.selectMbEntrpsGradMngChgCnt(mbEntrpsGradMngVO.getMbEntrpsGradMngSaveList());

			if (updateCnt > 0) {
				// 업체등급관리 update
				result = mbEntrpsGradMngService.updateMbEntrpsGradMng(mbEntrpsGradMngVO.getMbEntrpsGradMngSaveList());
			} else {
				result = -1;
			}
		} else {
			// 업체등급관리 insert
			result = mbEntrpsGradMngService.updateMbEntrpsGradMng(mbEntrpsGradMngVO.getMbEntrpsGradMngSaveList());
		}

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put("gubun", "update");
			retVal.put(ERRMSG, "");
		} else if (result == -1) {
			retVal.put(RESULT, FAIL);
			retVal.put("gubun", gubun);
			retVal.put(ERRMSG, "변경된 내용이 없습니다.");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put("gubun", gubun);
			retVal.put(ERRMSG, "");
		}

		List<MbEntrpsGradMngVO> mbEntrpsGradMngList = mbEntrpsGradMngService.selectMbEntrpsGradMngList();
		retVal.put("mbEntrpsGradMngList", mbEntrpsGradMngList);

		MbEntrpsGradMngVO vo = mbEntrpsGradMngService.selectMbEntrpsGradMngInfo();
		retVal.put("mbEntrpsGradMngInfo", vo);

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/selectMbEntrpsGradMngChgHistList")
	public String selectMbEntrpsGradMngChgHistList(ModelMap model) {

		try {

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			String oneWeek = DateUtil.addDays(today.replaceAll("-", ""), -7);
			String oneMonth = DateUtil.addMonths(today.replaceAll("-", ""), -1);
			String sixMonth = DateUtil.addMonths(today.replaceAll("-", ""), -6);
			String oneYear = DateUtil.addYears(today.replaceAll("-", ""), -1);

			model.addAttribute("today", today);
			model.addAttribute("oneWeek", oneWeek);
			model.addAttribute("oneMonth", oneMonth);
			model.addAttribute("sixMonth", sixMonth);
			model.addAttribute("oneYear", oneYear);

			return "mb/mbEntrpsGradMngChgHistList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectMbEntrpsGradMngChgHistListAjax")
	@ResponseBody
	public Map<String, Object> selectMbEntrpsGradMngChgHistListAjax(@RequestBody MbEntrpsGradMngVO mbEntrpsGradMngVO, ModelMap model) throws Exception {

		List<MbEntrpsGradMngVO> mbEntrpsGradMngChgHistList = mbEntrpsGradMngService.selectMbEntrpsGradMngChgHistList(mbEntrpsGradMngVO);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalDataCount", mbEntrpsGradMngService.selectMbEntrpsGradMngChgHistTotCnt(mbEntrpsGradMngVO));
		map.put("dataList", mbEntrpsGradMngChgHistList);
		return map;
	}

	@RequestMapping("/selectMbEntrpsGradMngChgHstDetail")
	public String selectMbEntrpsGradMngChgHstDetail(@RequestBody MbEntrpsGradMngVO mbEntrpsGradMngVO, ModelMap model) throws Exception {

		List<MbCmnCodeVO> entrpsGradCodeList = mbCmnCodeService.selectCmnCodeList("ENTRPS_GRAD_CODE");
		List<MbCmnCodeVO> entrpsGradEvlMthCodeList = mbCmnCodeService.selectCmnCodeList("GRAD_EVL_MTH_CODE");
		model.addAttribute("entrpsGradCodeList", entrpsGradCodeList);
		model.addAttribute("entrpsGradEvlMthCodeList", entrpsGradEvlMthCodeList);

		List<MbEntrpsGradMngVO> mbEntrpsGradMngChgHistDetailList = mbEntrpsGradMngService.selectMbEntrpsGradMngChgHistDetailList(mbEntrpsGradMngVO);
		model.addAttribute("mbEntrpsGradMngChgHistDetailList", mbEntrpsGradMngChgHistDetailList);
		model.addAttribute("mbEntrpsGradMngVO", mbEntrpsGradMngVO);

		return "mb/mbEntrpsGradMngChgHstDetail.modal";
	}

}
