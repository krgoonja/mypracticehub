package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.model.MbMrtggGrntyVO;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.bo.mb.service.MbMrtggGrntyService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/Member")
public class MbMrtggGrntyController {

	@Autowired
	private MbMrtggGrntyService mbMrtggGrntyService;
	@Autowired
	private MbCmnCodeService mbCmnCodeService;
	@Autowired
	private EntrpsMbService entrpsMbService;
	@Autowired
	private CustomValidator customValidator;
	@Autowired
	private UserInfoUtil userInfoUtil;

	@RequestMapping("/selectMbMrtggGrntyList")
	public String selectMbMrtggGrntyList(String entrpsNo, ModelMap model) {

		try {
			List<MbCmnCodeVO> mrtggDelngTyCodeList = mbCmnCodeService.selectCmnCodeList("MRTGG_DELNG_TY_CODE");
			model.addAttribute("mrtggDelngTyCodeList", mrtggDelngTyCodeList);

//			MbMrtggGrntyVO mbMrtggGrntyVO = mbMrtggGrntyService.selectMbEntrpsMrtggBasInfo(entrpsNo);
//			model.addAttribute("mbEntrpsMrtggBasInfo", mbMrtggGrntyVO);

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			String oneWeek = DateUtil.addDays(today.replaceAll("-", ""), -7);
			String oneMonth = DateUtil.addMonths(today.replaceAll("-", ""), -1);
			String sixMonth = DateUtil.addMonths(today.replaceAll("-", ""), -6);
			String oneYear = DateUtil.addYears(today.replaceAll("-", ""), -1);

			model.addAttribute("today", today);
			model.addAttribute("oneWeek", oneWeek);
			model.addAttribute("oneMonth", oneMonth);
			model.addAttribute("sixMonth", sixMonth);
			model.addAttribute("oneYear", oneYear);

			List<MbMrtggGrntyVO> mbMrtggGrntyNoList = mbMrtggGrntyService.selectMbMrtggGrntyNoList(entrpsNo, "01"); // 여신구분코드 01: 전자상거래보증 조회
			model.addAttribute("mbMrtggGrntyNoList", mbMrtggGrntyNoList);

			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);

			model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
			model.addAttribute("entrpsNo", entrpsNo);

			return "mb/mbMrtggGrntyList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectMbMrtggGrntyDtlListAjax")
	@ResponseBody
	public Map<String, Object> selectMbMrtggGrntyDtlListAjax(@RequestBody MbMrtggGrntyVO mbMrtggGrntyVO) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

//		String grntyNo = "";
//
//		if (mbMrtggGrntyNoList != null && mbMrtggGrntyNoList.size() > 0) {
//			grntyNo = mbMrtggGrntyNoList.get(0).getGrntyNo();
//		}
//
//		mbMrtggGrntyVO.setGrntyNo(grntyNo);

		List<MbMrtggGrntyVO> mbMrtggGrntyList = mbMrtggGrntyService.selectMbMrtggGrntyList(mbMrtggGrntyVO);
		MbMrtggGrntyVO vo = mbMrtggGrntyService.selectMbEntrpsMrtggBasInfo(mbMrtggGrntyVO);

		map.put("mbEntrpsMrtggBasInfo", vo);
		map.put("totalDataCount", mbMrtggGrntyService.selectMbMrtggGrntyTotalCnt(mbMrtggGrntyVO));
		map.put("dataList", mbMrtggGrntyList);

		return map;
	}

	@RequestMapping("/selectMbEntrpsMrtggGrntyMngList")
	public String selectMbEntrpsMrtggGrntyMngList(ModelMap model) {

		try {
			List<MbCmnCodeVO> mrtggDelngTyCodeList = mbCmnCodeService.selectCmnCodeList("MRTGG_DELNG_TY_CODE");
			model.addAttribute("mrtggDelngTyCodeList", mrtggDelngTyCodeList);

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			String oneWeek = DateUtil.addDays(today.replaceAll("-", ""), -7);
			String oneMonth = DateUtil.addMonths(today.replaceAll("-", ""), -1);
			String sixMonth = DateUtil.addMonths(today.replaceAll("-", ""), -6);
			String oneYear = DateUtil.addYears(today.replaceAll("-", ""), -1);

			model.addAttribute("today", today);
			model.addAttribute("oneWeek", oneWeek);
			model.addAttribute("oneMonth", oneMonth);
			model.addAttribute("sixMonth", sixMonth);
			model.addAttribute("oneYear", oneYear);

			return "mb/mbEntrpsMrtggGrntyMngList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectMbEntrpsMrtggGrntyListAjax")
	@ResponseBody
	public Map<String, Object> selectMbEntrpsMrtggGrntyListAjax(@RequestBody MbMrtggGrntyVO mbMrtggGrntyVO) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		List<MbMrtggGrntyVO> entrpsMbMrtggGrntyList = mbMrtggGrntyService.selectMbEntrpsMrtggGrntyList(mbMrtggGrntyVO);

		map.put("totalDataCount", mbMrtggGrntyService.selectMbEntrpsMrtggGrntyTotalCnt(mbMrtggGrntyVO));
		map.put("dataList", entrpsMbMrtggGrntyList);

		return map;
	}

	// 케이지크레딧
	@RequestMapping("/selectMbSorinCreditList")
	public String selectMbSorinCreditList(String entrpsNo, ModelMap model) {

		try {
			List<MbCmnCodeVO> mrtggDelngTyCodeList = mbCmnCodeService.selectCmnCodeList("MRTGG_DELNG_TY_CODE");
			model.addAttribute("mrtggDelngTyCodeList", mrtggDelngTyCodeList);

//			MbMrtggGrntyVO mbMrtggGrntyVO = mbMrtggGrntyService.selectMbEntrpsMrtggBasInfo(entrpsNo);
//			model.addAttribute("mbEntrpsMrtggBasInfo", mbMrtggGrntyVO);

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			String oneWeek = DateUtil.addDays(today.replaceAll("-", ""), -7);
			String oneMonth = DateUtil.addMonths(today.replaceAll("-", ""), -1);
			String sixMonth = DateUtil.addMonths(today.replaceAll("-", ""), -6);
			String oneYear = DateUtil.addYears(today.replaceAll("-", ""), -1);

			model.addAttribute("today", today);
			model.addAttribute("oneWeek", oneWeek);
			model.addAttribute("oneMonth", oneMonth);
			model.addAttribute("sixMonth", sixMonth);
			model.addAttribute("oneYear", oneYear);

			List<MbMrtggGrntyVO> mbMrtggGrntyNoList = mbMrtggGrntyService.selectMbMrtggGrntyNoList(entrpsNo, "02"); // 여신구분코드 02: 케이지크레딧 조회
			model.addAttribute("mbMrtggGrntyNoList", mbMrtggGrntyNoList);

			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);

			model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
			model.addAttribute("entrpsNo", entrpsNo);

			return "mb/mbSorinCreditList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
}
