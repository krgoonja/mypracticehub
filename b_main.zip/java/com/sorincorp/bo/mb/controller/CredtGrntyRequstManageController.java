package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.mb.model.CredtGrntyRequstManageVO;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.service.CredtGrntyRequstManageService;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/Member")
public class CredtGrntyRequstManageController {

	@Autowired
	private MbCmnCodeService mbCmnCodeService;
	@Autowired
	private CredtGrntyRequstManageService credtGrntyRequstManageService;

	@RequestMapping("/selectCredtGrntyRequstManageList")
	public String selectCredtGrntyRequstManageList(ModelMap model) {

		try {
			// 전자상거래보증 진행상태 코드
			List<MbCmnCodeVO> mrtggGrntyProgrsSttusCodeList = mbCmnCodeService.selectCmnCodeList("MRTGG_GRNTY_PROGRS_STTUS_CODE");
			model.addAttribute("mrtggGrntyProgrsSttusCodeList", mrtggGrntyProgrsSttusCodeList);

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			String oneWeek = DateUtil.addDays(today.replaceAll("-", ""), -7);
			String oneMonth = DateUtil.addMonths(today.replaceAll("-", ""), -1);
			String halfMonth = DateUtil.addDays(today.replaceAll("-", ""), -15);
			String oneYear = DateUtil.addYears(today.replaceAll("-", ""), -1);

			model.addAttribute("today", today);
			model.addAttribute("oneWeek", oneWeek);
			model.addAttribute("oneMonth", oneMonth);
			model.addAttribute("halfMonth", halfMonth);
			model.addAttribute("oneYear", oneYear);

			return "mb/credtGrntyRequstManageList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectCredtGrntyRequstManageListAjax")
	@ResponseBody
	public Map<String, Object> selectCredtGrntyRequstManageListAjax(@RequestBody CredtGrntyRequstManageVO credtGrntyRequstManageVO) throws Exception {

		String startDtm = credtGrntyRequstManageVO.getStartDate();
		String endtDtm = credtGrntyRequstManageVO.getEndDate();

		if (startDtm != null && !"".equals(startDtm)) {
			startDtm = startDtm + " 00:00:00";
			credtGrntyRequstManageVO.setStartDate(startDtm);
		}

		if (endtDtm != null && !"".equals(endtDtm)) {
			endtDtm = endtDtm + " 23:59:59";
			credtGrntyRequstManageVO.setEndDate(endtDtm);
		}
		List<CredtGrntyRequstManageVO> credtGrntyRequstManageList = credtGrntyRequstManageService.selectCredtGrntyRequstManageList(credtGrntyRequstManageVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalDataCount", credtGrntyRequstManageService.selectCredtGrntyRequstManageTotCnt(credtGrntyRequstManageVO));
		map.put("dataList", credtGrntyRequstManageList);
		return map;
	}
}
