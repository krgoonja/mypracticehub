package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEvlGradMngVO;
import com.sorincorp.bo.mb.model.MbInvtInclnGradMngVO;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.bo.mb.service.MbInvtInclnGradMngService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/Member")
public class MbInvtInclnGradMngController {

	@Autowired
	private MbInvtInclnGradMngService mbInvtInclnGradMngService;
	@Autowired
	private MbCmnCodeService mbCmnCodeService;
	@Autowired
	private CustomValidator customValidator;
	@Autowired
	private UserInfoUtil userInfoUtil;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	@RequestMapping("/selectMbPurchsInclnGradMngList")
	public String selectMbPurchsInclnGradMngList(ModelMap model) {

		try {
			List<MbInvtInclnGradMngVO> mbPurchsInclnGradMngList = mbInvtInclnGradMngService.selectMbInvtInclnGradMngList();
			MbInvtInclnGradMngVO vo = mbInvtInclnGradMngService.selectMbInvtInclnGradMng();
			List<MbCmnCodeVO> entrpsPurchsInclnGradCodeList = mbCmnCodeService.selectCmnCodeList("PURCHS_INCLN_GRAD_CODE");

			model.addAttribute("mbPurchsInclnGradMngList", mbPurchsInclnGradMngList);
			model.addAttribute("mbPurchsInclnGradMngInfo", vo);
			model.addAttribute("entrpsPurchsInclnGradCodeList", entrpsPurchsInclnGradCodeList);

			return "mb/mbInvtInclnGradMng";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/updateMbPurchsInclnGradMng")
	@ResponseBody
	public ResponseEntity<Object> updateMbInvtInclnGradMng(@RequestBody MbInvtInclnGradMngVO mbInvtInclnGradMngVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result = 0;
		// 투자성향등급관리 update
		result = mbInvtInclnGradMngService.updateMbInvtInclnGradMng(mbInvtInclnGradMngVO.getMbPurchsInclnGradMngSaveList());

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else if (result == -1) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "변경된 내용이 없습니다.");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		MbInvtInclnGradMngVO vo = mbInvtInclnGradMngService.selectMbInvtInclnGradMng();
		retVal.put("mbPurchsInclnGradMngInfo", vo);

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/selectMbPurchsInclnGradMngChgHistList")
	public String selectMbPurchsInclnGradMngChgHistList(ModelMap model) {

		try {

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			String oneWeek = DateUtil.addDays(today.replaceAll("-", ""), -7);
			String oneMonth = DateUtil.addMonths(today.replaceAll("-", ""), -1);
			String sixMonth = DateUtil.addMonths(today.replaceAll("-", ""), -6);
			String oneYear = DateUtil.addYears(today.replaceAll("-", ""), -1);

			model.addAttribute("today", today);
			model.addAttribute("oneWeek", oneWeek);
			model.addAttribute("oneMonth", oneMonth);
			model.addAttribute("sixMonth", sixMonth);
			model.addAttribute("oneYear", oneYear);

			return "mb/mbInvtInclnGradMngChgHistList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectMbInvtInclnGradMngChgHistListAjax")
	@ResponseBody
	public Map<String, Object> selectMbInvtInclnGradMngChgHistListAjax(@RequestBody MbInvtInclnGradMngVO mbInvtInclnGradMngVO, ModelMap model) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();

		List<MbInvtInclnGradMngVO> mbInvtInclnGradMngChgHistList = mbInvtInclnGradMngService.selectMbPurchsInclnGradMngChgHistList(mbInvtInclnGradMngVO);
		map.put("totalDataCount", mbInvtInclnGradMngService.selectMbPurchsInclnGradMngChgHistTotCnt(mbInvtInclnGradMngVO));
		map.put("dataList", mbInvtInclnGradMngChgHistList);
		return map;
	}

	@RequestMapping("/selectMbInvtInclnGradMngChgHistDetail")
	public String selectMbInvtInclnGradMngChgHistDetail(@RequestBody MbInvtInclnGradMngVO mbInvtInclnGradMngVO, ModelMap model) throws Exception {

		List<MbCmnCodeVO> entrpsPurchsInclnGradCodeList = mbCmnCodeService.selectCmnCodeList("PURCHS_INCLN_GRAD_CODE");
		List<MbEvlGradMngVO> mbPurchsInclnGradMngChgHistDetailList = mbInvtInclnGradMngService.selectMbPurchsInclnGradMngChgHistDetailList(mbInvtInclnGradMngVO);

		model.addAttribute("entrpsPurchsInclnGradCodeList", entrpsPurchsInclnGradCodeList);
		model.addAttribute("mbPurchsInclnGradMngChgHistDetailList", mbPurchsInclnGradMngChgHistDetailList);
		model.addAttribute("mbInvtInclnGradMngVO", mbInvtInclnGradMngVO);
		return "mb/mbInvtInclnGradMngChgHistDetail.modal";
	}
}
