package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.model.MbDeliveryCarMngVO;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.bo.mb.service.MbDeliveryCarMngService;
import com.sorincorp.comm.deliveryCarMng.model.DeliveryCarMngCommVO;
import com.sorincorp.comm.deliveryCarMng.service.DeliveryCarMngCommService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("bo/Member")
public class MbDeliveryCarMngController {

	@Autowired
	private EntrpsMbService entrpsMbService;

	@Autowired
	private MbDeliveryCarMngService mbDeliveryCarMngService;

	@Autowired
	private DeliveryCarMngCommService deliveryCarMngCommService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	@RequestMapping("/selectMbDeliveryCarMng")
	public String selectMbDeliveryCarMng(Model model, String entrpsNo, MbDeliveryCarMngVO mbDeliveryCarMngVO) {
		try {
			mbDeliveryCarMngVO.setEntrpsNo(entrpsNo);

			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);
			int totalVhcleCnt = mbDeliveryCarMngService.selectMbVhcleInfoListCnt(mbDeliveryCarMngVO);
			int totalDrvCnt = mbDeliveryCarMngService.selectMbDrvArticlInfoListCnt(mbDeliveryCarMngVO);

			model.addAttribute("entrpsNo", entrpsNo);
			model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
			model.addAttribute("totalVhcleCnt", totalVhcleCnt);
			model.addAttribute("totalDrvCnt", totalDrvCnt);

			return "mb/mbDeliveryCarMngList";

		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg",e);
			return "error/503";
		}

	}

	@RequestMapping("/selectMbVhcleInfoList")
	@ResponseBody
	public Map<String,Object> selectMbVhcleInfoList(Model model, @RequestBody MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception{
		Map<String,Object> map = new HashMap<String, Object>();

		List<MbDeliveryCarMngVO> dataList = mbDeliveryCarMngService.selectMbVhcleInfoList(mbDeliveryCarMngVO);
		int totalDataCount = mbDeliveryCarMngService.selectMbVhcleInfoListCnt(mbDeliveryCarMngVO);

		map.put("dataList", dataList);
		map.put("totalDataCount", totalDataCount);

		return map;

	}

	@RequestMapping("/selectMbDrvArticlInfoList")
	@ResponseBody
	public Map<String,Object> selectMbDrvArticlInfoList(Model model, @RequestBody MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception{
		Map<String,Object> map = new HashMap<String, Object>();

		List<MbDeliveryCarMngVO> dataList = mbDeliveryCarMngService.selectMbDrvArticlInfoList(mbDeliveryCarMngVO);
		int totalDataCount = mbDeliveryCarMngService.selectMbDrvArticlInfoListCnt(mbDeliveryCarMngVO);

		map.put("dataList", dataList);
		map.put("totalDataCount", totalDataCount);

		return map;

	}

	@RequestMapping("/insertMbDeliveryCarMngView")
	public String insertMbDeliveryCarMngView(Model model, @RequestBody MbDeliveryCarMngVO mbDeliveryCarMngVO) {
		try {

			model.addAttribute("mbDeliveryCarMngVO", mbDeliveryCarMngVO);
			return "mb/mbDeliveryCarMngDetail.modal";

		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg",e);
			return "error/503";
		}

	}

	@RequestMapping("/insertMbVhcleInfoAjax")
	@ResponseBody
	public ResponseEntity<Object> insertMbVhcleInfoAjax(@RequestBody MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception{
		Map<String,Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		DeliveryCarMngCommVO deliveryCarMngCommVO = new DeliveryCarMngCommVO();
		deliveryCarMngCommVO.setEntrpsNo(mbDeliveryCarMngVO.getEntrpsNo());
		deliveryCarMngCommVO.setVhcleNo(mbDeliveryCarMngVO.getVhcleNo());
		deliveryCarMngCommVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
		deliveryCarMngCommVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

		int result = deliveryCarMngCommService.insertDeliveryCar(deliveryCarMngCommVO);

		if(result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		}else if(result < 0){
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "중복된 차량정보가 존재합니다.");
		}else{
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal,HttpStatus.OK);

	}

	@RequestMapping("/insertMbDrvArticlInfoAjax")
	@ResponseBody
	public ResponseEntity<Object> insertMbDrvArticlInfoAjax(@RequestBody MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception{
		Map<String,Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		DeliveryCarMngCommVO deliveryCarMngCommVO = new DeliveryCarMngCommVO();
		deliveryCarMngCommVO.setEntrpsNo(mbDeliveryCarMngVO.getEntrpsNo());
		deliveryCarMngCommVO.setDrverNm(mbDeliveryCarMngVO.getDrverNm());
		deliveryCarMngCommVO.setDrverTlphonNo(mbDeliveryCarMngVO.getDrverTlphonNo());
		deliveryCarMngCommVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
		deliveryCarMngCommVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		int result = deliveryCarMngCommService.insertDeliveryDriver(deliveryCarMngCommVO);

		if(result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		}else if(result < 0){
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "중복된 운전기사정보가 존재합니다.");
		}else{
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal,HttpStatus.OK);

	}

	@RequestMapping("/updateMbDeliveryCarMngView")
	public String updateMbDeliveryCarMngView(Model model, @RequestBody MbDeliveryCarMngVO mbDeliveryCarMngVO) {
		try {
			MbDeliveryCarMngVO mbDeliveryCarMngInfo = null;

			if("vhcle".equals(mbDeliveryCarMngVO.getModalPageCode())) {
				mbDeliveryCarMngInfo = mbDeliveryCarMngService.selectMbVhcleInfo(mbDeliveryCarMngVO);

			}else if("drver".equals(mbDeliveryCarMngVO.getModalPageCode())) {
				mbDeliveryCarMngInfo = mbDeliveryCarMngService.selectMbDrvArticlInfo(mbDeliveryCarMngVO);
			}
			mbDeliveryCarMngInfo.setModalPageCode(mbDeliveryCarMngVO.getModalPageCode());
			mbDeliveryCarMngInfo.setModalPageStatus(mbDeliveryCarMngVO.getModalPageStatus());

			model.addAttribute("mbDeliveryCarMngVO", mbDeliveryCarMngInfo);
			return "mb/mbDeliveryCarMngDetail.modal";

		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg",e);
			return "error/503";
		}

	}

	@RequestMapping("/updateMbVhcleInfoAjax")
	@ResponseBody
	public ResponseEntity<Object> updateMbVhcleInfoAjax(@RequestBody MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception{
		Map<String,Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		DeliveryCarMngCommVO deliveryCarMngCommVO = new DeliveryCarMngCommVO();
		deliveryCarMngCommVO.setEntrpsNo(mbDeliveryCarMngVO.getEntrpsNo());
		deliveryCarMngCommVO.setVhcleNo(mbDeliveryCarMngVO.getVhcleNo());
		deliveryCarMngCommVO.setVhcleinfoSn(mbDeliveryCarMngVO.getVhcleinfoSn());
		deliveryCarMngCommVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
		deliveryCarMngCommVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

		int result = deliveryCarMngCommService.updateDeliveryCar(deliveryCarMngCommVO);

		if(result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		}else if(result < 0){
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "중복된 차량정보가 존재합니다.");
		}else{
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal,HttpStatus.OK);

	}

	@RequestMapping("/updateMbDrvArticlInfoAjax")
	@ResponseBody
	public ResponseEntity<Object> updateMbDrvArticlInfoAjax(@RequestBody MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception{
		Map<String,Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		DeliveryCarMngCommVO deliveryCarMngCommVO = new DeliveryCarMngCommVO();
		deliveryCarMngCommVO.setEntrpsNo(mbDeliveryCarMngVO.getEntrpsNo());
		deliveryCarMngCommVO.setDrverNm(mbDeliveryCarMngVO.getDrverNm());
		deliveryCarMngCommVO.setDrverTlphonNo(mbDeliveryCarMngVO.getDrverTlphonNo());
		deliveryCarMngCommVO.setDrvarticlSn(mbDeliveryCarMngVO.getDrvarticlSn());
		deliveryCarMngCommVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
		deliveryCarMngCommVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		int result = deliveryCarMngCommService.updateDeliveryDriver(deliveryCarMngCommVO);

		if(result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		}else if(result < 0){
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "중복된 운전기사정보가 존재합니다.");
		}else{
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal,HttpStatus.OK);

	}

	@RequestMapping("/deleteMbVhcleInfoAjax")
	@ResponseBody
	public ResponseEntity<Object> deleteMbVhcleInfoAjax(@RequestBody MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception{
		Map<String,Object> retVal = new HashMap<String, Object>();

		int result = mbDeliveryCarMngService.deleteMbVhcleInfoList(mbDeliveryCarMngVO);
		if(result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		}else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal,HttpStatus.OK);

	}

	@RequestMapping("/deleteMbDrvArticlInfoAjax")
	@ResponseBody
	public ResponseEntity<Object> deleteMbDrvArticlInfoAjax(@RequestBody MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception{
		Map<String,Object> retVal = new HashMap<String, Object>();

		int result = mbDeliveryCarMngService.deleteMbDrvArticlInfoList(mbDeliveryCarMngVO);
		if(result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		}else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal,HttpStatus.OK);

	}




}
