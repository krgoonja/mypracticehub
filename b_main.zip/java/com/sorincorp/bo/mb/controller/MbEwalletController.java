/**
 *
 */
package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.model.MbEwalletVO;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.bo.mb.service.MbEwalletService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * EntrpsDtlEwalletController.java
 * 
 * @version
 * @since 2021. 6. 9.
 * @author srec0009
 */
@Slf4j
@Controller
@RequestMapping("/bo/Member")
public class MbEwalletController {

	@Autowired
	private MbEwalletService mbEwalletService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private EntrpsMbService entrpsMbService;

	/**
	 * <pre>
	 * 처리내용: 기업회원조회> 업체명 선택 > E-wallet
	 * </pre>
	 * 
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @param mbEwalletVO
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectMbEwallet")
	public String selectMbEwallet(ModelMap model, MbEwalletVO mbEwalletVO, String entrpsNo) {
		try {
			List<MbCmnCodeVO> mberGradCodeList = mbCmnCodeService.selectCmnCodeList("EWALLET_DELNG_SE_CODE");
			StringBuilder mberGradCode = new StringBuilder(StringUtils.EMPTY);
			mberGradCode.append("");
			mberGradCode.append(CommonConstants.COLONE);
			mberGradCode.append("전체");
			mberGradCode.append(CommonConstants.SEMI_COLONE);

			for (MbCmnCodeVO lib : mberGradCodeList) {
				mberGradCode.append(lib.getSubCode());
				mberGradCode.append(":");
				mberGradCode.append(lib.getCodeNm());
				mberGradCode.append(";");
			}

			model.addAttribute("mberGradCode", mberGradCode);

			// SETLE_MTHD_CODE
			Map <String, String> setleKndCd = commonCodeService.getSubCodes("SETLE_MTHD_CODE");
			Map <String, String> setleDtlKndCd = commonCodeService.getSubCodes("SETLE_MTHD_DETAIL_CODE");
			for (Entry<String, String> entry : setleDtlKndCd.entrySet()) {
				if (entry.getKey().startsWith("40")) {
					setleKndCd.replace("40", entry.getValue()); //결제 종류 "여신(40)" 대체
				}
			}
			//결제 종류 "게좌이체" 제거
			setleKndCd.remove("80");

			model.addAttribute("setleKndCd", setleKndCd);

			mbEwalletVO.setEntrpsNo(entrpsNo);
			String ewalletBlce = mbEwalletService.selectMbEwalletBlce(mbEwalletVO);
			model.addAttribute("ewalletBlce", ewalletBlce);

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			String oneWeek = DateUtil.addDays(today.replaceAll("-", ""), -7);
			String oneMonth = DateUtil.addMonths(today.replaceAll("-", ""), -1);
			String sixMonth = DateUtil.addMonths(today.replaceAll("-", ""), -6);
			String oneYear = DateUtil.addYears(today.replaceAll("-", ""), -1);
			String twoYear = DateUtil.addYears(today.replaceAll("-", ""), -2);

			model.addAttribute("today", today);
			model.addAttribute("oneWeek", oneWeek);
			model.addAttribute("oneMonth", oneMonth);
			model.addAttribute("sixMonth", sixMonth);
			model.addAttribute("oneYear", oneYear);
			model.addAttribute("twoYear", twoYear);

			mbEwalletVO.setStartDate(oneWeek);
			mbEwalletVO.setEndDate(today);

			int totalDataCount = mbEwalletService.selectMbEwalletListTotCnt(mbEwalletVO);
			model.addAttribute("totalDataCount", totalDataCount);

			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);

			model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
			model.addAttribute("entrpsNo", entrpsNo);

			return "mb/mbEwalletList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 이월렛 목록 조회
	 * </pre>
	 * 
	 * @date 2021. 6. 9.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 9.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param sampleVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectMbEwalletList")
	@ResponseBody
	public Map<String, Object> selectMbEwalletList(@RequestBody MbEwalletVO mbEwalletVO, String entrpsNo) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		if (mbEwalletVO.getEntrpsNo() == null) {
			mbEwalletVO.setEntrpsNo(entrpsNo);
		}

		int totalDataCount = mbEwalletService.selectMbEwalletListTotCnt(mbEwalletVO);
		List<MbEwalletVO> ewalletList = mbEwalletService.selectMbEwalletList(mbEwalletVO);

		String ewalletBlce = mbEwalletService.selectMbEwalletBlce(mbEwalletVO);
		map.put("ewalletBlceNow", ewalletBlce);
		map.put("totalDataCount", totalDataCount);
		map.put("dataList", ewalletList);

		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 이월렛 목록 조회 (엑셀 다운로드)
	 * </pre>
	 * @date 2023. 11. 20.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 20.		bok3117				최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @return
	 * @throws Exception
	 */
	  @RequestMapping("/selectMbEwalletListDataForExcel")
	  @ResponseBody
	  public ResponseEntity<?> selectMbEwalletListDataForExcel(@RequestBody MbEwalletVO searchVO) throws Exception { 
		  Map<String, Object> map = new HashMap<String, Object>(); 
		  searchVO.setRecordCountPerPage(10000000);

		  List<MbEwalletVO> dataList = mbEwalletService.selectMbEwalletList(searchVO);
		  map.put("dataList", dataList);
		  
		  return new ResponseEntity<>(map, HttpStatus.OK); 
	  }
}
