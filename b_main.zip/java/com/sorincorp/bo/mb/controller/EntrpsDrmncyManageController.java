/**
 *
 */
package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.EntrpsDrmncyManageService;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;


/**
 * EntrpsDrmncyManageController.java
 *
 * @version
 * @since 2024. 1. 26.
 * @author sein
 */
@Slf4j
@Controller
@RequestMapping("/bo/Member")
public class EntrpsDrmncyManageController {

	@Autowired
	private EntrpsDrmncyManageService entrpsDrmncyManageService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private ItCmnCodeService itCmnCodeService;

	
	/**
	 * <pre>
	 * 처리내용: 휴먼 기업 회원 목록(90일이상 주문이력이 없는 업체)
	 * </pre>
	 * @date 2024. 1. 26.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2024. 1. 26.	  	sein				최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsDrmncyManage")
	public String selectEntrpsDrmncyManage(Model model) {
		try {
			// 공통코드

			// 승인상태코드
			List<MbCmnCodeVO> mberConfmSttusCode = mbCmnCodeService.selectCmnCodeList("MBER_CONFM_STTUS_CODE");
			model.addAttribute("mberConfmSttusCode", mberConfmSttusCode);

			// 사업자유형코드
			List<MbCmnCodeVO> bsnmTyCode = mbCmnCodeService.selectCmnCodeList("BSNM_TY_CODE");
			model.addAttribute("bsnmTyCode", bsnmTyCode);

			// 등급코드
			List<MbCmnCodeVO> mberGradCode = mbCmnCodeService.selectCmnCodeList("ENTRPS_GRAD_CODE");
			model.addAttribute("entrpsGradCode", mberGradCode);

			// 평가등급코드
			List<MbCmnCodeVO> entrpsEvlGradCode = mbCmnCodeService.selectCmnCodeList("ENTRPS_EVL_GRAD_CODE");
			model.addAttribute("entrpsEvlGradCode", entrpsEvlGradCode);

			ItCmnCodeVO vo = new ItCmnCodeVO();

			// 메탈코드 리스트
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");

			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);
			model.addAttribute("metalCodeList", metalCodeList);

			return "mb/entrpsDrmncyManageList";

		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 기업 회원 목록
	 * </pre>
	 *
	 * @date 2024. 1. 26.
	 * @author sein
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2024. 1. 26.
	 *          sein 최초작성 ------------------------------------------------
	 * @param entrpsMbVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectEntrpsDrmncyManageList")
	@ResponseBody
	public Map<String, Object> selectEntrpsDrmncyManageList(@RequestBody MbEntrpsMbVO entrpsMbVO) throws Exception {

		Map<String, Object> map = new HashMap<>();

		int totalDataCount = entrpsDrmncyManageService.selectEntrpsDrmncyManageListTotCnt(entrpsMbVO);
		List<MbEntrpsMbVO> selectEntrpsMbList = entrpsDrmncyManageService.selectEntrpsDrmncyManageList(entrpsMbVO);

		log.debug("selectEntrpsMbListTotCnt ::" + totalDataCount);
		map.put("totalDataCount", totalDataCount);
		map.put("dataList", selectEntrpsMbList);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 기업 회원 휴면등록 및 휴면해제
	 * </pre>
	 *
	 * @date 2024. 01. 29.
	 * @author sein
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2024. 01. 29.
	 *          sein 최초작성 ------------------------------------------------
	 * @param entrpsMbList
	 * @return
	 */
	@PostMapping("/updateEntrpsDrmncyList")
	@ResponseBody
	public ResponseEntity<Object> updateEntrpsDrmncyList(@RequestBody List<MbEntrpsMbVO> entrpsMbList) throws Exception {
		int result = 0;
		Map<String, Object> map = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			map.put("result", result);
			return new ResponseEntity<>(map, HttpStatus.OK);
		} else {
			result = entrpsDrmncyManageService.updateEntrpsDrmncyList(entrpsMbList);
		}

		map.put("result", result);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}


	@PostMapping("/selectDrmncyListGridDataForExcel")
	public ResponseEntity<?> selectDrmncyListGridDataForExcel(@RequestBody MbEntrpsMbVO mbEntrpsMbVO, BindingResult bindingResult) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		mbEntrpsMbVO.setRecordCountPerPage(10000000); // Excel Export 전용 Query를 만들경우 작정 안해도 됨
		List<MbEntrpsMbVO> excelList = entrpsDrmncyManageService.selectEntrpsDrmncyManageList(mbEntrpsMbVO);

		map.put("dataList", excelList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

}
