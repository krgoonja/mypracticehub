package com.sorincorp.bo.mb.controller;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.bo.mb.model.SmsSvcVO;
import com.sorincorp.bo.mb.service.SmsSvcService;
import com.sorincorp.bo.op.model.MetalWorldVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Controller
@RequestMapping("/bo/mb")
public class SmsSvcController {

    @Autowired
    private SmsSvcService smsSvcService;

    @Autowired
    CommonCodeService commonCodeService;

    @Autowired
    private UserInfoUtil userInfoUtil;

    /**
     * <pre>
     * 처리내용: 문자서비스 화면 이동
     * </pre>
     * @date 2024. 6. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     *  2024. 6. 19.			hamyoonsic			최초작성
     * ------------------------------------------------
     * @param model
     * @return
     * @throws Exception
     */
    @RequestMapping("/selectSmsSvc")
    public String selectSmsSvc(ModelMap model) {
        try {
            SmsSvcVO smsSvcVO = new SmsSvcVO();
            List<SmsSvcVO> templateList = smsSvcService.selectTemplate(smsSvcVO);
            model.addAttribute("templateList", templateList);
            return "mb/smsSvc";
        } catch(Exception e){
            log.error(e.getMessage());
            HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
            return "error/503";
        }
    }

    /**
     * <pre>
     * 처리내용: 목록 조회
     * </pre>
     * @date 2024. 6. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     *  2024. 6. 19.			hamyoonsic			최초작성
     * ------------------------------------------------
     * @param
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/selectSmsSvcAjax", method={RequestMethod.POST})
    @ResponseBody
    public Map<String,Object> selectSmsSvcAjax(@RequestBody SmsSvcVO gridParam) throws Exception {
        Map<String,Object> map = new HashMap<String, Object>();
        try {
            List<SmsSvcVO> entrpsList = smsSvcService.selectSmsSvcAjax(gridParam);
            map.put("dataList", entrpsList);
            map.put("totalDataCount", entrpsList.size());
        } catch (Exception e) {
            map.put("errorMsg",e.getMessage());
        }
        return map;
    }

    /**
     * <pre>
     * 처리내용: 메세지 전송
     * </pre>
     * @date 2024. 6. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2024. 6. 19.			    hamyoonsic			최초작성
     * ------------------------------------------------
     * @param
     * @return
     * @throws Exception
     */
    @PostMapping("/insertSms")
    @ResponseBody
    public ResponseEntity<?> insertSms(@RequestBody SmsSvcVO smsVO) throws Exception {
        try {
            smsSvcService.insertSms(smsVO);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            log.error("SmsSvcController insertSms error " + e.getMessage());
            return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * <pre>
     * 처리내용: 문자서비스 템플릿 조회
     * </pre>
     * @date 2024. 6. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2024. 6. 19.			    hamyoonsic			최초작성
     * ------------------------------------------------
     * @param
     * @return
     * @throws Exception
     */
    @PostMapping("/selectTemplate")
    @ResponseBody
    public List<SmsSvcVO> selectTemplate(@RequestBody(required = false) SmsSvcVO smsVO) throws Exception {
        List<SmsSvcVO> result = smsSvcService.selectTemplate(smsVO);
        return result;
    }

    /**
     * <pre>
     * 처리내용: 문자서비스 템플릿 등록
     * </pre>
     * @date 2024. 6. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2024. 6. 19.			    hamyoonsic			최초작성
     * ------------------------------------------------
     * @param
     * @return
     * @throws Exception
     */
    @PostMapping("/insertTemplate")
    @ResponseBody
    public ResponseEntity<Object> insertTemplate(@RequestBody SmsSvcVO smsVO) throws Exception {
        int key = 0;
        try {
            key = smsSvcService.insertTemplate(smsVO);
            return new ResponseEntity<>(key,HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(key,HttpStatus.BAD_REQUEST);
        }
    }

    /**
     * <pre>
     * 처리내용: 문자서비스 템플릿 수정
     * </pre>
     * @date 2024. 6. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2024. 6. 19.			    hamyoonsic			최초작성
     * ------------------------------------------------
     * @param
     * @return
     * @throws Exception
     */
    @PostMapping("/updateTemplate")
    @ResponseBody
    public ResponseEntity<Object> updateTemplate(@RequestBody SmsSvcVO smsVO) throws Exception {
        smsSvcService.updateTemplate(smsVO);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * <pre>
     * 처리내용: 문자서비스 템플릿 삭제
     * </pre>
     * @date 2024. 6. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2024. 6. 19.			    hamyoonsic			최초작성
     * ------------------------------------------------
     * @param
     * @return
     * @throws Exception
     */
    @PostMapping("/deleteTemplate")
    @ResponseBody
    public ResponseEntity<Object> deleteTemplate(@RequestBody SmsSvcVO smsVO) throws Exception {
        smsSvcService.deleteTemplate(smsVO);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * <pre>
     * 처리내용: 주소록 화면 이동
     * </pre>
     * @date 2024. 6. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2024. 6. 19.			    hamyoonsic			최초작성
     * ------------------------------------------------
     * @param
     * @return
     * @throws Exception
     */
    @RequestMapping("/selectAdbkList")
    public String selectadbkList(ModelMap model) {
        try {
            //model.addAttribute("metalClCodeList", smsSvcService.getSubCodesRetVo("METAL_CL_CODE"));
            //model.addAttribute("templateList", templateList);
            return "mb/adbkList";
        } catch(Exception e){
            log.error(e.getMessage());
            HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
            return "error/503";
        }
    }
    /**
     * <pre>
     * 처리내용: 목록 조회
     * </pre>
     * @date 2024. 6. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     *  2024. 6. 19.			hamyoonsic			최초작성
     * ------------------------------------------------
     * @param
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/selectSmsAdbkList", method={RequestMethod.POST})
    @ResponseBody
    public Map<String,Object> selectadbkAjax(@RequestBody SmsSvcVO gridParam) throws Exception {
        List<SmsSvcVO> entrpsList = smsSvcService.selectSmsAdbkList(gridParam);
        Map<String,Object> map = new HashMap<String, Object>();

        map.put("dataList", entrpsList);
        map.put("totalDataCount", entrpsList.size());
        return map;
    }

    /**
     * <pre>
     * 처리내용: 주소록 멤버 조회
     * </pre>
     * @date 2024. 6. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     *  2024. 6. 19.			hamyoonsic			최초작성
     * ------------------------------------------------
     * @param
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/selectSmsAdbkMberList", method={RequestMethod.POST})
    @ResponseBody
    public Map<String,Object> selectSmsAdbkMberList(@RequestBody SmsSvcVO gridParam) throws Exception {
        List<SmsSvcVO> entrpsList = smsSvcService.selectSmsAdbkMberList(gridParam);
        Map<String,Object> map = new HashMap<String, Object>();

        map.put("dataList", entrpsList);
        map.put("totalDataCount", entrpsList.size());
        return map;
    }

    /**
     * <pre>
     * 처리내용: 주소록 멤버 수정
     * </pre>
     * @date 2024. 6. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일 					작성자				변경내용
     * ------------------------------------------------
     * 2024. 6. 19.			srec0072			최초작성
     * ------------------------------------------------
     * @param mwo
     * @return
     * @throws Exception
     */
    @PostMapping("/insertAndUpdateAdbk")
    public ResponseEntity<?> insertAndUpdateAdbk(@RequestBody SmsSvcVO gridParam) throws Exception{

        Map<String, Object> map = new HashMap<String, Object>();
        try {
            int mssageAdbkSn = smsSvcService.insertAndUpdateAdbk(gridParam);
            map.put("mssageAdbkSn",mssageAdbkSn);
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    /**
     * <pre>
     * 처리내용: 주소록 삭제
     * </pre>
     * @date 2024. 6. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     *  2024. 6. 19.			hamyoonsic			최초작성
     * ------------------------------------------------
     * @param
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/deleteAdbkAjax", method={RequestMethod.POST})
    @ResponseBody
    public ResponseEntity<?> deleteAdbkAjax(@RequestBody SmsSvcVO gridParam) throws Exception {
        smsSvcService.deleteAdbkBas(gridParam);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
