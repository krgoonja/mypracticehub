/**
 *
 */
package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.model.MbTotSetleDtlsVO;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.bo.mb.service.MbTotSetleDtlsService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * MbTotSetleDtlsController.java
 * @version
 * @since 2022. 8. 25.
 * @author srec0073
 */
@Slf4j
@Controller
@RequestMapping("/bo/Member")
public class MbTotSetleDtlsController {

	@Autowired
	private MbTotSetleDtlsService mbTotSetleDtlsService;

	@Autowired
	private EntrpsMbService entrpsMbService;

	@Autowired
	private CommonCodeService commonCodeService;


	/**
	 * <pre>
	 * 처리내용: 기업회원조회> 업체명 선택 > 결제내역
	 * </pre>
	 * @date 2022. 8. 25.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0073			최초작성
	 * ------------------------------------------------
	 * @param sampleVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectMbTotSetleDtls")
	public String selectMbTotSetleDtlsList(ModelMap model, MbTotSetleDtlsVO mbTotSetleDtlsVO, String entrpsNo) {
		try {
			mbTotSetleDtlsVO.setEntrpsNo(entrpsNo);

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			String oneWeek = DateUtil.addDays(today.replaceAll("-", ""), -7);
			String oneMonth = DateUtil.addMonths(today.replaceAll("-", ""), -1);
			String sixMonth = DateUtil.addMonths(today.replaceAll("-", ""), -6);
			String oneYear = DateUtil.addYears(today.replaceAll("-", ""), -1);
			String twoYear = DateUtil.addYears(today.replaceAll("-", ""), -2);
			String cdtlnSvcSeCode = mbTotSetleDtlsService.selectCdtlnSvcSeCode(entrpsNo);


			model.addAttribute("today", today);
			model.addAttribute("oneWeek", oneWeek);
			model.addAttribute("oneMonth", oneMonth);
			model.addAttribute("sixMonth", sixMonth);
			model.addAttribute("oneYear", oneYear);
			model.addAttribute("twoYear", twoYear);
			model.addAttribute("cdtlnSvcSeCode", cdtlnSvcSeCode);

			mbTotSetleDtlsVO.setStartDate(oneWeek);
			mbTotSetleDtlsVO.setEndDate(today);

			// 거래내역 총건수 조회.
			int totalDataCount = mbTotSetleDtlsService.selectMbTotSetleDtlsListCnt(mbTotSetleDtlsVO);
			model.addAttribute("totalDataCount", totalDataCount);

			// 기타 건수 조회.
			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);

			model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
			model.addAttribute("entrpsNo", entrpsNo);

			return "mb/mbTotSetleList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 전체 결제내역 목록 조회
	 * </pre>
	 * @date 2022. 8. 10.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 10.			srec0073			최초작성
	 * ------------------------------------------------
	 * @param setleDtlsMngVO
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/selectMbTotSetleDtlsList")
	public Map<String,Object> selectSetleDtlsSearch(@RequestBody MbTotSetleDtlsVO mbTotSetleDtlsVO, String entrpsNo) throws Exception {
		Map<String,Object> map = new HashMap<String, Object>();

		mbTotSetleDtlsVO.setEntrpsNo(entrpsNo);

		// 거래내역 총건수 조회.
		int totalDataCount = mbTotSetleDtlsService.selectMbTotSetleDtlsListCnt(mbTotSetleDtlsVO);
		// 거래내역 조회.
		List<MbTotSetleDtlsVO> setleDtlsList = mbTotSetleDtlsService.selectMbTotSetleDtlsList(mbTotSetleDtlsVO);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", setleDtlsList);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 결제수단별 결제유형 조회조건 리스트 조회
	 * </pre>
	 * @date 2022. 08. 26.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 08. 26.		srec0073			최초작성
	 * ------------------------------------------------
	 * @param setleDtlsMngVO
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/selectSetleTypeDtlAjax")
	public ResponseEntity<Object> selectSetleTypeDtlAjax() throws Exception {
		Map<String, Object> retVal = new HashMap<>();
		Map<String, String> delngSeCode = new HashMap<String, String>();
		// 이월랫 거래유형코드 조회.
		Map<String, CommonCodeVO> ewalletDelngSeCode = commonCodeService.getFilterCodeRetVo("EWALLET_DELNG_SE_CODE", null, "CODE_REFRNONE", "Y");
		ewalletDelngSeCode.forEach((key, value) -> {
			delngSeCode.put(value.getSubCode(), value.getCodeChrctrRefrnone());
		});
		// 전자상거래보증 거래유형코드 조회.
		Map<String, String> mrtggDelngTyCode = commonCodeService.getFilterCode("MRTGG_DELNG_TY_CODE", null, null, null);
		// 구매자금 거래유형코드 조회.
		Map<String, String> lonDelngTyCode = commonCodeService.getFilterCode("LON_DELNG_TY_CODE", null, null, null);
		retVal.put("result", "S");
		retVal.put("errMsg", "");
		retVal.put("ewalletDelngSeCode", delngSeCode);
		retVal.put("mrtggDelngTyCode", mrtggDelngTyCode);
		retVal.put("lonDelngTyCode", lonDelngTyCode);
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

}
