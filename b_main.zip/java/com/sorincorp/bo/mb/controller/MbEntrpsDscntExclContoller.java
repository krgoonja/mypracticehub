package com.sorincorp.bo.mb.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEntrpsDscntExclVO;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.bo.mb.service.MbEntrpsDscntExclService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/mb")
public class MbEntrpsDscntExclContoller {

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private ItCmnCodeService itCmnCodeService;
	
	@Autowired
	private MbEntrpsDscntExclService mbEntrpsDscntExclService;

	private static String RESULT = "result";
	private static String CATEGORYNO = "categoryNo";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	
	/**
	 * <pre>
	 * 처리내용: 할인 제외 업체 페이지 조회
	 * </pre>
	  * @date 2024. 5. 29.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 29.				hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param DscntExclEntrpsVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectMbEntrpsDscntExcl")
	public String selectEntrpsMb(Model model) {
		try {

			// 공통코드

			// 승인상태코드
			List<MbCmnCodeVO> mberConfmSttusCode = mbCmnCodeService.selectCmnCodeList("MBER_CONFM_STTUS_CODE");
			model.addAttribute("mberConfmSttusCode", mberConfmSttusCode);

			// 사업자유형코드
			List<MbCmnCodeVO> bsnmTyCode = mbCmnCodeService.selectCmnCodeList("BSNM_TY_CODE");
			model.addAttribute("bsnmTyCode", bsnmTyCode);

			// 등급코드
			List<MbCmnCodeVO> mberGradCode = mbCmnCodeService.selectCmnCodeList("ENTRPS_GRAD_CODE");
			model.addAttribute("entrpsGradCode", mberGradCode);

			// 평가등급코드
			List<MbCmnCodeVO> entrpsEvlGradCode = mbCmnCodeService.selectCmnCodeList("ENTRPS_EVL_GRAD_CODE");
			model.addAttribute("entrpsEvlGradCode", entrpsEvlGradCode);
			
			// 할인 구분 코드
			List<MbCmnCodeVO> dscntSeCode = mbCmnCodeService.selectCmnCodeList("DSCNT_SE_CODE");
			model.addAttribute("dscntSeCode", dscntSeCode);

			ItCmnCodeVO vo = new ItCmnCodeVO();

			// 메탈코드 리스트
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");

			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);
			model.addAttribute("metalCodeList", metalCodeList);
			
			return "mb/mbEntrpsDscntExcl";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 할인 제외 업체 목록 조회
	 * </pre>
	  * @date 2024. 5. 29.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 29.				hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param DscntExclEntrpsVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/getMbEntrpsDscntExclList")
	public ResponseEntity<?> getCouponPolicyList(@RequestBody MbEntrpsDscntExclVO mbEntrpsDscntExclVO) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();
		List<MbEntrpsDscntExclVO> mbEntrpsDscntExclList = new ArrayList<MbEntrpsDscntExclVO>();
		int totalDataCount = 0;
		
		try {
			mbEntrpsDscntExclList = mbEntrpsDscntExclService.getMbEntrpsDscntExclList(mbEntrpsDscntExclVO);
			totalDataCount = mbEntrpsDscntExclService.getMbEntrpsDscntExclListCnt(mbEntrpsDscntExclVO);
		} catch (Exception e) {
			// TODO: handle exception
			log.info("[OrdtmDscntCouponContoller.OrdtmDscntCouponList Error] " + e.getMessage());
		}

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", mbEntrpsDscntExclList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 할인 제외 업체 추가 등록 팝업
	 * </pre>
	 * @date 2024. 5. 31.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 31.				hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/getMbEntrpsDscntExclModal")
	public String ordtmDscntCouponDtl(Model model) throws Exception {
		try {
			// 공통코드

			// 승인상태코드
			/*
			List<MbCmnCodeVO> mberConfmSttusCode = mbCmnCodeService.selectCmnCodeList("MBER_CONFM_STTUS_CODE");
			model.addAttribute("mberConfmSttusCode", mberConfmSttusCode);
			*/

			// 사업자유형코드
			List<MbCmnCodeVO> bsnmTyCode = mbCmnCodeService.selectCmnCodeList("BSNM_TY_CODE");
			model.addAttribute("bsnmTyCode", bsnmTyCode);

			// 등급코드
			List<MbCmnCodeVO> mberGradCode = mbCmnCodeService.selectCmnCodeList("ENTRPS_GRAD_CODE");
			model.addAttribute("entrpsGradCode", mberGradCode);

			// 평가등급코드
			List<MbCmnCodeVO> entrpsEvlGradCode = mbCmnCodeService.selectCmnCodeList("ENTRPS_EVL_GRAD_CODE");
			model.addAttribute("entrpsEvlGradCode", entrpsEvlGradCode);
			
			// 할인 구분 코드
			List<MbCmnCodeVO> dscntSeCode = mbCmnCodeService.selectCmnCodeList("DSCNT_SE_CODE");
			model.addAttribute("dscntSeCode", dscntSeCode);
			
			// 기업 업종 구분 코드
			List<MbCmnCodeVO> entrprsIndutySeCode = mbCmnCodeService.selectCmnCodeList("ENTRPRS_INDUTY_SE_CODE");
			model.addAttribute("entrprsIndutySeCode", entrprsIndutySeCode);

			ItCmnCodeVO vo = new ItCmnCodeVO();

			// 메탈코드 리스트
			vo.setMainCode("METAL_CODE");
			vo.setCodeDctwo("Y");
			vo.setUseAt("Y");

			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);
			model.addAttribute("metalCodeList", metalCodeList);
			
			return "mb/mbEntrpsDscntExclModal.modal";
		} catch (Exception e) {
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503.modal";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 기업 회원 목록
	 * </pre>
	 * @date 2024. 5. 31.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 31.				hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/getEntrpsMbList")
	@ResponseBody
	public ResponseEntity<?> selectEntrpsMbList(@RequestBody MbEntrpsDscntExclVO mbEntrpsDscntExclVO) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();
		List<MbEntrpsDscntExclVO> getEntrpsMbList = new ArrayList<MbEntrpsDscntExclVO>();
		int totalDataCount = 0;
		
		try {
			getEntrpsMbList = mbEntrpsDscntExclService.getEntrpsMbList(mbEntrpsDscntExclVO);
			totalDataCount = mbEntrpsDscntExclService.getEntrpsMbListCnt(mbEntrpsDscntExclVO);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		map.put("totalDataCount", totalDataCount);
		map.put("dataList", getEntrpsMbList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 기업 회원 목록
	 * </pre>
	 * @date 2024. 5. 31.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 31.				hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertUpdateMbEntrpsDscntExcl")
	@ResponseBody
	public ResponseEntity<Object> insertUpdateMbEntrpsDscntExcl(@RequestBody MbEntrpsDscntExclVO mbEntrpsDscntExclVO) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		boolean result = false;
		try {
			if (userInfoUtil.getAccountInfo() == null) {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
				retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
				return new ResponseEntity<>(retVal, HttpStatus.OK);
			}
			
			result = mbEntrpsDscntExclService.insertUpdateMbEntrpsDscntExcl(mbEntrpsDscntExclVO);
			
			if (result == true) {
				retVal.put(RESULT, SUCCESS);
				retVal.put(ERRMSG, "");
			} else if (result == false) {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "");
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
}
