package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.cs.model.ArrrgTrgterVO;
import com.sorincorp.bo.cs.service.ArrrgTrgterService;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.EntrpsMbService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/Member")
public class EntrpsArrrgTrgterController {

	@Autowired
	private ArrrgTrgterService arrrgTrgterService;

	@Autowired
	private EntrpsMbService entrpsMbService;

	@RequestMapping("/selectEntrpsArrrgTrgterList")
	public String viewEntrpsArrrgTrgterList(String entrpsNo, ModelMap model) {
		try {
			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);

			model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
			model.addAttribute("entrpsNo", entrpsNo);

			return "mb/entrpsArrrgTrgterList";
		} catch (Exception e) {

			log.error(e.getMessage());
			return "error/503";
		}
	}

	@PostMapping("/searchEntrpsArrrgTrgterList")
	@ResponseBody
	public Map<String, Object> searchEntrpsArrrgTrgterList(@RequestBody ArrrgTrgterVO vo) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		List<ArrrgTrgterVO> dataList = arrrgTrgterService.searchArrrgTrgterList(vo);
		int totalDataCount = arrrgTrgterService.selectArrrgTrgterListTotCnt(vo);

		map.put("dataList", dataList);
		map.put("totalDataCount", totalDataCount);

		return map;
	}
}
