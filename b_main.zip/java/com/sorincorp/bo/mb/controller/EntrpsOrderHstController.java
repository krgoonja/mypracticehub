/**
 *
 */
package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.mb.model.EntrpsOrderHstVO;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.bo.mb.service.EntrpsOrderHstService;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * EntrpsOrderHstController.java
 * 
 * @version
 * @since 2021. 6. 28.
 * @author srec0009
 */
@Slf4j
@Controller
@RequestMapping("/bo/Member")
@ComponentScan({ "com.sorincorp.comm.*" })
public class EntrpsOrderHstController {

	@Autowired
	private EntrpsOrderHstService entrpsOrderHstService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	@Autowired
	private EntrpsMbService entrpsMbService;

	@Value("${lcTrace.server.viewer.host}")
	private String lcTraceHost;

	@Value("${lcTrace.server.viewer.port}")
	private String lcTracePort;

	/**
	 * <pre>
	 * 처리내용: 회원 주문 내역 조회 화면
	 * </pre>
	 * 
	 * @date 2021. 9. 6.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 6.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsOrderHst")
	public String selectEntrpsOrderHst(String entrpsNo, Model model) {
		try {
			List<MbCmnCodeVO> orderSttusCodeNm = mbCmnCodeService.selectCmnCodeList("ORDER_STTUS_CODE");
			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);

			model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
			model.addAttribute("entrpsNo", entrpsNo);
			model.addAttribute("orderSttusCodeNm", orderSttusCodeNm);
			model.addAttribute("lcTraceHost", lcTraceHost);
			model.addAttribute("lcTracePort", lcTracePort);

			return "mb/entrpsOrderHstList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 회원 주문 내역 조회
	 * </pre>
	 * 
	 * @date 2021. 9. 6.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 6.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsOrderHstVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsOrderHstList")
	@ResponseBody
	public Map<String, Object> selectEntrpsMbInfoList(@RequestBody EntrpsOrderHstVO entrpsOrderHstVO) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		List<EntrpsOrderHstVO> entprsOrderHstList = entrpsOrderHstService.selectEntrpsOrderHst(entrpsOrderHstVO);
		int totalDataCount = entrpsOrderHstService.selectEntrpsMbInfoListTotCnt(entrpsOrderHstVO);
		log.info("totalDataCount ::" + totalDataCount);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", entprsOrderHstList);
		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 주문 내역 상세 조회 (modal)
	 * </pre>
	 * 
	 * @date 2021. 9. 6.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 6.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsOrderHstVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectOrderDlvrgDtl")
	public String selectOrderDlvrgDtl(@RequestBody EntrpsOrderHstVO entrpsOrderHstVO, Model model) {
		try {
			EntrpsOrderHstVO detailVO = entrpsOrderHstService.selectOrderDlvrgDtl(entrpsOrderHstVO);

			if (detailVO != null) {
				detailVO.setLcTraceHost(lcTraceHost);
				detailVO.setLcTracePort(lcTracePort);
			} // end if()

			model.addAttribute("detailVO", detailVO);
			return "mb/entrpsOrderHstDlvrgDtl.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
}
