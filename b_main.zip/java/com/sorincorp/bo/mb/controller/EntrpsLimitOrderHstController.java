package com.sorincorp.bo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.mb.model.MbCmnCodeVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.bo.mb.service.MbCmnCodeService;
import com.sorincorp.bo.or.model.LimitsOrderManageVO;
import com.sorincorp.bo.or.service.LimitsOrderManageService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/Member")
public class EntrpsLimitOrderHstController {

	@Autowired
	private LimitsOrderManageService limitsOrderManageService;

	@Autowired
	private EntrpsMbService entrpsMbService;

	@RequestMapping("/selectEntrpsLimitOrderHst")
	public String selectEntrpsOrderLimitHst(Model model, String entrpsNo) {
		try {

			MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);

			model.addAttribute("entrpsNo", entrpsNo);
			model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);

			return "mb/entrpsLimitOrderHstList";

		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg",e);
			return "error/503";
		}
	}

	@RequestMapping("/selectEntrpsLimitOrderHstList")
	@ResponseBody
	public Map<String,Object> selectEntrpsOrderLimitHstList(@RequestBody LimitsOrderManageVO searchVO) throws Exception {
		Map<String,Object> map = new HashMap<String, Object>();

		List<LimitsOrderManageVO> dataList = limitsOrderManageService.selectLimitsOrderManageList(searchVO);
		int totalDataCount = limitsOrderManageService.selectLimitsOrderManageListTotCnt(searchVO);

		map.put("dataList", dataList);
		map.put("totalDataCount", totalDataCount);
		return map;
	}

	@PostMapping("/selectEntrpsLimitOrderHstListForExcel")
	@ResponseBody
	public Map<String, Object> searchLimitsOrderManageListForExcel(@RequestBody LimitsOrderManageVO searchVo) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();
		List<LimitsOrderManageVO> dataList = limitsOrderManageService.selectLimitsOrderManageList(searchVo);
		map.put("dataList", dataList);

		return map;
	}
}
