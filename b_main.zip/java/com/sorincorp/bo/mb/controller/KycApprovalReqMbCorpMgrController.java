package com.sorincorp.bo.mb.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.co.model.CmmnCodeVO;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.mb.model.KycApprovalReqMbCorpMgrVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.service.EntrpsMbService;
import com.sorincorp.bo.mb.service.KycApprovalReqMbCorpMgrService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/mb")
//@ComponentScan(basePackages = { "com.sorincorp.api.mb.service", "com.sorincorp.comm.util" })
public class KycApprovalReqMbCorpMgrController {

	@Autowired
	private EntrpsMbService entrpsMbService;
	@Autowired
	private KycApprovalReqMbCorpMgrService kycapprovalReqMbCorpMgrService;
	@Autowired
	private UserInfoUtil userInfoUtil;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	final String RESPONSE_CODE = "rspnsCode";
	final String RESPONSE_MESSAGE = "rspnsMssage";

	/**
	 * <pre>
	 * 처리내용: kycApprovalReqMbCorpList 화면을 보여준다.
	 * </pre>
	 * 
	 * @date 2022. 12. 09.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 09		hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param model
	 * @return String
	 * @throws Exception
	 */
	@RequestMapping("/selectKycApprovalReqMbCorpList")
	public String selectKycApprovalReqMbCorpList(ModelMap model) {

		try {
			List<CmmnCodeVO> kycCompnyStrctCodeList = kycapprovalReqMbCorpMgrService.selectKycCompnyStrctCode();
			List<CmmnCodeVO> kycRequstSttusCodeList = kycapprovalReqMbCorpMgrService.selectKycRequstSttusCode();

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			String oneWeek = DateUtil.addDays(today.replaceAll("-", ""), -7);
			String oneMonth = DateUtil.addMonths(today.replaceAll("-", ""), -1);
			String sixMonth = DateUtil.addMonths(today.replaceAll("-", ""), -6);
			String oneYear = DateUtil.addYears(today.replaceAll("-", ""), -1);
			String twoYear = DateUtil.addYears(today.replaceAll("-", ""), -2);

			model.addAttribute("today", today);
			model.addAttribute("oneWeek", oneWeek);
			model.addAttribute("oneMonth", oneMonth);
			model.addAttribute("sixMonth", sixMonth);
			model.addAttribute("oneYear", oneYear);
			model.addAttribute("twoYear", twoYear);
			model.addAttribute("kycCompnyStrctCodeList", kycCompnyStrctCodeList);
			model.addAttribute("kycRequstSttusCodeList", kycRequstSttusCodeList);
			return "mb/kycApprovalReqMbCorpList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: kyc 승인업체 리스트를 비동기 ajax로 조회한다.
	 * </pre>
	 * 
	 * @date 2022. 12. 14.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 14.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectKycApprovalReqMbCorpListAjax")
	@ResponseBody
	public Map<String, Object> selectKycApprovalReqMbCorpListAjax(@RequestBody KycApprovalReqMbCorpMgrVO kycapprovalReqMbCorpMgrVO) throws Exception {
		List<KycApprovalReqMbCorpMgrVO> kycApprovalReqMbCorpList = kycapprovalReqMbCorpMgrService.selectKycCorpInfoList(kycapprovalReqMbCorpMgrVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalDataCount", kycapprovalReqMbCorpMgrService.selectKycCorpInfoListCount(kycapprovalReqMbCorpMgrVO));
		map.put("dataList", kycApprovalReqMbCorpList);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: kyc 접수요청. 10 -> 11
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/updateRcept")
	@ResponseBody
	public ResponseEntity<Object> updateRcept(@RequestBody KycApprovalReqMbCorpMgrVO kycapprovalReqMbCorpMgrVO) throws Exception {
		boolean result = false;
		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}
		try {
			kycapprovalReqMbCorpMgrVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			result = kycapprovalReqMbCorpMgrService.updateRcept(kycapprovalReqMbCorpMgrVO);
		} catch (Exception e) {
			log.info("KycApprovalReqMbCorpMgrController updateKycRequstSttusCode ERROR :" + e.getMessage());
		}
		if (result == true) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else if (result == false) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: kycApprovalReqMbCorpDetail 화면을 보여준다.
	 * </pre>
	 * 
	 * @date 2022. 12. 09.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 09		hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param model
	 * @return String
	 * @throws Exception
	 */
	@RequestMapping("/selectkycApprovalReqMbCorpDetail")
	public String selectkycApprovalReqMbCorpDetail(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO, ModelMap model) {
		try {
			KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpDetail = kycapprovalReqMbCorpMgrService.selectKycCorpDetailInfoVo(kycApprovalReqMbCorpMgrVO);
			List<KycApprovalReqMbCorpMgrVO> kycAttachFileList = kycapprovalReqMbCorpMgrService.selectKycAttachFileList(kycApprovalReqMbCorpMgrVO);
			List<KycApprovalReqMbCorpMgrVO> kycMailSendngList = kycapprovalReqMbCorpMgrService.selectKycMailSendngList(kycApprovalReqMbCorpMgrVO);

			model.addAttribute("kycApprovalReqMbCorpDetail", kycApprovalReqMbCorpDetail);
			model.addAttribute("kycAttachFileList", kycAttachFileList);
			model.addAttribute("kycMailSendngList", kycMailSendngList);
			return "mb/kycApprovalReqMbCorpDetail";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: kycApprovalReqMbCorpDetail화면 - kycApprovalReqMbCorpDetail 재조회.
	 * </pre>
	 * 
	 * @date 2022. 12. 09.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 09		hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param model
	 * @return String
	 * @throws Exception
	 */
	@RequestMapping("/reSelectkycApprovalReqMbCorpReDetail")
	@ResponseBody
	public Map<String, Object> selectkycApprovalReqMbCorpReDetail(@RequestBody KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception {

		KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpReDetail = kycapprovalReqMbCorpMgrService.selectKycCorpDetailInfoVo(kycApprovalReqMbCorpMgrVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("kycApprovalReqMbCorpReDetail", kycApprovalReqMbCorpReDetail);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: kyc 접수 업체 정보 - 사업배경 update.
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/updateKycApprovalReqMbCorp")
	@ResponseBody
	public ResponseEntity<Object> updateKycApprovalReqMbCorp(@RequestBody KycApprovalReqMbCorpMgrVO kycapprovalReqMbCorpMgrVO, Model model, BindingResult bindingResult) throws Exception {
		boolean result = false;
		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}
		try {
			kycapprovalReqMbCorpMgrVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			result = kycapprovalReqMbCorpMgrService.updateKycApprovalReqMbCorp(kycapprovalReqMbCorpMgrVO);
		} catch (Exception e) {
			log.info("KycApprovalReqMbCorpMgrController updateKycApprovalReqMbCorp ERROR :" + e.getMessage());
		}
		if (result == true) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else if (result == false) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: kyc 접수 업체 정보 - 이사회명단, 주주명단 리스트를 비동기 ajax로 조회한다.
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectkycApprovalCptalInfoList")
	@ResponseBody
	public Map<String, Object> selectkycApprovalCptalInfoList(@RequestBody KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO, ModelMap model) throws Exception {

		List<KycApprovalReqMbCorpMgrVO> kycApprovalCptalInfoList = kycapprovalReqMbCorpMgrService.selectkycApprovalCptalInfoList(kycApprovalReqMbCorpMgrVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("totalDataCount", kycapprovalReqMbCorpMgrService.selectkycApprovalCptalInfoListCount(kycApprovalReqMbCorpMgrVO));
		map.put("dataList", kycApprovalCptalInfoList);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: kyc 접수 업체 정보 - 이사회 명단, 주주 명단 리스트 insert.
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertkycApprovalCptalInfoList")
	@ResponseBody
	public ResponseEntity<Object> insertkycApprovalCptalInfoList(@RequestBody KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception {
		boolean result = false;
		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		try {
			for (KycApprovalReqMbCorpMgrVO vo : kycApprovalReqMbCorpMgrVO.getInsertList()) {
				vo.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
				vo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
				result = kycapprovalReqMbCorpMgrService.insertkycApprovalCptalInfoList(vo);
			}
		} catch (Exception e) {
			log.info("KycApprovalReqMbCorpMgrController insertkycApprovalCptalInfoList ERROR :" + e.getMessage());
		}
		if (result == true) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else if (result == false) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: kyc 접수 업체 정보 - 이사회명단, 주주명단 리스트 delete
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/deleteKycApprovalCptalInfoList")
	@ResponseBody
	public ResponseEntity<Object> deleteKycApprovalCptalInfoList(@RequestBody KycApprovalReqMbCorpMgrVO kycapprovalReqMbCorpMgrVO) throws Exception {
		boolean result = false;
		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		try {
			for (KycApprovalReqMbCorpMgrVO vo : kycapprovalReqMbCorpMgrVO.getInsertList()) {
				vo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
				result = kycapprovalReqMbCorpMgrService.deleteKycApprovalCptalInfoList(vo);
			}
		} catch (Exception e) {
			log.info("KycApprovalReqMbCorpMgrController deleteKycApprovalCptalInfoList ERROR :" + e.getMessage());
		}
		if (result == true) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else if (result == false) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: kyc 접수 업체 정보 - 메일 수신자 입력 모달창
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 *          ------------------------------------------------------------------------- 변경일 작성자 변경내용 ------------------------------------------------------------------------- 2022. 12. 15. hyunjin05 최초작성 -------------------------------------------------------------------------
	 * @param kycapprovalReqMbCorpMgrVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectKycRecveList")
	public String selectKycRecveList(@RequestBody KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO, ModelMap model) {
		try {
			model.put("kycApprovalReqMbCorpMgrVO", kycApprovalReqMbCorpMgrVO);
			return "mb/kycRecveListPop.modal";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 영업관리팀 수신자에게 kyc업체 정보 메일 전송.
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/sendKycMail")
	@ResponseBody
	public ResponseEntity<Object> sendKycMail(@RequestBody KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception {
		boolean result = false;
		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		try {
			for (KycApprovalReqMbCorpMgrVO vo : kycApprovalReqMbCorpMgrVO.getInsertList()) {
				result = kycapprovalReqMbCorpMgrService.sendKycMail(vo);
			}
		} catch (Exception e) {
			log.info("KycApprovalReqMbCorpMgrController sendKycMail ERROR :" + e.getMessage());
		}
		if (result == true) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else if (result == false) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: KYC - 승인 보류(거절) setKycRequstSttusCode -> 13(희망금액 수집 단계에서 거절) / 20(kyc 접수 요청 후 거절)
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/resrveKycApprovalCptalInfo")
	@ResponseBody
	public ResponseEntity<Object> resrveKycApprovalCptalInfo(@RequestBody KycApprovalReqMbCorpMgrVO kycapprovalReqMbCorpMgrVO, Model model, BindingResult bindingResult) throws Exception {
		boolean result = false;
		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		try {
			kycapprovalReqMbCorpMgrVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			result = kycapprovalReqMbCorpMgrService.resrveKycApprovalCptalInfo(kycapprovalReqMbCorpMgrVO);
		} catch (Exception e) {
			log.info("KycApprovalReqMbCorpMgrController resrveKycApprovalCptalInfo ERROR :" + e.getMessage());
		}
		if (result == true) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else if (result == false) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: KYC - 승인 정상 -> 30
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/kycCreditConfirm")
	@ResponseBody
	public ResponseEntity<Object> kycCreditConfirm(@RequestBody KycApprovalReqMbCorpMgrVO kycapprovalReqMbCorpMgrVO, Model model, BindingResult bindingResult) throws Exception {
		boolean result = false;
		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		try {
			kycapprovalReqMbCorpMgrVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			result = kycapprovalReqMbCorpMgrService.kycCreditConfirm(kycapprovalReqMbCorpMgrVO);
		} catch (Exception e) {
			log.info("KycApprovalReqMbCorpMgrController resrveKycApprovalCptalInfo ERROR :" + e.getMessage());
		}
		if (result == true) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else if (result == false) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 기업회원 조회 - 기업회원 상세 조회 - kyc 승인업체 정보를 상세조회한다.
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpKycDetail")
	public String selectEntrpKycDetail(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO, ModelMap model, String entrpsNo) throws Exception {
		KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpDetail = kycapprovalReqMbCorpMgrService.selectKycCorpDetailInfoVo(kycApprovalReqMbCorpMgrVO);
		List<KycApprovalReqMbCorpMgrVO> kycAttachFileList = kycapprovalReqMbCorpMgrService.selectKycAttachFileList(kycApprovalReqMbCorpMgrVO);
		List<KycApprovalReqMbCorpMgrVO> kycMailSendngList = kycapprovalReqMbCorpMgrService.selectKycMailSendngList(kycApprovalReqMbCorpMgrVO);

		MbEntrpsMbVO totalSlepcEtcList = entrpsMbService.selectTotSlePc(entrpsNo);

		entrpsNo = kycApprovalReqMbCorpMgrVO.getEntrpsNo();
		model.addAttribute("totalSlepcEtcList", totalSlepcEtcList);
		model.addAttribute("entrpsNo", entrpsNo);
		model.addAttribute("kycApprovalReqMbCorpDetail", kycApprovalReqMbCorpDetail);
		model.addAttribute("kycAttachFileList", kycAttachFileList);
		model.addAttribute("kycMailSendngList", kycMailSendngList);
		return "mb/entrpsKycDetail";
	}

	/**
	 * <pre>
	 * 처리내용: KYC - 첨부파일 삭제
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/fileDeleteKycApprovalReqMbCorpr")
	@ResponseBody
	public Object fileDeleteKycApprovalReqMbCorpr(@RequestBody KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result = 1;
		String entrpsNo = kycApprovalReqMbCorpMgrVO.getEntrpsNo();
		String atchSn = kycApprovalReqMbCorpMgrVO.getAtchSn();
		int docNo = kycApprovalReqMbCorpMgrVO.getDocNo();

		result = kycapprovalReqMbCorpMgrService.deleteKycAttachFile(entrpsNo, docNo, kycApprovalReqMbCorpMgrVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return retVal;

	}
	
	/**
	 * <pre>
	 * 처리내용: 영업관리팀 메일 발송 리스트 조회
	 * </pre>
	 * 
	 * @date 2024. 01. 31.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 01. 31.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param model
	 * @return String
	 * @throws Exception
	 */
	@RequestMapping("/selectKycMailSendngList")
	@ResponseBody
	public Map<String, Object> selectKycMailSendngList(@RequestBody KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();
		List<KycApprovalReqMbCorpMgrVO> selectKycMailSendngList = new  ArrayList<KycApprovalReqMbCorpMgrVO>();
		
		try {
			selectKycMailSendngList = kycapprovalReqMbCorpMgrService.selectKycMailSendngList(kycApprovalReqMbCorpMgrVO);
			
			map.put("selectKycMailSendngList", selectKycMailSendngList);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return map;
	}

}
