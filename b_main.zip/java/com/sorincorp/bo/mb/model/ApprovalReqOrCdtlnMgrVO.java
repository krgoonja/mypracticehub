package com.sorincorp.bo.mb.model;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Validated
public class ApprovalReqOrCdtlnMgrVO extends CommonVO {
	/**
	 *
	 */
	private static final long serialVersionUID = -4121726956497134360L;

	/**
	 * 여신 계약 번호
	 */
	private String cdtlnCntrctNo;
	/**
	 * 보증 번호
	 */
	private String grntyNo;
	/**
	 * 여신 명
	 */
	private String cdtlnNm;
	/**
	 * 여신 금액
	 */
	private String cdtlnAmount;
	/**
	 * 여신 시작 일자
	 */
	private String cdtlnBeginDe;
	/**
	 * 여신 종료 일자
	 */
	private String cdtlnEndDe;
	/**
	 * 사용 여부
	 */
	private String useAt;
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
}