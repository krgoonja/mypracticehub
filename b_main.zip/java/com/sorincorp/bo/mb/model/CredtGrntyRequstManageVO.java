package com.sorincorp.bo.mb.model;

import java.io.Serializable;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class CredtGrntyRequstManageVO extends CommonVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -3738624094630201693L;

	private int seq;
	private String entrpsNo;
	private String entrpsNm;
	private String denlgTyCode;
	private String denlgTyCodeNm;
	private String bsnmRegistNo;
	private String rprsntvNm;
	private String mberNm;
	private String moblphonNo;
	private String elctrnFnncDelngStplatAgreAt;
	private String elctrnFnncDelngStplatAgreDt;
	private String mrtggProgrsSttusCode;
	private String sttusCodeNm;
	private String occrrncDt;
	private String reqstDt;
	private String mberConfmSttusCode;
	private String confmAt;
	private String mberConfmProcessDt;

	private String srhTxt;
	private String srhTxtGubun;
	private String srhDateGubun;
	private String startDate;
	private String endDate;
	private String excelYn;

}
