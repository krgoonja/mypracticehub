package com.sorincorp.bo.mb.model;

import java.util.ArrayList;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * MbEntrpsVO.java
 *
 * @version
 * @since 2021. 5. 24.
 * @author srec0030 (김영웅)
 */

@Data
@EqualsAndHashCode(callSuper = false)
@Validated
public class ApprovalReqMbCorpMgrVO extends CommonVO {
	/**
	 * MBER_ETR_DT
	 *
	 */
	private static final long serialVersionUID = -9049084153857557111L;

	/**
	 * WRTM_AUTHOR_RATE Search</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface Search {
	};

	/**
	 * InsertAndUpdate</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface InsertAndUpdate {
	};

	/**
	 * 업체 번호
	 */
	private String entrpsNo;
	/**
	 * 업체명 한글
	 */
	private String entrpsnmKorean;

	/**
     * 기업명 약어
     */
    private String entrpsnmKoreanShort;
	/**
	 * 업체명 영문
	 */
	private String entrpsnmEng;
	/**
	 * 대표자 명
	 */
	private String rprsntvNm;
	/**
	 * 사업자 등록 번호
	 */
	private String bsnmRegistNo;
	/**
	 * 법인 등록 번호
	 */
	private String cprRegistNo;
	/**
	 * 기업 업태 코드
	 */
	private String entrprsBizcndCode;
	/**
	 * 기업 종목 코드
	 */
	private String entrprsItemCode;
	/**
	 * 사업자 유형 코드
	 */
	private String bsnmTyCode;

	/**
	 * 사업자 유형 코드명
	 */
	private String bsnmTyCodeNm;
	/**
	 * 회사 전화 번호
	 */
	@Size(groups = InsertAndUpdate.class, max = 30, message = "회사전화번호는 최대30자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	private String cmpnyTlphonNo;
	/**
	 * 회사 팩스 번호
	 */
	@Size(groups = InsertAndUpdate.class, max = 30, message = "회사팩스번호는 최대30자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	private String cmpnyFaxNo;
	/**
	 * 우편 번호
	 */
	@Size(groups = InsertAndUpdate.class, max = 6, message = "우편번호는 최대6자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = InsertAndUpdate.class, message = "우편번호는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String postNo;
	/**
	 * 주소
	 */
	@Size(groups = InsertAndUpdate.class, max = 300, message = "주소는 최대300자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = InsertAndUpdate.class, message = "주소는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String adres;
	/**
	 * 상세 주소
	 */
	@Size(groups = InsertAndUpdate.class, max = 300, message = "상세주소는 최대300자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	private String detailAdres;
	/**
	 * 도로명 주소
	 */
	@Size(groups = InsertAndUpdate.class, max = 300, message = "도로명주소는 최대300자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = InsertAndUpdate.class, message = "도로명주소는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String rnAdres;
	/**
	 * 도로명 상세 주소
	 */
	@Size(groups = InsertAndUpdate.class, max = 300, message = "도로명상세주소는 최대300자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	private String rnDetailAdres;
	/**
	 * 환불 계좌 번호
	 */
	@Size(groups = InsertAndUpdate.class, max = 100, message = "환불 계좌번호는 최대100자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	private String refndAcnutNo;
	/**
	 * 이월렛 계좌 번호
	 */
	@Size(groups = InsertAndUpdate.class, max = 100, message = "이월렛 계좌번호는 최대100자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	private String ewalletAcnutNo;
	/**
	 * 환불 계좌 상태 코드
	 */
	private String refndAcnutSttusCode;
	/**
	 * 환불 계좌 정합성 여부
	 */
	private String refndAcnutRgrsynthAt;
	/**
	 * 환불 계좌 정합성 일시
	 */
	private String refndAcnutRgrsynthDt;
	/**
	 * 고객 등록 주체 코드
	 */
	private String cstmrRegistMbyCode;
	/**
	 * 업체 등급 번호
	 */
	@Size(groups = InsertAndUpdate.class, max = 20, message = "업체등급번호는 최대20자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	private String entrpsGradNo;
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;
	/**
	 * 기업 업종 구분 코드
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "업종구분은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String entrprsIndutySeCode;
	/**
	 * 최대 주문 중량
	 */
	@NotNull(groups = InsertAndUpdate.class, message = "최대주문중량은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private int mxmmOrderWt;

	/**
	 * 회사 상태 코드
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "기업인증은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String cmpnySttusCode;
	/**
	 * 회사 상태 설명
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "기업인증은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String cmpnySttusDc;
	/**
	 * 인증 만료 일자
	 */
	private String crtfcEndDe;

//	/**
//	 * 기업 신용 코드
//	 */
//	private String entrprsCredtCode;
//	/**
//	 * 기업 신용 이름
//	 */
//	private String entrprsCredtNm;
//	/**
//	 * 기업 신용 순위
//	 */
//	private String entrprsCredtRank;
//	/**
//	 * 기업 신용 등급
//	 */
//	private String entrprsCredtGrad;
//	/**
//	 * 기업 신용 등급 설명
//	 */
//	private String entrprsCredtGradDc;
	/**
	 * 회원 번호
	 */
	private String mberNo;
	/**
	 * 회원 아이디
	 */
	private String mberId;
	/**
	 * 회원 비밀 번호
	 */
	private String mberSecretNo;
	/**
	 * 회원 가입 일시
	 */
	private String mberEtrDt;
	/**
	 * 승인요청일시
	 */
	private String requstDt;
	/**
	 * 회원 최근 방문 일시
	 */
	private String mberRecentVisitDt;
	/**
	 * 회원 승인 상태 코드
	 */
	@Size(groups = InsertAndUpdate.class, min = 2, max = 2, message = "회원승신 상태코드가 유효하지 않습니다.") // /message/validation.properties 에 등록된 메시지
	private String mberConfmSttusCode;
	/**
	 * 회원 승인 상태 코드명
	 */
	private String mberConfmSttusCodeNm;
	/**
	 * 회원 승인 처리 일시
	 */
	private String mberConfmProcessDt;
	/**
	 * 승인자 명
	 */
	private String confmerNm;
	/**
	 * 요청 사유
	 */
	private String requstResn;
	/**
	 * 승인 사유
	 */
	private String confmResn;
	/**
	 * 회원 이름
	 */
	private String mberNm;
	/**
	 * 휴대전화 번호
	 */
	private String moblphonNo;
	/**
	 * 회원 이메일
	 */
	private String mberEmail;
	/**
	 * 회원 메일 수신 동의 여부
	 */
	private String mberEmailRecptnAgreAt;
	/**
	 * 회원 메일 수신 일시
	 */
	private String mberEmailRecptnAgreDt;
	/**
	 * 회원 문자 수신 동의 여부
	 */
	private String mberChrctrRecptnAgreAt;
	/**
	 * 회원 문자 수신 동의 일시
	 */
	private String mberChrctrRecptnAgreDt;
	/**
	 * 뉴스레터 신청 여부
	 */
	private String nsltReqstAt;
	/**
	 * 뉴스레터 신청 일시
	 */
	private String nsltReqstDt;
	/**
	 * 본인 인증 여부
	 */
	private String selfCrtfcAt;
	/**
	 * 본인 인증 일시
	 */
	private String selfCrtfcDt;
	/**
	 * 로그인 실패 회수
	 */
	private int loginFailrRtrvl;
	/**
	 * 비밀 번호 오류 횟수
	 */
	private int secretNoErrorCo;
	/**
	 * 비밀 번호 수정 일시
	 */
	private String secretNoUpdtDt;
	/**
	 * 최근 접속 일시
	 */
	private String recentConectDt;
	/**
	 * 회원 상태 코드
	 */
	private String mberSttusCode;
	/**
	 * 회원 상태 코드명
	 */
	private String mberSttusCodeNm;
	/**
	 * 회원 구분 코드
	 */
	private String mberSeCode;
	/**
	 * 권한 변경 동의 여부
	 */
	private String authorChangeAgreAt;

	/**
	 * 배송지 번호
	 */
	private String dlvrgNo;
	/**
	 * 배송지 구분 상세 순번
	 */
	private long dlvrgSeDetailSn;
	/**
	 * 기본 배송지 여부
	 */
	private String bassDlvrgAt;
	/**
	 * 배송지 명
	 */
	private String dlvrgNm;
	/**
	 * 우편 번호
	 */
	private String dlvPostNo;
	/**
	 * 주소
	 */
	private String dlvAdres;
	/**
	 * 상세 주소
	 */
	private String dlvDetailAdres;
	/**
	 * 도로명 주소
	 */
	private String dlvRnAdres;
	/**
	 * 도로명 상세 주소
	 */
	private String dlvRnDetailAdres;

	/**
	 * 도로명 주소+도로명 상세주소
	 */
	private String dlvRnAdresDetailAdres;
	/**
	 * 좌표 위도
	 */
	private String crdntLa;
	/**
	 * 좌표 경도
	 */
	private String crdntLo;
	/**
	 * 법정동 코드
	 */
	private String legaldongCode;
	/**
	 * 배송지 담당자
	 */
	private String dlvrgCharger;
	/**
	 * 배송지 담당자 연락처
	 */
	private String dlvrgChargerCttpc;

	/**
	 * 배송지구분
	 */
	private String dlvrgSe;
	/**
	 * 배송지 구분 명
	 */
	private String dlvrgSeNm;

	/**
	 * 업체 등급 레벨
	 */
	private int entrpsGradLevel;
	/**
	 * 업체 등급 명
	 */
	private String entrpsGradNm;
	/**
	 * 등급 평가 기준 예외 여부
	 */
	private String gradEvlStdrExcpAt;
	/**
	 * 이월렛 체크 여부
	 */
	private String ewalletCeckAt;
	/**
	 * PG 체크 여부
	 */
	private String pgCeckAt;

	/**
	 * 라이브 고정가 체크 여부
	 */
	private String liveHghnetprcCeckAt;

	/**
	 * 구매 금액 한도
	 */
	private long purchsAmountLmt;
	/**
	 * 구매 중량 한도
	 */
	private java.math.BigDecimal purchsWtLmt;
	/**
	 * 1회 구매 중량
	 */
	private java.math.BigDecimal oncePurchsWt;
	/**
	 * 전문가용 메일링 서비스 여부
	 */
	private String spcltyusefulEmailringSvcAt;
	/**
	 * 재고 표시 여부
	 */
	private String invntryIndictAt;
	/**
	 * 최대 보관 기간
	 */
	private int mxmmCstdyPd;
	/**
	 * 선납 결제 비율
	 */
	private java.math.BigDecimal prepaySetleRate;
	/**
	 * 선납 출고 비율
	 */
	private java.math.BigDecimal prepayDlivyRate;

	private String scrinId;
	private String srhTxt;
	private String srhGubun;
	private String excelYn;

	/****** JAVA VO CREATE : MB_ENTRPS_ATCH_FILE_RLS(회원_업체 첨부 파일 관계) ******/
	/**
	 * 문서 번호
	 */
	private int docNo;
	/**
	 * 업무 구분 코드
	 */
	private String jobSeCode;
	/**
	 * 문서 제목
	 */
	private String docSj;
	/**
	 * 파일 실제경로
	 */
	private String docFileRealCours;

	/**** api response *****/
	/**
	 * erp 코드
	 */
	private String erpEntrpsCode;

	/**
	 * tCode
	 */
	private String tCode;

	private String teCode;
	/**
	 * 인터페이스 구분
	 */
	private String intrfcSe;

	/**
	 * 배송지 주소1
	 */
	private String dlvrgAddr1;
	/**
	 * 최초 변경자 아이디
	 */
	private String frstChangerId;
	/**
	 * 최초 변경 일시
	 */
	private String frstChangeDt;
	/**
	 * 담당자 아이디
	 */
	private String chargerId;
	/**
	 * 비밀번호
	 */
	private String secretNo;
	/**
	 * 담당자 이름
	 */
	private String chargerNm;
	/**
	 * 구매담당자 이메일주소
	 */
	private String purchschargerEmail;
	/**
	 * 승인 상태 코드
	 */
	private String confmProcessSe;

	/**
	 * 문서파일명
	 */
	private int docFileMg;

	/**
	 * 이월렛 인터페이스 순번
	 */
	private int intrfcSn;

	/**
	 * 이월렛 인터페이스 구분
	 */
	private String delngSe;

	/**
	 * 이월렛 에러메세지
	 */
	private String ewalletErrorMsg;

	/**
	 * 순번
	 */
	private int seq;

	/**
	 * 계좌 발급자
	 */
	private String acnutIssuer;

	/**
	 * 계좌 해지자
	 */
	private String acnutRscpsn;

	/**
	 * 계좌해지사유
	 */
	private String acnutTrmnatResn;

	/**
	 * 업체 퍼포먼스등급
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "기업등급은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@Size(groups = InsertAndUpdate.class, max = 2, message = "기업등급은 최대2자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	private String entrpsGrad;
	/**
	 * 업체 평가등급
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "평가등급은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@Size(groups = InsertAndUpdate.class, max = 2, message = "평가등급은 최대2자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	private String entrpsEvlGrad;
	/**
	 * 신용등급
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "기업신용등급은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@Size(groups = InsertAndUpdate.class, max = 5, message = "기업신용등급은 최대5자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	private String credtGrad;
	/**
	 * 구매성향등급
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "투자성향은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@Size(groups = InsertAndUpdate.class, max = 2, message = "투자성향은 최대2자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	private String entrpsPurchsInclnGrad;
	/**
	 * 업체평가등급명
	 */
	private String entrpsEvlGradNm;
	/**
	 * 등급 평가일
	 */
	private String gradEvlDt;
	/**
	 * 크레팝 시작 신용등급
	 */
	private String beginCredtGrad;
	/**
	 * 크레팝 시작 종료등급
	 */
	private String endCredtGrad;
	/**
	 * 여신구간
	 */
	private int cdtlnSctn;
	/**
	 * 전자상거래보증 허용 상환기간
	 */
	private int mrtggGrntyPermRepyPd;
	/**
	 * 평가등급 변경일시
	 */
	private String evlGradChangeDt;
	/**
	 * 변경요청 상세코드
	 */
	private String changeConfmDetailCode;
	/**
	 * 변경승인요청사유
	 */
	private String changeRequstResn;
	/**
	 * 변경요청 상세코드명
	 */
	private String changeConfmDetailCodeNm;
	/**
	 * 날짜검색 구분
	 */
	private String dateGubun;
	/**
	 * 날짜검색 시작일
	 */
	private String startDate;
	/**
	 * 날짜검색 종료일
	 */
	private String endDate;

	/**
	 * 메탈코드
	 */
	private String metalCode;
	/**
	 * 메탈코드명
	 */
	private String metalCodeNm;
	/**
	 * 고정가 여부
	 */
	private String fixingPcAt;
	/**
	 * 라이브가 여부
	 */
	private String livePcAt;
	/**
	 * 지정가 여부
	 */
	private String appnPcAt;
	/**
	 * 평균가 여부
	 */
	private String avrgPcAt;
	/**
	 * 고객여부
	 */
	private String cstmrAt;
	/**
	 * 벤더여부
	 */
	private String vendorAt;

	/**
	 * 메탈권한리스트
	 */
	private ArrayList<ApprovalReqMbCorpMgrVO> metalAuthList;

	/**
	 * 증거금 신청여부
	 */
	private String wrtmReqstAt;
	/**
	 * 전자상거래보증 신청여부
	 */
	private String mrtggGrntyReqstAt;
	/**
	 * 대출보증 신청여부
	 */
	private String lonGrntyReqstAt;
	/**
	 * 증거금 사용여부
	 */
	private String wrtmUseAt;
	/**
	 * 전자상거래보증 사용여부
	 */
	private String mrtggGrntyUseAt;
	/**
	 * 대출보증 사용여부
	 */
	private String lonGrntyUseAt;

	/**
	 * 증거금 신청일시
	 */
	private String wrtmReqstDt;
	/**
	 * 증거금 해지일시
	 */
	private String wrtmTrmnatDt;
	/**
	 * 증거금 비율
	 */
	private double wrtmAuthorRate;

	/**
	 * 담보 보증 해지 일시
	 */
	private String mrtggGrntyTrmnatDt;
	/**
	 * 담보 보증 신청 일시
	 */
	private String mrtggGrntyReqstDt;
	/**
	 * 담보 보증 보험 요율
	 */
	private double mrtggGrntyInsrncTariff;
	/**
	 * 담보 보증 계약 여부
	 */
	private String mrtggGrntyCntrctAt;
	private String mrtggGrntyCntrctAtNm;
	/**
	 * 담보 보증 수수료 부담 주체 여부
	 */
	private String mrtggGrntyFeeBndMbyAt;
	/**
	 * 담보 보증 보험료
	 */
	private long mrtggGrntyIrncf;
	/**
	 * 담보 보증 보험료 지원 기준 금액
	 */
	private long mrtggGrntyIrncfSportStdrAmount;
	/**
	 * 담보 보증 확인 보험료
	 */
	private long mrtggGrntyCnfirmIrncf;

	/**
	 * 담보 보증번호
	 */
	private String grntyNo;

	/**
	 * 보증 기한 시작 일자
	 */
	private String grntyTmlmtBeginDe;
	/**
	 * 보증 기한 종료 일자
	 */
	private String grntyTmlmtEndDe;
	/**
	 * 보증 기한 기간
	 */
	private String grntyTmlmt;
	/**
	 * 보증금액
	 */
	private long grntyAmount;
	/**
	 * 보증남은 한도금액
	 */
	private long mrtggBlce;

	/**
	 * 지원비율
	 */
	private double sportRate;

	/**
	 * 전자상거래보증 계약 진행 상태코드
	 */
	private String mrtggProgrsSttusCode;
	/**
	 * 전자상거래보증 계약 진행 상태코드명
	 */
	private String mrtggProgrsSttusCodeNm;

	/**
	 * 대출 보증 수수료 부담 주체 여부
	 */
	private String lonGrntyFeeBndMbyAt;

	/**
	 * 보증만료여부
	 */
	private String endAt;

	/**
	 * 업체 전자상거래보증 계약순번
	 */
	private int entrpsMrtggCntrctSn;

	/**
	 * 전자상거래보증 마일리지 누적 회전율
	 */
	private int mlgAccmltTrnov;

	/**
	 * 은행코드
	 */
	private String bankCode;
	/**
	 * 은행코드명
	 */
	private String bankCodeNm;
	/**
	 * 업체은행 순번
	 */
	private int entrpsBankSn;
	/**
	 * 은행 사용여부
	 */
	private String useAt;
	/**
	 * 구매자금 사용신청일시
	 */
	private String lonGrntyUseReqstDt;
	/**
	 * 구매자금 해지일시
	 */
	private String lonGrntyUseTrmnatDt;
	/**
	 * 구매자금 신청일시
	 */
	private String lonGrntyReqstDt;
	/**
	 * 구매자금 해지일시
	 */
	private String lonGrntyTrmnatDt;

	/**
	 * 증거금 해지 신쳥여부
	 */
	private String wrtmTrmnatAt;
	/**
	 * 전자상거래보증 해지 신쳥여부
	 */
	private String mrtggGrntyTrmnatAt;
	/**
	 * 대출보증 해지 신쳥여부
	 */
	private String lonGrntyTrmnatAt;

	private ArrayList<ApprovalReqMbCorpMgrVO> bankUseAtList;

	/**
	 * 증거금 사용신청 승인여부
	 */
	private String wrtmConfmAt;
	/**
	 * 전자상거래보증 사용신청 승인여부
	 */
	private String mrtggGrntyConfmAt;
	/**
	 * 구매자금 사용신청 승인여부
	 */
	private String lonGrntyConfmAt;

	// SLE_METAL_LIST 운영반영전에 삭제해야함
	/**
	 * 판매 금속 비트 코드
	 */
	private String sleMetalList;
	/**
	 * 판매 금속 비트 코드
	 */
	private String sleMetal01;
	/**
	 * 판매 금속 비트 코드
	 */
	private String sleMetal02;
	/**
	 * 판매 금속 비트 코드
	 */
	private String sleMetal03;
	/**
	 * 판매 금속 비트 코드
	 */
	private String sleMetal04;
	/**
	 * 판매 금속 비트 코드
	 */
	private String sleMetal05;
	/**
	 * 판매 금속 비트 코드
	 */
	private String sleMetal06;

	// 케이지 크레딧
	/**
	 * 여신 서비스 구분 코드
	 */
	private String cdtlnSvcSeCode;
	/**
	 * 케이지트레이딩 희망 한도 금액
	 */
	private long sorinHopeLmtAmount;
	/**
	 * 가능 한도액
	 */
	private long possLmt;
	/**
	 * 담보 진행 상태 코드
	 */
	private String grntyProgrsSttusCode;
	/**
	 * 담보 조건 변경 상세 코드
	 */
	private String mrtggCndChangeDetailCode;
	/**
	 * 부보 금액
	 */
	private long insurgAmount;
	/**
	 * 여신 계약 번호
	 */
	private String cdtlnCntrctNo;
	/**
	 * 일일 여신 구매 중량 한도
	 */
	private int dailCdtlnPurchsWtLmt;
	/**
	 * KYC 요청 상태 코드
	 */
	private String kycRequstSttusCode;

    /**
     * 추천인 아이디
     */
    private String recomendrId;

    /**
     * 회원 승인 진행 단계
     */
    private String confmSttusStep;
    private String confmSttusStepNm;

    /** 평균가 LIVE 구매 등급 코드 */
    private String avrgpcLivePurchsGradCode;
    /** 평균가 LIVE 구매 등급 코드명 */
    private String avrgpcLivePurchsGradCodeNm;
    /** 평균가 LIVE 구매 비율 */
    private int avrgpcPurchsRate;
    /** 평균가 세금계산서 발행시점 코드 */
    private String avrgpcTaxBillIsuPnttmCode;
    /** 부분 출고 상환 여부 */
    private String partDlivyRepyAt;
    /**
     * 잠정 단가 구매 설정 여부
    */
    private String prvsnlUntpcPurchsSetupAt;
    /**
     * 단가 분리 확정 여부
    */
    private String untpcSepratDcsnAt;
    /**
     * 단가 확정 최대 기간 코드
    */
    private String untpcDcsnMxmmPdCode;
    /**
     * 가격 변동 금액 비율 코드
    */
    private String pcChangeAmountRateCode;
    /**
     * 잠정 단가 출고 최대 수량
    */
    private Integer prvsnlUntpcDlivyMxmmQy;
    /**
     * 단가 미확정 중량
     */
    private Integer pcUnDcsnWt;

    // 할인 내역 MB_ENTRPS_MNBY_PURCHS_BNEF_BAS
    /**
     * 당월 상시 할인
     */
    private String entrpsMnbyPurchsBnef;
    
    /**
     * 당월 페이백
     */
    private String entrpsPayBackDscnt;
    
}
