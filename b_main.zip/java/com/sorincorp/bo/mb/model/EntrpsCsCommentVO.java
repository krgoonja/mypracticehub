/**
 *
 */
package com.sorincorp.bo.mb.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * EntrpsCsCommentVO.java
 *
 * @version
 * @since 2022. 2. 25.
 * @author hyunjin05
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class EntrpsCsCommentVO extends CommonVO {
	/**
	 * serial
	 */
	private static final long serialVersionUID = 1L;
	/**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 업체명 한글
    */
    private String entrpsnmKorean;
	/**
     * 고객 특이 사항
    */
    private String cstmrPartclrMatter;
    /**
     * 고객 특이 사항 최종 변경자 아이디
    */
    private String cstmrPartclrMatterlastChangerId;
    /**
     * 고객 특이 사항 최종 변경 일시
    */
    private String cstmrPartclrMatterlastChangeDt;

}
