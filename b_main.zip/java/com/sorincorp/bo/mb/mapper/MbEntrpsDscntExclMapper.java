package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.MbEntrpsDscntExclVO;

/**
 * MbEntrpsDscntExclMapper.java
 * 
 * @version
 * @since 2024. 5. 29.
 * @author huynjin0512
 */
public interface MbEntrpsDscntExclMapper {

	/**
	 * <pre>
	 * 처리내용: 할인 제외 업체 리스트 조회
	 * 처리내용: 할인 제외 업체 리스트 개수 조회
	 * </pre>
	 * @date 2024. 5. 29.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 29.				hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param MbEntrpsDscntExclVO
	 * @return
	 * @throws Exception
	 */
	List<MbEntrpsDscntExclVO> getMbEntrpsDscntExclList(MbEntrpsDscntExclVO mbEntrpsDscntExclVO) throws Exception;
	Integer getMbEntrpsDscntExclListCnt(MbEntrpsDscntExclVO mbEntrpsDscntExclVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 기업 회원 리스트 조회
	 * 처리내용: 기업 회원 리스트 개수 조회
	 * </pre>
	 * @date 2024. 5. 29.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 29.				hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param MbEntrpsDscntExclVO
	 * @return
	 * @throws Exception
	 */
	List<MbEntrpsDscntExclVO> getEntrpsMbList(MbEntrpsDscntExclVO mbEntrpsDscntExclVO) throws Exception;
	Integer getEntrpsMbListCnt(MbEntrpsDscntExclVO mbEntrpsDscntExclVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 할인 제외 업체 추가
	 * 처리내용: 할인 제외 업체 수정
	 * </pre>
	 * @date 2024. 5. 29.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 29.				hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param MbEntrpsDscntExclVO
	 * @return
	 * @throws Exception
	 */
	Integer insertUpdateEntrpsDscnt(MbEntrpsDscntExclVO mbEntrpsDscntExclVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 할인 제외 업체 조회
	 * </pre>
	 * @date 2024. 6. 05.
	 * @author huynjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 6. 05.				hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param MbEntrpsDscntExclVO
	 * @return
	 * @throws Exception
	 */
	public List<MbEntrpsDscntExclVO> getMbEntrpsDscntExclVOList(MbEntrpsDscntExclVO mbEntrpsDscntExclVO) throws Exception;
}
