package com.sorincorp.bo.mb.mapper;

import com.sorincorp.bo.mb.model.EntrpsCsCommentVO;

/**
 * CorpInfoMapper.java
 *
 * @version
 * @since 2022. 2. 27.
 * @author hyunjin05 (이현진)
 */
public interface EntrpsCsCommentMapper {

	
	/**
	 * <pre>
	 * 처리내용: 기업회원 > CS코멘트 조회
	 * </pre>
	 * @date 2022. 2. 27.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 28.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param entrpsCsCommentVO
	 * @return
	 */
	EntrpsCsCommentVO selectEntrpsCsComment(String entrpsNo);
	
	/**
	 * <pre>
	 * 처리내용: 기업회원 > CS코멘트 수정
	 * </pre>
	 * @date 2022. 2. 28.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 28.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param entrpsCsCommentVO
	 * @return
	 */
	int updateEntrpsCsComment(EntrpsCsCommentVO entrpsCsCommentVO);
	
	/**
	 * <pre>
	 * 처리내용: 기업회원 > CS코멘트 수정 이력 insert
	 * </pre>
	 * @date 2022. 2. 28.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 28.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param entrpsCsCommentVO
	 */
	void insertEntrpsCsCommentHst(EntrpsCsCommentVO entrpsCsCommentVO);
	
}
