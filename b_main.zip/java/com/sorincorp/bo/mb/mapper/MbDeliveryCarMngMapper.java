package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.MbDeliveryCarMngVO;

public interface MbDeliveryCarMngMapper {

	List<MbDeliveryCarMngVO> selectMbVhcleInfoList(MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception;

	int selectMbVhcleInfoListCnt(MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception;

	List<MbDeliveryCarMngVO> selectMbDrvArticlInfoList(MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception;

	int selectMbDrvArticlInfoListCnt(MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception;

	MbDeliveryCarMngVO selectMbVhcleInfo(MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception;

	MbDeliveryCarMngVO selectMbDrvArticlInfo(MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception;

	int deleteMbVhcleInfoList(MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception;

	int deleteMbDrvArticlInfoList(MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception;

	int insertMbVhcleInfoHst(MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception;

	int insertMbDrvArticlInfoHst(MbDeliveryCarMngVO mbDeliveryCarMngVO) throws Exception;

}
