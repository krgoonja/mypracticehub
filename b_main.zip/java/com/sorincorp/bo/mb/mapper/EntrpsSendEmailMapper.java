/**
 *
 */
package com.sorincorp.bo.mb.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.mb.model.EntrpsSendEmailVO;
import com.sorincorp.bo.mb.model.EntrpsSendMsgVO;
import com.sorincorp.bo.sample.model.SampleVO;

/**
 * EntrpsSendEmailMapper.java
 * @version
 * @since 2021. 7. 1.
 * @author srec0009
 */
public interface EntrpsSendEmailMapper {

	/**
	 * <pre>
	 * 처리내용: 기업회원조회 > 메일발송 조회 페이징
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsSendEmailVO
	 * @return
	 */
	int selectEntrpsSendEmailListToCnt(Map<String, Object> param);
	/**
	 * <pre>
	 * 처리내용: 기업회원조회 > 메일발송 조회
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsSendEmailVO
	 * @return
	 */
	List<EntrpsSendEmailVO> selectEntrpsSendEmailList(Map<String, Object> param);

	/**
	 * <pre>
	 * 처리내용: 기업회원조회 > 메일발송 상세 조회
	 * </pre>
	 * @date 2021. 7. 1.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 1.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsSendEmailVO
	 * @return
	 */
	EntrpsSendEmailVO selectEntrpsSendEmailDtl(EntrpsSendEmailVO entrpsSendEmailVO);
	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 26.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 26.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param string
	 * @return
	 */
	int selectTableExistCnt(String tableName);

}
