package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.MbMrtggGrntyVO;

public interface MbMrtggGrntyMapper {

	List<MbMrtggGrntyVO> selectMbMrtggGrntyList(MbMrtggGrntyVO mbMrtggGrntyVO) throws Exception;

	List<MbMrtggGrntyVO> selectMbMrtggGrntyNoList(String entrpsNo, String cdtlnSvcSeCode) throws Exception;

	int selectMbMrtggGrntyTotalCnt(MbMrtggGrntyVO mbMrtggGrntyVO) throws Exception;

	MbMrtggGrntyVO selectMbEntrpsMrtggBasInfo(MbMrtggGrntyVO mbMrtggGrntyVO) throws Exception;

	List<MbMrtggGrntyVO> selectMbEntrpsMrtggGrntyList(MbMrtggGrntyVO mbMrtggGrntyVO) throws Exception;

	int selectMbEntrpsMrtggGrntyTotalCnt(MbMrtggGrntyVO mbMrtggGrntyVO) throws Exception;

}
