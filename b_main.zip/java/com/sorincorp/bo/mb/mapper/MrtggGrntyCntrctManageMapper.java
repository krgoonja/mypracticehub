package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.EntrpsMbInfoVO;
import com.sorincorp.bo.mb.model.MrtggGrntyCntrctManageVO;

public interface MrtggGrntyCntrctManageMapper {

	List<MrtggGrntyCntrctManageVO> selectCredtGrntyRequstManageList(MrtggGrntyCntrctManageVO mrtggGrntyCntrctManageVO) throws Exception;

	int selectCredtGrntyRequstManageTotCnt(MrtggGrntyCntrctManageVO mrtggGrntyCntrctManageVO) throws Exception;

	List<MrtggGrntyCntrctManageVO> selectMbEntrpsMrtggLmtDtlList(MrtggGrntyCntrctManageVO mrtggGrntyCntrctManageVO) throws Exception;

	int selectMbEntrpsMrtggLmtDtlTotCnt(MrtggGrntyCntrctManageVO mrtggGrntyCntrctManageVO) throws Exception;

	List<MrtggGrntyCntrctManageVO> selectMrtggGrntyCntrctManageOrderList(MrtggGrntyCntrctManageVO mrtggGrntyCntrctManageVO) throws Exception;

	List<MrtggGrntyCntrctManageVO> selectEntrprsInfoInqire(MrtggGrntyCntrctManageVO mrtggGrntyCntrctManageVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이메일 템플릿 목록을 조회한다.
	 * </pre>
	 * @date 2022. 7. 14.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<MrtggGrntyCntrctManageVO> selectEmailTmplatList(MrtggGrntyCntrctManageVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기업 회원 조회
	 * </pre>
	 * @date 2023. 12. 26.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 12. 26.		hamyoonsic				최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	List<MrtggGrntyCntrctManageVO> selectEntrpsMbInfoList(MrtggGrntyCntrctManageVO vo);

}
