package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.MbEvlGradMngVO;

public interface MbEvlGradMngMapper {

	List<MbEvlGradMngVO> selectMbEvlGradMngList() throws Exception;

	String selectMbEvlGradManageBasChgYn(MbEvlGradMngVO mbEvlGradMngVO) throws Exception;

	int updateMbEntrpsEvlGradManageBas(MbEvlGradMngVO mbEvlGradMngVO) throws Exception;

	int insertMbEntrpsEvlGradManageBasHst(MbEvlGradMngVO mbEvlGradMngVO) throws Exception;

	MbEvlGradMngVO selectMbEvlGradMngInfo() throws Exception;

	List<MbEvlGradMngVO> selectMbEvlGradMngChgHistList(MbEvlGradMngVO mbEvlGradMngVO) throws Exception;

	int selectMbEvlGradMngChgHistListTotCnt(MbEvlGradMngVO mbEvlGradMngVO) throws Exception;

	List<MbEvlGradMngVO> selectMbEvlGradMngHstDetailList(MbEvlGradMngVO mbEvlGradMngVO) throws Exception;

}
