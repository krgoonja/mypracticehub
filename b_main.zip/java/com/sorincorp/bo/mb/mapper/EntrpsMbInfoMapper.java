/**
 *
 */
package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.EntrpsMbInfoVO;

/**
 * EntrpsMbInfoMapper.java
 * @version
 * @since 2021. 6. 11.
 * @author srec0009
 */
public interface EntrpsMbInfoMapper {
	/**
	 * <pre>
	 * 처리내용: 기업 회원 화면 조회 페이징
	 * </pre>
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 28.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsMbInfoVO
	 * @return
	 */
	int selectEntrpsMbInfoListTotCnt(EntrpsMbInfoVO entrpsMbInfoVO);

	/**
	 * <pre>
	 * 처리내용: 기업 회원 화면 조회
	 * </pre>
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 28.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsMbInfoVO
	 * @return
	 */
	List<EntrpsMbInfoVO> selectEntrpsMbInfoList(EntrpsMbInfoVO entrpsMbInfoVO);

	/**
	 * <pre>
	 * 처리내용: 기업 회원 삭제
	 * </pre>
	 * @date 2021. 6. 11.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 11.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsMbInfoVO
	 * @return
	 */
	int deleteEntrpsMbInfoList(EntrpsMbInfoVO entrpsMbInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기업 회원 로그인 이력 조회
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 15.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsMbInfoVO
	 * @return
	 */
	List<EntrpsMbInfoVO> selectMbLoginHstList(EntrpsMbInfoVO entrpsMbInfoVO);

	/**
	 * <pre>
	 * 처리내용: 기업 회원 로그인 이력 조회 페이징
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 15.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsMbInfoVO
	 * @return
	 */
	int selectMbLoginHstListTotCnt(EntrpsMbInfoVO entrpsMbInfoVO);

	/**
	 * <pre>
	 * 처리내용: 회원 정보 입력
	 * </pre>
	 * @date 2021. 6. 16.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 16.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsMbInfoVO
	 */
	int insertMbInfo(EntrpsMbInfoVO entrpsMbInfoVO);

	/**
	 * <pre>
	 * 처리내용: 아이디 중복 검사
	 * </pre>
	 * @date 2021. 6. 16.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 16.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberId
	 * @return
	 */
	int selectMberId(String mberId);

	/**
	 * <pre>
	 * 처리내용: 회원 정보 상세 조회
	 * </pre>
	 * @date 2021. 6. 18.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 18.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @return
	 */
	EntrpsMbInfoVO selectMbInfoDtlModal(String mberNo);

	/**
	 * <pre>
	 * 처리내용: 계정 잠금 해제
	 * </pre>
	 * @date 2021. 6. 18.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 18.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsMbInfoVO
	 * @return
	 */
	int updateMberLockSttus(EntrpsMbInfoVO entrpsMbInfoVO);

	/**
	 * <pre>
	 * 처리내용: 회원 정보 수정 (모달)
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 21.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsMbInfoVO
	 * @return
	 */
	int updateMbInfoDtlModal(EntrpsMbInfoVO entrpsMbInfoVO);

	/**
	 * <pre>
	 * 처리내용: 회원 삭제(모달)
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 21.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsMbInfoVO
	 * @return
	 */
	int deleteMbInfoDtlModal(EntrpsMbInfoVO entrpsMbInfoVO);

	/**
	 * <pre>
	 * 처리내용: 마스터회원 유무 체크
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	String selectMberMaster(String entrpsNo);

	/**
	 * <pre>
	 * 처리내용: 비밀번호 초기화
	 * </pre>
	 * @date 2021. 6. 28.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberId
	 * @param randomPwd
	 * @return
	 */
	int updatePwdInit(EntrpsMbInfoVO entrpsMbInfoVO);

	/**
	 * <pre>
	 * 처리내용: 마스터회원 변경
	 * </pre>
	 * @date 2021. 6. 29.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 29.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsMbInfoVO
	 * @return
	 */
	int deleteMbMaster(EntrpsMbInfoVO entrpsMbInfoVO);

	/**
	 * <pre>
	 * 처리내용: 회원 정보 이력 입력
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsMbInfoVO
	 * @return
	 */
	int insertMbInfoBasHst(EntrpsMbInfoVO entrpsMbInfoVO);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 24.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 24.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsMbInfoVO
	 * @return
	 */
	int selectSigninAt(EntrpsMbInfoVO entrpsMbInfoVO);


}
