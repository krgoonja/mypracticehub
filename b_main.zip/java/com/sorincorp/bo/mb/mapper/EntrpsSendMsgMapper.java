/**
 *
 */
package com.sorincorp.bo.mb.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.mb.model.EntrpsSendMsgVO;
import com.sorincorp.bo.sample.model.SampleVO;

/**
 * EntrpsSendMsgMapper.java
 * @version
 * @since 2021. 7. 1.
 * @author srec0009
 */
/**
 * EntrpsSendMsgMapper.java
 * @version
 * @since 2021. 9. 28.
 * @author srec0009
 */
public interface EntrpsSendMsgMapper {
	/**
	 * <pre>
	 * 처리내용: 기업회원조회 > 메시지발송 조회 페이징
	 * </pre>
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 28.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsSendMsgVO
	 * @return
	 */
	int selectEntrpsSendMsgListToCnt(EntrpsSendMsgVO entrpsSendMsgVO);

	/**
	 * <pre>
	 * 처리내용: 기업회원조회 > 메시지발송 조회
	 * </pre>
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 28.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsSendMsgVO
	 * @return
	 */
	public List<EntrpsSendMsgVO> selectEntrpsSendMsgList(Map<String, Object> param);

	/**
	 * <pre>
	 * 처리내용: 기업회원조회 > 메시지발송 상세 조회
	 * </pre>
	 * @date 2021. 7. 1.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 1.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsSendMsgVO
	 * @return
	 */
	EntrpsSendMsgVO selectEntrpsSendMsgDtl(EntrpsSendMsgVO entrpsSendMsgVO);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 26.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 26.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param string
	 * @return
	 */
	int selectTableExistCnt(String string);
}
