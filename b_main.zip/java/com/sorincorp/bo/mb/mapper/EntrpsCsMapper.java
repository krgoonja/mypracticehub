/**
 *
 */
package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.EntrpsCsVO;
import com.sorincorp.bo.mb.model.MbCmnCodeVO;

/**
 * SimpleMberMapper.java
 * 
 * @version
 * @since 2021. 6. 30.
 * @author srec0009
 */
public interface EntrpsCsMapper {

	/**
	 * <pre>
	 * 처리내용: 기업회원 > 상담/문의 리스트 조회
	 * </pre>
	 * 
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsCsVO
	 * @return
	 */
	List<EntrpsCsVO> selectEntrpsCsList(EntrpsCsVO entrpsCsVO);

	/**
	 * <pre>
	 * 처리내용: 기업회원 > 상담/문의 리스트 조회 페이징
	 * </pre>
	 * 
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsCsVO
	 * @return
	 */
	int selectEntrpsCsListTotCnt(EntrpsCsVO entrpsCsVO);

	/**
	 * <pre>
	 * 처리내용: 기업회원 > 상담/문의 - 대분류에 따른 중분류 검색
	 * </pre>
	 * 
	 * @date 2021. 9. 9.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 9.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param selInqrySeCode
	 * @return
	 */
	List<MbCmnCodeVO> selectInqrySeDetailCode(String inqrySeCode);
}
