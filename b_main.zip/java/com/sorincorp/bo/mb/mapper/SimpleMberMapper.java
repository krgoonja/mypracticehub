/**
 *
 */
package com.sorincorp.bo.mb.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.mb.model.EntrpsSendEmailVO;
import com.sorincorp.bo.mb.model.EntrpsSendMsgVO;
import com.sorincorp.bo.mb.model.SimpleMberInfoVO;

/**
 * SimpleMberMapper.java
 * @version
 * @since 2021. 6. 30.
 * @author srec0009
 */
/**
 * SimpleMberMapper.java
 * @version
 * @since 2021. 7. 23.
 * @author srec0009
 */
public interface SimpleMberMapper {


	/**
	 * <pre>
	 * 처리내용: 간편회원 리스트 조회
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simpleMberInfoVO
	 * @return
	 */
	List<SimpleMberInfoVO> selectSimpleMberInfoList(SimpleMberInfoVO simpleMberInfoVO);
	/**
	 * <pre>
	 * 처리내용: 간편회원 리스트 조회 paging
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simpleMberInfoVO
	 * @return
	 */
	int selectSimpleMberInfoListTotCnt(SimpleMberInfoVO simpleMberInfoVO);

	/**
	 * <pre>
	 * 처리내용: 간편회원 상세정보
	 * </pre>
	 * @date 2021. 7. 5.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 5.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simpleMberInfoVO
	 * @return
	 */
	SimpleMberInfoVO selectSimpleMberInfoDetail(SimpleMberInfoVO simpleMberInfoVO);

	/**
	 * <pre>
	 * 처리내용: 간편회원 접속 이력 조회 paging
	 * </pre>
	 * @date 2021. 7. 5.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 5.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simpleMberInfoVO
	 * @return
	 */
	int selectSimpleMberConectHstListTotCnt(SimpleMberInfoVO simpleMberInfoVO);

	/**
	 * <pre>
	 * 처리내용: 간편 회원 접속 이력 조회
	 * </pre>
	 * @date 2021. 7. 5.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 5.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simpleMberInfoVO
	 * @return
	 */
	List<SimpleMberInfoVO> selectSimpleMberConectHstList(SimpleMberInfoVO simpleMberInfoVO);

	/**
	 * <pre>
	 * 처리내용:간편 회원 알람 이력 조회
	 * </pre>
	 * @date 2021. 7. 6.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 6.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simpleMberInfoVO
	 * @return
	 */
	List<SimpleMberInfoVO> selectSimpleMberAlertHstList(Map<String, Object> param);

	/**
	 * <pre>
	 * 처리내용: 메세지 알람 상세조회
	 * </pre>
	 * @date 2021. 7. 6.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 6.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsSendMsgVO
	 * @return
	 */

	EntrpsSendMsgVO selectMsgAlertDtl(EntrpsSendMsgVO entrpsSendMsgVO);

	/**
	 * <pre>
	 * 처리내용: 이메일 알람 상세조회
	 * </pre>
	 * @date 2021. 7. 6.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 6.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsSendMsgVO
	 * @return
	 */
	EntrpsSendMsgVO selectEmailAlertDtl(EntrpsSendMsgVO entrpsSendMsgVO);

	/**
	 * <pre>
	 * 처리내용: 간편회원 접속 이력 paging
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsSendMsgVO
	 * @return
	 */
	int selectSimpleMberConectHstListTotCnt(EntrpsSendMsgVO entrpsSendMsgVO);

	/**
	 * <pre>
	 * 처리내용: 간편회원 paging
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsSendMsgVO
	 * @return
	 */
	int selectSimpleMberAlertHstListTotCnt(EntrpsSendMsgVO entrpsSendMsgVO);

	/**
	 * <pre>
	 * 처리내용: 간편 회원 비밀번호 초기화
	 * </pre>
	 * @date 2021. 7. 8.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 8.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simpleMberInfoVO
	 * @return
	 */
	int updateSimplPwdInit(SimpleMberInfoVO simpleMberInfoVO);

	/**
	 * <pre>
	 * 처리내용: 간편 회원 비밀번호 초기화 이력
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simpleMberInfoVO
	 */
	void updateSimplPwdInitHst(SimpleMberInfoVO simpleMberInfoVO);
	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 29.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 29.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param string
	 * @return
	 */
	int selectTableExistCnt(String string);
	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 12. 2.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 2.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsSendMsgVO
	 * @return
	 */
	EntrpsSendMsgVO selectPushAlertDtl(EntrpsSendMsgVO entrpsSendMsgVO);
	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 12. 2.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 2.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsSendMsgVO
	 * @return
	 */
	EntrpsSendMsgVO selectSmsAlertDtl(EntrpsSendMsgVO entrpsSendMsgVO);
	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 12. 2.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 2.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsSendMsgVO
	 * @return
	 */
	EntrpsSendMsgVO selectLmsAlertDtl(EntrpsSendMsgVO entrpsSendMsgVO);

}
