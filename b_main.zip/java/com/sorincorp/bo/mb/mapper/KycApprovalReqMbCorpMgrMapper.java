package com.sorincorp.bo.mb.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.co.model.CmmnCodeVO;
import com.sorincorp.bo.mb.model.ApprovalReqMbCorpMgrVO;
import com.sorincorp.bo.mb.model.KycApprovalReqMbCorpMgrVO;

public interface KycApprovalReqMbCorpMgrMapper {

	/**
	 * <pre>
	 * 처리내용: kyc 승인업체 검색 조건 조회한다.
	 * </pre>
	 * 
	 * @date 2022. 12. 14.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 14.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	//회사구조
	List<CmmnCodeVO> selectKycCompnyStrctCode() throws Exception;

	//요청상태
	List<CmmnCodeVO> selectKycRequstSttusCode() throws Exception;

	/**
	 * <pre>
	 * 처리내용: kyc 승인업체 리스트를 비동기 ajax로 조회한다.
	 * </pre>
	 * 
	 * @date 2022. 12. 14.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 14.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	List<KycApprovalReqMbCorpMgrVO> selectKycCorpInfoList(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: kyc 승인업체 리스트 카운트를 비동기 ajax로 조회한다.
	 * </pre>
	 * 
	 * @date 2022. 12. 14.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 14.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	Integer selectKycCorpInfoListCount(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: kyc 접수요청.
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	Integer updateKycRequstSttusCode(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

	Integer updateKycgrnty(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: kyc 승인업체 디테일 리스트 조회.
	 * </pre>
	 * 
	 * @date 2022. 12. 14.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 14.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	List<KycApprovalReqMbCorpMgrVO> selectKycCorpDetailInfoList(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

	KycApprovalReqMbCorpMgrVO selectKycCorpDetailInfoVo(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: kyc 승인업체 첨부파일 리스트
	 * </pre>
	 * 
	 * @date 2022. 12. 14.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 14.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	List<KycApprovalReqMbCorpMgrVO> selectKycAttachFileList(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: kyc 승인업체 첨부파일 삭제
	 * </pre>
	 * 
	 * @date 2022. 12. 14.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 14.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	int deleteAttachFile(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: kyc 승인업체 디테일 - 메일 발송 이력 리스트 조회
	 * </pre>
	 * 
	 * @date 2022. 12. 14.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 14.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	List<KycApprovalReqMbCorpMgrVO> selectKycMailSendngList(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: kyc 접수 업체 정보 - 사업배경 update.
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	Integer updateKycApprovalReqMbCorp(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: kyc 접수 업체 정보 - 이사회명단, 주주명단 리스트를 비동기 ajax로 조회한다.
	 * </pre>
	 * 
	 * @date 2022. 12. 14.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 14.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	//        List<KycApprovalReqMbCorpMgrVO> selectkycApprovalCptalInfoList(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO, boolean flag) throws Exception;
	List<KycApprovalReqMbCorpMgrVO> selectkycApprovalCptalInfoList(Map<String, Object> requestData) throws Exception;

	/**
	 * <pre>
	 * 처리내용: kyc 접수 업체 정보 - 이사회명단, 주주명단 리스트 카운트를 비동기 ajax로 조회한다.
	 * </pre>
	 * 
	 * @date 2022. 12. 14.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 14.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	Integer selectkycApprovalCptalInfoListCount(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: kyc 접수 업체 정보 - 이사회명단, 주주명단 리스트 insert.
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	int insertkycApprovalCptalInfoList(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: kyc 접수 업체 정보 - 이사회명단, 주주명단 리스트 delete
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	Integer deleteKycApprovalCptalInfoList(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: KYC - 승인 보류(희망한도금액 후 거절) setKycRequstSttusCode -> 13
	 * 처리내용: KYC - 승인 보류(거절) setKycRequstSttusCode -> 20
	 * 처리내용: KYC - 승인 완료(승인) setKycRequstSttusCode -> 30
	 * 처리내용: KYC - 최종 승인 완료(승인 완료) setKycRequstSttusCode -> 50
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	Integer resrveKycApprovalCptalInfo(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

	ApprovalReqMbCorpMgrVO selectApprovalReqMbCorpInfoDetail(String entrpsNo) throws Exception;

	Integer updateMbEntrpsInfoBas(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	Integer updateMbMberInfoBas(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	List<ApprovalReqMbCorpMgrVO> selectMberList(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: kyc 승인 요청 업체의 전화번호 조회
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	List<KycApprovalReqMbCorpMgrVO> selectAllTelno(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: KYC - 메일 히스토리 저장
	 * </pre>
	 * 
	 * @date 2022. 12. 15.
	 * @author hyunjin05
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 12. 15.	hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @param KycApprovalReqMbCorpMgrVO
	 * @return
	 * @throws Exception
	 */
	public int insertKycMailSendngList(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

	String selectMberNo(KycApprovalReqMbCorpMgrVO kycApprovalReqMbCorpMgrVO) throws Exception;

}
