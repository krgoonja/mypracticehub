/**
 *
 */
package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.EntrpsOrderHstVO;

/**
 * EntrpsOrderHstMapper.java
 * @version
 * @since 2021. 9. 6.
 * @author srec0009
 */
public interface EntrpsOrderHstMapper {

	/**
	 * <pre>
	 * 처리내용:  회원 주문 내역 조회 화면
	 * </pre>
	 * @date 2021. 9. 6.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 6.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsOrderHstVO
	 * @return
	 */
	List<EntrpsOrderHstVO> selectEntrpsOrderHst(EntrpsOrderHstVO entrpsOrderHstVO);

	/**
	 * <pre>
	 * 처리내용: 주문 내역 상세 조회 (modal)
	 * </pre>
	 * @date 2021. 9. 6.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 6.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsOrderHstVO
	 * @return
	 */
	EntrpsOrderHstVO selectOrderDlvrgDtl(EntrpsOrderHstVO entrpsOrderHstVO);

	/**
	 * <pre>
	 * 처리내용: 회원 주문 내역 조회 페이징
	 * </pre>
	 * @date 2021. 9. 7.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 7.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsOrderHstVO
	 * @return
	 */
	int selectEntrpsMbInfoListTotCnt(EntrpsOrderHstVO entrpsOrderHstVO);

}
