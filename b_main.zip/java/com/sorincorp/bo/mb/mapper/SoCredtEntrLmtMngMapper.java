package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.SoCredtEntrLmtHistVO;
import com.sorincorp.bo.mb.model.SoCredtEntrLmtMngVO;

/**
 * SoCredtEntrLmtMngMapper.java
 *
 * @version
 * @since 2022. 11. 15.
 * @author srec0070
 */
public interface SoCredtEntrLmtMngMapper {
	/**
	 * <pre>
	 * 처리내용: 검색조건 구성을 위한 distinct 여신 계약 번호 조회
	 * </pre>
	 *
	 * @date 2022. 11. 15.
	 * @author srec0070
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 15.
	 *          srec0070 최초작성 ------------------------------------------------
	 * @param lmtMngVO
	 * @return
	 */
	List<String> selectCdtlnCntrctNoList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 기업 한도 이력 목록을 페이징
	 * </pre>
	 *
	 * @date 2022. 11. 15.
	 * @author srec0070
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 15.
	 *          srec0070 최초작성 ------------------------------------------------
	 * @param lmtMngVO
	 * @return
	 */
	int selectEntrprsLmtHistListTotCnt(SoCredtEntrLmtHistVO lmtMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 기업 한도 이력 목록 조회
	 * </pre>
	 *
	 * @date 2022. 11. 15.
	 * @author srec0070
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 15.
	 *          srec0070 최초작성 ------------------------------------------------
	 * @param lmtMngVO
	 * @return
	 */
	List<SoCredtEntrLmtHistVO> selectEntrprsLmtHistList(SoCredtEntrLmtHistVO lmtMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 on-off line 사용 정보 조회
	 * </pre>
	 *
	 * @date 2022. 11. 15.
	 * @author srec0070
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 15.
	 *          srec0070 최초작성 ------------------------------------------------
	 * @param lmtMngVO
	 * @return
	 */
	SoCredtEntrLmtHistVO selectOn_OffUseAmountInfo(SoCredtEntrLmtHistVO lmtMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지 크레딧을 사용한 주문번호를 조회
	 * </pre>
	 *
	 * @date 2022. 11. 15.
	 * @author srec0070
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 15.
	 *          srec0070 최초작성 ------------------------------------------------
	 * @param lmtMngVO
	 * @return
	 */
	List<SoCredtEntrLmtHistVO> selectOrderNoInfoList(SoCredtEntrLmtHistVO lmtMngVO) throws Exception;
	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약 목록 조회
	 * </pre>
	 *
	 * @date 2022. 11. 16.
	 * @author srec0076
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 16.
	 *          srec0076 최초작성 ------------------------------------------------
	 * @param
	 * @return
	 */
	List<SoCredtEntrLmtMngVO> selectSoCredList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약 등록
	 * </pre>
	 *
	 * @date 2022. 11. 16.
	 * @author srec0076
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 16.
	 *          srec0076 최초작성 ------------------------------------------------
	 * @param
	 * @return
	 */
	void insertSoCredInfo(SoCredtEntrLmtMngVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약 history 등록
	 * </pre>
	 *
	 * @date 2022. 11. 16.
	 * @author srec0076
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 16.
	 *          srec0076 최초작성 ------------------------------------------------
	 * @param
	 * @return
	 */
	void insertSoCredHistory(SoCredtEntrLmtMngVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약 수정
	 * </pre>
	 *
	 * @date 2022. 11. 16.
	 * @author srec0076
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 16.
	 *          srec0076 최초작성 ------------------------------------------------
	 * @param
	 * @return
	 */
	void updateSoCredInfo(SoCredtEntrLmtMngVO vo) throws Exception;


	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약 목록 조회
	 * </pre>
	 *
	 * @date 2022. 11. 16.
	 * @author srec0076
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 16.
	 *          srec0076 최초작성 ------------------------------------------------
	 * @param
	 * @return
	 */
	List<SoCredtEntrLmtMngVO> selectEntrprsLmtMngList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 현재 사용중인 Marsh 계약 조회
	 * </pre>
	 *
	 * @date 2022. 11. 17.
	 * @author srec0076
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 17.
	 *          srec0076 최초작성 ------------------------------------------------
	 * @param
	 * @return
	 */
	List<SoCredtEntrLmtMngVO> selectEntrprsLmtMngUseData() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 현재 사용중인 Marsh 계약 사용중지로 변경
	 * </pre>
	 *
	 * @date 2022. 11. 17.
	 * @author srec0076
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 17.
	 *          srec0076 최초작성 ------------------------------------------------
	 * @param
	 * @return
	 */
	int updateEntrprsUseAt(String cdtlnCntrctNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약 등록
	 * </pre>
	 *
	 * @date 2022. 11. 16.
	 * @author srec0076
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 16.
	 *          srec0076 최초작성 ------------------------------------------------
	 * @param
	 * @return
	 */
	int insertEntrprsLmtMngInfo(SoCredtEntrLmtMngVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약 history 등록
	 * </pre>
	 *
	 * @date 2022. 11. 16.
	 * @author srec0076
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 16.
	 *          srec0076 최초작성 ------------------------------------------------
	 * @param
	 * @return
	 */
	void insertEntrprsLmtMngInfoHistory(SoCredtEntrLmtMngVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약 수정
	 * </pre>
	 *
	 * @date 2022. 11. 16.
	 * @author srec0076
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 16.
	 *          srec0076 최초작성 ------------------------------------------------
	 * @param
	 * @return
	 */
	int updateEntrprsLmtMngInfo(SoCredtEntrLmtMngVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 사용중인 Marsh 계약 수량
	 * </pre>
	 *
	 * @date 2022. 11. 16.
	 * @author srec0076
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 21.
	 *          srec0076 최초작성 ------------------------------------------------
	 * @param
	 * @return
	 */
	int selectEntrprsLmtMngUseDataCount() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 계약 삭제
	 * </pre>
	 * @date 2022. 11. 22.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 22.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */

	int deleteEntrprsLmtMng(SoCredtEntrLmtMngVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 가장 빠른 종료일 계약 건 조회
	 * </pre>
	 * @date 2022. 11. 22.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 22.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */

	SoCredtEntrLmtMngVO selectEntrprsLmtMngByEndd() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 한도 설정가 내역 조회
	 * </pre>
	 * @date 2022. 11. 22.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 22.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */

	List<SoCredtEntrLmtMngVO> selectSubEntrprsLmtMngList(SoCredtEntrLmtMngVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 기업 맵핑 목록
	 * </pre>
	 * @date 2022. 11. 22.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 22.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */

	List<SoCredtEntrLmtMngVO> selectSubEntrprsMngList(SoCredtEntrLmtMngVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 한도 설정 등록
	 * </pre>
	 * @date 2022. 11. 23.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 23.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */

	int insertEntrprsSubLmtMngInfo(SoCredtEntrLmtMngVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 한도 설정 등록 히스토리
	 * </pre>
	 * @date 2022. 11. 23.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 23.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */

	void insertEntrprsSubLmtMngInfoHistory(SoCredtEntrLmtMngVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 한도 설정 수정
	 * </pre>
	 * @date 2022. 11. 23.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 23.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */

	int updateEntrprsSubLmtMngInfo(SoCredtEntrLmtMngVO vo) throws Exception;
	
	
	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 Marsh 한도 설정 삭제
	 * </pre>
	 * @date 2022. 11. 23.
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 23.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	
	int deleteEntrprsSubLmtMngInfo(SoCredtEntrLmtMngVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 계약이력 조회
	 * </pre>
	 * @date 2022. 11. 23.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 23.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param lmtMngVO
	 * @return
	 * @throws Exception
	 */
	List<SoCredtEntrLmtHistVO> selectEntrprsSoCredtCntrctHstList(SoCredtEntrLmtHistVO lmtMngVO) throws Exception;
}

