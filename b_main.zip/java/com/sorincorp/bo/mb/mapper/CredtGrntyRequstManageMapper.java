package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.CredtGrntyRequstManageVO;

public interface CredtGrntyRequstManageMapper {

	List<CredtGrntyRequstManageVO> selectCredtGrntyRequstManageList(CredtGrntyRequstManageVO credtGrntyRequstManageVO) throws Exception;

	int selectCredtGrntyRequstManageTotCnt(CredtGrntyRequstManageVO credtGrntyRequstManageVO) throws Exception;

}
