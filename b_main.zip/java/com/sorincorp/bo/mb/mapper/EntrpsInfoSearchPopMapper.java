package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.MbEntrpsMbVO;

public interface EntrpsInfoSearchPopMapper {

	List<MbEntrpsMbVO> selectEntrpsInfoList(MbEntrpsMbVO mbEntrpsMbVO) throws Exception;

	int selectEntrpsInfoListCnt(MbEntrpsMbVO mbEntrpsMbVO) throws Exception;

}
