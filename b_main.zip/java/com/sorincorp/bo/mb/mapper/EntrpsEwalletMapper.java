/**
 *
 */
package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.EntrpsEwalletVO;
import com.sorincorp.bo.mb.model.EntrpsSendEmailVO;
import com.sorincorp.bo.mb.model.EntrpsSendMsgVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;
import com.sorincorp.bo.mb.model.SimpleMberInfoVO;

/**
 * SimpleMberMapper.java
 * @version
 * @since 2021. 6. 30.
 * @author srec0009
 */
/**
 * SimpleMberMapper.java
 * @version
 * @since 2021. 7. 23.
 * @author srec0009
 */
public interface EntrpsEwalletMapper {

	/**
	 * <pre>
	 * 처리내용: 이월렛 목록 조회
	 * </pre>
	 * @date 2021. 8. 19.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 19.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsEwalletVO
	 * @return
	 */
	List<MbEntrpsMbVO> selectEntrpsEwlaletList(EntrpsEwalletVO entrpsEwalletVO);

	/**
	 * <pre>
	 * 처리내용: 이월렛 목록 조회 페이징
	 * </pre>
	 * @date 2021. 8. 19.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 19.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsEwalletVO
	 * @return
	 */
	int selectEntrpsEwalletListTotCnt(EntrpsEwalletVO entrpsEwalletVO);




}
