package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.DeliveryRegionMngVO;

public interface DeliveryRegionMngMapper {

	/**
	 * <pre>
	 * 처리내용: 배송지 리스트 조회
	 * </pre>
	 * @date 2021. 6. 7.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 7.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return 배송지 리스트
	 * @throws Exception
	 */
	List<DeliveryRegionMngVO> selectDeliveryRegionMngList(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 배송지 리스트 총 카운트 조회
	 * </pre>
	 * @date 2021. 6. 7.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 7.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return 배송지 리스트 총 카운트
	 * @throws Exception
	 */
	int selectDeliveryRegionMngTotCnt(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 배송지 삭제
	 * </pre>
	 * @date 2021. 6. 7.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 7.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return 삭제 결과값
	 * @throws Exception
	 */
	int deleteMbDlvrgBas(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 배송지 상세정보 조회
	 * </pre>
	 * @date 2021. 6. 7.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 7.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return 배송지 상세정보
	 * @throws Exception
	 */
	DeliveryRegionMngVO selectDeliveryRegionMngDetail(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 배송지 구분 리스트 조회
	 * </pre>
	 * @date 2021. 6. 7.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 7.			srec0030			최초작성
	 * ------------------------------------------------
	 * @return 배송지 구분 리스트
	 * @throws Exception
	 */
	List<DeliveryRegionMngVO> selectMbDlvrgSeDtlListList(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 배송지 신규등록
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return 등록결과값
	 * @throws Exception
	 */
	int insertDeliveryRegion(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 배송지 수정
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return 수정결과
	 * @throws Exception
	 */
	int updateDeliveryRegion(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기본배송지 카운트 조회
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return 기본배송지 카운트
	 * @throws Exception
	 */
	int selectBassDlvrgCnt(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기본배송지 수정
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return 수정결과
	 * @throws Exception
	 */
	int updateBassDlvrgAt(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	void insertMbDlvrgBasHst(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

}
