/**
 *
 */
package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.MbTotSetleDtlsVO;


/**
 * MbTotSetleDtlsMapper.java
 * @version
 * @since 2022. 8. 25.
 * @author srec0073
 */
public interface MbTotSetleDtlsMapper {
	/**
	 * <pre>
	 * 처리내용: 전체 결제내역 목록 갯수
	 * </pre>
	 * @date 2022. 8. 25.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0073			최초작성
	 * ------------------------------------------------
	 * @param mbTotSetleDtlsVO
	 * @return
	 */
	int selectMbTotSetleDtlsListCnt(MbTotSetleDtlsVO mbTotSetleDtlsVO);

	/**
	 * <pre>
	 * 처리내용: 전체 결제내역 목록 조회
	 * </pre>
	 * @date 2022. 8. 25.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0073			최초작성
	 * ------------------------------------------------
	 * @param mbTotSetleDtlsVO
	 * @return
	 */
	List<MbTotSetleDtlsVO> selectMbTotSetleDtlsList(MbTotSetleDtlsVO mbTotSetleDtlsVO);

	/**
	 * <pre>
	 * 처리내용: 업체의 여신 구분 코드 조회
	 * </pre>
	 * @date 2022. 11. 18.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 18.			srec0073			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	String selectCdtlnSvcSeCode(String entrpsNo);
}
