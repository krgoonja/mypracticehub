package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.MbEntrpsGradMngVO;

public interface MbEntrpsGradMngMapper {

	MbEntrpsGradMngVO selectMbEntrpsGradMngInfo() throws Exception;

	List<MbEntrpsGradMngVO> selectMbEntrpsGradMngList() throws Exception;

	int updateMbEntrpsGradManageBas(MbEntrpsGradMngVO mbEntrpsGradMngVO) throws Exception;

	int insertMbEntrpsGradManageBasHst(MbEntrpsGradMngVO mbEntrpsGradMngVO) throws Exception;

	String selectMbEntrpsGradManageBasChgYn(MbEntrpsGradMngVO mbEntrpsGradMngVO) throws Exception;

	int insertMbEntrpsGradManageBas(MbEntrpsGradMngVO mbEntrpsGradMngVO) throws Exception;

	List<MbEntrpsGradMngVO> selectMbEntrpsGradMngChgHistList(MbEntrpsGradMngVO mbEntrpsGradMngVO) throws Exception;

	int selectMbEntrpsGradMngChgHistTotCnt(MbEntrpsGradMngVO mbEntrpsGradMngVO) throws Exception;

	List<MbEntrpsGradMngVO> selectMbEntrpsGradMngChgHistDetailList(MbEntrpsGradMngVO mbEntrpsGradMngVO) throws Exception;

}
