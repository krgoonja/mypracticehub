/**
 *
 */
package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.MbEntrpsGradMngVO;
import com.sorincorp.bo.mb.model.MbEntrpsMbVO;

/**
 * EntrpsMbMapper.java
 * 
 * @version
 * @since 2021. 6. 7.
 * @author srec0009
 */
public interface EntrpsMbMapper {

	/**
	 * <pre>
	 * 처리내용: 기업 회원 목록 페이징
	 * </pre>
	 * 
	 * @date 2021. 6. 9.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 9.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsMbVO
	 * @return
	 */
	int selectEntrpsMbListTotCnt(MbEntrpsMbVO entrpsMbVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기업 회원 목록
	 * </pre>
	 * 
	 * @date 2021. 6. 9.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 9.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsMbVO
	 * @return
	 */
	List<MbEntrpsMbVO> selectEntrpsMbList(MbEntrpsMbVO entrpsMbVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원사 등급 조회
	 * </pre>
	 * 
	 * @date 2021. 6. 7.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 7.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @return
	 */
	List<MbEntrpsMbVO> selectEntrpsGrad() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원 등급 일괄 변경.
	 * </pre>
	 * 
	 * @date 2021. 6. 9.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 9.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsMbList
	 * @return
	 */
	int updateEntrpsGradLevelAll(MbEntrpsMbVO entrpsMbList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원 등급 일괄 변경 이력 insert
	 * </pre>
	 * 
	 * @date 2021. 7. 23.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 23.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param mbEntrpsMbVO
	 */
	int insertEntrpsGradLevelAllHst(MbEntrpsMbVO entrpsMbList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 총 주문금액, 주문건수, voc 건수
	 * </pre>
	 * 
	 * @date 2021. 9. 9.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 9.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	MbEntrpsMbVO selectTotSlePc(String entrpsNo) throws Exception;

	int updateEntrpsGradList(MbEntrpsMbVO mbEntrpsMbVO) throws Exception;

	MbEntrpsGradMngVO selectMbEntrpsGradCalcDtl(String entrpsNo) throws Exception;

}
