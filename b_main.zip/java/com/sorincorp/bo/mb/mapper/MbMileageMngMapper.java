package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.MbMileageMngVO;

public interface MbMileageMngMapper {

	List<MbMileageMngVO> selectMbMileageMngList(MbMileageMngVO mbMileageMngVO) throws Exception;

	Integer selectMbMileageMngListCnt(MbMileageMngVO mbMileageMngVO) throws Exception;

	MbMileageMngVO selectMbMileageMngSeList(MbMileageMngVO mbMileageMngVO) throws Exception;
}
