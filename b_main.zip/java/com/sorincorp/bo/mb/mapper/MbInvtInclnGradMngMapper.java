package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.MbEvlGradMngVO;
import com.sorincorp.bo.mb.model.MbInvtInclnGradMngVO;

public interface MbInvtInclnGradMngMapper {

	List<MbInvtInclnGradMngVO> selectMbInvtInclnGradMngList() throws Exception;

	String selectMbInvtInclnGradMngBasChgYn(MbInvtInclnGradMngVO mbInvtInclnGradMngVO) throws Exception;

	int updateMbInvtInclnGradMngBas(MbInvtInclnGradMngVO mbInvtInclnGradMngVO) throws Exception;

	int insertMbInvtInclnGradMngBasHst(MbInvtInclnGradMngVO mbInvtInclnGradMngVO) throws Exception;

	MbInvtInclnGradMngVO selectMbInvtInclnGradMng() throws Exception;

	List<MbInvtInclnGradMngVO> selectMbPurchsInclnGradMngChgHistList(MbInvtInclnGradMngVO mbInvtInclnGradMngVO) throws Exception;

	int selectMbPurchsInclnGradMngChgHistTotCnt(MbInvtInclnGradMngVO mbInvtInclnGradMngVO) throws Exception;

	List<MbEvlGradMngVO> selectMbPurchsInclnGradMngChgHistDetailList(MbInvtInclnGradMngVO mbInvtInclnGradMngVO) throws Exception;

}
