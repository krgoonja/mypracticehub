package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.MbGradAcctoBnefMngVO;

public interface MbGradAcctoBnefMngMapper {

	List<MbGradAcctoBnefMngVO> selectMbGradAcctoBnefMngList(MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception;

	List<MbGradAcctoBnefMngVO> selectMbGradAcctoBnefMngBBList(MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception;

	List<MbGradAcctoBnefMngVO> selectMbGradAcctoBnefMngMDtlList(MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception;

	Integer selectMbGradAcctoBnefMngListCnt(MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception;

	int getOpertnDeDuplicateCnt(MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception;

	MbGradAcctoBnefMngVO selectMbGradAcctoBnefMngGradList() throws Exception;

	int updateMbGradAcctoBnefMngBB(MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception;

	int updateMbGradAcctoBnefMngMDtl(MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception;

	int insertMbGradAcctoBnefMngBBHSt(MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception;

	int insertMbGradAcctoBnefMngMDtlHSt(MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception;

	int insertMbGradAcctoBnefMngBB(MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception;

	int insertMbGradAcctoBnefMngMDtl(MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception;

	int deleteMbGradAcctoBnefMngBB(MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception;

	int deleteMbGradAcctoBnefMngMDtl(MbGradAcctoBnefMngVO mbGradAcctoBnefMngVO) throws Exception;
}
