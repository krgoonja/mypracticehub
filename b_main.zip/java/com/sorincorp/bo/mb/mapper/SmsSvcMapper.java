package com.sorincorp.bo.mb.mapper;

import com.sorincorp.bo.mb.model.SmsSvcVO;

import java.util.List;

public interface SmsSvcMapper {

    /**
     *
     * <pre>
     * 업체 목록 조회
     * </pre>
     * @date 2024. 06. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 06. 19.       hamyoonsic              최초작성
     * ------------------------------------------------
     * @param
     * @return  List<SmsSvcVO>
     * @throws  Exception
     */
    List<SmsSvcVO> selectSmsEntrpsList(SmsSvcVO gridParam) throws Exception;

    /**
     *
     * <pre>
     * 멤버 목록 조회
     * </pre>
     * @date 2024. 06. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 06. 19.       hamyoonsic              최초작성
     * ------------------------------------------------
     * @param
     * @return  List<SmsSvcVO>
     * @throws  Exception
     */
    List<SmsSvcVO> selectSmsMberList(SmsSvcVO gridParam) throws Exception;

    /**
     *
     * <pre>
     * 템플릿 조회
     * </pre>
     * @date 2024. 06. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 06. 19.       hamyoonsic              최초작성
     * ------------------------------------------------
     * @param
     * @return  List<SmsSvcVO>
     * @throws  Exception
     */
    List<SmsSvcVO> selectTemplate(SmsSvcVO smsVO) throws Exception;

    /**
     *
     * <pre>
     * 템플릿 등록
     * </pre>
     * @date 2024. 06. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 06. 19.       hamyoonsic              최초작성
     * ------------------------------------------------
     * @param   smsVO
     * @return
     * @throws  Exception
     */
     void insertTemplate(SmsSvcVO smsVO) throws Exception;

    /**
     *
     * <pre>
     * 템플릿 수정
     * </pre>
     * @date 2024. 06. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 06. 19.       hamyoonsic              최초작성
     * ------------------------------------------------
     * @param   smsVO
     * @return
     * @throws  Exception
     */
    void updateTemplate(SmsSvcVO smsVO) throws Exception;

    /**
     *
     * <pre>
     * 템플릿 삭제
     * </pre>
     * @date 2024. 06. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 06. 19.       hamyoonsic              최초작성
     * ------------------------------------------------
     * @param   smsVO
     * @return
     * @throws  Exception
     */
    void deleteTemplate(SmsSvcVO smsVO) throws Exception;

    /**
     *
     * <pre>
     * 주소록 멤버 수정
     * </pre>
     * @date 2024. 06. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 06. 19.       hamyoonsic              최초작성
     * ------------------------------------------------
     * @param   vo
     * @return
     * @throws  Exception
     */
    void updateAdbkDtl(SmsSvcVO vo) throws Exception;
    /**
     *
     * <pre>
     * 주소록 멤버 등록
     * </pre>
     * @date 2024. 06. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 06. 19.       hamyoonsic              최초작성
     * ------------------------------------------------
     * @param   vo
     * @return
     * @throws  Exception
     */
    void insertAdbkDtl(SmsSvcVO vo) throws Exception;

    /**
     *
     * <pre>
     * 주소록 등록
     * </pre>
     * @date 2024. 06. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 06. 19.       hamyoonsic              최초작성
     * ------------------------------------------------
     * @param   vo
     * @return
     * @throws  Exception
     */
    void insertAdbkBas(SmsSvcVO vo) throws Exception;

    /**
     *
     * <pre>
     * 주소록 삭제
     * </pre>
     * @date 2024. 06. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 06. 19.       hamyoonsic              최초작성
     * ------------------------------------------------
     * @param vo
     * @return
     * @throws  Exception
     */
    void deleteAdbkBas(SmsSvcVO vo) throws Exception;

    /**
     * <pre>
     * 주소록 조회
     * </pre>
     *
     * @param vo
     * @return List<SmsSvcVO>
     * @throws Exception
     * @date 2024. 06. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 06. 19.       hamyoonsic              최초작성
     * ------------------------------------------------
     */
    List<SmsSvcVO> selectSmsAdbkList(SmsSvcVO vo) throws Exception;

    /**
     * <pre>
     * 주소록  멤버 조회
     * </pre>
     *
     * @param vo
     * @return List<SmsSvcVO>
     * @throws Exception
     * @date 2024. 06. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 06. 19.       hamyoonsic              최초작성
     * ------------------------------------------------
     */
    List<SmsSvcVO> selectSmsAdbkMberList(SmsSvcVO vo) throws Exception;

    /**
     * <pre>
     * 주소록 수정
     * </pre>
     *
     * @param vo
     * @return
     * @throws Exception
     * @date 2024. 06. 19.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 06. 19.       hamyoonsic              최초작성
     * ------------------------------------------------
     */
    void updateAdbkBas(SmsSvcVO vo) throws Exception;
}
