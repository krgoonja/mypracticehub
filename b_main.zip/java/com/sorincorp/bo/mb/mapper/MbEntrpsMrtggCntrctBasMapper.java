package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.MbEntrpsMrtggCntrctBasVO;

public interface MbEntrpsMrtggCntrctBasMapper {

	/**
	 * <pre>
	 * 사용안함
	 * </pre>
	 * @date 2022. 12. 21.
	 * @author srec0051
	 * @return
	 * @throws Exception
	 * @deprecated
	 */
	List<MbEntrpsMrtggCntrctBasVO> selectIfKoditEntrpsProgrsSttusList() throws Exception;

	/**
	 * <pre>
	 * 회원업체담보기본 T 마지막 데이터 존재 여부 (최종계약=Y)
	 * </pre>
	 * @date 2022. 11. 21.
	 * @author srec0051
	 * @param ifKoditEntrpsProgrsSttusVO
	 * @return
	 * @throws Exception
	 */
	int selectLastEntrpsMrtggCnt(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	/**
	 * <pre>
	 * 회원업체담보기본 T 마지막 업체담보계약순번 조회 (최종계약=Y)
	 * </pre>
	 * @date 2022. 11. 21.
	 * @author srec0051
	 * @param ifKoditEntrpsProgrsSttusVO
	 * @return
	 * @throws Exception
	 */
	int selectLastEntrpsMrtggSn(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	double selectLastEntrpsMrtggSelngAchivrt(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int updateLastEntrpsMrtggSn2(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int selectMaxEntrpsMrtggSn(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	/**
	 * <pre>
	 * 회원업체담보기본 T 등록
	 * </pre>
	 * @date 2022. 11. 22.
	 * @author srec0051
	 * @param ifKoditEntrpsProgrsSttusVO
	 * @return
	 * @throws Exception
	 */
	int insertMbEntrpsMrtggCntrctBas(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int insertMbEntrpsMrtggCntrctBasHst(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	/**
	 * <pre>
	 * 사용안함
	 * </pre>
	 * @date 2022. 12. 21.
	 * @author srec0051
	 * @param ifKoditEntrpsProgrsSttusVO
	 * @return
	 * @throws Exception
	 * @deprecated
	 */
	int updateLedgrReflctAt(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	/**
	 * <pre>
	 * 사용안함
	 * </pre>
	 * @date 2022. 12. 21.
	 * @author srec0051
	 * @param ifKoditEntrpsProgrsSttusVO
	 * @return
	 * @throws Exception
	 * @deprecated
	 */
	MbEntrpsMrtggCntrctBasVO selectIfKoditEntrpsInfo(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	/**
	 * <pre>
	 * 회원업체담보상세 T 잔액 조회
	 * </pre>
	 * @date 2022. 11. 21.
	 * @author srec0051
	 * @param ifKoditEntrpsProgrsSttusVO
	 * @return
	 * @throws Exception
	 */
	long selectMrtggBlce(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	/**
	 * <pre>
	 * 회원업체담보기본 T 이전 한도 조회
	 * </pre>
	 * @date 2022. 11. 21.
	 * @author srec0051
	 * @param ifKoditEntrpsProgrsSttusVO
	 * @return
	 * @throws Exception
	 */
	long selectGrntyAmount(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	/**
	 * <pre>
	 * 회원업체담보상세 T 등록
	 * </pre>
	 * @date 2022. 11. 21.
	 * @author srec0051
	 * @param ifKoditEntrpsProgrsSttusVO
	 * @return
	 * @throws Exception
	 */
	int insertMbEntrpsMbEntrpsMrtggLmtDtl(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int insertMbEntrpsMbEntrpsMrtggLmtDtlHst(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int updateMbEntrpsMrtggGrntyTrmnatAt(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int insertMbEntrpsInfoBasHst(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	List<MbEntrpsMrtggCntrctBasVO> selectMbEntrpsMlgInfoDtlList(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	int selectRemndrMlgCnt(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	int selectRemndrMlg(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	int insertMbEntrpsMlgInfoDtl(MbEntrpsMrtggCntrctBasVO mlgVO) throws Exception;

	int insertMbEntrpsMlgInfoDtlHst(MbEntrpsMrtggCntrctBasVO mlgVO) throws Exception;

	int updateMbEntrpsMlgInfoDtl(MbEntrpsMrtggCntrctBasVO mlgVO) throws Exception;








	List<MbEntrpsMrtggCntrctBasVO> selectMbEntrpsMrtggCntrctBasList() throws Exception;

	/**
	 * <pre>
	 * 회원업체담보기본 T 해지 계약 카운트 조회
	 * </pre>
	 * @date 2022. 11. 18.
	 * @author srec0051
	 * @param mbEntrpsMrtggCntrctBasVO
	 * @return
	 * @throws Exception
	 */
	int selectEntrpsMrtggTerminationCnt(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	/**
	 * <pre>
	 * 회원업체담보기본 T 만료 계약 카운트 조회
	 * </pre>
	 * @date 2022. 11. 18.
	 * @author srec0051
	 * @param mbEntrpsMrtggCntrctBasVO
	 * @return
	 * @throws Exception
	 */
	int selectEntrpsMrtggEndAtCnt(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	/**
	 * <pre>
	 * 회원업체담보기본 T 마지막 계약여부, 배치적용여부 Y로 세팅
	 * </pre>
	 * @date 2022. 11. 21.
	 * @author srec0051
	 * @param ifKoditEntrpsProgrsSttusVO
	 * @return
	 * @throws Exception
	 */
	int updateLastEntrpsMrtggSn(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	/**
	 * <pre>
	 * 회원업체담보기본 T MP수수료 + 마지막 계약여부, 배치적용여부 Y로 세팅
	 * </pre>
	 * @date 2022. 11. 21.
	 * @author srec0051
	 * @param mbEntrpsMrtggCntrctBasVO
	 * @return
	 * @throws Exception
	 */
	int updateEntrpsMrtggCntctBasLastCntrctAt(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;







	/**
	 * <pre>
	 * 기간만료된 여신건 조회 (사용하게 된다면 케이지크레딧으로 변경필요)
	 * </pre>
	 * @date 2022. 12. 21.
	 * @author srec0051
	 * @return
	 * @throws Exception
	 * @deprecated
	 */
	List<MbEntrpsMrtggCntrctBasVO> selectMbEntrpsMrtggCntrctExpirationList() throws Exception;

	/**
	 * <pre>
	 * 사용안함
	 * </pre>
	 * @date 2022. 12. 21.
	 * @author srec0051
	 * @param mbEntrpsMrtggCntrctBasVO
	 * @return
	 * @throws Exception
	 * @deprecated
	 */
	int selectEntrpsMrtggCndChgCnt(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	/**
	 * <pre>
	 * 회원업체담보기본 T 만료 처리
	 * </pre>
	 * @date 2022. 11. 21.
	 * @author srec0051
	 * @param mbEntrpsMrtggCntrctBasVO
	 * @return
	 * @throws Exception
	 * @deprecated
	 */
	int updateMbEntrpsMbEntrpsMrtggEndAt(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;








	/**
	 * <pre>
	 * 회원업체담보기본 T 조회
	 * </pre>
	 * @date 2022. 11. 22.
	 * @author srec0051
	 * @param paramVo
	 * @return
	 */
	MbEntrpsMrtggCntrctBasVO selectMbEntrpsMrtggCntrctBas(MbEntrpsMrtggCntrctBasVO paramVo);

	/**
	 * <pre>
	 * 케이지크레딧 주문건 조회
	 * </pre>
	 * @date 2022. 12. 9.
	 * @author srec0051
	 * @param orginlVo
	 * @return
	 */
	int getCntOrder(MbEntrpsMrtggCntrctBasVO orginlVo);

	/**
	 * <pre>
	 * 케이지크레딧 회원업체담보계약 기본 T 보증금액 업데이트
	 * </pre>
	 * @date 2022. 12. 12.
	 * @author srec0051
	 * @param orginlVo
	 * @return
	 */
	int updateMbEntrpsMrtggCntrctBasGrntyAmt(MbEntrpsMrtggCntrctBasVO orginlVo);

	/**
	 * <pre>
	 * 케이지크레딧 회원업체담보상세 T 담보잔액 업데이트
	 * </pre>
	 * @date 2022. 12. 12.
	 * @author srec0051
	 * @param orginlVo
	 * @return
	 */
	int updateMbEntrpsMrtggLmtDtlMrtggAmt(MbEntrpsMrtggCntrctBasVO orginlVo);

}
