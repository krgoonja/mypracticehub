/**
 *
 */
package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.MbEntrpsMbVO;

/**
 * EntrpsDrmncyManageMapper.java
 * 
 * @version
 * @since 2024. 01. 29.
 * @author sein
 */
public interface EntrpsDrmncyManageMapper {

	/**
	 * <pre>
	 * 처리내용: 기업 회원 목록 페이징
	 * </pre>
	 * 
	 * @date 2024. 01. 29.
	 * @author sein
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2024. 01. 29.
	 *          sein 최초작성 ------------------------------------------------
	 * @param entrpsMbVO
	 * @return
	 */
	int selectEntrpsDrmncyManageListTotCnt(MbEntrpsMbVO entrpsMbVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기업 회원 목록
	 * </pre>
	 * 
	 * @date 2024. 01. 29.
	 * @author sein
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2024. 01. 29.
	 *          sein 최초작성 ------------------------------------------------
	 * @param entrpsMbVO
	 * @return
	 */
	List<MbEntrpsMbVO> selectEntrpsDrmncyManageList(MbEntrpsMbVO entrpsMbVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 휴면회원01 및 정회원02 으로 변경될 멤버 select
	 * </pre>
	 * 
	 * @date 2024. 01. 29.
	 * @author sein
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2024. 01. 29.
	 *          sein 최초작성 ------------------------------------------------
	 */
	List<MbEntrpsMbVO> selectMbDrmncyList(MbEntrpsMbVO entrpsMbVO) throws Exception;
	/**
	 * <pre>
	 * 처리내용: 휴면회원 MB_DRMNCY_MBER_BAS INSERT
	 * </pre>
	 * 
	 * @date 2024. 01. 29.
	 * @author sein
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2024. 01. 29.
	 *          sein 최초작성 ------------------------------------------------
	 */
	void insertMbDrmncyMberBas(MbEntrpsMbVO entrpsMbVO) throws Exception;
	/**
	 * <pre>
	 * 처리내용: MB_MBER_INFO_BAS 회원 상태 코드 05(휴면회원)로 업데이트
	 * </pre>
	 * 
	 * @date 2024. 01. 29.
	 * @author sein
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2024. 01. 29.
	 *          sein 최초작성 ------------------------------------------------
	 */
	void updateMberSttusDrmncy(MbEntrpsMbVO entrpsMbVO) throws Exception;
	/**
	 * <pre>
	 * 처리내용: MB_MBER_INFO_BAS 회원 상태 코드 이전 상태로 업데이트
	 * </pre>
	 * 
	 * @date 2024. 01. 29.
	 * @author sein
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2024. 01. 29.
	 *          sein 최초작성 ------------------------------------------------
	 */
	void updateMberSttusRgr(MbEntrpsMbVO entrpsMbVO) throws Exception;
	/**
	 * <pre>
	 * 처리내용: MB_MBER_INFO_BAS 회원 상태 코드 05로 업데이트 (history)
	 * </pre>
	 * 
	 * @date 2024. 01. 29.
	 * @author sein
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2024. 01. 29.
	 *          sein 최초작성 ------------------------------------------------
	 */
	void insertMbMberInfoBasHst(MbEntrpsMbVO entrpsMbVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 총 주문금액, 주문건수, voc 건수
	 * </pre>
	 * 
	 * @date 2021. 9. 9.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 9.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	MbEntrpsMbVO selectTotSlePc(String entrpsNo) throws Exception;



}
