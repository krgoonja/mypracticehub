package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.MbLonGrntyVO;

public interface MbLonGrntyMapper {

	List<MbLonGrntyVO> selectMbLonGrntyList(MbLonGrntyVO mbLonGrntyVO) throws Exception;

	int selectMbLonGrntyTotalCnt(MbLonGrntyVO mbLonGrntyVO) throws Exception;

}
