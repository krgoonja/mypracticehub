/**
 *
 */
package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.EntrpsMbInfoVO;
import com.sorincorp.bo.mb.model.MbEwalletVO;

/**
 * EntrpsDtlEwalletMapper.java
 * @version
 * @since 2021. 6. 9.
 * @author srec0009
 */
public interface MbEwalletMapper {
	/**
	 * <pre>
	 * 처리내용:  이월렛 목록 조회
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param ewalletVO
	 * @return
	 */
	List<MbEwalletVO> selectMbEwalletList(MbEwalletVO ewalletVO);
	/**
	 * <pre>
	 * 처리내용:  이월렛 목록 조회 페이징
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param ewalletVO
	 * @return
	 */
	int selectMbEwalletListTotCnt(MbEwalletVO ewalletVO);

	/**
	 * <pre>
	 * 처리내용:  이월렛 잔액 조회
	 * </pre>
	 * @date 2021. 7. 12.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 12.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mbEwalletVO
	 * @return
	 */
	String selectMbEwalletBlce(MbEwalletVO mbEwalletVO);
}
