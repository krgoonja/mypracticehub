package com.sorincorp.bo.mb.mapper;

import java.util.List;

import com.sorincorp.bo.mb.model.ApprovalReqMbCorpMgrVO;
import com.sorincorp.bo.mb.model.ApprovalReqOrCdtlnMgrVO;

/**
 * CorpInfoMapper.java
 *
 * @version
 * @since 2021. 5. 24.
 * @author srec0030 (김영웅)
 */
public interface ApprovalReqMbCorpMgrMapper {

	/**
	 * <pre>
	 * 승인업체 상세정보조회
	 * </pre>
	 *
	 * @date 2021. 5. 24.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param entrpsNo(업체번호)
	 * @return ApprovalReqMbCorpMgrVO )승인업체 상세정보)
	 * @throws Exception
	 */
	ApprovalReqMbCorpMgrVO selectCorpInfoDetail(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 승인업체 전체리스트 카운트 조회
	 * </pre>
	 *
	 * @date 2021. 5. 31.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param approvalReqMbCorpMgrVO
	 * @return int(승인업체 전체리스트 카운트)
	 */
	Integer selectCorpInfoTotalList(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO);

	/**
	 * <pre>
	 * 승인업체 리스트 조회
	 * </pre>
	 *
	 * @date 2021. 5. 25.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param corpInfoMgrVO
	 * @return List<ApprovalReqMbCorpMgrVO>(승인업체 리스트)
	 */
	List<ApprovalReqMbCorpMgrVO> selectCorpInfoList(ApprovalReqMbCorpMgrVO corpInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원 업체기본정보 수정
	 * </pre>
	 *
	 * @date 2021. 6. 2.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param approvalReqMbCorpMgrVO
	 * @return 수정결과값
	 */
	int updateMbEntrpsInfoBas(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원기본정보 수정
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param approvalReqMbCorpMgrVO
	 * @return 수정 결과값
	 * @throws Exception
	 */
	int updateMbMberInfoBas(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 승인상태코드 조회
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param approvalReqMbCorpMgrVO
	 * @return 승인상태코드
	 * @throws Exception
	 */
	String selectMberConfmSttusCodeOrg(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원업체등급리스트 조회
	 * </pre>
	 *
	 * @date 2021. 6. 8.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @return 회원업체등급리스트
	 * @throws Exception
	 */
	List<ApprovalReqMbCorpMgrVO> selectMbEntrpsGradStdrBasList() throws Exception;

	int insertApprovalReqMbCorpMgrAttachFile(ApprovalReqMbCorpMgrVO vo) throws Exception;

	List<ApprovalReqMbCorpMgrVO> selectAttachFileList(ApprovalReqMbCorpMgrVO vo) throws Exception;

	int deleteAttachFile(ApprovalReqMbCorpMgrVO vo) throws Exception;

	int insertMbEntrpsInfoBasHst(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	int insertMbMberInfoHist(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	int updateMbEntrpsCrtfcInfoDtl(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	int insertMbEntrpsCrtfcInfoDtlHst(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	int insertMbEntrpsAtchFileRelateHst(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	String getRefndAcnutSttusCode(String entrpsNo) throws Exception;

	String getRefndAcnutRgrsynthAt(String entrpsNo) throws Exception;

	String getEwalletAcnutNo() throws Exception;

	void updateOpEwalletAcnutBas(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	void insertOpEwalletAcnutDtl(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	void insertOpEwalletAcnutBasHst(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	void insertOpEwalletAcnutDtlHst(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	int insertMbEntrpsCrtfcInfoDtl(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	int selectCrtfcInfoCnt(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	void updateIfEwalletAcnutRegistRequst(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	String selectEwalletErrCd(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	String selectEwalletErrMsg(String errCd) throws Exception;

	String selectMemeberSecessionPossibleYn(String mberNo) throws Exception;

	int selectEwalletAcnutNoCnt(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	int updateRefndAcnutSttusCode(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	int updateOpEwalletAcnutDtl(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	List<ApprovalReqMbCorpMgrVO> selectMbEntrpsMetalAcctoAuthorSetupBas(String entrpsNo) throws Exception;

	int selectWrtmAuthorRate(String entrpsPurchsInclnGrad) throws Exception;

	int mergeMbEntrpsMetalAcctoAuthorSetupBas(ApprovalReqMbCorpMgrVO metalAuthVO) throws Exception;

	int insertMbEntrpsMetalAcctoAuthorSetupBasHst(ApprovalReqMbCorpMgrVO metalAuthVO) throws Exception;

	int updateMrtggGrntyFeeBndMbyAt(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	int insertMbEntrpsMrtggCntrctBasHst(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	List<ApprovalReqMbCorpMgrVO> selectLonGrntyBankUseAtList(String entrpsNo) throws Exception;

	int updateMbEntrpsLonGrntyBankInfoBas(ApprovalReqMbCorpMgrVO bankUseAtVO) throws Exception;

	int insertMbEntrpsLonGrntyBankInfoBasHst(ApprovalReqMbCorpMgrVO bankUseAtVO) throws Exception;

	// 케이지 크레딧
	int selectMrtggGrntySorinCreditCnt(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	int selectMaxEntrpsMrtggCntrctSn(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	int selectMaxEntrpsMrtggSn(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	int insertMrtggGrntySorinCredit(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	int insertMbEntrpsMrtggLmtDtl(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	int insertMbEntrpsMrtggLmtDtlHst(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	ApprovalReqOrCdtlnMgrVO selectOrCdtlnBas() throws Exception;

	int insertOrCdtlnEntrpsDtl(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	int insertOrCdtlnEntrpsDtlHst(ApprovalReqMbCorpMgrVO approvalReqMbCorpMgrVO) throws Exception;

	/**
	 * <pre>
	 * 평균가 LIVE 구매 등급 코드에 맞는 구매 비율 값 조회
	 * </pre>
	 * @date 2023. 8. 17.
	 * @author srec0051
	 * @param avrgpcLivePurchsGradCode
	 * @return
	 * @throws Exception
	double getAvrgpcPurchsRate(String avrgpcLivePurchsGradCode) throws Exception;
	 */

}
