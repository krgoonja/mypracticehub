package com.sorincorp.bo.mb.constant;

public class CdtlnSvcConstant {

	/** 전자상거래보증 진행 상태 코드 */
	public enum MRTGG_GRNTY_PROGRS_STTUS_CODE {
		/** 대기 00 */
		WAIT("00")
		/** 접수 10 */
		, RCEPT("10")
		/** 승인 20 */
		, CONFM("20")
		/** 발급 30 */
		, ISSU("30")
		/** 갱신 40 */
		, UPDT("40")
		/** 해지 50 */
		, TRMNAT("50")
		;

		private String code;
		private MRTGG_GRNTY_PROGRS_STTUS_CODE (String code) {
			this.code = code;
		}
		public String getCode() {
			return this.code;
		}
	}

	/** 전자상거래보증 조건 변경 상세 코드 */
	public enum MRTGG_CND_CHANGE_DETAIL_CODE {
		/** 계약 01 */
		CNTRCT("01")
		/** 증액 02 */
		, UPDT_IRSD("02")
		/** 감액 03 */
		, UPDT_RDCAMT("03")
		/** 기간변경 04 */
		, UPDT_PD("04")
		/** 만료 05 */
		, END("05")
		/** 해지 06 */
		, TRMNAT("06")
		;

		private String code;
		private MRTGG_CND_CHANGE_DETAIL_CODE (String code) {
			this.code = code;
		}
		public String getCode() {
			return this.code;
		}
	}

	/** 담보 거래 유형 코드 */
	public enum MRTGG_DELNG_TY_CODE {
		/** 계약 01 */
		CNTRCT("01")
		/** 주문 02 */
		, ORDER("02")
		/** 상환 03 */
		, REPY("03")
		/** 정산 04 */
		, EXCCLC("04")
		/** 만료 05 */
		, END("05")
		/** 갱신 06 */
		, UPDT("06")
		/** 해지 07 */
		, TRMNAT("07")
		;

		private String code;
		private MRTGG_DELNG_TY_CODE (String code) {
			this.code = code;
		}
		public String getCode() {
			return this.code;
		}
	}
}
