package com.sorincorp.bo.lo.service;

import java.util.ArrayList;
import java.util.List;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.lo.mapper.LgistCnterMapper;
import com.sorincorp.bo.lo.model.LgistCnterVO;

@Service
public class LgistCnterServiceImpl implements LgistCnterService {
	
	@Autowired
	LgistCnterMapper lgistCnterMapper;

	@Autowired
	private CommonService commonService;

	@Override
	public List<LgistCnterVO> selectLgistCnterList(LgistCnterVO lgistCnter) throws Exception {
		return lgistCnterMapper.selectLgistCnterList(lgistCnter);
	}

	@Override
	public int selectLgistCnterTotCnt(LgistCnterVO lgistCnter) throws Exception {
		return lgistCnterMapper.selectLgistCnterTotCnt(lgistCnter);
	}

	@Override
	public int updateLgistCnter(ArrayList<LgistCnterVO> lgistCnterList) throws Exception {
		LgistCnterVO vo = new LgistCnterVO();
		int result = 0;

		for(int i=0;i<lgistCnterList.size();i++) {
			vo = lgistCnterList.get(i);
			vo.setLastChangerId("test01");
			//lgistCnterMapper.insertLgistCnterHst(vo);		// 물류센터 정보 수정 전 이력 테이블에 저장
			commonService.insertTableHistory("LO_WRHOUS_INFO_BAS", vo);
			result = lgistCnterMapper.updateLgistCnter(vo);	// 물류센터 정보 수정
		}
		return result;
	}
}