package com.sorincorp.bo.lo.service;

import java.util.List;

import com.sorincorp.comm.common.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.lo.mapper.DlvyTariffMapper;
import com.sorincorp.bo.lo.model.DlvyTariffBasVO;

@Service
public class DlvyTariffServiceImpl implements DlvyTariffService {

	@Autowired
	private DlvyTariffMapper dlvyTariffMapper;

	@Autowired
	private CommonService commonService;

	@Override
	public int getDataCount(DlvyTariffBasVO dlvyTariffBasVO) throws Exception {
		return dlvyTariffMapper.getDataCount(dlvyTariffBasVO);
	}

	@Override
	public List<DlvyTariffBasVO> getDataList(DlvyTariffBasVO dlvyTariffBasVO) throws Exception {
		return dlvyTariffMapper.getDataList(dlvyTariffBasVO);
	}

	@Override
	public int insertLoDlvyTariffBas(DlvyTariffBasVO dlvyTariffBasVO) throws Exception {
		int result = 0;
		result = dlvyTariffMapper.mergeLoDlvyTariffBas(dlvyTariffBasVO);
		//dlvyTariffMapper.insertLoDlvyTariffBasHst(dlvyTariffBasVO);
		commonService.insertTableHistory("LO_DLVY_TARIFF_BAS", dlvyTariffBasVO);
		return result;
	}

	@Override
	public int checkKeyLoDlvyTariffBas(DlvyTariffBasVO dlvyTariffBasVO) throws Exception {
		return dlvyTariffMapper.checkKeyLoDlvyTariffBas(dlvyTariffBasVO);
	}

	@Override
	public int deleteLoDlvyTariffBas(DlvyTariffBasVO vo) throws Exception {
		int result = 0;
		result = dlvyTariffMapper.deleteLoDlvyTariffBas(vo);
		//dlvyTariffMapper.insertLoDlvyTariffBasHst(vo);
		commonService.insertTableHistory("LO_DLVY_TARIFF_BAS", vo);
		return result;
	}

}
