package com.sorincorp.bo.lo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.lo.mapper.InvntryCmpnspManageMapper;
import com.sorincorp.bo.lo.model.InvntryCmpnspManageVO;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * InvntryCmpnspManageServiceImpl.java
 * 물류관리 > 물류센타 관리 > 재고대사 관리 Service Class
 * 
 * @version
 * @since 2021. 9. 6.
 * @author srec0054
 */
@Slf4j
@Service
public class InvntryCmpnspManageServiceImpl implements InvntryCmpnspManageService{
	
	@Autowired
	private InvntryCmpnspManageMapper invntryCmpnspManageMapper;
	
	/**재고대사 관리 목록 카운트*/
	@Override
	public Integer searchInvntryCmpnspManageCount(InvntryCmpnspManageVO paramVo) throws Exception {
		log.debug("InvntryCmpnspManageServiceImpl::searchInvntryCmpnspManageCount 재고대사 관리 목록 카운트 Start");
		Integer resultCount = invntryCmpnspManageMapper.searchInvntryCmpnspManageCount(paramVo);
		log.debug("InvntryCmpnspManageServiceImpl::searchInvntryCmpnspManageCount 재고대사 관리 목록 카운트 End");
		return resultCount;
	}//end searchInvntryCmpnspManageCount()
	
	/**재고대사 관리 목록 조회*/
	@Override
	public List<InvntryCmpnspManageVO> searchInvntryCmpnspManage(InvntryCmpnspManageVO paramVo) throws Exception{
		log.debug("InvntryCmpnspManageServiceImpl::searchInvntryCmpnspManage 재고대사 관리 목록 조회 Start");
		List<InvntryCmpnspManageVO> invntryList = new ArrayList<InvntryCmpnspManageVO>();
		
		try {
			invntryList = invntryCmpnspManageMapper.searchInvntryCmpnspManage(paramVo);
		} catch (Exception e) {
			log.debug("InvntryCmpnspManageServiceImpl::searchInvntryCmpnspManage exception = " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		
		log.debug("InvntryCmpnspManageServiceImpl::searchInvntryCmpnspManage 재고대사 관리 목록 조회 End");
		return invntryList;
	}//end searchInvntryCmpnspManage()

	/**권역 중분류 코드 세팅*/
	@Override
	public List<InvntryCmpnspManageVO> getDstrctMlsfcCodeList(InvntryCmpnspManageVO paramVo) throws Exception {
		log.debug("InvntryCmpnspManageServiceImpl::getDstrctMlsfcCodeList 권역 소분류 코드 세팅 Start");
		List<InvntryCmpnspManageVO> cmpnspManageList = new ArrayList<InvntryCmpnspManageVO>();
		
		try {
			cmpnspManageList = invntryCmpnspManageMapper.getDstrctMlsfcCodeList(paramVo);
		} catch (Exception e) {
			log.debug("InvntryCmpnspManageServiceImpl::getDstrctMlsfcCodeList exception = " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		
		log.debug("InvntryCmpnspManageServiceImpl::getDstrctMlsfcCodeList 권역 소분류 코드 세팅 End");
		return cmpnspManageList;
	}//end getDstrctMlsfcCodeList()

	/**물류관리 > 물류센타 관리 > 재고대사 관리 > 권역/창고 : 창고 코드 세팅*/
	@Override
	public List<InvntryCmpnspManageVO> getWrhousCodeList(InvntryCmpnspManageVO paramVo) throws Exception {
		log.debug("InvntryCmpnspManageServiceImpl::getWrhousCodeList 창고 코드 세팅 Start");
		List<InvntryCmpnspManageVO> WrhousList = new ArrayList<InvntryCmpnspManageVO>();
		
		try {
			WrhousList = invntryCmpnspManageMapper.getWrhousCodeList(paramVo);
		} catch (Exception e) {
			log.debug("InvntryCmpnspManageServiceImpl::getWrhousCodeList exception = " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		
		log.debug("InvntryCmpnspManageServiceImpl::getWrhousCodeList 창고 코드 세팅 End");
		return WrhousList;
	}//end getWrhousCodeList()

	

}//end class()
