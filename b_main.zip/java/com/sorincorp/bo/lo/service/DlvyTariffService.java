package com.sorincorp.bo.lo.service;

import java.util.List;

import com.sorincorp.bo.lo.model.DlvyTariffBasVO;

public interface DlvyTariffService {

	/**
	 * <pre>
	 * 목록 총 카운트 조회
	 * </pre>
	 * @date 2022. 2. 21.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 21.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param dlvyTariffBasVO
	 * @return
	 * @throws Exception
	 */
	int getDataCount(DlvyTariffBasVO dlvyTariffBasVO) throws Exception;

	/**
	 * <pre>
	 * 목록 조회
	 * </pre>
	 * @date 2022. 2. 21.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 21.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param dlvyTariffBasVO
	 * @return
	 * @throws Exception
	 */
	List<DlvyTariffBasVO> getDataList(DlvyTariffBasVO dlvyTariffBasVO) throws Exception;

	/**
	 * <pre>
	 * 등록/저장
	 * </pre>
	 * @date 2022. 2. 21.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 21.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param dlvyTariffBasVO
	 * @return
	 * @throws Exception
	 */
	int insertLoDlvyTariffBas(DlvyTariffBasVO dlvyTariffBasVO) throws Exception;

	/**
	 * <pre>
	 * 등록전 키 조회
	 * </pre>
	 * @date 2022. 2. 21.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 21.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param dlvyTariffBasVO
	 * @return
	 * @throws Exception
	 */
	int checkKeyLoDlvyTariffBas(DlvyTariffBasVO dlvyTariffBasVO) throws Exception;

	/**
	 * <pre>
	 * 삭제
	 * </pre>
	 * @date 2022. 2. 21.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 21.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int deleteLoDlvyTariffBas(DlvyTariffBasVO vo) throws Exception;

}
