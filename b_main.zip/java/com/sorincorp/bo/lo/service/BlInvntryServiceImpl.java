package com.sorincorp.bo.lo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.lo.mapper.BlInvntryMapper;
import com.sorincorp.bo.lo.model.BlInvntryVO;

@Service
public class BlInvntryServiceImpl implements BlInvntryService {
	
	@Autowired
	BlInvntryMapper blInvntryMapper;	

	@Override
	public List<BlInvntryVO> selectBlInvntryList(BlInvntryVO blInvntry) throws Exception {
		return blInvntryMapper.selectBlInvntryList(blInvntry);
	}

	@Override
	public int selectBlInvntryTotCnt(BlInvntryVO blInvntry) throws Exception {
		return blInvntryMapper.selectBlInvntryTotCnt(blInvntry);
	}

	@Override
	public List<BlInvntryVO> selectBlInvntryInfo(BlInvntryVO blInvntry) throws Exception {
		return blInvntryMapper.selectBlInvntryInfo(blInvntry);
	}

	@Override
	public List<BlInvntryVO> selectBlInvntryHistDetailList(BlInvntryVO blInvntry) throws Exception {
		return blInvntryMapper.selectBlInvntryHistDetailList(blInvntry);
	}
}