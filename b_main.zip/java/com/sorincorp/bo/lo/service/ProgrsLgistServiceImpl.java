package com.sorincorp.bo.lo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.lo.mapper.ProgrsLgistMapper;
import com.sorincorp.bo.lo.model.ProgrsLgistVO;

@Service
public class ProgrsLgistServiceImpl implements ProgrsLgistService {
	
	@Autowired
	ProgrsLgistMapper progrsLgistMapper;	

	@Override
	public List<ProgrsLgistVO> selectProgrsLgistList(ProgrsLgistVO progrsLgist) throws Exception {
		return progrsLgistMapper.selectProgrsLgistList(progrsLgist);
	}

	@Override
	public int selectProgrsLgistTotCnt(ProgrsLgistVO progrsLgist) throws Exception {
		return progrsLgistMapper.selectProgrsLgistTotCnt(progrsLgist);
	}
}