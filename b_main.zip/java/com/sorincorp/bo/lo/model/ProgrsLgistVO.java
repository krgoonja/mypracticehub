package com.sorincorp.bo.lo.model;

import com.sorincorp.bo.op.model.DefaultVO;

import lombok.Data;

@Data
public class ProgrsLgistVO extends DefaultVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 조회조건
	 * */
	/**목록 조회 사용 용도 (조회, 엑셀다운로드)*/
	private String useMode;	
	/**
	 * 로우넘버
	 */
	private int rowNum;	
	/**
	 * 주문번호
	 */
	private String orderNo;
	/**
	 * 주문일자
	 */
	private String orderDe;
	/**
	 * 주문업체명
	 */
	private String orderEntrpsNm;
	/**
	 * 출고일자
	 */
	private String dlivyDe;
	/**
	 * 배송방식코드
	 */
	private String dlvyMnCode;
	/**
	 * 배송방식
	 */
	private String dlvyNm; 
	/**
	 * 메탈구분
	 */
	private String metalNm;
	/**
	 * 아이템명
	 */
	private String itmNm;
	/**
	 * 출고지
	 */
	private String dstrctLclasNm;
	/**
	 * 도착지
	 */
	private String orderEntrpsAdres;
	/**
	 * 배송상태
	 */
	private String dlvySttusCode; 	
	/** 
	 * 검색Keyword(시작일자) 
	 */
	private String startDate = "";
	/** 
	 * 검색Keyword(종료일자) 
	 */
	private String endDate = "";	
}
