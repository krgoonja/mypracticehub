package com.sorincorp.bo.lo.model;

import java.util.ArrayList;

import com.sorincorp.bo.op.model.DefaultVO;

import lombok.Data;

@Data
public class LgistCnterVO extends DefaultVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 로우넘버
	 */
	private int rowNum;	
	/**
	 * 창고 코드
	 */
	private String wrhousCode;
	/**
	 * 창고 명
	 */
	private String wrhousNm;
	/**
	 * 대분류 출고 권역 코드
	 */
	private String lclsfDlivyDstrctCode;
	/**
	 * 대분류 출고 권역
	 */
	private String lclsfDlivyDstrct;
	/**
	 * 중분류 출고 권역 코드
	 */
	private String mlsfcDlivyDstrctCode;
	/**
	 * 중분류 출고 권역
	 */
	private String mlsfcDlivyDstrct;
	/**
	 * 창고 우편 번호
	 */
	private String wrhousPostNo;
	/**
	 * 창고 도로명 주소
	 */
	private String wrhousRnAdres;
	/**
	 * 창고 도로명 주소 상세
	 */
	private String wrhousRnAdresDetail;
	/**
	 * 운영 업체 코드
	 */
	private String operEntrpsCode;
	/**
	 * 운영 업체 명
	 */
	private String operEntrpsNm;
	/**
	 * 창고 담당자
	 */
	private String wrhousCharger;
	/**
	 * 창고 담당자 전화 번호
	 */
	private String wrhousChargerTlphonNo;
	/**
	 * 창고 계약 형태 코드
	 */
	private String wrhousCntrctStleCode;
	/**
	 * EC 사용 여부
	 */
	private String ecUseAt;
	/**
	 * 삭제 일시
	 */
	private java.sql.Timestamp deleteDt;
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private java.sql.Timestamp frstRegistDt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	private java.sql.Timestamp lastChangeDt;
	/** 
	 * 비철 총 CAPA
	 **/
	private String nfTotCapa;
	/** 
	 * 비철 CAPA 사용 여부 
	**/
	private String nfCapaUseAt;
	
    private ArrayList<LgistCnterVO> lgistCnterList;	
}
