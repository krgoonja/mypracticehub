package com.sorincorp.bo.lo.model;

import com.sorincorp.bo.op.model.DefaultVO;

import lombok.Data;

@Data
public class InvntryCmpnspManageVO extends DefaultVO {

	private static final long serialVersionUID = -332878305408580927L;

	/**
	 * Search</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface Search {};
	
	/**
	 * 조회조건
	 * */
	/**목록 조회 사용 용도 (조회, 엑셀다운로드)*/
	private String useMode;
	
	/**권역 대분류 코드*/
	private String searchDstrctLclsfCode;

	/**권역 소분류 코드*/
	private String searchDstrctMlsfcCode;
	
	/**창고 코드*/
	private String searchWarehouse;
	
	/**BL NO*/
	private String searchBlNo;
	
	/**검색일*/
	private String searchDate;
	
	/**
	 * 그리드 항목
	 * */
	/**대사 일자*/
	private String mtblsmDe;
	
	/**BL 번호*/
	private String blNo;
	
	/**창고 코드*/
	private String wrhousCode;
	
	/**창고 명*/
	private String wrhousNm;
	
	/**중분류 출고 권역 명*/
	private String mlsfcDlivyDstrctCodeNm;
	
	/**중뷴류 출고 권역 코드*/
	private String mlsfcDlivyDstrctCode;
	
	/**삭제 여부*/
	private String deleteAt;
	
	/**삭제 일시*/
	private java.sql.Timestamp deleteDt;
	
	/**EC NET 중량*/
	private java.math.BigDecimal ecNetWt;
	
	/**EC GROSS 중량*/
	private java.math.BigDecimal ecGrossWt;
	
	/**EC 번들 수*/
	private int ecBundleCo;
	
	/**물류 NET 중량*/
	private java.math.BigDecimal lgistNetWt;
	
	/**물류 GROSS 중량*/
	private java.math.BigDecimal lgistGrossWt;
	
	/**물류 번들 수*/
	private int lgistBundleCo;
	
	/**검증 NET 중량*/
	private java.math.BigDecimal vrifyNetWt;
	
	/**검증 GROSS 중량*/
	private java.math.BigDecimal vrifyGrossWt;
	
	/**검증 번들 수*/
	private int vrifyBundleCo;
	
	/**최초 등록자 아이디*/
	private String frstRegisterId;
	
	/**최초 등록 일시*/
	private java.sql.Timestamp frstRegistDt;
	
	/**최종 변경자 아이디*/
	private String lastChangerId;
	
	/**최종 변경 일시*/
	private java.sql.Timestamp lastChangeDt;

	/**권역*/
	private String dlivyDstrctCode;
	
}//end class()
