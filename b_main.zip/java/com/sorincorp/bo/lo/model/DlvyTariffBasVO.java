package com.sorincorp.bo.lo.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class DlvyTariffBasVO extends CommonVO {

	private static final long serialVersionUID = -4581861621956465227L;

	/**
	 * Search</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface Search {};
	private String useMode; // 그리드 또는 그리드엑셀 모드 설정 ( useMode가 엑셀일 경우 excel, 그리드일경우 null)

	private String oneDstrctMlsfcCode;
	private String oneAreaCode;
	private String mode;

	/******  JAVA VO CREATE : LO_DLVY_TARIFF_BAS(물류_배송 요율 기본)                                                                        ******/
    /**
     * 권역 중분류 코드
    */
    private String dstrctMlsfcCode;
    private String dstrctMlsfcCodeNm;
    /**
     * 지역 코드
    */
    private String areaCode;
    /**
     * 지역 명
    */
    private String areaNm;
    /**
     * 우편 번호 시작
    */
    private String postNoBegin;
    /**
     * 우편 번호 끝
    */
    private String postNoEnd;
    /**
     * 차량 톤 코드
    */
    private String vhcleTonCode;
    private String vhcleTonCodeNm;
    /**
     * 배송 요율
    */
    private long dlvyTariff;
    /**
     * 서비스 구분 코드
    */
    private String svcSeCode;
    private String svcSeCodeNm;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
    /**
     * 당일 배송 여부
    */
    private String todayDlvyAt;
    /**
     * 당일 배송 요율
    */
    private long todayDlvyTariff;

}
