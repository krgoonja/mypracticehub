package com.sorincorp.bo.lo.mapper;

import java.util.List;

import com.sorincorp.bo.lo.model.InvntryCmpnspManageVO;

/**
 * 
 * InvntryCmpnspManageMapper.java
 * 물류관리 > 물류센타 관리 > 재고대사 관리 Mapper Interface
 * 
 * @version
 * @since 2021. 9. 6.
 * @author srec0054
 */
public interface InvntryCmpnspManageMapper {

	/**
	 * 
	 * <pre>
	 * 재고대사 관리 목록 카운트
	 * </pre>
	 * @date 2021. 9. 6.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 6.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	InvntryCmpnspManageVO paramVo
	 * @return	Integer
	 * @throws 	Exception
	 */
	Integer searchInvntryCmpnspManageCount(InvntryCmpnspManageVO paramVo);
	
	/**
	 * 
	 * <pre>
	 * 재고대사 관리 목록 조회
	 * </pre>
	 * @date 2021. 9. 6.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 6.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	InvntryCmpnspManageVO paramVo
	 * @return	List<InvntryCmpnspManageVO>
	 */
	List<InvntryCmpnspManageVO> searchInvntryCmpnspManage(InvntryCmpnspManageVO paramVo);
			
	/**
	 * 
	 * <pre>
	 * 권역 중분류 코드 세팅
	 * </pre>
	 * @date 2021. 9. 6.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 6.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	InvntryCmpnspManageVO paramVo
	 * @return	List<InvntryCmpnspManageVO>
	 */
	List<InvntryCmpnspManageVO> getDstrctMlsfcCodeList(InvntryCmpnspManageVO paramVo);
	
	/**
	 * 
	 * <pre>
	 * 창고 코드 세팅
	 * </pre>
	 * @date 2021. 9. 6.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 6.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	InvntryCmpnspManageVO paramVo
	 * @return	List<InvntryCmpnspManageVO>
	 * @throws 	Exception
	 */
	List<InvntryCmpnspManageVO> getWrhousCodeList(InvntryCmpnspManageVO paramVo);
	
}//end interface()
