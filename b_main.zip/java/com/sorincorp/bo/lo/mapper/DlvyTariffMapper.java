package com.sorincorp.bo.lo.mapper;

import java.util.List;

import com.sorincorp.bo.lo.model.DlvyTariffBasVO;

public interface DlvyTariffMapper {

	/**
	 * <pre>
	 *
	 * </pre>
	 * @date 2022. 2. 14.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 14.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param dlvyTariffBasVO
	 * @return
	 * @throws Exception
	 */
	public int getDataCount(DlvyTariffBasVO dlvyTariffBasVO) throws Exception;

	/**
	 * <pre>
	 *
	 * </pre>
	 * @date 2022. 2. 14.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 14.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param dlvyTariffBasVO
	 * @return
	 */
	public List<DlvyTariffBasVO> getDataList(DlvyTariffBasVO dlvyTariffBasVO) throws Exception;

	public int mergeLoDlvyTariffBas(DlvyTariffBasVO dlvyTariffBasVO) throws Exception;

	public int checkKeyLoDlvyTariffBas(DlvyTariffBasVO dlvyTariffBasVO) throws Exception;

	public int deleteLoDlvyTariffBas(DlvyTariffBasVO vo) throws Exception;

	public int insertLoDlvyTariffBasHst(DlvyTariffBasVO dlvyTariffBasVO) throws Exception;
}
