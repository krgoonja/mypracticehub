package com.sorincorp.bo.lo.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.lo.model.BlInvntryVO;

public interface BlInvntryMapper {
	
	/**
	 * <pre>
	 * 처리내용: BL별 재고 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param blInvntry
	 * @return
	 * @throws Exception
	 */
	List<BlInvntryVO> selectBlInvntryList(BlInvntryVO blInvntry) throws Exception;
	
	
	/**
	 * <pre>
	 * 처리내용: BL별 재고 총 건수를 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param blInvntry
	 * @return
	 * @throws Exception
	 */
	int selectBlInvntryTotCnt(BlInvntryVO blInvntry) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: BL 재고 정보를 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param blInvntry
	 * @return
	 * @throws Exception
	 */
	List<BlInvntryVO> selectBlInvntryInfo(BlInvntryVO blInvntry) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: BL 재고 이력 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param blInvntry
	 * @return
	 * @throws Exception
	 */
	List<BlInvntryVO> selectBlInvntryHistDetailList(BlInvntryVO blInvntry) throws Exception;	
}
