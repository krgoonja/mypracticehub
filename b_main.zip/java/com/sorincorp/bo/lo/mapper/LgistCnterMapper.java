package com.sorincorp.bo.lo.mapper;

import java.util.List;

import com.sorincorp.bo.lo.model.LgistCnterVO;

public interface LgistCnterMapper {
	
	/**
	 * <pre>
	 * 처리내용: 물류센터 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param lgistCnter
	 * @return
	 * @throws Exception
	 */
	List<LgistCnterVO> selectLgistCnterList(LgistCnterVO lgistCnter) throws Exception;
	
	
	/**
	 * <pre>
	 * 처리내용: 물류센터 총 건수를 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param lgistCnter
	 * @return
	 * @throws Exception
	 */
	int selectLgistCnterTotCnt(LgistCnterVO lgistCnter) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 물류센터 정보 수정 전 이력 테이블에 저장한다
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param lgistCnter
	 * @return
	 * @throws Exception
	 */	
	int insertLgistCnterHst(LgistCnterVO lgistCnter) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 물류센터 정보를 수정한다
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param lgistCnter
	 * @return
	 * @throws Exception
	 */
	int updateLgistCnter(LgistCnterVO lgistCnter) throws Exception;

}
