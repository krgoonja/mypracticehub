package com.sorincorp.bo.lo.mapper;

import java.util.List;

import com.sorincorp.bo.lo.model.ProgrsLgistVO;

public interface ProgrsLgistMapper {
	
	/**
	 * <pre>
	 * 처리내용: 진행물류 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param progrsLgist
	 * @return
	 * @throws Exception
	 */
	List<ProgrsLgistVO> selectProgrsLgistList(ProgrsLgistVO progrsLgist) throws Exception;
	
	
	/**
	 * <pre>
	 * 처리내용: 진행물류 총 건수를 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param progrsLgist
	 * @return
	 * @throws Exception
	 */
	int selectProgrsLgistTotCnt(ProgrsLgistVO progrsLgist) throws Exception;
	
}
