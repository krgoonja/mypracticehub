package com.sorincorp.bo.lo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.lo.model.LgistCnterVO;
import com.sorincorp.bo.lo.service.LgistCnterService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.comm.wrhouscode.service.WrhousCodeService;

import lombok.extern.slf4j.Slf4j;

/**
 * LgistCnterController.java
 * @version
 * @since 2021. 8. 17.
 * @author srec0050
 */
@Slf4j
@Controller
@RequestMapping("/bo/lgistCnter")
@ComponentScan({"com.sorincorp.comm.*"})
public class LgistCnterController {
	
	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired 
	private LgistCnterService lgistCnterService;	
	
	@Autowired 
	private WrhousCodeService wrhousCodeService;	
	
	
	@Autowired
	private CustomValidator customValidator;	
	
	/**
	 * <pre>
	 * 처리내용: 물류센터 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectLgistCnterList")
	public String selectLgistCnterList(ModelMap model) throws Exception {
		
		model.addAttribute("dstrctLclsfCodeList", commonCodeService.getSubCodes("DSTRCT_LCLSF_CODE"));
		model.addAttribute("dstrctMlsfcCodeList", commonCodeService.getSubCodes("DSTRCT_MLSFC_CODE"));
		
		return "lo/lgistCnterList";
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 물류센터 목록 데이터를 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param lgistCnter
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectLgistCnterListData")
	@ResponseBody
	public Map<String, Object> selectLgistCnterListData(@RequestBody LgistCnterVO lgistCnter) throws Exception {
		
		try {
			
			Map<String, Object> map = new HashMap<String, Object>();
			
			int totalDataCount = lgistCnterService.selectLgistCnterTotCnt(lgistCnter);
			List<LgistCnterVO> dataList = lgistCnterService.selectLgistCnterList(lgistCnter);
			map.put("totalDataCount", totalDataCount);
			map.put("dataList", dataList);
			
			return map;
			
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e); //<---- BO의 경우는 에러로그를 화면에 찍어야 하여 추가됩니다.
//			return "error/503";
			return null;
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 물류센터 데이터를 수정한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param lgistCnter
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/updateLgistCnter")
	@ResponseBody
	public ResponseEntity<?> updateBrandMgr(@RequestBody LgistCnterVO lgistCnter, Model model) throws Exception {

		int result = 0;

		log.debug(lgistCnter.toString());
		result = lgistCnterService.updateLgistCnter(lgistCnter.getLgistCnterList());	//물류센터 정보 update

		Map<String, Object> retVal = new HashMap<String, Object>();

		if (result > 0) {
			retVal.put("code", "S");
			wrhousCodeService.initWrhousCode();
		} else {
			retVal.put("code", "F");
		}
		
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}	

}
