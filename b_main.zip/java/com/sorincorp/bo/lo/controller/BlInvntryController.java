package com.sorincorp.bo.lo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.lo.model.BlInvntryVO;
import com.sorincorp.bo.lo.service.BlInvntryService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.comm.wrhouscode.model.WrhousCodeVO;
import com.sorincorp.comm.wrhouscode.service.WrhousCodeService;

import lombok.extern.slf4j.Slf4j;

/**
 * ProgrsLgistController.java
 * @version
 * @since 2021. 8. 17.
 * @author srec0050
 */
@Slf4j
@Controller
@RequestMapping("/bo/blInvntry")
@ComponentScan({"com.sorincorp.comm.*"})
public class BlInvntryController {
	
	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired
	private ItemCodeService itemCodeService;
	
	@Autowired
	private WrhousCodeService wrhousCodeService;	
	
	@Autowired 
	private BlInvntryService blInvntryService;	
	
	/**
	 * <pre>
	 * 처리내용: BL별 재고 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectBlInvntryList")
	public String selectBlInvntryList(ModelMap model) throws Exception {
		//아이템 리스트
		List<ItemCodeVO> itemCodeList = itemCodeService.getItemCodeList("");

		//물류센터 리스트 조회
		List<WrhousCodeVO> wrhousCodeList = wrhousCodeService.getWrhousCode();
		
		model.addAttribute("metalCodeList", commonCodeService.getSubCodes("METAL_CODE"));
		model.addAttribute("dstrctLclsfCodeList", commonCodeService.getSubCodes("DSTRCT_LCLSF_CODE"));
		model.addAttribute("dstrctMlsfcCodeList", commonCodeService.getSubCodes("DSTRCT_MLSFC_CODE"));
		model.addAttribute("brandGroupCodeList", commonCodeService.getSubCodes("BRAND_GROUP_CODE"));
		model.addAttribute("brandCodeList", commonCodeService.getSubCodes("BRAND_CODE"));

		model.addAttribute("itemCodeList", itemCodeList);
		model.addAttribute("wrhousCodeList", wrhousCodeList);
		
		
		return "lo/blInvntryList";
	}
	
	/**
	 * <pre>
	 * 처리내용: BL별 재고 목록 데이터를 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param blInvntry
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectBlInvntryListData")
	@ResponseBody
	public Map<String, Object> selectBlInvntryListData(@RequestBody BlInvntryVO blInvntry) throws Exception {
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		int totalDataCount = blInvntryService.selectBlInvntryTotCnt(blInvntry);
		List<BlInvntryVO> dataList = blInvntryService.selectBlInvntryList(blInvntry);
		
		map.put("totalDataCount", totalDataCount);
		map.put("dataList", dataList);
		
		return map;
	}
	
	@RequestMapping("/dstrctWrhousCodeList")
	@ResponseBody
	public ResponseEntity<?> onlineSalesStockMgrGetCodeList(@RequestParam(value = "dstrctLclsfCode") String dstrctLclsfCode, @RequestParam(value = "dstrctMlsfcCode") String dstrctMlsfcCode) throws Exception {

		Map<String, Object> map = new HashMap<String, Object>();

		map.put("dstrctMlsfcCodeList", commonCodeService.getFilterCode("DSTRCT_MLSFC_CODE",null,"CODE_REFRNONE",dstrctLclsfCode));
		
		if(StringUtil.isEmpty(dstrctLclsfCode)) {
			map.put("wrhousCodeList", wrhousCodeService.getWrhousCode());
		} else {
			map.put("wrhousCodeList", wrhousCodeService.getDetailWrhousCode(dstrctLclsfCode, dstrctMlsfcCode));
		}
			

		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: BL별 재고 상세 이력 목록 데이터를 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param mssage
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/blInvntryDetail")
	public String popUpModal(@RequestBody BlInvntryVO blInvntry, ModelMap model) throws Exception {
		model.put("blNo", blInvntry.getBlNo());
		return "lo/blInvntryDetail.modal";
	}
	
	/**
	 * <pre>
	 * 처리내용: BL 재고 정보 데이터를 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param blInvntry
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectBlInvntryInfoData")
	@ResponseBody
	public Map<String, Object> selectBlInvntryInfoData(@RequestBody BlInvntryVO blInvntry) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		List<BlInvntryVO> dataList = blInvntryService.selectBlInvntryInfo(blInvntry);
		map.put("dataList", dataList);
		return map;
	}	
	
	/**
	 * <pre>
	 * 처리내용: BL 재고 이력 목록 데이터를 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param blInvntry
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectBlInvntryHistDetailListData")
	@ResponseBody
	public Map<String, Object> selectBlInvntryHistDetailListData(@RequestBody BlInvntryVO blInvntry) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		List<BlInvntryVO> dataList = blInvntryService.selectBlInvntryHistDetailList(blInvntry);
		map.put("dataList", dataList);
		return map;
	}	
}