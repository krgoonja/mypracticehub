package com.sorincorp.bo.lo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.lo.model.DlvyTariffBasVO;
import com.sorincorp.bo.lo.service.DlvyTariffService;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 상품/전시관리 > 상품관리 > 선물환 API 관리
 * FtrsApiMgrController.java
 * @version
 * @since 2022. 1. 25.
 * @author srec0051
 */
@Slf4j
@Controller
@RequestMapping("/bo/lo/dlvyTariff")
public class DlvyTariffController {

	@Autowired
	private UserInfoUtil userInfoUtil;
	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private DlvyTariffService dlvyTariffService;


	private Account getAccountInfo() throws Exception {
		Account account = Optional.ofNullable(userInfoUtil.getAccountInfo()).orElseThrow(() -> {
			return new Exception("로그인 정보를 확인해주세요");
		});
		return account;
	}

	/**
	 * <pre>
	 * 배송요율관리 페이지
	 * </pre>
	 * @date 2022. 2. 14.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 14.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectDlvyTariffManage")
	public String selectDlvyTariffManage(DlvyTariffBasVO dlvyTariffBasVO, ModelMap model) throws Exception {
		log.debug("::: selectDlvyTariffManage ");

		try {
			getAccountInfo();

			// 1. 권역 중분류 코드
			Map<String, String> dstrctMlsfcCodeList = commonCodeService.getSubCodes("DSTRCT_MLSFC_CODE");
			log.debug(">> dstrctMlsfcCodeList : " + dstrctMlsfcCodeList.toString());
			// 2. 서비스 구분 코드
			Map<String, String> svcSeCodeList = commonCodeService.getSubCodes("SVC_SE_CODE");
			log.debug(">> svcSeCodeList : " + svcSeCodeList.toString());
			// 3. 차량 톤
			Map<String, String> vhcleTonCodeList = commonCodeService.getSubCodes("VHCLE_TON_CODE");
			log.debug(">> vhcleTonCodeList : " + vhcleTonCodeList.toString());


			model.put("dstrctMlsfcCodeList", dstrctMlsfcCodeList);
			model.put("svcSeCodeList", svcSeCodeList);
			model.put("vhcleTonCodeList", vhcleTonCodeList);

			return "lo/dlvyTariffManage";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 배송요율관리 페이지 목록
	 * </pre>
	 * @date 2022. 2. 14.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 14.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param lqdIntDatResVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/getDlvyTariffMgrListAjax")
	public ResponseEntity<?> getDlvyTariffMgrListAjax(@RequestBody DlvyTariffBasVO dlvyTariffBasVO) throws Exception {
		log.debug("::: getDlvyTariffMgrListAjax");
		log.debug("::: param : "+ dlvyTariffBasVO.toString());

		Map<String, Object> map = new HashMap<String, Object>();

		int totalDataCount = dlvyTariffService.getDataCount(dlvyTariffBasVO);
		List<DlvyTariffBasVO> dataList = dlvyTariffService.getDataList(dlvyTariffBasVO);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", dataList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@RequestMapping("/registDlvyTariff")
	public ResponseEntity<?> registDlvyTariff(@RequestBody DlvyTariffBasVO dlvyTariffBasVO) throws Exception {
		log.debug("::: registDlvyTariff param : "+ dlvyTariffBasVO.toString());

		Map<String, Object> map = new HashMap<String, Object>();
		Account account = getAccountInfo();
		dlvyTariffBasVO.setFrstRegisterId(account.getId());
		dlvyTariffBasVO.setLastChangerId(account.getId());
		int result = 0;

		// 등록이라면 유니크 키 검증
//		if (StringUtils.isBlank(dlvyTariffBasVO.getOneDstrctMlsfcCode())) {
//			result = dlvyTariffService.checkKeyLoDlvyTariffBas(dlvyTariffBasVO);
//			if (result > 0) {
//				
//				map.put("result", -1);
//				log.error("이미 존재하는 코드 - 권역중분류코드 : {}, 지역코드 : {}", dlvyTariffBasVO.getDstrctMlsfcCode(), dlvyTariffBasVO.getAreaCode());
//				return new ResponseEntity<>(map, HttpStatus.OK);
//			}
//		}

		result = dlvyTariffService.insertLoDlvyTariffBas(dlvyTariffBasVO);
		map.put("result", result);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@RequestMapping("/removeDlvyTariff")
	public ResponseEntity<?> removeDlvyTariff(@RequestBody List<DlvyTariffBasVO> dlvyTariffBasVoList) throws Exception {
		log.debug("::: removeDlvyTariff param size : "+ dlvyTariffBasVoList.size());

		Map<String, Object> map = new HashMap<String, Object>();
		Account account = getAccountInfo();
		int result = 0;

		if (CollectionUtils.isEmpty(dlvyTariffBasVoList)) {
			map.put("result", -1);
			log.error("삭제할 데이터 미존재");
			return new ResponseEntity<>(map, HttpStatus.OK);
		}

		for (DlvyTariffBasVO vo : dlvyTariffBasVoList) {
			log.debug(vo.toString());
			vo.setFrstRegisterId(account.getId());
			vo.setLastChangerId(account.getId());
			result += dlvyTariffService.deleteLoDlvyTariffBas(vo);
		}

		map.put("result", result);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
}
