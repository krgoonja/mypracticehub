package com.sorincorp.bo.lo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.lo.model.ProgrsLgistVO;
import com.sorincorp.bo.lo.service.ProgrsLgistService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * ProgrsLgistController.java
 * @version
 * @since 2021. 8. 17.
 * @author srec0050
 */
@Slf4j
@Controller
@RequestMapping("/bo/progrsLgist")
@ComponentScan({"com.sorincorp.comm.*"})
public class ProgrsLgistController {
	
	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired 
	private ProgrsLgistService progrsLgistService;	
	
	@Autowired
	private CustomValidator customValidator;	
	
	/**
	 * <pre>
	 * 처리내용: 진행물류 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectProgrsLgistList")
	public String selectProgrsLgistList(ModelMap model) throws Exception {
		
		model.addAttribute("dlvyMnCode", commonCodeService.getSubCodes("DLVY_MN_CODE"));
		return "lo/progrsLgistList";

	}
	
	
	/**
	 * <pre>
	 * 처리내용: 진행물류 목록 데이터를 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0050
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0050			최초작성
	 * ------------------------------------------------
	 * @param lgistCnter
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectProgrsLgistListData")
	@ResponseBody
	public Map<String, Object> selectProgrsLgistListData(@RequestBody ProgrsLgistVO progrsLgist) throws Exception {
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		int totalDataCount = progrsLgistService.selectProgrsLgistTotCnt(progrsLgist);
		List<ProgrsLgistVO> dataList = progrsLgistService.selectProgrsLgistList(progrsLgist);
		
//		commonCodeService.getMainCodes();
		
		map.put("totalDataCount", totalDataCount);
		map.put("dataList", dataList);
		
		return map;
	}
	
}
