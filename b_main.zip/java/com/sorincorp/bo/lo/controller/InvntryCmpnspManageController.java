package com.sorincorp.bo.lo.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.lo.model.InvntryCmpnspManageVO;
import com.sorincorp.bo.lo.service.InvntryCmpnspManageService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * InvntryCmpnspManageController.java
 * 물류관리 > 물류센타 관리 > 재고대사 관리 Controller Class
 * 
 * @version
 * @since 2021. 9. 6.
 * @author srec0054
 */
@Slf4j
@Controller
@RequestMapping("/bo/InvntryCmpnspManage")
@ComponentScan(basePackages = {"com.sorincorp.comm.*.service"})
public class InvntryCmpnspManageController {

	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired
	private InvntryCmpnspManageService invntryCmpnspManageService;
	
	private static final String GRID = "grid"; //그리드 목록 조회 사용 용도 (조회, 엑셀다운로드)
	
	/**
	 * 
	 * <pre>
	 * 물류관리 > 물류센타 관리 > 재고대사 관리 : 페이지 로드
	 * </pre>
	 * @date 2021. 9. 6.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 6.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	ModelMap model
	 * @return	String
	 * @throws 	Exception
	 */
	@RequestMapping("/viewListInvntryCmpnspManage")
	public String viewListInvntryCmpnspManage(ModelMap model) {	
		
		try {
			Map<String, String> dstrctLclsfCode = commonCodeService.getSubCodes("DSTRCT_LCLSF_CODE");
			
			model.put("dstrctLclsfCode"	, dstrctLclsfCode); 	// 권역 대분류 코드
			
			return "lo/invntryCmpnspManage";
		} catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
		
	}//end viewListInvntryCmpnspManage()
	
	/**
	 * 
	 * <pre>
	 * 물류관리 > 물류센타 관리 > 재고대사 관리 : 목록 조회
	 * </pre>
	 * @date 2021. 9. 6.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 6.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	InvntryCmpnspManageVO paramVo
	 * @param 	BindingResult bindingResult
	 * @return
	 * @throws 	Exception
	 */
	@ResponseBody
	@PostMapping("/searchInvntryCmpnspManage")
	public ResponseEntity<?> searchInvntryCmpnspManage(@RequestBody InvntryCmpnspManageVO paramVo, BindingResult bindingResult) throws Exception {
		log.debug("InvntryCmpnspManageController::searchInvntryCmpnspManage 물류관리 > 물류센타 관리 > 재고대사 관리 : 목록 조회 Start");
		log.debug("InvntryCmpnspManageVO = " + paramVo.toString());

		Map<String, Object> map = new HashMap<String, Object>();
		
		//그리드 목록 조회 사용 용도 (조회, 엑셀다운로드)
		String useMode = paramVo.getUseMode();
		
		if(useMode.equals(GRID)) {
			//재고대사 관리 목록 갯수 조회
			Integer totalDataCount = invntryCmpnspManageService.searchInvntryCmpnspManageCount(paramVo);
			map.put("totalDataCount", totalDataCount);
		}
		
		//재고대사 관리 목록 조회
		List<InvntryCmpnspManageVO> invntryList = invntryCmpnspManageService.searchInvntryCmpnspManage(paramVo);
		map.put("dataList", invntryList);
				
		log.debug("InvntryCmpnspManageController::searchInvntryCmpnspManage 물류관리 > 물류센타 관리 > 재고대사 관리 : 목록 조회 End");
		return new ResponseEntity<>(map, HttpStatus.OK);
	}//end searchInvntryCmpnspManage()
	
	
	/**
	 * 
	 * <pre>
	 * 물류관리 > 물류센타 관리 > 재고대사 관리 > 권역/창고 : 권역 중분류 코드 세팅
	 * </pre>
	 * @date 2021. 9. 6.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 6.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	Map<String, String> codeSearchVo
	 * @return	Map<String, Object>
	 */
	@PostMapping("/getDstrctMlsfcCodeList")
	@ResponseBody
	public Map<String, Object> getDstrctMlsfcCodeList(@RequestBody Map<String, String> codeSearchVo) throws Exception{
		log.debug("InvntryCmpnspManageController::getDstrctMlsfcCodeList 물류관리 > 물류센타 관리 > 재고대사 관리 > 권역/창고 : 권역 중분류 코드 세팅 Start");
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		InvntryCmpnspManageVO paramVo 			= new InvntryCmpnspManageVO();
		List<CommonCodeVO> dstrctMlsfcCodeList 	= new ArrayList<CommonCodeVO>();
		
		//권역 대분류 코드
		String dstrctLclsfCode = codeSearchVo.get("dstrctLclsfCode");
		paramVo.setSearchDstrctLclsfCode(dstrctLclsfCode);
		
		List<InvntryCmpnspManageVO> commCdList = invntryCmpnspManageService.getDstrctMlsfcCodeList(paramVo);
		
		for(int a = 0 ; a < commCdList.size() ; a++) {
			CommonCodeVO codeVo = new CommonCodeVO();
			codeVo.setCodeNm(commCdList.get(a).getMlsfcDlivyDstrctCodeNm());	//중분류 출고 권역 명
			codeVo.setSubCode(commCdList.get(a).getMlsfcDlivyDstrctCode());		//중분류 출고 권역 코드
			dstrctMlsfcCodeList.add(codeVo);
		}//end for()
			
		returnMap.put("dstrctMlsfcCodeList", dstrctMlsfcCodeList);

		log.debug("InvntryCmpnspManageController::getDstrctMlsfcCodeList 물류관리 > 물류센타 관리 > 재고대사 관리 > 권역/창고 : 권역 중분류 코드 세팅 End");
		return returnMap;
	}//end getDstrctMlsfcCodeList()
	
	
	/**
	 * 
	 * <pre>
	 * 물류관리 > 물류센타 관리 > 재고대사 관리 > 권역/창고 : 창고 코드 세팅
	 * </pre>
	 * @date 2021. 9. 6.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 6.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	Map<String, String> codeSearchVo
	 * @return	Map<String, Object>
	 */
	@PostMapping("/getWrhousCodeList")
	@ResponseBody
	public Map<String, Object> getWrhousCodeList(@RequestBody Map<String, String> codeSearchVo) throws Exception{
		log.debug("InvntryCmpnspManageController::getWrhousCodeList 물류관리 > 물류센타 관리 > 재고대사 관리 > 권역/창고 : 창고 코드 세팅 Start");
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		InvntryCmpnspManageVO paramVo 			= new InvntryCmpnspManageVO();
		List<CommonCodeVO> wrhousCodeList 		= new ArrayList<CommonCodeVO>();
		
		String dstrctLclsfCode = codeSearchVo.get("dstrctLclsfCode");	//권역 대분류 코드
		String dstrctMlsfcCode = codeSearchVo.get("dstrctMlsfcCode");	//권역 중뷴류 코드
		
		paramVo.setSearchDstrctLclsfCode(dstrctLclsfCode);
		paramVo.setSearchDstrctMlsfcCode(dstrctMlsfcCode);
		
		List<InvntryCmpnspManageVO> commCdList = invntryCmpnspManageService.getWrhousCodeList(paramVo);
		
		for(int a = 0 ; a < commCdList.size() ; a++) {
			CommonCodeVO codeVo = new CommonCodeVO();
			codeVo.setSubCode(commCdList.get(a).getWrhousCode());		//창고 코드
			codeVo.setCodeNm(commCdList.get(a).getWrhousNm());			//창고 명
			wrhousCodeList.add(codeVo);
		}
		
		returnMap.put("wrhousCodeList", wrhousCodeList);

		log.debug("InvntryCmpnspManageController::getWrhousCodeList 물류관리 > 물류센타 관리 > 재고대사 관리 > 권역/창고 : 창고 코드 세팅 End");
		return returnMap;
	}//end getWrhousCodeList()
	
}//end class()
