package com.sorincorp.bo.chart.mapper;

import java.util.List;

import com.sorincorp.bo.chart.model.FixPreminumVO;
import com.sorincorp.bo.chart.model.HeaderMenuVO;
import com.sorincorp.bo.chart.model.ItHghnetprcPurchsPrmpcDtlVO;
import com.sorincorp.bo.chart.model.MainPriceListVO;
import com.sorincorp.bo.chart.model.PcChartMntrngSelVO;
import com.sorincorp.bo.chart.model.PrLmePblntfPcBasVO;
import com.sorincorp.bo.chart.model.PrMetalDisplayVO;
import com.sorincorp.bo.chart.model.PreminumInfoDto;
import com.sorincorp.bo.chart.model.PreminumSelVO;
import com.sorincorp.bo.chart.model.SelMetalVO;


public interface PcChartMntrngMapper {


	/**
	 * <pre>
	 * 1분 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcChartMntrngSelVO> getPcMngtrngSel1MinList(PcChartMntrngSelVO pcMntrngSelVO);
	
	/**
	 * <pre>
	 * 30분 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	/**
	 * <pre>
	 * 30분 단위 판매 가격 리스트
	 * </pre>
	 * @date 2021. 11. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcChartMntrngSelVO> getPcMngtrngSel30MinList(PcChartMntrngSelVO pcMntrngSelVO);
	
	/**
	 * <pre>
	 * 60분 단위 판매가격 리스트
	 * </pre>
	 * @date 2021. 11. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcChartMntrngSelVO> getPcMngtrngSel60MinList(PcChartMntrngSelVO pcMntrngSelVO);
	
	/**
	 * <pre>
	 * 반기 기준 판매가격 리스트
	 * </pre>
	 * @date 2021. 11. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcChartMntrngSelVO> getPcMngtrngSelHalfYearList(PcChartMntrngSelVO pcMntrngSelVO);
	
	/**
	 * <pre>
	 * 기준 프리미엄 가격 데이터
	 * </pre>
	 * @date 2021. 11. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @return
	 */
	PreminumSelVO getPremiumPriceData(String metalCode);
	
	/**
	 * <pre>
	 * 기준 프리미엄 가격 데이터 함수 호출
	 * </pre>
	 * @date 2021. 11. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param preminumInfoDto
	 * @return
	 */
	PreminumSelVO getFnPremiumInfo(PreminumInfoDto preminumInfoDto);
	
	/**
	 * <pre>
	 * 프리미엄 가격 리스트
	 * </pre>
	 * @date 2021. 11. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param preminumInfoDto
	 * @return
	 */
	List<PreminumSelVO> getFnPremiumInfoList(PreminumInfoDto preminumInfoDto);
	
	/**
	 * <pre>
	 * 고정가, 실시간가 프리미엄 가격 리스트 조회
	 * </pre>
	 * @date 2022. 3. 18.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 3. 18.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param preminumInfoDto
	 * @return
	 */
	List<PreminumSelVO> getFnPreminumInfoList2(PreminumInfoDto preminumInfoDto);
	
	/**
	 * <pre>
	 * LME 대비가격 리스트
	 * </pre>
	 * @date 2021. 11. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param prLmePblntfPcBasVO
	 * @return
	 */
	PrLmePblntfPcBasVO getPrLmePblntfPc(PrLmePblntfPcBasVO prLmePblntfPcBasVO);
	
	
	/**
	 * <pre>
	 * 판매방식에 따른 금속명을 가져온다
	 * </pre>
	 * @date 2022. 3. 14.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 3. 14.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param prMetalDisplayVo
	 * @return
	 */
	PrMetalDisplayVO selectMetalDisplay(PrMetalDisplayVO prMetalDisplayVo);
	
	/**
	 * <pre>
	 * 판매중인 금속 정보를 불러온다.
	 * </pre>
	 * @date 2022. 3. 18.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 3. 18.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 */
	List<SelMetalVO> selectSelMetalList(String metalCode, String sleMthdCode);
	
	/**
	 * <pre>
	 * 일 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 26.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcChartMntrngSelVO> getPcMngtrngSelDeList(PcChartMntrngSelVO pcMntrngSelVO);
	
	/**
	 * <pre>
	 * 일 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 26.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcChartMntrngSelVO> getPcMngtrngSelMonthList(PcChartMntrngSelVO pcMntrngSelVO);

	/**
	 * <pre>
	 * 하위메뉴로 금속메뉴를 가지는 비금속 메뉴를 가져온다.
	 * </pre>
	 * @date 2023.01.10
	 * @author srec0068
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			     작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 01. 10.	 srec0068		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param
	 * @return
	 */
	List<HeaderMenuVO> getUpperMenuList();

}
