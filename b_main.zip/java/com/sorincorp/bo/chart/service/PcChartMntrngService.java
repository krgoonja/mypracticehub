package com.sorincorp.bo.chart.service;

import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;

import com.sorincorp.bo.chart.model.ItHghnetprcPurchsPrmpcDtlVO;
import com.sorincorp.bo.chart.model.MainPriceListVO;
import com.sorincorp.bo.chart.model.PcChartMntrngSelVO;
import com.sorincorp.comm.bsnInfo.model.RestTermVO;

public interface PcChartMntrngService {


	/**
	 * <pre>
	 * 메인 페이지의 차트 데시보드 정보를 가져온다.
	 * </pre>
	 * @date 2021. 9. 13.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 13.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> getMainChartData() throws Exception;
	
	/**
	 * <pre>
	 * 금속 코드에 해당되는 차트 데시보드 정보를 가져온다.
	 * </pre>
	 * @date 2021. 11. 9.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 9.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> getItemChartDate(String metalCode, String sleMthdCode) throws Exception;
	
	/**
	 * <pre>
	 * 1분 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcChartMntrngSelVO> getPcMngtrngSel1MinList(PcChartMntrngSelVO pcMntrngSelVO) throws Exception;
	
	/**
	 * <pre>
	 * 30분 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcChartMntrngSelVO> getPcMngtrngSel30MinList(PcChartMntrngSelVO pcMntrngSelVO) throws Exception;
	
	/**
	 * <pre>
	 * 60분 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 24.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 * @throws Exception
	 */
	List<PcChartMntrngSelVO> getPcMngtrngSel60MinList(PcChartMntrngSelVO pcMntrngSelVO) throws Exception;
	
	/**
	 * <pre>
	 * 일 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 26.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcChartMntrngSelVO> getPcMngtrngSelDeList(PcChartMntrngSelVO pcMntrngSelVO) throws Exception;
	
	/**
	 * <pre>
	 * 월 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 24.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 * @throws Exception
	 */
	List<PcChartMntrngSelVO> getPcMngtrngSelMonthList(PcChartMntrngSelVO pcMntrngSelVO) throws Exception;
	
	/**
	 * <pre>
	 * 30분 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcChartMntrngSelVO> getPcMngtrngSelHalfYearList(PcChartMntrngSelVO pcMntrngSelVO) throws Exception;
		
	/**
	 * <pre>
	 * 영업시간 계산 웹소캣 스캐줄러
	 * </pre>
	 * @date 2021. 12. 10.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 10.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	List<Map<String, Object>> selectRestDtTimeSet();
	
	/**
	 * <pre>
	 * 처리내용: 헤더 - 휴일, 실시간 고정가 영업 여부 
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public List<RestTermVO> headerRestInfo();

	/**
	 * <pre>
	 * 처리내용: 3분마다 조회 헤더 타이머 - 시간을 조회한다.
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public Map<String, Object> restDtTimeSetSchdule();
	
	/**
	 * <pre>
	 * 휴일 정보 리스트를 JSONArray 형태로 가져온다
	 * </pre>
	 * @date 2022. 4. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 4. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	JSONArray getRestdeInfoJson() throws Exception;
}
