package com.sorincorp.bo.chart.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.codehaus.plexus.util.ExceptionUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.chart.mapper.PcChartMntrngMapper;
import com.sorincorp.bo.chart.model.MainPriceListVO;
import com.sorincorp.bo.chart.model.PcChartMntrngSelVO;
import com.sorincorp.bo.chart.model.PrLmePblntfPcBasVO;
import com.sorincorp.bo.chart.model.PrMetalDisplayVO;
import com.sorincorp.bo.chart.model.SelMetalVO;
import com.sorincorp.comm.bsnInfo.model.RestTermVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.pcInfo.model.PrEhgtRltmVO;
import com.sorincorp.comm.pcInfo.model.PrPremiumSelVO;
import com.sorincorp.comm.pcInfo.model.PreminumSelInfoVO;
import com.sorincorp.comm.pcInfo.model.RvcmpnVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PcChartMntrngServiceImpl implements PcChartMntrngService {

	@Autowired
	private PcChartMntrngMapper pcChartMntrngMapper;

	@Autowired
	private PcInfoService pcInfoService;

	@Autowired
	private ItemCodeService itemCodeService;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private BsnInfoService bsnInfoService;

	// 종목코드 (삼성선물)
	private final Map<String, String> GIC_NAME = new HashMap<String, String>() {
		{
			// LME 시세 조회시 금속코드마다 지정해 줄것.
			put("7", "LALM03");
		}
	};

	// 고정가 상수
	private final Map<String, Map<String, Object>> FIX_ITEM = new HashMap<String, Map<String, Object>>() {
		{
			Map<String, Object> fixProperty = new HashMap<String, Object>();
			fixProperty.put("dstrctLclsfCode", "10");
			fixProperty.put("brandGroupCode", "31");
			fixProperty.put("itmSn", 471);
			put("1", fixProperty);
		}
	};

	@Override
	public Map<String, Object> getMainChartData() throws Exception {
		return mainChartData(null, null);
	}

	@Override
	public Map<String, Object> getItemChartDate(String metalCode, String sleMthdCode) throws Exception {
		return mainChartData(metalCode, sleMthdCode);
	}

	@Override
	@Cacheable(cacheNames = "Chart_All", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager = "localCacheManager")
	public List<PcChartMntrngSelVO> getPcMngtrngSel1MinList(PcChartMntrngSelVO pcMntrngSelVO) {
		return pcChartMntrngMapper.getPcMngtrngSel1MinList(pcMntrngSelVO);
	}

	@Override
	@Cacheable(cacheNames = "Chart_All", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager = "localCacheManager")
	public List<PcChartMntrngSelVO> getPcMngtrngSel30MinList(PcChartMntrngSelVO pcMntrngSelVO) throws Exception {
		return pcChartMntrngMapper.getPcMngtrngSel30MinList(pcMntrngSelVO);
	}

	@Override
	@Cacheable(cacheNames = "Chart_All", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager = "localCacheManager")
	public List<PcChartMntrngSelVO> getPcMngtrngSel60MinList(PcChartMntrngSelVO pcMntrngSelVO) throws Exception {
		return pcChartMntrngMapper.getPcMngtrngSel60MinList(pcMntrngSelVO);
	}

	@Override
	public List<PcChartMntrngSelVO> getPcMngtrngSelHalfYearList(PcChartMntrngSelVO pcMntrngSelVO) throws Exception {
		return pcChartMntrngMapper.getPcMngtrngSel60MinList(pcMntrngSelVO);
	}

	@Override
	@Cacheable(cacheNames = "Chart_All", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager = "localCacheManager")
	public List<PcChartMntrngSelVO> getPcMngtrngSelDeList(PcChartMntrngSelVO pcMntrngSelVO) {
		return pcChartMntrngMapper.getPcMngtrngSelDeList(pcMntrngSelVO);
	}

	@Override
	@Cacheable(cacheNames = "Chart_All", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager = "localCacheManager")
	public List<PcChartMntrngSelVO> getPcMngtrngSelMonthList(PcChartMntrngSelVO pcMntrngSelVO) throws Exception {
		return pcChartMntrngMapper.getPcMngtrngSelMonthList(pcMntrngSelVO);
	}

	/*
	 * @Override public List<ItHghnetprcPurchsPrmpcDtlVO>
	 * getItHghnetprcPurchsPrmpcDtlMonth( ItHghnetprcPurchsPrmpcDtlVO
	 * itHghnetprcPurchsPrmpcDtlVO) throws Exception { return
	 * pcChartMntrngMapper.getItHghnetprcPurchsPrmpcDtlMonth(
	 * itHghnetprcPurchsPrmpcDtlVO); }
	 * 
	 * @Override public List<ItHghnetprcPurchsPrmpcDtlVO>
	 * getItHghnetprcPurchsPrmpcDtlQuarter( ItHghnetprcPurchsPrmpcDtlVO
	 * itHghnetprcPurchsPrmpcDtlVO) throws Exception { return
	 * pcChartMntrngMapper.getItHghnetprcPurchsPrmpcDtlQuarter(
	 * itHghnetprcPurchsPrmpcDtlVO); }
	 * 
	 * @Override public List<ItHghnetprcPurchsPrmpcDtlVO>
	 * getItHghnetprcPurchsPrmpcDtlHalfYear( ItHghnetprcPurchsPrmpcDtlVO
	 * itHghnetprcPurchsPrmpcDtlVO) throws Exception { return
	 * pcChartMntrngMapper.getItHghnetprcPurchsPrmpcDtlHalfYear(
	 * itHghnetprcPurchsPrmpcDtlVO); }
	 * 
	 * @Override public List<ItHghnetprcPurchsPrmpcDtlVO>
	 * getItHghnetprcPurchsPrmpcDtlYear( ItHghnetprcPurchsPrmpcDtlVO
	 * itHghnetprcPurchsPrmpcDtlVO) throws Exception { return
	 * pcChartMntrngMapper.getItHghnetprcPurchsPrmpcDtlYear(
	 * itHghnetprcPurchsPrmpcDtlVO); }
	 */
	// 차트 대시보드 데이터
	@SuppressWarnings("unchecked")
	private Map<String, Object> mainChartData(String metalCode, String sleMthdCode) throws Exception {
		Map<String, Object> returnChartData = new HashMap<String, Object>();
		List<MainPriceListVO> liveListVo = new ArrayList<MainPriceListVO>();
		List<MainPriceListVO> fixListVo = new ArrayList<MainPriceListVO>();

		// 휴일 코드 추가
		List<Map<String, Object>> restdeStateListMap = new ArrayList<Map<String, Object>>();
		List<RestTermVO> restTermListVO = bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");
		if (!restTermListVO.isEmpty()) {
			for (int i = 0; i < restTermListVO.size(); i++) {
				Map<String, Object> map = new HashMap<String, Object>();
//					if("7".equals(restTermListVO.get(i).getMetalCode())) {
				map.put("metalCode", restTermListVO.get(i).getMetalCode());
				map.put("restWaitTerm", restTermListVO.get(i).getWaitTerm()); // 영업 시작, 종료 시간까지 초단위
				map.put("restWaitNm", restTermListVO.get(i).getWaitNm());
				map.put("openTimeCode", restTermListVO.get(i).getOpenTimeCode());
				map.put("chartStTitle", restTermListVO.get(i).getChartStTitle());
				map.put("chartEdTitle", restTermListVO.get(i).getChartEdTitle());
				map.put("topWaitTerm", restTermListVO.get(i).getTopWaitTerm());
				map.put("topWaitNm", restTermListVO.get(i).getTopWaitNm());


//					}
				restdeStateListMap.add(map);
			}
		}

		// 휴일종류, 사이드카 관련 데이터 리스트
		returnChartData.put("restdeInfoListString", convertListToJson(restdeStateListMap));

		// 권역 조회
		Map<String, CommonCodeVO> brandCode = commonCodeService.getSubCodesRetVo("BRAND_GROUP_CODE");
		Map<String, CommonCodeVO> dstrctLclsfCode = commonCodeService.getSubCodesRetVo("DSTRCT_LCLSF_CODE");

		// 판매 금속 조회
		List<SelMetalVO> matalCodeLiveList = new ArrayList<SelMetalVO>();
		List<SelMetalVO> matalCodeFixList = new ArrayList<SelMetalVO>();

		List<SelMetalVO> selMetalList = pcChartMntrngMapper.selectSelMetalList(metalCode, sleMthdCode);

		for (int i = 0; i < selMetalList.size(); i++) {
			if ("01".equals(selMetalList.get(i).getSleMthdCode())) {
				matalCodeLiveList.add(selMetalList.get(i));
			} else if ("02".equals(selMetalList.get(i).getSleMthdCode())) {
				matalCodeFixList.add(selMetalList.get(i));
			}
		}

		// 금속을 하위메뉴로 가지고 있는 상위메뉴 리스트
//		List<HeaderMenuVO> upperMenuList = pcChartMntrngMapper.getUpperMenuList();

		// 탭메뉴 리스트
//		List<MainPriceListVO> tabMenuList = new ArrayList<MainPriceListVO>();

		// 프리미엄 기준아이템 정보 조회
		List<PreminumSelInfoVO> premiumInfoListByRedisData = pcInfoService.getPremiumInfoListByRedisData();

		// 실시간
		for (SelMetalVO liveCode : matalCodeLiveList) {
			List<PreminumSelInfoVO> preminumInfoList = null;
			preminumInfoList = premiumInfoListByRedisData.stream()
				.filter(preminumInfo -> preminumInfo.getMetalCode().equals(liveCode.getMetalCode())
						&& preminumInfo.getItmSn() == Integer.parseInt(liveCode.getItmSn())
						&& preminumInfo.getBrandCode().equals(liveCode.getBrandCode()))
				.collect(Collectors.toList());

			// 실시간
			MainPriceListVO paramVO = new MainPriceListVO();

			PreminumSelInfoVO stdrPreminumInfo = null;
			if(preminumInfoList != null) {
				for (PreminumSelInfoVO stdrPreminum : preminumInfoList) {
					if (stdrPreminum.getMetalCode().equals(liveCode.getMetalCode())
							&& stdrPreminum.getItmSn() == Integer.parseInt(liveCode.getItmSn())
							&& stdrPreminum.getDstrctLclsfCode().equals(liveCode.getDstrctLclsfCode())
							&& stdrPreminum.getBrandGroupCode().equals(liveCode.getBrandGroupCode())
							&& stdrPreminum.getBrandCode().equals(liveCode.getBrandCode())) {
						stdrPreminumInfo = stdrPreminum;
					}
				}
			}

			if (stdrPreminumInfo != null) {
				// 실시간 기준 가격 파라미터 세팅
				paramVO.setMetalCode(liveCode.getMetalCode()); // 금속 코드*
				paramVO.setItmSn(Integer.parseInt(liveCode.getItmSn())); // 아이탬 순번*
				paramVO.setDstrctLclsfCode(liveCode.getDstrctLclsfCode()); // 권역코드*
				paramVO.setBrandGroupCode(liveCode.getBrandGroupCode()); // 브랜드 그룹코드*
				paramVO.setBrandCode("0000000000"); // 브랜드 코드
				paramVO.setSleMthdCode(liveCode.getSleMthdCode());
				paramVO.setCodeNm(liveCode.getCodeNm());
				paramVO.setMetalClCode(liveCode.getMetalClCode());

				// 메인 페이지 문구
				paramVO.setCodeDcone(liveCode.getCodeDcone()); // 금속코드 영문명
				// paramVO.setCodeChrctrRefrnsix(liveCode.getCodeChrctrRefrnsix()); //금속코드 한글명
				paramVO.setCodeChrctrRefrntwo(liveCode.getCodeChrctrRefrntwo());
				paramVO.setBrandGroupNm(brandCode.get(stdrPreminumInfo.getBrandGroupCode()).getCodeDcone());
				paramVO.setDstrctLclsfName(dstrctLclsfCode.get(stdrPreminumInfo.getDstrctLclsfCode()).getCodeNm());

				List<ItemCodeVO> itemCodeList = itemCodeService.getItemCodeList(liveCode.getMetalCode());

				for (ItemCodeVO itemCodeVO : itemCodeList) {
					if (itemCodeVO.getSubCode().equals(liveCode.getItmSn())) {
						paramVO.setGoodsNm(itemCodeVO.getDspyGoodsNm());
					}
				}

				// 탭메뉴 문구
				PrMetalDisplayVO metalDisplayVo = new PrMetalDisplayVO();
				metalDisplayVo.setMetalCode(liveCode.getMetalCode());
				metalDisplayVo.setCtgryLevel("1");
				metalDisplayVo.setHghnetprcSleAt("N"); // 라이브는 N, 고정가는 Y

				PrMetalDisplayVO metalDisplayResult = pcChartMntrngMapper.selectMetalDisplay(metalDisplayVo);
				if (metalDisplayResult != null) {
					paramVO.setCodeChrctrRefrnsix(metalDisplayResult.getCtgryNm());
					paramVO.setCtgryNo(metalDisplayResult.getCtgryNo());
					paramVO.setUpperCtgryNo(metalDisplayResult.getUpperCtgryNo());
				}

				// 실시간 기준가 조회
				List<PrPremiumSelVO> chartTitleInfoByRedisDataList = (List<PrPremiumSelVO>) pcInfoService
						.getChartTitleInfoByRedisData(paramVO.getMetalCode());

				for (PrPremiumSelVO chartTitleInfoByRedisData : chartTitleInfoByRedisDataList) {
					if (chartTitleInfoByRedisData.getMetalCode().equals(paramVO.getMetalCode())
							&& chartTitleInfoByRedisData.getItmSn() == paramVO.getItmSn()
							&& chartTitleInfoByRedisData.getDstrctLclsfCode().equals(paramVO.getDstrctLclsfCode())
							&& chartTitleInfoByRedisData.getBrandGroupCode().equals(paramVO.getBrandGroupCode())
							&& chartTitleInfoByRedisData.getBrandCode().equals(paramVO.getBrandCode())) {

						paramVO.setEndPc(chartTitleInfoByRedisData.getEndPc() > 0 ? chartTitleInfoByRedisData.getEndPc()
								: chartTitleInfoByRedisData.getPastEndPc()); // 현재가격
						paramVO.setTopPc(chartTitleInfoByRedisData.getTopPc()); // 현재 고가
						paramVO.setLwetPc(chartTitleInfoByRedisData.getLwetPc()); // 현재 저가
						paramVO.setBeginPc(chartTitleInfoByRedisData.getBeginPc()); // 현재 시가
						paramVO.setEndPcAgo(chartTitleInfoByRedisData.getPastEndPc()); // 전날 종가
						paramVO.setFluctuationRate(chartTitleInfoByRedisData.getVersusRate().floatValue());// 등락률
						paramVO.setVersusPc(chartTitleInfoByRedisData.getVersusPc()); // 대비가격
						paramVO.setOccrrncDe(chartTitleInfoByRedisData.getSlePcRltmSn().substring(0, 8));
						paramVO.setOccrrncTime(chartTitleInfoByRedisData.getSlePcRltmSn().substring(8, 14));

						// 프리미엄 기준정보 세팅
						stdrPreminumInfo.setAgoEndPc((long) chartTitleInfoByRedisData.getPastEndPc());
						paramVO.setPreminumSelVO(stdrPreminumInfo);
					}

					// 케이지트레이딩 시세
					if(preminumInfoList != null) {
						for (int i = 0; i < preminumInfoList.size(); i++) {
							if (chartTitleInfoByRedisData.getMetalCode().equals(paramVO.getMetalCode())
									&& chartTitleInfoByRedisData.getItmSn() == preminumInfoList.get(i).getItmSn()
									&& chartTitleInfoByRedisData.getDstrctLclsfCode()
											.equals(preminumInfoList.get(i).getDstrctLclsfCode())
									&& chartTitleInfoByRedisData.getBrandGroupCode()
											.equals(preminumInfoList.get(i).getBrandGroupCode())
									&& "0000000000".equals(chartTitleInfoByRedisData.getBrandCode())) {

								preminumInfoList.get(i)
										.setEndPc(chartTitleInfoByRedisData.getEndPc() > 0
												? chartTitleInfoByRedisData.getEndPc()
												: chartTitleInfoByRedisData.getPastEndPc()); // 아이탬별 종가
								preminumInfoList.get(i).setVersusPc(chartTitleInfoByRedisData.getVersusPc());
								preminumInfoList.get(i)
										.setVersusRate(chartTitleInfoByRedisData.getVersusRate().floatValue());
								preminumInfoList.get(i).setAgoEndPc(chartTitleInfoByRedisData.getPastEndPc());
								preminumInfoList.get(i).setBrandGroupNm(
										brandCode.get(preminumInfoList.get(i).getBrandGroupCode()).getCodeDcone());
								preminumInfoList.get(i).setDstrctLclsfNm(
										dstrctLclsfCode.get(preminumInfoList.get(i).getDstrctLclsfCode()).getCodeNm());
							}
						}
					}
				}

				paramVO.setPreminumSelListVO(preminumInfoList);

				// 조달청 가격 조회
				List<RvcmpnVO> rvcmpnVOList = pcInfoService.getRvcmpn(DateUtil.getNowDate(), liveCode.getMetalCode());
				if (!rvcmpnVOList.isEmpty()) {
					for (RvcmpnVO rvcmpnVO : rvcmpnVOList) {
						rvcmpnVO.setBrandGroupName(brandCode.get(rvcmpnVO.getBrandGroupCode()).getCodeDcone());
					}
				}
				paramVO.setRvcmpnVOArr(rvcmpnVOList);

				// LME 가격 조회
				PrLmePblntfPcBasVO prLmePblntfPcBasVO = new PrLmePblntfPcBasVO();
				prLmePblntfPcBasVO.setMetalCode(paramVO.getMetalCode());
				prLmePblntfPcBasVO.setGicName(GIC_NAME.get(paramVO.getMetalCode()));
				PrLmePblntfPcBasVO lmePriceVO = pcChartMntrngMapper.getPrLmePblntfPc(prLmePblntfPcBasVO);
				paramVO.setPrLmePblntfPcBasVO(lmePriceVO);
			}
			liveListVo.add(paramVO);
		}

		// 탭메뉴 설정
//		for(HeaderMenuVO upperMenu : upperMenuList) {
//			MainPriceListVO paramVO = new MainPriceListVO();
//			int count = 0;
//			for(MainPriceListVO fixVo : fixListVo) {
//				if(fixVo.getUpperCtgryNo() != null && fixVo.getUpperCtgryNo().equals(upperMenu.getCtgryNo())) {
//					count ++;
//				}
//			}
//			if(count > 0) {
//				paramVO.setCodeChrctrRefrnsix(upperMenu.getCtgryNm());
//				paramVO.setCtgryNo(upperMenu.getCtgryNo());
//				tabMenuList.add(paramVO);
//			}
//		}
//		returnChartData.put("tabMenuList", tabMenuList);

		// 휴일 관련
		returnChartData.put("restdeInfoList", restTermListVO);

		// 라이브 시세 리스트
		returnChartData.put("liveList", liveListVo);
		// 고정가 시세 리스트
		returnChartData.put("fixList", fixListVo);

		// 환율 조회
		PrEhgtRltmVO prEhgtRltmVO = pcInfoService.getNewestPrEhgtRltm("SPTUSD/KRW");
		if (prEhgtRltmVO != null) {
			returnChartData.put("ehgtRltm", prEhgtRltmVO.getEndPc());
		} else {
			returnChartData.put("ehgtRltm", 0);
		}

		return returnChartData;
	}

	private float getVersusRate(long agoEndPcL, long nowEndPcL, long premiumAmountL) {
		float agoEndPcF = (float) agoEndPcL;
		float nowEndPcF = (float) nowEndPcL;
		float premiumAmountF = (float) premiumAmountL;

		float vsusRate = 0;

		if (agoEndPcF == 0) {
			vsusRate = 100;
		} else {
			vsusRate = ((nowEndPcF + premiumAmountF) - agoEndPcF) / agoEndPcF * 100;
		}

		String vsusRateStr = String.format("%.2f", vsusRate);

		return Float.parseFloat(vsusRateStr);
	}

	private String getPreviousDay() {
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(cal.DATE, -1); // 하루전

		return df.format(cal.getTime());
	}

	private String getPreviousMonth() {
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(cal.MONTH, -1); // 이전 달
		cal.set(Calendar.DAY_OF_MONTH, 1);

		return df.format(cal.getTime());
	}

	@Override
	public List<RestTermVO> headerRestInfo() {
		List<RestTermVO> restTermListVO = new ArrayList<RestTermVO>();
		try {
			restTermListVO = bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		}
		return restTermListVO;
	}

	@Override
	public List<Map<String, Object>> selectRestDtTimeSet() {
		List<Map<String, Object>> returnMap = new ArrayList<>();
		try {
			List<RestTermVO> restTermListVO = bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");
			for (int i = 0; i < restTermListVO.size(); i++) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("metalCode", restTermListVO.get(i).getMetalCode());
				map.put("restWaitTerm", restTermListVO.get(i).getWaitTerm()); // 영업 시작, 종료 시간까지 초단위
				map.put("restWaitNm", restTermListVO.get(i).getWaitNm()); // 타이머 문구
				map.put("openTimeCode", restTermListVO.get(i).getOpenTimeCode()); // 개장시간 범위 코드
				map.put("chartStTitle", restTermListVO.get(i).getChartStTitle());
				map.put("chartEdTitle", restTermListVO.get(i).getChartEdTitle());
				map.put("topWaitTerm", restTermListVO.get(i).getTopWaitTerm());
				map.put("topWaitNm", restTermListVO.get(i).getTopWaitNm());
				returnMap.add(map);
			}
			return returnMap;
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return null;
		}
	}

	@Override
	public Map<String, Object> restDtTimeSetSchdule() {
		MDC.put("scheduled", "true");
		Map<String, Object> map = new HashMap<>();
		map.put("restDtTime", selectRestDtTimeSet());
		return map;
	}

	@Override
	public JSONArray getRestdeInfoJson() throws Exception {
		// 휴일 코드 추가
		List<Map<String, Object>> restdeStateListMap = new ArrayList<Map<String, Object>>();
		List<RestTermVO> restTermListVO = bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");
		if (!restTermListVO.isEmpty()) {
			for (int i = 0; i < restTermListVO.size(); i++) {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("metalCode", restTermListVO.get(i).getMetalCode());
				map.put("restWaitTerm", restTermListVO.get(i).getWaitTerm()); // 영업 시작, 종료 시간까지 초단위
				map.put("restWaitNm", restTermListVO.get(i).getWaitNm());
				map.put("openTimeCode", restTermListVO.get(i).getOpenTimeCode());
				map.put("chartStTitle", restTermListVO.get(i).getChartStTitle());
				map.put("chartEdTitle", restTermListVO.get(i).getChartEdTitle());
				map.put("topWaitTerm", restTermListVO.get(i).getTopWaitTerm());
				map.put("topWaitNm", restTermListVO.get(i).getTopWaitNm());

				restdeStateListMap.add(map);
			}
		}

		return convertListToJson(restdeStateListMap);
	}

	// list<map> 을 json 형태로 변형.
	public static JSONArray convertListToJson(List<Map<String, Object>> bankCdList) {
		JSONArray jsonArray = new JSONArray();
		for (Map<String, Object> map : bankCdList) {
			jsonArray.add(convertMapToJson(map));
		}
		return jsonArray;
	}

	// map 을 json 형태로 변형
	public static JSONObject convertMapToJson(Map<String, Object> map) {
		JSONObject json = new JSONObject();
		for (Map.Entry<String, Object> entry : map.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			// json.addProperty(key, value);
			json.put(key, value);
		}
		return json;
	}

}
