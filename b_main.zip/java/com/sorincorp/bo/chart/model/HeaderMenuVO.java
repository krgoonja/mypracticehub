package com.sorincorp.bo.chart.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class HeaderMenuVO implements Serializable{
	
	private static final long serialVersionUID = 2051642899069834571L;
	
	 /**
	 *  메뉴명
	 */
	private String ctgryNm;

	 /**
	 *  메뉴번호
	 */
	private String ctgryNo;

	 /**
	 *  상위메뉴번호
	 */
	private String upperCtgryNo;

	 /**
	 *  메뉴레벨
	 */
	private String ctgryLevel;
	
	 /**
	 *  금속 코드
	 */
	private String metalCode;

	 /**
	 *  금속 코드
	 */
	private String metalClCode;
	
	 /**
	 * 메뉴 url
	 */
	private String menuUrl;
	
	 /**
	 * 상품 판매 코드
	 */
	private String sleMthdCode;
	
	 /**
	 * 메뉴 정렬 순서
	 */
	private String ctgryOrdr;
	
	/**
	 * 고정가 여부
	 */
	private String hghnetprcSleAt;
	
	/**
	 * 라이브가 여부
	 */
	private String liveSleAt;
	
	/**
	 * 지정가여부
	 */
	private String limitsSleAt;
	
	private String subCtgryChk;
}
