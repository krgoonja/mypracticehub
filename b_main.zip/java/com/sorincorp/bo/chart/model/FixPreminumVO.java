package com.sorincorp.bo.chart.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * PreminumSelVO.java
 * @version
 * @since 2021. 11. 15.
 * @author srec0008
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class FixPreminumVO{

	private static final long serialVersionUID = 1L;

	/**
	 * 아이탬 번호
	 */
	private int itmSn;
	/**
	 * 아이탬명
	 */
	private String itmName;
	/**
	 * 고정가 판매 가격
	 */
	private long sleStdrPc;
	/**
	 * 전일자 고정가 판매 가격
	 */
	private long sleStdrPcAgo;
	/**
	 * 대비가격
	 */
	private long versusPc;
	/**
	 * 전일 대비 비율
	 */
	private java.math.BigDecimal sleStdrPcRate;
	/**
	 * 금속코드
	 */
	private String metalCode;
	/**
	 * 금속분류코드
	 */
	private String metalClCode;
}
