package com.sorincorp.bo.chart.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class PcChartMntrngSelVO extends CommonVO {

	private static final long serialVersionUID = 1L;

	/**
	 * 차트 데이터 개수
	 */
	private int chartCount;
	/**
	 * 차트 타입
	 */
	private String chartType;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 차트 기간 구분
     */
    private String type;
    /**
     * 판매 가격 일 순번
    */
    private long slePcDeSn;
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 변동률
     */
    private String versusRate;
    /**
     * 변동금액
     */
    private int versusPc;
    /**
     * 발생 일자
    */
    private String occrrncDe;
    /**
     * 차트 일시
     */
    private String chartSelTime;
    /**
     * 발생 시간
    */
    private String occrrncTime;
    /**
     * 발생 순번
    */
    private String occrrncSn;
    /**
     * 판매 가격 실시간 순번
    */
    private long slePcRltmSn;
    /**
     * 총 실제 주문 중량
     */
    private int delngQy;
    /**
     * 시작 가격
    */
    private long beginPc;
    /**
     * 종료 가격
    */
    private long endPc;
    /**
     * 최고 가격
    */
    private long topPc;
    /**
     * 최저 가격
    */
    private long lwetPc;
    /**
     * 3개월 LME 가격
    */
    private java.math.BigDecimal threemonthLmePc;
    /**
     * LME 가격
    */
    private java.math.BigDecimal lmePc;
    /**
     * LME 정산 가격
    */
    private java.math.BigDecimal lmeExcclcPc;
    /**
     * 프리미엄 가격
    */
    private java.math.BigDecimal premiumPc;
    /**
     * 환율 가격
    */
    private java.math.BigDecimal ehgtPc;
    /**
     * LME 가격 실시간 순번
    */
    private long lmePcRltmSn;
    /**
     * 프리미엄 번호
    */
    private String premiumNo;
    /**
     * 환율 가격 실시간 순번
    */
    private long ehgtPcRltmSn;
    /**
     * LME 조정 계수
    */
    private java.math.BigDecimal lmeMdatCffcnt;
    /**
     * FX 조정 계수
    */
    private java.math.BigDecimal fxMdatCffcnt;
    /**
     * 대비 등락 코드
    */
    private String versusFlctsCode;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
}
