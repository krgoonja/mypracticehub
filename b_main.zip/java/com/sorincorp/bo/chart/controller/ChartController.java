package com.sorincorp.bo.chart.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.chart.service.PcChartMntrngService;
import com.sorincorp.comm.bsnInfo.model.RestTermVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.PcMntrngSelVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * chartController.java
 * @version
 * @since 2021. 9. 7.
 * @author srec0008
 */
@Slf4j
@Controller
@RequestMapping("/chart")
public class ChartController {
	
	@Autowired
	PcChartMntrngService pcChartMntrngService;
	
	@Autowired
	CommonCodeService commonCodeService;
	
	@Autowired
	SimpMessagingTemplate simpMessagingTemplate;
	
	@Autowired
	private PcInfoService pcInfoService;
	
	/**
	 * <pre>
	 * 금속 코드 조회
	 * </pre>
	 * @date 2021. 12. 8.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 8.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value="/getMetalCode")
	@ResponseBody
	public Map<String, Object> getMetalCode() throws Exception{
		Map<String, Object> returnMap = new HashMap<String, Object>();
		returnMap.put("metalCode", commonCodeService.getFilterCodeRetVo("METAL_CODE",null,"CODE_DCTWO","Y"));
		
		
		return returnMap;
	}
	
	/**
	 * <pre>
	 * 판매 금액 조회
	 * </pre>
	 * @date 2021. 12. 8.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 8.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value="/pcMngtrngSelList")
	@ResponseBody
	public Map<String, Object> pcMngtrngSelList(@RequestBody PcMntrngSelVO pcMntrngSelVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		List<PcMntrngSelVO> resultList = new ArrayList<PcMntrngSelVO>();
		
		switch (pcMntrngSelVO.getType()) {
		case "1minute":
			pcMntrngSelVO.setOccrrncDe(DateUtil.getNowDate());
			pcMntrngSelVO.setOccrrncTime(DateUtil.getFormatDate(DateUtil.getCalendar(), "hhmm") + "00");
			resultList = pcInfoService.getPcMngtrngSel1MinList(pcMntrngSelVO);
			break;

		case "30minute":
			pcMntrngSelVO.setOccrrncDe(DateUtil.getNowDate());
			int mm = Integer.parseInt(DateUtil.getFormatDate(DateUtil.getCalendar(), "mm"));
			pcMntrngSelVO.setOccrrncTime(DateUtil.getFormatDate(DateUtil.getCalendar(), "hh") + (mm>= 30 ? "30": "00") + "00");
			resultList = pcInfoService.getPcMngtrngSel30MinList(pcMntrngSelVO);
			break;
			
		case "60minute":
			pcMntrngSelVO.setOccrrncDe(DateUtil.getNowDate());
			pcMntrngSelVO.setOccrrncTime(DateUtil.getFormatDate(DateUtil.getCalendar(), "hh") + "0000");
			resultList = pcInfoService.getPcMngtrngSel60MinList(pcMntrngSelVO);
			break;
			
		case "day":
			pcMntrngSelVO.setOccrrncDe(DateUtil.getNowDate());
			resultList = pcInfoService.getPcMngtrngSelDeList(pcMntrngSelVO);
			break;
			
		case "month":
			pcMntrngSelVO.setOccrrncDe(DateUtil.getNowDate());
			resultList = pcInfoService.getPcMngtrngSelMonthList(pcMntrngSelVO);
			break;

		default:
			break;
		}
		
		returnMap.put("restInfoJson", pcChartMntrngService.getRestdeInfoJson());
		returnMap.put("result", resultList);
		
		return returnMap; 
	}
	
//	@PostMapping(value="/pcMngtrngSelDeList")
//	@ResponseBody
//	public Map<String, Object> pcMngtrngSelDeList(@RequestBody PcChartMntrngSelVO pcMntrngSelVO) throws Exception {
//		Map<String, Object> returnMap = new HashMap<String, Object>();
//		
//		List<PcChartMntrngSelVO> resultList = pcChartMntrngService.getPcMngtrngSelDeList(pcMntrngSelVO);
//		
//		returnMap.put("result", resultList);
//		
//		return returnMap;
//	}
//	

	/**
	 * <pre>
	 * 차트 영업시간 타이머
	 * </pre>
	 * @date 2021. 12. 10.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 10.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/restDtTimeSet")
	public ResponseEntity<Object> restDtTimeSet(){

		Map<String,Object> restDtTimeMap = new HashMap<>();
		
		try {
			restDtTimeMap.put("restDtTime",pcChartMntrngService.selectRestDtTimeSet());	
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
		}

		return new ResponseEntity<>(restDtTimeMap, HttpStatus.OK);
		
	}
	
	/**
	 * <pre>
	 * 처리내용: 스케줄 (3분에 한번 씩 호출) 
	 * 			 헤더 타이머 조회 - 타이머 문구, 시간차, 개장시간 범위 코드
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	@Scheduled(fixedRate = 180000)
	public void restDtTimeSetSchdule() throws Exception {
		// 3분에 한번 씩 호출
		Map<String,Object> timeSetMap = pcChartMntrngService.restDtTimeSetSchdule();
		simpMessagingTemplate.convertAndSend("/selectHeaderTimeSet",timeSetMap);
	}
	
	/**
	 * <pre>
	 * 처리내용: 헤더 - 영업시간 여부, 고정가 실시간가 운영 여부 조회
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@ResponseBody
	@PostMapping("/headerRestInfo")
	public ResponseEntity<Object>  headerRestInfo() {
		//Map<String,Object> restInfo = pcChartMntrngService.headerRestInfo();
		List<RestTermVO> restInfo = pcChartMntrngService.headerRestInfo();
		return new ResponseEntity<>(restInfo, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 전체 종목에 대한 프리미엄가격정보를 조회한다.
	 * </pre>
	 *
	 * @date 2023. 4. 21.
	 * @author srec0067
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 4. 21.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param paramMap
	 * @return Map<String, Object>
	 * @throws Exception
	 */
	@PostMapping("/getPremiumInfoMap")
	@ResponseBody
	public Map<String, TreeSet<LivePremiumVO>> getPremiumInfoMap() throws Exception {
		// 프리미엄가격정보 가져오기
		Map<String, TreeSet<LivePremiumVO>> premiumInfoMap = pcInfoService.getPremiumInfoMap();
		return premiumInfoMap;
	}
} 
