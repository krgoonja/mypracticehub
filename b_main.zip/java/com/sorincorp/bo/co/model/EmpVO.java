package com.sorincorp.bo.co.model;

import java.util.Date;

import com.sorincorp.bo.sample.model.SampleDefaultVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class EmpVO extends SampleDefaultVO{
	
	/**
	 *  serialVersion UID
	 */
	private static final long serialVersionUID = -858838578081269359L;
	
	/* 부서이름 */
	private String deptNm;
	
	/* 회원 ID */
	private String userId;
	
	/* 회원 이름*/
	private String nm;
	
	/* 이메일  */
	private String cmpnyEmail;
	
	/* 연락처 */
	private String cryalTlphonNo;
	
	/* 권한코드 */
	private int authorNo;
	
	/* 사원 번호 */
	private String emplNo;
	
	/** 최초 등록자 아이디 */
	private String frstRegisterId;
	
	/** 최초 등록 일시 */
	private Date frstRegistDt;
	
	/*최종 변경자 아이디*/
	private String lastChangerId;
	
	/* 최종 변경 일시 */
	private String lastChangeDt;
}
