package com.sorincorp.bo.co.model;

import java.util.Date;
import java.util.Map;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class DeptTreeVO extends DeptVO{

	/** 아이디 */
	private String id;

	/** 이름 */
	private String text;

	/** 부모 아이디 */
	private String parent;

	/** 속성값 */
	private Map<String , Boolean> state;
	
	/** 권한 갯수 */
	private int cnt;
	
	/** 권한 ID */
	private int authorNo;
	
	/** 최초 등록자 아이디 */
	private String frstRegisterId;
	
	/** 최초 등록 일시 */
	private Date frstRegistDt;
	
	/**최종 변경자 아이디*/
	private String lastChangerId;
	
	/** 최종 변경 일시 */
	private String lastChangeDt;
	
}
