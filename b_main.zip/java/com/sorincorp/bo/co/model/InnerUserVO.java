package com.sorincorp.bo.co.model;

import com.sorincorp.bo.sample.model.SampleDefaultVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * InnerUserVO.java
 * @version
 * @since 2021. 6. 21.
 * @author srec0033
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class InnerUserVO extends SampleDefaultVO  {

	private static final long serialVersionUID = 6882956165304862133L;
	
    /**
     * 회사 고유 번호
    */
    private String cmpnyEsntlNo;
    
    /**
     * 사용자 아이디
    */
    private String userId;
    
    /**
     * 직위 고유 번호
    */
    private String ofcpsEsntlNo;
    
    /**
     * 직급 고유 번호
    */
    private String clsfEsntlNo;
    
    /**
     * 직책 고유 번호
    */
    private String rspofcEsntlNo;
    
    /**
     * 성명
    */
    private String nm;
    
    /**
     * 사원 번호
    */
    private String emplNo;
    
    /**
     * 직원 상태
    */
    private String empSttus;
    
    /**
     * 휴대 전화 번호
    */
    private String cryalTlphonNo;
    
    /**
     * 회사 전화 번호
    */
    private String cmpnyTlphonNo;
    
    /**
     * 회사 이메일
    */
    private String cmpnyEmail;
    
    /**
     * 사업장 코드
    */
    private String bplcCode;
    
    /**
     * 사업장명
    */
    private String koreanBplcNm;
    
    /**
     * 법인 코드
    */
    private String cprCode;
    
    /**
     * 법인명
    */
    private String koreanCprNm;
    
    /**
     * 부서 코드
    */
    private String deptEsntlNo;
    
    /**
     * 부서명
    */
    private String koreanDeptNm;
    
    /**
     * 직급
    */
    private String koreanOfcpsNm; 
    
    /**
     * 권한
    */
    private String authorNm; 
    
    /**
     * 입사 일자
    */
    private String ecnyDe;
    
    /**
     * 퇴사 일자
    */
    private String retireDe;
    
}
