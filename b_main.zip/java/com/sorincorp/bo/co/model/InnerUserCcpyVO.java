package com.sorincorp.bo.co.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.sorincorp.bo.mb.model.ApprovalReqMbCorpMgrVO.InsertAndUpdate;
import com.sorincorp.bo.sample.model.SampleDefaultVO;

import lombok.Data;

@Data
public class InnerUserCcpyVO extends SampleDefaultVO {
	
	/**
     * 회사 고유 번호
    */
    private String cmpnyEsntlNo;
    
    /**
     * 사용자 아이디
    */
    private String userId;
    
    /**
     * 직위 고유 번호
    */
    private String ofcpsEsntlNo;
    
    /**
     * 직급 고유 번호
    */
    private String clsfEsntlNo;
    
    /**
     * 직책 고유 번호
    */
    private String rspofcEsntlNo;
    
    /**
     * 표기 명
    */
    private String markNm;
    
    /**
     * 성명
    */
    private String nm;
    
    /**
     * 영문 성명
    */
    private String engNm;
    
    /**
     * 중문 성명
    */
    private String chnsntNm;
    
    /**
     * 일문 성명
    */
    private String jpnsntNm;
   
    /**
     * 생년월일
    */
    private String brthdy;
    
    /**
     * 주소
    
    private String adres;*/
    
    /**
     * 자택 전화 번호
    */
    private String ownhomTlphonNo;
    
    /**
     * 사원 번호
    */
    private String emplNo;
    
    /**
     * 직원 상태
    */
    private String empSttus;
    
    /**
     * 휴대 전화 번호
    */
    private String cryalTlphonNo;
    
    /**
     * 회사 전화 번호
    */
    private String cmpnyTlphonNo;
    
    /**
     * 내선 번호
    */
    private String lxtnNo;
    
    /**
     * 팩스 번호
    */
    private String faxNo;
    
    /**
     * 회사 이메일
    */
    private String cmpnyEmail;
    
    /**
     * 사업장 코드
    */
    private String bplcCode;
    
    /**
     * 사업장명
    */
    private String koreanBplcNm;
    
    /**
     * 법인 코드
    */
    private String cprCode;
    
    /**
     * 법인명
    */
    private String koreanCprNm;
    
    /**
     * 부서 코드
    */
    private String deptEsntlNo;
    
    /**
     * 부서명
    */
    private String koreanDeptNm;
    
    /**
     * 직위
    */
    private String koreanOfcpsNm; 
    
    /**
     * 직급
     */
    private String koreanClsfNm;
    
    /**
     * 직책
     */
    private String koreanRspofcNm;
    
    /**
     * 권한
    */
    private String authorNm; 
    
    /**
     * 입사 일자
    */
    private String ecnyDe;
    
    /**
     * 퇴사 일자
    */
    private String retireDe;
    
    /**
     * 계열사 기본 여부
    */
    private String affltsBassAt;
    
    /**
     * 사업장 구분
    */
    private String bplcSe;
    
    /**
     * 패스워드
    */
    private String password;
    
	private List<String> emplNoList;
	
	
	/**
	 * 우편 번호
	 */
	@Size(groups = InsertAndUpdate.class, max = 6, message = "우편번호는 최대6자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = InsertAndUpdate.class, message = "우편번호는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String postNo;
	/**
	 * 주소
	 */
	@Size(groups = InsertAndUpdate.class, max = 300, message = "주소는 최대300자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = InsertAndUpdate.class, message = "주소는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String adres;
	/**
	 * 상세 주소
	 */
	@Size(groups = InsertAndUpdate.class, max = 300, message = "상세주소는 최대300자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	private String detailAdres;
	/**
	 * 도로명 주소
	 */
	@Size(groups = InsertAndUpdate.class, max = 300, message = "도로명주소는 최대300자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = InsertAndUpdate.class, message = "도로명주소는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String rnAdres;
	/**
	 * 도로명 상세 주소
	 */
	@Size(groups = InsertAndUpdate.class, max = 300, message = "도로명상세주소는 최대300자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	private String rnDetailAdres;
    
    
	/** Grid 상태 */
	private String gridRowStatus;
    
    /** modalPageStatus 상태 */
	private String modalPageStatus;
	
	/** 검색Keyword */
	private String searchKeyword;
	
    /** 엑셀 다운로드 여부 */
    private String excelYn;



}
