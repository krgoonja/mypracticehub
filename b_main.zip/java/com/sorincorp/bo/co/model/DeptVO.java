package com.sorincorp.bo.co.model;

import lombok.Data;

@Data
public class DeptVO {
	
	/* 회사 고유 번호 */
	private String cmpnyEsntlNo;
	
	/* 부서 고유 번호 */
	private String deptEsntlNo;
	
	/* 사업자 번호 */
	private String bsnmNo;
	
	/* 한글 부서 명 */
	private String koreanDeptNm;
	
	/* 영문 부서 명 */
	private String engDeptNm;
	
	/* 중문 부서 명 */
	private String chnsntDeptNm;
	
	/* 일문 부서 명 */
	private String jpnsntDeptNm;
	
	/* 정렬 순서 */
	private String sortOrdr;
	
	/* 사업장 코드 */
	private String bplcCode;
	
	/* 상위 부서 코드 */
	private String upperDeptCode;
	
	/* 부서 상태 */
	private String deptSttus;
	
	/* 부서 등록 일 */
	private String deptRegistDe;
	
	/* 부서 종료 일 */
	private String deptEndDe;
	
	/* 최종 수정 일 */
	private String lastUpdtDe;
	
}
