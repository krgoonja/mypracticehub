package com.sorincorp.bo.co.model;

import java.math.BigDecimal;
import java.util.Date;

import com.sorincorp.bo.sample.model.SampleDefaultVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CmmnCodeVO.java 
 * @version
 * @since 2021. 6. 9.
 * @author srec0033
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class CmmnCodeVO extends SampleDefaultVO {
	
	private static final long serialVersionUID = 6882956165304862133L;

	/**
	 * InsertAndUpdate</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface InsertAndUpdate {};
	
	/** 메인 코드 */
	private String mainCode;
	
	/** 서브 코드 */
	private String subCode; 
	
	/** 코드 명 */
	private String codeNm;
	
	/** 코드 길이 */
	private int codeLt;
	
	/** 코드 순서 */
	private int codeOrdr;
	
	/** 코드 설명1 */
	private String codeDcone;
	
	/** 코드 설명2 */
	private String codeDctwo;
	
	/** 코드 참조1 */
	private String codeRefrnone;
	
	/** 코드 참조2 */
	private String codeRefrntwo;
	
	/** 코드 참조3 */
	private String codeRefrnthree;
	
	/** 코드 문자 참조1 */
	private String codeChrctrRefrnone;
	
	/** 코드 문자 참조2 */
	private String codeChrctrRefrntwo;
	
	/** 코드 문자 참조3 */
	private String codeChrctrRefrnthree;
	
	/** 코드 문자 참조4 */
	private String codeChrctrRefrnfour;
	
	/** 코드 문자 참조5 */
	private String codeChrctrRefrnfive;
	
	/** 코드 문자 참조6 */
	private String codeChrctrRefrnsix;
	
	/** 코드 숫자 참조1 */
	private BigDecimal codeNumberRefrnone;
	
	/** 코드 숫자 참조2 */
	private BigDecimal codeNumberRefrntwo;
	
	/** 코드 숫자 참조3 */
	private BigDecimal codeNumberRefrnthree;
	
	/** 코드 숫자 참조4 */
	private BigDecimal codeNumberRefrnfour;
	
	/** 시스템 여부 */
	private String sysAt;
	
	/** 트레이딩 사용 여부 */
	private String extrlSysUseAt; 
	
	/** 사용 여부 */
	private String useAt;
	
	/** 트레이딩 연동 여부 */
	private String extrlSysIntrlckAt; 
	
	/** 삭제 여부 */
	private String deleteAt;
	
	/** 삭제 일시 */
	private Date deleteDt;
	
	/** 최초 등록자 아이디 */
	private String frstRegisterId;
	
	/** 최초 등록 일시 */
	private Date frstRegistDt;
	
	/** 최종 변경자 아이디 */
	private String lastChangerId;
	
	/** 최종 변경 일시 */
	private Date lastChangeDt;
	
	/** 공통코드 이력순번 */
	private int cmmnCdHistSn;
	
	/** Grid 상태 */
	private String gridRowStatus;
	
	/** modalPageStatus 상태 */
	private String modalPageStatus;
	
    /** 트레이딩 메인코드 */
    private String extrlSysMainCode;
    
    /** 변경할 메인코드PK */
    private String newMainCode;
    
    /** 순번 */
    private String rownum;
    
    /** 화면 코드 숫자 참조1 */
	private String number1;
	
	/** 화면 코드 숫자 참조2 */
	private String number2;
	
	/** 화면 코드 숫자 참조3 */
	private String number3;
	
	/** 화면 코드 숫자 참조4 */
	private String number4;
}
