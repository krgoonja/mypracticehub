package com.sorincorp.bo.co.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class MenuAuthVO implements Serializable{
	
	private static final long serialVersionUID = 6882956165301262133L;

	/* 메뉴 번호 */
	private int menuNo;

	/* 권한 번호 */
	private int authorNo;
	
	/* 권한 Id */
	private String authorId;

	/* 조회 권한 여부 */
	private String inqireAuthorAt;

	/* 입력 권한 여부 */
	private String inputAuthorAt;

	/* 수정 권한 여부 */
	private String updtAuthorAt;
	
	/* 삭제 권한 여부 */
	private String deleteAuthorAt;
	
	/* 엑셀 권한 여부 */
	private String excelAuthorAt;
	
	/* 삭제 여부 */
	private String deleteAt;
	
	/*삭제 일시*/
	private String deleteDt;
	
	/*최초 등록자 아이디*/
	private String frstRegisterId;
	
	/*최초 등록 일시*/
	private String frstRegistDt;
	
	/*최종 변경자 아이디*/
	private String lastChangerId;
	
	/* 최종 변경 일시 */
	private String lastChangeDt;
	
	
	/* 권한 이름 */
	private String authorNm;
	
	/* 조회 권한 여부 */
	private boolean inqireAuthorAtBool;

	/* 입력 권한 여부 */
	private boolean inputAuthorAtBool;

	/* 수정 권한 여부 */
	private boolean updtAuthorAtBool;
	
	/* 삭제 권한 여부 */
	private boolean deleteAuthorAtBool;
	
	/* 엑셀 권한 여부 */
	private boolean excelAuthorAtBool;
	
	/* 메뉴 권한 메핑 여부 */
	private boolean authExistBool;
	
	/* 시스템 구분 코드 */
	private String sysSeCode;


}
