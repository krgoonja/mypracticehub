package com.sorincorp.bo.co.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class MenuExcelVO extends MenuVO {
	
	/** 아이디 */
	private String id;

	/** 이름 */
	private String text;

	/** 부모 아이디 */
	private String parent;
	
	/** 트리 depth */
	private int level;

}
