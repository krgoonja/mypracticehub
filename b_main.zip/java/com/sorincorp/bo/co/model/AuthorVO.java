package com.sorincorp.bo.co.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.sorincorp.bo.sample.model.SampleDefaultVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class AuthorVO extends SampleDefaultVO{

	private static final long serialVersionUID = -6792075936042823631L;
	
	/* 권한 번호 */
	private int authorNo;
	
	/* 권한 ID */
	@Size(min=0, max=30, message = "권한 ID는 30자 미만으로 입력해 주세요.")
	private String authorId;
	
	/* 시스템 구분 코드 */
	private String sysSeCode;
	
	/* 권한명 */
	@Size(min=0, max=50, message = "권한명은 50자 미만으로 입력해 주세요.")
	private String authorNm;
	
	/* 권한 설명 */
	@Size(min=0, max=1000, message = "권한설명은 1000자 미만으로 입력해 주세요.")
	private String authorDc;
	
	/* 권한 순서 */
	private String authorOrdr;
	
	/* 사용 여부 */
	@NotBlank(message = "사용여부를 선택해 주세요.")
	private String useAt;
	
	/* 삭제 여부 */
	private String deleteAt;
	
	/*삭제 일시*/
	private String deleteDt;
	
	/*최초 등록자 아이디*/
	private String frstRegisterId;
	
	/*최초 등록 일시*/
	private String frstRegistDt;
	
	/*최종 변경자 아이디*/
	private String lastChangerId;
	
	/* 최종 변경 일시 */
	private String lastChangeDt;
	
	/* 선택 권한 ID */
	private Integer curAuthorNo;
}
