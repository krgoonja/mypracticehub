package com.sorincorp.bo.co.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.co.model.AuthorMenuVO;
import com.sorincorp.bo.co.model.MenuAuthVO;
import com.sorincorp.bo.co.model.MenuTreeVO;
import com.sorincorp.bo.co.model.MenuVO;

/**
 * MenuMapper.java
 * @version
 * @since 2021. 6. 9.
 * @author Sim sung bo
 */
public interface MenuMapper {

	/**
	 * <pre>
	 * 처리내용: 메뉴 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @return
	 * @throws Exception
	 */
	List<MenuTreeVO> getListMenu(MenuTreeVO menuVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메뉴를 수정한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @throws Exception
	 */
	void updateMenu(MenuTreeVO menuVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메뉴를 등록한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @throws Exception
	 */
	void insertMenu(MenuTreeVO menuVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메뉴-권한 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @return
	 * @throws Exception
	 */
	List<AuthorMenuVO> getListAuthor(MenuTreeVO menuVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 모든 권한을 조회한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @return
	 * @throws Exception
	 */
	List<AuthorMenuVO> getListAllAuthor(MenuTreeVO menuVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메뉴-권한을 등록한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authVo
	 * @throws Exception
	 */
	void insertAuth(AuthorMenuVO authVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메뉴-권한을 수정한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authVo
	 * @throws Exception
	 */
	void updateAuth(AuthorMenuVO authVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메뉴를 삭제한다.
	 * </pre>
	 * @date 2021. 6. 14.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 14.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @throws Exception
	 */
	void deleteMenu(MenuTreeVO menuVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이력 등록
	 * </pre>
	 * @date 2021. 7. 26.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 26.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @throws Exception
	 */
	void insertHistMenu(MenuTreeVO menuVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이력 등록
	 * </pre>
	 * @date 2021. 7. 26.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 26.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param authVo
	 * @throws Exception
	 */
	void insertHistAuth(AuthorMenuVO authVo) throws Exception;


	/**
	 * <pre>
	 * 처리내용: 사이드바 메뉴 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 7. 28.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 28.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<MenuVO> getSideBarMenu(Map map) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 특정한 계정의 사이드바 메뉴 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 5. 16.
	 * @author heehoonc
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 5. 16.			heehoonc			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<MenuVO> getSideBarMenu2() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 사용자 권한에 해당되는 사이드바 level3 메뉴 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 26.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<MenuVO> getAuthMenu() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 사용자 권한에 해당되는 사이드바 상위 메뉴 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 26.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param upperMenuNo
	 * @return
	 * @throws Exception
	 */
	MenuVO getUpperMenu(int upperMenuNo) throws Exception;


	/**
	 * <pre>
	 * 처리내용: 각 메뉴의 권한 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 8. 23.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 23.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<MenuAuthVO> getMenuAuthInfo(String menuNo) throws Exception;

	List<MenuAuthVO> getMenuAuthInfoList(List<Integer> urlMenuList) throws Exception;


}
