package com.sorincorp.bo.co.mapper;

import java.util.List;

import com.sorincorp.bo.co.model.CmmnCodeVO;

/**
 * CmmnCodeMapper.java
 * @version
 * @since 2021. 6. 9. 
 * @author srec0033
 */
public interface CmmnCodeMapper {
	
	/**
	 * <pre> 
	 * 처리내용: 메인코드 목록을 조회한다.
	 * </pre>
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @return
	 * @throws Exception
	 */
	List<CmmnCodeVO> selectCmmnMainCodeList(CmmnCodeVO searchVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 서브코드 목록을 조회한다.
	 * </pre>
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @return
	 * @throws Exception
	 */
	List<CmmnCodeVO> selectCmmnSubCodeList(CmmnCodeVO mainCode) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공통코드를 조회한다.
	 * </pre>
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param codeVO
	 * @return
	 * @throws Exception
	 */
	CmmnCodeVO selectCmmnCode(CmmnCodeVO codeVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공통코드를 등록한다. 
	 * </pre>
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param codeVO
	 * @throws Exception
	 */
	void insertCmmnCode(CmmnCodeVO codeVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공통코드를 수정한다.
	 * </pre>
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param codeVO
	 * @throws Exception
	 */
	void updateCmmnCode(CmmnCodeVO codeVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 메인코드PK를 수정한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param mainVO
	 * @throws Exception
	 */
	void updateMaincodePK(CmmnCodeVO mainVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공통코드를 삭제한다.
	 * </pre>
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param codeVO
	 * @throws Exception
	 */
	void deleteCmmnCode(CmmnCodeVO codeVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공통코드의 총 갯수를 조회한다.
	 * </pre>
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @return
	 */
	int selectCmmnCodeListTotcnt(CmmnCodeVO searchVO);
	
	/**
	 * <pre>
	 * 처리내용: 공통코드 이력을 등록한다.
	 * </pre>
	 * @date 2021. 8. 23.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 23.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param codeVO
	 * @throws Exception
	 */
	void insertCmmnCodeHistory(CmmnCodeVO codeVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 모든 메인코드 목록을 조회한다.
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<String> selectAllMainCodes() throws Exception;
	
}
