package com.sorincorp.bo.co.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.co.model.CmmnCodeVO;
import com.sorincorp.bo.co.service.CmmnCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * CmmnCodeDbController.java
 * 
 * @version
 * @since 2021. 6. 9.
 * @author srec0033
 */
@Slf4j
@Controller
@RequestMapping("/bo/Cmmncode")
public class CmmnCodeController {

	@Autowired
	private CmmnCodeService codeService;

	@Autowired
	private CustomValidator customValidator;
	
	/**
	 * <pre>
	 * 처리내용: 공통코드 목록 페이지을 조회한다
	 * </pre>
	 * 
	 * @date 2021. 5. 31.
	 * @author srec0033
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 31.
	 *          srec0033 최초작성 ------------------------------------------------
	 * @return "co/cmmncodeList.tiles"
	 * @throws Exception
	 */
	@RequestMapping("/selectCmmncodeList")
	public String selectCmmncodeList() {
		try {

			return "co/cmmncodeList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 메인코드 그리드의 정보를 조회한다.
	 * </pre>
	 * 
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 27.
	 *          srec0033 최초작성 ------------------------------------------------
	 * @param sampleVO
	 * @return map
	 * @throws Exception
	 */
	@PostMapping("/selectMaincodeList")
	public ResponseEntity<?> selectMaincodeList(@RequestBody CmmnCodeVO searchVO) throws Exception {

		Map<String, Object> map = new HashMap<>();
		int totalDataCount = codeService.selectCmmnCodeListTotcnt(searchVO);
		List<CmmnCodeVO> codeList = codeService.selectCmmnMainCodeList(searchVO);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", codeList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 서브코드 그리드의 정보를 조회한다.
	 * </pre>
	 * 
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 27.
	 *          srec0033 최초작성 ------------------------------------------------
	 * @param sampleVO
	 * @return map
	 * @throws Exception
	 */
	@PostMapping("/selectSubcodeList")
	public ResponseEntity<?> selectSubcodeList(@RequestBody CmmnCodeVO mainCode) throws Exception {

		Map<String, Object> map = new HashMap<>();
		List<CmmnCodeVO> codeList = codeService.selectCmmnSubCodeList(mainCode);

		map.put("totalDataCount", codeList.size());
		map.put("dataList", codeList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 그리드의 정보를 저장, 업데이트 한다.
	 * </pre>
	 * 
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 27.
	 *          srec0033 최초작성 ------------------------------------------------
	 * @param sampleVOList
	 * @param bindingResult
	 * @param status
	 * @return "success"
	 * @throws Exception
	 */
	@PostMapping("/insertAndUpdateCodeList")
	@ResponseBody
	public ResponseEntity<?> insertAndUpdateCodeList(@RequestBody List<CmmnCodeVO> codeList, BindingResult bindingResult) throws Exception {

		for (CmmnCodeVO code: codeList) {
			if(code.isValidation()) {
				customValidator.validate(code, bindingResult);
			}
		}

		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		codeService.insertAndUpdateCodeList(codeList);

		return new ResponseEntity<>(HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 메인코드PK를 수정한다.
	 * </pre>
	 * 
	 * @date 2021. 6. 10.
	 * @author srec0033
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 10.
	 *          srec0033 최초작성 ------------------------------------------------
	 * @param mainVO
	 * @throws Exception
	 */
	@PostMapping("/updateMaincodePK")
	@ResponseBody
	public ResponseEntity<?> updateMaincodePK(@RequestBody List<CmmnCodeVO> codeList, BindingResult bindingResult) throws Exception {
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		log.debug("updateMaincodePK controller : mainVO" + codeList.get(0));

		codeService.updateMaincodePK(codeList.get(0));

		return new ResponseEntity<>(HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 그리드의 정보를 삭제 한다.
	 * </pre>
	 * 
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 27.
	 *          srec0033 최초작성 ------------------------------------------------
	 * @param sampleVOList
	 * @param status
	 * @return "success"
	 * @throws Exception
	 */
	@PostMapping("/deleteCodeList")
	@ResponseBody
	public String deleteCodeList(@RequestBody List<CmmnCodeVO> codeList) throws Exception {
		codeService.deleteGridDataList(codeList);
		return "success";
	}

	/**
	 * <pre>
	 * 처리내용: 메인코드 등록, 업데이트 팝업 창을 조회한다.
	 * </pre>
	 * 
	 * @date 2021. 5. 31.
	 * @author srec0033
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 31.
	 *          srec0033 최초작성 ------------------------------------------------
	 * @param mainVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertAndUpdateMaincodeView")
	public String insertMaincodeView(@RequestBody CmmnCodeVO mainVO, ModelMap model) {
		try {
			model.put("mainVO", mainVO);
	
			return "co/cmmnMaincodePopRegister.modal";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 메인코드 변경 팝업창을 조회한다. (main_code PK 변경)
	 * </pre>
	 * 
	 * @date 2021. 6. 10.
	 * @author srec0033
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 10.
	 *          srec0033 최초작성 ------------------------------------------------
	 * @param mainVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/updateMaincodeView")
	public String updateMaincodeView(@RequestBody CmmnCodeVO mainVO, ModelMap model) {
		try {
			model.put("mainVO", mainVO);
			
			return "co/cmmnMaincodePkPopUpdate.modal";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 서브코드 등록, 업데이트 팝업 창을 조회한다.
	 * </pre>
	 * 
	 * @date 2021. 5. 31.
	 * @author srec0033
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 31.
	 *          srec0033 최초작성 ------------------------------------------------
	 * @param subVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertAndUpdateSubcodeView")
	public String insertSubcodeView(@RequestBody CmmnCodeVO subVO, ModelMap model) {
		try {
			model.addAttribute("subVO", subVO);
			
			return "co/cmmnSubcodePopRegister.modal";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 레디스를 전체 갱신한다.
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/updateRedis")
	@ResponseBody
	public Map<String, String> updateRedis() throws Exception {
		 Map<String, String> result = codeService.updateRedis();
		 return result;
	}
}
