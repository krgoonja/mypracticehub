package com.sorincorp.bo.co.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.co.model.InnerUserCcpyVO;
import com.sorincorp.bo.co.service.InnerUserCcpyService;

import lombok.extern.slf4j.Slf4j;

/**
 * InnerUserCcpyController.java
 * @version
 * @since 2023. 4. 14.
 * @author srec0082
 */
@Controller
@RequestMapping("/bo/InneruserCcpy")
@Slf4j
public class InnerUserCcpyController {
	
	@Autowired
	private InnerUserCcpyService innerUserCcpyService;
	
	/**
	 * <pre>
	 * 처리내용: 내부사용자_협력업체 목록 페이지를 조회한다.
	 * </pre>
	 * @date 2023. 4. 14.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 14.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param user
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectInneruserCcpyList")
	public String selectInneruserCcpyList() {
		return "co/innerUserCcpyList";
	}

	/**
	 * <pre>
	 * 처리내용: 내부사용자_협력업체 목록 데이터를 조회한다.
	 * </pre>
	 * @date 2023. 4. 14.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 14.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param user
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectInneruserCcpyListData")
	@ResponseBody
	public Map<String, Object> selectInneruserCcpyListData(@RequestBody InnerUserCcpyVO user) throws Exception{
		
		Map<String, Object> map = new HashMap<String, Object>();
		int totalDataCount = innerUserCcpyService.selectInneruserCcpyTotCnt(user);
		List<InnerUserCcpyVO> dataList = innerUserCcpyService.selectInneruserCcpyList(user);
		
		map.put("totalDataCount", totalDataCount);
		map.put("dataList", dataList);
		
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 내부사용자_협력업체 상세정보를 조회(수정)한다.
	 * </pre>
	 * @date 2023. 4. 17.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 17.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param user
	 * @param model
	 * @return
	 * @throws Exception 
	 */
	@PostMapping("/selectInneruserCcpyView")
	public String selectInneruserCcpyDetail(@RequestBody InnerUserCcpyVO user, ModelMap model) throws Exception {
		log.debug("test : "+ user);
		
		if(user.getModalPageStatus().equals("insert")) {
			model.put("userCcpyVO", user);
		} else {
			InnerUserCcpyVO vo = innerUserCcpyService.selectInneruserCcpy(user);
			vo.setModalPageStatus(user.getModalPageStatus());
			model.put("userCcpyVO", vo);
		}
		
		model.put("koreanOfcpsNm",innerUserCcpyService.getKoreanOfcpsNm()); // 직위 콤보박스
		model.put("koreanClsfNm",innerUserCcpyService.getKoreanClsfNm()); // 직급 콤보박스
		model.put("koreanRspofcNm",innerUserCcpyService.getKoreanRspofcNm()); // 직책 콤보박스
		model.put("koreanBplcNm",innerUserCcpyService.getKoreanBplcNm()); // 사업장 콤보박스
		
		return "co/innerUserCcpyPopRegister.modal";
		
		
	}
	
	/**
	 * <pre>
	 * 처리내용: 내부사용자_협력업체 목록을 조회한다.(엑셀 다운로드)
	 * </pre>
	 * @date 2023. 4. 17.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 17.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectInneruserCcpyListDataForExcel")
	public ResponseEntity<?> selectInneruserCcpyListDataForExcel(@RequestBody InnerUserCcpyVO searchVO) throws Exception{
		Map<String,Object> map = new HashMap<>();
		searchVO.setRecordCountPerPage(10000000);
		List<InnerUserCcpyVO> dataList = innerUserCcpyService.selectInneruserCcpyList(searchVO);
		
		map.put("dataList", dataList);
		
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 내부사용자_협력업체 목록을 등록 및 수정한다.
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param userList
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertAndUpdateGridListData")
	@ResponseBody
	public int insertInneruserCcpy(@RequestBody List<InnerUserCcpyVO> userList) throws Exception{ 
		return innerUserCcpyService.insertAndUpdateGridDataList(userList);
	}
	
	/**
	 * <pre>
	 * 처리내용: 내부사용자_협력업체 목록을 등록한다.
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0082  
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param userList
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertInneruserCcpy")
	@ResponseBody
	public int insertInneruserCcpy(@RequestBody InnerUserCcpyVO user) throws Exception{ 
		return innerUserCcpyService.insertInneruserCcpy(user);
	}
	
	/**
	 * <pre>
	 * 처리내용: 내부사용자_협력업체 목록을 수정한다.
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param userList
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/updateInneruserCcpy")
	@ResponseBody
	public int updateInneruserCcpy (@RequestBody InnerUserCcpyVO user) throws Exception{ 
		return innerUserCcpyService.updateInneruserCcpy(user);
	}
	
	/**
	 * <pre>
	 * 처리내용: 내부사용자_협력업체 목록을 삭제 한다.
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param userList
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/deleteInneruserCcpy")
	@ResponseBody
	public int deleteInneruserCcpy (@RequestBody List<InnerUserCcpyVO> userList) throws Exception{
		
		return innerUserCcpyService.deleteInneruserCcpy(userList);
	}
	
	/**
	 * <pre>
	 * 처리내용: 두 테이블 간 내부사용자 아이디 중복체크 여부를 확인한다.
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param userId
	 * @return
	 */
	@RequestMapping("/idCheck")
	@ResponseBody
	public int idCheck(@RequestBody String userId){
		int cnt = innerUserCcpyService.idCheck(userId);				
		return cnt;
	}
	
	
	

}
