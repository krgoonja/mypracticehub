package com.sorincorp.bo.co.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.http.HttpResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.co.comm.BoCoConstants;
import com.sorincorp.bo.co.comm.CoResponseEntity;
import com.sorincorp.bo.co.model.AuthorMenuVO;
import com.sorincorp.bo.co.model.MenuTreeVO;
import com.sorincorp.bo.co.model.MenuVO;
import com.sorincorp.bo.co.service.MenuService;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * MenuController.java
 * @version
 * @since 2021. 6. 9.
 * @author Sim sung bo	
 */
@Slf4j
@Controller
@RequestMapping("/bo/Menu")
public class MenuController {
	
	@Autowired
	private MenuService menuService;
	
	/**
	 * <pre>
	 * 처리내용: 메뉴 관리 페이지를 보여준다.
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/viewMenu")
	public String viewMenu(MenuTreeVO menuVo, ModelMap model) {
		try {
			
			return "co/menuList";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 메뉴 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @param model
	 * @return CoResponseEntity
	 * @throws Exception
	 */
	@GetMapping("/getListMenu")
	@ResponseBody
	public ResponseEntity<?> getListMenu(MenuTreeVO menuVo, ModelMap model) throws Exception {

		List<MenuTreeVO> menuList = menuService.getListMenu(menuVo);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG, menuList), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 메뉴를 수정한다.
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @param model
	 * @return CoResponseEntity
	 * @throws Exception
	 */
	@PostMapping("/updateMenu")
	@ResponseBody
	public ResponseEntity<?> updateMenu(@Valid MenuTreeVO menuVo, BindingResult bindingResult, ModelMap model) throws Exception {
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		menuService.updateMenu(menuVo);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 메뉴를 삭제한다.
	 * </pre>
	 * @date 2021. 6. 14.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 14.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/deleteMenu")
	@ResponseBody
	public ResponseEntity<?> deleteMenu(MenuTreeVO menuVo, BindingResult bindingResult, ModelMap model) throws Exception {
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		menuService.deleteMenu(menuVo);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 메뉴를 등록한다.
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @param model
	 * @return CoResponseEntity
	 * @throws Exception
	 */
	@PostMapping("/insertMenu")
	@ResponseBody
	public ResponseEntity<?> insertMenu(@Valid MenuTreeVO menuVo, BindingResult bindingResult, HttpResponse response) throws Exception {
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		menuService.insertMenu(menuVo);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 메뉴-권한 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @param model
	 * @return CoResponseEntity
	 * @throws Exception
	 */
	@PostMapping("/getListAuthor")
	@ResponseBody
	public ResponseEntity<?> getListAuthor(@RequestBody MenuTreeVO menuVo, ModelMap model) throws Exception {
		
		List<AuthorMenuVO> authorList = menuService.getListAuthor(menuVo);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG, authorList, authorList.size()), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 모든 권한을 조회한다.
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @param model
	 * @return CoResponseEntity
	 * @throws Exception
	 */
	@PostMapping("/getListAllAuthor")
	@ResponseBody
	public ResponseEntity<?> getListAllAuthor(@RequestBody MenuTreeVO menuVo, ModelMap model) throws Exception {
		
		List<AuthorMenuVO> authorList = menuService.getListAllAuthor(menuVo);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG, authorList, authorList.size()), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 메뉴-권한을 등록한다.
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authList
	 * @param model
	 * @return CoResponseEntity
	 * @throws Exception
	 */
	@PostMapping("/insertAuth")
	@ResponseBody
	public ResponseEntity<?> insertAuth(@RequestBody List<AuthorMenuVO> authList, ModelMap model) throws Exception {
		
		menuService.insertAuth(authList);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 메뉴 트리 구조를 엑셀로 다운로드한다.
	 * </pre>
	 * @date 2021. 6. 11.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 11.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param menuList
	 * @param response
	 * @throws Exception
	 */
	@PostMapping("/excelDown")
	public void menuExcelDownload( MenuTreeVO menuList, HttpServletResponse response) throws Exception {
		
		menuService.menuExcelDownload(menuList, response);
		
	}
	
	/**
	 * <pre>
	 * 처리내용: sidebar 메뉴 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 7. 28.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 28.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/getSideBarMenu")
	public ResponseEntity<Object> getSideBarMenu(HttpServletRequest request) throws Exception {
		
		Map<String,Object> map = new HashMap<String,Object>();
		
		Account account = (Account) request.getSession().getAttribute("USER");
		
		/*
		 * 사용자 권한에 따른 사이드 메뉴 리스트 조회 
		 * Account account = (Account) request.getSession().getAttribute("USER");
		 * List<MenuVO> menuList = menuService.getAuthSideBarMenu(account);
		 */
		List<MenuVO> menuList;
		
		menuList = menuService.getSideBarMenu(account.getId()); //권한 없이 사이드 메뉴 모두 조회

		map.put("menuList", menuList);
		
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
}
