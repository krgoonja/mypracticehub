package com.sorincorp.bo.co.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sorincorp.bo.co.comm.BoCoConstants;
import com.sorincorp.bo.co.comm.CoResponseEntity;
import com.sorincorp.bo.co.model.AuthorMapVO;
import com.sorincorp.bo.co.model.AuthorVO;
import com.sorincorp.bo.co.model.DeptTreeVO;
import com.sorincorp.bo.co.model.EmpVO;
import com.sorincorp.bo.co.service.AuthorService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * AuthorController.java
 * @version
 * @since 2021. 6. 23.
 * @author Sim sung bo
 */
@Controller
@RequestMapping("/bo/Author")
@Slf4j
public class AuthorController {
	
	@Autowired
	private AuthorService authorService;
	
	/**
	 * <pre>
	 * 처리내용: 권한 관리 페이지를 보여준다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/viewAuthor")
	public String viewAuthor(ModelMap map) {
		try {
			
			return "co/authorList";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			
			return "error/503";
		}
		
	}
	
	/**
	 * <pre>
	 * 처리내용: 권한 추가 매핑 팝업을 보여준다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/authMapModalView")
	public String viewAuthMapModalView() throws Exception {
		return "co/authorMapPop";
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 해당 시스템의 권한 목록을 불러온다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param sysSeCode
	 * @param authorVo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/authorList/{sysSeCode}")
	public ResponseEntity<?> getAuthorList(@PathVariable String sysSeCode, @RequestBody AuthorVO authorVo) throws Exception{
		
		authorVo.setSysSeCode(sysSeCode);
		List<AuthorVO> authList = authorService.getAuthorList(authorVo);
		int totalCount = authorService.getAuthorListCnt(authorVo);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG, authList, totalCount), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 권한 목록을 엑셀 다운로드한다.
	 * </pre>
	 * @date 2021. 9. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param sysSeCode
	 * @param authorVo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/authorListForExcel/{sysSeCode}")
	public ResponseEntity<?> authorListForExcel(@PathVariable String sysSeCode, @RequestBody AuthorVO authorVo) throws Exception {
		Map<String,Object> map = new HashMap<>();
		
		authorVo.setSysSeCode(sysSeCode);
		authorVo.setRecordCountPerPage(10000000);
		List<AuthorVO> authList = authorService.getAuthorList(authorVo);
		
		map.put("dataList", authList);
		
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 선택 권한의 대한 상세내용을 불러온다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorNo
	 * @param authorVo
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/author/{authorNo}")
	public ResponseEntity<?> getAuthor(@PathVariable int authorNo, AuthorVO authorVo) throws Exception{
		
		authorVo.setAuthorNo(authorNo);
		AuthorVO authorDetail = authorService.getAuthor(authorVo);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG, authorDetail, null), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 권한 ID 중복 체크를 한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorId
	 * @param authorVo
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/authorCnt/{authorId}")
	public ResponseEntity<?> checkAuthorId(@PathVariable String authorId, AuthorVO authorVo) throws Exception{
		
		authorVo.setAuthorId(authorId);
		int authorCnt = authorService.checkAuthorId(authorVo);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG, authorCnt, null), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 권한을 등록한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorVo
	 * @param bindingfResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/author")
	public ResponseEntity<?> insertAuthor(@Valid AuthorVO authorVo, BindingResult bindingfResult) throws Exception{
		
		if(bindingfResult.hasErrors()) {
			return new ResponseEntity<>(bindingfResult.getAllErrors(), HttpStatus.BAD_GATEWAY);
		}
		authorService.insertAuthor(authorVo);
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 권한을 수정한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorNo
	 * @param authorVo
	 * @param bindingfResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/author/{authorNo}")
	public ResponseEntity<?> updateAuthor(@PathVariable int authorNo, @Valid AuthorVO authorVo, BindingResult bindingfResult) throws Exception{
		
		if(bindingfResult.hasErrors()) {
			return new ResponseEntity<>(bindingfResult.getAllErrors(), HttpStatus.BAD_GATEWAY);
		}
		
		authorService.updateAuthor(authorVo);
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 권한을 삭제한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorNo
	 * @param authorVo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/delAuthor/{authorNo}")
	public ResponseEntity<?> deleteAuthor(@PathVariable int authorNo, AuthorVO authorVo) throws Exception{
		
		authorVo.setAuthorNo(authorNo);
		authorService.deleteAuthor(authorVo);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 해당 권한에 매핑된 리스틑 불러온다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorNo
	 * @param authorVo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/authorMap/{authorNo}")
	public ResponseEntity<?> getAuthorMap(@PathVariable int authorNo, @RequestBody AuthorMapVO authorVo) throws Exception{
		
		authorVo.setAuthorNo(authorNo);
		List<AuthorMapVO> authMap = authorService.getAuthorMap(authorVo);
		int totalCount = authorService.getAuthorMapCnt(authorVo);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG, authMap, totalCount), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 매핑된 권한을 삭제한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorMapList
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/authorMap")
	public ResponseEntity<?> deleteAuthorMap(@RequestBody List<AuthorMapVO> authorMapList) throws Exception{
		
		authorService.deleteAuthorMap(authorMapList);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 부서리스트틑 불러온다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param deptVo
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/dept")
	public ResponseEntity<?> getDeptList(DeptTreeVO deptVo) throws Exception{

		List<DeptTreeVO> deptList = authorService.getDeptList(deptVo);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG, deptList), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 부서와 권한을 매핑시킨다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorNo
	 * @param deptList
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/dept/{authorNo}")
	public ResponseEntity<?> insertDeptAuthor(@PathVariable int authorNo, @RequestBody List<DeptTreeVO> deptList) throws Exception{

		authorService.insertDeptAuthor(authorNo, deptList);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 직원 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorNo
	 * @param empVo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/emp/{authorNo}")
	public ResponseEntity<?> getEmpList(@PathVariable int authorNo, @RequestBody EmpVO empVo) throws Exception{
		
		empVo.setAuthorNo(authorNo);
		List<EmpVO> authMap = authorService.getEmpList(empVo);
		int totalCount = authorService.getEmpListCnt(empVo);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG, authMap, totalCount), HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 직원과 권한을 매핑시킨다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorNo
	 * @param empList
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/empAuth/{authorNo}")
	public ResponseEntity<?> insertEmpAuthor(@PathVariable int authorNo, @RequestBody List<EmpVO> empList) throws Exception{

		authorService.insertEmpAuthor(authorNo, empList);
		
		return new ResponseEntity<>(new CoResponseEntity(BoCoConstants.SUCCESS_CODE, BoCoConstants.SUCCESS_MSG), HttpStatus.OK);
	}
}
