package com.sorincorp.bo.co.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.co.model.InnerUserVO;
import com.sorincorp.bo.co.service.InnerUserService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * InnerUserController.java
 * @version
 * @since 2021. 6. 21.
 * @author srec0033
 */
@Slf4j
@Controller
@RequestMapping("/bo/Inneruser")
@ComponentScan({"com.sorincorp.comm.*"})
public class InnerUserController {
	
	@Autowired 
	private InnerUserService innerUserService;
	
	/**
	 * <pre>
	 * 처리내용: 내부사용자 목록 페이지를 조회한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			srec0033			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectInneruserList")
	public String selectInneruserList() {
		try {
			
			return "co/innerUserList";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 내부사용자 목록 데이터를 조회한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param user
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectInneruserListData")
	@ResponseBody
	public Map<String, Object> selectInneruserListData(@RequestBody InnerUserVO user) throws Exception {
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		int totalDataCount = innerUserService.selectInneruserTotCnt(user);
		List<InnerUserVO> dataList = innerUserService.selectInneruserList(user);
		
		map.put("totalDataCount", totalDataCount);
		map.put("dataList", dataList);
		
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 내부사용자 목록을 조회한다.(엑셀 다운로드)
	 * </pre>
	 * @date 2021. 9. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectInneruserListDataForExcel")
	public ResponseEntity<?> selectNoticeListDataForExcel(@RequestBody InnerUserVO searchVO) throws Exception {
		Map<String,Object> map = new HashMap<>();
		searchVO.setRecordCountPerPage(10000000);
		List<InnerUserVO> dataList = innerUserService.selectInneruserList(searchVO);
		
		map.put("dataList", dataList);
		
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 내부사용자 상세정보를 조회한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param user
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectInneruserDetail")
	public String selectInneruserDetail(@RequestBody InnerUserVO user, ModelMap model) {
		try {
			model.put("userVO", user);
			
			return "co/innerUserDetail.modal";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			
			return "error/503";
		}
	}
	
}
