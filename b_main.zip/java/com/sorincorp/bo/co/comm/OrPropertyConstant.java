/**
 *
 */
package com.sorincorp.bo.co.comm;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Getter;

/**
 * OrPropertyConstant.java
 * @version
 * @since 2021. 11. 17.
 * @author srec0049
 */
@Getter
@Component
public class OrPropertyConstant {

	/** oms 송신 url **/
	@Value("${order.api.lo.oms.url}")
	private String loOmsUrl;

	/** ewallet 주문 url **/
	@Value("${order.api.ewallet.order.url}")
	private String ewalletOrderUrl;

	/** 세금계산서 url **/
	@Value("${order.api.taxbill.url}")
	private String taxbillUrl;

	/** 이월렛 타임아웃 **/
	@Value("${order.ewallet.timeoutsec}")
	private int ewalletTimeoutsec;

	/** 삼성선물 주문 url **/
	@Value("${order.api.samsung.order.url}")
	private String samsungOrderUrl;

	/** 삼성선물 claim 주문 url **/
	@Value("${order.api.samsung.claim.url}")
	private String samsungClaimUrl;

	/** 삼성선물 취소 url **/
	@Value("${order.api.samsung.cancel.url}")
	private String samsungCancelUrl;

	/** 삼성선물 주문 타입 **/
	@Value("${order.samsung.ordertype}")
	private String samsungOrdertype;

	/** 구매자금 대출보증 실행 **/
	@Value("${credit.loan.repy-url}")
	private String loanRepyUrl;

	@Value("${credit.loan.cancel-url}")
	private String loanRepyCanclUrl;

	/** 전자상거래보증 재처리 url */
	@Value("${credit.mrtgg.repy-url}")
	private String mrtggRepyUrl;

	/** 이월렛 상환 url */
	@Value("${credit.ewallet.repy-url}")
	private String repyEwalletUrl;

	/** 삼성선물 계좌번호 **/
	@Value("${order.samsung.acnut}")
	private String samsungAcnutNo;

	/** 이베스트증권 계좌번호 **/
	@Value("${order.ebest.acnut}")
	private String ebestAcnutNo;
	
	/** 재고할당 정보 송신 url **/
	@Value("${invntry.api.lo.asgn.url}")
	private String loInvntryAsgnUrl;
}