package com.sorincorp.bo.co.comm;

import lombok.Getter;

/**
 * 클레임 상수
 *
 * @version
 * @since 2021. 9. 9.
 * @author srec0051
 */
public class OrClaimConstants {

	/** 결제 구분 코드 */
	public static final String SETLE_SE_CODE_ORDER = "10";//주문
	public static final String SETLE_SE_CODE_CANCEL = "20";//취소
	public static final String SETLE_SE_CODE_RETURN = "30";//반품
	public static final String SETLE_SE_CODE_EXCHANGE = "40";//교환

	/** 결제 유형 코드 */
	public static final String SETLE_TY_CODE_SETTLE = "10";//정산 (케이지트레이딩 <-- 가상)
	public static final String SETLE_TY_CODE_REFUND = "20";//환불 (케이지트레이딩 --> 가상)

	/** 결제 상태 코드 */
	public static final String SETLE_STTUS_CODE_REQUEST = "01";//요청
	public static final String SETLE_STTUS_CODE_COMPLETE = "02";//완료
	public static final String SETLE_STTUS_CODE_FAIL = "03";//실패

	/** 이월렛 정산 유형 코드 */
	public static final String EXCCLC_TY_CODE_ORDER = "03";//주문
	public static final String EXCCLC_TY_CODE_CANCEL = "05";//취소
	public static final String EXCCLC_TY_CODE_EXCHANGE = "06";//교환
	public static final String EXCCLC_TY_CODE_RETURN = "07";//반품

	/*
	 * CANCL_EXCHNG_RTNGUD_TY_CODE 취소 교환 반품 유형 코드
	 */
	public enum TY_CODE {
		CANCEL("01", "취소"), RETURN("02", "반품"), EXCHANGE("03", "교환");

		@Getter
		private String code;
		@Getter
		private String name;

		private TY_CODE(String code, String name) {
			this.code = code;
			this.name = name;
		}

		public static String codeToName(String code) {
			for (TY_CODE v : TY_CODE.values()) {
				if (v.code.equals(code)) {
					return v.getName();
				}
			}
			return null;
		}
	}

	/*
	 * CANCL_EXCHNG_RTNGUD_STTUS_CODE 취소 교환 반품 상태 코드
	 */
	public enum STTUS_CODE {
		REGIST("01", "등록"), CONFIRMED("02", "확정"), PROPOSAL("03", "신청"),
//		FTRS_COMPLETE("10", "선물처리완료"), FSHG_COMPLETE("20", "선물환처리완료"), EWALLET_COMPLETE("30", "이월렛처리완료"),
//		TAKE_AWAY_DIRECT("03", "수거지시"),
//		WARE_HOUSE_COMPLETE("04", "입고완료"),
		PROCESSING("04", "처리중"), COMPLETION("05", "완료"), FAIL("90", "실패");

		@Getter
		private String code;
		@Getter
		private String name;

		private STTUS_CODE(String code, String name) {
			this.code = code;
			this.name = name;
		}

	}

	/*
	 * CANCL_EXCHNG_RTNGUD_RESN_CODE 취소 교환 반품 사유 코드
	 */
	public enum RESN_CODE {
		CUSTOMER_CHANGE("10", "고객변심"), PRODUCT_DEFECT("20", "상품결함"), WRONG_DELIVERY("30", "오배송");

		@Getter
		private String code;
		@Getter
		private String name;

		private RESN_CODE(String code, String name) {
			this.code = code;
			this.name = name;
		}

	}

	/*
	 * DLVY_SE_CODE 배송 구분 코드
	 */
	public enum DLVY_SE_CODE {
		DELIVERY("01", "배송"), TAKE_AWAY("02", "수거");

		@Getter
		private String code;
		@Getter
		private String name;

		private DLVY_SE_CODE(String code, String name) {
			this.code = code;
			this.name = name;
		}

	}

	/*
	 * DLVY_MN_CODE 배송 수단 코드
	 */
	public enum DLVY_MN_CODE {
		DELIVERY("01", "케이지배송"), TAKE_AWAY("02", "자차배송");

		@Getter
		private String code;
		@Getter
		private String name;

		private DLVY_MN_CODE(String code, String name) {
			this.code = code;
			this.name = name;
		}

	}

}
