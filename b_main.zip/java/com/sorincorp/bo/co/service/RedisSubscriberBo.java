package com.sorincorp.bo.co.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.bo.sample.service.LimitDataUtil;
import com.sorincorp.comm.limit.service.LimitService;
import com.sorincorp.comm.limit.service.OrLimitOrderBasVoMapService;
import com.sorincorp.comm.limit.service.PrSelVoService;
import com.sorincorp.comm.order.model.CommLimitOrderQueueMsgVO;
import com.sorincorp.comm.order.model.CommLimitOrderRedisMsgVO;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.premium.service.ItPremiumStdrBasVoService;
import com.sorincorp.comm.redis.config.RedisPubSubMessage;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class RedisSubscriberBo implements MessageListener {	// RedisPubSubListener<String, Object>
	@Autowired
	private SimpMessagingTemplate simpMessagingTemplate;

	@Autowired
	private PcInfoService pcInfoService;

	@Autowired
	private LimitService limitService;

	@Autowired
	private ItPremiumStdrBasVoService itPremiumStdrBasVoService;

	private final OrLimitOrderBasVoMapService orderLimitOrderBasVoMapService;

	@Value("${redisPubsub.uri.fx}")
	private String fxpcUri;

	@Value("${redisPubsub.crncyCode.KRW}")
	private String fxpcKRW;

	@Value("${redisPubsub.uri.restTime}")
	private String restTimeUri;

	@Value("${redisPubsub.uri.startLmeData}")
	private String startLmeDataUri;

	@Value("${redisPubsub.uri.limit}")
	private String limitUri;

	@Value("${redisPubsub.uri.sel}")
	private String selUri;

	@Value("${redisPubsub.uri.premium}")
	private String premiumUri;

	@Value("${redisPubsub.uri.invntry}")
	private String invntryUri;

	@Value("${metalCode.list}")
	private List<String> metalCodeList;
	
	@Value("${redisPubsub.uri.selpcAll}")
	private String selpcAll;

	@Value("${redisPubsub.uri.properties}")
	private String propertiesUri;

	private final PrSelVoService prSelVoService;
	//private final OrderLimitOrderBasVoMapService orderLimitOrderBasVoMapService;

	@Autowired
	public RedisSubscriberBo(PrSelVoService prSelVoService
			, OrLimitOrderBasVoMapService orderLimitOrderBasVoMapService) {
		this.prSelVoService = prSelVoService;
		this.orderLimitOrderBasVoMapService = orderLimitOrderBasVoMapService;
	}

	@PostConstruct
	public void init() throws Exception {
		// 프리미엄 가격 초기값 세팅
		Map<String, TreeSet<LivePremiumVO>> originalMap = pcInfoService.getPremiumInfoMap();
		itPremiumStdrBasVoService.setItPremiumStdrBasVo(originalMap);

		log.debug("0) init premiumMap Setting");
	}

	/*
	@PostConstruct
	public void init() throws Exception {
		//log.debug("여기 먼저1");
		ObjectMapper objectMapper = new ObjectMapper();

		// 지정가 초기값 세팅
		orderLimitOrderBasVoMapService.setOrderCommLimitOrderRedisMsgVoMap(limitService.loadInitialLimitData());
		String result = objectMapper.writeValueAsString(orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());	// TODO [pje] 테스트용 - 삭제예정
		log.debug("*** initial Order Limit Data: " + result);
		//calculateLimitPremiumExclAmount();

	}*/

	@Override
	public void onMessage(Message message, byte[] pattern) {
		byte[] messageBody = message.getBody();
		ByteArrayInputStream in = new ByteArrayInputStream(messageBody);
		//ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ObjectInputStream is =null;
		RedisPubSubMessage pubSubMsg = null;
		try {
			is = new ObjectInputStream(in);
			pubSubMsg = (RedisPubSubMessage) is.readObject();
			String channel = pubSubMsg.getChannelId();

			if(channel.equals(fxpcUri + "/" + fxpcKRW)) {
				Map<String, String> map = new HashedMap<>();
				map = objMapper.readValue(pubSubMsg.getMessage().toString(), Map.class);
				simpMessagingTemplate.convertAndSend(fxpcUri + "/" + fxpcKRW, map);
			} else if(channel.equals(restTimeUri)) {
				if("setRestTime".equals(pubSubMsg.getMessage().toString())){
					simpMessagingTemplate.convertAndSend(channel , pubSubMsg.getMessage().toString());
				}
			} else if(channel.equals(startLmeDataUri)) {
				if(pubSubMsg.getMessage().toString().contains("startLmeData")){
					simpMessagingTemplate.convertAndSend(channel , pubSubMsg.getMessage().toString());
				}
			} else if(channel.contains(selUri)) {
				if (channel.startsWith(selUri + "/")) {
					String[] channelSplit = channel.split("/");
					String code = channelSplit[channelSplit.length - 1];
					if (metalCodeList.contains(code)) {
						PrSelVO vo = objMapper.readValue(pubSubMsg.getMessage().toString(), PrSelVO.class);
						BeanUtils.copyProperties(vo, prSelVoService.getPrSelVo(vo.getMetalCode())); // 받은 값 복사
						//checkLimitData(vo);

					}
					simpMessagingTemplate.convertAndSend(channel, pubSubMsg.getMessage().toString());
				} else if(channel.contains(selpcAll)) {
					if (channel.startsWith(selpcAll + "/")) {
					    simpMessagingTemplate.convertAndSend(channel , pubSubMsg.getMessage().toString());
					}
				}
			} else if(channel.equals(premiumUri)) {
				if(pubSubMsg.getMessage().toString().contains(LimitDataUtil.LimitOrderSttusCode.UPDATE.value)){

					Map<String, TreeSet<LivePremiumVO>> originalMap = pcInfoService.getPremiumInfoMap();
					itPremiumStdrBasVoService.setItPremiumStdrBasVo(originalMap);
					simpMessagingTemplate.convertAndSend(channel, pubSubMsg.getMessage().toString());
					//calculateLimitPremiumExclAmount();
				}
			} else if(channel.contains(invntryUri)) {
				if(channel.startsWith(invntryUri + "/")) {
					String[] channelSplit = channel.split("/");
					String code = channelSplit[channelSplit.length - 1];
					if (metalCodeList.contains(code)) {

						simpMessagingTemplate.convertAndSend(channel, pubSubMsg.getMessage().toString());
					}
				}
			} else {
				simpMessagingTemplate.convertAndSend(channel, pubSubMsg.getMessage().toString());
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.debug(message.toString());
		}
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			log.debug(message.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/* ### 수신받은 지정가 데이터 저장 로직 ###
	 * 1. 그룹키 생성
	 * 2. 지정가주문번호-지정가입력금액 map 및 종목별 지정가 주문 리스트 세팅
	 *
	 * 3. 저장된 지정가 주문번호가 없는 경우 insert 되지 않은 상태이므로, 저장하는 로직만 타고 return
	 * 		- 프리미엄 제외 금액 계산하여 저장
	 * 4. 이미 저장된 지정가 주문번호가 있는 경우
	 * 		4-1. Update인 경우
	 * 			- 종목별 지정가 주문 리스트에서 해당 주문번호 데이터 삭제 후, 다시 insert
	 * 			- 지정가주문번호-지정가입력금액 map update
	 * 			- 프리미엄 제외 금액 계산하여 저장
	 * 		4-2. Delete인 경우
	 * 			- 종목별 지정가 주문 리스트와 지정가주문번호-지정가입력금액 map에서 삭제
	 */
	private void saveLimitData(CommLimitOrderRedisMsgVO redisVo) {
		try {

			Map<String, String> map = new HashMap<>();
			LocalDateTime now = LocalDateTime.now();

			ObjectMapper objectMapper = new ObjectMapper();	// TODO [pje] 테스트용 - 삭제 예정
			// 1. 그룹키 생성
			String groupKey = limitService.generateKey(redisVo);

			// 2. 지정가주문번호-지정가입력금액 map 및 종목별 지정가 주문 리스트 세팅
			CommLimitOrderRedisMsgVO limitOrderNoInputAmountVo = orderLimitOrderBasVoMapService.getLimitOrderNoInputAmountVo(redisVo.getLimitOrderNo());	// 지정가주문번호-지정가입력금액 map

			// 3. 저장된 지정가 주문번호가 없는 경우 - insert 되지 않은 상태이므로, 저장하는 로직만 타고 return
			if(limitOrderNoInputAmountVo.getLimitInputAmount() == 0) {
				orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(groupKey).add(redisVo);
				limitOrderNoInputAmountVo.setLimitInputAmount(redisVo.getLimitInputAmount());

				String result = objectMapper.writeValueAsString(orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());	// TODO [pje] 테스트용 - 삭제예정
				log.debug("1-1!!!) limit data insert: " + result);

				limitOrderNoInputAmountVo.setLimitInputAmount(redisVo.getLimitInputAmount());

				// 프리미엄 제외 금액 계산
				//calculateLimitPremiumExclAmount(groupKey, redisVo);
				return;
			}

			/* 4-1. Update인 경우
			 * 		- 종목별 지정가 주문 리스트에서 해당 주문번호 데이터 삭제 후, 다시 insert
			 * 		- 지정가주문번호-지정가입력금액 map update
			*/
			if(redisVo.getIntrfcSttusCode().equals(LimitDataUtil.LimitOrderSttusCode.UPDATE.value)) {
				CommLimitOrderRedisMsgVO oldVo = orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(groupKey)
						.stream()
						.filter(vo -> vo.getLimitOrderNo().equals(redisVo.getLimitOrderNo()))
						.findFirst()
						.orElse(null);

				orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(groupKey).remove(oldVo);	// 기존에 존재하는 주문번호 VO를 List에서 삭제
				orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(groupKey).add(redisVo);		// 레디스에서 받은 새로운 가격을 key로 하는 List에서 레디스에서 받은 VO 값 add
				limitOrderNoInputAmountVo.setLimitInputAmount(redisVo.getLimitInputAmount());

				String result = objectMapper.writeValueAsString(orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());	// TODO [pje] 테스트용 - 삭제예정
				log.debug("1-2) limit data update: " + result);

				//calculateLimitPremiumExclAmount(groupKey, redisVo);
				return;
			}

			/*
			 * 4-2. Delete인 경우
			 * 	   - 종목별 지정가 주문 리스트와 지정가주문번호-지정가입력금액 map, 시간별 지정가 주문 리스트에서 삭제
			 */
			if(redisVo.getIntrfcSttusCode().equals(LimitDataUtil.LimitOrderSttusCode.DELETE.value)) {
				orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(groupKey).remove(redisVo); // 기존에 존재하는 주문번호 VO를 List에서 삭제
				orderLimitOrderBasVoMapService.removeLimitOrderNoInputAmountVo(redisVo.getLimitOrderNo());

				String result = objectMapper.writeValueAsString(orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());			// TODO [pje] 테스트용 - 삭제예정
				log.debug("1-3) limit data delete: " + result);
			}
		} catch(Exception e) {
			log.error("[saveLimitData Error] {}", ExceptionUtils.getStackTrace(e));
		}
	}

	/*
	 * 판매 가격 데이터를 수신 받은 경우, 지정가 확인하여 기준에 맞는 데이터인지 체크
	 *
	 * 1) 큐 레이아웃에 맞는 데이터 설정
	 * 2) 지정가와 판매가격 비교하여 일치하는 데이터 amountGroupedMap에 저장
	 * 3) 종목별로 큐에 넘겨줄 최종 데이터를 세팅 후 큐에 전송
	 * 4) 전송된 데이터 메모리에서 제거
	 */
	private synchronized void checkLimitData(PrSelVO prSelVo) {
		//log.debug("3-0)" + prSelVo.getMetalCode());
		// 1) 큐 레이아웃에 맞는 데이터 설정
		CommLimitOrderQueueMsgVO queueVo = new CommLimitOrderQueueMsgVO();
		queueVo.setLimitOrderRequestDt("" + prSelVo.getOccrrncDe() + prSelVo.getOccrrncTime());	// 지정가 주문 요청 일시
		queueVo.setSlePcRltmSn(prSelVo.getSlePcRltmSn());										// 판매 가격 실시간 순번
		queueVo.setLmePcRltmSn(prSelVo.getLmePcRltmSn());										// LME 가격 실시간 순번
		queueVo.setLme3m(prSelVo.getThreemonthLmePc());											// LME 3M
		queueVo.setLmeCash(prSelVo.getLmePc());													// LME 현금
		queueVo.setLmeMdatCffcnt(prSelVo.getLmeMdatCffcnt());									// LME 조정계수
		queueVo.setEhgtPcRltmSn(prSelVo.getEhgtPcRltmSn());										// 환율 가격 실시간 순번
		queueVo.setSpex(prSelVo.getEhgtPc());													// 환율 가격
		queueVo.setSpexMdatCffcnt(prSelVo.getFxMdatCffcnt());									// 환율 조정계수

		if(orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap().isEmpty())
			return;

		orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap().entrySet().stream().forEach(entry -> {
			String key = entry.getKey();

			// 지정가 가격 리스트
			TreeSet<CommLimitOrderRedisMsgVO> orderLimitList = orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(key);

			/*
			 * 2) 지정가와 판매가격 비교하여 일치하는 데이터 amountGroupedMap에 저장
			 *
			 * 시간대별 지정가 가격 리스트에서 수신 받은 판매 데이터의 메탈 코드와 일치하고,
			 * 현재 시간 범위에 있는, 수신 받은 판매가격보다 큰 지정가 리스트로 필터링
			 */
			TreeSet<CommLimitOrderRedisMsgVO> amountGroupedSet = orderLimitList.stream()
					.filter(vo -> vo.getLimitPremiumExclAmount() >= prSelVo.getEndPc() && vo.getMetalCode().equals(prSelVo.getMetalCode()))
					.collect(Collectors.toCollection(TreeSet::new));

			/*Map<Long, TreeSet<CommLimitOrderRedisMsgVO>> amountGroupedMap = orderLimitList.stream()
					.filter(redisVo -> redisVo.getLimitPremiumExclAmount() >= prSelVo.getEndPc()
							&& prSelVo.getMetalCode().equals(redisVo.getMetalCode()))
					.collect(Collectors.groupingBy(CommLimitOrderRedisMsgVO::getLimitPremiumExclAmount,
								Collectors.toCollection(TreeSet::new)));
			*/

			if(amountGroupedSet.isEmpty())
				return;

			ObjectMapper objectMapper = new ObjectMapper();	// TODO [pje] 테스트용 - 삭제예정
			try {
				String result = objectMapper.writeValueAsString(amountGroupedSet);			// TODO [pje] 테스트용 - 삭제예정

				log.debug("3-1) Matching metalCode: " + prSelVo.getMetalCode());
				log.debug("3-2) prSelVo endPc: " + prSelVo.getEndPc());
				log.debug("3-3) Matching amount map: " + result);
			} catch(Exception e) {

			}

			// amountGroupedMap에 있는 주문번호 리스트
			/*List<String> limitOrderNoList = amountGroupedMap.values().stream()
					.flatMap(Set::stream)
					.map(CommLimitOrderRedisMsgVO::getLimitOrderNo)
					.map(Object::toString)
					.collect(Collectors.toList());
			*/

			List<String> limitOrderNoList = amountGroupedSet.stream()
					.map(CommLimitOrderRedisMsgVO::getLimitOrderNo)
					.collect(Collectors.toList());

			//amountGroupedMap.entrySet().stream().forEach(amountEntry -> {
				//Long amountKey = amountEntry.getKey();
			queueVo.setLimitOrderStdrSlePc(prSelVo.getEndPc());

				///////////////////////////////////////////////////////////////////////
			log.debug("3-4) key: " + key);
				//queueVo.setLimitOrderStdrSlePc(prSelVo.getEndPc());

			log.debug("3-5) queueVo: " + queueVo);

			try {
				// 3) 종목별로 큐에 넘겨줄 최종 데이터를 세팅 후 큐에 전송
				limitService.settingLimitQueueData(amountGroupedSet, queueVo);

				// 4) 전송된 데이터 메모리에서 제거
				orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(key).removeIf(item -> limitOrderNoList.contains(item.getLimitOrderNo()));

				String result = objectMapper.writeValueAsString(orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());			// TODO [pje] 테스트용 - 삭제예정
				log.debug("6-1) After Sending Data to the Queue: " + result);
			} catch (Exception e) {
				log.error("[amountGroupedMap Error] {}", ExceptionUtils.getStackTrace(e));
			}
		});
		//});
	}

	private CommLimitOrderRedisMsgVO createOrderLimitByTimeVO(CommLimitOrderRedisMsgVO receiveLimitVO, LivePremiumVO livePremiumVO) {
		CommLimitOrderRedisMsgVO orderLimitByTimeVO = new CommLimitOrderRedisMsgVO();

		orderLimitByTimeVO.setLimitOrderNo(receiveLimitVO.getLimitOrderNo());
		orderLimitByTimeVO.setIntrfcSttusCode(receiveLimitVO.getIntrfcSttusCode());
		orderLimitByTimeVO.setLimitOrderDt(receiveLimitVO.getLimitOrderDt());
		orderLimitByTimeVO.setEntrpsNo(receiveLimitVO.getEntrpsNo());
		orderLimitByTimeVO.setMetalCode(receiveLimitVO.getMetalCode());
		orderLimitByTimeVO.setItmSn(receiveLimitVO.getItmSn());
		orderLimitByTimeVO.setDstrctLclsfCode(receiveLimitVO.getDstrctLclsfCode());
		orderLimitByTimeVO.setBrandGroupCode(receiveLimitVO.getBrandGroupCode());
		orderLimitByTimeVO.setBrandCode(receiveLimitVO.getBrandCode());
		orderLimitByTimeVO.setLimitInputAmount(receiveLimitVO.getLimitInputAmount());
		orderLimitByTimeVO.setCstmrOrderWt(receiveLimitVO.getCstmrOrderWt());
		orderLimitByTimeVO.setStdrPremiumCnvrsnAmount(receiveLimitVO.getStdrPremiumCnvrsnAmount());

		orderLimitByTimeVO.setLimitPremiumExclAmount(receiveLimitVO.getLimitInputAmount() - livePremiumVO.getSlePremiumAmount());
		orderLimitByTimeVO.setValidBeginDt(livePremiumVO.getValidBeginDt());
		orderLimitByTimeVO.setValidEndDt(livePremiumVO.getValidEndDt());

		return orderLimitByTimeVO;
	}

}
