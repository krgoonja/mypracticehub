package com.sorincorp.bo.co.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.co.model.InnerUserCcpyVO;

public interface InnerUserCcpyService{
	
	/**
	 * <pre>
	 * 처리내용: 내부사용자_협력업체 목록을 조회한다.
	 * </pre>
	 * @date 2023. 4. 14.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 14.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param user
	 * @return
	 * @throws Exception
	 */
	List<InnerUserCcpyVO> selectInneruserCcpyList(InnerUserCcpyVO user) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 내부사용자_협력업체 총 개수를 조회한다.
	 * </pre>
	 * @date 2023. 4. 14.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 14.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param user
	 * @return
	 * @throws Exception
	 */
	int selectInneruserCcpyTotCnt(InnerUserCcpyVO user) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 두 테이블 간 내부사용자 아이디 중복체크 여부를 확인한다.
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param userId
	 * @return
	 */
	int idCheck(String userId);

	/**
	 * <pre>
	 * 처리내용: 내부사용자_협력업체 목록을 등록 및 수정한다.
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param userList
	 * @return
	 * @throws Exception
	 */
	int insertAndUpdateGridDataList(List<InnerUserCcpyVO> userList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 내부사용자_협력업체 목록을 등록한다.
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param user
	 * @return
	 * @throws Exception
	 */
	int insertInneruserCcpy(InnerUserCcpyVO user) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 내부사용자_협력업체 목록을 수정한다.
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param user
	 * @return
	 * @throws Exception
	 */
	int updateInneruserCcpy(InnerUserCcpyVO user) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 내부사용자_협력업체 목록을 삭제 한다.
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param userList
	 * @return
	 */
	int deleteInneruserCcpy(List<InnerUserCcpyVO> userList);

	/**
	 * <pre>
	 * 처리내용: 직위명을 가져온다.
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0082			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<Map<String, String>> getKoreanOfcpsNm();

	/**
	 * <pre>
	 * 처리내용: 직급명을 가져온다.
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0082			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<Map<String, String>> getKoreanClsfNm();

	/**
	 * <pre>
	 * 처리내용: 직책명을 가져온다.
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0082			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<Map<String, String>> getKoreanRspofcNm();

	/**
	 * <pre>
	 * 처리내용: 사업장명을 가져온다.
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0082			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<Map<String, String>> getKoreanBplcNm();

	/**
	 * <pre>
	 * 처리내용: 내부사용자_협력업체 목록을 단건 조회한다.
	 * </pre>
	 * @date 2023. 4. 28.
	 * @author srec0082
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 28.			srec0082			최초작성
	 * ------------------------------------------------
	 * @param user
	 * @return
	 * @throws Exception
	 */
	InnerUserCcpyVO selectInneruserCcpy(InnerUserCcpyVO user) throws Exception;

}
