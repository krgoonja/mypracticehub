package com.sorincorp.bo.co.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.sorincorp.comm.common.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.co.mapper.CmmnCodeMapper;
import com.sorincorp.bo.co.model.CmmnCodeVO;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.brandgroupcode.mapper.BrandGroupCodeMapper;
import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.CacheUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * CmmnCodeServiceImpl.java
 * @version
 * @since 2021. 6. 9.
 * @author srec0033
 */
@Slf4j
@Service
public class CmmnCodeServiceImpl implements CmmnCodeService {

	@Autowired
	private CmmnCodeMapper codeMapper;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private BrandGroupCodeMapper brandGroupCodeMapper;

	@Autowired
	private CacheUtil cacheUtil;

	@Autowired
	private CommonService commonService;

	/**
	 * 메인코드 목록을 조회한다.
	 */
	@Override
	public List<CmmnCodeVO> selectCmmnMainCodeList(CmmnCodeVO searchVO) throws Exception {
		return codeMapper.selectCmmnMainCodeList(searchVO);
	}

	/**
	 * 공통코드의 총 갯수를 조회한다.
	 */
	@Override
	public int selectCmmnCodeListTotcnt(CmmnCodeVO searchVO) throws Exception {
		return codeMapper.selectCmmnCodeListTotcnt(searchVO);
	}

	/**
	 * 서브코드 목록을 조회한다.
	 */
	@Override
	public List<CmmnCodeVO> selectCmmnSubCodeList(CmmnCodeVO mainCode) throws Exception {
		return codeMapper.selectCmmnSubCodeList(mainCode);
	}

	/**
	 * 공통코드를 등록한다.
	 */
	@Override
	public void insertCmmnCode(CmmnCodeVO codeVO) throws Exception {
		Account account= userInfoUtil.getAccountInfo();
		String userId = "";
		if(account != null) {
			userId = account.getId();
		}
		codeVO.setFrstRegisterId(userId);
		codeVO.setLastChangerId(userId);

		//숫자 참조 numeric 변환
		codeVO = convertNumRefToNumeric(codeVO);
		String subCode =codeVO.getSubCode();

		if(subCode == null || subCode.isEmpty()) { //서브코드가 없다면 메인코드 등록의 경우
			codeVO.setSubCode("@");				   //서브코드 존재시 서브코드 등록 - 바로 insert
		}

		log.debug("insertCmmnCode code1 : " + codeVO);

		codeMapper.insertCmmnCode(codeVO);
		//codeMapper.insertCmmnCodeHistory(codeVO);
		commonService.insertTableHistory("CO_CMMN_CD",codeVO);
		
		commonCodeService.initCommonCodeByMainCode(codeVO.getMainCode());
	}

	/**
	 * <pre>
	 * 처리내용: 숫자 참조값을 numeric으로 변환하여 리턴한다.
	 * </pre>
	 * @date 2021. 11. 17.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 17.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param codeVO
	 * @return
	 */
	private CmmnCodeVO convertNumRefToNumeric(CmmnCodeVO codeVO) {
		if(!StringUtil.isNull(codeVO.getNumber1()) && StringUtil.isNotEmpty(codeVO.getNumber1())) {
			BigDecimal num1 = new BigDecimal(codeVO.getNumber1());
			codeVO.setCodeNumberRefrnone(num1);
		}

		if(!StringUtil.isNull(codeVO.getNumber2()) && StringUtil.isNotEmpty(codeVO.getNumber2())) {
			BigDecimal num2 = new BigDecimal(codeVO.getNumber2());
			codeVO.setCodeNumberRefrntwo(num2);
		}

		if(!StringUtil.isNull(codeVO.getNumber3()) && StringUtil.isNotEmpty(codeVO.getNumber3())) {
			BigDecimal num3 = new BigDecimal(codeVO.getNumber3());
			codeVO.setCodeNumberRefrnthree(num3);
		}

		if(!StringUtil.isNull(codeVO.getNumber4()) && StringUtil.isNotEmpty(codeVO.getNumber4())) {
			BigDecimal num4 = new BigDecimal(codeVO.getNumber4());
			codeVO.setCodeNumberRefrnfour(num4);
		}
		return codeVO;
	}

	/**
	 * 공통코드를 수정한다.
	 */
	@Override
	public void updateCmmnCode(CmmnCodeVO codeVO) throws Exception {
		codeVO = convertNumRefToNumeric(codeVO);
		codeMapper.updateCmmnCode(codeVO);
		//codeMapper.insertCmmnCodeHistory(codeVO);
		if(StringUtil.isEmpty(codeVO.getSubCode())){
			codeVO.setSubCode("@");
		}
		commonService.insertTableHistory("CO_CMMN_CD",codeVO);
		
		commonCodeService.initCommonCodeByMainCode(codeVO.getMainCode());
	}

	/**
	 *	메인코드PK를 수정한다.
	 */
	public void updateMaincodePK(CmmnCodeVO mainVO) throws Exception {

		Account account= userInfoUtil.getAccountInfo();
		String userId = "";
		if(account != null) {
			userId = account.getId();
		}
		mainVO.setLastChangerId(userId);

		codeMapper.updateMaincodePK(mainVO);
		//codeMapper.insertCmmnCodeHistory(mainVO);
		if(StringUtil.isEmpty(mainVO.getSubCode())){
			mainVO.setSubCode("@");
		}
		commonService.insertTableHistory("CO_CMMN_CD",mainVO);

		commonCodeService.initCommonCodeByMainCode(mainVO.getNewMainCode());
	}

	/**
	 *  공통코드를 삭제한다.
	 */
	@Override
	public void deleteCmmnCode(CmmnCodeVO codeVO) throws Exception {
		codeMapper.deleteCmmnCode(codeVO);
		//codeMapper.insertCmmnCodeHistory(codeVO);
		if(StringUtil.isEmpty(codeVO.getSubCode())){
			codeVO.setSubCode("@");
		}
		commonService.insertTableHistory("CO_CMMN_CD", codeVO);
		
		commonCodeService.initCommonCodeByMainCode(codeVO.getMainCode());
	}

	/**
	 * 공통코드 정보를 삽입, 수정한다.
	 */
	@Override
	public void insertAndUpdateCodeList(List<CmmnCodeVO> codeList) throws Exception {

		Account account= userInfoUtil.getAccountInfo();
		String userId = "";
		if(account != null) {
			userId = account.getId();
		}

		for (int i = 0; i < codeList.size(); i++) {
			String status = codeList.get(i).getGridRowStatus();
			CmmnCodeVO data = codeList.get(i);
			data.setFrstRegisterId(userId);
			data.setLastChangerId(userId);

			if(status.equals("created")) {
				insertCmmnCode(data);
			} else if(status.equals("updated")) {
				updateCmmnCode(data);
			}
		}

		BrandGroupCodeVO brandGroupCodeVO = new BrandGroupCodeVO();
		List<BrandGroupCodeVO> brandGroupCodeList = brandGroupCodeMapper.getBrandGroupCode(brandGroupCodeVO);
		cacheUtil.put("brandGroupCodeList", brandGroupCodeList);
	}

	/**
	 * 공통코드 정보를 삭제한다.
	 */
	@Override
	public void deleteGridDataList(List<CmmnCodeVO> codeList) throws Exception {
		log.debug("deleteGridDataList delete codeList >>> " + codeList);

		Account account= userInfoUtil.getAccountInfo();
		String userId = "";
		if(account != null) {
			userId = account.getId();
		}

		//들어온 코드목록 삭제
		for (int i = 0; i < codeList.size(); i++) {
			codeList.get(i).setFrstRegisterId(userId);
			codeList.get(i).setLastChangerId(userId);
			deleteCmmnCode(codeList.get(i));

			//메인코드삭제일 경루 => 서브코드 목록까지 삭제
			String subCd = codeList.get(i).getSubCode();
			if(subCd.equals("@") || subCd.equals("")) { 		//메인코드 삭제
				List<CmmnCodeVO> subList = selectCmmnSubCodeList(codeList.get(0));
				log.debug("deleteGridDataList subList >>> " + subList);

				for (int j = 0; j < subList.size(); j++) {
					deleteCmmnCode(subList.get(j));			//메인코드 하위 서브코드들 삭제
				}
			}
		}
	}

	/**
	 * 레디스를 전체 갱신한다.
	 */
	@Override
	public Map<String, String> updateRedis(){
		Map<String, String> result = new HashMap<String, String>();

		try {
			List<String> maincodeList = codeMapper.selectAllMainCodes();
			for (String maincode: maincodeList) {
				commonCodeService.initCommonCodeByMainCode(maincode);
			}
			
			result.put("msg", "REDIS 전체갱신에 성공했습니다.");
		} catch (Exception e) {
			log.debug("reids 갱신 실패 >> " + e.getMessage());
			result.put("msg", "REDIS 전체갱신에 실패했습니다.");
		}
		
		return result;
	}

}
