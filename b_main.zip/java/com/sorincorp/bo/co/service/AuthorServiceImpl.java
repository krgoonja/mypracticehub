package com.sorincorp.bo.co.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sorincorp.comm.common.service.CommonService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.co.comm.BoCoConstants;
import com.sorincorp.bo.co.mapper.AuthorMapper;
import com.sorincorp.bo.co.model.AuthorMapVO;
import com.sorincorp.bo.co.model.AuthorVO;
import com.sorincorp.bo.co.model.DeptTreeVO;
import com.sorincorp.bo.co.model.EmpVO;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.util.CryptoUtil;

@Service
public class AuthorServiceImpl implements AuthorService{

	@Autowired
	private AuthorMapper authorMapper;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private CommonService commonService;

	@Override
	public List<AuthorVO> getAuthorList(AuthorVO authorVo) throws Exception {
		List<AuthorVO> authorList = authorMapper.getAuthorList(authorVo);
		return authorList;
	}

	@Override
	public int getAuthorListCnt(AuthorVO authorVo) throws Exception {
		return authorMapper.getAuthorListCnt(authorVo);
	}

	@Override
	public AuthorVO getAuthor(AuthorVO authorVo) throws Exception {
		return authorMapper.getAuthor(authorVo);
	}

	@Override
	public int checkAuthorId(AuthorVO authorVo) throws Exception {
		return authorMapper.checkAuthorId(authorVo);
	}

	@Override
	public void insertAuthor(AuthorVO authorVo) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		String userId ="";
		if(account != null) {
			userId = account.getId();
		}

		authorVo.setFrstRegisterId(userId);
		authorVo.setLastChangerId(userId);
		authorMapper.insertAuthor(authorVo);

		authorVo.setAuthorNo(authorVo.getAuthorNo());
		authorMapper.insertAuthHist(authorVo);
		//commonService.insertTableHistory("CO_AUTHOR_BAS",authorVo);
	}

	@Override
	public void updateAuthor(AuthorVO authorVo) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		String userId ="";
		if(account != null) {
			userId = account.getId();
		}
		authorVo.setLastChangerId(userId);

		authorMapper.updateAuthor(authorVo);
		authorMapper.insertAuthHist(authorVo);
		//commonService.insertTableHistory("CO_AUTHOR_BAS",authorVo);
	}

	@Override
	public void deleteAuthor(AuthorVO authorVo) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		String userId ="";
		if(account != null) {
			userId = account.getId();
		}
		authorVo.setLastChangerId(userId);

		authorMapper.deleteAuthor(authorVo);
		authorMapper.insertAuthHist(authorVo);
		//commonService.insertTableHistory("CO_AUTHOR_BAS",authorVo);
	}

	@Override
	public List<AuthorMapVO> getAuthorMap(AuthorMapVO authorVo) throws Exception {
		List<AuthorMapVO> authorMap = authorMapper.getAuthorMap(authorVo);

		for (AuthorMapVO authorMapVO : authorMap) {
			if (StringUtils.isNotBlank(authorMapVO.getCryalTlphonNo())) {
				authorMapVO.setCryalTlphonNo(CryptoUtil.decryptAES256(authorMapVO.getCryalTlphonNo()));	//복호화
			}
		}

		return authorMap;
	}

	@Override
	public int getAuthorMapCnt(AuthorMapVO authorVo) throws Exception {
		return authorMapper.getAuthorMapCnt(authorVo);
	}

	@Override
	public void deleteAuthorMap(List<AuthorMapVO> authorMapList) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		String userId ="";
		if(account != null) {
			userId = account.getId();
		}
		for(AuthorMapVO authMapVo : authorMapList) {
			authMapVo.setLastChangerId(userId);
			authorMapper.deleteAuthorMap(authMapVo);

			String authorType = authMapVo.getAuthorType();
			if(authorType.equals("dept")) {
//				authMapVo.setDeptEsntlNo(authMapVo.getKeyCode());

				DeptTreeVO deptHst = new DeptTreeVO();
				deptHst.setDeptEsntlNo(authMapVo.getKeyCode());
				deptHst.setAuthorNo(authMapVo.getAuthorNo());
				//authorMapper.insertDeptAuthHist(deptHst);
				commonService.insertTableHistory("CO_DEPT_AUTHOR_RLS",deptHst);
			} else if(authorType.equals("emp")) {
//				authMapVo.setEmplNo(authMapVo.getKeyCode());

				EmpVO empHst = new EmpVO();
				empHst.setEmplNo(authMapVo.getKeyCode());
				empHst.setAuthorNo(authMapVo.getAuthorNo());
				//authorMapper.insertEmpAuthHist(empHst);
				commonService.insertTableHistory("CO_EMP_AUTHOR_RLS",empHst);
			}



		}

	}

	@Override
	public List<DeptTreeVO> getDeptList(DeptTreeVO deptVo) throws Exception {
		List<DeptTreeVO> deptList = authorMapper.getDeptList(deptVo);
		for(DeptTreeVO dept :  deptList) {
			if(dept.getCnt() > 0 ) {
				Map<String , Boolean> state = new HashMap<String , Boolean>();
				state.put(BoCoConstants.AUTHOR_DEPT_CHECK_DISABLE, true);
				dept.setState(state);
			}
		}
		return deptList;
	}

	@Override
	public void insertDeptAuthor(int authorNo, List<DeptTreeVO> deptList) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		String userId ="";
		if(account != null) {
			userId = account.getId();
		}

		for(DeptTreeVO dept :  deptList) {
			dept.setAuthorNo(authorNo);
			dept.setFrstRegisterId(userId);
			dept.setLastChangerId(userId);
			authorMapper.insertDeptAuthor(dept);
			//authorMapper.insertDeptAuthHist(dept);
			commonService.insertTableHistory("CO_DEPT_AUTHOR_RLS",dept);
		}

	}

	@Override
	public List<EmpVO> getEmpList(EmpVO empVo) throws Exception {
		List<EmpVO> empList = authorMapper.getEmpList(empVo);

		for (EmpVO empVO : empList) {
			if (StringUtils.isNotBlank(empVO.getCryalTlphonNo())) {
				empVO.setCryalTlphonNo(CryptoUtil.decryptAES256(empVO.getCryalTlphonNo()));	//복호화
			}
		}

		return empList;
	}

	@Override
	public int getEmpListCnt(EmpVO empVo) throws Exception {
		return authorMapper.getEmpListCnt(empVo);
	}

	@Override
	public void insertEmpAuthor(int authorNo, List<EmpVO> empList) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		String userId ="";
		if(account != null) {
			userId = account.getId();
		}

		for(EmpVO empVo : empList) {
			empVo.setAuthorNo(authorNo);
			empVo.setFrstRegisterId(userId);
			empVo.setLastChangerId(userId);
			authorMapper.insertEmpAuthor(empVo);
			//authorMapper.insertEmpAuthHist(empVo);
			commonService.insertTableHistory("CO_EMP_AUTHOR_RLS",empVo);
		}
	}
}
