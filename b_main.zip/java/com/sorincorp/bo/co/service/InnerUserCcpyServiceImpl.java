package com.sorincorp.bo.co.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.co.mapper.InnerUserCcpyMapper;
import com.sorincorp.bo.co.model.InnerUserCcpyVO;
import com.sorincorp.comm.util.CryptoUtil;

/**
 * InnerUserCcpyServiceImpl.java
 * @version
 * @since 2023. 4. 14.
 * @author srec0082
 */
@Service
public class InnerUserCcpyServiceImpl implements InnerUserCcpyService {
	
	@Autowired
	InnerUserCcpyMapper innerUserCcpyMapper;

	/**
	 * 내부사용자_협력업체 목록을 조회한다.
	 */
	@Override
	public List<InnerUserCcpyVO> selectInneruserCcpyList(InnerUserCcpyVO user) throws Exception {
		List<InnerUserCcpyVO> innerUserCcpyList = innerUserCcpyMapper.selectInneruserCcpyList(user);
		List<InnerUserCcpyVO> list = new ArrayList<>();
		
		for (InnerUserCcpyVO innerUserVO : innerUserCcpyList) {
			if (StringUtils.isNotBlank(innerUserVO.getCryalTlphonNo())) {
				innerUserVO.setCryalTlphonNo(CryptoUtil.decryptAES256(innerUserVO.getCryalTlphonNo()));	// 휴대 전화 번호 복호화
				}
				if(user.getSearchCondition().equals("04")) { // 연락처 검색
					if (innerUserVO.getCryalTlphonNo().contains(user.getSearchKeyword())) {
						list.add(innerUserVO);}
				}
		}
		if (user.getSearchCondition().equals("04")) {
			return list;
		} else {
			return innerUserCcpyList;
		}
	}
	
	
	/**
	 * 내부사용자_협력업체 총 개수를 조회한다.
	 */
	@Override
	public int selectInneruserCcpyTotCnt(InnerUserCcpyVO user) throws Exception {
	
		return innerUserCcpyMapper.selectInneruserCcpyTotCnt(user);
	}

	/**
	 * 두 테이블 간 내부사용자 아이디 중복체크 여부를 확인한다.
	 */
	@Override
	public int idCheck(String userId) {
		int cnt = innerUserCcpyMapper.idCheck(userId);
		return cnt;
	}

	/**
	 * 내부사용자_협력업체 목록을 등록 및 수정한다.
	 */
	@Override
	public int insertAndUpdateGridDataList(List<InnerUserCcpyVO> userList) throws Exception {
		int result =0;
		for(InnerUserCcpyVO  userCcpy:userList) {
			String status = userCcpy.getGridRowStatus();
			if(status.equals("created")) {
				result = insertInneruserCcpy(userCcpy);		
			} else if(status.equals("updated")) {
				result = updateInneruserCcpy(userCcpy);
			}
		}
		
		return result;
	}
	
	/**
	 * 내부사용자_협력업체 목록을 등록한다.
	 */
	@Override
	public int insertInneruserCcpy(InnerUserCcpyVO user) throws Exception {
		if (StringUtils.isNotBlank(user.getCryalTlphonNo())) {
			user.setCryalTlphonNo(CryptoUtil.encryptAES256(user.getCryalTlphonNo())); // 휴대 전화 번호 암호화
		}
		if (StringUtils.isNotBlank(user.getPassword())) {
			user.setPassword(CryptoUtil.encryptAES256(user.getPassword())); // 비밀번호 암호화
		}

		
		return innerUserCcpyMapper.insertInneruserCcpy(user);
	}

	/**
	 * 내부사용자_협력업체 목록을 수정한다.
	 */
	@Override
	public int updateInneruserCcpy(InnerUserCcpyVO user) throws Exception {
		if (StringUtils.isNotBlank(user.getCryalTlphonNo())) {
			user.setCryalTlphonNo(CryptoUtil.encryptAES256(user.getCryalTlphonNo())); // 휴대 전화 번호 암호화
		}
		if (StringUtils.isNotBlank(user.getPassword())) {
			user.setPassword(CryptoUtil.encryptAES256(user.getPassword())); // 비밀번호 암호화
		}
		
		return innerUserCcpyMapper.updateInneruserCcpy(user);
	}

	/**
	 * 내부사용자_협력업체 목록을 삭제한다.
	 */
	@Override
	public int deleteInneruserCcpy(List<InnerUserCcpyVO> userList) {
		int result = 0;
		List<String> emplNoList = new ArrayList<>();
		for(int i=0;i<userList.size();i++) {
		InnerUserCcpyVO userVo = userList.get(i);
		String emplNo = userVo.getEmplNo();
		emplNoList.add(emplNo);
		}
		InnerUserCcpyVO vo = new InnerUserCcpyVO();
		vo.setEmplNoList(emplNoList);
		
		innerUserCcpyMapper.deleteInneruserCcpy(vo);
		
		return result;
	}

	/**
	 * 직위명을 가져온다.
	 */
	@Override
	public List<Map<String, String>> getKoreanOfcpsNm() {
		
		return innerUserCcpyMapper.getKoreanOfcpsNm();
	}

	/**
	 * 직급명을 가져온다.
	 */
	@Override
	public List<Map<String, String>> getKoreanClsfNm() {
		
		return innerUserCcpyMapper.getKoreanClsfNm();
	}

	/**
	 * 직책명을 가져온다.
	 */
	@Override
	public List<Map<String, String>> getKoreanRspofcNm() {
		
		return innerUserCcpyMapper.getKoreanRspofcNm();
	}

	/**
	 * 사업장명을 가져온다.
	 */
	@Override
	public List<Map<String, String>> getKoreanBplcNm() {
		
		return innerUserCcpyMapper.getKoreanBplcNm();
	}

	/**
	 * 내부사용자_협력업체 목록을 단건 조회한다.
	 */
	@Override
	public InnerUserCcpyVO selectInneruserCcpy(InnerUserCcpyVO user) throws Exception {
		
		InnerUserCcpyVO vo = innerUserCcpyMapper.selectInneruserCcpy(user);
		
		if (StringUtils.isNotBlank(vo.getCryalTlphonNo())) {
			vo.setCryalTlphonNo(CryptoUtil.decryptAES256(vo.getCryalTlphonNo()));// 휴대 전화 번호 복호화
		}
		
		if (StringUtils.isNotBlank(vo.getPassword())) {
			vo.setPassword(CryptoUtil.decryptAES256(vo.getPassword()));// 비밀번호 복호화
		}
		
		return vo;
	}

}
