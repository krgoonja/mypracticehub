package com.sorincorp.bo.co.service;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.sorincorp.bo.co.model.AuthorMenuVO;
import com.sorincorp.bo.co.model.MenuAuthVO;
import com.sorincorp.bo.co.model.MenuTreeVO;
import com.sorincorp.bo.co.model.MenuVO;
import com.sorincorp.bo.login.model.Account;

/**
 * MenuService.java
 * @version
 * @since 2021. 6. 9.
 * @author Sim sung bo
 */
public interface MenuService {

	/**
	 * <pre>
	 * 처리내용: 메뉴 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			Sim sung bo				최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @return
	 * @throws Exception
	 */
	List<MenuTreeVO> getListMenu(MenuTreeVO menuVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메뉴를 수정한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			Sim sung bo				최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @throws Exception
	 */
	void updateMenu(MenuTreeVO menuVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메뉴를 등록한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			Sim sung bo				최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @throws Exception
	 */
	void insertMenu(MenuTreeVO menuVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메뉴-권한 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			Sim sung bo				최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @return
	 * @throws Exception
	 */
	List<AuthorMenuVO> getListAuthor(MenuTreeVO menuVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 모든 권한을 조회한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			Sim sung bo				최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 * @return
	 * @throws Exception
	 */
	List<AuthorMenuVO> getListAllAuthor(MenuTreeVO menuVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메뉴-권한을 등록한다.
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			Sim sung bo				최초작성
	 * ------------------------------------------------
	 * @param authList
	 * @throws Exception
	 */
	void insertAuth(List<AuthorMenuVO> authList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메뉴 트리 구조를 엑셀로 다운로드한다.
	 * </pre>
	 * @date 2021. 6. 11.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 11.			Sim sung bo				최초작성
	 * ------------------------------------------------
	 * @param menuList
	 * @param response
	 * @throws Exception
	 */
	void menuExcelDownload(MenuTreeVO menuList, HttpServletResponse response) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메뉴를 삭제한다.
	 * </pre>
	 * @date 2021. 6. 14.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 14.			Sim sung bo				최초작성
	 * ------------------------------------------------
	 * @param menuVo
	 */
	void deleteMenu(MenuTreeVO menuVo) throws Exception;

	/**
	 * <pre>
	 * 특정한 계정의 sidebar 메뉴 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 7. 28.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 28.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return menuVo
	 * @throws Exception
	 */
	List<MenuVO> getSideBarMenu(String userId) throws Exception;

	/**
	 * <pre>
	 * sidebar 메뉴 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 7. 28.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 28.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return menuVo
	 * @throws Exception
	 */
	List<MenuVO> getSideBarMenu2() throws Exception;


	/**
	 * <pre>
	 * 처리내용: 각메뉴의 -권한 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 8. 23.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 23.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param menuNo
	 * @return
	 * @throws Exception
	 */
	List<MenuAuthVO> getMenuAuthInfo(String menuNo) throws Exception;

	/**
	 * <pre>
	 * 메뉴의 권한 리스트를 조회
	 * </pre>
	 * @date 2023. 7. 10.
	 * @author srec0051
	 * @param urlMenuList
	 * @return
	 * @throws Exception
	 */
	List<MenuAuthVO> getMenuAuthInfoList(List<Integer> urlMenuList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 사용자 권한에 해당되는 메뉴 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 26.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 * @throws Exception
	 */
//	List<MenuVO> getAuthSideBarMenu(Account account) throws Exception;

}
