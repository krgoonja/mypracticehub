package com.sorincorp.bo.co.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.co.mapper.InnerUserMapper;
import com.sorincorp.bo.co.model.InnerUserVO;
import com.sorincorp.comm.util.CryptoUtil;

/**
 * InnerUserServiceImpl.java
 * @version
 * @since 2021. 6. 21.
 * @author srec0033
 */
@Service
public class InnerUserServiceImpl implements InnerUserService {

	@Autowired
	InnerUserMapper innerUserMapper;

	/**
	 *	내부사용자 목록을 조회한다.
	 */
	@Override
	public List<InnerUserVO> selectInneruserList(InnerUserVO user) throws Exception {
		List<InnerUserVO> innerUserList = innerUserMapper.selectInneruserList(user);

		for (InnerUserVO innerUserVO : innerUserList) {
			if (StringUtils.isNotBlank(innerUserVO.getCryalTlphonNo())) {
				innerUserVO.setCryalTlphonNo(CryptoUtil.decryptAES256(innerUserVO.getCryalTlphonNo()));	//복호화
			}
		}

		return innerUserList;
	}

	/**
	 *	내부사용자 총 갯수를 조회한다.
	 */
	@Override
	public int selectInneruserTotCnt(InnerUserVO user) throws Exception {
		return innerUserMapper.selectInneruserTotCnt(user);
	}

}
