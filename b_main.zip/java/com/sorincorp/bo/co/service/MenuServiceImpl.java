package com.sorincorp.bo.co.service;

import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.sorincorp.comm.common.service.CommonService;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.bo.co.comm.BoCoConstants;
import com.sorincorp.bo.co.mapper.MenuMapper;
import com.sorincorp.bo.co.model.AuthorMenuVO;
import com.sorincorp.bo.co.model.MenuAuthVO;
import com.sorincorp.bo.co.model.MenuExcelVO;
import com.sorincorp.bo.co.model.MenuTreeVO;
import com.sorincorp.bo.co.model.MenuVO;
import com.sorincorp.bo.config.InitConfig;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.login.model.Account;

import lombok.extern.slf4j.Slf4j;

/**
 * MenuServiceImpl.java
 * @version
 * @since 2021. 10. 26.
 * @author srec0033
 */
@Slf4j
@Service
public class MenuServiceImpl implements MenuService{

	@Autowired
	private MenuMapper menuMapper;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private InitConfig initConfig;

	@Autowired
	private CommonService commonService;



	/**
	 *	메뉴 리스트를 조회한다.
	 */
	@Override
	public List<MenuTreeVO> getListMenu(MenuTreeVO menuVo) throws Exception {
		log.debug("menuVo ===> " + menuVo);
		List<MenuTreeVO>  menuList = menuMapper.getListMenu(menuVo);

		if(StringUtils.equals(BoCoConstants.SYS_SE_CODE_BO, menuVo.getSysSeCode())) {
			MenuTreeVO rootMenu = new MenuTreeVO(BoCoConstants.MENU_ROOT_BO_ID, BoCoConstants.MENU_ROOT_BO_NAME, BoCoConstants.MENU_ROOT_PARENT_ID, null, BoCoConstants.SYS_SE_CODE_BO);
			menuList.add(0, rootMenu);
			MenuTreeVO rootMenuMbo = new MenuTreeVO(BoCoConstants.MENU_ROOT_MBO_ID, BoCoConstants.MENU_ROOT_MBO_NAME, BoCoConstants.MENU_ROOT_PARENT_ID, null, BoCoConstants.SYS_SE_CODE_MBO);
			menuList.add(1, rootMenuMbo);
		}else if(StringUtils.equals(BoCoConstants.SYS_SE_CODE_FO, menuVo.getSysSeCode())) {
			MenuTreeVO rootMenu = new MenuTreeVO(BoCoConstants.MENU_ROOT_FO_ID, BoCoConstants.MENU_ROOT_FO_NAME, BoCoConstants.MENU_ROOT_PARENT_ID, null, BoCoConstants.SYS_SE_CODE_FO);
			menuList.add(0, rootMenu);
			MenuTreeVO rootMenuMo = new MenuTreeVO(BoCoConstants.MENU_ROOT_MO_ID, BoCoConstants.MENU_ROOT_MO_NAME, BoCoConstants.MENU_ROOT_PARENT_ID, null, BoCoConstants.SYS_SE_CODE_MO);
			menuList.add(1, rootMenuMo);
		}

		return menuList;
	}

	/**
	 *	메뉴를 수정한다.
	 */
	@Override
	public void updateMenu(MenuTreeVO menuVo) throws Exception {

		Account account = userInfoUtil.getAccountInfo();
		String userId = "";
		if(account != null) {
			userId = account.getId();
		}
		menuVo.setLastChangerId(userId);

		menuMapper.updateMenu(menuVo);
		//menuMapper.insertHistMenu(menuVo);
		commonService.insertTableHistory("CO_MENU_BAS",menuVo);

		//REDIS 갱신
		initConfig.InitMenuSettings();
	}

	/**
	 *	메뉴를 등록한다.
	 */
	@Override
	public void insertMenu(MenuTreeVO menuVo) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		String userId = "";
		if(account != null) {
			userId = account.getId();
		}
		menuVo.setFrstRegisterId(userId);
		menuVo.setLastChangerId(userId);

		menuMapper.insertMenu(menuVo);
		menuVo.setMenuNo(menuVo.getCurMenuNo());
		//menuMapper.insertHistMenu(menuVo);
		commonService.insertTableHistory("CO_MENU_BAS",menuVo);

		//REDIS 갱신
		initConfig.InitMenuSettings();
	}

	/**
	 *	메뉴-권한 리스트를 조회한다.
	 */
	@Override
	public List<AuthorMenuVO> getListAuthor(MenuTreeVO menuVo) throws Exception {
		List<AuthorMenuVO> authorList  = menuMapper.getListAuthor(menuVo);
		return authorList;
	}

	/**
	 *	모든 권한을 조회한다.
	 */
	@Override
	public List<AuthorMenuVO> getListAllAuthor(MenuTreeVO menuVo) throws Exception {
		List<AuthorMenuVO> authorList  = menuMapper.getListAllAuthor(menuVo);
		return authorList;
	}

	/**
	 *	메뉴-권한을 등록한다.
	 */
	@Override
	public void insertAuth(List<AuthorMenuVO> authList) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		String userId = "";
		if(account != null) {
			userId = account.getId();
		}

		for(AuthorMenuVO authVo : authList ) {

			authVo.setLastChangerId(userId);

			if(authVo.isAuthExistBool()) {
				authVo.setFrstRegisterId(userId);
				menuMapper.insertAuth(authVo);
			}else {
				menuMapper.updateAuth(authVo);
			}
			//menuMapper.insertHistAuth(authVo);
			commonService.insertTableHistory("CO_MENU_AUTHOR_RLS",authVo);
		}

		//REDIS 갱신
		initConfig.InitMenuSettings();
	}

	/**
	 *	메뉴 트리 구조를 엑셀로 다운로드한다.
	 */
	@Override
	public void menuExcelDownload(MenuTreeVO menuList, HttpServletResponse response) throws Exception {

		Workbook workbook = new SXSSFWorkbook();
		Sheet sheet = workbook.createSheet();
		Row row = null;
        Cell cell = null;
		try {
			String fileName = menuList.getExcelSysSeCode() + BoCoConstants.UNDERBAR + BoCoConstants.MENU_EXCEL_FILE_NAME;
			ObjectMapper mapper = new ObjectMapper();
			String excelJson = StringEscapeUtils.unescapeHtml4(menuList.getExcelData());
			MenuExcelVO[] menuExcelArr = mapper.readValue(excelJson, MenuExcelVO[].class);
			int rowIndex = 0;

			for (MenuExcelVO vo : menuExcelArr) {
				row = sheet.createRow(rowIndex++);
				cell = row.createCell(0);
				String space = StringUtils.EMPTY;
				for(int i = 0 ; i < vo.getLevel() ; i++) {
					space += BoCoConstants.EXCEL_DEPTH_EMPTY;
				}
				if(vo.getLevel() == 0 ) {
					cell.setCellValue(vo.getText());
				}else {
					cell.setCellValue(space + BoCoConstants.EXCEL_DEPTH_STRING + vo.getText());
				}

			}

			response.setContentType("ms-vnd/excel");
			response.setHeader("Content-Disposition", "attachment;filename=" + fileName);

			workbook.write(response.getOutputStream());
			workbook.close();

		}catch(Exception e){

			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('"+ BoCoConstants.EXCEL_DOWNLOAD_FAIL_MSG +"');history.back();</script>");
			out.flush();

		}

	}

	/**
	 *	메뉴를 삭제한다.
	 */
	@Override
	public void deleteMenu(MenuTreeVO menuVo) throws Exception {

		Account account = userInfoUtil.getAccountInfo();
		String userId = "";
		if(account != null) {
			userId = account.getId();
		}
		menuVo.setLastChangerId(userId);

		menuMapper.deleteMenu(menuVo);
		//menuMapper.insertHistMenu(menuVo);
		commonService.insertTableHistory("CO_MENU_BAS",menuVo);

		//REDIS 갱신
		initConfig.InitMenuSettings();
	}

	/**
	 *	sidebar 메뉴 리스트를 조회한다.
	 */
	@Override
	public List<MenuVO> getSideBarMenu(String userId) throws Exception {
		Map<String, String> map = new HashedMap<>();
		map.put("userId", userId);
		List<MenuVO> sideBarMenuList =  menuMapper.getSideBarMenu(map);
		return sideBarMenuList;
	}

	/**
	 *	특정 계정의 sidebar 메뉴 리스트를 조회한다.
	 * @throws Exception
	 */
	@Override
	public List<MenuVO> getSideBarMenu2() throws Exception {
		List<MenuVO> sideBarMenuList =  menuMapper.getSideBarMenu2();
		return sideBarMenuList;
	}

	/**
	 *	메뉴-권한 리스트를 조회한다.
	 */
	@Override
	public List<MenuAuthVO> getMenuAuthInfo(String menuNo) throws Exception {
		List<MenuAuthVO> authorList  = menuMapper.getMenuAuthInfo(menuNo);
		return authorList;
	}
	@Override
	public List<MenuAuthVO> getMenuAuthInfoList(List<Integer> urlMenuList) throws Exception {
		return menuMapper.getMenuAuthInfoList(urlMenuList);
	}

	/**
	 *	메뉴리스트-권한리스트를 조회한다.
	 */
//	@Override
//	public List<MenuVO> getAuthSideBarMenu(Account account) throws Exception {
//
//		List<MenuVO> sideBarMenuList =  menuMapper.getAuthMenu();
//		List<MenuVO> upperMenuList =  new ArrayList<>();
//		List<MenuVO> result  =  new ArrayList<>();
//
//		for(MenuVO menuVo : sideBarMenuList) {
//			if(menuVo.getAuthorNoList() != null) {
//
//				String str = menuVo.getAuthorNoList();
//				List<String> authNoList =  Arrays.asList(str.split(","));
//				List<String> userAuthList = Arrays.asList(account.getAuthorNo().split(","));
//
//				for(String authNo : authNoList) {
//
//					if(userAuthList.indexOf(authNo) != -1) { //권한이 하나만 있는 경우, 권한이 없는 경우 테스트 권한테이블 null값 방지되어 있음
//						result.add(menuVo);
//						upperMenuList.add(menuMapper.getUpperMenu(menuVo.getUpperMenuNo()));
//
//					}
//				}
//			}
//
//		}
//
//		upperMenuList = upperMenuList.stream().distinct().collect(Collectors.toList());
//
//		result.addAll(upperMenuList);
//		result = result.stream().distinct().collect(Collectors.toList());
//
//
//		for(MenuVO vo : upperMenuList) {
//			result.add(menuMapper.getUpperMenu(vo.getUpperMenuNo()));
//		}
//
//		return result;
//	}

}
