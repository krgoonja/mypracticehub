package com.sorincorp.bo.co.service;

import java.util.List;

import com.sorincorp.bo.co.model.InnerUserVO;

public interface InnerUserService {
	
	/**
	 * <pre>
	 * 처리내용: 내부사용자 목록을 조회한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param user
	 * @return
	 * @throws Exception
	 */
	List<InnerUserVO> selectInneruserList(InnerUserVO user) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 내부사용자 총 갯수를 조회한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param user
	 * @return
	 * @throws Exception
	 */
	int selectInneruserTotCnt(InnerUserVO user) throws Exception;
	
}
