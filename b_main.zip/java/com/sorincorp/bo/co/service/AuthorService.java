package com.sorincorp.bo.co.service;

import java.util.List;

import javax.validation.Valid;

import com.sorincorp.bo.co.model.AuthorMapVO;
import com.sorincorp.bo.co.model.AuthorVO;
import com.sorincorp.bo.co.model.DeptTreeVO;
import com.sorincorp.bo.co.model.EmpVO;

/**
 * AuthorService.java
 * @version
 * @since 2021. 6. 23.
 * @author Sim sung bo
 */
public interface AuthorService {

	/**
	 * <pre>
	 * 처리내용: 해당 시스템의 권한 목록을 불러온다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorVo
	 * @return
	 * @throws Exception
	 */
	List<AuthorVO> getAuthorList(AuthorVO authorVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 해당 시스템의 권한 목록 갯수를 불러온다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorVo
	 * @return
	 * @throws Exception
	 */
	int getAuthorListCnt(AuthorVO authorVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 선택 권한의 대한 상세내용을 불러온다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorVo
	 * @return
	 * @throws Exception
	 */
	AuthorVO getAuthor(AuthorVO authorVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 권한 ID 중복 체크를 한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorVo
	 * @return
	 * @throws Exception
	 */
	int checkAuthorId(AuthorVO authorVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 권한을 등록한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorVo
	 * @throws Exception
	 */
	void insertAuthor(AuthorVO authorVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 권한을 수정한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorVo
	 * @throws Exception
	 */
	void updateAuthor(AuthorVO authorVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 권한을 삭제한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorVo
	 * @throws Exception
	 */
	void deleteAuthor(AuthorVO authorVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 해당 권한에 매핑된 리스틑 불러온다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorVo
	 * @return
	 * @throws Exception
	 */
	List<AuthorMapVO> getAuthorMap(AuthorMapVO authorVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 해당 권한에 매핑된 리스 갯수틑 불러온다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorVo
	 * @return
	 * @throws Exception
	 */
	int getAuthorMapCnt(AuthorMapVO authorVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 매핑된 권한을 삭제한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorMapList
	 * @throws Exception
	 */
	void deleteAuthorMap(List<AuthorMapVO> authorMapList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 부서리스트틑 불러온다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param deptVo
	 * @return
	 * @throws Exception
	 */
	List<DeptTreeVO> getDeptList(DeptTreeVO deptVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 부서와 권한을 매핑시킨다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorNo
	 * @param deptList
	 * @throws Exception
	 */
	void insertDeptAuthor(int authorNo, List<DeptTreeVO> deptList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 직원 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param empVo
	 * @return
	 * @throws Exception
	 */
	List<EmpVO> getEmpList(EmpVO empVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 직원 리스트 갯수를 조회한다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param empVo
	 * @return
	 * @throws Exception
	 */
	int getEmpListCnt(EmpVO empVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 직원과 권한을 매핑시킨다.
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 23.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param authorNo
	 * @param authorVo
	 * @throws Exception
	 */
	void insertEmpAuthor(int authorNo,List<EmpVO> authorVo) throws Exception;

}
