package com.sorincorp.bo.co.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.co.model.CmmnCodeVO;

/**
 * CmmnCodeService.java
 * @version 
 * @since 2021. 6. 9.
 * @author srec0033
 */
public interface CmmnCodeService {

	/**
	 * <pre>
	 * 처리내용: 메인코드 목록을 조회한다.
	 * </pre>
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 조회한 메인코드 목록
	 * @throws Exception
	 */
	List<CmmnCodeVO> selectCmmnMainCodeList(CmmnCodeVO searchVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공통코드의 총 갯수를 조회한다.
	 * </pre>
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 공통코드 총 갯수
	 */
	int selectCmmnCodeListTotcnt(CmmnCodeVO searchVO) throws Exception;;
	
	/**
	 * <pre>
	 * 처리내용: 서브코드 목록을 조회한다.
	 * </pre>
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param mainCode - 조회할 서브코드 목록의 대상 메인코드
	 * @return 조회한 서브코드 목록
	 * @throws Exception
	 */
	List<CmmnCodeVO> selectCmmnSubCodeList(CmmnCodeVO mainCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 공통코드 정보를 삽입, 수정한다.
	 * </pre>
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param codeList - 삽입,수정할 정보가 담긴 CmmnCodeVO 리스트
	 * @throws Exception
	 */
	void insertAndUpdateCodeList(List<CmmnCodeVO> codeList) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공통코드를 등록한다. 
	 * </pre>
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param codeVO - 등록할 정보가 담긴 codeVO
	 * @throws Exception
	 */
	void insertCmmnCode(CmmnCodeVO codeVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공통코드를 수정한다.
	 * </pre>
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param codeVO - 수정할 정보가 담긴 codeVO
	 * @throws Exception
	 */
	void updateCmmnCode(CmmnCodeVO codeVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 메인코드PK를 수정한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param mainVO
	 * @throws Exception
	 */
	void updateMaincodePK(CmmnCodeVO mainVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공통코드를 삭제한다.
	 * </pre>
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param codeVO - 삭제할 정보가 담긴 codeVO
	 * @throws Exception
	 */
	void deleteCmmnCode(CmmnCodeVO codeVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용:  공통코드 정보를 삭제한다.
	 * </pre>
	 * @date 2021. 5. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param codeList - 삭제할 정보가 담긴 CmmnCodeVO 리스트
	 * @throws Exception
	 */
	void deleteGridDataList(List<CmmnCodeVO> codeList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 레디스를 전체 갱신한다.
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	Map<String, String> updateRedis() throws Exception;
	
}
