package com.sorincorp.bo.ma.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.ma.model.DashBoardEwalletVO;
import com.sorincorp.bo.ma.model.DashboardDlvyVO;
import com.sorincorp.bo.ma.model.DashboardInvntrySttusVO;
import com.sorincorp.bo.ma.model.DashboardOrderSttusVO;
import com.sorincorp.bo.ma.model.DashboardRltmOrderDetailVO;
import com.sorincorp.bo.ma.model.DashboardRltmOrderInfoVO;
import com.sorincorp.bo.ma.model.DashboardSelngVO;

/**
 * DashboardMapper.java
 * BO 대쉬보드 Mapper
 * 
 * @version
 * @since 2021. 11. 08.
 * @author srec0052
 */
public interface DashboardMapper {
	
	public abstract String selectOrderCnt() throws Exception;
	
	public abstract List<DashboardOrderSttusVO> selectOrderSttusList() throws Exception;

	public abstract String selectInvntryCnt() throws Exception;
	
	public abstract List<DashboardInvntrySttusVO> selectInvntrySttusList() throws Exception;

	public abstract List<DashboardSelngVO> selectSelngList() throws Exception;

	public abstract List<DashboardDlvyVO> selectDlvyList() throws Exception;

	public abstract DashboardRltmOrderInfoVO selectRltmOrderInfo(DashboardRltmOrderInfoVO dashboardRltmOrderInfoVO) throws Exception;

	public abstract DashboardRltmOrderDetailVO selectOrderBasInfo(DashboardRltmOrderDetailVO dashboardRltmOrderDetailVO) throws Exception;

	public abstract List<DashboardRltmOrderDetailVO> selectOrderHistory(DashboardRltmOrderDetailVO dashboardRltmOrderDetailVO) throws Exception;

	public abstract List<DashboardRltmOrderDetailVO> selectLogistInfo(DashboardRltmOrderDetailVO dashboardRltmOrderDetailVO) throws Exception;

	public abstract DashboardRltmOrderInfoVO selectOrderCntInfo() throws Exception;

	public abstract List<DashBoardEwalletVO> selectEwlltList() throws Exception;

	public abstract List<DashboardRltmOrderInfoVO> selectTodayOrderList() throws Exception;
	
	public abstract List<Map<String, Object>> getSarokPcList(Map<String, Object> param);
}
