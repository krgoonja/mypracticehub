package com.sorincorp.bo.ma.mapper;

public interface MainMapper {

	public abstract String newInqryCount();

	public abstract String solvedInqryCount();

	public abstract String unsolvedInqryCount();
	
}
