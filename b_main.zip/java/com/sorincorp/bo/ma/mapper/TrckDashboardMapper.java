package com.sorincorp.bo.ma.mapper;

import java.util.List;
import java.util.Map;

public interface TrckDashboardMapper {

	public abstract Map<String, Object> selectTodayReport();
	
	public abstract Map<String, Object> selectMonthReport();
	
	public abstract List<Map<String, Object>> selectLoginLank();

	public abstract List<Map<String, Object>> selectPurchLank();

	public abstract List<Map<String, Object>> selectTodayPurchMber();
	
	public abstract List<Map<String, Object>> selectMonthSignUpList();
	
	public abstract List<Map<String, Object>> selectTodayVisitList();

	public abstract List<Map<String, Object>> selectEntrpsCurrLocation();
	
	public abstract List<Map<String, Object>> selectRecentVisitList();
	
	public abstract List<Map<String, Object>> selectTodayConvertList();
	
	public abstract List<Map<String, Object>> selectMonthConvertAvg();
	
	public abstract List<Map<String, Object>> selectTodayVisitPt();
	
	int updateTrackDetail(Map<String, Object> map) throws Exception;
	
	Map<String, Object> selectTrackMsg(Map<String, Object> map) throws Exception;
	
}
