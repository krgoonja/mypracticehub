package com.sorincorp.bo.ma.mapper;

import java.util.List;

import com.sorincorp.bo.chart.model.SelMetalVO;
import com.sorincorp.bo.ma.model.DashboardInvntrySttusVO;
import com.sorincorp.bo.ma.model.DashboardLimitsOrderInfoVO;
import com.sorincorp.bo.ma.model.DashboardOrderCntVO;
import com.sorincorp.bo.ma.model.DashboardPrvsnlOrderVO;
import com.sorincorp.bo.ma.model.DashboardRltmOrderInfoVO;

/**
 * OrderDashboardMapper.java
 * 주문 대시보드 Mapper 인터페이스 (주문/ 지정가주문/ 소량구매)
 * @version
 * @since 2023. 5. 4.
 * @author srec0066
 */
public interface OrderDashboardMapper {

	/**
	 * <pre>
	 * 처리내용: 주문 접수 현황 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	DashboardOrderCntVO selectOrderRceptCntInfo() throws Exception;

	/**
	 * <pre>
	 * 처리내용: Live 재고 현황 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	List<DashboardInvntrySttusVO> selectLiveInvntrySttusList(String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 소량구매 재고 현황 조회
	 * </pre>
	 * @date 2024. 5. 27.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 27.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	List<DashboardInvntrySttusVO> selectSmlqyInvntrySttusList(String metalCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: LIVE 지정가 호가창 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<DashboardLimitsOrderInfoVO> selectLiveRltmLimitsOrderList() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 소량 구매 지정가 호가창 조회
	 * </pre>
	 * @date 2024. 5. 27.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 27.          srec0049         최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<DashboardLimitsOrderInfoVO> selectSmlqyRltmLimitsOrderList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 접수 목록 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<DashboardLimitsOrderInfoVO> selectLimitsOrderRceptList() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 소량구매 지정가 주문 접수 목록 조회
	 * </pre>
	 * @date 2024. 5. 27.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 27.          srec0049         최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<DashboardLimitsOrderInfoVO> selectSmlqyLimitsOrderRceptList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 금일 주문 목록 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<DashboardRltmOrderInfoVO> selectTodayOrderList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 가단가 구매 평가 목록 조회
	 * </pre>
	 * @date 2024. 10. 29.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 29.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	List<DashboardPrvsnlOrderVO> selectPrvsnlPurchsEvlList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 변동금 입금 대상 목록 조회
	 * </pre>
	 * @date 2024. 10. 29.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 29.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	List<DashboardPrvsnlOrderVO> selectChangeAmountRcpmnyTrgetList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기준 프리미엄 환산 금액 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param limitOrderNo
	 * @return
	 * @throws Exception
	 */
	Long selectStdrPremiumCnvrsnAmount(String limitOrderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 재고현황 조회대상 금속 리스트(현재는 아연/알루미늄만 조회하도록 함)
	 * </pre>
	 * @date 2023. 5. 8.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 8.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<SelMetalVO> selectSelMetalList() throws Exception;
}
