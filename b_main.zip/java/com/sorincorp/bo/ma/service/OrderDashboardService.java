package com.sorincorp.bo.ma.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.bo.ma.model.DashboardLimitsOrderInfoVO;
import com.sorincorp.bo.ma.model.DashboardOrderCntVO;
import com.sorincorp.bo.ma.model.DashboardPrvsnlOrderVO;
import com.sorincorp.bo.ma.model.DashboardRltmOrderInfoVO;

/**
 * OrderDashboardService.java
 * 주문 대시보드 Service 인터페이스 (주문/ 지정가주문/ 소량구매)
 * @version
 * @since 2023. 5. 4.
 * @author srec0066
 */
public interface OrderDashboardService {

	/**
	 * <pre>
	 * 처리내용: 주문 접수 현황 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * 2024. 5. 24.			srec0049			공동구매 제거, 소량구매 추가
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	DashboardOrderCntVO selectOrderRceptCntInfo() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 재고 현황 조회 (LIVE + 소량판매)
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * 2024. 5. 24.			srec0049			소량구매 추가
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> selectInvntrySttusList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: LIVE 지정가 호가창 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	 Map<Long, List<DashboardLimitsOrderInfoVO>> selectLiveRltmLimitsOrderList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 소량 구매 지정가 호가창 조회
	 * </pre>
	 * @date 2024. 5. 27.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 27.          srec0049         최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<DashboardLimitsOrderInfoVO> selectSmlqyRltmLimitsOrderList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 접수 목록 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<DashboardLimitsOrderInfoVO> selectLimitsOrderRceptList() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 소량구매 지정가 주문 접수 목록 조회
	 * </pre>
	 * @date 2024. 5. 27.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 27.          srec0049         최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<DashboardLimitsOrderInfoVO> selectSmlqyLimitsOrderRceptList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 금일 주문 목록 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<DashboardRltmOrderInfoVO> selectTodayOrderList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기준 프리미엄 환산 금액 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param limitOrderNo
	 * @return
	 * @throws Exception
	 */
	Long selectStdrPremiumCnvrsnAmount(String limitOrderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 재고 현황 조회대상 금속리스트 조회
	 * </pre>
	 * @date 2023. 7. 10.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 10.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<String> selectSelMetalList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 다이버 상태 조회
	 * </pre>
	 * @date 2024. 3. 15.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 3. 15.			hamyoonsic				최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	boolean selectDiverInfo() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 가단가 구매 평가 목록 조회 (단가 미확정 건만 노출)
	 * </pre>
	 * @date 2024. 10. 29.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 29.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	List<DashboardPrvsnlOrderVO> selectPrvsnlPurchsEvlList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 변동금 입금 대상 목록 조회 (당일 발생 건만 노출, 출금 건 제외)
	 * </pre>
	 * @date 2024. 10. 29.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 29.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	List<DashboardPrvsnlOrderVO> selectChangeAmountRcpmnyTrgetList() throws Exception;
}
