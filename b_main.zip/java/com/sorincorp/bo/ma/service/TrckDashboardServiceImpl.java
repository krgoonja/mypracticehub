package com.sorincorp.bo.ma.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.ma.mapper.TrckDashboardMapper;
import com.sorincorp.comm.redis.config.RedisPubSubService;

@Service
public class TrckDashboardServiceImpl implements TrckDashboardService {

	@Value("${redisPubsub.uri.track}")
	private String trackUri;

	@Autowired
	private RedisPubSubService redisPubSubService;

	@Autowired
	TrckDashboardMapper trckDashboardMapper;

	@Override
	public Map<String, Object> selectTodayReport() {
		return trckDashboardMapper.selectTodayReport();
	}

	@Override
	public Map<String, Object> selectMonthReport() {
		return trckDashboardMapper.selectMonthReport();
	}

	@Override
	public List<Map<String, Object>> selectLoginLank() {
		return trckDashboardMapper.selectLoginLank();
	}

	@Override
	public List<Map<String, Object>> selectPurchLank() {
		return trckDashboardMapper.selectPurchLank();
	}

	@Override
	public List<Map<String, Object>> selectTodayPurchMber() {
		return trckDashboardMapper.selectTodayPurchMber();
	}

	@Override
	public List<Map<String, Object>> selectMonthSignUpList() {
		return trckDashboardMapper.selectMonthSignUpList();
	}

	@Override
	public List<Map<String, Object>> selectTodayVisitList() {
		return trckDashboardMapper.selectTodayVisitList();
	}

	@Override
	public List<Map<String, Object>> selectEntrpsCurrLocation() {
		List<Map<String, Object>> entrpsCurrLocationList = trckDashboardMapper.selectEntrpsCurrLocation();
		//PC, 모바일 분류
		for(Map<String, Object> entrpsCurrLocation : entrpsCurrLocationList) {
			boolean isMobile = ((String) entrpsCurrLocation.get("conectEnvrn")).matches(".*(iPhone|iPod|iPad|BlackBerry|Android|Windows CE|LG|MOT|SAMSUNG|SonyEricsson).*");
			
			if(isMobile) {
				entrpsCurrLocation.put("rceptMediaSeCode", "02");
			}else {
				entrpsCurrLocation.put("rceptMediaSeCode", "01");
			}
		}
		return entrpsCurrLocationList;
	}
	
	@Override
	public List<Map<String, Object>> selectRecentVisitList() {
		return trckDashboardMapper.selectRecentVisitList();
	}
	
	@Override
	public List<Map<String, Object>> selectTodayConvertList() {
		return trckDashboardMapper.selectTodayConvertList();
	}
	
	@Override
	public List<Map<String, Object>> selectMonthConvertAvg() {
		return trckDashboardMapper.selectMonthConvertAvg();
	}
	
	@Override
	public List<Map<String, Object>> selectTodayVisitPt() {
		return trckDashboardMapper.selectTodayVisitPt();
	}
	
	@Override
	public void trackEntrpsSecsn(Map<String, Object> param) throws Exception {
		//트래킹 테이블 회원탈퇴 승인여부 변경
		int result = trckDashboardMapper.updateTrackDetail(param);
		
		//트래킹 정보 레디스 전송
		if(result > 0) {
			Map<String, Object> trackMsgMap = new HashMap<>();
			trackMsgMap = trckDashboardMapper.selectTrackMsg(param);
			//PC, 모바일 분류
			boolean isMobile = ((String) trackMsgMap.get("conectEnvrn")).matches(".*(iPhone|iPod|iPad|BlackBerry|Android|Windows CE|LG|MOT|SAMSUNG|SonyEricsson).*");
			if(isMobile) {
				trackMsgMap.put("rceptMediaSeCode", "02");
			}else {
				trackMsgMap.put("rceptMediaSeCode", "01");
			}
			redisPubSubService.publishMessage(trackUri, "/track", trackMsgMap);
		}
	}
}
