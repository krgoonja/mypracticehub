package com.sorincorp.bo.ma.service;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

/**
 * DashboardWebsocketServiceImpl.java
 * BO 대시보드 websocket publish Service 구현체 클래스
 * @version
 * @since 2023. 5. 4.
 * @author srec0066
 */
@Slf4j
@Service
public class DashboardWebsocketServiceImpl implements DashboardWebsocketService {

	@Autowired
	private SimpMessagingTemplate simpMessagingTemplate;

	@Autowired
	private OrderDashboardService orderDashboardService;

	/**
	 *	라이브 주문정보 websocket publish
	 */
	@Override
	public void publishLiveOrder(String orderNo) {
		log.info("[DashboardWebsocketServiceImpl] publishLiveOrder IN");
		try {

			simpMessagingTemplate.convertAndSend("/subscriber/dashboard/order", orderNo);
		} catch (Exception e) {
			log.info("[DashboardWebsocketServiceImpl] publishLiveOrder ERROR :: ", ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 *	지정가 주문정보 websocket publish
	 */
	@Override
	public void publishLimitOrder(String limitOrderNo) {
		log.info("[DashboardWebsocketServiceImpl] publishLimitOrder IN");
		try {

			long stdrPremiumCnvrsnAmount = orderDashboardService.selectStdrPremiumCnvrsnAmount(limitOrderNo);
			log.info("[DashboardWebsocketServiceImpl] stdrPremiumCnvrsnAmount :: " + stdrPremiumCnvrsnAmount);

			simpMessagingTemplate.convertAndSend("/subscriber/dashboard/limitOrder", stdrPremiumCnvrsnAmount);
		} catch (Exception e) {
			log.info("[DashboardWebsocketServiceImpl] publishLimitOrder ERROR :: ", ExceptionUtils.getStackTrace(e));
		}
	}
	
	/**
	 *	다이버 작동 websocket publish
	 */
	@Override
	public void publishDiverRunning(String runningAt) {
		log.info("[DashboardWebsocketServiceImpl] publishDiverRunning IN");
		try {
			simpMessagingTemplate.convertAndSend("/subscriber/dashboard/diverRunning", runningAt);
		} catch (Exception e) {
			log.info("[DashboardWebsocketServiceImpl] publishDiverRunning ERROR :: ", ExceptionUtils.getStackTrace(e));
		}
	}

	@Override
	public void publishRcpmnyEvent(String orderNo) {
		log.info("[DashboardWebsocketServiceImpl] publishRcpmnyEvent IN");
		try {

			simpMessagingTemplate.convertAndSend("/subscriber/dashboard/rcpmny", orderNo);
		} catch (Exception e) {
			log.info("[DashboardWebsocketServiceImpl] publishRcpmnyEvent ERROR :: ", ExceptionUtils.getStackTrace(e));
		}
	}

}
