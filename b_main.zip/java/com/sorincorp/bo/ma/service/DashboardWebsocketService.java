package com.sorincorp.bo.ma.service;

/**
 * DashboardWebsocketService.java
 * BO 대시보드 websocket publish Service 인터페이스
 * @version
 * @since 2023. 5. 4.
 * @author srec0066
 */
public interface DashboardWebsocketService {

	/**
	 * <pre>
	 * 처리내용: 라이브 주문정보 websocket publish
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 */
	public void publishLiveOrder(String orderNo);

	/**
	 * <pre>
	 * 처리내용: 지정가 주문정보 websocket publish
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param limitOrderNo
	 */
	public void publishLimitOrder(String limitOrderNo);
	
	/**
	 * 다이버 작동 websocket publish
	 * @param runningAt
	 */
	public void publishDiverRunning(String runningAt);

	/**
	 * <pre>
	 * 처리내용: 가격 변동금 입금관련 websocket publish
	 * </pre>
	 * @date 2024. 10. 30.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 30.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public void publishRcpmnyEvent(String limitOrderNo);

}
