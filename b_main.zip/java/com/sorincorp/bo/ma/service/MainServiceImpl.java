package com.sorincorp.bo.ma.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.ma.mapper.MainMapper;

@Service
public class MainServiceImpl implements MainService {
	
	@Autowired
	MainMapper mainMapper;

	@Override
	public String newInqryCount() {
		return mainMapper.newInqryCount();
	}

	@Override
	public String solvedInqryCount() {
		
		int newInqry = Integer.parseInt(newInqryCount());
		int unsolveInqry = Integer.parseInt(unsolvedInqryCount());
		String solvedInqryCount = String.valueOf(newInqry-unsolveInqry);
		
		return solvedInqryCount;
	}
	
	@Override
	public String unsolvedInqryCount() {
		return mainMapper.unsolvedInqryCount();
	}
	
}
