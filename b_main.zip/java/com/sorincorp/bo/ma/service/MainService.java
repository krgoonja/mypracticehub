package com.sorincorp.bo.ma.service;

public interface MainService {

	public abstract String newInqryCount();

	public abstract String solvedInqryCount();

	public abstract String unsolvedInqryCount();
	
}
