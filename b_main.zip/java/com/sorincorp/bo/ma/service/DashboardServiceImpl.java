package com.sorincorp.bo.ma.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.ma.mapper.DashboardMapper;
import com.sorincorp.bo.ma.model.DashBoardEwalletVO;
import com.sorincorp.bo.ma.model.DashboardDlvyVO;
import com.sorincorp.bo.ma.model.DashboardInvntrySttusVO;
import com.sorincorp.bo.ma.model.DashboardOrderSttusVO;
import com.sorincorp.bo.ma.model.DashboardRltmOrderDetailVO;
import com.sorincorp.bo.ma.model.DashboardRltmOrderInfoVO;
import com.sorincorp.bo.ma.model.DashboardSelngVO;

/**
 * DashboardServiceImpl.java
 * BO 대쉬보드 ServiceImpl
 * 
 * @version
 * @since 2021. 11. 08.
 * @author srec0052
 */
@Service
public class DashboardServiceImpl implements DashboardService{
	
	@Autowired
	DashboardMapper dashboardMapper;
	
	/**
	 * 주문 건수 정보를 조회한다
	 */
	@Override
	public DashboardRltmOrderInfoVO selectOrderCntInfo() throws Exception {
		return dashboardMapper.selectOrderCntInfo();
	}
	
	/**
	 * 오늘 발생한 주문 리스트 조회
	 */
	@Override
	public List<DashboardRltmOrderInfoVO> selectTodayOrderList() throws Exception {
		return dashboardMapper.selectTodayOrderList();
	}

	/**
	 * 실시간 주문정보를 조회한다
	 */
	@Override
	public Map<String, Object> selectRltmOrderInfo(DashboardRltmOrderInfoVO dashboardRltmOrderInfoVO) throws Exception {
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		// 실시간 주문 정보 조회
		map.put("rltmOrderInfo", dashboardMapper.selectRltmOrderInfo(dashboardRltmOrderInfoVO));
		
		return map;
	}

	/**
	 * 주문 상세정보 조회
	 */
	@Override
	public Map<String, Object> selectRltmOrderDetail(DashboardRltmOrderDetailVO dashboardRltmOrderDetailVO) throws Exception {
		
		Map<String, Object> map = new HashMap<String, Object>();
		// 주문기본 정보
		map.put("orderBasInfo", dashboardMapper.selectOrderBasInfo(dashboardRltmOrderDetailVO));
		// 주문 이력 정보
		map.put("orderHistory", dashboardMapper.selectOrderHistory(dashboardRltmOrderDetailVO));
		// 물류 정보
		map.put("logistInfo", dashboardMapper.selectLogistInfo(dashboardRltmOrderDetailVO));
		
		return map;
	}

	/**
	 * 금일 주문 현황 주문 수 조회
	 */
	@Override
	public String selectOrderCnt() throws Exception {
		return dashboardMapper.selectOrderCnt();
	}

	/**
	 * 금일 주문 현황 통계 리스트
	 */
	@Override
	public List<DashboardOrderSttusVO> selectOrderSttusList() throws Exception {
		return dashboardMapper.selectOrderSttusList();
	}
	
	/**
	 * 금일 재고 현황 재고 수 조회
	 */
	@Override
	public String selectInvntryCnt() throws Exception {
		return dashboardMapper.selectInvntryCnt();
	}

	/**
	 * 금일 재고 현황 통계 리스트
	 */
	@Override
	public List<DashboardInvntrySttusVO> selectInvntrySttusList() throws Exception {
		return dashboardMapper.selectInvntrySttusList();
	}

	/**
	 * 매출현황 조회
	 */
	@Override
	public List<DashboardSelngVO> selectSelngList() throws Exception {
		return dashboardMapper.selectSelngList();
	}

	/**
	 * 배송현황 조회
	 */
	@Override
	public List<DashboardDlvyVO> selectDlvyList() throws Exception {
		return dashboardMapper.selectDlvyList();
	}
	
	/**
	 * 이웰렛잔고 조회
	 */
	@Override
	public List<DashBoardEwalletVO> selectEwlltList() throws Exception {
		return dashboardMapper.selectEwlltList();
	}
	
	/**
	 * 조달청 가격을 가져온다
	 */
	@Override
	public List<Map<String, Object>> getSarokPcList(String getNowDate) {

		List<Map<String, Object>> returnValue = new ArrayList<Map<String, Object>>();
		Map<String, Object> params = new HashMap<>();
		params.put("getNowDate", getNowDate);
		returnValue = dashboardMapper.getSarokPcList(params);
		return returnValue;
	}

}