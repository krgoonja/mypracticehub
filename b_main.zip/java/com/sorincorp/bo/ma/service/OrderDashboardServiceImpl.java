package com.sorincorp.bo.ma.service;

import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.chart.model.SelMetalVO;
import com.sorincorp.bo.ma.mapper.OrderDashboardMapper;
import com.sorincorp.bo.ma.model.DashboardInvntrySttusVO;
import com.sorincorp.bo.ma.model.DashboardLimitsOrderInfoVO;
import com.sorincorp.bo.ma.model.DashboardOrderCntVO;
import com.sorincorp.bo.ma.model.DashboardPrvsnlOrderVO;
import com.sorincorp.bo.ma.model.DashboardRltmOrderInfoVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.order.service.CommPrvsnlOrderService;
import com.sorincorp.comm.pcInfo.model.PrSelVO;

import lombok.extern.slf4j.Slf4j;

/**
 * OrderDashboardServiceImpl.java
 * 주문 대시보드 Service 구현체 클래스 (주문/ 지정가주문/ 소량구매)
 * @version
 * @since 2023. 5. 4.
 * @author srec0066
 */
@Slf4j
@Service
public class OrderDashboardServiceImpl implements OrderDashboardService {

	@Autowired
	private OrderDashboardMapper orderDashboardMapper;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private CommPrvsnlOrderService commPrvsnlOrderService;

	@Value("${lme.api.diver.url}")
	private String lmeDiverUrl;

	@Autowired
	private HttpClientHelper httpClientHelper;

	/**
	 *	주문 접수 현황 조회
	 */
	@Override
	public DashboardOrderCntVO selectOrderRceptCntInfo() throws Exception {
		// 주문 접수 현황 조회
		return orderDashboardMapper.selectOrderRceptCntInfo();
	}

	/**
	 *	재고 현황 조회 (LIVE + 소량구매)
	 */
	@Override
	public Map<String, Object> selectInvntrySttusList() throws Exception {
		LinkedHashMap<String, Object> returnMap = new LinkedHashMap<>();

		// 재고는 현재 라이브 [7:알루미늄, 1:아연] 만 조회하도록 함
		List<SelMetalVO> selMetalList = orderDashboardMapper.selectSelMetalList();

		for (int i = 0; i < selMetalList.size(); i++) {
			
			// 소량구매 재고 현황 조회
			List<DashboardInvntrySttusVO> selectSmlqyInvntrySttusList = orderDashboardMapper.selectSmlqyInvntrySttusList(selMetalList.get(i).getMetalCode());
			// 소량구매 재고 현황 조회 맵 전환 (key : rowKey[행구분 키 (LIVE와 소량구매 데이터 매치용)], value : smlqySleInvntryUnsleBundleBnt[소량 판매 재고 미판매 번들 잔량])
			Map<String, Long> selectSmlqyInvntrySttusMap = selectSmlqyInvntrySttusList.stream()
					.collect(Collectors.toMap(DashboardInvntrySttusVO::getRowKey, DashboardInvntrySttusVO::getSmlqySleInvntryUnsleBundleBnt, (o1, o2) -> o1, LinkedHashMap::new));
			
			// Live 재고 현황 조회
			List<DashboardInvntrySttusVO> selectLiveInvntrySttusList = orderDashboardMapper.selectLiveInvntrySttusList(selMetalList.get(i).getMetalCode());
			for(DashboardInvntrySttusVO dashboardInvntrySttusVO : selectLiveInvntrySttusList) {
				// 소량구매 재고 현황 조회 맵에서 소량 판매 재고 미판매 번들 잔량 값 가져오기
				dashboardInvntrySttusVO.setSmlqySleInvntryUnsleBundleBnt(selectSmlqyInvntrySttusMap.get(dashboardInvntrySttusVO.getRowKey()));
			}
			
			// LIVE 재고 현황 조회
			returnMap.put(selMetalList.get(i).getCodeChrctrRefrnsix(), selectLiveInvntrySttusList);
		}

		return returnMap;
	}

	/**
	 *	LIVE 지정가 호가창 조회
	 */
	@Override
	public Map<Long, List<DashboardLimitsOrderInfoVO>> selectLiveRltmLimitsOrderList() throws Exception {
		Map<Long, List<DashboardLimitsOrderInfoVO>> resultMap = new HashMap<Long, List<DashboardLimitsOrderInfoVO>>();

		List<DashboardLimitsOrderInfoVO> limitOrderList = orderDashboardMapper.selectLiveRltmLimitsOrderList();
		for (DashboardLimitsOrderInfoVO order : limitOrderList) {
			List<DashboardLimitsOrderInfoVO> listByPrice = new LinkedList<>();

			// 호가창 세팅 위한 카운터
			int spanCnt = 0;
			if(StringUtils.equals("Y", order.getSmlqyPurchsAt())) {
				// 소량구매
				spanCnt = 1;
			} else {
				// 바로구매
				spanCnt = order.getLimitOrderWt() / order.getSleUnitWt();
			}
			order.setTotLimitOrderCnt(spanCnt);

			// 호가별 주문리스트 세팅
			if(resultMap.containsKey(order.getStdrPremiumCnvrsnAmount())) {
				listByPrice = resultMap.get(order.getStdrPremiumCnvrsnAmount());
				listByPrice.add(order);

				resultMap.put(order.getStdrPremiumCnvrsnAmount(), listByPrice);
			} else {
				// 최조
				listByPrice.add(order);
				resultMap.put(order.getStdrPremiumCnvrsnAmount(), listByPrice);
			}
		}

		resultMap.entrySet().stream().forEach(entry -> {
			Long key = entry.getKey();

			resultMap.get(key).sort(Comparator.comparing(DashboardLimitsOrderInfoVO::getLimitOrderNo));
		});

		return resultMap;
	}

	/**
	 * 소량 구매 지정가 호가창 조회
	 */
	@Override
	public List<DashboardLimitsOrderInfoVO> selectSmlqyRltmLimitsOrderList() throws Exception {
		return orderDashboardMapper.selectSmlqyRltmLimitsOrderList();
	}

	/**
	 *	지정가 주문 접수 목록 조회
	 */
	@Override
	public List<DashboardLimitsOrderInfoVO> selectLimitsOrderRceptList() throws Exception {
		List<CommonCodeVO> dstrctLclsfCodes = commonCodeService.getSubCodesToCommonCode("DSTRCT_LCLSF_CODE"); 		// 권역
		List<CommonCodeVO> brandGroupCodes = commonCodeService.getSubCodesToCommonCode("BRAND_GROUP_CODE"); 		// 브랜드 그룹
		List<DashboardLimitsOrderInfoVO> limitsOrderRceptList = orderDashboardMapper.selectLimitsOrderRceptList();  // 지정가 주문 접수 목록

		for (DashboardLimitsOrderInfoVO limitsOrder : limitsOrderRceptList) {
			StringBuilder sb = new StringBuilder();
			// 권역
			for (int i = 0; i < dstrctLclsfCodes.size(); i++) {
				if(StringUtils.equals(dstrctLclsfCodes.get(i).getSubCode(), limitsOrder.getDstrctLclsfCode())) {
					sb.append(dstrctLclsfCodes.get(i).getCodeNm()+"/");
					break;
				}
			}
			// 브랜드 그룹
			for (int i = 0; i < brandGroupCodes.size(); i++) {
				if(StringUtils.equals(brandGroupCodes.get(i).getSubCode(), limitsOrder.getBrandGroupCode())) {
					sb.append(brandGroupCodes.get(i).getCodeDcone()+"/");
					break;
				}
			}
			// 브랜드
			sb.append(limitsOrder.getBrandCode().equals("0000000000") ? "무관" :limitsOrder.getBrandCode());
			limitsOrder.setTotBrand(sb.toString());
		}

		return limitsOrderRceptList;
	}
	
	/**
	 * 소량구매 지정가 주문 접수 목록 조회
	 */
	@Override
	public List<DashboardLimitsOrderInfoVO> selectSmlqyLimitsOrderRceptList() throws Exception {
		List<CommonCodeVO> dstrctLclsfCodes = commonCodeService.getSubCodesToCommonCode("DSTRCT_LCLSF_CODE"); 		// 권역
		List<CommonCodeVO> brandGroupCodes = commonCodeService.getSubCodesToCommonCode("BRAND_GROUP_CODE"); 		// 브랜드 그룹
		List<DashboardLimitsOrderInfoVO> smlqyLimitsOrderRceptList = orderDashboardMapper.selectSmlqyLimitsOrderRceptList();  // 소량구매 지정가 주문 접수 목록

		for (DashboardLimitsOrderInfoVO smlqyLimitsOrder : smlqyLimitsOrderRceptList) {
			StringBuilder sb = new StringBuilder();
			// 권역
			for (int i = 0; i < dstrctLclsfCodes.size(); i++) {
				if(StringUtils.equals(dstrctLclsfCodes.get(i).getSubCode(), smlqyLimitsOrder.getDstrctLclsfCode())) {
					sb.append(dstrctLclsfCodes.get(i).getCodeNm()+"/");
					break;
				}
			}
			// 브랜드 그룹
			for (int i = 0; i < brandGroupCodes.size(); i++) {
				if(StringUtils.equals(brandGroupCodes.get(i).getSubCode(), smlqyLimitsOrder.getBrandGroupCode())) {
					sb.append(brandGroupCodes.get(i).getCodeDcone()+"/");
					break;
				}
			}
			// 브랜드
			sb.append(smlqyLimitsOrder.getBrandCode().equals("0000000000") ? "무관" :smlqyLimitsOrder.getBrandCode());
			smlqyLimitsOrder.setTotBrand(sb.toString());
		}

		return smlqyLimitsOrderRceptList;
	}

	/**
	 *	금일 주문 목록 조회
	 */
	@Override
	public List<DashboardRltmOrderInfoVO> selectTodayOrderList() throws Exception {
		return orderDashboardMapper.selectTodayOrderList();
	}

	/**
	 *	기준 프리미엄 환산 금액 조회
	 */
	@Override
	public Long selectStdrPremiumCnvrsnAmount(String limitOrderNo) throws Exception {
		return orderDashboardMapper.selectStdrPremiumCnvrsnAmount(limitOrderNo);
	}

	/**
	 *	재고 현황 조회대상 금속리스트 조회
	 */
	@Override
	public List<String> selectSelMetalList() throws Exception {
		List<String> metalList = orderDashboardMapper.selectSelMetalList().stream().map(SelMetalVO::getMetalCode).collect(Collectors.toList());
		return metalList;
	}

	/**
	 *	다이버 상태 조회
	 */
	@Override
	public boolean selectDiverInfo() throws Exception {
		Map<String, Object> resObj = Optional.ofNullable(httpClientHelper.postCallApi(lmeDiverUrl, null))
		.orElseThrow(() -> {
			log.error("selectDiverInfo httpClientHelper postCallApi lmeDiverMotnCndCnfirm 호출 실패 url : {}", lmeDiverUrl);
			return new Exception("다이버 발동 상태 확인 중 오류가 발생하였습니다. ");
		});
		String diverStatusCode = String.valueOf(Optional.ofNullable(resObj.get("diverStatusCode")).orElse("0"));// 0 대기 1 하강 2 상승
		String diverAt = String.valueOf(Optional.ofNullable(resObj.get("diverAt")).orElse("N"));//Y : ON, N : OFF
		if(diverAt.equals("N") || diverStatusCode.equals("0")) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * 가단가 구매 평가 목록 조회
	 */
	@Override
	public List<DashboardPrvsnlOrderVO> selectPrvsnlPurchsEvlList() throws Exception {
		Map<String, PrSelVO> groupCodeMap = new HashMap<>();
		List<DashboardPrvsnlOrderVO> prvsnlPurchsEvlList = orderDashboardMapper.selectPrvsnlPurchsEvlList();

		// 그룹코드별 실시간 가격 매핑
		for (DashboardPrvsnlOrderVO order : prvsnlPurchsEvlList) {
			if(groupCodeMap.containsKey(order.getGroupCode())) {
				continue;
			} else {
				// 가장 최근 가격정보 조회 (프리미엄 제외 endPc)
				PrSelVO prSelVO = Optional.ofNullable(commPrvsnlOrderService.getPreRealEndPc(order.getMetalCode(),
																 order.getItmSn(),
																 order.getDstrctLclsfCode(),
																 order.getBrandGroupCode(),
																 order.getBrandCode())).orElse(new PrSelVO());

				groupCodeMap.put(order.getGroupCode(), prSelVO);
			}
		}

		for (DashboardPrvsnlOrderVO order : prvsnlPurchsEvlList) {
			PrSelVO prSelVO = groupCodeMap.get(order.getGroupCode());

			order.setRealEndpc(prSelVO.getNonPremiumEndPc()); // 프리미엄 제외 가격 세팅
		}

		return prvsnlPurchsEvlList;
	}

	/**
	 * 변동금 입금 대상 목록 조회
	 */
	@Override
	public List<DashboardPrvsnlOrderVO> selectChangeAmountRcpmnyTrgetList() throws Exception {
		return orderDashboardMapper.selectChangeAmountRcpmnyTrgetList();
	}
}
