package com.sorincorp.bo.ma.model;

import lombok.Data;

@Data
public class DashboardDlvyVO {
	
	private static final long serialVersionUID = 2904375848327594320L;
	
	/**
	 * 날짜
	 */
	private String de;
	/**
	 * 자차 출차건수
	 */
	private int selfAll;
	/**
	 * 자차 출고완료 건수
	 */
	private int selfCompt;
	/**
	 * 자차 출고율
	 */
	private String selfRpblty;
	/**
	 * 케이지배송 출차건수
	 */
	private int sorinAll;
	/**
	 * 케이지배송 출고완료 건수
	 */
	private int sorinCompt;
	/**
	 * 케이지배송 출고율
	 */
	private String sorinRpblty;
	
	
}
