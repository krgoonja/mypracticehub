package com.sorincorp.bo.ma.model;

import lombok.Data;

@Data
public class DashboardRltmOrderInfoVO {

	private static final long serialVersionUID = 903727453498385762L;

	private int cnt;
	/**
	 * 월 주문 건수
	 */
	private int monthOrderCnt;
	/**
	 * 일 주문 건수
	 */
	private int dayOrderCnt;
	/**
	 * 주문번호
	 */
	private String orderNo;
	/**
	 * 주문일자
	 */
	private String orderDe;
	/**
	 * 주문완료 일자
	 */
	private String orderComptDt;
	/**
	 * 업체명
	 */
	private String entrpsNm;
	/**
	 * 업체번호
	 */
	private String entrpsNo;
	/**
	 * 배송수단 코드
	 */
	private String dlvyMnCode;
	/**
	 * 출고요청 일
	 */
	private String dlivyRequstDe;
	/**
	 * 주문 배송지 번호
	 */
	private String orderDlvrgNo;
	/**
	 * 배송수단 명
	 */
	private String dlvyMnNm;
	/**
	 * 메탈코드
	 */
	private String metalCode;
	/**
	 * 메탈코드 명
	 */
	private String metalNm;
	/**
	 * 권역 대분류 코드
	 */
	private String dstrctLclsfCode;
	/**
	 * 권역 대분류 명
	 */
	private String dstrctLclsfNm;
	/**
	 * 브랜드 코드
	 */
	private String brandCode;
	/**
	 * 브랜드 명
	 */
	private String brandNm;
	/**
	 * 총 실제 주문 중량
	 */
	private java.math.BigDecimal totRealOrderWt;
	/**
	 * 총 실제 주문 중량
	 */
	private String totRealOrderWtNm;
	/**
	 * 확정 중량
	 */
	private java.math.BigDecimal totDcsnWt;
	/**
	 * 판매 방식 코드
	 */
	private String sleMthdCode;
	/**
	 * 판매 방식 명
	 */
	private String sleMthdNm;
	/**
	 * 결제 수단 명
	 */
	private String setleMthdNm;
	/**
	 * 접수 매체 구분 코드
	 */
	private String rceptMediaSeCode;
	/**
	 * 상품 단가
	 */
	private String goodsUntpc;
}
