package com.sorincorp.bo.ma.model;

import lombok.Data;

@Data
public class DashboardOrderSttusVO {
	
	private static final long serialVersionUID = 340124553545379191L;
	
	/**
	 * 건수
	 */
	private int cnt;
	/**
	 * 권역 코드
	 */
	private String dstrctCode;
	/**
	 * 이전 권역 코드
	 */
	private String prevDstrctCode;
	/**
	 * 권역
	 */
	private String dstrct;
	/**
	 * 배송
	 */
	private String dlvy;
	/**
	 * 주문건수
	 */
	private int orderCnt;
	/**
	 * 모바일 주문건수
	 */
	private int mobileOrderCnt;
	/**
	 * 주문중량
	 */
	private java.math.BigDecimal wt;
	/**
	 * 모바일 주문중량
	 */
	private java.math.BigDecimal mobileWt;
	/**
	 * 주문금액
	 */
	private long amount;
	/**
	 * 모바일 주문금액
	 */
	private long mobileAmount;
	
}
