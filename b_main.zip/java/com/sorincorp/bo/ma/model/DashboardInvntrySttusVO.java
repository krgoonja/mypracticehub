package com.sorincorp.bo.ma.model;

import lombok.Data;

@Data
public class DashboardInvntrySttusVO {

	private static final long serialVersionUID = 461246324355379178L;

	/**
	 * 건수
	 */
	private int cnt;
	/**
	 * 금속 코드
	 */
	private String metalCode;
	/**
	 * 권역 코드
	 */
	private String dstrctLclsfCode;
	/**
	 * 권역 코드 명
	 */
	private String dstrctLclsfNm;
	/**
	 * 이전 권역 코드
	 */
	private String prevDstrctLclsfCode;
	/**
	 * 브랜드 그룹 코드
	 */
	private String brandGroupCode;
	/**
	 * 브랜드 그룹 코드 명
	 */
	private String brandGroupNm;
	/**
	 * 브랜드 그룹 코드 커스텀 명
	 */
	private String brandGroupNmCustm;
	/**
	 * 기초 입고재고
	 */
	private String bsisWrhousngInvntry;
	/**
	 * 판매 설정 중량
	 */
	private String sleSetupWt;
	/**
	 * 시작
	 */
	private long enter;
	/**
	 * 판매
	 */
	private long ple;
	/**
	 * 잔량
	 */
	private long bnt;
	/**
	 * 미할당
	 */
	private long unasgn;
	/**
	 * 판매 재고 미판매 번들 잔량
	 */
	private long sleInvntryUnsleBundleBnt;
	
	/**
	 * 행구분 키 (LIVE와 소량구매 데이터 매치용)
	 */
	private String rowKey;
	
	/**
     * 소량 판매 재고 미판매 번들 잔량
     */
    private long smlqySleInvntryUnsleBundleBnt;	
}
