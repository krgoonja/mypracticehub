package com.sorincorp.bo.ma.model;

import lombok.Data;

@Data
public class DashboardOrderCntVO {

	/** 오늘 주문 건수  */
	private int todayOrderCnt;
	/** 오늘 주문 수량 */
	private int todayOrderWt;
	/** 당월 주문 건수  */
	private int monthOrderCnt;
	/** 당월 주문 수량  */
	private int monthOrderWt;
	/** 지정가 주문 체결 건수 */
	private int limitOrderCmpltCnt;
	/** 지정가 주문 대기 건수 */
	private int limitOrderWaitCnt;
	/** 소량구매 주문 건수 */
	private int smlqyPurchsOrderCnt;
	/** 소량구매 주문 수량 */
	private int smlqyPurchsOrderWt;
}
