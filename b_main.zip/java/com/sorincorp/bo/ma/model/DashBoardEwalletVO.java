package com.sorincorp.bo.ma.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class DashBoardEwalletVO implements Serializable {

	private static final long serialVersionUID = 7402433857088002190L;

	/**
	 * 이웰렛 거래 일시
	 */
	private String ewalletDelngDt;
	
	/**
	 * 이웰렛 입금  
	 */
	private String ewalletDeposit;
	
	/**
	 * 이웰렛 정산 
	 */
	private String ewalletCal;
	
	/**
	 * 이월렛 환불
	 */
	private String ewalletRefund;
	
	/**
	 * 이웰렛 출금
	 */
	private String ewalletWithdraw;
	
	/**
	 * 이웰렛 잔액
	 */
	private String ewalletBalance;
}
