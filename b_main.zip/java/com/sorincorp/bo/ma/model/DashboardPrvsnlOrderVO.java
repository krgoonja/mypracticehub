package com.sorincorp.bo.ma.model;

import lombok.Data;

@Data
public class DashboardPrvsnlOrderVO {

	/** 주문번호 */
	private String orderNo;
	/** 업체명 약어 한글  */
    private String entrpsnmKoreanShort;
    /** 총 실제 주문 중량 */
    private int totRealOrderWt;
    /** 평균가 상품 단가 */
    private long avrgpcGoodsUntpc;
    /** 프리미엄 가격 */
    private long premiumPc;
	/** 입출금 대상 금액 */
    private String rcppayTrgetAmount;
	/** 가격 변동금 상태*/
    private String pcChangegldSttus;
    /** 권역 대분류 코드 */
    private String dstrctLclsfCode;
    /** 금속 코드 */
    private String metalCode;
    /** 아이템 순번 */
    private int itmSn;
    /** 브랜드 그룹 코드 */
    private String brandGroupCode;
    /** 브랜드 코드 */
    private String brandCode;
    /** 그룹 코드 (실시간 가격 조회용) */
    private String groupCode;
    /** 프리미엄 제외 현재가 */
    private long realEndpc;
    /** 확정 변동 단가 */
    private long dcsnChangeUntpc;
}
