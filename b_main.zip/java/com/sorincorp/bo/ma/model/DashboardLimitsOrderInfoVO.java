package com.sorincorp.bo.ma.model;

import lombok.Data;

@Data
public class DashboardLimitsOrderInfoVO {

	/** 지정가 주문 시각 */
    private String limitOrderTm;
    /** 주문 업체 명 */
    private String orderEntrpsNm;
    /** 상품명 */
    private String goodsNm;
    /** 출고권역 + 브랜드 그룹 + 브랜드 */
    private String totBrand;
    /** 권역 대분류 코드 */
    private String dstrctLclsfCode;
    /** 권역 대분류 명 */
    private String dstrctLclsfNm;
    /** 브랜드 그룹 코드 */
    private String brandGroupCode;
    /** 브랜드 그룹 명 */
    private String brandGroupNm;
    /** 브랜드 코드 */
    private String brandCode;
    /** 브랜드 명 */
    private String brandNm;
    /** 지정가 주문 중량 */
    private int limitOrderWt;
    /** 지정가 입력 금액 */
    private long limitInputAmount;

    /** 기준 프리미엄 환산 금액(호가) */
    private long stdrPremiumCnvrsnAmount;
    /** 총 접수(주문) 건수 */
    private int totLimitOrderCnt;
    /** 총 주문 톤수 */
    private int totLimitOrderWt;
    private int sleUnitWt;

    /** 지정가 주문 번호 */
    private String limitOrderNo;
    /** 소량 구매 여부 */
    private String smlqyPurchsAt;
}
