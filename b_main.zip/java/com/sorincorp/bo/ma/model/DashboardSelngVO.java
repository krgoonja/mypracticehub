package com.sorincorp.bo.ma.model;

import lombok.Data;

@Data
public class DashboardSelngVO {
	
	private static final long serialVersionUID = 9384712892945578L;
	
	/**
	 * 건수
	 */
	private int cnt;
	/**
	 * 기준일
	 */
	private String de;
	/**
	 * 이론중량
	 */
	private java.math.BigDecimal totRealOrderWt;
	/**
	 * 공급가액
	 */
	private long splpc;
	/**
	 * 확정중량
	 */
	private java.math.BigDecimal totDcsnWt;
	/**
	 * 확정 공금가액
	 */
	private long totDcsnSplpc;
	
	
	////////////////////////////////////////////////////////////
	
	/**
	 * 주문중량
	 */
	private java.math.BigDecimal busanWt;
	/**
	 * 주문금액
	 */
	private long busanSelng;
	/**
	 * 모바일 주문금액
	 */
	private long busanPrfts;
	/**
	 * 주문중량
	 */
	private java.math.BigDecimal incheonWt;
	/**
	 * 주문금액
	 */
	private long incheonSelng;
	/**
	 * 모바일 주문금액
	 */
	private long incheonPrfts;
	
	
}
