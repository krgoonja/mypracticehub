package com.sorincorp.bo.ma.model;

import lombok.Data;

@Data
public class DashboardRltmOrderDetailVO {
	
	private static final long serialVersionUID = 9037271243537653762L;
	
	/**
	 * 주문번호
	 */
	private String orderNo;
	/**
	 * 주문일자 
	 */
	private String orderDe;
	/**
	 * 주문완료 일자
	 */
	private String orderComptDt;
	/**
	 * 업체명
	 */
	private String entrpsNm;
	/**
	 * 업체번호
	 */
	private String entrpsNo;
	/**
	 * 금속코드
	 */
	private String metalNm;
	/**
	 * 총 실제 주문 중량
	 */
	private java.math.BigDecimal totRealOrderWt;
	/**
	 * 총 실제 주문 중량 
	 */
	private String totRealOrderWtNm;
	/**
	 * 권역 대분류 코드
	 */
	private String dstrctLclsfCode;
	/**
	 * 권역 대분류 코드 명
	 */
	private String dstrctLclsfNm;
	/**
	 * 브랜드 코드
	 */
	private String brandCode;
	/**
	 * 브랜드 명
	 */
	private String brandNm;
	
	
	
	/**
	 * 프라이싱 분류 코드
	 */
	private String pricingStepCode;
	/**
	 * 프라이싱 분류 코드 명
	 */
	private String pricingStepNm;
	/**
	 * 일시
	 */
	private String de;
	/**
	 * 상품 단가
	 */
	private long goodsUntpc;
	/**
	 * 주문 중량
	 */
	private java.math.BigDecimal orderWt;
	/**
	 * 주문 금액
	 */
	private long orderPc;
	
	
	/**
	 * 배송 주문지 번호
	 */
	private String orderDlvrgNo;
	/**
	 * 배송 차수
	 */
	private int dlvyOdr;
	/**
	 * 창고 코드
	 */
	private String wrhousCode;
	/**
	 * 창고명
	 */
	private String wrhousNm;
	/**
	 * net 확정 중량
	 */
	private java.math.BigDecimal netDcsnWt;
	/**
	 * 확정번들 수량
	 */
	private int dcsnBundleQy;
	/**
	 * 배송수단 코드
	 */
	private String dlvyMnCode;
	/**
	 * 출고요청 일
	 */
	private String dlivyRequstDe;
	/**
	 * 수취업체 도로명 주소
	 */
	private String receptEntrpsRnAdres;
	/**
	 * 수취업체 상세 주소
	 */
	private String receptEntrpsRnDetailAdres;
	
	
	
}
