package com.sorincorp.bo.ma.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class TrckDashboardVO extends CommonVO {

	/**
	  기준 일자
	 */
	 private String std;
	 
	 /**
	  방문자 수
	 */
	 private String visitrCnt;
	 
	 /**
	  로그인 회원 수
	 */
	 private String visitrIdCnt;
	 
	 /**
	  구매 회원 수
	 */
	 private String visitrPurchaseCnt;
	 
	 /**
	  로그인 전환율
	 */
	 private float convertRate;
	 
	 /**
	  유입
	 */
	 private float visitrIncomeRate;
	 
	 /**
	  로그인
	 */
	 private float visitrLoginRate;
	 
	 /**
	  상품탐색
	 */
	 private float visitrSearchRate;
	 
	 /**
	  주문입력
	 */
	 private float visitrInputRate;
	 
	 /**
	  결제
	 */
	 private float visitrPurchaseRate;
	 
	 /**
	  당월 로그인 전환율
	 */
	 private float convertYmRate;
	 
	 /**
	  유입 경로
	 */
	 private String inflowCoursNm;
	 
	 /**
	  유입 경로 백분률
	 */
	 private float inflowCoursPt;
}
