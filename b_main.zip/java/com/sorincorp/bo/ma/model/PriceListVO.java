package com.sorincorp.bo.ma.model;

import java.math.BigDecimal;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class PriceListVO extends CommonVO {

	private static final long serialVersionUID = 1L;

	/**
	 * 금속 코드
	 */
	private String metalCode;
	/**
	 * 금속 코드 영문명
	 */
	private String codeDcone;
	/**
	 * 금속 코드 한글명
	 */
	private String codeChrctrRefrnsix;
	/**
	 * 실시간 종가
	 */
	private long endPc;
	/**
	 * 최근 종가
	 */
	private long deEndPc;
	/**
	 * 환율 실시간 종가
	 */
	private BigDecimal ehgtEndPc;
	/**
	 * 등락률
	 */
	private float fluctuationRate;
	/**
	 * 아이탬 순번
	 */
	private int itmSn;
	/**
	 * 권역 코드
	 */
	private String dstrctLclsfCode;
	/**
	 * 권역 이름
	 */
	private String dstrctLclsfName;
	/**
	 * 브랜드 그룹 코드
	 */
	private String brandGroupCode;
	/**
	 * 브랜드 코드
	 */
	private String brandCode;
	/**
	 * 조달청 가격
	 */
	private BigDecimal sarokPc;
	/**
	 * 아이템 이름
	 */
	private String itemCodeName;
}
