package com.sorincorp.bo.ma.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.co.model.MenuVO;
import com.sorincorp.bo.co.service.MenuService;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.bo.it.service.ItemInvntrySetupService;
import com.sorincorp.bo.ma.service.MainService;
import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.brandcode.service.BrandCodeService;
import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;
import com.sorincorp.comm.brandgroupcode.service.BrandGroupCodeService;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.wrhouscode.model.WrhousCodeVO;
import com.sorincorp.comm.wrhouscode.service.WrhousCodeService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class MainController {

	@Autowired
	MainService mainService;
	
	@Autowired
	private ItemInvntrySetupService itemInvntrySetupService;
	@Autowired
	private ItCmnCodeService itCmnCodeService;
	@Autowired
	private ItemCodeService itemCodeService;
	@Autowired
	private BrandGroupCodeService brandGroupCodeService;
	@Autowired
	private BrandCodeService brandCodeService;
	@Autowired
	private WrhousCodeService wrhousCodeService;
	@Autowired
	private MenuService menuService;

	@RequestMapping("/")
	public String index(Model model){
		try {
			return "ma/main.tiles";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
		
//		try {
//			ItCmnCodeVO vo = new ItCmnCodeVO();
//			vo.setMainCode("METAL_CODE");
//			vo.setCodeDctwo("Y");
//			vo.setUseAt("Y");
//			//메탈코드 리스트
//			List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);
//
//			vo.setMainCode("DSTRCT_LCLSF_CODE");
//			vo.setCodeDctwo("");
//			vo.setUseAt("Y");
//			//권역 대분류 리스트
//			List<ItCmnCodeVO> dstrctLclsfCodeList = itCmnCodeService.selectCmnCodeList(vo);
//
//			vo.setMainCode("DSTRCT_MLSFC_CODE");
//			vo.setCodeDctwo("");
//			vo.setUseAt("Y");
//			//권역 중분류 리스트
//			List<ItCmnCodeVO> dstrctMlsfcCodeList = itCmnCodeService.selectCmnCodeList(vo);
//
//			//판매상태 코드 리스트 조회
//			vo.setMainCode("GOODS_SLE_STTUS_CODE");
//			vo.setCodeDctwo("");
//			vo.setUseAt("Y");
//			//권역 중분류 리스트
//			List<ItCmnCodeVO> goodsSleSttusCodeList = itCmnCodeService.selectCmnCodeList(vo);
//
//			//아이템 리스트
//			List<ItemCodeVO> itemCodeList = itemCodeService.getItemCodeList("");
//			//브랜드 그룹코드 리스트
//			List<BrandGroupCodeVO> brandGroupCodeList = brandGroupCodeService.getBrandGroupCodeList("");
//			//브랜드코드 리스트
//			List<BrandCodeVO> brandCodeList = brandCodeService.getBrandCodeList("");
//			//물류센터 리스트 조회
//			List<WrhousCodeVO> wrhousCodeList = wrhousCodeService.getWrhousCode();
////			for(int i=0;i<wrhousCodeList.size();i++) {
////				log.debug("wrhousCodeList ==========>" + wrhousCodeList.get(i).toString());
////			}
//			//물류센터 위치 리스트 조회
//			List<ItCmnCodeVO> wrhousCellLcList = itemInvntrySetupService.getWrhousCellLcList("");
//
//			model.addAttribute("metalCodeList", metalCodeList);
//			model.addAttribute("itemCodeList", itemCodeList);
//			model.addAttribute("dstrctLclsfCodeList", dstrctLclsfCodeList);
//			model.addAttribute("dstrctMlsfcCodeList", dstrctMlsfcCodeList);
//
//			model.addAttribute("brandGroupCodeList", brandGroupCodeList);
//			model.addAttribute("brandCodeList", brandCodeList);
//			model.addAttribute("wrhousCodeList", wrhousCodeList);
//			model.addAttribute("goodsSleSttusCodeList", goodsSleSttusCodeList);
//			model.addAttribute("wrhousCellLcList", wrhousCellLcList);
//
//			List<MenuVO> menuList = menuService.getSideBarMenu(); //권한 없이 사이드 메뉴 모두 조회
//			for(MenuVO menu : menuList) {
//				if("/bo/it/selectBlNoInqireList".equals(menu.getMenuUrl())) {
//					//log.debug(menu.toString());
//					model.addAttribute("menuNo", Integer.toString(menu.getMenuNo()));
//				}
//			}
//
//			return "it/itemInvntrySetupList.tiles";
//		} catch(Exception e){
//			log.error(e.getMessage());
//			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
//			return "error/503";
//		}
	}

	@ResponseBody
	@GetMapping("/bo/ma/csStatus")
	public Map<String, Object> selectMainCsStatus() {
		Map<String, Object> map = new HashMap<>();
		
		map.put("newInqry", mainService.newInqryCount()); // 오늘 새로 들어온 문의개수
		map.put("solvedInqry", mainService.solvedInqryCount()); // 오늘 해결한 문의개수
		map.put("unsolvedInqry", mainService.unsolvedInqryCount()); // 전체 미해결 문의개수
		return map;
	}

}