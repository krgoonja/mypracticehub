package com.sorincorp.bo.ma.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.bo.ma.service.TrckDashboardService;

import lombok.extern.slf4j.Slf4j;

/**
 * @ClassName: TrckDashboardController
 * @Author: chajeeman
 * @Date: 2023. 6. 20.
 */
@Slf4j
@Controller
@RequestMapping("/bo/trckDashboard")
public class TrckDashboardController {
	
	@Autowired
	private TrckDashboardService trckDashboardService;

	/**
	 * <pre>
	 * 처리내용:
	 * </pre>
	 * 
	 * @date 2023. 6. 20.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2023. 6. 20.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param model
	 * @return
	 */
	@RequestMapping("/viewTrckDashboard")
	public String viewDashboard(Model model) {
		try {

			// JS파일에서 사용 하기위한 JSON데이터로 변환
			ObjectMapper objectMapper = new ObjectMapper();
			String entrpsCurrLocation = objectMapper.writeValueAsString(trckDashboardService.selectEntrpsCurrLocation());
			
			model.addAttribute("todayReport", trckDashboardService.selectTodayReport());
			model.addAttribute("monthReport", trckDashboardService.selectMonthReport());
			model.addAttribute("entrpsCurrLocation", entrpsCurrLocation);
			
			return "ma/trckDashboard";
		} catch (Exception e) {

			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 누적 접속 랭킹 조회
	 * </pre>
	 * @date 2023. 06. 21
	 * @author srec0068
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 06. 21			srec0068			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/loginLank")
	@ResponseBody
	public Map<String, Object> selectLoginLank() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("loginLank", trckDashboardService.selectLoginLank());
		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 누적 구매 랭킹 조회
	 * </pre>
	 * @date 2023. 06. 21
	 * @author srec0068
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 06. 21			srec0068			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/purchLank")
	@ResponseBody
	public Map<String, Object> selectPurchLank() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("purchLank", trckDashboardService.selectPurchLank());
		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 누적 구매 랭킹 조회
	 * </pre>
	 * @date 2023. 06. 21
	 * @author srec0068
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 06. 21			srec0068			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/todayPurchMber")
	@ResponseBody
	public Map<String, Object> selectTodayPurchMber() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("todayPurchMber", trckDashboardService.selectTodayPurchMber());
		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 누적 구매 랭킹 조회
	 * </pre>
	 * @date 2023. 06. 21
	 * @author srec0068
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 06. 21			srec0068			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/monthSignUpList")
	@ResponseBody
	public Map<String, Object> selectMonthSignUpList() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("monthSignUpList", trckDashboardService.selectMonthSignUpList());
		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 누적 구매 랭킹 조회
	 * </pre>
	 * @date 2023. 06. 21
	 * @author srec0068
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 06. 21			srec0068			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/todayVisitList")
	@ResponseBody
	public Map<String, Object> selectTodayVisitList() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("todayVisitList", trckDashboardService.selectTodayVisitList());
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 최근 5일 방문자 수 조회
	 * </pre>
	 * @date 2023. 07. 13
	 * @author bok3117
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 13			bok3117				최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/recentVisitChartList")
	@ResponseBody
	public Map<String, Object> selectRecentVisitChartList() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("recentVisitList", trckDashboardService.selectRecentVisitList());
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 당일 파널 별, 구매 전환율 조회
	 * </pre>
	 * @date 2023. 07. 14
	 * @author bok3117
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 14			bok3117				최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/todayConvertChartList")
	@ResponseBody
	public Map<String, Object> selectTodayConvertChartList() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("todayConvertList", trckDashboardService.selectTodayConvertList());
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 당월 로그인 전환률 (평균)
	 * </pre>
	 * @date 2023. 07. 14
	 * @author bok3117
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 14			bok3117				최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/monthConvertChartAvg")
	@ResponseBody
	public Map<String, Object> selectMonthConvertChartAvg() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("monthConvertAvg", trckDashboardService.selectMonthConvertAvg());
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: Today 방문자 기록 조회
	 * </pre>
	 * @date 2023. 07. 25
	 * @author bok3117
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 25			bok3117				최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/todayVisitListPt")
	@ResponseBody
	public Map<String, Object> selectTodayVisitListPt() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("todayVisitList", trckDashboardService.selectTodayVisitPt());
		return map;
	}
	
	@PostMapping("/trackEntrpsSecsn")
	@ResponseBody
	public void trackMberSecsn(@RequestBody Map<String, Object> param) throws Exception {
		trckDashboardService.trackEntrpsSecsn(param);
	}
}