package com.sorincorp.bo.ma.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.bo.chart.service.PcChartMntrngService;
import com.sorincorp.bo.ma.service.OrderDashboardService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.pcInfo.model.RvcmpnVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * OrderDashboardController.java
 * 주문 대시보드 Controller 클래스 (주문/ 지정가주문/ 소량구매)
 * @version
 * @since 2023. 5. 4.
 * @author srec0066
 */
@Slf4j
@Controller
@RequestMapping("/bo/orderDashboard")
public class OrderDashboardController {

	@Autowired
	private PcChartMntrngService pcMntrngService;

	@Autowired
	private OrderDashboardService orderDashboardService;
	
	@Autowired
	private PcInfoService pcInfoService;
	
	@Autowired
	private CommonCodeService commonCodeService;

	/**
	 * <pre>
	 * 처리내용: 주문 대시보드 화면 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 */
	@RequestMapping("/viewDashboard")
	public String viewDashboard(Model model) {
		try {
			Map<String, Object> mainChart = new HashMap<String,Object>();

			mainChart = pcMntrngService.getMainChartData();
			model.addAttribute("chartList", mainChart);

			//JS파일에서 사용 하기위한 JSON데이터로 변환
			ObjectMapper objectMapper = new ObjectMapper();
			String jsonMainChart = objectMapper.writeValueAsString(mainChart);

			model.addAttribute("jsonChartList", jsonMainChart);
			model.addAttribute("metalCodeList", orderDashboardService.selectSelMetalList());

			return "ma/orderDashboard";
		} catch (Exception e) {

			log.error(ExceptionUtils.getStackTrace(e));
			return "error/503";
		}
	}
	
	@PostMapping("/getSarokData")
	@ResponseBody
	public Map<String, Object> getSarokData(@RequestBody Map<String, Object> param) throws Exception {
		String metalCode = (String) param.get("metalCode");
		Map<String, Object> map = new HashMap<String, Object>();
		
		//권역 조회
		Map<String, CommonCodeVO> brandCode = commonCodeService.getSubCodesRetVo("BRAND_GROUP_CODE");
		
		//조달청 가격 조회
		List<RvcmpnVO> rvcmpnVOList = pcInfoService.getRvcmpn(DateUtil.getNowDate(), metalCode);
		if(!rvcmpnVOList.isEmpty()) {
			for (RvcmpnVO rvcmpnVO : rvcmpnVOList) {
				rvcmpnVO.setBrandGroupName(brandCode.get(rvcmpnVO.getBrandGroupCode()).getCodeDcone());
			}
		}
		
		map.put("sarokData", rvcmpnVOList);
		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 주문 접수 현황 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/orderRceptCntInfo")
	@ResponseBody
	public Map<String, Object> selectOrderRceptCntInfo() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		
		// 주문 접수 현황 조회
		map.put("orderRceptCntInfo", orderDashboardService.selectOrderRceptCntInfo());

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 재고 현황 조회 (LIVE + 소량구매)
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/invntrySttus")
	@ResponseBody
	public Map<String, Object> selectInvntrySttusList() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		// 재고 현황 조회 (LIVE + 소량구매)
		map.put("invntrySttus", orderDashboardService.selectInvntrySttusList());

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: LIVE 지정가 호가창 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/rltmLimitsOrderList")
	@ResponseBody
	public Map<String, Object> selectRltmLimitsOrderList() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("rltmLimitsOrderList", orderDashboardService.selectLiveRltmLimitsOrderList());

		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 소량 구매 지정가 호가창 조회
	 * </pre>
	 * @date 2024. 5. 27.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 27.          srec0049         최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/rltmSmlqyLimitsOrderList")
	@ResponseBody
	public Map<String, Object> selectRltmSmlqyLimitsOrderList() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("rltmSmlqyLimitsOrderList", orderDashboardService.selectSmlqyRltmLimitsOrderList());

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 접수 목록 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/limitsOrderList")
	@ResponseBody
	public Map<String, Object> selectLimitsOrderRceptList() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("limitsOrderList", orderDashboardService.selectLimitsOrderRceptList());

		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 소량구매 지정가 주문 접수 목록 조회
	 * </pre>
	 * @date 2024. 5. 27.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 27.          srec0049         최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/smlqyLimitsOrderList")
	@ResponseBody
	public Map<String, Object> selectSmlqyLimitsOrderRceptList() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("smlqyLimitsOrderList", orderDashboardService.selectSmlqyLimitsOrderRceptList());

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 금일 주문 목록 조회
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/todayOrderList")
	@ResponseBody
	public Map<String, Object> selectTodayOrderList() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("todayOrderList", orderDashboardService.selectTodayOrderList());

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 다이버 상태값 조회
	 * </pre>
	 * @date 2024. 3. 15.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 3. 15.			hamyoonsic				최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/diverInfo")
	@ResponseBody
	public Map<String, Object> selectDiverInfo() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			map.put("diverInfo", orderDashboardService.selectDiverInfo());
		} catch (Exception e) {
			log.error("selectDiverInfo errorMsg : " + e.getMessage());
		}
		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 가단가 구매 평가 목록 조회
	 * </pre>
	 * @date 2024. 10. 29.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 29.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	@PostMapping("/prvsnlPurchsEvlList")
	@ResponseBody
	public Map<String, Object> selectPrvsnlPurchsEvlList() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("prvsnlPurchsEvlList", orderDashboardService.selectPrvsnlPurchsEvlList());

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 변동금 입금 대상 목록 조회
	 * </pre>
	 * @date 2024. 10. 29.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 29.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	@PostMapping("/changeAmountRcpmnyTrgetList")
	@ResponseBody
	public Map<String, Object> selectChangeAmountRcpmnyTrgetList() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("changeAmountRcpmnyTrgetList", orderDashboardService.selectChangeAmountRcpmnyTrgetList());

		return map;
	}
}
