package com.sorincorp.bo.ma.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.bo.chart.service.PcChartMntrngService;
import com.sorincorp.bo.ma.model.DashboardRltmOrderDetailVO;
import com.sorincorp.bo.ma.model.DashboardRltmOrderInfoVO;
import com.sorincorp.bo.ma.service.DashboardService;
import com.sorincorp.bo.st.model.AcmsltAnalsVO;
import com.sorincorp.bo.st.service.AcmsltAnalsService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * DashboardController.java
 * BO 대쉬보드 Contoller
 * 
 * @version
 * @since 2021. 11. 08.
 * @author srec0052
 */
@Slf4j
@Controller
@RequestMapping("/bo/dashboard")
public class AcmsltDashboardController {
	
	@Autowired
	DashboardService dashboardService;
	
	@Autowired
	PcChartMntrngService pcMntrngService;
	
    @Autowired
    private AcmsltAnalsService acmsltAnalsService;
	
	@Value("${spring.profiles}")
	private String profiles;
	
	@Value("${spring.bo.domain}")
	private String domain;
	
	/**
	 * <pre>
	 * 처리내용: BO 실적 대쉬보드
	 * </pre>
	 * @date 2023. 11. 22.
	 * @author srec0077
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 22.			srec0077			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
    @RequestMapping("/viewAcmsltDashboard")
	public String viewAcmsltDashboard(Model model) {
		try {
		    Map<String, String> mainGubunCodeMap = acmsltAnalsService.getMetalCode();
            model.addAttribute("mainGubunCodeMap", mainGubunCodeMap);
            
            String nowDate = DateUtil.getNowDate();
            
            AcmsltAnalsVO acmsLtVO = new AcmsltAnalsVO();
            acmsLtVO.setSearchDateEnd(nowDate);
            
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat yymmdd = new SimpleDateFormat("yyyyMMdd");
            Date date = yymmdd.parse(nowDate);
            
            // 5일
            acmsLtVO.setFlagDtSearch("DAY");
            calendar.setTime(date);
            calendar.add(Calendar.DATE, -4);
            acmsLtVO.setSearchDateFrom(yymmdd.format(calendar.getTime()));
            model.addAttribute("acmsltStatsDayList", acmsltAnalsService.sorinAcmsltStatsList(acmsLtVO));
            
            // 5주 (일 ~ 토)
            acmsLtVO.setFlagDtSearch("WEEK");
            calendar.setTime(date);
            calendar.add(Calendar.WEEK_OF_YEAR, -4);
            calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
            //calendar.add(Calendar.DATE, -4 * 7);
            acmsLtVO.setSearchDateFrom(yymmdd.format(calendar.getTime()));
            model.addAttribute("acmsltStatsWeekList", acmsltAnalsService.sorinAcmsltStatsList(acmsLtVO));
            
            // 5개월 (1일 ~ 말일)
            acmsLtVO.setFlagDtSearch("MONTH");
            calendar.setTime(date);
            calendar.add(Calendar.MONTH, -4);
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            acmsLtVO.setSearchDateFrom(yymmdd.format(calendar.getTime()));
            model.addAttribute("acmsltStatsMonthList", acmsltAnalsService.sorinAcmsltStatsList(acmsLtVO));
            
            acmsLtVO.setFlagDtSearch("BFRT");   //전일 
            model.addAttribute("sleEntrpsNdQyList", acmsltAnalsService.selectSleEntrpsNdQy(acmsLtVO));
            model.addAttribute("selngQyList", acmsltAnalsService.selectSelngQy(acmsLtVO));
            
			return "ma/acmsltDashboard";
		} catch (Exception e) {
			log.error("[DashboardController][dashboard]" + ExceptionUtils.getStackTrace(e));
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	
}
