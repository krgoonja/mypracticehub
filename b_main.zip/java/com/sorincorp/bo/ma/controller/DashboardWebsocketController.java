package com.sorincorp.bo.ma.controller;

import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.bo.comm.util.CommResponseEntity;
import com.sorincorp.bo.ma.service.DashboardWebsocketService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.exception.CommCustomException;

import lombok.extern.slf4j.Slf4j;

/**
 * DashboardWebsocketController.java
 * 주문/지정가 주문 BO websocket publish Controller 클래스
 * @version
 * @since 2023. 5. 4.
 * @author srec0066
 */
@Slf4j
@RestController
@RequestMapping("/bo/ma")
public class DashboardWebsocketController {

	@Autowired
	private DashboardWebsocketService dashboardWebsocketService;
	
	/** 외부 연계 api 호출 모듈 **/
    @Autowired
    private HttpClientHelper httpClientHelper;
    
    /**
	 * [BO -> FO] 연결 테스트 URL
	 */
	@Value("${order.api.foTest.url}")
	private String FO_TEST_URL;
	

	/**
	 * <pre>
	 * 처리내용: 일반 주문 websocket publish
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	@GetMapping("/dashboard/order/{orderNo}")
	public ResponseEntity<?> callDashboardOrder(@PathVariable(value = "orderNo") String orderNo){
		log.info("[BO][DashboardWebsocketController] IN >> ORDER_NO  : " + orderNo);

		// 라이브 주문정보 websocket publish
		dashboardWebsocketService.publishLiveOrder(orderNo);

		return ResponseEntity.status(HttpStatus.OK).build();
	}

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 websocket publish
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param limitOrderNo
	 * @return
	 */
	@GetMapping("/dashboard/limitOrder/{limitOrderNo}")
	public ResponseEntity<?> callDashboardLimitOrder(@PathVariable(value = "limitOrderNo") String limitOrderNo){
		log.info("[BO][DashboardWebsocketController] IN >> LIMIT_ORDER_NO  : " + limitOrderNo);

		// 지정가 주문정보 websocket publish
		dashboardWebsocketService.publishLimitOrder(limitOrderNo);

		return ResponseEntity.status(HttpStatus.OK).build();
	}

	/**
	 * <pre>
	 * 처리내용: 다이버 작동 websocket publish
	 * </pre>
	 * @date 2024. 2. 8.
	 * @author 
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * ------------------------------------------------
	 * @param runningAt
	 * @return
	 */
	@GetMapping("/dashboard/diverRunning/{runningAt}")
	public ResponseEntity<?> callDashboardDiverRunning(@PathVariable(value = "runningAt") String runningAt){
		log.info("[BO][DashboardWebsocketController] IN >> DIVER RUNNING  : " + runningAt);

		// 다이버 작동 websocket publish
		dashboardWebsocketService.publishDiverRunning(runningAt);

		return ResponseEntity.status(HttpStatus.OK).build();
	}

	/**
	 * <pre>
	 * 처리내용: 가격 변동금 입금관련 websocket publish
	 * </pre>
	 * @date 2024. 10. 30.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 30.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	@GetMapping("/dashboard/rcpmny/{orderNo}")
	public ResponseEntity<?> callDashboardRcpmny(@PathVariable(value = "orderNo") String orderNo){
		log.info("[BO][DashboardWebsocketController] IN >> ORDER_NO  : " + orderNo);

		// 입금된 주문정보 websocket publish
		dashboardWebsocketService.publishRcpmnyEvent(orderNo);

		return ResponseEntity.status(HttpStatus.OK).build();
	}

	/**
	 * <pre>
	 * 처리내용: BO로 오는 연결 테스트
	 * </pre>
	 * @date 2023. 7. 4.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 7. 4.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param testNo
	 * @return
	 */
	@GetMapping("/callTest/{testNo}")
	public ResponseEntity<?> callTest(@PathVariable(value = "testNo") String testNo) {
		log.info(">> [callTest] testNo : " + testNo);
		
		return ResponseEntity.status(HttpStatus.OK).body(new CommResponseEntity(200, testNo));
	}
	
	/**
	 * <pre>
	 * 처리내용: BO에서 FO로 연결 테스트
	 * </pre>
	 * @date 2023. 7. 4.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 7. 4.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param testNo
	 * @return
	 */
	@GetMapping("/foCallTest/{testNo}")
	public ResponseEntity<?> foCallTest(@PathVariable(value = "testNo") String testNo) {
		log.info(">> [foCallTest] testNo : " + testNo);
		
		String message = "success";
    	HttpStatus httpStatus = HttpStatus.OK;
    	
    	try {
    		// BO 연결 요청
	    	Map<String, Object> resMap = httpClientHelper.getCallApi(FO_TEST_URL + "/" + testNo);
	    	log.info("[foCallTest] >> resMap : " + resMap);
	    	if(resMap == null) {
				throw new CommCustomException("FO 연결 요청 API 호출 실패");
			}
    	} catch(Exception e) {
			log.error("[foCallTest] e : " + e.getMessage());
			message = ExceptionUtils.getStackTrace(e);
			httpStatus = HttpStatus.BAD_GATEWAY;
			log.error("[foCallTest] stacktrace : " + message);
    	}
		
		return ResponseEntity.status(HttpStatus.OK).body(new CommResponseEntity(200, "[" + httpStatus.toString() + "]" + message));
	}
}
