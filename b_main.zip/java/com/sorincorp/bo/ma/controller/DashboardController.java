package com.sorincorp.bo.ma.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.bo.chart.service.PcChartMntrngService;
import com.sorincorp.bo.ma.model.DashboardRltmOrderDetailVO;
import com.sorincorp.bo.ma.model.DashboardRltmOrderInfoVO;
import com.sorincorp.bo.ma.service.DashboardService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * DashboardController.java
 * BO 대쉬보드 Contoller
 * 
 * @version
 * @since 2021. 11. 08.
 * @author srec0052
 */
@Slf4j
@Controller
@RequestMapping("/bo/dashboard")
public class DashboardController {
	
	@Autowired
	DashboardService dashboardService;
	
	@Autowired
	PcChartMntrngService pcMntrngService;
	
	@Value("${spring.profiles}")
	private String profiles;
	
	@Value("${spring.bo.domain}")
	private String domain;
	
	/**
	 * <pre>
	 * 처리내용: BO 대쉬보드 화면 진입
	 * </pre>
	 * @date 2021. 11. 12.
	 * @author srec0052
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 12.			srec0052			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/viewDashboard")
	public String dashboard(Model model) {
		try {
			Map<String, Object> mainChart = new HashMap<String,Object>();
			
			mainChart = pcMntrngService.getMainChartData();
			model.addAttribute("chartList", mainChart);
			
			//JS파일에서 사용 하기위한 JSON데이터로 변환
			ObjectMapper objectMapper = new ObjectMapper();
			String jsonMainChart = objectMapper.writeValueAsString(mainChart);
			
			model.addAttribute("jsonChartList", jsonMainChart);
			
			return "ma/dashboard";
		} catch (Exception e) {
			log.error("[DashboardController][dashboard]" + ExceptionUtils.getStackTrace(e));
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 17.
	 * @author srec0052
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 17.			srec0052			최초작성
	 * ------------------------------------------------
	 * @param dashboardRltmOrderInfoVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/orderCntInfo")
	@ResponseBody
	public Map<String, Object> selectOrderCntInfo() throws Exception {
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		// 월, 일 주문 건수 조회
		map.put("orderCntInfo", dashboardService.selectOrderCntInfo());
		
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 오늘 발생한 주문 리스트 조회
	 * </pre>
	 * @date 2021. 11. 19.
	 * @author srec0052
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 19.			srec0052			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/todayOrderList")
	@ResponseBody
	public Map<String, Object> selectTodayOrderList() throws Exception {
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		// 오늘 발생한 주문 리스트 조회
		map.put("todayOrderList", dashboardService.selectTodayOrderList());
		
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 실시간 주문정보를 조회한다
	 * </pre>
	 * @date 2021. 11. 12.
	 * @author srec0052
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 12.			srec0052			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/rltmOrderInfo")
	@ResponseBody
	public Map<String, Object> selectRltmOrderInfo(@RequestBody DashboardRltmOrderInfoVO dashboardRltmOrderInfoVO) throws Exception {
		
		return dashboardService.selectRltmOrderInfo(dashboardRltmOrderInfoVO);
	}
	
	/**
	 * <pre>
	 * 처리내용: 주문 상세정보 조회
	 * </pre>
	 * @date 2021. 11. 12.
	 * @author srec0052
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 12.			srec0052			최초작성
	 * ------------------------------------------------
	 * @param dashboardRltmOrderInfoVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/rltmOrderDetail")
	@ResponseBody
	public Map<String, Object> selectRltmOrderDetail(@RequestBody DashboardRltmOrderDetailVO dashboardRltmOrderDetailVO) throws Exception {
		
		return dashboardService.selectRltmOrderDetail(dashboardRltmOrderDetailVO);
	}
	
	/**
	 * <pre>
	 * 처리내용: 금일 주문현황을 조회한다
	 * </pre>
	 * @date 2021. 11. 12.
	 * @author srec0052
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 12.			srec0052			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/orderSttus")
	@ResponseBody
	public Map<String, Object> selectOrderSttus() throws Exception {
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		//금일 주문 수
		map.put("orderCnt", dashboardService.selectOrderCnt());
		//금일 주문 현황 통계 리스트
		map.put("orderSttusList", dashboardService.selectOrderSttusList());
	
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 금일 재고현황을 조회한다
	 * </pre>
	 * @date 2021. 11. 12.
	 * @author srec0052
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 12.			srec0052			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/invntrySttus")
	@ResponseBody
	public Map<String, Object> selectInvntrySttus() throws Exception {
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		//금일 재고 수
		map.put("invntryCnt", dashboardService.selectInvntryCnt());
		//금일 재고 현황 통계 리스트
		map.put("invntrySttusList", dashboardService.selectInvntrySttusList());
	
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 매출현황을 조회한다
	 * </pre>
	 * @date 2021. 11. 12.
	 * @author srec0052
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 12.			srec0052			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selng")
	@ResponseBody
	public Map<String, Object> selectSelng() throws Exception {
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		//금일 리스트
		map.put("selngList", dashboardService.selectSelngList());
	
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 배송현황을 조회한다
	 * </pre>
	 * @date 2021. 11. 12.
	 * @author srec0052
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 12.			srec0052			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/dlvy")
	@ResponseBody
	public Map<String, Object> selectDlvy() throws Exception {
		
		Map<String, Object> map = new HashMap<String, Object>();
		
		//금일 리스트
		map.put("dlvyList", dashboardService.selectDlvyList());
	
		return map;
	}
	
	@PostMapping("/ewllt")
	@ResponseBody
	public Map<String,Object> selectEwllt() throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		
		map.put("ewlltList",dashboardService.selectEwlltList());
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 대쉬보드 도메인 설정
	 * </pre>
	 * @date 2021. 11. 24.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@ResponseBody
	@PostMapping("/domain")
	public Map<String, Object> boDomain() {
	   Map<String, Object> map = new HashMap<>();
	   
	   String url = "";
       
	   if("local".equals(profiles)) {
    	   //url = "http://"+domain+":28083";
       }
       else if("dev".equals(profiles)) {
    	   //url = "http://"+domain+":28083";
       }
       else if("prd".equals(profiles)) {
    	   //url = domain;
       }
       
       System.out.println(url);
       map.put("dashBoardUrl", url);

		return map;
	}
	
	/**
	 * <pre>
	 * 조달청 가격 가져오기
	 * </pre>
	 * @date 2022. 05. 26.
	 * @author jdrttl
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 05. 26.		jdrttl				최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@RequestMapping("/getSarokPcList")
	@ResponseBody
	public List<Map<String, Object>> getSarokPcList() throws Exception {
		return dashboardService.getSarokPcList(DateUtil.getNowDate());
	}

}
