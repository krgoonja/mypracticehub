package com.sorincorp.bo.bd.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.sorincorp.comm.common.service.CommonService;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.bd.mapper.BdSvcStplatMapper;
import com.sorincorp.bo.bd.model.BdMberManageVO;
import com.sorincorp.bo.bd.model.BdSvcStplatVO;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * BdSvcStplatServiceImpl.java
 * @version
 * @since 2023. 08. 01.
 * @author sein
 */
@Slf4j
@Service
public class BdSvcStplatServiceImpl implements BdSvcStplatService {

	@Autowired
	private BdSvcStplatMapper bdStplatMapper;

	@Autowired
	private MailMapper mailMapper;

	@Autowired
	private MailService mailService;

	@Autowired
	private SMSService smsService;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private CommonService commonService;

	/**
	 * 서비스 약관을 조회한다.
	 */
	@Override
	public BdSvcStplatVO selectBdSvcStplat(BdSvcStplatVO bdStplat) throws Exception {
		return bdStplatMapper.selectBdSvcStplat(bdStplat);
	}

	/**
	 * 게시중인 서비스 약관을 조회한다.
	 */
	@Override
	public BdSvcStplatVO selectBdSvcstplatIng(BdSvcStplatVO bdStplat) throws Exception {
		return bdStplatMapper.selectBdSvcstplatIng(bdStplat);
	}
	/**
	 * 서비스 약관 목록을 조회한다.
	 */
	@Override
	public List<BdSvcStplatVO> selectBdSvcStplatList(BdSvcStplatVO bdStplat) throws Exception {
		return bdStplatMapper.selectBdSvcStplatList(bdStplat);
	}

	/**
	 * 서비스 약관 총 갯수를 조회한다.
	 */
	@Override
	public int selectBdSvcStplatListTotcnt(BdSvcStplatVO bdStplat) throws Exception {
		return bdStplatMapper.selectBdSvcStplatListTotcnt(bdStplat);
	}

	/**
	 * 그리드의 서비스약관 정보를 저장, 업데이트 한다.
	 */
	public void insertAndUpdateBdSvcstplatDataList(BdSvcStplatVO bdStplat) throws Exception {

		log.debug("insertAndUpdateBdSvcstplatDataList 서비스임플: " + bdStplat);
		String status = bdStplat.getGridRowStatus();
		int stplatNo = bdStplat.getStplatNo();
		if(status.equals("created") && (stplatNo == 0)) {
			insertBdSvcStplat(bdStplat);
		} else if(status.equals("updated")) {
			updateBdSvcStplat(bdStplat);
		}
	}

	/**
	 * 서비스 약관을 등록한다.
	 */
	@Override
	public void insertBdSvcStplat(BdSvcStplatVO bdStplat) throws Exception {
		Account account= userInfoUtil.getAccountInfo();
		String userId = "";
		if(account != null) {
			userId = account.getId();
		}

		bdStplat.setFrstRegisterId(userId);
		bdStplat.setLastChangerId(userId);
		bdStplatMapper.insertBdSvcStplat(bdStplat);
		int key = bdStplat.getStplatNo();
		log.debug("inserted key ===> " + key);
		bdStplat.setStplatNo(key);
		//bdStplatMapper.insertBdSvcStplatHistory(bdStplat);
		commonService.insertTableHistory("OP_SVC_STPLAT_BAS", bdStplat);

//		//SMS/Push/메일 발송
		insertSMS(bdStplat);
		insertMail(bdStplat);
	}

	/**
	 * 서비스 약관을 수정한다.
	 */
	@Override
	public void updateBdSvcStplat(BdSvcStplatVO bdStplat) throws Exception {
		Account account= userInfoUtil.getAccountInfo();
		String userId = "";
		if(account != null) {
			userId = account.getId();
		}
		bdStplat.setLastChangerId(userId);
		bdStplatMapper.updateBdSvcStplat(bdStplat);
		//bdStplatMapper.insertBdSvcStplatHistory(bdStplat);
		commonService.insertTableHistory("OP_SVC_STPLAT_BAS", bdStplat);

//		//SMS/Push/메일 발송
		insertSMS(bdStplat);
		insertMail(bdStplat);
	}

	/**
	 * <pre>
	 * 처리내용: LMS를 발송한다.
	 * </pre>
	 * @date 2021. 12. 6.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 05. 25.			sumin95			    마케팅정보수신동의 추가
	 * ------------------------------------------------
	 * @param bdStplat
	 * @throws Exception
	 */
	private void insertSMS(BdSvcStplatVO bdStplat) throws Exception {

		Map<String, String> dataMap = getTargetDataMap(bdStplat, null);	// 발송 데이터
		int msgTmplat = Integer.parseInt(dataMap.get("templateNum"));	// 메세지템플릿 번호
		String stplatSeCode = bdStplat.getStplatSeCode(); 				// 약관 구분 코드

		List<BdMberManageVO> bdMberList = new ArrayList<>();

		if (stplatSeCode.equals("10")) {
			bdMberList = bdStplatMapper.selectBdMberMarketingRecieverList(); 	//마케팅 동의 회원 발송 목록
		} else {
			bdMberList = bdStplatMapper.selectBdMberRecieverList(); 			//발송대상회원 목록
		}

		if(msgTmplat > 0) { //템플릿 없으면 예외처리
			for (BdMberManageVO mb : bdMberList) {
				SMSVO sms = new SMSVO();
				sms.setPhone(mb.getVrscMoblphonNo());
				String phone = sms.getPhone();

				if(StringUtils.isNotEmpty(phone) && !phone.equals("null")) {
					try {
						phone = CryptoUtil.decryptAES256(phone);	//전화번호 복호화
						sms.setPhone(phone);
					} catch(Exception e) {
						log.error("BdSvcStplatServiceImpl procSms VRSC_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
					}
				}
				//SMS 발송
				//smsService.insertSMS(sms, dataMap);
			}
		}
	}


	/**
	 * <pre>
	 * 처리내용: 이메일을 발송한다.
	 * </pre>
	 * @date 2021. 12. 2.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 2.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param bdStplat
	 * @throws Exception
	 */
	private void insertMail(BdSvcStplatVO bdStplat) throws Exception {

		Map<String, String> dataMap = getTargetDataMap(bdStplat, "email");   // 발송 데이터
		int mailTmplat = Integer.parseInt(dataMap.get("templateNum"));	   // 메일템플릿 번호
		String stplatSeCode = bdStplat.getStplatSeCode(); 				   // 약관 구분 코드

		List<BdMberManageVO> bdMberList = new ArrayList<>();
		List<MailVO> mailList = new ArrayList<>();

		if(stplatSeCode.equals("10")) {
			bdMberList = bdStplatMapper.selectBdMberMarketingRecieverList(); 	//마케팅 동의 회원 발송 목록
		}else {
			bdMberList = bdStplatMapper.selectBdMberRecieverList(); 			//발송대상회원 목록
		}

		if(mailTmplat > 0) { //템플릿 없으면 예외처리
			MailVO selectMailTmpt = mailMapper.selectMailTmpt(mailTmplat);
			String userEmail = selectMailTmpt.getSntoEmail();					//발신자 이메일 (webmaster@kztraders.com)
			String[] splitEmail = userEmail.split("@");
			String userId = splitEmail[0];										//발신자 아이디 (webmaster)

			for (BdMberManageVO mb : bdMberList) {
				MailVO mail = new MailVO();
				mail.setEmail(mb.getVrscBidMberEmail());
				mail.setName(mb.getVrscEntrpsNm());
				mail.setPhoneNum(CryptoUtil.decryptAES256(mb.getVrscMoblphonNo()));
				mail.setMailTmptSeq(mailTmplat);
				mail.setMailSendUserId(userId);
				mail.setMailSendEmail(userEmail);
				mailList.add(mail);
			}
			
			//메일 발송
			//mailService.insertMailListSend(mailList, dataMap);
		}
	}

	/**
	 * SMS/앱푸시/이메일 발송을 위한 데이터를 map형식으로 리턴받는다.
	 */
	private Map<String,String> getTargetDataMap(BdSvcStplatVO bdStplat, String gubun) throws Exception {
		int tmplatNo = 0;
		Map<String,String> resultMap = new HashedMap<>();   // 리턴할 데이터 맵
		String stplatSeCode = bdStplat.getStplatSeCode(); 	// 약관 구분 코드

		if(StringUtils.isNotEmpty(stplatSeCode)) {
			tmplatNo = 10;									// 템플릿 번호 : SMS&이메일 모두 [10]번 사용으로 통합

			// 공통코드: 약관 구분 코드 명 조회
			Map<String,String> stplatSeCodeList = commonCodeService.getSubCodes("STPLAT_SE_CODE");
			stplatSeCodeList.forEach((key, value) -> {
				if(stplatSeCode.equals(key)) {
					resultMap.put("stplatSeNm", value);					// 약관 제목
					return;
				}
			});

			//공지 일자, 개정 일자
			String noticeDt = bdStplat.getStplatreformNoticeDe();
			String revisionDt = bdStplat.getStplatreformBeginDe();
			String noticeDate = noticeDt.substring(0,4) + "-" + noticeDt.substring(4, 6) + "-" + noticeDt.substring(6);
			String revisionDate = revisionDt.substring(0,4) + "-" + revisionDt.substring(4, 6) + "-" + revisionDt.substring(6);

			resultMap.put("templateNum", String.valueOf(tmplatNo));  	// 템플릿 번호
			resultMap.put("noticeDate", noticeDate); 					// 사전 공지일
			resultMap.put("revisionDate", revisionDate); 				// 개정 시행일

			//이메일 발송일 경우 데이터 추가
			if("email".equals(gubun)) {
				String preStplatCn = "";
				BdSvcStplatVO bdSvcStplatVO = bdStplatMapper.selectBdSvcstplatIng(bdStplat); // 게시중 약관 조회

				if(bdSvcStplatVO != null) {
					preStplatCn = bdSvcStplatVO.getStplatCnOne(); // 개정전 내용 -> 게시중 약관내용
				}
				String nextStplatCn = bdStplat.getStplatCnOne();  // 개정후 내용 -> 새로 저장할 내용

				resultMap.put("preStplatCn", preStplatCn.replaceAll("\n", "<br>").replaceAll("\r\n", "<br>")); 	   // 개정전 약관내용
				resultMap.put("nextStplatCn", nextStplatCn.replaceAll("\n", "<br>").replaceAll("\r\n", "<br>"));   // 개정후 약관내용
			}

		}
		log.debug("getTargetDataMap resultMap >>> " + resultMap.toString());
		return resultMap;
	}
}
