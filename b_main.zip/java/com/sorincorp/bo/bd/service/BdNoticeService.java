package com.sorincorp.bo.bd.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.bo.bd.model.BdNoticeVO;
import com.sorincorp.comm.filedoc.model.FileDocVO;

public interface BdNoticeService {
	

	/**
	 * <pre>
	 * 처리내용: 공지사항 목록을 조회한다
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * @param searchVO
	 * @return
	 * @throws Exception
	 */
	List<BdNoticeVO> selectNoticeList(BdNoticeVO searchVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용:  공지사항 총 갯수를 조회한다.
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @return
	 * @throws Exception
	 */
	int selectNoticeListTotcnt(BdNoticeVO searchVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 공지사항을 등록한다.
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param noticeVO
	 * @throws Exception
	 */
	void insertNotice(BdNoticeVO noticeVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 공지사항을 수정한다.
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param noticeVO
	 * @throws Exception
	 */
	void updateNotice(BdNoticeVO noticeVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 공지사항을 삭제한다.
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param noticeVO
	 * @throws Exception
	 */
	void deleteNotice(BdNoticeVO noticeVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용:  Grid 정보를 삽입, 수정한다.
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param noticeList
	 * @throws Exception
	 */
	void insertAndUpdateGridDataList(List<BdNoticeVO> noticeList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: Grid 정보를 삭제한다.
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param noticeList
	 */
	void deleteGridDataList(List<BdNoticeVO> noticeList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 공지사항의 첨부파일 목록을 조회한다.
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param notice
	 * @return
	 * @throws Exception
	 */
	List<FileDocVO> selectListNoticeAtchmnfl(BdNoticeVO notice) throws Exception;
	/**
	 * <pre>
	 * 처리내용: 공지사항의 첨부파일 목록을 조회한다.
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param notice
	 * @return
	 * @throws Exception
	 */
	Map<String, FileDocVO> selectMainPopupImageAtchmnfl(BdNoticeVO notice) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 첨부파일을 등록한다.
	 * </pre>
     * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param mrequest
	 * @return
	 */
	Map<String, Object> uploadFileDoc(MultipartHttpServletRequest mrequest) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 첨부파일을 삭제한다.
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param fileVO
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> deleteFileDoc(FileDocVO fileVO) throws Exception;

	Map<String, Object> uploadNoticeImageFileDoc(MultipartHttpServletRequest mrequest) throws Exception;
}
