package com.sorincorp.bo.bd.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sorincorp.comm.common.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import com.sorincorp.bo.bd.mapper.BdNoticeMapper;
import com.sorincorp.bo.bd.model.BdNoticeVO;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service 
public class BdNoticeServiceImpl implements BdNoticeService {
	
	@Autowired
	private BdNoticeMapper bdNoticeMapper;

	@Autowired
	private FileDocService fileDocService;

	@Autowired
	private CommonService commonService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	/**
	 * 공지사항을 등록한다.
	 */
	@Override
	public void insertNotice(BdNoticeVO noticeVO) throws Exception {
		//공지사항 등록
		bdNoticeMapper.insertNotice(noticeVO);
		int key =  noticeVO.getNoticeNo();
		log.debug("inserted key ===> " + key);
		noticeVO.setNoticeNo(key);
		//bdNoticeMapper.insertNoticeHistory(noticeVO);
		commonService.insertTableHistory("BD_NOTICE_BAS", noticeVO);

		//공지사항 첨부파일 등록
		int docNos[] = noticeVO.getDocNos();
		for (int i = 0; i < docNos.length; i++) {
			if(docNos[i] == 0) {
				continue;
			}

			noticeVO.setDocNo(docNos[i]);
			int result  = bdNoticeMapper.insertNoticeAtchmnfl(noticeVO);
			if(result == 1) {
				//bdNoticeMapper.insertNoticeAtchmnflHistory(noticeVO);
				commonService.insertTableHistory("BD_NOTICE_ATCHMNFL_BAS", noticeVO);
			}
		}
	}

	/**
	 * 공지사항을 수정한다.
	 */
	@Override
	public void updateNotice(BdNoticeVO noticeVO) throws Exception {
		log.debug("update notice ===> " + noticeVO);

		// 공지사항 수정
		bdNoticeMapper.updateNotice(noticeVO);
		//bdNoticeMapper.insertNoticeHistory(noticeVO);
		commonService.insertTableHistory("BD_NOTICE_BAS", noticeVO);

		//공지사항 첨부파일 수정(추가)
		int docNos[] = noticeVO.getDocNos(); // 등록된 문서 번호
		int delNo[] = noticeVO.getDelNo(); // 삭제된 문서 번호
		for (int i = 0; i < docNos.length; i++) {
			if(docNos[i] == 0) {
				continue;
			}

			noticeVO.setDocNo(docNos[i]);
			int result  = bdNoticeMapper.insertNoticeAtchmnfl(noticeVO);
			if(result == 1) {
				//bdNoticeMapper.insertNoticeAtchmnflHistory(noticeVO);
				commonService.insertTableHistory("BD_NOTICE_ATCHMNFL_BAS", noticeVO);
			}
		}

		//공지사항 첨부파일 수정(삭제)
		for (int i = 0; i < delNo.length; i++) {
			FileDocVO delFile = fileDocService.selectDocInfo(delNo[i]);
			if(delFile != null) {
				deleteFileDoc(delFile);
			}

			noticeVO.setDocNo(delNo[i]);
			bdNoticeMapper.deleteNoticeAtchmnfl(noticeVO);
			//bdNoticeMapper.insertNoticeAtchmnflHistory(noticeVO);
			commonService.insertTableHistory("BD_NOTICE_ATCHMNFL_BAS", noticeVO);
		}
	}

	/**
	 * 공지사항을 삭제한다.
	 */
	@Override
	public void deleteNotice(BdNoticeVO noticeVO) throws Exception {
		log.debug("deleteNotice notice ===> " + noticeVO);
		bdNoticeMapper.deleteNotice(noticeVO);
		//bdNoticeMapper.insertNoticeHistory(noticeVO);
		commonService.insertTableHistory("BD_NOTICE_BAS", noticeVO);

		List<BdNoticeVO> fileList = bdNoticeMapper.selectListNoticeAtchmnfl(noticeVO);
		log.debug("deleteNotice fileList ===> " + fileList);
		//공통문서 삭제
		if(fileList.size() != 0) {
			for (int i = 0; i < fileList.size(); i++) {
				FileDocVO delFile = fileDocService.selectDocInfo(fileList.get(i).getDocNo());
				if(delFile != null) {
					deleteFileDoc(delFile);

					//공지사항 첨부파일 bas 삭제
					noticeVO.setDocNo(delFile.getDocNo());
					bdNoticeMapper.deleteNoticeAtchmnfl(noticeVO);
					//bdNoticeMapper.insertNoticeAtchmnflHistory(noticeVO);
					commonService.insertTableHistory("BD_NOTICE_ATCHMNFL_BAS", noticeVO);
				}
			}
		}
	}

	/**
	 * 공지사항 목록을 조회한다.
	 */
	@Override
	public List<BdNoticeVO> selectNoticeList(BdNoticeVO searchVO) throws Exception {
		return bdNoticeMapper.selectNoticeList(searchVO);
	}

	/**
	 * 공지사항 총 갯수를 조회한다.
	 */
	@Override
	public int selectNoticeListTotcnt(BdNoticeVO searchVO) throws Exception {
		return bdNoticeMapper.selectNoticeListTotcnt(searchVO);
	}

	/**
	 * Grid 정보를 삽입, 수정한다.
	 */
	@Override
	public void insertAndUpdateGridDataList(List<BdNoticeVO> noticeList) throws Exception {

		Account account = userInfoUtil.getAccountInfo();
		String userId ="";
		if(account != null) {
			userId = account.getId();
		}

		for(int i = 0; i < noticeList.size(); i++) {
			String status = noticeList.get(i).getGridRowStatus();
			BdNoticeVO data = noticeList.get(i);
			data.setFrstRegisterId(userId);
			data.setLastChangerId(userId);

			if(status.equals("created")) {
				log.debug("insertGridDataList insert: " + data);
				insertNotice(data);
			} else if (status.equals("updated")) {
				log.debug("updateGridDataList insert: " + data);
				updateNotice(data);
			}
		}
	}

	/**
	 * Grid 정보를 삭제한다.
	 */
	@Override
	public void deleteGridDataList(List<BdNoticeVO> noticeList) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		String userId ="";
		if(account != null) {
			userId = account.getId();
		}

		for(int i = 0; i < noticeList.size(); i++) {
			noticeList.get(i).setFrstRegisterId(userId);
			noticeList.get(i).setLastChangerId(userId);
			deleteNotice(noticeList.get(i));
		}
	}

	/**
	 *	공지사항의 첨부파일 목록을 조회한다.
	 */
	@Override
	public List<FileDocVO> selectListNoticeAtchmnfl(BdNoticeVO notice) throws Exception {
		List<FileDocVO> filelist = new ArrayList<>();
		List<BdNoticeVO> list = bdNoticeMapper.selectListNoticeAtchmnfl(notice);

		if(notice.getModalPageStatus().equals("insert")) {
			return filelist;
		} else if(notice.getModalPageStatus().equals("update")) {
			for (int i = 0; i < list.size(); i++) {
				FileDocVO file = new FileDocVO();
				file = fileDocService.selectDocInfo(list.get(i).getDocNo());
				filelist.add(file);
			}
		}
		log.debug("Notice fileList ===> " + filelist);
		return filelist;
	}

	/**
	 *	공지사항의 메인팝업 이미지파일 목록을 조회한다.
	 */
	@Override
	public Map<String, FileDocVO> selectMainPopupImageAtchmnfl(BdNoticeVO notice) throws Exception {
		Map<String, FileDocVO> filelist = new HashMap<>();

		if(notice.getModalPageStatus().equals("insert")) {
			return filelist;
		} else if(notice.getModalPageStatus().equals("update")) {
			FileDocVO foImageFile;
			if(notice.getFoImageDocNo() != null) {
				foImageFile = fileDocService.selectDocInfo(notice.getFoImageDocNo());
				filelist.put("foImageFile", foImageFile);
			}
			FileDocVO moImageFile;
			if(notice.getMoImageDocNo() != null) {
				moImageFile = fileDocService.selectDocInfo(notice.getMoImageDocNo());
				filelist.put("moImageFile", moImageFile);
			}
		}
		return filelist;
	}

	/**
	 *	첨부파일을 등록한다.
	 */
	@Override
	public Map<String, Object> uploadFileDoc(MultipartHttpServletRequest mrequest) throws Exception {
		Map<String,Object> map = new HashMap<String,Object>();
		List<FileDocVO> fileList = fileDocService.uploadAttachFilesVoList("OP", mrequest);
		map.put("list", fileList);

		return map;
	}

	/**
	 *	첨부파일을 삭제한다.
	 */
	@Override
	public Map<String, Object> deleteFileDoc(FileDocVO fileVO) throws Exception {
		Map<String,Object> map = new HashMap<String,Object>();

		fileDocService.deleteCommonDoc(fileVO.getDocNo());
		map.put("docNo", fileVO.getDocNo());
		map.put("result","success");

		return map;
	}

	@Override
	public Map<String, Object> uploadNoticeImageFileDoc(MultipartHttpServletRequest mrequest) throws Exception{
		Map<String,Object> map = new HashMap<String,Object>();
		List<FileDocVO> fileList = fileDocService.uploadPublicAttachFilesVoList("OP", mrequest);
		map.put("list", fileList);

		return map;
	}

	
}
