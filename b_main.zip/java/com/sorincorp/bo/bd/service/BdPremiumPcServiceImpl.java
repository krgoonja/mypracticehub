package com.sorincorp.bo.bd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.bd.mapper.BdPremiumPcMapper;
import com.sorincorp.bo.bd.model.BdPremiumPcVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BdPremiumPcServiceImpl implements BdPremiumPcService  {

    @Autowired
    private  BdPremiumPcMapper  bidPremiumPcMapper;

    @Override
    public List<BdPremiumPcVO> selectPremiumPcList(BdPremiumPcVO pcVO) throws Exception {
        return bidPremiumPcMapper.selectPremiumPcList(pcVO);
    }



}
