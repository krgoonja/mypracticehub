package com.sorincorp.bo.bd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.bd.mapper.BdLgistCnterMapper;
import com.sorincorp.bo.bd.model.BdLgistCnterVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service 
public class BdLgistCnterServiceImpl implements BdLgistCnterService {
	
	@Autowired
	BdLgistCnterMapper bdLgistCnterMapper;

	@Override
	public List<BdLgistCnterVO> selectLgistCnterList(BdLgistCnterVO lco) {
		// TODO Auto-generated method stub
		return bdLgistCnterMapper.selectLgistCnterList(lco);
	}

	@Override
	public int selectLgistCnterTotCnt(BdLgistCnterVO lco) {
		// TODO Auto-generated method stub
		return bdLgistCnterMapper.selectLgistCnterTotCnt(lco);
	}

	@Override
	public int insertAndUpdateGridDataList(List<BdLgistCnterVO> list, String userId) {
		// TODO Auto-generated method stub
		int result = 0; 
	
		for(BdLgistCnterVO lcList : list) {
			String status = lcList.getGridRowStatus();
			
			String addArr[] =lcList.getAddDelyArr();
			String deleteArr[]=lcList.getDeleteDelyArr();
			String haveArr[] = lcList.getHaveArr();
			
			if(status.equals("created")) {
				lcList.setFrstRegisterId(userId);
				lcList.setLastChangerId(userId);
				/**입찰_창고 기본 에 insert**/
				result = insertLgistData(lcList);
				/**입찰 창고에 insert가 성공했다면 현재의 BD_WRHOUS_BAS의 currentNum을 가져온다.*/
				int key =  getCurrentNum();
				
				/**인도조건 코드가 선택된 만큼 입찰_창고 인도 조건 상세테이블에 insert한다.**/
				for(String delyCode : addArr) {
					lcList.setDelyCndCode(delyCode);
					lcList.setWrhousNo(key);
					result = insertLgistDtlData(lcList);
				}
				
			}else if(status.equals("updated")) {
				lcList.setLastChangerId(userId);
				result = updateLgistData(lcList);
				/**인도조건 코드가 새로 추가된 경우 인도 조건 상세테이블에 insert한다..**/
				for(String delyCode : addArr) {
					lcList.setFrstRegisterId(userId);
					lcList.setDelyCndCode(delyCode);
					result = insertLgistDtlData(lcList);
				}
				/**인도조건 코드가 삭제된 경우 인도 조건 상세테이블에서 delete한다..**/
				for(String delyCode : deleteArr) {
					lcList.setDelyCndCode(delyCode);
					result = deleteLgistDtlData(lcList);
				}
			}else if(status.equals("delete")) {
				lcList.setLastChangerId(userId);
				result = deleteGridDataList(lcList);
				
				/**인도조건 코드가 삭제된 경우 인도 조건 상세테이블에서 delete한다..**/
				for(String delyCode : haveArr) {
					lcList.setDelyCndCode(delyCode);
					result = deleteLgistDtlData(lcList);
				}
			}
			
		}
		return result;
	}
	
	@Override
	public int insertLgistData(BdLgistCnterVO lcList) {
		int result =  bdLgistCnterMapper.insertLgistData(lcList);
		
		/**입찰 창고에 insert가 성공했다면 현재의 BD_WRHOUS_BAS의 currentNum을 가져온다.*/
		int key =  getCurrentNum();
		lcList.setWrhousNo(key);
		bdLgistCnterMapper.insertInsertLgistDataHis(lcList);
		return result;
	}
	
	@Override
	public int insertLgistDtlData(BdLgistCnterVO lcList) {
		int result = bdLgistCnterMapper.insertLgistDtlData(lcList);
		bdLgistCnterMapper.insertLgistDtlDataHis(lcList);
		return result;
	}
	
	@Override
	public List<BdLgistCnterVO> selectOriginalData(BdLgistCnterVO lco) {
		// TODO Auto-generated method stub
		return bdLgistCnterMapper.selectOriginalData(lco);
	}
	
	@Override
	public int updateLgistData(BdLgistCnterVO lcList) {
		int result= bdLgistCnterMapper.updateLgistData(lcList);
		bdLgistCnterMapper.insertInsertLgistDataHis(lcList);
		return result;
	}

	@Override
	public int selectOriginalTotCnt(BdLgistCnterVO lco) {
		// TODO Auto-generated method stub
		return bdLgistCnterMapper.selectOriginalTotCnt(lco);
	}

	@Override
	public int deleteLgistDtlData(BdLgistCnterVO lcList) {
		// TODO Auto-generated method stub
		int result = bdLgistCnterMapper.deleteLgistDtlData(lcList);
		bdLgistCnterMapper.insertLgistDtlDataHis(lcList);
		return result;
	} 
	

	@Override
	public int updateLgistDtlData(BdLgistCnterVO lcList) {
		int result = bdLgistCnterMapper.updateLgistDtlData(lcList);
		// TODO Auto-generated method stub
		bdLgistCnterMapper.insertLgistDtlDataHis(lcList);
		return result;
	}

	@Override
	public int deleteGridDataList(BdLgistCnterVO lco) {
		// TODO Auto-generated method stub
		int result = bdLgistCnterMapper.deleteGridDataList(lco);
		bdLgistCnterMapper.insertInsertLgistDataHis(lco);
		
		return result;
	}

	@Override
	public int getCurrentNum() {
		// TODO Auto-generated method stub
		int result =bdLgistCnterMapper.getCurrentNum();
		
		return result;
	} 
	
	
	

}
