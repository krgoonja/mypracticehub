package com.sorincorp.bo.bd.service;

import java.util.List;

import com.sorincorp.bo.bd.model.BdPremiumPcVO;

public interface BdPremiumPcService {

    /**
      * <pre>
     * 처리내용: 전환 프리미엄 가격 리스트를 가져온다.
     * </pre>
     * @date 2023. 7. 17.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 17.         srec0077            최초작성
     * ------------------------------------------------
     * @param BdPremiumPcVO pcVO
     * @return
     * @throws Exception
     */
	List<BdPremiumPcVO> selectPremiumPcList(BdPremiumPcVO pcVO) throws Exception;


}
