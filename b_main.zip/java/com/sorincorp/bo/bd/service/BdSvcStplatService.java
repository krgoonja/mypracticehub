package com.sorincorp.bo.bd.service;

import java.util.List;

import com.sorincorp.bo.bd.model.BdSvcStplatVO;

/**
 * BdSvcStplatService.java
 * @version
 * @since 2023. 08. 01.
 * @author sein
 */
public interface BdSvcStplatService {
	
	/**
	 * <pre>
	 * 처리내용: 서비스 약관을 조회한다.
	 * </pre>
	 * @date 2023. 08. 01.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 08. 01.			sein				최초작성
	 * ------------------------------------------------
	 * @param bdStplat - 조회할 정보가 담긴 BdSvcStplatVO
	 * @return
	 * @throws Exception
	 */
	BdSvcStplatVO selectBdSvcStplat(BdSvcStplatVO bdStplat) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 게시중인 서비스 약관을 조회한다.
	 * </pre>
	 * @date 2023. 08. 01.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 08. 01.			sein				최초작성
	 * ------------------------------------------------
	 * @param bdStplat
	 * @return
	 * @throws Exception
	 */
	BdSvcStplatVO selectBdSvcstplatIng(BdSvcStplatVO bdStplat) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 서비스 약관 목록을 조회한다. 
	 * </pre>
	 * @date 2023. 08. 01.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 08. 01.		sein					최초작성
	 * ------------------------------------------------
	 * @param searchVO - 조회할 정보가 담긴 BdSvcStplatVO
	 * @return 서비스 약관 목록
	 * @throws Exception
	 */
	List<BdSvcStplatVO> selectBdSvcStplatList(BdSvcStplatVO bdStplat) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 그리드의 서비스약관 정보를 저장, 업데이트 한다.
	 * </pre>
	 * @date 2021. 08. 01.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 08. 01.		sein					최초작성
	 * ------------------------------------------------
	 * @param stplat
	 * @throws Exception
	 */
	void insertAndUpdateBdSvcstplatDataList(BdSvcStplatVO bdStplat) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 서비스 약관을 등록한다.
	 * </pre>
	 * @date 2021. 08. 01.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 08. 01.		sein					최초작성
	 * ------------------------------------------------
	 * @param bdStplat - 등록할 정보가 담긴 BdSvcStplatVO
	 * @throws Exception
	 */
	void insertBdSvcStplat(BdSvcStplatVO bdStplat) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 서비스 약관을 수정한다.
	 * </pre>
	 * @date 2023. 08. 01.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 08. 01.		sein					최초작성
	 * ------------------------------------------------
	 * @param bdStplat - 수정할 정보가 담긴 BdSvcStplatVO
	 * @throws Exception
	 */
	void updateBdSvcStplat(BdSvcStplatVO bdStplat) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 서비스 약관 총 갯수를 조회한다.
	 * </pre>
	 * @date 2023. 08. 01.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 01.		sein					최초작성
	 * ------------------------------------------------
	 * @param searchVO - 조회할 정보가 담긴 SvcStplatVO
	 * @return 서비스 약관 총 갯수
	 * @throws Exception
	 */
	int selectBdSvcStplatListTotcnt(BdSvcStplatVO bdStplat) throws Exception;
	
}
