package com.sorincorp.bo.bd.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.bd.mapper.BdManageMapper;
import com.sorincorp.bo.bd.model.BdManageVO;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.filedoc.service.FileDocService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BdManageServiceImpl implements BdManageService  {

	@Autowired
	private  BdManageMapper  bdManageMapper;

    @Autowired
    private FileDocService fileDocService;

    @Autowired
    private UserInfoUtil userInfoUtil;

    @Autowired
    private CommonService commonService;

    @Autowired
    private BdManageService bdManageService;

    @Autowired
    private ItCmnCodeService itCmnCodeService;
    
    @Autowired
    private AssignService assignService;

	@Override
	public List<BdManageVO> selectBdList(BdManageVO bidVO) throws Exception {
		return bdManageMapper.selectBdList(bidVO);
	}

	@Override
	public int selectBdListTotcnt(BdManageVO bidVO) throws Exception {
		return bdManageMapper.selectBdListTotcnt(bidVO);
	}

	@Override
	public List<BdManageVO> selectSearchBidSttusList(BdManageVO bidVO) throws Exception {
		return bdManageMapper.selectSearchBidSttusList(bidVO);
	}

	@Override
    public BdManageVO selectBidDashboardData(BdManageVO bidVO) throws Exception {
        return bdManageMapper.selectBidDashboardData(bidVO);
    }

    @Override
    public int insertBidData(BdManageVO bidVO) throws Exception {

        Account account = userInfoUtil.getAccountInfo();
        String userId ="";
        if(account != null) {
            userId = account.getId();
        }
        
        bidVO.setFrstRegisterId(userId);
        bidVO.setLastChangerId(userId);

        String bidKey;
        if(bidVO.getBidPblancId() != null) {
            bidKey = bidVO.getBidPblancId();
        }
        else {
            bidKey = bdManageMapper.selectBidPblancId(bidVO);
        }
        bidVO.setBidPblancId(bidKey);
        /*********** 투찰기간으로 공고 상태 코드 설정 ***********/
        Calendar currentDateTime = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        Date beginDt = null;
        Date endDt = null;
        
        try {
            beginDt = sdf.parse(bidVO.getBddprBeginDt());
            endDt = sdf.parse(bidVO.getBddprEndDt());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        
        if(bidVO.getDspyAt().equals("N")) {
            // 비활성으로 등록
            bidVO.setBidSttusCode("11"); // 공고대기
            
        } else {
            // 활성으로 등록
            if(currentDateTime.getTime().before(beginDt)) {
                // 시작일 이전일 경우
                bidVO.setBidSttusCode("12"); // 입찰예정
            } else if(currentDateTime.getTime().after(endDt)) {
                // 마감일 이후일 경우
                // 투찰 업체 순위 및 낙찰여부 업데이트
                //List<BdManageVO> rankList = bdManageMapper.selectBddprRankList(bidVO);
               
                List<BdManageVO> bddprEntrpsList = bdManageMapper.selectBddprEntrpsList(bidVO); //투찰 업체 목록

                String sttusCode = bddprEntrpsList.size() > 0 ? "21" : "32";   // 개찰중 : 유찰
                if(bddprEntrpsList.size() == 0) bidVO.setRejectBidResn("투찰기업:0, 자동 유찰 처리");
                bidVO.setBidSttusCode(sttusCode);
                
//                if(rankList.size() > 0) {
//                    BdManageVO rankVO = new BdManageVO();
//                    for(int i=0; i<rankList.size(); i++) {
//                        rankVO.setBidPblancId(rankList.get(i).getBidPblancId());
//                        rankVO.setBidEntrpsNo(rankList.get(i).getBidEntrpsNo());
//                        rankVO.setOpengRank(rankList.get(i).getRownum());
//                        if(rankList.get(i).getRownum() == 1) {
//                            rankVO.setScsbidAt("Y");
//                        } else {
//                            rankVO.setScsbidAt("N");
//                        }
//                        // 마감 시 투찰 업체 순위 자동 집계
//                        bdManageMapper.updateBddprDtl(rankVO);
//                    }
//                    // 1순위 업체 낙찰 테이블 인서트
//                    bdManageMapper.insertScsbidDtl(bidVO);
//                }
            } else {
                bidVO.setBidSttusCode("13"); // 투찰중      
            }
        }
        
        /*********** 추가제출 서류 ***********/
        ItCmnCodeVO vo = new ItCmnCodeVO();
        vo.setMainCode("BID_DOC_TY_CODE");
        vo.setCodeDctwo("");
        vo.setUseAt("Y");
        
        String docArr[] = bidVO.getBidDocArr();
        
        List<ItCmnCodeVO> bdDocTyCodeList = itCmnCodeService.selectCmnCodeList(vo); // (공통코드) 입찰 문서 유형 코드 리스트
        for(int i=0; i < bdDocTyCodeList.size(); i++) {
            if(docArr[i].equals("Y")) {
                bidVO.setDocUseAt("Y");
            } else {
                bidVO.setDocUseAt("N");
            }
            bidVO.setBidDocTyCode("0"+Integer.toString(i+1));
            bdManageMapper.insertBidDocBas(bidVO);
        }
        // return 0;

        if(bidVO.getBidUpdtCn() != null && !bidVO.getBidUpdtCn().equals("")) {
            bdManageMapper.insertBidUpdtInfo(bidVO);
        }
        return bdManageMapper.insertBidData(bidVO);
    }

    @Override
    public BdManageVO selectBidDetailData(BdManageVO bidVO) throws Exception {
        List<BdManageVO> selectBidFileList = bdManageService.selectBidFileList(bidVO);
        String bddprFileConfmSttus = null;
        for (int i = 0; i < selectBidFileList.size(); i++) {
            bidVO = selectBidFileList.get(i);
            if(bidVO.getBidDocJdgmnSttusCode() != null && !bidVO.getBidDocJdgmnSttusCode().equals("01")) {
                bddprFileConfmSttus = "Y";
            } else {
                bddprFileConfmSttus = "N";
            }
        }
        bidVO.setBddprFileConfm(bddprFileConfmSttus);
        return bdManageMapper.selectBidDetailData(bidVO);
    }

    @Override
    public List<BdManageVO> selectBddprAtcList(BdManageVO bidVO) throws Exception {
        return bdManageMapper.selectBddprAtcList(bidVO);
    }

    @Override
    public List<BdManageVO> selectBidFileList(BdManageVO bidVO) throws Exception {
        return bdManageMapper.selectBidFileList(bidVO);
    }

    @Override
    public List<BdManageVO> selectBidUpdtList(BdManageVO bidVO) throws Exception {
        return bdManageMapper.selectBidUpdtList(bidVO);
    }

    @Override
    public List<BdManageVO> selectBddprEntrpsList(BdManageVO bidVO) throws Exception {
        return bdManageMapper.selectBddprEntrpsList(bidVO);
    }

    @Override
    public int deleteBid(BdManageVO bidVO) throws Exception {

        Account account = userInfoUtil.getAccountInfo();
        String userId ="";
        if(account != null) {
            userId = account.getId();
        }
        bidVO.setBidSttusCode("33");         // 33 : 공고 취소
        bidVO.setDspyAt("N");                // N  : 전시 여부
        bidVO.setFrstRegisterId(userId);
        bidVO.setLastChangerId(userId);

        return bdManageMapper.deleteBid(bidVO);
    }
    
    public int updatePapersConfm(BdManageVO bidVO) throws Exception {
        Account account = userInfoUtil.getAccountInfo();
        String userId ="";
        if(account != null) {
            userId = account.getId();
        }
        bidVO.setLastChangerId(userId);
        
        //bidVO.setBidDocJdgmnSttusCode("03"); // 입찰 문서 심사 상태 코드 : 적합(03)
        bdManageMapper.updateBidDocJdgmnSttusCode(bidVO);
        
        
        boolean jdgmnComptAt = true; // 승인 완료 여부

        BdManageVO vo = new BdManageVO();
        vo.setBidPblancId(bidVO.getBidPblancId());
        vo.setBidDocTyCode("");        
        List<BdManageVO> atcFileList = bdManageMapper.selectBddprAtcList(vo);
        
        for(int i=0; i<atcFileList.size(); i++) {
            if(!atcFileList.get(i).getBidDocJdgmnSttusCode().equals("03")) {
                jdgmnComptAt = false;
            } 
            if(atcFileList.get(i).getBidDocJdgmnSttusCode().equals("04")) {
                bidVO.setJdgmnSttusCode("41"); // (투찰) 심사 상태 코드 : 41(부적격) 
                bdManageMapper.updateJdgmnSttusCode(bidVO);
                
                bidVO.setBidSttusCode("22"); // 입찰 상태 코드 : 22(서류접수중) 
                bdManageMapper.updateBidSttusCode(bidVO);
            }
        }
        
        if(jdgmnComptAt) {
            // 제출 서류가 전부 승인일 경우 ==> 심사 상태 코드 승인으로 변경
            //bidVO.setBidSttusCode("30"); // 입찰 상태 코드 : 마감(30) 
            bidVO.setJdgmnSttusCode("40"); // (투찰) 심사 상태 코드 : 40(승인) 
            //bdManageMapper.updateBidSttusCode(bidVO);
            bdManageMapper.updateJdgmnSttusCode(bidVO);
        }
        
        return 0;
        
    }

    public String selectScsbidEntrpsNo(BdManageVO bidVO) throws Exception {
        return (String) bdManageMapper.selectScsbidEntrpsNo(bidVO);
    }

    public String selectJdgmnSttusCode(BdManageVO bidVO) throws Exception {
        return (String) bdManageMapper.selectJdgmnSttusCode(bidVO);
    }
    
    @Override
    public int updateBidSttusCode(BdManageVO bidVO) throws Exception {
        Account account = userInfoUtil.getAccountInfo();
        String userId ="";
        if(account != null) {
            userId = account.getId();
        }
        bidVO.setLastChangerId(userId);
      
        return bdManageMapper.updateBidSttusCode(bidVO);
    }

    @Override
    public List<BdManageVO> selectBidFileUseList(BdManageVO bidVO) throws Exception {
        return bdManageMapper.selectBidFileUseList(bidVO);
    }
    
    @Override
    public int updateJdgmnCoomptDt(BdManageVO bidVO) throws Exception {
      
        return bdManageMapper.updateJdgmnCoomptDt(bidVO);
    }
    
    /**
     * 입찰공고 수정내역 
     */
    @Override
    public List<BdManageVO> selectBidUpdtInfo(BdManageVO bidVO) throws Exception {
        return bdManageMapper.selectBidUpdtInfo(bidVO);
    }
    
    /**
     * 투찰업체 정보(순위, 낙찰여부) 등록
     */
    @Override
    public int updateBddprEntrpsInfo(ArrayList<BdManageVO> bddprEntrpsList) throws Exception {
        // TODO Auto-generated method stub
        BdManageVO bdManageVO;
        int result = 0;

        for(int i=0;i<bddprEntrpsList.size();i++) {
            bdManageVO = bddprEntrpsList.get(i);

            bdManageVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
            result = bdManageMapper.updateBddprEntrpsInfo(bdManageVO);
            bdManageVO.setBidSttusCode("31"); // 입찰 상태 코드 : 31(낙찰) 
            bdManageMapper.updateBidSttusCode(bdManageVO);
            // 투찰 히스토리 insert 추가 필요
        }

//        BrandCodeVO brandCodeVO = new BrandCodeVO();
//        List<BrandCodeVO> brandCodeList = brandCodeMapper.getBrandCode(brandCodeVO);
//        cacheUtil.put("brandCodeList", brandCodeList);
//
//        BrandGroupCodeVO brandGroupCodeVO = new BrandGroupCodeVO();
//        List<BrandGroupCodeVO> brandGroupCodeList = brandGroupCodeMapper.getBrandGroupCode(brandGroupCodeVO);
//        cacheUtil.put("brandGroupCodeList", brandGroupCodeList);

        return result;
    }
    
    @Override
    public List<BdManageVO> selectDelyCndCodeList(String dstrctLclsfCode) throws Exception {
        return bdManageMapper.selectDelyCndCodeList(dstrctLclsfCode);
    }
    
}
