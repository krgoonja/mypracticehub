package com.sorincorp.bo.bd.service;

import java.util.List;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.bd.mapper.BdMberManageMapper;
import com.sorincorp.bo.bd.model.BdMberManageVO;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.util.CryptoUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * BidMberManageServiceImpl.java
 *
 * @version
 * @since 2023. 06. 23.
 * @author srec0077
 */
@Slf4j
@Service
@ComponentScan(basePackages = { "com.sorincorp.comm.service", "com.sorincorp.comm.util" })
public class BdMberManageServiceImpl implements BdMberManageService {
	
	@Autowired
	public BdMberManageMapper bidMberMapper;

	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Autowired
	private CommonService commonService;
	
	/**구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 목록 조회*/
	@Override
	public List<BdMberManageVO> searchBidMberList(BdMberManageVO bidMberManageVO) throws Exception {
		try {
			List<BdMberManageVO> bdMberList = bidMberMapper.searchBidMberList(bidMberManageVO);
			String moblphonNo = "";
	 
			
			for(BdMberManageVO vo : bdMberList) {
				moblphonNo = vo.getMoblphonNo2();
				if(moblphonNo != null && !"".equals(moblphonNo)) {
					try {
					    log.debug("휴대폰번호 복호화 전 =============>" + moblphonNo);
					    moblphonNo = CryptoUtil.decryptAES256(moblphonNo);
					    log.debug("휴대폰번호 복호화 후 =============>" + moblphonNo);
					    vo.setMoblphonNo2(moblphonNo);
					} catch (Exception e) {
					    log.error("searchBidMberList RECVER_TLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
						}
					}
			}

			return bdMberList;
		} catch (Exception e) {
		    log.error("searchBidMberList RECVER_TLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
		}
		return null;
		
	}
	
	/**구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 목록 조회(개수)*/
	@Override
	public int searchBidMberListCnt(BdMberManageVO bidMberManageVO) throws Exception {
		return bidMberMapper.searchBidMberListCnt(bidMberManageVO);
	}
	
	/**구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 목록 조회*/
	@Override
	public BdMberManageVO selectBidMber(BdMberManageVO bidMberManageVO) throws Exception {
		try {
			BdMberManageVO bidMber = bidMberMapper.selectBidMber(bidMberManageVO);
			
			String moblphonNo = "";
			moblphonNo = bidMber.getMoblphonNo2();
			if(moblphonNo != null && !"".equals(moblphonNo)) {
				try {
				    log.debug("휴대폰번호 복호화 전 =============>" + moblphonNo);
				    moblphonNo = CryptoUtil.decryptAES256(moblphonNo);
				    log.debug("휴대폰번호 복호화 후 =============>" + moblphonNo);
				    bidMber.setMoblphonNo2(moblphonNo);
				} catch (Exception e) {
				    log.error("searchBidMberList RECVER_TLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
					}
				}
			
			String vrscMoblphonNo = "";
			vrscMoblphonNo = bidMber.getVrscMoblphonNo();
			if(vrscMoblphonNo != null && !"".equals(vrscMoblphonNo)) {
				try {
				    log.debug("휴대폰번호 복호화 전 =============>" + vrscMoblphonNo);
				    vrscMoblphonNo = CryptoUtil.decryptAES256(vrscMoblphonNo);
				    log.debug("휴대폰번호 복호화 후 =============>" + vrscMoblphonNo);
				    bidMber.setVrscMoblphonNo(vrscMoblphonNo);
				} catch (Exception e) {
				    log.error("searchBidMberList RECVER_TLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
					}
				}

			String entrpsTlphonNo = bidMber.getEntrpsTlphonNo();
			String vrscTlphonNo = bidMber.getVrscTlphonNo();
			if(entrpsTlphonNo != null && !"".equals(entrpsTlphonNo)){
				log.info("업체 회사번호 복호화 전 ===============>" + entrpsTlphonNo);
				entrpsTlphonNo = CryptoUtil.decryptAES256(entrpsTlphonNo);
				log.info("업체 회사번호 복호화 후 ===============>" + entrpsTlphonNo);
				bidMber.setEntrpsTlphonNo(entrpsTlphonNo);
			}
			if(vrscTlphonNo != null && !"".equals(vrscTlphonNo)){
				log.info("대행업체 회사번호 복호화 전 ===============>" + vrscTlphonNo);
				vrscTlphonNo = CryptoUtil.decryptAES256(vrscTlphonNo);
				log.info("대행업체 회사번호 복호화 후 ===============>" + vrscTlphonNo);
				bidMber.setVrscTlphonNo(vrscTlphonNo);
			}
			return bidMber;
		} catch (Exception e) {
		    log.error("selectBidMber RECVER_TLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
		}
		return null;
		
	}
	
	/**구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 목록 조회*/
	@Override
	public int checkBlockBidMemberCnt(BdMberManageVO bidMberManagerVO) throws Exception {
		return bidMberMapper.checkBlockBidMemberCnt(bidMberManagerVO);
	}
	
	/**구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 상세페이지 회원 차단기능 */
	@Override
	public void blockBidMember(BdMberManageVO bidMberManagerVO) throws Exception {
		try {
			
			Account account = userInfoUtil.getAccountInfo();
			String userId ="";
	
			if(account != null) {
				userId = account.getId();
			}
			bidMberManagerVO.setLastChangerId(userId);
			//업데이트(회원)
			bidMberMapper.blockBidMember(bidMberManagerVO);
			//히스토리
			commonService.insertTableHistory("BD_ENTRPS_INFO_BAS", bidMberManagerVO);
			
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 상세페이지 회원 차단 해제기능 */
	@Override
	public void unBlockBidMember(BdMberManageVO bidMberManageVO) throws Exception {
		try {
			
			Account account = userInfoUtil.getAccountInfo();
			String userId ="";
	
			if(account != null) {
				userId = account.getId();
			}
			bidMberManageVO.setLastChangerId(userId);
			//업데이트(회원)
			bidMberMapper.unBlockBidMember(bidMberManageVO);
			//히스토리
			commonService.insertTableHistory("BD_ENTRPS_INFO_BAS", bidMberManageVO);
			
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 상세페이지 회원 승인 기능 */
	@Override
	public void changeBidMember(BdMberManageVO bidMberManageVO) throws Exception {
		try {
			Account account = userInfoUtil.getAccountInfo();
			String userId ="";
			
			if(account != null) {
				userId = account.getId();
			}
			bidMberManageVO.setLastChangerId(userId);
			
			//가입 회원 업데이트(회원)
			if(bidMberManageVO.getActiveGrid().equals("app")) {
				bidMberMapper.appBidMember(bidMberManageVO);
			//변경 회원 업데이트(회원)
			}else if(bidMberManageVO.getActiveGrid().equals("info")) {
				bidMberMapper.infoBidMember(bidMberManageVO);
			}
			
			//히스토리
			commonService.insertTableHistory("BD_ENTRPS_INFO_BAS", bidMberManageVO);
			
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	
	/**구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 상세페이지 회원 거절 기능 */
	@Override
	public void unChangeBidMember(BdMberManageVO bidMberManageVO) throws Exception {
		try {
			
			Account account = userInfoUtil.getAccountInfo();
			String userId ="";
			
			if(account != null) {
				userId = account.getId();
			}
			bidMberManageVO.setLastChangerId(userId);
			
			//가입 회원 업데이트(회원)
			if(bidMberManageVO.getActiveGrid().equals("app")) {
				bidMberMapper.unAppBidMember(bidMberManageVO);
			//변경 회원 업데이트(회원)
			}else if(bidMberManageVO.getActiveGrid().equals("info")) {
				bidMberMapper.unInfoBidMember(bidMberManageVO);
			}
			//히스토리
			commonService.insertTableHistory("BD_ENTRPS_INFO_BAS", bidMberManageVO);
			
		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**구매입찰관리 > 입찰 회원 관리 > 정상 회원 수 */
	@Override
	public int selectNormalEntrpsCnt( ) throws Exception {
		return bidMberMapper.selectNormalEntrpsCnt();
	}
	/**구매입찰관리 > 입찰 회원 관리 > 차단 회원 수 */
	@Override
	public int selectBlockEntrpsCnt( ) throws Exception {
		return bidMberMapper.selectBlockEntrpsCnt();
	}
	/**구매입찰관리 > 입찰 회원 관리 > 가입 승인 대기 수 */
	@Override
	public int selectAppEntrpsCnt( ) throws Exception {
		return bidMberMapper.selectAppEntrpsCnt();
	}

	/** 사업자 등록증 조회 */
	@Override
	public String selectDocNo(String docNo) throws Exception {
		String filePath = "";
		try {
			FileDocVO bsnmFile = bidMberMapper.selectDocNo(docNo);
			filePath = bsnmFile.getDocFileRealCours();
		}  catch(Exception e) {
			log.error("BdMberManageServiceImpl :: selectDocNo ERROR " + e.getMessage());
		}
		return filePath;
	}
}
