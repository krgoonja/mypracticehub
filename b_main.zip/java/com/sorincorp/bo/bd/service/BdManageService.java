package com.sorincorp.bo.bd.service;

import java.util.ArrayList;
import java.util.List;

import com.sorincorp.bo.bd.model.BdManageVO;
import com.sorincorp.bo.it.model.BrandMgrVO;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.op.model.NoticeVO;

public interface BdManageService {
    /**
     * <pre>
     * 처리내용: 구매입찰 공고 목록을 조회한다
     * </pre>
     * @date 2023. 7. 7.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 7.         srec0077            최초작성
     * ------------------------------------------------
     * 
     * 
     * @param bidVO
     * @return
     * @throws Exception
     */
	List<BdManageVO> selectBdList(BdManageVO bidVO) throws Exception;

    /**
     * <pre>
     * 처리내용:  구매입찰 공고 총 갯수를 조회한다.
     * </pre>
     * @date 2023. 7. 7.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 7.         srec0077            최초작성
     * ------------------------------------------------
     * @param bidVO
     * @return
     * @throws Exception
     */
	int selectBdListTotcnt(BdManageVO bidVO) throws Exception;

    /**
     * <pre>
     * 처리내용: 구매입찰 공고 상태(검색영역)목록을 조회한다
     * </pre>
     * @date 2023. 7. 7.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 7.         srec0077            최초작성
     * ------------------------------------------------
     * @param bidVO
     * @return
     * @throws Exception
     */
	List<BdManageVO> selectSearchBidSttusList(BdManageVO bidVO) throws Exception;

    /**
      * <pre>
     * 처리내용: 구매입찰 공고 현황 대시보드 데이터를 조회한다
     * </pre>
     * @date 2023. 7. 7.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 7.         srec0077            최초작성
     * ------------------------------------------------
     * @param bidVO
     * @return
     * @throws Exception
     */
	BdManageVO selectBidDashboardData(BdManageVO bidVO) throws Exception;

    /**
     * <pre>
     * 처리내용: 구매입찰 공고를 등록한다.
     * </pre>
     * @date 2023. 7. 19.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 7. 19.         srec0077            최초작성
     * ------------------------------------------------
     * @param vo
     * @return
     */
    int insertBidData(BdManageVO bidVO) throws Exception;

    /**
     * <pre>
    * 처리내용: 구매입찰 공고 상세 데이터를 조회한다
    * </pre>
    * @date 2023. 7. 21.
    * @author srec0077
    * @history
    * ------------------------------------------------
    * 변경일                  작성자          변경내용
    * ------------------------------------------------
    * 2023. 7. 21.         srec0077            최초작성
    * ------------------------------------------------
    * @param bidVO
    * @return
    * @throws Exception
    */
   BdManageVO selectBidDetailData(BdManageVO bidVO) throws Exception;

   /**
    * <pre>
    * 처리내용: 구매입찰 서류 목록을 조회한다.
    * </pre>
    * @date 2023. 7. 26.
    * @author srec0077
    * @history
    * ------------------------------------------------
    * 변경일                  작성자          변경내용
    * ------------------------------------------------
    * 2023. 7. 26.         srec0077            최초작성
    * ------------------------------------------------
    * @param bidVO
    * @return
    * @throws Exception
    */
   List<BdManageVO> selectBddprAtcList(BdManageVO bidVO) throws Exception;
   List<BdManageVO> selectBidFileList(BdManageVO bidVO) throws Exception;

   /**
    * <pre>
    * 처리내용: 구매입찰 수정 이력 목록을 조회한다.
    * </pre>
    * @date 2023. 7. 26.
    * @author srec0077
    * @history
    * ------------------------------------------------
    * 변경일                  작성자          변경내용
    * ------------------------------------------------
    * 2023. 7. 26.         srec0077            최초작성
    * ------------------------------------------------
    * @param bidVO
    * @return
    * @throws Exception
    */
   List<BdManageVO> selectBidUpdtList(BdManageVO bidVO) throws Exception;

   /**
    * <pre>
    * 처리내용: 투찰 업체 목록을 조회한다.
    * </pre>
    * @date 2023. 7. 27.
    * @author srec0077
    * @history
    * ------------------------------------------------
    * 변경일                  작성자          변경내용
    * ------------------------------------------------
    * 2023. 7. 27.         srec0077            최초작성
    * ------------------------------------------------
    * @param bidVO
    * @return
    * @throws Exception
    */
   List<BdManageVO> selectBddprEntrpsList(BdManageVO bidVO) throws Exception;

   /**
    * <pre>
    * 처리내용: 구매입찰 공고를 삭제한다.
    * </pre>
    * @date 2023. 7. 19.
    * @author srec0077
    * @history
    * ------------------------------------------------
    * 변경일                  작성자             변경내용
    * ------------------------------------------------
    * 2023. 7. 19.         srec0077            최초작성
    * ------------------------------------------------
    * @param vo
    * @return
    */
   int deleteBid(BdManageVO bidVO) throws Exception;
   
   int updatePapersConfm(BdManageVO bidVO) throws Exception;
   
   /* 1순위 업체 번호 */
   String selectScsbidEntrpsNo(BdManageVO bidVO) throws Exception;

   String selectJdgmnSttusCode(BdManageVO bidVO) throws Exception;
   
   int updateBidSttusCode(BdManageVO bidVO) throws Exception;
   int updateJdgmnCoomptDt(BdManageVO bidVO) throws Exception;
  
   List<BdManageVO> selectBidFileUseList(BdManageVO vo) throws Exception;

   List<BdManageVO> selectBidUpdtInfo(BdManageVO bidVO) throws Exception;
   
   //투찰업체 정보(순위, 낙찰여부) 등록
   int updateBddprEntrpsInfo(ArrayList<BdManageVO> bddprEntrpsList) throws Exception;
   
   List<BdManageVO> selectDelyCndCodeList(String dstrctLclsfCode) throws Exception;
   
}
