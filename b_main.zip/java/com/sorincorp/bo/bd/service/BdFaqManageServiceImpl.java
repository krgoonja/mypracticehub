package com.sorincorp.bo.bd.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sorincorp.comm.common.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.microsoft.azure.storage.core.Logger;
import com.sorincorp.bo.bd.mapper.BdFaqManageMapper;
import com.sorincorp.bo.bd.model.BdFaqManageVO;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.util.MessageUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BdFaqManageServiceImpl implements BdFaqManageService {

	@Autowired
	public FileDocService fileDocService;

	@Autowired
	private CommonService commonService;

	@Autowired
	private BdFaqManageMapper BdFaqMapper;

	@Autowired
	MessageUtil messageUtil;

	@Override
	public int insertAndUpdateGridDataList(List<BdFaqManageVO> faqVoList, String regId) throws Exception {
		int result = 0;
		try {
			for(BdFaqManageVO paramVo : faqVoList) {
				String status = paramVo.getGridRowStatus();
				paramVo.setFrstRegisterId(regId);
				paramVo.setLastChangerId(regId);
				if(status.equals("created")) {
					result = insertFaq(paramVo);
				} else if (status.equals("updated")) {
					result = updateFaq(paramVo);
				}

				List<FileDocVO> attachFiles = paramVo.getAttachFiles();
				if(attachFiles != null) {
					for(FileDocVO file : attachFiles) {
						int docNo = file.getDocNo();
						paramVo.setDocNo(docNo);
						BdFaqMapper.insertBdFaqAtchmnflBas(paramVo);
					}
				}
			}
		}catch(Exception e) {
			log.error(e.getMessage());
			throw e;
		}
		return result;
	}

	/**
	 * Faq를 등록한다.
	 * @param vo - 등록할 정보가 담긴 BdFaqManageVO
	 * @return void형
	 * @exception Exception
	 */
	@Override
	public int insertFaq(BdFaqManageVO vo) throws Exception {
		
		int insertResult =BdFaqMapper.insertFaq(vo);
		//BdFaqMapper.insertFaqHis(vo);
		commonService.insertTableHistory("BD_FAQ_BAS", vo);

		return insertResult;
	}

	/**
	 * Faq를 수정한다.
	 * @param vo - 수정할 정보가 담긴 BdFaqManageVO
	 * @return void형
	 * @exception Exception
	 */
	@Override
	public int updateFaq(BdFaqManageVO vo) throws Exception {
		int updateResult = BdFaqMapper.updateFaq(vo);
		//BdFaqMapper.insertFaqHis(vo);
		commonService.insertTableHistory("BD_FAQ_BAS", vo);
		return updateResult;
	}

	@Override
	public int deleteFaqList(List<BdFaqManageVO> paramList, String delId) throws Exception {
		int del_cnt = 0;
		for(BdFaqManageVO deleteVO : paramList) {
			/*
			 * Step1. faq 삭제
			 */

			deleteVO.setFrstRegisterId(delId);
			deleteVO.setLastChangerId(delId);
			del_cnt += deleteFaq(deleteVO);

			/*
			 * Step2. 파일 삭제
			 */
			List<BdFaqManageVO> faqFileList = BdFaqMapper.selectBdFaqAtchmnflBasList(deleteVO);
			for(BdFaqManageVO fileVo : faqFileList) {
				fileVo.setFrstRegisterId(delId);
				fileVo.setLastChangerId(delId);
				deleteFaqAttachFile(fileVo);
			}
		}

		return del_cnt;
	}

	/**
	 * Faq를 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BdFaqManageVO
	 * @return delete count
	 * @exception Exception
	 */
	private int deleteFaq(BdFaqManageVO vo) throws Exception {
		int delResult = BdFaqMapper.deleteFaq(vo);
		//BdFaqMapper.insertFaqHis(vo);
		commonService.insertTableHistory("BD_FAQ_BAS", vo);
		return delResult;
	}

	/**
	 * Faq를 조회한다.
	 * @param vo - 조회할 정보가 담긴 BdFaqManageVO
	 * @return 조회한 Faq
	 * @exception Exception
	 */
	@Override
	public HashMap<?,?> selectFaq(BdFaqManageVO vo) throws Exception {
		HashMap<?,?> resultVO = BdFaqMapper.selectFaq(vo);
		return resultVO;
	}

	/**
	 * Faq 목록을 조회한다.
	 * @param BdFaqManageVO - 조회할 정보가 담긴 VO
	 * @return Faq 목록
	 * @exception Exception
	 */
	@Override
	public List<BdFaqManageVO> selectFaqList(BdFaqManageVO faqVO) throws Exception {
		return BdFaqMapper.selectFaqList(faqVO);
	}


	/**
	 * Faq 총 갯수를 조회한다.
	 * @param BdFaqManageVO - 조회할 정보가 담긴 VO
	 * @return Faq 총 갯수
	 * @exception
	 */
	@Override
	public int selectFaqListTotCnt(BdFaqManageVO faqVO) {
		return BdFaqMapper.selectFaqListTotCnt(faqVO);
	}

	/**
	 * Faq 신규 순서를 조회한다.
	 * @return 신규 Faq 순서
	 * @exception
	 */
	@Override
	public int selectMaxFaqOrdr() {
		return BdFaqMapper.selectMaxFaqOrdr();
	}

	@Override
	public List<FileDocVO> selectAttachFiles(BdFaqManageVO vo) throws Exception {
		List<FileDocVO> fileList = null;
		int faqNo = vo.getFaqNo();
		if(faqNo > 0) {
			fileList = BdFaqMapper.selectDocInfoList(vo);
		}else {
			fileList = new ArrayList<>();
		}
		return fileList;
	}

	@SuppressWarnings("finally")
	@Override
	public Map<String, Object> saveAttachFile(MultipartHttpServletRequest mRequest) throws Exception {
		Map<String,Object> map = new HashMap<String,Object>();
		List<FileDocVO> list = new ArrayList<FileDocVO>();

//		list = fileDocService.uploadAttachFilesVoList("OP", mRequest);// 파일 저장
		list = fileDocService.uploadPublicAttachFilesVoList("OP", mRequest);// 파일 저장

		map.put("list", list);
		return map;
	}

	@Override
	public void deleteFaqAttachFile(BdFaqManageVO vo) throws Exception {
		int docNo = vo.getDocNo();
		BdFaqMapper.deleteBdFaqAtchmnflBas(vo);

		fileDocService.deleteCommonDoc(docNo);
	}

}
