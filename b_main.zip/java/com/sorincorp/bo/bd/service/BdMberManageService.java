package com.sorincorp.bo.bd.service;

import java.util.List;

import com.sorincorp.bo.bd.model.BdMberManageVO;


/**
 * BidMberManageService.java
 *
 * @version
 * @since 2023. 06. 23.
 * @author srec0077
 */
public interface BdMberManageService {
	
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 목록 조회
	 * </pre>
	 * @date 2023. 06. 23.
	 * @author srec0077
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 06. 23.		 srec0077			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bidMberManageVO
	 * @return	List<BdMberManageVO>
	 * @throws 	Exception
	 */
	List<BdMberManageVO> searchBidMberList(BdMberManageVO bidMberManageVO) throws Exception;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 목록 조회(개수)
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bidMberManageVO
	 * @return	int
	 * @throws 	Exception
	 */
	int searchBidMberListCnt(BdMberManageVO bidMbeManagerVO) throws Exception ;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 목록 조회 
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bidMberManageVO
	 * @return	
	 * @throws 	Exception
	 */
	BdMberManageVO selectBidMber(BdMberManageVO bidMberManageVO) throws Exception ;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 목록 조회 
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bidMberManageVO
	 * @return	
	 * @throws 	Exception
	 */
	int checkBlockBidMemberCnt(BdMberManageVO bidMberManagerVO) throws Exception ;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 목록 조회 
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param BdMberManageVO bidMberManageVO
	 * @return	
	 * @throws 	Exception
	 */
	void blockBidMember(BdMberManageVO bidMberManageVO) throws Exception ;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 상세페이지 회원 차단 해제기능
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bidMberManageVO
	 * @return	
	 * @throws 	Exception
	 */
	void unBlockBidMember(BdMberManageVO bidMberManageVO) throws Exception ;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 상세페이지 회원 승인 기능
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param BdMberManageVO bidMberManageVO
	 * @return	
	 * @throws 	Exception
	 */
	void changeBidMember(BdMberManageVO bidMberManageVO) throws Exception ;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 상세페이지 회원 거절 기능 
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bidMberManageVO  
	 * @return	
	 * @throws 	Exception
	 */
	void unChangeBidMember(BdMberManageVO bidMberManageVO) throws Exception ;
	
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 정상 회원 수 
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein					최초작성
	 * ------------------------------------------------
	 * @param 	
	 * @return	int
	 * @throws 	Exception
	 */
	int selectNormalEntrpsCnt() throws Exception ;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 차단 회원 수 
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein					최초작성
	 * ------------------------------------------------
	 * @param 	
	 * @return	int
	 * @throws 	Exception
	 */
	int selectBlockEntrpsCnt() throws Exception ;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 가입승인대기 수 
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein					최초작성
	 * ------------------------------------------------
	 * @param 	
	 * @return	int
	 * @throws 	Exception
	 */
	int selectAppEntrpsCnt() throws Exception ;

	/**
	 * <pre>
	 * 처리내용: 사업자 등록증 조회
	 * </pre>
	 * @date 2023. 9. 11.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 11.	  	hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param docNo
	 * @throws Exception
	 */
	String selectDocNo(String docNo) throws Exception;
}
