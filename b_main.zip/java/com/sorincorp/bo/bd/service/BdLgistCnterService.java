package com.sorincorp.bo.bd.service;

import java.util.List;

import com.sorincorp.bo.bd.model.BdLgistCnterVO;

public interface BdLgistCnterService {

	/**
	 * <pre>
	 * 처리내용: 지정보세창고관리 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 13.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param lco
	 * @return 
	 */
	List<BdLgistCnterVO> selectLgistCnterList(BdLgistCnterVO lco);

	/**
	 * <pre>
	 * 처리내용: 지정보세창고관리 리스트의 수를 카운트한다.
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 13.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param lco
	 * @return
	 */
	int selectLgistCnterTotCnt(BdLgistCnterVO lco);

	/**
	 * <pre>
	 * 처리내용: 지정보세 창고 관리 리스트를 insert또는 update의 판별 후 실행한다.
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 13.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param list
	 * @param userId
	 * @return
	 */
	int insertAndUpdateGridDataList(List<BdLgistCnterVO> list, String userId);

	/**
	 * <pre>
	 * 처리내용: 기존 창고리스트를 조회한다.
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 13.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param lco
	 * @return
	 */
	List<BdLgistCnterVO> selectOriginalData(BdLgistCnterVO lco);

	/**
	 * <pre>
	 * 처리내용: 기존 창고리스트의 수를 카운트한다.
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 13.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param lco
	 * @return
	 */
	int selectOriginalTotCnt(BdLgistCnterVO lco);

	/**
	 * <pre>
	 * 처리내용: 지정보세 창고 관리 리스트를 insert한다.
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 13.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param lcList
	 * @return
	 */
	int insertLgistData(BdLgistCnterVO lcList);

	/**
	 * <pre>
	 * 처리내용: 지정보세 창고 관리 리스트의 인도조건 코드를 insert한다.
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 13.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param lcList
	 * @return
	 */
	int insertLgistDtlData(BdLgistCnterVO lcList);

	/**
	 * <pre>
	 * 처리내용: 지정보세 창고 관리 리스트를 update한다.
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 13.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param lcList
	 * @return
	 */
	int updateLgistData(BdLgistCnterVO lcList);
	
	/**
	 * <pre>
	 * 처리내용: 지정보세 창고 관리 리스트의 인도조건 코드를 delete한다.
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 13.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param lcList
	 * @return
	 */
	int deleteLgistDtlData(BdLgistCnterVO lcList);

	/**
	 * <pre>
	 * 처리내용: 지정보세 창고 관리 리스트의 인도조건 코드를 update한다.
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 13.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param lcList
	 * @return
	 */
	int updateLgistDtlData(BdLgistCnterVO lcList);

	/**
	 * <pre>
	 * 처리내용: 지정보세 창고 관리 리스트를 삭제한다.
	 * </pre>
	 * @date 2022. 9. 15.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 15.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param lco
	 * @return
	 */
	int deleteGridDataList(BdLgistCnterVO lco);
	
	/**
	 * <pre>
	 * 처리내용: 현재의 BD_WRHOUS_BAS의 currentNum을 가져온다.
	 * </pre>
	 * @date 2022. 9. 15.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 15.			srec0072			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	int getCurrentNum();

}
