package com.sorincorp.bo.bd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.bo.bd.mapper.BdCnvrsPremiumMapper;
import com.sorincorp.bo.bd.model.BdCnvrsPremiumVO;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.common.service.CommonService;

import lombok.extern.slf4j.Slf4j;

/**
 * BdCnvrsPremiumMapper.java
 *
 * @version
 * @since 2023. 07. 31.
 * @author bok3117
 */
@Slf4j
@Service
public class BdCnvrsPremiumServiceImpl implements BdCnvrsPremiumService {
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private BdCnvrsPremiumMapper bdCnvrsPremiumMapper;
	
	/**구매입찰관리 > 전환프리미엄가격관리 > 전환프리미엄가격관리 : 목록 조회*/
	@Override
	public List<BdCnvrsPremiumVO> selectCnvrsPremiumList(BdCnvrsPremiumVO bdCnvrsPremiumVO) throws Exception {
		return bdCnvrsPremiumMapper.selectCnvrsPremiumList(bdCnvrsPremiumVO);
	}
	
	/**구매입찰관리 > 전환프리미엄가격관리 > 전환프리미엄가격관리 : 목록 조회(개수)*/
	@Override
	public int selectCnvrsPremiumListTotcnt(BdCnvrsPremiumVO bdCnvrsPremiumVO) throws Exception {
		return bdCnvrsPremiumMapper.selectCnvrsPremiumListTotcnt(bdCnvrsPremiumVO);
	}
	
	/**구매입찰관리 > 전환프리미엄가격관리 > 전환프리미엄가격관리 : 전환 프리미엄 가격 등록*/
	@Override
	public int insertCnvrsPremium(BdCnvrsPremiumVO bdCnvrsPremiumVO) throws Exception {
		int result = 0;
		
		result = bdCnvrsPremiumMapper.insertCnvrsPremium(bdCnvrsPremiumVO);
		commonService.insertTableHistory("BD_PREMIUM_BAS", bdCnvrsPremiumVO);
		return result;
	}
	
	/**구매입찰관리 > 전환프리미엄가격관리 > 전환프리미엄가격관리 : 전환 프리미엄 가격 수정*/
	@Override
	public int updateCnvrsPremium(BdCnvrsPremiumVO bdCnvrsPremiumVO) throws Exception {
		int result = 0;
		
		result = bdCnvrsPremiumMapper.updateCnvrsPremium(bdCnvrsPremiumVO);
		commonService.insertTableHistory("BD_PREMIUM_BAS", bdCnvrsPremiumVO);
		return result;
	}
	
	/**구매입찰관리 > 전환프리미엄가격관리 > 전환프리미엄가격관리 : 전환 프리미엄 가격 삭제*/
	@Override
	public int deleteCnvrsPremium(BdCnvrsPremiumVO bdCnvrsPremiumVO) throws Exception {
		int result = 0;
		
		result = bdCnvrsPremiumMapper.deleteCnvrsPremium(bdCnvrsPremiumVO);
		commonService.insertTableHistory("BD_PREMIUM_BAS", bdCnvrsPremiumVO);
		return result;
	}
	
	/**구매입찰관리 > 전환프리미엄가격관리 > 전환프리미엄가격관리 : 상태값에 따른 등록 및 수정*/
	@Override
	public int insertAndUpdateGridDataList(List<BdCnvrsPremiumVO> bdCnvrsPremiumList, String userId) throws Exception {
        Account account = userInfoUtil.getAccountInfo();
        int result = 0; 
        userId = account.getId();
        
        for (int i = 0; i < bdCnvrsPremiumList.size(); i++) {
        	String status = bdCnvrsPremiumList.get(i).getGridRowStatus();
            BdCnvrsPremiumVO data = bdCnvrsPremiumList.get(i);
            
            if(status.equals("created")) {
                log.info("insertGridDataList insert: " + data);
                data.setFrstRegisterId(userId);
                data.setLastChangerId(userId);
                result = insertCnvrsPremium(data);
            } else if (status.equals("updated")) {
                log.info("updateGridDataList insert: " + data);
                data.setLastChangerId(userId);
                result = updateCnvrsPremium(data);
            } else if (status.equals("delete")) {
                log.info("deleteGridDataList delete: " + data);
                data.setLastChangerId(userId);
               result = deleteCnvrsPremium(data);
            }
            
            if(result == 0) {
                log.info("ERROR.Rollback::insertAndUpdateGridDataList " + data);
                return result;
            }
        }
        return result;
	}
	
	
	
}
