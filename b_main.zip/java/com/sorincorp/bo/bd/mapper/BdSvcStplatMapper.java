package com.sorincorp.bo.bd.mapper;

import java.util.List;

import com.sorincorp.bo.bd.model.BdMberManageVO;
import com.sorincorp.bo.bd.model.BdSvcStplatVO;

/**
 * SvcStplatMapper.java
 * @version
 * @since 2021. 6. 9.
 * @author srec0033
 */
public interface BdSvcStplatMapper { 
	
	/**
	 * <pre>
	 * 처리내용: 서비스 약관을 조회한다.
	 * </pre>
	 * @date 2023.08. 04.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023.08. 04.			sein					최초작성
	 * ------------------------------------------------
	 * @param bdStplat - 조회할 정보가 담긴 BdSvcStplatVO
	 * @return
	 * @throws Exception
	 */
	BdSvcStplatVO selectBdSvcStplat(BdSvcStplatVO bdStplat) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 게시중인 서비스 약관을 조회한다.
	 * </pre>
	 * @date 2023.08. 04.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 *2023.08. 04.			sein					최초작성
	 * ------------------------------------------------
	 * @param bdStplat
	 * @return
	 * @throws Exception
	 */
	BdSvcStplatVO selectBdSvcstplatIng(BdSvcStplatVO bdStplat) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 서비스 약관 목록을 조회한다.
	 * </pre>
	 * @date 2023.08. 04.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023.08. 04.			sein					최초작성
	 * ------------------------------------------------
	 * @param bdStplat - 조회할 정보가 담긴 BdSvcStplatVO
	 * @return 서비스 약관 목록
	 * @throws Exception
	 */
	List<BdSvcStplatVO> selectBdSvcStplatList(BdSvcStplatVO bdStplat) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 서비스 약관을 등록한다.
	 * </pre>
	 * @date 2023.08. 04.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023.08. 04.			sein					최초작성
	 * ------------------------------------------------
	 * @param bdStplat - 등록할 정보가 담긴 BdSvcStplatVO
	 * @throws Exception
	 */
	void insertBdSvcStplat(BdSvcStplatVO bdStplat) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 서비스 약관을 수정한다.
	 * </pre>
	 * @date 2023.08. 04.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023.08. 04.			sein					최초작성
	 * ------------------------------------------------
	 * @param bdStplat - 수정할 정보가 담긴 BdSvcStplatVO
	 * @throws Exception
	 */
	void updateBdSvcStplat(BdSvcStplatVO bdStplat) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 서비스 약관 총 갯수를 조회한다.
	 * </pre>
	 * @date 2023.08. 04.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023.08. 04.			sein					최초작성
	 * ------------------------------------------------
	 * @param bdStplat - 조회할 정보가 담긴 BdSvcStplatVO
	 * @return 서비스 약관 총 갯수
	 * @throws Exception
	 */
	int selectBdSvcStplatListTotcnt(BdSvcStplatVO bdStplat) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 서비스 약관 이력을 등록한다.
	 * </pre>
	 * @date 2023.08. 04.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023.08. 04.			sein					최초작성
	 * ------------------------------------------------
	 * @param bdStplat
	 * @throws Exception
	 */
	void insertBdSvcStplatHistory(BdSvcStplatVO bdStplat) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이메일 발송시를 int형으로 조회한다.
	 * </pre>
	 * @date 2023.08. 04.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023.08. 04.			sein					최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	int selectNsltSndngDtToInt() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 수신자 회원 목록을 조회한다.
	 * </pre>
	 * @date 2023.08. 04.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023.08. 04.			sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<BdMberManageVO> selectBdMberRecieverList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 마케팅 수신 동의 회원 목록을 조회한다.
	 * </pre>
	 * @date 2023.08. 04.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023.08. 04.			sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<BdMberManageVO> selectBdMberMarketingRecieverList() throws Exception;

}
