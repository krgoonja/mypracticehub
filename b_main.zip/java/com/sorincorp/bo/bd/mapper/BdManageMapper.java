package com.sorincorp.bo.bd.mapper;

import java.util.List;

import com.sorincorp.bo.bd.model.BdManageVO;

public interface BdManageMapper {
    /**
     * <pre>
     * 처리내용: 구매입찰 공고 목록을 조회한다
     * </pre>
     * @date 2023. 7. 7.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 7.         srec0077            최초작성
     * ------------------------------------------------
     * @param bidVO
     * @return
     * @throws Exception
     */
	List<BdManageVO> selectBdList(BdManageVO bidVO);

	/**
     * <pre>
     * 처리내용:  구매입찰 공고 총 갯수를 조회한다.
     * </pre>
     * @date 2023. 7. 7.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 7.         srec0077            최초작성
     * ------------------------------------------------
     * @param bidVO
     * @return
     * @throws Exception
     */
	int selectBdListTotcnt(BdManageVO bidVO);

	/**
     * <pre>
     * 처리내용: 구매입찰 공고 상태(검색영역)목록을 조회한다
     * </pre>
     * @date 2023. 7. 7.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 7.         srec0077            최초작성
     * ------------------------------------------------
     * @param bidVO
     * @return
     * @throws Exception
     */
    List<BdManageVO> selectSearchBidSttusList(BdManageVO bidVO);

    /**
     * <pre>
     * 처리내용: 구매입찰 공고 현황 대시보드 데이터를 조회한다
     * </pre>
     * @date 2023. 7. 7.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 7.         srec0077            최초작성
     * ------------------------------------------------
     * @param bidVO
     * @return
     * @throws Exception
     */
    BdManageVO selectBidDashboardData(BdManageVO bidVO);

    /**
     * <pre>
     * 처리내용:  구매입찰 공고를 등록한다.
     * </pre>
     * @date 2023. 7. 19.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 19.         srec0077           최초작성
     * ------------------------------------------------
     * @param bidVO
     * @return
     * @throws Exception
     */
    int insertBidData(BdManageVO bidVO);

    /**
     * <pre>
     * 처리내용: 구매입찰 공고 상세 데이터를 조회한다
     * </pre>
     * @date 2023. 7. 21.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 21.         srec0077            최초작성
     * ------------------------------------------------
     * @param bidVO
     * @return
     * @throws Exception
     */
    BdManageVO selectBidDetailData(BdManageVO bidVO);

    /**
     * <pre>
     * 처리내용: 구매입찰 서류 목록을 조회한다.
     * </pre>
     * @date 2023. 7. 26.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 26.         srec0077            최초작성
     * ------------------------------------------------
     * @param bidVO
     * @return
     * @throws Exception
     */
    List<BdManageVO> selectBddprAtcList(BdManageVO bidVO);
    List<BdManageVO> selectBidFileList(BdManageVO bidVO);
    

    /**
     * <pre>
     * 처리내용: 구매입찰 수정 이력 목록을 조회한다.
     * </pre>
     * @date 2023. 7. 26.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 26.         srec0077            최초작성
     * ------------------------------------------------
     * @param bidVO
     * @return
     * @throws Exception
     */
    List<BdManageVO> selectBidUpdtList(BdManageVO bidVO);


    /**
     * <pre>
     * 처리내용: 투찰 업체 목록을 조회한다.
     * </pre>
     * @date 2023. 7. 27.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 27.         srec0077            최초작성
     * ------------------------------------------------
     * @param bidVO
     * @return
     * @throws Exception
     */
    List<BdManageVO> selectBddprEntrpsList(BdManageVO bidVO);
    List<BdManageVO> selectBddprRankList(BdManageVO bidVO);

    /**
     * <pre>
     * 처리내용:  구매입찰 공고를 삭제한다.
     * </pre>
     * @date 2023. 7. 19.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 19.         srec0077           최초작성
     * ------------------------------------------------
     * @param bidVO
     * @return
     * @throws Exception
     */
    int deleteBid(BdManageVO bidVO);
    

    /**
     * <pre>
     * 처리내용:  입찰 문서 사용여부를 등록한다.
     * </pre>
     * @date 2023. 9. 07.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 9. 07.         srec0077           최초작성
     * ------------------------------------------------
     * @param bidVO
     * @return
     * @throws Exception
     */
    int insertBidDocBas(BdManageVO bidVO);
    
    String selectBidPblancId(BdManageVO bidVO);
    
    int updateBidDocJdgmnSttusCode(BdManageVO bidVO);
    int updateBidSttusCode(BdManageVO bidVO);
    int updateJdgmnSttusCode(BdManageVO bidVO);

    String selectScsbidEntrpsNo(BdManageVO bidVO);
    
    String selectJdgmnSttusCode(BdManageVO bidVO);
    
    List<BdManageVO> selectBidFileUseList(BdManageVO bidVO);
    

    int updateBddprDtl(BdManageVO bidVO);
    int updateJdgmnCoomptDt(BdManageVO bidVO);
    
    int insertScsbidDtl(BdManageVO bidVO);

    int insertBidUpdtInfo(BdManageVO bidVO);
    List<BdManageVO> selectBidUpdtInfo(BdManageVO bidVO);
    
    int updateBddprEntrpsInfo(BdManageVO bidVO);

    List<BdManageVO> selectDelyCndCodeList(String dstrctLclsfCode);
}
