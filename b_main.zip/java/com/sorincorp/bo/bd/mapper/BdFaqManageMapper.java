package com.sorincorp.bo.bd.mapper;

import java.util.HashMap;
import java.util.List;

import com.sorincorp.bo.bd.model.BdFaqManageVO;
import com.sorincorp.comm.filedoc.model.FileDocVO;

public interface BdFaqManageMapper {

//	/**
//	 * Faq 작업이력 등록한다.
//	 * @param vo - 등록할 정보가 담긴 FaqVO
//	 * @return 등록 결과
//	 * @exception Exception
//	 */
//	int insertFaqHis(BdFaqManageVO vo) throws Exception;

	/**
	 * Faq를 등록한다.
	 * @param vo - 등록할 정보가 담긴 bdFaqManageVO
	 * @return 등록 결과
	 * @exception Exception
	 */
	int insertFaq(BdFaqManageVO vo) throws Exception;

	/**
	 * Faq를 수정한다.
	 * @param vo - 수정할 정보가 담긴 BdFaqManageVO
	 * @return void형
	 * @exception Exception
	 */
	int updateFaq(BdFaqManageVO vo) throws Exception;

	/**
	 * Faq를 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BdFaqManageVO
	 * @return 삭제 결과
	 * @exception Exception
	 */
	int deleteFaq(BdFaqManageVO vo) throws Exception;

	/**
	 * Faq를 조회한다.
	 * @param vo - 조회할 정보가 담긴 BdFaqManageVO
	 * @return 조회한 Faq
	 * @exception Exception
	 */
	HashMap<?,?> selectFaq(BdFaqManageVO vo) throws Exception;

	/**
	 * Faq 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return Faq 목록
	 * @exception Exception
	 */
	List<BdFaqManageVO> selectFaqList(BdFaqManageVO searchVO) throws Exception;

	/**
	 * Faq 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return Faq 총 갯수
	 * @exception
	 */
	int selectFaqListTotCnt(BdFaqManageVO searchVO);

	/**
	 * Faq 신규 순서를 조회한다.
	 * @return 신규 Faq 순서
	 * @exception
	 */
	int selectMaxFaqOrdr();

	List<FileDocVO> selectDocInfoList(BdFaqManageVO fileVo) throws Exception;

	int insertBdFaqAtchmnflBas(BdFaqManageVO vo) throws Exception;

	int deleteBdFaqAtchmnflBas(BdFaqManageVO vo) throws Exception;

	List<BdFaqManageVO> selectBdFaqAtchmnflBasList(BdFaqManageVO deleteVO) throws Exception;
	
	void insertFaqHis (BdFaqManageVO vo) throws Exception;
}
