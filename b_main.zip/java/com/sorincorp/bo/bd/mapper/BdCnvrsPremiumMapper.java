package com.sorincorp.bo.bd.mapper;

import java.util.List;

import com.sorincorp.bo.bd.model.BdCnvrsPremiumVO;

/**
 * BdCnvrsPremiumMapper.java
 *
 * @version
 * @since 2023. 07. 31.
 * @author bok3117
 */
public interface BdCnvrsPremiumMapper {
	
	/**
	 * <pre>
	 * 구매입찰관리 > 전환프리미엄가격관리 > 전환프리미엄가격관리 : 목록 조회
	 * </pre>
	 * @date 2023. 07. 31.
	 * @author bok3117
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 31.		bok3117				최초작성
	 * ------------------------------------------------
	 * @param 	bdCnvrsPremiumVO
	 * @return	List<BdCnvrsPremiumVO>
	 * @throws 	Exception
	 */
	List<BdCnvrsPremiumVO> selectCnvrsPremiumList(BdCnvrsPremiumVO bdCnvrsPremiumVO) throws Exception;
	
	/**
	 * <pre>
	 * 구매입찰관리 > 전환프리미엄가격관리 > 전환프리미엄가격관리 : 목록 조회 (개수)
	 * </pre>
	 * @date 2023. 07. 31.
	 * @author bok3117
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 31.		bok3117				최초작성
	 * ------------------------------------------------
	 * @param 	bdCnvrsPremiumVO
	 * @return	int
	 * @throws 	Exception
	 */
	int selectCnvrsPremiumListTotcnt(BdCnvrsPremiumVO bdCnvrsPremiumVO) throws Exception;
	
	/**
	 * <pre>
	 * 구매입찰관리 > 전환프리미엄가격관리 > 전환프리미엄가격관리 : 가격 등록
	 * </pre>
	 * @date 2023. 08. 02.
	 * @author bok3117
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 02.		bok3117				최초작성
	 * ------------------------------------------------
	 * @param 	bdCnvrsPremiumVO
	 * @return
	 * @throws 	Exception
	 */
	int insertCnvrsPremium(BdCnvrsPremiumVO bdCnvrsPremiumVO) throws Exception;
	
	/**
	 * <pre>
	 * 구매입찰관리 > 전환프리미엄가격관리 > 전환프리미엄가격관리 : 가격 수정
	 * </pre>
	 * @date 2023. 08. 02.
	 * @author bok3117
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 02.		bok3117				최초작성
	 * ------------------------------------------------
	 * @param 	bdCnvrsPremiumVO
	 * @return
	 * @throws 	Exception
	 */
	int updateCnvrsPremium(BdCnvrsPremiumVO bdCnvrsPremiumVO) throws Exception;
	
	/**
	 * <pre>
	 * 구매입찰관리 > 전환프리미엄가격관리 > 전환프리미엄가격관리 : 가격 삭제
	 * </pre>
	 * @date 2023. 08. 02.
	 * @author bok3117
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 02.		bok3117				최초작성
	 * ------------------------------------------------
	 * @param 	bdCnvrsPremiumVO
	 * @return
	 * @throws 	Exception
	 */
	int deleteCnvrsPremium(BdCnvrsPremiumVO bdCnvrsPremiumVO) throws Exception;
}
