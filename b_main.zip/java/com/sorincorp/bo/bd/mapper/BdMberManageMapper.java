package com.sorincorp.bo.bd.mapper;

import java.util.List;

import com.sorincorp.bo.bd.model.BdMberManageVO;
import com.sorincorp.comm.filedoc.model.FileDocVO;

/**
 * BidMberManageMapper.java
 *
 * @version
 * @since 2023. 06. 23.
 * @author srec0077
 */
public interface BdMberManageMapper {
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 목록 조회
	 * </pre>
	 * @date 2023. 06. 23.
	 * @author srec0077
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 06. 23.		 srec0077			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bidMberManageVO
	 * @return	List<BdMberManageVO>
	 * @throws 	Exception
	 */
	List<BdMberManageVO> searchBidMberList(BdMberManageVO bdMberManageVO) throws Exception;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 목록 조회(개수)
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bidMberManageVO
	 * @return	int
	 * @throws 	Exception
	 */
	int searchBidMberListCnt(BdMberManageVO bdMberManageVO) throws Exception;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 목록 조회 
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bidMberManageVO
	 * @return	
	 * @throws 	Exception
	 */
	BdMberManageVO selectBidMber(BdMberManageVO bidMberManageVO) throws Exception;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 목록 조회 
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bidMberManageVO
	 * @return	
	 * @throws 	Exception
	 */
	int checkBlockBidMemberCnt(BdMberManageVO bdMberManageVO) throws Exception;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 목록 조회 
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param BdMberManageVO bidMberManageVO
	 * @return	
	 * @throws 	Exception
	 */
	void blockBidMember(BdMberManageVO bdMberManageVO) throws Exception;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 상세페이지 회원 차단 해제기능
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bidMberManageVO
	 * @return	
	 * @throws 	Exception
	 */
	void unBlockBidMember(BdMberManageVO bdMberManageVO) throws Exception;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 상세페이지 회원 승인 기능
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param BdMberManageVO bidMberManageVO
	 * @return	
	 * @throws 	Exception
	 */
	void appBidMember(BdMberManageVO bidMberManageVO) throws Exception;
	void infoBidMember(BdMberManageVO bidMberManageVO) throws Exception;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 입찰 회원 관리 : 상세페이지 회원 거절 기능 
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bidMberManageVO  
	 * @return	
	 * @throws 	Exception
	 */
	void unAppBidMember(BdMberManageVO bidMberManageVO) throws Exception ; 
	void unInfoBidMember(BdMberManageVO bidMberManageVO) throws Exception ;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 정상 회원 수 
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein					최초작성
	 * ------------------------------------------------
	 * @param 	
	 * @return	int
	 * @throws 	Exception
	 */
	int selectNormalEntrpsCnt( ) throws Exception ;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 차단 회원 수 
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein					최초작성
	 * ------------------------------------------------
	 * @param 	
	 * @return	int
	 * @throws 	Exception
	 */
	int selectBlockEntrpsCnt( ) throws Exception ;
	/**
	 * 
	 * <pre>
	 * 구매입찰관리 > 입찰 회원 관리 > 가입 승인 대기 수 
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein					최초작성
	 * ------------------------------------------------
	 * @param 	
	 * @return	int
	 * @throws 	Exception
	 */
	int selectAppEntrpsCnt( ) throws Exception ;

	/**
	 * <pre>
	 * 처리내용: 사업자 등록증 조회
	 * </pre>
	 * @date 2023. 9. 8.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 8.	  	hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param docNo
	 * @throws Exception
	 */
	FileDocVO selectDocNo(String docNo) throws Exception;
	
}
