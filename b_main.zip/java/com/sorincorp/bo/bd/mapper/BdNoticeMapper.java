package com.sorincorp.bo.bd.mapper;

import java.util.List;

import com.sorincorp.bo.bd.model.BdNoticeVO;

public interface BdNoticeMapper {

	/**
	 * <pre>
	 * 처리내용: 공지사항 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @return
	 * @throws Exception
	 */
	List<BdNoticeVO> selectNoticeList(BdNoticeVO searchVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공지사항 총 갯수를 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @return
	 */
	int selectNoticeListTotcnt(BdNoticeVO searchVO);
	
	/**
	 * <pre>
	 * 처리내용: 공지사항을 등록한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param notice
	 * @throws Exception
	 */
	void insertNotice(BdNoticeVO notice) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공지사항을 수정한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param notice
	 * @throws Exception
	 */
	void updateNotice(BdNoticeVO notice) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공지사항을 삭제한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param notice
	 * @throws Exception
	 */
	void deleteNotice(BdNoticeVO notice) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공지사항의 첨부파일 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param notice
	 * @return
	 * @throws Exception
	 */
	List<BdNoticeVO> selectListNoticeAtchmnfl(BdNoticeVO notice) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공지사항의 첨부파일을 등록한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param file
	 * @throws Exception
	 */
	int insertNoticeAtchmnfl(BdNoticeVO file) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공지사항의 첨부파일을 삭제한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param file
	 * @throws Exception
	 */
	void deleteNoticeAtchmnfl(BdNoticeVO file) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공지사항의 이력을 등록한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param noticeVO
	 * @throws Exception
	 */
	void insertNoticeHistory(BdNoticeVO noticeVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공지사항 첨부파일 이력을 등록한다.
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param noticeVO
	 * @throws Exception
	 */
	void insertNoticeAtchmnflHistory(BdNoticeVO noticeVO) throws Exception;

}
