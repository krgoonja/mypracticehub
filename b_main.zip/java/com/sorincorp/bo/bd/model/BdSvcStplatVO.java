package com.sorincorp.bo.bd.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.bo.sample.model.SampleDefaultVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * BdSvcStplatVO.java
 * @version
 * @since 2023. 8. 4.
 * @author sein
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Validated
public class BdSvcStplatVO extends SampleDefaultVO {
	
	private static final long serialVersionUID = -8676528934516756280L;
	
	/**
	 * 약관 번호
	*/
	private int stplatNo;
	
	/**
	 * 약관구분 코드
	*/
	private String stplatSeCode;
	
	/**
	 * 약관 내용 1
	*/
	@NotBlank(message = "약관 내용을 입력해 주세요.")
	@Size(min=0 , max=1073741823)
	private String stplatCnOne = "";
	
	/**
	 * 약관 내용 2
	*/
	@Size(min=0 , max=1073741823)
	private String stplatCnTwo = "";
	
	private String stplatCnThree = "";
	
	/**
	 * 약관개정 공지 일자
	*/
	@NotBlank(message = "약관 공지일을 입력해 주세요.")
	@Max(value = 8)
	private String stplatreformNoticeDe;
	
	/**
	 * 약관개정 시작 일자
	 */
	@NotBlank(message = "약관 개정일을 입력해 주세요.")
	@Max(value = 8)
	private String stplatreformBeginDe;
	
	/**
	 * 삭제 여부
	*/
	private String deleteAt;
	
	/**
	 * 삭제 일시
	*/
	private java.sql.Timestamp deleteDt;
	
	/**
	 * 최초 등록자 아이디
	*/
	private String frstRegisterId;
	
	/**
	 * 최초 등록 일시
	*/
	private java.sql.Timestamp frstRegistDt;
	
	/**
	 * 최종 변경자 아이디
	*/
	private String lastChangerId;
	
	/**
	 * 최종 변경 일시
	*/
	private java.sql.Timestamp lastChangeDt;
	
	/**
	 * 약관 상태
	*/
	private String stplatSttus;
	
	/**
	 * Grid 상태
	*/
	private String gridRowStatus;
	
	/**
	 * modalPageStatus 상태 
	*/
	private String modalPageStatus;

}
