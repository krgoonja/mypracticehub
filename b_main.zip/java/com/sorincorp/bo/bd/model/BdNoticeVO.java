package com.sorincorp.bo.bd.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import com.sorincorp.comm.model.CommonVO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * BdNoticeVO.java
 * @version
 * @since 2022. 8. 26.
 * @author srec0033
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class BdNoticeVO extends CommonVO {

	private static final long serialVersionUID = 6882956165304862133L;

	/**
	 * InsertAndUpdate</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface InsertAndUpdate {};

    /**
     * 공지사항 번호
    */
    private int noticeNo;

    /**
     * 문서 번호
    */
    private int docNo;

    /**
     * 공지사항 제목
    */
    @NotBlank(groups=InsertAndUpdate.class, message = "제목을 입력해 주세요.")
    @Size(groups=InsertAndUpdate.class, min=0, max=100, message = "제목은 100자 이하로 입력해 주세요.")
    private String noticeSj;

    /**
     * 공지사항 내용
    */
    @NotBlank(groups=InsertAndUpdate.class, message = "내용을 입력해 주세요.")
    @Size(groups=InsertAndUpdate.class, min=0, max=2000, message = "내용은 2000자 이하로 입력해 주세요.")
    private String noticeCn;

    /**
     * 공지사항 상단노출 여부
    */
    @NotBlank(groups=InsertAndUpdate.class, message = "공지사항 상단노출 여부를 선택해 주세요.")
    private String noticeUpendexpsrAt;

    /**
     * 공지사항 상단노출 시작일
    */
    private String noticeUpendexpsrBgnde;

    /**
     * 공지사항 상단노출 종료일
    */
    private String noticeUpendexpsrEndde;

    /**
     * 공지사항 메인팝업 여부
    */
    @NotBlank(groups=InsertAndUpdate.class, message = "공지사항 메인팝업 여부를 선택해 주세요.")
    private String noticeMainpopupAt;

    /**
     * 공지사항 긴급팝업 여부
    */
    @NotBlank(groups=InsertAndUpdate.class, message = "공지사항 긴급팝업 여부를 선택해 주세요.")
    private String emrgncyMainpopupAt;
    
    /**
     * 공지사항 메인팝업 시작일
    */
    private String noticeMainpopupBgnde;

    /**
     * 공지사항 메인팝업 종료일
    */
    private String noticeMainpopupEndde;

    /**
     * 공지사항 조회 수
     */
    private int noticeInqireCo;

    /**
     * FO 이미지 문서 번호
     */
    private Integer foImageDocNo;

    /**
     * MO 이미지 문서 번호
     */
    private Integer moImageDocNo;

    /**
     * 사용 여부
    */
    @NotBlank(groups=InsertAndUpdate.class, message = "사용 여부를 선택해 주세요.")
    private String useAt;

    /**
     * 삭제 여부
    */
    private String deleteAt;

    /**
     * 삭제 일시
    */
    private String deleteDt;

    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;

    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;

    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;

    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;

	/**
	 * Grid 상태
	 */
	private String gridRowStatus;

	/**
	 * modalPageStatus 상태
	 */
	private String modalPageStatus;

	/**
	 * 검색 날짜1
	 */
	private String searchDateFrom;

	/**
	 * 검색 날짜2
	 */
	private String searchDateEnd;

	/**
	 * 문서 번호 배열 - 프론트단에서 받아오는 값
	 */
	private int[] docNos;

	/**
	 * 삭제된 문서 번호 배열 - 프론트단에서 받아오는 값
	 */
	private int[] delNo;

	/**
	 * 순번
	 */
	private String rownum;
}
