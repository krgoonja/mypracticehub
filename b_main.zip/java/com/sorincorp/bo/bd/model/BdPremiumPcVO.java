package com.sorincorp.bo.bd.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class BdPremiumPcVO extends CommonVO {

	/**
	 *
	 */
	private static final long serialVersionUID = 7435360650166947685L;
	
    /**
     * 적용 일자
    */
    private String applcDe;

    /**
     * 무역 조건 코드
    */
    private String cmmrcCndCode;

    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;

    /**
     * 창고 운영 주체 코드
    */
    private String wrhousOperMbyCode;

    /**
     * 전환 프리미엄 금액
    */
    private double cnvrsPremiumAmount;

    /**
     * 비고
    */
    private String rm;

    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;

    /**
     * 삭제 여부
    */
    private String deleteAt;

    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;

    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;

    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;

    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;

    /**
     * 마지막 날짜(최근 날짜)
    */
    private String endDay;

    /**
     * 프리미엄 가격 상태
    */
    private String premiumPcSttus;


}
