package com.sorincorp.bo.bd.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class BdLgistCnterVO extends CommonVO {

	/******  JAVA VO CREATE : BD_WRHOUS_BAS(입찰_창고 기본)                                                                                  ******/
    /**
     * 창고 번호
    */
    private int wrhousNo;
    
    /**
     * 대분류 출고 권역 코드
    */
    private String lclsfDlivyDstrctCode;
    
    /**
     * 대분류 출고 권역 이름
    */
    private String lclsfDlivyDstrct;
    
    /**
     * 중분류 출고 권역 코드
    */
    private String mlsfcDlivyDstrctCode;
    
    /**
     * 대분류 출고 권역 이름
    */
    private String mlsfcDlivyDstrct;
    
    /**
     * 창고 코드
    */
    private String wrhousCode;
    
    /**
     * 창고 명
    */
    private String wrhousNm;
    
    /**
     * 운영 업체 코드
    */
    private String operEntrpsCode;
    
    /**
     * 운영 업체 명
    */
    private String operEntrpsNm;
    
    /**
     * 창고 우편 번호
    */
    private String wrhousPostNo;
    
    /**
     * 창고 도로명 주소
    */
    private String wrhousRnAdres;
    
    /**
     * 창고 도로명 주소 상세
    */
    private String wrhousRnAdresDetail;
    
    /**
     * 창고 담당자
    */
    private String wrhousCharger;
    
    /**
     * 창고 담당자 전화 번호
    */
    private String wrhousChargerTlphonNo;
    
    /**
     * 창고 계약 형태 코드
    */
    private String wrhousCntrctStleCode;
    
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    
    /**
     * 삭제 여부
    */
    private String deleteAt;
    
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    
   
    /**
     * 인도 조건 코드
    */
    private String delyCndCode;
    
    
    /**
     * 인도 조건 코드 10판별
    */
    private String delCode10;
    
    /**
     * 인도 조건 코드 20판별
    */
    
    private String delCode20;
    
    /**
     * 인도 조건 코드 30판별
    */
    private String delCode30;

    /**
     * 검색키워드
    */
    private String searchKeyword;
 
	/**
	 * 순번
	 */
	private String rownum;
	/**
	 * Grid 상태
	 */
	private String gridRowStatus;
	/**
	 * modalPageStatus 상태
	 */
	private String modalPageStatus;
	
	/**체크버튼*/
	private String checkBtn;
	
	/**인도조건 코드 추가 배열*/
	private String addDelyArr[];
	
	/**인도조건 코드 삭제 배열*/
	private String deleteDelyArr[];
	
	/**인도조건 코드 가지고있는 배열*/
	private String haveArr[];
	
 
}
