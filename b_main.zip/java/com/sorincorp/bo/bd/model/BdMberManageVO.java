package com.sorincorp.bo.bd.model;

import javax.validation.constraints.NotEmpty;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * BdMberManageVO.java
 *
 * @version
 * @since 2023. 06. 23.
 * @author srec0077
 */

@Data
@EqualsAndHashCode(callSuper = false)
@Validated
public class BdMberManageVO extends CommonVO {
 
	private static final long serialVersionUID = 7402433857088043650L;
	
	private String rownum;				
	
	/**
	 * 입찰 회원 목록 , 회원 정보 수정, 가입 승인 대기 구분 필드
	 */
	private String activeGrid;					
	/**
	 * 패찰 건 수 
	 */
	private int defCo;			
	/**
	 * 낙찰 건 수
	 */
	private int adjuCo;			
	
//-------------------------------------------------------------------------------------
	/**
	 * 입찰 업체 번호
	 */
	private String bidEntrpsNo;					 
	/**
	 * 입찰 회원 아이디
	 */
	private String bidMberId;
	/**
	 * 입찰 회원 비밀 번호
	 */
	private String bidMberSecretNo;
	/**
	 * 업체 명
	 */
	private String entrpsNm;
	/**
	 * 사업자 등록 번호
	 */
	private String bsnmRegistNo;
	/**
	 * 입찰 회원 이메일
	 */
	private String bidMberEmail;
	/**
	 * 휴대폰 번호
	 */
	private String moblphonNo2;
	/**
	 * 추가 항목
	 */
	private String aditIem;
	/**
	 * 외국 업체 여부
	 */
	private String frntnEntrpsAt;
	/**
	 * 대행 업체 명
	 */
	private String vrscEntrpsNm;
	/**
	 * 대행 사업자 등록 번호
	 */
	private String vrscBsnmRegistNo;
	/**
	 * 대행 입찰 회원 이메일
	 */
	private String vrscBidMberEmail;
	/**
	 * 대행 휴대폰 번호
	 */
	private String vrscMoblphonNo;
	/**
	 * 추가 항목2
	 */
	private String aditIem2;

	//------------------ 상태코드 ------------------
	/**
	 * 입찰 회원 상태 코드
	 */
    private String bidMberSttusCode;
    /**
     * 입찰 가입 승인 상태 코드
     */
	private String bidConfmSttusCode;
	/**
	 * 입찰 승인 상세 상태 코드
	 */
    private String bidConfmDetailSttusCode;
    //------------------ 상태코드 끝 ------------------

    /**
	 * 가입 승인 요청 일시
	 */
    private String etrConfmRequstDt;
    /**
     * 가입 숭인 처리 일시
     */
    private String etrConfmProcessDt;
    /**
     * 변경 승인 요청 일시
     */
    private String changeConfmRequstDt;
    /**
     * 변경 숭인 처리 일시
     */
    private String changeConfmProcessDt;
    /**
     * 입찰 회원 가입 일시
     */
    private String bidMberEtrDt;
    /**
     * 입찰 회원 차단 일시
     */
    private String bidMberIntrcpDt;
    /**
     * 입찰 회원 차단 내용
     */
    private String bidMberIntrcpCn;
    /**
	 * 이용 약관 동의 여부
	 */
	private String useStplatAgreAt;
	/**
	 * 이용 약관 동의 일시
	 */
	private String useStplatAgreDt;
	
	/**
	 * 개인 정보 3자 제공 동의 여부
	 */
	private String indvdlInfoThreemanProvdAgreAt;
	/**
	 * 개인 정보 3자 제공 동의 일시
	 */
	private String indvdlInfoThreemanProvdAgreDt;
	/**
	 * 개인 정보 처리 방침 동의 여부
	 */
	private String indvdlInfoProcessPolcyAgreAt;
	/**
	 * 개인 정보 처리 방침 동의 일시
	 */
	private String indvdlInfoProcessPolcyAgreDt;
	/**
	 * 마케팅 수신 동의 여부
	 */
	private String marktRecptnAgreAt;
	/**
	 * 마케팅 수신 동의 일시
	 */
	private String marktRecptnAgreDt;
	/**
	 * 회원 문자 수신 동의 여부
	 */
	private String mberChrctrRecptnAgreAt;
	/**
	 * 회원 문자 수신 여부 일시
	 */
	private String mberChrctrRecptnAgreDt;
	/**
	 * 회원 메일 수신 동의 여부
	 */
	private String mberEmailRecptnAgreAt;
	/**
	 * 회원 메일 수신 여부 일시
	 */
	private String mberEmailRecptnAgreDt;
	/**
	 * 회원 푸시 수신 동의 여부
	 */
	private String mberPushRecptnAgreAt;
	/**
	 * 회원 푸시 수신 여부 일시
	 */
	private String mberPushRecptnAgreDt;
	/**
	 * 투찰 취소 건수
	 */
	private String bddprCanclCo;
	/**
	 * 변경 핸드폰 번호
	 */
	private String changeMoblphonNo2;
	/**
	 * 변경 대형 핸드폰 번호
	 */
	private String changeVrscMoblphonNo;
	/**
	 * 변경 입찰 회원 비밀 번호
	 */
	private String changeBidMberSecretNo;
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	/**
	 * 최초 변경자 아이디
	 */
	@NotEmpty(message = "최초 등록자 아이디는 필수값입니다.")
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	
	/**
	 * 최초 변경자 아이디
	 */
	@NotEmpty(message = "최종 변경자 아이디는 필수값입니다.")
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;

	
	
	 /** 조회값 : 시작일 */
    private String searchDateFrom;

    /** 조회값 : 종료일 */
    private String searchDateEnd;

	/**
	 * 업체 전화 번호
	 */

	private String entrpsTlphonNo;
	/**
	 * 대행 전화 번호
	 */
	private String vrscTlphonNo;

	/**
	 * 사업자등록증 문서 번호1
	 */
	private String bsnmRegistDocNo1;

	/**
	 * 사업자등록증 문서 번호2
	 */
	private String bsnmRegistDocNo2;

	/**
	 * 우편 번호
	 */
	private String postNo;
	/**
	 * 주소
	 */
	private String adres;
	/**
	 * 상세 주소
	 */
	private String detailAdres;
	/**
	 * 도로명 주소
	 */
	private String rnAdres;
	/**
	 * 도로명 상세 주소
	 */
	private String rnDetailAdres;
	/**
	 * 국가 코드1
	 */
	private String nationCode1;
	/**
	 * 국가 코드2
	 */
	private String nationCode2;
	/**
	 * 국가 코드3
	 */
	private String nationCode3;
	/**
	 * 국가 코드4
	 */
	private String nationCode4;
	 
}
