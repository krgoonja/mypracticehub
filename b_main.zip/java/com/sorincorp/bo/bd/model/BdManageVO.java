package com.sorincorp.bo.bd.model;

import java.util.ArrayList;

import com.sorincorp.bo.it.model.BrandMgrVO;
import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class BdManageVO extends CommonVO  {
	/**
	 *
	 */
	private static final long serialVersionUID = 7435360650166947685L;
	/**
	 * 입찰 공고 아이디
	 */
	private String bidPblancId;
	/**
	 * 금속 코드
	 */
	private String metalCode;
	/**
	 * 금속 코드 명
	 */
	private String metalCodeNm;
	/**
	 * 브랜드 그룹 코드
	 */
	private String brandGroupCode;
    /**
     * 브랜드 그룹 코드 명
     */
    private String brandGroupCodeNm;
	/**
	 * 브랜드 코드
	 */
	private String brandCode;
	/**
	 * 브랜드 코드 명
	 */
	private String brandCodeNm;
	/**
	 * 아이템 순번
	 */
	private int itmSn;
	/**
	 * 아이템 명
	 */
	private String itmNm;
	/**
	 * 권역 대분류 코드
	 */
	private String dstrctLclsfCode;
    /**
     * 권역 대분류 코드 명
     */
    private String dstrctLclsfCodeNm;
	/**
	 * 입찰 중량
	 */
	private String bidWt;
	/**
	 * 허용 중량 비율
	 */
	private String permWtRate;
	/**
	 * 인도 조건 01 적용 여부
	 */
	private String delyCnd01ApplcAt;
	/**
	 * 인도 조건 01 기준 가격
	 */
	private String delyCnd01StdrPc;
	/**
	 * 인도 조건 01 프리미엄 가격
	 */
	private String delyCnd01PremiumPc;
	/**
	 * 인도 조건 02 적용 여부
	 */
	private String delyCnd02ApplcAt;
	/**
	 * 인도 조건 02 기준 가격
	 */
	private String delyCnd02StdrPc;
	/**
	 * 인도 조건 02 프리미엄 가격
	 */
	private String delyCnd02PremiumPc;
	/**
	 * 인도 조건 03 적용 여부
	 */
	private String delyCnd03ApplcAt;
	/**
	 * 인도 조건 03 기준 가격
	 */
	private String delyCnd03StdrPc;
	/**
	 * 인도 조건 03 프리미엄 가격
	 */
	private String delyCnd03PremiumPc;
	/**
	 * 인도 시작 일자
	 */
	private String delyBeginDe;
	/**
	 * 인도 종료 일자
	 */
	private String delyEndDe;
	/**
	 * 가격 지정 시작 일자
	 */
	private String pcAppnBeginDe;
	/**
	 * 가격 지정 종료 일자
	 */
	private String pcAppnEndDe;
	/**
	 * 가격 지정 방법 코드
	 */
	private String pcAppnMthCode;
    /**
     * 가격 지정 방법 코드 명
     */
    private String pcAppnMthCodeNm;
	/**
	 * 결제 통화 코드
	 */
	private String setleCrncyCode;
    /**
     * 결제 통화 코드 명
     */
    private String setleCrncyCodeNm;
	/**
	 * 결제 방법 코드
	 */
	private String setleMthCode;
    /**
     * 결제 방법 코드 명
     */
    private String setleMthCodeNm;
	/**
	 * 결제 기간 코드
	 */
	private String setlePdCode;
    /**
     * 결제 기간 코드 명
     */
    private String setlePdCodeNm;
	/**
	 * 기타 내용
	 */
	private String etcCn;
	/**
	 * 서류 선화 증권 제출 여부
	 */
	private String papersBlScritsPresentnAt;
	/**
	 * 서류 성적서 제출 여부
	 */
	private String papersScreofePresentnAt;
	/**
	 * 서류 포장 명세서 제출 여부
	 */
	private String papersPackngDtstmnPresentnAt;
	/**
	 * 서류 원산지 증명서 제출 여부
	 */
	private String papersOrgplceCrtfPresentnAt;
	/**
	 * 서류 CRIW 제출 여부
	 */
	private String papersCriwPresentnAt;
	/**
	 * 서류 수입 통관 면장 제출 여부
	 */
	private String papersImportEntrMyeonhedPresentnAt;
	/**
	 * 서류 최종 송장 제출 여부
	 */
	private String papersLastInvcPresentnAt;
	/**
	 * 서류 가송장 제출 여부
	 */
	private String papersPcinvcPresentnAt;
	/**
	 * 서류 분할 증명서 제출 여부
	 */
	private String papersPartitnCrtfPresentnAt;
	/**
	 * 투찰 시작 일시
	 */
	private String bddprBeginDt;
	/**
	 * 투찰 종료 일시
	 */
	private String bddprEndDt;
    /**
     * 투찰 일시
     * (YYYY.MM.DD HH:mm:ss~YYYY.MM.DD HH:mm:ss)
     */
    private String bddprPd;
	/**
	 * 투찰 취소 가능 여부
	 */
	private String bddprCanclPossAt;
	/**
	 * 투찰 취소 제한 일자
	 */
	private String bddprCanclLmttDe;
	/**
	 * 입찰 상태 코드
	 */
	private String bidSttusCode;
    /**
     * 입찰 상태 코드 (조회코드)
     */
    private String srchBidSttusCode;
    /**
     * 입찰 상태별 공고 수
     */
    private int bidSttusPblancCo;

    /**
     * 입찰 상태 코드 명
     */
    private String bidSttusCodeNm;
	/**
	 * 참여 업체 수량
	 */
	private String partcptnEntrpsQy;
	/**
	 * 관심 업체 수량
	 */
	private String intrstEntrpsQy;
	/**
	 * 전시 여부
	 */
	private String dspyAt;
	/**
	 * 공고 취소 여부
	 */
	private String pblancCanclAt;
	/**
	 * 개찰 일시
	 */
	private String opengDt;
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;
    /**
     * 투찰 기업 수
     */
    private int bddprEntrprsCo;
    /**
     * 최저 프리미엄 가격
     */
    private String lwetPremiumPc;
    /**
     * 입찰 단계 코드
     */
    private String bidStepCode;
    /**
     * 입찰 단계 코드 명
     */
    private String bidStepCodeNm;
    /**
     * 인도 기한 내용
     */
    private String delyPdCn;
    /**
     * 유찰 사유
     */
    private String rejectBidResn;
    /**
     * 검색(시작일)
     */
    private String searchDateFrom;
    /**
     * 검색(종료일)
     */
    private String searchDateEnd;

    /**
     * 대시보드
     **/
    private String bidWait;
    private String bidOn;
    private String bidEnd;
    private String bidCancel;


    /**
     * 입찰 문서
     */

    /**
    * 입찰 문서 순번
    */
    private String bidDocSn;

    /**
     * 입찰 문서 타입 코드
     */
    private String bidDocTyCode;

    /**
     * 입찰 문서 타입 코드 명
     */
    private String bidDocTyCodeNm;

    /**
     * 문서 번호
     */
    private String docNo;

    /**
     * 입찰 문서 심사 현황 코드
     */
    private String bidDocJdgmnSttusCode;

    /**
     * 입찰 문서 심사 현황 코드 명
     */
    private String bidDocJdgmnSttusCodeNm;

    /**
     * 재요청 대상 여부
     */
    private String rerequstTrgetAt;

    /**
     * 접수 일시
     */
    private String rceptDt;

    /**
     * 승인 일시
     */
    private String confmDt;


    //==============================공통_문서 기본=================================
    /**
     * 문서 파일 명
     */
    private String docFileNm;
    /**
     * 문서 파일 경로
     */
    private String docFileCours;
    /**
     * 문서 파일 실제 경로
     */
    private String docFileRealCours;
    /**
     * 문서 파일 크기
     */
    private String docFileMg;

    /**
     * 순번
     */
    private int rownum;



    //==============================수정 이력=================================
    /**
     * 입찰 공고 수정 이력 순번
     */
    private int bidUpdtHstSn;

    /**
     * 입찰 공고 수정 내용
     */
    private String bidUpdtCn;

    /**
     * 입찰 공고 수정 사유
     */
    private String bidUpdtResn;

    /**
     * 입찰 공고 수정 일시
     */
    private String bidUpdtDt;

    /**
     * 입찰 공고 수정자
     */
    private String bidUpdtId;


    //==============================투찰 업체 정보=================================

    /**
     * (투찰)입찰 업체 번호
     */
    private String bidEntrpsNo;

    /**
     * (투찰)입찰 업체 명
     */
    private String bidEntrpsNm;

    /**
     * (투찰)인도 조건 코드
     */
    private String delyCndCode;

    /**
     * (투찰)인도 조건 코드 명
     */
    private String delyCndCodeNm;

    /**
     * (투찰)인도 조건 기준 가격
     */
    private int delyCndStdrPc;

    /**
     * (투찰)전환 프리미엄 금액
     */
    private int cnvrsPremiumAmount;

    /**
     * (투찰)투찰 프리미엄 가격
     */
    private double bddprPremiumPc;

    /**
     * (투찰)투찰 최종 금액
     */
    private int bddprTotalAmount;
    
    /**
     * (투찰)투찰 중량
     */
    private int bddprWt;

    /**
     * (투찰)참여 동의 여부
     */
    private String partcptnAgreAt;

    /**
     * (투찰)투찰 일시
     */
    private String bddprDt;

    /**
     * (투찰)투찰 정상 여부
     */
    private String bddprNrmltAt;

    /**
     * (투찰)개찰 순위
     */
    private int opengRank;
    
    /**
     * (투찰)개찰 순위 내용
     */
    private String opengRankCn;

    /**
     * (투찰)낙찰 여부
     */
    private String scsbidAt;

    /**
     * (투찰)낙찰 일시
     */
    private String scsbidDt;

    /**
     * (투찰)취소 여부
     */
    private String canclAt;

    /**
     * (투찰)취소 일시
     */
    private String canclDt;

    /**
     * (투찰)취소 사유
     */
    private String canclResn;

    private String bddprFileConfm;

    private String popupSe;

    private String bidDoc01;
    private String bidDoc02;
    private String bidDoc03;
    private String bidDoc04;
    private String bidDoc05;
    private String bidDoc06;
    private String bidDoc07;
    private String bidDoc08;
    private String bidDoc09;
    private String docUseAt;
    

    private String bidDocArr[];

    /**
     * (서류)제출 여부
     */
    private String presentnAt;
    
    /**
     * (투찰)심사 상태 코드 
     **/
    private String jdgmnSttusCode;
    

    /*
     * OZ 리포트 변수
     */
    
    private String param1;
    private String param2;
    

    /**
     * Grid 상태
     */
    private String gridRowStatus;

    private ArrayList<BdManageVO> bddprEntrpsList;


    /**
     * 인도 조건 Seller/Buyer
     */
    private String delyCndSb;
    
    /**
     * 프리미엄 가격 Seller/Buyer
     */
    private String premiumPcSb;
    
    /**
     * 프리미엄 가격 코드
     */
    private String premiumPcCode;
    
    /**
     * 가격 지정 기간 Seller/Buyer
     */
    private String pcAppnPdSb;
    
    /**
     * 가격 지정 방법 Seller/Buyer
     */
    private String pcAppnMthSb;

	/**
	 * 브랜드 seller/buyer
	 */
	private String brandSb;

	/**
	 * 참여 업체 수량 조정
	 */
	private String partcptnEntrpsQyAdjst;

	/**
	 * 비고
	 */
	private String remark;


    
}
