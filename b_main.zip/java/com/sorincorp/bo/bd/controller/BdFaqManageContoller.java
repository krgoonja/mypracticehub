package com.sorincorp.bo.bd.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.bo.bd.model.BdFaqManageVO;
import com.sorincorp.bo.bd.service.BdFaqManageService;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping(value = "/bo/bdFaq")
@ComponentScan({"com.sorincorp.comm.*"})
public class BdFaqManageContoller {

	@Autowired
	private CommonCodeService cmnCodeService;

	@Autowired
	private CustomValidator customValidator;

	@Autowired
	private BdFaqManageService bdFaqManageService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	/**
	 * Faq 목록페이지 이동한다. (pageing)
	 * @param faqVO - 조회할 정보가 담긴 FaqVO
	 * @param model
	 * @return "faqList"
	 * @exception Exception
	 */
	@RequestMapping("/selectFaqListView")
	public String selectFaqListView(ModelMap model) throws Exception {
		try {
			/*
			 * 구분 : 공통, 주문, 결제, 배송, 회원            구분상세 : 회원가입, 회원탈퇴, 회원명의변경, 회원가입조건, 반품/취소접수
			 */
			Map<String, String> mainGubunCodeMap = cmnCodeService.getSubCodes("BID_FAQ_SE_CODE");
			model.addAttribute("mainGubunCodeMap", mainGubunCodeMap);

			return "bd/faqManageList";
		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}


	@PostMapping("/getFaqGubunDetailCodeList")
	@ResponseBody
	public Map<String, Object> getFaqGubunDetailCodeList(@RequestBody Map<String, String> codeSearchVo){
		Map<String, Object> returnMap = new HashMap<String, Object>();
		try {

			String faqGubunMainCode =codeSearchVo.get("faqGubunMainCode");
			String faqGubunDtlCode =codeSearchVo.get("faqGubunDtlCode");
			Map<String, String> subGubunCodeMap = cmnCodeService.getSubCodes(faqGubunMainCode);
			subGubunCodeMap.remove("@");             //Main Code 제외
			List<CommonCodeVO> dtlCodeList = new ArrayList<CommonCodeVO>();
			subGubunCodeMap.forEach((key, value) -> {
				CommonCodeVO codeVo = new CommonCodeVO();
				if(key.startsWith(faqGubunDtlCode)) {
					codeVo.setSubCode(key);
					codeVo.setCodeNm(value);
					dtlCodeList.add(codeVo);
				}
			});

			returnMap.put("subGubunCodeList", dtlCodeList);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return returnMap;
	}

	/**
	 * Faq 목록을 조회한다. (pageing)
	 * @param faqVO - 조회할 정보가 담긴 FaqVO
	 * @param model
	 * @return "faqList"
	 * @exception Exception
	 */
	@ResponseBody
	@RequestMapping("/selectFaqListData")
	public Map<String,Object> selectFaqListData(@RequestBody BdFaqManageVO faqVO) throws Exception {
		Map<String,Object> map = new HashMap<String, Object>();
		int totalDataCount        = bdFaqManageService.selectFaqListTotCnt(faqVO);
		List<BdFaqManageVO> faqList = bdFaqManageService.selectFaqList(faqVO);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", faqList);
		return map;
	}

	@PostMapping("/selectFaqForExcel")
	public ResponseEntity<?> selectFaqForExcel(@RequestBody BdFaqManageVO searchVO) throws Exception {
		searchVO.setRecordCountPerPage(10000000);
		List<BdFaqManageVO> dataList = bdFaqManageService.selectFaqList(searchVO);

		Map<String,Object> map = new HashMap<String, Object>();
		map.put("dataList", dataList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * Faq 등록 화면을 조회한다.
	 * @param faqVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "faqRegister"
	 * @exception Exception
	 */
	@PostMapping("/insertFaqView")
	public String insertFaqView(@RequestBody BdFaqManageVO vo, ModelMap model) throws Exception {
		try {
			Map<String, String> mainGubunCodeMap = cmnCodeService.getSubCodes("FAQ_JOB_SE_CODE");
			mainGubunCodeMap.remove("@");             //Main Code 제외
			model.addAttribute("mainGubunCodeMap", mainGubunCodeMap);
			model.addAttribute("faqVO", vo);

			List<FileDocVO> fileList = bdFaqManageService.selectAttachFiles(vo);

			model.put("faqNo", vo.getFaqNo());
			model.put("fileList", fileList);

			return "bd/faqManagePopRegister.modal";
		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	@SuppressWarnings("finally")
	@RequestMapping("/fileUploads")
	@ResponseBody
	public ResponseEntity<?> fileUploads(MultipartHttpServletRequest mRequest) throws Exception {
		Map<String,Object> fileMap = new HashMap<String,Object>();
		fileMap = bdFaqManageService.saveAttachFile(mRequest);
		log.debug(fileMap.toString());
		return new ResponseEntity<>(fileMap,HttpStatus.OK);
	}

	/**
	 * Faq를 등록한다.
	 * @param faqVO - 등록할 정보, 목록 조회조건 담긴 VO
	 * @param status
	 * @return "forward:/faqList"
	 * @exception Exception
	 */
	@PostMapping("/insertAndUpdateGridListData")
	@ResponseBody
	public ResponseEntity<?> insertFaq(	@RequestBody List<BdFaqManageVO> faqVoList
																, Model model
																, BindingResult bindingResult) throws Exception {

//		customValidator.validate(faqVoList, bindingResult, BdFaqManageVO.InsertAndUpdate.class);
//		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
//			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
//		}

		Map<String, Object> retVal = new HashMap<String, Object>();

		Account account= userInfoUtil.getAccountInfo();
		if(account == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		String userId = account.getId();
		int result = bdFaqManageService.insertAndUpdateGridDataList(faqVoList, userId);

		if (result > 0) {
			retVal.put("code", "S");
			retVal.put("msg", "");
		} else {
			retVal.put("code", "F");
			retVal.put("msg", "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * Faq를 삭제한다.
	 * @param faqVO - 삭제할 정보, 목록 조회조건 담긴 VO
	 * @param status
	 * @return
	 * @exception Exception
	 */
	@ResponseBody
	@PostMapping("/deleteGridListData")
	public ResponseEntity<?> deleteFaqs(@RequestBody List<BdFaqManageVO> faqVOList, SessionStatus status) throws Exception {
		/*
	 	 STEP 1. Session 사용자 등록
		*/
		Map<String, Object> retVal = new HashMap<String, Object>();

		Account account= userInfoUtil.getAccountInfo();
		if(account == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		String userId = account.getId();
		 /*
			STEP 2. Faq 삭제 실행
		 */
		bdFaqManageService.deleteFaqList(faqVOList, userId);
		retVal.put(RESULT, SUCCESS);
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@PostMapping("/deleteFaqAttachFile")
	@ResponseBody
	public ResponseEntity<?> deleteFaqAttachFile(@RequestBody BdFaqManageVO faqVo) throws Exception {
		// 리턴값
		Map<String, Object> retVal = new HashMap<String, Object>();

		Account account= userInfoUtil.getAccountInfo();
		if(account == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		String userId = account.getId();
		faqVo.setFrstRegisterId(userId);
		faqVo.setLastChangerId(userId);

		bdFaqManageService.deleteFaqAttachFile(faqVo);

		List<?> fileList = bdFaqManageService.selectAttachFiles(faqVo);
		if(fileList.size() == 0) {
			retVal.put("code", "S");
			retVal.put("msg", "");
		}else {
			retVal.put("code", "F");
			retVal.put("msg", "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}


}
