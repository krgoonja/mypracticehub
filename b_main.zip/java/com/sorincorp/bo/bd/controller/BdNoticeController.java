package com.sorincorp.bo.bd.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.bo.bd.model.BdNoticeVO;
import com.sorincorp.bo.bd.service.BdNoticeService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping(value = "/bo/bdNotice")
@ComponentScan({"com.sorincorp.comm.*"})
public class BdNoticeController {

	@Autowired
	private BdNoticeService bdNoticeService;

	@Autowired
	private CustomValidator customValidator;

	@Autowired
	private CommonCodeService cmnCodeService;

	/**
	 * <pre>
	 * 처리내용: 공지사항 목록 페이지를 조회한다.
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 4.			srec0033			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectNoticeList")
	public String selectNoticeList() {
		try {

			return "bd/noticeList";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 공지사항 목록을 조회한다.
	 * </pre>
	  @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectNoticeListData")
	public ResponseEntity<?> selectNoticeListData(@RequestBody BdNoticeVO searchVO, BindingResult bindingResult) throws Exception {

		if(searchVO.isValidation()) {
			customValidator.validate(searchVO, bindingResult);
		}

		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		Map<String,Object> map = new HashMap<String, Object>();
		int totalCount =  bdNoticeService.selectNoticeListTotcnt(searchVO);
		List<BdNoticeVO> noticeList = bdNoticeService.selectNoticeList(searchVO);

		map.put("totalDataCount", totalCount);
		map.put("dataList", noticeList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 공지사항 목록을 조회한다.(엑셀 다운로드)
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectNoticeListDataForExcel")
	public ResponseEntity<?> selectNoticeListDataForExcel(@RequestBody BdNoticeVO searchVO) throws Exception {
		Map<String,Object> map = new HashMap<String, Object>();
		searchVO.setRecordCountPerPage(10000000);
		List<BdNoticeVO> noticeList = bdNoticeService.selectNoticeList(searchVO);

		map.put("dataList", noticeList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 공지사항 등록 화면을 조회한다.
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertNoticeView")
	public String insertNoticeView(@RequestBody BdNoticeVO notice, ModelMap model) {
		try {
			List<FileDocVO> fileList = bdNoticeService.selectListNoticeAtchmnfl(notice);
			Map<String, FileDocVO> mainPopupFileList = bdNoticeService.selectMainPopupImageAtchmnfl(notice);

			model.addAttribute("noticeVO", notice);
			model.addAttribute("fileList", fileList);
			model.addAttribute("mainPopupFileList", mainPopupFileList);

			return "bd/noticePopRegister.modal";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 공지사항을 등록, 수정한다.
	 * </pre>
	*  @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param noticeVO
	 * @param bindingResult
	 * @param model
	 * @param status
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertAndUpdateGridDataList")
	@ResponseBody
	public ResponseEntity<?> insertAndUpdateGridDataList(@RequestBody List<BdNoticeVO> noticeList, BindingResult bindingResult) throws Exception {

		for (BdNoticeVO notice : noticeList) {
			if(notice.isValidation()) {
				customValidator.validate(notice, bindingResult, BdNoticeVO.InsertAndUpdate.class);
			}
		}

		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		bdNoticeService.insertAndUpdateGridDataList(noticeList);

		return new ResponseEntity<>(HttpStatus.OK);
	}

	/**
	 * 공지사항을 삭제한다.
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/deleteNoticeGridDataList")
	@ResponseBody
	public String deleteGridDataList(@RequestBody List<BdNoticeVO> noticeList) throws Exception {
		bdNoticeService.deleteGridDataList(noticeList);
		return "success";
	}

	/**
	 * <pre>
	 * 처리내용: 첨부파일을 업로드한다.
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param mrequest
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertFile")
	@ResponseBody
	public ResponseEntity<?> insertFile(MultipartHttpServletRequest mrequest) throws Exception {
		Map<String,Object> map = bdNoticeService.uploadFileDoc(mrequest);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 첨부파일을 삭제한다.
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/deleteFile")
	@ResponseBody
	public ResponseEntity<?> deleteFile(@RequestBody FileDocVO vo) throws Exception {
		Map<String,Object> map = bdNoticeService.deleteFileDoc(vo);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@RequestMapping("/insertNoticeImageFile")
	@ResponseBody
	public ResponseEntity<?> insertNoticeImageFile(MultipartHttpServletRequest mrequest) throws Exception {
		Map<String,Object> map = bdNoticeService.uploadNoticeImageFileDoc(mrequest);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}



}
