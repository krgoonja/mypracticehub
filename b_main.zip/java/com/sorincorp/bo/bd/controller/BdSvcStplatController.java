package com.sorincorp.bo.bd.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.bd.model.BdSvcStplatVO;
import com.sorincorp.bo.bd.service.BdSvcStplatService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * BdSvcStplatDbController.java
 * @version
 * @since 2023. 08. 01.
 * @author sein
 */
@Slf4j
@Controller
@RequestMapping("/bd/BdSvcstplat")
public class BdSvcStplatController {
	
	@Autowired
	private BdSvcStplatService bdStplatService; 
	
	@Autowired
	private CustomValidator customValidator;
	
	/**
	 * <pre>
	 * 처리내용: 서비스약관 목록(구매 입찰) 페이지를 조회한다.
	 * </pre>
	 * @date 2023. 08. 01.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 08. 01.			sein			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@RequestMapping("/selectBdSvcstplatList")
	public String selectBdSvcstplatList() {
		try {
			
			return "bd/bdSvcstplatList";
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 서비스 약관(구매 입찰) 데이터목록를 조회한다.
	 * </pre>
	 * @date 2023. 08. 01.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 08. 01.		sein					최초작성
	 * ------------------------------------------------
	 * @param stplat: 약관구분코드 3개에 따라 조회 (08 : 입찰 화원 이용 약관
											09 : 입찰 개인정보 수집 및 이용 동의
											10 : 마케팅 수신 동의
	 * @return 서비스 약관목록
	 * @throws Exception
	 */
	@PostMapping("/selectBdSvcstplatListData")
	@ResponseBody
	public Map<String, Object> selectBdSvcstplatListData(@RequestBody BdSvcStplatVO bdStplat) throws Exception {
		log.debug("selectBdSvcstplatListData ajax 조회 성공");
		Map<String,Object> map = new HashMap<String, Object>();
		
		int totalDataCount = bdStplatService.selectBdSvcStplatListTotcnt(bdStplat);
		List<BdSvcStplatVO> bdStplatList = bdStplatService.selectBdSvcStplatList(bdStplat); //약관구분코드로 (첫 조회 '08')조회
		
		map.put("totalDataCount", totalDataCount);
		map.put("dataList", bdStplatList);
		
		return map;
	}
	 
	/**
	 * <pre>
	 * 처리내용: 게시중인 약관을 조회한다.
	 * </pre>
	 * @date 2023. 08. 01.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 01.		sein					최초작성
	 * ------------------------------------------------
	 * @param bdStplat
	 * @return bdStplatIng
	 * @throws Exception
	 */
	@PostMapping("/selectBdSvcstplatIng")
	@ResponseBody 
	public BdSvcStplatVO selectBdSvcstplatIng(@RequestBody BdSvcStplatVO bdStplat) throws Exception {
		BdSvcStplatVO bdStplatIng = bdStplatService.selectBdSvcstplatIng(bdStplat);
		return bdStplatIng;
	}
	
	/**
	 * <pre>
	 * 처리내용: 서비스 약관(구매 입찰)을 상세 조회한다.
	 * </pre>
	 * @date 2023. 08. 01.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 08. 01.			sein				최초작성
	 * ------------------------------------------------
	 * @param bdStplat
	 * @return resultVO - 조회한 서비스 약관
	 * @throws Exception
	 */
	@PostMapping("/selectBdSvcstplat")
	@ResponseBody
	public BdSvcStplatVO selectBdSvcstplat(@RequestBody BdSvcStplatVO bdStplat) throws Exception {
		BdSvcStplatVO resultVO = bdStplatService.selectBdSvcStplat(bdStplat); //stplatNo로 조회
		return resultVO;
	}

	/**
	 * <pre>
	 * 처리내용: 그리드의 서비스약관 정보를 저장, 업데이트 한다.
	 * </pre>
	 * @date 2023. 08. 01.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 01.		sein					최초작성
	 * ------------------------------------------------
	 * @param bdStplat(status)
	 * @param bindingResult
	 * @return "success"
	 * @throws Exception
	 */
	@PostMapping("/insertAndUpdateGridDataList")
	@ResponseBody
	public ResponseEntity<?> insertAndUpdateGridDataList(@RequestBody BdSvcStplatVO bdStplat, BindingResult bindingResult) throws Exception {
		if(bdStplat.isValidation()) {
			customValidator.validate(bdStplat, bindingResult);
		}
		
		if (bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		bdStplatService.insertAndUpdateBdSvcstplatDataList(bdStplat);
		
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
