package com.sorincorp.bo.bd.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.bd.model.BdManageVO;
import com.sorincorp.bo.bd.model.BdPremiumPcVO;
import com.sorincorp.bo.bd.service.BdManageService;
import com.sorincorp.bo.bd.service.BdPremiumPcService;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.it.model.ItCmnCodeVO;
import com.sorincorp.bo.it.service.ItCmnCodeService;
import com.sorincorp.comm.brandcode.service.BrandCodeService;
import com.sorincorp.comm.brandgroupcode.service.BrandGroupCodeService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bo/bd")
public class BdManageController {

    @Autowired
    private BdManageService bdManageService;

    @Autowired
    private ItCmnCodeService itCmnCodeService;

    @Autowired
    private ItemCodeService itemCodeService;

    @Autowired
    private BrandGroupCodeService brandGroupCodeService;

    @Autowired
    private BrandCodeService brandCodeService;

    @Autowired
    private UserInfoUtil userInfoUtil;

    @Autowired
    private BdPremiumPcService bdPremiumPcService;

    @Autowired
    private CommonCodeService commonCodeService;

    private static String RESULT = "result";
    private static String ERRMSG = "errorMsg";
    private static String SUCCESS = "S";
    private static String FAIL = "F";

    @RequestMapping("/selectBidList")
    public String selectBidList(ModelMap model, BdManageVO bidVO) {

        try {

            List<BdManageVO> searchBidSttusList = bdManageService.selectSearchBidSttusList(bidVO); // 검색 영역 (상태)
            BdManageVO bdDashboardData = new BdManageVO();

            bdDashboardData = bdManageService.selectBidDashboardData(bidVO);

            model.addAttribute("searchBidSttusList", searchBidSttusList);
            model.addAttribute("bdDashboardData", bdDashboardData);

            return "bd/bdManageList";
        } catch (Exception e) {
            log.error(e.getMessage());
            HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
            return "error/503";
        }
    }

    @RequestMapping("/selectBdListAjax")
    @ResponseBody
    public Map<String, Object> selectBidListAjax(@RequestBody BdManageVO bidVO) throws Exception {

        Map<String, Object> map = new HashMap<String, Object>();

        int totalDataCount = bdManageService.selectBdListTotcnt(bidVO); // 입찰 공고 카운트
        List<BdManageVO> bdList = bdManageService.selectBdList(bidVO); // 입찰 공고 리스트
        List<BdManageVO> searchBidSttusList = bdManageService.selectSearchBidSttusList(bidVO); // 검색 영역 (상태)

        map.put("totalDataCount", totalDataCount);
        map.put("dataList", bdList);
        map.put("searchBidSttusList", searchBidSttusList);

        return map;
    }

    @RequestMapping("/insertBidView")
    public String insertBidView(ModelMap model, @RequestBody BdManageVO bidVO) {
        try {
            ItCmnCodeVO vo = new ItCmnCodeVO();
            vo.setMainCode("METAL_CODE");
            vo.setCodeDctwo("Y");
            vo.setUseAt("Y");
            // 메탈코드 리스트
            List<ItCmnCodeVO> metalCodeList = itCmnCodeService.selectCmnCodeList(vo);

            vo.setMainCode("DSTRCT_LCLSF_CODE");
            vo.setCodeDctwo("");
            vo.setUseAt("Y");
            // 권역 대분류 리스트
            List<ItCmnCodeVO> dstrctLclsfCodeList = itCmnCodeService.selectCmnCodeList(vo);
            
            BdManageVO bidData = new BdManageVO();

            if(bidVO.getPopupSe().equals("update")) {
                bidData = bdManageService.selectBidDetailData(bidVO);
                List<BdManageVO> bidFileUseList = bdManageService.selectBidFileUseList(bidVO);
                model.addAttribute("bidFileUseList", bidFileUseList);
              }

            model.addAttribute("bidData", bidData);
            model.addAttribute("popupSe", bidVO.getPopupSe());
            model.addAttribute("metalCodeList", metalCodeList);
            model.addAttribute("dstrctLclsfCodeList", dstrctLclsfCodeList);
            model.addAttribute("itemCodeList", itemCodeService.getItemFtrsProcessAtCodeList("", ""));
            model.addAttribute("brandGroupCodeList", brandGroupCodeService.getBrandGroupCodeList(""));
            model.addAttribute("brandCodeList", brandCodeService.getBrandCodeList(""));
            model.addAttribute("pcAppnMthCodeList", commonCodeService.getSubCodesToCommonCode("PC_APPN_MTH_CODE"));
            model.addAttribute("setleCrncyCodeList", commonCodeService.getSubCodesToCommonCode("CRNCY_CODE"));
            model.addAttribute("setleMthCodeList", commonCodeService.getSubCodesToCommonCode("SETLE_MTH_CODE"));
            model.addAttribute("setlePdCodeList", commonCodeService.getSubCodesToCommonCode("SETLE_PD_CODE"));
            model.addAttribute("bidDelyCndStdrPcList", commonCodeService.getSubCodesToCommonCode("BID_DELY_CND_STDR_PC"));


            // 프리미엄 가격 (전환프리미엄 가격관리 데이터)
            BdPremiumPcVO pcVO = new BdPremiumPcVO();
            pcVO.setPremiumPcSttus("ING"); // 최근 날짜 적용
            List<BdPremiumPcVO> premiumPcList = bdPremiumPcService.selectPremiumPcList(pcVO);
            model.addAttribute("premiumPcList", premiumPcList);

            return "bd/bdManagePopRegister.modal";

        } catch (Exception e) {
            log.error(e.getMessage());
            HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
            return "error/503";
        }
    }

    /**
     * 처리내용: 구매입찰 공고를 등록한다.
     *
     * @param BdManageVO
     * @return
     * @exception Exception
     */
    @RequestMapping("/insertBidData")
    @ResponseBody
    public ResponseEntity<Object> insertBidData(@RequestBody BdManageVO vo, BindingResult bindingResult, Model model)
            throws Exception {
        // validation check
        if (bindingResult.hasErrors()) {
            return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_GATEWAY); // ajax에서 error 호출
        }
        bdManageService.insertBidData(vo);
        // valid 에러 문제 없으면 true리턴
        return new ResponseEntity<>(true, HttpStatus.OK); // ajax success 데이터 전달
    }

    /**
     * 처리내용: 구매입찰 공고 상세정보를 조회한다.
     *
     * @param BdManageVO
     * @return
     * @exception Exception
     */
    @PostMapping("/selectBidDetaildata")
    public String selectBidDetaildata(@RequestBody BdManageVO bidVO, ModelMap model) throws Exception {
        BdManageVO selectBidDetailData = bdManageService.selectBidDetailData(bidVO);
        List<BdManageVO> selectBidFileList = bdManageService.selectBidFileList(bidVO);
        List<BdManageVO> selectBidUpdtList = bdManageService.selectBidUpdtList(bidVO);
        List<BdManageVO> selectBddprEntrpsList = bdManageService.selectBddprEntrpsList(bidVO);
        String scsbidEntrpsNo = "";
        
        if(selectBddprEntrpsList.size() > 0) {
            scsbidEntrpsNo = bdManageService.selectScsbidEntrpsNo(bidVO);
        }
           
        String bddprEndDt = selectBidDetailData.getBddprEndDt();
        String jdgmnSttusCode = bdManageService.selectJdgmnSttusCode(bidVO);
        
        // 공고 수정이력 (list)               
        List<BdManageVO> updtInfoList = bdManageService.selectBidUpdtInfo(bidVO);
        model.addAttribute("updtInfoList", updtInfoList);
        
        model.put("bidPblancId", bidVO.getBidPblancId());
        model.put("bddprEndDt", bddprEndDt);
        model.put("selectBidDetailData", selectBidDetailData);
        model.put("selectBidFileList", selectBidFileList);
        model.put("selectBidUpdtList", selectBidUpdtList);
        model.put("selectBddprEntrpsList", selectBddprEntrpsList);
        model.put("scsbidEntrpsNo", scsbidEntrpsNo);
        model.put("jdgmnSttusCode", jdgmnSttusCode);

        return "bd/bdManageDetail.modal";
    }
    
    @RequestMapping("/selectBddprListAjax")
    @ResponseBody
    public Map<String, Object> selectBddprListAjax(@RequestBody BdManageVO bidVO) throws Exception {
        
        Map<String, Object> map = new HashMap<String, Object>();

        List<BdManageVO> selectBddprEntrpsList = bdManageService.selectBddprEntrpsList(bidVO);
        int totalDataCount = selectBddprEntrpsList.size(); // 투찰 업체 카운트

        map.put("totalDataCount", totalDataCount);
        map.put("dataList", selectBddprEntrpsList);

        return map;
    }

    /**
     * 처리내용: 구매입찰 공고를 삭제한다.
     *
     * @param BdManageVO
     * @return
     * @exception Exception
     */
    @RequestMapping("/deleteBid")
    @ResponseBody
    public ResponseEntity<?> deleteBid(@RequestBody BdManageVO bidVO, BindingResult bindingResult ) throws Exception {

          // validation check
          if (bindingResult.hasErrors()) {
              return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_GATEWAY); // ajax에서 error 호출
          }

          bdManageService.deleteBid(bidVO); // 삭제

          return new ResponseEntity<>(true, HttpStatus.OK); // ajax success 데이터 전달
    }
    
    @PostMapping("/papersConfm")
    @ResponseBody
    public ResponseEntity<Object> updatePapersConfm(@RequestBody BdManageVO bidVO, BindingResult bindingResult, Model model) throws Exception {
        
        int result = 0;
        Map<String, Object> map = new HashMap<String, Object>();

        if (bindingResult.hasErrors()) { 
            return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
        }
        result = bdManageService.updatePapersConfm(bidVO);
        map.put("result", result);
        return new ResponseEntity<>(map, HttpStatus.OK);
    }
    
    /**
     * 처리내용: 업체 제출 서류 목록을 조회한다.
     *
     * @param BdManageVO
     * @return
     * @exception Exception
     */
    @PostMapping("/selectBidFileList")
    public String selectBidFileList(@RequestBody BdManageVO bidVO, ModelMap model) throws Exception {
        List<BdManageVO> selectBddprAtcList = bdManageService.selectBddprAtcList(bidVO);
        String bidDocTyCodeNm = commonCodeService.getCodeValue("BID_DOC_TY_CODE",bidVO.getBidDocTyCode());
        String jdgmnSttusCode = bdManageService.selectJdgmnSttusCode(bidVO);
        
        model.put("selectBddprAtcList", selectBddprAtcList);
        model.put("bidDocTyCodeNm", bidDocTyCodeNm);
        model.put("jdgmnSttusCode", jdgmnSttusCode);
        model.put("bidSttusCode", bidVO.getBidSttusCode());

        return "bd/bdBidFileListPop.modal";
    }
    
    /**
     * 처리내용: 공고 상태를 변경한다.
     *
     * @param BdManageVO
     * @return
     * @exception Exception
     */
    @RequestMapping("/updateBidSttusCode")
    @ResponseBody
    public ResponseEntity<Object> updateBidSttusCode(@RequestBody BdManageVO vo, BindingResult bindingResult, Model model)
            throws Exception {
        // validation check
        if (bindingResult.hasErrors()) {
            return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_GATEWAY); // ajax에서 error 호출
        }
        bdManageService.updateBidSttusCode(vo);
        bdManageService.updateJdgmnCoomptDt(vo);
        
        // valid 에러 문제 없으면 true리턴
        return new ResponseEntity<>(true, HttpStatus.OK); // ajax success 데이터 전달
    }
    
    @Transactional
    @RequestMapping("/updateBddprEntrpsInfo")
    @ResponseBody
    public ResponseEntity<Object> updateBddprEntrpsInfo(@RequestBody BdManageVO vo, Model model, BindingResult bindingResult) throws Exception {

        Map<String, Object> retVal = new HashMap<String, Object>();

        if(userInfoUtil.getAccountInfo() == null) {
            retVal.put(RESULT, FAIL);
            retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
            retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
            return new ResponseEntity<>(retVal, HttpStatus.OK);
        }

        int result = 0;
        result = bdManageService.updateBddprEntrpsInfo(vo.getBddprEntrpsList());

        if (result > 0) {
            retVal.put(RESULT, SUCCESS);
            retVal.put(ERRMSG, "");
        } else {
            retVal.put(RESULT, FAIL);
            retVal.put(ERRMSG, "");
        }

        return new ResponseEntity<>(retVal, HttpStatus.OK);
    }
    
    @RequestMapping("/selectDelyCndCodeList")
    @ResponseBody
    public ResponseEntity<Object> selectDelyCndCodeList(@RequestParam(value = "dstrctLclsfCode") String dstrctLclsfCode) throws Exception {

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("delyCndCodeList", bdManageService.selectDelyCndCodeList(dstrctLclsfCode));

        return new ResponseEntity<>(map, HttpStatus.OK);
    }

}
