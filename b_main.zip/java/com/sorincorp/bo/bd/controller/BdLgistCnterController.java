package com.sorincorp.bo.bd.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.bd.model.BdLgistCnterVO;
import com.sorincorp.bo.bd.service.BdLgistCnterService;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.lo.model.LgistCnterVO;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping(value = "/bo/bdLgist")
@ComponentScan({"com.sorincorp.comm.*"})
public class BdLgistCnterController {

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private BdLgistCnterService bdLgistCnterService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	/**
	 * <pre>
	 * 처리내용: 지정창고 보세목록페이지로 이동한다.
	 * </pre>
	 * @date 2022. 9. 5.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 5.			srec0072			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectLgistCnterList")
	public String selectLgistCnterList(ModelMap model) throws Exception {
		try {
			model.addAttribute("dstrctLclsfCodeList", commonCodeService.getSubCodes("DSTRCT_LCLSF_CODE"));
			model.addAttribute("dstrctMlsfcCodeList", commonCodeService.getSubCodes("DSTRCT_MLSFC_CODE"));

			return "bd/selectLgistCnterList";
		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}

	}

	/**
	 * <pre>
	 * 처리내용: 지정창고 보세목록을 등록페이지로 이동한다.
	 * </pre>
	 * @date 2022. 9. 5.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 5.			srec0072			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@PostMapping("/insertLgistCnterView")
	public String insertLgistCnterView(@RequestBody BdLgistCnterVO lco, ModelMap model) throws Exception{

		try {
			model.addAttribute("dstrctLclsfCodeList", commonCodeService.getSubCodes("DSTRCT_LCLSF_CODE"));
			model.addAttribute("dstrctMlsfcCodeList", commonCodeService.getSubCodes("DSTRCT_MLSFC_CODE"));
			model.addAttribute("lco",lco);

			return "bd/lgistCnterPopRegister.modal";
		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}



	/**
	 * <pre>
	 * 처리내용: 지정창고 보세목록을 조회한다.
	 * </pre>
	 * @date 2022. 9. 5.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 5.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param lco
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/selectLgistCnterListData")
	public Map<String,Object> selectLgistCnterListData(@RequestBody BdLgistCnterVO lco) throws Exception {

		Map<String,Object> map = new HashMap<String, Object>();

		List<BdLgistCnterVO>  dataList = bdLgistCnterService.selectLgistCnterList(lco);
		int totalDataCount = bdLgistCnterService.selectLgistCnterTotCnt(lco);

		map.put("totalDataCount", totalDataCount);
		map.put("dataList", dataList);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 보세창고목록 리스트를 엑셀로 다운로드 한다.
	 * </pre>
	 * @date 2022. 9. 6.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 6.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectLgistForExcel")
	public ResponseEntity<?> selectLgistForExcel(@RequestBody BdLgistCnterVO searchVO) throws Exception {
		searchVO.setRecordCountPerPage(10000000);
		List<BdLgistCnterVO> dataList = bdLgistCnterService.selectLgistCnterList(searchVO);

		Map<String,Object> map = new HashMap<String, Object>();
		map.put("dataList", dataList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 지정창고 보세목록을 등록 또는 수정한다.
	 * </pre>
	 * @date 2022. 9. 6.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 6.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param list
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertAndUpdateGridLgistCnterList")
	@ResponseBody
	public ResponseEntity<?> insertAndUpdateGridLgistCnterList(@RequestBody List<BdLgistCnterVO> list, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();
		Account account= userInfoUtil.getAccountInfo();
		String userId = "";

		if(account != null) {
			userId= account.getId();
		}

		int result = bdLgistCnterService.insertAndUpdateGridDataList(list, userId);

		if (result > 0) {
			retVal.put("code", "S");
			retVal.put("msg", "");
		} else {
			retVal.put("code", "F");
			retVal.put("msg", "");
		}

		return new ResponseEntity<>(retVal,HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 기존에 존재하는 물류_창고 정보 기본를 조회한다.
	 * </pre>
	 * @date 2022. 9. 6.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 6.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param lco
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/selectOriginalData")
	public Map<String,Object> selectOriginalData(@RequestBody BdLgistCnterVO lco) throws Exception{
		Map<String,Object> map = new HashMap<String, Object>();

		List<BdLgistCnterVO> originalDataList = bdLgistCnterService.selectOriginalData(lco);
		int orginalTotalDataCount = bdLgistCnterService.selectOriginalTotCnt(lco);
		map.put("dataList", originalDataList);
		map.put("totalDataCount", orginalTotalDataCount);
		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 기존 물류_창고 정보 기본에 있던 데이터를 조회하는 페이지를 연다.
	 * </pre>
	 * @date 2022. 9. 7.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 7.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/findOriginalInfo")
	public String findOriginalInfo(ModelMap model) throws Exception{
		try {
			model.addAttribute("dstrctLclsfCodeList", commonCodeService.getSubCodes("DSTRCT_LCLSF_CODE"));
			model.addAttribute("dstrctMlsfcCodeList", commonCodeService.getSubCodes("DSTRCT_MLSFC_CODE"));

			return "bd/findOriginalInfo.modal";
		}catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 지정 보세창고 관리 리스트를 삭제한다.
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param lco
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/deleteGridDataList")
	@ResponseBody
	public String deleteGridDataList(@RequestBody BdLgistCnterVO lco) throws Exception {
		bdLgistCnterService.deleteGridDataList(lco);
		return "success";
	}
}
