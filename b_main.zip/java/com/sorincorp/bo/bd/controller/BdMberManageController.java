
package com.sorincorp.bo.bd.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.bd.model.BdMberManageVO;
import com.sorincorp.bo.bd.service.BdMberManageService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * BidMberManageController.java
 *
 * @version
 * @since 2023. 06. 23.
 * @author srec0077
 */
@Slf4j
@Controller
@RequestMapping("/bo/bd")
@ComponentScan(basePackages = { "com.sorincorp.api.mb.service", "com.sorincorp.comm.util" })
public class BdMberManageController {
	
	@Autowired
	CommonCodeService commonCodeService ;
	@Autowired
	BdMberManageService bidMberManageService ;
	
	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";
		
	/**
	 * 
	 * <pre>
	 * 구매입찰 회원 목록 화면으로 이동한다.
	 * </pre>
	 * @date 2023. 06. 23.
	 * @author srec0077
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 06. 23.		 srec0077			최초작성
	 * ------------------------------------------------
	 * @param 	ModelMap model
	 * @return	String
	 * @throws 	Exception
	 */
	@RequestMapping("/selectBidMberList")
	public String selectBidMberList(ModelMap model) throws Exception {
		try {
			//입찰 회원 상태코드(공통)값 map으로 반환 
			model.addAttribute("bidMberSttusCodeList", commonCodeService.getSubCodes("BID_MBER_STTUS_CODE"));
			//정상 회원, 차단 회원, 가입 승인 대기 (갯수)
			model.addAttribute( "normalEntrpsCnt",bidMberManageService.selectNormalEntrpsCnt());
			model.addAttribute( "blockEntrpsCnt",bidMberManageService.selectBlockEntrpsCnt());
			model.addAttribute( "appEntrpsCnt",bidMberManageService.selectAppEntrpsCnt());
			
			return "bd/bdMberList";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	
 
	/**
	 * 
	 * <pre>
	 * 구매입찰 회원 리스트를 불러온다.
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	ModelMap model
	 * @return	Map<String, Object>
	 * @throws 	Exception
	 */
	@RequestMapping("/searchBidMberList")
	@ResponseBody
	public Map<String, Object> searchBidMberList(@RequestBody BdMberManageVO searchVO) throws Exception{
		HashMap<String, Object> map = new HashMap<>();
		
		//입찰 회원 목록
		List<BdMberManageVO> bdMberList = bidMberManageService.searchBidMberList(searchVO);
		int totalDataCount = bidMberManageService.searchBidMberListCnt(searchVO);
	
		
		System.out.println("bdMberList:"+bdMberList);
		System.out.println("totalDataCount:"+totalDataCount);
		
		map.put("dataList", bdMberList);
		map.put("totalDataCount", totalDataCount);

		return map;
	}
	/**
	 * 
	 * <pre>
	 * 구매입찰 회원 상세페이지 화면으로 이동한다.
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bdMberManageVO ModelMap model
	 * @return	String
	 * @throws 	Exception
	 */
	@RequestMapping("/bidMberListModal")
	public String bidMberListModal(@RequestBody BdMberManageVO bidMberManageVO, ModelMap model) {
		try {
			//select Mber정보
			BdMberManageVO bdMber = bidMberManageService.selectBidMber(bidMberManageVO);
			model.addAttribute("bdMber",  bdMber);
			//회원 분기 상태 가져오기
			model.addAttribute("activeGrid",  bidMberManageVO.getActiveGrid());
			//사업자 등록증 파일 경로 조회
			String bsnmFilePath = bidMberManageService.selectDocNo(bdMber.getBsnmRegistDocNo1());
			String vrscBsnmFilePath = bidMberManageService.selectDocNo(bdMber.getBsnmRegistDocNo2());
			model.addAttribute("bsnmFilePath",  bsnmFilePath);
			model.addAttribute("vrscBsnmFilePath",  vrscBsnmFilePath);
			
			return "bd/bdMberDetail.modal";

		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}
	}
	/**
	 * 
	 * <pre>
	 * 구매입찰 회원 차단하는 기능이다.
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bdMberManageVO
	 * @return	ResponseEntity<Object>
	 * @throws 	Exception
	 */
	@RequestMapping("/blockBidMember")
	@ResponseBody
	public ResponseEntity<Object> blockBidMember(@RequestBody BdMberManageVO bidMberManageVO ) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		
		try {
		
			//상태 확인 카운트
			int bdMberCnt = bidMberManageService.checkBlockBidMemberCnt(bidMberManageVO);
			//투찰중~심사이면 차단 불가능
			if(bdMberCnt > 0) {
				retVal.put(RESULT, FAIL);
				retVal.put(ERRMSG, "입찰 상태 중이거나, 마감 후 심사중인 상태입니다.(차단불가)");
				return new ResponseEntity<>(retVal, HttpStatus.OK);
			
			//회원 차단 가능
			}else {
				 
				bidMberManageService.blockBidMember(bidMberManageVO);
				retVal.put(RESULT, SUCCESS);
				retVal.put(ERRMSG, "정상적으로 차단되었습니다.");
				return new ResponseEntity<>(retVal, HttpStatus.OK);
			}
		
		//예외처리 쿼리오류
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "예외처리(쿼리) 오류가 발생햇습니다.");
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}
	}
	/**
	 * 
	 * <pre>
	 * 구매입찰 회원 차단해제하는 기능이다.
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bdMberManageVO
	 * @return	ResponseEntity<Object>
	 * @throws 	Exception
	 */
	@RequestMapping("/unBlockBidMember")
	@ResponseBody
	public ResponseEntity<Object> unBlockBidMember(@RequestBody BdMberManageVO bidMberManageVO) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		try {
			bidMberManageService.unBlockBidMember(bidMberManageVO);
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "정상적으로 차단이 해제되었습니다.");
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		//예외처리 쿼리오류
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "예외처리(쿼리) 오류가 발생햇습니다.");
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}
	}
	/**
	 * 
	 * <pre>
	 * 구매입찰 회원 가입,변경 승인하는 기능이다..
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bdMberManageVO
	 * @return	ResponseEntity<Object>
	 * @throws 	Exception
	 */
	@RequestMapping("/changeBidMember")
	@ResponseBody
	public ResponseEntity<Object> changeBidMember(@RequestBody BdMberManageVO bidMberManageVO) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		String str = bidMberManageVO.getActiveGrid().equals("app") ? "가입" : "변경";
		try {
			bidMberManageService.changeBidMember(bidMberManageVO);
			 
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, str+"이 승인되었습니다.");
			return new ResponseEntity<>(retVal, HttpStatus.OK);
			
		//예외처리 쿼리오류
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "예외처리(쿼리) 오류가 발생햇습니다.");
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}
	}
	/**
	 * 
	 * <pre>
	 * 구매입찰 회원 가입,변경 거절하는 기능이다.
	 * </pre>
	 * @date 2023. 07. 03.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 07. 03.		 sein			최초작성
	 * ------------------------------------------------
	 * @param 	BdMberManageVO bdMberManageVO
	 * @return	ResponseEntity<Object>
	 * @throws 	Exception
	 */
	@RequestMapping("/unChangeBidMember")
	@ResponseBody
	public ResponseEntity<Object> unChangeBidMember(@RequestBody BdMberManageVO bidMberManageVO ) throws Exception {
		Map<String, Object> retVal = new HashMap<String, Object>();
		String str = bidMberManageVO.getActiveGrid().equals("app") ? "가입" : "변경";
		try {
			
			bidMberManageService.unChangeBidMember(bidMberManageVO);
			
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, str+"이 거절 처리 되었습니다.");
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		//예외처리 쿼리오류
		}catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "예외처리(쿼리) 오류가 발생햇습니다.");
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}
	}
}
