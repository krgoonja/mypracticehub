package com.sorincorp.bo.bd.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.bo.bd.model.BdCnvrsPremiumVO;
import com.sorincorp.bo.bd.service.BdCnvrsPremiumService;
import com.sorincorp.bo.config.UserInfoUtil;
import com.sorincorp.bo.login.model.Account;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * BdPremiumPriceMngController.java
 *
 * @version
 * @since 2023. 7. 28.
 * @author bok3117
 */
@Slf4j
@Controller
@RequestMapping("/bo/bdPremium")
public class BdCnvrsPremiumController {
	
	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Autowired
    private CustomValidator customValidator;
	
	@Autowired
	private BdCnvrsPremiumService bdCnvrsPremiumService;
	
	/**
	 * <pre>
	 * 처리내용: 전환 프리미엄 가격 관리 페이지를 조회
	 * </pre>
	 * @date 2023. 7. 28.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 7. 28.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectCnvrsPremiumList")
	public String premiumPrice(ModelMap model) {
		try {
			model.addAttribute("cmmrcCndCodeList", commonCodeService.getSubCodes("CMMRC_CND_CODE"));
            model.addAttribute("dstrctLclsfCodeList", commonCodeService.getSubCodes("DSTRCT_LCLSF_CODE"));
            
			return "bd/selectCnvrsPremiumList";
		} catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 전환 프리미엄 가격 목록을 조회
	 * </pre>
	 * @date 2023. 7. 31.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 31.			bok3117				최초작성
	 * ------------------------------------------------
	 * @param bdCnvrsPremiumVO - 조회할 정보가 담긴 VO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectCnvrsPremiumListData")
	@ResponseBody
	public Map<String, Object> selectCnvrsPremiumListData(@RequestBody BdCnvrsPremiumVO bdCnvrsPremiumVO) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		List<BdCnvrsPremiumVO> bdCnvrsPremiumList = bdCnvrsPremiumService.selectCnvrsPremiumList(bdCnvrsPremiumVO);
		int totalDataCount = bdCnvrsPremiumService.selectCnvrsPremiumListTotcnt(bdCnvrsPremiumVO);
		
		map.put("dataList", bdCnvrsPremiumList);
		map.put("totalDataCount", totalDataCount);
		
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 전환 프리미엄 가격 등록, 수정 팝업창을 나타냄
	 * </pre>
	 * @date 2023. 8. 02.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 02.			bok3117				최초작성
	 * ------------------------------------------------
	 * @param bdCnvrsPremiumVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertCnvrsPremiumView")
    public String insertCnvrsPremiumView(@RequestBody BdCnvrsPremiumVO bdCnvrsPremiumVO, ModelMap model) throws Exception{
        try {
            model.addAttribute("cmmrcCndCodeList", commonCodeService.getSubCodes("CMMRC_CND_CODE"));
            model.addAttribute("dstrctMlsfcCodeList", commonCodeService.getSubCodes("DSTRCT_MLSFC_CODE"));
            model.addAttribute("modalPremiumVO", bdCnvrsPremiumVO);
            if(bdCnvrsPremiumVO.getModalPageStatus().equals("update")) {
                List<BdCnvrsPremiumVO> premiumList = bdCnvrsPremiumService.selectCnvrsPremiumList(bdCnvrsPremiumVO);

                for (BdCnvrsPremiumVO cnvrs : premiumList) {
                	String cnvrsLastChangeDt = cnvrs.getLastChangeDt();
                	String cnvrsFrstRegistDt = cnvrs.getFrstRegistDt();

                	SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS"); 
                    SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    
                    Date lastDate = inputFormat.parse(cnvrsLastChangeDt);
                    Date frstDate = inputFormat.parse(cnvrsFrstRegistDt);
                    String formatLastDate = outputFormat.format(lastDate);
                    String formatFrstDate = outputFormat.format(frstDate);
                    
                    cnvrs.setLastChangeDt(formatLastDate);
                    cnvrs.setFrstRegistDt(formatFrstDate);
                }
                model.addAttribute("premiumList", premiumList);
            }
            return "bd/cnvrsPremiumPopRegister.modal";
        } catch(Exception e) {
            log.error(e.getMessage());
            HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
            return "error/503";
        }
    }
	
	/**
	 * <pre>
	 * 처리내용: 전환 프리미엄 가격 등록 시 해당 적용일자에 등록된 데이터가 있는지 확인
	 * </pre>
	 * @date 2023. 8. 02.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 02.			bok3117				최초작성
	 * ------------------------------------------------
	 * @param bdCnvrsPremiumList
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/cnvrsPremiumCheck")
    @ResponseBody
    public ResponseEntity<?> insertView(@Valid @RequestBody BdCnvrsPremiumVO bdCnvrsPremiumVO, BindingResult bindingResult) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
        customValidator.validate(bdCnvrsPremiumVO, bindingResult);
        
        if(bindingResult.hasErrors()) {
            map.put("errorMessage","F");
            return new ResponseEntity<>(map, HttpStatus.OK);
        }
        
        try {
        	int totalDataCount = bdCnvrsPremiumService.selectCnvrsPremiumListTotcnt(bdCnvrsPremiumVO);
        	boolean isTotalDataCount = false;
        	
        	if(totalDataCount > 0) {
                isTotalDataCount = true;
            }
        	map.put("applcDe" , bdCnvrsPremiumVO.getApplcDe());
            map.put("isTotalDataCount", isTotalDataCount);
            return new ResponseEntity<>(map, HttpStatus.OK);
        	
        } catch(Exception e) {
            log.error(e.getMessage());
            HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
            return new ResponseEntity<>("error::cnvrsPremiumCheck.", HttpStatus.BAD_REQUEST);
        }
	}
	
	/**
	 * <pre>
	 * 처리내용: 전환 프리미엄 가격 등록 및 수정
	 * </pre>
	 * @date 2023. 8. 02.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 02.			bok3117				최초작성
	 * ------------------------------------------------
	 * @param bdCnvrsPremiumList
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertAndUpdateGridDataList")
    @ResponseBody
    public ResponseEntity<?> insertAndUpdateGridDataList(@RequestBody List<BdCnvrsPremiumVO> bdCnvrsPremiumList, BindingResult bindingResult) throws Exception {
		Account account= userInfoUtil.getAccountInfo();
		String userId = account.getId();
		int result = 0;
		
		try {
			result = bdCnvrsPremiumService.insertAndUpdateGridDataList(bdCnvrsPremiumList, userId);
            if(result > 0) {
                return new ResponseEntity<>(result,HttpStatus.OK);
            } else {
                return new ResponseEntity<>("ERROR", HttpStatus.BAD_REQUEST);
            }
		} catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
            return new ResponseEntity<>(ExceptionUtils.getStackTrace(e), HttpStatus.BAD_REQUEST);
        }
	}
    
	/**
	 * <pre>
	 * 처리내용: 전환 프리미엄 가격 목록을 엑셀 다운로드
	 * </pre>
	 * @date 2023. 8. 02.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 02.			bok3117				최초작성
	 * ------------------------------------------------
	 * @param bdCnvrsPremiumVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectCnvrsPremiumForExcel")
	public ResponseEntity<?> selectCnvrsPremiumForExcel(@RequestBody BdCnvrsPremiumVO bdCnvrsPremiumVO) throws Exception {
		try {
            List<BdCnvrsPremiumVO> dataList = bdCnvrsPremiumService.selectCnvrsPremiumList(bdCnvrsPremiumVO);
            Map<String,Object> map = new HashMap<String, Object>();
            map.put("dataList", dataList);
            
            return new ResponseEntity<>(map, HttpStatus.OK);
        } catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
            return new ResponseEntity<>("엑셀다운로드에 실패했습니다.", HttpStatus.BAD_REQUEST);
        }
	}
}
