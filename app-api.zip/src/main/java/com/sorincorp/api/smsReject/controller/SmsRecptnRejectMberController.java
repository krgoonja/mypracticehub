package com.sorincorp.api.smsReject.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.lo.comm.constant.LoCommConstant;
import com.sorincorp.api.smsReject.constant.SmsRecptnRejectMberConstant;
import com.sorincorp.api.smsReject.entity.SmsRecptnRejectMberEntity;
import com.sorincorp.api.smsReject.service.SmsRecptnRejectMberService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@Api(value = "정회원 정보 송신")
public class SmsRecptnRejectMberController {

	@Autowired
	private SmsRecptnRejectMberService smsRecptnRejectMberService;
	
	/**
	 * <pre>
	 * 처리내용: 회원 확인
	 * 회원일 경우 => 
	 * 아닐 경우 => 
	 * </pre>
	 * @date 2022. 06. 27.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 06. 27.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param entrpsMberInfoVO
	 * @param 
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/marktSmsReject")	
	@ApiOperation(value = "수신거부 처리", notes = "수신거부 처리")
	public ResponseEntity<?> marktSmsReject(HttpServletRequest request,
			@RequestBody Map<String,Object> requestData) throws Exception{
		log.debug("SmsRecptnRejectMberController::수신 거부 회원 Start");

		smsRecptnRejectMberService.marktSmsReject(requestData);
		
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new SmsRecptnRejectMberEntity(SmsRecptnRejectMberConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
		
	}
	
	
}