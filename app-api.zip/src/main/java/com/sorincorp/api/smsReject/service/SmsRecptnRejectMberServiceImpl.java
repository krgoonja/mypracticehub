package com.sorincorp.api.smsReject.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.smsReject.mapper.SmsRecptnRejectMberMapper;
import com.sorincorp.api.smsReject.model.SmsRecptnRejectMberVO;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.util.CryptoUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SmsRecptnRejectMberServiceImpl implements SmsRecptnRejectMberService {
	
	@Autowired
	private SmsRecptnRejectMberMapper smsRecptnRejectMberMapper;
	
	@Autowired
	private CommonService commonService;
	
	
	/**
	 * <pre>
	 * 처리내용: 회원 정보 확인
	 * 회원일 경우 => 수신거부 처리
	 * 아닐 경우 => 무시
	 * @date 2022. 6. 29.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 29.			hyunjin05			최초작성
	 * 2024. 2. 07.			hyunjin05			이력 적재 수정
	 * ------------------------------------------------
	 * @param smsRecptnRejectMberVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public void marktSmsReject(Map<String,Object> requestData) throws Exception {
		
		String rNumber = (String) requestData.get("rNumber");
		
		requestData.put("moblphonNo" ,CryptoUtil.encryptAES256(rNumber)); // 수신 번호 암호화 
		
		SmsRecptnRejectMberVO vo = new SmsRecptnRejectMberVO();
		
		List<Map<String,Object>> mberList = smsRecptnRejectMberMapper.selectMberList(requestData);
		
		for(Map<String, Object> map : mberList) {
			vo.setMberNo((String) map.get("mberNo"));
			
			
			smsRecptnRejectMberMapper.updateMaketInfo(vo);	// 문자 수신 = "N"
//			smsRecptnRejectMberMapper.insertMarketHst(vo);	// 마켓팅 테이블 변경이력 추가
			commonService.insertTableHistory("MB_MBER_MARKT_RECPTN_MEDIA_BAS", vo);
			
			if(vo.getMberNo().contains("P")) {	//기업회원				
				smsRecptnRejectMberMapper.updateMberInfo(vo);
//				smsRecptnRejectMberMapper.insertMberInfoHst(vo);
				commonService.insertTableHistory("MB_MBER_INFO_BAS", vo);
			}
			if(vo.getMberNo().contains("S")) {	//간편회원				
				smsRecptnRejectMberMapper.updateSimMberInfo(vo);
				smsRecptnRejectMberMapper.insertSimMberInfoHst(vo);
//				commonService.insertTableHistory("MB_SIMPL_MBER_INFO_BAS", vo);
			}
		}
		
	}	

}
