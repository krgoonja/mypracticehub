package com.sorincorp.api.smsReject.constant;

public class SmsRecptnRejectMberConstant {

	public static final String SUCCESS_RESULT_CODE = "200";
	
	public static final String SUCCESS_RESULT_MSG = "Success";	//OK
	
}
