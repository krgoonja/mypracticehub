package com.sorincorp.api.smsReject.service;

import java.util.Map;

public interface SmsRecptnRejectMberService {

	/**
	 * <pre>
	 * 처리내용: 회원 정보 확인 후 수신거부 처리
	 * @date 2022. 6. 29.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 29.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param smsRecptnRejectMberVO
	 * @return
	 * @throws Exception
	 */
	void marktSmsReject(Map<String,Object> requestData) throws Exception; 
 
}
