package com.sorincorp.api.smsReject.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SmsRecptnRejectMberEntity {
	
	/** 결과 코드  **/
	private String rspnsCode;
	
	/** 결과 메세지  **/
	private String rspnsMssage;

}
