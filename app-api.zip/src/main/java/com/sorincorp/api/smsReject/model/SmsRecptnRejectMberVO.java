package com.sorincorp.api.smsReject.model;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

@ApiModel("SMS 수신 거부 VO")
@Data
@EqualsAndHashCode(callSuper = false)
public class SmsRecptnRejectMberVO implements Serializable{

	/**
	 * serialVersion UID
	 */
	private static final long serialVersionUID = 1L;
	
	private String uNumber;
	
	private String rNumber;
	
	private String requestAt;
	
	/**
     * 회원 번호 (기업/간편)
     */
	private String mberNo;
	/**
     * 휴대 전화 번호 (기업/간편)
     */
	private String moblphonNo;
	/**
     * 마켓팅 수신 문자
     */
	private String marktRecptnSms;
	/**
     * 마켓팅 수신 이메일
     */
	private String marktRecptnEmail;
	/**
     * 마켓팅 수신 푸쉬
     */
	private String marktRecptnPush;
	/**
     * 마켓팅 수신동의 여부 (lastChangerId_for_marketTable)
     */
	private String advrtsRecptnAgreAt;
	/**
     * 마켓팅 수신동의 일시 (lastChangeDt_for_marketTable)
     */
	private String advrtsRecptnAgreDt;
	/**
     * 최조 변경자 아이디
     */
	private String lastChangerId;
	/**
     * 최조 변경 일시
     */
	private String lastChangeDt;
	
}
