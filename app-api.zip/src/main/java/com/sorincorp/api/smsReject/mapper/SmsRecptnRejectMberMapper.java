
/**
 *
 */
package com.sorincorp.api.smsReject.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.api.smsReject.model.SmsRecptnRejectMberVO;

/**
 * SmsRecptnRejectMberMapper.java
 * @version
 * @since 2022. 6. 29.
 * @author hyunjin05
 */
public interface SmsRecptnRejectMberMapper {

	/**회원 확인*/
	List<Map<String,Object>> selectMberList(Map<String,Object> requestData);
	
	/**마켓팅 수신 정보 -SMS 수정*/
	void updateMaketInfo(SmsRecptnRejectMberVO smsRecptnRejectMberVO);
	
	/**마켓팅 수신 변경 이력*/
	void insertMarketHst(SmsRecptnRejectMberVO smsRecptnRejectMberVO);
	
	/**기업회원 정보 수정*/
	void updateMberInfo(SmsRecptnRejectMberVO smsRecptnRejectMberVO);
	
	/**기업회원 변경 이력*/
	void insertMberInfoHst(SmsRecptnRejectMberVO smsRecptnRejectMberVO);
	
	/**간편회원 정보 수정*/
	void updateSimMberInfo(SmsRecptnRejectMberVO smsRecptnRejectMberVO);
	
	/**간편회원 변경 이력*/
	void insertSimMberInfoHst(SmsRecptnRejectMberVO smsRecptnRejectMberVO);
	
	
}
