package com.sorincorp.api.lo.model;

import java.util.List;

import lombok.Data;

@Data
public class InvntryWrhousngVO {
	List<InvntryWrhousngVO_02> blList;
}
