package com.sorincorp.api.lo.model;

import lombok.Data;

@Data
public class ExcclcInfoVO {
	/**
	 * 주문 번호
	 */
	private String orderNo;
	/**
	 * 취소교환반품 번호
	 */
	private String canclExchngRtngudNo;
    /**
     * 회원 번호
    */
    private String mberNo;
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 판매가
    */
    private long slepc;
    /**
     * 정산 공급가
    */
    private Long excclcSplpc;
    /**
     * 정산 부가세
    */
    private Long excclcVat;
    /**
     * 정산 금액
    */
    private Long excclcAmount;
    /**
     * 중량 정산 금액
    */
    private Long wtExcclcAmount;
    /**
     * 최종 변경자 아이디
     */
    private String lastChangerId;
    /**
     * 세금계산서 발행 여부
     */
    private boolean taxbillIssueYn;
    /**
     *  총 확정 주문 가격
     */
    private long totDcsnOrderPc;
    /**
     * 총 확정 공급가
     */
    private long totDcsnSplpc;
    /**
     * 구분 코드(데이터 등록시 사용)
     */
    private String seCode;
    /**
     * 환불 구분 코드
     */
    private String refndSeCode;
    /**
     * 결제 상태 코드
     */
    private String setleSttusCode;
    /**
     * 결제 방식 코드
    */
    private String setleMthdCode;
    /**
     * 추가 금액 유예 기간
     */
    private int aditAmountPostpnePd;
    /**
     * 미 결제 금액
    */
    private long unSetleAmount;
    /**
     * 미 상환 건수 (부분 출고 상환 관련)
     */
    private int nrdmpCnt;
    
    /**
     * 결제 번호
     */
    private String setleNo;
    
    /**
     * 추가 입금 금액(기존에 이월렛으로 입금 처리된 가격변동금의 총합)
     */
    private long aditRcpmnyAmount;
    
    /**
     * 최종 정산 금액
     */
    private long lastExcclcAmount;
}
