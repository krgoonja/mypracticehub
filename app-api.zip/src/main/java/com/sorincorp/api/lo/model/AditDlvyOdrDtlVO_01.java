package com.sorincorp.api.lo.model;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class AditDlvyOdrDtlVO_01 {
	/** 인터페이스 번호 **/
	@ApiModelProperty(hidden = true)
	private int intrfcNo;

	/**
	 * 인터페이스 순번
	 */
	@ApiModelProperty(hidden = true)
	String intrfcSn;


	/**
	 * OMS 주문 번호
	 */
	String omsOrderNo;
	/**
	 * EC 주문 번호
	 */
	String ecOrderNo;
	/**
	 * 배송 차수
	 */
	String dlvyOdr;
	/**
	 * 비용 리스트
	 */
	List<AditDlvyOdrDtlVO_02> ctList;

	/** 최초 등록자 아이디* **/
	private String frstRegisterId;

	/** 최종 변경자 아이디* **/
	private String lastChangerId;

}
