package com.sorincorp.api.lo.model;

import lombok.Data;

@Data
public class DlvyProgrsReqVO_02 {
	/**
	 * OMS 주문번호
	 */
	private String omsOrderNo;
	/**
	 * 배송 차수
	 */
	private String dlvyOdr;
	/**
	 * EC 주문번호
	 */
	private String ecOrderNo;
}
