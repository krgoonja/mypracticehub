package com.sorincorp.api.lo.model;

import java.util.List;

import lombok.Data;

@Data
public class CorprEntrpsVO {
	
	private List<CorprEntrpsDtlVO> corprEntrpsList;

}
