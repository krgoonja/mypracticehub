package com.sorincorp.api.lo.model;

import java.util.List;

import lombok.Data;

@Data
public class DlvyProgrsResVO {
	/**
	 * 주문 번호 리스트
	 */
	private List<DlvyProgrsResVO_02> orderNoList;
}