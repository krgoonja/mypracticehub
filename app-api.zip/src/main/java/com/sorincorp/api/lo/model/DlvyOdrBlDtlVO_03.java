package com.sorincorp.api.lo.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * DlvyOdrBlDtlVO_03.java
 * @version
 * @since 2021. 7. 23.
 * @author srec0032
 */
@Data
public class DlvyOdrBlDtlVO_03{
	/**
	 * 인터페이스 순번
	 */
	@ApiModelProperty(hidden = true)
	String intrfcSn;

	/**
	 * 배송 차수
	 */
	@ApiModelProperty(hidden = true)
	String dlvyOdr;

	/**
	 * BL 번호
	 */
	@ApiModelProperty(hidden = true)
	String blNo;

	/**
	 * 확정중량 BL 상세 순번
	 */
	@ApiModelProperty(hidden = true)
	String dcsnWtBlDetailSn;

	/**
	 * 번들 번호 (제조Lot번호)
	 */
	String bundleNo;
	/**
	 * 번들 WT(N.W)
	 */
	String bundleNetWt;
	/**
	 * 번들_WT(G.W)
	 */
	String bundleGrossWt;
	/**
	 * EC 주문 번호
	 */
	String ecOrderNo;
	/**
	 * EC 주문 순번
	 */
	String ecOrderSn;
	/**
	 * 상차 완료 일자
	 */
	String loadComptDe;
	/** 최초 등록자 아이디* **/
	private String frstRegisterId;

	/** 최종 변경자 아이디* **/
	private String lastChangerId;
}
