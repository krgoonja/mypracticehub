package com.sorincorp.api.lo.model;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@SuppressWarnings("serial")
@Data
public class SignInfoVO implements Serializable {
    /**
     * 인터페이스 순번
    */
	@ApiModelProperty(hidden = true)
    private long intrfcSn;
    /**
     * 인터페이스 번호
    */
	@ApiModelProperty(hidden = true)
    private long intrfcNo;
    /**
     * OMS 주문 번호
    */
    private String omsOrderNo;
    /**
     * 배송 차수
    */
    private int dlvyOdr;
    /**
     * 주문 번호
    */
    private String ecOrderNo;
    /**
     * 인도 인수 구분(기사:1, 고객:2)
    */
    private String delyUndtakeSe;
    /**
     * 서명 정보 파일 구분(서명:1, 파일:2)
    */
    private String fileSe;
    /**
     * 서명 정보 파일 URL
    */
    private String fileUrl;
    /**
     * 서명 정보 등록 일시
    */
    private String signInfoRegistDt;
    /**
     * 최초 등록자 아이디
    */
    @ApiModelProperty(hidden = true)
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    @ApiModelProperty(hidden = true)
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    @ApiModelProperty(hidden = true)
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    @ApiModelProperty(hidden = true)
    private String lastChangeDt;
    /**
     * 배송 수단 코드
    */
    @ApiModelProperty(hidden = true)
    private String dlvyMnCode;
 
}
