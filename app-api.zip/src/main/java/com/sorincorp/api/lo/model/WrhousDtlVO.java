package com.sorincorp.api.lo.model;

import lombok.Data;
@Data
public class WrhousDtlVO {

	/** 인터페이스 번호 **/
	private int intrfcNo;

	/** 창고 코드 **/
	private String wrhousCode;

	/** 창고 명 **/
	private String wrhousNm;

	/** 대분류 출고 권역 코드 **/
	private String lclsfDlivyDstrctCode;

	/** 중분류 출고 권역 코드 **/
	private String mlsfcDlivyDstrctCode;

	/** 창고 우편번호 **/
	private String wrhousZip;

	/** 창고 도로명 주소 **/
	private String wrhousRnAdres;

	/** 창고 도로명 주소 상세 **/
	private String wrhousRnAdresDetail;

	/** 운영 업체 명 **/
	private String operEntrpsNm;

	/** 운영 업체 코드 **/
	private String operEntrpsCode;

	/** 창고 담당자 **/
	private String wrhousCharger;

	/** 담당자 전화 번호 **/
	private String chargerTlphonNo;

	/** 인터페이스 구분 **/
	private String intrfcSe;

	/** 최초 등록자 아이디 **/
	private String frstRegisterId;

	/** 최종 변경자 아이디 **/
	private String lastChangerId;

	/** 비철 총 CAPA **/
	private String nfTotCapa;
	
	/** 비철 CAPA 사용 여부 **/
	private String capaUseAt;
	
}
