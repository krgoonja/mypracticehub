package com.sorincorp.api.lo.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.api.lo.model.*;

public interface LoService {

	void saveCorprEntrpsBas(CorprEntrpsVO corprEntrpsVo) throws Exception;

	void saveDlvyOdrBas(DlvyOdrBasVO dlvyOdrBasVo) throws Exception;

	void saveWrhousInfo(WrhousDtlVO wrhousDtlVo) throws Exception;

	void saveCoCmmnCd(CoCmmnCdVO coCmmnCdVo) throws Exception;

	void saveRltmDlvyOdr(RltmDlvyOdrVO rltmDlvyOdrVO) throws Exception;

	void saveAllInvntry(AllInvntryVO allInvntryVO) throws Exception;

	void saveAditDlvyOdr(AditDlvyOdrVO aditDlvyOdrVo) throws Exception;

	void saveDlvyOdrBl(DlvyOdrBlVO iF057VO) throws Exception;

	void saveDlvyTariff(DlvyTariffVO dlvyTariffVO) throws Exception;

	void saveDlvyProgrsSttus(DlvyProgrsSttusVO dlvyProgrsSttus) throws Exception;

	void saveInvntryMdat(InvntryMdatVO InvntryMdatVO) throws Exception;

	void saveInvntryBadn(InvntryBadnVO invntryBadnVO) throws Exception;

	void saveInvntryWrhousng(InvntryWrhousngVO invntryWrhousngVO) throws Exception;

	void saveDlvyOdrSignInfo(SignInfoVO dlvyOdrVO) throws Exception;

	InvntryInfoVO getRltmInvntryInfo(InvntryInfoRequstVO invntryInfoRequstVO) throws Exception;

	void sendDlvrgChangeInfo(String orderNo, String dlvrgNo, String dlvyRqestde, String sysSe) throws Exception;

	/**
	 * <pre>
	 * 처리내용: [물류관리 SOREC-IF-114] 자차배송일경우 차량정보 등록, 수정, 삭제 시 차량정보를 전송한다.
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoList
	 * @param sysSe
	 * @throws Exception
	 */
	void sendDlvyVhcleInfo(List<VhcleInfoVO> vhcleInfoList, String sysSe) throws Exception;

	void sendChangeDlvyMthd(String orginlOrderNo, String changeOrderNo) throws Exception;

	String sendSetleInfo(String orderNo, String orderType, String orderSttus, String orderSttusCode) throws Exception;

	List<DlvyProgrsResVO_03> getDlvyProgrs(List<String> orderNo) throws Exception;

	void saveWrhousStdrChcy(WrhousStdrChcyVO wrhousStdrChcyVO) throws Exception;

	String sendOrderSttusChange(OrderSttusChgInfoVO orderSttusChgInfoVO) throws Exception;
	
	Map<String, String> sendInvntryAsgnInfo(InvntryAsgnInfoVO invntryAsgnInfoVO) throws Exception;

	RltmCapaVO saveRltmLgistCnfirm(RltmCapaVO rltmCapaVO) throws Exception;

	Map<String, String> saveFlsOrderAsgnCanclCompt(FlsOrderAsgnCanclVO flsOrderAsgnCanclVO) throws Exception;

	/**
	 * <pre>
	 * 중량 변동금 자동 환불 처리
	 * </pre>
	 * @date 2022. 9. 19.
	 * @param orderNo
	 * @param intrfcId
	 * @param isRetry (재처리=true)
	 * @throws Exception
	 */
	void atmcRefndProcess(String orderNo, String intrfcId, boolean isRetry) throws Exception;

	/* 해당 주문 번호의 모든 BL에 대한 실재고여부 확인: 모두 실재고이면 TRUE, 하나라도 가재고이면 FALSE 리턴 */
	boolean isAllRealInvntry(String orderNo) throws Exception;
	
	/* 인터페이스 병렬로 인한 미정산된 주문 재처리 */
	 void executOrTaxBillError() throws Exception;

	void dispatChange(DlvyOdrDtlVO dlvyOdrDtl) throws Exception;
}
