package com.sorincorp.api.lo.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class AditDlvyOdrDtlVO_02 {
	/**
	 * 인터페이스 순번
	 */
	@ApiModelProperty(hidden = true)
	private String intrfcSn;
	/**
	 * 비용 순번
	 */
	@ApiModelProperty(hidden = true)
	private String ctSn;
	/**
	 * EC 주문 번호
	 */
	@ApiModelProperty(hidden = true)
	private String ecOrderNo;

	/**
	 * 배송 차수
	 */
	@ApiModelProperty(hidden = true)
	private String dlvyOdr;

	/**
	 * 공급 업체 코드
	 */
	private String suplyEntrpsCode;
	/**
	 * 비용 코드
	 */
	private String ctCode;
	/**
	 * 비용 공급가
	 */
	private String ctSplpc;
	/**
	 * 세율
	 */
	private String taxrt;
	/**
	 * 세목
	 */
	private String taxitm;

	/**
	 * 인터페이스 구분(I/U/D)
	 */
	private String intrfcSe;

	/** 최초 등록자 아이디* **/
	@ApiModelProperty(hidden = true)
	private String frstRegisterId;

	/** 최종 변경자 아이디* **/
	@ApiModelProperty(hidden = true)
	private String lastChangerId;
}
