package com.sorincorp.api.lo.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class CoCmmnCdDtlVO {

	/** 인터페이스 번호 **/
	@ApiModelProperty(hidden = true)
	private int intrfcNo;

	/**
	 * 코드(코드타입)
	 */
	private String code;
	/**
	 * 코드명
	 */
	private String codeNm;
	/**
	 * 디테일 코드
	 */
	private String detailCode;
	/**
	 * 디테일 코드
	 */
	private String detailCodeNm;
	/**
	 * 참조 1
	 */
	private String value1;
	/**
	 * 참조 2
	 */
	private String value2;
	/**
	 * 참조 3
	 */
	private String value3;
	/**
	 * 참조 4
	 */
	private String value4;
	/**
	 * 참조 5
	 */
	private String value5;
	/**
	 * 노출 순서
	 */
	private String displaySeq;
	/**
	 * 인터페이스 구분(I/U/D)
	 */
	private String intrfcSe;

	/** 최초 등록자 아이디* **/
	private String frstRegisterId;

	/** 최종 변경자 아이디* **/
	private String lastChangerId;
}
