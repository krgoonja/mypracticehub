package com.sorincorp.api.lo.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonIgnoreProperties({"intrfcSn", "intrfcNo", "frstRegisterId", "frstRegistDt", "lastChangerId", "lastChangeDt", "orderHoldingUseAt"})
public class SetleInfoVO {
    /**
     * 인터페이스 순번
    */
    private long intrfcSn;
    /**
     * 인터페이스 번호
    */
    private long intrfcNo;
    /**
     * 주문 번호
    */
    private String ecOrderNo;
    /**
     * 출고 요청 일자
    */
    private String dlvyRqestde;
    /**
     * 배송 요청 내용
    */
    private String orderMemo;
    /**
     * 관리자 배송 요청 내용
    */
    private String chargerMemo;
    /**
     * 주문 타입 코드
    */
    /* 1 : 주문, 2 : 취소, 3 : 반품, 4 : 교환 입고, 5 : 교환 출고 */
    private String orderTy;
    /**
     * 고객 주문 중량
    */
    private java.math.BigDecimal orderWt;
    /**
     * 총 번들 수량
    */
    private int bundleTotQy;
    /**
     * 결제 금액
    */
    private java.math.BigDecimal setleAmount;
    /**
     * 배송 수단 코드
    */
    private String dlvyMnCode;
    /**
     * 차량 그룹 코드
    */
    private String vhcleGroupCode;
    /**
     * 수취 업체 담당자 명
    */
    private String dlvrgCharger;
    /**
     * 수취 업체 휴대폰 번호
    */
    private String dlvrgCttpc;
    /**
     * 수취업체 담당자 이메일
    */
    private String ordrrEmail;
    /**
     * ERP 업체 코드
    */
    @JsonProperty(value = "tCode")
    private String tCode;
    /**
     * 주문 업체 명
    */
    private String entrpsnmKorean;
    /**
     * 배송지 번호
    */
    private int dlvrgNo;
    /**
     * 배송지 명
     */
    private String dlvrgNm;
    /**
     * 우편 번호
    */
    private String alocZip;
    /**
     * 주소
    */
    private String alocAdres;
    /**
     * 상세 주소
    */
    private String alocAdresDetail;
    /**
     * 도로명 주소
    */
    private String alocRnAdres;
    /**
     * 도로명 상세 주소
    */
    private String alocRnAdresDetail;
    /**
     * OMS 접수 번호
    */
    private String omsOrderRceptNo;
    /**
     * 당일 배송 여부(Y:당일배송, N:일반배송)
     */
    private String todayDlvyAt;
    /**
     * BL 리스트
     */
    private List<SetleInfoVO_02> blList;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    /**
     * 주문상태 (가주문"0", 실주문"1", 취소주문 "2")
    */
    private String orderSttus;
    /**
     * 주문 홀딩 사용 여부
    */
    private String orderHoldingUseAt;
}
