package com.sorincorp.api.lo.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class DlvyProgrsSttusVO {
	/** 인터페이스 번호 **/
	@ApiModelProperty(hidden = true)
	private int intrfcNo;

	/**
     * 인터페이스 순번
    */
	@ApiModelProperty(hidden = true)
    private long intrfcSn;

	/**
	 * OMS 주문 번호
	 */
	private String omsOrderNo;
	/**
	 * 배송 차수
	 */
	private String dlvyOdr;
	/**
	 * 진행 상태 코드
	 */
	private String progrsSttusCode;
	/**
	 * 진행 상태 등록 일시
	 */
	private String progrsSttusRegistDt;
	/**
	 * 상차 일시
	 */
	private String pickDate;
	/**
	 * 차량 번호
	 */
	private String vhcleNo;
	/**
	 * 차량 그룹 코드
	 */
	private String vhcleGroupCode;
	/**
	 * 기사 코드(자차일경우)
	 */
	private String articlCode;
	/**
	 * 기사 명
	 */
	private String articlNm;
	/**
	 * 기사 전화 번호
	 */
	private String articlTlphonNo;
	/**
	 * EC 주문 번호
	 */
	private String ecOrderNo;
	/**
	 * EC 배송 차수
	 */
	private String ecOdr;

	/** 최초 등록자 아이디* **/
	private String frstRegisterId;

	/** 최종 변경자 아이디* **/
	private String lastChangerId;

	/**
	 * 주문 상태코드
	 */
	@ApiModelProperty(hidden = true)
	private String orderSttusCode;

	/**
	 * 부분 출고 상환 여부
	 */
	@ApiModelProperty(hidden = true)
	private String partDlivyRepyAt;
}
