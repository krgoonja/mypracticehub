package com.sorincorp.api.lo.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class RltmCapaVO {
	/**
    * 인터페이스 순번
   */
	@ApiModelProperty(hidden = true)
	@JsonIgnore
   private long intrfcSn;
   /**
    * 인터페이스 번호
   */
	@ApiModelProperty(hidden = true)
	@JsonIgnore
   private long intrfcNo;
   /**
    * 창고 코드
   */
   private String wrhousCode;
   /**
    * 출고 요청 일자
   */
   private String dlvyRqestde;                                                                              
   /**
    * 비철 총 CAPA
   */
   @ApiModelProperty(hidden = true)
   @JsonIgnore
   private String nfTotCapa;
   /**
    * 비철 가용 CAPA
   */
   @ApiModelProperty(hidden = true)
   @JsonIgnore
   private String nfUsefulCapa;
   /**
    * 최초 등록자 아이디
   */
   @ApiModelProperty(hidden = true)
   @JsonIgnore
   private String frstRegisterId;
   /**
    * 최초 등록 일시
   */
   @ApiModelProperty(hidden = true)
   @JsonIgnore
   private java.sql.Timestamp frstRegistDt;
   /**
    * 최종 변경자 아이디
   */
   @ApiModelProperty(hidden = true)
   @JsonIgnore
   private String lastChangerId;
   /**
    * 최종 변경 일시
   */
   @ApiModelProperty(hidden = true)
   @JsonIgnore
   private java.sql.Timestamp lastChangeDt;
}
