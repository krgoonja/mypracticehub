package com.sorincorp.api.lo.comm.constant;

public class LoCommConstant {

	public static final String SUCCESS_RESULT_CODE = "200";

	public static final String ERROR_RESULT_CODE = "500";

	public static final String SUCCESS_RESULT_MSG = "Success";

	public static final String ERROR_RESULT_MSG = "Error";

	/* 물류 재처리 구분자 */
	public static final String LO_023_REAL_ORDER = "T";

	public static final String LO_023_FALSE_ORDER = "F";

	public static final String LO_125_REAL_ORDER = "O";

	public static final String LO_125_CANCEL_ORDER = "C";

	/* 주문 상태 코드 */
	public static final String ORDER_STTUS_CODE_REAL = "15";

	public static final String ORDER_STTUS_CODE_FALSE = "13";

	/* 시스템 구분 코드 */
	public static final String SYS_SE_FO = "1";

	public static final String SYS_SE_BO = "2";

	public static final String SYS_SE_BATCH = "3";

	/* 금속 코드 */
	public static final String METAL_NI = "8";  //니켈

	public static final String METAL_SN = "9";  //주석

}
