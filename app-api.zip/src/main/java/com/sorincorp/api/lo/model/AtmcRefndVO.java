package com.sorincorp.api.lo.model;

import java.io.Serializable;

import lombok.Data;

/**
 * 중량 변동금 자동 환불 재처리 VO
 * @author srec0051
 *
 */
@Data
public class AtmcRefndVO implements Serializable {

	private static final long serialVersionUID = -1084293719170068581L;

	/** 주문번호 */
	private String orderNo;
	/** 회원번호 (등록자, 수정자) */
	private String mberNo;
	/** 재처리여부 */
	private String retry;

}
