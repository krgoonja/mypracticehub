package com.sorincorp.api.lo.model;

import lombok.Data;

@Data
public class OrderDlvyMthdChangeVO {
	/**
	 * 주문 번호(취소된 주문 번호)
	 */
	private String orginlOrderNo;
	/**
	 * 배송 방식 변경 주문 번호
	 */
	private String changeOrderNo;
	/**
	 * 배송 방식 변경 OMS 접수 번호
	 */
	private String omsRceptNo;
	/**
     * 최초 등록자 아이디
    */
	private String frstRegisterId;
	/**
     * 최종 변경자 아이디
    */
	private String lastChangerId;
}
