package com.sorincorp.api.lo.model;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * DlvyOdrBlDtlVO_01.java
 * @version
 * @since 2021. 7. 23.
 * @author srec0032
 */
@Data
public class DlvyOdrBlDtlVO_01 {
	/**
	 * 인터페이스 순번
	 */
	@ApiModelProperty(hidden = true)
	String intrfcSn;

	/**
	 * 인터페이스 번호
	 */
	@ApiModelProperty(hidden = true)
	int intrfcNo;

	/**
	 * EC 주문 번호
	 */
	@ApiModelProperty(hidden = true)
	String ecOrderNo;

	/**
	 * OMS 주문 번호
	 */
	String omsOrderNo;
	/**
	 * 배송 차수
	 */
	String dlvyOdr;
	/**
	 * 출고 담당자
	 */
	String lvvhclCharger;
	/**
	 * 인수자
	 */
	String acptr;
    /**
     * 총 확정 중량
    */
    java.math.BigDecimal totDcsnWt;
    /**
     * 총 확정 주문 가격
    */
    long totDcsnOrderPc;
	/**
	 * BL 리스트
	 */
	List<DlvyOdrBlDtlVO_02> blList;

	/**
	 * 상차 완료 일자
	 */
	@ApiModelProperty(hidden = true)
	String loadComptDe;
	/**
	 * 마지막 차수 여부
	 */
	@ApiModelProperty(hidden = true)
	String lastOdrAt;
	/**
	 * 창고 코드
	 */
	@ApiModelProperty(hidden = true)
	String wrhousCode;

	@ApiModelProperty(hidden = true)
	String workType;

	/** 최초 등록자 아이디* **/
	private String frstRegisterId;

	/** 최종 변경자 아이디* **/
	private String lastChangerId;
}
