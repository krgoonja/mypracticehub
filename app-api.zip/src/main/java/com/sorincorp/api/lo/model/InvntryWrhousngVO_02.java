package com.sorincorp.api.lo.model;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class InvntryWrhousngVO_02 {
    /**
     * 인터페이스 순번
    */
	@ApiModelProperty(hidden = true)
    private long intrfcSn;
    /**
     * 인터페이스 번호
    */
	@ApiModelProperty(hidden = true)
    private long intrfcNo;
    /**
     * 창고 코드
    */
    private String wrhousCode;
    /**
     * 보관 위치
    */
    private String cstdyLc;
    /**
     * 권역 대분류 코드
    */
    private String lclsfDlivyDstrctCode;
    /**
     * 권역 중분류 코드
    */
    private String mlsfcDlivyDstrctCode;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 코드
    */
    private String itmCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 아이템 품목 한글
    */
    private String prductNm;
    /**
     * BL 번호
    */
    private String blNo;
    /**
     * LOT 수량
    */
    private int bundleQy;
    /**
     * NET 중량
    */
    private java.math.BigDecimal blNetWt;
    /**
     * GROSS 중량
    */
    private java.math.BigDecimal blGrossWt;
    /**
     * 도착 예정 시간
    */
    private String arvlPrearngeTime;
    /**
     * 입고 일시
    */
    private String wrhousngDt;
    /**
     * 주문 번호
    */
    private String ecOrderNo;
    /**
     * 주문 순번
    */
    private String ecOrderSn;
    /**
     * 구매 주문 번호
    */
    private String orderId;
    /**
     * 구매 라인 번호
    */
    private String orderDetailNo;
    /**
     * 통관 일시
    */
    private String entrDt;
    /**
     * 화물 관리 번호
    */
    private String frghtManageNo;
    /**
     * NET 평균 중량
     */
    @ApiModelProperty(hidden = true)
    private java.math.BigDecimal netAvrgWt;
    /**
     * GROSS 평균 중량
     */
    @ApiModelProperty(hidden = true)
    private java.math.BigDecimal grossAvrgWt;
    /**
     * 입고 구분
    */
    private String wrhousngSe;
    /**
     * OMS 주문 접수 번호(반품입고 및 교환입고시에만 제공)
     */
    private String omsOrderRceptNo;
    /**
     * 통관 여부
     */
    private String entrAt;
    /**
     * 번들 리스트
     */
    private List<InvntryWrhousngVO_03> bundleList;
    /**
     * AGENT ID
     */
    private String agentId;
    /**
     * 최초 등록자 아이디
    */
    @ApiModelProperty(hidden = true)
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    @ApiModelProperty(hidden = true)
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    @ApiModelProperty(hidden = true)
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    @ApiModelProperty(hidden = true)
    private String lastChangeDt;
}
