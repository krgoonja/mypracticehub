package com.sorincorp.api.lo.model;

import lombok.Data;

@Data
public class FlsOrderAsgnCanclVO {
	/**
     * 주문 번호
    */
    private String ecOrderNo;
    /**
     * OMS 접수 번호
    */
    private String omsOrderRceptNo;
}	
