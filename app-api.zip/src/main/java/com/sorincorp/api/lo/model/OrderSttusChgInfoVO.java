package com.sorincorp.api.lo.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class OrderSttusChgInfoVO {
   /**
     * 인터페이스 순번
    */
	@ApiModelProperty(hidden = true)
	@JsonIgnore
    private long intrfcSn;
   /**
     * 인터페이스 번호
    */
	@ApiModelProperty(hidden = true)
	@JsonIgnore
    private long intrfcNo;
   /**
     * 주문 번호
    */
    private String ecOrderNo;
   /**
     * OMS 접수 번호
    */
    private String omsOrderRceptNo;
   /**
     * 주문 상태
    */
    private String orderSttus;
   /**
     * 최초 등록자 아이디
    */
    @ApiModelProperty(hidden = true)
    @JsonIgnore
    private String frstRegisterId;
   /**
     * 최초 등록 일시
    */
    @ApiModelProperty(hidden = true)
    @JsonIgnore
    private java.sql.Timestamp frstRegistDt;
   /**
     * 최종 변경자 아이디
    */
    @ApiModelProperty(hidden = true)
    @JsonIgnore
    private String lastChangerId;
   /**
     * 최종 변경 일시
    */
    @ApiModelProperty(hidden = true)
    @JsonIgnore
    private java.sql.Timestamp lastChangeDt;
	 
}
