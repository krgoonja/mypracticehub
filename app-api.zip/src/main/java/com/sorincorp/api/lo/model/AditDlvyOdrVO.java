package com.sorincorp.api.lo.model;

import java.util.List;

import lombok.Data;

@Data
public class AditDlvyOdrVO {
	/**
	 * 주문 번호 리스트
	 */
	private List<AditDlvyOdrDtlVO_01> orderNoList;
}
