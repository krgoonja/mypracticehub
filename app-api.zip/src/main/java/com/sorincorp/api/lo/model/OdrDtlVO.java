package com.sorincorp.api.lo.model;

import java.text.DecimalFormat;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class OdrDtlVO {
	@JsonIgnore
	private DecimalFormat formatter;
	/**
     * 결제 방식 코드
    */
    private String setleMthdCode;
	/**
	 * 회원 번호
	 */
	private String mberNo;
	/**
	 * 주문 업체 명
	 */
	private String orderEntrpsNm;
	/**
	 * 주문자명
	 */
	private String ordrrNm;
	/**
	 * 주문자 휴대폰 번호
	 */
	private String ordrrMoblphonNo;
	/**
	 * 주문 일자
	 */
	private String orderDe;
	/**
	 * 문서 파일 실제 경로
	 */
	private String docFileRealCours;
	/**
	 * 주문 번호
	 */
	private String orderNo;
	/**
	 * 금속명
	 */
	private String metalNm;
	/**
	 * 상품명
	 */
	private String goodsNm;
	/**
	 * 브랜드 그룹명
	 */
	private String brandGroupNm;
	/**
	 * 상품 단가
	 */
	private String goodsUntpc;
	/**
	 * 총 실제 주문 중량
	 */
	private String totRealOrderWt;
	/**
	 * 주문 상품가격
	 */
	private String goodsPc;
	/**
	 * 총 확정 중량
	 */
	private String totDcsnWt;
	/**
	 * 총 확정 주문 가격
	 */
	private String totDcsnOrderPc;
	/**
	 * 정산 중량
	 */
	private String excclcWt;
	/**
	 * 정산 주문 가격
	 */
	private String excclcPc;
	/**
	 * 중량변동금
	 */
	private String wtChangegld;
	/**
	 * 예상 배송비
	 */
	private String expectDlvrf;
	/**
	 * 확정 배송비
	 */
	private String dcsnDlvyCt;
	/**
	 * 정산 배송비
	 */
	private String excclcDlvyCt;
	/**
	 * 공급가
	 */
	private String splpc;
	/**
	 * 부가세
	 */
	private String vat;
	/**
	 * 판매가
	 */
	private String slepc;
	/**
	 * E-Wallet 결제 금액
	 */
	private String ewalletAmount;
	/**
	 * 배송 방법
	 */
	private String dlvyMnNm;
	/**
	 * 주문자 이메일
	 */
	private String ordrrEmail;
	/**
	 * 정산 공급가
	 */
	private String excclcSplpc;
	/**
	 * 정산 부가세
	 */
	private String excclcVat;
	/**
	 * 정산 금액
	 */
	private String excclcAmount;
	/**
     * 추가 금액
     */
    private String aditAmount;
	/**
	 * 창고 이름
	 */
	private String wrhousNm;
	/**
	 * 창고 담당자
	 */
	private String wrhousCharger;
	/**
	 * 창고 담당자 전화번호
	 */
	private String wrhousChargerTlphonNo;
	/**
	 * 배송지 명
	 */
	private String dlvrgNm;
	/**
	 * 수취 업체 주소(지번)
	 */
	private String receptEntrpsAdres;
	/**
	 * 수취 업체 상세주소(지번)
	 */
	private String receptEntrpsDetailAdres;
	/**
	 * 배송지 주소
	 */
	private String dlvrgAdres;
	/**
	 * 수취 업체 담당자 명
	 */
	private String receptEntrpsChargerNm;
	/**
	 * 수취 업체 휴대폰 번호
	 */
	private String receptEntrpsMoblphonNo;
	/**
	 * 배송 요청 내용
	 */
	private String dlvyRequstCn;
	/**
	 * 회원 구분 코드
	 */
	private String mberSeCode;
	/**
	 * 디바이스 ID
	 */
	private String deviceId;
	/**
	 * 결제 방법
	 */
	private String payMethod;
	/**
     * 최초 결제 금액
    */
    private String frstSetleAmount;
    
    /**
     * 결제 예정 금액
     */
    private String setlePrearngeAmount;
    
    /**
     * 미 결제 금액
     */
    private String unSetleAmount;
    /**
     * 최초 결제예정일
     */
    private String frstSetlePrearngeDe;
    /**
     * 결제 예정일 (변경이후)
     */
    private String setlePrearngeDe;
    /**
     * 결제 예정일 (변경이전)
     */
    private String originSetlePrearngeDe;
    /**
     * 고객센터 전화번호
     */
    private String csTelNo;
    /**
     * 출고 요청 일자
    */
    private String dlivyRequstDe;
    /**
     * 판매 방식 코드
    */
    private String sleMthdCodeNm;
    /**
     * 판매 방식 코드
    */
    private String sleMthdCode;
    /**
     * 판매 방식 상세코드
    */
    private String sleMthdDetailCode;
    /**
     * 평균가 상품 단가 (가단가)
     */
    private String avrgpcGoodsUntpc;
    /**
     * 평균가 판매가
     */
    private String avrgpcSlepc;
    /**
     * 담보보증 미상환 금액
     */
    private String nrdmpAmount;
    /**
	 * 배송 차수
	 */
	private String dlvyOdr;
	/**
	 * 상환 완료 코드 (P: 미대상, N: 미완료, Y: 완료)
	 */
	private String repyComptCode;

	public OdrDtlVO() {
		this.formatter = new DecimalFormat("###,###");
	}

	public void setGoodsUntpc(int goodsUntpc) {
		this.goodsUntpc = formatter.format(goodsUntpc);
	}
	public void setGoodsPc(int goodsPc) {
		this.goodsPc = formatter.format(goodsPc);
	}
	public void setTotDcsnOrderPc(int totDcsnOrderPc) {
		this.totDcsnOrderPc = formatter.format(totDcsnOrderPc);
	}
	public void setExcclcPc(int excclcPc) {
		this.excclcPc = formatter.format(excclcPc);
	}
	public void setWtChangegld(int wtChangegld) {
		this.wtChangegld = formatter.format(wtChangegld);
	}
	public void setExpectDlvrf(int expectDlvrf) {
		if(expectDlvrf == 0) {
			this.expectDlvrf = "-";
		}else {
			this.expectDlvrf = formatter.format(expectDlvrf);
		}
	}
	public void setDcsnDlvyCt(int dcsnDlvyCt) {
		if(dcsnDlvyCt == 0) {
			this.dcsnDlvyCt = "-";
		}else {
			this.dcsnDlvyCt = formatter.format(dcsnDlvyCt);
		}
	}
	public void setExcclcDlvyCt(int excclcDlvyCt) {
		if(excclcDlvyCt == 0) {
			this.excclcDlvyCt = "-";
		}else {
			this.excclcDlvyCt = formatter.format(excclcDlvyCt);
		}
	}
	public void setSplpc(int splpc) {
		this.splpc = formatter.format(splpc);
	}
	public void setVat(int vat) {
		this.vat = formatter.format(vat);
	}
	public void setSlepc(int slepc) {
		this.slepc = formatter.format(slepc);
	}
	public void setEwalletAmount(int ewalletAmount) {
		this.ewalletAmount = formatter.format(ewalletAmount);
	}
	public void setExcclcSplpc(int excclcSplpc) {
		this.excclcSplpc = formatter.format(excclcSplpc);
	}
	public void setExcclcVat(int excclcVat) {
		this.excclcVat = formatter.format(excclcVat);
	}
	public void setExcclcAmount(int excclcAmount) {
		this.excclcAmount = formatter.format(excclcAmount);
	}
	public void setAditAmount(int aditAmount) {
		this.aditAmount = formatter.format(aditAmount);
	}
	public void setFrstSetleAmount(int frstSetleAmount) {
		this.frstSetleAmount = formatter.format(frstSetleAmount);
	}
	public void setSetlePrearngeAmount(int setlePrearngeAmount) {
		this.setlePrearngeAmount = formatter.format(setlePrearngeAmount);
	}
	public void setUnSetleAmount(int unSetleAmount) {
		if(unSetleAmount == 0) {
			this.unSetleAmount = "0";
		}else {
			this.unSetleAmount = formatter.format(unSetleAmount);
		}
	}
	public void setNrdmpAmount(int nrdmpAmount) {
		if(nrdmpAmount == 0) {
			this.nrdmpAmount = "0";
		}else {
			this.nrdmpAmount = formatter.format(nrdmpAmount);
		}
	}
}
