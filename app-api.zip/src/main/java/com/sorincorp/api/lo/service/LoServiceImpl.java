package com.sorincorp.api.lo.service;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.api.common.APICommConstant;
import com.sorincorp.api.credt.model.OrMrtggMdstrmRepyDtlVO;
import com.sorincorp.api.lo.comm.constant.LoCommConstant;
import com.sorincorp.api.lo.mapper.IfLoMapper;
import com.sorincorp.api.lo.mapper.LoMapper;
import com.sorincorp.api.lo.model.AditDlvyOdrDtlVO_01;
import com.sorincorp.api.lo.model.AditDlvyOdrDtlVO_02;
import com.sorincorp.api.lo.model.AditDlvyOdrVO;
import com.sorincorp.api.lo.model.AllInvntryVO;
import com.sorincorp.api.lo.model.AllInvntryVO_02;
import com.sorincorp.api.lo.model.ChangeDlvyMthdVO;
import com.sorincorp.api.lo.model.ChangeDlvyMthdVO_02;
import com.sorincorp.api.lo.model.CoCmmnCdDtlVO;
import com.sorincorp.api.lo.model.CoCmmnCdVO;
import com.sorincorp.api.lo.model.CorprEntrpsDtlVO;
import com.sorincorp.api.lo.model.CorprEntrpsVO;
import com.sorincorp.api.lo.model.DlvrgChangeVO;
import com.sorincorp.api.lo.model.DlvyOdrBasVO;
import com.sorincorp.api.lo.model.DlvyOdrBlDtlVO_01;
import com.sorincorp.api.lo.model.DlvyOdrBlDtlVO_02;
import com.sorincorp.api.lo.model.DlvyOdrBlDtlVO_03;
import com.sorincorp.api.lo.model.DlvyOdrBlVO;
import com.sorincorp.api.lo.model.DlvyOdrDtlVO;
import com.sorincorp.api.lo.model.DlvyProgrsReqVO;
import com.sorincorp.api.lo.model.DlvyProgrsReqVO_02;
import com.sorincorp.api.lo.model.DlvyProgrsResVO;
import com.sorincorp.api.lo.model.DlvyProgrsResVO_02;
import com.sorincorp.api.lo.model.DlvyProgrsResVO_03;
import com.sorincorp.api.lo.model.DlvyProgrsSttusVO;
import com.sorincorp.api.lo.model.DlvyTariffVO;
import com.sorincorp.api.lo.model.DlvyVhcleVO;
import com.sorincorp.api.lo.model.DlvyVhcleVO_02;
import com.sorincorp.api.lo.model.DlvyVhcleVO_03;
import com.sorincorp.api.lo.model.ExcclcInfoVO;
import com.sorincorp.api.lo.model.FlsOrderAsgnCanclVO;
import com.sorincorp.api.lo.model.InvntryAsgnInfoVO;
import com.sorincorp.api.lo.model.InvntryBadnVO;
import com.sorincorp.api.lo.model.InvntryBadnVO_02;
import com.sorincorp.api.lo.model.InvntryInfoRequstVO;
import com.sorincorp.api.lo.model.InvntryInfoVO;
import com.sorincorp.api.lo.model.InvntryMdatVO;
import com.sorincorp.api.lo.model.InvntryRecoverVO;
import com.sorincorp.api.lo.model.InvntryWrhousngVO;
import com.sorincorp.api.lo.model.InvntryWrhousngVO_02;
import com.sorincorp.api.lo.model.InvntryWrhousngVO_03;
import com.sorincorp.api.lo.model.OdrDtlVO;
import com.sorincorp.api.lo.model.OdrDtlVO_02;
import com.sorincorp.api.lo.model.OrSetleBasVO;
import com.sorincorp.api.lo.model.OrderDlvyMthdChangeVO;
import com.sorincorp.api.lo.model.OrderNoDtlVO;
import com.sorincorp.api.lo.model.OrderSttusChgInfoVO;
import com.sorincorp.api.lo.model.RltmCapaVO;
import com.sorincorp.api.lo.model.RltmDlvyOdrDtlVO;
import com.sorincorp.api.lo.model.RltmDlvyOdrVO;
import com.sorincorp.api.lo.model.SetleInfoVO;
import com.sorincorp.api.lo.model.SetleInfoVO_02;
import com.sorincorp.api.lo.model.SetleInfoVO_03;
import com.sorincorp.api.lo.model.SetleInfoVO_04;
import com.sorincorp.api.lo.model.SignInfoVO;
import com.sorincorp.api.lo.model.VhcleInfoVO;
import com.sorincorp.api.lo.model.WrhousDtlVO;
import com.sorincorp.api.lo.model.WrhousStdrChcyVO;
import com.sorincorp.api.or.model.OrOrderBasVO;
import com.sorincorp.api.taxBill.comm.constant.TaxBillCommConstant;
import com.sorincorp.api.taxBill.model.TaxBillRequestVO;
import com.sorincorp.api.taxBill.service.TaxBillService;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.btb.comm.BtoBConstants;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;
import com.sorincorp.comm.btb.model.BtoBReqEntity;
import com.sorincorp.comm.btb.model.BtoBResEntity;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.invntry.service.InvntrySttusService;
import com.sorincorp.comm.message.model.AppPushQueueVO;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.mapper.CommPrvsnlOrderMapper;
import com.sorincorp.comm.order.model.CommPrvsnlOrderVO;
import com.sorincorp.comm.order.service.CommAvrgpcOrderService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.comm.wrhouscode.service.WrhousCodeService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LoServiceImpl implements LoService {

    /** ewallet 주문 url **/
    @Value("${api.ewallet.order.url}")
    private String ewalletOrderUrl;

    /** 세금계산서 url **/
    @Value("${api.taxbill.url}")
    private String taxbillUrl;

    @Value("${api.ewallet.timeout}")
    private int ewalletTimeoutsec;

    @Value("${appPush.domain}")
    private String appPushDomain;

    @Value("${credit.mrtgg.url}")
    private String mrtggTrnsmisUrl;

    @Autowired
    private LoMapper loMapper;

    @Autowired
    private IfLoMapper ifLoMapper;
    
    @Autowired
	private CommPrvsnlOrderMapper commPrvsnlOrderMapper;

    @Autowired
    private AssignService assignService;

    @Autowired
    private WrhousCodeService wrhousCodeService;

    @Autowired
    private InvntrySttusService invntrySttusService;

    @Autowired
    private MailService mailService;

    @Autowired
    private SMSService smsService;
    
    /** 공통 서비스 */
    @Autowired
    private CommonService commonService;

    @Autowired
	private CommonCodeService commonCodeService;

    @Autowired
    private CommAvrgpcOrderService commAvrgpcOrderService;

    @Autowired
    private TaxBillService taxbillService;

    @Autowired
    private HttpClientHelper httpClientHelper;

    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public void saveCorprEntrpsBas(CorprEntrpsVO corprEntrpsVo) throws Exception {

        String intrfc_code = "SOREC-IF-004";

        /** 통합 로그 INSERT **/
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, corprEntrpsVo);

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
            /** 서비스 로직(interface table insert) **/
            for (CorprEntrpsDtlVO corprEntrpsDtl : corprEntrpsVo.getCorprEntrpsList()) {
                corprEntrpsDtl.setIntrfcNo(btbLogVo.getIntrfcNo());

                /* 사용자 등록 */
                corprEntrpsDtl.setFrstRegisterId(intrfc_code);
                corprEntrpsDtl.setLastChangerId(intrfc_code);

                ifLoMapper.insertIfLoCorprEntrpsBas(corprEntrpsDtl);
            }

            /** 서비스 로직(원본/원복이력 table insert) **/
            for (CorprEntrpsDtlVO corprEntrpsDtl : corprEntrpsVo.getCorprEntrpsList()) {
                /* 사용자 등록 */
                corprEntrpsDtl.setFrstRegisterId(intrfc_code);
                corprEntrpsDtl.setLastChangerId(intrfc_code);

                loMapper.insertLoCorprEntrpsBas(corprEntrpsDtl);
                loMapper.insertLoCorprEntrpsBasHst(corprEntrpsDtl);
            }

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }

    }

    @Override
    public void saveDlvyOdrBas(DlvyOdrBasVO dlvyOdrBasVo) throws Exception {

        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-009";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, dlvyOdrBasVo);

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
            /** 서비스 로직(interface table insert) **/
            for (OrderNoDtlVO orderNoDtl : dlvyOdrBasVo.getOrderNoList()) {
                for (DlvyOdrDtlVO dlvyOdrDtl : orderNoDtl.getDlvyOdrList()) {
                    dlvyOdrDtl.setEcOrderNo(orderNoDtl.getEcOrderNo());
                    dlvyOdrDtl.setOmsOrderNo(orderNoDtl.getOmsOrderNo());
                    dlvyOdrDtl.setOrderSnJson(objectMapper.writeValueAsString(dlvyOdrDtl.getOrderSnList()));
                    dlvyOdrDtl.setIntrfcNo(btbLogVo.getIntrfcNo());
                    /* 사용자 등록 */
                    dlvyOdrDtl.setFrstRegisterId(intrfc_code);
                    dlvyOdrDtl.setLastChangerId(intrfc_code);

                    if (StringUtils.isNotBlank(dlvyOdrDtl.getArticlTlphonNo())) {
                        dlvyOdrDtl.setArticlTlphonNo(CryptoUtil.encryptAES256(dlvyOdrDtl.getArticlTlphonNo())); // 암호화
                    }

                    ifLoMapper.insertIfLoCaralcInfoBas(dlvyOdrDtl);
                }
            }

            /** 서비스 로직(원본/원복이력 table insert) **/
            for (OrderNoDtlVO orderNoDtl : dlvyOdrBasVo.getOrderNoList()) {
                for (DlvyOdrDtlVO dlvyOdrDtl : orderNoDtl.getDlvyOdrList()) {
                    dlvyOdrDtl.setEcOrderNo(orderNoDtl.getEcOrderNo());
                    dlvyOdrDtl.setOmsOrderNo(orderNoDtl.getOmsOrderNo());
                    /* 사용자 등록 */
                    dlvyOdrDtl.setFrstRegisterId(intrfc_code);
                    dlvyOdrDtl.setLastChangerId(intrfc_code);

                    /* [EC 배송 차수] 적용여부 체크 */
                    String ecDlvyOdr = checkEcDlvyOdrApplcAt(dlvyOdrDtl.getEcOrderNo(), dlvyOdrDtl.getOmsOrderNo(), dlvyOdrDtl.getDlvyOdr());
                    if(ecDlvyOdr.length() > 0 ) {
                    	dlvyOdrDtl.setDlvyOdr(ecDlvyOdr);
                    }

                    loMapper.insertOrDlvyOdrBas(dlvyOdrDtl);
                    loMapper.insertOrDlvyOdrBasHst(dlvyOdrDtl);
                }
            }

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }

    }

    @Override
    public void saveWrhousInfo(WrhousDtlVO wrhousDtlVo) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-027";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, wrhousDtlVo);

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
            /** 서비스 로직(interface table insert) **/
            wrhousDtlVo.setIntrfcNo(btbLogVo.getIntrfcNo());
            /* 사용자 등록 */
            wrhousDtlVo.setFrstRegisterId(intrfc_code);
            wrhousDtlVo.setLastChangerId(intrfc_code);

            ifLoMapper.insertIfLoWrhousInfoBas(wrhousDtlVo);

            /** 서비스 로직(원본/원복이력 table insert) **/
            loMapper.insertLoWrhousInfoBas(wrhousDtlVo);
            loMapper.insertLoWrhousInfoBasHst(wrhousDtlVo);

            wrhousCodeService.initWrhousCode();

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }
    }

    @Override
    public void saveCoCmmnCd(CoCmmnCdVO coCmmnCdVo) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-053";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, coCmmnCdVo);

        try {
            /** 서비스 로직(interface table insert) **/
            List<CoCmmnCdDtlVO> codeList = coCmmnCdVo.getCodeList();
            if (codeList != null) {
                for (CoCmmnCdDtlVO coCmmnCdDtlVO : codeList) {
                    coCmmnCdDtlVO.setIntrfcNo(btbLogVo.getIntrfcNo());
                    /* 사용자 등록 */
                    coCmmnCdDtlVO.setFrstRegisterId(intrfc_code);
                    coCmmnCdDtlVO.setLastChangerId(intrfc_code);

                    ifLoMapper.insertIfLoCodeInfoBas(coCmmnCdDtlVO);
                }
            }
            /** 서비스 로직(원본/원복이력 table insert) **/

            /* 2021-11-25 공통 코드 연계 대상에서 제외 처리됨 -> 원 테이블 insert 로직 주석 처리 */

            /*
             * if (codeList != null) { Map<String, List<CoCmmnCdDtlVO>> groupCodeMap =
             * codeList.stream() .collect(Collectors.groupingBy(CoCmmnCdDtlVO::getCode));
             *
             * groupCodeMap.forEach((key, value) -> { log.debug("key: " + key + ", value: " +
             * value); CoCmmnCdDtlVO mainCodeVo = new CoCmmnCdDtlVO(); String mainCode =
             * key; String mainCodeNm = groupCodeMap.get(key).get(0).getCodeNm(); String
             * mainCodeSe = groupCodeMap.get(key).get(0).getIntrfcSe();
             *
             * mainCodeVo.setCode(mainCode); mainCodeVo.setDetailCodeNm(mainCodeNm);
             * mainCodeVo.setDetailCode("@"); mainCodeVo.setDisplaySeq("0"); // main code
             * displaySeq = 0 mainCodeVo.setValue1(null); mainCodeVo.setValue2(null);
             * mainCodeVo.setValue3(null); mainCodeVo.setValue4(null);
             * mainCodeVo.setValue5(null); mainCodeVo.setIntrfcSe(mainCodeSe);
             *
             * 사용자 등록 mainCodeVo.setFrstRegisterId(intrfc_code + "(" +
             * btbLogVo.getIntrfcNo() + ")"); mainCodeVo.setLastChangerId(intrfc_code + "("
             * + btbLogVo.getIntrfcNo() + ")");
             *
             * try { loMapper.insertCoCmmnCd(mainCodeVo);
             * loMapper.insertCoCmmnCdHst(mainCodeVo); } catch (Exception e) { if
             * (e.getCause() != null) { throw new RuntimeException(e); } }
             *
             * value.forEach(obj -> { try { 사용자 등록 obj.setFrstRegisterId(intrfc_code);
             * obj.setLastChangerId(intrfc_code); loMapper.insertCoCmmnCd(obj);
             * loMapper.insertCoCmmnCdHst(obj); } catch (Exception e) { if (e.getCause() !=
             * null) throw new RuntimeException(e); } }); });
             *
             * }
             */
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }

    }

    @Override
    public void saveRltmDlvyOdr(RltmDlvyOdrVO rltmDlvyOdrVO) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-057";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, rltmDlvyOdrVO);

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
            /** 서비스 로직(interface table insert) **/
            for (RltmDlvyOdrDtlVO rltmDlvyOdrDtlVO : rltmDlvyOdrVO.getOrderNoList()) {
                rltmDlvyOdrDtlVO.setIntrfcNo(btbLogVo.getIntrfcNo());
                /* 사용자 등록 */
                rltmDlvyOdrDtlVO.setFrstRegisterId(intrfc_code);
                rltmDlvyOdrDtlVO.setLastChangerId(intrfc_code);

                ifLoMapper.insertIfLoDlvyCyBas(rltmDlvyOdrDtlVO);
            }

            /** 서비스 로직(원본/원복이력 table insert) **/
            for (RltmDlvyOdrDtlVO rltmDlvyOdrDtlVO : rltmDlvyOdrVO.getOrderNoList()) {
                /* 사용자 등록 */
                rltmDlvyOdrDtlVO.setFrstRegisterId(intrfc_code);
                rltmDlvyOdrDtlVO.setLastChangerId(intrfc_code);

                /* [EC 배송 차수] 적용여부 체크 */
                String ecDlvyOdr = checkEcDlvyOdrApplcAt(rltmDlvyOdrDtlVO.getEcOrderNo(), rltmDlvyOdrDtlVO.getOmsOrderNo(), rltmDlvyOdrDtlVO.getDlvyOdr());
                if(ecDlvyOdr.length() > 0 ) {
                	rltmDlvyOdrDtlVO.setDlvyOdr(ecDlvyOdr);
                }

                loMapper.insertRltmOrDlvyOdrBas(rltmDlvyOdrDtlVO);
                loMapper.insertRltmOrDlvyOdrBasHst(rltmDlvyOdrDtlVO);
            }

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }

    }

    @Override
    public void saveAllInvntry(AllInvntryVO allInvntryVO) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-069";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, allInvntryVO);

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
            /** 서비스 로직(interface table insert) **/
            /* 인터페이스 번호 등록 */
            allInvntryVO.setIntrfcNo(btbLogVo.getIntrfcNo());
            /* 사용자 등록 */
            allInvntryVO.setFrstRegisterId(intrfc_code);
            allInvntryVO.setLastChangerId(intrfc_code);

            ifLoMapper.insertIfLoAllInvntryBas(allInvntryVO);

            for (AllInvntryVO_02 allInvntryVO_02 : allInvntryVO.getBundleList()) {
                /* 부모 테이블의 인터페이스 순번 등록 */
                allInvntryVO_02.setIntrfcSn(allInvntryVO.getIntrfcSn());
                /* 사용자 등록 */
                allInvntryVO_02.setFrstRegisterId(intrfc_code);
                allInvntryVO_02.setLastChangerId(intrfc_code);

                ifLoMapper.insertIfLoAllInvntryLotDtl(allInvntryVO_02);
            }

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }
    }

    @Override
    public void saveDlvyOdrBl(DlvyOdrBlVO dlvyOdrBlVO) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-071";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, dlvyOdrBlVO);

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        /* Lot 리스트 삭제 여부*/
        boolean lotListDelYn;

        try {
            /** 서비스 로직(interface table insert) **/
            List<DlvyOdrBlDtlVO_01> dlvyOdrList = dlvyOdrBlVO.getDlvyOdrList();

            if (dlvyOdrList != null) {
                for (DlvyOdrBlDtlVO_01 vo01 : dlvyOdrList) {
                    vo01.setIntrfcNo(btbLogVo.getIntrfcNo());
                    /* 사용자 등록 */
                    vo01.setFrstRegisterId(intrfc_code);
                    vo01.setLastChangerId(intrfc_code);

                    ifLoMapper.insertIfLoDcsnWtBas(vo01); /* IF_LO_DCSN_WT_BAS 등록 */
                    String intrfcSn = vo01.getIntrfcSn();
                    for (DlvyOdrBlDtlVO_02 vo02 : ListUtils.emptyIfNull(vo01.getBlList())) {
                        vo02.setIntrfcSn(intrfcSn);
                        /* 사용자 등록 */
                        vo02.setFrstRegisterId(intrfc_code);
                        vo02.setLastChangerId(intrfc_code);

                        ifLoMapper.insertIfLoDcsnWtBlDtl(vo02); /* IF_LO_DCSN_WT_BL_DTL 테이블 등록 */

                        String blNo = vo02.getBlNo();
                        String dcsnWtBlDetailSn = vo02.getDcsnWtBlDetailSn();
                        for (DlvyOdrBlDtlVO_03 vo03 : vo02.getBundleList()) {
                            vo03.setBlNo(blNo);
                            vo03.setIntrfcSn(intrfcSn);
                            vo03.setDcsnWtBlDetailSn(dcsnWtBlDetailSn);
                            /* 사용자 등록 */
                            vo03.setFrstRegisterId(intrfc_code);
                            vo03.setLastChangerId(intrfc_code);

                            ifLoMapper.insertIfLoDcsnWtLotDtl(vo03); /* IF_LO_DCSN_WT_LOT_DTL 등록 */
                        }
                    }
                }
            }

            /** 서비스 로직(원본/원복이력 table insert) **/
            if (dlvyOdrList != null) {
                for (DlvyOdrBlDtlVO_01 vo01 : dlvyOdrList) { // Depth 1 Logic
                    String dlvyOdr = vo01.getDlvyOdr();
                    String ecOrderNo = vo01.getEcOrderNo();
                    String loadComptDe = vo01.getLoadComptDe();
                    boolean isOrderNo = !"C".equalsIgnoreCase(ecOrderNo.substring(9, 10)); // 주문번호인지 취교반 번호인지 구분

                    /* 사용자 등록 */
                    vo01.setFrstRegisterId(intrfc_code);
                    vo01.setLastChangerId(intrfc_code);

                    /* [EC 배송 차수] 적용여부 체크 */
                    String ecDlvyOdr = checkEcDlvyOdrApplcAt(ecOrderNo, vo01.getOmsOrderNo(), dlvyOdr);
                    if(ecDlvyOdr.length() > 0 ) {
                    	vo01.setDlvyOdr(ecDlvyOdr);
                    	dlvyOdr = ecDlvyOdr;
                    }

                    loMapper.insertBlDtlOrDlvyOdrBas(vo01);
                    loMapper.insertBlDtlOrDlvyOdrBasHst(vo01);

                    for (DlvyOdrBlDtlVO_02 vo02 : vo01.getBlList()) { // Depth 2 Logic
                        String blNo = vo02.getBlNo();
                        String ecOrderSn = vo02.getEcOrderSn();

                        vo02.setEcOrderNo(ecOrderNo);
                        vo02.setDlvyOdr(dlvyOdr);
                        /* 사용자 등록 */
                        vo02.setFrstRegisterId(intrfc_code);
                        vo02.setLastChangerId(intrfc_code);

                        loMapper.insertBlDtlOrDlvyOdrBlDtl(vo02);
                        loMapper.insertBlDtlOrDlvyOdrBlDtlHst(vo02);

                        /* Lot 리스트 삭제 여부*/
                        lotListDelYn = true;

                        for (DlvyOdrBlDtlVO_03 vo03 : vo02.getBundleList()) { // Depth 3 Logic
                            vo03.setDlvyOdr(dlvyOdr);
                            vo03.setBlNo(blNo);
                            vo03.setEcOrderNo(ecOrderNo);
                            vo03.setEcOrderSn(ecOrderSn);
                            vo03.setLoadComptDe(loadComptDe);

                            /* 사용자 등록 */
                            vo03.setFrstRegisterId(intrfc_code);
                            vo03.setLastChangerId(intrfc_code);

                            if( lotListDelYn ) {
                            	/* Lot 리스트 삭제 */
                                loMapper.deleteBlDtlOrDlvyOdrLotDtl(vo03);
                                lotListDelYn = false;
                            }

                            loMapper.insertBlDtlOrDlvyOdrLotDtl(vo03);
                            loMapper.insertBlDtlOrDlvyOdrLotDtlHst(vo03);

                            if (isOrderNo) { // 주문번호가 들어온거라면,
                                loMapper.insertOrLotInfoDtl(vo03);
                                loMapper.insertOrLotInfoDtlHst(vo03);
                            } else { // 취소교환반품 번호가 들어온거라면,
                                loMapper.insertOrExchngBlLotInfoDtl(vo03);
                                loMapper.insertOrExchngBlLotInfoDtlHst(vo03);
                            }
                        }

                        if (isOrderNo) { // 주문번호가 들어온거라면,
                            loMapper.updateOrOrderDtl(vo02);
                            loMapper.insertOrOrderDtlHst(vo02);
                        } else { // 취소교환반품 번호가 들어온거라면,
                            loMapper.updateOrExchngBlDtl(vo02);
                            loMapper.insertOrExchngBlDtlHst(vo02);
                        }
                    }

                    if (isOrderNo) { // 주문번호가 들어온거라면,
                        loMapper.updateOrOrderBas(vo01);
                        loMapper.insertOrOrderBasHst(ecOrderNo);
                    }
                }
            }

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }
    }

    @Override
    public void saveDlvyProgrsSttus(DlvyProgrsSttusVO dlvyProgrsSttus) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-090";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, dlvyProgrsSttus);

        String intrfc_id = intrfc_code; // 재고처리 공통 프로시져 호출용

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
            /** 서비스 로직(interface table insert) **/
            dlvyProgrsSttus.setIntrfcNo(btbLogVo.getIntrfcNo());
            /* 사용자 등록 */
            dlvyProgrsSttus.setFrstRegisterId(intrfc_code);
            dlvyProgrsSttus.setLastChangerId(intrfc_code);

            if (StringUtils.isNotBlank(dlvyProgrsSttus.getArticlTlphonNo())) {
                dlvyProgrsSttus.setArticlTlphonNo(CryptoUtil.encryptAES256(dlvyProgrsSttus.getArticlTlphonNo())); // 암호화)
            }

            ifLoMapper.insertIfLoDlvySttusRltmBas(dlvyProgrsSttus);

            /* [EC 배송 차수] 적용여부 체크 */
            String ecDlvyOdr = checkEcDlvyOdrApplcAt(dlvyProgrsSttus.getEcOrderNo(), dlvyProgrsSttus.getOmsOrderNo(), dlvyProgrsSttus.getDlvyOdr());
            if(ecDlvyOdr.length() > 0 ) {
            	dlvyProgrsSttus.setDlvyOdr(ecDlvyOdr);
            }

            // 기저장되어있는 배송진행상태 코드
            String agoDlvyCode = loMapper.selectAgoDlvyProgrsSttusCode(dlvyProgrsSttus);
            // 수신받은 배송진행상태 코드
            String newDlvyCode = loMapper.selectNewDlvyProgrsSttusCode(dlvyProgrsSttus);


            // 재고처리 공통 프로시져 추가
            loMapper.insertBlInfo(intrfc_id, Long.toString(dlvyProgrsSttus.getIntrfcSn()));

            // SOREC-IF-090 - dlvyProgrsSttus.getProgrsSttusCode() : 배송 진행상태 코드
            // 저장되어있는 배송진행상태코드 보다 이전 코드 수신시 업데이트 제외
            if( Integer.parseInt(agoDlvyCode) <= Integer.parseInt(newDlvyCode)){

                /** 서비스 로직(원본/원복이력 table insert) **/
                loMapper.insertProgrsSttusOrDlvyOdrBas(dlvyProgrsSttus);
                loMapper.insertProgrsSttusOrDlvyOdrBasHst(dlvyProgrsSttus);

                loMapper.insertProgrsSttusOrDlvyProgrsSttusDtl(dlvyProgrsSttus);
                loMapper.insertProgrsSttusOrDlvyProgrsSttusDtlHst(dlvyProgrsSttus);

                /*
                 * DB상의 배송 진행 상태 코드 10. 배송준비 20. 출고지시 30. 배차완료 40. 출고완료 50. 배송중 60. 인수확인 70.
                 * 배송완료 DB상의 주문 상태 코드 21. 배차중(배차완료) 22. 배송중 30. 배송 완료
                 */
                // int nowOrderSttus = loMapper.isFalseOrRealOrder(dlvyProgrsSttus.getEcOrderNo());
                // log.debug(" ################## saveDlvyProgrsSttus nowOrderSttus : " + nowOrderSttus);
                String resultCode = loMapper.selectFnGetOrderSttusCode(dlvyProgrsSttus);

                // 담보 중도상환 프로세스 실행
                executeMrtggMdstrmRepyProcess(dlvyProgrsSttus, resultCode, newDlvyCode);

                /* 주문_기본 테이블의 ORDER_STTUS_CODE(주문상태코드) 변경은 실주문일 경우만 가능하도록 한다 */
                // if (nowOrderSttus > 13) {
                log.debug(" ################## saveDlvyProgrsSttus result OrderSttusCode :" + resultCode);
                if (resultCode != null && !"".equals(resultCode)) {
            		//090,071,057순서 변경(BTBcni병렬)으로 인한 테이블 적재 
                    switch (resultCode){
                        case "90" :
                            loMapper.insertOrTaxBillError(dlvyProgrsSttus);
                            break;
                        case "80" :
                            loMapper.insertOrTaxBillError(dlvyProgrsSttus);
                            Map<String, String> smsMap = new HashMap<>();
                            smsMap.put("templateNum", "147");					// [147] 물류 이론중량 오류 안내
                            smsMap.put("orderNo", dlvyProgrsSttus.getEcOrderNo()); 			// 주문번호
                            // 내부사용자 별도 전송
                            smsMap.put("commerceNtcnAt", "N"); 					// 추가 수신사 커머스 알림 여부 따로 설정
                            smsMap.put("excpSndngOptnAt", "Y"); 				// 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.

                            smsService.insertSMS(null, smsMap);
                            break;
                        default:
                            dlvyProgrsSttus.setOrderSttusCode(resultCode); // 주문 상태코드 업데이트
                            loMapper.updateProgrsSttusOrOrderBas(dlvyProgrsSttus);
                            loMapper.insertOrOrderBasHst(dlvyProgrsSttus.getEcOrderNo());
                            break;
                    }
                }
                // }


                // 22-04-25 수정사항 : 환불처리여부 Check 로직을 메세지 발송 시에도 필요로하여, 자동환불처리 메소드 내부에서 현 위치로 로직이동
                // * 환불 처리 여부 Check
                boolean refunded = loMapper.selectIsRefnded(dlvyProgrsSttus.getEcOrderNo());

                // 배차 완료 추가 프로세스 : 배차 완료 메세지 발송
                if ("21".equals(resultCode) && !refunded) {
                    this.sendMessageToCustomer(dlvyProgrsSttus.getEcOrderNo(), dlvyProgrsSttus.getDlvyOdr(), 17);
                    this.sendMessageToReptCoustomer(dlvyProgrsSttus.getEcOrderNo(), dlvyProgrsSttus.getDlvyOdr(), 143);
                }
                
                // 배송 완료 추가 프로세스 : 1. 중량 변동금 차이 금액 정산 2. 배송 완료 메세지 발송
                else if ("30".equals(resultCode) && !refunded) { // 모든 차수가 배송 완료라면(=주문 상태코드 30.배송완료)
                    this.atmcRefndProcess(dlvyProgrsSttus.getEcOrderNo(), intrfc_code, false);
                    this.sendMessageToCustomer(dlvyProgrsSttus.getEcOrderNo(), null, 19);
                }

                btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
                btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);
                
            // 저장되어있는 배송진행상태코드보다 이전 코드 수신 시 상태값을 제외한 값들은 업데이트 
            }else if(Integer.parseInt(agoDlvyCode) > Integer.parseInt(newDlvyCode)){
            	 /** 서비스 로직(원본/원복이력 table insert) **/
                loMapper.insertProgrsSttusOrDlvyOdrBas(dlvyProgrsSttus);
                loMapper.insertProgrsSttusOrDlvyOdrBasHst(dlvyProgrsSttus);
                
                loMapper.insertProgrsSttusOrDlvyProgrsSttusDtl(dlvyProgrsSttus);
                loMapper.insertProgrsSttusOrDlvyProgrsSttusDtlHst(dlvyProgrsSttus);
                
                btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
                btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);
            }else {
            	 log.debug(" ################## [LoServiceImpl][saveDlvyProgrsSttus] 물류상태코드 : 배송진행상태코드 보다 이전 코드 수신 ##################");
            	 btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
                 btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);
            }
            //인터페이스 병렬로 인한 미정산된 주문 재처리 
            executOrTaxBillError();
            
        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }

    }

    // 담보 중도상환 프로세스 실행
	private void executeMrtggMdstrmRepyProcess(DlvyProgrsSttusVO dlvyProgrsSttus, String resultCode, String newDlvyCode) {
		/*
		   [담보 중도상환 관련 프로세스]

		  - 부분 출고 상환 여부(PART_DLIVY_REPY_AT): Y 인 주문 건 대상
		  - 각 차수별 배송완료 된 시점에 데이터 등록: newDlvyCode - 자차배송: 40/ 케이지배송: 60

		  - 배송비 등록
		    자차배송: null
		    케이지배송: 차수별 배송비 등록
		    	   (단, 배송비 쿠폰 사용했을 경우에는 첫 번째 데이터의 배송비를 0으로, 그 이후 데이터부터 배송비 순차적으로 등록)

		  - 상환 완료 코드(REPY_COMPT_CODE) >> P: 미대상, N: 미완료, Y: 완료
	        1) 배송완료 데이터 바로 들어오는 case - N: 미완료 (상환 대상 의미)
	        2) 미출고상환 데이터 생성 후, 배송완료 데이터 들어오는 case - P: 미대상 (입금요청금액, 결제예정일 null)

	      - 확정금액/ 입금요청금액은 반올림으로 계산처리
	        : 하지만, 해당 주문의 '최종 상환금액(공급가 기준 계산-정산 시점과 정책 통일)'과 '각 차수별 확정 금액의 합계(각 차수별 확정중량 기준으로 반올림 계산)'가 ±1원 차이 발생하는 케이스가 있음
	          >> 금액이 상이한 경우, 마지막 출고 데이터의 확정 금액을 보정처리 하기로 협의
	    */
		if("Y".equals(dlvyProgrsSttus.getPartDlivyRepyAt()) && ("40".equals(newDlvyCode) || "60".equals(newDlvyCode))) {
			try {
				// 1. 부분 출고 상환 대상 주문건 - 등록 대상 데이터 조회
				OrMrtggMdstrmRepyDtlVO repyInfo = loMapper.selectOrMrtggMdstrmRepyDtlTargetInfo(dlvyProgrsSttus);

				// 확정 금액 계산
				long setleAmount = Math.round(repyInfo.getDcsnWt().multiply(BigDecimal.valueOf(repyInfo.getGoodsUntpc())).add(BigDecimal.valueOf(repyInfo.getDlvrf())).longValue() * 1.1);

				// 마지막 출고 데이터이므로, 가격비교 후 보정처리
				if ("30".equals(resultCode)) {
					// 최종 미상환금액(공급가 기준 계산) - 현재 출고완료 데이터 확정금액 합계
					long lastOdrAmount = repyInfo.getNrdmpAmount() - repyInfo.getDcsnAmount();

					// 확정 중량 기준으로 계산한 금액과 공급가 기준으로 계산한 잔여금액이 상이한 경우, 데이터 보정처리
					if(setleAmount != lastOdrAmount) {
						// 등록할 확정 금액 재세팅
						setleAmount = lastOdrAmount;
					}
				}

				// 데이터 세팅
				repyInfo.setDcsnAmount(setleAmount); 		  						// 확정 금액
				repyInfo.setRcpmnyRequstAmount(setleAmount);  						// 입금 요청 금액
				repyInfo.setFrstRegisterId(dlvyProgrsSttus.getFrstRegisterId());	// 등록자
				repyInfo.setLastChangerId(dlvyProgrsSttus.getLastChangerId());		// 수정자

				// 2. 주문_담보 중도 상환 상세 tbl insert (데이터 없을 경우만 등록 진행)
				int res = loMapper.insertOrMrtggMdstrmRepyDtl(repyInfo);
				if(res > 0) {
					// 3. 이력 테이블 등록
					commonService.insertTableHistory("OR_MRTGG_MDSTRM_REPY_DTL", repyInfo);
				}

				// 4. 배송완료(부분 출고) SMS 발송
				this.sendMessageToCustomer(dlvyProgrsSttus.getEcOrderNo(), dlvyProgrsSttus.getDlvyOdr(), 146);

			} catch (Exception e) {
				log.info("executeMrtggMdstrmRepyProcess 담보 중도 상환 상세 데이터 등록 실패 ERROR : " + e.getMessage());
			}
		}
	}

	@Override
	public void executOrTaxBillError() throws Exception {
		/** 통합 로그 INSERT **/
		String intrfc_code = "SOREC-IF-090(E)";
		List<DlvyProgrsSttusVO> dlvyProgrsSttusList = loMapper.selectOrTaxBillError();
		
		if(dlvyProgrsSttusList.size() > 0) {
			for(DlvyProgrsSttusVO dlvyProgrsSttus : dlvyProgrsSttusList) {
					
				String resultCode = loMapper.selectFnGetOrderSttusCode(dlvyProgrsSttus);
				
				if (resultCode != null && !"".equals(resultCode)) {

					// 22-04-25 수정사항 : 환불처리여부 Check 로직을 메세지 발송 시에도 필요로하여, 자동환불처리 메소드 내부에서 현 위치로 로직이동
					// * 환불 처리 여부 Check
					boolean refunded = loMapper.selectIsRefnded(dlvyProgrsSttus.getEcOrderNo());

					if ("30".equals(resultCode) && !refunded) { // 모든 차수가 배송 완료라면(=주문 상태코드 30.배송완료)
						this.atmcRefndProcess(dlvyProgrsSttus.getEcOrderNo(), intrfc_code, false);
						this.sendMessageToCustomer(dlvyProgrsSttus.getEcOrderNo(), null, 19);

						dlvyProgrsSttus.setOrderSttusCode(resultCode); // 주문 상태코드 업데이트
						dlvyProgrsSttus.setLastChangerId(intrfc_code);
						loMapper.updateProgrsSttusOrOrderBas(dlvyProgrsSttus);
						loMapper.insertOrOrderBasHst(dlvyProgrsSttus.getEcOrderNo());
						//재처리 성공
						loMapper.updateOrTaxBillErrorSuccess(dlvyProgrsSttus);
					}else {
						//재처리 실패
						loMapper.updateOrTaxBillErrorFail(dlvyProgrsSttus);
					}
				}
			}
		}
	}
    
    @Override
    public void saveAditDlvyOdr(AditDlvyOdrVO aditDlvyOdrVo) throws Exception {

        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-107";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, aditDlvyOdrVo);

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
            /** 서비스 로직(interface table insert) **/
            for (AditDlvyOdrDtlVO_01 aditDlvyOdrDtlVO_01 : aditDlvyOdrVo.getOrderNoList()) {
                aditDlvyOdrDtlVO_01.setIntrfcNo(btbLogVo.getIntrfcNo());
                /* 사용자 등록 */
                aditDlvyOdrDtlVO_01.setFrstRegisterId(intrfc_code);
                aditDlvyOdrDtlVO_01.setLastChangerId(intrfc_code);

                ifLoMapper.insertIfLoAditCtBas(aditDlvyOdrDtlVO_01);
                String intrfcSn = aditDlvyOdrDtlVO_01.getIntrfcSn();
                for (AditDlvyOdrDtlVO_02 aditDlvyOdrDtlVO_02 : aditDlvyOdrDtlVO_01.getCtList()) {
                    aditDlvyOdrDtlVO_02.setIntrfcSn(intrfcSn);
                    /* 사용자 등록 */
                    aditDlvyOdrDtlVO_02.setFrstRegisterId(intrfc_code);
                    aditDlvyOdrDtlVO_02.setLastChangerId(intrfc_code);

                    ifLoMapper.insertIfLoAditCtDtl(aditDlvyOdrDtlVO_02);
                }
            }

            /** 서비스 로직(원본/원복이력 table insert) **/
            for (AditDlvyOdrDtlVO_01 aditDlvyOdrDtlVO_01 : aditDlvyOdrVo.getOrderNoList()) {
                /* 사용자 등록 */
                aditDlvyOdrDtlVO_01.setFrstRegisterId(intrfc_code);
                aditDlvyOdrDtlVO_01.setLastChangerId(intrfc_code);

                /* [EC 배송 차수] 적용여부 체크 */
                String ecDlvyOdr = checkEcDlvyOdrApplcAt(aditDlvyOdrDtlVO_01.getEcOrderNo(), aditDlvyOdrDtlVO_01.getOmsOrderNo(), aditDlvyOdrDtlVO_01.getDlvyOdr());
                if(ecDlvyOdr.length() > 0 ) {
                	aditDlvyOdrDtlVO_01.setDlvyOdr(ecDlvyOdr);
                }

                loMapper.insertAditOrDlvyOdrBas(aditDlvyOdrDtlVO_01); /* OR_DLVY_ODR_BAS 테이블 등록 */
                loMapper.insertAditOrDlvyOdrBasHst(aditDlvyOdrDtlVO_01);

                String ecOrderNo = aditDlvyOdrDtlVO_01.getEcOrderNo();
                String dlvyOdr = aditDlvyOdrDtlVO_01.getDlvyOdr();

                for (AditDlvyOdrDtlVO_02 aditDlvyOdrDtlVO_02 : aditDlvyOdrDtlVO_01.getCtList()) {
                    // 11-19 이사님 지시사항 : ctAmount 값이 0이면 insert 안함
                    // 22-02-03 ctAmount -> ctSplpc
                    if (Double.parseDouble(aditDlvyOdrDtlVO_02.getCtSplpc()) == 0) {
                        continue;
                    }

                    aditDlvyOdrDtlVO_02.setEcOrderNo(ecOrderNo);
                    aditDlvyOdrDtlVO_02.setDlvyOdr(dlvyOdr);
                    /* 사용자 등록 */
                    aditDlvyOdrDtlVO_02.setFrstRegisterId(intrfc_code);
                    aditDlvyOdrDtlVO_02.setLastChangerId(intrfc_code);

                    loMapper.insertAditOrDlvyOdrAditCtDtl(aditDlvyOdrDtlVO_02); /* OR_DLVY_ODR_ADIT_CT_DTL 테이블 등록 */
                    loMapper.insertAditOrDlvyOdrAditCtDtlHst(aditDlvyOdrDtlVO_02);
                }
            }

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }

    }

    @Override
    public void saveInvntryMdat(InvntryMdatVO invntryMdatVO) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-110";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, invntryMdatVO);

        String intrfc_id = intrfc_code; // 재고처리 공통 프로시져 호출용

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
            /** 서비스 로직(interface table insert) **/
            /* 인터페이스 번호 등록 */
            invntryMdatVO.setIntrfcNo(btbLogVo.getIntrfcNo());
            /* 사용자 등록 */
            invntryMdatVO.setFrstRegisterId(intrfc_code);
            invntryMdatVO.setLastChangerId(intrfc_code);

            ifLoMapper.insertLoInvntryMdatBas(invntryMdatVO);

            /** 서비스 로직(원본/원복이력 table insert) **/
            loMapper.insertBlInfo(intrfc_id, Long.toString(invntryMdatVO.getIntrfcSn()));

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }
    }

    @Override
    public void saveInvntryBadn(InvntryBadnVO invntryBadnVO) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-111";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, invntryBadnVO);

        String intrfc_id = intrfc_code; // 재고처리 공통 프로시져 호출용

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
            /** 서비스 로직(interface table insert) **/

            /* 인터페이스 번호 등록 */
            invntryBadnVO.setIntrfcNo(btbLogVo.getIntrfcNo());
            /* 사용자 등록 */
            invntryBadnVO.setFrstRegisterId(intrfc_code);
            invntryBadnVO.setLastChangerId(intrfc_code);

            ifLoMapper.insertLoInvntryBadnBas(invntryBadnVO);

            for (InvntryBadnVO_02 InvntryBadnVO_02 : invntryBadnVO.getBundleList()) {
                InvntryBadnVO_02.setIntrfcSn(invntryBadnVO.getIntrfcSn());
                /* 사용자 등록 */
                InvntryBadnVO_02.setFrstRegisterId(intrfc_code);
                InvntryBadnVO_02.setLastChangerId(intrfc_code);

                ifLoMapper.insertLoInvntryBadnLotDtl(InvntryBadnVO_02);
            }

            /** 서비스 로직(원본/원복이력 table insert) **/
            loMapper.insertBlInfo(intrfc_id, Long.toString(invntryBadnVO.getIntrfcSn()));

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }
    }

    @Override
    public void saveInvntryWrhousng(InvntryWrhousngVO invntryWrhousngVO) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-112";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, invntryWrhousngVO);

        String intrfc_id = intrfc_code; // 재고처리 공통 프로시져 호출용

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
            /** 서비스 로직(interface table insert) **/
            for (InvntryWrhousngVO_02 invntryWrhousngVO_02 : invntryWrhousngVO.getBlList()) {
                /* 인터페이스 번호 등록 */
                invntryWrhousngVO_02.setIntrfcNo(btbLogVo.getIntrfcNo());
                /* 사용자 등록 */
                invntryWrhousngVO_02.setFrstRegisterId(intrfc_code);
                invntryWrhousngVO_02.setLastChangerId(intrfc_code);

                ifLoMapper.insertLoInvntryWrhousngBas(invntryWrhousngVO_02);

                for (InvntryWrhousngVO_03 invntryWrhousngVO_03 : invntryWrhousngVO_02.getBundleList()) {
                    invntryWrhousngVO_03.setIntrfcSn(invntryWrhousngVO_02.getIntrfcSn());
                    /* 사용자 등록 */
                    invntryWrhousngVO_03.setFrstRegisterId(intrfc_code);
                    invntryWrhousngVO_03.setLastChangerId(intrfc_code);

                    ifLoMapper.insertInvntryWrhousngLotDtl(invntryWrhousngVO_03);
                }
            }

            /** 서비스 로직(원본/원복이력 table insert) **/
            for (InvntryWrhousngVO_02 invntryWrhousngVO_02 : invntryWrhousngVO.getBlList()) {
                // bl 정보가 업데이트 되기전에 가재고등록여부 확인 : TRUE 가재고->실재고 / FALSE 실재고
                InvntryWrhousngVO_02 paramVo = invntryWrhousngVO_02;
                paramVo.setWrhousngSe("4"); //입고 구분 코드 : 4(입고예정재고 입고)
                boolean flsInvntryYn = loMapper.isRegisteredInvntry(paramVo);
                // 재고처리 프로시져 호출
                loMapper.insertBlInfo(intrfc_id, Long.toString(invntryWrhousngVO_02.getIntrfcSn()));
                // 재고데이터 갱신 redis publish
                invntrySttusService.invntrySttusMsgPublish();

                /*
                  가재고->실재고 입고 경우, 가재고 주문건 결제정보를 OMS에 송신한다.
                  송신대상 조건은 다음과 같다.

                  1. OMS 접수번호 X
                  2. 주문상태코드 다음의 경우들 제외: 주문접수/주문실패/주문취소/사고처리중/사고완료
                  3. 해당 주문건과 관련된 모든 BL이 실재고여야 함
                  4. 이월렛/전자상거래보증/미결제금액=0 증거금의 경우는 "1" 실주문,
                                    미결제금액>0 증거금의 경우는 "0" 가주문으로 송신
                 */
                if(flsInvntryYn) {
                    // 가재고 주문건 조회
                    List<OrOrderBasVO> flsInvtyOrderList = loMapper.selectOrOrderListWithFlsInvntry(invntryWrhousngVO_02.getBlNo());

                    for (OrOrderBasVO order : flsInvtyOrderList) {
                        log.debug("실재고 입고되어 물류 전송 >> orderNo : " + order.getOrderNo());

                        sendSetleInfo(order.getOrderNo(), "1", order.getOrderSttus(), order.getOrderSttusCode()); // 주문번호, 주문타입:주문(1), 주문상태:가주문(0)/실주문(1), 업데이트할 주문상태코드
                    }
                }

                // 교환 및 반품 입고의 경우, 입고 여부를 클레임 테이블에 업데이트 해줌
                if (StringUtils.equals("2", invntryWrhousngVO_02.getWrhousngSe())
                        || StringUtils.equals("3", invntryWrhousngVO_02.getWrhousngSe())) {
                    String ecOrderNo = invntryWrhousngVO_02.getEcOrderNo();
                    String blNo = invntryWrhousngVO_02.getBlNo();
                    for (InvntryWrhousngVO_03 invntryWrhousngVO_03 : invntryWrhousngVO_02.getBundleList()) {
                        invntryWrhousngVO_03.setEcOrderNo(ecOrderNo);
                        invntryWrhousngVO_03.setBlNo(blNo);

                        loMapper.updateOrCanclExchngRtngudDlvyOdrLotDtl(invntryWrhousngVO_03);
                        loMapper.insertOrCanclExchngRtngudDlvyOdrLotDtlHst(invntryWrhousngVO_03);
                    }
                }
            }

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }
    }

    @Override
    public void saveDlvyOdrSignInfo(SignInfoVO signInfoVO) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-005";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, signInfoVO);

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
            /** 서비스 로직(interface table insert) **/
            /* 인터페이스 번호 등록 */
            signInfoVO.setIntrfcNo(btbLogVo.getIntrfcNo());
            /* 사용자 등록 */
            signInfoVO.setFrstRegisterId(intrfc_code);
            signInfoVO.setLastChangerId(intrfc_code);

            ifLoMapper.insertLoSignInfoBas(signInfoVO);

            /* [EC 배송 차수] 적용여부 체크 */
            String ecDlvyOdr = checkEcDlvyOdrApplcAt(signInfoVO.getEcOrderNo(), signInfoVO.getOmsOrderNo(), String.valueOf(signInfoVO.getDlvyOdr()));
            if(ecDlvyOdr.length() > 0 ) {
            	signInfoVO.setDlvyOdr(Integer.parseInt(ecDlvyOdr));
            }

            /** 서비스 로직(원본/원복이력 table insert) **/
            loMapper.insertSignInfoOrDlvyOdrBas(signInfoVO);
            loMapper.insertSignInfoOrDlvyOdrBasHst(signInfoVO);

            /* 2022.10.25 >> 1.수정세금계산서 발행 2.중량변동금 환불시점 서명수신 직후로 변경
             * 2022.11.21 >> 기존로직으로 원복후 주석처리

                케이지배송(01) :    고객서명(2) 시점
                자차배송(02) : 배송기사서명(1) 시점

                1. 환불이력 X
                2. 마지막 차수 존재 O
                3. 모든 차수 사인이력 O (케이지배송:기사+고객 / 자차:기사)

                위 조건을 모두 만족시키는 경우에만 환불 프로세스를 진행한다.

            String ecOrderNo = signInfoVO.getEcOrderNo();
            String dlvyMnCode = loMapper.selectDlvyMnCode(ecOrderNo);       // 배송수단코드 조회
            signInfoVO.setDlvyMnCode(dlvyMnCode);

            boolean refunded = loMapper.selectIsRefnded(ecOrderNo);         // 1. 환불여부 Check
            boolean lastYn = loMapper.selectIsLastDlvyOdr(signInfoVO);      // 2. 마지막 차수 여부 Check
            boolean signYn = loMapper.selectIsAllSigned(signInfoVO);        // 3. 모든차수 사인여부 Check
            log.debug(ecOrderNo + " >> 환불여부 = " + refunded + ", 마지막차수여부 = " + lastYn + ", 모든차수서명여부 = " + signYn);

            if(!refunded && lastYn && signYn) {
                String signSe = signInfoVO.getDelyUndtakeSe();

                if("01".equals(dlvyMnCode) && "2".equals(signSe)) {
                    // 케이지배송 + 고객서명 수신
                    atmcRefndProcess(ecOrderNo, intrfc_code, false);
                } else if("02".equals(dlvyMnCode) && "1".equals(signSe)) {
                    // 자차배송 + 기사서명 수신
                    atmcRefndProcess(ecOrderNo, intrfc_code, false);
                }
            }  */

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }
    }

    @Override
    public InvntryInfoVO getRltmInvntryInfo(InvntryInfoRequstVO invntryInfoRequstVO) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-026";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, invntryInfoRequstVO);

        String intrfc_id = intrfc_code; // b2b cni api 호출용

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        InvntryInfoVO invntryInfoVO = null;

        try {
            Map<String, Object> responseEntity = this.extrlSysApiCall(intrfc_id, invntryInfoRequstVO);
            invntryInfoVO = objectMapper.convertValue(responseEntity, InvntryInfoVO.class);

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);
        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }

        return invntryInfoVO;
    }

    @Override
    public void sendDlvrgChangeInfo(String orderNo, String dlvrgNo, String dlvyRqestde, String sysSe) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-106";
        DlvrgChangeVO dlvrgChangeVO = loMapper.selectOrDlvrgBas(orderNo, dlvrgNo, dlvyRqestde, LoCommConstant.SYS_SE_BATCH.equals(sysSe) ? LoCommConstant.SYS_SE_BO : sysSe); //BATCH로 들어온 경우는 BO로 간주
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, dlvrgChangeVO);

        String intrfc_id = intrfc_code; // b2b cni api 호출용

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
            /** 서비스 로직(interface table insert) **/
            if (dlvrgChangeVO == null) {
                throw new Exception("해당하는 주문번호(" + orderNo + ") 또는 배송지번호(" + dlvrgNo + ") 가 존재하지 않습니다.");
            }

            /* 인터페이스 번호 등록 */
            dlvrgChangeVO.setIntrfcNo(btbLogVo.getIntrfcNo());
            /* 사용자 등록 */
            dlvrgChangeVO.setFrstRegisterId(intrfc_code);
            dlvrgChangeVO.setLastChangerId(intrfc_code);

            ifLoMapper.insertLoDlvrgChangeBas(dlvrgChangeVO);

            if (StringUtils.isNotBlank(dlvrgChangeVO.getDlvrgCttpc())) {
                dlvrgChangeVO.setDlvrgCttpc(CryptoUtil.decryptAES256(dlvrgChangeVO.getDlvrgCttpc())); // 복호화
            }

            Map<String, Object> response = this.extrlSysApiCall(intrfc_id, dlvrgChangeVO);
            log.debug("sendDlvrgChangeInfo response >>> " + response.toString());

            /** 서비스 로직(원본/원복이력 table insert)
                1.api 호출결과 성공 2.출고요청일 변경건에 해당시
                OR_ORDER_BAS 테이블에 반영

                출고요청일 변경건에 대하여 결제수단별로 결제예정일 데이터 변경 적용
             **/
            if("200".equals((String)response.get("rspnsCode"))) {
                if(dlvyRqestde != null && !dlvyRqestde.isEmpty()) {
                    loMapper.updateOrDlivyRequstDe(dlvrgChangeVO);  //주문_기본 출고요청일자 UPDATE
                    loMapper.insertOrOrderBasHst(orderNo);          //주문_이력 INSERT

                    /*
                      1. 시스템구분(sysSe) 1:FO 2:BO로 들어왔을 경우에만 결제예정일을 변경한다.
                      2. 시스템구분(sysSe) 3:BATCH로 들어온 경우는 결제예정일 변경하지 않는다.
                      3. 여신결제일 경우에만 결제예정일을 변경한다.
                     */
                    OrOrderBasVO orderInfo = Optional.ofNullable(loMapper.selectOrOrderBasInfo(orderNo)).orElseThrow(() -> {return new Exception("주문 정보 미존재");});
                    String setleMthd = orderInfo.getSetleMthdCode();
                    log.debug("setleMthd : " + setleMthd + ", sysSe : " + sysSe);
                    if(!LoCommConstant.SYS_SE_BATCH.equals(sysSe) && !"10".equals(setleMthd)) {
                        Map<String,Object> param = new HashMap<>();
                        int repyPd = loMapper.selectDayCntBySetleMthd(orderNo);
                        param.put("startDay", dlvyRqestde);                         //기준일자(변경된 출고예정일)
                        param.put("repyPd", repyPd);                                //계산할 날자일수
                        String setleDe = loMapper.getChangeSetlePrearngeDe(param);  //기준일자&날자일수로 계산한 변경될 결제예정일

                        OrOrderBasVO orderVO = new OrOrderBasVO();                  //테이블 반영을 위한 데이터 세팅
                        orderVO.setSetlePrearngeDe(setleDe);
                        orderVO.setOrderNo(orderNo);
                        orderVO.setLastChangerId(intrfc_id);

                        if("90".equals(setleMthd)) {
                            loMapper.updateOrWrtmSetlePrearngeDe(orderVO);               //주문기본 증거금결제예정일 업데이트
                            loMapper.insertOrOrderBasHst(orderNo);                       //주문기본 이력 등록
                        } else if("20".equals(setleMthd) || "40".equals(setleMthd)) {
                            OrOrderBasVO mrtggInfo = loMapper.selectMrtggInfo(orderNo);  //전자상거래보증 데이터 조회
                            loMapper.updateOrMrtggSetlePrearngeDe(orderVO);              //담보기본 결제예정일 업데이트
                            loMapper.insertOrMrtggBasHst(mrtggInfo);                     //담보기본 이력 등록
                        }
                        log.debug("출고요청일 변경 후 결제예정일 변경 완료 >> " + setleDe);
                    }
                }
             } else {
                 throw new Exception("케이지배송 배송정보 송신결과 실패 : " + (String)response.get("rspnsMssage"));
             }

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }
    }

    /**
     * [물류관리 SOREC-IF-114] 자차배송일경우 차량정보 등록, 수정, 삭제 시 차량정보를 전송한다.
     */
    @Override
    public void sendDlvyVhcleInfo(List<VhcleInfoVO> vhcleInfoList, String sysSe) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-114";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, vhcleInfoList);
        String intrfc_id = intrfc_code; // b2b cni api 호출용

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
        	/* Data Setting Start */
            String orderNo = vhcleInfoList.get(0).getOrderNo(); // 주문 번호
            List<String> orderSns = vhcleInfoList.stream().map(vo -> vo.getOrderSn()).distinct().collect(Collectors.toList()); // 주문 순번 리스트
			List<String> dlvyOdrs = vhcleInfoList.stream().map(vo -> Integer.toString(vo.getDlvyOdr())).collect(Collectors.toList()); // 차량 주문 순번 리스트 (기존 배송 차수 [dlvyOdr] 이름 유지)

			// 자차배송 차량정보 송신 시 주문 번호에 대한 OMS 접수 번호와 주문 번호를 가져오기
            DlvyVhcleVO dlvyVhcleVO = loMapper.selectOrDlvyOdrBas(orderNo);
            dlvyVhcleVO.setSysSe(LoCommConstant.SYS_SE_BATCH.equals(sysSe) ? LoCommConstant.SYS_SE_BO : sysSe); // 시스템 구분(FO:1, BO:2), BATCH로 들어온 경우는 BO로 간주

            // 자차배송 차량정보 송신 시 주문 번호, 주문 순번에 대한 BL정보 리스트를 가져오기
            List<DlvyVhcleVO_02> blList = loMapper.selectOrDlvyOdrBlDtl(orderNo, orderSns);
            List<DlvyVhcleVO_03> vhcleList;

            for(DlvyVhcleVO_02 dlvyVhcleVO_02 : blList) {
            	// 자차배송 차량정보 송신 시 주문 번호, 주문 순번, 차량 주문 순번 (기존 배송 차수)에 대한 주문 차량 정보 리스트 가져오기
                vhcleList = loMapper.selectOrDlvyOdrLotDtl(orderNo, dlvyVhcleVO_02.getOrderSn(), dlvyOdrs);

                // 자차배송 차량정보 송신 시 주문 번호, 주문 순번, 차량 주문 순번 (기존 배송 차수)에 대한 주문 차량 정보 리스트 set
                dlvyVhcleVO_02.setVhcleList(vhcleList);
            }

            // 자차배송 차량정보 송신 시 주문 번호, 주문 순번에 대한 BL정보 리스트 set
            dlvyVhcleVO.setBlList(blList);
            /* Data Setting End */

            /** 서비스 로직(interface table insert) **/
            /* 인터페이스 번호 등록 */
            dlvyVhcleVO.setIntrfcNo(btbLogVo.getIntrfcNo());
            /* 사용자 등록 */
            dlvyVhcleVO.setFrstRegisterId(intrfc_code);
            dlvyVhcleVO.setLastChangerId(intrfc_code);

            // 자차배송 차량정보 송신 시 인터페이스 차량 정보 기본 등록 후 인터페이스 순번 리턴
        	ifLoMapper.insertLoVhcleInfoBas(dlvyVhcleVO);

            long intrfcSn = dlvyVhcleVO.getIntrfcSn(); // 인터페이스 순번

            for (DlvyVhcleVO_02 dlvyVhcleVO_02 : dlvyVhcleVO.getBlList()) {
                dlvyVhcleVO_02.setIntrfcSn(intrfcSn);
                dlvyVhcleVO_02.setFrstRegisterId(intrfc_code);
                dlvyVhcleVO_02.setLastChangerId(intrfc_code);

                // 자차배송 차량정보 송신 시 인터페이스 차량 정보 BL 상세 등록 후 차량 정보 BL 상세 순번 리턴
                ifLoMapper.insertLoVhcleInfoBlDtl(dlvyVhcleVO_02);

                long vhcleInfoBlDetailSn = dlvyVhcleVO_02.getVhcleInfoBlDetailSn(); // 차량 정보 BL 상세 순번 리턴

                for (DlvyVhcleVO_03 dlvyVhcleVO_03 : dlvyVhcleVO_02.getVhcleList()) {
                    dlvyVhcleVO_03.setIntrfcSn(intrfcSn);
                    dlvyVhcleVO_03.setVhcleInfoBlDetailSn(vhcleInfoBlDetailSn);
                    dlvyVhcleVO_03.setFrstRegisterId(intrfc_code);
                    dlvyVhcleVO_03.setLastChangerId(intrfc_code);

                    // 자차배송 차량정보 송신 시 인터페이스 차량 정보 BL 차수 상세 등록
                    ifLoMapper.insertLoVhcleInfoBlOdrDtl(dlvyVhcleVO_03);
                    
                    if (StringUtils.isNotBlank(dlvyVhcleVO_03.getArticlTlphonNo())) {
                        dlvyVhcleVO_03
                                .setArticlTlphonNo(CryptoUtil.decryptAES256(dlvyVhcleVO_03.getArticlTlphonNo())); // 복호화
                    }
                }
            }

            // 외부 API Call
            Map<String, Object> response = this.extrlSysApiCall(intrfc_id, dlvyVhcleVO);
            log.debug("sendDlvyVhcleInfo response >>> " + response.toString());

            /** 서비스 로직
                1.api 호출결과 성공 2.입고예정일 변경시 결제수단별로 결제예정일 변경적용
            **/
            if("200".equals((String)response.get("rspnsCode"))) {
            	//1.결제예정일 변경 대상여부, 기존 결제예정일, 변경될 결제예정일 데이터를 조회한다.
            	//  최소차량입고일 기준으로 변경될 결제예정일 <= 오늘인 경우는 변경대상에서 제외한다.
                Map<String, Object> targetInfo = loMapper.selectOrVhclInfo(orderNo);

                //2. BATCH로 들어온 경우는 제외하고 결제예정일을 변경한다.
                if(null != targetInfo && "Y".equals(targetInfo.get("targetAt")) && !LoCommConstant.SYS_SE_BATCH.equals(sysSe)) {
                	log.info("targetInfo >> " + targetInfo.toString());
                    String setleMthd = (String)targetInfo.get("setleMthdCode");		//결제 수단 코드
                    String newSetleDe = (String)targetInfo.get("newSetleDe");		//변경될 결제예정일

                    OrOrderBasVO orderVO = new OrOrderBasVO();
                    orderVO.setSetlePrearngeDe(newSetleDe);
                    orderVO.setOrderNo(orderNo);
                    orderVO.setLastChangerId(intrfc_id);

                    if("90".equals(setleMthd)) {
                        loMapper.updateOrWrtmSetlePrearngeDe(orderVO);               //주문기본 증거금결제예정일 업데이트
                        loMapper.insertOrOrderBasHst(orderNo);                       //주문기본 이력 등록
                    } else if("20".equals(setleMthd) || "40".equals(setleMthd)) {
                        OrOrderBasVO mrtggInfo = loMapper.selectMrtggInfo(orderNo);  //전자상거래보증 데이터 조회
                        loMapper.updateOrMrtggSetlePrearngeDe(orderVO);              //담보기본 결제예정일 업데이트
                        loMapper.insertOrMrtggBasHst(mrtggInfo);                     //담보기본 이력 등록
                    }
                    log.info("자차배송 차량정보 변경 후 결제예정일 변경 완료 >> " + newSetleDe);
                }
            } else {
                throw new Exception("자차배송 차량정보 송신결과 실패 : " + (String)response.get("rspnsMssage"));
            }

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);
        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }
    }

    @Override
    public void sendChangeDlvyMthd(String orginlOrderNo, String changeOrderNo) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-113";

        /* Data Setting Start */
        ChangeDlvyMthdVO changeDlvyMthdVO = loMapper.selectOrOrderBas(orginlOrderNo);
        changeDlvyMthdVO.setBlList(loMapper.selectChangeDlvyOdrBlDtl(orginlOrderNo));
        changeDlvyMthdVO.setOrderTy("6"); // 주문 타입(배송방식 변경 : 6)
        /* Data Setting End */

        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, changeDlvyMthdVO);

        String intrfc_id = intrfc_code; // b2b cni api 호출용

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
            /** 서비스 로직(interface table insert) **/
            /* 인터페이스 번호 등록 */
            changeDlvyMthdVO.setIntrfcNo(btbLogVo.getIntrfcNo());
            /* 사용자 등록 */
            changeDlvyMthdVO.setFrstRegisterId(intrfc_code);
            changeDlvyMthdVO.setLastChangerId(intrfc_code);
            /* 원 주문번호 세팅 */
            changeDlvyMthdVO.setCanclEcOrderNo(orginlOrderNo);
            /* 신규 주문번호 세팅 */
            changeDlvyMthdVO.setEcOrderNo(changeOrderNo);

            ifLoMapper.insertLoInvntryChangeBas(changeDlvyMthdVO);

            for (ChangeDlvyMthdVO_02 changeDlvyMthdVO_02 : changeDlvyMthdVO.getBlList()) {
                changeDlvyMthdVO_02.setFrstRegisterId(intrfc_code);
                changeDlvyMthdVO_02.setLastChangerId(intrfc_code);
                changeDlvyMthdVO_02.setIntrfcSn(changeDlvyMthdVO.getIntrfcSn());

                ifLoMapper.insertLoInvntryChangeLotDtl(changeDlvyMthdVO_02);
            }

            if (StringUtils.isNotBlank(changeDlvyMthdVO.getDlvrgCttpc())) {
                changeDlvyMthdVO.setDlvrgCttpc(CryptoUtil.decryptAES256(changeDlvyMthdVO.getDlvrgCttpc())); // 복호화
            }

            /** 서비스 로직(원본/원복이력 table insert) **/
            Map<String, Object> response = this.extrlSysApiCall(intrfc_id, changeDlvyMthdVO);

            /* 배송 방식 변경 OMS 접수 번호 업데이트 */
            String omsRceptNo = (String) response.get("omsOrderRceptNo");
            ifLoMapper.updateLoInvntryChangeBas(changeDlvyMthdVO.getIntrfcSn(), omsRceptNo);

            /* Data Setting */
            OrderDlvyMthdChangeVO orderDlvyMthdChangeVO = new OrderDlvyMthdChangeVO();
            orderDlvyMthdChangeVO.setOrginlOrderNo(orginlOrderNo);
            orderDlvyMthdChangeVO.setChangeOrderNo(changeOrderNo);
            orderDlvyMthdChangeVO.setOmsRceptNo(omsRceptNo);
            orderDlvyMthdChangeVO.setFrstRegisterId(intrfc_code);
            orderDlvyMthdChangeVO.setLastChangerId(intrfc_code);

            loMapper.insertOrOrderDlvyMthdChangeDtl(orderDlvyMthdChangeVO);
            loMapper.insertOrOrderDlvyMthdChangeDtlHst(orderDlvyMthdChangeVO);

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }
    }

    @Override
    public String sendSetleInfo(String orderNo, String orderType, String orderSttus, String orderSttusCode) throws Exception {
        /* orderType */
        /* 1 : 주문, 2 : 취소, 3 : 반품, 4 : 교환 입고, 5 : 교환 출고 */
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-023";

        /* Data Setting Start */

        /* Depth 1 Data Declare and Select */
        SetleInfoVO setleInfoVO = loMapper.selectSetleInfoBas(orderNo, orderType);
        /* orderSttus(주문상태) 0:가주문, 1:실주문, 2:취소주문 */
        setleInfoVO.setOrderSttus(orderSttus);

        if (!"2".equals(orderType)) { // 취소일 경우, Depth 1의 데이터만 필요
            /* Depth 2 Data Declare and Select */
            List<SetleInfoVO_02> blList;

            if ("5".equals(orderType)) {
                blList = loMapper.selectSetleInfoDtlExchngDlivy(orderNo);
            } else {
                blList = loMapper.selectSetleInfoDtl(orderNo, orderType);
            }

            if ("3".equals(orderType) || "4".equals(orderType)) { // 반품, 교환 입고일 때만 Depth 3,4 데이터 필요
                /* Depth 3 Data Declare */
                List<SetleInfoVO_03> wonorderDtlList;

                /* Depth 4 Data Declare */
                List<SetleInfoVO_04> wonorderBundleList;

                for (SetleInfoVO_02 setleInfoVO_02 : blList) {
                    String blNo = setleInfoVO_02.getBlNo();
                    wonorderDtlList = loMapper.selectSetleInfoWonorderDtl(orderNo, orderType, blNo); /* Depth 3 Data Select */
                    for (SetleInfoVO_03 setleInfoVO_03 : wonorderDtlList) {
                        int dlvyOdr = setleInfoVO_03.getDlvyOdr();
                        wonorderBundleList = loMapper.selectSetleInfoWonorderBundle(orderNo, orderType, blNo, dlvyOdr); /* Depth 4 Data Select */
                        setleInfoVO_03.setBundleList(wonorderBundleList); /* Depth 4 Data Setting into Depth 3 Data */
                    }
                    setleInfoVO_02.setBlOmsOrderList(wonorderDtlList); /* Depth 3 Data Setting into Depth 2 Data */
                }
            }

            setleInfoVO.setBlList(blList); /* Depth 2 Data Setting into Depth 1 Data */
        }
        /* Data Setting End */

        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, setleInfoVO);

        String intrfc_id = intrfc_code; // b2b cni api 호출용
        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";
        String omsOrderRceptNo = null;

        try {
            /** 서비스 로직(interface table insert) **/
            /* 인터페이스 번호 등록 */
            setleInfoVO.setIntrfcNo(btbLogVo.getIntrfcNo());
            /* 사용자 등록 */
            setleInfoVO.setFrstRegisterId(intrfc_code);
            setleInfoVO.setLastChangerId(intrfc_code);

            ifLoMapper.insertLoSetleInfoBas(setleInfoVO);

            if (setleInfoVO.getBlList() != null) {
                for (SetleInfoVO_02 setleInfoVO_02 : setleInfoVO.getBlList()) {
                    setleInfoVO_02.setIntrfcSn(setleInfoVO.getIntrfcSn());

                    setleInfoVO_02.setFrstRegisterId(intrfc_code);
                    setleInfoVO_02.setLastChangerId(intrfc_code);

                    ifLoMapper.insertLoSetleInfoDtl(setleInfoVO_02);

                    if (setleInfoVO_02.getBlOmsOrderList() != null) {
                        for (SetleInfoVO_03 setleInfoVO_03 : setleInfoVO_02.getBlOmsOrderList()) {
                            setleInfoVO_03.setIntrfcSn(setleInfoVO.getIntrfcSn());
                            setleInfoVO_03.setSetleInfoDetailSn(setleInfoVO_02.getSetleInfoDetailSn());

                            setleInfoVO_03.setFrstRegisterId(intrfc_code);
                            setleInfoVO_03.setLastChangerId(intrfc_code);

                            ifLoMapper.insertLoSetleInfoWonorderDtl(setleInfoVO_03);

                            if (setleInfoVO_03.getBundleList() != null) {
                                for (SetleInfoVO_04 setleInfoVO_04 : setleInfoVO_03.getBundleList()) {
                                    setleInfoVO_04.setIntrfcSn(setleInfoVO.getIntrfcSn());
                                    setleInfoVO_04.setSetleInfoDetailSn(setleInfoVO_02.getSetleInfoDetailSn());
                                    setleInfoVO_04.setWonorderDetailSn(setleInfoVO_03.getWonorderDetailSn());

                                    setleInfoVO_04.setFrstRegisterId(intrfc_code);
                                    setleInfoVO_04.setLastChangerId(intrfc_code);

                                    ifLoMapper.insertSetleInfoWonorderBundle(setleInfoVO_04);
                                }
                            }
                        }
                    }
                }
            }

            if (StringUtils.isNotBlank(setleInfoVO.getDlvrgCttpc())) {
                setleInfoVO.setDlvrgCttpc(CryptoUtil.decryptAES256(setleInfoVO.getDlvrgCttpc())); // 복호화
            }

            /** 서비스 로직(원본/원복이력 table insert) **/
            Map<String, Object> response = this.extrlSysApiCall(intrfc_id, setleInfoVO);

            omsOrderRceptNo = (String) response.get("omsOrderRceptNo");

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);

           //api호출 실패시 물류재처리대상 업데이트
           if(omsOrderRceptNo == null) {
                String rehndlCode = "";
                if(orderSttus.equals("0"))      rehndlCode=LoCommConstant.LO_023_FALSE_ORDER; //가주문 실패
                else if(orderSttus.equals("1")) rehndlCode=LoCommConstant.LO_023_REAL_ORDER;  //실주문 실패

                loMapper.updateOrLgistRehndlTrget(orderNo, rehndlCode, intrfc_code);
                loMapper.insertOrOrderBasHst(orderNo);

                // [44] 물류전송실패 내부사용자 SMS 발송
                sendMessageOmsFail(orderNo);
           } else {

        	   //[OR_ORDER_BAS] 1.OMS접수번호 & 2.주문상태코드 업데이트
               if(orderSttusCode != null) { //가재고
                   loMapper.updateOmsOrderRceptNo(orderNo, omsOrderRceptNo, intrfc_code, orderSttusCode);
                   loMapper.insertOrOrderBasHst(orderNo);
               } else {						//실재고
            	   if(orderSttus.equals("0")) orderSttusCode = LoCommConstant.ORDER_STTUS_CODE_FALSE; 		//가주문
            	   else if(orderSttus.equals("1")) orderSttusCode = LoCommConstant.ORDER_STTUS_CODE_REAL; 	//실주문

            	   loMapper.updateOmsOrderRceptNo(orderNo, omsOrderRceptNo, intrfc_code, orderSttusCode);
                   loMapper.insertOrOrderBasHst(orderNo);
               }

               //IF테이블 OMS접수번호 업데이트
               setleInfoVO.setOmsOrderRceptNo(omsOrderRceptNo);
               ifLoMapper.updateLoSetleInfoBasOmsRceptNo(setleInfoVO);
           }
        }

        return omsOrderRceptNo;
    }

    @Override
    public List<DlvyProgrsResVO_03> getDlvyProgrs(List<String> orderNo) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-007";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, orderNo);

        String intrfc_id = intrfc_code; // b2b cni api 호출용
        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        List<DlvyProgrsResVO_03> dlvyProgrsList; // return 해줄 데이터 리스트

        /* Data Setting Start */
        DlvyProgrsReqVO dlvyProgrsReqVO = new DlvyProgrsReqVO();

        List<DlvyProgrsReqVO_02> orderNoList = new LinkedList<>();

        for (String orderNumber : orderNo) {
            List<DlvyProgrsReqVO_02> dlvyOdrInfos = loMapper.selectDlvyOdrInfo(orderNumber);

            for (DlvyProgrsReqVO_02 dlvyProgrsReqVO_02 : dlvyOdrInfos) {
                orderNoList.add(dlvyProgrsReqVO_02);
            }
        }

        dlvyProgrsReqVO.setOrderNoList(orderNoList);
        /* Data Setting End */

        try {
            DlvyProgrsResVO dlvyProgrsResVO = objectMapper
                    .convertValue(this.extrlSysApiCall(intrfc_id, dlvyProgrsReqVO), DlvyProgrsResVO.class);

            dlvyProgrsList = new LinkedList<>();

            /** 서비스 로직(interface table insert) **/
            for (DlvyProgrsResVO_02 dlvyProgrsResVO_02 : dlvyProgrsResVO.getOrderNoList()) {
                String ecOrderNo = dlvyProgrsResVO_02.getEcOrderNo();
                String omsOrderNo = dlvyProgrsResVO_02.getOmsOrderNo();

                String originOrderNo = dlvyProgrsResVO_02.getEcOrderNo();

                for (DlvyProgrsResVO_03 dlvyProgrsResVO_03 : dlvyProgrsResVO_02.getDlvyOdrList()) {
                    // 추가 데이터 세팅
                    dlvyProgrsResVO_03.setOmsOrderNo(omsOrderNo);
                    dlvyProgrsResVO_03.setEcOrderNo(ecOrderNo);

                    /* 인터페이스 번호 등록 */
                    dlvyProgrsResVO_03.setIntrfcNo(btbLogVo.getIntrfcNo());
                    /* 사용자 등록 */
                    dlvyProgrsResVO_03.setFrstRegisterId(intrfc_code);
                    dlvyProgrsResVO_03.setLastChangerId(intrfc_code);

                    if (StringUtils.isNotBlank(dlvyProgrsResVO_03.getArticlTlphonNo())) {
                        dlvyProgrsResVO_03
                                .setArticlTlphonNo(CryptoUtil.encryptAES256(dlvyProgrsResVO_03.getArticlTlphonNo())); // 암호화
                    }

                    ifLoMapper.insertLoDlvySttusBas(dlvyProgrsResVO_03);

                    /* 원 주문번호 다시 세팅 */
                    dlvyProgrsResVO_03.setEcOrderNo(originOrderNo);
                    dlvyProgrsList.add(dlvyProgrsResVO_03); // return 해줄 데이터 리스트에 추가
                }
            }

            /** 서비스 로직(원본/원복이력 table insert) **/
            /* 조회 용도의 인터페이스로, 해당사항 없음 */
            /* 10-19일 자 추가 로직 : 배송차수 테이블에 MERGE 로직 추가 */

            DlvyProgrsSttusVO dlvyProgrsSttusVO = null; // 배송 진행 상태 처리용 객체

            for (DlvyProgrsResVO_02 dlvyProgrsResVO_02 : dlvyProgrsResVO.getOrderNoList()) {
                for (DlvyProgrsResVO_03 dlvyProgrsResVO_03 : dlvyProgrsResVO_02.getDlvyOdrList()) {
                	/* [EC 배송 차수] 적용여부 체크 */
                	String ecDlvyOdr = checkEcDlvyOdrApplcAt(dlvyProgrsResVO_03.getEcOrderNo(), dlvyProgrsResVO_03.getOmsOrderNo(), dlvyProgrsResVO_03.getDlvyOdr());
                	if(ecDlvyOdr.length() > 0 ) {
                		dlvyProgrsResVO_03.setDlvyOdr(ecDlvyOdr);
                	}

                    loMapper.insertDlvyOdrBas(dlvyProgrsResVO_03);
                    loMapper.insertDlvyOdrBasHst(dlvyProgrsResVO_03);

                    loMapper.insertDlvyProgrsSttusDtl(dlvyProgrsResVO_03);
                    loMapper.insertDlvyProgrsSttusDtlHst(dlvyProgrsResVO_03);

                    /*
                     * DB상의 배송 진행 상태 코드 10. 배송준비 20. 출고지시 30. 배차완료 40. 출고완료 50. 배송중 60. 인수확인 70.
                     * 배송완료
                     */
                    dlvyProgrsSttusVO = new DlvyProgrsSttusVO();
                    dlvyProgrsSttusVO.setEcOrderNo(dlvyProgrsResVO_03.getEcOrderNo());
                    dlvyProgrsSttusVO.setProgrsSttusCode(dlvyProgrsResVO_03.getDlvyProgrsSttusCode());

                    String resultCode = loMapper.selectFnGetOrderSttusCode(dlvyProgrsSttusVO);

                    log.debug(" getDlvyProgrs result OrderSttusCode : " + resultCode);
                    if (resultCode != null && !"".equals(resultCode)) {
                        dlvyProgrsSttusVO.setOrderSttusCode(resultCode); // 주문 상태코드 업데이트
                        dlvyProgrsSttusVO.setLastChangerId(intrfc_code);
                        loMapper.updateProgrsSttusOrOrderBas(dlvyProgrsSttusVO);
                        loMapper.insertOrOrderBasHst(dlvyProgrsResVO_03.getEcOrderNo());
                    }

                    /*
                    // 추가 프로세스 : 중량 변동금 차이 금액 정산
                    if ("30".equals(resultCode)) { // 모든 차수가 배송 완료라면(=주문 상태코드 30.배송완료)
                        this.atmcRefndProcess(dlvyProgrsResVO_03.getEcOrderNo(), intrfc_code, false);
                    }*/
                }
            }

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }

        return dlvyProgrsList;
    }

    @Override
    public void saveWrhousStdrChcy(WrhousStdrChcyVO wrhousStdrChcyVO) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-109";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, wrhousStdrChcyVO);

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
            /** 서비스 로직(interface table insert) **/
            /* 인터페이스 번호 등록 */
            wrhousStdrChcyVO.setIntrfcNo(btbLogVo.getIntrfcNo());
            /* 사용자 등록 */
            wrhousStdrChcyVO.setFrstRegisterId(intrfc_code);
            wrhousStdrChcyVO.setLastChangerId(intrfc_code);

            ifLoMapper.insertLoWrhousStdrChcy(wrhousStdrChcyVO);
            /** 서비스 로직(원본/원복이력 table insert) **/
            loMapper.insertLoWrhousStdrChcy(wrhousStdrChcyVO);
            loMapper.insertLoWrhousStdrChcyHst(wrhousStdrChcyVO);

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }
    }

    @Override
    public void saveDlvyTariff(DlvyTariffVO dlvyTariffVO) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-089";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, dlvyTariffVO);

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        try {
            /** 서비스 로직(interface table insert) **/
            /* 인터페이스 번호 등록 */
            dlvyTariffVO.setIntrfcNo(btbLogVo.getIntrfcNo());
            /* 사용자 등록 */
            dlvyTariffVO.setFrstRegisterId(intrfc_code);
            dlvyTariffVO.setLastChangerId(intrfc_code);

            ifLoMapper.insertLoDlvyTariffBas(dlvyTariffVO);

            /** 서비스 로직(원본/원복이력 table insert) **/
            loMapper.insertLoDlvyTariffBas(dlvyTariffVO);
            loMapper.insertLoDlvyTariffBasHst(dlvyTariffVO);

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }
    }

    @Override
    public String sendOrderSttusChange(OrderSttusChgInfoVO orderSttusChgInfoVO) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-125";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, orderSttusChgInfoVO);

        String intrfc_id = intrfc_code; // b2b cni api 호출용

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        String rspnsCode = LoCommConstant.ERROR_RESULT_CODE;
        String orderSttus = orderSttusChgInfoVO.getOrderSttus(); //주문상태
        String orderNo = orderSttusChgInfoVO.getEcOrderNo();     //주문번호

        try {
            /** 서비스 로직(interface table insert) **/
            /* 인터페이스 번호 등록 */
            orderSttusChgInfoVO.setIntrfcNo(btbLogVo.getIntrfcNo());
            /* 사용자 등록 */
            orderSttusChgInfoVO.setFrstRegisterId(intrfc_code);
            orderSttusChgInfoVO.setLastChangerId(intrfc_code);

            ifLoMapper.insertLoOrderSttusChangeBas(orderSttusChgInfoVO);

            /*  [주문상태(orderSttus)] - 0: 가주문, 1: 실주문: 2: 취소주문, 3: 출고중지, 4 :출고중지 취소

				- 송신 미대상 취소주문[2]
				  >> 송신 대상여부 체크 :
				     1) 각 주문건의 모든 Bl이 실재고인지 체크(하나라도 가재고로 확인되면 대상아님)
                     2) OMS접수번호가 존재하지 않는 주문건

               	     위 경우에 주문정보가 물류에 넘어가지 않았으므로, 취소주문 API는 호출하지 않고 재고 원복 처리만 진행한다.

               - 출고중지[3]
               - 출고중지 취소[4]
                 >> 중도상환과 관련된 위 2가지 경우는 물류 시스템 미개발 상태라, 우선 무조건 성공 RETURN 해주기로 합의 (2024-07-03)
                    (물류쪽 개발 이후 수정예상, 호출하는 곳에서는 물류관계자에게 알림톡 전송 필요)
            */
            boolean targetAt = loMapper.isAllRealInvntry(orderNo);

            if(!targetAt && "2".equals(orderSttus)) {
            	// 송신 미대상 취소주문[2]
            	log.info("["+orderNo+"] 취소주문 >> 가재고 존재 or OMS 접수번호 미존재로 api는 호출하지 않음");

                rspnsCode = LoCommConstant.SUCCESS_RESULT_CODE; //재고원복은 진행
            } else {
                Map<String, Object> response = this.extrlSysApiCall(intrfc_id, orderSttusChgInfoVO);
                log.info("sendOrderSttusChange response >> " + response.toString());

                if("3".equals(orderSttus) || "4".equals(orderSttus)) {
                	// 출고중지[3] or 출고중지 취소[4]
                	log.info("["+orderNo+"] 주문상태 변경 >> " + orderSttus + " : api 호출 결과 무조건 성공 처리");

                	rspnsCode = LoCommConstant.SUCCESS_RESULT_CODE;
                } else {
                	rspnsCode = (String)response.get("rspnsCode");
                }
            }

            /*
             다음 모든 조건을 만족하는 경우, 취소주문에 대한 재고원복처리를 진행한다.
                1. 취소주문("2")
                2. api 호출결과 성공
                3. 해당 주문건에 대한 재고원복 이력이 없는경우
             */
            if(LoCommConstant.SUCCESS_RESULT_CODE.equals(rspnsCode)) {

                if("2".equals(orderSttus) ) {
                    List<OrOrderBasVO> blList = loMapper.selectOrDtlBlList(orderNo); //해당 주문번호의 BL리스트 조회

                    // 24-06-07 변경사항 : 소량판매 방식 추가에 따른 로직 및 쿼리 변경
                    Map<String, String> keyValues;

                    for (OrOrderBasVO bl : blList) { //각 BL에 대한 재고원복 진행
                        boolean recoverYn = loMapper.isAlreadyRecoveredBlInfo(bl);
                        //해당 주문번호+BL 에 대한 재고원복 이력이 없으므로 재고원복처리를 진행한다.
                        if(!recoverYn) {
                            //재고원복을 위한 데이터 조회
                            InvntryRecoverVO invntryVO = loMapper.selectInvntryRecoverTargetInfo(bl);
                            invntryVO.setLastChangerId(intrfc_id);
                            //재고데이터 원복
                            loMapper.updateRecoverInvntryBlInfoBas(invntryVO);
                            //HST 처리
                            keyValues = Collections.singletonMap("BL_NO", invntryVO.getBlNo());
                            commonService.insertTableHistory("IT_BL_INFO_BAS", keyValues);
                            //bl이력데이터 등록
                            loMapper.insertInvntryBlInfoHistDtl(invntryVO);
                            //재고데이터 갱신 redis publish
                            invntrySttusService.invntrySttusMsgPublish();
                        }
                    }//for
                }
            }

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);

            //api호출 실패시 물류재처리대상 업데이트
            if(LoCommConstant.ERROR_RESULT_CODE.equals(rspnsCode)) {
                String rehndlCode = "";
                if("1".equals(orderSttusChgInfoVO.getOrderSttus()))      rehndlCode=LoCommConstant.LO_125_REAL_ORDER;    //실주문변경 실패
                else if("2".equals(orderSttusChgInfoVO.getOrderSttus())) rehndlCode=LoCommConstant.LO_125_CANCEL_ORDER;  //취소주문변경 실패

                loMapper.updateOrLgistRehndlTrget(orderSttusChgInfoVO.getEcOrderNo(), rehndlCode, intrfc_code);
                loMapper.insertOrOrderBasHst(orderSttusChgInfoVO.getEcOrderNo());
            }

            // 출고중지[3] or 출고중지 취소[4] 일 경우, '출고 중지 여부' update
        	if("3".equals(orderSttus) || "4".equals(orderSttus)) {
        		loMapper.updateOrdlivyStpgeAt(orderSttusChgInfoVO);
        		loMapper.insertOrOrderBasHst(orderSttusChgInfoVO.getEcOrderNo());
            }
        }

        return rspnsCode;
    }

    @Override
    public RltmCapaVO saveRltmLgistCnfirm(RltmCapaVO rltmCapaRequestVO) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-126";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, rltmCapaRequestVO);

        String intrfc_id = intrfc_code; // b2b cni api 호출용

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        RltmCapaVO rltmCapaVO = new RltmCapaVO(); // 리턴해줄 데이터

        try {
            /** 물류 실시간 CAPA 정보 조회 **/
            Map<String, Object> response = this.extrlSysApiCall(intrfc_id, rltmCapaRequestVO);
            rltmCapaVO = objectMapper.convertValue(response, RltmCapaVO.class);

            /** 서비스 로직(interface table insert) **/
            /* 인터페이스 번호 등록 */
            rltmCapaVO.setIntrfcNo(btbLogVo.getIntrfcNo());
            /* 사용자 등록 */
            rltmCapaVO.setFrstRegisterId(intrfc_code);
            rltmCapaVO.setLastChangerId(intrfc_code);
            rltmCapaVO.setWrhousCode(rltmCapaRequestVO.getWrhousCode()); // 창고코드
            /* 물류 실시간 CAPA 기본 테이블에 등록 */
            ifLoMapper.insertLoRltmCapaBas(rltmCapaVO);

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }

        return rltmCapaVO;
    }

    @Override
    public Map<String, String> saveFlsOrderAsgnCanclCompt(FlsOrderAsgnCanclVO flsOrderAsgnCanclVO) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-127";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, flsOrderAsgnCanclVO);

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        Map<String,String> flsOrderAsgnCanclComptMap = new HashMap<>();
        flsOrderAsgnCanclComptMap.put("omsOrderRceptNo", flsOrderAsgnCanclVO.getOmsOrderRceptNo());

        try {
            /* 취소주문건 여부 확인 : 취소/교환 테이블에서 데이터유무 체크 */
            OrOrderBasVO canclOrder = loMapper.selectCanclOrderAtCnfirm(flsOrderAsgnCanclVO);

            if (canclOrder == null) {
                flsOrderAsgnCanclComptMap.put("rspnsCode", LoCommConstant.ERROR_RESULT_CODE);
                flsOrderAsgnCanclComptMap.put("rspnsMssage", LoCommConstant.ERROR_RESULT_MSG);

                throw new Exception("주문번호(" + flsOrderAsgnCanclVO.getEcOrderNo() + ")에 대한 취소주문이 존재하지 않습니다.");
            } else {
                /* IF-125 주문상태변경 서비스 호출 : "2"취소주문 재요청 **/
                OrderSttusChgInfoVO orderSttusChgInfoVO = new OrderSttusChgInfoVO();
                orderSttusChgInfoVO.setEcOrderNo(flsOrderAsgnCanclVO.getEcOrderNo());
                orderSttusChgInfoVO.setOmsOrderRceptNo(flsOrderAsgnCanclVO.getOmsOrderRceptNo());
                orderSttusChgInfoVO.setOrderSttus("2");

                String rspnsCode = sendOrderSttusChange(orderSttusChgInfoVO);

                flsOrderAsgnCanclComptMap.put("rspnsCode", rspnsCode);
                flsOrderAsgnCanclComptMap.put("rspnsMssage", LoCommConstant.SUCCESS_RESULT_CODE.equals(rspnsCode) ? LoCommConstant.SUCCESS_RESULT_MSG : LoCommConstant.ERROR_RESULT_MSG);
            }

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }

        return flsOrderAsgnCanclComptMap;
    }

    @Override
    public Map<String, String> sendInvntryAsgnInfo(InvntryAsgnInfoVO invntryAsgnInfoVO) throws Exception {
    	/** 통합 로그 INSERT **/
	    String intrfc_code = "SOREC-IF-152";
	    InvntryAsgnInfoVO invntryAsgnInfoVO2 = loMapper.selectAsgnInvntryDtl(invntryAsgnInfoVO);
	    //데이터가 없을 경우(할당 해제)
	    if(invntryAsgnInfoVO2 == null) {
	    	InvntryAsgnInfoVO invntryAsgnInfoVO3 = loMapper.selectAsgnInvntryDtlHst(invntryAsgnInfoVO);
	    	if(invntryAsgnInfoVO3 !=null) {
	    		invntryAsgnInfoVO2 = invntryAsgnInfoVO3;
	    	}
	    }
	    BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, invntryAsgnInfoVO2);
	    String intrfc_id = intrfc_code; // b2b cni api 호출용

	    intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

	    Map<String, String> responseEntity = new HashMap<String, String>();

	    try {
	    	if(invntryAsgnInfoVO2 != null) {
		    	/** 서비스 로직(interface table insert) **/
			    /* 인터페이스 번호 등록 */
			    invntryAsgnInfoVO2.setIntrfcNo(btbLogVo.getIntrfcNo());
			    /* 사용자 등록 */
			    invntryAsgnInfoVO2.setFrstRegistDt(intrfc_code);
			    invntryAsgnInfoVO2.setLastChangeDt(intrfc_code);

			    ifLoMapper.insertLoInvntryAsgnBas(invntryAsgnInfoVO2);

			    Map<String, Object> response = this.extrlSysApiCall(intrfc_id, invntryAsgnInfoVO2);
			    log.debug("sendInvntryAsgnInfo response >>> " + response.toString());

			    /* api 호출결과 성공 */
			    if(!"200".equals(String.valueOf(response.get("rspnsCode")))) {
			    	throw new Exception("재고할당정보 송신결과 실패 : " + (String)response.get("rspnsMssage"));
			    } else {
			    	responseEntity.put("loInvntryAsgnNo",  String.valueOf(response.get("invntryAsgnNo"))); // 물류에서 받은 재고할당번호
			    	responseEntity.put("dbInvntryAsgnNo", invntryAsgnInfoVO2.getInvntryAsgnNo()); // 할당재고상세 또는 할당재고상세이력에 저장된 재고할당번호
			    }

			    btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
	            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);
	    	}else {
	    		btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
	    		btbLogVo.setIntrfcRspnsCn(LoCommConstant.ERROR_RESULT_MSG);
	    	}
	    } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }

	    return responseEntity;
    }

    // 외부 API Call Method
    private Map<String, Object> extrlSysApiCall(String intrfc_code, Object data) throws Exception {
        BtoBReqEntity reqEntity = new BtoBReqEntity();

        /* 인터페이스 ID Setting */
        reqEntity.setInterfaceId(intrfc_code);

        /* Request Setting */
        reqEntity.setRequest(objectMapper.convertValue(data, Map.class));

        /* 호출 */
        BtoBResEntity resEntity = httpClientHelper.callApi(reqEntity);

        if (!StringUtils.equals(resEntity.getResultcode(), BtoBConstants.BTOB_CNI_SUCCESS_CODE)) {
            /* 에러 발생 */
            throw new Exception("External System API Call Failed \nCause : " + resEntity.getMessage());
        }

        /* 데이터 캐스팅 */
        Map<String, Object> response = (Map<String, Object>) resEntity.getResponse();

        log.debug("B2B CNI " + intrfc_code + " API Call Result : " + response);

        return response;
    }

    // 고객 대상 메세지 발송 메소드
    private void sendMessageToCustomer(String orderNo, String dlvyOdr, int tmptNo) throws Exception {
    	int emailTmptNo = tmptNo;
    	// 주문 Data만 Select
    	DlvyProgrsSttusVO paramVO = new DlvyProgrsSttusVO();
    	paramVO.setEcOrderNo(orderNo);
    	if(tmptNo == 146) {
    		// 부분출고(중도상환)주문일 경우, 차수별 데이터 조회하도록 파라미터 추가세팅
    		paramVO.setDlvyOdr(dlvyOdr);
    		emailTmptNo = 19; // 부분출고는 이메일 없음
    	}

        OdrDtlVO odrData = loMapper.selectOrderDataForMail(paramVO);

        // OR_ORDER_BAS(주문_주문 기본)-ORDRR_MOBLPHON_NO(주문자 휴대폰 번호) 복호화
        String ordrrMoblphonNo = odrData.getOrdrrMoblphonNo();
        if (StringUtils.isNotEmpty(ordrrMoblphonNo)) {
            try {
                log.debug("주문자 휴대폰 번호 복호화 전 ==================>" + ordrrMoblphonNo);
                ordrrMoblphonNo = CryptoUtil.decryptAES256(ordrrMoblphonNo);
                log.debug("주문자 휴대폰 번호 복호화 후 ==================>" + ordrrMoblphonNo);
                /** 주문자 휴대폰 번호 셋팅 **/
                odrData.setOrdrrMoblphonNo(StringUtil.formatPhone(ordrrMoblphonNo));
            } catch (Exception e) {
                log.error("LoServiceImpl sendMessageToCustomer ORDRR_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR "
                        + e.getMessage());
            }
        }

        // OR_DLVRG_BAS(주문_배송지 기본) - RECEPT_ENTRPS_MOBLPHON_NO(수취 업체 휴대폰 번호) 복호화
        String receptEntrpsMoblphonNo = odrData.getReceptEntrpsMoblphonNo();
        if (StringUtils.isNotEmpty(receptEntrpsMoblphonNo)) {
            try {
                log.debug("수취 업체 휴대폰 번호 복호화 전 ==================>" + receptEntrpsMoblphonNo);
                receptEntrpsMoblphonNo = CryptoUtil.decryptAES256(receptEntrpsMoblphonNo);
                log.debug("수취 업체 휴대폰 번호 복호화 후 ==================>" + receptEntrpsMoblphonNo);
                /** 수취 업체 휴대폰 번호 셋팅 **/
                odrData.setReceptEntrpsMoblphonNo(StringUtil.formatPhone(receptEntrpsMoblphonNo));
            } catch (Exception e) {
                log.error(
                        "LoServiceImpl sendMessageToCustomer RECEPT_ENTRPS_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR "
                                + e.getMessage());
            }
        }

        // 배송 차수 관련 데이터 Select
        List<OdrDtlVO_02> dlvyOdrData = null;
        if (tmptNo == 17) {
            dlvyOdrData = loMapper.selectDlvyOdrDataForMail(orderNo, dlvyOdr);
        } else {
            dlvyOdrData = loMapper.selectDlvyOdrDataForMail(orderNo, null);
        }

        MailVO mailVo = new MailVO();
        mailVo.setMailTmptSeq(emailTmptNo);
        mailVo.setMailSendUserId("SYSTEM");
        mailVo.setEmail(odrData.getOrdrrEmail());
        mailVo.setMailSendEmail(loMapper.getSntoEmail(emailTmptNo));

        // 주문 Data만 가지고 Mapping 데이터를 먼저 작성
        Map<String, String> odrMap = objectMapper.convertValue(odrData, Map.class);
        odrMap.put("orderNo", commAvrgpcOrderService.getOrderInfoString(odrMap.get("orderNo"), null));
        // 배송 차수 관련 데이터를 따로따로 작성
        setDlvyOdrData(odrMap, dlvyOdrData, tmptNo);
        // Null값 처리 : null값일 시, 공통쪽에서 에러 발생함
        odrMap.forEach((key, value) -> {
            if (StringUtils.isEmpty(value) || StringUtils.equals("0", value)) {
                odrMap.replace(key, "");
            }
        });

        odrMap.put("goodsInfoLink", "");
        odrMap.put("Servicedomain", "https://www.kztraders.com");
        odrMap.put("documentViewDomain", "https://kztraders.com/my/papersManage/viewPapersManage"); // 20220401 이현진_세금계산서 url추가
        // 결제수단에 따른 주문상세정보 치환
        String replacedOdrDtlsInfo = getOdrDtlsInfoData(odrData);
        odrMap.put("odrDtlsInfo", replacedOdrDtlsInfo);
        // 평균가 주문이 아닌 경우 메일 발송 & 부분 출고 주문건은 메일 발송 제외(기존처럼 전체 차수 배송완료일시 최종 1번만 발송)
        // 24-11-12 변경사항 : 가단가 주문(05)일 경우에도 이메일 발송 제외 처리되도록 조건문 수정
		if( ( !StringUtils.equals("04", odrMap.get("sleMthdCode")) && !StringUtils.equals("05", odrMap.get("sleMthdCode")) ) 
				&& tmptNo != 146) {
        	mailService.insertMailSend(mailVo, odrMap);
		}
        SMSVO smsVo = new SMSVO();

        smsVo.setPhone(odrData.getOrdrrMoblphonNo().replace("-", ""));
        smsVo.setMberNo(odrData.getMberNo());
        smsVo.setMberKndSeCode(odrData.getMberSeCode());
        smsVo.setCommerceNtcnAt("Y");

        odrMap.put("templateNum", Integer.toString(tmptNo));
        odrMap.put("Servicedomain", "https://m.kztraders.com");
        // 결제수단에 따른 결제정보 치환
        String replacedOdrSetleInfo = getOdrSetleInfoData(odrData, tmptNo);
        odrMap.put("odrSetleInfo", replacedOdrSetleInfo);
        if (tmptNo == 17) {
            odrMap.put("commerceNtcnCn", "[케이지트레이딩] 고객님의 주문이 배차 되었습니다.");
        } else {
        	// 배송완료시: 주문중량 -> 확정중량으로 표기
    		odrMap.put("totRealOrderWt", odrData.getTotDcsnWt());
        	odrMap.put("commerceNtcnCn", "[케이지트레이딩] 고객님의 주문이 배송완료 되었습니다.");
        }

        smsService.insertSMS(smsVo, odrMap);

        if (StringUtils.isNotEmpty(odrData.getDeviceId())) {
            AppPushQueueVO pushVo = new AppPushQueueVO();

            pushVo.setCallback(odrData.getOrdrrMoblphonNo());
            pushVo.setMberNo(odrData.getMberNo());
            pushVo.setIdentify(odrData.getDeviceId());

            if (tmptNo == 17) {
                pushVo.setMsgTitle("[케이지트레이딩] 배차 알림");
            } else {
                pushVo.setMsgTitle("[케이지트레이딩] 상품 인도 알림");
            }

            pushVo.setType("1"); // 주문 후 process
            pushVo.setUrl(appPushDomain + "/mo/my/order/orderDtls"); // push 메세지를 눌렀을 때, mapping되는 url

            smsService.insertAppPush(pushVo, odrMap);
        }
    }
    
    //수취인 대상 메세지 발송 메소드
    private void sendMessageToReptCoustomer(String orderNo, String dlvyOdr, int tmptNo) throws Exception{
    	
    	// 주문 Data만 Select	: 수취인 대상 핸드폰 번호 조회를 위함
    	DlvyProgrsSttusVO paramVO = new DlvyProgrsSttusVO();
    	paramVO.setEcOrderNo(orderNo);
    	OdrDtlVO odrData = loMapper.selectOrderDataForMail(paramVO);

        // OR_DLVRG_BAS(주문_배송지 기본) - RECEPT_ENTRPS_MOBLPHON_NO(수취 업체 휴대폰 번호) 복호화
        String receptEntrpsMoblphonNo = odrData.getReceptEntrpsMoblphonNo();
        
        if (StringUtils.isNotEmpty(receptEntrpsMoblphonNo)) {
            try {
                log.debug("수취 업체 휴대폰 번호 복호화 전 ==================>" + receptEntrpsMoblphonNo);
                receptEntrpsMoblphonNo = CryptoUtil.decryptAES256(receptEntrpsMoblphonNo);
                log.debug("수취 업체 휴대폰 번호 복호화 후 ==================>" + receptEntrpsMoblphonNo);
                /** 수취 업체 휴대폰 번호 셋팅 **/
                odrData.setReceptEntrpsMoblphonNo(StringUtil.formatPhone(receptEntrpsMoblphonNo));
            } catch (Exception e) {
                log.error(
                        "LoServiceImpl sendMessageToCustomer RECEPT_ENTRPS_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR "
                                + e.getMessage());
            }
        }
        
    	SMSVO smsVO = new SMSVO();
        smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
        smsVO.setPhone(receptEntrpsMoblphonNo.replace("-", ""));
        smsVO.setCommerceNtcnAt("N");
        
        Map<String, String> smsMap = null;
        smsMap = loMapper.selectDataForReptCoustomer(orderNo, dlvyOdr);
        if(smsMap != null && smsMap.size() == 8) {
            	smsMap.put("templateNum", Integer.toString(tmptNo));
            	// OR_DLVRG_BAS(주문_배송지 기본) - RECEPT_ENTRPS_MOBLPHON_NO(수취 업체 휴대폰 번호) 복호화
            	String drverTlphonNo = String.valueOf(smsMap.get("drverTlphonNo"));
            	if(StringUtils.isNotEmpty(drverTlphonNo) && !drverTlphonNo.equals("null")) {
            		try {
            			log.debug("배송 기사 휴대폰 번호 복호화 전 ==================>" + drverTlphonNo);
            			drverTlphonNo = CryptoUtil.decryptAES256(drverTlphonNo);
            			log.debug("배송 기사 휴대폰 번호 복호화 후 ==================>" + drverTlphonNo);
            			/** 배송 기사 휴대폰 번호 셋팅 **/
            			smsMap.put("drverTlphonNo", StringUtil.formatPhone(drverTlphonNo));
            		} catch(Exception e) {
            			log.error("OrderServiceImpl procSms RECEPT_ENTRPS_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
            		}
            	}
            	log.debug(">>sendMessageToReptCoustomer smsMap : " + String.valueOf(smsMap));
            	smsMap.put("excpSndngOptnAt", "N"); // 예외 발송 옵션 여부, N일 경우 SMS 수신자만 발송한다.
            	smsService.insertSMS(smsVO, smsMap);
        }else {
        	log.debug(">>sendMessageToReptCoustomer smsMap error: " + String.valueOf(smsMap));
        }
    }

    private void setDlvyOdrData(Map<String, String> odrMap, List<OdrDtlVO_02> dlvyOdrData, int tmptNo) throws Exception {
        if (tmptNo == 17) {
            // 배송 차수 관련 데이터를 따로따로 작성
            for (int i = 0; i < dlvyOdrData.size(); i++) {
                OdrDtlVO_02 iterator = dlvyOdrData.get(i);

                if (StringUtils.isNotBlank(iterator.getDrverTlphonNo())) {
                    iterator.setDrverTlphonNo(
                            StringUtil.formatPhone(CryptoUtil.decryptAES256(iterator.getDrverTlphonNo())));
                }

                int numbering = i + 1;
                Field[] fieldes = OdrDtlVO_02.class.getDeclaredFields();

                for (Field field : fieldes) {
                    field.setAccessible(true);

                    Object tmpValue = field.get(iterator);
                    String key = field.getName();
                    String value = "";

                    if (tmpValue != null) {
                        value = tmpValue.toString();
                    }

                    if (numbering == 1) {
                        odrMap.put(key, value);
                    } else {
                        odrMap.put(key + numbering, value);
                    }
                }
            }

        } else {
            StringBuilder sb = new StringBuilder();

            sb.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"border-collapse:collapse; \" width=\"100%\">");
            sb.append("</thead>");
            sb.append(" <tr style=\"height: 36px;\">");
            sb.append("     <th align=\"center\" style=\"background: #efefef; border-bottom: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">배차번호</th>");
            sb.append("     <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">출고일</th>");
            sb.append("     <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">중량</th>");
            sb.append("     <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">배송업체</th>");
            sb.append("     <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">배송기사</th>");
            sb.append("     <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">차량번호</th>");
            sb.append("     <th align=\"center\" style=\"background: #efefef; border-bottom: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">기사 연락처</th>");
            sb.append(" </tr>");
            sb.append("</thead>");
            sb.append("<tbody>");

            //차수별 배차정보 입력
            for (OdrDtlVO_02 dlvyOdr : dlvyOdrData) {
                 if (StringUtils.isNotBlank(dlvyOdr.getDrverTlphonNo())) {
                     dlvyOdr.setDrverTlphonNo(StringUtil.formatPhone(CryptoUtil.decryptAES256(dlvyOdr.getDrverTlphonNo()))); //복호화
                 }

                sb.append("<tr>");
                sb.append("    <td align=\"center\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">"+dlvyOdr.getDlvyOdr()+"</td>");
                sb.append("    <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">"+dlvyOdr.getDlivyComptDt()+"</td>");
                sb.append("    <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">"+dlvyOdr.getWt()+"</td>");
                sb.append("    <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">"+dlvyOdr.getTrnsprtCmpnyNm()+"</td>");
                sb.append("    <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">"+dlvyOdr.getDrverNm()+"</td>");
                sb.append("    <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">"+dlvyOdr.getVhcleNo()+""+dlvyOdr.getVhcleKind()+"</td>");
                sb.append("    <td align=\"center\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">"+dlvyOdr.getDrverTlphonNo()+"</td>");
                sb.append("</tr>");
            }//for

            sb.append("</tbody>");
            sb.append("</table>");

            odrMap.put("dlvyOdrInfo", sb.toString());
        }
    }

    private String getOdrDtlsInfoData(OdrDtlVO odrData) throws Exception {
        // 결제수단에 따른 동적 html 세팅
        String targetHtml = getOdrDtlsHtml(odrData.getSetleMthdCode(), Long.parseLong(odrData.getExcclcAmount().replaceAll(",","")));

        Field[] fields = OdrDtlVO.class.getDeclaredFields();
        for (Field field : fields) {
            field.setAccessible(true);

            Object tmpValue = field.get(odrData);
            String key = field.getName();
            String value = "";

            if (tmpValue != null) {
                value = tmpValue.toString();
            }
            targetHtml = targetHtml.replace(key, value); // 데이터 치환
        }

        return targetHtml;
    }

    private String getOdrSetleInfoData(OdrDtlVO odrData, int tmptNo) throws Exception {
        String targetTmplat = "";
        String setleMthCode = odrData.getSetleMthdCode();

        // 2023-12-06 변경사항 : 평균가 판매방식 추가에 따른 메세지 포멧 변경
        // 1. 기본 문구 세팅
        String goodsUntPcString = "결제단가 : goodsUntpc";
        String slepc = "주문금액 : slepc";
        String excclcAmountString = "정산금액 : excclcAmount";
        String avrgpcGoodsUntpc = odrData.getAvrgpcGoodsUntpc();
        String setlePrearngeDe = "결제예정일 : setlePrearngeDe";

        // 템플릿 19이고 미결제금액이 존재하고, 추가 금액이 존재할 경우
        if(tmptNo == 19 && !StringUtils.equals("0", odrData.getUnSetleAmount()) && !StringUtils.equals("0", odrData.getAditAmount())) {
        	excclcAmountString = "정산금액 : 0 (추가결제금액 : " + odrData.getAditAmount() + ")";
        }

        // 부분출고일 경우
        if(tmptNo == 146) {
        	if("P".equals(odrData.getRepyComptCode())) {
        		// 미출고상환 이후 들어온 확정데이터일 경우, '상환금액확정' 영역 전체 미표기
        		return targetTmplat;
        	} else {
        		// 타이틀 설정
        		targetTmplat += "\r\n* 상환금액확정\r\n";
        		// 정산금액 미표기
        		excclcAmountString = "";
        		setlePrearngeDe += "\r\n"; // 개행처리
        	}
        }

        // 2. 평균가(04) 또는 평균가-LIVE(0104) 주문일 경우, 세팅된 문구 추가 또는 바꿔치기
        // 24-02-19 변경사항 : 평균가-지정가(0304) 주문도 해당 로직 수행하도록 조건 추가
        if(StringUtils.equals("04", odrData.getSleMthdCode())
        		|| StringUtils.equals("0104", odrData.getSleMthdDetailCode())
        		|| StringUtils.equals("0304", odrData.getSleMthdDetailCode())
    			|| StringUtils.equals("05", odrData.getSleMthdCode())) {
        	if(StringUtils.isNotEmpty(avrgpcGoodsUntpc) && !StringUtils.equals("0", avrgpcGoodsUntpc)) {
        		if(StringUtils.isNotEmpty(odrData.getGoodsUntpc()) && !StringUtils.equals("0", odrData.getGoodsUntpc())) {
        			goodsUntPcString +=  " (가단가 : " + avrgpcGoodsUntpc + ")";
        		} else {
        			goodsUntPcString = "결제단가 : " + avrgpcGoodsUntpc + "(가단가)";
        		}

        		slepc = "주문금액 : avrgpcSlepc";
        	}

        	excclcAmountString = commAvrgpcOrderService.getExcclcInfoString(odrData.getOrderNo());
        }

        /** 결제 수단에 따른 SMS 템플릿 설정 */
        /* 전자상거래보증 or 케이지크레딧 */
        if ("20".equals(setleMthCode) || "40".equals(setleMthCode)) {
            targetTmplat += "결제 방법 : payMethod\r\n" + goodsUntPcString + "\r\n" + "배송비 : expectDlvrf\r\n"
                    + slepc + "\r\n" + (StringUtils.isNotEmpty(excclcAmountString) ? excclcAmountString + "\r\n" : "") + "결제예정금액 : nrdmpAmount\r\n"
                    + setlePrearngeDe;
        }
        /* 증거금 */
        else if("90".equals(setleMthCode)){
            targetTmplat += "결제 방법 : payMethod\r\n"+ goodsUntPcString +"\r\n배송비 : expectDlvrf\r\n주문금액 : slepc\r\n"
                    + "결제금액(1차) : frstSetleAmount\r\n결제금액(2차) : setlePrearngeAmount\r\n" + excclcAmountString;
        }
        /* 이월렛단독 */
        else {
            targetTmplat += "결제 방법 : payMethod\r\n" + goodsUntPcString + "\r\n" + "배송비 : expectDlvrf\r\n"
                    + slepc + "\r\n" + excclcAmountString;
        }

        /** 템플릿에 결제정보 담기 */
        Field[] fields = OdrDtlVO.class.getDeclaredFields();
        for (Field field : fields) {
            field.setAccessible(true);

            Object tmpValue = field.get(odrData);
            String key = field.getName();
            String value = "";

            if (tmpValue != null) {
                value = tmpValue.toString();
            }
            targetTmplat = targetTmplat.replace(key, value); // 데이터 치환
        }

        return targetTmplat;
    }

    // 고객 대상 메세지 발송 메소드 : 결제예정일 변경안내(전자상거래보증 or 케이지크레딧)
    private void sendMessageSetlePrearngeDeChange(String orderNo, String originSetlePrearngeDe, ExcclcInfoVO excclcInfoVO) throws Exception {
    	// 주문 Data만 Select
        OdrDtlVO mrtggData = loMapper.selectMrtggDataForSms(orderNo, originSetlePrearngeDe, excclcInfoVO.getExcclcAmount());
        // OR_ORDER_BAS(주문_주문 기본)-ORDRR_MOBLPHON_NO(주문자 휴대폰 번호) 복호화
        String ordrrMoblphonNo = mrtggData.getOrdrrMoblphonNo();
        if (StringUtils.isNotEmpty(ordrrMoblphonNo)) {
            try {
                log.debug("주문자 휴대폰 번호 복호화 전 ==================>" + ordrrMoblphonNo);
                ordrrMoblphonNo = CryptoUtil.decryptAES256(ordrrMoblphonNo);
                log.debug("주문자 휴대폰 번호 복호화 후 ==================>" + ordrrMoblphonNo);
                /** 주문자 휴대폰 번호 셋팅 **/
                mrtggData.setOrdrrMoblphonNo(StringUtil.formatPhone(ordrrMoblphonNo));
            } catch (Exception e) {
                log.error("LoServiceImpl sendMessageToCustomer ORDRR_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR "
                        + e.getMessage());
            }
        }

        Map<String, String> mrtggMap = objectMapper.convertValue(mrtggData, Map.class);
        mrtggMap.put("orderNo", commAvrgpcOrderService.getOrderInfoString(orderNo, null));
        mrtggMap.put("templateNum", "74"); // 전자상거래보증 결제예정일 변경안내
        mrtggMap.put("Servicedomain", "https://m.kztraders.com");
        // null 데이터 빈 값으로 처리
        mrtggMap.forEach((key, value) -> {
            if (StringUtils.isEmpty(value) || StringUtils.equals("0", value)) {
                mrtggMap.replace(key, "");
            }
        });

		SMSVO smsVo = new SMSVO();
        smsVo.setPhone(mrtggData.getOrdrrMoblphonNo().replace("-", ""));
        smsVo.setMberNo(mrtggData.getMberNo());
        smsVo.setMberKndSeCode(mrtggData.getMberSeCode());
        // 커머스알림설정
        smsVo.setCommerceNtcnAt("Y");
        mrtggMap.put("commerceNtcnCn", "[케이지트레이딩] " + mrtggData.getPayMethod()+ " 주문건에 대한 결제예정일이 변경되었습니다.");

        smsService.insertSMS(smsVo, mrtggMap);
    }

    // OMS 전송 실패시 내부사용자 메세지 발송
    private void sendMessageOmsFail(String orderNo) throws Exception {
    	log.info(">> 물류 OMS 전송 실패로 SMS 발송 :: [" + orderNo + "]");

    	Map<String, String> smsMap = new HashMap<>();
		smsMap.put("templateNum", "44");					// [44] 물류(결제정보) 송신 실패
		smsMap.put("orderNo", orderNo); 			// 주문번호
		smsMap.put("returnMsg", "물류 OMS번호 수신 실패"); 		// 주문 데이터 물류IF시 오류 발생
		smsMap.put("commerceNtcnCn", "물류(결제정보) 송신 실패");  // 알림 메세지

		// 내부사용자 별도 전송
		smsMap.put("commerceNtcnAt", "Y"); 					// 추가 수신사 커머스 알림 여부 따로 설정
		smsMap.put("excpSndngOptnAt", "Y"); 				// 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.

		smsService.insertSMS(null, smsMap);
    }

    // 중량 변동금 자동 환불 처리 메소드
    @Override
    public void atmcRefndProcess(String orderNo, String intrfcId, boolean isRetry) throws Exception {
        log.debug(":: 중량 변동금 환불 & 수정세금계산서 발행 PROCESS START ");

        // 0. 환불 관련 데이터 select(공통)
    	OrOrderBasVO orderInfo = loMapper.selectOrOrderBasInfo(orderNo); 		  // 주문 정보 조회: 결제 방식 코드, 상품단가(확정단가), 가단가 조회 등
        ExcclcInfoVO excclcInfoVO = getExcclcInfo(orderNo, orderInfo, intrfcId);  // 정산 데이터 세팅

        // 1. 환불 정보/배송 완료 일자 Update(공통)
        // 2024-04-15: 고객이 추가 납입해야 하는 경우, [추가 금액/미결제 금액/결제 예정일] Update
        loMapper.updateExcclcInfo(excclcInfoVO);
        loMapper.insertOrOrderBasHst(orderNo);

    	/**
            결제 방식에 따른 환불처리 분기처리
            SETLE_MTHD_CODE(결제방식 코드) >> 10:이월렛, 20:전자상거래보증, 40:케이지크레딧, 90:증거금

            결제 방식이 "전자상거래보증 or 케이지크레딧"일 경우 정산 시 "MP로 상환" 된다. (이월렛 환불X)
            그 외의 경우는 "이월렛 환불" 처리 된다.
         */
        String setleMthd = orderInfo.getSetleMthdCode(); // 결제 방식 코드
        if(excclcInfoVO.getExcclcAmount() == null) {
        	excclcInfoVO.setExcclcAmount((long) 0); // 데이터 없을 경우, 기본값 0으로 설정(null exception 방지)
    	}

        /** 결제방식 : 전자상거래보증 or 케이지크레딧 */
        if ("20".equals(setleMthd) || "40".equals(setleMthd)) {
        	 // 2. 수정 세금계산서 발행(공통)
             taxbillIsue(excclcInfoVO);

            // 3. 결제예정일 업데이트 : 수정 세금계산서 발행시점+상환기간
            // 기존 결제예정일 != 변경예정 결제예정일 경우 :
            // (1) 담보_기본 결제예정일 UPDATE
            // (2) 결제예정일 변경안내 SMS발송
            // 2022.09 재처리가 아닐 때만 처리함
            if (!isRetry) {
	           updateMrtggSetlePrearngeDeProcess(orderNo, intrfcId, excclcInfoVO);
            }

            // 4. 담보 관련 프로세스 호출(MP상환)
	       	Map<String, Object> mrtggMap = new HashMap<String, Object>();
	        mrtggMap.put("mrtggSttusCode", "30"); // 담보 상태 코드 : 30-부분상환
	        mrtggMap.put("repySeCode", "01"); // 상환 구분 코드 : 01-중량정산
	        mrtggMap.put("orderNo", orderNo); // 주문 번호

	        Map<String, Object> resObj = httpClientHelper.postCallApi(mrtggTrnsmisUrl, mrtggMap);
            if (resObj != null && !APICommConstant.SUCCESS_RESULT_CODE.equals(resObj.get("rspnsCode"))) {
                log.debug("전자상거래보증 MP 중량정산 상환 성공");
            }
        }
        /** 결제방식 : 이월렛단독 or 증거금(이월렛, 대출보증) */
        else {
            // 2. 이월렛 환불처리
            ewalletTransfer(intrfcId, excclcInfoVO);
            
            // 24-10-24 변경사항 : 가단가 주문(05)의 추가 입금 금액이 존재할 경우, 기존 프로세스의 정산 금액과 추가 변동금에 대한 증적이 되는 데이터를 DB에 insert 한다.
    		if(excclcInfoVO.getAditRcpmnyAmount() != 0 							// 가단가 주문(05) 이면서, 환불해줘야하는 추가 입금 금액이 존재
    				&& StringUtils.equals(excclcInfoVO.getRefndSeCode(), "03")	// 환불 구분 코드 - [03: 중량/단가환불]
    				&& excclcInfoVO.getSetleNo() != null) {						// 이월렛 환불처리시 생성된 결제 번호 필요
    			insertOrDelngInfoDtl(intrfcId, excclcInfoVO);
    		}

            // 3. 수정 세금계산서 발행(공통)
            taxbillIsue(excclcInfoVO);
        }

        log.debug(":: 중량 변동금 환불 & 수정세금계산서 발행 PROCESS END");
    }

	/**
	 * <pre>
	 * 처리내용: 주문_거래 정보 상세 테이블에 증적 Data를 insert 한다.
	 * </pre>
	 * @date 2024. 10. 24.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 10. 24.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param intrfcId
	 * @param excclcInfoVO
	 * @throws Exception
	 */
	private void insertOrDelngInfoDtl(String intrfcId, ExcclcInfoVO excclcInfoVO) throws Exception {
		CommPrvsnlOrderVO commPrvsnlOrderVO = new CommPrvsnlOrderVO();
		
		commPrvsnlOrderVO.setOrderNo(excclcInfoVO.getOrderNo());
		commPrvsnlOrderVO.setSetleNo(excclcInfoVO.getSetleNo());
		commPrvsnlOrderVO.setMberId(intrfcId);	// 최초 등록자, 최종 변경자
		
		// 증적 1. 중량/단가 정산 금액
		commPrvsnlOrderVO.setDelngAmount(excclcInfoVO.getExcclcAmount());	// 거래 금액 = 중량/단가 정산 금액
		commPrvsnlOrderVO.setDelngDetailSeCode("10");  // 거래 상세 구분 코드 - [10: 정산]
		commPrvsnlOrderMapper.insertOrDelngInfoDtl(commPrvsnlOrderVO);
		commonService.insertTableHistory("OR_DELNG_INFO_DTL", commPrvsnlOrderVO);
		
		// 증적 2. 추가 변동금의 총합
		commPrvsnlOrderVO.setDelngAmount(excclcInfoVO.getAditRcpmnyAmount());	// 거래 금액 = 추가 변동금의 총합
		commPrvsnlOrderVO.setDelngDetailSeCode("20");  // 거래 상세 구분 코드 - [20: 변동금]
		commPrvsnlOrderMapper.insertOrDelngInfoDtl(commPrvsnlOrderVO);
		commonService.insertTableHistory("OR_DELNG_INFO_DTL", commPrvsnlOrderVO);
	}

    // 정산 데이터 세팅 (가단가 or 확정가 고려)
    private ExcclcInfoVO getExcclcInfo(String orderNo, OrOrderBasVO order, String intrfcId) throws Exception {
    	// 기본 정산 데이터 조회
    	// 24-10-24 변경사항 : 이월렛으로 결제된 가단가 주문(05)의 추가 입금 금액(ADIT_RCPMNY_AMOUNT)도 조회하도록 쿼리문 수정
    	ExcclcInfoVO excclcInfoVO = loMapper.selectExcclcInfo(orderNo);
    	excclcInfoVO.setOrderNo(orderNo);

    	// 중량 정산 금액
    	long wtExcclcAmount = 0;

    	// 정산 공급가, 부가세, 최종 금액
		long excclcSplpc = 0;
		long excclcVat = 0;
    	long excclcAmount = 0;

    	// 수정 세금계산서 발행 여부: 확정가, 확정중량 존재할 경우에만 가능
    	boolean taxbillIssueYn = false;

    	if(order.getAvrgpcGoodsUntpc() > 0) {
    		/** [가단가] 주문 **/

    		// 주문 시점 가격 (가단가, 가중량)
    		// 24-10-23 변경사항 : 가단가 주문(05)의 가격변동금(pcChangegld)도 주문 시점 가격에 포함되도록 변경
    		long orderPc = order.getTotOrderWt().multiply(BigDecimal.valueOf(order.getAvrgpcGoodsUntpc())).add(BigDecimal.valueOf(order.getPcChangegld())).longValue();

    		long wtPc = 0; 			// 중량정산 시점 가격
    		long goodsUntpc = 0; 	// 현 시점의 상품단가 (확정가 or 가단가)

    		if(order.getGoodsUntpc() > 0) {
    			// [CASE 1] 현 시점에 확정가 : 주문 > 단가정산 > 중량정산(현재)
    			goodsUntpc = order.getGoodsUntpc();

    			wtPc = order.getTotDcsnWt().multiply(BigDecimal.valueOf(goodsUntpc)).longValue();   // 중량정산 시점 가격 (확정가, 확정중량)

    			// 중량정산 대상금액 = 중량정산 시점 가격 - 단가정산 시점 가격
    			wtExcclcAmount = Math.abs((order.getTotDcsnWt().subtract(order.getTotOrderWt())).multiply(BigDecimal.valueOf(goodsUntpc)).longValue()); // 절대값으로 금액계산 후 부호처리
    			wtExcclcAmount = Math.round(wtExcclcAmount * 1.1) * (order.getTotDcsnWt().compareTo(order.getTotOrderWt()) < 0 ? -1 : 1); // 부가세 10% * 부호처리

				// 최종 등록할 정산 데이터 : 확정가, 확정중량이 나온 case이므로 데이터 등록 진행
    			excclcSplpc = Math.abs(wtPc - orderPc); // 절대값으로 금액계산 후 부호처리
    			excclcVat = Math.round(excclcSplpc * 0.1);
    			excclcAmount = Math.round(excclcSplpc * 1.1);

    			// 확정가일 경우, 총 확정 주문 가격/총 확정 공급가 데이터 함께 등록(이전에 확정가 없어서 데이터 미등록 상태임)
    		    long totDcsnOrderPc = order.getTotDcsnWt().multiply(BigDecimal.valueOf(goodsUntpc)).longValue();
    		    long totDcsnSplpc = totDcsnOrderPc + order.getExpectDlvrf();
    		    excclcInfoVO.setSeCode("Y");

    		    // 1. 중량정산 데이터 세팅(SKIP) 및 등록
    		    excclcInfoVO.setWtExcclcAmount(wtExcclcAmount);
    			excclcInfoVO.setSetleSttusCode("99");  // 결제 상태 코드 - [99: SKIP]
    			excclcInfoVO.setRefndSeCode("01");	   // 환불 구분 코드 - [01: 중량환불]

				if (!"20".equals(order.getSetleMthdCode()) && !"40".equals(order.getSetleMthdCode())) {
    				insertEwalletSetle(intrfcId, excclcInfoVO);
    			}

    			// 2. 최종 정산 데이터 재세팅
				int sign = -1;
    			if(wtPc - orderPc >= 0) {
    				// 돌려줄 금액이 없는 경우(고객이 추가입금 필요)
    				sign = 1;
    			}

    			excclcInfoVO.setExcclcSplpc(excclcSplpc * sign);
    			excclcInfoVO.setExcclcVat(excclcVat * sign);
    			excclcInfoVO.setExcclcAmount(excclcAmount * sign);
    			excclcInfoVO.setTotDcsnOrderPc(totDcsnOrderPc);
    			excclcInfoVO.setTotDcsnSplpc(totDcsnSplpc);
    			
    			// 24-10-24 변경사항 : 가단가 주문(05)에서 발생한 추가 변동금을 이월렛(10)으로 입금받은 금액도 정산 금액으로 포함시키는 로직 추가
    			//																여신(20,40)으로 처리된 추가 변동금은 현 로직(자동 정산)에서 처리 하지 아니함
    			//				최종 정산 금액 = 중량/단가 정산 금액 + 입금 받은 추가 변동금의 총합(=추가 입금 금액)
    			excclcInfoVO.setLastExcclcAmount(excclcInfoVO.getExcclcAmount() + excclcInfoVO.getAditRcpmnyAmount()); 

    			if (excclcInfoVO.getLastExcclcAmount() >= 0) { // 거래금액이 음수(고객이 추가 결제)라면
        			excclcInfoVO.setSetleSttusCode("04");  // 결제 상태 코드 - [04: 실패(거래금액 음수)]

        			// SORIN_SETUP_CODE: 추가 금액 유예 기간 조회
        			CommonCodeVO aditAmountPostpnePdInfo = Optional.ofNullable(commonCodeService.getCodeValueRetVo("SORIN_SETUP_CODE", "ADIT_AMOUNT_POSTPNE_PD")).orElse(new CommonCodeVO());
        			int aditAmountPostpnePd = Optional.ofNullable(Integer.parseInt(aditAmountPostpnePdInfo.getCodeDcone())).orElse(0);
        			excclcInfoVO.setAditAmountPostpnePd(aditAmountPostpnePd+1); // 당일 미포함이므로 +1
                } else {
                	excclcInfoVO.setSetleSttusCode("01");  // 결제 상태 코드 - [01: 요청]
                }
    			excclcInfoVO.setRefndSeCode("03");	       // 환불 구분 코드 - [03: 중량/단가환불]

    			taxbillIssueYn = true;
    		} else {
    			// [CASE 2] 현 시점에 가단가 : 주문 > 중량정산(현재) > 단가정산(예정)
    			// 확정가 나오지 않은 시점이므로, 주문 테이블에 데이터는 등록하지 않음
    			goodsUntpc = order.getAvrgpcGoodsUntpc();

    			// 중량정산 대상금액 = 중량정산 시점 가격(가단가, 확정중량) - 주문 시점 가격
    			wtExcclcAmount = (order.getTotDcsnWt().subtract(order.getTotOrderWt())).multiply(BigDecimal.valueOf(goodsUntpc)).longValue();
    			wtExcclcAmount = Math.round(wtExcclcAmount * 1.1); // 부가세 10%

    			// 중량정산 데이터 세팅(SKIP)
    			excclcInfoVO.setWtExcclcAmount(wtExcclcAmount);
    			excclcInfoVO.setSetleSttusCode("99"); // 결제 상태 코드 - [99: SKIP]
    			excclcInfoVO.setRefndSeCode("01");	  // 환불 구분 코드 - [01: 중량환불]
    		}
    	} else {
    		/** [확정가] 주문 **/
    		excclcInfoVO.setWtExcclcAmount((long) 0);  // 기본값 0으로 설정(null exception 방지)
    		
    		// 24-10-24 변경사항 : 가단가 주문(05)에서 추가된 "최종 정산 금액"에 대응하는 세팅 로직 추가
    		excclcInfoVO.setLastExcclcAmount(excclcInfoVO.getExcclcAmount());

    		if (excclcInfoVO.getExcclcAmount() >= 0) { // 거래금액이 음수(고객이 추가 결제)라면
    			excclcInfoVO.setSetleSttusCode("04");  // 결제 상태 코드 - [04: 실패(거래금액 음수)]

    			// SORIN_SETUP_CODE: 추가 금액 유예 기간 조회
    			CommonCodeVO aditAmountPostpnePdInfo = Optional.ofNullable(commonCodeService.getCodeValueRetVo("SORIN_SETUP_CODE", "ADIT_AMOUNT_POSTPNE_PD")).orElse(new CommonCodeVO());
    			int aditAmountPostpnePd = Optional.ofNullable(Integer.parseInt(aditAmountPostpnePdInfo.getCodeDcone())).orElse(0);
    			excclcInfoVO.setAditAmountPostpnePd(aditAmountPostpnePd+1); // 당일 미포함이므로 +1
            } else {
            	excclcInfoVO.setSetleSttusCode("01");  // 결제 상태 코드 - [01: 요청]
            }
    		excclcInfoVO.setRefndSeCode("01");		   // 환불 구분 코드 - [01: 중량환불]

    		taxbillIssueYn = true;
    	}

    	excclcInfoVO.setLastChangerId(intrfcId);
    	excclcInfoVO.setTaxbillIssueYn(taxbillIssueYn);

    	log.info("[LoServiceImpl] getExcclcInfo >> " + excclcInfoVO.toString());
    	return excclcInfoVO;
	}

	// 이월렛 환불
    private void ewalletTransfer(String intrfcId, ExcclcInfoVO excclcInfoVO) throws Exception {
    	/* 2024-05-02: 거래금액이 음수(고객이 추가 결제)일때는 주문_결제 기본 테이블에 Data 넣지 않는다. */
    	if(!StringUtils.equals("04", excclcInfoVO.getSetleSttusCode())) {
    		try {
	        	// 2-1. 주문_결제 기본 테이블에 환불 Data insert
	        	OrSetleBasVO orSetleBasVo = insertEwalletSetle(intrfcId, excclcInfoVO);

	            // 2-2. E-Wallet 환불 처리
	            /**
	             * iemSeCode : 0001(물품구매), 0002(환불), 0003(이체), 0004(기업뱅킹 환불) 0002 = 가상계좌 -> 고객계좌
	             * 0003 = 케이지트레이딩계좌 -> 가상계좌(고객)
	             *
	             * 22-03-03 추가 변경 사항 거래금액이 음수(고객이 추가 결제)일 경우 E-Wallet 환불 처리 요청을 안 함
	             * 24-01-06 이월렛 결제상태코드가 99(SKIP)일 경우 E-Wallet 환불 처리 요청을 안 함
	             */

	            if (excclcInfoVO.getExcclcAmount() < 0 && !StringUtils.equals(excclcInfoVO.getSetleSttusCode(), "99")) {
	                Map<String, Object> ewalletMap = new HashMap<String, Object>();
	                ewalletMap.put("entrpsNo", excclcInfoVO.getEntrpsNo());
	                ewalletMap.put("iemSeCode", "0003");
	                ewalletMap.put("ewalletExcclcTyCode", "04"); // E-Wallet 정산 유형 코드 04 : 중량정산
	                ewalletMap.put("setleNo", orSetleBasVo.getSetleNo());
	                ewalletMap.put("delngAmount", (-1) * excclcInfoVO.getLastExcclcAmount());
	                Map<String, Object> ewalletResMap = httpClientHelper.postCallApi(ewalletOrderUrl, ewalletMap);
	                log.debug(ewalletResMap.toString()); // log

	                // 이월렛 서버에서 결재테이블 정상 성공으로 업데이트 되었는지 체크, 실패일 시 세금계산서 처리를 안 함
	                if (null != ewalletResMap && StringUtils.equals("200", ewalletResMap.get("resultCode").toString())
	                        && ewalletResMap.get("data") != null) {
	                    boolean isSuccess = false;
	                    Map<String, Object> resultData = (Map<String, Object>) ewalletResMap.get("data");
	                    String delngSeqNo = String.valueOf(resultData.get("delngSeqNo"));

	                    for (int i = 0; i < ewalletTimeoutsec * 2; i++) {
	                        Thread.sleep(500);
	                        // 호출 건 응답 코드 확인
	                        String rspnsCode = loMapper.selectEwalletRspnCode(delngSeqNo);
	                        log.debug(">> rspnsCode : " + rspnsCode);
	                        if (!StringUtils.isEmpty(rspnsCode)) {
	                            // 응답 코드가 000 일때 거래 완료 -> 전문설계서 응답코드 확인
	                            if (StringUtils.equals(rspnsCode, "000")) {
	                                isSuccess = true;
	                            }
	                            log.debug(">> rspnsCode : " + rspnsCode + ", isSuccess : " + isSuccess);
	                            break;
	                        }
	                    } // end for
	                    log.debug(">> finally isSuccess : " + isSuccess);

	                    if (!isSuccess) {
	                        throw new Exception("이월렛 주문 실패");
	                    }
	                } else {
	                    throw new Exception("이월렛 호출 실패");
	                }
	            } else {
	                log.debug("거래금액 음수 or 결제상태코드 99(SKIP)로 이월렛 환불처리 PASS : " + excclcInfoVO.getExcclcAmount());
	            }
	        } catch (Exception e) {
	            throw new Exception("이월렛 환불처리 실패 :: " + e.getMessage());
	        }
        }
    }

    // 주문_결제 기본 테이블에 환불 Data insert
    private OrSetleBasVO insertEwalletSetle(String intrfcId, ExcclcInfoVO excclcInfoVO) throws Exception {
        String nowDate = DateUtil.getNowDate();
        String setleNo = nowDate + "-" + assignService.selectAssignValue("OR", "SETLE_NO", nowDate, excclcInfoVO.getMberNo(), 5);
        excclcInfoVO.setSetleNo(setleNo);

        // 중량변동 정산 금액이 존재할 경우, 가단가 주문이므로
        // 이월렛 결제상태코드가 99(SKIP)일 경우, 가단가 주문-중량정산 CASE이므로 중량정산에 대한 이력성 데이터를 등록한다.
        long delngAmount = 0;
    	if(StringUtils.equals(excclcInfoVO.getSetleSttusCode(), "99")) {
        	delngAmount = excclcInfoVO.getWtExcclcAmount();
        } else {
        	// 24-10-31 변경사항 : 가단가 주문(05)에서 추가된 "최종 정산 금액" 을 거래 금액으로 하도록 변경(excclcAmount -> lastExcclcAmount)
        	delngAmount = excclcInfoVO.getLastExcclcAmount();
    	}

        OrSetleBasVO orSetleBasVo = new OrSetleBasVO();
        orSetleBasVo.setSetleNo(setleNo);
        orSetleBasVo.setOrderNo(excclcInfoVO.getOrderNo());
        orSetleBasVo.setCanclExchngRtngudNo(excclcInfoVO.getCanclExchngRtngudNo());
        orSetleBasVo.setSetleSeCode("10"); // 결제 구분 코드 - 값 10 : 주문
        orSetleBasVo.setSetleTyCode("20"); // 결제 유형 코드 - 값 20 : 환불(케이지트레이딩계좌 ==> 가상계좌)
        orSetleBasVo.setSetleSttusCode(excclcInfoVO.getSetleSttusCode()); // 결제 상태 코드 - [01: 요청, 04: 실패(거래금액 음수), 99: SKIP]
        orSetleBasVo.setRefndSeCode(excclcInfoVO.getRefndSeCode()); // 환불 구분 코드 - [01: 중량환불, 03 : 중량/단가환불]
        orSetleBasVo.setDelngAmount(Long.toString((-1) * delngAmount)); // 정산(환불) 금액이 음수로 표기되므로, 양수 표기를 위해 -1을 곱해줌
        orSetleBasVo.setFrstRegisterId(intrfcId);
        orSetleBasVo.setLastChangerId(intrfcId);

        loMapper.insertEwalletSetle(orSetleBasVo);
        loMapper.insertOrSetleBasHst(orSetleBasVo);

        return orSetleBasVo;
	}

	// 수정 세금계산서 발행
    private void taxbillIsue(ExcclcInfoVO excclcInfoVO) throws Exception {
        try {
        	if(!excclcInfoVO.isTaxbillIssueYn()) {
        		log.info(">> 상품단가(확정단가) 데이터 미존재:: 수정세금계산서 발행 SKIP");
        	} else {
	        	// 2023-09-22 수정: 정산금액이 없을 경우 수정세금계산서를 발행하지 않는다. (즉, 주문시점 중량과 확정중량이 완전히 동일한 경우만 제외)
	        	if(excclcInfoVO.getExcclcAmount() != 0) {
		            TaxBillRequestVO taxReqVo = new TaxBillRequestVO();
		            taxReqVo.setOrderNo(excclcInfoVO.getOrderNo()); // 주문번호
		            taxReqVo.setCanclExchngRtngudNo(excclcInfoVO.getCanclExchngRtngudNo()); // 취소반품번호
		            taxReqVo.setJobSe("WT"); // 업무구분 : 중량

		            String res = taxbillService.taxBillIsu(taxReqVo);
		            if(StringUtils.equals(res, TaxBillCommConstant.SUCCESS_RESULT_MSG) || StringUtils.equals(res, TaxBillCommConstant.SKIP_RESULT_MSG)) {
		        		log.info("수정세금계산서 발행 성공 or skip res:: " + res);
		            } else {
		            	throw new Exception("수정세금계산서 발행 실패 res :: " + res);
		            }
	        	} else {
	        		log.info("정산금액 0으로 수정세금계산서 발행 skip");
	        	}
        	}
        } catch (Exception e) {
            log.info("LoServiceImpl : taxbillIsue >> " + e.getMessage());
        }
    }

    // 전자상거래보증 결제예정일 변경 : 변경될 결제예정일이 기존예정일과 다른 경우 반영한다.
    private void updateMrtggSetlePrearngeDeProcess(String orderNo, String intrfcId, ExcclcInfoVO excclcInfoVO) throws Exception {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");

        OrOrderBasVO mrtggInfo = loMapper.selectMrtggInfo(orderNo);                              // 전자상거래보증 데이터 조회
        String originSetlePrearngeDe = mrtggInfo.getSetlePrearngeDe();                           // 기존 결제예정일
        //String changeSetlePrearngeDe = loMapper.getChangeSetlePrearngeDe(mrtggInfo.getRepyPd()); // 수정세금계산서 발행시점 기준 변경예정 결제예정일
        String changeSetlePrearngeDe = loMapper.getChangeSetlePrearngeDe(Collections.singletonMap("repyPd", mrtggInfo.getRepyPd())); // 수정세금계산서 발행시점(포함) 기준 변경예정 결제예정일

        // 날짜 비교위해 데이터 convert
        Date date1 = simpleDateFormat.parse(originSetlePrearngeDe);
        Date date2 = simpleDateFormat.parse(changeSetlePrearngeDe);

        int compare = date1.compareTo(date2);
        if (compare != 0) { // 변경예정일이 기존예정일과 다름
            log.debug("전자상거래보증 결제예정일 변경 : " + originSetlePrearngeDe + " >> " + changeSetlePrearngeDe);
            OrOrderBasVO orderVO = new OrOrderBasVO();
            orderVO.setSetlePrearngeDe(changeSetlePrearngeDe);
            orderVO.setOrderNo(orderNo);
            orderVO.setLastChangerId(intrfcId);
            loMapper.updateOrMrtggSetlePrearngeDe(orderVO);                         			  //담보기본 결제예정일 업데이트
            loMapper.insertOrMrtggBasHst(mrtggInfo);                                			  //담보기본 이력 등록

            // 미결제금액 존재하는 경우만 sms 발송
            if(excclcInfoVO.getUnSetleAmount() > 0) {
            	this.sendMessageSetlePrearngeDeChange(orderNo, originSetlePrearngeDe, excclcInfoVO);  //sms 발송
            }
        }
    }

    // [물류 배송 차수] > [EC 배송 차수] 적용여부 체크 공통 메소드
    private String checkEcDlvyOdrApplcAt(String orderNo, String omsOrderNo, String lgistDlvyOdr) throws Exception {
    	int compare = -1;

    	// 1. SORIN_SETUP_CODE 설정값 조회: 다중 BL 적용 일시 이상 주문건들만 대상
    	CommonCodeVO applcInfo = Optional.ofNullable(commonCodeService.getCodeValueRetVo("SORIN_SETUP_CODE", "MULTI_BL_APPLC_YYYYMMDD")).orElse(new CommonCodeVO());
		String applcDe = Optional.ofNullable(applcInfo.getCodeDcone()).orElse("");
		if(StringUtil.isEmpty(applcDe)) {
			log.info("다중 BL 적용 일시(MULTI_BL_APPLC_YYYYMMDD) 정보 미존재");
			return "";
		}

		// 1-1. 주문일자와 다중BL적용일자 비교
		compare = compareDate(orderNo.substring(0,8) ,applcDe);
		if(compare < 0) {
			log.info("다중 BL 적용일자에 해당하는 주문건이 아님");
			return "";
		}

		// 2. BL 개수 조회: 다중 BL인 주문건을 대상으로 함
		int blCnt = loMapper.selectOrDtlBlList(orderNo).size();

		// 3-1. 1,2 번 조건을 만족하는 경우에만 [EC 배송 차수]로 변환 작업 실행
		if(compare >= 0 && blCnt > 1) {

			// 4. 이미 존재하는 or 신규 생성한 [EC 배송 차수] 데이터를 조회
	    	String ecDlvyOdr = loMapper.insertOrDlvyOdrMappingBas(orderNo, omsOrderNo, lgistDlvyOdr);
	    	log.info("[LoServiceImpl] [주문번호: " + orderNo + "] 기존배송차수: " + lgistDlvyOdr + " >> ec배송차수: " + ecDlvyOdr + " 로 변환");

	    	return ecDlvyOdr;

    	} else {

    		//3-2. 1, 2번에 해당하지 않는 경우에는 물류에서 전송된 [물류 배송 차수] 데이터를 그대로 사용
    		log.info("[LoServiceImpl] 기존배송차수 유지");
    		return "";
		}
    }

    // 날짜 비교: [0]-두 날짜가 같은 경우, [음수]-day1 < day2 , [양수]-day1 > day2
    private int compareDate(String strDate1, String strDate2) throws ParseException {
    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");

    	Date date1 = simpleDateFormat.parse(strDate1);
	    Date date2 = simpleDateFormat.parse(strDate2);

	    int compare = date1.compareTo(date2);

	    return compare;
    }

    // 결제수단에 따른 동적 html 설정
    private String getOdrDtlsHtml(String setleMthd, long excclcAmount) {
        StringBuilder sb = new StringBuilder();
        /* 전자상거래보증 or 케이지크레딧 */
        if ("20".equals(setleMthd) || "40".equals(setleMthd)) {
            sb.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"border-collapse:collapse; \" width=\"100%\">");
            sb.append(" <thead>");
            sb.append("     <tr style=\"height: 36px;\">");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">구분</th>");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">항목</th>");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">주문</th>");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">출고</th>");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">정산금액<br>(출고-주문)</th>");
            sb.append("     </tr>");
            sb.append(" </thead>");
            sb.append(" <tbody>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" rowspan=\"2\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; border-right: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><strong>주문정보</strong></td>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">수량</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">totRealOrderWt</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">totDcsnWt</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcWt</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">상품단가</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">goodsUntpc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">goodsUntpc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">&nbsp;</td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; border-right: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><strong>주문금액</strong></td>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">①상품금액</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">goodsPc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">goodsPc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcPc</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">②중량변동금</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">wtChangegld</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">-wtChangegld</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">③배송비</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">expectDlvrf</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">expectDlvrf</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid rgb(233, 233, 233); font-size: 12px; line-height: 24px;\"><font color=\"#fa5e38\"><b>excclcDlvyCt</b></font></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; border-right: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><strong>결제요청금액</strong></td>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">공급가액(①+②+③)</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">splpc</td>");
            sb.append("         <td align=\"right\" rowspan=\"3\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">계산서<br>발행 없음</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcSplpc</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">VAT</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">vat</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcVat</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">결제 요청금액</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">slepc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcAmount</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; border-right: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><strong>결제금액</strong></td>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">결제금액(1차)</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">-</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">결제금액(2차)</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">-</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");

            //중량정산 +/- 여부에 따라 분기
            if( excclcAmount > 0 ) {
                sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px; color: red;\">추가정산예정금액</td>");
            } else {
                sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">정산금액</td>");
            }

            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");

            //중량정산 +/- 여부에 따라 분기
            if( excclcAmount > 0 ) {
                sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: red; font-weight: bold;\">excclcAmount</span></td>");
            } else {
                sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcAmount</span></td>");
            }

            sb.append("     </tr>");
            sb.append("        <tr>");
            sb.append("         <td align=\"center\" rowspan=\"2\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; border-right: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><strong>결제예정금액</strong></td>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">결제예정일</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">frstSetlePrearngeDe</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">setlePrearngeDe</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">결제예정금액</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">setlePrearngeAmount</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">totDcsnOrderPc</span></td>");
            sb.append("     </tr>");
            sb.append(" </tbody>");
            sb.append("</table>");
        }
        /* 증거금 */
        else if ("90".equals(setleMthd)) {
            sb.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"border-collapse:collapse; \" width=\"100%\">");
            sb.append(" <thead>");
            sb.append("     <tr style=\"height: 36px;\">");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">구분</th>");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">항목</th>");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">주문</th>");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">결제(잔액결제)</th>");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">출고</th>");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">정산금액<br>(출고-주문)</th>");
            sb.append("     </tr>");
            sb.append(" </thead>");
            sb.append(" <tbody>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" rowspan=\"2\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; border-right: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><strong>주문정보</strong></td>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">수량</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">totRealOrderWt</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">totRealOrderWt</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">totDcsnWt</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcWt</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">상품단가</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">goodsUntpc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">goodsUntpc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">goodsUntpc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">&nbsp;</td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; border-right: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><strong>주문금액</strong></td>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">①상품금액</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">goodsPc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">goodsPc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">totDcsnOrderPc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcPc</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">②중량변동금</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">wtChangegld</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">wtChangegld</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">-wtChangegld</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">③배송비</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">expectDlvrf</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">expectDlvrf</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">expectDlvrf</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid rgb(233, 233, 233); font-size: 12px; line-height: 24px;\"><font color=\"#fa5e38\"><b>excclcDlvyCt</b></font></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; border-right: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><strong>결제요청금액</strong></td>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">공급가액(①+②+③)</td>");
            sb.append("         <td align=\"right\" rowspan=\"3\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">계산서<br>발행 없음</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">splpc</td>");
            sb.append("         <td align=\"right\" rowspan=\"3\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">계산서<br>발행 없음</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcSplpc</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">VAT</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">vat</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcVat</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">결제 요청금액</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">slepc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcAmount</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; border-right: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><strong>결제금액</strong></td>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">결제금액(1차)</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">frstSetleAmount</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">frstSetleAmount</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">-</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">결제금액(2차)</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">setlePrearngeAmount</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">-</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");

            //중량정산 +/- 여부에 따라 분기
            if( excclcAmount > 0 ) {
                sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px; color: red;\">추가정산예정금액</td>");
            } else {
                sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">정산금액</td>");
            }

            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");

            //중량정산 +/- 여부에 따라 분기
            if( excclcAmount > 0 ) {
                sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: red; font-weight: bold;\">excclcAmount</span></td>");
            } else {
                sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcAmount</span></td>");
            }

            sb.append("     </tr>");
            sb.append("        <tr>");
            sb.append("         <td align=\"center\" rowspan=\"2\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; border-right: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><strong>결제예정금액</strong></td>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">결제예정일</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">setlePrearngeDe</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">-</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">결제예정금액</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">setlePrearngeAmount</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">-</span></td>");
            sb.append("     </tr>");
            sb.append(" </tbody>");
            sb.append("</table>");
        }
        /* 이월렛 단독 */
        else {
            sb.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"border-collapse:collapse; \" width=\"100%\">");
            sb.append(" <thead>");
            sb.append("     <tr style=\"height: 36px;\">");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">구분</th>");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">항목</th>");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">주문</th>");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">출고</th>");
            sb.append("         <th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">정산금액(출고-주문)</th>");
            sb.append("     </tr>");
            sb.append(" </thead>");
            sb.append(" <tbody>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" rowspan=\"2\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; border-right: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><strong>주문 정보</strong></td>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">수량</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">totRealOrderWt</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">totDcsnWt</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcWt</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">상품단가</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">goodsUntpc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">goodsUntpc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">&nbsp;</td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; border-right: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><strong>결제 정보</strong></td>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">①상품금액</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">goodsPc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">totDcsnOrderPc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcPc</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">②중량변동금</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">wtChangegld</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">-wtChangegld</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">③배송비</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">expectDlvrf</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">expectDlvrf</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid rgb(233, 233, 233); font-size: 12px; line-height: 24px;\"><font color=\"#fa5e38\"><b>excclcDlvyCt</b></font></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; border-right: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><strong>계산서 정보</strong></td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">공급가액(①+②+③)</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">splpc</td>");
            sb.append("         <td align=\"right\" rowspan=\"3\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">계산서 발행 없음</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcSplpc</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">VAT</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">vat</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcVat</span></td>");
            sb.append("     </tr>");
            sb.append("     <tr>");
            sb.append("         <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">결제 요청금액</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">slepc</td>");
            sb.append("         <td align=\"right\" style=\"padding: 4px 10px 0 4px; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcAmount</span></td>");
            sb.append("     </tr>");
            sb.append(" </tbody>");
            sb.append("</table>");
        }

        return sb.toString();
    }

    @Override
    public boolean isAllRealInvntry(String orderNo) throws Exception {
        return loMapper.isAllRealInvntry(orderNo);
    }

    @Override
    public void dispatChange(DlvyOdrDtlVO dlvyOdrDtl) throws Exception {
        /** 통합 로그 INSERT **/
        String intrfc_code = "SOREC-IF-115";
        BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, dlvyOdrDtl);

        String intrfc_id = intrfc_code;

        intrfc_code += "(" + btbLogVo.getIntrfcNo() + ")";

        log.info("LoServiceImpl > dispatChange :: dlvyOdrDtl {}", dlvyOdrDtl);
        Map<String,Object> paramMap = new HashMap<>();
        try {
            /** 서비스 로직(interface table insert) **/
            /* 인터페이스 번호 등록 */
            dlvyOdrDtl.setIntrfcNo(btbLogVo.getIntrfcNo());
            /* 사용자 등록 */
            dlvyOdrDtl.setFrstRegisterId(intrfc_code);
            dlvyOdrDtl.setLastChangerId(intrfc_code);
            //전용 인터페이스 테이블 적재 ifLoMapper.insertLoDlvrgChangeBas(dlvrgChangeVO);
            paramMap.put("ecOrderNo",dlvyOdrDtl.getEcOrderNo());
            paramMap.put("dlvyOdr",dlvyOdrDtl.getDlvyOdr());
            paramMap.put("changeRequstCode",dlvyOdrDtl.getChangeRequstCode());
            paramMap.put("dlvyRqestde",dlvyOdrDtl.getDlvyRqestde());
            paramMap.put("lastChangerNm",dlvyOdrDtl.getLastChangerNm());

            Map<String, Object> response = this.extrlSysApiCall(intrfc_id, paramMap);
            log.debug("dispatChange response >>> " + response.toString());

            if("200".equals((String)response.get("rspnsCode"))) {
                loMapper.updateOrDlvyOdrBas(dlvyOdrDtl);        //주문_배송 차수 기본 기존 차량 정보 삭제
                loMapper.insertOrDlvyOdrBasHst(dlvyOdrDtl);     //주문_배송 차수이력 INSERT

                //loMapper.insertOrDlvyOdrBas(dlvyOdrDtl);        //주문_배송 차수 기본 UPDATE
                //loMapper.insertOrDlvyOdrBasHst(dlvyOdrDtl);     //주문_배송 차수이력 INSERT
            } else {
                throw new Exception("SOREC-IF-115 ERROR : " + (String)response.get("rspnsMssage"));
            }

            btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

        } catch (Exception e) {
            btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
            btbLogVo.setIntrfcRspnsCn(e.getMessage());
            throw new Exception(e.getMessage());
        } finally {
            /** 통합 로그 UPDATE **/
            httpClientHelper.updateBtbLog(btbLogVo);
        }
    }

}