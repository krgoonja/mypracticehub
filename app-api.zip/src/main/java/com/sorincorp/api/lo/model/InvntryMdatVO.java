package com.sorincorp.api.lo.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class InvntryMdatVO {
    /**
     * 인터페이스 순번
    */
	@ApiModelProperty(hidden = true)
    private long intrfcSn;
    /**
     * 인터페이스 번호
    */
	@ApiModelProperty(hidden = true)
    private long intrfcNo;
    /**
     * BL 번호
    */
    private String blNo;
    /**
     * 조정 LOT 수량
    */
    private int bundleQy;
    /**
     * 사유 코드
    */
    private String resnCode;
    /**
     * 사유 내용
    */
    private String resnCn;
    /**
     * 최초 등록자 아이디
    */
    @ApiModelProperty(hidden = true)
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    @ApiModelProperty(hidden = true)
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    @ApiModelProperty(hidden = true)
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    @ApiModelProperty(hidden = true)
    private String lastChangeDt;
 
}
