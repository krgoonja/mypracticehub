package com.sorincorp.api.lo.model;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class DlvyOdrBlDtlVO_02{
	/**
	 * 인터페이스 순번
	 */
	@ApiModelProperty(hidden = true)
	String intrfcSn;

	/**
	 * EC 주문 번호
	 */
	@ApiModelProperty(hidden = true)
	String ecOrderNo;

	/**
	 * 배송 차수
	 */
	@ApiModelProperty(hidden = true)
	String dlvyOdr;

	/**
	 * 확정중량 BL 상세 순번
	 */
	@ApiModelProperty(hidden = true)
	String dcsnWtBlDetailSn;

	/**
	 * BL 번호
	 */
	String blNo;
    /**
     * NET 확정 중량
    */
    java.math.BigDecimal blNetWt;
    /**
     * GROSS 확정 중량
    */
    java.math.BigDecimal blGrossWt;
	/**
	 * 확정 번들 수량
	 */
	String dcsnBundleQy;
	/**
	 * 아이템 코드
	 */
	String itmCode;
	/**
	 * 브랜드 코드
	 */
	String brandCode;
	/**
	 * 제품 명
	 */
	String prductNm;
	/**
	 * EC 주문 순번
	 */
	String ecOrderSn;
	/**
	 * 보관 일수
	 */
	String cstdyDaycnt;
	/**
	 * 보관 비용(요율표기준)
	 */
	String cstdyCt;
	/**
	 * 번들 리스트
	 */
	List<DlvyOdrBlDtlVO_03> bundleList;

	/** 최초 등록자 아이디* **/
	private String frstRegisterId;

	/** 최종 변경자 아이디* **/
	private String lastChangerId;
}
