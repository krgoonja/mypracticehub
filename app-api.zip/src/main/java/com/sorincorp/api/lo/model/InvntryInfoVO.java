package com.sorincorp.api.lo.model;

import lombok.Data;

@Data
public class InvntryInfoVO {
	/**
	 * BL 번호
	 */
	private String blNo	;
	/**
	 * 아이템 코드
	 */
	private String itmCode;
	/**
	 * 브랜드 코드
	 */
	private String brandCode;
	/**
	 * 중량
	 */
	private String wt;
	/**
	 * 수량(번들 수량)
	 */
	private String qy;
	/**
	 * 응답 코드
	 */
	private String rspnsCode;
	/**
	 * 응답 메세지
	 */
	private String rspnsMssage;
}
