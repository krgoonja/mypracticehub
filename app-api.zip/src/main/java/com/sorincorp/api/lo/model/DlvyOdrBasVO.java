package com.sorincorp.api.lo.model;

import java.util.List;

import lombok.Data;

@Data
public class DlvyOdrBasVO {
	
	private List<OrderNoDtlVO> orderNoList;

}
