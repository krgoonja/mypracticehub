package com.sorincorp.api.lo.model;

import lombok.Data;

@Data
public class VhcleInfoVO {
	/**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 주문 순번
    */
    private String orderSn;
    /**
     * 차량 주문 순번 (기존 배송 차수 [dlvyOdr] 이름 유지)
    */
    private int dlvyOdr;
}
