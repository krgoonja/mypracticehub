package com.sorincorp.api.lo.model;

import java.util.List;

import lombok.Data;
@Data
public class OrderNoDtlVO {
	
	/** EC 주문번호 **/
	private String ecOrderNo;
	
	/** OMS 주문번호 **/
	private String omsOrderNo;
	
	/** 배송차수 리스트 **/
	private List<DlvyOdrDtlVO> dlvyOdrList;

}
