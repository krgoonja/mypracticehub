package com.sorincorp.api.lo.model;

import java.util.List;

import lombok.Data;
@Data
public class DlvyOdrDtlVO {

	/** 인터페이스 번호 **/
	private int intrfcNo;

	/** EC 주문번호 **/
	private String ecOrderNo;

	/** OMS 주문번호 **/
	private String omsOrderNo;

	/** 배송 차수 **/
	private String dlvyOdr;

	/** 계획 번호 **/
	private String planNo;

	/** 배차 일시 **/
	private String caralcDt;

	/** 납기 예정 일자 **/
	private String dedtPrearngeDe;

	/** 차량 그룹 코드 **/
	private String vhcleGroupCode;

	/** 운송 회사 코드 **/
	private String trnsprtCmpnyCode;

	/** 운송 회사 명 **/
	private String trnsprtCmpnyNm;

	/** 운송 회사 전화 번호 **/
	private String trnsprtCmpnyTlphonNo;

	/** 차량 번호 **/
	private String vhcleNo;

	/** 기사 코드 **/
	private String articlCode;

	/** 기사 명 **/
	private String articlNm;

	/** 기사 전화 번호 **/
	private String articlTlphonNo;
	
	/* 인터페이스 구분 */
	private String intrfcSe;
	
	/** 주문 순번 리스트 **/
	private List<OrderSnDtlVO> orderSnList;

	/** 주문순번 **/
	private String orderSnJson;

	/*최초 등록자 아이디*/
	private String frstRegisterId;

	/*최종 변경자 아이디*/
	private String lastChangerId;

	/*변경 요청 코드( I, U, D)*/
	private String changeRequstCode;

	/** 마지막 수정자명 */
	private String lastChangerNm;

	/* 배송지 담당자*/
	private String dlvrgCharger;

	/*배송지 연락처*/
	private String dlvrgCttpc;

	/*배송 요청일 */
	private String dlvyRqestde;

	/*배송지*/
	private String dlvrg;
}