package com.sorincorp.api.lo.model;

import org.apache.commons.lang3.StringUtils;

import lombok.Data;

@Data
public class OdrDtlVO_02 {
	/**
	 * 배송 차수
	 */
	private String dlvyOdr;
	/**
	 * 출고 완료 일시
	 */
	private String dlivyComptDt;
	/**
	 * 중량
	 */
	private String wt;
	/**
	 * 운송 회사 명
	 */
	private String trnsprtCmpnyNm;
	/**
	 * 운전자 명
	 */
	private String drverNm;
	/**
	 * 차량 번호
	 */
	private String vhcleNo;
	/**
	 * 차량 종류
	 */
	private String vhcleKind;
	/**
	 * 기사 연락처
	 */
	private String drverTlphonNo;

	public void setVhcleKind(String vhcleKind) {
		if(!StringUtils.isEmpty(vhcleKind)) {
			this.vhcleKind = "<br>(" + vhcleKind + ")";
		}else {
			this.vhcleKind = "";
		}
	}
}
