package com.sorincorp.api.lo.mapper;

import org.apache.ibatis.annotations.Param;

import com.sorincorp.api.lo.model.AditDlvyOdrDtlVO_01;
import com.sorincorp.api.lo.model.AditDlvyOdrDtlVO_02;
import com.sorincorp.api.lo.model.AllInvntryVO;
import com.sorincorp.api.lo.model.AllInvntryVO_02;
import com.sorincorp.api.lo.model.ChangeDlvyMthdVO;
import com.sorincorp.api.lo.model.ChangeDlvyMthdVO_02;
import com.sorincorp.api.lo.model.CoCmmnCdDtlVO;
import com.sorincorp.api.lo.model.CorprEntrpsDtlVO;
import com.sorincorp.api.lo.model.DlvrgChangeVO;
import com.sorincorp.api.lo.model.DlvyOdrBlDtlVO_01;
import com.sorincorp.api.lo.model.DlvyOdrBlDtlVO_02;
import com.sorincorp.api.lo.model.DlvyOdrBlDtlVO_03;
import com.sorincorp.api.lo.model.DlvyOdrDtlVO;
import com.sorincorp.api.lo.model.DlvyProgrsResVO_03;
import com.sorincorp.api.lo.model.DlvyProgrsSttusVO;
import com.sorincorp.api.lo.model.DlvyTariffVO;
import com.sorincorp.api.lo.model.DlvyVhcleVO;
import com.sorincorp.api.lo.model.DlvyVhcleVO_02;
import com.sorincorp.api.lo.model.DlvyVhcleVO_03;
import com.sorincorp.api.lo.model.InvntryAsgnInfoVO;
import com.sorincorp.api.lo.model.InvntryBadnVO;
import com.sorincorp.api.lo.model.InvntryBadnVO_02;
import com.sorincorp.api.lo.model.InvntryMdatVO;
import com.sorincorp.api.lo.model.InvntryWrhousngVO_02;
import com.sorincorp.api.lo.model.InvntryWrhousngVO_03;
import com.sorincorp.api.lo.model.OrderSttusChgInfoVO;
import com.sorincorp.api.lo.model.RltmCapaVO;
import com.sorincorp.api.lo.model.RltmDlvyOdrDtlVO;
import com.sorincorp.api.lo.model.SetleInfoVO;
import com.sorincorp.api.lo.model.SetleInfoVO_02;
import com.sorincorp.api.lo.model.SetleInfoVO_03;
import com.sorincorp.api.lo.model.SetleInfoVO_04;
import com.sorincorp.api.lo.model.SignInfoVO;
import com.sorincorp.api.lo.model.WrhousDtlVO;
import com.sorincorp.api.lo.model.WrhousStdrChcyVO;

public interface IfLoMapper {

	void insertIfLoCorprEntrpsBas(CorprEntrpsDtlVO corprEntrpsDtl)  throws Exception;

	void insertIfLoCaralcInfoBas(DlvyOdrDtlVO dlvyOdrDtl)  throws Exception;

	void insertIfLoWrhousInfoBas(WrhousDtlVO wrhousDtl)  throws Exception;

	void insertIfLoCodeInfoBas(CoCmmnCdDtlVO coCmmnCdDtlVO) throws Exception;

	void insertIfLoDlvyCyBas(RltmDlvyOdrDtlVO rltmDlvyOdrDtlVO) throws Exception;

	void insertIfLoAllInvntryBas(AllInvntryVO loAllInvntryVO) throws Exception;

	void insertIfLoAllInvntryLotDtl(AllInvntryVO_02 loAllInvntryVO_02) throws Exception;

	void insertIfLoDlvySttusRltmBas(DlvyProgrsSttusVO dlvyProgrsSttusVO) throws Exception;

	void insertIfLoDcsnWtBas(DlvyOdrBlDtlVO_01 vo01) throws Exception;

	void insertIfLoDcsnWtBlDtl(DlvyOdrBlDtlVO_02 vo02) throws Exception;

	void insertIfLoDcsnWtLotDtl(DlvyOdrBlDtlVO_03 vo03) throws Exception;

	void insertIfLoAditCtBas(AditDlvyOdrDtlVO_01 aditDlvyOdrDtlVO_01) throws Exception;

	void insertIfLoAditCtDtl(AditDlvyOdrDtlVO_02 aditDlvyOdrDtlVO_02) throws Exception;

	void insertLoInvntryMdatBas(InvntryMdatVO InvntryMdatVO) throws Exception;

	void insertLoInvntryBadnBas(InvntryBadnVO invntryBadnVO_01) throws Exception;

	void insertLoInvntryBadnLotDtl(InvntryBadnVO_02 invntryBadnVO_02) throws Exception;

	void insertLoInvntryWrhousngBas(InvntryWrhousngVO_02 invntryWrhousngVO_02) throws Exception;

	void insertInvntryWrhousngLotDtl(InvntryWrhousngVO_03 invntryWrhousngVO_03) throws Exception;

	void insertLoSignInfoBas(SignInfoVO signInfoVO) throws Exception;

	void insertLoDlvrgChangeBas(DlvrgChangeVO dlvrgChangeVO) throws Exception;

	/* Interface SOREC-IF-114 start */
	/**
	 * <pre>
	 * 처리내용: 자차배송 차량정보 송신 시 인터페이스 차량 정보 기본 등록 후 인터페이스 순번 리턴
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param dlvyVhcleVO
	 * @throws Exception
	 */
	void insertLoVhcleInfoBas(DlvyVhcleVO dlvyVhcleVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 자차배송 차량정보 송신 시 인터페이스 차량 정보 BL 상세 등록 후 차량 정보 BL 상세 순번 리턴
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param dlvyVhcleVO_02
	 * @throws Exception
	 */
	void insertLoVhcleInfoBlDtl(DlvyVhcleVO_02 dlvyVhcleVO_02) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 자차배송 차량정보 송신 시 인터페이스 차량 정보 BL 차수 상세 등록
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param dlvyVhcleVO_03
	 * @throws Exception
	 */
	void insertLoVhcleInfoBlOdrDtl(DlvyVhcleVO_03 dlvyVhcleVO_03) throws Exception;
	/* Interface SOREC-IF-114 end */

	void insertLoInvntryChangeBas(ChangeDlvyMthdVO changeDlvyMthdVO) throws Exception;

	void insertLoInvntryChangeLotDtl(ChangeDlvyMthdVO_02 changeDlvyMthdVO_02) throws Exception;

	void updateLoInvntryChangeBas(@Param("intrfSn") long intrfSn, @Param("omsRceptNo") String omsRceptNo) throws Exception;

	void insertLoSetleInfoBas(SetleInfoVO setleInfoVO) throws Exception;

	void insertLoSetleInfoDtl(SetleInfoVO_02 setleInfoVO_02) throws Exception;

	void insertLoSetleInfoWonorderDtl(SetleInfoVO_03 setleInfoVO_03) throws Exception;

	void insertSetleInfoWonorderBundle(SetleInfoVO_04 setleInfoVO_04) throws Exception;

	void updateLoSetleInfoBasOmsRceptNo(SetleInfoVO setleInfoVO) throws Exception;

	void insertLoDlvySttusBas(DlvyProgrsResVO_03 dlvyProgrsResVO_03) throws Exception;

	void insertLoWrhousStdrChcy(WrhousStdrChcyVO wrhousStdrChcyVO) throws Exception;

	void insertLoDlvyTariffBas(DlvyTariffVO dlvyTariffVO) throws Exception;

	void insertLoOrderSttusChangeBas(OrderSttusChgInfoVO orderSttusChgInfoVO) throws Exception;

	void insertLoRltmCapaBas(RltmCapaVO rltmCapaVO) throws Exception;
	
	void insertLoInvntryAsgnBas(InvntryAsgnInfoVO invntryAsgnInfoVO) throws Exception;
}
