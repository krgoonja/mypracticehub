package com.sorincorp.api.lo.model;

import java.util.List;

import lombok.Data;

@Data
public class CoCmmnCdVO {

	/**
	 * 코드 리스트
	 */
	private List<CoCmmnCdDtlVO> codeList;
}
