package com.sorincorp.api.lo.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties({"intrfcSn", "setleInfoDetailSn", "wonorderDetailSn", "bundleDetailSn", "frstRegisterId", "frstRegistDt", "lastChangerId", "lastChangeDt"})
public class SetleInfoVO_04 {
    /**
     * 인터페이스 순번
    */
    private long intrfcSn;
    /**
     * 결제 정보 상세 순번
    */
    private long setleInfoDetailSn;
    /**
     * 원주문 상세 순번
    */
    private long wonorderDetailSn;
    /**
     * 번들 상세 순번
    */
    private long bundleDetailSn;
    /**
     * 번들 번호
    */
    private String bundleNo;
    /**
     * 번들 NET 중량
    */
    private java.math.BigDecimal bundleNetWt;
    /**
     * 번들 GROSS 중량
    */
    private java.math.BigDecimal bundleGrossWt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
 
}
