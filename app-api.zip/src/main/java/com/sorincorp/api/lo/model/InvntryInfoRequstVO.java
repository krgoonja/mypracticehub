package com.sorincorp.api.lo.model;

import lombok.Data;

@Data
public class InvntryInfoRequstVO {
	/**
	 * 창고 코드
	 */
	private String wrhousCode;
	/**
	 * 아이템 코드
	 */
	private String itmCode;
	/**
	 * BL 번호
	 */
	private String blNo;
}
