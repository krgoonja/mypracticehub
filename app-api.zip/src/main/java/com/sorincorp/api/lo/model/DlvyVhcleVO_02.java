package com.sorincorp.api.lo.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties({"intrfcSn", "vhcleInfoBlDetailSn", "frstRegisterId", "frstRegistDt", "lastChangerId", "lastChangeDt", "orderSn"})
public class DlvyVhcleVO_02 {
    /**
     * 인터페이스 순번
    */
    private long intrfcSn;
    /**
     * 차량 정보 BL 상세 순번
    */
    private long vhcleInfoBlDetailSn;
    /**
     * BL 번호
    */
    private String blNo;
    /**
     * 아이템 코드
    */
    private String itmCode;
    /**
     * 창고 코드
    */
    private String wrhousCode;
    /**
     * 권역 대분류 코드
    */
    private String lclsfDlivyDstrctCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * BL 중량
    */
    private java.math.BigDecimal blWt;
    /**
     * LOT 수량
    */
    private int bundleQy;
    /**
     * 주문 순번
     */
    private String orderSn;
    /**
     * 차량 리스트
     */
    private List<DlvyVhcleVO_03> vhcleList;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;

}
