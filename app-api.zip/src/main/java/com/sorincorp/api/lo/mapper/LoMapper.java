package com.sorincorp.api.lo.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sorincorp.api.credt.model.OrMrtggMdstrmRepyDtlVO;
import com.sorincorp.api.lo.model.AditDlvyOdrDtlVO_01;
import com.sorincorp.api.lo.model.AditDlvyOdrDtlVO_02;
import com.sorincorp.api.lo.model.ChangeDlvyMthdVO;
import com.sorincorp.api.lo.model.ChangeDlvyMthdVO_02;
import com.sorincorp.api.lo.model.CoCmmnCdDtlVO;
import com.sorincorp.api.lo.model.CorprEntrpsDtlVO;
import com.sorincorp.api.lo.model.DlvrgChangeVO;
import com.sorincorp.api.lo.model.DlvyOdrBlDtlVO_01;
import com.sorincorp.api.lo.model.DlvyOdrBlDtlVO_02;
import com.sorincorp.api.lo.model.DlvyOdrBlDtlVO_03;
import com.sorincorp.api.lo.model.DlvyOdrDtlVO;
import com.sorincorp.api.lo.model.DlvyProgrsReqVO_02;
import com.sorincorp.api.lo.model.DlvyProgrsResVO_03;
import com.sorincorp.api.lo.model.DlvyProgrsSttusVO;
import com.sorincorp.api.lo.model.DlvyTariffVO;
import com.sorincorp.api.lo.model.DlvyVhcleVO;
import com.sorincorp.api.lo.model.DlvyVhcleVO_02;
import com.sorincorp.api.lo.model.DlvyVhcleVO_03;
import com.sorincorp.api.lo.model.ExcclcInfoVO;
import com.sorincorp.api.lo.model.FlsOrderAsgnCanclVO;
import com.sorincorp.api.lo.model.InvntryAsgnInfoVO;
import com.sorincorp.api.lo.model.InvntryRecoverVO;
import com.sorincorp.api.lo.model.InvntryWrhousngVO_02;
import com.sorincorp.api.lo.model.InvntryWrhousngVO_03;
import com.sorincorp.api.lo.model.OdrDtlVO;
import com.sorincorp.api.lo.model.OdrDtlVO_02;
import com.sorincorp.api.lo.model.OrSetleBasVO;
import com.sorincorp.api.lo.model.OrderDlvyMthdChangeVO;
import com.sorincorp.api.lo.model.OrderSttusChgInfoVO;
import com.sorincorp.api.lo.model.RltmDlvyOdrDtlVO;
import com.sorincorp.api.lo.model.SetleInfoVO;
import com.sorincorp.api.lo.model.SetleInfoVO_02;
import com.sorincorp.api.lo.model.SetleInfoVO_03;
import com.sorincorp.api.lo.model.SetleInfoVO_04;
import com.sorincorp.api.lo.model.SignInfoVO;
import com.sorincorp.api.lo.model.WrhousDtlVO;
import com.sorincorp.api.lo.model.WrhousStdrChcyVO;
import com.sorincorp.api.or.model.OrOrderBasVO;

public interface LoMapper {

	void insertLoCorprEntrpsBas(CorprEntrpsDtlVO corprEntrpsDtl)  throws Exception;
	void insertLoCorprEntrpsBasHst(CorprEntrpsDtlVO corprEntrpsDtl)  throws Exception;

	void insertOrDlvyOdrBas(DlvyOdrDtlVO dlvyOdrDtl)  throws Exception;
	void insertOrDlvyOdrBasHst(DlvyOdrDtlVO dlvyOdrDtl)  throws Exception;
	void updateOrDlvyOdrBas(DlvyOdrDtlVO dlvyOdrDtl)  throws Exception;
	void insertLoWrhousInfoBas(WrhousDtlVO wrhousDtl)  throws Exception;
	void insertLoWrhousInfoBasHst(WrhousDtlVO wrhousDtl)  throws Exception;

	void insertCoCmmnCd(CoCmmnCdDtlVO coCmmnCdDtlvo)  throws Exception;
	void insertCoCmmnCdHst(CoCmmnCdDtlVO coCmmnCdDtlvo)  throws Exception;

	int insertRltmOrDlvyOdrBas(RltmDlvyOdrDtlVO rltmDlvyOdrDtlVO) throws Exception;
	int insertRltmOrDlvyOdrBasHst(RltmDlvyOdrDtlVO rltmDlvyOdrDtlVO) throws Exception;

	int insertAditOrDlvyOdrBas(AditDlvyOdrDtlVO_01 aditdlvyodrdtlvo01) throws Exception;
	int insertAditOrDlvyOdrBasHst(AditDlvyOdrDtlVO_01 aditdlvyodrdtlvo01) throws Exception;
	int insertAditOrDlvyOdrAditCtDtl(AditDlvyOdrDtlVO_02 aditdlvyodrdtlvo02) throws Exception;
	int insertAditOrDlvyOdrAditCtDtlHst(AditDlvyOdrDtlVO_02 aditdlvyodrdtlvo02) throws Exception;

	//	######### 인터페이스  SOREC-IF-090 ##############
	int insertOrTaxBillError(DlvyProgrsSttusVO dlvyProgrsSttusvo) throws Exception;

	int insertProgrsSttusOrDlvyOdrBas(DlvyProgrsSttusVO dlvyProgrsSttusvo) throws Exception;
	int insertProgrsSttusOrDlvyOdrBasHst(DlvyProgrsSttusVO dlvyProgrsSttusvo) throws Exception;
	String selectNewDlvyProgrsSttusCode(DlvyProgrsSttusVO dlvyProgrsSttusvo) throws Exception;
	String selectAgoDlvyProgrsSttusCode(DlvyProgrsSttusVO dlvyProgrsSttusvo) throws Exception;

	int insertProgrsSttusOrDlvyProgrsSttusDtl(DlvyProgrsSttusVO dlvyProgrsSttusvo) throws Exception;
	int insertProgrsSttusOrDlvyProgrsSttusDtlHst(DlvyProgrsSttusVO dlvyProgrsSttusvo) throws Exception;

	int updateProgrsSttusOrOrderBas(DlvyProgrsSttusVO dlvyProgrsSttusvo) throws Exception;

	String selectFnGetOrderSttusCode(DlvyProgrsSttusVO dlvyProgrsSttusvo) throws Exception;

	boolean selectIsRefnded(@Param("orderNo") String orderNo);
	ExcclcInfoVO selectExcclcInfo(@Param("orderNo") String orderNo) throws Exception;
	int updateExcclcInfo(ExcclcInfoVO excclcInfoVO) throws Exception;
	
	List<DlvyProgrsSttusVO> selectOrTaxBillError() throws Exception;
	int updateOrTaxBillErrorSuccess(DlvyProgrsSttusVO dlvyProgrsSttusvo) throws Exception;
	int updateOrTaxBillErrorFail(DlvyProgrsSttusVO dlvyProgrsSttusvo) throws Exception;

	OrMrtggMdstrmRepyDtlVO selectOrMrtggMdstrmRepyDtlTargetInfo(DlvyProgrsSttusVO dlvyProgrsSttusvo) throws Exception;
	int insertOrMrtggMdstrmRepyDtl(OrMrtggMdstrmRepyDtlVO orMrtggMdstrmRepyDtlVO) throws Exception; // 주문_담보 중도 상환 상세 등록

	//	######### 인터페이스  SOREC-IF-071 ##############
	int insertBlDtlOrDlvyOdrBas(DlvyOdrBlDtlVO_01 dlvyodrbldtlvo01) throws Exception;
	int insertBlDtlOrDlvyOdrBasHst(DlvyOdrBlDtlVO_01 dlvyodrbldtlvo01) throws Exception;

	int insertBlDtlOrDlvyOdrBlDtl(DlvyOdrBlDtlVO_02 dlvyodrbldtlvo02) throws Exception;
	int insertBlDtlOrDlvyOdrBlDtlHst(DlvyOdrBlDtlVO_02 dlvyodrbldtlvo02) throws Exception;

	int insertBlDtlOrDlvyOdrLotDtl(DlvyOdrBlDtlVO_03 dlvyodrbldtlvo03) throws Exception;
	int insertBlDtlOrDlvyOdrLotDtlHst(DlvyOdrBlDtlVO_03 dlvyodrbldtlvo03) throws Exception;

	int deleteBlDtlOrDlvyOdrLotDtl(DlvyOdrBlDtlVO_03 dlvyodrbldtlvo03) throws Exception;

	int updateOrOrderBas(DlvyOdrBlDtlVO_01 dlvyOdrBlDtlVO_01) throws Exception;
	int insertOrOrderBasHst(@Param("orderNo") String orderNo) throws Exception;
	int updateOrOrderDtl(DlvyOdrBlDtlVO_02 dlvyOdrBlDtlVO_02) throws Exception;
	int insertOrOrderDtlHst(DlvyOdrBlDtlVO_02 dlvyOdrBlDtlVO_02) throws Exception;
	int insertOrLotInfoDtl(DlvyOdrBlDtlVO_03 dlvyOdrBlDtlVO_03) throws Exception;
	int insertOrLotInfoDtlHst(DlvyOdrBlDtlVO_03 dlvyOdrBlDtlVO_03) throws Exception;

	int updateOrExchngBlDtl(DlvyOdrBlDtlVO_02 dlvyOdrBlDtlVO_02) throws Exception;
	int insertOrExchngBlDtlHst(DlvyOdrBlDtlVO_02 dlvyOdrBlDtlVO_02) throws Exception;

	int insertOrExchngBlLotInfoDtl(DlvyOdrBlDtlVO_03 dlvyOdrBlDtlVO_03) throws Exception;
	int insertOrExchngBlLotInfoDtlHst(DlvyOdrBlDtlVO_03 dlvyOdrBlDtlVO_03) throws Exception;

	/* Interface SOREC-IF-112 */
	int updateOrCanclExchngRtngudDlvyOdrLotDtl(InvntryWrhousngVO_03 invntryWrhousngVO_03) throws Exception;
	int insertOrCanclExchngRtngudDlvyOdrLotDtlHst(InvntryWrhousngVO_03 invntryWrhousngVO_03) throws Exception;
	boolean isRegisteredInvntry(InvntryWrhousngVO_02 invntryWrhousngVO_02) throws Exception;
	List<OrOrderBasVO> selectOrOrderListWithFlsInvntry(String blNo) throws Exception;

	/* Interface SOREC-IF-110, 111, 112에서 공통 사용*/
	int insertBlInfo(@Param("intrfcId") String intrfcCode, @Param("intrfcSn") String intrfcSn) throws Exception;

	/*상품_BL 정보 기본 이력 테이블*/
	int insertItBlInfoBasHst(@Param("blNo") String blNo) throws Exception;
	/*상품_BL 정보 이력 상세 테이블*/
	int insertItBlInfoHistDtl(@Param("blNo") String blNo, @Param("blHistEventTyCode") String blHistEventTyCode) throws Exception;
	/* 상품_ LOT 정보 상세 이력 */
	int insertLotInfoBasHst(@Param("blNo") String blNo, @Param("bundleNo") String bundleNo) throws Exception;

	/* Interface SOREC-IF-005 */
	int insertSignInfoOrDlvyOdrBas(SignInfoVO signInfoVO) throws Exception;
	int insertSignInfoOrDlvyOdrBasHst(SignInfoVO signInfoVO) throws Exception;
	String selectDlvyMnCode(String ecOrderNo) throws Exception;
	boolean selectIsLastDlvyOdr(SignInfoVO signInfoVO) throws Exception;
	boolean selectIsAllSigned(SignInfoVO signInfoVO) throws Exception;

	/* Interface SOREC-IF-106 */
	DlvrgChangeVO selectOrDlvrgBas(@Param("orderNo") String orderNo, @Param("dlvrgNo")String dlvrgNo, @Param("dlvyRqestde")String dlvyRqestde, @Param("sysSe")String sysSe) throws Exception;
	void updateOrDlivyRequstDe(DlvrgChangeVO dlvrgChangeVO) throws Exception;
	void updateOrWrtmSetlePrearngeDe(OrOrderBasVO orderVO) throws Exception;

	/* Interface SOREC-IF-113 */
	ChangeDlvyMthdVO selectOrOrderBas(@Param("orginlOrderNo") String orginlOrderNo) throws Exception;
	List<ChangeDlvyMthdVO_02> selectChangeDlvyOdrBlDtl(@Param("orginlOrderNo") String orginlOrderNo) throws Exception;
	int insertOrOrderDlvyMthdChangeDtl(OrderDlvyMthdChangeVO orderDlvyMthdChangeVO) throws Exception;
	int insertOrOrderDlvyMthdChangeDtlHst(OrderDlvyMthdChangeVO orderDlvyMthdChangeVO) throws Exception;

	/* Interface SOREC-IF-114 start */
	/**
	 * <pre>
	 * 처리내용: 자차배송 차량정보 송신 시 주문 번호에 대한 OMS 접수 번호와 주문 번호를 가져오기
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	DlvyVhcleVO selectOrDlvyOdrBas(@Param("orderNo") String orderNo) throws Exception;
	/**
	 * <pre>
	 * 처리내용: 자차배송 차량정보 송신 시 주문 번호, 주문 순번에 대한 BL정보 리스트를 가져오기
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @param orderSns
	 * @return
	 * @throws Exception
	 */
	List<DlvyVhcleVO_02> selectOrDlvyOdrBlDtl(@Param("orderNo") String orderNo, @Param("orderSns") List<String> orderSns) throws Exception;
	/**
	 * <pre>
	 * 처리내용: 자차배송 차량정보 송신 시 주문 번호, 주문 순번, 차량 주문 순번 (기존 배송 차수)에 대한 주문 차량 정보 리스트 가져오기
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @param orderSn
	 * @param dlvyOdrs
	 * @return
	 * @throws Exception
	 */
	List<DlvyVhcleVO_03> selectOrDlvyOdrLotDtl(@Param("orderNo") String orderNo, @Param("orderSn") String orderSn, @Param("dlvyOdrs") List<String> dlvyOdrs) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 결제예정일 변경 대상여부, 기존 결제예정일, 변경될 결제예정일 데이터를 조회한다.
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> selectOrVhclInfo(String orderNo) throws Exception;
	/* Interface SOREC-IF-114 end */

	/* Interface SOREC-IF-023 */
	SetleInfoVO selectSetleInfoBas(@Param("orderNo") String orderNo, @Param("orderType") String orderType) throws Exception;
	List<SetleInfoVO_02> selectSetleInfoDtl(@Param("orderNo") String orderNo, @Param("orderType") String orderType) throws Exception;
	List<SetleInfoVO_02> selectSetleInfoDtlExchngDlivy(@Param("orderNo") String orderNo) throws Exception;
	List<SetleInfoVO_03> selectSetleInfoWonorderDtl(@Param("orderNo") String orderNo, @Param("orderType") String orderType, @Param("blNo") String blNo) throws Exception;
	List<SetleInfoVO_04> selectSetleInfoWonorderBundle(@Param("orderNo") String orderNo, @Param("orderType") String orderType, @Param("blNo") String blNo, @Param("dlvyOdr") int dlvyOdr) throws Exception;

	int updateOmsOrderRceptNo(@Param("orderNo") String orderNo, @Param("omsOrderRceptNo") String omsOrderRceptNo, @Param("intrfcCode") String intrfcCode, @Param("orderSttusCode") String orderSttusCode) throws Exception;

	/* Interface SOREC-IF-007 */
	List<DlvyProgrsReqVO_02> selectDlvyOdrInfo(@Param("orderNo") String orderNo) throws Exception;
	int insertDlvyOdrBas(DlvyProgrsResVO_03 dlvyProgrsResVO_03) throws Exception;
	int insertDlvyOdrBasHst(DlvyProgrsResVO_03 dlvyProgrsResVO_03) throws Exception;
	int insertDlvyProgrsSttusDtl(DlvyProgrsResVO_03 dlvyProgrsResVO_03) throws Exception;
	int insertDlvyProgrsSttusDtlHst(DlvyProgrsResVO_03 dlvyProgrsResVO_03) throws Exception;

	/* Interface SOREC-IF-109 */
	int insertLoWrhousStdrChcy(WrhousStdrChcyVO wrhousStdrChcyVO) throws Exception;
	int insertLoWrhousStdrChcyHst(WrhousStdrChcyVO wrhousStdrChcyVO) throws Exception;

	/* Interface SOREC-IF-089 */
	int insertLoDlvyTariffBas(DlvyTariffVO dlvyTariffVO) throws Exception;
	int insertLoDlvyTariffBasHst(DlvyTariffVO dlvyTariffVO) throws Exception;

	/* Interface SOREC-IF-125 */
	List<OrOrderBasVO> selectOrDtlBlList(String ecOrderNo) throws Exception;
	boolean isAlreadyRecoveredBlInfo(OrOrderBasVO bl) throws Exception;
	InvntryRecoverVO selectInvntryRecoverTargetInfo(OrOrderBasVO bl) throws Exception;
	void updateRecoverInvntryBlInfoBas(InvntryRecoverVO invntryVO) throws Exception;
	void insertBlInfoBasHst(InvntryRecoverVO invntryVO) throws Exception;
	void insertInvntryBlInfoHistDtl(InvntryRecoverVO invntryVO) throws Exception;

	/* Interface SOREC-IF-127 */
	OrOrderBasVO selectCanclOrderAtCnfirm(FlsOrderAsgnCanclVO flsOrderAsgnCanclVO) throws Exception;

	/* Interface SOREC-IF-152 */
	InvntryAsgnInfoVO selectAsgnInvntryDtl(InvntryAsgnInfoVO invntryAsgnInfoVO) throws Exception;
	InvntryAsgnInfoVO selectAsgnInvntryDtlHst(InvntryAsgnInfoVO invntryAsgnInfoVO) throws Exception;

	/* 주문_배송 차수 맵핑 기본 */
	String insertOrDlvyOdrMappingBas(String orderNo, String omsOrderNo, String lgistDlvyOdr);

	int insertEwalletSetle(OrSetleBasVO orSetleBasVO) throws Exception;
	int insertOrSetleBasHst(OrSetleBasVO orSetleBasVO) throws Exception;

	String selectEwalletRspnCode(@Param("delngSeqNo") String delngSeqNo) throws Exception;

	OdrDtlVO selectOrderDataForMail(DlvyProgrsSttusVO paramVO) throws Exception;
	List<OdrDtlVO_02> selectDlvyOdrDataForMail(@Param("orderNo") String orderNo, @Param("dlvyOdr") String dlvyOdr) throws Exception;

	String getSntoEmail(@Param("emailTmplatNo") int emailTmplatNo);

	/* 해당 주문건의 결제방식코드 조회 */
	OrOrderBasVO selectOrOrderBasInfo(String orderNo) throws Exception;
	/* 가주문/실주문 확인 */
	int isFalseOrRealOrder(String orderNo) throws Exception;
	/* 전자상거래보증 데이터 조회 */
	OrOrderBasVO selectMrtggInfo(String orderNo) throws Exception;
	/* 전자상거래보증 수정세금계산서 발행이후 변경예정 결제예정일을 조회한다 */
	String getChangeSetlePrearngeDe(Map<String, Object> map) throws Exception;
	/* 전자상거래보증: 수정 세금계산서 발행이후 발행시점+상환기간 으로 결제예정일을 변경한다 */
	void updateOrMrtggSetlePrearngeDe(OrOrderBasVO orderVO) throws Exception;
	/* 답보보증 이력 등록*/
	void insertOrMrtggBasHst(OrOrderBasVO mrtggInfo) throws Exception;
	/* 전자상거래보증 SMS발송을 위한 데이터 조회 */
	OdrDtlVO selectMrtggDataForSms(String orderNo, String originSetlePrearngeDe, long excclcAmount) throws Exception;
	/* 여신결제 > 출고요청일 변경시 결제예정일 변경을 위한 계산일수 데이터 조회*/
	int selectDayCntBySetleMthd(String orderNo) throws Exception;

	/* 물류 통신 실패시 재처리 대상으로 업데이트 */
	void updateOrLgistRehndlTrget(String orderNo, String rehndlTrgetCode, String lastChangerId) throws Exception;
	/* 출고 중지 여부 업데이트 */
	void updateOrdlivyStpgeAt(OrderSttusChgInfoVO orderSttusChgInfoVO);

	/* 해당 주문 번호의 모든 BL에 대한 실재고여부 확인: 모두 실재고이면 TRUE, 하나라도 가재고이면 FALSE 리턴 */
	boolean isAllRealInvntry(String orderNo) throws Exception;
	
	/* 수취인 대상 메세지 발송 필요 데이터 조회 */
	Map<String, String> selectDataForReptCoustomer(String orderNo, String dlvyOdr) throws Exception;
	
}
