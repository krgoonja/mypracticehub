package com.sorincorp.api.lo.model;

import lombok.Data;
@Data
public class OrderSnDtlVO {
	
	/** EC 주문순번 **/
	private String ecOrderSn;

}
