package com.sorincorp.api.lo.model;

import lombok.Data;
@Data
public class CorprEntrpsDtlVO {

	/** 인터페이스 번호 **/
	private int intrfcNo;

	/** 협력 업체 코드 **/
	private String corprEntrpsCode;

	/** 협력 업체 명 **/
	private String corprEntrpsNm;

	/** 인터페이스 구분 **/
	private String intrfcSe;

	/*최초 등록자 아이디*/
	private String frstRegisterId;

	/*최종 변경자 아이디*/
	private String lastChangerId;
}
