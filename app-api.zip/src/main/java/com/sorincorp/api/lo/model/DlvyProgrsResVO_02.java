package com.sorincorp.api.lo.model;

import java.util.List;

import lombok.Data;

@Data
public class DlvyProgrsResVO_02 {
	/**
	 * 배송 차수 리스트
	 */
	private List<DlvyProgrsResVO_03> dlvyOdrList;
	/**
	 * EC 주문 번호
	 */
	private String ecOrderNo;
	/**
	 * OMS 주문 번호
	 */
	private String omsOrderNo;
}
