package com.sorincorp.api.lo.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties({"intrfcSn", "intrfcNo", "frstRegisterId", "frstRegistDt", "lastChangerId", "lastChangeDt"})
public class DlvyVhcleVO {
    /**
     * 인터페이스 순번
    */
    private long intrfcSn;
    /**
     * 인터페이스 번호
    */
    private long intrfcNo;
    /**
     * OMS 주문 번호
    */
    private String omsOrderRceptNo;
    /**
     * 주문 번호
    */
    private String ecOrderNo;
    /**
     * 시스템 구분(FO:1, BO:2)
    */
    private String sysSe;
    /**
     * BL 리스트
     */
    private List<DlvyVhcleVO_02> blList;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
 
}
