package com.sorincorp.api.lo.model;

import java.util.List;

import lombok.Data;

@Data
public class DlvyOdrBlVO {
	List<DlvyOdrBlDtlVO_01> dlvyOdrList;
}