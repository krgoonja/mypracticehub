package com.sorincorp.api.lo.model;

import java.util.List;

import lombok.Data;

@Data
public class DlvyProgrsReqVO {
	private List<DlvyProgrsReqVO_02> orderNoList;
}
