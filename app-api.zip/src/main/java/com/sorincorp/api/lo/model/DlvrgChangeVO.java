package com.sorincorp.api.lo.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties({"intrfcSn", "intrfcNo", "frstRegisterId", "frstRegistDt", "lastChangerId", "lastChangeDt"})
public class DlvrgChangeVO {
    /**
     * 인터페이스 순번
    */
	@ApiModelProperty(hidden = true)
    private long intrfcSn;
    /**
     * 인터페이스 번호
    */
	@ApiModelProperty(hidden = true)
    private long intrfcNo;
    /**
     * ERP 업체 코드
    */
	@JsonProperty(value = "tCode")
    private String tCode;
    /**
     * 배송 수단 코드
    */
    private String dlvyMnCode;
    /**
     * 차량 그룹 코드
    */
    private String vhcleGroupCode;
    /**
     * 수취 업체 담당자 명
    */
    private String dlvrgCharger;
    /**
     * 수취 업체 휴대폰 번호
    */
    private String dlvrgCttpc;
    /**
     * 수취업체 담당자 이메일
    */
    private String dlvrgEmail;
    /**
     * 배송 요청 내용
    */
    private String orderMemo;
    /**
     * 관리자 배송 요청 내용
    */
    private String chargerMemo;
    /**
     * 변경 배송지 번호
    */
    private String changeDlvrgNo;
    /**
     * 변경 배송지 우편 번호
    */
    private String changeAlocZip;
    /**
     * 변경 배송지 주소
    */
    private String changeAlocAdres;
    /**
     * 변경 배송지 주소 상세
    */
    private String changeAlocAdresDetail;
    /**
     * 변경 배송지 도로명 주소
    */
    private String changeAlocRnAdres;
    /**
     * 변경 배송지 도로명 주소 상세
    */
    private String changeAlocRnAdresDetail;
    /**
     * 주문 번호
    */
    private String ecOrderNo;
    /**
     * 출고 요청 일자
    */
    private String dlvyRqestde;
    /**
     * 시스템 구분 코드(FO:1, BO:2)
    */
    private String sysSe;
    /**
     * 최초 등록자 아이디
    */
    @ApiModelProperty(hidden = true)
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    @ApiModelProperty(hidden = true)
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    @ApiModelProperty(hidden = true)
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    @ApiModelProperty(hidden = true)
    private String lastChangeDt;

}
