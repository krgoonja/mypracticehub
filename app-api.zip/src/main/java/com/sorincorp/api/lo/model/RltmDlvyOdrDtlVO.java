package com.sorincorp.api.lo.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class RltmDlvyOdrDtlVO {
	/** 인터페이스 번호 **/
	@ApiModelProperty(hidden = true)
	private int intrfcNo;

	/**
	 * OMS 주문 번호
	 */
	private String omsOrderNo;
	/**
	 * 배송 차수
	 */
	private String dlvyOdr;
	/**
	 * 실제 배송 비용
	 */
	private String realDlvyCt;
	/**
	 * 확정 배송 비용
	 */
	private String dcsnDlvyCt;
	/**
	 * 배송 완료 일자
	 */
	private String dlvyComptDe;
	/**
	 * 이동 거리 (킬로수)
	 */
	private String mvmnDstnc;
	/**
	 * EC 주문 번호
	 */
	private String ecOrderNo;

	/** 최초 등록자 아이디* **/
	private String frstRegisterId;

	/** 최종 변경자 아이디* **/
	private String lastChangerId;
}
