package com.sorincorp.api.lo.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class WrhousStdrChcyVO {
    /**
     * 인터페이스 순번
    */
	@ApiModelProperty(hidden = true)
    private long intrfcSn;
    /**
     * 인터페이스 번호
    */
	@ApiModelProperty(hidden = true)
    private long intrfcNo;
    /**
     * 창고 코드
    */
    private String wrhousCode;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 보관 료
    */
    private java.math.BigDecimal cstdyChrge;
    /**
     * 인터페이스 구분(I/U/D)
     */
    private String intrfcSe;
    /**
     * 최초 등록자 아이디
    */
    @ApiModelProperty(hidden = true)
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    @ApiModelProperty(hidden = true)
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    @ApiModelProperty(hidden = true)
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    @ApiModelProperty(hidden = true)
    private String lastChangeDt;
 
}
