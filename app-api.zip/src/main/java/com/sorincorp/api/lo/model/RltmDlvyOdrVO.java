package com.sorincorp.api.lo.model;

import java.util.List;

import lombok.Data;

@Data
public class RltmDlvyOdrVO {
	/**
	 * 주문 번호 리스트
	 */
	private List<RltmDlvyOdrDtlVO> orderNoList;
}
