package com.sorincorp.api.lo.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties({"intrfcSn", "invntryChangeLotDetailSn", "frstRegisterId", "frstRegistDt", "lastChangerId", "lastChangeDt"})
public class ChangeDlvyMthdVO_02 {
    /**
     * 인터페이스 순번
    */
    private long intrfcSn;
    /**
     * 재고 변경 LOT 상세 순번
    */
    private long invntryChangeLotDetailSn;
    /**
     * 주문 순번
    */
    private String ecOrderSn;
    /**
     * BL 번호
    */
    private String blNo;
    /**
     * 아이템 코드
    */
    private String itmCode;
    /**
     * 창고 코드
    */
    private String wrhousCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * BL 중량
    */
    private java.math.BigDecimal blWt;
    /**
     * 주문 번들 수량
    */
    private int bundleQy;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
 
}
