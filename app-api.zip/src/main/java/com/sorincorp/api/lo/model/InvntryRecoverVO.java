package com.sorincorp.api.lo.model;

import lombok.Data;

@Data
public class InvntryRecoverVO {
	/**
	 * 주문 번호
	 */
	private String orderNo;
	/**
	 * 총 번들 수량
	 */
	private int totBundleQy;
	/**
	 * BL 번호
	 */
	private String blNo;
	/**
	 * 총 중량
	 */
	private java.math.BigDecimal totWt;
	/**
	 * 소량 구매 여부
	 */
	private String smlqyPurchsAt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
}
