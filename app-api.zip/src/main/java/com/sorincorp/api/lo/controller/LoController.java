package com.sorincorp.api.lo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.sorincorp.api.lo.model.*;
import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.lo.comm.constant.LoCommConstant;
import com.sorincorp.api.lo.comm.entity.LoResponseEntity;
import com.sorincorp.api.lo.service.LoService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.util.StringUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/lo")
@Api("물류관리")
public class LoController {

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private LoService loService;

	/* 물류관리	SOREC-IF-004 */
	@PostMapping("/CorprEntrps")
	@ApiOperation(value = "SOREC-IF-004 : 운송사업체등의 기본정보 실시간 수신", notes = "운송업체의 정보를 TMS로부터 수신해 EC에 저장한다.")
	public ResponseEntity<?> setCorprEntrps(@RequestBody CorprEntrpsVO corprEntrpsVo, HttpServletRequest request) throws Exception{

		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		loService.saveCorprEntrpsBas(corprEntrpsVo);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-005 */
	@PostMapping("/DlvyOdrSignInfo")
	@ApiOperation(value = "SOREC-IF-005 : 서명정보 TMS 수신", notes = "통합물류에서 서명정보 등록시 EC에 제공 한다.")
	public ResponseEntity<?> set(@RequestBody SignInfoVO signInfoVO, HttpServletRequest request) throws Exception{
		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		loService.saveDlvyOdrSignInfo(signInfoVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-007 */
	@PostMapping("/DlvyProgrs")
	@ApiOperation(value = "SOREC-IF-007 : 배송진행상태 TMS 수신", notes = "EC에서 주문된 주문진행건에 대한 배송상태를 OMS로부터 수신해 EC에 저장한다.(배송완료이외의건)")
	public ResponseEntity<?> getDlvyProgrs(@RequestBody List<String> orderNo , HttpServletRequest request) throws Exception{

		List<DlvyProgrsResVO_03> dlvyProgrsList = loService.getDlvyProgrs(orderNo);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(dlvyProgrsList);
	}

	/* 물류관리	SOREC-IF-009 */
	@PostMapping("/DlvyOdrBas")
	@ApiOperation(value = "SOREC-IF-009 : 배차 정보 실시간 수신", notes = "배차 정보를 TMS로부터 수신해 EC에 저장한다.")
	public ResponseEntity<?> setDlvyOdrBas(@RequestBody DlvyOdrBasVO dlvyOdrBasVo, HttpServletRequest request) throws Exception{

		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		loService.saveDlvyOdrBas(dlvyOdrBasVo);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-023 */
	@PostMapping("/SetleInfo/{orderNo}/{orderType}/{orderSttus}")
	@ApiOperation(value = "SOREC-IF-023 : 결제정보 OMS 송신(주문/취소/반품/교환입출고)", notes = "Front에서 결제된 주문내역을 EC_BO 담당자가 확인후 출고지시시에 OMS로 데이터를 넘겨준다.")
	public ResponseEntity<?> sendSetleInfo(@PathVariable String orderNo, @PathVariable String orderType, @PathVariable String orderSttus, HttpServletRequest request) throws Exception{

		String omsOrderRceptNo = loService.sendSetleInfo(orderNo, orderType, orderSttus, null);

		Map<String, String> responseEntity = new HashMap<>();

		responseEntity.put("omsOrderRceptNo", omsOrderRceptNo);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(responseEntity);
	}

	/* 물류관리	SOREC-IF-026 */
	@PostMapping("/RltmInvntryInfo")
	@ApiOperation(value = "SOREC-IF-026 : 실시간재고 WMS 수신", notes = "주문상세에 진입시 호출되며 해당 상품의 재고정보를 수신해 EC에 Display 한다.")
	public ResponseEntity<?> getRltmInvntryInfo(@RequestBody InvntryInfoRequstVO invntryInfoRequstVO, HttpServletRequest request) throws Exception{

		InvntryInfoVO result = loService.getRltmInvntryInfo(invntryInfoRequstVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(result);
	}

	/* 물류관리	SOREC-IF-027 */
	@PostMapping("/WrhousInfo")
	@ApiOperation(value = "SOREC-IF-027 : 창고 정보 실시간 수신", notes = "창고 정보를 WMS로부터 수신해 EC에 저장한다.")
	public ResponseEntity<?> setWrhousInfo(@RequestBody WrhousDtlVO wrhousDtlVo, HttpServletRequest request) throws Exception{

		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		loService.saveWrhousInfo(wrhousDtlVo);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-053 */
	@PostMapping("/CoCmmnCd")
	@ApiOperation(value = "SOREC-IF-053: WMS/OMS/OMS 코드정보 실시간 수신", notes = "WMS/OMS/OMS 코드정보를 수신해 EC에 저장한다.")
	public ResponseEntity<?> setCoCmmnCd(@RequestBody CoCmmnCdVO coCmmnCdVo, HttpServletRequest request) throws Exception{

		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		loService.saveCoCmmnCd(coCmmnCdVo);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-057 */
	@PostMapping("/RltmDlvyOdr")
	@ApiOperation(value = "OREC-IF-057: 실배송비용 실시간 수신 (케이지배송-배송완료, 자차-상차완료)", notes = "실배송비용 실시간 수신 (케이지배송-배송완료, 자차-상차완료) 수신해 EC에 저장한다.")
	public ResponseEntity<?> setRltmDlvyOdr(@RequestBody RltmDlvyOdrVO rltmDlvyOdrVO, HttpServletRequest request) throws Exception{

		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		loService.saveRltmDlvyOdr(rltmDlvyOdrVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-069 */
	@PostMapping("/AllInvntry")
	@ApiOperation(value = "SOREC-IF-069 : 전체재고 WMS 수신(EC용재고)", notes = "WMS에서 전체 재고 정보를 제공받는다.")
	public ResponseEntity<?> setAllInvntry(@RequestBody AllInvntryVO allInvntryVO, HttpServletRequest request) throws Exception{

		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		loService.saveAllInvntry(allInvntryVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-071 */
	@PostMapping("/DlvyOdrBl")
	@ApiOperation(value = "SOREC-IF-071: 확정 중량 수신(상차시점)", notes = "확정 중량 수신(상차시점)해 EC에 저장한다.")
	public ResponseEntity<?> setDlvyOdrBl(@RequestBody DlvyOdrBlVO dlvyOdrBlVO, HttpServletRequest request) throws Exception{

		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		loService.saveDlvyOdrBl(dlvyOdrBlVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-089 */
	@PostMapping("/DlvyTariff")
	@ApiOperation(value = "SOREC-IF-089 : 배송요율표 수신", notes = "EC BO에서 예상 물류비 계산 시 사용되는 배송요율표를 EC에 저장한다.")
	public ResponseEntity<?> setDlvyTariff(@RequestBody DlvyTariffVO dlvyTariffVO, HttpServletRequest request) throws Exception{
		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		loService.saveDlvyTariff(dlvyTariffVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-090 */
	@PostMapping("/DlvyProgrsSttus")
	@ApiOperation(value = "SOREC-IF-090: 진행상태 OMS 실시간 수신", notes = "창고 정보를 WMS로부터 수신해 EC에 저장한다.")
	public ResponseEntity<?> setDlvyProgrsSttus(@RequestBody DlvyProgrsSttusVO dlvyProgrsSttusVO, HttpServletRequest request) throws Exception{

		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		loService.saveDlvyProgrsSttus(dlvyProgrsSttusVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-106 */
	@PostMapping(value = {"/DlvrgChange/{orderNo}/{dlvrgNo}/{sysSe}", "/DlvrgChange/{orderNo}/{dlvrgNo}/{dlvyRqestde}/{sysSe}"})
//	@ApiOperation(value = "SOREC-IF-106 : 배송지변경 송신", notes = "EC에서 상차전까지는 배송지를 변경할수 있으며, 변경시 OMS 송신 한다.")
	//2022-03-21 변경사항 : 기존 인터페이스의 기능에서 단순 메모만 연동시키는 기능으로 변경
	//2022-09-06 변경사항 : 결제수단 '증거금' 결제예정일 이후에 입금완료된 경우 출고요청일자 변경가능하도록 수정
	//2022-10-11 변경사항 : 시스템 구분코드()
	@ApiOperation(value = "SOREC-IF-106 : 배송메모 송신", notes = "주문메모와 담당자메모만 연동하는 배송메모 변경 송신.")
	public ResponseEntity<?> sendDlvrgChangeInfo(
				@PathVariable String orderNo,
				@PathVariable String dlvrgNo,
				@PathVariable(required = false) String dlvyRqestde,
				@PathVariable(required = false) String sysSe,
				HttpServletRequest request
			) throws Exception{

		loService.sendDlvrgChangeInfo(orderNo, dlvrgNo, dlvyRqestde, sysSe);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-107 */
	@PostMapping("/AditDlvyOdr")
	@ApiOperation(value = "SOREC-IF-107: 추가상하차비용 수신(상하차,보관료,조작료,셔틀비,검수비,할증료,조출료)-배송완료시점", notes = "추가상하차비용 수신해 EC에 저장한다.")
	public ResponseEntity<?> setAditDlvyOdr(@RequestBody AditDlvyOdrVO aditDlvyOdrVo, HttpServletRequest request) throws Exception{

		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		loService.saveAditDlvyOdr(aditDlvyOdrVo);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-109 */
	@PostMapping("/WrhousStdrChcy")
	@ApiOperation(value = "SOREC-IF-109 : 창고별 기준보관료 수신 - 창고,아이템,보관료(톤)", notes = "창고별 금속별 보관 비용을 EC에 제공 한다.")
	public ResponseEntity<?> setWrhousStdrChcy(@RequestBody WrhousStdrChcyVO wrhousStdrChcyVO, HttpServletRequest request) throws Exception{
		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		loService.saveWrhousStdrChcy(wrhousStdrChcyVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-110 */
	@PostMapping("/InvntryMdat")
	@ApiOperation(value = "SOREC-IF-110 : 재고조정 수신", notes = "불량과 멸실 이외 재고의 가감이 있을경우 조정된 수량에 대한 재고를 수신 한다.")
	public ResponseEntity<?> setInvntryMdat(@RequestBody InvntryMdatVO invntryMdatVO, HttpServletRequest request) throws Exception{
		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		loService.saveInvntryMdat(invntryMdatVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-111 */
	@PostMapping("/InvntryBadn")
	@ApiOperation(value = "SOREC-IF-111 : 재고 불량 실시간 수신", notes = "관리되는재고중 불량이나 멸실의 BL및 번들정보를 EC에 제공 한다.")
	public ResponseEntity<?> setInvntryBadn(@RequestBody InvntryBadnVO invntryBadnVO, HttpServletRequest request) throws Exception{
		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		loService.saveInvntryBadn(invntryBadnVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-112 */
	@PostMapping("/InvntryWrhousng")
	@ApiOperation(value = "SOREC-IF-112 : PO입고_EC반품입고_EC교환입고 수신", notes = "일반입고/반품입고/교환입고시 재고정보 및 번들정보를를 REQUEST한다.")
	public ResponseEntity<?> setInvntryWrhousng(@RequestBody InvntryWrhousngVO invntryWrhousngVO, HttpServletRequest request) throws Exception{
		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		loService.saveInvntryWrhousng(invntryWrhousngVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-113 */
	/* 2022-03-08 변경사항 : 인터페이스 오용 방지를 위해 주석처리 */
	/*
	@PostMapping("/sendChangeDlvyMthd/{orginlOrderNo}/{changeOrderNo}")
	@ApiOperation(value = "SOREC-IF-113 : 배송방식 변경 송신", notes = "B/O에서 배송방식을 변경했을경우 EC_BO 담당자가 확인후 OMS로 데이터를 넘겨준다.")
	public ResponseEntity<?> set(@PathVariable String orginlOrderNo, @PathVariable String changeOrderNo, HttpServletRequest request) throws Exception{

		loService.sendChangeDlvyMthd(orginlOrderNo, changeOrderNo);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}
	*/

	/**
	 * <pre>
	 * 처리내용: [물류관리 SOREC-IF-114] 자차배송일경우 차량정보 등록, 수정, 삭제 시 차량정보를 전송한다.
	 *   - 요청1 : [BATCH] 당일 미납 주문 건 배송요청일 변경 (매일 17시 실행)
	 *   - 요청2 : [운영 사용안함] [BATCH] 자차배송 차량 입고일 D-day 차량 정보 미등록 대상으로 배송 요청일 자동 연장 (영업일 기준 +5)
	 *   - 요청3-1 : [BO] CS관리 > 배송관리 > 배송진행내역조회 > 상세 (팝업) > 차량등록/수정, 저장 버튼 클릭 시
	 *   - 요청3-2 : [BO] CS관리 > 배송관리 > 배송진행내역조회 > 상세 (팝업) > 차량등록/수정, 삭제 버튼 클릭 시
	 *   - 요청4-1 : [FO] 마이페이지 > 주문 배송 내역 > 차량정보등록 > 차량정보등록 (팝업) > 차량정보 등록, 저장 버튼 클릭 시
	 *   - 요청4-2 : [FO] 마이페이지 > 주문 배송 내역 > 차량정보등록 > 차량정보등록 (팝업) > 차량정보 등록, X 버튼 클릭 시
	 *   - 요청5-1 : [개발, 운영 사용안함] [MO] 모바일용 > 마이페이지 > 차량정보 등록, 저장 버튼 클릭 시
	 *   - 요청5-2 : [개발, 운영 사용안함] [MO] 모바일용 > 마이페이지 > 차량정보 등록, 삭제 버튼 클릭 시
	 *   - 요청6-1 : [MO] 차량등록 모바일용 > 주문 목록 > 차량정보 등록 > 저장하기 버튼 클릭 시
	 *   - 요청6-2 : [MO] 차량등록 모바일용 > 주문 목록 > 차량정보 등록 > 삭제 버튼 클릭 시
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoList
	 * @param sysSe
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/sendDlvyVhcleInfo/{sysSe}")
	@ApiOperation(value = "SOREC-IF-114 : 자차배송 차량정보 송신", notes = "자차배송일경우 고객의 차량정보를 전송한다.")
	public ResponseEntity<?> sendDlvyVhcleInfo(@RequestBody List<VhcleInfoVO> vhcleInfoList, @PathVariable String sysSe, HttpServletRequest request) throws Exception {

		// [물류관리 SOREC-IF-114] 자차배송일경우 차량정보 등록, 수정, 삭제 시 차량정보를 전송한다.
		loService.sendDlvyVhcleInfo(vhcleInfoList, sysSe);

		return ResponseEntity.status(HttpStatus.OK).body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-125 */
	@PostMapping("/OrderSttusChange")
	@ApiOperation(value = "SOREC-IF-125 : 주문상태 변경", notes = "주문상태를 변경한다.")
	public ResponseEntity<?> sendOrderSttusChange(@RequestBody OrderSttusChgInfoVO orderSttusChgInfoVO, HttpServletRequest request) throws Exception{

		String rspnsCode = loService.sendOrderSttusChange(orderSttusChgInfoVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(rspnsCode, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* 물류관리	SOREC-IF-126 */
	@PostMapping("/RltmLgistCnfirm")
	@ApiOperation(value = "SOREC-IF-126 : 실시간 물류 CAPA 확인", notes = "해당 물류센터의 CAPA정보를 수신해 주문 가능 여부를 확인 한다.")
	public ResponseEntity<?> setRltmLgistCnfirm(@RequestBody RltmCapaVO rltmCapaVO, HttpServletRequest request) throws Exception{
		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		RltmCapaVO result = loService.saveRltmLgistCnfirm(rltmCapaVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(result);
	}

	/* 물류관리	SOREC-IF-127 */
	@PostMapping("/FlsOrderAsgnCanclCompt")
	@ApiOperation(value = "SOREC-IF-127 : 가주문할당취소완료 수신", notes = "해당 가주문의 할당취소완료 수신시 다시 가주문취소 인터페이스를 호출 한다.")
	public ResponseEntity<?> FlsOrderAsgnCanclCompt(@RequestBody FlsOrderAsgnCanclVO flsOrderAsgnCanclVO, HttpServletRequest request) throws Exception{
		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		Map<String, String> result = loService.saveFlsOrderAsgnCanclCompt(flsOrderAsgnCanclVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(result);
	}
	
	/* 물류관리	SOREC-IF-152 */
	@PostMapping("/sendInvntryAsgnInfo")
	@ApiOperation(value = "SOREC-IF-152 : 재고할당 정보 송신", notes = "재고할당 정보를 전송한다.")
	public ResponseEntity<?> sendInvntryAsgnInfo(@RequestBody InvntryAsgnInfoVO invntryAsgnInfoVO, HttpServletRequest request) throws Exception{

		Map<String, String> responseEntity = loService.sendInvntryAsgnInfo(invntryAsgnInfoVO);
		
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(responseEntity);
		
	}

	/** 중량 변동금 자동 환불 처리 */
	@PostMapping("/atmcRefnd")
	public ResponseEntity<?> atmcRefnd(@RequestBody AtmcRefndVO atmcRefndVo) throws Exception {

		String orderNo = StringUtil.nvl(atmcRefndVo.getOrderNo());
		String mberNo = StringUtil.nvl(atmcRefndVo.getMberNo());
		String retry = StringUtil.nvl(atmcRefndVo.getRetry(), "N");

		if (StringUtil.isBlank(orderNo)) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body(new LoResponseEntity(LoCommConstant.ERROR_RESULT_CODE, "주문번호 확인 불가"));
		}

		if (StringUtil.isBlank(mberNo)) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.body(new LoResponseEntity(LoCommConstant.ERROR_RESULT_CODE, "등록자 확인 불가"));
		}

		// Y == 재처리
		boolean isRetry = StringUtil.isBlank(retry) ? false : "N".equals(retry) ? false : "Y".equals(retry) ? true : false;
		loService.atmcRefndProcess(orderNo, mberNo, isRetry);

		return ResponseEntity.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	/* VO 통신 테스트 */
	@RequestMapping("/vaConnectTest")
	public ResponseEntity<?> vaConnectTest(HttpServletRequest request, @Value("${spring.profiles.active}") String profiles) throws Exception{
		String test = String.valueOf(request.getParameter("test"));
		log.debug(">> test : " + test + ", profiles : " + profiles);
		String url = "";
		String entrpsNo = "C0093";

		String domain = "http://127.0.0.1:28088";
		if(StringUtils.equals(profiles, "dev")) {
			domain = "http://10.202.0.6:28088";
			entrpsNo = "C0093";
		} else if(StringUtils.equals(profiles, "prd")) {
			domain = "http://10.202.0.11:28088";
			entrpsNo = "C0140";
		}

		if(StringUtils.equals(test, "money")) {
			url = domain + "/api/ewallet/money";
		}

		log.debug(">> entrpsNo : " + entrpsNo + ", url : " + url);

		Map<String, Object> ewalletMap = new HashMap<String, Object>();
		ewalletMap.put("entrpsNo", entrpsNo);

		Map<String, Object> ewalletResMap = httpClientHelper.postCallApi(url, ewalletMap);
		log.debug(ewalletResMap.toString()); // log

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> exception(Exception e) throws Exception{

		return ResponseEntity
				.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body(new LoResponseEntity(LoCommConstant.ERROR_RESULT_CODE, e.getMessage()));
	}

	/* 케이지 배송 변경 SOREC-IF-115 */
	@PostMapping("/dispatChange")
	@ApiOperation(value = "SOREC-IF-115: 케이지 배송 변경", notes = "케이지 배송 변경요청 정보를 물류시스템에 전달한다.")
	public ResponseEntity<?> dispatChange(@RequestBody DlvyOdrDtlVO dlvyOdrDtl, HttpServletRequest request) throws Exception{
		log.info("LoController > dispatChange :: dlvyOdrDtl {}", dlvyOdrDtl);

		loService.dispatChange(dlvyOdrDtl);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}
}
