package com.sorincorp.api.lo.model;

import lombok.Data;

@Data
public class DlvyProgrsResVO_03 {
	/**
     * 인터페이스 순번
    */
    private long intrfcSn;
    /**
     * 인터페이스 번호
    */
    private long intrfcNo;
    /**
     * OMS 주문 번호
    */
    private String omsOrderNo;
    /**
     * 주문 번호
    */
    private String ecOrderNo;
	/**
	 * 배송 차수
	 */
	private String dlvyOdr;
	/**
	 * 배송 진행 상태 코드
	 */
	private String dlvyProgrsSttusCode;
	/**
	 * 주문 상태 코드(배송 진행 상태 코드에 따라 바뀜)
	 */
	private String orderSttusCode;
	/**
	 * 배송 진행 상태 등록 일시
	 */
	private String progrsSttusRegistDt;
	/**
	 * 차량 번호
	 */
	private String vhcleNo;
	/**
	 * 차량 그룹 코드
	 */
	private String vhcleGroupCode;
	/**
	 * 기사 코드
	 */
	private String articlCode;
	/**
	 * 기사 명
	 */
	private String articlNm;
	/**
	 * 기사 전화 번호
	 */
	private String articlTlphonNo;
	/**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
}
