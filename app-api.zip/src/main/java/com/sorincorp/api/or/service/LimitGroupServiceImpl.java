package com.sorincorp.api.or.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.jms.JMSException;
import javax.jms.Message;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.api.or.mapper.LimitGroupMapper;
import com.sorincorp.api.or.model.OrLimitOrderLogVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingWeightCalculateValuesVO;
import com.sorincorp.comm.itemprice.service.ItemPriceMatchingService;
import com.sorincorp.comm.order.model.CommItmWtInfoVO;
import com.sorincorp.comm.order.model.CommLimitGroupModel;
import com.sorincorp.comm.order.model.CommLimitOrderModel;
import com.sorincorp.comm.order.model.CommLimitOrderQueueMsgVO;
import com.sorincorp.comm.order.model.CommOrLimitOrderBasVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderQueueMsgVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.comm.order.service.CommLimitOrderService;
import com.sorincorp.comm.order.service.CommOrderService;
import com.sorincorp.comm.order.service.CommPrvsnlOrderService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * LimitGroupServiceImpl.java
 * 지정가 그룹 Service 구현체 클래스
 *
 * @version
 * @since 2023. 4. 14.
 * @author srec0049
 */
@Slf4j
@Service
public class LimitGroupServiceImpl implements LimitGroupService {

	/**
	 * 주문 공통 Service
	 */
	@Autowired
	CommOrderService commOrderService;

	/**
	 * 지정가 주문 공통 Service
	 */
	@Autowired
	CommLimitOrderService commLimitOrderService;

	/**
	 * 가단가 주문 공통 Service
	 */
	@Autowired
	CommPrvsnlOrderService commPrvsnlOrderService;

	/**
	 * 지정가 그룹 Mapper
	 */
	@Autowired
	LimitGroupMapper limitOrderMapper;

	/**
	 * 사이트 운영 설정 서비스
	 */
	@Autowired
	private BsnInfoService bsnInfoService;

    /**
     * BL Service
     */
	@Autowired
    private ItemPriceMatchingService itemPriceService;

	/**
	 * http 통신
	 */
	@Autowired
	private HttpClientHelper httpClientHelper;

	/**
	 * 지정가 그룹 SYSTEM ID
	 */
	static final String LIMIT_GROUP_SYSTEM = "LIMIT_SYSTEM";

	/**
	 * [API -> FO] 지정가 주문 요청 API 서비스 URL
	 */
	@Value("${api.limit.order.url}")
	private String LIMIT_ORDER_URL;

	/**
	 * [API -> FO] 가단가 지정가 주문 요청 API 서비스 URL
	 */
	@Value("${api.limit.prvsnlOrder.url}")
	private String PRVSNL_LIMIT_ORDER_URL;

	/**
	 * 지정가 그룹 처리
	 */
	public void procLimitGroup(CommLimitOrderQueueMsgVO commLimitOrderQueueMsgVO, Message message) {
		/**
		 * 01. 지정가 그룹 메시지 주문 로그 저장
		 *  1) Azure Service Bus Queue에서 받은 메시지 전문을 저장하고 지정가 주문 로그 순번을 반환
		 * 02. 지정가 주문 번호 리스트 존재 유효성 체크, 지정가 주문 번호 중복 건수 있을 경우 중복 제거
		 * 03. 지정가 주문 번호 리스트에 따른 지정가 주문 내역 정보 가져오기
		 *  - 조건 1) 지정가 주문 번호 리스트
		 *  - 조건 2) 지정가 주문 일자가 현재 날짜인 경우
		 *  - 조건 3) 지정가 주문 상태 코드가 미체결(10)인 경우
		 *  - 조건 4) 삭제 여부가 'N'인 경우
		 *  - 쿼리에 위 조건으로 지정가 그룹 내 지정가들의 당일 날짜 체크 및 중복 체크를 대체함
		 *  1) 지정가 주문 번호들로 해당 지정가 주문 내역 리스트 가져오기 [복수]
		 * 04. 지정가 그룹 내 지정가들의 주문 상태 변경
		 *  1) DB, 지정가 주문 상태 코드[주문처리중(20)] 변경
		 * 05. 허수 주문 체결 처리
		 *  1) DB, 지정가 주문 상태 코드[체결(30)] 변경
		 *  2) FO, BO의 해당 지정가 주문 번호를 호가창에서 제거 요청 (취소: C) [지정가 주문 정보 소켓 통신(송신)]
		 *  3) 주문_지정가 주문 기본 이력 정보 등록하기
		 * 06. 최적의 BL리스트 기준으로 재고 체크
		 *  1) 재고 초기 데이터 설정 (판매 단위 중량, 1회 판매 가능 중량)
		 *  2) 지정가 주문 재고 파악
		 *  3) 최적의 BL 조회 후 잔여 중량으로 주문 가능 시 지정가 주문 수량 재설정
		 *  4) 재고 관련 주문 정합성 체크
		 *  5) 재고 선 차감
		 * 07. Queue 지정가 그룹 메시지 명시적 삭제 요청
		 * 08. 삭제 요청에 따른 [주문_지정가 주문 로그] 응답 일시를 수정
		 * 09. 최종 타겟 지정가 주문 번호들의 해당 주문_지정가 주문 기본(OR_LIMIT_ORDER_BAS) 정보(지정가 주문 큐 메시지 정보와 재고 체크 중량 업데이트)를 업데이트
		 * 10. 지정가 그룹 주문 요청 [FO 프로젝트]
		 * **/

		// 지정가 그룹 공통 VO 객체
		CommLimitGroupModel commLimitGroupModel = new CommLimitGroupModel();
		commLimitGroupModel.setSystemId(LIMIT_GROUP_SYSTEM); // 시스템 아이디

		try {
			/**
			 * 01. 지정가 그룹 메시지 주문 로그 저장
			 *  1) Azure Service Bus Queue에서 받은 메시지 전문을 저장하고 지정가 주문 로그 순번을 반환
			 * **/
			ObjectMapper mapper = new ObjectMapper();
			String messageJsonStr = mapper.writeValueAsString(commLimitOrderQueueMsgVO);
			// Azure Service Bus Queue에서 받은 메시지 전문을 저장하고 지정가 주문 로그 순번을 반환
			long returnLimitOrderLogSn = this.insertQueueMessageLog(commLimitOrderQueueMsgVO.getLimitOrderRequestDt(), messageJsonStr);
			log.warn("[procLimitGroup] returnLimitOrderLogSn : " + returnLimitOrderLogSn);

			boolean restdeYn = true; // 영업시간 체크 메소드가 문제가 있어도 통과시키기 위해 default 값은 true
			try {
				// 영업시간 체크
				//restdeYn = bsnInfoService.isRestDeLive(); // LIVE 20230831 isRestDeByMetal 메소드로 통합됨에 따라 삭제

				// isRestDeByMetal 메소드에서 판매방식 01, 02에 대한 처리만 있어서 03 지정가일 경우엔 01로 세팅, 평균가(지정가)가 생겨도 01로 사용하게될 듯...
				restdeYn = bsnInfoService.isRestDeByMetal(commLimitOrderQueueMsgVO.getMetalCode(), "01");
			} catch(Exception restdeE) {
				log.error("[procLimitGroup] restdeE : " + restdeE.getMessage());
				String restdeEstacktrace = ExceptionUtils.getStackTrace(restdeE);
				log.error("[procLimitGroup] restdeEstacktrace : " + restdeEstacktrace);
			}
			log.warn("[procLimitGroup] restdeYn : " + restdeYn);

			// 현재 시간
			String currentTime = DateUtil.getNowDateTime("HHmmss");

			// 영업시간 체크해서 지난 건은 무시
			if(restdeYn) {
				commLimitGroupModel.setLimitOrderLogSn(returnLimitOrderLogSn); // 지정가 주문 로그 순번 set

				// 지정가 주문 큐 메시지 공통 VO 객체 set
				commLimitGroupModel.setCommLimitOrderQueueMsgVO(commLimitOrderQueueMsgVO);

				// 타겟 지정가 주문 번호 정보 Map
				Map<String, CommOrLimitOrderBasVO> targetLimitOrderNoInfoMap = new HashMap<String, CommOrLimitOrderBasVO>();

				// 허수 지정가 주문 번호 리스트
				List<String> imaginaryLimitOrderNoList = new ArrayList<String>();

				/**
				 * 02. 지정가 주문 번호 리스트 존재 유효성 체크, 지정가 주문 번호 중복 건수 있을 경우 중복 제거
				 * **/
				List<String> tempLimitOrderNoList = commLimitOrderQueueMsgVO.getLimitOrderNoList(); // 지정가 주문 번호 LIST
				log.warn("[procLimitGroup] tempLimitOrderNoList : " + String.valueOf(tempLimitOrderNoList));
				if(tempLimitOrderNoList == null || tempLimitOrderNoList.size() == 0) {
					throw new CommCustomException("지정가 그룹 내 지정가 주문 번호 미존재.");
				}

				// 지정가 주문 번호 중복 건수 있을 경우 중복 제거
				List<String> limitOrderNoList = tempLimitOrderNoList.stream().distinct().collect(Collectors.toList());
				log.warn("[procLimitGroup] limitOrderNoList : " + String.valueOf(limitOrderNoList));

				/**
				 * 03. 지정가 주문 번호 리스트에 따른 지정가 주문 내역 정보 가져오기
				 *  - 조건 1) 지정가 주문 번호 리스트
				 *  - 조건 2) 지정가 주문 유효 일자가 현재 날짜보다 미래인 경우
				 *  - 조건 3) 지정가 주문 상태 코드가 미체결(10)인 경우
				 *  - 조건 4) 삭제 여부가 'N'인 경우
				 *  - 쿼리에 위 조건으로 지정가 그룹 내 지정가들의 당일 날짜 체크 및 중복 체크를 대체함
				 *  * 24-02-19 변경사항 : 계약구매-지정가 주문 case 반영을 위해 "조건 2) 지정가 주문 일자가 현재 날짜인 경우" 에서 변경
				 *  1) 지정가 주문 번호들로 해당 지정가 주문 내역 리스트 가져오기 [복수]
				 * **/

				// 지정가 주문 번호들로 해당 지정가 주문 내역 리스트 가져오기 [복수]
				List<CommOrLimitOrderBasVO> selectCommOrLimitOrderBasList = commLimitOrderService.selectCommOrLimitOrderBasList(limitOrderNoList);
				log.warn("[procLimitGroup] selectCommOrLimitOrderBasList 개수 : " + selectCommOrLimitOrderBasList.size());
				if(selectCommOrLimitOrderBasList == null || selectCommOrLimitOrderBasList.size() == 0) {
					throw new CommCustomException("지정가 주문 번호 리스트에 따른 지정가 주문 정보 미존재.");
				}

				// 지정가 주문 번호들로 해당 지정가 주문 내역 리스트 맵 정보로 변환 (key : limitOrderNo)
				HashMap<String, CommOrLimitOrderBasVO> selectCommOrLimitOrderBasMap = selectCommOrLimitOrderBasList.stream()
						.collect(Collectors.toMap(CommOrLimitOrderBasVO::getLimitOrderNo,  Function.identity(), (o1, o2) -> o1, HashMap::new));

				log.warn("[procLimitGroup] selectCommOrLimitOrderBasMap : " + String.valueOf(selectCommOrLimitOrderBasMap));

				// LME에서 넘겨준 지정가 주문 번호 리스트 순으로 처리
				for(String limitOrderNo : limitOrderNoList) {

					CommOrLimitOrderBasVO commOrLimitOrderBasVO = selectCommOrLimitOrderBasMap.get(limitOrderNo);

					// 지정가 주문 번호에 해당하는 지정가 주문 내역이 없는 경우 제외
					// 24-02-19 변경사항 : 지정가 주문 유효일자 체크를 위해 조건문 추가
					if(commOrLimitOrderBasVO == null) {
						log.warn("[procLimitGroup] 지정가 주문 내역이 없음 limitOrderNo : " + limitOrderNo);
					} else if (StringUtils.isNotBlank(commOrLimitOrderBasVO.getLimitOrderValidDe())
							&& (DateUtil.isPast(commOrLimitOrderBasVO.getLimitOrderValidDe()))
							) {
						log.warn("[procLimitGroup] 지정가 주문 유효일자 초과 limitOrderNo : {} , 유효일자 : {}, 체결일자 : {}" ,limitOrderNo,commOrLimitOrderBasVO.getLimitOrderValidDe(),DateUtil.getNowDate());
					} else if (StringUtils.isNotBlank(commOrLimitOrderBasVO.getLimitOrderValidTime())
							&& (Integer.parseInt(currentTime) > Integer.parseInt(commOrLimitOrderBasVO.getLimitOrderValidTime()))
							) {
						log.warn("[procLimitGroup] 지정가 주문 유효시간 초과 limitOrderNo : {} , 유효시간 : {}, 체결시간 : {}" ,limitOrderNo,commOrLimitOrderBasVO.getLimitOrderValidTime(),currentTime);
					} else {
						// 타겟 지정가 주문 번호 담기
						commLimitGroupModel.getTargetLimitOrderNoList().add(limitOrderNo);

						// 타겟 지정가 주문 번호 정보 Map에 담기
						targetLimitOrderNoInfoMap.put(limitOrderNo, selectCommOrLimitOrderBasMap.get(limitOrderNo));

						// 허수 지정가 주문 번호 찾기
						if(StringUtils.equals("Y", selectCommOrLimitOrderBasMap.get(limitOrderNo).getImaginaryOrderAt())) {
							imaginaryLimitOrderNoList.add(limitOrderNo); // 허수 지정가 주문 번호 담기
						} else {
							// 타겟 지정가 주문 번호에 대한 필요 정보 담을 맵 생성
							commLimitGroupModel.getLimitOrderModelMap().put(limitOrderNo, new CommLimitOrderModel());
						}
					}
				}

				log.warn("[procLimitGroup] commLimitGroupModel.getTargetLimitOrderNoList() : " + String.valueOf(commLimitGroupModel.getTargetLimitOrderNoList()));

				/**
				 * 04. 지정가 그룹 내 지정가들의 주문 상태 변경
				 *  1) DB, 지정가 주문 상태 코드[주문처리중(20)] 변경
				 * **/
				// DB, 지정가 주문 상태 코드[주문처리중(20)] 변경
				if(commLimitGroupModel.getTargetLimitOrderNoList().size() > 0) {
					int updateLimitOrderSttusCode = commLimitOrderService.updateCommLimitOrderSttusCode(commLimitGroupModel.getTargetLimitOrderNoList(), "20", null, LIMIT_GROUP_SYSTEM, null, null);
					log.warn("[procLimitGroup] updateLimitOrderSttusCode : " + updateLimitOrderSttusCode);
				}

				/**
				 * 05. 허수 주문 체결 처리
				 *  1) DB, 지정가 주문 상태 코드[체결(30)] 변경
				 *  2) FO, BO의 해당 지정가 주문 번호를 호가창에서 제거 요청 (취소: C) [지정가 주문 정보 소켓 통신(송신)]
				 *  3) 주문_지정가 주문 기본 이력 정보 등록하기
				 * **/
				if(imaginaryLimitOrderNoList.size() > 0) {
					// DB, 지정가 주문 상태 코드[체결(30)] 변경
					int updateLimitOrderImaginarySttusCode = commLimitOrderService.updateCommLimitOrderSttusCode(imaginaryLimitOrderNoList, "30", null, LIMIT_GROUP_SYSTEM, null, null);
					log.warn("[procLimitGroup] updateLimitOrderImaginarySttusCode : " + updateLimitOrderImaginarySttusCode);

					for(String imaginaryLimitOrderNo : imaginaryLimitOrderNoList) {
						// FO, BO의 해당 지정가 주문 번호를 호가창에서 제거 요청 (취소: C) [지정가 주문 정보 소켓 통신(송신)]
						commLimitOrderService.publishLimitOrder(imaginaryLimitOrderNo, "C", true, true); // 취소 (제거요청)

						// 주문_지정가 주문 기본 이력 정보 등록하기
						commLimitOrderService.insertOrLimitOrderBasHst(imaginaryLimitOrderNo);

					}
				}

				// 타겟 지정가 주문 번호 리스트에서 체결된 허수 지정가 주문 번호 리스트 제거
				if(imaginaryLimitOrderNoList.size() > 0) {
					commLimitGroupModel.getTargetLimitOrderNoList().removeAll(imaginaryLimitOrderNoList);
				}
				log.warn("[procLimitGroup] commLimitGroupModel.getTargetLimitOrderNoList() : " + String.valueOf(commLimitGroupModel.getTargetLimitOrderNoList()));

				// 허수 지정가 주문 번호를 제외하고 타겟 지정가 주문 번호가 남아 있을 시 07번 수행
				if(commLimitGroupModel.getTargetLimitOrderNoList().size() > 0) {
					/**
					 * 06. 최적의 BL리스트 기준으로 재고 체크
					 *  1) 재고 초기 데이터 설정 (판매 단위 중량, 1회 판매 가능 중량)
					 *  2) 지정가 주문 재고 파악
					 *  3) 최적의 BL 조회 후 잔여 중량으로 주문 가능 시 지정가 주문 수량 재설정
					 *  4) 재고 관련 주문 정합성 체크
					 *  5) 재고 선 차감
					 * **/
					this.limitOrderInvntryChk(commLimitGroupModel, targetLimitOrderNoInfoMap);
				}

				log.warn("[procLimitGroup] commLimitGroupModel : " + String.valueOf(commLimitGroupModel));

				/**
				 * 07. Queue 지정가 그룹 메시지 명시적 삭제 요청
				 * **/
				// Queue 지정가 그룹 메시지 명시적 삭제 요청
				log.warn("[procLimitGroup] acknowledge req");
				// Queue에 명시적 삭제 요청
				message.acknowledge();

				/**
				 * 08. 삭제 요청에 따른 [주문_지정가 주문 로그] 응답 일시를 수정
				 * **/
				// 삭제 요청에 따른 [주문_지정가 주문 로그] 응답 일시를 수정
				this.updateOrLimitOrderLog(returnLimitOrderLogSn);

				// 실제로 재고 선 차감 대상인 타겟 지정가 주문 번호가 남아 있을 시 10번 수행
				if(commLimitGroupModel.getTargetLimitOrderNoList().size() > 0) {
					/**
					 * 09. 최종 타겟 지정가 주문 번호들의 해당 주문_지정가 주문 기본(OR_LIMIT_ORDER_BAS) 정보(지정가 주문 큐 메시지 정보와 재고 체크 중량 업데이트)를 업데이트
					 * **/
					this.updateOrLimitOrderBasByFinalTarget(commLimitGroupModel);
				}

				// 최종 타겟 지정가 주문 번호들이 남아 있을 시 11번 수행
				if(commLimitGroupModel.getTargetLimitOrderNoList().size() > 0) {
					/**
					 * 10. 지정가 그룹 주문 요청 [FO 프로젝트]
					 * **/
					// 지정가 그룹 주문 요청 [FO 프로젝트]
					Map<String, Object> limitOrderResMap = httpClientHelper.postCallApi(LIMIT_ORDER_URL, commLimitGroupModel);
					log.warn("[procLimitGroup] limitOrderResMap : " + limitOrderResMap);
					if(limitOrderResMap == null) {
						commLimitGroupModel.setLimitOrderSttusCode("95"); // 체결실패 (기타) : API 호출 실패
						throw new CommCustomException("지정가 그룹 주문 요청 API 호출 실패");
					}
				}
			} else {
				throw new CommCustomException("영업시간 마감");
			}
		} catch(Exception e) {
			log.error("[procLimitGroup] e : " + e.getMessage());
			String stacktrace = ExceptionUtils.getStackTrace(e);
			log.error("[procLimitGroup] stacktrace : " + stacktrace);

			/**
			 * 08. Queue 지정가 그룹 메시지 명시적 삭제 요청
			 * **/
			// Queue 지정가 그룹 메시지 명시적 삭제 요청
			log.warn("[procLimitGroup] exception acknowledge req");
			// Queue에 명시적 삭제 요청
			try {
				message.acknowledge();
			} catch (JMSException je) {
				log.error("[procLimitGroup] stacktrace : " + ExceptionUtils.getStackTrace(je));
			}

			if(StringUtils.isNotEmpty(commLimitGroupModel.getLimitOrderSttusCode())) {
				// 지정가 주문 상태 코드가 [94: 유효성 검사 실패, 95: 기타]일 경우 주문 실패 사유를 넣어준다.
				if(StringUtils.equals("94", commLimitGroupModel.getLimitOrderSttusCode()) || StringUtils.equals("95", commLimitGroupModel.getLimitOrderSttusCode())) {
					commLimitGroupModel.setLimitOrderFailrResn(e.getMessage());
				}
				// 지정가 주문 번호[복수] 지정가 주문 실패 시
				commLimitOrderService.limitOrderFail(commLimitGroupModel.getTargetLimitOrderNoList(), commLimitGroupModel.getLimitOrderSttusCode()
						, commLimitGroupModel.getLimitOrderFailrResn(), LIMIT_GROUP_SYSTEM
						, "Y", true, true);
			}
		}
	}

	/**
	 * 가단가 지정가 그룹 처리
	 */
	@Override
	public void procPrvsnlLimitGroup(CommPrvsnlLimitOrderQueueMsgVO commPrvsnlLimitOrderQueueMsgVO, Message message) {
		/**
		 * 01. 지정가 그룹 메시지 주문 로그 저장
		 *  1) Azure Service Bus Queue에서 받은 메시지 전문을 저장하고 지정가 주문 로그 순번을 반환
		 * 02. 지정가 주문 번호 리스트 존재 유효성 체크, 지정가 주문 번호 중복 건수 있을 경우 중복 제거
		 * 03. 지정가 주문 번호 리스트에 따른 지정가 주문 내역 정보 가져오기
		 *  - 조건 1) 지정가 주문 번호 리스트
		 *  - 조건 2) 지정가 주문 유효 일자가 현재 날짜와 같거나 큰 경우
		 *  - 조건 3) 지정가 주문 상태 코드가 미체결(10)인 경우
		 *  - 조건 4) 삭제 여부가 'N'인 경우
		 *  - 쿼리에 위 조건으로 지정가 그룹 내 지정가들의 날짜 체크 및 중복 체크를 대체함
		 *  1) 지정가 주문 번호들로 해당 지정가 주문 내역 리스트 가져오기 [복수]
		 * 04. 지정가 그룹 내 지정가들의 주문 상태 변경
		 *  1) DB, 지정가 주문 상태 코드[주문처리중(20)] 변경
		 * 05. Queue 지정가 그룹 메시지 명시적 삭제 요청
		 * 06. 삭제 요청에 따른 [주문_지정가 주문 로그] 응답 일시를 수정
		 * 07. 최종 타겟 지정가 주문 번호들의 관련 데이터 UPDATE(지정가 주문 큐 메시지 정보)를 업데이트
		 * 08. 가단가 지정가 그룹 주문 요청 [FO 프로젝트]
		 * **/
		// 지정가 그룹 공통 VO 객체
		CommLimitGroupModel commLimitGroupModel = new CommLimitGroupModel();
		commLimitGroupModel.setSystemId(LIMIT_GROUP_SYSTEM); // 시스템 아이디

		try {
			/**
			 * 01. 지정가 그룹 메시지 주문 로그 저장
			 *  1) Azure Service Bus Queue에서 받은 메시지 전문을 저장하고 지정가 주문 로그 순번을 반환
			 * **/
			ObjectMapper mapper = new ObjectMapper();
			String messageJsonStr = mapper.writeValueAsString(commPrvsnlLimitOrderQueueMsgVO);
			// Azure Service Bus Queue에서 받은 메시지 전문을 저장하고 지정가 주문 로그 순번을 반환
			long returnLimitOrderLogSn = this.insertQueueMessageLog(commPrvsnlLimitOrderQueueMsgVO.getLimitOrderRequestDt(), messageJsonStr);
			log.warn("[procPrvsnlLimitGroup] returnLimitOrderLogSn : " + returnLimitOrderLogSn);

			boolean restdeYn = true; // 영업시간 체크 메소드가 문제가 있어도 통과시키기 위해 default 값은 true
			try {
				// 영업시간 체크
				//restdeYn = bsnInfoService.isRestDeLive(); // LIVE 20230831 isRestDeByMetal 메소드로 통합됨에 따라 삭제

				// isRestDeByMetal 메소드에서 판매방식 01, 02에 대한 처리만 있어서 03 지정가일 경우엔 01로 세팅, 평균가(지정가)가 생겨도 01로 사용하게될 듯...
				restdeYn = bsnInfoService.isRestDeByMetal(commPrvsnlLimitOrderQueueMsgVO.getMetalCode(), "01");
			} catch(Exception restdeE) {
				log.error("[procPrvsnlLimitGroup] restdeE : " + restdeE.getMessage());
				String restdeEstacktrace = ExceptionUtils.getStackTrace(restdeE);
				log.error("[procPrvsnlLimitGroup] restdeEstacktrace : " + restdeEstacktrace);
			}
			log.warn("[procPrvsnlLimitGroup] restdeYn : " + restdeYn);

			// 현재 시간
			String currentTime = DateUtil.getNowDateTime("HHmmss");

			// 영업시간 체크해서 지난 건은 무시
			if(restdeYn) {
				commLimitGroupModel.setLimitOrderLogSn(returnLimitOrderLogSn); // 지정가 주문 로그 순번 set

				// 지정가 주문 큐 메시지 공통 VO 객체 set
				commLimitGroupModel.setCommPrvsnlLimitOrderQueueMsgVO(commPrvsnlLimitOrderQueueMsgVO);

				// 타겟 지정가 주문 번호 정보 Map
				Map<String, CommOrLimitOrderBasVO> targetLimitOrderNoInfoMap = new HashMap<String, CommOrLimitOrderBasVO>();

				/**
				 * 02. 지정가 주문 번호 리스트 존재 유효성 체크, 지정가 주문 번호 중복 건수 있을 경우 중복 제거
				 * **/
				List<String> tempLimitOrderNoList = commPrvsnlLimitOrderQueueMsgVO.getLimitOrderNoList(); // 지정가 주문 번호 LIST
				log.warn("[procPrvsnlLimitGroup] tempLimitOrderNoList : " + String.valueOf(tempLimitOrderNoList));
				if(tempLimitOrderNoList == null || tempLimitOrderNoList.size() == 0) {
					throw new CommCustomException("가단가 지정가 그룹 내 지정가 주문 번호 미존재.");
				}

				// 지정가 주문 번호 중복 건수 있을 경우 중복 제거
				List<String> limitOrderNoList = tempLimitOrderNoList.stream().distinct().collect(Collectors.toList());
				log.warn("[procPrvsnlLimitGroup] limitOrderNoList : " + String.valueOf(limitOrderNoList));

				/**
				 * 03. 지정가 주문 번호 리스트에 따른 지정가 주문 내역 정보 가져오기
				 *  - 조건 1) 지정가 주문 번호 리스트
				 *  - 조건 2) 지정가 주문 유효 일자가 현재 날짜보다 미래인 경우
				 *  - 조건 3) 지정가 주문 상태 코드가 미체결(10)인 경우
				 *  - 조건 4) 삭제 여부가 'N'인 경우
				 *  - 쿼리에 위 조건으로 지정가 그룹 내 지정가들의 당일 날짜 체크 및 중복 체크를 대체함
				 *  * 24-02-19 변경사항 : 계약구매-지정가 주문 case 반영을 위해 "조건 2) 지정가 주문 일자가 현재 날짜인 경우" 에서 변경
				 *  1) 지정가 주문 번호들로 해당 지정가 주문 내역 리스트 가져오기 [복수]
				 * **/

				// 지정가 주문 번호들로 해당 지정가 주문 내역 리스트 가져오기 [복수]
				List<CommOrLimitOrderBasVO> selectCommOrPrvsnlLimitOrderBasList = commPrvsnlOrderService.selectCommOrPrvsnlOrderBasList(limitOrderNoList);
				log.warn("[procPrvsnlLimitGroup] selectCommOrPrvsnlLimitOrderBasList 개수 : " + selectCommOrPrvsnlLimitOrderBasList.size());
				if(selectCommOrPrvsnlLimitOrderBasList == null || selectCommOrPrvsnlLimitOrderBasList.size() == 0) {
					throw new CommCustomException("지정가 주문 번호 리스트에 따른 지정가 주문 정보 미존재.");
				}

				// 지정가 주문 번호들로 해당 지정가 주문 내역 리스트 맵 정보로 변환 (key : limitOrderNo)
				HashMap<String, CommOrLimitOrderBasVO> selectCommOrPrvsnlLimitOrderBasMap = selectCommOrPrvsnlLimitOrderBasList.stream()
						.collect(Collectors.toMap(CommOrLimitOrderBasVO::getLimitOrderNo,  Function.identity(), (o1, o2) -> o1, HashMap::new));

				log.warn("[procPrvsnlLimitGroup] selectCommOrPrvsnlLimitOrderBasMap : " + String.valueOf(selectCommOrPrvsnlLimitOrderBasMap));

				// LME에서 넘겨준 지정가 주문 번호 리스트 순으로 처리
				for(String limitOrderNo : limitOrderNoList) {

					CommOrLimitOrderBasVO commOrLimitOrderBasVO = selectCommOrPrvsnlLimitOrderBasMap.get(limitOrderNo);

					// 지정가 주문 번호에 해당하는 지정가 주문 내역이 없는 경우 제외
					// 24-02-19 변경사항 : 지정가 주문 유효일자 체크를 위해 조건문 추가
					if(commOrLimitOrderBasVO == null) {
						log.warn("[procPrvsnlLimitGroup] 지정가 주문 내역이 없음 limitOrderNo : " + limitOrderNo);
					} else if (StringUtils.isNotBlank(commOrLimitOrderBasVO.getLimitOrderValidDe())
							&& (DateUtil.isPast(commOrLimitOrderBasVO.getLimitOrderValidDe()))
							) {
						log.warn("[procPrvsnlLimitGroup] 지정가 주문 유효일자 초과 limitOrderNo : {} , 유효일자 : {}, 체결일자 : {}" ,limitOrderNo,commOrLimitOrderBasVO.getLimitOrderValidDe(),DateUtil.getNowDate());
					} else if (StringUtils.isNotBlank(commOrLimitOrderBasVO.getLimitOrderValidTime())
							&& (Integer.parseInt(currentTime) > Integer.parseInt(commOrLimitOrderBasVO.getLimitOrderValidTime()))
							) {
						log.warn("[procPrvsnlLimitGroup] 지정가 주문 유효시간 초과 limitOrderNo : {} , 유효시간 : {}, 체결시간 : {}" ,limitOrderNo,commOrLimitOrderBasVO.getLimitOrderValidTime(),currentTime);
					} else {
						// 타겟 지정가 주문 번호 담기
						commLimitGroupModel.getTargetLimitOrderNoList().add(limitOrderNo);

						// 타겟 지정가 주문 번호 정보 Map에 담기
						targetLimitOrderNoInfoMap.put(limitOrderNo, selectCommOrPrvsnlLimitOrderBasMap.get(limitOrderNo));

						// 타겟 지정가 주문 번호에 대한 필요 정보 담을 맵 생성
						commLimitGroupModel.getLimitOrderModelMap().put(limitOrderNo, new CommLimitOrderModel());
					}
				}

				log.warn("[procPrvsnlLimitGroup] commLimitGroupModel.getTargetLimitOrderNoList() : " + String.valueOf(commLimitGroupModel.getTargetLimitOrderNoList()));

				/**
				 * 04. 지정가 그룹 내 지정가들의 주문 상태 변경
				 *  1) DB, 지정가 주문 상태 코드[주문처리중(20)] 변경
				 * **/
				// DB, 지정가 주문 상태 코드[주문처리중(20)] 변경
				if(commLimitGroupModel.getTargetLimitOrderNoList().size() > 0) {
					int updateLimitOrderSttusCode = commPrvsnlOrderService.updateCommPrvsnlLimitOrderSttusCode(commLimitGroupModel.getTargetLimitOrderNoList(), "20", null, LIMIT_GROUP_SYSTEM);
					log.warn("[procPrvsnlLimitGroup] updateLimitOrderSttusCode : " + updateLimitOrderSttusCode);
				}

				log.warn("[procPrvsnlLimitGroup] commLimitGroupModel : " + String.valueOf(commLimitGroupModel));

				if(commLimitGroupModel.getTargetLimitOrderNoList().size() > 0) {
					/**
					 * 05. 가단가 주문의 BL리스트 조회
					 *  1) 재고 초기 데이터 설정 (판매 단위 중량, 1회 판매 가능 중량)
					 *  2) 주문완료된 BL목록 조회 및 데이터 세팅
					 * **/
					this.prvsnlLimitOrderInvntryChk(commLimitGroupModel, targetLimitOrderNoInfoMap);
				}

				log.warn("[procLimitGroup] commLimitGroupModel : " + String.valueOf(commLimitGroupModel));

				/**
				 * 06. Queue 지정가 그룹 메시지 명시적 삭제 요청
				 * **/
				// Queue 지정가 그룹 메시지 명시적 삭제 요청
				log.warn("[procPrvsnlLimitGroup] acknowledge req");
				// Queue에 명시적 삭제 요청
				message.acknowledge();

				/**
				 * 07. 삭제 요청에 따른 [주문_지정가 주문 로그] 응답 일시를 수정
				 * **/
				// 삭제 요청에 따른 [주문_지정가 주문 로그] 응답 일시를 수정
				this.updateOrLimitOrderLog(returnLimitOrderLogSn);

				if(commLimitGroupModel.getTargetLimitOrderNoList().size() > 0) {
					/**
					 * 08. 최종 타겟 지정가 주문 번호들에 대한 지정가 주문 큐 메시지 정보 업데이트
					 * **/
					this.updateOrPrvsnlLimitOrderBasByFinalTarget(commLimitGroupModel, targetLimitOrderNoInfoMap);
				}

				if(commLimitGroupModel.getTargetLimitOrderNoList().size() > 0) {
					/**
					 * 09. 지정가 그룹 주문 요청 [FO 프로젝트]
					 * **/
					// 지정가 그룹 주문 요청 [FO 프로젝트]
					Map<String, Object> limitOrderResMap = httpClientHelper.postCallApi(PRVSNL_LIMIT_ORDER_URL, commLimitGroupModel);
					log.warn("[procPrvsnlLimitGroup] limitOrderResMap : " + limitOrderResMap);
					if(limitOrderResMap == null) {
						commLimitGroupModel.setLimitOrderSttusCode("95"); // 체결실패 (기타) : API 호출 실패
						throw new CommCustomException("지정가 그룹 주문 요청 API 호출 실패");
					}
				}
			} else {
				throw new CommCustomException("영업시간 마감");
			}
		} catch(Exception e) {
			log.error("[procPrvsnlLimitGroup] e : " + e.getMessage());
			String stacktrace = ExceptionUtils.getStackTrace(e);
			log.error("[procPrvsnlLimitGroup] stacktrace : " + stacktrace);

			/**
			 * 06. Queue 지정가 그룹 메시지 명시적 삭제 요청
			 * **/
			// Queue 지정가 그룹 메시지 명시적 삭제 요청
			log.warn("[procPrvsnlLimitGroup] exception acknowledge req");
			// Queue에 명시적 삭제 요청
			try {
				message.acknowledge();
			} catch (JMSException je) {
				log.error("[procPrvsnlLimitGroup] stacktrace : " + ExceptionUtils.getStackTrace(je));
			}

			if(StringUtils.isNotEmpty(commLimitGroupModel.getLimitOrderSttusCode())) {
				// 지정가 주문 상태 코드가 [94: 유효성 검사 실패, 95: 기타]일 경우 주문 실패 사유를 넣어준다.
				if(StringUtils.equals("94", commLimitGroupModel.getLimitOrderSttusCode()) || StringUtils.equals("95", commLimitGroupModel.getLimitOrderSttusCode())) {
					commLimitGroupModel.setLimitOrderFailrResn(e.getMessage());
				}
				// 지정가 주문 번호[복수] 지정가 주문 실패 시
				commPrvsnlOrderService.prvsnlLimitOrderFail(commLimitGroupModel.getTargetLimitOrderNoList(), commLimitGroupModel.getLimitOrderSttusCode()
						, commLimitGroupModel.getLimitOrderFailrResn(), LIMIT_GROUP_SYSTEM);
			}
		}
	}

	/**
	 * <pre>
	 * 처리내용: 최종 타겟 지정가 주문 번호들의 해당 주문_지정가 주문 기본(OR_LIMIT_ORDER_BAS) 정보(지정가 주문 큐 메시지 정보와 재고 체크 중량 업데이트)를 업데이트
	 * </pre>
	 * @date 2023. 5. 8.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 8.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commLimitGroupModel
	 */
	private void updateOrLimitOrderBasByFinalTarget(CommLimitGroupModel commLimitGroupModel) {
		List<String> failLimitOrderNoList = new ArrayList<String>();

		for(String targetLimitOrderNo : commLimitGroupModel.getTargetLimitOrderNoList()) {
			try {
				// 타겟 지정가 주문 번호에 대한 필요 정보 담을 맵의 객체 가져오기
				CommLimitOrderModel getLimitOrderModel = commLimitGroupModel.getLimitOrderModelMap().get(targetLimitOrderNo);
				commLimitGroupModel.setTempTargetLimitOrderNo(targetLimitOrderNo); // 임시 지정가 주문 번호 (각 지정가 주문 업데이트 용도)
				commLimitGroupModel.setTempInvntryCeckWt(getLimitOrderModel.getTargetLimitOrderWt()); // 임시 재고 체크 중량 (각 지정가 주문 업데이트 용도)

				// 최종 타겟 지정가 주문 번호들의 해당 주문_지정가 주문 기본(OR_LIMIT_ORDER_BAS) 정보(지정가 주문 큐 메시지 정보와 재고 체크 중량 업데이트)를 업데이트
				limitOrderMapper.updateOrLimitOrderBasByFinalTarget(commLimitGroupModel);
			} catch(Exception e) {
				failLimitOrderNoList.add(targetLimitOrderNo); // 최종 타겟 지정가 정보 업데이트 실패된 주문 번호 set

				String limitOrderSttusCode = "94"; // 지정가 주문 상태 코드[94(유효성 검사 실패)] set
				String limitOrderFailrResn = "[" + targetLimitOrderNo + "] 지정가 주문 번호 정보 업데이트 실패"; // 주문 실패 사유

				// 지정가 주문 실패 시
				commLimitOrderService.limitOrderFail(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn
						, LIMIT_GROUP_SYSTEM, null, null
						, "Y", true, true);
			}
		}

		// 업데이트 실패된 주문 번호 리스트를 제거한다.
		if(failLimitOrderNoList.size() > 0) {
			commLimitGroupModel.getTargetLimitOrderNoList().removeAll(failLimitOrderNoList);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 최종 타겟 지정가 주문들에 대한 지정가 주문 큐 메시지 정보 업데이트
	 * </pre>
	 * @date 2024. 9. 27.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 27.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	private void updateOrPrvsnlLimitOrderBasByFinalTarget(CommLimitGroupModel commLimitGroupModel, Map<String, CommOrLimitOrderBasVO> targetLimitOrderNoInfoMap) {
		List<String> failLimitOrderNoList = new ArrayList<String>();

		for(String targetLimitOrderNo : commLimitGroupModel.getTargetLimitOrderNoList()) {
			try {
				commLimitGroupModel.setTempTargetLimitOrderNo(targetLimitOrderNo); // 임시 지정가 주문 번호 (각 지정가 주문 업데이트 용도)

				// 지정가 구분 코드
				String limitSeCode = targetLimitOrderNo.substring(9, 10);
				if("F".equals(limitSeCode)) {
					// LME
					commPrvsnlOrderService.updateOrLimitOrderLmeBasQueueInfo(commLimitGroupModel);
				} else if("X".equals(limitSeCode)) {
					// 환율
					commPrvsnlOrderService.updateOrLimitOrderEhgtBasQueueInfo(commLimitGroupModel);
				} else if("R".equals(limitSeCode)) {
					// KRW
					commPrvsnlOrderService.updateOrLimitOrderKrwBasQueueInfo(commLimitGroupModel);
				}
			} catch(Exception e) {
				failLimitOrderNoList.add(targetLimitOrderNo); // 최종 타겟 지정가 정보 업데이트 실패된 주문 번호 set

				String limitOrderSttusCode = "94"; // 지정가 주문 상태 코드[94(유효성 검사 실패)] set
				String limitOrderFailrResn = "[" + targetLimitOrderNo + "] 지정가 주문 번호 정보 업데이트 실패"; // 주문 실패 사유

				// 지정가 주문 실패 시
				commPrvsnlOrderService.prvsnlLimitOrderFail(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn, LIMIT_GROUP_SYSTEM);
			}
		}

		// 업데이트 실패된 주문 번호 리스트를 제거한다.
		if(failLimitOrderNoList.size() > 0) {
			commLimitGroupModel.getTargetLimitOrderNoList().removeAll(failLimitOrderNoList);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 처리내용: 최적의 BL리스트 기준으로 재고 체크
	 *  1) 재고 초기 데이터 설정 (판매 단위 중량, 1회 판매 가능 중량)
	 *  2) 지정가 주문 재고 파악
	 *  3) 최적의 BL 조회 후 잔여 중량으로 주문 가능 시 지정가 주문 수량 재설정
	 *  4) 재고 관련 주문 정합성 체크
	 *  5) 재고 선 차감
	 * </pre>
	 * @date 2023. 5. 3.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 3.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commLimitGroupModel
	 * @param targetLimitOrderNoInfoMap
	 */
	private void limitOrderInvntryChk(CommLimitGroupModel commLimitGroupModel, Map<String, CommOrLimitOrderBasVO> targetLimitOrderNoInfoMap) {
		try {
			// 재고 및 유효성 체크로 실패된 주문 번호 리스트
			List<String> failLimitOrderNoList = new ArrayList<String>();

			for(String targetLimitOrderNo : commLimitGroupModel.getTargetLimitOrderNoList()) {
				log.warn("[limitOrderInvntryChk] targetLimitOrderNo : " + targetLimitOrderNo);

				// 타겟 지정가 주문 번호에 대한 필요 정보 담을 맵의 객체 가져오기
				CommLimitOrderModel getLimitOrderModel = commLimitGroupModel.getLimitOrderModelMap().get(targetLimitOrderNo);

				CommOrLimitOrderBasVO targetLimitOrderNoInfo = targetLimitOrderNoInfoMap.get(targetLimitOrderNo); // 타겟 지정가 주문 번호에 해당하는 정보 가져오기

				// 24-02-20 변경사항 : 판매 방식 상세 코드, 계약 발주 번호 정보 추가
				getLimitOrderModel.setMetalCode(targetLimitOrderNoInfo.getMetalCode()); // 금속 코드 set
				getLimitOrderModel.setEntrpsNo(targetLimitOrderNoInfo.getEntrpsNo()); // 업체 번호 set
				getLimitOrderModel.setSleMthdCode("03"); // 판매 방식 코드 [03: 지정가]
				getLimitOrderModel.setSleMthdDetailCode(targetLimitOrderNoInfo.getCntrctOrderNo() != null ? "0304" : null); // 판매 방식 상세 코드 [0304: 지정가(계약구매)]
				getLimitOrderModel.setItmSn(targetLimitOrderNoInfo.getItmSn()); // 아이템 순번
				getLimitOrderModel.setDstrctLclsfCode(targetLimitOrderNoInfo.getDstrctLclsfCode()); // 권역 대분류 코드
				getLimitOrderModel.setBrandGroupCode(targetLimitOrderNoInfo.getBrandGroupCode()); // 브랜드 그룹 코드
				getLimitOrderModel.setBrandCode(targetLimitOrderNoInfo.getBrandCode()); // 브랜드 코드
				getLimitOrderModel.setTargetLimitOrderWt(targetLimitOrderNoInfo.getLimitOrderWt()); // 지정가 주문 중량 (개별)
				getLimitOrderModel.setCntrctOrderNo(targetLimitOrderNoInfo.getCntrctOrderNo()); // 계약 발주 번호
				getLimitOrderModel.setSmlqyPurchsAt(targetLimitOrderNoInfo.getSmlqyPurchsAt()); // 소량 구매 여부
				getLimitOrderModel.setBlNo(StringUtils.equals("Y", getLimitOrderModel.getSmlqyPurchsAt()) ? targetLimitOrderNoInfo.getBlNo() : null); // BL 번호

				// 24-02-20 변경사항 : 해당 지정가 주문이 계약구매 - 지정가 주문(0304)인 경우, 하단의 재고 체크 로직을 수행하지 않음 (FO 단에서 수행)
				if(StringUtils.equals(getLimitOrderModel.getSleMthdDetailCode(), "0304")) {
					continue;
				}


				log.warn("[limitOrderInvntryChk] targetLimitOrderNoInfo.getItmSn : " + targetLimitOrderNoInfo.getItmSn());

				// 재고 초기 데이터 설정 (판매 단위 중량, 1회 판매 가능 중량), 판매 단위 중량(상품별) 및 1회 판매 가능 중량(상품별), 최대 구매 가능 중량(상품별) 가져오기
				CommItmWtInfoVO selectItmWtInfo = commOrderService.selectItmWtInfo(targetLimitOrderNoInfo.getItmSn());
				if(selectItmWtInfo == null) {
					log.error("[limitOrderInvntryChk] 해당 상품_아이템 정보가 없습니다, 지정가 주문 번호 : " + targetLimitOrderNo);

					failLimitOrderNoList.add(targetLimitOrderNo); // 재고 및 유효성 체크로 실패된 주문 번호 set

					String limitOrderSttusCode = "94"; // 지정가 주문 상태 코드[94(유효성 검사 실패)] set
					String limitOrderFailrResn = "[" + targetLimitOrderNo + "] 의 해당 상품_아이템 정보가 없습니다."; // 주문 실패 사유

					// 지정가 주문 실패 시
					commLimitOrderService.limitOrderFail(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn
							, LIMIT_GROUP_SYSTEM, null, null
							, "Y", true, true);

					continue;
				}

				BigDecimal originSleUnitWt = Optional.ofNullable(selectItmWtInfo.getSleUnitWt()).orElse(BigDecimal.ZERO); // 판매 단위 중량
				if(originSleUnitWt.compareTo(BigDecimal.ZERO) == 0) {
					log.error("[limitOrderInvntryChk] 판매 단위 중량이 null이거나 0입니다, 지정가 주문 번호 : " + targetLimitOrderNo);

					failLimitOrderNoList.add(targetLimitOrderNo); // 재고 및 유효성 체크로 실패된 주문 번호 set

					String limitOrderSttusCode = "94"; // 지정가 주문 상태 코드[94(유효성 검사 실패)] set
					String limitOrderFailrResn = "[" + targetLimitOrderNo + "] 의 판매 단위 중량이 null이거나 0입니다."; // 주문 실패 사유

					// 지정가 주문 실패 시
					commLimitOrderService.limitOrderFail(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn
							, LIMIT_GROUP_SYSTEM, null, null
							, "Y", true, true);

					continue;
				}

				BigDecimal originOnceSlePossWt = Optional.ofNullable(selectItmWtInfo.getOnceSlePossWt()).orElse(BigDecimal.ZERO); // 1회 판매 가능 중량
				if(originOnceSlePossWt.compareTo(BigDecimal.ZERO) == 0) {
					log.error("[limitOrderInvntryChk] 1회 판매 가능 중량(상품별)이 null이거나 0입니다, 지정가 주문 번호 : " + targetLimitOrderNo);

					failLimitOrderNoList.add(targetLimitOrderNo); // 재고 및 유효성 체크로 실패된 주문 번호 set

					String limitOrderSttusCode = "94"; // 지정가 주문 상태 코드[94(유효성 검사 실패)] set
					String limitOrderFailrResn = "[" + targetLimitOrderNo + "] 의 1회 판매 가능 중량(상품별)이 null이거나 0입니다."; // 주문 실패 사유

					// 지정가 주문 실패 시
					commLimitOrderService.limitOrderFail(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn
							, LIMIT_GROUP_SYSTEM, null, null
							, "Y", true, true);

					continue;
				}

				getLimitOrderModel.setSleUnitWt(originSleUnitWt.intValue() / 1000); // 판매 단위 중량 kg -> MT로 변환
				getLimitOrderModel.setOnceSlePossWt(originOnceSlePossWt.intValue() / 1000); // 1회 판매 가능 중량 kg -> MT로 변환

				int totBundleQy = 0;

				// 지정가 주문 재고 파악, 최적의 BL 가져오기
				List<ItemPriceMatchingBlInfoVO> blList = this.getBlList(targetLimitOrderNo, commLimitGroupModel);
				log.warn("[limitOrderInvntryChk] blList : " + blList);

				// 최적의 BL 조회 후 잔여 중량으로 주문 가능 시 지정가 주문 수량 재설정
				if(blList.size() > 0 && blList.get(0).getLeftOverExistYn()) {
					// 주문톤수 - 남은중량 으로 변경
//					BigDecimal leftOverWeight = blList.get(0).getLeftOverWeight(); // 남은 중량
					BigDecimal leftOverWeight = new BigDecimal(getLimitOrderModel.getTargetLimitOrderWt() - blList.get(0).getLeftOverWeight().intValue());
					int sleUnitWt = getLimitOrderModel.getSleUnitWt(); // 판매 단위 중량

					int remainder = Math.floorDiv(leftOverWeight.intValue(), sleUnitWt); // 나머지 값
					int resetWt = remainder * sleUnitWt; // 나머지 * 판매 단위 중량 == 재설정된 중량
					// 상품 재고 검색 체크, 재설정된 중량이 0이면 재고 없음으로 판단
					if(resetWt == 0) {
						log.error("[limitOrderInvntryChk] 상품 재고 검색 실패, 지정가 주문 번호 : " + targetLimitOrderNo);

						failLimitOrderNoList.add(targetLimitOrderNo); // 재고 및 유효성 체크로 실패된 주문 번호 set

						String limitOrderSttusCode = "91"; // 지정가 주문 상태 코드[91(체결실패(재고 부족))] set
						String limitOrderFailrResn = null; // 주문 실패 사유

						// 지정가 주문 실패 시
						commLimitOrderService.limitOrderFail(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn
								, LIMIT_GROUP_SYSTEM, null, null
								, "Y", true, true);

						continue;
					} else {
						// 재설정된 중량이 0이 아니면 재설정된 중량으로 최적의 BL을 다시 구한다.
						getLimitOrderModel.setTargetLimitOrderWt(resetWt); // 재설정된 중량으로 set
						blList = this.getBlList(targetLimitOrderNo, commLimitGroupModel); // 최적의 BL 다시 가져오기

						getLimitOrderModel.setInvntryPartCnclsAt("Y"); // 재고 부분 체결 여부
					}
				} else if(blList.isEmpty()){
					//최적의 BL이 없을 경우 재고 없음으로 주문 처리
					log.error("[limitOrderInvntryChk] 상품 재고 검색 실패, 지정가 주문 번호 : " + targetLimitOrderNo);

					failLimitOrderNoList.add(targetLimitOrderNo); // 재고 및 유효성 체크로 실패된 주문 번호 set

					String limitOrderSttusCode = "91"; // 지정가 주문 상태 코드[91(체결실패(재고 부족))] set
					String limitOrderFailrResn = null; // 주문 실패 사유

					// 지정가 주문 실패 시
					commLimitOrderService.limitOrderFail(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn
							, LIMIT_GROUP_SYSTEM, null, null
							, "Y", true, true);

					continue;
				}

				// 재고 관련 주문 정합성 체크
				List<String> duplRemoveBrandCodeList = blList.stream().map(ItemPriceMatchingBlInfoVO::getBrandCode).distinct().collect(Collectors.toList());
				log.warn("[limitOrderInvntryChk] blList brandCode : " + String.valueOf(duplRemoveBrandCodeList));
				if(duplRemoveBrandCodeList.size() > 1) {
					log.error("[limitOrderInvntryChk] 브랜드 검색 오류["+String.valueOf(duplRemoveBrandCodeList)+"], 지정가 주문 번호 : " + targetLimitOrderNo);

					failLimitOrderNoList.add(targetLimitOrderNo); // 재고 및 유효성 체크로 실패된 주문 번호 set

					String limitOrderSttusCode = "91"; // 지정가 주문 상태 코드[91(체결실패(재고 부족))] set
					String limitOrderFailrResn = null; // 주문 실패 사유

					// 지정가 주문 실패 시
					commLimitOrderService.limitOrderFail(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn
							, LIMIT_GROUP_SYSTEM, null, null
							, "Y", true, true);

					continue;
				}
				getLimitOrderModel.setBrandCodeByPremium(duplRemoveBrandCodeList.get(0)); // 프리미엄 가격을 위한 브랜드코드 (가격정보 가져올때 사용)

				// 재고 관련 주문 정합성 체크 및 재고 선 차감
				// 최적의 BL에서 준 리스트에서 BL별로 재고 파악 및 재고 차감
				for(ItemPriceMatchingBlInfoVO  bl : blList) {
					OrderModel orderModel = new OrderModel();
					orderModel.setBlDetail(bl); // 선택된 bl를 객체에 담기
					orderModel.setMberId(LIMIT_GROUP_SYSTEM);
					orderModel.setSmlqyPurchsAt(getLimitOrderModel.getSmlqyPurchsAt());

					log.warn("[limitOrderInvntryChk] orderInvntryChk dstrctMlsfcCode : " + bl.getDstrctMlsfcCode());
					log.warn("[limitOrderInvntryChk] bl : " + String.valueOf(bl));

					log.warn("[limitOrderInvntryChk] bl.getWrhousngSeCode() : " + bl.getWrhousngSeCode());
					log.warn("[limitOrderInvntryChk] bl.getWrhousngPrearngeInvntryAt() : " + bl.getWrhousngPrearngeInvntryAt());

					// WMS 재고 API 호출 MAP 생성
					Map<String, Object> apiMap = new HashMap<String, Object>();
					apiMap.put("wrhousCode", bl.getWrhousCode());
					apiMap.put("itmCode", bl.getItmCode());
					apiMap.put("blNo", bl.getBlNo());

					Map<String, Object> resObj = new HashMap<String, Object>(); // 주석처리 test 용도
					// WMS 실시간 재고 체크
//					Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getLoInvntryUrl(), apiMap);
					// 응답 받은 MAP에서 QY가 현재 BL의 남은 실시간 번들 수 -> API 명세서 확인
					resObj.put("qy", "10000000"); // 주석처리 test 용도
//					log.debug("[limitOrderInvntryChk] 재고 체크 : " + String.valueOf(resObj));

					log.warn("[limitOrderInvntryChk] 재고 체크 resObj 존재 확인 : " + resObj);

					// 실시간 재고 API 호출 체크
					if(resObj != null) {
						log.warn("[limitOrderInvntryChk] 재고 체크 : " + String.valueOf(resObj));
						log.warn("[limitOrderInvntryChk] qy : " + resObj.get("qy"));

						// 최적의 BL에서 받아온 주문 할 번들 수
//						int searchBundleCnt = bl.getMatchedSleInvntryUnsleBundleBnt().intValue();
						BigDecimal searchBundleCntTemp = Optional.ofNullable(bl.getMatchedSleInvntryUnsleBundleBnt()).orElse(BigDecimal.ZERO);
						Double searchBundleCnt = searchBundleCntTemp.doubleValue();

						// WMS 실시간 재고 에서 받아온 주문 가능한 총 번들 수 (double로 넘어옴)
						double wmsBundleCnt = NumberUtils.toDouble(String.valueOf(resObj.get("qy")));

						log.warn("[limitOrderInvntryChk] searchBundleCnt : " + searchBundleCnt);
						log.warn("[limitOrderInvntryChk] wmsBundleCnt : " + wmsBundleCnt);

						// 실시간 재고 수량 체크
						if(wmsBundleCnt < searchBundleCnt) {
							log.error("실시간 재고 수량 부족, 지정가 주문 번호 : " + targetLimitOrderNo);

							failLimitOrderNoList.add(targetLimitOrderNo); // 재고 및 유효성 체크로 실패된 주문 번호 set

							String limitOrderSttusCode = "91"; // 지정가 주문 상태 코드[91(체결실패(재고 부족))] set
							String limitOrderFailrResn = null; // 주문 실패 사유

							// 지정가 주문 실패 시
							commLimitOrderService.limitOrderFail(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn
									, LIMIT_GROUP_SYSTEM, null, null
									, "Y", true, true);

							continue;
						}else {
							// 해당 BL의 실제 주문 번들 및 중량 셋팅
							bl.setRealMatchedOrderedBnt(bl.getMatchedOrderedBnt());
							bl.setRealMatchedSleInvntryUnsleBnt(bl.getMatchedSleInvntryUnsleBnt());
							bl.setRealMatchedSleInvntryUnsleBundleBnt(bl.getMatchedSleInvntryUnsleBundleBnt());
							// 실제 주문 번들 수 증가
							totBundleQy += searchBundleCnt.intValue();
						}
					}
//					WMS 실시간 재고 체크 적용될 때 아래 로직 필요, 20230519
//					else {
//						log.error("실시간 재고 호출 실패, 지정가 주문 번호 : " + targetLimitOrderNo);
//
//						failLimitOrderNoList.add(targetLimitOrderNo); // 재고 및 유효성 체크로 실패된 주문 번호 set
//
//						String limitOrderSttusCode = "91"; // 지정가 주문 상태 코드[91(체결실패(재고 부족))] set
//						String limitOrderFailrResn = null; // 주문 실패 사유
//
//						// 지정가 주문 실패 시
//						this.limitOrderFail(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn);
//
//						continue;
//					}

					log.warn("[limitOrderInvntryChk] totBundleQy : " + totBundleQy);

					try {
						// 주문 중량에 대한 재고 차감 및 재고 차감 FLAG ( TRUE ) 변경 -> 추후 에러 발생시 해당 BL 원복을 위해
						log.warn("[limitOrderInvntryChk] getMatchedSleInvntryUnsleBnt : " + orderModel.getBlDetail().getMatchedSleInvntryUnsleBnt());
						log.warn("[limitOrderInvntryChk] getMatchedSleInvntryUnsleBundleBnt : " + orderModel.getBlDetail().getMatchedSleInvntryUnsleBundleBnt());
						log.warn("[limitOrderInvntryChk] getMberId : " + orderModel.getMberId());
						log.warn("[limitOrderInvntryChk] getBlNo : " + orderModel.getBlDetail().getBlNo());
						// 주문 중량에 대한 재고 차감
						commOrderService.updateMinusInvntryBlInfoBas(orderModel);
						bl.setInvntryUdt(true); // 실재 재고 변경 확인
					} catch(Exception e) {
						log.error("[limitOrderInvntryChk] 주문 중량에 대한 재고 차감 실패, 지정가 주문 번호 : " + targetLimitOrderNo);

						failLimitOrderNoList.add(targetLimitOrderNo); // 주문 중량에 대한 재고 차감 실패된 주문 번호 set

						String limitOrderSttusCode = "91"; // 지정가 주문 상태 코드[91(체결실패(재고 부족))] set
						String limitOrderFailrResn = null; // 주문 실패 사유

						// 지정가 주문 실패 시
						commLimitOrderService.limitOrderFail(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn
								, LIMIT_GROUP_SYSTEM, null, null
								, "Y", true, true);

						continue;
					}

				}
				// 실제 주문 총 중량 셋팅
				getLimitOrderModel.setTotBundleQy(totBundleQy);
				// 재조회를 안하기 위해 최적의 BL 리스트 객체에 주소값 저장
				getLimitOrderModel.setBlList(blList);
			}

			// 타겟 지정가 주문 번호 리스트에서 재고 및 유효성 체크로 실패된 주문 번호 리스트를 제거한다.
			if(failLimitOrderNoList.size() > 0) {
				commLimitGroupModel.getTargetLimitOrderNoList().removeAll(failLimitOrderNoList);
			}
			log.warn("[limitOrderInvntryChk] commLimitGroupModel.getTargetLimitOrderNoList() : " + String.valueOf(commLimitGroupModel.getTargetLimitOrderNoList()));
		} catch(Exception e) {
			String stacktrace = ExceptionUtils.getStackTrace(e);
			log.error("[limitOrderInvntryChk] : " + stacktrace);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 가단가 지정가 주문의 재고 체크
	 * </pre>
	 * @date 2024. 9. 20.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 20.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param commLimitGroupModel
	 * @param targetLimitOrderNoInfoMap
	 */
	private void prvsnlLimitOrderInvntryChk(CommLimitGroupModel commLimitGroupModel, Map<String, CommOrLimitOrderBasVO> targetLimitOrderNoInfoMap) {
		try {
			// 재고 및 유효성 체크로 실패된 주문 번호 리스트
			List<String> failLimitOrderNoList = new ArrayList<String>();

			for(String targetLimitOrderNo : commLimitGroupModel.getTargetLimitOrderNoList()) {
				log.warn("[prvsnlLimitOrderInvntryChk] targetLimitOrderNo : " + targetLimitOrderNo);

				// 타겟 지정가 주문 번호에 대한 필요 정보 담을 맵의 객체 가져오기
				CommLimitOrderModel getLimitOrderModel = commLimitGroupModel.getLimitOrderModelMap().get(targetLimitOrderNo);

				CommOrLimitOrderBasVO targetLimitOrderNoInfo = targetLimitOrderNoInfoMap.get(targetLimitOrderNo); // 타겟 지정가 주문 번호에 해당하는 정보 가져오기

				getLimitOrderModel.setMetalCode(targetLimitOrderNoInfo.getMetalCode()); 			// 금속 코드 set
				getLimitOrderModel.setEntrpsNo(targetLimitOrderNoInfo.getEntrpsNo()); 				// 업체 번호 set
				getLimitOrderModel.setSleMthdCode("05"); 											// 판매 방식 코드 [05: 가단가]
				getLimitOrderModel.setItmSn(targetLimitOrderNoInfo.getItmSn()); 					// 아이템 순번
				getLimitOrderModel.setDstrctLclsfCode(targetLimitOrderNoInfo.getDstrctLclsfCode()); // 권역 대분류 코드
				getLimitOrderModel.setBrandGroupCode(targetLimitOrderNoInfo.getBrandGroupCode()); 	// 브랜드 그룹 코드
				getLimitOrderModel.setBrandCode(targetLimitOrderNoInfo.getBrandCode()); 			// 브랜드 코드

				// 재고 초기 데이터 설정 (판매 단위 중량, 1회 판매 가능 중량), 판매 단위 중량(상품별) 및 1회 판매 가능 중량(상품별), 최대 구매 가능 중량(상품별) 가져오기
				CommItmWtInfoVO selectItmWtInfo = commOrderService.selectItmWtInfo(targetLimitOrderNoInfo.getItmSn());
				if(selectItmWtInfo == null) {
					log.error("[prvsnlLimitOrderInvntryChk] 해당 상품_아이템 정보가 없습니다, 지정가 주문 번호 : " + targetLimitOrderNo);

					failLimitOrderNoList.add(targetLimitOrderNo); // 재고 및 유효성 체크로 실패된 주문 번호 set

					String limitOrderSttusCode = "94"; // 지정가 주문 상태 코드[94(유효성 검사 실패)] set
					String limitOrderFailrResn = "[" + targetLimitOrderNo + "] 의 해당 상품_아이템 정보가 없습니다."; // 주문 실패 사유

					// 지정가 주문 실패 시
					commPrvsnlOrderService.prvsnlLimitOrderFail(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn, LIMIT_GROUP_SYSTEM);

					continue;
				}

				BigDecimal originSleUnitWt = Optional.ofNullable(selectItmWtInfo.getSleUnitWt()).orElse(BigDecimal.ZERO); // 판매 단위 중량
				if(originSleUnitWt.compareTo(BigDecimal.ZERO) == 0) {
					log.error("[prvsnlLimitOrderInvntryChk] 판매 단위 중량이 null이거나 0입니다, 지정가 주문 번호 : " + targetLimitOrderNo);

					failLimitOrderNoList.add(targetLimitOrderNo); // 재고 및 유효성 체크로 실패된 주문 번호 set

					String limitOrderSttusCode = "94"; // 지정가 주문 상태 코드[94(유효성 검사 실패)] set
					String limitOrderFailrResn = "[" + targetLimitOrderNo + "] 의 판매 단위 중량이 null이거나 0입니다."; // 주문 실패 사유

					// 지정가 주문 실패 시
					commPrvsnlOrderService.prvsnlLimitOrderFail(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn, LIMIT_GROUP_SYSTEM);

					continue;
				}

				BigDecimal originOnceSlePossWt = Optional.ofNullable(selectItmWtInfo.getOnceSlePossWt()).orElse(BigDecimal.ZERO); // 1회 판매 가능 중량
				if(originOnceSlePossWt.compareTo(BigDecimal.ZERO) == 0) {
					log.error("[prvsnlLimitOrderInvntryChk] 1회 판매 가능 중량(상품별)이 null이거나 0입니다, 지정가 주문 번호 : " + targetLimitOrderNo);

					failLimitOrderNoList.add(targetLimitOrderNo); // 재고 및 유효성 체크로 실패된 주문 번호 set

					String limitOrderSttusCode = "94"; // 지정가 주문 상태 코드[94(유효성 검사 실패)] set
					String limitOrderFailrResn = "[" + targetLimitOrderNo + "] 의 1회 판매 가능 중량(상품별)이 null이거나 0입니다."; // 주문 실패 사유

					// 지정가 주문 실패 시
					commPrvsnlOrderService.prvsnlLimitOrderFail(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn, LIMIT_GROUP_SYSTEM);

					continue;
				}

				getLimitOrderModel.setSleUnitWt(originSleUnitWt.intValue() / 1000); // 판매 단위 중량 kg -> MT로 변환
				getLimitOrderModel.setOnceSlePossWt(originOnceSlePossWt.intValue() / 1000); // 1회 판매 가능 중량 kg -> MT로 변환

				int totBundleQy = 0;
				int sleUnitWt = getLimitOrderModel.getSleUnitWt(); 		   // 판매 단위 중량
				int onceSlePossWt = getLimitOrderModel.getOnceSlePossWt(); // 1회 판매 가능 중량

				// 해당 가단가 주문의 BL 목록 가져오기
				List<ItemPriceMatchingBlInfoVO> blList = commPrvsnlOrderService.selectPrvsnlOrderBlList(targetLimitOrderNoInfo.getOrderNo());
				log.warn("[prvsnlLimitOrderInvntryChk] blList : " + blList);

				// 주문된 BL별 필요데이터 세팅
				for(ItemPriceMatchingBlInfoVO  bl : blList) {

					// 해당 BL의 실제 주문 번들 및 중량 셋팅
					bl.setRealMatchedOrderedBnt(bl.getMatchedOrderedBnt());
					bl.setRealMatchedSleInvntryUnsleBnt(bl.getMatchedSleInvntryUnsleBnt());
					bl.setRealMatchedSleInvntryUnsleBundleBnt(bl.getMatchedSleInvntryUnsleBundleBnt());

					// 실제 주문 번들 수 체크
					totBundleQy += bl.getSleInvntryUnsleBundleBnt();

					bl.setInvntryUdt(true); // 실재 재고 변경 확인 flag

					log.warn("[prvsnlLimitOrderInvntryChk] totBundleQy : " + totBundleQy);

					// 판매단위 중량 당 tolerance 범위 및 최소,최대,최적 번들 수 와 중량 별도 세팅
					Map<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO> mapMatchingWeightValueMap = new HashMap<>();
					mapMatchingWeightValueMap = itemPriceService.setMathcingValuesMap(bl, sleUnitWt, onceSlePossWt, sleUnitWt);

					bl.setWeightMappingCalculateValues(mapMatchingWeightValueMap);
				}

				// 실제 주문 총 중량 셋팅
				getLimitOrderModel.setTotBundleQy(totBundleQy);
				// 재조회를 안하기 위해 최적의 BL 리스트 객체에 주소값 저장
				getLimitOrderModel.setBlList(blList);
			}

			// 타겟 지정가 주문 번호 리스트에서 재고 및 유효성 체크로 실패된 주문 번호 리스트를 제거한다.
			if(failLimitOrderNoList.size() > 0) {
				commLimitGroupModel.getTargetLimitOrderNoList().removeAll(failLimitOrderNoList);
			}

			log.warn("[prvsnlLimitOrderInvntryChk] commLimitGroupModel.getTargetLimitOrderNoList() : " + String.valueOf(commLimitGroupModel.getTargetLimitOrderNoList()));
		} catch(Exception e) {
			String stacktrace = ExceptionUtils.getStackTrace(e);
			log.error("[prvsnlLimitOrderInvntryChk] : " + stacktrace);
		}
	}

	/**
	 * <pre>
	 * 처리내용: Azure Service Bus Queue에서 받은 메시지 전문을 저장하고 지정가 주문 로그 순번을 반환
	 * </pre>
	 * @date 2023. 5. 8.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 8.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param limitOrderRequestDt
	 * @param mesaage
	 * @return
	 * @throws Exception
	 */
	private long insertQueueMessageLog(String limitOrderRequestDt, String mesaage) throws Exception {
		log.warn("[insertQueueMessageLog] in");
		log.warn("[insertQueueMessageLog] limitOrderRequestDt : " + limitOrderRequestDt);
		log.warn("[insertQueueMessageLog] mesaage : " + mesaage);

		OrLimitOrderLogVO orLimitOrderLogVO = OrLimitOrderLogVO.builder().limitOrderRequestDt(limitOrderRequestDt).requstSpclty(mesaage).build();

		// 주문_지정가 주문 로그 등록, 지정가 주문 로그 순번을 반환
		int insertOrLimitOrderLog = limitOrderMapper.insertOrLimitOrderLog(orLimitOrderLogVO);
		log.warn("[insertQueueMessageLog] insertOrLimitOrderLog : " + insertOrLimitOrderLog);
		log.warn("[insertQueueMessageLog] limitOrderLogSn : " + orLimitOrderLogVO.getLimitOrderLogSn());

		return orLimitOrderLogVO.getLimitOrderLogSn();
	}

	/**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 로그 수정, Queue 메시지 삭제 요청 시 응답 일시를 수정
	 * </pre>
	 * @date 2023. 4. 27.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 4. 27.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param limitOrderLogSn
	 * @throws Exception
	 */
	private void updateOrLimitOrderLog(long limitOrderLogSn) throws Exception {
		log.warn("[updateOrLimitOrderLog] in");
		log.warn("[updateOrLimitOrderLog] limitOrderLogSn : " + limitOrderLogSn);

		// 주문_지정가 주문 로그 수정, Queue 메시지 삭제 요청 시 응답 일시를 수정한다.
		int updateOrLimitOrderLog = limitOrderMapper.updateOrLimitOrderLog(limitOrderLogSn);
		log.warn("[updateOrLimitOrderLog] updateOrLimitOrderLog : " + updateOrLimitOrderLog);
	}

	/**
	 * <pre>
	 * 처리내용: 최적의 BL 가져오기
	 * </pre>
	 * @date 2023. 5. 3.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 3.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param targetLimitOrderNo
	 * @param commLimitGroupModel
	 * @return
	 * @throws Exception
	 */
	private List<ItemPriceMatchingBlInfoVO> getBlList(String targetLimitOrderNo, CommLimitGroupModel commLimitGroupModel) throws Exception {
		CommLimitOrderModel getLimitOrderModel = commLimitGroupModel.getLimitOrderModelMap().get(targetLimitOrderNo);
		log.warn("[getBlList] getLimitOrderModel : " + String.valueOf(getLimitOrderModel));

		// 최적의 BL 리스트를 가져온다 (leftOverWtRetrunBlEmptyYn 재고없음처리 리턴여부 사용)
		return commOrderService.getOptimalBlList(getLimitOrderModel.getEntrpsNo(), getLimitOrderModel.getMetalCode(), getLimitOrderModel.getItmSn()
				, getLimitOrderModel.getDstrctLclsfCode(), getLimitOrderModel.getBrandGroupCode(), getLimitOrderModel.getBrandCode()
				, getLimitOrderModel.getSleMthdCode(), getLimitOrderModel.getTargetLimitOrderWt(), getLimitOrderModel.getSleUnitWt()
				, getLimitOrderModel.getOnceSlePossWt(), getLimitOrderModel.getBlNo(), "Y", null, null, getLimitOrderModel.getSmlqyPurchsAt());
	}


}
