package com.sorincorp.api.or.service;

import javax.jms.JMSException;
import javax.jms.Message;

import com.sorincorp.comm.order.model.CommLimitOrderQueueMsgVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderQueueMsgVO;

/**
 * LimitGroupService.java
 * 지정가 그룹 Service 인터페이스
 * 
 * @version
 * @since 2023. 4. 14.
 * @author srec0049
 */
public interface LimitGroupService {
	
	/**
	 * <pre>
	 * 처리내용: 지정가 그룹 처리
	 * </pre>
	 * @date 2023. 4. 25.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 4. 25.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commLimitOrderQueueMsgVO
	 * @param message
	 * @throws JMSException
	 * @throws Exception
	 */
	public void procLimitGroup(CommLimitOrderQueueMsgVO commLimitOrderQueueMsgVO, Message message);

	/**
	 * <pre>
	 * 처리내용: 가단가 지정가 그룹 처리
	 * </pre>
	 * @date 2024. 8. 27.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 8. 27.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public void procPrvsnlLimitGroup(CommPrvsnlLimitOrderQueueMsgVO commPrvsnlLimitOrderQueueMsgVO, Message message);

}
