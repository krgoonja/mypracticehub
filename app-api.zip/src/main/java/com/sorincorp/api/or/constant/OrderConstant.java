package com.sorincorp.api.or.constant;

public class OrderConstant {

	/** 결제 방식 코드 */
	public enum SetleMthdCode {
		/** 이월렛 */
		EWALLET("10")
		/** 전자상거래보증 */
		,MRTGG("20")
		/** 구매자금 */
		,LON("30")
		/** 여신 */
		,CDTLN("40")
		/** 증거금 */
		,WRTM("90")
		;

		private String code;
		private SetleMthdCode(String code){
			this.code = code;
		}
		public String getCode() {
			return code;
		}
		public static SetleMthdCode codeOf(String code) {
			if (null == code) {
				throw new IllegalArgumentException("SetleMthdCode Name must not be null.");
			}
			SetleMthdCode type = null;
			for (SetleMthdCode currentType : SetleMthdCode.values()) {
				if (currentType.getCode().equals(code)) {
					type = currentType;
					break;
				}
			}
			if (null == type) {
				throw new IllegalArgumentException("This SetleMthdCode[ code : " + code + " ] is not supported.");
	        } else {
	            return type;
	        }
		}
	}

	/** 결제 방식 상세 코드 */
	public enum SetleMthdDetailCode {
		/** 케이지크레딧 */
		SORIN_CREDT_MARSH("4010")
		/** 이월렛+이월렛 */
		,EWALLET_EWALLET("9010")
		/** 이월렛+구매자금 */
		,EWALLET_LON("9030")
		;

		private String code;
		private SetleMthdDetailCode(String code){
			this.code = code;
		}
		public String getCode() {
			return code;
		}
		public static SetleMthdDetailCode codeOf(String code) {
			if (null == code) {
				throw new IllegalArgumentException("SetleMthdDetailCode Name must not be null.");
			}
			SetleMthdDetailCode type = null;
			for (SetleMthdDetailCode currentType : SetleMthdDetailCode.values()) {
				if (currentType.getCode().equals(code)) {
					type = currentType;
					break;
				}
			}
			if (null == type) {
				throw new IllegalArgumentException("This SetleMthdDetailCode[ code : " + code + " ] is not supported.");
	        } else {
	            return type;
	        }
		}
	}

	/** 결제 유형 코드 */
	public enum SetleTyCode {
		/** 정산 */
		EXCCLC("10")
		/** 환불 */
		,REFND("20")
		;

		private String code;
		private SetleTyCode(String code){
			this.code = code;
		}
		public String getCode() {
			return code;
		}
		public static SetleTyCode codeOf(String code) {
			if (null == code) {
				throw new IllegalArgumentException("SetleTyCode Name must not be null.");
			}
			SetleTyCode type = null;
			for (SetleTyCode currentType : SetleTyCode.values()) {
				if (currentType.getCode().equals(code)) {
					type = currentType;
					break;
				}
			}
			if (null == type) {
				throw new IllegalArgumentException("This SetleTyCode[ code : " + code + " ] is not supported.");
	        } else {
	            return type;
	        }
		}
	}

	/** 여신서비스구분코드 */
	public enum CdtlnSvcSeCode {
		/** 전자상거래보증 */
		ELCTRN_BIZDL_GRNTY("01")
		/** 케이지크레딧 */
		,SORIN_CREDT_MARSH("02")
		;

		private String code;
		private CdtlnSvcSeCode(String code){
			this.code = code;
		}
		public String getCode() {
			return code;
		}
		public static CdtlnSvcSeCode codeOf(String code) {
			if (null == code) {
				throw new IllegalArgumentException("CdtlnSvcSeCode Name must not be null.");
			}
			CdtlnSvcSeCode type = null;
			for (CdtlnSvcSeCode currentType : CdtlnSvcSeCode.values()) {
				if (currentType.getCode().equals(code)) {
					type = currentType;
					break;
				}
			}
			if (null == type) {
				throw new IllegalArgumentException("This CdtlnSvcSeCode[ code : " + code + " ] is not supported.");
	        } else {
	            return type;
	        }
		}
	}
}
