package com.sorincorp.api.or.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * OrLimitOrderLogVO.java
 * 주문_지정가 주문 로그 VO 객체
 * 
 * @version
 * @since 2023. 4. 14.
 * @author srec0049
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrLimitOrderLogVO {
	
	/**
	 * 지정가 주문 로그 순번
	 */
	private long limitOrderLogSn;
	
	/**
	 * 지정가 주문 요청 일시
	 */
	private String limitOrderRequestDt;
	
	/**
	 * 요청 전문
	 */
	private String requstSpclty;
}
