package com.sorincorp.api.or.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.lo.comm.constant.LoCommConstant;
import com.sorincorp.api.lo.comm.entity.LoResponseEntity;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.order.mapper.CommOrderMapper;
import com.sorincorp.comm.order.model.CommLimitGroupModel;
import com.sorincorp.comm.order.model.CommLimitOrderQueueMsgVO;
import com.sorincorp.comm.order.model.CommOrLimitOrderBasVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderQueueMsgVO;
import com.sorincorp.comm.order.service.CommPrvsnlOrderService;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.queue.azure.servicebus.sender.AzureServiceBusQueueSender;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * QueueSendController.java
 * 큐 보내기 테스트 컨트롤러
 * 
 * @version
 * @since 2023. 4. 6.
 * @author srec0049
 */
@Slf4j
@RestController
public class QueueSendController {
	
	/**
	 * 메시지 게이트웨이 인터페이스
	 */
	@Autowired
	AzureServiceBusQueueSender azureServiceBusQueueSender;
	
	/**
	 * 실시간 판매 가격 Service
	 */
	@Autowired
	private PcInfoService pcInfoService;
	
	/**
	 * 가단가 주문 공통 Service
	 */
	@Autowired
	private CommPrvsnlOrderService commPrvsnlOrderService;

	/**
	 * 주문 공통 Mapper
	 */
	@Autowired
	private CommOrderMapper commOrderMapper;
	
	/**
	 * http 통신
	 */
	@Autowired
	private HttpClientHelper httpClientHelper;
	
	/**
	 * [API -> FO] 지정가 주문 요청 쓰레드 테스트 API 서비스 URL
	 */
	@Value("${api.limit.orderTest.url}")
	private String LIMIT_ORDER_TEST_URL;
	
	/**
	 * [API -> BO] 연결 테스트 URL
	 */
	@Value("${api.limit.boTest.url}")
	private String BO_TEST_URL;
	
	
	/**
     * (limitOrder or test) Queue에 보내기 테스트 API 
     */
    @PostMapping("/queueSend")
    public void queueSend(@RequestBody CommLimitOrderQueueMsgVO commLimitOrderQueueMsgVO) throws Exception {
    	log.info(">> [queueSend] commLimitOrderQueueMsgVO : " + String.valueOf(commLimitOrderQueueMsgVO));
    	
    	// 임시
    	String metalCode = commOrderMapper.selectMetalCode(commLimitOrderQueueMsgVO.getItmSn());
    	log.info(">> [queueSend] metalCode : " + metalCode);
    	
    	// 실시간 판매 가격 정보 조회
    	PrSelVO prSelVO = pcInfoService.getNewestPrSelRltm(metalCode, commLimitOrderQueueMsgVO.getItmSn(), commLimitOrderQueueMsgVO.getDstrctLclsfCode()
    			, commLimitOrderQueueMsgVO.getBrandGroupCode(), commLimitOrderQueueMsgVO.getBrandCode()
    			, DateUtil.getNowDateTime("yyyyMMdd"));
		log.warn(">> 실시간 판매 가격 정보 조회 prSelVO 존재 확인 : " + String.valueOf(prSelVO));
		
		commLimitOrderQueueMsgVO.setSlePcRltmSn(prSelVO.getSlePcRltmSn()); // 판매 가격 실시간 순번
		commLimitOrderQueueMsgVO.setLmePcRltmSn(prSelVO.getLmePcRltmSn()); // LME 가격 실시간 순번
		commLimitOrderQueueMsgVO.setLme3m(prSelVO.getThreemonthLmePc()); // LME 3M
		commLimitOrderQueueMsgVO.setLmeCash(prSelVO.getLmePc()); // LME 현금
		commLimitOrderQueueMsgVO.setLmeMdatCffcnt(prSelVO.getLmeMdatCffcnt()); // LME 조정 계수
		commLimitOrderQueueMsgVO.setEhgtPcRltmSn(prSelVO.getEhgtPcRltmSn()); // 환율 가격 실시간 순번
		commLimitOrderQueueMsgVO.setSpex(prSelVO.getEhgtPc()); // 현물환
		commLimitOrderQueueMsgVO.setSpexMdatCffcnt(prSelVO.getFxMdatCffcnt()); // 현물환 조정 계수
    	
    	// 아웃바운드 채널 통해 Queue에 메시지 보내기
    	azureServiceBusQueueSender.send(commLimitOrderQueueMsgVO);
    }
    
    /**
     * (prvsnlLimitOrder or prvsnlTest) Queue에 보내기 테스트 API 
     */
    @PostMapping("/prvsnlQueueSend")
    public void prvsnlQueueSend(@RequestBody CommPrvsnlLimitOrderQueueMsgVO commPrvsnlLimitOrderQueueMsgVO) throws Exception {
    	log.info(">> [prvsnlQueueSend] commPrvsnlLimitOrderQueueMsgVO : " + String.valueOf(commPrvsnlLimitOrderQueueMsgVO));

    	// 가단가 주문 데이터 조회
    	CommOrLimitOrderBasVO prvsnlLimitOrderInfo = commPrvsnlOrderService.selectCommOrPrvsnlOrderBasList(commPrvsnlLimitOrderQueueMsgVO.getLimitOrderNoList()).get(0);

    	// 실시간 판매 가격 정보 조회
    	PrSelVO prSelVO = pcInfoService.getNewestPrSelRltm(prvsnlLimitOrderInfo.getMetalCode(), prvsnlLimitOrderInfo.getItmSn(), prvsnlLimitOrderInfo.getDstrctLclsfCode()
    			, prvsnlLimitOrderInfo.getBrandGroupCode(), prvsnlLimitOrderInfo.getBrandCode()
    			, DateUtil.getNowDateTime("yyyyMMdd"));
		log.warn(">> 실시간 판매 가격 정보 조회 prSelVO 존재 확인 : " + String.valueOf(prSelVO));

		commPrvsnlLimitOrderQueueMsgVO.setLimitOrderStdrSlePc(prSelVO.getEndPc()); // 지정가 주문 기준 판매 가격
    	commPrvsnlLimitOrderQueueMsgVO.setSlePcRltmSn(prSelVO.getSlePcRltmSn()); // 판매 가격 실시간 순번
    	commPrvsnlLimitOrderQueueMsgVO.setLmePcRltmSn(prSelVO.getLmePcRltmSn()); // LME 가격 실시간 순번
    	commPrvsnlLimitOrderQueueMsgVO.setLme3m(prSelVO.getThreemonthLmePc()); // LME 3M
    	commPrvsnlLimitOrderQueueMsgVO.setLmeCash(prSelVO.getLmePc()); // LME 현금
    	commPrvsnlLimitOrderQueueMsgVO.setLmeMdatCffcnt(prSelVO.getLmeMdatCffcnt()); // LME 조정 계수
    	commPrvsnlLimitOrderQueueMsgVO.setEhgtPcRltmSn(prSelVO.getEhgtPcRltmSn()); // 환율 가격 실시간 순번
    	commPrvsnlLimitOrderQueueMsgVO.setSpex(prSelVO.getEhgtPc()); // 현물환
    	commPrvsnlLimitOrderQueueMsgVO.setSpexMdatCffcnt(prSelVO.getFxMdatCffcnt()); // 현물환 조정 계수

    	// 아웃바운드 채널 통해 Queue에 메시지 보내기
    	azureServiceBusQueueSender.prvsnlSend(commPrvsnlLimitOrderQueueMsgVO);
    }
    
    
    /**
     * <pre>
     * 처리내용: 지정가 주문 쓰레드 테스트 용도
     * </pre>
     * @date 2023. 5. 24.
     * @author srec0049
     * @history 
     * ------------------------------------------------
     * 변경일                 작성자          변경내용
     * ------------------------------------------------
     * 2023. 5. 24.          srec0049         최초작성
     * ------------------------------------------------
     * @param commLimitGroupModel
     * @throws Exception
     */
    @PostMapping("/foSend")
    public ResponseEntity<?> foSend(@RequestBody CommLimitGroupModel commLimitGroupModel) throws Exception {
    	String message = "success";
    	HttpStatus httpStatus = HttpStatus.OK;
    	
    	for(long a=0; a<commLimitGroupModel.getLimitOrderLogSn(); a++) {
	    	try {
	    		// 지정가 그룹 주문 요청 [FO 프로젝트]
		    	Map<String, Object> limitOrderResMap = httpClientHelper.postCallApi(LIMIT_ORDER_TEST_URL, commLimitGroupModel);
		    	log.info("[foSend][" + a + "] >> limitOrderResMap : " + limitOrderResMap);
		    	if(limitOrderResMap == null) {
		    		commLimitGroupModel.setLimitOrderSttusCode("95"); // 체결실패 (기타) : API 호출 실패
					throw new CommCustomException("지정가 그룹 주문 요청 API 호출 실패");
				}
		    	
		    	Thread.sleep(1000);
	    	} catch(Exception e) {
				log.error("[foSend] e : " + e.getMessage());
				message = ExceptionUtils.getStackTrace(e);
				httpStatus = HttpStatus.BAD_GATEWAY;
				log.error("[foSend] stacktrace : " + message);
				log.info(String.valueOf(commLimitGroupModel));
	    	}
    	}
    	
    	return ResponseEntity
				.status(httpStatus)
				.body(new LoResponseEntity(httpStatus.toString(), message));
    }
    
    /**
     * <pre>
     * 처리내용: BO 연결 테스트 용도
     * </pre>
     * @date 2023. 7. 4.
     * @author srec0049
     * @history 
     * ------------------------------------------------
     * 변경일                 작성자          변경내용
     * ------------------------------------------------
     * 2023. 7. 4.          srec0049         최초작성
     * ------------------------------------------------
     * @param request
     * @return
     * @throws Exception
     */
    @GetMapping("/boSend/{testNo}")
    public ResponseEntity<?> boSend(@PathVariable(value = "testNo") String testNo) throws Exception {
    	String message = "success";
    	HttpStatus httpStatus = HttpStatus.OK;
    	
    	try {
    		// BO 연결 요청
	    	Map<String, Object> resMap = httpClientHelper.getCallApi(BO_TEST_URL + "/" + testNo);
	    	log.info("[boSend] >> resMap : " + resMap);
	    	if(resMap == null) {
				throw new CommCustomException("BO 연결 요청 API 호출 실패");
			}
    	} catch(Exception e) {
			log.error("[boSend] e : " + e.getMessage());
			message = ExceptionUtils.getStackTrace(e);
			httpStatus = HttpStatus.BAD_GATEWAY;
			log.error("[boSend] stacktrace : " + message);
    	}
    	
    	return ResponseEntity
				.status(httpStatus)
				.body(new LoResponseEntity(httpStatus.toString(), message));
    }
    
	@GetMapping("/testResponseEntity")
	public ResponseEntity<?> testResponseEntity(HttpServletRequest request) throws Exception {

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new LoResponseEntity(LoCommConstant.SUCCESS_RESULT_CODE, LoCommConstant.SUCCESS_RESULT_MSG));
	}
    
}
