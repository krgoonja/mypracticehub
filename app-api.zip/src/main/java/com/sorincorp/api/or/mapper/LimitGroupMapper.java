package com.sorincorp.api.or.mapper;

import java.util.List;

import com.sorincorp.api.or.model.OrLimitOrderLogVO;
import com.sorincorp.comm.order.model.CommLimitGroupModel;
import com.sorincorp.comm.order.model.CommLimitOrderModel;
import com.sorincorp.comm.order.model.CommOrLimitOrderBasVO;

/**
 * LimitGroupMapper.java
 * 지정가 그룹 Mapper 인터페이스
 * 
 * @version
 * @since 2023. 4. 14.
 * @author srec0049
 */
public interface LimitGroupMapper {
	
	/**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 로그 등록, 지정가 주문 로그 순번을 반환
	 * </pre>
	 * @date 2023. 4. 14.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 14.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orLimitOrderLogVO
	 * @return
	 * @throws Exception
	 */
	public int insertOrLimitOrderLog(OrLimitOrderLogVO orLimitOrderLogVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 로그 수정, Queue 메시지 삭제 요청 시 응답 일시를 수정
	 * </pre>
	 * @date 2023. 4. 17.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 17.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param limitOrderLogSn
	 * @return
	 * @throws Exception
	 */
	public int updateOrLimitOrderLog(long limitOrderLogSn) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 최종 타겟 지정가 주문 번호들의 해당 주문_지정가 주문 기본(OR_LIMIT_ORDER_BAS) 정보(지정가 주문 큐 메시지 정보와 재고 체크 중량 업데이트)를 업데이트
	 * </pre>
	 * @date 2023. 5. 8.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 8.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commLimitGroupModel
	 * @return
	 * @throws Exception
	 */
	public int updateOrLimitOrderBasByFinalTarget(CommLimitGroupModel commLimitGroupModel) throws Exception;
}
