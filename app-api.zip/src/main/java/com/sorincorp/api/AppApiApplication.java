package com.sorincorp.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
public class AppApiApplication extends SpringApplicationBuilder{


	public static void main(String[] args) {
		SpringApplication.run(AppApiApplication.class, args);
	}   
}
