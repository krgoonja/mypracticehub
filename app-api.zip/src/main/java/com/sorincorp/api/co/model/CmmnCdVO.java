package com.sorincorp.api.co.model;

import java.util.List;

import lombok.Data;

/**
 * CmmnCdVO.java
 * @version
 * @since 2021. 8. 26.
 * @author srec0033
 */
@Data
public class CmmnCdVO {
	
	private List<CmmnCdDtlVO> codeList;
	
}
