package com.sorincorp.api.co.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * CmmnCdDtlVO.java
 * @version
 * @since 2021. 8. 26.
 * @author srec0033
 */
@Data
public class CmmnCdDtlVO {
	
	/** 인터페이스 번호 **/
	@ApiModelProperty(hidden = true)
	private int intrfcNo;

    /**
     * 메인 코드
    */
    private String mainCode;
    /**
     * 서브 코드
    */
    private String subCode;
    /**
     * 코드 명
    */
    private String codeName;
    /**
     * 사용 여부1_사용 여부
    */
    private String useYN;
    /**
     * 사용 여부2_시스템 여부
    */
    private String sysAt;
    /**
     * 서브코드 길이
    */
    private int codeLength;
    /**
     * 참조1
    */
    private String ref1;
    /**
     * 참조2
    */
    private String ref2;
    /**
     * 참조3
    */
    private String ref3;
    /**
     * 설명1
    */
    private String desc1;
    /**
     * 설명2
    */
    private String desc2;
    /**
     * 정렬순서
    */
    private int orderBy;
    /**
     * 최초 등록자 
    */
    private String createUser;
    /**
     * 최초 등록 일시
    */
    private String createDate;
    /**
     * 최종 변경자 
    */
    private String updateUser;
    /**
     * 최종 변경 일시
    */
    private String updateDate;
    /**
     * 참조(STS)1
    */
    private String refs1;
    /**
     * 참조(STS)2
    */
    private String refs2;
    /**
     * 참조(STS)3
    */
    private String refs3;
    /**
     * 참조(STS)4
    */
    private String refs4;
    /**
     * 참조(STS)5
    */
    private String refs5;
    /**
     * 참조(STS)6
    */
    private String refs6;
    /**
     * 참조(number)1
    */
    private java.math.BigDecimal refn1;
    /**
     * 참조(number)2
    */
    private java.math.BigDecimal refn2;
    /**
     * 참조(number)3
    */
    private java.math.BigDecimal refn3;
    /**
     * 참조(number)4
    */
    private java.math.BigDecimal refn4;
	
	/** 인터페이스 구분(I/U/D) **/
	private String intrfcSe;
}
