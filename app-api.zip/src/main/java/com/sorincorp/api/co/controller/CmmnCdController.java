package com.sorincorp.api.co.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.co.model.CmmnCdVO;
import com.sorincorp.api.co.service.CmmnCdService;
import com.sorincorp.api.common.APICommConstant;
import com.sorincorp.api.common.ApiResponseEntity;
import com.sorincorp.comm.btb.comm.HttpClientHelper;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * CmmnCdController.java
 * @version
 * @since 2021. 8. 26.
 * @author srec0033
 */
@RestController
@RequestMapping("/api/sts")
@Api("공통코드 관리")
public class CmmnCdController {

	@Autowired
	private CmmnCdService cdService;

	@Autowired
	private HttpClientHelper httpClientHelper;

	/* 공통관리	SOREC-IF-012 */
	@PostMapping("/code_info")
	@ApiOperation(value = "SOREC-IF-012: STS 공통코드 정보 수신", notes = "STS 공통코드 정보를 수신해 EC에 저장한다.")
	public ResponseEntity<?> setCmmnCdInfo(@RequestBody CmmnCdVO cmmnCdVo, HttpServletRequest request) throws Exception {

		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		cdService.saveCmmnCd(cmmnCdVo);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new ApiResponseEntity(APICommConstant.SUCCESS_RESULT_CODE, APICommConstant.SUCCESS_RESULT_MSG));
	}
}
