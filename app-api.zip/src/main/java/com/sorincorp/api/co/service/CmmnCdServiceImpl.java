package com.sorincorp.api.co.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.co.model.CmmnCdDtlVO;
import com.sorincorp.api.co.model.CmmnCdVO;
import com.sorincorp.api.common.APICommConstant;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;

/**
 * CmmnCdServiceImpl.java
 * @version
 * @since 2021. 8. 26.
 * @author srec0033
 */
@Service
public class CmmnCdServiceImpl implements CmmnCdService {

	@Autowired
	private HttpClientHelper httpClientHelper;

	/**
	 *	STS의 공통코드 정보를 EC에 저장한다.
	 */
	@Override
	public void saveCmmnCd(CmmnCdVO cmmnCd) throws Exception {

		String intrfc_code = "SOREC-IF-012";
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, cmmnCd);

		try {	//성공
			/** 서비스 로직(interface table insert) **/
			List<CmmnCdDtlVO> codeList = cmmnCd.getCodeList();
			if(codeList != null) {
				for(CmmnCdDtlVO cdDtl: codeList) {
					cdDtl.setIntrfcNo(btbLogVo.getIntrfcNo());

					/* 사용자 등록 */
					cdDtl.setCreateUser(intrfc_code);
					cdDtl.setUpdateUser(intrfc_code);

					//cdMapper.insertIfCoCmmnCd(cdDtl);
				}

				/** 서비스 로직(원본/원복이력 table insert) **/
				for(CmmnCdDtlVO cdDtl: cmmnCd.getCodeList()) {
					/* 사용자 등록 */
					cdDtl.setCreateUser(intrfc_code);
					cdDtl.setUpdateUser(intrfc_code);

					//cdMapper.insertCoCmmnCdBas(cdDtl);
					//cdMapper.insertCoCmmnCdHst(cdDtl);
				}
			}

			btbLogVo.setIntrfcRspnsCode(APICommConstant.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(APICommConstant.SUCCESS_RESULT_MSG);

			/** Redis 갱신 **/
			//commonCodeService.initCommonCodeList();

		} catch (Exception e) { //에러 발생
			btbLogVo.setIntrfcRspnsCode(APICommConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(APICommConstant.ERROR_RESULT_MSG);
			throw new Exception(e.getMessage());
		}

		/** 통합 로그 UPDATE **/
		httpClientHelper.updateBtbLog(btbLogVo);
	}

}
