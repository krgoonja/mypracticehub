package com.sorincorp.api.co.service;

import com.sorincorp.api.co.model.CmmnCdVO;

/**
 * CmmnCdService.java
 * @version
 * @since 2021. 8. 26.
 * @author srec0033
 */
public interface CmmnCdService {
	
	/**
	 * <pre>
	 * 처리내용: STS의 공통코드 정보를 EC에 저장한다.
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 26.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param cmmnCd
	 * @throws Exception
	 */
	public void saveCmmnCd(CmmnCdVO cmmnCd) throws Exception;
	
}
