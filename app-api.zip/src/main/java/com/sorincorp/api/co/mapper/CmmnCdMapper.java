package com.sorincorp.api.co.mapper;

import com.sorincorp.api.co.model.CmmnCdDtlVO;

/**
 * CmmnCdMapper.java
 * @version
 * @since 2021. 8. 26.
 * @author srec0033
 */
public interface CmmnCdMapper {

	/**
	 * <pre>
	 * 처리내용: 공통코드 Bas를 등록, 수정, 삭제한다.
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 26.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param cmmnCdDtl
	 * @throws Exception
	 */
	void insertCoCmmnCdBas(CmmnCdDtlVO cmmnCdDtl) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공통코드 history를 등록한다. 
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 26.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param cmmnCdDtl
	 * @throws Exception
	 */
	void insertCoCmmnCdHst(CmmnCdDtlVO cmmnCdDtl) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 인터페이스_공통코드를 등록한다.
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 26.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param cmmnCdDtl
	 * @throws Exception
	 */
	void insertIfCoCmmnCd(CmmnCdDtlVO cmmnCdDtl) throws Exception;
}
