package com.sorincorp.api.erp.model;

import lombok.Data;

/**
 * 
 * ErpAcntTrnsmitRequestVO.java
 * ERP 계정 송신 공통 VO.java
 * 
 * @version
 * @since 2021. 10. 5.
 * @author srec0054
 */
@Data
public class ErpAcntTrnsmitRequestVO {

	/**
	 * 상품매출 EC
	 * */
	
	/**주문 번호*/
	private String orderNo;
	
	/**취소 교환 반품 번호*/
	private String canclExchngRtngudNo;
	
	/**세금 계산서 발행 구분 코드 리스트*/
	private String taxBillIsuSeCode;	
	
	/**
	 * 판관비(지급수수료, 물류비)
	 * */
	
	/**비용 정산 요청 번호*/
	private String ctExcclcRequstNo;
	
	/**ERP 비용 코드*/
    private String erpCtCode;
    
    /**업체 번호(공급업체)*/
    private String entrpsNo;
    
	/**수익 사업 단위*/
    private String ernBsnsUnit;
    
    /**주계정*/
    private String mainAcnt;
    
    /**보조 계정*/
    private String asstnAcnt;
    
    /**공급가*/
    private String splpc;
    
    /**부가세*/
    private String vat;
    
    /**정산 확정 금액*/
    private String excclcDcsnAmount;

	/**
	 * 재고조정 관련 변수
	 */
    
    /** 재고조정 구분 코드 */
	private String erpInvntryAdjstCode;

	/** 재고조정 메탈 코드 */
	private String erpInvntryAdjstMetalCode;
	
	/** 재고조정 대상 년월 */
	private String yyyyMM;
    
}//end class()
