package com.sorincorp.api.erp.model;

import lombok.Data;

/**
 * 
 * ErpIfErpVo.java
 * EC ERP interface 공통 VO.JAVA
 * 
 * @version
 * @since 2021. 10. 13.
 * @author srec0054
 */
@Data
public class ErpIfErpVO {

	/**openJDE API 응답*/
	/**openJDE : mnT5JNO (Job번호 채번, API의 Key)*/
	private String mnT5JNO;
	
	/**openJDE : mnT5IFNO (Interface번호 채번, Interface Processing의 Key)*/
	private String mnT5IFNO;
	
	/**openJDE : szT5IFTP (Interface 유형)*/
	private String szT5IFTP;
	
	/**openJDE : szT5SYSC (Interface System Code)*/
	private String szT5SYSC;
	
	/**openJDE : szT5TDPID (Geust System Program ID)*/
	private String szT5TDPID;
	
	/**openJDE : szUSER (사용자)*/
	private String szUSER;

	
	/**IF_ERP*/
	/**시스템 구분*/
	private String sysSe;
	
	/**인터페이스 순번*/
	private String intrfcSn;
	
	/**인터페이스 번호*/
	private String intrfcNo;
	
	/**ERP 인터페이스 번호*/
	private String erpIntrfcNo;
	
	/**ERP 인터페이스 유형*/
	private String erpIntrfcTy;
	
	/**ERP 인터페이스 라인 번호*/
	private String erpIntrfcLineNo;
	
	/**ERP 인터페이스 시스템 코드*/
	private String erpIntrfcSysCode;
	
	/**성공 여부*/
	private String succesAt;
	
	/**이커머스 오더번호*/
	private String ecOrderNo;
	
	/**이커머스 오더 라인 번호*/
	private String ecOrderLineNo;
	
	/**취소 교환 반품 번호*/
	private String canclExchngRtngudNo;
	
	/**취소 교환 반품 상태*/
	private String canclExchngRtngudTy;
	
	/**취소 교환 반품 상태 코드*/
	private String canclExchngRtngudTyCode;
	
	/**이커머스 인보이스 번호*/
	private String ecInvoiceNo;
	
	/**검증 결과*/
	private String vrifyResult;
	
	/**오류 내역*/
	private String errorDtls;
	
	/**오류 건수*/
	private String errorCo;
	
	/**정산 유형*/
	private String excclcTy;
	
	/**정산 순번*/
	private String excclcSn;
	
	/**오더 회사*/
	private String orderCmpny;
	
	/**오더 번호*/
	private String orderNo;
	
	/**오더 유형*/
	private String orderTy;
	
	/**라인 번호*/
	private String lineNo;
	
	/**오더 SUFFIX*/
	private String orderSuffix;
	
	/**거래처*/
	private String bcnc;
	
	/**납품처*/
	private String dvyfgOffic;
	
	/**사업장*/
	private String bplc;
	
	/**수익 사업 단위*/
	private String ernBsnsUnit;
	
	/**오더 일자*/
	private String orderDe;
	
	/**출하 일자*/
	private String shipmntDe;
	
	/**송장 일자*/
	private String invcDe;
	
	/**GL 일자*/
	private String glDe;
	
	/**품목 번호*/
	private String prdlstNo;
	
	/**오더 수량*/
	private String orderQy;
	
	/**출하 수량*/
	private String shipmntQy;
	
	/**차이 수량*/
	private String diffQy;
	
	/**세목 코드*/
	private String taxitmCode;
	
	/**세율*/
	private String taxrt;
	
	/**GL Class*/
	private String glClass;
	
	/**원화 단가*/
	private String wonUntpc;
	
	/**원화 금액*/
	private String wonAmount;
	
	/**통화 코드*/
	private String crncyCode;
	
	/**외화 단가*/
	private String fgcryUntpc;
	
	/**외화 금액*/
	private String fgcryAmount;
	
	/**환율*/
	private String ehgt;
	
	/**LC 번호*/
	private String lcNo;
	
	/**BL 번호*/
	private String blNo;
	
	/**배치 번호*/
	private String batchNo;
	
	/**배치 유형*/
	private String batchTy;
	
	/**회사*/
	private String cmpny;
	
	/**문서 번호*/
	private String docNo;
	
	/**문서 유형*/
	private String docTy;
	
	/**지급 항목*/
	private String pymntIem;
	
	/**결제 코드*/
	private String setleCode;
	
	/**지급 항목 선급*/
	private String pymntIemAdvpay;
	
	/**일반 회계 라인 번호*/
	private String gnrlAccnutLineNo;
	
	/**공급가 액*/
	private String splpcAm;
	
	/**세 액*/
	private String taxAm;
	
	/**비과세 액*/
	private String taxxmptAm;
	
	/**총 액*/
	private String totAm;
	
	/**외화 공급가 액*/
	private String fgcrySplpcAm;
	
	/**외화 세 액*/
	private String fgcryTaxAm;
	
	/**외화 비과세 액*/
	private String fgcryTaxxmptAm;
	
	/**외화 총 액*/
	private String fgcryTotAm;
	
	/**조정 처리 유무*/
	private String mdatProcessEnnc;
	
	/**기준 통화*/
	private String stdrCrncy;
	
	/**입고 전표 배치 번호*/
	private String wrhousngChitBatchNo;
	
	/**입고 전표 배치 유형*/
	private String wrhousngChitBatchTy;
	
	/**입고 전표 문서 번호*/
	private String wrhousngChitDocNo;
	
	/**입고 전표 문서 유형*/
	private String wrhousngChitDocTy;
	
	/**선물 평가 익월 전표 라인 번호*/
	private String ftrsEvlNxhChitLineNo;
	
	/**ERP 인터페이스 구분*/
	private String erpIntrfcSe;
	
	/**ERP 전기 역처리 코드*/
	private String erpFrmtrmStatnProcessCode;
	
	/**전기 역처리 일자*/
	private String frmtrmStatnProcessDe;
	
	/**EDI 회사*/
	private String ediCmpny;
	
	/**EDI 유형*/
	private String ediTy;
	
	/**EDI 번호*/
	private String ediNo;
	
	/**EDI 트랜잭션 번호*/
	private String ediTrnscNo;
	
	/**EDI 라인 번호*/
	private String ediLineNo;
	
	/**EDI 배치 번호*/
	private String ediBatchNo;
	
	/**이커머스 선급 요청 아이디*/
	private String ecAdvpayRequstId;
	
	/**이커머스 처리 순번*/
	private String ecProcessSn;
	
	/**만기 일자*/
	private String exprtnDe;
	
	/**비고*/
	private String rm;
	
	/**설명*/
	private String dc;
	
	/**주 계정*/
	private String weekAcnt;
	
	/**보조 계정*/
	private String asstnAcnt;
	
	/**IF 비고*/
	private String ifRm;
	
	/**이커머스 프로그램 아이디*/
	private String ecProgrmId;
	
	/**선물 평가 계정 코드*/
	private String ftrsEvlAcntCode;
	
	/**생성자 ERP 계정*/
	private String crtrErpAcnt;
	
	/**이커머스 수정 일자*/
	private String ecUpdtDe;
	
	/**이커머스 수정 시간*/
	private String ecUpdtTime;
	
	/**ERP 프로그램 아이디*/
	private String erpProgrmId;
	
	/**ERP 처리 단말기*/
	private String erpProcessTrmnl;
	
	/**ERP 수정일자*/
	private String erpUpdtDate;
	
	/**ERP 수정시간*/
	private String erpUpdtTime;
	
	/**인터페이스 처리 상태*/
	private String intrfcProcessSttusCode;
	
	/**최초 등록자 아이디*/
	private String frstRegisterId;
	
	/**최초 등록 일시*/
	private String frstRegistDt;
	
	/**최종 변경자 아이디*/
	private String lastChangerId;
	
	/**최종 변경 일시*/
	private String lastChangeDt;

	/**업무 구분*/
	private String jobSe;
	
	/**closeJDE RESULT*/
	private String closeJdeResult;
	
	/**ERP 비용 코드*/
	private String erpCtCode;
	
	/**비용 AP / GL 구분*/
	private String apglDiv;
	
	/**패널티 금액*/
	private String penltyAmount;
	
	/**업무 구분*/
	private String taxBillIsuSeCode;
	
	/**전체 부분 여부*/
	private String allPartAt;
	
	/**
	 * 재고 조정
	 */
	/**재고 조정 년월*/
	private String invntryAdjstYyyymm;
	/**재고 조정 순번 */
	private String invntryAdjstSeq;
	/**재고 조정 ERP ORDER TYPE */
	private String imErpOrderType;
	/**재고 조정 ERP PO NO */
	private String imErpPoNo;
	/**재고 조정 ERP PO LINE */
	private String imErpPoLine;
	/**재고 조정 ERP PO 거래처 코드 */
	private String imErpPoCustCd;
	/**재고 조정 GL DATE ( Julian ) */
	private String imErpGlDateJulian;
	/**재고 조정 GL DATE */
	private String imErpGlDate;
	/**재고 조정 ERP ITEM CODE */
	private String imErpItemCode;
	/**재고 조정 BL NO */
	private String imBlNo;
	/**재고 조정 대상 수량 */
	private String imQty;
	/**재고 조정 라인 번호 */
	private String imErpLine;
	/**재고 조정 비고 */
	private String imLotn;
	/**재고 조정 최초 등록자 아이디 */
	private String imFrstRegisterId;
	/**재고 조정 최초 등록 일시 ( Julian ) */
	private String imFrstRegistDate;
	/**재고 조정 최초 등록 시간 */
	private String imFrstRegistTime;
	
}//end class()
