package com.sorincorp.api.erp.mapper;

import java.util.List;

import com.sorincorp.api.erp.model.ErpAcntTrnsmitRequestVO;
import com.sorincorp.api.erp.model.ErpIfErpVO;

/**
 * 
 * ErpAcntTrnsmitMapper.java
 * ERP 계정 송신 공통 Mapper.java
 * 
 * @version
 * @since 2021. 10. 5.
 * @author srec0054
 */
public interface ErpAcntTrnsmitMapper {
	
	/**
	 * 
	 * <pre>
	 * 주문 정보 조회
	 * </pre>
	 * @date 2021. 10. 13.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 14.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	ErpAcntTrnsmitRequestVO requestVo
	 * @return	ErpIfErpVO
	 */
	List<ErpIfErpVO> selectErpOrderInfo(ErpAcntTrnsmitRequestVO requestVo);
	
	/**
	 * <pre>
	 * 처리내용: 주문 정보 다중 BL 조회
	 * </pre>
	 * @date 2023. 1. 31.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 1. 31.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param requestVo
	 * @return
	 */
	List<ErpIfErpVO> selectErpOrderInfoSeprat(ErpAcntTrnsmitRequestVO requestVo);
	
	/**
	 * <pre>
	 * 처리내용: 주문 정보 배송비 조회
	 * </pre>
	 * @date 2023. 3. 3.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 3.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param requestVo
	 * @return
	 */
	ErpIfErpVO selectErpOrderDlvrfInfo(ErpAcntTrnsmitRequestVO requestVo);
	
	/**
	 * 
	 * <pre>
	 * 클레임 정보 조회
	 * </pre>
	 * @date 2021. 10. 20.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 20.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	ErpAcntTrnsmitRequestVO requestVo
	 * @return	ErpIfErpVO
	 */
	ErpIfErpVO selectErpClaimInfo(ErpAcntTrnsmitRequestVO requestVo);
	
	/**
	 * 
	 * <pre>
	 * ERP 코드 조회
	 * </pre>
	 * @date 2021. 10. 27.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 27.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	ErpAcntTrnsmitRequestVO requestVo
	 * @return	ErpIfErpVO
	 */
	ErpIfErpVO selectErpCodeInfo(ErpAcntTrnsmitRequestVO requestVo);
	
	/**
	 * 
	 * <pre>
	 * EC openJDE API 응답 결과 > EC IF_ERP INSERT
	 * </pre>
	 * @date 2021. 10. 13.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 13.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param ErpIfErpVO returnObj
	 */
	void insertOpenJDEIfErp(ErpIfErpVO returnObj);
	
	/**
	 * 
	 * <pre>
	 * EC openJDE API 응답 결과 > EC IF_ERP_ADJ INSERT
	 * </pre>
	 * @date 2023. 06. 09.
	 * @author jdrttl
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 06. 09.		jdrttl				최초작성
	 * ------------------------------------------------
	 * @param ErpIfErpVO returnObj
	 */
	void insertOpenJDEIfErpAdj(ErpIfErpVO returnObj);
	
	/**
	 * 
	 * <pre>
	 * IF_ERP 결과값 업데이트
	 * </pre>
	 * @date 2021. 10. 22.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 22.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param ErpIfErpVO erpIfErpVo
	 */
	void updateErpCloseResult(ErpIfErpVO erpIfErpVo);
	
	/**
	 * 
	 * <pre>
	 * 재고 조정 대상 조회
	 * </pre>
	 * @date 2023. 05. 31
	 * @author jdrttl
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 05. 31			jdrttl				최초작성
	 * ------------------------------------------------
	 * @param 	ErpAcntTrnsmitRequestVO requestVo
	 * @return	ErpIfErpVO
	 */
	List<ErpIfErpVO> selectErpInvntryAdjstList(ErpAcntTrnsmitRequestVO requestVo);
}//end interface()
