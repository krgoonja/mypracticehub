package com.sorincorp.api.erp.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * 
 * ErpOpenJDEVO.java
 * openJDE 공통 VO.java
 * 
 * @version
 * @since 2021. 10. 12.
 * @author srec0054
 */
@Data
public class ErpOpenJDEVO {

	/**in*/
	@JsonProperty("cTargetTable")
    private String cTargetTable;		//1(F55TD01) / 2(F55TD03) 구분
	
    private String szT5IFTP;			//Interface 유형
    private String szT5SYSC;			//Interface System Code
    private String mnT5RCNT;			//Edit 후 라인수가 맞지 않으면 에러(Close API), 테스트 항목(추후 제거될 수 있음)
    private String szUSER;				//사용자
    private String szT5TDPID;			//Geust System Program ID
    
    /**out*/
    private String mnT5IFNO;			//Interface번호 채번, Interface Processing의 Key
    private String mnT5JNO;				//Job번호 채번, API의 Key
    
    @JsonProperty("cErrorFlag")
    private String cErrorFlag;			//정상 - 공란, 에러발생 - E
    private String szErrorDescription;	//에러내용
    private String result;				//erp api 송신 결과
    
    /**etc*/
    private String sysSe;				//시스템 구분 01:SECS
}//end ()
