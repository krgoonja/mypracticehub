package com.sorincorp.api.erp.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.erp.comm.constant.ErpAcntTrnsmitConstant;
import com.sorincorp.api.erp.comm.entity.ErpAcntTrnsmitResponseEntity;
import com.sorincorp.api.erp.model.ErpAcntTrnsmitRequestVO;
import com.sorincorp.api.erp.model.ErpCloseJDEVO;
import com.sorincorp.api.erp.service.ErpAcntTrnsmitService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * ErpAcntTrnsmitController.java
 * ERP 계정 송신 공통 Controller.java
 * 
 * @version
 * @since 2021. 10. 5.
 * @author srec0054
 */
@Slf4j
@RestController
@RequestMapping("/api/erpAcntTrnsmit")
@Api("ERP 계정 송신")
public class ErpAcntTrnsmitController {

	@Autowired
	ErpAcntTrnsmitService erpAcntTrnsmitService;
	
	@PostMapping("/ErpGoodsSelng")
	@ApiOperation(value = "상품매출(내수EC) ERP계정 송신", notes = "상품매출(내수EC) ERP계정 송신")
	public ResponseEntity<?> erpGoodsSelng(@RequestBody ErpAcntTrnsmitRequestVO requestVo, HttpServletRequest request) throws Exception {		
		log.debug("ErpAcntTrnsmitController::erpGoodsSelng (상품매출(내수EC) ERP계정 송신) Start");
		log.debug("requestVo.toString() = " + requestVo.toString());
		
		erpAcntTrnsmitService.erpGoodsSelng(requestVo);
		
		log.debug("ErpAcntTrnsmitController::erpGoodsSelng (상품매출(내수EC) ERP계정 송신) End");
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new ErpAcntTrnsmitResponseEntity(ErpAcntTrnsmitConstant.SUCCESS_RESULT_CODE, ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG));
	}//end erpGoodsSelng()
	
	@PostMapping("/ErpEwalletFee")
	@ApiOperation(value = "판관비(지급수수료) ERP계정 송신", notes = "판관비(지급수수료) ERP계정 송신")
	public ResponseEntity<?> erpEwalletFee(@RequestBody ErpAcntTrnsmitRequestVO requestVo, HttpServletRequest request) throws Exception {
		log.debug("ErpAcntTrnsmitController::erpEwalletFee (판관비(지급수수료) ERP계정 송신) Start");
		log.debug("requestVo.toString() = " + requestVo.toString());
		
		ErpCloseJDEVO erpCloseJDEVO = erpAcntTrnsmitService.erpEwalletFee(requestVo);	// 판관비(지급수수료) ERP 계정 송싱
		String cErrorFlag 			= erpCloseJDEVO.getCErrorFlag();					// API Error Flag
		String resultCode			= null;												// RESULT CODE
		String resultMsg			= null;												// RESULT MESSAGE
		
		if("E".equals(cErrorFlag)) {
			resultCode	= ErpAcntTrnsmitConstant.ERROR_RESULT_CODE;
			resultMsg	= ErpAcntTrnsmitConstant.ERROR_RESULT_MSG;
		} else {
			resultCode	= ErpAcntTrnsmitConstant.SUCCESS_RESULT_CODE;
			resultMsg	= ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG;
		}//end if()
		
		log.debug("ErpAcntTrnsmitController::erpEwalletFee (판관비(지급수수료) ERP계정 송신) End");
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new ErpAcntTrnsmitResponseEntity(resultCode, resultMsg));
	}//end erpEwalletFee()
	
	@PostMapping("/ErpLgistCt")
	@ApiOperation(value = "판관비(물류비) ERP계정 송신", notes = "판관비(물류비) ERP계정 송신")
	public ResponseEntity<?> erpLgistCt(@RequestBody ErpAcntTrnsmitRequestVO requestVo, HttpServletRequest request) throws Exception {
		log.debug("ErpAcntTrnsmitController::erpLgistCt (판관비(물류비) ERP계정 송신) Start");
		log.debug("requestVo.toString() = " + requestVo.toString());
		
		ErpCloseJDEVO erpCloseJDEVO = erpAcntTrnsmitService.erpLgistCt(requestVo);
		String cErrorFlag 			= erpCloseJDEVO.getCErrorFlag();					// API Error Flag
		String resultCode			= null;												// RESULT CODE
		String resultMsg			= null;												// RESULT MESSAGE
		
		if("E".equals(cErrorFlag)) {
			resultCode	= ErpAcntTrnsmitConstant.ERROR_RESULT_CODE;
			resultMsg	= ErpAcntTrnsmitConstant.ERROR_RESULT_MSG;
		} else {
			resultCode	= ErpAcntTrnsmitConstant.SUCCESS_RESULT_CODE;
			resultMsg	= ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG;
		}//end if()
		
				
		log.debug("ErpAcntTrnsmitController::erpLgistCt (판관비(물류비) ERP계정 송신) End");
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new ErpAcntTrnsmitResponseEntity(resultCode, resultMsg));
	}//end erpLgistCt()
	
	@PostMapping("/ErpInvntryAdjst")
	@ApiOperation(value = "재고조정 ERP계정 송신", notes = "재고조정 ERP계정 송신")
	public ResponseEntity<?> ErpInvntryAdjst(@RequestBody ErpAcntTrnsmitRequestVO requestVo, HttpServletRequest request) throws Exception {		
		log.debug("ErpAcntTrnsmitController::ErpInvntryAdjst (재고조정 ERP계정 송신) Start");
		log.debug("requestVo.toString() = " + requestVo.toString());
		
		erpAcntTrnsmitService.erpInvntryAdjst(requestVo);
		
		log.debug("ErpAcntTrnsmitController::erpGoodsSelng (상품매출(내수EC) ERP계정 송신) End");
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new ErpAcntTrnsmitResponseEntity(ErpAcntTrnsmitConstant.SUCCESS_RESULT_CODE, ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG));
	}//end erpGoodsSelng()
	
}//end class()
