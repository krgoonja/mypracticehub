package com.sorincorp.api.erp.comm.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * 
 * ErpAcntTrnsmitResponseEntity.java
 * ERP 계정 송신 공통 ResponseEntity.java
 * 
 * @version
 * @since 2021. 10. 5.
 * @author srec0054
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ErpAcntTrnsmitResponseEntity {

	/** 결과 코드 */
	private String responseCode;
	
	/** 결과 메시지 */
	private String responseMessage;
	
}//end class()
