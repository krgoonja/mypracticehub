package com.sorincorp.api.erp.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.api.erp.comm.constant.ErpAcntTrnsmitConstant;
import com.sorincorp.api.erp.mapper.ErpAcntTrnsmitMapper;
import com.sorincorp.api.erp.model.ErpAcntTrnsmitRequestVO;
import com.sorincorp.api.erp.model.ErpCloseJDEVO;
import com.sorincorp.api.erp.model.ErpIfErpVO;
import com.sorincorp.api.erp.model.ErpOpenJDEVO;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

/**
 *
 * ErpAcntTrnsmitServiceImpl.java
 * ERP 계정 송신 공통 ServiceImpl.java
 *
 * @version
 * @since 2021. 10. 5.
 * @author srec0054
 */
@Slf4j
@Service
public class ErpAcntTrnsmitServiceImpl implements ErpAcntTrnsmitService {
//	@Autowired
//	private HttpClientHelper httpClientHelper;

	@Autowired
	private AssignService assignService;

	@Autowired
	private ErpIntrlckInfoService erpIntrlckInfoService;
	
	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private ErpAcntTrnsmitMapper erpAcntTrnsmitMapper;

	/**주문-기본매출 ERP계정 송신*/
	@Transactional(rollbackFor = Exception.class)
	@Override
	public void erpGoodsSelng(ErpAcntTrnsmitRequestVO requestVo) throws Exception {
		log.debug("ErpAcntTrnsmitServiceImpl::erpGoodsSelng Start");

		//인터페이스 송신 전문 등록 (IF_LOG)
		BtoBInrecfcLogVO btbLogVo =httpClientHelper.insertBtbLog(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_117, requestVo);

		/**
		 * 업무 구분
		 * 01 : 주문
		 * 02 : 중량
		 * 03 : 취소
		 * 04 : 교환
		 * 05 : 반품
		 * 07 : 판매중량정산 역처리
		 */
		String taxBillIsuSeCode = requestVo.getTaxBillIsuSeCode();

		try {
			/**
			 * 세금계산서 발행 후 국세청 응답 결과 성공 건인 경우에 대해 ERP 계정 송신
			 * 업무 구분에 따른 ERP 계정 송신 프로세스
			 * 1) ORDER		: CSU {판매마감(원주문)} || CSI {판매마감(원주문 - 물품대)} > CSB {판매마감(원주문 - 배송비)}
			 *
			 * 2) WT 		: CWS {판매중량정산(원주문)}
			 *
			 * 3) CANCL 	: RSU {판매마감 역처리(원주문 역처리)} > 잡이익 패널티 (계정 및 맵핑 항목 미정)
			 *
			 * 4) EXCHNG 	: 전체 교환 	> CWS{판매중량정산(클레임)}
			 * 				  부분 교환 	> CWS{판매중량정산(클레임)}
			 *
			 * 5) RTNGUD	: 전체 반품 	> RSU{판매마감 역처리(원주문 역처리)}
			 * 						 	> RWS{판매중량정산 역처리(원주문 역처리)}
			 * 				  부분 반품	> CWS{판매중량정산(클레임)}
			 * 
			 * 7) CANCLWT	: RWS {판매중량정산 역처리}
			 * 
			 * 8) DLVRF		: CSB {판매마감(원주문 - 배송비)} 
			 */
			if(ErpAcntTrnsmitConstant.JOB_SE_01.equals(taxBillIsuSeCode)
					|| ErpAcntTrnsmitConstant.JOB_SE_02.equals(taxBillIsuSeCode)
					|| ErpAcntTrnsmitConstant.JOB_SE_03.equals(taxBillIsuSeCode)
					|| ErpAcntTrnsmitConstant.JOB_SE_07.equals(taxBillIsuSeCode)) {
				erpGoodsSelngOrderWtCanclProcess(requestVo);
			}
			else if(ErpAcntTrnsmitConstant.JOB_SE_04.equals(taxBillIsuSeCode)) {
				erpGoodsSelngExchngProcess(requestVo);
			}
			else if(ErpAcntTrnsmitConstant.JOB_SE_05.equals(taxBillIsuSeCode)) {
				erpGoodsSelngRtngudProcess(requestVo);
			}
			else if(ErpAcntTrnsmitConstant.JOB_SE_08.equals(taxBillIsuSeCode)) {
				dlvrfExcclcProcess(requestVo);
			}

			btbLogVo.setIntrfcRspnsCode(ErpAcntTrnsmitConstant.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG);

		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(ErpAcntTrnsmitConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			log.error("ErpAcntTrnsmitServiceImpl::erpGoodsSelng exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		} finally {
			//인터페이스 수신 전문 등록 (IF_LOG)
			httpClientHelper.updateBtbLog(btbLogVo);
		}

		log.debug("ErpAcntTrnsmitServiceImpl::erpGoodsSelng End");
	}//end erpGoodsSelng()

	/**
	 *
	 * <pre>
	 * ORDER 	: CSU {판매마감(원주문)} || CSI {판매마감(원주문 - 물품대)} > CSB {판매마감(원주문 - 배송비)}
	 * WT 		: CWS {판매중량정산(원주문)}
	 * CANCL 	: RSU {판매마감 역처리(원주문 역처리)} > 잡이익 패널티 (계정 및 맵핑 항목 미정)
	 * </pre>
	 * @date 2021. 11. 4.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 4.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	ErpAcntTrnsmitRequestVO requestVo
	 * @throws 	Exception
	 */
	public void erpGoodsSelngOrderWtCanclProcess(ErpAcntTrnsmitRequestVO requestVo) throws Exception {
		log.debug("ErpAcntTrnsmitServiceImpl::erpGoodsSelngOrderWtProcess Start");

		List<ErpIfErpVO> selectErpOrderInfoList = null;						// 주문정보, BL별 + 중량변동금에 대한 데이터 별로 VO 객체 생성
		ErpOpenJDEVO returnObj 			= null;								// openJDE VO
		ErpIfErpVO erpIfErpVo 			= new ErpIfErpVO();					// EC 내부 VO
		String openJDEResult			= null;								// openJDE API 응답 결과
		String taxBillIsuSeCode	 		= requestVo.getTaxBillIsuSeCode();	// 업무구분
		String jobSe					= null;
		String exceptionResult			= ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG;
		int erpIntrfcLineNo             = 0;

		// 2023-01-31 변경사항 : 설정값에 따라 기존 쿼리문(운영 소스)과 신규 쿼리문(개발 소스)의 분기 처리
		/* ERP 분리 전송 여부 설정값 가져오기 - Y값일시 true, 아니면 false */
		boolean isSeprat = StringUtils.equals("Y", commonCodeService.getCodeValueRetVo("ERP_SEPRAT_TRNSMIS_CODE", "10").getCodeDcone());
		log.debug("ERP 분리 전송 여부 설정값 : {}", isSeprat);
		
		try {

			if(ErpAcntTrnsmitConstant.JOB_SE_01.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.ORDER;
			if(ErpAcntTrnsmitConstant.JOB_SE_02.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.WT;
			if(ErpAcntTrnsmitConstant.JOB_SE_03.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.CANCL;
			if(ErpAcntTrnsmitConstant.JOB_SE_04.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.EXCHNG;
			if(ErpAcntTrnsmitConstant.JOB_SE_05.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.RTNGUD;
			if(ErpAcntTrnsmitConstant.JOB_SE_07.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.CANCLWT;

			// OR_ORDER_BAS (주문) 정보
			if(isSeprat) {	//신규 쿼리문 사용 : 주문 정보 BL별 조회(many rows)
				selectErpOrderInfoList = erpAcntTrnsmitMapper.selectErpOrderInfoSeprat(requestVo);
			} else {		//기존 쿼리문 사용 : 주문 정보 통합 조회(1 row)
				selectErpOrderInfoList = erpAcntTrnsmitMapper.selectErpOrderInfo(requestVo);
			}
			
			// 2023-01-30 변경사항 : 오더 수량(orderQy)이 0일 경우 ERP 전송 대상에서 제외
			selectErpOrderInfoList = selectErpOrderInfoList.stream()
					.filter(erpOrderInfo -> Double.parseDouble(erpOrderInfo.getOrderQy()) != 0)
					.collect(Collectors.toList());

			if(ErpAcntTrnsmitConstant.JOB_SE_03.equals(taxBillIsuSeCode)) {
				for (ErpIfErpVO selectErpOrderInfo : selectErpOrderInfoList) {
					selectErpOrderInfo.setCanclExchngRtngudNo(requestVo.getCanclExchngRtngudNo());			// 이커머스 취소교환반품번호
					selectErpOrderInfo.setCanclExchngRtngudTy(ErpAcntTrnsmitConstant.CANCL_TY);				// 이머커스 취소교환반품상태
					selectErpOrderInfo.setCanclExchngRtngudTyCode(ErpAcntTrnsmitConstant.CANCL_TY_CODE);	// 이커머스 취소교환반품상태코드
				}
			}//end if()

			// ERP openJDE
			returnObj = erpIntrlckInfoService.openJDE(taxBillIsuSeCode);
			
			// ERP openJDE API 응답 결과
			openJDEResult = returnObj.getResult();
			
			for (ErpIfErpVO selectErpOrderInfo : selectErpOrderInfoList) {
				selectErpOrderInfo.setJobSe(jobSe);													// 업무 구분
				selectErpOrderInfo.setEcProgrmId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_117);	// 이커머스 프로그램 아이디
				
				// ERP openJDE API 응답 결과 : 성공
				if(ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG.equals(openJDEResult)) {
					// openJDE API Response + OR_ORDER_BAS (주문) 정보
					erpIfErpVo = erpIfErpVoSet(returnObj, selectErpOrderInfo);
					
					// 등록자, 수정자
					erpIfErpVo.setFrstRegisterId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_117);
					erpIfErpVo.setLastChangerId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_117);
					
					// 2023-01-10 변경사항 : 다중 BL 및 고정가 주문  ERP 분리 처리 로직 추가
					erpIntrfcLineNo++;	//Interface 라인번호, 항목당 1씩 증가
					erpIfErpVo.setErpIntrfcLineNo(String.valueOf(erpIntrfcLineNo));		//Interface 라인번호
					
					// IF_ERP (ERP 인터페이스) 데이터 적재
					erpAcntTrnsmitMapper.insertOpenJDEIfErp(erpIfErpVo);
					
					// ERP editF55TD01JDE
					erpIntrlckInfoService.editF55TD01JDE(erpIfErpVo);
				} else {
					
					log.debug("ErpAcntTrnsmitServiceImpl::erpGoodsSelng ERP openJDE API response result Fail");
					
				}//end if()
			}


		} catch (Exception e) {

			exceptionResult	= ErpAcntTrnsmitConstant.ERROR_RESULT_MSG;
			log.error("ErpAcntTrnsmitServiceImpl::erpGoodsSelngOrderWtProcess exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		} finally {

			// ERP closeJDE
			erpIntrlckInfoService.closeJDE(returnObj);
			
			// 2023-03-03 변경사항 : 주문에 대한 배송비 항목 처리 로직 추가, 사용 계정은 CSB(배송비)
			if(isSeprat
					&& ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG.equals(exceptionResult)
					&& ErpAcntTrnsmitConstant.JOB_SE_01.equals(taxBillIsuSeCode)) {
				
				log.debug("배송비 계정 송신");
				dlvrfExcclcProcess(requestVo);
			}
			// 취소 : RSU (판매마감 역처리) 정상 수행, 종료
			else if(ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG.equals(exceptionResult)
					&& ErpAcntTrnsmitConstant.JOB_SE_03.equals(taxBillIsuSeCode)) {

				log.debug("취소 : RSU (판매마감 역처리) 정상 수행, 종료");
				log.debug("잡이익 (패널티 + 상품금액 차액) 계정 송신");
				// 잡이익 (패널티 + 상품금액 차액) 계정 송신
				jobProfitPntProcess(requestVo);

			}//end if()

		}

		log.debug("ErpAcntTrnsmitServiceImpl::erpGoodsSelngOrderWtProcess End");
	}//end erpGoodsSelngOrderWtCanclProcess()

	/**
	 *
	 * <pre>
	 * EXCHNG : 전체 교환 	> CWS{판매중량정산(클레임)}
	 * 			부분 교환 	> CWS{판매중량정산(클레임)}
	 * </pre>
	 * @date 2021. 11. 4.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 4.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param requestVo
	 * @throws Exception
	 */
	public void erpGoodsSelngExchngProcess(ErpAcntTrnsmitRequestVO requestVo) throws Exception {
		log.debug("ErpAcntTrnsmitServiceImpl::erpGoodsSelngExchngProcess Start");

		ErpIfErpVO selectErpClaimInfo 	= new ErpIfErpVO();		// 클레임정보
		ErpOpenJDEVO returnObj 			= new ErpOpenJDEVO();	// openJDE VO
		ErpIfErpVO erpIfErpVo 			= new ErpIfErpVO();		// EC 내부 VO
		String openJDEResult			= null;					// openJDE API 응답 결과
		String jobSe					= null;					// 업무구분
		String taxBillIsuSeCode	 		= requestVo.getTaxBillIsuSeCode();	// 업무구분


		try {

			if(ErpAcntTrnsmitConstant.JOB_SE_01.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.ORDER;
			if(ErpAcntTrnsmitConstant.JOB_SE_02.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.WT;
			if(ErpAcntTrnsmitConstant.JOB_SE_03.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.CANCL;
			if(ErpAcntTrnsmitConstant.JOB_SE_04.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.EXCHNG;
			if(ErpAcntTrnsmitConstant.JOB_SE_05.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.RTNGUD;

			// OR_CANCL_EXCHNG_RTNGUD_BAS (클레임) 정보
			selectErpClaimInfo = erpAcntTrnsmitMapper.selectErpClaimInfo(requestVo);
			selectErpClaimInfo.setJobSe(jobSe);														// 업무 구분
			selectErpClaimInfo.setEcProgrmId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_117);		// 이커머스 프로그램 아이디
			selectErpClaimInfo.setCanclExchngRtngudNo(requestVo.getCanclExchngRtngudNo());			// 이커머스 취소교환반품번호
			selectErpClaimInfo.setCanclExchngRtngudTy(ErpAcntTrnsmitConstant.EXCHNG_TY);			// 이머커스 취소교환반품상태
			selectErpClaimInfo.setCanclExchngRtngudTyCode(ErpAcntTrnsmitConstant.EXCHNG_TY_CODE);	// 이커머스 취소교환반품상태코드

			// ERP openJDE
			returnObj = erpIntrlckInfoService.openJDE(ErpAcntTrnsmitConstant.INTERFACE_TYPE_CWS);

			// ERP openJDE API 응답 결과
			openJDEResult = returnObj.getResult();

			// ERP openJDE API 응답 결과 : 성공
			if(ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG.equals(openJDEResult)) {

				// openJDE API Response + OR_CANCL_EXCHNG_RTNGUD_BAS (클레임) 정보
				erpIfErpVo = erpIfErpVoSet(returnObj, selectErpClaimInfo);

				// 등록자, 수정자
				erpIfErpVo.setFrstRegisterId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_117);
				erpIfErpVo.setLastChangerId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_117);

				// IF_ERP (ERP 인터페이스) 데이터 적재
				erpAcntTrnsmitMapper.insertOpenJDEIfErp(erpIfErpVo);

				// ERP editF55TD01JDE
				erpIntrlckInfoService.editF55TD01JDE(erpIfErpVo);

				// ERP closeJDE
				erpIntrlckInfoService.closeJDE(returnObj);

			} else {
				log.debug("ErpAcntTrnsmitServiceImpl::erpGoodsSelngRtngudProcess ERP::ALL_PART_AT_N openJDE API response result Fail");
			}//end if()

		} catch (Exception e) {
			log.error("ErpAcntTrnsmitServiceImpl::erpGoodsSelngExchngProcess exception = " + e.getMessage());
			throw new Exception(e.getMessage());
		}

		log.debug("ErpAcntTrnsmitServiceImpl::erpGoodsSelngExchngProcess End");
	}//end erpGoodsSelngExchngProcess()

	/**
	 *
	 * <pre>
	 * RTNGUD :	: 전체 반품 	> RSU{판매마감 역처리(원주문 역처리)}
	 * 					 	> RWS{판매중량정산 역처리(원주문 역처리)}
	 * 			  부분 반품	> CWS{판매중량정산(클레임)}
	 * </pre>
	 * @date 2021. 11. 4.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 4.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param requestVo
	 * @throws Exception
	 */
	public void erpGoodsSelngRtngudProcess(ErpAcntTrnsmitRequestVO requestVo) throws Exception {
		log.debug("ErpAcntTrnsmitServiceImpl::erpGoodsSelngRtngudProcess Start");

		List<ErpIfErpVO> selectErpOrderInfoList = null;					// 주문정보
		ErpIfErpVO selectErpClaimInfo 	= new ErpIfErpVO();					// 클레임정보
		ErpOpenJDEVO returnObj 			= new ErpOpenJDEVO();				// openJDE VO
		String openJDEResult			= null;								// openJDE API 응답 결과
		String jobSe					= null;								// 업무구분
		String taxBillIsuSeCode	 		= requestVo.getTaxBillIsuSeCode();	// 업무구분
		String[] revPrcArr				= {ErpAcntTrnsmitConstant.INTERFACE_TYPE_RSU, ErpAcntTrnsmitConstant.INTERFACE_TYPE_RWS};
		int erpIntrfcLineNo             = 0;

		try {

			if(ErpAcntTrnsmitConstant.JOB_SE_01.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.ORDER;
			if(ErpAcntTrnsmitConstant.JOB_SE_02.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.WT;
			if(ErpAcntTrnsmitConstant.JOB_SE_03.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.CANCL;
			if(ErpAcntTrnsmitConstant.JOB_SE_04.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.EXCHNG;
			if(ErpAcntTrnsmitConstant.JOB_SE_05.equals(taxBillIsuSeCode)) jobSe = ErpAcntTrnsmitConstant.RTNGUD;

			// OR_CANCL_EXCHNG_RTNGUD_BAS (클레임) 정보
			selectErpClaimInfo = erpAcntTrnsmitMapper.selectErpClaimInfo(requestVo);
			selectErpClaimInfo.setJobSe(jobSe);														// 업무 구분
			selectErpClaimInfo.setEcProgrmId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_117);		// 이커머스 프로그램 아이디
			selectErpClaimInfo.setCanclExchngRtngudNo(requestVo.getCanclExchngRtngudNo());			// 이커머스 취소교환반품번호
			selectErpClaimInfo.setCanclExchngRtngudTy(ErpAcntTrnsmitConstant.RTNGUD_TY);			// 이머커스 취소교환반품상태
			selectErpClaimInfo.setCanclExchngRtngudTyCode(ErpAcntTrnsmitConstant.RTNGUD_TY_CODE);	// 이커머스 취소교환반품상태코드

			// 전체, 부분 클레임 여부
			String allPartAt = selectErpClaimInfo.getAllPartAt();

			// 전체 반품
			if(ErpAcntTrnsmitConstant.ALL_PART_AT_Y.equals(allPartAt)) {

				// RSU (판매마감역처리) > RWS (판매중량정산 역처리) : 원주문 역처리
				for(int revPrcCnt = 0 ; revPrcCnt < revPrcArr.length ; revPrcCnt++) {

					ErpIfErpVO erpIfErpVo 	= new ErpIfErpVO();		// EC 내부 VO
					String revPrcDiv 		= revPrcArr[revPrcCnt];	// 인터페이스 유형

					// ERP 송신 계정에 따른 금액, 중량 구분
					if(ErpAcntTrnsmitConstant.INTERFACE_TYPE_RSU.equals(revPrcDiv)) requestVo.setTaxBillIsuSeCode(ErpAcntTrnsmitConstant.JOB_SE_01);
					else if(ErpAcntTrnsmitConstant.INTERFACE_TYPE_RWS.equals(revPrcDiv)) requestVo.setTaxBillIsuSeCode(ErpAcntTrnsmitConstant.JOB_SE_02);

					// 2023-01-31 변경사항 : 설정값에 따라 기존 쿼리문(운영 소스)과 신규 쿼리문(개발 소스)의 분기 처리
					/* ERP 분리 전송 여부 설정값 가져오기 - Y값일시 true, 아니면 false */
					boolean isSeprat = StringUtils.equals("Y", commonCodeService.getCodeValueRetVo("ERP_SEPRAT_TRNSMIS_CODE", "10").getCodeDcone());
					log.debug("ERP 분리 전송 여부 설정값 : {}", isSeprat);
					
					// OR_ORDER_BAS (주문) 정보
					if(isSeprat) {	//신규 쿼리문 사용 : 주문 정보 BL별 조회(many rows)
						selectErpOrderInfoList = erpAcntTrnsmitMapper.selectErpOrderInfoSeprat(requestVo);
					} else {												//기존 쿼리문 사용 : 주문 정보 통합 조회(1 row)
						selectErpOrderInfoList = erpAcntTrnsmitMapper.selectErpOrderInfo(requestVo);
					}
					
					// 2023-01-30 변경사항 : 오더 수량(orderQy)이 0일 경우 ERP 전송 대상에서 제외
					selectErpOrderInfoList = selectErpOrderInfoList.stream()
							.filter(erpOrderInfo -> Double.parseDouble(erpOrderInfo.getOrderQy()) != 0)
							.collect(Collectors.toList());
					
					for (ErpIfErpVO selectErpOrderInfo : selectErpOrderInfoList) {
						selectErpOrderInfo.setJobSe(jobSe);													// 업무 구분
						selectErpOrderInfo.setEcProgrmId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_117);	// 이커머스 프로그램 아이디
						selectErpOrderInfo.setCanclExchngRtngudNo(requestVo.getCanclExchngRtngudNo());			// 이커머스 취소교환반품번호
						selectErpOrderInfo.setCanclExchngRtngudTy(ErpAcntTrnsmitConstant.RTNGUD_TY);			// 이머커스 취소교환반품상태
						selectErpOrderInfo.setCanclExchngRtngudTyCode(ErpAcntTrnsmitConstant.RTNGUD_TY_CODE);	// 이커머스 취소교환반품상태코드
					}

					// ERP openJDE
					returnObj = erpIntrlckInfoService.openJDE(revPrcDiv);

					// ERP openJDE API 응답 결과
					openJDEResult = returnObj.getResult();

					// ERP openJDE API 응답 결과 : 성공
					if(ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG.equals(openJDEResult)) {
						for (ErpIfErpVO selectErpOrderInfo : selectErpOrderInfoList) {
							// openJDE API Response + OR_ORDER_BAS (주문) 정보
							erpIfErpVo = erpIfErpVoSet(returnObj, selectErpOrderInfo);
							
							// 등록자, 수정자
							erpIfErpVo.setFrstRegisterId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_117);
							erpIfErpVo.setLastChangerId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_117);
							
							// 2023-01-10 변경사항 : 다중 BL 및 고정가 주문  ERP 분리 처리 로직 추가
							erpIntrfcLineNo++;	//Interface 라인번호, 항목당 1씩 증가
							erpIfErpVo.setErpIntrfcLineNo(String.valueOf(erpIntrfcLineNo));		//Interface 라인번호
							
							if("120".equals(erpIfErpVo.getBplc().trim())){			// ERP 사업장 코드(bplc) 가 120이면 부산영업소
								erpIfErpVo.setOrderTy(ErpAcntTrnsmitConstant.ORDER_TY_SP);
								erpIfErpVo.setErnBsnsUnit(blankLtrim(ErpAcntTrnsmitConstant.ERN_BSNS_UNIT_SP, 12));
							} else if("130".equals(erpIfErpVo.getBplc().trim())){	// ERP 사업장 코드(bplc) 가 130이면 인천영업소
								erpIfErpVo.setOrderTy(ErpAcntTrnsmitConstant.ORDER_TY_SI);
								erpIfErpVo.setErnBsnsUnit(blankLtrim(ErpAcntTrnsmitConstant.ERN_BSNS_UNIT_SI, 12));
							} // 둘 다 해당 안되면 기본값 유지
							
							// IF_ERP (ERP 인터페이스) 데이터 적재
							erpAcntTrnsmitMapper.insertOpenJDEIfErp(erpIfErpVo);
							
							// ERP editF55TD01JDE
							erpIntrlckInfoService.editF55TD01JDE(erpIfErpVo);
							
						}
						
						// ERP closeJDE
						erpIntrlckInfoService.closeJDE(returnObj);

					} else {
						log.debug("ErpAcntTrnsmitServiceImpl::erpGoodsSelngRtngudProcess ERP::ALL_PART_AT_Y openJDE API response result Fail");
					}//end if()

				}//end for()

			// 부분 반품
			} else if(ErpAcntTrnsmitConstant.ALL_PART_AT_N.equals(allPartAt)) {

				ErpIfErpVO erpIfErpVo 	= new ErpIfErpVO();		// EC 내부 VO

				// ERP openJDE
				returnObj = erpIntrlckInfoService.openJDE(ErpAcntTrnsmitConstant.INTERFACE_TYPE_CWS);

				// ERP openJDE API 응답 결과
				openJDEResult = returnObj.getResult();

				// ERP openJDE API 응답 결과 : 성공
				if(ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG.equals(openJDEResult)) {

					// openJDE API Response + OR_CANCL_EXCHNG_RTNGUD_BAS (클레임) 정보
					erpIfErpVo = erpIfErpVoSet(returnObj, selectErpClaimInfo);

					// 등록자, 수정자
					erpIfErpVo.setFrstRegisterId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_117);
					erpIfErpVo.setLastChangerId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_117);

					// IF_ERP (ERP 인터페이스) 데이터 적재
					erpAcntTrnsmitMapper.insertOpenJDEIfErp(erpIfErpVo);

					// ERP editF55TD01JDE
					erpIntrlckInfoService.editF55TD01JDE(erpIfErpVo);

					// ERP closeJDE
					erpIntrlckInfoService.closeJDE(returnObj);

				} else {
					log.debug("ErpAcntTrnsmitServiceImpl::erpGoodsSelngRtngudProcess ERP::ALL_PART_AT_N openJDE API response result Fail");
				}//end if()

			} else {
				log.debug("ErpAcntTrnsmitServiceImpl::erpGoodsSelngRtngudProcess ALL_PART_AT is null");
			}//end if()

		} catch (Exception e) {
			log.error("ErpAcntTrnsmitServiceImpl::erpGoodsSelngRtngudProcess exception = " + e.getMessage());
			throw new Exception(e.getMessage());
		}

		log.debug("ErpAcntTrnsmitServiceImpl::erpGoodsSelngRtngudProcess End");
	}//end erpGoodsSelngRtngudProcess()

	/**
	 *
	 * <pre>
	 * ERP 상품매출 계정송신 > 취소 : 잡이익 패널티
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 3.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	ErpIfErpVO selectErpClaimInfo
	 * @throws 	Exception
	 */
	public void jobProfitPntProcess(ErpAcntTrnsmitRequestVO requestVo) throws Exception {
		log.debug("ErpAcntTrnsmitServiceImpl::jobProfitPntProcess Start");

		ErpIfErpVO selectErpClaimInfo 	= new ErpIfErpVO();					// 클레임정보
		ErpOpenJDEVO returnObj 			= new ErpOpenJDEVO();				// openJDE VO
		ErpIfErpVO erpIfErpVo 			= new ErpIfErpVO();					// EC 내부 VO
		String openJDEResult			= null;								// openJDE API 응답 결과
		String jobSe					= ErpAcntTrnsmitConstant.JOB;		// 업무구분

		try {

			//ERP openJDE
			returnObj = erpIntrlckInfoService.openJDE(ErpAcntTrnsmitConstant.JOB_SE_06);

			//ERP openJDE API 응답 결과
			openJDEResult 	= returnObj.getResult();

			//ERP openJDE API 응답 결과 성공인 경우
			if(ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG.equals(openJDEResult)) {

				// 잡이익 ( 패널티 + 상품금액차이 ) 쿼리 추가 필요합니다.
				selectErpClaimInfo = erpAcntTrnsmitMapper.selectErpClaimInfo(requestVo);
				selectErpClaimInfo.setJobSe(jobSe);													// 업무 구분
				selectErpClaimInfo.setEcProgrmId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_120);	// 이커머스 프로그램 아이디

				// openJDE API Response + OR_CANCL_EXCHNG_RTNGUD_BAS (클레임) 정보
				erpIfErpVo = erpIfErpVoSet(returnObj, selectErpClaimInfo);

				// 패널티 공급가 부가세 판매가 계산
				long splpc 	= NumberUtils.toLong(selectErpClaimInfo.getPenltyAmount());	//공급가 	- 확정금액
				long vat 	= (long) (splpc * 0.1);										//세액 	- 확정금액 * 0.1
				long slepc	= splpc + vat;												//총액

				erpIfErpVo.setSplpcAm(String.valueOf(splpc));							//공급가
				erpIfErpVo.setTaxAm(String.valueOf(vat));								//부가세
				erpIfErpVo.setTotAm(String.valueOf(slepc));								//총액

				// 등록자, 수정자
				erpIfErpVo.setFrstRegisterId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_120);
				erpIfErpVo.setLastChangerId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_120);

				// IF_ERP (ERP 인터페이스) 데이터 적재
				erpAcntTrnsmitMapper.insertOpenJDEIfErp(erpIfErpVo);

				// ERP editF55TD01JDE
				erpIntrlckInfoService.editF55TD01JDE(erpIfErpVo);

			} else {
				
				log.debug("ErpAcntTrnsmitServiceImpl::jobProfitPntProcess ERP openJDE API response result Fail");
				
			}//end if()
		} catch (Exception e) {
			
			log.debug("ErpAcntTrnsmitServiceImpl::jobProfitPntProcess exception = " + e.getMessage());
			
		} finally {
			
			// ERP closeJDE
			erpIntrlckInfoService.closeJDE(returnObj);
			
		}

		log.debug("ErpAcntTrnsmitServiceImpl::jobProfitPntProcess End");
	}//end jobProfitPntProcess()
	
	/**
	 * <pre>
	 * 처리내용: ERP 배송비 계정송신 
	 * </pre>
	 * @date 2023. 2. 23.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 2. 23.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param requestVo
	 * @throws Exception
	 */
	public void dlvrfExcclcProcess(ErpAcntTrnsmitRequestVO requestVo) throws Exception {
		log.debug("ErpAcntTrnsmitServiceImpl::dlvrfExcclcProcess Start");

		ErpIfErpVO selectErpOrderDlvrfInfo 	= new ErpIfErpVO();				// 배송비정보
		ErpOpenJDEVO returnObj 			= new ErpOpenJDEVO();				// openJDE VO
		ErpIfErpVO erpIfErpVo 			= new ErpIfErpVO();					// EC 내부 VO
		String openJDEResult			= null;								// openJDE API 응답 결과
		String jobSe					= ErpAcntTrnsmitConstant.DLVRF;		// 업무구분

		try {
			// 배송비 항목 조회
			selectErpOrderDlvrfInfo = erpAcntTrnsmitMapper.selectErpOrderDlvrfInfo(requestVo);
			
			if(selectErpOrderDlvrfInfo == null) {
				throw new Exception("배송비 항목 미존재, 배송비 정산 프로세스 종료");
			}

			//ERP openJDE
			returnObj = erpIntrlckInfoService.openJDE(ErpAcntTrnsmitConstant.JOB_SE_08);

			//ERP openJDE API 응답 결과
			openJDEResult 	= returnObj.getResult();

			//ERP openJDE API 응답 결과 성공인 경우
			if(ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG.equals(openJDEResult)) {
				selectErpOrderDlvrfInfo.setJobSe(jobSe);												// 업무 구분
				selectErpOrderDlvrfInfo.setEcProgrmId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_121);	// 이커머스 프로그램 아이디

				// openJDE API Response + OR_ORDER_BAS (주문의 배송비) 정보
				erpIfErpVo = erpIfErpVoSet(returnObj, selectErpOrderDlvrfInfo);

				// 등록자, 수정자
				erpIfErpVo.setFrstRegisterId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_121);
				erpIfErpVo.setLastChangerId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_121);

				// IF_ERP (ERP 인터페이스) 데이터 적재
				erpAcntTrnsmitMapper.insertOpenJDEIfErp(erpIfErpVo);

				// ERP editF55TD01JDE
				erpIntrlckInfoService.editF55TD01JDE(erpIfErpVo);

			} else {
				log.debug("ErpAcntTrnsmitServiceImpl::dlvrfExcclcProcess ERP openJDE API response result Fail");
			}//end if()

		} catch (Exception e) {

			log.debug("ErpAcntTrnsmitServiceImpl::dlvrfExcclcProcess exception = " + e.getMessage());

		} finally {

			// ERP closeJDE
			if(ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG.equals(openJDEResult))
				erpIntrlckInfoService.closeJDE(returnObj);

		}

		log.debug("ErpAcntTrnsmitServiceImpl::dlvrfExcclcProcess End");
	}//end dlvrfExcclcProcess()

	/**판관비(지급수수료) ERP계정 송신*/
	@Transactional(rollbackFor = Exception.class)
	@Override
	public ErpCloseJDEVO erpEwalletFee(ErpAcntTrnsmitRequestVO requestVo) throws Exception {
		log.debug("ErpAcntTrnsmitServiceImpl::erpEwalletFee Start");

		//인터페이스 송신 전문 등록 (IF_LOG)
		BtoBInrecfcLogVO btbLogVo =httpClientHelper.insertBtbLog(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_118, requestVo);

		ErpIfErpVO erpIfErpVo 		= new ErpIfErpVO();
		ErpOpenJDEVO returnObj 		= new ErpOpenJDEVO();
		ErpCloseJDEVO erpCloseJDEVO = new ErpCloseJDEVO();

		String[] apglArr		= {ErpAcntTrnsmitConstant.AP, ErpAcntTrnsmitConstant.GL};

		try {

			//AP, GL 금액 계산
			long splpc 	= NumberUtils.toLong(requestVo.getExcclcDcsnAmount());	//공급가 	- 확정금액
			long vat 	= (long) (splpc * 0.1);									//세액 	- 확정금액 * 0.1
			long slepc	= splpc + vat;											//총액

			//1. ERP openJDE
			returnObj = erpIntrlckInfoService.openJDE(ErpAcntTrnsmitConstant.JOB_SE_CEP);

			//ERP openJDE API 응답 결과
			String openJDEResult 	= returnObj.getResult();

			//ERP openJDE API 응답 결과 성공인 경우
			if(ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG.equals(openJDEResult)) {

				//비용 (이월렛 수수료) AP, GL 단위 ROW 적재
				for(int apglArrLength = 0 ; apglArrLength < apglArr.length ; apglArrLength ++) {
					String apglDiv = apglArr[apglArrLength];

					ErpIfErpVO selectErpEwalletFeeInfo 	= new ErpIfErpVO();

					//2. 판관비(지급수수료) 정보 SELECT
					selectErpEwalletFeeInfo = erpAcntTrnsmitMapper.selectErpCodeInfo(requestVo);			//ERP 코드 조회
					selectErpEwalletFeeInfo.setSplpcAm(String.valueOf(splpc));								//공급가
					selectErpEwalletFeeInfo.setTaxAm(String.valueOf(vat));									//부가세
					selectErpEwalletFeeInfo.setTotAm(String.valueOf(slepc));								//총액
					selectErpEwalletFeeInfo.setEcOrderNo(requestVo.getCtExcclcRequstNo());					//결제번호
					selectErpEwalletFeeInfo.setRm(requestVo.getCtExcclcRequstNo());							//비고 - 결제번호
					selectErpEwalletFeeInfo.setJobSe(ErpAcntTrnsmitConstant.JOB_SE_CEP);					//업무 구분
					selectErpEwalletFeeInfo.setApglDiv(apglDiv);											//비용 - AP / GL 구분
					selectErpEwalletFeeInfo.setEcProgrmId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_118);	//이커머스 프로그램 아이디
					selectErpEwalletFeeInfo.setTaxxmptAm(ErpAcntTrnsmitConstant.RETURN_ZERO);				//비과세액
					selectErpEwalletFeeInfo.setErnBsnsUnit(requestVo.getErnBsnsUnit());						//수익사업단위
					selectErpEwalletFeeInfo.setBcnc(requestVo.getEntrpsNo());								//거래처(= ERP 업체 코드)

					if(ErpAcntTrnsmitConstant.GL.equals(apglDiv)) {
						selectErpEwalletFeeInfo.setErpCtCode(ErpAcntTrnsmitConstant.ERP_CT_CODE_S405);		//비용코드
					}//end if()


					//3. EC openJDE API 응답 결과 > EC IF_ERP INSERT Data Set
					erpIfErpVo = erpIfErpVoSet(returnObj, selectErpEwalletFeeInfo);

					// 등록자, 수정자
					erpIfErpVo.setFrstRegisterId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_118);
					erpIfErpVo.setLastChangerId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_118);

					//4. EC openJDE API 응답 결과 > EC IF_ERP INSERT
					erpAcntTrnsmitMapper.insertOpenJDEIfErp(erpIfErpVo);

					//5. Edit JDE
					erpIntrlckInfoService.editF55TD01JDE(erpIfErpVo);

				}//end for()

			}//end if()

			btbLogVo.setIntrfcRspnsCode(ErpAcntTrnsmitConstant.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG);

		} catch (Exception e) {

			btbLogVo.setIntrfcRspnsCode(ErpAcntTrnsmitConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			log.error("ErpAcntTrnsmitServiceImpl::erpEwalletFee exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		} finally {

			//6. Close JDE
			erpCloseJDEVO = erpIntrlckInfoService.closeJDE(returnObj);

			log.debug("erpEwalletFee::erpCloseJDEVO = " + erpCloseJDEVO.toString());

			//인터페이스 수신 전문 등록 (IF_LOG)
			httpClientHelper.updateBtbLog(btbLogVo);
		}

		log.debug("ErpAcntTrnsmitServiceImpl::erpEwalletFee End");
		return erpCloseJDEVO;
	}//end erpEwalletFee()

	/**판관비(물류비) ERP계정 송신*/
	@Transactional(rollbackFor = Exception.class)
	@Override
	public ErpCloseJDEVO erpLgistCt(ErpAcntTrnsmitRequestVO requestVo) throws Exception {
		log.debug("ErpAcntTrnsmitServiceImpl::erpLgistCt Start");

		//인터페이스 송신 전문 등록 (IF_LOG)
		BtoBInrecfcLogVO btbLogVo =httpClientHelper.insertBtbLog(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_119, requestVo);

		ErpIfErpVO erpIfErpVo 		= new ErpIfErpVO();
		ErpOpenJDEVO returnObj 		= new ErpOpenJDEVO();
		ErpCloseJDEVO erpCloseJDEVO = new ErpCloseJDEVO();
		String[] apglArr		= {ErpAcntTrnsmitConstant.AP, ErpAcntTrnsmitConstant.GL};
		String erpCtCode		= requestVo.getErpCtCode();
		try {

			long splpc 	= NumberUtils.toLong(requestVo.getExcclcDcsnAmount());	//공급가 	- 확정금액
			long vat 	= NumberUtils.toLong(requestVo.getVat());				//세액 	- 확정금액 * 0.1
			long slepc	= splpc + vat;											//총액

			//1. ERP openJDE
			returnObj = erpIntrlckInfoService.openJDE(ErpAcntTrnsmitConstant.JOB_SE_CEP);

			//ERP openJDE API 응답 결과
			String openJDEResult 	= returnObj.getResult();

			//ERP openJDE API 응답 결과 성공인 경우
			if(ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG.equals(openJDEResult)) {

				//비용 (물류비) AP, GL 단위 ROW 적재
				for(int apglArrLength = 0 ; apglArrLength < apglArr.length ; apglArrLength ++) {
					String apglDiv = apglArr[apglArrLength];

					ErpIfErpVO selectErpLgistCtInfo 	= new ErpIfErpVO();

					//2. 판관비(물류비) 정보 SELECT
					selectErpLgistCtInfo = erpAcntTrnsmitMapper.selectErpCodeInfo(requestVo);			//ERP 코드 조회
					selectErpLgistCtInfo.setSplpcAm(String.valueOf(splpc));								//공급가
					selectErpLgistCtInfo.setTaxAm(String.valueOf(vat));									//부가세
					selectErpLgistCtInfo.setTotAm(String.valueOf(slepc));								//총액
					selectErpLgistCtInfo.setEcOrderNo(requestVo.getCtExcclcRequstNo());					//비용 정산 요청 번호
					selectErpLgistCtInfo.setRm(requestVo.getCtExcclcRequstNo());						//비고 - 비용 정산 요청 번호
					selectErpLgistCtInfo.setJobSe(ErpAcntTrnsmitConstant.JOB_SE_CEP);					//업무 구분
					selectErpLgistCtInfo.setApglDiv(apglDiv);											//비용 - AP / GL 구분
					selectErpLgistCtInfo.setEcProgrmId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_119);	//이커머스 프로그램 아이디
					selectErpLgistCtInfo.setTaxxmptAm(ErpAcntTrnsmitConstant.RETURN_ZERO);				//비과세액
					selectErpLgistCtInfo.setErnBsnsUnit(requestVo.getErnBsnsUnit());					//수익사업단위
					selectErpLgistCtInfo.setBcnc(requestVo.getEntrpsNo());								//거래처(= ERP 업체 코드)

					if(ErpAcntTrnsmitConstant.GL.equals(apglDiv)) {
						selectErpLgistCtInfo.setErpCtCode(erpCtCode);									//비용코드
					}//end if()


					//3. EC openJDE API 응답 결과 > EC IF_ERP INSERT Data Set
					erpIfErpVo = erpIfErpVoSet(returnObj, selectErpLgistCtInfo);

					// 등록자, 수정자
					erpIfErpVo.setFrstRegisterId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_119);
					erpIfErpVo.setLastChangerId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_119);

					//4. EC openJDE API 응답 결과 > EC IF_ERP INSERT
					erpAcntTrnsmitMapper.insertOpenJDEIfErp(erpIfErpVo);

					//5. Edit JDE
					erpIntrlckInfoService.editF55TD01JDE(erpIfErpVo);

				}//end for()

			}//end if()


			btbLogVo.setIntrfcRspnsCode(ErpAcntTrnsmitConstant.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG);

		} catch (Exception e) {

			btbLogVo.setIntrfcRspnsCode(ErpAcntTrnsmitConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			log.error("ErpAcntTrnsmitServiceImpl::erpLgistCt exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		} finally {

			//6. Close JDE
			erpCloseJDEVO = erpIntrlckInfoService.closeJDE(returnObj);

			//인터페이스 수신 전문 등록 (IF_LOG)
			httpClientHelper.updateBtbLog(btbLogVo);
		}

		log.debug("ErpAcntTrnsmitServiceImpl::erpLgistCt End");
		return erpCloseJDEVO;
	}//end erpLgistCt()

	/**
	 *
	 * <pre>
	 * EC openJDE API 응답 결과 > EC IF_ERP INSERT Data Set
	 * </pre>
	 * @date 2021. 10. 13.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 13.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	ErpOpenJDEVO returnObj
	 * @param	ErpIfErpVO selectErpInfo
	 * @return	ErpIfErpVO
	 * @throws 	Exception
	 */
	public ErpIfErpVO erpIfErpVoSet(ErpOpenJDEVO returnObj, ErpIfErpVO selectErpInfo) throws Exception {
		SimpleDateFormat ecUpdtDeFormat 	= new SimpleDateFormat ("yyyy/MM/dd");
		SimpleDateFormat ecUpdtTimeFormat 	= new SimpleDateFormat ("HHmmss");
		Date date 				= new Date();
		String ecUpdtTime 		= ecUpdtTimeFormat.format(date);
		String ecUpdtDe 		= ecUpdtDeFormat.format(date);
		String jobSe 			= selectErpInfo.getJobSe();
		String InterfaceType 	= returnObj.getSzT5IFTP();

		try {

			//인터페이스 순번 채번 (날짜 기준)
			String intrfcNo = assignService.selectAssignValue(
					ErpAcntTrnsmitConstant.JOB_SE
					, ErpAcntTrnsmitConstant.ERP_INTRFC_NO
					, DateUtil.getNowDate()
					, ErpAcntTrnsmitConstant.SYSTEM, 8);


			/**공통 Start ***********************************************************************************************************************************************************/
			log.debug("ErpAcntTrnsmitServiceImpl::erpIfErpVoSet 공통");
			selectErpInfo.setIntrfcNo(intrfcNo);												// 인터페이스 번호
			selectErpInfo.setEcOrderLineNo(ErpAcntTrnsmitConstant.RETURN_ONE);					// 이커머스 오더라인 번호 		(매출 마감 1건, 비용 처리 시 EC 오더번호에 따른 순번)
			selectErpInfo.setErpIntrfcSysCode(ErpAcntTrnsmitConstant.SECS);						// ERP 인터페이스 시스템 코드
			selectErpInfo.setEcUpdtDe(ecUpdtDe);												// 이커머스 수정 일자
			selectErpInfo.setEcUpdtTime(ecUpdtTime);											// 이커머스 수정 시간

			// 2023-02-23 변경사항 : 사업장 코드에 따라 수익 사업 단위, 오더 유형을 분기 처리
			if("120".equals(selectErpInfo.getBplc().trim())){			// ERP 사업장 코드(bplc) 가 120이면 부산영업소
				selectErpInfo.setErnBsnsUnit(blankLtrim(ErpAcntTrnsmitConstant.ERN_BSNS_UNIT_SP, 12));	// 수익 사업 단위 - 부산영업소
				selectErpInfo.setOrderTy(ErpAcntTrnsmitConstant.ORDER_TY_SP);							// 오더 유형 (SP : 이커머스 부산영업소 판매)
			} else if("130".equals(selectErpInfo.getBplc().trim())){	// ERP 사업장 코드(bplc) 가 130이면 인천영업소
				selectErpInfo.setErnBsnsUnit(blankLtrim(ErpAcntTrnsmitConstant.ERN_BSNS_UNIT_SI, 12));	// 수익 사업 단위 - 인천영업소
				selectErpInfo.setOrderTy(ErpAcntTrnsmitConstant.ORDER_TY_SI);							// 오더 유형 (SI : 이커머스 인천영업소 판매)
			} else {	// 둘 다 해당 안되면 본사
				selectErpInfo.setErnBsnsUnit(blankLtrim(ErpAcntTrnsmitConstant.ERN_BSNS_UNIT, 12));		// 수익 사업 단위 - 본사
				selectErpInfo.setOrderTy(ErpAcntTrnsmitConstant.ORDER_TY);								// 오더 유형 ('S9' : 이커머스 내수 판매)
			}
			
			selectErpInfo.setCrncyCode(ErpAcntTrnsmitConstant.CRNCY_CODE);						// 통화 코드
			selectErpInfo.setCrtrErpAcnt(ErpAcntTrnsmitConstant.CRTR_ERP_ACNT);					// 생성자 ERP 계정
			/**공통 End ***********************************************************************************************************************************************************/

			/**ERP CODE Start ***********************************************************************************************************************************************************/
			log.debug("ErpAcntTrnsmitServiceImpl::erpIfErpVoSet ERP CODE");
			selectErpInfo.setBplc(blankLtrim(selectErpInfo.getBplc(), 12));						// 사업장
			selectErpInfo.setTaxitmCode(selectErpInfo.getTaxitmCode());							// 세목 코드
			selectErpInfo.setTaxrt(selectErpInfo.getTaxrt());									// 세율
			selectErpInfo.setCmpny(selectErpInfo.getCmpny());									// 회사 (케이지트레이딩 ERP 코드)
			/**ERP CODE End ***********************************************************************************************************************************************************/

			/**openJDE API Response Start ***********************************************************************************************************************************************************/
			log.debug("ErpAcntTrnsmitServiceImpl::erpIfErpVoSet openJDE API Response");
			selectErpInfo.setErpIntrfcTy(returnObj.getSzT5IFTP());								// openJDE : szT5IFTP (Interface 유형)
			selectErpInfo.setErpIntrfcNo(returnObj.getMnT5IFNO());								// openJDE : mnT5IFNO
			selectErpInfo.setMnT5JNO(returnObj.getMnT5JNO());									// openJDE : mnT5JNO (Job번호 채번, API의 Key)
			selectErpInfo.setMnT5IFNO(returnObj.getMnT5IFNO());									// openJDE : mnT5IFNO (Interface번호 채번, Interface Processing의 Key)
			selectErpInfo.setSzT5IFTP(returnObj.getSzT5IFTP());									// openJDE : szT5IFTP (Interface 유형)
			selectErpInfo.setSzT5SYSC(returnObj.getSzT5SYSC());									// openJDE : szT5SYSC (Interface System Code)
			selectErpInfo.setSzT5TDPID(returnObj.getSzT5TDPID());								// openJDE : szT5TDPID (Geust System Program ID)
			selectErpInfo.setSzUSER(returnObj.getSzUSER());										// openJDE : szUSER (사용자)
			/**openJDE API Response End ***********************************************************************************************************************************************************/

			if(ErpAcntTrnsmitConstant.ORDER.equals(jobSe)
					|| ErpAcntTrnsmitConstant.WT.equals(jobSe)
					|| ErpAcntTrnsmitConstant.CANCL.equals(jobSe)
					|| ErpAcntTrnsmitConstant.RTNGUD.equals(jobSe)
					|| ErpAcntTrnsmitConstant.EXCHNG.equals(jobSe)
					|| ErpAcntTrnsmitConstant.CANCLWT.equals(jobSe)
					|| ErpAcntTrnsmitConstant.DLVRF.equals(jobSe)) {

				/**상품매출 Start ***********************************************************************************************************************************************************/
				log.debug("ErpAcntTrnsmitServiceImpl::erpIfErpVoSet 상품매출");
				//정산순번 채번 (주문번호 기준)
				String excclcSn = assignService.selectAssignValue(
						ErpAcntTrnsmitConstant.JOB_SE
						, ErpAcntTrnsmitConstant.ERP_EXCCLC_SN
						, selectErpInfo.getEcOrderNo()
						, ErpAcntTrnsmitConstant.SYSTEM, 8);

				/** 정산유형 (PV(매출), WC(수정매출), FN(배송비)) */
				// 2023-03-03 변경사항 : 배송비 항목에 대한 정산 유형 추가
				if(ErpAcntTrnsmitConstant.ORDER.equals(jobSe)) selectErpInfo.setExcclcTy(ErpAcntTrnsmitConstant.PV);		//매출
				else if(ErpAcntTrnsmitConstant.DLVRF.equals(jobSe)) selectErpInfo.setExcclcTy(ErpAcntTrnsmitConstant.FN);	//배송비
				else selectErpInfo.setExcclcTy(ErpAcntTrnsmitConstant.WC);																//수정매출

				//역처리 : 금액, 중량 (-) 처리
				if(ErpAcntTrnsmitConstant.INTERFACE_TYPE_RSU.equals(InterfaceType)) {

					selectErpInfo.setOrderQy(String.valueOf(-1 * Float.parseFloat(selectErpInfo.getOrderQy())));		// 오더수량 	: 중량
					selectErpInfo.setShipmntQy(String.valueOf(-1 * Float.parseFloat(selectErpInfo.getShipmntQy())));	// 출하수량 	: 중량
					selectErpInfo.setSplpcAm(String.valueOf(-1 * Integer.parseInt(selectErpInfo.getSplpcAm()))); 		// 공급가액 	: 금액
					selectErpInfo.setTaxAm(String.valueOf(-1 * Integer.parseInt(selectErpInfo.getTaxAm()))); 			// 세액 		: 금액
					selectErpInfo.setTotAm(String.valueOf(-1 * Integer.parseInt(selectErpInfo.getTotAm()))); 			// 총액		: 금액

				} else {

					selectErpInfo.setOrderQy(selectErpInfo.getOrderQy());						// 오더수량 	: 중량
					selectErpInfo.setShipmntQy(selectErpInfo.getShipmntQy());					// 출하수량 	: 중량
					selectErpInfo.setSplpcAm(selectErpInfo.getSplpcAm()); 						// 공급가액 	: 금액
					selectErpInfo.setTaxAm(selectErpInfo.getTaxAm()); 							// 세액 		: 금액
					selectErpInfo.setTotAm(selectErpInfo.getTotAm()); 							// 총액		: 금액

					if(ErpAcntTrnsmitConstant.INTERFACE_TYPE_CWS.equals(InterfaceType)
							&& ErpAcntTrnsmitConstant.WT.equals(jobSe)) {

						selectErpInfo.setOrderQy(selectErpInfo.getDiffQy());					// 오더수량 	: 중량
						selectErpInfo.setShipmntQy(selectErpInfo.getDiffQy());					// 출하수량 	: 중량

					} else if(ErpAcntTrnsmitConstant.CANCLWT.equals(jobSe)) {
						
						selectErpInfo.setOrderQy(String.valueOf(-1 * Float.parseFloat(selectErpInfo.getDiffQy())));	
						selectErpInfo.setShipmntQy(String.valueOf(-1 * Float.parseFloat(selectErpInfo.getDiffQy())));	
					
					} else if (ErpAcntTrnsmitConstant.INTERFACE_TYPE_RWS.equals(InterfaceType)) {

						if(ErpAcntTrnsmitConstant.WT.equals(jobSe)) {
							selectErpInfo.setOrderQy(String.valueOf(-1 * Float.parseFloat(selectErpInfo.getDiffQy())));			// 오더수량 	: 중량
							selectErpInfo.setShipmntQy(String.valueOf(-1 * Float.parseFloat(selectErpInfo.getDiffQy())));		// 출하수량 	: 중량
						} else {

							selectErpInfo.setOrderQy(String.valueOf(-1 * Float.parseFloat(selectErpInfo.getOrderQy())));		// 오더수량 	: 중량
							selectErpInfo.setShipmntQy(String.valueOf(-1 * Float.parseFloat(selectErpInfo.getShipmntQy())));	// 출하수량 	: 중량

						}//end if()

						selectErpInfo.setSplpcAm(String.valueOf(-1 * Integer.parseInt(selectErpInfo.getSplpcAm()))); 		// 공급가액 	: 금액
						selectErpInfo.setTaxAm(String.valueOf(-1 * Integer.parseInt(selectErpInfo.getTaxAm()))); 			// 세액 		: 금액
						selectErpInfo.setTotAm(String.valueOf(-1 * Integer.parseInt(selectErpInfo.getTotAm()))); 			// 총액		: 금액

					}//end if()

				}//end if()

				selectErpInfo.setWonAmount(selectErpInfo.getWonAmount());						// 원화금액 	: 금액
				selectErpInfo.setWonUntpc(selectErpInfo.getWonUntpc());							// 원화단가 	: 단가
				selectErpInfo.setExcclcSn(excclcSn);											// 정산 순번
				selectErpInfo.setErpIntrfcLineNo(ErpAcntTrnsmitConstant.RETURN_ONE);			// ERP 인터페이스 라인 번호	(매출 마감 1건, 비용 처리 시 여러 건.)
				/**상품매출 End ***********************************************************************************************************************************************************/

			} else if (ErpAcntTrnsmitConstant.JOB_SE_CEP.equals(jobSe)) {

				/**비용 Start ***********************************************************************************************************************************************************/
				log.debug("ErpAcntTrnsmitServiceImpl::erpIfErpVoSet 비용");
				selectErpInfo.setInvcDe(ecUpdtDe);												// 송장일자
				selectErpInfo.setGlDe(ecUpdtDe);												// GL 일자
				selectErpInfo.setGlClass(ErpAcntTrnsmitConstant.GL_CLASS);						// GL Class (AP인 경우만 적재)
				selectErpInfo.setBplc(selectErpInfo.getErnBsnsUnit());							// 사업장 : 비용에서 사용하는 사업장값은 수익사업단위
				selectErpInfo.setErnBsnsUnit(null);												// 수익사업단위

				/**AP / GL 구분*/
				if(ErpAcntTrnsmitConstant.AP.equals(selectErpInfo.getApglDiv())) {

					selectErpInfo.setExcclcTy(ErpAcntTrnsmitConstant.AP);						// 정산유형 (AP)
					selectErpInfo.setTaxAm(selectErpInfo.getTaxAm()); 							// 세액 		: 금액
					selectErpInfo.setTotAm(selectErpInfo.getTotAm()); 							// 총액		: 금액
					selectErpInfo.setSplpcAm(selectErpInfo.getSplpcAm()); 						// 공급가액 	: 금액
					selectErpInfo.setErpIntrfcLineNo(ErpAcntTrnsmitConstant.RETURN_ONE);		// ERP 인터페이스 라인 번호	(open 시 처리할 전표의 건수(라인수))
					selectErpInfo.setOrderTy(null);												// 오더유형

				} else if(ErpAcntTrnsmitConstant.GL.equals(selectErpInfo.getApglDiv())) {

					selectErpInfo.setExcclcTy(ErpAcntTrnsmitConstant.GL);						// 정산유형 (GL)
					selectErpInfo.setTotAm(selectErpInfo.getSplpcAm()); 						// 총액		: 금액 (공급가액 = 총액)
					selectErpInfo.setTaxAm(ErpAcntTrnsmitConstant.RETURN_ZERO); 				// 세액 		: 금액
					selectErpInfo.setSplpcAm(ErpAcntTrnsmitConstant.RETURN_ZERO); 				// 공급가액 	: 금액
					selectErpInfo.setErpIntrfcLineNo(ErpAcntTrnsmitConstant.RETURN_TWO);		// ERP 인터페이스 라인 번호	(open 시 처리할 전표의 건수(라인수))
					selectErpInfo.setTaxitmCode(null);											// 세목
					selectErpInfo.setTaxrt(null);												// 세율/세역
					selectErpInfo.setGlClass(null);												// G/L Class
					selectErpInfo.setSplpcAm(null);												// 공급가액
					selectErpInfo.setTaxAm(null);												// 세액
					selectErpInfo.setTaxxmptAm(null);											// 원화비과세액

				}//end if()
				/**비용 End ***********************************************************************************************************************************************************/

			} else if (ErpAcntTrnsmitConstant.JOB.equals(jobSe)) {
				/**잡이익 Start ***********************************************************************************************************************************************************/
				log.debug("ErpAcntTrnsmitServiceImpl::erpIfErpVoSet 잡이익");
				selectErpInfo.setErpIntrfcLineNo(ErpAcntTrnsmitConstant.RETURN_ONE);			// ERP 인터페이스 라인 번호
				selectErpInfo.setOrderTy(null);													// 오더 유형
				selectErpInfo.setDvyfgOffic(null);												// 납품처
				selectErpInfo.setBplc(null);													// 사업장
				selectErpInfo.setErnBsnsUnit(null);												// 수익사업단위
				selectErpInfo.setOrderDe(null);													// 오더일자
				selectErpInfo.setShipmntDe(null);												// 출하일자
				selectErpInfo.setPrdlstNo(null);												// 품목번호
				selectErpInfo.setOrderQy(null);													// 오더수량
				selectErpInfo.setShipmntQy(null);												// 출하수량
				selectErpInfo.setWonUntpc(null);												// 원화단가
				selectErpInfo.setSplpcAm(null);													// 원화금액
				selectErpInfo.setCanclExchngRtngudTy(null);	 									// ECommerce 주문 취소/교환/반품 상태 코드
				selectErpInfo.setCanclExchngRtngudNo(null);										// ECommerce 취소/교환/반품 번호
				selectErpInfo.setOrderDe(null); 												// 오더일자 Juilan Date 전환용 날짜
				selectErpInfo.setShipmntDe(null); 												// 출하일자 Juilan Date 전환용 날짜
				/**잡이익 End ***********************************************************************************************************************************************************/
			} else if (ErpAcntTrnsmitConstant.INVNTRY.equals(jobSe) || ErpAcntTrnsmitConstant.CANCLINVNTRY.equals(jobSe)) {
				/**재고조정 Start ***********************************************************************************************************************************************************/
				log.debug("ErpAcntTrnsmitServiceImpl::erpIfErpVoSet 재고조정");
				selectErpInfo.setErpIntrfcLineNo(ErpAcntTrnsmitConstant.RETURN_ONE);			// ERP 인터페이스 라인 번호
				/**재고조정 End ***********************************************************************************************************************************************************/
			} else {
				log.debug("ErpAcntTrnsmitServiceImpl::erpIfErpVoSet jobSe is null");

			}//end if()

		} catch (Exception e) {
			log.error("ErpAcntTrnsmitServiceImpl::erpIfErpVoSet exception = " + e.getMessage());
		}

		return selectErpInfo;
	}//end erpIfErpVoSet()

	/**
	 *
	 * <pre>
	 * Ltrim 처리
	 * 수익사업단위	- 12자리
	 * 사업장		- 12자리
	 * </pre>
	 * @date 2021. 11. 17.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 17.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	String inputString
	 * @param 	Integer length
	 * @return	String
	 */
	public String blankLtrim(String inputString, Integer length) {

		if (inputString.length() >= length) return inputString;

	    StringBuilder sb = new StringBuilder();

	    while (sb.length() < length - inputString.length()) {
	        sb.append(" ");
	    }

	    sb.append(inputString);

		return sb.toString();
	}//end blankLtrim()

	/**재고조정 ERP계정 송신*/
	@Transactional(rollbackFor = Exception.class)
	@Override
	public void erpInvntryAdjst(ErpAcntTrnsmitRequestVO requestVo) throws Exception {
		log.debug("ErpAcntTrnsmitServiceImpl::erpInvntryAdjst Start");

		//인터페이스 송신 전문 등록 (IF_LOG)
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_122, requestVo);

		/**
		 * 업무 구분
		 * 01 : 재고조정 처리
		 * 02 : 재고조정 역처리
		 */
		String erpInvntryAdjstCode = requestVo.getErpInvntryAdjstCode();

		try {
			/**
			 * 업무 구분에 따른 ERP 계정 송신 프로세스
			 * 1) 01 : INVNTRY 			: ADJ ( 재고조정 )
			 * 2) 02 : CANCLINVNTRY 	: ADJ ( 재고조정 역처리 )
			 */
			if(ErpAcntTrnsmitConstant.JOB_SE_01.equals(erpInvntryAdjstCode)
					|| ErpAcntTrnsmitConstant.JOB_SE_02.equals(erpInvntryAdjstCode)) {
				erpInvntryAdjstProcess(requestVo);
			}

			btbLogVo.setIntrfcRspnsCode(ErpAcntTrnsmitConstant.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG);

		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(ErpAcntTrnsmitConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			log.error("ErpAcntTrnsmitServiceImpl::erpInvntryAdjst exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		} finally {
			//인터페이스 수신 전문 등록 (IF_LOG)
			httpClientHelper.updateBtbLog(btbLogVo);
		}

		log.debug("ErpAcntTrnsmitServiceImpl::erpInvntryAdjst End");
	}//end erpInvntryAdjst()
	
	/**
	 *
	 * <pre>
	 * INVNTRY: ADJ (재고조정)
	 * </pre>
	 * @date 2023. 05. 15.
	 * @author jdrttl
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 05. 15.		정대룡				최초작성
	 * ------------------------------------------------
	 * @param 	ErpAcntTrnsmitRequestVO requestVo
	 * @throws 	Exception
	 */
	public void erpInvntryAdjstProcess(ErpAcntTrnsmitRequestVO requestVo) throws Exception {
		log.debug("ErpAcntTrnsmitServiceImpl::erpInvntryAdjstProcess Start");

		List<ErpIfErpVO> erpInvntryAdjstList = null;										// 재고 조정 대상 리스트
		ErpOpenJDEVO returnObj 			= null;											// openJDE VO
		ErpIfErpVO erpIfErpVo 			= new ErpIfErpVO();								// EC 내부 VO
		String openJDEResult			= null;											// openJDE API 응답 결과
		String erpInvntryAdjstCode	 	= requestVo.getErpInvntryAdjstCode();			// 업무구분
		String erpInvntryAdjstMetalCode	= requestVo.getErpInvntryAdjstMetalCode();		// 메탈코드
		String jobSe					= null;
		String exceptionResult			= ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG;
		int erpIntrfcLineNo             = 0;

		try {

			if(ErpAcntTrnsmitConstant.JOB_SE_01.equals(erpInvntryAdjstCode)) jobSe = ErpAcntTrnsmitConstant.INVNTRY;
			if(ErpAcntTrnsmitConstant.JOB_SE_02.equals(erpInvntryAdjstCode)) jobSe = ErpAcntTrnsmitConstant.CANCLINVNTRY;

			// 재고 조정 대상 여부
			erpInvntryAdjstList = erpAcntTrnsmitMapper.selectErpInvntryAdjstList(requestVo);
			
			log.debug("ErpAcntTrnsmitServiceImpl::erpInvntryAdjstProcess >>> erpInvntryAdjstList " + erpInvntryAdjstList);
			
			if( erpInvntryAdjstList.size() > 0 ) {
				// ERP openJDE
				returnObj = erpIntrlckInfoService.openJDE(ErpAcntTrnsmitConstant.INTERFACE_TYPE_ADJ);
				
				// ERP openJDE API 응답 결과
				openJDEResult = returnObj.getResult();
				
				//ERP openJDE API 응답 결과 : 성공
				if(ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG.equals(openJDEResult)) {
				
					for (ErpIfErpVO erpInvntryAdjst : erpInvntryAdjstList) {
						erpInvntryAdjst.setJobSe(jobSe);													// 업무 구분
						erpInvntryAdjst.setEcProgrmId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_122);		// 이커머스 프로그램 아이디
						
						// openJDE API Response + 재고 조정 정보
						erpIfErpVo = erpIfErpVoSet(returnObj, erpInvntryAdjst);
						
						log.debug("ErpAcntTrnsmitServiceImpl::erpInvntryAdjstProcess >>> erpIfErpVo " + erpIfErpVo);
						
						// 등록자, 수정자
						erpIfErpVo.setFrstRegisterId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_122);
						erpIfErpVo.setLastChangerId(ErpAcntTrnsmitConstant.ERP_ACNT_TRNSMIT_IF_122);
						
						// 다중 BL 및 고정가 주문  ERP 분리 처리 로직 추가
						erpIntrfcLineNo++;	//Interface 라인번호, 항목당 1씩 증가
						erpIfErpVo.setErpIntrfcLineNo(String.valueOf(erpIntrfcLineNo));		//Interface 라인번호
						
						// IF_ERP (ERP 인터페이스) 데이터 적재
						erpAcntTrnsmitMapper.insertOpenJDEIfErpAdj(erpIfErpVo);
						
						// ERP editF55TD01JDE_ADJ 재고조정
						erpIntrlckInfoService.editF55TD01JDE_ADJ(erpIfErpVo);
					}
				} else {
					
					log.debug("ErpAcntTrnsmitServiceImpl::erpInvntryAdjst ERP openJDE API response result Fail");
					
				}//end if()
			}else {
				log.debug("ErpAcntTrnsmitServiceImpl::selectErpInvntryAdjstList is null");
				
				return;
			}

		} catch (Exception e) {

			exceptionResult	= ErpAcntTrnsmitConstant.ERROR_RESULT_MSG;
			log.error("ErpAcntTrnsmitServiceImpl::erpGoodsSelngOrderWtProcess exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		} finally {
			// ERP closeJDE
			erpIntrlckInfoService.closeJDE(returnObj, "ADJ");
		}

		log.debug("ErpAcntTrnsmitServiceImpl::erpGoodsSelngOrderWtProcess End");
	}//end erpGoodsSelngOrderWtCanclProcess()
	
}//end class()
