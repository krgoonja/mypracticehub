package com.sorincorp.api.erp.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * 
 * ErpCloseJDEVO.java
 * openJDE 공통 VO.java
 * 
 * @version
 * @since 2021. 10. 12.
 * @author srec0054
 */
@Data
public class ErpCloseJDEVO {

	/**in*/
	/**JOB ID*/
	private String mnT5JNO;
	
	/**N55TD01 실행여부 1(Run) / 2(Not run)*/
	@JsonProperty("cRunningFlag")
	private String cRunningFlag;
	
	/**out*/
	@JsonProperty("cErrorFlag")
	private String cErrorFlag;
	
	private String szErrorDescription;
	
	/**Edit Row Count 반환*/
	private String mnT5RCNT;
	
	private String result;
	
}//end ()
