package com.sorincorp.api.erp.model;

import lombok.Data;

/**
 * 
 * ErpSelectF55TD01JDEVO.java
 * F55TD01JDE 공통 VO.java
 * 
 * @version
 * @since 2021. 10. 28.
 * @author srec0054
 */
@Data
public class ErpSelectF55TD01JDEVO {

	/**
	 * IN
	 */
	
	/**Index Case :: 조회할 조건 컬럼을 설정*/
	private String mnT5INDEX;
	
	/**
	구분값	컬럼1		컬럼2		컬럼3			컬럼4		컬럼5		컬럼6	
	1		T5SYSC	T5IFNO	T5IFTP						T5SYSC
	2		T5SYSC	T5IFTP	T5PREPID					T5IFNO
	3		T5SYSC	T5IFTP	T5TDNO						T5IFTP
	4		T5SYSC	T5IFTP	T5TDNO		DCTO			T5PREPID
	5		T5SYSC	T5IFTP	T5TDNO		DCTO	T5TDLN	T5TDNO
	6		T5SYSC	T5TDNO				DCTO
	7		T5SYSC	T5TDNO	DCTO						T5TDLN
	8		T5SYSC	T5TDNO	DCTO		T5TDLN			ICU
	9		T5SYSC	ICU									T5JNO
	10		T5SYSC	T5JNO				
	*/
	
	/**Interface System Code*/
	private String szT5SYSC_In;
	
	/**Interface 번호*/
	private String mnT5IFNO_In;
	
	/**Interface 유형*/
	private String szT5IFTP_In;
	
	/**Sequence ID*/
	private String mnT5PREPID_In;
	
	/**Trading 오더번호*/
	private String szT5TDNO_In;
	
	/**오더유형*/
	private String szDCTO_In;
	
	/**Trading 오더 라인번호*/
	private String mnT5TDLN_In;
	
	/**배치번호*/
	private String mnICU_In;
	
	/**API Job Number*/
	private String mnT5JNO_In;
	
	
	
	
	/**
	 * OUT
	 */
	
	
	/**Row Count*/
	private String mnT5RCNT;
	
	/**API Error Flag*/
	private String cErrorFlag;
	
	/**API Error Description*/
	private String szErrorDescription;
	
	/**Interface 번호*/
	private String szT5IFNO;
	
	/**Interface 유형*/
	private String szT5IFTP;
	
	/**Interface 라인번호*/
	private String szT5IFLN;
	
	/**Interface System Code*/
	private String szT5SYSC;
	
	/**성공여부(Y/N)*/
	private String szT5IFSP;
	
	/**Trading 오더번호*/
	private String szT5TDNO;
	
	/**Trading 오더 라인번호*/
	private String szT5TDLN;
	
	/**Trading Invoice 번호*/
	private String szT5INVNO;
	
	/**Validation Flag*/
	private String szEV01;
	
	/**Error 내역*/
	private String szT5ERDL;
	
	/**Error Count*/
	private String szDLLJ;
	
	/**정산유형*/
	private String szT5BALTP;
	
	/**정산순번*/
	private String szASE;
	
	/**오더회사*/
	private String szKCOO;
	
	/**오더번호*/
	private String szDOCO;
	
	/**오더유형*/
	private String szDCTO;
	
	/**라인번호*/
	private String szLNID;
	
	/**Order Suffix*/
	private String szSFXO;
	
	/**거래처*/
	private String szAN8;
	
	/**납품처*/
	private String szSHAN;
	
	/**사업장*/
	private String szMCU;
	
	/**수익사업단위*/
	private String szEMCU;
	
	/**오더일자*/
	private String szTRDJ;
	
	/**출하일자*/
	private String szADDJ;
	
	/**송장일자*/
	private String szIVD;
	
	/**G/L일자*/
	private String szDGL;
	
	/**품목번호*/
	private String szLITM;
	
	/**오더수량*/
	private String szUORG;
	
	/**출하수량*/
	private String szSOQS;
	
	/**세목코드*/
	private String szEXR1;
	
	/**세율/세역*/
	private String szTXA1;
	
	/**G/L Class*/
	private String szGLC;
	
	/**원화단가*/
	private String szUPRC;
	
	/**원화금액*/
	private String szAEXP;
	
	/**통화코드*/
	private String szCRCD;
	
	/**외화단가*/
	private String szFUP;
	
	/**외화금액*/
	private String szFEA;
	
	/**환율*/
	private String szCRR;
	
	/**L/C 번호*/
	private String szK5LCNO;
	
	/**B/L 번호*/
	private String szK5BLNO;
	
	/**배치번호*/
	private String szICU;
	
	/**배치유형*/
	private String szICUT;
	
	/**회사*/
	private String szKCO;
	
	/**문서번호*/
	private String szDOC;
	
	/**문서유형*/
	private String szDCT;
	
	/**지급항목*/
	private String szSFX;
	
	/**결제코드*/
	private String szSFXE;
	
	/**지급항목 - 선급*/
	private String szSFX0;
	
	/**일반회계(GA)라인번호*/
	private String szJELN;
	
	/**공급가액*/
	private String szATXA;
	
	/**세액*/
	private String szSTAM;
	
	/**비과세액*/
	private String szATXN;
	
	/**총액*/
	private String szAG;
	
	/**외화공급가액*/
	private String szCTXA;
	
	/**외화세액*/
	private String szCTAM;
	
	/**외화비과세액*/
	private String szCTXN;
	
	/**외화총액*/
	private String szACR;
	
	/**조정처리유무*/
	private String szEV02;
	
	/**기준통화*/
	private String szBCRC;
	
	/**입고전표배치번호/선물평가익월배치번호*/
	private String szBN01;
	
	/**입고전표배치유형/선물평가익월배치유형*/
	private String szBTY1;
	
	/**입고전표문서번호/선물평가익월문서번호*/
	private String szDOC1;
	
	/**입고전표문서유형/선물평가익월문서유형*/
	private String szDCT1;
	
	/**선물평가익월전표라인번호*/
	private String szJELA;
	
	/**Interface Flag(STS용 전기역처리 체크)*/
	private String szT5IFFG;
	
	/**ERP 전기 역처리 코드*/
	private String szT5PTCD;
	
	/**전기 역처리 일자(G/L일자)*/
	private String szHDGJ;
	
	/**Sequence ID*/
	private String szT5PREPID;
	
	/**Trading 처리순번*/
	private String szT5PSQN;
	
	/**Due Date*/
	private String szDDJ;
	
	/**Remark(비고)*/
	private String szRMK;
	
	/**설명*/
	private String szEXA;
	
	/**주계정*/
	private String szOBJ;
	
	/**보조계정*/
	private String szSUB;
	
	/**I/F 비고*/
	private String szDL01;
	
	/**Trading Program ID*/
	private String szT5TDPID;
	
	/**선물평가 계정코드*/
	private String szT5ACCD;
	
	/**API Job Number*/
	private String szT5JNO;
	
	/**생성자 ERP 계정*/
	private String szUSER;
	
	/**Trading 수정일자*/
	private String szUPMJ;
	
	/**Trading 수정시간*/
	private String szUPMT;
	

	
}//end class()
