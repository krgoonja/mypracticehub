package com.sorincorp.api.erp.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * 
 * ErpAcntTrnsmitVO.java
 * EditF55TD01JDE 공통 VO.java
 * 
 * @version
 * @since 2021. 10. 5.
 * @author srec0054
 */
@Data
public class ErpEditF55TD01JDEVO {

	/**Job Number*/
	private String mnT5JNO;
	
	/**API Error Flag*/
	@JsonProperty("cErrorFlag")
	private String cErrorFlag;
	
	/**API Error Description*/
	private String szErrorDescription;
	
	/**Interface 번호*/
	private String mnT5IFNO;
	
	/**Interface 유형*/
	private String szT5IFTP;
	
	/**Interface 라인번호*/
	private String mnT5IFLN;
	
	/**Interface System Code*/
	private String szT5SYSC;
	
	/**Trading 오더번호*/
	private String szT5TDNO;
	
	/**Trading 오더 라인번호*/
	private String mnT5TDLN;
	
	/**Trading Invoice 번호*/
	private String szT5INVNO;
	
	/**정산유형*/
	private String szT5BALTP;
	
	/**정산순번*/
	private String mnASE;
	
	/**오더유형*/
	private String szDCTO;
	
	/**거래처*/
	private String mnAN8;
	
	/**납품처*/
	private String mnSHAN;
	
	/**사업장*/
	private String szMCU;
	
	/**수익사업단위*/
	private String szEMCU;
	
	/**오더일자*/
	private String jdTRDJ;
	
	/**출하일자*/
	private String jdADDJ;
	
	/**송장일자*/
	private String jdIVD;
	
	/**G/L일자*/
	private String jdDGL;
	
	/**품목번호*/
	private String szLITM;
	
	/**오더수량*/
	private String mnUORG;
	
	/**출하수량*/
	private String mnSOQS;
	
	/**세목코드*/
	private String szEXR1;
	
	/**세율/세역*/
	private String szTXA1;
	
	/**G/L Class*/
	private String szGLC;
	
	/**원화단가*/
	private String mnUPRC;
	
	/**원화금액*/
	private String mnAEXP;
	
	/**통화코드*/
	private String szCRCD;
	
	/**외화단가*/
	private String mnFUP;
	
	/**외화금액*/
	private String mnFEA;
	
	/**환율*/
	private String mnCRR;
	
	/**L/C 번호*/
	private String szK5LCNO;
	
	/**B/L 번호*/
	private String szK5BLNO;
	
	/**회사*/
	private String szKCO;
	
	/**공급가액*/
	private String mnATXA;
	
	/**세액*/
	private String mnSTAM;
	
	/**비과세액*/
	private String mnATXN;
	
	/**총액*/
	private String mnAG;
	
	/**외화공급가액*/
	private String mnCTXA;
	
	/**외화세액*/
	private String mnCTAM;
	
	/**외화비과세액*/
	private String mnCTXN;
	
	/**외화총액*/
	private String mnACR;
	
	/**Interface Flag(STS용 전기역처리 체크)*/
	@JsonProperty("cT5IFFG")
	private String cT5IFFG;
	
	/**ERP 전기 역처리 코드*/
	@JsonProperty("cT5PTCD")
	private String cT5PTCD;
	
	/**전기 역처리 일자(G/L일자)*/
	private String jdHDGJ;
	
	/**Trading 선급요청 ID*/
	private String mnT5PREPID;
	
	/**Due Date*/
	private String jdDDJ;
	
	/**Remark(비고)*/
	private String szRMK;
	
	/**설명*/
	private String szEXA;
	
	/**주계정*/
	private String szOBJ;
	
	/**보조계정*/
	private String szSUB;
	
	/**I/F 비고*/
	private String szDL01;
	
	/**Guest Program ID*/
	private String szT5TDPID;
	
	/**선물평가 계정코드*/
	private String szT5ACCD;
	
	/**생성자 ERP 계정*/
	private String szUSER;
	
	/**Trading 수정일자*/
	private String jdUPMJ;
	
	/**Trading 수정시간*/
	private String mnUPMT;
	
	/**ECommerce  주문 취소/교환/반품 상태 코드*/
	private String szT5ECSTCD; 
	
	/**ECommerce 취소/교환/반품 번호*/
	private String szT5ECSTNO; 
	
	/**Ecommerce 비용 코드*/
	private String szT5ECEPCD; 
	
	/**오더일자 Juilan Date 전환용 날짜*/
	private String szT5TRDJ;  
	
	/**출하일자 Juilan Date 전환용 날짜*/
	private String szT5ADDJ;   
	
	/**송장일자 Juilan Date 전환용 날짜*/
	private String szT5IVD;    
	
	/**G/L일자 Juilan Date 전환용 날짜*/
	private String szT5DGL;    

}//end class()
