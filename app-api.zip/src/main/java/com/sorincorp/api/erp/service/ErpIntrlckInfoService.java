package com.sorincorp.api.erp.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.api.erp.comm.constant.ErpAcntTrnsmitConstant;
import com.sorincorp.api.erp.model.ErpCloseJDEVO;
import com.sorincorp.api.erp.model.ErpEditF55TD01JDEVO;
import com.sorincorp.api.erp.model.ErpIfErpVO;
import com.sorincorp.api.erp.model.ErpOpenJDEVO;
import com.sorincorp.api.erp.model.ErpSelectF55TD01JDEVO;
import com.sorincorp.api.erp.model.ErpSelectF55TD02JDEVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * ErpIntrlckInfoService.java
 * ERP 연동 정보 Service.java
 * 
 * @version
 * @since 2021. 10. 5.
 * @author srec0054
 */
@Slf4j
@Service
public class ErpIntrlckInfoService {
	
	private static final String ERP_URL = "SR/exeBSFN.do?";
	
	@Value("${erp.server.api.host}")
	private String jdcHost;
	
	@Value("${erp.server.api.port}")
	private String jdcPort;
	
	@Autowired
	private CommonCodeService commonCodeService;
	
	
	/**
	 * 
	 * <pre>
	 * ERP Open JDE API
	 * </pre>
	 * @date 2021. 10. 14.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 14.		srec0054			최초작성
	 * 2023. 06. 01.		jdrttl				재고조정 추가
	 * ------------------------------------------------
	 * @param 	String interfaceDiv
	 * @return	ErpOpenJDEVO
	 * @throws 	Exception
	 */
	public ErpOpenJDEVO openJDE(String interfaceDiv) throws Exception {
		log.debug("openJDE Start");
		
		ErpOpenJDEVO returnObj		= new ErpOpenJDEVO();
		JSONObject requestObj 		= new JSONObject();					//JDE Interface Requset (functionParam + functionName)
		JSONObject functionParam	= new JSONObject(); 				//JDE Interface Request (functionParam)
        Map<String, Object> resp 	= new HashMap<String, Object>();	//JDE Interface Request
        String returnJsonString 	= null;								//openJDE API 응답 결과
        String responseCode 		= null;								//openJDE API 응답 결과 코드
        /* ERP 분리 전송 여부 설정값 가져오기 - Y값일시 true, 아니면 false */
		boolean isSeprat = StringUtils.equals("Y", commonCodeService.getCodeValueRetVo("ERP_SEPRAT_TRNSMIS_CODE", "10").getCodeDcone()) ;
		log.debug("ERP 분리 전송 여부 설정값 : {}", isSeprat);
        
        try {

        	//JDE Interface Request (functionParam)
        	functionParam.put(ErpAcntTrnsmitConstant.C_TARGET_TABLE	, ErpAcntTrnsmitConstant.JDE_1);			//구분 (1(F55TD01) / 2(F55TD03))
        	
        	//Interface 유형
        	// 2023-03-03 변경사항 : 주문에 대한 매출 처리 ERP 전송 계정을 설정값(isSeprat)에 따라 CSU(판매마감) 또는 CSI(물품대) + CSB(배송비) 로 처리하도록 변경
        	if(ErpAcntTrnsmitConstant.JOB_SE_01.equals(interfaceDiv) && !isSeprat) functionParam.put(ErpAcntTrnsmitConstant.SZ_T5IFTP	, ErpAcntTrnsmitConstant.INTERFACE_TYPE_CSU);	//판매마감
        	else if(ErpAcntTrnsmitConstant.JOB_SE_01.equals(interfaceDiv) && isSeprat) functionParam.put(ErpAcntTrnsmitConstant.SZ_T5IFTP	, ErpAcntTrnsmitConstant.INTERFACE_TYPE_CSI);//물품대
        	else if(ErpAcntTrnsmitConstant.JOB_SE_02.equals(interfaceDiv)) functionParam.put(ErpAcntTrnsmitConstant.SZ_T5IFTP	, ErpAcntTrnsmitConstant.INTERFACE_TYPE_CWS);			//판매중량정산
        	else if(ErpAcntTrnsmitConstant.JOB_SE_03.equals(interfaceDiv)) functionParam.put(ErpAcntTrnsmitConstant.SZ_T5IFTP	, ErpAcntTrnsmitConstant.INTERFACE_TYPE_RSU);			//판매마감 역처리
        	else if(ErpAcntTrnsmitConstant.INTERFACE_TYPE_RSU.equals(interfaceDiv)) functionParam.put(ErpAcntTrnsmitConstant.SZ_T5IFTP	, ErpAcntTrnsmitConstant.INTERFACE_TYPE_RSU);	//판매마감 역처리
        	else if(ErpAcntTrnsmitConstant.INTERFACE_TYPE_RWS.equals(interfaceDiv)) functionParam.put(ErpAcntTrnsmitConstant.SZ_T5IFTP	, ErpAcntTrnsmitConstant.INTERFACE_TYPE_RWS);	//판매중량정산 역처리
        	else if(ErpAcntTrnsmitConstant.INTERFACE_TYPE_CWS.equals(interfaceDiv)) functionParam.put(ErpAcntTrnsmitConstant.SZ_T5IFTP	, ErpAcntTrnsmitConstant.INTERFACE_TYPE_CWS);	//판매중량정산
        	else if(ErpAcntTrnsmitConstant.JOB_SE_06.equals(interfaceDiv)) functionParam.put(ErpAcntTrnsmitConstant.SZ_T5IFTP	, ErpAcntTrnsmitConstant.INTERFACE_TYPE_JOB);			//잡이익
        	else if(ErpAcntTrnsmitConstant.JOB_SE_CEP.equals(interfaceDiv)) functionParam.put(ErpAcntTrnsmitConstant.SZ_T5IFTP	, ErpAcntTrnsmitConstant.INTERFACE_TYPE_CEP);			//비용전표생성
        	else if(ErpAcntTrnsmitConstant.JOB_SE_07.equals(interfaceDiv)) functionParam.put(ErpAcntTrnsmitConstant.SZ_T5IFTP	, ErpAcntTrnsmitConstant.INTERFACE_TYPE_RWS);			//중량 역처리
        	else if(ErpAcntTrnsmitConstant.JOB_SE_08.equals(interfaceDiv)) functionParam.put(ErpAcntTrnsmitConstant.SZ_T5IFTP	, ErpAcntTrnsmitConstant.INTERFACE_TYPE_CSB);			//배송비
        	else if(ErpAcntTrnsmitConstant.INTERFACE_TYPE_ADJ.equals(interfaceDiv)) functionParam.put(ErpAcntTrnsmitConstant.SZ_T5IFTP	, ErpAcntTrnsmitConstant.INTERFACE_TYPE_ADJ);	//재고조정

        	functionParam.put(ErpAcntTrnsmitConstant.SZ_T5SYSC		, ErpAcntTrnsmitConstant.SECS);				//Interface System Code	(SECS)
        	functionParam.put(ErpAcntTrnsmitConstant.SZ_USER		, ErpAcntTrnsmitConstant.USER_NM);			//사용자
        	functionParam.put(ErpAcntTrnsmitConstant.SZ_T5TDPID		, ErpAcntTrnsmitConstant.SECS);				//Geust System Program ID
        	
        	//JDE Interface Requset (functionParam + functionName)
        	requestObj.put(ErpAcntTrnsmitConstant.FUNCTION_PARAM	, functionParam);
        	
        	if(ErpAcntTrnsmitConstant.INTERFACE_TYPE_ADJ.equals(interfaceDiv)) {
        		requestObj.put(ErpAcntTrnsmitConstant.FUNCTION_NAME, ErpAcntTrnsmitConstant.OPEN_JDE_FOR_STOCK);
        	} else {
        		requestObj.put(ErpAcntTrnsmitConstant.FUNCTION_NAME, ErpAcntTrnsmitConstant.OPEN_JDE);
        	}

        	//JDE Interface Request
            resp.put(ErpAcntTrnsmitConstant.URL			, ERP_URL);
            resp.put(ErpAcntTrnsmitConstant.REQUEST_OBJ	, requestObj);
            
            //JDE interface call
            for(int a = 0 ; a < 5 ; a++) {
            	log.debug("JDE interface call ============= " + a + " ============= ");
            	resp = getJDEgInterface(resp, requestObj);
            	
            	responseCode 		= resp.get(ErpAcntTrnsmitConstant.RESPONSE_CODE).toString();	//openJDE API 응답 결과 코드
            	
            	if(ErpAcntTrnsmitConstant.SUCCESS_RESULT_CODE.equals(responseCode) ) {
            		returnJsonString 	= resp.get(ErpAcntTrnsmitConstant.OUTPUT).toString();			//openJDE API 응답 결과
            		break;
            	}

            }//end for()
            
			// openJDE API 응답 결과 Json > String > VO parsing
        	ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        	returnObj 			= mapper.readValue(returnJsonString, ErpOpenJDEVO.class);
        	
        } catch (Exception e) {
            returnObj.setCErrorFlag(ErpAcntTrnsmitConstant.RESPONSE_CODE_MINUS_1);
            returnObj.setSzErrorDescription(e.toString());
            returnObj.setResult(ErpAcntTrnsmitConstant.ERROR_RESULT_MSG);
            log.debug("ErpIntrlckInfoService::openJDE Exception = " + e.getMessage());
        }
        
        log.debug("openJDE returnObj = " + returnObj.toString());
        log.debug("openJDE End");
        return returnObj;
	}//end openJDE()
	
	/**
	 * 
	 * <pre>
	 * ERP editF55TD01JDE API
	 * </pre>
	 * @date 2021. 10. 14.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 14.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	ErpIfErpVO erpIfErpVo
	 * @return	Map<String, Object>
	 * @throws 	Exception
	 */
	@SuppressWarnings("null")
	public Map<String, Object> editF55TD01JDE(ErpIfErpVO erpIfErpVo) throws Exception {
		log.debug("editF55TD01JDE Start");
		
		JSONObject requestObj 					= new JSONObject();					//JDE Interface Requset (functionParam + functionName)
		JSONObject functionParam 				= new JSONObject();					//JDE Interface Request (functionParam)
		Map<String, Object> resp 				= new HashMap<String, Object>();	//JDE Interface Request
		ErpEditF55TD01JDEVO erpEditF55TD01JDEVo = new ErpEditF55TD01JDEVO();		//F55TD01
		String returnJsonString 				= null;								//editF55TD01JDE API 응답 결과
        String responseCode 					= null;								//editF55TD01JDE API 응답 결과 코드
        
        try {
        	//JDE Interface Request (functionParam)
        	erpEditF55TD01JDEVo 			= voConvert(erpIfErpVo);					//functionParam IF_ERP > F55TD01 Convert
    		
        	functionParam.put("mnT5JNO"		, erpEditF55TD01JDEVo.getMnT5JNO());		//Job Numbe
        	functionParam.put("mnT5IFNO"	, erpEditF55TD01JDEVo.getMnT5IFNO());		//Interface 번호
        	functionParam.put("szT5IFTP"	, erpEditF55TD01JDEVo.getSzT5IFTP());		//Interface 유형
        	functionParam.put("mnT5IFLN"	, erpEditF55TD01JDEVo.getMnT5IFLN());		//Interface 라인번호
        	functionParam.put("szT5SYSC"	, erpEditF55TD01JDEVo.getSzT5SYSC());		//Interface System Code
        	functionParam.put("szT5TDNO"	, erpEditF55TD01JDEVo.getSzT5TDNO());		//Trading 오더번호
        	functionParam.put("mnT5TDLN"	, erpEditF55TD01JDEVo.getMnT5TDLN());		//Trading 오더 라인번호\
        	functionParam.put("szT5INVNO"	, erpEditF55TD01JDEVo.getSzT5INVNO());		//Trading Invoice 번호
        	functionParam.put("szT5BALTP"	, erpEditF55TD01JDEVo.getSzT5BALTP());		//정산유형
        	functionParam.put("mnASE"		, erpEditF55TD01JDEVo.getMnASE());			//정산순번
        	functionParam.put("szDCTO"		, erpEditF55TD01JDEVo.getSzDCTO());			//오더유형
        	functionParam.put("mnAN8"		, erpEditF55TD01JDEVo.getMnAN8());			//거래처
        	functionParam.put("mnSHAN"		, erpEditF55TD01JDEVo.getMnSHAN());			//납품처
        	functionParam.put("szMCU"		, erpEditF55TD01JDEVo.getSzMCU());			//사업장
        	functionParam.put("szEMCU"		, erpEditF55TD01JDEVo.getSzEMCU());			//수익사업단위
        	functionParam.put("jdTRDJ"		, erpEditF55TD01JDEVo.getJdTRDJ());			//오더일자
        	functionParam.put("jdADDJ"		, erpEditF55TD01JDEVo.getJdADDJ());			//출하일자
        	functionParam.put("jdIVD"		, erpEditF55TD01JDEVo.getJdIVD());			//송장일자
        	functionParam.put("jdDGL"		, erpEditF55TD01JDEVo.getJdDGL());			//G/L일자
        	functionParam.put("szLITM"		, erpEditF55TD01JDEVo.getSzLITM());			//품목번호
        	functionParam.put("mnUORG"		, erpEditF55TD01JDEVo.getMnUORG());			//오더수량
        	functionParam.put("mnSOQS"		, erpEditF55TD01JDEVo.getMnSOQS());			//출하수량
        	functionParam.put("szEXR1"		, erpEditF55TD01JDEVo.getSzEXR1());			//세목코드
        	functionParam.put("szTXA1"		, erpEditF55TD01JDEVo.getSzTXA1());			//세율/세역
        	functionParam.put("szGLC"		, erpEditF55TD01JDEVo.getSzGLC());			//G/L Class
        	functionParam.put("mnUPRC"		, erpEditF55TD01JDEVo.getMnUPRC());			//원화단가
        	functionParam.put("mnAEXP"		, erpEditF55TD01JDEVo.getMnAEXP());			//원화금액
        	functionParam.put("szCRCD"		, erpEditF55TD01JDEVo.getSzCRCD());			//통화코드
        	functionParam.put("mnFUP"		, erpEditF55TD01JDEVo.getMnFUP());			//외화단가
        	functionParam.put("mnFEA"		, erpEditF55TD01JDEVo.getMnFEA());			//외화금액
        	functionParam.put("mnCRR"		, erpEditF55TD01JDEVo.getMnCRR());			//환율
        	functionParam.put("szK5LCNO"	, erpEditF55TD01JDEVo.getSzK5LCNO());		//L/C 번호
        	functionParam.put("szK5BLNO"	, erpEditF55TD01JDEVo.getSzK5BLNO());		//B/L 번호
        	functionParam.put("szKCO"		, erpEditF55TD01JDEVo.getSzKCO());			//회사
        	functionParam.put("mnATXA"		, erpEditF55TD01JDEVo.getMnATXA());			//공급가액
        	functionParam.put("mnSTAM"		, erpEditF55TD01JDEVo.getMnSTAM());			//세액
        	functionParam.put("mnATXN"		, erpEditF55TD01JDEVo.getMnATXN());			//비과세액
        	functionParam.put("mnAG"		, erpEditF55TD01JDEVo.getMnAG());			//총액
        	functionParam.put("mnCTXA"		, erpEditF55TD01JDEVo.getMnCTXA());			//외화공급가액
        	functionParam.put("mnCTAM"		, erpEditF55TD01JDEVo.getMnCTAM());			//외화세액
        	functionParam.put("mnCTXN"		, erpEditF55TD01JDEVo.getMnCTXN());			//외화비과세액
        	functionParam.put("mnACR"		, erpEditF55TD01JDEVo.getMnACR());			//외화총액
        	functionParam.put("cT5IFFG"		, erpEditF55TD01JDEVo.getCT5IFFG());		//Interface Flag(STS용 전기역처리 체크)
        	functionParam.put("cT5PTCD"		, erpEditF55TD01JDEVo.getCT5PTCD());		//ERP 전기 역처리 코드
        	functionParam.put("jdHDGJ"		, erpEditF55TD01JDEVo.getJdHDGJ());			//전기 역처리 일자(G/L일자)
        	functionParam.put("mnT5PREPID"	, erpEditF55TD01JDEVo.getMnT5PREPID());		//Trading 선급요청 ID
        	functionParam.put("jdDDJ"		, erpEditF55TD01JDEVo.getJdDDJ());			//Due Date
        	functionParam.put("szRMK"		, erpEditF55TD01JDEVo.getSzRMK());			//Remark(비고)
        	functionParam.put("szEXA"		, erpEditF55TD01JDEVo.getSzEXA());			//설명
        	functionParam.put("szOBJ"		, erpEditF55TD01JDEVo.getSzOBJ());			//주계정
        	functionParam.put("szSUB"		, erpEditF55TD01JDEVo.getSzSUB());			//보조계정
        	functionParam.put("szDL01"		, erpEditF55TD01JDEVo.getSzDL01());			//I/F 비고
        	functionParam.put("szT5TDPID"	, erpEditF55TD01JDEVo.getSzT5TDPID());		//Guest Program ID
        	functionParam.put("szT5ACCD"	, erpEditF55TD01JDEVo.getSzT5ACCD());		//선물평가 계정코드
        	functionParam.put("szT5ECSTCD"	, erpEditF55TD01JDEVo.getSzT5ECSTCD());		//ECommerce  주문 취소/교환/반품 상태 코드
        	functionParam.put("szT5ECSTNO"	, erpEditF55TD01JDEVo.getSzT5ECSTNO());		//ECommerce 취소/교환/반품 번호
        	functionParam.put("szT5ECEPCD"	, erpEditF55TD01JDEVo.getSzT5ECEPCD());		//Ecommerce 비용 코드
        	functionParam.put("szT5TRDJ"	, erpEditF55TD01JDEVo.getSzT5TRDJ());		//오더일자 Juilan Date 전환용 날짜
        	functionParam.put("szT5ADDJ"	, erpEditF55TD01JDEVo.getSzT5ADDJ());		//출하일자 Juilan Date 전환용 날짜
        	functionParam.put("szT5IVD"		, erpEditF55TD01JDEVo.getSzT5IVD());		//송장일자 Juilan Date 전환용 날짜
        	functionParam.put("szT5DGL"		, erpEditF55TD01JDEVo.getSzT5DGL());		//G/L일자 Juilan Date 전환용 날짜
        	functionParam.put("szUSER"		, erpEditF55TD01JDEVo.getSzUSER());			//생성자 ERP 계정
        	functionParam.put("jdUPMJ"		, erpEditF55TD01JDEVo.getJdUPMJ());			//Trading 수정일자
        	functionParam.put("mnUPMT"		, erpEditF55TD01JDEVo.getMnUPMT());			//Trading 수정시간
        	
        	log.debug("functionParam ==============================================================");
        	log.debug(functionParam.toString());
        	log.debug("functionParam ==============================================================");
        	
            //JDE Interface Requset (functionParam + functionName)
    		requestObj.put(ErpAcntTrnsmitConstant.FUNCTION_PARAM	, functionParam);		   
    		requestObj.put(ErpAcntTrnsmitConstant.FUNCTION_NAME		, ErpAcntTrnsmitConstant.EDIT_F55TD01JDE);    
    		
    		//JDE Interface Request
    		resp.put(ErpAcntTrnsmitConstant.URL			, ERP_URL);
            resp.put(ErpAcntTrnsmitConstant.REQUEST_OBJ	, requestObj);
            
            //JDE interface call
            resp = getJDEgInterface(resp, requestObj);
            returnJsonString 	= resp.get(ErpAcntTrnsmitConstant.OUTPUT).toString();
            responseCode 		= resp.get(ErpAcntTrnsmitConstant.RESPONSE_CODE).toString();

            log.debug("ErpIntrlckInfoService::editF55TD01JDE returnJsonString 	= " + returnJsonString);
            log.debug("ErpIntrlckInfoService::editF55TD01JDE responseCode 		= " + responseCode);
            
		} catch (Exception e) {
			log.debug("ErpIntrlckInfoService::editF55TD01JDE Exception = " + e.getMessage());
		}
		
		log.debug("editF55TD01JDE End");
		return resp;
	}//end editF55TD01JDE()
	
	/**
	 * 
	 * <pre>
	 * ERP editF55TD01JDE_ADJ API
	 * </pre>
	 * @date 2023. 06. 12.
	 * @author jdrttl
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 06. 12.		jdrttl				최초작성
	 * ------------------------------------------------
	 * @param 	ErpIfErpVO erpIfErpVo
	 * @return	Map<String, Object>
	 * @throws 	Exception
	 */
	@SuppressWarnings("null")
	public Map<String, Object> editF55TD01JDE_ADJ(ErpIfErpVO erpIfErpVo) throws Exception {
		log.debug("editF55TD01JDE_ADJ Start");
		
		JSONObject requestObj 					= new JSONObject();					//JDE Interface Requset (functionParam + functionName)
		JSONObject functionParam 				= new JSONObject();					//JDE Interface Request (functionParam)
		Map<String, Object> resp 				= new HashMap<String, Object>();	//JDE Interface Request
		String returnJsonString 				= null;								//editF55TD01JDE API 응답 결과
		String responseCode 					= null;								//editF55TD01JDE API 응답 결과 코드

		try {
			functionParam.put("mnT5JNO"		, erpIfErpVo.getMnT5JNO());				//Job Numbe
			functionParam.put("cErrorFlag"			, "");
			functionParam.put("szErrorDescription"	, "");
			functionParam.put("mnT5IFNO"	, erpIfErpVo.getMnT5IFNO());			//인터페이스번호
			functionParam.put("szT5IFTP"	, "ADJ");								//인터페이스 타입
			functionParam.put("mnT5IFLN"	, erpIfErpVo.getErpIntrfcLineNo());		//인터페이스라인번호
			functionParam.put("szT5SYSC"	, "SECS");								//시스템코드
			functionParam.put("szKCO"		, "00001");								//회사코드
			functionParam.put("mnDOCO"		, erpIfErpVo.getImErpPoNo());			//오더번호
			functionParam.put("szDCTO"		, erpIfErpVo.getImErpOrderType());		//오더타입
			functionParam.put("mnLNID"		, erpIfErpVo.getImErpPoLine());			//오더라인번호
			functionParam.put("mnAN8"		, erpIfErpVo.getImErpPoCustCd());		//거래처코드
			functionParam.put("szMCU"		, erpIfErpVo.getBplc());				//사업단위
			functionParam.put("szLITM"		, erpIfErpVo.getImErpItemCode());		//아이템코드
			functionParam.put("mnUORG"		, erpIfErpVo.getImQty());				//재고조정수량
			functionParam.put("szK5LCNO"	, "본사창고");								//창고(ERP)
			functionParam.put("szK5BLNO"	, erpIfErpVo.getImBlNo());				//BL번호
			functionParam.put("mnICU"		, "0");									//배치번호(ERP)
			functionParam.put("szICUT"		, "XX");								//배치타입(ERP)
			functionParam.put("mnDOC"		, "0");									//문서번호(ERP)
			functionParam.put("szDCT"		, "XX");								//문서타입(ERP)
			functionParam.put("mnJELN"		, erpIfErpVo.getImErpLine());			//재고조정전표라인번호
			functionParam.put("szDC"		, "");								//문서타입(ERP)
			functionParam.put("szDL01"		, erpIfErpVo.getImLotn());				//재고조정비고내용
			functionParam.put("szUSER"		, erpIfErpVo.getImFrstRegisterId());	//USERID
			//functionParam.put("jdUPMJ"		, erpIfErpVo.getImFrstRegistDate());	//UpdateDate
			//functionParam.put("mnUPMT"		, erpIfErpVo.getImFrstRegistTime());	//UpdateTime
			functionParam.put("jdUPMJ"		, "");	//UpdateDate
			functionParam.put("mnUPMT"		, "");	//UpdateTime
			functionParam.put("szT5DGL"		, erpIfErpVo.getImErpGlDate());			//회계일자



			log.debug("functionParam ==============================================================");
			log.debug(functionParam.toString());
			log.debug("functionParam ==============================================================");
			
			//JDE Interface Requset (functionParam + functionName)
			requestObj.put(ErpAcntTrnsmitConstant.FUNCTION_PARAM	, functionParam);		   
			requestObj.put(ErpAcntTrnsmitConstant.FUNCTION_NAME		, ErpAcntTrnsmitConstant.STOCK_ADJUSTMENT);
			
			//JDE Interface Request
			resp.put(ErpAcntTrnsmitConstant.URL			, ERP_URL);
			resp.put(ErpAcntTrnsmitConstant.REQUEST_OBJ	, requestObj);
			
			//JDE interface call
			resp = getJDEgInterface(resp, requestObj);
			returnJsonString 	= resp.get(ErpAcntTrnsmitConstant.OUTPUT).toString();
			responseCode 		= resp.get(ErpAcntTrnsmitConstant.RESPONSE_CODE).toString();
			
			log.debug("ErpIntrlckInfoService::editF55TD01JDE returnJsonString 	= " + returnJsonString);
			log.debug("ErpIntrlckInfoService::editF55TD01JDE responseCode 		= " + responseCode);

		} catch (Exception e) {
			log.debug("ErpIntrlckInfoService::editF55TD01JDE Exception = " + e.getMessage());
		}

		log.debug("editF55TD01JDE End");
		return resp;
	}//end editF55TD01JDE()
	
	public ErpCloseJDEVO closeJDE(ErpOpenJDEVO returnObj) throws Exception {
		return closeJDEDiv(returnObj, "");
	}
	
	public ErpCloseJDEVO closeJDE(ErpOpenJDEVO returnObj, String interfaceDiv) throws Exception {
		return closeJDEDiv(returnObj, interfaceDiv);
	}
	
	/**
	 * 
	 * <pre>
	 * ERP CloseJDE API
	 * </pre>
	 * @date 2021. 10. 15.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 15.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	ErpOpenJDEVO returnObj
	 * @return	ErpCloseJDEVO
	 * @throws 	Exception
	 */
	public ErpCloseJDEVO closeJDEDiv(ErpOpenJDEVO returnObj, String interfaceDiv) throws Exception {
		log.debug("closeJDE Start");
		
		ErpCloseJDEVO erpCloseJDEVo	= new ErpCloseJDEVO();
		JSONObject requestObj 		= new JSONObject();								//JDE Interface Requset (functionParam + functionName)
		JSONObject functionParam	= new JSONObject();								//JDE Interface Request (functionParam)
		Map<String, Object> resp 	= new HashMap<String, Object>();				//JDE Interface Request
		String returnJsonString		= null;											//closeJDE API 응답 결과
		String responseCode			= null;											//closeJDE API 응답 결과 코드
		String jobId 				= returnObj.getMnT5JNO();						//JOB ID : openJDE API 응답 결과
		
		try {
			
			//JDE Interface Request (functionParam)
			functionParam.put(ErpAcntTrnsmitConstant.MN_T5JNO			, jobId);							//JOB ID
	    	functionParam.put(ErpAcntTrnsmitConstant.C_RUNNING_FLAG		, ErpAcntTrnsmitConstant.JDE_1);	//N55TD01 실행여부 1(Run) / 2(Not run)
	    	
	    	//JDE Interface Requset (functionParam + functionName)
	    	requestObj.put(ErpAcntTrnsmitConstant.FUNCTION_PARAM	, functionParam);
	    	
        	if(ErpAcntTrnsmitConstant.INTERFACE_TYPE_ADJ.equals(interfaceDiv)) {
        		requestObj.put(ErpAcntTrnsmitConstant.FUNCTION_NAME		, ErpAcntTrnsmitConstant.CLOSE_JDE_FOR_STOCK);
        	} else {
        		requestObj.put(ErpAcntTrnsmitConstant.FUNCTION_NAME		, ErpAcntTrnsmitConstant.CLOSE_JDE);
        	}

	    	//JDE Interface Request
	        resp.put(ErpAcntTrnsmitConstant.URL			, ERP_URL);
	        resp.put(ErpAcntTrnsmitConstant.REQUEST_OBJ	, requestObj);

	        //JDE interface call
	        resp = getJDEgInterface(resp, requestObj);
			
	        returnJsonString 	= resp.get(ErpAcntTrnsmitConstant.OUTPUT).toString();
	        responseCode 		= resp.get(ErpAcntTrnsmitConstant.RESPONSE_CODE).toString();
	        
	        log.debug("===========================================================================================");
	        log.debug("returnJsonString = " + returnJsonString);
	        log.debug("responseCode = " + responseCode);
	        log.debug("===========================================================================================");
	        
	        // closeJDE API 응답 결과 Json > String > VO parsing
        	ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        	erpCloseJDEVo 		= mapper.readValue(returnJsonString, ErpCloseJDEVO.class);
        	
		} catch (Exception e) {
			erpCloseJDEVo.setCErrorFlag(ErpAcntTrnsmitConstant.RESPONSE_CODE_MINUS_1);
			erpCloseJDEVo.setSzErrorDescription(e.toString());
			erpCloseJDEVo.setResult(ErpAcntTrnsmitConstant.ERROR_RESULT_MSG);
			log.debug("ErpIntrlckInfoService::closeJDE Exception = " + e.getMessage());
		}
		
		log.debug("closeJDE End");
		return erpCloseJDEVo;
	}//end closeJDE()
	
	public ErpSelectF55TD01JDEVO selectF55TD01JDE() throws Exception{
		log.debug("ErpIntrlckInfoService::selectF55TD01JDE Start");
		
		ErpSelectF55TD01JDEVO erpSelectF55TD01JDEVo = new ErpSelectF55TD01JDEVO();  
		JSONObject requestObj 		= new JSONObject();								//JDE Interface Requset (functionParam + functionName)
		JSONObject functionParam	= new JSONObject();								//JDE Interface Request (functionParam)
		Map<String, Object> resp 	= new HashMap<String, Object>();				//JDE Interface Request
		String returnJsonString		= null;											//SelectF55TD01JDE API 응답 결과
		String responseCode			= null;											//SelectF55TD01JDE API 응답 결과 코드
		
		//JDE Interface Request (functionParam)
		functionParam.put(ErpAcntTrnsmitConstant.MN_T5INDEX			, "10");							//Index Case
    	functionParam.put("szT5SYSC_In"								, "SECS");							//Interface System Code
    	functionParam.put("mnT5JNO_In"								, "384");							//API Job Number
    	
    	//JDE Interface Requset (functionParam + functionName)
    	requestObj.put(ErpAcntTrnsmitConstant.FUNCTION_PARAM	, functionParam);
    	requestObj.put(ErpAcntTrnsmitConstant.FUNCTION_NAME		, ErpAcntTrnsmitConstant.SELECT_F55TD01_JDE);

    	//JDE Interface Request
        resp.put(ErpAcntTrnsmitConstant.URL			, ERP_URL);
        resp.put(ErpAcntTrnsmitConstant.REQUEST_OBJ	, requestObj);

        //JDE interface call
        resp = getJDEgInterface(resp, requestObj);
		
        returnJsonString 	= resp.get(ErpAcntTrnsmitConstant.OUTPUT).toString();
        responseCode 		= resp.get(ErpAcntTrnsmitConstant.RESPONSE_CODE).toString();
        
        log.debug("===========================================================================================");
        log.debug("returnJsonString = " + returnJsonString);
        log.debug("responseCode = " + responseCode);
        log.debug("===========================================================================================");
        
        
        log.debug("ErpIntrlckInfoService::selectF55TD01JDE End");
        return erpSelectF55TD01JDEVo;
	}//end selectF55TD01JDE()
	
	public ErpSelectF55TD02JDEVO selectF55TD02JDE() throws Exception {
		log.debug("ErpIntrlckInfoService::selectF55TD02JDE Start");
		
		ErpSelectF55TD02JDEVO erpSelectF55TD02JDEVo = new ErpSelectF55TD02JDEVO();  
		JSONObject requestObj 		= new JSONObject();								//JDE Interface Requset (functionParam + functionName)
		JSONObject functionParam	= new JSONObject();								//JDE Interface Request (functionParam)
		Map<String, Object> resp 	= new HashMap<String, Object>();				//JDE Interface Request
		String returnJsonString		= null;											//SelectF55TD01JDE API 응답 결과
		String responseCode			= null;											//SelectF55TD01JDE API 응답 결과 코드
		
		//JDE Interface Request (functionParam)
		functionParam.put("mnT5INDEX"			, "1");							//Index Case
    	functionParam.put("mnT5IFNO_In"			, "2568");						//Interface 번호
    	functionParam.put("szT5IFTP_In"			, "RSU");						//Interface 라인번호
    	
    	//JDE Interface Requset (functionParam + functionName)
    	requestObj.put(ErpAcntTrnsmitConstant.FUNCTION_PARAM	, functionParam);
    	requestObj.put(ErpAcntTrnsmitConstant.FUNCTION_NAME		, ErpAcntTrnsmitConstant.SELECT_F55TD02_JDE);

    	//JDE Interface Request
        resp.put(ErpAcntTrnsmitConstant.URL			, ERP_URL);
        resp.put(ErpAcntTrnsmitConstant.REQUEST_OBJ	, requestObj);

        //JDE interface call
        resp = getJDEgInterface(resp, requestObj);
		
        returnJsonString 	= resp.get(ErpAcntTrnsmitConstant.OUTPUT).toString();
        responseCode 		= resp.get(ErpAcntTrnsmitConstant.RESPONSE_CODE).toString();
        
        log.debug("===========================================================================================");
        log.debug("returnJsonString = " + returnJsonString);
        log.debug("responseCode = " + responseCode);
        log.debug("===========================================================================================");
        
        
        log.debug("ErpIntrlckInfoService::selectF55TD02JDE End");
		
		return erpSelectF55TD02JDEVo;
	}//end selectF55TD02JDE()
	
	/**
	 * 
	 * <pre>
	 * DJC 호출
	 * </pre>
	 * @date 2021. 10. 5.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 5.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	Map<String, Object> param
	 * @return	Map<String, Object>
	 * @throws 	JsonParseException
	 * @throws 	JsonMappingException
	 * @throws 	IOException
	 */
	public Map<String, Object> getJDEgInterface(Map<String, Object> param, JSONObject requestObj) throws JsonParseException, JsonMappingException, IOException {
   		log.debug("getJDEgInterface Start");
   		HttpURLConnection conn 	= null;
   		Integer responseCode 	= 0;
   		String resultMessage 	= "";
   		
   		try {
   			log.debug("jdcHost ===========> " + jdcHost);
   			log.debug("jdcPort ===========> " + jdcPort);
   			//ERP API URL 설정
			String url = "http://" + jdcHost + ":"+ jdcPort + "/" + ObjToString(param.get(ErpAcntTrnsmitConstant.URL));
			BufferedWriter  wr = null;

			//ERP (POST, JSON) 전송
			URL obj = new URL(url);
			conn = (HttpURLConnection) obj.openConnection();
			
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Accept"		, "application/json");
			conn.setRequestProperty("Content-Type"	, "application/json; charset=UTF-8");
			conn.setConnectTimeout(30000);			//컨텍션타임아웃 10초
			conn.setReadTimeout(15000);           	//컨텐츠조회 타임아웃 5총
			conn.setDoOutput(true);              	//항상 갱신된내용을 가져옴.
			
			wr = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
			wr.write(requestObj.toString());
			wr.flush();
			wr.close();
			
			responseCode 	= conn.getResponseCode();
			String output 	= "";
			
			if (responseCode == 400) resultMessage = "400:: 해당 명령을 실행할 수 없음";
			else if (responseCode == 401) resultMessage = "401:: X-Auth-Token Header가 잘못됨";
			else if (responseCode == 500) resultMessage = "500:: 서버 에러, 문의 필요";
			else { 
				resultMessage = ErpAcntTrnsmitConstant.SUCCESS_RESULT_MSG;
				
				BufferedReader br 	= new BufferedReader(new InputStreamReader(conn.getInputStream()));
				StringBuilder sb 	= new StringBuilder();
				String line 		= "";
				
				while ((line = br.readLine()) != null) {
			             sb.append(line);
				}//end while()
				
				output = sb.toString();

			}//end if()
			
			param.put(ErpAcntTrnsmitConstant.OUTPUT, output);
			
   		} catch (Exception e) {
   			resultMessage = e.toString();
   		} finally {
   			if(!isEmpty(conn)){
   				conn.disconnect();
   			}//end if()
	        param.put(ErpAcntTrnsmitConstant.RESPONSE_CODE	, responseCode);
	        param.put(ErpAcntTrnsmitConstant.RESULT_MESSAGE	, resultMessage);
        }
   		
   		log.debug("===========================================================================================");
   		log.debug("getJDEgInterface result ===== " + param.toString());
   		log.debug("===========================================================================================");
   		
        log.debug("getJDEgInterface End");
        return param;
	}//end getJDEgInterface()
	
	/**
	 * 
	 * <pre>
	 * IF_ERP VO > ERP_EDIT_F55TD01 VO CONVERT
	 * </pre>
	 * @date 2021. 10. 15.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 15.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	ErpIfErpVO erpIfErpVo
	 * @return	ErpEditF55TD01JDEVO
	 * @throws 	Exception
	 */
	public ErpEditF55TD01JDEVO voConvert(ErpIfErpVO erpIfErpVo) throws Exception {
		ErpEditF55TD01JDEVO erpEditF55TD01JDEVo = new ErpEditF55TD01JDEVO();
				
		try {
			
			String szT5IFTP = erpIfErpVo.getSzT5IFTP();		//Interface 유형
			
			erpEditF55TD01JDEVo.setMnT5JNO(erpIfErpVo.getMnT5JNO());
			erpEditF55TD01JDEVo.setMnT5IFNO(erpIfErpVo.getMnT5IFNO());
			erpEditF55TD01JDEVo.setSzT5IFTP(erpIfErpVo.getSzT5IFTP());
			erpEditF55TD01JDEVo.setMnT5IFLN(erpIfErpVo.getErpIntrfcLineNo());
			erpEditF55TD01JDEVo.setSzT5SYSC(erpIfErpVo.getSzT5SYSC());
			erpEditF55TD01JDEVo.setSzT5TDNO(erpIfErpVo.getEcOrderNo());
			erpEditF55TD01JDEVo.setMnT5TDLN(erpIfErpVo.getEcOrderLineNo());
			erpEditF55TD01JDEVo.setSzT5INVNO(erpIfErpVo.getEcInvoiceNo());
			erpEditF55TD01JDEVo.setSzT5BALTP(erpIfErpVo.getExcclcTy());
			erpEditF55TD01JDEVo.setMnASE(erpIfErpVo.getExcclcSn());
			erpEditF55TD01JDEVo.setSzDCTO(erpIfErpVo.getOrderTy());
			erpEditF55TD01JDEVo.setMnAN8(erpIfErpVo.getBcnc());
			erpEditF55TD01JDEVo.setMnSHAN(erpIfErpVo.getDvyfgOffic());
			erpEditF55TD01JDEVo.setSzMCU(erpIfErpVo.getBplc());
			erpEditF55TD01JDEVo.setSzEMCU(erpIfErpVo.getErnBsnsUnit());
			erpEditF55TD01JDEVo.setJdTRDJ(erpIfErpVo.getOrderDe());
			erpEditF55TD01JDEVo.setJdADDJ(erpIfErpVo.getShipmntDe());
			erpEditF55TD01JDEVo.setJdIVD(erpIfErpVo.getInvcDe());
			erpEditF55TD01JDEVo.setJdDGL(erpIfErpVo.getGlDe());
			erpEditF55TD01JDEVo.setSzLITM(erpIfErpVo.getPrdlstNo());
			erpEditF55TD01JDEVo.setMnUORG(erpIfErpVo.getOrderQy());
			erpEditF55TD01JDEVo.setMnSOQS(erpIfErpVo.getShipmntQy());
			erpEditF55TD01JDEVo.setSzEXR1(erpIfErpVo.getTaxitmCode());
			erpEditF55TD01JDEVo.setSzTXA1(erpIfErpVo.getTaxrt());
			erpEditF55TD01JDEVo.setSzGLC(erpIfErpVo.getGlClass());
			erpEditF55TD01JDEVo.setMnUPRC(erpIfErpVo.getWonUntpc());
			
			if(ErpAcntTrnsmitConstant.INTERFACE_TYPE_CEP.equals(szT5IFTP)) erpEditF55TD01JDEVo.setMnAEXP(null);
			else erpEditF55TD01JDEVo.setMnAEXP(erpIfErpVo.getSplpcAm());
			
			erpEditF55TD01JDEVo.setSzCRCD(erpIfErpVo.getCrncyCode());
			erpEditF55TD01JDEVo.setMnFUP(erpIfErpVo.getFgcryUntpc());
			erpEditF55TD01JDEVo.setMnFEA(erpIfErpVo.getFgcryAmount());
			erpEditF55TD01JDEVo.setMnCRR(erpIfErpVo.getEhgt());
			erpEditF55TD01JDEVo.setSzK5LCNO(erpIfErpVo.getLcNo());
			erpEditF55TD01JDEVo.setSzK5BLNO(erpIfErpVo.getBlNo());
			erpEditF55TD01JDEVo.setSzKCO(erpIfErpVo.getCmpny());
			erpEditF55TD01JDEVo.setMnATXA(erpIfErpVo.getSplpcAm());
			erpEditF55TD01JDEVo.setMnSTAM(erpIfErpVo.getTaxAm());
			erpEditF55TD01JDEVo.setMnATXN(erpIfErpVo.getTaxxmptAm());
			erpEditF55TD01JDEVo.setMnAG(erpIfErpVo.getTotAm());
			erpEditF55TD01JDEVo.setMnCTXA(erpIfErpVo.getFgcrySplpcAm());
			erpEditF55TD01JDEVo.setMnCTAM(erpIfErpVo.getFgcryTaxAm());
			erpEditF55TD01JDEVo.setMnCTXN(erpIfErpVo.getFgcryTaxxmptAm());
			erpEditF55TD01JDEVo.setMnACR(erpIfErpVo.getFgcryTotAm());
			erpEditF55TD01JDEVo.setCT5IFFG(erpIfErpVo.getErpIntrfcSe());
			erpEditF55TD01JDEVo.setCT5PTCD(erpIfErpVo.getErpFrmtrmStatnProcessCode());
			erpEditF55TD01JDEVo.setJdHDGJ(erpIfErpVo.getFrmtrmStatnProcessDe());
			erpEditF55TD01JDEVo.setMnT5PREPID(erpIfErpVo.getEcAdvpayRequstId());
			erpEditF55TD01JDEVo.setJdDDJ(erpIfErpVo.getExprtnDe());
			erpEditF55TD01JDEVo.setSzRMK(erpIfErpVo.getRm());
			erpEditF55TD01JDEVo.setSzEXA(erpIfErpVo.getDc());
			erpEditF55TD01JDEVo.setSzOBJ(erpIfErpVo.getWeekAcnt());
			erpEditF55TD01JDEVo.setSzSUB(erpIfErpVo.getAsstnAcnt());
			erpEditF55TD01JDEVo.setSzT5ECSTCD(erpIfErpVo.getCanclExchngRtngudTy()); 
			erpEditF55TD01JDEVo.setSzT5ECSTNO(erpIfErpVo.getCanclExchngRtngudNo()); 
			erpEditF55TD01JDEVo.setSzT5ECEPCD(erpIfErpVo.getErpCtCode());
			erpEditF55TD01JDEVo.setSzT5TRDJ(erpIfErpVo.getOrderDe());  
			erpEditF55TD01JDEVo.setSzT5ADDJ(erpIfErpVo.getShipmntDe());   
			erpEditF55TD01JDEVo.setSzT5IVD(erpIfErpVo.getInvcDe());    
			erpEditF55TD01JDEVo.setSzT5DGL(erpIfErpVo.getGlDe());   
			erpEditF55TD01JDEVo.setSzDL01(erpIfErpVo.getIfRm());
			erpEditF55TD01JDEVo.setSzT5TDPID(erpIfErpVo.getEcProgrmId());
			erpEditF55TD01JDEVo.setSzT5ACCD(erpIfErpVo.getFtrsEvlAcntCode());
			erpEditF55TD01JDEVo.setSzUSER(erpIfErpVo.getSzUSER());
			erpEditF55TD01JDEVo.setJdUPMJ(erpIfErpVo.getEcUpdtDe());
			erpEditF55TD01JDEVo.setMnUPMT(erpIfErpVo.getEcUpdtTime());

			//out
			erpEditF55TD01JDEVo.setCErrorFlag(null);
			erpEditF55TD01JDEVo.setSzErrorDescription(null);
			
		} catch (Exception e) {
			log.error("ErpIntrlckInfoService::voConvert exception = " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		
		return erpEditF55TD01JDEVo;
	}//end voConvert()
	
	
	public static String ObjToString(Object obj) {
		Object dataobject = obj;
		String convert= String.valueOf(dataobject);
		return convert;		
	}//end ObjToString()
	
    public static boolean isEmpty(Object obj) {
        return StringUtils.isEmpty(ObjToString(obj));
    }//end isEmpty()
	
	public static int ObjToInt(Object obj) {
		Object dataobject = obj;
		int convert= Integer.valueOf((String)dataobject);
		return convert;
		
	}//end ObjToInt()
	
	public static boolean isNumber(String str) {
		boolean result = true;
		if (str == null || str.length() == 0) {
			result = false;
		} else {
			for (int i = 0; i < str.length(); i++) {
				int c = (int) str.charAt(i);
				if (c < 48 || c > 57) {
					result = false;
				}//end if()
			}//end for()
		}//end if()
		return result;
	}//end isNumber()
	
}//end class()
