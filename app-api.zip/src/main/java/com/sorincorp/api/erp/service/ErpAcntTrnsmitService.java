package com.sorincorp.api.erp.service;

import com.sorincorp.api.erp.model.ErpAcntTrnsmitRequestVO;
import com.sorincorp.api.erp.model.ErpCloseJDEVO;

/**
 * 
 * ErpAcntTrnsmitService.java
 * ERP 계정 송신 공통 Service.java
 * 
 * @version
 * @since 2021. 10. 5.
 * @author srec0054
 */
public interface ErpAcntTrnsmitService {

	/**
	 * 
	 * <pre>
	 * 상품매출(내수EC) ERP계정 송신
	 * </pre>
	 * @date 2021. 10. 5.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 5.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	ErpAcntTrnsmitRequestVO requestVo
	 * @throws 	Exception
	 */
	void erpGoodsSelng(ErpAcntTrnsmitRequestVO requestVo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 판관비(지급수수료) ERP계정 송신
	 * </pre>
	 * @date 2021. 10. 5.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 5.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	ErpAcntTrnsmitRequestVO requestVo
	 * @throws 	Exception
	 */
	ErpCloseJDEVO erpEwalletFee(ErpAcntTrnsmitRequestVO requestVo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 판관비(물류비) ERP계정 송신
	 * </pre>
	 * @date 2021. 10. 5.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 5.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	ErpAcntTrnsmitRequestVO requestVo
	 * @throws 	Exception
	 */
	ErpCloseJDEVO erpLgistCt(ErpAcntTrnsmitRequestVO requestVo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 재고조정 ERP계정 송신
	 * </pre>
	 * @date 2023. 05. 15.
	 * @author jdrttl
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 05. 15.		jdrttl				최초작성
	 * ------------------------------------------------
	 * @param 	ErpAcntTrnsmitRequestVO requestVo
	 * @throws 	Exception
	 */
	void erpInvntryAdjst(ErpAcntTrnsmitRequestVO requestVo) throws Exception;
}//end interface()
