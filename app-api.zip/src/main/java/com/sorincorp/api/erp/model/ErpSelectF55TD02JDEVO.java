package com.sorincorp.api.erp.model;

import lombok.Data;

@Data
public class ErpSelectF55TD02JDEVO {

	/**
	 * IN
	 */
	
	/**Index Case*/
	private String mnT5INDEX;
	
	/**
	구분값	컬럼1		컬럼2		컬럼3
	1		T5IFNO	T5IFTP	
	2		T5IFNO	T5IFTP	T5IFLN
	 */
	
	/**Interface 번호*/
	private String mnT5IFNO_In;
	
	/**Interface 유형*/
	private String szT5IFTP_In;
	
	/**Interface 라인번호*/
	private String mnT5IFLN_In;
	
	
	/**
	 * OUT
	 */
	
	
	/**API Error Flag*/
	private String cErrorFlag;
	
	/**API Error Description*/
	private String szErrorDescription;
	
	/**Interface 번호*/
	private String szT5IFNO;
	
	/**Interface 유형*/
	private String szT5IFTP;
	
	/**Interface 라인번호*/
	private String szT5IFLN;
	
	/**Error 순번*/
	private String szDLLJ;
	
	/**Error 내역*/
	private String szT5ERDL;
	

	
}//end class()
