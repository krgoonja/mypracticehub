package com.sorincorp.api.erp.comm.constant;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * ErpAcntTrnsmitConstant.java
 * ERP 계정 송신 공통 Constant.java
 * 
 * @version
 * @since 2021. 10. 5.
 * @author srec0054
 */
@Slf4j
public class ErpAcntTrnsmitConstant {

	private ErpAcntTrnsmitConstant() {
		log.debug(ErpAcntTrnsmitConstant.class.getSimpleName());
	}
	
	/**RESULT*/
	public static final String SUCCESS_RESULT_CODE	= "200";
	public static final String ERROR_RESULT_CODE 	= "500";
	public static final String SUCCESS_RESULT_MSG 	= "Success";
	public static final String ERROR_RESULT_MSG 	= "Error";
	public static final String ALL_PART_AT_Y		= "Y";
	public static final String ALL_PART_AT_N		= "N";
	
	/**인터페이스 ID*/
	public static final String ERP_ACNT_TRNSMIT_IF_117 	= "SOREC-IF-117";	//상품매출(내수EC) ERP계정 송신
	public static final String ERP_ACNT_TRNSMIT_IF_118 	= "SOREC-IF-118";	//판관비(지급수수료) ERP계정 송신
	public static final String ERP_ACNT_TRNSMIT_IF_119 	= "SOREC-IF-119";	//판관비(물류비) ERP계정 송신
	public static final String ERP_ACNT_TRNSMIT_IF_120 	= "SOREC-IF-120";	//잡이익 ERP계정 송신
	public static final String ERP_ACNT_TRNSMIT_IF_121 	= "SOREC-IF-121";	//배송비 ERP계정 송신
	public static final String ERP_ACNT_TRNSMIT_IF_122 	= "SOREC-IF-122";	//재고조정 ERP계정 송신
	
	/**채번*/
	public static final String JOB_SE 					= "OR";					//업무구분
	public static final String ERP_INTRFC_NO 			= "INTRFC_NO";			//인터페이스 번호
	public static final String ERP_EXCCLC_SN 			= "EXCCLC_SN";			//정산 순번
	public static final String ERP_INTRFC_LINE_NO		= "ERP_INTRFC_LINE_NO";	//ERP 인터페이스 라인 번호 
	public static final String SYSTEM 					= "SYSTEM";				//등록자
	
	/**JDE API*/
	public static final String OPEN_JDE 				= "OpenJDE";
	public static final String OPEN_JDE_FOR_STOCK		= "OpenJDEforStock";
	public static final String EDIT_F55TD01JDE			= "EditF55TD01JDE";
	public static final String STOCK_ADJUSTMENT			= "InsertF55TD01forStockAdjustment";
	public static final String CLOSE_JDE				= "CloseJDE";
	public static final String CLOSE_JDE_FOR_STOCK		= "CloseJDEforStock";
	public static final String SELECT_F55TD01_JDE		= "SelectF55TD01JDE";
	public static final String SELECT_F55TD02_JDE		= "SelectF55TD02JDE";
	
	
	/**ERP 연동 정보*/
	public static final String FUNCTION_PARAM					= "functionParam";
	public static final String FUNCTION_NAME					= "functionName";
	public static final String URL 								= "url";
	public static final String REQUEST_OBJ 						= "requestObj";
	public static final String OUTPUT 							= "output";
	public static final String RESPONSE_CODE 					= "responseCode";
	public static final String RESULT_MESSAGE 					= "resultMessage";
	public static final String RESPONSE_CODE_MINUS_1			= "-1";

	/**IF_ERP*/
	public static final String ORDER_TY							= "S9"; 			//오더 유형 (S9 : 이커머스 내수 판매)
	public static final String ORDER_TY_SI						= "SI"; 			//오더 유형 (SI : 이커머스 인천영업소 판매)
	public static final String ORDER_TY_SP						= "SP"; 			//오더 유형 (SP : 이커머스 부산영업소 판매)
	public static final String BPLC								= "110";			//사업장
	public static final String ERN_BSNS_UNIT					= "14060";			//수익 사업 단위 - 본사 (14060)
	public static final String ERN_BSNS_UNIT_SI					= "20310";			//수익 사업 단위 - 인천영업소(20310)
	public static final String ERN_BSNS_UNIT_SP					= "20210";			//수익 사업 단위 - 부산영업소(20210)
	public static final String CRNCY_CODE 						= "KRW";			//통화 코드
	public static final String CMPNY_CODE 						= "00001";			//회사 (케이지트레이딩 ERP 코드)
	public static final String CRTR_ERP_ACNT 					= "STSDJCUSR"; 		//생성자 ERP 계정
	
	/**JDE*/
	public static final String C_TARGET_TABLE 					= "cTargetTable";	//구분 (1(F55TD01) / 2(F55TD03))
	public static final String SZ_T5IFTP 						= "szT5IFTP";		//Interface 유형
	public static final String SZ_T5SYSC 						= "szT5SYSC"; 		//Interface System Code	(SECS)
	public static final String SZ_USER 							= "szUSER";			//사용자
	public static final String SZ_T5TDPID 						= "szT5TDPID"; 		//Geust System Program ID
	public static final String MN_T5JNO 						= "mnT5JNO";		//JOB ID
	public static final String C_RUNNING_FLAG 					= "cRunningFlag";	//N55TD01 실행여부 1(Run) / 2(Not run)
	public static final String SECS								= "SECS";			//ERP 인터페이스 시스템 코드
	public static final String JDE_1							= "1";
	public static final String MN_T5INDEX						= "mnT5INDEX";		//Index Case
	
	/**업무 구분*/
	public static final String ORDER	= "ORDER";		//주문 (매출)
	public static final String WT		= "WT";			//중량 (수정)
	public static final String CANCL	= "CANCL";		//취소
	public static final String RTNGUD	= "RTNGUD";		//반품
	public static final String EXCHNG	= "EXCHNG";		//교환
	public static final String JOB		= "JOB";		//잡이익
	public static final String CANCLWT	= "CANCLWT";	//중량 역처리
	public static final String DLVRF	= "DLVRF";		//배송비

	public static final String INVNTRY	= "INVNTRY";			//재고조정
	public static final String CANCLINVNTRY	= "CANCLINVNTRY";	//재고조정 역처리
	
	public static final String JOB_SE_01	= "01";		//주문 (매출), 재고조정
	public static final String JOB_SE_02	= "02";		//중량 (수정), 재고조정역처리
	public static final String JOB_SE_03	= "03";		//취소
	public static final String JOB_SE_04	= "04";		//교환
	public static final String JOB_SE_05	= "05";		//반품
	public static final String JOB_SE_06	= "06";		//잡이익
	public static final String JOB_SE_07	= "07";		//중량 역처리
	public static final String JOB_SE_08	= "08";		//배송비
	public static final String JOB_SE_CEP	= "CEP";	//비용
	
	/**IF Code(UDC) 인터페이스 유형*/
	public static final String INTERFACE_TYPE_CSU = "CSU";	//판매마감
	public static final String INTERFACE_TYPE_CWS = "CWS";	//판매중량정산	 
	public static final String INTERFACE_TYPE_RSU = "RSU";	//판매마감 역처리  
	public static final String INTERFACE_TYPE_RWS = "RWS";	//판매중량정산 역처리
	public static final String INTERFACE_TYPE_CEP = "CEP";	//비용전표생성
	public static final String INTERFACE_TYPE_JOB = "CER";	//잡이익 (미정)
	public static final String INTERFACE_TYPE_CSI = "CSI";	//물품대
	public static final String INTERFACE_TYPE_CSB = "CSB";	//배송비
	public static final String INTERFACE_TYPE_ADJ = "ADJ";	//재고조정
	
	/**BalanceType(UDC)*/
	public static final String PV		= "PV";			//매출
	public static final String WC		= "WC";			//수정매출
	public static final String FN		= "FN";			//배송비
	public static final String AP		= "AP";			//EP(부대비용) - AP
	public static final String GL		= "GL";			//EP(부대비용) - GL
	
	/**EC 비용 코드*/
	public static final String EC_CT_CDOE_001 	= "001";	//상/하차료
	public static final String EC_CT_CDOE_002 	= "002";	//조작료
	public static final String EC_CT_CDOE_003 	= "003";	//보관비
	public static final String EC_CT_CDOE_004 	= "004";	//운송비
	public static final String EC_CT_CDOE_005 	= "005";	//할증비
	public static final String EC_CT_CDOE_006 	= "006";	//검수료
	public static final String EC_CT_CDOE_007 	= "007";	//기타비용
	public static final String EC_CT_CDOE_008 	= "008";	//추가운송비
	
	/**ERP 비용 코드*/
	public static final String ERP_CT_CODE_S101 = "S101";	//해상운송료
	public static final String ERP_CT_CODE_S102 = "S102";	//THC
	public static final String ERP_CT_CODE_S103 = "S103";	//CFS Charge
	public static final String ERP_CT_CODE_S104 = "S104";	//Demurrage
	public static final String ERP_CT_CODE_S199 = "S199";	//해상운송료(기타)
	public static final String ERP_CT_CODE_S201 = "S201";	//내륙운송료
	public static final String ERP_CT_CODE_S299 = "S299";	//내륙운송료(기타)
	public static final String ERP_CT_CODE_S301 = "S301";	//창고료
	public static final String ERP_CT_CODE_S401 = "S401";	//환가료
	public static final String ERP_CT_CODE_S402 = "S402";	//포페이팅비용
	public static final String ERP_CT_CODE_S403 = "S403";	//입금지연이자
	public static final String ERP_CT_CODE_S404 = "S404";	//은행이자
	public static final String ERP_CT_CODE_S405 = "S405";	//입금수수료
	public static final String ERP_CT_CODE_S406 = "S406";	//LESS CHARGE
	public static final String ERP_CT_CODE_S499 = "S499";	//은행제비(기타)
	public static final String ERP_CT_CODE_S501 = "S501";	//통관수수료
	public static final String ERP_CT_CODE_S601 = "S601";	//수출보험료
	public static final String ERP_CT_CODE_S701 = "S701";	//적하보험료
	public static final String ERP_CT_CODE_S801 = "S801";	//매출채권할인비용
	
	/**ETC*/
	public static final String RETURN_ZERO 		= "0";
	public static final String RETURN_ONE 		= "1";
	public static final String RETURN_TWO 		= "2";
	public static final String GL_CLASS			= "M";
	public static final String USER_NM			= "SECUSER";		//사용자
	
	/**취소교환반품 유형, 코드*/
	public static final String CANCL_TY_CODE	= "01";		//취소
	public static final String RTNGUD_TY_CODE	= "02";		//반품
	public static final String EXCHNG_TY_CODE	= "03";		//교환
	public static final String CANCL_TY			= "취소";
	public static final String EXCHNG_TY		= "교환";
	public static final String RTNGUD_TY		= "반품";
}//end class()

