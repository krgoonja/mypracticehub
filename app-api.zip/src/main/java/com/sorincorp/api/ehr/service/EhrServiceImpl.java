package com.sorincorp.api.ehr.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.ehr.comm.EhrConstants;
import com.sorincorp.api.ehr.mapper.EhrMapper;
import com.sorincorp.api.ehr.model.EhrVO;
import com.sorincorp.comm.btb.comm.BtoBConstants;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBReqEntity;
import com.sorincorp.comm.btb.model.BtoBResEntity;
import com.sorincorp.comm.util.CryptoUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EhrServiceImpl implements EhrService{

	@Autowired
	private EhrMapper ehrMapper;

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Override

	public BtoBResEntity sampleCall(EhrVO reqEntity) throws Exception {
		BtoBReqEntity sampleEntity = new BtoBReqEntity();

		/* 타겟 시스텡 Setting ( EHR만 필수 )*/
		sampleEntity.setTargetSys(BtoBConstants.BTB_EHR_SYSTEM);

		/* 인터페이스 ID Setting */
		sampleEntity.setInterfaceId(reqEntity.getInterfaceId());

		/* request Setting */
		Map<String, Object> sampleRequestMap = new HashMap<String, Object>();
		sampleRequestMap.put("price", 10000);
		sampleEntity.setRequest(sampleRequestMap);

		/* 호출 */
		BtoBResEntity resEntity = httpClientHelper.callApi(sampleEntity);

		if(!StringUtils.equals(resEntity.getResultcode(), BtoBConstants.BTOB_CNI_SUCCESS_CODE)) {
			/* 에러 발생 */
		}

		/* 데이터 캐스팅 */
		Map<String, Object> response= (Map<String, Object>)resEntity.getResponse();

		return resEntity;
	}

	@Override
	public void updateCom(EhrVO ehrVo) throws Exception {

		BtoBResEntity resEntity = httpClientHelper.callApi(new BtoBReqEntity(BtoBConstants.BTB_EHR_SYSTEM, ehrVo.getInterfaceId()));

		/* 모듈 에러 발생 */
		if(StringUtils.equals(resEntity.getResultcode(), BtoBConstants.BTOB_HELPER_ERROR_CODE)) {
			log.error(resEntity.getMessage());
			return;
		}

		if(resEntity.getResponse() != null) {

			Map<String,Object> comMap = (Map<String, Object>) resEntity.getResponse();

			List<Map<String,Object>> comList = (List<Map<String,Object>>)comMap.get(EhrConstants.EHR_REPONSE_RESULT_DATA);

			for(Map<String,Object> comDetail : comList) {
				comDetail.put(EhrConstants.INTRFC_NO, resEntity.getIntrfcNo());
				comDetail.put(EhrConstants.INTRFC_ID, ehrVo.getInterfaceId());

				ehrMapper.updateCom(comDetail);
				ehrMapper.insertIfCprBas(comDetail);
			}
			ehrMapper.deleteCom(resEntity.getIntrfcNo());
		}

	}

	@Override
	public void updateBU(EhrVO ehrVo) throws Exception {

		BtoBResEntity resEntity = httpClientHelper.callApi(new BtoBReqEntity(BtoBConstants.BTB_EHR_SYSTEM, ehrVo.getInterfaceId()));

		/* 모듈 에러 발생 */
		if(StringUtils.equals(resEntity.getResultcode(), BtoBConstants.BTOB_HELPER_ERROR_CODE)) {
			log.error(resEntity.getMessage());
			return;
		}

		if(resEntity.getResponse() != null) {

			Map<String,Object> buMap = (Map<String, Object>) resEntity.getResponse();

			List<Map<String,Object>> buList = (List<Map<String,Object>>)buMap.get(EhrConstants.EHR_REPONSE_RESULT_DATA);

			for(Map<String,Object> buDetail : buList) {
				buDetail.put(EhrConstants.INTRFC_NO, resEntity.getIntrfcNo());
				buDetail.put(EhrConstants.INTRFC_ID, ehrVo.getInterfaceId());

				ehrMapper.updateBU(buDetail);
				ehrMapper.insertIfBplcBas(buDetail);
			}
			ehrMapper.deleteBU(resEntity.getIntrfcNo());

		}
	}

	@Override
	public void updateDept(EhrVO ehrVo) throws Exception {

		String interfaceId = ehrVo.getInterfaceId();
		BtoBResEntity resEntity = httpClientHelper.callApi(new BtoBReqEntity(BtoBConstants.BTB_EHR_SYSTEM, interfaceId));

		/* 모듈 에러 발생 */
		if(StringUtils.equals(resEntity.getResultcode(), BtoBConstants.BTOB_HELPER_ERROR_CODE)) {
			log.error(resEntity.getMessage());
			return;
		}

		if(resEntity.getResponse() != null) {

			Map<String,Object> deptMap = (Map<String, Object>) resEntity.getResponse();

			List<Map<String,Object>> deptList = (List<Map<String,Object>>)deptMap.get(EhrConstants.EHR_REPONSE_RESULT_DATA);

			for(Map<String,Object> deptDetail : deptList) {
				deptDetail.put(EhrConstants.INTRFC_NO, resEntity.getIntrfcNo());
				deptDetail.put(EhrConstants.INTRFC_ID, ehrVo.getInterfaceId());

				ehrMapper.updateDept(deptDetail);
				ehrMapper.insertIfDeptBas(deptDetail);
			}
			ehrMapper.deleteDept(resEntity.getIntrfcNo());
		}

	}

	@Override
	public void updateSecond(EhrVO ehrVo) throws Exception {

		String interfaceId = ehrVo.getInterfaceId();
		BtoBResEntity resEntity = httpClientHelper.callApi(new BtoBReqEntity(BtoBConstants.BTB_EHR_SYSTEM, interfaceId));

		/* 모듈 에러 발생 */
		if(StringUtils.equals(resEntity.getResultcode(), BtoBConstants.BTOB_HELPER_ERROR_CODE)) {
			log.error(resEntity.getMessage());
			return;
		}

		if(resEntity.getResponse() != null) {

			Map<String,Object> secondMap = (Map<String, Object>) resEntity.getResponse();

			List<Map<String,Object>> secondList = (List<Map<String,Object>>)secondMap.get(EhrConstants.EHR_REPONSE_RESULT_DATA);

			for(Map<String,Object> secondDetail : secondList) {
				secondDetail.put(EhrConstants.INTRFC_NO, resEntity.getIntrfcNo());
				secondDetail.put(EhrConstants.INTRFC_ID, ehrVo.getInterfaceId());

				ehrMapper.updateSecond(secondDetail);
				ehrMapper.insertIfCtsBas(secondDetail);
			}
			ehrMapper.deleteSecond(resEntity.getIntrfcNo());
		}

	}

	@Override
	public void updateDuty(EhrVO ehrVo) throws Exception {

		String interfaceId = ehrVo.getInterfaceId();
		BtoBResEntity resEntity = httpClientHelper.callApi(new BtoBReqEntity(BtoBConstants.BTB_EHR_SYSTEM, interfaceId));

		/* 모듈 에러 발생 */
		if(StringUtils.equals(resEntity.getResultcode(), BtoBConstants.BTOB_HELPER_ERROR_CODE)) {
			log.error(resEntity.getMessage());
			return;
		}

		if(resEntity.getResponse() != null) {

			Map<String,Object> dutyMap = (Map<String, Object>) resEntity.getResponse();

			List<Map<String,Object>> dutyList = (List<Map<String,Object>>)dutyMap.get(EhrConstants.EHR_REPONSE_RESULT_DATA);

			for(Map<String,Object> dutyDetail : dutyList) {
				dutyDetail.put(EhrConstants.INTRFC_NO, resEntity.getIntrfcNo());
				dutyDetail.put(EhrConstants.INTRFC_ID, ehrVo.getInterfaceId());

				ehrMapper.updateDuty(dutyDetail);
				ehrMapper.insertIfRspofcBas(dutyDetail);
			}
			ehrMapper.deleteDuty(resEntity.getIntrfcNo());
		}

	}

	@Override
	public void updatePosition(EhrVO ehrVo) throws Exception {

		String interfaceId = ehrVo.getInterfaceId();
		BtoBResEntity resEntity = httpClientHelper.callApi(new BtoBReqEntity(BtoBConstants.BTB_EHR_SYSTEM, interfaceId));

		/* 모듈 에러 발생 */
		if(StringUtils.equals(resEntity.getResultcode(), BtoBConstants.BTOB_HELPER_ERROR_CODE)) {
			log.error(resEntity.getMessage());
			return;
		}

		if(resEntity.getResponse() != null) {

			Map<String,Object> positionMap = (Map<String, Object>) resEntity.getResponse();

			List<Map<String,Object>> positionList = (List<Map<String,Object>>)positionMap.get(EhrConstants.EHR_REPONSE_RESULT_DATA);

			for(Map<String,Object> positionDetail : positionList) {
				positionDetail.put(EhrConstants.INTRFC_NO, resEntity.getIntrfcNo());
				positionDetail.put(EhrConstants.INTRFC_ID, ehrVo.getInterfaceId());

				ehrMapper.updatePosition(positionDetail);
				ehrMapper.insertIfOfcpsBas(positionDetail);
			}
			ehrMapper.deletePosition(resEntity.getIntrfcNo());
		}

	}

	@Override
	public void updateRank(EhrVO ehrVo) throws Exception {

		String interfaceId = ehrVo.getInterfaceId();
		BtoBResEntity resEntity = httpClientHelper.callApi(new BtoBReqEntity(BtoBConstants.BTB_EHR_SYSTEM, interfaceId));

		/* 모듈 에러 발생 */
		if(StringUtils.equals(resEntity.getResultcode(), BtoBConstants.BTOB_HELPER_ERROR_CODE)) {
			log.error(resEntity.getMessage());
			return;
		}

		if(resEntity.getResponse() != null) {

			Map<String,Object> rankMap = (Map<String, Object>) resEntity.getResponse();

			List<Map<String,Object>> rankList = (List<Map<String,Object>>)rankMap.get(EhrConstants.EHR_REPONSE_RESULT_DATA);

			for(Map<String,Object> rankDetail : rankList) {
				rankDetail.put(EhrConstants.INTRFC_NO, resEntity.getIntrfcNo());
				rankDetail.put(EhrConstants.INTRFC_ID, ehrVo.getInterfaceId());

				ehrMapper.updateRank(rankDetail);
				ehrMapper.insertIfClsfBas(rankDetail);
			}

			ehrMapper.deleteRank(resEntity.getIntrfcNo());
		}

	}

	@Override
	public void updateEmp(EhrVO ehrVo) throws Exception {

		String interfaceId = ehrVo.getInterfaceId();
		BtoBResEntity resEntity = httpClientHelper.callApi(new BtoBReqEntity(BtoBConstants.BTB_EHR_SYSTEM, interfaceId));

		/* 모듈 에러 발생 */
		if(StringUtils.equals(resEntity.getResultcode(), BtoBConstants.BTOB_HELPER_ERROR_CODE)) {
			log.error(resEntity.getMessage());
			return;
		}

		if(resEntity.getResponse() != null) {

			Map<String,Object> empMap = (Map<String, Object>) resEntity.getResponse();

			List<Map<String,Object>> empList = (List<Map<String,Object>>)empMap.get(EhrConstants.EHR_REPONSE_RESULT_DATA);

			for(Map<String,Object> empDetail : empList) {
				empDetail.put(EhrConstants.INTRFC_NO, resEntity.getIntrfcNo());
				empDetail.put(EhrConstants.INTRFC_ID, ehrVo.getInterfaceId());

				Object cellPhone = empDetail.get("CELL_PHONE");

				if (cellPhone != null && StringUtils.isNotBlank(cellPhone.toString())) {
					empDetail.replace("CELL_PHONE", CryptoUtil.encryptAES256(cellPhone.toString().replace("-", "")));	//암호화
				}

				ehrMapper.updateEmp(empDetail);
				ehrMapper.insertIfEmplBas(empDetail);
			}

			ehrMapper.deleteEmp(resEntity.getIntrfcNo());

		}

	}

}
