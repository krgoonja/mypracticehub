package com.sorincorp.api.ehr.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.ehr.comm.EhrConstants;
import com.sorincorp.api.ehr.comm.EhrResponseEntity;
import com.sorincorp.api.ehr.model.EhrVO;
import com.sorincorp.api.ehr.service.EhrService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/api/ehr")
@Api( value = "EHR 연계 Controller")
public class EhrController {

	@Autowired
	private EhrService ehrService;

	/**
	 * <pre>
	 * 처리내용: BTB CNI 샘플
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 21.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param sampleStr
	 * @param ehrVo
	 * @return
	 * @throws Exception
	 */

	@PostMapping("/Com")
	@ApiOperation("법인 정보 전체 조회 API")
	public EhrResponseEntity callCom(@ApiParam(value = "interfaceId 값 저장 VO", required = true) @RequestBody @Valid EhrVO ehrVo,  BindingResult bindingResult) throws Exception{
		if(bindingResult.hasErrors()) {
			return new EhrResponseEntity(EhrConstants.ERROR_CODE, bindingResult.getFieldError().getDefaultMessage(), null);
		}
		ehrService.updateCom(ehrVo);

		return new EhrResponseEntity(EhrConstants.SUCCESS_CODE, EhrConstants.SUCCESS_MSG, null);
	}

	@PostMapping("/BU")
	@ApiOperation("사업장 정보 전체 조회 API")
	public EhrResponseEntity callBU(@ApiParam(value = "interfaceId 값 저장 VO", required = true) @RequestBody @Valid EhrVO ehrVo,  BindingResult bindingResult) throws Exception{
		if(bindingResult.hasErrors()) {
			return new EhrResponseEntity(EhrConstants.ERROR_CODE, bindingResult.getFieldError().getDefaultMessage(), null);
		}
		ehrService.updateBU(ehrVo);

		return new EhrResponseEntity(EhrConstants.SUCCESS_CODE, EhrConstants.SUCCESS_MSG, null);
	}

	@PostMapping("/Dept")
	@ApiOperation("부서 정보 전체 조회 API")
	public EhrResponseEntity callDept(@ApiParam(value = "interfaceId 값 저장 VO", required = true) @RequestBody @Valid EhrVO ehrVo,  BindingResult bindingResult) throws Exception{
		if(bindingResult.hasErrors()) {
			return new EhrResponseEntity(EhrConstants.ERROR_CODE, bindingResult.getFieldError().getDefaultMessage(), null);
		}
		ehrService.updateDept(ehrVo);

		return new EhrResponseEntity(EhrConstants.SUCCESS_CODE, EhrConstants.SUCCESS_MSG, null);
	}

	@PostMapping("/Second")
	@ApiOperation("겸직 정보 전체 조회 API")
	public EhrResponseEntity callSecond(@ApiParam(value = "interfaceId 값 저장 VO", required = true) @RequestBody @Valid EhrVO ehrVo,  BindingResult bindingResult) throws Exception{
		if(bindingResult.hasErrors()) {
			return new EhrResponseEntity(EhrConstants.ERROR_CODE, bindingResult.getFieldError().getDefaultMessage(), null);
		}
		ehrService.updateSecond(ehrVo);

		return new EhrResponseEntity(EhrConstants.SUCCESS_CODE, EhrConstants.SUCCESS_MSG, null);
	}

	@PostMapping("/Duty")
	@ApiOperation("직책 정보 전체 조회 API")
	public EhrResponseEntity callDuty(@ApiParam(value = "interfaceId 값 저장 VO", required = true) @RequestBody @Valid EhrVO ehrVo,  BindingResult bindingResult) throws Exception{
		if(bindingResult.hasErrors()) {
			return new EhrResponseEntity(EhrConstants.ERROR_CODE, bindingResult.getFieldError().getDefaultMessage(), null);
		}
		ehrService.updateDuty(ehrVo);

		return new EhrResponseEntity(EhrConstants.SUCCESS_CODE, EhrConstants.SUCCESS_MSG, null);
	}

	@PostMapping("/Position")
	@ApiOperation("직위 정보 전체 조회 API")
	public EhrResponseEntity callPosition(@ApiParam(value = "interfaceId 값 저장 VO", required = true) @RequestBody @Valid EhrVO ehrVo,  BindingResult bindingResult) throws Exception{
		if(bindingResult.hasErrors()) {
			return new EhrResponseEntity(EhrConstants.ERROR_CODE, bindingResult.getFieldError().getDefaultMessage(), null);
		}
		ehrService.updatePosition(ehrVo);

		return new EhrResponseEntity(EhrConstants.SUCCESS_CODE, EhrConstants.SUCCESS_MSG, null);
	}

	@PostMapping("/Rank")
	@ApiOperation("직급 정보 전체 조회 API")
	public EhrResponseEntity callRank(@ApiParam(value = "interfaceId 값 저장 VO", required = true) @RequestBody @Valid EhrVO ehrVo,  BindingResult bindingResult) throws Exception{
		if(bindingResult.hasErrors()) {
			return new EhrResponseEntity(EhrConstants.ERROR_CODE, bindingResult.getFieldError().getDefaultMessage(), null);
		}
		ehrService.updateRank(ehrVo);

		return new EhrResponseEntity(EhrConstants.SUCCESS_CODE, EhrConstants.SUCCESS_MSG, null);
	}

	@PostMapping("/Emp")
	@ApiOperation("사용자 정보 전체 조회 API")
	public EhrResponseEntity callEmp(@ApiParam(value = "interfaceId 값 저장 VO", required = true) @RequestBody @Valid EhrVO ehrVo,  BindingResult bindingResult) throws Exception{
		if(bindingResult.hasErrors()) {
			return new EhrResponseEntity(EhrConstants.ERROR_CODE, bindingResult.getFieldError().getDefaultMessage(), null);
		}
		ehrService.updateEmp(ehrVo);

		return new EhrResponseEntity(EhrConstants.SUCCESS_CODE, EhrConstants.SUCCESS_MSG, null);
	}

}
