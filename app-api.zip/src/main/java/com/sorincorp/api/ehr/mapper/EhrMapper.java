package com.sorincorp.api.ehr.mapper;

import java.util.Map;

public interface EhrMapper {

	void deleteCom(int intrfcNo) throws Exception;

	void updateCom(Map<String, Object> comMap) throws Exception;

	void deleteBU(int intrfcNo) throws Exception;

	void updateBU(Map<String, Object> buDetail) throws Exception;

	void deleteDept(int intrfcNo) throws Exception;

	void updateDept(Map<String, Object> deptDetail) throws Exception;

	void deleteSecond(int intrfcNo) throws Exception;

	void updateSecond(Map<String, Object> secondDetail) throws Exception;

	void deleteDuty(int intrfcNo) throws Exception;

	void updateDuty(Map<String, Object> dutyDetail) throws Exception;

	void deletePosition(int intrfcNo) throws Exception;

	void updatePosition(Map<String, Object> positionDetail) throws Exception;

	void deleteRank(int intrfcNo) throws Exception;

	void updateRank(Map<String, Object> rankDetail) throws Exception;

	void deleteEmp(int intrfcNo) throws Exception;

	void updateEmp(Map<String, Object> empDetail) throws Exception;


	/* 이력 관리 테이블 insert */
	void insertIfCprBas(Map<String, Object> paramMap) throws Exception;
	void insertIfBplcBas(Map<String, Object> paramMap) throws Exception;
	void insertIfDeptBas(Map<String, Object> paramMap) throws Exception;
	void insertIfCtsBas(Map<String, Object> paramMap) throws Exception;
	void insertIfRspofcBas(Map<String, Object> paramMap) throws Exception;
	void insertIfOfcpsBas(Map<String, Object> paramMap) throws Exception;
	void insertIfClsfBas(Map<String, Object> paramMap) throws Exception;
	void insertIfEmplBas(Map<String, Object> paramMap) throws Exception;
}
