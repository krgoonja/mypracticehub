package com.sorincorp.api.ehr.comm;

/**
 * <pre>
 * 처리내용: batch - ehr 패키지의 공통 상수를 관리한다.
 * </pre>
 * EhrConstants.java
 * @version
 * @since 2021. 6. 9.
 * @author Sim sung bo
 * @history
 * ------------------------------------------------
 * 변경일					작성자				변경내용
 * ------------------------------------------------
 * 2021. 6. 8.			Sim sung bo			최초작성
 * ------------------------------------------------
 */
public final class EhrConstants {

	public static final int SUCCESS_CODE = 200;
	public static final int ERROR_CODE = 400;

	public static final String SUCCESS_MSG = "Success";
	public static final String ERROR_MSG = "Error";

	public static final String INTRFC_NO = "INTRFC_NO";
	public static final String INTRFC_ID = "INTRFC_ID";

	public static final String EHR_REPONSE_RESULT_MSG = "result_msg";
	public static final String EHR_REPONSE_RESULT_DATA = "result_data";
	public static final String EHR_REPONSE_RESULT_CODE = "result_code";

}
