package com.sorincorp.api.ehr.model;

import javax.validation.constraints.NotEmpty;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@ApiModel("EHR 호출 VO")
public class EhrVO {

	/* 호출 인터페이스 ID */
	@NotEmpty(message = "Interface ID는 필수 값입니다.")
	@ApiModelProperty(value = "인터페이스 ID", example = "EHR-IF-008")
	private String interfaceId;

	/* 호출 TARGET SYSTEM */
	@ApiModelProperty(value = "타겟 시스템", example = "EHR")
	private String targetSys;

}
