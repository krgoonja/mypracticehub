package com.sorincorp.api.ehr.service;

import com.sorincorp.api.ehr.model.EhrVO;
import com.sorincorp.comm.btb.model.BtoBResEntity;

public interface EhrService {

	/**
	 * <pre>
	 * 처리내용: BTB CNI 샘플
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 21.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param reqEntity
	 * @return
	 * @throws Exception
	 */
	BtoBResEntity sampleCall(EhrVO reqEntity) throws Exception;

	void updateCom(EhrVO ehrVo) throws Exception;

	void updateBU(EhrVO ehrVo) throws Exception;

	void updateDept(EhrVO ehrVo) throws Exception;

	void updateSecond(EhrVO ehrVo) throws Exception;

	void updateDuty(EhrVO ehrVo) throws Exception;

	void updatePosition(EhrVO ehrVo) throws Exception;

	void updateRank(EhrVO ehrVo) throws Exception;

	void updateEmp(EhrVO ehrVo) throws Exception;

}
