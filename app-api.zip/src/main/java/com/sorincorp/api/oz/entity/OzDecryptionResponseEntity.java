package com.sorincorp.api.oz.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OzDecryptionResponseEntity {

	/** 결과 코드 */
	private String responseMsg;
	
	/** 결과 값 */
	private String responseStr;
	
}//end class()
