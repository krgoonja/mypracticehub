package com.sorincorp.api.oz.model;

import java.util.ArrayList;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 매출 증빙자료 출력 Service
 *
 * @version
 * @since 2023. 11. 23.
 * @author sumin
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class SlePrufDtaOutptVO  extends CommonVO {

	private static final long serialVersionUID = 8208425408500028886L;

	/**
	 * Search</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface Search {};

	/**
	 * 기간검색 시작 일자
	 */
	private String searchFromDate;

	/**
	 * approvalKey
	 */
	private String approvalKey;

	/**
	 * 기간검색 종료 일자
	 */
	private String searchToDate;

	/**
	 * 검색
	 */
	private String searchCondition01;

	/**
	 * 기간검색 종료 일자
	 */
	//private String searchCondition03;


	/**
	 * 검색 키워드 (주문번호)
	 */
	private String searchKeyword01;

	/**
	 * 검색 키워드 (전표 발행상태)
	 */
	private String searchKeyword02;

	/**
	 * 검색 키워드
	 */
	private String searchKeyword03;
	
	/**
	 * 검색 키워드 (erpSo)
	 */
	private String searchErpSo;
	
	/**
	 * 검색 키워드 (전기여부)
	 */
	private String searchPostYn;


	/**
	 * row
	*/
	private String rowNum;

	/**
	 * 출력 횟수
	*/
	private String printCounts;

	/**
	 * 결제 방법
	*/
	private String setleMthdNm;

	/**
	 * 주문 입금 배치번호
	*/
	private String orderReceiptBatch;
	
	/**
	 * 주문 입금 상태
	*/
	private String orderReceiptPostyn;
	
	/**
	 * 주문 입금전표
	*/
	private String orderRcpmnySlng;

	/**
	 * 주문 잔금 배치번호
	*/
	private String orderAdvReceiptBatch;
	
	/**
	 * 주문 잔금 상태
	*/
	private String orderAdvReceiptPostyn;
	
	/**
	 * 주문 잔금 입금전표
	*/
	private String orderAdvRcpmnySlng;

	/**
	 * 주문 매출전표 배치번호
	*/
	private String orderSalesBatch;
	
	/**
	 * 주문 매출전표 상태
	*/
	private String orderSalesPostyn;
	
	/**
	 * 주문 매출전표
	*/
	private String orderSalesSlng;

	/**
	 * 정산 입금 배치번호
	*/
	private String excclcReceiptBatch;
	
	/**
	 * 정산 입금 상태
	*/
	private String excclcReceiptPostyn;
	
	/**
	 * 정산 입금전표
	*/
	private String excclcRcpmnySlng;

	/**
	 * 정산 매출 전표 배치번호
	*/
	private String excclcSalesBatch;

	/**
	 * 정산 매출 전표 상태
	*/
	private String excclcSalesPostyn;
	
	/**
	 * 정산 매출 전표
	*/
	private String excclcSalesSlng;
	
	/**
	 * 정산 매출
	*/
	private String excclcSales;
	
	/**
	 * ERP SO
	*/
	private String erpSoNo;

	/**
	 * 주문번호
	*/
	private ArrayList<String> orderNos;

	/**
	 * 주문번호
	*/
	private String orderNo;
	
    /**
	 * 목록 조회 사용 용도 (조회, 엑셀다운로드)
	 */
	private String useMode;


	/**
	 * 결제 방법
	*/
	private String setleMthdCode;

	/**
	 * 정산 타입(1차:01. 2차:02)
	*/
	private String excclcTy;


	/**리포트명*/
    private String sqlQuery;

	/**리포트명*/
    private String reportName;

	/**서류명*/
	private String papersNm;

	/**서류 구분*/
    private String tabDiv;

    /** 주문 정산 구분 코드 01, 02 */
    private String receiptTy;

    /**내용*/
   	private String contents;

	/**상태-이론/탈리*/
    private String sttus;

    /**ozr 파일명*/
	private String ozNm;

	 /**파라미터 설정*/
	private String pCount;


	 /**파라미터 설정*/
	private String fromDate;

	 /**파라미터 설정*/
	private String toDate;

	//private ArrayList<SlePrufDtaOutptVO> paramVoList;

    /**오즈리포트 호출 공통 파라미터*/
    //private String param1;
	//private List<String> param1;
	private String param1;
	private String param2;
    private String param3;
    private String param4;
    private String param5;
    private String param6;
    private String param7;
    private String param8;
    private String param9;
    private String param10;
    private String param11;

    private String paramNm2;
    private String paramNm3;
    private String paramNm4;
    private String paramNm5;

    private String ozFlag;


    /**성적서&패킹리스트*/
    /**BL 번호*/
    private String blNo;

    /**성적서 파일 경로*/
	private String screofeFileCours;

	/**포장 리스트 파일 경로*/
	private String packngListFileCours;

	/**브랜드명*/
    private String brandNm;

	/**날짜정보*/
    private String paperDe;

    /**DB정보 (EC DB, ERP DB)*/
    private String dbAlias;
    private String erpDbAlias;

    private String batchNo;

    /**CSU배치번호*/
    private String csuBatchNo;
    /**CWS배치번호*/
    private String cwsBatchNo;

    /** 최초 등록자 아이디 */
    private String frstRegisterId;

    /** 최초 등록 일시 */
    private String frstRegistDt;

    /** 최종 변경자 아이디 */
    private String lastChangerId;

    /** 최종 변경 일시 */
    private String lastChangeDt;
    
    /** 입금전표 배치번호 */
    private String orderRcpmnyBatch;
    
    /** 선수금 입금전표 배치번호 */
    private String orderEntyRcpmnyBatch;
    
}
