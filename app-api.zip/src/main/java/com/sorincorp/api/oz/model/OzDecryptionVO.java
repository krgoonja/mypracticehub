package com.sorincorp.api.oz.model;

import lombok.Data;

@Data
public class OzDecryptionVO {

	private String orderNum;

	private String wrhousCode;

	private String blNo;

}//end class()
