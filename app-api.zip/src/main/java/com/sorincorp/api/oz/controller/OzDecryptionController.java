package com.sorincorp.api.oz.controller;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.api.oz.model.OzDecryptionVO;
import com.sorincorp.api.oz.model.SlePrufDtaOutptVO;
import com.sorincorp.api.oz.service.OzDecryptionService;
import com.sorincorp.api.oz.service.UnityOrderDetailService;
import com.sorincorp.comm.util.CryptoUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/api/oz")
@Api("오즈리포트 복호화")
public class OzDecryptionController {

	@Autowired
	private UnityOrderDetailService unityOrderDetailService;

	@Value("${oz.connection.reportname}")
	private String reportName;

	@Value("${oz.db.alias}")
	private String dbAlias;

	@Value("${oz.erpDb.alias}")
	private String erpDbAlias;

	@Autowired
	private OzDecryptionService ozDecryptionService;

	@RequestMapping("/Decryption")
	@ApiOperation(value = "오즈리포트 복호화", notes = "오즈리포트 복호화")
	public ResponseEntity<?> ozDecryption(OzDecryptionVO ozDecryptionVo, HttpServletRequest req) throws Exception {

		String ip 			= getClientIP(req);	//오즈리포트 복호화 API request 요청 IP 조회
		String rtnXml 		= "" ;				//OZ server return XML String
		HttpStatus status 	= HttpStatus.OK;

		log.debug("ozDecryptionVo = " + ozDecryptionVo.toString());

			if (ozDecryptionVo != null
					&& StringUtils.isNotBlank(ozDecryptionVo.getOrderNum())		// 주문 번호
					&& StringUtils.isNotBlank(ozDecryptionVo.getWrhousCode())	// 창고 코드
					&& StringUtils.isNotBlank(ozDecryptionVo.getBlNo())			// blNo
				) {

				rtnXml = ozDecryptionService.executeConvertToOzReportXml(ozDecryptionVo);

				if(StringUtils.isEmpty(rtnXml)) status = HttpStatus.BAD_REQUEST;
			//EC_changegld_Cnfrmn 계좌번호 복호화
			}else if(ozDecryptionVo != null 
					&& StringUtils.isNotBlank(ozDecryptionVo.getOrderNum())
					)	{	// 주문 번호
				rtnXml = ozDecryptionService.ewalletExecuteConvertToOzReportXml(ozDecryptionVo);
				
				if(StringUtils.isEmpty(rtnXml)) status = HttpStatus.BAD_REQUEST;
			}//end if()

//		} else {
//			status = HttpStatus.BAD_REQUEST;
//		}//end if()


		log.debug("rtnXml = " + rtnXml);
		return (ResponseEntity<?>) ResponseEntity.status(status).body(rtnXml);
	}//end ozDecryption()


	public String getClientIP(HttpServletRequest request) {
		String ip = request.getHeader("X-Forwarded-For");
	    log.debug("> X-FORWARDED-FOR : " + ip);

	    if (ip == null) {
	        ip = request.getHeader("Proxy-Client-IP");
	        log.debug("> Proxy-Client-IP : " + ip);
	    }
	    if (ip == null) {
	        ip = request.getHeader("WL-Proxy-Client-IP");
	        log.debug("> WL-Proxy-Client-IP : " + ip);
	    }
	    if (ip == null) {
	        ip = request.getHeader("HTTP_CLIENT_IP");
	        log.debug("> HTTP_CLIENT_IP : " + ip);
	    }
	    if (ip == null) {
	        ip = request.getHeader("HTTP_X_FORWARDED_FOR");
	        log.debug("> HTTP_X_FORWARDED_FOR : " + ip);
	    }
	    if (ip == null) {
	        ip = request.getRemoteAddr();
	        log.debug("> getRemoteAddr : "+ip);
	    }
	    log.debug("> Result : IP Address : "+ip);

	    return ip;
	}//end getClientIP

	/**
	 * <pre>
	 * 처리내용: OZ리포트 외부 접속 메소드.
	 * </pre>
	 *
	 * @date 2024. 07. 26.
	 * @author hanjook
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 07. 26.		hanjook		최초작성
	 * -------------------------------------------------------------------------
	 * @param session
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/relatePapersOzReport")
	public String relatePapersOzReport(HttpSession session, ModelMap model, HttpServletRequest request) throws Exception {
		log.debug("UnityOrderDetailController::relatePapersOzReport Start");

		SlePrufDtaOutptVO paramVo = new SlePrufDtaOutptVO();
		Map<String, String> paramMap = new HashMap<>();

		paramVo.setReportName(reportName);
		paramVo.setDbAlias(dbAlias);
		paramVo.setErpDbAlias(erpDbAlias);

		try {
			String[] param = URLDecoder.decode(CryptoUtil.decryptAES(request.getParameter("param").replace(" ", "+")), "UTF-8").split("&");

			for(String p : param) {
				if(p != null && !p.isEmpty() && !p.endsWith("=")) {
					paramMap.put(p.split("=")[0], p.split("=")[1]);
				}
			}

			/* url param -> paramVo 세팅 */
			paramVo.setOrderNo(paramMap.get("orderNo"));
			paramVo.setCsuBatchNo(paramMap.get("csuBatchNo"));
			paramVo.setCwsBatchNo(paramMap.get("cwsBatchNo"));
			paramVo.setOrderRcpmnyBatch(paramMap.get("orderRcpmnyBatch"));
			paramVo.setExcclcRcpmnySlng(paramMap.get("excclcRcpmnySlng"));
			paramVo.setOrderEntyRcpmnyBatch(paramMap.get("orderEntyRcpmnyBatch"));
			paramVo.setApprovalKey(paramMap.get("approvalKey"));

			List<SlePrufDtaOutptVO> slePrufDataList = unityOrderDetailService.getSlePrufDtaOutptList(paramVo);
			List<Map<String, Object>> paramList = new ArrayList<>();

			for(SlePrufDtaOutptVO relatePapersInfo : slePrufDataList) {
				//평균가 견적서, 평균가 계약서가 아닐 경우
				if(!("prqudo".equals(relatePapersInfo.getTabDiv())||"ctrtc".equals(relatePapersInfo.getTabDiv()))){
					log.debug("param1 		= " + paramMap.get("param1"));
					log.debug("param2 		= " + paramMap.get("param2"));
					log.debug("param3 		= " + paramMap.get("param3"));
					log.debug("param4 		= " + paramMap.get("param4"));
					log.debug("param5 		= " + paramMap.get("param5"));
					log.debug("param6 		= " + paramMap.get("param6"));
					log.debug("param7 		= " + paramMap.get("param7"));
					log.debug("param8 		= " + paramMap.get("param8"));
					log.debug("param9 		= " + paramMap.get("param9"));
					log.debug("param10 		= " + paramMap.get("param10"));
					log.debug("param11 		= " + paramMap.get("param11"));
					log.debug("tabDiv 		= " + paramMap.get("tabDiv"));
					log.debug("reportName 	= " + reportName);
					log.debug("dbAlias 		= " + dbAlias);
					log.debug("erpDbAlias 	= " + erpDbAlias);

					Map<String, Object> map = new HashMap<>();

					String frghtAddrseMoblphonNo = "";

					/**2022-04-19 추가 수정*/
					//출고지시서인 경우
					if(StringUtils.equals("instr", relatePapersInfo.getTabDiv()) || StringUtils.equals("tax_selng_sle", relatePapersInfo.getTabDiv())) {
						//출고지시서 화물수취인 전화번호 복호화
						frghtAddrseMoblphonNo = unityOrderDetailService.updateMoblphonNoDecryption(relatePapersInfo);
					//입금증빙 경우
					} else if(StringUtils.equals("rcptPruf", relatePapersInfo.getTabDiv())) {
						String ewalletAcnutNo = unityOrderDetailService.getEwalletAcnutNo(relatePapersInfo.getParam1());
						relatePapersInfo.setParam2(ewalletAcnutNo);
						log.debug(" 계좌번호 복호화 후 ===========> " + ewalletAcnutNo);
					}

					map.put("PAPERSNM"		, relatePapersInfo.getPapersNm());
					map.put("OZNM"			, relatePapersInfo.getOzNm());
					map.put("PCOUNT"		, relatePapersInfo.getPCount());
					map.put("PARAM1"		, relatePapersInfo.getParam1());
					map.put("PARAMNM2"		, relatePapersInfo.getParamNm2());
					map.put("PARAM2"		, relatePapersInfo.getParam2());
					map.put("PARAMNM3"		, relatePapersInfo.getParamNm3());
					map.put("PARAM3"		, relatePapersInfo.getParam3());
					map.put("PARAMNM4"		, relatePapersInfo.getParamNm4());
					map.put("PARAM4"		, relatePapersInfo.getParam4());
					map.put("PARAMNM5"		, relatePapersInfo.getParamNm5());
					map.put("PARAM5"		, relatePapersInfo.getParam5());
					map.put("PARAM6"		, relatePapersInfo.getParam6());
					map.put("PHONE_NO"	    , frghtAddrseMoblphonNo);
					map.put("TAB_DIV"	    , relatePapersInfo.getTabDiv());
					map.put("RECEIPT_TY"	, relatePapersInfo.getReceiptTy());
					map.put("DB_ALIAS"	    , relatePapersInfo.getDbAlias());
					paramList.add(map);
				}
			}
			// 관련서류 - 일괄출력 구분
			String flag = "all_slePrufOzReport";
			model.addAttribute("flag", flag);

			ObjectMapper objectMapper = new ObjectMapper();
			String paramListJson = objectMapper.writeValueAsString(paramList);

			model.addAttribute("paramListJson", paramListJson);
			model.addAttribute("REPORT_NAME"  , reportName);
			model.addAttribute("DB_ALIAS"	  , dbAlias);
			model.addAttribute("ERP_DB_ALIAS" , erpDbAlias);
			model.addAttribute("APPROVAL_KEY" , paramMap.get("approvalKey"));

		} catch (Exception e) {
			log.error("UnityOrderDetailController::relatePapersOzReport exception = " + e.getMessage());
			throw new Exception(e.getMessage());
		}

		log.debug("UnityOrderDetailController::relatePapersOzReport End");
		return "oz/relatePapersOzReport";
	}

	/**
	 * <pre>
	 * 처리내용: 전자증빙 매출전표 개별 호츌
	 * </pre>
	 *
	 * @date 2024. 09. 12.
	 * @author sumin
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 09. 12.			sumin				최초작성
	 * -------------------------------------------------------------------------
	 * @param session
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/salesSlngOzReport")
	public String salesSlngOzReport(HttpSession session, ModelMap model, HttpServletRequest request) throws Exception {
		log.debug("OzDecryptionController::salesSlngOzReport Start");
		try {
			SlePrufDtaOutptVO paramVo = new SlePrufDtaOutptVO();

			paramVo.setDbAlias(dbAlias);
			paramVo.setErpDbAlias(erpDbAlias);

			model.addAttribute("PARAM2", request.getParameter("param"));
			model.addAttribute("flag", "salesSlng");
			model.addAttribute("DB_ALIAS"	  , dbAlias);
			model.addAttribute("ERP_DB_ALIAS" , erpDbAlias);

		} catch (Exception e) {
			log.error("OzDecryptionController::salesSlngOzReport exception = " + e.getMessage());
			throw new Exception(e.getMessage());
		}

		log.debug("OzDecryptionController::salesSlngOzReport End");
		return "oz/relatePapersOzReport";
	}

	/**
	 * 출력 횟수를 입력한다.
	 */
	@PostMapping("/insertSlePrufDtaPrintCnt")
	public ResponseEntity<?> insertSlePrufDtaPrintCnt(@RequestBody SlePrufDtaOutptVO slePrufDtaOutptVO, BindingResult bindingResult) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		// 주문 진행 상태를 변경한다.
		int insertSlePrufDtaPrintCnt = unityOrderDetailService.insertSlePrufDtaPrintCnt(slePrufDtaOutptVO);

		log.debug(">> insertSlePrufDtaPrintCnt : " + insertSlePrufDtaPrintCnt);

		map.put("insertCnt", insertSlePrufDtaPrintCnt);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 전자증빙 입금전표 개별 호츌
	 * </pre>
	 *
	 * @date 2024. 09. 25.
	 * @author hanjook
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 09. 25.			hanjook				최초작성
	 * -------------------------------------------------------------------------
	 * @param session
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/rcpmnyrOzReport")
	public String rcpmnyrOzReport(HttpSession session, ModelMap model, HttpServletRequest request) throws Exception {
		log.debug("OzDecryptionController::rcpmnyrOzReport Start");
		try {
			SlePrufDtaOutptVO paramVo = new SlePrufDtaOutptVO();

			paramVo.setDbAlias(dbAlias);
			paramVo.setErpDbAlias(erpDbAlias);

			model.addAttribute("PARAM2", request.getParameter("param"));
			model.addAttribute("flag", "rcpmnyr");
			model.addAttribute("DB_ALIAS"	  , dbAlias);
			model.addAttribute("ERP_DB_ALIAS" , erpDbAlias);

		} catch (Exception e) {
			log.error("OzDecryptionController::rcpmnyrOzReport exception = " + e.getMessage());
			throw new Exception(e.getMessage());
		}

		log.debug("OzDecryptionController::rcpmnyrOzReport End");
		return "oz/relatePapersOzReport";
	}
}//end class()
