package com.sorincorp.api.oz.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.oz.mapper.UnityOrderDetailMapper;
import com.sorincorp.api.oz.model.SlePrufDtaOutptVO;
import com.sorincorp.api.oz.model.UnityOrderPapersVO;
import com.sorincorp.comm.util.CryptoUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 통합주문상세 Service 구현체 클래스
 *
 * @version
 * @since 2021. 7. 19.
 * @author srec0049
 */
@Slf4j
@Service
public class UnityOrderDetailServiceImpl implements UnityOrderDetailService {

     @Autowired
    private UnityOrderDetailMapper unityOrderDetailMapper;     

     /**출고지시서 화물수취인 전화번호 복호화*/
     @Override
     public String updateMoblphonNoDecryption(SlePrufDtaOutptVO paramVo) throws Exception {
          String resultStr = "";

          try {
               //출고지시서 화물수취인 전화번호 조회
               String frghtAddrseMoblphonNo = unityOrderDetailMapper.selectMoblphonNoDecryption(paramVo);

               if(!StringUtils.isEmpty(frghtAddrseMoblphonNo)) {

                    String decryptStr   = CryptoUtil.decryptAES256(frghtAddrseMoblphonNo);          //복호화
                    resultStr           = unityOrderDetailMapper.selectFnGetTelNo(decryptStr); //전화번호 하이픈 포맷 적용

               } else {

                    log.debug("UnityOrderDetailServiceImpl::updateMoblphonNoDecryption frghtAddrseMoblphonNo is empty");

               }//end if()

          } catch (Exception e) {

               log.error("UnityOrderDetailServiceImpl::updateMoblphonNoDecryption exception = " + e.getMessage());

          }

          return resultStr;
     }//end updateMoblphonNoDecryption()

     /**출고명세서*/
     @Override
     public String selectDlvyOdrCount(UnityOrderPapersVO paramVo) throws Exception {
          String dlvyOdrCount = "";

          try {
        	  //배송차수
        	  dlvyOdrCount = unityOrderDetailMapper.selectDlvyOdrCount(paramVo);

          } catch (Exception e) {

               log.error("UnityOrderDetailServiceImpl::selectDlvyOdrCount exception = " + e.getMessage());

          }

          return dlvyOdrCount;
     }//end selectDlvyOdrCount()

	@Override
	public List<SlePrufDtaOutptVO> getSlePrufDtaOutptList(SlePrufDtaOutptVO paramVo) throws Exception {
		return unityOrderDetailMapper.getSlePrufDtaOutptList(paramVo);
	}
	
	/**
	 * 처리내용: 주문 기업 계좌번호 조회 후 복호화
	*/
	@Override
	public String getEwalletAcnutNo(String orderNo) throws Exception {
		String CryptoAcnutNo = "";
		CryptoAcnutNo = CryptoUtil.decryptAES256(unityOrderDetailMapper.getEwalletAcnutNo(orderNo));
		return CryptoAcnutNo;
	}
	
	/**
	* 출력 횟수를 입력한다.
	*/
	public int insertSlePrufDtaPrintCnt(SlePrufDtaOutptVO slePrufDtaOutptVO) throws Exception {
		int insertSlePrufDtaPrintCnt = 0;
		SlePrufDtaOutptVO vo = new SlePrufDtaOutptVO();

		for(String orderNo : slePrufDtaOutptVO.getOrderNos()) {
			//로그인 계정 정보 set
			vo.setFrstRegisterId("");
			vo.setOrderNo(orderNo);
			insertSlePrufDtaPrintCnt += unityOrderDetailMapper.insertSlePrufDtaPrintCnt(vo);
		}
		return insertSlePrufDtaPrintCnt;
	}

}
//TEST