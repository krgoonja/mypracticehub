package com.sorincorp.api.oz.constant;

public class OzDecryptionConstant {

}//end class()
