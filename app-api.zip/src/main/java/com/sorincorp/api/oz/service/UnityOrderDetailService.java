/**
 *
 */
package com.sorincorp.api.oz.service;

import java.util.List;

import com.sorincorp.api.oz.model.SlePrufDtaOutptVO;
import com.sorincorp.api.oz.model.UnityOrderPapersVO;
/**
 * UnityOrderDetailService.java
 * 통합주문상세 Service 인터페이스
 *
 * @version
 * @since 2021. 7. 19.
 * @author srec0049
 */
public interface UnityOrderDetailService {

	/**
	 * <pre>
	 * 출고지시서 화물수취인 전화번호 복호화
	 * </pre>
	 * @date 2022. 4. 19.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 4. 19.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param relatePapersInfo
	 * @return
	 * @throws Exception
	 */
	String updateMoblphonNoDecryption(SlePrufDtaOutptVO relatePapersInfo) throws Exception;

	/**
	 * <pre>
	 * 주문번호로 배송차수 조회
	 * </pre>
	 * @date 2023. 2. 6.
	 * @author jdrttl
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 2.  6.			jdrttl				최초작성
	 * ------------------------------------------------
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	String selectDlvyOdrCount(UnityOrderPapersVO paramVo) throws Exception;	

	List<SlePrufDtaOutptVO> getSlePrufDtaOutptList(SlePrufDtaOutptVO paramVo) throws Exception;

	/**
	 * 처리내용: 주문 기업 계좌번호 조회 후 복호화
	*/
	String getEwalletAcnutNo(String orderNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 출력 횟수를 입력한다.
	 * </pre>
	 * @date 2023. 12. 08
	 * @author
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 12. 08
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	int insertSlePrufDtaPrintCnt(SlePrufDtaOutptVO slePrufDtaOutptVO) throws Exception;

}
