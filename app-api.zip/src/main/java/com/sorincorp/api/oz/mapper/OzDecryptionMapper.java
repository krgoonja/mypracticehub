package com.sorincorp.api.oz.mapper;


import com.sorincorp.api.oz.model.OzDecryptionVO;

public interface OzDecryptionMapper {
	
	String selectMoblphonNo(OzDecryptionVO ozDecryptionVO);

	String selectEwalletAcnutNo(String resultStr);

	Object selectTelNoFormatConvert(String resultStr);
	
}
