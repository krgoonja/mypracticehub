package com.sorincorp.api.oz.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.api.oz.mapper.OzDecryptionMapper;
import com.sorincorp.api.oz.model.OzDecryptionVO;
import com.sorincorp.comm.util.CryptoUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OzDecryptionServiceImpl implements OzDecryptionService {


	@Autowired
	private OzDecryptionMapper ozDecryptionMapper;
	
	@Transactional(rollbackFor = Exception.class)
	@Override
	public String executeConvertToOzReportXml(OzDecryptionVO ozDecryptionVO) throws Exception {
		
		String returnStr = "";
		
		try {
			
			//1. 화물수취인 전화번호(수취 업체 휴대폰 번호) 조회
			String receptEntrpsMoblphonNo = ozDecryptionMapper.selectMoblphonNo(ozDecryptionVO);
			log.debug("receptEntrpsMoblphonNo = " + receptEntrpsMoblphonNo);
			
			//2. 화물수취인 전화번호(수취 업체 휴대폰 번호) 복호화
			String resultStr = CryptoUtil.decryptAES256(receptEntrpsMoblphonNo);
			log.debug("resultStr = " + resultStr);
			
			//3. String to XML Convert (화물수취인 전화번호)
			returnStr = ConvertToOzReportXml(resultStr);
			
		} catch (Exception e) {
			throw new Exception("/api/oz/Decryption Error = " + e.getMessage());
		} 
		
		System.out.println("returnStr = " + returnStr);
		return returnStr;
	}//end executeConvertToOzReportXml()

	public String ConvertToOzReportXml(String resultStr) {
		
		StringBuffer sb = new StringBuffer();
		Object value 	= null;
		
		//화물수취인 전화번호 FORMAT 변경
		value = ozDecryptionMapper.selectTelNoFormatConvert(resultStr);
		
		// RdReport XML rule
		sb.append("<XMLSET>");
		sb.append("<DATASET>");
		
		// RECORD AREA START
		sb.append("<RECORD>");
	    sb.append("<MOBLPHNUM>");
	    sb.append(value != null ? value : " ");
	    sb.append("</MOBLPHNUM>");
		sb.append("</RECORD>");
		// RECORD AREA END
		
		sb.append("</DATASET>");
		sb.append("</XMLSET>");
		
		return sb.toString();
	}//end ConvertToOzReportXml()
	
	public String ewalletExecuteConvertToOzReportXml(OzDecryptionVO ozDecryptionVO) throws Exception {
		StringBuffer sb = new StringBuffer();
		try {
			String ewalletAcnutNo = "";
			Object value 	= null;
			//계좌번호 FORMAT 변경
			ewalletAcnutNo = CryptoUtil.decryptAES256(ozDecryptionMapper.selectEwalletAcnutNo(ozDecryptionVO.getOrderNum()));
			value = ewalletAcnutNo;
			// RdReport XML rule
			sb.append("<XMLSET>");
			sb.append("<DATASET>");
			
			// RECORD AREA START
			sb.append("<RECORD>");
			sb.append("<EWALLETACNUTNO>");
			sb.append(value != null ? value : " ");
			sb.append("</EWALLETACNUTNO>");
			sb.append("</RECORD>");
			// RECORD AREA END
			
			sb.append("</DATASET>");
			sb.append("</XMLSET>");
			
			return sb.toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sb.toString();
	}//end ConvertToOzReportXml()
	

}//end class()

