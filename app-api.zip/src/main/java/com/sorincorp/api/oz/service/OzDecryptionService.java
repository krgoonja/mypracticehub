package com.sorincorp.api.oz.service;

import com.sorincorp.api.oz.model.OzDecryptionVO;

public interface OzDecryptionService {

	String executeConvertToOzReportXml(OzDecryptionVO ozDecryptionVO) throws Exception;

	String ewalletExecuteConvertToOzReportXml(OzDecryptionVO ozDecryptionVO) throws Exception;
	
}//end interface()
