package com.sorincorp.api.oz.model;

import lombok.Data;

@Data
public class OzRespVO {
	
	private String resultFlag;
	
	private String resultStr;
	
}//end class()
