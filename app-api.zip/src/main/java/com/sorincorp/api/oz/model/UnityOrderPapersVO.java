package com.sorincorp.api.oz.model;

import java.util.List;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * UnityOrderPapersVo.java
 * 통합주문상세 - 관련 서류 VO 객체
 * @version
 * @since 2021. 9. 29.
 * @author srec0054
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class UnityOrderPapersVO extends CommonVO{
	
	private static final long serialVersionUID = -653988917961339151L;

	/**
	 * Search</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface Search {};
	
	/**주문 번호*/
	private String orderNo;
	
	/**서류명*/
	private String papersNm;
	
	/**서류 구분*/
    private String tabDiv;
    
    /**내용*/
	private String contents;
	
	/**상태-이론/탈리*/
    private String sttus;
    
    /**ozr 파일명*/
	private String ozNm;
	
	 /**파라미터 설정*/
	private String pCount;
    
    /**오즈리포트 호출 공통 파라미터*/
    private String param1;
    private String param2;
    private String param3;
    private String param4;
    private String param5;
    private String param6;
    private String param7;
    private String param8;
    private String param9;
    private String param10;
    private String param11;
    
    private String paramNm2;
    private String paramNm3;
    private String paramNm4;
    
    private String flag;
    
    /**성적서&패킹리스트*/
    /**BL 번호*/
    private String blNo;
    
    /**성적서 파일 경로*/
	private String screofeFileCours;
	
	/**포장 리스트 파일 경로*/
	private String packngListFileCours;
	
	/**브랜드명*/
    private String brandNm;
    
	/**날짜정보*/
    private String paperDe;
    
    /**
     * 출력서류 선택 ((tabDivList : details,tally) 이면 출고명세서와 출고증 출력)
     */
    private List<String> tabDivList;
    
}//end class()
