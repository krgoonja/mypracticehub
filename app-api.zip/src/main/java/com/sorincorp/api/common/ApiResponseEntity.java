package com.sorincorp.api.common;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ApiResponseEntity {

	/** 결과 코드  **/
	private String rspnsCode;

	/** 결과 메세지  **/
	private String rspnsMssage;

	/** 결과 데이터 **/
	private Map<String, Object> rspnsCont;


	/** Generates part args constructor
	 * @param rspnsCode
	 * @param rspnsMssage
	 */
	public ApiResponseEntity(String rspnsCode, String rspnsMssage) {
		this.rspnsCode = rspnsCode;
		this.rspnsMssage = rspnsMssage;
	}

}
