package com.sorincorp.api.it.model;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@ApiModel("아이템정보 수신 Detail VO")
public class ItemInfoDtlVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 8361136673054118673L;

	/** 인터페이스 번호 **/
	private int intrfcNo;

	/**
	 * 아이템순번
	 */
	@ApiModelProperty(value = "아이템순번", example = "1")
	@NotEmpty(message="{itemInfoDtlVO.seq.isEmpty}")
	@NotNull(message="{itemInfoDtlVO.seq.isNull}")
	private String seq;
	/**
	 * Material 코드
	 */
	@Size(max=50, message="{itemInfoDtlVO.materialCode.maxSizeOver}")
	private String materialCode;
	/**
	 * Chemical01 코드
	 */
	private String chemical01Code;
	/**
	 * Chemical02 코드
	 */
	private String chemical02Code;
	/**
	 * Shape 코드
	 */
	private String shapeCode;
	/**
	 * 아이템 코드
	 */
	private String itemCom;
	/**
	 * 아이템 품목 한글
	 */
	private String itemNm;
	/**
	 * 아이템 품목 영문
	 */
	private String itemNmEn;
	/**
	 * 포장 코드
	 */
	private String packing;
	/**
	 * MetalList
	 */
	private List<ItemInfoSubDtlVO> specList;
	/**
	 * 세번 코드
	 */
	private String hsCode;
	/**
	 * ERP 코드
	 */
	private String erpCode;
	/**
	 * 유효 시작 일자
	 */
	private String valFrom;
	/**
	 * 유효 종료 일자
	 */
	private String valTo;
	/**
	 * 사용 여부
	 */
	private String useYn;
	/**
	 * 생성 일자
	 */
	private String createDate;
	/**
	 * 생성 아이디 번호
	 */
	private String createUserNo;
	/**
	 * 업데이트 일자
	 */
	private String updateDate;
	/**
	 * 업데이트 아이디 번호
	 */
	private String updateUserNo;
	/**
	 * 인터페이스 구분(I/U/D)
	 */
	@ApiModelProperty(value = "인터페이스 구분", example = "I")
	@NotEmpty(message="{itemInfoDtlVO.intrfcSe.isEmpty}")
	@NotNull(message="{itemInfoDtlVO.intrfcSe.isNull}")
	private String intrfcSe;

	private String intrfcId;

}
