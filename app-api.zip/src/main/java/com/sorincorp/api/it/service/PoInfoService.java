package com.sorincorp.api.it.service;

import java.util.List;
import java.util.Map;


public interface PoInfoService {

	void updateItPurchsInfoBas(List<Map<String, String>> blNoList) throws Exception;
}
