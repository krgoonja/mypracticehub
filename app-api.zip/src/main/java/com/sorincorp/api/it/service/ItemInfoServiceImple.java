package com.sorincorp.api.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.it.comm.ItConstants;
import com.sorincorp.api.it.mapper.ItemInfoMapper;
import com.sorincorp.api.it.model.ItemInfoDtlVO;
import com.sorincorp.api.it.model.ItemInfoSubDtlVO;
import com.sorincorp.api.it.model.ItemInfoVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;
import com.sorincorp.comm.itemcode.mapper.ItemCodeMapper;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemweight.mapper.ItemWeightMapper;
import com.sorincorp.comm.itemweight.model.ItemWeightVO;
import com.sorincorp.comm.util.CacheUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ItemInfoServiceImple implements ItemInfoService {

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private ItemInfoMapper itemInfoMapper;
	@Autowired
	private ItemCodeMapper itemCodeMapper;
	@Autowired
	private ItemWeightMapper itemWeightMapper;
	@Autowired
	private CacheUtil cacheUtil;

	@Override
	public void insertItemInfoBas(ItemInfoVO itemInfoVO) throws Exception {
		// TODO Auto-generated method stub
		/** 통합 로그 INSERT **/
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog("SOREC-IF-011", itemInfoVO);

		// 아이템 코드 카운트
		int itemCnt = 0;
		String updateDateEqYn = "N";
		// 원장테이블 수행결과
		int basRtn = 0;
		// 히스토리 테이블 수행결과
		int hstRtn = 0;

		try {
//			log.debug("itemInfoVO : "+ itemInfoVO.toString());
//			log.debug("itemInfoVO.getItemList().size() : "+ itemInfoVO.getItemList().size());
			/** 서비스 로직(원본/원복이력 table insert) **/
			for (ItemInfoDtlVO itemInfoDtlVO : itemInfoVO.getItemList()) {
				// 인터페이스 id 세팅하여 등록자아이디, 수정자아이디로 사용한다.
				itemInfoDtlVO.setIntrfcId("SOREC-IF-011");
				// 아이템 순번 카운트 체크
				itemCnt = itemInfoMapper.selectItemInfoBasCnt(itemInfoDtlVO);

				if ("I".equals(itemInfoDtlVO.getIntrfcSe())) {
					// 인터페이스 구분 I면 insert
					if (itemCnt == 0) {
						// 중복 데이터 없을 경우 insert
						basRtn = itemInfoMapper.insertItemInfoBas(itemInfoDtlVO);
						hstRtn = itemInfoMapper.insertItemInfoBasHst(itemInfoDtlVO);

						if (basRtn < 1 || hstRtn < 1) {
							btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
							btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_MSG);
							throw new Exception(ItConstants.ERROR_RESULT_MSG);
						}

						for (ItemInfoSubDtlVO itemInfoSubDtlVO : itemInfoDtlVO.getSpecList()) {
							// 인터페이스 id 세팅하여 등록자아이디, 수정자아이디로 사용한다.
							itemInfoSubDtlVO.setIntrfcId("SOREC-IF-011");
							itemInfoSubDtlVO.setSeq(itemInfoDtlVO.getSeq());
							itemInfoSubDtlVO.setCreateDate(itemInfoDtlVO.getCreateDate());
							itemInfoSubDtlVO.setCreateUserNo(itemInfoDtlVO.getCreateUserNo());

							basRtn = itemInfoMapper.insertItItmStdSpecDtl(itemInfoSubDtlVO);
							hstRtn = itemInfoMapper.insertItItmStdSpecDtlHst(itemInfoSubDtlVO);

							if (basRtn < 1 || hstRtn < 1) {
								btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
								btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_MSG);
								throw new Exception(ItConstants.ERROR_RESULT_MSG);
							}

						}
					} else {
						// 데이터가 있으면 update
						updateDateEqYn = itemInfoMapper.selectUpdateDataEqYn(itemInfoDtlVO);

						if ("N".equals(updateDateEqYn)) {
							// 수정일자가 다를 경우 update
							basRtn = itemInfoMapper.updateItemInfoBas(itemInfoDtlVO);
							hstRtn = itemInfoMapper.insertItemInfoBasHst(itemInfoDtlVO);

							if (basRtn < 1 || hstRtn < 1) {
								btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
								btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_MSG);
								throw new Exception(ItConstants.ERROR_RESULT_MSG);
							}

							// 표준스펙
							for (ItemInfoSubDtlVO itemInfoSubDtlVO : itemInfoDtlVO.getSpecList()) {
								// 인터페이스 id 세팅하여 등록자아이디, 수정자아이디로 사용한다.
								itemInfoSubDtlVO.setIntrfcId("SOREC-IF-011");
								itemInfoSubDtlVO.setSeq(itemInfoDtlVO.getSeq());
								itemInfoSubDtlVO.setCreateDate(itemInfoDtlVO.getCreateDate());
								itemInfoSubDtlVO.setCreateUserNo(itemInfoDtlVO.getCreateUserNo());

								basRtn = itemInfoMapper.insertItItmStdSpecDtl(itemInfoSubDtlVO);
								hstRtn = itemInfoMapper.insertItItmStdSpecDtlHst(itemInfoSubDtlVO);

								if (basRtn < 1 || hstRtn < 1) {
									btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
									btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_MSG);
									throw new Exception(ItConstants.ERROR_RESULT_MSG);
								}
							}
						}
					}

				} else if ("U".equals(itemInfoDtlVO.getIntrfcSe())) {
					// 수정일자 동일여부 조회
					// updateDateEqYn = itemInfoMapper.selectUpdateDataEqYn(itemInfoDtlVO);
					// 인터페이스 구분 U면 update
					// if(itemCnt == 1 && "N".equals(updateDateEqYn)) {
					if (itemCnt == 1) {
						// 데이터 존재 할 경우 update
						basRtn = itemInfoMapper.updateItemInfoBas(itemInfoDtlVO);
						hstRtn = itemInfoMapper.insertItemInfoBasHst(itemInfoDtlVO);

						for (ItemInfoSubDtlVO itemInfoSubDtlVO : itemInfoDtlVO.getSpecList()) {
							// 인터페이스 id 세팅하여 등록자아이디, 수정자아이디로 사용한다.
							itemInfoSubDtlVO.setIntrfcId("SOREC-IF-011");
							itemInfoSubDtlVO.setSeq(itemInfoDtlVO.getSeq());
							itemInfoSubDtlVO.setUpdateDate(itemInfoDtlVO.getUpdateDate());
							itemInfoSubDtlVO.setUpdateUserNo(itemInfoDtlVO.getUpdateUserNo());

							basRtn = itemInfoMapper.updateItItmStdSpecDtl(itemInfoSubDtlVO);
							hstRtn = itemInfoMapper.insertItItmStdSpecDtlHst(itemInfoSubDtlVO);
						}

						if (basRtn < 1 || hstRtn < 1) {
							btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
							btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_MSG);
							throw new Exception(ItConstants.ERROR_RESULT_MSG);
						}

					} else if (itemCnt < 1) {
						// 데이터 없을 경우 insert
						basRtn = itemInfoMapper.insertItemInfoBas(itemInfoDtlVO);
						hstRtn = itemInfoMapper.insertItemInfoBasHst(itemInfoDtlVO);

						if (basRtn < 1 || hstRtn < 1) {
							btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
							btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_MSG);
							throw new Exception(ItConstants.ERROR_RESULT_MSG);
						}

						for (ItemInfoSubDtlVO itemInfoSubDtlVO : itemInfoDtlVO.getSpecList()) {
							// 인터페이스 id 세팅하여 등록자아이디, 수정자아이디로 사용한다.
							itemInfoSubDtlVO.setIntrfcId("SOREC-IF-011");
							itemInfoSubDtlVO.setSeq(itemInfoDtlVO.getSeq());
							itemInfoSubDtlVO.setCreateDate(itemInfoDtlVO.getCreateDate());
							itemInfoSubDtlVO.setCreateUserNo(itemInfoDtlVO.getCreateUserNo());

							basRtn = itemInfoMapper.insertItItmStdSpecDtl(itemInfoSubDtlVO);
							hstRtn = itemInfoMapper.insertItItmStdSpecDtlHst(itemInfoSubDtlVO);

							if (basRtn < 1 || hstRtn < 1) {
								btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
								btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_MSG);
								throw new Exception(ItConstants.ERROR_RESULT_MSG);
							}

						}
					}
				} else if ("D".equals(itemInfoDtlVO.getIntrfcSe())) {
					// 인터페이스 구분 D면 delete
					if (itemCnt == 1) {
						// 데이터 존재 할 경우 delete
						basRtn = itemInfoMapper.deleteItemInfoBas(itemInfoDtlVO);
						hstRtn = itemInfoMapper.insertItemInfoBasHst(itemInfoDtlVO);

						for (ItemInfoSubDtlVO itemInfoSubDtlVO : itemInfoDtlVO.getSpecList()) {
							// 인터페이스 id 세팅하여 등록자아이디, 수정자아이디로 사용한다.
							itemInfoDtlVO.setIntrfcId("SOREC-IF-011");
							itemInfoSubDtlVO.setSeq(itemInfoDtlVO.getSeq());
							itemInfoSubDtlVO.setUpdateDate(itemInfoDtlVO.getUpdateDate());
							itemInfoSubDtlVO.setUpdateUserNo(itemInfoDtlVO.getUpdateUserNo());

							basRtn = itemInfoMapper.deleteItItmStdSpecDtl(itemInfoSubDtlVO);
							hstRtn = itemInfoMapper.insertItItmStdSpecDtlHst(itemInfoSubDtlVO);
						}

						if (basRtn < 1 || hstRtn < 1) {
							btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
							btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_MSG);
							throw new Exception(ItConstants.ERROR_RESULT_MSG);
						}

					} else {
						// 데이터 없을 경우 throw exception
						btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
						btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_MSG);
						throw new Exception(ItConstants.ERROR_RESULT_MSG);
					}
				}
			}

			btbLogVo.setIntrfcRspnsCode(ItConstants.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(ItConstants.SUCCESS_RESULT_MSG);

			// Radis 정보 업데이트
			ItemCodeVO itemCodeVO = new ItemCodeVO();
			List<ItemCodeVO> itemCodeList = itemCodeMapper.getItemCode(itemCodeVO);
			cacheUtil.put("itemCodeList", itemCodeList);

			ItemWeightVO itemWeightVO = new ItemWeightVO();
			List<ItemWeightVO> itemWeightCodeList = itemWeightMapper.getItemWeightCode(itemWeightVO);
			cacheUtil.put("itemWeightCodeList", itemWeightCodeList);

		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			throw new Exception(e.getMessage());
		} finally {
			/** 통합 로그 UPDATE **/
			httpClientHelper.updateBtbLog(btbLogVo);
		}
	}

}
