package com.sorincorp.api.it.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
public class WrhousHolidayVO{
	
	/* 창고코드 */
	@ApiModelProperty(value = "창고 코드", example = "AA")
	@NotEmpty(message="{sampleVO.id.isEmpty}")
	private String wrhousCode;
	
	/* 휴일일자 */
	@ApiModelProperty(value = "휴일일자", example = "20210629")
	@NotEmpty(message="{sampleVO.id.isEmpty}")
	private String holiday;
	
	/* 휴일명 */
	@ApiModelProperty(value = "휴일명", example = "테스트 휴일 입니다.(api)")
	@NotEmpty(message="{sampleVO.id.isEmpty}")
	private String holidayName;
	
	/* 비고 */
	@ApiModelProperty(value = "비고", example = "비고 테스트 입니다.(api)")
	private String rm;
	
	/* 인터페이스 구분(I/U/D) */
	@ApiModelProperty(hidden = true)
	private String intrfcSe;
	
	
}
