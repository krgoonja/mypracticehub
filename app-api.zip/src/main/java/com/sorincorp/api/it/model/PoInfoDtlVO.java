package com.sorincorp.api.it.model;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class PoInfoDtlVO implements Serializable {

	private static final long serialVersionUID = 6739318240780192927L;

	public interface InsertAndUpdate {
	};

	/****** JAVA VO CREATE : IT_PURCHS_INFO_BAS(상품_PO 정보 기본) ******/
	/**
	 * BL 번호
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "BL 번호 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String blNo;
	/**
	 * 구매 주문 번호 (PO NO)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "구매 주문 번호 (PO NO) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String purchsOrderNo;
	/**
	 * 구매 라인 번호 (lineNo)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "구매 라인 번호 (lineNo) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String purchsLineNo;
	/**
	 * 구매 한도 수량 (Quota)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "구매 한도 수량 (Quota) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String purchQuota;
	/**
	 * 구매 사업자 (ACCOUNT)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "구매 사업자 (ACCOUNT) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String purchsBsnm;
	/**
	 * 구매 무역 조건 (ICT)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "구매 무역 조건 (ICT) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String purchsCmmrcCnd;
	/**
	 * 구매 위치 명 (LOCATION)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "구매 위치 명 (LOCATION) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String purchsLcNm;
	/**
	 * 구매 수량 (QTY)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "구매 수량 (QTY) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String purchsQy;
	/**
	 * 구매 LME 달러 가격 (LME)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "구매 LME 달러 가격 (LME) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String purchsLmeDollarPc;
	/**
	 * 구매 프리미엄 달러 금액 (PREM)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "구매 프리미엄 달러 금액 (PREM) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String purchsPremiumDollarAmount;
	/**
	 * 구매 단위 달러 가격 (U.PRICE)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "구매 단위 달러 가격 (U.PRICE) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String purchsUnitDollarPc;
	/**
	 * 구매 달러 총액 (AMOUNT(USD))
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "구매 달러 총액 (AMOUNT(USD)) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String purchsDollarAmount;
	/**
	 * 구매 원화 총액 (AMOUNT(KRW))
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "구매 원화 총액 (AMOUNT(KRW)) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String purchsWonAmount;
	/**
	 * 선물 계약 번호 (FS NO)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물 계약 번호 (FS NO) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String ftrsCntrctNo;
	/**
	 * 선물 삼성 계약 번호 (삼성선물 NO)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물 삼성 계약 번호 (삼성선물 NO) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String ftrsThsexCntrctNo;
	/**
	 * 선물 거래 일시 (ORDER DATE)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물 거래 일시 (ORDER DATE) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String ftrsDelngDt;
	/**
	 * 선물 거래 LOT 수량 (LOT)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물 거래 LOT 수량 (LOT) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String ftrsDelngLotQy;
	/**
	 * 선물 거래 중량 (QTY)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물 거래 중량 (QTY) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String ftrsDelngWt;
	/**
	 * 선물 거래 옵션 (PRICE OPTION)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물 거래 옵션 (PRICE OPTION) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String ftrsDelngOptn;
	/**
	 * 선물 거래 시작 일자 (FROM)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물 거래 시작 일자 (FROM) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String ftrsDelngBeginDe;
	/**
	 * 선물 거래 종료 일자 (TO)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물 거래 종료 일자 (TO) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String ftrsDelngEndDe;
	/**
	 * 선물 LME 달러 가격 (LME)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물 LME 달러 가격 (LME) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String ftrsLmeDollarPc;
	/**
	 * 선물 스프레드 달러 가격 (SPREAD)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물 스프레드 달러 가격 (SPREAD) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String ftrsSpreadDollarPc;
	/**
	 * 선물 종료 달러 가격 (U.PRICE)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물 종료 달러 가격 (U.PRICE) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String ftrsEndDollarPc;
	/**
	 * 선물 달러 수수료 (Commission)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물 달러 수수료 (Commission) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String ftrsDollarFee;
	/**
	 * 선물 만기 일자 (Prompt)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물 만기 일자 (Prompt) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String ftrsExprtnDe;
	/**
	 * 선물환 계약 번호 (FXS NO)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물환 계약 번호 (FXS NO) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String fshgCntrctNo;
	/**
	 * 선물환 거래 일시 (ORDER DATE)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물환 거래 일시 (ORDER DATE) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String fshgDelngDt;
	/**
	 * 선물환 배부 중량 (배부중량)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물환 배부 중량 (배부중량) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String fshgDlryWt;
	/**
	 * 선물환 거래 통화 (Cur)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물환 거래 통화 (Cur) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String fshgDelngCrncy;
	/**
	 * 선물환 거래 달러 금액 (Amount)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물환 거래 달러 금액 (Amount) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String fshgDelngDollarAmount;
	/**
	 * 선물환 원화 환율 (현물환)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물환 원화 환율 (현물환) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String fshgWonEhgt;
	/**
	 * 선물환 원화 스프레드 (Swap Rate)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물환 원화 스프레드 (Swap Rate) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String fshgWonSpread;
	/**
	 * 선물환 종료 원화 가격 (체결환율)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물환 종료 원화 가격 (체결환율) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String fshgEndWonPc;
	/**
	 * 선물환 매수 원화 가격 (Amount KRW)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물환 매수 원화 가격 (Amount KRW) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String fshgPrchasWonPc;
	/**
	 * 선물환 만기 일자 (Prompt)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물환 만기 일자 (Prompt) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String fshgExprtnDe;
	/**
	 * 물류 터미널 사용 원화 비용 (THC)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "물류 터미널 사용 원화 비용 (THC) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String lgistTrminlUseWonCt;
	/**
	 * 물류 해상 운송 원화 비용 (해상운송료)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "물류 해상 운송 원화 비용 (해상운송료) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String lgistTrnsprtWonCt;
	/**
	 * 물류 내륙 운송 원화 비용 (내륙운송료)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "물류 내륙 운송 원화 비용 (내륙운송료) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String lgistLandTrnsprtWonCt;
	/**
	 * 물류 하역 원화 비용 (하역료)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "물류 하역 원화 비용 (하역료) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String lgistLnlWonCt;
	/**
	 * 물류 보관 원화 비용
	 */
	private int lgistCstdyWonCt;
	/**
	 * 물류 기타 원화 비용 (기타비용)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "물류 기타 원화 비용 (기타비용)") // /message/validation.properties 에 등록된 메시지
	private String lgistEtcWonCt;
	/**
	 * 물류 합계 원화 비용 (합계)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "물류 합계 원화 비용 (합계) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String lgistSmWonCt;
	/**
	 * 통관 관세 원화 비용 (관세)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "통관 관세 원화 비용 (관세) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String entrCstmsWonCt;
	/**
	 * 통관 수수료 원화 비용 (통관수수료)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "통관 수수료 원화 비용 (통관수수료) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String entrFeeWonCt;
	/**
	 * 금융 이자 원화 비용 (이자비용)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "금융 이자 원화 비용 (이자비용) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String fnncIntrWonCt;
	/**
	 * 금융 기타 원화 비용 (기타비용)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "금융 기타 원화 비용 (기타비용) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String fnncEtcWonCt;
	/**
	 * 비용 합계 원화 비용(합계)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "비용 합계 원화 비용(합계) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String ctSmWonCt;
	/**
	 * 선적 일자 (ON BOARD)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선적 일자 (ON BOARD) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String shipngDe;
	/**
	 * 선적항 명 (POL)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선적항 명 (POL) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String prloadNm;
	/**
	 * 도착항 명 (POD)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "도착항 명 (POD) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String arvlhangNm;
	/**
	 * 성적서 파일 경로
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "성적서 파일 경로 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String screofeFileCours;
	/**
	 * 포장 리스트 파일 경로
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "포장 리스트 파일 경로 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String packngListFileCours;
	/**
	 * 입고 일자 (입고일)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "입고 일자 (입고일) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String wrhousngDe;
	/**
	 * 요율 값 (요율(원/일))
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "요율 값 (요율(원/일)) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String tariffVal;
	/**
	 * 프리 타임 (Free Time)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "프리 타임 (Free Time) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String freeTime;
	/**
	 * NET 중량 (NET WEIGHT)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "NET 중량 (NET WEIGHT) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String netWt;
	/**
	 * GROSS 중량 (GROSS WEIGHT)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "GROSS 중량 (GROSS WEIGHT) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String grossWt;
	/**
	 * LOT 수량 (BUNDLES)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "LOT 수량 (BUNDLES) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String lotQy;
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;

	/**
	 * 선물 라인 번호 (line)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물 라인 번호 (line) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String ftrsLineNo;
	/**
	 * 통화 코드 (Cur)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "통화 코드 (Cur) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String crncyCode;
	/**
	 * 통관일자
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "통관일자 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String enterDe;

	/**
	 * 선물환 관리번호
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "선물환 관리번호 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String fshgManageNo;

	private String lotSndYn;

	private String sleSttusCode;

	private List<LotInfoDtlVO> lotNoList;

	// 2022-08-30 항목 추가
	// start----------------------------------------------------------

	/**
	 * 선물 최초 수량
	 */
	private String ftrsDelngLotOrgQy;

	/**
	 * 선물환 최초 중량
	 */
	private String fshgDlryOrgWt;

	/**
	 * 선물환 최초 체결 금액
	 */
	private String fshgDelngDollarOrgAmount;

	// 2022-08-30 항목 추가
	// end-------------------------------------------------------------------------------

	/**
	 * 선물사 구분 코드(TCODE)
	 */
	private String ftrsCmpnySeCode;

	/**
	 * 인터페이스 구분(I,U,D)
	 */
	private String intrfcSe;
	/**
	 * 인터페이스 아이디
	 */
	private String intrfcId;
	

    /**
     * BL 파일 경로
    */
    private String blFileCours;

}
