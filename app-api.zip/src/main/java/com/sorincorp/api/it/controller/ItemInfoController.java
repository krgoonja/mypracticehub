package com.sorincorp.api.it.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.it.comm.ItConstants;
import com.sorincorp.api.it.comm.ItResponseEntity;
import com.sorincorp.api.it.model.ItemInfoVO;
import com.sorincorp.api.it.service.ItemInfoService;
import com.sorincorp.api.it.service.PoInfoService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.validation.CustomValidator;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/sts")
@Api( value = "아이템정보 수신")
@ComponentScan("com.sorincorp.comm.*")
public class ItemInfoController {

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private ItemInfoService itemInfoService;

	@Autowired
	private PoInfoService poInfoService;

	@Autowired
	private CustomValidator customValidator;

	@PostMapping("/item_info")
	@ApiOperation(value = "아이템정보 수신", notes = "트레이딩에서 등록한 아이템 정보(ITEM) EC로 수신")
	public ResponseEntity<?> itemInfoRecptn(@ApiParam(value = "아이템정보수신 VO", required = true)
		@RequestBody ItemInfoVO itemInfoVO, HttpServletRequest request, BindingResult bindingResult) throws Exception{

		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		customValidator.validate(itemInfoVO, bindingResult);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

//		Map<String, String> param = new HashMap<String, String>();
//		List<Map<String, String>> blNoList = new ArrayList<Map<String,String>>();
//
//		param.put("blNo", "MAEU591311435");
//		param.put("orderNo", "ECPO20211103-71");
//		param.put("lineNo", "1");
//		blNoList.add(param);
//
//		poInfoService.updateItPurchsInfoBas(blNoList);

		itemInfoService.insertItemInfoBas(itemInfoVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new ItResponseEntity(ItConstants.SUCCESS_RESULT_CODE, ItConstants.SUCCESS_RESULT_MSG));
	}

}
