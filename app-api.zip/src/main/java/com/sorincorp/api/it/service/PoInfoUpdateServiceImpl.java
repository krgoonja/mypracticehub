package com.sorincorp.api.it.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.sorincorp.comm.btb.comm.BtoBConstants;
import com.sorincorp.comm.btb.model.BtoBReqEntity;
import com.sorincorp.comm.btb.model.BtoBResEntity;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import com.sorincorp.api.it.comm.ItConstants;
import com.sorincorp.api.it.mapper.PoInfoMapper;
import com.sorincorp.api.it.model.LotInfoDtlVO;
import com.sorincorp.api.it.model.PoInfoDtlVO;
import com.sorincorp.api.it.model.PoInfoVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;
import com.sorincorp.comm.common.mapper.CommonMapper;
import com.sorincorp.comm.common.service.CommonService;

import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class PoInfoUpdateServiceImpl implements PoInfoUpdateService {

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private PoInfoMapper poInfoUpdateMapper;

//	@Autowired
//	private CustomValidator customValidator;

	@Autowired
	private CommonService commonService;

	@Autowired
	private CommonMapper commonMapper;

	@Autowired
	private ObjectMapper objectMapper;

	@Override
	public void updateItPurchsInfoBas(PoInfoVO poInfoVO, BindingResult bindingResult) throws Exception {
		// TODO Auto-generated method stub
		/** 통합 로그 INSERT **/
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog("SOREC-IF-150", poInfoVO);

//		int poCnt = 0;
//		int lotCnt = 0;
//		int tariffVal = 0;
//		int freeTime = 0;
//		int lgistCstdyWonCt = 0;

//		// 20220215 bl 판매상태변경 로직추가
//		BlSleSttusCodeChgVO blSleSttusCodeChgVO;

//		// BL번호
//		String blNo = "";
//		// BL만기경과여부
//		String blExpiryYn = "";
//		// 소수점여부
//		String decimalYn = "";
//		// 선물환 관리번호
//		String fshgManageNo = "";
//		// 삼성선물계약번호
//		// String ftrsThsexCntrctNo = "";
//		// 판매상태코드
//		String sleSttusCode = "";
//		// 선물환 관리번호 카운트
//		int fshgManageNoCnt = 0;
//		// 통관여부
//		String entrAt = "";
//		// 판매불가 사유코드
//		String sleImprtyResn = "";
//		//선물 최초 수량
//		String ftrsDelngLotOrgQy = "";
//		//선물 최초 중량
//		String fshgDlryOrgWt = "";
//		//선물환 최초 체결 금액
//		String fshgDelngDollarOrgAmount = "";

		try {

			/** 서비스 로직(원본/원복이력 table insert) **/
			// for(PoInfoDtlVO poInfoDtlVO : poInfoVO.getBlNoRspList()) {
			for (PoInfoDtlVO poInfoDtlVO : poInfoVO.getBlNoList()) {
				// 인터페이스 id 세팅하여 등록자아이디, 수정자아이디로 사용한다.
				poInfoDtlVO.setIntrfcId("SOREC-IF-150");

				poInfoUpdateMapper.mergeItPurchsInfoBas2(poInfoDtlVO);
//				poInfoUpdateMapper.insertItPurchsInfoBasHst(poInfoDtlVO);
				commonMapper.insertItPurchsInfoBasHst(poInfoDtlVO.getBlNo());

//				customValidator.validate(poInfoDtlVO, bindingResult, PoInfoDtlVO.InsertAndUpdate.class);

//				if(bindingResult.hasErrors()) {
//					//파라미터 중 하나라도 값이 없으면 BL 판매중지로 업데이트
//					poInfoDtlVO.setSleSttusCode("03");
//					poInfoUpdateMapper.updateItBlInfoBas(poInfoDtlVO);
//					poInfoUpdateMapper.insertItBlInfoBasHst(poInfoDtlVO);
//				}

				// Lot 전송 여부(Y-전송,N-미전송)가 Y인 경우만 처리
				if ("Y".equals(poInfoDtlVO.getLotSndYn())) {
					// lot정보 리스트 업데이트
					for (LotInfoDtlVO lotInfoDtlVO : poInfoDtlVO.getLotNoList()) {

						// 인터페이스 id 세팅하여 등록자아이디, 수정자아이디로 사용한다.
						lotInfoDtlVO.setIntrfcId("SOREC-IF-150");
						// bl번호 세팅
						lotInfoDtlVO.setBlNo(poInfoDtlVO.getBlNo());
						// 통관일자는 poInfoDtlVO에 enterDe로 세팅한다.
						lotInfoDtlVO.setEntrDe(poInfoDtlVO.getEnterDe());

						poInfoUpdateMapper.mergeItLotInfoBas(lotInfoDtlVO);
						poInfoUpdateMapper.insertItLotInfoBasHst(lotInfoDtlVO);

					}
				}

//				commonService.blSleSttusCodeChg(poInfoDtlVO.getBlNo());
				commonService.blSleSttusCodeChg(poInfoDtlVO.getBlNo(), "BlSleSttusCodeChg API(150)");

				/*
				 * bl 판매상태변경 CommonService -
				 * commonService.blSleSttusCodeChg(poInfoDtlVO.getBlNo()); 으로 변경
				 *
				 * blSleSttusCodeChgVO =
				 * poInfoUpdateMapper.selectBlSleSttusCodeChgData(poInfoDtlVO.getBlNo());
				 * 
				 * if (blSleSttusCodeChgVO != null && !"".equals(blSleSttusCodeChgVO.getBlNo()))
				 * { blSleSttusCodeChgVO.setLastChangerId("BlSleSttusCodeChg API(150)");
				 * 
				 * blNo = blSleSttusCodeChgVO.getBlNo(); blExpiryYn =
				 * blSleSttusCodeChgVO.getBlExpiryYn(); decimalYn =
				 * blSleSttusCodeChgVO.getDecimalYn(); fshgManageNo =
				 * blSleSttusCodeChgVO.getFshgManageNo(); sleSttusCode =
				 * blSleSttusCodeChgVO.getSleSttusCode(); // fshgManageNo =
				 * blSleSttusCodeChgVO.getFshgManageNo(); // ftrsThsexCntrctNo =
				 * blSleSttusCodeChgVO.getFtrsThsexCntrctNo(); // fshgManageNoCnt =
				 * blSleSttusCodeChgVO.getFshgManageNoCnt(); entrAt =
				 * blSleSttusCodeChgVO.getEntrAt(); sleImprtyResn = ""; ftrsDelngLotOrgQy =
				 * blSleSttusCodeChgVO.getFtrsDelngLotOrgQy(); fshgDlryOrgWt =
				 * blSleSttusCodeChgVO.getFshgDlryOrgWt(); fshgDelngDollarOrgAmount =
				 * blSleSttusCodeChgVO.getFshgDelngDollarOrgAmount();
				 * 
				 * //BL 판매상태코드 04(만기경과)로 업데이트 if("Y".equals(blExpiryYn) ||
				 * "".equals(fshgManageNo) || fshgManageNo == null || fshgManageNoCnt < 1 ||
				 * "Y".equals(decimalYn) || !"Y".equals(entrAt) || ftrsDelngLotOrgQy == null ||
				 * fshgDlryOrgWt == null || fshgDelngDollarOrgAmount == null) { //만기경과(판매중지) 상태가
				 * 아닌 BL만 업데이트 if(!"04".equals(sleSttusCode)) { log.debug(
				 * "=========================STOP========================================");
				 * log.debug("BL_NO                 :" + blNo);
				 * log.debug("BL_SEL_STOP_YN        :" + blExpiryYn);
				 * log.debug("DECIMAL_YN            :" + decimalYn);
				 * log.debug("FSHG_MANAGE_NO        :" + fshgManageNo);
				 * log.debug("FSHG_MANAGE_NO_CNT    :" + fshgManageNoCnt);
				 * log.debug("ENTR_AT               :" + entrAt);
				 * log.debug("SLE_STTUS_CODE        :" + sleSttusCode);
				 * log.debug("SLE_IMPRTY_RESN_CODE  :" + sleImprtyResn);
				 * log.debug("FTRS_DELNG_LOT_ORG_QY :" + ftrsDelngLotOrgQy);
				 * log.debug("FSHG_DLRY_ORG_WT      :" + fshgDlryOrgWt);
				 * log.debug("FSHG_DELNG_DOLLAR_ORG_AMOUNT :" + fshgDelngDollarOrgAmount);
				 * log.debug("================================================================="
				 * );
				 * 
				 * if ("Y".equals(blExpiryYn)) { // 만기경과 sleImprtyResn += "만기경과"; }
				 * 
				 * if (!"Y".equals(entrAt)) { // 미통관 if (!"".equals(sleImprtyResn)) {
				 * sleImprtyResn += ","; } sleImprtyResn += "미통관"; }
				 * 
				 * if ("".equals(fshgManageNo) || fshgManageNo == null || fshgManageNoCnt < 1) {
				 * if (!"".equals(sleImprtyResn)) { sleImprtyResn += ","; } // 선물환관리번호 불일치
				 * sleImprtyResn += "선물환관리번호 불일치"; }
				 * 
				 * // if("".equals(ftrsThsexCntrctNo) || ftrsThsexCntrctNo == null) { //
				 * if(!"".equals(sleImprtyResn)) { // sleImprtyResn += ","; // } // //삼성선물계약번호
				 * 미존재 // sleImprtyResn += "삼성선물계약번호 미존재"; // }
				 * 
				 * if ("Y".equals(decimalYn)) { if (!"".equals(sleImprtyResn)) { sleImprtyResn
				 * += ","; } // 선물환달러금액/선물환배부중량 나머지 소수점 sleImprtyResn +=
				 * "선물환달러금액/선물환배부중량 나머지 소수점"; }
				 * 
				 * if("".equals(ftrsDelngLotOrgQy) || ftrsDelngLotOrgQy == null) {
				 * if(!"".equals(sleImprtyResn)) { sleImprtyResn += ","; } sleImprtyResn +=
				 * "선물 최초 수량정보 미존재"; }
				 * 
				 * 
				 * if("".equals(fshgDlryOrgWt) || fshgDlryOrgWt == null) {
				 * if(!"".equals(sleImprtyResn)) { sleImprtyResn += ","; } sleImprtyResn +=
				 * "선물 최초 중량정보 미존재"; }
				 * 
				 * if("".equals(fshgDelngDollarOrgAmount) || fshgDelngDollarOrgAmount == null) {
				 * if(!"".equals(sleImprtyResn)) { sleImprtyResn += ","; } sleImprtyResn +=
				 * "선물환 최초 체결 금액정보 미존재"; }
				 * 
				 * blSleSttusCodeChgVO.setSleSttusCode("04");
				 * blSleSttusCodeChgVO.setSleImprtyResn(sleImprtyResn);
				 * 
				 * poInfoUpdateMapper.updateItBlSleSttus(blSleSttusCodeChgVO);
				 * poInfoUpdateMapper.insertItBlInfoBasHst(blSleSttusCodeChgVO.getBlNo()); } }
				 * 
				 * //BL 판매상태코드 01(판매대기)로 업데이트 if("N".equals(blExpiryYn) &&
				 * !"".equals(fshgManageNo) && fshgManageNo != null && fshgManageNoCnt > 0 &&
				 * "N".equals(decimalYn) && "Y".equals(entrAt)) { //만기경과(판매중지) 상태인 BL만 업데이트
				 * if("04".equals(sleSttusCode)) { log.debug(
				 * "=========================READY========================================");
				 * log.debug("BL_NO                 :" + blNo);
				 * log.debug("BL_EXPIRY_YN          :" + blExpiryYn);
				 * log.debug("DECIMAL_YN            :" + decimalYn);
				 * log.debug("FSHG_MANAGE_NO        :" + fshgManageNo);
				 * log.debug("FSHG_MANAGE_NO_CNT    :" + fshgManageNoCnt);
				 * log.debug("ENTR_AT               :" + entrAt);
				 * log.debug("SLE_STTUS_CODE        :" + sleSttusCode);
				 * log.debug("================================================================="
				 * );
				 * 
				 * blSleSttusCodeChgVO.setSleSttusCode("01");
				 * blSleSttusCodeChgVO.setSleImprtyResn("");
				 * 
				 * poInfoUpdateMapper.updateItBlSleSttus(blSleSttusCodeChgVO);
				 * poInfoUpdateMapper.insertItBlInfoBasHst(blSleSttusCodeChgVO.getBlNo()); } } }
				 * 
				 */
			}

			btbLogVo.setIntrfcRspnsCode(ItConstants.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(ItConstants.SUCCESS_RESULT_MSG);

		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			throw new Exception(e.getMessage());
		} finally {
			/** 통합 로그 UPDATE **/
			httpClientHelper.updateBtbLog(btbLogVo);
		}
	}

	@Override
	public Map<String, Object> stsApRecptn(Map<String,Object> paramMap) throws Exception {
		Map<String, Object> response =  new HashMap<String, Object>();;
		List<Map<String, Object>> responseMapList = new ArrayList<>();
		List<PoInfoVO> blList = new ArrayList<>();
		/** 통합 로그 INSERT **/
		String intrfc_code = "SOREC-IF-153";
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, paramMap);

		try {
			// b2b cni api 호출
			response = this.extrlSysApiCall(intrfc_code, paramMap);
			//response > Map List
			responseMapList = (List<Map<String, Object>>) response.get("blList");
			//Map List > List<PoInfoVO>
			blList = objectMapper.convertValue(
					responseMapList,
					TypeFactory.defaultInstance().constructCollectionType(List.class, PoInfoVO.class)
			);
			//업데이트 및 히스토리 등록
			if(blList != null &&  blList.size() > 0) {
				for(PoInfoVO vo : blList) {
					vo.setLastChangerId(intrfc_code);
					poInfoUpdateMapper.updateStsApData(vo);
					commonService.insertTableHistory("IT_PURCHS_INFO_BAS",vo);
				}
			}
			btbLogVo.setIntrfcRspnsCode(ItConstants.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(ItConstants.SUCCESS_RESULT_MSG);

		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			throw new Exception(e);
		} finally {
			/** 통합 로그 UPDATE **/
			httpClientHelper.updateBtbLog(btbLogVo);
		}

		return response;
	}

	private Map<String, Object> extrlSysApiCall(String intrfc_code, Object data) throws Exception {
		BtoBReqEntity reqEntity = new BtoBReqEntity();
		/* 인터페이스 ID Setting */
		reqEntity.setInterfaceId(intrfc_code);
		/* Request Setting */
		reqEntity.setRequest(objectMapper.convertValue(data, Map.class));
		/* 호출 */
		BtoBResEntity resEntity = httpClientHelper.callApi(reqEntity);
		if (!StringUtils.equals(resEntity.getResultcode(), BtoBConstants.BTOB_CNI_SUCCESS_CODE)) {
			/* 에러 발생 */
			throw new Exception("External System API Call Failed \nCause : " + resEntity.getMessage());
		}
		/* 데이터 캐스팅 */
		Map<String, Object> response = (Map<String, Object>) resEntity.getResponse();
		log.debug("B2B CNI " + intrfc_code + " API Call Result : " + response);
		return response;

	}

}
