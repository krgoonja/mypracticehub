package com.sorincorp.api.it.model;

import java.io.Serializable;
import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class LotInfoDtlVO implements Serializable {/**
	 *
	 */
	private static final long serialVersionUID = 5703119054043249298L;

	private String blNo;
	/**
	 *
	 */
	private String lotNo;
	/**
	 *
	 */
	private String lotNetWt;
	/**
	 *
	 */
	private String lotGrossWt;
	/**
	 *
	 */
	private String lotBadnAt;
	/**
	 *
	 */
	private String entrDe;
	/**
	 * 인터페이스 아이디
	 */
	private String intrfcId;

}
