package com.sorincorp.api.it.mapper;

import com.sorincorp.api.it.model.BlInfoDtlVO;

public interface BlInfoRecptnMapper {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 10. 20.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 10. 20.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param blInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int selectBlSleSetupChgCnt(BlInfoDtlVO blInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 10. 19.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 10. 19.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param blInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int mergeBlInfoBas(BlInfoDtlVO blInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 10. 21.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 10. 21.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param blInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	void deleteBlInfoBas(BlInfoDtlVO blInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 10. 21.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 10. 21.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param blInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int insertBlInfoBas(BlInfoDtlVO blInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 10. 19.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 10. 19.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param blInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int insertItBlInfoBasHst(BlInfoDtlVO blInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 10. 20.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 10. 20.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param blInfoDtlVO
	 * @return
	 */
	int updateBlInfoBasInvntryAtmcCalc(BlInfoDtlVO blInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 10. 21.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 10. 21.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param blInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int insertItBlInfoHistDtl(BlInfoDtlVO blInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 10. 20.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 10. 20.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param blInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int insertIfStsWrhousngPrearngeInvntryBas(BlInfoDtlVO blInfoDtlVO) throws Exception;

	int mergePoInfoBas(BlInfoDtlVO blInfoDtlVO) throws Exception;

	int insertItPurchsInfoBasHst(BlInfoDtlVO blInfoDtlVO) throws Exception;

}
