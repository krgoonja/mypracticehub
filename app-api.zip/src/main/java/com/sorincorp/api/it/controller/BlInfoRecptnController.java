package com.sorincorp.api.it.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.it.comm.ItConstants;
import com.sorincorp.api.it.comm.ItResponseEntity;
import com.sorincorp.api.it.model.BlInfoVO;
import com.sorincorp.api.it.service.BlInfoRecptnService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.validation.CustomValidator;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/sts")
@Api(value = "BL 정보 수신")
@ComponentScan("com.sorincorp.comm.*")
public class BlInfoRecptnController {

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private BlInfoRecptnService blInfoRecptnService;

	@Autowired
	private CustomValidator customValidator;

	@PostMapping("/bl_info")
	@ApiOperation(value = "BL정보 수신", notes = "STS에서 입고예정 BL 정보를 실시간으로 송신하고 SECS에서 정보를 수신한다.")
	public ResponseEntity<?> blInfoRecptn(@ApiParam(value = "BL정보수신 VO", required = true) @RequestBody BlInfoVO blInfoVO, HttpServletRequest request, BindingResult bindingResult) throws Exception {

		/** BTB CNI 인증 체크 **/
		if (!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		customValidator.validate(blInfoVO, bindingResult);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		blInfoRecptnService.mergeBlInfoBas(blInfoVO, bindingResult);

		return ResponseEntity.status(HttpStatus.OK).body(new ItResponseEntity(ItConstants.SUCCESS_RESULT_CODE, ItConstants.SUCCESS_RESULT_MSG));
	}
}
