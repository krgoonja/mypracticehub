package com.sorincorp.api.it.mapper;

import java.util.List;

import com.sorincorp.api.it.model.*;

public interface PoInfoMapper {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 3.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param poInfoDtlVO
	 * @throws Exception
	 */
	int updateItPurchsInfoBas(PoInfoDtlVO poInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 3.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param poInfoDtlVO
	 * @throws Exception
	 */
	int insertItPurchsInfoBasHst(PoInfoDtlVO poInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 3.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param lotInfoDtlVO
	 * @throws Exception
	 */
	int updateItLotInfoBas(LotInfoDtlVO lotInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 3.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param lotInfoDtlVO
	 * @throws Exception
	 */
	int insertItLotInfoBasHst(LotInfoDtlVO lotInfoDtlVO) throws Exception;

	int updateItLotInfoBas2(LotInfoDtlVO rspLotVO) throws Exception;

	int selectItPurchsInfoBasCnt(PoInfoDtlVO poInfoDtlVO) throws Exception;

	int selectItLotInfoBasCnt(LotInfoDtlVO lotInfoDtlVO) throws Exception;

	int mergeItPurchsInfoBas(PoInfoDtlVO poInfoDtlVO) throws Exception;

	int mergeItPurchsInfoBas2(PoInfoDtlVO rspVO) throws Exception;

	int mergeItLotInfoBas(LotInfoDtlVO rspLotVO) throws Exception;

	int updateItBlInfoBas(PoInfoDtlVO poInfoDtlVO) throws Exception;

	//int insertItBlInfoBasHst(PoInfoDtlVO poInfoDtlVO) throws Exception;
	int insertItBlInfoBasHst(String blNo) throws Exception;

	BlSleSttusCodeChgVO selectBlSleSttusCodeChgData(String blNo) throws Exception;

	void updateItBlSleSttus(BlSleSttusCodeChgVO vo)throws Exception;

	void updateStsApData(PoInfoVO vo)throws Exception;
}
