package com.sorincorp.api.it.mapper;

import com.sorincorp.api.it.model.ItemInfoDtlVO;
import com.sorincorp.api.it.model.ItemInfoSubDtlVO;

public interface ItemInfoMapper {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 29.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 29.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int selectItemInfoBasCnt(ItemInfoDtlVO itemInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 29.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 29.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int insertItemInfoBas(ItemInfoDtlVO itemInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 29.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 29.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int insertItemInfoBasHst(ItemInfoDtlVO itemInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 29.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 29.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int updateItemInfoBas(ItemInfoDtlVO itemInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 29.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 29.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int deleteItemInfoBas(ItemInfoDtlVO itemInfoDtlVO) throws Exception;

	int insertItItmStdSpecDtl(ItemInfoSubDtlVO itemInfoSubDtlVO) throws Exception;

	int updateItItmStdSpecDtl(ItemInfoSubDtlVO itemInfoSubDtlVO) throws Exception;

	int deleteItItmStdSpecDtl(ItemInfoSubDtlVO itemInfoSubDtlVO) throws Exception;

	int insertItItmStdSpecDtlHst(ItemInfoSubDtlVO itemInfoSubDtlVO) throws Exception;

	String selectUpdateDataEqYn(ItemInfoDtlVO itemInfoDtlVO) throws Exception;

}
