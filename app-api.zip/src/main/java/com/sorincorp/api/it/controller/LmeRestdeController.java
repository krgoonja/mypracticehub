package com.sorincorp.api.it.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.it.comm.ItConstants;
import com.sorincorp.api.it.comm.ItResponseEntity;
import com.sorincorp.api.it.model.LmeRestdeRecptnVO;
import com.sorincorp.api.it.service.LmeRestdeService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.validation.CustomValidator;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/sts")
@Api( value = "LME휴일 Controller")
@ComponentScan("com.sorincorp.comm.*")
public class LmeRestdeController {

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private LmeRestdeService lmeRestdeService;

	@Autowired
	private CustomValidator customValidator;


	/**
	 * <pre>
	 * STS에서 LME 휴일 정보를 수신하여 저장한다.
	 * </pre>
	 * @date 2021. 6. 24.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 24.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param lgistRestdeRecptnVO
	 * @param request
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/LmeRestdeRecptn")
	@ApiOperation(value = "LME 휴일 STS수신", notes = "LME 휴일관련 데이터 C/U/D")
	public ResponseEntity<?> LmeRestdeRecptn(@RequestBody LmeRestdeRecptnVO lmeRestdeRecptnVO
												, HttpServletRequest request
												, BindingResult bindingResult) throws Exception{

		/* 외부에 정보 제공을 위한 API일 경우 아래 함수 통과 후 서비스 로직 진행 */
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		/* 유효성 검사 */
		// validation을 수행한다, validation VO Class의 형식은 VO, List<Vo>, Map<VO> 가능
		// process별로 validation 수행 field 들을 나누고 싶다면 group interface class를 지정하여 사용한다. (VO에도 지정)
		customValidator.validate(lmeRestdeRecptnVO, bindingResult);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		/* 물류 휴일 저장 */
		lmeRestdeService.insertLmeRestde(lmeRestdeRecptnVO);

		return  ResponseEntity
				.status(HttpStatus.OK)
				.body(new ItResponseEntity(ItConstants.SUCCESS_RESULT_CODE, ItConstants.SUCCESS_RESULT_MSG));
	}

}
