package com.sorincorp.api.it.model;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@ApiModel("아이템정보 수신 Detail 서브정보 VO ")
public class ItemInfoSubDtlVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -4163443048755835114L;

	private String seq;
	/**
	 * Metal 정보
	 */
	private String metalInfo;
	/**
	 * Option 정보
	 */
	private String optionInfo;
	/**
	 * Spec1 정보
	 */
	private String spec1Info;
	/**
	 * Spec2 정보
	 */
	private String spec2Info;

	/**
	 * 생성 일자
	 */
	private String createDate;
	/**
	 * 생성 아이디 번호
	 */
	private String createUserNo;
	/**
	 * 업데이트 일자
	 */
	private String updateDate;
	/**
	 * 업데이트 아이디 번호
	 */
	private String updateUserNo;

	private String intrfcId;
}
