package com.sorincorp.api.it.model;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@ApiModel("브랜드정보 수신 VO")
public class BrandInfoDtlVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 3894291933384845315L;

	/** 인터페이스 번호 **/
	private int intrfcNo;

	/**
	 * 브랜드 코드
	 */
	@ApiModelProperty(value = "브랜드 코드", example = "AAR")
	@NotEmpty(message="{brandInfoDtlVO.code.isEmpty}")
	private String code;
	/**
	 * 브랜드 명
	 */
	private String brand;
	/**
	 * 주소
	 */
	private String addr;
	/**
	 * 금속 코드
	 */
	private String metal;
	/**
	 * 생산자 명
	 */
	private String producer;
	/**
	 * 생산 국가 코드
	 */
	private String country;
	/**
	 * 사용 여부
	 */
	private String useYN;
	/**
	 * 출처
	 */
	private String source;
	/**
	 * 생성 일자
	 */
	private String createDate;
	/**
	 * 생성 아이디 번호
	 */
	private String createUserNo;
	/**
	 * 업데이트 일자
	 */
	private String updateDate;
	/**
	 * 업데이트 아이디 번호
	 */
	private String updateUserNo;
	/**
	 * 인터페이스 구분(I/U/D)
	 */
	@ApiModelProperty(value = "인터페이스 구분", example = "I")
	@NotEmpty(message="{brandInfoDtlVO.intrfcSe.isEmpty}")
	private String intrfcSe;
	/**
	 * 인터페이스 ID
	 */
	private String intrfcId;

}
