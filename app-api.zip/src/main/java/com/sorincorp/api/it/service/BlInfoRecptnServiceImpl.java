package com.sorincorp.api.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import com.sorincorp.api.it.comm.ItConstants;
import com.sorincorp.api.it.mapper.BlInfoRecptnMapper;
import com.sorincorp.api.it.model.BlInfoDtlVO;
import com.sorincorp.api.it.model.BlInfoVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;
import com.sorincorp.comm.common.mapper.CommonMapper;
import com.sorincorp.comm.invntry.service.InvntrySttusService;
import com.sorincorp.comm.validation.CustomValidator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BlInfoRecptnServiceImpl implements BlInfoRecptnService {

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private BlInfoRecptnMapper blInfoRecptnMapper;

	@Autowired
	private CustomValidator customValidator;

	@Autowired
	private CommonMapper commonMapper;

	@Autowired
	InvntrySttusService invntrySttusService;

	@Override
	public void mergeBlInfoBas(BlInfoVO blInfoVO, BindingResult bindingResult) throws Exception {
		// TODO Auto-generated method stub
		/** 통합 로그 INSERT **/
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog("SOREC-IF-151", blInfoVO);

		int result = 0;
		int blSleSetupChgCnt = 0;
		int blInsCnt = 0;

		try {

			for (BlInfoDtlVO blInfoDtlVO : blInfoVO.getBlNoList()) {
				customValidator.validate(blInfoDtlVO, bindingResult, BlInfoDtlVO.InsertAndUpdate.class);

				if (bindingResult.hasErrors()) {
					log.error(bindingResult.getAllErrors().toString());
					// throw new Exception();
				}

				blInfoDtlVO.setIntrfcId("SOREC-IF-151");
				blInfoDtlVO.setIntrfcNo(btbLogVo.getIntrfcNo());
				// IF테이블 INSERT
				blInfoRecptnMapper.insertIfStsWrhousngPrearngeInvntryBas(blInfoDtlVO);

				// 판매설정 변경 카운트 조회
				blSleSetupChgCnt = blInfoRecptnMapper.selectBlSleSetupChgCnt(blInfoDtlVO);
				// 판매설정 변경 카운트 0일 경우만 MERGE
				if (blSleSetupChgCnt < 1) {
					blInfoDtlVO.setIntrfcId("SOREC-IF-151");

					// bl delete
					blInfoRecptnMapper.deleteBlInfoBas(blInfoDtlVO);

					// bl insert
					result = blInfoRecptnMapper.insertBlInfoBas(blInfoDtlVO);
					blInsCnt += result;

					if (result < 1) {
						btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
						btbLogVo.setIntrfcRspnsCn("insertBlInfoBas query excute result 0");
						throw new Exception("insertBlInfoBas query excute result 0");
					}

					// bl 재고 자동계산
					result = blInfoRecptnMapper.updateBlInfoBasInvntryAtmcCalc(blInfoDtlVO);
					if (result < 1) {
						btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
						btbLogVo.setIntrfcRspnsCn("updateBlInfoBasInvntryAtmcCalc query excute result 0");
						throw new Exception("updateBlInfoBasInvntryAtmcCalc query excute result 0");
					}

					// dtlHist insert
					result = blInfoRecptnMapper.insertItBlInfoHistDtl(blInfoDtlVO);
					if (result < 1) {
						btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
						btbLogVo.setIntrfcRspnsCn("insertItBlInfoHistDtl query excute result 0");
						throw new Exception("insertItBlInfoHistDtl query excute result 0");
					}

					// hst insert
//					result = blInfoRecptnMapper.insertItBlInfoBasHst(blInfoDtlVO);
					result = commonMapper.insertItBlInfoBasHst(blInfoDtlVO.getBlNo());
					if (result < 1) {
						btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
						btbLogVo.setIntrfcRspnsCn("insertItBlInfoBasHst query excute result 0");
						throw new Exception("insertItBlInfoBasHst query excute result 0");
					}
				}

				result = blInfoRecptnMapper.mergePoInfoBas(blInfoDtlVO);

				if (result < 1) {
					btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
					btbLogVo.setIntrfcRspnsCn("mergePoInfoBas query excute result 0");
					throw new Exception("mergePoInfoBas query excute result 0");
				}

//				result = blInfoRecptnMapper.insertItPurchsInfoBasHst(blInfoDtlVO);
				result = commonMapper.insertItPurchsInfoBasHst(blInfoDtlVO.getBlNo());
				if (result < 1) {
					btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
					btbLogVo.setIntrfcRspnsCn("insertItPurchsInfoBasHst query excute result 0");
					throw new Exception("insertItPurchsInfoBasHst query excute result 0");
				}
			}

			btbLogVo.setIntrfcRspnsCode(ItConstants.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(ItConstants.SUCCESS_RESULT_MSG);

			if (blInsCnt > 0) {
				// 20230710 srec0030 실시간 재고잔량 체크 메소드 호출
				invntrySttusService.invntrySttusMsgPublish();
			}

		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			throw new Exception(e.getMessage());
		} finally {
			/** 통합 로그 UPDATE **/
			httpClientHelper.updateBtbLog(btbLogVo);
		}
	}
}
