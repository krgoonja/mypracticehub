package com.sorincorp.api.it.service;

import org.springframework.validation.BindingResult;

import com.sorincorp.api.it.model.BlInfoVO;

public interface BlInfoRecptnService {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * 
	 * @date 2022. 10. 19.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 10. 19.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param blInfoVO
	 * @param bindingResult
	 */
	void mergeBlInfoBas(BlInfoVO blInfoVO, BindingResult bindingResult) throws Exception;

}
