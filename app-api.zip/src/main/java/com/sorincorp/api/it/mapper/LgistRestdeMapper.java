package com.sorincorp.api.it.mapper;

import java.util.Map;

import com.sorincorp.api.it.model.LgistRestdeRecptnVO;
import com.sorincorp.api.it.model.WrhousHolidayVO;

public interface LgistRestdeMapper {

	/**
	 * <pre>
	 * 창고휴일을 저장한다.
	 * </pre>
	 * @date 2021. 7. 27.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 27.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertLgistRestde(WrhousHolidayVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 창고휴일 저장 히스토리 등록
	 * </pre>
	 * @date 2021. 7. 27.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 27.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertLgistRestdeHst(WrhousHolidayVO vo) throws Exception;
}
