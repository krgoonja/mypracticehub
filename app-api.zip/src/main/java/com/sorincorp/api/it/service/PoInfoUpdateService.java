package com.sorincorp.api.it.service;

import org.springframework.validation.BindingResult;

import com.sorincorp.api.it.model.PoInfoVO;

import java.util.List;
import java.util.Map;

public interface PoInfoUpdateService {

	void updateItPurchsInfoBas(PoInfoVO poInfoVO, BindingResult bindingResult) throws Exception;

	/**
	 * <pre>
	 * 처리내용: STS AP UPDATE
	 * </pre>
	 * @date 2024.07.31
	 * @auther hamyoonsic
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024.07.31				hamyoonsic			최초작성
	 * -----------------------------------------------
	 * @param paramMap
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> stsApRecptn(Map<String,Object> paramMap) throws Exception;

}
