package com.sorincorp.api.it.model;

import java.io.Serializable;
import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class BlNoVO implements Serializable {

	private static final long serialVersionUID = 7427574051532754714L;
	/**
	 *	BL번호
	 */
	private String blNo;
	/**
	 * 주문번호
	 */
	private String orderNo;
	/**
	 * 라인번호
	 */
	private String lineNo;
}
