package com.sorincorp.api.it.service;

import com.sorincorp.api.it.model.BrandInfoVO;

public interface BrandInfoService {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 28.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 28.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandInfoVO
	 * @throws Exception
	 */
	void insertBrandInfoBas(BrandInfoVO brandInfoVO) throws Exception;

}
