package com.sorincorp.api.it.comm;

/**
 * <pre>
 * 처리내용: api - it 패키지의 공통 상수를 관리한다.
 * </pre>
 * ItConstants.java
 * @version
 * @since 2021. 6. 23.
 * @author srec0008
 * @history
 * ------------------------------------------------
 * 변경일					작성자				변경내용
 * ------------------------------------------------
 * 2021. 6. 23.			srec0008			최초작성
 * ------------------------------------------------
 */

public final class ItConstants {

	public static final String SUCCESS_RESULT_CODE = "200";
	public static final String ERROR_RESULT_CODE = "500";

	public static final String SUCCESS_RESULT_MSG = "Success";
	public static final String ERROR_RESULT_MSG = "Error";

}
