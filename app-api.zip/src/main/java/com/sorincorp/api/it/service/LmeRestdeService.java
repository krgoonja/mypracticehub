package com.sorincorp.api.it.service;

import com.sorincorp.api.it.model.LmeRestdeRecptnVO;

public interface LmeRestdeService {
	
	/**
	 * <pre>
	 * 물류휴일 등록 및 수정
	 * </pre>
	 * @date 2021. 6. 23.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 23.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	void insertLmeRestde(LmeRestdeRecptnVO vo) throws Exception; 


}
