package com.sorincorp.api.it.mapper;

import com.sorincorp.api.it.model.LmeCalListVO;

public interface LmeRestdeMapper {

	/**
	 * <pre>
	 * Lme 휴일을 등록한다
	 * </pre>
	 * @date 2021. 7. 27.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 27.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertLmeRestde(LmeCalListVO vo) throws Exception;
	
	/**
	 * <pre>
	 * Lme 휴일 히스토리를 등록한다.
	 * </pre>
	 * @date 2021. 7. 27.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 27.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertLmeRestdeHst(LmeCalListVO vo) throws Exception;
}
