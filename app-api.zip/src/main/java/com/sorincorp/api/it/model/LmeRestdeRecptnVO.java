package com.sorincorp.api.it.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * LmeRestdeRecptnVO.java
 * @version
 * @since 2021. 6. 25.
 * @author srec0008
 */
@Data
public class LmeRestdeRecptnVO{

	/**
	 * 인터페이스 구분
	 */
	@ApiModelProperty(value = "인터페이스 구분(I/U/D)", example = "I")
	@NotEmpty(message="{sampleVO.id.isEmpty}")
	private String intrfcSe;
	
	/**
	 * 수신 데이터 리스트
	 */
	private List<LmeCalListVO> lmeCalList;

}
