package com.sorincorp.api.it.model;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class BlInfoVO implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = -8917718872760354928L;

	@NotEmpty
	private List<BlInfoDtlVO> blNoList;

}
