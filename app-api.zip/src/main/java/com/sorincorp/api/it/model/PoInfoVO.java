package com.sorincorp.api.it.model;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class PoInfoVO implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 6301443862904883595L;

	private List<BlNoVO> blNoParamList;

	@NotEmpty
	private List<PoInfoDtlVO> blNoList;

	private List<PoInfoDtlVO> blNoRspList;

	/*	인터페이스 ID	*/
	private String intrfcId;
	/*	BL 번호	*/
	private String blNo;
	/*	구매 한도	*/
	private String purchQuota;
	/*	구매 주문 번호	*/
	private String purchsOrderNo;
	/*	구매 라인 번호	*/
	private String purchsLineNo;
	/*	구매 사업자	*/
	private String purchsBsnm;
	/*	구매 프리미엄 달러 가격	*/
	private java.math.BigDecimal purchsPremiumDollarAmount;
	/*	GROSS 중량	*/
	private java.math.BigDecimal grossWt;
	/*	LOT 수량	*/
	private int lotQy;
	/*	구매 무역 조건	*/
	private String purchsCmmrcCnd;
	/*	구매 단위 달러 가격	*/
	private java.math.BigDecimal purchsUnitDollarPc;
	/*	구매 LME 달러 가격	*/
	private java.math.BigDecimal purchsLmeDollarPc;
	/*	구매 원화 총액	*/
	private java.math.BigDecimal purchsWonAmount;
	/*	구매 달러 총액	*/
	private java.math.BigDecimal purchsDollarAmount;
	/*	도착항 명	*/
	private String arvlhangNm;
	/*	최종 등록자 아이디	*/
	private String frstRegisterId;
	/*	최조 등록 일시	*/
	private String frstRegistDt;
	/*	최종 변경자 아이디	*/
	private String lastChangerId;
	/*	최종 변경 일시	*/
	private String lastChangeDt;

}
