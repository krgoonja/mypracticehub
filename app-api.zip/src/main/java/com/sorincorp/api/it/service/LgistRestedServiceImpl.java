package com.sorincorp.api.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.it.mapper.LgistRestdeMapper;
import com.sorincorp.api.it.model.LgistRestdeRecptnVO;
import com.sorincorp.api.it.model.WrhousHolidayVO;
import com.sorincorp.api.lo.comm.constant.LoCommConstant;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LgistRestedServiceImpl implements LgistRestdeService{

	@Autowired
	private LgistRestdeMapper lgistRestdeMapper;

	@Autowired
	private HttpClientHelper httpClientHelper;


	@Override
	public void insertLgistRestde(LgistRestdeRecptnVO vo) throws Exception {

		/** 통합 로그 INSERT **/
		String intrfc_code = "SOREC-IF-091";
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, vo);

		try {
			for (WrhousHolidayVO wrhousHolidayVO : vo.getWrhousHolidayList()) {
				wrhousHolidayVO.setIntrfcSe(vo.getIntrfcSe());
				lgistRestdeMapper.insertLgistRestde(wrhousHolidayVO);
				lgistRestdeMapper.insertLgistRestdeHst(wrhousHolidayVO);
			}

		btbLogVo.setIntrfcRspnsCode(LoCommConstant.SUCCESS_RESULT_CODE);
		btbLogVo.setIntrfcRspnsCn(LoCommConstant.SUCCESS_RESULT_MSG);

		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			throw new Exception(e.getMessage());
		}

		/** 통합 로그 UPDATE **/
		httpClientHelper.updateBtbLog(btbLogVo);

	}

}
