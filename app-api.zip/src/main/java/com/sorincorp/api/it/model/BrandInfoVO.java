package com.sorincorp.api.it.model;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@ApiModel("브랜드정보 수신 VO")
public class BrandInfoVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -4728850653700418625L;
	/**
	 * 아이템정보 리스트
	 */
	@NotNull(message="{brandInfoVO.BrandList.isNull}")
	@NotEmpty(message="{brandInfoVO.BrandList.isEmpty}")
	private List<BrandInfoDtlVO> brandList;

}
