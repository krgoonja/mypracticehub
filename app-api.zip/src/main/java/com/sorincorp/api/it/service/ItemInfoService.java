package com.sorincorp.api.it.service;

import com.sorincorp.api.it.model.ItemInfoVO;

public interface ItemInfoService {

	void insertItemInfoBas(ItemInfoVO itemInfoVO) throws Exception;

}
