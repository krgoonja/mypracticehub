package com.sorincorp.api.it.controller;

import javax.servlet.http.HttpServletRequest;

import com.sorincorp.api.lo.comm.constant.LoCommConstant;
import com.sorincorp.api.lo.comm.entity.LoResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.it.comm.ItConstants;
import com.sorincorp.api.it.comm.ItResponseEntity;
import com.sorincorp.api.it.model.PoInfoVO;
import com.sorincorp.api.it.service.ItemInfoService;
import com.sorincorp.api.it.service.PoInfoUpdateService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.validation.CustomValidator;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/sts")
@Api( value = "PO 정보 수신")
@ComponentScan("com.sorincorp.comm.*")
public class PoInfoUpdateController {

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private PoInfoUpdateService poInfoUpdateService;

	@Autowired
	private CustomValidator customValidator;

	@PostMapping("/po_info")
	@ApiOperation(value = "PO정보 수신", notes = "EC와 BL단위의 PO 인터페이스 된 항목에 대해서 변경분에 대해서 실시간으로 송신한다.")
	public ResponseEntity<?> poInfoRecptn(@ApiParam(value = "PO정보수신 VO", required = true)
		@RequestBody PoInfoVO poInfoVO, HttpServletRequest request, BindingResult bindingResult) throws Exception{

		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		customValidator.validate(poInfoVO, bindingResult);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		poInfoUpdateService.updateItPurchsInfoBas(poInfoVO, bindingResult);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new ItResponseEntity(ItConstants.SUCCESS_RESULT_CODE, ItConstants.SUCCESS_RESULT_MSG));
	}

	@PostMapping("/stsApRecptn")
	@ApiOperation(value = "STS AP 정보 수신", notes = "실시간 STS AP 정보 업데이트")
	public Map<String, Object> stsApRecptn(@ApiParam(value = "STS AP 정보 수신 ", required = true)
										  @RequestBody Map<String,Object> paramMap, HttpServletRequest request) throws Exception{
		log.info("paramMap : {}", paramMap);
		return poInfoUpdateService.stsApRecptn(paramMap);
	}
}
