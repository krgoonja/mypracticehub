package com.sorincorp.api.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.it.comm.ItConstants;
import com.sorincorp.api.it.mapper.BrandInfoMapper;
import com.sorincorp.api.it.model.BrandInfoDtlVO;
import com.sorincorp.api.it.model.BrandInfoVO;
import com.sorincorp.comm.brandcode.mapper.BrandCodeMapper;
import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.brandgroupcode.mapper.BrandGroupCodeMapper;
import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;
import com.sorincorp.comm.util.CacheUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BrandInfoServiceImple implements BrandInfoService {

	@Autowired
	private BrandInfoMapper brandInfoMapper;
	@Autowired
	private BrandCodeMapper brandCodeMapper;
	@Autowired
	private BrandGroupCodeMapper brandGroupCodeMapper;
	@Autowired
	private CacheUtil cacheUtil;
	@Autowired
	private HttpClientHelper httpClientHelper;

	@Override
	public void insertBrandInfoBas(BrandInfoVO brandInfoVO) throws Exception {
		// TODO Auto-generated method stub

		/** 통합 로그 INSERT **/
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog("SOREC-IF-100", brandInfoVO);

		//브랜드 코드 카운트
		int brandCnt = 0;
		int brandDelCnt = 0;
		String updateDateEqYn = "N";
		//원장테이블 수행결과
		int basRtn = 0;
		//히스토리 테이블 수행결과
		int hstRtn = 0;

		try {

			/** 서비스 로직(원본/원복이력 table insert) **/
			for(BrandInfoDtlVO brandInfoDtlVO : brandInfoVO.getBrandList()) {
				//인터페이스 id 세팅하여 등록자아이디, 수정자아이디로 사용한다.
				brandInfoDtlVO.setIntrfcId("SOREC-IF-100");
				//브랜드 코드 카운트 조회
				brandCnt = brandInfoMapper.selectBrandInfoBasCnt(brandInfoDtlVO);
				brandDelCnt = brandInfoMapper.selectBrandInfoBasCnt2(brandInfoDtlVO);

				if("I".equals(brandInfoDtlVO.getIntrfcSe())) {
					//인터페이스 구분 I면 insert
					if(brandCnt == 0) {
						if(brandDelCnt < 1) {
							//중복 데이터 없을 경우 insert
							basRtn = brandInfoMapper.insertBrandInfoBas(brandInfoDtlVO);
							hstRtn = brandInfoMapper.insertBrandInfoBasHst(brandInfoDtlVO);

							if(basRtn < 1 || hstRtn < 1) {
								//원장테이블과 히스토리 테이블 둘중 하나라도 실패할 경우 에러처리
								btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);

								if(basRtn < 1) {
									btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_CODE);
									throw new Exception(ItConstants.ERROR_RESULT_MSG);
								} else  if(hstRtn < 1) {
									btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_CODE);
									throw new Exception(ItConstants.ERROR_RESULT_MSG);
								}
							}
						} else {
							//삭제건이 있을 경우 업데이트로 전환한다.
							basRtn = brandInfoMapper.updateBrandInfoBas(brandInfoDtlVO);
							hstRtn = brandInfoMapper.insertBrandInfoBasHst(brandInfoDtlVO);
						}
					} else {

						//등록할 데이터가 존재 이미 존재 할 경우 update
						updateDateEqYn = brandInfoMapper.selectUpdateDataEqYn(brandInfoDtlVO);

						if("N".equals(updateDateEqYn)) {
							basRtn = brandInfoMapper.updateBrandInfoBas(brandInfoDtlVO);
							hstRtn = brandInfoMapper.insertBrandInfoBasHst(brandInfoDtlVO);

							if(basRtn < 1 || hstRtn < 1) {
								//원장테이블과 히스토리 테이블 둘중 하나라도 실패할 경우 에러처리
								btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);

								if(basRtn < 1) {
									btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_MSG);
									throw new Exception(ItConstants.ERROR_RESULT_MSG);
								} else  if(hstRtn < 1) {
									btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_CODE);
									throw new Exception(ItConstants.ERROR_RESULT_MSG);
								}
							}
						}
					}

				} else if("U".equals(brandInfoDtlVO.getIntrfcSe())) {

					updateDateEqYn = brandInfoMapper.selectUpdateDataEqYn(brandInfoDtlVO);
					//log.debug("updateDateEqYn : " + updateDateEqYn);
					//인터페이스 구분 U면 update
					if(brandCnt == 1 && "N".equals(updateDateEqYn)) {
						//데이터 존재 할 경우 update
						basRtn = brandInfoMapper.updateBrandInfoBas(brandInfoDtlVO);
						hstRtn = brandInfoMapper.insertBrandInfoBasHst(brandInfoDtlVO);

						if(basRtn < 1 || hstRtn < 1) {
							//원장테이블과 히스토리 테이블 둘중 하나라도 실패할 경우 에러처리
							btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);

							if(basRtn < 1) {
								btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_MSG);
								throw new Exception(ItConstants.ERROR_RESULT_MSG);
							} else  if(hstRtn < 1) {
								btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_CODE);
								throw new Exception(ItConstants.ERROR_RESULT_MSG);
							}
						}
					} else if(brandCnt < 1){

						if(brandDelCnt > 0) {
							//데이터 존재 할 경우 update
							basRtn = brandInfoMapper.updateBrandInfoBas2(brandInfoDtlVO);
							hstRtn = brandInfoMapper.insertBrandInfoBasHst(brandInfoDtlVO);

							if(basRtn < 1 || hstRtn < 1) {
								//원장테이블과 히스토리 테이블 둘중 하나라도 실패할 경우 에러처리
								btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);

								if(basRtn < 1) {
									btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_MSG);
									throw new Exception(ItConstants.ERROR_RESULT_MSG);
								} else  if(hstRtn < 1) {
									btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_CODE);
									throw new Exception(ItConstants.ERROR_RESULT_MSG);
								}
							}
						} else {
							//수정할 데이터가 없으면 insert
							basRtn = brandInfoMapper.insertBrandInfoBas(brandInfoDtlVO);
							hstRtn = brandInfoMapper.insertBrandInfoBasHst(brandInfoDtlVO);

							if(basRtn < 1 || hstRtn < 1) {
								//원장테이블과 히스토리 테이블 둘중 하나라도 실패할 경우 에러처리
								btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);

								if(basRtn < 1) {
									btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_CODE);
									throw new Exception(ItConstants.ERROR_RESULT_MSG);
								} else  if(hstRtn < 1) {
									btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_CODE);
									throw new Exception(ItConstants.ERROR_RESULT_MSG);
								}
							}
						}
					}

				} else if("D".equals(brandInfoDtlVO.getIntrfcSe())) {
					//인터페이스 구분 D면 delete
					if(brandCnt == 1) {
						//데이터 존재 할 경우 delete
						basRtn = brandInfoMapper.deleteBrandInfoBas(brandInfoDtlVO);
						hstRtn = brandInfoMapper.insertBrandInfoBasHst(brandInfoDtlVO);

						if(basRtn < 1 || hstRtn < 1) {
							//원장테이블과 히스토리 테이블 둘중 하나라도 실패할 경우 에러처리
							btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);

							if(basRtn < 1) {
								btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_MSG);
								throw new Exception(ItConstants.ERROR_RESULT_MSG);
							} else  if(hstRtn < 1) {
								btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_CODE);
								throw new Exception(ItConstants.ERROR_RESULT_MSG);
							}
						}
					} else {
						//데이터 없을 경우 throw exception
						btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
						btbLogVo.setIntrfcRspnsCn(ItConstants.ERROR_RESULT_MSG);
						throw new Exception(ItConstants.ERROR_RESULT_MSG);
					}
				}
			}

			btbLogVo.setIntrfcRspnsCode(ItConstants.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(ItConstants.SUCCESS_RESULT_MSG);

			//Radis 정보 업데이트
			BrandCodeVO brandCodeVO = new BrandCodeVO();
			List<BrandCodeVO> brandCodeList = brandCodeMapper.getBrandCode(brandCodeVO);
			cacheUtil.put("brandCodeList", brandCodeList);

			BrandGroupCodeVO brandGroupCodeVO = new BrandGroupCodeVO();
			List<BrandGroupCodeVO> brandGroupCodeList = brandGroupCodeMapper.getBrandGroupCode(brandGroupCodeVO);
			cacheUtil.put("brandGroupCodeList", brandGroupCodeList);

		} catch(Exception e) {
			btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			throw new Exception(e.getMessage());
		} finally {
			/** 통합 로그 UPDATE **/
			httpClientHelper.updateBtbLog(btbLogVo);
		}

	}
}
