package com.sorincorp.api.it.model;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class BlInfoDtlVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -5032048779260835771L;

	public interface InsertAndUpdate {
	};

	/****** JAVA VO CREATE : IT_PURCHS_INFO_BAS(상품_PO 정보 기본) ******/
	/**
	 * BL 번호
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "BL 번호 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String blNo;
	/**
	 * 구매 주문 번호 (PO NO)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "창고 코드 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String wrhousCode;
	/**
	 * 구매 라인 번호 (lineNo)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "보관 위치 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String cstdyLc;
	/**
	 * 구매 한도 수량 (Quota)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "대분류 출고 권역 코드 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String lclsfDlivyDstrctCode;
	/**
	 * 구매 사업자 (ACCOUNT)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "중분류 출고 권역 코드 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String mlsfcDlivyDstrctCode;
	/**
	 * 구매 무역 조건 (ICT)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "금속 코드(아이템 그룹코드) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String metalCode;
	/**
	 * 구매 위치 명 (LOCATION)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "아이템 코드 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String itmCode;
	/**
	 * 구매 수량 (QTY)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "브랜드 코드 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String brandCode;
	/**
	 * 구매 LME 달러 가격 (LME)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "제품 명 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String prductNm;
	/**
	 * 구매 프리미엄 달러 금액 (PREM)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "번들 수량 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String bundleQy;
	/**
	 * 구매 단위 달러 가격 (U.PRICE)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "BL WT(N.W) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String blNetWt;
	/**
	 * 구매 달러 총액 (AMOUNT(USD))
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "BL WT(G.W) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String blGrossWt;
	/**
	 * 구매 원화 총액 (AMOUNT(KRW))
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "도착 예정 일자(ETA) - (YYYYMMDD) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String arvlPrearngeTime;
	/**
	 * 선물 계약 번호 (FS NO)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "입고 일시(YYYYMMDDHHMMSS) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String wrhousngDt;
	/**
	 * 선물 삼성 계약 번호 (삼성선물 NO)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "PO 헤더 번호(구매 주문 번호) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String orderId;
	/**
	 * 선물 거래 일시 (ORDER DATE)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "PO 디테일 번호(구매 라인 번호) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String orderDetailNo;
	/**
	 * 선물 거래 LOT 수량 (LOT)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "통관 여부 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String entrAt;
	/**
	 * 선물 거래 중량 (QTY)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "통관 일시(YYYYMMDDHHMMSS) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String entrDt;
	/**
	 * 선물 거래 옵션 (PRICE OPTION)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "화물 관리 번호 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String frghtManageNo;
	/**
	 * 선물 거래 시작 일자 (FROM)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "창고 도착일 - (YYYYMMDD) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String wrhousArvlde;
	/**
	 * 선물 거래 종료 일자 (TO)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "판매 가능일 - (YYYYMMDD) 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String slePossde;
	/**
	 * 선물 LME 달러 가격 (LME)
	 */
	@NotEmpty(groups = InsertAndUpdate.class, message = "입고 예정 재고 여부 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String wrhousngPrearngeInvntryAt;

	private String screofeFileCours;

	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;
	/**
	 * 인터페이스 구분(I,U,D)
	 */
	private String intrfcSe;
	/**
	 * 인터페이스 아이디
	 */
	private String intrfcId;
	private long intrfcSn;
	private long intrfcNo;

}
