package com.sorincorp.api.it.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.it.comm.ItConstants;
import com.sorincorp.api.it.comm.ItResponseEntity;
import com.sorincorp.api.it.model.BrandInfoVO;
import com.sorincorp.api.it.service.BrandInfoService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.validation.CustomValidator;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/sts")
@Api( value = "브랜드정보 수신")
@ComponentScan("com.sorincorp.comm.*")
public class BrandInfoController {

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private BrandInfoService brandInfoService;

	@Autowired
	private CustomValidator customValidator;

	@PostMapping("/brand_info")
	@ApiOperation(value = "브랜드정보 수신", notes = "트레이딩 브랜드 정보 EC에서 수신")
	public ResponseEntity<?> itemInfoRecptn(@ApiParam(value = "브랜드정보수신 VO", required = true)
		@RequestBody BrandInfoVO brandInfoVO, HttpServletRequest request, BindingResult bindingResult) throws Exception{

		/** BTB CNI 인증 체크 **/
		if(!httpClientHelper.specCheck(request)) {
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}

		customValidator.validate(brandInfoVO, bindingResult);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		brandInfoService.insertBrandInfoBas(brandInfoVO);

		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new ItResponseEntity(ItConstants.SUCCESS_RESULT_CODE, ItConstants.SUCCESS_RESULT_MSG));
	}

}
