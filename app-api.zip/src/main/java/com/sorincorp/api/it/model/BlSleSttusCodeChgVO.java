package com.sorincorp.api.it.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class BlSleSttusCodeChgVO extends CommonVO {
	/**
	 *
	 */
	private static final long serialVersionUID = -5683743891639018652L;

	private String blNo;
	private String blExpiryYn;
	private String decimalYn;
	private int fshgManageNoCnt;
	private String fshgManageNo;
	private String tktAmtSameYn;
	private String ftrsThsexCntrctNo;
	private String sleSttusCode;
	private String lastChangerId;
	private String entrAt;
	private String sleImprtyResn;
	private String ftrsDelngLotOrgQy;
	private String fshgDlryOrgWt;
	private String fshgDelngDollarOrgAmount;

}
