package com.sorincorp.api.it.model;

import javax.validation.constraints.NotEmpty;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * LmeRestdeRecptnVO.java
 * @version
 * @since 2021. 6. 25.
 * @author srec0008
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class LmeCalListVO{
	
	/* 회사 코드 */
	@ApiModelProperty(value = "회사 코드", example = "00001")
	@NotEmpty(message="{sampleVO.id.isEmpty}")
	private String companyCd;
	
	/* 일자 */
	@ApiModelProperty(value = "일자", example = "20210629")
	@NotEmpty(message="{sampleVO.id.isEmpty}")
	private String lmeDate;
	
	/* 요일 */
	@ApiModelProperty(value = "요일(일,월,화,수,목,금,토)", example = "화")
	@NotEmpty(message="{sampleVO.id.isEmpty}")
	private String weekday;
	
	/* 일자유형 */
	@ApiModelProperty(value = "일자유형 0:해당없음, 1:LME closed(휴일), 2:Weekend(휴일), 3:3rd Wednesday, 4;Non-LME prompts, 5:LME Week", example = "1")
	@NotEmpty(message="{sampleVO.id.isEmpty}")
	private String lmeCtype;
	
	/* 비고 */
	@ApiModelProperty(value = "비고", example = "비고입니다.")
	@NotEmpty(message="{sampleVO.id.isEmpty}")
	private String remark;
	
	/* 생성일시 */
	@ApiModelProperty(value = "생성일시 yyyyMMddHHmmssfff", example = "20210624145518330")
	@NotEmpty(message="{sampleVO.id.isEmpty}")
	private String createDate;
	
	/* 생성자 아이디 */
	@ApiModelProperty(value = "생성자 아이디", example = "admin")
	@NotEmpty(message="{sampleVO.id.isEmpty}")
	private String createUserId;
	
	/* 수정일시 */
	@ApiModelProperty(value = "수정일시 yyyyMMddHHmmssfff", example = "20210624145518330")
	@NotEmpty(message="{sampleVO.id.isEmpty}")
	private String updateDate;
	
	/* 수정자 아이디 */
	@ApiModelProperty(value = "수정자 아이디", example = "admin")
	@NotEmpty(message="{sampleVO.id.isEmpty}")
	private String updateUserId;
	
	/* 인터페이스 구분(I/U/D) */
	@ApiModelProperty(hidden = true)
	private String intrfcSe;
	
}
