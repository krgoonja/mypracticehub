package com.sorincorp.api.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.it.mapper.LmeRestdeMapper;
import com.sorincorp.api.it.model.LmeCalListVO;
import com.sorincorp.api.it.model.LmeRestdeRecptnVO;
import com.sorincorp.api.lo.comm.constant.LoCommConstant;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LmeRestedServiceImpl implements LmeRestdeService{

	@Autowired
	private LmeRestdeMapper lmeRestdeMapper;

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Override
	public void insertLmeRestde(LmeRestdeRecptnVO vo) throws Exception {

		String intrfc_code = "SOREC-IF-013";

		/** 통합 로그 INSERT **/
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfc_code, vo);

		try {

			for (LmeCalListVO lmeCalVO : vo.getLmeCalList()) {
				lmeCalVO.setIntrfcSe(vo.getIntrfcSe());
				lmeRestdeMapper.insertLmeRestde(lmeCalVO);
				lmeRestdeMapper.insertLmeRestdeHst(lmeCalVO);
			}

		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(LoCommConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			throw new Exception(e.getMessage());
		}

		/** 통합 로그 UPDATE **/
		httpClientHelper.updateBtbLog(btbLogVo);

	}

}
