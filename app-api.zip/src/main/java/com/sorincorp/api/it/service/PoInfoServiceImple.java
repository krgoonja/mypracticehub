package com.sorincorp.api.it.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.sorincorp.api.it.comm.ItConstants;
import com.sorincorp.api.it.mapper.PoInfoMapper;
import com.sorincorp.api.it.model.BlNoVO;
import com.sorincorp.api.it.model.LotInfoDtlVO;
import com.sorincorp.api.it.model.PoInfoDtlVO;
import com.sorincorp.comm.btb.comm.BtoBConstants;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;
import com.sorincorp.comm.btb.model.BtoBReqEntity;
import com.sorincorp.comm.btb.model.BtoBResEntity;
import com.sorincorp.comm.common.mapper.CommonMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PoInfoServiceImple implements PoInfoService {

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private PoInfoMapper poInfoUpdateMapper;

	@Autowired
	private CommonMapper commonMapper;

	@Override
	@Async
	public void updateItPurchsInfoBas(List<Map<String, String>> paramList) throws Exception {
		// TODO Auto-generated method stub
		/** 통합 로그 INSERT **/
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog("SOREC-IF-054", paramList);

		Map<String, Object> blInfoReqMap = new HashMap<String, Object>();
		Map<String, Object> respMap = new HashMap<String, Object>();
		BlNoVO blNoVO = new BlNoVO();
		PoInfoDtlVO poInfoDtlVO = new PoInfoDtlVO();
		List<BlNoVO> blNoList = new ArrayList<BlNoVO>();

//		int tariffVal = 0;
//		int freeTime = 0;
//		int lgistCstdyWonCt = 0;
//		int poCnt = 0;

		try {
			for (int i = 0; i < paramList.size(); i++) {
				log.debug("blNo : " + paramList.get(i).get("blNo"));
				log.debug("orderNo : " + paramList.get(i).get("orderNo"));
				log.debug("lineNo : " + paramList.get(i).get("lineNo"));
				blNoVO.setBlNo(paramList.get(i).get("blNo"));
				blNoVO.setOrderNo(paramList.get(i).get("orderNo"));
				blNoVO.setLineNo(paramList.get(i).get("lineNo"));
				blNoList.add(blNoVO);

				poInfoDtlVO.setBlNo(blNoVO.getBlNo());
				poInfoDtlVO.setPurchsOrderNo(blNoVO.getOrderNo());
				poInfoDtlVO.setPurchsLineNo(blNoVO.getLineNo());
				poInfoDtlVO.setIntrfcId("SOREC-IF-54");
				// PO 기본 마스터 MERGE
				poInfoUpdateMapper.mergeItPurchsInfoBas(poInfoDtlVO);
//				poInfoUpdateMapper.insertItPurchsInfoBasHst(poInfoDtlVO);
				commonMapper.insertItPurchsInfoBasHst(poInfoDtlVO.getBlNo());
			}

			log.debug("=====================updateItPurchsInfoBas CALL API====================");

			blInfoReqMap = new HashMap<String, Object>();
			blInfoReqMap.put("blNoList", blNoList);

			BtoBReqEntity blInfoEntity = new BtoBReqEntity();
			blInfoEntity.setInterfaceId("SOREC-IF-54");
			blInfoEntity.setRequest(blInfoReqMap);

			// BtoBConstants.BTB_RESPONSE_API_KEY
			httpClientHelper.setHeader(blInfoEntity);

			/* 호출 */
			BtoBResEntity resEntity = httpClientHelper.callApi(blInfoEntity);

			if (!StringUtils.equals(resEntity.getResultcode(), BtoBConstants.BTOB_CNI_SUCCESS_CODE)) {
				/* 에러 발생 */
			}

			if (!StringUtils.equals(resEntity.getResultcode(), BtoBConstants.BTOB_CNI_SUCCESS_CODE)) {
				/* 에러 발생 */
			}

			/* 데이터 캐스팅 */
			Map<String, Object> response = (Map<String, Object>) resEntity.getResponse();

			log.debug("response : ", response.get("blNoRspList"));

			String respCode = (String) response.get("respCode");
			String respMssg = (String) response.get("respMssg");
			respMap.put("respCode", respCode);
			respMap.put("respMssg", respMssg);
			log.debug("respCode =========> " + respCode);
			log.debug("respMssg =========> " + respMssg);

			// List<PoInfoDtlVO> blNoRspList = (ArrayList<PoInfoDtlVO>)
			// response.get("blNoRspList");
			// List<PoInfoDtlVO> blNoRspList = (List<PoInfoDtlVO>)
			// response.get("blNoRspList");
			List<Map<String, Object>> blNoRspList = (List<Map<String, Object>>) response.get("blNoRspList");
			List<Map<String, Object>> lotNoList = null;
			PoInfoDtlVO rspVO = new PoInfoDtlVO();
			LotInfoDtlVO rspLotVO = new LotInfoDtlVO();

			log.debug("blNoRspList.size()           ==========>" + blNoRspList.size());

			if ("01".equals(respCode)) {

				for (Map<String, Object> blNoRsp : blNoRspList) {

					rspVO.setIntrfcId("SOREC-IF-54");
					rspVO.setBlNo((String) blNoRsp.get("blNo"));
					rspVO.setArvlhangNm((String) blNoRsp.get("arvlhangNm"));
					rspVO.setCrncyCode((String) blNoRsp.get("crncyCode"));
					rspVO.setCtSmWonCt((String) blNoRsp.get("ctSmWonCt"));
					rspVO.setEnterDe((String) blNoRsp.get("enterDe"));
					rspVO.setEntrCstmsWonCt((String) blNoRsp.get("cstmsWonCt"));
					rspVO.setEntrFeeWonCt((String) blNoRsp.get("entrFeeWonCt"));
					rspVO.setFnncEtcWonCt((String) blNoRsp.get("fnncEtcWonCt"));
					rspVO.setFnncIntrWonCt((String) blNoRsp.get("fnncIntrWonCt"));
					rspVO.setFreeTime((String) blNoRsp.get("freeTime"));
					rspVO.setFshgCntrctNo((String) blNoRsp.get("fshgCntrctNo"));
					rspVO.setFshgDelngCrncy((String) blNoRsp.get("fshgDelngCrncy"));
					rspVO.setFshgDelngDollarAmount((String) blNoRsp.get("fshgDelngDollarAmount"));
					rspVO.setFshgDelngDt((String) blNoRsp.get("fshgDelngDt"));
					rspVO.setFshgDlryWt((String) blNoRsp.get("fshgDlryWt"));
					rspVO.setFshgEndWonPc((String) blNoRsp.get("fshgEndWonPc"));
					rspVO.setFshgExprtnDe((String) blNoRsp.get("fshgExprtnDe"));
					rspVO.setFshgPrchasWonPc((String) blNoRsp.get("fshgPrchasWonPc"));
					rspVO.setFshgWonEhgt((String) blNoRsp.get("fshgWonEhgt"));
					rspVO.setFshgWonSpread((String) blNoRsp.get("fshgWonSpread"));
					rspVO.setFtrsCntrctNo((String) blNoRsp.get("ftrsCntrctNo"));
					rspVO.setFtrsDelngBeginDe((String) blNoRsp.get("ftrsDelngBeginDe"));
					rspVO.setFtrsDelngDt((String) blNoRsp.get("ftrsDelngDt"));
					rspVO.setFtrsDelngEndDe((String) blNoRsp.get("ftrsDelngEndDe"));
					rspVO.setFtrsDelngLotQy((String) blNoRsp.get("ftrsDelngLotQy"));
					rspVO.setFtrsDelngOptn((String) blNoRsp.get("ftrsDelngOptn"));
					rspVO.setFtrsDelngWt((String) blNoRsp.get("ftrsDelngWt"));
					rspVO.setFtrsDollarFee((String) blNoRsp.get("ftrsDollarFee"));
					rspVO.setFtrsEndDollarPc((String) blNoRsp.get("ftrsEndDollarPc"));
					rspVO.setFtrsExprtnDe((String) blNoRsp.get("ftrsExprtnDe"));
					rspVO.setFtrsLineNo((String) blNoRsp.get("ftrsLineNo"));
					rspVO.setFtrsLmeDollarPc((String) blNoRsp.get("ftrsLmeDollarPc"));
					rspVO.setFtrsThsexCntrctNo((String) blNoRsp.get("ftrsThsexCntrctNo"));
					rspVO.setGrossWt((String) blNoRsp.get("grossWt"));
					rspVO.setLgistEtcWonCt((String) blNoRsp.get("lgistEtcWonCt"));
					rspVO.setLgistLandTrnsprtWonCt((String) blNoRsp.get("lgistLandTrnsprtWonCt"));
					rspVO.setLgistTrnsprtWonCt((String) blNoRsp.get("lgistTrnsprtWonCt"));
					rspVO.setLgistLnlWonCt((String) blNoRsp.get("lgistLnlWonCt"));
					rspVO.setLgistSmWonCt((String) blNoRsp.get("lgistSmWonCt"));
					rspVO.setLgistTrminlUseWonCt((String) blNoRsp.get("lgistTrminlUseWonCt"));
					rspVO.setLgistTrnsprtWonCt((String) blNoRsp.get("lgistTrnsprtWonCt"));
					rspVO.setLotQy((String) blNoRsp.get("lotQy"));
					rspVO.setNetWt((String) blNoRsp.get("netWt"));
					rspVO.setPackngListFileCours((String) blNoRsp.get("packngListFileCours"));
					rspVO.setPrloadNm((String) blNoRsp.get("prloadNm"));
					rspVO.setPurchQuota((String) blNoRsp.get("purchQuota"));
					rspVO.setPurchsBsnm((String) blNoRsp.get("purchsBsnm"));
					rspVO.setPurchsCmmrcCnd((String) blNoRsp.get("purchsCmmrcCnd"));
					rspVO.setPurchsDollarAmount((String) blNoRsp.get("purchsDollarAmount"));
					rspVO.setPurchsLcNm((String) blNoRsp.get("purchsLcNm"));
					rspVO.setPurchsLineNo((String) blNoRsp.get("purchsLineNo"));
					rspVO.setPurchsLmeDollarPc((String) blNoRsp.get("purchsLmeDollarPc"));
					rspVO.setPurchsOrderNo((String) blNoRsp.get("purchsOrderNo"));
					rspVO.setPurchsPremiumDollarAmount((String) blNoRsp.get("purchsPremiumDollarAmount"));
					rspVO.setPurchsQy((String) blNoRsp.get("purchsQy"));
					rspVO.setPurchsUnitDollarPc((String) blNoRsp.get("purchsUnitDollarPc"));
					rspVO.setPurchsWonAmount((String) blNoRsp.get("purchsWonAmount"));
					rspVO.setScreofeFileCours((String) blNoRsp.get("screofeFileCours"));
					rspVO.setShipngDe((String) blNoRsp.get("shipngDe"));
					rspVO.setTariffVal((String) blNoRsp.get("tariffVal"));
					rspVO.setWrhousngDe((String) blNoRsp.get("wrhousngDe"));
//						//요율 값 int형변환
//						if(rspVO.getTariffVal() != null && !"".equals(rspVO.getTariffVal())) {
//							tariffVal = Integer.parseInt(rspVO.getTariffVal());
//						} else {
//							tariffVal = 0;
//						}
//						//프리타임 int형변환
//						if(rspVO.getFreeTime() != null && !"".equals(rspVO.getFreeTime())) {
//							freeTime = Integer.parseInt(rspVO.getFreeTime());
//						} else {
//							freeTime = 0;
//						}
//						//물류 보관 원화 비용 계산(요율 값 * 프리타임)
//						lgistCstdyWonCt = tariffVal * freeTime;
//						//물류 보관 원화 비용 세팅
//						rspVO.setLgistCstdyWonCt(lgistCstdyWonCt);

					log.debug("rspVO ===============>" + rspVO.toString());
					// poInfoUpdateMapper.updateItPurchsInfoBas(rspVO);
					// PO 기본 마스터 MERGE
					poInfoUpdateMapper.mergeItPurchsInfoBas2(rspVO);
//					poInfoUpdateMapper.insertItPurchsInfoBasHst(rspVO);
					commonMapper.insertItPurchsInfoBasHst(rspVO.getBlNo());

					lotNoList = (List<Map<String, Object>>) blNoRsp.get("lotNoList");

					// rspVO.setLotNoList(lotNoList);

					for (Map<String, Object> lotNoRsp : lotNoList) {
						rspLotVO.setIntrfcId("SOREC-IF-54");
						// bl번호 세팅
						rspLotVO.setBlNo(rspVO.getBlNo());
						// 통관일자는 poInfoDtlVO에 enterDe로 세팅한다.
						rspLotVO.setEntrDe(rspVO.getEnterDe());
						rspLotVO.setLotNo((String) lotNoRsp.get("lotNo"));
						rspLotVO.setLotNetWt((String) lotNoRsp.get("lotNetWt"));
						rspLotVO.setLotGrossWt((String) lotNoRsp.get("lotGrossWt"));
						rspLotVO.setLotBadnAt((String) lotNoRsp.get("lotBadnAt"));

						log.debug("rspLotVO ===============>" + rspLotVO.toString());

						poInfoUpdateMapper.mergeItLotInfoBas(rspLotVO);
						poInfoUpdateMapper.insertItLotInfoBasHst(rspLotVO);
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			btbLogVo.setIntrfcRspnsCode(ItConstants.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			throw new Exception(e.getMessage());
		} finally {
			log.debug("=====================updateItPurchsInfoBas END====================");
			/** 통합 로그 UPDATE **/
			httpClientHelper.updateBtbLog(btbLogVo);
		}
	}

}
