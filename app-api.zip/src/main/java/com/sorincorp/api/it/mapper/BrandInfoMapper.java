package com.sorincorp.api.it.mapper;

import com.sorincorp.api.it.model.BrandInfoDtlVO;

public interface BrandInfoMapper {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 29.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 29.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int selectBrandInfoBasCnt(BrandInfoDtlVO brandInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 28.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 28.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int insertBrandInfoBas(BrandInfoDtlVO brandInfoDtlVO) throws Exception;

	int selectBrandInfoBasCnt2(BrandInfoDtlVO brandInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 28.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 28.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int updateBrandInfoBas(BrandInfoDtlVO brandInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 8. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int updateBrandInfoBas2(BrandInfoDtlVO brandInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 28.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 28.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int deleteBrandInfoBas(BrandInfoDtlVO brandInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 28.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 28.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	int insertBrandInfoBasHst(BrandInfoDtlVO brandInfoDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 8. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandInfoDtlVO
	 * @return
	 * @throws Exception
	 */
	String selectUpdateDataEqYn(BrandInfoDtlVO brandInfoDtlVO) throws Exception;

	int selectUpdateDataEqCnt(BrandInfoDtlVO brandInfoDtlVO) throws Exception;

}
