package com.sorincorp.api.it.model;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@ApiModel("아이템정보 수신 VO")
public class ItemInfoVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -5075996734251877919L;
	/**
	 * 아이템정보 리스트
	 */
	@NotNull(message="{itemInfoVO.ItemList.isNull}")
	@NotEmpty(message="{itemInfoVO.ItemList.isEmpty}")
	private List<ItemInfoDtlVO> itemList;
}
