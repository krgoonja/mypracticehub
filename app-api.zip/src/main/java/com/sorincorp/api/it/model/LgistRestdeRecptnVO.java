package com.sorincorp.api.it.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
public class LgistRestdeRecptnVO{
	
	/* 인터페이스 구분(I/U/D) */
	@ApiModelProperty(value = "인터페이스 구분(I/U/D)", example = "I")
	@NotEmpty(message="{sampleVO.id.isEmpty}")
	private String intrfcSe;
	
	/**
	 * 창고 휴일 목록
	 */
	private List<WrhousHolidayVO> wrhousHolidayList;
	
	
}
