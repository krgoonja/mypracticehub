package com.sorincorp.api.credt.service;

import java.text.DecimalFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.api.common.APICommConstant;
import com.sorincorp.api.common.ApiResponseEntity;
import com.sorincorp.api.credt.constant.MrtggConstant;
import com.sorincorp.api.credt.constant.MrtggConstant.MrtggRepySttusCode;
import com.sorincorp.api.credt.constant.MrtggConstant.MrtggSttusCode;
import com.sorincorp.api.credt.constant.MrtggConstant.RepySeCode;
import com.sorincorp.api.credt.dto.CredtMrtggTrnsmisDto;
import com.sorincorp.api.credt.mapper.MrtggMapper;
import com.sorincorp.api.credt.model.DlivyStpgeVO;
import com.sorincorp.api.credt.model.IfKoditMrtggOrderVO;
import com.sorincorp.api.credt.model.MbEntrpsMlgInfoDtlVO;
import com.sorincorp.api.credt.model.MbEntrpsMrtggLmtDtlVO;
import com.sorincorp.api.credt.model.OrMrtggBasVO;
import com.sorincorp.api.credt.model.OrMrtggDtlVO;
import com.sorincorp.api.lo.model.OrderSttusChgInfoVO;
import com.sorincorp.api.lo.service.LoService;
import com.sorincorp.api.or.constant.OrderConstant.SetleMthdCode;
import com.sorincorp.api.or.model.OrOrderBasVO;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.message.service.CdtlnMessageService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.mapper.CommPrvsnlOrderMapper;
import com.sorincorp.comm.order.model.CommPrvsnlOrderVO;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MrtggServiceImpl implements MrtggService {
	/** ewallet 주문 url **/
    @Value("${api.ewallet.order.url}")
    private String ewalletOrderUrl;
    
    @Value("${api.ewallet.timeout}")
    private int ewalletTimeoutsec;

	/** 공통 채번 서비스 */
	@Autowired
	private AssignService assignService;

	/** 이월렛 잔액조회 url */
//	@Value("${api.ewallet.money.url}")
//	private String ewalletAccountMoney;

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	SMSService smsService;
	
	/** 물류 서비스 **/
    @Autowired
    private LoService loService;
    
    @Autowired
    private CommonService commonService;
    
    @Autowired
	private MrtggMapper mrtggMapper;
    
    @Autowired
	private CommPrvsnlOrderMapper commPrvsnlOrderMapper;
	

	/** 전자상거래보증 매매계약 요청 URL */
	@Value("${credit.mrtgg.api.trnsmisrequst}")
	private String trnsmisRequstUrl;
	/** 전자상거래보증 부분상환 요청 URL */
	@Value("${credit.mrtgg.api.partrepy}")
	private String partRepyUrl;

	@Autowired
	CdtlnMessageService cdtlnMessageService;

	private static final String IF_RESPONSE_CODE = "responseCode";
	private static final String IF_RESPONSE_MSG = "responseMsg";



	@Override
	public ApiResponseEntity trnsmis(CredtMrtggTrnsmisDto param) throws Exception {

		ApiResponseEntity responseEntity = new ApiResponseEntity();

		try {
			// 담보상태코드에 따라 분기
			MrtggSttusCode type = MrtggSttusCode.codeOf(param.getMrtggSttusCode());

			if (MrtggSttusCode.REQUEST == type) { // 매매계약 요청
				trnsmisRequst(param);
			}
			else if (MrtggSttusCode.PARTREPY == type) { // 부분상환
				mrtggPartRepy(param);
			}
			else {
				throw new Exception("담보상태코드를 확인해주세요.");
			}
//			else if (MrtggSttusCode.SUCCESS == type) { // 매매계약 성공
////				trnsmisSucces
//			}
//			else if (MrtggSttusCode.REPYCOMPT == type) { // 상환완료
////				mrtggRepyCompt
//			}
//			else if (MrtggSttusCode.FAILR == type) { // 매매계약 실패
////				trnsmisFailr
//			}

		} catch (Exception e) {
			log.error(e.getMessage());
			responseEntity.setRspnsCode(APICommConstant.ERROR_RESULT_CODE);
			responseEntity.setRspnsMssage(e.getMessage());
			return responseEntity;
		}

		responseEntity.setRspnsCode(APICommConstant.SUCCESS_RESULT_CODE);

		return responseEntity;
	}

	public void trnsmisRequst(CredtMrtggTrnsmisDto paramDto) throws Exception {

		// 등록자, 수정자 인터페이스 번호 발급 없이 sorin 으로
		String intrfcCode = "KODIT-IF-001";

		// 통합 로그 INSERT
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfcCode, paramDto);
		btbLogVo.setIntrfcRspnsCode(APICommConstant.SUCCESS_RESULT_CODE);
		btbLogVo.setIntrfcRspnsCn(APICommConstant.SUCCESS_RESULT_MSG);
		intrfcCode += "(" + btbLogVo.getIntrfcNo() + ")";

		IfKoditMrtggOrderVO ifKoditMrtggOrderVo = new IfKoditMrtggOrderVO();

		try {
			// 1. 담보 매매계약 주문 정보 조회
			ifKoditMrtggOrderVo = selectIfKoditMrtggOrder(paramDto);

			// 여신 추가 2022.11
			SetleMthdCode setleMthdCodeType = SetleMthdCode.codeOf(ifKoditMrtggOrderVo.getSetleMthdCode());
//			SetleMthdDetailCode setleMthdDetailCodeType = SetleMthdDetailCode.codeOf(ifKoditMrtggOrderVo.getSetleMthdDetailCode());
//			CdtlnSvcSeCode cdtlnSvcSeCodeType = CdtlnSvcSeCode.codeOf(ifKoditMrtggOrderVo.getCdtlnSvcSeCode());

			// 여신 추가 2022.11 (여신일때 IF 전송 없이 성공 처리)
			if (SetleMthdCode.CDTLN == setleMthdCodeType) {
				ifKoditMrtggOrderVo.setMrtggSttusCode(MrtggSttusCode.SUCCESS.getCode());
			}

			// 재처리 호출시 로직 추가 (2022.09.07)
			if (paramDto.isRetry()) {
				log.info("전자상거래보증 매매계약 요청 (재처리)");

				String newMrtggNo = DateUtil.getNowDate() + "-"
						+ assignService.selectAssignValue("OR", "MRTGG_NO", DateUtil.getNowDate(), paramDto.getMberNo(), 5);

				OrMrtggBasVO newMrtggBasVo = OrMrtggBasVO.builder()
						.mrtggNo(newMrtggNo)
						.preMrtggNo(ifKoditMrtggOrderVo.getMrtggNo())
						.orderNo(ifKoditMrtggOrderVo.getOrderNo())
						.lastChangerId(paramDto.getMberNo())
						.build();

				// 여신 추가 2022.11 (여신일때 IF 전송 없이 성공 처리)
				if (SetleMthdCode.CDTLN == setleMthdCodeType) {
					log.info("전자상거래보증 매매계약 요청 (재처리) 여신으로 인한 완료 처리");
					newMrtggBasVo.setMrtggSttusCode(MrtggSttusCode.SUCCESS.getCode());
				} else {
					newMrtggBasVo.setMrtggSttusCode(MrtggSttusCode.REQUEST.getCode());
				}

				// 담보 기본 이전 데이터 삭제 (담보기본, 주문기본 데이터는 1:1 이였으므로 다른 곳에서 해당 로직으로 인한 오류 방지용 방어로직)
				if (1 > mrtggMapper.updatePreOrMrtggBas(newMrtggBasVo)) {
					log.error("담보 기본 이전 데이터 삭제 실패");
					throw new Exception("담보 기본 이전 데이터 삭제 실패");
				}
				mrtggMapper.insertOrMrtggBasHst(OrMrtggBasVO.builder()
						.mrtggNo(ifKoditMrtggOrderVo.getMrtggNo())
						.orderNo(ifKoditMrtggOrderVo.getOrderNo())
						.build());

				// 담보 기본 신규 데이터 생성
				if (1 > mrtggMapper.insertNewOrMrtggBas(newMrtggBasVo)) {
					log.error("담보 기본 재등록 실패");
					throw new Exception("담보 기본 재등록 실패");
				}
				mrtggMapper.insertOrMrtggBasHst(newMrtggBasVo);

				// 신규 담보번호 설정
				ifKoditMrtggOrderVo.setMrtggNo(newMrtggNo);
			}

			// 여신 추가 2022.11 (여신일때 IF 전송 없이 성공 처리)
			// 전자상거래 담보가 아니면 주문시 바로 완료 처리함
			if (SetleMthdCode.MRTGG == setleMthdCodeType) {

				// 처리상태코드 PROCESS_STTUS_CODE - 최초 등록 = "N"
				ifKoditMrtggOrderVo.setProcessSttusCode("N");
				ifKoditMrtggOrderVo.setFrstRegisterId(intrfcCode);
				ifKoditMrtggOrderVo.setLastChangerId(intrfcCode);

				// 2. 신보담보매매계약기본 IF T 등록 IF_KODIT_MRTGG_ORDER_BAS
				if (1 > mrtggMapper.insertIfKoditMrtggOrderBas(ifKoditMrtggOrderVo)) {
					log.error("매매계약 기본 IF 등록 실패");
					throw new Exception("매매계약 기본 IF 등록 실패");
				}

				// 3. 신보담보매매계약상세 IF T 등록 IF_KODIT_MRTGG_ORDER_DTL
				if (1 > mrtggMapper.insertIfKoditMrtggOrderDtl(ifKoditMrtggOrderVo)) {
					log.error("매매계약 상세 IF 등록 실패");
					throw new Exception("매매계약 상세 IF 등록 실패");
				}

				// 4. call api
				OrMrtggBasVO mrtggBasVo = OrMrtggBasVO.builder()
						.intrfcSn(ifKoditMrtggOrderVo.getIntrfcSn())
						.mrtggNo(ifKoditMrtggOrderVo.getMrtggNo())
						.orderNo(ifKoditMrtggOrderVo.getOrderNo())
						.preMrtggSttusCode(MrtggSttusCode.REQUEST.getCode())
						.lastChangerId(intrfcCode)
						.build();

				Map<String, Object> resultMap = Optional
						.ofNullable(httpClientHelper.postCallApi(trnsmisRequstUrl, Collections.singletonMap("intrfcSn", String.valueOf(ifKoditMrtggOrderVo.getIntrfcSn()))))
						.orElseThrow(() -> {
							mrtggBasVo.setMrtggSttusCode(MrtggSttusCode.FAILR.getCode());
							mrtggMapper.updateOrMrtggBasSttusCode(mrtggBasVo);
							mrtggMapper.insertOrMrtggBasHst(mrtggBasVo);

							log.error("매매계약 요청 API 실패");
							return new Exception("매매계약 요청 API 실패");
						});

				btbLogVo.setIntrfcRspnsCode(String.valueOf(resultMap.get(IF_RESPONSE_CODE)));
				btbLogVo.setIntrfcRspnsCn(String.valueOf(resultMap.get(IF_RESPONSE_MSG)));

				// 5. 결과 처리
				boolean isResult = true;
				if (!StringUtils.equals(String.valueOf(resultMap.get(IF_RESPONSE_CODE)), "0000")) {
					isResult = false;
					log.error("매매계약 요청 실패 사유 : {}", resultMap.get(IF_RESPONSE_MSG));
					mrtggBasVo.setMrtggSttusCode(MrtggSttusCode.FAILR.getCode());
				} else {
					mrtggBasVo.setMrtggSttusCode(MrtggSttusCode.SUCCESS.getCode());
				}

				// 담보기본 업데이트
				if (1 > mrtggMapper.updateOrMrtggBasSttusCode(mrtggBasVo)) {
					log.error("매매계약 담보 기본 상태 코드 업데이트 실패");
					throw new Exception("매매계약 담보 기본 상태 코드 업데이트 실패");
				}
				mrtggMapper.insertOrMrtggBasHst(mrtggBasVo);

				// 실패시 결과 노출을 위한 오류 결과 리턴
				if (!isResult) {
					log.error("매매계약요청 실패 : "+ resultMap.get(IF_RESPONSE_MSG));
					throw new Exception("매매계약요청 실패 : "+ resultMap.get(IF_RESPONSE_MSG));
				}
			}

		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(APICommConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());

			throw new Exception(e.getMessage());
		} finally {
			// 통합 로그 UPDATE
			httpClientHelper.updateBtbLog(btbLogVo);
		}

	}


	public void mrtggPartRepy(CredtMrtggTrnsmisDto paramDto) throws Exception {

		String intrfcCode = "KODIT-IF-002";
		paramDto.setIntrfcCode(intrfcCode);

		// 통합 로그 INSERT
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfcCode, paramDto);
		btbLogVo.setIntrfcRspnsCode(APICommConstant.SUCCESS_RESULT_CODE);
		btbLogVo.setIntrfcRspnsCn(APICommConstant.SUCCESS_RESULT_MSG);

		IfKoditMrtggOrderVO ifKoditMrtggOrderVo = new IfKoditMrtggOrderVO();

		try {
			// 주문 기본 조회
			OrOrderBasVO orderBasVo = selectOrderBas(paramDto);
			log.warn(">> [MrtggServiceImpl][mrtggPartRepy] orderBasVo : " + String.valueOf(orderBasVo));

			// 배치에서 미납 상환으로 호출시 mberId = BATCH
			if (StringUtil.isBlank(paramDto.getMberId())) {
				paramDto.setMberId(intrfcCode);
			}

			OrMrtggDtlVO mrtggDtlVo = null;

			// 담보 매매계약 주문 정보 조회
			ifKoditMrtggOrderVo = selectIfKoditMrtggOrder(paramDto);
			log.warn(">> [MrtggServiceImpl][mrtggPartRepy] ifKoditMrtggOrderVo : " + String.valueOf(ifKoditMrtggOrderVo));

			// 여신 추가 2022.11
			SetleMthdCode setleMthdCodeType = SetleMthdCode.codeOf(ifKoditMrtggOrderVo.getSetleMthdCode());
//			SetleMthdDetailCode setleMthdDetailCodeType = SetleMthdDetailCode.codeOf(ifKoditMrtggOrderVo.getSetleMthdDetailCode());
//			CdtlnSvcSeCode cdtlnSvcSeCodeType = CdtlnSvcSeCode.codeOf(ifKoditMrtggOrderVo.getCdtlnSvcSeCode());

			// 24-07-25 변경사항 : 중도상환 대상 주문이 미출고 상환 대상이면서 중량정산으로 호출됐을 경우, 상환 완료 여부에 따라 정산 처리를 하도록 로직 추가
			if(StringUtils.equals(orderBasVo.getPartDlivyRepyAt(), "Y")		// 중도 상환 대상 여부
					&& StringUtils.equals(ifKoditMrtggOrderVo.getNootgRepyExstAt(), "Y")	// 미출고 상환 대상 여부
					&& StringUtils.equals(paramDto.getRepySeCode(), RepySeCode.WT_EXCCLC.getCode())) {	// 상환구분 : 중량정산(01)
				
				// 정산 시 환불
				if(orderBasVo.getExcclcAmount() < 0) {
					if(StringUtils.equals(ifKoditMrtggOrderVo.getMrtggSttusCode(), "50")) {	// 담보 상태 코드 : 상환 완료(50)
						log.info("이미 상환 완료된 중도상환 대상 주문입니다(주문번호 : {}). 미정산된 정산 금액에 대해서 정산 처리를 시도합니다."
								, orderBasVo.getOrderNo());
						
						// OR_ORDER_BAS 에서 조회된 정산 금액 만큼 환불 처리
						this.ewalletTransfer(intrfcCode, orderBasVo);
						
						// 메소드 종료
						return;
					} else {
						log.info("중도 상환 + 미출고 상환 대상 주문의 환불 금액에 대한 처리는 하단의 처리 로직 미실행");
						return;
					}
				} else if(orderBasVo.getExcclcAmount() > 0) {	// 정산 시 추가 금액 발생
					log.info("중도 상환 + 미출고 상환 대상 주문의 추가 금액에 대한 처리는 하단의 처리 로직 실행");
				}
			}
			

			// 24-11-14 변경사항 : 가단가 주문(05)이 상환 완료되었으면, 추가 변동금에 대한 처리내역을 회원_업체 담보 한도 상세 테이블에 저장한다. (=여신 한도 회복) 
			if(orderBasVo.getCdtlnDdctTotAmount() != 0	// 가단가 주문(05) 이면서, 상환 처리가 필요한 추가 입금 금액이 존재
					&& StringUtils.equals(ifKoditMrtggOrderVo.getMrtggSttusCode(), "50")) {	// 담보 상태 코드 : 50 (상환 완료), 상환 완료 == 중량정산 완료
				// 거래금액을 차감된 총 추가변동금의 합으로 세팅
				paramDto.setSetleAmount(orderBasVo.getCdtlnDdctTotAmount());
				
				// 회원_업체 담보 한도 상세 update
				insertMbEntrpsMrtggLmtDtl(paramDto, ifKoditMrtggOrderVo, setleMthdCodeType);
				
				// 후속 로직 실행 필요 없음. 메소드 종료
				return;
			}

			// 2022.09.13 재처리시 로직 추가
			if (paramDto.isRetry()) {
				mrtggDtlVo = Optional.ofNullable(mrtggMapper.selectFailMrtggDtl(paramDto))
						.orElseThrow(()->{
							log.error("담보 상세 재처리 대상 데이터 조회 실패");
							return new Exception("담보 상세 재처리 대상 데이터 조회 실패");
						});
			}

			// 상환금 설정 및 담보기본 상태코드 설정
			setRepyAmountAndSttusCode(paramDto, orderBasVo, mrtggDtlVo);

			// 1. MP 상환 (담보상세 및 주문_담보 중도 상환 상세 수정)
			mrtggDtlVo = insertRepyOrMrtggDtl(paramDto, orderBasVo, setleMthdCodeType);
			
			// 24-01-17 변경사항 : 해당 주문이 평균가 주문(sleMthdCode : 04)이고,
			//						상환 구분이 중량 정산(repySeCode : 01) 또는 단가 정산(repySeCode : 03)일 경우
			//						이후의 로직을 실행하지 않음(SKIP, 메소드 종료 처리)
			// 24-01-24 변경사항 : 중량정산 및 단가정산이 모두 완료된 상황이면 중량/단가정산 로직을 실행하고 메소드 종료
			// 24-01-24 변경사항 : 확정단가로 시작하는 평균가 주문은 해당 로직을 수행하지 않도록 조건 추가
			//						(확정단가로 시작하는 평균가일 경우, 가단가가 없음(0)
			// 24-09-23 변경사항 : 신규 판매 방식 "가단가 주문(05)" 이 기존 판매 방식인 "평균가 주문(04)" 과 동일한 로직을 수행할 수 있도록 조건문 변경(간소화)
			RepySeCode repySeCode = RepySeCode.codeOf(paramDto.getRepySeCode());
			if(orderBasVo.getAvrgpcGoodsUntpc() != 0	// 평균가 상품 단가(가단가) 존재 == 평균가(04) 또는 가단가(05) 주문임
					&& (RepySeCode.WT_EXCCLC == repySeCode || RepySeCode.UNTPC_EXCCLC == repySeCode)) {
				log.info("해당 평균가 주문의 실제 {}은 SKIP 처리됨, 주문번호 : {}", repySeCode.toString(), orderBasVo.getOrderNo());
				
				// 중량정산 및 단가정산 모두 완료된 상황이면 중량/단가정산 로직 실행
				// 24-04-02 변경사항 : 로직 실행 조건 변경
				if(StringUtils.equals(orderBasVo.getOrderSttusCode(), "30")	// 중량 정산 완료 
						&& orderBasVo.getGoodsUntpc() != 0) {	// 단가 정산 완료
					log.info("중량정산 및 단가정산 모두 완료된 주문으로, 중량/단가정산 로직 실행");
					
					paramDto.setRepySeCode(RepySeCode.WT_AND_UNTPC_EXCCLC.getCode());
					this.mrtggPartRepy(paramDto);
				}
				
				return;
			}

			// 2. 담보 기본 미상환금액/상태코드 update
			// 3. 주문 기본 미결제금액 update, 여기 없음, 이월렛 모듈로 옮겨짐, 20240719 확인
			updateOrderNrdmpAmountAndSttusCode(paramDto);

			// 4. 회원 업체 담보 한도 상세 update
			insertMbEntrpsMrtggLmtDtl(paramDto, ifKoditMrtggOrderVo, setleMthdCodeType);
			
			// 24-10-31 변경사항 : 가단가 주문(05)의 중량/단가정산 시, 상환 처리된 추가 변동금에 대한 상세내역을 
			//                     회원_업체 담보 한도 상세 테이블과 주문_거래 정보 상세 테이블에 저장한다.
			if(orderBasVo.getCdtlnDdctTotAmount() != 0		// 가단가 주문(05) 이면서, 상환 처리가 필요한 추가 입금 금액이 존재
					&& paramDto.getRepySeCode() == RepySeCode.WT_AND_UNTPC_EXCCLC.getCode()) {	// 상환구분코드 - 중량/단가 정산
				
				// 로직 실행을 위한 데이터 객체를 새로 생성하고, 기존 데이터 객체를 deep copy
				CredtMrtggTrnsmisDto paramDtoForCdtlnDdctTotAmount = new CredtMrtggTrnsmisDto();
				BeanUtils.copyProperties(paramDto, paramDtoForCdtlnDdctTotAmount);
				
				// 담보 거래 금액(MRTGG_DELNG_AMOUNT) 으로 저장되는 결제 금액(SetleAmount)을 추가 입금 금액(CdtlnDdctTotAmount)으로 세팅
				paramDtoForCdtlnDdctTotAmount.setSetleAmount(orderBasVo.getCdtlnDdctTotAmount());
				
				// 회원_업체 담보 한도 상세 update
				insertMbEntrpsMrtggLmtDtl(paramDtoForCdtlnDdctTotAmount, ifKoditMrtggOrderVo, setleMthdCodeType);
			}

			// 여신 && 상환 && !재처리
			if (SetleMthdCode.CDTLN == setleMthdCodeType
					&& RepySeCode.RCPMNY == RepySeCode.codeOf(paramDto.getRepySeCode()) && !paramDto.isRetry()) {
				// 상환완료시 sms, email 발송
				sendCdtlnMessage(paramDto);
			}
			// 여신 외 기타 담보
			else if (SetleMthdCode.MRTGG == setleMthdCodeType) {
				// 5. 인터페이스 신보 담보 결제 등록 IF_KODIT_MRTGG_SETTLE_BAS
				paramDto.setIntrfcCode(intrfcCode + "(" + btbLogVo.getIntrfcNo() + ")"); // IF 등록용
				insertIfKoditMrtggSettleBas(paramDto, ifKoditMrtggOrderVo);

				// 6. call api
				Map<String, Object> resultMap = Optional
						.ofNullable(httpClientHelper.postCallApi(partRepyUrl, Collections.singletonMap("intrfcSn", String.valueOf(ifKoditMrtggOrderVo.getIntrfcSn()))))
						.orElseThrow(() -> {
							log.error("상환 요청 API 실패");
							return new Exception("상환 요청 API 실패");
						});

				btbLogVo.setIntrfcRspnsCode(String.valueOf(resultMap.get(IF_RESPONSE_CODE)));
				btbLogVo.setIntrfcRspnsCn(String.valueOf(resultMap.get(IF_RESPONSE_MSG)));

				// 7. 결과 처리
				mrtggDtlVo.setPreMrtggRepySttusCode(MrtggRepySttusCode.REQUEST.getCode());
				mrtggDtlVo.setIntrfcSn(ifKoditMrtggOrderVo.getIntrfcSn());

				// 성공시
				if (StringUtils.equals(String.valueOf(resultMap.get(IF_RESPONSE_CODE)), "0000")) {
					// 7-1. 담보 상세 상태값 set
					mrtggDtlVo.setMrtggRepySttusCode(MrtggRepySttusCode.SUCCESS.getCode());

					// 7-2. 상환완료시 sms, email 발송
					if (paramDto.getNrdmpAmount() == 0 && MrtggSttusCode.REPYCOMPT.getCode().equals(paramDto.getMrtggSttusCode())) {
						sendCdtlnMessage(paramDto);
					}
				}
				// 실패시
				else {
					log.error("상환 요청 실패 사유 : {}", resultMap.get(IF_RESPONSE_MSG));

					// 7-1. 담보 상세 상태값 set
					mrtggDtlVo.setMrtggRepySttusCode(MrtggRepySttusCode.FAILR.getCode());

					// 7-2. 담보 기본 미상환금액, 상태코드 update
					CredtMrtggTrnsmisDto rollbackParamDto = new CredtMrtggTrnsmisDto();
					BeanUtils.copyProperties(paramDto, rollbackParamDto);
					rollbackParamDto.setMrtggSttusCode(MrtggSttusCode.PARTREPY.getCode());
					rollbackParamDto.setNrdmpAmount(paramDto.getNrdmpAmount()+ paramDto.getSetleAmount()); // 미결제금액 증감
					// 중량정산시 주문기본 미납금을 업데이트 하므로 미납금이 재수정되지 않도록 상환구분코드를 강제로 변경 조치함
					rollbackParamDto.setRepySeCode(RepySeCode.RCPMNY.getCode());
					updateOrderNrdmpAmountAndSttusCode(rollbackParamDto);
				}

				// 7-1. 담보 상세 결과 업데이트
				if (1 > mrtggMapper.updateOrMrtggDtlSttusCode(mrtggDtlVo)) {
					log.error("주문 담보 상세 결과 등록 실패");
					throw new Exception("주문 담보 상세 결과 등록 실패");
				}
				mrtggMapper.insertOrMrtggDtlHst(mrtggDtlVo);
			}
			
			// 미납되어 출고 중지된 주문건에 대해 상환완료 시 출고 중지 해제 API 호출 및 SMS 전송
			try {
				this.callApiAndSmsDlivyStpgeRelisByRepyCompt(paramDto.getOrderNo(), paramDto.getSetleAmount());
			} catch(Exception e) {
				log.error("[MrtggServiceImpl][mrtggPartRepy] 미납되어 출고 중지된 주문건에 대해 상환완료 시 출고 중지 해제 API 호출 및 SMS 전송 ERROR: ", ExceptionUtils.getStackTrace(e));
			}
			
			// 24-07-25 변경사항 : 이번에 상환 완료 처리된 중도상환 대상 주문이 미출고 상환 대상이면서 이미 배송완료된 주문인 경우, 정산 금액에 대해서 정산 처리만 하도록 로직 추가
			if(StringUtils.equals(mrtggDtlVo.getMrtggRepySttusCode(), MrtggRepySttusCode.SUCCESS.getCode())	// 상환 성공
					&& StringUtils.equals(orderBasVo.getPartDlivyRepyAt(), "Y")		// 중도 상환 대상 여부
					&& StringUtils.equals(paramDto.getMrtggSttusCode(), "50")	// 담보 상태 코드 : 상환 완료(50)
					&& StringUtils.equals(ifKoditMrtggOrderVo.getNootgRepyExstAt(), "Y")	// 미출고 상환 대상 여부
					&& StringUtils.equals(orderBasVo.getOrderSttusCode(), "30")) {	// 주문 상태 코드 : 배송완료(30)
				log.info("중도상환 대상 주문입니다(주문번호 : {}). 미정산된 정산 금액에 대해서 정산 처리를 시도합니다."
							, orderBasVo.getOrderNo());
				
				// OR_ORDER_BAS 에서 조회된 정산 금액 만큼 환불 처리
				this.ewalletTransfer(intrfcCode, orderBasVo);
			}

		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(APICommConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());

			log.error(e.getMessage());
			throw new Exception("담보 부분상환 요청 등록 실패");
		} finally {
			// 통합 로그 UPDATE
			httpClientHelper.updateBtbLog(btbLogVo);
		}

	}

	/**
	 * <pre>
	 * 상환완료시 sms, email 발송
	 * </pre>
	 * @date 2022. 11. 16.
	 * @author srec0051
	 * @param paramDto
	 */
	private void sendCdtlnMessage(CredtMrtggTrnsmisDto paramDto) {
		// 중도 상환 순번이 존재하면 (null이 아니고 -1보다 클 때), 부분 출고 상환이고 이때 메일 전송은 하지 않는다.
		// 출고 완료 상황이어도 부분 출고 상환 건이면 보내지 않음
		if(paramDto.getMdstrmRepySn() != null && paramDto.getMdstrmRepySn() > -1) {
			log.warn(">>[MrtggServiceImpl][sendCdtlnMessage] 상환 완료 시 부분출고 상환은 메일 전송 안함 mdstrmRepySn : {}", paramDto.getMdstrmRepySn());
		} else {
			log.warn(">>[MrtggServiceImpl][sendCdtlnMessage] 상환 완료 시 부분출고 상환이 아닌 경우 메일 전송 mdstrmRepySn : {}", paramDto.getMdstrmRepySn());
			cdtlnMessageService.insertCdtlnMailSendReturnMailNo(paramDto.getOrderNo(), "57");	// ("57" 잔금결제완료)
		}
		
		cdtlnMessageService.insertCdtlnSmsReturnMssageNo(paramDto.getOrderNo(), Optional.ofNullable(paramDto.getMdstrmRepySn()).orElse(-1L), "68", null);	// ("68" 결제 완료 처리)
	}

	/**
	 * <pre>
	 * 인터페이스 신보 담보 결제 등록 IF_KODIT_MRTGG_SETTLE_BAS
	 * </pre>
	 * @date 2022. 8. 1.
	 * @author srec0051
	 * @param paramDto
	 * @param ifKoditMrtggOrderVo
	 * @throws Exception
	 */
	private void insertIfKoditMrtggSettleBas(CredtMrtggTrnsmisDto paramDto, IfKoditMrtggOrderVO ifKoditMrtggOrderVo)
			throws Exception {

		if (StringUtil.isBlank(paramDto.getMberId())) {
			ifKoditMrtggOrderVo.setFrstRegisterId(paramDto.getIntrfcCode());
			ifKoditMrtggOrderVo.setLastChangerId(paramDto.getIntrfcCode());
		} else {
			ifKoditMrtggOrderVo.setFrstRegisterId(paramDto.getMberId());
			ifKoditMrtggOrderVo.setLastChangerId(paramDto.getMberId());
		}

		ifKoditMrtggOrderVo.setMrtggDetailSn(paramDto.getMrtggDetailSn());
		ifKoditMrtggOrderVo.setSetleAmount(paramDto.getSetleAmount());
		ifKoditMrtggOrderVo.setNrdmpAmount(paramDto.getNrdmpAmount());
		ifKoditMrtggOrderVo.setRepySeCode(paramDto.getRepySeCode());
		ifKoditMrtggOrderVo.setProcessSttusCode("N"); // 처리상태코드 (최초 등록 = "N")

		log.debug("IF DATA ifKoditMrtggOrderVo : {}", ifKoditMrtggOrderVo.toString());

		if (1 > mrtggMapper.insertIfKoditMrtggSettleBas(ifKoditMrtggOrderVo)) {
			log.error("인터페이스 신보 담보 결제 등록 실패");
			throw new Exception("인터페이스 신보 담보 결제 등록 실패");
		}
	}

	/**
	 * <pre>
	 * 회원 업체 담보 한도 상세 update <br>
	 * 2022.09.13 재처리 로직 추가
	 * </pre>
	 * @date 2022. 8. 1.
	 * @author srec0051
	 * @param paramDto
	 * @param ifKoditMrtggOrderVo
	 * @throws Exception
	 */
	private void insertMbEntrpsMrtggLmtDtl(CredtMrtggTrnsmisDto paramDto, IfKoditMrtggOrderVO ifKoditMrtggOrderVo,
			SetleMthdCode setleMthdCodeType) throws Exception {

		// 재처리시 로직 PASS
		if (paramDto.isRetry()) {
			log.debug("재처리 진입으로 회원업체 로직 PASS");
			return;
		}

		RepySeCode repySeCode = RepySeCode.codeOf(paramDto.getRepySeCode());

		// 적요 : 결제방식상세 코드에 따라 분기될 수 있음
		String mrtggSumry = StringUtils.EMPTY;
		if (SetleMthdCode.CDTLN == setleMthdCodeType) {
			mrtggSumry = "케이지크레딧";
		} else if (SetleMthdCode.MRTGG == setleMthdCodeType) {
			mrtggSumry = "전자상거래보증";
		}

		// 회원 업체 담보 한도 상세 등록 기초 데이터 조회
		MbEntrpsMrtggLmtDtlVO memldVo = mrtggMapper.selectMbEntrpsMrtggLmtDtl(
				MbEntrpsMrtggLmtDtlVO.builder()
				.mrtggNo(paramDto.getMrtggNo())
				.orderNo(paramDto.getOrderNo())
				.grntyNo(ifKoditMrtggOrderVo.getGrntyNo()) // 보증번호
				.mrtggDelngAmount(paramDto.getSetleAmount()) // 담보거래금액
//					.mrtggBlce() // 담보잔액 (업체 보증번호의 총 잔액)
				.entrpsNo(paramDto.getEntrpsNo())
				.frstRegisterId(paramDto.getIntrfcCode())
				.lastChangerId(paramDto.getIntrfcCode())
				.build());


		if (null == memldVo || 0 == memldVo.getEntrpsMrtggCntrctSn()) {
			log.error("담보 기본 데이터 조회 실패 (null or 업체담보계약순번 is null)");
			throw new Exception("담보 기본 데이터 조회 실패 (null or 업체담보계약순번 is null)");
		}

		// 상환 구분에 따른 분리
		// 23-11-23 변경사항 : "단가정산"일 경우에도 동일 로직 수행하도록 조건문 추가
		// 24-01-17 변경사항 : "중량/단가 정산"일 경우에도 동일 로직 수행하도록 조건문 추가
		if (RepySeCode.WT_EXCCLC == repySeCode 
				|| RepySeCode.UNTPC_EXCCLC == repySeCode
				|| RepySeCode.WT_AND_UNTPC_EXCCLC == repySeCode) {
			
			// 24-04-19 변경사항 : 추가결제 case 분기처리
			if(paramDto.getSetleAmount() < 0) {
				memldVo.setMrtggDelngTyCode("08"); // 담보거래유형코드
				memldVo.setMrtggSumry("추가주문("+ mrtggSumry+ ")"); // 적요
			} else {
				memldVo.setMrtggDelngTyCode("04"); // 담보거래유형코드
				memldVo.setMrtggSumry("정산("+ mrtggSumry+ ")"); // 적요
			}
		}
		else if (RepySeCode.RCPMNY == repySeCode) {
			/**
			 * 중도상환은 마일리지 노출
			 * 1. 상환(전자상거래보증)
			 * 2. 중도상환(전자상거래보증)
			 */
			memldVo.setMrtggDelngTyCode("03");

			if ("N".equals(memldVo.getMdstrmRepyAt()) || memldVo.getUntpcIncrseAmount() < 1) {
				log.info("마일리지 없음 (중도상환이 아니거나 단가인상금액 없음)");
				memldVo.setMrtggSumry("상환("+ mrtggSumry+ ")"); // 적요

			} else {
				/**
				 * 마일리지 계산
				 *
				 * 1. 마일리지 = 담보대출금액*((적용일수-중도상환일수)/연간뱅킹데이) * (CD금리30일+케이지트레이딩가산금리)
				 * 2. 담보대출금액 = (주문기본단가-담보기본단가인상금액) * 주문기본실제주문수량
				 * 3. 적용일수 = 주문시 적용일수 - 담보보증 무이자 일수
				 * 4. 중도상환일수 = (세금계산서발행일+적용일) - 상환일
				 * 5. 1,000원 단위 올림 (엑셀의 roundup 과 동일)
				 * 6. CD금리, 케이지트레이딩가산금리 = 공통테이블 아닌, 담보기본 필드를 사용
				 */
				Long mdstrmRepyMileageAmt = getMdstrmRepyMileageAmt(paramDto);

				// 적립할 마일리지가 있을 때만 insert
				if (mdstrmRepyMileageAmt > 0) {
					DecimalFormat decFormat = new DecimalFormat("###,###");
			    	String formatStrMileageAmt = decFormat.format(mdstrmRepyMileageAmt);
					memldVo.setMrtggSumry("중도상환("+ mrtggSumry+ ") : "+ formatStrMileageAmt+ " 마일리지 적립"); // 적요

					// 회원_업체 마일리지 내역 상세 등록
					MbEntrpsMlgInfoDtlVO mileageVo = MbEntrpsMlgInfoDtlVO.builder()
							.orderNo(paramDto.getOrderNo())
							.canclExchngRtngudNo(MrtggConstant.BASIS_CANCL_EXCHNG_RTNGUD_NO)
							.entrpsNo(paramDto.getEntrpsNo())
							.mlgSe("01") // 마일리지구분 (01:적립,02:적립예정,03:사용)
							.mlgTy("09") // 마일리지유형 (09:중도상환)
							.mlgDetailDtls("중도상환 마일리지 적립") // 상세내역
							.delngMlg(mdstrmRepyMileageAmt.intValue()) // 적립 마일리지
							.grntyNo(ifKoditMrtggOrderVo.getGrntyNo()) // 보증번호
							.frstRegisterId(paramDto.getIntrfcCode())
							.lastChangerId(paramDto.getIntrfcCode())
							.build();

					if (1 > mrtggMapper.insertMbEntrpsMileage(mileageVo)) {
						String errMsg = "주문번호 : "+ paramDto.getOrderNo()+ ", 업체번호 : "+ paramDto.getEntrpsNo()+ ", 중도상환 마일리지 적립 실패";
						log.error(errMsg);
						// 실패 sms 발송 안하는걸로 2022.08.12	sendSmsMileageFail(errMsg); 20230103 sendSmsMileageFail 메소드 제거
					} else {
						log.debug("중도상환 마일리지 적립 데이터 - {}", mileageVo.toString());
						mrtggMapper.insertMbEntrpsMileageHst(mileageVo);
					}
				}
			}

		} else {
			log.error("비정상 상환구분코드 = "+ paramDto.getRepySeCode());
			throw new Exception("비정상 상환구분코드 = "+ paramDto.getRepySeCode());
		}

		log.debug("회원업체담보상세 insert before memldVo : "+ memldVo.toString());

		// 회원 업체 담보 한도 상세 등록
		if (1 > mrtggMapper.insertMbEntrpsMrtggLmtDtl(memldVo)) {
			log.error("회원 업체 담보 한도 상세 등록 실패");
			throw new Exception("회원 업체 담보 한도 상세 등록 실패");
		}

		log.debug("회원업체담보상세 insert after memldVo : "+ memldVo.toString());
		mrtggMapper.insertMbEntrpsMrtggLmtDtlHst(memldVo);
	}

	@Override
	public long getMdstrmRepyMileageAmt(CredtMrtggTrnsmisDto paramDto) throws Exception {
		if (StringUtil.isNotBlank(paramDto.getMdstrmRepyDe())) {
			java.util.Date dt = DateUtil.getDate(paramDto.getMdstrmRepyDe(), "yyyyMMdd");
			if (null == dt) {
				log.error("유효한 중도상환일이 아닙니다. MdstrmRepyDe : {}", paramDto.getMdstrmRepyDe());
				throw new IllegalArgumentException("유효한 중도상환일이 아닙니다.");
			}
		}

		long amt = mrtggMapper.getMdstrmRepyMileage(paramDto);
		log.info("계산된 마일리지 : {}", amt);
		return amt;
	}

	/**
	 * <pre>
	 * 상환금 설정 및 담보기본 상태코드 설정
	 * </pre>
	 * @date 2022. 8. 1.
	 * <br>2022. 9. 13 재처리 로직 추가
	 * @author srec0051
	 * @param paramDto
	 * @param orderBasVo
	 * @param mrtggDtlVo
	 * @throws Exception
	 */
	private void setRepyAmountAndSttusCode(CredtMrtggTrnsmisDto paramDto, OrOrderBasVO orderBasVo, OrMrtggDtlVO mrtggDtlVo)
			throws Exception {

		RepySeCode repySeCode = RepySeCode.codeOf(paramDto.getRepySeCode());

		if (!paramDto.isRetry()) {
			// 중량정산
			if (RepySeCode.WT_EXCCLC == repySeCode) {
				log.info("setRepyAmountAndSttusCode ::: 중량정산");
				
				// 중량정산금이 음수이므로 양수로 치환
				long excclcAmount = orderBasVo.getExcclcAmount() * -1;
				
				if (0 != orderBasVo.getExcclcAmount()) {
					// "SKIP" case
					// 24-09-23 변경사항 : 신규 판매 방식 "가단가 주문(05)" 이 기존 판매 방식인 "평균가 주문(04)" 과 동일한 로직을 수행할 수 있도록 조건문 변경(간소화)
					if(orderBasVo.getAvrgpcGoodsUntpc() != 0) {	// 평균가 상품 단가(가단가) 존재 == 평균가(04) 또는 가단가(05) 주문임
						paramDto.setSetleAmount(excclcAmount - orderBasVo.getTotSetleAmount());
						paramDto.setNrdmpAmount(Math.round((orderBasVo.getAvrgpcSplpc()) * 1.1));
					} else {
						paramDto.setSetleAmount(excclcAmount);
						// 미상환금액 = (주문)미납금 - (중량정산)결제금
						paramDto.setNrdmpAmount(orderBasVo.getUnSetleAmount());
					}
				} else if(0 == orderBasVo.getExcclcAmount()) {
					// 중량정산금이 없을 때(0일 때) == 확정된 단가가 없을때
					// 미납 금액 = (가단가 * 확정 중량) * 1.1
					double nrdmpAmount = orderBasVo.getAvrgpcGoodsUntpc() 
											* orderBasVo.getTotDcsnWt().doubleValue()
											+ orderBasVo.getExpectDlvrf();
					
					long setleAmount = Math.round((orderBasVo.getAvrgpcSplpc() - orderBasVo.getPcChangegld() - nrdmpAmount) * 1.1);
					
					paramDto.setSetleAmount(setleAmount);
					paramDto.setNrdmpAmount(orderBasVo.getUnSetleAmount());
				}

				paramDto.setMrtggSttusCode(MrtggSttusCode.PARTREPY.getCode());
			}
			// 단가정산
			else if (RepySeCode.UNTPC_EXCCLC == repySeCode) {
				log.info("setRepyAmountAndSttusCode ::: 단가정산");
				
				// 단가정산금이 음수이므로 양수로 치환
				long excclcAmount = orderBasVo.getExcclcAmount() * -1;
				
				if (0 != orderBasVo.getExcclcAmount()) {
					// "SKIP" case
					// 24-09-23 변경사항 : 신규 판매 방식 "가단가 주문(05)" 이 기존 판매 방식인 "평균가 주문(04)" 과 동일한 로직을 수행할 수 있도록 조건문 변경(간소화)
					if(orderBasVo.getAvrgpcGoodsUntpc() != 0) {	// 평균가 상품 단가(가단가) 존재 == 평균가(04) 또는 가단가(05) 주문임
						paramDto.setSetleAmount(excclcAmount - orderBasVo.getTotSetleAmount());
						paramDto.setNrdmpAmount(Math.round((orderBasVo.getAvrgpcSplpc()) * 1.1));
					} else {
						paramDto.setSetleAmount(excclcAmount);
						// 미상환금액 = (주문)미납금 - (단가정산)결제금
						paramDto.setNrdmpAmount(orderBasVo.getUnSetleAmount());
					}
				} else if(0 == orderBasVo.getExcclcAmount()) {
					// 단가정산금이 없을 때(0일 때) == 확정된 중량이 없을때
					// 미납 금액 = ( 확정 단가 * 가중량(주문 중량)
					//				+ 확정 단가 * 중량 변동
					//				+ 예상 배송비 )
					double nrdmpAmount = (orderBasVo.getGoodsUntpc() * orderBasVo.getTotRealOrderWt())
											+ (orderBasVo.getGoodsUntpc() * orderBasVo.getWtChange().doubleValue())
											+ orderBasVo.getExpectDlvrf(); 
					
					long setleAmount = Math.round((orderBasVo.getAvrgpcSplpc() - nrdmpAmount) * 1.1);
					
					paramDto.setSetleAmount(setleAmount);
					paramDto.setNrdmpAmount(orderBasVo.getUnSetleAmount());
				}
				
				paramDto.setMrtggSttusCode(MrtggSttusCode.PARTREPY.getCode());
			}
			// 24-01-17 변경사항 : 중량/단가 정산 case 추가
			// 중량/단가 정산
			else if (RepySeCode.WT_AND_UNTPC_EXCCLC == repySeCode) {
				log.info("setRepyAmountAndSttusCode ::: 중량/단가정산");
				
				// 정산금이 음수이므로 양수로 치환
				long excclcAmount = orderBasVo.getExcclcAmount() * -1;
				
				// 24-04-19 변경사항 : 추가 결제 금액 표현을 위해 분기 처리 구문 제거
				paramDto.setSetleAmount(excclcAmount);
				
				// 미상환금액 = (주문)미납금
				paramDto.setNrdmpAmount(orderBasVo.getUnSetleAmount());

				paramDto.setMrtggSttusCode(MrtggSttusCode.PARTREPY.getCode());
			}
			// 상환입금
			else if (RepySeCode.RCPMNY == repySeCode) {
				log.info("setRepyAmountAndSttusCode ::: 상환입금");
				long unSetleAmount = mrtggMapper.getNrdmpAmount(paramDto);

				paramDto.setSetleAmount(unSetleAmount);
				paramDto.setNrdmpAmount(0);
				paramDto.setMrtggSttusCode(MrtggSttusCode.REPYCOMPT.getCode());
			}
			// 미납상환
			// 24-07-11 참고사항 : 중도상환 대상인 주문 건도 해당 로직으로 수행됨. 실질적인 내부 로직은 변경 없음
			else if (RepySeCode.NYP_REPY == repySeCode) {
				log.info("setRepyAmountAndSttusCode ::: 미납상환");
				long unSetleAmount = mrtggMapper.getNrdmpAmount(paramDto);
				long setleAmount = mrtggMapper.getDelngAmount(paramDto);
				long nrdmpAmount = unSetleAmount - setleAmount;
				
				log.warn("unSetleAmount : {}, setleAmount : {}, nrdmpAmount : {}", unSetleAmount, setleAmount, nrdmpAmount);

				paramDto.setSetleAmount(setleAmount);
				paramDto.setNrdmpAmount(nrdmpAmount);

				// 미결제금액이 없다면 상환완료
				if (nrdmpAmount > 0) {
					paramDto.setMrtggSttusCode(MrtggSttusCode.PARTREPY.getCode());
				} else {
					paramDto.setMrtggSttusCode(MrtggSttusCode.REPYCOMPT.getCode());
				}

				// 이월렛을 처리 하고 후순위 처리 로직이므로 잔액이 없을 수 있음
	//			// 잔액 전체를 상환금액으로 (결제금액)
	//			Map<String, Object> accountRes = httpClientHelper.postCallApi(ewalletAccountMoney, Collections.singletonMap("entrpsNo", paramDto.getEntrpsNo()));
	//			if (null != accountRes && null != accountRes.get("data")) {
	//				Map<String, Object> dataObj = (Map<String, Object>) accountRes.get("data");
	//				long ewalletMoney = NumberUtils.toLong(String.valueOf(dataObj.get("delngAmount")));
	//			} else {
	//				throw new Exception("잔액조회 결과 없음");
	//			}

				// 미납상환일때 실제 없는 상태코드 이므로 상환으로 설정
				paramDto.setRepySeCode(RepySeCode.RCPMNY.getCode());
			}
		}
		else {
			log.info("setRepyAmountAndSttusCode ::: 재처리");

			paramDto.setSetleAmount(mrtggDtlVo.getSetleAmount());
			paramDto.setNrdmpAmount(mrtggDtlVo.getNrdmpAmount());

			if (mrtggDtlVo.getNrdmpAmount() > 0) {
				paramDto.setMrtggSttusCode(MrtggSttusCode.PARTREPY.getCode());
			} else {
				paramDto.setMrtggSttusCode(MrtggSttusCode.REPYCOMPT.getCode());
			}

			// 미납상환일때 실제 없는 상태코드 이므로 상환으로 설정
			if (RepySeCode.NYP_REPY == repySeCode) {
				paramDto.setRepySeCode(RepySeCode.RCPMNY.getCode());
			}
		}

		log.debug("결제금액 : {}, 미상환금액 : {}", paramDto.getSetleAmount(), paramDto.getNrdmpAmount());
	}

	/**
	 * <pre>
	 * 담보 매매계약 주문 정보 조회
	 * </pre>
	 * @date 2022. 7. 29.
	 * <br>2022.11 여신 로직 추가
	 * @author srec0051
	 * @param paramDto
	 * @return
	 * @throws Exception
	 */
	private IfKoditMrtggOrderVO selectIfKoditMrtggOrder(CredtMrtggTrnsmisDto paramDto) throws Exception {

		IfKoditMrtggOrderVO ifKoditMrtggOrderVo = Optional.ofNullable(mrtggMapper.selectIfKoditMrtggOrder(paramDto))
				.orElseThrow(()->{
					log.error("주문 정보 조회 실패");
					return new Exception("주문 정보 조회 실패");
				});

		// 전자상거래보증 번호 확인
		if (StringUtil.isBlank(ifKoditMrtggOrderVo.getGrntyNo())) {
			log.error("보증 번호 확인 불가");
			throw new Exception("보증 번호 확인 불가");
		}

		paramDto.setMrtggNo(ifKoditMrtggOrderVo.getMrtggNo());
		// 여신 추가 2022.11
		paramDto.setSetleMthdCode(ifKoditMrtggOrderVo.getSetleMthdCode());
		paramDto.setSetleMthdDetailCode(ifKoditMrtggOrderVo.getSetleMthdDetailCode());
		paramDto.setCdtlnSvcSeCode(ifKoditMrtggOrderVo.getCdtlnSvcSeCode());

		return ifKoditMrtggOrderVo;
	}

	/**
	 * <pre>
	 * 주문 기본 조회
	 * </pre>
	 * @date 2022. 7. 29.
	 * @author srec0051
	 * @param paramDto
	 * @return
	 * @throws Exception
	 */
	private OrOrderBasVO selectOrderBas(CredtMrtggTrnsmisDto paramDto) throws Exception {

		OrOrderBasVO orderBasVo = Optional.ofNullable(mrtggMapper.selectOrder(paramDto.getOrderNo()))
				.orElseThrow(()->{
					log.error("주문 기본 조회 실패");
					return new Exception("주문 기본 조회 실패");
				});

		// 23-11-23 변경사항 :
		// 평균가-평균가 주문에서 정산금액이 없는 상태로 부분 상환이 일어날 수 있으므로, 주석 처리
//		if (0 == orderBasVo.getExcclcAmount()) {
//			log.error("정산금액 조회 실패");
//			
//			throw new Exception("정산금액 조회 실패");
//		}

		paramDto.setEntrpsNo(orderBasVo.getEntrpsNo());

		return orderBasVo;
	}

	/**
	 * <pre>
	 * MP 상환 (담보상세 및 주문_담보 중도 상환 상세 수정)
	 * </pre>
	 * @date 2022. 8. 1.
	 * <br>2022. 9. 13 재처리 로직 추가
	 * <br>2022. 11 여신 로직 추가
	 * <br>2024. 07. 03 srec0049 주문_담보 중도 상환 상세 수정 추가 
	 * @author srec0051
	 * @param paramDto
	 * @throws Exception
	 */
	private OrMrtggDtlVO insertRepyOrMrtggDtl(CredtMrtggTrnsmisDto paramDto, OrOrderBasVO orderBasVo, SetleMthdCode setleMthdCodeType) throws Exception {

		OrMrtggDtlVO mrtggDtlVo = OrMrtggDtlVO.builder()
				.mrtggNo(paramDto.getMrtggNo())
				.setleAmount(paramDto.getSetleAmount()) // 결제금액
				.nrdmpAmount(paramDto.getNrdmpAmount()) // 미상환금액
				.repySeCode(paramDto.getRepySeCode()) // 상환구분코드
				.mdstrmRepySn(paramDto.getMdstrmRepySn()) //중도 상환 순번 (사용 안함 : -1 or null)
				.orderNo(paramDto.getOrderNo()) // 주문번호
				.frstRegisterId(paramDto.getIntrfcCode())
				.lastChangerId(paramDto.getIntrfcCode())
				.build();

		if (StringUtil.isNotBlank(paramDto.getMberId())) {
			mrtggDtlVo.setFrstRegisterId(paramDto.getMberId());
			mrtggDtlVo.setLastChangerId(paramDto.getMberId());
		}
		
		// 24-01-17 변경사항 : 해당 주문이 평균가 주문(sleMthdCode : 04)이고,
		//						상환 구분이 중량 정산(repySeCode : 01) 또는 단가 정산(repySeCode : 03)일 경우
		//						담보 상환 상태 코드를 99(SKIP) 로 세팅함
		// 24-01-24 변경사항 : 확정단가로 시작하는 평균가 주문은 해당 로직을 수행하지 않도록 조건 추가
		//						(확정단가로 시작하는 평균가일 경우, 가단가가 없음(0)
		// 24-09-23 변경사항 : 신규 판매 방식 "가단가 주문(05)" 이 기존 판매 방식인 "평균가 주문(04)" 과 동일한 로직을 수행할 수 있도록 조건문 변경(간소화)
		RepySeCode repySeCode = RepySeCode.codeOf(paramDto.getRepySeCode());
		
		if(orderBasVo.getAvrgpcGoodsUntpc() != 0	// 평균가 상품 단가(가단가) 존재 == 평균가(04) 또는 가단가(05) 주문임
				&& (RepySeCode.WT_EXCCLC == repySeCode || RepySeCode.UNTPC_EXCCLC == repySeCode)) {
			mrtggDtlVo.setMrtggRepySttusCode(MrtggRepySttusCode.SKIP.getCode());
		}
		// 여신 추가 2022.11 (여신일때 IF 전송 없이 성공 처리)
		else if (SetleMthdCode.CDTLN == setleMthdCodeType) {
			mrtggDtlVo.setMrtggRepySttusCode(MrtggRepySttusCode.SUCCESS.getCode());
		} else if (SetleMthdCode.MRTGG == setleMthdCodeType) {
			mrtggDtlVo.setMrtggRepySttusCode(MrtggRepySttusCode.REQUEST.getCode());
		} else {
			log.error("담보 상세 결제상세코드 확인불가");
			throw new Exception("담보 상세 결제상세코드 확인불가");
		}

		log.debug("담보상세 데이터 : {}", mrtggDtlVo.toString());

		if (!paramDto.isRetry()) {
			if (1 > mrtggMapper.insertOrMrtggDtl(mrtggDtlVo)) {
				log.error("담보 상세 등록 실패");
				throw new Exception("담보 상세 등록 실패");
			}
			paramDto.setMrtggDetailSn((int) mrtggDtlVo.getMrtggDetailSn());
		} else {
			mrtggDtlVo.setMrtggDetailSn(paramDto.getMrtggDetailSn());
			if (1 > mrtggMapper.updateFailToReqstOrMrtggDtl(mrtggDtlVo)) {
				log.error("담보 상세 수정 실패");
				throw new Exception("담보 상세 수정 실패");
			}
		}
		
		mrtggMapper.insertOrMrtggDtlHst(mrtggDtlVo);
		
		// 중도 상환 순번이 존재하면 (null이 아니고 -1보다 클 때), 주문_담보 중도 상환 상세의 담보 상세 순번 수정
		if(paramDto.getMdstrmRepySn() != null && paramDto.getMdstrmRepySn() > -1) {
			if (1 > mrtggMapper.updateRepyComptOrMrtggMdstrmRepyDtl(mrtggDtlVo)) {
				log.error("담보 중도 상환 상세 수정 실패");
				throw new Exception("담보 중도 상환 상세 수정 실패");
			}
			
			// 주문_담보 중도 상환 상세 이력 등록
			mrtggMapper.insertOrMrtggMdstrmRepyDtlHst(mrtggDtlVo);
		}
		
		return mrtggDtlVo;
	}

	/**
	 * <pre>
	 * 담보 기본 미상환금액, 상태코드 update<br>
	 * 주문 기본 미결제금액 update
	 * </pre>
	 * @date 2022. 7. 29.
	 * @author srec0051
	 * @param paramDto
	 * @return OrMrtggBasVO
	 * @throws Exception
	 */
	private OrMrtggBasVO updateOrderNrdmpAmountAndSttusCode(CredtMrtggTrnsmisDto paramDto) throws Exception {

		// 담보 기본 미상환금액, 상태코드 update
		OrMrtggBasVO mrtggBasVo = OrMrtggBasVO.builder()
				.mrtggNo(paramDto.getMrtggNo())
				.orderNo(paramDto.getOrderNo())
				.nrdmpAmount(paramDto.getNrdmpAmount())
				.mrtggSttusCode(paramDto.getMrtggSttusCode())
				.lastChangerId(paramDto.getIntrfcCode())
				.build();

		if (StringUtil.isNotBlank(paramDto.getMberId())) {
			mrtggBasVo.setLastChangerId(paramDto.getMberId());
		}

		log.debug("mrtggBasVo : {}", mrtggBasVo.toString());

		if (1 > mrtggMapper.setOrMrtggBasNrdmpAmountAndSttusCode(mrtggBasVo)) {
			log.error("주문 담보 기본 미상환금액, 상태코드 수정 실패");
			throw new Exception("주문 담보 기본 미상환금액, 상태코드 수정 실패");
		}
		mrtggMapper.insertOrMrtggBasHst(mrtggBasVo);

		// 재처리시 로직 PASS
		if (paramDto.isRetry()) {
			log.info("재처리 진입으로 주문기본T 중량정산 로직 PASS");
			return mrtggBasVo;
		}

		// 주문 기본 T 중량정산 일 때만 업데이트, 기타 상환에서는 이월렛 처리시 업데이트 됨
		// 23-11-23 변경사항 : "단가정산"일 경우에도 동일 로직 수행하도록 조건문 추가
		// 24-01-17 변경사항 : "중량/단가 정산"일 경우에도 동일 로직 수행하도록 조건문 추가
		// 24-04-29 변경사항 : 해당 로직은 정산 시점에 최초로 실행되는 중량 정산 API(SOREC-IF-090)와 단가 정산 BATCH에서 처리되도록 변경됨에 따라 주석 처리됨
//		if (RepySeCode.WT_EXCCLC == RepySeCode.codeOf(paramDto.getRepySeCode())
//				|| RepySeCode.UNTPC_EXCCLC == RepySeCode.codeOf(paramDto.getRepySeCode())
//				|| RepySeCode.WT_AND_UNTPC_EXCCLC == RepySeCode.codeOf(paramDto.getRepySeCode())) {
//			// 주문 기본 미결제금액 update
//			OrOrderBasVO newOrderBasVo = new OrOrderBasVO();
//			newOrderBasVo.setOrderNo(paramDto.getOrderNo());
//			newOrderBasVo.setUnSetleAmount(paramDto.getNrdmpAmount());
//
//			if (StringUtil.isBlank(paramDto.getMberId())) {
//				newOrderBasVo.setLastChangerId(paramDto.getIntrfcCode());
//			} else {
//				newOrderBasVo.setLastChangerId(paramDto.getMberId());
//			}
//
//			log.debug("newOrderBasVo : {}", newOrderBasVo.toString());
//
//			if (1 > mrtggMapper.setOrOrderBasUnSetleAmount(newOrderBasVo)) {
//				log.error("중량정산 주문 기본 미상환금액 수정 실패");
//				throw new Exception("중량정산 주문 기본 미상환금액 수정 실패");
//			}
//
//			mrtggMapper.insertOrOrderBasHst(paramDto.getOrderNo());
//		}

		return mrtggBasVo;
	}
	
	/**
	 * <pre>
	 * 처리내용: 미납되어 출고 중지된 주문건에 대해 상환완료 시 출고 중지 해제 API 호출 및 SMS 전송
	 * </pre>
	 * @date 2024. 7. 24.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 7. 24.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @param setleAmount
	 * @throws Exception
	 */
	private void callApiAndSmsDlivyStpgeRelisByRepyCompt(String orderNo, Long setleAmount) throws Exception {
		// 출고 중지된 건 중에 상환 완료된 주문 정보 가져오기
		DlivyStpgeVO getOrderInfoByDlivyStpgeRepyCompt = mrtggMapper.getOrderInfoByDlivyStpgeRepyCompt(orderNo);
		try {
			// 출고 중지된 건 중에 상환 완료된 주문 정보가 있을 때
			if(getOrderInfoByDlivyStpgeRepyCompt != null) {
				OrderSttusChgInfoVO orderSttusChgInfoVO = new OrderSttusChgInfoVO();
                orderSttusChgInfoVO.setEcOrderNo(getOrderInfoByDlivyStpgeRepyCompt.getOrderNo()); // EC 주문번호
                orderSttusChgInfoVO.setOmsOrderRceptNo(getOrderInfoByDlivyStpgeRepyCompt.getOmsRceptNo()); // OMS 주문 접수 번호
                orderSttusChgInfoVO.setOrderSttus(getOrderInfoByDlivyStpgeRepyCompt.getOrderSttus()); // 주문 상태 - 4: 출고 중지 해제
				
				// 출고 중지 해제 API 호출
				String rspnsCode = loService.sendOrderSttusChange(orderSttusChgInfoVO);
				log.warn("[MrtggServiceImpl][callApiAndSmsDlivyStpgeRelisByRepyCompt] 출고 중지 해제 API orderNo: {}, resObj: {}", getOrderInfoByDlivyStpgeRepyCompt.getOrderNo(), rspnsCode);
				
				if(rspnsCode != null && StringUtils.equals("200", rspnsCode)) {
					log.warn("[MrtggServiceImpl][callApiAndSmsDlivyStpgeRelisByRepyCompt] 출고 중지 해제 API 송신결과 - 성공");
				} else {
					log.warn("[MrtggServiceImpl][callApiAndSmsDlivyStpgeRelisByRepyCompt] 출고 중지 해제 API 송신결과 - 실패");
				}
			}
		} catch(Exception e) {
			log.error("[MrtggServiceImpl][callApiAndSmsDlivyStpgeRelisByRepyCompt] 출고 중지 해제 API 호출 ERROR: ", ExceptionUtils.getStackTrace(e));
		} finally {
			if(getOrderInfoByDlivyStpgeRepyCompt != null) {
				// API 송신 성공 or 실패 여부와 상관없이 SMS 발송
				// 출고중지 및 출고중지 해제 SMS 전송 공통 서비스
				//    , dlivyStpgeCode[출고 중지 코드] : stpge(중지), relis(해제)
				//    , outptAmount [출력 금액] : stpge(중지) 시 미납금액, relis(해제) 시 결제금액
				cdtlnMessageService.sendDlivyStpgeRelisSms("relis", orderNo, setleAmount, 145);
			}
		}
	}
	

	@Override
	public void trnsmisSucces(CredtMrtggTrnsmisDto paramDto) throws Exception {
	}
	@Override
	public void trnsmisFailr(CredtMrtggTrnsmisDto paramDto) throws Exception {
	}
	@Override
	public void mrtggRepyCompt(CredtMrtggTrnsmisDto paramDto) throws Exception {
	}

	// 이월렛 환불
    private void ewalletTransfer(String intrfcCode, OrOrderBasVO orOrderBasVO) throws Exception {
		try {
            /**
             * iemSeCode : 0001(물품구매), 0002(환불), 0003(이체), 0004(기업뱅킹 환불) 0002 = 가상계좌 -> 고객계좌
             * 0003 = 케이지트레이딩계좌 -> 가상계좌(고객)
             */

            if (orOrderBasVO.getExcclcAmount() < 0) {	// 환불 대상 금액이 있을 경우 (정산 금액이 음수)
            	String nowDate = DateUtil.getNowDate();
    	        String setleNo = nowDate + "-" + assignService.selectAssignValue("OR", "SETLE_NO", nowDate, orOrderBasVO.getMberNo(), 5);

    	        orOrderBasVO.setSetleNo(setleNo);
    	        orOrderBasVO.setFrstRegisterId(intrfcCode);
    	        orOrderBasVO.setLastChangerId(intrfcCode);

    	        mrtggMapper.insertEwalletSetle(orOrderBasVO);
    	        mrtggMapper.insertOrSetleBasHst(orOrderBasVO);
    	        
                Map<String, Object> ewalletMap = new HashMap<String, Object>();
                ewalletMap.put("entrpsNo", orOrderBasVO.getEntrpsNo());
                ewalletMap.put("iemSeCode", "0003");
                ewalletMap.put("ewalletExcclcTyCode", "04"); // E-Wallet 정산 유형 코드 04 : 중량정산
                ewalletMap.put("setleNo", setleNo);
                ewalletMap.put("delngAmount", (-1) * orOrderBasVO.getExcclcAmount());
                
                // 중도 상환 대상 주문일 경우, 선수금 여부(precdntAt) 값을 C로 한다.
                if(StringUtils.equals(orOrderBasVO.getPartDlivyRepyAt(), "Y")) {	// 중도 상환 대상 여부
                	ewalletMap.put("precdntAt", "C");
                } else {	// 중도 상환 대상 주문이 아닐 경우, 선수금 여부(precdntAt) 값을 N으로 한다.
                	ewalletMap.put("precdntAt", "N");
                }
                
                Map<String, Object> ewalletResMap = httpClientHelper.postCallApi(ewalletOrderUrl, ewalletMap);
                log.debug(ewalletResMap.toString()); // log

                // 이월렛 서버에서 결재테이블 정상 성공으로 업데이트 되었는지 체크, 실패일 시 세금계산서 처리를 안 함
                if (null != ewalletResMap && StringUtils.equals("200", ewalletResMap.get("resultCode").toString())
                        && ewalletResMap.get("data") != null) {
                    boolean isSuccess = false;
                    Map<String, Object> resultData = (Map<String, Object>) ewalletResMap.get("data");
                    String delngSeqNo = String.valueOf(resultData.get("delngSeqNo"));

                    for (int i = 0; i < ewalletTimeoutsec * 2; i++) {
                        Thread.sleep(500);
                        // 호출 건 응답 코드 확인
                        String rspnsCode = mrtggMapper.selectEwalletRspnCode(delngSeqNo);
                        log.debug(">> rspnsCode : " + rspnsCode);
                        if (!StringUtils.isEmpty(rspnsCode)) {
                            // 응답 코드가 000 일때 거래 완료 -> 전문설계서 응답코드 확인
                            if (StringUtils.equals(rspnsCode, "000")) {
                                isSuccess = true;
                            }
                            log.debug(">> rspnsCode : " + rspnsCode + ", isSuccess : " + isSuccess);
                            break;
                        }
                    } // end for
                    log.debug(">> finally isSuccess : " + isSuccess);

                    if (!isSuccess) {
                        throw new Exception("이월렛 주문 실패");
                    }
                } else {
                    throw new Exception("이월렛 호출 실패");
                }
            } else {
                log.debug("거래금액 음수로 이월렛 환불처리 PASS : " + orOrderBasVO.getExcclcAmount());
            }
        } catch (Exception e) {
            throw new Exception("이월렛 환불처리 실패 :: " + e.getMessage());
        }
    }
}
