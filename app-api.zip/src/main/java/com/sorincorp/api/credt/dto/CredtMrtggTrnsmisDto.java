package com.sorincorp.api.credt.dto;

import javax.validation.constraints.NotEmpty;

import lombok.Data;

/**
 * 신용보증 담보 매매계약 DTO
 * @author srec0051
 *
 */
@Data
public class CredtMrtggTrnsmisDto {

	/** 주문번호 */
	@NotEmpty(message = "주문번호를 확인해주세요.")
	private String orderNo;

	/** 담보번호 */
	private String mrtggNo;
	/** 담보상세순번 */
	private Integer mrtggDetailSn;

	/** 담보 상태 코드 { 10:계약요청, 20:계약성공, 30:부분상환, 50:상환완료, 90:계약실패 } */
	private String mrtggSttusCode;

//	/** 담보 상환 상태 코드 { 10:요청, 20:성공, 90:실패 } */
//	private String mrtggRepySttusCode;

	/** 상환 구분 코드 { 01:중량정산, 02:상환입금, 03:미납상환 } */
	private String repySeCode;

	/** 업체번호 */
	private String entrpsNo;

	/** 인터페이스 번호 */
	private String intrfcCode;

	/** 결제금액 */
	private long setleAmount;
	/** 미납금액 */
	private long nrdmpAmount;

	/** 재처리수행여부 */
	private boolean isRetry;
	/** 회원번호 */
	private String mberNo;
	/** 중도상환일 (yyyyMMdd) */
	private String mdstrmRepyDe;
    /** 결제 방식 코드 */
    private String setleMthdCode;
    /** 결제 방식 상세 코드 */
    private String setleMthdDetailCode;
    /** 여신 구분 코드 */
    private String cdtlnSvcSeCode;

    /** 호출 사용자 */
    private String mberId;
    
    /** 중도 상환 순번 */
	private Long mdstrmRepySn;
	/** 결제 번호 */
	private String setleNo;
}
