package com.sorincorp.api.credt.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * OrMrtggMdstrmRepyDtlVO.java : 주문_담보 중도 상환 상세 VO
 * @version
 * @since 2024. 7. 4.
 * @author srec0066
 */
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class OrMrtggMdstrmRepyDtlVO extends OrMrtggDtlVO {

   /** 배송 차수 */
   private int dlvyOdr;

   /** 확정 금액 */
   private long dcsnAmount;

   /** 입금 요청 금액 */
   private long rcpmnyRequstAmount;

   /** 결제 예정 일자 */
   private String setlePrearngeDe;

   /** 확정 중량 */
   private java.math.BigDecimal dcsnWt;

   /** 주문 별 확정 중량 */
   private java.math.BigDecimal orderDcsnWt;

   /** 배송 수단 코드 */
   private String dlvyMnCode;

   /** 배송비 */
   private long dlvrf;

   /** 상품 단가 */
   private long goodsUntpc;

   /** 상환 완료 코드 (P: 미대상, N: 미완료, Y: 완료) */
   private String repyComptCode;
}
