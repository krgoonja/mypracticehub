package com.sorincorp.api.credt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.common.APICommConstant;
import com.sorincorp.api.common.ApiResponseEntity;
import com.sorincorp.api.credt.dto.CredtMrtggTrnsmisDto;
import com.sorincorp.api.credt.service.MrtggService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
 * 신용보증 담보관리 Controller Class
 * @author srec0051
 *
 */
@Slf4j
@Api("신용보증 담보관리")
@RestController
@RequestMapping("/api/credt/mrtgg")
public class MrtggController {

	@Autowired
	private MrtggService mrtggService;


	/**
	 * <pre>
	 * 1. 전자상거래보증 매매계약 및 상환<br>
	 * 2. 전자상거래보증 매매계약 및 상환 재처리 (retry = true)
	 * </pre>
	 * @date 2022. 9. 2.
	 * @author srec0051
	 * @param param
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/trnsmis")
	@ApiOperation(value="SOREC-IF-000 : 담보 처리", notes="주문, 담보 정보를 기반으로 매매 요청, 상환, 실패 등 처리")
	@ResponseBody
	public ResponseEntity<?> trnsmis(
			@ApiParam(value = "CredtMrtggTrnsmisDto", required = true) @Validated @RequestBody CredtMrtggTrnsmisDto param,
			BindingResult bindingResult) throws Exception {

		log.info("trnsmis param : {}", param.toString());

		ApiResponseEntity apiResponseEntity = null;

		// 필수 데이터 검사
		if (bindingResult.hasErrors()) {
			String errDefaultMessage = bindingResult.getFieldError().getDefaultMessage();
			log.error(errDefaultMessage);

			apiResponseEntity = new ApiResponseEntity();
			apiResponseEntity.setRspnsCode(APICommConstant.BAD_REQUEST_RESULT_CODE);
			apiResponseEntity.setRspnsMssage(errDefaultMessage);

			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(apiResponseEntity);
		}

		// Response 객체를 리턴하도록 하여 응답 받는 쪽에서 처리 하도록 하자
		apiResponseEntity = mrtggService.trnsmis(param);

		return ResponseEntity.status(HttpStatus.OK).body(apiResponseEntity);
	}

	/**
	 * <pre>
	 * 상환 예상 적립 마일리지 조회 (테스트 조회용)
	 * </pre>
	 * @date 2022. 10. 14.
	 * @author srec0051
	 * @param param
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/repyMileageAmt")
	@ResponseBody
	public ResponseEntity<?> repyMileageAmt(@Validated @RequestBody CredtMrtggTrnsmisDto param,
			BindingResult bindingResult) throws Exception {

		log.debug("repyMileageAmt param : {}", param.toString());
		ApiResponseEntity apiResponseEntity = new ApiResponseEntity();

		if (bindingResult.hasErrors()) {
			log.error(bindingResult.getFieldError().getDefaultMessage());
			apiResponseEntity.setRspnsCode(APICommConstant.BAD_REQUEST_RESULT_CODE);
			apiResponseEntity.setRspnsMssage(bindingResult.getFieldError().getDefaultMessage());
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(apiResponseEntity);
		}

		long mileageAmt = mrtggService.getMdstrmRepyMileageAmt(param);
		apiResponseEntity.setRspnsCode(APICommConstant.SUCCESS_RESULT_CODE);
		apiResponseEntity.setRspnsMssage(String.valueOf(mileageAmt));

		return ResponseEntity.status(HttpStatus.OK).body(apiResponseEntity);
	}
}
