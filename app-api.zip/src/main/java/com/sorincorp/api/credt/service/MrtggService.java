package com.sorincorp.api.credt.service;

import com.sorincorp.api.common.ApiResponseEntity;
import com.sorincorp.api.credt.dto.CredtMrtggTrnsmisDto;

public interface MrtggService {

	/**
	 * 전자상거래보증 처리
	 * @param param
	 * @return
	 * @throws Exception
	 */
	ApiResponseEntity trnsmis(CredtMrtggTrnsmisDto param) throws Exception;

	/**
	 * 매매계약전송 요청
	 * @param paramDto
	 * @return
	 * @return
	 * @throws Exception
	 */
	void trnsmisRequst(CredtMrtggTrnsmisDto paramDto) throws Exception;

	/**
	 * 매매계약전송 성공
	 * @param paramDto
	 * @return
	 * @throws Exception
	 */
	void trnsmisSucces(CredtMrtggTrnsmisDto paramDto) throws Exception;

	/**
	 * 매매계약전송 실패
	 * @param paramDto
	 * @return
	 * @throws Exception
	 */
	void trnsmisFailr(CredtMrtggTrnsmisDto paramDto) throws Exception;

	/**
	 * 부분상환
	 * @param paramDto
	 * @return
	 * @throws Exception
	 */
	void mrtggPartRepy(CredtMrtggTrnsmisDto paramDto) throws Exception;

	/**
	 * 상환완료
	 * @param paramDto
	 * @return
	 * @throws Exception
	 */
	void mrtggRepyCompt(CredtMrtggTrnsmisDto paramDto) throws Exception;

	/**
	 * <pre>
	 * 예상 적립 마일리지 조회
	 * </pre>
	 * @date 2022. 10. 14.
	 * @author srec0051
	 * @param paramDto
	 * @return
	 * @throws Exception
	 */
	long getMdstrmRepyMileageAmt(CredtMrtggTrnsmisDto paramDto) throws Exception;
}
