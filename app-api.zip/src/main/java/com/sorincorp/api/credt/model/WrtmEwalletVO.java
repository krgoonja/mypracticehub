package com.sorincorp.api.credt.model;

import lombok.Data;

@Data
public class WrtmEwalletVO {

   /** 주문 번호  */
    private String orderNo;
   /** 회원 번호  */
    private String mberNo;
    /** 회원 아이디 */
    private String mberId;
   /** 업체 번호 */
    private String entrpsNo;
   /** 주문 상태 코드 */
    private String orderSttusCode;
   /** OMS 접수 번호 */
    private String omsRceptNo;
   /** 결제 방식 코드 */
    private String setleMthdCode;
   /** 결제 방식 상세 코드 */
    private String setleMthdDetailCode;
   /** 미 결제 금액 */
    private long unSetleAmount;
   /** 주문 홀딩 사용 여부 */
    private String orderHoldingUseAt;
    /** 업데이트 구분자 */
    private String updateSe;
    /** 배송 수단 코드 */
    private String dlvyMnCode;
    /** 출고 요청 일자 */
    private String dlivyRequstDe;
    /** 증거금 결제 예정 일자 */
    private String wrtmSetlePrearngeDe;
    /** 주문 배송지 번호 */
    private String orderDlvrgNo;

    /** 담보번호 */
	private String mrtggNo;
	/** 담보순번 */
	private String mrtggDetailSn;
	/** 회원권한구분코드 */
	private String mberSeCode;
	/** 상환 구분 코드 : 01중량정산, 02:상환입금, 03:부분상환 가능한 경우(배치) */
	private String repySeCode;

    /** 결제 번호 */
    private String setleNo;
    /** 거래 일련 번호 */
    private String delngSeqNo;
    /** 거래 금액 */
    private String delngAmount;
    /** 응답 코드 */
    private String rspnsCode;
    /** 이월렛 잔액 */
	private long ewalletBlce;

	/** 2022.09.20 재처리 여부 */
	private String retry;

	/** 추가 금액 */
	private long aditAmount;
	
	/**
	 * 상환 예정 금액
	 * 중도 상환 서비스가 추가됨에 따라, 미결제금액 전부를 상환하는 경우가 아닐수도 있으므로
	 * 상환 예정 대상 금액을 따로 조회
	 */
	private long setleRequstAmount;
	
	/**
     * 추가 금액 상환 여부
     * 화면에서 상환 대상으로 선택 시 "Y"값으로 넘어옴
     * 기본값 : N
     */
    private String aditAmountRepyAt = "N";
	
	/** 부분 출고 상환 여부 */
	private String partDlivyRepyAt;
	
	/** 중도 상환 순번 */
	private Long mdstrmRepySn;

	/**
     * 변동금 상환 여부
     * 추가변동금 입급하는 경우, "Y"값으로 넘어옴
     * 기본값 : N
     */
    private String changegldRepyAt = "N";
    /** 변동금 발생 순번 */
    private int occrrncSn;
}
