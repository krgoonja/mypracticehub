package com.sorincorp.api.credt.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.api.common.APICommConstant;
import com.sorincorp.api.credt.mapper.LonMapper;
import com.sorincorp.api.credt.model.IfKoditLonSettleBasVO;
import com.sorincorp.api.credt.model.LmtInqireReqVO;
import com.sorincorp.api.credt.model.LonComptProcessVO;
import com.sorincorp.api.credt.model.LonOrderVO;
import com.sorincorp.api.credt.model.LonReqVO;
import com.sorincorp.api.lo.model.OrderSttusChgInfoVO;
import com.sorincorp.api.lo.service.LoService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;
import com.sorincorp.comm.message.service.CdtlnMessageService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LonServiceImpl implements LonService {

	@Autowired
	private LoService loService;

	@Autowired
	private CdtlnMessageService cdtlnMessageService;

	@Autowired
	private LonMapper lonMapper;

	@Autowired
	private ObjectMapper objectMapper;

	/**
	 * API 통신 모듈
	 */
	@Autowired
	private HttpClientHelper httpClientHelper;

	/**
	 * 대출한도조회 API URL
	 */
	@Value(value = "${lon.api.lmtInqireUrl}")
	private String lmtInqireUrl;

	/**
	 * 매매계약서 요청 API URL
	 */
	@Value(value = "${lon.api.executeUrl}")
	private String executeUrl;

	/**
	 * 매매계약서 취소 요청 API URL
	 */
	@Value(value = "${lon.api.cancelUrl}")
	private String cancelUrl;

	/**
	 * 구동 환경
	 */
	@Value("${spring.profiles.active}")
	private String profiles;

	/**
	 * 구매자금 대출한도 조회
	 */
	@Override
	public Map<String, Object> getLonLmt(LonReqVO lonReqVO) throws Exception {
		String intrfcCode = "KODIT-IF-005";

		// 통합 로그 INSERT
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfcCode, lonReqVO);
		intrfcCode += "(" + btbLogVo.getIntrfcNo() + ")";

		Map<String, Object> result = new HashMap<>();

		try {
			// 22-11-18 변경사항 : 구동 환경이 개발환경(local, dev)일 시, 별도의 로직 실행 없이 한도 리턴하도록 변경
			if(profiles.equals("local") || profiles.equals("dev")) {
				//{responseCode=0000, responseMsg=, bankLimitAmt=000001100000000, bankLimitSpare=000001100000000}
				result.put("responseCode", "0000");
				result.put("responseMsg", profiles);
				result.put("bankLimitAmt", "000010000000000");
				result.put("bankLimitSpare", "000010000000000");
			} else {
				// 은행별 구매자금 대출 otp 실행 가능 시간 체크
				if (!lonMapper.checkExecutPossTime(lonReqVO.getBankCode())) {
					throw new Exception("결제 처리 시간이 지났습니다.");
				}

				// 한도 조회 시 필요한 구매사 정보 조회
				LmtInqireReqVO lmtInqireReqVO = lonMapper.selectMberData(lonReqVO);

				// 법인등록번호가 13자리가 아니면 공백으로 처리
				// 22-10-07 변경사항 : trim 처리 추가 및 null값이나 공백이면 0으로 13자리 채우도록 변경
				if (StringUtils.trim(Optional.ofNullable(lmtInqireReqVO.getBuyIncorpoNo()).orElse("")).length() != 13) {
					lmtInqireReqVO.setBuyIncorpoNo("0000000000000");
				}

				lmtInqireReqVO.setBankCode(lonReqVO.getBankCode());
				lmtInqireReqVO.setSettlementtype(lonReqVO.getSanctnMnCode());

				result = httpClientHelper.postCallApi(lmtInqireUrl, lmtInqireReqVO);
				log.debug("getLonLmt : b2bmore responseMsg : " + objectMapper.writeValueAsString(result));

				String apiFailMessage = "\r\n\r\n한도 조회에 실패했습니다. 관리자에게 문의해주십시오.";

				if (!StringUtils.equals(Optional.ofNullable(result.get("responseCode")).orElseThrow(() -> {
					return new Exception(apiFailMessage);
				}).toString(), "0000")) { // 0000 정상처리 가 아니면 예외 발생
					// 22-10-07 변경사항 : 전문 상의 에러 메세지를 그대로 노출시키도록 변경
					throw new Exception(result.get("responseMsg").toString() + apiFailMessage);
				}

				btbLogVo.setIntrfcRspnsCode(APICommConstant.SUCCESS_RESULT_CODE);
				btbLogVo.setIntrfcRspnsCn(APICommConstant.SUCCESS_RESULT_MSG);
			}
		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(APICommConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());

			log.error(e.getMessage());
			throw new Exception(e.getMessage());
		} finally {
			// 통합 로그 UPDATE
			httpClientHelper.updateBtbLog(btbLogVo);
		}

		return result;
	}

	/**
	 * 결제예정금액과 대출한도를 비교하여 대출가능여부를 판별한다.
	 */
	@Override
	public boolean checkLonLmt(String lonNo) throws Exception {
		// 대출 한도 체크 : 한도 이내일 시 true, 한도 초과일 시 false
		boolean isLonLmtUnder = true;

		LonReqVO lonReqVO = lonMapper.selectLonInfo(lonNo);

		// 한도 조회
		long lonLmt = Long.parseLong(this.getLonLmt(lonReqVO).get("bankLimitSpare").toString());

		// 결제 예정 금액 조회 후, 한도 금액과 비교하여 한도 초과일 시 false
		if (Integer.parseInt(Optional.ofNullable(lonReqVO.getSetlePrearngeAmount()).orElse("0")) > lonLmt) {
			isLonLmtUnder = false;
		}

		return isLonLmtUnder;
	}

	/**
	 * 구매자금 대출을 위한 매매계약서 요청 처리
	 */
	@Override
	public void ifKoditLonOrderBas(String lonNo) throws Exception {
		String intrfcCode = "KODIT-IF-003";
		String exceptionMessage = "매매계약서 발행 요청에 실패했습니다. 관리자에게 문의해주십시오.";
		String lonSttusCode = "20"; // 대출 상태 코드 - 20 : 매매 계약 전송 성공
		LonOrderVO lonOrderVO = null;

		// 통합 로그 INSERT
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfcCode, lonNo);
		intrfcCode += "(" + btbLogVo.getIntrfcNo() + ")";

		try {
			log.debug("1. 대출 한도 체크 : 한도 초과(false)일 시 예외 발생");
			if (!checkLonLmt(lonNo)) {
				log.debug("insertIfKoditLonOrderBas : 대출 한도 초과");
				throw new Exception("구매 자금 대출 한도가 초과되었습니다.");
			}

			log.debug("2. 대출 보증 로직 실행");
			// 매매계약서 작성 관련 데이터 조회
			lonOrderVO = lonMapper.selectKoditLonOrderData(lonNo);

			// 매매계약서 관련 I/F 테이블 데이터 삽입
			if (lonOrderVO != null) {
				lonOrderVO.setFrstRegisterId(intrfcCode);
				lonOrderVO.setLastChangerId(intrfcCode);

				lonMapper.insertIfKoditLonOrderBas(lonOrderVO);
				lonMapper.insertIfKoditLonOrderDtl(lonOrderVO);
			} else {
				log.debug("insertIfKoditLonOrderBas : 매매계약서 작성 관련 데이터 조회 실패");
				throw new Exception(exceptionMessage);
			}

			// url 방식 api call을 통해, b2b 시스템에서 ec 시스템의 I/F 테이블 데이터를 가져가도록 함
			Map<String, Object> result = null;
			Map<String, Object> param = new HashMap<>();
			long intrfcSn = lonOrderVO.getIntrfcSn();
			param.put("intrfcSn", intrfcSn);

			log.debug("insertIfKoditLonOrderBas : API CALL");
			result = httpClientHelper.postCallApi(executeUrl, param);

			log.debug("result : {}", result.toString());
			// 전문 수신 결과 검사
			if (!StringUtils.equals(Optional.ofNullable(result.get("responseCode")).orElseThrow(() -> {
				return new Exception(exceptionMessage);
			}).toString(), "0000")) { // 0000 정상처리 가 아니면 예외 발생
				log.debug("insertIfKoditLonOrderBas : 매매계약서 발행 요청 API Call 실패");
				throw new Exception(exceptionMessage);
			}

			// 매매계약서 발행 요청 API 성공 데이터 조회, 조회 데이터 없으면 예외 처리
			if (!lonMapper.selectRequestSuccessData(intrfcSn)) {
				log.debug("insertIfKoditLonOrderBas : 매매계약서 발행 요청 결과 - 매매 계약 전송 실패");
				throw new Exception(exceptionMessage);
			}

			// 주문_주문 기본 테이블 결제 방식 상세 코드 업데이트 : 9030(이월렛 + 구매자금)
			lonMapper.updateSetleMthdDetailCode(lonOrderVO);
			lonMapper.insertOrOrderBasHst(lonOrderVO.getOrderNo());

			btbLogVo.setIntrfcRspnsCode(APICommConstant.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(APICommConstant.SUCCESS_RESULT_MSG);
		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(APICommConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			lonSttusCode = "90"; // 대출 상태 코드 - 90 : 매매 계약 전송 실패

			log.error(e.getMessage());
			throw new Exception(e.getMessage());
		} finally {
			// 통합 로그 UPDATE
			httpClientHelper.updateBtbLog(btbLogVo);

			if (lonOrderVO == null) {
				lonOrderVO = new LonOrderVO();
				lonOrderVO.setLonNo(lonNo);
				lonOrderVO.setLastChangerId(intrfcCode);
			}

			lonOrderVO.setLonSttusCode(lonSttusCode);
			lonMapper.updateOrLonBas(lonOrderVO);
			lonMapper.insertOrLonBasHst(lonNo);
		}
	}

	/**
	 * 매매계약서 취소 요청 처리
	 */
	@Override
	public void ifKoditLonOrderCanclBas(String lonNo) throws Exception {
		String intrfcCode = "KODIT-IF-004";
		String exceptionMessage = "매매계약서 취소 요청에 실패했습니다. 관리자에게 문의해주십시오.";
		String lonSttusCode = "40"; // 대출 상태 코드 - 40 : 취소 전송 성공
		LonOrderVO lonOrderVO = null;

		// 통합 로그 INSERT
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfcCode, lonNo);
		intrfcCode += "(" + btbLogVo.getIntrfcNo() + ")";

		try {
			lonOrderVO = lonMapper.selectKoditLonCancelData(lonNo);
			lonOrderVO.setFrstRegisterId(intrfcCode);
			lonOrderVO.setLastChangerId(intrfcCode);
			lonMapper.insertIfKoditLonOrderCanclBas(lonOrderVO);

			// url 방식 api call을 통해, b2b 시스템에서 ec 시스템의 I/F 테이블 데이터를 가져가도록 함
			Map<String, Object> result = null;
			Map<String, Object> param = new HashMap<>();
			long intrfcSn = lonOrderVO.getIntrfcSn();
			param.put("intrfcSn", intrfcSn);

			log.debug("insertIfKoditLonOrderCanclBas : API CALL");
			result = httpClientHelper.postCallApi(cancelUrl, param);

			log.debug("result : {}", result.toString());

			// 전문 수신 결과 검사
			if (!StringUtils.equals(Optional.ofNullable(result.get("responseCode")).orElseThrow(() -> {
				return new Exception(exceptionMessage);
			}).toString(), "0000")) { // 0000 정상처리 가 아니면 예외 발생
				log.debug("insertIfKoditLonOrderBas : 매매계약서 취소 요청 API Call 실패");
				throw new Exception(exceptionMessage);
			}

			// 매매계약서 취소 요청 API 성공 데이터 조회, 조회 데이터 없으면 예외 처리
			if (!lonMapper.selectCancelRequestSuccessData(intrfcSn)) {
				log.debug("insertIfKoditLonOrderBas : 매매계약서 취소 요청 결과 - 취소 전송 실패");
				throw new Exception(exceptionMessage);
			}

			// 주문_주문 기본 테이블에 해당 주문번호의 결제 방식 상세 코드를 null 값으로 초기화
			lonMapper.updateOrOrderBas2(lonOrderVO.getOrderNo(), intrfcCode);
			lonMapper.insertOrOrderBasHst(lonOrderVO.getOrderNo());

			btbLogVo.setIntrfcRspnsCode(APICommConstant.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(APICommConstant.SUCCESS_RESULT_MSG);
		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(APICommConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			lonSttusCode = "91"; // 대출 상태 코드 - 91 : 취소 전송 실패

			log.error(e.getMessage());
			throw new Exception("매매계약서 취소 요청에 실패했습니다. 관리자에게 문의해주십시오.");
		} finally {
			// 통합 로그 UPDATE
			httpClientHelper.updateBtbLog(btbLogVo);

			if (lonOrderVO == null) {
				lonOrderVO = new LonOrderVO();
				lonOrderVO.setLonNo(lonNo);
				lonOrderVO.setLastChangerId(intrfcCode);
			}

			lonOrderVO.setLonSttusCode(lonSttusCode);
			lonMapper.updateOrLonBas(lonOrderVO);
			lonMapper.insertOrLonBasHst(lonNo);
		}
	}

	/**
	 * 대출 승인 전문(K311 전문) 수신 후처리
	 */
	@Override
	public void koditLonSetleProcess(String lonNo) throws Exception {
		String intrfcCode = "KODIT-IF-006";
		String lonSttusCode = "60";
		IfKoditLonSettleBasVO ifKoditLonSettleBasVO = null;

		// 통합 로그 INSERT
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(intrfcCode, lonNo);
		intrfcCode += "(" + btbLogVo.getIntrfcNo() + ")";

		try {
			// parameter validation
			if (lonNo == null) {
				log.debug("insertKoditLonSetleProcess : 파라메터 lonNo가 빈 값입니다.");
				throw new Exception("lonNo is Empty.");
			}

			// 이미 처리된 건인지 체크
//			if (lonMapper.isExistingLonNo(lonNo)) { // 이미 처리된 적이 있다면 메소드 종료
//				btbLogVo.setIntrfcRspnsCode(APICommConstant.SUCCESS_RESULT_CODE);
//				btbLogVo.setIntrfcRspnsCn(APICommConstant.SUCCESS_RESULT_MSG);
//				return;
//			}

			// 수신된 인터페이스 데이터 select
			ifKoditLonSettleBasVO = lonMapper.selectIfKoditLonSettleBas(lonNo);

			if (ifKoditLonSettleBasVO == null) {
				log.debug("insertKoditLonSetleProcess : 인터페이스 데이터 조회 실패");

				// IF Table Update - 처리 실패 상태코드(F)로 업데이트
				ifKoditLonSettleBasVO = new IfKoditLonSettleBasVO();
				ifKoditLonSettleBasVO.setProcessSttusCode("F"); // 처리 상태 코드 : F - 처리실패
				ifKoditLonSettleBasVO.setLastChangerId(intrfcCode);
				ifKoditLonSettleBasVO.setLonNo(lonNo);
				lonMapper.updateIfKoditLonSettleBas(ifKoditLonSettleBasVO);
				
				lonSttusCode = "92"; // 대출상태 코드 : 92 - 대출 승인 실패

				throw new Exception("인터페이스된 데이터가 조회되지 않습니다.");
			}

			// 조회된 대출 상태 코드에 따라 후속 로직 수행
			if (StringUtils.equals(ifKoditLonSettleBasVO.getDspthSeCode(), "1")) { // 대출 완료 시
				// 대출 완료 데이터 Select
				LonComptProcessVO lonComptProcessVO = lonMapper.selectCnfirmedLon(lonNo);
				lonComptProcessVO.setLastChangerId(intrfcCode);

				// 대출 한도 변동사항 테이블 저장
				lonMapper.insertMbEntrpsLonLmtDtl(lonComptProcessVO);
				lonMapper.insertMbEntrpsLonLmtDtlHst(lonComptProcessVO);

				// 22-12-21 변경사항 : 물류 api 호출 로직 변경, 해당 주문의 모든 재고가 실재고일 때만 가주문->실주문 api 호출
//				// 주문 홀딩 사용 여부 값으로 처리 방식 분기
//				if (StringUtils.equalsIgnoreCase("N", lonComptProcessVO.getOrderHoldingUseAt())) {
//					// 물류 처리 : 가주문->실주문 방식 (SOREC-IF-125 호출)
//					lonComptProcessVO.setOrderSttus("1"); // 가주문 : 0, 실주문 : 1
//
//					loService.sendOrderSttusChange(
//							objectMapper.convertValue(lonComptProcessVO, OrderSttusChgInfoVO.class));
//				} else {
//					// 물류 처리 : 주문 홀딩 방식 (SOREC-IF-023 호출)
//					loService.sendSetleInfo(lonComptProcessVO.getOrderNo(), "1", "1", null); // parameter : orderNo, orderTy
//																						// == 1 (주문), orderSttus == 1
//																						// (실주문)
//				}

				boolean invnryCheck = loService.isAllRealInvntry(lonComptProcessVO.getOrderNo());

		    	if(invnryCheck) {      	//모든 BL이 실재고
		    		// 물류 처리 : 가주문->실주문 방식 (SOREC-IF-125 호출)
					lonComptProcessVO.setOrderSttus("1"); // 가주문 : 0, 실주문 : 1

					loService.sendOrderSttusChange(
							objectMapper.convertValue(lonComptProcessVO, OrderSttusChgInfoVO.class));
			    } else { 				//가재고 1개이상 존재 >> 물류에 보내지 않는다.
			    	log.info("orderNo["+lonComptProcessVO.getOrderNo()+"] 가재고 존재하여 물류에 전송하지 않음.");
			    }

				// 주문_주문 기본 테이블에 해당 주문번호의 주문 상태 코드를 15 (배송 준비) 로 업데이트
				// 22.09.06 추가 내용 : 물류 진행 상태에 따라 주문 상태 코드가 변경될 수 있도록 쿼리문 수정
				// 물류 미진행 시 기존처럼 주문 상태 코드를 15로 업데이트
				ifKoditLonSettleBasVO.setLastChangerId(intrfcCode);
				
				lonMapper.updateOrOrderBas(ifKoditLonSettleBasVO);
				lonMapper.insertOrOrderBasHst(ifKoditLonSettleBasVO.getOrderNo());

				/*
				 * 물류 처리 이후 증거금의 경우 배송요청일 변경 IF를 호출한다.
				 * 22.10.11 추가 내용 : 로직에서 자동으로 배송요청일을 변경하는 프로세스 제거
				 * callDlvrgChangeInfo(lonComptProcessVO);
				 */

				// 결제 완료 처리 메세지, 메일 서비스 호출
				cdtlnMessageService.insertCdtlnSmsReturnMssageNo(lonComptProcessVO.getOrderNo(), -1L, "68", null);
				cdtlnMessageService.insertCdtlnMailSendReturnMailNo(lonComptProcessVO.getOrderNo(), "57");
			} else { // 대출 승인 실패 시
				lonSttusCode = "92"; // 대출상태 코드 : 92 - 대출 승인 실패
			}

			// IF Table Update - 비투비모아 측에서 EC 시스템이 정상 수신했는지 확인하기 위함
			ifKoditLonSettleBasVO.setProcessSttusCode("S"); // 처리 상태 코드 : S - 처리완료
			lonMapper.updateIfKoditLonSettleBas(ifKoditLonSettleBasVO);

			btbLogVo.setIntrfcRspnsCode(APICommConstant.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(APICommConstant.SUCCESS_RESULT_MSG);
		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(APICommConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());

			log.error(e.getMessage());
			throw new Exception(e.getMessage());
		} finally {
			// UPDATE OR_LON_BAS
			if(ifKoditLonSettleBasVO == null) {
				ifKoditLonSettleBasVO = new IfKoditLonSettleBasVO();
				ifKoditLonSettleBasVO.setLonNo(lonNo);
			}
			
			ifKoditLonSettleBasVO.setLonSttusCode(lonSttusCode);
			ifKoditLonSettleBasVO.setLastChangerId(intrfcCode);
			lonMapper.updateOrLonBas2(ifKoditLonSettleBasVO);
			lonMapper.insertOrLonBasHst(lonNo);
			
			// 통합 로그 UPDATE
			httpClientHelper.updateBtbLog(btbLogVo);
		}
	}

	/** 출고 요청 일자 변경 : IF-106 */
	/** 22.10.11 추가 내용 : 로직에서 자동으로 배송요청일을 변경하는 프로세스 제거 */
//	private void callDlvrgChangeInfo(LonComptProcessVO lonComptProcessVO) throws Exception {
//		try {
//			String dlivyRequstDe = lonComptProcessVO.getDlivyRequstDe(); // 기존 출고요청일
//			String newDlivyRequstDe = lonMapper.getNewDlivyRequstDe(lonComptProcessVO.getOrderNo()); // 변경될 출고요청일
//
//			// 기존 출고요청일과 변경될 출고요청일이 다른지 확인
//			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
//			// 날짜 비교위해 데이터 convert
//			Date originDate = simpleDateFormat.parse(dlivyRequstDe); // 기존 출고요청일
//			Date newDate = simpleDateFormat.parse(newDlivyRequstDe); // 변경될 출고요청일
//
//			int compare = originDate.compareTo(newDate);
//			if (compare != 0) { // 기존 출고요청일과 변경될 출고요청일이 다름
//				log.debug("증거금 출고요청일 변경 : " + dlivyRequstDe + " >> " + newDlivyRequstDe);
//				// 출고요청일 변경 api 호출
//				loService.sendDlvrgChangeInfo(lonComptProcessVO.getOrderNo(), lonComptProcessVO.getOrderDlvrgNo(),
//						newDlivyRequstDe);
//			}
//
//		} catch (Exception e) {
//			log.debug("출고요청일자 변경 실패");
//			throw new Exception("출고요청일자 변경에 실패했습니다.");
//		}
//	}
}
