package com.sorincorp.api.credt.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/******  JAVA VO CREATE : MB_ENTRPS_MRTGG_LMT_DTL(회원_업체 담보 한도 상세) ******/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MbEntrpsMrtggLmtDtlVO {

	/**
	 * 담보 번호
	 */
	private String mrtggNo;
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 보증 번호
    */
    private String grntyNo;
    /**
     * 담보 거래 일시
    */
    private java.sql.Timestamp mrtggDelngDt;
    /**
     * 담보 거래 유형 코드
    */
    private String mrtggDelngTyCode;
    /**
     * 담보 적요
    */
    private String mrtggSumry;
    /**
     * 담보 거래 금액
    */
    private long mrtggDelngAmount;
    /**
     * 담보 잔액
    */
    private long mrtggBlce;
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 취소 교환 반품 번호
    */
    private String canclExchngRtngudNo;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
    /**
     * 업체 담보 순번
    */
    private int entrpsMrtggSn;
    /**
     * 업체 담보 계약 순번
    */
    private long entrpsMrtggCntrctSn;
    /**
     * 담보 차액
    */
    private long mrtggDfnnt;
    /** 중도상환여부 */
    private String mdstrmRepyAt;
    /** 단가 인상 금액 */
    private long untpcIncrseAmount;
    /** 담보보증 무이자 일수 */
    private int mrtggGrntyNintrDaycnt;
}
