package com.sorincorp.api.credt.mapper;

import com.sorincorp.api.credt.model.IfKoditLonSettleBasVO;
import com.sorincorp.api.credt.model.LmtInqireReqVO;
import com.sorincorp.api.credt.model.LonComptProcessVO;
import com.sorincorp.api.credt.model.LonOrderVO;
import com.sorincorp.api.credt.model.LonReqVO;

public interface LonMapper {
	/**
	 * <pre>
	 * 처리내용: 은행별 구매자금 대출 otp 실행 가능 시간 체크
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param bankCode
	 * @return
	 */
	boolean checkExecutPossTime(String bankCode);
	
	/**
	 * <pre>
	 * 처리내용: 대출 한도 조회를 위한 구매사 정보 조회
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonReqVO
	 * @return
	 */
	LmtInqireReqVO selectMberData(LonReqVO lonReqVO);
	
	/**
	 * <pre>
	 * 처리내용: 구매자금 대출 정보 조회
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonNo
	 * @return
	 */
	LonReqVO selectLonInfo(String lonNo);
	
	/**
	 * <pre>
	 * 처리내용: 매매계약서 작성 시 필요한 데이터 조회
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonNo
	 * @return
	 */
	LonOrderVO selectKoditLonOrderData(String lonNo);
	
	/**
	 * <pre>
	 * 처리내용: 매매계약서 발행 요청 결과 조회
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param intrfcSn
	 * @return
	 */
	boolean selectRequestSuccessData(long intrfcSn);
	
	/**
	 * <pre>
	 * 처리내용: 주문_주문 기본 테이블 결제 방식 상세 코드 업데이트
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonOrderVO
	 */
	void updateSetleMthdDetailCode(LonOrderVO lonOrderVO);
	
	/**
	 * <pre>
	 * 처리내용: 회원_업체 대출 한도 상세 테이블 대출 정보 INSERT
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonOrderVO
	 */
	void insertMbEntrpsLonLmtDtl(LonComptProcessVO lonComptProcessVO);
	
	/**
	 * <pre>
	 * 처리내용: 회원_업체 대출 한도 상세 테이블 이력 관리
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonOrderVO
	 */
	void insertMbEntrpsLonLmtDtlHst(LonComptProcessVO lonComptProcessVO);
	
	/**
	 * <pre>
	 * 처리내용: 매매계약서 취소 요청 시 필요한 데이터 조회
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonNo
	 * @return
	 */
	LonOrderVO selectKoditLonCancelData(String lonNo);
	
	/**
	 * <pre>
	 * 처리내용: 매매계약서 취소 요청 성공 여부 조회
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param intrfcSn
	 * @return
	 */
	boolean selectCancelRequestSuccessData(long intrfcSn);
	
	/**
	 * <pre>
	 * 처리내용: 기존에 대출 완료 처리된 대출 건인지 조회
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonNo
	 * @return
	 */
	boolean isExistingLonNo(String lonNo);
	
	/**
	 * <pre>
	 * 처리내용: 대출 승인 전문(K311 전문) 데이터 조회
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonNo
	 * @return
	 */
	IfKoditLonSettleBasVO selectIfKoditLonSettleBas(String lonNo);
	
	/**
	 * <pre>
	 * 처리내용: 주문_대출 기본 테이블에 대출 승인 전문(K311 전문) 데이터 UPDATE
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param ifKoditLonSettleBasVO
	 */
	int updateOrLonBas2(IfKoditLonSettleBasVO ifKoditLonSettleBasVO);
	
	/**
	 * <pre>
	 * 처리내용: 주문_주문 기본 테이블에 대출 완료에 따른 데이터 변경사항 UPDATE
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param ifKoditLonSettleBasVO
	 */
	void updateOrOrderBas(IfKoditLonSettleBasVO ifKoditLonSettleBasVO);
	
	/**
	 * <pre>
	 * 처리내용: 주문_주문 기본 테이블에 매매계약서 취소에 따른 데이터 변경사항 UPDATE
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @param lastChangerId
	 */
	void updateOrOrderBas2(String orderNo, String lastChangerId);
	
	/**
	 * <pre>
	 * 처리내용: 주문_주문 기본 테이블 이력 관리
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 */
	void insertOrOrderBasHst(String orderNo);
	
	/**
	 * <pre>
	 * 처리내용: 물류 처리를 위한 대출 데이터 조회
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonNo
	 * @return
	 */
	LonComptProcessVO selectCnfirmedLon(String lonNo);
	
	/**
	 * <pre>
	 * 처리내용: 주문_대출 기본 테이블에 대출 상태 코드(LON_STTUS_CODE) UPDATE
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonOrderVO
	 */
	void updateOrLonBas(LonOrderVO lonOrderVO);
	
	/**
	 * <pre>
	 * 처리내용: 주문_대출 기본 테이블 이력 관리
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonNo
	 */
	void insertOrLonBasHst(String lonNo);
	
	/**
	 * <pre>
	 * 처리내용: 매매계약서 요청 데이터 INSERT
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonOrderVO
	 */
	void insertIfKoditLonOrderBas(LonOrderVO lonOrderVO);
	
	/**
	 * <pre>
	 * 처리내용: 매매계약서 요청 상세 데이터 INSERT
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonOrderVO
	 */
	void insertIfKoditLonOrderDtl(LonOrderVO lonOrderVO);
	
	/**
	 * <pre>
	 * 처리내용: 매매계약서 취소 요청 데이터 INSERT
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonOrderVO
	 * @return
	 */
	long insertIfKoditLonOrderCanclBas(LonOrderVO lonOrderVO);
	
	/**
	 * <pre>
	 * 처리내용: 대출 승인 전문(K311) 수신 결과 UPDATE (비투비모아에서 확인용)
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param ifKoditLonSettleBasVO
	 */
	void updateIfKoditLonSettleBas(IfKoditLonSettleBasVO ifKoditLonSettleBasVO);
	
	/**
	 * <pre>
	 * 처리내용: 변경될 출고요청일자를 조회한다.
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 22.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	String getNewDlivyRequstDe(String orderNo) throws Exception;
}
