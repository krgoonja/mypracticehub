package com.sorincorp.api.credt.service;

import com.sorincorp.api.common.ApiResponseEntity;
import com.sorincorp.api.credt.model.WrtmEwalletVO;

public interface WrtmEwalletService {

	/**
	 * <pre>
	 * 처리내용: 이월렛으로 상환한다.
	 * </pre>
	 * @date 2022. 9. 20.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 20.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param reqVO
	 * @return
	 * @throws Exception
	 */
	ApiResponseEntity ewalletRepy(WrtmEwalletVO reqVO) throws Exception;

}
