package com.sorincorp.api.credt.service;

import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.api.common.APICommConstant;
import com.sorincorp.api.common.ApiResponseEntity;
import com.sorincorp.api.credt.constant.MrtggConstant.RepySeCode;
import com.sorincorp.api.credt.mapper.WrtmEwalletMapper;
import com.sorincorp.api.credt.model.WrtmEwalletVO;
import com.sorincorp.api.lo.model.OrderSttusChgInfoVO;
import com.sorincorp.api.lo.service.LoService;
import com.sorincorp.api.taxBill.model.TaxBillRequestVO;
import com.sorincorp.api.taxBill.service.TaxBillService;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.message.service.CdtlnMessageService;
import com.sorincorp.comm.order.service.CommPrvsnlOrderService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class WrtmEwalletServiceImpl implements WrtmEwalletService {

    /** 이월렛 잔액조회 url */
    @Value("${api.ewallet.money.url}")
    private String ewalletAccountMoney;

    /** 이월렛 주문 url **/
    @Value("${api.ewallet.order.url}")
    private String ewalletTransfer;

    /** 이월렛 타임아웃 **/
    @Value("${api.ewallet.timeout}")
    private int ewalletTimeoutsec;

    /** 물류 서비스 **/
    @Autowired
    private LoService loService;

    /** 세금계산서 서비스 **/
    @Autowired
    private TaxBillService taxbillService;

    @Autowired
    private WrtmEwalletMapper wrtmEwalletMapper;

    @Autowired
    private AssignService assignService;

    @Autowired
    private CdtlnMessageService cdtlnMessageService;
    
    @Autowired
    private CommonService commonService;

    @Autowired
    private CommPrvsnlOrderService commPrvsnlOrderService;

    @Autowired
    private HttpClientHelper httpClientHelper;

    final private String REAL_ORDER = "1";                          //주문상태     : 가주문"0", 실주문"1", 취소주문"2"
    final private String SETLE_MTHD_WRTM = "90";                    //결제 방식   : 증거금"90"
    final private String SETLE_MTHD_DETAIL_WRTM = "9010";           //결제 방식 상세 코드  : 이월렛 + 이월렛"9010"
    final private String REPY_SE_CODE_PART = RepySeCode.NYP_REPY.getCode();  //상환구분코드 : 부분상환(미납상환)

	/**
	 * 이월렛으로 상환한다.
	 */
    @Override
    public ApiResponseEntity ewalletRepy(WrtmEwalletVO reqVO) throws Exception {
        log.debug("[이월렛 상환] START - orderNo : " + reqVO.getOrderNo());

        ApiResponseEntity responseEntity = new ApiResponseEntity();

        try {

            /** 1.상환대상 주문정보 조회 */
            WrtmEwalletVO order = Optional.ofNullable(wrtmEwalletMapper.selectoOrOrderBasInfo(reqVO)).
                    orElseThrow(()->{return new Exception("[이월렛 상환] 주문 정보가 존재하지 않습니다.");});
            
            log.warn(">> WrtmEwalletServiceImpl ewalletRepy order : " + String.valueOf(order));
            
            /** 2.해당 업체 이월렛 잔액 조회 */
            checkewalletAccountMoney(order);

            /** 3.이월렛 결제 */
            doEwalletTransfer(order);

            /** 증거금(90) 상환완료 이후 프로세스 */
            if(SETLE_MTHD_WRTM.equals(order.getSetleMthdCode()) && order.getAditAmount() == 0) { // 추가결제 건은 제외

                /** 4.세금계산서+ERP 발행 */
                callTaxbillIsue(order);

                /** 5.물류시스템 연계: 가주문 or 주문홀딩
                 * 2022.09.20 재처리시 처리 X
                 * */
                if ("N".equals(reqVO.getRetry())) {
                    loProcess(order);
                }
            }

        } catch (Exception e) {
            /** 실패 */
            log.error(e.getMessage(),e);
            responseEntity.setRspnsCode(APICommConstant.ERROR_RESULT_CODE);
            responseEntity.setRspnsMssage(e.getMessage());
            return responseEntity;
        }

        /** 성공 */
        responseEntity.setRspnsCode(APICommConstant.SUCCESS_RESULT_CODE);
        responseEntity.setRspnsMssage(APICommConstant.SUCCESS_RESULT_MSG);

        return responseEntity;
    }

    /**
        물류 api 호출
        헤당 주문번호 bl리스트의 실재고 유무 확인
        모든 재고가 실재고일때만 물류에 송신한다.
    */
    private void loProcess(WrtmEwalletVO order) throws Exception {
    	boolean invnryCheck = loService.isAllRealInvntry(order.getOrderNo());
    	if(invnryCheck) {      	//모든 BL이 실재고

    		//가주문 > 실주문 연계 : IF-125
	        callOrderSttusChange(order, REAL_ORDER);
	    } else { 				//가재고 1개이상 존재 >> 물류에 보내지 않는다.

	    	log.info("orderNo["+order.getOrderNo()+"] 가재고 존재하여 물류에 전송하지 않음.");
	    }

        /* 2022-12-20 : 증거금 물류송신 실재고조회조건으로 변경하여 주석처리

        if("N".equals(order.getOrderHoldingUseAt())) {      //가주문

            //가주문 > 실주문 연계 : IF-125
            callOrderSttusChange(order, REAL_ORDER);

        } else if("Y".equals(order.getOrderHoldingUseAt())){ //주문홀딩

            //OMS 호출 : IF-023
            callOms(order, REAL_ORDER); //전체상환완료 시점에 oms로 주문을 내린다.
        }*/

        /*
         물류 처리 이후 증거금의 경우 배송요청일 변경 IF를 호출한다.
         2022-10-11 배송요청일변경 로직변경으로 주석처리
         */
        //callDlvrgChangeInfo(order);
    }

    /** 세금계산서+ERP 발행 */
    private void callTaxbillIsue(WrtmEwalletVO order) throws Exception {
        try {
            TaxBillRequestVO taxReqVo = new TaxBillRequestVO();
            taxReqVo.setOrderNo(order.getOrderNo());                //주문번호
            taxReqVo.setCanclExchngRtngudNo(null);                  //취소반품번호
            taxReqVo.setJobSe("ORDER");                             //업무구분 : 주문

            taxbillService.taxBillIsu(taxReqVo);

        } catch (Exception e) {
            log.error("[이월렛 상환] 세금계산서 발행 실패 :: {}", e.getMessage());
            throw new Exception("[이월렛 상환] 세금계산서 발행 실패 :: ");
        }
    }

    /** OMS 호출 : IF-023 */
    private void callOms(WrtmEwalletVO order, String orderSttus) throws Exception {
        try {

            String omsOrderRceptNo = loService.sendSetleInfo(order.getOrderNo(), "1", orderSttus, null);

            if(omsOrderRceptNo != null && !omsOrderRceptNo.isEmpty()) {
                log.debug("물류 OMS 호출 성공");

                //주문 기본 tbl: OMS접수번호, 주문상태코드, 결제상세코드, 미결제금액 UPDATE
                order.setUpdateSe("3");
                order.setOmsRceptNo(omsOrderRceptNo);
                //order.setOrderSttusCode(ORDER_STTUS_CODE_15); 13(배송대기)일 경우 15(배송준비)로 업데이트/ 15(배송준비)보다 큰 경우 그대로 유지
                wrtmEwalletMapper.updateOrOrderBas(order);
                wrtmEwalletMapper.insertOrOrderHst(order);
            } else {
                throw new Exception("물류 OMS 응답결과 오류");
            }
        } catch (Exception e) {
            log.error("[이월렛 상환] 물류 OMS 실패 :: {}", e.getMessage());
            throw new Exception("[이월렛 상환] 물류 OMS 실패 :: ");
        }

    }

    /** 가주문 > 실주문 연계 : IF-125 */
    private void callOrderSttusChange(WrtmEwalletVO order, String orderSttus) throws Exception {
        try {
            OrderSttusChgInfoVO orderSttusChgInfoVO = new OrderSttusChgInfoVO();
            orderSttusChgInfoVO.setEcOrderNo(order.getOrderNo());
            orderSttusChgInfoVO.setOmsOrderRceptNo(order.getOmsRceptNo());
            orderSttusChgInfoVO.setOrderSttus(orderSttus);

            loService.sendOrderSttusChange(orderSttusChgInfoVO);
            log.debug("[이월렛 상환] 실주문 연계 성공");

            //주문 기본 tbl: 주문상태코드 UPDATE
            order.setUpdateSe("2");
            //order.setOrderSttusCode(ORDER_STTUS_CODE_15); 13(배송대기)일 경우 15(배송준비)로 업데이트/ 15(배송준비)보다 큰 경우 그대로 유지
            wrtmEwalletMapper.updateOrOrderBas(order);
            wrtmEwalletMapper.insertOrOrderHst(order);

        } catch (Exception e) {
            log.error("[이월렛 상환] 실주문 연계 실패 :: {}", e.getMessage());
            throw new Exception("[이월렛 상환] 실주문 연계 실패 :: ");
        }
    }

    /** 출고 요청 일자 변경 : IF-106
     *	2022-10-11 배송요청일변경 로직변경으로 주석처리
    private void callDlvrgChangeInfo(WrtmEwalletVO order) throws Exception {
        try {
            String dlivyRequstDe = order.getDlivyRequstDe(); 										//기존 출고요청일
            String newDlivyRequstDe = wrtmEwalletMapper.getNewDlivyRequstDe(order.getOrderNo());  	//변경될 출고요청일

            //기존 출고요청일과 변경될 출고요청일이 다른지 확인
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
            // 날짜 비교위해 데이터 convert
            Date originDate = simpleDateFormat.parse(dlivyRequstDe);   //기존 출고요청일
            Date newDate = simpleDateFormat.parse(newDlivyRequstDe);   //변경될 출고요청일

            int compare = originDate.compareTo(newDate);
            if(compare != 0) { //기존 출고요청일과 변경될 출고요청일이 다름
            	log.debug("증거금 출고요청일 변경 : " + dlivyRequstDe + " >> " + newDlivyRequstDe);
            	//출고요청일 변경 api 호출
            	loService.sendDlvrgChangeInfo(order.getOrderNo(), order.getOrderDlvrgNo(), newDlivyRequstDe);
            }

        } catch (Exception e) {
            log.error("[이월렛 상환] 출고요청일자 변경 실패 :: {}", e.getMessage());
            throw new Exception("[이월렛 상환] 출고요청일자 변경 실패 :: ");
        }
    }
    */

    /** 이월렛 결제 */
    private void doEwalletTransfer(WrtmEwalletVO order) throws Exception {
        boolean isSuccess = false;

        try {
        	// 24-07-12 변경사항 : 중도 상환 서비스 추가에 따라, 결제 요청 금액을 따로 조회하도록 로직 변경
            long ewalletBlce = order.getEwalletBlce();      //이월렛 잔액
            long originAmount = order.getUnSetleAmount();   //기존 미결제 금액 데이터 저장
            long setleRequstAmount = order.getSetleRequstAmount();  //결제 요청 금액
            String partRepyAt = "N";						//부분상환 여부: N전체입금 Y부분입금
            
            // 상환 입금(미납)이고 중도 상환이 아닐 때 (중도 상환 순번 : -1) 부분 상환 가능하고
            // 상환 입금(미납)이고 중도 상환일 경우 (중도 상환 순번 0보다 큼) 전체 상환만 가능
            if(REPY_SE_CODE_PART.equals(order.getRepySeCode()) && (order.getMdstrmRepySn() == null || order.getMdstrmRepySn() == -1)) {
                //"부분상환" : 이월렛 잔액이 미결제 금액보다 작은경우 모든 이월렛 잔액만큼 결제한다.
                if(ewalletBlce <  setleRequstAmount) {
                	setleRequstAmount = ewalletBlce;
                	partRepyAt = "Y";
                }
            }

            //결제 기본 tbl INSERT
            String setleNo = DateUtil.getNowDateTime("yyyyMMdd")+ "-" + assignService.selectAssignValue("OR", "SETLE_NO", DateUtil.getNowDate(), order.getMberNo(), 5);
            order.setSetleNo(setleNo);
            order.setSetleRequstAmount(setleRequstAmount);
            wrtmEwalletMapper.insertOrSetleBas(order);
            wrtmEwalletMapper.insertOrSetleHst(order);
            
            // 24-07-19 변경사항 : 중도상환 대상 주문의 중복 결제를 방지하기 위해 주문_담보 중도 상환 상세 테이블에 결제 번호 update 처리 로직 추가
            if(order.getMdstrmRepySn() != null && order.getMdstrmRepySn() != -1) {
            	wrtmEwalletMapper.updateRepyComptOrMrtggMdstrmRepyDtl(order);
            	
            	Map<String, String> keyValues = new HashMap<>();
            	keyValues.put("MRTGG_NO", order.getMrtggNo());
            	keyValues.put("ORDER_NO", order.getOrderNo());
            	keyValues.put("MDSTRM_REPY_SN", String.valueOf(order.getMdstrmRepySn()));
            	commonService.insertTableHistory("OR_MRTGG_MDSTRM_REPY_DTL", keyValues);
            }

            Map<String, Object> transferMap = new HashMap<String, Object>();
            transferMap.put("entrpsNo", order.getEntrpsNo());                   //업체번호
            transferMap.put("iemSeCode", "0001");                               //항목구분코드: 0001구매 0002고객환불 0003이체
            transferMap.put("delngAmount", setleRequstAmount);                  //거래금액
            transferMap.put("setleNo", order.getSetleNo());                     //결제번호
            transferMap.put("ewalletExcclcTyCode", "03");                       //이월렛 정산 유형 코드: 03주문결제
            transferMap.put("orderNo", order.getOrderNo());                     //주문번호
            
            // 중도 상환 주문이면 선수금 여부를 "C"로 세팅
            // 24-11-08 변경사항 : 추가변동금에 대한 입금일 시, 선수금 여부를 "A"로 세팅
            if(StringUtils.equals(order.getPartDlivyRepyAt(), "Y")) {	
            	transferMap.put("precdntAt", "C");                                  //선수금 여부
            } else if (StringUtils.equals(order.getChangegldRepyAt(), "Y")) {	
            	transferMap.put("precdntAt", "A");                                  //선수금 여부
            } else {	// Default : 선수금 여부를 "N"으로 세팅
            	transferMap.put("precdntAt", "N");                                  //선수금 여부
            }
            
            transferMap.put("partRepyAt", partRepyAt);                          //부분상환 여부: N전체입금 Y부분입금
            
            // 24-07-26 변경사항 : 중도 상환 주문의 추가 금액에 대한 결제 시, 이월렛 거래 구분 코드를 09(추가정산) 으로 하는 파라미터 추가
            if(StringUtils.equals(order.getAditAmountRepyAt(), "Y")) {
            	transferMap.put("ewalletDelngSeCode", "09");
            }

            Map<String, Object> transferRes  = httpClientHelper.postCallApi(ewalletTransfer, transferMap);
            if(null != transferRes && StringUtils.equals("200", String.valueOf(transferRes.get("resultCode")))) {
                Map<String, Object> dataObj = (Map<String, Object>) transferRes.get("data");
                order.setDelngSeqNo(String.valueOf(dataObj.get("delngSeqNo"))); //거래일련번호
                long setleAmt = 0; //결제금액

                // 이월렛 서버에서 결재테이블 정상 성공으로 업데이트 되었는지 체크 현재 5초 설정
                for (int i = 0; i < ewalletTimeoutsec * 2 ; i++) {
                    Thread.sleep(500);
                    //호출 건 응답 코드 확인
                    WrtmEwalletVO rspns = wrtmEwalletMapper.selectEwalletRspnCode(order);
                    if(null != rspns && !StringUtils.isEmpty(rspns.getRspnsCode())) {
                        //응답 코드가 000 일때 거래 완료
                        if(StringUtils.equals("000", rspns.getRspnsCode())) {
                            isSuccess = true;
                        }

                        setleAmt = NumberUtils.toLong(rspns.getDelngAmount());//거래금액
                        log.debug("[이월렛 상환] 이월렛 결제 rspnsCode >>> " + rspns.getRspnsCode() + ", 거래금액 >>> " + setleAmt);
                        break;
                    }
                }//for() END

                if(!isSuccess) { //최종 결제 실패
                	log.error("응답코드 에러 finally isSuccess = {}", isSuccess);
                    throw new Exception("응답코드 에러 ");
                } else {         //최종 결제 성공 : ORDER_BAS 미결제금액, 결제방식상세코드 업데이트
                    if (StringUtils.equals(order.getChangegldRepyAt(), "Y")) {
                    	// 추가변동금 입금인 경우
                    	// 가격 변동금 tbl 업데이트
                    	commPrvsnlOrderService.updateOrPcOrPcChangegldBasByRcpmny(order.getOrderNo(), order.getOccrrncSn(), setleNo, "EWALLET-API");
                    } else {
                    	// 일반 주문의 경우
	                    long setledAmount = originAmount -  setleAmt;
	                    log.debug("[이월렛 상환] 이월렛 결제 미결제금액 >>> {}, 업데이트할 금액 >>> {}", originAmount, setledAmount);

	                    order.setUpdateSe("1");
	                    order.setUnSetleAmount(setledAmount);                           //미결제금액
	                    if(SETLE_MTHD_WRTM.equals(order.getSetleMthdCode())) {
	                        order.setSetleMthdDetailCode(SETLE_MTHD_DETAIL_WRTM);       //증거금일 경우 결제방식상세코드:9010
	                    }

	                    wrtmEwalletMapper.updateOrOrderBas(order);
	                    wrtmEwalletMapper.insertOrOrderHst(order);

	                    // 증거금일때 결제완료 후 sms, email 발송
	                    // 추가결제건은 빌송 제외
	                    if(SETLE_MTHD_WRTM.equals(order.getSetleMthdCode()) && order.getUnSetleAmount() == 0 && order.getAditAmount() == 0) {
	                        cdtlnMessageService.insertCdtlnMailSendReturnMailNo(order.getOrderNo(), "57"); // ("57" 잔금결제완료)
	                        cdtlnMessageService.insertCdtlnSmsReturnMssageNo(order.getOrderNo(), -1L, "68", null);    // ("68" 결제 완료 처리)
	                    }
                    }
                }

            } else {
                throw new Exception("결제응답 수신 실패");
            }
        } catch (Exception e) {
            log.error("[이월렛 상환] 이월렛 결제 실패 :: {}", e.getMessage());
            throw new Exception("[이월렛 상환] 이월렛 결제 실패 :: " + e.getMessage());
        }
    }

    /** 이월렛 잔액 조회 */
    private void checkewalletAccountMoney(WrtmEwalletVO order) throws Exception {

        try {
        	Map<String, Object> ewalletMap = new HashMap<>();
            ewalletMap.put("entrpsNo", order.getEntrpsNo());
            ewalletMap.put("accoutWaitSecond", 7); // 잔액 조회 대기 시간을 7초로 설정 (default : 5초, 지정가 touch 시 3초, accoutWaitSecond 파라미터 설정 시 설정 값을 우선)
            
            Map<String, Object> accountRes = httpClientHelper.postCallApi(ewalletAccountMoney, ewalletMap);
            if(null != accountRes && null != accountRes.get("data")) {
                Map<String, Object> dataObj = (Map<String, Object>) accountRes.get("data");
                long ewalletMoney = NumberUtils.toLong(String.valueOf(dataObj.get("delngAmount")));

                // 상환 입금(미납)이고 중도 상환이 아닐 때 (중도 상환 순번 : -1) 부분 상환 가능하고
                // 상환 입금(미납)이고 중도 상환일 경우 (중도 상환 순번 0보다 큼) 전체 상환만 가능
                if(REPY_SE_CODE_PART.equals(order.getRepySeCode()) && (order.getMdstrmRepySn() == null || order.getMdstrmRepySn() == -1)) {
                    //"부분상환"(전자상거래보증) 가능할 경우에만 진행
                    if(ewalletMoney <= 0) throw new Exception("잔액 부족 >> 부분상환 불가능");
                } else {
                    //잔금에 대한 "전체상환" 가능할 경우에만 진행
                    if(ewalletMoney < order.getSetleRequstAmount()) throw new Exception("잔액 부족 >> 전체상환 불가능");
                }

                order.setEwalletBlce(ewalletMoney); //이월렛 잔액 정보 저장

            } else {
                throw new Exception("잔액조회 결과 없음");
            }
        } catch (Exception e) {
            log.error("[이월렛 상환] 이월렛 잔액조회 실패 :: {}", e.getMessage());
            throw new Exception("[이월렛 상환] 이월렛 잔액조회 실패 :: " + e.getMessage());
        }
    }

    /** 입금완료 시점이 결제예정일 이후인지의 여부를 체크한다. 결제예정일 지난 시점의 입금이면 TRUE를 리턴한다.
    private boolean isOverSetlePrearngeDe(String wrtmSetlePrearngeDe) throws Exception {
        boolean result = false;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        String strToday = DateUtil.getNowDate();

        // 날짜 비교위해 데이터 convert
        Date setlePrearngeDe = simpleDateFormat.parse(wrtmSetlePrearngeDe);   //결제예정일
        Date today = simpleDateFormat.parse(strToday);                        //입금시점(현재)

        int compare = setlePrearngeDe.compareTo(today);
        if(compare < 0) { //결제예정일 < 입금시점
            result = true;
        }

        return result;
    }
    */
}
