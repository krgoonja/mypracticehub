package com.sorincorp.api.credt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.common.ApiResponseEntity;
import com.sorincorp.api.credt.model.WrtmEwalletVO;
import com.sorincorp.api.credt.service.WrtmEwalletService;
import com.sorincorp.comm.util.StringUtil;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequestMapping("/api/wrtm")
@RestController
@Api("증거금 이월렛")
public class WrtmEwalletController {

     @Autowired
     private WrtmEwalletService wrtmEwalletService;

	/**
	 * <pre>
	 * 처리내용: 이월렛으로 상환한다.
	 * </pre>
	 * @date 2022. 9. 20.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 20.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param reqVO
	 * @return
	 * @throws Exception
	 */
     @PostMapping("/ewalletRepy")
     public ResponseEntity<?> ewalletRepy(@RequestBody WrtmEwalletVO reqVO) throws Exception {

          reqVO.setRetry(StringUtil.nvl(reqVO.getRetry(), "N")); // 재처리 여부
          ApiResponseEntity apiResponseEntity = wrtmEwalletService.ewalletRepy(reqVO);

		return  ResponseEntity
				.status(HttpStatus.OK)
				.body(apiResponseEntity);
     }

}
