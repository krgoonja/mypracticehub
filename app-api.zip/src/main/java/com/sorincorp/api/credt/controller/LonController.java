package com.sorincorp.api.credt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.common.APICommConstant;
import com.sorincorp.api.common.ApiResponseEntity;
import com.sorincorp.api.credt.model.LonReqVO;
import com.sorincorp.api.credt.service.LonService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/credt/lon")
@Slf4j
public class LonController {
	@Autowired
	private LonService lonService;
	
	/**
	 * <pre>
	 * 처리내용: 대출한도조회 API
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonReqVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/getLonLmt")
	public ResponseEntity<?> getLonLmt(@RequestBody LonReqVO lonReqVO) throws Exception {
		//화면에서 선택한 은행의 대출 한도 조회 api 호출 후 한도 값 return
		ApiResponseEntity entity = new ApiResponseEntity();
		entity.setRspnsCode(APICommConstant.SUCCESS_RESULT_CODE);
		entity.setRspnsMssage(APICommConstant.SUCCESS_RESULT_MSG);
		
		entity.setRspnsCont(lonService.getLonLmt(lonReqVO));
		
		return ResponseEntity.ok(entity);
	}
	
	/**
	 * <pre>
	 * 처리내용: 매매계약서 요청 API
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonReqVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value = "/execute", consumes = "application/json")
	public ResponseEntity<?> executeLon(@RequestBody LonReqVO lonReqVO) throws Exception {
		lonService.ifKoditLonOrderBas(lonReqVO.getLonNo());
		
		return ResponseEntity.ok(new ApiResponseEntity(APICommConstant.SUCCESS_RESULT_CODE, APICommConstant.SUCCESS_RESULT_MSG, null));
	}
	
	/**
	 * <pre>
	 * 처리내용: 매매계약서 취소 요청 API
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonReqVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/cancel")
	public ResponseEntity<?> cancelLon(@RequestBody LonReqVO lonReqVO) throws Exception {
		lonService.ifKoditLonOrderCanclBas(lonReqVO.getLonNo());
		
		return ResponseEntity.ok(new ApiResponseEntity(APICommConstant.SUCCESS_RESULT_CODE, APICommConstant.SUCCESS_RESULT_MSG, null));
	}
	
	/**
	 * <pre>
	 * 처리내용: 대출 승인 전문(K311 전문) 수신 후처리 API
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonReqVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/setleProcess")
	public ResponseEntity<?> setleProcess(@RequestBody LonReqVO lonReqVO) throws Exception {
		lonService.koditLonSetleProcess(lonReqVO.getLonNo());
		
		return ResponseEntity.ok(new ApiResponseEntity(APICommConstant.SUCCESS_RESULT_CODE, APICommConstant.SUCCESS_RESULT_MSG, null));
	}
	
	/**
	 * <pre>
	 * 처리내용: API 예외 처리 공통 메소드 
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param ex
	 * @return
	 */
	@ExceptionHandler
	public ResponseEntity<?> exceptionHandler(Exception ex) {
		ApiResponseEntity entity = new ApiResponseEntity();
		entity.setRspnsCode(APICommConstant.ERROR_RESULT_CODE);
		entity.setRspnsMssage(ex.getMessage());
		
		return ResponseEntity
				.status(HttpStatus.INTERNAL_SERVER_ERROR)
				.body(entity);
	}
}
