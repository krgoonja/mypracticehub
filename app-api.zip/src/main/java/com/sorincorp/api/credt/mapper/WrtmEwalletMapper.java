package com.sorincorp.api.credt.mapper;

import com.sorincorp.api.credt.model.WrtmEwalletVO;

public interface WrtmEwalletMapper {

	/**
	 * <pre>
	 * 처리내용: 주문 정보를 조회한다.
	 * </pre>
	 * @date 2022. 9. 20.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 20.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param reqVO
	 * @return
	 * @throws Exception
	 */
	WrtmEwalletVO selectoOrOrderBasInfo(WrtmEwalletVO reqVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 결제_기본 테이블에 INSERT한다.
	 * </pre>
	 * @date 2022. 9. 20.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 20.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param order
	 * @throws Exception
	 */
	void insertOrSetleBas(WrtmEwalletVO order) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 결제_이력 테이블에 INSERT한다.
	 * </pre>
	 * @date 2022. 9. 20.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 20.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param order
	 * @throws Exception
	 */
	void insertOrSetleHst(WrtmEwalletVO order) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이월렛 이체 응답코드를 조회한다.
	 * </pre>
	 * @date 2022. 9. 20.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 20.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param order
	 * @return
	 * @throws Exception
	 */
	WrtmEwalletVO selectEwalletRspnCode(WrtmEwalletVO order) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_기본 테이블을 업데이트 한다.
	 * </pre>
	 * @date 2022. 9. 20.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 20.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param order
	 * @throws Exception
	 */
	void updateOrOrderBas(WrtmEwalletVO order) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_이력 테이블에 INSERT한다.
	 * </pre>
	 * @date 2022. 9. 20.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 20.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param order
	 * @throws Exception
	 */
	void insertOrOrderHst(WrtmEwalletVO order) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 변경될 출고요청일자를 조회한다.
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 22.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	String getNewDlivyRequstDe(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 중도 상환 상세 테이블에 결제번호를 update 한다.
	 * </pre>
	 * @date 2024. 7. 19.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 7. 19.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param order
	 */
	void updateRepyComptOrMrtggMdstrmRepyDtl(WrtmEwalletVO order);

}
