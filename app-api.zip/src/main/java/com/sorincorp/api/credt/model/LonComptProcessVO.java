package com.sorincorp.api.credt.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class LonComptProcessVO {
	/**
	 * 주문 번호
	 */
	@JsonProperty("ecOrderNo")
	private String orderNo;
	/**
	 * 대출 번호
	 */
	private String lonNo;
	/**
	 * 결제 예정 일자
	 */
	private String wrtmSetlePrearngeDe;
	/**
	 * 배송 수단 코드
	 */
	private String dlvyMnCode;
	/**
	 * 출고 요청 일자
	 */
	private String dlivyRequstDe;
	/**
	 * 주문 배송지 번호
	 */
	private String orderDlvrgNo;
	/**
	 * OMS 접수 번호
	 */
	@JsonProperty("omsOrderRceptNo")
	private String omsRceptNo;
	/**
	 * 주문 상태
	 */
	private String orderSttus;
	/**
	 * 주문 홀딩 사용 여부
	 */
	private String orderHoldingUseAt;
	
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
}
