package com.sorincorp.api.credt.model;

import lombok.Data;

/**
 * DlivyStpgeVO.java
 * 출고중지 및 해제 관련 VO 객체
 * 
 * @version
 * @since 2024. 7. 19.
 * @author srec0049
 */
@Data
public class DlivyStpgeVO {

	/**
	 * 주문 번호
	 */
	private String orderNo;
	
	/**
	 * OMS 접수 번호
	 */
	private String omsRceptNo;
	
	/**
	 * 주문 상태: 3(출고중지) 4(출고중지 해제)
	 */
	private String orderSttus;
}
