package com.sorincorp.api.credt.model;

import lombok.Data;

@Data
public class LonOrderVO {
	/******  JAVA VO CREATE : IF_KODIT_LON_ORDER_BAS(인터페이스 신보 대출 매매 계약 기본)                                                    ******/
    /**
     * 인터페이스 순번
    */
    private long intrfcSn;
    /**
     * 대출 번호
    */
    private String lonNo;
    /**
     * 결재 수단 코드
    */
    private String sanctnMnCode;
    /**
     * 주문 일자
    */
    private String orderDe;
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 업체 명
    */
    private String entrpsNm;
    /**
     * 사업자 등록 번호
    */
    private String bsnmRegistNo;
    /**
     * 법인 등록 번호
    */
    private String cprRegistNo;
    /**
     * 판매자 사업자 등록 번호
    */
    private String selerBsnmRegistNo;
    /**
     * 판매자 법인 등록 번호
    */
    private String selerCprRegistNo;
    /**
     * 공급가
    */
    private long splpc;
    /**
     * 부가세
    */
    private long vat;
    /**
     * 판매가
    */
    private long slepc;
    /**
     * 구매자 은행 코드
    */
    private String purchsrBankCode;
    /**
     * 판매자 은행 코드
    */
    private String selerBankCode;
    /**
     * 판매자 계좌 번호
    */
    private String selerAcnutNo;
    /**
     * 세금계산서 승인 번호
    */
    private String taxbilConfmNo;
    /**
     * 세금계산서 일련 번호
    */
    private String taxbilSeqNo;
    /**
     * 세금계산서 발행 일자
    */
    private String taxbilIsuDe;
    /**
     * 세금계산서 발행 금액
    */
    private long taxbilIsuAmount;
    /**
     * 세금계산서 공급가
    */
    private long taxbilSplpc;
    /**
     * 대표 품목
    */
    private String repPrdlst;
    /**
     * 결제 예정 금액
    */
    private long setlePrearngeAmount;
    /**
     * 결제 예정 일자
    */
    private String setlePrearngeDe;
    /**
     * 만기 일자
    */
    private String exprtnDe;
    /**
     * 부가세 포함 여부
    */
    private String vatInclsAt;
    /**
     * 수동 여부
    */
    private String passivAt;
    /**
     * MP 수수료
    */
    private long mpFee;
    /**
     * 은행 수수료
    */
    private long bankFee;
    /**
     * 주문 상세 건수
    */
    private int orderDetailCo;
    /**
     * 처리 상태 코드
    */
    private String processSttusCode;
    
    
    /******  JAVA VO CREATE : IF_KODIT_LON_ORDER_DTL(인터페이스 신보 대출 매매 계약 상세)                                                    ******/
    /**
     * 매매 계약 상세 순번
    */
    private long trdeCntrctDetailSn;
    /**
     * 품목
    */
    private String prdlst;
    /**
     * 규격
    */
    private String stndrd;
    /**
     * 수량
    */
    private java.math.BigDecimal qy;
    /**
     * 수량 단위
    */
    private String qyUnit;
    /**
     * 단가
    */
    private long thngUntpc;
    /**
     * 공급가
    */
    private long thngSuplyAmount;
    /**
     * 부가세
    */
    private long thngTaxamt;
    /**
     * 판매가
    */
    private long thngSlePc;
    
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    
    /**
     * 대출 보증 신청 일자
     */
    private String lonGrntyReqstDe;
 
    /**
     * 대출 상태 코드
     */
    private String lonSttusCode;
}
