package com.sorincorp.api.credt.service;

import java.util.Map;

import com.sorincorp.api.credt.model.LonReqVO;

public interface LonService {
	
	/**
	 * <pre>
	 * 처리내용: 구매자금 대출한도 조회
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonReqVO
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> getLonLmt(LonReqVO lonReqVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 결제예정금액과 대출한도를 비교하여 대출가능여부를 판별한다.
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonNo
	 * @return
	 * @throws Exception
	 */
	boolean checkLonLmt(String lonNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 구매자금 대출을 위한 매매계약서 요청 처리
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonNo
	 * @throws Exception
	 */
	void ifKoditLonOrderBas(String lonNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 매매계약서 취소 요청 처리
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonNo
	 * @throws Exception
	 */
	void ifKoditLonOrderCanclBas(String lonNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 대출 승인 전문(K311 전문) 수신 후처리
	 * </pre>
	 * @date 2022. 9. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param lonNo
	 * @throws Exception
	 */
	void koditLonSetleProcess(String lonNo) throws Exception;
}
