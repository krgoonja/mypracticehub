package com.sorincorp.api.credt.mapper;

import com.sorincorp.api.credt.dto.CredtMrtggTrnsmisDto;
import com.sorincorp.api.credt.model.DlivyStpgeVO;
import com.sorincorp.api.credt.model.IfKoditMrtggOrderVO;
import com.sorincorp.api.credt.model.MbEntrpsMlgInfoDtlVO;
import com.sorincorp.api.credt.model.MbEntrpsMrtggLmtDtlVO;
import com.sorincorp.api.credt.model.OrMrtggBasVO;
import com.sorincorp.api.credt.model.OrMrtggDtlVO;
import com.sorincorp.api.or.model.OrOrderBasVO;

public interface MrtggMapper {

	/**
	 * <pre>
	 * 담보 매매계약 주문 정보 조회
	 * </pre>
	 * @date 2022. 7. 29.
	 * @author srec0051
	 * @param param
	 * @return
	 * @throws Exception
	 */
	IfKoditMrtggOrderVO selectIfKoditMrtggOrder(CredtMrtggTrnsmisDto param) throws Exception;

	/**
	 * <pre>
	 * 신보담보매매계약기본 등록 (IF TABLE)
	 * </pre>
	 * @date 2022. 7. 29.
	 * @author srec0051
	 * @param orderVo
	 * @return
	 * @throws Exception
	 */
	int insertIfKoditMrtggOrderBas(IfKoditMrtggOrderVO orderVo) throws Exception;

	/**
	 * <pre>
	 * 신보담보매매계약상세 등록 (IF TABLE)
	 * </pre>
	 * @date 2022. 7. 29.
	 * @author srec0051
	 * @param orderVo
	 * @return
	 * @throws Exception
	 */
	int insertIfKoditMrtggOrderDtl(IfKoditMrtggOrderVO orderVo) throws Exception;

	/**
	 * <pre>
	 * 주문 기본 조회
	 * </pre>
	 * @date 2022. 7. 29.
	 * @author srec0051
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	OrOrderBasVO selectOrder(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 주문 담보 상세 등록
	 * </pre>
	 * @date 2022. 7. 29.
	 * @author srec0051
	 * @param mrtggDtlVo
	 * @return
	 */
	int insertOrMrtggDtl(OrMrtggDtlVO mrtggDtlVo) throws Exception;
	int insertOrMrtggDtlHst(OrMrtggDtlVO mrtggDtlVo) throws Exception;

	/**
	 * <pre>
	 * 담보 기본 미상환금액, 상태코드 update
	 * </pre>
	 * @date 2022. 7. 29.
	 * @author srec0051
	 * @param mrtggBasVo
	 * @return
	 */
	int setOrMrtggBasNrdmpAmountAndSttusCode(OrMrtggBasVO mrtggBasVo) throws Exception;

	int insertOrMrtggBasHst(OrMrtggBasVO mrtggBasVo);

	/**
	 * <pre>
	 * 주문 기본 미결제금액 update
	 * </pre>
	 * @date 2022. 7. 29.
	 * @author srec0051
	 * @param orderBasVo
	 * @return
	 */
	int setOrOrderBasUnSetleAmount(OrOrderBasVO orderBasVo) throws Exception;

	int insertOrOrderBasHst(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 회원 업체 담보 한도 상세 등록 데이터 조회
	 * </pre>
	 * @date 2022. 8. 1.
	 * @author srec0051
	 * @param memldVo
	 * @return
	 */
	MbEntrpsMrtggLmtDtlVO selectMbEntrpsMrtggLmtDtl(MbEntrpsMrtggLmtDtlVO memldVo) throws Exception;

	/**
	 * <pre>
	 * 회원 업체 담보 한도 상세 등록
	 * </pre>
	 * @date 2022. 8. 1.
	 * @author srec0051
	 * @param memldVo
	 * @return
	 */
	int insertMbEntrpsMrtggLmtDtl(MbEntrpsMrtggLmtDtlVO memldVo) throws Exception;

	int insertMbEntrpsMrtggLmtDtlHst(MbEntrpsMrtggLmtDtlVO memldVo) throws Exception;

	/**
	 * <pre>
	 * 인터페이스 신보 담보 결제 등록 IF TABLE
	 * </pre>
	 * @date 2022. 8. 1.
	 * @author srec0051
	 * @param ifKoditMrtggOrderVo
	 * @return
	 */
	int insertIfKoditMrtggSettleBas(IfKoditMrtggOrderVO ifKoditMrtggOrderVo) throws Exception;

	/**
	 * <pre>
	 * 중도상환 마일리지 계산
	 * </pre>
	 * @date 2022. 8. 8.
	 * @author srec0051
	 * @param paramDto
	 * @return
	 */
	long getMdstrmRepyMileage(CredtMrtggTrnsmisDto paramDto) throws Exception;

	/**
	 * <pre>
	 * 회원_업체 마일리지 내역 상세 등록
	 * </pre>
	 * @date 2022. 8. 9.
	 * @author srec0051
	 * @param build
	 * @return
	 */
	int insertMbEntrpsMileage(MbEntrpsMlgInfoDtlVO mileageVo) throws Exception;

	int insertMbEntrpsMileageHst(MbEntrpsMlgInfoDtlVO mileageVo) throws Exception;

	/**
	 * <pre>
	 * 담보기본 미결제금액 조회
	 * </pre>
	 * @date 2022. 8. 17.
	 * @author srec0051
	 * @param paramDto
	 * @return
	 */
	long getNrdmpAmount(CredtMrtggTrnsmisDto paramDto) throws Exception;

	/**
	 * <pre>
	 * 결제기본 거래금액 조회
	 * </pre>
	 * @date 2022. 8. 17.
	 * @author srec0051
	 * @param paramDto
	 * @return
	 */
	long getDelngAmount(CredtMrtggTrnsmisDto paramDto) throws Exception;

	/**
	 * <pre>
	 * 담보 기본 매매계약 결과 등록
	 * </pre>
	 * @date 2022. 8. 19.
	 * @author srec0051
	 * @param mrtggBasVo
	 * @return
	 */
	int updateOrMrtggBasSttusCode(OrMrtggBasVO mrtggBasVo);

	int updateOrMrtggBasSttusCode2(OrMrtggBasVO mrtggBasVo) throws Exception;

	/**
	 * <pre>
	 * 담보 상세 결과 업데이트
	 * </pre>
	 * @date 2022. 8. 22.
	 * @author srec0051
	 * @param mrtggDtlVo
	 * @return
	 */
	int updateOrMrtggDtlSttusCode(OrMrtggDtlVO mrtggDtlVo) throws Exception;

	/**
	 * <pre>
	 * 담보 기본 이전 데이터 삭제
	 * </pre>
	 * @date 2022. 9. 7.
	 * @author srec0051
	 * @param mrtggBasVo
	 * @return
	 */
	int updatePreOrMrtggBas(OrMrtggBasVO mrtggBasVo) throws Exception;

	/**
	 * <pre>
	 * 담보 기본 신규 데이터 생성
	 * </pre>
	 * @date 2022. 9. 7.
	 * @author srec0051
	 * @param mrtggBasVo
	 * @return
	 */
	int insertNewOrMrtggBas(OrMrtggBasVO mrtggBasVo) throws Exception;

	/**
	 * <pre>
	 * 담보 상세 실패건 조회
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0051
	 * @param paramDto
	 * @return
	 */
	OrMrtggDtlVO selectFailMrtggDtl(CredtMrtggTrnsmisDto paramDto) throws Exception;

	/**
	 * <pre>
	 * 담보 상세 실패건 수정
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0051
	 * @param mrtggDtlVo
	 * @return
	 */
	int updateFailToReqstOrMrtggDtl(OrMrtggDtlVO mrtggDtlVo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문_담보 중도 상환 상세의 상환 완료 여부와 담보 상세 순번 수정
	 * </pre>
	 * @date 2024. 7. 3.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 7. 3.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param mrtggDtlVo
	 * @return
	 * @throws Exception
	 */
	int updateRepyComptOrMrtggMdstrmRepyDtl(OrMrtggDtlVO mrtggDtlVo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문_담보 중도 상환 상세 이력 등록
	 * </pre>
	 * @date 2024. 7. 3.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 7. 3.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param mrtggDtlVo
	 * @return
	 * @throws Exception
	 */
	int insertOrMrtggMdstrmRepyDtlHst(OrMrtggDtlVO mrtggDtlVo) throws Exception;
		
	/**
	 * <pre>
	 * 처리내용: 출고 중지된 건 중에 상환 완료된 주문 정보 가져오기
	 * </pre>
	 * @date 2024. 7. 19.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 7. 19.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	DlivyStpgeVO getOrderInfoByDlivyStpgeRepyCompt(String orderNo) throws Exception;

	void insertEwalletSetle(OrOrderBasVO orOrderBasVO) throws Exception;

	void insertOrSetleBasHst(OrOrderBasVO orOrderBasVO) throws Exception;

	String selectEwalletRspnCode(String delngSeqNo) throws Exception;

}
