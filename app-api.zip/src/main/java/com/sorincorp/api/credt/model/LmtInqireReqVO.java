package com.sorincorp.api.credt.model;

import lombok.Data;

@Data
public class LmtInqireReqVO {
	/**
	 * 구매사 사업자번호 10자리
	 */
	private String buyBusinessNo;
	/**
	 * 구매사 법인번호 13자리, 개인기업의 경우 0000000000000
	 */
	private String buyIncorpoNo;
	/**
	 * 은행고유코드 7자리
	 */
	private String bankCode;
	/**
	 * 결제수단코드
	 * 2. 구매카드대출 / 3. 구매론대출 / 4. 구매자금대출
	 */
	private String settlementtype;
}
