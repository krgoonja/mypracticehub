package com.sorincorp.api.credt.model;

import lombok.Data;

@Data
public class IfKoditMrtggOrderDtlVO {

	/******  JAVA VO CREATE : IF_KODIT_MRTGG_ORDER_DTL(인터페이스 신보 담보 매매 계약 상세)                                                  ******/
    /**
     * 인터페이스 순번
    */
    private long intrfcSn;
    /**
     * 매매 계약 상세 순번
    */
    private long trdeCntrctDetailSn;
    /**
     * 품목
    */
    private String prdlst;
    /**
     * 규격
    */
    private String stndrd;
    /**
     * 수량
    */
    private java.math.BigDecimal qy;
    /**
     * 수량 단위
    */
    private String qyUnit;
    /**
     * 단가
    */
    private long untpc;
    /**
     * 공급가
    */
    private long splpc;
    /**
     * 부가세
    */
    private long vat;
    /**
     * 판매가
    */
    private long slepc;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;

}
