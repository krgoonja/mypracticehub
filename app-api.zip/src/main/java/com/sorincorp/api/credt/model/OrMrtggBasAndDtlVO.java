package com.sorincorp.api.credt.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class OrMrtggBasAndDtlVO extends OrMrtggDtlVO {

	/******  JAVA VO CREATE : OR_MRTGG_BAS(주문_담보 기본)                                                                                   ******/
    /**
     * 담보 번호
    */
    private String mrtggNo;
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 담보 상태 코드
    */
    private String mrtggSttusCode;
    /**
     * 상환 기간
    */
    private int repyPd;
    /**
     * 결제 예정 일자
    */
    private String setlePrearngeDe;
    /**
     * 주문 시점 총 한도 금액
    */
    private long orderPnttmTotLmtAmount;
    /**
     * 주문 시점 잔여 한도 금액
    */
    private long orderPnttmRemndrLmtAmount;
    /**
     * 보증 번호
    */
    private String grntyNo;
    /**
     * 보증 기한 시작 일자
    */
    private String grntyTmlmtBeginDe;
    /**
     * 보증 기한 종료 일자
    */
    private String grntyTmlmtEndDe;
    /**
     * CD 금리
    */
    private java.math.BigDecimal cdInrst;
    /**
     * 케이지트레이딩 가산 금리
    */
    private java.math.BigDecimal sorinAddiInrst;
    /**
     * 연간 은행 일자
    */
    private int fyerBankDe;
    /**
     * 이자율
    */
    private java.math.BigDecimal intrt;
    /**
     * 단가 인상 금액
    */
    private long untpcIncrseAmount;
    /**
     * 공급가
    */
    private long splpc;
    /**
     * 부가세
    */
    private long vat;
    /**
     * 판매가
    */
    private long slepc;
    /**
     * 미상환 금액
    */
    private long nrdmpAmount;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;

}
