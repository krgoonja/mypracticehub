package com.sorincorp.api.credt.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MbEntrpsMlgInfoDtlVO {

	/******  JAVA VO CREATE : MB_ENTRPS_MLG_INFO_DTL(회원_업체 마일리지 내역 상세)                                                           ******/
    /**
     * 마일리지 순번
    */
    private long mlgSn;
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 마일리지 거래 일시
    */
    private String mlgDelngDt;
    /**
     * 마일리지 만료 일자
    */
    private String mlgEndDe;
    /**
     * 마일리지 구분
    */
    private String mlgSe;
    /**
     * 마일리지 유형
    */
    private String mlgTy;
    /**
     * 마일리지 상세 내역
    */
    private String mlgDetailDtls;
    /**
     * 거래 마일리지
    */
    private int delngMlg;
    /**
     * 잔여 마일리지
    */
    private int remndrMlg;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 취소 교환 반품 번호
    */
    private String canclExchngRtngudNo;
    /**
     * 보증 번호
     */
    private String grntyNo;
}
