package com.sorincorp.api.credt.model;

import lombok.Data;

@Data
public class IfKoditLonSettleBasVO {
	/******  JAVA VO CREATE : IF_KODIT_LON_SETTLE_BAS(인터페이스 신보 대출 결제 )                                                            ******/
    /**
     * 인터페이스 순번
    */
    private long intrfcSn;
    /**
     * 대출 번호
    */
    private String lonNo;
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 통보 구분 코드
    */
    private String dspthSeCode;
    /**
     * 결재 수단 코드
    */
    private String sanctnMnCode;
    /**
     * 결제 일자
    */
    private String setleDe;
    /**
     * 결제 금액
    */
    private long setleAmount;
    /**
     * MP 수수료
    */
    private long mpFee;
    /**
     * 은행 수수료
    */
    private long bankFee;
    
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 대출 상태 코드
    */
    private String lonSttusCode;
    /**
     * 처리 상태 코드 (인터페이스 테이블 업데이트 용)
     */
    private String processSttusCode;
}
