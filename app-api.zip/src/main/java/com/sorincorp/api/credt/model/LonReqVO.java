package com.sorincorp.api.credt.model;

import lombok.Data;

@Data
public class LonReqVO {
	/**
	 * 대출 번호
	 */
	private String lonNo;
	/**
	 * EC주문번호
	 */
	private String orderNo;
	/**
	 * 업체 번호
	 */
	private String entrpsNo;
	/**
	 * 은행 코드
	 */
	private String bankCode;
	/**
	 * 결제 수단 코드
	 * 2. 구매카드대출 / 3. 구매론대출 / 4. 구매자금대출
	 */
	private String sanctnMnCode;
	/**
	 * 결제 예정 금액
	 */
	private String setlePrearngeAmount;
}
