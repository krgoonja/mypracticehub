package com.sorincorp.api.taxBill.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sorincorp.api.taxBill.model.TaxBillECVO;
import com.sorincorp.api.taxBill.model.TaxBillRequestVO;

public interface TaxBillMapper {

	/**주문_세금계산서 정보 조회*/
	TaxBillECVO selectOrderTaxbillInfo(TaxBillRequestVO requestVo);
	
	/**클레임_세금계산서 정보 조회*/
	TaxBillECVO selectClaimTaxbillInfo(TaxBillRequestVO requestVo);
	
	/**주문_세금계산서 상세 정보 조회 (주문가격)*/
	TaxBillECVO selectOrderPcDtlInfo(TaxBillRequestVO requestVo);
	
	/**주문_세금계산서 상세 정보 조회 (중량변동금)*/
	TaxBillECVO selectWtChangegldDtlInfo(TaxBillRequestVO requestVo);
	
	/**주문_세금계산서 상세 정보 조회 (케이지배송비)*/
	TaxBillECVO selectSorinDlvyDtlInfo(TaxBillRequestVO requestVo);

	/**주문_세금계산서 상세 정보 조회 (가격변동금)*/
	TaxBillECVO selectPcChangegldInfo(TaxBillRequestVO requestVo);

	/**주문_세금계산서 상세 정보 조회 (확정단가차이)*/
	TaxBillECVO selectDcsnUntpcDiffInfo(TaxBillRequestVO requestVo);

	/**클레임_세금계산서 상세 정보 조회 (미정)*/
	List<TaxBillECVO> selectClaimTaxbillDtlInfo(TaxBillRequestVO requestVo);
	
	/**주문_세금계산서_기본 (OR_TAX_BILL_BAS) 데이터 적재*/
	void saveOrTaxBillBas(TaxBillECVO taxBillECVo);
	
	/**주문_세금계산서_상세 (OR_TAX_BILL_DTL) 데이터 적재*/
	void saveOrTaxBillDtl(TaxBillECVO taxBillECVo);
	
	/**인터페이스_세금계산서_기본 (IF_OR_TAX_BILL_BAS) 데이터 적재*/
	void saveIfOrTaxBillBas(TaxBillECVO taxBillECVo);
	
	/**인터페이스_세금계산서_상세 (IF_OR_TAX_BILL_DTL) 데이터 적재*/
	void saveIfOrTaxBillDtl(TaxBillECVO taxBillECVo);
	
	/**주문_세금계산서_기본 이력*/
	void saveOrTaxBillBasHst(TaxBillECVO taxBillECVo);
	
	/**주문_세금계산서_상세 이력*/
	void saveOrTaxBillDtlHst(TaxBillECVO taxBillECVo);
	
	/* 주문_세금계산서 발행 가능 여부 조회 */
	Map<String, Object> selectTaxbillIsuPossAt(TaxBillECVO taxBillECVo);

	/* 해당 월의 첫 영업일 또는 마지막 영업일 조회 */
	String getFirstOrLastBusinessDayOfMonth(@Param("taxBillIsuMonth") String taxBillIsuMonth, @Param("avrgpcTaxBillIsuPnttmCode") String avrgpcTaxBillIsuPnttmCode);
	
}//end interface()
