package com.sorincorp.api.taxBill.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.taxBill.comm.constant.TaxBillCommConstant;
import com.sorincorp.api.taxBill.comm.entity.TaxBillResponseEntity;
import com.sorincorp.api.taxBill.model.TaxBillRequestVO;
import com.sorincorp.api.taxBill.service.TaxBillService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/taxBill")
@Api("세금계산서")
public class TaxBillController {
	
	@Autowired
	private TaxBillService taxBillService;
	
	@PostMapping("/TaxBillIsu")
	@ApiOperation(value = "세금계산서 발행요청 botobi 송신", notes = "세금계산서 발행요청 botobi 송신")
	public ResponseEntity<?> taxBillIsu(@RequestBody TaxBillRequestVO requestVo, HttpServletRequest request) throws Exception {
		log.debug("TaxBillController:saveTaxBillIsu 세금계산서 발행 Start");
		
		//세금 계산서 발행 Process
		String resultMsg = taxBillService.taxBillIsu(requestVo);
		
		log.debug("TaxBillController:saveTaxBillIsu 세금계산서 발행 End");
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(new TaxBillResponseEntity(TaxBillCommConstant.SUCCESS_RESULT_CODE, resultMsg));
	}//end taxBillIsu()
}//end class()
