package com.sorincorp.api.taxBill.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.sorincorp.api.taxBill.comm.constant.TaxBillCommConstant;
import com.sorincorp.api.taxBill.mapper.TaxBillMapper;
import com.sorincorp.api.taxBill.model.TaxBillECVO;
import com.sorincorp.api.taxBill.model.TaxBillRequestVO;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TaxBillServiceImpl implements TaxBillService {

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private TaxBillMapper taxBillMapper;

	@Autowired
	private AssignService assignService;
	

	/**세금계산서 발행
	 * @return */
	@Transactional(rollbackFor = Exception.class)
	@Override
	public String taxBillIsu(TaxBillRequestVO requestVo) throws Exception {
		log.debug("Start TaxBillServiceImpl:taxBillIsu (세금계산서 발행)");

		//인터페이스 송신 전문 등록 (IF_LOG)
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(TaxBillCommConstant.TAX_BILL_IF, requestVo);

		try {
			//세금 계산서 발행 프로그램 실행 파라미터 유효성 검사 
			validateRequestParams(requestVo);
			
			//세금계산서 발행여부 체크 로직 : 이미 발행이 되었다면 세금 계산서 프로세스 Skip
			//23-11-24 변경사항 : 세금계산서 발행여부 체크 로직을 세금계산서 발행 가능 여부 체크 로직으로 변경
			if(isTaxbillIsuPossAt(requestVo)) {
				log.debug("TaxBillServiceImpl:taxBillIsu 신규 세금계산서 발행");
				//세금계산서 발행요청 btobi 송신 프로세스
				selectTaxBillIsuProcess(requestVo);
				
				btbLogVo.setIntrfcRspnsCode(TaxBillCommConstant.SUCCESS_RESULT_CODE);
				btbLogVo.setIntrfcRspnsCn(TaxBillCommConstant.SUCCESS_RESULT_MSG);
			} else {
				log.debug("TaxBillServiceImpl:taxBillIsu 발행 로직 스킵");
				btbLogVo.setIntrfcRspnsCode(TaxBillCommConstant.SUCCESS_RESULT_CODE);
				btbLogVo.setIntrfcRspnsCn(TaxBillCommConstant.SKIP_RESULT_MSG);
				
				return TaxBillCommConstant.SKIP_RESULT_MSG;
			}
		} catch (Exception e) {

			btbLogVo.setIntrfcRspnsCode(TaxBillCommConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			log.error("TaxBillServiceImpl::taxBillIsu exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		} finally {
			//인터페이스 수신 전문 등록 (IF_LOG)
			httpClientHelper.updateBtbLog(btbLogVo);
		}

		log.debug("TaxBillServiceImpl:taxBillIsu (세금계산서 발행) End");
		
		return TaxBillCommConstant.SUCCESS_RESULT_MSG;
	}//end taxBillIsu()

	/**
	 *
	 * <pre>
	 * 세금계산서 발행요청 btobi 송신 프로세스
	 * </pre>
	 * @date 2021. 9. 1.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 1.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	TaxBillRequestVO requestVo
	 * @throws 	Exception
	 */
	public void selectTaxBillIsuProcess(TaxBillRequestVO requestVo) throws Exception {
		log.debug("TaxBillServiceImpl:selectTaxBillIsuProcess (세금계산서 발행요청 btobi 송신 프로세스) Start");

		String orderNo 				= requestVo.getOrderNo();				//주문 번호
		String canclExchngRtngudNo	= requestVo.getCanclExchngRtngudNo();	//취소 교환 반품 번호
		String jobSe				= requestVo.getJobSe();					//업무 구분 (ORDER	: 주문, WT : 상차, 배송완료 (차이 중량 계산), CANCL : 취소, RTNGUD	: 반품, EXCHNG : 교환)

		log.debug("orderNo 				==========> " + orderNo);
		log.debug("canclExchngRtngudNo 	==========> " + canclExchngRtngudNo);
		log.debug("jobSe 				==========> " + jobSe);

		try {

			//1. 주문, 인터페이스 세금계산서 기본 (주문가격 + 중량변동금 + 케이지배송비 = 1row)
			TaxBillECVO taxBillEcNewNumberVo = orTaxBillBasProcess(requestVo);

			if(taxBillEcNewNumberVo != null) {
				//2. 주문, 인터페이스 세금계산서 상세 (주문가격, 중량변동금, 케이지배송비 = 3row)
				orTaxBillDtlProcess(requestVo, taxBillEcNewNumberVo);
			}//end if()

		} catch (Exception e) {

			log.error("TaxBillServiceImpl::selectTaxBillIsuProcess exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		}

		log.debug("TaxBillServiceImpl:selectTaxBillIsuProcess (세금계산서 발행요청 btobi 송신 프로세스) End");
	}//end selectTaxBillIsuProcess()

	/**
	 *
	 * <pre>
	 * 주문, 인터페이스 세금계산서 기본 (주문가격 + 중량변동금 + 케이지배송비 = 1row)
	 * </pre>
	 * @date 2022. 1. 5.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 5.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	TaxBillRequestVO requestVo
	 * @return 	TaxBillECVO
	 * @throws 	Exception
	 */
	public TaxBillECVO orTaxBillBasProcess(TaxBillRequestVO requestVo) throws Exception {
		log.debug("TaxBillServiceImpl:orTaxBillBasProcess (주문, 인터페이스 세금계산서 기본) Start");

		TaxBillECVO taxBillECVo = new TaxBillECVO();
		String jobSe			= requestVo.getJobSe(); //업무 구분 (ORDER	: 주문, WT : 상차, 배송완료 (차이 중량 계산), CANCL : 취소, RTNGUD	: 반품, EXCHNG : 교환)
		
		try {

			//세금계산서 정보 조회
			//22-12-08 변경사항 : 판매방식이 고정가인 주문에 대해서, 해당 주문 건의 권역 대분류 코드에 따라 공급자(사업장) 정보가 바뀌도록 조회 쿼리문 변경
			//23-12-08 변경사항 : 판매방식이 평균가인 주문에 대해서, 해당 주문 건이 단가 확정 전인 주문이면, 가단가를 기준으로 한 가격 정보를 가져오도록 쿼리문 변경
			//24-09-27 변경사항 : 가단가 주문도 평균가 주문과 동일하게 가격 정보를 가져오도록 쿼리문 변경
			if(TaxBillCommConstant.JOB_SE_ORDER.equals(jobSe)
					|| TaxBillCommConstant.JOB_SE_WT.equals(jobSe)) {
				taxBillECVo = taxBillMapper.selectOrderTaxbillInfo(requestVo);
			} else if(TaxBillCommConstant.JOB_SE_CANCL.equals(jobSe)
					|| TaxBillCommConstant.JOB_SE_RTNGUD.equals(jobSe)
					|| TaxBillCommConstant.JOB_SE_EXCHNG.equals(jobSe)) {
				//23-02-20 변경사항 : "발행완료"된 주문세금계산서가 존재할 시에만 클레임세금계산서 발행 처리, 주문세금계산서가 없을 시 taxBillECVo = null 로 로직 통과
				taxBillECVo = taxBillMapper.selectClaimTaxbillInfo(requestVo);
			} else {
				log.debug("TaxBillServiceImpl::orTaxBillBasProcess jobSe is null");
			}//end if()

			if(taxBillECVo != null) {

				taxBillECVo.setJobSe(jobSe);							//업무 구분
				taxBillECVo.setSysSe(TaxBillCommConstant.SECS);			//시스템 구분 : SECS
				
				// 24-03-05 변경사항 : 평균가 주문(04)의 수정세금계산서 신청일자, 작성일자를 변경해주기 위해 로직 추가
				if(TaxBillCommConstant.JOB_SE_WT.equals(jobSe)						// 수정세금계산서(jobSe = WT)일 경우
						&& StringUtils.isNotEmpty(taxBillECVo.getUntpcDcsnDe())) {	// 평균가 주문(04)일 때만 단가 확정 일자(untpcDcsnDe) 데이터 존재
					String untpcDcsnDe = taxBillECVo.getUntpcDcsnDe();	// 단가 확정 일자
					String avrgpcTaxBillIsuPnttmCode = taxBillECVo.getAvrgpcTaxBillIsuPnttmCode();	// 세금계산서 발행 시점 코드
					
					if(StringUtils.equals(avrgpcTaxBillIsuPnttmCode, "10")) {	// 세금계산서 발행 시점 : 익월 첫 영업일 (10)
						untpcDcsnDe = DateUtil.removeFormat(DateUtil.addMonths(untpcDcsnDe, 1));	// 익월 계산, 포맷은 yyyyMMdd
					}
					
					String taxBillIsuMonth = untpcDcsnDe.substring(0,6);	// 세금계산서 발행 월을 구하기 위해 데이터 추출, 포맷은 yyyyMM
					
					// 세금계산서 발행 시점 코드에 따라, 세금계산서 발행 월에 해당하는 첫 영업일 또는 마지막 영업일 조회
					String taxBillReqstDe = taxBillMapper.getFirstOrLastBusinessDayOfMonth(taxBillIsuMonth, avrgpcTaxBillIsuPnttmCode);
					
					// 24-03-18 변경사항 : 조회된 영업일이 기존에 발행된 주문세금계산서의 신청일자보다 이전일 경우, 조회된 영업일을 세팅하지 않음
					if(DateUtil.compareToCalerdar(taxBillReqstDe, taxBillECVo.getOrderTaxBillReqstDe()) < 0) {
						// 위에서 조회된 영업일로 세팅 안 함, 기존 로직에서 세팅된 오늘 날짜나 마지막 상차일 데이터 유지
					} else {
						taxBillECVo.setTaxBillReqstDe(taxBillReqstDe);
						taxBillECVo.setWritngDe(taxBillReqstDe);
					}
				}

				// 24-04-01 변경사항 : 평균가 주문(04)의 수정세금계산서 신청일자, 작성일자 변경에 따라 채번도 동일 적용 되어야함
				taxBillECVo = selectRmInfoFunction(taxBillECVo);		//비고 (기본 전용)
				taxBillECVo = selectTaxBillCommCdInfo(taxBillECVo);		//코드 (기본 전용)
				taxBillECVo = selectTaxBasNewNumber(taxBillECVo);		//채번 (기본 전용)
				/*
				 * 주문_세금계산서_기본 		(OR_TAX_BILL_BAS)
				 * 인터페이스_세금계산서_기본 	(IF_OR_TAX_BILL_BAS)
				 * 데이터 적재
				 */
				saveOrTaxBillBas(taxBillECVo);

			} else if(taxBillECVo == null && (   TaxBillCommConstant.JOB_SE_CANCL.equals(jobSe)
											  || TaxBillCommConstant.JOB_SE_RTNGUD.equals(jobSe)
											  || TaxBillCommConstant.JOB_SE_EXCHNG.equals(jobSe)) ) {
				log.debug("orTaxBillBasProcess:: 기발행된 주문 세금계산서가 존재하지 않음으로, 클레임 세금계산서 발행 로직을 종료합니다.");
			} else {
				log.debug("orTaxBillBasProcess::taxBillECVo is null");
			}//end if()

		} catch (Exception e) {
			log.error("TaxBillServiceImpl::orTaxBillBasProcess exception = " + e.getMessage());
			throw new Exception(e.getMessage());
		}

		log.debug("TaxBillServiceImpl:orTaxBillBasProcess (주문, 인터페이스 세금계산서 기본) End");
		return taxBillECVo;
	}//end orTaxBillBasProcess()

	/**
	 *
	 * <pre>
	 * 주문, 인터페이스 세금계산서 상세 (주문가격, 중량변동금, 케이지배송비 = 3row)
	 * </pre>
	 * @date 2022. 1. 5.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 5.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	TaxBillRequestVO requestVo, TaxBillECVO taxBillEcVo
	 * @throws 	Exception
	 */
	public void orTaxBillDtlProcess(TaxBillRequestVO requestVo, TaxBillECVO taxBillEcNewNumberVo) throws Exception {
		log.debug("TaxBillServiceImpl:orTaxBillDtlProcess (주문, 인터페이스 세금계산서 상세) Start");

		List<TaxBillECVO> taxBillECList = new ArrayList<TaxBillECVO>();
		String jobSe					= requestVo.getJobSe(); //업무 구분 (ORDER	: 주문, WT : 상차, 배송완료 (차이 중량 계산), CANCL : 취소, RTNGUD	: 반품, EXCHNG : 교환)

		try {

			//세금계산서 정보 조회
			//23-12-08 변경사항 : 판매방식이 평균가인 주문에 대해서, 해당 주문 건이 단가 확정 전인 주문이면, 가단가를 기준으로 한 가격 정보를 가져오도록 쿼리문 변경
			if(TaxBillCommConstant.JOB_SE_ORDER.equals(jobSe)
					|| TaxBillCommConstant.JOB_SE_WT.equals(jobSe)) {

				TaxBillECVO orderPcVo 		= taxBillMapper.selectOrderPcDtlInfo(requestVo);		//주문가격
				TaxBillECVO wtChangegldVo 	= taxBillMapper.selectWtChangegldDtlInfo(requestVo);	//중량변동금

				if(orderPcVo != null) 		taxBillECList.add(orderPcVo);
				if(wtChangegldVo != null) 	taxBillECList.add(wtChangegldVo);

				//판매 정산인 경우 케이지배송비 정보 추가
				//중량 정산인 경우 케이지배송비 정보 제외
				if(TaxBillCommConstant.JOB_SE_ORDER.equals(jobSe))	{

					TaxBillECVO sorinDlvyVo = taxBillMapper.selectSorinDlvyDtlInfo(requestVo);		//케이지배송비
					if(sorinDlvyVo != null)	{

						//배송 수단 : 케이지배송인 경우
						String dlvyMnCode = sorinDlvyVo.getDlvyMnCode();
						if("01".equals(dlvyMnCode)) taxBillECList.add(sorinDlvyVo);

					}//end if()

				}//end if()
				
				// 24-09-30 변경사항 : 가단가 주문(05)일 경우, 가격변동금 정보를 추가하고, 수정세금계산서일 경우, 확정단가차이 정보도 추가한다.
				if(StringUtils.equals(taxBillEcNewNumberVo.getSleMthdCode(), "05")) {
					// 가격변동금 정보 조회
					TaxBillECVO pcChangegldVo = taxBillMapper.selectPcChangegldInfo(requestVo);
					
					if(pcChangegldVo != null)    taxBillECList.add(pcChangegldVo);
					
					// 수정세금계산서일 경우
					if(TaxBillCommConstant.JOB_SE_WT.equals(jobSe)) {
						// 확정단가차이 정보 조회
						TaxBillECVO dcsnUntpcDiffVo = taxBillMapper.selectDcsnUntpcDiffInfo(requestVo);
						
						if(dcsnUntpcDiffVo != null)    taxBillECList.add(dcsnUntpcDiffVo);
					}
				}

			} else if(TaxBillCommConstant.JOB_SE_CANCL.equals(jobSe)
					|| TaxBillCommConstant.JOB_SE_RTNGUD.equals(jobSe)
					|| TaxBillCommConstant.JOB_SE_EXCHNG.equals(jobSe)) {
				//세금계산서 상세 : 클레임 항목 미정
				// 22.11.07 변경사항 : 해당 주문 건의 주문_세금계산서_상세 데이터로 클레임 항목 조회 
				taxBillECList = taxBillMapper.selectClaimTaxbillDtlInfo(requestVo);
			} else {
				log.debug("TaxBillServiceImpl::orTaxBillDtlProcesss jobSe is null");
			}//end if()

			if(!CollectionUtils.isEmpty(taxBillECList)) {

				for(TaxBillECVO taxBillEcVo : taxBillECList) {

					taxBillEcVo.setJobSe(jobSe);							//업무 구분
					taxBillEcVo.setSysSe(TaxBillCommConstant.SECS);			//시스템 구분 : SECS

					TaxBillECVO taxBillDtlNewNumberVo = selectTaxDtlNewNumber(taxBillEcNewNumberVo);	//채번 (상세 전용)

					if(taxBillDtlNewNumberVo != null) {
						taxBillEcVo.setTaxBillReqstNo(taxBillDtlNewNumberVo.getTaxBillReqstNo());       		//세금 계산서 신청 번호
						taxBillEcVo.setTaxBillReqstDetailSn(taxBillDtlNewNumberVo.getTaxBillReqstDetailSn()); 	//세금 계산서 신청 상세 순번
						taxBillEcVo.setTaxBillGoodsSeqNo(taxBillDtlNewNumberVo.getTaxBillGoodsSeqNo());    		//세금 계산서 상품 일련 번호
						taxBillEcVo.setIntrfcSn(taxBillDtlNewNumberVo.getIntrfcSn());             				//인터페이스 순번
						taxBillEcVo.setIntrfcDetailSn(taxBillDtlNewNumberVo.getIntrfcDetailSn());       		//인터페이스 상세 순번
						taxBillEcVo.setThngSeqNo(taxBillDtlNewNumberVo.getThngSeqNo());            				//물품 일련 번호
					} else {
						log.debug("orTaxBillDtlProcess::taxBillDtlNewNumberVo is null");
					}//end if()
					
					// 23-11-24 변경사항 : 평균가 - 평균가 주문의 수정세금계산서일 경우, 수량(thngRm)과 단가(thngUntpc) 항목을 NULL 처리
					if(StringUtils.equals(taxBillEcNewNumberVo.getSleMthdCode(), "04") && TaxBillCommConstant.JOB_SE_WT.equals(jobSe)) {
						taxBillEcVo.setThngRm(null);
						taxBillEcVo.setThngUntpc(null);
					}

					/*
					 * 주문_세금계산서_상세 		(OR_TAX_BILL_DTL)
					 * 인터페이스_세금계산서_상세 	(IF_OR_TAX_BILL_DTL)
					 * 데이터 적재
					 */
					saveOrTaxBillDtl(taxBillEcVo);

				}//end for()

			} else {
				log.debug("orTaxBillDtlProcess::taxBillECList is null");
			}//end if()

		} catch (Exception e) {
			log.error("TaxBillServiceImpl::orTaxBillDtlProcess exception = " + e.getMessage());
			throw new Exception(e.getMessage());
		}

		log.debug("TaxBillServiceImpl:orTaxBillDtlProcess (주문, 인터페이스 세금계산서 상세) End");
	}//end orTaxBillDtlProcess()

	/***
	 *
	 * <pre>
	 * 비고 (기본 전용)
	 * </pre>
	 * @date 2021. 9. 1.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 1.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	TaxBillECVO taxBillECVo
	 * @return	TaxBillECVO
	 * @throws 	Exception
	 */
	public TaxBillECVO selectRmInfoFunction(TaxBillECVO taxBillECVo) throws Exception {
		log.debug("TaxBillServiceImpl:selectRmInfoFunction (비고) Start");
		StringBuilder thngRm 	= new StringBuilder();

		try {

			String jobSe = taxBillECVo.getJobSe(); //업무 구분

			if(TaxBillCommConstant.JOB_SE_ORDER.equals(jobSe)) {
				//케이지배송
				if(taxBillECVo.getDlvyMnCode().equals("01")){
					//중량변동 0
					if(taxBillECVo.getWtChange() == 0) {
						thngRm.append("공급가액 = 상품금액 + 케이지배송비");
					//중량변동 1.5
					}else {
						thngRm.append("공급가액 = 상품금액 + 중량변동금  + 케이지배송비");
					}
				//자차배송
				}else {
					//중량변동 0
					if(taxBillECVo.getWtChange() == 0) {
						thngRm.append("공급가액 = 상품금액");
					//중량변동 1.5
					}else {
						thngRm.append("공급가액 = 상품금액 + 중량변동금");
					}
				}
				
				// 24-09-30 변경사항 : 가단가 주문(05)일 경우, 가격변동금 항목을 추가
				if(StringUtils.equals(taxBillECVo.getSleMthdCode(), "05")) {
					thngRm.append(" + 가격변동금");
				}
			}
			else if(TaxBillCommConstant.JOB_SE_WT.equals(jobSe)) {
				//중량변동 0
				if(taxBillECVo.getWtChange() == 0) {
					thngRm.append("공급가액 = (중량차이 X 구매단가)");
				//중량변동 1.5
				}else {
					thngRm.append("공급가액 = (중량차이 X 구매단가) - 중량변동금");
				}
				
				// 24-09-30 변경사항 : 가단가 주문(05)일 경우, 가격변동금, 확정단가차이 항목을 추가
				if(StringUtils.equals(taxBillECVo.getSleMthdCode(), "05")) {
					thngRm.append(" - 가격변동금 - 확정단가차이");
				}
			}else if(TaxBillCommConstant.JOB_SE_CANCL.equals(jobSe)) thngRm.append("공급가액 = 최초공급가액 + 취소차액 + 취소물류비용 + 취소수수료");
			else if(TaxBillCommConstant.JOB_SE_RTNGUD.equals(jobSe)) thngRm.append("공급가액 = 환불금액 + 케이지배송비 + 반품물류비용 + 반품수수료");
			else if(TaxBillCommConstant.JOB_SE_EXCHNG.equals(jobSe)) thngRm.append("공급가액 = 중량차이 * 구매단가");
			else log.debug("TaxBillServiceImpl::selectRmInfoFunction jobSe is null");

			taxBillECVo.setRm(thngRm.toString());
			taxBillECVo.setThngRm(thngRm.toString());

		} catch (Exception e) {

			log.error("TaxBillServiceImpl::selectRmInfoFunction exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		}

		log.debug("TaxBillServiceImpl:selectRmInfoFunction (비고) End");
		return taxBillECVo;
	}//end selectRmInfoFunction()

	/**
	 *
	 * <pre>
	 * 코드 (기본 전용)
	 * </pre>
	 * @date 2021. 9. 1.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 1.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	TaxBillECVO taxBillECVo
	 * @return	TaxBillECVO
	 * @throws 	Exception
	 */
	public TaxBillECVO selectTaxBillCommCdInfo(TaxBillECVO taxBillECVo) throws Exception{
		log.debug("TaxBillServiceImpl:selectTaxBillCommCdInfo (코드) Start");

		try {

			String jobSe = taxBillECVo.getJobSe(); //업무 구분

			/**코드 셋팅*/
			taxBillECVo.setIsuMthdCode(TaxBillCommConstant.CD_01);					//발행 방식 코드			(01 정발행, 02 역발행)
			taxBillECVo.setPuchasSelngSeCode(TaxBillCommConstant.CD_01);			//매입 매출 구분 코드			(01 매출, 02 매입)
			taxBillECVo.setTaxBillSeCode(TaxBillCommConstant.CD_01);				//세금 계산서 구분 코드		(01 전자세금계산서, 02 종이세금계산서)
			taxBillECVo.setTaxtSeCode(TaxBillCommConstant.CD_01);					//과세 구분 코드			(01(과세), 02(비과세), 03(영세), 04(면세))
			taxBillECVo.setProcessSttusCode(TaxBillCommConstant.CD_01);				//처리 상태 코드			(01:신청,02:처리중,03:발행완료,04:발행실패,05:송신실패(재처리요청)) BTOB 업데이트 + 송신 시 01 : 신청값 셋팅
			taxBillECVo.setTaxBillKndCode(TaxBillCommConstant.CD_01);				//세금 계산서 종류 코드		((세금)계산서 종류(2자리) : 01(일반), 02(영세율), 03(위수탁), 04(수입), 05(영세율 위수탁), 06(수입납부유예))
			taxBillECVo.setRcptRqestSeCode(TaxBillCommConstant.CD_01);				//영수 청구 구분 코드			(01 : 영수, 02 : 청구)
			taxBillECVo.setSetleMthCode(TaxBillCommConstant.CD_10);					//결제 방법 코드			(10:현금, 20:수표, 30:어음, 40:외상(매출금/미수금))
			taxBillECVo.setSupledBsnmRegistNoSeCode(TaxBillCommConstant.CD_01);		//사업자 등록 번호 구분 코드 	(01 : 사업자등록번호, 02 : 주민등록번호, 03 : 외국인)

			//매출세금계산서
			if(TaxBillCommConstant.JOB_SE_ORDER.equals(jobSe)) {

				taxBillECVo.setTaxBillClCode(TaxBillCommConstant.CD_01);			//세금 계산서 분류 코드		((세금)계산서 분류(2자리) : 01(세금계산서), 02(수정세금계산서), 03(계산서), 04(수정계산서))
				taxBillECVo.setUpdtResnCode(null);									//수정 사유 코드			(01 : 기재사항의 착오·정정, 02: 공급가액 변동, 03: 환입, 04 : 계약의 해제, 05 : 내국신용장 사후 개설) (수정세금계산서,수정계산서)는 필수항목

			//수정세금계산서
			} else {

				taxBillECVo.setTaxBillClCode(TaxBillCommConstant.CD_02);			//세금 계산서 분류 코드		((세금)계산서 분류(2자리) : 01(세금계산서), 02(수정세금계산서), 03(계산서), 04(수정계산서))

				//수정 사유 코드 (01 : 기재사항의 착오·정정, 02: 공급가액 변동, 03: 환입, 04 : 계약의 해제, 05 : 내국신용장 사후 개설) (수정세금계산서,수정계산서)는 필수항목
				if(TaxBillCommConstant.JOB_SE_WT.equals(jobSe)) taxBillECVo.setUpdtResnCode(TaxBillCommConstant.CD_02);
				else if(TaxBillCommConstant.JOB_SE_CANCL.equals(jobSe)) taxBillECVo.setUpdtResnCode(TaxBillCommConstant.CD_04);
				else if(TaxBillCommConstant.JOB_SE_RTNGUD.equals(jobSe)) taxBillECVo.setUpdtResnCode(TaxBillCommConstant.CD_03);
				else if(TaxBillCommConstant.JOB_SE_EXCHNG.equals(jobSe)) taxBillECVo.setUpdtResnCode(TaxBillCommConstant.CD_03);

			}//end if()

			//전자 세금 계산서 종류 구분자 (세금 계산서 분류 코드+세금 계산서 종류 코드)
			String taxBillClCode			= taxBillECVo.getTaxBillClCode();		//세금계산서 분류 코드
			String taxBillKndCode			= taxBillECVo.getTaxBillKndCode();		//세금계산서 종류 코드
			String elctrnTaxBillKndSprtr 	= taxBillClCode.concat(taxBillKndCode);	//전자 세금 계산서 종류 구분자

			taxBillECVo.setElctrnTaxBillKndSprtr(elctrnTaxBillKndSprtr);

			//세금 계산서 발행 구분 코드
			if(TaxBillCommConstant.JOB_SE_ORDER.equals(taxBillECVo.getJobSe())) taxBillECVo.setTaxBillIsuSeCode(TaxBillCommConstant.CD_01);
			else if(TaxBillCommConstant.JOB_SE_WT.equals(taxBillECVo.getJobSe())) taxBillECVo.setTaxBillIsuSeCode(TaxBillCommConstant.CD_02);
			else if(TaxBillCommConstant.JOB_SE_CANCL.equals(taxBillECVo.getJobSe())) taxBillECVo.setTaxBillIsuSeCode(TaxBillCommConstant.CD_03);
			else if(TaxBillCommConstant.JOB_SE_EXCHNG.equals(taxBillECVo.getJobSe())) taxBillECVo.setTaxBillIsuSeCode(TaxBillCommConstant.CD_04);
			else if(TaxBillCommConstant.JOB_SE_RTNGUD.equals(taxBillECVo.getJobSe())) taxBillECVo.setTaxBillIsuSeCode(TaxBillCommConstant.CD_05);

		} catch (Exception e) {

			log.error("TaxBillServiceImpl::selectTaxBillCommCdInfo exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		}

		log.debug("TaxBillServiceImpl:selectTaxBillCommCdInfo (코드) End");
		return taxBillECVo;
	}//end selectTaxBillCommCdInfo()

	/**
	 *
	 * <pre>
	 * 채번 (기본 전용)
	 * </pre>
	 * @date 2021. 9. 1.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 1.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	TaxBillECVO taxBillECVo
	 * @return	TaxBillECVO
	 * @throws 	Exception
	 */
	public TaxBillECVO selectTaxBasNewNumber(TaxBillECVO taxBillECVo) throws Exception{
		log.debug("TaxBillServiceImpl:selectTaxBasNewNumber (채번) Start");

		try {

			/************************************
			 **** 주문, 인터페이스 세금계산서 기본 BAS****
			 ************************************/

			/**OR_TAX_BILL_BAS*/
			// 세금 계산서 신청 번호(PK) 채번
			String taxBillReqstDe 		= taxBillECVo.getTaxBillReqstDe();
			String taxBillReqstNo 		= taxBillReqstDe.concat("-") + assignService.selectAssignValue(
					TaxBillCommConstant.JOB_SE
					, TaxBillCommConstant.TAX_BILL_REQST_NO
					, taxBillReqstDe
					, TaxBillCommConstant.SYSTEM, 5);

			// 세금 계산서 신청 상세 순번(PK) 채번
			String taxBillReqstDetailSn = assignService.selectAssignValue(
					TaxBillCommConstant.JOB_SE
					, TaxBillCommConstant.TAX_BILL_REQST_DETAIL_SN
					, taxBillReqstDe
					, TaxBillCommConstant.SYSTEM, 4);

			/**IF_OR_TAX_BILL_BAS*/
			// 인터페이스 번호 채번
			String intrfcNo				= taxBillReqstDe + assignService.selectAssignValue(
					TaxBillCommConstant.JOB_SE
					, TaxBillCommConstant.INTRFC_NO
					, taxBillReqstDe
					, TaxBillCommConstant.SYSTEM, 6);

			// 인터페이스 순번 채번
			String intrfcSn				= assignService.selectAssignValue(
					TaxBillCommConstant.JOB_SE
					, TaxBillCommConstant.INTRFC_SN
					, taxBillReqstDe
					, TaxBillCommConstant.SYSTEM, 8);

			/**OR_TAX_BILL_BAS, IF_OR_TAX_BILL_BAS*/
			// 승인번호 채번
			String confmNoSeq 			= assignService.selectAssignValue(
					TaxBillCommConstant.JOB_SE
					, TaxBillCommConstant.CONFM_NO
					, taxBillReqstDe
					, TaxBillCommConstant.SYSTEM, 6);

			String confmNo				= taxBillReqstDe.concat(TaxBillCommConstant.NTS_REGIST_NO) + "ec".concat(confmNoSeq);

			taxBillECVo.setTaxBillReqstNo(taxBillReqstNo);					//세금 계산서 신청 번호		(OR)
			taxBillECVo.setTaxBillReqstDetailSn(taxBillReqstDetailSn);		//세금 계산서 신청 상세 순번	(OR)
			taxBillECVo.setIntrfcSn(intrfcSn);								//인터페이스 순번 채번		(IF)
			taxBillECVo.setIntrfcNo(intrfcNo);								//인터페이스 번호 채번		(IF)
			taxBillECVo.setConfmNo(confmNo);								//승인번호 채번				(OR, IF)

		} catch (Exception e) {

			log.error("TaxBillServiceImpl::selectTaxBasNewNumber exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		}

		log.debug("TaxBillServiceImpl:selectTaxBasNewNumber (채번) End");
		return taxBillECVo;
	}//end selectTaxBasNewNumber()

	/**
	 *
	 * <pre>
	 * 채번 (상세 전용)
	 * </pre>
	 * @date 2022. 1. 5.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 5.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	TaxBillECVO taxBillEcNewNumberVo
	 * @return	TaxBillECVO
	 * @throws 	Exception
	 */
	public TaxBillECVO selectTaxDtlNewNumber(TaxBillECVO taxBillEcNewNumberVo) throws Exception {
		log.debug("TaxBillServiceImpl:selectTaxDtlNewNumber (채번) Start");

		TaxBillECVO taxBillECVo = new TaxBillECVO();

		String taxBillReqstNo 		= taxBillEcNewNumberVo.getTaxBillReqstNo();			//세금 계산서 신청 번호
		String taxBillReqstDetailSn = taxBillEcNewNumberVo.getTaxBillReqstDetailSn();	//세금 계산서 신청 상세 순번
		String intrfcSn				= taxBillEcNewNumberVo.getIntrfcSn();				//인터페이스 순번
		String intrfcNo				= taxBillEcNewNumberVo.getIntrfcNo();				//인터페이스 번호

		try {

			/************************************
			 **** 주문, 인터페이스 세금계산서 상세 DTL****
			 ************************************/

			/**OR_TAX_BILL_DTL*/
			// 세금 계산서 상품 일련 번호(PK) 채번
			String taxBillGoodsSeqNo 	= assignService.selectAssignValue(
					TaxBillCommConstant.JOB_SE
					, TaxBillCommConstant.TAX_BILL_GOODS_SEQ_NO
					, taxBillReqstNo
					, TaxBillCommConstant.SYSTEM, 4);

			/**IF_OR_TAX_BILL_DTL*/
			// 인터페이스 상세 순번 채번
			String intrfcDetailSn		= assignService.selectAssignValue(
					TaxBillCommConstant.JOB_SE
					, TaxBillCommConstant.INTRFC_DETAIL_SN
					, intrfcNo
					, TaxBillCommConstant.SYSTEM, 8);

			//세금 계산서 물품 일련 번호
			String thngSeqNo 			= assignService.selectAssignValue(
					TaxBillCommConstant.JOB_SE
					, TaxBillCommConstant.THNG_SEQ_NO
					, intrfcNo
					, TaxBillCommConstant.SYSTEM, 4);

			taxBillECVo.setTaxBillReqstNo(taxBillReqstNo);					//세금 계산서 신청 번호		(OR)
			taxBillECVo.setTaxBillReqstDetailSn(taxBillReqstDetailSn);		//세금 계산서 신청 상세 순번	(OR)
			taxBillECVo.setTaxBillGoodsSeqNo(taxBillGoodsSeqNo);			//세금 계산서 상품 일련 번호	(OR) (param	: taxBillReqstNo)
			taxBillECVo.setIntrfcSn(intrfcSn);								//인터페이스 순번			(IF)
			taxBillECVo.setIntrfcDetailSn(intrfcDetailSn);					//인터페이스 상세 순번 채번		(IF) (param	: intrfcSn)
			taxBillECVo.setThngSeqNo(thngSeqNo);							//세금 계산서 물품 일련 번호	(IF) (param	: intrfcSn)

		} catch (Exception e) {

			log.error("TaxBillServiceImpl:selectTaxDtlNewNumber exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		}

		log.debug("TaxBillServiceImpl:selectTaxDtlNewNumber (채번) End");
		return taxBillECVo;
	}//end selectTaxDtlNewNumber();


	/**
	 *
	 * <pre>
	 * 세금계산서 업무, I/F 기본 데이터 적재 (기본)
	 * </pre>
	 * @date 2021. 9. 1.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 1.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	TaxBillECVO taxBillECVo
	 * @throws 	Exception
	 */
	public void saveOrTaxBillBas(TaxBillECVO taxBillECVo) throws Exception {
		log.debug("TaxBillServiceImpl:saveOrTaxBillBas (세금계산서 업무, I/F 기본 데이터 적재) Start");

		try {

			taxBillECVo.setFrstRegisterId(TaxBillCommConstant.TAX_BILL_IF);
			taxBillECVo.setLastChangerId(TaxBillCommConstant.TAX_BILL_IF);

			taxBillMapper.saveOrTaxBillBas(taxBillECVo);	//주문_세금계산서_기본 (OR_TAX_BILL_BAS)
			taxBillMapper.saveIfOrTaxBillBas(taxBillECVo);	//인터페이스_세금계산서_기본 (IF_OR_TAX_BILL_BAS)
			taxBillMapper.saveOrTaxBillBasHst(taxBillECVo);	//주문_세금계산서_기본 이력	(OR_TAX_BILL_BAS_HST)

		} catch (Exception e) {

			log.error("TaxBillServiceImpl::saveOrTaxBillBas exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		}

		log.debug("TaxBillServiceImpl:saveOrTaxBillBas (세금계산서 업무, I/F 기본 데이터 적재) End");
	}//end saveOrTaxBill()

	/**
	 *
	 * <pre>
	 * 세금계산서 업무, I/F 상세 데이터 적재 (상세)
	 * </pre>
	 * @date 2022. 1. 5.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 5.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	TaxBillECVO taxBillECVo
	 * @throws 	Exception
	 */
	public void saveOrTaxBillDtl(TaxBillECVO taxBillECVo) throws Exception {
		log.debug("TaxBillServiceImpl:saveOrTaxBillDtl (세금계산서 업무, I/F 상세 데이터 적재) Start");

		try {

			taxBillECVo.setFrstRegisterId(TaxBillCommConstant.TAX_BILL_IF);
			taxBillECVo.setLastChangerId(TaxBillCommConstant.TAX_BILL_IF);

			taxBillMapper.saveOrTaxBillDtl(taxBillECVo);	//주문_세금계산서_상세 (OR_TAX_BILL_DTL)
			taxBillMapper.saveIfOrTaxBillDtl(taxBillECVo);	//인터페이스_세금계산서_상세 (IF_OR_TAX_BILL_DTL)
			taxBillMapper.saveOrTaxBillDtlHst(taxBillECVo);	//주문_세금계산서_상세 이력	(OR_TAX_BILL_DTL_HST)

		} catch (Exception e) {

			log.error("TaxBillServiceImpl::saveOrTaxBillDtl exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		}

		log.debug("TaxBillServiceImpl:saveOrTaxBillDtl (세금계산서 업무, I/F 상세 데이터 적재) End");
	}//end saveOrTaxBill()

	public String setComma(String replaceNumber) throws Exception {

		if(StringUtils.isNotEmpty(replaceNumber)) {
			return replaceNumber = replaceNumber.replaceAll("\\B(?=(\\d{3})+(?!\\d))", ",");
		} else {
			return null;
		}

	}//end setComma()

	/**
	 * <pre>
	 * 처리내용: 세금 계산서 발행 가능 여부 조회
	 * </pre>
	 * @date 2022. 7. 20.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022.  7. 20.			srec0053			최초작성
	 * 2023. 11. 24.			srec0053			체크 로직 변경
	 * ------------------------------------------------
	 * @param requestVo
	 * @throws Exception
	 */
	private boolean isTaxbillIsuPossAt(TaxBillRequestVO requestVo) throws Exception {
		//업무 구분(jobSe)에 따른 세금 계산서 발행 구분 코드(taxBillIsuSeCode) 구하기
		TaxBillECVO taxBillECVO = new TaxBillECVO();
		taxBillECVO.setOrderNo(requestVo.getOrderNo());
		taxBillECVO.setCanclExchngRtngudNo(requestVo.getCanclExchngRtngudNo());
		taxBillECVO.setJobSe(requestVo.getJobSe());
		selectTaxBillCommCdInfo(taxBillECVO);

		//세금 계산서 발행 가능 여부 판단을 위한 데이터를 DB에서 조회
		Map<String, Object> result = taxBillMapper.selectTaxbillIsuPossAt(taxBillECVO);
		
		// 기존에 발행된 세금계산서가 있으면 발행 불가(false)
		if(result.get("taxBillReqstNo") != null) {	
			return false;
		} 
		// 해당 발행 요청 건이 수정세금계산서에 대한 발행 요청 건이고,
		// 판매 방식이 "평균가(04)" 이면서,
		// 상품 단가가 null (가단가 상태) 이거나, 확정 중량이 null (가중량 상태) 이면 발행 불가(false)
		else if( TaxBillCommConstant.JOB_SE_WT.equals(requestVo.getJobSe())
					&& (result.get("sleMthdCode") != null && StringUtils.equals(result.get("sleMthdCode").toString(), "04"))
					&& (result.get("goodsUntpc") == null || result.get("totDcsnWt") == null) ) {
			return false;
		} 
		// 위의 경우에 해당 안되면 발행 가능(true)
		else {
			return true;
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 세금 계산서 발행 프로그램 실행 파라미터 유효성 검사
	 * </pre>
	 * @date 2022. 7. 28.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 28.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param requestVo
	 * @throws Exception
	 */
	private void validateRequestParams(TaxBillRequestVO requestVo) throws Exception {
		String orderNo 				= requestVo.getOrderNo();
		String canclExchngRtngudNo 	= requestVo.getCanclExchngRtngudNo();
		String jobSe				= requestVo.getJobSe();
		String errorMessage			= null;
		log.debug("[ orderNo = " + orderNo + " ]");
		log.debug("[ canclExchngRtngudNo = " + canclExchngRtngudNo + " ]");
		log.debug("[ JobSe = " + jobSe + " ]");
		
		//세금계산서 발행 인터페이스 호출 시 적재 파라미터 (주문번호, 취소교환반품번호, 호출 업무단 명)
		if(TaxBillCommConstant.JOB_SE_ORDER.equals(jobSe) || TaxBillCommConstant.JOB_SE_WT.equals(jobSe)) {
			if(StringUtils.isEmpty(orderNo)) {
				errorMessage = "TaxBillServiceImpl:validateRequestParams 필수 값(주문 번호) 누락";
				throw new Exception(errorMessage);
			}				
		} else if(TaxBillCommConstant.JOB_SE_CANCL.equals(jobSe)
					|| TaxBillCommConstant.JOB_SE_EXCHNG.equals(jobSe)
					|| TaxBillCommConstant.JOB_SE_RTNGUD.equals(jobSe)) {
			if(StringUtils.isEmpty(canclExchngRtngudNo)) {
				errorMessage = "TaxBillServiceImpl:validateRequestParams 필수 값(클레임 번호) 누락";
				throw new Exception(errorMessage);
			}
		} else {
			errorMessage = "TaxBillServiceImpl:validateRequestParams 업무 구분 코드(jobSe) 식별 불가"; 
			throw new Exception(errorMessage);
		}//end if()
			
	} 
}//end class()
