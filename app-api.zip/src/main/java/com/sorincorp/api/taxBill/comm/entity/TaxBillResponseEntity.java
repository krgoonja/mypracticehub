package com.sorincorp.api.taxBill.comm.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaxBillResponseEntity {

	/** 결과 코드 */
	private String responseCode;
	
	/** 결과 메시지 */
	private String responseMessage;
	
}//end class()
