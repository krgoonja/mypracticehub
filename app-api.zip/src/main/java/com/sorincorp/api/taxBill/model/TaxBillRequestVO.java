package com.sorincorp.api.taxBill.model;

import lombok.Data;

/**
 * 
 * TaxBillRequestVO.java
 * 세금계산서 IF 호출 request VO
 * @version
 * @since 2021. 8. 27.
 * @author srec0054
 */
@Data
public class TaxBillRequestVO {

	/**주문 번호*/
	private String orderNo;
	
	/**취소 교환 반품 번호*/
	private String canclExchngRtngudNo;
	
	/**
	 * 업무 구분
	 * ORDER	: 주문
	 * WT		: 상차, 배송완료 (차이 중량 계산)
	 * CANCL	: 취소
	 * RTNGUD	: 반품
	 * EXCHNG 	: 교환
	 * */
	private String jobSe;
	
}//end class()
