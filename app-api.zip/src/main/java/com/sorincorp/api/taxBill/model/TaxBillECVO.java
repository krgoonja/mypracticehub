package com.sorincorp.api.taxBill.model;

import lombok.Data;

@Data
public class TaxBillECVO {

	/**
	 * 주문_세금계산서_기본 (OR_TAX_BILL_BAS)
	 * */
	
	/**세금 계산서 신청 번호(PK)*/
	private String taxBillReqstNo;
	
	/**세금 계산서 신청 상세 순번(PK)*/
	private String taxBillReqstDetailSn;
	
	/**주문 번호(PK)(FK)*/
	private String orderNo;
	
	/**취소 교환 반품 번호(PK)(FK)*/
	private String canclExchngRtngudNo;
	
	/**세금 계산서 신청 일자*/
	private String taxBillReqstDe;
	
	/**공급자 사업자 등록 번호*/
	private String suplerBsnmRegistNo;
	
	/**공급자 종 사업자 번호*/
	private String suplerSpcsBsnmNo;
	
	/**공급자 상호 명*/
	private String suplerMtltyNm;
	
	/**공급자 업태 명*/
	private String suplerBizcndNm;
	
	/**공급자 종목 명*/
	private String suplerItemNm;
	
	/**공급자 대표자 명*/
	private String suplerRprsntvNm;
	
	/**공급자 소재지 명*/
	private String suplerLocplcNm;
	
	/**공급자 사업자 주소*/
	private String suplerBsnmAdres;
	
	/**공급자 사업자 상세 주소*/
	private String suplerBsnmDetailAdres;
	
	/**공급자 사업자 도로명 주소*/
	private String suplerBsnmRnAdres;
	
	/**공급자 사업자 도로명 상세 주소*/
	private String suplerBsnmRnDetailAdres;
	
	/**공급자 담당자 부서 명*/
	private String suplerChargerDeptNm;
	
	/**공급자 담당자 명*/
	private String suplerChargerNm;
	
	/**공급자 담당자 이메일*/
	private String suplerChargerEmail;
	
	/**공급자 담당자 전화 번호*/
	private String suplerChargerTlphonNo;
	
	/**공급자 사업장 전화번호*/
	private String suplerBplcTelno;
	
	/**공급자 사업장 팩스번호*/
	private String suplerBplcFxnum;
	
	/**공급받는자 회원 번호*/
	private String supledMberNo;
	
	/**공급받는자 사업자 등록 번호*/
	private String supledBsnmRegistNo;
	
	/**공급받는자 종 사업자 번호*/
	private String supledSpcsBsnmNo;
	
	/**공급받는자 상호 명*/
	private String supledMtltyNm;
	
	/**공급받는자 대표자 명*/
	private String supledRprsntvNm;
	
	/**공급받는자 소재지 명*/
	private String supledLocplcNm;
	
	/**공급받는자 업태 명*/
	private String supledBizcndNm;
	
	/**공급받는자 종목 명*/
	private String supledItemNm;
	
	/**공급받는자 사업자 이메일*/
	private String supledBsnmEmail;
	
	/**공급받는자 사업자 우편 번호*/
	private String supledBsnmPostNo;
	
	/**공급받는자 사업자 주소*/
	private String supledBsnmAdres;
	
	/**공급받는자 사업자 상세 주소*/
	private String supledBsnmDetailAdres;
	
	/**공급받는자 사업자 도로명 주소*/
	private String supledBsnmRnAdres;
	
	/**공급받는자 사업자 도로명 상세 주소*/
	private String supledBsnmRnDetailAdres;
	
	/**공급받는자 사업자 전화 번호*/
	private String supledBsnmTlphonNo;
	
	/**공급받는자 사업자 휴대폰 번호*/
	private String supledBsnmMoblphonNo;
	
	/**공급받는자 담당자 부서 명*/
	private String supledChargerDeptNm;
	
	/**공급받는자 담당자 명*/
	private String supledChargerNm;
	
	/**공급받는자 담당자 전화 번호*/
	private String supledChargerTlphonNo;
	
	/**공급받는자 담당자 이메일*/
	private String supledChargerEmail;
	
	/**발행 방식 코드*/
	private String isuMthdCode;
	
	/**매입 매출 구분 코드*/
	private String puchasSelngSeCode;
	
	/**세금 계산서 구분 코드*/
	private String taxBillSeCode;
	
	/**과세 구분 코드*/
	private String taxtSeCode;
	
	/**처리 상태 코드*/
	private String processSttusCode;
	
	/**발행 일시*/
	private String isuDt;
	
	/**세금 계산서 분류 코드*/
	private String taxBillClCode;
	
	/**세금 계산서 종류 코드*/
	private String taxBillKndCode;
	
	/**비고*/
	private String rm;
	
	/**작성 일자*/
	private String writngDe;
	
	/**수정 사유 코드*/
	private String updtResnCode;
	
	/**영수 청구 구분 코드*/
	private String rcptRqestSeCode;
	
	/**총 금액(공급가액+세액)*/
	private String totAmount;
	
	/**총 공급 가액 합계*/
	private String totSuplyAmountSm;
	
	/**총 세액 합계*/
	private String totTaxamtSm;
	
	/**결제 방법 코드*/
	private String setleMthCode;
	
	/**결제 방법 별 금액*/
	private String setleMthAcctoAmount;
	
	/**승인 번호*/
	private String confmNo;
	
	/**당초 승인 번호*/
	private String bgnnConfmNo;
	
	/**원본 세금 계산서 신청 상세 순번*/
	private String orginlTaxBillReqstDetailSn;
	
	/**삭제 일시*/
	private String deleteDt;
	
	/**삭제 여부*/
	private String deleteAt;
	
	/**최초 등록자 아이디*/
	private String frstRegisterId;
	
	/**최초 등록 일시*/
	private java.sql.Timestamp frstRegistDt;
	
	/**최종 변경자 아이디*/
	private String lastChangerId;
	
	/**최종 변경 일시*/
	private java.sql.Timestamp lastChangeDt;
	

	/**
	 * 주문_세금계산서_상세 (OR_TAX_BILL_DTL)
	 * */
	
	/**세금 계산서 상품 일련 번호*/
	private String taxBillGoodsSeqNo;
	
	/**비고*/
	private String thngRm;
	
	/**물품 공급 가액*/
	private String thngSuplyAmount;
	
	/**물품 수량*/
	private String thngQy;
	
	/**물품 규격*/
	private String thngStndrd;
	
	/**물품 명*/
	private String thngNm;
	
	/**물품 공급 일자*/
	private String thngSuplyDe;
	
	/**물품 세액*/
	private String thngTaxamt;
	
	/**물품 단가*/
	private String thngUntpc;

	/**물품 판매가*/
	private String thngSlePc;
	
	/**
	 * 비고
	 * */
	
	/**(비고)총 실제 주문 중량*/
	private String rmTotRealOrderWt;
	
	/**(비고)총 확정 중량*/
	private String rmTotDcsnWt;
	
	/**(비고)상품 금액*/
	private String rmOrderPc;				
	
	/**(비고)물품 단가*/
	private String rmGoodsUntpc;			
	
	/**(비고)중량변동금*/
 	private String rmWtChangegld;			
 	
 	/**(비고)케이지배송비*/
	private String rmExpectDlvrf;			
	
	/**(비고)수정 상품 금액*/
	private String rmTotDcsnOrderPc;		
	
	/**(비고)공급가액 - 차액*/
	private String rmExcclcSplpc;			
	
	/**판매 단위 코드*/
	private String rmSleUnitCode;
	
	/**
	 * 인터페이스_세금계산서_기본 (IF_OR_TAX_BILL_BAS)
	 */
	
	/**시스템 구분*/
	private String sysSe;
	
	/**인터페이스 순번*/
	private String intrfcSn;
	
	/**인터페이스 번호*/
	private String intrfcNo;
	
	/**서비스 사업자 관리번호*/
	private String svcBsnm;
	
	/**전자 세금 계산서 발급일시*/
	private String elctrnTaxBillIssuDt;
	
	/**사업자 관리 번호*/
	private String bsnmManageNo;
	
	/**전자 서명*/
	private String elctrnSign;
	
	/**세금 계산서 승인 번호*/
	private String taxBillConfmNo;
	
	/**전자 세금 계산서 종류 구분자*/
	private String elctrnTaxBillKndSprtr;
	
	/**전자 세금 계산서 작성 일자*/
	private String elctrnTaxBillWritngDe;
	
	/**전자 세금 계산서 수정 사유 코드*/
	private String elctrnTaxBillUpdtResnCode;
	
	/**세금 계산서 영수 청구 구분 코드*/
	private String taxBillRcptRqestSeCode;
	
	/**당초 전자 세금 계산서 승인 번호*/
	private String bgnnElctrnTaxBillConfmNo;
	
	/**수입 신고서 번호*/
	private String importDclrtNo;
	
	/**일괄 발급 수입 건수*/
	private String bndeIssuImportCo;
	
	/**일괄 발급 시작 일자*/
	private String bndeIssuBeginDe;
	
	/**일괄 발급 종료 일자*/
	private String bndeIssuEndDe;
	
	/**공급자 업태*/
	private String suplerBizcnd;
	
	/**공급자 명*/
	private String suplerNm;
	
	/**공급자 업종*/
	private String suplerInduty;
	
	/**공급자 종 사업장 번호*/
	private String suplerSpcsBplcNo;
	
	/**공급자 담당 부서*/
	private String suplerChrgDept;
	
	/**공급자 주소*/
	private String suplerAdres;
	
	/**공급받는자 업태*/
	private String supledBizcnd;
	
	/**공급받는자 명*/
	private String supledNm;
	
	/**공급받는자 업종*/
	private String supledInduty;
	
	/**공급받는자 종 사업장 번호*/
	private String supledSpcsBplcNo;
	
	/**공급받는자 사업자 등록 번호 구분 코드*/
	private String supledBsnmRegistNoSeCode;
	
	/**공급받는자 담당 부서*/
	private String supledChrgDept;
	
	/**공급받는자 주소*/
	private String supledAdres;
	
	/**공급받는자_사업장_전화번호*/
	private String supledBplcTelno;
	
	/**수탁 사업자 등록 번호*/
	private String trustBsnmRegistNo;
	
	/**수탁 사업자 업태*/
	private String trustBsnmBizcnd;
	
	/**수탁 사업자 사업체 명*/
	private String trustBsnmBsnesNm;
	
	/**수탁 사업자 업종*/
	private String trustBsnmInduty;
	
	/**수탁 사업자 종 사업장 번호*/
	private String trustBsnmSpcsBplcNo;
	
	/**수탁 사업자 대표자 명*/
	private String trustBsnmRprsntvNm;
	
	/**수탁 사업자 담당 부서*/
	private String trustBsnmChrgDept;
	
	/**수탁 사업자 담당자 명*/
	private String trustBsnmChargerNm;
	
	/**수탁 사업자 담당자 전화 번호*/
	private String trustBsnmChargerTlphonNo;
	
	/**수탁 사업자 담당자 이메일*/
	private String trustBsnmChargerEmail;
	
	/**수탁 사업자 주소*/
	private String trustBsnmAdres;
	
	/**총액*/
	private String totamt;
	
	/**문서 상태 코드*/
	private String docSttusCode;
	
	/**수신 메시지 코드*/
	private String recptnMssageCode;
	
	/**수신 결과 코드*/
	private String recptnResultCode;
	
	/**처리 상세 설명*/
	private String processDetailDc;
	
	/**
	 * 인터페이스_세금계산서_상세 (IF_OR_TAX_BILL_DTL)	
	 */
	
	/**인터페이스 상세 순번*/
	private String intrfcDetailSn;
	
	/**물품 일련 번호*/
	private String thngSeqNo;
	
	/**
	 * 기타
	 * */
	
	/**
	 * 업무 구분
	 * ORDER	: 주문
	 * CANCL	: 취소
	 * RTNGUD	: 반품
	 * EXCHNG 	: 교환
	 * */
	private String jobSe;
	
	/**
	 * 세금 계산서 발행 구분 코드
	 */
	private String taxBillIsuSeCode;
	
	/**배송 수단 코드*/
	private String dlvyMnCode;
	
	/**
	 * 판매 방식 코드
	 */
	private String sleMthdCode;
	/**
	 * 중량 변동
	 */
	private int wtChange;
	/**
	 * 단가 확정 일자
	 */
	private String untpcDcsnDe;
	/**
	 * 평균가 세금계산서 발행 시점 코드
	 */
	private String avrgpcTaxBillIsuPnttmCode;
	/**
	 * 주문세금계산서 신청 일자
	 */
	private String orderTaxBillReqstDe;
}//end class()
