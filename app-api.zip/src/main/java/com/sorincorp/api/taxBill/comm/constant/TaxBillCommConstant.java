package com.sorincorp.api.taxBill.comm.constant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TaxBillCommConstant {
	
	private TaxBillCommConstant() {
		log.debug(TaxBillCommConstant.class.getSimpleName());
	}
	
	/**RESULT*/
	public static final String SUCCESS_RESULT_CODE	= "200";
	public static final String ERROR_RESULT_CODE 	= "500";
	
	public static final String SUCCESS_RESULT_MSG 	= "Success";
	public static final String SKIP_RESULT_MSG 		= "Skip";
	public static final String ERROR_RESULT_MSG 	= "Error";
	
	/**세금계산서 발행 업무 구분*/
	public static final String JOB_SE_ORDER			= "ORDER";	//주문 (매출)
	public static final String JOB_SE_WT			= "WT";		//중량 (수정)
	public static final String JOB_SE_CANCL			= "CANCL";	//취소
	public static final String JOB_SE_RTNGUD		= "RTNGUD";	//반품
	public static final String JOB_SE_EXCHNG		= "EXCHNG";	//교환
	
	/**인터페이스 ID*/
	public static final String TAX_BILL_IF 			= "SOREC-IF-115";	//세금계산서 발행요청 btobi 송신
	
	/**세금계산서 코드 항목*/
	public static final String CD_01 = "01";
	public static final String CD_02 = "02";
	public static final String CD_03 = "03";
	public static final String CD_04 = "04";
	public static final String CD_05 = "05";
	public static final String CD_06 = "06";
	public static final String CD_10 = "10";
	public static final String CD_20 = "20";
	public static final String CD_30 = "30";
	public static final String CD_40 = "40";
	
	/**채번*/
	public static final String JOB_SE 					= "OR";
	public static final String TAX_BILL_REQST_NO		= "TAX_BILL_REQST_NO";			//세금 계산서 신청 번호
	public static final String TAX_BILL_REQST_DETAIL_SN = "TAX_BILL_REQST_DETAIL_SN";	//세금 계산서 신청 상세 순번
	public static final String TAX_BILL_GOODS_SEQ_NO	= "TAX_BILL_GOODS_SEQ_NO";		//세금 계산서 상품 일련 번호
	public static final String INTRFC_SN				= "INTRFC_SN";					//인터페이스 순번
	public static final String INTRFC_DETAIL_SN			= "INTRFC_DETAIL_SN";			//인터페이스 상세 순번
	public static final String INTRFC_NO				= "INTRFC_NO";					//인터페이스 번호
	public static final String THNG_SEQ_NO				= "THNG_SEQ_NO";				//세금 계산서 물품 일련 번호
	
	
	public static final String CONFM_NO					= "CONFM_NO";					//승인번호
	public static final String NTS_REGIST_NO 			= "42000257";					//국세청 등록번호
	
	public static final String SYSTEM 					= "SYSTEM";						//등록자
	
	/**시스템 구분*/
	public static final String SECS						= "01";							//EC
}//end class()
