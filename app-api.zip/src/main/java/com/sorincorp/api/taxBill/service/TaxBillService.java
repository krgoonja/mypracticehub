package com.sorincorp.api.taxBill.service;

import com.sorincorp.api.taxBill.model.TaxBillRequestVO;

public interface TaxBillService {

	String taxBillIsu(TaxBillRequestVO requestVo) throws Exception;
	
}//end interface
