package com.sorincorp.api.queue.azure.servicebus.listener;

import javax.jms.ConnectionFactory;
//import javax.jms.Session;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;

/**
 * AzureServiceBusQueueListenerConfig.java
 * Azure Service Bus Queue JMS 리스너 설정
 * 
 * @version
 * @since 2023. 4. 24.
 * @author srec0049
 */
@Configuration
@EnableJms
public class AzureServiceBusQueueListenerConfig {
	
	/**
	 * <pre>
	 * 처리내용: JMS 리스너 컨테이너 설정 재정의
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param configurer
	 * @param connectionFactory
	 * @return
	 */
	@Bean
	@ConditionalOnMissingBean
	public JmsListenerContainerFactory<?> jmsListenerContainerFactory(DefaultJmsListenerContainerFactoryConfigurer configurer, ConnectionFactory connectionFactory) {
		DefaultJmsListenerContainerFactory jmsListenerContainerFactory = new DefaultJmsListenerContainerFactory();
		configurer.configure(jmsListenerContainerFactory, connectionFactory);
		jmsListenerContainerFactory.setPubSubDomain(Boolean.FALSE);
		jmsListenerContainerFactory.setSessionTransacted(false);
//		jmsListenerContainerFactory.setSessionAcknowledgeMode(Session.CLIENT_ACKNOWLEDGE);
		
		return jmsListenerContainerFactory;
	}
}
