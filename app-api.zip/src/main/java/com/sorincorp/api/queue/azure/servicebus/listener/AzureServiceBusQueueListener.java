package com.sorincorp.api.queue.azure.servicebus.listener;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import com.sorincorp.api.or.mapper.LimitGroupMapper;
import com.sorincorp.api.or.service.LimitGroupService;
import com.sorincorp.comm.order.model.CommLimitOrderQueueMsgVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderQueueMsgVO;

import lombok.extern.slf4j.Slf4j;

/**
 * AzureServiceBusQueueListener.java
 * Azure Service Bus Queue Listener
 * 
 * @version
 * @since 2023. 4. 12.
 * @author srec0049
 */
@Component
@Slf4j
public class AzureServiceBusQueueListener {
	
	/**
	 * 지정가 그룹 Service
	 */
	@Autowired
	LimitGroupService limitOrderService;
	
	/**
	 * 지정가 그룹 Mapper
	 */
	@Autowired
	LimitGroupMapper limitOrderMapper;
	
	
	/**
	 * <pre>
	 * 처리내용: 지정가 체결 Queue 메시지 받기 위한 리스너
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param commLimitOrderQueueMsgVO
	 * @param headers
	 * @param message
	 * @param session
	 * @throws JMSException
	 */
	@JmsListener(destination = "${spring.jms.servicebus.destination.limitOrder}", containerFactory = "jmsListenerContainerFactory")
	public void limitJmsListener(@Payload CommLimitOrderQueueMsgVO commLimitOrderQueueMsgVO, @Headers MessageHeaders headers, Message message, Session session) {
		log.info("[limitJmsListener] >> received : " + String.valueOf(commLimitOrderQueueMsgVO));
		log.info("[limitJmsListener] >> headers : " + headers);
		log.info("[limitJmsListener] >> message : " + message);
		log.info("[limitJmsListener] >> session : " + session);
		
		// 지정가 그룹 처리
		limitOrderService.procLimitGroup(commLimitOrderQueueMsgVO, message);
    }
	
	/**
	 * <pre>
	 * 처리내용: 잠정 지정가 체결 Queue 메시지 받기 위한 리스너
	 * </pre>
	 * @date 2024. 8. 27.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 8. 27.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commLimitOrderQueueMsgVO
	 * @param headers
	 * @param message
	 * @param session
	 */
	@JmsListener(destination = "${spring.jms.servicebus.destination.prvsnlLimitOrder}", containerFactory = "jmsListenerContainerFactory")
	public void prvsnlLimitJmsListener(@Payload CommPrvsnlLimitOrderQueueMsgVO commPrvsnlLimitOrderQueueMsgVO, @Headers MessageHeaders headers, Message message, Session session) {
		log.info("[prvsnlLimitJmsListener] >> received : " + String.valueOf(commPrvsnlLimitOrderQueueMsgVO));
		log.info("[prvsnlLimitJmsListener] >> headers : " + headers);
		log.info("[prvsnlLimitJmsListener] >> message : " + message);
		log.info("[prvsnlLimitJmsListener] >> session : " + session);

		// 가단가 지정가 그룹 처리
		limitOrderService.procPrvsnlLimitGroup(commPrvsnlLimitOrderQueueMsgVO, message);
    }

}
