package com.sorincorp.api.mb.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import com.sorincorp.api.mb.comm.constant.MbCommConstant;
import com.sorincorp.api.mb.model.EntrpsMberInfoVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;
import com.sorincorp.comm.btb.model.BtoBReqEntity;
import com.sorincorp.comm.btb.model.BtoBResEntity;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EntrpsMberInfoServiceImpl implements EntrpsMberInfoService {

	@Autowired
	private HttpClientHelper httpClientHelper;


	/**
	 * <pre>
	 * 처리내용: TR 기회원인지 확인
	 * 회원일 경우 => ERP 업체 코드, T코드 수신
	 * 아닐 경우 => 일반 회원 가입
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsMberInfoVO
	 * @param request
	 * @param response
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@Override
	public BtoBResEntity selectTrdEtnrpsMberInfo(EntrpsMberInfoVO entrpsMberInfoVO) throws Exception {
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog("STS_IF_002", entrpsMberInfoVO);
		// 정회원 관련 정보를 select해서 보내!
		BtoBReqEntity entrpsMberEntity = new BtoBReqEntity();
		BtoBResEntity resEntity = new BtoBResEntity();

		/* 인터페이스 ID Setting */
		entrpsMberEntity.setInterfaceId("STS_IF_002");

		try {
			/* request Setting */
			Map<String, Object> entrpsMberReqMap = new HashMap<String, Object>();
			entrpsMberReqMap.put("AccountNo", entrpsMberInfoVO.getBsnmRegistNo());
			entrpsMberEntity.setRequest(entrpsMberReqMap);

			/* 호출 */
			resEntity = httpClientHelper.callApi(entrpsMberEntity);
			//log.debug("resEntity :: " + resEntity);

			// BtoBConstants꺼 써야되나?
			btbLogVo.setIntrfcRspnsCode(MbCommConstant.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(MbCommConstant.SUCCESS_RESULT_MSG);
		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(MbCommConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			throw new Exception(e.getMessage());
		} finally {
			/** 통합 로그 UPDATE **/
			httpClientHelper.updateBtbLog(btbLogVo);
		}
		return resEntity;
	}
	/**
	 * <pre>
	 * 처리내용: EC 회원 가입 승인 처리 => TR에 회원 정보 송신 후 ERP 업체 코드, TCODE 수신
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param approvalReqMbCorpMgrVOMap
	 * @param request
	 * @param response
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@Override
	public BtoBResEntity insertApprovalMberInfo(MultiValueMap<String, String> approvalReqMbCorpMgrVOMap) throws Exception {
		/** 통합 로그 INSERT **/
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog("SOREC-IF-002", approvalReqMbCorpMgrVOMap);

		// RequestEntity
		BtoBReqEntity entrpsMberEntity = new BtoBReqEntity();

		/* 인터페이스 ID Setting */
		entrpsMberEntity.setInterfaceId("SOREC-IF-002");

		BtoBResEntity resEntity = new BtoBResEntity();

//		if (!StringUtils.equals(resEntity.getResultcode(), BtoBConstants.BTOB_CNI_SUCCESS_CODE)) {
//			/* 에러 발생 */
//		}

		try {
			Map<String,String> map = approvalReqMbCorpMgrVOMap.toSingleValueMap();
			entrpsMberEntity.setRequest(map);
			/* 호출 */
			resEntity = httpClientHelper.callApi(entrpsMberEntity);
			//log.debug("resEntity :: " + resEntity);
			// BtoBConstants꺼 써야되나?
			btbLogVo.setIntrfcRspnsCode(MbCommConstant.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(MbCommConstant.SUCCESS_RESULT_MSG);

		} catch (Exception e) {
			btbLogVo.setIntrfcRspnsCode(MbCommConstant.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			throw new Exception(e.getMessage());

		}finally {
			/** 통합 로그 UPDATE **/
			httpClientHelper.updateBtbLog(btbLogVo);
		}
		return resEntity;
	}

}
