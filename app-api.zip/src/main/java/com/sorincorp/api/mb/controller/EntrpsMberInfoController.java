package com.sorincorp.api.mb.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.mb.model.EntrpsMberInfoVO;
import com.sorincorp.api.mb.service.EntrpsMberInfoService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBResEntity;
import com.sorincorp.comm.validation.CustomValidator;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/sts")
@Api(value = "정회원 정보 송신")
@ComponentScan("com.sorincorp.comm.*")
//@CrossOrigin("*")
public class EntrpsMberInfoController {

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private EntrpsMberInfoService entrpsMberInfoService;

	@Autowired
	private CustomValidator customValidator;

	/**
	 * <pre>
	 * 처리내용: TR 기회원인지 확인
	 * 회원일 경우 => ERP 업체 코드, T코드 수신
	 * 아닐 경우 => 일반 회원 가입
	 * </pre>
	 * @date 2021. 8. 17.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 17.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsMberInfoVO
	 * @param request
	 * @param response
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/trd_entrps_mber_info")
	@ApiOperation(value = "회원 정보 수신", notes = "트레이딩 기회원 정보 수신")
	public ResponseEntity<?> selectTrdEtnrpsMberInfo(
			@ApiParam(value = "회원정보수신 VO", required = true) EntrpsMberInfoVO entrpsMberInfoVO,
			HttpServletRequest request, HttpServletResponse response, BindingResult bindingResult) throws Exception {

		String bsnmRegistNo = request.getParameter("bsnmRegistNo");
		String callback = request.getParameter("callback");

		entrpsMberInfoVO.setBsnmRegistNo(bsnmRegistNo);

		customValidator.validate(entrpsMberInfoVO, bindingResult);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		BtoBResEntity btbResEntity = entrpsMberInfoService.selectTrdEtnrpsMberInfo(entrpsMberInfoVO);
		log.debug("btbResEntity :: "+ btbResEntity);

		LinkedHashMap<?, ?> map = (LinkedHashMap<?, ?>) btbResEntity.getResponse();
		String respCode = (String) map.get("respCode");
		String respMssg = (String) map.get("respMssg");
		String tcode = (String) map.get("Tcode");

		JSONObject obj = new JSONObject();
		obj.put("respCode", respCode);
		obj.put("respMssg", respMssg);
		obj.put("tcode", tcode);


		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.set("Content-Type", "application/javascript; charset=UTF-8");
		ResponseEntity<?> result = new ResponseEntity<>(callback + "(" + obj.toString() + ")", responseHeaders,
				HttpStatus.OK);
		return result;
	}

	@PostMapping("/approval_entrps_mber_info")
	@ApiOperation(value = "회원 정보 수신", notes = "트레이딩 기회원 정보 수신")
	public ResponseEntity<?> insertApprovalMberInfo(
			@ApiParam(value = "회원정보수신 VO", required = true) @RequestBody LinkedMultiValueMap<String, String> parameters,
			BindingResult bindingResult) throws Exception {

		BtoBResEntity trdResult = entrpsMberInfoService.insertApprovalMberInfo(parameters);
		Map<String, Object> resData = (Map<String, Object>) trdResult.getResponse();

		 //customValidator.validate(entrpsMberInfoVO, bindingResult);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		ResponseEntity<?> result = new ResponseEntity<>(resData, HttpStatus.OK);
		return result;
	}

}