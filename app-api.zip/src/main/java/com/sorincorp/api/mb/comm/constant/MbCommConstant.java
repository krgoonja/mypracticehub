package com.sorincorp.api.mb.comm.constant;

public final class MbCommConstant {

	public static final String SUCCESS_RESULT_CODE = "200";

	public static final String ERROR_RESULT_CODE = "500";

	public static final String SUCCESS_RESULT_MSG = "Success";

	public static final String ERROR_RESULT_MSG = "Error";

}
