/**
 *
 */
package com.sorincorp.api.mb.mapper;

import com.sorincorp.api.mb.model.EntrpsMberInfoVO;

/**
 * EntrpsMberInfoMapper.java
 * @version
 * @since 2021. 7. 30.
 * @author srec0009
 */
public interface EntrpsMberInfoMapper {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 30.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 30.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	// 추후 개발 예정
	//EntrpsMberInfoVO selectEtnrpsMberInfo(String entrpsNo);

}
