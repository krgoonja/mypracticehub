/**
 *
 */
package com.sorincorp.api.mb.model;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;


@ApiModel("정회원 정보 송신 VO")
@Data
@EqualsAndHashCode(callSuper = false)
public class EntrpsMberInfoVO implements Serializable {
	/**
	 * serialVersion UID
	 */
	private static final long serialVersionUID = 1L;

	/****** JAVA VO CREATE : MB_ENTRPS_INFO_BAS(회원_업체 정보 기본) ******/
	/**
	 * vo 리스트
	 */
	////////////////////[[ 업체 기본 정보 ]]///////////////////
	/**
	 * 업체 번호
	 */
	private String entrpsNo;
    /**
     * ERP 업체 코드
     */
    private String erpEntrpsCode;
	/**
	 * T코드
	 */
	private String TCode;
	/**
	 * 업체명 한글
	 */
	private String entrpsnmKorean;
	/**
	 * 업체명 영문
	 */
	private String entrpsnmEng;
	/**
	 * 대표자 명
	 */
	private String rprsntvNm;
	/**
	 * 사업자 등록 번호
	 */
	private String bsnmRegistNo;
	/**
	 * 법인 등록 번호
	 */
	private String cprRegistNo;
	/**
	 * 기업 업태 코드
	 */
	private String entrprsBizcndCode;
	/**
	 * 기업 종목 코드
	 */
	private String entrprsItemCode;
	/**
	 * 사업자 유형 코드
	 */
	private String bsnmTyCode;
	/**
	 * 회사 전화 번호
	 */
	private String cmpnyTlphonNo;
	/**
	 * 회사 팩스 번호
	 */
	private String cmpnyFaxNo;
	/**
     * 우편 번호 !!!!!!!!!!!!!!!!!!
     */
    private String postNo;
    /**
     * 주소
     */
    private String adres;
    /**
     * 상세 주소
     */
    private String detailAdres;
    /**
     * 도로명 주소
     */
    private String rnAdres;
    /**
     * 도로명 상세주소
     */
    private String rnDetailAdres;
	/**
	 * 환불 계좌 번호
	 */
	private String refndAcnutNo;
	/**
	 * 이월렛 계좌 번호
	 */
	private String ewalletAcnutNo;
	/**
	 * 환불 계좌명
	 */
	private String refndAcnutNm;
	/**
	 * 환불 계좌 상태 코드
	 */
	private String refndAcnutSttusCode;
	/**
	 * 환불 계좌 상태 설명
	 */
	private String refndAcnutSttusDc;
	/**
	 * 환불 계좌 정합성 여부
	 */
	private String refndAcnutCnfrmtyAt;
	/**
	 * 환불 계좌 정합성 일시 !!!!!!!!!!
	 */
	private String refndAcnutCnfrmtyDt;
	/**
	 * 고객 등록 주체 코드
	 */
	private String cstmrRegistMbyCode;
	/**
	 * 업체 등급 번호
	 */
	private String entrpsGradNo;
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	/**
	 * 담당자 아이디
	 */
	private String chargerId;
	/**
	 * 비밀번호
	 */
	private String secretNo;
	/**
	 * 담당자 이름
	 */
	private String chargerNm;
	/**
	 * 휴대폰 번호
	 */
	private String moblphonNo;
	/**
	 * 문자 수신 여부
	 */
	private String chrctrRecptnAt;
	/**
	 * 이메일 수신 여부
	 */
	private String emailRecptnAt;
    ///////////////////[[ 배송지 정보 ]]////////////////
	/**
	 * 배송지 명
	 */
	private String dlvrgNm;
    /**
     * 배송지 구분
     */
    private String dlvrSe;
    /**
     * [배송지]우편 번호
     */
    private String dlvrgPostNo;
    /**
     * [배송지]주소
     */
    private String dlvrgAddr1;
    /**
     * [배송지]주소2
     */
    private String dlvrgAddr2;
    /**
     * 배송지 담당자
     */
    private String dlvrgCharger;
    /**
     * 승인자 명
     */
    private String confmerNm;
    /**
     * 승인 상태 코드
     */
    private String confmProcessSe;
    /**
     * 요청 사유
     */
    private String requstResn;
    /**
     * 승인 사유
     */
    private String confmResn;

	/**
	 * 인터페이스 번호
	 */
	private int intrfcNo;
    /**
	 * 인터페이스 구분(I/U/D)
	 */
	//@NotEmpty(message="{brandInfoDtlVO.intrfcSe.isEmpty}")
	@ApiModelProperty(value = "인터페이스 구분", example = "I")
	private String intrfcSe;
	/**
	 * 인터페이스 ID
	 */
	private String intrfcId;

	private String SrCustCd;
	private String respMssg;
	private String respCode;
	private String Tcode;

	private String mberConfmSttusCode;


}
