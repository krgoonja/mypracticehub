package com.sorincorp.api.mb.service;

import java.util.Map;

import org.springframework.util.MultiValueMap;

import com.sorincorp.api.mb.model.EntrpsMberInfoVO;
import com.sorincorp.comm.btb.model.BtoBResEntity;

public interface EntrpsMberInfoService {
/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 30.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 30.			srec0009			최초작성
	 * ------------------------------------------------
	 */
	// 추후 개발 예정
	//BtoBResEntity selectEtnrpsMberInfo(EntrpsMberInfoVO reqEntity) throws Exception;
	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * @date 2021. 7. 30.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 30.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 * @throws Exception
	 */
	BtoBResEntity selectTrdEtnrpsMberInfo(EntrpsMberInfoVO entrpsMberInfoVO) throws Exception;
	/**
	 * <pre>
	 * 처리내용: EC에서 회원가입 승인된 회원 정보를 트레이딩에 송신.
	 *         트레이딩에서 ERP코드와 TCODE 수신
	 * @date 2021. 8. 13.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 30.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 * @throws Exception
	 */
	BtoBResEntity insertApprovalMberInfo(MultiValueMap<String, String> parameters) throws Exception;
	}
