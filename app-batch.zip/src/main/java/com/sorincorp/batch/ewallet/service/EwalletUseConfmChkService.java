/**
 *
 */
package com.sorincorp.batch.ewallet.service;

/**
 * EwalletUseConfmChkService.java
 * @version
 * @since 2021. 11. 19.
 * @author srec0009
 */
public interface EwalletUseConfmChkService {


	public void ewalletUseConfmCheck() throws Exception;
}
