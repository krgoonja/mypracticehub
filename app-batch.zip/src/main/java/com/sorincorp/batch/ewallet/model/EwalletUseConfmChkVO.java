package com.sorincorp.batch.ewallet.model;

import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EwalletUseConfmChkVO {

	/** 업체번호 **/
	@NotEmpty(message = "업체 번호 미존재")
	private String entrpsNo;

	/** Ewallet 가상 계좌 번호 **/
	private String ewalletAcnutNo;

	/** 거래 일자 **/
	private String delngDe;

	/** 거래 일련 번호 **/
	private String delngSeqNo;

	/** 거래 금액 ( 잔액 ) **/
	private String delngAmount;

	/** 배치 대상인지 구분 **/
	private String stts;

	/** 호나불 계좌 정합성 여부**/
	private String refndAcnutRgrsynthAt;

	/** 환불 계좌 상태 코드**/
	private String refndAcnutSttusCode;

	public EwalletUseConfmChkVO(String entrpsNo) {
		this.entrpsNo = entrpsNo;
	}

}
