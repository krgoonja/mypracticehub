/**
 *
 */
package com.sorincorp.batch.ewallet.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.ewallet.mapper.EwalletUseConfmChkMapper;
import com.sorincorp.batch.ewallet.model.EwalletUseConfmChkVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;

import lombok.extern.slf4j.Slf4j;

/**
 * EwalletUseConfmChkServiceImpl.java
 * @version
 * @since 2021. 11. 19.
 * @author srec0009
 */
@Slf4j
@Service
public class EwalletUseConfmChkServiceImpl implements EwalletUseConfmChkService {

	@Autowired
	private EwalletUseConfmChkMapper ewalletUseConfmChkMapper;

	@Autowired
	private HttpClientHelper httpClientHelper;

	/** 이월렛 잔고 확인 url **/
	@Value("${order.api.ewallet.money.url}")
	private String ewalletMoneyUrl;

	@Override
	public void ewalletUseConfmCheck() throws Exception {

		List<EwalletUseConfmChkVO> entrpsNoList = ewalletUseConfmChkMapper.selectRequstUser();

		for(int i = 0; i < entrpsNoList.size(); i++) {
			if("NONE".equals(entrpsNoList.get(i).getStts())) {
				log.debug("=================================================");
				log.debug("      >> 이월렛 계좌 사용등록 승인 통보 배치 대상 업체 없음");
				log.debug("=================================================");
			}else {
				log.debug("STTS ===============> " + entrpsNoList.get(i).getStts());
				Map<String, Object> returnMap = httpClientHelper.postCallApi(ewalletMoneyUrl, entrpsNoList.get(i));
				//딜레이 10초
				Thread.sleep(10000);
				log.debug(returnMap.toString());
				String resultCode = returnMap.get("resultCode").toString();
				String resultMsg = returnMap.get("resultMsg").toString();
				log.debug("=================================================");
				log.debug("        resultCode :: " + resultCode);
				log.debug("        resultMsg  :: " + resultMsg);
				log.debug("=================================================");

				if("200".equals(resultCode)) {
					log.debug("=================================================");
					log.debug("      >> 이월렛 계좌 사용등록 승인");
					log.debug("=================================================");
					entrpsNoList.get(i).setRefndAcnutRgrsynthAt("Y");
					entrpsNoList.get(i).setRefndAcnutSttusCode("05");
					ewalletUseConfmChkMapper.updateUseConfmSttus(entrpsNoList.get(i));
					ewalletUseConfmChkMapper.insertMbEntrpsInfoBasHst(entrpsNoList.get(i));
				}else {
					log.debug("=================================================");
					log.debug("      >> 이월렛 계좌 최종 사용 승인 대기 (7350 대기 상태)");
					log.debug("대상 업체 번호:: ", entrpsNoList.get(i).getEntrpsNo());
					log.debug("=================================================");
					//entrpsNoList.get(i).setRefndAcnutRgrsynthAt("N");
					// entrpsNoList.get(i).setRefndAcnutSttusCode("06");
					//ewalletUseConfmChkMapper.updateUseConfmSttus(entrpsNoList.get(i));
					//ewalletUseConfmChkMapper.insertMbEntrpsInfoBasHst(entrpsNoList.get(i));
				}
			}
		}
	}



}
