/**
 *
 */
package com.sorincorp.batch.ewallet.mapper;

import java.util.List;

import com.sorincorp.batch.ewallet.model.EwalletUseConfmChkVO;

/**
 * EwalletUserConfmChkMapper.java
 * @version
 * @since 2021. 11. 19.
 * @author srec0009
 */
public interface EwalletUseConfmChkMapper {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 19.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 19.			srec0009			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<EwalletUseConfmChkVO> selectRequstUser();

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 19.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 19.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param ewalletUseConfmChkVO
	 */
	void updateUseConfmSttus(EwalletUseConfmChkVO ewalletUseConfmChkVO);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 19.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 19.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param ewalletUseConfmChkVO
	 */
	void insertMbEntrpsInfoBasHst(EwalletUseConfmChkVO ewalletUseConfmChkVO);

}
