package com.sorincorp.batch.sample.cotroller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;

import com.sorincorp.batch.sample.model.SampleVO;
import com.sorincorp.batch.sample.service.SampleService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Controller
public class SampleDbController {
	
	@Autowired
	private SampleService sampleService;
	
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param sampleVO - 조회할 정보가 담긴 SampleVO
	 * @param model
	 * @return "sampleList"
	 * @exception Exception
	 */
	@RequestMapping("/selectSampleList")
	public String selectSampleList(@ModelAttribute("sampleVO") SampleVO sampleVO, ModelMap model) throws Exception {
		
		List<SampleVO> sampleList = sampleService.selectSampleList(sampleVO);
		model.addAttribute("resultList", sampleList);
		
		log.debug("selectSampleList log Sample 1 : " + model);

		int totalcount = sampleService.selectSampleListTotCnt(sampleVO);
		model.addAttribute("totalcount", totalcount);
		
		log.debug("selectSampleList log Sample 2 : " + totalcount);

		return "sample/sampleList.tiles";
	}
	
	/**
	 * 글 등록 화면을 조회한다.
	 * @param sampleVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "sampleRegister"
	 * @exception Exception
	 */
	@RequestMapping("/insertSampleView")
	public String insertSampleView(Model model) throws Exception {
		
		model.addAttribute("sampleVO", new SampleVO());
		return "sample/sampleRegister.tiles";
	}

	/**
	 * 글을 등록한다.
	 * @param sampleVO - 등록할 정보, 목록 조회조건 담긴 VO
	 * @param status
	 * @return "forward:/sampleList"
	 * @exception Exception
	 */
	@Transactional
	@PostMapping("/insertSample")
	public String insertSample(@ModelAttribute("sampleVO") @Valid SampleVO sampleVO, BindingResult bindingResult, Model model, SessionStatus status)
			throws Exception {
		
		if (bindingResult.hasErrors()) {
			model.addAttribute("sampleVO", sampleVO);
			return "sample/sampleRegister.tiles";
		}
		
		sampleService.insertSample(sampleVO);
		status.setComplete();
		return "redirect:/selectSampleList";
	}

	/**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param sampleVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "sampleRegister"
	 * @exception Exception
	 */
	@RequestMapping("/updateSampleView")
	public String updateSampleView(@RequestParam("selectedId") String id, @ModelAttribute("sampleVO") SampleVO sampleVO, Model model) throws Exception {
		
		sampleVO.setId(id);
		model.addAttribute(selectSample(sampleVO));
		return "sample/sampleRegister.tiles";
	}

	/**
	 * 글을 조회한다.
	 * @param sampleVO - 조회할 정보, 목록 조회조건 담긴 VO
	 * @param status
	 * @return sampleVO - 조회한 정보
	 * @exception Exception
	 */
	public SampleVO selectSample(@ModelAttribute("sampleVO") SampleVO sampleVO) throws Exception {
		
		return sampleService.selectSample(sampleVO);
	}

	/**
	 * 글을 수정한다.
	 * @param sampleVO - 수정할 정보, 목록 조회조건 담긴 VO
	 * @param status
	 * @return "forward:/selectSampleList"
	 * @exception Exception
	 */
	@Transactional
	@RequestMapping("/updateSample")
	public String updateSample(@ModelAttribute("sampleVO") @Valid SampleVO sampleVO, BindingResult bindingResult, Model model, SessionStatus status)
			throws Exception {
		
		if (bindingResult.hasErrors()) {
			model.addAttribute("sampleVO", sampleVO);
			return "sample/sampleRegister.tiles";
		}
		
		sampleService.updateSample(sampleVO);
		status.setComplete();
		return "redirect:/selectSampleList";
	}

	/**
	 * 글을 삭제한다.
	 * @param sampleVO - 삭제할 정보, 목록 조회조건 담긴 VO
	 * @param status
	 * @return "forward:/selectSampleList"
	 * @exception Exception
	 */
	@Transactional
	@RequestMapping("/deleteSample")
	public String deleteSample(@ModelAttribute("sampleVO") SampleVO sampleVO, SessionStatus status) throws Exception {
		
		sampleService.deleteSample(sampleVO);
		status.setComplete();
		return "redirect:/selectSampleList";
	}
	
    /**
     * 조회
     * @param sampleVO - 조회할 정보가 담긴 sampleVO
     * @param model
     * @return "sampleVO"
     * @exception Exception
     */
    @RequestMapping("/selectSampleAjax")
    @ResponseBody
    public SampleVO selectSampleAjax(@ModelAttribute("sampleVO") SampleVO sampleVO) throws Exception {
        
        log.debug(sampleVO.toString());
        
        return sampleVO;
    }
}
