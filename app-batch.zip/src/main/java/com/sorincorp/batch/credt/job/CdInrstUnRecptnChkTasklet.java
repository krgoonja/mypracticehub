package com.sorincorp.batch.credt.job;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.credt.service.MrtggService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * CdInrstUnRecptnChkTasklet.java
 * CD금리 미 수신 체크 후 SMS 전송 단계 태스크 릿
 * @version
 * @since 2022. 8. 11.
 * @author srec0049
 */
@Slf4j
@Component
public class CdInrstUnRecptnChkTasklet implements Tasklet, StepExecutionListener {
	
	
	/**
	 * SMS 발송 서비스
	 */
	@Autowired
	private SMSService smsService;
	
	/**
	 * 담보 보증 서비스
	 */
	@Autowired
	MrtggService mrtggService;
	
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("[CdInrstUnRecptnChkTasklet][beforeStep] in");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("[CdInrstUnRecptnChkTasklet][execute] in");
		
		// 당일 오전 8시에 전일날짜로 CD금리 수신 인터페이스 테이블(GTX_API_CDRATE)에 해당 요청일자의 데이터가 있는지 체크(CD금리 데이터 확인)
		String refDate = this.getCalculFormatDay("yyyyMMdd", -1); // 전일날짜, 요청일자 조회 조건
		boolean cdInrstUnRecptnChk = mrtggService.isCdInrstUnRecptnChk(refDate);
		log.debug(">> [CdInrstUnRecptnChkTasklet][execute] cdInrstUnRecptnChk : " + cdInrstUnRecptnChk);
		if(!cdInrstUnRecptnChk) {
			// 데이터가 없으면 SMS 전송 [SMS_SNDNG_GROUP_CODE(90) : CD 금리 미수신]
			log.debug(">> [CdInrstUnRecptnChkTasklet][execute] sms 전송!!");
			
			Map<String, String> smsMap = new HashMap<String, String>();
			smsMap.put("commerceNtcnCn", "CD 금리 미수신"); // 알림 메세지
			smsMap.put("templateNum", "72");
			smsMap.put("returnMsg", StringUtil.formatDate(refDate)); // 요청일자(전일) formatDate(String strTarget)
			smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
			smsService.insertSMS(null, smsMap);
		}
		
		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("[CdInrstUnRecptnChkTasklet][afterStep] in");
        return ExitStatus.COMPLETED;
	}
	
	private String getCalculFormatDay(String formatStr, int calc) {
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(cal.DATE, calc); // 하루전

		return df.format(cal.getTime());
	}
}
