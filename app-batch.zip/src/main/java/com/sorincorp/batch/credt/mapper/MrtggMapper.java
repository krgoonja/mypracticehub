package com.sorincorp.batch.credt.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.batch.credt.model.CredtRepyVO;
import com.sorincorp.batch.credt.model.OrMrtggMdstrmRepyDtlVO;

public interface MrtggMapper {

	/**
	 * <pre>
	 * 전자상거래보증 결제예정일 지난 미상환 목록 조회
	 * </pre>
	 * @date 2022. 8. 3.
	 * @author srec0051
	 * @return
	 */
	List<CredtRepyVO> getUnRepyList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 미상환 출고 등록대상 목록 조회
	 * </pre>
	 * @date 2024. 7. 11.
	 * @author srec0066
	 * @param orderNo
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 7. 11.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	List<OrMrtggMdstrmRepyDtlVO> selectNootgRepyTargetList(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_담보 중도 상환 상세 tbl 미상환 출고 데이터 등록
	 * </pre>
	 * @date 2024. 7. 11.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 7. 11.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	int insertOrMrtggMdstrmRepyDtl(OrMrtggMdstrmRepyDtlVO orMrtggMdstrmRepyDtlVO) throws Exception; //
	
	/**
	 * <pre>
	 * 처리내용: 담보 미출고 상환 SMS 정보 가져오기
	 * </pre>
	 * @date 2024. 7. 16.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 7. 16.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orMrtggMdstrmRepyDtlVO
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectMrtggNootgRepySmsInfo(OrMrtggMdstrmRepyDtlVO orMrtggMdstrmRepyDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 전일날짜 기준 CD금리 수신 건수 조회
	 * </pre>
	 * @date 2022. 8. 12.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 12.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param refDate
	 * @return
	 * @throws Exception
	 */
	int cdInrstRecptnCnt(String refDate) throws Exception;
}
