package com.sorincorp.batch.credt.mapper;

import java.util.List;

import com.sorincorp.batch.credt.model.NpyOrderVO;

public interface NpyOrderDlvyRqestdeChangeMapper {
	/**
	 * <pre>
	 * 처리내용: 결제예정일이 오늘인 미결제 주문 정보 조회
	 * </pre>
	 * @date 2022. 11. 8.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 8.			srec0053			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<NpyOrderVO> selectNpyOrderList();
	
	/**
	 * <pre>
	 * 처리내용: 주문_차량 기본 테이블에 차량 입고 일자 update
	 * </pre>
	 * @date 2022. 11. 8.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 8.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param npyOrderVO
	 */
	int updateVhcleInfoBas(NpyOrderVO npyOrderVO);

	/**
	 * <pre>
	 * 처리내용: 주문_차량 주문 상세 테이블 update
	 * </pre>
	 * @date 2024. 6. 4.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 6. 4.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	int updateOrVhcleOrderDtl(NpyOrderVO npyOrderVO);

	/**
	 * <pre>
	 * 처리내용: 주문번호에 해당하는 배송차수 정보 조회
	 * </pre>
	 * @date 2022. 11. 8.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 8.			srec0053			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<NpyOrderVO> selectVhcleInfoBas(String orderNo);
}
