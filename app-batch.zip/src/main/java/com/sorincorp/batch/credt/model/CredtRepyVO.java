package com.sorincorp.batch.credt.model;

import lombok.Data;

@Data
public class CredtRepyVO {

	/** 주문번호 */
	private String orderNo;
	/** 담보번호 */
	private String mrtggNo;
	/** 결제예정일자 */
	private String setlePrearngeDe;
	/** 미 결제 금액 */
	private long unSetleAmount;
	/** 업체번호 */
	private String entrpsNo;
	/** 결제 방식 코드 */
	private String setleMthdCode;
	/** 담보 상태 코드 */
	private String mrtggSttusCode;
    /** 중도 상환 순번 */
    private long mdstrmRepySn;


//	/** 결제번호 */
//	private String setleNo;
//	/** 담보순번 */
//	private String mrtggDetailSn;
//	/** 대출번호 */
//	private String lonNo;
//
//	/** 대출결제수단코드 {2:카드, 3:론, 4:자금} */
//	private String sanctnMnCode;
//	/** 상태코드 */
//	private String sttusCode;
//	/** 만기일 */
//	private String exprtnDe;
//	/** 은행코드 */
//	private String bankCode;
//	/** 총한도 */
//	private Long bankLimitAmt;
//	/** 남은한도 */
//	private Long bankLimitSpare;
//	/** 회원권한구분코드 */
//	private String mberSeCode;
//	/** 주문 상태 코드 */
//	private String orderSttusCode;
//	/** OMS 접수 번호 */
//	private String omsRceptNo;
//	/** 결제 방식 상세 코드 */
//	private String setleMthdDetailCode;
//	/** 주문 홀딩 사용 여부 */
//	private String orderHoldingUseAt;
//	/** 회원번호 */
//	private String mberNo;
}
