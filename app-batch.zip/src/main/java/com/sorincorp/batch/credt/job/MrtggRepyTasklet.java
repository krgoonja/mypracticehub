package com.sorincorp.batch.credt.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.credt.service.MrtggService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class MrtggRepyTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	MrtggService mrtggService;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("::beforeStep");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("::execute Start");

		String ret = mrtggService.mrtggRepyCall();
		log.debug(ret);

		log.debug("::execute End");
		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("::afterStep");
        return ExitStatus.COMPLETED;
	}
}
