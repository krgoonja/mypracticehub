package com.sorincorp.batch.credt.service;

public interface NotCnclsLonCanclService {
	void notCnclsLonCancl() throws Exception;
}
