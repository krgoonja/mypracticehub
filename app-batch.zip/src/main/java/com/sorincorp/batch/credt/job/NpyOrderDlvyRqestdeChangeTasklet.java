package com.sorincorp.batch.credt.job;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.credt.service.NpyOrderDlvyRqestdeChangeService;

import lombok.extern.slf4j.Slf4j;

/**
 * NpyOrderDlvyRqestdeChangeTasklet.java
 * @version
 * @since 2022. 11. 8.
 * @author srec0053
 */
@Slf4j
@Component
public class NpyOrderDlvyRqestdeChangeTasklet implements Tasklet, StepExecutionListener {
	
	@Autowired
	NpyOrderDlvyRqestdeChangeService npyOrderDlvyRqestdeChangeService;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("NpyOrderDlvyRqestdeChangeTasklet::beforeStep");
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("NpyOrderDlvyRqestdeChangeTasklet::afterStep");
        return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("::execute Start");
		try {
			npyOrderDlvyRqestdeChangeService.executeNpyOrderDlvyRqestdeChange();
		}catch(Exception e) {
			log.error("[npyOrderDlvyRqestdeChange Error] {}", ExceptionUtils.getStackTrace(e));
		}
		log.debug("NpyOrderDlvyRqestdeChangeTasklet::execute End");
		return RepeatStatus.FINISHED;
	}

}
