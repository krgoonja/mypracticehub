package com.sorincorp.batch.credt.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.sorincorp.batch.comm.constants.CommConstants;
import com.sorincorp.batch.credt.constant.MrtggConstant;
import com.sorincorp.batch.credt.mapper.MrtggMapper;
import com.sorincorp.batch.credt.model.CredtRepyVO;
import com.sorincorp.batch.credt.model.OrMrtggMdstrmRepyDtlVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.mapper.CommLimitOrderMapper;
import com.sorincorp.comm.order.model.CommBlceInfoVO;
import com.sorincorp.comm.order.model.CommOrLimitOrderBasVO;
import com.sorincorp.comm.order.service.CommFinalBlceCheckService;
import com.sorincorp.comm.order.service.CommLimitOrderService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MrtggServiceImpl implements MrtggService {

	/** 외부 연계 api 호출 모듈 **/
	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	MrtggMapper mrtggMapper;

	/** 지정가 주문 Mapper */
	@Autowired
	CommLimitOrderMapper commLimitOrderMapper;

	/** 예수금 포함 최종 잔액 조회 서비스 */
	@Autowired
	private CommFinalBlceCheckService commFinalBlceCheckService;

	/** 지정가 주문 공통 서비스 */
	@Autowired
	private CommLimitOrderService commLimitOrderService;

	/** 공통 서비스 */
    @Autowired
    private CommonService commonService;
    
    /** SMS 발송 서비스 */
    @Autowired
    private SMSService smsService;

	/** 이월렛 잔액조회 url */
	@Value("${order.api.ewallet.money.url}")
	private String ewalletAccountMoney;

	/** 이월렛 상환 url */
	@Value("${credit.ewallet.repy.url}")
	private String repyEwalletUrl;

	/** 전자상거래보증 상환 url */
	@Value("${credit.mrtgg.repy.url}")
	private String repyMrtggUrl;

	private final String RESPONSE_CODE = "rspnsCode";
	private final String RESPONSE_MESSAGE = "rspnsMssage";


	@Override
	public String mrtggRepyCall() throws Exception {
		log.debug("mrtggRepyCall::: START");

		// 전자상거래보증 미상환 목록 조회
		List<CredtRepyVO> unRepyList = mrtggMapper.getUnRepyList();

		if (CollectionUtils.isEmpty(unRepyList)) {
			return CommConstants.SUCCESS_MSG;
		}

		for (CredtRepyVO vo : unRepyList) {
			excuteRepy(vo);
		}

		log.debug("mrtggRepyCall::: END");

		return CommConstants.SUCCESS_MSG;
	}

	// 상환 실행
	private void excuteRepy(CredtRepyVO vo) {

		Map<String, Object> requstObj = null;
		Map<String, Object> rspnsObj = null;

		try {
//			ewalletAccountMoney(vo); // 이월렛 잔액 조회 (이중 체크로 제거)

			/**
			 * 2023.05.18 예수금최종잔액조회
			 */
			CommBlceInfoVO commBlceInfoVO = commFinalBlceCheckService
					.selectFinalBlceInfoBySetleMn(vo.getEntrpsNo(), "", "", vo.getUnSetleAmount());

			// 1. 대상 지정가 목록을 가져온다 (가장 최근 주문 기준으로 - 역순)
			List<CommOrLimitOrderBasVO> limitOrderList = commLimitOrderMapper.selectListLimitOrderAutoCancel(vo.getEntrpsNo());

			// 상환 불가능 판단시 지정가 주문 자동 취소 공통 서비스 호출
			// 2024.06.20 - 지정가 리스트 존재 여부 확인 추가
			if (!commBlceInfoVO.isDelngPossAt()) {
				if (!CollectionUtils.isEmpty(limitOrderList)) {
					commLimitOrderService.limitOrderAutoCancel("BATCH", vo.getEntrpsNo(), "44", vo.getUnSetleAmount());
				}
			}

			/** 1. call ewallet
			 * 이월렛 처리 호출시 "상환구분코드"를 "03" 으로 호출하여 잔액 모두를 처리할 수 있도록 한다
			 */
			requstObj = new HashMap<>();
			requstObj.put("orderNo", vo.getOrderNo());
			requstObj.put("repySeCode", MrtggConstant.RepySeCode.NYP_REPY.getCode()); // 10:미납상환(모두)
			requstObj.put("mdstrmRepySn", vo.getMdstrmRepySn()); // 중도 상환 순번

			rspnsObj = httpClientHelper.postCallApi(repyEwalletUrl, requstObj);
			if (null == rspnsObj || StringUtil.isBlank(String.valueOf(rspnsObj.get(RESPONSE_CODE))) ) {
				throw new Exception("e-wallet rspnsObj is null");
			}

			if ("500".equals(String.valueOf(rspnsObj.get(RESPONSE_CODE)))) {
				throw new Exception(String.valueOf(rspnsObj.get(RESPONSE_MESSAGE)));
			}

			/** 2. call mrtgg
			 * 전자상거래보증 미납 처리 호출시 "상환구분코드"를 "03" 으로 호출하여 잔액 모두를 처리할 수 있도록 한다
			 *
			 * 2024-04-24: 전자상거래보증(20) or 케이지크레딧(40)일 경우에만 호출, 상환완료 이후 추가결제건은 이월렛만 결제하므로 제외
			 */
			if(("20".equals(vo.getSetleMthdCode()) || "40".equals(vo.getSetleMthdCode())) && !MrtggConstant.MrtggSttusCode.REPYCOMPT.getCode().equals(vo.getMrtggSttusCode())) {
				requstObj.put("mrtggSttusCode", MrtggConstant.MrtggSttusCode.PARTREPY.getCode());
				requstObj.put("mberId", "BATCH");

				rspnsObj = httpClientHelper.postCallApi(repyMrtggUrl, requstObj);
				if (null == rspnsObj || StringUtil.isBlank(String.valueOf(rspnsObj.get(RESPONSE_CODE))) ) {
					throw new Exception("mrtgg rspnsObj is null");
				}

				if ("500".equals(String.valueOf(rspnsObj.get(RESPONSE_CODE)))) {
					throw new Exception(String.valueOf(rspnsObj.get(RESPONSE_MESSAGE)));
				}

			}
		} catch (Exception e) {
			log.error(e.getMessage()+ " 업체번호:{}, 주문번호:{}, 담보번호:{}", vo.getEntrpsNo(), vo.getOrderNo(), vo.getMrtggNo());
		}
	}

	/**
	 * 이월렛 잔액 조회
	private void ewalletAccountMoney(CredtRepyVO vo) throws Exception {
		Map<String, Object> rspnsObj = httpClientHelper.postCallApi(ewalletAccountMoney, Collections.singletonMap("entrpsNo", vo.getEntrpsNo()));
		log.warn(">> E-WALLET 잔금 조회 resObj : " + rspnsObj);
		if (rspnsObj != null && rspnsObj.get("data") != null) {
			Map<String, Object> dataObj = (Map<String, Object>) rspnsObj.get("data");
			long ewalletMoney =  NumberUtils.toLong(String.valueOf(dataObj.get("delngAmount")));
			if (ewalletMoney < vo.getUnSetleAmount()) {
				throw new Exception("Ewallet 금액 부족");
			}
		} else {
			throw new Exception("Ewallet 잔금 조회 실패");
		}
	}
	 */

	/**
	 * 담보 미출고 상환 데이터 생성 (OR_MRTGG_MDSTRM_REPY_DTL(주문_담보 중도 상환 상세) tbl 등록)
	 */
	@Override
	public void saveMrtggNootgRepyInfo(String orderNo) throws Exception {
		// 1. 등록 대상 목록 조회
		List<OrMrtggMdstrmRepyDtlVO> nootgRepyList = mrtggMapper.selectNootgRepyTargetList(orderNo);
		log.info("[mrtggNootgRepyInfoCreatJob] nootgRepyList :: " + nootgRepyList);

		for (OrMrtggMdstrmRepyDtlVO data : nootgRepyList) {
			try {
				// 2. 담보 미출고 상환 데이터 등록 (데이터 없을 경우만 등록 진행)
				int res = mrtggMapper.insertOrMrtggMdstrmRepyDtl(data);
				if(res > 0) {
					// 3. 담보 미출고 상환 SMS 발송
					try {
						// 담보 미출고 상환 SMS 발송
						this.sendMrtggNootgRepySms(data, 144);
					} catch(Exception e) {
						log.error("[mrtggNootgRepyInfoCreatJob][saveMrtggNootgRepyInfo] - orderNo(" + data.getOrderNo() + ") 담보 미출고 상환 SMS 전송 ERROR: " + e.getMessage());
					}
					
					// 4. 이력 테이블 등록
					commonService.insertTableHistory("OR_MRTGG_MDSTRM_REPY_DTL", data);
				}
			} catch (Exception e) {
				log.error("[mrtggNootgRepyInfoCreatJob] - orderNo(" + data.getOrderNo() + ") 담보 미출고 상환 데이터 등록 ERROR: " + e.getMessage());
			}
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 담보 미출고 상환 SMS 발송
	 * </pre>
	 * @date 2024. 7. 16.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 7. 16.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orMrtggMdstrmRepyDtlVO
	 * @param templateNum
	 * @throws Exception
	 */
	private void sendMrtggNootgRepySms(OrMrtggMdstrmRepyDtlVO orMrtggMdstrmRepyDtlVO, int templateNum) throws Exception {
		// 담보 미출고 상환 SMS 정보 가져오기
		Map<String, String> smsMap = mrtggMapper.selectMrtggNootgRepySmsInfo(orMrtggMdstrmRepyDtlVO);
		
		SMSVO smsVo = new SMSVO();
		
		// OR_ORDER_BAS(주문_주문 기본)-ORDRR_MOBLPHON_NO(주문자 휴대폰 번호) 복호화
        String ordrrMoblphonNo = String.valueOf(smsMap.get("ordrrMoblphonNo")); // 주문자 휴대폰 번호
        if (StringUtils.isNotEmpty(ordrrMoblphonNo)) {
            try {
                log.debug("주문자 휴대폰 번호 복호화 전 ==================>" + ordrrMoblphonNo);
                ordrrMoblphonNo = CryptoUtil.decryptAES256(ordrrMoblphonNo);
                log.debug("주문자 휴대폰 번호 복호화 후 ==================>" + ordrrMoblphonNo);
                /** 주문자 휴대폰 번호 셋팅 **/
                ordrrMoblphonNo = StringUtil.formatPhone(ordrrMoblphonNo);
            } catch (Exception e) {
                log.error("LoServiceImpl sendMessageToCustomer ORDRR_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
            }
        }
        
        smsVo.setPhone(ordrrMoblphonNo.replace("-", "")); // 주문자 휴대폰 번호
        smsVo.setMberNo(String.valueOf(smsMap.get("mberNo"))); // 회원 번호
        smsVo.setCommerceNtcnAt("N");
        
        // OR_DLVRG_BAS(주문_배송지 기본) - RECEPT_ENTRPS_MOBLPHON_NO(수취 업체 휴대폰 번호) 복호화, 배송지 담당자 연락처
        String receptEntrpsMoblphonNo = String.valueOf(smsMap.get("receptEntrpsMoblphonNo"));
        if (StringUtils.isNotEmpty(receptEntrpsMoblphonNo)) {
            try {
                log.debug("수취 업체 휴대폰 번호 복호화 전 ==================>" + receptEntrpsMoblphonNo);
                receptEntrpsMoblphonNo = CryptoUtil.decryptAES256(receptEntrpsMoblphonNo);
                log.debug("수취 업체 휴대폰 번호 복호화 후 ==================>" + receptEntrpsMoblphonNo);
                /** 수취 업체 휴대폰 번호 셋팅 **/
                receptEntrpsMoblphonNo = StringUtil.formatPhone(receptEntrpsMoblphonNo);
            } catch (Exception e) {
                log.error("LoServiceImpl sendMessageToCustomer RECEPT_ENTRPS_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
            }
        }
        
        smsMap.put("receptEntrpsMoblphonNo", receptEntrpsMoblphonNo); // 배송지 담당자 연락처 변경
        
        smsMap.put("templateNum", String.valueOf(templateNum));
        smsMap.put("Servicedomain", "https://m.metalsorin.com");
        // 결제수단에 따른 결제정보 치환
        String replacedOdrSetleInfo = getOdrSetleInfoData(smsMap);
        smsMap.put("odrSetleInfo", replacedOdrSetleInfo);
        
        // SMS 또는 LMS 발송 및 알림톡 발송
        smsService.insertSMSByReturnMssageSndngHistNo(smsVo, smsMap);
	}
	
	/**
	 * <pre>
	 * 처리내용: 결제수단에 따른 결제정보 치환
	 * </pre>
	 * @date 2024. 7. 17.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 7. 17.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param smsMap
	 * @return
	 * @throws Exception
	 */
	private String getOdrSetleInfoData(Map<String, String> smsMap) throws Exception {
		StringBuilder targetTmplat = new StringBuilder();
		
		String setleMthCode = String.valueOf(smsMap.get("setleMthCode")); // 결제 방식 코드
        String sleMthdCode = String.valueOf(smsMap.get("sleMthdCode")); // 판매 방식 코드
        String sleMthdDetailCode = String.valueOf(smsMap.get("sleMthdDetailCode")); // 판매 방식 상세 코드
        String goodsUntpc = String.valueOf(smsMap.get("goodsUntpc")); // 결제단가
        String slepc = String.valueOf(smsMap.get("slepc")); // 주문금액
        String setlePrearngeAmount = String.valueOf(smsMap.get("setlePrearngeAmount")); // 결제예정금액
        String setlePrearngeDe = String.valueOf(smsMap.get("setlePrearngeDe")); // 결제예정일
        String setleMthdNm = String.valueOf(smsMap.get("setleMthdNm")); // 결제방법

        // 2023-12-06 변경사항 : 평균가 판매방식 추가에 따른 메세지 포멧 변경
        // 1. 기본 문구 세팅
        String setleMthdNmStr = "결제 방법 : " + setleMthdNm;
        String goodsUntPcStr = "결제단가 : " + goodsUntpc;
        String slepcStr = "주문금액 : " + slepc;
        String setlePrearngeAmountStr = "결제예정금액 : " + setlePrearngeAmount;
        String setlePrearngeDeStr = "결제예정일 : " + setlePrearngeDe;
        
        // 평균가(04)는 부분상환이 없어서 이 로직을 탈 일은 현재는 없음, 20240719
        // 2. 평균가(04) 또는 평균가-LIVE(0104) 주문일 경우, 세팅된 문구 추가 또는 바꿔치기
        // 24-02-19 변경사항 : 평균가-지정가(0304) 주문도 해당 로직 수행하도록 조건 추가
        if( StringUtils.equals("04", sleMthdCode) || StringUtils.equals("0104", sleMthdDetailCode) || StringUtils.equals("0304", sleMthdDetailCode) ) {
        	String avrgpcGoodsUntpc = String.valueOf(smsMap.get("avrgpcGoodsUntpc")); // 평균가 결제단가
        	
        	if(StringUtils.isNotEmpty(avrgpcGoodsUntpc) && !StringUtils.equals("0", avrgpcGoodsUntpc)) {
        		if(StringUtils.isNotEmpty(goodsUntpc) && !StringUtils.equals("0", goodsUntpc)) {
        			goodsUntPcStr +=  " (가단가 : " + avrgpcGoodsUntpc + ")";
        		} else {
        			goodsUntPcStr = "결제단가 : " + avrgpcGoodsUntpc + "(가단가)";
        		}
        		
        		String avrgpcSlepc = String.valueOf(smsMap.get("avrgpcSlepc")); // 평균가 주문금액
        		slepcStr = "주문금액 : " + avrgpcSlepc;
        	}
        }

        /** 결제 수단에 따른 SMS 템플릿 설정 */
        /* 전자상거래보증 or 서린크레딧 */
        if ("20".equals(setleMthCode) || "40".equals(setleMthCode)) {
        	targetTmplat.append(setleMthdNmStr).append("\r\n")
        		.append(goodsUntPcStr).append("\r\n")
        		.append(slepcStr).append("\r\n")
        		.append(setlePrearngeAmountStr).append("\r\n")
        		.append(setlePrearngeDeStr);
        }
        
        return targetTmplat.toString();
    }

	/**
	 * 당일 오전 8시에 전일날짜로 CD금리 수신 인터페이스 테이블(GTX_API_CDRATE)에 해당 요청일자의 데이터가 있는지 체크(CD금리 데이터 확인)
	 */
	@Override
	public boolean isCdInrstUnRecptnChk(String refDate) throws Exception {
		boolean cdInrstRecptnChkStatus = false; // true: 수신, false: 미수신
		// 전일날짜 기준 CD금리 수신 건수 조회
		int cdInrstRecptnCnt = mrtggMapper.cdInrstRecptnCnt(refDate);
		log.debug(">> [MrtggServiceImpl][isCdInrstUnRecptnChk] cdInrstRecptnCnt : " + cdInrstRecptnCnt);
		if(cdInrstRecptnCnt > 0) {
			cdInrstRecptnChkStatus = true;
		}
		log.debug(">> [MrtggServiceImpl][isCdInrstUnRecptnChk] cdInrstRecptnChkStatus : " + cdInrstRecptnChkStatus);
		return cdInrstRecptnChkStatus;
	}
}
