package com.sorincorp.batch.credt.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.credt.mapper.NpyOrderDlvyRqestdeChangeMapper;
import com.sorincorp.batch.credt.model.NpyOrderVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.common.service.CommonService;

import lombok.extern.slf4j.Slf4j;

/**
 * NpyOrderDlvyRqestdeChangeServiceImpl.java
 * @version
 * @since 2022. 11. 8.
 * @author srec0053
 */
@Slf4j
@Service
public class NpyOrderDlvyRqestdeChangeServiceImpl implements NpyOrderDlvyRqestdeChangeService {
	
	@Autowired
	private NpyOrderDlvyRqestdeChangeMapper npyOrderDlvyRqestdeChangeMapper;
	
	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private CommonService commonService;

	@Value("${order.api.lo.url}")
	private String loOmsUrl;

	/**
	 *	잔금이 미납된 주문의 배송요청일을 변경한다.
	 */
	@Override
	public void executeNpyOrderDlvyRqestdeChange() throws Exception {
		// api call url init
		String url = null;
		
		// 1. 금일 기준 미납 주문 데이터 select
		List<NpyOrderVO> npyOrderList = npyOrderDlvyRqestdeChangeMapper.selectNpyOrderList();

		// 2. 배송수단에 따라 로직 분기
		for (NpyOrderVO npyOrderVO : npyOrderList) {

			if(StringUtils.equals("01", npyOrderVO.getDlvyMnCode())) {
				// [01 : 케이지배송] 일 때

				// 1)API 호출 : SOREC-IF-106 (출고요청일자 변경)
				// /DlvrgChange/{orderNo}/{dlvrgNo}/{dlvyRqestde}/{sysSe}
				url = loOmsUrl + "/DlvrgChange" 
					+ "/" + npyOrderVO.getOrderNo() 			//주문 번호
					+ "/" + npyOrderVO.getOrderDlvrgNo() 		//주문 배송지 번호
					+ "/" + npyOrderVO.getChangeDlvyRqestde() 	//변경할 출고요청일자
					+ "/3";										//시스템 구분 번호 : 3 (batch 프로그램에서 호출)
				Map<String, Object> result = httpClientHelper.postCallApi(url, null);
				
				if(result == null) {
					log.debug("SOREC-IF-106 API CALL FAILED");
				}
			} else {
				// [02 : 자차배송] 일 때

				// 1) 차량 관련 데이터 조회
				List<NpyOrderVO> vhcleInfoList = npyOrderDlvyRqestdeChangeMapper.selectVhcleInfoBas(npyOrderVO.getOrderNo());
				Map<String,String> keyValue = new HashMap<>(); // 이력 등록용

				if(vhcleInfoList != null && vhcleInfoList.size() > 0) {
					for (NpyOrderVO vhcleInfo : vhcleInfoList) {
						vhcleInfo.setChangeDlvyRqestde(npyOrderVO.getChangeDlvyRqestde());

						// 2) 주문_차량 기본 UPDATE
						int updateBasResult = npyOrderDlvyRqestdeChangeMapper.updateVhcleInfoBas(vhcleInfo);
						if(updateBasResult > 0) {
							// 이력 등록
							keyValue.put("VHCLE_SN",String.valueOf(vhcleInfo.getVhcleSn()));
							commonService.insertTableHistory("OR_VHCLE_BAS", keyValue);
						}

						// 3) 주문_차량 주문 상세 UPDATE
						int updateDtlResult = npyOrderDlvyRqestdeChangeMapper.updateOrVhcleOrderDtl(vhcleInfo);
						if(updateDtlResult > 0) {
							// 이력 등록
							keyValue = new HashMap<>();
							keyValue.put("VHCLE_ORDER_SN",String.valueOf(vhcleInfo.getDlvyOdr()));
							commonService.insertTableHistory("OR_VHCLE_ORDER_DTL", keyValue);
						}
					}

					// 4) API 호출 : SOREC-IF-114 (자차배송 차량정보 송신)
					// /sendDlvyVhcleInfo/{sysSe}
					url = loOmsUrl + "/sendDlvyVhcleInfo/3";	//시스템 구분 번호 : 3 (batch 프로그램에서 호출)

					Map<String, Object> result = httpClientHelper.postCallApi(url, vhcleInfoList);

					if(result == null) {
						log.debug("SOREC-IF-114 API CALL FAILED");
					}
				}
			}
		}
	}

}
