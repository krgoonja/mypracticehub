package com.sorincorp.batch.credt.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class NotCnclsLonCanclJobConfig {
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private NotCnclsLonCanclTasklet notCnclsLonCanclTasklet;
	
	@Bean
	public Job notCnclsLonCanclJob() {
		return jobBuilderFactory.get("notCnclsLonCanclJob")
				.start(notCnclsLonCanclStep())
				.build();
	}
	
	@Bean
	@JobScope
	public Step notCnclsLonCanclStep() {
		return stepBuilderFactory.get("notCnclsLonCanclStep")
				.tasklet(notCnclsLonCanclTasklet)
				.build();
	}
}
