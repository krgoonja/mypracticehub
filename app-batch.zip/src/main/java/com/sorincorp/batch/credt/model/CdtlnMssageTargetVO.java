package com.sorincorp.batch.credt.model;

import lombok.Data;

@Data
public class CdtlnMssageTargetVO {
	/**
	 * 주문번호
	 */
	private String orderNo;
	/**
	 * 메시지 템플릿 번호
	 */
	private String templateNum;
	
	/** 중도 상환 순번 */
	private Long mdstrmRepySn;
}
