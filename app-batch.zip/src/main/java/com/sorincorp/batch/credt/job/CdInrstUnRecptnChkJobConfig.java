package com.sorincorp.batch.credt.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * CdInrstUnRecptnChkJobConfig.java
 * CD금리 미 수신 체크 후 SMS 전송 배치 설정
 * @version
 * @since 2022. 8. 11.
 * @author srec0049
 */
@Slf4j
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class CdInrstUnRecptnChkJobConfig {
	@Autowired
	CdInrstUnRecptnChkTasklet cdInrstUnRecptnChkTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory;
	
	@Bean
	public Job cdInrstUnRecptnChkJob() {
		log.debug("[CdInrstUnRecptnChkJobConfig][cdInrstUnRecptnChkJob] in");
		
		return jobBuilderFactory.get("cdInrstUnRecptnChkJob")
				.start(cdInrstUnRecptnChkStep())
				.build();  
	}
	
	@Bean
	@JobScope
	public Step cdInrstUnRecptnChkStep() {
		log.debug("[CdInrstUnRecptnChkJobConfig][cdInrstUnRecptnChkStep] in");
		
		return stepBuilderFactory.get("cdInrstUnRecptnChkStep")
				.tasklet(cdInrstUnRecptnChkTasklet)
				.build();
	}
}
