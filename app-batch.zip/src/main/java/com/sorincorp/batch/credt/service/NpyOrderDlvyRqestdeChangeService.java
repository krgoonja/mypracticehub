package com.sorincorp.batch.credt.service;

/**
 * NpyOrderDlvyRqestdeChangeService.java
 * @version
 * @since 2022. 11. 8.
 * @author srec0053
 */
public interface NpyOrderDlvyRqestdeChangeService {
	/**
	 * <pre>
	 * 처리내용: 잔금이 미납된 주문의 배송요청일을 변경한다.
	 * </pre>
	 * @date 2022. 11. 8.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 8.			srec0053			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	void executeNpyOrderDlvyRqestdeChange() throws Exception;
}
