package com.sorincorp.batch.credt.mapper;

import java.util.List;

public interface NotCnclsLonCanclMapper {
	List<String> getCanclTargetList();
}
