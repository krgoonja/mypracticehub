package com.sorincorp.batch.credt.model;

import lombok.Data;

@Data
public class WrtmOppsTrdeVo {

    /**
     * 주문 번호
    */
    private String orderNo;

    /**
     * 주문자 명
    */
    private String ordrrNm;

    /**
     * 주문자 휴대폰 번호
    */
    private String ordrrMoblphonNo;
    /**
     * 주문자 이메일
    */
    private String ordrrEmail;
    /**
     * 회원 번호
    */
    private String mberNo;
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 주문 업체 명
     */
    private String orderEntrpsNm;
    /**
     * 총 실제 주문 중량
    */
    private int totRealOrderWt;
    /**
     * 상품 단가
    */
    private long goodsUntpc;
	 /**
	  * 주문 가격
	 */
	 private long orderPc;
    /**
     * 중량 변동금
    */
    private long wtChangegld;
	/**
	 * 예상배송비
	*/
	private long expectDlvrf;
    /**
     * 최초 결제 금액
    */
    private long frstSetleAmount;
    /**
     * 미 결제 금액
    */
    private long unSetleAmount;
    /**
     * 증거금 결제 예정 일자
    */
    private String wrtmSetlePrearngeDe;
    /**
     * 반대매매 예정일
     */
    private String oppsTrdePrarnde;
    /**
     * 템플릿메세지 타입("D4: 미납 4일 초과", "D5: 미납 5일 초과")
     */
    private String templateType;
    /*
     * 계약 발주 번호
     */
    private String cntrctOrderNo;
}