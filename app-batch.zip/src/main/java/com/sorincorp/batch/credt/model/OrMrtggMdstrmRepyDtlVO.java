package com.sorincorp.batch.credt.model;

import lombok.Data;

/**
 * OrMrtggMdstrmRepyDtlVO.java : 주문_담보 중도 상환 상세 VO
 * @version
 * @since 2024. 7. 11.
 * @author srec0066
 */
@Data
public class OrMrtggMdstrmRepyDtlVO {
	
	/** 담보 번호 */
	private String mrtggNo;

    /** 주문 번호  */
    private String orderNo;

    /** 중도 상환 순번 */
    private long mdstrmRepySn;

    /** 배송 차수 */
    private int dlvyOdr;

    /** 입금 요청 금액 */
    private long rcpmnyRequstAmount;

    /** 결제 예정 일자 */
    private String setlePrearngeDe;

    /** 배송 수단 코드 */
    private String dlvyMnCode;

    /** 배송비 */
    private long dlvrf;
}
