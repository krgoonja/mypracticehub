package com.sorincorp.batch.credt.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * 전자상거래보증 만기 상환 배치
 * @author srec0051
 *
 */
@Slf4j
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class MrtggRepyJobConfig {

	@Autowired
	private MrtggRepyTasklet mrtggRepyTasklet;

	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job mrtggRepyJob() {
		return jobBuilderFactory.get("mrtggRepyJob")
				.start(mrtggRepyStep())
//				.on("FAILED") // FAILED 일 경우
//                .to(step3()) // step3으로 이동한다.
//                .on("*") // step3의 결과 관계 없이
//                .end() // step3으로 이동하면 Flow가 종료한다.
				.build();
	}

	@Bean
	@JobScope
	public Step mrtggRepyStep() {
		return stepBuilderFactory.get("mrtggRepyStep")
				.tasklet(mrtggRepyTasklet)
				.build();
	}

//	@Bean
//    public Step step3() {
//        return stepBuilderFactory.get("step3")
//                .tasklet((contribution, chunkContext) -> {
//                    log.debug(">>>>> This is stepNextConditionalJob Step3");
//                    return RepeatStatus.FINISHED;
//                })
//                .build();
//    }
}
