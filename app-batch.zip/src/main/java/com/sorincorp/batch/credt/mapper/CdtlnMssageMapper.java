package com.sorincorp.batch.credt.mapper;

import java.util.List;

import com.sorincorp.batch.credt.model.CdtlnMssageTargetVO;
import com.sorincorp.batch.credt.model.WrtmOppsTrdeVo;

public interface CdtlnMssageMapper {
	/**
	 * <pre>
	 * 처리내용: 메세지 발송 대상 데이터 조회
	 * </pre>
	 * @date 2022. 9. 20.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 20.			srec0053			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<CdtlnMssageTargetVO> selectCdtlnMssageTarget();

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 미납 주문(D+4, D+5)에 대한 반대매매 대상 조회
	 * </pre>
	 * @date 2022. 10. 26.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 26.			srec0070			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<WrtmOppsTrdeVo> selectWrtmOppsTrdeTargetList() throws Exception;
}
