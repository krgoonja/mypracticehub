package com.sorincorp.batch.credt.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 담보 미출고 상환 데이터 생성 배치 JobConfig
 * @version
 * @since 2024. 7. 10.
 * @author srec0066
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class MrtggNootgRepyInfoCreatJobConfig {

	@Autowired
	MrtggNootgRepyInfoCreatTasklet mrtggNootgRepyInfoCreatTasklet;

	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job mrtggNootgRepyInfoCreatJob() {
		return jobBuilderFactory.get("mrtggNootgRepyInfoCreatJob")
				.start(mrtggNootgRepyInfoCreatStep())
				.build();
	}

	@Bean
	@JobScope
	public Step mrtggNootgRepyInfoCreatStep() {
		return stepBuilderFactory.get("mrtggNootgRepyInfoCreatStep")
				.tasklet(mrtggNootgRepyInfoCreatTasklet)
				.build();
	}
}
