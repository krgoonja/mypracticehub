package com.sorincorp.batch.credt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.batch.comm.constants.CommConstants;
import com.sorincorp.batch.credt.service.MrtggService;
import com.sorincorp.batch.or.comm.ClaimResponseEntity;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/batch/credt")
@Api( value = "Mrtgg Batch Controller")
@ComponentScan("com.sorincorp.comm.*")
public class MrtggController {

	@Autowired
	private MrtggService mrtggService;

	@PostMapping("/mrtggRepy")
	@ApiOperation(value = "전자상거래보증 미상환 처리 Batch", notes = "전자상거래보증 미상환 처리 Batch")
	public ClaimResponseEntity mrtggRepy() throws Exception {

		try {
			String ret = mrtggService.mrtggRepyCall();
			log.debug(ret);

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new Exception(e.getMessage());
		}

		return new ClaimResponseEntity(CommConstants.SUCCESS_CODE, CommConstants.SUCCESS_MSG, null);
	}
}
