package com.sorincorp.batch.credt.model;

import lombok.Data;

@Data
public class NpyOrderVO {
	/**
	 * 주문 번호
	 */
	private String orderNo;
	
	/**
	 * 주문 배송지 번호
	 */
	private String orderDlvrgNo;
	
	/**
	 * 변경 예정 배송요청일 (= 기존 배송요청일 + 5일)
	 */
	private String changeDlvyRqestde;
	
	/**
	 * 배송 수단 코드
	 */
	private String dlvyMnCode;
	
	/**
	 * 주문 순번
	 */
	private String orderSn;
	
	/**
	 * 배송 차수
	 */
	private int dlvyOdr;
	
	/**
     * 차량 순번
     */
    private int vhcleSn;
}
