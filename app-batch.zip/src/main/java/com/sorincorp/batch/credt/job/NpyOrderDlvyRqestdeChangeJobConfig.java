package com.sorincorp.batch.credt.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * NpyOrderDlvyRqestdeChangeJobConfig.java
 * @version
 * @since 2022. 11. 8.
 * @author srec0053
 */
@Configuration
@EnableBatchProcessing
public class NpyOrderDlvyRqestdeChangeJobConfig {
	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private NpyOrderDlvyRqestdeChangeTasklet npyOrderDlvyRqestdeChangeTasklet;
	
	@Bean
	public Job npyOrderDlvyRqestdeChangeJob() {
		return jobBuilderFactory.get("npyOrderDlvyRqestdeChangeJob")
				.start(npyOrderDlvyRqestdeChangeStep())
				.build();
	}
	
	@Bean
	@JobScope
	public Step npyOrderDlvyRqestdeChangeStep() {
		return stepBuilderFactory.get("npyOrderDlvyRqestdeChangeStep")
				.tasklet(npyOrderDlvyRqestdeChangeTasklet)
				.build();
	}
}
