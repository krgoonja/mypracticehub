package com.sorincorp.batch.credt.service;

import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.sorincorp.batch.credt.mapper.CdtlnMssageMapper;
import com.sorincorp.batch.credt.model.CdtlnMssageTargetVO;
import com.sorincorp.batch.credt.model.WrtmOppsTrdeVo;
import com.sorincorp.batch.or.service.WrtmMsgService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.message.service.CdtlnMessageService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CdtlnMssageServiceImpl implements CdtlnMssageService {
	@Autowired
	CdtlnMessageService cdtlnMessageService;

	@Autowired
	CdtlnMssageMapper cdtlnMssageMapper;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private WrtmMsgService wrtmMsgService;

	@Override
	public void sendCdtlnMssage() throws Exception {
		List<CdtlnMssageTargetVO> mssageTarget = cdtlnMssageMapper.selectCdtlnMssageTarget();

		for (CdtlnMssageTargetVO target : mssageTarget) {
			cdtlnMessageService.insertCdtlnSmsReturnMssageNo(target.getOrderNo(), target.getMdstrmRepySn(), target.getTemplateNum(), null);
		}
	}

	@Override
	public void sendWrtmOppsTrdeMssage() throws Exception {
		List<WrtmOppsTrdeVo> mssageTarget = cdtlnMssageMapper.selectWrtmOppsTrdeTargetList();
		if(!CollectionUtils.isEmpty(mssageTarget)) {
			CommonCodeVO csCodeInfo =
					Optional.ofNullable(commonCodeService.getCodeValueRetVo("SORIN_SETUP_CODE", "CS_TEL"))
							.orElseThrow(() -> {return new Exception("SORIN_SETUP_CODE 정보 미존제.");});

			String csTelNo = csCodeInfo.getCodeDcone();
			for(WrtmOppsTrdeVo target : mssageTarget) {
				// 평균가 주문인 경우 메일은 전송 하지 않는다.
				String cntrctOrderNo = target.getCntrctOrderNo();
				if(StringUtils.isEmpty(cntrctOrderNo)) {
					wrtmMsgService.sendWrtmOppsTrdeEmail(target, csTelNo, 69);
				}
				wrtmMsgService.sendWrtmOppsTrdeSms(target, csTelNo, 81);
			}
		}
	}
}
