package com.sorincorp.batch.credt.service;

public interface CdtlnMssageService {
	void sendCdtlnMssage() throws Exception;

	void sendWrtmOppsTrdeMssage() throws Exception;
}
