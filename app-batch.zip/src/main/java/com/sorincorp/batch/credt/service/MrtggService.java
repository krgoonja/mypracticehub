package com.sorincorp.batch.credt.service;

public interface MrtggService {

	/**
	 * <pre>
	 * 전자상거래보증 만기 상환 처리 Batch
	 * </pre>
	 * @date 2022. 8. 3.
	 * @author srec0051
	 * @return
	 * @throws Exception
	 */
	String mrtggRepyCall() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 담보 미출고 상환 데이터 생성 (OR_MRTGG_MDSTRM_REPY_DTL(주문_담보 중도 상환 상세) tbl 등록)
	 * </pre>
	 * @date 2024. 7. 10.
	 * @author srec0066
	 * @param orderNo
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 7. 10.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws Exception
	 */
	void saveMrtggNootgRepyInfo(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 당일 오전 8시에 전일날짜로 CD금리 수신 인터페이스 테이블(GTX_API_CDRATE)에 해당 요청일자의 데이터가 있는지 체크(CD금리 데이터 확인)
	 * </pre>
	 * @date 2022. 8. 12.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 12.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param refDate
	 * @return
	 * @throws Exception
	 */
	boolean isCdInrstUnRecptnChk(String refDate) throws Exception;
}
