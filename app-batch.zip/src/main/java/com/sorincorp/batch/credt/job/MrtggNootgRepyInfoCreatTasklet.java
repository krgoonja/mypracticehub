package com.sorincorp.batch.credt.job;

import java.util.Map;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.credt.service.MrtggService;

import lombok.extern.slf4j.Slf4j;

/**
 * 담보 미출고 상환 데이터 생성 배치 Tasklet
 * @version
 * @since 2024. 7. 10.
 * @author srec0066
 */
@Slf4j
@Component
public class MrtggNootgRepyInfoCreatTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	MrtggService mrtggService;

	public void beforeStep(StepExecution stepExecution) {
		log.debug("MrtggNootgRepyInfoCreatTasklet::beforeStep");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("MrtggNootgRepyInfoCreatTasklet::execute Start");

		JobParameters jobParameters = chunkContext.getStepContext().getStepExecution().getJobParameters();
		Map<String, JobParameter> jobParamMap = jobParameters.getParameters();
		JobParameter param = jobParamMap.get("param01");

		String orderNo = null;
		if(null != param) {
			orderNo = param.toString();
		}
		log.info("MrtggNootgRepyInfoCreatTasklet::orderNo - {}", orderNo);

		mrtggService.saveMrtggNootgRepyInfo(orderNo);

		log.debug("MrtggNootgRepyInfoCreatTasklet::execute End");

		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("MrtggNootgRepyInfoCreatTasklet::afterStep");
        return ExitStatus.COMPLETED;
	}
}
