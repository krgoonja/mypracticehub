package com.sorincorp.batch.credt.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.credt.mapper.NotCnclsLonCanclMapper;
import com.sorincorp.comm.btb.comm.HttpClientHelper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class NotCnclsLonCanclServiceImpl implements NotCnclsLonCanclService {
	@Autowired
	private NotCnclsLonCanclMapper notCnclsLonCanclMapper;
	
	@Autowired
	private HttpClientHelper httpClientHelper;
	
	@Value("${credit.lon.cancl.url}")
	private String canclApiUrl;

	@Override
	public void notCnclsLonCancl() throws Exception {
		//취소 대상인 매매계약서의 대출 번호 조회
		List<String> targetList = notCnclsLonCanclMapper.getCanclTargetList();
		
		if (targetList != null) {
			//호출 파라메터 작성
			Map<String, String> param = new HashMap<>();
			
			//매매계약서 취소 api 호출
			for (String target : targetList) {
				param.clear();
				param.put("lonNo", target);
				httpClientHelper.postCallApi(canclApiUrl, param);
			}
		}
	}
	
}
