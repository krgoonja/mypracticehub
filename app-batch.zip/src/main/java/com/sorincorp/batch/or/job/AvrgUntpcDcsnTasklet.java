package com.sorincorp.batch.or.job;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.or.service.EstmtPurchsService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AvrgUntpcDcsnTasklet implements Tasklet, StepExecutionListener {
	
	@Autowired
	private EstmtPurchsService estmtPurchsService;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("AvrgUntpcDcsnTasklet::beforeStep");
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("AvrgUntpcDcsnTasklet::afterStep");
        return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("AvrgUntpcDcsnTasklet::execute Start");
		
		// 24-03-05 변경사항 : Lme Csp 배치 프로그램과 기능 통합함에 따라 현 프로그램은 더이상 사용하지 않음
		
//		JobParameters jobParameters = chunkContext.getStepContext().getStepExecution().getJobParameters();
//		Map<String, JobParameter> jobParamMap = jobParameters.getParameters();
//		JobParameter param = jobParamMap.get("param01");
//		
//		String nowDate = DateUtil.getNowDate();
//		String executeTimePoint = "FIRST";	// "FIRST" (월초)
//		
//		// 24-01-19 변경사항 : 테스트를 위한 코드 추가
//		String testMode = null;
//		String orderNos = null;
//		String occrrncMt = null;
//		
//		if(param!= null) {
//			Map<String, String> commandOption = getParseOptions(param.toString());
//			log.info("commandOption :[{}]", commandOption.toString());
//			
//			testMode = commandOption.get("testMode");
//			orderNos = commandOption.get("orderNos");
//			occrrncMt = commandOption.get("occrrncMt");
//			
//			log.info("testMode : {}, orderNo : {}, occrrncMt : {}", testMode, orderNos, occrrncMt);
//			
//			if(StringUtils.equals(testMode, "Y")) {
//				if(orderNos == null) {
//					log.info("입력된 주문번호가 없으므로 테스트 모드 실행이 불가능합니다.");
//					return RepeatStatus.FINISHED;
//				}
//				
//				estmtPurchsService.executeAvrgUntpcDcsn(executeTimePoint, orderNos, occrrncMt);
//			} else {
//				log.info("testMode 값이 Y가 아닙니다.");
//				return RepeatStatus.FINISHED;
//			}
//		} else if(estmtPurchsService.isFirstOrLastBusinessDayOfMonth(nowDate, executeTimePoint)) {
//			// parameter : "FIRST" (월초) -> 월초에 실행되는 단가 확정 처리 로직
//			estmtPurchsService.executeAvrgUntpcDcsn(executeTimePoint, null, null);
//		}
		
		log.debug("AvrgUntpcDcsnTasklet::execute End");
		return RepeatStatus.FINISHED;
	}
	
	/*
	 * 젠킨스 커맨드라인에서 받은 문자열 파싱
	 */
	private Map<String, String> getParseOptions(String param) {
		log.info("getParseOptions ========> receive param: [{}]", param);
		Map<String, String> map = new HashMap<String, String>();
		if(StringUtils.isEmpty(param)) {
			return map;
		}

		String options[] = param.split(":");

		if (options != null && options.length > 0) {
            for (String option : options) {
                if (option.contains("=")) {
                    String key = option.substring(0, option.indexOf("="));
                    String value = option.substring(option.lastIndexOf("=") + 1).toUpperCase();
                    map.put(key, value);
                }
            }
        }
        return map;
	}
}
