package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * PrvsnlPcChangegldRealarmJobConfig.java
 * 가단가 변동금 재알람(Tasklet 방식) 구성
 * 
 * @version
 * @since 2024. 11. 21.
 * @author srec0049
 */
@Configuration
@EnableBatchProcessing
public class PrvsnlPcChangegldRealarmJobConfig {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private PrvsnlPcChangegldRealarmTasklet prvsnlPcChangegldRealarmTasklet;
	
	
	@Bean
	public Job prvsnlPcChangegldRealarmJob() {
		return jobBuilderFactory.get("prvsnlPcChangegldRealarmJob")
				.start(prvsnlPcChangegldRealarmStep())
				.build();
	}

	@Bean
	@JobScope
	public Step prvsnlPcChangegldRealarmStep() {
		return stepBuilderFactory.get("prvsnlPcChangegldRealarmStep")
				.tasklet(prvsnlPcChangegldRealarmTasklet)
				.build();
	}
}
