package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 평균가 확정 단가 배치
 * @version
 * @since 2023. 12. 7.
 * @author srec0053
 */
@Configuration
@EnableBatchProcessing
public class AvrgUntpcDcsnJobConfig {

	@Autowired
	private AvrgUntpcDcsnTasklet avrgUntpcDcsnTasklet;

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job avrgUntpcDcsnJob() {
		return jobBuilderFactory.get("avrgUntpcDcsnJob").start(avrgUntpcDcsnStep()).build();
	}

	@Bean
	@JobScope
	public Step avrgUntpcDcsnStep() {
		return stepBuilderFactory.get("avrgUntpcDcsnStep").tasklet(avrgUntpcDcsnTasklet).build();
	}

}
