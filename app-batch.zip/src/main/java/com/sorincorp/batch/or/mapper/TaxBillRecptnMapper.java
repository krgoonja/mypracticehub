package com.sorincorp.batch.or.mapper;

import java.util.List;

import com.sorincorp.batch.or.model.TaxBillRecptnVO;


/**
 * 
 * 세금계산서 발행완료 btobi 수신 Batch Mapper.java
 * @version
 * @since 2021. 9. 2.
 * @author srec0054
 */
public interface TaxBillRecptnMapper {

	/**세금계산서 발행완료 목록 조회*/
	List<TaxBillRecptnVO> getListTaxBillRecptn();
	
	/**세금계산서 발행완료 btobi 수신 결과 업데이트 OR_TAX_BILL_BAS (주문_세금계산서_기본)*/
	void updateOrTaxBillBas(TaxBillRecptnVO paramVo);
	
	String selectOrTaxBillBas(TaxBillRecptnVO paramVo) throws Exception;
	
	/**세금계산서 발행완료 btobi 수신 결과 업데이트 IF_OR_TAX_BILL_BAS (인터페이스_세금계산서_기본)*/
	void updateifOrTaxBillBas(TaxBillRecptnVO paramVo);
	
	/**주문_세금계산서_기본 이력	(OR_TAX_BILL_BAS_HST)*/
	void updateOrTaxBillBasHst(TaxBillRecptnVO paramVo);

	/**ERP 전송 대상 주문 목록 조회*/
	List<TaxBillRecptnVO> selectErpTrnsmisTaxBillList();
	
	/**ERP 송신 여부 업데이트*/
	void updateErpTrnsmisTaxBill(TaxBillRecptnVO taxBillRecptnVo);
	
	/**2차 세금계산서 발송 IF 여부*/
	void selectReceiverList(String smsSndngGroupCode) throws Exception;
	
}//end interface()
