package com.sorincorp.batch.or.comm;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 세금계산서 발행완료 btobi 수신 Batch TaxBillRecptnConstants.java
 * @version
 * @since 2021. 9. 2.
 * @author srec0054
 */
@Slf4j
public final class TaxBillRecptnConstants {

	private TaxBillRecptnConstants() {
		log.debug(TaxBillRecptnConstants.class.getSimpleName());
	}
	
	/**RESULT*/
	public static final int SUCCESS_CODE 			= 200;
	public static final int ERROR_CODE 				= 400;
	public static final String SUCCESS_RESULT_CODE	= "200";
	public static final String ERROR_RESULT_CODE 	= "500";
	public static final String SUCCESS_MSG 			= "Success";
	public static final String ERROR_MSG 			= "Error";
	public static final String EHR_REPONSE_RESULT_MSG 	= "result_msg";
	public static final String EHR_REPONSE_RESULT_DATA 	= "result_data";
	public static final String EHR_REPONSE_RESULT_CODE 	= "result_code";
	
	/**인터페이스 ID*/
	public static final String TAX_BILL_IF	= "SOREC-IF-116";	//세금계산서 발행요청 btobi 수신
	
	
	/**B2B 연계상태*/
	/**문서 상태 코드*/
	public static final String B2B_STATUS_R		= "R";
	public static final String B2B_STATUS_X		= "X";
	public static final String B2B_STATUS_S		= "S";
	public static final String B2B_STATUS_T		= "T";
	public static final String B2B_STATUS_P 	= "P";
	public static final String B2B_STATUS_F 	= "F";
	/**수신 메시지 코드*/
	public static final String B2B_MSGCODE_0 	= "00";
	public static final String B2B_MSGCODE_1	= "01";
	public static final String B2B_MSGCODE_2	= "02";
	public static final String B2B_MSGCODE_3	= "03";
	public static final String B2B_MSGCODE_98	= "98";
	public static final String B2B_MSGCODE_99	= "99";
	/**수신 결과 코드*/
	public static final String B2B_RESULTCODE_SUC001 = "SUC001";
	
	
	/**인터페이스 처리 상태 코드 (EC)*/
	public static final String INTRFC_STTUS_CODE_C	= "C"; //수신완료
	public static final String INTRFC_STTUS_CODE_E	= "E"; //오류발생
	public static final String INTRFC_STTUS_CODE_F	= "F"; //처리 실패
	public static final String INTRFC_STTUS_CODE_I	= "I"; //처리중
	public static final String INTRFC_STTUS_CODE_N	= "N"; //미처리
	public static final String INTRFC_STTUS_CODE_R	= "R"; //송신완료
	public static final String INTRFC_STTUS_CODE_S	= "S"; //처리완료
	
	/**처리 상태 코드 (EC)*/
	public static final String PROCESS_STTUS_CODE_01 = "01"; //신청
	public static final String PROCESS_STTUS_CODE_02 = "02"; //처리중
	public static final String PROCESS_STTUS_CODE_03 = "03"; //발행완료
	public static final String PROCESS_STTUS_CODE_04 = "04"; //발행실패
	public static final String PROCESS_STTUS_CODE_05 = "05"; //송신실패(재처리요청)
	
}//end class()
