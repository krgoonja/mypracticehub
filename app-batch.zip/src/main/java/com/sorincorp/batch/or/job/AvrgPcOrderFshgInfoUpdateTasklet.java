package com.sorincorp.batch.or.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.or.service.AvrgPcOrderFshgInfoUpdateService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AvrgPcOrderFshgInfoUpdateTasklet implements Tasklet, StepExecutionListener {
	@Autowired
	private AvrgPcOrderFshgInfoUpdateService avrgPcOrderFshgInfoUpdateService;
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.info("AvrgPcOrderFshgInfoUpdateTasklet::beforeStep");
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.info("AvrgPcOrderFshgInfoUpdateTasklet::afterStep");
        return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.info("AvrgPcOrderFshgInfoUpdateTasklet::execute Start");
		
		avrgPcOrderFshgInfoUpdateService.updateAvrgPcOrderFshgInfo();
		
		log.info("AvrgPcOrderFshgInfoUpdateTasklet::execute End");
		
		return RepeatStatus.FINISHED;
	}
	
}
