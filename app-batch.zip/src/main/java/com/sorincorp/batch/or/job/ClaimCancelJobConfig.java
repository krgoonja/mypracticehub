package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class ClaimCancelJobConfig {

	@Autowired
	private ClaimCancelTasklet claimCancelTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory;
	
	@Bean
	public Job claimCancelJob() {
		return jobBuilderFactory.get("claimCancelJob")
				.start(claimCancelStep())
				.build();  
	}
	
	@Bean
	@JobScope
	public Step claimCancelStep() {
		return stepBuilderFactory.get("claimCancelStep")
				.tasklet(claimCancelTasklet)
				.build();
	}
}
