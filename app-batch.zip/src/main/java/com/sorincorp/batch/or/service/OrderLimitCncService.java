package com.sorincorp.batch.or.service;

/**
 * 미체결 지정가 주문 취소 서비스
 * @author srec0051
 *
 */
public interface OrderLimitCncService {

	/**
	 * <pre>
	 * 미체결 지정가 주문 취소 처리
	 * </pre>
	 * @date 2023. 4. 19.
	 * @author srec0051
	 * @throws Exception
	 */
	void cancelPendingOrders(String time) throws Exception;

	/**
	 * <pre>
	 * 미체결 가단가 지정가 주문 취소 처리
	 * </pre>
	 * @date 2024. 10. 24.
	 * @author srec0066
	 * @throws Exception
	 */
	void cancelPendingPrvsnlOrders(String time) throws Exception;
}
