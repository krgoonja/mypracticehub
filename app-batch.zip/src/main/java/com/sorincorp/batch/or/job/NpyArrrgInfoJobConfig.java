package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 결제 예정, 미납/연체 내역 메일 발송 JobConfig
 * NpyArrrgInfoJobConfig.java
 * @version
 * @since 2023. 1. 20.
 * @author srec0076
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class NpyArrrgInfoJobConfig {
	
	@Autowired
	NpyArrrgInfoTasklet npyArrrgInfoTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory; 
	
	@Bean
	public Job npyArrrgInfoJob() {
		return jobBuilderFactory.get("npyArrrgInfoJob")
				.start(npyArrrgInfoStep())
				.build();  
	}//end NpyArrrgInfoJobConfig()
	
	@Bean
	@JobScope
	public Step npyArrrgInfoStep() {
		return stepBuilderFactory.get("npyArrrgInfoStep")
				.tasklet(npyArrrgInfoTasklet)
				.build();
	}//end NpyArrrgInfoStep()
	
}//end class()