package com.sorincorp.batch.or.model;

import java.io.Serializable;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class AvrgPcEstmtCntrctVO extends CommonVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 4523468673028883572L;

	private String estmtNo;
	private String cntrctNo;
	private String estmtSttusCode;
	private String propseTitle;
	private String mberNo;
	private String entrpsNo;
	private String orderEntrpsNm;
	private String ordrrNm;
	private String ordrrMoblphonNo;
	private String ordrrEmail;
	private String tmlmtEndDt;
	private String mssageTmplatSj;
	private String newEstmtSttusCode;
	private String seCode;
}
