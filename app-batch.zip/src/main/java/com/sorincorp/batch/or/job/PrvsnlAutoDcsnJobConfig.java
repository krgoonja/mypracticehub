package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * PrvsnlAutoDcsnJobConfig.java
 * 가단가 자동 확정 배치(Tasklet 방식) 구성
 * 
 * @version
 * @since 2024. 11. 6.
 * @author srec0049
 */
@Configuration
@EnableBatchProcessing
public class PrvsnlAutoDcsnJobConfig {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private PrvsnlAutoDcsnTasklet prvsnlAutoDcsnTasklet;
	
	
	@Bean
	public Job prvsnlAutoDcsnJob() {
		return jobBuilderFactory.get("prvsnlAutoDcsnJob")
				.start(prvsnlAutoDcsnStep())
				.build();
	}

	@Bean
	@JobScope
	public Step prvsnlAutoDcsnStep() {
		return stepBuilderFactory.get("prvsnlAutoDcsnStep")
				.tasklet(prvsnlAutoDcsnTasklet)
				.build();
	}
}
