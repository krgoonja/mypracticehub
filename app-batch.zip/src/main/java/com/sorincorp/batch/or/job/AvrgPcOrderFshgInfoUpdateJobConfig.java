package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class AvrgPcOrderFshgInfoUpdateJobConfig {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private AvrgPcOrderFshgInfoUpdateTasklet avrgPcOrderFshgInfoUpdateTasklet;
	
	@Bean
	public Job avrgPcOrderFshgInfoUpdateJob() {
		return jobBuilderFactory.get("avrgPcOrderFshgInfoUpdateJob").start(avrgPcOrderFshgInfoUpdateStep()).build();
	}

	@Bean
	@JobScope
	public Step avrgPcOrderFshgInfoUpdateStep() {
		return stepBuilderFactory.get("avrgPcOrderFshgInfoUpdateStep")
									.tasklet(avrgPcOrderFshgInfoUpdateTasklet)
									.build();
	}
}
