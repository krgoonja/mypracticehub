package com.sorincorp.batch.or.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.batch.or.model.ArrrgTrgterVO;
import com.sorincorp.batch.or.model.ClaimDtlVO;
import com.sorincorp.batch.or.model.DlvrfBasVO;
import com.sorincorp.batch.or.model.OrderDtlVO;
import com.sorincorp.batch.or.model.OrderFtrsBasVO;
import com.sorincorp.batch.or.model.BatchOrderModel;
import com.sorincorp.comm.order.model.ItPurchsInfoBas;

public interface WrtmOrderCnclMapper {

	/**
	 *
	 * <pre>
	 * 처리내용: 다음달 선물, 선물환 만기일을 조회한다.
	 * </pre>
	 * @date 2022. 10. 19.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 19.			srec0070			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectNextMonthExprtnDate() throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 주문 중 연체주문 정보의 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 9. 5.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 5.			srec0070			최초작성
	 * ------------------------------------------------
	 * @return 증거금 연제주문 List<batchOrderModel>
	 * @throws Exception
	 */
	List<BatchOrderModel> selectWrtmArrrgOrderList(String wrtmCanclOrderNo) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 주문 상세 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 9. 7.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 7.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @return
	 */
	List<OrderDtlVO> selectOrderBasDtlList(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 주문과 연동된 배송비 리스트 정보를 조회한다.
	 * </pre>
	 * @date 2022. 9. 7.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 7.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @return
	 */
	DlvrfBasVO selectOrderDlvrfBasInfo(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 주문 쥐소와 관련된 주문_배송비 기본 데이터를 등록한다.
	 * </pre>
	 * @date 2022. 9. 7.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 7.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	int insertOrDlvrfBas(DlvrfBasVO param) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 주문_배송비 기본 데이터의 이력 정보를 등록한다.
	 * </pre>
	 * @date 2022. 9. 7.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 7.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	int insertOrDlvrfBasHst(DlvrfBasVO param) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: BL별 PO 정보를 조회한다.
	 * </pre>
	 * @date 2022. 9. 21.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 21.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @return
	 * @throws Exception
	 */
	ItPurchsInfoBas selectItPurchsInfoBas(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: PO 테이블의 선물 만기일 날짜가 오늘 날짜 이전이면 PO 테이블의 선물 만기일을 다음달 만기일로 수정한다.
	 * </pre>
	 * @date 2022. 10. 25.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 25.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param caimDtlVO
	 * @return
	 * @throws Exception
	 */
	int updatePOFtrsExprtnDe(ClaimDtlVO caimDtlVO) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: PO 테이블의 변경시 PO 테이블의 이력 테이블에 등록 한다.
	 * </pre>
	 * @date 2022. 10. 25.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 25.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param claimDtlVO
	 * @return
	 * @throws Exception
	 */
	int insertItPurchsInfoBasHst(ClaimDtlVO claimDtlVO) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 주문의 주문 선물(삼성선물) 기본 데이터를 주문 수량별로 등록한다.
	 * </pre>
	 * @date 2022. 9. 19.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 19.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @return
	 * @throws Exception
	 */
	int insertSamsungBase(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 삼성선물 주문건 중 실패건에 대한 취소주문 처리를 한다.
	 * </pre>
	 * @date 2022. 10. 7.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 7.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @throws Exception
	 */
	void insertSamsungCancel(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 삼성선물 주문건 중 취소 주문에 대한 완료 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 10. 7.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 7.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @return
	 */
	List<OrderFtrsBasVO> selectCancelSamsungResponse(BatchOrderModel batchOrderModel);

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소주문의 주문 선물환(하나FX) 기본 데이터를 주문 수량별로 등록한다.
	 * </pre>
	 * @date 2022. 9. 21.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 21.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @throws Exception
	 */
	void insertHanaFxBase(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소주문의 결재 정보를 등록한다.
	 * </pre>
	 * @date 2022. 9. 23.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 23.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @throws Exception
	 */
	void insertEwalletSetle(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 상품_BL 정보 기본 재고 수정한다.
	 * </pre>
	 * @date 2022. 9. 23.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 23.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @throws Exception
	 */
	void updateInvntryBlInfoBas(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 상품_BL 정보이력 상세 등록 한다.
	 * </pre>
	 * @date 2022. 9. 23.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 23.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @throws Exception
	 */
	void insertInvntryBlInfoHstDtl(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 상품_BL 정보 기본 재고 수정 이력 등록한다.
	 * </pre>
	 * @date 2022. 9. 23.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 23.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @throws Exception
	 */
	void insertBlInfoBasHst(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 환율 사이드카 발동여부를 조회한다.
	 * </pre>
	 * @date 2022. 10. 7.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 7.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @return
	 * @throws Exception
	 */
	int chkLmeSidecar(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: LME 사이드카 발동여부를 조회한다.
	 * </pre>
	 * @date 2022. 10. 7.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 7.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @return
	 * @throws Exception
	 */
	int chkFxSidecar(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 주취소주문 성공 후 메일 전송을 위해 미납대상자 관리내용을 조회한다.
	 * </pre>
	 * @date 2022. 10. 18.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 18.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	List<ArrrgTrgterVO> selectNpyOrderManageList(String orderNo) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 주문 취소시 메일 전송을 위해 Live 가격 산정 근거 조회한다.
	 * 주문시점의 가격 및 바로 직전 데이터 및 그이후 데이터 3개를 조회한다.
	 * </pre>
	 * @date 2022. 10. 20.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 20.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @return
	 * @throws Exception
	 */
	List<Map<String, String>> selectLivePcCalcBasisList(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 주문중 상세 코드가 이월렛 + 구매자금 주문의 매매계약서 대출번호를 조회한다.
	 * </pre>
	 * @date 2022. 11. 7.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 7.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	List<String> selectWrtmTrdeCtrtcList(String orderNo) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 취소(반대매매) 배치 진행 시에 해당 주문 건에 대하여 회원_업체 정보 기본(MB_ENTRPS_INFO_BAS) 테이블에
	 * 		  연체 건수를 증가 시킨다.
	 * </pre>
	 * @date 2022. 12. 6.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 6.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @return int
	 * @throws Exception
	 */
	int increaseArrrgCo(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소주문시 회원_업체 정보 기본 테이블의 연체건수를 증가시킨후 HIST 테이블에 등록
	 * </pre>
	 * @date 2022. 12. 6.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 6.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @return
	 * @throws Exception
	 */
	int registArrrgCoForHist(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소(반대매매) 배치 진행 시에 해당 주문건에 대하여 이력을 남긴다.
	 * </pre>
	 * @date 2022. 12. 6.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 6.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @return int
	 * @throws Exception
	 */
	int registOrCdtlnAcdntHst(BatchOrderModel batchOrderModel) throws Exception;
}
