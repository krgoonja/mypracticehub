package com.sorincorp.batch.or.model;

import lombok.Data;

@Data
public class DlvrfBasVO {

	/**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 취소 교환 반품 번호
    */
    private String canclExchngRtngudNo;
    /**
     * 주문 배송비 번호
    */
    private String orderDlvrfNo;

    /**
     * 취소 주문 배송비 번호
    */
    private String cnclOrderDlvrfNo;

    /**
     * 배송 구분 코드
    */
    private String dlvySeCode;
    /**
     * 배송비 부담 주체 코드
    */
    private String dlvrfBndMbyCode;
    /**
     * 배송비 부과 구분 코드
    */
    private String dlvrfLevySeCode;
    /**
     * 예상 배송비
    */
    private java.math.BigDecimal expectDlvrf;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
}
