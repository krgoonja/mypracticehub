package com.sorincorp.batch.or.mapper;

import java.util.List;

import com.sorincorp.batch.or.model.OrderLimitCncVO;
import com.sorincorp.batch.or.model.OrderLimitVO;

public interface OrderLimitMapper {

	/**
	 * <pre>
	 * 미체결 지정가 취소 처리
	 * </pre>
	 * @date 2023. 4. 19.
	 * @author srec0051
	 * @param time 
	 * @return
	 */
	int cancelPendingOrders(OrderLimitCncVO orderLimitCncVO) throws Exception;

	/**
	 * <pre>
	 * 취소처리된 지정가 주문 히스토리 등록
	 * </pre>
	 * @date 2023. 4. 19.
	 * @author srec0051
	 * @param time 
	 */
	int insertOrLimitOrderBasHst(OrderLimitCncVO orderLimitCncVO) throws Exception;

	/**
	 * <pre>
	 * 미체결 지정가 주문 취소 건 SMS 발송
	 * </pre>
	 * @date 2023. 5. 22.
	 * @author srec0051
	 * @param time 
	 * @throws Exception
	 */
	List<OrderLimitVO> selectListCncLimitOrder(OrderLimitCncVO orderLimitCncVO) throws Exception;

	/**
	 * <pre>
	 * 취소 대상 미체결 가단가 지정가 주문목록 조회
	 * </pre>
	 * @date 2024. 10. 24.
	 * @author srec0066
	 * @param time
	 * @throws Exception
	 */
	List<OrderLimitVO> selectCnclTrgetPrvsnlLimitOrderList(OrderLimitCncVO orderLimitCncVO) throws Exception;

}
