package com.sorincorp.batch.or.service;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.batch.or.mapper.SoCredtSttusInfoMapper;
import com.sorincorp.batch.or.model.SoCredtSttusInfoVO;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SoCredtSttusInfoServiceImpl implements SoCredtSttusInfoService{

	@Autowired
	private SoCredtSttusInfoMapper sorinCreditSttuInfoMapper;

	/** 메일 발송 서비스 */
    @Autowired
    private MailService mailService;

	@Autowired
	private MailMapper mailMapper;

    @Autowired
    private CommonCodeService commonCodeService;
    
	/**
	 * 월 단위 케이지크레딧 현황 정보 발송
	 * */
	@Transactional(rollbackFor = Exception.class)
	@Override
	public void sendSoCredtSttusInfo() throws Exception {

		log.debug("SorinCreditSttusInfoServiceImpl:sendSorinCreditSttusInfo (케이지크레딧 현황정보 전송) Start");

		// 당일과 금주 마지막 영업일 차이
		int lastBsnDe = sorinCreditSttuInfoMapper.selectLastBsnDe();

		// 오늘 = 금주 마지막 영업일 
		if(lastBsnDe == 0) {
			log.debug("오늘 = 금주 마지막 영업일이므로 로직 실행");
			
	        // 케이지크레딧 현황 정보 조회
	        List<SoCredtSttusInfoVO> sttusInfo = sorinCreditSttuInfoMapper.selectSoCredtSttuInfoList();
	        
	        // 당일 날짜 구하기
            String dayParam = DateUtil.getNowDate();

	        // 메일 발송 및 히스토리 등록
	        sendSoCredtSttusInfoEmail(sttusInfo, dayParam);
		}
	}

	/**
	 * Email 전송 및 history 등록
	 * */
	@Transactional(rollbackFor = Exception.class)
	public void sendSoCredtSttusInfoEmail( List<SoCredtSttusInfoVO> sttusInfo, String dayParam) throws Exception{
		log.debug("SorinCreditSttusInfoServiceImpl:sendSoCredtSttusInfoEmail (케이지크레딧 현황정보 전송 _ Email) Start" + sttusInfo.toString());

		DecimalFormat decFormat = new DecimalFormat("###,###");

		Map<String, String> mailMap = new HashMap<String, String>();
		Map<String, CommonCodeVO> csTelNo = commonCodeService.getSubCodesRetVo("SORIN_SETUP_CODE", "CS_TEL");

		SoCredtSttusInfoVO soCredtInfo = sttusInfo.get(0);
		mailMap.put("CS_TEL_NO", csTelNo.get("CS_TEL").getCodeDcone());						// 연락처
		mailMap.put("LAST_BSN_DE", dateformat(dayParam));									// 기준일
		mailMap.put("CDTLN_CNTRCT_NO", soCredtInfo.getCdtlnCntrctNo());						// 여신계약번호
		mailMap.put("CDTLN_NM", soCredtInfo.getCdtlnNm());									// 여신명
		mailMap.put("CDTLN_SCRITS_NO", soCredtInfo.getCdtlnScritsNo());						// 여신증권번호
		mailMap.put("CDTLN_AMOUNT", decFormat.format(soCredtInfo.getCdtlnAmount()));		// 계약금액
		mailMap.put("CDTLN_BEGIN_DE", dateformat(soCredtInfo.getCdtlnBeginDe()));			// 계약 시작일
		mailMap.put("CDTLN_END_DE", dateformat(soCredtInfo.getCdtlnEndDe()));				// 계약 종료일
		mailMap.put("SO_CREDT_ENTPRS_INFO_LIST", getSoCredtSttusInfoList(sttusInfo));		// 업체별 케이지크레딧 현황 정보

		log.warn("::: mailMap : "+ mailMap.toString());

		List<MailVO> param = new ArrayList<>();
		MailVO mail = new MailVO();

		/* mailVo 셋팅 */
		mail = mailMapper.selectMailTmpt(70);

		MailVO mailVo = new MailVO();
		mailVo.setMailTmptSeq(70);
		mailVo.setMailSendEmail(mail.getSntoEmail());
		mailVo.setMailSendUserId("system");
		param.add(mailVo);

		/* 메일 발송 */
		mailService.insertMailListSend(param, mailMap);

	}

	/**
	 * 업체별 케이지크레딧 현황 정보 html 리턴
	 * */
	public String getSoCredtSttusInfoList(List<SoCredtSttusInfoVO> sttusInfo) {
		StringBuilder builder = new StringBuilder();
		DecimalFormat decFormat = new DecimalFormat("###,###");

		long totalConfmAmount = 0; 			// 총계_부보확인금액
		long totalGrntyAmount = 0; 			// 총계_케이지부보금액
		long totalSorinUseAmount = 0;		// 총계_케이지사용금액
		long totalSorinUsePossAmount = 0; 	// 총계_사용가능금액
		String zero = "-";

		// html setting

		builder.append("<tr>");
		builder.append("<td height=\"40\" valign=\"middle\" align=\"center\" width=\"120\" style=\"height: 40px; background: #f1f1f1; vertical-align: middle; border-bottom: 1px solid #dedede; font-size: 12px; font-weight: bold;\">업체명</td>");
		builder.append("<td height=\"40\" valign=\"middle\" align=\"center\" width=\"90\" style=\"height: 40px; background: #f1f1f1; vertical-align: middle; border-bottom: 1px solid #dedede; font-size: 12px; font-weight: bold;\">사업자번호</td>");
		builder.append("<td height=\"40\" valign=\"middle\" align=\"center\" width=\"100\" style=\"height: 40px; background: #f1f1f1; vertical-align: middle; border-bottom: 1px solid #dedede; font-size: 12px; font-weight: bold;\">신청일자</td>");
		builder.append("<td height=\"40\" valign=\"middle\" align=\"center\" width=\"120\" style=\"height: 40px; background: #f1f1f1; vertical-align: middle; border-bottom: 1px solid #dedede; font-size: 12px; font-weight: bold;\">내부계약번호</td>");
		builder.append("<td height=\"40\" valign=\"middle\" align=\"center\" width=\"100\" style=\"height: 40px; background: #f1f1f1; vertical-align: middle; border-bottom: 1px solid #dedede; font-size: 12px; font-weight: bold;\">부보확인금액</td>");
		builder.append("<td height=\"40\" valign=\"middle\" align=\"center\" width=\"100\" style=\"height: 40px; background: #f1f1f1; vertical-align: middle; border-bottom: 1px solid #dedede; font-size: 12px; font-weight: bold;\">케이지부보금액</td>");
		builder.append("<td height=\"40\" valign=\"middle\" align=\"center\" width=\"100\" style=\"height: 40px; background: #f1f1f1; vertical-align: middle; border-bottom: 1px solid #dedede; font-size: 12px; font-weight: bold;\">케이지사용금액</td>");
		builder.append("<td height=\"40\" valign=\"middle\" align=\"center\" width=\"100\" style=\"height: 40px; background: #f1f1f1; vertical-align: middle; border-bottom: 1px solid #dedede; font-size: 12px; font-weight: bold;\">사용가능금액</td>");
		builder.append("</tr>");

		for(SoCredtSttusInfoVO vo : sttusInfo) {
			// 사용가능금액 setting
				vo.setSorinUsePossAmount(vo.getGrntyAmount() - vo.getSorinUseAmount());
	
				builder.append("<tr>");
				builder.append("<td align=\"center\" style=\"padding: 6px 0; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">" +vo.getEntrpsNm()+ "</td>");
				builder.append("<td align=\"center\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">" + bsnmRegistNoFormat(vo.getBsnmRegistNo()) + "</td>");
				builder.append("<td align=\"center\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">" + vo.getGrntyTmlmtBeginDe() + "</td>");
				builder.append("<td align=\"center\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">" + vo.getGrntyNo() + "</td>");
				builder.append("<td align=\"right\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">"+ decFormat.format(vo.getConfmAmount()) + "&nbsp;</td>");
				builder.append("<td align=\"right\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; font-weight: bold; line-height: 24px;\">" + decFormat.format(vo.getGrntyAmount()) + "&nbsp;</td>");
				if(vo.getSorinUseAmount() > 0) {
					builder.append("<td align=\"right\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #FD3535; font-size: 12px; line-height: 24px;\">" + decFormat.format(vo.getSorinUseAmount()) + "&nbsp;</td>");
				}else {
					builder.append("<td align=\"right\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #FD3535; font-size: 12px; line-height: 24px;\">" + zero + "&nbsp;</td>");
				}
				builder.append("<td align=\"right\" style=\"padding: 6px 0; border-bottom: 1px solid #e9e9e9; color: #FD3535; font-size: 12px; line-height: 24px;\">" + decFormat.format(vo.getSorinUsePossAmount()) + "&nbsp;</td>");
				builder.append("</tr>");
	
				totalConfmAmount += vo.getConfmAmount();
				totalGrntyAmount += vo.getGrntyAmount();
				totalSorinUseAmount += vo.getSorinUseAmount();
				totalSorinUsePossAmount += vo.getSorinUsePossAmount();
		}


		builder.append("<tr>");
		builder.append("<td align=\"center\" style=\"background: #E5F2FF; padding: 6px 0; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">총계</td>");
		builder.append("<td align=\"center\" style=\"background: #E5F2FF; padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"></td>");
		builder.append("<td align=\"center\" style=\"background: #E5F2FF; padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"></td>");
		builder.append("<td align=\"center\" style=\"background: #E5F2FF; padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"></td>");
		builder.append("<td align=\"right\" style=\"background: #E5F2FF; padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px;  font-weight: bold; line-height: 24px;\">" + decFormat.format(totalConfmAmount) + "&nbsp;</td>");
		builder.append("<td align=\"right\" style=\"background: #E5F2FF; padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px;  font-weight: bold; line-height: 24px;\">" + decFormat.format(totalGrntyAmount) + "&nbsp;</td>");
		builder.append("<td align=\"right\" style=\"background: #E5F2FF; padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px;  font-weight: bold; line-height: 24px;\">" + decFormat.format(totalSorinUseAmount) + "&nbsp;</td>");
		builder.append("<td align=\"right\" style=\"background: #E5F2FF; padding: 6px 0; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; font-weight: bold; line-height: 24px;\">" + decFormat.format(totalSorinUsePossAmount) + "&nbsp;</td>");
		builder.append("</tr>");

		return builder.toString();
	}

	public String dateformat(String date) {
		String format = date.substring(0,4) + "-" + date.substring(4,6) + "-" + date.substring(6,8);
		return format;
	}

	public String bsnmRegistNoFormat(String bsnmNo) {
		String format = bsnmNo.substring(0,3) + "-" + bsnmNo.substring(3,5) + "-" + bsnmNo.substring(5);
		return format;
	}
}