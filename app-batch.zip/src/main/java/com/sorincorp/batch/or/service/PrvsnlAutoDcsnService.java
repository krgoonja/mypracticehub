package com.sorincorp.batch.or.service;

import java.util.Map;

/**
 * PrvsnlAutoDcsnService.java
 * 가단가 자동 확정 배치 관련 Service 인터페이스
 * 
 * @version
 * @since 2024. 11. 6.
 * @author srec0049
 */
public interface PrvsnlAutoDcsnService {

	/**
	 * <pre>
	 * 처리내용: 가단가 자동 확정 배치 수행
	 * </pre>
	 * @date 2024. 11. 21.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 21.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param map
	 * @throws Exception
	 */
	public void updatePrvsnlAutoDcsn(Map<String, String> map) throws Exception;
}
