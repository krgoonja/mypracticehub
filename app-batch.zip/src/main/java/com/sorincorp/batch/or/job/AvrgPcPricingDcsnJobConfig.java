package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 평균가 프라이싱 확정 처리 배치
 * @version
 * @since 2023. 12. 7.
 * @author srec0053
 */
@Configuration
@EnableBatchProcessing
public class AvrgPcPricingDcsnJobConfig {
	
	@Autowired
	private AvrgPcPricingDcsnTasklet avrgPcPricingDcsnTasklet;
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job avrgPcPricingDcsnJob() {
		return jobBuilderFactory.get("avrgPcPricingDcsnJob").start(avrgPcPricingDcsnStep()).build();
	}

	@Bean
	@JobScope
	public Step avrgPcPricingDcsnStep() {
		return stepBuilderFactory.get("avrgPcPricingDcsnStep").tasklet(avrgPcPricingDcsnTasklet).build();
	}
}
