package com.sorincorp.batch.or.mapper;

import java.util.List;

import com.sorincorp.batch.or.model.PrvsnlAutoDcsnInfoVO;

/**
 * PrvsnlAutoDcsnMapper.java
 * 가단가 자동 확정 배치 관련 Mapper 인터페이스
 * 
 * @version
 * @since 2024. 11. 8.
 * @author srec0049
 */
public interface PrvsnlAutoDcsnMapper {

	/**
	 * <pre>
	 * 처리내용: 가단가 자동 확정 대상 리스트 가져오기
	 * </pre>
	 * @date 2024. 11. 8.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 8.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param prvsnlAutoDcsnInfoVO
	 * @return
	 * @throws Exception
	 */
	List<PrvsnlAutoDcsnInfoVO> selectPrvsnlAutoDcsnTargetList(PrvsnlAutoDcsnInfoVO prvsnlAutoDcsnInfoVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 가단가 자동 확정에 따른 지정가 취소 대상 가져오기
	 * </pre>
	 * @date 2024. 11. 8.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 8.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	PrvsnlAutoDcsnInfoVO selectPrvsnlLimitCancelTarget(String orderNo) throws Exception;
	
}
