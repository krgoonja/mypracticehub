package com.sorincorp.batch.or.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.or.service.SoCredtSttusInfoService;

import lombok.extern.slf4j.Slf4j;

/**
 * 월단위 서린트레딧 현황 정보 영업팀 메일 발송 batch Tasklet
 * SorinCreditSttusInfoTasklet.java
 * @version
 * @since 2022. 12. 09.
 * @author srec0076
 */
@Slf4j
@Component
public class SoCredtSttusInfoTasklet implements Tasklet, StepExecutionListener {
	
	@Autowired
	SoCredtSttusInfoService soCredtSttusInfoService;
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("SorinCreditSttusInfoTasklet::beforeStep");
	}//end beforeStep()
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("SorinCreditSttusInfoTasklet::execute Start");
		
		soCredtSttusInfoService.sendSoCredtSttusInfo();
		
		log.debug("SorinCreditSttusInfoTasklet::execute End");
		return RepeatStatus.FINISHED;
	}//end execute()
	
	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("SorinCreditSttusInfoTasklet::afterStep");
        return ExitStatus.COMPLETED;
	}//end afterStep()

}//end class()