package com.sorincorp.batch.or.service;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.or.mapper.PrvsnlPcChangegldRegistMapper;
import com.sorincorp.batch.or.model.OrPcChangegldBasVO;
import com.sorincorp.batch.or.model.PrvsnlPcChangegldInfoVO;
import com.sorincorp.comm.bsnInfo.model.RestTermVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.expectbeginpr.mapper.ExpectBeginPcMapper;
import com.sorincorp.comm.expectbeginpr.model.DcsnBeginPcVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.service.CommDashboardWebsocketService;
import com.sorincorp.comm.util.BsnInfoUtil;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * PrvsnlPcChangegldRegistServiceImpl.java
 * 가단가 가격 변동금 등록 배치 관련 Service 구현체 클래스
 * 
 * @version
 * @since 2024. 10. 30.
 * @author srec0049
 */
@Slf4j
@Service
public class PrvsnlPcChangegldRegistServiceImpl implements PrvsnlPcChangegldRegistService {

	/**
	 * 사이트 운영 설정 서비스
	 */
	@Autowired
	private BsnInfoService bsnInfoService;
	
	/**
     * 공통 서비스
     */
    @Autowired
    private CommonService commonService;
    
    /**
     * 공통 코드 서비스
     */
    @Autowired
    private CommonCodeService commonCodeService;
    
    /**
     * SMS 발송 서비스
     */
    @Autowired
    private SMSService smsService;
    
    /**
     * BO 지정가 주문정보 웹소켓 서비스
     */
    @Autowired
    private CommDashboardWebsocketService commDashboardWebsocketService;
    
	/**
	 * 시초가 관련 Mapper
	 */
	@Autowired
	ExpectBeginPcMapper expectBeginPcMapper;
	
	/**
	 * 가단가 가격 변동금 등록 배치 관련 Mapper
	 */
	@Autowired
	PrvsnlPcChangegldRegistMapper prvsnlPcChangegldRegistMapper;
	
	
	/**
	 * 가단가 가격 변동금 등록 배치 수행
	 */
	@Override
	public void insertPrvsnlPcChangegld(Map<String, String> map) throws Exception {
		
		//log.info(">> [PrvsnlPcChangegldRegistServiceImpl][insertPrvsnlPcChangegld] param : " + map.toString());
		
		PrvsnlPcChangegldInfoVO prvsnlPcChangegldInfoVO = new PrvsnlPcChangegldInfoVO();
		
		// 외부로 받은 파라미터로 주문 번호가 존재할 때 set 
		if(map.get("pOrderNo") != null) {
			prvsnlPcChangegldInfoVO.setOrderNo(String.valueOf(map.get("pOrderNo")));
		}
		// 외부로 받은 파라미터로 날짜가 존재할 때 set 
		String settingStrDate = "";
		if(map.get("pOccrrncDe") != null) {
			prvsnlPcChangegldInfoVO.setOccrrncDe(String.valueOf(map.get("pOccrrncDe")));
			SimpleDateFormat tempTime = new SimpleDateFormat("HH:mm:ss");
			settingStrDate = DateUtil.getFormatDate(prvsnlPcChangegldInfoVO.getOccrrncDe(), "yyyy-MM-dd") + " " + tempTime.format(new Date());
		} else {
			prvsnlPcChangegldInfoVO.setOccrrncDe(DateUtil.getNowDate());
			SimpleDateFormat currentDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			settingStrDate = currentDate.format(new Date());
		}
		// 외부로 받은 파라미터로 평가금액(시초가)가 존재할 때 set
		Long evlAmount = null; // 평가금액(시초가)
		if(map.get("pEvlAmount") != null) {
			evlAmount = Long.parseLong(String.valueOf(map.get("pEvlAmount")));
		}
		
		// 라이브 영업시간 리스트를 가져온다.
		List<RestTermVO> restDeLiveList = bsnInfoService.getRestTermInfoBySleMthd(prvsnlPcChangegldInfoVO.getOccrrncDe(), "01");
		
		// 가단가 가격 변동금 등록 대상 리스트 가져오기
		List<PrvsnlPcChangegldInfoVO> selectPrvsnlPcChangegldRegistTargetList = prvsnlPcChangegldRegistMapper.selectPrvsnlPcChangegldRegistTargetList(prvsnlPcChangegldInfoVO);
		for(PrvsnlPcChangegldInfoVO infoVO : selectPrvsnlPcChangegldRegistTargetList) {
			//log.info(">> infoVO : " + infoVO.toString());
			
			String metalCode = infoVO.getMetalCode(); // 금속코드
			
			Optional<RestTermVO> restDeLiveOp = Optional.ofNullable(restDeLiveList).orElse(Collections.emptyList())
					.stream()
					.filter(restTerm -> "N".equals(restTerm.getRestdeAt())
							&& metalCode.equals(restTerm.getMetalCode()) 
							&& BsnInfoUtil.OperateSttusCode.OPERATE_AT.getValues().contains(restTerm.getOpenTimeCode())
					)
					.findFirst();
			
			boolean restStatus = restDeLiveOp.isPresent(); // 영업시간 체크(true: 영업시간, false: 휴일)
			
			// 영업시간일 경우 진행
			if(restStatus) {
				Long beginPc = null; // 시초가
				
				// 외부로 받은 파라미터로 평가금액(시초가)가 있을 시
				if(evlAmount != null && evlAmount > 0) {
					beginPc = evlAmount; // 평가금액(시초가)
				} else {
					String applcBeginTime = restDeLiveOp.get().getApplcBeginTime(); // 영업 시작 시간 [ex) 100000]
					
					DcsnBeginPcVO expectBeginPcVoParam = new DcsnBeginPcVO();
					expectBeginPcVoParam.setApplcDe(prvsnlPcChangegldInfoVO.getOccrrncDe()); // 발생 일자 (YYYYMMDD)
					expectBeginPcVoParam.setSleMthdCode("01"); // 01 라이브로 처리
					expectBeginPcVoParam.setMetalCode(infoVO.getMetalCode());
					expectBeginPcVoParam.setItmSn(infoVO.getItmSn());
					expectBeginPcVoParam.setDstrctLclsfCode(infoVO.getDstrctLclsfCode());
					expectBeginPcVoParam.setBrandGroupCode(infoVO.getBrandGroupCode());
					expectBeginPcVoParam.setBrandCode(infoVO.getBrandCode());
					expectBeginPcVoParam.setValidBeginDt(prvsnlPcChangegldInfoVO.getOccrrncDe() + applcBeginTime);
					expectBeginPcVoParam.setValidEndDt(prvsnlPcChangegldInfoVO.getOccrrncDe() + applcBeginTime);
					// 해당 아이템의 시초가 조회 (최초 등록된 판매가격)
					DcsnBeginPcVO expectBeginPcVO = expectBeginPcMapper.selectDcsnBeginPc(expectBeginPcVoParam);
					
					if(expectBeginPcVO != null) {
						beginPc = expectBeginPcVO.getBeginPc(); // 평가금액(시초가)
					} else {
						log.warn(">> [PrvsnlPcChangegldRegistServiceImpl][insertPrvsnlPcChangegld] 시초가 객체가 존재하지 않음, " + String.valueOf(expectBeginPcVO));
					}
				}
				
				// 평가금액(시초가가 존재할 때 배치 수행
				if(beginPc != null) {
					//log.info(">> orderNo : " + infoVO.getOrderNo());
					//log.info(">> beginPc : " + beginPc);
					
					
					String setleMthdCode = infoVO.getSetleMthdCode(); // 결제 방식 코드
					String lqdTrgetExclAt = infoVO.getLqdTrgetExclAt(); // 청산 대상 제외 여부
					
					//log.info(">> setleMthdCode : " + setleMthdCode);
					//log.info(">> lqdTrgetExclAt : " + lqdTrgetExclAt);
					
					// 마지막 주문_가격 변동금 정보 가져오기
					OrPcChangegldBasVO selectLastPcChangegldInfo = prvsnlPcChangegldRegistMapper.selectLastPcChangegldInfo(infoVO);
					//log.info(">> selectLastPcChangegldInfo : " + String.valueOf(selectLastPcChangegldInfo));
					
					// 발생한 일자가 동일할 경우 작업을 막는다, 변동금 발생은 같은 날짜에 하나
					if(selectLastPcChangegldInfo != null && StringUtils.equals(prvsnlPcChangegldInfoVO.getOccrrncDe(), selectLastPcChangegldInfo.getOccrrncDe())) {
						log.warn("발생 일자가 동일합니다, (신규: " + prvsnlPcChangegldInfoVO.getOccrrncDe() + ", 존재: " + selectLastPcChangegldInfo.getOccrrncDe() + ")");
						return;
					}
					
					
					long occrrncSn = 0; // 발생 순번
					long frstUntpcStdrPrePayAmount = 0; // 최초 단가 기준 기 납입 금액
					long frstPrePayAmount = 0; // 최초 기 납입 금액
					long untpcStdrPrePayAmount = 0; // 단가 기준 기 납입 금액
					long prePayAmount = 0; // 기 납입 금액
					
					// 마지막 주문_가격 변동금 정보가 존재할 때
					if(selectLastPcChangegldInfo != null) {
						//log.info(">> selectLastPcChangegldInfo is not null");
						
						occrrncSn = selectLastPcChangegldInfo.getOccrrncSn() + 1; // 신규 발생 순번
						frstUntpcStdrPrePayAmount = selectLastPcChangegldInfo.getUntpcStdrPrePayAmount(); // 최초 단가 기준 기 납입 금액에 단가 기준 기 납입 금액 넣기
						frstPrePayAmount = selectLastPcChangegldInfo.getPrePayAmount(); // 최초 기 납입 금액에 기 납입 금액 넣기
						untpcStdrPrePayAmount = selectLastPcChangegldInfo.getUntpcStdrPrePayAmount(); // 단가 기준 기 납입 금액
						prePayAmount = selectLastPcChangegldInfo.getPrePayAmount(); // 기 납입 금액
					} else {
						occrrncSn = 1; // 발생 순번
					}
					
					long mntncChangeAmount = infoVO.getMntncChangeAmount(); // 유지 변동 금액
					long changeUntpc = (infoVO.getAvrgpcGoodsUntpc() + infoVO.getFrstPcChangeAmount() + untpcStdrPrePayAmount) - beginPc; // 변동 단가
					long pcChangegldTrans = beginPc - (infoVO.getAvrgpcGoodsUntpc() + infoVO.getFrstPcChangeAmount()); // 변동 단가 추이
					long tempChangeUntpc = pcChangegldTrans < 0 ? 0 : pcChangegldTrans; // 계산용 변동 단가 (변동 단가 추이가 0보다 작으면 0)
					double dcsnChangeStep = Math.ceil(Double.parseDouble(String.valueOf(tempChangeUntpc)) / Double.parseDouble(String.valueOf(mntncChangeAmount))); // 확정 변동 단계
					long dcsnChangeUntpc = ((new Double(dcsnChangeStep).longValue()) * mntncChangeAmount) - untpcStdrPrePayAmount; // 확정 변동 단가
					long rcppayTrgetAmount = dcsnChangeUntpc * infoVO.getTotRealOrderWt(); // 입출금 대상 금액
					
//					log.info(">> mntncChangeAmount : " + mntncChangeAmount);
//					log.info(">> pcChangegldTrans : " + pcChangegldTrans);
//					log.info(">> tempChangeUntpc : " + tempChangeUntpc);
//					log.info(">> dcsnChangeStep : " + dcsnChangeStep);
//					log.info(">> dcsnChangeUntpc : " + dcsnChangeUntpc);
//					log.info(">> rcppayTrgetAmount : " + rcppayTrgetAmount);
					
					// 가격 변동금 상태 코드 [10(입금 요망), 20(입금 완료), 30(입금 취소), 40(출금 대상), 50(출금 완료), 60(출금 취소), 70(여신 차감), 80(여신 상환)]
					String pcChangegldSttusCode = "";
					
					if(StringUtils.equals("10", setleMthdCode)) {
						// 이월렛일 경우
						
						// 전일 변동금 정보가 출금대상일 경우 출금취소 시키고 금일 변동금 정보를 출금대상으로 등록한다.
						if(selectLastPcChangegldInfo != null && StringUtils.equals("40", selectLastPcChangegldInfo.getPcChangegldSttusCode())) {
							// 전일 변동금 정보 출금취소
							OrPcChangegldBasVO updateVO = new OrPcChangegldBasVO();
							updateVO.setOrderNo(infoVO.getOrderNo()); // 주문 번호
							updateVO.setOccrrncSn(selectLastPcChangegldInfo.getOccrrncSn()); // 발생 순번
							updateVO.setPcChangegldSttusCode("60"); // 가격 변동금 상태 코드, 60(출금취소)
							updateVO.setLastChangeDt(settingStrDate); // 최종 변경 일시
							// 해당 가단가 가격 변동금 정보 수정  (주문_가격 변동금 기본 테이블), 가격 변동금 상태 코드를 60(출금취소)로 변경한다.
							prvsnlPcChangegldRegistMapper.updateOrPcChangegldBasByPrvsnl(updateVO);
							
							// OR_PC_CHANGEGLD_BAS(주문_가격 변동금 기본) 이력 등록
							commonService.insertTableHistory("OR_PC_CHANGEGLD_BAS", updateVO);
						} else {
							// 청산 대상 제외 여부가 Y이고, 입금요망일 경우 입금취소 시키고 금일 변동금 정보를 입금요망으로 등록한다. ==> 2024-11-21 청산 대상 제외 여부 조건 제거
							//if(StringUtils.equals("Y", lqdTrgetExclAt) && selectLastPcChangegldInfo != null && StringUtils.equals("10", selectLastPcChangegldInfo.getPcChangegldSttusCode())) {
							if(selectLastPcChangegldInfo != null && StringUtils.equals("10", selectLastPcChangegldInfo.getPcChangegldSttusCode())) {
								// 전일 변동금 정보 입금취소
								//selectLastPcChangegldInfo.getOccrrncSn()
								OrPcChangegldBasVO updateVO = new OrPcChangegldBasVO();
								updateVO.setOrderNo(infoVO.getOrderNo()); // 주문 번호
								updateVO.setOccrrncSn(selectLastPcChangegldInfo.getOccrrncSn()); // 발생 순번
								updateVO.setPcChangegldSttusCode("30"); // 가격 변동금 상태 코드, 30(입금취소)
								updateVO.setLastChangeDt(settingStrDate); // 최종 변경 일시
								// 해당 가단가 가격 변동금 정보 수정  (주문_가격 변동금 기본 테이블), 가격 변동금 상태 코드를 30(입금취소)로 변경한다.
								prvsnlPcChangegldRegistMapper.updateOrPcChangegldBasByPrvsnl(updateVO);
								
								// OR_PC_CHANGEGLD_BAS(주문_가격 변동금 기본) 이력 등록
								commonService.insertTableHistory("OR_PC_CHANGEGLD_BAS", updateVO);
							}
						}
						
						if(dcsnChangeUntpc == 0) {
							pcChangegldSttusCode = ""; // 가격 변동금 상태 코드
						} else if(dcsnChangeUntpc > 0) {
							pcChangegldSttusCode = "10"; // 가격 변동금 상태 코드, 입금요망
						} else if(dcsnChangeUntpc < 0) {
							pcChangegldSttusCode = "40"; // 가격 변동금 상태 코드, 출금대상
						}
						
						OrPcChangegldBasVO insertVO = new OrPcChangegldBasVO();
						insertVO.setOrderNo(infoVO.getOrderNo()); // 주문 번호
						insertVO.setOccrrncSn(occrrncSn); // 발생 순번
						insertVO.setOccrrncDt(settingStrDate); // 발생 일시
						insertVO.setEvlAmount(beginPc); // 평가 금액 (시초가)
						insertVO.setPcChangegldSttusCode(pcChangegldSttusCode); // 가격 변동금 상태 코드
						insertVO.setFrstUntpcStdrPrePayAmount(frstUntpcStdrPrePayAmount); // 최초 단가 기준 기 납입 금액
						insertVO.setFrstPrePayAmount(frstPrePayAmount); // 최초 기 납입 금액
						insertVO.setUntpcStdrPrePayAmount(untpcStdrPrePayAmount); // 단가 기준 기 납입 금액
						insertVO.setPrePayAmount(prePayAmount); // 기 납입 금액
						insertVO.setChangeUntpc(changeUntpc); // 변동 단가
						insertVO.setDcsnChangeUntpc(Math.abs(dcsnChangeUntpc)); // 확정 변동 단가 (절대값)
						insertVO.setRcppayTrgetAmount(Math.abs(rcppayTrgetAmount)); // 입출금 대상 금액 (절대값)
						insertVO.setLqdTrgetExclAt(lqdTrgetExclAt); // 청산 대상 제외 여부
						insertVO.setFrstRegistDt(settingStrDate); // 최초 등록 일시
						insertVO.setLastChangeDt(settingStrDate); // 최종 변경 일시
						// 가격 변동금 정보 등록 (주문_가격 변동금 기본 테이블)
						prvsnlPcChangegldRegistMapper.insertOrPcChangegldBasByPrvsnl(insertVO);
						
						// OR_PC_CHANGEGLD_BAS(주문_가격 변동금 기본) 이력 등록
						commonService.insertTableHistory("OR_PC_CHANGEGLD_BAS", insertVO);
						
						// 이월렛 - 가단가 구매 변동금 추가/환불 SMS 호출
						if(pcChangegldSttusCode != null && !StringUtils.equals("", pcChangegldSttusCode)) {
							insertVO.setSetleMthdCode(setleMthdCode); // 결제 방식 코드
							insertVO.setOccrrncDe(prvsnlPcChangegldInfoVO.getOccrrncDe()); // 발생일자 (평가일자)
							insertVO.setAvrgpcGoodsUntpc(infoVO.getAvrgpcGoodsUntpc()); // 평균가 상품 단가 (가단가)
							insertVO.setFrstPcChangeAmount(infoVO.getFrstPcChangeAmount()); // 최초 가격 변동 금액 (최초변동금)
							// 합계 : 가단가 + 최초변동금 + 추가변동금(단가 기준 기 납입 금액[이월렛일 경우 입금, 출금 이벤트 후 판단하기때문에 단가 기준 기 납입 금액 사용])
							insertVO.setTotalChangeAmount(infoVO.getAvrgpcGoodsUntpc() + infoVO.getFrstPcChangeAmount() + untpcStdrPrePayAmount);
							
							// 가단가 구매 변동금 추가/환불 SMS 호출
							this.callPrvsnlPcChangegldProcSms(insertVO);
						}
						
					} else if(StringUtils.equals("20", setleMthdCode) || StringUtils.equals("40", setleMthdCode)) {
						// 여신 (전자상거래보증 또는 케이지크레딧)일 경우
						
						String mrtggDelngTyCode = ""; // 담보 거래 유형 코드
						String mrtggSumry = ""; // 담보 적요
						String mrtggKindNm = ""; // 여신 종류
						
						switch(setleMthdCode) {
							case "20" : mrtggKindNm = "전자상거래보증"; break;
							case "40" : mrtggKindNm = "케이지크레딧"; break;
						}
						
						if(dcsnChangeUntpc == 0) {
							pcChangegldSttusCode = ""; // 가격 변동금 상태 코드
						} else if(dcsnChangeUntpc > 0) {
							pcChangegldSttusCode = "70"; // 가격 변동금 상태 코드, 여신차감
							mrtggDelngTyCode = "02"; // 담보 거래 유형 코드, 02(주문)
							mrtggSumry = "주문(" + mrtggKindNm + ")"; // 담보 적요
						} else if(dcsnChangeUntpc < 0) {
							pcChangegldSttusCode = "80"; // 가격 변동금 상태 코드, 여신상환
							mrtggDelngTyCode = "03"; // 담보 거래 유형 코드, 03(상환)
							mrtggSumry = "상환(" + mrtggKindNm + ")"; // 담보 적요
						}
						
						OrPcChangegldBasVO insertVO = new OrPcChangegldBasVO();
						insertVO.setOrderNo(infoVO.getOrderNo()); // 주문 번호
						insertVO.setOccrrncSn(occrrncSn); // 발생 순번
						insertVO.setOccrrncDt(settingStrDate); // 발생 일시
						insertVO.setEvlAmount(beginPc); // 평가 금액 (시초가)
						insertVO.setPcChangegldSttusCode(pcChangegldSttusCode); // 가격 변동금 상태 코드
						insertVO.setFrstUntpcStdrPrePayAmount(frstUntpcStdrPrePayAmount); // 최초 단가 기준 기 납입 금액
						insertVO.setFrstPrePayAmount(frstPrePayAmount); // 최초 기 납입 금액
						insertVO.setUntpcStdrPrePayAmount(untpcStdrPrePayAmount + dcsnChangeUntpc); // 단가 기준 기 납입 금액
						insertVO.setPrePayAmount(prePayAmount + rcppayTrgetAmount); // 기 납입 금액
						insertVO.setChangeUntpc(changeUntpc); // 변동 단가
						insertVO.setDcsnChangeUntpc(Math.abs(dcsnChangeUntpc)); // 확정 변동 단가 (절대값)
						insertVO.setRcppayTrgetAmount(Math.abs(rcppayTrgetAmount)); // 입출금 대상 금액 (절대값)
						insertVO.setLqdTrgetExclAt(lqdTrgetExclAt); // 청산 대상 제외 여부
						insertVO.setFrstRegistDt(settingStrDate); // 최초 등록 일시
						insertVO.setLastChangeDt(settingStrDate); // 최종 변경 일시
						// 가격 변동금 정보 등록 (주문_가격 변동금 기본 테이블)
						prvsnlPcChangegldRegistMapper.insertOrPcChangegldBasByPrvsnl(insertVO);
						
						// OR_PC_CHANGEGLD_BAS(주문_가격 변동금 기본) 이력 등록
						commonService.insertTableHistory("OR_PC_CHANGEGLD_BAS", insertVO);
						
						// 가격 변동금 상태가 존재할 때
						if(pcChangegldSttusCode != null && !StringUtils.equals("", pcChangegldSttusCode)) {
							insertVO.setMrtggDelngTyCode(mrtggDelngTyCode); // 담보 거래 유형 코드
							insertVO.setMrtggSumry(mrtggSumry); // 담보 적요
							insertVO.setMrtggDelngAmount(Math.abs(rcppayTrgetAmount)); // 담보 거래 금액
							// 가격 변동금 내역 회원_업체 담보 한도 상세 등록, 담보 차감 및 상환 처리 (회원_업체 담보 한도 상세 테이블)
							prvsnlPcChangegldRegistMapper.insertLastMbEntrpsMrtggLmtDtl(insertVO);
							
							//log.info(">> 담보 차감 및 상환 후 잔액 결과 : " + insertVO.getMrtggBlce());
							
							// 여신 - 가단가 구매 변동금 추가/환불 SMS 호출
							insertVO.setSetleMthdCode(setleMthdCode); // 결제 방식 코드
							insertVO.setOccrrncDe(prvsnlPcChangegldInfoVO.getOccrrncDe()); // 발생일자 (평가일자)
							insertVO.setAvrgpcGoodsUntpc(infoVO.getAvrgpcGoodsUntpc()); // 평균가 상품 단가 (가단가)
							insertVO.setFrstPcChangeAmount(infoVO.getFrstPcChangeAmount()); // 최초 가격 변동 금액 (최초변동금)
							// 합계 : 가단가 + 최초변동금 + 추가변동금(최초 단가 기준 기 납입 금액[여신일 경우 판단하고 바로 차감, 상환되기때문에 최초 단가 기준 기 납입 금액 사용])
							insertVO.setTotalChangeAmount(infoVO.getAvrgpcGoodsUntpc() + infoVO.getFrstPcChangeAmount() + frstUntpcStdrPrePayAmount);
							
							// 가단가 구매 변동금 추가/환불 SMS 호출
							this.callPrvsnlPcChangegldProcSms(insertVO);
						}
					}
					
					// 가격 변동금 입금관련 이벤트 websocket publish, BO 대시보드 변동금 입금 대상 목록 갱신
					commDashboardWebsocketService.publishRcpmnyEvent(infoVO.getOrderNo(), true);
					
				} else {
					log.warn(">> [PrvsnlPcChangegldRegistServiceImpl][insertPrvsnlPcChangegld] 시초가가 존재하지 않음");
				}
			}
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 가단가 구매 변동금 추가/환불 SMS 호출
	 * </pre>
	 * @date 2024. 11. 15.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 15.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orPcChangegldBasVO
	 */
	private void callPrvsnlPcChangegldProcSms(OrPcChangegldBasVO orPcChangegldBasVO) {
		try {
			// 가단가 구매 변동금 추가/환불 SMS 내용 정보 가져오기
			Map<String, String> smsMap = prvsnlPcChangegldRegistMapper.selectPrvsnlPcChangegldSmsInfo(orPcChangegldBasVO);
			
			smsMap.put("templateNum", "151"); // 템플릿 번호
			
			String setleMthdCode = orPcChangegldBasVO.getSetleMthdCode(); // 결제 방식 코드
			
			// 평가 영역
            StringBuilder evlArea = new StringBuilder();
            evlArea.append("가단가 : ").append(String.valueOf(smsMap.get("avrgpcGoodsUntpc"))).append(System.lineSeparator()); // 가단가 (평균가 상품 단가)
            evlArea.append("최초변동금 : ").append(String.valueOf(smsMap.get("frstPcChangeAmount"))).append(System.lineSeparator()); // 최초변동금 (최초 가격 변동 금액)
            
            if(StringUtils.equals("10", setleMthdCode)) {
	            String untpcStdrPrePayAmount = String.valueOf(smsMap.get("untpcStdrPrePayAmount"));
	            if(StringUtils.isNotEmpty(untpcStdrPrePayAmount) && !untpcStdrPrePayAmount.equals("null")) {
	            	evlArea.append("추가변동금 : ").append(untpcStdrPrePayAmount).append(System.lineSeparator()); // 추가변동금 (단가 기준 기 납입 금액)
	            }
            } else if(StringUtils.equals("20", setleMthdCode) || StringUtils.equals("40", setleMthdCode)) {
            	String frstUntpcStdrPrePayAmount = String.valueOf(smsMap.get("frstUntpcStdrPrePayAmount"));
	            if(StringUtils.isNotEmpty(frstUntpcStdrPrePayAmount) && !frstUntpcStdrPrePayAmount.equals("null")) {
	            	evlArea.append("추가변동금 : ").append(frstUntpcStdrPrePayAmount).append(System.lineSeparator()); // 추가변동금 (최초 단가 기준 기 납입 금액)
	            }
            }
            
            evlArea.append("합계 : ").append(String.valueOf(smsMap.get("totalChangeAmount"))).append(System.lineSeparator()); // 합계 (가단가 + 최초변동금 + 추가변동금)
            evlArea.append("시초가 : ").append(String.valueOf(smsMap.get("evlAmount"))).append(System.lineSeparator()); // 시초가
            evlArea.append("평가 : ").append(String.valueOf(smsMap.get("changeUntpc"))); // 평가 (변동 단가)
            
            smsMap.put("evlArea", evlArea.toString()); // 평가 영역
            evlArea = null; // StringBuilder 메모리 해제 유도
            
            // 변동금 내역 영역
            StringBuilder changeGldArea = new StringBuilder();
            changeGldArea.append("확정변동단가 : ").append(String.valueOf(smsMap.get("dcsnChangeUntpc"))).append(System.lineSeparator()); // 확정변동단가
            
            String pcChangegldSttusCode = orPcChangegldBasVO.getPcChangegldSttusCode(); // 가격 변동금 상태 코드
            
            if(StringUtils.equals("10", setleMthdCode)) {
            	// 이월렛일 경우
            	switch(pcChangegldSttusCode) {
	            	case "10" : 
	            		// 입금요망
	            		changeGldArea.append("입금 요망 금액 : ").append(String.valueOf(smsMap.get("rcppayTrgetAmount"))).append(System.lineSeparator()); // 입출금 대상 금액
	            		changeGldArea.append(System.lineSeparator());
	            		changeGldArea.append("위 금액을 당일 17:00 까지 입금하여 주십시오.(미입금시 17:00분에 단가 확정 됩니다.)").append(System.lineSeparator());
	            		break;
	            	case "40" : 
	            		// 출금대상
	            		changeGldArea.append("출금 가능 금액 : ").append(String.valueOf(smsMap.get("rcppayTrgetAmount"))).append(System.lineSeparator()); // 입출금 대상 금액
	            		changeGldArea.append(System.lineSeparator());
	            		changeGldArea.append("위 금액은 출금 가능합니다.(미출금시에는 정산 시점에 자동 환불 처리 됩니다.)").append(System.lineSeparator());
	            		break;
            	}
            } else if(StringUtils.equals("20", setleMthdCode) || StringUtils.equals("40", setleMthdCode)) {
            	// 여신 (전자상거래보증 또는 케이지크레딧)일 경우
            	changeGldArea.append("여신 변동 금액 : ").append(String.valueOf(smsMap.get("rcppayTrgetAmount"))).append(System.lineSeparator()); // 입출금 대상 금액
            	changeGldArea.append("현재 잔여 여신 금액 : ").append(String.valueOf(smsMap.get("mrtggBlce"))).append(System.lineSeparator()); // 담보 잔액
            	
            	switch(pcChangegldSttusCode) {
	            	case "70" : 
	            		// 여신차감
	            		changeGldArea.append(System.lineSeparator());
	            		changeGldArea.append("위 금액을 케이지크레딧으로 자동 차감 하였습니다.").append(System.lineSeparator());
	            		break;
	            	case "80" : 
	            		// 여신상환
	            		changeGldArea.append(System.lineSeparator());
	            		changeGldArea.append("위 금액을 케이지크레딧으로 자동 상환 하였습니다.").append(System.lineSeparator());
	            		break;
	        	}
            }
            
            smsMap.put("changeGldArea", changeGldArea.toString()); // 변동금 내역 영역
            changeGldArea = null; // StringBuilder 메모리 해제 유도
            
            
            Map<String, CommonCodeVO> csTelNo = commonCodeService.getSubCodesRetVo("SORIN_SETUP_CODE", "CS_TEL");
            smsMap.put("csTelNo", csTelNo.get("CS_TEL").getCodeDcone()); // 고객센터번호
			
			SMSVO smsVO = new SMSVO();
            smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
            smsVO.setMberNo(String.valueOf(smsMap.get("mberNo"))); // 회원 번호
            
            String phone = String.valueOf(smsMap.get("ordrrMoblphonNo"));
            if(StringUtils.isNotEmpty(phone) && !phone.equals("null")) {
                try {
                    log.debug("휴대전화 번호 복호화 전 ==================>" + phone);
                    phone = CryptoUtil.decryptAES256(phone);
                    log.debug("휴대전화 번호 복호화 후 ==================>" + phone);
                    /** 휴대전화 번호 셋팅 **/
                    smsVO.setPhone(phone);
                } catch(Exception e) {
                    log.error("PrvsnlPcChangegldRegistServiceImpl callPrvsnlPcChangegldProcSms ORDRR_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
                }
            }
            
            // SMS 또는 LMS 발송 및 알림톡 발송
            smsService.insertSMS(smsVO, smsMap);
			
		} catch(Exception e) {
			log.error("[PrvsnlPcChangegldRegistServiceImpl][callPrvsnlPcChangegldProcSms] " + ExceptionUtils.getStackTrace(e));
		}
	}
}
