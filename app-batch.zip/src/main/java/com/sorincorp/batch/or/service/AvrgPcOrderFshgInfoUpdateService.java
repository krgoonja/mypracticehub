package com.sorincorp.batch.or.service;

public interface AvrgPcOrderFshgInfoUpdateService {
	/**
	 * <pre>
	 * 처리내용: 평균가 주문 선물환 정보 update
	 * </pre>
	 * @date 2024. 2. 6.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 2. 6.			srec0053			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	void updateAvrgPcOrderFshgInfo() throws Exception;
}
