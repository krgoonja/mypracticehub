package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * IfGfxFrtsInfoDeleteJobConfig.java
 * @version
 * @since 2023. 2. 17.
 * @author srec0066
 */
@Configuration
@EnableBatchProcessing
public class IfGfxFrtsInfoDeleteJobConfig {

	@Autowired
	private IfGfxFrtsInfoDeleteTasklet ifGfxFrtsInfoDeleteTasklet;

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job ifGfxFrtsInfoDeleteJob() {
		return jobBuilderFactory.get("ifGfxFrtsInfoDeleteJob").start(ifGfxFrtsInfoDeleteStep()).build();
	}

	@Bean
	@JobScope
	public Step ifGfxFrtsInfoDeleteStep() {
		return stepBuilderFactory.get("ifGfxFrtsInfoDeleteStep").tasklet(ifGfxFrtsInfoDeleteTasklet).build();
	}

}
