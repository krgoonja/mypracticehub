package com.sorincorp.batch.or.service;

/**
 * 
 * 세금계산서 발행완료 btobi 수신 Batch Service.java
 * @version
 * @since 2021. 9. 2.
 * @author srec0054
 */
public interface TaxBillRecptnService {
	
	/**
	 * 
	 * <pre>
	 * 세금계산서 발행완료 btobi 수신
	 * </pre>
	 * @date 2021. 9. 2.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 2.			srec0054			최초작성
	 * ------------------------------------------------
	 */
	void saveTaxBillRecptn() throws Exception;
	
}//end interface()
