package com.sorincorp.batch.or.service;

import java.math.BigDecimal;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.batch.or.mapper.EstmtPurchsMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AvrgPcOrderFshgInfoUpdateServiceImpl implements AvrgPcOrderFshgInfoUpdateService {
	@Autowired
	private EstmtPurchsMapper estmtPurchsMapper;
	
	@Autowired
	private ObjectMapper objectMapper;

	@Override
	public void updateAvrgPcOrderFshgInfo() throws Exception {
		// 최신 매매 기준율 데이터 조회
		Map<String, Object> latestGtxApiFxrate = estmtPurchsMapper.selectLatestGtxApiFxrate();
		
		log.info("최신 매매 기준율 데이터 : {}", objectMapper.writeValueAsString(latestGtxApiFxrate));
		
		// 평균가 주문 선물환 정보 업데이트 대상 날짜(yyMMdd) 조회
		String targetDate = estmtPurchsMapper.selectAvrgPcOrderFshgInfoUpdateTarget();
		
		log.info("업데이트 대상 날짜(yyMMdd) : {}", targetDate);
		
		double usdCvtrate = ((BigDecimal)latestGtxApiFxrate.get("USD_CVTRATE")).doubleValue();
		
		int result = estmtPurchsMapper.updateAvrgPcOrderFshgInfo(usdCvtrate, targetDate);
		
		log.info("UPDATE 처리된 ROW 갯수 : {}", result);
	}

}
