package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 평균가 결제기한 처리 배치
 * @version
 * @since 2023. 12. 7.
 * @author srec0053
 */
@Configuration
@EnableBatchProcessing
public class AvrgPcSetleTmlmtJobConfig {
	
	@Autowired
	private AvrgPcSetleTmlmtTastlet avrgPcSetleTmlmtTastlet;
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job avrgPcSetleTmlmtJob() {
		return jobBuilderFactory.get("avrgPcSetleTmlmtJob").start(avrgPcSetleTmlmtStep()).build();
	}

	@Bean
	@JobScope
	public Step avrgPcSetleTmlmtStep() {
		return stepBuilderFactory.get("avrgPcSetleTmlmtStep").tasklet(avrgPcSetleTmlmtTastlet).build();
	}
}
