package com.sorincorp.batch.or.job;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.or.service.EstmtPurchsService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
//@Transactional(value = "batchTransactionManager")
public class AvrgLmeCspTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	EstmtPurchsService estmtPurchsService;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("AvrgLmeCspTasklet::beforeStep");
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("AvrgLmeCspTasklet::afterStep");
        return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.info("AvrgLmeCspTasklet::execute Start");
		try {

			JobParameters jobParameters = chunkContext.getStepContext().getStepExecution().getJobParameters();
			Map<String, JobParameter> jobParamMap = jobParameters.getParameters();
			JobParameter param = jobParamMap.get("param01");
			Map<String, String> commandOption = getParseOptions(param.toString());
			log.info("commandOption :[{}]", commandOption.toString());

			String nowDate = DateUtil.getNowDate();
			String retry = commandOption.get("retry");
			String orderNos = commandOption.get("orderNos");
			String occrrncMt = commandOption.get("occrrncMt");

			if(StringUtils.isNotBlank(orderNos)) {			// 특정 주문번호를 대상으로 기동 시, 단가 확정 처리 서비스만 실행
				estmtPurchsService.executeAvrgUntpcDcsn(orderNos);
			} else if(StringUtils.equals(retry, "Y")											// 재처리를 위한 기동 시, 영업일 체크를 안하고 실행
					|| estmtPurchsService.isFirstOrLastBusinessDayOfMonth(nowDate, "FIRST")) {	// 기동일이 영업일 기준 월 초일 경우에만 실행
				estmtPurchsService.executeBfeMtAvrgLmeCsp(occrrncMt);
				
				estmtPurchsService.executeAvrgUntpcDcsn(null);
			}

			log.info("AvrgLmeCspTasklet::execute End");
		} catch(Exception e) {
			throw new RuntimeException("Rollback test", e);
		}

		return RepeatStatus.FINISHED;
	}


	/*
	 * 젠키스에서 28-31 실행되는 동안 현재월의 마지막 날짜 체크
	 */
//	private boolean getLastDateOfMonth(String yyyyMMdd) {
//		String year = yyyyMMdd.substring(0,4);
//		String month = yyyyMMdd.substring(4,6);
//
//		Calendar cal = Calendar.getInstance();
//		cal.set(Integer.parseInt(year),Integer.parseInt(month)-1,1);
//
//		String lastDay = year+month+Integer.toString(cal.getActualMaximum(Calendar.DAY_OF_MONTH));
//
//		log.info("currentday::{}, lastdayOfMonth::{}", yyyyMMdd, lastDay);
//
//		return yyyyMMdd.equals(lastDay);
//	}

	/*
	 * 젠킨스 커맨드라인에서 받은 문자열 파싱
	 */
	private Map<String, String> getParseOptions(String param) {
		log.info("getParseOptions ========> receive param: [{}]", param);
		Map<String, String> map = new HashMap<String, String>();
		if(StringUtils.isEmpty(param)) {
			return map;
		}

		String options[] = param.split(":");

		if (options != null && options.length > 0) {
            for (String option : options) {
                if (option.contains("=")) {
                    String key = option.substring(0, option.indexOf("="));
                    String value = option.substring(option.lastIndexOf("=") + 1).toUpperCase();
                    map.put(key, value);
                }
            }
        }
        return map;
	}

//	public static void main(String[] args) {
//		AvrgLmeCspTasklet tester = new AvrgLmeCspTasklet();
//		Map<String, String> map = tester.getParseOptions("chekLastOfMonth=Y&occrrncMt=&executeTimePoint=Last");
//		System.out.println("map >>>>>" + map);
//
//		String nowDate = DateUtil.getNowDate();
//		boolean isLastDayOfMonth = tester.getLastDateOfMonth(nowDate);
//		System.out.println("isLastDayOfMonth >>>>>" + isLastDayOfMonth);
//	}
}
