package com.sorincorp.batch.or.service;

public interface AvrgPcEstmtCntrctService {

	void selectEstmtTmlmtEndDtList() throws Exception;

	void executeEstmtCntrctTmlmtEnd() throws Exception;
}
