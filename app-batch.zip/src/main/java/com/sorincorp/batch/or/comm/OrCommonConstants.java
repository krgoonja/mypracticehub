package com.sorincorp.batch.or.comm;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Getter;

@Getter
@Component
public class OrCommonConstants {

	/** 삼성선물 계좌번호 **/
	@Value("${order.samsung.acnut}")
	private String samsungAcnutNo;

	/** 이베스트증권 계좌번호 **/
	@Value("${order.ebest.acnut}")
	private String ebestAcnutNo;

	/** 삼성선물 타임아웃 **/
	@Value("${order.samsung.timeoutsec}")
	private int samsungTimeoutsec;

	/** 삼성선물 주문 타입 **/
	@Value("${order.samsung.ordertype}")
	private String samsungOrdertype;

	/** 삼성선물 클레임 url **/
	@Value("${order.api.samsung.claim.url}")
	private String samsungClaimUrl;

	/** 삼성선물 취소 url **/
	@Value("${order.api.samsung.cancel.url}")
	private String samsungCancelUrl;

	/** 선물환 주문 url **/
	@Value("${order.api.fx.claim.url}")
	private String fxOrderClaimUrl;

	/** ewallet 주문 url **/
	@Value("${order.api.ewallet.order.url}")
	private String ewalletOrderUrl;

	/** 세금계산서 url **/
	@Value("${order.api.taxbill.url}")
	private String taxbillUrl;

	/** 이월렛 타임아웃 **/
	@Value("${order.ewallet.timeoutsec}")
	private int ewalletTimeoutsec;

	/** oms 송신 url **/
	@Value("${order.api.lo.url}")
	private String loOmsUrl;

	/** 매매계약서 취소 url **/
	@Value("${credit.lon.cancl.url}")
	private String lonCanclApiUrl;
}
