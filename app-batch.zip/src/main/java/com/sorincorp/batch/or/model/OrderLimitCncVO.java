package com.sorincorp.batch.or.model;

import lombok.Data;

@Data
public class OrderLimitCncVO {

    private String time;

}