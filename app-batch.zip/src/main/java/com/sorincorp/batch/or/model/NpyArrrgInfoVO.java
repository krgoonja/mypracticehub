package com.sorincorp.batch.or.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 결제예정액 관리 NpyArrrgInfoVO.java
 * @version
 * @since 2023. 01. 20.
 * @author srec0076
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class NpyArrrgInfoVO extends CommonVO {

	private static final long serialVersionUID = 6882956165304862133L;

	/******  JAVA VO CREATE : OR_ORDER_BAS(주문_주문 기본)                                                                                   ******/
	/**
     * 순번
    */
    private String rownum;
    
    /**
     * 결제 상태
     * */
    private String baseSetleSttus;
    
    /**
     * 결제 종류
     * */
    private String setleKnd;
    
    /**
     * 결제 예정일
     */
    private String baseSetlePrearngeDe;
    
    /**
     * 판매가격
     * */
    private long slepc;
    
	/**
     * 주문 번호
    */
    private String orderNo;
   
    /**
     * 입금액
    */
    private long setleAmount;
    
    /**
     * 입금일시
     * */
    private String setleComptDt; 
    
    /**
     * 결제 방식 코드
    */
    private String setleMthdCode;
   
    /**
     * 결제 방식 상세 코드
    */
    private String setleMthdDetailCode;
   
    /**
     * 최초 결제 금액
    */
    private long frstSetleAmount;
  
    /**
     * 미 결제 금액
    */
    private long unSetleAmount;
   
    /**
     * 업체 번호
    */
    private String entrpsNo;
    
    /**
     * 주문 업체 명
    */
    private String orderEntrpsNm;
    
    /**
     * 주문 상태 코드
    */
    private String orderSttusCode;
    
    /**
     * 금속 코드
    */
    private String metalCode;
    
    /**
     * 금속 코드명
    */
    private String metalCodeNm;
    
    /**
     * 주문 완료 일시
    */
    private String orderComptDt;
    
    /**
     * 여신 상환 일수
     * */
    private String cdtlnRepyDaycnt;

    /**
     * 탬플릿 번호
     * */
    private int templateNum;

    /**
     * 결제 예정 목록 순번
    */
    private String scheduledRownum;

    /**
     * 미납/연체 목록 순번
    */
    private String unpaidRownum;
    
    /**
     * 총 실제 주문 중량
    */
    private Integer totRealOrderWt;
    
    /**
     * 확정 중량
     */
    private double totDcsnWt;
    
    /**
     * 평균가 상품 단가
     */
    private long avrgpcGoodsUntpc;
    
    /**
     * 상품 단가
     */
    private long goodsUntpc;
    
}
