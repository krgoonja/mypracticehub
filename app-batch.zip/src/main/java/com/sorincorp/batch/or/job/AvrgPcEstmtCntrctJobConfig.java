package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class AvrgPcEstmtCntrctJobConfig {

	@Autowired
	AvrgPcEstmtCntrctTasklet avrgPcEstmtCntrctTasklet;

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job avrgPcEstmtCntrctJob() {
		return jobBuilderFactory.get("avrgPcEstmtCntrctJob").start(avrgPcEstmtCntrctTaskletStep()).build();
	}

	@Bean
	@JobScope
	public Step avrgPcEstmtCntrctTaskletStep() {
		return stepBuilderFactory.get("avrgPcEstmtCntrctTaskletStep").tasklet(avrgPcEstmtCntrctTasklet).build();
	}
}
