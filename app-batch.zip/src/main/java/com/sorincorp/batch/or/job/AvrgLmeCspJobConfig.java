package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * 이전월의 누적 평균 LME CSP를 구하는 배치 JobConfig
 * @since 2023. 11. 06
 * @author srec0070
 */
@Configuration
@EnableBatchProcessing
public class AvrgLmeCspJobConfig {

	@Autowired
	private AvrgLmeCspTasklet avrgLmeCspTasklet;

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

//    @Autowired
//    @Qualifier("batchTransactionManager")
//    private PlatformTransactionManager batchTransactionManager;

	@Bean
	public Job avrgLmeCspJob() {
		return jobBuilderFactory.get("avrgLmeCspJob").start(avrgLmeCspStep()).build();
	}

	@Bean
	@JobScope
	public Step avrgLmeCspStep() {
		return stepBuilderFactory.get("avrgLmeCspStep")
								.tasklet(avrgLmeCspTasklet)
//								.transactionManager(batchTransactionManager)
								.build();
	}

}
