package com.sorincorp.batch.or.model;

import lombok.Data;

/**
 * PrvsnlPcChangegldRealarmInfoVO.java
 * 가단가 변동금 재알람 정보 VO 객체
 * 
 * @version
 * @since 2024. 11. 21.
 * @author srec0049
 */
@Data
public class PrvsnlPcChangegldRealarmInfoVO {

	/**
	 * 주문 번호
	 */
	private String orderNo;
	
	/**
	 * 주문 일자
	 */
	private String orderDe;
	
	/**
	 * 결제 방식 코드
	 */
	private String setleMthdCode;
	
	/**
	 * 금속 코드
	 */
	private String metalCode;
	
	/**
	 * 평균가 상품 단가
	 */
	private long avrgpcGoodsUntpc;
	
	/**
	 * 최초 가격 변동 금액
	 */
	private long frstPcChangeAmount;
	
	/**
	 * 발생 일자 (YYYYMMDD)
	 */
	private String occrrncDe;
	
	/**
     * 가격 변동금 상태 코드
     */
    private String pcChangegldSttusCode;
    
    /**
     * 단가 기준 기 납입 금액
     */
    private long untpcStdrPrePayAmount;
    
    /**
     * 평가 금액
     */
    private long evlAmount;
    
    /**
     * 변동 단가
     */
    private long changeUntpc;
    
    /**
     * 확정 변동 단가
     */
    private long dcsnChangeUntpc;
    
    /**
     * 입출금 대상 금액
     */
    private long rcppayTrgetAmount;
}
