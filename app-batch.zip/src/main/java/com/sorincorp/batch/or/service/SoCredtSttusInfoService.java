package com.sorincorp.batch.or.service;

/**
 * 월단위 서린트레딧 현황 정보 영업팀 메일 발송 batch Service
 * SorinCreditSttusInfoService.java
 * @version
 * @since 2022. 12. 09.
 * @author srec0076
 */
public interface SoCredtSttusInfoService {
	
	/**
	 * 
	 * <pre>
	 * 월 단위 서린크렛딧 현황 정보 메일 발송
	 * </pre>
	 * @date 2022. 12. 9
	 * @author srec0076
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 9.			srec0076			최초작성
	 * ------------------------------------------------
	 */
	void sendSoCredtSttusInfo() throws Exception;
	
}