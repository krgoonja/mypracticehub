package com.sorincorp.batch.or.mapper;

import java.util.List;

import com.sorincorp.batch.or.model.AvrgPcEstmtCntrctVO;

public interface AvrgPcEstmtCntrctMapper {

	List<AvrgPcEstmtCntrctVO> selectEstmtTmlmtEndDtList(AvrgPcEstmtCntrctVO param) throws Exception;

	int updateEstmtCntrctTmlmtEndSttusCode(AvrgPcEstmtCntrctVO param) throws Exception;

	void insertCnEstmtBasHst(AvrgPcEstmtCntrctVO param) throws Exception;
}
