package com.sorincorp.batch.or.mapper;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.sorincorp.batch.or.model.ClaimBasVO;
import com.sorincorp.batch.or.model.ClaimDtlVO;
import com.sorincorp.batch.or.model.OrSetleBasVO;
import com.sorincorp.batch.or.model.OrderFtrsBasVO;
import com.sorincorp.batch.or.model.BatchOrderModel;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;

public interface ClaimMapper {

	/**
	 * <pre>
	 * 클레임 대상 목록 조회
	 * </pre>
	 * @date 2021. 10. 28.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 28.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param searchMap
	 * @return
	 */
	List<ClaimBasVO> selectListEwalletTarget(Map<String, Object> searchMap) throws Exception;

	/**
	 * <pre>
	 * 주문 결제 기본 등록
	 * </pre>
	 * @date 2021. 10. 28.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 28.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orSetleBasVo
	 * @return
	 */
	int insertEwalletSetle(OrSetleBasVO orSetleBasVo) throws Exception;

	/**
	 * <pre>
	 * 주문 결제 기본 이력 등록
	 * </pre>
	 * @date 2021. 10. 28.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 28.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orSetleBasVo
	 * @return
	 */
	int insertEwalletSetleHst(OrSetleBasVO orSetleBasVo) throws Exception;

	/**
	 * <pre>
	 * 클레임 완료 처리
	 * </pre>
	 * @date 2021. 11. 17.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 17.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orSetleBasVo
	 * @return
	 */
	int updateComplateClaim(ClaimBasVO vo) throws Exception;

	/**
	 * <pre>
	 * 클레임 완료 처리 이력 등록
	 * </pre>
	 * @date 2021. 11. 30.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 30.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int insertOrCanclExchngRtngudBasHst(ClaimBasVO vo) throws Exception;

	/**
	 * <pre>
	 * 이월렛 or 세금계산서 실패 사유 등록
	 * </pre>
	 * @date 2021. 11. 17.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 17.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orSetleBasVo
	 */
	int updateFailClaim(ClaimBasVO vo) throws Exception;

	/**
	 *
	 * <pre>
	 * 이월렛 호출 API 응답코드 확인
	 * </pre>
	 * @date 2021. 11. 30.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 30.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param delngSeqNo
	 * @return
	 */
	String selectEwalletRspnCode(String delngSeqNo);

	/**
	 *
	 * <pre>
	 * 처리내용: 주문취소 건 등록한다.
	 * </pre>
	 * @date 2022. 9. 7.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 7.			srec0070			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	int insertOrCanclExchngRtngudBas(ClaimBasVO param) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 주문_취소 교환 반품 상세 정보를 등록한다.
	 * </pre>
	 * @date 2022. 9. 7.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 7.			srec0070			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	int insertOrCanclExchngRtngudDtl(ClaimDtlVO param) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 주문_취소 교환 반품 상세이력 정보를 등록한다.
	 * </pre>
	 * @date 2022. 9. 7.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 7.			srec0070			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	int insertOrCanclExchngRtngudDtlHst(ClaimDtlVO param) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 주문_취소 교환 반품 상세 테이블과 연결된 BL 정보를 조회한다.
	 * </pre>
	 * @date 2022. 9. 26.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 26.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	List<ClaimDtlVO> getClaimBlList(ClaimBasVO param) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 상품 BL 정보를 조회한다.
	 * </pre>
	 * @date 2022. 9. 26.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 26.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param bl
	 * @return
	 * @throws Exception
	 */
	ItemPriceMatchingBlInfoVO getItBlInfo(ClaimDtlVO bl) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 고정가는 할증요율 조회한다.
	 * </pre>
	 * @date 2022. 9. 28.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 28.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @return
	 * @throws Exception
	 */
	BigDecimal selectTotAmtTariff(BatchOrderModel batchOrderModel) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 주문_취소 교환 반품 기본 (OR_CANCL_EXCHNG_RTNGUD_BAS) 테이블 수정
	 * </pre>
	 * @date 2022. 9. 21.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 21.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	int updateLastClaimMaster(ClaimBasVO param) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 주문_주문 기본(OR_ORDER_BAS) 테이블 상태 수정
	 * </pre>
	 * @date 2022. 9. 21.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 21.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	int updateLastOrderMaster(BatchOrderModel param) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 주문_주문 기본(OR_ORDER_BAS)의 이력 데이터 등록
	 * </pre>
	 * @date 2023. 01. 30.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 21.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	int insertOrOrderBasHst(BatchOrderModel param) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 삼성선물로 부터의 응답결과인 증거금 취소 주문 내역을 조회한다.
	 * </pre>
	 * @date 2022. 9. 30.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 30.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	List<OrderFtrsBasVO> selectClaimOrderFtrsResponse(BatchOrderModel param) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 삼성선물로 부터의 응답결과중 인 증거금 취소 주문 성공 건수를 조회한다.
	 * </pre>
	 * @date 2023. 1. 5.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 1. 5.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param claimDtl
	 * @return
	 * @throws Exception
	 */
	int selectClaimOrderFtrsOkCount(ClaimDtlVO claimDtl) throws Exception;
}
