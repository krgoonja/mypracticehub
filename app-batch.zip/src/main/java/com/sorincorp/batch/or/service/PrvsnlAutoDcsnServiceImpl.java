package com.sorincorp.batch.or.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.or.mapper.PrvsnlAutoDcsnMapper;
import com.sorincorp.batch.or.model.PrvsnlAutoDcsnInfoVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.order.model.CommPrvsnlDcsnInfoVO;
import com.sorincorp.comm.order.service.CommFrontOrderWebsocketService;
import com.sorincorp.comm.order.service.CommPrvsnlOrderService;

import lombok.extern.slf4j.Slf4j;

/**
 * PrvsnlAutoDcsnServiceImpl.java
 * 가단가 자동 확정 배치 관련 Service 구현체 클래스
 * 
 * @version
 * @since 2024. 11. 6.
 * @author srec0049
 */
@Slf4j
@Service
public class PrvsnlAutoDcsnServiceImpl implements PrvsnlAutoDcsnService {

	/**
	 * 사이트 운영 설정 서비스
	 */
	@Autowired
	private BsnInfoService bsnInfoService;
	
	/**
	 *  FO 웹소켓 Service
	 */
	@Autowired
	private CommFrontOrderWebsocketService commFrontOrderWebsocketService;
	
	/**
	 * 가단가 주문 공통 Service 
	 */
	@Autowired
	CommPrvsnlOrderService commPrvsnlOrderService;
	
	/**
	 * 가단가 자동 확정 배치 관련 Mapper
	 */
	@Autowired
	PrvsnlAutoDcsnMapper prvsnlAutoDcsnMapper;
	
	
	/**
	 * 가단가 자동 확정 배치
	 */
	@Override
	public void updatePrvsnlAutoDcsn(Map<String, String> map) throws Exception {
		//log.info(">> PrvsnlAutoDcsnServiceImpl updatePrvsnlAutoDcsn in param : " + map.toString());
		
		PrvsnlAutoDcsnInfoVO prvsnlAutoDcsnInfoVO = new PrvsnlAutoDcsnInfoVO();
		
		// 외부로 받은 파라미터로 주문 번호가 존재할 때 set 
		if(map.get("pOrderNo") != null) {
			prvsnlAutoDcsnInfoVO.setOrderNo(String.valueOf(map.get("pOrderNo")));
		}
		
		
		// 가단가 자동 확정 대상 리스트 가져오기
		List<PrvsnlAutoDcsnInfoVO> selectPrvsnlAutoDcsnTargetList = prvsnlAutoDcsnMapper.selectPrvsnlAutoDcsnTargetList(prvsnlAutoDcsnInfoVO);
		for(PrvsnlAutoDcsnInfoVO infoVO : selectPrvsnlAutoDcsnTargetList) {
			//log.info(">> infoVO : " + infoVO.toString());
			
			String orderNo = infoVO.getOrderNo(); // 주문 번호
			String metalCode = infoVO.getMetalCode(); // 금속 코드
			
			// 영업시간 체크
	        boolean restdeYn = bsnInfoService.isRestDeByMetal(metalCode,  "01");
	        if(!restdeYn) {
	        	log.warn("영업시간이 아닙니다.");
				return;
	        }
	        
			// 가단가 자동 확정에 따른 지정가 취소 대상 가져오기
			PrvsnlAutoDcsnInfoVO selectPrvsnlLimitCancelTarget = Optional.ofNullable(prvsnlAutoDcsnMapper.selectPrvsnlLimitCancelTarget(orderNo)).orElse(new PrvsnlAutoDcsnInfoVO());
			
			// 주문 번호에 대한 공통 가단가 확정 여부 정보 가져오기
			CommPrvsnlDcsnInfoVO getPrvsnlDcsnAtInfo = commPrvsnlOrderService.getPrvsnlDcsnAtInfo(orderNo);
			//log.info(">> getPrvsnlDcsnAtInfo : " + String.valueOf(getPrvsnlDcsnAtInfo));
			
			
			//분리 미확정 untpcSepratDcsnAt=Y CommPrvsnlDcsnInfoVO(orderNo=20241113-S01912, untpcDcsnProcAt=N, untpcDcsnAt=N, singlDcsnCd=null, lmeDcsnCd=null, fxDcsnCd=null) section=smtm
			//분리 LME만 확정 untpcSepratDcsnAt=Y CommPrvsnlDcsnInfoVO(orderNo=20241016-S01811, untpcDcsnProcAt=N, untpcDcsnAt=N, singlDcsnCd=null, lmeDcsnCd=LIVE_DCSN, fxDcsnCd=null) section=fx
			//분리 확정 나올수없음
			//분리 FX만 확정 untpcSepratDcsnAt=Y CommPrvsnlDcsnInfoVO(orderNo=20241111-S01884, untpcDcsnProcAt=N, untpcDcsnAt=N, singlDcsnCd=null, lmeDcsnCd=null, fxDcsnCd=LIVE_DCSN) section=lme
			//단일(단가) 미확정 untpcSepratDcsnAt=N CommPrvsnlDcsnInfoVO(orderNo=20241016-S01812, untpcDcsnProcAt=N, untpcDcsnAt=N, singlDcsnCd=null, lmeDcsnCd=null, fxDcsnCd=null) section=singl
			//단일(단가) 확정 나올수없음
			
			String section = "";
			switch(infoVO.getUntpcSepratDcsnAt()) {
				case "Y" : 
					// 분리 확정
					
					boolean lmeDcsnStatus = false; // LME 확정 여부 (true: 확정, false: 미확정)
					if(getPrvsnlDcsnAtInfo.getLmeDcsnCd() != null && getPrvsnlDcsnAtInfo.getLmeDcsnCd().indexOf("DCSN") > -1) {
						lmeDcsnStatus = true;
					}
					
					boolean fxDcsnStatus = false; // FX 확정 여부 (true: 확정, false: 미확정)
					if(getPrvsnlDcsnAtInfo.getFxDcsnCd() != null && getPrvsnlDcsnAtInfo.getFxDcsnCd().indexOf("DCSN") > -1) {
						fxDcsnStatus = true;
					}
					
					if(!lmeDcsnStatus && !fxDcsnStatus) {
						// LME, FX 모두 미확정 (분리 미확정)
						section = "smtm"; // 동시확정 처리
					} else if(!lmeDcsnStatus && fxDcsnStatus) {
						// LME 미확정, FX 확정 (분리 LME 확정)
						section = "lme"; // LME 분리확정
					} else if(lmeDcsnStatus && !fxDcsnStatus) {
						// LME 확정, FX 미확정 (분리 FX 확정)
						section = "fx"; // FX 분리확정
					}
					
					break;
				case "N" : 
					// 단일(단가) 확정
					
					boolean singlDcsnStatus = false; // 단일(단가) 확정 여부 (true: 확정, false: 미확정)
					if(getPrvsnlDcsnAtInfo.getSinglDcsnCd() != null && getPrvsnlDcsnAtInfo.getSinglDcsnCd().indexOf("DCSN") > -1) {
						singlDcsnStatus = true;
					}
					if(!singlDcsnStatus) {
						// 단일(단가) 미확정
						section = "singl"; // 단일(단가)확정 처리
					}
					
					break;
			}
			
			//log.info(">> section : " + section);
			
			if(section == "") {
				log.warn("처리불가 가단가 확정(section 빈값)");
			} else {
				Map<String, Object> param = new HashMap<String, Object>();
				param.put("onlyRefresh", "N"); // 단가확정하기 모달창 갱신만 할 것인지, 단가확정하고 갱신할 것인지 여부 [Y: 단가확정하기 모달창 화면만 갱신, N: 단가확정 후 단가확정하기 모달창 화면 갱신]
				param.put("orderNo", infoVO.getOrderNo()); // 주문 번호
				param.put("section", section); // 가단가 확정 - 구분 [lme: LME 분리확정, fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]
				param.put("sttusCode", "I"); // 가단가 확정 - 상태 코드 [I: 등록, U: 수정, D: 취소]
				param.put("mberNo", infoVO.getMberNo()); // 회원 번호
				param.put("mberId", "BATCH");
				
				if(selectPrvsnlLimitCancelTarget != null) {
					if(selectPrvsnlLimitCancelTarget.getLimitLmeOrderNo() != null) {
						param.put("limitLmeOrderNo", selectPrvsnlLimitCancelTarget.getLimitLmeOrderNo()); // LME 지정가 주문 번호
					}
					if(selectPrvsnlLimitCancelTarget.getLimitEhgtOrderNo() != null) {
						param.put("limitEhgtOrderNo", selectPrvsnlLimitCancelTarget.getLimitEhgtOrderNo()); // 환율 지정가 주문 번호
					}
					if(selectPrvsnlLimitCancelTarget.getLimitKrwOrderNo() != null) {
						param.put("limitKrwOrderNo", selectPrvsnlLimitCancelTarget.getLimitKrwOrderNo()); // KRW 지정가 주문 번호
					}
				}
				
				// 가단가 확정하기 정보 websocket publish, 가단가 자동 확정하기
				commFrontOrderWebsocketService.publishPrvsnlDcsn(param);
			}
		}
	}
	
}
