package com.sorincorp.batch.or.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel("케이지크레딧 현황 정보 VO")
public class SoCredtSttusInfoVO {
	
	/**
	 * 여신 계약 번호
	 */
	private String cdtlnCntrctNo;
	
	/**
	 * 여신 증권 번호
	 */
	private String cdtlnScritsNo;
	
	/**
	 * 여신 명
	 */
	private String cdtlnNm;
	
	/**
	 * 계약 금액
	 * */
	private long cdtlnAmount;
	
	/**
	 * 여신 기한 시작 일자(계약 시작일)
	 */
	private String cdtlnBeginDe;
	
	/**
	 * 여신 기한 종료 일자(계약 종료일)
	 */
	private String cdtlnEndDe;
	
	/**
	 * 업체명
	 */
	private String entrpsNm;
	
	/**
	 * 사업자 등록 번호
	 */
	private String bsnmRegistNo;
	
	/**
	 * 보증 기한 시작 일자(계약 신청일)
	 */
	private String grntyTmlmtBeginDe;
	
	/**
	 * 보증 번호(계약번호)
	 */
	private String grntyNo;
	
	/**
	 * 승인 금액(부보 확인 금액)
	 */
	private long confmAmount;
	
	/**
	 * 보증 금액(케이지 부보 금액)
	 */
	private long grntyAmount ;
	
	/**
	 * 케이지트레이딩 사용 금액
	 */
	private long sorinUseAmount;
	
	/**
	 * 케이지트레이딩 사용 가능 금액
	 */
	private long sorinUsePossAmount;
	
}
