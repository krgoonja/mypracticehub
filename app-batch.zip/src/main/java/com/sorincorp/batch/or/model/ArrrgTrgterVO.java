package com.sorincorp.batch.or.model;

import lombok.Data;

/**
 * 미납대상자 관리 ArrrgTrgterVO.java
 */
@Data
public class ArrrgTrgterVO {

	/**
     * 순번
    */
    private String rownum;
	/**
     * 주문 번호
    */
    private String orderNo;

    /**
     * 상세 순번
    */
    private long detailSn;

    /**
     * 미납 처리 유형 코드
    */
    private String npyProcessTyCode;
    /**
     * 미납 처리 유형
    */
    private String npyProcessTy;

    /**
     * 메시지 발송 이력 번호
    */
    private int mssageSndngHistNo;
   /**
     * 이메일 발송 이력 번호
    */
    private int emailSndngHistNo;

    /**
     * 주문자 명
    */
    private String ordrrNm;

    /**
     * 주문자 휴대폰 번호
    */
    private String ordrrMoblphonNo;
   /**
     * 주문자 이메일
    */
    private String ordrrEmail;

    /**
     * CS 담당자 ID
    */
    private String csChargerId;
    /**
     * CS 담당자
    */
    private String csChargerNm;
    /**
     * 처리 내용
    */
    private String processCn;
   /**
     * 처리 일시
    */
    private String processDt;

    /**
 	 * 고객 연락처
    */
    private String ordrrInfo;






//    /**
//     * 회원 번호
//    */
//    private String mberNo;
//   /**
//     * 업체 번호
//    */
//    private String entrpsNo;
//    /**
//     * 판매 방식 코드
//    */
//    private String sleMthdCode;
//
//
//   /**
//     * 주문 업체 명
//    */
//    private String orderEntrpsNm;
//    /**
//     * 주문 상태 코드
//    */
//    private String orderSttusCode;
//    /**
//     * 결제 방식 코드
//    */
//    private String setleMthdCode;
//   /**
//     * 결제 방식 상세 코드
//    */
//    private String setleMthdDetailCode;
//   /**
//     * 최초 결제 금액
//    */
//    private long frstSetleAmount;
//   /**
//     * 미 결제 금액
//    */
//    private long unSetleAmount;
//    /**
//     * 증거금 결제 예정 일자
//    */
//    private String wrtmSetlePrearngeDe;
//    /**
//     * 결제 예정일
//     */
//    private String setlePrearngeDe;
//    /**
//     * 연체 시작일
//     */
//    private String arrrgBgnde;
//    /**
//     * 연체 일수
//     */
//    private String arrrgDaycnt;
//    /**
//     * 연체 이자율
//     */
//    private String arrrgIntrt;
//    /**
//     * 연체 이자액
//     */
//    private long arrrgIntrAmount;
//    /**
//     *  결제 상태
//     */
//    private String setleSttus;
//    /**
//     * 결제 종류
//     */
//    private String setleKnd;
//    /**
//     * Grid 상태
//     */
//	private String gridRowStatus;
//	/**
//	 * modalPageStatus 상태
//	 */
//	private String modalPageStatus;
//	/**
//	 * 주문일자
//	 */
//	private String orderDe;
//
//	/******  JAVA VO CREATE : OR_NPY_ORDER_MANAGE_BAS(주문_미납 주문 관리 기본)                                                              ******/
//
//
//
//
//
//   /**
//    * 삭제 여부
//   */
//   private String deleteAt;
//   /**
//    * 삭제 일시
//   */
//   private java.sql.Timestamp deleteDt;
//   /**
//    * 최초 등록자 아이디
//   */
//   private String frstRegisterId;
//   /**
//    * 최초 등록 일시
//   */
//   private java.sql.Timestamp frstRegistDt;
//   /**
//    * 최종 변경자 아이디
//   */
//   private String lastChangerId;
//   /**
//    * 최종 변경 일시
//   */
//   private java.sql.Timestamp lastChangeDt;
//   /**
//    * 전화 처리여부
//   */
//   private String tlphonProcessAt;
//   /**
//    * 이메일 처리여부
//   */
//   private String emailProcessAt;
//   /**
//    * SMS 처리여부
//   */
//   private String smsProcessAt;
//   /**
//    * 총 처리여부
//   */
//   private String totProcessAt;
//
//   /**
//	 *  그리드 아이템인덱스
//	*/
//   private String itemIndex;
//
//	/***	이메일/메세지 템플릿 관련		***/
//	/**
//     * 메시지 템플릿 번호
//    */
//    private int tmplatNo;
//    /**
//     * 발신자 전화번호
//    */
//    private String sntoTelno;
//    /**
//     * 발신자 이메일
//    */
//    private String sntoEmail;
//    /**
//     * 템플릿 제목
//    */
//    private String tmplatSj;
//    /**
//     * 템플릿 내용
//    */
//    private String tmplatCn;
}
