package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class WrtmOrderCnclJobConfig {

	@Autowired
	private WrtmOrderCnclTasklet wrtmCnclTasklet;

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job wrtmOrderCnclJob() {
		return jobBuilderFactory.get("wrtmOrderCnclJob").start(wrtmOrderCnclStep()).build();
	}

	@Bean
	@JobScope
	public Step wrtmOrderCnclStep() {
		return stepBuilderFactory.get("wrtmOrderCnclStep").tasklet(wrtmCnclTasklet).build();
	}
}
