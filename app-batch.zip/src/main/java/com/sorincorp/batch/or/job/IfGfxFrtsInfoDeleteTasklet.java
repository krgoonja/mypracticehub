package com.sorincorp.batch.or.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.or.service.IfGfxFrtsInfoDeleteService;

import lombok.extern.slf4j.Slf4j;

/**
 * IfGfxFrtsInfoDeleteTasklet.java
 * @version
 * @since 2023. 2. 17.
 * @author srec0066
 */
@Slf4j
@Component
public class IfGfxFrtsInfoDeleteTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	private IfGfxFrtsInfoDeleteService ifGfxFrtsInfoDeleteService;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("IfGfxFrtsInfoDeleteTasklet::beforeStep");
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("IfGfxFrtsInfoDeleteTasklet::afterStep");
		return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("IfGfxFrtsInfoDeleteTasklet::Start");

		ifGfxFrtsInfoDeleteService.deleteIfGfxFrtsInfo();

		log.debug("IfGfxFrtsInfoDeleteTasklet::End");
		return RepeatStatus.FINISHED;
	}

}
