package com.sorincorp.batch.or.job;

import java.util.Map;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.or.service.OrderLimitCncService;

import lombok.extern.slf4j.Slf4j;

/**
 * 대기중인 지정가 주문 취소 배치 Tasklet
 * @since 2023. 4. 19
 * @author srec0051
 */
@Slf4j
@Component
public class OrderLimitCncTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	OrderLimitCncService orderLimitCncService;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("OrderLimitCncTasklet::beforeStep");
	}//end beforeStep()

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("OrderLimitCncTasklet::execute Start");
		JobParameters jobParameters = chunkContext.getStepContext().getStepExecution().getJobParameters();
		Map<String, JobParameter> jobParamMap = jobParameters.getParameters();
		JobParameter param = jobParamMap.get("param01");
		String time = null;
		if (param != null) {
			time = param.toString();
		}
		orderLimitCncService.cancelPendingOrders(time);
		log.debug("OrderLimitCncTasklet::execute End");
		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("OrderLimitCncTasklet::afterStep");
        return ExitStatus.COMPLETED;
	}

}
