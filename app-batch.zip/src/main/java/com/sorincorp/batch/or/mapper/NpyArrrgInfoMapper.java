package com.sorincorp.batch.or.mapper;

import java.util.List;

import com.sorincorp.batch.or.model.NpyArrrgInfoVO;

public interface NpyArrrgInfoMapper {


	/**
	 * <pre>
	 * 주말, 공휴일 확인
	 * </pre>
	 * @date 2023. 01. 20
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 01. 20.	  srec0076			    최초작성
	 * ------------------------------------------------
	 * @return
	 */
	int selectLastBsnDe()throws Exception;
	
	
	/**
	 * <pre>
	 * 당일 기준 결제예정 및 미납/연체 내역 조회 
	 * </pre>
	 * @date 2023. 01. 20
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 01. 20.	   srec0076			     최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<NpyArrrgInfoVO> selectNpyArrrgInfoList()throws Exception;
	
}
