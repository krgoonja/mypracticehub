package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 세금계산서 발행요청 btobi 수신 배치 JobConfig
 * TaxBillRecptnJobConfig.java
 * @version
 * @since 2021. 9. 14.
 * @author srec0054
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class TaxBillRecptnJobConfig {
	
	@Autowired
	TaxBillRecptnTasklet taxBillRecptnTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory; 
	
	@Bean
	public Job taxBillRecptnJob() {
		return jobBuilderFactory.get("taxBillRecptnJob")
				.start(taxBillRecptnStep())
				.build();  
	}//end taxBillRecptnJob()
	
	@Bean
	@JobScope
	public Step taxBillRecptnStep() {
		return stepBuilderFactory.get("taxBillRecptnStep")
				.tasklet(taxBillRecptnTasklet)
				.build();
	}//end taxBillRecptnStep()
	
}//end class()
