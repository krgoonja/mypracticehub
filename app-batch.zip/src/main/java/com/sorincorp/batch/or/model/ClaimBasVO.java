package com.sorincorp.batch.or.model;

import lombok.Data;

@Data
public class ClaimBasVO {
	/******  JAVA VO CREATE : OR_CANCL_EXCHNG_RTNGUD_BAS(주문_취소 교환 반품 기본)                                                           ******/
	/**
	* 주문 번호*/
	private String orderNo;
	/**
	* 취소 교환 반품 번호*/
	private String canclExchngRtngudNo;
	/**
	* 회원 번호*/
	private String mberNo;
	/**
	* 업체 번호*/
	private String entrpsNo;
	/**
	* 취소 교환 반품 유형 코드*/
	private String canclExchngRtngudTyCode;
	/**
	* 취소 교환 반품 상태 코드*/
	private String canclExchngRtngudSttusCode;
	/**
	* 취소 교환 반품 사유 코드*/
	private String canclExchngRtngudResnCode;
	/**
	* 취소 교환 반품 사유 설명*/
	private String canclExchngRtngudResnDc;
	/**
	* 취소 교환 반품 동의 여부*/
	private String canclExchngRtngudAgreAt;
	/**
	* 반품 교환 회수 예정 일자*/
	private java.sql.Date rtngudExchngRtrvlPrearngeDe;
	/**
	* 총 취소 교환 반품 중량*/
	private int totCanclExchngRtngudWt;
	/**
	* 총 취소 교환 반품 번들 수량*/
	private int totCanclExchngRtngudBundleQy;
	/**
	* 총 취소 교환 반품 확정 중량*/
	private java.math.BigDecimal totCanclExchngRtngudDcsnWt;
	/**
	* 취소 주문 배송비 번호*/
	private String cnclOrderDlvrfNo;
	/**
	* 전체 부분 여부*/
	private String allPartAt;
	/**
	* 판매 가격 실시간 순번*/
	private String slePcRltmSn;
	/**
	* LME 가격 실시간 순번*/
	private String lmePcRltmSn;
	/**
	* 프리미엄 번호*/
	private String premiumNo;
	/**
	* 환율 가격 실시간 순번*/
	private String ehgtPcRltmSn;
	/**
	* 프리미엄 기준 금액*/
	private java.math.BigDecimal premiumStdrAmount;
	/**
	* 권역 변동 금액*/
	private java.math.BigDecimal dstrctChangeAmount;
	/**
	* 고정가 권역 변동 금액*/
	private java.math.BigDecimal hghnetprcDstrctChangeAmount;
	/**
	* 브랜드 그룹 변동 금액*/
	private java.math.BigDecimal brandGroupChangeAmount;
	/**
	* 고정가 브랜드 그룹 변동 금액*/
	private java.math.BigDecimal hghnetprcBrandGroupChangeAmount;
	/**
	* 브랜드 변동 금액*/
	private java.math.BigDecimal brandChangeAmount;
	/**
	* 고정가 브랜드 변동 금액*/
	private java.math.BigDecimal hghnetprcBrandChangeAmount;
	/**
	* 프리미엄 가격*/
	private java.math.BigDecimal premiumPc;
	/**
	* LME 3M*/
	private java.math.BigDecimal lme3m;
	/**
	* LME 현금*/
	private java.math.BigDecimal lmeCash;
	/**
	* LME 조정 계수*/
	private java.math.BigDecimal lmeMdatCffcnt;
	/**
	* 현물환*/
	private java.math.BigDecimal spex;
	/**
	* 현물환 조정 계수*/
	private java.math.BigDecimal spexMdatCffcnt;
	/**
	* 상품 단가*/
	private long goodsUntpc;
	/**
	* 주문 가격*/
	private long orderPc;
	/**
	* 중량 변동금*/
	private long wtChangegld;
	/**
	* 공급가*/
	private long splpc;
	/**
	* 부가세*/
	private long vat;
	/**
	* 판매가*/
	private long slepc;
	/**
	* 페널티 금액*/
	private long penltyAmount;
	/**
	* 취소 단가 차액*/
	private long canclUntpcDfnnt;
	/**
	* 프리미엄 차손 금액*/
	private long premiumDfnlosAmount;
	/**
	* 정산 차액 */
	private long excclcDfnnt;
	/**
	* 환불 금액*/
	private long refndAmount;

	/**
	* 정산 상품 단가*/
	private long excclcGoodsUntpc;
	/**
	* 정산 상품 금액*/
	private long excclcGoodsAmount;
	/**
	* 정산 중량 변동금*/
	private long excclcWtChangegld;
	/**
	* 정산 케이지배송비*/
	private long excclcSorinDlvrf;
	/**
	* 정산 페널티 금액*/
	private long excclcPenltyAmount;
	/**
	* 정산 공급가*/
	private long excclcSplpc;
	/**
	* 정산 부가세*/
	private long excclcVat;
	/**
	* 정산 판매가*/
	private long excclcSlepc;
	/**
	* 등록 일시*/
	private java.sql.Timestamp registDt;
	/**
	* 신청 일시*/
	private java.sql.Timestamp reqstDt;
	/**
	* 완료 일시*/
	private java.sql.Timestamp comptDt;
	/**
	* 정산 처리 여부*/
	private String excclcProcessAt;
	/**
	* 정산 처리 일시*/
	private java.sql.Timestamp excclcProcessDt;
	/**
	* OMS 접수 번호*/
	private String omsRceptNo;
	/**
	* 삭제 일시*/
	private java.sql.Timestamp deleteDt;
	/**
	* 삭제 여부*/
	private String deleteAt;
	/**
	* 최초 등록자 아이디*/
	private String frstRegisterId;
	/**
	* 최초 등록 일시*/
	private java.sql.Timestamp frstRegistDt;
	/**
	* 최종 변경자 아이디*/
	private String lastChangerId;
	/**
	* 최종 변경 일시*/
	private java.sql.Timestamp lastChangeDt;
	/**
	* 실패 사유*/
	private String claimFailrResn;
	/**
	 * 판매 방식 코드 */
	private String sleMthdCode;

	/**
	 * 고정가 할증 요율
	 */
	private java.math.BigDecimal hghnetprcTotAmtTariff;

	/**
	 * 고정가 판매 금액
	 */
	private java.math.BigDecimal hghnetprcSleAmount;

	/**
	 * 고정가 평균 구매 원가
	 */
	private java.math.BigDecimal hghnetprcAvrgPurchsPrmpc;

	/**
	 * 고시 금액
	 */
	private long ntfcAmount;
	/**
	 * 대운송비 금액
	 */
	private long lrgetrnsprtctAmount;
	/**
	 * 마진 금액
	 */
	private long marginAmount;
}
