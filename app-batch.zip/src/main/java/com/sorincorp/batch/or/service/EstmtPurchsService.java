package com.sorincorp.batch.or.service;

public interface EstmtPurchsService {
	
	/**
	 * <pre>
	 * 처리내용: 입력받은 날짜가 해당 월의 첫 혹은 마지막 영업일인지 체크하는 메소드
	 * </pre>
	 * @date 2024. 1. 4.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 1. 4.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param yyyyMMdd
	 * @param executeTimePoint
	 * @return
	 * @throws Exception
	 */
	public boolean isFirstOrLastBusinessDayOfMonth(String yyyyMMdd, String executeTimePoint) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이전월의 누적 평균 LME CSP를 구하여 CN_AVRGPC_FTRS_BAS(계약_평균가 선물 기본) - 스프레드,
	 *         OR_ORDER_FTRS_DTL(주문_주문 선물 상세) - 평균가 스프레드를 업데이트 해준다.
	 *         기본적으로 배치작업을 이용해 월최초 시작일 1번 실행하거나 특수 한 경우 "발생월"을 입력 받아 실행한다.
	 * </pre>
	 * @date 2023. 11. 6.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 6.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param occrrncMt
	 * @throws Exception
	 */
	public void executeBfeMtAvrgLmeCsp(String occrrncMt) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 단가 확정 일자가 금일 이전인 평균가 주문 건에 대하여 
	 * 			해당 월(단가 확정 일자의 월)의 평균가를 도출하여 상품 가격 등의 가격 정보를 업데이트한다.
	 * 			상차 처리되어 중량이 확정된 건은(총 확정 중량 데이터가 있을 시) 정산 데이터를 생성 및 업데이트하고,
	 * 			배송 완료까지 처리된 건은 세금계산서 발행 모듈 호출을 통해 수정세금계산서 발행까지 진행한다.
	 * </pre>
	 * @date 2023. 11. 21.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 21.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderNos			수동 처리 대상 주문 번호들
	 * @throws Exception
	 */
	public void executeAvrgUntpcDcsn(String orderNos) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 평균가 프라이싱 확정 처리
	 *           해당 계약 월의 주문 중량(ORDER_WT)을 전부 평균가 구매 중량(AVRGPC_PURCHS_WT)으로 UPDATE하여
	 *           프라이싱 확정 처리한다. 월 말에서 영업일 -3일에 실행
	 * </pre>
	 * @date 2023. 11. 27.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 27.			srec0053			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	public void executeAvrgPcPricingDcsn() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 평균가 주문 결제 기한 처리 배치
	 * 			 발주 데이터 결제 기한의 경과 여부를 UPDATE
	 * </pre>
	 * @date 2023. 11. 27.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 27.			srec0053			최초작성
	 * ------------------------------------------------
	 */
	public void executeAvrgPcSetleTmlmtProcess() throws Exception;
}
