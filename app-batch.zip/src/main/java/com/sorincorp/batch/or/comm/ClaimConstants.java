package com.sorincorp.batch.or.comm;

public class ClaimConstants {

	public static final String SERVICE_DOMAIN = "https://www.kztraders.com";

	/** 클레임 유형 코드 */
	public static final String CLAIM_TY_CODE_CANCEL = "01";//취소
	public static final String CLAIM_TY_CODE_RETURN = "02";//반품
	public static final String CLAIM_TY_CODE_EXCHANGE = "03";//교환
	public static final String CLAIM_TY_CODE_ACDNT = "04";//사고

	/** 결제 구분 코드 */
	public static final String SETLE_SE_CODE_ORDER = "10";//주문
	public static final String SETLE_SE_CODE_CANCEL = "20";//취소
	public static final String SETLE_SE_CODE_RETURN = "30";//반품
	public static final String SETLE_SE_CODE_EXCHANGE = "40";//교환

	/** 결제 유형 코드 */
	public static final String SETLE_TY_CODE_SETTLE = "10";//정산 (케이지트레이딩<-- 가상)
	public static final String SETLE_TY_CODE_REFUND = "20";//환불 (케이지트레이딩--> 가상)

	/** 결제 상태 코드 */
	public static final String SETLE_STTUS_CODE_REQUEST = "01";//요청
	public static final String SETLE_STTUS_CODE_COMPLETE = "02";//완료
	public static final String SETLE_STTUS_CODE_FAIL = "03";//실패

	/** 이월렛 정산 유형 코드 */
	public static final String EXCCLC_TY_CODE_CANCEL = "05";//취소
	public static final String EXCCLC_TY_CODE_EXCHANGE = "06";//교환
	public static final String EXCCLC_TY_CODE_RETURN = "07";//반품

	/** 이월렛 정산 작업 구분 */
	public static final String JOB_SE_CODE_CANCL = "CANCL";
	public static final String JOB_SE_CODE_RTNGUD = "RTNGUD";
	public static final String JOB_SE_CODE_EXCHNG = "EXCHNG";

	/** 이월렛 응답 파라미터 */
	public static final String EWALLET_RESULT_KEY = "resultCode";
	public static final String EWALLET_DATA_KEY = "data";

	/** 삼성선물 */
	public static final String API_RESULT_KEY = "code";
	public static final String API_SUCCESS_CODE = "200";

	/** 주문 상태 코드 */
	public enum OrderSttusCode{
		/** 11:주문취소(증거금만 사용) */
		WRTM_ORDER_CANCL("11");

		private String code;
		private OrderSttusCode(String code) {
			this.code = code;
		}
		public String getCode() {
			return code;
		}
	}

	/** 취소 교환 반품 상태 코드 */
	public enum CanclExchngRtngudSttusCode {
		/** 등록:01, 확정:02, 신청:03, 처리중: 04, 완료:05, 실패:90 */
		REGIST("01"), DCSN("02"), REQST("03"), PRCSNG("04"), COMPT("05"), FAILR("90");

		private String code;
		private CanclExchngRtngudSttusCode(String code) {
			this.code = code;
		}
		public String getCode() {
			return code;
		}
	}

	/** 취소 교환 반품 사유 코드 */
	public enum CanclExchngRtngudResnCode {
		/** 10:고객변심, 20:상품결함, 30:오배송, 40:여신불이행 */
		CSTMR_CHANGE_MIND("10"), GOODS_DEFECT("20"), WRONG_DELIVERY("30"), CREDIT_FAILR("40");

		private String code;
		private CanclExchngRtngudResnCode(String code) {
			this.code = code;
		}
		public String getCode() {
			return code;
		}
	}

	/** CS 미납 처리 유형 코드 */
	public enum NpyProcessTyCode {
		/** 10:전화, 20:이메일, 30:SMS */
		PHONE("10"), MAIL("20"), SMS("30");

		private String code;
		private NpyProcessTyCode(String code) {
			this.code = code;
		}
		public String getCode() {
			return code;
		}
	}

	/** 판매 방식 코드 코드 */
	public enum SleMthdCode {
		/** 01:LIVE, 02:고정가, 03:지정가 */
		LIVE("01"), FIXING("02"), LIMIT("03");

		private String code;
		private SleMthdCode(String code) {
			this.code = code;
		}
		public String getCode() {
			return code;
		}
	}
}
