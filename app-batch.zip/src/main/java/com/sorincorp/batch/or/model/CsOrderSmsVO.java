package com.sorincorp.batch.or.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class CsOrderSmsVO extends CommonVO{

	private static final long serialVersionUID = -5962839912648702203L;
	
	/******  JAVA VO CREATE : OR_ORDER_BAS(주문_주문 기본)                                                                                   ******/
    /**
     * 순서 번호
     */
    private String rownum;
	/**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 주문 상태명
     */
    private String orderSttusNm;
    /**
     * 출고 요청 일자(배송요청일)
     */
    private String dlivyRequstDe;
    /**
     * 주문 업체 명
    */
    private String orderEntrpsNm;
    /**
     * 주문자 명
    */
    private String ordrrNm;
    /**
     * 주문자 휴대폰 번호
    */
    private String ordrrMoblphonNo;
    /**
     * 주문 업체 전화번호
    */
    private String orderEntrpsTelno;
    /**
     * 브랜드 코드
     */
    private String brandCode;
    /**
     * 배송 수단 명
    */
    private String dlvyMnNm;
    /**
     * 물류센터
     */
    private String itemCenter;
    /**
     * 총 실제 주문 중량
    */
    private int totRealOrderWt;

    /**
     * 주문 일자
    */
    private String orderDe;
    /**
     * 사업자 등록 번호
     */
    private String bsnmRegistNo;
    /**
     * 금속 코드
     */
    private String metalCode;
    /**
     * 업체 배송 메모
     */
    private String dlvyMemo;
    /**
     * 상품명
     */
    private String itmNm;
    /**
     * 차량입고일
     */
    private String vhcleWrhousngDe;
    /**
     * 차량입고일 월 일
     */
    private String vhcleWrhousngDe2;
    /**
     * 배송요청일 월일
     */
    private String dlivyRequstDe2;
    /**
     * 업체주소
     */
    private String adres;
    /**
     * 검색조건 : 배송구분
     */
    private String dlvySe;
    /**
     * 배송기사명
     */
    private String drverNm;
    /**
     * 차량정보
     */
    private String vhcleNo;
    /**
     * 기사핸드폰
     */
    private String drverTlphonNo;    
    /**
     * 검색조건 : CS대상여부
     */
    private String csTargetAt;
    /**
     * 검색조건 : 검색 날짜 구분
     */
    private String dateRadio;
    /**
     * 검색조건 : 검색 시작일
     */
    private String searchDateFrom;
    /**
     * 검색조건 : 검색 종료일
     */
    private String searchDateEnd;
    

}