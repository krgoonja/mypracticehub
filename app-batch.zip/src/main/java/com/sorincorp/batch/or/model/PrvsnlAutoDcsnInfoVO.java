package com.sorincorp.batch.or.model;

import lombok.Data;

/**
 * PrvsnlAutoDcsnInfoVO.java
 * 가단가 자동 확정 정보 VO 객체
 * 
 * @version
 * @since 2024. 11. 8.
 * @author srec0049
 */
@Data
public class PrvsnlAutoDcsnInfoVO {

	/**
	 * 주문 번호
	 */
	private String orderNo;
	
	/**
     * 단가 분리 확정 여부
     */
    private String untpcSepratDcsnAt;
	
	/**
	 * 회원 번호
	 */
	private String mberNo;
	
	/**
	 * 금속 코드
	 */
	private String metalCode;
	
	/**
	 * 발생 일자 (YYYYMMDD)
	 */
	private String occrrncDe;
	
	/**
     * 지정가 LME 주문 번호
     */
    private String limitLmeOrderNo;
    
    /**
     * 지정가 환율 주문 번호
     */
    private String limitEhgtOrderNo;
    
    /**
     * 지정가 KRW 주문 번호
     */
    private String limitKrwOrderNo;
}
