package com.sorincorp.batch.or.service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.or.mapper.PrvsnlPcChangegldRealarmMapper;
import com.sorincorp.batch.or.model.OrPcChangegldBasVO;
import com.sorincorp.batch.or.model.PrvsnlPcChangegldRealarmInfoVO;
import com.sorincorp.comm.bsnInfo.model.RestTermVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.BsnInfoUtil;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * PrvsnlPcChangegldRealarmServiceImpl.java
 * 가단가 변동금 재알람 관련 Service 구현체 클래스
 * 
 * @version
 * @since 2024. 11. 21.
 * @author srec0049
 */
@Slf4j
@Service
public class PrvsnlPcChangegldRealarmServiceImpl implements PrvsnlPcChangegldRealarmService {

	/**
	 * 사이트 운영 설정 서비스
	 */
	@Autowired
	private BsnInfoService bsnInfoService;
	
	/**
     * 공통 코드 서비스
     */
    @Autowired
    private CommonCodeService commonCodeService;
    
    /**
     * SMS 발송 서비스
     */
    @Autowired
    private SMSService smsService;
    
    /**
     * 가단가 변동금 재알람 관련 Mapper
     */
    @Autowired
    PrvsnlPcChangegldRealarmMapper prvsnlPcChangegldRealarmMapper;
    
    
    /**
     * 가단가 변동금 재알람 배치 수행
     */
    @Override
	public void callPrvsnlPcChangegldRealarm(Map<String, String> map) throws Exception {
    	
    	//log.info(">> [PrvsnlPcChangegldRealarmServiceImpl][callPrvsnlPcChangegldRealarm] param : " + map.toString());
    	
    	PrvsnlPcChangegldRealarmInfoVO prvsnlPcChangegldRealarmInfoVO = new PrvsnlPcChangegldRealarmInfoVO();
    	
    	// 외부로 받은 파라미터로 주문 번호가 존재할 때 set 
		if(map.get("pOrderNo") != null) {
			prvsnlPcChangegldRealarmInfoVO.setOrderNo(String.valueOf(map.get("pOrderNo")));
		}
		// 외부로 받은 파라미터로 날짜가 존재할 때 set 
		if(map.get("pOccrrncDe") != null) {
			prvsnlPcChangegldRealarmInfoVO.setOccrrncDe(String.valueOf(map.get("pOccrrncDe")));
		} else {
			prvsnlPcChangegldRealarmInfoVO.setOccrrncDe(DateUtil.getNowDate());
		}
		
		// 라이브 영업시간 리스트를 가져온다.
		List<RestTermVO> restDeLiveList = bsnInfoService.getRestTermInfoBySleMthd(prvsnlPcChangegldRealarmInfoVO.getOccrrncDe(), "01");
		
		// 가단가 변동금 재알람 대상 리스트 가져오기 (이월렛의 입금요망(10), 출금대상(40)만 대상)
		List<PrvsnlPcChangegldRealarmInfoVO> selectPrvsnlPcChangegldRealarmTargetList = prvsnlPcChangegldRealarmMapper.selectPrvsnlPcChangegldRealarmTargetList(prvsnlPcChangegldRealarmInfoVO);
		for(PrvsnlPcChangegldRealarmInfoVO infoVO : selectPrvsnlPcChangegldRealarmTargetList) {
			//log.info(">> infoVO : " + infoVO.toString());
			
			String metalCode = infoVO.getMetalCode(); // 금속코드
			
			Optional<RestTermVO> restDeLiveOp = Optional.ofNullable(restDeLiveList).orElse(Collections.emptyList())
					.stream()
					.filter(restTerm -> "N".equals(restTerm.getRestdeAt())
							&& metalCode.equals(restTerm.getMetalCode()) 
							&& BsnInfoUtil.OperateSttusCode.OPERATE_AT.getValues().contains(restTerm.getOpenTimeCode())
					)
					.findFirst();
			
			boolean restStatus = restDeLiveOp.isPresent(); // 영업시간 체크(true: 영업시간, false: 휴일)
			
			// 영업시간일 경우 진행
			if(restStatus) {
				String setleMthdCode = infoVO.getSetleMthdCode(); // 결제 방식 코드
				
				// 이월렛일 경우 진행
				if(StringUtils.equals("10", setleMthdCode)) {
					OrPcChangegldBasVO insertVO = new OrPcChangegldBasVO();
					insertVO.setOrderNo(infoVO.getOrderNo()); // 주문 번호
					insertVO.setOccrrncDe(infoVO.getOccrrncDe()); // 발생일자 (평가일자)
					insertVO.setAvrgpcGoodsUntpc(infoVO.getAvrgpcGoodsUntpc()); // 평균가 상품 단가 (가단가)
					insertVO.setFrstPcChangeAmount(infoVO.getFrstPcChangeAmount()); // 최초 가격 변동 금액 (최초변동금)
					insertVO.setPcChangegldSttusCode(infoVO.getPcChangegldSttusCode()); // 가격 변동금 상태 코드
					insertVO.setUntpcStdrPrePayAmount(infoVO.getUntpcStdrPrePayAmount()); // 단가 기준 기 납입 금액
					// 합계 : 가단가 + 최초변동금 + 추가변동금(단가 기준 기 납입 금액[이월렛일 경우 입금, 출금 이벤트 후 판단하기때문에 단가 기준 기 납입 금액 사용])
					insertVO.setTotalChangeAmount(infoVO.getAvrgpcGoodsUntpc() + infoVO.getFrstPcChangeAmount() + infoVO.getUntpcStdrPrePayAmount());
					insertVO.setEvlAmount(infoVO.getEvlAmount()); // 평가 금액 (시초가)
					insertVO.setChangeUntpc(infoVO.getChangeUntpc()); // 변동 단가
					insertVO.setDcsnChangeUntpc(infoVO.getDcsnChangeUntpc()); // 확정 변동 단가
					insertVO.setRcppayTrgetAmount(infoVO.getRcppayTrgetAmount()); // 입출금 대상 금액
					
					// 가단가 구매 변동금 추가/환불 재알람 SMS 호출
					this.callPrvsnlPcChangegldRealarmProcSms(insertVO);
				}
			}
		}
    }
    
    /**
     * <pre>
     * 처리내용: 가단가 구매 변동금 추가/환불 재알람 SMS 호출
     * </pre>
     * @date 2024. 11. 21.
     * @author srec0049
     * @history 
     * ------------------------------------------------
     * 변경일                 작성자          변경내용
     * ------------------------------------------------
     * 2024. 11. 21.          srec0049         최초작성
     * ------------------------------------------------
     * @param orPcChangegldBasVO
     */
    private void callPrvsnlPcChangegldRealarmProcSms(OrPcChangegldBasVO orPcChangegldBasVO) {
    	try {
			// 가단가 구매 변동금 추가/환불 재알람 SMS 내용 정보 가져오기 (이월렛의 입금요망(10), 출금대상(40)만 대상)
			Map<String, String> smsMap = prvsnlPcChangegldRealarmMapper.selectPrvsnlPcChangegldRealarmSmsInfo(orPcChangegldBasVO);
			
			smsMap.put("templateNum", "151"); // 템플릿 번호
			
			// 평가 영역
            StringBuilder evlArea = new StringBuilder();
            evlArea.append("가단가 : ").append(String.valueOf(smsMap.get("avrgpcGoodsUntpc"))).append(System.lineSeparator()); // 가단가 (평균가 상품 단가)
            evlArea.append("최초변동금 : ").append(String.valueOf(smsMap.get("frstPcChangeAmount"))).append(System.lineSeparator()); // 최초변동금 (최초 가격 변동 금액)
            
            String untpcStdrPrePayAmount = String.valueOf(smsMap.get("untpcStdrPrePayAmount"));
            if(StringUtils.isNotEmpty(untpcStdrPrePayAmount) && !untpcStdrPrePayAmount.equals("null")) {
            	evlArea.append("추가변동금 : ").append(untpcStdrPrePayAmount).append(System.lineSeparator()); // 추가변동금 (단가 기준 기 납입 금액)
            }
            
            evlArea.append("합계 : ").append(String.valueOf(smsMap.get("totalChangeAmount"))).append(System.lineSeparator()); // 합계 (가단가 + 최초변동금 + 추가변동금)
            evlArea.append("시초가 : ").append(String.valueOf(smsMap.get("evlAmount"))).append(System.lineSeparator()); // 시초가
            evlArea.append("평가 : ").append(String.valueOf(smsMap.get("changeUntpc"))); // 평가 (변동 단가)
            
            smsMap.put("evlArea", evlArea.toString()); // 평가 영역
            evlArea = null; // StringBuilder 메모리 해제 유도
            
            // 변동금 내역 영역
            StringBuilder changeGldArea = new StringBuilder();
            changeGldArea.append("확정변동단가 : ").append(String.valueOf(smsMap.get("dcsnChangeUntpc"))).append(System.lineSeparator()); // 확정변동단가
            
            String pcChangegldSttusCode = orPcChangegldBasVO.getPcChangegldSttusCode(); // 가격 변동금 상태 코드
            
            // 이월렛일 경우
        	switch(pcChangegldSttusCode) {
            	case "10" : 
            		// 입금요망
            		changeGldArea.append("입금 요망 금액 : ").append(String.valueOf(smsMap.get("rcppayTrgetAmount"))).append(System.lineSeparator()); // 입출금 대상 금액
            		changeGldArea.append(System.lineSeparator());
            		changeGldArea.append("위 금액을 당일 17:00 까지 입금하여 주십시오.(미입금시 17:00분에 단가 확정 됩니다.)").append(System.lineSeparator());
            		break;
            	case "40" : 
            		// 출금대상
            		changeGldArea.append("출금 가능 금액 : ").append(String.valueOf(smsMap.get("rcppayTrgetAmount"))).append(System.lineSeparator()); // 입출금 대상 금액
            		changeGldArea.append(System.lineSeparator());
            		changeGldArea.append("위 금액은 출금 가능합니다.(미출금시에는 정산 시점에 자동 환불 처리 됩니다.)").append(System.lineSeparator());
            		break;
        	}
            
            smsMap.put("changeGldArea", changeGldArea.toString()); // 변동금 내역 영역
            changeGldArea = null; // StringBuilder 메모리 해제 유도
            
            
            Map<String, CommonCodeVO> csTelNo = commonCodeService.getSubCodesRetVo("SORIN_SETUP_CODE", "CS_TEL");
            smsMap.put("csTelNo", csTelNo.get("CS_TEL").getCodeDcone()); // 고객센터번호
			
			SMSVO smsVO = new SMSVO();
            smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
            smsVO.setMberNo(String.valueOf(smsMap.get("mberNo"))); // 회원 번호
            
            String phone = String.valueOf(smsMap.get("ordrrMoblphonNo"));
            if(StringUtils.isNotEmpty(phone) && !phone.equals("null")) {
                try {
                    log.debug("휴대전화 번호 복호화 전 ==================>" + phone);
                    phone = CryptoUtil.decryptAES256(phone);
                    log.debug("휴대전화 번호 복호화 후 ==================>" + phone);
                    /** 휴대전화 번호 셋팅 **/
                    smsVO.setPhone(phone);
                } catch(Exception e) {
                    log.error("OrderPrvsnlDcsnServiceImpl callPrvsnlPcChangegldRealarmProcSms ORDRR_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
                }
            }
            
            // SMS 또는 LMS 발송 및 알림톡 발송
            smsService.insertSMS(smsVO, smsMap);
			
		} catch(Exception e) {
			log.error("[OrderPrvsnlDcsnServiceImpl][callPrvsnlPcChangegldRealarmProcSms] " + ExceptionUtils.getStackTrace(e));
		}
    }
}
