package com.sorincorp.batch.or.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sorincorp.batch.or.model.AvrgUntpcDcsnVO;
import com.sorincorp.batch.or.model.EstmtPurchsVO;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.comm.order.model.OrOrderAvrgpcDtlVO;

public interface EstmtPurchsMapper {
	
	/**
	 * <pre>
	 * 처리내용: 입력받은 년월의 첫 혹은 마지막 영업일을 구하는 메소드
	 * </pre>
	 * @date 2024. 1. 4.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 1. 4.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param yyyyMM
	 * @param executeTimePoint
	 * @return
	 * @throws Exception
	 */
	public String getFirstOrLastBusinessDayOfMonth(@Param("time") String yyyyMM, @Param("executeTimePoint") String executeTimePoint) throws Exception;

	/**
	 * <pre>
	 * 처리내용: ST_EVEMTH_ACCMLT_DALY_AVG_PC_BAS(통계_월단위 일자별 누적평균가 현황) 테이블에서 메탈별 해당월의 LME_CSP 평균을 구한다.
	 *        ST_EVEMTH_ACCMLT_DALY_AVG_PC_BAS 테이블의 원천 데이터는 PR_LME_PBLNTF_PC_BAS(가격_LME 공시 가격 기본) 테이블로 LME 서버에서 등록 하고 있으며
	 *        LME 스케쥴러를 통해 ST_EVEMTH_ACCMLT_DALY_AVG_PC_BAS 테이블에 일별로 등록 하고 있다.
	 * </pre>
	 * @date 2023. 11. 8.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 8.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param occrrncMt - 계약월
	 * @return
	 * @throws Exception
	 */
	public List<EstmtPurchsVO> selectBfeMtAvrgLmeCspList(EstmtPurchsVO paramVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: CN_AVRGPC_FTRS_BAS(계약_평균가 선물 기본)의 LME 가격, 최종 가격을 update 한다.
	 * </pre>
	 * @date 2023. 11. 8.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 8.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	public int updateCnAvrgpcFtrsBasLmeCsp(EstmtPurchsVO paramVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: CN_AVRGPC_FTRS_BAS(계약_평균가 선물 기본) 수정 후 CN_AVRGPC_FTRS_BAS_HST(계약_평균가 선물 기본 이력) 테이블에 등록한다.
	 * </pre>
	 * @date 2023. 11. 10.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 10.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	public int insertCnAvrgpcFtrsBasHst(EstmtPurchsVO paramVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 평균가 계약 관련 OR_ORDER_FTRS_DTL(주문_주문 선물 상세)의 선물체결 리스트를 조회한다.
	 * </pre>
	 * @date 2023. 11. 10.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 10.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	public List<EstmtPurchsVO> selectCntrctFtrsDtlList(EstmtPurchsVO paramVo)throws Exception;

	/**
	 * <pre>
	 * 처리내용: OR_ORDER_FTRS_BAS(주문_주문 선물 기본) 데이터 중 요청 선물사 구분 코드,  요청 선물사 대상 코드를 update 한다.
	 * </pre>
	 * @date 2023. 11. 15.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 15.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	public int updateOrOrderFtrsBasLmeCsp(EstmtPurchsVO paramVo) throws Exception;
    /**
     * <pre>
     * 처리내용: OR_ORDER_FTRS_DTL(주문_주문 선물 상세) 데이터 중 체결데이터의 체결 단가, 평균가 스프레드를 update한다.
     * </pre>
     * @date 2023. 11. 8.
     * @author srec0070
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2023. 11. 8.			srec0070			최초작성
     * ------------------------------------------------
     * @param paramVo
     * @return
     * @throws Exception
     */
    public int updateOrOrderFtrsDtlLmeCsp(EstmtPurchsVO paramVo) throws Exception;
    
    /**
     * <pre>
     * 처리내용: 평균가 확정 처리 대상 주문의 발주 번호 및 로직 처리에 필요한 데이터 조회
     * </pre>
     * @date 2023. 11. 21.
     * @author srec0053
     * @param executeTimePoint 
     * @history 
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2023. 11. 21.			srec0053			최초작성
     * ------------------------------------------------
     * @return
     * @throws Exception
     */
    public List<AvrgUntpcDcsnVO> selectAvrgUntpcDcsnData(@Param("orderNoInArray") String[] orderNoInArray) throws Exception;
    
    /**
	 * <pre>
	 * 처리내용: 주문_주문 평균가 상세 리스트로 등록 (bulk insert)
	 * </pre>
	 * @date 2023. 11. 22.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 22.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orOrderAvrgpcDtlVOList
	 */
	public void insertOrOrderAvrgpcDtlList(List<OrOrderAvrgpcDtlVO> orOrderAvrgpcDtlVOList, String orderNo);
	
	/**
	 * <pre>
	 * 처리내용: 주문_주문 평균가 상세 이력 리스트로 처리 (bulk insert)
	 * </pre>
	 * @date 2023. 12. 1.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 12. 1.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orOrderAvrgpcDtlVOList
	 * @param orderNo
	 */
	public void insertOrOrderAvrgpcDtlHst(String orderNo);

	/**
	 * <pre>
	 * 처리내용: 계산된 가격 정보를 주문_주문 기본 테이블에 update
	 * </pre>
	 * @date 2023. 11. 22.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 22.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param targetVO
	 */
	public void updateOrderPriceInfos(AvrgUntpcDcsnVO targetVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문_주문 기본 이력 테이블에 insert
	 * </pre>
	 * @date 2023. 11. 22.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 22.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param targetVO
	 */
	public void insertOrOrderBasHst(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 계약_계약 월 상세 현재 월의 미확정된 프라이싱 데이터를 확정 데이터로 update
	 * </pre>
	 * @date 2023. 11. 27.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 27.			srec0053			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	
	public void updateCntrctMtPricingDcsn() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 프라이싱 확정 배치 테스트용
	 * </pre>
	 * @date 2023. 11. 27.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 27.			srec0053			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	
	public void updateCntrctMtPricingDcsnForTest(String cntrctNo, String cntrctYm) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 계약_계약 발주 기본 테이블에서 결제 기한이 경과한 데이터를 update 처리
	 * </pre>
	 * @date 2023. 11. 27.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 27.			srec0053			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	public void updateCntrctOrderSetleTmlmt() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 환불, 상환 처리 여부 조회
	 * </pre>
	 * @date 2023. 12. 14.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 12. 14.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	public boolean selectIsRefnded(@Param("orderNo") String orderNo);
	
	/**
	 * <pre>
	 * 처리내용: 담보 보증 미상환 금액 조회
	 * </pre>
	 * @date 2023. 12. 18.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 12. 18.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	public Long selectNrdmpAmount(@Param("orderNo") String orderNo);
	
	/**
	 * <pre>
	 * 처리내용: 해당 주문에서 사용된 쿠폰 리스트 조회
	 * </pre>
	 * @date 2024. 1. 26.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 1. 26.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	public List<CouponVO> selectCouponList(@Param("orderNo") String orderNo);
	
	/**
	 * <pre>
	 * 처리내용: 평균가 주문 선물환 정보 update
	 * </pre>
	 * @date 2024. 2. 6.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 2. 6.			srec0053			최초작성
	 * ------------------------------------------------
	 */
	int updateAvrgPcOrderFshgInfo(@Param("usdCvtrate") double usdCvtrate, @Param("targetDate") String targetDate);
	
	/**
	 * <pre>
	 * 처리내용: 최신 매매 기준율 데이터 조회
	 * </pre>
	 * @date 2024. 2. 28.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 2. 28.			srec0053			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	Map<String, Object> selectLatestGtxApiFxrate();
	
	/**
	 * <pre>
	 * 처리내용: 평균가 주문 선물환 정보 업데이트 대상 조회
	 * </pre>
	 * @date 2024. 2. 28.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 2. 28.			srec0053			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	String selectAvrgPcOrderFshgInfoUpdateTarget();

	void updateOrMrtggBas(@Param("orderNo") String orderNo, @Param("excclcAmount") long excclcAmount);
}
