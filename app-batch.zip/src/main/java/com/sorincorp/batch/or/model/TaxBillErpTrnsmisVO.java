package com.sorincorp.batch.or.model;

import java.util.List;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel("세금계산서 발행완료, ERP 전송 목록 VO")
public class TaxBillErpTrnsmisVO {

	/**주문번호 리스트*/
	private List<String> orderNoList;
	
	/**취소 교환 반품 번호 리스트*/
	private List<String> canclExchngRtngudNoList;
	
	/**세금 계산서 발행 구분 코드 리스트*/
	private List<String> taxBillIsuSeCodeList;
}//end class()
