package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * AvrgPcEstmtCntrctTmlmtEndJobConfig.java
 * : 평균가 견적 기한/계약 승인 기한 만료 Batch JobConfig
 * @version
 * @since 2024. 1. 3.
 * @author srec0066
 */
@Configuration
@EnableBatchProcessing
public class AvrgPcEstmtCntrctTmlmtEndJobConfig {

	@Autowired
	private AvrgPcEstmtCntrctTmlmtEndTasklet avrgPcEstmtCntrctTmlmtEndTasklet;

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job avrgPcEstmtCntrctTmlmtEndJob() {
		return jobBuilderFactory.get("avrgPcEstmtCntrctTmlmtEndJob").start(avrgPcEstmtCntrctTmlmtEndStep()).build();
	}

	@Bean
	@JobScope
	public Step avrgPcEstmtCntrctTmlmtEndStep() {
		return stepBuilderFactory.get("avrgPcEstmtCntrctTmlmtEndStep").tasklet(avrgPcEstmtCntrctTmlmtEndTasklet).build();
	}

}
