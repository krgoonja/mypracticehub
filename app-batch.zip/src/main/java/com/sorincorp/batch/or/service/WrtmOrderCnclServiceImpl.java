package com.sorincorp.batch.or.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.sorincorp.batch.or.comm.ClaimConstants;
import com.sorincorp.batch.or.comm.ClaimConstants.CanclExchngRtngudResnCode;
import com.sorincorp.batch.or.comm.ClaimConstants.CanclExchngRtngudSttusCode;
import com.sorincorp.batch.or.comm.ClaimConstants.OrderSttusCode;
import com.sorincorp.batch.or.comm.ClaimConstants.SleMthdCode;
import com.sorincorp.batch.or.comm.OrCommonConstants;
import com.sorincorp.batch.or.mapper.ClaimMapper;
import com.sorincorp.batch.or.mapper.WrtmOrderCnclMapper;
import com.sorincorp.batch.or.model.ClaimBasVO;
import com.sorincorp.batch.or.model.ClaimDtlVO;
import com.sorincorp.batch.or.model.DlvrfBasVO;
import com.sorincorp.batch.or.model.OrSetleBasVO;
import com.sorincorp.batch.or.model.OrderDtlVO;
import com.sorincorp.batch.or.model.OrderFtrsBasVO;
import com.sorincorp.batch.or.model.BatchOrderModel;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.order.constant.CommFtrsConstant;
import com.sorincorp.comm.order.model.CommFtrsFshgMngVO;
import com.sorincorp.comm.order.service.CommFtrsFshgMngService;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class WrtmOrderCnclServiceImpl implements WrtmOrderCnclService {

	@Autowired
	private OrCommonConstants orProperty;

	@Autowired
	private ClaimService claimService;

	@Autowired
	private WrtmMsgService msgService;

	@Autowired
	private ClaimMapper claimMapper;

	@Autowired
	private WrtmOrderCnclMapper wrtmCnclMapper;

	@Autowired
	private CommonCodeService commonCodeService;

	/** 선물 선물환 관리 서비스 **/
	@Autowired
	private CommFtrsFshgMngService commFtrsFshgMngService;

	/** 실시간 판매 가격 함수 서비스 **/
	@Autowired
	private PcInfoService pcInfoService;

	/**
	 * 외부 연계 api 호출 모듈
	 */
	@Autowired
	private HttpClientHelper httpClientHelper;

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소 주문에 필요한 다음달 선물, 선물환의 만기일를 조회한다.
	 *        고객센터 정보 조회한다.
	 *        발신자 메일 주소 조회한다.
	 * </pre>
	 * @date 2022. 10. 19.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 19.			srec0070			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@Override
	public Map<String, String> selectBeforeProcInfo() throws Exception {
		//1. 다음달 선물, 선물환 만기일 조회
		Map<String, String> nextExprtnDeMap =
				Optional.ofNullable(wrtmCnclMapper.selectNextMonthExprtnDate()).orElseGet(HashMap::new);

		//2. 고객센터 정보 조회
		CommonCodeVO csCodeInfo =
				Optional.ofNullable(commonCodeService.getCodeValueRetVo("SORIN_SETUP_CODE", "CS_TEL"))
						.orElseThrow(() -> {return new Exception("SORIN_SETUP_CODE 정보 미존제.");});

		String csTelNo = csCodeInfo.getCodeDcone();
		nextExprtnDeMap.put("CS_TEL_NO", csTelNo);

		return nextExprtnDeMap;
	}

	/**
	 * 증거금 주문중 연체된 주문 리스트를 조회한다.
	 */
	@Override
	public List<BatchOrderModel> selectWrtmArrrgOrderList(String wrtmCanclOrderNo) throws Exception {
		List<BatchOrderModel> orderBasList = wrtmCnclMapper.selectWrtmArrrgOrderList(wrtmCanclOrderNo);
		for(BatchOrderModel batchOrderModel : orderBasList) {
			/*
			 * 주문_주문 상세 정보
			 */
			List<OrderDtlVO> orderDtlList = wrtmCnclMapper.selectOrderBasDtlList(batchOrderModel);
			batchOrderModel.setOrderBasDtlList(orderDtlList);
			/*
			 *주문_배송비 정보
			 */
			DlvrfBasVO orderDlvrfList = wrtmCnclMapper.selectOrderDlvrfBasInfo(batchOrderModel);
			batchOrderModel.setOrderDlvrfBas(orderDlvrfList);
		}
		return orderBasList;
	}

	/**
	 * 증거금 연체 주문을 취소처리 한다.
	 */
	@Override
	public void doWrtmOrderCncl(BatchOrderModel batchOrderModel) throws Exception {
		try {
			log.warn("[doWrtmOrderCncl] :" + String.valueOf(batchOrderModel));

			// 증거금 취소 주문 초기 데이터 설정
			initOrderData(batchOrderModel);

			orderValidation(batchOrderModel);

			log.warn("new doWrtmOrderCncl :" + String.valueOf(batchOrderModel));

			String sleMthdCode = batchOrderModel.getSleMthdCode();
			if( !(StringUtils.equals(SleMthdCode.LIVE.getCode(), sleMthdCode)
					|| StringUtils.equals(SleMthdCode.FIXING.getCode(), sleMthdCode)
					|| StringUtils.equals(SleMthdCode.LIMIT.getCode(), sleMthdCode)
				 )
			  )
			{
				log.warn("판매 방식 예외건. ORD_NO:{}, SLE_MTHD_CODE:{}", batchOrderModel.getSleMthdCode(), batchOrderModel.getSleMthdCode());
				throw new CommCustomException("판매 방식 예외건. ORD_NO:" + batchOrderModel.getOrderNo() + ", SLE_MTHD_CODE:" +  batchOrderModel.getSleMthdCode());
			}

			/* 주문_취소 교환 반품 기본 테이블 등록 */
			claimInstTblBase(batchOrderModel);

			/**
			 * 클레임 BL 기준으로 원주문 BL 정보 조회
			 **/
			batchOrderModel.setClaimBlList(Optional.ofNullable(claimMapper.getClaimBlList(batchOrderModel.getClaimBas()))
											.orElseThrow(() -> {
												return new CommCustomException(batchOrderModel.getPrefix() + " 클레임 BL 정보 미존재"); }));

			batchOrderModel.getClaimBlList().stream().forEach(claimDtlVO -> log.warn(claimDtlVO.toString()));

			/** 주문 성공 후 처리 **/
			wrtmOrderComplete(batchOrderModel);

			// 주문_취소 교환 반품 기본 테이블 상태 수정
			ClaimBasVO claimBasVO = batchOrderModel.getClaimBas();
			claimBasVO.setCanclExchngRtngudSttusCode(CanclExchngRtngudSttusCode.COMPT.getCode()); // 완료
			claimMapper.updateLastClaimMaster(claimBasVO);

			// 주문 상태 -> 증거금 취소 변경
			batchOrderModel.setOrderSttusCode(OrderSttusCode.WRTM_ORDER_CANCL.getCode());
			claimMapper.updateLastOrderMaster(batchOrderModel);
			claimMapper.insertOrOrderBasHst(batchOrderModel);

		} catch(Exception e) {
			String claimFailrResn = ExceptionUtils.getStackTrace(e);
			log.error(claimFailrResn);
			if(batchOrderModel.getClaimBas() != null)
				batchOrderModel.getClaimBas().setClaimFailrResn(claimFailrResn);

			wrtmOrderCnclFail(batchOrderModel);
		}
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소주문 실패 처리를 한다.
	 * </pre>
	 * @date 2022. 10. 13.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 13.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 */
	private void wrtmOrderCnclFail(BatchOrderModel batchOrderModel) {
		try {
			// 주문_취소 교환 반품 기본 테이블 상태 수정
			ClaimBasVO claimBasVO = batchOrderModel.getClaimBas();
			if(claimBasVO != null) {
				claimBasVO.setCanclExchngRtngudSttusCode(CanclExchngRtngudSttusCode.FAILR.getCode()); // 증거금 취소 주문 실패
				claimMapper.updateLastClaimMaster(claimBasVO);
			}else {
				log.warn("ORD_NO [{}] - 증거금 취소 주문 진행중 [OR_CANCL_EXCHNG_RTNGUD_BAS] 데이터 생성 실패함.",  batchOrderModel.getOrderNo());
			}
			msgService.sendWrtmOrderCnclSms(batchOrderModel, "77", null, "증거금미납건 취소주문을 위한 배치작업시 주문요청 실패");
		}catch(Exception e) {
			log.error("[wrtmOrderCnclFail] " + ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소 주문을 위한 주문 초기 데이터 설정
	 * </pre>
	 * @date 2022. 10. 12.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 12.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @throws CommCustomException
	 * @throws Exception
	 */
	private void initOrderData(BatchOrderModel batchOrderModel) throws CommCustomException, Exception {

		// 삼성선물 주문 타입
		// C : 청산번호가 있으면 청산번호로 요청청산포지션번호 셋, 없으면 만기일자로 셋
		// N : 무조건 만기일자로 셋
		String samsungOrdertype = orProperty.getSamsungOrdertype();
		if(StringUtils.isEmpty(samsungOrdertype) || samsungOrdertype.equals("null")) throw new CommCustomException(batchOrderModel.getPrefix() + " 삼성선물 주문 타입 설정이 없습니다.");
		batchOrderModel.setSamsungOrdertype(samsungOrdertype);

		String metalCode = batchOrderModel.getMetalCode();
		CommonCodeVO metalCodeInfo = Optional.ofNullable(commonCodeService.getCodeValueRetVo("METAL_CODE", metalCode)).orElseThrow(() -> {return new CommCustomException(batchOrderModel.getPrefix() + " 공통코드_메탈코드 정보가 없습니다.");});

		String samsungStockCode = metalCodeInfo.getCodeRefrnone(); // 요청 선물 종목 코드
		if(StringUtils.isEmpty(samsungStockCode)) throw new CommCustomException(batchOrderModel.getPrefix() + " 요청 선물 종목 코드 값이 없습니다.");
		batchOrderModel.setSamsungStockCode(samsungStockCode); // 요청 선물 종목 코드

		BigDecimal samsungOrderWt = Optional.ofNullable(metalCodeInfo.getCodeNumberRefrnone()).orElse(BigDecimal.ZERO); // 삼성선물 주문 단위 중량
		if(samsungOrderWt.compareTo(BigDecimal.ZERO) == 0) throw new CommCustomException(batchOrderModel.getPrefix() + " 삼성선물 주문 단위 중량이 null이거나 0입니다.");
		batchOrderModel.setSamsungOrderWt(samsungOrderWt.intValue()); // 삼성선물 주문 단위 중량
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 주문 정합성 체크 단계
	 * </pre>
	 * @date 2022. 10. 12.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 12.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @throws CommCustomException
	 * @throws Exception
	 */
	private void orderValidation(BatchOrderModel batchOrderModel) throws CommCustomException, Exception {

		// LME 사이드카 발동여부
		if(
			(StringUtils.equals(batchOrderModel.getSleMthdCode(), SleMthdCode.LIVE.getCode())
					|| StringUtils.equals(batchOrderModel.getSleMthdCode(), SleMthdCode.LIMIT.getCode())
			) && wrtmCnclMapper.chkLmeSidecar(batchOrderModel) > 0 ) throw new CommCustomException(batchOrderModel.getPrefix() + " 사이드카[LME] 발동");

		// 환율 사이드카 발동여부
		if(
			(StringUtils.equals(batchOrderModel.getSleMthdCode(), SleMthdCode.LIVE.getCode())
					|| StringUtils.equals(batchOrderModel.getSleMthdCode(), SleMthdCode.LIMIT.getCode())
			) && wrtmCnclMapper.chkFxSidecar(batchOrderModel) > 0 ) throw new CommCustomException(batchOrderModel.getPrefix() + " 사이드카[환율] 발동");

		/* ITM_SN(아이템 순번)에 해당되는 IT_ITM_INFO_BAS(상품_아이템 기본)의 WT_CHANGE(중량 변동) 값을 새로 가져오는 대신
		   기존 OR_ORDER_BAS 테이블의 WT_CHANGE의 값을 사용한다. */

		// 판매 가격 및 프리미엄 가격에 따른 주문 금액 정보 계산
		if(StringUtils.equals(batchOrderModel.getSleMthdCode(), SleMthdCode.LIVE.getCode())
				|| StringUtils.equals(batchOrderModel.getSleMthdCode(), SleMthdCode.LIMIT.getCode())
		  )
		{
			// 실시간 판매 가격 정보 조회 및 체크
			String brandCode = batchOrderModel.getBrandCode();
			//브랜드 무관일 경우 "주문상세테이블" 의 실제 brand_code 사용
			if(brandCode.equals("0000000000")) {
				brandCode = batchOrderModel.getOrderBasDtlList().get(0).getBrandCode();
			}

			log.warn("{} >> 실시간 판매 가격 정보 조회 시작: metalCode:{}, itmSn:{}, dstrctLclsfCode:{}, brandGroupCode:{}, brandCode:{}"
					, batchOrderModel.getPrefix()
					, batchOrderModel.getMetalCode(), batchOrderModel.getItmSn(), batchOrderModel.getDstrctLclsfCode(), batchOrderModel.getBrandGroupCode(), brandCode);

			batchOrderModel.setPrSelVO(Optional.ofNullable(pcInfoService.getNewestPrSelRltm(batchOrderModel.getMetalCode()
					, batchOrderModel.getItmSn()
					, batchOrderModel.getDstrctLclsfCode()
					, batchOrderModel.getBrandGroupCode()
					, brandCode
					, DateUtil.getNowDateTime("yyyyMMdd"))).orElseThrow(() -> {return new CommCustomException("실시간 판매가격 정보 미존재");}));

			log.warn("{} >> 실시간 판매 가격 정보 조회 batchOrderModel.getPrSelVO() 존재 확인 : {}", batchOrderModel.getPrefix(), batchOrderModel.getPrSelVO());

			// 선물 SKIP 여부, 선물 틱 설정 값 등 정보 조회
			BigDecimal threemonthLmePc = Optional.ofNullable(batchOrderModel.getPrSelVO().getThreemonthLmePc()).orElse(BigDecimal.ZERO); // 3개월 LME 가격(3M 가격)
			//증거금 취소주문으로 SELL Position(B: BUY, S: SELL)
			batchOrderModel.setCommFtrsFshgMngVO(Optional.ofNullable(commFtrsFshgMngService.getFtrsFshgMngRetVo(batchOrderModel.getMetalCode(), "S", threemonthLmePc)).orElseThrow(() -> {return new CommCustomException("선물 SKIP 여부, 선물 틱 설정 값 등 정보 미존재");}));
			log.warn("{} >> 실시간 판매 가격 정보 조회 (선물 SKIP 여부, 선물 틱 설정 값 등 정보 조회) : {}", batchOrderModel.getPrefix(), batchOrderModel.getCommFtrsFshgMngVO());

			// LIVE와 고정가가 DB에 넣을 때 같이 쓰기에 담아준다.
			batchOrderModel.setClaimPremiumNo(batchOrderModel.getPrSelVO().getPremiumNo());

			String lmePcRltmSn = batchOrderModel.getPrSelVO().getLmePcRltmSn();  // LME 가격 실시간 순번
			String ehgtPcRltmSn = batchOrderModel.getPrSelVO().getEhgtPcRltmSn(); // 환율 가격 실시간 순번

			log.warn("{} >> LME 가격 실시간 순번 (lmePcRltmSn) : {}, {}", batchOrderModel.getPrefix(), lmePcRltmSn, lmePcRltmSn.substring(0, 14));
			log.warn("{} >> 환율 가격 실시간 순번 (ehgtPcRltmSn) : {}, {}", batchOrderModel.getPrefix(), ehgtPcRltmSn, ehgtPcRltmSn.substring(0, 14));

			long currentTime = System.currentTimeMillis();
			log.warn(">> currentTime : " + currentTime);
			SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmss");

			// LME 순번 값 체크 및 LME 수집 시간 간격 체크
			if(StringUtils.isEmpty(lmePcRltmSn)) {
				throw new CommCustomException("[1]현재 일시적인 문제로 주문 및 시세 제공이 불가능합니다,\n관리자에게 문의 바랍니다.");
			} else {
				Date lmeDate = dateTimeFormat.parse(lmePcRltmSn.substring(0, 14));
				long lmeTime = lmeDate.getTime();
				log.warn("{} >> lmeTime calc : {}, {}", batchOrderModel.getPrefix(), lmeTime, (currentTime - lmeTime));
				if((currentTime - lmeTime) > (70*1000)) {
					throw new CommCustomException(batchOrderModel.getPrefix() +" [2]현재 일시적인 문제로 주문 및 시세 제공이 불가능합니다,\n관리자에게 문의 바랍니다.");
				}
			}

			// 환률 순번 값 체크 및 환률 수집 시간 간격 체크
			if(StringUtils.isEmpty(ehgtPcRltmSn)) {
				throw new CommCustomException(batchOrderModel.getPrefix() + " [3]현재 일시적인 문제로 주문 및 시세 제공이 불가능합니다,\n관리자에게 문의 바랍니다.");
			} else {
				Date ehgtDate = dateTimeFormat.parse(ehgtPcRltmSn.substring(0, 14));
				long ehgtTime = ehgtDate.getTime();
				log.warn("{} >> ehgtTime calc : {}, {}", batchOrderModel.getPrefix(), ehgtTime, (currentTime - ehgtTime));
				if((currentTime - ehgtTime) > (70*1000)) {
					throw new CommCustomException(batchOrderModel.getPrefix() +" [4]현재 일시적인 문제로 주문 및 시세 제공이 불가능합니다,\n관리자에게 문의 바랍니다.");
				}
			}

			// 프리미엄 가격 정보 조회 및 체크
			batchOrderModel.setLivePremiumVO(Optional.ofNullable(pcInfoService.getLivePremiumInfo("present", batchOrderModel.getClaimPremiumNo())).orElseThrow(
						() -> {return new CommCustomException(batchOrderModel.getPrefix() + " 프리미엄 가격 미존재,\n관리자에게 문의 바랍니다.");}
						));
			log.warn("{} >> 프리미엄 가격 정보 조회 batchOrderModel.getLivePremiumVO() 존재 확인 : {}", batchOrderModel.getPrefix(), batchOrderModel.getLivePremiumVO());

			// LIVE와 고정가가 DB에 넣을 때 같이 쓰기에 담아준다.
			if(batchOrderModel.getLivePremiumVO() != null) {
				log.warn("{} >> 프리미엄 가격 정보 조회 batchOrderModel.getLivePremiumVO() : {}", batchOrderModel.getPrefix(), String.valueOf(batchOrderModel.getLivePremiumVO()));
				BigDecimal premiumStdrAmount = Optional.ofNullable(batchOrderModel.getLivePremiumVO().getPremiumStdrAmount()).orElse(BigDecimal.ZERO); // 프리미엄 기준 금액
				BigDecimal dstrctChangeAmount = Optional.ofNullable(batchOrderModel.getLivePremiumVO().getDstrctChangeAmount()).orElse(BigDecimal.ZERO); // 권역 변동 금액
				BigDecimal brandGroupChangeAmount = Optional.ofNullable(batchOrderModel.getLivePremiumVO().getBrandGroupChangeAmount()).orElse(BigDecimal.ZERO); // 브랜드 그룹 변동 금액
				BigDecimal brandChangeAmount = Optional.ofNullable(batchOrderModel.getLivePremiumVO().getBrandChangeAmount()).orElse(BigDecimal.ZERO); // 브랜드 변동 금액
				BigDecimal compPremiumSum = premiumStdrAmount.add(dstrctChangeAmount).add(brandGroupChangeAmount).add(brandChangeAmount); // 판매 프리미엄 금액과 비교용

				log.warn(">> 판매 프리미엄 금액과 비교 : " + compPremiumSum.longValue() + ", " + batchOrderModel.getLivePremiumVO().getSlePremiumAmount());
				// 프리미엄 기준 금액 + 권역 변동 금액 + 브랜드 그룹 변동 금액 + 브랜드 변동 금액의 합이 판매 프리미엄 금액과 다르면 주문 불가
				if(compPremiumSum.longValue() != batchOrderModel.getLivePremiumVO().getSlePremiumAmount()) {
					throw new CommCustomException("판매 가격 설정을 확인해야 합니다,\n관리자에게 문의 바랍니다.");
				}

				batchOrderModel.setClaimPremiumPc(new BigDecimal(String.valueOf(batchOrderModel.getLivePremiumVO().getSlePremiumAmount()))); // 판매 프리미엄 금액
			}

			// 취소 상품단가 : endPc(종료 가격) + slePremiumAmount(판매 프리미엄 금액)
			long calcGoodsUntpc = batchOrderModel.getPrSelVO().getNonPremiumEndPc() + batchOrderModel.getLivePremiumVO().getSlePremiumAmount();

			// 가격 정보 셋팅 (배송비, 공급가, 부가세, 판매가 계산 제외 - 배송비 때문)
			setLivePriceInfo(batchOrderModel, calcGoodsUntpc);

		}else {
			/*
			 * 고정가 판매 일 경우 반대매매시 Master 테이블(Order 테이블의 가격을 그대로 가져와서 적용한다.
			 * 2023-01-20일 김지훈 팀장과 협의 결과
			 * 고객에게는 원래의 금액에 취소 수수료만 받기로 함.
			 */
			// 반대매매 가격 정보 셋팅
			setFixPriceInfo(batchOrderModel);
		}
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 반대 매매에 대한 판매 방식이 고정가격인 경우의 가경정보를 설정한다.
	 * </pre>
	 * @date 2023. 01. 26.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 01. 26.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @throws Exception
	 */
	private void setFixPriceInfo(BatchOrderModel batchOrderModel) throws Exception {
		log.warn("{} >> setFixPriceInfo > orderNo :{}", batchOrderModel.getOrderNo());

		String premiumNo        = batchOrderModel.getPremiumNo();    //원주문 프리미엄 번호
		BigDecimal premiumPc    = batchOrderModel.getPremiumPc();    // 원주문 프리미엄 가겨
		long goodsUntpc 		= batchOrderModel.getGoodsUntpc();   // 원주문 상품단가
		long orderPc 			= batchOrderModel.getOrderPc(); 		// 원주문 주문가격
		long wtChangegld 		= batchOrderModel.getWtChangegld();  // 원주문 중량변동금

		batchOrderModel.setClaimPremiumNo(premiumNo);                // 취소 프리미엄 번호
		batchOrderModel.setClaimPremiumPc(premiumPc);                // 취소 프리미엄 가격
		batchOrderModel.setClaimGoodsUntpc(goodsUntpc);              // 취소 상품단가
		batchOrderModel.setClaimOrderPc(orderPc);                    // 취소 주문가겯
		batchOrderModel.setClaimWtChangegld(wtChangegld);            // 취소 중량변동금

		log.warn("==> ClaimGoodsUntpc:{}, ClaimOrderPc:{}, ClaimWtChangegld:{}", goodsUntpc, orderPc, wtChangegld);

		long expectDlvrf = 0L;
		if(batchOrderModel.getOrderDlvrfBas() != null) {
			expectDlvrf = batchOrderModel.getOrderDlvrfBas().getExpectDlvrf().longValue();		// 원주문 예상배송비
		}

		long splpc =  batchOrderModel.getSplpc();				// 원주문 공급가
		long slepc = batchOrderModel.getSlepc();					// 원주문 판매가
		long vat   = batchOrderModel.getVat();                  	// 원주문 부가세

		batchOrderModel.setExpectDlvrf(expectDlvrf);				// 취소 예상 배상비
		batchOrderModel.setClaimSplpc(splpc);                   	// 취소 공급가
		batchOrderModel.setClaimSlepc(slepc);					// 취소 판매가
		batchOrderModel.setClaimVat(vat);						// 취소 부가세

		log.warn("==> ExpectDlvrf :{}, ClaimSplpc:{}, ClaimSlepc:{}, ClaimVat:{}", expectDlvrf, splpc, slepc, vat);
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 반대 매매에 대한 판매 방식이 Live인 경우의 가경정보를 설정한다.
	 * </pre>
	 * @date 2022. 10. 12.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 12.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel			원주문 정보 및 취소 정보 포함 model
	 * @param calcGoodsUntpc		새로 계산 되어진 상품 단가
	 * @throws CommCustomException
	 * @throws Exception
	 */
	private void setLivePriceInfo(BatchOrderModel batchOrderModel, long calcGoodsUntpc) throws CommCustomException, Exception {
		/* 원주문 주문중량 */
		int orderWt = batchOrderModel.getTotRealOrderWt(); //총 실제 주문 중량 (OR_ORDER_BAS.TOT_REAL_ORDER_WT)
		log.warn("{} >> calcGoodsUntpc :{}, batchOrderModel :{}", batchOrderModel.getPrefix(), calcGoodsUntpc, String.valueOf(batchOrderModel));

		/* 취소 상품단가 -> 기존 주문시에 생성한 상품단가 대신 Claim 주문시 새로 계산한다. */
		long claimGoodsUntpc = Math.round(calcGoodsUntpc / 1000.0) * 1000;

		/* 취소 주문가격 : (취소 상품단가 * 총 실제 주문 중량) */
		long claimOrderPc = (claimGoodsUntpc * orderWt);
		log.warn("{} >> orderPc : {}, goodsUntpc : {}, orderWt : {}", batchOrderModel.getPrefix(), claimOrderPc, claimGoodsUntpc, orderWt);

		/**
		 *  취소 중량변동금 : (취소 상품단가 * 중량 변동)
		 *  중량변동은(WtChange) IT_METAL_ITM_WT_CHANGE_BAS(중량 변동금 관리 기본) 테이블에서 새로 가져 오지 않고
		 *  기존 주문 테이블에 있는것을 사용
		 *  중량변동인 변경 가능하고 계산할때마 새로 가져와야 한다면 신규로 가져오는 것은 변경해야 함
		 * */
		long claimWtChangegld = Double.valueOf( claimGoodsUntpc * batchOrderModel.getWtChange() ).longValue();
		log.warn("{} >> wtChangegld : {}", batchOrderModel.getPrefix(), claimWtChangegld);

		batchOrderModel.setClaimGoodsUntpc(claimGoodsUntpc);
		batchOrderModel.setClaimOrderPc(claimOrderPc);
		batchOrderModel.setClaimWtChangegld(claimWtChangegld);

		/*
		 *  예상배송비는 기존 주문시 계산된 OR_DLVRF_BAS.EXPECT_DLVR 사용한다.
		 *  신규 배송비를 가져와야 한다면 변경해야함
		 */
		long expectDlvrf = 0L;
		if(batchOrderModel.getOrderDlvrfBas() != null) {
			expectDlvrf = batchOrderModel.getOrderDlvrfBas().getExpectDlvrf().longValue();
		}

		/** 취소 공급가 **/
		long claimSplpc =  ( claimGoodsUntpc * orderWt ) + claimWtChangegld + expectDlvrf;

		/** 취소 부가세 **/
		long claimVat = (long) (claimSplpc * 0.1);

		/** 취소 판매가 **/
		long claimSlepc = claimSplpc + claimVat;
		log.warn("{} >> splpc : {}, vat : {}, slepc : {}, expectDlvrf : {}", batchOrderModel.getPrefix(), claimSplpc, claimVat, claimSlepc, expectDlvrf);

		batchOrderModel.setExpectDlvrf(expectDlvrf);  // 취소 예상배송비
		batchOrderModel.setClaimSplpc(claimSplpc);	 // 취소 공급가
		batchOrderModel.setClaimSlepc(claimSlepc);	 // 취소 판매가
		batchOrderModel.setClaimVat(claimVat);		 // 취소 부가세
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 반대매매 관련 테이블 생성 후 관련 외부 API 작업, 메일, SMS 작업등을 처리한다.
	 * </pre>
	 * @date 2022. 10. 12.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 12.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 */
	private void wrtmOrderComplete(BatchOrderModel batchOrderModel) {
		try {
			//판매방식: 01.LIVE, 02.고정가, 03.LIMIT(지정가)
			if(StringUtils.equals(batchOrderModel.getSleMthdCode(), SleMthdCode.LIVE.getCode())
					|| StringUtils.equals(batchOrderModel.getSleMthdCode(), SleMthdCode.LIMIT.getCode())
			  ){
				// 실시간 가격일시 삼성선물 호출
				callSamsung(batchOrderModel);

				// FX 호출
				callFX(batchOrderModel);

				/*
				  선물, 선물환 만기일이 다음달로 변경시 변경 거래로 인한 PO 테이블 Update 처리는 FS, FX 서버에서 처리하기로 이광현 과장과 협의함.
				*/
			}

			// Oms 통신 -- 물류 가주문 에 대한 취소주문
		    callOms(batchOrderModel);

			// 이월렛 호출 -- 환불금이 있는 경우에 한해서
		    long refndAmount 			= batchOrderModel.getClaimBas().getRefndAmount();
		    if(refndAmount > 0) {
		    	callEwallet(batchOrderModel);
		    }

		    // 결제방식이 이월렛 + 구매자금일 경우에 별도의 매매계약서 취소, 세금 계산서 발행 취소를 진행한다.
		    if(StringUtils.equals("9030", batchOrderModel.getSetleMthdDetailCode())) {
		    	// 결제방식이 이월렛 + 구매자금일 경우 매매계약서 취소를 진행한다.
		    	callTrdeCtrtc(batchOrderModel);
		    }

	    	// 세금 계산서 발행 취소를 진행한다.
	    	callTaxbill(batchOrderModel);

			// 메일 발송, 평균가 주문인 경우에는 메일 발송하지 않는다.
	    	String cntrctOrderNo = batchOrderModel.getCntrctOrderNo();
	    	if( StringUtils.isEmpty(cntrctOrderNo) ) {
	    		msgService.sendWrtmOrderCnclMail(batchOrderModel);
	    	}
			// SMS 발송
		    msgService.sendWrtmOrderCnclSms(batchOrderModel, "78", null, null);

		    // 회원_업체 정보 기본 테이블의 연체 건수 증가 시켜 업체에 페널티를 적용한다.(MB_ENTRPS_INFO_BAS.ARRRG_CO)
		    wrtmCnclMapper.increaseArrrgCo(batchOrderModel);
		    wrtmCnclMapper.registArrrgCoForHist(batchOrderModel);

		    // 주문_여신 사고 이력 테이블 등록(OR_CDTLN_ACDNT_HST)
		    batchOrderModel.setAcdntHistSeCode("10"); //사고 이력 구분 코드(10. 연체(증거금), 20. 사고(전자상거래보증, 케이지크레딧))
		    wrtmCnclMapper.registOrCdtlnAcdntHst(batchOrderModel);

		}catch (Exception e) {
			log.error("{} : {}",  batchOrderModel.getPrefix(), ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금취소 주문의 선물 거래 후 BL별 성공건이 존재하고 거래한 만기일이
	 *        PO 테이블의 만기일이 상이할 경우 PO 테이블의 선무 만기일을 UPDATE 처리한다.
	 * </pre>
	 * @date 2023. 1. 5.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 1. 5.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 */
	private void callPoTblUpdate(BatchOrderModel batchOrderModel) {
		String orderNo = batchOrderModel.getOrderNo();
		log.warn("[callPoTblUpdate] IN --> ORDER_NO[{}]", orderNo);
		try {
			for(ClaimDtlVO claimDtl : batchOrderModel.getClaimBlList()) {
				if(claimDtl.isUpdateFtrsExprtnDe()) {            		//신규 만기일 대체 여부거 true인 경우
					/*
					 * - BL당 선물 주문 응답 성공 리스트 가져오기, 응답 선물 상태 코드가 체결(30) 건수를 파악하여
					 * - BL별 성공건이 1건이라도 존재하면 PO 테이블의 선물 만기일을 UPDATE 한다.
					 */
					int ftrsOrderResOk = claimMapper.selectClaimOrderFtrsOkCount(claimDtl);

					if(ftrsOrderResOk > 0){
						wrtmCnclMapper.updatePOFtrsExprtnDe(claimDtl);
						wrtmCnclMapper.insertItPurchsInfoBasHst(claimDtl);

						log.warn("[callPoTblUpdate] PO UPDATE SUCCESS - ORDER_NO[{}], BL_NO[{}], 선물만기일[{}]"
								, orderNo, claimDtl.getBlNo(), claimDtl.getNextFtrsExprtnDe());
					}
				}
			}
		}catch(Exception e) {
			log.error("ORDER_NO[{}] PO 테이불 만기일 수정 에러. {}", orderNo, ExceptionUtils.getStackTrace(e));
			msgService.sendWrtmOrderCnclSms(batchOrderModel, "45", orderNo, "증거금미납건 취소주문을 위한 배치작업시 선물요청 중 Po 테이블 만기일 update 에러.");
		}
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소 주문을 위한 삼성선물로 Sell 주문 처리한다.
	 * </pre>
	 * @date 2022. 10. 14.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 14.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @throws Exception
	 */
	private void callSamsung(BatchOrderModel batchOrderModel) throws Exception{

		String orderNo = batchOrderModel.getOrderNo();
		log.warn("[callSamsung] IN --> ORDER_NO[{}]", orderNo);

		/** 삼성선물 신규 생성 Key 리스트 **/
		List<String> ftrnNoList = new ArrayList<String>();

		try {
			// 삼성선물 공통 주문 조건 정보
			CommFtrsFshgMngVO commFtrsFshgMngVO = batchOrderModel.getCommFtrsFshgMngVO();
			if(commFtrsFshgMngVO == null) {
				log.warn("ORDER_NO[{}] 삼성선물 공통 주문 조건 정보가 null로 인해 삼성선물 주문 진행 불가.", orderNo);
				return;
			}

			//판매방식: 01.LIVE, 02.고정가, 03.LIMIT(지정가) 에 따라 TICK 정보가 다름
			int ftrsTick = 0;
			if(StringUtils.equals(batchOrderModel.getSleMthdCode(), SleMthdCode.LIVE.getCode())){
				ftrsTick = commFtrsFshgMngVO.getFtrsTick();
			}else {
				ftrsTick  = commFtrsFshgMngVO.getFtrsLimitTick();
			}

			// 삼성선물 호가 단위
			double ftrsQuoteUnit = commFtrsFshgMngVO.getQuoteUnit();

			/** 삼성선물 계좌 번호 **/
//			String requstAcnutNo = CryptoUtil.encryptAES256(orProperty.getSamsungAcnutNo());
//			batchOrderModel.setRequstAcnutNo(requstAcnutNo);

			// 삼성선물 마스터 테이블 생성
			for(ClaimDtlVO claimDtl : batchOrderModel.getClaimBlList()) {

				batchOrderModel.setClaimBlDetail(claimDtl);

				// 삼성선물은 삼성선물 주문 단위 중량(ex. 메탈코드 7 알루미늄 25톤) 단위로 주문 하기때문에 삼성선물 주문 단위 중량으로 나눠서 1건씩 호출
				// MatchedOrderedBnt -> OR_ORDER_DTL.REAL_ORDER_WT -> OR_CANCL_EXCHNG_RTNGUD_DTL.CANCL_EXCHNG_RTNGUD_WT
				int orderQy = claimDtl.getCanclExchngRtngudWt() / batchOrderModel.getSamsungOrderWt();
				batchOrderModel.setItPurchsInfoBas(Optional.ofNullable(wrtmCnclMapper.selectItPurchsInfoBas(batchOrderModel)).orElseThrow(() -> {return new CommCustomException("[callSamsung] PO 테이블 미존재");}));

				// PO 만기일이 현재일을 지난 경우에 다음달 선물 만기일로 주문한다..
				String toDay = DateUtil.getNowDate();
				String ftrsExprtnDe = batchOrderModel.getItPurchsInfoBas().getFtrsExprtnDe(); //선물 만기일
				int intervalDay = DateUtil.intervalDay(toDay, ftrsExprtnDe); //금일, 만기일
				log.warn("ORD_NO [{}] - 금일: {}, 선물 만기일: {}, 날짜 차이: {}, 다음달 선물 만기일: {}"
						, orderNo, toDay, ftrsExprtnDe, intervalDay, batchOrderModel.getNextFtrsExprtnDe());

				// 현재일 기준 만기일 D-2이내인 경우(선물, 선뮬환 모두) 다음달 만기일 지정한다.
				if(intervalDay < 3) {
					String nextFtrsExprtnDe = batchOrderModel.getNextFtrsExprtnDe();
					if(nextFtrsExprtnDe == null) new CommCustomException("[callSamsung] 다음달 선물 만기일 미존재");

					/*  --> 증거금 주문 취소시 선물 만기일이 지난 경우
					   1. callSamsung 에서는 기존 만기일을 다음달 만기일로 OR_ORDER_FTRS_BAS 테이블에 신규 만기일을 등록하여 fs가 선물 거래하도록 처리
					   2. 전체 프로세스가 끝난 후에 증거금 주문취소의 각 BL 선물 응답이 Success인 경우에
					      PO테이블의 해당 BL의 선물환 만기일과 비교하여 다를 경우 신규 만기일로 PO테이블 UPDATE 처리 함.
					*/
					claimDtl.setUpdateFtrsExprtnDe(true);								//신규 만기일 대체 여부 표시
					claimDtl.setNextFtrsExprtnDe(nextFtrsExprtnDe);                     //수정 만기일 입력
					batchOrderModel.getItPurchsInfoBas().setFtrsExprtnDe(nextFtrsExprtnDe); 	//신규 만기일갑으로 대체
				}

				String ftrsCmpnyTrgetCode = batchOrderModel.getItPurchsInfoBas().getFtrsCmpnyTrgetCode();
				if(StringUtil.isEmpty(ftrsCmpnyTrgetCode)) {
					throw new CommCustomException("[callSamsung] 선물사 대상 코드 미존재");
				}

				// 선물사 다중화로 선물사 대성코드에 따라 계좌가 변경됨.
				if(StringUtils.equals(CommFtrsConstant.FTRS_SAMSUNG_CMPNY_CODE, ftrsCmpnyTrgetCode)){
					batchOrderModel.setRequstAcnutNo(CryptoUtil.encryptAES256(orProperty.getSamsungAcnutNo()));		//삼성증권
				}else if(StringUtils.equals(CommFtrsConstant.FTRS_EBEST_CMPNY_CODE, ftrsCmpnyTrgetCode)){
					batchOrderModel.setRequstAcnutNo(CryptoUtil.encryptAES256(orProperty.getEbestAcnutNo()));		//이베스트증권
				}else {
					throw new CommCustomException("[callSamsung] 선물사 대상 코드 오류 [" + ftrsCmpnyTrgetCode + "]");
				}

				for(int i = 0 ;  i < orderQy ; i++) {
					// 채번
					String ftrsRequstOrderNo = claimService.getNewOrderFtrsNo();

					// SELL Position으로 Tick 만큼 주문시 (-) 처리
					BigDecimal requstOrderUntpc = batchOrderModel.getPrSelVO().getThreemonthLmePc()
							.subtract(BigDecimal.valueOf(ftrsQuoteUnit * ftrsTick));

					batchOrderModel.setFtrsRequstOrderNo(ftrsRequstOrderNo);
					// 아래의 1은 삼성선물 주문 단위 중량(ex. 메탈코드 7 알루미늄 25톤)을 의미, 삼성선물 주문 단위 중량 단위로 호출하는 방식으로 정책 변경
					batchOrderModel.setRequstOrderQy(1); // 1은 25톤을 의미
					batchOrderModel.setRequstOrderUntpc(String.valueOf(requstOrderUntpc));

					wrtmCnclMapper.insertSamsungBase(batchOrderModel);
					// 호출한 KEY값 저장 -> 추후 실패했는지 성공했는지 파악하기 위해
					ftrnNoList.add(ftrsRequstOrderNo);
				}
			}

			// OR_ORDER_FTRS_BAS 에 등록된 선물 요청 주문 번호들 세팅
			batchOrderModel.setFtrnNoList(ftrnNoList);

			if(!StringUtils.equals(Optional.ofNullable(commFtrsFshgMngVO.getSkipAt()).orElse("N"), "Y")) {
				if(ftrnNoList.size() > 0) {
				// skip 사용 여부가 아닌 경우, 삼성 선물 주문 요청 및 취소 로직 수행
					boolean isSuccess = false;
					Map<String, Object> rqsObj = null;

					try {
						rqsObj = new HashMap<String, Object>();
						rqsObj.put("orderNo", orderNo);
						rqsObj.put("canclExchngRtngudNo", batchOrderModel.getCanclExchngRtngudNo());
						rqsObj.put("userId", "BATCH");
						// Sell 주문 URL 변경 필요
						log.warn("ORDER_NO[{}] >> 삼성선물 주문 전송 : [{}], [{}]", orderNo, rqsObj, orProperty.getSamsungClaimUrl());

						Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getSamsungClaimUrl(), rqsObj);
						log.warn("ORDER_NO[{}] >> 삼성선물 주문 응답 : {}", orderNo, String.valueOf(resObj));

						if( resObj != null
								&& StringUtils.equals(String.valueOf(resObj.get(ClaimConstants.API_RESULT_KEY)), ClaimConstants.API_SUCCESS_CODE))
						{

							List<OrderFtrsBasVO> ftrsOrderResFails = new ArrayList<OrderFtrsBasVO>();
							// 0.5초씩 쉬면서 설정 시간 초만큼 주문 요청 성공여부 체크
							for(int i = 0 ; i < orProperty.getSamsungTimeoutsec() * 2  ; i ++) {
								Thread.sleep(500);
								// 선물 주문 응답 실패 리스트 가져오기, 응답 선물 상태 코드가 체결(30)이 아닌 것 또는 NULL인 것을 조회하여 실패 건 갯수를 파악
								ftrsOrderResFails = claimMapper.selectClaimOrderFtrsResponse(batchOrderModel);

								if(ftrsOrderResFails.size() == 0){
									isSuccess = true;
									break;
								}
							}

							log.warn("삼성선물 응답성공 코드 '30'이 아닌것을 조회하여 실패 건 개수 {}/{}, 성공여부:{}"
									, ftrsOrderResFails.size(), ftrnNoList.size(), isSuccess);

							if(!isSuccess) {
								// 삼성선물 실패 로직 구현
								if(ftrsOrderResFails.size() > 0) {
									batchOrderModel.setSamsungFailList(ftrsOrderResFails);
									cancelCallSamsung(batchOrderModel);
								}
							}
							//증거금 주문은 마일리지 처리 프로세스 없음
						}else {
							log.warn("ORDER_NO[{}] >> callSamsung > 삼성선물 기타 장애로 응답실패. ", orderNo);
							msgService.sendWrtmOrderCnclSms(batchOrderModel, "45", StringUtils.join(ftrnNoList, ","), "증거금미납건 취소주문을 위한 배치작업시 선물요청 중 기타 장애로 응답실패");
						}
					}catch(Exception e) {
						log.error("ORDER_NO[{}] 삼성선물 송신/수신 에러. {}", orderNo, ExceptionUtils.getStackTrace(e));
						msgService.sendWrtmOrderCnclSms(batchOrderModel, "45", StringUtils.join(ftrnNoList, ","), "증거금미납건 취소주문을 위한 배치작업시 선물요청 중 송신/수신 에러.");
					}
				}
			} else {
				// skip 사용 여부인 경우, 삼성 선물 주문 요청을 하지 않는다.
				log.warn("ORDER_NO[{}] 삼성선물 주문 요청 call : skip사용, 삼성 선물 주문 요청하지 않음.", orderNo);
			}
		}catch(Exception e) {
			log.error("ORDER_NO[{}] OR_ORDER_FTRS_BAS 등록 에러. {}", orderNo, ExceptionUtils.getStackTrace(e));
			msgService.sendWrtmOrderCnclSms(batchOrderModel, "45", StringUtils.join(ftrnNoList, ","), "증거금미납건 취소주문을 위한 배치작업시 선물요청 중 기타에러.");
		}
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 삼성선물 주문 실패에 대한 취소 주문을 처리한다.
	 * </pre>
	 * @date 2022. 10. 14.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 14.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @throws CommCustomException
	 * @throws Exception
	 */
	private void cancelCallSamsung(BatchOrderModel batchOrderModel) throws Exception {
		String orderNo = batchOrderModel.getOrderNo();
		log.warn("[cancelCallSamsung] IN --> ORDER_NO[{}]", orderNo);

		List<String> cancelFtrnNoList = null;
		List<String> requstWonOrderNoListByCancel = null;
		boolean allFailStatus = false; // (true : 전부다 실패인 경우, false : 한 건이라도 성공이 있는 경우)

		try {
			cancelFtrnNoList = new ArrayList<String>();
			requstWonOrderNoListByCancel = new ArrayList<String>(); // 실패 건들의 원주문번호 리스트

			int ftrnNoListSize = batchOrderModel.getFtrnNoList().size(); // 선물 주문 요청 건수
			int samsungFailListSize = batchOrderModel.getSamsungFailList().size(); // 선물 주문 체결(30)이 아닌 (요청 실패 및 요청상태, null) 건수
			if( ftrnNoListSize == samsungFailListSize ) {
				// 전부다 실패인 경우
				allFailStatus = true;
			}
			log.warn("ORDER_NO[{}] >> allFailStatus : {}", orderNo, allFailStatus);

			for(OrderFtrsBasVO failVo : batchOrderModel.getSamsungFailList()) {
				log.warn("ORDER_NO[{}] >> cancelCallSamsung:{} > RspnsFtrsSttusCode() : {}", failVo.getOrderNo(), failVo.getFtrsRequstOrderNo(), failVo.getRspnsFtrsSttusCode());
				// 삼성선물 실패건 중에서 상태가 '10'인 건만 취소 요청을 보냄
				// 2021.12.08 삼성선물 5초 동안 응답 코드 없는 CASE 발생해서 NULL 건 추가
				if (StringUtils.isBlank(failVo.getRspnsFtrsSttusCode())
						|| StringUtils.equals(failVo.getRspnsFtrsSttusCode(), "10")) {
					// 해당 취소건의 원 주문 Key값 셋팅
					batchOrderModel.setRequstWonOrderNo(failVo.getFtrsRequstOrderNo());
					requstWonOrderNoListByCancel.add(failVo.getFtrsRequstOrderNo()); // 실패 건들의 원주문번호 리스트 담기, 실패로 분류된 선물요청주문의 체결을 확인하기 위함

					// 채번
					String ftrsRequstOrderNo = claimService.getNewOrderFtrsNo();
					batchOrderModel.setFtrsRequstOrderNo(ftrsRequstOrderNo);
					// 정상 실패 여부를 확인하기 위해 키값 저장 -> 정책변경으로 실패 성공여부를 파악하지않아 필요는 없지만 살려둠 -> 파악하는 것으로 정책 다시 변경 20220517
					cancelFtrnNoList.add(ftrsRequstOrderNo);

					wrtmCnclMapper.insertSamsungCancel(batchOrderModel);
				}
			}
		}catch(Exception e) {
			log.error("ORDER_NO[{}] OR_ORDER_FTRS_BAS 취소주문 등록 에러. {}", orderNo, ExceptionUtils.getStackTrace(e));
		}

		batchOrderModel.setCancelFtrnNoList(cancelFtrnNoList); // 취소 주문 요청 키 값 리스트 batchOrderModel에 담기
		batchOrderModel.setRequstWonOrderNoListByCancel(requstWonOrderNoListByCancel); // 실패 건들의 원주문번호 리스트 batchOrderModel에 담기

		// 삼성선물 취소 콜
		if(cancelFtrnNoList.size() > 0 ) {

			try {
				String requstWonOrderNoListByCancelStr = StringUtils.join(requstWonOrderNoListByCancel, ",");
				log.warn("ORDER_NO[{}] >> cancelCallSamsung > 삼성선물 취소 요청 > 선물요청주문번호(원주문) : {}", orderNo, requstWonOrderNoListByCancelStr);
				// 취소 요청 발생 SMS 전송, 템플릿에 따라 SMS 전송을 처리한다.
				msgService.sendWrtmOrderCnclSms(batchOrderModel, "73", requstWonOrderNoListByCancelStr, null);

			} catch(Exception e) {
				log.error("ORDER_NO[{}] 삼성선물 취소 요청 발생에 의한 SMS전송 실패", orderNo);
			}

			try {
				log.warn("ORDER_NO[{}] >> cancelCallSamsung > 삼성선물 취소요청 전송[{}]", orderNo, orProperty.getSamsungCancelUrl());

				Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getSamsungCancelUrl(), Collections.singletonMap("orderNo", orderNo));
				log.warn(">> cancelCallSamsung > 삼성선물 취소요청 응답 : " + String.valueOf(resObj));

				if( resObj!= null
						&& StringUtils.equals(String.valueOf(resObj.get(ClaimConstants.API_RESULT_KEY)), ClaimConstants.API_SUCCESS_CODE))
				{
					// 취소 에서 60 실패 코드가 뜨면? -> 고려 하지않기로 했다 20210915 -> 다시 고려하기로.. 20220517

					/*
					 *  전부다 실패인 경우에만 5초간 응답 체크, 한건이라도 성공이 있는 경우 5초간 체크를 하지 않는다
					 *  실패 건들의 원주문 건(requstWonOrderNoListByCancel) 응답 선물 상태 코드가 체결인지 아닌지를 확인한다.
					 */
					if(allFailStatus) {
						// 실패 건들의 원주문 건(requstWonOrderNoListByCancel) 응답 선물 상태 코드 중 체결된 건을 담는다, 아직 활용 계획은 없지만 추후 활용을 대비, 담아 놓는다.
						List<OrderFtrsBasVO> samsungCancelFailList = new ArrayList<OrderFtrsBasVO>();
						// 0.5초씩 쉬면서 설정 시간 초만큼 실패 건들의 원주문 건(requstWonOrderNoListByCancel) 응답 선물 상태 코드가 체결인지 아닌지를 확인
						for(int i = 0 ; i < orProperty.getSamsungTimeoutsec() * 2  ; i ++) {
							Thread.sleep(500);
							// 실패 건들의 원주문 건(requstWonOrderNoListByCancel) 응답 선물 상태 코드가 체결인지 아닌지를 확인한다, 응답선물상태코드가 30인 것을 조회하여 성공 건 개수 파악
							samsungCancelFailList = wrtmCnclMapper.selectCancelSamsungResponse(batchOrderModel);
							if(samsungCancelFailList.size() > 0) {
								allFailStatus = false; // 한 건이라도 성공이 있는 경우로 변경
								break;
							};
						}
					}
				}else {
					log.warn("ORDER_NO[{}] >> cancelCallSamsung > 삼성선물 기타 장애로 응답실패. ", orderNo);
					msgService.sendWrtmOrderCnclSms(batchOrderModel, "45", "배치작업 삼성선물 취소 호출 실패", "증거금미납건 취소주문 배치착업증 삼성선물 기타 장애로 응답실패");
				}
			}catch(Exception e) {
				log.error("ORDER_NO[{}] 삼성선물 취소주문 송신/수신 에러. {}", orderNo, ExceptionUtils.getStackTrace(e));
				msgService.sendWrtmOrderCnclSms(batchOrderModel, "45", "배치작업 삼성선물 취소 호출 실패", "증거금미납건 취소주문 배치착업증 삼성선물 취소주문 송신/수신 에러");
			}
		}else {
			// 삼성선물 취소 호출 실패 -> 고려 하지않기로 했다 20210915 -> 다시 고려하기로 했지만 로직 상 변화 없음.. 20220517
			log.error("ORDER_NO[{}] 삼성선물 취소 호출 실패", orderNo);
			msgService.sendWrtmOrderCnclSms(batchOrderModel, "45", "배치작업 삼성선물 취소 호출 실패", "증거금미납건 취소주문 배치착업증 삼성선물 취소 호출 실패");
		}
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소 주문을 위해 하나은행 FX 쪽으로 선물환 SELL 주문을 처리한다.
	 * </pre>
	 * @date 2022. 10. 14.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 14.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 */
	private void callFX(BatchOrderModel batchOrderModel) {
		String orderNo = batchOrderModel.getOrderNo();
		log.warn("[callFX] IN --> ORDER_NO[{}]", orderNo);
		List<String> fxNoList = null;
			try {

				fxNoList = new ArrayList<String>();
				// 주문 디테일 테이블 생성
				for(ClaimDtlVO claimDtl : batchOrderModel.getClaimBlList()) {
					if(claimDtl.getCanclExchngRtngudWt() > 0) {

						batchOrderModel.setClaimBlDetail(claimDtl);

						// 채번
						//String fshgRequstOrderNo = DateUtil.getNowDateTime("yyyyMMdd")+ "-" + "2" + assignService.selectAssignValue("OR", "FSHG_REQUST_ORDER_NO", DateUtil.getNowDate(), batchOrderModel.getMberNo(), 10);
						String fshgRequstOrderNo = claimService.getNewOrderFshgNo();
						batchOrderModel.setFshgRequstOrderNo(fshgRequstOrderNo);

						 /*
						    PO테이블 조회
						    - 2021.12.07 PO 테이블의 선물환관리번호 필드(FSHG_MANAGE_NO) 추가
						    - IT_PURCHS_INFO_BAS 테이블의 bl번호에 해당하는
						    	만기일(FTRS_EXPRTN_DE), 선물환 거래 달러 금액 (FSHG_DELNG_DOLLAR_AMOUNT), 선물환 최초 중량 (FSHG_DLRY_ORG_WT)
						    	가져와 선물환 요청가격(REQUST_ORDER_PC)을 만든다
						    - REQUST_ORDER_PC(요청가격) = (FSHG_DELNG_DOLLAR_ORG_AMOUNT * CANCL_EXCHNG_RTNGUD_WT(REAL_ORDER_WT) ) / FSHG_DLRY_ORG_WT
						 */
						batchOrderModel.setItPurchsInfoBas(Optional.ofNullable(wrtmCnclMapper.selectItPurchsInfoBas(batchOrderModel)).orElseThrow(() -> {return new CommCustomException("callFX > PO 테이블 미존재");}));

						/*
						   - PO 만기일이 현재일을 지난 경우에 다음달 선물환 만기일로 주문을 진행한다.
						*/
						String toDay = DateUtil.getNowDate();
						String fshgExprtnDe = batchOrderModel.getItPurchsInfoBas().getFshgExprtnDe(); //선물환 만기일
						int intervalDay = DateUtil.intervalDay(toDay, fshgExprtnDe); //금일, 선물환 만기일
						log.warn("ORD_NO [{}] - 금일: {}, 선물환 만기일: {}, 날짜 차이: {}, 다음달 선물환 만기일: {}"
								, orderNo, toDay, fshgExprtnDe, intervalDay, batchOrderModel.getNextFshgExprtnDe());

						// 현재일 기준 만기일 D-2이내인 경우(선물, 선뮬환 모두) 다음달 만기일 지정한다.
						if(intervalDay < 3) {
							String nextFshgExprtnDe = batchOrderModel.getNextFshgExprtnDe();
							if(nextFshgExprtnDe == null) new CommCustomException("[callSamsung] 다음달 선물환 만기일 미존재");

							/*  --> 선물환 만기일이 지난 경우
							   1. 배치작업 단에서는 기존 만기일을 다음달 만기일로 OR_ORDER_FSHG_BAS 테이블에 신규 만기일을 등록하여 fx가 선물 거래하도록 처리
							   2. APP-FS 에서는 증거금 주문취소의 선물환거래 응답이 Success인 경우에 한해
							      PO 테이블의 해당 BL의 선물환 만기일과 비교하여 다를 경우 신규 만기일로 PO 테이블 UPDATE 처리하기로 함.
							*/
							batchOrderModel.getItPurchsInfoBas().setFshgExprtnDe(nextFshgExprtnDe); //신규 만기일로 대체
						}
						
						// 24-06-11 변경사항 : 해당 주문이 소량 구매 주문일 경우, 요청 주문 금액 계산 시 사용되는 취소교환반품중량(=주문중량) 대신
						//						삼성선물 주문 단위 중량(EX: 25)을 사용하도록 데이터 세팅
						if(StringUtils.equals(batchOrderModel.getSmlqyPurchsAt(), "Y")) {	// 소량 구매 여부가 Y이면
							log.warn("주문번호 : {}, 소량 구매 주문에 대한 추가 처리 start", orderNo);
							
							// 취소교환반품중량 대신 삼성선물 주문 단위 중량 세팅
							claimDtl.setCanclExchngRtngudWt(batchOrderModel.getSamsungOrderWt());
						}

						// 하나은행 fx
						// 2021.12.07 PO 테이블의 선물환관리번호 -> 요청청산번호 필드 추가
						// 2022.12.23 증거금 취소주문 경우 무조건 신규 주문 처리하기로 협의함(김지훈팀장-이시형부장)
						// 그로 인해 PO테이블의 FSHG_MANAGE_NO(선물환 관리 번호는 사용 안함)
						wrtmCnclMapper.insertHanaFxBase(batchOrderModel);

						fxNoList.add(fshgRequstOrderNo);
					}
				}

				Map<String, String> reqObj = new HashMap<String, String>();
				reqObj.put("userId", "BATCH");
				reqObj.put("orderNo", orderNo);
				reqObj.put("canclExchngRtngudNo", batchOrderModel.getCanclExchngRtngudNo());
				log.warn("ORDER_NO[{}] >> 하나은행 전송 : [{}], [{}]", orderNo, reqObj, orProperty.getFxOrderClaimUrl());

				Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getFxOrderClaimUrl(), reqObj);
				log.warn("ORDER_NO[{}] >> 하나은행 응답 : {}", orderNo, resObj);

				if( !(resObj != null
						&& StringUtils.equals(String.valueOf(resObj.get(ClaimConstants.API_RESULT_KEY)), ClaimConstants.API_SUCCESS_CODE)) )
				{
					msgService.sendWrtmOrderCnclSms(batchOrderModel, "46", StringUtils.join(fxNoList, ","), "증거금미납건 취소주문을 위한 배치작업시 선물환요청 중 통신에러");
				}
			} catch (Exception e) {
				log.error("[callFX] ORDER_NO[{}] : {}", orderNo, ExceptionUtils.getStackTrace(e));
				msgService.sendWrtmOrderCnclSms(batchOrderModel, "46", StringUtils.join(fxNoList, ","), "증거금미납건 취소주문을 위한 배치작업시 선물환요청 중 기타에러");
			}
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소주문을 위해 물류 쪽에 기존에 맺어진 물류 주문에 대해 가주문 취소 요청을 처리한다.
	 * </pre>
	 * @date 2022. 10. 14.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 14.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 */
	private void callOms(BatchOrderModel batchOrderModel) {
		String orderNo = batchOrderModel.getOrderNo();
		log.warn("[callOms] IN  --> ORDER_NO[{}]", orderNo);

		try {
			log.warn("ORDER_NO[{}] >> LoOmsUrl : {}", orderNo, orProperty.getLoOmsUrl());

			// 주문쪽에서는 주문 홀딩일 경우 증거금 주문 시, 물류 API 송신은 하지 않는다.
			// 그러나 증거금 반대매매의 경우 물류에서 제고 원복을 위해 무조건 OMS를 호출 하기로 협의함.(2023-01-09)
			String omsRceptNo = batchOrderModel.getOmsRceptNo();

			Map<String, String> reqObj = new HashMap<>();
			reqObj.put("ecOrderNo", orderNo);           //EC 주문번호
			reqObj.put("omsOrderRceptNo", omsRceptNo);  //OMS 주문 접수 번호
			reqObj.put("orderSttus", "2"); //취소 주문
            log.warn("ORDER_NO[{}] >> OMS 송신 : {}", orderNo, String.valueOf(reqObj));

			Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getLoOmsUrl() + "/OrderSttusChange", reqObj);
			log.warn("ORDER_NO[{}] >> OMS 수신 : {}", orderNo, String.valueOf(resObj));

			if(resObj != null && resObj.get("rspnsCode") != null
					&& StringUtils.equals(resObj.get("rspnsCode").toString(), "200")) {

				log.warn("ORDER_NO[{}] OMS_NO[{}] >> OMS 수신 성공.", orderNo, batchOrderModel.getOmsRceptNo());
			} else {
				log.error("ORDER_NO[{}] OMS_NO[{}] >> OMS 수신 실패.", orderNo, batchOrderModel.getOmsRceptNo());

				// 템플릿에 따라 SMS 전송을 처리한다.
				msgService.sendWrtmOrderCnclSms(batchOrderModel, "44", "증거금미납건 취소주문을 위한 배치작업시 OMS번호 수신 실패", null);
			}
		} catch (Exception e) {
			log.error("[callOms][물류 API호출 실패] ORDER_NO[{}] : ", orderNo, ExceptionUtils.getStackTrace(e));
			// 템플릿에 따라 SMS 전송을 처리한다.
			msgService.sendWrtmOrderCnclSms(batchOrderModel, "44", "증거금미납건 취소주문을 위한 배치작업시 물류 API호출 실패", null);
		}
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소 주문을 위해 이월렛에 환불 처리를 한다.
	 * </pre>
	 * @date 2022. 10. 14.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 14.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 */
	@SuppressWarnings("unchecked")
	private void callEwallet(BatchOrderModel batchOrderModel) {
		String orderNo = batchOrderModel.getOrderNo();
		log.warn("[callEwallet] IN --> ORDER_NO[{}]", orderNo);

		try {
			// 결제 기본 테이블 생성
			// 채번
			String setleNo 				= claimService.getNewOrderSetleNo();
			String canclExchngRtngudNo 	= batchOrderModel.getCanclExchngRtngudNo(); //취소반품 번호
			ClaimBasVO claimBasVO 		= batchOrderModel.getClaimBas();
			long refndAmount 			= claimBasVO.getRefndAmount();

			OrSetleBasVO orSetleBasVo = new OrSetleBasVO();
			orSetleBasVo.setSetleNo(setleNo);
			orSetleBasVo.setOrderNo(orderNo);
			orSetleBasVo.setCanclExchngRtngudNo(canclExchngRtngudNo);
			orSetleBasVo.setSetleTyCode(ClaimConstants.SETLE_TY_CODE_REFUND); // 20:환불
			orSetleBasVo.setSetleSttusCode(ClaimConstants.SETLE_STTUS_CODE_REQUEST); // 01:요청
			orSetleBasVo.setSetleSeCode(ClaimConstants.SETLE_SE_CODE_CANCEL);
			orSetleBasVo.setDelngAmount(String.valueOf(refndAmount)); //거래금액 2021.12.10

			claimMapper.insertEwalletSetle(orSetleBasVo);
			claimMapper.insertEwalletSetleHst(orSetleBasVo);

			/**
			 * iemSeCode : 0001(물품구매), 0002(환불), 0003(이체), 0004(기업뱅킹 환불)
			 * 0002 = 가상계좌 -> 고객계좌
			 * 0003 = 서린계좌 -> 가상계좌(고객)
			 */
			Map<String, Object> ewalletMap = new HashMap<String, Object>();
			ewalletMap.put("entrpsNo", batchOrderModel.getEntrpsNo());
			ewalletMap.put("iemSeCode", "0003");
			ewalletMap.put("delngAmount", refndAmount);
			ewalletMap.put("setleNo", setleNo);
			ewalletMap.put("ewalletExcclcTyCode", ClaimConstants.EXCCLC_TY_CODE_CANCEL); // 이월렛 정산 유형 코드
			log.warn("ORDER_NO[{}] >> 이월렛 전송 : {}", orderNo, ewalletMap);

			Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getEwalletOrderUrl(), ewalletMap);
			log.warn("ORDER_NO[{}] >> 이월렛 응답 : {}", orderNo, resObj);

			if(resObj != null
					&& StringUtils.equals(String.valueOf(resObj.get(ClaimConstants.EWALLET_RESULT_KEY)), ClaimConstants.API_SUCCESS_CODE)
					&& resObj.get(ClaimConstants.EWALLET_DATA_KEY) != null){

				boolean isSuccess = true;
				Map<String, Object> resultData = (Map<String, Object>) resObj.get(ClaimConstants.EWALLET_DATA_KEY);
				String delngSeqNo = String.valueOf(resultData.get("delngSeqNo"));
				batchOrderModel.setDelngSeqNo(delngSeqNo);

				// 이월렛 서버에서 결제테이블 정상 성공으로 업데이트 되었는지 체크 현재 5초 설정
				for(int i = 0 ; i < orProperty.getEwalletTimeoutsec() * 2  ; i ++) {
					Thread.sleep(500);
					//호출 건 응답 코드 확인
					String rspnsCode = claimMapper.selectEwalletRspnCode(delngSeqNo);
					log.warn("{} >> rspnsCode : {}", i, rspnsCode);
					if(!StringUtils.isEmpty(rspnsCode)) {
						//응답 코드가 000 일때 거래 완료 -> 전문설계서 응답코드 확인
						if(StringUtils.equals(rspnsCode, "000")) {
							isSuccess = true;
						}
						log.warn("ORDER_NO[{}] >> rspnsCode : {}, isSuccess : {}", orderNo, rspnsCode, isSuccess);
						break;
					}
				}

				if(isSuccess) {
					log.warn("ORDER_NO[{}] >> 이월렛 finally Success : {}", orderNo, isSuccess);

				}else{
					log.error("ORDER_NO[{}] >> 이월렛 finally Fail : {}", orderNo, isSuccess);
					msgService.sendWrtmOrderCnclSms(batchOrderModel, "47", "증거금미납건 취소주문을 위한 배치작업시 이월렛 수신 실패", null);
				}

			} else {
				log.error("ORDER_NO[{}] >> 이월렛 통신 및 기타 에러.", orderNo);
				msgService.sendWrtmOrderCnclSms(batchOrderModel, "47", "증거금미납건 취소주문을 위한 배치작업시 이월렛 통신 및 기타 에러", null);
			}

		} catch (Exception e) {
			msgService.sendWrtmOrderCnclSms(batchOrderModel, "47", "증거금미납건 취소주문을 위한 배치작업시 이월렛 실패", null);
			log.error("[callEwallet] ORDER_NO[{}] : {}", orderNo, ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 주문중 상세 코드가 이월렛 + 구매자금 주문의 매매계약서 대출번호를 조회하여 API서버에 대출 취소 요청을 한다.
	 * </pre>
	 * @date 2022. 11. 7.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 7.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 */
	private void callTrdeCtrtc(BatchOrderModel batchOrderModel) {
		String orderNo = batchOrderModel.getOrderNo();
		log.warn("[callTrdeCtrtc] IN  --> ORDER_NO[{}]", orderNo);
		try {

			int faiilCnt = 0;
			List<String> targetList = wrtmCnclMapper.selectWrtmTrdeCtrtcList(orderNo);
			if (targetList != null) {
				//호출 파라메터 작성
				Map<String, String> param = new HashMap<>();
				//매매계약서 취소 api 호출
				for (String target : targetList) {
					param.clear();
					param.put("lonNo", target);

					Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getLonCanclApiUrl(), param);
					log.warn("ORDER_NO[{}] >> 매매계약서 수신 : {}", orderNo, String.valueOf(resObj));

					if (null != resObj && resObj.get("rspnsCode") != null
							&& StringUtils.equals(resObj.get("rspnsCode").toString(), "200")) {

						log.warn("ORDER_NO[{}] LON_NO[{}]>> 매매계약서 수신 성공.", orderNo, target);
					} else {
						log.error("ORDER_NO[{}] LON_NO[{}]>> 매매계약서 수신 실패.", orderNo, target);
						faiilCnt++;
					}
				}

				if(faiilCnt > 0) {
					// 템플릿에 따라 SMS 전송을 처리한다.
					msgService.sendWrtmOrderCnclSms(batchOrderModel, "77", null, "증거금미납건 취소주문을 위한 배치작업시 대출취소 요청 실패");
				}
			}
		} catch (Exception e) {
			log.error("[매매계약서 API호출 실패] ORDER_NO[{}] : ", orderNo, ExceptionUtils.getStackTrace(e));
			// 템플릿에 따라 SMS 전송을 처리한다.
			msgService.sendWrtmOrderCnclSms(batchOrderModel, "77", null, "증거금미납건 취소주문을 위한 배치작업시 대출취소 요청중 기타오류 발생");
		}
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 세금 계산서 취소 요청을 실행한다.
	 * </pre>
	 * @date 2022. 11. 7.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 7.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 */
	private void callTaxbill(BatchOrderModel batchOrderModel) {
		String orderNo = batchOrderModel.getOrderNo();
		String canclExchngRtngudNo = batchOrderModel.getCanclExchngRtngudNo();

		log.warn("[callTaxbill] IN  --> ORDER_NO[{}]", orderNo);
		try {
			Map<String, Object> reqObj = new HashMap<>();
			reqObj.put("canclExchngRtngudNo", canclExchngRtngudNo);
			reqObj.put("jobSe", "CANCL");
			reqObj.put("orderNo", orderNo);

			Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getTaxbillUrl(), reqObj);

			log.warn("ORDER_NO[{}] >> 세금계산서 수신 : {}", orderNo, String.valueOf(resObj));

			if (null != resObj && resObj.get("responseCode") != null
					&& StringUtils.equals(resObj.get("responseCode").toString(), "200")) {

				log.warn("ORDER_NO[{}] >> 세금계산서 수신 성공.", orderNo);
			} else {
				log.error("ORDER_NO[{}] >> 세금계산서 수신 실패.", orderNo);

				// 템플릿에 따라 SMS 전송을 처리한다.
				msgService.sendWrtmOrderCnclSms(batchOrderModel, "77", null, "증거금미납건 취소주문을 위한 배치작업시 세금계산서 취소요청 실패");
			}

		} catch (Exception e) {
			log.error("[세금계산서 API호출 실패] ORDER_NO[{}] : ", orderNo, ExceptionUtils.getStackTrace(e));
			// 템플릿에 따라 SMS 전송을 처리한다.
			msgService.sendWrtmOrderCnclSms(batchOrderModel, "77", null, "증거금미납건 취소주문을 위한 배치작업시 세금계산서 취소요청중 기타오류 발생");
		}
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소주문 처리를 위한 데이터를 Claim 기본 테이블에 저장한다.
	 * </pre>
	 * @date 2022. 9. 16.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 16.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 * @param nowDateVal
	 * @throws Exception
	 */
	private void claimInstTblBase(BatchOrderModel batchOrderModel) throws Exception {

		String newClaimNo = claimService.getNewClaimNo();
		batchOrderModel.setCanclExchngRtngudNo(newClaimNo);

		/* 취소주문 배송 번호 */
		String cnclOrderDlvrfNo = null;

		/* 주문_배송비 기본 등록 - DLVY_MN_CODE (01: 케이지배송, 02: 자차 배송) */
		if(StringUtils.equals(batchOrderModel.getDlvyMnCode(), "01")) {
			DlvrfBasVO orderDlvrf = this.getOrderDlvrfInfos(batchOrderModel);
			wrtmCnclMapper.insertOrDlvrfBas(orderDlvrf);
			wrtmCnclMapper.insertOrDlvrfBasHst(orderDlvrf);
			cnclOrderDlvrfNo = orderDlvrf.getCnclOrderDlvrfNo();
		}

		/* 주문_취소 교환 반품 상세 등록*/
		List<ClaimDtlVO> claimDtlList = this.getClaimDtlInfos(batchOrderModel);
		if(!CollectionUtils.isEmpty(claimDtlList)) {
			for(ClaimDtlVO claimDtlvo : claimDtlList) {
				claimMapper.insertOrCanclExchngRtngudDtl(claimDtlvo);
				claimMapper.insertOrCanclExchngRtngudDtlHst(claimDtlvo);
			}
		}

		/* 주문_취소 교환 반품 등록*/
		ClaimBasVO claimBasvo = this.getClaimBasInfo(batchOrderModel);
		claimBasvo.setCnclOrderDlvrfNo(cnclOrderDlvrfNo);

		claimMapper.insertOrCanclExchngRtngudBas(claimBasvo);
		claimMapper.insertOrCanclExchngRtngudBasHst(claimBasvo);

		/* 증거금 취소 주문 내용 set */
		batchOrderModel.setClaimBas(claimBasvo);
	}
	/*
	 * 주문 테이블 기준으로 주문_취소 교환 반품 기본 정보 set한다.
	 */
	private ClaimBasVO getClaimBasInfo(BatchOrderModel batchOrderModel) {

		ClaimBasVO claimBasvo = new ClaimBasVO();
		claimBasvo.setOrderNo(batchOrderModel.getOrderNo());
		claimBasvo.setCanclExchngRtngudNo(batchOrderModel.getCanclExchngRtngudNo());
		claimBasvo.setMberNo(batchOrderModel.getMberNo());
		claimBasvo.setEntrpsNo(batchOrderModel.getEntrpsNo());
		claimBasvo.setCanclExchngRtngudTyCode(ClaimConstants.CLAIM_TY_CODE_ACDNT);         				//사고
		claimBasvo.setCanclExchngRtngudSttusCode(CanclExchngRtngudSttusCode.PRCSNG.getCode());          //처리중
		claimBasvo.setCanclExchngRtngudResnCode(CanclExchngRtngudResnCode.CREDIT_FAILR.getCode());		//여신불이행
		claimBasvo.setTotCanclExchngRtngudBundleQy(batchOrderModel.getTotBundleQy());

		/* Live 주문일 때만 의미 있음 - 시작*/
		claimBasvo.setSlePcRltmSn(batchOrderModel.getPrSelVO().getSlePcRltmSn()); 							// 판매 가격 실시간 순번
		claimBasvo.setLmePcRltmSn(batchOrderModel.getPrSelVO().getLmePcRltmSn());                            // LME 가격 실시간 순번
		claimBasvo.setEhgtPcRltmSn(batchOrderModel.getPrSelVO().getEhgtPcRltmSn());                          // 환율 가격 실시간 순번
		claimBasvo.setLme3m(batchOrderModel.getPrSelVO().getThreemonthLmePc());                              // LME 3M
		claimBasvo.setLmeCash(batchOrderModel.getPrSelVO().getLmePc());                                      // LME 현금
		claimBasvo.setLmeMdatCffcnt(batchOrderModel.getPrSelVO().getLmeMdatCffcnt());                        // LME 조정 계수
		claimBasvo.setSpex(batchOrderModel.getPrSelVO().getEhgtPc());                                        // 현물환
		claimBasvo.setSpexMdatCffcnt(batchOrderModel.getPrSelVO().getFxMdatCffcnt());                        // 현물환 조정 계수

		claimBasvo.setPremiumStdrAmount(batchOrderModel.getLivePremiumVO().getPremiumStdrAmount());          // 프리미엄 기준 금액
		claimBasvo.setDstrctChangeAmount(batchOrderModel.getLivePremiumVO().getDstrctChangeAmount());        // 권역 변동 금액
		claimBasvo.setBrandGroupChangeAmount(batchOrderModel.getLivePremiumVO().getBrandGroupChangeAmount());// 브랜드 그룹 변동 금액
		claimBasvo.setBrandChangeAmount(batchOrderModel.getLivePremiumVO().getBrandChangeAmount());          // 브랜드 변동 금액

		/* 고정기 주문일 때만 의미 있음 - 시작*/
		claimBasvo.setHghnetprcDstrctChangeAmount(batchOrderModel.getHghnetprcDstrctChangeAmount());  	    // 고정가 권역 변동 금액
		claimBasvo.setHghnetprcBrandGroupChangeAmount(batchOrderModel.getHghnetprcBrandGroupChangeAmount()); // 고정가 브랜드 그룹 변동 금액
		claimBasvo.setHghnetprcBrandChangeAmount(batchOrderModel.getHghnetprcBrandChangeAmount());           // 고정가 브랜드 변동 금액
		claimBasvo.setHghnetprcAvrgPurchsPrmpc(batchOrderModel.getHghnetprcAvrgPurchsPrmpc());               // 고정가 평균 구매 원가
		claimBasvo.setHghnetprcSleAmount(batchOrderModel.getHghnetprcSleAmount());                           // 고정가 판매 금액
		claimBasvo.setHghnetprcTotAmtTariff(batchOrderModel.getHghnetprcTotAmtTariff());                     // 고정가 할증 요율

		claimBasvo.setPremiumNo(batchOrderModel.getClaimPremiumNo());                                        // 프리미엄 번호
		claimBasvo.setPremiumPc(batchOrderModel.getClaimPremiumPc());

		/* 주문 로직 참조 */
		long goodsUntpc = batchOrderModel.getGoodsUntpc();                   //주문 상품 단가
		long orderPc    = batchOrderModel.getOrderPc();                  	//주문 가격
		long frstSetleAmount = batchOrderModel.getFrstSetleAmount();         //증거금 취초 결제 금액

		BigDecimal premiumPc = batchOrderModel.getPremiumPc();               //주문 프리미엄 가격
		long claimGoodsUntpc = batchOrderModel.getClaimGoodsUntpc();         //취소 주문 상품 단가
		long claimOrderPc 	= batchOrderModel.getClaimOrderPc();             //취소 주문 가격
		BigDecimal claimPremiumPc = batchOrderModel.getClaimPremiumPc();     //취소 주문 프리미엄 가격

		claimBasvo.setOrderPc(claimOrderPc);
		claimBasvo.setWtChangegld(batchOrderModel.getClaimWtChangegld());
		claimBasvo.setSplpc(batchOrderModel.getClaimSplpc());
		claimBasvo.setVat(batchOrderModel.getClaimVat());
		claimBasvo.setSlepc(batchOrderModel.getClaimSlepc());

		claimBasvo.setTotCanclExchngRtngudWt(batchOrderModel.getTotRealOrderWt()); // 총 실제 주문 중량 (TOT_REAL_ORDER_WT)
		claimBasvo.setGoodsUntpc(claimGoodsUntpc);
		/*
		 * [페널티 금액(취소 수수료)] : 취소 세금계산서 발행 파일 참조
		 * 중량 * 주문단가 * 1%(취소수수료) ==> 중량변동금 제외한 중량
		 * 1,000원 단위 반올림
		 */
//		double calcPenltyAmount = (orderWt * goodsUntpc * 0.01);  //
		double calcPenltyAmount = (orderPc * 0.01);
		long penltyAmount = Math.round(calcPenltyAmount / 1000.0) * 1000;
		claimBasvo.setPenltyAmount(penltyAmount);                            // 페널티 금액

		/*
		 * [취소 단가 차액]
		 * OR_ORDER_BAS.GOODS_UNTPC - OR_CANCL_EXCHNG_RTNGUD_BAS.GOODS_UNTPC
		 * 주문 단가 - 취소 단가
		 */
		long canclUntpcDfnnt = goodsUntpc - claimGoodsUntpc;
		claimBasvo.setCanclUntpcDfnnt(canclUntpcDfnnt);                     // 취소 단가 차액

		/*
		 * [프리미엄 차손 금액]
		 * OR_ORDER_BAS.PREMIUM_PC - OR_CANCL_EXCHNG_RTNGUD_BASPREMIUM_PC
		 * 주문 프리미엄 - 취소 프리미엄
		 */
		log.warn("{}, premiumPc :{}, claimPremiumPc :{}", batchOrderModel.getPrefix(), premiumPc, claimPremiumPc);
		if(premiumPc != null) {
			long premiumDfnlosAmount = premiumPc.subtract(claimPremiumPc).longValue();
			claimBasvo.setPremiumDfnlosAmount(premiumDfnlosAmount);            // 프리미엄 차손 금액
		}

		/*
		 * 정산 차액 : ((중량 * 주문 단가) ) - ((중량 *  취소 단가) ) ==> 중량변동금 제외한 중량
		 */
		long canclOrderDfnnt = (orderPc - claimOrderPc);
		claimBasvo.setExcclcDfnnt(canclOrderDfnnt);				  		  // 정산 차액

		/*
		 * ① : ((중량 * 주문 단가) ) - ((중량 *  취소 단가) ) ==> 중량변동금 제외한 중량
		 * 1) ①이 양수일 경우 : 케이지트레이딩 이익  ==> ② : 최초결제액 - 패널티금액 - ①
		 * 2) ①이 음수일 경우 : 케이지트레이딩 손해  ==> ② : 최초결제액 - 패널티금액
		 */
		long refndAmount = 0L;

		if(canclOrderDfnnt>0) { //케이지트레이딩손해
			refndAmount = (frstSetleAmount-penltyAmount-canclOrderDfnnt);
		}else {                 //케이지트레이딩이익
			refndAmount = (frstSetleAmount-penltyAmount);
		}

		claimBasvo.setRefndAmount(refndAmount);							// 환불 금액

		claimBasvo.setNtfcAmount(batchOrderModel.getNtfcAmount());			// 고시 금액
		claimBasvo.setLrgetrnsprtctAmount(batchOrderModel.getLrgetrnsprtctAmount());	//대운송비 금액
		claimBasvo.setMarginAmount(batchOrderModel.getMarginAmount());		// 마진 금액

		return claimBasvo;
	}

	/*
	 * 주문_취소 교환 반품 상세 테이블에 증거금 주문 정보를 등록하기위해
	 * 주문시의 증거금 주문 상세정보를 기준으로 정보를 set한다.
	 */
	private List<ClaimDtlVO> getClaimDtlInfos(BatchOrderModel batchOrderModel) {
		List<ClaimDtlVO> claimDtls = new ArrayList<>();

		List<OrderDtlVO> orderDtlList = batchOrderModel.getOrderBasDtlList();
		if(!CollectionUtils.isEmpty(orderDtlList)) {
			for(OrderDtlVO orderDtlVO : orderDtlList) {

				ClaimDtlVO claimDtlVO = new ClaimDtlVO();

				claimDtlVO.setOrderNo(orderDtlVO.getOrderNo());							// 주문 번호
				claimDtlVO.setOrderSn(orderDtlVO.getOrderSn());							// 주문 순번
				claimDtlVO.setCanclExchngRtngudNo(batchOrderModel.getCanclExchngRtngudNo()); // 취소 교환 반품 번호
				claimDtlVO.setBlNo(orderDtlVO.getBlNo());                               // BL 번호
				claimDtlVO.setCanclExchngRtngudWt(orderDtlVO.getRealOrderWt());         // 취소 교환 반품 중량
				claimDtlVO.setCanclExchngRtngudBundleQy(orderDtlVO.getBundleQy());      // 취소 교환 반품 번들 수량
				claimDtlVO.setCanclExchngRtngudDcsnWt(orderDtlVO.getDcsnWt());          // 취소 교환 반품 확정 중량

				claimDtls.add(claimDtlVO);
			}
		}
		return claimDtls;
	}

	/*
	 * 주문_배송비 기본 테이블에 증거금 반대 매매 정보 등록 위해
	 * 주문시 배송비 정보를 기준으로 정보 set한다.
	 */
	private DlvrfBasVO getOrderDlvrfInfos(BatchOrderModel batchOrderModel) {
		DlvrfBasVO resultDlvrf = batchOrderModel.getOrderDlvrfBas();

		log.warn("getOrderDlvrfInfos >>> {}", resultDlvrf );

		DlvrfBasVO dlvrfBasData = new DlvrfBasVO();

		dlvrfBasData.setOrderNo(batchOrderModel.getOrderNo());
		dlvrfBasData.setCanclExchngRtngudNo(batchOrderModel.getCanclExchngRtngudNo());
		dlvrfBasData.setDlvySeCode("01");				//01: 배송, 02: 수거
		dlvrfBasData.setDlvrfBndMbyCode("01");			//01: 고객, 02: 케이지트레이딩
		dlvrfBasData.setDlvrfLevySeCode("02");          //01: 부과, 02: 환불
		dlvrfBasData.setExpectDlvrf(resultDlvrf.getExpectDlvrf());

		return dlvrfBasData;
	}
}
