package com.sorincorp.batch.or.model;

import lombok.Data;

@Data
public class OrderLimitVO {

	/******  JAVA VO CREATE : OR_LIMIT_ORDER_BAS(주문_지정가 주문 기본)                                                                      ******/
    /**
     * 지정가 주문 번호
    */
    private String limitOrderNo;
    /**
     * 지정가 주문 일자
    */
    private String limitOrderDe;
    /**
     * 지정가 주문 시각
    */
    private String limitOrderTm;
    /**
     * 지정가 주문 상태 코드
    */
    private String limitOrderSttusCode;
    /**
     * 회원 번호
    */
    private String mberNo;
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 접수 매체 구분 코드
    */
    private String rceptMediaSeCode;
    /**
     * 지정가 주문 중량
    */
    private int limitOrderWt;
    /**
     * 지정가 입력 금액
    */
    private long limitInputAmount;
    /**
     * 결제 방식 코드
    */
    private String setleMthdCode;
    /**
     * 결제 방식 상세 코드
    */
    private String setleMthdDetailCode;
    /**
     * 권역 중분류 코드
    */
    private String dstrctMlsfcCode;
    /**
     * 프라이싱 번호
    */
    private String pricingNo;
    /**
     * 장바구니 번호
    */
    private String bsktNo;
    /**
     * 주문자 명
    */
    private String ordrrNm;
    /**
     * 주문자 휴대폰 번호
    */
    private String ordrrMoblphonNo;
    /**
     * 주문자 이메일
    */
    private String ordrrEmail;
    /**
     * 주문 업체 명
    */
    private String orderEntrpsNm;
    /**
     * 주문 업체 전화번호
    */
    private String orderEntrpsTelno;
    /**
     * 주문 업체 우편번호
    */
    private String orderEntrpsZip;
    /**
     * 주문 업체 주소
    */
    private String orderEntrpsAdres;
    /**
     * 주문 업체 상세 주소
    */
    private String orderEntrpsDetailAdres;
    /**
     * 주문 업체 도로명 주소
    */
    private String orderEntrpsRnAdres;
    /**
     * 주문 업체 도로명 상세 주소
    */
    private String orderEntrpsRnDetailAdres;
    /**
     * 배송 수단 코드
    */
    private String dlvyMnCode;
    /**
     * 출고 요청 일자
    */
    private String dlivyRequstDe;
    /**
     * 판매 단위 코드
    */
    private String sleUnitCode;
    /**
     * 최대 브랜드 변동 금액
    */
    private long mxmmBrandChangeAmount;
    /**
     * 프리미엄 아이디
    */
    private String premiumId;
    /**
     * 최종 상품 단가
    */
    private long lastGoodsUntpc;
    /**
     * 주문 가격
    */
    private long orderPc;
    /**
     * 중량 변동금
    */
    private long wtChangegld;
    /**
     * 공급가
    */
    private long splpc;
    /**
     * 부가세
    */
    private long vat;
    /**
     * 판매가
    */
    private long slepc;
    /**
     * 상환 기간
    */
    private int repyPd;
    /**
     * 증거금 최소 증거금 비율
    */
    private java.math.BigDecimal wrtmMummWrtmRate;
    /**
     * 예상 배송비
    */
    private java.math.BigDecimal expectDlvrf;
    /**
     * 배송지 명
    */
    private String dlvrgNm;
    /**
     * 수취 업체 명
    */
    private String receptEntrpsNm;
    /**
     * 수취 업체 우편 번호
    */
    private String receptEntrpsPostNo;
    /**
     * 수취 업체 주소
    */
    private String receptEntrpsAdres;
    /**
     * 수취 업체 상세 주소
    */
    private String receptEntrpsDetailAdres;
    /**
     * 수취 업체 도로명 주소
    */
    private String receptEntrpsRnAdres;
    /**
     * 수취 업체 도로명 상세 주소
    */
    private String receptEntrpsRnDetailAdres;
    /**
     * 수취 업체 법정동 코드
    */
    private String receptEntrpsLegaldongCode;
    /**
     * 수취 업체 휴대폰 번호
    */
    private String receptEntrpsMoblphonNo;
    /**
     * 수취 업체 담당자 명
    */
    private String receptEntrpsChargerNm;
    /**
     * 수취 업체 담당자 이메일
    */
    private String receptEntrpsChargerEmail;
    /**
     * 배송 요청 내용
    */
    private String dlvyRequstCn;
    /**
     * 중량 변동
    */
    private java.math.BigDecimal wtChange;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 예수 금액
    */
    private long advrcvAmount;
    /**
     * 지정가 프리미엄 기준 금액
    */
    private long limitPremiumStdrAmount;
    /**
     * 지정가 권역 변동 금액
    */
    private long limitDstrctChangeAmount;
    /**
     * 지정가 브랜드 그룹 변동 금액
    */
    private long limitBrandGroupChangeAmount;
    /**
     * 지정가 브랜드 변동 금액
    */
    private long limitBrandChangeAmount;
    /**
     * 지정가 프리미엄 제외 금액
    */
    private long limitPremiumExclAmount;
    /**
     * 지정가 주문 로그 순번
    */
    private long limitOrderLogSn;
    /**
     * 지정가 주문 요청 일시
    */
    private String limitOrderRequstDt;
    /**
     * 지정가 주문 기준 판매 가격
    */
    private java.math.BigDecimal limitOrderStdrSlePc;
    /**
     * 판매 가격 실시간 순번
    */
    private String slePcRltmSn;
    /**
     * LME 가격 실시간 순번
    */
    private String lmePcRltmSn;
    /**
     * LME 3M
    */
    private java.math.BigDecimal lme3m;
    /**
     * LME 현금
    */
    private java.math.BigDecimal lmeCash;
    /**
     * LME 조정 계수
    */
    private java.math.BigDecimal lmeMdatCffcnt;
    /**
     * 환율 가격 실시간 순번
    */
    private String ehgtPcRltmSn;
    /**
     * 현물환
    */
    private java.math.BigDecimal spex;
    /**
     * 현물환 조정 계수
    */
    private java.math.BigDecimal spexMdatCffcnt;
    /**
     * 프리미엄 번호
    */
    private String premiumNo;
    /**
     * 프리미엄 기준 금액
    */
    private long premiumStdrAmount;
    /**
     * 권역 변동 금액
    */
    private long dstrctChangeAmount;
    /**
     * 브랜드 그룹 변동 금액
    */
    private long brandGroupChangeAmount;
    /**
     * 브랜드 변동 금액
    */
    private long brandChangeAmount;
    /**
     * 프리미엄 가격
    */
    private java.math.BigDecimal premiumPc;
    /**
     * 재고 체크 중량
    */
    private int invntryCeckWt;
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 실제 체결 중량
    */
    private int realCnclsWt;
    /**
     * 주문 실패 사유
    */
    private String orderFailrResn;
    /**
     * 허수 주문 여부
    */
    private String imaginaryOrderAt;
    /**
     * 지정가 취소 시각
    */
    private String limitCanclTm;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    /**
	 *	지정가 구분 코드 - 가단가용 [F: LME/X: 환율/R: KRW]
	 */
	private String limitSeCode;
}
