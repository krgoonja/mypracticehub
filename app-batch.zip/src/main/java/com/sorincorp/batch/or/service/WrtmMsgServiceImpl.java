package com.sorincorp.batch.or.service;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.sorincorp.batch.credt.model.WrtmOppsTrdeVo;
import com.sorincorp.batch.or.comm.ClaimConstants;
import com.sorincorp.batch.or.comm.ClaimConstants.NpyProcessTyCode;
import com.sorincorp.batch.or.comm.ClaimConstants.SleMthdCode;
import com.sorincorp.batch.or.mapper.WrtmOrderCnclMapper;
import com.sorincorp.batch.or.model.ArrrgTrgterVO;
import com.sorincorp.batch.or.model.ClaimBasVO;
import com.sorincorp.batch.or.model.NpyOrderManageVO;
import com.sorincorp.batch.or.model.BatchOrderModel;
import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.CdtlnMessageService;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.service.CommAvrgpcOrderService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class WrtmMsgServiceImpl implements WrtmMsgService{

	@Autowired
	private WrtmOrderCnclMapper wrtmCnclMapper;

	/** 이메일 발송 매퍼 */
	@Autowired
	private MailMapper mailMapper;

	/** SMS 발송 서비스 */
	@Autowired
	private SMSService smsService;

	/** 메일 발송 서비스 */
    @Autowired
    private MailService mailService;

    @Autowired
    CdtlnMessageService cdtlnMessageService;

    /** 평균가 주문 공통 Service  */
    @Autowired
    private CommAvrgpcOrderService commAvrgpcOrderService;

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소 완료후 안내 메일을 고객에게 전송한다.
	 * </pre>
	 * @date 2022. 10. 18.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 18.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 */
	@Override
	public void sendWrtmOrderCnclMail(BatchOrderModel batchOrderModel) {
		log.warn("[callWrtmOrderCnclMail] ::: ORDER_NO[{}] IN", batchOrderModel.getOrderNo());
		try {

			DecimalFormat decFormat = new DecimalFormat("###,###");

			/*
			 67 미납에 의한 주문 취소 환불 처리 안내(케이지트레이딩이익) => 정산차액{주문시 상품금액 - 환불시 상품금액} (-)
			 68 미납에 의한 주문 취소 환불 처리 안내(케이지트레이딩손해) => 정산차액{주문시 상품금액 - 환불시 상품금액} (+)
			*/
			String orderNo = batchOrderModel.getOrderNo();
			String ordrrNm = batchOrderModel.getOrdrrNm();
			String ordrrEmail = batchOrderModel.getOrdrrEmail();

			int orderWt = batchOrderModel.getTotRealOrderWt();
			long goodsUntpc = batchOrderModel.getGoodsUntpc();
			long orderPc = batchOrderModel.getOrderPc();
			long firstAmount = batchOrderModel.getFrstSetleAmount();

			ClaimBasVO claimBasVO = batchOrderModel.getClaimBas();
			long excclcDfnnt = claimBasVO.getExcclcDfnnt();      //정산차액

            /*
             * 1. 정산 차액이 (+)인 경우 케이지트레이딩 손해로 파악하여 가격 산정 근거와 취소 관련 데이터기 들어 있는 68번 메일 템플릿 이용
             *    정산 차액이 (-)인 경우 케이지트레이딩 이익으로 파악하여 67번 메일 템플릿 이용한다.
             * 2. 판매벙식 코드가 고정가(02)인 경우에는 무조건 67번 메일 템플릿을 이용한다.
             *    - 고정가인 경우 고객에게 취소 수수료를 받는것으로 로직을 정해 가격산정 근거가 필요없음(2023-01-20일 김지훈 팀장과 협의함)
             */
			int maiTmpNo = excclcDfnnt <= 0 ? 67:68;	//67: 케이지트레이딩이익-고객손해(정산 내역 미포함), 68:케이지트레이딩손해-고객이익(정산내역 포함)
			String sleMthdCode = batchOrderModel.getSleMthdCode();
			if(StringUtils.equals(SleMthdCode.FIXING.getCode(), sleMthdCode)){
				maiTmpNo = 67;
			}

			int claimOrderWt = claimBasVO.getTotCanclExchngRtngudWt();
			long claimUntpc = claimBasVO.getGoodsUntpc();
			long claimPc = claimBasVO.getOrderPc();
			long penlty = claimBasVO.getPenltyAmount() * -1;               //페널티 금액은 부호를 반대로 바꾼다.
			long refnd = claimBasVO.getRefndAmount();

			MailVO mailVo = new MailVO();
			mailVo.setMailTmptSeq(maiTmpNo);								// 템플릿 번호(OP_EMAIL_TMPLAT_BAS): 미납에 의한 주문 취소 환불 처리 안내
			mailVo.setEmail(ordrrEmail);									// 이메일 (수신자)(주문자)
			mailVo.setMemberNo(batchOrderModel.getMberNo());						// 회원 번호
			mailVo.setEntrpsNo(batchOrderModel.getEntrpsNo());					// 업체 번호
			mailVo.setMailSendUserId("SYSTEM");								// 발신자 아이디 (로그인)

			mailVo.setMailSendEmail(mailMapper.selectMailTmpt(maiTmpNo).getSntoEmail());	// 발신자 이메일 주소

			log.warn("::: mailVo : " + mailVo);

			Map<String, String> mailMap = new HashMap<String, String>();
			mailMap.put("ORDER_NO", orderNo);
			mailMap.put("ORDER_WT", decFormat.format(orderWt));
			mailMap.put("ORDER_UNTPC", decFormat.format(goodsUntpc));
			mailMap.put("ORDER_PC", decFormat.format(orderPc));
			mailMap.put("FRST_AMOUNT", decFormat.format(firstAmount));

			mailMap.put("CLAIM_WT", decFormat.format(claimOrderWt));
			mailMap.put("CLAIM_UNTPC", decFormat.format(claimUntpc));
			mailMap.put("CLAIM_PC", decFormat.format(claimPc));
			mailMap.put("EXCCLC_DFNNT", decFormat.format((excclcDfnnt * -1)));		//정산차액은 반대 부호 처리한다.
			mailMap.put("PENLTY", decFormat.format(penlty));
			mailMap.put("REFND", decFormat.format(refnd));

			mailMap.put("PC_CALC_BASIS_CONTENTS", getWrtmOrderCnclCnts(batchOrderModel));
			mailMap.put("CS_HIST_GUID_CONTENTS", getCsHistGuids(orderNo));
			mailMap.put("ENTRPS_NM", batchOrderModel.getEntrpsNm());
			mailMap.put("CS_TEL_NO", batchOrderModel.getCsTelNo());
			mailMap.put("serviceDomain", ClaimConstants.SERVICE_DOMAIN);

			log.warn("::: mailMap : "+ mailMap.toString());

			int mailNoSeq = mailService.insertMailSendByReturnMailNo(mailVo, mailMap);

			/* 주문_미납 주문 관리 기본 테이블 등록 */
			NpyOrderManageVO npyMngVo = new NpyOrderManageVO(orderNo, "20", ordrrNm);
			npyMngVo.setEmailSndngHistNo(mailNoSeq);
			npyMngVo.setOrdrrEmail(ordrrEmail);
			npyMngVo.setProcessCn("미납에 의한 주문 취소 환불 처리 안내");
			this.insertWrtmOrderManage(npyMngVo);

		} catch (Exception e) {
			log.error("ORDER_NO[{}] : {}", batchOrderModel.getOrderNo(), ExceptionUtils.getStackTrace(e));
		}

		log.warn("[callWrtmOrderCnclMail] END");
	}

   /**
    *
    * <pre>
    * 처리내용: 고객 및 내부 관리자 그룹에게 관련 내용을 SMS전송한다.
    * </pre>
    * @date 2022. 10. 20.
    * @author srec0070
    * @history
    * ------------------------------------------------
    * 변경일					작성자				변경내용
    * ------------------------------------------------
    * 2022. 10. 20.			srec0070			최초작성
    * ------------------------------------------------
    * @param batchOrderModel
    * @param templateNum
    * @param addStr
    */
   @Override
	public void sendWrtmOrderCnclSms(BatchOrderModel batchOrderModel, String templateNum, String returnMsg, String errMsg) {
		log.warn("[sendWrtmOrderCnclSms] ::: ORDER_NO[{}] IN ", batchOrderModel.getOrderNo());

		try {
			DecimalFormat decFormat = new DecimalFormat("###,###");

			String orderNo = batchOrderModel.getOrderNo();
			String ordrrNm = batchOrderModel.getOrdrrNm();
			String entrpsNm = batchOrderModel.getEntrpsNm();

			SMSVO smsVO = new SMSVO();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
			smsVO.setMberNo(batchOrderModel.getMberNo());
			/* 핸드폰 번호 복호화 */
			String phone = this.getDecPhone(batchOrderModel.getOrdrrMoblphonNo(), orderNo);
			smsVO.setPhone(phone);
			smsVO.setCommerceNtcnAt("Y"); // 커머스 알림 여부, 20211116 추가

			Map<String, String> smsMap = null;

			switch(templateNum) {
				case "44" :
					smsMap = new HashMap<String, String>();
					smsMap.put("commerceNtcnCn", "물류(결제정보) 송신 실패"); // 알림 메세지
					smsMap.put("orderNo", batchOrderModel.getOrderNo()); // 주문번호
					smsMap.put("returnMsg", returnMsg); // 주문 데이터 물류IF시 오류 발생
					break;
				case "45" :
					smsMap = new HashMap<String, String>();
					smsMap.put("commerceNtcnCn", "선물 요청 실패"); // 알림 메세지
					smsMap.put("orderNo", batchOrderModel.getOrderNo()); // 주문번호
					smsMap.put("returnMsg", returnMsg); // 선물요청주문번호
					smsMap.put("errMsg", errMsg); // 실패사유
					break;
				case "46" :
					smsMap = new HashMap<String, String>();
					smsMap.put("commerceNtcnCn", "선물환 처리 실패"); // 알림 메세지
					smsMap.put("orderNo", batchOrderModel.getOrderNo()); // 주문번호
					smsMap.put("returnMsg", returnMsg); // 선물환요청주문번호
					smsMap.put("errMsg", errMsg); // 실패사유
					break;
				case "47" :
					smsMap = new HashMap<String, String>();
					smsMap.put("commerceNtcnCn", "이월렛 처리 실패"); // 알림 메세지
					smsMap.put("orderNo", batchOrderModel.getOrderNo()); // 주문번호
					break;
				case "73" :
					smsMap = new HashMap<String, String>();
					smsMap.put("commerceNtcnCn", "선물 취소 요청"); // 알림 메세지
					smsMap.put("orderNo", batchOrderModel.getOrderNo()); // 주문번호
					smsMap.put("returnMsg", returnMsg); // 선물요청주문번호(복수)
					break;
				case "77" :
					smsMap = new HashMap<String, String>();
					smsMap.put("commerceNtcnCn", "주문 실패"); // 알림 메세지
					smsMap.put("orderNo", batchOrderModel.getOrderNo()); // 주문번호
					smsMap.put("errMsg", errMsg); // 실패 사유
					break;
				case "78" :
					int phoneCnt = 0, mailCnt = 0, smsCnt = 0;
					List<ArrrgTrgterVO> csResults = wrtmCnclMapper.selectNpyOrderManageList(batchOrderModel.getOrderNo());
					if(!CollectionUtils.isEmpty(csResults)) {
						phoneCnt = (int)csResults.stream().filter(
									r->NpyProcessTyCode.PHONE.getCode().equals(r.getNpyProcessTyCode())).count();
						mailCnt = (int)csResults.stream().filter(
									r->NpyProcessTyCode.MAIL.getCode().equals(r.getNpyProcessTyCode())).count();
						smsCnt = (int)csResults.stream().filter(
									r->NpyProcessTyCode.SMS.getCode().equals(r.getNpyProcessTyCode())).count();
					}

					smsMap = new HashMap<String, String>();
					smsMap.put("ENTRPS_NM", entrpsNm);
					smsMap.put("PHONE_CNT", String.valueOf(phoneCnt));
					smsMap.put("MAII_CNT", String.valueOf(mailCnt));
					smsMap.put("SMS_CNT", String.valueOf(smsCnt));
					smsMap.put("CSTMR_CNTER_TELNO", "");

					long frstSetleAmount = batchOrderModel.getFrstSetleAmount();
					long orderPc 		= batchOrderModel.getOrderPc();					  //주문가격
					long claimOrderPc 	= batchOrderModel.getClaimOrderPc();				  //Claim 주문가격
					long excclcDfnnt 	= batchOrderModel.getClaimBas().getExcclcDfnnt();  //정산차액
					long penltyAmt 		= batchOrderModel.getClaimBas().getPenltyAmount(); //페널티금액
					long refndAmount    = batchOrderModel.getClaimBas().getRefndAmount();  //환불금액

					// 평균가 주문인 경우 계약번호, 계약년월 추가
					String cntrctOrderNo = batchOrderModel.getCntrctOrderNo();
					String orderMsg = commAvrgpcOrderService.getOrderInfoString(orderNo, cntrctOrderNo);

					// 결제정보 동적 영역
					StringBuilder payArea = new StringBuilder();
					payArea.append("주문번호 : ").append(orderMsg).append(System.lineSeparator()); // 주문번호
//					payArea.append("주문번호 : ").append(batchOrderModel.getOrderNo()).append(System.lineSeparator()); // 주문번호
					payArea.append("주문일자 : ").append(batchOrderModel.getOrderComptDt()).append(System.lineSeparator()); // 주문일자
					payArea.append("주문상품 : ").append(batchOrderModel.getGoodsNm()).append(System.lineSeparator()); // 주문상품
					payArea.append("보증금 : ").append(decFormat.format(frstSetleAmount)).append(System.lineSeparator()); // 보증금

					/*
					 케이지트레이딩이익 => 정산차액{주문시 상품금액 - 환불시 상품금액} (-)
					 케이지트레이딩손해 => 정산차액{주문시 상품금액 - 환불시 상품금액} (+)
					*/
					if(excclcDfnnt > 0) {
						payArea.append("주문 시 금액 : ").append(decFormat.format(orderPc)).append(System.lineSeparator());
						payArea.append("취소 시 금액 : ").append(decFormat.format(claimOrderPc)).append(System.lineSeparator()); // 결제예정금액
						payArea.append("취소 차액 : ").append(decFormat.format(excclcDfnnt * -1)).append(System.lineSeparator()); // 결제예정일
						payArea.append("취소 수수료 : ").append(decFormat.format(penltyAmt * -1)).append(System.lineSeparator()); // 결제예정일
						payArea.append("환불 금액 : ").append(decFormat.format(refndAmount)).append(System.lineSeparator()); // 환불금액

					} else {
						payArea.append("취소 수수료 : ").append(decFormat.format(penltyAmt * -1)).append(System.lineSeparator()); // 결제예정금액
						payArea.append("환불 금액 : ").append(decFormat.format(refndAmount)).append(System.lineSeparator()); // 환불금액
					}
					smsMap.put("payArea", payArea.toString()); // 결제정보 동적 영역

					payArea = null; // StringBuilder 메모리 해제 유도

					smsMap.put("commerceNtcnCn", "[케이지트레이딩] 미납에 의한 주문 취소 환불 처리 안내"); // 알림 메세지
					break;
			}

			if(smsMap != null) {
				smsMap.put("templateNum", templateNum);

				// 증거금 취소주문 성공시에만 주문자에게 SMS전송한다.
				if(StringUtils.equals(templateNum, "78")) {
				   try {
						log.warn("ORDER_NO[{}] >> 고객용 smsMap : {}", batchOrderModel.getOrderNo(), String.valueOf(smsMap));

						smsMap.put("excpSndngOptnAt", "N"); // 예외 발송 옵션 여부, N일 경우 SMS 수신자만 발송한다.
						String mssageSndngHistNo = smsService.insertSMSByReturnMssageSndngHistNo(smsVO, smsMap);

						/* 주문_미납 주문 관리 기본 테이블 등록 (20: 이메일, 30: SMS) */
						NpyOrderManageVO npyMngVo = new NpyOrderManageVO(orderNo, "30", ordrrNm);
						npyMngVo.setMssageSndngHistNo(Integer.parseInt(mssageSndngHistNo));
						npyMngVo.setOrdrrMoblphonNo(phone);
						npyMngVo.setProcessCn("미납에 의한 주문 취소 환불 처리 안내");

						this.insertWrtmOrderManage(npyMngVo);
					}catch(Exception e1) {
						log.error("ORDER_NO[{}] : {}", batchOrderModel.getOrderNo(), ExceptionUtils.getStackTrace(e1));
					}
				}

				//내부 사용자 그룹에게도 SMS전송한다.
				smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
				smsService.insertSMS(null, smsMap);
				log.warn("ORDER_NO[{}] >> 내부 사용자 그룹 smsMap : {}", orderNo, String.valueOf(smsMap));
			}
		} catch (Exception e2) {
			log.error("ORDER_NO[{}] - {}", batchOrderModel.getOrderNo(), ExceptionUtils.getStackTrace(e2));
		}
	}

   /**
   *
   * <pre>
   * 처리내용: 증거금 주문 미납 대상(D+4, D+5)에 대한 안내 SMS를 전송한다.
   * </pre>
   * @date 2022. 10. 20.
   * @author srec0070
   * @history
   * ------------------------------------------------
   * 변경일					작성자				변경내용
   * ------------------------------------------------
   * 2022. 10. 20.			srec0070			최초작성
   * ------------------------------------------------
   * @param oppsTrdeVo
   * @param csTelNo
   * @param templateNum
   */
	@Override
	public void sendWrtmOppsTrdeSms(WrtmOppsTrdeVo oppsTrdeVo, String csTelNo, int templateNum) {
		log.warn("[sendWrtmOppsTrdeSms] ::: {}", oppsTrdeVo.toString());

		try {

			String templateType = oppsTrdeVo.getTemplateType();
			if(!("D4".equals(templateType) || "D5".equals(templateType))) {
				throw new Exception("미납안내 SMS 타입 오류");
			}

			DecimalFormat decFormat = new DecimalFormat("###,###");

			SMSVO smsVO = new SMSVO();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
			smsVO.setCommerceNtcnAt("Y"); // 커머스 알림 여부, 20211116 추가
			smsVO.setMberNo(oppsTrdeVo.getMberNo());

			/* 핸드폰 번호 복호화 */
			String orderNo = oppsTrdeVo.getOrderNo();
			String phone = this.getDecPhone(oppsTrdeVo.getOrdrrMoblphonNo(), orderNo);
			smsVO.setPhone(phone);

			int phoneCnt = 0, mailCnt = 0, smsCnt = 0;
			List<ArrrgTrgterVO> csResults = wrtmCnclMapper.selectNpyOrderManageList(orderNo);
			if(!CollectionUtils.isEmpty(csResults)) {
				phoneCnt = (int)csResults.stream().filter(r->NpyProcessTyCode.PHONE.getCode().equals(r.getNpyProcessTyCode())).count();
				mailCnt = (int)csResults.stream().filter(r->NpyProcessTyCode.MAIL.getCode().equals(r.getNpyProcessTyCode())).count();
				smsCnt = (int)csResults.stream().filter(r->NpyProcessTyCode.SMS.getCode().equals(r.getNpyProcessTyCode())).count();
			}

			String ordrrNm          = oppsTrdeVo.getOrdrrNm();
			String entrpsNm         = oppsTrdeVo.getOrderEntrpsNm();
			long orderPc 			= oppsTrdeVo.getOrderPc();
			long unSetleAmount  	= oppsTrdeVo.getUnSetleAmount();
			long frstSetleAmount 	= oppsTrdeVo.getFrstSetleAmount();
			String oppsTrdePrarnde  = oppsTrdeVo.getOppsTrdePrarnde();
			try {
				if(oppsTrdePrarnde != null && oppsTrdePrarnde.length() == 8)
					oppsTrdePrarnde = DateUtil.getFormatDate(oppsTrdePrarnde, "yyyy년 MM월 dd일");
			}catch(Exception e) {
				log.error("[Parsing Error] ORDER_NO[{}] {}", orderNo, ExceptionUtils.getStackTrace(e));
			}

			String commerceNtcnCn = "";
			String processCn      = "";
			StringBuilder builder = new StringBuilder();

			if("D4".equals(templateType)) {
				builder.append(entrpsNm + " 회원님, 증거금 상환 기간 내 금액이 납부되지 않아 " + oppsTrdePrarnde + " 반대매매 진행 예정임을 알려드립니다.").append(System.lineSeparator());
				builder.append("반대매매 진행시 기납부한 증거금에서 수수료 및 차액을 차감한 금액이 가상계좌로 입금 예정입니다.").append(System.lineSeparator());

				commerceNtcnCn = "[케이지트레이딩] 반대 매매 진행 예정 안내";
				processCn      = "반대 매매 진행 예정 안내(D+4)";
			}else {
				builder.append(entrpsNm + " 회원님, 증거금에 대한 잔금이 상환 기간 내 금액이 납부되지 않아 " + oppsTrdePrarnde + " 반대매매 실행 함을 알려드립니다.").append(System.lineSeparator());
				builder.append("반대매매 실행 후 기납부한 증거금에서 수수료 및 차액을 차감한 금액이 가상계좌로 입금 예정입니다.").append(System.lineSeparator());

				commerceNtcnCn = "[케이지트레이딩] 반대 매매 실행 안내";
				processCn      = "반대 매매 실행 안내(D+5)";
			}

			// 평균가 주문인 경우 계약번호, 계약년월 추가
			String cntrctOrderNo = oppsTrdeVo.getCntrctOrderNo();
			String orderMsg = commAvrgpcOrderService.getOrderInfoString(orderNo, cntrctOrderNo);

			Map<String, String> smsMap = new HashMap<String, String>();
			smsMap.put("commerceNtcnCn", commerceNtcnCn); // 알림 메세지
			smsMap.put("WRTM_OPPS_TRDE_TITLE", builder.toString());

			smsMap.put("ORDER_NO", orderMsg);                                   //주문번호
			smsMap.put("ORDER_PC", decFormat.format(orderPc));					//주문판매가액
			smsMap.put("UN_SETLE_AMOUNT", decFormat.format(unSetleAmount));     //상환예정금액
			smsMap.put("FRST_SETLE_AMOUNT", decFormat.format(frstSetleAmount)); //이월렛 입금액
			smsMap.put("SMS_CNT", String.valueOf(smsCnt));
			smsMap.put("MAII_CNT", String.valueOf(mailCnt));
			smsMap.put("PHONE_CNT", String.valueOf(phoneCnt));
			smsMap.put("CSTMR_CNTER_TELNO", csTelNo);
			smsMap.put("templateNum", String.valueOf(templateNum));

			String mssageSndngHistNo = smsService.insertSMSByReturnMssageSndngHistNo(smsVO, smsMap);

			/* 주문_미납 주문 관리 기본 테이블 등록 (20: 이메일, 30: SMS */
			NpyOrderManageVO npyMngVo = new NpyOrderManageVO(orderNo, "30", ordrrNm);
			npyMngVo.setMssageSndngHistNo(Integer.parseInt(mssageSndngHistNo));
			npyMngVo.setOrdrrMoblphonNo(phone);
			npyMngVo.setProcessCn(processCn);
			this.insertWrtmOrderManage(npyMngVo);

		}catch(Exception e) {
			log.error("ORDER_NO[{}] : {}", oppsTrdeVo.getOrderNo(), ExceptionUtils.getStackTrace(e));
		}
	}

   /**
   *
   * <pre>
   * 처리내용: 증거금 주문 미납 대상(D+4, D+5)에 대한 안내 EMAIL을 전송한다.
   * </pre>
   * @date 2022. 10. 20.
   * @author srec0070
   * @history
   * ------------------------------------------------
   * 변경일					작성자				변경내용
   * ------------------------------------------------
   * 2022. 10. 20.			srec0070			최초작성
   * ------------------------------------------------
   * @param oppsTrdeVo
   * @param csTelNo
   * @param templateNum
   */
	@Override
	public void sendWrtmOppsTrdeEmail(WrtmOppsTrdeVo oppsTrdeVo, String csTelNo, int templateNum) {
		log.warn("[sendWrtmOppsTrdeEmail] - {}", oppsTrdeVo.toString());

		try {
			String templateType = oppsTrdeVo.getTemplateType();
			if(!("D4".equals(templateType) || "D5".equals(templateType))) {
				throw new Exception("미납안내 메일 타입 오류");
			}

			DecimalFormat decFormat = new DecimalFormat("###,###");

			String orderNo = oppsTrdeVo.getOrderNo();
			String ordrrNm = oppsTrdeVo.getOrdrrNm();
			String ordrrEmail = oppsTrdeVo.getOrdrrEmail();
			String wrtmSetlePrearngeDe = oppsTrdeVo.getWrtmSetlePrearngeDe();
			int orderWt = oppsTrdeVo.getTotRealOrderWt();
			long goodsUntpc = oppsTrdeVo.getGoodsUntpc();
			long orderPc = oppsTrdeVo.getOrderPc();
			long firstAmount = oppsTrdeVo.getFrstSetleAmount();
			long wtChangegld = oppsTrdeVo.getWtChangegld();
			long expectDlvrf = oppsTrdeVo.getExpectDlvrf();
			long unSetleAmount = oppsTrdeVo.getUnSetleAmount();

			MailVO mailVo = new MailVO();
			mailVo.setMailTmptSeq(templateNum);								// 템플릿 번호(OP_EMAIL_TMPLAT_BAS): 미납에 의한 주문 취소 환불 처리 안내

			mailVo.setEmail(ordrrEmail);									// 이메일 (수신자)(주문자)
//			mailVo.setEmail("srec0007@sorincokr.onmicrosoft.com"); 			// 받는 사람 아이디( not null )
//			mailVo.setEmail("srec0070@sorincorp.com"); 						// 받는 사람 아이디( not null )
			mailVo.setMemberNo(oppsTrdeVo.getMberNo());						// 회원 번호
			mailVo.setEntrpsNo(oppsTrdeVo.getEntrpsNo());					// 업체 번호
			mailVo.setMailSendUserId("SYSTEM");								// 발신자 아이디 (로그인)

			mailVo.setMailSendEmail(mailMapper.selectMailTmpt(templateNum).getSntoEmail());				// 발신자 이메일 주소 (로그인)

			log.warn("::: mailVo : " + mailVo);

			Map<String, String> mailMap = new HashMap<String, String>();
			mailMap.put("ORDER_NO", oppsTrdeVo.getOrderNo());
			mailMap.put("TOT_REAL_ORDER_WT", String.valueOf(orderWt));
			mailMap.put("GOODS_UNTPC", decFormat.format(goodsUntpc));
			mailMap.put("ORDER_PC", decFormat.format(orderPc));
			mailMap.put("WT_CHANGEGLD", decFormat.format(wtChangegld));
			mailMap.put("EXPECT_DLVRF", decFormat.format(expectDlvrf));
			mailMap.put("FRST_SETLE_AMOUNT", decFormat.format(firstAmount));
			mailMap.put("SETLE_PREARNGE_DE", wrtmSetlePrearngeDe);
			mailMap.put("UN_SETLE_AMOUNT", decFormat.format(unSetleAmount));

			mailMap.put("CS_HIST_GUID", getCsHistGuids(orderNo));
			mailMap.put("OPPS_TRDE_TITLE", getWrtmOppsTrdeTitleCnts(oppsTrdeVo, templateType));
			mailMap.put("CS_TEL_NO", csTelNo);
			mailMap.put("serviceDomain", ClaimConstants.SERVICE_DOMAIN);

			log.warn("[END] mailMap : "+ mailMap.toString());

			int mailNoSeq = mailService.insertMailSendByReturnMailNo(mailVo, mailMap);

			/* 주문_미납 주문 관리 기본 테이블 등록 (20: 이메일, 30: SMS */
			String processCn = "반대 매매 실행 안내(D+5)";
			if("D4".equals(templateType)) {
				processCn = "반대 매매 진행 예정 안내(D+4)";
			}
			NpyOrderManageVO npyMngVo = new NpyOrderManageVO(orderNo, "20", ordrrNm);
			npyMngVo.setEmailSndngHistNo(mailNoSeq);
			npyMngVo.setOrdrrEmail(ordrrEmail);
			npyMngVo.setProcessCn(processCn);

			this.insertWrtmOrderManage(npyMngVo);
		}catch(Exception e) {
			log.error("ORDER_NO[{}] : {}", oppsTrdeVo.getOrderNo(), ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 * <pre>
	 * 처리내용: 주문_미납 주문 관리 기본 Insert
	 * @param cdtlnData
	 * @throws Exception
	 */
	private void insertWrtmOrderManage(NpyOrderManageVO npyMngVo) throws Exception{
			Map<String, String> npyOrderManageMap = new HashMap<String, String>();
			npyOrderManageMap.put("orderNo", npyMngVo.getOrderNo());						// 주문 번호
			npyOrderManageMap.put("npyProcessTyCode", npyMngVo.getNpyProcessTyCode());		// 미납 처리 유형 코드
			npyOrderManageMap.put("mssageSndngHistNo", String.valueOf(npyMngVo.getMssageSndngHistNo()));   	// 메시지 발송 이력 번호
			npyOrderManageMap.put("emailSndngHistNo", String.valueOf(npyMngVo.getEmailSndngHistNo()));    	// 이메일 발송 이력 번호
			npyOrderManageMap.put("ordrrNm", npyMngVo.getOrdrrNm());             			// 주문자 명
			npyOrderManageMap.put("moblphonNo", npyMngVo.getOrdrrMoblphonNo());          	// 주문자 휴대폰 번호
			npyOrderManageMap.put("ordrrEmail", npyMngVo.getOrdrrEmail());          		// 주문자 이메일
			npyOrderManageMap.put("userId", "SYSTEM");          							// CS 담당자 ID
			npyOrderManageMap.put("processCn", npyMngVo.getProcessCn());           			// 처리 내용

			cdtlnMessageService.insertNpyOrderManage(npyOrderManageMap);
	}

	   /**
	    * 메일 내용 중 가격산정근거 Contents를 조회 생성 한다.
	    */
	   private String getWrtmOrderCnclCnts(BatchOrderModel batchOrderModel) {
	       String rtnMsg = "";
	       try {
	       	List<Map<String, String>> livePcCalcList = wrtmCnclMapper.selectLivePcCalcBasisList(batchOrderModel);

	            StringBuilder builder = new StringBuilder();
	            builder.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"border-collapse:collapse; \" width=\"100%\">").append(System.lineSeparator());
	            builder.append("<thead>").append(System.lineSeparator());
	            builder.append("<tr style=\"height: 36px;\">").append(System.lineSeparator());
	            builder.append("<th align=\"center\" style=\"background: #efefef; border-bottom: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">일시</th>").append(System.lineSeparator());
	            builder.append("<th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">현재가</th>").append(System.lineSeparator());
	            builder.append("<th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">3M</th>").append(System.lineSeparator());
	            builder.append("<th align=\"center\" style=\"background: #efefef; border-bottom: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">SPOT 환율</th>").append(System.lineSeparator());
	            builder.append("</tr>").append(System.lineSeparator());
	            builder.append("</thead>").append(System.lineSeparator());
	            builder.append("<tbody>").append(System.lineSeparator());

	            String sleMthdCode = batchOrderModel.getSleMthdCode();
	            if( ( StringUtils.equals(SleMthdCode.LIVE.getCode(), sleMthdCode)
	            		|| StringUtils.equals(SleMthdCode.LIMIT.getCode(), sleMthdCode))
	            	  && !CollectionUtils.isEmpty(livePcCalcList)){

		           	 for(Map<String, String> livePcCalcMap : livePcCalcList) {

		           		     builder.append("<tr>").append(System.lineSeparator());
				           	 builder.append("<td align=\"center\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">" + livePcCalcMap.get("OCCRRNC_DATE") + "</td>").append(System.lineSeparator());
				           	 builder.append("<td align=\"right\" style=\"padding: 0 10px 0 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">" + livePcCalcMap.get("END_PC") + "</td>").append(System.lineSeparator());
				           	 builder.append("<td align=\"right\" style=\"padding: 0 10px 0 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">" + livePcCalcMap.get("THREEMONTH_LME_PC") + "</td>").append(System.lineSeparator());
				           	 builder.append("<td align=\"center\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">" + livePcCalcMap.get("EHGT_PC") + "</td>").append(System.lineSeparator());
				           	 builder.append("</tr>").append(System.lineSeparator());

		           	 }
	            }else {
		           	 builder.append("<tr>").append(System.lineSeparator());
		           	 builder.append("<td align=\"center\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">&nbsp;</td>").append(System.lineSeparator());
		           	 builder.append("<td align=\"right\" style=\"padding: 0 10px 0 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">&nbsp;</td>").append(System.lineSeparator());
		           	 builder.append("<td align=\"right\" style=\"padding: 0 10px 0 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">&nbsp;</td>").append(System.lineSeparator());
		           	 builder.append("<td align=\"center\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">&nbsp;</td>").append(System.lineSeparator());
		           	 builder.append("</tr>").append(System.lineSeparator());
	            }
	            builder.append("</tbody></table>").append(System.lineSeparator());

	            rtnMsg = builder.toString();

	       }catch(Exception e){
	            log.error(ExceptionUtils.getStackTrace(e));
	       }

	       return rtnMsg;
	  }

		/**
		* 메일 내용 중 CS이력안내 Contents를 조회 생성 한다.
		*/
	   private String getCsHistGuids(String orderNo) {
	       String rtnMsg = "";
	       try {

	            List<ArrrgTrgterVO> csResults = wrtmCnclMapper.selectNpyOrderManageList(orderNo);

	            StringBuilder builder = new StringBuilder();
	            builder.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"border-collapse:collapse; \" width=\"100%\">").append(System.lineSeparator());
	            builder.append("<thead>").append(System.lineSeparator());
	            builder.append("<tr style=\"height: 36px;\">").append(System.lineSeparator());
	            builder.append("<th align=\"center\" style=\"background: #efefef; border-bottom: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">유형</th>").append(System.lineSeparator());
	            builder.append("<th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">고객정보</th>").append(System.lineSeparator());
	            builder.append("<th align=\"center\" style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">처리일시</th>").append(System.lineSeparator());
	            builder.append("<th align=\"center\" style=\"background: #efefef; border-bottom: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 18px;\">CS담당자</th>").append(System.lineSeparator());
	            builder.append("</tr>").append(System.lineSeparator());
	            builder.append("</thead>").append(System.lineSeparator());
	            builder.append("<tbody>").append(System.lineSeparator());

	            if( !CollectionUtils.isEmpty(csResults) ) {

	                 for(ArrrgTrgterVO csVo : csResults) {
	                	  String npyProcessTyCode = csVo.getNpyProcessTyCode();
	                	  String npyProcessTy = csVo.getNpyProcessTy();
	                      String ordrrInfo = csVo.getOrdrrNm();
	                      String ordrrEmail = csVo.getOrdrrEmail();
	                      String ordrrMoblphonNo = csVo.getOrdrrMoblphonNo();

	                      if("20".equals(npyProcessTyCode)) {
		                      if(StringUtils.isNotEmpty(ordrrEmail)) {
		                           ordrrInfo += "(" + ordrrEmail + ")";
		                      }
	                      }else {
	                    	  if(StringUtils.isNotEmpty(ordrrMoblphonNo)) {
	                    		  ordrrMoblphonNo = getDecPhone(ordrrMoblphonNo, orderNo);
	                    		  ordrrInfo += "(" + ordrrMoblphonNo + ")";
	                    	  }
	                      }

	                      String processDt  = csVo.getProcessDt();
	                      if(StringUtils.isEmpty(processDt)) processDt = "-";

	                      String csChargerNm = csVo.getCsChargerNm();
	                      if(StringUtils.isEmpty(csChargerNm)) csChargerNm = "-";

	                      builder.append("<tr>").append(System.lineSeparator());
	                      builder.append("<td align=\"center\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">" + npyProcessTy + "</td>").append(System.lineSeparator());
	                      builder.append("<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">" + ordrrInfo + "</td>").append(System.lineSeparator());
	                      builder.append("<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">" + processDt + "</td>").append(System.lineSeparator());
	                      builder.append("<td align=\"center\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">" + csChargerNm + "</td>").append(System.lineSeparator());
	                      builder.append("</tr>").append(System.lineSeparator());
	                 }
	            }else {
	                builder.append("<tr>").append(System.lineSeparator());
	                builder.append("<td align=\"center\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">&nbsp;</td>").append(System.lineSeparator());
	                builder.append("<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">&nbsp;</td>").append(System.lineSeparator());
	                builder.append("<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">&nbsp;</td>").append(System.lineSeparator());
	                builder.append("<td align=\"center\" style=\"padding: 4px 0; border-bottom: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\">&nbsp;</td>").append(System.lineSeparator());
	                builder.append("</tr>").append(System.lineSeparator());
	            }

	            builder.append("</tbody></table>").append(System.lineSeparator());

	            rtnMsg = builder.toString();

	       }catch(Exception e){
	            log.error("[getCsHistGuidContents] " + ExceptionUtils.getStackTrace(e));
	       }

	       return rtnMsg;
	  }

	/**
	 * 미납금 안내 메일 타이틀 컨텐츠 생성하기(D+4일, D+5일)
	 */
	private String getWrtmOppsTrdeTitleCnts(WrtmOppsTrdeVo oppsTrdeVo, String templateType) {

		String ENTRPS_NM = oppsTrdeVo.getOrderEntrpsNm();
		String OPPS_TRDE_PRARNDE = oppsTrdeVo.getOppsTrdePrarnde();
		try {
			if(OPPS_TRDE_PRARNDE != null && OPPS_TRDE_PRARNDE.length() == 8)
				OPPS_TRDE_PRARNDE = DateUtil.getFormatDate(OPPS_TRDE_PRARNDE, "yyyy년 MM월 dd일");
		}catch(Exception e) {
			log.error("[Parsing Error] {}", ExceptionUtils.getStackTrace(e));
		}

		StringBuilder builder = new StringBuilder();
		if("D4".equals(templateType)){
			builder.append("<h2 style=\"margin: 0; color: #222; font-size:22px; line-height: 38px; font-weight: bold; letter-spacing: -1.5px; font-family: 맑은고딕, Malgun Gothic, dotum, gulim, sans-serif;\">").append(System.lineSeparator());
			builder.append(ENTRPS_NM + "회원님,&nbsp;</br>").append(System.lineSeparator());
			builder.append("<span style=\"color: #1D5FD0\">&nbsp;&nbsp;상환 기간 내 금액이 납부되지 않아 " + OPPS_TRDE_PRARNDE + "</span><br/>").append(System.lineSeparator());
			builder.append("<span style=\"color: #1D5FD0;\">반대매매 진행 예정임</span>을 알려드립니다. <br>반대매매 진행시 기납부한 증거금에서 수수료 및 차액을 차감한</br>").append(System.lineSeparator());
			builder.append("금액이 가상계좌로 입금 예정입니다.").append(System.lineSeparator());
			builder.append("</h2>").append(System.lineSeparator());
		}else {
			builder.append("<h2 style=\"margin: 0; color: #222; font-size:22px; line-height: 38px; font-weight: bold; letter-spacing: -1.5px; font-family: 맑은고딕, Malgun Gothic, dotum, gulim, sans-serif;\">").append(System.lineSeparator());
			builder.append(ENTRPS_NM + "회원님,&nbsp;</br>").append(System.lineSeparator());
			builder.append("<span style=\"color: #1D5FD0\">&nbsp;&nbsp;증거금에 대한 잔금이 상환 기간 내 금액이 납부되지 않아</span></br>").append(System.lineSeparator());
			builder.append("<span style=\"color: #1D5FD0;\">" + OPPS_TRDE_PRARNDE + " 반대매매 실행 함</span>을 알려드립니다. </br>").append(System.lineSeparator());
			builder.append("반대매매 실행 후 기납부한 증거금에서 수수료 및 차액을 차감한</br>").append(System.lineSeparator());
			builder.append("금액이 가상계좌로 입금 예정입니다.").append(System.lineSeparator());
			builder.append("</h2>").append(System.lineSeparator());
		}

		return builder.toString();
	}

	/**
	 * 암호화된 전화번호를 복호화한다.
	 */
	private String getDecPhone(String phone, String orderNo) {
		String decPhone = String.valueOf(phone);
		if(StringUtils.isNotEmpty(phone) && !phone.equals("null")) {
			try {
				decPhone = CryptoUtil.decryptAES256(phone);
			} catch(Exception e) {
				log.error("ORDER_NO[{}] ERROR. {}", orderNo, ExceptionUtils.getStackTrace(e));
			}
		}
		return decPhone;
	}
}
