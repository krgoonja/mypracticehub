package com.sorincorp.batch.or.job;

import java.util.Map;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.or.service.OrderLimitCncService;

import lombok.extern.slf4j.Slf4j;

/**
 * OrderPrvsnlLimitCncTasklet.java
 * 가단가 지정가 주문 취소 배치 Tasklet
 * @version
 * @since 2024. 10. 23.
 * @author srec0066
 */
@Slf4j
@Component
public class OrderPrvsnlLimitCncTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	OrderLimitCncService orderLimitCncService;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("OrderPrvsnlLimitCncTasklet::beforeStep");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("OrderPrvsnlLimitCncTasklet::execute Start");

		JobParameters jobParameters = chunkContext.getStepContext().getStepExecution().getJobParameters();
		Map<String, JobParameter> jobParamMap = jobParameters.getParameters();
		JobParameter param = jobParamMap.get("param01");

		String time = null;
		if(null != param) {
			time = param.toString();
		}
		log.info("OrderPrvsnlLimitCncTasklet::time - {}", time);

		orderLimitCncService.cancelPendingPrvsnlOrders(time);

		log.debug("OrderPrvsnlLimitCncTasklet::execute End");
		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("OrderPrvsnlLimitCncTasklet::afterStep");
        return ExitStatus.COMPLETED;
	}

}
