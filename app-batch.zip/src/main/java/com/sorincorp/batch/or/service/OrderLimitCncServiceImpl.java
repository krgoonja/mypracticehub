package com.sorincorp.batch.or.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.sorincorp.batch.or.mapper.OrderLimitMapper;
import com.sorincorp.batch.or.model.OrderLimitCncVO;
import com.sorincorp.batch.or.model.OrderLimitVO;
import com.sorincorp.comm.bsnInfo.model.RltmEndTimeVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.order.service.CommDashboardWebsocketService;
import com.sorincorp.comm.order.service.CommFrontOrderWebsocketService;
import com.sorincorp.comm.order.service.CommLimitOrderRedisPubService;
import com.sorincorp.comm.order.service.CommLimitOrderService;
import com.sorincorp.comm.order.service.CommPrvsnlLimitOrderRedisPubService;
import com.sorincorp.comm.order.service.CommPrvsnlOrderService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OrderLimitCncServiceImpl implements OrderLimitCncService {

	@Autowired
	private OrderLimitMapper orderLimitMapper;
	/** 지정가 주문 공통 서비스 */
	@Autowired
	private CommLimitOrderService commLimitOrderService;
	/** 가단가 주문 공통 서비스 */
	@Autowired
	private CommPrvsnlOrderService commPrvsnlOrderService;
	/** websocket FO */
	@Autowired
	private CommFrontOrderWebsocketService commFrontOrderWebsocketService;
	/** websocket BO */
	@Autowired
	private CommDashboardWebsocketService commDashboardWebsocketService;
	/** redis 지정가 주문 메시지 발행 서비스 */
	@Autowired
	private CommLimitOrderRedisPubService commLimitOrderRedisPubService;
	/** redis 가단가 지정가 주문 메시지 발행 서비스 */
	@Autowired
	private CommPrvsnlLimitOrderRedisPubService commPrvsnlLimitOrderRedisPubService;

	@Autowired
	private BsnInfoService bsnInfoService;
	/** 공통 서비스 */
    @Autowired
    private CommonService commonService;

	/**
	 * 미체결 지정가 주문 취소 처리
	 */
	@Override
	public void cancelPendingOrders(String time) throws Exception {
		log.info("cancelPendingOrders ::: IN");
		/* 
		 * 하절기 22시, 동절기 23시 배치 실행을 체크하기 위함.
		 * 2024.2.16 기준 17, 22, 23시 배치가 각각 존재 
		 * */
		if (StringUtils.isNotBlank(time)) {
			log.info("cancelPendingOrders ::: time param : {}",time); // 170000, 220000, 230000 
			//운영 종료 시간 조회
			RltmEndTimeVO rltmEndTimeVO = bsnInfoService.getRltmEndTime();
			String rltmEndTime = rltmEndTimeVO.getRltmEndTimeValue(); // 220000
			String rltmMidTime = rltmEndTimeVO.getRltmMidTimeValue(); // 170000
			//지정가 유효시간과 운영종료시간이 일치하지 않으면 종료
			if ( !time.equals(rltmEndTime) && !time.equals(rltmMidTime)) {
				log.info("cancelPendingOrders ::: 지정가 유효시간 파라미터와 운영종료시간이 불일치. 유효시간 파라미터 {}, 종료시간1 {}, 종료시간2 {}",time,rltmMidTime,rltmEndTime);
				return;
			}
		}

		OrderLimitCncVO orderLimitCncVO = new OrderLimitCncVO();
		orderLimitCncVO.setTime(time);

		int ret = orderLimitMapper.cancelPendingOrders(orderLimitCncVO);
		if (ret > 0) {
			orderLimitMapper.insertOrLimitOrderBasHst(orderLimitCncVO);
		}
		log.info("{} 미체결 지정가 취소건 : {}", DateUtil.getNowDateTime("yyyy-MM-dd") + " "+ time, ret);

		// 지정가 주문 취소 완료 후 처리
		limitOrderCancelComplate(orderLimitCncVO);

		log.info("cancelPendingOrders ::: OUT");
	}

	/**
	 * <pre>
	 * 지정가 주문 취소 완료 후 처리 <br>
	 * 1. 주문 취소 SMS 발송
	 * </pre>
	 * @date 2023. 5. 22.
	 * @author srec0051
	 */
	private void limitOrderCancelComplate(OrderLimitCncVO orderLimitCncVO) {
		log.info("limitOrderCancelComplate ::: IN");

		try {
			/** 주문 취소 SMS 발송 */
			List<OrderLimitVO> limitOrderList = orderLimitMapper.selectListCncLimitOrder(orderLimitCncVO);
			if (!CollectionUtils.isEmpty(limitOrderList)) {
				int i = 0;
				int listSize = limitOrderList.size();
				for (OrderLimitVO vo : limitOrderList) {
					++i;
					/** Redis 전송 */
					commLimitOrderRedisPubService.limitOrderMsgPublish(vo.getLimitOrderNo(), "D");

					/** 지정가 주문정보 fo websocket 호출 */
					Map<String, Object> sendTarget = new HashMap<>();
					sendTarget.put("type", "C");	// type : 주문 - O, 취소 (제거요청) - C
					sendTarget.put("limitOrderNo", vo.getLimitOrderNo());
					commFrontOrderWebsocketService.publishLimitOrder(sendTarget, true);

					// 허수주문은 취소 SMS 발송 안함
					if (vo.getImaginaryOrderAt().equals("N")) {
						commLimitOrderService.limitOrderCancelSendSms(vo.getLimitOrderNo(), "Y");
					}

					/** 지정가 주문정보 bo websocket 호출 (bo에서는 구독정보 갱신시 DB 데이터를 조회하므로 마지막에 한 번 call 한다) */
					if (i == listSize) {
						commDashboardWebsocketService.publishLimitOrder(vo.getLimitOrderNo(), true);
					}

					/** 쿠폰 사용 원복 */
					commLimitOrderService.limitOrderCouponUpdate(vo.getLimitOrderNo(), "BATCH");
				}
			}
		} catch (Exception e) {
			log.error("limitOrderCancelSendSms ::: 미체결 지정가 주문 취소 건 SMS 발송 오류 :::", e);
		}

		log.info("limitOrderCancelComplate ::: OUT");
	}

	/**
	 *  미체결 가단가 지정가 주문 취소 처리
	 */
	@Override
	public void cancelPendingPrvsnlOrders(String time) throws Exception {
		log.info("cancelPendingPrvsnlOrders ::: IN");

		RltmEndTimeVO rltmEndTimeVO = bsnInfoService.getRltmEndTime();

		if (StringUtils.isNotBlank(time)) {
			// 운영 종료 시간 조회
			String rltmEndTime = rltmEndTimeVO.getRltmEndTimeValue(); // 220000

			// 지정가 유효시간과 운영종료시간이 일치하지 않으면 종료
			if ( !time.equals(rltmEndTime)) {
				log.info("cancelPendingPrvsnlOrders ::: 지정가 유효시간 파라미터와 운영종료시간이 불일치. 유효시간 파라미터 {}, 종료시간 {}", time, rltmEndTime);
				return;
			}
		} else {
			// 시간 파라미터 없을 경우, 영업종료 시간 기본으로 조회
			time = rltmEndTimeVO.getRltmEndTimeValue();
		}

		OrderLimitCncVO orderLimitCncVO = new OrderLimitCncVO();
		orderLimitCncVO.setTime(time);

		// 1. 취소 대상 미체결 가단가 지정가 주문목록 조회
		// - 지정가 주문 상태 = 미체결
		// - 지정가 유효일자 = 오늘
		// - 지정가 유효시간 <= 영업 종료시간
		List<OrderLimitVO> targetOrderList = orderLimitMapper.selectCnclTrgetPrvsnlLimitOrderList(orderLimitCncVO);
		for (OrderLimitVO order : targetOrderList) {

			// 2. 가단가 지정가 주문 취소처리 - 지정가 주문 상태 코드: 48.지정가 주문취소(유효 시간 경과)
			int res = commPrvsnlOrderService.updateCommPrvsnlLimitOrderSttusCode(order.getLimitOrderNo(), "48", null, "BATCH");

			// 지정가 구분 코드
			String limitSeCode = order.getLimitSeCode();
			if(res > 0) {
				// 3. 이력 테이블 등록
				if("F".equals(limitSeCode)) {
					commonService.insertTableHistory("OR_LIMIT_ORDER_LME_BAS", order);  // LME
				} else if("X".equals(limitSeCode)) {
					commonService.insertTableHistory("OR_LIMIT_ORDER_EHGT_BAS", order); // 환율
				} else if("R".equals(limitSeCode)) {
					commonService.insertTableHistory("OR_LIMIT_ORDER_KRW_BAS", order);  // KRW
				}
			}

			// 4. Redis 삭제 메세지 전송
			if("F".equals(limitSeCode)) {
				commPrvsnlLimitOrderRedisPubService.prvsnlLimitOrderMsgFxPublish(order.getLimitOrderNo(), "D");
			} else {
				commPrvsnlLimitOrderRedisPubService.prvsnlLimitOrderMsgLmePublish(order.getLimitOrderNo(), "D");
			}

			// 5. 지정가 자동 취소 SMS 발송
			commPrvsnlOrderService.prvsnlLimitOrderCancelSendSms(order.getLimitOrderNo(), "Y");

			// 6. 쿠폰 사용 원복
			commLimitOrderService.limitOrderCouponUpdate(order.getLimitOrderNo(), "BATCH");
		}

		log.info("cancelPendingPrvsnlOrders ::: OUT");
	}
}
