package com.sorincorp.batch.or.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.batch.or.model.BatchOrderModel;

public interface WrtmOrderCnclService {

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소 주문에 필요한 다음달 선물, 선물환의 만기일를 조회한다.
	 *        고객센터 정보 조회한다.
	 *        발신자 메일 주소 조회한다.
	 * </pre>
	 * @date 2022. 10. 19.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 19.			srec0070			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectBeforeProcInfo() throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 주문중 연체된 주문 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 9. 5.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 5.			srec0070			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<BatchOrderModel> selectWrtmArrrgOrderList(String wrtmCanclOrderNo) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 연체 주문을 취소처리 한다.
	 * </pre>
	 * @date 2022. 9. 5.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 5.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @throws Exception
	 */
	void doWrtmOrderCncl(BatchOrderModel param) throws Exception;
}
