package com.sorincorp.batch.or.service;

/**
 * 매일 8시30분 ERP생성 오류 건메일 발송 (세금계산서) batch Service(휴일,공휴일 제외)
 * TaxbilUnIsuService.java
 * @version
 * @since 2023. 12. 18.
 * @author sein
 */
public interface TaxbilUnIsuService {
	
	/**
	 * 
	 * <pre>
	 * ERP생성 오류 건메일 발송 (세금계산서)
	 * </pre>
	 * @date 2023. 12. 18.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 12. 18.	  	sein			    최초작성
	 * ------------------------------------------------
	 */
	void sendTaxbilUnIsu() throws Exception;
	
}