package com.sorincorp.batch.or.model;

import lombok.Data;

@Data
public class AvrgUntpcDcsnVO {
	/******  JAVA VO CREATE : cn_cntrct_order_bas(계약_계약 발주 기본)                                                                       ******/
    /**
     * 계약 발주 번호
    */
    private String cntrctOrderNo;
    /**
     * 회원 번호
    */
    private String mberNo;
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 판매 방식 코드
    */
    private String sleMthdCode;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 주문 중량
    */
    private int orderWt;
    /**
     * 배송 수단 코드
    */
    private String dlvyMnCode;
    /**
     * 출고 요청 일자
    */
    private String dlivyRequstDe;
    /**
     * 권역 중분류 코드
    */
    private String dstrctMlsfcCode;
    /**
     * 배송지 번호
    */
    private String dlvrgNo;
    /**
     * 단가 산식 코드
    */
    private String untpcMntnfrmlaCode;
    /**
     * 통화 구분 코드
    */
    private String crncySeCode;
    /**
     * 프리미엄 가격
    */
    private long premiumPc;
    /**
     * 단가 확정 일자
    */
    private String untpcDcsnDe;
    /**
     * 판매 단위 중량
     */
    private int sleUnitWt;
    
    /**
     * 주문 번호
     */
    private String orderNo;
    /**
     * 주문 상태 코드
     */
    private String orderSttusCode;
    /**
     * 상품 단가
    */
    private long goodsUntpc;
    /**
     * 주문 가격
    */
    private long orderPc;
    /**
     * 중량 변동금
    */
    private long wtChangegld;
    /**
     * 공급가
    */
    private long splpc;
    /**
     * 부가세
    */
    private long vat;
    /**
     * 판매가
    */
    private long slepc;
    /**
     * 정산 처리 여부
    */
    private String excclcProcessAt;
    /**
     * 총 확정 중량
    */
    private java.math.BigDecimal totDcsnWt;
    /**
     * 총 확정 주문 가격
    */
    private Long totDcsnOrderPc;
    /**
     * 총 확정 공급가
    */
    private Long totDcsnSplpc;
    /**
     * 정산 공급가
    */
    private Long excclcSplpc;
    /**
     * 정산 부가세
    */
    private Long excclcVat;
    /**
     * 정산 금액
    */
    private Long excclcAmount;
    /**
     * 중량 변동
    */
    private double wtChange;
    /**
     * 결제 방식 코드
    */
    private String setleMthdCode;
    /**
     * 미 결제 금액
    */
    private long unSetleAmount;
    /**
     * 쿠폰 적용 여부
    */
    private String couponApplcAt;
    /**
     * 원 상품 단가
    */
    private long orgGoodsUntpc;
    
    // 평균가 - 평균가 관련 데이터
    /**
     * 평균가 주문 단가 (가단가)
     */
    private long avrgpcGoodsUntpc;
    
    /**
     * 평균가 주문 가격
    */
    private long avrgpcOrderPc;
    /**
     * 평균가 중량 변동금
    */
    private long avrgpcWtChangegld;
    /**
     * 평균가 공급가
    */
    private long avrgpcSplpc;
    /**
     * 평균가 판매가
     */
    private long avrgpcSlepc;
    
    /**
     * 담보 상태 코드
     */
    private String mrtggSttusCode;
    /**
     * 상환 기간
    */
    private int repyPd;
    
    /**
     * 쿠폰 구분 코드
    */
    private String couponSeCode;
    /**
     * 중복 사용 제한 여부
    */
    private String couponDplctUseLmttQyAt;
    
    /**
     * 쿠폰 일련 번호
    */
    private int couponSeqNo;
    
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    
    /*
     * 환불 금액
     * */
    private long refndAmount;
    
    // SMS 전송 시 사용되는 추가 데이터
    /**
	 * 주문 업체 명
	 */
	private String orderEntrpsNm;
	/**
	 * 주문자명
	 */
	private String ordrrNm;
	/**
	 * 주문자 휴대폰 번호
	 */
	private String ordrrMoblphonNo;
	/**
	 * 주문 일자
	 */
	private String orderDe;
	/**
	 * 상품명
	 */
	private String goodsNm;
	/**
	 * 브랜드 그룹명
	 */
	private String brandGroupNm;
	/**
	 * 총 실제 주문 중량
	 */
	private String totRealOrderWt;
	/**
	 * 결제 방법
	 */
	private String payMethod;
	/**
	 * 예상 배송비
	 */
	private String expectDlvrf;
	/**
     * 결제 예정일
     */
    private String setlePrearngeDe;
    /**
	 * 배송 방법
	 */
	private String dlvyMnNm;
	/**
	 * 창고 이름
	 */
	private String wrhousNm;
	/**
	 * 배송지 명
	 */
	private String dlvrgNm;
	/**
	 * 수취 업체 담당자 명
	 */
	private String receptEntrpsChargerNm;
	/**
	 * 수취 업체 휴대폰 번호
	 */
	private String receptEntrpsMoblphonNo;
	/**
	 * 배송 요청 내용
	 */
	private String dlvyRequstCn;
	/**
	 * 회원 구분 코드
	 */
	private String mberSeCode;
	/**
	 * 취소 교환 반품 번호
	 */
	private String canclExchngRtngudNo;
	/**
	 * 등급 할인 금액
	 */
	private long gradApplcAmount;
}
