package com.sorincorp.batch.or.service;

import com.sorincorp.batch.credt.model.WrtmOppsTrdeVo;
import com.sorincorp.batch.or.model.BatchOrderModel;

public interface WrtmMsgService {

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소 완료후 안내 메일을 고객에게 전송한다.
	 * </pre>
	 * @date 2022. 10. 18.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 18.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param batchOrderModel
	 */
	void sendWrtmOrderCnclMail(BatchOrderModel batchOrderModel);

	/**
	    *
	    * <pre>
	    * 처리내용: 고객 및 내부 관리자 그룹에게 관련 내용을 SMS전송한다.
	    * </pre>
	    * @date 2022. 10. 20.
	    * @author srec0070
	    * @history
	    * ------------------------------------------------
	    * 변경일					작성자				변경내용
	    * ------------------------------------------------
	    * 2022. 10. 20.			srec0070			최초작성
	    * ------------------------------------------------
	    * @param batchOrderModel
	    * @param templateNum
	    * @param returnMsg
	    * @param errMsg
	    */
	void sendWrtmOrderCnclSms(BatchOrderModel batchOrderModel, String templateNum, String returnMsg, String errMsg);

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 주문 미납 대상(D+4, D+5)에 대한 안내 SMS를 전송한다.
	 * </pre>
	 * @date 2022. 10. 27.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 27.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param ordInfo
	 * @param csTelNo
	 * @param templateNum
	 */
	void sendWrtmOppsTrdeSms(WrtmOppsTrdeVo ordInfo,  String csTelNo, int templateNum);

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 주문 미납 대상(D+4, D+5)에 대한 안내 메일을 전송한다.
	 * </pre>
	 * @date 2022. 10. 27.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 27.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param ordInfo
	 * @param csTelNo
	 * @param invalid
	 */
	void sendWrtmOppsTrdeEmail(WrtmOppsTrdeVo ordInfo,  String csTelNo, int templateNum);


}
