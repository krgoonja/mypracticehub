package com.sorincorp.batch.or.service;

import java.util.Map;

/**
 * PrvsnlPcChangegldRealarmService.java
 * 가단가 변동금 재알람 관련 Service 인터페이스
 * 
 * @version
 * @since 2024. 11. 21.
 * @author srec0049
 */
public interface PrvsnlPcChangegldRealarmService {

	/**
	 * <pre>
	 * 처리내용: 가단가 변동금 재알람 배치 수행
	 * </pre>
	 * @date 2024. 11. 21.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 21.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param map
	 * @throws Exception
	 */
	public void callPrvsnlPcChangegldRealarm(Map<String, String> map) throws Exception;
}
