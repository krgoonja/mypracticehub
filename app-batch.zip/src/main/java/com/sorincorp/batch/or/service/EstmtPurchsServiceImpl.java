package com.sorincorp.batch.or.service;

import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.batch.or.comm.OrCommonConstants;
import com.sorincorp.batch.or.mapper.ClaimMapper;
import com.sorincorp.batch.or.mapper.EstmtPurchsMapper;
import com.sorincorp.batch.or.model.AvrgUntpcDcsnVO;
import com.sorincorp.batch.or.model.EstmtPurchsVO;
import com.sorincorp.batch.or.model.OrSetleBasVO;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.model.CnCntrctOrderBasVO;
import com.sorincorp.comm.order.model.OrOrderAvrgpcDtlVO;
import com.sorincorp.comm.order.model.OrderEntrpsSetleMnVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.comm.order.service.CommAvrgpcOrderService;
import com.sorincorp.comm.order.service.CommOrderService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * BfeMtAvrgLmeCspImpl.java
 * @version
 * @since 2023. 11. 6.
 * @author srec0070
 */
@Slf4j
@Service
public class EstmtPurchsServiceImpl implements EstmtPurchsService {

	@Autowired
	private OrCommonConstants orProperty;

    @Autowired
    private CommOrderService commOrderService;

	@Autowired
	private CommAvrgpcOrderService commAvrgpcOrderService;

	@Autowired
    private AssignService assignService;

	@Autowired
	private SMSService smsService;

	@Autowired
	private EstmtPurchsMapper estmtPurchsMapper;

	@Autowired
	private ClaimMapper claimMapper;

	@Autowired
    private HttpClientHelper httpClientHelper;

	@Autowired
    private ObjectMapper objectMapper;

	@Value("${credit.mrtgg.repy.url}")
	private String repyMrtggUrl;
	

	@Override
	public boolean isFirstOrLastBusinessDayOfMonth(String yyyyMMdd, String executeTimePoint) throws Exception {
		String time = yyyyMMdd.substring(0,6);	// yyyyMM
		
		// 영업일 도출
		// executeTimePoint 가 "FIRST"일 시 : 해당 월의 첫번째 영업일 도출
		// executeTimePoint 가 "LAST" 일 시 : 해당 월의 마지막 영업일 도출
		String businessDay = estmtPurchsMapper.getFirstOrLastBusinessDayOfMonth(time, executeTimePoint);
		
		boolean result = StringUtils.equals(businessDay, yyyyMMdd);
		
		log.info("현재 일자 : {}, 영업일 : {}, 첫번째 혹은 마지막 영업일 여부 : {}", yyyyMMdd, businessDay, result);
		
		return result;
	}

	/**
	 * 매달 말일에 원자재 LME CSP를 평균을 구하여 해당 BL의 평균가 계약의 LME, 최종 가격등을 계산한다.
	 *
	 */
//	@Transactional(value = "batchTransactionManager")
	@Override
	public void executeBfeMtAvrgLmeCsp(String occrrncMt) throws Exception {

		EstmtPurchsVO estmtPurchsvo = new EstmtPurchsVO();
		estmtPurchsvo.setOccrrncMt(occrrncMt);

		//1. 이전월 금속코드별, 권역 대분류, 브랜드 그룹별 LME CSP 구하기
		List<EstmtPurchsVO> avgrLmeCspList = estmtPurchsMapper.selectBfeMtAvrgLmeCspList(estmtPurchsvo);
		log.info("===> 평균 LME CSP SIZE:[{}]", avgrLmeCspList.size());
		int i=0;
		for(EstmtPurchsVO avgrLmeCspData : avgrLmeCspList) {

			log.info("{}===> 평균 LME CSP DATA:{}", ++i, avgrLmeCspData.toString());

			int updResult1 = updateCnAvrgpcFtrsBasLmeCsp(avgrLmeCspData);

			log.info("{}===> UPDATE CN_AVRGPC_FTRS_BAS COUNT:[{}]", i, updResult1);

		}

	}

	/**
	 * CN_AVRGPC_FTRS_BAS 테이블의 LME, 최종 가겨 등을 수정한다.
	 */
	private int updateCnAvrgpcFtrsBasLmeCsp(EstmtPurchsVO paramVo) throws Exception {
		int resultCnt = 0;


		log.info("#################### CN_AVRGPC_FTRS_BAS UPDATE ####################");

		resultCnt = estmtPurchsMapper.updateCnAvrgpcFtrsBasLmeCsp(paramVo);
		if(resultCnt > 0) {
			estmtPurchsMapper.insertCnAvrgpcFtrsBasHst(paramVo);
			updateOrOrderFtrsDtlLmeCsp(paramVo);
		}

		return resultCnt;
	}

	/**
	 * OR_ORDER_FTRS_DTL 테이블의 체결단가, 평균가 스프레드 등을 수정한다.
	 */
	private int updateOrOrderFtrsDtlLmeCsp(EstmtPurchsVO paramVo) throws Exception {
		int updTotCnt = 0;
		try {
			log.info("#################### OR_ORDER_FTRS_DTL UPDATE ####################");

			List<EstmtPurchsVO> ftrsDtlList = estmtPurchsMapper.selectCntrctFtrsDtlList(paramVo);
			Map<String, EstmtPurchsVO> ftrsBasMap = new HashMap<String, EstmtPurchsVO>();

			for( EstmtPurchsVO ftrsData : ftrsDtlList) {

				int resultCnt = estmtPurchsMapper.updateOrOrderFtrsDtlLmeCsp(ftrsData);
				updTotCnt += resultCnt;

				log.info("==> Update OR_ORDER_FTRS_DTL Count:{}", resultCnt);
				log.info("==> param:{}", ftrsData.toString());

				// OR_ORDER_FTRS_BAS 테이블의 REQUST_FTRS_CMPNY_SE_CODE(요청 선물사 구분 코드)를 업데이트 하기 위해 Map에 저장
				String ftrsRequstOrderNo = ftrsData.getFtrsRequstOrderNo();
				if(!ftrsBasMap.containsKey(ftrsRequstOrderNo)) {
					ftrsBasMap.put(ftrsRequstOrderNo, ftrsData);
				}
			}

			// OR_ORDER_FTRS_BAS 테이블 수정
			for(String key : ftrsBasMap.keySet()) {

				EstmtPurchsVO ftrsBasData = ftrsBasMap.get(key);

				String requstFtrsCmpnySeCode = ftrsBasData.getRequstFtrsCmpnySeCode();//요청 선물사 구분 코드
				String cnclsFtrsprofsSeCode  = ftrsBasData.getCnclsFtrsprofsSeCode();  //체결 선물사 구분 코드)

				if(cnclsFtrsprofsSeCode != null && !StringUtils.equals(requstFtrsCmpnySeCode, cnclsFtrsprofsSeCode)) {
					estmtPurchsMapper.updateOrOrderFtrsBasLmeCsp(ftrsBasData);
					log.info("==> Update OR_ORDER_FTRS_BAS BEFOR:{}, AFTER:{}", requstFtrsCmpnySeCode, cnclsFtrsprofsSeCode);
				}

				log.info("==> param:{}", ftrsBasData.toString());
			}

		}catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
		return updTotCnt;
	}

	/**
	 *	평균가 주문 단가 확정 처리
	 */
	@Override
	public void executeAvrgUntpcDcsn(String orderNos) throws Exception {
		// 24-01-19 변경사항 : 테스트 코드 추가
		String[] orderNoInArray = null;
		if(StringUtils.isNotBlank(orderNos)) {
			orderNoInArray = orderNos.split(",");
		}

		OrderModel orderModel = null;
		CnCntrctOrderBasVO cnCntrctOrderBasVO = null;

		// 1. 처리 대상 주문의 발주 번호 및 로직 처리에 필요한 데이터 조회
		List<AvrgUntpcDcsnVO> targetList = estmtPurchsMapper.selectAvrgUntpcDcsnData(orderNoInArray);

		for (AvrgUntpcDcsnVO targetVO : targetList) {
			try {
				// 로직 실행에 필요한 parameter get
				String orderNo = targetVO.getOrderNo();
				String orderSttusCode = targetVO.getOrderSttusCode();
				String setleMthdCode = targetVO.getSetleMthdCode();
				String mrtggSttusCode = targetVO.getMrtggSttusCode();

				// 2. 누적 평균 가격 목록 조회 후 평균가 상세 테이블 insert 처리
				List<OrOrderAvrgpcDtlVO> accmltAvrgpcList = commAvrgpcOrderService.selectAccmltAvrgpcList(targetVO.getCntrctOrderNo());

				estmtPurchsMapper.insertOrOrderAvrgpcDtlList(accmltAvrgpcList, orderNo);
				estmtPurchsMapper.insertOrOrderAvrgpcDtlHst(orderNo);

				// 3. 평균가 단가 및 가격 관련 데이터 계산
				// 대상 데이터 목록 : 상품 단가(평균가 단가), 주문 가격, 중량 변동금, 원 상품 단가, 공급가, 부가세, 판매가

				// 3-1. 단가 계산을 위해 orderModel 객체로 변환
				orderModel = new OrderModel();
				BeanUtils.copyProperties(targetVO, orderModel);

				// 3-2. 평균가 단가 계산을 위해 cnCntrctOrderBasVO 객체로 변환 및 orderModel에 세팅
				cnCntrctOrderBasVO = new CnCntrctOrderBasVO();
				BeanUtils.copyProperties(targetVO, cnCntrctOrderBasVO);
				
				// 24-01-26 변경사항 : 3-3의 평균가 단가 계산 시, 확정단가로 계산하기 위해 평균가 확정 단가 여부(avrgpcDcsnUntpcAt) 값을 Y로 세팅
				//						평균가 확정 단가 여부와 추가로 필요한 발생 월 데이터를 단가 확정 일자로 세팅
				cnCntrctOrderBasVO.setAvrgpcDcsnUntpcAt("Y");
				cnCntrctOrderBasVO.setOccrrncMt(cnCntrctOrderBasVO.getUntpcDcsnDe());

				orderModel.setCntrctOrderBasInfo(cnCntrctOrderBasVO);

				// 평균가 단가 계산을 위한 "평균가 거래 금액 비율" 세팅
				OrderEntrpsSetleMnVO entrpsSetleMnInfo = new OrderEntrpsSetleMnVO();
				entrpsSetleMnInfo.setAvrgpcDelngAmountRate(1);
				orderModel.setEntrpsSetleMnInfo(entrpsSetleMnInfo);

				// 3-3. 평균가 단가 계산
				long goodsUntpc = commOrderService.getAvrgpcGoodsUntpc(orderModel);

				// 평균가 단가 계산 메소드에서 확정 단가(goodsUntpc)를 가단가(avrgpcGoodsUntpc) 에 넣어주고 있어서, 원 데이터로 재설정
				orderModel.setAvrgpcGoodsUntpc(targetVO.getAvrgpcGoodsUntpc());
				
				// 24-01-26 변경사항 : 가격 데이터 계산 전, 쿠폰 관련 데이터 추가 세팅
				if(StringUtils.equals(orderModel.getCouponApplcAt(), "Y")) {
					orderModel.setCouponList(estmtPurchsMapper.selectCouponList(orderNo));
					orderModel.setCouponDplctUseLmttQyAt("N");
				}

				// 3-4. 상품 단가(평균가 단가), 주문 가격, 중량 변동금, 원 상품 단가 계산 및 세팅
				// 확정 단가, 가 중량으로 계산 (기존 live와 동일)
				commOrderService.setPriceInfo(orderModel, goodsUntpc, orderModel.getOrderWt());

				// 3-5. 공급가, 부가세, 판매가 계산 및 세팅
				// 확정 단가, 가 중량으로 계산 (기존 live와 동일)
				commOrderService.setOrderPcWithDlvrfAndCoupon(orderModel, orderModel.getOrderWt(), true);

				// 3-6. 계산 후 원본 Object로 데이터 복사
				BeanUtils.copyProperties(orderModel, targetVO);

				// 4. 중량 확정 처리되었다면, 확정 가격 데이터까지 계산
				// 대상 데이터 목록 : 총 확정 주문 가격, 총 확정 공급가

				// 확정 공급가 계산시 필요한 (예상 배송비 - 쿠폰 총 할인 금액) 계산
				// (예상 배송비 - 쿠폰 총 할인 금액) = 공급가 - 주문 가격 - 중량 변동금
				long expectDlvrfAndCpDscntAmount = orderModel.getSplpc()
						- orderModel.getOrderPc()
						- orderModel.getWtChangegld();

				if(targetVO.getTotDcsnWt() != null) {
					// 총 확정 주문 가격 계산
					long totDcsnOrderPc = (long) (targetVO.getTotDcsnWt().doubleValue() * targetVO.getGoodsUntpc());

					targetVO.setTotDcsnOrderPc(totDcsnOrderPc);	// 총 확정 주문 가격
					targetVO.setTotDcsnSplpc(totDcsnOrderPc + expectDlvrfAndCpDscntAmount);	// 총 확정 공급가

				}

				// 5. 배송 완료 처리되었다면, 정산 가격 데이터까지 계산
				// 대상 데이터 목록 : 정산 공급가, 정산 부가세, 정산 금액
				if(StringUtils.equals(orderSttusCode, "30")) {
					// 정산 공급가 = 총 확정 공급가 - 주문(발주) 시점 계산된 공급가
					long excclcSplpc = targetVO.getTotDcsnSplpc() - targetVO.getAvrgpcSplpc();
					
					// 24-01-25 변경사항 : 정산 공급가가 음수일 경우, 양수에서 반올림 처리되도록 로직 추가
					int signNumber = excclcSplpc >= 0 ? 1 : -1;

					targetVO.setExcclcSplpc(excclcSplpc);											// 정산 공급가
					targetVO.setExcclcVat(Math.round(Math.abs(excclcSplpc) * 0.1) * signNumber);	// 정산 부가세
					targetVO.setExcclcAmount(Math.round(Math.abs(excclcSplpc) * 1.1) * signNumber);	// 정산 금액
				}

				// 6. 계산된 가격 정보(데이터) 업데이트
				// 24-04-19 변경사항 : 정산 금액이 양수 (추가금액 발생) 일 시, 추가 금액(ADIT_AMOUNT)에 정산 금액을 더해서 UPDATE 하고,
				//						증거금 결제 예정 일자(WRTM_SETLE_PREARNGE_DE) 에 "추가금액에 대한 결제 기한"을 UPDATE 하도록 쿼리문 변경
				estmtPurchsMapper.updateOrderPriceInfos(targetVO);
				estmtPurchsMapper.insertOrOrderBasHst(targetVO.getOrderNo());
				
				// * 환불, 상환 처리 여부 Check, True 값이면 밑의 로직 skip (메소드 종료)
	            if(estmtPurchsMapper.selectIsRefnded(targetVO.getOrderNo())) {
	            	log.info("EstmtPurchsServiceImpl :: executeAvrgUntpcDcsn - 기존 환불 또는 상환 이력이 있으므로, 메소드를 종료합니다.");
	            	return;
	            }

				// 결제 방식 및 각종 상태 코드에 따라 환불, 부분 상환, 세금계산서 발행 처리
				// 담보보증(전자상거래보증, 여신) 일 경우
	            // 24-01-16 변경사항 : 부분 상환 또는 부분 환불 시, 실제 상환과 환불 행위를 하지 않고, 데이터만 DB에 쌓는 로직으로 변경
				if(StringUtils.equals(setleMthdCode, "20") || StringUtils.equals(setleMthdCode, "40")) {
					// 담보 상태 코드 및 주문 상태 코드에 따라 처리하는 로직이 다름
					if(StringUtils.equals(mrtggSttusCode, "50") && StringUtils.equals(orderSttusCode, "30")) {
						// 상환 완료(50), 배송 완료(30) >> 환불 및 세금계산서 처리
						
						// 24-01-16 변경사항 : 최종 정산 금액으로 환불 처리하기 위해 정산 금액 copy
						long excclcAmount = targetVO.getExcclcAmount();

						// 환불 금액 계산식 : Math.round((총 확정 공급가 - (가단가 * 확정중량 + (예상 배송비 - 쿠폰 총 할인 금액)))) * 1.1)
						double refndAmount = targetVO.getTotDcsnSplpc() 
												- (targetVO.getAvrgpcGoodsUntpc() * targetVO.getTotDcsnWt().doubleValue() + expectDlvrfAndCpDscntAmount);
						
						int signNumber = refndAmount >=0 ? 1 : -1;

						// 환불 금액 세팅
						targetVO.setExcclcAmount(Math.round(Math.abs(refndAmount) * 1.1) * signNumber);
						callEwalletAPI(targetVO, "02");	// 단가 환불 처리, 실제 금액이 환불 처리 되지 않고 OR_SETLE_BAS 테이블에 1 row 만 insert
						
						// 최종 환불 금액 세팅
						targetVO.setExcclcAmount(excclcAmount);
						callEwalletAPI(targetVO, "03");	// 중량/단가 환불 처리, 최종 환불 금액으로 환불 처리.
						
						callTaxbillAPI(orderNo);		// 세금계산서 처리

						// 24-05-03 변경사항 : 추가 결제 금액 발생 시, 해당 금액과 상환 기간을 추가로 설정
						if(targetVO.getExcclcAmount() > 0) {
							estmtPurchsMapper.updateOrMrtggBas(orderNo, excclcAmount);
						}
					} else if(StringUtils.equals(mrtggSttusCode, "50") && !StringUtils.equals(orderSttusCode, "30")) {
						// 상환 완료(50), 배송 완료 전 >> 해당 케이스 존재하지 않음
					} else if(!StringUtils.equals(mrtggSttusCode, "50") && StringUtils.equals(orderSttusCode, "30")) {
						// 상환 전, 배송 완료(30) >> 세금계산서 및 부분 상환 처리
						callTaxbillAPI(orderNo);			// 세금계산서 처리
						callMrtggAPI(orderNo);		// 부분 상환 처리
					} else if(!StringUtils.equals(mrtggSttusCode, "50") && !StringUtils.equals(orderSttusCode, "30")) {
						// 상환 전, 배송 완료 전 >> 부분 상환 처리
						callMrtggAPI(orderNo);		// 부분 상환 처리
					}
				} else {// 담보보증 이외의 결제수단 인 경우
					if(StringUtils.equals(orderSttusCode, "30")) {
						// 24-01-16 변경사항 : 최종 정산 금액으로 환불 처리하기 위해 정산 금액 copy
						long excclcAmount = targetVO.getExcclcAmount();
						
						// 환불 금액 계산식 : Math.round((총 확정 공급가 - (가단가 * 확정중량 + (예상 배송비 - 쿠폰 총 할인 금액)))) * 1.1)
						double refndAmount = targetVO.getTotDcsnSplpc() 
												- (targetVO.getAvrgpcGoodsUntpc() * targetVO.getTotDcsnWt().doubleValue() + expectDlvrfAndCpDscntAmount);
						
						int signNumber = refndAmount >=0 ? 1 : -1;

						// 단가 환불 금액 세팅
						targetVO.setExcclcAmount(Math.round(Math.abs(refndAmount) * 1.1) * signNumber);
						callEwalletAPI(targetVO, "02");	// 단가 환불 처리, 실제 금액이 환불 처리 되지 않고 OR_SETLE_BAS 테이블에 1 row 만 insert
						
						// 최종 환불 금액 세팅
						targetVO.setExcclcAmount(excclcAmount);
						callEwalletAPI(targetVO, "03");	// 중량/단가 환불 처리, 최종 환불 금액으로 환불 처리.
						
						// 배송 완료(30) >> 환불 및 세금계산서 처리
						callTaxbillAPI(orderNo);			// 세금계산서 처리
					} else {
						// 배송 완료가 안 됐으면, ewallet 단가 환불(중간 정산)을 위한 환불 금액 계산 및 세팅
						// 환불 금액 계산식 : Math.round((가중량 * 확정단가 
						//									+ 중량변동 * 확정단가
						//									+ (예상 배송비 - 쿠폰 총 할인 금액) 
						//									- 최초 발주 시 계산된 공급가) 
						//							* 1.1)
						double refndAmount = targetVO.getOrderWt() * targetVO.getGoodsUntpc()
												+ targetVO.getWtChange() * targetVO.getGoodsUntpc()
												+ expectDlvrfAndCpDscntAmount
												- targetVO.getAvrgpcSplpc();
						
						int signNumber = refndAmount >=0 ? 1 : -1;

						// 환불 금액 세팅
						targetVO.setExcclcAmount(Math.round(Math.abs(refndAmount) * 1.1) * signNumber);
						callEwalletAPI(targetVO, "02");	// 단가 환불 처리, 실제 금액이 환불 처리 되지 않고 OR_SETLE_BAS 테이블에 1 row 만 insert
					}
					
				}
				
				// SMS 발송 처리
				sendMessageToCustomer(targetVO);
			} catch (Exception e) {
				log.error("EstmtPurchsServiceImpl :: executeAvrgUntpcDcsn Error - orderNo : {} \n" + e.getMessage(), targetVO.getOrderNo());
			}
		}
	}

	/**
	 * 평균가 프라이싱 확정 처리
	 */
	@Override
	public void executeAvrgPcPricingDcsn() throws Exception {
		estmtPurchsMapper.updateCntrctMtPricingDcsn();
	}

	/**
	 * 평균가 결제 기한 경과 여부 처리
	 */
	@Override
	public void executeAvrgPcSetleTmlmtProcess() throws Exception {
		estmtPurchsMapper.updateCntrctOrderSetleTmlmt();
	}

	/**
	 * <pre>
	 * 처리내용: 환불 처리를 위한 이월렛 송금 모듈 호출
	 * </pre>
	 * @date 2023. 11. 23.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 23.			srec0053			최초작성
	 * 2024. 01. 16.			srec0053			환불 구분 코드(refndSeCode) 파라미터로 추가 및 실행 로직 분기 처리
	 * ------------------------------------------------
	 * @param avrgUntpcDcsnVO
	 * @throws Exception
	 */
	private void callEwalletAPI(AvrgUntpcDcsnVO avrgUntpcDcsnVO, String refndSeCode) throws Exception {
		// 거래금액이 음수(고객이 추가 결제)라면, 결제 테이블에 정보 입력하지 않음, 이월렛 결제 요청 하지 않음
		if(avrgUntpcDcsnVO.getExcclcAmount() >= 0 && !StringUtils.equals(refndSeCode, "02")) {
			return;
		}
		
		try {
            // 2-1. 주문_결제 기본 테이블에 환불 Data insert
            String nowDate = DateUtil.getNowDate();
            String setleNo = nowDate + "-"
                    + assignService.selectAssignValue("OR", "SETLE_NO", nowDate, avrgUntpcDcsnVO.getMberNo(), 5);

            OrSetleBasVO orSetleBasVo = new OrSetleBasVO();
            orSetleBasVo.setSetleNo(setleNo);
            orSetleBasVo.setOrderNo(avrgUntpcDcsnVO.getOrderNo());
            orSetleBasVo.setCanclExchngRtngudNo(avrgUntpcDcsnVO.getCanclExchngRtngudNo());
            orSetleBasVo.setSetleTyCode("20"); // 결제 유형 코드 - 값 20 : 환불(서린계좌 ==> 가상계좌)
            orSetleBasVo.setRefndSeCode(refndSeCode); // 환불 구분 코드 - 값 02 : 단가 환불, 03 : 중량/단가환불

            if (StringUtils.equals(refndSeCode, "02")) {	// 24-01-16 변경사항 : 단가 환불일 경우, 결제 상태 코드를 99(SKIP) 로 처리
            	orSetleBasVo.setSetleSttusCode("99"); // 결제 상태 코드 - 값 99 : SKIP
            } else {
                orSetleBasVo.setSetleSttusCode("01"); // 결제 상태 코드 - 값 01 : 요청
            }
            orSetleBasVo.setSetleSeCode("10"); // 결제 구분 코드 - 값 10 : 주문
            orSetleBasVo.setDelngAmount(Long.toString((-1) * avrgUntpcDcsnVO.getExcclcAmount())); // 정산(환불) 금액이 음수로 표기되므로,
                                                                                                // 양수 표기를 위해 -1을 곱해줌

            claimMapper.insertEwalletSetle(orSetleBasVo);
            claimMapper.insertEwalletSetleHst(orSetleBasVo);
            
            // 24-01-16 변경사항 : 단가 환불일 경우, 실제 환불 로직은 실행하지 않도록 변경
            if (StringUtils.equals(refndSeCode, "02")) {
            	log.info("단가 환불일 경우, E-Wallet 환불 처리 Skip");
            	return;
            }

            // 2-2. E-Wallet 환불 처리
            /**
             * iemSeCode : 0001(물품구매), 0002(환불), 0003(이체), 0004(기업뱅킹 환불) 0002 = 가상계좌 -> 고객계좌
             * 0003 = 서린계좌 -> 가상계좌(고객)
             *
             * 22-03-03 추가 변경 사항 거래금액이 음수(고객이 추가 결제)일 경우 E-Wallet 환불 처리 요청을 안 함
             */

            if (avrgUntpcDcsnVO.getExcclcAmount() < 0) {
                Map<String, Object> ewalletMap = new HashMap<String, Object>();
                ewalletMap.put("entrpsNo", avrgUntpcDcsnVO.getEntrpsNo());
                ewalletMap.put("iemSeCode", "0003");
                ewalletMap.put("ewalletExcclcTyCode", "04"); // E-Wallet 정산 유형 코드 04 : 중량정산
                ewalletMap.put("setleNo", setleNo);
                ewalletMap.put("delngAmount", (-1) * avrgUntpcDcsnVO.getExcclcAmount());
                Map<String, Object> ewalletResMap = httpClientHelper.postCallApi(orProperty.getEwalletOrderUrl(), ewalletMap);
                log.debug(ewalletResMap.toString()); // log

                // 이월렛 서버에서 결재테이블 정상 성공으로 업데이트 되었는지 체크, 실패일 시 세금계산서 처리를 안 함
                if (null != ewalletResMap && StringUtils.equals("200", ewalletResMap.get("resultCode").toString())
                        && ewalletResMap.get("data") != null) {
                    boolean isSuccess = false;
                    Map<String, Object> resultData = (Map<String, Object>) ewalletResMap.get("data");
                    String delngSeqNo = String.valueOf(resultData.get("delngSeqNo"));

                    for (int i = 0; i < orProperty.getEwalletTimeoutsec() * 2; i++) {
                        Thread.sleep(500);
                        // 호출 건 응답 코드 확인
                        String rspnsCode = claimMapper.selectEwalletRspnCode(delngSeqNo);
                        log.debug(">> rspnsCode : " + rspnsCode);
                        if (!StringUtils.isEmpty(rspnsCode)) {
                            // 응답 코드가 000 일때 거래 완료 -> 전문설계서 응답코드 확인
                            if (StringUtils.equals(rspnsCode, "000")) {
                                isSuccess = true;
                            }
                            log.debug(">> rspnsCode : " + rspnsCode + ", isSuccess : " + isSuccess);
                            break;
                        }
                    } // end for
                    log.debug(">> finally isSuccess : " + isSuccess);

                    if (!isSuccess) {
                        throw new Exception("이월렛 주문 실패");
                    }
                } else {
                    throw new Exception("이월렛 호출 실패");
                }
            } else {
                log.debug("거래금액 음수로 이월렛 환불처리 PASS : " + avrgUntpcDcsnVO.getExcclcAmount());
            }
        } catch (Exception e) {
            throw new Exception("이월렛 환불처리 실패 :: " + e.getMessage());
        }
    }

	/**
	 * <pre>
	 * 처리내용: 수정세금계산서 발행 처리를 위한 세금계산서 모듈 호출
	 * </pre>
	 * @date 2023. 11. 23.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 23.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 */
	private void callTaxbillAPI(String orderNo) throws Exception {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("orderNo", orderNo);
		paramMap.put("canclExchngRtngudNo", null);
		paramMap.put("jobSe", "WT");

		Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getTaxbillUrl(), paramMap);
		if (resObj != null && resObj.get("responseCode") != null
				&& StringUtils.equals(resObj.get("responseCode").toString(), "200")) {
			log.warn("세금계산서 처리 성공");
		}
	}

	/**
	 * <pre>
	 * 처리내용: 담보보증 부분 상환 처리를 위한 담보보증 모듈 호출
	 * </pre>
	 * @date 2023. 11. 23.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 23.			srec0053			최초작성
	 * 2024. 01. 16.			srec0053			상환 구분 코드(repySeCode)에 따라 실행 로직 분기되도록, 파라미터 추가
	 * ------------------------------------------------
	 * @param orderNo
	 */
	private void callMrtggAPI(String orderNo) throws Exception {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("mrtggSttusCode", "30"); // 담보 상태 코드 : 30-부분상환
		paramMap.put("repySeCode", "03"); // 상환 구분 코드 : 03-단가정산
//		paramMap.put("mberId", "BATCH");
		paramMap.put("orderNo", orderNo); // 주문 번호

		Map<String, Object> resObj = httpClientHelper.postCallApi(repyMrtggUrl, paramMap);
		if (resObj != null && resObj.get("rspnsCode") != null
				&& StringUtils.equals(resObj.get("rspnsCode").toString(), "200")) {
			log.debug("담보 상환 처리 성공");
		}
	}

	// 고객 대상 메세지 발송 메소드
    private void sendMessageToCustomer(AvrgUntpcDcsnVO avrgUntpcDcsnVO) throws Exception {
        // OR_ORDER_BAS(주문_주문 기본)-ORDRR_MOBLPHON_NO(주문자 휴대폰 번호) 복호화
        String ordrrMoblphonNo = avrgUntpcDcsnVO.getOrdrrMoblphonNo();
        if (StringUtils.isNotEmpty(ordrrMoblphonNo)) {
            try {
                log.debug("주문자 휴대폰 번호 복호화 전 ==================>" + ordrrMoblphonNo);
                ordrrMoblphonNo = CryptoUtil.decryptAES256(ordrrMoblphonNo);
                log.debug("주문자 휴대폰 번호 복호화 후 ==================>" + ordrrMoblphonNo);
                /** 주문자 휴대폰 번호 셋팅 **/
                avrgUntpcDcsnVO.setOrdrrMoblphonNo(StringUtil.formatPhone(ordrrMoblphonNo));
            } catch (Exception e) {
                log.error("EstmtPurchsServiceImpl sendMessageToCustomer ORDRR_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR "
                        + e.getMessage());
            }
        }

        // OR_DLVRG_BAS(주문_배송지 기본) - RECEPT_ENTRPS_MOBLPHON_NO(수취 업체 휴대폰 번호) 복호화
        String receptEntrpsMoblphonNo = avrgUntpcDcsnVO.getReceptEntrpsMoblphonNo();
        if (StringUtils.isNotEmpty(receptEntrpsMoblphonNo)) {
            try {
                log.debug("수취 업체 휴대폰 번호 복호화 전 ==================>" + receptEntrpsMoblphonNo);
                receptEntrpsMoblphonNo = CryptoUtil.decryptAES256(receptEntrpsMoblphonNo);
                log.debug("수취 업체 휴대폰 번호 복호화 후 ==================>" + receptEntrpsMoblphonNo);
                /** 수취 업체 휴대폰 번호 셋팅 **/
                avrgUntpcDcsnVO.setReceptEntrpsMoblphonNo(StringUtil.formatPhone(receptEntrpsMoblphonNo));
            } catch (Exception e) {
                log.error(
                        "EstmtPurchsServiceImpl sendMessageToCustomer RECEPT_ENTRPS_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR "
                                + e.getMessage());
            }
        }

        Map<String, Object> convertedMap = objectMapper.convertValue(avrgUntpcDcsnVO, Map.class);
        Map<String, String> odrMap = new LinkedHashMap<>();

        // Null값 처리 : null값일 시, 공통쪽에서 에러 발생함
        convertedMap.forEach((key, value) -> {
        	String convertedStringValue = "";

        	if(value instanceof String) {
        		convertedStringValue = value.toString();
        		if ((StringUtils.isEmpty(convertedStringValue) || StringUtils.equals("0", convertedStringValue))) {
        			convertedStringValue = "";
        		}
        	}

        	odrMap.put(key, convertedStringValue);
        });

        odrMap.put("orderNo", commAvrgpcOrderService.getOrderInfoString(convertedMap.get("orderNo").toString(), null));
        odrMap.put("goodsInfoLink", "");
        odrMap.put("documentViewDomain", "https://kztraders.com/my/papersManage/viewPapersManage");

        SMSVO smsVo = new SMSVO();

        smsVo.setPhone(avrgUntpcDcsnVO.getOrdrrMoblphonNo().replace("-", ""));
        smsVo.setMberNo(avrgUntpcDcsnVO.getMberNo());
        smsVo.setMberKndSeCode(avrgUntpcDcsnVO.getMberSeCode());
        smsVo.setCommerceNtcnAt("Y");

        odrMap.put("templateNum", "142");
        odrMap.put("Servicedomain", "https://m.kztraders.com");
        // 결제수단에 따른 결제정보 치환
        String replacedOdrSetleInfo = getOdrSetleInfoData(avrgUntpcDcsnVO);
        odrMap.put("odrSetleInfo", replacedOdrSetleInfo);

        log.info(replacedOdrSetleInfo);

        smsService.insertSMS(smsVo, odrMap);
    }

    private String getOdrSetleInfoData(AvrgUntpcDcsnVO avrgUntpcDcsnVO) throws Exception {
        String targetTmplat = "";
        String setleMthCode = avrgUntpcDcsnVO.getSetleMthdCode();

        // 문구 세팅
        String goodsUntpc = priceFormatter(avrgUntpcDcsnVO.getGoodsUntpc());
        String avrgpcGoodsUntpc = priceFormatter(avrgUntpcDcsnVO.getAvrgpcGoodsUntpc());
        String expectDlvrf = priceFormatter(avrgUntpcDcsnVO.getExpectDlvrf());
        String avrgpcSlepc = priceFormatter(avrgUntpcDcsnVO.getAvrgpcSlepc());
        String goodsUntPcString = "결제단가 : " + goodsUntpc + " (가단가 : " + avrgpcGoodsUntpc + ")";
        String setlePrearngeDe = "\r\n결제예정일 : setlePrearngeDe";	// 24-01-24 변경사항 : eWallet 환불 Case에서 결제예정일 표현이 안되도록 로직 추가
        String excclcAmountString = commAvrgpcOrderService.getExcclcInfoString(avrgUntpcDcsnVO.getOrderNo());

        /** 결제 수단에 따른 SMS 템플릿 설정 */
        /* 전자상거래보증 or 케이지크레딧 */
        if ("20".equals(setleMthCode) || "40".equals(setleMthCode)) {
        	String expectedSetleAmount = "결제예정금액 : ";
        	String nrdmpAmount = priceFormatter(estmtPurchsMapper.selectNrdmpAmount(avrgUntpcDcsnVO.getOrderNo()));
        	
        	long excclcAmount = avrgUntpcDcsnVO.getExcclcAmount() == null ? 0 : avrgUntpcDcsnVO.getExcclcAmount();
        	
        	// eWallet 환불 Case
        	if(StringUtils.equals(avrgUntpcDcsnVO.getMrtggSttusCode(), "50") && StringUtils.equals(avrgUntpcDcsnVO.getOrderSttusCode(), "30")) {
        		// 정산금액이 존재할 때, 환불금액 표시, 정산금액이 없으면 추가금액으로 인지
        		if(excclcAmount < 0) {
	        		expectedSetleAmount = "환불금액 : " + priceFormatter((-1) * avrgUntpcDcsnVO.getExcclcAmount());	// 양수로 변환
	        		setlePrearngeDe = "";	// 결제예정일 항목 표현 제거
        		} else {
        			expectedSetleAmount += priceFormatter(avrgUntpcDcsnVO.getExcclcAmount());
        		}
        	} else if (0 >= excclcAmount) {
        		expectedSetleAmount += nrdmpAmount;
        	} else {
        		expectedSetleAmount += "-";
        	}
        	
            targetTmplat += "결제 방법 : payMethod\r\n" + goodsUntPcString + "\r\n" + "배송비 : " + expectDlvrf + "\r\n"
                    + "주문금액 : " + avrgpcSlepc + "\r\n" + excclcAmountString + "\r\n" + expectedSetleAmount + setlePrearngeDe;
            log.info(targetTmplat);
        }
//        /* 증거금 */
//        else if("90".equals(setleMthCode)){
//            targetTmplat += "결제 방법 : payMethod\r\n"+ goodsUntPcString +"\r\n배송비 : expectDlvrf\r\n주문금액 : " + slepc + "\r\n"
//                    + "결제금액(1차) : frstSetleAmount\r\n결제금액(2차) : unSetleAmount\r\n" + excclcAmountString;
//        }
        /* 이월렛단독 */
        else {
            targetTmplat += "결제 방법 : payMethod\r\n" + goodsUntPcString + "\r\n" + "배송비 : " + expectDlvrf + "\r\n"
                    + "주문금액 : " + avrgpcSlepc + "\r\n" + excclcAmountString;
        }

        /** 템플릿에 결제정보 담기 */
        Field[] fields = AvrgUntpcDcsnVO.class.getDeclaredFields();
        for (Field field : fields) {
            field.setAccessible(true);

            Object tmpValue = field.get(avrgUntpcDcsnVO);
            String key = field.getName();
            String value = "";

            if (tmpValue != null) {
                value = tmpValue.toString();
            }
            targetTmplat = targetTmplat.replace(key, value); // 데이터 치환
        }

        log.info(targetTmplat);

        return targetTmplat;
    }

    private String priceFormatter(Object price) {
    	log.info("priceFormatter::");
    	DecimalFormat formatter = new DecimalFormat("###,###");

    	String result = "-";

    	try {
    		result = formatter.format(price);
		} catch (Exception e) {
			log.info(e.getMessage());
			if(price instanceof String) {
				result = price.toString();
			} else {
				result = "-";
			}
		}

    	return result;
    }
}
