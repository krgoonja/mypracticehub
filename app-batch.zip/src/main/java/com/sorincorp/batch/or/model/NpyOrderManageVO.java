package com.sorincorp.batch.or.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class NpyOrderManageVO {
	/******  JAVA VO CREATE : OR_NPY_ORDER_MANAGE_BAS(주문_미납 주문 관리 기본)                                                              ******/

	public NpyOrderManageVO(String orderNo, String npyProcessTyCode, String ordrrNm) {
		this.orderNo = orderNo;
		this.npyProcessTyCode = npyProcessTyCode;
		this.ordrrNm = ordrrNm;
	}

    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 상세 순번
    */
    private long detailSn;
    /**
     * 미납 처리 유형 코드
    */
    private String npyProcessTyCode;
    /**
     * 메시지 발송 이력 번호
    */
    private int mssageSndngHistNo;
    /**
     * 이메일 발송 이력 번호
    */
    private int emailSndngHistNo;
    /**
     * 주문자 명
    */
    private String ordrrNm;
    /**
     * 주문자 휴대폰 번호
    */
    private String ordrrMoblphonNo;
    /**
     * 주문자 이메일
    */
    private String ordrrEmail;
    /**
     * CS 담당자 ID
    */
    private String csChargerId;
    /**
     * 처리 내용
    */
    private String processCn;

    /**
     * 삭제 여부
    */
    private String deleteAt;

    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;

}
