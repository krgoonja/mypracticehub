package com.sorincorp.batch.or.mapper;

import java.util.List;

import com.sorincorp.batch.or.model.SoCredtSttusInfoVO;

public interface SoCredtSttusInfoMapper {


	/**
	 * <pre>
	 * 금주 마지막 영업일 조회
	 * </pre>
	 * @date 2022. 12. 09
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 09.		srec0076			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	int selectLastBsnDe()throws Exception;
	
	
	/**
	 * <pre>
	 * 현재 사용중인 케이지크레딧 사용현황 정보
	 * </pre>
	 * @date 2022. 12. 09
	 * @author srec0076
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 09.		srec0076			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<SoCredtSttusInfoVO> selectSoCredtSttuInfoList()throws Exception;
	
}
