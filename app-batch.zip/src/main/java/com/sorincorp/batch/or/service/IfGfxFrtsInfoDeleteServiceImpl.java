package com.sorincorp.batch.or.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.or.mapper.IfGfxFrtsInfoDeleteMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * IfGfxFrtsInfoDeleteServiceImpl.java
 * @version
 * @since 2023. 2. 17.
 * @author srec0066
 */
@Slf4j
@Service
public class IfGfxFrtsInfoDeleteServiceImpl implements IfGfxFrtsInfoDeleteService {

	@Autowired
	private IfGfxFrtsInfoDeleteMapper ifGfxFrtsInfoDeleteMapper;

	/**
	 * GFX_RFS_RES          (거래용 환율 RFS I/F)
	 * IF_FTRS_ORDER_REQUST (인터페이스_선물 주문 요청_ POLL/POOK)
	 * IF_FTRS_ORDER_RSPNS  (인터페이스_선물 주문 응답_ POLL/POOK)
	 *
	 * 위 3개 테이블의 3개월 이전 데이터를 삭제하는 프로시저를 실행한다.
	 */
	@Override
	public void deleteIfGfxFrtsInfo() throws Exception {
		log.info("IfGfxFrtsInfoDeleteServiceImpl:deleteIfGfxFrtsInfo (IF[거래용 환율,선물 주문 요청/응답 데이터 삭제 실행) Start");

		ifGfxFrtsInfoDeleteMapper.deleteIfGfxFrtsInfo();

		log.info("IfGfxFrtsInfoDeleteServiceImpl:deleteIfGfxFrtsInfo (IF[거래용 환율,선물 주문 요청/응답 데이터 삭제 실행) End");
	}

}
