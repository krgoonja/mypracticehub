package com.sorincorp.batch.or.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.sorincorp.batch.or.mapper.AvrgPcEstmtCntrctMapper;
import com.sorincorp.batch.or.model.AvrgPcEstmtCntrctVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AvrgPcEstmtCntrctServiceImpl implements AvrgPcEstmtCntrctService {

	@Autowired
	private AvrgPcEstmtCntrctMapper avrgPcEstmtCntrctMapper;

	@Autowired
	private SMSService smsService;

	@Autowired
	private CommonCodeService commonCodeService;

	/**
	 *	견적 기한/계약 승인 기한 만료 D-1일에 고객에게 알림톡발송
	 */
	@Override
	public void selectEstmtTmlmtEndDtList() throws Exception {
		// 견적확정만료&계약승인만료 임박 대상 리스트 조회
		List<AvrgPcEstmtCntrctVO> list = avrgPcEstmtCntrctMapper.selectEstmtTmlmtEndDtList(new AvrgPcEstmtCntrctVO());
		// 견적확정만료 임박건 수
		int estmtSttus30 = 0;
		// 계약승인만료 임박건 수
		int estmtSttus40 = 0;
		// 예약발송일시 오전 9시
		String smsReqDate = DateUtil.getNowDateTime("yyyy-MM-dd 09:00:00");
		// 케이지트레이딩고객센터 전화번호
		String csTel = commonCodeService.getCodeValueRetVo("SORIN_SETUP_CODE", "CS_TEL").getCodeDcone();

		if (list != null) {

			AvrgPcEstmtCntrctVO avrgPcEstmtCntrctVO = null;
			String estmtSttusCode = "";
			String moblphonNo = "";

			Map<String, String> msgMap = null;
			SMSVO smsVO = null;

			for (int i = 0; i < list.size(); i++) {
				avrgPcEstmtCntrctVO = list.get(i);
				// 견적승인상태
				estmtSttusCode = avrgPcEstmtCntrctVO.getEstmtSttusCode();
				// 휴대폰번호 복호화
				moblphonNo = CryptoUtil.decryptAES256(avrgPcEstmtCntrctVO.getOrdrrMoblphonNo());

				msgMap = new HashMap<>();
				smsVO = new SMSVO();

				smsVO.setPhone(moblphonNo); // 받는사람 번호(복호화)
				smsVO.setMberNo(avrgPcEstmtCntrctVO.getMberNo());
				smsVO.setReqDate(smsReqDate); // 발송희망시간 AM 9

				if ("30".equals(estmtSttusCode)) {
					// 견적확정기한만료
					estmtSttus30++;

					msgMap.put("templateNum", "134"); 									// 메시지 템플릿 번호
					msgMap.put("estmtNo", avrgPcEstmtCntrctVO.getEstmtNo()); 			// 견적번호
					msgMap.put("estmtTmlmtEndDt", avrgPcEstmtCntrctVO.getTmlmtEndDt()); // 견적 기한 만료 일시
					msgMap.put("csTel", csTel); 										// 고객센터 전화번호
					// 고객에게만 발송
					msgMap.put("excpSndngOptnAt", "N");

					// log.info("견적확정기한 만료 알림톡 발송 =============> " + msgMap.toString());
				} else if ("40".equals(estmtSttusCode)) {
					// 계약승인기한만료
					estmtSttus40++;

					msgMap.put("templateNum", "137"); 									 // 메시지 템플릿 번호
					msgMap.put("estmtNo", avrgPcEstmtCntrctVO.getEstmtNo()); 			 // 견적번호
					msgMap.put("cntrctNo", avrgPcEstmtCntrctVO.getCntrctNo()); 			 // 계약번호
					msgMap.put("cntrctConfmEndDt", avrgPcEstmtCntrctVO.getTmlmtEndDt()); // 계약 승인 만료 일시
					msgMap.put("csTel", csTel); 										 // 고객센터 전화번호
					// 고객에게만 발송
					msgMap.put("excpSndngOptnAt", "N");
					// log.info("견적승인기한 만료 알림톡 발송 =============> " + msgMap.toString());
				}

				// 기한만료 메세지 전송
				smsService.insertSMS(smsVO, msgMap);
			}
		}

		log.info("견적확정기한만료 건수 : " + estmtSttus30);
		log.info("계약승인기한만료 건수 : " + estmtSttus40);
	}

	/**
	 *	견적 기한/계약 승인 기한 만료일시 견적 상태 코드 업데이트
	 */
	@Override
	public void executeEstmtCntrctTmlmtEnd() throws Exception {
		AvrgPcEstmtCntrctVO param = new AvrgPcEstmtCntrctVO();
		param.setSeCode("end");
		List<AvrgPcEstmtCntrctVO> targetList = avrgPcEstmtCntrctMapper.selectEstmtTmlmtEndDtList(param);

		if (!CollectionUtils.isEmpty(targetList)) {
			for (AvrgPcEstmtCntrctVO target : targetList) {
				// 견적 상태 코드 조회
				String estmtSttusCode = target.getEstmtSttusCode();

				if("30".equals(estmtSttusCode)) { // 견적 확정 대기 건

					// 새로운 견적 상태 코드 세팅: [견적 기한 경과]
					target.setNewEstmtSttusCode("60");
				} else if("40".equals(estmtSttusCode)) { // 계약 승인 대기 건

					// 새로운 견적 상태 코드 세팅: [계약 승인 기한 경과]
					target.setNewEstmtSttusCode("70");
				}
				log.info("executeEstmtCntrctTmlmtEnd [Target-" + target.toString() + "]");

				try {
					int result = avrgPcEstmtCntrctMapper.updateEstmtCntrctTmlmtEndSttusCode(target);
					if(result > 0) {
						avrgPcEstmtCntrctMapper.insertCnEstmtBasHst(target);
					}
				} catch(Exception e) {
					log.info("executeEstmtCntrctTmlmtEnd [ERROR-" +  target.getEstmtNo() + "] " + e.getMessage());
					continue;
				}
			}
		}
	}
}
