package com.sorincorp.batch.or.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.or.service.AvrgPcEstmtCntrctService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AvrgPcEstmtCntrctTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	AvrgPcEstmtCntrctService avrgPcEstmtCntrctService;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		// TODO Auto-generated method stub
		log.debug("MbEntrpsGradEvlTasklet beforeStep method");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		// TODO Auto-generated method stub
		log.debug("MbEntrpsGradEvlTasklet execute method");
		avrgPcEstmtCntrctService.selectEstmtTmlmtEndDtList();
		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		// TODO Auto-generated method stub
		log.debug("MbEntrpsGradEvlTasklet afterStep method");
		return ExitStatus.COMPLETED;
	}
}
