package com.sorincorp.batch.or.model;

import lombok.Data;

/**
 * PrvsnlPcChangegldInfoVO.java
 * 가단가 가격 변동금 정보 VO 객체
 * 
 * @version
 * @since 2024. 10. 31.
 * @author srec0049
 */
@Data
public class PrvsnlPcChangegldInfoVO {

	/**
	 * 주문 번호
	 */
	private String orderNo;
	
	/**
	 * 주문 일자
	 */
	private String orderDe;
	
	/**
	 * 판매 방식 코드
	 */
	private String selMthdCode;
	
	/**
	 * 결제 방식 코드
	 */
	private String setleMthdCode;
	
	/**
	 * 금속 코드
	 */
	private String metalCode;
	
	/**
	 * 아이템 순번
	 */
	private Integer itmSn;
	
	/**
	 * 권역 대분류 코드
	 */
	private String dstrctLclsfCode;
	
	/**
	 * 브랜드 그룹 코드
	 */
	private String brandGroupCode;
	
	/**
	 * 브랜드 코드
	 */
	private String brandCode;
	
	/**
	 * 총 실제 주문 중량
	 */
	private int totRealOrderWt;
	
	/**
	 * 단가 확정 최대 기간 코드
	 */
	private String untpcDcsnMxmmPdCode;
	
	/**
	 * 단가 확정 최대 일자
	 */
	private String untpcDcsnMxmmDe;
	
	/**
	 * 청산 대상 제외 여부
	 */
	private String lqdTrgetExclAt;
	
	/**
	 * 발생 일자 (YYYYMMDD)
	 */
	private String occrrncDe;
	
	/**
	 * 평균가 상품 단가
	 */
	private long avrgpcGoodsUntpc;
	
	/**
	 * 유지 변동 금액
	 */
	private long mntncChangeAmount;
	
	/**
	 * 최초 가격 변동 금액
	 */
	private long frstPcChangeAmount;
}
