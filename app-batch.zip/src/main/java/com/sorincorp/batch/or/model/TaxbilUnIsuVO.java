package com.sorincorp.batch.or.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 *  ERP생성 오류 건 관리 (세금계산서) TaxbilUnIsuVO.java
 * @version
 * @since 2023. 12. 18.
 * @author sein
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class TaxbilUnIsuVO extends CommonVO {

	private static final long serialVersionUID = 6882956122304862133L;

	/******  JAVA VO CREATE : OR_ORDER_BAS(주문_주문 기본),VW_ERP_ORDER_BATCHNO(SC_STS)  ******/
	/**
     * 순번
    */
    private String rownum;

    /**
     * 업체 번호
    */
    private String entrpsNo;

    /**
     * 주문 번호
    */
    private String orderNo;

    /**
     * CSU_CWS_CODE
    */
    private String CsuCwsCode;

    /**
     * 2차 세금계산서 ERP 존재 판단 유,무
    */
    private String cnt;

    /**
     * 탬플릿 번호
     * */
    private int templateNum;

}
