package com.sorincorp.batch.or.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.batch.or.comm.TaxBillRecptnConstants;
import com.sorincorp.batch.or.comm.TaxBillRecptnResponseEntity;
import com.sorincorp.batch.or.service.TaxBillRecptnService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 세금계산서 발행완료 btobi 수신 Controller
 * @version
 * @since 2021. 9. 2.
 * @author srec0054
 */
@Slf4j
@RestController
@RequestMapping("/batch/or")
@Api( value = "세금계산서 발행완료 btobi 수신 Batch Controller")
@ComponentScan("com.sorincorp.comm.*")
public class TaxBillRecptnController {
	
	@Autowired
	private TaxBillRecptnService taxBillRecptnService;
	
	@PostMapping("/saveTaxBillRecptn")
	@ApiOperation(value = "세금계산서 발행완료 btobi 수신 Batch", notes = "세금계산서 발행완료 btobi 수신 Batch")
	public TaxBillRecptnResponseEntity saveTaxBillRecptn() throws Exception{
		log.debug("TaxBillRecptnController:saveTaxBillRecptn (세금계산서 발행완료 btobi 수신 Batch) Start");
		try {
			
			taxBillRecptnService.saveTaxBillRecptn();
			
		} catch (Exception e) {
			
			throw new Exception("TaxBillRecptnController:saveTaxBillRecptn = " + e.getMessage());
			
		}
		log.debug("TaxBillRecptnController:saveTaxBillRecptn (세금계산서 발행완료 btobi 수신 Batch) End");
		return new TaxBillRecptnResponseEntity(TaxBillRecptnConstants.SUCCESS_CODE, TaxBillRecptnConstants.SUCCESS_MSG, null);
	}//end saveTaxBillRecptn()

}//end class()
