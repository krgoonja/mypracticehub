package com.sorincorp.batch.or.model;

import lombok.Data;

/**
 * EstmtPurchsVO.java
 * @version
 * @since 2023. 11. 8.
 * @author srec0070
 * - 견적 구매 관련 DATA VO
 */
@Data
public class EstmtPurchsVO {
	/**
	 * 계약 번호
	 */
	String cntrctNo;
	/**
	 * 계약 년월
	 */
	String cntrctYm;
	/**
	 * 계약 년월 순번
	 */
	String cntrctYmSn;
	/**
	 * 계약월(평균가 적용월)
	 */
	String occrrncMt;
	/**
	 * 금속 코드
	 */
	String metalCode;
	/**
	 * 아이템 순번
	 */
	String itmSn;
	/**
	 * 권역 대분류 코드
	 */
	String dstrctLclsfCode;
	/**
	 * 브랜드 그룹 코드
	 */
	String brandGroupCode;
	/**
	 * 브랜드 코드
	 */
	String brandCode;
	/**
	 * LEM CSP 확정 월
	 */
	String lmeCspDcsnMt;
	/**
	 * 평균 LME CSP
	 */
	String avrgLmeCsp;
	/**
	 * 평균가 스프레드
	 */
	String avrgpcSpread;
	/**
	 * 평균가 선물 요청 번호
	 */
	String avrgpcFtrsRequstNo;
	/**
	 * BL 번호
	 */
	String blNo;
	/**
	 * 체결 선물사 구분 코드
	 */
	String cnclsFtrsprofsSeCode;
	/**
	 * 선물 요청 주문 번호
	 */
	String ftrsRequstOrderNo;
	/**
	 * 선물 요청 상세 순번
	 */
	String ftrsRequstDetailSn;
	/**
	 * 청산 실행 ID
	 */
	String lqdExecutId;
	/*
	 * 요청 선물사 구분 코드
	 */
	String requstFtrsCmpnySeCode;
}
