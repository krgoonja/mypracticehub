package com.sorincorp.batch.or.model;

import lombok.Data;

@Data
public class OrderDtlVO {
	/******  JAVA VO CREATE : OR_ORDER_DTL(주문_주문 상세)   ******/
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 주문 순번
    */
    private String orderSn;
    /**
     * BL 번호
    */
    private String blNo;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 아이템 명
    */
    private String itmNm;
    /**
     * 창고 코드
    */
    private String wrhousCode;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 상품 명
    */
    private String goodsNm;
    /**
     * 고객 주문 중량
    */
    private int cstmrOrderWt;
    /**
     * 실제 주문 중량
    */
    private int realOrderWt;
    /**
     * 번들 수량
    */
    private int bundleQy;
    /**
     * 확정 중량
    */
    private java.math.BigDecimal dcsnWt;
    /**
     * 확정 주문 가격
    */
    private long dcsnOrderPc;
    /**
     * 확정 일시
    */
    private java.sql.Timestamp dcsnDt;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
    /**
     * 보관료
    */
    private long chcy;

    /** 아이템 코드 */
    private String itmCode;
    /** 클레임 중량 */
    private java.math.BigDecimal canclExchngRtngudWt; //CANCL_EXCHNG_RTNGUD_WT
    /** 클레임 번들 수량 */
    private int canclExchngRtngudBundleQy; //CANCL_EXCHNG_RTNGUD_BUNDLE_QY
    /** 클레임 확정 중량 */
    private java.math.BigDecimal canclExchngRtngudDcsnWt; //CANCL_EXCHNG_RTNGUD_DCSN_WT
    /** 상품기본 테이블 NET 평균 중량 */
    private java.math.BigDecimal netAvrgWt;
    /** BL 이력 이벤트 유형 코드 */
    private String blHistEventTyCode;
    /** 재고 변경 플래그 */
    private boolean isInvntryUdt;

    /** 삼성선물상세 거부사유 */
    private String rejectResn;
}
