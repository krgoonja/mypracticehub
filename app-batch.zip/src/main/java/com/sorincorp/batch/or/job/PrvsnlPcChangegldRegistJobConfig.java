package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * PrvsnlPcChangegldRegistJobConfig.java
 * 가단가 가격 변동금 등록 배치(Tasklet 방식) 구성
 * 
 * @version
 * @since 2024. 10. 28.
 * @author srec0049
 */
@Configuration
@EnableBatchProcessing
public class PrvsnlPcChangegldRegistJobConfig {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private PrvsnlPcChangegldRegistTasklet prvsnlPcChangegldRegistTasklet;
	
	
	@Bean
	public Job prvsnlPcChangegldRegistJob() {
		return jobBuilderFactory.get("prvsnlPcChangegldRegistJob")
				.start(prvsnlPcChangegldRegistStep())
				.build();
	}

	@Bean
	@JobScope
	public Step prvsnlPcChangegldRegistStep() {
		return stepBuilderFactory.get("prvsnlPcChangegldRegistStep")
				.tasklet(prvsnlPcChangegldRegistTasklet)
				.build();
	}
}
