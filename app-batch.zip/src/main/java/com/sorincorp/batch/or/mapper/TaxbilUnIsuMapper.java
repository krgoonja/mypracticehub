package com.sorincorp.batch.or.mapper;

import java.util.List;

import com.sorincorp.batch.or.model.TaxbilUnIsuVO;

public interface TaxbilUnIsuMapper {


	/**
	 * <pre>
	 * 주말, 공휴일 확인
	 * </pre>
	 * @date 2023. 12. 18
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 12. 18		  	 sein				     최초작성
	 * ------------------------------------------------
	 * @return
	 */
	int selectLastBsnDe()throws Exception;
	
	
	/**
	 * <pre>
	 * ERP 미 발행  메일 발송(1차 세금계산서)
	 * </pre>
	 * @date 2023. 12. 18
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 12. 18		  	 sein				     최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<TaxbilUnIsuVO> selectOneTaxbilUnIsuList()throws Exception;
	
	/**
	 * <pre>
	 * ERP 미 발행  메일 발송(2차 세금계산서)
	 * </pre>
	 * @date 2023. 12. 18
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 12. 18		  	 sein				     최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<TaxbilUnIsuVO> selectTwoTaxbilUnIsuList()throws Exception;
	
}
