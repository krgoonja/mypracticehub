package com.sorincorp.batch.or.service;

/**
 * 매일 9시 여신 결제 예정 및 미납/연체 내역 메일 발송 batch Service(휴일,공휴일 제외)
 * NpyArrrgInfoService.java
 * @version
 * @since 2023. 01. 20.
 * @author srec0076
 */
public interface NpyArrrgInfoService {
	
	/**
	 * 
	 * <pre>
	 * 여신 결제 예정 및 미납/연체 내역 메일 발송
	 * </pre>
	 * @date 2023. 01. 20.
	 * @author srec0076
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 01. 20.	  srec0076			    최초작성
	 * ------------------------------------------------
	 */
	void sendNpyArrrgInfo() throws Exception;
	
}