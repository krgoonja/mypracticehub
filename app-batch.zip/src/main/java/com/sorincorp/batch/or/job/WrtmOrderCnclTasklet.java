package com.sorincorp.batch.or.job;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.MDC;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.or.comm.WrtmOrderCnclPool;
import com.sorincorp.batch.or.model.BatchOrderModel;
import com.sorincorp.batch.or.service.WrtmMsgService;
import com.sorincorp.batch.or.service.WrtmOrderCnclService;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component(value = "WrtmOrderCnclTasklet")
public class WrtmOrderCnclTasklet implements Tasklet, StepExecutionListener{

	/** 사이트 운영 설정 서비스 */
	@Autowired
	BsnInfoService bsnInfoService;

	@Autowired
	WrtmOrderCnclService wrtmCnclService;

	@Autowired
	WrtmMsgService wrtmMsgService;

	@Autowired
	WrtmOrderCnclPool taskPool;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		taskPool.initialize();
		log.debug("WrtmOrderCnclTasklet::beforeStep");
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("WrtmOrderCnclTasklet::afterStep");
		try {
			ThreadPoolTaskExecutor executor = taskPool.getExecutor();
			while(true) {

				if(executor==null) break;

				int activeCnt = executor.getActiveCount();

				log.warn("Active Thread Count {} 건", activeCnt);

				if(activeCnt == 0) {
					break;
				}

				Thread.sleep(1000L);
			}

			executor.shutdown();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.warn("WrtmOrderCnclTasklet::execute Start");
		JobParameters jobParameters = chunkContext.getStepContext().getStepExecution().getJobParameters();
		Map<String, JobParameter> jobParamMap = jobParameters.getParameters();
		JobParameter param = jobParamMap.get("param01");
		String wrtmCanclOrderNo = null;
		if(null != param) {
			wrtmCanclOrderNo = param.toString();
		}

		log.warn("WrtmOrderCnclTasklet::executeOrderNo - {}", wrtmCanclOrderNo);

		/* 케이지트레이딩 영업관리
		   1. 영업관리(LIVE, 고정가 정보)
		   2. 영업관리 요일별 휴일 정보
		   3. LME 휴일 정보
		   4. 이벤트 휴일관리
		   5. 휴무시간 관리
		   에서 나오는 휴일 정보를 모두 조회
		*/

//      케이지트레이딩휴무일 체크는 무의미 해서 주석 처리함.
//		String nowDate = DateUtil.getNowDate(); // 현재날짜
//		RestdeVO bsnInfovo = bsnInfoService.getRestdeInfo(nowDate);
//		if( !StringUtils.equals("Y", bsnInfovo.getDeAcctoRestdeAt()) ) {

			/** 다음달 만기일 조회.
			 *  PO테이불의 만기일이 현재일 보다 이전일 경우 다믕달 만기일 지정을 한다.
			 */
			Map<String, String> nextExprtnDeMap = wrtmCnclService.selectBeforeProcInfo();
			log.warn("배치 작업전 사전처리 정보 조회: {}", nextExprtnDeMap);

			String toDay 			= nextExprtnDeMap.get("TODAY"); 				//다음달 선물 만기일
			String tmpCurFtrsExprtnDe 	= nextExprtnDeMap.get("CUR_FTRS_EXPRTN_DE"); 	//이번달 선물 만기일
			String tmpNextFtrsExprtnDe = nextExprtnDeMap.get("NEXT_FTRS_EXPRTN_DE"); 	//다음달 선물 만기일
			String tmpCurFshgExprtnDe 	= nextExprtnDeMap.get("CUR_FSHG_EXPRTN_DE"); 	//이번달 선물환 만기일
			String tmpNextFshgExprtnDe = nextExprtnDeMap.get("NEXT_FSHG_EXPRTN_DE"); 	//다음달 선물환 만기일

			/*
			 * 증거금 취소 주문 만기일 적재시
			 * 현재일이 현재월 만기일보다 작거나 같으면 이번달 만기일 적재
			 * 현재일이 현재월 만기일보다 크면 다음달 만기일을 적재한다.
			 */
			if(Integer.parseInt(toDay) <= Integer.parseInt(tmpCurFtrsExprtnDe)) {
				tmpNextFtrsExprtnDe = tmpCurFtrsExprtnDe;
			}

			if(Integer.parseInt(toDay) <= Integer.parseInt(tmpCurFshgExprtnDe)) {
				tmpNextFshgExprtnDe = tmpCurFshgExprtnDe;
			}

			final String nextFtrsExprtnDe  = tmpNextFtrsExprtnDe;							//다음달 선물 만기일
			final String nextFshgExprtnDe  = tmpNextFshgExprtnDe;                           //다음달 선물환 만기일
			final String csTelNo           = nextExprtnDeMap.get("CS_TEL_NO");           	//고객센터 전화번호
			List<BatchOrderModel> orderList = wrtmCnclService.selectWrtmArrrgOrderList(wrtmCanclOrderNo);
			log.warn("증거금 취소 주문 건: {} 건", orderList.size());

			for(BatchOrderModel batchOrderModel : orderList) {
				Runnable workRun = () -> {
					try {
						final UUID uuid = UUID.randomUUID();
						MDC.put("request_id", uuid.toString());

						batchOrderModel.setNextFtrsExprtnDe(nextFtrsExprtnDe);
						batchOrderModel.setNextFshgExprtnDe(nextFshgExprtnDe);
						batchOrderModel.setCsTelNo(csTelNo);

						wrtmCnclService.doWrtmOrderCncl(batchOrderModel);

						MDC.clear();
					} catch (Exception e) {
						log.error(ExceptionUtils.getStackTrace(e));
					}
				};
				taskPool.getExecutor().execute(workRun);

				Thread.sleep(1000L);
			}
//		}else {
//			log.warn("오늘 {}일은 케이지트레이딩 휴무일입니다.", nowDate);
//		}
		log.warn("WrtmOrderCnclTasklet::execute End");
		return RepeatStatus.FINISHED;
	}

}
