package com.sorincorp.batch.or.mapper;

/**
 * IfGfxFrtsInfoDeleteMapper.java
 * @version
 * @since 2023. 2. 17.
 * @author srec0066
 */
public interface IfGfxFrtsInfoDeleteMapper {

	/**
	 * <pre>
	 * 처리내용:
	 * GFX_RFS_RES          (거래용 환율 RFS I/F)
	 * IF_FTRS_ORDER_REQUST (인터페이스_선물 주문 요청_ POLL/POOK)
	 * IF_FTRS_ORDER_RSPNS  (인터페이스_선물 주문 응답_ POLL/POOK)
	 *
	 * 위 3개 테이블의 3개월 이전 데이터를 삭제하는 프로시저를 실행한다.
	 * </pre>
	 * @date 2023. 2. 17.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 2. 17.			srec0066			최초작성
	 * ------------------------------------------------
	 */
	void deleteIfGfxFrtsInfo();

}
