package com.sorincorp.batch.or.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.batch.or.comm.TaxBillRecptnConstants;
import com.sorincorp.batch.or.mapper.TaxBillRecptnMapper;
import com.sorincorp.batch.or.model.TaxBillRecptnVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;
import com.sorincorp.comm.message.mapper.SMSMapper;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.service.CommAvrgpcOrderServiceImpl;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

/**
 *
 * 세금계산서 발행완료 btobi 수신 Batch ServiceImpl.java
 * @version
 * @since 2021. 9. 2.
 * @author srec0054
 */
@Slf4j
@Service
public class TaxBillRecptnServiceImpl implements TaxBillRecptnService {

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private TaxBillRecptnMapper taxBillRecptnMapper;

	@Autowired
	private SMSMapper smsMapper;

	@Autowired
	private SMSService smsService;
	
	@Autowired
	private CommAvrgpcOrderServiceImpl commAvrgpcOrderServiceImpl;

	@Value("${taxBillRecptn.url.server}")
	private String taxBillRecptnUrl;

//	@Value("${taxBillRecptn.server.schema.http}")
//	private String httpSchema;
//
//	@Value("${taxBillRecptn.server.api.host}")
//	private String apiHost;
//
//	@Value("${taxBillRecptn.server.api.port}")
//	private Integer apiPort;

	/**
	 * 세금계산서 발행완료 btobi 수신
	 */
	@Transactional(rollbackFor = Exception.class)
	@Override
	public void saveTaxBillRecptn() throws Exception {
		log.debug("TaxBillRecptnServiceImpl:saveTaxBillRecptn (세금계산서 발행완료 btobi 수신) Start");

		//인터페이스 수신 전문 등록 (IF_LOG)
		BtoBInrecfcLogVO btbLogVo = httpClientHelper.insertBtbLog(TaxBillRecptnConstants.TAX_BILL_IF, null);

		try {

			//세금계산서 발행완료 목록 조회
			List<TaxBillRecptnVO> taxBillRecptnList = taxBillRecptnMapper.getListTaxBillRecptn();
			log.debug("taxBillRecptnList.size() = " + taxBillRecptnList.size());

			if(taxBillRecptnList.size() > 0) {

				for(TaxBillRecptnVO paramVo : taxBillRecptnList) {

					paramVo = intrfcProcessSttusCodeSubs(paramVo);	//인터페이스 처리 상태 코드 치환
					paramVo = processSttusCodeSubs(paramVo);		//EC 처리 상태 코드 치환

					String docSttusCode		 		= paramVo.getDocSttusCode();			//문서 상태 코드 (B2B_STATUS)
					String recptnMssageCode 		= paramVo.getRecptnMssageCode();		//수신 메시지 코드 (B2B_MSGCODE)
					String recptnResultCode			= paramVo.getRecptnResultCode();		//수신 결과 코드 (B2B_RESULTCODE)
					String intrfcProcessSttusCode 	= paramVo.getIntrfcProcessSttusCode();	//인터페이스 처리 상태 코드
					String processSttusCode 		= paramVo.getProcessSttusCode();		//EC 처리 상태 코드
					log.debug("BTOBI 수신 항목====================================================");
					log.debug("[ 문서 상태 코드 (B2B_STATUS) = " + docSttusCode + " ]");
					log.debug("[ 수신 메시지 코드 (B2B_MSGCODE)) = " + recptnMssageCode + " ]");
					log.debug("[ 수신 결과 코드 (B2B_RESULTCODE) = " + recptnResultCode + " ]");
					log.debug("================================================================");

					log.debug("EC 업데이트 항목 ===================================================");
					log.debug("[ 인터페이스 처리 상태 코드 = " + intrfcProcessSttusCode + " ]");
					log.debug("[ EC 처리 상태 코드 = " + processSttusCode + " ]");
					log.debug("================================================================");

					paramVo.setFrstRegisterId(TaxBillRecptnConstants.TAX_BILL_IF);
					paramVo.setLastChangerId(TaxBillRecptnConstants.TAX_BILL_IF);

					//세금계산서 발행완료 btobi 수신 결과 업데이트
					taxBillRecptnMapper.updateOrTaxBillBas(paramVo);	//OR_TAX_BILL_BAS (주문_세금계산서_기본)

					String taxBillClCode = taxBillRecptnMapper.selectOrTaxBillBas(paramVo);		//OR_TAX_BILL_BAS (주문_세금계산서_기본)
					// 테스트시 
					//processSttusCode = "03";// 나중 지워 !!
					//taxBillClCode = "02";
					//조건 : PROCESS_STTUS_CODE = 03 발행완료 , TAX_BILL_CL_CODE = 02 수정세금계산서
					if(processSttusCode.equals("03") && taxBillClCode.equals("02")){
						log.debug("2차 세금계산서발송 ===================================================");
						callSms(paramVo, "62", "2차 세금계산서발송 SMS 처리실패");
					}

					taxBillRecptnMapper.updateifOrTaxBillBas(paramVo);		//IF_OR_TAX_BILL_BAS (인터페이스_세금계산서_기본)

					if(TaxBillRecptnConstants.INTRFC_STTUS_CODE_S.equals(intrfcProcessSttusCode)
							|| TaxBillRecptnConstants.INTRFC_STTUS_CODE_E.equals(intrfcProcessSttusCode)
							|| TaxBillRecptnConstants.INTRFC_STTUS_CODE_F.equals(intrfcProcessSttusCode)) {
						taxBillRecptnMapper.updateOrTaxBillBasHst(paramVo);		//주문_세금계산서_기본 이력	(OR_TAX_BILL_BAS_HST)
					}//end if()

				}//end for()

				//ERP 전송 프로세스
				erpTrnsmisTaxBillProcess();

			} else {
				log.debug("세금계산서 발행완료 목록 조회 taxBillRecptnList.size() IS NULL");
			}//end if()

			btbLogVo.setIntrfcRspnsCode(TaxBillRecptnConstants.SUCCESS_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(TaxBillRecptnConstants.SUCCESS_MSG);

		} catch (Exception e) {

			btbLogVo.setIntrfcRspnsCode(TaxBillRecptnConstants.ERROR_RESULT_CODE);
			btbLogVo.setIntrfcRspnsCn(e.getMessage());
			log.error("TaxBillRecptnServiceImpl::saveTaxBillRecptn exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		} finally {

			//인터페이스 수신 전문 등록 (IF_LOG)
			httpClientHelper.updateBtbLog(btbLogVo);

		}

		log.debug("TaxBillRecptnServiceImpl:saveTaxBillRecptn (세금계산서 발행완료 btobi 수신) End");
	}//end saveTaxBillRecptn()

	/**
	 * 템플릿에 따라 SMS 전송 처리. (내부 사용자 SMS)
	 * TaxBillRecptnVO billVo
	 */
	private void callSms(TaxBillRecptnVO billVo, String templateNum, String addStr) {
		log.warn("[TaxBillRecptnServiceImpl][수정세금계산서 발행완료][procSms] IN");

		try {
			SMSVO smsVO = new SMSVO();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
		//	smsVO.setCommerceNtcnAt("N"); // 커머스 알림 여부
			String cryalTlphonNo = billVo.getTlphonNo(); // 휴대 전화 번호, 세금계산서 발행자 추가 발행자 휴대폰 번호
			if(StringUtils.isNotEmpty(cryalTlphonNo) && !cryalTlphonNo.equals("null")) {
				try {
					log.debug("휴대전화 번호 복호화 전 ==================>" + cryalTlphonNo);
					cryalTlphonNo = CryptoUtil.decryptAES256(cryalTlphonNo);
					log.debug("휴대전화 번호 복호화 후 ==================>" + cryalTlphonNo);
					/** 휴대전화 번호 셋팅 **/
					smsVO.setPhone(cryalTlphonNo); // 수신 핸드폰 번호
					smsVO.setMberNo(billVo.getMberNo()); // 회원번호
				} catch(Exception e) {
					log.error("TaxBillRecptnServiceImpl callSms CRYAL_TLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
			}

			Map<String, String> smsMap = null;

			// 23-12-07 변경사항 : 평균가 판매방식 추가에 따른 주문번호 + 평균가 계약번호 포멧 적용
			//						평균가 주문이 아닐 경우, 기존 주문번호만 노출됨 
			switch (templateNum) {
				case "62":
					smsMap = new HashMap<String, String>();
					smsMap.put("supledMtltyNm", billVo.getSupledMtltyNm()); // 공급자 상호 명
					smsMap.put("orderNo", commAvrgpcOrderServiceImpl.getOrderInfoString(billVo.getOrderNo(), null)); // 주문번호
					smsMap.put("elctrnTaxBillIssuDt", DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss")); // 발행일시
					smsMap.put("totAmount", String.format("%,d", Math.round(Float.parseFloat(billVo.getTotAmount())))); // 총 금액
					smsMap.put("Servicedomain", "https://www.kztraders.com"); // 사이트바로가기 URL
					smsMap.put("returnMsg", addStr); // returnMsg : 2차 세금계산서발송 SMS 처리실패
					break;
			}

			smsMap.put("templateNum", templateNum);

			smsService.insertSMS(smsVO, smsMap);
		} catch (Exception e) {
			log.error("[TaxBillRecptnServiceImpl][callSms] " + ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 *
	 * <pre>
	 * 인터페이스 처리 상태 코드 치환
	 * </pre>
	 * @date 2021. 9. 3.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 3.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	InvntryCmpnspVO paramVo
	 * @return	TaxBillRecptnVO
	 * @throws 	Exception
	 */
	public TaxBillRecptnVO intrfcProcessSttusCodeSubs(TaxBillRecptnVO paramVo) throws Exception {
		log.debug("TaxBillRecptnServiceImpl::intrfcProcessSttusCodeSubs (인터페이스 처리 상태 코드 치환) Start");

		try {

			String docSttusCode		 	= paramVo.getDocSttusCode();		//문서 상태 코드 (B2B_STATUS)
			String recptnMssageCode 	= paramVo.getRecptnMssageCode();	//수신 메시지 코드 (B2B_MSGCODE)
			String recptnResultCode		= paramVo.getRecptnResultCode();	//수신 결과 코드 (B2B_RESULTCODE)

			//처리완료(성공) >> 처리완료
			if(TaxBillRecptnConstants.B2B_STATUS_T.equals(docSttusCode)
					&& TaxBillRecptnConstants.B2B_MSGCODE_1.equals(recptnMssageCode)
					&& TaxBillRecptnConstants.B2B_RESULTCODE_SUC001.equals(recptnResultCode)) {
				paramVo.setIntrfcProcessSttusCode(TaxBillRecptnConstants.INTRFC_STTUS_CODE_S);
			//처리완료(에러 발생)	 >> 오류발생
			} else if (TaxBillRecptnConstants.B2B_STATUS_T.equals(docSttusCode)
					&& TaxBillRecptnConstants.B2B_MSGCODE_1.equals(recptnMssageCode)
					&& !TaxBillRecptnConstants.B2B_RESULTCODE_SUC001.equals(recptnResultCode)) {
				paramVo.setIntrfcProcessSttusCode(TaxBillRecptnConstants.INTRFC_STTUS_CODE_E);
			//처리 실패
			} else if ((TaxBillRecptnConstants.B2B_STATUS_P.equals(docSttusCode)
					&& (TaxBillRecptnConstants.B2B_MSGCODE_3.equals(recptnMssageCode)
							|| TaxBillRecptnConstants.B2B_MSGCODE_98.equals(recptnMssageCode)
							|| TaxBillRecptnConstants.B2B_MSGCODE_99.equals(recptnMssageCode) ))
					|| TaxBillRecptnConstants.B2B_STATUS_F.equals(docSttusCode)) {
				paramVo.setIntrfcProcessSttusCode(TaxBillRecptnConstants.INTRFC_STTUS_CODE_F);
			} else {
				log.debug("btobi 연계 처리 중 ........");
			}//end if()

		} catch (Exception e) {

			log.error("TaxBillRecptnServiceImpl::intrfcProcessSttusCodeSubs exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		}

		log.debug("TaxBillRecptnServiceImpl::intrfcProcessSttusCodeSubs (인터페이스 처리 상태 코드 치환) End");
		return paramVo;
	}//end intrfcProcessSttusCodeSubs()


	/**
	 *
	 * <pre>
	 * EC 처리 상태 코드 치환
	 * </pre>
	 * @date 2021. 9. 3.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 3.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	InvntryCmpnspVO paramVo
	 * @return	TaxBillRecptnVO
	 * @throws 	Exception
	 */
	public TaxBillRecptnVO processSttusCodeSubs(TaxBillRecptnVO paramVo) throws Exception {
		log.debug("TaxBillRecptnServiceImpl::intrfcProcessSttusCodeSubs (EC 처리 상태 코드 치환) Start");

		try {

			String docSttusCode		 	= paramVo.getDocSttusCode();		//문서 상태 코드 (B2B_STATUS)
			String recptnMssageCode 	= paramVo.getRecptnMssageCode();	//수신 메시지 코드 (B2B_MSGCODE)
			String recptnResultCode		= paramVo.getRecptnResultCode();	//수신 결과 코드 (B2B_RESULTCODE)

			//발행완료
			if(TaxBillRecptnConstants.B2B_STATUS_T.equals(docSttusCode)
					&& TaxBillRecptnConstants.B2B_MSGCODE_1.equals(recptnMssageCode)
					&& TaxBillRecptnConstants.B2B_RESULTCODE_SUC001.equals(recptnResultCode)) {
				paramVo.setProcessSttusCode(TaxBillRecptnConstants.PROCESS_STTUS_CODE_03);

			//발행실패
			} else if (TaxBillRecptnConstants.B2B_STATUS_T.equals(docSttusCode)
					&& TaxBillRecptnConstants.B2B_MSGCODE_1.equals(recptnMssageCode)
					&& !TaxBillRecptnConstants.B2B_RESULTCODE_SUC001.equals(recptnResultCode)) {
				paramVo.setProcessSttusCode(TaxBillRecptnConstants.PROCESS_STTUS_CODE_04);
			} else if (TaxBillRecptnConstants.B2B_STATUS_P.equals(docSttusCode)
					&& TaxBillRecptnConstants.B2B_MSGCODE_3.equals(recptnMssageCode)) {
				paramVo.setProcessSttusCode(TaxBillRecptnConstants.PROCESS_STTUS_CODE_04);
			} else if (TaxBillRecptnConstants.B2B_STATUS_F.equals(docSttusCode)) {
				paramVo.setProcessSttusCode(TaxBillRecptnConstants.PROCESS_STTUS_CODE_04);

			//송신실패(재처리요청)
			} else if (TaxBillRecptnConstants.B2B_STATUS_P.equals(docSttusCode)
					&& (TaxBillRecptnConstants.B2B_MSGCODE_98.equals(recptnMssageCode)
							|| TaxBillRecptnConstants.B2B_MSGCODE_99.equals(recptnMssageCode))) {
				paramVo.setProcessSttusCode(TaxBillRecptnConstants.PROCESS_STTUS_CODE_05);

			//처리중
			} else {
				paramVo.setProcessSttusCode(TaxBillRecptnConstants.PROCESS_STTUS_CODE_02);
			}//end if()

		} catch (Exception e) {

			log.error("TaxBillRecptnServiceImpl::processSttusCodeSubs exception = " + e.getMessage());
			throw new Exception(e.getMessage());

		}


		log.debug("TaxBillRecptnServiceImpl::intrfcProcessSttusCodeSubs (EC 처리 상태 코드 치환) End");
		return paramVo;
	}//end processSttusCodeSubs()

	/**
	 *
	 * <pre>
	 * 국세청 응답결과 - 세금계산서 발행완료 건 ERP 전송
	 * </pre>
	 * @date 2021. 10. 22.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 22.			srec0054			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	public void erpTrnsmisTaxBillProcess() throws Exception {
		log.debug("TaxBillRecptnServiceImpl::erpTrnsmisTaxBillProcess (세금계산서 발행완료 건 ERP 전송) Start");
		
		List<TaxBillRecptnVO> erpTrnsmisTaxBillList = null;

		try {
			//ERP 전송 대상 주문 목록 조회
			erpTrnsmisTaxBillList = taxBillRecptnMapper.selectErpTrnsmisTaxBillList();

			if(erpTrnsmisTaxBillList.size() > 0) {
				// 2023-01-31 변경사항 : ERP 중복 전송 방어 로직 추가
				// 조회된 리스트가 다음 배치 프로그램에서 재조회 되지 않도록, 먼저 ERP 전송여부 업데이트
				for (TaxBillRecptnVO taxBillRecptnVo : erpTrnsmisTaxBillList) {
					taxBillRecptnVo.setTrnsmitAt("P");	//송신 처리 중
					taxBillRecptnVo.setFrstRegisterId(TaxBillRecptnConstants.TAX_BILL_IF);
					taxBillRecptnVo.setLastChangerId(TaxBillRecptnConstants.TAX_BILL_IF);
					taxBillRecptnMapper.updateErpTrnsmisTaxBill(taxBillRecptnVo);
					taxBillRecptnMapper.updateOrTaxBillBasHst(taxBillRecptnVo);
				}

				for(TaxBillRecptnVO taxBillRecptnVo : erpTrnsmisTaxBillList) {
					//ERP 계정 송신(세금계산서 - 매출) API call
					//read time out exception 발생으로 건 단위 api call로 수정함.
					//URI path = getPath(httpSchema, null, apiHost, apiPort, null, null, null);
					log.debug("taxBillRecptnUrl ======> " + taxBillRecptnUrl);
					Map<String, Object> returnMap = httpClientHelper.postCallApi(taxBillRecptnUrl, taxBillRecptnVo);
					String responseCode = (String) returnMap.get("responseCode");
					log.debug("responseCode =================> " + responseCode);

					//ERP 계정 송신(새금계산서 - 매출) API : SUCCESS(성공)인 경우
					if(TaxBillRecptnConstants.SUCCESS_RESULT_CODE.equals(responseCode)) {
						log.debug("TaxBillRecptnServiceImpl::erpTrnsmisTaxBillProcess /api/erpAcntTrnsmit/BassSelng Success");
						taxBillRecptnVo.setTrnsmitAt("Y");	//송신 완료
					} else {
						log.debug("TaxBillRecptnServiceImpl::erpTrnsmisTaxBillProcess /api/erpAcntTrnsmit/BassSelng Fail");
						taxBillRecptnVo.setTrnsmitAt(null);	//송신 대상 = 미전송건
					}//end if()
					
					//ERP 송신 여부 업데이트
					taxBillRecptnMapper.updateErpTrnsmisTaxBill(taxBillRecptnVo);
					taxBillRecptnMapper.updateOrTaxBillBasHst(taxBillRecptnVo);
				}//end for()
			} else {
				log.debug("TaxBillRecptnServiceImpl::erpTrnsmisTaxBillProcess (세금계산서 발행완료 건 ERP 전송) is null");
			}//end if()

		} catch (Exception e) {
			log.error("TaxBillRecptnServiceImpl::erpTrnsmisTaxBillProcess exception = " + e.getMessage());
			throw new Exception(e.getMessage());
		}

		log.debug("TaxBillRecptnServiceImpl::erpTrnsmisTaxBillProcess (세금계산서 발행완료 건 ERP 전송) End");
	}//end erpTrnsmisTaxBillProcess()

	public URI getPath(String scheme, String userInfo, String host, Integer port, String path, String query, String fragment) throws Exception {
		log.debug("TaxBillRecptnServiceImpl::getPath");
		log.debug("scheme = " + scheme);
		log.debug("userInfo = " + userInfo);
		log.debug("host = " + host);
		log.debug("port = " + port);
		log.debug("path = " + path);
		log.debug("query = " + query);
		log.debug("fragment = " + fragment);

		URI uri = null;

		try {
			uri = new URI(scheme, userInfo, host, port, path, query, fragment);

			log.debug("********************************************************************************");
			log.debug("uri = " + uri);
			log.debug("********************************************************************************");
		} catch (URISyntaxException e) {
			log.debug("TaxBillRecptnServiceImpl::getPath exception = " + e.getMessage());
			throw new Exception("TaxBillIssueInquiryServiceImpl::getPath exception = " + e.getMessage());
		}

		return uri;
	}//end getPath()
}//end class()
