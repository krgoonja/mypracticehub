package com.sorincorp.batch.or.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.or.service.TaxbilUnIsuService;

import lombok.extern.slf4j.Slf4j;

/**
 *  ERP생성 오류 건 메일 알림 서비스 (세금계산서) JobConfig
 * TaxbilUnIsuJobConfig.java
 * @version
 * @since 2023. 12. 18.
 * @author sein
 */
@Slf4j
@Component
public class TaxbilUnIsuTasklet implements Tasklet, StepExecutionListener {
	
	@Autowired
	TaxbilUnIsuService taxbilUnIsuService;
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("TaxbilUnIsuTasklet::beforeStep");
	}//end beforeStep()
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("TaxbilUnIsuTasklet::execute Start");
		
		taxbilUnIsuService.sendTaxbilUnIsu();
		
		log.debug("TaxbilUnIsuTasklet::execute End");
		return RepeatStatus.FINISHED;
	}//end execute()
	
	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("TaxbilUnIsuTasklet::afterStep");
        return ExitStatus.COMPLETED;
	}//end afterStep()

}//end class()