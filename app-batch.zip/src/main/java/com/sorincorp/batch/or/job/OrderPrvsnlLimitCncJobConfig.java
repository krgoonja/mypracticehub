package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * OrderPrvsnlLimitCncJobConfig.java
 * 가단가 지정가 주문 취소 배치 JobConfig
 * @version
 * @since 2024. 10. 23.
 * @author srec0066
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class OrderPrvsnlLimitCncJobConfig {

	@Autowired
	OrderPrvsnlLimitCncTasklet orderPrvsnlLimitCncTasklet;

	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job orderPrvsnlLimitCncJob() {
		return jobBuilderFactory.get("orderPrvsnlLimitCncJob")
				.start(orderPrvsnlLimitCncStep())
				.build();
	}

	@Bean
	@JobScope
	public Step orderPrvsnlLimitCncStep() {
		return stepBuilderFactory.get("orderPrvsnlLimitCncStep")
				.tasklet(orderPrvsnlLimitCncTasklet)
				.build();
	}
}
