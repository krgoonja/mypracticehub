package com.sorincorp.batch.or.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.batch.or.mapper.TaxbilUnIsuMapper;
import com.sorincorp.batch.or.model.TaxbilUnIsuVO;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TaxbilUnIsuServiceImpl implements TaxbilUnIsuService{

	@Autowired
	private TaxbilUnIsuMapper taxbilUnIsuMapper;

	/** 메일 발송 서비스 */
    @Autowired
    private MailService mailService;

	/** 알림톡 발송 서비스 */
	@Autowired
	SMSService smsService;

	@Autowired
	private MailMapper mailMapper;

	@Value("${spring.profiles.active}")
	private String profiles;


	/**
	 * 세금계산서 미 발행  메일 발송
	 * */
	@Transactional(rollbackFor = Exception.class)
	@Override
	public void sendTaxbilUnIsu() throws Exception {

		log.debug("TaxbilUnIsuServiceImpl:sendTaxbilUnIsu (ERP생성 오류 건 메일 발송 (세금계산서)) Start");
        
        // 당일이 휴일 혹은 공휴일인지 확인
		int lastBsnDe = taxbilUnIsuMapper.selectLastBsnDe();

		if(lastBsnDe == 0) {
			log.debug("주말, 휴일이 아니므로 실행");
			List<TaxbilUnIsuVO> mergedTaxbilUnIsuList = new ArrayList<>();
			// ERP생성 오류 건 (1차 세금계산서)
			List<TaxbilUnIsuVO> oneTaxbilUnIsu = taxbilUnIsuMapper.selectOneTaxbilUnIsuList();
			// ERP생성 오류 건 (2차 세금계산서)  니켈은 1차만 발행하기 때문에 제외(쿼리에 적용) 
			List<TaxbilUnIsuVO> twoTaxbilUnIsu = taxbilUnIsuMapper.selectTwoTaxbilUnIsuList();
			mergedTaxbilUnIsuList.addAll(oneTaxbilUnIsu);
			mergedTaxbilUnIsuList.addAll(twoTaxbilUnIsu);
			// 당일 날짜 구하기
			String dayParam = DateUtil.getNowDateTime();
			// 메일 발송 및 히스토리 등록
			// 세금계산서 미 발행 건
			sendTaxbilUnIsuEmail(mergedTaxbilUnIsuList, dayParam, 86);
		}
	}

	/**
	 * Email 전송 및 history 등록
	 * */
	@Transactional(rollbackFor = Exception.class)
	public void sendTaxbilUnIsuEmail( List<TaxbilUnIsuVO> taxbilUnIsu, String dayParam, int templateNum) throws Exception{
		log.debug("TaxbilUnIsuServiceImpl:sendTaxbilUnIsuEmail (ERP생성 오류 건 메일 발송 (세금계산서)) :: templateNum " + templateNum + " Start" + taxbilUnIsu.toString());

		Map<String, String> mailMap = new HashMap<String, String>();
		
		List<TaxbilUnIsuVO> filterList = taxbilUnIsu.stream()
				.filter(vo -> vo.getTemplateNum() == templateNum)
				.collect(Collectors.toList());
		
		// 내역이 없는 경우 메일 발송하지 않음
		if(filterList.size() == 0) return;
		
		mailMap.put("TODAY", dayParam);                                        // 당일 날자
		mailMap.put("CHIT_UN_ISU_DTLS", getTaxbilUnIsuList(filterList, templateNum)); //  ERP생성 오류 건 1차,2차 합쳐서 발송(추후에 분리가능)

		log.warn("::: mailMap : "+ mailMap.toString());

		List<MailVO> param = new ArrayList<>();
		MailVO mail = new MailVO();

		/* mailVo 셋팅 */
		mail = mailMapper.selectMailTmpt(templateNum); 

		MailVO mailVo = new MailVO();
		mailVo.setMailTmptSeq(templateNum);
		mailVo.setMailSendEmail(mail.getSntoEmail());
		mailVo.setMailSendUserId("system");
		param.add(mailVo);

		/* 메일 발송 */
		mailService.insertMailListSend(param, mailMap);

	}

	/**
	 * ERP전표 오류 건 String 전환
	 * */
	public String getTaxbilUnIsuList(List<TaxbilUnIsuVO> taxbilUnIsu, int templateNum) {
		StringBuilder builder = new StringBuilder();
		int lastSize = 1;
		// html setting
		if(taxbilUnIsu.size() > 0) {
			for(TaxbilUnIsuVO vo : taxbilUnIsu) {
				if(lastSize == taxbilUnIsu.size()) {
					builder.append(" "+vo.getOrderNo());
				}else {
					builder.append(" "+vo.getOrderNo()+", ");
				}
				lastSize++;
			}
		}
		return builder.toString();
	}


	public String dateformat(String date) {
		String format = date.substring(0,4) + "-" + date.substring(4,6) + "-" + date.substring(6,8);
		return format;
	}

}