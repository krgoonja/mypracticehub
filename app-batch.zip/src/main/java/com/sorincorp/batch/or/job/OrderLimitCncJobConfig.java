package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 대기중인 지정가 주문 취소 배치 JobConfig
 * @since 2023. 4. 19
 * @author srec0051
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class OrderLimitCncJobConfig {

	@Autowired
	OrderLimitCncTasklet orderLimitCncTasklet;

	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job orderLimitCncJob() {
		return jobBuilderFactory.get("orderLimitCncJob")
				.start(orderLimitCncStep())
				.build();
	}

	@Bean
	@JobScope
	public Step orderLimitCncStep() {
		return stepBuilderFactory.get("orderLimitCncStep")
				.tasklet(orderLimitCncTasklet)
				.build();
	}
}
