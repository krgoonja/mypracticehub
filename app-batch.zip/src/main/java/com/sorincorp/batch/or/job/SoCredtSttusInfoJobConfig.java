package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 월 단위 서린트레딧 현황 정보 영업팀 메일 발송 JobConfig
 * SorinCreditSttusInfoJobConfig.java
 * @version
 * @since 2022. 12. 09.
 * @author srec0076
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class SoCredtSttusInfoJobConfig {
	
	@Autowired
	SoCredtSttusInfoTasklet sorinCreditSttusInfoTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory; 
	
	@Bean
	public Job sorinCreditSttusInfoJob() {
		return jobBuilderFactory.get("sorinCreditSttusInfoJob")
				.start(sorinCreditSttusInfoStep())
				.build();  
	}//end sorinCreditSttusInfoJob()
	
	@Bean
	@JobScope
	public Step sorinCreditSttusInfoStep() {
		return stepBuilderFactory.get("sorinCreditSttusInfoStep")
				.tasklet(sorinCreditSttusInfoTasklet)
				.build();
	}//end sorinCreditSttusInfoStep()
	
}//end class()