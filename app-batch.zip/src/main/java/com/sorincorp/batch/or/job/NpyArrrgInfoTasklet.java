package com.sorincorp.batch.or.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.or.service.NpyArrrgInfoService;

import lombok.extern.slf4j.Slf4j;

/**
 * 결제 예정, 미납/연체 내역 메일 발송 JobConfig
 * NpyArrrgInfoJobConfig.java
 * @version
 * @since 2023. 1. 20.
 * @author srec0076
 */
@Slf4j
@Component
public class NpyArrrgInfoTasklet implements Tasklet, StepExecutionListener {
	
	@Autowired
	NpyArrrgInfoService npyArrrgInfoService;
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("NpyArrrgInfoTasklet::beforeStep");
	}//end beforeStep()
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("NpyArrrgInfoTasklet::execute Start");
		
		npyArrrgInfoService.sendNpyArrrgInfo();
		
		log.debug("NpyArrrgInfoTasklet::execute End");
		return RepeatStatus.FINISHED;
	}//end execute()
	
	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("NpyArrrgInfoTasklet::afterStep");
        return ExitStatus.COMPLETED;
	}//end afterStep()

}//end class()