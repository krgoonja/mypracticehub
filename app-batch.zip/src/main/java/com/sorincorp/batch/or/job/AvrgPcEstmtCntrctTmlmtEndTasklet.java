package com.sorincorp.batch.or.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.or.service.AvrgPcEstmtCntrctService;

import lombok.extern.slf4j.Slf4j;

/**
 * AvrgPcEstmtCntrctTmlmtEndTasklet.java
 * : 평균가 견적 기한/계약 승인 기한 만료 Batch Tasklet
 * @version
 * @since 2024. 1. 3.
 * @author srec0066
 */
@Slf4j
@Component
public class AvrgPcEstmtCntrctTmlmtEndTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	AvrgPcEstmtCntrctService avrgPcEstmtCntrctService;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("AvrgPcEstmtCntrctTmlmtEndTasklet::beforeStep");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		avrgPcEstmtCntrctService.executeEstmtCntrctTmlmtEnd();

		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("AvrgPcEstmtCntrctTmlmtEndTasklet::afterStep");
		return ExitStatus.COMPLETED;
	}

}
