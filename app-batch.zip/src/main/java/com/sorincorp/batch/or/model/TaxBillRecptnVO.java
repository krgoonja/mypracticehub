package com.sorincorp.batch.or.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel("세금계산서 발행완료 btobi 수신 VO")
public class TaxBillRecptnVO{
	

	/**주문 번호*/
	private String orderNo;					
	
	/**취소 교환 반품 번호*/
	private String canclExchngRtngudNo;		

	/**세금 계산서 승인 번호*/
	private String taxBillConfmNo;
	
	/**문서 상태 코드 (BTOBI)*/
	private String docSttusCode;			
	
	/**수신 메시지 코드 (BTOBI)*/
    private String recptnMssageCode;		
    
    /**수신 결과 코드 (BTOBI)*/
    private String recptnResultCode;		
    
    /**처리 상세 설명 (BTOBI)*/
    private String processDetailDc;			
    
    /**전자 세금 계산서 발급일시 (BTOBI)*/
    private String elctrnTaxBillIssuDt;		
    
    /**사업자 관리 번호 (BTOBI)*/
	private String bsnmManageNo;			

	/** EC 코드 생성 */
	/**인터페이스 처리 상태 코드 (EC)*/
	private String intrfcProcessSttusCode;
	
	/**처리 상태 코드 (EC)*/
	private String processSttusCode;
	
	/**세금 계산서 신청 번호*/
	private String taxBillReqstNo;
	
	/**세금 계산서 신청 상세 순번*/
	private String taxBillReqstDetailSn;
	
	/**세금 계산서 발행 구분 코드*/
	private String taxBillIsuSeCode;
	
	/**최초 등록자 아이디*/
	private String frstRegisterId;
	
	/**최종 변경자 아이디*/
	private String lastChangerId;
	
	/**세금계산서 분류코드*/
	private String taxBillClCode;
	
	/**주문자 휴대폰번호*/
	private String tlphonNo;
	
	/**공급자 상호 명*/
	private String supledMtltyNm;
	
	/**총 금액*/
	private String totAmount;
	
	/**회원번호*/
	private String mberNo;
	
	/**ERP 송신여부*/
	private String trnsmitAt;
	
}//end class()
