package com.sorincorp.batch.or.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.batch.comm.constants.CommConstants;
import com.sorincorp.batch.or.comm.ClaimResponseEntity;
import com.sorincorp.batch.or.model.ClaimBasVO;
import com.sorincorp.batch.or.service.ClaimService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/batch/or")
@Api( value = "Claim Batch Controller")
@ComponentScan("com.sorincorp.comm.*")
public class ClaimController {

	@Autowired
	private ClaimService claimService;

	@PostMapping("/orderCancelEwallet")
	@ApiOperation(value = "주문 취소 클레임 이월렛 처리 Batch", notes = "주문 취소 클레임 이월렛 처리 Batch")
	public ClaimResponseEntity orderCancelEwallet() throws Exception{
		log.debug("::Start");

		try {
			String ret = claimService.cancelEwalletCall();
			log.debug(ret);

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new Exception(e.getMessage());
		}

		log.debug("::End");
		return new ClaimResponseEntity(CommConstants.SUCCESS_CODE, CommConstants.SUCCESS_MSG, null);
	}

	@PostMapping("/orderRetrunEwallet")
	@ApiOperation(value = "주문 반품 클레임 이월렛 처리 Batch", notes = "주문 반품 클레임 이월렛 처리 Batch")
	public ClaimResponseEntity orderRetrunEwallet() throws Exception{
		log.debug("::Start");

		try {
			String ret = claimService.returnEwalletCall();
			log.debug(ret);

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new Exception(e.getMessage());
		}

		log.debug("::End");
		return new ClaimResponseEntity(CommConstants.SUCCESS_CODE, CommConstants.SUCCESS_MSG, null);
	}

	/**
	 * <pre>
	 * 처리내용: 이월렛 단건 재처리 (이월렛 처리 후 세금계산서 까지)
	 * </pre>
	 * @date 2021. 11. 17.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 17.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param claimVo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/retryEwallet")
	public ClaimResponseEntity retryEwallet(@RequestBody ClaimBasVO claimVo) throws Exception{
		log.debug(":: START ");
		log.debug(":: END ");
		return new ClaimResponseEntity(CommConstants.SUCCESS_CODE, CommConstants.SUCCESS_MSG, null);
	}

	/**
	 * <pre>
	 * 처리내용: 세금계산서 단건 재처리 (세금계산서만)
	 * </pre>
	 * @date 2021. 11. 17.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 17.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param claimVo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/retryTaxbill")
	public ClaimResponseEntity retryTaxbill(@RequestBody ClaimBasVO claimVo) throws Exception{
		log.debug(":: START ");
		log.debug(":: END ");
		return new ClaimResponseEntity(CommConstants.SUCCESS_CODE, CommConstants.SUCCESS_MSG, null);
	}
}
