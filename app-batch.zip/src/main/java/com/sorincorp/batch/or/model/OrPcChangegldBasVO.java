package com.sorincorp.batch.or.model;

import lombok.Data;

/**
 * OrPcChangegldBasVO.java
 * 주문_가격 변동금 기본 VO 객체
 * 
 * @version
 * @since 2024. 11. 11.
 * @author srec0049
 */
@Data
public class OrPcChangegldBasVO {

	/**
     * 주문 번호
     */
    private String orderNo;
    
    /**
     * 발생 순번
     */
    private long occrrncSn;
    
    /**
     * 발생 일시
     */
    private String occrrncDt;
    
    /**
     * 발생 일자
     */
    private String occrrncDe;
    
    /**
     * 평가 금액
     */
    private long evlAmount;
    
    /**
     * 가격 변동금 상태 코드
     */
    private String pcChangegldSttusCode;
    
    /**
     * 최초 단가 기준 기 납입 금액
     */
    private long frstUntpcStdrPrePayAmount;
    
    /**
     * 최초 기 납입 금액
     */
    private long frstPrePayAmount;
    
    /**
     * 단가 기준 기 납입 금액
     */
    private long untpcStdrPrePayAmount;
    
    /**
     * 기 납입 금액
     */
    private long prePayAmount;
    
    /**
     * 변동 단가
     */
    private long changeUntpc;
    
    /**
     * 확정 변동 단가
     */
    private long dcsnChangeUntpc;
    
    /**
     * 입출금 대상 금액
     */
    private long rcppayTrgetAmount;
    
    /**
     * 청산 대상 제외 여부
     */
    private String lqdTrgetExclAt;
    
    /**
     * 결제 번호
     */
    private String setleNo;
    
    /**
     * 삭제 일시
     */
    private String deleteDt;
    
    /**
     * 삭제 여부
     */
    private String deleteAt;
    
    /**
     * 최초 등록자 아이디
     */
    private String frstRegisterId;
    
    /**
     * 최초 등록 일시
     */
    private String frstRegistDt;
    
    /**
     * 최종 변경자 아이디
     */
    private String lastChangerId;
    
    /**
     * 최종 변경 일시
     */
    private String lastChangeDt;
    
    /**
     * 담보 거래 유형 코드
     */
    private String mrtggDelngTyCode;
    
    /**
     * 담보 적요
     */
    private String mrtggSumry;
    
    /**
     * 담보 거래 금액
     */
    private long mrtggDelngAmount;
    
    /**
	 * 평균가 상품 단가
	 */
	private long avrgpcGoodsUntpc;
	
	/**
	 * 최초 가격 변동 금액
	 */
	private long frstPcChangeAmount;
	
	/**
	 * 총 합계 금액
	 */
	private long totalChangeAmount;
	
    /**
     * 담보 잔액
     */
    private Long mrtggBlce;
    
    /**
	 * 결제 방식 코드
	 */
	private String setleMthdCode;
}
