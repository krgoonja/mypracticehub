package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class ClaimReturnJobConfig {

	@Autowired
	private ClaimReturnTasklet claimReturnTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory;
	
	@Bean
	public Job claimReturnJob() {
		return jobBuilderFactory.get("claimReturnJob")
				.start(claimReturnStep())
				.build();  
	}
	
	@Bean
	@JobScope
	public Step claimReturnStep() {
		return stepBuilderFactory.get("claimReturnStep")
				.tasklet(claimReturnTasklet)
				.build();
	}
}
