package com.sorincorp.batch.or.model;

import java.util.List;

import com.sorincorp.comm.order.model.CommFtrsFshgMngVO;
import com.sorincorp.comm.order.model.ItPurchsInfoBas;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;

import lombok.Data;

@Data
public class BatchOrderModel {

    /**
     * 주문 일자
    */
    private String orderDe;
    /**
     * 회원 번호
    */
    private String mberNo;
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 판매 방식 코드
    */
    private String sleMthdCode;
    /**
     * 주문 상태 코드
    */
    private String orderSttusCode;
    /**
     * 배송 수단 코드
    */
    private String dlvyMnCode;
    /**
     * 출고 요청 일자
    */
    private String dlivyRequstDe;
    /**
     * 주문 배송지 번호
    */
    private String orderDlvrgNo;
    /**
     * 주문 배송비 번호
    */
    private String orderDlvrfNo;
    /**
     * 판매 단위 코드
    */
    private String sleUnitCode;
    /**
     * 총 번들 수량
    */
    private int totBundleQy;
    /**
     * 판매 가격 실시간 순번
    */
    private String slePcRltmSn;
    /**
     * LME 가격 실시간 순번
    */
    private String lmePcRltmSn;
    /**
     * 환율 가격 실시간 순번
    */
    private String ehgtPcRltmSn;
    /**
     * 프리미엄 기준 금액
    */
    private long premiumStdrAmount;
    /**
     * 권역 변동 금액
    */
    private long dstrctChangeAmount;
    /**
     * 브랜드 그룹 변동 금액
    */
    private long brandGroupChangeAmount;
    /**
     * 브랜드 변동 금액
    */
    private long brandChangeAmount;

    /**
     * 고정가 권역 변동 금액
    */
    private java.math.BigDecimal hghnetprcDstrctChangeAmount;
    /**
     * 고정가 브랜드 그룹 변동 금액
    */
    private java.math.BigDecimal hghnetprcBrandGroupChangeAmount;
    /**
     * 고정가 브랜드 변동 금액
    */
    private java.math.BigDecimal hghnetprcBrandChangeAmount;
    /**
     * 고정가 할증 요율
    */
    private java.math.BigDecimal hghnetprcTotAmtTariff;
    /**
     * 고정가 평균 구매 원가
    */
    private java.math.BigDecimal hghnetprcAvrgPurchsPrmpc;
    /**
     * 고정가 판매 금액
    */
    private java.math.BigDecimal hghnetprcSleAmount;


    /**
     * LME 3M
    */
    private java.math.BigDecimal lme3m;
    /**
     * LME 현금
    */
    private java.math.BigDecimal lmeCash;
    /**
     * LME 조정 계수
    */
    private java.math.BigDecimal lmeMdatCffcnt;
    /**
     * 현물환
    */
    private java.math.BigDecimal spex;
    /**
     * 현물환 조정 계수
    */
    private java.math.BigDecimal spexMdatCffcnt;
    /**
     * 정산 처리 여부
    */
    private String excclcProcessAt;
    /**
     * 정산 처리 일시
    */
    private java.sql.Timestamp excclcProcessDt;

    /**
     * 총 확정 중량
    */
    private java.math.BigDecimal totDcsnWt;
    /**
     * 총 확정 주문 가격
    */
    private long totDcsnOrderPc;
    /**
     * 총 확정 공급가
    */
    private long totDcsnSplpc;
    /**
     * 정산 공급가
    */
    private long excclcSplpc;
    /**
     * 정산 부가세
    */
    private long excclcVat;
    /**
     * 정산 금액
    */
    private long excclcAmount;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
    /**
     * 결제 방식 코드
    */
    private String setleMthdCode;
    /**
     * 결제 방식 상세 코드
    */
    private String setleMthdDetailCode;
    /**
     * 증거금 결제 예정 일자
    */
    private String wrtmSetlePrearngeDe;
    /**
     * 주문 홀딩 사용 여부
    */
    private String orderHoldingUseAt;
	/**
	 * 사고 이력 구분 코드(10. 연체(증거금), 20. 사고(전자상거래보증, 케이지크레딧))
	 */
	private String acdntHistSeCode;

/*
 * 확인 시작
 */
    /**
     * 주문 번호
    */
    private String orderNo;

    /**
     * 주문자 명
    */
    private String ordrrNm;

    /**
     * 주문자 휴대폰 번호
    */
    private String ordrrMoblphonNo;
    /**
     * 주문자 이메일
    */
    private String ordrrEmail;

    /**
     * 주문자 회사명
     */
    private String orderEntrpsNm;

    /**
     * 주문 완료 일시
    */
    private String orderComptDt;

	/**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 아이템 명
    */
    private String itmNm;
    /**
     * 상품 명
    */
    private String goodsNm;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;

    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;

	/**
	 * 프리미엄 번호
	*/
	private String premiumNo;

    /**
     * 취소 프리미엄 번호
    */
    private String claimPremiumNo;
    /**
     * 프리미엄 가격
    */
    private java.math.BigDecimal premiumPc;

    /**
     * 취소 프리미엄 가격
    */
    private java.math.BigDecimal claimPremiumPc;

    /**
     * 상품 단가
    */
    private long goodsUntpc;
	 /**
	  * 주문 가격
	 */
	 private long orderPc;
	/**
	 * 중량 변동금
	 */
	private long wtChangegld;
	/**
	 * 공급가
	*/
	private long splpc;
	/**
	 * 부가세
	*/
	private long vat;
	/**
	 * 판매가
	 */
	private long slepc;

    /**
     * claim 상품 단가
    */
    private long claimGoodsUntpc;

    /**
     * claim 주문 가격
    */
    private long claimOrderPc;

	/**
	 * 중량 변동
	**/
	private double wtChange;

    /**
     * 중량 변동금
    */
    private long claimWtChangegld;

    /**
     * 공급가
    */
    private long claimSplpc;

    /**
     * 부가세
    */
    private long claimVat;

    /**
     * 판매가
    */
    private long claimSlepc;

    /**
     * 총 고객 주문 중량
    */
    private int totCstmrOrderWt;
    /**
     * 총 실제 주문 중량
    */
    private int totRealOrderWt;
    /**
     * OMS 접수 번호
    */
    private String omsRceptNo;

	/** 취소교환 반품번호 **/
	private String canclExchngRtngudNo;
    /**
     * 주문 업체 명
    */
    private String entrpsNm;
    /**
     * 다음달 선물 만기일
     */
	private String nextFtrsExprtnDe;
	/**
	 * 다음달 선물환 만기일
	 */
	private String nextFshgExprtnDe;
    /**
     * 최초 결제 금액
    */
    private long frstSetleAmount;
	/**
	 * 고객센터 전화번호
	 */
	private String csTelNo;
	/**
	 * 삼성선물 주문 단위 중량
	*/
	private int samsungOrderWt;
	/**
	 * 요청 선물 종목 코드
	*/
	private String samsungStockCode;
	/**
	 * 선물 요청 주문 번호
	 */
	private String ftrsRequstOrderNo;
	/**
	 * 선물 원 요청 주문 번호
	 */
	private String requstWonOrderNo;
	/**
	 * 선물환 요청 주문 번호
	 * **/
	private String fshgRequstOrderNo;
	/**
	 * Ewallet 가상 계좌 번호
	 */
	private String ewalletAcnutNo;
	/**
	 * 로그인 유저 ID
	 */
	private String mberId;
	/**
	 * 예상배송비
	 * **/
	private long expectDlvrf;
	/**
	 * 삼성성물 계좌번호
	 */
	private String requstAcnutNo;
	/**
	 * 요청 주문 단가
	 */
	private String requstOrderUntpc;
	/**
	 * BL QY 수량
	 */
	private int requstOrderQy;

	/**
	 * 거래 일련 번호
	 */
	private String delngSeqNo;
	/**
	 * 새로 채번 프라이싱 번호
	 */
	private String newPricingNo;
	/**
	 * 삼성선물 주문 타입
	 */
	private String samsungOrdertype;
	/**
	 * 고시 금액
	 */
	private long ntfcAmount;
	/**
	 * 대운송비 금액
	 */
	private long lrgetrnsprtctAmount;
	/**
	 * 마진 금액
	 */
	private long marginAmount;

	public String getPrefix() {
		return "ORDER_NO: [" + this.orderNo + "]";
	}

	/*
	 * 주문_취소 교환 반품 기본 정보
	 */
	private ClaimBasVO claimBas;
	/**
	 * BL PO 테이블
	 */
	private ItPurchsInfoBas itPurchsInfoBas;
	/**
	 * 원주문 BL 상세
	*/
	private ClaimDtlVO claimBlDetail;
	/**
	 * 배송비 기본 리스트
	 */
	private DlvrfBasVO orderDlvrfBas;
	/**
	 * 선물 선물환 관리
	 */
	private CommFtrsFshgMngVO commFtrsFshgMngVO;
	/**
	 * 원주문 BL 목록
	*/
	private List<ClaimDtlVO> claimBlList;
	/**
	 * 삼성선물 키 값 리스트
	*/
	private List<String> ftrnNoList;
	/**
	 * 삼성선물 실패 리스트
	*/
	private List<OrderFtrsBasVO> samsungFailList;
	/**
	 * 주문 상세 리스트
	 */
	private List<OrderDtlVO> orderBasDtlList;
	/**
	 * 삼성선물 취소 키 값 리스트
	 */
	private List<String> cancelFtrnNoList;
	/**
	 * 삼성선물 실패 건들의 원주문번호 키 값 리스트
	 */
	private List<String> requstWonOrderNoListByCancel;
	/**
	 * 실시간 판매가격 정보
	 */
	private PrSelVO prSelVO = new PrSelVO();
	/**
	 * 라이브 프리미엄 가격 정보
	 */
	private LivePremiumVO livePremiumVO = new LivePremiumVO();
	/*
	 * 계약 발주 번호
	 */
	private String cntrctOrderNo;
	/**
	 * 소량 구매 여부
	 */
	private String smlqyPurchsAt;
}