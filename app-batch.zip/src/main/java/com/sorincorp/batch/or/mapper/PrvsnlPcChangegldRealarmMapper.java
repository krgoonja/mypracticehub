package com.sorincorp.batch.or.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.batch.or.model.OrPcChangegldBasVO;
import com.sorincorp.batch.or.model.PrvsnlPcChangegldRealarmInfoVO;

/**
 * PrvsnlPcChangegldRealarmMapper.java
 * 가단가 변동금 재알람 관련 Mapper 인터페이스
 * 
 * @version
 * @since 2024. 11. 21.
 * @author srec0049
 */
public interface PrvsnlPcChangegldRealarmMapper {

	/**
	 * <pre>
	 * 처리내용: 가단가 변동금 재알람 대상 리스트 가져오기 (이월렛의 입금요망(10), 출금대상(40)만 대상)
	 * </pre>
	 * @date 2024. 11. 21.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 21.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param prvsnlPcChangegldRealarmInfoVO
	 * @return
	 * @throws Exception
	 */
	List<PrvsnlPcChangegldRealarmInfoVO> selectPrvsnlPcChangegldRealarmTargetList(PrvsnlPcChangegldRealarmInfoVO prvsnlPcChangegldRealarmInfoVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 가단가 구매 변동금 추가/환불 재알람 SMS 내용 정보 가져오기 (이월렛의 입금요망(10), 출금대상(40)만 대상)
	 * </pre>
	 * @date 2024. 11. 21.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 21.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orPcChangegldBasVO
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectPrvsnlPcChangegldRealarmSmsInfo(OrPcChangegldBasVO orPcChangegldBasVO) throws Exception;
}
