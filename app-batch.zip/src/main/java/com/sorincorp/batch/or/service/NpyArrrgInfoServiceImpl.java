package com.sorincorp.batch.or.service;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.batch.or.mapper.NpyArrrgInfoMapper;
import com.sorincorp.batch.or.model.NpyArrrgInfoVO;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class NpyArrrgInfoServiceImpl implements NpyArrrgInfoService{

	@Autowired
	private NpyArrrgInfoMapper npyArrrgInfoMapper;

	/** 메일 발송 서비스 */
    @Autowired
    private MailService mailService;

	/** 알림톡 발송 서비스 */
	@Autowired
	SMSService smsService;

	@Autowired
	private MailMapper mailMapper;

    @Autowired
    private CommonCodeService commonCodeService;

	@Value("${spring.profiles.active}")
	private String profiles;


	/**
	 * 매일 여신 결제 예정,미납,연체 내역 메일 발송
	 * */
	@Transactional(rollbackFor = Exception.class)
	@Override
	public void sendNpyArrrgInfo() throws Exception {

		log.debug("NpyArrrgInfoServiceImpl:sendNpyArrrgInfo (여신 결제예정/미납/연체 내역 발송) Start");
        
        // 당일이 휴일 혹은 공휴일인지 확인
		int lastBsnDe = npyArrrgInfoMapper.selectLastBsnDe();

		if(lastBsnDe == 0) {
			log.debug("주말, 휴일이 아니므로 실행");

			// 케이지크레딧 현황 정보 조회
			List<NpyArrrgInfoVO> npyArrrgInfo = npyArrrgInfoMapper.selectNpyArrrgInfoList();

			// 당일 날짜 구하기
			String dayParam = DateUtil.getNowDate();

			// 내부사용자 알림톡 발송 및 히스토리 등록
			sendNpyArrrgInfoSMS(npyArrrgInfo);

			// 메일 발송 및 히스토리 등록
			// 결제 예정
			sendNpyArrrgInfoEmail(npyArrrgInfo, dayParam, 79);
			// 미납/연체
			sendNpyArrrgInfoEmail(npyArrrgInfo, dayParam, 85);
		}
	}

	/**
	 * Email 전송 및 history 등록
	 * */
	@Transactional(rollbackFor = Exception.class)
	public void sendNpyArrrgInfoEmail( List<NpyArrrgInfoVO> npyArrrgInfo, String dayParam, int templateNum) throws Exception{
		log.debug("NpyArrrgInfoServiceImpl:sendNpyArrrgInfo (여신 결제예정/미납/연체 내역 발송) :: templateNum " + templateNum + " Start" + npyArrrgInfo.toString());

		Map<String, String> mailMap = new HashMap<String, String>();
		Map<String, CommonCodeVO> csTelNo = commonCodeService.getSubCodesRetVo("SORIN_SETUP_CODE", "CS_TEL");
		
		List<NpyArrrgInfoVO> filterList = npyArrrgInfo.stream()
				.filter(vo -> vo.getTemplateNum() == templateNum)
				.collect(Collectors.toList());
		
		// 내역이 없는 경우 메일 발송하지 않음
		if(filterList.size() == 0) return;
		
		mailMap.put("CS_TEL_NO", csTelNo.get("CS_TEL").getCodeDcone());                    // 연락처
		mailMap.put("TODAY", dateformat(dayParam));                                        // 당일 날자
		mailMap.put("CDTLN_NPY_ARRRG_DTLS", getNpyArrrgInfoList(filterList, templateNum)); // 여신 결제예정,미납,연체 내역

		log.warn("::: mailMap : "+ mailMap.toString());

		List<MailVO> param = new ArrayList<>();
		MailVO mail = new MailVO();

		/* mailVo 셋팅 */
		mail = mailMapper.selectMailTmpt(templateNum);


		MailVO mailVo = new MailVO();
		mailVo.setMailTmptSeq(templateNum);
		mailVo.setMailSendEmail(mail.getSntoEmail());
		mailVo.setMailSendUserId("system");
		param.add(mailVo);

		/* 메일 발송 */
		mailService.insertMailListSend(param, mailMap);

	}

	/**
	 * 업체별 케이지크레딧 현황 정보 html 리턴
	 * */
	public String getNpyArrrgInfoList(List<NpyArrrgInfoVO> npyArrrgInfo, int templateNum) {
		StringBuilder builder = new StringBuilder();
		DecimalFormat decFormat = new DecimalFormat("###,###");
		
		// html setting

		if(npyArrrgInfo.size() > 0) {
			for(NpyArrrgInfoVO vo : npyArrrgInfo) {
				builder.append("<tr>");
				if(vo.getBaseSetleSttus().equals("연체") || vo.getBaseSetleSttus().equals("미납")) { //미납/연체 순번
					builder.append("<td height=\"40\" align=\"center\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + vo.getUnpaidRownum() + "</td>");
				}else { //결제 예정 순번
					builder.append("<td height=\"40\" align=\"center\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + vo.getScheduledRownum() + "</td>");					
				}
				builder.append("<td height=\"40\" align=\"center\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + vo.getBaseSetleSttus() + "</td>");

				switch(vo.getSetleKnd()) {
					case "20" : builder.append("<td height=\"40\" align=\"center\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">전자상거래보증</td>"); break;
					case "4010" : builder.append("<td align=\"center\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 10px; line-height: 24px;\">케이지크레딧</td>"); break;
					case "90" : builder.append("<td height=\"40\" align=\"center\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">증거금</td>"); break;
					default : builder.append("<td height=\"40\" align=\"center\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\"></td>"); break;
				}
				String totDcsnWt = vo.getTotDcsnWt() == 0?"":Double.toString(vo.getTotDcsnWt());
				builder.append("<td height=\"40\" align=\"right\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + vo.getOrderComptDt()+ "&nbsp;</td>");
				builder.append("<td height=\"40\" align=\"center\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + vo.getMetalCodeNm() + "</td>");
				builder.append("<td height=\"40\" align=\"center\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; font-weight: bold; line-height: 12px; word-break: keep-all;\">" + vo.getOrderEntrpsNm()+ "</td>");
				builder.append("<td height=\"40\" align=\"center\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + vo.getOrderNo()+ "&nbsp;</td>");
				builder.append("<td height=\"40\" align=\"right\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + decFormat.format(vo.getSlepc()) + "&nbsp;</td>");
				builder.append("<td height=\"40\" align=\"right\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + vo.getTotRealOrderWt() + "&nbsp;</td>");
				builder.append("<td height=\"40\" align=\"right\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + totDcsnWt + "&nbsp;</td>");
				builder.append("<td height=\"40\" align=\"right\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + decFormat.format(vo.getAvrgpcGoodsUntpc()) + "&nbsp;</td>");				
				builder.append("<td height=\"40\" align=\"right\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + decFormat.format(vo.getGoodsUntpc()) + "&nbsp;</td>");				
				builder.append("<td height=\"40\" align=\"right\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + decFormat.format(vo.getFrstSetleAmount())+ "&nbsp;</td>");
				builder.append("<td height=\"40\" align=\"right\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + decFormat.format(vo.getSetleAmount())+ "&nbsp;</td>");
				builder.append("<td height=\"40\" align=\"right\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + decFormat.format(vo.getUnSetleAmount())+ "&nbsp;</td>");
				builder.append("<td height=\"40\" align=\"right\" style=\"padding: 6px 3px; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + vo.getBaseSetlePrearngeDe()+ "&nbsp;</td>");


				if(vo.getSetleKnd().equals("20") || vo.getSetleKnd().equals("4010")) {
					if(vo.getOrderSttusCode().equals("30")) {
						builder.append("<td height=\"40\" align=\"right\" style=\"padding: 6px 3px; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + vo.getSetleComptDt()+ "</td>");
					}else {
						builder.append("<td height=\"40\" align=\"right\" style=\"padding: 6px 3px; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\"></td>");
					}
				}else {
					if(vo.getSetleAmount() > 0) {
						builder.append("<td height=\"40\" align=\"right\" style=\"padding: 6px 3px; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\">" + vo.getSetleComptDt()+ "</td>");
					}else {
						builder.append("<td height=\"40\" align=\"right\" style=\"padding: 6px 3px; border: 1px solid #e9e9e9; color: #333333; font-size: 9px; line-height: 12px;\"></td>");
					}
				}

//				if(vo.getBaseSetleSttus().equals("연체") || vo.getBaseSetleSttus().equals("미납")) {
//					builder.append("<td align=\"right\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #ff0000; font-size: 10px; line-height: 24px;\">" + vo.getCdtlnRepyDaycnt()+ "&nbsp;</td>");
//				}else {
//					builder.append("<td align=\"right\" style=\"padding: 6px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 10px; line-height: 24px;\">" + vo.getCdtlnRepyDaycnt()+ "&nbsp;</td>");
//				}
				builder.append("</tr>");
			}
		}else {
			builder.append("<tr>");
			builder.append("<td colspan=\"13\" align=\"center\" style=\"padding: 10px 10px; border: 1px solid #e9e9e9; color: #333333; font-size: 14px; line-height: 24px;\"> 결제 예정, 연체/미납 내역이 없습니다.</td>");
			builder.append("</tr>");
		}
		return builder.toString();
	}


	public String dateformat(String date) {
		String format = date.substring(0,4) + "-" + date.substring(4,6) + "-" + date.substring(6,8);
		return format;
	}

	/**
	 * 연체 내역 알림톡 발송 및 history 등록
	 * */
	@Transactional(rollbackFor = Exception.class)
	public void sendNpyArrrgInfoSMS( List<NpyArrrgInfoVO> npyArrrgInfo) throws Exception{
		//연체내역 내부사용자 알림톡 발송
		log.debug("HAM :: NpyArrrgInfoServiceImpl:sendNpyArrrgInfoSMS 연체내역 알림톡 발송 Start");

		if(profiles.equals("local") || profiles.equals("dev")) {
			log.debug("HAM :: NpyArrrgInfoServiceImpl:sendNpyArrrgInfoSMS 연체내역 알림톡 발송 end(local)");
			return;
		}

		for (NpyArrrgInfoVO vo : npyArrrgInfo) {
			if (StringUtils.equals(vo.getBaseSetleSttus(), "연체")) {
				try {
					Map<String, String> smsMap = new HashMap<>();
					String templateNum = "126";
					String setleMthd = "";
					switch (vo.getSetleMthdCode()) {
						case "20":
							setleMthd = "전자상거래보증";
							break;
						case "30":
							setleMthd = "구매자금";
							break;
						case "80":
							setleMthd = "계좌이체";
							break;
						case "90":
							setleMthd = "증거금";
							break;
						default:
							setleMthd = "케이지크레딧";
							break;
					}
					//알림톡 내용 셋팅
					smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
					smsMap.put("templateNum", templateNum); // 템플릿 번호
					smsMap.put("companyName", vo.getOrderEntrpsNm()); //업체명
					smsMap.put("setleMthd", setleMthd);// 결제 방식
					smsMap.put("setleDate", vo.getBaseSetlePrearngeDe());//결제 예정 일자
					smsMap.put("unSetleAmount", String.valueOf(vo.getUnSetleAmount()).replaceAll("(\\d)(?=(\\d{3})+$)", "$1,")); //미 결제 금액
					// 내부사용자 별도 전송
					smsService.insertSMS(null, smsMap);
				} catch (Exception e){
					log.error("HAM :: NpyArrrgInfoServiceImpl:sendNpyArrrgInfoSMS 연체내역 알림톡 발송 ERROR" + e.getMessage());
				}
			}
		}
	}
}