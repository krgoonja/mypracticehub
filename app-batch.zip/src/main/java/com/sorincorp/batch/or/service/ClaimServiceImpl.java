package com.sorincorp.batch.or.service;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.sorincorp.batch.comm.constants.CommConstants;
import com.sorincorp.batch.or.comm.ClaimConstants;
import com.sorincorp.batch.or.comm.OrCommonConstants;
import com.sorincorp.batch.or.mapper.ClaimMapper;
import com.sorincorp.batch.or.model.ClaimBasVO;
import com.sorincorp.batch.or.model.OrSetleBasVO;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ClaimServiceImpl implements ClaimService {

	@Autowired
	private OrCommonConstants orProperty;

	/** 외부 연계 api 호출 모듈 **/
	@Autowired
	private HttpClientHelper httpClientHelper;

	/** 공통 채번 서비스 **/
	@Autowired
	AssignService assignService;

	@Autowired
	ClaimMapper claimMapper;

	/** Claim 등록자 */
	private final String orRegisterId = "BATCH";

	@Override
	public String cancelEwalletCall() throws Exception {
		log.debug("::cancelEwalletCall START");

		List<ClaimBasVO> list = getClaimList(ClaimConstants.CLAIM_TY_CODE_CANCEL);
		List<OrSetleBasVO> listEwalletComple = callEwallet(list);
		callTaxBill(listEwalletComple);

		log.debug("::cancelEwalletCall END");

		return CommConstants.SUCCESS_MSG;
	}

	@Override
	public String returnEwalletCall() throws Exception {
		log.debug("::returnEwalletCall START");

		List<ClaimBasVO> list = getClaimList(ClaimConstants.CLAIM_TY_CODE_RETURN);
		List<OrSetleBasVO> listEwalletComple = callEwallet(list);
		callTaxBill(listEwalletComple);

		log.debug("::returnEwalletCall END");

		return CommConstants.SUCCESS_MSG;
	}

	private List<ClaimBasVO> getClaimList(String claimTyCode) throws Exception {
		Map<String, Object> searchMap = new HashMap<>();
		searchMap.put("canclExchngRtngudTyCode", claimTyCode);
		/**
		 * 처리 대기중인 클레임 데이터 조회
		 * - 취소가 아니면 lot 정보가 존재해야하고 입고가 모두 완료시 이월렛 처리가 가능 (쿼리 조건 추가)
		 */
		return claimMapper.selectListEwalletTarget(searchMap);
	}

	private List<OrSetleBasVO> callEwallet(List<ClaimBasVO> listClaimVo) throws Exception {
		log.debug("::callEwallet START");

		List<OrSetleBasVO> listEwalletComple = new LinkedList<OrSetleBasVO>();
		if (CollectionUtils.isEmpty(listClaimVo)) {
			log.debug("listClaimVo size is 0");
			return listEwalletComple;
		}

		log.debug("::list count = " + listClaimVo.size());

		String nowDate = DateUtil.getNowDate(); // yyyyMMdd
		for (ClaimBasVO vo : listClaimVo) {
			try {
				/** 결재 기본 테이블 생성 */
//				String setleNo = nowDate + "-"
//						+ assignService.selectAssignValue("OR", "SETLE_NO", nowDate, vo.getMberNo(), 5);

				String setleNo = getNewOrderSetleNo();

				String setleSeCode = null;
				String excclcTyCode = null;

				if (ClaimConstants.CLAIM_TY_CODE_CANCEL.equals(vo.getCanclExchngRtngudTyCode())) {
					setleSeCode = ClaimConstants.SETLE_SE_CODE_CANCEL;
					excclcTyCode = ClaimConstants.EXCCLC_TY_CODE_CANCEL;
				} else if (ClaimConstants.CLAIM_TY_CODE_RETURN.equals(vo.getCanclExchngRtngudTyCode())) {
					setleSeCode = ClaimConstants.SETLE_SE_CODE_RETURN;
					excclcTyCode = ClaimConstants.EXCCLC_TY_CODE_RETURN;
				}

				OrSetleBasVO orSetleBasVo = new OrSetleBasVO();
				orSetleBasVo.setSetleNo(setleNo);
				orSetleBasVo.setOrderNo(vo.getOrderNo());
				orSetleBasVo.setCanclExchngRtngudNo(vo.getCanclExchngRtngudNo());
				orSetleBasVo.setCanclExchngRtngudTyCode(vo.getCanclExchngRtngudTyCode());
				orSetleBasVo.setSetleTyCode(ClaimConstants.SETLE_TY_CODE_REFUND); // 20:환불
				orSetleBasVo.setSetleSttusCode(ClaimConstants.SETLE_STTUS_CODE_REQUEST); // 01:요청
				orSetleBasVo.setSetleSeCode(setleSeCode);
				orSetleBasVo.setDelngAmount(String.valueOf(vo.getExcclcSlepc())); //거래금액 2021.12.10
				// TODO 이월렛 'sms 발송여부' N 으로 설정함
				claimMapper.insertEwalletSetle(orSetleBasVo);
				claimMapper.insertEwalletSetleHst(orSetleBasVo);

				/**
				 * iemSeCode : 0001(물품구매), 0002(환불), 0003(이체), 0004(기업뱅킹 환불)
				 * 0002 = 가상계좌 -> 고객계좌
				 * 0003 = 서린계좌 -> 가상계좌(고객)
				 */
				Map<String, Object> ewalletMap = new HashMap<String, Object>();
				ewalletMap.put("entrpsNo", vo.getEntrpsNo());
				ewalletMap.put("iemSeCode", "0003");
				ewalletMap.put("delngAmount", vo.getSlepc());
				ewalletMap.put("setleNo", setleNo);
				ewalletMap.put("ewalletExcclcTyCode", excclcTyCode); // 이월렛 정산 유형 코드
				ewalletMap.put("orderNo", vo.getOrderNo());
				ewalletMap.put("canclExchngRtngudNo", vo.getCanclExchngRtngudNo());
				log.debug("ewallet request = "+ ewalletMap.toString());

				Map<String, Object> ewalletResMap = httpClientHelper.postCallApi(orProperty.getEwalletOrderUrl(), ewalletMap);
				log.debug("ewallet response = " + ewalletResMap.toString());

				// 이월렛 성공건만 객체에 담는다
				if (null != ewalletResMap && StringUtils.equals("200", ewalletResMap.get("resultCode").toString())) {
					/** 2021.12.10 라이브, 고정가 구분 없이 체크 */
					boolean isSuccess = false;
					Map<String, Object> resultData = (Map<String, Object>) ewalletResMap.get("data");
					String delngSeqNo = String.valueOf(resultData.get("delngSeqNo"));

					// 이월렛 서버에서 결재테이블 정상 성공으로 업데이트 되었는지 체크 현재 5초 설정 (2021.12.21 60초로 변경)
					for (int i = 0; i < orProperty.getEwalletTimeoutsec() * 2; i++) {
						Thread.sleep(500);
						//호출 건 응답 코드 확인
						String rspnsCode = claimMapper.selectEwalletRspnCode(delngSeqNo);
						log.debug(">> rspnsCode : " + rspnsCode);
						if(!StringUtils.isEmpty(rspnsCode)) {
							//응답 코드가 000 일때 거래 완료 -> 전문설계서 응답코드 확인
							if(StringUtils.equals(rspnsCode, "000")) {
								isSuccess = true;
							}
							log.debug(">> rspnsCode : " + rspnsCode + ", isSuccess : " + isSuccess);
							break;
						}
					} // end for

					log.debug(">> finally isSuccess : " + isSuccess);
					if(!isSuccess) {
						throw new Exception("이월렛 주문 실패");
					} else {
						listEwalletComple.add(orSetleBasVo);
					}
				} else {
					throw new Exception("이월렛 호출 실패");
				}
			} catch (Exception e) {
				log.error("callEwallet error : " + e);
//				vo.setClaimFailrResn("callEwallet error : " + e.getMessage());
//				vo.setCanclExchngRtngudSttusCode(""); // TODO 이월렛 실패코드 필요
//				claimMapper.updateFailClaim(vo);
//				claimMapper.insertComplateClaimHst(vo);
			}
		} // end for

		log.debug("::: callEwallet END");

		return listEwalletComple;
	}

	private void callTaxBill(List<OrSetleBasVO> listEwalletComple) {
		log.debug("::callTaxBill START");

		if (CollectionUtils.isEmpty(listEwalletComple)) {
			log.debug("listEwalletComple size is 0");
			return;
		}

		for (OrSetleBasVO vo : listEwalletComple) {
			ClaimBasVO claimVo = new ClaimBasVO();
			claimVo.setOrderNo(vo.getOrderNo());
			claimVo.setCanclExchngRtngudNo(vo.getCanclExchngRtngudNo());

			try {
				String jobSe = null;

				// 클레임 구분
				if (StringUtils.equals(ClaimConstants.CLAIM_TY_CODE_CANCEL, vo.getCanclExchngRtngudTyCode())) {
					jobSe = ClaimConstants.JOB_SE_CODE_CANCL;
				} else if (StringUtils.equals(ClaimConstants.CLAIM_TY_CODE_RETURN, vo.getCanclExchngRtngudTyCode())) {
					jobSe = ClaimConstants.JOB_SE_CODE_RTNGUD;
				} else if (StringUtils.equals(ClaimConstants.CLAIM_TY_CODE_EXCHANGE, vo.getCanclExchngRtngudTyCode())) {
					// TODO 교환은 입교, 출고 분기 필요??
					jobSe = ClaimConstants.JOB_SE_CODE_EXCHNG;
				} else {
					throw new Exception("클레임 구분 확인 필요");
				}

				Map<String, Object> taxbillReqMap = new HashMap<String, Object>();
				taxbillReqMap.put("orderNo", vo.getOrderNo());
				taxbillReqMap.put("canclExchngRtngudNo", vo.getCanclExchngRtngudNo());
				taxbillReqMap.put("jobSe", jobSe);
				log.debug("taxbill request = "+ taxbillReqMap.toString());

				Map<String, Object> taxbillResMap = httpClientHelper.postCallApi(orProperty.getTaxbillUrl(), taxbillReqMap);
				log.debug("taxbill response = "+ taxbillResMap.toString());

				// 세금계산서 호출까지 완료된 건만 완료 처리
				if (null != taxbillResMap && StringUtils.equals("Success", taxbillResMap.get("responseMessage").toString())) {
					claimMapper.updateComplateClaim(claimVo);
					claimMapper.insertOrCanclExchngRtngudBasHst(claimVo);
				} else {
					throw new Exception("세금계산서 호출 실패");
				}

			} catch (Exception e) {
				log.error("callTaxBill error : " + e);
//				claimVo.setClaimFailrResn("callTaxBill error : " + e.getMessage());
//				claimVo.setCanclExchngRtngudSttusCode(""); // TODO 세금계산서 실패코드 필요
//				claimMapper.updateFailClaim(claimVo);
			}
		}// end for

		log.debug("::callTaxBill END");
	}

	/**
	 * 주문_취소 교환 반품 기본 테이블의 취소 교환 반품 번호를 채번한다.
	 */
	@Override
	public synchronized String getNewClaimNo() throws Exception {

		String nowYear = DateUtil.getNowDateTime("yyyy");

		String newCanclExchngRtngudNo = DateUtil.getNowDateTime("yyyyMMdd")
										+ "-C"
										+ assignService.selectAssignValue("OR","CANCL_EXCHNG_RTNGUD_NO", nowYear, orRegisterId, 5);

		return newCanclExchngRtngudNo; // 신규 클레임 번호
	}

	/**
	 * 주문_주문 선물 기본 테이블의 선물 요청 주문 번호를 채번한다.
	 */
	@Override
	public synchronized String getNewOrderFtrsNo() throws Exception {

			String newFtrsRequstOrderNo = DateUtil.getNowDateTime("yyyyMMdd")
										+ "-1" + assignService.selectAssignValue("OR", "FTRS_REQUST_ORDER_NO", DateUtil.getNowDate(), orRegisterId, 10);
		return newFtrsRequstOrderNo;
	}

	/**
	 * 문_주문 선물환 기본 테이블의 선물환 요청 주문 번호를 채번한다.
	 */
	@Override
	public synchronized String getNewOrderFshgNo() throws Exception {

		String newOrderFshgNo = DateUtil.getNowDateTime("yyyyMMdd")
										+ "-2" + assignService.selectAssignValue("OR", "FSHG_REQUST_ORDER_NO", DateUtil.getNowDate(), orRegisterId, 10);

		return newOrderFshgNo;
	}

	/**
	 * 주문_결제 기본 테이블의 결제번호를 채번한다.
	 */
	@Override
	public synchronized String getNewOrderSetleNo() throws Exception {
		String newOrderSetleNo = DateUtil.getNowDateTime("yyyyMMdd")
										+ "-" + assignService.selectAssignValue("OR", "SETLE_NO", DateUtil.getNowDate(), orRegisterId, 5);

		return newOrderSetleNo;
	}
}
