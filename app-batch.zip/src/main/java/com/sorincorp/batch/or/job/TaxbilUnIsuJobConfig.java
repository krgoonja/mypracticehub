package com.sorincorp.batch.or.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * ERP생성 오류 건 메일 알림 서비스 (세금계산서)  JobConfig
 * TaxbilUnIsuJobConfig.java
 * @version
 * @since 2023. 12. 18.
 * @author sein
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class TaxbilUnIsuJobConfig {
	
	@Autowired
	TaxbilUnIsuTasklet taxbilUnIsuTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory; 
	
	@Bean
	public Job taxbilUnIsuJob() {
		return jobBuilderFactory.get("taxbilUnIsuJob")
				.start(taxbilUnIsuStep())
				.build();  
	}//end TaxbilUnIsuJobConfig()
	
	@Bean
	@JobScope
	public Step taxbilUnIsuStep() {
		return stepBuilderFactory.get("taxbilUnIsuStep")
				.tasklet(taxbilUnIsuTasklet)
				.build();
	}//end taxbilUnIsuStep()
	
}//end class()