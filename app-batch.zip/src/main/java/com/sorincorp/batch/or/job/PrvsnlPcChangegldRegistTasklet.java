package com.sorincorp.batch.or.job;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.or.service.PrvsnlPcChangegldRegistService;

import lombok.extern.slf4j.Slf4j;

/**
 * PrvsnlPcChangegldRegistTasklet.java
 * 가단가 가격 변동금 등록 배치(Tasklet 방식) 실행
 * 
 * @version
 * @since 2024. 10. 28.
 * @author srec0049
 */
@Slf4j
@Component
public class PrvsnlPcChangegldRegistTasklet implements Tasklet, StepExecutionListener {

	/**
	 * 가단가 가격 변동금 등록 배치 관련 Service
	 */
	@Autowired
	PrvsnlPcChangegldRegistService prvsnlPcChangegldRegistService;
	
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.info(">> beforeStep getStepName : " + stepExecution.toString());
	}
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		log.info(">> execute chunkContext getJobParameters : " + chunkContext.getStepContext().getStepExecution().getJobParameters());
		
		/**
		 * 파라미터 받아서 map으로 변환한다.
		 * 
		 * 테스트 시 파라미터 넣고 사용 가능 (각각 따로 넣어도 됨)
		 *   1. pOrderNo : 주문번호
		 *   2. pOccrrncDe : 발생일자 (익일 주문 대상 배치임으로 주문일자 다음날부터 배치 생성 가능)
		 *   3. pEvlAmount : 평가금액(시초가)
		 *   ex) pOrderNo=20241025-S01825,pOccrrncDe=20241028,pEvlAmount=3713000
		 */
		JobParameters jobParameters = chunkContext.getStepContext().getStepExecution().getJobParameters();
		Map<String, JobParameter> jobParamMap = jobParameters.getParameters();
		JobParameter param = jobParamMap.get("param01");
		log.info(">> execute param : " + String.valueOf(param));
		
		Map<String, String> map = new HashMap<String, String>();
		
		if(param != null) {
			String[] paramSplit = String.valueOf(param).split(",");
			for(String paramStr : paramSplit) {
				String[] keyValue = paramStr.split("=");
		        map.put(keyValue[0], keyValue[1]);
		        
		        log.info(">> value type : " + keyValue[1].getClass().getName());
			}
		}
		
		log.info(">> execute map : " + map.toString());
		
		// 가단가 가격 변동금 등록 배치 수행
		prvsnlPcChangegldRegistService.insertPrvsnlPcChangegld(map);
		
		return RepeatStatus.FINISHED;
	}
	
	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		
		log.info(">> afterStep getStepName : " + stepExecution.toString());
		
		return ExitStatus.COMPLETED;
	}
}
