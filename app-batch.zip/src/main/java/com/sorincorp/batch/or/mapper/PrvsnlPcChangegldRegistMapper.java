package com.sorincorp.batch.or.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.batch.or.model.OrPcChangegldBasVO;
import com.sorincorp.batch.or.model.PrvsnlPcChangegldInfoVO;

/**
 * PrvsnlPcChangegldRegistMapper.java
 * 가단가 가격 변동금 등록 배치 관련 Mapper 인터페이스
 * 
 * @version
 * @since 2024. 10. 31.
 * @author srec0049
 */
public interface PrvsnlPcChangegldRegistMapper {

	/**
	 * <pre>
	 * 처리내용: 가단가 가격 변동금 등록 대상 리스트 가져오기
	 * </pre>
	 * @date 2024. 10. 31.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 31.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param prvsnlPcChangegldInfoVO
	 * @return
	 * @throws Exception
	 */
	List<PrvsnlPcChangegldInfoVO> selectPrvsnlPcChangegldRegistTargetList(PrvsnlPcChangegldInfoVO prvsnlPcChangegldInfoVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 마지막 가격 변동금 정보 가져오기
	 * </pre>
	 * @date 2024. 11. 11.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 11.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param infoVO
	 * @return
	 * @throws Exception
	 */
	OrPcChangegldBasVO selectLastPcChangegldInfo(PrvsnlPcChangegldInfoVO infoVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 해당 가단가 가격 변동금 정보 수정 (주문_가격 변동금 기본 테이블)
	 * </pre>
	 * @date 2024. 11. 12.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 12.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orPcChangegldBasVO
	 * @throws Exception
	 */
	void updateOrPcChangegldBasByPrvsnl(OrPcChangegldBasVO orPcChangegldBasVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 가격 변동금 정보 등록 (주문_가격 변동금 기본 테이블)
	 * </pre>
	 * @date 2024. 11. 12.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 12.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orPcChangegldBasVO
	 * @throws Exception
	 */
	void insertOrPcChangegldBasByPrvsnl(OrPcChangegldBasVO orPcChangegldBasVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 가격 변동금 내역 회원_업체 담보 한도 상세 등록
	 * </pre>
	 * @date 2024. 11. 12.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 12.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orPcChangegldBasVO
	 * @throws Exception
	 */
	void insertLastMbEntrpsMrtggLmtDtl(OrPcChangegldBasVO orPcChangegldBasVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 가단가 구매 변동금 추가/환불 SMS 내용 정보 가져오기
	 * </pre>
	 * @date 2024. 11. 20.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 20.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orPcChangegldBasVO
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectPrvsnlPcChangegldSmsInfo(OrPcChangegldBasVO orPcChangegldBasVO) throws Exception;
}
