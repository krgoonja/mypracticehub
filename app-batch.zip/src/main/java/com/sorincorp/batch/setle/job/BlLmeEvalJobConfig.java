package com.sorincorp.batch.setle.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class BlLmeEvalJobConfig {

	@Autowired
	BlLmeEvalJobTasklet blLmeEvalJobTasklet;

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job blLmeEvalJob() {
		return jobBuilderFactory.get("blLmeEvalJob")
				.start(blLmeEvalStep())
				.build();
	}

	@Bean
	@JobScope
	public Step blLmeEvalStep() {
		return stepBuilderFactory.get("blLmeEvalStep")
				.tasklet(blLmeEvalJobTasklet)
				.build();
	}
	
}
