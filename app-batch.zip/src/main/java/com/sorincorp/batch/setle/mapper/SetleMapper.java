package com.sorincorp.batch.setle.mapper;

import java.util.List;

import com.sorincorp.batch.setle.model.MetalVO;
import com.sorincorp.batch.setle.model.PpsVO;
import com.sorincorp.batch.setle.model.SetleVO;

public interface SetleMapper {

	/**
	 * 글을 조회한다.
	 * 
	 * @param vo - 조회할 정보가 담긴 MetalVO
	 * @return 조회한 글
	 * @exception Exception
	 */
	//List<MetalVO> selectMetalList() throws Exception;

	/**
	 * 글을 조회한다.
	 * 
	 * @param vo - 조회할 정보가 담긴 PpsVO
	 * @return 조회한 글
	 * @exception Exception
	 */
	//List<PpsVO> selectPpsList() throws Exception;

	/**
	 * 글을 등록한다.
	 * 
	 * @param vo - 등록할 정보가 담긴 SampleVO
	 * @return 등록 결과
	 * @exception Exception
	 */
	void insertCrawlingTx(SetleVO vo) throws Exception;

	Integer selectPpsMms(String logTableDt) throws Exception;
	
	/**
	 * 조달청 크롤링 공통코드 조회
	 * 
	 * @param 
	 * @return
	 * @exception 
	 */
	List<PpsVO> selectRvcmpnList() throws Exception;
	
	/**
	 * 조달청 가격 리스트 조회 (중복확인)
	 * 
	 * @param 
	 * @return
	 * @exception 	
	 */
	int getRvcmpnPcList() throws Exception;
	
	/**
	 * 조달청 공통코드 등록개수 확인
	 * 
	 * @param 
	 * @return
	 * @exception 	
	 */
	int getCommCdCnt() throws Exception;

}
