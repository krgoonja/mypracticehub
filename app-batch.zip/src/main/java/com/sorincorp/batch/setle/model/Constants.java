package com.sorincorp.batch.setle.model;

public class Constants {
	
	/**
	 *  MetalCode
	 **/
	
	public static final String METALCODE_ZN = "1";		//아연
	public static final String METALCODE_PB = "2";		//납	
	public static final String METALCODE_CU = "5";		//구리
	public static final String METALCODE_AL = "7";		//알루미늄
	public static final String METALCODE_NI = "8";		//니켈
	public static final String METALCODE_SN = "9";		//주석
	public static final String METALCODE_TS = "98989";	//탄산리튬
	
	public static final String METALCODE_PS = "98989";	//
	
	/**
	 * BrandGroupCode 
	 **/
	public static final String BRAND_GROUP_CODE_ALS 		= "01"; //알루미늄(서구산)
	public static final String BRAND_GROUP_CODE_ALBS 		= "02"; //알루미늄(비서구산)
	public static final String BRAND_GROUP_CODE_ZN 			= "31"; //아연
	public static final String BRAND_GROUP_CODE_CU9999		= "11"; //구리99.99이상
//	public static final String BRAND_GROUP_CODE_PB			= "21"; //납99.99이상
	public static final String BRAND_GROUP_CODE_PBI			= "21"; //납99.99이상(인천, 대구)
	public static final String BRAND_GROUP_CODE_PBB			= "22"; //납99.99이상(부산, 전북)
	public static final String BRAND_GROUP_CODE_SN9985		= "41"; //주석99.85
	public static final String BRAND_GROUP_CODE_SN9990		= "42"; //주석99.90
	public static final String BRAND_GROUP_CODE_NIH 		= "51"; //니켈합금용
	public static final String BRAND_GROUP_CODE_NID			= "52"; //니켈도금용
	public static final String BRAND_GROUP_CODE_TS			= "98989"; //탄산리튬
	
	public static final String BRAND_GROUP_CODE_PS75		= "98989"; //니켈도금용
	
	
	/**
	 * STS Converting
	 */
	public static final String STS_METAL_CODE_CO		= "R_CBD";
	public static final String STS_METAL_CODE_COMMON	= "R_M";
	
	public static final String STS_LME_NAME_CO			= "CBD0";
	public static final String STS_LME_NAME_COMMON		= "M";
	
	/**
	 * 
	 * FTP Connect Info(Picture Upload)
	 * 
	 */
	
	public static final String sServer 		= "";
	public static final String iPort 		= "";
	public static final String sId 			= "";
	public static final String sPassword 	= "";
	
	public static final String sUpDir 		= "";
	public static final String sDownDir 	= "";
	public static final String sLogDir 		= "";
	
	public static final String IMG_FTP_UPLOAD_URL = "";
	
}
