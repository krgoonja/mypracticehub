package com.sorincorp.batch.setle.service;


public interface SetleService {

	void getCrawlingData() throws Exception ;
}
