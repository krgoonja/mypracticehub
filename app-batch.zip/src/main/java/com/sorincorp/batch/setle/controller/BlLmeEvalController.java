package com.sorincorp.batch.setle.controller;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sorincorp.batch.setle.service.BlLmeEvalService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Controller
public class BlLmeEvalController {
	
	@Autowired
	private BlLmeEvalService blLmeEvalService;
	
	
	/**
	 * BL기준으로 LME Evaluation 가격을 가져온다
	 * @param model
	 * @return 
	 * @exception Exception
	 */
	@RequestMapping({ "/setBlLmeEval.do" })
	public ModelAndView setBlLmeEval(Map<String, Object> commandMap, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ModelAndView mav = new ModelAndView("home");
		
		try {
			blLmeEvalService.setBlLmeEval();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return mav;
	}
}
