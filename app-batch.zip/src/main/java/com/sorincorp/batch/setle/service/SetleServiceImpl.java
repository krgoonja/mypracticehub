package com.sorincorp.batch.setle.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.setle.mapper.SetleMapper;
import com.sorincorp.batch.setle.model.PpsVO;
import com.sorincorp.batch.setle.model.SetleVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.message.service.SMSService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SetleServiceImpl<E> implements SetleService {

	@Autowired
	private SMSService smsService;

	@Autowired
	private SetleMapper setleMapper;

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Value("${order.api.lme.rvcmpnPc.url}")
	private String apiDomain;

	/** 공통 코드 서비스 */
	@Autowired
	private CommonCodeService commonCodeService;

	@Override
	public void getCrawlingData() throws Exception {
		SetleVO vo = new SetleVO();

		List<PpsVO> metalListForSms = new ArrayList<PpsVO>();
		List<PpsVO> rvcmpnList = new ArrayList<PpsVO>();
		rvcmpnList = setleMapper.selectRvcmpnList(); //조달청 크롤링 공통코드 조회

		int rvcmpnPcCount = setleMapper.getRvcmpnPcList();

		String URL = "https://www.pps.go.kr/bichuk/index.do";
		Document doc = null;

		try {
			setSSL();
			doc = Jsoup.connect(URL).get();
		} catch (IOException e) {
			e.printStackTrace();
		}

		Elements str = doc.getElementsByClass("con_box2");
		Elements name = str.select("tbody");
		Elements names = name.select("tr");

		String tempTxt = "";
		int pcInsertCnt = 0;

		if(rvcmpnPcCount == 0) {				//테이블에 오늘자 데이터가 없을때만 INSERT
			for (Element tr : names) {
				String th = tr.select("th").text();
				String td = tr.getElementsByClass("ta-l").get(1).text();
				//String column = th+td;			//품명+판매지방청
				String itemName = th;			//조달청 품명
				String itemCity = td;			//조달청 판매지방청

				Elements columnsTd = tr.select("td");

				for(PpsVO ppsvo : rvcmpnList) {
					//String codeNm = ppsvo.getCodeNm() + ppsvo.getCodeRefrnone();
					String codeName = ppsvo.getCodeNm(); //공통코드 품명
					String codeCity = ppsvo.getCodeRefrnone();//공통코드 판매지방청

					itemCity = itemCity.replaceAll("\\s+", "");//조달청 판매지방청 공백제거
					//codeNm = codeNm.replaceAll(".*\\)", "");// ")"포함 앞부분 제거
					String[] cities = codeCity.split("/");//공통코드 판매지방청 배열저장

					if(codeName.equals(itemName)){ // 조달청, 공통코드 품명이 일치할 경우
						for (String city : cities) {
							if (itemCity.contains(city)) {	// 조달청 판매지방청 중 공통코드에 해당하는 판매지방청 하나라도 있을 경우 insert
								tempTxt = ppsvo.getSubCode();
								vo.setMetalCode(tempTxt.substring(0,1));			//메탈코드 저장
								vo.setBrandGroupCode(tempTxt.substring(1,3));		//브랜드 그룹 저장
								vo.setDeleteAt("N");

								for(int i=0; i<columnsTd.size(); i++){
									System.out.println(columnsTd.get(1).text() + columnsTd.get(3).text());
									vo.setSellPrice(columnsTd.get(1).text().replace(",", "").replace("원/톤", ""));	// 판매가격 저장
									vo.setApplcDe(columnsTd.get(3).text().replace(".", ""));						// 날짜 . 기호 제거
								}

								if(!vo.getMetalCode().isEmpty() && !vo.getMetalCode().isEmpty()) {
									setleMapper.insertCrawlingTx(vo);
									pcInsertCnt++;
								}
								break;
							}
						}
					}
//					if (codeNm.equals(column)) {		//품명+판매지방청 공통코드와 비교
//						tempTxt = ppsvo.getSubCode();
//						vo.setMetalCode(tempTxt.substring(0,1));			//메탈코드 저장
//						vo.setBrandGroupCode(tempTxt.substring(1,3));		//브랜드 그룹 저장
//						vo.setDeleteAt("N");
//
//						for(int i=0; i<columnsTd.size(); i++){
//							System.out.println(columnsTd.get(1).text() + columnsTd.get(3).text());
//							vo.setSellPrice(columnsTd.get(1).text().replace(",", "").replace("원/톤", ""));	// 판매가격 저장
//							vo.setApplcDe(columnsTd.get(3).text().replace(".", ""));						// 날짜 . 기호 제거
//						}
//
//						if(!vo.getMetalCode().isEmpty() && !vo.getMetalCode().isEmpty()) {
//							setleMapper.insertCrawlingTx(vo);
//							pcInsertCnt++;
//						}
//					}
				}
			}
		}

		lmeRvcmpnPcInit();

		SimpleDateFormat sdf02 = new SimpleDateFormat("yyyyMM");
		Calendar c1 = Calendar.getInstance();
		String logTableDt = sdf02.format(c1.getTime());

		if(pcInsertCnt > setleMapper.getCommCdCnt() && setleMapper.selectPpsMms(logTableDt) == 0) {
			callSms(metalListForSms);
		}

//		if (!metalListForSms.isEmpty() && vo.getApplcDe().equals(strToday)) {
//			if (setleMapper.selectPpsMms(logTableDt) == 0) {
//				callSms(metalListForSms);
//			}
//		}
	}

	/**
	 * <pre>
	 * 처리내용: 조달청 가격 받아오면 해당 가격으로 LME 변수 초기화
	 * </pre>
	 * @date 2023. 6. 8.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 6. 8.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @throws Exception
	 */
	private void lmeRvcmpnPcInit() throws Exception {
		Map<String, Object> resObj = null;
		try {
			// 영업 관리 등록 및 수정 api
			resObj = httpClientHelper.postCallApi(apiDomain, null);

			if (resObj.isEmpty()) {
				throw new Exception("통신장애");
			}
		} catch (Exception e) {
			log.error("LME 조달청 가격 초기화 api resObj :::  + resObj");
			log.error("LME 조달청 가격 API 실패 ===> ", e.getMessage());
			// 추가
		}
	}

	//	@Scheduled( cron="0 */5 9-11 * * *" ) //9-11 시 5분마다
	public void CrawlingScheduler() throws Exception {
		BufferedReader in = null;
		try {
			URL obj = new URL("http://localhost:52003/crawlingmain.do");
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("GET");
			in = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (in != null)
				try {
					in.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
	}

	private synchronized void callSms(List<PpsVO> metalListForSms) {
		try {
			log.warn("[SetleServiceImpl][callSms] IN");
			procSms(metalListForSms, "83", null);
		} catch (Exception e) {
			log.warn("[SetleServiceImpl][callSms] ERROR" + e.getMessage());
		}
	}

	private void procSms(List<PpsVO> metalListForSms, String templateNum, String addStr) {
		try {
			log.warn("[SetleServiceImpl][procSms] IN");
			StringBuffer bf = new StringBuffer();
			Map<String, String> smsMap = null;
			smsMap = new HashMap<String, String>();
			String mssBf;

			for (PpsVO vo : metalListForSms) {
				bf.append(vo.getGoodsName() + ", ");
			}
			mssBf = StringUtils.removeEnd(bf.toString(), ", ");

			if (StringUtils.equals(templateNum, "83")) {
				smsMap.put("templateNum", templateNum);
				smsMap.put("metalList", mssBf);
				smsMap.put("commerceNtcnAt", "Y"); // 추가 수신사 커머스 알림 여부 따로 설정
				smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
				smsService.insertSMS(null, smsMap);
			}
		} catch (Exception e) {
			log.warn("[SetleServiceImpl][procSms] ERROR" + e.getMessage());
		}
	}

	public static void setSSL() throws NoSuchAlgorithmException, KeyManagementException {
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			@Override
			public X509Certificate[] getAcceptedIssuers() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				// TODO Auto-generated method stub

			}

			@Override
			public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				// TODO Auto-generated method stub
			}
		} };
		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, new SecureRandom());
		HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {

			@Override
			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		});
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	}

}
