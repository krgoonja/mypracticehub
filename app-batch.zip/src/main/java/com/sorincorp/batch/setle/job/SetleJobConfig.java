package com.sorincorp.batch.setle.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class SetleJobConfig {

	@Autowired
	SetleJobTasklet setleJobTasklet;

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job setleJob() {
		return jobBuilderFactory.get("setleJob")
				.start(setleStep())
				.build();
	}

	@Bean
	@JobScope
	public Step setleStep() {
		return stepBuilderFactory.get("setleStep")
				.tasklet(setleJobTasklet)
				.build();
	}
	
}
