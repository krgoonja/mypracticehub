package com.sorincorp.batch.setle.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.setle.mapper.BlLmeEvalMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BlLmeEvalServiceImpl<E> implements BlLmeEvalService {

	@Autowired
	private BlLmeEvalMapper blLmeEvalMapper;

	@Override
	public void setBlLmeEval() throws Exception {
		
		blLmeEvalMapper.setBlLmeEval(); //평가 데이터를 저장한다.
		
	}
}
