package com.sorincorp.batch.setle.model;

import org.springframework.validation.annotation.Validated;

import lombok.Data;

@Data
@Validated
public class PpsVO {

	/******  JAVA VO CREATE : IT_RVCMPN_MANAGE_BAS()                                                                                         ******/

    /**
     * 
    */
    private int idx;


    /**
     * 금속 코드
    */
    private String metalCode;


    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;


    /**
     * 상품코드
    */
    private String goodsCode;


    /**
     * 상품명
    */
    private String goodsName;


    /**
     * 판매지방청
    */
    private String seller;


    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;


    /**
     * 삭제 여부
    */
    private String deleteAt;


    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;


    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;


    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;


    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;

	
    //공통코드 컬럼
    
    /**
     * 서브 코드
    */
    private String subCode;
    
    /**
     * 코드 명
     */
    private String codeNm;
    
    /**
     * 코드 참조1
     */
    private String codeRefrnone;
    
    /**
     * 코드 문자 참조6
     */
    private String codeChrctrRefrnsix;
	
}
