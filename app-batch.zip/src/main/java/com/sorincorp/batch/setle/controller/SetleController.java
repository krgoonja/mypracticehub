package com.sorincorp.batch.setle.controller;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sorincorp.batch.setle.service.SetleService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Controller
public class SetleController {
	
	@Autowired
	private SetleService setleService;
	
	
	/**
	 * 조달청 금속 가격을 가져온다
	 * @param sampleVO - 조회할 정보가 담긴 SampleVO
	 * @param model
	 * @return "sampleList"
	 * @exception Exception
	 */
	@RequestMapping({ "/crawlingmain.do" })
	public ModelAndView CrawlingMain(Map<String, Object> commandMap, HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		ModelAndView mav = new ModelAndView("home");
		try {
			setleService.getCrawlingData();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return mav;
	}
}
