package com.sorincorp.batch.setle.model;

import org.springframework.validation.annotation.Validated;

import lombok.Data;

@Data
@Validated
public class MetalVO {

	/******  
	 * JAVA VO CREATE : CO_CMMN_CD()
	 ******/
    
    /**
     * 서브 코드
    */
    private String subCode;
    
    /**
     * 코드 명
     */
    private String codeNm;
    
    /**
     * 코드 문자 참조6
     */
    private String codeChrctrRefrnsix;
    
    
}
