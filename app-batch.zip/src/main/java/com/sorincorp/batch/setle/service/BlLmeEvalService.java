package com.sorincorp.batch.setle.service;


public interface BlLmeEvalService {

	void setBlLmeEval() throws Exception;
}
