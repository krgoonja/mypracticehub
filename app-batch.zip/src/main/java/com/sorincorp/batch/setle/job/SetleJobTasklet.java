package com.sorincorp.batch.setle.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.entrps.service.EntrpsNoRefndService;
import com.sorincorp.batch.setle.controller.SetleController;
import com.sorincorp.batch.setle.service.SetleService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SetleJobTasklet implements Tasklet, StepExecutionListener {

	@Autowired
//	EntrpsNoRefndService entrpsNoRefndService;
//	SetleController setleController;
	SetleService setleService;
	
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("setleJobTasklet beforeStep method");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("setleJobTasklet execute method");
		setleService.getCrawlingData();

		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("setleJobTasklet afterStep method");
		return ExitStatus.COMPLETED;
	}

}
