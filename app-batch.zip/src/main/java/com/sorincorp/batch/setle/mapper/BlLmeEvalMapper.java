package com.sorincorp.batch.setle.mapper;

public interface BlLmeEvalMapper {
	/**
	 * 평가 데이터를 등록한다.
	 * 
	 * @param
	 * @return
	 * @exception Exception
	 */
	int setBlLmeEval() throws Exception;
}
