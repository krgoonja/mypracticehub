package com.sorincorp.batch.ehr.job.com;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class EhrComJobConfig {

	@Autowired
	private EhrComTasklet ehrComTasklet;
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Bean
	public Job ehrComJob() {
		return jobBuilderFactory.get("ehrComJob")
				.start(ehrComStep())
				.build();
	}
	
	@Bean
	@JobScope
	public Step ehrComStep() {
		return stepBuilderFactory.get("ehrComStep")
				.tasklet(ehrComTasklet)
				.build();
	}
}
