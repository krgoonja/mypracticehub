package com.sorincorp.batch.ehr.job.dept;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.ehr.model.EhrVO;
import com.sorincorp.batch.ehr.service.EhrService;
import com.sorincorp.batch.or.job.TaxBillRecptnTasklet;
import com.sorincorp.batch.or.service.TaxBillRecptnService;
import com.sorincorp.comm.btb.comm.BtoBConstants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class EhrDeptTasklet implements Tasklet, StepExecutionListener {
	
	@Value("${batch.job.dept}")
	private String interfaceId;
	
	@Autowired
	private EhrService ehrService;
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("EhrDeptTasklet::execute Start");
		
		EhrVO ehrVo = new EhrVO();
		ehrVo.setTargetSys(BtoBConstants.BTB_EHR_SYSTEM);
		ehrVo.setInterfaceId(interfaceId);
		ehrService.updateDept(ehrVo);
		
		log.debug("EhrDeptTasklet::execute End");
		return RepeatStatus.FINISHED;
	}
	
	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("EhrDeptTasklet::afterStep");
		return ExitStatus.COMPLETED;
	}

}
