package com.sorincorp.batch.ehr.model;

import com.sorincorp.batch.comm.model.BatchBaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@ApiModel("EHR 호출 VO")
public class EhrVO extends BatchBaseVO{
	
	/* 호출 TARGET SYSTEM */
	@ApiModelProperty(value = "타겟 시스템", example = "EHR")
	private String targetSys;
	
}
