package com.sorincorp.batch.ehr.job.duty;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class EhrDutyJobConfig {

	@Autowired
	private EhrDutyTasklet ehrDutyTasklet;
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Bean
	public Job ehrDutyJob() {
		return jobBuilderFactory.get("ehrDutyJob")
				.start(ehrDutyStep())
				.build();
	}
	
	@Bean
	@JobScope
	public Step ehrDutyStep() {
		return stepBuilderFactory.get("ehrDutyStep")
				.tasklet(ehrDutyTasklet)
				.build();
	}
}
