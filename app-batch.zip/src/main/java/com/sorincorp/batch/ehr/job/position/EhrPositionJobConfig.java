package com.sorincorp.batch.ehr.job.position;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class EhrPositionJobConfig {

	@Autowired
	private EhrPositionTasklet ehrPositionTasklet;
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Bean
	public Job ehrPositionJob() {
		return jobBuilderFactory.get("ehrPositionJob")
				.start(ehrPositionStep())
				.build();
	}
	
	@Bean
	@JobScope
	public Step ehrPositionStep() {
		return stepBuilderFactory.get("ehrPositionStep")
				.tasklet(ehrPositionTasklet)
				.build();
	}
}
