package com.sorincorp.batch.ehr.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.ehr.model.EhrVO;
import com.sorincorp.comm.btb.comm.BtoBConstants;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.btb.model.BtoBReqEntity;
import com.sorincorp.comm.btb.model.BtoBResEntity;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EhrServiceImpl implements EhrService{

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Value("${batch.api.uri}")
	private String baseUri;

	@Value("${batch.api.com}")
	private String com;

	@Value("${batch.api.bu}")
	private String bu;

	@Value("${batch.api.dept}")
	private String dept;

	@Value("${batch.api.second}")
	private String second;

	@Value("${batch.api.duty}")
	private String duty;

	@Value("${batch.api.position}")
	private String position;

	@Value("${batch.api.rank}")
	private String rank;

	@Value("${batch.api.emp}")
	private String emp;

	@Override
	public BtoBResEntity sampleCall(EhrVO reqEntity) throws Exception {
		BtoBReqEntity sampleEntity = new BtoBReqEntity();

		/* 타겟 시스텡 Setting ( EHR만 필수 )*/
		sampleEntity.setTargetSys(BtoBConstants.BTB_EHR_SYSTEM);

		/* 인터페이스 ID Setting */
		sampleEntity.setInterfaceId(reqEntity.getInterfaceId());

		/* request Setting */
		Map<String, Object> sampleRequestMap = new HashMap<String, Object>();
		sampleRequestMap.put("price", 10000);
		sampleEntity.setRequest(sampleRequestMap);

		/* 호출 */
		BtoBResEntity resEntity = httpClientHelper.callApi(sampleEntity);

		if(!StringUtils.equals(resEntity.getResultcode(), BtoBConstants.BTOB_CNI_SUCCESS_CODE)) {
			/* 에러 발생 */
		}

		/* 데이터 캐스팅 */
		Map<String, Object> response= (Map<String, Object>)resEntity.getResponse();

		return resEntity;
	}

	@Override
	public void updateCom(EhrVO ehrVo) throws Exception {
		String uri = this.baseUri + this.com;
		this.intrnlSysApiCall(ehrVo, uri);
	}

	@Override
	public void updateBU(EhrVO ehrVo) throws Exception {
		String uri = this.baseUri + this.bu;
		this.intrnlSysApiCall(ehrVo, uri);
	}

	@Override
	public void updateDept(EhrVO ehrVo) throws Exception {
		String uri = this.baseUri + this.dept;
		this.intrnlSysApiCall(ehrVo, uri);
	}

	@Override
	public void updateSecond(EhrVO ehrVo) throws Exception {
		String uri = this.baseUri + this.second;
		this.intrnlSysApiCall(ehrVo, uri);
	}

	@Override
	public void updateDuty(EhrVO ehrVo) throws Exception {
		String uri = this.baseUri + this.duty;
		this.intrnlSysApiCall(ehrVo, uri);
	}

	@Override
	public void updatePosition(EhrVO ehrVo) throws Exception {
		String uri = this.baseUri + this.position;
		this.intrnlSysApiCall(ehrVo, uri);
	}

	@Override
	public void updateRank(EhrVO ehrVo) throws Exception {
		String uri = this.baseUri + this.rank;
		this.intrnlSysApiCall(ehrVo, uri);
	}

	@Override
	public void updateEmp(EhrVO ehrVo) throws Exception {
		String uri = this.baseUri + this.emp;
		this.intrnlSysApiCall(ehrVo, uri);
	}

	@Override
	public void intrnlSysApiCall(EhrVO ehrVo, String uri) throws Exception {
		httpClientHelper.postCallApi(uri, ehrVo);
	}

}
