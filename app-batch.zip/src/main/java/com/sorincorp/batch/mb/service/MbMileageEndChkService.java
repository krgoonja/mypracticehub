package com.sorincorp.batch.mb.service;

import java.util.List;

import com.sorincorp.batch.mb.model.MbMileageMngVO;

public interface MbMileageEndChkService {

	public void mbMileageEndDateChk() throws Exception;

	public void delPrearngeMileageChk() throws Exception;

}
