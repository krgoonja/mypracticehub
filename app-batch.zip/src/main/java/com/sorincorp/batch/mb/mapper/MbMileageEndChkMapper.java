package com.sorincorp.batch.mb.mapper;

import java.util.List;

import com.sorincorp.batch.mb.model.MbMileageMngVO;

public interface MbMileageEndChkMapper {

	List<MbMileageMngVO> selectMbMileageEndList() throws Exception;

	List<MbMileageMngVO> selectMbMileageDelPrearngeList() throws Exception;

	int insertMbMileageMngList(MbMileageMngVO mbMileageMngVO) throws Exception;

	int updateMbMileageMngEndList(MbMileageMngVO mbMileageMngVO) throws Exception;

	int insertMbMileageMngListHst(MbMileageMngVO mbMileageMngVO) throws Exception;

	Integer selectRemndrMlg(MbMileageMngVO mbMileageMngVO) throws Exception;
}
