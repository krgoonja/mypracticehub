package com.sorincorp.batch.mb.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MbDrmncyMberVO {

	/******  JAVA VO CREATE : MB_MBER_INFO_BAS(회원_회원 정보 기본)          ******/
	    /**
	     * 회원 번호
	    */
	    private String mberNo;
	    /**
	     * 업체 번호
	    */
	    private String entrpsNo;
	    /**
	     * 회원 아이디
	    */
	    private String mberId;
	    /**
	     * 회원 비밀 번호
	    */
	    private String mberSecretNo;
	    /**
	     * 회원 가입 일시
	    */
	    private String mberEtrDt;
	    /**
	     * 회원 최근 방문 일시
	    */
	    private String mberRecentVisitDt;
	    /**
	     * 회원 승인 상태 코드
	    */
	    private String mberConfmSttusCode;
	    /**
	     * 회원 승인 처리 일시
	    */
	    private String mberConfmProcessDt;
	    /**
	     * 승인자 명
	    */
	    private String confmerNm;
	    /**
	     * 요청 사유
	    */
	    private String requstResn;
	    /**
	     * 승인 사유
	    */
	    private String confmResn;
	    /**
	     * 회원 이름
	    */
	    private String mberNm;
	    /**
	     * 휴대전화 번호
	    */
	    private String moblphonNo;
	    /**
	     * 전화 번호
	    */
	    private String tlphonNo;
	    /**
	     * 회원 이메일
	    */
	    private String mberEmail;
	    /**
	     * 이용 약관 동의 여부
	    */
	    private String useStplatAgreAt;
	    /**
	     * 이용 약관 동의 일시
	    */
	    private String useStplatAgreDt;
	    /**
	     * 전자 금융 거래 약관 동의 여부
	    */
	    private String elctrnFnncDelngStplatAgreAt;
	    /**
	     * 전자 금융 거래 약관 동의 일시
	    */
	    private String elctrnFnncDelngStplatAgreDt;
	    /**
	     * 개인 정보 처리 방침 동의 여부
	    */
	    private String indvdlInfoProcessPolcyAgreAt;
	    /**
	     * 개인 정보 처리 방침 동의 일시
	    */
	    private String indvdlInfoProcessPolcyAgreDt;
	    /**
	     * 개인 정보 수집 이용 동의 여부
	    */
	    private String indvdlInfoColctUseAgreAt;
	    /**
	     * 개인 정보 수집 이용 동의 일시
	    */
	    private String indvdlInfoColctUseAgreDt;
	    /**
	     * 회원 메일 수신 동의 여부
	    */
	    private String mberEmailRecptnAgreAt;
	    /**
	     * 회원 메일 수신 여부 일시
	    */
	    private String mberEmailRecptnAgreDt;
	    /**
	     * 회원 문자 수신 동의 여부
	    */
	    private String mberChrctrRecptnAgreAt;
	    /**
	     * 회원 문자 수신 동의 일시
	    */
	    private String mberChrctrRecptnAgreDt;
	    /**
	     * 뉴스레터 신청 여부
	    */
	    private String nsltReqstAt;
	    /**
	     * 뉴스레터 신청 일시
	    */
	    private String nsltReqstDt;
	    /**
	     * 본인 인증 여부
	    */
	    private String selfCrtfcAt;
	    /**
	     * 본인 인증 일시
	    */
	    private String selfCrtfcDt;
	    /**
	     * 로그인 실패 회수
	    */
	    private int loginFailrRtrvl;
	    /**
	     * 비밀 번호 오류 횟수
	    */
	    private int secretNoErrorCo;
	    /**
	     * 비밀 번호 수정 일시
	    */
	    private String secretNoUpdtDt;
	    /**
	     * 다음 비밀 번호 변경 일시
	    */
	    private String nextSecretNoChangeDt;
	    /**
	     * 최근 접속 일시
	    */
	    private String recentConectDt;
	    /**
	     * 회원 상태 코드
	    */
	    private String mberSttusCode;
	    /**
	     * 사용 구분 코드
	    */
	    private String useSeCode;
	    /**
	     * 회원 구분 코드
	    */
	    private String mberSeCode;
	    /**
	     * 권한 변경 동의 여부
	    */
	    private String authorChangeAgreAt;
	    /**
	     * 삭제 여부
	    */
	    private String deleteAt;
	    /**
	     * 삭제 일시
	    */
	    private String deleteDt;
	    /**
	     * 최초 등록자 아이디
	    */
	    private String frstRegisterId;
	    /**
	     * 최초 등록 일시
	    */
	    private String frstRegistDt;
	    /**
	     * 최종 변경자 아이디
	    */
	    private String lastChangerId;
	    /**
	     * 최종 변경 일시
	    */
	    private String lastChangeDt;
	    /**
	     * 요청 일시
	    */
	    private String requstDt;
	    /**
	     * 권한번호
	    */
	    private int authorNo;

	    /**
	     * 휴면 전환 예정일
	     */
	    private String drmncyDate;

	    /**
	     * 휴면 전환일
	     */
	    private String drmncyDt;

	    /**
	     * 보내는 날짜
	     */
	    private String sendDate;

}
