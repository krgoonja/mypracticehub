package com.sorincorp.batch.mb.model;

import lombok.Data;

@Data
public class MbMileageMngVO {
	/**
     * 마일리지 순번
    */
	private int mlgSn;
	/**
     * 업체 번호
    */
	private String entrpsNo;
	/**
     * 마일리지 거래 일시
    */
	private String mlgDelngDt;
	/**
     * 마일리지 만료 일자
    */
	private String mlgEndDe;
	/**
     * 마일리지 구분
    */
	private String mlgSe;
	/**
     * 마일리지 유형
    */
	private String mlgTy;
	/**
     * 마일리지 상세 내역
    */
	private String mlgDetailDtls;
	/**
     * 거래 마일리지
    */
	private int delngMlg;
	/**
     * 잔여 마일리지
    */
	private int remndrMlg;
	/**
     * 삭제 여부
    */
	private String deleteAt;
	/**
     * 삭제 일시
    */
	private String deleteDt;
	/**
     * 최초 등록자 아이디
    */
	private String frstRegisterId;
	/**
     * 최초 등록 일시
    */
	private String frstRegistDt;
	/**
     * 최종 변경자 아이디
    */
	private String lastChangerId;
	/**
     * 최종 변경 일시
    */
	private String lastChangeDt;
	/**
     * 주문 번호
    */
	private String orderNo;
	/**
     * 취소 교환 반품 번호
    */
	private String canclExchngRtngudNo;
	/**
     * 사용 마일리지
    */
	private int useMlg;
	/**
     * 소멸 마일리지
    */
	private int delMlg;
	/**
     * 소멸 예정 마일리지
    */
	private int delPrearngeMlg;
	/**
     * 소멸 여부
    */
	private String accmlExtshAt;
	/**
     * 소멸 여부
    */
	private String grntyNo;
	/**
     * 마일리지 만료 날짜 차이
    */
	private int mlgDateDiff;
	/**
     * 회원 아이디
    */
	private String mberId ;
	/**
     * 회원 전화번호
    */
	private String moblphonNo ;
	/**
     * 회원번호
    */
	private String mberNo ;
	/**
     * 회원번호
    */
	private String mberEmail ;
	/**
     * 회원이름
    */
	private String mberNm ;


}
