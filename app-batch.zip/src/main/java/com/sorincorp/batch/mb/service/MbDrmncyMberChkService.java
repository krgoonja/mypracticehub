/**
 *
 */
package com.sorincorp.batch.mb.service;

/**
 * EwalletUseConfmChkService.java
 * @version
 * @since 2021. 11. 19.
 * @author srec0009
 */
public interface MbDrmncyMberChkService {

	//휴면 전환 예정
	public void selectPreMbDrmncyMber() throws Exception;

	//휴면 전환
	public void selectMbDrmncyMber() throws Exception;
}
