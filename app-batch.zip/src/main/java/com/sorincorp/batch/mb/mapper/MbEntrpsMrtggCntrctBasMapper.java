package com.sorincorp.batch.mb.mapper;

import java.util.List;

import com.sorincorp.batch.mb.model.MbEntrpsMrtggCntrctBasVO;

public interface MbEntrpsMrtggCntrctBasMapper {

	List<MbEntrpsMrtggCntrctBasVO> selectIfKoditEntrpsProgrsSttusList() throws Exception;

	int insertMbEntrpsMrtggCntrctBas(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int insertMbEntrpsMrtggCntrctBasHst(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int selectMaxEntrpsMrtggSn(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int selectLastEntrpsMrtggSn(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int updateLastEntrpsMrtggSn(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int updateLastEntrpsMrtggSn2(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int updateLedgrReflctAt(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int selectLastEntrpsMrtggCnt(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	MbEntrpsMrtggCntrctBasVO selectIfKoditEntrpsInfo(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	List<MbEntrpsMrtggCntrctBasVO> selectMbEntrpsMrtggCntrctBasList() throws Exception;

	int selectEntrpsMrtggEndAtCnt(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	int selectEntrpsMrtggTerminationCnt(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	int selectEntrpsMrtggCndChgCnt(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	int updateEntrpsMrtggCntctBasLastCntrctAt(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	int insertMbEntrpsMbEntrpsMrtggLmtDtl(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int insertMbEntrpsMbEntrpsMrtggLmtDtlHst(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	long selectMrtggBlce(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	long selectGrntyAmount(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	List<MbEntrpsMrtggCntrctBasVO> selectMbEntrpsMrtggCntrctExpirationList() throws Exception;

	int insertMbEntrpsInfoBasHst(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	int updateMbEntrpsMbEntrpsMrtggEndAt(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	List<MbEntrpsMrtggCntrctBasVO> selectMbEntrpsMlgInfoDtlList(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	int insertMbEntrpsMlgInfoDtl(MbEntrpsMrtggCntrctBasVO mlgVO) throws Exception;

	int insertMbEntrpsMlgInfoDtlHst(MbEntrpsMrtggCntrctBasVO mlgVO) throws Exception;

	int selectRemndrMlgCnt(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	int selectRemndrMlg(MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO) throws Exception;

	double selectLastEntrpsMrtggSelngAchivrt(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int updateMbEntrpsMrtggGrntyTrmnatAt(MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO) throws Exception;

	int updateMbEntrpsMlgInfoDtl(MbEntrpsMrtggCntrctBasVO mlgVO) throws Exception;

}
