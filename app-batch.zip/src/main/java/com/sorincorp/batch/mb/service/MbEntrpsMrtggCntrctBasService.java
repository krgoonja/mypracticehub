package com.sorincorp.batch.mb.service;

public interface MbEntrpsMrtggCntrctBasService {

	public int insertMbEntrpsMrtggCntrctBas() throws Exception;

	public int updateEntrpsMrtggCntctBasLastCntrctAt() throws Exception;

	public int updateEntrpsMrtggCntctBasCntrctExpiration() throws Exception;
}
