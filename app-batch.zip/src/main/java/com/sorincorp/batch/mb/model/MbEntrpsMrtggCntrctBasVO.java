package com.sorincorp.batch.mb.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class MbEntrpsMrtggCntrctBasVO implements Serializable {

	private static final long serialVersionUID = -8948506016038693701L;

	private int intrfcSn;
	private String entrpsNm;
	private String bsnmRegistNo;
	private String cprRegistNo;
	private String grntyReqstNo;
	private String grntyNo;
	private String rceptDe;
	private long grntyReqstAmount;
	private String confmDe;
	private long confmAmount;
	private String grntyProgrsSttusCode;
	private String ledgrReflctAt;
	private String frstRegisterId;
	private String lastChangerId;

	private int cndChangeDetailSn;
	private String changeBfe;
	private String changeAfter;

	private String issuDe;
	private long grntyAmount;
	private String grntyTmlmtBeginDe;
	private String grntyTmlmtEndDe;

	private String entrpsNo;
	private String lastCntrctAt;
	private String batchReflctAt;
	private String entrpsnm_korean;
	private int entrpsMrtggSn;
	private int entrpsMrtggCntrctSn;
	private int lastEntrpsMrtggCntrctSn;
	private long mpFee;
	private String mrtggCndChangeDetailCode;

	private String mrtggDelngTyCode;
	private String mrtggSumry;
	private long mrtggDelngAmount;
	private long mrtggBlce;
	private long mrtggDfnnt;
	private String mrtggDfnntStr;

	private String mrtggGrntyFeeBndMbyAt;
	private double selngAchivrt;

	private int mlgSn;
	private String mlgSe;
	private String mlgTy;
	private int delngMlg;
	private int remndrMlg;
	private String mlgDetailDtls;
	private String orderNo;
	private String canclExchngRtngudNo;

}
