package com.sorincorp.batch.mb.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class MbEntrpsGradEvlVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -5900594511514887617L;
	/**
	 * 등급평가년도
	 */
	private String gradEvlYear;
	/**
	 * 톤 수 직전분기 누계
	 */
	private int tonCoBeforeQuAcmtl;
	/**
	 * 톤 수 당해누적
	 */
	private int tonCoPrtintAccmlt;
	/**
	 * 주문톤수 점수
	 */
	private int orderTonCoScore;
	/**
	 * 빈도 직전 분기 누계
	 */
	private int fqBeforeQuAcmtl;
	/**
	 * 빈도 당해 누적
	 */
	private int fqPrtintAccmlt;
	/**
	 * 주문 빈도 점수
	 */
	private int orderFqScore;
	/**
	 * 평가 기준 합계 점수
	 */
	private int evlStdrSmScore;

	// MB_ENTRPS_GRAD_BNEF_BAS(회원_업체 등급 혜택 기본)
	/**
	 * 업체 등급 순번
	 */
	private int entrpsGradSn;
	/**
	 * 시행 일자
	 */
	private String opertnDe;
	/**
	 * 재고 표시 여부
	 */
	private String invntryIndictAt;
	/**
	 * 전문가용 메일링 서비스 여부
	 */
	private String spcltyusefulEmailringSvcAt;

	// MB_ENTRPS_GRAD_METAL_ACCTO_MANAGE_DTL(회원_업체 등급 금속 별 관리 상세)
	/**
	 * 금속 코드
	 */
	private String metalCode;
	/**
	 * 1일 구매 중량 한도
	 */
	private int onedePurchsWtLmt;
	/**
	 * 1회 구매 중량 한도
	 */
	private int oncePurchsWtLmt;
	/**
	 * 적립 마일리지
	 */
	private int accmlMlg;

	// 회원_업체 등급 관리 기본
	/**
	 * 등급 평가 순번
	 */
	private String gradEvlSn;
	/**
	 * 등급 평가 일자
	 */
	private int gradEvlDe;
	/**
	 * 등급 항목 순번
	 */
	private int gradIemSn;
	/**
	 * 시작 주문 톤 수
	 */
	private int beginOrderTonCo;
	/**
	 * 종료 주문 톤 수
	 */
	private int endOrderTonCo;
	/**
	 * 주문 톤 수 기준 점수
	 */
	private int orderTonCoStdrScore;
	/**
	 * 시작 빈도 수
	 */
	private int beginFqCo;
	/**
	 * 종료 빈도 수
	 */
	private int endFqCo;
	/**
	 * 주문 빈도 기준 점수
	 */
	private int orderFqStdrScore;
	/**
	 * 시작 합계 점수
	 */
	private int beginSmScore;
	/**
	 * 종료 합계 점수
	 */
	private int endSmScore;

	// 공통컬럼
	/**
	 * 업체번호
	 */
	private String entrpsNo;
	/**
	 * 등급 평가 분기
	 */
	private String gradEvlQu;
	private String gradEvlQuNm;
	/**
	 * 업체 등급
	 */
	private String entrpsGrad;
	private String entrpsGradNm;
	/**
	 * 삭제여부
	 */
	private String deleteAt;
	/**
	 * 삭제일시
	 */
	private String deleteDt;
	/**
	 * 최초등록자id
	 */
	private String frstRegisterId;
	/**
	 * 최초등록일시
	 */
	private String frstRegistDt;
	/**
	 * 최종변경자id
	 */
	private String lastChangerId;
	/**
	 * 최종변경자id
	 */
	private String lastChangerNm;
	/**
	 * 최종변경일시
	 */
	private String lastChangeDt;

	private String today;

	private String oneQyYn;
	private String twoQyYn;
	private String threeQyYn;
	private String fourQyYn;
	private String oneHyYn;
	private String twoHyYn;
	private String oneYyYn;

	private int totOrderTonCo;
	private int totFqCo;

	private String gradEvlMthCode;
	private int gradCalcSn;

	private String mberNo;
	private String mberId;
	private String mberEmail;
	private String entrpsnmKorean;

	private String moblphonNo;
}
