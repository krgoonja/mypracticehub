package com.sorincorp.batch.mb.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.batch.mb.model.MbEntrpsGradEvlVO;

public interface MbEntrpsGradEvlMapper {

	MbEntrpsGradEvlVO selectMbEntrpsGradEvlDeInfo(Map<String, String> gradEvlDeParam) throws Exception;

	MbEntrpsGradEvlVO selectMbEntrpsGradEvlInfo(MbEntrpsGradEvlVO param) throws Exception;

	List<MbEntrpsGradEvlVO> selectEntrpsList() throws Exception;

	int insertMbEntrpsGradCalcDtl(MbEntrpsGradEvlVO param) throws Exception;

	int insertMbEntrpsGradCalcDtlHst(MbEntrpsGradEvlVO param) throws Exception;

	int insertMbEntrpsGradManageDtl(MbEntrpsGradEvlVO param) throws Exception;

	int updateMbEntrpsInfoBas(MbEntrpsGradEvlVO param) throws Exception;

	int insertMbEntrpsInfoBasHst(MbEntrpsGradEvlVO param) throws Exception;

	MbEntrpsGradEvlVO selectOrderAcmt(MbEntrpsGradEvlVO mbEntrpsGradEvlVO) throws Exception;

}
