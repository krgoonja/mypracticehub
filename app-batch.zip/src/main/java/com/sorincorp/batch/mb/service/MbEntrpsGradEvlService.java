package com.sorincorp.batch.mb.service;

public interface MbEntrpsGradEvlService {

	int mbEntrpsGradEvl(String gradCalcDt) throws Exception;

}
