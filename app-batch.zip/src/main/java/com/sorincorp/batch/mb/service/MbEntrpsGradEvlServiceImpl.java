package com.sorincorp.batch.mb.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.mb.mapper.MbDrmncyMberChkMapper;
import com.sorincorp.batch.mb.mapper.MbEntrpsGradEvlMapper;
import com.sorincorp.batch.mb.model.MbEntrpsGradEvlVO;
import com.sorincorp.comm.mbLog.mapper.MbLogMapper;
import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MbEntrpsGradEvlServiceImpl implements MbEntrpsGradEvlService {

	@Autowired
	MbEntrpsGradEvlMapper mbEntrpsGradEvlMapper;

	@Autowired
	private MbDrmncyMberChkMapper mbDrmncyMberChkMapper;

	@Autowired
	private MbLogMapper mbLogMapper;

	@Autowired
	private MailService mailService;

	@Autowired
	private SMSService smsService;

	@Value("${spring.profiles}")
	private String profiles;
	
	/** 이메일 발송 매퍼 */
    @Autowired
    private MailMapper mailMapper;
    
	@Override
	public int mbEntrpsGradEvl(String gradCalcDt) throws Exception {
		// TODO Auto-generated method stub
		log.debug("=====================업체 등급 평가===================");

		MbEntrpsGradEvlVO gradEvlInfo;
		MbEntrpsGradEvlVO orderAcmt;
		MbEntrpsGradEvlVO param = new MbEntrpsGradEvlVO();
		SMSVO smsVO = new SMSVO();
		Map<String, String> msgMap = new HashMap<>();
		// gradCalcDt = "20221001";
		String today = gradCalcDt;
		String today2 = DateUtil.getNowDateTime("yyyy년 MM월 dd일");
		String today3 = DateUtil.getNowDateTime("yy.MM.dd");
		String smsReqDate = DateUtil.getNowDateTime("yyyy-MM-dd 09:00:00");

		int tonCoBeforeQuAcmtl = 0;
		int tonCoPrtintAccmlt = 0;
		int totOrderTonCo = 0;
		int fqBeforeQuAcmtl = 0;
		int fqPrtintAccmlt = 0;
		int totFqCo = 0;
		int gradCalcCnt = 0;
		int result = 0;
		String lastChangerId = "BATCH_ENTRPS_GRAD_EVL";

		Map<String, String> mailMap = new HashMap<>();
		MailVO mailVO = new MailVO();
		Map<String, String> kkoMap = new HashMap<>();
		Integer nsltSndngDt = mbDrmncyMberChkMapper.selectNsltSndngDt(); // 메일 발송 시작 시간 출력
		String prevMemberClassImg = "";
		String presMemberClassImg = "";
		String moblphonNo = "";

		Map<String, String> gradEvlDeParam = new HashMap<>();
		gradEvlDeParam.put("gradCalcDt", gradCalcDt);

		MbEntrpsGradEvlVO mbEntrpsGradEvlVO = mbEntrpsGradEvlMapper.selectMbEntrpsGradEvlDeInfo(gradEvlDeParam);

		// log.debug(mbEntrpsGradEvlVO.toString());

		if ("QY".equals(mbEntrpsGradEvlVO.getGradEvlQu())) {
			if ("Y".equals(mbEntrpsGradEvlVO.getOneQyYn())) {
				log.debug("1분기 평가!!!");
				param.setGradEvlQu("1Q");
			} else if ("Y".equals(mbEntrpsGradEvlVO.getTwoQyYn())) {
				log.debug("2분기 평가!!!");
				param.setGradEvlQu("2Q");
			} else if ("Y".equals(mbEntrpsGradEvlVO.getThreeQyYn())) {
				log.debug("3분기 평가!!!");
				param.setGradEvlQu("3Q");
			} else if ("Y".equals(mbEntrpsGradEvlVO.getFourQyYn())) {
				log.debug("4분기 평가!!!");
				param.setGradEvlQu("4Q");
			}
		} else if ("HY".equals(mbEntrpsGradEvlVO.getGradEvlQu())) {
			if ("Y".equals(mbEntrpsGradEvlVO.getOneHyYn())) {
				log.debug("1반기 평가!!!");
				param.setGradEvlQu("2Q");
			} else if ("Y".equals(mbEntrpsGradEvlVO.getTwoHyYn())) {
				log.debug("2반기 평가!!!");
				param.setGradEvlQu("4Q");
			}
		} else if ("YY".equals(mbEntrpsGradEvlVO.getGradEvlQu())) {
			if ("Y".equals(mbEntrpsGradEvlVO.getOneYyYn())) {
				log.debug("1년기 평가!!!");
				param.setGradEvlQu("4Q");
			}
		}
		log.debug("param.getGradEvlQu() : " + param.getGradEvlQu());

		if (!"".equals(param.getGradEvlQu()) && param.getGradEvlQu() != null) {

			List<MbEntrpsGradEvlVO> entrpsList = mbEntrpsGradEvlMapper.selectEntrpsList();

			for (MbEntrpsGradEvlVO entrpsVO : entrpsList) {
				// 업체번호 세팅
				mbEntrpsGradEvlVO.setEntrpsNo(entrpsVO.getEntrpsNo());
				// 주문톤수, 주문빈도수 조회 김은영씨가 만들어준 DB FUNCTION 호출하여 조회
				orderAcmt = mbEntrpsGradEvlMapper.selectOrderAcmt(mbEntrpsGradEvlVO);

				// 직전 주문톤수
				tonCoBeforeQuAcmtl = orderAcmt.getTonCoBeforeQuAcmtl();
				// 당해 누적 주문톤수
				tonCoPrtintAccmlt = orderAcmt.getTonCoPrtintAccmlt();
				// 직전+당해누적 주문톤수
				totOrderTonCo = tonCoBeforeQuAcmtl + tonCoPrtintAccmlt;

				// 직전 주문빈도수
				fqBeforeQuAcmtl = orderAcmt.getFqBeforeQuAcmtl();
				// 당해 누적 빈도수
				fqPrtintAccmlt = orderAcmt.getFqPrtintAccmlt();
				// 직전+당해누적 주문빈도수
				totFqCo = fqBeforeQuAcmtl + fqPrtintAccmlt;

				param.setTonCoBeforeQuAcmtl(tonCoBeforeQuAcmtl);
				param.setTonCoPrtintAccmlt(tonCoPrtintAccmlt);
				param.setTotOrderTonCo(totOrderTonCo);

				param.setFqBeforeQuAcmtl(fqBeforeQuAcmtl);
				param.setFqPrtintAccmlt(fqPrtintAccmlt);
				param.setTotFqCo(totFqCo);

				param.setEntrpsNo(entrpsVO.getEntrpsNo());
				param.setGradEvlSn(mbEntrpsGradEvlVO.getGradEvlSn());
				param.setGradEvlMthCode(mbEntrpsGradEvlVO.getGradEvlQu());
				param.setGradEvlDe(mbEntrpsGradEvlVO.getGradEvlDe());

				gradEvlInfo = mbEntrpsGradEvlMapper.selectMbEntrpsGradEvlInfo(param);

				log.debug(gradEvlInfo.toString());

				if (gradEvlInfo != null) {

					param.setEntrpsGrad(gradEvlInfo.getEntrpsGrad());
					// param.setOrderTonCoStdrScore(gradEvlInfo.getOrderTonCoStdrScore());
					// param.setOrderFqStdrScore(gradEvlInfo.getOrderFqStdrScore());
					param.setOrderTonCoScore(gradEvlInfo.getOrderTonCoScore());
					param.setOrderFqScore(gradEvlInfo.getOrderFqScore());
					param.setEvlStdrSmScore(gradEvlInfo.getEvlStdrSmScore());
					param.setLastChangerId(lastChangerId);

					// 회원_업체 등급 산정 상세 insert
					result = mbEntrpsGradEvlMapper.insertMbEntrpsGradCalcDtl(param);

					if (result > 0) {
						// 회원_업체 등급 산정 상세 이력 insert
						mbEntrpsGradEvlMapper.insertMbEntrpsGradCalcDtlHst(param);
						// 회원_업체 등급 관리 상세 insert
						mbEntrpsGradEvlMapper.insertMbEntrpsGradManageDtl(param);
						// 업체기본 업체등급 update
						result = mbEntrpsGradEvlMapper.updateMbEntrpsInfoBas(param);

						if (result > 0) {
							gradCalcCnt++;
							// 업체기본 이력 insert
//							mbEntrpsGradEvlMapper.insertMbEntrpsInfoBasHst(param);
							mbLogMapper.insertMbEntrpsInfoBasHst(entrpsVO.getEntrpsNo());

							if (entrpsVO.getMberEmail() != null && !"".equals(entrpsVO.getMberEmail())) {
								MailVO selectMailTmpt = mailMapper.selectMailTmpt(61);  // 발신자 이메일 가져오기
								// 메일 없을 경우 에러발생
								mailVO.setMailTmptSeq(61); // 사용할 템플릿 번호 지정
								mailVO.setEmail(entrpsVO.getMberEmail()); // 수신자 메일 주소
								mailVO.setMailSendUserId("admin"); // 보내는 사람 아이디
								mailVO.setMailSendEmail(selectMailTmpt.getSntoEmail()); // 보내는 사람 이메일
								mailVO.setMemberNo(entrpsVO.getMberNo());
								mailVO.setNsltSndngDt(nsltSndngDt); // 보내는 시간

//								if ("prd".equals(profiles)) {
//									// 등급에 따른 이미지 경로 설정
//									if ("01".equals(entrpsVO.getEntrpsGrad())) {
//										prevMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_bronze_1661752473034.png";
//									} else if ("02".equals(entrpsVO.getEntrpsGrad())) {
//										prevMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_silver_1661752484891.png";
//									} else if ("03".equals(entrpsVO.getEntrpsGrad())) {
//										prevMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_gold_1661752478422.png";
//									} else if ("04".equals(entrpsVO.getEntrpsGrad())) {
//										prevMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_platinum_1661752481982.png";
//									} else if ("05".equals(entrpsVO.getEntrpsGrad())) {
//										prevMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_diamond_1661752476016.png";
//									}
								//
//									if ("01".equals(gradEvlInfo.getEntrpsGrad())) {
//										presMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_bronze_1661752473034.png";
//									} else if ("02".equals(gradEvlInfo.getEntrpsGrad())) {
//										presMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_silver_1661752484891.png";
//									} else if ("03".equals(gradEvlInfo.getEntrpsGrad())) {
//										presMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_gold_1661752478422.png";
//									} else if ("04".equals(gradEvlInfo.getEntrpsGrad())) {
//										presMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_platinum_1661752481982.png";
//									} else if ("05".equals(gradEvlInfo.getEntrpsGrad())) {
//										presMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_diamond_1661752476016.png";
//									}
//								} else {
//									// 등급에 따른 이미지 경로 설정
//									if ("01".equals(entrpsVO.getEntrpsGrad())) {
//										prevMemberClassImg = "https://sorincorp.blob.core.windows.net/secs-t/it/icon_bronze_1661751957802.png";
//									} else if ("02".equals(entrpsVO.getEntrpsGrad())) {
//										prevMemberClassImg = "https://sorincorp.blob.core.windows.net/secs-t/it/icon_silver_1661751991558.png";
//									} else if ("03".equals(entrpsVO.getEntrpsGrad())) {
//										prevMemberClassImg = "https://sorincorp.blob.core.windows.net/secs-t/it/icon_gold_1661751986301.png";
//									} else if ("04".equals(entrpsVO.getEntrpsGrad())) {
//										prevMemberClassImg = "https://sorincorp.blob.core.windows.net/secs-t/it/icon_platinum_1661751988617.png";
//									} else if ("05".equals(entrpsVO.getEntrpsGrad())) {
//										prevMemberClassImg = "https://sorincorp.blob.core.windows.net/secs-t/it/icon_diamond_1661751983428.png";
//									}
								//
//									if ("01".equals(gradEvlInfo.getEntrpsGrad())) {
//										presMemberClassImg = "https://sorincorp.blob.core.windows.net/secs-t/it/icon_bronze_1661751957802.png";
//									} else if ("02".equals(gradEvlInfo.getEntrpsGrad())) {
//										presMemberClassImg = "https://sorincorp.blob.core.windows.net/secs-t/it/icon_silver_1661751991558.png";
//									} else if ("03".equals(gradEvlInfo.getEntrpsGrad())) {
//										presMemberClassImg = "https://sorincorp.blob.core.windows.net/secs-t/it/icon_gold_1661751986301.png";
//									} else if ("04".equals(gradEvlInfo.getEntrpsGrad())) {
//										presMemberClassImg = "https://sorincorp.blob.core.windows.net/secs-t/it/icon_platinum_1661751988617.png";
//									} else if ("05".equals(gradEvlInfo.getEntrpsGrad())) {
//										presMemberClassImg = "https://sorincorp.blob.core.windows.net/secs-t/it/icon_diamond_1661751983428.png";
//									}
//								}

								// 등급에 따른 이미지 url 설정(prd url)
								if ("01".equals(entrpsVO.getEntrpsGrad())) {
									prevMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_bronze_1661752473034.png";
								} else if ("02".equals(entrpsVO.getEntrpsGrad())) {
									prevMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_silver_1661752484891.png";
								} else if ("03".equals(entrpsVO.getEntrpsGrad())) {
									prevMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_gold_1661752478422.png";
								} else if ("04".equals(entrpsVO.getEntrpsGrad())) {
									prevMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_platinum_1661752481982.png";
								} else if ("05".equals(entrpsVO.getEntrpsGrad())) {
									prevMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_diamond_1661752476016.png";
								}

								if ("01".equals(gradEvlInfo.getEntrpsGrad())) {
									presMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_bronze_1661752473034.png";
								} else if ("02".equals(gradEvlInfo.getEntrpsGrad())) {
									presMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_silver_1661752484891.png";
								} else if ("03".equals(gradEvlInfo.getEntrpsGrad())) {
									presMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_gold_1661752478422.png";
								} else if ("04".equals(gradEvlInfo.getEntrpsGrad())) {
									presMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_platinum_1661752481982.png";
								} else if ("05".equals(gradEvlInfo.getEntrpsGrad())) {
									presMemberClassImg = "https://sorincorp.blob.core.windows.net/secs/it/icon_diamond_1661752476016.png";
								}

								// 이전등급
								mailMap.put("prevMemberClass", entrpsVO.getEntrpsGradNm());
								// 현재등급
								mailMap.put("presMemberClass", gradEvlInfo.getEntrpsGradNm());
								// yyyy년 MM월 dd일
								mailMap.put("today", today2);
								// yy.MM.dd
								mailMap.put("today2", today3);
								// 업체명
								mailMap.put("entrpsnmKorean", entrpsVO.getEntrpsnmKorean());
								// 이전등급 이미지 url
								mailMap.put("prevMemberClassImg", prevMemberClassImg);
								// 조정등급 이미지 url
								mailMap.put("presMemberClassImg", presMemberClassImg);
								mailMap.put("servicedomain", "https://www.kztraders.com");
								// 메일발송
								mailService.insertMailSend(mailVO, mailMap);

								moblphonNo = entrpsVO.getMoblphonNo();

								if (moblphonNo != null && !"".equals(moblphonNo)) {
									moblphonNo = CryptoUtil.decryptAES256(moblphonNo);
									moblphonNo = moblphonNo.replaceAll("[^0-9]", "");
								}

								log.debug("회원 휴대폰번호 복호화 후 ===========>" + moblphonNo);

								// SMS 발송
								smsVO.setPhone(moblphonNo); // 받는사람 번호(복호화)
								smsVO.setMberNo(entrpsVO.getMberNo());
								smsVO.setMsgTitle("[ SORIN.COM ] 회원등급 조정 안내");
								smsVO.setReqDate(smsReqDate);

								msgMap.put("templateNum", "79"); // 메시지 템플릿 번호
								msgMap.put("ordrrNm", entrpsVO.getEntrpsnmKorean());
								msgMap.put("yyyy", DateUtil.getNowDateTime("yyyy"));
								msgMap.put("mm", DateUtil.getNowDateTime("MM"));
								msgMap.put("dd", DateUtil.getNowDateTime("dd"));
								msgMap.put("prevMemberClass", entrpsVO.getEntrpsGradNm());
								msgMap.put("presMemberClass", gradEvlInfo.getEntrpsGradNm());

								smsService.insertSMS(smsVO, msgMap); // 메소드 호출

//								kkoMap.put("templateNum", "79");
//								kkoMap.put("ordrrNm", entrpsVO.getEntrpsnmKorean());
//								kkoMap.put("yyyy", DateUtil.getNowDateTime("yyyy"));
//								kkoMap.put("mm", DateUtil.getNowDateTime("MM"));
//								kkoMap.put("dd", DateUtil.getNowDateTime("dd"));
//								kkoMap.put("prevMemberClass", entrpsVO.getEntrpsGradNm());
//								kkoMap.put("presMemberClass", gradEvlInfo.getEntrpsGradNm());
//								kkoMap.put("urlPc", "https://www.metalsorin.com/");
//								kkoMap.put("urlMobile", "https://m.metalsorin.com/");
//								kkoMap.put("urlName", "케이지트레이딩 >");
//
//								KkoMsgVO kkoVO = new KkoMsgVO();
//								kkoVO.setPhone(moblphonNo);
//								kkoVO.setMberNo(entrpsVO.getMberNo());
//								kkoVO.setReqDate(smsReqDate);
//
//								smsService.insertKkoMsg(kkoVO, kkoMap);

							}
//							log.debug("기존등급: " + entrpsVO.getEntrpsGradNm());
//							log.debug("조정등급: " + gradEvlInfo.getEntrpsGradNm());
						}
					}
				}
			}
		}

		return gradCalcCnt;
	}

}
