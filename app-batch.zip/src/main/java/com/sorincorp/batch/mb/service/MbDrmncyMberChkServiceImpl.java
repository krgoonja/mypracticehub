/**
 *
 */
package com.sorincorp.batch.mb.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.mb.mapper.MbDrmncyMberChkMapper;
import com.sorincorp.batch.mb.model.MbDrmncyMberVO;
import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * EwalletUseConfmChkServiceImpl.java
 *
 * @version
 * @since 2021. 11. 19.
 * @author srec0009
 */
@Slf4j
@Service
public class MbDrmncyMberChkServiceImpl implements MbDrmncyMberChkService {

	@Autowired
	private MbDrmncyMberChkMapper mbDrmncyMberChkMapper;

	@Autowired
	private MailService mailService;

	@Autowired
	private SMSService smsService;
	
	/** 이메일 발송 매퍼 */
    @Autowired
    private MailMapper mailMapper;
    
	String serviceDomain = "https://www.kztraders.com";

	String smsReqDate = DateUtil.getNowDateTime("yyyy-MM-dd 09:00:00");

	@Override
	public void selectPreMbDrmncyMber() throws Exception {
		Integer nsltSndngDt = mbDrmncyMberChkMapper.selectNsltSndngDt(); // 메일 발송 시작 시간 출력
		String templateNum = "8";
		String title = mbDrmncyMberChkMapper.selectMssageSj(templateNum);
		log.debug("selectPreMbDrmncyMber ===============================");
		// 휴면 전환 예정
		List<MbDrmncyMberVO> preMbDrmncyMberList = mbDrmncyMberChkMapper.selectPreMbDrmncyMber();

		String moblphonNo = "";

		if (preMbDrmncyMberList.size() > 0) {
			for (MbDrmncyMberVO vo : preMbDrmncyMberList) {
				Map<String, String> msgMap = new HashMap<>();
				SMSVO smsVO = new SMSVO();
				msgMap.put("templateNum", templateNum); // 메시지 템플릿 번호
				msgMap.put("userId", vo.getMberId());
				msgMap.put("drmncyDate", vo.getDrmncyDate());
				msgMap.put("sendDate", vo.getSendDate());
				msgMap.put("Servicedomain", serviceDomain);

				moblphonNo = vo.getMoblphonNo();

				if (moblphonNo != null && !"".equals(moblphonNo)) {

					try {
						log.debug("휴면배치 회원 휴대폰번호 복호화 전 ===========>" + moblphonNo);
						moblphonNo = CryptoUtil.decryptAES256(moblphonNo);
						moblphonNo = moblphonNo.replaceAll("[^0-9]", "");
						log.debug("휴면배치 회원 휴대폰번호 복호화 후 ===========>" + moblphonNo);
					} catch (Exception e) {
						// TODO: handle exception
						log.error("selectPreMbDrmncyMber MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
					}
				}

				// smsVO.setPhone(vo.getMoblphonNo()); // 받는사람 번호
				smsVO.setPhone(moblphonNo); // 받는사람 번호(복호화)
				smsVO.setMberNo(vo.getMberNo());
				smsVO.setMsgTitle(title);

				smsVO.setReqDate(smsReqDate);
				smsService.insertSMS(smsVO, msgMap); // 메소드 호출

				Map<String, String> mailMap = new HashMap<>();
				MailVO mailVO = new MailVO();
			    MailVO selectMailTmpt = mailMapper.selectMailTmpt(8);          // 발신자 이메일 가져오기
				mailVO.setMailTmptSeq(8); // 사용할 템플릿 번호 지정
				mailVO.setEmail(vo.getMberEmail()); // 수신자 메일 주소
				mailVO.setMailSendUserId("admin"); // 보내는 사람 아이디
				mailVO.setMailSendEmail(selectMailTmpt.getSntoEmail()); // 보내는 사람 이메일
				mailVO.setMemberNo(vo.getMberNo());
				mailVO.setNsltSndngDt(nsltSndngDt); // 보내는 시간

				mailMap.put("userId", vo.getMberId());
				mailMap.put("drmcyDate", vo.getDrmncyDate());
				mailMap.put("sendDate", vo.getSendDate());
				mailService.insertMailSend(mailVO, mailMap);

				log.debug("=================================================================");
				log.debug("휴면 전환 예정 회원 아이디 ::" + vo.getMberId());
				log.debug("=================================================================");

			}
		} else {
			log.debug("=================================================================");
			log.debug("                       휴면 전환 예정 회원 없음 ");
			log.debug("=================================================================");
		}
	}

	@Override
	public void selectMbDrmncyMber() throws Exception {
		log.debug("selectMbDrmncyMber ===============================");
		Integer nsltSndngDt = mbDrmncyMberChkMapper.selectNsltSndngDt(); // 메일 발송 시작 시간 출력
		String templateNum = "9";
		String title = mbDrmncyMberChkMapper.selectMssageSj(templateNum);
		// 휴면 전환
		List<MbDrmncyMberVO> mbDrmncyMberList = mbDrmncyMberChkMapper.selectMbDrmncyMber();

		String moblphonNo = "";

		if (mbDrmncyMberList.size() > 0) {
			for (MbDrmncyMberVO vo : mbDrmncyMberList) {
				Map<String, String> msgMap = new HashMap<>();
				SMSVO smsVO = new SMSVO();

				msgMap.put("templateNum", templateNum);
				msgMap.put("userId", vo.getMberId());
				msgMap.put("drmncyDate", vo.getDrmncyDate());
				msgMap.put("sendDate", vo.getDrmncyDate());
				msgMap.put("Servicedomain", serviceDomain);


				moblphonNo = vo.getMoblphonNo();

				if (moblphonNo != null && !"".equals(moblphonNo)) {
					try {
						log.debug("휴면배치 회원 휴대폰번호 복호화 전 ===========>" + moblphonNo);
						moblphonNo = CryptoUtil.decryptAES256(moblphonNo);
						moblphonNo = moblphonNo.replaceAll("[^0-9]", "");
						log.debug("휴면배치 회원 휴대폰번호 복호화 후 ===========>" + moblphonNo);
					} catch (Exception e) {
						// TODO: handle exception
						log.error("selectMbDrmncyMber MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
					}
				}

				smsVO.setMsgTitle(title);
				// smsVO.setPhone(vo.getMoblphonNo()); // 받는사람 번호
				smsVO.setPhone(moblphonNo); // 받는사람 번호(복호화)
				smsVO.setMberNo(vo.getMberNo());
				smsVO.setReqDate(smsReqDate); // 예약 발송 시간

				smsService.insertSMS(smsVO, msgMap); // 메소드 호출

				Map<String, String> mailMap = new HashMap<>();
				MailVO mailVO = new MailVO();
				mailVO.setMailTmptSeq(9); // 사용할 템플릿 번호 지정
				MailVO selectMailTmpt = mailMapper.selectMailTmpt(9);          // 발신자 이메일 가져오기
				mailVO.setEmail(vo.getMberEmail()); // 수신자 메일 주소
				mailVO.setMailSendUserId("admin"); // 보내는 사람 아이디
				mailVO.setMailSendEmail(selectMailTmpt.getSntoEmail()); // 보내는 사람 이메일
				mailVO.setNsltSndngDt(nsltSndngDt); // 보내는 시간
				mailVO.setMemberNo(vo.getMberNo());
				mailMap.put("userId", vo.getMberId());
				mailMap.put("drmncyDate", vo.getDrmncyDate());
				mailMap.put("sendDate", vo.getDrmncyDate());

				if (vo.getMberEmail() != null && !"".equals(vo.getMberEmail())) {
					// 메일 없을 경우 에러발생
					mailService.insertMailSend(mailVO, mailMap);
				}

				vo.setLastChangerId("MB_DRMNCY_BATCH");
				vo.setFrstRegisterId("MB_DRMNCY_BATCH");

				// 휴면 회원 테이블 인서트
				mbDrmncyMberChkMapper.insertMbDrmncyMberBas(vo);

				vo.setMberSttusCode("05");

				// 회원 테이블 상태 업데이트 MBER_STTUS_CODE => '05' (휴면회원)
				mbDrmncyMberChkMapper.updateMberSttus(vo);
				// 회원 이력 테이블 인서트
				mbDrmncyMberChkMapper.insertMbMberInfoBasHst(vo);
				// 휴면 회원 테이블 인서트
				// mbDrmncyMberChkMapper.insertMbDrmncyMberBas(vo);

				log.debug("=================================================================");
				log.debug("휴면 전환 회원 아이디 ::" + vo.getMberId());
				log.debug("=================================================================");
			}
		} else {
			log.debug("=================================================================");
			log.debug("                       휴면 전환 회원 없음 ");
			log.debug("=================================================================");
		}
	}
}
