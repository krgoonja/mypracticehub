/**
 *
 */
package com.sorincorp.batch.mb.mapper;

import java.util.List;

import com.sorincorp.batch.ewallet.model.EwalletUseConfmChkVO;
import com.sorincorp.batch.mb.model.MbDrmncyMberVO;

/**
 * EwalletUserConfmChkMapper.java
 * @version
 * @since 2021. 11. 19.
 * @author srec0009
 */
public interface MbDrmncyMberChkMapper {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 30.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 30.			srec0009			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<MbDrmncyMberVO> selectMbDrmncyMber();

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 30.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 30.			srec0009			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<MbDrmncyMberVO> selectPreMbDrmncyMber();

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 30.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 30.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	void updateMberSttus(MbDrmncyMberVO vo);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 30.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 30.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	void insertMbMberInfoBasHst(MbDrmncyMberVO vo);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 30.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 30.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	void insertMbDrmncyMberBas(MbDrmncyMberVO vo);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 12. 1.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 1.			srec0009			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	Integer selectNsltSndngDt();

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 12. 14.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 14.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param templateNum
	 * @return
	 */
	String selectMssageSj(String templateNum);

}
