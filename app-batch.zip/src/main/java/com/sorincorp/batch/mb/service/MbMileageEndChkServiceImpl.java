package com.sorincorp.batch.mb.service;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.mb.mapper.MbMileageEndChkMapper;
import com.sorincorp.batch.mb.model.MbMileageMngVO;
import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MbMileageEndChkServiceImpl implements MbMileageEndChkService{

	@Autowired
	private MbMileageEndChkMapper mbMileageEndChkMapper;

	@Autowired
	private MailService mailService;
	
	/** 이메일 발송 매퍼 */
    @Autowired
    private MailMapper mailMapper;
    
	@Override
	public void mbMileageEndDateChk() throws Exception {

		int remndrMlg = 0; // 잔여 마일리지
		int delMlg = 0; // 소멸 마일리지
		int updateCnt = 0;
		int result = 0;
		int templateNum = 63;
		List<MbMileageMngVO> mbMileageEndList = mbMileageEndChkMapper.selectMbMileageEndList();

		if(mbMileageEndList != null) {
			for(MbMileageMngVO vo : mbMileageEndList) {
				result = mbMileageEndChkMapper.updateMbMileageMngEndList(vo);
				mbMileageEndChkMapper.insertMbMileageMngListHst(vo);
				if(result > 0) {
					updateCnt++;
				}
				remndrMlg = mbMileageEndChkMapper.selectRemndrMlg(vo);
				delMlg = vo.getDelngMlg()-vo.getUseMlg();
				vo.setDelngMlg(delMlg);
			    vo.setRemndrMlg(remndrMlg - delMlg);
			    vo.setUseMlg(0);
				vo.setMlgDetailDtls("마일리지 만료에 따른 소멸");
				vo.setMlgTy("05");
				mbMileageEndChkMapper.insertMbMileageMngList(vo);
				mbMileageEndChkMapper.insertMbMileageMngListHst(vo);

				Map<String, String> mailMap = new HashMap<>();
				MailVO mailVO = new MailVO();
				MailVO selectMailTmpt = mailMapper.selectMailTmpt(templateNum);          // 발신자 이메일 가져오기
                mailVO.setMailTmptSeq(templateNum); // 사용할 템플릿 번호 지정
				mailVO.setEmail(vo.getMberEmail()); // 수신자 메일 주소
				mailVO.setMailSendUserId("admin"); // 보내는 사람 아이디
				mailVO.setMailSendEmail(selectMailTmpt.getSntoEmail()); // 보내는 사람 이메일

				mailMap.put("userNm", vo.getMberNm());
				mailMap.put("mlgEndDe", vo.getMlgEndDe());
				mailMap.put("delMlg", Integer.toString(delMlg).replaceAll("\\B(?=(\\d{3})+(?!\\d))", ","));
				mailMap.put("Servicedomain", "https://www.kztraders.com");

				if (vo.getMberEmail() != null && !"".equals(vo.getMberEmail())) {
					// 메일 없을 경우 에러발생
					mailService.insertMailSend(mailVO, mailMap);
				}
			}
		}

		log.debug("마일리지 소멸 대상 건수 ===========>" + mbMileageEndList.size());
		log.debug("마일리지 소멸 처리 건수     ===========>" + updateCnt);
	}

	@Override
	public void delPrearngeMileageChk() throws Exception {
		int templateNum = 65;
		String delPrearngeMlg = ""; //소멸 예정 마일리지
		String today = DateUtil.getNowDateTime("yyyy.MM.dd");
		List<MbMileageMngVO> mbMileageDelPrearngeList = mbMileageEndChkMapper.selectMbMileageDelPrearngeList();

		if(mbMileageDelPrearngeList != null) {
			for(MbMileageMngVO vo : mbMileageDelPrearngeList) {

				delPrearngeMlg = Integer.toString(vo.getDelngMlg()-vo.getUseMlg()).replaceAll("\\B(?=(\\d{3})+(?!\\d))", ","); //콤마 추가

				Map<String, String> mailMap = new HashMap<>();
				MailVO mailVO = new MailVO();
				MailVO selectMailTmpt = mailMapper.selectMailTmpt(templateNum);          // 발신자 이메일 가져오기  
				mailVO.setMailTmptSeq(templateNum); // 사용할 템플릿 번호 지정
				mailVO.setEmail(vo.getMberEmail()); // 수신자 메일 주소
				mailVO.setMailSendUserId("admin"); // 보내는 사람 아이디
				mailVO.setMailSendEmail(selectMailTmpt.getSntoEmail()); // 보내는 사람 이메일

				mailMap.put("userNm", vo.getMberNm());
				mailMap.put("today", today);
				mailMap.put("delPrearngeMlg", delPrearngeMlg);
				mailMap.put("mlgEndDe", vo.getMlgEndDe());
				mailMap.put("Servicedomain", "https://www.kztraders.com");

				if (vo.getMberEmail() != null && !"".equals(vo.getMberEmail())) {
					// 메일 없을 경우 에러발생
					mailService.insertMailSend(mailVO, mailMap);
				}
			}
		}

		log.debug("마일리지 소멸예상 대상 건수 ===========>" + mbMileageDelPrearngeList.size());

	}





}
