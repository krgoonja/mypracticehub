package com.sorincorp.batch.mb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.mb.mapper.MbEntrpsMrtggCntrctBasMapper;
import com.sorincorp.batch.mb.model.MbEntrpsMrtggCntrctBasVO;
import com.sorincorp.comm.bsnInfo.model.CdtlnInfoVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MbEntrpsMrtggCntrctBasServiceImpl implements MbEntrpsMrtggCntrctBasService {

	@Autowired
	MbEntrpsMrtggCntrctBasMapper mbEntrpsMrtggCntrctBasMapper;

	@Autowired
	private BsnInfoService bsnInfoService;

	/**
	 * <pre>
	 * 처리내용: 전자상거래보증계약 IF테이블을 조회하고 전자상거래보증계약기본, 전자상거래보증계약상세내역 테이블에 insert하고 IF테이블 원장여부를 Y로 업데이트한다.
	 * </pre>
	 *
	 * @date 2022. 7. 19.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 19.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@Override
	public int insertMbEntrpsMrtggCntrctBas() throws Exception {
		// TODO Auto-generated method stub
		// 1.IF_KODIT_ENTRPS_PROGRS_STTUS 테이블에 원장적용여부 N인 데이터 조회
		List<MbEntrpsMrtggCntrctBasVO> ifKoditEntrpsProgrsSttusList = mbEntrpsMrtggCntrctBasMapper.selectIfKoditEntrpsProgrsSttusList();
		// log.debug("ABCDEF ======>" + ifKoditEntrpsProgrsSttusList.size());
		MbEntrpsMrtggCntrctBasVO ifKoditEntrpsProgrsSttusVO;
		MbEntrpsMrtggCntrctBasVO ifKoditEntrpsVO;

		String entrpsNo = "";
		String grntyProgrsSttusCode = "";
		int maxEntrpsMrtggCntrctSn = 0;
		int result = 0;
		int insertCnt = 0;
		int lastEntrpsMrtggCntrctSnCnt = 0;
		int lastEntrpsMrtggCntrctSn = 0;
		long mpFee = 0;
		long grntyAmount = 0;
		long mrtggBlce = 0;
		long mrtggDfnnt = 0;
		String mrtggDfnntStr = "";
		// String mrtggSumry = "";

		MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO = new MbEntrpsMrtggCntrctBasVO();
		List<MbEntrpsMrtggCntrctBasVO> mlgDtlList;
		double lastSelngAchivrt = 0;
		int remndrMlgCnt = 0;
		int remndrMlg = 0;
		int mlgSn = 0;

		String today = DateUtil.getNowDateTime("yyyy-MM-dd");
		CdtlnInfoVO cdtlnInfoVO = bsnInfoService.getCdtlnInfo(today);

		Exception ex = new Exception();

		for (int i = 0; i < ifKoditEntrpsProgrsSttusList.size(); i++) {
			// 2. 루프돌면서 데이터 추출
			ifKoditEntrpsProgrsSttusVO = ifKoditEntrpsProgrsSttusList.get(i);
			entrpsNo = ifKoditEntrpsProgrsSttusVO.getEntrpsNo();

			grntyProgrsSttusCode = ifKoditEntrpsProgrsSttusVO.getGrntyProgrsSttusCode();
			ifKoditEntrpsProgrsSttusVO.setLastChangerId("BATCH_MRTGG_CNTRCT1");

			// if ("00".equals(grntyProgrsSttusCode) || "10".equals(grntyProgrsSttusCode) ||
			// "20".equals(grntyProgrsSttusCode) || "30".equals(grntyProgrsSttusCode) ||
			// "50".equals(grntyProgrsSttusCode)) {
			if ("10".equals(grntyProgrsSttusCode) || "20".equals(grntyProgrsSttusCode) || "30".equals(grntyProgrsSttusCode) || "50".equals(grntyProgrsSttusCode)) {

				// 3.보증진행상태 10(접수완료), 20(승인완료), 30(발급완료), 50(해지완료)인 데이터는 마지막계약여부 Y인
				// 순번을 카운트 조회하여 있으면 4번 수행
				// 접수(10),승인(20),발급완료(30)
				lastEntrpsMrtggCntrctSnCnt = mbEntrpsMrtggCntrctBasMapper.selectLastEntrpsMrtggCnt(ifKoditEntrpsProgrsSttusVO);

				if (lastEntrpsMrtggCntrctSnCnt > 0) {
					// 4. 보증진행상태 10(접수),20(승인),30(발급완료),50(해지)인 데이터는 마지막계약여부 Y인 순번을 조회하고 있으면 해당 데이터의
					// 마지막계약여부 N으로 업데이트
					// 같은 보증번호, 사업자번호 데이터 마지마계약여부 N으로 수정
					lastEntrpsMrtggCntrctSn = mbEntrpsMrtggCntrctBasMapper.selectLastEntrpsMrtggSn(ifKoditEntrpsProgrsSttusVO);
					// 계약해지일 경우 매출달성율 조회
					if ("50".equals(grntyProgrsSttusCode)) {
						// 마지막 계약 매출 달성율 조회
						lastSelngAchivrt = mbEntrpsMrtggCntrctBasMapper.selectLastEntrpsMrtggSelngAchivrt(ifKoditEntrpsProgrsSttusVO);
					}

					// 마지막 계약여부가 Y인 데이터가 있을 경우만 N으로 업데이트한다.
					if (lastEntrpsMrtggCntrctSn > 0) {
						ifKoditEntrpsProgrsSttusVO.setEntrpsMrtggCntrctSn(lastEntrpsMrtggCntrctSn);
						// 마지막계약여부 N으로 업데이트
						result = mbEntrpsMrtggCntrctBasMapper.updateLastEntrpsMrtggSn2(ifKoditEntrpsProgrsSttusVO);
						if (result > 0) {
							mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMrtggCntrctBasHst(ifKoditEntrpsProgrsSttusVO);
						} else {
							log.error(ex.getMessage());
							throw ex;
						}
					}
				}
			}

			// if ("00".equals(grntyProgrsSttusCode) || "10".equals(grntyProgrsSttusCode) ||
			// "20".equals(grntyProgrsSttusCode)) {
			if ("10".equals(grntyProgrsSttusCode) || "20".equals(grntyProgrsSttusCode)) {
				// 5. 보증진행상태 10(접수완료), 20(승인완료)인 데이터는 IF_KODIT_ENTRPS_PROGRS_STTUS
				// 에서 추출한 데이터만 MB_ENTRPS_MRTGG_CNTRCT_BAS에 마지막 계약여부Y로 인서트하고
				// IF_KODIT_ENTRPS_PROGRS_STTUS 테이블에 원장적용여부를 Y로 업데이트한다.
				// 10 접수, 20 승인 일 경우 IF_KODIT_ENTRPS_PROGRS_STTUS 테이블에서 데이터 추출하여
				// INSERT한다.
				maxEntrpsMrtggCntrctSn = mbEntrpsMrtggCntrctBasMapper.selectMaxEntrpsMrtggSn(ifKoditEntrpsProgrsSttusVO);
				ifKoditEntrpsProgrsSttusVO.setEntrpsMrtggCntrctSn(maxEntrpsMrtggCntrctSn);
				ifKoditEntrpsProgrsSttusVO.setLastCntrctAt("Y");
				ifKoditEntrpsProgrsSttusVO.setLedgrReflctAt("Y");

				result = mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMrtggCntrctBas(ifKoditEntrpsProgrsSttusVO);

				if (result > 0) {
					insertCnt++;
					mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMrtggCntrctBasHst(ifKoditEntrpsProgrsSttusVO);
				} else {
					log.error(ex.getMessage());
					throw ex;
				}

				// IF_KODIT_ENTRPS_PROGRS_STTUS만 원장반영여부 Y로 업데이트
				result = mbEntrpsMrtggCntrctBasMapper.updateLedgrReflctAt(ifKoditEntrpsProgrsSttusVO);
				if (result < 1) {
					log.error(ex.getMessage());
					throw ex;
				}
			} else if ("30".equals(grntyProgrsSttusCode) || "40".equals(grntyProgrsSttusCode) || "50".equals(grntyProgrsSttusCode)) {
				// 6. 보증진행상태 30(발급완료),40(조건변경),50(해지)인 데이터는 IF_KODIT_ENTRPS_PROGRS_STTUS 에서 추출한
				// 데이터와 IF_KODIT_ENTRPS 테이블에서 발급일자, 발급기간, 한도금액을 결합하고 MP수수료 계산하고
				// MB_ENTRPS_MRTGG_CNTRCT_BAS에 30(발급완료)은 마지막 계약여부Y로 인서트하고 40(조건변경)은 마지막 계약여부를N로
				// 인서트한다. 업체번호가 존재할 경우 7번으로 이동
				// 30 발급완료, 40 갱신, 50 해지 일 경우 IF_KODIT_ENTRPS 테이블에서 데이터 추출하여 INSERT한다.
				ifKoditEntrpsVO = mbEntrpsMrtggCntrctBasMapper.selectIfKoditEntrpsInfo(ifKoditEntrpsProgrsSttusVO);

				if (ifKoditEntrpsVO != null) {
					// 발급일자, 보증금액, 보증 기한 시작 일자, 보증 기한 종료 일자 추출하여 세팅
					ifKoditEntrpsProgrsSttusVO.setIssuDe(ifKoditEntrpsVO.getIssuDe());
					ifKoditEntrpsProgrsSttusVO.setGrntyAmount(ifKoditEntrpsVO.getGrntyAmount());
					ifKoditEntrpsProgrsSttusVO.setGrntyTmlmtBeginDe(ifKoditEntrpsVO.getGrntyTmlmtBeginDe());
					ifKoditEntrpsProgrsSttusVO.setGrntyTmlmtEndDe(ifKoditEntrpsVO.getGrntyTmlmtEndDe());
					// ifKoditEntrpsProgrsSttusVO.setMrtggCndChangeDetailCode(ifKoditEntrpsVO.getGrntySttusCode());

					maxEntrpsMrtggCntrctSn = mbEntrpsMrtggCntrctBasMapper.selectMaxEntrpsMrtggSn(ifKoditEntrpsProgrsSttusVO);
					ifKoditEntrpsProgrsSttusVO.setEntrpsMrtggCntrctSn(maxEntrpsMrtggCntrctSn);

					if ("30".equals(grntyProgrsSttusCode) || "50".equals(grntyProgrsSttusCode)) {
						ifKoditEntrpsProgrsSttusVO.setLastCntrctAt("Y");
					} else {
						// 40 갱신 일 경우 마지막 계약 여부를 N으로 세팅한다(보증기간 날짜가 미래이기 때문에 nextstep 배치에서 마지막 계약 여부 별도로
						// 처리)
						ifKoditEntrpsProgrsSttusVO.setLastCntrctAt("N");
					}
					ifKoditEntrpsProgrsSttusVO.setLedgrReflctAt("Y");

					if ("30".equals(grntyProgrsSttusCode) || "40".equals(grntyProgrsSttusCode)) {
						// MP수수료 계산 보증금액 * 전자상거래보증 MP수수료 비율
						mpFee = (long) (ifKoditEntrpsVO.getGrntyAmount() * cdtlnInfoVO.getMrtgggrntyMpfeeRate());
						ifKoditEntrpsProgrsSttusVO.setMpFee(mpFee);
					}

					if ("30".equals(grntyProgrsSttusCode)) {
						// 발급완료 - 계약
						ifKoditEntrpsProgrsSttusVO.setMrtggCndChangeDetailCode("01");
						// 적요
						mrtggDfnntStr = "보증서 발급";
					} else if ("40".equals(grntyProgrsSttusCode)) {
						// 갱신 전 잔액 조회
						mrtggBlce = mbEntrpsMrtggCntrctBasMapper.selectMrtggBlce(ifKoditEntrpsProgrsSttusVO);
						// 이전한도 조회
						grntyAmount = mbEntrpsMrtggCntrctBasMapper.selectGrntyAmount(ifKoditEntrpsProgrsSttusVO);
						// 보증금액 차액 계산
						mrtggDfnnt = ifKoditEntrpsProgrsSttusVO.getGrntyAmount() - grntyAmount;
						// 갱신 후 잔액 계산
						mrtggBlce = mrtggBlce + mrtggDfnnt;

						if (mrtggDfnnt > 0) {
							// 조건변경(증액) - 갱신(증액)
							ifKoditEntrpsProgrsSttusVO.setMrtggCndChangeDetailCode("02");

							// 조건변경(증액) - 갱신(증액)
							mrtggDfnntStr = "증액";
							// 금액 콤마 처리
							mrtggDfnntStr += "(+" + StringUtil.formatMoney(String.valueOf(mrtggDfnnt)) + ")";
						} else if (mrtggDfnnt < 0) {
							// 조건변경(감액) - 갱신(감액)
							ifKoditEntrpsProgrsSttusVO.setMrtggCndChangeDetailCode("03");

							// 조건변경(감액) - 갱신(감액)
							mrtggDfnntStr = "감액";
							// 금액 콤마 처리
							mrtggDfnntStr += "(" + StringUtil.formatMoney(String.valueOf(mrtggDfnnt)) + ")";
						} else {
							// 조건변경(만료연장) - 기간변경
							ifKoditEntrpsProgrsSttusVO.setMrtggCndChangeDetailCode("04");

							// 조건변경(만료연장) - 기간변경
							mrtggDfnntStr = "갱신";
						}

						log.debug("차액 ==============> " + mrtggDfnnt);
						log.debug("적요 ==============> " + mrtggDfnntStr);

					} else if ("50".equals(grntyProgrsSttusCode)) {
						// 해지 - 해지
						ifKoditEntrpsProgrsSttusVO.setMrtggCndChangeDetailCode("06");
						// 갱신 전 잔액 조회
						mrtggBlce = mbEntrpsMrtggCntrctBasMapper.selectMrtggBlce(ifKoditEntrpsProgrsSttusVO);
						// 이전한도 조회
						ifKoditEntrpsProgrsSttusVO.setLastEntrpsMrtggCntrctSn(lastEntrpsMrtggCntrctSn);
						grntyAmount = mbEntrpsMrtggCntrctBasMapper.selectGrntyAmount(ifKoditEntrpsProgrsSttusVO);
						// 보증금액 차액 계산
						mrtggDfnnt = ifKoditEntrpsProgrsSttusVO.getGrntyAmount() - grntyAmount;
						// 갱신 후 잔액 계산
						// mrtggBlce = mrtggBlce - mrtggDfnnt;
						// 갱신전 잔액 - 현재한도
						mrtggBlce = mrtggBlce - ifKoditEntrpsProgrsSttusVO.getGrntyAmount();
						// 적요
						mrtggDfnntStr = "보증서 해지";
					}

					// 전자상거래보증계약기본 insert
					result = mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMrtggCntrctBas(ifKoditEntrpsProgrsSttusVO);

					if (result > 0) {
						// 전자상거래보증계약기본 히스토리 insert
						mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMrtggCntrctBasHst(ifKoditEntrpsProgrsSttusVO);
					} else {
						log.error(ex.getMessage());
						throw ex;
					}

					// 업체번호 존재할 경우 상세내역 테이블에 INSERT
					if (entrpsNo != null && !"".equals(entrpsNo)) {
						// 7. 업체번호가 존재하는 보증진행상태 30(발급완료),40(조건변경) 데이터를 MB_ENTRPS_MRTGG_LMT_DTL 테이블에
						// 인서트한다.
						// 담보 조건 변경 상세 코드 01(계약)인 경우 남은한도 = 담보거래금액
						// 담보 조건 변경 상세 코드 02(갱신(증액)), 03(갱신(감액)) 인 경우 남은한도 = 남은한도 + (신규한도-이전한도)
						// 담보 조건 변경 상세 코드 02(갱신(증액)), 03(갱신(감액)) 인 경우 차액계산 차액 = 신규한도-이전한도
						// 담보 거래 금액
						ifKoditEntrpsProgrsSttusVO.setMrtggDelngAmount(ifKoditEntrpsProgrsSttusVO.getGrntyAmount());

						// 회원_업체 담보 한도 상세 담보거래 유형코드 세팅
						if ("30".equals(grntyProgrsSttusCode)) {
							// 계약
							ifKoditEntrpsProgrsSttusVO.setMrtggDelngTyCode("01");
							// 계약
							// ifKoditEntrpsProgrsSttusVO.setMrtggCndChangeDetailCode("01");
							// 계약일경우 남은 한도에 담보거래 금액 적용
							ifKoditEntrpsProgrsSttusVO.setMrtggBlce(ifKoditEntrpsProgrsSttusVO.getGrntyAmount());
							// 적요
							ifKoditEntrpsProgrsSttusVO.setMrtggDfnntStr(mrtggDfnntStr);

						} else if ("40".equals(grntyProgrsSttusCode)) {
							// 갱신 전 잔액 조회
							// mrtggBlce =
							// mbEntrpsMrtggCntrctBasMapper.selectMrtggBlce(ifKoditEntrpsProgrsSttusVO);
							// 이전한도 조회
							// grntyAmount =
							// mbEntrpsMrtggCntrctBasMapper.selectGrntyAmount(ifKoditEntrpsProgrsSttusVO);
							// 보증금액 차액 계산
							// mrtggDfnnt = ifKoditEntrpsProgrsSttusVO.getGrntyAmount() - grntyAmount;
							// 갱신 후 잔액 계산
							// mrtggBlce = mrtggBlce + mrtggDfnnt;

							// 갱신
							ifKoditEntrpsProgrsSttusVO.setMrtggDelngTyCode("06");
							// 잔액 세팅
							ifKoditEntrpsProgrsSttusVO.setMrtggBlce(mrtggBlce);
							// 차액 세팅
							ifKoditEntrpsProgrsSttusVO.setMrtggDfnnt(mrtggDfnnt);
							// 차액 콤마 문자열
							ifKoditEntrpsProgrsSttusVO.setMrtggDfnntStr(mrtggDfnntStr);

							// 차액이 0이면 기간변경 양수면 증액, 차액이 마이너스면 감액
//							if(mrtggDfnnt > 0) {
//								//갱신(증액)
//								ifKoditEntrpsProgrsSttusVO.setMrtggCndChangeDetailCode("02");
//							} else if(mrtggDfnnt < 0) {
//								//갱신(감액)
//								ifKoditEntrpsProgrsSttusVO.setMrtggCndChangeDetailCode("03");
//							} else {
//								//갱신(기간변경)
//								ifKoditEntrpsProgrsSttusVO.setMrtggCndChangeDetailCode("04");
//							}
						} else if ("50".equals(grntyProgrsSttusCode)) {
							// 해지
							ifKoditEntrpsProgrsSttusVO.setMrtggDelngTyCode("07");
							// 종결
							// ifKoditEntrpsProgrsSttusVO.setMrtggCndChangeDetailCode("05");
							// 갱신 전 잔액 조회
							// mrtggBlce =
							// mbEntrpsMrtggCntrctBasMapper.selectMrtggBlce(ifKoditEntrpsProgrsSttusVO);
							// 이전한도 조회
							// grntyAmount =
							// mbEntrpsMrtggCntrctBasMapper.selectGrntyAmount(ifKoditEntrpsProgrsSttusVO);
							// 잔액 = 이전잔액-이전한도
							// mrtggBlce = mrtggBlce-grntyAmount;
							// 이전잔액
							ifKoditEntrpsProgrsSttusVO.setMrtggBlce(mrtggBlce);
							// 적요
							ifKoditEntrpsProgrsSttusVO.setMrtggDfnntStr(mrtggDfnntStr);
						}

						if (!"40".equals(grntyProgrsSttusCode)) {
							// 40 갱신은 다음 스텝에서 insert
							result = mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMbEntrpsMrtggLmtDtl(ifKoditEntrpsProgrsSttusVO);

							if (result > 0) {
								mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMbEntrpsMrtggLmtDtlHst(ifKoditEntrpsProgrsSttusVO);
							} else {
								log.error(ex.getMessage());
								throw ex;
							}
						}

						// 50 해지인 경우 업체의 전자상거래보증 해지여부, 해지일시를 업데이트한다.
						if ("50".equals(grntyProgrsSttusCode)) {
							result = mbEntrpsMrtggCntrctBasMapper.updateMbEntrpsMrtggGrntyTrmnatAt(ifKoditEntrpsProgrsSttusVO);
							mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsInfoBasHst(ifKoditEntrpsProgrsSttusVO);
//							if (result > 0) {
//								mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsInfoBasHst(ifKoditEntrpsProgrsSttusVO);
//							} else {
//								log.error(ex.getMessage());
//								throw ex;
//							}
						}

						// 해지일경우 적립예정 마일리지 소멸
						if ("50".equals(grntyProgrsSttusCode)) {
							if (lastSelngAchivrt < 100) {

								mbEntrpsMrtggCntrctBasVO.setGrntyNo(ifKoditEntrpsProgrsSttusVO.getGrntyNo());
								mbEntrpsMrtggCntrctBasVO.setEntrpsNo(entrpsNo);

								// 달성율 100%이하 구분-02:적립예정, 유형-08:수수료 마일리지 소멸처리
								mlgDtlList = mbEntrpsMrtggCntrctBasMapper.selectMbEntrpsMlgInfoDtlList(mbEntrpsMrtggCntrctBasVO);

								if (mlgDtlList.size() > 0) {

									remndrMlgCnt = mbEntrpsMrtggCntrctBasMapper.selectRemndrMlgCnt(mbEntrpsMrtggCntrctBasVO);

									if (remndrMlgCnt > 0) {
										// 잔여마일리지 조회
										remndrMlg = mbEntrpsMrtggCntrctBasMapper.selectRemndrMlg(mbEntrpsMrtggCntrctBasVO);
									} else {
										remndrMlg = 0;
									}

									for (MbEntrpsMrtggCntrctBasVO mlgVO : mlgDtlList) {

										mlgSn = mlgVO.getMlgSn();

										mlgVO.setFrstRegisterId("BATCH_MRTGG_CNTRCT1");
										mlgVO.setLastChangerId("BATCH_MRTGG_CNTRCT1");
										mlgVO.setMlgTy("05"); // 소멸(05)
										mlgVO.setMlgDetailDtls("[" + mlgVO.getOrderNo() + "] 전자상거래보증 계약해지에 따른 소멸");
										mlgVO.setRemndrMlg(remndrMlg);

										result = mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMlgInfoDtl(mlgVO);
										if (result > 0) {
											mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMlgInfoDtlHst(mlgVO);
										} else {
											log.error(ex.getMessage());
											throw ex;
										}

										mlgVO.setMlgSn(mlgSn);
										// 원본데이터 소멸여부 Y로 업데이트
										result = mbEntrpsMrtggCntrctBasMapper.updateMbEntrpsMlgInfoDtl(mlgVO);
										if (result > 0) {
											mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMlgInfoDtlHst(mlgVO);
										} else {
											log.error(ex.getMessage());
											throw ex;
										}
									}
								}
							}
						}
					}

					if (result > 0) {
						insertCnt++;
					}
					// 8. 보증진행상태 30(발급완료),40(조건변경),50(해지)인 데이터는 IF_KODIT_ENTRPS_PROGRS_STTUS 와
					// IF_KODIT_ENTRPS_PROGRS_STTUS 2개 테이블 모두 원장적용여부를 Y로 업데이트한다.
					// IF_KODIT_ENTRPS_PROGRS_STTUS 원장반영여부 Y로 업데이트
					ifKoditEntrpsProgrsSttusVO.setGrntyProgrsSttusCode("10");
					result = mbEntrpsMrtggCntrctBasMapper.updateLedgrReflctAt(ifKoditEntrpsProgrsSttusVO);
					if (result < 1) {
						log.error(ex.getMessage());
						throw ex;
					}
					// IF_KODIT_ENTRPS 원장반영여부 Y로 업데이트
					ifKoditEntrpsProgrsSttusVO.setGrntyProgrsSttusCode(grntyProgrsSttusCode);
					ifKoditEntrpsProgrsSttusVO.setIntrfcSn(ifKoditEntrpsVO.getIntrfcSn());
					result = mbEntrpsMrtggCntrctBasMapper.updateLedgrReflctAt(ifKoditEntrpsProgrsSttusVO);
					if (result < 1) {
						log.error(ex.getMessage());
						throw ex;
					}
				}
			} else {
				// 진행상태 10,20,30,40,50 아닐 때
			}
		}
		log.debug("IF 전자상거래보증 계약 신규 대상 건수 ========>" + ifKoditEntrpsProgrsSttusList.size());
		log.debug("IF 전자상거래보증 계약 신규 건수	 ========>" + insertCnt);
		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 조건변경 전자상거래보증계약의 보증시작기간이 오늘인 전자상거래보증을 조회하고 해당 전자상거래보증의 최종계약여부를 Y로 업데이트한다.
	 * </pre>
	 *
	 * @date 2022. 7. 19.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 19.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@Override
	public int updateEntrpsMrtggCntctBasLastCntrctAt() throws Exception {
		// TODO Auto-generated method stub
		// 1. 보증진행상태 40(조건변경)이고 마지막 계약여부 N이고 배치적용여부가 N이고 보증기간시작일자가 오늘인 데이터를 조회한다.
		List<MbEntrpsMrtggCntrctBasVO> mbEntrpsMrtggCntrctBasList = mbEntrpsMrtggCntrctBasMapper.selectMbEntrpsMrtggCntrctBasList();
		MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO;
		int result = 0;
		int updateCnt = 0;
		long mpFee = 0;
		int terminationCnt = 0;
		int endAtCnt = 0;
		int lastEntrpsMrtggCntrctSnCnt = 0;
		int lastEntrpsMrtggCntrctSn = 0;
		int entrpsMrtggCntrctSnOrg = 0;

		long grntyAmount = 0;
		long mrtggBlce = 0;
		long mrtggDfnnt = 0;
		String mrtggDfnntStr = "";

		String today = DateUtil.getNowDateTime("yyyy-MM-dd");
		CdtlnInfoVO cdtlnInfoVO = bsnInfoService.getCdtlnInfo(today);
		Exception ex = new Exception();

		for (int i = 0; i < mbEntrpsMrtggCntrctBasList.size(); i++) {

			mbEntrpsMrtggCntrctBasVO = mbEntrpsMrtggCntrctBasList.get(i);
			// 해지 계약 카운트 조회
			terminationCnt = mbEntrpsMrtggCntrctBasMapper.selectEntrpsMrtggTerminationCnt(mbEntrpsMrtggCntrctBasVO);
			// 만료 계약 카운트 조회
			endAtCnt = mbEntrpsMrtggCntrctBasMapper.selectEntrpsMrtggEndAtCnt(mbEntrpsMrtggCntrctBasVO);

			// 해지, 만료가 업는 경우
			if (terminationCnt < 1 && endAtCnt < 1) {

				mbEntrpsMrtggCntrctBasVO.setLastChangerId("BATCH_MRTGG_CNTRCT2");
				entrpsMrtggCntrctSnOrg = mbEntrpsMrtggCntrctBasVO.getEntrpsMrtggCntrctSn();

				// 2. 해당 보증계약의 마지막계약 여부 Y인 데이터를 찾아서 마지막계약여부를 N으로 업데이트한다.
				// 접수(10),승인(20),발급완료(30)
				lastEntrpsMrtggCntrctSnCnt = mbEntrpsMrtggCntrctBasMapper.selectLastEntrpsMrtggCnt(mbEntrpsMrtggCntrctBasVO);

				if (lastEntrpsMrtggCntrctSnCnt > 0) {
					// 같은 lastEntrpsMrtggCntrctSnCnt, 사업자번호 데이터 마지마계약여부 N으로 수정
					lastEntrpsMrtggCntrctSn = mbEntrpsMrtggCntrctBasMapper.selectLastEntrpsMrtggSn(mbEntrpsMrtggCntrctBasVO);

					// 마지막 계약여부가 Y인 데이터가 있을 경우만 N으로 업데이트한다.
					if (lastEntrpsMrtggCntrctSn > 0) {
						// 업체담보순번 마지막 계약여부 Y인 순번으로 임시 세팅
						mbEntrpsMrtggCntrctBasVO.setEntrpsMrtggCntrctSn(lastEntrpsMrtggCntrctSn);
						// 이전한도 조회
						grntyAmount = mbEntrpsMrtggCntrctBasMapper.selectGrntyAmount(mbEntrpsMrtggCntrctBasVO);
						// 마지막 계약여부, 배치적용여부 Y로 세팅
						mbEntrpsMrtggCntrctBasVO.setBatchReflctAt("Y");
						result = mbEntrpsMrtggCntrctBasMapper.updateLastEntrpsMrtggSn(mbEntrpsMrtggCntrctBasVO);
						if (result > 0) {
							mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMrtggCntrctBasHst(mbEntrpsMrtggCntrctBasVO);
						} else {
							throw ex;
						}
					}
				}

				// 3. MP 수수료계산
				// MP수수료 계산 보증금액 * 전자상거래보증 MP수수료 비율
				mpFee = (long) (mbEntrpsMrtggCntrctBasVO.getGrntyAmount() * cdtlnInfoVO.getMrtgggrntyMpfeeRate());
				mbEntrpsMrtggCntrctBasVO.setMpFee(mpFee);
				// 업체담보순번 다시 세팅
				mbEntrpsMrtggCntrctBasVO.setEntrpsMrtggCntrctSn(entrpsMrtggCntrctSnOrg);

				// 4. 마지막 계약여부를 Y로 세팅해서 업데이트한다.
				result = mbEntrpsMrtggCntrctBasMapper.updateEntrpsMrtggCntctBasLastCntrctAt(mbEntrpsMrtggCntrctBasVO);
				if (result > 0) {
					mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMrtggCntrctBasHst(mbEntrpsMrtggCntrctBasVO);
				} else {
					throw ex;
				}

				if (result > 0) {
					updateCnt++;

					// 갱신 전 잔액 조회
					mrtggBlce = mbEntrpsMrtggCntrctBasMapper.selectMrtggBlce(mbEntrpsMrtggCntrctBasVO);
					log.debug("갱신 전 잔액 =====>" + mrtggBlce);
					log.debug("이전한도 조회 =====>" + grntyAmount);
					// 보증금액 차액 계산
					mrtggDfnnt = mbEntrpsMrtggCntrctBasVO.getGrntyAmount() - grntyAmount;
					log.debug("보증금액 차액 =====>" + mrtggDfnnt);
					// 갱신 후 잔액 계산
					mrtggBlce = mrtggBlce + mrtggDfnnt;
					log.debug("갱신 후 잔액 =====>" + mrtggBlce);

					if (mrtggDfnnt > 0) {
						// 조건변경(증액) - 갱신(증액)
						mbEntrpsMrtggCntrctBasVO.setMrtggCndChangeDetailCode("02");

						// 조건변경(증액) - 갱신(증액)
						mrtggDfnntStr = "증액";
						// 금액 콤마 처리
						mrtggDfnntStr += "(+" + StringUtil.formatMoney(String.valueOf(mrtggDfnnt)) + ")";
					} else if (mrtggDfnnt < 0) {
						// 조건변경(감액) - 갱신(감액)
						mbEntrpsMrtggCntrctBasVO.setMrtggCndChangeDetailCode("03");

						// 조건변경(감액) - 갱신(감액)
						mrtggDfnntStr = "감액";
						// 금액 콤마 처리
						mrtggDfnntStr += "(" + StringUtil.formatMoney(String.valueOf(mrtggDfnnt)) + ")";
					} else {
						// 조건변경(만료연장) - 기간변경
						mbEntrpsMrtggCntrctBasVO.setMrtggCndChangeDetailCode("04");

						// 조건변경(만료연장) - 기간변경
						mrtggDfnntStr = "갱신";
					}

					log.debug("차액 ==============> " + mrtggDfnnt);
					log.debug("적요 ==============> " + mrtggDfnntStr);

					// 거래금액
					mbEntrpsMrtggCntrctBasVO.setMrtggDelngAmount(mbEntrpsMrtggCntrctBasVO.getGrntyAmount());
					// 갱신
					mbEntrpsMrtggCntrctBasVO.setMrtggDelngTyCode("06");
					// 잔액 세팅
					mbEntrpsMrtggCntrctBasVO.setMrtggBlce(mrtggBlce);
					// 차액 세팅
					mbEntrpsMrtggCntrctBasVO.setMrtggDfnnt(mrtggDfnnt);
					// 차액 콤마 문자열
					mbEntrpsMrtggCntrctBasVO.setMrtggDfnntStr(mrtggDfnntStr);

					result = mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMbEntrpsMrtggLmtDtl(mbEntrpsMrtggCntrctBasVO);
					if (result > 0) {
						mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMbEntrpsMrtggLmtDtlHst(mbEntrpsMrtggCntrctBasVO);
					} else {
						throw ex;
					}
				}
			}
		}

		log.debug("IF 전자상거래보증 계약 갱신 적용 대상 건수 ========>" + mbEntrpsMrtggCntrctBasList.size());
		log.debug("IF 전자상거래보증 계약 갱신 적용 건수	 ========>" + updateCnt);

		return updateCnt;
	}

	/**
	 * <pre>
	 * 처리내용: 기간만료된 담보계약의 만료내역을 insert하고 업체의 전자상거래보증 사용여부를 N으로 업데이트한다.
	 * </pre>
	 *
	 * @date 2022. 7. 19.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 19.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@Override
	public int updateEntrpsMrtggCntctBasCntrctExpiration() throws Exception {
		// TODO Auto-generated method stub
		List<MbEntrpsMrtggCntrctBasVO> mbEntrpsMrtggCntrctExpirationList = mbEntrpsMrtggCntrctBasMapper.selectMbEntrpsMrtggCntrctExpirationList();
		MbEntrpsMrtggCntrctBasVO mbEntrpsMrtggCntrctBasVO;
		int result = 0;
		int updateCnt = 0;
		long mrtggBlce = 0;
		int cndChgCnt = 0;
		int remndrMlgCnt = 0;
		int remndrMlg = 0;
		int mlgSn = 0;

		Exception ex = new Exception();
		List<MbEntrpsMrtggCntrctBasVO> mlgDtlList = null;

		for (int i = 0; i < mbEntrpsMrtggCntrctExpirationList.size(); i++) {

			mbEntrpsMrtggCntrctBasVO = mbEntrpsMrtggCntrctExpirationList.get(i);
			// 조건변경 예약건이 있는경우(조건변경이고 보증기간 시작일이 도래하지 않은 데이터)
			cndChgCnt = mbEntrpsMrtggCntrctBasMapper.selectEntrpsMrtggCndChgCnt(mbEntrpsMrtggCntrctBasVO);
			// 조건변경 예약건이 없는경우 만료처리
			if (cndChgCnt < 1) {
				mbEntrpsMrtggCntrctBasVO.setLastChangerId("BATCH_MRTGG_CNTRCT3");
				// 05 만료
				mbEntrpsMrtggCntrctBasVO.setMrtggDelngTyCode("05");
				// 05 종결
				// mbEntrpsMrtggCntrctBasVO.setMrtggCndChangeDetailCode("05");
				// 거래금액 0
				mbEntrpsMrtggCntrctBasVO.setMrtggDelngAmount(0);
				// 차액 0
				mbEntrpsMrtggCntrctBasVO.setMrtggDfnnt(0);
				// 잔액 조회
				mrtggBlce = mbEntrpsMrtggCntrctBasMapper.selectMrtggBlce(mbEntrpsMrtggCntrctBasVO);
				mbEntrpsMrtggCntrctBasVO.setMrtggBlce(mrtggBlce);

				mbEntrpsMrtggCntrctBasVO.setMrtggDfnntStr("보증서 만료");
				// 계약만료 내역 insert
				result = mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMbEntrpsMrtggLmtDtl(mbEntrpsMrtggCntrctBasVO);
				mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMbEntrpsMrtggLmtDtlHst(mbEntrpsMrtggCntrctBasVO);

				if (result < 1) {
					log.error(ex.getMessage());
					throw ex;
				}

				result = mbEntrpsMrtggCntrctBasMapper.updateMbEntrpsMbEntrpsMrtggEndAt(mbEntrpsMrtggCntrctBasVO);
				if (result > 0) {
					mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMrtggCntrctBasHst(mbEntrpsMrtggCntrctBasVO);
				} else {
					log.error(ex.getMessage());
					throw ex;
				}

				if (result > 0) {
					updateCnt++;

					if (mbEntrpsMrtggCntrctBasVO.getSelngAchivrt() < 100) {
						// 달성율 100%이하 구분-02:적립예정, 유형-08:수수료 마일리지 소멸처리
						mlgDtlList = mbEntrpsMrtggCntrctBasMapper.selectMbEntrpsMlgInfoDtlList(mbEntrpsMrtggCntrctBasVO);

						if (mlgDtlList.size() > 0) {

							remndrMlgCnt = mbEntrpsMrtggCntrctBasMapper.selectRemndrMlgCnt(mbEntrpsMrtggCntrctBasVO);

							if (remndrMlgCnt > 0) {
								// 잔여마일리지 조회
								remndrMlg = mbEntrpsMrtggCntrctBasMapper.selectRemndrMlg(mbEntrpsMrtggCntrctBasVO);
							} else {
								remndrMlg = 0;
							}

							for (MbEntrpsMrtggCntrctBasVO mlgVO : mlgDtlList) {

								mlgSn = mlgVO.getMlgSn();

								mlgVO.setFrstRegisterId("BATCH_MRTGG_CNTRCT3");
								mlgVO.setLastChangerId("BATCH_MRTGG_CNTRCT3");
								mlgVO.setMlgTy("05"); // 소멸(05)
								// mlgVO.setMlgDetailDtls("[" + mlgVO.getOrderNo() + "] 전자상거래보증 계약만료에 따른 소멸");
								mlgVO.setMlgDetailDtls("전자상거래보증 계약만료에 따른 소멸");
								mlgVO.setRemndrMlg(remndrMlg);

								result = mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMlgInfoDtl(mlgVO);
								log.debug("MLG_SN ================>" + mlgVO.getMlgSn());
								if (result > 0) {
									mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMlgInfoDtlHst(mlgVO);
								} else {
									log.error(ex.getMessage());
									throw ex;
								}

								mlgVO.setMlgSn(mlgSn);
								// 원본데이터 소멸여부 Y로 업데이트
								result = mbEntrpsMrtggCntrctBasMapper.updateMbEntrpsMlgInfoDtl(mlgVO);
								if (result > 0) {
									mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsMlgInfoDtlHst(mlgVO);
								} else {
									log.error(ex.getMessage());
									throw ex;
								}
							}
						}
					}
				}

//				if(mbEntrpsMrtggCntrctBasVO.getEntrpsNo() != null && !"".equals(mbEntrpsMrtggCntrctBasVO.getEntrpsNo())) {
//					//업체번호 존재 시 전자상거래보증 미사용으로 업데이트
//					result = mbEntrpsMrtggCntrctBasMapper.updateMbEntrpsMrtggGrntyUseAt(mbEntrpsMrtggCntrctBasVO);
//					mbEntrpsMrtggCntrctBasMapper.insertMbEntrpsInfoBasHst(mbEntrpsMrtggCntrctBasVO);
//
//					if (result < 1) {
//						log.error(ex.getMessage());
//						throw ex;
//					}
//				}
			}
		}

		log.debug("IF 전자상거래보증 계약 만료 대상 건수 ========>" + mbEntrpsMrtggCntrctExpirationList.size());
		log.debug("IF 전자상거래보증 계약 만료 건수	 ========>" + updateCnt);

		return updateCnt;
	}

}
