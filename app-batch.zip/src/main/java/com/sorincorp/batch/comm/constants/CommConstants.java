package com.sorincorp.batch.comm.constants;

public class CommConstants {

	public static final int SUCCESS_CODE = 200;
	public static final String SUCCESS_CODE_STR	= "200";
	public static final int ERROR_CODE = 400;
	public static final String ERROR_CODE_STR = "400";
	public static final String SUCCESS_MSG = "Success";
	public static final String ERROR_MSG = "Error";
	public static final String REPONSE_RESULT_MSG 	= "result_msg";
	public static final String REPONSE_RESULT_DATA 	= "result_data";
	public static final String REPONSE_RESULT_CODE 	= "result_code";
}
