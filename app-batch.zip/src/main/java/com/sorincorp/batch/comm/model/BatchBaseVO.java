package com.sorincorp.batch.comm.model;

import javax.validation.constraints.NotEmpty;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class BatchBaseVO {

	/* 호출 인터페이스 ID */
	@NotEmpty(message = "Interface ID는 필수 값입니다.")
	@ApiModelProperty(value = "인터페이스 ID", example = "EHR-IF-008")
	private String interfaceId;

}
