package com.sorincorp.batch;


import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.EnableScheduling;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@EnableScheduling
@EnableBatchProcessing
@Slf4j
public class AppBatchApplication {


	public static void main(String[] args)	throws JobParametersInvalidException, JobExecutionAlreadyRunningException,
													JobRestartException, JobInstanceAlreadyCompleteException {

			try {
				ConfigurableApplicationContext context = SpringApplication.run(AppBatchApplication.class, args);

				JobLauncher jobLauncher = context.getBean(JobLauncher.class);
				int argsLen = args.length;
				if (argsLen > 0) {

					log.info("실행 배치 잡 이름: "+args[0]);
					//테스트 배치용 배치 배치명
					//Job job = context.getBean("mbDrmncyMberChkJob", Job.class);
					Job job = context.getBean(args[0], Job.class);
					Map<String, JobParameter> jobParamMap = new HashMap<>();
			        jobParamMap.put("time", new JobParameter(System.currentTimeMillis()));
			        if(argsLen == 3 && StringUtils.isNotEmpty(args[2])) { // param01 - 주문번호
			        	jobParamMap.put("param01", new JobParameter(args[2]));
			        }

			        JobParameters jobParameters = new JobParameters(jobParamMap);
					jobLauncher.run(job, jobParameters);
				} else {
					log.error("배치 잡 이름을 입력해 주세요. EX) {}", "java -jar app.jar sampleTestJob1");
				}
			}catch(Exception e) {
				log.error("오류 실행 배치 잡 이름: " + args[0], e);
			}
			System.exit(0);
	}
}
