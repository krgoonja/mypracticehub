package com.sorincorp.batch.ev.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 상시할인 쿠폰 발급 JobConfig
 * OrdtmDscntCouponJobConfig.java
 * @version
 * @since 2024. 01. 06.
 * @author sein
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class OrdtmDscntCouponJobConfig {
	
	@Autowired
	OrdtmDscntCouponTasklet ordtmDscntCouponTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory; 
	
	@Bean
	public Job ordtmDscntCouponJob() {
		return jobBuilderFactory.get("ordtmDscntCouponJob")
				.start(ordtmDscntCouponStep())
				.build();  
	}//end ordtmDscntCouponJob()
	
	@Bean
	@JobScope
	public Step ordtmDscntCouponStep() {
		return stepBuilderFactory.get("ordtmDscntCouponStep")
				.tasklet(ordtmDscntCouponTasklet)
				.build();
	}//end ordtmDscntCouponStep()
	
}//end class()