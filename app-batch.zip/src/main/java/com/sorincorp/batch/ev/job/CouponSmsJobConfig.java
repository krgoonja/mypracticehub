package com.sorincorp.batch.ev.job;

import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 쿠폰 만료 알림톡 배치 JobConfig
 * CouponSmsJobConfig.java
 * @version
 * @since 2023. 8. 16.
 * @author hamyoonsic
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class CouponSmsJobConfig {
	
	@Autowired
	CouponSmsTasklet couponSmsTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory; 
	
	@Bean
	public Job couponSmsJob() {
		return jobBuilderFactory.get("couponSmsJob")
				.start(couponSmsStep())
				.build();  
	}//end CouponJob()
	
	@Bean
	@JobScope
	public Step couponSmsStep() {
		return stepBuilderFactory.get("couponSmsStep")
				.tasklet(couponSmsTasklet)
				.build();
	}//end CouponStep()
	
}//end class()