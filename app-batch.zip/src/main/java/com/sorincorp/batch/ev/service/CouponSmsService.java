package com.sorincorp.batch.ev.service;

/**
 * 쿠폰 만료 알림톡 발송 배치 batch Service(휴일,공휴일 제외)
 * CouponService.java
 * @version
 * @since 2023. 08. 16.
 * @author hamyoonsic
 */
public interface CouponSmsService {
	
	/**
	 * 
	 * <pre>
	 * 쿠폰 만료 현황 조회
	 * </pre>
	 * @date 2023. 08. 16.
	 * @author hamyoonsic
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 16.	  hamyoonsic			    최초작성
	 * ------------------------------------------------
	 */
	void sendCouponSms() throws Exception;
	
}