package com.sorincorp.batch.ev.job;

import com.sorincorp.batch.ev.service.CouponSmsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 쿠폰 만료 알림톡 배치 JobConfig
 * CouponTasklet.java
 * @version
 * @since 2023. 8. 16.
 * @author hamyoonsic
 */
@Slf4j
@Component
public class CouponSmsTasklet implements Tasklet, StepExecutionListener {
	
	@Autowired
	CouponSmsService couponSmsService;
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("CouponTasklet::beforeStep");
	}//end beforeStep()
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("CouponTasklet::execute Start");

		couponSmsService.sendCouponSms();
		
		log.debug("CouponTasklet::execute End");
		return RepeatStatus.FINISHED;
	}//end execute()
	
	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("CouponTasklet::afterStep");
        return ExitStatus.COMPLETED;
	}//end afterStep()

}//end class()