package com.sorincorp.batch.ev.model;

import java.sql.Timestamp;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 결제예정액 관리 OrdtmDscntCouponVO.java
 * @version
 * @since 2024. 01. 16.
 * @author sein
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class OrdtmDscntCouponVO extends CommonVO {

    /**
     * 알림톡 순위
     */
    private String couponRank;
    
    /**
     * 전월까지 최대 구매 수량
     */
    private int toLsmthMxmmPurchsMt;
    /**
     * 전월까지 최저 구매 수량
     */
    private int toLsmthMinPurchsMt;
    
    /**
     * 구매 시작일부터 전월까지 합산 구매 수량
     */
    private int toLsmthAdupPurchsMt;

    /**
     * 구매 시작일부터 전체 구매 수량
     */
    private int toLsmthAvrgPurchsMt;
    
    /**
     * 구매 시작일부터 전달까지 기간
     */
    private int lsmthDe;
    
    /**
     * 올림(전체 기간에 대한 평균 중량 / 25) * 25 
     */
    private int ceilAvgTotRealOrderWt;
    
    /**
     * 버림(전체 기간에 대한 평균 중량 / 25) * 25 
     */
    private int floorAvgTotRealOrderWt;
    
    /**
     * 당월 합산 구매 수량
     */
    private int thsmonAdupPurchsMt;

    /**
     * 최대 구매 수량 달성 여부 Y/N
     */
    private String mxmmPurchsMtAchivAt;
 
    /**
     * 평균 구매 수량 달성 여부 Y/N
     */
    private String avrgPurchsMtRisingAt;
    
    /**
     * 평균 구매 수량 유지 여부 Y/N
     */
    private String avrgPurchsMtMntncAt;

    /**
     * 쿠폰 유효월
     */
    private int couponValidMth;
    
	/** EV_PROMTN_INFO_BAS*/	
	
	/**
	 * 프로모션 명
	 */
	private String promtnNm; 

	/**
	 * 프로모션 번호
	 */
	private String promtnNo; 
	
	/** CP_COUPON_INFO_DTL*/
	/**
	 * 쿠폰 상세 번호
	 */
	private String couponDtlNo; 
	/**
	 * 쿠폰 번호
	 */
	private String couponNo; 
	/**
	 * 적용 주문 타입 코드
	 */
	private String orderTyCode;
	/**
	 * 적용 주문 타입 코드 명
	 */
	private String orderTyName;
	/**
	 * 쿠폰 타입 코드
	 */
	private String couponTyCode;
	/**
	 * 쿠폰 타입 코드
	 */
	private String couponTyCodeNm;
	/**
	 * 쿠폰 타입 코드 명
	 */
	private String couponTyName;
	/**
	 * 금속
	 */
	private String metalCode;
	/**
	 * 금속명
	 */
	private String metalName;
	/**
	 * 브랜드코드
	 */
	private String brandCode;  
	/**
	 * 톤수
	 */
	private int mt;  
	/**
	 * 지정 BL 번호
	 */
	private String appnBlNo;  
	/**
	 * 단가 할인 금액
	 */
	private int untpcDscntAmount;
	/**
	 * 단가 쿠폰 총 할인 금액
	 */
	private int untpcCouponTotalAmount;
	/**
	 * 총액 할인 금액
	 */
	private int totalUntpcAmount;
	/**
	 * 쿠폰 시작 일시
	 */
	private String couponBgnde;
	/**
	 * 쿠폰 종료 일시
	 */
	private String couponEndde;
	/**
	 * 중복 사용 여부
	 */
	private String dplctAt; 
	/**
	 * 임시 저장 여부
	 */
	private String tmprStreAt; 
	/**
	 * 발행 일자
	 */
	private String isuDt; 
	/**
	 * 발행자 아이디
	 */
	private String isuId; 
	/**
	 * 배송비 적용 차수
	 */
	private int dlvrfApplcOdr; 
	/**
	 * 배송비 권역 정보
	 */
	private String dlvrfDstrctInfo; 
	/**
	 * 삭제 여부
	 */
	private String deleteAt;  
	/**
	 * 삭제 일시
	 */
	private Timestamp deleteDt;  
	/**
	 * 쿠폰명
	 */
	private String couponNm;  
	
/** CP_COUPON_ISU_BAS*/
	/**
	 * 쿠폰 일련 번호
	 */
	private String couponSn;  
    /**
    * 업체 번호
   */
   private String entrpsNo; 
   /**
    * 대상 연월
    */
   private String trgetYm; 
    /**
    * 쿠폰 적용 주문 번호
   */
   private String couponApplcOrderNo; 
   /**
	 * 쿠폰 할인 적용 금액
	 */
	private int couponDscntApplcAmount;
	/**
	 * 쿠폰 발급 코드
	 */
   private String couponIssuCode;    
   /**
    * 자동 재발행 여부
    */
   private String atmIsgnAt;    
	
/** 공통VO*/
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId; 
	/**
	 * 최초 등록 일시
	 */
	private Timestamp frstRegistDt; 
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId; 
	/**
	 * 최종 변경 일시
	 */
	private Timestamp lastChangeDt; 
	/**
	 * 최종 변경자 아이디
	 */
	private String fieldName; 
    /**
    * 쿠폰 사용 여부
   */
   private String couponUseAt; 
    /**
    * 쿠폰 사용자 아이디
   */
   private String couponUseId; 
    /**
    * 쿠폰 사용 일시
   */
   private Timestamp couponUseDt; 
   /**
   * 업체명 한글
   */
   private String entrpsnmKorean;
   /**
   * 배송지
   */
   private String receptEntrpsAdres;     
   /**
   * 쿠폰 상태 코드
   */
   private String couponSttusCode; 
   /**
   * 주문 일자
   */
   private String orderDe;    
   /**
   * 쿠폰 적용 기간
   */
   private String couponPeriod;   
   /**
   * 발행 제한 금액
   */
   private String isuLmttAmount;
   /**
   * 발행 제한 수량
   */
   private String isuLmttQuantity;
   /**
   * 사용 금액
   */
   private int totalAmount;
   /**
   * 사용 수량
   */
   private int totalQuantity;
   /**
    * 발행 가능 잔액
    */
   private String isPossBlce;
	/**
	 * 발행 가능 수량
	 */
	private String isPossPrchas;
   /**
	 * 발행 쿠폰명
	 */
   private String isuCouponNm; 
	/**
	 * 업체 발행수량
	 */
	private int entrpsIsuCount; 
	/**
	 * 모달 상태 (insert/update)
	 */
	private String modalPageStatus;
	/**
	 * 사용중인 쿠폰 수
	 */
	private String couponUseCount;
	/**
	 * 회원번호
	 */
	private String mberNo;
	/**
	 * 휴대전화 번호
	 */
	private String moblphonNo;
	/**
	 * 삭제 이유
	 */
	private String deleteResn;

	
	/**
	 * 단가(UntPcCoupon), 배송비(UntPcCoupon) 상태 
	 */
	private String activeTabVal;
    
}
