package com.sorincorp.batch.ev.mapper;

import java.util.List;

import com.sorincorp.batch.ev.model.OrdtmDscntCouponVO;

public interface OrdtmDscntCouponMapper {


	 
	

	/**
	 * <pre>
	 * 월말 기준 (배치 오후 11시 50분) 상시할인 가능 기업 조회
	 * </pre>
	 * @date 2024. 01. 06
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 06  		sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<OrdtmDscntCouponVO> selectOrdtmDscntCouponList()throws Exception;


	/**
	 * <pre>
	 * 월말 기준 (배치 오후 11시 50분) 상시할인 가능 기업 조회 알림톡
	 * </pre>
	 * @date 2024. 01. 06
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 06  		sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<OrdtmDscntCouponVO> selectMberInfoList(OrdtmDscntCouponVO ordtmDscntCouponVO)throws Exception;
	/**
	 * <pre>
	 * 회원_업체 월별 구매 혜택과 프로모션_자동발행 쿠폰 정보 조회
	 * MB_ENTRPS_MNBY_PURCHS_BNEF_BAS,  CP_ATMC_ISU_COUPON_INFO_BAS 쿠폰 정보 가져오기
	 * </pre>
	 * @date 2024. 01. 06
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 06  		sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<OrdtmDscntCouponVO> selectMbPurchsCpAtmcIsuCouponInfoList(String atmcIsuCndCode1, String atmcIsuCndCode2, String atmcIsuCndCode3)throws Exception;
	
	/**
	 * <pre>
	 * 상시할인 가능 회원 업체 월별 구매 혜택 상태 insert 
	 * </pre>
	 * @date 2024. 01. 06
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 06  		sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	void insertMbEntrpsMnbyPurchsBnefBas(OrdtmDscntCouponVO ordtmDscntCouponVO)throws Exception;
	
	/**
	 * <pre>
	 * 상시할인 가능 시 쿠폰 정보 상세 insert
	 * </pre>
	 * @date 2024. 01. 06
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 06  		sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	void insertCpCouponInfoDtl(OrdtmDscntCouponVO ordtmDscntCouponVO)throws Exception;
	
	/**
	 * <pre>
	 * 쿠폰발행 :  쿠폰발행테이블 insert
	 * <pre>
	  * @date 2024. 01. 06
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 06  		sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	int insertCouponIsu(OrdtmDscntCouponVO ordtmDscntCouponVO);
	
	/**
	 * <pre>
	 * 쿠폰발행 알림톡 발송을 위한 정보조회	 
	 * <pre>
	 * @date 2024. 01. 06
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 06  		sein					최초작성
	 * ------------------------------------------------
	 * @return
	 *
	*/
	OrdtmDscntCouponVO getCouponSmsInfo(OrdtmDscntCouponVO ordtmDscntCouponVO)throws Exception;

	/**
	 * <pre>
	 *프로모션 번호를 가지고 회원_업체 월별 구매 혜택 기본(CP_COUPON_INFO_BAS) SELECT 
	 * <pre>
	 * @date 2024. 01. 06
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 06  		sein					최초작성
	 * ------------------------------------------------
	 * @return
	 *
	 */
	OrdtmDscntCouponVO selectCpAtmcIsuCouponInfoBas(String atmcIsuCndCode)throws Exception;
	
	/**
	 * <pre>
	 * 페이백 등급 업데이트(당월 판매수량 기준)
	 * <pre>
	 * @date 2024. 02. 07
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 02. 07  		sein					최초작성
	 * ------------------------------------------------
	 * @return
	 *
	 */
	void updateMbEntrpsGrad();
	
	/**
	 * <pre>
	 * MB_ENTRPS_MNBY_PURCHS_BNEF_BAS update 
	 * 당월 등급 할인 금액(THSMON_GRAD_DSCNT_AMOUNT)
	 * 당월 주문 등급 할인 적용 총 금액(THSMON_ORDER_GRAD_DSCNT_APPLC_TOT_AMOUNT)
	 * 당월 주문 상시 할인 적용 총 금액(THSMON_ORDER_ORDTM_DSCNT_APPLC_TOT_AMOUNT)
	 * <pre>
	 * @date 2024. 02. 27
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 02. 27  		sein					최초작성
	 * ------------------------------------------------
	 * @return
	 *
	 */
	void updateMbEntrpsMnbyPurchsBnefBas();
}
