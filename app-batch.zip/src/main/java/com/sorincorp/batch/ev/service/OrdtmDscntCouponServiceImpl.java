package com.sorincorp.batch.ev.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.batch.ev.mapper.OrdtmDscntCouponMapper;
import com.sorincorp.batch.ev.model.OrdtmDscntCouponVO;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OrdtmDscntCouponServiceImpl implements OrdtmDscntCouponService {

	@Autowired
	OrdtmDscntCouponMapper ordtmDscntCouponMapper;
	
	@Autowired
	AssignService assignService;
	
	@Autowired
	CommonService commonService;
	/** 알림톡 발송 서비스 */
	@Autowired
	SMSService smsService;

	/**
	 * 상시할인 쿠폰 발행
	 * */
	
	/**
	 * <pre>
	 * 처리내용: 상시할인 쿠폰 발행
	 * </pre>
	 * @date 2024. 1. 17.
	 * @author tpdls7080
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 1. 17.				tpdls7080			최초작성
	 * 2024.06. 07.				hyunjin05			할인 제외 업체 공통화 추가
	 * ------------------------------------------------
	 * @param 
	 * @return
	 * @throws Exception
	 */
	@Transactional(rollbackFor = Exception.class)
	@Override
	public void ordtmDscntCouponIsgn() throws Exception {
		
		//페이백 쿠폰 발행
		log.debug("OrdtmDscntCouponServiceImpl:ordtmDscntCouponIsgn 상시할인 쿠폰 발행 Start");
		try {
	        /** 전월 기준 상시할인 가능 기업 리스트(Y,N)
	         *  1. 최고 구매 수량 달성 고객 감사 혜택 ("01")
	         *  2. 평균 수량 이상 구매 고객 감사 혜택 ("02")
	         *  3. 평균 구매 수량 유지 고객 감사 혜택 ("03") **/
			// ordtmDscntCouponList - 상시 할인 제외 업체 공통 추가 2024.06.07
			List<OrdtmDscntCouponVO> ordtmDscntCouponList = ordtmDscntCouponMapper.selectOrdtmDscntCouponList();
			if (ordtmDscntCouponList.size() == 0){
				log.debug("OrdtmDscntCouponServiceImpl:ordtmDscntCouponIsgn 상시할인 쿠폰 발행 기업 없음 End");
			}else{
				int mxmmCnt = 0;
				int avrgRisingCnt = 0;
				int avrgMntncCnt = 0;
				//COUPON_DTL_NO 담기(LIST)
				List<String> couponDtlNoList = new ArrayList<>();
				// 회원_업체 월별 구매 혜택 기본(CP_COUPON_INFO_BAS) insert 및 CP_COUPON_INFO_DTL에 insert할 상시할인 개수
				for (OrdtmDscntCouponVO vo : ordtmDscntCouponList) {
					//코랄,한강,무원상사,무원메탈 제외(하드코딩)
					// 상시 할인 제외 업체 - 공통으로 변경 - 2024.06.07
//					if (!vo.getEntrpsNo().equals("C0134") && !vo.getEntrpsNo().equals("C0138")
//							&& !vo.getEntrpsNo().equals("C0273") && !vo.getEntrpsNo().equals("C0284")) {
						
						//회원_업체 월별 구매 혜택 기본 CP_COUPON_INFO_BAS INSERT
						ordtmDscntCouponMapper.insertMbEntrpsMnbyPurchsBnefBas(vo);
						//쿠폰 정보 상세 CP_COUPON_INFO_DTL 단가/지정가 상시 할인 발급 INSERT
						if (vo.getMxmmPurchsMtAchivAt().equals("Y") && mxmmCnt == 0) {
							OrdtmDscntCouponVO mxmm = ordtmDscntCouponMapper.selectCpAtmcIsuCouponInfoBas("01");
							mxmmCnt++;
							insertCpCouponInfoDtl(mxmm,couponDtlNoList);
						} else if (vo.getMxmmPurchsMtAchivAt().equals("N")
								&& vo.getAvrgPurchsMtRisingAt().equals("Y") && avrgRisingCnt == 0) {
							OrdtmDscntCouponVO avrgRising = ordtmDscntCouponMapper.selectCpAtmcIsuCouponInfoBas("02");
							avrgRisingCnt++;
							insertCpCouponInfoDtl(avrgRising,couponDtlNoList);
						} else if (vo.getMxmmPurchsMtAchivAt().equals("N")
								&& vo.getAvrgPurchsMtRisingAt().equals("N")
								&& vo.getAvrgPurchsMtMntncAt().equals("Y") && avrgMntncCnt == 0) {
							OrdtmDscntCouponVO avrgMntnc = ordtmDscntCouponMapper.selectCpAtmcIsuCouponInfoBas("03");
							avrgMntncCnt++;
							insertCpCouponInfoDtl(avrgMntnc,couponDtlNoList);
						}
//					}
				}
				
				// MB_ENTRPS_MNBY_PURCHS_BNEF_BAS , CP_ATMC_ISU_COUPON_INFO_BAS 로 구현 (  1 : "01", 2 : "02", 3 : "03") 
				List<OrdtmDscntCouponVO> mbPuchsCpAtmcIsuCouponInfoList = ordtmDscntCouponMapper.selectMbPurchsCpAtmcIsuCouponInfoList("01","02","03");
				for (OrdtmDscntCouponVO vo : mbPuchsCpAtmcIsuCouponInfoList) {
					//CP_COUPON_INFO_DTL만들면서 생성된 COUPON_DTL_NO이 같을 시 ISU테이블 insert
					for(String list: couponDtlNoList) {
						if(list.equals(vo.getCouponDtlNo())) {
							if("03".equals(vo.getOrderTyCode())) {    //지정가 주문
								int count = 0;
								while (count < 10) {
									vo.setCouponSn("CP-"+DateUtil.getNowDateTime("yyyyMM")+"-"+ assignService.selectAssignValue("CP", "COUPON_SN", DateUtil.calDate("yyyy"), "SYSTEM", 5));
									ordtmDscntCouponMapper.insertCouponIsu(vo);
									commonService.insertTableHistory("CP_COUPON_ISU_BAS", vo);
									count++;
								}
								//SMS 기본 설정
								OrdtmDscntCouponVO couponSmsVO = ordtmDscntCouponMapper.getCouponSmsInfo(vo);
								// 템플릿 번호
								String templateNum = "122";
								if(!StringUtils.isEmpty(templateNum)) {
									//알림톡 발송
									procSms(couponSmsVO, templateNum);
								}
							} else {
								vo.setCouponSn("CP-"+DateUtil.getNowDateTime("yyyyMM")+"-"+ assignService.selectAssignValue("CP", "COUPON_SN", DateUtil.calDate("yyyy"), "SYSTEM", 5));
								ordtmDscntCouponMapper.insertCouponIsu(vo);
								commonService.insertTableHistory("CP_COUPON_ISU_BAS", vo);
								//SMS 기본 설정
								OrdtmDscntCouponVO couponSmsVO = ordtmDscntCouponMapper.getCouponSmsInfo(vo);
								// 템플릿 번호
								String templateNum = "122";
								if(!StringUtils.isEmpty(templateNum)) {
									//알림톡 발송
									procSms(couponSmsVO, templateNum);
								}
							}
						}
					}
				}
				//MB_ENTRPS_MNBY_PURCHS_BNEF_BAS update 
				//(당월 등급 할인 금액(THSMON_GRAD_DSCNT_AMOUNT), 당월 주문 등급 할인 적용 총 금액(THSMON_ORDER_GRAD_DSCNT_APPLC_TOT_AMOUNT), 당월 주문 상시 할인 적용 총 금액(THSMON_ORDER_ORDTM_DSCNT_APPLC_TOT_AMOUNT))
				ordtmDscntCouponMapper.updateMbEntrpsMnbyPurchsBnefBas();
				//페이백 등급 할인 업데이트
				//코랄,한강,무원상사,무원메탈 제외(하드코딩)
				// 상시 할인 제외 업체 - 공통으로 변경 - 2024.06.07
				ordtmDscntCouponMapper.updateMbEntrpsGrad();
				
				log.debug("OrdtmDscntCouponServiceImpl:ordtmDscntCouponIsgn 상시할인 쿠폰 발행 완료 End");
			}
		} catch (Exception e) {
			log.debug("OrdtmDscntCouponServiceImpl::ordtmDscntCouponIsgn exception = " + e.getMessage());
		}
	}
		
	
	
	public void insertCpCouponInfoDtl(OrdtmDscntCouponVO vo, List<String> couponDtlNoList) throws Exception {
		//CP_COUPON_INFO_DTL 생성(LIVE)
		vo.setOrderTyCode("01");
		vo.setCouponDtlNo(DateUtil.getNowDate()+ "-C" + assignService.selectAssignValue("CP", "COUPON_DTL_NO", DateUtil.calDate("yyyy"), "SYSTEM", 5));
		couponDtlNoList.add(vo.getCouponDtlNo());
		ordtmDscntCouponMapper.insertCpCouponInfoDtl(vo); 
		commonService.insertTableHistory("CP_COUPON_INFO_DTL", vo);
		//CP_COUPON_INFO_DTL 생성(지정가)
		vo.setOrderTyCode("03");
		vo.setCouponDtlNo(DateUtil.getNowDate()+ "-C" + assignService.selectAssignValue("CP", "COUPON_DTL_NO", DateUtil.calDate("yyyy"), "SYSTEM", 5));
		couponDtlNoList.add(vo.getCouponDtlNo());
		ordtmDscntCouponMapper.insertCpCouponInfoDtl(vo); 
		commonService.insertTableHistory("CP_COUPON_INFO_DTL", vo);
		//CP_COUPON_INFO_DTL 생성(계약구매)
		vo.setOrderTyCode("04");
		vo.setCouponDtlNo(DateUtil.getNowDate()+ "-C" + assignService.selectAssignValue("CP", "COUPON_DTL_NO", DateUtil.calDate("yyyy"), "SYSTEM", 5));
		couponDtlNoList.add(vo.getCouponDtlNo());
		ordtmDscntCouponMapper.insertCpCouponInfoDtl(vo); 
		commonService.insertTableHistory("CP_COUPON_INFO_DTL", vo);
	}
	
	/** 쿠폰발행 알림톡 발송 */
	public void procSms(OrdtmDscntCouponVO couponSmsVO, String templateNum) throws Exception {

		log.debug("OrdtmDscntCouponServiceImpl::procSms 상시할인 쿠폰 발행 : 쿠폰 발행 알림톡 발송 Start");
		try {
			SMSVO smsVO = new SMSVO();
			String entrpsNo = couponSmsVO.getEntrpsNo();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
			smsVO.setCommerceNtcnAt("Y"); //커머스 전송 여부
			List<OrdtmDscntCouponVO> mberList = ordtmDscntCouponMapper.selectMberInfoList(couponSmsVO);

			//같은 업체명을 가진 모든 회원에게 알림톡 전송
			for(OrdtmDscntCouponVO vo : mberList){
				smsVO.setMberNo(vo.getMberNo());
				smsVO.setPhone(vo.getMoblphonNo());
				// MB_MBER_INFO_BAS(회원_회원 정보 기본) - MOBLPHON_NO(휴대전화 번호) 복호화
				String phone = String.valueOf(smsVO.getPhone());
				if(StringUtils.isNotEmpty(phone) && !phone.equals("null")) {
					try {
						log.debug("휴대전화 번호 복호화 전 ==================>" + phone);
						phone = CryptoUtil.decryptAES256(phone);
						log.debug("휴대전화 번호 복호화 후 ==================>" + phone);
						/** 휴대전화 번호 셋팅 **/
						smsVO.setPhone(phone);
					} catch(Exception e) {
						log.error("OrdtmDscntCouponServiceImpl procSms MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
					}
				}

				Map<String, String> smsMap = new HashMap<>();

				smsMap.put("couponNm",couponSmsVO.getCouponNm());						//쿠폰명
				smsMap.put("metalName",couponSmsVO.getMetalName());						//메탈명
				if(couponSmsVO.getMt()==0) {
					smsMap.put("mt", "무관");																	//톤수
				}else {
					smsMap.put("mt", couponSmsVO.getMt()+"");											//톤수
				}
				smsMap.put("couponTyName",couponSmsVO.getCouponTyName());			//쿠폰타입
				smsMap.put("orderTyName",couponSmsVO.getOrderTyName());				//쿠폰타입
				smsMap.put("couponBgnde",couponSmsVO.getCouponBgnde());				//쿠폰시작일자
				smsMap.put("couponEndde",couponSmsVO.getCouponEndde());				//쿠폰마감일자
				smsMap.put("dlvrfApplcOdr", "1");														//차수 : 1 고정
				smsMap.put("dlvrfDstrctInfo", "전체");													//구간 : 전체
				smsMap.put("templateNum", templateNum); 										// 템플릿 번호
				smsMap.put("excpSndngOptnAt","N");													//예외 발송 여부
				smsService.insertSMS(smsVO, smsMap);
			}
		} catch (Exception e) {
			log.debug("OrdtmDscntCouponServiceImpl::procSms exception = " + e.getMessage());
		}

	}
}