package com.sorincorp.batch.ev.mapper;

import com.sorincorp.batch.ev.model.CouponSmsVO;

import java.util.List;

public interface CouponSmsMapper {


	/**
	 * <pre>
	 * 주말, 공휴일 확인
	 * </pre>
	 * @date 2023. 08. 16
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 16	  			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	int selectLastBsnDe()throws Exception;
	
	
	/**
	 * <pre>
	 * 당일 기준 (배치 오전 9시) 쿠폰 만료 내역 조회
	 * </pre>
	 * @date 2023. 08. 16
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 16	   			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<CouponSmsVO> selectCouponInfoList()throws Exception;

	/**
	 * <pre>
	 * 쿠폰 만료 업체의 회원 조회
	 * </pre>
	 * @date 2023. 08. 16
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 16	   		hamyoonsic			    최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<CouponSmsVO> selectMberInfoList(CouponSmsVO couponSmsVO)throws Exception;
	
	/**
	 * <pre>
	 * 쿠폰 종료 일시가 지난 상태(01:사용전, 05:사용중) 인 쿠폰 기한만료로 변경 
	 * </pre>
	 * @date 2023. 10. 25
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 25			sein		 		    최초작성
	 * ------------------------------------------------
	 * @return
	 */
	void updateCouponInfoList() throws Exception;
	
}
