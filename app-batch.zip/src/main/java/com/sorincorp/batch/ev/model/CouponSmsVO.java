package com.sorincorp.batch.ev.model;

import com.sorincorp.comm.model.CommonVO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 결제예정액 관리 NpyArrrgInfoVO.java
 * @version
 * @since 2023. 01. 20.
 * @author srec0076
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CouponSmsVO extends CommonVO {

	/**
     * 쿠폰명
    */
    private String couponNm;
    
    /**
     * 메탈명
     * */
    private String metalName;
    
    /**
     * 중량
     * */
    private String mt;
    
    /**
     * 쿠폰타입명
     */
    private String couponTyName;
    
    /**
     * 쿠폰 시작 일시
     * */
    private long couponBgnde;
    
	/**
     * 쿠폰 종료 일시
    */
    private String couponEndde;

    /**
     * 알림톡 순위
     */
    private String couponRank;

    /**
     * 업체 번호
     */
    private String entrpsNo;

    /**
     * 회원 번호
     */
    private String mberNo;

    /**
     * 휴대전호 번호
     */
    private String moblphonNo;

    
}
