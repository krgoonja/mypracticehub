package com.sorincorp.batch.ev.service;

import com.sorincorp.batch.ev.mapper.CouponSmsMapper;
import com.sorincorp.batch.ev.model.CouponSmsVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class CouponSmsServiceImpl implements CouponSmsService {

	@Autowired
	private CouponSmsMapper couponSmsMapper;

	/** 알림톡 발송 서비스 */
	@Autowired
	SMSService smsService;

	/**
	 * 쿠폰 만료 알림톡 발송
	 * */
	@Transactional(rollbackFor = Exception.class)
	@Override
	public void sendCouponSms() throws Exception {

		//쿠폰 만료 알림톡 발송
		log.debug("HAM :: CouponSmsServiceImpl:sendCouponSms 쿠폰 만료 알림톡 발송 Start");
        
        // 당일이 휴일 혹은 공휴일인지 확인
		int lastBsnDe = couponSmsMapper.selectLastBsnDe();
 
		if(lastBsnDe == 0) {
			log.debug("주말, 휴일이 아니므로 실행");
			
			// 기간 만료 쿠폰 상태 값 업데이트
			couponSmsMapper.updateCouponInfoList();
			
	        // 쿠폰 만료 현황 조회
	        List<CouponSmsVO> couponInfo = couponSmsMapper.selectCouponInfoList();

			SMSVO smsVO = new SMSVO();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
			smsVO.setCommerceNtcnAt("Y"); // 커머스 알림 여부
			for (CouponSmsVO vo : couponInfo) {
				Map<String, String> smsMap = new HashMap<>();
				String templateNum = "";

				//쿠폰 만료 업체의 회원목록 조회
				List<CouponSmsVO> mberInfo = couponSmsMapper.selectMberInfoList(vo);
				if (vo.getCouponRank() == null || vo.getCouponRank().trim().isEmpty()) {
					log.debug("HAM :: CouponSmsServiceImpl:sendCouponSms 쿠폰 만료 내역 없음 End");
				} else {
					switch (vo.getCouponRank()) {//알림톡 템플릿 번호 셋팅
					case "1":	// 당일 만료
						templateNum = "125";
						break;
					case "2":	// 만료 하루 전
						templateNum = "124";
						break;
					case "3":	// 만료 3일 전
						templateNum = "123";
						break;
					}
					// 해당 업체의 모든 회원에게 알림톡 발송
					for(CouponSmsVO dataVO : mberInfo){
						try {
							smsVO.setMberNo(dataVO.getMberNo());	//알림톡 발송 회원 번호
							smsVO.setPhone(dataVO.getMoblphonNo()); // 알림톡 발송 대상 전화번호
							//휴대전화 번호 복호화
							String phone = String.valueOf(smsVO.getPhone());
							if(StringUtils.isNotEmpty(phone) && !phone.equals("null")) {
								log.debug("휴대전화 번호 복호화 전 ==================>" + phone);
								phone = CryptoUtil.decryptAES256(phone);
								log.debug("휴대전화 번호 복호화 후 ==================>" + phone);
								/** 휴대전화 번호 셋팅 **/
								smsVO.setPhone(phone);
							}
							//알림톡 내용 셋팅
							smsMap.put("templateNum", templateNum); // 템플릿 번호
							smsMap.put("couponTyName", vo.getCouponTyName()); //쿠폰타입
							smsMap.put("couponNm", vo.getCouponNm());// 쿠폰명
							smsMap.put("couponEndde", vo.getCouponEndde());//쿠폰 종료 일시
							smsMap.put("excpSndngOptnAt","N");			//예외 발송 여부
							//알림톡 발송
							smsService.insertSMS(smsVO, smsMap);
						} catch(Exception e) {
							log.error("CouponServiceImpl sendCouponInfo 쿠폰 만료 내역 알림톡 발송 ERROR " + e.getMessage());
						}
					}
				}
			}
		}
	}	
}