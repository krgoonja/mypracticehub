package com.sorincorp.batch.ev.service;

import java.util.List;

import com.sorincorp.batch.ev.model.OrdtmDscntCouponVO;

/**
 * 상시할인 쿠폰 발행 및 알림톡 발송 (batch service)
 * OrdtmDscntCouponService.java
 * @version
 * @since 2024. 01. 06.
 * @author sein
 */
public interface OrdtmDscntCouponService {
	
	/**
	 * 
	 * <pre>
	 * 상시할인 쿠폰 발행
	 * </pre>
	 * @date 2024. 01. 06.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 01. 06.	  sein				    최초작성
	 * ------------------------------------------------
	 */
	void ordtmDscntCouponIsgn() throws Exception;
	
	/**
	 * 
	 * <pre>
	 * CP_COUPON_INFO_DTL insert문 (단가/지정가)
	 *  1. 최고 구매 수량 달성 고객 감사 혜택
	 *  2. 평균 수량 이상 구매 고객 감사 혜택
	 *  3. 평균 구매 수량 유지 고객 감사 혜택
	 * </pre>
	 * @date 2024. 01. 06.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 01. 06.	  sein				    최초작성
	 * ------------------------------------------------
	 */
	void insertCpCouponInfoDtl(OrdtmDscntCouponVO vo, List<String> couponDtlNoList) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 쿠폰발행 알림톡 발송 
	 * </pre>
	 * @date 2024. 01. 06.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 01. 06.	  sein				    최초작성
	 * ------------------------------------------------
	 */
	void procSms(OrdtmDscntCouponVO couponSmsVO, String templateNum) throws Exception;
}