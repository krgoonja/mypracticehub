//package com.sorincorp.batch.test;
//
//
//import javax.sql.DataSource;
//
//import org.springframework.batch.core.Job;
//import org.springframework.batch.core.Step;
//import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
//import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
//import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
//import org.springframework.batch.core.configuration.annotation.StepScope;
//import org.springframework.batch.item.ItemProcessor;
//import org.springframework.batch.item.database.JdbcBatchItemWriter;
//import org.springframework.batch.item.database.JdbcCursorItemReader;
//import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
//import org.springframework.batch.item.database.builder.JdbcCursorItemReaderBuilder;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.jdbc.core.BeanPropertyRowMapper;
//
//import com.sorincorp.batch.sample.model.SampleVO;
//
//import lombok.AllArgsConstructor;
//
//@AllArgsConstructor
//@Configuration
//public class SampleConfig {
//
//	private final DataSource dataSource;
//	private static final int CHUNKSIZE = 20;
//	
//	private final JobBuilderFactory jobFactory;
//	private final StepBuilderFactory stepFactory;
//	
//	@Bean
//	public Job sampleJob() throws Exception {
//		
//		return jobFactory
//				.get("sampleJob100")
//				.preventRestart()
//				.start(sampleStep())
//				.build();
//	}
//	
//	@Bean
//	public Step sampleStep() throws Exception {
//		return stepFactory
//				.get("sampleStep")
//				.<SampleVO, SampleVO> chunk(CHUNKSIZE)
//				.reader(jdbcCursorItemReader())
//				.processor(sampleProcessor())
//				.writer(jdbcBatchItemWriter())
//				.build();
//	}
//	
//	@Bean
//	@StepScope
//	public JdbcCursorItemReader<SampleVO> jdbcCursorItemReader() {
//		return new JdbcCursorItemReaderBuilder<SampleVO>()
//				.name("sampleRead")
//				.fetchSize(10)
//				.dataSource(dataSource)
//				.rowMapper(new BeanPropertyRowMapper<>(SampleVO.class))
//				.sql("select id, name, description, use_yn, reg_user from sample")
//				.build();
//	}
//	
//	public ItemProcessor<SampleVO, SampleVO> sampleProcessor() {
//		
//		return sample -> {
//			sample.setUseYn(sample.getUseYn().equals("Y")? "N" : "Y");
//			return sample;
//		};
//	}
//	
//	@Bean
//	public JdbcBatchItemWriter<SampleVO> jdbcBatchItemWriter() {
//		return new JdbcBatchItemWriterBuilder<SampleVO>()
//				.dataSource(dataSource)
//				.sql("update SAMPLE set use_yn = :useYn where id=:id")
//				.beanMapped()
//				.build();
//	}
//}
