package com.sorincorp.batch.jobs.ewallet;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

@Configuration
@EnableBatchProcessing
public class EwalletUseConfmChkJobConfig {

	@Autowired
	EwalletUseConfmChkJobTasklet ewalletUseConfmChkJobTasklet;

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job ewalletUseConfmChkJob() {
		return jobBuilderFactory.get("ewalletUseConfmChkJob")
				.start(ewalletUseConfmChkStep())
				.build();
	}

	@Bean
	@JobScope
	public Step ewalletUseConfmChkStep() {
		return stepBuilderFactory.get("ewalletUseConfmChkStep")
				.tasklet(ewalletUseConfmChkJobTasklet)
				.build();
	}
}
