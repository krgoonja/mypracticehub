package com.sorincorp.batch.jobs.mb;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.mb.service.MbEntrpsMrtggCntrctBasService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class MbEntrpsMrtggCntrctBasTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	MbEntrpsMrtggCntrctBasService mbEntrpsMrtggCntrctBasService;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		// TODO Auto-generated method stub
		log.debug("MbEntrpsMrtggCntrctBasTasklet beforeStep method");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		// TODO Auto-generated method stub
		log.debug("MbEntrpsMrtggCntrctBasTasklet execute method");
		mbEntrpsMrtggCntrctBasService.insertMbEntrpsMrtggCntrctBas();
		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		// TODO Auto-generated method stub
		log.debug("MbEntrpsMrtggCntrctBasTasklet afterStep method");
		try {
			mbEntrpsMrtggCntrctBasService.updateEntrpsMrtggCntctBasLastCntrctAt();
			mbEntrpsMrtggCntrctBasService.updateEntrpsMrtggCntctBasCntrctExpiration();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			log.error(e.toString());
		}
		return ExitStatus.COMPLETED;
	}



}
