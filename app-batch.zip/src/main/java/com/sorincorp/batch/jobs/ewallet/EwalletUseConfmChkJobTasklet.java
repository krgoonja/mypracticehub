package com.sorincorp.batch.jobs.ewallet;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.ewallet.service.EwalletUseConfmChkService;
import com.sorincorp.batch.it.service.LgistCstdyWonCtCalcService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class EwalletUseConfmChkJobTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	EwalletUseConfmChkService ewalletUseConfmChkService;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("ewalletUseConfmChTasklet beforeStep method");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("ewalletUseConfmChTasklet execute method");
		ewalletUseConfmChkService.ewalletUseConfmCheck();

		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("ewalletUseConfmChTasklet afterStep method");
		return ExitStatus.COMPLETED;
	}

}
