package com.sorincorp.batch.jobs.sample;

import java.util.List;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.sample.mapper.SampleMapper;
import com.sorincorp.batch.sample.model.SampleVO;
import com.sorincorp.batch.sample.service.SampleService;
import com.sorincorp.batch.sample.service.SampleServiceImpl;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SampleTasklet implements Tasklet{

	@Autowired
	SampleService sampleService;
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		// TODO Auto-generated method stub
		
		SampleVO sampleVO = new SampleVO();
		sampleVO.setName("eee");

		List<SampleVO> selectSampleList =sampleService.selectSampleList(sampleVO);
		for(SampleVO vo : selectSampleList) {
			log.debug("Selected User:"+vo.getName());
		}
		
		return RepeatStatus.FINISHED;
	}

	
}
