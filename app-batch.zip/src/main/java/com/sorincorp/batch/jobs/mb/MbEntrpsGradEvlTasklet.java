package com.sorincorp.batch.jobs.mb;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.mb.service.MbEntrpsGradEvlService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class MbEntrpsGradEvlTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	MbEntrpsGradEvlService mbEntrpsGradEvlService;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		// TODO Auto-generated method stub
		log.debug("MbEntrpsGradEvlTasklet beforeStep method");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		// TODO Auto-generated method stub
		log.debug("MbEntrpsGradEvlTasklet execute method");
		mbEntrpsGradEvlService.mbEntrpsGradEvl("");
		// 강제로 업체등급 산정시 날짜 파라미터 세팅하여 메소드 호출 1분기-yyyy0401 2분기-yyyy0701 3분기-yyyy1001
		// 4분기-yyyy0101(당해1월1일로 세팅해야 직전년도 4분기 등급산정됨)
		// mbEntrpsGradEvlService.mbEntrpsGradEvl("20221001"); // ex) 2022년3분기
		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		// TODO Auto-generated method stub
		log.debug("MbEntrpsGradEvlTasklet afterStep method");
		return ExitStatus.COMPLETED;
	}
}
