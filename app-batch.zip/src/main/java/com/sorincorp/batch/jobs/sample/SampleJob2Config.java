package com.sorincorp.batch.jobs.sample;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 개별 배치 Job 설정 샘플
 * SampleJobConfig.java
 * @version
 * @since 2021. 8. 11.
 * @author srec0012
 */
@Configuration
@RequiredArgsConstructor
public class SampleJob2Config {

	@Autowired
	Sample2Tasklet sample2Tasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory;

	/**
	 * 
	 * <pre>
	 * Job을 설정한다. Step 순서 및 분기
	 * </pre>
	 * @date 2021. 8. 11.
	 * @author srec0012
	 * @history 
	 * <pre>
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 11.			srec0012			최초작성
	 * ------------------------------------------------
	 * </pre>
	 * @return
	 */
	@Bean
	public Job sampleTestJob2() {
		return jobBuilderFactory.get("sampleTestJob3")
				.start(sampleStep2())
				.build();
	}
	
	/**
	 * 
	 * <pre>
	 * 실행될 Step을 정의한다.
	 * </pre>
	 * @date 2021. 8. 11.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 11.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@Bean
	@JobScope
	public Step sampleStep2() {
		return stepBuilderFactory.get("sampleStep2")
				.tasklet(sample2Tasklet)
				.build();
	}
}
