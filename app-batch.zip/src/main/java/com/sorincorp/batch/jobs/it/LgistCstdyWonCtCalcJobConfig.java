package com.sorincorp.batch.jobs.it;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

@Configuration
@EnableBatchProcessing
public class LgistCstdyWonCtCalcJobConfig {

	@Autowired
	LgistCstdyWonCtCalcTasklet lgistCstdyWonCtCalcTasklet;

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job lgistCstdyWonCtCalcJob() {
		return jobBuilderFactory.get("lgistCstdyWonCtCalcJob")
				.start(lgistCstdyWonCtCalcStep())
				.build();
	}

	@Bean
	@JobScope
	public Step lgistCstdyWonCtCalcStep() {
		return stepBuilderFactory.get("lgistCstdyWonCtCalcStep")
				.tasklet(lgistCstdyWonCtCalcTasklet)
				.build();
	}
}
