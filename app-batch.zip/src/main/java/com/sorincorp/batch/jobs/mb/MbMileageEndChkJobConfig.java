package com.sorincorp.batch.jobs.mb;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class MbMileageEndChkJobConfig {

	@Autowired
	MbMileageEndChkJobTasklet mbMileageEndChkJobTasklet;

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job mbMileageEndChkJob() {
		return jobBuilderFactory.get("mbMileageEndChkJob")
				.start(mbMileageEndChkJobTaskletStep())
				.build();
	}

	@Bean
	@JobScope
	public Step mbMileageEndChkJobTaskletStep() {
		return stepBuilderFactory.get("mbMileageEndChkJobTaskletStep")
				.tasklet(mbMileageEndChkJobTasklet)
				.build();
	}

}
