package com.sorincorp.batch.jobs.it;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.it.service.LgistCstdyWonCtCalcService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class LgistCstdyWonCtCalcTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	LgistCstdyWonCtCalcService lgistCstdyWonCtCalcService;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		// TODO Auto-generated method stub
		log.debug("LgistCstdyWonCtCalcTasklet beforeStep method");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		// TODO Auto-generated method stub
		log.debug("LgistCstdyWonCtCalcTasklet execute method");
		lgistCstdyWonCtCalcService.updateLgistCstdyWonCt();

		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		// TODO Auto-generated method stub
		log.debug("LgistCstdyWonCtCalcTasklet afterStep method");
		return ExitStatus.COMPLETED;
	}

}
