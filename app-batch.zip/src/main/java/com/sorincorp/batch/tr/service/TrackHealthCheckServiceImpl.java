package com.sorincorp.batch.tr.service;


import com.sorincorp.batch.tr.mapper.TrackHealthCheckMapper;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class TrackHealthCheckServiceImpl implements TrackHealthCheckService {

	@Autowired
	private TrackHealthCheckMapper trackHealthCheckMapper;

	@Autowired
	private RedisPubSubService redisPubSubService;

	@Value("${redisPubsub.uri.track}")
	private String trackUri;
	/**
	 * 트래킹 방문자 헬스체크
	 * */
	@Transactional(rollbackFor = Exception.class)
	@Override
	public void trackHealthCheck() throws Exception {


		log.debug("HAM :: TrackHealthCheckServiceImpl:trackHealthCheck 방문자 헬스체크 Start");

        // 당일이 휴일 혹은 공휴일인지 확인
		int lastBsnDe = trackHealthCheckMapper.selectLastBsnDe();

		if(lastBsnDe == 0) {
			log.debug("주말, 휴일이 아니므로 실행");
		}
		try {
			//트래킹 방문자 제거 리스트 조회
			List<Map<String, Object>> trackMsgMap = trackHealthCheckMapper.trackHealthCheck();
			//BO dashboard 제거 리스트 전송
			redisPubSubService.publishMessage(trackUri, "/track", trackMsgMap);

		} catch(Exception e) {
			log.error("TrackHealthCheckServiceImpl trackHealthCheck 방문자 헬스체크 ERROR " + e.getMessage());
		}

	}
}