package com.sorincorp.batch.tr.job;

import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 방문자 트래킹 헬스체크 배치 JobConfig
 * TrackHealthCheckJobConfig.java
 * @version
 * @since 2023. 8. 30.
 * @author hamyoonsic
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class TrackHealthCheckJobConfig {
	
	@Autowired
	TrackHealthCheckTasklet trackHealthCheckTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory; 
	
	@Bean
	public Job trackHealthCheckJob() {
		return jobBuilderFactory.get("trackHealthCheckJob")
				.start(trackHealthCheckStep())
				.build();  
	}//end trackHealthCheckJob()
	
	@Bean
	@JobScope
	public Step trackHealthCheckStep() {
		return stepBuilderFactory.get("trackHealthCheckStep")
				.tasklet(trackHealthCheckTasklet)
				.build();
	}//end trackHealthCheckStep()
	
}//end class()