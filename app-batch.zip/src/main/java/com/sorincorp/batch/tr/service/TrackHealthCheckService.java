package com.sorincorp.batch.tr.service;

/**
 * 방문자 트래킹 헬스체크 배치 batch Service(휴일,공휴일 제외)
 * TrackHealthCheckService.java
 * @version
 * @since 2023. 08. 30.
 * @author hamyoonsic
 */
public interface TrackHealthCheckService {
	
	/**
	 * 
	 * <pre>
	 * 방문자 트래킹 헬스체크
	 * </pre>
	 * @date 2023. 08. 30.
	 * @author hamyoonsic
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 30.	  		hamyoonsic			최초작성
	 * ------------------------------------------------
	 */
	void trackHealthCheck() throws Exception;

}