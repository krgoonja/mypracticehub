package com.sorincorp.batch.tr.mapper;

import java.util.List;
import java.util.Map;


public interface TrackHealthCheckMapper {


	/**
	 * <pre>
	 * 주말, 공휴일 확인
	 * </pre>
	 * @date 2023. 08. 30
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 30	  		hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	int selectLastBsnDe()throws Exception;
	
	
	/**
	 * <pre>
	 * 방문자 트래킹 헬스체크
	 * </pre>
	 * @date 2023. 08. 30
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 30	   		hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<Map<String, Object>> trackHealthCheck()throws Exception;


}
