package com.sorincorp.batch.config;

import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;

import com.sorincorp.batch.jobs.sample.SampleJobConfig;

import lombok.extern.slf4j.Slf4j;

/**
 * Batch Job Scheduling 설정
 * JobScheduler.java
 * @version
 * @since 2021. 8. 11.
 * @author srec0012
 */
@Slf4j
//@Component
public class JobScheduler {

	@Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private SampleJobConfig sampleJobConfig;
    
    /**
     * 
     * <pre>
     * Job의 스케쥴링 처리 업무에 따라
     * cron 형태 또는 fixedDelay 또는 fixedRate를 사용가능하다
     * </pre>
     * @date 2021. 8. 11.
     * @author srec0012
     * @history 
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2021. 8. 11.			srec0012			최초작성
     * ------------------------------------------------
     */
    //@Scheduled(initialDelay = 10000, fixedRate = 5000)
//    @Scheduled(cron = "0/30 * * * * *")
//    public void runSampleJob() {
//
//        Map<String, JobParameter> jobParamMap = new HashMap<>();
//        jobParamMap.put("time", new JobParameter(System.currentTimeMillis()));
//        JobParameters jobParameters = new JobParameters(jobParamMap);
//
//        try {
//            jobLauncher.run(sampleJobConfig.sampleTestJob1(), jobParameters);
//        } catch (JobExecutionAlreadyRunningException | JobInstanceAlreadyCompleteException
//                | JobParametersInvalidException | org.springframework.batch.core.repository.JobRestartException e) {
//            log.error(e.getMessage());
//        }
//    }


}
