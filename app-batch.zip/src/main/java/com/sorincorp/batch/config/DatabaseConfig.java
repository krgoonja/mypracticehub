package com.sorincorp.batch.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.batch.core.configuration.annotation.DefaultBatchConfigurer;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

@Configuration
@MapperScan(basePackages = {"com.sorincorp.batch.sample.mapper", "com.sorincorp.batch.*.mapper", "com.sorincorp.comm.*.mapper"})
public class DatabaseConfig extends DefaultBatchConfigurer
{
	
	@Override
	public void setDataSource(DataSource dataSource) {
		
	}
	
	@Bean
	@ConfigurationProperties(prefix ="spring.datasource")
	public DataSource dataSource() {
		return DataSourceBuilder.create().build();
	}
	
//	@Bean
//	public DataSource dataSource() {
//		return DataSourceBuilder.create()
//								.url("jdbc:log4jdbc:sqlserver://172.10.0.204:1433;database=SEC_DEV")
//								.driverClassName("net.sf.log4jdbc.sql.jdbcapi.DriverSpy")
//								.username("srec0008")
//								.password("Korea11!@")
//								.build();
//	}
	
	@Bean
	public SqlSessionFactory sqlSessionFactory(DataSource dataSource) throws Exception {
		SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
		sqlSessionFactoryBean.setDataSource(dataSource);
		
		PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
		sqlSessionFactoryBean.setMapperLocations(resolver.getResources("classpath*:/mapper/*/*.xml"));
		
		Properties properties = new Properties();
		properties.put("mapUnderscoreToCamelCase", true);
		sqlSessionFactoryBean.setConfigurationProperties(properties);
		
		return sqlSessionFactoryBean.getObject();
	}

	@Bean
	public SqlSessionTemplate sqlSessionTemplate(SqlSessionFactory sqlSessionFactory) {
		sqlSessionFactory.getConfiguration().setMapUnderscoreToCamelCase(true);
		final SqlSessionTemplate sqlSessionTemplate = new SqlSessionTemplate(sqlSessionFactory);
		return sqlSessionTemplate;
	}	
}