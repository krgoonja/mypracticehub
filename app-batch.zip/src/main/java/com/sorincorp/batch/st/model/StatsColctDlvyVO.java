package com.sorincorp.batch.st.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * 배송 통계 StatsColctDlvyVO.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel("배송 통계 VO")
public class StatsColctDlvyVO {

}//end class()
