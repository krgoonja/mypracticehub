package com.sorincorp.batch.st.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.st.mapper.StatsColctInvntryMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 재고 통계 StatsColctInvntryServiceImpl.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Slf4j
@Service
public class StatsColctInvntryServiceImpl implements StatsColctInvntryService {

	@Autowired
	StatsColctInvntryMapper statsColctInvntryMapper;

	/**재고 통계 수집 (DBO.SP_ST_INVNTRY_STTUS_CREATE)*/
	@Override
	public void invntryStatsColct() {
		log.debug("StatsColctInvntryServiceImpl::invntryStatsColct Start");
		
		try {
			statsColctInvntryMapper.invntryStatsColct();
		} catch (Exception e) {
			log.debug("StatsColctInvntryServiceImpl::invntryStatsColct exception = " + e.getMessage());
		}
		
		log.debug("StatsColctInvntryServiceImpl::invntryStatsColct End");
	}//end InvntryStatsColct()
	
}//end class()
