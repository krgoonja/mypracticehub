package com.sorincorp.batch.st.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * 재고 통계 StatsColctInvntryVO.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel("재고 통계 VO")
public class StatsColctInvntryVO {

}//end class()
