package com.sorincorp.batch.st.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.st.service.StatsColctMktService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 매출 통계 수집 batch StatsColctMktTasklet.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Slf4j
@Component
public class StatsColctMktTasklet implements Tasklet, StepExecutionListener {
	
	@Autowired
	StatsColctMktService statsColctMktService;
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("StatsColctMktTasklet::beforeStep");
	}//end beforeStep

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("StatsColctMktTasklet::execute Start == delete first");
		statsColctMktService.mktStatsColctDel();
		log.debug("StatsColctMktTasklet::execute Start == insert second");
		statsColctMktService.mktStatsColct();
		log.debug("StatsColctMktTasklet::execute End");
		return RepeatStatus.FINISHED;
	}//end execute()
	
	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("StatsColctMktTasklet::afterStep");
		return ExitStatus.COMPLETED;
	}//end afterStep()

}//end class()
