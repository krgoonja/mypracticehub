package com.sorincorp.batch.st.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.st.mapper.StatsColctEwalletMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 이월렛 통계 StatsColctEwalletServiceImpl.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Slf4j
@Service
public class StatsColctEwalletServiceImpl implements StatsColctEwalletService {

	@Autowired
	StatsColctEwalletMapper statsColctEwalletMapper;
	
}//end class()
