package com.sorincorp.batch.st.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 
 * 배송 통계 수집 batch StatsColctDlvyJobConfig.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class StatsColctDlvyJobConfig {

	@Autowired
	StatsColctDlvyTasklet statsColctDlvyTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory; 
	
	@Bean
	public Job statsColctDlvyJob() {
		return jobBuilderFactory.get("statsColctDlvyJob")
				.start(statsColctDlvyStep())
				.build();  
	}//end statsColctDlvyJob()
	
	@Bean
	@JobScope
	public Step statsColctDlvyStep() {
		return stepBuilderFactory.get("statsColctDlvyStep")
				.tasklet(statsColctDlvyTasklet)
				.build();
	}//end statsColctDlvyStep()
	
}//end class()
