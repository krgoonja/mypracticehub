package com.sorincorp.batch.st.mapper;

import java.util.List;

import com.sorincorp.batch.st.model.GwIfElctrnPrufVO;

/**
 * 
 * 전자 증빙 배치 GwIfElctrnPrufMapper.java
 * @version
 * @since 2024. 09. 12.
 * @author sein
 */
public interface GwIfElctrnPrufMapper {

	/* CSU,CWS정보 가져오기 */
	List<GwIfElctrnPrufVO> selectCsuCwsInfoList() throws Exception;
	
	/* CSU,CWS정보 가져오기 */
	int mergeCsuCwsInfo(GwIfElctrnPrufVO gwIfElctrnPrufVO) throws Exception;

	/* 입금전표 insert */
	int insertRcpmnyBatchNo(GwIfElctrnPrufVO gwIfElctrnPrufVO) throws Exception;
	
	/* IF_GW 상태변경 D,A */
	int updateIfGwStats() throws Exception;
	
	/* 선수금 GW 정보 가져오기 */
	List<GwIfElctrnPrufVO> selectPrecdntGwStatusInfoList() throws Exception;
	
}//end interface()
