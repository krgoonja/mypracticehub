package com.sorincorp.batch.st.mapper;

/**
 * 
 * 배송 통계 StatsColctDlvyMapper.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
public interface StatsColctDlvyMapper {

	
}//end interface()
