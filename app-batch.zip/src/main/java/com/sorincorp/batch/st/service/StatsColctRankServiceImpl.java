package com.sorincorp.batch.st.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.st.mapper.StatsColctRankMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 순위 통계 StatsColctRankServiceImpl.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Slf4j
@Service
public class StatsColctRankServiceImpl implements StatsColctRankService {

	@Autowired
	StatsColctRankMapper statsColctRankMapper;
	
}//end class()
