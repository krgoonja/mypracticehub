package com.sorincorp.batch.st.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * 전자 증빙 GwIfElctrnPrufVO.java
 * @version
 * @since 2021. 09. 12.
 * @author sein
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel("전자 증빙 VO")
public class GwIfElctrnPrufVO {
	
	/** GW_LINK_INFO 정보 **/
	/**  **/
	private String companyCd;
	/**  **/
	private String gwNo;
	/**  **/
	private String type;
	/**  **/
	private String aprErpId;
	/**  **/
	private String aprId;
	/**  **/
	private String docBatchNo;
	/**  **/
	private String gwDocNo;
	/**  **/
	private String submDt;
	/**  **/
	private String statusDt;
	/**  **/
	private String status;
	/**  **/
	private String appId;
	/**  **/
	private String postYn;
	/**  **/
	private String pAprErpId;
	/**  **/
	private String createDt;
	/**  **/
	private String createId;
	/**  **/
	private String updateDt;
	/**  **/
	private String updateId;
	/** GW_LINK_INFO 정보끝 **/

	/** IF_GW 정보 **/
	/**  **/
	private String approvalKey;
	/**  **/
	private String rcpmnyBatchNo;
	/**  **/
	private String sttusCode;
	/**  **/
	private String frstRegisterId;
	/**  **/
	private String frstRegistDt;
	/**  **/
	private String lastChangerId;
	/**  **/
	private String lastChangeDt;
	/** IF_GW 정보 끝**/
	
	private String csuCws;
	private int batchNo;
	
}//end class()
