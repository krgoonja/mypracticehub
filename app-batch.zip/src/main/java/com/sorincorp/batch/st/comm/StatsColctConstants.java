package com.sorincorp.batch.st.comm;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 통계 Batch 공통 StatsColctConstants.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Slf4j
public class StatsColctConstants {
	
	private StatsColctConstants() {
		log.debug(StatsColctConstants.class.getSimpleName());
	}
	
	/**RESULT*/
	public static final int SUCCESS_CODE 				= 200;
	public static final int ERROR_CODE 					= 400;
	public static final String SUCCESS_RESULT_CODE		= "200";
	public static final String ERROR_RESULT_CODE 		= "500";
	public static final String SUCCESS_MSG 				= "Success";
	public static final String ERROR_MSG 				= "Error";
	public static final String EHR_REPONSE_RESULT_MSG 	= "result_msg";
	public static final String EHR_REPONSE_RESULT_DATA 	= "result_data";
	public static final String EHR_REPONSE_RESULT_CODE 	= "result_code";
	
}//end class()
