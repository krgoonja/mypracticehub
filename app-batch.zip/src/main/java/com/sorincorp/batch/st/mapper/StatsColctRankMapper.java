package com.sorincorp.batch.st.mapper;

/**
 * 
 * 순위 통계 StatsColctRankMapper.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
public interface StatsColctRankMapper {

	
}//end interface()
