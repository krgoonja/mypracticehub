package com.sorincorp.batch.st.mapper;

/**
 * 
 * 매출 통계 StatsColctMktMapper.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
public interface StatsColctMktMapper {

	/**매출 통계 수집*/
	void mktStatsColct();
	
	/* DEL */
	void mktStatsColctDel();
}//end interface()
