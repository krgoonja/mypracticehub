package com.sorincorp.batch.st.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.st.service.GwIfElctrnPrufService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 매출 통계 수집 batch GwIfElctrnPrufTasklet.java
 * @version
 * @since 2024. 09. 12.
 * @author sein
 */
@Slf4j
@Component
public class GwIfElctrnPrufTasklet implements Tasklet, StepExecutionListener {
	
	@Autowired
	GwIfElctrnPrufService gwIfElctrnPrufService;
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("GwIfElctrnPrufTasklet::beforeStep");
	}//end beforeStep

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("GwIfElctrnPrufTasklet::execute Start");
		gwIfElctrnPrufService.gwIfElctrnPrufStats();
		log.debug("GwIfElctrnPrufTasklet::execute End");
		return RepeatStatus.FINISHED;
	}//end execute()
	
	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("GwIfElctrnPrufTasklet::afterStep");
		return ExitStatus.COMPLETED;
	}//end afterStep()

}//end class()
