package com.sorincorp.batch.st.mapper;

/**
 * 
 * 매출 통계 StatsColctSelngMapper.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
public interface StatsColctSelngMapper {

	/**매출 통계 수집*/
	void selngStatsColct();
}//end interface()
