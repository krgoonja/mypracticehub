package com.sorincorp.batch.st.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.st.mapper.StatsColctMktMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 매출 통계 StatsColctMktServiceImpl.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Slf4j
@Service
public class StatsColctMktServiceImpl implements StatsColctMktService {

	@Autowired
	StatsColctMktMapper statsColctMktMapper;

	/**매출 통계 수집*/
	@Override
	public void mktStatsColct() {
		log.debug("StatsColctMktServiceImpl::mktStatsColct Start");
		
		try {
			statsColctMktMapper.mktStatsColct();
		} catch (Exception e) {
			log.debug("StatsColctMktServiceImpl::mktStatsColct exception = " + e.getMessage());
		}
		
		log.debug("StatsColctMktServiceImpl::mktStatsColct End");
	}//end mktStatsColct()
	
	@Override
	public void mktStatsColctDel() {
		log.debug("StatsColctMktServiceImpl::mktStatsColctDel (pre-insert) Start");
		try {
			statsColctMktMapper.mktStatsColctDel();
		} catch (Exception e) {
			log.debug("StatsColctMktServiceImpl::mktStatsColctDel exception = " + e.getMessage());
		}
		log.debug("StatsColctMktServiceImpl::mktStatsColctDel End");
	}
	
}//end class()
