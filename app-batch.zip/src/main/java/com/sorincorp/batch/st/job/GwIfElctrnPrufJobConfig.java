package com.sorincorp.batch.st.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 
 * 전자 증빙 배치 batch GwIfElctrnPrufJobConfig.java
 * @version
 * @since 2024. 09. 12.
 * @author sein
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class GwIfElctrnPrufJobConfig {

	@Autowired
	GwIfElctrnPrufTasklet gwIfElctrnPrufTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory; 
	
	@Bean
	public Job gwIfElctrnPrufJob() {
		return jobBuilderFactory.get("gwIfElctrnPrufJob")
				.start(gwIfElctrnPrufStep())
				.build();  
	}//end gwIfElctrnPrufJob()
	
	@Bean
	@JobScope
	public Step gwIfElctrnPrufStep() {
		return stepBuilderFactory.get("gwIfElctrnPrufStep")
				.tasklet(gwIfElctrnPrufTasklet)
				.build();
	}//end gwIfElctrnPrufStep()
	
}//end class()
