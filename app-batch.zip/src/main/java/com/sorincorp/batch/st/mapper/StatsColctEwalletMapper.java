package com.sorincorp.batch.st.mapper;

/**
 * 
 * 이월렛 통계 StatsColctEwalletMapper.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
public interface StatsColctEwalletMapper {

	
}//end interface()
