package com.sorincorp.batch.st.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.st.mapper.GwIfElctrnPrufMapper;
import com.sorincorp.batch.st.model.GwIfElctrnPrufVO;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 전자 증빙 배치 GwIfElctrnPrufServiceImpl.java
 * @version
 * @since 2024. 09. 12.
 * @author sein
 */
@Slf4j
@Service
public class GwIfElctrnPrufServiceImpl implements GwIfElctrnPrufService {

	@Autowired
	GwIfElctrnPrufMapper gwIfElctrnPrufMapper;

	/**전자 증빙 배치*/
	@Override
	public void gwIfElctrnPrufStats() {
		log.debug("StatsColctSelngServiceImpl::selngStatsColct Start");

		try {
			List<GwIfElctrnPrufVO> gwIfElctrnPrufList= gwIfElctrnPrufMapper.selectCsuCwsInfoList();						//매출증빙 IF_GW 상태 확인
			//List<GwIfElctrnPrufVO> gwIfPrecdntElctrnPrufList= gwIfElctrnPrufMapper.selectPrecdntGwStatusInfoList();		//선수금 IF_GW 상태 확인
			
			//if(gwIfElctrnPrufList.size() > 0) {
				int  cnt = 0;
				for(int i = 0; i < gwIfElctrnPrufList.size() ; i++) {
					//APR_ERP_ID(PK설정으로 인한 변경
					if(i != 0) {
						gwIfElctrnPrufList.get(i).setAprErpId(gwIfElctrnPrufList.get(i).getAprErpId() + 0);
						gwIfElctrnPrufList.get(i).setAprErpId(Integer.toString(Integer.parseInt(gwIfElctrnPrufList.get(i).getAprErpId()) + cnt++));
					}
					gwIfElctrnPrufMapper.mergeCsuCwsInfo(gwIfElctrnPrufList.get(i));
					
					//마지막 csu,cws일때 입금전표 추가
					if(i ==  gwIfElctrnPrufList.size() - 1) {
						//입금전표(BATCH 번호)
						String[] rcpmnyBatchNoList = gwIfElctrnPrufList.get(i).getRcpmnyBatchNo().split("/");
						
						for(int j = 0 ; j < rcpmnyBatchNoList.length ; j++) {
							//첫증빙+첫입금
							if(i == 0 && j == 0) {
								gwIfElctrnPrufList.get(i).setAprErpId(gwIfElctrnPrufList.get(i).getAprErpId() + 0);
							}
							//rcpmnyBatchNo 공백 or null 체크
							if(!"".equals(rcpmnyBatchNoList[j]) || !rcpmnyBatchNoList[j].isEmpty()) {
								//APR_ERP_ID(PK설정으로 인한 변경
								if(i == 0 && j == 0) {
									gwIfElctrnPrufList.get(i).setAprErpId(Integer.toString(Integer.parseInt(gwIfElctrnPrufList.get(i).getAprErpId()) + cnt++));
								}else {
									gwIfElctrnPrufList.get(i).setAprErpId(Integer.toString(Integer.parseInt(gwIfElctrnPrufList.get(i).getAprErpId()) + 1));
								}
								gwIfElctrnPrufList.get(i).setBatchNo(Integer.parseInt(rcpmnyBatchNoList[j]));
								//GW_LINK_INFO 입금전표 batch_no insert
								gwIfElctrnPrufMapper.insertRcpmnyBatchNo(gwIfElctrnPrufList.get(i));
							}
						}
					}
				}
			//}
			/*	
			if(gwIfPrecdntElctrnPrufList.size() > 0) {
				int  precdntCnt = 0;		
				for(int i = 0; i < gwIfPrecdntElctrnPrufList.size() ; i++) {
					
					//APR_ERP_ID(PK설정으로 인한 변경
					if(i != 0) {
						gwIfPrecdntElctrnPrufList.get(i).setAprErpId(gwIfPrecdntElctrnPrufList.get(i).getAprErpId() + 0);
						gwIfPrecdntElctrnPrufList.get(i).setAprErpId(Integer.toString(Integer.parseInt(gwIfPrecdntElctrnPrufList.get(i).getAprErpId()) + precdntCnt++));
					}
					
					gwIfElctrnPrufMapper.mergeCsuCwsInfo(gwIfPrecdntElctrnPrufList.get(i));
					
					//마지막 csu,cws일때 입금전표 추가
					if(i ==  gwIfPrecdntElctrnPrufList.size() - 1) {
						//입금전표(BATCH 번호)
						String[] rcpmnyBatchNoList = gwIfPrecdntElctrnPrufList.get(i).getRcpmnyBatchNo().split("/");
						
						for(int j = 0 ; j < rcpmnyBatchNoList.length ; j++) {
							//첫증빙+첫입금
							if(i == 0 && j == 0) {
								gwIfPrecdntElctrnPrufList.get(i).setAprErpId(gwIfPrecdntElctrnPrufList.get(i).getAprErpId() + 0);
							}
							//rcpmnyBatchNo 공백 or null 체크
							if(!"".equals(rcpmnyBatchNoList[j]) || !rcpmnyBatchNoList[j].isEmpty()) {
								//APR_ERP_ID(PK설정으로 인한 변경
								if(i == 0 && j == 0) {
									gwIfPrecdntElctrnPrufList.get(i).setAprErpId(Integer.toString(Integer.parseInt(gwIfPrecdntElctrnPrufList.get(i).getAprErpId()) + precdntCnt++));
								}else {
									gwIfPrecdntElctrnPrufList.get(i).setAprErpId(Integer.toString(Integer.parseInt(gwIfPrecdntElctrnPrufList.get(i).getAprErpId()) + 1));
								}
								gwIfPrecdntElctrnPrufList.get(i).setBatchNo(Integer.parseInt(rcpmnyBatchNoList[j]));
								//GW_LINK_INFO 입금전표 batch_no insert
								gwIfElctrnPrufMapper.insertRcpmnyBatchNo(gwIfPrecdntElctrnPrufList.get(i));
							}
						}
					}
				}
			}
			*/
			
			//IF_GW 상태변경 D,A,C,N
			gwIfElctrnPrufMapper.updateIfGwStats();
			
		} catch (Exception e) {
			log.debug("StatsColctSelngServiceImpl::selngStatsColct exception = " + e.getMessage());
		}
		
		
		log.debug("StatsColctSelngServiceImpl::selngStatsColct End");
	}//end selngStatsColct()
	
}//end class()
