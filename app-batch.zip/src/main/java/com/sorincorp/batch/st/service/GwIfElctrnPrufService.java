package com.sorincorp.batch.st.service;

/**
 * 
 *  전자 증빙 배치 batch GwIfElctrnPrufService.java
 * @version
 * @since 2024. 09. 12.
 * @author sein
 */
public interface GwIfElctrnPrufService {

	/**
	 * 
	 * <pre>
	 * 매출 통계 수집
	 * </pre>
	 * @date 2021. 11. 24.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 24.			srec0054			최초작성
	 * ------------------------------------------------
	 */
	void gwIfElctrnPrufStats();
	
}//end interface()
