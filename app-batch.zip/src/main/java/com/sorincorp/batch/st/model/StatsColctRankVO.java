package com.sorincorp.batch.st.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * 순위 통계 StatsColctRankVO.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel("순위 통계 VO")
public class StatsColctRankVO {

}//end class()
