package com.sorincorp.batch.st.service;

/**
 * 
 * 재고 통계 batch StatsColctInvntryService.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
public interface StatsColctInvntryService {

	/**
	 * 
	 * <pre>
	 * 재고 통계 수집
	 * </pre>
	 * @date 2021. 11. 23.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 23.			srec0054			최초작성
	 * ------------------------------------------------
	 */
	void invntryStatsColct();
	
}//end interface()
