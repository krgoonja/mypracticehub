package com.sorincorp.batch.st.service;

/**
 * 
 * 순위 통계 batch StatsColctRankService.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
public interface StatsColctRankService {

}//end interface()
