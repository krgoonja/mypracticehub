package com.sorincorp.batch.st.mapper;

/**
 * 
 * 재고 통계 StatsColctInvntryMapper.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
public interface StatsColctInvntryMapper {

	/**재고 통계 수집 (DBO.SP_ST_INVNTRY_STTUS_CREATE)*/
	void invntryStatsColct();
	
}//end interface()
