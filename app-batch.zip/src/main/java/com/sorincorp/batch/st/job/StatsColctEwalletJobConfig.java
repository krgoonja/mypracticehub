package com.sorincorp.batch.st.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 
 * 이월렛 통계 수집 batch StatsColctEwalletJobConfig.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class StatsColctEwalletJobConfig {

	@Autowired
	StatsColctEwalletTasklet statsColctEwalletTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory; 
	
	@Bean
	public Job statsColctEwalletJob() {
		return jobBuilderFactory.get("statsColctEwalletJob")
				.start(statsColctEwalletStep())
				.build();  
	}//end statsColctEwalletJob()
	
	@Bean
	@JobScope
	public Step statsColctEwalletStep() {
		return stepBuilderFactory.get("statsColctEwalletStep")
				.tasklet(statsColctEwalletTasklet)
				.build();
	}//end statsColctEwalletStep()
	
}//end class()
