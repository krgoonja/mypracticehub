package com.sorincorp.batch.st.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 
 * 순위 통계 수집 batch StatsColctRankJobConfig.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class StatsColctRankJobConfig {

	@Autowired
	StatsColctRankTasklet statsColctRankTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory; 
	
	@Bean
	public Job statsColctRankJob() {
		return jobBuilderFactory.get("statsColctRankJob")
				.start(statsColctRankStep())
				.build();  
	}//end statsColctRankJob()
	
	@Bean
	@JobScope
	public Step statsColctRankStep() {
		return stepBuilderFactory.get("statsColctRankStep")
				.tasklet(statsColctRankTasklet)
				.build();
	}//end statsColctRankStep()
	
}//end class()
