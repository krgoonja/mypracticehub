package com.sorincorp.batch.st.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 
 * 재고 통계 수집 batch StatsColctInvntryJobConfig.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class StatsColctInvntryJobConfig {

	@Autowired
	StatsColctInvntryTasklet statsColctInvntryTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory; 
	
	@Bean
	public Job statsColctInvntryJob() {
		return jobBuilderFactory.get("statsColctInvntryJob")
				.start(statsColctInvntryStep())
				.build();  
	}//end statsColctInvntryJob()
	
	@Bean
	@JobScope
	public Step statsColctInvntryStep() {
		return stepBuilderFactory.get("statsColctInvntryStep")
				.tasklet(statsColctInvntryTasklet)
				.build();
	}//end statsColctInvntryStep()
	
}//end class()
