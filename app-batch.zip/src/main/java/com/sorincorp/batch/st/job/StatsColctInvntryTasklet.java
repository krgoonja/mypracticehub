package com.sorincorp.batch.st.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.st.service.StatsColctInvntryService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 재고 통계 수집 batch StatsColctInvntryTasklet.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Slf4j
@Component
public class StatsColctInvntryTasklet implements Tasklet, StepExecutionListener {
	
	@Autowired
	StatsColctInvntryService statsColctInvntryService;
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("StatsColctInvntryTasklet::beforeStep");
	}//end beforeStep

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("StatsColctInvntryTasklet::execute Start");
		statsColctInvntryService.invntryStatsColct();
		log.debug("StatsColctInvntryTasklet::execute End");
		return RepeatStatus.FINISHED;
	}//end execute()
	
	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("StatsColctInvntryTasklet::afterStep");
		return ExitStatus.COMPLETED;
	}//end afterStep()

}//end class()
