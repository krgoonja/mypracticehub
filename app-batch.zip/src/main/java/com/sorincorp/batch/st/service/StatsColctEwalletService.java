package com.sorincorp.batch.st.service;

/**
 * 
 * 이월렛 통계 batch StatsColctEwalletService.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
public interface StatsColctEwalletService {

}//end interface()
