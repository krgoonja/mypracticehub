package com.sorincorp.batch.st.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.st.mapper.StatsColctSelngMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 매출 통계 StatsColctSelngServiceImpl.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Slf4j
@Service
public class StatsColctSelngServiceImpl implements StatsColctSelngService {

	@Autowired
	StatsColctSelngMapper statsColctSelngMapper;

	/**매출 통계 수집*/
	@Override
	public void selngStatsColct() {
		log.debug("StatsColctSelngServiceImpl::selngStatsColct Start");
		
		try {
			statsColctSelngMapper.selngStatsColct();
		} catch (Exception e) {
			log.debug("StatsColctSelngServiceImpl::selngStatsColct exception = " + e.getMessage());
		}
		
		
		log.debug("StatsColctSelngServiceImpl::selngStatsColct End");
	}//end selngStatsColct()
	
}//end class()
