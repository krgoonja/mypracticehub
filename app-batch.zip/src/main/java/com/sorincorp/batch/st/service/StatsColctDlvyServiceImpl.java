package com.sorincorp.batch.st.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.st.mapper.StatsColctDlvyMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 배송 통계 StatsColctDlvyServiceImpl.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Slf4j
@Service
public class StatsColctDlvyServiceImpl implements StatsColctDlvyService {

	@Autowired
	StatsColctDlvyMapper statsColctDlvyMapper;
	
}//end class()
