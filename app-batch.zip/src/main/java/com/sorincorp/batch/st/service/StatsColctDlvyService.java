package com.sorincorp.batch.st.service;

/**
 * 
 * 배송 통계 batch StatsColctDlvyService.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
public interface StatsColctDlvyService {

}//end interface()
