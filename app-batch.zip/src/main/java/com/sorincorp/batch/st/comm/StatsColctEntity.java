package com.sorincorp.batch.st.comm;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * 통계 Batch 공통 StatsColctEntity.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class StatsColctEntity {

	/* 응답 코드 */
	private int responseCode;
	
	/* 응답 MSG */
	private String msg;
	
	/* 응답 DATA */
	private Object data;
	
}//end class()
