package com.sorincorp.batch.st.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * 매출 통계 StatsColctMktVO.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel("매출 통계 VO")
public class StatsColctMktVO {

}//end class()
