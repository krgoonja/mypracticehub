package com.sorincorp.batch.st.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 
 * 매출 통계 수집 batch StatsColctSelngJobConfig.java
 * @version
 * @since 2021. 11. 11.
 * @author srec0054
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class StatsColctSelngJobConfig {

	@Autowired
	StatsColctSelngTasklet statsColctSelngTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory; 
	
	@Bean
	public Job statsColctSelngJob() {
		return jobBuilderFactory.get("statsColctSelngJob")
				.start(statsColctSelngStep())
				.build();  
	}//end statsColctSelngJob()
	
	@Bean
	@JobScope
	public Step statsColctSelngStep() {
		return stepBuilderFactory.get("statsColctSelngStep")
				.tasklet(statsColctSelngTasklet)
				.build();
	}//end statsColctSelngStep()
	
}//end class()
