package com.sorincorp.batch.lo.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 물류 출고 중지 배치 JobConfig (중도상환 미납건 대상)
 * @version
 * @since 2024. 7. 15.
 * @author srec0066
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class LgistDlivyStpgeJobConfig {

	@Autowired
	LgistDlivyStpgeTasklet lgistDlivyStpgeTasklet;

	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job lgistDlivyStpgeJob() {
		return jobBuilderFactory.get("lgistDlivyStpgeJob")
				.start(lgistDlivyStpgeStep())
				.build();
	}

	@Bean
	@JobScope
	public Step lgistDlivyStpgeStep() {
		return stepBuilderFactory.get("lgistDlivyStpge")
				.tasklet(lgistDlivyStpgeTasklet)
				.build();
	}
}
