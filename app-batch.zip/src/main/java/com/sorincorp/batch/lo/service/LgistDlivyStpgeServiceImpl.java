package com.sorincorp.batch.lo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.lo.mapper.LgistDlivyStpgeMapper;
import com.sorincorp.batch.lo.model.LgistRehndlVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.message.service.CdtlnMessageService;

import lombok.extern.slf4j.Slf4j;

/**
 * 물류 출고 중지 배치 Service 구현체 클래스
 * @version
 * @since 2024. 7. 15.
 * @author srec0066
 */
@Slf4j
@Service
public class LgistDlivyStpgeServiceImpl implements LgistDlivyStpgeService {

	/**
	 * 여신 메세지/이메일 발송 공통 서비스
	 */
	@Autowired
	private CdtlnMessageService cdtlnMessageService;
	
	@Autowired
	private LgistDlivyStpgeMapper lgistDlivyStpgeMapper;

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Value("${order.api.lo.url}")
	private String loOmsUrl;

	/**
	 *	중도상환 미납건 물류 출고 중지 실행
	 */
	@Override
	public void doLgistDlivyStpge() throws Exception {

		// 1. 중도상환 미납건 목록 조회
		List<LgistRehndlVO> targetOrderList = lgistDlivyStpgeMapper.selectLgistDlivyStpgeTrgtList();

		// 2. 물류 출고중지 API 송신
		for (LgistRehndlVO order: targetOrderList) {
			try {

				Map<String, String> reqObj = new HashMap<>();
				reqObj.put("ecOrderNo", order.getOrderNo());           // EC 주문번호
				reqObj.put("omsOrderRceptNo", order.getOmsRceptNo());  // OMS 주문 접수 번호
				reqObj.put("orderSttus", order.getOrderSttus()); 	   // 주문 상태 - 3:출고 중지

	            // 출고 중지 송신
				Map<String, Object> resObj = httpClientHelper.postCallApi(loOmsUrl + "/OrderSttusChange", reqObj);
				log.info("LgistDlivyStpgeService 출고 중지 API orderNo: {}, resObj: {}", order.getOrderNo(), String.valueOf(resObj));

				if(resObj != null && resObj.get("rspnsCode") != null && StringUtils.equals(resObj.get("rspnsCode").toString(), "200")) {
					log.info("LgistDlivyStpgeService 출고 중지 API 송신결과 - 성공");
				} else {
					log.info("LgistDlivyStpgeService 출고 중지 API 송신결과 - 실패");
				}
			} catch (Exception e) {

				log.info("LgistDlivyStpgeService 출고 중지 API 호출 ERROR: ", ExceptionUtils.getStackTrace(e));
			} finally {
				if(targetOrderList.size() > 0 && order != null) {
					// API 송신 성공 or 실패 여부와 상관없이 SMS 발송
					// 출고중지 및 출고중지 해제 SMS 전송 공통 서비스
					//    , dlivyStpgeCode[출고 중지 코드] : stpge(중지), relis(해제)
					//    , outptAmount [출력 금액] : stpge(중지) 시 미납금액, relis(해제) 시 결제금액
					cdtlnMessageService.sendDlivyStpgeRelisSms("stpge", order.getOrderNo(), order.getNrdmpAmount(), 145);
				}
			}
		}
	}

}
