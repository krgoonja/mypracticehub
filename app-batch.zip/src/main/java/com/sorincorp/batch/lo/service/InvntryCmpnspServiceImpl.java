package com.sorincorp.batch.lo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.lo.mapper.InvntryCmpnspMapper;
import com.sorincorp.batch.lo.model.InvntryCmpnspVO;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 재고 대사 Batch ServiceImpl.java
 * @version
 * @since 2021. 9. 7.
 * @author srec0054
 */
@Slf4j
@Service
public class InvntryCmpnspServiceImpl implements InvntryCmpnspService {

	@Autowired
	private InvntryCmpnspMapper invntryCmpnspMapper;

	/**
	 * 재고 대사 데이터 수집
	 */
	@Override
	public void saveInvntryCmpnsp() throws Exception {
		log.debug("InvntryCmpnspServiceImpl:saveInvntryCmpnsp (재고 대사) Start");
		InvntryCmpnspVO paramVo = new InvntryCmpnspVO(); 
		
		try {
			String batchJobNm = "invntryCmpnspJob";
			
			paramVo.setFrstRegisterId(batchJobNm);
			paramVo.setLastChangerId(batchJobNm);
			
			//재고 대사 데이터 수집
			invntryCmpnspMapper.saveInvntryCmpnsp(paramVo);
		} catch (Exception e) {
			log.error("InvntryCmpnspServiceImpl::saveInvntryCmpnsp exception = " + e.getMessage());
		} 
		
		log.debug("InvntryCmpnspServiceImpl:saveInvntryCmpnsp (재고 대사) Etart");
	}//end saveInvntryCmpnsp()

}//end class()
