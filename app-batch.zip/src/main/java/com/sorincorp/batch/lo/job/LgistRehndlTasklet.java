package com.sorincorp.batch.lo.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.lo.service.LgistRehndlService;

import lombok.extern.slf4j.Slf4j;

/**
 * 물류 재처리 전송 배치 Tasklet
 * @version
 * @since 2023. 6. 12.
 * @author srec0066
 */
@Slf4j
@Component
public class LgistRehndlTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	LgistRehndlService lgistRehndlService;

	public void beforeStep(StepExecution stepExecution) {
		log.debug("LgistRehndlTasklet::beforeStep");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("LgistRehndlTasklet::execute Start");

		lgistRehndlService.doLgistRehndl();

		log.debug("LgistRehndlTasklet::execute End");

		return RepeatStatus.FINISHED;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("LgistRehndlTasklet::afterStep");
        return ExitStatus.COMPLETED;
	}

}
