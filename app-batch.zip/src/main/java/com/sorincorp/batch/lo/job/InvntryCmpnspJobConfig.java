package com.sorincorp.batch.lo.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 
 * 재고 대사 수집 배치 JobConfig
 * @version
 * @since 2021. 9. 14.
 * @author srec0054
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class InvntryCmpnspJobConfig {

	@Autowired
	InvntryCmpnspTasklet invntryCmpnspTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory;
	
	@Bean
	public Job invntryCmpnspJob() {
		return jobBuilderFactory.get("invntryCmpnspJob")
				.start(invntryCmpnspStep())
				.build();  
	}//end taxBillRecptnJob()
	
	@Bean
	@JobScope
	public Step invntryCmpnspStep() {
		return stepBuilderFactory.get("invntryCmpnspStep")
				.tasklet(invntryCmpnspTasklet)
				.build();
	}//end taxBillRecptnStep()
	
}//end class()
