package com.sorincorp.batch.lo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.lo.mapper.LgistRehndlMapper;
import com.sorincorp.batch.lo.model.LgistRehndlVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.message.service.SMSService;

import lombok.extern.slf4j.Slf4j;

/**
 * 물류 재처리 전송 배치 Service 구현체 클래스
 * @version
 * @since 2023. 6. 12.
 * @author srec0066
 */
@Slf4j
@Service
public class LgistRehndlServiceImpl implements LgistRehndlService {

	@Autowired
	private LgistRehndlMapper lgistRehndlMapper;

	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private SMSService smsService;

	@Value("${order.api.lo.url}")
	private String loOmsUrl;

	/**
	 *	물류 재처리 실행
	 */
	@Override
	public void doLgistRehndl() throws Exception {

		// 1. SORIN_SETUP_CODE 설정값 조회
		// 1-1. 주문별 물류 전송 횟수 조회
		CommonCodeVO cntInfo = Optional.ofNullable(commonCodeService.getCodeValueRetVo("SORIN_SETUP_CODE", "ORDER_LGIST_TRN_CNT"))
										.orElseThrow(() -> {return new Exception("주문별 물류 전송 횟수(ORDER_LGIST_TRN_CNT) 정보 미존재");});

		int lgistTrnCnt = Integer.parseInt(cntInfo.getCodeDcone());

		// 1-2. 주문별 물류 배치 전송 주기(초) 조회
		CommonCodeVO cycleInfo = Optional.ofNullable(commonCodeService.getCodeValueRetVo("SORIN_SETUP_CODE", "ORDER_LGIST_BATCH_TRN_CYCLE"))
										.orElseThrow(() -> {return new Exception("주문별 물류 배치 전송 주기(ORDER_LGIST_BATCH_TRN_CYCLE) 정보 미존재");});

		double batchTrnCycleDob = Double.parseDouble(cycleInfo.getCodeDcone());
		int lgistBatchTrnSecond = (int) (batchTrnCycleDob * 1000);

		log.info("물류 전송 횟수: " + lgistTrnCnt + ", 물류 배치 전송 주기(millisecond): " + batchTrnCycleDob);

		// 2. 물류 재처리 대상 조회
		List<LgistRehndlVO> targetOrderList = lgistRehndlMapper.selectLgistRehndlTrgtList(lgistTrnCnt);
		log.info("물류 재처리 대상 조회: " + targetOrderList.toString());

		// 3. 물류 OMS 전송
		for (LgistRehndlVO order: targetOrderList) {

			try {
				Map<String, Object> resObj = httpClientHelper.postCallApi(loOmsUrl + "/SetleInfo/" + order.getOrderNo() + "/1/" + order.getOrderSttus(), null);
				log.info(">> ["+ order.getOrderNo() +"] OMS 송신 결과: " + String.valueOf(resObj));
				if(resObj != null && resObj.get("omsOrderRceptNo") != null) {

					order.setOmsRceptNo(String.valueOf(resObj.get("omsOrderRceptNo")));
				} else {
					// 물류 전송 횟수만큼 재전송 했으나 실패인 경우에는 알림톡 발송
					procSms(order, lgistTrnCnt);
				}

				// 4. OR_ORDER_BAS 업데이트 & 이력 등록 >> 물류 재처리 전송 횟수/oms 접수 번호/주문 상태 코드
				int uptRes = lgistRehndlMapper.updateLastOrderMaster(order);
				if(uptRes > 0) {
					lgistRehndlMapper.insertOrOrderBasHst(order);
				}

				// 설정된 배치 전송 주기만큼 대기 후 OMS 전송
				Thread.sleep(lgistBatchTrnSecond);

			} catch (Exception e) {
				log.info(">> ["+ order.getOrderNo() +"] 물류 API호출 실패 : " + ExceptionUtils.getStackTrace(e));
				// 물류 전송 횟수만큼 재전송 했으나 실패인 경우에는 알림톡 발송
				procSms(order, lgistTrnCnt);
			}
		}
	}

	/**
	 *	물류 실패 SMS 발송 : 내부사용자 대상
	 */
	private void procSms(LgistRehndlVO order, int lgistTrnCnt) {
		if((order.getLgistRehndlTrnsmisCo() + 1) == lgistTrnCnt) {
			log.info(">> 물류 전송 횟수만큼 재전송 시도했으나 실패:: SMS 발송");

			Map<String, String> smsMap = new HashMap<>();
			smsMap.put("templateNum", "44");					// [44] 물류(결제정보) 송신 실패
			smsMap.put("orderNo", order.getOrderNo()); 			// 주문번호
			smsMap.put("returnMsg", "물류 OMS번호 수신 실패"); 		// 주문 데이터 물류IF시 오류 발생
			smsMap.put("commerceNtcnCn", "물류(결제정보) 송신 실패");  // 알림 메세지

			// 내부사용자 별도 전송
			smsMap.put("commerceNtcnAt", "Y"); 					// 추가 수신사 커머스 알림 여부 따로 설정
			smsMap.put("excpSndngOptnAt", "Y"); 				// 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.

			smsService.insertSMS(null, smsMap);
		}
	}

}
