package com.sorincorp.batch.lo.service;

/**
 * 물류 출고 중지 배치 Service 인터페이스
 * @version
 * @since 2024. 7. 15.
 * @author srec0066
 */
public interface LgistDlivyStpgeService {

	/**
	 * <pre>
	 * 처리내용: 중도상환 미납건 물류 출고 중지 실행
	 * </pre>
	 * @date 2024. 7. 15.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 7. 15.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	void doLgistDlivyStpge() throws Exception;
}
