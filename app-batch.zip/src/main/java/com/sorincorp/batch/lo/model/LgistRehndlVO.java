package com.sorincorp.batch.lo.model;

import lombok.Data;

/**
 * 물류 재처리 전송 배치 VO 클래스
 * @version
 * @since 2023. 6. 12.
 * @author srec0066
 */
@Data
public class LgistRehndlVO {

	/** 주문번호 **/
	private String orderNo;

	/** 주문 상태: 0가주문 1실주문 **/
	private String orderSttus;

	/** 주문 상태 코드 **/
	private String orderSttusCode;

	/** 물류 재처리 전송 횟수 **/
	private int lgistRehndlTrnsmisCo;

	/** oms 접수 번호 **/
	private String omsRceptNo;
	
	/** 미상환 금액 **/
	private Long nrdmpAmount;

}
