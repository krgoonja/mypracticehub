package com.sorincorp.batch.lo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.batch.lo.comm.InvntryCmpnspConstants;
import com.sorincorp.batch.lo.comm.InvntryCmpnspResponseEntity;
import com.sorincorp.batch.lo.service.InvntryCmpnspService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 재고 대사 Controller.java
 * @version
 * @since 2021. 9. 7.
 * @author srec0054
 */
@Slf4j
@RestController
@RequestMapping("/batch/lo")
@Api( value = "재고 대사 Batch Controller")
@ComponentScan("com.sorincorp.comm.*")
public class InvntryCmpnspController {
	
	@Autowired
	private InvntryCmpnspService invntryCmpnspService;
	
	@PostMapping("/saveInvntryCmpnsp")
	@ApiOperation(value = "재고 대사 Batch", notes = "재고 대사 Batch")
	public InvntryCmpnspResponseEntity saveInvntryCmpnsp() throws Exception{
		log.debug("InvntryCmpnspController:saveInvntryCmpnsp (재고 대사 Batch) Start");
		try {
			invntryCmpnspService.saveInvntryCmpnsp();
		} catch (Exception e) {
			log.debug("InvntryCmpnspController:saveInvntryCmpnsp exception = " + e.getMessage());
		}
		log.debug("InvntryCmpnspController:saveInvntryCmpnsp (재고 대사 Batch) End");
		return new InvntryCmpnspResponseEntity(InvntryCmpnspConstants.SUCCESS_CODE, InvntryCmpnspConstants.SUCCESS_MSG, null);
	}//end saveInvntryCmpnsp()

}//end class()
