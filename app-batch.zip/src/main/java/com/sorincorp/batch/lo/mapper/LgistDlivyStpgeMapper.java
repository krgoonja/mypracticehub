package com.sorincorp.batch.lo.mapper;

import java.util.List;

import com.sorincorp.batch.lo.model.LgistRehndlVO;

/**
 * 물류 출고 중지 배치 Mapper
 * @version
 * @since 2024. 7. 15.
 * @author srec0066
 */
public interface LgistDlivyStpgeMapper {

	/**
	 * <pre>
	 * 처리내용: 중도상환 미납 주문 목록을 조회한다.
	 * </pre>
	 * @date 2024. 7. 15.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 7. 15.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	List<LgistRehndlVO> selectLgistDlivyStpgeTrgtList() throws Exception;
}
