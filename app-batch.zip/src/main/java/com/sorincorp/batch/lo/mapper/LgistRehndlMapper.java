package com.sorincorp.batch.lo.mapper;

import java.util.List;

import com.sorincorp.batch.lo.model.LgistRehndlVO;

/**
 * 물류 재처리 전송 배치 Mapper
 * @version
 * @since 2023. 6. 12.
 * @author srec0066
 */
public interface LgistRehndlMapper {

	/**
	 * <pre>
	 * 처리내용: 물류 재처리 대상 주문 목록을 조회한다.
	 * </pre>
	 * @date 2023. 6. 13.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 13.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param lgistTrnCnt
	 * @return
	 * @throws Exception
	 */
	List<LgistRehndlVO> selectLgistRehndlTrgtList(int lgistTrnCnt) throws Exception;

	/**
	 * <pre>
	 * 처리내용: OR_ORDER_BAS를 업데이트 한다.
	 * 		  물류 재처리 전송 횟수/oms 접수 번호/주문 상태 코드
	 * </pre>
	 * @date 2023. 6. 13.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 13.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param lgistRehndlVO
	 * @return
	 * @throws Exception
	 */
	int updateLastOrderMaster(LgistRehndlVO lgistRehndlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: OR_ORDER_BAS_HST 이력을 등록한다.
	 * </pre>
	 * @date 2023. 6. 13.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 13.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param lgistRehndlVO
	 * @throws Exception
	 */
	void insertOrOrderBasHst(LgistRehndlVO lgistRehndlVO) throws Exception;
}
