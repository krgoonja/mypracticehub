package com.sorincorp.batch.lo.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 물류 재처리 전송 배치 JobConfig
 * @version
 * @since 2023. 6. 12.
 * @author srec0066
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class LgistRehndlJobConfig {

	@Autowired
	LgistRehndlTasklet lgistRehndlTasklet;

	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job lgistRehndlJob() {
		return jobBuilderFactory.get("lgistRehndlJob")
				.start(lgistRehndlStep())
				.build();
	}

	@Bean
	@JobScope
	public Step lgistRehndlStep() {
		return stepBuilderFactory.get("lgistRehndlStep")
				.tasklet(lgistRehndlTasklet)
				.build();
	}

}
