package com.sorincorp.batch.lo.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.lo.service.InvntryCmpnspService;

import lombok.extern.slf4j.Slf4j;

/**
 * 재고 대사 수집 배치 Tasklet
 * InvntryCmpnspTasklet.java
 * @version
 * @since 2021. 9. 14.
 * @author srec0054
 */
@Slf4j
@Component
public class InvntryCmpnspTasklet implements Tasklet, StepExecutionListener {
	
	@Autowired
	InvntryCmpnspService invntryCmpnspService;
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("InvntryCmpnspTasklet::beforeStep");
	}//end beforeStep()

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("InvntryCmpnspTasklet::execute Start");
		
		invntryCmpnspService.saveInvntryCmpnsp();
		
		log.debug("InvntryCmpnspTasklet::execute End");
		return RepeatStatus.FINISHED;
	}//end execute()
	
	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("InvntryCmpnspTasklet::afterStep");
		return ExitStatus.COMPLETED;
	}//end afterStep()

}//end class()
