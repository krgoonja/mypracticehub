/**
 *
 */
package com.sorincorp.batch.lo.service;

/**
 * 물류 재처리 전송 배치 Service 인터페이스
 * @version
 * @since 2023. 6. 12.
 * @author srec0066
 */
public interface LgistRehndlService {

	/**
	 * <pre>
	 * 처리내용: 물류 재처리 실행
	 * </pre>
	 * @date 2023. 6. 12.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 12.			srec0066			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	void doLgistRehndl() throws Exception;

}
