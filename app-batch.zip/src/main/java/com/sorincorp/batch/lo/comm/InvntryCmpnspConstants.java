package com.sorincorp.batch.lo.comm;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 재고대사 수신 Batch Constants.java
 * @version
 * @since 2021. 9. 7.
 * @author srec0054
 */
@Slf4j
public class InvntryCmpnspConstants {

	private InvntryCmpnspConstants() {
		log.debug(InvntryCmpnspConstants.class.getSimpleName());
	}
	
	/**RESULT*/
	public static final int SUCCESS_CODE 			= 200;
	public static final int ERROR_CODE 				= 400;
	public static final String SUCCESS_RESULT_CODE	= "200";
	public static final String ERROR_RESULT_CODE 	= "500";
	public static final String SUCCESS_MSG 			= "Success";
	public static final String ERROR_MSG 			= "Error";
	public static final String EHR_REPONSE_RESULT_MSG 	= "result_msg";
	public static final String EHR_REPONSE_RESULT_DATA 	= "result_data";
	public static final String EHR_REPONSE_RESULT_CODE 	= "result_code";
	
	/**인터페이스 ID*/
	public static final String INVNTRY_CMPNSP_IF	= "SOREC-IF-999";	//재고 대사 인터페이스
	
}//end class()
