package com.sorincorp.batch.lo.mapper;

import com.sorincorp.batch.lo.model.InvntryCmpnspVO;

/**
 * 
 * 재고 대사 Batch Mapper.java
 * @version
 * @since 2021. 9. 7.
 * @author srec0054
 */
public interface InvntryCmpnspMapper {

	/**
	 * 
	 * <pre>
	 * 재고 대사 데이터 수집
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	InvntryCmpnspVO paramVo
	 * @throws 	Exception
	 */
	void saveInvntryCmpnsp(InvntryCmpnspVO paramVo);
	
}//end interface()
