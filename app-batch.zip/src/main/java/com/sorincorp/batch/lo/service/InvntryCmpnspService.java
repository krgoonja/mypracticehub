package com.sorincorp.batch.lo.service;

/**
 * 
 * 재고 대사 Batch Service.java
 * @version
 * @since 2021. 9. 7.
 * @author srec0054
 */
public interface InvntryCmpnspService {
	
	/**
	 * 
	 * <pre>
	 * 재고 대사 데이터 수집
	 * </pre>
	 * @date 2021. 9. 7.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 7.			srec0054			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	void saveInvntryCmpnsp() throws Exception;
	
}//end interface()
