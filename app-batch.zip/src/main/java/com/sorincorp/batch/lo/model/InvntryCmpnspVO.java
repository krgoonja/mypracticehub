package com.sorincorp.batch.lo.model;

import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel("재고 대사 Batch VO")
public class InvntryCmpnspVO {
	
	/**최초 등록자 아이디*/
	private String frstRegisterId;
	
	/**최종 변경자 아이디*/
	private String lastChangerId;
}//end class()
