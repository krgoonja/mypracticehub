package com.sorincorp.batch.it.mapper;

import java.util.List;

import com.sorincorp.batch.it.model.LgistCstdyWonCtCalcVO;

public interface LgistCstdyWonCtCalcMapper {

	/**
	 * <pre>
	 * PO 기본 마스터 리스트 조회
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 8.			srec0030			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<LgistCstdyWonCtCalcVO> selectItPurchsInfoBasList() throws Exception;

	/**
	 * <pre>
	 * PO 기본 마스터 테이블의 물류 보관 원화 비용(LGIST_CSTDY_WON_CT)을 UPDATE
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 8.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param lgistCstdyWonCtCalcVO
	 * @return
	 */
	int updateItPurchsInfoBas(LgistCstdyWonCtCalcVO lgistCstdyWonCtCalcVO) throws Exception;

	/**
	 * <pre>
	 * PO 기본 마스터 이력테이블 INSERT
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 8.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param lgistCstdyWonCtCalcVO
	 */
	int insertItPurchsInfoBasHst(LgistCstdyWonCtCalcVO lgistCstdyWonCtCalcVO) throws Exception;

	List<LgistCstdyWonCtCalcVO> selectBlNoList(LgistCstdyWonCtCalcVO lgistCstdyWonCtCalcVO) throws Exception;

	int updateItBlInfoBas(LgistCstdyWonCtCalcVO blNoVO) throws Exception;

	int insertItBlInfoBasHst(LgistCstdyWonCtCalcVO blNoVO) throws Exception;

}
