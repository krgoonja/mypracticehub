package com.sorincorp.batch.it.service;

public interface BlSleSttusCodeChgService {

	//	int blSleSttusCodeChg() throws Exception;
	void blSleSttusCodeChg() throws Exception;

	int insertIsecoSleClBas() throws Exception;

}
