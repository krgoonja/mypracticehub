package com.sorincorp.batch.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.it.mapper.BlSleSttusCodeChgMapper;
import com.sorincorp.batch.it.model.BlSleSttusCodeChgVO;
import com.sorincorp.batch.it.model.IsecoVO;
import com.sorincorp.comm.common.mapper.CommonMapper;
import com.sorincorp.comm.common.service.CommonService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BlSleSttusCodeChgServiceImpl implements BlSleSttusCodeChgService {

	@Autowired
	BlSleSttusCodeChgMapper blSleSttusCodeChgMapper;
	@Autowired
	private CommonMapper commonMapper;
	@Autowired
	CommonService commonService;

	@Override
//	public int blSleSttusCodeChg() throws Exception {
	public void blSleSttusCodeChg() throws Exception {
		// TODO Auto-generated method stub

//		int blStopCnt = 0;
//		int blReadyCnt = 0;
		BlSleSttusCodeChgVO vo;

//		 BL번호
//		String blNo = "";
//		// BL만기경과여부
//		String blExpiryYn = "";
//		// 소수점여부
//		String decimalYn = "";
//		// 선물환 관리번호
//		String fshgManageNo = "";
//		// 삼성선물계약번호
//		String ftrsThsexCntrctNo = "";
//		// 판매상태코드
//		String sleSttusCode = "";
//		// 선물환 관리번호 카운트
//		int fshgManageNoCnt = 0;
//		// 통관여부
//		String entrAt = "";
//		// 판매불가 사유코드
//		String sleImprtyResn = "";
//		// 선물 최초 수량
//		String ftrsDelngLotOrgQy = "";
//		// 선물 최초 중량
//		String fshgDlryOrgWt = "";
//		// 선물환 최초 체결 금액
//		String fshgDelngDollarOrgAmount = "";
//		// 구매라인번호
//		String poBlNo = "";
//		// 선물 만기 -1 여부
//		String ftrsExpiryYn = "";
//		// 선물환 만기일-2 여부
//		String fshgExpiryYn = "";

		List<BlSleSttusCodeChgVO> blSleSttusCodeChgList = blSleSttusCodeChgMapper.selectBlSleSttusCodeChgList();

		if (blSleSttusCodeChgList != null) {
			for (int i = 0; i < blSleSttusCodeChgList.size(); i++) {
				vo = blSleSttusCodeChgList.get(i);
				vo.setLastChangerId("BlSleSttusCodeChg BATCH");
				
				commonService.blSleSttusCodeChg(vo.getBlNo(), vo.getLastChangerId());
				
//
//				blNo = vo.getBlNo();
//				blExpiryYn = vo.getBlExpiryYn();
//				decimalYn = vo.getDecimalYn();
//				fshgManageNo = vo.getFshgManageNo();
//				fshgManageNoCnt = vo.getFshgManageNoCnt();
//				ftrsThsexCntrctNo = vo.getFtrsThsexCntrctNo();
//				sleSttusCode = vo.getSleSttusCode();
//				entrAt = vo.getEntrAt();
//				ftrsDelngLotOrgQy = vo.getFtrsDelngLotOrgQy();
//				fshgDlryOrgWt = vo.getFshgDlryOrgWt();
//				fshgDelngDollarOrgAmount = vo.getFshgDelngDollarOrgAmount();
//				poBlNo = vo.getPoBlNo();
//				sleImprtyResn = "";
//				ftrsExpiryYn = vo.getFtrsExpiryYn();
//				fshgExpiryYn = vo.getFshgExpiryYn();
//
//				// PO 정보 없을 경우 판매불가
//				if (poBlNo == null || "".equals(poBlNo)) {
//					if (!"04".equals(sleSttusCode)) {
//						// 만기경과
//						sleImprtyResn = "매입정보 미존재";
//
//						vo.setSleSttusCode("04");
//						vo.setSleImprtyResn(sleImprtyResn);
//
//						blStopCnt += blSleSttusCodeChgMapper.updateItBlInfoBas(vo);
////						blSleSttusCodeChgMapper.insertItBlInfoBasHst(vo);
//						commonMapper.insertItBlInfoBasHst(vo.getBlNo());
//					}
//				} else {
//					// BL 판매상태코드 04(만기경과)로 업데이트
//					// if("Y".equals(blExpiryYn) || "".equals(fshgManageNo) || fshgManageNo == null
//					// || fshgManageNoCnt < 1 || "Y".equals(decimalYn) ||
//					// "".equals(ftrsThsexCntrctNo) || ftrsThsexCntrctNo == null ||
//					// !"Y".equals(entrAt)) {
//					if ("Y".equals(blExpiryYn) || "Y".equals(decimalYn) || !"Y".equals(entrAt) || ftrsDelngLotOrgQy == null || fshgDlryOrgWt == null || fshgDelngDollarOrgAmount == null) {
//						// 만기경과(판매중지) 상태가 아닌 BL만 업데이트
//						if (!"04".equals(sleSttusCode) || ("04".equals(sleSttusCode) && "매입정보 미존재".equals(vo.getSleImprtyResn()))) {
//							log.debug("=========================STOP========================================");
//							log.debug("BL_NO                 :" + blNo);
//							log.debug("BL_SEL_STOP_YN        :" + blExpiryYn);
//							log.debug("DECIMAL_YN            :" + decimalYn);
//							log.debug("FSHG_MANAGE_NO        :" + fshgManageNo);
//							log.debug("FSHG_MANAGE_NO_CNT    :" + fshgManageNoCnt);
//							log.debug("FTRS_THSEX_CNTRCT_NO  :" + ftrsThsexCntrctNo);
//							log.debug("ENTR_AT               :" + entrAt);
//							log.debug("SLE_STTUS_CODE        :" + sleSttusCode);
//							log.debug("FTRS_DELNG_LOT_ORG_QY :" + ftrsDelngLotOrgQy);
//							log.debug("FSHG_DLRY_ORG_WT      :" + fshgDlryOrgWt);
//							log.debug("FSHG_DELNG_DOLLAR_ORG_AMOUNT :" + fshgDelngDollarOrgAmount);
//							log.debug("FTRS_SEL_STOP_YN      :" + ftrsExpiryYn);
//							log.debug("FSHG_SEL_STOP_YN      :" + fshgExpiryYn);
//							log.debug("=====================================================================");
//
//							if ("Y".equals(fshgExpiryYn) && "N".equals(ftrsExpiryYn)) {
//								sleImprtyResn += "선물환 만기 도래예정";
//							} else if ("N".equals(fshgExpiryYn) && "Y".equals(ftrsExpiryYn)) {
//								sleImprtyResn += "선물 만기 도래예정";
//							} else if ("Y".equals(ftrsExpiryYn) && "Y".equals(fshgExpiryYn)) {
//								sleImprtyResn += "선물 선물환 만기 도래예정";
//							} else {
//								sleImprtyResn += "강제청산";
//							}
//
//							if (!"Y".equals(entrAt)) {
//								// 미통관
//								if (!"".equals(sleImprtyResn)) {
//									sleImprtyResn += ",";
//								}
//								sleImprtyResn += "미통관";
//							}
//
////							if ("".equals(fshgManageNo) || fshgManageNo == null || fshgManageNoCnt < 1) {
////								if (!"".equals(sleImprtyResn)) {
////									sleImprtyResn += ",";
////								}
////								// 선물환관리번호 불일치
////								sleImprtyResn += "선물환관리번호 불일치";
////							}
//
////							if("".equals(ftrsThsexCntrctNo) || ftrsThsexCntrctNo == null) {
////								if(!"".equals(sleImprtyResn)) {
////									sleImprtyResn += ",";
////								}
////								//삼성선물계약번호 미존재
////								sleImprtyResn += "삼성선물계약번호 미존재";
////							}
//
//							if ("Y".equals(decimalYn)) {
//								if (!"".equals(sleImprtyResn)) {
//									sleImprtyResn += ",";
//								}
//								// 선물환달러금액/선물환배부중량 나머지 소수점
//								sleImprtyResn += "선물환달러금액/선물환배부중량 나머지 소수점";
//							}
//
//							if ("".equals(ftrsDelngLotOrgQy) || ftrsDelngLotOrgQy == null) {
//								if (!"".equals(sleImprtyResn)) {
//									sleImprtyResn += ",";
//								}
//								sleImprtyResn += "선물 최초 수량정보 미존재";
//							}
//
//							if ("".equals(fshgDlryOrgWt) || fshgDlryOrgWt == null) {
//								if (!"".equals(sleImprtyResn)) {
//									sleImprtyResn += ",";
//								}
//								sleImprtyResn += "선물 최초 중량정보 미존재";
//							}
//
//							if ("".equals(fshgDelngDollarOrgAmount) || fshgDelngDollarOrgAmount == null) {
//								if (!"".equals(sleImprtyResn)) {
//									sleImprtyResn += ",";
//								}
//								sleImprtyResn += "선물환 최초 체결 금액정보 미존재";
//							}
//
//							vo.setSleSttusCode("04");
//							vo.setSleImprtyResn(sleImprtyResn);
//
//							blStopCnt += blSleSttusCodeChgMapper.updateItBlInfoBas(vo);
////							blSleSttusCodeChgMapper.insertItBlInfoBasHst(vo);
//							commonMapper.insertItBlInfoBasHst(vo.getBlNo());
//						}
//					}
//
//					// BL 판매상태코드 01(판매대기)로 업데이트
//					// if("N".equals(blExpiryYn) && !"".equals(fshgManageNo) && fshgManageNo != null
//					// && fshgManageNoCnt > 0 && "N".equals(decimalYn)&&
//					// !"".equals(ftrsThsexCntrctNo) && ftrsThsexCntrctNo != null &&
//					// "Y".equals(entrAt)) {
//					if ("N".equals(blExpiryYn) && "N".equals(decimalYn) && "Y".equals(entrAt) && ftrsDelngLotOrgQy != null && fshgDlryOrgWt != null && fshgDelngDollarOrgAmount != null) {
//						// 만기경과(판매중지) 상태인 BL만 업데이트
//						if ("04".equals(sleSttusCode)) {
//							log.debug("=========================READY========================================");
//							log.debug("BL_NO                 :" + blNo);
//							log.debug("BL_EXPIRY_YN          :" + blExpiryYn);
//							log.debug("DECIMAL_YN            :" + decimalYn);
//							log.debug("FSHG_MANAGE_NO        :" + fshgManageNo);
//							log.debug("FSHG_MANAGE_NO_CNT    :" + fshgManageNoCnt);
//							log.debug("FTRS_THSEX_CNTRCT_NO  :" + ftrsThsexCntrctNo);
//							log.debug("ENTR_AT               :" + entrAt);
//							log.debug("SLE_STTUS_CODE        :" + sleSttusCode);
//							log.debug("======================================================================");
//
//							vo.setSleSttusCode("01");
//							vo.setSleImprtyResn("");
//
//							blReadyCnt += blSleSttusCodeChgMapper.updateItBlInfoBas(vo);
////							blSleSttusCodeChgMapper.insertItBlInfoBasHst(vo);
//							commonMapper.insertItBlInfoBasHst(vo.getBlNo());
//						}
//					}
//				}
			}
		}

//		log.debug("TOTAL EXCUTE BL SLE STOP UPDATE CNT : " + blStopCnt);
//		log.debug("TOTAL EXCUTE BL SLE READY UPDATE CNT : " + blReadyCnt);

//		return blStopCnt + blReadyCnt;
	}

	@Override
	public int insertIsecoSleClBas() throws Exception {
		// TODO Auto-generated method stub
		int result = 0;
		List<IsecoVO> blinfoBasList = blSleSttusCodeChgMapper.selectItBlInfoBasList();

		if (blinfoBasList.size() > 0) {
			blSleSttusCodeChgMapper.deletetIsecoSleClBas();
		}

		for (IsecoVO isecoVO : blinfoBasList) {
			isecoVO.setFrstRegisterId("BlSleSttusCodeChg BATCH2");
			blSleSttusCodeChgMapper.insertIsecoSleClBas(isecoVO);
			blSleSttusCodeChgMapper.insertIsecoSleClBasHst(isecoVO);

			result++;
		}

		return result;
	}

}
