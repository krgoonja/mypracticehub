package com.sorincorp.batch.it.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class LgistCstdyWonCtCalcVO extends CommonVO {

	private static final long serialVersionUID = 7640998193519462747L;

	/**
	 * 아이템순번
	 */
	private int itmSn;
	/**
	 * B/L 번호
	 */
	private String blNo;
	private String metalCode;
	private String brandCode;
	private String brandGroupCode;
	/**
	 * 요율값
	 */
	private int tariffVal;
	/**
	 * 프리타임
	 */
	private int freeTime;
	/**
	 * 물류 보관 원화 비용
	 */
	private int lgistCstdyWonCt;

	private String sleSttusCode;
	private String blSelStopYn;
	private String lastChangerId;

	private String wrhousngDe;
	private String freeDay;
	private int diffDay;
	private int chcy1;
	private int chcy2;
}
