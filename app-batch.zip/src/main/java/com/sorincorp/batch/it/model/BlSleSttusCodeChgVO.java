package com.sorincorp.batch.it.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class BlSleSttusCodeChgVO extends CommonVO {
	/**
	 *
	 */
	private static final long serialVersionUID = 2557894401698981070L;

	private String blNo;
	private String blExpiryYn;
	private String decimalYn;
	private int fshgManageNoCnt;
	private String fshgManageNo;
	private String tktAmtSameYn;
	private String ftrsThsexCntrctNo;
	private String sleSttusCode;
	private String lastChangerId;
	private String entrAt;
	private String sleImprtyResn;
	private String ftrsDelngLotOrgQy;
	private String fshgDlryOrgWt;
	private String fshgDelngDollarOrgAmount;
	private String poBlNo;
	private String ftrsExpiryYn;
	private String fshgExpiryYn;
}
