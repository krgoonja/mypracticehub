package com.sorincorp.batch.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.it.mapper.LgistCstdyWonCtCalcMapper;
import com.sorincorp.batch.it.model.LgistCstdyWonCtCalcVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LgistCstdyWonCtCalcServiceImpl implements LgistCstdyWonCtCalcService {

	@Autowired
	private LgistCstdyWonCtCalcMapper lgistCstdyWonCtCalcMapper;

	/**
	 * <pre>
	 * PO 기본 마스터 리스트를 조회하고 물류원화보관비용을 계산하여 UPDATE한다.
	 * </pre>
	 *
	 * @date 2021. 11. 8.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 11. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@Override
	public int updateLgistCstdyWonCt() throws Exception {
		// TODO Auto-generated method stub
		// PO 기본 마스터 리스트 조회
		List<LgistCstdyWonCtCalcVO> poList = lgistCstdyWonCtCalcMapper.selectItPurchsInfoBasList();
		// List<LgistCstdyWonCtCalcVO> blNoList = null;
		int cnt = 0;
		// int cnt2 = 0;
		LgistCstdyWonCtCalcVO lgistCstdyWonCtCalcVO;
		int lgistCstdyWonCt = 0;
		String lgistCstdyWonCtSameYn = "";
		// LgistCstdyWonCtCalcVO blNoVO;

		try {

			if (poList.isEmpty()) {
				return 0;
			} else {

				for (int i = 0; i < poList.size(); i++) {
					lgistCstdyWonCtCalcVO = poList.get(i);
					lgistCstdyWonCt = lgistCstdyWonCtCalcVO.getLgistCstdyWonCt();
					lgistCstdyWonCtSameYn = "Y";

					// 물류 보관 원화 비용 계산 (TariffVal*FreeTime)
					// lgistCstdyWonCtCalcVO.setLgistCstdyWonCt(lgistCstdyWonCtCalcVO.getTariffVal()
					// * lgistCstdyWonCtCalcVO.getFreeTime());
					if (lgistCstdyWonCtCalcVO.getChcy2() > 0) {
						// lgistCstdyWonCtCalcVO.setLgistCstdyWonCt(lgistCstdyWonCtCalcVO.getChcy1());
						lgistCstdyWonCtCalcVO.setLgistCstdyWonCt(lgistCstdyWonCtCalcVO.getChcy2());
					} else {
						// 보관료가 0이하 일 경우 0으로 UPDATE
						lgistCstdyWonCtCalcVO.setLgistCstdyWonCt(0);
					}

					// 물류보관비용이 기존과 다를 경우만 update
					if (lgistCstdyWonCt != lgistCstdyWonCtCalcVO.getLgistCstdyWonCt()) {
						lgistCstdyWonCtSameYn = "N";
						// PO기본마스터 UPDATE
						lgistCstdyWonCtCalcMapper.updateItPurchsInfoBas(lgistCstdyWonCtCalcVO);
						lgistCstdyWonCtCalcMapper.insertItPurchsInfoBasHst(lgistCstdyWonCtCalcVO);

						cnt++;
					}

					log.debug("=================================================================");
					log.debug("BL NO                       ==========>" + lgistCstdyWonCtCalcVO.getBlNo());
					log.debug("WRHOUSNG_DE                 ==========>" + lgistCstdyWonCtCalcVO.getWrhousngDe());
					log.debug("TARIFF_VAL                  ==========>" + lgistCstdyWonCtCalcVO.getTariffVal());
					log.debug("FREE_TIME                   ==========>" + lgistCstdyWonCtCalcVO.getFreeTime());
					log.debug("FREE_DAY                    ==========>" + lgistCstdyWonCtCalcVO.getFreeDay());
					log.debug("DIFF_DAY                    ==========>" + lgistCstdyWonCtCalcVO.getDiffDay());
					log.debug("LGIST_CSTDY_WON_CT BEFORE   ==========>" + lgistCstdyWonCt);
					log.debug("LGIST_CSTDY_WON_CT NOW      ==========>" + lgistCstdyWonCtCalcVO.getLgistCstdyWonCt());
					log.debug("LGIST_CSTDY_WON_CT SAME YN  ==========>" + lgistCstdyWonCtSameYn);
					log.debug("=================================================================");
				}

				log.debug("TOTAL EXCUTE PO LGIST_CSTDY_WON_CT UPDATE CNT : " + cnt);
				// log.debug("TOTAL EXCUTE BL UPDATE CNT : " + cnt2);
			}
		} catch (Exception e) {
			// TODO: handle exception
			log.error("updateLgistCstdyWonCt exception :", e);
			return -1;
		}

		return cnt;
	}

}
