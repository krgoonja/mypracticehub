package com.sorincorp.batch.it.service;

public interface LgistCstdyWonCtCalcService {

	int updateLgistCstdyWonCt() throws Exception;


}
