package com.sorincorp.batch.it.mapper;

import java.util.List;

import com.sorincorp.batch.it.model.BlSleSttusCodeChgVO;
import com.sorincorp.batch.it.model.IsecoVO;

public interface BlSleSttusCodeChgMapper {

	List<BlSleSttusCodeChgVO> selectBlSleSttusCodeChgList() throws Exception;

	int updateItBlInfoBas(BlSleSttusCodeChgVO vo) throws Exception;

	int insertItBlInfoBasHst(BlSleSttusCodeChgVO vo) throws Exception;

	int deletetIsecoSleClBas() throws Exception;

	int insertIsecoSleClBas(IsecoVO vo) throws Exception;

	int insertIsecoSleClBasHst(IsecoVO vo) throws Exception;

	List<IsecoVO> selectItBlInfoBasList() throws Exception;

}
