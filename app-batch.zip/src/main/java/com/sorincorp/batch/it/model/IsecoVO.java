package com.sorincorp.batch.it.model;

import java.io.Serializable;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class IsecoVO extends CommonVO implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 871046464973616780L;
	/**
	 *
	 */
	private int isecoSleClSn;
	/**
	 * 판매방식코드
	 */
	private String sleMthdCode;
	/**
	 * 금속분류코드
	 */
	private String metalClCode;
	/**
	 * 아이템코드
	 */
	private String itmCode;
	/**
	 * 아이템 순번
	 */
	private int itmSn;
	/**
	 * 대분류권역코드
	 */
	private String dstrctLclsfCode;
	/**
	 * 브랜드그룹코드
	 */
	private String brandGroupCode;
	/**
	 * 브랜드코드
	 */
	private String brandCode;
	/**
	 * 금속코드
	 */
	private String metalCode;
	private String frstRegisterId;
}
