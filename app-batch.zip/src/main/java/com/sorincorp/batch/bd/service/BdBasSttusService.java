package com.sorincorp.batch.bd.service;


/**
 * 구매입찰 상태 변경 batch Service
 * BdBasSttusService.java
 * @version
 * @since 2023. 09. 14.
 * @author sein
 */
public interface BdBasSttusService {
	
	/**
	 * 
	 * <pre>
	 * 입찰 공고 입찰예정 > 투찰중 업데이트
	 * </pre>
	 * @date 2023. 09. 14.
	 * @author sein
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 14.		sein				    최초작성
	 * ------------------------------------------------
	 */
	void sendBdBasSttus() throws Exception ;
	
	
}