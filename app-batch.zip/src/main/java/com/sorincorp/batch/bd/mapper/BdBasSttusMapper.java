package com.sorincorp.batch.bd.mapper;

import java.util.List;

import com.sorincorp.batch.bd.model.BdBasSttusVO;
import com.sorincorp.batch.bd.model.BdBddprDtlVO;

public interface BdBasSttusMapper {


	
	/**
	 * <pre>
	 * 입찰 예정 > 투찰중 변경 대상 조회
	 * </pre>
	 * @date 2023. 09. 14
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 14			sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<BdBasSttusVO> selectBdBasBeginSttusList()throws Exception ;
	
	/**
	 * <pre>
	 * 투찰중 > 서류심사중 변경 대상 조회
	 * </pre>
	 * @date 2023. 09. 14
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 14			sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<BdBasSttusVO> selectBdBasEndSttusList()throws Exception ;

	/**
	 * <pre>
	 * 입찰 예정 > 투찰중 변경 대상 업데이트
	 * </pre>
	 * @date 2023. 09. 14
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 14			sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	void updateBdBasBeginSttus(BdBasSttusVO bdBasSttusVO)throws Exception ;
	
	/**
	 * <pre>
	 * 투찰중 > 서류접수중 변경 대상 업데이트
	 * </pre>
	 * @date 2023. 09. 14
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 14			sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	void updateBdBasEndSttus(BdBasSttusVO bdBasSttusVO)throws Exception ;

	/**
	 * <pre>
	 * 투찰중 > 서류접수중 업데이트 시 투찰 기업 순위 설정(낙찰)
	 * </pre>
	 * @date 2023. 09. 14
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 14			sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	void updateBddprDtlEndSttus(BdBasSttusVO bdBasSttusVO)throws Exception ;
	
	/**
	 * <pre>
	 * 1위 기업 낙찰 상세 테이블 INSERT
	 * </pre>
	 * @date 2023. 09. 14
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 14			sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	void insertScsbidDtlEndSttus(BdBasSttusVO bdBasSttusVO)throws Exception ;
	
	/**
	 * <pre>
	 * 투찰 기업 존재 여부 개수
	 * </pre>
	 * @date 2023. 09. 14
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 14			sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	int selectBddprDtlCnt(BdBasSttusVO bdBasSttusVO)throws Exception ;
	
	/**
	 * <pre>
	 * 투찰중 > 유찰 상태로 변경 (투찰 기업 미 존재)
	 * </pre>
	 * @date 2023. 09. 14
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 14			sein					최초작성
	 * ------------------------------------------------
	 * @return
	 */
	void updateBdBasFailSttus(BdBasSttusVO bdBasSttusVO)throws Exception ;

}
