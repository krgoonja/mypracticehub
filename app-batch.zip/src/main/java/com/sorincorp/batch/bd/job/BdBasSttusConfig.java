package com.sorincorp.batch.bd.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * 구매입찰 공고 상태 배치 JobConfig
 * BdBasSttusConfig.java
 * @version
 * @since 2023. 9. 14.
 * @author sein
 */
@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class BdBasSttusConfig {
	
	@Autowired
	BdBasSttusTasklet bdBasSttusTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory; 
	
	@Bean
	public Job bdBasSttusJob() {
		return jobBuilderFactory.get("bdBasSttusJob")
				.start(bdBasSttusStep())
				.build();  
	}//end CouponJob()
	
	@Bean
	@JobScope
	public Step bdBasSttusStep() {
		return stepBuilderFactory.get("bdBasSttusStep")
				.tasklet(bdBasSttusTasklet)
				.build();
	}//end CouponStep()
	
}//end class()