package com.sorincorp.batch.bd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.batch.bd.mapper.BdBasSttusMapper;
import com.sorincorp.batch.bd.model.BdBasSttusVO;
import com.sorincorp.comm.message.service.SMSService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BdBasSttusServiceImpl implements BdBasSttusService {

	@Autowired
	private BdBasSttusMapper bdBasSttusMapper;

	/** 알림톡 발송 서비스 */
	@Autowired
	SMSService smsService;

	/**
	 * 입찰 예정 > 투찰중 변경
	 * 투찰중 	> 서류제출중 , 유찰 변경
	 * */
	@Transactional(rollbackFor = Exception.class)
	@Override
	public void sendBdBasSttus() throws Exception {

		try {
			//입찰 예정 > 투찰중 조회
			List<BdBasSttusVO> bdBasSttusBeginList = bdBasSttusMapper.selectBdBasBeginSttusList();
			//투찰중  > 서류접수중 조회
			List<BdBasSttusVO> bdBasSttusEndList = bdBasSttusMapper.selectBdBasEndSttusList();

			log.debug("BdBasSttusServiceImpl:sendBdBasSttus 구매입찰 상태 코드 변경 Start");
			//입찰 예정 > 투찰중 상태 변화
			if(bdBasSttusBeginList.size() > 0) {
				for(BdBasSttusVO vo : bdBasSttusBeginList) {
					bdBasSttusMapper.updateBdBasBeginSttus(vo);
				}
			}
			//투찰중 >마감,유찰 상태 변화
			if(bdBasSttusEndList.size() > 0) {
				for(BdBasSttusVO vo : bdBasSttusEndList) {
					bdBasSttusMapper.updateBdBasEndSttus(vo);
					//투찰 기업 개수 화인
					int bddprCnt = bdBasSttusMapper.selectBddprDtlCnt(vo);
					//투찰 기업 존재	 : 마감 (1순위:낙찰,나머지:패찰(순위로 분기))
					if(bddprCnt > 0) {
						bdBasSttusMapper.updateBddprDtlEndSttus(vo);
						bdBasSttusMapper.insertScsbidDtlEndSttus(vo);
					//투찰 기업 미존재 : 유찰
					}else {
						bdBasSttusMapper.updateBdBasFailSttus(vo);
					}
				}
			}

			log.debug("BdBasSttusServiceImpl:sendBdBasSttus 구매입찰 상태 코드 변경 end");
		
		} catch(Exception e) {
			log.error("BdBasSttusServiceImpl sendBdBasSttus 구매입찰 상태 코드 변경 ERROR " + e.getMessage());
		}
 
	}
}