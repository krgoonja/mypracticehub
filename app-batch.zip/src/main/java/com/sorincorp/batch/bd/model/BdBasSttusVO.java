package com.sorincorp.batch.bd.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 구매입찰 공고 관리 BdBasSttusVO.java
 * @version
 * @since 2023. 09. 15.
 * @author sein
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class BdBasSttusVO extends CommonVO {

	/**
	* 입찰 업체 번호 
	*/
	private String bidEntrpsNo;
	/**
	 * 입찰 공고 아이디
	 */
	private String bidPblancId;
	/**
	* 투찰 시작 일시
	*/
	private String bddprBeginDt;

	/**
	* 투찰 종료 일시
	*/
	private String bddprEndDt;

	/**
    * 입찰 상태 코드
	*/
	private String bidSttusCode;
	

	/**
	* 전시 여부
	*/
	private String dspyAt;
	/**
	* 공고 취소 여부
	*/
	private String pblancCanclAt;
	/**
	* 개찰 일시
	*/
	private String opengDt;
	
	/**
 * 삭제 여부
	*/
	private String deleteAt;
	/**
    * 삭제 일시
	*/
	private String deleteDt;
	/**
	* 최초 등록자 아이디
	*/
	private String frstRegisterId;
	/**
	* 최초 등록 일시
	*/
	private String frstRegistDt;
	/**
	* 최종 변경자 아이디
	*/
	private String lastChangerId;
	/**
	* 최종 변경 일시
	*/
	private String lastChangeDt;
}
