package com.sorincorp.batch.bd.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 투찰상세 BdBddprDtlVO.java
 * 
 * @version
 * @since 2023. 09. 15.
 * @author sein
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class BdBddprDtlVO extends CommonVO {

	/**
	 * 입찰 업체 번호
	 */
	private String bidEntrpsNo;
	/**
	 * 입찰 공고 아이디
	 */
	private String bidPblancId;
	/**
	 * 인도 조건 코드
	 */
	private String delyCndCode;
	/**
	 * 인도 조건 기준 가격
	 */
	private String delyCndStdrPc;
	/**
	 * 전환 프리미엄 금액
	 */
	private String cnvrsPremiumAmount;
	/**
	 * 투찰 프리미엄 가격
	 */
	private String bddprPremiumPc;
	/**
	 * 투찰 중량
	 */
	private String bddprWt;
	/**
	 * 참여 동의 여부
	 */
	private String partcptnAgreAt;
	/**
	 * 투찰 일시
	 */
	private String bddprDt;
	/**
	 * 투찰 정상 여부
	 */
	private String bddprNrmltAt;
	/**
	 * 개찰 순위
	 */
	private String opengRank;
	/**
	 * 개찰 일시
	 */
	private String opengDt;
	/**
	 * 낙찰 여부
	 */
	private String scsbidAt;
	/**
	 * 낙찰 일시
	 */
	private String scsbidDt;
	/**
	 * 취소 여부
	 */
	private String canclAt;
	/**
	 * 취소 일시
	 */
	private String canclDt;
	/**
	 * 취소 사유
	 */
	private String canclResn;
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;
}
