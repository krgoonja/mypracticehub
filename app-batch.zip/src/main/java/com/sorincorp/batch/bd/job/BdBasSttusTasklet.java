package com.sorincorp.batch.bd.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.bd.service.BdBasSttusService;

import lombok.extern.slf4j.Slf4j;

/**
 * 구매입찰 공고 상태 배치 JobConfig
 * BdBasSttusTasklet.java
 * @version
 * @since 2023. 9. 14.
 * @author sein
 */
@Slf4j
@Component
public class BdBasSttusTasklet implements Tasklet, StepExecutionListener {
	
	@Autowired
	BdBasSttusService bdBasSttusService;
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("BdBasSttusTasklet::beforeStep");
	}//end beforeStep()
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("BdBasSttusTasklet::execute Start");

		bdBasSttusService.sendBdBasSttus();
		
		log.debug("CouponTasklet::execute End");
		return RepeatStatus.FINISHED;
	}//end execute()
	
	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("BdBasSttusTasklet::afterStep");
        return ExitStatus.COMPLETED;
	}//end afterStep()

}//end class()