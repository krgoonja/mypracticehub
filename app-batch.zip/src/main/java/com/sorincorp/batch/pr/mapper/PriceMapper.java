package com.sorincorp.batch.pr.mapper;

public interface PriceMapper {
	
	int insertLmePriceEnd() throws Exception;

}