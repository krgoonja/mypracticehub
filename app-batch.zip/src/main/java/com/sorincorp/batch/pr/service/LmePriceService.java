package com.sorincorp.batch.pr.service;

public interface LmePriceService {
	void insertLmePriceEnd() throws Exception;
}
