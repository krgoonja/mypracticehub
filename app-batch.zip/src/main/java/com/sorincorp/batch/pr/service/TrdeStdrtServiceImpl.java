package com.sorincorp.batch.pr.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.batch.pr.mapper.TrdeStdrtMapper;
import com.sorincorp.batch.pr.model.PcSleExpectBeginPcEhgtInfoVO;
import com.sorincorp.comm.expectbeginpr.mapper.ExpectBeginPcMapper;
import com.sorincorp.comm.expectbeginpr.service.ExpectBeginPcService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TrdeStdrtServiceImpl implements TrdeStdrtService {

	@Autowired
	TrdeStdrtMapper trdeStdrtMapper;
	
	@Autowired
	private ExpectBeginPcMapper expectBeginPcMapper;

	@Value("${price.trdeStdrt.url}")
	private String trdeStdrtUrl;

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void getCrawlingData() throws Exception {

		log.info("TrdeStdrtService getCrawlingData START");

		String today = "";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();

		today = sdf.format(cal.getTime());

		String preBsnDe = expectBeginPcMapper.selectPreSarokDate(DateUtil.getNowDate());

		cal.add(Calendar.DAY_OF_MONTH, -1);

		String year = preBsnDe.substring(0, 4);
		String month = preBsnDe.substring(4, 6);
		String day = preBsnDe.substring(6, 8);

		log.info("TrdeStdrtService 적용일자 : {} ",today);
		log.info("TrdeStdrtService 기준일자 : {} ",year+""+month+""+day);

		Document doc = null;

		try {
			doc = Jsoup.connect(trdeStdrtUrl)
					.data("StrSch_sYear", year)
					.data("StrSch_sMonth", month)
					.data("StrSch_sDay", day)
					.data("StrSch_eYear", year)
					.data("StrSch_eMonth", month)
					.data("StrSch_eDay", day)
					.data("StrSchFull", year+"."+month+"."+day)
					.data("StrSchFull2", year+"."+month+"."+day)
					.post();

		} catch (IOException e) {
			e.printStackTrace();
		}

		Elements trList = doc.getElementsByClass("td2 brb0");

		if (trList == null || trList.size() == 0) {
			log.info("TrdeStdrtService 크롤링 데이터 없음.");
			return;
		}

		Element tr = trList.get(0);
		String tempStr = tr.data();

		int start = tempStr.indexOf("'", 0);
		int end = tempStr.indexOf("'", start+1);

		String str = tempStr.substring(start+1, end);

		Pattern pattern = Pattern.compile("_C");

        Matcher matcher = pattern.matcher(str);

        str = matcher.replaceAll("");

        str = java.net.URLDecoder.decode(str, "UTF-8");

        log.info("TrdeStdrtService 환율가격 : {} ",str);

        PcSleExpectBeginPcEhgtInfoVO vo = new PcSleExpectBeginPcEhgtInfoVO();
        vo.setApplcDe(today);//적용일자
        vo.setStdrDe(year+""+month+""+day);//기준일자
        vo.setEhgtSeCode("01");//EHGT_SE_CODE(환율구분코드)
        BigDecimal ehgtPc = new BigDecimal(str.replaceAll(",", ""));
        vo.setEhgtPc(ehgtPc);
        vo.setFrstRegisterId("TRDESTDRT_BACTH");
        vo.setLastChangerId("TRDESTDRT_BACTH");

        trdeStdrtMapper.insertPcSleExpectBeginPcEhgtInfo(vo);
        trdeStdrtMapper.insertPcSleExpectBeginPcEhgtInfoHst(vo);

        log.info("TrdeStdrtService getCrawlingData END");

		return;
	}

}