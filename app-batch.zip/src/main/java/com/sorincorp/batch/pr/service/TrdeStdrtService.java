package com.sorincorp.batch.pr.service;

public interface TrdeStdrtService {
	void getCrawlingData() throws Exception;
}
