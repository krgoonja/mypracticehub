package com.sorincorp.batch.pr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.pr.mapper.PriceMapper;
import com.sorincorp.batch.pr.model.LmePriceVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LmePriceServiceImpl implements LmePriceService {
	
	@Autowired
	PriceMapper lmePriceMapper;
	
	@Override
	public void insertLmePriceEnd() throws Exception {
	
		log.debug("::insertItMetalItmStdr START");
	
		try {
			
			lmePriceMapper.insertLmePriceEnd();		
			
		} catch (Exception e) {
			log.error("insertItMetalItmStdr error : " + e);
		}
		
		log.debug("::insertLmePriceEnd END");

		return;
	}
	
}