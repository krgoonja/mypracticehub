package com.sorincorp.batch.pr.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class DcsnBeginPcJobConfig {

	@Autowired
	private DcsnBeginPcTasklet dcsnBeginPcTasklet;

	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job dcsnBeginPcJob() {
		return jobBuilderFactory.get("dcsnBeginPcJob")
				.start(dcsnBeginPcStep())
				.build();
	}

	@Bean
	@JobScope
	public Step dcsnBeginPcStep() {
		return stepBuilderFactory.get("dcsnBeginPcStep")
				.tasklet(dcsnBeginPcTasklet)
				.build();
	}
}
