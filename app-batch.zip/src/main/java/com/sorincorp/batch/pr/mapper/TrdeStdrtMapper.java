package com.sorincorp.batch.pr.mapper;

import com.sorincorp.batch.pr.model.PcSleExpectBeginPcEhgtInfoVO;

public interface TrdeStdrtMapper {

	void insertPcSleExpectBeginPcEhgtInfo(PcSleExpectBeginPcEhgtInfoVO vo);

	void insertPcSleExpectBeginPcEhgtInfoHst(PcSleExpectBeginPcEhgtInfoVO vo);
	
	String selectPreBsnDe();
}
