package com.sorincorp.batch.pr.model;

import lombok.Data;

@Data
public class LmePriceVO {
	/**
	* 발생 일자*/
	private String occrrncDe;
}