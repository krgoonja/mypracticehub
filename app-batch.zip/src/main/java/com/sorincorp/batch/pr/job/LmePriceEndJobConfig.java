package com.sorincorp.batch.pr.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor
public class LmePriceEndJobConfig {

	@Autowired
	private LmePriceEndTasklet lmePriceEndTasklet;
	
	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory;
	
	@Bean
	public Job lmePriceEndJob() {
		return jobBuilderFactory.get("lmePriceEndJob")
				.start(lmePriceEndStep())
				.build();  
	}
	
	@Bean
	@JobScope
	public Step lmePriceEndStep() {
		return stepBuilderFactory.get("claimReturnStep")
				.tasklet(lmePriceEndTasklet)
				.build();
	}
}
