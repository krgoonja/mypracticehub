package com.sorincorp.batch.op.comm;

/**
 * PchrgArticlInfoConstants.java
 * @version
 * @since 2021. 10. 13.
 * @author srec0033
 */
public final class PchrgArticlInfoConstants {

	/**URL*/
	public static final String SNM_NEWS = "http://www.snmnews.com/rss/sorinsnmnews.xml"; 					//철강신문 '01'
	public static final String EMETAL_WORLD = "http://www.emetalworld.co.kr/rss/sorinmetalworld.xml"; 		//메탈월드 '02'
	
	/**RESULT*/
	public static final int SUCCESS_CODE 			= 200;
	public static final int ERROR_CODE 				= 400;
	public static final String SUCCESS_RESULT_CODE	= "200";
	public static final String ERROR_RESULT_CODE 	= "500";
	public static final String SUCCESS_MSG 			= "Success";
	public static final String ERROR_MSG 			= "Error";
	public static final String EHR_REPONSE_RESULT_MSG 	= "result_msg";
	public static final String EHR_REPONSE_RESULT_DATA 	= "result_data";
	public static final String EHR_REPONSE_RESULT_CODE 	= "result_code";
	
	public static final String ARTICL_SJ = "title";
	public static final String ARTICL_LINK = "link";
	public static final String ARTICL_ORGINL = "contents";
	public static final String ARTICL_CN = "description";
	public static final String LAST_BUILD_DATE = "lastBuildDate";
	public static final String ITEM = "item";
	public static final String IMAGE_URL = "default_img";
	public static final String ARTICL_CL_NM = "category";
	public static final String WRITNG_JRNLST_NM = "author";
	public static final String ISU_DT = "pubDate";
	public static final String ARTICL_CL_CODE = "code";
	public static final String ARTICL_SE_CODE = "level";
	public static final String HOSU = "hosu";
	public static final String VIEW_DATE = "viewDate"; 
	
	public static final String ARTICL_NO_START = "?idxno=";
	
	
	
}//end class()
