package com.sorincorp.batch.op.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

/**
 * FeedVO.java
 * @version
 * @since 2021. 10. 6.
 * @author srec0033
 */
@Data
public class ArticlVO {
	
	/**
     * 기사 제목
     */
	private String articlSj;	
	
	/**
     * 기사 링크
     */
	private String articlLink;	
    
	/**
     * 	기사 내용
     */
	private String articlCn;
	
    /**
     * 언어
     */
//    private String language;
    
    /**
     *  저작권정보
     */
//    private String copyright;
    
	/**
     * 발행 일시
     */
	private String lastBuildDate;
    
    /**
     * item 리스트
     */
    private List<ArticlItemVO> items = new ArrayList<ArticlItemVO>();
    
    public List<ArticlItemVO> getItems() {
    	return items;
    }

	public ArticlVO(String articlSj, String articlLink, String articlCn, String lastBuildDate) {
		super();
		this.articlSj = articlSj;
		this.articlLink = articlLink;
		this.articlCn = articlCn;
		this.lastBuildDate = lastBuildDate;
	}

}
