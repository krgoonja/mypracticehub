package com.sorincorp.batch.op.service;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.XMLEvent;

import org.apache.poi.util.ReplacingInputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.op.comm.PchrgArticlInfoConstants;
import com.sorincorp.batch.op.mapper.PchrgArticlInfoMapper;
import com.sorincorp.batch.op.model.ArticlItemVO;
import com.sorincorp.batch.op.model.ArticlVO;

import lombok.extern.slf4j.Slf4j;

/**
 * 유료 기사 정보 Batch ServiceImpl.java
 *
 * @version
 * @since 2021. 10. 13.
 * @author srec0033
 */
@Slf4j
@Service
public class PchrgArticlInfoServiceImpl implements PchrgArticlInfoService {

	@Autowired
	private PchrgArticlInfoMapper pchrgArticlInfoMapper;

	/**
	 * 유료 기사 정보 데이터 수집
	 */
	@Override
	public void savePchrgArticlInfo(String url) throws Exception {

		String chnnlSeCode = "";
		if (url.equals(PchrgArticlInfoConstants.SNM_NEWS)) {
			chnnlSeCode = "01";
		} else if (url.equals(PchrgArticlInfoConstants.EMETAL_WORLD)) {
			chnnlSeCode = "02";
		}

		ArticlVO feed = getListArticleItem(url);
		for (ArticlItemVO item : feed.getItems()) {
			item.setChnnlSeCode(chnnlSeCode);

			// insert
			pchrgArticlInfoMapper.insertOpPchrgArticlInfo(item);
		}

	}

	/**
	 * <pre>
	 * 처리내용: xml 형식 데이터를 vo로 조회한다.
	 * </pre>
	 *
	 * @date 2021. 10. 14.
	 * @author srec0033
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 10. 14.
	 *          srec0033 최초작성 ------------------------------------------------
	 * @return
	 */
	public ArticlVO getListArticleItem(String url) {
		ArticlVO feed = null;

		try {
			boolean isFeedHeader = true;

			String articlSj = "";
			String articlLink = "";
			String articlNo = "";
			String articlOrginl = ""; // contents
			String articlCn = ""; // description
			String lastBuildDate = "";
			String articlSeCode = "";
			String imageUrl = "";
			String articlClNm = ""; // 카테고리
			String articlClCode = "";
			String writngJrnlstNm = "";
			String isuDt = "";
			String hosu = "";
			String ntceDe = "";

			// inputFactory 생성
			XMLInputFactory inputFactory = XMLInputFactory.newInstance();

			// eventReader 설정
			InputStream in = read(url);
			XMLEventReader eventReader = inputFactory.createXMLEventReader(in);

			// XML 데이터 읽기
			while (eventReader.hasNext()) {
				XMLEvent event = eventReader.nextEvent();
				if (event.isStartElement()) {
					String localPart = event.asStartElement().getName().getLocalPart();
					switch (localPart) {
					case PchrgArticlInfoConstants.ITEM:
						if (isFeedHeader) {
							isFeedHeader = false;
							feed = new ArticlVO(articlSj, articlLink, articlCn, lastBuildDate);
						}
						event = eventReader.nextEvent();
						break;
					case PchrgArticlInfoConstants.ARTICL_SJ:
						articlSj = getCharacterData(event, eventReader);
						break;
					case PchrgArticlInfoConstants.ARTICL_LINK:
						articlLink = getCharacterData(event, eventReader);
						articlNo = substringBetween(articlLink, PchrgArticlInfoConstants.ARTICL_NO_START, "");// .get(0);
						break;
					case PchrgArticlInfoConstants.ARTICL_ORGINL:
						articlOrginl = getCharacterData(event, eventReader);
						break;
					case PchrgArticlInfoConstants.ARTICL_CN:
						articlCn = getCharacterData(event, eventReader);
						break;
					case PchrgArticlInfoConstants.LAST_BUILD_DATE:
						lastBuildDate = getCharacterData(event, eventReader);
						break;
					case PchrgArticlInfoConstants.ARTICL_SE_CODE:
						articlSeCode = getCharacterData(event, eventReader);
						break;
					case PchrgArticlInfoConstants.IMAGE_URL:
						imageUrl = getCharacterData(event, eventReader);
						imageUrl = imageUrl.replace("http", "https");
						break;
					case PchrgArticlInfoConstants.ARTICL_CL_NM:
						articlClNm = getCharacterData(event, eventReader);
						break;
					case PchrgArticlInfoConstants.ARTICL_CL_CODE:
						articlClCode = getCharacterData(event, eventReader);
						break;
					case PchrgArticlInfoConstants.WRITNG_JRNLST_NM:
						writngJrnlstNm = getCharacterData(event, eventReader);
						break;
					case PchrgArticlInfoConstants.ISU_DT:
						isuDt = getCharacterData(event, eventReader);
						break;
					case PchrgArticlInfoConstants.HOSU:
						hosu = getCharacterData(event, eventReader);
						break;
					case PchrgArticlInfoConstants.VIEW_DATE:
						ntceDe = getCharacterData(event, eventReader);
						break;
					}// switch END

				} else if (event.isEndElement()) {
					if (event.asEndElement().getName().getLocalPart() == PchrgArticlInfoConstants.ITEM) {
						ArticlItemVO itemVO = new ArticlItemVO();
						itemVO.setArticlSj(articlSj);
						itemVO.setArticlLink(articlLink);
						itemVO.setArticlCn(articlCn);
						itemVO.setArticlOrginl(articlOrginl);
						itemVO.setArticlNo(Integer.parseInt(articlNo));
						itemVO.setArticlSeCode(articlSeCode);
						itemVO.setImageUrl(imageUrl);
						itemVO.setArticlClNm(articlClNm);
						itemVO.setArticlClCode(articlClCode);
						itemVO.setWritngJrnlstNm(writngJrnlstNm);
						itemVO.setIsuDt(isuDt);
						itemVO.setIsuHo(hosu);
						itemVO.setNtceDe(ntceDe);
						feed.getItems().add(itemVO);
						event = eventReader.nextEvent();
						continue;
					} // if END

				}
			} // while END
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		return feed;
	}

	/**
	 * <pre>
	 * 처리내용: 데이터를 읽어온다.
	 * </pre>
	 *
	 * @date 2021. 10. 14.
	 * @author srec0033
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 10. 14.
	 *          srec0033 최초작성 ------------------------------------------------
	 * @param event
	 * @param eventReader
	 * @return
	 * @throws XMLStreamException
	 */
	private String getCharacterData(XMLEvent event, XMLEventReader eventReader) throws XMLStreamException {
		String result = "";
		event = eventReader.nextEvent();
		if (event instanceof Characters) {
			result = event.asCharacters().getData();
		}

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 헤당 url을 연결한다.
	 * </pre>
	 *
	 * @date 2021. 10. 14.
	 * @author srec0033
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 10. 14.
	 *          srec0033 최초작성 ------------------------------------------------
	 * @return
	 */
	private InputStream read(String feedUrl) { // Stream : 데이터가 전송되는 통로, inputStream : 데이터가 들어오는 통로의 역할에 관해 규정하고있는 추상 class
		try {
			URL url = new URL(feedUrl);
			ReplacingInputStream ris = new ReplacingInputStream(url.openStream(), "&quot;", "\""); //	ReplacingInputStream
			return ris;
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 문자열 사이의 문자열을 추출한다.
	 * </pre>
	 *
	 * @date 2021. 10. 13.
	 * @author srec0033
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 10. 13.
	 *          srec0033 최초작성 ------------------------------------------------
	 * @param str
	 * @param open
	 * @param close
	 * @return
	 */
	private String substringBetween(String str, String open, String close) {
		if (str == null || open == null || close == null) {
			return null;
		}

		int start = str.indexOf(open);
		if (start != -1) {

			if (close.equals("")) {
				return str.substring(start + open.length());
			} else {
				int end = str.indexOf(close, start + open.length());
				if (end != -1) {
					return str.substring(start + open.length(), end);
				}
			}
		}

		return null;
	}

}
