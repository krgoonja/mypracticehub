package com.sorincorp.batch.op.mapper;

import com.sorincorp.batch.op.model.ArticlItemVO;

/**
 * PchrgArticlInfoMapper.java
 * @version
 * @since 2021. 10. 20.
 * @author srec0033
 */
public interface PchrgArticlInfoMapper {
	 
	int insertOpPchrgArticlInfo(ArticlItemVO item) throws Exception;
	
	void insertOpPchrgArticlInfoHst(ArticlItemVO item) throws Exception;
	
}
