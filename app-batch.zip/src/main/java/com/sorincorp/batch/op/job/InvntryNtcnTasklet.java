package com.sorincorp.batch.op.job;

import org.springframework.stereotype.Component;

import com.sorincorp.batch.op.service.InvntryNtcnService;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import lombok.extern.slf4j.Slf4j;

/**
 * InvntryNtcnTasklet.java : 재고알림배치 Tasklet
 * @version
 * @since 2021. 12. 13.
 * @author srec0033
 */
@Slf4j
@Component
public class InvntryNtcnTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	private InvntryNtcnService invntryService;
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("InvntryNtcnTasklet :: 재고알림 >> beforeStep");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("InvntryNtcnTasklet :: 재고알림 >> execute");
		
		invntryService.insertInvntryAlarm();
		
		log.debug("InvntryNtcnTasklet :: 재고알림 >> execute end");
		return null;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("InvntryNtcnTasklet :: 재고알림 >> afterStep");
		return ExitStatus.COMPLETED;
	}

}
