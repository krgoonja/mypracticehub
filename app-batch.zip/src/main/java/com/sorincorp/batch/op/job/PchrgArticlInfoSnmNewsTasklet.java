package com.sorincorp.batch.op.job;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.batch.op.comm.PchrgArticlInfoConstants;
import com.sorincorp.batch.op.service.PchrgArticlInfoService;

import lombok.extern.slf4j.Slf4j;

/**
 * 유료 기사 정보 배치 : 철강금속신문 Tasklet
 * @version
 * @since 2021. 10. 14.
 * @author srec0033
 */
@Component
@Slf4j
public class PchrgArticlInfoSnmNewsTasklet implements Tasklet, StepExecutionListener{

	@Autowired
	private PchrgArticlInfoService pchrgArticlInfoService; 
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.debug("PchrgArticlInfoSnmNewsTasklet :: 철강금속 >> beforeStep");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.debug("PchrgArticlInfoSnmNewsTasklet :: 철강금속 >> execute Start");
		
		//철강금속
		pchrgArticlInfoService.savePchrgArticlInfo(PchrgArticlInfoConstants.SNM_NEWS);
		
		log.debug("PchrgArticlInfoSnmNewsTasklet :: 철강금속 >> execute End");
		return RepeatStatus.FINISHED;
	}
	
	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.debug("PchrgArticlInfoSnmNewsTasklet :: 철강금속 >> afterStep");
		return ExitStatus.COMPLETED;
	}

}
