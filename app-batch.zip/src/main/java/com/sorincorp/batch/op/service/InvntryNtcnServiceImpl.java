package com.sorincorp.batch.op.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.op.mapper.InvntryNtcnMapper;
import com.sorincorp.batch.op.model.InvntryNtcnVO;
import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.brandcode.service.BrandCodeService;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingSelectVO;
import com.sorincorp.comm.itemprice.service.ItemPriceMatchingService;
import com.sorincorp.comm.message.model.AppPushQueueVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;

import lombok.extern.slf4j.Slf4j;

/**
 * InvntryNtcnServiceImpl.java : 재고알림배치 서비스임플
 * @version
 * @since 2021. 12. 13.
 * @author srec0033
 */
@Slf4j
@Service
public class InvntryNtcnServiceImpl implements InvntryNtcnService {

	@Autowired
	private SMSService smsService;

	@Autowired
	private BrandCodeService brandCodeService;

	@Autowired
	private ItemPriceMatchingService itemPriceService;

	@Autowired
	private InvntryNtcnMapper invntryMapper;

	@Value("${appPush.domain}")
	private String appPushDomain;

	/**
	 *	재고알림을 발송한다.
	 */
	@Override
	public void insertInvntryAlarm() {

		int cnt = 0;

		try {
			List<InvntryNtcnVO> setupList = invntryMapper.selectInvntryNtcnSetupList();
			while(cnt < setupList.size()) {
				for (InvntryNtcnVO vo : setupList) {
					log.debug(cnt + "번째 시도 : " + vo.getMberNo() + ", " + vo.getEntrpsNo());
					int totQty = 0;							 								//총 재고수 파악
						List<ItemPriceMatchingBlInfoVO> blList = getBlList(vo); 			//최적 BL확인
						if(!blList.isEmpty())  {

							for (ItemPriceMatchingBlInfoVO bl : blList) {
								log.debug("insertInvntryAlarm bl >>> " + bl.toString());

								totQty += bl.getMatchedOrderedBnt().intValue();
							}// blList for END

							log.debug("총 재고수 totQty >>> " + totQty);

							if(totQty >= vo.getInvntryqy()) {								//재고유무 파악 => 재고 있을경우에만 알람

								/**** 	재고알림발송 등록	 ****/
								log.debug("재고알림발송 >>> " + vo);
								int result = invntryMapper.insertInvntryNtcnSndng(vo);
								if(result > 0) {
									/**** 	재고알림 발송 : SMS/PUSH  ****/
									insertSMS(vo);
									//insertAppPush(vo);	//22.02.11 지시사항 - 재고 push 알림 안나가도록 주석처리

									/**** 	재고알림설정 삭제	 ****/
									invntryMapper.deleteInvntryNtcnSetup(vo);
								}
							}
						} else {
							log.debug("재고 알림 배치 : 재고 검색 실패 " + blList);
						}
					cnt++;
				}//for END
			}

		} catch (Exception e) {
			log.debug("insertInvntryAlarm error >> " + e.getMessage());
		}

	}

	/**
	 * <pre>
	 * 처리내용: 최적 bl리스트를 조회한다.
	 * </pre>
	 * @date 2021. 12. 14.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 14.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	private List<ItemPriceMatchingBlInfoVO> getBlList(InvntryNtcnVO vo) throws Exception {
		ItemPriceMatchingSelectVO itemVo = new ItemPriceMatchingSelectVO();
		itemVo.setDistrictLargeCode(vo.getDstrctLclsfCode());
		itemVo.setMetalCode(vo.getMetalCode());
		itemVo.setItemSn(vo.getItmSn());
		itemVo.setBrandGroupCode(vo.getBrandGroupCode());
		itemVo.setBrandCode(vo.getBrandCode());
		itemVo.setOrderWeight(BigDecimal.valueOf(vo.getInvntryqy()));

		//브랜드 무관일 경우
		if(vo.getBrandCode().equals("0000000000")) {
			List<String> brandCodeList = new ArrayList<>();
			List<BrandCodeVO> brandCodeVoList = brandCodeService.getBrandCodeList(vo.getBrandGroupCode());

			for(BrandCodeVO brandCodeVo : brandCodeVoList) {
				brandCodeList.add(brandCodeVo.getSubCode());
			}

			itemVo.setBrandCodeList(brandCodeList);
		}

		log.debug(">> getBlList ItemPriceMatchingSelectVO : " + itemVo.toString());

		int weightUnit = 0;
		int onceSlePossWt = 0;
		if(vo.getMetalCode().equals("7")) { 		//알루미늄
			weightUnit = 25;
			onceSlePossWt = 100;
		} else if(vo.getMetalCode().equals("1")){ 	//아연
			weightUnit = 1;
			onceSlePossWt = 25;
		}
		return itemPriceService.itemBLWithMatchingList(itemVo, weightUnit, onceSlePossWt, 4, weightUnit);
	}

	/**
	 * <pre>
	 * 처리내용: AppPush를 발송한다.
	 * </pre>
	 * @date 2021. 12. 14.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 14.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	private void insertAppPush(InvntryNtcnVO vo) {
		try {
			InvntryNtcnVO data = invntryMapper.selectInvntryNtcnInfo(vo);
			Map<String, String> map = new HashedMap<>();																//발송 데이터
			map.put("templateNum", "29"); 																				//템플릿번호
			map.put("itemName", data.getGoodsNm()); 																	//아이템
			map.put("dlivyDstrct", data.getDstrctLclsfNm()); 															//출고권역
			map.put("brandGroup", data.getBrandGroupNm());																//브랜드그룹
			map.put("brand", (data.getBrandCode().equals("0000000000") ? "브랜드 무관" : data.getBrandCode()));	  			//브랜드
			map.put("orderWt", String.valueOf(data.getInvntryqy()));													//주문중량

			AppPushQueueVO push = new AppPushQueueVO();
			push.setCallback(vo.getMoblphonNo());
			push.setMberNo(vo.getMberNo());
			push.setMsgTitle("[케이지트레이딩] 재고 입고 알림");
			push.setType("0");	//주문 전 process
			push.setUrl(appPushDomain+"/my/alarm/alarmList");	// push 메세지를 눌렀을 때, mapping되는 url

			List<InvntryNtcnVO> deviceList = invntryMapper.selectDeviceList(vo);
			for (InvntryNtcnVO device : deviceList) {
				push.setIdentify(device.getDeviceId());


//				smsService.insertAppPush(push, map);
			}

		} catch (Exception e) {
			log.debug("재고알림배치 insertAppPush error :: " + e.getMessage());
		}

	}

	/**
	 * <pre>
	 * 처리내용: SMS를 발송한다.
	 * </pre>
	 * @date 2021. 12. 14.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 14.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	private void insertSMS(InvntryNtcnVO vo) {
		try {
			SMSVO sms = new SMSVO();
			sms.setPhone(vo.getMoblphonNo());
			sms.setMberNo(vo.getMberNo());

			InvntryNtcnVO data = invntryMapper.selectInvntryNtcnInfo(vo);
			Map<String, String> map = new HashedMap<>();																//발송 데이터
			map.put("templateNum", "29"); 																				//템플릿번호
			map.put("itemName", data.getGoodsNm()); 																	//아이템
			map.put("dlivyDstrct", data.getDstrctLclsfNm()); 															//출고권역
			map.put("brandGroup", data.getBrandGroupNm());																//브랜드그룹
			map.put("brand", (data.getBrandCode().equals("0000000000") ? "브랜드 무관" : data.getBrandCode()));	  			//브랜드
//			map.put("orderWt", String.valueOf(data.getInvntryqy()));													//주문중량		//2022.03.28 서린닷컴 재고 입고 알림 수정 (이현진 사원)
			
			smsService.insertSMS(sms, map);

		} catch (Exception e) {
			log.debug("재고알림배치 insertSMS error :: " + e.getMessage());
		}

	}

}
