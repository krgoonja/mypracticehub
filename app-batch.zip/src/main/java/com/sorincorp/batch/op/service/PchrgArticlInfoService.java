package com.sorincorp.batch.op.service;

/**
 * PchrgArticlInfoService.java
 * @version
 * @since 2021. 10. 13.
 * @author srec0033
 */
public interface PchrgArticlInfoService {
	
	void savePchrgArticlInfo(String url) throws Exception;
}
