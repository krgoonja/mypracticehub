package com.sorincorp.batch.op.mapper;

import java.util.List;

import com.sorincorp.batch.op.model.InvntryNtcnVO;

/**
 * InvntryNtcnMapper.java : 재고알림배치 매퍼
 * @version
 * @since 2021. 12. 13.
 * @author srec0033
 */
public interface InvntryNtcnMapper {
	
	/**
	 * <pre>
	 * 처리내용: 재고 알림 설정 목록을 조회한다.
	 * </pre>
	 * @date 2021. 12. 14.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 14.			srec0033			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<InvntryNtcnVO> selectInvntryNtcnSetupList() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 알림발송을 위한 데이터를 조회한다.
	 * </pre>
	 * @date 2021. 12. 14.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 14.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	InvntryNtcnVO selectInvntryNtcnInfo(InvntryNtcnVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 재고 알림 설정을 삭제한다.
	 * </pre>
	 * @date 2021. 12. 14.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 14.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void deleteInvntryNtcnSetup(InvntryNtcnVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 재고 알림 발송을 등록한다.
	 * </pre>
	 * @date 2021. 12. 14.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 14.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int insertInvntryNtcnSndng(InvntryNtcnVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원의 디바이스 목록을 조회한다.
	 * </pre>
	 * @date 2021. 12. 22.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 22.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<InvntryNtcnVO> selectDeviceList(InvntryNtcnVO vo) throws Exception;

}
