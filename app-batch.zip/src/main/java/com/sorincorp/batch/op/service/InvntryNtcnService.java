package com.sorincorp.batch.op.service;

/**
 * InvntryNtcnService.java : 재고알림서비스
 * @version
 * @since 2021. 12. 13.
 * @author srec0033
 */
public interface InvntryNtcnService {
	
	/**
	 * <pre>
	 * 처리내용: 재고알림을 발송한다.
	 * </pre>
	 * @date 2021. 12. 14.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 14.			srec0033			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	void insertInvntryAlarm() throws Exception;
}
