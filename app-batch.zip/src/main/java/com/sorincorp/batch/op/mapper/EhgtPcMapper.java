package com.sorincorp.batch.op.mapper;

public interface EhgtPcMapper {

	void insertEhgtPcDay();
	
	void insertEhgtPcWeek();
	
	void insertEhgtPcMon();
	
	void insertEhgtPcQuarter();
	
	void insertEhgtPcYear();

}
