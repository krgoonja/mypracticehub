package com.sorincorp.batch.op.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * FeedItemVO.java
 * @version
 * @since 2021. 10. 6.
 * @author srec0033
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class ArticlItemVO {
	
	/**
     * 기사 순번(PK)
     */
	private int articlSn;
	
	/**
     * 채널 구분 코드
     */
	private String chnnlSeCode;
	
	/**
     * 기사 번호	
     */
	private int articlNo;
	
	/**
     * 기사 제목
     */
	private String articlSj;	
	
	/**
     * 기사 링크
     */
	private String articlLink;	
	
	/**
     * 	기사 내용1 (html 제외) - 원문
     */
	private String articlOrginl;
	
	/**
     * 	기사 내용2 (html 포함) - 내용
     */
	private String articlCn;
		
	/**
	 * 기사 구분 코드
	 */
	private String articlSeCode;
	
	/**
     * 이미지 URL
     */
	private String imageUrl;
	
	/**
     * 기사 분류 명
     */
	private String articlClNm;
	
	/**
     * 기사 분류 코드
     */
	private String articlClCode;
	
	/**
     * 작성 기자 명
     */
	private String writngJrnlstNm;
	
	/**
     * 발행 일시
     */
	private String isuDt;
	
	/**
     * 게시 여부
     */
	private String ntceAt;

	/**
     * 발행 호
     */
	private String isuHo;
	
	/**
	 * 게시 일자
	 */
	private String ntceDe;
	
}
