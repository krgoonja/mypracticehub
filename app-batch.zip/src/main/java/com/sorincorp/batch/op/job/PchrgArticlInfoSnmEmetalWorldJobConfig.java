package com.sorincorp.batch.op.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 유료 기사 정보 배치 : 메탈월드 JobConfig
 * @version
 * @since 2021. 10. 14.
 * @author srec0033
 */
@Configuration
@EnableBatchProcessing
public class PchrgArticlInfoSnmEmetalWorldJobConfig {

	@Autowired
	PchrgArticlInfoSnmEmetalWorldTasklet pchrgArticlInfoSnmEmetalWorldTasklet;
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	/**
	 * 메탈월드 
	 */
	@Bean
	public Job pchrgArticlInfoEmetalWorldJob() {
		return jobBuilderFactory.get("pchrgArticlInfoEmetalWorldJob")
				.start(pchrgArticlInfoEmetalWorldStep())
				.build();
	}
	
	@Bean
	@JobScope
	public Step pchrgArticlInfoEmetalWorldStep() {
		return stepBuilderFactory.get("pchrgArticlInfoEmetalWorldStep")
				.tasklet(pchrgArticlInfoSnmEmetalWorldTasklet)
				.build();
	}
}
