package com.sorincorp.batch.op.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

/**
 * InvntryNtcnJobConfig.java : 재고알림배치 JobConfig 
 * @version
 * @since 2021. 12. 13.
 * @author srec0033
 */

@Configuration
@EnableBatchProcessing
@RequiredArgsConstructor	
public class InvntryNtcnJobConfig {
	
	@Autowired
	private InvntryNtcnTasklet invntryNtcnTasklet;

	public final JobBuilderFactory jobBuilderFactory;
	public final StepBuilderFactory stepBuilderFactory;
	
	@Bean
	public Job invntryNtcnJob() {
		return jobBuilderFactory.get("invntryNtcnJob")
				.start(invntryNtcnStep())
				.build();
	}
	
	@Bean
	@JobScope
	public Step invntryNtcnStep() {
		return stepBuilderFactory.get("invntryNtcnStep")
				.tasklet(invntryNtcnTasklet)
				.build();
	}
}
