package com.sorincorp.batch.op.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 유료 기사 정보 : 철강금속신문 배치 JobConfig
 * @version
 * @since 2021. 10. 14.
 * @author srec0033
 */
@Configuration
@EnableBatchProcessing
public class PchrgArticlInfoSnmNewsJobConfig {

	@Autowired
	PchrgArticlInfoSnmNewsTasklet pchrgArticlInfoSnmNewsTasklet;
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	/**
	 * 철강금속 
	 */
	@Bean
	public Job pchrgArticlInfoSnmNewsJob() {
		return jobBuilderFactory.get("pchrgArticlInfoSnmNewsJob")
				.start(pchrgArticlInfoSnmNewsStep())
				.build();
	}
	
	@Bean
	@JobScope
	public Step pchrgArticlInfoSnmNewsStep() {
		return stepBuilderFactory.get("pchrgArticlInfoSnmNewsStep")
				.tasklet(pchrgArticlInfoSnmNewsTasklet)
				.build();
	}
}
