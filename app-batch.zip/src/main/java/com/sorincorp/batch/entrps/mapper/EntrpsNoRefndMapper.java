/**
 *
 */
package com.sorincorp.batch.entrps.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.batch.entrps.model.EntrpsNoRefndVO;

/**
 * EntrpsNoRefndMapper.java
 * @version
 * @since 2022. 03. 24.
 * @author sjham
 */
public interface EntrpsNoRefndMapper {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2022. 03. 24.
	 * @author sjham
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 03. 24.		sjham				최초작성
	 * 2022. 06. 22.		hyunjin05			수정
	 * ------------------------------------------------
	 * @return
	 */
	List<Map<String, String>> selectEntrpsNoRefndList();

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2022. 03. 24.
	 * @author sjham
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 03. 24.		sjham				최초작성
	 * 2022. 06. 22.		hyunjin05			수정
	 * ------------------------------------------------
	 * @return
	 */
	Integer selectNsltSndngDt();
	
	/**
	 * <pre>
	 * 처리내용: 환불계좌 미등록 기업 메일 발송 후 계좌 미등록 메일 발송 여부 = Y, 계좌 미등록 메일 발송 여부 일시 Update
	 * </pre>
	 * @date 2022. 06. 21.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 06. 21.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	void updateEntrpsNoRefnd(EntrpsNoRefndVO vo);
	void insertEntrpsNoRefndHst(EntrpsNoRefndVO vo);
}
