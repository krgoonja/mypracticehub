/**
 *
 */
package com.sorincorp.batch.entrps.service;

import java.util.List;

import com.sorincorp.batch.entrps.model.EntrpsNoRefndVO;

/**
 * EntrpsNoRefndService.java
 * @version
 * @since 2022. 03. 24.
 * @author sjham
 */
public interface EntrpsNoRefndService {

	public void sendEmailEntrpsNoRefnd() throws Exception;
	
}
