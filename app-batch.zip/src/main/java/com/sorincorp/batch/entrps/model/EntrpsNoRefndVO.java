package com.sorincorp.batch.entrps.model;

import lombok.Data;

@Data
public class EntrpsNoRefndVO {
	
	/** 업체번호 **/
	private String entrpsNo;
	
	/** 사업자 등록번호 **/
	private String bsnmRegistNo;

	/** 법인 등록번호 **/
	private String cprRegistNo;

	/** 기업명 **/
	private String entrpsNm;

	/** 대표자 명 **/
	private String rprsntvNm;

	/** 우편번호 **/
	private String postNo;

	/** 도로명 주소 **/
	private String rnAdres;

	/** 도로명 주소 상세 **/
	private String rnDetailAdres;

	/** 전화번호 **/
	private String cmpnyTlphonNo;

	/** 최종 변경자 아이디 **/
	private String lastChangerId;
	
	/** 계좌 미등록 메일 발송 여부 **/
    private String acnutUnregistEmailSndngAt;
    
	/** 계좌 미등록 메일 발송 일시 **/
    private String acnutUnregistEmailSndngDt;
}
