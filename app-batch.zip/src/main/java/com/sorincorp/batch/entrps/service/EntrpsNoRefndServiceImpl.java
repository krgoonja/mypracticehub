/**
 *
 */
package com.sorincorp.batch.entrps.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.batch.entrps.mapper.EntrpsNoRefndMapper;
import com.sorincorp.batch.entrps.model.EntrpsNoRefndVO;
import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.service.MailService;

import lombok.extern.slf4j.Slf4j;

/**
 * EntrpsNoRefndServiceImpl.java
 * 
 * @version
 * @since 2022. 03. 24.
 * @author sjham
 */
@Slf4j
@Service
public class EntrpsNoRefndServiceImpl implements EntrpsNoRefndService {

	@Autowired
	private EntrpsNoRefndMapper entrpsNoRefndMapper;

	/* 하나은행 담당자 이메일 */
//	hana0946@hanafn.com
	@Value("${batch.hana.eml.addr}")
	private String recvEmlAddr;

	/* 하나은행 기업정보 이메일 템플릿 */
	@Value("${batch.hana.eml.tmpl}")
	private String templateNum;

	@Autowired
	private MailService mailService;
	
	/** 이메일 발송 매퍼 */
    @Autowired
    private MailMapper mailMapper;

	@Override
	public void sendEmailEntrpsNoRefnd() throws Exception {

		log.debug("sendEmailEntrpsNoRefnd ===============================");

		// 환불계좌 미등록 기업 리스트
		List<Map<String, String>> entrpsNoRefndList = entrpsNoRefndMapper.selectEntrpsNoRefndList();
		System.out.println("sendEmailEntrpsNoRefnd ===============================" +entrpsNoRefndList);
		EntrpsNoRefndVO vo = new EntrpsNoRefndVO();
		
		if (entrpsNoRefndList.size() > 0) {

			Integer nsltSndngDt = entrpsNoRefndMapper.selectNsltSndngDt(); // 메일 발송 시작 시간 출력
			MailVO mailVO = new MailVO();
			MailVO selectMailTmpt = mailMapper.selectMailTmpt(Integer.parseInt(templateNum));          // 발신자 이메일 가져오기
            
			mailVO.setMailTmptSeq(Integer.parseInt(templateNum));	// 사용할 템플릿 번호 지정
			mailVO.setEmail(recvEmlAddr);							// 수신자 메일 주소
			mailVO.setMailSendUserId("admin");						// 보내는 사람 아이디
			mailVO.setMailSendEmail(selectMailTmpt.getSntoEmail());	// 보내는 사람 이메일
			mailVO.setNsltSndngDt(nsltSndngDt);						// 보내는 시간
			
			List<List<Map<String,String>>> entrpsNoRefndListList = new ArrayList<List<Map<String,String>>>();
			entrpsNoRefndListList.add(entrpsNoRefndList);
			mailService.insertMailRepitSend(mailVO, entrpsNoRefndListList);
			
			// 기업 리스트 테이블 MB_ENTRPS_BAS_INFO 에 발송유무 컬럼 생성 및 Y/N 관리
			// 환불계좌 미등록 기업 메일 발송 후 계좌 미등록 메일 발송 여부 = Y, 계좌 미등록 메일 발송 여부 일시 Update
			log.debug("=================================================================");
			log.debug("환불계좌 미등록 기업 총 건 수 :: {} 건", entrpsNoRefndList.size());
			for(Map<String, String> map : entrpsNoRefndList) {
				log.debug("업체번호 :: {}", map.get("entrpsNo"));
			}

			for(Map<String, String> map : entrpsNoRefndList) {
//				System.out.println("환불계좌 미등록 기업 메일 발송 후 처리 : ");
//				System.out.println(map.get("entrpsNo"));
				
				vo.setEntrpsNo(map.get("entrpsNo"));
				vo.setLastChangerId("MB_ENTRPS_NOREFND_BATCH");
				
				entrpsNoRefndMapper.updateEntrpsNoRefnd(vo);
				entrpsNoRefndMapper.insertEntrpsNoRefndHst(vo);
			}
			log.debug("=================================================================");
			
		} else {
			log.debug("=================================================================");
			log.debug("                       환불계좌 미등록 기업 없음");
			log.debug("=================================================================");
		}
	}
	
}
