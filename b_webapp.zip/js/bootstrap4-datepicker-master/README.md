# bootstrap4-datepicker

A port of the excellent [bootstrap-datepicker](https://github.com/uxsolutions/bootstrap-datepicker) to Bootstrap 4

This currently only alters the CSS to build on Bootstrap 4's SCSS, instead of Bootstrap 3's LESS, which is enough to nicely integrate into a Bootstrap 4-based site.
