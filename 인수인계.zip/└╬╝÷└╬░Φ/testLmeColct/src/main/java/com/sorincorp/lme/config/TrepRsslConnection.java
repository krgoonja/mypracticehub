package com.sorincorp.lme.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.refinitiv.ema.access.EmaFactory;
import com.refinitiv.ema.access.OmmConsumer;
import com.refinitiv.ema.access.OmmConsumerConfig.OperationModel;

/**
 * TrepRsslConnection.java
 * @version
 * @since 2024. 8. 21.
 * @author srec0049
 */
@Component
public class TrepRsslConnection {

	@Value("${refinitiv.trep.rssl.ip}")
	private String trepRsslIp;
	
	@Value("${refinitiv.trep.rssl.port}")
	private int trepRsslPort;
	
	@Value("${refinitiv.trep.rssl.userName}")
	private String trepRsslUserName;
	
	
	public OmmConsumer rsslConsumer() throws Exception {
		OmmConsumer consumer = null;
		
		String trepRsslHost = trepRsslIp + ":" + String.valueOf(trepRsslPort); // refinitiv TREP 서버 HOST
		
		consumer = EmaFactory.createOmmConsumer(EmaFactory.createOmmConsumerConfig()
				.operationModel(OperationModel.USER_DISPATCH)
				.host(trepRsslHost).username("sc_trep_admin_tr"));
		
		return consumer;
	}
}
