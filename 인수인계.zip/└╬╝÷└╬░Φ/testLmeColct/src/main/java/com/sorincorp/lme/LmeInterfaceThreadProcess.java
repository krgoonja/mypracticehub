package com.sorincorp.lme;

import javax.annotation.PreDestroy;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import ch.qos.logback.classic.LoggerContext;

/**
 * LmeInterfaceThreadProcess.java
 * @version
 * @since 2024. 8. 7.
 * @author srec0049
 */
@Component
public class LmeInterfaceThreadProcess {
	public static boolean LMEINTERFACE_ENABLE = false;

	@Autowired
	public LMEStreaming trepService;
	
	@Autowired
	private ThreadPoolTaskExecutor lmeThreadPoolExcuter;
	
	public void start() {
		try {
		if(LMEINTERFACE_ENABLE) {
			System.out.println("####################### This LmeInterfaceThreadProcess App has already started. #####################");
			return;
		}
			trepService.Streaming();
			LMEINTERFACE_ENABLE = true;
		} catch(Exception e) {
			System.out.println("#### error : " + e);
			System.out.println("####################### This LmeInterfaceThreadProcess App End. #####################");
		}
	}
	
	@PreDestroy
	private void interruptedThread() {
		lmeThreadPoolExcuter.shutdown();
		
		System.out.println("####################### Interrupted thread #######################");
		
		LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
		loggerContext.stop();
	}
}
