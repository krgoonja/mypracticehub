package com.sorincorp.lme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestLmeColctApplicationTests {

	@Test
	void contextLoads() {
	}

}
