package com.refinitiv.eta.valueadd.reactor;

class ConnectOptionsInfo {

    int reconnectAttempts;
    boolean hostAndPortProvided;
}
