package kr.co.sorin.LME.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class InvnVo implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String useDiv = "saveInvo"; // 사용 구분 (저장용도인지 아닌지)
	
	private String metalCode; // 메탈 구분
	
	private String HSTCL2_DAT; // Data Date
	
	private String GEN_TEXT16; // Country
	
	private String OPEN_PRC; // Open Stock
	
	private String GEN_VAL1; // Delivery In
	
	private String GEN_VAL2; // Delivery Out
	
	private String PRIMACT_1; // Closing Stock
	
	private String NETCHNG_1; // Net Change

	private String GEN_VAL3; // Warrant On
	
	private String GEN_VAL4; // Warrant Cancel
	
	private String GEN_VAL6; // Net Fresh Cancel
	
	private String GEN_VAL7; // Cancel to Total
}
