package kr.co.sorin.LME.objects;

import com.refinitiv.ema.access.OmmConsumer;
import kr.co.sorin.LME.objects.FlatChain.OnCompleteFunction;
import kr.co.sorin.LME.objects.FlatChain.OnErrorFunction;
import kr.co.sorin.LME.objects.FlatChain.OnElementAddedFunction;
import kr.co.sorin.LME.objects.FlatChain.OnElementChangedFunction;
import kr.co.sorin.LME.objects.FlatChain.OnElementRemovedFunction;

interface ChainRecordContext
{
    OmmConsumer getOmmConsumer();
            
    String getName();
    
    String getServiceName();
    
    boolean getWithUpdates();
    
    SummaryLinksToSkipByDisplayTemplate getSummaryLinksToSkipByDisplayTemplate();
    
    int getNameGuessesCount();

    OnElementAddedFunction getOnElementAddedFunction();
    
    OnElementChangedFunction getOnElementChangedFunction();
    
    OnElementRemovedFunction getOnElementRemovedFunction();
    
    OnCompleteFunction getOnCompleteFunction();
    
    OnErrorFunction getOnErrorFunction();
    
}
