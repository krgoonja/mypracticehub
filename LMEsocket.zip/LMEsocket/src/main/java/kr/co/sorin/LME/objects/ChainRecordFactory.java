package kr.co.sorin.LME.objects;

interface ChainRecordFactory
{

    ChainRecord acquire(String name);

    void releaseAll();
}
