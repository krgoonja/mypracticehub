package kr.co.sorin.LME.model;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SamsungSaveVo implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String useDiv = "settleSamsungSave";
	
	private String monOrDay; // 월물인지 일물인지
	
	private String metalDiv;	// metal 종류

	private String csp_date;	// 기준날짜 	VALUE_DT1

	private String value;;		// Value 		SEC_ACT_1
	
	private String val_date; 	// 만료날짜 	EXPIR_DATE
	
}
