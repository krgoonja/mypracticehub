package kr.co.sorin.LME.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NDFRateVo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String useDiv = "NDF";

	private String BID; //BID
	
	private String ASK; //ASK
	
	private String TIMACT; //TIME ACT.
	
	private String ACTIV_DATE; //ACTIV_DATE.
	
}
