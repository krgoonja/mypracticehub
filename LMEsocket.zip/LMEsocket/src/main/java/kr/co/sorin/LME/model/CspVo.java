package kr.co.sorin.LME.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CspVo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String useDiv;			// 사용 구분 (저장용도인지 아닌지)
	
	private String gridDiv;			//1,2,3,4그리드 구분
	
	private String metalCode;		//metalCode
	
	private String TRADE_DATE;		//CSP Date

	private String OFF_ASK;			//전일자 CSP
	
	private String HST_CLOSE;		//Cash-3M Spread
	
	private String SETTLE;			//Cash전일종가
	
	private String SETTLE3;			//3M전일종가
	
	private String OFFICIAL_3M;	 // 오피셜 3M
}
