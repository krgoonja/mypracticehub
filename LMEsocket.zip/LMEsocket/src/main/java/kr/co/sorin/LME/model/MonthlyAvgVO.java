package kr.co.sorin.LME.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MonthlyAvgVO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String useDiv = "monthlySave";
	private String currOrPriv ;
	
	// 전월 평균가
	String metalName = ""; // 금속구분
	String monthInfo = "";// 년월
	String avgPrice = "";// 종가 평균
	
	// 당월 평균가
	String currMetalName = ""; // 금속구분
	String currMonthInfo = "";// 년월
	String currAvgPrice = "";// 종가 평균
}
