package kr.co.sorin.LME;

import java.time.LocalTime;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.refinitiv.ema.access.EmaFactory;
import com.refinitiv.ema.access.OmmConsumer;
import com.refinitiv.ema.access.OmmConsumerConfig.OperationModel;
import com.refinitiv.ema.access.OmmException;
import com.refinitiv.ema.rdm.EmaRdm;

import kr.co.sorin.LME.model.SamsungSaveVo;
import kr.co.sorin.LME.objects.FlatChain;
import kr.co.sorin.LME.objects.RecursiveChain;

@Component
public class LMEStreaming {

	//실시간 data연동	
	/*
	 * consumer는 세션이기에 하나만 존재해야함. 
	 * appClient 객체는 복수생성이 가능하니 그리드 성격별로 객체생성해서 registerClient 처리할 예정
	 * registerClient는 갯수제한이 없다고 함.
	 */
	
	OmmConsumer consumer = null;
	OmmConsumer conn = null;
	
	@Value("${RicCode.forwardList}") private List<String> ricCodeList;
	@Value("${RicCode.shfeList}") private List<String> shfeList;
	@Value("${RicCode.samsungList}") private List<String> samsungList;
	@Value("${RicCode.samsungMonthList}") private List<String> samsungMonthList;
	@Value("${RicCode.monthlyAvgList}") private List<String> monthlyAvgList;
	@Value("${RicCode.currentMonAvgList}") private List<String> currentMonAvgList;
	@Value("${RicCode.nhMonthList}") private List<String> nhMonthList;
	@Value("${RicCode.invnList}") private List<String> invnList;
	
	
	public void Streaming()
	{
		//OmmConsumer consumer = null;
		try
		{
			//RecieveMessage appClient = new RecieveMessage();
			RecieveLMERT appClient = new RecieveLMERT();
			RecieveForwardPrice appClient2 = new RecieveForwardPrice();
			RecieveFxRate appClient_fxrate = new RecieveFxRate();
			RecieveShfe appClient_shfe = new RecieveShfe();
			RecieveKrw appClient_krw = new RecieveKrw();
			RecieveInvn appClient_invn = new RecieveInvn();
			
			
			consumer  = EmaFactory.createOmmConsumer(EmaFactory.createOmmConsumerConfig()
														.operationModel(OperationModel.USER_DISPATCH)
														.host("172.10.0.189:14002").username("sc_trep_admin_tr"));	
			
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMZN3"), appClient, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMPB3"), appClient, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMAL3"), appClient, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMCU3"), appClient, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMNI3"), appClient, 0);
			
			
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("KRW="), appClient_fxrate, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CNY="), appClient_fxrate, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("JPYKRW=R"), appClient_fxrate, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("EURKRW=R"), appClient_fxrate, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("SGD="), appClient_fxrate, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("SGDUSD=R"), appClient_fxrate, 0);
			//최초가 환율 정보 가져오기
//			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
//					.serviceName("IDN_SELECTFEED").name("KRW1MNDFOR="), appClient_fxrate, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("KRW1MNDFOR="), appClient_krw, 0);
			
			// 재고 정보 불러오기
//			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
//					.serviceName("IDN_SELECTFEED").name("MZN-STXSG-TOT"), appClient_invn, 0);
			
			for(String ricCode : invnList) {				
				consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
						.serviceName("IDN_SELECTFEED").name(ricCode), appClient_invn, 0);				
			}
			
			//Forward Price 처리객체등록
			for(String ricCode : ricCodeList) {
				for(int i=0; i<13; i++) {
					consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
							.serviceName("IDN_SELECTFEED").name(ricCode + Integer.toString(i)), appClient2, 0);
				}
			}
			
			//Shfe처리객체등록
			for(String shfeList : shfeList) {
				for(int i=1; i<13; i++) {
					consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
							.serviceName("IDN_SELECTFEED").name(shfeList + Integer.toString(i)), appClient_shfe, 0);
				}
			}
			
			//Thread.sleep(60000);			// API calls onRefreshMsg(), onUpdateMsg() and onStatusMsg()
			/*
			 * long startTime = System.currentTimeMillis(); while (startTime + 60000 >
			 * System.currentTimeMillis()) consumer.dispatch(10);
			 */
			
			LocalTime now = LocalTime.now();
			while(now.getHour() + 18 > LocalTime.now().getHour()) {
				consumer.dispatch(10);
			}
				
		}		
		//catch (InterruptedException | OmmException excp)
		catch (OmmException excp)
		{
			System.out.println(excp.getMessage());
		}
		finally 
		{
			if (consumer != null) consumer.uninitialize();
		}
	}
	
	public void callCSP(String sessionID) {
		
		try {
			RecieveCSP appClient2 = new RecieveCSP();
			
			appClient2.setSessionID(sessionID);
			appClient2.setSaveYn("N");
			
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMZN0").interestAfterRefresh(false), appClient2);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMPB0").interestAfterRefresh(false), appClient2);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMAL0").interestAfterRefresh(false), appClient2);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMCU0").interestAfterRefresh(false), appClient2);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMNI0").interestAfterRefresh(false), appClient2);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMZN0-3").interestAfterRefresh(false), appClient2);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMPB0-3").interestAfterRefresh(false), appClient2);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMCU0-3").interestAfterRefresh(false), appClient2);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMAL0-3").interestAfterRefresh(false), appClient2);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMNI0-3").interestAfterRefresh(false), appClient2);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMZN3").interestAfterRefresh(false), appClient2);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMPB3").interestAfterRefresh(false), appClient2);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMAL3").interestAfterRefresh(false), appClient2);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMCU3").interestAfterRefresh(false), appClient2);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMNI3").interestAfterRefresh(false), appClient2);
			
			RecieveMessage appClient = new RecieveMessage();
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMZN3").interestAfterRefresh(false), appClient, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMPB3").interestAfterRefresh(false), appClient, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMAL3").interestAfterRefresh(false), appClient, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMCU3").interestAfterRefresh(false), appClient, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CMNI3").interestAfterRefresh(false), appClient, 0);
			
			RecieveFxRate appClient_FxRate = new RecieveFxRate();
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("KRW=").interestAfterRefresh(false), appClient_FxRate, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("CNY=").interestAfterRefresh(false), appClient_FxRate, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("JPYKRW=R").interestAfterRefresh(false), appClient_FxRate, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("EURKRW=R").interestAfterRefresh(false), appClient_FxRate, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("SGD=").interestAfterRefresh(false), appClient_FxRate, 0);
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("SGDUSD=R").interestAfterRefresh(false), appClient_FxRate, 0);
			//최초가 환율 정보 가져오기			
//			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
//					.serviceName("IDN_SELECTFEED").name("KRW1MNDFOR=").interestAfterRefresh(false), appClient_FxRate, 0);
			
			RecieveKrw appClient_krw = new RecieveKrw();
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("KRW1MNDFOR=").interestAfterRefresh(false), appClient_krw, 0);
			
			// 재고 정보 불러오기
			RecieveInvn appClient_invn = new RecieveInvn();
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name("MZN-STXSG-TOT").interestAfterRefresh(false), appClient_invn, 0);
			
			RecieveForwardPrice appClient3 = new RecieveForwardPrice();
			
			//Forward Price 처리객체등록
			for(String ricCode : ricCodeList) {
				for(int i=0; i<13; i++) {
					consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
							.serviceName("IDN_SELECTFEED").name(ricCode + Integer.toString(i)).interestAfterRefresh(false), appClient3, 0);
				}
			}
			
			RecieveShfe appClient_shfe = new RecieveShfe();
//			//Shfe 처리객체등록
			for(String shfeList : shfeList) {
				for(int i=0; i<13; i++) {
					consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
							.serviceName("IDN_SELECTFEED").name(shfeList + Integer.toString(i)).interestAfterRefresh(false), appClient_shfe, 0);
				}
			}
			
			
			
			
		}
		catch (OmmException excp)
		{
			System.out.println(excp.getMessage());
		}
		
	}
	
	public void cspSave(String sessionID) {
		System.out.println("Call cspSave !!");
		RecieveCSP rcvCsp = new RecieveCSP();
		
		if(!sessionID.equals("") && sessionID != null) rcvCsp.setSessionID(sessionID);
		rcvCsp.setSaveYn("Y");
		
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMZN0").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMPB0").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMAL0").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMCU0").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMNI0").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMSN0").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMZN0-3").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMPB0-3").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMCU0-3").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMAL0-3").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMNI0-3").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMSN0-3").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMZN3").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMPB3").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMAL3").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMCU3").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMNI3").interestAfterRefresh(false), rcvCsp);
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("CMSN3").interestAfterRefresh(false), rcvCsp);
	}
	
	public void monthlyAvgSave(String sessionID) {
		System.out.println("Call monthlyAvgSave !!");
		RecieveMonthlyAvg rcvMon = new RecieveMonthlyAvg();
		RecieveMonthlyAvg rcvMon2 = new RecieveMonthlyAvg();
		
		if(!sessionID.equals("") && sessionID != null) rcvMon.setSessionID(sessionID);
		
		for(String monthlyAvgList : monthlyAvgList) {
			rcvMon.setCurrOrPriv("priv");
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name(monthlyAvgList).interestAfterRefresh(false), rcvMon);
		}
		
		for(String currentMonAvgList : currentMonAvgList) {
			rcvMon2.setCurrOrPriv("curr");
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name(currentMonAvgList).interestAfterRefresh(false), rcvMon2);
		}
	}
	
	public void NDFDailySave(String sessionID) {
		System.out.println("Call ndf !!");
		RecieveNDFDaily appClient_krw = new RecieveNDFDaily();	
		consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
				.serviceName("IDN_SELECTFEED").name("KRW1MNDFOR=").interestAfterRefresh(false), appClient_krw);
	}
	
	public void settleSave(String sessionID) {
		System.out.println("Call settleSave !!");
		RecieveSamsung rcvSS = new RecieveSamsung();
		RecieveSamsung2 rcvSS2 = new RecieveSamsung2();
		RecieveNh rcvNh = new RecieveNh();
		if(!sessionID.equals("") && sessionID != null) rcvSS.setSessionID(sessionID);
		if(!sessionID.equals("") && sessionID != null) rcvSS2.setSessionID(sessionID);
		rcvSS.setSaveYn("Y");
		rcvSS2.setSaveYn("Y");
		
		for(String nhMonthList : nhMonthList) {
			for(int i=1; i<=13; i++) {
				consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
						.serviceName("IDN_SELECTFEED").name(nhMonthList+"c"+i).interestAfterRefresh(false), rcvNh);
			}
		}
		
		for(String samsungList : samsungList) {
			rcvSS.setMonOrDay("day");
			FlatChain theChain = new FlatChain.Builder()
								.withOmmConsumer(consumer)
								.withServiceName("IDN_SELECTFEED")
								.withChainName(samsungList)
								.onComplete(
									chain -> { 
													chain.getElements().forEach(
																							(K, V) -> {
																											if(K != 0) {
																												consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
																														.serviceName("IDN_SELECTFEED").name(V).interestAfterRefresh(false), rcvSS);
																											}else {
																												System.out.println("Value is null");
																											}
																										}
																						);
												}
								)
								.build();
			theChain.open();
		}
		
		for(String samsungMonthList : samsungMonthList) {
			rcvSS2.setMonOrDay("mon");
			FlatChain theChain = new FlatChain.Builder()
					.withOmmConsumer(consumer)
					.withServiceName("IDN_SELECTFEED")
					.withChainName(samsungMonthList)
					.onComplete(
							chain -> { 
								chain.getElements().forEach(
										(K, V) -> {
											if(K != 0) {
												consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
														.serviceName("IDN_SELECTFEED").name(V).interestAfterRefresh(false), rcvSS2);
											}else {
												System.out.println("Value is null");
											}
										}
										);
							}
							)
					.build();
			theChain.open();
		}

	}
	
	public void invnSave(String sessionID) {
		System.out.println("Call invnSave !!");
		RecieveInvn invn = new RecieveInvn();
		
		for(String invnList : invnList) {
			consumer.registerClient( EmaFactory.createReqMsg().domainType(EmaRdm.MMT_MARKET_PRICE)
					.serviceName("IDN_SELECTFEED").name(invnList).interestAfterRefresh(false), invn);
		}
	}
	
	public void getSettleChain(SamsungSaveVo vo) {
		System.out.println("Call settleSave2 !!");
		System.out.println(vo);
	}
}
