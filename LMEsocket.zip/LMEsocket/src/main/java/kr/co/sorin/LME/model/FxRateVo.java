package kr.co.sorin.LME.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FxRateVo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String gridDiv;
	
	private String VALUE_DT1 ;
	
	private String VALUE_DT2 ;
	
	private String VALUE_DT3 ;
	
	private String BID;
	
	private String BID_1;
	
	private String BID_2 ;
	
	private String ASK ;
	
	private String ASK_1 ;
	
	private String ASK_2;
	
	private String BID_HIGH_1;
	
	private String BID_LOW_1 ;
	
	private String OPEN_BID ;
	
	private String OPEN_ASK ;
	
	private String CLOSE_BID ;
	
	private String CLOSE_ASK ;
	
}
