package kr.co.sorin.LME.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DataVo implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String RicCode;			//RicCode

	private String TRDPRC_1;		//Live 3M
	
	private String NETCHNG_1;		//Net Change
	
	private String PCTCHNG;			//Pct. Change
	
	private String BID;				//Bid
	
	private String ASK;				//Ask
	
	private String HIGH_1;			//High
	
	private String LOW_1;			//Low
	
	private String OPEN_PRC;		//Open
	
	private String HST_CLOSE;		//Close
	
	private String ACVOL_1;			//Volume
}
