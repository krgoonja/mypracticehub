package kr.co.sorin.LME.model;

public class CspSaveVo {
	// CSP 기준 날짜
	
	// 메탈 종류
	
	// CSP값
	
	// Cash-3M Spread 값
	
	// Cash Closing 값
	
	// 3M Closing 값
}
