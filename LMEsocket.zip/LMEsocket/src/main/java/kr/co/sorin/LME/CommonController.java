package kr.co.sorin.LME;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import kr.co.sorin.LME.model.CspVo;
import kr.co.sorin.LME.model.DataVo;
import kr.co.sorin.LME.model.FxRateVo;
import kr.co.sorin.LME.model.InvnVo;
import kr.co.sorin.LME.model.MonthlyAvgVO;
import kr.co.sorin.LME.model.NhSaveVo;
import kr.co.sorin.LME.model.SamsungSaveVo;
import kr.co.sorin.LME.model.NDFRateVo;

@RestController
public class CommonController {
	
	SocketHandler webSocket = new SocketHandler();
	
	@RequestMapping("/")
    public String hello() {
        return "Hello World!";
    }

    public void sendMessage(String jsonString) {
    	webSocket.sendMessageLME(jsonString);
    }
    
    public void sendm(DataVo vo) throws Exception { 
    	ObjectMapper mapper = new ObjectMapper(); 
    	String jsonString = mapper.writeValueAsString(vo);
    	webSocket.sendMessageLME(jsonString);
    }
    
    public void sendCSP(CspVo vo) throws JsonProcessingException { 
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonString = mapper.writeValueAsString(vo);
    	webSocket.sendMessageLME(jsonString);
    }
    
    public void sendSamsungSettle(SamsungSaveVo vo) throws Exception { 
    	ObjectMapper mapper = new ObjectMapper(); 
    	String jsonString = mapper.writeValueAsString(vo);
    	webSocket.sendMessageLME(jsonString);
    }
    
    public void sendNhSettle(NhSaveVo vo) throws Exception { 
    	ObjectMapper mapper = new ObjectMapper(); 
    	String jsonString = mapper.writeValueAsString(vo);
    	webSocket.sendMessageLME(jsonString);
    }
    
    public void sendMonthlyData(MonthlyAvgVO vo) throws Exception { 
    	ObjectMapper mapper = new ObjectMapper(); 
    	String jsonString = mapper.writeValueAsString(vo);
    	webSocket.sendMessageLME(jsonString);
    }
    
    public void sendFxRate(FxRateVo vo) throws JsonProcessingException { 
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonString = mapper.writeValueAsString(vo);
    	webSocket.sendMessageLME(jsonString);
    }
    
    public void sendNDFData(NDFRateVo vo) throws Exception { 
    	ObjectMapper mapper = new ObjectMapper(); 
    	String jsonString = mapper.writeValueAsString(vo);
    	webSocket.sendMessageLME(jsonString);
    }
    
    public void sendInvn(InvnVo vo) throws JsonProcessingException { 
    	ObjectMapper mapper = new ObjectMapper();
    	String jsonString = mapper.writeValueAsString(vo);
    	webSocket.sendMessageLME(jsonString);
    }
}
