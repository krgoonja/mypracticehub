package com.sorincorp.fo.smsTest.service;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.KkoMsgVO;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.login.model.AccountEntrpsInfoVO;
import com.sorincorp.fo.login.service.EntrpsInfoService;
import com.sorincorp.fo.mb.service.MbCmnCodeService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AlimTestServiceImpl implements AlimTestService {

	@Autowired
    private SMSService smsService;
	
	@Autowired
    private MailService mailService;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Autowired
	private MbCmnCodeService mbCmnCodeService;
	
	@Autowired
	private EntrpsInfoService entrpsInfoService;
	
	/** 이메일 발송 매퍼 */
    @Autowired
    private MailMapper mailMapper;
    
	/**
	 * 알림톡 테스트 전문 전송처리
	 * @return 등록 결과
	 * @exception Exception
	 */
	@Override
	public ResponseEntity<Object> insertAlimTest() {
		Account account = userInfoUtil.getAccountInfo();
		
		try {
			if (account != null) {
				Map<String, String> kkoMap = new HashMap<>();
				String entrpsNo = account.getEntrpsNo();
				AccountEntrpsInfoVO accountEntrpsInfoVO = (AccountEntrpsInfoVO) entrpsInfoService.selectAccountEntrpsInfo(entrpsNo);
				kkoMap.put("templateNum", "999");
				kkoMap.put("companyName", accountEntrpsInfoVO.getEntrpsnmKorean());
				kkoMap.put("mberNm", account.getName());
				kkoMap.put("companyCeoName", accountEntrpsInfoVO.getRprsntvNm());
				kkoMap.put("userId", account.getId());
				kkoMap.put("moblPhonNo", account.getPhonenum());
				kkoMap.put("regDate", account.getMberConfmProcessDt());
				kkoMap.put("urlPc", "https://www.kztraders.com/");
				kkoMap.put("urlMobile", "https://m.kztraders.com/");
				kkoMap.put("urlName", "케이지트레이딩");
				KkoMsgVO kkoVO = new KkoMsgVO();
				kkoVO.setPhone(account.getPhonenum().replaceAll("[^0-9]", ""));
				kkoVO.setMberNo(account.getMberNo());
				smsService.insertKkoMsg(kkoVO, kkoMap);
				
				log.debug("insertAlimTest log end : " + kkoVO.toString());
				
				return new ResponseEntity<>("success", HttpStatus.OK);
			} else {
				return new ResponseEntity<>("로그인되어 있지 않습니다.", HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * 문자 테스트 전송처리
	 * @return 등록 결과
	 * @exception Exception
	 */
	@Override
	public ResponseEntity<Object> insertSmsTest() {
		try {
			String templateNum = "999";
			String title = mbCmnCodeService.selectMssageSj(templateNum);
			Account account = userInfoUtil.getAccountInfo();
			
			if (account != null) {
				String entrpsNo = account.getEntrpsNo();
				AccountEntrpsInfoVO accountEntrpsInfoVO = (AccountEntrpsInfoVO) entrpsInfoService.selectAccountEntrpsInfo(entrpsNo);
				Map<String, String> msgMap = new HashMap<>();
				SMSVO smsVO = new SMSVO();
				
				msgMap.put("templateNum", "999"); // 메시지 템플릿 번호
				msgMap.put("companyName", accountEntrpsInfoVO.getEntrpsnmKorean());
				msgMap.put("mberNm", account.getName());
				msgMap.put("companyCeoName", accountEntrpsInfoVO.getRprsntvNm());
				msgMap.put("userId", account.getId());
				msgMap.put("moblPhonNo", account.getPhonenum());
				msgMap.put("regDate", account.getMberConfmProcessDt());
				msgMap.put("urlPc", "https://www.kztraders.com/");
				msgMap.put("urlMobile", "https://m.kztraders.com/");
				msgMap.put("urlName", "케이지트레이딩");

				smsVO.setPhone(account.getPhonenum()); // 받는사람 번호
				smsVO.setMberNo(account.getMberNo());
				smsVO.setMsgTitle(title);
				
				smsService.insertSMS(smsVO, msgMap);
			
				return new ResponseEntity<>("success", HttpStatus.OK);
			} else {
				return new ResponseEntity<>("로그인되어 있지 않습니다.", HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * 이메일 테스트 전송처리
	 * @return 등록 결과
	 * @exception Exception
	 */
	@Override
	public ResponseEntity<Object> insertEmailTest() {
		try {
			Account account = userInfoUtil.getAccountInfo();
			if (account != null) {
				String entrpsNo = account.getEntrpsNo();
				AccountEntrpsInfoVO accountEntrpsInfoVO = (AccountEntrpsInfoVO) entrpsInfoService.selectAccountEntrpsInfo(entrpsNo);
				int templateNum = 27;
				Date today = new Date();
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy년 MM월 dd일"); // 원하는 데이터 포맷 지정
				String regDate = simpleDateFormat.format(today); // 지정한 포맷으로 변환
				
				Map<String, String> mailMap = new HashMap<>();
				MailVO mailVO = new MailVO();
				MailVO selectMailTmpt = mailMapper.selectMailTmpt(templateNum);          // 발신자 이메일 가져오기
				mailVO.setMailTmptSeq(templateNum); // 사용할 템플릿 번호 지정
				mailVO.setEmail(account.getEmail()); // 수신자 메일 주소
				mailVO.setMemberNo(account.getMberNo());
				mailVO.setMailSendUserId("admin"); // 보내는 사람 아이디
				mailVO.setMailSendEmail(selectMailTmpt.getSntoEmail()); // 보내는 사람 이메일
				// 구매담당자 이메일 전송위해 파라미터 세팅
				mailVO.setEntrpsNo(accountEntrpsInfoVO.getEntrpsNo()); // 업체 번호 (로그인)
	
				mailMap.put("userId", account.getId());
				mailMap.put("entrpsnmKorean", accountEntrpsInfoVO.getEntrpsnmKorean());
				mailMap.put("regDate", regDate);
				mailMap.put("mailSendEmail", selectMailTmpt.getSntoEmail());
				mailService.insertMailSend(mailVO, mailMap);
				
				return new ResponseEntity<>("success", HttpStatus.OK);
			} else {
				return new ResponseEntity<>("로그인되어 있지 않습니다.", HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			log.error("alimTest error log : " + ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>("이메일 전송처리중 에러가 발생하였습니다.", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
