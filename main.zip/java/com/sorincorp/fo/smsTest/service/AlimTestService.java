package com.sorincorp.fo.smsTest.service;

import org.springframework.http.ResponseEntity;

public interface AlimTestService {

	/**
	 * <pre>
	 * 알림톡 테스트 전문 전송처리
	 * </pre>
	 * @date 2022. 6. 14.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 14.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param kkoVO
	 * @param map
	 */
	public ResponseEntity<Object> insertAlimTest();
	
	/**
	 * <pre>
	 * 문자 테스트 전문 전송처리
	 * </pre>
	 * @date 2022. 7. 12.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 12.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param kkoVO
	 * @param map
	 */
	public ResponseEntity<Object> insertSmsTest();
	
	/**
	 * <pre>
	 * 이메일 테스트 전문 전송처리
	 * </pre>
	 * @date 2022. 7. 12.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param kkoVO
	 * @param map
	 */
	public ResponseEntity<Object> insertEmailTest();
}