package com.sorincorp.fo.smsTest.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.fo.smsTest.service.AlimTestService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Controller
@RequestMapping("/smsTest")
public class AlimTestController {
	
	@Autowired
	private AlimTestService alimTestService;
	
	/**
	 * <pre>
	 * 알림톡 테스트 화면 진입
	 * </pre>
	 * @date 2022. 6. 14.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 14.			srec0067			최초작성
	 * ------------------------------------------------
	 */
	@RequestMapping("/alim")
	public String alimTest( HttpServletRequest request, HttpServletResponse response) {
		try {
			return "smsTest/alim";
		} catch (Exception e) {
			log.error("alimTest :::: " + ExceptionUtils.getMessage(e));
			return "error/503";
		}

	}

	/**
	 * <pre>
	 * 알림톡 테스트 전문 전송처리
	 * </pre>
	 * @date 2022. 6. 14.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 14.			srec0067			최초작성
	 * ------------------------------------------------
	 */
	@Transactional
	@RequestMapping("/alimTest")
	@ResponseBody
	public ResponseEntity<Object> alimTest() throws Exception {
		try {
			return alimTestService.insertAlimTest();
		} catch (Exception e) {
			log.error("alimTest error log : " + ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>("fail", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * <pre>
	 * 문자 테스트 전문 전송처리
	 * </pre>
	 * @date 2022. 7. 12.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 12.			srec0067			최초작성
	 * ------------------------------------------------
	 */
	@Transactional
	@RequestMapping("/smsTest")
	@ResponseBody
	public ResponseEntity<Object> smsTest() throws Exception {
		try {
			return alimTestService.insertSmsTest();
		} catch (Exception e) {
			log.error("smsTest error log : " + ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>("fail", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * <pre>
	 * 이메일 테스트 전문 전송처리
	 * </pre>
	 * @date 2022. 7. 12.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0067			최초작성
	 * ------------------------------------------------
	 */
	@Transactional
	@RequestMapping("/emailTest")
	@ResponseBody
	public ResponseEntity<Object> emailTest() throws Exception {
		try {
			return alimTestService.insertEmailTest();
		} catch (Exception e) {
			log.error("emailTest error log : " + ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>("fail", HttpStatus.OK);
		}
	}
}
