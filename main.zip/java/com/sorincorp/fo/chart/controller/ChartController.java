package com.sorincorp.fo.chart.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.bsnInfo.model.RestTermVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.pcInfo.model.PcMntrngSelVO;
import com.sorincorp.comm.pcInfo.model.PrEhgtRltmVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.model.PreminumSelInfoVO;
import com.sorincorp.comm.pcInfo.model.RvcmpnVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.fo.chart.model.EntrpsMetalItmStdrVO;
import com.sorincorp.fo.chart.model.ItHghnetprcPurchsPrmpcDtlVO;
import com.sorincorp.fo.chart.model.MetalInfoListVO;
import com.sorincorp.fo.chart.model.PcMntrngFxVO;
import com.sorincorp.fo.chart.model.PcMntrngLmeVO;
import com.sorincorp.fo.chart.model.PrLmePblntfPcBasVO;
import com.sorincorp.fo.chart.model.SelPcChartVO;
import com.sorincorp.fo.chart.service.PcMntrngFxService;
import com.sorincorp.fo.chart.service.PcMntrngLmeService;
import com.sorincorp.fo.chart.service.PcMntrngService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;

import lombok.extern.slf4j.Slf4j;

/**
 * chartController.java
 * @version
 * @since 2021. 9. 7.
 * @author srec0008
 */
@Slf4j
@Controller
@RequestMapping("/chart")
public class ChartController {
	
	@Autowired
	PcMntrngService pcMntrngService;
	
	@Autowired
	CommonCodeService commonCodeService;
	
	@Autowired
	PcInfoService pcInfoService;
	
	@Autowired
	UserInfoUtil userInfoUtil;
	
	@Autowired
	BsnInfoService bsnInfoService;
	
	/**
	 * LME 차트 관련 Service
	 */
	@Autowired
	PcMntrngLmeService pcMntrngLmeService;
	
	/**
	 * 환율 차트 관련 Service
	 */
	@Autowired
	PcMntrngFxService pcMntrngFxService;
	
	
	/**
	 * <pre>
	 * 처리내용: 금속 코드를 가져온다
	 * </pre>
	 * @date 2022. 1. 12.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 12.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value="/getMetalCode")
	@ResponseBody
	public Map<String, Object> getMetalCode() throws Exception{
		Map<String, Object> returnMap = new HashMap<String, Object>();
		returnMap.put("metalCode", commonCodeService.getFilterCodeRetVo("METAL_CODE",null,"CODE_DCTWO","Y"));
		return returnMap;
	}
	
	/**
	 * <pre>
	 * 처리내용: 시간 간격별 차트 데이터 리스트를 가져온다.
	 * </pre>
	 * @date 2022. 1. 12.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 12.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value="/pcMngtrngSelList")
	@ResponseBody
	public Map<String, Object> pcMngtrngSelList(@RequestBody PcMntrngSelVO pcMntrngSelVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		List<PcMntrngSelVO> resultList = new ArrayList<PcMntrngSelVO>();
		
		switch (pcMntrngSelVO.getType()) {
			case "1minute":
				pcMntrngSelVO.setOccrrncDe(DateUtil.getNowDate());
				pcMntrngSelVO.setOccrrncTime(DateUtil.getFormatDate(DateUtil.getCalendar(), "hhmm") + "00");
				resultList = pcInfoService.getPcMngtrngSel1MinList(pcMntrngSelVO);
				break;
				
			case "30minute":
				pcMntrngSelVO.setOccrrncDe(DateUtil.getNowDate());
				int mm = Integer.parseInt(DateUtil.getFormatDate(DateUtil.getCalendar(), "mm"));
				pcMntrngSelVO.setOccrrncTime(DateUtil.getFormatDate(DateUtil.getCalendar(), "hh") + (mm>= 30 ? "30": "00") + "00");
				resultList = pcInfoService.getPcMngtrngSel30MinList(pcMntrngSelVO);
				break;
				
			case "60minute":
				pcMntrngSelVO.setOccrrncDe(DateUtil.getNowDate());
				pcMntrngSelVO.setOccrrncTime(DateUtil.getFormatDate(DateUtil.getCalendar(), "hh") + "0000");
				resultList = pcInfoService.getPcMngtrngSel60MinList(pcMntrngSelVO);
				break;
				
			case "day":
				pcMntrngSelVO.setOccrrncDe(DateUtil.getNowDate());
				resultList = pcInfoService.getPcMngtrngSelDeList(pcMntrngSelVO);
				break;
				
			case "month":
				pcMntrngSelVO.setOccrrncDe(DateUtil.getNowDate());
				resultList = pcInfoService.getPcMngtrngSelMonthList(pcMntrngSelVO);
				break;
	
			default:
				break;
		}
		
		returnMap.put("restInfoJson", pcMntrngService.getRestdeInfoJson());
		returnMap.put("result", resultList);
		
		return returnMap; 
	}
	
	/**
	 * <pre>
	 * 처리내용: 일별 차트 데이터를 가져온다
	 * </pre>
	 * @date 2022. 1. 12.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 12.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value="/pcMngtrngSelDeList")
	@ResponseBody
	public Map<String, Object> pcMngtrngSelDeList(@RequestBody PcMntrngSelVO pcMntrngSelVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		List<PcMntrngSelVO> resultList = pcInfoService.getPcMngtrngSelDeList(pcMntrngSelVO);
		
		returnMap.put("result", resultList);
		
		return returnMap;
	}
	
	/**
	 * <pre>
	 * 처리내용: 기간별 고정가 차트 데이터를 가져온다
	 * </pre>
	 * @date 2022. 1. 12.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 12.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itHghnetprcPurchsPrmpcDtlVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value="/getItHghnetprcPurchsPrmpcDtl")
	@ResponseBody
	public Map<String, Object> getItHghnetprcPurchsPrmpcDtl(@RequestBody ItHghnetprcPurchsPrmpcDtlVO itHghnetprcPurchsPrmpcDtlVO) throws Exception { 
		Map<String, Object> returnMap = new HashMap<String, Object>();
		List<ItHghnetprcPurchsPrmpcDtlVO> resultList = new ArrayList<ItHghnetprcPurchsPrmpcDtlVO>();
		switch (itHghnetprcPurchsPrmpcDtlVO.getType()) {
			case "month":
				itHghnetprcPurchsPrmpcDtlVO.setApplcYm(DateUtil.getFormatDate(DateUtil.getCalendar(), "yyyymmdd"));
				 resultList = pcMntrngService.getItHghnetprcPurchsPrmpcDtlMonth(itHghnetprcPurchsPrmpcDtlVO);
				break;
			case "quarter":
				itHghnetprcPurchsPrmpcDtlVO.setApplcYm(DateUtil.getFormatDate(DateUtil.getCalendar(), "yyyymmdd"));
				 resultList = pcMntrngService.getItHghnetprcPurchsPrmpcDtlQuarter(itHghnetprcPurchsPrmpcDtlVO);
				break;
			case "halfYear":
				itHghnetprcPurchsPrmpcDtlVO.setApplcYm(DateUtil.getFormatDate(DateUtil.getCalendar(), "yyyymmdd"));
				resultList = pcMntrngService.getItHghnetprcPurchsPrmpcDtlHalfYear(itHghnetprcPurchsPrmpcDtlVO);
				break;
			case "year":
				itHghnetprcPurchsPrmpcDtlVO.setApplcYm(DateUtil.getFormatDate(DateUtil.getCalendar(), "yyyymmdd"));
				 resultList = pcMntrngService.getItHghnetprcPurchsPrmpcDtlYear(itHghnetprcPurchsPrmpcDtlVO);
				break;
			default:
				break;
		}
		
		returnMap.put("result", resultList);
		
		return returnMap;
	}
	
	/**
	 * <pre>
	 * 처리내용: 조달청리스트조회
	 * </pre>
	 * @date 2023. 9. 8.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 8.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/getLiveList")
	ResponseEntity<Object> getLiveList(@RequestBody MetalInfoListVO metalInfoListVO) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		
		try {
			Account account = userInfoUtil.getAccountInfo();
			List<MetalInfoListVO> liveList = new ArrayList<MetalInfoListVO>();
			
			if ( account == null) { 
				liveList = pcMntrngService.getLiveList(metalInfoListVO.getMetalCode(), metalInfoListVO.getSleMthdCode(),"main", null);
			}else {
				liveList = pcMntrngService.getLiveList(metalInfoListVO.getMetalCode(), metalInfoListVO.getSleMthdCode(),"login",account.getEntrpsNo());
			}
			
			rtnMap.put("liveList", liveList);
		} catch (Exception e) {
			log.error("[ChartController][main]" + ExceptionUtils.getStackTrace(e));
		}
		
		return new ResponseEntity<>(rtnMap, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 최신 환율 시세를 조회한다.
	 * </pre>
	 * @date 2023. 9. 8.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 8.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/getEhgtRltm")
	ResponseEntity<Object> getEhgtRltm() {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		try {
			//환율 조회
			PrEhgtRltmVO prEhgtRltmVO = pcInfoService.getNewestPrEhgtRltm("SPTUSD/KRW");
			if (prEhgtRltmVO != null) {
				rtnMap.put("ehgtRltm", prEhgtRltmVO.getEndPc());
			} else {
				rtnMap.put("ehgtRltm", 0);
			} 
		} catch (Exception e) {
			log.error("[ChartController][getEhgtRltm]" + ExceptionUtils.getStackTrace(e));
		}
		
		return new ResponseEntity<>(rtnMap, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 운영정보조회
	 * </pre>
	 * @date 2023. 9. 8.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 8.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/getRestdeInfoList")
	ResponseEntity<Object> getRestdeInfoList(@RequestBody String mainGbn) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		
		try {
			List<RestTermVO> restTermListVO =  bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");
			
			if(!"main".equals(mainGbn)) {
				restTermListVO.addAll(bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "02"));
			}
			
			rtnMap.put("restdeInfoList", restTermListVO);
		} catch (Exception e) {
			log.error("[ChartController][getRestdeInfoList]" + ExceptionUtils.getStackTrace(e));
		}
		
		return new ResponseEntity<>(rtnMap, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 조달청리스트조회
	 * </pre>
	 * @date 2023. 9. 8.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 8.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/getRvcmpnList")
	ResponseEntity<Object> getRvcmpnList(@RequestBody String metalCode) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		
		try {
			List<RvcmpnVO> rvcmpnVOList = pcInfoService.getRvcmpn(DateUtil.getNowDate(), metalCode);
			Map<String, CommonCodeVO> brandCode = commonCodeService.getSubCodesRetVo("BRAND_GROUP_CODE");
			
			for(RvcmpnVO rvcmpnVO : rvcmpnVOList) {
				rvcmpnVO.setBrandGroupName(brandCode.get(rvcmpnVO.getBrandGroupCode()).getCodeDcone());
			}
			
			rtnMap.put("rvcmpnVOList", rvcmpnVOList);
		} catch (Exception e) {
			log.error("[ChartController][rvcmpnList]" + ExceptionUtils.getStackTrace(e));
		}
		
		return new ResponseEntity<>(rtnMap, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: LME 대비가격 리스트
	 * </pre>
	 * @date 2023. 9. 8.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 8.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/getPrLmePblntfPc")
	ResponseEntity<Object> getPrLmePblntfPc(@RequestBody PrLmePblntfPcBasVO prLmePblntfPcBasVO) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		
		try {
			PrLmePblntfPcBasVO lmePriceVO = pcMntrngService.getPrLmePblntfPc(prLmePblntfPcBasVO);
			
			rtnMap.put("prLmePblntfPcBasVO", lmePriceVO);
		} catch (Exception e) {
			log.error("[ChartController][getPrLmePblntfPc]" + ExceptionUtils.getStackTrace(e));
		}
		
		return new ResponseEntity<>(rtnMap, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 기준 매매가 조회
	 * </pre>
	 * @date 2023. 9. 8.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 8.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/getAvgDeEndPrice")
	ResponseEntity<Object> getAvgDeEndPrice(@RequestBody(required = false)PrSelVO prSelVO) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		
		try {
			PrSelVO avgCspVo = pcInfoService.getAvgDeEndPrice(prSelVO.getMetalCode(), prSelVO.getItmSn(), prSelVO.getDstrctLclsfCode(), prSelVO.getBrandGroupCode(), prSelVO.getBrandCode());
			
			if(avgCspVo != null) {
				rtnMap.put("avgSelPc", avgCspVo.getAvgSelPc());
				rtnMap.put("accmltLmeCsp", avgCspVo.getAccmltLmeCsp());
				rtnMap.put("accmltUsdCvtrate", avgCspVo.getAccmltUsdCvtrate());
			}else{
				rtnMap.put("avgSelPc", "0");
				rtnMap.put("accmltLmeCsp", "0");
				rtnMap.put("accmltUsdCvtrate", "0");
			}
		} catch (Exception e) {
			log.error("[ChartController][getAvgDeEndPrice]" + ExceptionUtils.getStackTrace(e));
		}
		
		return new ResponseEntity<>(rtnMap, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 기준 매매가 조회
	 * </pre>
	 * @date 2023. 9. 8.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 8.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/getSelPcChartList")
	ResponseEntity<Object> getSelPcChartList(@RequestBody(required = false)SelPcChartVO selPcChartParamVO) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		
		try {
			SelPcChartVO selPcChartVO = pcMntrngService.getSelPcChartList(selPcChartParamVO);
			rtnMap.put("selPcChartList", selPcChartVO);
		} catch (Exception e) {
			log.error("[ChartController][getPreminumSelList]" + ExceptionUtils.getStackTrace(e));
		}
		
		return new ResponseEntity<>(rtnMap, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 메탈별 권역/브랜드그룹을 조회한다.
	 * </pre>
	 * @date 2023. 9. 26.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 26.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/getSelMetalList")
	ResponseEntity<Object> getSelMetalList() {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		
		try {
			Account account = userInfoUtil.getAccountInfo();
			List<PreminumSelInfoVO> preminumSelInfoListVO = null;
			EntrpsMetalItmStdrVO entrpsMetalItmStdrVO = null;
			if ( account != null) {
				preminumSelInfoListVO = pcMntrngService.getSelMetalList(account.getEntrpsNo());
				entrpsMetalItmStdrVO = pcMntrngService.getEntrpsMetalItmStdr(account.getEntrpsNo());
				
				rtnMap.put("entrpsMetalItmStdrVO", entrpsMetalItmStdrVO);
			} else {
				preminumSelInfoListVO = pcMntrngService.getSelMetalList(null);
			}
			
			rtnMap.put("preminumSelInfoList", preminumSelInfoListVO);
		} catch (Exception e) {
			log.error("[ChartController][getSelMetalList]" + ExceptionUtils.getStackTrace(e));
		}
		
		return new ResponseEntity<>(rtnMap, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 로그인한 업체 기준아이템 설정를 저장한다.
	 * </pre>
	 * @date 2023. 10. 10.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 10.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/insertEntrpsMetalItmStdr")
	public ResponseEntity<Object> insertEntrpsMetalItmStdr(@RequestBody(required = false) EntrpsMetalItmStdrVO entrpsMetalItmStdrVO) {
		Map<String, Object> map = new HashMap<String, Object>();
		
		try {
			entrpsMetalItmStdrVO.setEntrpsNo(userInfoUtil.getEntripsNo());
			entrpsMetalItmStdrVO.setMberId(userInfoUtil.getAccountInfo().getId());
			
			int result = pcMntrngService.insertEntrpsMetalItmStdr(entrpsMetalItmStdrVO);
			
			if(result == 1) {
				map.put("result", "success");
				pcMntrngService.insertEntrpsMetalItmStdrHst(entrpsMetalItmStdrVO);
			}
			
		} catch (Exception e) {
			log.error("[ChartController][insertEntrpsMetalItmStdr]" + ExceptionUtils.getStackTrace(e));
		}
		
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	
	/**
	 * <pre>
	 * 처리내용: LME 초기 가격 정보 데이터 가져오기 (실시간 LME 가격 정보 가져오기 전)
	 * </pre>
	 * @date 2024. 9. 12.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 12.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param pcMntrngLmeVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value="/pcMngtrngLmeInitInfo")
	@ResponseBody
	public Map<String, Object> pcMngtrngLmeInitInfo(@RequestBody PcMntrngLmeVO pcMntrngLmeVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		PcMntrngLmeVO pcMngtrngLmeInitInfo = pcMntrngLmeService.pcMngtrngLmeInitInfo(pcMntrngLmeVO);
		
		returnMap.put("result", pcMngtrngLmeInitInfo);
		
		return returnMap;
	}
	
	/**
	 * <pre>
	 * 처리내용: 시간별 LME 차트 데이터 가져오기
	 * </pre>
	 * @date 2024. 9. 9.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 9.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param pcMntrngLmeVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value="/pcMngtrngLmeList")
	@ResponseBody
	public Map<String, Object> pcMngtrngLmeList(@RequestBody PcMntrngLmeVO pcMntrngLmeVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		List<PcMntrngLmeVO> resultList = new ArrayList<PcMntrngLmeVO>();
		
		switch (pcMntrngLmeVO.getType()) {
			case "1minute":
				// 1분 기준 LME 차트 데이터를 가져온다.
				resultList = pcMntrngLmeService.getPcMngtrngLme01MinList(pcMntrngLmeVO);
				break;	
			case "30minute":
				// 30분 기준 LME 차트 데이터를 가져온다.
				resultList = pcMntrngLmeService.getPcMngtrngLme30MinList(pcMntrngLmeVO);
				break;
			case "60minute":
				// 60분 기준 LME 차트 데이터를 가져온다.
				resultList = pcMntrngLmeService.getPcMngtrngLme60MinList(pcMntrngLmeVO);
				break;
			case "day":
				// 일 기준 LME 차트 데이터를 가져온다.
				resultList = pcMntrngLmeService.getPcMngtrngLmeDeList(pcMntrngLmeVO);
				break;
			case "month":
				// 월 기준 LME 차트 데이터를 가져온다.
				resultList = pcMntrngLmeService.getPcMngtrngLmeMonthList(pcMntrngLmeVO);
				break;
			default:
				break;
		}
		
		returnMap.put("result", resultList);
		
		return returnMap;
	}
	
	/**
	 * <pre>
	 * 처리내용: 환율 초기 가격 정보 데이터 가져오기 (실시간 환율 가격 정보 가져오기 전)
	 * </pre>
	 * @date 2024. 9. 12.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 12.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param pcMntrngFxVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value="/pcMngtrngFxInitInfo")
	@ResponseBody
	public Map<String, Object> pcMngtrngFxInitInfo(@RequestBody PcMntrngFxVO pcMntrngFxVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		// 환율 초기 가격 정보 데이터 가져오기 (실시간 환율 가격 정보 가져오기 전)
		PcMntrngFxVO pcMngtrngFxInitInfo = pcMntrngFxService.pcMngtrngFxInitInfo(pcMntrngFxVO);
		
		returnMap.put("result", pcMngtrngFxInitInfo);
		
		return returnMap;
	}
	
	/**
	 * <pre>
	 * 처리내용: 시간별 환율 차트 데이터 가져오기
	 * </pre>
	 * @date 2024. 9. 9.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 9.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param pcMntrngFxVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value="/pcMngtrngFxList")
	@ResponseBody
	public Map<String, Object> pcMngtrngFxList(@RequestBody PcMntrngFxVO pcMntrngFxVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		
		List<PcMntrngFxVO> resultList = new ArrayList<PcMntrngFxVO>();
		
		switch (pcMntrngFxVO.getType()) {
			case "1minute":
				// 1분 기준 환율 차트 데이터를 가져온다.
				resultList = pcMntrngFxService.getPcMngtrngFx01MinList(pcMntrngFxVO);
				break;	
			case "30minute":
				// 30분 기준 환율 차트 데이터를 가져온다.
				resultList = pcMntrngFxService.getPcMngtrngFx30MinList(pcMntrngFxVO);
				break;
			case "60minute":
				// 60분 기준 환율 차트 데이터를 가져온다.
				resultList = pcMntrngFxService.getPcMngtrngFx60MinList(pcMntrngFxVO);
				break;
			case "day":
				// 일 기준 환율 차트 데이터를 가져온다.
				resultList = pcMntrngFxService.getPcMngtrngFxDeList(pcMntrngFxVO);
				break;
			case "month":
				// 월 기준 환율 차트 데이터를 가져온다.
				resultList = pcMntrngFxService.getPcMngtrngFxMonthList(pcMntrngFxVO);
				break;
			default:
				break;
		}
		
		returnMap.put("result", resultList);
		
		return returnMap;
	}
}
