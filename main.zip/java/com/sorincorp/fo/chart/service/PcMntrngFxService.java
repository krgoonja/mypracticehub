package com.sorincorp.fo.chart.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.sorincorp.fo.chart.model.PcMntrngFxVO;

/**
 * PcMntrngFxService.java
 * 환율 차트 관련 Service 인터페이스
 * 
 * @version
 * @since 2024. 9. 9.
 * @author srec0049
 */
public interface PcMntrngFxService {

	/**
	 * <pre>
	 * 처리내용: 환율 초기 가격 정보 데이터 가져오기 (실시간 환율 가격 정보 가져오기 전)
	 * </pre>
	 * @date 2024. 9. 12.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 12.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param pcMntrngFxVO
	 * @return
	 * @throws Exception
	 */
	public PcMntrngFxVO pcMngtrngFxInitInfo(@RequestBody PcMntrngFxVO pcMntrngFxVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 1분 기준 환율 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2024. 9. 9.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 9.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param pcMntrngFxVO
	 * @return
	 * @throws Exception
	 */
	List<PcMntrngFxVO> getPcMngtrngFx01MinList(PcMntrngFxVO pcMntrngFxVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 30분 기준 환율 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2024. 9. 9.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 9.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param pcMntrngFxVO
	 * @return
	 * @throws Exception
	 */
	List<PcMntrngFxVO> getPcMngtrngFx30MinList(PcMntrngFxVO pcMntrngFxVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 60분 기준 환율 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2024. 9. 9.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 9.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param pcMntrngFxVO
	 * @return
	 * @throws Exception
	 */
	List<PcMntrngFxVO> getPcMngtrngFx60MinList(PcMntrngFxVO pcMntrngFxVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 일 기준 환율 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2024. 9. 9.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 9.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param pcMntrngFxVO
	 * @return
	 * @throws Exception
	 */
	List<PcMntrngFxVO> getPcMngtrngFxDeList(PcMntrngFxVO pcMntrngFxVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 월 기준 환율 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2024. 9. 9.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 9.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param pcMntrngFxVO
	 * @return
	 * @throws Exception
	 */
	List<PcMntrngFxVO> getPcMngtrngFxMonthList(PcMntrngFxVO pcMntrngFxVO) throws Exception;
}
