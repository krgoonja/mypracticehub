package com.sorincorp.fo.chart.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.fo.chart.mapper.PcMntrngFxMapper;
import com.sorincorp.fo.chart.model.PcMntrngFxVO;

import lombok.extern.slf4j.Slf4j;

/**
 * PcMntrngFxServiceImpl.java
 * 환율 차트 관련 Service 구현체 클래스
 * 
 * @version
 * @since 2024. 9. 9.
 * @author srec0049
 */
@Slf4j
@Service
public class PcMntrngFxServiceImpl implements PcMntrngFxService {

	@Autowired
	private RedisUtil redisUtil;
	
	/**
     * 사이트 운영 설정 서비스
     */
    @Autowired
    private BsnInfoService bsnInfoService;
	
	/**
	 * 환율 차트 관련 Mapper
	 */
	@Autowired
    private PcMntrngFxMapper pcMntrngFxMapper;
	
	private String LAST_DATA_FXPC = "lastDataFxpc";	// 레디스로 발행한 마지막 실시간 환율 정보 이름(레디스에 저장된 이름)
	
	
	/**
	 * 환율 초기 가격 정보 데이터 가져오기 (실시간 환율 가격 정보 가져오기 전)
	 */
	@Override
	public PcMntrngFxVO pcMngtrngFxInitInfo(PcMntrngFxVO pcMntrngFxVO) throws Exception {
		// 환율 초기 가격 정보 데이터 가져오기 (실시간 환율 가격 정보 가져오기 전)
		
		PcMntrngFxVO pcMntrngFxByDB = pcMntrngFxMapper.pcMngtrngFxInitInfo(pcMntrngFxVO);
		
		log.info(">> pcMngtrngFxInitInfo pcMntrngFxVO.getMetalCode() : " + pcMntrngFxVO.getMetalCode());
		boolean restdeYn = bsnInfoService.isRestDeByMetal(pcMntrngFxVO.getMetalCode(),  "01");
		
		// 운영시간일 경우 DB와 레디스를 비교하여 가장 최근 시간대로 가져온다. 운영시간이 아닐경우 DB에 운영시간 마지막 시간대로 조회한 값을 가져온다.
		if(restdeYn) {
			if(pcMntrngFxByDB != null) {
				ObjectMapper objectMapper = new ObjectMapper();
				Map<String, Object> pcMntrngFxJsonMapByRedis = objectMapper.readValue(String.valueOf(redisUtil.getDataJson(LAST_DATA_FXPC)), new TypeReference<Map<String, Object>>() {});
				
				String ehgtPcRltmSn = String.valueOf(pcMntrngFxJsonMapByRedis.get("ehgtPcRltmSn"));
			
				BigInteger redisEhgtPcRltmSn = new BigInteger(ehgtPcRltmSn);
				BigInteger dbEhgtPcRltmSn = new BigInteger(pcMntrngFxByDB.getEhgtPcRltmSn());
				
				if(redisEhgtPcRltmSn.compareTo(dbEhgtPcRltmSn) > 0) {
					PcMntrngFxVO changeVO = new PcMntrngFxVO();
					changeVO.setEhgtPcRltmSn(ehgtPcRltmSn);
					changeVO.setEndPc(new BigDecimal(String.valueOf(pcMntrngFxJsonMapByRedis.get("endPc"))));
					changeVO.setVersusPc(new BigDecimal(String.valueOf(pcMntrngFxJsonMapByRedis.get("versusPc"))));
					changeVO.setVersusRate(new BigDecimal(String.valueOf(pcMntrngFxJsonMapByRedis.get("versusRate"))));
					
					return changeVO;
				}
			}
		}
		
		return pcMntrngFxByDB;
	}
	
	/**
	 * 1분 기준 환율 차트 데이터를 가져온다.
	 */
	@Override
	public List<PcMntrngFxVO> getPcMngtrngFx01MinList(PcMntrngFxVO pcMntrngFxVO) throws Exception {
		// 1분 기준 환율 차트 데이터를 가져온다.
		return pcMntrngFxMapper.getPcMngtrngFx01MinList(pcMntrngFxVO);
	}

	/**
	 * 30분 기준 환율 차트 데이터를 가져온다.
	 */
	@Override
	public List<PcMntrngFxVO> getPcMngtrngFx30MinList(PcMntrngFxVO pcMntrngFxVO) throws Exception {
		// 30분 기준 환율 차트 데이터를 가져온다.
		return pcMntrngFxMapper.getPcMngtrngFx30MinList(pcMntrngFxVO);
	}

	/**
	 * 60분 기준 환율 차트 데이터를 가져온다.
	 */
	@Override
	public List<PcMntrngFxVO> getPcMngtrngFx60MinList(PcMntrngFxVO pcMntrngFxVO) throws Exception {
		// 60분 기준 환율 차트 데이터를 가져온다.
		return pcMntrngFxMapper.getPcMngtrngFx60MinList(pcMntrngFxVO);
	}

	/**
	 * 일 기준 환율 차트 데이터를 가져온다.
	 */
	@Override
	public List<PcMntrngFxVO> getPcMngtrngFxDeList(PcMntrngFxVO pcMntrngFxVO) throws Exception {
		// 일 기준 환율 차트 데이터를 가져온다.
		return pcMntrngFxMapper.getPcMngtrngFxDeList(pcMntrngFxVO);
	}

	/**
	 * 월 기준 환율 차트 데이터를 가져온다.
	 */
	@Override
	public List<PcMntrngFxVO> getPcMngtrngFxMonthList(PcMntrngFxVO pcMntrngFxVO) throws Exception {
		// 월 기준 환율 차트 데이터를 가져온다.
		return pcMntrngFxMapper.getPcMngtrngFxMonthList(pcMntrngFxVO);
	}
}
