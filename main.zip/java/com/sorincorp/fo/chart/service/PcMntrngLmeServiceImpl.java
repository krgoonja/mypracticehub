package com.sorincorp.fo.chart.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.fo.chart.mapper.PcMntrngLmeMapper;
import com.sorincorp.fo.chart.model.PcMntrngLmeVO;

import lombok.extern.slf4j.Slf4j;

/**
 * PcMntrngLmeServiceImpl.java
 * LME 차트 관련 Service 구현체 클래스
 * 
 * @version
 * @since 2024. 9. 9.
 * @author srec0049
 */
@Slf4j
@Service
public class PcMntrngLmeServiceImpl implements PcMntrngLmeService {

	@Autowired
	private RedisUtil redisUtil;
	
    /**
     * 사이트 운영 설정 서비스
     */
    @Autowired
    private BsnInfoService bsnInfoService;
	
	/**
	 * LME 차트 관련 Mapper
	 */
	@Autowired
    private PcMntrngLmeMapper pcMntrngLmeMapper;
	
	private String LAST_DATA_LMEPC = "lastDataLmepc"; // 레디스로 발행한 마지막 실시간 LME 정보 이름(레디스에 저장된 이름)
	
	
	/**
	 * LME 초기 가격 정보 데이터 가져오기 (실시간 LME 가격 정보 가져오기 전)
	 */
	@Override
	public PcMntrngLmeVO pcMngtrngLmeInitInfo(PcMntrngLmeVO pcMntrngLmeVO) throws Exception {
		// LME 초기 가격 정보 데이터 가져오기 (실시간 LME 가격 정보 가져오기 전)
		
		PcMntrngLmeVO pcMntrngLmeByDB = pcMntrngLmeMapper.pcMngtrngLmeInitInfo(pcMntrngLmeVO);
		
		log.info(">> pcMngtrngLmeInitInfo pcMntrngLmeVO.getMetalCode() : " + pcMntrngLmeVO.getMetalCode());
		boolean restdeYn = bsnInfoService.isRestDeByMetal(pcMntrngLmeVO.getMetalCode(),  "01");
		
		// 운영시간일 경우 DB와 레디스를 비교하여 가장 최근 시간대로 가져온다. 운영시간이 아닐경우 DB에 운영시간 마지막 시간대로 조회한 값을 가져온다.
		if(restdeYn) {
			if(pcMntrngLmeByDB != null) {
				ObjectMapper objectMapper = new ObjectMapper();
				Map<String, Object> pcMntrngLmeJsonMapByRedis = objectMapper.readValue(String.valueOf(redisUtil.getDataJson(LAST_DATA_LMEPC + pcMntrngLmeVO.getMetalCode())), new TypeReference<Map<String, Object>>() {});
				
				String lmePcRltmSn = String.valueOf(pcMntrngLmeJsonMapByRedis.get("lmePcRltmSn"));
			
				BigInteger redisLmePcRltmSn = new BigInteger(lmePcRltmSn);
				BigInteger dbLmePcRltmSn = new BigInteger(pcMntrngLmeByDB.getLmePcRltmSn());
				
				if(redisLmePcRltmSn.compareTo(dbLmePcRltmSn) > 0) {
					PcMntrngLmeVO changeVO = new PcMntrngLmeVO();
					changeVO.setLmePcRltmSn(lmePcRltmSn);
					
					changeVO.setEndPc(new BigDecimal(String.valueOf(pcMntrngLmeJsonMapByRedis.get("endMdatPc"))));
					changeVO.setVersusPc(new BigDecimal(String.valueOf(pcMntrngLmeJsonMapByRedis.get("versusPc"))));
					changeVO.setVersusRate(new BigDecimal(String.valueOf(pcMntrngLmeJsonMapByRedis.get("versusRate"))));
					
					return changeVO;
				}
			}
		}
		
		return pcMntrngLmeByDB;
	}
	
	/**
	 * 1분 기준 LME 차트 데이터를 가져온다.
	 */
	@Override
	public List<PcMntrngLmeVO> getPcMngtrngLme01MinList(PcMntrngLmeVO pcMntrngLmeVO) throws Exception {
		// 1분 기준 LME 차트 데이터를 가져온다.
		return pcMntrngLmeMapper.getPcMngtrngLme01MinList(pcMntrngLmeVO);
	}

	/**
	 * 30분 기준 LME 차트 데이터를 가져온다.
	 */
	@Override
	public List<PcMntrngLmeVO> getPcMngtrngLme30MinList(PcMntrngLmeVO pcMntrngLmeVO) throws Exception {
		// 30분 기준 LME 차트 데이터를 가져온다.
		return pcMntrngLmeMapper.getPcMngtrngLme30MinList(pcMntrngLmeVO);
	}

	/**
	 * 60분 기준 LME 차트 데이터를 가져온다.
	 */
	@Override
	public List<PcMntrngLmeVO> getPcMngtrngLme60MinList(PcMntrngLmeVO pcMntrngLmeVO) throws Exception {
		// 60분 기준 LME 차트 데이터를 가져온다.
		return pcMntrngLmeMapper.getPcMngtrngLme60MinList(pcMntrngLmeVO);
	}

	/**
	 * 일 기준 LME 차트 데이터를 가져온다.
	 */
	@Override
	public List<PcMntrngLmeVO> getPcMngtrngLmeDeList(PcMntrngLmeVO pcMntrngLmeVO) throws Exception {
		// 일 기준 LME 차트 데이터를 가져온다.
		return pcMntrngLmeMapper.getPcMngtrngLmeDeList(pcMntrngLmeVO);
	}

	/**
	 * 월 기준 LME 차트 데이터를 가져온다.
	 */
	@Override
	public List<PcMntrngLmeVO> getPcMngtrngLmeMonthList(PcMntrngLmeVO pcMntrngLmeVO) throws Exception {
		// 월 기준 LME 차트 데이터를 가져온다.
		return pcMntrngLmeMapper.getPcMngtrngLmeMonthList(pcMntrngLmeVO);
	}
}
