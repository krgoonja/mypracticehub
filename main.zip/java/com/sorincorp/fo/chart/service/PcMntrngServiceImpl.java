package com.sorincorp.fo.chart.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.codehaus.plexus.util.ExceptionUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.bsnInfo.model.RestTermVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.pcInfo.model.CommSelMetalVO;
import com.sorincorp.comm.pcInfo.model.LmePcVO;
import com.sorincorp.comm.pcInfo.model.PrEhgtRltmVO;
import com.sorincorp.comm.pcInfo.model.PrPremiumSelVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.model.PreminumSelInfoVO;
import com.sorincorp.comm.pcInfo.model.RvcmpnVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.fo.chart.mapper.PcMntrngMapper;
import com.sorincorp.fo.chart.model.EntrpsMetalItmStdrVO;
import com.sorincorp.fo.chart.model.ItHghnetprcPurchsPrmpcDtlVO;
import com.sorincorp.fo.chart.model.MainPriceListVO;
import com.sorincorp.fo.chart.model.MetalInfoListVO;
import com.sorincorp.fo.chart.model.PrLmePblntfPcBasVO;
import com.sorincorp.fo.chart.model.PrMetalDisplayVO;
import com.sorincorp.fo.chart.model.SelMetalVO;
import com.sorincorp.fo.chart.model.SelPcChartVO;
import com.sorincorp.fo.config.UserInfoUtil;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class PcMntrngServiceImpl implements PcMntrngService{

	@Autowired
	private PcMntrngMapper pcMntrngMapper;

	@Autowired
	private PcInfoService pcInfoService;

	@Autowired
	private ItemCodeService itemCodeService;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	UserInfoUtil userInfoUtil;
	
	@Autowired
	private BsnInfoService bsnInfoService;
	
	@Override
	public Map<String, Object> getMainChartData() throws Exception {
		return mainChartData(null, null, null, null, null);
	}

	@Override
	public Map<String, Object> getItemChartDate(String metalCode, String sleMthdCode, String metalClCode) throws Exception {
		return mainChartData(metalCode, sleMthdCode, metalClCode, null, null);
	}

	@Override
	public Map<String, Object> getItemChartDate(String metalCode, String sleMthdCode,String type ,String entrpsNo) throws Exception {
		return mainChartData(null, null, null, type ,entrpsNo);
	}

	@Override
	public List<ItHghnetprcPurchsPrmpcDtlVO> getItHghnetprcPurchsPrmpcDtlMonth(
			ItHghnetprcPurchsPrmpcDtlVO itHghnetprcPurchsPrmpcDtlVO) throws Exception {
		return pcMntrngMapper.getItHghnetprcPurchsPrmpcDtlMonth(itHghnetprcPurchsPrmpcDtlVO);
	}

	@Override
	public List<ItHghnetprcPurchsPrmpcDtlVO> getItHghnetprcPurchsPrmpcDtlQuarter(
			ItHghnetprcPurchsPrmpcDtlVO itHghnetprcPurchsPrmpcDtlVO) throws Exception {
		return pcMntrngMapper.getItHghnetprcPurchsPrmpcDtlQuarter(itHghnetprcPurchsPrmpcDtlVO);
	}

	@Override
	public List<ItHghnetprcPurchsPrmpcDtlVO> getItHghnetprcPurchsPrmpcDtlHalfYear(
			ItHghnetprcPurchsPrmpcDtlVO itHghnetprcPurchsPrmpcDtlVO) throws Exception {
		return pcMntrngMapper.getItHghnetprcPurchsPrmpcDtlHalfYear(itHghnetprcPurchsPrmpcDtlVO);
	}

	@Override
	public List<ItHghnetprcPurchsPrmpcDtlVO> getItHghnetprcPurchsPrmpcDtlYear(
			ItHghnetprcPurchsPrmpcDtlVO itHghnetprcPurchsPrmpcDtlVO) throws Exception {
		return pcMntrngMapper.getItHghnetprcPurchsPrmpcDtlYear(itHghnetprcPurchsPrmpcDtlVO);
	}

	// 차트 대시보드 데이터
	@SuppressWarnings("unchecked")
	private Map<String, Object> mainChartData(String metalCode, String sleMthdCode, String metalClCode, String type ,String entrpsNo) throws Exception{
		Map<String, Object> returnChartData = new HashMap<String, Object>();
		List<MainPriceListVO> liveListVo = new ArrayList<MainPriceListVO>();
		List<MainPriceListVO> fixListVo = new ArrayList<MainPriceListVO>();
		
		List<RestTermVO> restTermListVO =  bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");
		
		if(type != "main") {
			restTermListVO.addAll(bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "02"));
		}
		
		//권역 조회
		Map<String, CommonCodeVO> brandCode = commonCodeService.getSubCodesRetVo("BRAND_GROUP_CODE");
		Map<String, CommonCodeVO> dstrctLclsfCode = commonCodeService.getSubCodesRetVo("DSTRCT_LCLSF_CODE");
		
		//기업회원 메탈 및 판매방식 리스트호출
		List<SelMetalVO> selMetalList = getEntrpsSelMetalList(entrpsNo, metalCode, "", sleMthdCode, type);
		List<SelMetalVO> matalCodeLiveList = new ArrayList<SelMetalVO>();
		List<SelMetalVO> matalCodeFixList = new ArrayList<SelMetalVO>();
		
		//금속을 하위메뉴로 가지고 있는 상위메뉴 리스트
//		List<HeaderMenuVO> upperMenuList = pcMntrngMapper.getUpperMenuList();
		
		//탭메뉴 리스트
//		List<MainPriceListVO> tabMenuList = new ArrayList<MainPriceListVO>();
		
		List<CommSelMetalVO> selMetalCodeList = new ArrayList<CommSelMetalVO>();
				
		for (int i = 0; i < selMetalList.size(); i++) {
			if ("01".equals(selMetalList.get(i).getSleMthdCode())) {
				matalCodeLiveList.add(selMetalList.get(i));
				
				CommSelMetalVO commSelMetalVO = new CommSelMetalVO();
				commSelMetalVO.setMetalCode(selMetalList.get(i).getMetalCode());
				commSelMetalVO.setMetalClCode(selMetalList.get(i).getMetalClCode());
				commSelMetalVO.setSleMthdCode(selMetalList.get(i).getSleMthdCode());
				commSelMetalVO.setItmSn(selMetalList.get(i).getItmSn());
				commSelMetalVO.setDstrctLclsfCode(selMetalList.get(i).getDstrctLclsfCode());
				commSelMetalVO.setBrandGroupCode(selMetalList.get(i).getBrandGroupCode());
				commSelMetalVO.setBrandCode(selMetalList.get(i).getBrandCode());
				
				selMetalCodeList.add(commSelMetalVO);
			} else if("02".equals(selMetalList.get(i).getSleMthdCode())) {
				matalCodeFixList.add(selMetalList.get(i));
				
				CommSelMetalVO commSelMetalVO = new CommSelMetalVO();
				commSelMetalVO.setMetalCode(selMetalList.get(i).getMetalCode());
				commSelMetalVO.setMetalClCode(selMetalList.get(i).getMetalClCode());
				commSelMetalVO.setSleMthdCode(selMetalList.get(i).getSleMthdCode());
				commSelMetalVO.setItmSn(selMetalList.get(i).getItmSn());
				commSelMetalVO.setDstrctLclsfCode(selMetalList.get(i).getDstrctLclsfCode());
				commSelMetalVO.setBrandGroupCode(selMetalList.get(i).getBrandGroupCode());
				commSelMetalVO.setBrandCode(selMetalList.get(i).getBrandCode());
				
				selMetalCodeList.add(commSelMetalVO);
			}
		}
		
		//탭메뉴 문구
		PrMetalDisplayVO metalDisplayVo = new PrMetalDisplayVO();
		metalDisplayVo.setCtgryLevel("1");
		metalDisplayVo.setHghnetprcSleAt("N"); //라이브는 N, 고정가는 Y

		List<PrMetalDisplayVO> metalDisplayResultList = pcMntrngMapper.selectMetalDisplayList(metalDisplayVo);
		
		//조달청 가격 조회
		RvcmpnVO rvcmpnParamVO = new RvcmpnVO();
		rvcmpnParamVO.setSelMetalCodeList(selMetalCodeList);
		rvcmpnParamVO.setApplcDe(DateUtil.getNowDate());
		List<RvcmpnVO> rvcmpnVOList = pcInfoService.getRvcmpnList(rvcmpnParamVO);
		
		List<PreminumSelInfoVO> premiumInfoListByRedisData = pcInfoService.getPremiumInfoListByRedisData();
		
		// 실시간
		for (SelMetalVO liveCode : matalCodeLiveList) {
			//프리미엄 기준아이템 정보 조회
			List<PreminumSelInfoVO> preminumInfoList = null;
			preminumInfoList = premiumInfoListByRedisData.stream().filter(preminumInfo -> 
				preminumInfo.getMetalCode().equals(liveCode.getMetalCode()) 
				&& preminumInfo.getItmSn() == Integer.parseInt(liveCode.getItmSn())
				&& preminumInfo.getBrandCode().equals(liveCode.getBrandCode())
			).collect(Collectors.toList());
			
			// 실시간
			MainPriceListVO paramVO = new MainPriceListVO();
			
			PreminumSelInfoVO stdrPreminumInfo = null;
			if(preminumInfoList != null) {
				for (PreminumSelInfoVO stdrPreminum : preminumInfoList) {
					if(stdrPreminum.getMetalCode().equals(liveCode.getMetalCode()) 
					&& stdrPreminum.getItmSn() == Integer.parseInt(liveCode.getItmSn())
					&& stdrPreminum.getDstrctLclsfCode().equals(liveCode.getDstrctLclsfCode()) 
					&& stdrPreminum.getBrandGroupCode().equals(liveCode.getBrandGroupCode())
					&& stdrPreminum.getBrandCode().equals(liveCode.getBrandCode())) {
							stdrPreminumInfo = stdrPreminum;
					}
				}
			}
			 
			if(stdrPreminumInfo != null) {
				//실시간 기준 가격 파라미터 세팅
				paramVO.setMetalCode(liveCode.getMetalCode());	//금속 코드*
				paramVO.setItmSn(Integer.parseInt(liveCode.getItmSn()));  //아이탬 순번*
				paramVO.setDstrctLclsfCode(liveCode.getDstrctLclsfCode());	//권역코드*
				paramVO.setBrandGroupCode(liveCode.getBrandGroupCode());	//브랜드 그룹코드*
				paramVO.setBrandCode(liveCode.getBrandCode()); // 브랜드 코드
				paramVO.setSleMthdCode(liveCode.getSleMthdCode());
				paramVO.setCodeNm(liveCode.getCodeNm());
				paramVO.setMetalClCode(liveCode.getMetalClCode());

				//메인 페이지 문구
				paramVO.setCodeDcone(liveCode.getCodeDcone()); //금속코드 영문명
				//paramVO.setCodeChrctrRefrnsix(liveCode.getCodeChrctrRefrnsix()); //금속코드 한글명
				paramVO.setCodeChrctrRefrntwo(liveCode.getCodeChrctrRefrntwo());
				paramVO.setBrandGroupNm(brandCode.get(stdrPreminumInfo.getBrandGroupCode()).getCodeDcone());
				paramVO.setDstrctLclsfName(dstrctLclsfCode.get(stdrPreminumInfo.getDstrctLclsfCode()).getCodeNm());
				
				List<ItemCodeVO> itemCodeList = itemCodeService.getItemCodeList(liveCode.getMetalCode());
				
				for(ItemCodeVO itemCodeVO : itemCodeList) {
					if(itemCodeVO.getSubCode().equals(liveCode.getItmSn())) {
						paramVO.setGoodsNm(itemCodeVO.getDspyGoodsNm());
					}
				}
				
				for(PrMetalDisplayVO prMetalDisplayVO: metalDisplayResultList) {
					if(prMetalDisplayVO.getMetalCode().equals(liveCode.getMetalCode())) {
						paramVO.setCodeChrctrRefrnsix(liveCode.getCodeChrctrRefrnsix());
						paramVO.setCtgryNo(prMetalDisplayVO.getCtgryNo());
						paramVO.setUpperCtgryNo(prMetalDisplayVO.getUpperCtgryNo());
					}
				}
				
				//기준 매매가 조회
				PrSelVO avgCspVo = pcInfoService.getAvgDeEndPrice(paramVO.getMetalCode(), paramVO.getItmSn(), paramVO.getDstrctLclsfCode()
						, paramVO.getBrandGroupCode(), paramVO.getBrandCode());
				
				if(avgCspVo != null) {
					paramVO.setAvgSelPc(avgCspVo.getAvgSelPc());
					paramVO.setAccmltLmeCsp(avgCspVo.getAccmltLmeCsp());
					paramVO.setAccmltUsdCvtrate(avgCspVo.getAccmltUsdCvtrate());
				}else{
					paramVO.setAvgSelPc("0");
					paramVO.setAccmltLmeCsp("0");
					paramVO.setAccmltUsdCvtrate("0");
				}
				
				//실시간 기준가 조회
				List<PrPremiumSelVO> chartTitleInfoByRedisDataList = (List<PrPremiumSelVO>) pcInfoService.getChartTitleInfoByRedisData(paramVO.getMetalCode());
				
				for (PrPremiumSelVO chartTitleInfoByRedisData : chartTitleInfoByRedisDataList) {
					if(chartTitleInfoByRedisData.getMetalCode().equals(paramVO.getMetalCode()) 
						&& chartTitleInfoByRedisData.getItmSn() == paramVO.getItmSn()
						&& chartTitleInfoByRedisData.getDstrctLclsfCode().equals(paramVO.getDstrctLclsfCode()) 
						&& chartTitleInfoByRedisData.getBrandGroupCode().equals(paramVO.getBrandGroupCode())
						&& chartTitleInfoByRedisData.getBrandCode().equals(paramVO.getBrandCode())) {
							
						paramVO.setEndPc(chartTitleInfoByRedisData.getEndPc() > 0 ? chartTitleInfoByRedisData.getEndPc() : chartTitleInfoByRedisData.getPastEndPc()); // 현재가격
						paramVO.setTopPc(chartTitleInfoByRedisData.getTopPc()); // 현재 고가
						paramVO.setLwetPc(chartTitleInfoByRedisData.getLwetPc()); // 현재 저가
						paramVO.setBeginPc(chartTitleInfoByRedisData.getBeginPc()); // 현재 시가
						paramVO.setEndPcAgo(chartTitleInfoByRedisData.getPastEndPc());	// 전날 종가
						paramVO.setFluctuationRate(chartTitleInfoByRedisData.getVersusRate().floatValue());// 등락률
						paramVO.setVersusPc(chartTitleInfoByRedisData.getVersusPc());						 // 대비가격	
						paramVO.setOccrrncDe(chartTitleInfoByRedisData.getSlePcRltmSn().substring(0, 8));
						paramVO.setOccrrncTime(chartTitleInfoByRedisData.getSlePcRltmSn().substring(8, 14));
						
						//프리미엄 기준정보 세팅
						stdrPreminumInfo.setAgoEndPc((long) chartTitleInfoByRedisData.getPastEndPc());
						paramVO.setPreminumSelVO(stdrPreminumInfo);
					}
					
					// 케이지트레이딩 시세
					if(preminumInfoList != null) {
						for (int i = 0; i < preminumInfoList.size(); i++) {
							if(chartTitleInfoByRedisData.getMetalCode().equals(paramVO.getMetalCode()) 
								&& chartTitleInfoByRedisData.getItmSn() == preminumInfoList.get(i).getItmSn()
								&& chartTitleInfoByRedisData.getDstrctLclsfCode().equals(preminumInfoList.get(i).getDstrctLclsfCode()) 
								&& chartTitleInfoByRedisData.getBrandGroupCode().equals(preminumInfoList.get(i).getBrandGroupCode())
								&& "0000000000".equals(chartTitleInfoByRedisData.getBrandCode())) {
								
								preminumInfoList.get(i).setEndPc(chartTitleInfoByRedisData.getEndPc() > 0 ? chartTitleInfoByRedisData.getEndPc() : chartTitleInfoByRedisData.getPastEndPc()); //아이탬별 종가
								preminumInfoList.get(i).setVersusPc(chartTitleInfoByRedisData.getVersusPc());
								preminumInfoList.get(i).setVersusRate(chartTitleInfoByRedisData.getVersusRate().floatValue());
								preminumInfoList.get(i).setAgoEndPc(chartTitleInfoByRedisData.getPastEndPc());
								preminumInfoList.get(i).setBrandGroupNm(brandCode.get(preminumInfoList.get(i).getBrandGroupCode()).getCodeDcone());
								preminumInfoList.get(i).setDstrctLclsfNm(dstrctLclsfCode.get(preminumInfoList.get(i).getDstrctLclsfCode()).getCodeNm());
							}
						}
					}
				}
				
				paramVO.setPreminumSelListVO(preminumInfoList);
				
				List<RvcmpnVO> resultRvcmpnVOList = new ArrayList<RvcmpnVO>();
				if(rvcmpnVOList.size() > 0) {
					for (RvcmpnVO rvcmpnVO : rvcmpnVOList) {
						if(rvcmpnVO.getMetalCode().equals(paramVO.getMetalCode())) {
							resultRvcmpnVOList.add(rvcmpnVO);
						}
					}
				}
				
				for(RvcmpnVO rvcmpnVO : resultRvcmpnVOList) {
					if("31".equals(brandCode.get(rvcmpnVO.getBrandGroupCode()).getSubCode())) {
						rvcmpnVO.setBrandGroupName("아연");
					}else {
						rvcmpnVO.setBrandGroupName(brandCode.get(rvcmpnVO.getBrandGroupCode()).getCodeDcone());
					}
				}
				
				paramVO.setRvcmpnVOArr(resultRvcmpnVOList);

				//LME 가격 조회
				PrLmePblntfPcBasVO prLmePblntfPcBasVO = new PrLmePblntfPcBasVO();
				prLmePblntfPcBasVO.setMetalCode(paramVO.getMetalCode());
				prLmePblntfPcBasVO.setGicName(liveCode.getGicName());
				PrLmePblntfPcBasVO lmePriceVO = pcMntrngMapper.getPrLmePblntfPc(prLmePblntfPcBasVO);
				paramVO.setPrLmePblntfPcBasVO(lmePriceVO);
				
				liveListVo.add(paramVO);
			}
		}

			//케이지몰(탭영역 주석처리)
//			if(bsnInfoService.isRestDeFixed()) {
//			for (SelMetalVO fixVO : matalCodeFixList) {
//				MainPriceListVO paramVO = new MainPriceListVO();
//				List<ItemCodeVO> itemCodeList = itemCodeService.getItemCodeList(fixVO.getMetalCode());
//
//				IsecoCommVO param = new IsecoCommVO();
//	            param.setSrhGubunCode("02");
//	            param.setSleMthdCode(fixVO.getSleMthdCode());
//	            param.setMetalClCode(fixVO.getMetalClCode());
//
//				PreminumInfoDto preminumInfoDto = new PreminumInfoDto();
//				preminumInfoDto.setStdDt(DateUtil.getNowDate()); // 오늘날짜
//				preminumInfoDto.setSleMthdCode(fixVO.getSleMthdCode());
//				preminumInfoDto.setMetalCode(fixVO.getMetalCode());	 // 금속코드
//				preminumInfoDto.setItmSn(Integer.parseInt(fixVO.getItmSn()));
//				preminumInfoDto.setDstrctLclsfCode(fixVO.getDstrctLclsfCode());
//				preminumInfoDto.setBrandGroupCode(fixVO.getBrandGroupCode());
//				preminumInfoDto.setBrandCode(fixVO.getBrandCode());
//				preminumInfoDto.setValidBeginDt(DateUtil.getNowDateTime("yyyyMMddHHmmss"));
//				preminumInfoDto.setValidEndDt(DateUtil.getNowDateTime("yyyyMMddHHmmss"));
//				preminumInfoDto.setMetalClCode(fixVO.getMetalClCode());	 // 금속분류코드
//
//				List<PreminumSelVO> stdrPreminumInfo = pcMntrngMapper.getFnPreminumInfoList(preminumInfoDto);
//				if(stdrPreminumInfo.size() > 0) {
//					paramVO.setMetalCode(fixVO.getMetalCode());	//금속 코드
//					paramVO.setItmSn(Integer.parseInt(fixVO.getItmSn()));  //기준 아이탬 순번* (하드코딩)
//					paramVO.setBrandCode(fixVO.getBrandCode()); // 브랜드 코드
//					paramVO.setSleMthdCode(fixVO.getSleMthdCode());
//					paramVO.setCodeNm(fixVO.getCodeNm());
//					paramVO.setMetalClCode(fixVO.getMetalClCode());
//					paramVO.setChartTitleMetalNm(fixVO.getCodeChrctrRefrnsix());
//
//
//					//메인 페이지 문구
//					paramVO.setCodeDcone(fixVO.getCodeDcone()); //금속코드 영문명
//					paramVO.setCodeChrctrRefrntwo(fixVO.getCodeChrctrRefrntwo());
//
//					//탭메뉴 문구
//					PrMetalDisplayVO metalDisplayVo = new PrMetalDisplayVO();
//					metalDisplayVo.setMetalCode(fixVO.getMetalCode());
//					metalDisplayVo.setMetalClCode(fixVO.getMetalClCode());
//					//metalDisplayVo.setCtgryLevel("1");
//					metalDisplayVo.setHghnetprcSleAt("Y"); //라이브는 N, 고정가는 Y
//
//					PrMetalDisplayVO metalDisplayResult = pcMntrngMapper.selectMetalDisplay(metalDisplayVo);
//					if(metalDisplayResult != null) {
//						paramVO.setCodeChrctrRefrnsix(metalDisplayResult.getCtgryNm());
//						paramVO.setCtgryNo(metalDisplayResult.getCtgryNo());
//						paramVO.setUpperCtgryNo(metalDisplayResult.getUpperCtgryNo());
//						
//						if(metalCode != null && !"".equals(metalCode)) {
//							if(paramVO.getMetalCode().equals(metalCode) && paramVO.getSleMthdCode().equals(sleMthdCode) && paramVO.getMetalClCode().equals(metalClCode)) {
//								tabMenuList.add(paramVO);
//							}
//						}
//					}
//
//					//고정가 프리미엄 정보
//					List<FixPreminumVO> fpVO = pcMntrngMapper.getFixPremiumInfoList(preminumInfoDto);
//
//					//고정가 기준 아이템
//					for (int i = 0; i < fpVO.size(); i++) {
//						if (fpVO.get(i).getItmSn() == Integer.parseInt(fixVO.getMetalCode()) && fpVO.get(i).getMetalClCode().equals(fixVO.getMetalClCode())) {
//							paramVO.setItmSn(fpVO.get(i).getItmSn());
//							paramVO.setEndPc(fpVO.get(i).getSleStdrPc()); //판매 기준 가격
//							paramVO.setVersusPc(fpVO.get(i).getVersusPc());
//							paramVO.setFluctuationRate(fpVO.get(i).getSleStdrPcRate().floatValue());
//						}
//					}
//
//					//시가 고가 저가
//					ItHghnetprcPurchsPrmpcDtlVO itHghnetprcPurchsPrmpcDtlVO = new ItHghnetprcPurchsPrmpcDtlVO();
//					itHghnetprcPurchsPrmpcDtlVO.setItmSn(Integer.parseInt(fixVO.getItmSn()));
//					itHghnetprcPurchsPrmpcDtlVO.setMetalCode(fixVO.getMetalCode());
//					List<ItHghnetprcPurchsPrmpcDtlVO> fixPriceInfoList = pcMntrngMapper.getItHghnetprcPurchsPrmpcDtlMonth(itHghnetprcPurchsPrmpcDtlVO);
//					if (!fixPriceInfoList.isEmpty()) {
//						paramVO.setEndPc(Long.parseLong(fixPriceInfoList.get(0).getEndPc()));
//						paramVO.setTopPc(Long.parseLong(fixPriceInfoList.get(0).getTopPc()));
//						paramVO.setBeginPc(Long.parseLong(fixPriceInfoList.get(0).getBeginPc()));
//						paramVO.setLwetPc(Long.parseLong(fixPriceInfoList.get(0).getLwetPc()));
//						if(fixPriceInfoList.size() >= 2){
//							paramVO.setEndPcAgo(Long.parseLong(fixPriceInfoList.get(1).getEndPc()));
//						}else {
//							paramVO.setEndPcAgo(0);
//						}
//					}
//
//
//					// 아이탬명 세팅
//					if(!itemCodeList.isEmpty()) {
//						for (int i = 0; i < itemCodeList.size(); i++) {
//
//							for (int j = 0; j < fpVO.size(); j++) {
//								//전체 아이템 이름
//								if(Integer.parseInt(itemCodeList.get(i).getSubCode())  == fpVO.get(j).getItmSn()) {
//									fpVO.get(j).setItmName(itemCodeList.get(i).getCodeNm());
//								}
//								//기준 아이템 이름
//								if(Integer.parseInt(itemCodeList.get(i).getSubCode())  == paramVO.getItmSn()) {
//									paramVO.setGoodsNm(itemCodeList.get(i).getDspyGoodsNm());
//								}
//							}
//						}
//					}
//					paramVO.setFixPreminumArr(fpVO);
//
//
//				//조달청 가격
//				List<RvcmpnVO> rvcmpnVOList = pcInfoService.getRvcmpn(DateUtil.getNowDate(), fixVO.getMetalCode());
//				if(!rvcmpnVOList.isEmpty()) {
//					for (RvcmpnVO rvcmpnVO : rvcmpnVOList) {
//						rvcmpnVO.setBrandGroupName(brandCode.get(rvcmpnVO.getBrandGroupCode()).getCodeDcone());
//						paramVO.setRvcmpnVOArr(rvcmpnVOList);
//					}
//				}
//				fixListVo.add(paramVO);
//			}
//		}

		//탭메뉴 설정
//		if(entrpsNo != null) {
//			for(HeaderMenuVO upperMenu : upperMenuList) {
//				MainPriceListVO paramVO = new MainPriceListVO();
//				int count = 0;
//				for(MainPriceListVO fixVo : fixListVo) {
//					if(fixVo.getUpperCtgryNo() != null && fixVo.getUpperCtgryNo().equals(upperMenu.getCtgryNo())) {
//						count ++;
//					}
//				}
//				if(count > 0) {
//					paramVO.setCodeChrctrRefrnsix(upperMenu.getCtgryNm());
//					paramVO.setCtgryNo(upperMenu.getCtgryNo());
//					tabMenuList.add(paramVO);
//				}
//			}
//		}
//		returnChartData.put("tabMenuList", tabMenuList);
			
		// 휴일 관련
		returnChartData.put("restdeInfoList", restTermListVO);

		// 라이브 시세 리스트
		returnChartData.put("liveList", liveListVo);
		// 고정가 시세 리스트
		returnChartData.put("fixList", fixListVo);

		//환율 조회
		PrEhgtRltmVO prEhgtRltmVO = pcInfoService.getNewestPrEhgtRltm("SPTUSD/KRW");
		if (prEhgtRltmVO != null) {
			returnChartData.put("ehgtRltm", prEhgtRltmVO.getEndPc());
		} else {  
			returnChartData.put("ehgtRltm", 0);
		}
		
		if(metalCode != null) {
			//실시간 Lme가격 조회
			LmePcVO prLmeRltmVO = pcInfoService.getNewestPrLmeRltm(metalCode, DateUtil.getNowDate());
			if (prEhgtRltmVO != null) {
				BigDecimal lmeRltm = prLmeRltmVO.getEndPc().setScale(2, RoundingMode.FLOOR);
				
				returnChartData.put("lmeRltm", lmeRltm);
			} else {  
				returnChartData.put("lmeRltm", 0);
			}
		}

		return returnChartData;
	}
	
	public List<MetalInfoListVO> getLiveList(String metalCode, String sleMthdCode, String type ,String entrpsNo) throws Exception{
		List<MetalInfoListVO> liveListVo = new ArrayList<MetalInfoListVO>();
		Map<String, CommonCodeVO> brandCode = commonCodeService.getSubCodesRetVo("BRAND_GROUP_CODE");
		Map<String, CommonCodeVO> dstrctLclsfCode = commonCodeService.getSubCodesRetVo("DSTRCT_LCLSF_CODE");
		
		//기업회원 메탈 및 판매방식 리스트호출
		List<SelMetalVO> selMetalList = getEntrpsSelMetalList(entrpsNo, metalCode, "", sleMthdCode, type);
		List<SelMetalVO> matalCodeLiveList = new ArrayList<SelMetalVO>();
				
		for (int i = 0; i < selMetalList.size(); i++) {
			if ("01".equals(selMetalList.get(i).getSleMthdCode())) {
				matalCodeLiveList.add(selMetalList.get(i));
			}
		}
		
		//탭메뉴 문구
		PrMetalDisplayVO metalDisplayVo = new PrMetalDisplayVO();
		metalDisplayVo.setCtgryLevel("1");
		metalDisplayVo.setHghnetprcSleAt("N"); //라이브는 N, 고정가는 Y
		
		List<PrMetalDisplayVO> metalDisplayResultList = selectMetalDisplayList(metalDisplayVo);
		
		List<PreminumSelInfoVO> premiumInfoListByRedisData = pcInfoService.getPremiumInfoListByRedisData();
		
		// 실시간
		for (SelMetalVO liveCode : matalCodeLiveList) {
			//프리미엄 기준아이템 정보 조회
			List<PreminumSelInfoVO> preminumInfoList = premiumInfoListByRedisData.stream().filter(preminumInfo -> 
				preminumInfo.getMetalCode().equals(liveCode.getMetalCode()) 
				&& preminumInfo.getItmSn() == Integer.parseInt(liveCode.getItmSn())
				&& preminumInfo.getBrandCode().equals(liveCode.getBrandCode())
			).collect(Collectors.toList());
			
			// 실시간
			MetalInfoListVO paramVO = new MetalInfoListVO();
			
			PreminumSelInfoVO stdrPreminumInfo = null;
			if(preminumInfoList  != null) {
				for (PreminumSelInfoVO stdrPreminum : preminumInfoList) {
					if(stdrPreminum.getMetalCode().equals(liveCode.getMetalCode()) 
					&& stdrPreminum.getItmSn() == Integer.parseInt(liveCode.getItmSn())
					&& stdrPreminum.getDstrctLclsfCode().equals(liveCode.getDstrctLclsfCode()) 
					&& stdrPreminum.getBrandGroupCode().equals(liveCode.getBrandGroupCode())
					&& stdrPreminum.getBrandCode().equals(liveCode.getBrandCode())) {
							stdrPreminumInfo = stdrPreminum;
					}
				}
			}
			
			if(stdrPreminumInfo != null) {
				//실시간 기준 가격 파라미터 세팅
				paramVO.setMetalCode(liveCode.getMetalCode());	//금속 코드*
				paramVO.setItmSn(Integer.parseInt(liveCode.getItmSn()));  //아이탬 순번*
				paramVO.setDstrctLclsfCode(liveCode.getDstrctLclsfCode());	//권역코드*
				paramVO.setBrandGroupCode(liveCode.getBrandGroupCode());	//브랜드 그룹코드*
				paramVO.setBrandCode(liveCode.getBrandCode()); // 브랜드 코드
				paramVO.setSleMthdCode(liveCode.getSleMthdCode());
				paramVO.setCodeNm(liveCode.getCodeNm());
				paramVO.setMetalClCode(liveCode.getMetalClCode());
				paramVO.setGicName(liveCode.getGicName());

				//메인 페이지 문구
				paramVO.setCodeDcone(liveCode.getCodeDcone()); //금속코드 영문명

				paramVO.setCodeChrctrRefrntwo(liveCode.getCodeChrctrRefrntwo());
				
				String codeChrctrRefrnsix = liveCode.getCodeChrctrRefrnsix();
				
				for(PrMetalDisplayVO prMetalDisplayVO: metalDisplayResultList) {
					if(prMetalDisplayVO.getMetalCode().equals(liveCode.getMetalCode())) {
						paramVO.setCodeChrctrRefrnsix(codeChrctrRefrnsix);
						paramVO.setCtgryNo(prMetalDisplayVO.getCtgryNo());
						paramVO.setUpperCtgryNo(prMetalDisplayVO.getUpperCtgryNo());
					}
				}
			
				paramVO.setBrandGroupNm(brandCode.get(stdrPreminumInfo.getBrandGroupCode()).getCodeDcone());
				paramVO.setDstrctLclsfName(dstrctLclsfCode.get(stdrPreminumInfo.getDstrctLclsfCode()).getCodeNm());
				
				liveListVo.add(paramVO);
			}
		}

		return liveListVo;
	}

	@Override
	public JSONArray getRestdeInfoJson() throws Exception {
		// 휴일 코드 추가
		List<Map<String, Object>> restdeStateListMap = new ArrayList<Map<String, Object>>();
		List<RestTermVO> restTermListVO =  bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");
		if(!restTermListVO.isEmpty()) {
			for (int i = 0; i < restTermListVO.size(); i++) {
				Map<String,Object> map = new HashMap<String,Object>();
					map.put("metalCode", restTermListVO.get(i).getMetalCode());
					map.put("restWaitTerm",restTermListVO.get(i).getWaitTerm()); // 영업 시작, 종료 시간까지 초단위
					map.put("restWaitNm", restTermListVO.get(i).getWaitNm());
					map.put("openTimeCode", restTermListVO.get(i).getOpenTimeCode());
					map.put("chartStTitle", restTermListVO.get(i).getChartStTitle());
					map.put("chartEdTitle", restTermListVO.get(i).getChartEdTitle());
					map.put("topWaitTerm", restTermListVO.get(i).getTopWaitTerm());
					map.put("topWaitNm", restTermListVO.get(i).getTopWaitNm());
					map.put("sleMthdCode", restTermListVO.get(i).getSleMthdCode());

				restdeStateListMap.add(map);
			}
		}

		return convertListToJson(restdeStateListMap);
	}

	// list<map> 을 json 형태로 변형.
	public static JSONArray convertListToJson(List<Map<String, Object>> bankCdList) {
		JSONArray jsonArray = new JSONArray();
		for (Map<String, Object> map : bankCdList) {
			jsonArray.add(convertMapToJson(map));
		}
		return jsonArray;
	}

	// map 을 json 형태로 변형
	public static JSONObject convertMapToJson(Map<String, Object> map) {
		JSONObject json = new JSONObject();
		for (Map.Entry<String, Object> entry : map.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			// json.addProperty(key, value);
			json.put(key, value);
		}
		return json;
	}

	public List<SelMetalVO> getEntrpsSelMetalList(String entrpsNo, String metalCode, String metalClCode, String sleMthdCode ,String type) {
		List<SelMetalVO> selMetalList = new ArrayList<SelMetalVO>();
		try {
			List<ItemCodeVO> itemCodeList = new ArrayList<ItemCodeVO>();

			if(entrpsNo != null) {
				itemCodeList = itemCodeService.getMbEntrpsMetalAcctoAuthorSetupBasList(entrpsNo);
			}
			
			Map<String, List<String>> itemMetalList = new HashMap<>();
			for(ItemCodeVO itemCodeVO : itemCodeList) {
				List<String> sleMthdCodeList = new ArrayList<>();
				if ("Y".equals(itemCodeVO.getLivePcAt())) {
					sleMthdCodeList.add(CommonConstants.LIVE_SLE_MTHD_CODE);
				}
			
				if ("Y".equals(itemCodeVO.getFixingPcAt())) {
					sleMthdCodeList.add(CommonConstants.HGHNETPRC_SLE_MTHD_CODE);
				}

				if ("Y".equals(itemCodeVO.getAppnPcAt())) {
					sleMthdCodeList.add(CommonConstants.LIMITS_SLE_MTHD_CODE);
				}
				
				if ("Y".equals(itemCodeVO.getAvrgPcAt())) {
					sleMthdCodeList.add(CommonConstants.AVRGPC_SLE_MTHD_CODE);
				}
				
				itemMetalList.put(itemCodeVO.getMetalCode(), sleMthdCodeList);
			}

			selMetalList = pcMntrngMapper.selectEntrpsSelMetalList(metalCode, sleMthdCode, metalClCode, type, itemMetalList);
		} catch(Exception e) {
			log.error("getEntrpsSelMetalList Error=====>" + ExceptionUtils.getStackTrace(e));
		}
		return selMetalList;
	}

	@Override
	public PrLmePblntfPcBasVO getPrLmePblntfPc(PrLmePblntfPcBasVO prLmePblntfPcBasVO) throws Exception {
		return pcMntrngMapper.getPrLmePblntfPc(prLmePblntfPcBasVO);
	}
	
	@Override
	public List<PrMetalDisplayVO> selectMetalDisplayList(PrMetalDisplayVO metalDisplayVo) throws Exception {
		return pcMntrngMapper.selectMetalDisplayList(metalDisplayVo);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public SelPcChartVO getSelPcChartList(SelPcChartVO selPcChartParamVO) throws Exception {
		//실시간 기준가 조회
		SelPcChartVO selPcChartVO = new SelPcChartVO();
		Map<String, CommonCodeVO> brandCode = commonCodeService.getSubCodesRetVo("BRAND_GROUP_CODE");
		Map<String, CommonCodeVO> dstrctLclsfCode = commonCodeService.getSubCodesRetVo("DSTRCT_LCLSF_CODE");
		List<PrPremiumSelVO> chartTitleInfoByRedisDataList = (List<PrPremiumSelVO>) pcInfoService.getChartTitleInfoByRedisData(selPcChartParamVO.getMetalCode());
		List<PreminumSelInfoVO> premiumInfoListByRedisData = pcInfoService.getPremiumInfoListByRedisData();
		List<PreminumSelInfoVO> preminumInfoList = premiumInfoListByRedisData.stream().filter(preminumInfo -> 
			preminumInfo.getMetalCode().equals(selPcChartParamVO.getMetalCode()) 
			&& preminumInfo.getItmSn() == selPcChartParamVO.getItmSn()
			&& preminumInfo.getBrandCode().equals(selPcChartParamVO.getBrandCode())
		).collect(Collectors.toList());
		
		PreminumSelInfoVO stdrPreminumInfo = null;
		for (PreminumSelInfoVO stdrPreminum : preminumInfoList) {
			if(stdrPreminum.getMetalCode().equals(selPcChartParamVO.getMetalCode()) 
			&& stdrPreminum.getItmSn() == selPcChartParamVO.getItmSn()
			&& stdrPreminum.getDstrctLclsfCode().equals(selPcChartParamVO.getDstrctLclsfCode()) 
			&& stdrPreminum.getBrandGroupCode().equals(selPcChartParamVO.getBrandGroupCode())
			&& stdrPreminum.getBrandCode().equals(selPcChartParamVO.getBrandCode())) {
				stdrPreminumInfo = stdrPreminum;
			}
		}
		
		for (PrPremiumSelVO chartTitleInfoByRedisData : chartTitleInfoByRedisDataList) {
			if(chartTitleInfoByRedisData.getMetalCode().equals(selPcChartParamVO.getMetalCode()) 
				&& chartTitleInfoByRedisData.getItmSn() == selPcChartParamVO.getItmSn()
				&& chartTitleInfoByRedisData.getDstrctLclsfCode().equals(selPcChartParamVO.getDstrctLclsfCode()) 
				&& chartTitleInfoByRedisData.getBrandGroupCode().equals(selPcChartParamVO.getBrandGroupCode())
				&& chartTitleInfoByRedisData.getBrandCode().equals(selPcChartParamVO.getBrandCode())) {
					
				selPcChartVO.setMetalCode(selPcChartParamVO.getMetalCode());
				selPcChartVO.setItmSn(selPcChartParamVO.getItmSn());
				selPcChartVO.setDstrctLclsfCode(selPcChartParamVO.getDstrctLclsfCode());
				selPcChartVO.setBrandGroupCode(selPcChartParamVO.getBrandGroupCode());
				selPcChartVO.setBrandCode(selPcChartParamVO.getBrandCode());
				selPcChartVO.setEndPc(chartTitleInfoByRedisData.getEndPc() > 0 ? chartTitleInfoByRedisData.getEndPc() : chartTitleInfoByRedisData.getPastEndPc()); // 현재가격
				selPcChartVO.setTopPc(chartTitleInfoByRedisData.getTopPc()); // 현재 고가
				selPcChartVO.setLwetPc(chartTitleInfoByRedisData.getLwetPc()); // 현재 저가
				selPcChartVO.setBeginPc(chartTitleInfoByRedisData.getBeginPc()); // 현재 시가
				selPcChartVO.setEndPcAgo(chartTitleInfoByRedisData.getPastEndPc());	// 전날 종가
				selPcChartVO.setFluctuationRate(chartTitleInfoByRedisData.getVersusRate().floatValue());// 등락률
				selPcChartVO.setVersusPc(chartTitleInfoByRedisData.getVersusPc());						 // 대비가격	
				selPcChartVO.setOccrrncDe(chartTitleInfoByRedisData.getSlePcRltmSn().substring(0, 8));
				selPcChartVO.setOccrrncTime(chartTitleInfoByRedisData.getSlePcRltmSn().substring(8, 14));
				selPcChartVO.setBrandGroupNm(brandCode.get(stdrPreminumInfo.getBrandGroupCode()).getCodeDcone());
				selPcChartVO.setDstrctLclsfName(dstrctLclsfCode.get(stdrPreminumInfo.getDstrctLclsfCode()).getCodeNm());
				
				//프리미엄 기준정보 세팅
				stdrPreminumInfo.setAgoEndPc((long) chartTitleInfoByRedisData.getPastEndPc());
				selPcChartVO.setPreminumSelVO(stdrPreminumInfo);
			}
			
			// 케이지트레이딩 시세
			if(preminumInfoList != null) {
				for (int i = 0; i < preminumInfoList.size(); i++) {
					if(chartTitleInfoByRedisData.getMetalCode().equals(selPcChartParamVO.getMetalCode()) 
						&& chartTitleInfoByRedisData.getItmSn() == preminumInfoList.get(i).getItmSn()
						&& chartTitleInfoByRedisData.getDstrctLclsfCode().equals(preminumInfoList.get(i).getDstrctLclsfCode()) 
						&& chartTitleInfoByRedisData.getBrandGroupCode().equals(preminumInfoList.get(i).getBrandGroupCode())
						&& "0000000000".equals(chartTitleInfoByRedisData.getBrandCode())) {
						
						preminumInfoList.get(i).setEndPc(chartTitleInfoByRedisData.getEndPc() > 0 ? chartTitleInfoByRedisData.getEndPc() : chartTitleInfoByRedisData.getPastEndPc()); //아이탬별 종가
						preminumInfoList.get(i).setVersusPc(chartTitleInfoByRedisData.getVersusPc());
						preminumInfoList.get(i).setVersusRate(chartTitleInfoByRedisData.getVersusRate().floatValue());
						preminumInfoList.get(i).setAgoEndPc(chartTitleInfoByRedisData.getPastEndPc());
						preminumInfoList.get(i).setBrandGroupNm(brandCode.get(preminumInfoList.get(i).getBrandGroupCode()).getCodeDcone());
						preminumInfoList.get(i).setDstrctLclsfNm(dstrctLclsfCode.get(preminumInfoList.get(i).getDstrctLclsfCode()).getCodeNm());
					}
				}
				
				selPcChartVO.setPreminumSelListVO(preminumInfoList);
			}
		}
		
		List<ItemCodeVO> itemCodeList = itemCodeService.getItemCodeList(selPcChartParamVO.getMetalCode());
		
		for(ItemCodeVO itemCodeVO : itemCodeList) {
			if(itemCodeVO.getSubCode().equals(String.valueOf(selPcChartParamVO.getItmSn()))) {
				selPcChartVO.setGoodsNm(itemCodeVO.getDspyGoodsNm());
			}
		}
		
		return selPcChartVO;
	}
	
	@Override
	public EntrpsMetalItmStdrVO getEntrpsMetalItmStdr(String entrpsNo) throws Exception {
		EntrpsMetalItmStdrVO entrpsMetalItmStdrVO = new EntrpsMetalItmStdrVO();
		entrpsMetalItmStdrVO.setEntrpsNo(entrpsNo);	
		return pcMntrngMapper.getEntrpsMetalItmStdr(entrpsMetalItmStdrVO);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<PreminumSelInfoVO> getSelMetalList(String entrpsNo) throws Exception {
		
		//기업회원 메탈 및 판매방식 리스트호출
		List<SelMetalVO> selMetalList = new ArrayList<SelMetalVO>();
		
		if ( entrpsNo == null) {
			selMetalList = getEntrpsSelMetalList("", "", "", "01", "main");
		}else {
			selMetalList = getEntrpsSelMetalList(entrpsNo, "", "", "01", "login");
		}
		
		List<PreminumSelInfoVO> preminumSelInfoListVO = new ArrayList<PreminumSelInfoVO>();
		
		Map<String, CommonCodeVO> brandCode = commonCodeService.getSubCodesRetVo("BRAND_GROUP_CODE");
		Map<String, CommonCodeVO> dstrctLclsfCode = commonCodeService.getSubCodesRetVo("DSTRCT_LCLSF_CODE");
		//실시간 기준가 조회
		for(SelMetalVO selMetalVO : selMetalList) {
			List<PrPremiumSelVO> chartTitleInfoByRedisDataList = (List<PrPremiumSelVO>) pcInfoService.getChartTitleInfoByRedisData(selMetalVO.getMetalCode());
			List<PreminumSelInfoVO> premiumInfoListByRedisData = pcInfoService.getPremiumInfoListByRedisData();
			List<PreminumSelInfoVO> preminumInfoList = premiumInfoListByRedisData.stream().filter(preminumInfo -> 
				preminumInfo.getMetalCode().equals(selMetalVO.getMetalCode()) 
				&& preminumInfo.getItmSn() == Integer.parseInt(selMetalVO.getItmSn())
				&& preminumInfo.getBrandCode().equals(selMetalVO.getBrandCode())
			).collect(Collectors.toList());
			
			for (PrPremiumSelVO chartTitleInfoByRedisData : chartTitleInfoByRedisDataList) {
				// 케이지트레이딩 시세
				if(!preminumInfoList.isEmpty()) {
					for (PreminumSelInfoVO preminumSelInfoVO : preminumInfoList) {
						if(chartTitleInfoByRedisData.getMetalCode().equals(selMetalVO.getMetalCode()) 
							&& chartTitleInfoByRedisData.getItmSn() == preminumSelInfoVO.getItmSn()
							&& chartTitleInfoByRedisData.getDstrctLclsfCode().equals(preminumSelInfoVO.getDstrctLclsfCode()) 
							&& chartTitleInfoByRedisData.getBrandGroupCode().equals(preminumSelInfoVO.getBrandGroupCode())
							&& "0000000000".equals(chartTitleInfoByRedisData.getBrandCode())) {
							
							preminumSelInfoVO.setBrandGroupNm(brandCode.get(preminumSelInfoVO.getBrandGroupCode()).getCodeDcone());
							preminumSelInfoVO.setDstrctLclsfNm(dstrctLclsfCode.get(preminumSelInfoVO.getDstrctLclsfCode()).getCodeNm());
							preminumSelInfoVO.setMetalClCode(selMetalVO.getMetalClCode());
							preminumSelInfoListVO.add(preminumSelInfoVO);
						}
					}
				}
			}
		}
		
		return preminumSelInfoListVO;
	}
	
	@Override
	public int insertEntrpsMetalItmStdr(EntrpsMetalItmStdrVO entrpsMetalItmStdrVO) throws Exception {
		return pcMntrngMapper.insertEntrpsMetalItmStdr(entrpsMetalItmStdrVO);
	}
	
	@Override
	public int insertEntrpsMetalItmStdrHst(EntrpsMetalItmStdrVO entrpsMetalItmStdrVO) throws Exception {
		return pcMntrngMapper.insertEntrpsMetalItmStdrHst(entrpsMetalItmStdrVO);
	}
}
