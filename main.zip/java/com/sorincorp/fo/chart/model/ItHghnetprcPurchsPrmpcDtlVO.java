package com.sorincorp.fo.chart.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ItHghnetprcPurchsPrmpcDtlVO extends CommonVO {

	private static final long serialVersionUID = 1L;

    /**
     * 적용 년월
    */
    private String applcYm;
    /**
     * 적용 월
     */
    private String month;
    /**
     * 차트 적용 시간
     */
    private String chartSelTime;
    /**
     * 종가 기준 시간
     */
    private String chartEndTime;
    /**
     * 기간 구분
     */
    private String type;
    /**
     * 고가
     */
    private String topPc;
    /**
     * 저가
     */
    private String lwetPc;
    /**
     * 시가
     */
    private String beginPc;
    /**
     * 종가
     */
    private String endPc;
    /**
     * 분기
     */
    private String yyyyQt;
    /**
     * 년도
     */
    private String yyyy;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 거래량
     */
    private int delngQy;
    /**
     * 아이템 변동 금액
    */
    private long itmChangeAmount;
    /**
     * 변동률
     */
    private String versusRate;
    /**
     * 변동금액
     */
    private int versusPc;
    /**
     * 매입 가격
    */
    private long puchasPc;
    /**
     * 판매 기준 가격
    */
    private long sleStdrPc;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
}
