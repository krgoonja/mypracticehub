package com.sorincorp.fo.chart.model;

import java.io.Serializable;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * PreminumSelVO.java
 * @version
 * @since 2021. 11. 15.
 * @author srec0008
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class PrLmePblntfPcBasVO  implements Serializable {

	private static final long serialVersionUID = -4371748259883381685L;
	
	/**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 발생 일자
    */
    private String occrrncDe;
    /**
     * 종목코드(삼성선물)
     */
    private String gicName;
    /**
     * LME 공시 가격 순번
    */
    private String lmePblntfPcSn;
    /**
     * 전 영업 일자
    */
    private String bfeBsnDe;
    /**
     * 전일 종가
     */
    private java.math.BigDecimal endPc;
    /**
     * 전일 종가 대비비율
     */
    private java.math.BigDecimal endPcRate;
    /**
     * 3개월 종가
     */
    private java.math.BigDecimal threemonthEndPc;
    /**
     * 3개월 종가 대비비율
     */
    private java.math.BigDecimal threemonthEndPcRate;
    /**
     * 현물 공시 매도 가격
    */
    private java.math.BigDecimal acthngPblntfSalePc;
    /**
     * 현물 공시 매도 가격 대비비율
     */
    private java.math.BigDecimal acthngPblntfSalePcRate;
    /**
     * 선물 공시 매도 가격
    */
    private java.math.BigDecimal ftrsPblntfSalePc;
    /**
     * 선물 공시 매도 가격 대비비율
     */
    private java.math.BigDecimal ftrsPblntfSalePcRate;

}
