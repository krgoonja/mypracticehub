package com.sorincorp.fo.chart.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * PreminumSelVO.java
 * @version
 * @since 2021. 11. 15.
 * @author srec0008
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class PrMetalDisplayVO extends CommonVO {

	private static final long serialVersionUID = 1L;

    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 금속 코드
    */
    private String metalClCode;
    /**
     * 카테고리 레벨 
     */
    private String ctgryLevel;
    /**
     * 고정가 판매 여부 (Y/N)
     */
    private String hghnetprcSleAt;
    /**
     * 카테고리 이름
     */
    private String ctgryNm;
    /**
     * 카테고리 번호
     */
    private String ctgryNo;
    /**
     * 상위 카테고리 번호
     */
    private String upperCtgryNo;
}
