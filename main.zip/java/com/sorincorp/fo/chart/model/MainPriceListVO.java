package com.sorincorp.fo.chart.model;

import java.math.BigDecimal;
import java.util.List;

import com.sorincorp.comm.model.CommonVO;
import com.sorincorp.comm.pcInfo.model.FixPriceVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.model.PreminumSelInfoVO;
import com.sorincorp.comm.pcInfo.model.RvcmpnVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class MainPriceListVO extends CommonVO {

	private static final long serialVersionUID = 1L;

	/**
	 * 금속 코드
	 */
	private String metalCode;
	/**
	 * 금속 코드
	 */
	private String metalClCode;
	/**
	 * 금속 코드 영문명
	 */
	private String codeDcone;
	/**
	 * 금속 코드 한글명
	 */
	private String codeChrctrRefrnsix;
	/**
	 * 실시간 종가
	 */
	private long endPc;
	/**
	 * 실시간 고가
	 */
	private long topPc;
	/**
	 * 실시간 저가
	 */
	private long lwetPc;
	/**
	 * 실시간 시가
	 */
	private long beginPc;
	/**
	 * 전일 종가
	 */
	private long endPcAgo;
	/**
	 * 최근 종가
	 */
	private long deEndPc;
	/**
	 * 환율 실시간 종가
	 */
	private BigDecimal ehgtEndPc;
	/**
	 * 등락률
	 */
	private float fluctuationRate;
	/**
	 * 대비가격
	 */
	private long versusPc;
	/**
	 * 아이탬 순번
	 */
	private int itmSn;
	/**
	 * 아이탬명
	 */
	private String goodsNm;
	/**
	 * 금속코드 명
	 */
	private String codeNm;
	/**
	 * 금속코드 인덱스명
	 */
	private String codeChrctrRefrntwo;
	/**
	 * 권역 코드
	 */
	private String dstrctLclsfCode;
	/**
	 * 권역 이름
	 */
	private String dstrctLclsfName;
	/**
	 * 브랜드 그룹 코드
	 */
	private String brandGroupCode;
	/**
	 * 브랜드 그룹 이름
	 */
	private String brandGroupNm;
	/**
	 * 브랜드 코드
	 */
	private String brandCode;
	/**
	 * 아이템 이름
	 */
	private String itemCodeName;
	/**
	 * 프리미엄 아이디
	 */
	private String premiumId;
	/**
	 * 기준가
	 */
	private PrSelVO prSelRltmVo;
	/**
     * 기준 매매가 평균
    */
    private String avgEndPc;
    /**
     * 월 누적 평균 가격
    */
    private String avgSelPc;
    /**
     * LME(CSP) 누적 평균 가격
     */
    private String accmltLmeCsp;
    /**
     * 환율(최초매매) 누적 가격
     */
    private String accmltUsdCvtrate;
	/**
	 * 판매방식코드
	 */
	private String sleMthdCode;
	/**
     * 카테고리 번호
     */
	private String ctgryNo;
	/**
     * 카테고리 번호
     */
	private String upperCtgryNo;
	/**
	 * 프리미엄 기준 데이터
	 */
	private PreminumSelInfoVO preminumSelVO;
	/**
	 * 프리미엄 정보 리스트 
	 */
	private List<PreminumSelInfoVO> preminumSelListVO;
	/**
	 * Lme 시세 정보
	 */
	private PrLmePblntfPcBasVO prLmePblntfPcBasVO;
	/**
	 * 프리미엄 아연 아이탬 리스트
	 */
	private List<FixPreminumVO> fixPreminumArr;
	/**
	 * 비 기준가 리스트
	 */
	private List<PrSelVO> prSelNonStdrArr;
	/**
	 * 조달청 가격 리스트
	 */
	private List<RvcmpnVO> rvcmpnVOArr;
	/**
	 * 차트 상단 케이지몰 금속이름
	 */
	private String chartTitleMetalNm;
	/**
	 * 제원
	 */
	private String specifications;
	
    /**
     * 발생 일자
    */
    private String occrrncDe;
    /**
     * 발생 시간
    */
    private String occrrncTime;

	private List<FixPriceVO> nonStdrFixPriceList;
	
	public List<RvcmpnVO> getRvcmpnVOArr(){
		return rvcmpnVOArr;
	}
	
	public void setRvcmpnVOArr(List<RvcmpnVO> rvcmpnVOArr) {
		this.rvcmpnVOArr = rvcmpnVOArr;
	}
	
	public List<FixPreminumVO> getFixPreminumVArr(){
		return fixPreminumArr;
	}
	
	public void setFixPreminumVOArr(List<FixPreminumVO> fixPreminumArr) {
		this.fixPreminumArr = fixPreminumArr;
	}
	
	public List<PreminumSelInfoVO> getPreminumSelListVO(){
		return preminumSelListVO;
	}
	
	public void setPreminumSelListVO(List<PreminumSelInfoVO> preminumSelListVO) {
		this.preminumSelListVO = preminumSelListVO;
	}

}
