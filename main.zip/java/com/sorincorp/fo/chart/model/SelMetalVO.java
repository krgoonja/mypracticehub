package com.sorincorp.fo.chart.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * PreminumSelVO.java
 * @version
 * @since 2022. 03. 16.
 * @author srec0008
 */
/**
 * SelMetalVO.java
 * @version
 * @since 2022. 3. 18.
 * @author srec0008
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class SelMetalVO extends CommonVO {

	private static final long serialVersionUID = 1L;

    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 금속 분류 코드
    */
    private String metalClCode;
    /**
     * 판매방식 
     */
    private String sleMthdCode;
    /**
     * 기준아이템
     */
    private String stdrItmAt;
    /**
     * 아이템 번호
     */
    private String itmSn;
    /**
     * 권역코드
     */
    private String dstrctLclsfCode;
    /**
     * 브랜드 그룹 코드
     */
    private String brandGroupCode;
    /**
     * 브랜드 코드
     */
    private String brandCode;
    /**
     * 금속 기호
     */
    private String codeNm;
    /**
     * 금속 영문명
     */
    private String codeDcone;
    /**
     * 금속 심벌
     */
    private String codeChrctrRefrntwo;
    /**
     * 아이템 코드
     */
    private String itmCode;
    /**
     * 상품명
     */
    private String goodsNm;
    /**
     * 전시 상품명
     */
    private String dspyGoodsNm;
    /**
     * 삼성선물 종목코드
     */
    private String gicName;
    /**
     * 차트 접근 종류 
     */
    private String type;
    /**
     * 금속 한글명
     */
    private String codeChrctrRefrnsix;
    
	/**
	 * 평균가 여부
	 */
	private String avrgpcSleAt;
}
