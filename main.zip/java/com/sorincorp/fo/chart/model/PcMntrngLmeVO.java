package com.sorincorp.fo.chart.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * PcMntrngLmeVO.java
 * LME 차트 관련 VO 객체
 * 
 * @version
 * @since 2024. 9. 9.
 * @author srec0049
 */
@Data
@EqualsAndHashCode
public class PcMntrngLmeVO {

	/**
	 * 차트 데이터 개수
	 */
	private int chartCount;
	
	/**
	 * 차트 타입
	 */
	private String type;
	
	/**
	 * LME 차트 일시
	 */
	private String chartLmeTime;
	
	/**
	 * LME 조정 테이블 사용 여부 (Y: 사용)
	 */
	private String mdat;
	
	/**
	 * 금속 코드
	 */
	private String metalCode;
	
	/**
	 * 발생 일자
	 */
	private String occrrncDe;
	
	/**
	 * 발생 시간
	 */
	private String occrrncTime;
	
	/**
	 * LME 가격 실시간 순번
	 */
	private String lmePcRltmSn;
	
	/**
	 * LME 가격 01 분 순번
	 */
	private String lmePc01MinSn;
	
	/**
	 * LME 가격 30 분 순번
	 */
	private String lmePc30MinSn;
	
	/**
	 * LME 가격 60 분 순번
	 */
	private String lmePc60MinSn;
	
	/**
	 * LME 가격 일 순번
	 */
	private String lmePcDeSn;
	
	/**
	 * LME 가격 년월 순번
	 */
	private String lmeYyMtSn;
	
	/**
	 * LME 영업 일자
	 */
	private String lmeBsnDe;
	
	/**
	 * 시작 가격
	 */
	private java.math.BigDecimal beginPc;
	
	/**
	 * 종료 가격
	 */
	private java.math.BigDecimal endPc;
	
	/**
	 * 최고 가격
	 */
	private java.math.BigDecimal topPc;
	
	/**
	 * 최저 가격
	 */
	private java.math.BigDecimal lwetPc;
	
	/**
	 * 대비 가격
	 */
	private java.math.BigDecimal versusPc;
	
	/**
	 * 대비 비율
	 */
	private java.math.BigDecimal versusRate;
	
	/**
	 * 거래 수량
	 */
	private long delngQy;
	
	/**
	 * 삭제 일시
	 */
	private java.sql.Timestamp deleteDt;
	
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	
	/**
	 * 최초 등록 일시
	 */
	private java.sql.Timestamp frstRegistDt;
	
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	
	/**
	 * 최종 변경 일시
	 */
	private java.sql.Timestamp lastChangeDt;
}
