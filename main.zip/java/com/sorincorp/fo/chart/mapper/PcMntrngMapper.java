package com.sorincorp.fo.chart.mapper;

import java.util.List;
import java.util.Map;

import org.springframework.cache.annotation.Cacheable;

import com.sorincorp.fo.chart.model.EntrpsMetalItmStdrVO;
import com.sorincorp.fo.chart.model.ItHghnetprcPurchsPrmpcDtlVO;
import com.sorincorp.fo.chart.model.PrLmePblntfPcBasVO;
import com.sorincorp.fo.chart.model.PrMetalDisplayVO;
import com.sorincorp.fo.chart.model.PreminumInfoDto;
import com.sorincorp.fo.chart.model.PreminumSelVO;
import com.sorincorp.fo.chart.model.SelMetalVO;
import com.sorincorp.fo.ma.model.HeaderMenuVO;


public interface PcMntrngMapper {
	
	/**
	 * <pre>
	 * 기준 프리미엄 가격 데이터
	 * </pre>
	 * @date 2021. 11. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @return
	 */
	PreminumSelVO getPremiumPriceData(String metalCode);
	
	/**
	 * <pre>
	 * 기준 프리미엄 가격 데이터 함수 호출
	 * </pre>
	 * @date 2021. 11. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param preminumInfoDto
	 * @return
	 */
	PreminumSelVO getFnPremiumInfo(PreminumInfoDto preminumInfoDto);
	
	/**
	 * <pre>
	 * 프리미엄 가격 리스트
	 * </pre>
	 * @date 2021. 11. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param preminumInfoDto
	 * @return
	 */
	List<PreminumSelVO> getFnPreminumInfoList(PreminumInfoDto preminumInfoDto);
	
	/**
	 * <pre>
	 * 고정가 프리미엄 가격리스트
	 * </pre>
	 * @date 2021. 11. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @return
	 */
//	@Cacheable(cacheNames = "Preminume_Info", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
//	List<FixPreminumVO> getFixPremiumInfoList(PreminumInfoDto preminumInfoDto);
	
	/**
	 * <pre>
	 * LME 대비가격 리스트
	 * </pre>
	 * @date 2021. 11. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param prLmePblntfPcBasVO
	 * @return
	 */
	@Cacheable(cacheNames = "Lme_info", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	PrLmePblntfPcBasVO getPrLmePblntfPc(PrLmePblntfPcBasVO prLmePblntfPcBasVO);
	
	/**
	 * <pre>
	 * 판매방식에 따른 금속명을 가져온다
	 * </pre>
	 * @date 2022. 3. 14.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 3. 14.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param prMetalDisplayVo
	 * @return
	 */
	@Cacheable(cacheNames = "Preminume_Info", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	List<PrMetalDisplayVO> selectMetalDisplayList(PrMetalDisplayVO prMetalDisplayVo);
	
	/**
	 * <pre>
	 * 판매중인 금속 정보를 불러온다.
	 * </pre>
	 * @date 2022. 3. 18.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 3. 18.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 */
	List<SelMetalVO> selectSelMetalList(String metalCode, String sleMthdCode, String type ,List<String> itemMetalList);
	
	/**
	 * <pre>
	 * 월 기준의 고정가 차트 데이터를 가져온다
	 * </pre>
	 * @date 2021. 11. 1.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 1.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itHghnetprcPurchsPrmpcDtlVO
	 * @return
	 */
	@Cacheable(cacheNames = "Preminume_Info", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	List<ItHghnetprcPurchsPrmpcDtlVO> getItHghnetprcPurchsPrmpcDtlMonth(ItHghnetprcPurchsPrmpcDtlVO itHghnetprcPurchsPrmpcDtlVO);

	/**
	 * <pre>
	 * 분기 기준의 고정가 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itHghnetprcPurchsPrmpcDtlVO
	 * @return
	 */
	List<ItHghnetprcPurchsPrmpcDtlVO> getItHghnetprcPurchsPrmpcDtlQuarter(ItHghnetprcPurchsPrmpcDtlVO itHghnetprcPurchsPrmpcDtlVO);
	
	/**
	 * <pre>
	 * 분기 기준의 고정가 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itHghnetprcPurchsPrmpcDtlVO
	 * @return
	 */
	List<ItHghnetprcPurchsPrmpcDtlVO> getItHghnetprcPurchsPrmpcDtlHalfYear(ItHghnetprcPurchsPrmpcDtlVO itHghnetprcPurchsPrmpcDtlVO);

	/**
	 * <pre>
	 * 년 기준의 고정가 차트데이터를 가져온다.
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itHghnetprcPurchsPrmpcDtlVO
	 * @return
	 */
	List<ItHghnetprcPurchsPrmpcDtlVO> getItHghnetprcPurchsPrmpcDtlYear(ItHghnetprcPurchsPrmpcDtlVO itHghnetprcPurchsPrmpcDtlVO);
	
	/**
	 * <pre>
	 * 처리내용: 업체회원 판매금속 정보를 가져온다.
	 * </pre>
	 * @date 2022. 6. 27.
	 * @author srec0068
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 27.			srec0068			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<SelMetalVO> selectEntrpsSelMetalList(String metalCode, String sleMthdCode, String metalClCode, String type ,Map<String, List<String>> itemMetalList);
	
	List<HeaderMenuVO> getUpperMenuList();

	/**
	 * <pre>
	 * 처리내용: 메인 업체별 기준아이템 설정정보를 조회한다.
	 * </pre>
	 * @date 2023. 9. 25.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 25.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param MbEntrpsGradVO
	 * @return
	 * @throws Exception
	 */
	EntrpsMetalItmStdrVO getEntrpsMetalItmStdr(EntrpsMetalItmStdrVO entrpsMetalItmStdrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 로그인한 업체 기준아이템 설정를 저장한다.
	 * </pre>
	 * @date 2023. 10. 10.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 10.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param MbEntrpsGradVO
	 * @return
	 * @throws Exception
	 */
	int insertEntrpsMetalItmStdr(EntrpsMetalItmStdrVO entrpsMetalItmStdrVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 로그인한 업체 기준아이템 설정을 이력에 저장한다.
	 * </pre>
	 * @date 2023. 10. 10.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 10.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param MbEntrpsGradVO
	 * @return
	 * @throws Exception
	 */
	int insertEntrpsMetalItmStdrHst(EntrpsMetalItmStdrVO entrpsMetalItmStdrVO) throws Exception;
}
