package com.sorincorp.fo.config;

import java.util.concurrent.ThreadPoolExecutor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * ThreadPoolConfig.java
 * 쓰레드풀 이용한 멀티쓰레드 구현 클래스
 * 
 * @version
 * @since 2023. 5. 24.
 * @author srec0049
 */
@Configuration
public class ThreadPoolConfig {
	
	/** [주문] 스레드 사용 해제시간 **/
	@Value("${thread.order.keepAliveSeconds}")
	public int orderKeepAliveSeconds;
	
	/** [주문] 사용할 총 스레드 수 **/
	@Value("${thread.order.corePoolSize}")
	public int orderCorePoolSize;
	
	/** [주문] 스레드가 가득 차고 queue가 가득 찾을때 늘어나는 스레드 수 **/
	@Value("${thread.order.maxPoolSize}")
	public int orderMaxPoolSize;
	
	/** [주문] 스레드가 가득 찾을떄 대기하는 수 **/
	@Value("${thread.order.queueCapacity}")
	public int orderQueueCapacity;
	
	/** [주문] 스레드 명칭 **/
	@Value("${thread.order.threadPrefix}")
	public String orderThreadPrefix;
	
	/** [주문] 서버 강제 종료 시 대기 중인 스래드를 처리할 최대 시간 **/
	@Value("${thread.order.terminationSeconds}")
	public int orderTerminationSeconds;
	
	/** [지정가 주문] 스레드 사용 해제시간 **/
	@Value("${thread.limitOrder.keepAliveSeconds}")
	public int limitOrderKeepAliveSeconds;
	
	/** [지정가 주문] 사용할 총 스레드 수 **/
	@Value("${thread.limitOrder.corePoolSize}")
	public int limitOrderCorePoolSize;
	
	/** [지정가 주문] 스레드가 가득 차고 queue가 가득 찾을때 늘어나는 스레드 수 **/
	@Value("${thread.limitOrder.maxPoolSize}")
	public int limitOrderMaxPoolSize;
	
	/** [지정가 주문] 스레드가 가득 찾을떄 대기하는 수 **/
	@Value("${thread.limitOrder.queueCapacity}")
	public int limitOrderQueueCapacity;
	
	/** [지정가 주문] 스레드 명칭 **/
	@Value("${thread.limitOrder.threadPrefix}")
	public String limitOrderThreadPrefix;
	
	/** [지정가 주문] 서버 강제 종료 시 대기 중인 스래드를 처리할 최대 시간 **/
	@Value("${thread.limitOrder.terminationSeconds}")
	public int limitOrderTerminationSeconds;
	
	/** [지정가 그룹] 스레드 사용 해제시간 **/
	@Value("${thread.limitGroup.keepAliveSeconds}")
	public int limitGroupKeepAliveSeconds;
	
	/** [지정가 그룹] 사용할 총 스레드 수 **/
	@Value("${thread.limitGroup.corePoolSize}")
	public int limitGroupCorePoolSize;
	
	/** [지정가 그룹] 스레드가 가득 차고 queue가 가득 찾을때 늘어나는 스레드 수 **/
	@Value("${thread.limitGroup.maxPoolSize}")
	public int limitGroupMaxPoolSize;
	
	/** [지정가 그룹] 스레드가 가득 찾을떄 대기하는 수 **/
	@Value("${thread.limitGroup.queueCapacity}")
	public int limitGroupQueueCapacity;
	
	/** [지정가 그룹] 스레드 명칭 **/
	@Value("${thread.limitGroup.threadPrefix}")
	public String limitGroupThreadPrefix;
	
	/** [지정가 그룹] 서버 강제 종료 시 대기 중인 스래드를 처리할 최대 시간 **/
	@Value("${thread.limitGroup.terminationSeconds}")
	public int limitGroupTerminationSeconds;
	
	/** [가단가 자동 확정] 스레드 사용 해제시간 **/
	@Value("${thread.prvsnlAutoDcsn.keepAliveSeconds}")
	public int prvsnlAutoDcsnKeepAliveSeconds;
	
	/** [가단가 자동 확정] 사용할 총 스레드 수 **/
	@Value("${thread.prvsnlAutoDcsn.corePoolSize}")
	public int prvsnlAutoDcsnCorePoolSize;
	
	/** [가단가 자동 확정] 스레드가 가득 차고 queue가 가득 찾을때 늘어나는 스레드 수 **/
	@Value("${thread.prvsnlAutoDcsn.maxPoolSize}")
	public int prvsnlAutoDcsnMaxPoolSize;
	
	/** [가단가 자동 확정] 스레드가 가득 찾을떄 대기하는 수 **/
	@Value("${thread.prvsnlAutoDcsn.queueCapacity}")
	public int prvsnlAutoDcsnQueueCapacity;
	
	/** [가단가 자동 확정] 스레드 명칭 **/
	@Value("${thread.prvsnlAutoDcsn.threadPrefix}")
	public String prvsnlAutoDcsnThreadPrefix;
	
	/** [가단가 자동 확정] 서버 강제 종료 시 대기 중인 스래드를 처리할 최대 시간 **/
	@Value("${thread.prvsnlAutoDcsn.terminationSeconds}")
	public int prvsnlAutoDcsnTerminationSeconds;
	
	
	
	/**
	 * <pre>
	 * 처리내용: 주문 스레드 풀
	 * </pre>
	 * @date 2023. 5. 24.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 24.          srec0049         최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@Bean(value = "orderThreadPool")
	public ThreadPoolTaskExecutor orderExcutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setAllowCoreThreadTimeOut(true);
		threadPoolTaskExecutor.setKeepAliveSeconds(orderKeepAliveSeconds);	
		threadPoolTaskExecutor.setCorePoolSize(orderCorePoolSize);
		threadPoolTaskExecutor.setMaxPoolSize(orderMaxPoolSize);
		threadPoolTaskExecutor.setQueueCapacity(orderQueueCapacity);
		threadPoolTaskExecutor.setThreadNamePrefix(orderThreadPrefix);
		
		/** 최대 스레드로 최대 queue 값 만큼 증가 됫을때 처리 방법 정의 **/
		threadPoolTaskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
		/** 서버 강제 종료 시 대기하고 있는 쓰레드를 처리할지 여부 **/
		threadPoolTaskExecutor.setWaitForTasksToCompleteOnShutdown(true);
		/** 서버 강제 종료 시 대기 중인 스래드를 처리할 최대 시간 **/
		threadPoolTaskExecutor.setAwaitTerminationSeconds(orderTerminationSeconds);
		return threadPoolTaskExecutor;
	}
	
	/**
	 * <pre>
	 * 처리내용: 지정가 주문 스레드 풀
	 * </pre>
	 * @date 2023. 5. 24.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 24.          srec0049         최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@Bean(value = "limitOrderThreadPool")
	public ThreadPoolTaskExecutor limitOrderExcutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setAllowCoreThreadTimeOut(true);
		threadPoolTaskExecutor.setKeepAliveSeconds(limitOrderKeepAliveSeconds);	
		threadPoolTaskExecutor.setCorePoolSize(limitOrderCorePoolSize);
		threadPoolTaskExecutor.setMaxPoolSize(limitOrderMaxPoolSize);
		threadPoolTaskExecutor.setQueueCapacity(limitOrderQueueCapacity);
		threadPoolTaskExecutor.setThreadNamePrefix(limitOrderThreadPrefix);
		
		/** 최대 스레드로 최대 queue 값 만큼 증가 됫을때 처리 방법 정의 **/
		threadPoolTaskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
		/** 서버 강제 종료 시 대기하고 있는 쓰레드를 처리할지 여부 **/
		threadPoolTaskExecutor.setWaitForTasksToCompleteOnShutdown(true);
		/** 서버 강제 종료 시 대기 중인 스래드를 처리할 최대 시간 **/
		threadPoolTaskExecutor.setAwaitTerminationSeconds(limitOrderTerminationSeconds);
		return threadPoolTaskExecutor;
	}
	
	/**
	 * <pre>
	 * 처리내용: 지정가 그룹 스레드 풀
	 * </pre>
	 * @date 2023. 5. 24.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 24.          srec0049         최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@Bean(value = "limitGroupThreadPool")
	public ThreadPoolTaskExecutor limitGroupExcutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setAllowCoreThreadTimeOut(true);
		threadPoolTaskExecutor.setKeepAliveSeconds(limitGroupKeepAliveSeconds);	
		threadPoolTaskExecutor.setCorePoolSize(limitGroupCorePoolSize);
		threadPoolTaskExecutor.setMaxPoolSize(limitGroupMaxPoolSize);
		threadPoolTaskExecutor.setQueueCapacity(limitGroupQueueCapacity);
		threadPoolTaskExecutor.setThreadNamePrefix(limitGroupThreadPrefix);
		
		/** 최대 스레드로 최대 queue 값 만큼 증가 됫을때 처리 방법 정의 **/
		threadPoolTaskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
		/** 서버 강제 종료 시 대기하고 있는 쓰레드를 처리할지 여부 **/
		threadPoolTaskExecutor.setWaitForTasksToCompleteOnShutdown(true);
		/** 서버 강제 종료 시 대기 중인 스래드를 처리할 최대 시간 **/
		threadPoolTaskExecutor.setAwaitTerminationSeconds(limitGroupTerminationSeconds);
		return threadPoolTaskExecutor;
	}
	
	/**
	 * <pre>
	 * 처리내용: 가단가 자동 확정 스레드 풀
	 * </pre>
	 * @date 2024. 11. 13.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 13.          srec0049         최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@Bean(value = "prvsnlAutoDcsnThreadPool")
	public ThreadPoolTaskExecutor prvsnlAutoDcsnExcutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setAllowCoreThreadTimeOut(true);
		threadPoolTaskExecutor.setKeepAliveSeconds(prvsnlAutoDcsnKeepAliveSeconds);	
		threadPoolTaskExecutor.setCorePoolSize(prvsnlAutoDcsnCorePoolSize);
		threadPoolTaskExecutor.setMaxPoolSize(prvsnlAutoDcsnMaxPoolSize);
		threadPoolTaskExecutor.setQueueCapacity(prvsnlAutoDcsnQueueCapacity);
		threadPoolTaskExecutor.setThreadNamePrefix(prvsnlAutoDcsnThreadPrefix);
		
		/** 최대 스레드로 최대 queue 값 만큼 증가 됫을때 처리 방법 정의 **/
		threadPoolTaskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
		/** 서버 강제 종료 시 대기하고 있는 쓰레드를 처리할지 여부 **/
		threadPoolTaskExecutor.setWaitForTasksToCompleteOnShutdown(true);
		/** 서버 강제 종료 시 대기 중인 스래드를 처리할 최대 시간 **/
		threadPoolTaskExecutor.setAwaitTerminationSeconds(prvsnlAutoDcsnTerminationSeconds);
		return threadPoolTaskExecutor;
	}
	
}
