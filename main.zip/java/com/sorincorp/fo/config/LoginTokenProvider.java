package com.sorincorp.fo.config;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.time.Duration;
import java.util.Date;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseCookie;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.login.model.Account;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * JWT Token을 생성하고 Token의 유효성을 체크하는 Class
 * @version
 * @since 2021. 7. 7.
 * @author srec0012
 */
@RequiredArgsConstructor
@Component
@Slf4j
public class LoginTokenProvider {
	/**
	 * JWT Token을 위한 Secret Key. hmacShaKey는 256 byte 이상을 요구. 한글 11자, 영문 32자 이상으로 지정
	 */
	private String secretKey = CommonConstants.JWT_SECRET_KEY;

	/**
	 * <pre>
	 * Secret Key를 안호화하여 JWT Token의 Key로 사용한다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param sceretKey
	 * @return
	 */
	public Key getSigningKey(String sceretKey) {
		byte[] keyBytes = secretKey.getBytes(StandardCharsets.UTF_8);
		return Keys.hmacShaKeyFor(keyBytes);
	}
	
	/**
	 * <pre>
	 * JWT Token에 등록되어 있는 Payload 정보(Claims)를 모두 읽어온다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param token
	 * @return
	 * @throws ExpiredJwtException
	 */
	public Claims extractAllClaims(String token) throws ExpiredJwtException {
		return Jwts.parserBuilder()
				.setSigningKey(getSigningKey(secretKey))
				.build()
				.parseClaimsJws(token)
				.getBody();
	}
	
	/**
	 * <pre>
	 * JWT Token에 등록되어 있는 Username을 조회한다. Token의 유효성 체크에 사용한다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param token
	 * @return
	 */
	public String getUsername(String token) {
		return extractAllClaims(token).get("username", String.class);
	}
	
	/**
	 * <pre>
	 * Token의 유효기간이 만료되었는지 확인한다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param token
	 * @return
	 */
	public Boolean isTokenExpired(String token) {
		try {
			final Date expiration = extractAllClaims(token).getExpiration();
			return expiration.before(new Date());
		} catch(Exception e) {
			return false;
		}
	}
	
	/**
	 * <pre>
	 * Access Token을 생성한다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 */
	public String generateAccessToken(Account account, String username) {
		return doGenerateToken(account, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND, username);
	}

    /**
     * <pre>
     * (구매입찰) Access Token을 생성한다.
     * </pre>
     * @date 2023. 8. 25.
     * @author srec0077
     * @history 
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 8. 25.          srec0077            최초작성
     * ------------------------------------------------
     * @param bdAccount
     * @return
     */
    public String generateBdAccessToken(BdAccount bdAccount, String username) {
        return doGenerateBdToken(bdAccount, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND, username);
    }
	
	/**
	 * <pre>
	 * Refresh Token을 생성한다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 */
	public String generateRefreshToken(String username) {
		return doGenerateToken(null, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND, username);
	}

    /**
     * <pre>
     * (구매입찰) Refresh Token을 생성한다.
     * </pre>
     * @date 2023. 8. 25.
     * @author srec0077
     * @history 
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 8. 25.          srec0077            최초작성
     * ------------------------------------------------
     * @param bdAccount
     * @return
     */
    public String generateBdRefreshToken(String username) {
        return doGenerateBdToken(null, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND, username);
    }

	/**
	 * <pre>
	 * JWT Token을 생성한다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @param expireTime
	 * @return
	 */
	public String doGenerateToken(Account account, long expireTime, String username) {
		Claims claims = Jwts.claims();
		claims.put("username", username);
		
		if (account != null) {
			claims.put("account", account);
		} else {
			claims.put("account", "");
		}
		
		Date now = new Date();
		
		String jwt = Jwts.builder()
				.setClaims(claims)
				.setIssuedAt(now)
				.setExpiration(new Date(now.getTime() + expireTime))
				.signWith(getSigningKey(secretKey), SignatureAlgorithm.HS256)
				.compact();
		
		return jwt;
	}
	
	public String generateSmsToken(String authNum) {
		Claims claims = Jwts.claims();
		claims.put("username", authNum);
		
		Date now = new Date();
		
		String jwt = Jwts.builder()
				.setClaims(claims)
				.setIssuedAt(now)
				.setExpiration(new Date(now.getTime() + CommonConstants.SMS_TOKEN_VALIDATION_SECOND))
				.signWith(getSigningKey(secretKey), SignatureAlgorithm.HS256)
				.compact();
		
		return jwt;
	}
	
    /**
     * <pre>
     * (구매입찰) JWT Token을 생성한다.
     * </pre>
     * @date 2023. 8. 25.
     * @author srec0077
     * @history 
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 8. 25.          srec0077            최초작성
     * ------------------------------------------------
     * @param bdAccount
     * @param expireTime
     * @return
     */
	public String doGenerateBdToken(BdAccount account, long expireTime, String username) {
        Claims claims = Jwts.claims();
        claims.put("username", username);
        
        if (account != null) {
            claims.put("bdAccount", account);
        } else {
            claims.put("bdAccount", "");
        }
        
        Date now = new Date();
        
        String jwt = Jwts.builder()
                .setClaims(claims)
                .setIssuedAt(now)
                .setExpiration(new Date(now.getTime() + expireTime))
                .signWith(getSigningKey(secretKey), SignatureAlgorithm.HS256)
                .compact();
        
        return jwt;
    }
	
	/**
	 * <pre>
	 * Token의 유효성을 확인한다. Username과 만료여부를 확인.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param token
	 * @param userDetails
	 * @return
	 */
	public Boolean validateToken(String token, UserDetails userDetails) {
		final String username = getUsername(token);
		return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
	}
	
	/**
	 * <pre>
	 * Token을 Cookie에 저장한다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param cookieName
	 * @param value
	 * @param expireTime
	 * @return
	 */
	public Cookie createCookie(String cookieName, String value, long expireTime) {
		Cookie token = new Cookie(cookieName, value);
		token.setHttpOnly(true);
		token.setMaxAge((int)expireTime/1000);
		token.setPath("/");

		return token;
	}
	
	/**
	 * <pre>
	 * Cookie에 값을 저장하여 생성한다..(sameSite,secure 설정)
	 * </pre>
	 * @date 2021. 8. 4.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 4.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param cookieName
	 * @param value
	 * @param expireTime
	 * @return
	 */
	public ResponseCookie createSecureCookie(String cookieName, String value, long expireTime) {
		ResponseCookie cookie = ResponseCookie.from(cookieName, value) // key & value
				.httpOnly(true)		// prohibit js reading
//				.secure(true)		// also transmit under http
//				.domain(CommonConstants.SERVER_DOMAIN)// domain name
				.path("/")			// path
				.maxAge(Duration.ofMillis(expireTime))	// Expires in 1 hour
//				.sameSite("Lax")	// In most cases, third-party cookies are not sent, except for Get requests that navigate to the target URL
				.build()
				;
		log.debug("CommonConstants.SERVER_DOMAIN: " + CommonConstants.SERVER_DOMAIN);
		return cookie;
	}
	
	
	/**
	 * <pre>
	 * Cookie에서 Token 값을 읽어온다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param cookieName
	 * @return
	 */
	public Cookie getCookie(HttpServletRequest request, String cookieName) {
		final Cookie[] cookies = request.getCookies();
		if ( cookies == null ) return null;
		
		for ( Cookie cookie : cookies ) {
			if ( cookie.getName().equals(cookieName) ) {
				return cookie;
			}
		}
		
		return null;
	}
}
