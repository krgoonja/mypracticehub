package com.sorincorp.fo.config;

import java.util.Optional;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.login.service.AccountServiceImpl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@RequiredArgsConstructor
public class UserInfoUtil {
	
	@Autowired
	private LoginTokenProvider loginTokenProvider;
	
	@Autowired
	private AccountServiceImpl accountService;
	
	Authentication auth = null;
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 정보를 얻는다.
	 * </pre>
	 * @date 2021. 8. 2.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @throws Exception
	 */
	public Account getAccountInfo() {
	    Account account = null;
	    RequestAttributes requestAtt = RequestContextHolder.getRequestAttributes();
	    Cookie accessCookie = null;
        try{
            if(requestAtt != null) {
                accessCookie = loginTokenProvider.getCookie(((ServletRequestAttributes)requestAtt).getRequest(), CommonConstants.ACCESS_TOKEN_NAME);
            } 
            
            if(accessCookie != null && loginTokenProvider.isTokenExpired(accessCookie.getValue())) {
                return (Account) accountService.loadUserByUsername(accessCookie.getValue());
            } else {
                auth = SecurityContextHolder.getContext().getAuthentication();
                if(SecurityContextHolder.getContext().getAuthentication() != null) {
                    if ( !"anonymousUser".equals(auth.getPrincipal())) account = (Account)auth.getPrincipal();
                }
                return account;
            }
        
        } catch(Exception e) {
            log.error("UserInfoUtil getAccountInfo Error =====>>> {}", ExceptionUtils.getStackTrace(e));
            return null;
        }	    
	}
	
	   
    /**
     * <pre>
     * (구매입찰) 로그인 되어 있는 계정의 정보를 얻는다.
     * </pre>
     * @date 2023. 8. 25.
     * @author srec0077
     * @history 
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 8. 25.          srec0077            최초작성
     * ------------------------------------------------
     * @param request
     * @throws Exception
     */
    public BdAccount getBdAccountInfo() {
            BdAccount account = null;
            RequestAttributes requestAtt = RequestContextHolder.getRequestAttributes();
            Cookie accessCookie = null;
            try{
                if(requestAtt != null) {
                    accessCookie = loginTokenProvider.getCookie(((ServletRequestAttributes)requestAtt).getRequest(), CommonConstants.BID_ACCESS_TOKEN_NAME);
                } 
                
                if(accessCookie != null) {
                    return (BdAccount) accountService.loadBdUserByUsername(accessCookie.getValue());
                } else {
                    auth = SecurityContextHolder.getContext().getAuthentication();
                    if(SecurityContextHolder.getContext().getAuthentication() != null) {
                        if ( !"anonymousUser".equals(auth.getPrincipal())) account = (BdAccount)auth.getPrincipal();
                }
                return account;
            }
        
        } catch(Exception e) {
            log.error("UserInfoUtil getBdAccountInfo Error =====>>> {}", ExceptionUtils.getStackTrace(e));
            return null;
        }       
    }
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 회명명을 구한다.
	 * </pre>
	 * @date 2021. 8. 2.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 */
	public String getMemberName() {
		return Optional.ofNullable(getAccountInfo())
//		return Optional.ofNullable(getAccountInfo(request))
				.map(Account::getName)
				.orElse(null);
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 회원사 번호를 구한다.
	 * </pre>
	 * @date 2021. 8. 2.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 */
	public String getEntripsNo() {
		return Optional.ofNullable(getAccountInfo())
						.map(Account::getEntrpsNo)
						.orElse(null);
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 회원 구분 정보를 구한다.
	 * 01: 회원사 사용자, 02: 간편 로그인 사용자
	 * </pre>
	 * @date 2021. 8. 2.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.		srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 */
	public String getType() {
		return Optional.ofNullable(getAccountInfo())
						.map(Account::getType)
						.orElse(null);
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 회명 Email을 구한다.
	 * </pre>
	 * @date 2021. 8. 2.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.    	  srec0012			    최초작성
	 * ------------------------------------------------
	 * @param request
	 */
	public String getMemberEmail() {
		return Optional.ofNullable(getAccountInfo())
				.map(Account::getEmail)
				.orElse(null);
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 Secode를 구한다.
	 * </pre>
	 * @date 2021. 8. 2.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 */
	public String getMemberSecode() {
		return Optional.ofNullable(getAccountInfo())
				.map(Account::getSecode)
				.orElse(null);
	}
	
	public String getAuthorNo() {
		return Optional.ofNullable(getAccountInfo())
				.map(Account::getAuthorNo)
				.orElse(null);
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 정보를 얻는다.
	 * </pre>
	 * @date 2021. 7. 29.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 29.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @throws Exception
	 */
	public Account getAccountInfo(HttpServletRequest request) {
		try{
			Cookie accessCookie = loginTokenProvider.getCookie(request, CommonConstants.ACCESS_TOKEN_NAME);
	    	
			if(accessCookie != null && loginTokenProvider.isTokenExpired(accessCookie.getValue())) {
				return (Account) accountService.loadUserByUsername(accessCookie.getValue());
			} else {
				return getAccountInfo();
			}
		} catch(Exception e) {
			log.error("UserInfoUtil getAccountInfo Error =====>>> {}", ExceptionUtils.getStackTrace(e));
			return null;
		}
	}
	
    /**
     * <pre>
     * (구매입찰) 로그인 되어 있는 계정의 정보를 얻는다.
     * </pre>
     * @date 2023. 8. 25.
     * @author srec0077
     * @history 
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 8. 25.          srec0077            최초작성
     * ------------------------------------------------
     * @param request
     * @throws Exception
     */
    public BdAccount getBdAccountInfo(HttpServletRequest request) {
        try{
            Cookie accessCookie = loginTokenProvider.getCookie(request, CommonConstants.BID_ACCESS_TOKEN_NAME);
            
            if(accessCookie != null) {
                return (BdAccount) accountService.loadBdUserByUsername(accessCookie.getValue());
            } else {
                return getBdAccountInfo();
            }
        } catch(Exception e) {
            log.error("UserInfoUtil getBdAccountInfo Error =====>>> {}", ExceptionUtils.getStackTrace(e));
            return null;
        }
    }
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 회원명을 구한다.
	 * </pre>
	 * @date 2021. 7. 29.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 29.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 */
	public String getMemberName(HttpServletRequest request) {
		return Optional.ofNullable(getAccountInfo(request))
//		return Optional.ofNullable(getAccountInfo(request))
				.map(Account::getName)
				.orElse(null);
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 회원사 번호를 구한다.
	 * </pre>
	 * @date 2021. 7. 29.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 29.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 */
	public String getEntripsNo(HttpServletRequest request) {
		return Optional.ofNullable(getAccountInfo(request))
						.map(Account::getEntrpsNo)
						.orElse(null);
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 회원 구분 정보를 구한다.
	 * 01: 회원사 사용자, 02: 간편 로그인 사용자
	 * </pre>
	 * @date 2021. 7. 29.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 29.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 */
	public String getType(HttpServletRequest request) {
		return Optional.ofNullable(getAccountInfo(request))
						.map(Account::getType)
						.orElse(null);
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 회명 Email을 구한다.
	 * </pre>
	 * @date 2021. 7. 30.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 30.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 */
	public String getMemberEmail(HttpServletRequest request) {
		return Optional.ofNullable(getAccountInfo(request))
				.map(Account::getEmail)
				.orElse(null);
	}
	
	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 Secode를 구한다.
	 * </pre>
	 * @date 2021. 8. 2.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 2.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 */
	public String getMemberSecode(HttpServletRequest request) {
		return Optional.ofNullable(getAccountInfo(request))
				.map(Account::getSecode)
				.orElse(null);
	}

	/**
	 * <pre>
	 * 로그인 되어 있는 계정의 회원사이름을 구한다.
	 * </pre>
	 * @date 2021. 7. 29.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 29.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 */
	public String getEntrpsnmKorean(HttpServletRequest request) {
		return Optional.ofNullable(getAccountInfo(request))
						.map(Account::getEntrpsnmKorean)
						.orElse(null);
	}

}
