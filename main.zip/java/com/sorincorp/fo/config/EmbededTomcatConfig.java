package com.sorincorp.fo.config;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.catalina.LifecycleException;
import org.apache.catalina.valves.rewrite.RewriteValve;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class EmbededTomcatConfig implements WebServerFactoryCustomizer<TomcatServletWebServerFactory> {
	
	@Bean 
	public TomcatServletWebServerFactory servletContainerFactory() {
		TomcatServletWebServerFactory factory = new TomcatServletWebServerFactory();
		factory.addContextValves(new RewriteValve());
		return factory;
	}
	
	@Override
    public void customize(TomcatServletWebServerFactory factory) {

        final RewriteValve valve = new RewriteValve() {

            @Override
            protected synchronized void startInternal() throws LifecycleException {
                super.startInternal();

                try {
                    InputStream resource = new ClassPathResource("rewrite.config").getInputStream();

                    InputStreamReader resourceReader = new InputStreamReader(resource);
                    BufferedReader buffer = new BufferedReader(resourceReader);

                    parse(buffer);

                } catch (IOException e) {
                    log.error(ExceptionUtils.getStackTrace(e));
                }
            }
        };

        valve.setEnabled(true);

        factory.addContextValves(valve);
    }
}
