package com.sorincorp.fo.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.FilterChain;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.util.PatternMatchUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.login.service.AccountServiceImpl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public class LoginAuthenticationFilter extends OncePerRequestFilter {
	private final LoginTokenProvider loginTokenProvider;
	private final AccountServiceImpl accountService;
	private final RedisUtil redisUtil;
	
	private final CommonCodeService commonCodeService;
	/**
	 * 로그인이 필요한 URL 지정
	 */
	Map<String, CommonCodeVO> loingNeedPageMap = null;
	List<String> loginNeedPage = null;
	
	
	private static final String[] whitelist = {"/css/*", "/fonts/*", "/guide/*", "/images/*", "/js/*", "/error/*", "/properties/*"};
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		String requestURI = httpRequest.getRequestURI();

		String accessCookieJwtToken = null;
		String refreshCookieJwtToken = null;
		boolean isLoginRequiredUrl = false;

		// Access Token, Refresh Token을 가져온다.
		Cookie accessCookie = requestURI.contains("/bid")? loginTokenProvider.getCookie(request, CommonConstants.BID_ACCESS_TOKEN_NAME) : loginTokenProvider.getCookie(request, CommonConstants.ACCESS_TOKEN_NAME);
		Cookie refreshCookie = requestURI.contains("/bid")? loginTokenProvider.getCookie(request, CommonConstants.BID_REFRESH_TOKEN_NAME) : loginTokenProvider.getCookie(request, CommonConstants.REFRESH_TOKEN_NAME);
		
		if (isLoginCheckPath(requestURI)) {
			isLoginRequiredUrl = true;
			// Token의 유효기간과 Cookie의 유효기간이 동일하기 때문에 Cookie의 유효기간이 만료되면 Token의 유효기간되 만료된 것이다.
			if (accessCookie != null) {
				try {
					accessCookieJwtToken = accessCookie.getValue();
					String accessUserId = loginTokenProvider.getUsername(accessCookieJwtToken);
					String accessRedisJwtToken = requestURI.contains("/bid") ? (String)redisUtil.getData(CommonConstants.REDIS_KEY_BID_ACCESS + accessUserId) : (String)redisUtil.getData(CommonConstants.REDIS_KEY_FO_ACCESS + accessUserId);
					UserDetails userDetails = requestURI.contains("/bid") ? accountService.loadBdUserByUsername(accessCookieJwtToken) : accountService.loadUserByUsername(accessCookieJwtToken);
					
					// access Token 쿠키값과 레디스 값이 같고
					if(accessCookieJwtToken.equals(accessRedisJwtToken) && accessUserId != null && userDetails != null 
							&& loginTokenProvider.validateToken(accessCookieJwtToken, userDetails)) {
						// Access Token이 유효하면 로그인 정보을 SecurityContextHolder에 저장한다.
						UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
						usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
						SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);	
					} else {
						accessCookieJwtToken = null;
					}
				} catch (Exception e) {
					accessCookie = null;
					accessCookieJwtToken = null;
				}	
			} else {
				accessCookieJwtToken = null;
			}
			
			// Token의 유효기간과 Cookie의 유효기간이 동일하기 때문에 Cookie의 유효기간이 만료되면 Token의 유효기간되 만료된 것이다
			if ( accessCookieJwtToken == null && refreshCookie != null ) {
				try {
					refreshCookieJwtToken = refreshCookie.getValue();
					String refreshUserId = loginTokenProvider.getUsername(refreshCookieJwtToken);
					String refreshRedisJwtToken = requestURI.contains("/bid") ? (String)redisUtil.getData(CommonConstants.REDIS_KEY_BID_REFRESH + refreshUserId) : (String)redisUtil.getData(CommonConstants.REDIS_KEY_FO_REFRESH + refreshUserId);
					
					// refresh Token 쿠키값과 레디스 값이 같고
					if(refreshUserId != null && refreshCookieJwtToken.equals(refreshRedisJwtToken)) {
						// Refresh Token이 유효하면 로그인 정보을 SecurityContextHolder에 저장한다.
					    if(requestURI.contains("/bid")) {
	                       // 구매입찰
					        BdAccount account = accountService.selectBdAccount(refreshUserId);
	                        account.setBidMberSecretNo(null); //Token 생성전에 패스워드정보를 제외한다.
					        
	                        if(account.getBidMberId() != null) {
	                            String newAccessToken = loginTokenProvider.generateBdAccessToken(account, account.getBidMberId());
	                            redisUtil.setDataExpire(CommonConstants.REDIS_KEY_BID_ACCESS + account.getBidMberId(), newAccessToken, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND); 
	                            
	                            ResponseCookie newAccessCookie = loginTokenProvider.createSecureCookie(CommonConstants.BID_ACCESS_TOKEN_NAME, newAccessToken, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);
	                            String accessCookieStr = newAccessCookie.toString().replaceAll("[\\r\\n]", "");
	                            response.addHeader(HttpHeaders.SET_COOKIE, accessCookieStr);
	                            
	                            // 신규Access Token 생성시 로그인 정보을 SecurityContextHolder에 저장한다.
	                            UserDetails userDetails = accountService.loadBdUserByUsername(newAccessCookie.getValue());
	                            UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
	                            usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
	                            SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
	                        } else {
	                            refreshCookieJwtToken = null;
	                            deleteCookieProcess(request, response, filterChain);
	                        }
	                        
					    } else {
					    // 케이지트레이딩
						Account account = accountService.selectAccount(refreshUserId);
						account.setPassword(null); //Token 생성전에 패스워드정보를 제외한다.
						
						if(account.getId() != null) {
							String newAccessToken = loginTokenProvider.generateAccessToken(account, account.getId());
							redisUtil.setDataExpire(CommonConstants.REDIS_KEY_FO_ACCESS + account.getId(), newAccessToken, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);	
							
							ResponseCookie newAccessCookie = loginTokenProvider.createSecureCookie(CommonConstants.ACCESS_TOKEN_NAME, newAccessToken, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);
							String accessCookieStr = newAccessCookie.toString().replaceAll("[\\r\\n]", "");
							response.addHeader(HttpHeaders.SET_COOKIE, accessCookieStr);
							
							// 신규Access Token 생성시 로그인 정보을 SecurityContextHolder에 저장한다.
							UserDetails userDetails = accountService.loadUserByUsername(newAccessCookie.getValue());
							UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
							usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
							SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
						} else {
							refreshCookieJwtToken = null;
							deleteCookieProcess(request, response, filterChain);
						}

                      }
					} else {
						refreshCookieJwtToken = null;
						deleteCookieProcess(request, response, filterChain);
					}
				} catch (Exception e) {
					log.error(ExceptionUtils.getStackTrace(e));
					refreshCookieJwtToken = null;
					deleteCookieProcess(request, response, filterChain);
				}		
			} else {
				refreshCookieJwtToken = null;
			}
		}

		
		try {
			if (isLoginRequiredUrl == true && null == accessCookieJwtToken && null == refreshCookieJwtToken) {
				newLoginProcess(request, response, filterChain);
			} else {
				filterChain.doFilter(request, response);
			}
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		}
	}
	
	private void deleteCookieProcess(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
		// Access Token Cookie 조회
		//Cookie accessCookie = loginTokenProvider.getCookie(request, CommonConstants.ACCESS_TOKEN_NAME);
		ResponseCookie responseAccesstoken = loginTokenProvider.createSecureCookie(request.getRequestURI().contains("/bid") ? CommonConstants.BID_ACCESS_TOKEN_NAME : CommonConstants.ACCESS_TOKEN_NAME , null, 0);
		response.addHeader(HttpHeaders.SET_COOKIE, responseAccesstoken.toString());

		//Cookie refreshCookie = loginTokenProvider.getCookie(request, CommonConstants.REFRESH_TOKEN_NAME);
		ResponseCookie responseRefreshToken = loginTokenProvider.createSecureCookie(request.getRequestURI().contains("/bid") ? CommonConstants.BID_REFRESH_TOKEN_NAME :CommonConstants.REFRESH_TOKEN_NAME, null, 0);
		response.addHeader(HttpHeaders.SET_COOKIE, responseRefreshToken.toString());
		
		//newLoginProcess(request, response, filterChain);
	}
	
	private void newLoginProcess(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
		try {
			//CSS나 Font등 파일을 요청하는 경우 제외 처리
			//loingNeedPageMap,loginNeedPage를 값이 없는경우 로만 처리한경우 공통코드가 수정되면 반영 불가함
			if (request.getRequestURI().indexOf(".") == -1) {  
	
				loingNeedPageMap = commonCodeService.getSubCodesRetVo(CommonConstants.FO_LOGIN_NEED_PAGE_CODE);
				
				loginNeedPage = loingNeedPageMap.values().stream()
						.map(data->data.getCodeNm())
						.collect(Collectors.toCollection(ArrayList::new));
	
				if (loginNeedPage.indexOf(request.getRequestURI()) > -1) {
	
					if(request.getHeader("data") != null && !request.getHeader("data").isEmpty()) {
						JSONParser parser = new JSONParser();
						Object obj = parser.parse(request.getHeader("data"));
						JSONObject jsonObj = (JSONObject) obj;
						request.setAttribute("refererData",jsonObj);
					}
					
					request.setAttribute("originAddress", request.getRequestURI());
					request.getServletContext().getRequestDispatcher("/account/login").forward(request, response);
				} else {
					filterChain.doFilter(request, response);
				}
			} else {
				filterChain.doFilter(request, response);
			}
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		}
	}
	
    /**
     * whiteList의 경우 인증 체크를 안하도록 한다.
     */
    private boolean isLoginCheckPath(String requestURI) {
        return !PatternMatchUtils.simpleMatch(whitelist, requestURI);
    }	
}
