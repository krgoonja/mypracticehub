package com.sorincorp.fo.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.fo.comm.service.RedisSubscriberFo;


@Service
public class InitConfig {

	@Autowired
	RedisUtil redisUtil;

	@Autowired
	RedisPubSubService redisPubSubService;

	@Autowired
	RedisSubscriberFo redisSubscriberFo;

	@Value("${metalCode.list}")
	private List<String> metalCodeList;

	@Value("${redisPubsub.uri.sel}")
	private String selPcUri;

	@Value("${redisPubsub.uri.lme}")
	private String lmePcUri;

	@Value("${redisPubsub.uri.sidecar}")
	private String sidecarUri;

	@Value("${redisPubsub.uri.wishAlram}")
	private String wishAlramUri;

	@Value("${redisPubsub.uri.fx}")
	private String fxpcUri;

	@Value("${redisPubsub.crncyCode.KRW}")
	private String fxpcKRW;

	@Value("${redisPubsub.uri.restTime}")
	private String restTimeUri;

	@Value("${redisPubsub.uri.startLmeData}")
	private String startLmeDataUri;

	@Value("${redisPubsub.uri.spread}")
	private String spreadUri;

	@Value("${redisPubsub.uri.invntry}")
	private String invntryUri;
	
	@Value("${redisPubsub.uri.selpcAll}")
	private String selpcAllUri;

	@Bean(initMethod="init")
	public void InitSettings() throws Exception{
		// 실시간 환율
		if(!redisPubSubService.isExistChannel(fxpcUri + "/" + fxpcKRW)) {
			redisPubSubService.createChannel(fxpcUri + "/" + fxpcKRW, redisSubscriberFo);
		}

		//금속코드별 판매가격 수신
		for (String metalCode : metalCodeList) {
			// 실시간 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode)) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode, redisSubscriberFo);
			}
			// 1분 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/01")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/01", redisSubscriberFo);
			}
			// 30분 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/30")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/30", redisSubscriberFo);
			}
			// 60분 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/60")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/60", redisSubscriberFo);
			}
			// 일 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/DE")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/DE", redisSubscriberFo);
			}
			// 주 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/WK")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/WK", redisSubscriberFo);
			}
			// 월 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/MT")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/MT", redisSubscriberFo);
			}
			// 분기 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/QU")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/QU", redisSubscriberFo);
			}
			// 년 판매 가격
			if(!redisPubSubService.isExistChannel(selPcUri + "/" + metalCode + "/YY")) {
				redisPubSubService.createChannel(selPcUri + "/" + metalCode + "/YY", redisSubscriberFo);
			}
			
			if(!redisPubSubService.isExistChannel(selpcAllUri + "/" + metalCode)) {
 				redisPubSubService.createChannel(selpcAllUri + "/" + metalCode, redisSubscriberFo);
			}
			
			if(!redisPubSubService.isExistChannel(lmePcUri + "/" + metalCode)) {
 				redisPubSubService.createChannel(lmePcUri + "/" + metalCode, redisSubscriberFo);
			}
		}

		// 사이드카
		if(!redisPubSubService.isExistChannel(sidecarUri)) {
			redisPubSubService.createChannel(sidecarUri, redisSubscriberFo);
		}
		// 희망가
		if(!redisPubSubService.isExistChannel(wishAlramUri)) {
			redisPubSubService.createChannel(wishAlramUri, redisSubscriberFo);
		}
		// lme 시작
		if(!redisPubSubService.isExistChannel(startLmeDataUri)) {
			redisPubSubService.createChannel(startLmeDataUri, redisSubscriberFo);
		}
		// lme 휴무시간 실시간 적용
		if(!redisPubSubService.isExistChannel(restTimeUri)) {
			redisPubSubService.createChannel(restTimeUri, redisSubscriberFo);
		}
		if(!redisPubSubService.isExistChannel(spreadUri)) {
			redisPubSubService.createChannel(spreadUri, redisSubscriberFo);
		}

		// 금속코드별 재고데이터 수신
		for (String metalCode : metalCodeList) {
			if(!redisPubSubService.isExistChannel(invntryUri + "/" + metalCode)) {
				redisPubSubService.createChannel(invntryUri + "/" + metalCode, redisSubscriberFo);
			}
		}
	}

	@Value("${spring.fo.domain}")
	private void setServerDomain(String domain) {
//	System.out.println("---------------------------------------------------------------------------------------------------------"+domain);
	CommonConstants.SERVER_DOMAIN = domain;
	}
}
