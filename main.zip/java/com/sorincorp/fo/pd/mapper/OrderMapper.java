package com.sorincorp.fo.pd.mapper;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.data.repository.query.Param;

import com.sorincorp.comm.order.model.CnAvrgpcFshgBasVO;
import com.sorincorp.comm.order.model.CnAvrgpcFtrsBasVO;
import com.sorincorp.comm.order.model.CnCntrctOrderBasVO;
import com.sorincorp.comm.order.model.CommOrOrderFtrsBasVO;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.comm.order.model.ItPurchsInfoBas;
import com.sorincorp.comm.order.model.MbDlvrgBasVO;
import com.sorincorp.comm.order.model.OrPricingBasVO;
import com.sorincorp.comm.order.model.OrderEntrpsSetleMnVO;
import com.sorincorp.comm.order.model.OrderMbEntrpsMlgInfoDtlVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.fo.ev.model.PromtnNewYearVO;
import com.sorincorp.fo.pd.model.CredtCdtlnInfoVO;
import com.sorincorp.fo.pd.model.FixingPcOrderPossWtCeckVO;
import com.sorincorp.fo.pd.model.ItemDtlInfoVO;
import com.sorincorp.fo.pd.model.LimitOrderModel;
import com.sorincorp.fo.pd.model.OrGrntyInfoVO;
import com.sorincorp.fo.pd.model.OrUntpcDcsnDeChangeDtlVO;
import com.sorincorp.fo.pd.model.OrderEtcPrice;
import com.sorincorp.fo.pd.model.OrderItWrtmStdrAmoutMangeVO;
import com.sorincorp.fo.pd.model.OrderLimitReceiptVO;
import com.sorincorp.fo.pd.model.OrderWrhousVO;
import com.sorincorp.fo.pd.model.SettleSttusDeVO;

/**
 * OrderMapper.java
 * 주문 Mapper 인터페이스
 * @version
 * @since 2022. 9. 21.
 * @author srec0049
 */
public interface OrderMapper {

	/**
	 * <pre>
	 * 처리내용: 주문 프라이싱 정보 가져오기
	 * </pre>
	 * @date 2022. 9. 15.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 15.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	OrPricingBasVO selectOrPricingInfo(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원 및 업체, 배송지 정보 가져오기
	 * </pre>
	 * @date 2022. 9. 15.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 15.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	MbDlvrgBasVO selectOrMbEntrpsDlvrgInfo(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_주문 기본 정보 등록하기
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 22.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrOrderBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_주문 상세 정보 등록하기
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 22.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrOrderDtl(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_PO 정보 기본 등록하기
	 * </pre>
	 * @date 2022. 2. 25.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 25.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrPurchsInfoBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_배송지 기본 정보 등록하기
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 22.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrDlvrgBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_배송비 기본 정보 등록하기
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 22.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrDlvrfBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 상품_PO 정보 가져오기
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 22.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	ItPurchsInfoBas selectItPurchsInfoBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_주문 선물 기본 정보 등록하기
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 22.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrOrderFtrsBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_주문 선물환 기본 정보 등록하기
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 22.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrOrderFshgBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 선물 주문 응답 실패 리스트 가져오기
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 22.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	List<CommOrOrderFtrsBasVO> selectFtrsOrderResFailList(OrderModel orderModel) throws Exception;

	List<CommOrOrderFtrsBasVO> selectCancelSamsungResponse(OrderModel orderModel) throws Exception;

	/**
	 * 주문 내역 조회
	 */
	OrderLimitReceiptVO selectOrderReceipt(OrderModel orderModel) throws Exception;

	/**
	 * 지정가 주문 내역 조회
	 */
	OrderLimitReceiptVO selectLimitOrderReceipt(OrderModel orderModel) throws Exception;

	String selectBlNos(OrderModel orderModel) throws Exception;

	void insertSamsungCancel(OrderModel orderModel) throws Exception;

	void insertEwalletSetle(OrderModel orderModel) throws Exception;

	int selectSamsungFailResponse(OrderModel orderModel) throws Exception;

	void updateInvntryBlInfoBas(OrderModel orderModel) throws Exception;

	void insertInvntryBlInfoHistDtl(OrderModel orderModel) throws Exception;

	void insertBlInfoBasHst(OrderModel orderModel) throws Exception;

	List<CommOrOrderFtrsBasVO> selectSamsungWonList(OrderModel orderModel) throws Exception;

	void updateOrderMaster(OrderModel orderModel) throws Exception;

	void updateOrderDetail(OrderModel orderModel) throws Exception;

	void updateOrderDlvrf(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_주문 기본의 주문상태코드 및 주문완료일시, OMS접수 번호, 주문 실패 사유 등을 값에 따라 업데이트
	 * </pre>
	 * @date 2023. 1. 18.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 1. 18.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void updateLastOrderMaster(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_주문 기본의 주문상태코드 및 주문완료일시를 주문상태코드 조건에 따라 업데이트
	 * </pre>
	 * @date 2023. 1. 18.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 1. 18.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void updateLastOrderMasterByOrderSttusCode(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 프라이싱 테이블을 등록[프라이싱 단계 코드 : 03(결제완료)]한다.
	 * </pre>
	 * @date 2021. 11. 23.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 23.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrderPricingByStepCode(OrderModel orderModel) throws Exception;

	void updatePlusInvntryBlInfoBas(OrderModel orderModel) throws Exception;

	void updateRecoverInvntryBlInfoBas(OrderModel orderModel) throws Exception;

	OrderEtcPrice getEwalletInfo(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 내부 관리용 이월렛 잔액 가져오기
	 * </pre>
	 * @date 2023. 6. 21.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 6. 21.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	long getEwalletBlceInnerManagePrpos(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 전자상거래보증 or 케이지크레딧 한도조회 가져오기
	 * </pre>
	 * @date 2022. 6. 30.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 30.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	OrderEtcPrice getMrtggGrntyLmtInqire(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: LME 전일 종가 가져오기
	 * </pre>
	 * @date 2022. 8. 25.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 25.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @param sleMthdCode
	 * @return
	 */
	String getPreEndPc(String metalCode, String sleMthdCode);

	/**
	 * <pre>
	 * 처리내용: 구매성향등급에 따른 단계별 금액 가져오기(LME 전일 종가[케이지몰일 경우 현재 단가] 포함)
	 * </pre>
	 * @date 2022. 7. 21.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 21.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @param endPcAgo
	 * @return
	 * @throws Exception
	 */
	OrderItWrtmStdrAmoutMangeVO getStepAmountByPurchsInclnGrade(String metalCode, float endPcAgo) throws Exception;

	List<OrderWrhousVO> selectOrderReceiptWrhous(OrderModel orderModel) throws Exception;

	int getOrderEntrpsCnt(OrderModel orderModel) throws Exception;

	String selectEwalletRspnCode(OrderModel orderModel) throws Exception;

	Object selectSorinSign() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_주문 기본 이력 정보 등록하기
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 22.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrOrderBasHst(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_주문 정보 기본 이력 정보 등록하기
	 * </pre>
	 * @date 2023. 10. 30.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 30.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrOrderInfoBasHst(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_주문 평균가 상세 이력 등록하기
	 * </pre>
	 * @date 2023. 11. 21.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 21.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrOrderAvrgpcDtlHst(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_주문 상세 이력 정보 등록하기
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 22.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrOrderDtlHst(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_배송지 기본 이력 정보 등록하기
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 22.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrDlvrgBasHst(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_배송비 기본 이력 정보 등록하기
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 22.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrDlvrfBasHst(OrderModel orderModel) throws Exception;

	void insertEwalletSetleHist(OrderModel orderModel) throws Exception;

	void insertMbEntrpsMrtggLmtDtlHst(OrderModel orderModel) throws Exception;

	void insertMrtggBasHst(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: LME 사이드카 발동여부
	 * </pre>
	 * @date 2022. 2. 14.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 14.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	int chkLmeSidecar(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 환율 사이드카 발동여부
	 * </pre>
	 * @date 2022. 2. 14.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 14.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	int chkFxSidecar(OrderModel orderModel) throws Exception;

		/**
	 * <pre>
	 * 처리내용: 쿠폰 사용으로 처리
	 * </pre>
	 * @date 2023. 1. 3.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 1. 3.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param couponVO
	 * @param orderNo
	 * @param mberId
	 * @return
	 * @throws Exception
	 */
	int updateDlvrfDscntAt (String couponSeqNo, String couponDscntAmount, String orderNo, String mberId) throws Exception;

	/**
	 * <pre>
	 * 처리내용: SMS 내용 정보 가져오기
	 * </pre>
	 * @date 2022. 9. 6.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 6.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectSmsInfo(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메일 내용 정보 가져오기
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 13.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectMailInfo(OrderModel orderModel) throws Exception;

	int chkMberSeCodeByOrder(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: [상품별 하루 총 실제 주문 중량] 또는 [업체 단위 메탈코드별 하루 총 실제 주문 중량] 또는 [업체 단위 케이지크레딧 하루 총 실제 주문 중량] 가져오기
	 * </pre>
	 * @date 2022. 10. 21.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 21.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	int getTotRealOrderWt(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 당일배송 여부 체크
	 * </pre>
	 * @date 2022. 3. 8.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 3. 8.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	int chkSameDayDelivery(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 당일배송 종료 시간 가져오기
	 * </pre>
	 * @date 2022. 3. 10.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 3. 10.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	String getSameDayDeliveryCloseTime(OrderModel orderModel) throws Exception;

	int chkRestdeByDlivyRequstDe(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문 시 SMS 전송 수신자 추가 리스트 가져오기[SMS_SNDNG_GROUP_CODE:20 or 40]
	 * </pre>
	 * @date 2022. 4. 21.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 4. 21.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param smsSndngGroupCode
	 * @return
	 * @throws Exception
	 */
	List<Map<String, String>> selectReceiverList(String smsSndngGroupCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 판매단위중량(상품별) 및 최대구매가능중량(상품별) 가져오기
	 * </pre>
	 * @date 2022. 4. 8.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 4. 8.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	ItemDtlInfoVO getSleWtInfo(int itmSn) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이벤트 휴일 관리 기반 기준일에 영업 일자 만큼 계산된 날짜 리턴(기준일 포함), 리턴 대상 날짜가 휴일이면 그 다음 날짜를 리턴한다.
	 * </pre>
	 * @date 2022. 8. 1.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 1.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param settleSttusDeVO
	 * @return
	 * @throws Exception
	 */
	String getSettleSttusDe(SettleSttusDeVO settleSttusDeVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원_업체 담보 한도 상세 테이블 등록 후 업체 담보 순번 리턴
	 * </pre>
	 * @date 2022. 7. 29.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 29.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	void insertMbEntrpsMrtggLmtDtl(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_담보 기본 정보 등록
	 * </pre>
	 * @date 2022. 7. 29.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 29.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrMrtggBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_담보 기본 정보의 업체 담보 순번 값 및 주문 시점 잔여 한도 금액 추가
	 * </pre>
	 * @date 2022. 12. 9.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 09.			srec0049			최초작성
	 * 2023. 07. 06.			srec0049			주문 시점 잔여 한도 금액 추가
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void updateOrMrtggBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 증거금과 전자상거래보증 사용 권한(증거금 총 사용 여부, 전자상거래보증 또는 케이지크레딧 총 사용 여부), 증거금 신청 여부(화면단 별도 체크), 담보 보증 신청 여부(화면단 별도 체크), 연체 및 사고 건수 가져오기
		: 증거금 총 사용 여부(증거금 신청 여부, 증거금 사용 여부, 증거금 해지 여부 체크)
		: 전자상거래보증 또는 케이지크레딧 총 사용 여부(담보 보증 신청 여부, 담보 보증 사용 여부, 담보 보증 승인 여부 , 담보 보증 해지 여부 체크)
	 * </pre>
	 * @date 2022. 8. 4.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 4.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	OrderEntrpsSetleMnVO getWrtmMrtggUseAuthor(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 담보 보증 보험 요율(소수점) 가져오기
	 * </pre>
	 * @date 2022. 8. 26.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 26.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	BigDecimal getMrtggGrntyInsrncTariffDcmlpoint(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 실제발생담보매출액 가져오기
	 * </pre>
	 * @date 2022. 8. 29.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 29.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	BigDecimal getRealOccrrncMrtggRvamt(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 현재 총 마일리지 적립 금액 가져오기
	 * </pre>
	 * @date 2022. 9. 6.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 6.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	BigDecimal getNowTotMlgAccmlAmount(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원_업체 마일리지 내역 상세 등록
	 * </pre>
	 * @date 2022. 8. 29.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 29.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertMbEntrpsMlgInfoDtl(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 마일리지 적립예정에서 적립으로 변환 대상 가져오기
	 * </pre>
	 * @date 2022. 9. 1.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 1.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	List<OrderMbEntrpsMlgInfoDtlVO> selectMlgAccmlCnvrTrget(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원_업체 담보 기본의 매출 달성율 업데이트
	 * </pre>
	 * @date 2022. 8. 31.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 31.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void updateMrtggSelngAchivrt(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원_업체 담보 기본의 매출 달성율 가져오기
	 * </pre>
	 * @date 2022. 9. 2.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 2.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	BigDecimal selectMrtggSelngAchivrt(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원_업체 마일리지 내역 상세 이력 등록
	 * </pre>
	 * @date 2022. 9. 2.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 2.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertMbEntrpsMlgInfoDtlHst(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원_업체 담보 기본 이력 등록
	 * </pre>
	 * @date 2022. 9. 2.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 2.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertMbEntrpsMrtggCntrctBasHst(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 비철 CAPA 사용 여부 가져오기
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 13.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param wrhousCode
	 * @return
	 * @throws Exception
	 */
	String getNfCapaUseAt(String wrhousCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 사용 쿠폰 내역을 가져온다.
	 * </pre>
	 * @date 2022. 12. 14.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 14.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	List<CouponVO> selectCouponSeqNo(String[] couponSeqNoArray, String couponDplctUseLmttQyAt, String entrpsNo, String dscntExpectDlvrf, int orderWt, String [] couponSnArray) throws Exception;
	/**
	 * <pre>
	 * 상시할인 재발행 여부에 따라 쿠폰 재발급
	 * </pre>
	 * @date 2024. 01. 11.
	 * @auther sein
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024. 01. 11.			sein			최초작성
	 * -----------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	void insertReCouponIsuBas(CouponVO couponVo) throws Exception;
	
	/**
	 * <pre>
	 * 사용한 쿠폰에 대한 정보 CP_COUPON_INFO_BAS 업데이트 (couponNo, 총 할인 금액)
	 * </pre>
	 * @date 2024. 01. 11.
	 * @auther sein
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024. 01. 11.			sein			최초작성
	 * -----------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	void updateCpCouponInfoBas(String couponDtlNo, String sectionPrice, String mberId) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_여신 기본 테이블의 여신 계약 번호를 가져온다. (케이지크레딧에서 사용)
	 * </pre>
	 * @date 2022. 11. 22.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 22.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param grntyNo
	 * @return
	 * @throws Exception
	 */
	String getCdtlnCntrctNo(String grntyNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 사용 여부(SORIN CREDIT ON/OFF)(Y:사용가능, N:사용불가) 가져오기
	 * </pre>
	 * @date 2022. 11. 22.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 22.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param cdtlnCntrctNo
	 * @return
	 * @throws Exception
	 */
	String getSorinCredtUseAt(String cdtlnCntrctNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 보증 정보 가져오기
	 * (보증 번호, 업체 담보 계약 순번, 담보 보증 수수료 부담 주체 여부, 보증 기한 시작 일자, 보증 기한 종료 일자)
	 * </pre>
	 * @date 2022. 11. 23.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 23.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @param cdtlnSvcSeCode
	 * @return
	 * @throws Exception
	 */
	OrGrntyInfoVO getGrntyInfo(@Param("entrpsNo") String entrpsNo, @Param("cdtlnSvcSeCode") String cdtlnSvcSeCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 여신 정보(금리 정보, 패널티 정보, 여신 증권 발급 수수료 정보) 가져오기
	 *     여신 금리 정보(CD금리, 케이지트레이딩 가산금리, 연간뱅킹데이, CD 금리 사용 여부, 담보보증 무이자 일수)
	 *         CD금리는 CD 금리 사용 여부에 따라 미사용(N)일 경우 0으로 반환한다
	 *     여신 패널티 정보(여신관리 패널티 연체 건수, 여신관리 패널티 사고 건수)
	 *     여신 증권 발급 수수료 정보(전자상거래보증 증권발급 수수료 보상 비율, 전자상거래보증 증권발급 수수료 보상 건당 인정 비율)
	 * </pre>
	 * @date 2022. 11. 22.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 22.			srec0049			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	CredtCdtlnInfoVO getCdtlnInrstInfo() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원_업체 특정 브랜드 관계 테이블에서 삭제
	 * </pre>
	 * @date 2022. 11. 29.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 11. 29.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	int deleteMbEntrpsSpcifyBrandRls(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 고객이 지정 BL 이 맞는지 여부
	 * </pre>
	 * @date 2022. 11. 29.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 11. 29.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	int isMbEntrpsSpcifyBrandRls(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 톨로런스 최소범위 구하는 로직
	 * </pre>
	 * @date 2022. 12. 13.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 11. 29.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	int getMinToleranceRate(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이벤트_쿠폰 이력 정보 등록하기
	 * </pre>
	 * @date 2022. 12. 13.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 11. 29.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	void insertEvCouponIsuHst(CouponVO couponVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 지정 BL 이력정보 등록하기
	 * </pre>
	 * @date 2022. 12. 13.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 11. 29.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	void insertMbEntrpsSpcifyBrandRlsHst(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이월렛 환불 상태 체크
	 * </pre>
	 * @date 2022. 12. 12.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 12.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param section
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	Map<String, String> chkEwalletRefndSttus(String section, String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: FS서버 LINK 상태 확인
	 * </pre>
	 * @date 2024. 10. 28.
	 * @author jdrttl
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 10. 28.		jdrttl				최초작성
	 * ------------------------------------------------
	 * @param section
	 * @param 
	 * @return
	 * @throws Exception
	 */
	boolean getFsLinkStatus() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 선물 자동 승인 여부 가져오기
	 * </pre>
	 * @date 2023. 2. 2.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 2. 2.			srec0049			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	String getFutureAutoYn() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 권역 대분류별 아이템별 업체별 케이지몰 주문 가능 중량을 체크하여 주문 가능 여부와 총 실제 주문 중량을 반환한다[Y : 주문 가능, N : 주문 불가능]
	 * </pre>
	 * @date 2023. 3. 7.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 7.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param fixingPcOrderPossWtCeckVO
	 * @return
	 * @throws Exception
	 */
	FixingPcOrderPossWtCeckVO getFixingPcOrderPossWtCeckInfo(FixingPcOrderPossWtCeckVO fixingPcOrderPossWtCeckVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 기본 테이블 insert
	 * </pre>
	 * @date 2023. 5. 3.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 3.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param limitOrderModel
	 * @throws Exception
	 */
	void insertOrLimitOrderBas(LimitOrderModel limitOrderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 아이템의 판매 단위 중량을 조회한다.
	 * </pre>
	 * @date 2023. 5. 3.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 3.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param itmSn
	 * @return
	 * @throws Exception
	 */
	int getSleUnitWt(String itmSn) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 지정가 주문으로 발생한 결제수단 별 예수금의 총합을 조회한다.
	 * </pre>
	 * @date 2023. 6. 9.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 9.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	long getTotalAdvrcvAmount(OrderModel orderModel) throws Exception;

	Map<String, Object> getOrderLimitCheckInfo(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 쿠폰 발행테이블 update
	 * </pre>
	 * @date 2023. 7. 24.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 24.			sumin				최초작성
	 * ------------------------------------------------
	 * @param
	 */
	void updateCouponIsuBas(String couponSttusCode, String orderNo, String realMt, String realDscntApplcAmount, String mberId, String couponSn) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 평균가 거래 금액 비율 코드/세금 계산서 발행 시점 코드 가져오기
	 * </pre>
	 * @date 2023. 10. 23.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 23.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	OrderEntrpsSetleMnVO getAvrgpcDelngAmountRateCode(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 계약_계약 발주 기본 데이터 조회
	 * </pre>
	 * @date 2023. 10. 23.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 23.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	CnCntrctOrderBasVO selectCnCntrctOrderBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_주문 정보 기본 등록(평균가)
	 * </pre>
	 * @date 2023. 10. 23.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 23.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrOrderInfoBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 계약_발주 기본 테이블 update
	 * </pre>
	 * @date 2023. 10. 27.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 27.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void updateCnCntrctOrderBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 계약_평균가 선물 기본 조회
	 * </pre>
	 * @date 2023. 11. 15.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 15.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	CnAvrgpcFtrsBasVO selectCnAvrgpcFtrsBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 계약_평균가 선물환 기본 조회
	 * </pre>
	 * @date 2023. 11. 23.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 23.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	CnAvrgpcFshgBasVO selectCnAvrgpcFshgBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_주문 선물 상세 정보 등록
	 * </pre>
	 * @date 2023. 11. 15.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 15.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertOrOrderFtrsDtl(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 계약_평균가 선물 처리 상세 정보 등록
	 * </pre>
	 * @date 2023. 11. 15.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 15.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertCnAvrgpcFtrsProcessDtl(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 계약_평균가 선물환 처리 상세 정보 등록
	 * </pre>
	 * @date 2023. 11. 23.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 23.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void insertCnAvrgpcFshgProcessDtl(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 이벤트 추첨권 잔량체크
	 * 		: 2024 설날 복주머니 이벤트 추첨권 등록
	 * 		: 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 01. 26.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 26.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	int selectCntEvNewYearPromtn() throws Exception;
	void insertEvNewYearPromtn(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: LME MARK UP 사용여부 및 GAIN VALUE 불러오기
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author HANJOOK
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 02. 13.		HANJOOK			최초작성
	 * ------------------------------------------------
	 * @param
	 * @return
	 * @throws Exception
	 */
	String selectLmeMarkUpAt() throws Exception; 
	BigDecimal selectGainValue() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: LME MARK UP 주문 저장
	 * </pre>
	 * @date 2024. 02. 14.
	 * @author HANJOOK
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 02. 14.		HANJOOK			최초작성
	 * ------------------------------------------------
	 * @param
	 * @return
	 * @throws Exception
	 */
	int insertMarkUpOrderNo(OrderModel orderModel) throws Exception;

	OrderModel getPrvsnlUntpcInfo(OrderModel orderModel) throws Exception;

	OrderModel selectItPcChangegldManageBas(OrderModel orderModel, long calcGoodsUntpc);

	void insertOrUntpcDcsnDeChangeDtl(OrUntpcDcsnDeChangeDtlVO orUntpcDcsnDeChangeDtlVO) throws Exception;
}
