package com.sorincorp.fo.pd.mapper;

import java.util.List;

import com.sorincorp.fo.pd.model.ItemDtlInfoVO;

public interface ItemDtlInfoMapper {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 5.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 5.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemDtlInfoVO
	 * @return
	 * @throws Exception
	 */
	ItemDtlInfoVO selectItemDtlInfo(ItemDtlInfoVO itemDtlInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 5.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 5.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemDtlInfoVO
	 * @return
	 * @throws Exception
	 */
	List<ItemDtlInfoVO> selectBrandStdSpecDtlList(ItemDtlInfoVO itemDtlInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 5.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 5.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemDtlInfoVO
	 * @return
	 * @throws Exception
	 */
	List<ItemDtlInfoVO> selectItmStdSpecDtlList(ItemDtlInfoVO itemDtlInfoVO) throws Exception;

}
