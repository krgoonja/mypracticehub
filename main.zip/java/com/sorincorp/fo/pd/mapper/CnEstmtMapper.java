
package com.sorincorp.fo.pd.mapper;

import java.util.List;

import com.sorincorp.fo.pd.model.CnEstmtVO;

public interface CnEstmtMapper {

	List<CnEstmtVO> selectCnEstmtList(CnEstmtVO cnEstmtVO) throws Exception;

	String selectEntrpsnmKoreanShort(String entrpsNo) throws Exception;

	String selectCsTel() throws Exception;

	String getAuthCheckInsertCnEstmt(CnEstmtVO cnEstmtVO) throws Exception;
	
	int insertCnEstmt(CnEstmtVO cnEstmtVO) throws Exception;

	int insertCnEstmtHst(CnEstmtVO cnEstmtVO) throws Exception;

	int insertCnEstmtItmDtl(CnEstmtVO cnEstmtVO) throws Exception;

	int insertCnEstmtItmDtlHst(CnEstmtVO cnEstmtVO) throws Exception;

	int insertCnEstmtDstrctDtl(CnEstmtVO cnEstmtVO) throws Exception;

	int insertCnEstmtDstrctDtlHst(CnEstmtVO cnEstmtVO) throws Exception;

	int insertCnEstmtBrandGroupDtl(CnEstmtVO cnEstmtVO) throws Exception;

	int insertCnEstmtBrandGroupDtlHst(CnEstmtVO cnEstmtVO) throws Exception;

	int insertCnEstmtMtOrderWtDtl(CnEstmtVO cnEstmtVO) throws Exception;

	int insertCnEstmtMtOrderWtDtlHst(CnEstmtVO cnEstmtVO) throws Exception;
}
