package com.sorincorp.fo.pd.comm.aop;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.login.model.AccountEntrpsInfoVO;
import com.sorincorp.fo.pd.comm.exception.CustomEmptyLoginUserException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Aspect
@Component
public class OrderAccountAop {
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Pointcut("execution(* com.sorincorp.fo.pd.controller.OrderController.*(..))")
	public void orderAccountPointcut() {}
	
	@Before("orderAccountPointcut()")
	public void orderControllerAccountBefore(JoinPoint joinPoint) throws Exception{
		Account account = null;
		Object[] jpArgs = joinPoint.getArgs();
		for(Object obj : jpArgs) {
			if(obj instanceof HttpServletRequest) {
				account = Optional.ofNullable(userInfoUtil.getAccountInfo()).orElseThrow(() -> { return new CustomEmptyLoginUserException("로그인 유저 정보 없음");});
				log.debug("[OrderAccountAop][orderControllerAccountBefore] account 1 : " + String.valueOf(account));
			}else if(obj instanceof OrderModel && account != null) {
				log.debug("[OrderAccountAop][orderControllerAccountBefore] account 2 : " + account.getEntrpsNo() + ", " + account.getMberNo() + ", " + account.getId() + ", " + account.getEmail());
				OrderModel orderModel = (OrderModel) obj;
				orderModel.setEntrpsNo(account.getEntrpsNo());
				orderModel.setMberNo(account.getMberNo());
				orderModel.setMberId(account.getId());
				orderModel.setMberEmail(account.getEmail());
			}
		}
	}
	
	
}
