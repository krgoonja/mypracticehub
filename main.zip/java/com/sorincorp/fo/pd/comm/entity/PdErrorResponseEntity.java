package com.sorincorp.fo.pd.comm.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PdErrorResponseEntity {
	
	private int responseCode;
	
	private String defaultMessage;
	
	private Object data;

}
