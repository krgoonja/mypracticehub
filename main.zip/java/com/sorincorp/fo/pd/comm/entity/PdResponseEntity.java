package com.sorincorp.fo.pd.comm.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PdResponseEntity {
	
	private int responseCode;
	
	private String msg;
	
	private Object data;

}
