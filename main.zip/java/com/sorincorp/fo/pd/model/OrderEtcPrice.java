package com.sorincorp.fo.pd.model;

import lombok.Data;

@Data
public class OrderEtcPrice {
	
	/**
	 * 이월렛 계좌 번호
	 */
	private String ewalletAcnutNo;
	
	/**
	 * 이월렛 잔액
	 */
	private String ewalletBlce;
	
	/**
	 * 이월렛 거래 일시
	 */
	private String ewalletDelngDt;
	
	/**
	 * 보증 금액
	 */
	private String grntyAmount;
	
	/**
	 * 담보 잔액
	 */
	private String mrtggBlce;
	
	/**
	 * 담보 보증 한도 상태
	 */
	private String mrtggGrntyLmtStatus;
}
