package com.sorincorp.fo.pd.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class OrderPricePricingVO extends CommonVO {

	private static final long serialVersionUID = 1533139996874056588L;
	
	/******  JAVA VO CREATE : OR_PRICING_BAS(주문_프라이싱 기본)                                                                             ******/
    /**
     * 프라이싱 번호
    */
    private String pricingNo;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 시퀸스
    */
    private int itmSn;
    /**
     * 판매 방식 코드
    */
    private String sleMthdCode;
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 적용 일시
    */
    private String applcDt;
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 회원 번호
    */
    private String mberNo;
    /**
     * 프라이싱 단계 코드
    */
    private String pricingStepCode;
    /**
     * 아이템 명
    */
    private String itmNm;
    /**
     * 상품 명
    */
    private String goodsNm;
    /**
     * 상품 단가
    */
    private long goodsUntpc;
    /**
     * 판매 가격 실시간 순번
    */
    private String slePcRltmSn;
    /**
     * LME 가격 실시간 순번
    */
    private String lmePcRltmSn;
    /**
     * 환율 가격 실시간 순번
    */
    private String ehgtPcRltmSn;
    /**
     * 프리미엄 번호
    */
    private String premiumNo;
    /**
     * 장바구니 번호
    */
    private String bsktNo;
    /**
     * 원 프라이싱 번호
    */
    private String wonPricingNo;
    /**
     * 주문 중량
    */
    private int orderWt;
    /**
     * 배송 수단 코드
    */
    private String dlvyMnCode;
    /**
     * 배송지 번호
    */
    private String dlvrgNo;
    /**
     * 출고 요청 일자
    */
    private String dlivyRequstDe;
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 주문 가격
    */
    private long orderPc;
    /**
     * 중량 변동금
    */
    private long wtChangegld;
    /**
     * 배송비
    */
    private long dlvrf;
    /**
     * 부가세
    */
    private long vat;
    /**
     * 판매가
    */
    private long slepc;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;

}