package com.sorincorp.fo.pd.model;

import com.sorincorp.comm.order.model.OrderModel;

import lombok.Data;

@Data
public class LimitOrderModel extends OrderModel{
	/**
     * 지정가 주문 번호
    */
    private String limitOrderNo;

    /**
     * 지정가 주문 중량
     */
    private int limitOrderWt;

    /**
     * 지정가 입력 금액
     */
//    @NotNull
    private long limitInputAmount;

    /**
     * 최종 상품 단가
     */
    private long lastGoodsUntpc;

    /**
     * 최대 브랜드 변동금(브랜드 무관 시에만 존재)
     */
    private long mxmmBrandChangeAmount;

    /**
     * 지정가 주문 시각
     */
    private String limitOrderTm;

    /**
     * 차수 = 지정가 주문 중량 / 판매 단위 중량
     * 화면에서 표현할 span 태그의 갯수
     */
    private int limitOrderWtCnt;

    /**
     * 지정가 체결 우선 순위
     */
    private int limitsCnclsPriorRank;

    /**
     * 지정가 주문 유효 일자
     */
    private String limitOrderValidDe;
}
