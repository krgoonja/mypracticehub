package com.sorincorp.fo.pd.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CnCntrctOrderBasVO.java
 * 계약_계약 발주 기본 VO 객체
 * @version
 * @since 2023. 10. 13.
 * @author srec0066
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class CnCntrctOrderBasVO {
   /**
    * 계약 발주 번호
   */
   private String cntrctOrderNo;
   /**
    * 계약 번호
   */
   private String cntrctNo;
   /**
    * 발주 일시
   */
   private java.sql.Timestamp orderDt;
   /**
    * 판매 방식 코드
   */
   private String sleMthdCode;
   /**
    * 금속 코드
   */
   private String metalCode;
   /**
    * 아이템 순번
   */
   private int itmSn;
   /**
    * 권역 대분류 코드
   */
   private String dstrctLclsfCode;
   /**
    * 브랜드 그룹 코드
   */
   private String brandGroupCode;
   /**
    * 브랜드 코드
   */
   private String brandCode;
   /**
    * 주문 중량
   */
   private int orderWt;
   /**
    * 배송 수단 코드
   */
   private String dlvyMnCode;
   /**
    * 출고 요청 일자
   */
   private String dlivyRequstDe;
   /**
    * 예상 배송비
   */
   private java.math.BigDecimal expectDlvrf;
   /**
    * 배송지 명
   */
   private String dlvrgNm;
   /**
    * 수취 업체 명
   */
   private String receptEntrpsNm;
   /**
    * 수취 업체 우편 번호
   */
   private String receptEntrpsPostNo;
   /**
    * 수취 업체 주소
   */
   private String receptEntrpsAdres;
   /**
    * 수취 업체 상세 주소
   */
   private String receptEntrpsDetailAdres;
   /**
    * 수취 업체 도로명 주소
   */
   private String receptEntrpsRnAdres;
   /**
    * 수취 업체 도로명 상세 주소
   */
   private String receptEntrpsRnDetailAdres;
   /**
    * 수취 업체 법정동 코드
   */
   private String receptEntrpsLegaldongCode;
   /**
    * 수취 업체 휴대폰 번호
   */
   private String receptEntrpsMoblphonNo;
   /**
    * 수취 업체 담당자 명
   */
   private String receptEntrpsChargerNm;
   /**
    * 수취 업체 담당자 이메일
   */
   private String receptEntrpsChargerEmail;
   /**
    * 배송 요청 내용
   */
   private String dlvyRequstCn;
   /**
    * 단가 산식 코드
   */
   private String untpcMntnfrmlaCode;
   /**
    * 통화 구분 코드
   */
   private String crncySeCode;
   /**
    * 프리미엄 가격
   */
   private long premiumPc;
   /**
    * 주문 번호
   */
   private String orderNo;
   /**
    * 지정가 주문 번호
   */
   private String limitOrderNo;
   /**
    * 미결제 사유
   */
   private String unsetlResn;
   /**
    * 삭제 일시
   */
   private java.sql.Timestamp deleteDt;
   /**
    * 삭제 여부
   */
   private String deleteAt;
   /**
    * 최초 등록자 아이디
   */
   private String frstRegisterId;
   /**
    * 최초 등록 일시
   */
   private java.sql.Timestamp frstRegistDt;
   /**
    * 최종 변경자 아이디
   */
   private String lastChangerId;
   /**
    * 최종 변경 일시
   */
   private java.sql.Timestamp lastChangeDt;

}
