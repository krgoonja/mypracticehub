package com.sorincorp.fo.pd.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class CnEstmtVO  {

	private String estmtNo; 					/**       * 견적 번호      */
    private String estmtRceptDt; 				/**       * 견적 접수 일시      */
    private String estmtSttusCode;				/**       * 견적 상태 코드      */
    private String estmtSttusCodeNm;			/**       * 견적 상태 코드명      */
    private String estmtMngrRegistAt;           /**       * 견적 관리자 등록 여부      */
    private String mberNo;						/**       * 회원 번호      */
    private String entrpsNo;					/**       * 업체 번호      */
    private String entrpsnmKoreanShort;			/**       * 업체명 약어      */
    private String itmSn;						/**       * 아이템 순번      */
    private String metalCode;					/**       * 금속 코드      */
    private String metalCodeNm;					/**       * 금속 코드명      */
    private String avrgpcDstrctLclsfCode;		/**       * 권역 코드      */
    private String avrgpcDstrctLclsfCodeNmList;
    private String brandGroupCode;				/**       * 브랜드그룹 코드      */
    private String brandGroupCodeNmList;
    private String orderYm;						/**       * 주문 년월      */
    private String orderYmList;
    private String orderWt;						/**       * 주문 중량      */
    private String totOrderWt;					/**       * 주문 총 중량      */
    private String ordrrNm;						/**       * 주문자 명      */
    private String ordrrMoblphonNo;				/**       * 주문자 휴대폰 번호      */
    private String ordrrEmail;					/**       * 주문자 이메일      */
    private String orderEntrpsNm;				/**       * 주문 업체 명      */
    private String orderMonthCoCode;			/**       * 주문 개월 수 코드      */
    private String frstRegisterId;				/**       * 최초 등록자 아이디      */
    private String frstRegistDt;				/**       * 최초 등록 일시      */
    private String lastChangerId;				/**       * 최종 변경자 아이디      */
    private String lastChangeDt;				/**       * 최종 변경 일시      */
    private ArrayList<CnEstmtVO> itmList;
    private ArrayList<CnEstmtVO> avrgpcDstrctLclsfCodeList;
    private ArrayList<CnEstmtVO> brandGroupCodeList;
    private ArrayList<CnEstmtVO> orderList;

    private String sleMthdCode;					/**       * 판매 방식 코드      */
    private String metalClCode;					/**       * 매탈 구분 코드 (케이지몰전용)      */

}
