package com.sorincorp.fo.pd.model;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ItemPriceSelectVO extends CommonVO {

	private static final long serialVersionUID = 6882956165304862133L;

	public interface Search {};

	public interface Insert {};

	/** 판매 방식 코드 */
	@NotBlank(groups=Search.class, message="판매방식 코드는 필수값 입니다.")
	private String sleMthdCode;

	/** 판매 방식 상세 코드 */
	private String sleMthdDetailCode;

	/** 메탈 코드 */
	@NotBlank(groups=Search.class, message="메탈코드는 필수값 입니다.")
	private String metalCode;

	/** 배송지 번호 */
	@NotEmpty(groups=Insert.class, message="배송지 번호는 필수값 입니다.")
	private String dlvrgNo;

	/** 업체 번호 */
	@NotBlank(groups=Insert.class, message="업체번호는 필수값 입니다.")
	private String entrpsNo;

	/** 배송구분 코드 */
	@NotBlank(groups=Insert.class, message="배송구분은 필수값 입니다.")
	private String dlvyMnCode;

	/** 배송구분명 */
	private String dlvyMnNm;

	/** 출고권역 대분류 코드*/
	@NotBlank(groups=Search.class, message="출고권역은 필수값 입니다.")
	private String dstrctLclsfCode;

	/** 출고권역 대분류 */
	private String dstrctLclsfNm;

	/** 출고요청일 */
	@NotEmpty(groups=Insert.class, message="출고요청일은 필수값 입니다.")
	private String dlivyRequstDe;

	/** 브랜드 그룹 코드*/
	@NotBlank(groups=Search.class, message="브랜드 그룹은 필수값 입니다.")
	private String brandGroupCode;

	/** 브랜드 그룹명*/
	private String brandGroupNm;

	/** 브랜드 코드 */
	private String brandCode;

	/** 브랜드 코드 리스트*/
	private List<String> brandCodeList;

	/** 브랜드명 */
	private String brandNm;

	/** 아이템*/
	@Positive(groups=Search.class, message="아이템은 필수값 입니다.")
	private int itmSn;

	/** 아이템명 한글*/
	private String itmNm;

	/** 상품명*/
	private String goodsNm;

	/** 주문 중량 */
	@NotBlank(groups=Insert.class, message="주문중량은 필수값 입니다.")
	private BigDecimal orderWeight;

	/** 프라이싱 번호 */
	private String pricingNo;

	/** 장바구니 번호 */
	private String bsktNo;

	/** 최초 변경자 아이디 */
	private String frstRegisterId;

    /** 최종 변경자 아이디 */
	private String lastChangerId;

	/** 회원번호 */
	private String mberNo;

	/**       * 프리미엄 번호      */
	private String premiumNo;

    /**       * 판매 가격 실시간 순번      */
	private String slePcRltmSn;

    /**       * LME 가격 실시간 순번      */
	private String lmePcRltmSn;

    /**       * 환율 가격 실시간 순번      */
	private String ehgtPcRltmSn;

	/** 조회 가격 */
	private long goodsUntpc;

	/** 금속 명 예:Zn */
	private String metalNm;

	/** 금속 명 한글 예:아연 */
	private String metalNmKorea;

	/** 국기 이미지 URL */
	private String nationFlagImgUrl;

	/** 실중량 */
	private BigDecimal realStock;

	/** 성공여부 */
	private String success;

	/** 삭제여부 */
	private String deleteAt;

	/** 최소중량비율 */
	private int minToleranceRate;

	/** 바로구매 */
	private String justBuy;

	/** 매탈 구분 코드 (케이지몰전용) */
	private String metalClCode;

	/** 매탈 구분명 (케이지몰전용) */
	private String metalClCodeNm;

	/** ITM 대표이미지URL */
	private String pcImageOnePath;

	/** 판매 단위 중량 **/
	private int sleUnitWt;

	/** 1회 판매 가능 중량 **/
	private int onceSlePossWt;

	/** 브랜드 코드 **/
	@NotEmpty(message = "실제 브랜드 코드 미존재")
	private String realBrandCode;

	/** 주문 중량 **/
	@Min(value = 1,  message = "최소 주문 중량 확인 필요")
	private int orderWt;

	/** 지정 여부 */
	private String blRemain;

	/** 지정 BL */
	private String blNo;

	/** 지정 BL 실중량 */
	private BigDecimal blRealStock;

	/** 브랜드코드목록 */
	List<BrandCodeVO> subBrandCodeList;

	/** 지정BLNO 목록 */
	List<String> remainBlNoList;

	/** 전시 상품명*/
	private String dspyGoodsNm;

	/** 최대 주문 중량(톤)  */
	private int MxmmOrderWt;
	
	/** 상품검색페이지 검색조건 구분코드 (아이템: item, 권역: dsLf, 브랜드그룹: bdGrp, 브랜드: brand, 검색버튼: srchBrand**/
	private String goodsSrchcode;
	
	/** 상품검색페이지 검색조건 구분코드 - 브랜드 무관 시 RUSAL 제외**/
	private String clickbutton;

	/** 성적서 파일 경로 */
	private String screofeFileCours;

	/** 소량 구매 여부 */
	private String smlqyPurchsAt;

	/** 선물 잔량 */
	private int remainQy;

	/** 소량 판매 재고 미판매 번들 잔량 */
	private int smlqySleInvntryUnsleBundleBnt;

	/** 소량 판매 선물 여부 */
	private String smlqySleFtrsAt;
	
	/**
     * 잠정 단가 구매 설정 여부 (=가단가구매 여부)
    */
    private String prvsnlUntpcPurchsSetupAt;
    
    /**
     * 잠정 단가 출고 최대 수량
     */
    private int prvsnlUntpcDlivyMxmmQy;
    /**
     * 단가 미확정 중량
     */
    private int pcUnDcsnWt;
}