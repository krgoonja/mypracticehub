package com.sorincorp.fo.pd.model;

import lombok.Data;

@Data
public class OrUntpcDcsnDeChangeDtlVO {
	/******  JAVA VO CREATE : OR_UNTPC_DCSN_DE_CHANGE_DTL(주문_단가 확정 일자 변경 상세)                                                     ******/
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 변경 순번
    */
    private long changeSn;
    /**
     * 단가 확정 최대 일자
    */
    private String untpcDcsnMxmmDe;
    /**
     * 비고
    */
    private String rm;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 로그인 유저 ID
     */
    private String mberId;
}
