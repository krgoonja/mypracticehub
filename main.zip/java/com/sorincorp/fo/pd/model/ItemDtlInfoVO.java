package com.sorincorp.fo.pd.model;

import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ItemDtlInfoVO implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = -3827844834292737243L;

	/**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 화학물질 1 코드
    */
    private String chmclsOneCode;
    /**
     * 화학물질 2 코드
    */
    private String chmclsTwoCode;
    /**
     * 모양 코드
    */
    private String shapeCode;
    /**
     * 모양 코드명
     */
    private String shapeCodeNm;
    /**
     * 아이템 코드
    */
    private String itmCode;
    /**
     * 아이템 품목 한글
    */
    private String itmPrdlstKorean;
    /**
     * 아이템 품목 영문
    */
    private String itmPrdlstEng;
    /**
     * 포장 코드
    */
    private String packngCode;
    /**
     * 포장 코드명
     */
    private String packngCodeNm;
    /**
     * ERP 품목 코드
    */
    private String erpPrdlstCode;
    /**
     * 세번 코드
    */
    private String hsCode;
    /**
     * 유효 시작 일자
    */
    private String validBeginDe;
    /**
     * 유효 종료 일자
    */
    private String validEndDe;
    /**
     * 사용 여부
    */
    private String useAt;
    /**
     * 등록 일시
    */
    private String registDt;
    /**
     * 등록자 아이디
    */
    private String registerId;
    /**
     * 수정 일시
    */
    private String updtDt;
    /**
     * 수정자 아이디
    */
    private String updusrId;
    /**
     * 상품 명
    */
    private String goodsNm;
    /**
     * 선물 처리 여부
    */
    private String ftrsProcessAt;
    /**
     * 판매 여부
    */
    private String sleAt;
    /**
     * 판매 단위 코드
    */
    private String sleUnitCode;
    /**
     * 판매 단위 중량
    */
    private java.math.BigDecimal sleUnitWt;
    /**
     * 계약서 시작 허용 중량 비율
    */
    private int ctrtcBeginPermWtRate;
    /**
     * 계약서 종료 혀용 중량 비율
    */
    private int ctrtcEndPermWtRate;
    /**
     * BL 판매 최소 중량
    */
    private java.math.BigDecimal blSleMummWt;
    /**
     * 1회 판매 가능 중량
    */
    private java.math.BigDecimal onceSlePossWt;
    /**
     * 최대 구매 가능 중량
    */
    private java.math.BigDecimal mxmmPurchsPossWt;
    /**
     * 등록 여부
    */
    private String registAt;
    /**
     * 상품 설명 내용 PC
    */
    private String goodsDcCnPc;
    /**
     * 상품 설명 내용 모바일
    */
    private String goodsDcCnMobile;
    /**
     * PC 이미지 1 순번
    */
    private String pcImageOneSn;
    private String pcImageOneNm;
    /**
     * PC 이미지 2 순번
    */
    private String pcImageTwoSn;
    private String pcImageTwoNm;
    /**
     * PC 이미지 3 순번
    */
    private String pcImageThreeSn;
    private String pcImageThreeNm;
    /**
     * PC 이미지 4 순번
    */
    private String pcImageFourSn;
    private String pcImageFourNm;
    /**
     * PC 이미지 5 순번
    */
    private String pcImageFiveSn;
    private String pcImageFiveNm;
    /**
     * 모바일 이미지 1 순번
    */
    private String mobileImageOneSn;
    private String mobileImageOneNm;
    /**
     * 모바일 이미지 2 순번
    */
    private String mobileImageTwoSn;
    private String mobileImageTwoNm;
    /**
     * 모바일 이미지 3 순번
    */
    private String mobileImageThreeSn;
    private String mobileImageThreeNm;
    /**
     * 모바일 이미지 4 순번
    */
    private String mobileImageFourSn;
    private String mobileImageFourNm;
    /**
     * 모바일 이미지 5 순번
    */
    private String mobileImageFiveSn;
    private String mobileImageFiveNm;
    /**
     * 총 재고 중량
    */
    private java.math.BigDecimal totInvntryWt;
    /**
     * 판매 가능 재고 중량
    */
    private java.math.BigDecimal slePossInvntryWt;
    /**
     * 담당자 명
    */
    private String chargerNm;
    /**
     * 담당자 연락처
    */
    private String chargerCttpc;
    /**
     * 담당자 핸드폰
    */
    private String chargerMoblphon;
    /**
     * 담당자 이메일
    */
    private String chargerEmail;
    /**
     * AS 책임자
    */
    private String asRspnber;
    /**
     * 소비자 상담 전화번호
    */
    private String cnsmrCnsltTelno;


    /******  표준SPEC                                                                                    ******/
    /**
     *
     */
    private String metalCodeNm;
    /**
     *
     */
    private String optnCode;
    /**
     *
     */
    private String optnCodeNm;
    /**
     *
     */
    private String specOneCode;
    /**
     *
     */
    private String specTwoCode;

    /******  품목분류                                                                                    ******/

    /**
     *
     */
    private String ctgryId;
    /**
     *
     */
    private String ctgryCodeLv1;
    /**
     *
     */
    private String ctgryCodeLv2;
    /**
     *
     */
    private String ctgryCodeLv3;
    /**
     *
     */
    private String ctgryCodeLv4;

    private String ctgryNo;
    private int ctgrySn;
    private String regCtgryNo;
    private String delCtgryNo;
    private String delCtgrySn;
    private String ctgryNm;
    private String upperCtgryNo;
    private String ctgryLevel;

    private String ctgryLv1No;
    private String ctgryLv2No;
    private String ctgryLv3No;
    private String ctgryLv1Nm;
    private String ctgryLv2Nm;
    private String ctgryLv3Nm;

    private String pcImageOnePath;
    private String pcImageTwoPath;
    private String pcImageThreePath;
    private String pcImageFourPath;
    private String pcImageFivePath;

    private int pcImageOneSize;
    private int pcImageTwoSize;
    private int pcImageThreeSize;
    private int pcImageFourSize;
    private int pcImageFiveSize;

    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 브랜드 명
    */
    private String brandNm;
    /**
     * 주소
    */
    private String adres;
    /**
     * 생산자 명
    */
    private String mkerNm;
    /**
     * 국가 코드
    */
    private String nationCode;
    /**
     * 국가 코드명
     */
    private String nationCodeNm;
    /**
     * 브랜드 소스
    */
    private String brandSourc;
    private String brandSourcNm;
    /**
     * 관세 비율
    */
    private java.math.BigDecimal cstmsRate;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    private String brandGroupCodeNm;
    /**
     * 브랜드 그룹 코드
     */
    private String dstrctLclsfCode;
    private String dstrctLclsfCodeNm;
    /**
     * EC 사영 여부
    */
    private String ecUseAt;

    /******  JAVA VO CREATE : IT_BRAND_STD_SPEC_DTL()                                                                                        ******/
    /**
     *
    */
    private int brandStdSpecDetailSn;
    /**
     * 우선순위
     */
    private String priorRank;

}
