package com.sorincorp.fo.pd.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ItPremiumBrandBasVO {

	/******  JAVA VO CREATE : IT_PREMIUM_BRAND_BAS(상품_프리미엄 브랜드 기본)                                                                ******/
    /**
     * 프리미엄 번호
    */
    private String premiumNo;
    /**
     * 프리미엄 아이디
    */
    private String premiumId;
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 브랜드 변동 금액
    */
    private long brandChangeAmount;
    /**
     * 고정가 브랜드 변동 금액
    */
    private long hghnetprcBrandChangeAmount;
    /**
     * 판매 프리미엄 금액
    */
    private long slePremiumAmount;
    /**
     * 고정가 판매 금액
    */
    private long hghnetprcSleAmount;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;

}
