package com.sorincorp.fo.pd.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;

/**
 * SettleSttusDeVO.java
 * @version
 * @since 2022. 8. 1.
 * @author srec0049
 */
@Data
public class SettleSttusDeVO {
	
	/**
	 * 기준일 ex) 20220801
	 */
	@NotBlank(message = "기준일 미존재")
	@Size(min=8, max=8, message = "기준일 형식은 YYYYMMDD")
	private String stdde;
	
	/**
	 * 계산될 일자 ex) after 2, pre -2
	 */
	@NotNull(message = "계산될 일자 미존재")
	private int calcDay;
}
