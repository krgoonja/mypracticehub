package com.sorincorp.fo.pd.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class OrderLimitReceiptVO extends OrderReceiptVO {
    /**
     * 2023.05 지정가 고도화로 추가
     */

    /** 지정가 주문 번호 */
    private String limitOrderNo;
    /** 지정가 상품 단가 */
    private long lastGoodsUntpc;
    /** 예수금 */
    private long advrcvAmount;
    /** 계약 구매 최종 상품 단가 */
    private long cntrctPurchsLastGoodsUntpc;
}
