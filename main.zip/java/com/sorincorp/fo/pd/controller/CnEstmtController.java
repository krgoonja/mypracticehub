package com.sorincorp.fo.pd.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;
import com.sorincorp.comm.brandgroupcode.service.BrandGroupCodeService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.constants.ExceptionConstants;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.pd.model.CnEstmtVO;
import com.sorincorp.fo.pd.service.CnEstmtService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping("/pd")
public class CnEstmtController {

	@Autowired
	private CnEstmtService cnEstmtSerivce;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private BrandGroupCodeService brandGroupCodeService;

	@Autowired
	private ItemCodeService itemCodeService;


	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	@RequestMapping("/cnEstmtRcept")
	public String selectCnEstmt(Model model, @RequestBody CnEstmtVO cnEstmtVO){
		try {
			List<CnEstmtVO> cnEstmtList = cnEstmtSerivce.selectCnEstmtList(cnEstmtVO);

			model.addAttribute("cnEstmtList",cnEstmtList);
			model.addAttribute("metalCodeInfo",commonCodeService.getCodeValueRetVo("METAL_CODE", cnEstmtVO.getMetalCode()));
			model.addAttribute("itemList",itemCodeService.getItemAvrgpcUseAtCodeList(cnEstmtVO.getMetalCode(), "Y"));
			model.addAttribute("avrgpcDstrctLclsfCodeList",commonCodeService.getSubCodesToCommonCode("AVRGPC_DSTRCT_LCLSF_CODE"));
			model.addAttribute("brandGroupCodeList",brandGroupCodeService.getBrandGroupSleMthdCodeList(cnEstmtVO.getMetalCode(),"01"));
			//model.addAttribute("brandGroupCodeList",brandGroupCodeService.getBrandGroupSleMthdCodeList(cnEstmtVO.getMetalCode(),cnEstmtVO.getSleMthdCode()));
			return "pd/cnEstmtRcept";

		}catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}

	}

	/*
	 * Purchase Contract Auth Check
	 */
	@PostMapping("/getAuthCheckInsertCnEstmt")
	@ResponseBody
	public ResponseEntity<Object> getAuthCheckInsertCnEstmt(@RequestBody CnEstmtVO cnEstmtVO) throws Exception {

		Map<String,Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		String result = cnEstmtSerivce.getAuthCheckInsertCnEstmt(cnEstmtVO);

		if(result.equals("Y")) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		}else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal,HttpStatus.OK);
	}


	@PostMapping("/insertCnEstmt")
	@ResponseBody
	public ResponseEntity<Object> insertCnEstmtList(@RequestBody CnEstmtVO cnEstmtVO) throws Exception {

		Map<String,Object> retVal = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result = cnEstmtSerivce.insertCnEstmtList(cnEstmtVO);

		if(result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		}else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal,HttpStatus.OK);
	}

	@RequestMapping("/cnEstmtEnd")
	public String cnEstmtEnd(Model model, @RequestBody CnEstmtVO cnEstmtVO){
		try {
			List<CnEstmtVO> cnEstmtList = cnEstmtSerivce.selectCnEstmtList(cnEstmtVO);

			model.addAttribute("metalCodeNm",cnEstmtVO.getMetalCodeNm());
			model.addAttribute("cnEstmtList",cnEstmtList);
			return "pd/cnEstmtEnd";

		}catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}





}
