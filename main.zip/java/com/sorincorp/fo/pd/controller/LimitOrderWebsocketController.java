package com.sorincorp.fo.pd.controller;

import java.util.Map;
import java.util.concurrent.CompletableFuture;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.comm.order.service.CommFrontOrderWebsocketService;
import com.sorincorp.comm.order.service.CommPrvsnlLimitOrderRedisPubService;
import com.sorincorp.fo.my.mapper.OrderPrvsnlDcsnMapper;
import com.sorincorp.fo.my.model.OrderPrvsnlDcsnProcessVO;
import com.sorincorp.fo.my.service.OrderPrvsnlDcsnService;
import com.sorincorp.fo.pd.comm.entity.PdResponseEntity;

import lombok.extern.slf4j.Slf4j;

/**
 * LimitOrderWebsocketController.java
 * FO websocket publish Controller 클래스
 * 
 * @version
 * @since 2023. 5. 4.
 * @author srec0066
 */
@Slf4j
@RestController
@RequestMapping("/fo/pub")
public class LimitOrderWebsocketController {

	/**
	 * 가단가 자동 확정 스레드 풀
	 */
	@Resource(name = "prvsnlAutoDcsnThreadPool")
	private ThreadPoolTaskExecutor prvsnlAutoDcsnTaskExecutor;
	
	/**
	 * FO 웹소켓 Service 
	 */
	@Autowired
	private CommFrontOrderWebsocketService commFrontOrderWebsocketService;
	
	/**
	 * 단가확정하기 관련 Service 
	 */
	@Autowired
	private OrderPrvsnlDcsnService orderPrvsnlDcsnService;
	
	/**
     * 가단가 지정가 주문 Redis Publish 공통 서비스
     */
    @Autowired
    private CommPrvsnlLimitOrderRedisPubService commPrvsnlLimitOrderRedisPubService;
    
    /**
	 * 단가확정하기 관련 Mapper
	 */
	@Autowired
    private OrderPrvsnlDcsnMapper orderPrvsnlDcsnMapper;
	

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 websocket publish (FO 호가창)
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/limitOrder")
	public ResponseEntity<?> publishLimitOrder(@RequestBody Map<String,Object> param) throws Exception {
		log.info("[FO][LimitOrderWebsocketController] IN : " + param.toString());

		// 지정가 주문 websocket publish
		commFrontOrderWebsocketService.publishLimitOrder(param, false);

		return ResponseEntity.status(HttpStatus.OK).build();
	}
	
	/**
	 * <pre>
	 * 처리내용: 가단가 확정 websocket publish
	 * </pre>
	 * @date 2024. 11. 6.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 6.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/prvsnlDcsn")
	public CompletableFuture<ResponseEntity<?>> publishPrvsnlAutoDcsn(@RequestBody Map<String, Object> param) throws Exception {
		//log.info("[FO][LimitOrderWebsocketController] publishPrvsnlDcsn IN : " + param.toString());
		
		// 단가 자동 확정 진행
		this.doPrvsnlAutoDcsn(param);
		
		return CompletableFuture.completedFuture(ResponseEntity.status(HttpStatus.OK).build());
	}
	
	
	
	/**
	 * <pre>
	 * 처리내용: 단가 자동 확정 진행
	 * </pre>
	 * @date 2024. 11. 13.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 13.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param param
	 * @throws Exception
	 */
	public void doPrvsnlAutoDcsn(Map<String, Object> param) throws Exception {
		Runnable prvsnlAutoDcsnRun = () -> {
			try {
				//log.info("[FO][LimitOrderWebsocketController] doPrvsnlDcsn IN : " + param.toString());
				
				// 단가확정하기 모달창 갱신만 할 것인지, 단가확정하고 갱신할 것인지 여부 [Y: 단가확정하기 모달창 화면만 갱신, N: 단가확정 후 단가확정하기 모달창 화면 갱신]
				String onlyRefresh = String.valueOf(param.get("onlyRefresh")); 
				
				String section = String.valueOf(param.get("section")); // 가단가 확정 - 구분 [lme: LME 분리확정, fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]
				String sttusCode = String.valueOf(param.get("sttusCode")); // 가단가 확정 - 상태 코드 [I: 등록, U: 수정, D: 취소]
				
				OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO = new OrderPrvsnlDcsnProcessVO();
				orderPrvsnlDcsnProcessVO.setOrderNo(String.valueOf(param.get("orderNo"))); // 주문 번호
				orderPrvsnlDcsnProcessVO.setSection(section); // 가단가 확정 - 구분 [lme: LME 분리확정, fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]
				orderPrvsnlDcsnProcessVO.setSttusCode(sttusCode); // 가단가 확정 - 상태 코드 [I: 등록, U: 수정, D: 취소]
				
				
				if(StringUtils.equals("N", onlyRefresh)) {
					orderPrvsnlDcsnProcessVO.setMberNo(String.valueOf(param.get("mberNo"))); // 회원 번호
					orderPrvsnlDcsnProcessVO.setMberId(String.valueOf(param.get("mberId"))); // 회원 ID
					
					// 지정가 주문 상태 코드 [49 : 지정가 주문취소(최대 단가확정 경과)], 입금 요망일 때, 배치시간까지 입금하지 않을 시 지정가 주문 취소도 포함
					orderPrvsnlDcsnProcessVO.setLimitOrderSttusCode("49"); 
					
					// 지정가 취소 대상일 경우 각 해당 지정가 취소하기
					if(param.get("limitLmeOrderNo") != null) {
						orderPrvsnlDcsnProcessVO.setLimitLmeOrderNo(String.valueOf(param.get("limitLmeOrderNo")));
						
						// 주문_지정가 주문 LME 기본 테이블 취소
						orderPrvsnlDcsnMapper.cancelOrLimitLmeOrderBas(orderPrvsnlDcsnProcessVO);
						
						// LME/KRW - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
						commPrvsnlLimitOrderRedisPubService.prvsnlLimitOrderMsgLmePublish(orderPrvsnlDcsnProcessVO.getLimitLmeOrderNo(), "D");
					}
					
					if(param.get("limitEhgtOrderNo") != null) {
						orderPrvsnlDcsnProcessVO.setLimitEhgtOrderNo(String.valueOf(param.get("limitEhgtOrderNo")));
						
						// 주문_지정가 주문 환율 기본 테이블 취소
						orderPrvsnlDcsnMapper.cancelOrLimitEhgtOrderBas(orderPrvsnlDcsnProcessVO);
						
						// FX - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
						commPrvsnlLimitOrderRedisPubService.prvsnlLimitOrderMsgFxPublish(orderPrvsnlDcsnProcessVO.getLimitEhgtOrderNo(), "D");
					}
					
					if(param.get("limitKrwOrderNo") != null) {
						orderPrvsnlDcsnProcessVO.setLimitKrwOrderNo(String.valueOf(param.get("limitKrwOrderNo")));
						
						// 주문_지정가 주문 KRW 기본 테이블 취소
						orderPrvsnlDcsnMapper.cancelOrLimitKrwOrderBas(orderPrvsnlDcsnProcessVO);
						
						// LME/KRW - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
						commPrvsnlLimitOrderRedisPubService.prvsnlLimitOrderMsgLmePublish(orderPrvsnlDcsnProcessVO.getLimitKrwOrderNo(), "D");
					}
					
					
					orderPrvsnlDcsnProcessVO.setSelMthd("live"); // 가단가 확정 - 판매 방식 [live: 라이브, limit: 지정가]
					
					// 구분 및 판매 방식, 상태 코드에 따른 확정 [라이브, 지정가] 등록 진행
					orderPrvsnlDcsnService.registPrvsnlDcsnProcess(orderPrvsnlDcsnProcessVO);
				} else {
					// 단가확정하기 정보 및 주문 번호에 대한 공통 가단가 확정 여부 정보 가져오기, 구분 및 판매 방식, 상태 코드에 따른 등록, 수정, 취소 진행 후 정보 가져오기
					orderPrvsnlDcsnService.getOrderPrvsnlDcsnProcessInfo(orderPrvsnlDcsnProcessVO);
					// 가단가 확정하기 정보 websocket publish, FO에 해당 확정 여부 전파 전달 (SimpMessagingTemplate) [확정, 체결, 수정, 취소] 모두 대상
					orderPrvsnlDcsnService.websocketPublishPrvsnlDcsnSimpMsg(orderPrvsnlDcsnProcessVO);
				}
			} catch (Exception e) {
				
			}
		};
		
		prvsnlAutoDcsnTaskExecutor.execute(prvsnlAutoDcsnRun);
	}
	
	/**
	 * <pre>
	 * 처리내용: FO로 오는 연결 테스트
	 * </pre>
	 * @date 2023. 7. 4.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 7. 4.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param testNo
	 * @return
	 */
	@GetMapping("/callTest/{testNo}")
	public ResponseEntity<?> callTest(@PathVariable(value = "testNo") String testNo) {
		log.info(">> [callTest] testNo : " + testNo);
		
		return ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(200, testNo, null));
	}
}
