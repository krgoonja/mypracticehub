package com.sorincorp.fo.pd.controller;

import java.math.BigDecimal;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.codehaus.jettison.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.brandcode.service.BrandCodeService;
import com.sorincorp.comm.brandgroupcode.service.BrandGroupCodeService;
import com.sorincorp.comm.bsnInfo.model.RltmEndTimeVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.entrpsdlvrg.service.EntrpsDlvrgService;
import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.invntry.model.InvntrySttusVO;
import com.sorincorp.comm.invntry.service.InvntrySttusService;
import com.sorincorp.comm.iseco.model.IsecoCommVO;
import com.sorincorp.comm.iseco.service.IsecoCommService;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingSelectVO;
import com.sorincorp.comm.itemprice.service.ItemPriceMatchingService;
import com.sorincorp.comm.order.model.CommFtrsFshgMngVO;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.comm.order.model.OrderEntrpsSetleMnVO;
import com.sorincorp.comm.order.service.CommFtrsFshgMngService;
import com.sorincorp.comm.order.service.CommOrderService;
import com.sorincorp.comm.pcInfo.mapper.PcInfoMapper;
import com.sorincorp.comm.pcInfo.model.FixPriceVO;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.sidecar.service.SidecarService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.fo.chart.model.PreminumSelVO;
import com.sorincorp.fo.chart.model.SelMetalVO;
import com.sorincorp.fo.chart.service.PcMntrngService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.ma.service.MainService;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.model.MbEntrpsGradVO;
import com.sorincorp.fo.mb.service.EntrpsEtrService;
import com.sorincorp.fo.my.model.DeliveryRegionMngVO;
import com.sorincorp.fo.my.service.DashboardService;
import com.sorincorp.fo.my.service.DeliveryRegionMngService;
import com.sorincorp.fo.my.service.InqryDtlsService;
import com.sorincorp.fo.my.service.MyCouponDtlsSerivce;
import com.sorincorp.fo.pd.model.ItemDtlInfoVO;
import com.sorincorp.fo.pd.model.ItemPriceSelectVO;
import com.sorincorp.fo.pd.model.OrderPricePricingVO;
import com.sorincorp.fo.pd.service.ItemDtlInfoService;
import com.sorincorp.fo.pd.service.ItemPriceService;
import com.sorincorp.fo.pd.service.OrderService;

import lombok.extern.slf4j.Slf4j;

/**
 * ItemPriceController.java
 *
 * @version
 * @since 2021. 7. 15.
 * @author Kwon sun hyung
 */
@Slf4j
@Controller
@RequestMapping("/pd")
@ComponentScan(basePackages = { "com.sorincorp.comm.*" })
@EnableScheduling
public class ItemPriceController {

	public static final String SRCH_CODE_ITEM = "item";
	public static final String SRCH_CODE_BRAND = "brand";
	public static final String SRCH_CODE_ITEM_BRAND_SRCH = "itemBrandSrch";

	@Autowired
	private ItemPriceService itemPriceService;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private PcInfoService pcInfoService;

	@Autowired
	private BrandCodeService brandCodeService;

	@Autowired
	private BrandGroupCodeService brandGroupCodeService;

	@Autowired
	private ItemCodeService itemCodeService;

	@Autowired
	private CustomValidator customValidator;

	@Autowired
	private ItemPriceMatchingService itemPriceMatchingService;

	@Autowired
	private EntrpsDlvrgService entrpsDlvrgService;

	@Autowired
	private ItemDtlInfoService itemDtlInfoService;

	@Autowired
	private InqryDtlsService inqryDtlsService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private PcMntrngService pcMntrngService;

	@Autowired
	private SidecarService sidecarService;

	@Autowired
	private EntrpsEtrService entrpsEtrService;

	@Autowired
	private DeliveryRegionMngService deliveryRegionMngService;

	@Autowired
	MainService mainService;

	@Autowired
	private OrderService orderService;

	@Autowired
	private MyCouponDtlsSerivce myCouponDtlsSerivce;

	@Autowired
	private IsecoCommService isecoCommService;

	@Autowired
	private DashboardService dashboardService;

	/**
	 * 주문 공통 Service
	 */
	@Autowired
	private CommOrderService commOrderService;

	@Autowired
	PcInfoMapper pcInfoMapper;

	@Autowired
	private InvntrySttusService invntrySttusService;

	@Value("${redisPubsub.uri.invntry}")
	private String invntryUri;

	@Autowired
	private BsnInfoService bsnInfoService;
	
	@Autowired
    private CommFtrsFshgMngService commFtrsFshgMngService;


	/**
	 * <pre>
	 * 처리내용: ItemPrice 화면을 보여준다.
	 * </pre>
	 *
	 * @date 2021. 7. 15.
	 * @author Kwon sun hyung
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 15.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param model
	 * @return String
	 * @throws Exception
	 */
	@RequestMapping("/itemPriceSearch")
	public String viewItemPriceLiveSearchController(@RequestParam(required = false, value = "metalCode") String metalCodeGet,
			@RequestParam(required = false, value = "sleMthdCode") String sleMthdCodeGet, @RequestParam(required = false, value = "metalClCode") String metalClCodeGet,
			@RequestBody(required = false) ItemPriceSelectVO itemPriceSelectVO, HttpServletRequest request, ModelMap model) {
		try {
			// 판매방식코드 01:live, 02:고정가 -> 선물처리여부 Y:live, N:고정가
			String metalCode = "";
			String sleMthdCode = "";
			String metalClCode = "";

			if (request.getMethod().equals("GET")) {
				metalCode = metalCodeGet;
				sleMthdCode = sleMthdCodeGet;
				metalClCode = metalClCodeGet;
			} else if (request.getMethod().equals("POST")) {
				metalCode = itemPriceSelectVO.getMetalCode();
				sleMthdCode = itemPriceSelectVO.getSleMthdCode();
				metalClCode = itemPriceSelectVO.getMetalClCode();
			}
			
			// 24-08-30 변경사항 : "가단가구매" 로직 실행에 필요한 데이터 세팅
			if(StringUtils.equals(sleMthdCode, "05")) {	// 판매방식이 가단가구매(05)일 시
				sleMthdCode = "01";	// LIVE 와 동일한 로직 수행을 위해 판매방식 코드를 01(LIVE)로 재설정
				model.addAttribute("prvsnlUntpcPurchsSetupAt", "Y");	// 잠정 단가 구매 설정 여부 (=가단가주문 여부) 를 Y로 설정
			}

			CommonCodeVO codeValueRetVo = commonCodeService.getCodeValueRetVo("METAL_CODE", metalCode);

			model.addAttribute("metalCode", metalCode);
			model.addAttribute("metalClCode", metalClCode);
			model.addAttribute("metalNm", codeValueRetVo.getCodeNm());
			model.addAttribute("metalKrNm", codeValueRetVo.getCodeChrctrRefrnsix());

			Map<String, String> returnDstrctLclsfCode = new HashMap<String, String>();

			if (sleMthdCode != null) {
				if (sleMthdCode.equals("02")) {
					IsecoCommVO param = new IsecoCommVO();
					param.setSrhGubunCode("02");
					param.setSleMthdCode(sleMthdCode);
					param.setMetalClCode(metalClCode);

					List<IsecoCommVO> isecoItemList = isecoCommService.getIsEcoSearchList(param);

					String entrpsNo = userInfoUtil.getEntripsNo();

					//케이지몰 업체별 가격정보 및 제한중량
					List<FixPriceVO> stdrFixPriceList = pcInfoService.hasEntrpsFixPriceDataList(metalCode, metalClCode, 0, "00",
							"00", "0000000000", entrpsNo, DateUtil.getNowDateTime("yyyyMM"));

					List<ItemCodeVO> itemList = new ArrayList<ItemCodeVO>();
					for (IsecoCommVO isecoItem : isecoItemList) {
						for (FixPriceVO stdrFixPrice : stdrFixPriceList) {
							if(isecoItem.getItmSn() == stdrFixPrice.getItmSn()) {

								//케이지몰 업체별 주문중량 제한여부
								String fixingPcOrderPossWtYn = orderService.getFixingPcOrderPossWtCeck(stdrFixPrice.getDstrctLclsfCode(), stdrFixPrice.getItmSn()
										, entrpsNo, stdrFixPrice.getSorinmallUnitPdCode(), stdrFixPrice.getLmttWt(), 0, sleMthdCode);

								if("Y".equals(fixingPcOrderPossWtYn)) {
									ItemCodeVO item = new ItemCodeVO();
									item.setSubCode(Integer.toString(isecoItem.getItmSn()));
									item.setGoodsNm(isecoItem.getGoodsNm());
									item.setCodeNm(isecoItem.getDspyGoodsNm());
									item.setDspyGoodsNm(isecoItem.getDspyGoodsNm());
									item.setItmCode(isecoItem.getItmCode());

									itemList.add(item);
									break;
								}
							}
						}

					}
					model.addAttribute("itmSnList", itemList);
				}

				model.addAttribute("dstrctLclsfCodeList", returnDstrctLclsfCode);
			} else {
				model.addAttribute("itmSnList", new ArrayList<ItemCodeVO>()); // 아이템
				model.addAttribute("dstrctLclsfCodeList", returnDstrctLclsfCode);
			}

			model.addAttribute("sleMthdCode", sleMthdCode);

			// 문의 구분 대분류 코드(문의하기 팝업화면에 필요함)
			model.addAttribute("inqrySeCode", inqryDtlsService.getCommCodeListStr(commonCodeService.getFilterCode("INQRY_SE_CODE", null, "CODE_CHRCTR_REFRNTWO", "IT"), ""));
			model.addAttribute("scrinSeCode", "item"); // 화면 구분 코드
			model.addAttribute("inqryGoodsCode", ""); // 상품코드

			// 사이드카 정보
			model.addAttribute("sidcar", sidecarService.getSidecarOnList());

			String loginYn = "";
			Account account = userInfoUtil.getAccountInfo();

			if (account == null) {
				loginYn = "N";
			} else {
				loginYn = "Y";
			}

			Map<String, Object> loginStatusMap = new HashMap<String, Object>();
			loginStatusMap.put("loginYn", loginYn);
			model.addAttribute("loginStatusMap", loginStatusMap); // 로그인 여부

			if (sleMthdCode.equals("01")) {
				return "pd/itemPriceLiveSearch";
			} else {
				return "pd/itemPriceFixedSearch";
			}
		} catch (Exception e) {
			log.debug(ExceptionUtils.getStackTrace(e));
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 소량구매 화면을 조회한다.`
	 * </pre>
	 * @date 2024. 5. 13.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 5. 13.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param model
	 * @return String
	 * @throws Exception
	 */
	@RequestMapping("/itemPriceSmlqySearch")
	public String viewItemPriceSmlqySearchController(@RequestParam(required = false, value = "metalCode") String metalCodeGet,
			@RequestParam(required = false, value = "sleMthdCode") String sleMthdCodeGet, @RequestParam(required = false, value = "metalClCode") String metalClCodeGet,
			@RequestBody(required = false) ItemPriceSelectVO itemPriceSelectVO, HttpServletRequest request, ModelMap model) {
		try {
			// 판매방식코드 01:live, 02:고정가 -> 선물처리여부 Y:live, N:고정가
			String metalCode = "";
			String sleMthdCode = "";
			String metalClCode = "";

			if (request.getMethod().equals("GET")) {
				metalCode = metalCodeGet;
				sleMthdCode = sleMthdCodeGet;
				metalClCode = metalClCodeGet;
			} else if (request.getMethod().equals("POST")) {
				metalCode = itemPriceSelectVO.getMetalCode();
				sleMthdCode = itemPriceSelectVO.getSleMthdCode();
				metalClCode = itemPriceSelectVO.getMetalClCode();
			}

			CommonCodeVO codeValueRetVo = commonCodeService.getCodeValueRetVo("METAL_CODE", metalCode);

			model.addAttribute("metalCode", metalCode);
			model.addAttribute("metalClCode", metalClCode);
			model.addAttribute("metalNm", codeValueRetVo.getCodeNm());
			model.addAttribute("metalKrNm", codeValueRetVo.getCodeChrctrRefrnsix());

			model.addAttribute("itmSnList", new ArrayList<ItemCodeVO>()); // 아이템
			model.addAttribute("dstrctLclsfCodeList", new HashMap<String, String>()); // 권역

			model.addAttribute("sleMthdCode", sleMthdCode);

			// 사이드카 정보
			model.addAttribute("sidcar", sidecarService.getSidecarOnList());

			String loginYn = "";
			Account account = userInfoUtil.getAccountInfo();

			if (account == null) {
				loginYn = "N";
			} else {
				loginYn = "Y";
			}

			Map<String, Object> loginStatusMap = new HashMap<String, Object>();
			loginStatusMap.put("loginYn", loginYn);
			model.addAttribute("loginStatusMap", loginStatusMap); // 로그인 여부

			return "pd/itemPriceSmlqySearch";
		} catch (Exception e) {
			log.debug(ExceptionUtils.getStackTrace(e));
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}

	}

	/**
	 * <pre>
	 * 처리내용: 검색 조건에 맞는 아이템을 검색한다.
	 * </pre>
	 *
	 * @date 2021. 7. 15.
	 * @author Kwon sun hyung
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 15.		Kwon sun hyung		최초작성
	 * 2021. 9. 17.		Kwon sun hyung		수정
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param itemPriceVO
	 * @return List<ItemPriceVO>
	 * @throws Exception
	 */
	@PostMapping("/insertOrderPriceSearchStep")
	@ResponseBody
	public ResponseEntity<Object> insertOrderPriceSearchStep(@RequestBody ItemPriceSelectVO itemPriceSelectVo, BindingResult bindingResult) throws Exception {
		Map<String, Object> rtnMap = new HashMap<String, Object>();

		try {

			customValidator.validate(itemPriceSelectVo, bindingResult, ItemPriceSelectVO.Search.class);

			if (bindingResult.hasErrors()) {
				return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
			}

			Account account = userInfoUtil.getAccountInfo();

			if (account != null) {
				itemPriceSelectVo.setEntrpsNo(account.getEntrpsNo());
				itemPriceSelectVo.setMberNo(account.getMberNo());
				itemPriceSelectVo.setFrstRegisterId(account.getId());
				itemPriceSelectVo.setLastChangerId(account.getId());
			}

			if (itemPriceSelectVo.getSleMthdCode().equals("01")) {

				PrSelVO prSelVO = pcInfoService.getNewestPrSelRltm(itemPriceSelectVo.getMetalCode(), itemPriceSelectVo.getItmSn(), itemPriceSelectVo.getDstrctLclsfCode(),
						itemPriceSelectVo.getBrandGroupCode(), itemPriceSelectVo.getBrandCode(), DateUtil.getNowDate());

				if (prSelVO == null) {
					return new ResponseEntity<>("조건에 맞는 실시간 판매가격 정보가 없습니다.", HttpStatus.BAD_REQUEST);
				}

				itemPriceSelectVo.setPremiumNo(prSelVO.getPremiumNo());
				itemPriceSelectVo.setSlePcRltmSn(prSelVO.getSlePcRltmSn());
				itemPriceSelectVo.setLmePcRltmSn(prSelVO.getLmePcRltmSn());
				itemPriceSelectVo.setEhgtPcRltmSn(prSelVO.getEhgtPcRltmSn());
				itemPriceSelectVo.setGoodsUntpc(prSelVO.getEndPc());

			} else if (itemPriceSelectVo.getSleMthdCode().equals("02")) {

				FixPriceVO fixPriceVO = pcInfoService.hasEntrpsFixPriceData(itemPriceSelectVo.getMetalCode(), itemPriceSelectVo.getItmSn(), itemPriceSelectVo.getDstrctLclsfCode(),
						itemPriceSelectVo.getBrandGroupCode(), itemPriceSelectVo.getBrandCode(), account.getEntrpsNo(), DateUtil.getNowDateTime("yyyyMM"));

				if (fixPriceVO == null) {
					return new ResponseEntity<>("조건에 맞는 케이지몰 판매가격 정보가 없습니다.", HttpStatus.BAD_REQUEST);
				}

				itemPriceSelectVo.setPremiumNo(fixPriceVO.getPremiumNo());
				itemPriceSelectVo.setSlePcRltmSn("");
				itemPriceSelectVo.setLmePcRltmSn("");
				itemPriceSelectVo.setEhgtPcRltmSn("");
				itemPriceSelectVo.setGoodsUntpc(fixPriceVO.getSlePc().longValue());
			}

			if (itemPriceSelectVo.getPremiumNo() != null) {
				OrderPricePricingVO orderPricePricingVo = itemPriceService.insertOrderPricing(itemPriceSelectVo);
				itemPriceSelectVo.setPricingNo(orderPricePricingVo.getPricingNo());
			} else {
				return new ResponseEntity<>("조건에 맞는 프리미엄 브랜드 가격정보가 없습니다.", HttpStatus.BAD_REQUEST);
			}

			ItemDtlInfoVO itemDtlInfoVO = new ItemDtlInfoVO();
			itemDtlInfoVO.setItmSn(itemPriceSelectVo.getItmSn());
			itemDtlInfoVO.setBrandCode(itemPriceSelectVo.getBrandCode());

			ItemDtlInfoVO detailVO = itemDtlInfoService.selectItemDtlInfo(itemDtlInfoVO);

			List<ItemDtlInfoVO> stdSpecDtlList = itemDtlInfoService.selectBrandStdSpecDtlList(itemDtlInfoVO);

			if (stdSpecDtlList.isEmpty()) {
				stdSpecDtlList = itemDtlInfoService.selectItmStdSpecDtlList(itemDtlInfoVO);
			}

			rtnMap.put("itemPriceSelectVo", itemPriceSelectVo);
			rtnMap.put("detailVO", detailVO);
			rtnMap.put("stdSpecDtlList", stdSpecDtlList);
			rtnMap.put("preminumPrice", itemPriceService.getFnPreminumPrice(itemPriceSelectVo));
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		}

		return new ResponseEntity<>(rtnMap, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 검색한 상품을 관심 상품에 담는다.
	 * </pre>
	 *
	 * @date 2021. 8. 4.
	 * @author Kwon sun hyung
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 4.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param orderPricingVO
	 * @return String
	 * @throws Exception
	 */
	@PostMapping("/insertOrderBasketInsertOrderPricing")
	@ResponseBody
	public ResponseEntity<Object> insertOrderBasketInsertOrderPricing(@RequestBody ItemPriceSelectVO itemPriceSelectVo) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		if (account != null) {
			int count = itemPriceService.selectOrderBasketCount(itemPriceSelectVo);

			if (count > 4) {
				itemPriceSelectVo.setSuccess("countOver");
				return new ResponseEntity<>(itemPriceSelectVo, HttpStatus.OK);
			}

			String id = account.getId() != null ? account.getId() : "";

			itemPriceSelectVo.setFrstRegisterId(id);
			itemPriceSelectVo.setLastChangerId(id);

			itemPriceSelectVo.setBsktNo(itemPriceService.insertOrderBasket(itemPriceSelectVo));

			if (itemPriceSelectVo.getPricingNo() != null) {
				itemPriceService.insertOrderPricing(itemPriceSelectVo);
			} else {
				return new ResponseEntity<>("조건에 맞는 프리미엄 브랜드 가격정보가 없습니다.", HttpStatus.BAD_REQUEST);
			}

			itemPriceSelectVo.setSuccess("success");
			return new ResponseEntity<>(itemPriceSelectVo, HttpStatus.OK);
		} else {
			return new ResponseEntity<>("로그인되어 있지 않습니다.", HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 검색한 상품을 관심 상품에 담고 제일 마지막의 관심 상품을 삭제한다.
	 * </pre>
	 *
	 * @date 2021. 8. 4.
	 * @author Kwon sun hyung
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 4.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param orderPricingVO
	 * @return String
	 * @throws Exception
	 */
	@PostMapping("/deleteOlderBasketAndInsertOrderBasketInsertOrderPricing")
	@ResponseBody
	public ResponseEntity<Object> deleteOlderBasketAndInsertOrderBasketInsertOrderPricing(@RequestBody ItemPriceSelectVO itemPriceSelectVo) throws Exception {

		Account account = userInfoUtil.getAccountInfo();

		if (account != null) {
			itemPriceSelectVo.setFrstRegisterId(account.getId());
			itemPriceSelectVo.setLastChangerId(account.getId());
		}

		itemPriceService.deleteOlderOrderBasket(itemPriceSelectVo);
		itemPriceSelectVo.setBsktNo(itemPriceService.insertOrderBasket(itemPriceSelectVo));

		if (itemPriceSelectVo.getPricingNo() != null) {
			itemPriceService.insertOrderPricing(itemPriceSelectVo);
		} else {
			return new ResponseEntity<>("조건에 맞는 프리미엄 브랜드 가격정보가 없습니다.", HttpStatus.BAD_REQUEST);
		}

		itemPriceSelectVo.setSuccess("success");
		return new ResponseEntity<>(itemPriceSelectVo, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 검색 상품을 관심 상품에 담지 않고 바로 구매한다.
	 * </pre>
	 *
	 * @date 2022. 2. 21.
	 * @author Kwon sun hyung
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 2. 21.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param itemPriceSelectVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/justBuySearchItem")
	public String viewJustBuySearchItemController(@RequestBody ItemPriceSelectVO itemPriceSelectVo, ModelMap model) {
		try {
			Account account = userInfoUtil.getAccountInfo();

			if (account != null) {
				itemPriceSelectVo.setFrstRegisterId(account.getId());
				itemPriceSelectVo.setLastChangerId(account.getId());
				itemPriceSelectVo.setEntrpsNo(account.getEntrpsNo());
			}

			if (itemPriceSelectVo.getDstrctLclsfNm() != null && !"".equals(itemPriceSelectVo.getDstrctLclsfNm())) {
				itemPriceSelectVo.setDstrctLclsfNm(URLDecoder.decode(itemPriceSelectVo.getDstrctLclsfNm(), "UTF-8"));
			}

			if (itemPriceSelectVo.getBrandGroupNm() != null && !"".equals(itemPriceSelectVo.getBrandGroupNm())) {
				itemPriceSelectVo.setBrandGroupNm(URLDecoder.decode(itemPriceSelectVo.getBrandGroupNm(), "UTF-8"));
			}
			if (itemPriceSelectVo.getBrandNm() != null && !"".equals(itemPriceSelectVo.getBrandNm())) {
				itemPriceSelectVo.setBrandNm(URLDecoder.decode(itemPriceSelectVo.getBrandNm(), "UTF-8"));
			}

			if (itemPriceSelectVo.getMetalNm() != null && !"".equals(itemPriceSelectVo.getMetalNm())) {
				itemPriceSelectVo.setMetalNm(URLDecoder.decode(itemPriceSelectVo.getMetalNm(), "UTF-8"));
			}

			if (itemPriceSelectVo.getMetalNmKorea() != null && !"".equals(itemPriceSelectVo.getMetalNmKorea())) {
				itemPriceSelectVo.setMetalNmKorea(URLDecoder.decode(itemPriceSelectVo.getMetalNmKorea(), "UTF-8"));
			}

			if (itemPriceSelectVo.getGoodsNm() != null && !"".equals(itemPriceSelectVo.getGoodsNm())) {
				itemPriceSelectVo.setGoodsNm(URLDecoder.decode(itemPriceSelectVo.getGoodsNm(), "UTF-8"));
			}

			if (itemPriceSelectVo.getItmNm() != null && !"".equals(itemPriceSelectVo.getItmNm())) {
				itemPriceSelectVo.setItmNm(URLDecoder.decode(itemPriceSelectVo.getItmNm(), "UTF-8"));
			}

			if (itemPriceSelectVo.getDlvyMnNm() != null && !"".equals(itemPriceSelectVo.getDlvyMnNm())) {
				itemPriceSelectVo.setDlvyMnNm(URLDecoder.decode(itemPriceSelectVo.getDlvyMnNm(), "UTF-8"));
			}

			itemPriceSelectVo.setBsktNo(itemPriceService.insertOrderBasket(itemPriceSelectVo));
			String pricingNo = itemPriceService.insertOrderPricing(itemPriceSelectVo).getPricingNo();

			ItemPriceSelectVO settingItemPriceSelectVo = new ItemPriceSelectVO();
			settingItemPriceSelectVo.setEntrpsNo(userInfoUtil.getAccountInfo() != null ? userInfoUtil.getAccountInfo().getEntrpsNo() : "");
			settingItemPriceSelectVo.setPricingNo(pricingNo);
			settingItemPriceSelectVo.setDeleteAt("N");

			// 자투리 일때 자투리 추가
			settingItemPriceSelectVo.setBlRemain("20".equals(itemPriceSelectVo.getBlRemain()) ? "20" : "0");

			if ("20".equals(itemPriceSelectVo.getBlRemain())) {
				settingItemPriceSelectVo.setBlNo(itemPriceSelectVo.getBlNo());
			}

			// 소량 구매일 경우, 파라미터 전달
			if("Y".equals(itemPriceSelectVo.getSmlqyPurchsAt())) {
				settingItemPriceSelectVo.setBlNo(itemPriceSelectVo.getBlNo());
				settingItemPriceSelectVo.setSmlqyPurchsAt("Y");
				settingItemPriceSelectVo.setOrderWt(itemPriceSelectVo.getOrderWt());
				settingItemPriceSelectVo.setSmlqySleInvntryUnsleBundleBnt(itemPriceSelectVo.getSmlqySleInvntryUnsleBundleBnt());
				settingItemPriceSelectVo.setRemainQy(itemPriceSelectVo.getRemainQy());
				settingItemPriceSelectVo.setSmlqySleFtrsAt(itemPriceSelectVo.getSmlqySleFtrsAt());
				settingItemPriceSelectVo.setScreofeFileCours(itemPriceSelectVo.getScreofeFileCours());
			}
			
			// 24-08-30 변경사항 : 가단가구매 여부를 파라미터로 전달
			settingItemPriceSelectVo.setPrvsnlUntpcPurchsSetupAt(itemPriceSelectVo.getPrvsnlUntpcPurchsSetupAt());

			itemPriceMakeOrderProcess(settingItemPriceSelectVo, model, true);

//			// 쿠폰 리스트 가져오는 부분
//			CouponVO couponVO = new CouponVO();
//			couponVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());
//			couponVO.setSearchPmgId("PD");// PD쪽 조회임
//
//			List<CouponVO> couponDtlsList = myCouponDtlsSerivce.selectCouponDtlsList(couponVO);
//
//			model.addAttribute("totalCnt", couponDtlsList.size());
//			model.addAttribute("couponList", couponDtlsList);

			/* 1회 최대 주문 LOT(횟수) */
			int mxmmOrderWt = itemPriceService.selectMxmmOrderWt(itemPriceSelectVo);
			model.addAttribute("mxmmOrderWt", mxmmOrderWt);

			return "pd/itemPriceMakeOrder";/// -----------------------------
		} catch (Exception e) {
			log.error("justBuySearchItem Error ====> {}", ExceptionUtils.getStackTrace(e));
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@RequestMapping("/selectKoreaWeekendList")
	@ResponseBody
	public List<String> selectKoreaWeekendList() throws Exception {
		List<String> resultList = itemPriceService.selectKoreaWeekendList();
		return resultList;
	}

	@RequestMapping("/itemPriceMakeOrderByInventory")
	public String viewItemPriceMakeOrderByInventory(@RequestParam(required = false, value = "pricingNo") String pricingNoGet, @RequestBody(required = false) String pricingNoPost,
			HttpServletRequest request,
			// @RequestBody String pricingNo,
			ModelMap model) {

		String pricingNo = "";

		if (request.getMethod().equals("GET")) {
			pricingNo = pricingNoGet;
		} else if (request.getMethod().equals("POST")) {
			pricingNo = pricingNoPost;
		}

		try {
			ItemPriceSelectVO itemPriceSelectVo = new ItemPriceSelectVO();
			itemPriceSelectVo.setEntrpsNo(userInfoUtil.getAccountInfo() != null ? userInfoUtil.getAccountInfo().getEntrpsNo() : "");
			itemPriceSelectVo.setPricingNo(pricingNo);

			itemPriceMakeOrderProcess(itemPriceSelectVo, model, false);

			/* 1회 최대 주문 수량(톤수) */
			int mxmmOrderWt = itemPriceService.selectMxmmOrderWt(itemPriceSelectVo);
			model.addAttribute("mxmmOrderWt", mxmmOrderWt);

			return "pd/itemPriceMakeOrder";
		} catch (Exception e) {
			log.debug(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: ItemPriceBasket 화면을 보여준다.
	 * </pre>
	 *
	 * @date 2021. 7. 15.
	 * @author Kwon sun hyung
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 15.		Kwon sun hyung		최초작성
	 * 2021. 9. 23.		Kwon sun hyung		수정
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param model
	 * @return String
	 * @throws Exception
	 */
	@RequestMapping("/itemPriceBasket")
	public String viewItemPriceBasketController(@RequestParam(required = false, value = "metalCode") String metalCodeGet, @RequestBody(required = false) ItemPriceSelectVO itemPriceSelectVO,
			HttpServletRequest request, ModelMap model) {

		try {

			String metalCode = "";
			if (request.getMethod().equals("GET")) {
				metalCode = metalCodeGet;
			} else if (request.getMethod().equals("POST")) {
				metalCode = itemPriceSelectVO.getMetalCode();
			}

			List<ItemCodeVO> metalCodeInfoList = new ArrayList<ItemCodeVO>();
			List<ItemCodeVO> entrpsMetalAcctoAuthorVO = itemCodeService.getMbEntrpsMetalAcctoAuthorSetupBasList(userInfoUtil.getEntripsNo());
			List<SelMetalVO> entrpsSelMetalList = pcMntrngService.getEntrpsSelMetalList(userInfoUtil.getEntripsNo(), null, null, null, "login");

			for (ItemCodeVO itemCode : entrpsMetalAcctoAuthorVO) {

				boolean noneMetalCode = entrpsSelMetalList.stream().noneMatch(s -> s.getMetalCode().equals(itemCode.getMetalCode()));
				if (noneMetalCode)
					continue;

				// 라이브가, 고정가, 지정가 여부가 전부 N이면 메탈코드리스트에 추가하지 않는다
				if (itemCode.getLivePcAt().equals("N") && itemCode.getFixingPcAt().equals("N") && itemCode.getAppnPcAt().equals("N"))
					continue;

				if (itemCode.getMetalCode().equals("7")) {
					metalCodeInfoList.add(0, itemCode);
					continue;
				}

				metalCodeInfoList.add(itemCode);
			}

			if (metalCode.equals("")) {
				if (!metalCodeInfoList.isEmpty()) {
					metalCode = metalCodeInfoList.get(0).getSubCode();
				}
			}
			model.addAttribute("metalCodeInfoList", metalCodeInfoList);

			itemPriceSelectVO.setEntrpsNo(userInfoUtil.getAccountInfo() != null ? userInfoUtil.getAccountInfo().getEntrpsNo() : "");
			itemPriceSelectVO.setDeleteAt("N");

			List<ItemPriceSelectVO> itemPriceServiceList = itemPriceService.selectOrderBasketList(itemPriceSelectVO);

			List<PreminumSelVO> fnPreminumPriceVoList = itemPriceService.getFnPreminumPriceVoList(itemPriceServiceList);

			model.addAttribute("itemPriceSelectVo", itemPriceServiceList);
			model.addAttribute("selectMetalCode", metalCode);
			model.addAttribute("preminumPriceList", fnPreminumPriceVoList);

			//JS파일에서 사용 하기위한 JSON데이터로 변환
			ObjectMapper objectMapper = new ObjectMapper();
			String jsonPreminumPriceList = objectMapper.writeValueAsString(fnPreminumPriceVoList);

			model.addAttribute("jsonPreminumPriceList", jsonPreminumPriceList);

//			model.addAttribute("entrpsMetalAcctoAuthorVO", entrpsMetalAcctoAuthorVO);
//			model.addAttribute("httpRequest", request.getMethod());

			return "pd/itemPriceBasket";
		} catch (Exception e) {
			log.error("itemPriceBasket Error ====> {}", ExceptionUtils.getStackTrace(e));
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 관심목록을 삭제한다.
	 * </pre>
	 *
	 * @date 2021. 8. 23.
	 * @author Kwon sun hyung
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param bsktNo
	 */
	@PostMapping("/deleteOrderBasket")
	@ResponseBody
	public ResponseEntity<Object> deleteOrderBasket(@RequestBody String bsktNo) {
		ItemPriceSelectVO itemPriceSelectVO = new ItemPriceSelectVO();
		itemPriceSelectVO.setBsktNo(bsktNo);
		itemPriceSelectVO.setLastChangerId(userInfoUtil.getAccountInfo() != null ? userInfoUtil.getAccountInfo().getId() : "");

		itemPriceService.deleteOrderBasket(itemPriceSelectVO);

		itemPriceSelectVO.setSuccess("success");
		return new ResponseEntity<>(itemPriceSelectVO, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 관심목록을 가져온다.
	 * </pre>
	 *
	 * @date 2022. 05. 06.
	 * @author Ham Seung Jae
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 05. 06.		sjham		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param ItemPriceSelectVO itemPriceSelectVO
	 */
	@PostMapping("/selectOrderBasketList")
	@ResponseBody
	public ResponseEntity<Object> selectOrderBasketList(@RequestBody(required = false) ItemPriceSelectVO itemPriceSelectVO) {

		// 판매방식코드 01:live, 02:고정가 -> 선물처리여부 Y:live, N:고정가
		String metalCode = "";
		String sleMthdCode = "";

		Map<String, Object> returnMap = new HashMap<String, Object>();

		try {
			metalCode = itemPriceSelectVO.getMetalCode();
			sleMthdCode = itemPriceSelectVO.getSleMthdCode();

			ItemPriceSelectVO itemPriceSelectVo = new ItemPriceSelectVO();
			itemPriceSelectVo.setEntrpsNo(userInfoUtil.getAccountInfo() != null ? userInfoUtil.getAccountInfo().getEntrpsNo() : "");
			itemPriceSelectVo.setDeleteAt("N");
			itemPriceSelectVo.setMetalCode(metalCode); // [pje]추가
			itemPriceSelectVo.setSleMthdCode(sleMthdCode); // [pje]추가

			// 관심상품 목록
			// 신규 순으로 정렬 됨
			List<ItemPriceSelectVO> itemPriceServiceBasketList = itemPriceService.selectOrderBasketList(itemPriceSelectVo);
			// 좌측부터 오래된 순으로 정렬하기 위함
//			Collections.reverse(itemPriceServiceBasketList);	// 좌측부터 최신순으로 변경

			List<PreminumSelVO> premiumPriceList = itemPriceService.getFnPreminumPriceVoList(itemPriceServiceBasketList);

			returnMap.put("itemPriceServiceBasketList", itemPriceServiceBasketList);
			returnMap.put("premiumPriceList", premiumPriceList);
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		}
		return new ResponseEntity<>(returnMap, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 주문 화면으로 이동한다.
	 * </pre>
	 *
	 * @date 2021. 9. 24.
	 * @author Kwon sun hyung
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 24.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param entrpsNo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/itemPriceMakeOrder")
	public String viewItemPriceMakeOrderController(@RequestParam(required = false, value = "pricingNo") String pricingNoGet, @RequestBody(required = false) String pricingNoPost,
			HttpServletRequest request,
			// @RequestBody String pricingNo,
			ModelMap model) {

		String pricingNo = "";

		if (request.getMethod().equals("GET")) {
			pricingNo = pricingNoGet;
		} else if (request.getMethod().equals("POST")) {
			pricingNo = pricingNoPost;
		}

		try {
			ItemPriceSelectVO itemPriceSelectVo = new ItemPriceSelectVO();
			itemPriceSelectVo.setEntrpsNo(userInfoUtil.getAccountInfo() != null ? userInfoUtil.getAccountInfo().getEntrpsNo() : "");
			itemPriceSelectVo.setPricingNo(pricingNo);
			itemPriceSelectVo.setDeleteAt("N");

			itemPriceMakeOrderProcess(itemPriceSelectVo, model, false);

			/* 1회 최대 주문 LOT(횟수) */
			int mxmmOrderWt = itemPriceService.selectMxmmOrderWt(itemPriceSelectVo);
			model.addAttribute("mxmmOrderWt", mxmmOrderWt);

			return "pd/itemPriceMakeOrder";
		} catch (Exception e) {
			log.error("itemPriceMakeOrder error message :: {}", ExceptionUtils.getStackTrace(e));
			return "error/503";
		}
	}

	private void itemPriceMakeOrderProcess(ItemPriceSelectVO itemPriceSelectVo, ModelMap model, boolean isJustBuyProcess) throws Exception {

		ItemPriceSelectVO returnItemPriceSelectVo = itemPriceService.selectOrderBasketList(itemPriceSelectVo).get(0);
		
		// 24-09-11 변경사항 : 판매방식이 가단가 구매(05)일 시, LIVE(01) 과 동일한 로직을 수행하도록 코드값 변경 처리
		if(StringUtils.equals(returnItemPriceSelectVo.getSleMthdCode(), "05")) {
			returnItemPriceSelectVo.setSleMthdCode("01");
		}

		String metalCode = returnItemPriceSelectVo.getMetalCode();
		String sleMthdCode = returnItemPriceSelectVo.getSleMthdCode();
		String metalClCode = returnItemPriceSelectVo.getMetalClCode();

		// 차트 데시보드 데이터
		if("01".equals(sleMthdCode)) {
			Map<String, Object> chartList = pcMntrngService.getItemChartDate(metalCode, sleMthdCode, metalClCode);
			model.addAttribute("chartList", chartList);

			//스크립트에서 사용 하기위한 JSON데이터로 변환
			ObjectMapper objectMapper = new ObjectMapper();
			String jsonMainChart = objectMapper.writeValueAsString(chartList);

			model.addAttribute("jsonChartList", jsonMainChart);
		}

		// 소량 구매일 경우
		if("Y".equals(itemPriceSelectVo.getSmlqyPurchsAt())) {
			returnItemPriceSelectVo.setBlNo(itemPriceSelectVo.getBlNo());
			returnItemPriceSelectVo.setSmlqyPurchsAt("Y");
			returnItemPriceSelectVo.setOrderWt(itemPriceSelectVo.getOrderWt());
			returnItemPriceSelectVo.setSmlqySleInvntryUnsleBundleBnt(itemPriceSelectVo.getSmlqySleInvntryUnsleBundleBnt());
			returnItemPriceSelectVo.setRemainQy(itemPriceSelectVo.getRemainQy());
			returnItemPriceSelectVo.setSmlqySleFtrsAt(itemPriceSelectVo.getSmlqySleFtrsAt());
			returnItemPriceSelectVo.setScreofeFileCours(itemPriceSelectVo.getScreofeFileCours());
		}

		// 실재고 체크로직 & 최소중량체크 추가
		BigDecimal realstock = BigDecimal.ZERO;

		if(!"0000000000".equals(returnItemPriceSelectVo.getBrandCode())) {
			realstock = itemPriceService.selectRealStock(returnItemPriceSelectVo);
		} else {
			//브랜드무관일경우 브랜드별 실재고 총중량중 최대중량으로 조회
			realstock = itemPriceService.selectRealStockByBrandCodeIrrelevant(returnItemPriceSelectVo);
		}

		ItemPriceSelectVO itmInfoBasVo = itemPriceService.selectItmInfoBas(returnItemPriceSelectVo);
		returnItemPriceSelectVo.setRealStock(realstock);
		returnItemPriceSelectVo.setMinToleranceRate(itmInfoBasVo.getMinToleranceRate());
		returnItemPriceSelectVo.setSleUnitWt( itmInfoBasVo.getSleUnitWt() );
		returnItemPriceSelectVo.setOnceSlePossWt( itmInfoBasVo.getOnceSlePossWt() );

		// 자투리 일때 자투리 추가
		returnItemPriceSelectVo.setBlRemain("20".equals(itemPriceSelectVo.getBlRemain()) ? "20" : "0");

		if ("20".equals(itemPriceSelectVo.getBlRemain())) {
			// returnItemPriceSelectVo.setBlRealStock(itemPriceService.selectBlinfoBas(itemPriceSelectVo));
			returnItemPriceSelectVo.setBlNo(itemPriceSelectVo.getBlNo());
		}
		
		// 24-08-30 변경사항 : 가단가구매 여부가 Y 일 시, 가단가구매 정보 조회 및 세팅
		if(StringUtils.equals(itemPriceSelectVo.getPrvsnlUntpcPurchsSetupAt(), "Y")) {	// 가단가구매 여부가 Y 일시
			returnItemPriceSelectVo.setPrvsnlUntpcPurchsSetupAt(itemPriceSelectVo.getPrvsnlUntpcPurchsSetupAt());	// Y로 세팅
			
			// 가단가 구매 정보
			Map<String, Object> prvsnlUntpcInfo = itemPriceService.getPrvsnlUntpcInfo(returnItemPriceSelectVo.getEntrpsNo());
			
			// 조회 결과가 있으면 세팅
			if(!CollectionUtils.isEmpty(prvsnlUntpcInfo)) {
				// 가단가 출고 수량 제한 (=잠정 단가 출고 최대 수량)
				int prvsnlUntpcDlivyMxmmQy = (int) Optional.ofNullable(prvsnlUntpcInfo.get("prvsnlUntpcDlivyMxmmQy")).orElse(0);
				returnItemPriceSelectVo.setPrvsnlUntpcDlivyMxmmQy(prvsnlUntpcDlivyMxmmQy);
				
				// 단가 미확정 중량
				int pcUnDcsnWt = (int) Optional.ofNullable(prvsnlUntpcInfo.get("pcUnDcsnWt")).orElse(0);
				returnItemPriceSelectVo.setPcUnDcsnWt(pcUnDcsnWt);
			}
			
			// 조정계수 조회
	        CommFtrsFshgMngVO ftrsFshgMngVO = Optional.ofNullable(commFtrsFshgMngService.commFtrsFshgManageDtlListByToday("B").stream()
	                                                  .filter(data -> ( StringUtils.equals(data.getMetalCode(), metalCode))).collect(Collectors.toList()).get(0))
	                                                  .orElse(new CommFtrsFshgMngVO());
	        
	        model.addAttribute("ftrsFshgMngVO", ftrsFshgMngVO);
	        
	        // 24-10-16 변경사항 : 가격 변동금 실시간 평가를 위한 가격 변동금 설정 조회
	        model.addAttribute("pcChangegldInfoByJSON", itemPriceService.getPcChangegldInfoByJSONString(returnItemPriceSelectVo));
	        
	        // 24-11-19 변경사항 : 가격변동금 설정값 조회
	        model.addAttribute("pcChangegldInfoList", itemPriceService.getPcChangegldInfoList(returnItemPriceSelectVo));
	        
	        // 24-11-22 변경사항 : 주문일(금일) 기준 시초가 조회 및 세팅
	        model.addAttribute("beginPc", itemPriceService.getTodaysBeginPc(returnItemPriceSelectVo));
		}

		model.addAttribute("itemPriceSelectVo", returnItemPriceSelectVo);
		model.addAttribute("dlvyMnCode", itemPriceService.getCodeListAfterRemoveSubName(commonCodeService.getSubCodes("DLVY_MN_CODE")));
		model.addAttribute("entrpsDlvrg", entrpsDlvrgService.getEntrpsDlvrgList(returnItemPriceSelectVo.getEntrpsNo()));
		model.addAttribute("deliveryRequestDate", new ObjectMapper().writeValueAsString(itemPriceService.selectDeliveryRequestDate(returnItemPriceSelectVo.getMetalCode())));
		model.addAttribute("metalCode", returnItemPriceSelectVo.getMetalCode());
		model.addAttribute("preminumPrice", itemPriceService.getFnPreminumPrice(returnItemPriceSelectVo));

		// 20211220 주문 모달창에 약관 추가
		List<EntrpsEtrVO> selectOrderStplat = entrpsEtrService.selectEntrpsEtrStplat();
		if (selectOrderStplat == null || selectOrderStplat.size() == 0) {
			model.addAttribute("orderStplatInfo", new EntrpsEtrVO());
		} else {
			List<EntrpsEtrVO> filterSelectOrderStplat = selectOrderStplat.stream().filter(data -> (StringUtils.equals(data.getStplatSeCode(), "01"))).collect(Collectors.toList());
			if (filterSelectOrderStplat == null || filterSelectOrderStplat.size() == 0) {
				model.addAttribute("orderStplatInfo", new EntrpsEtrVO());
			} else {
				model.addAttribute("orderStplatInfo", filterSelectOrderStplat.get(0));
			}
		}

		// 2023-04-19 신규 주문 모달창에 필요한 데이터 추가
		if(!StringUtils.equals(returnItemPriceSelectVo.getSleMthdCode(), "02")) {	// 케이지몰(고정가) 주문이 아닐때만 데이터 추가
			// 1. 지정가 서비스 약관 관련 데이터 추가
			for (EntrpsEtrVO entrpsEtrVO : selectOrderStplat) {
				if(StringUtils.equals(entrpsEtrVO.getStplatSeCode(), "11")) {	// 11 : 지정가 서비스 약관
					model.addAttribute("limitsOrderStplat", entrpsEtrVO);
					break;
				}
			}

			// 2. 브랜드 변동금 안내 목록 데이터 추가
			List<LivePremiumVO> brandChangeAmountList = Optional.ofNullable(
					pcInfoService.getLivePremiumInfoList(
						"present", null, returnItemPriceSelectVo.getMetalCode()
						, returnItemPriceSelectVo.getItmSn(), returnItemPriceSelectVo.getDstrctLclsfCode(), returnItemPriceSelectVo.getBrandGroupCode()
						, null, DateUtil.getNowDateTime("yyyyMMddHHmmss")
					)
				).orElseThrow(() -> {return new CommCustomException("프리미엄 가격 미존재,\n관리자에게 문의 바랍니다.");})
				.stream().filter(livePremiumVO -> !StringUtils.equals(livePremiumVO.getBrandCode(), "0000000000")).collect(Collectors.toList());

			model.addAttribute("brandChangeAmountList", brandChangeAmountList);

			// 3. 선택한 브랜드 변동금 데이터 추가
			// 23-05-17 변경사항 : "브랜드 무관" 선택 시, 금액이 제일 큰 브랜드 변동금을 추가한다.
			if(StringUtils.equals(returnItemPriceSelectVo.getBrandCode(), "0000000000")) {
				model.addAttribute("brandChangeAmount", brandChangeAmountList.get(0).getBrandChangeAmount());
			} else {
				for (LivePremiumVO livePremiumVO : brandChangeAmountList) {
					if(StringUtils.equals(livePremiumVO.getBrandCode(), returnItemPriceSelectVo.getBrandCode())) {
						model.addAttribute("brandChangeAmount", livePremiumVO.getBrandChangeAmount());
						break;
					}
				}
			}

			// 4. 금일 Live 주문 중, 브랜드까지 동일한 주문 리스트(가격, 수량, 시간)
			model.addAttribute("liveOrderList", itemPriceService.selectLiveOrderList(returnItemPriceSelectVo));

			// 5. 금일 체결된 지정가 주문 중, 브랜드까지 동일한 지정가 주문 관련 데이터 추가
			// 소량구매일 경우, 특정 BL에 대한 지정가 주문 데이터로 조회
			Map<String, Object> limitOrderData = itemPriceService.selectLimitOrderData(returnItemPriceSelectVo);
			model.addAttribute("limitOrderTotalCnt", limitOrderData.get("limitOrderTotalCnt"));
			model.addAttribute("limitOrderListMap", limitOrderData.get("limitOrderListMap"));

			// 6. 지정가 주문 가능 여부 check
			// 23-06-23 변경사항 : 지정가 주문 불가능 사유 항목 추가 (Front 단에서 지정가 radio 버튼 mouseover 시, 툴팁으로 안내)
			model.addAttribute("limitOrderPossAt", itemPriceService.getLimitOrderPossAt(returnItemPriceSelectVo));

			// 7. 영엽시간 데이터 추가
			model.addAttribute("rltmTime", itemPriceService.selectSalesTime());

			// 23-07-10 변경사항 : 실시간 재고 데이터 수신 uri 및 실시간 재고 데이터 추가
			// 8. 실시간 재고 데이터 수신 uri
			model.addAttribute("invntryUri", invntryUri);

			// 9. 실시간 재고 데이터 : 해당 브랜드 전체에 대한 실시간 재고 조회
			String key = String.join("_"
					, returnItemPriceSelectVo.getMetalCode()
					, String.valueOf(returnItemPriceSelectVo.getItmSn())
					, returnItemPriceSelectVo.getDstrctLclsfCode()
					, returnItemPriceSelectVo.getBrandGroupCode()
					, returnItemPriceSelectVo.getBrandCode());
			// 소량구매일 경우, 해당 BL에 대한 실시간 재고 조회
			if("Y".equals(itemPriceSelectVo.getSmlqyPurchsAt())) {
				key += "_" + returnItemPriceSelectVo.getBlNo();
			}
			InvntrySttusVO invntrySttusVO = invntrySttusService.getInvntrySttusInfoMap(metalCode).get(key);
			long totSleInvntryUnsleBundleBnt = invntrySttusVO == null ? 0 : invntrySttusVO.getTotSleInvntryUnsleBundleBnt();
			model.addAttribute("totSleInvntryUnsleBundleBnt", totSleInvntryUnsleBundleBnt);

			// 10. 쿠폰 리스트
			CouponVO couponVO = new CouponVO();
			couponVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());
			couponVO.setMetalCode(metalCode);
//			couponVO.setSearchPmgId("PD");// PD쪽 조회임

			List<CouponVO> untCouponList = myCouponDtlsSerivce.couponList(couponVO, "01");
			List<CouponVO> dlvyCouponList = myCouponDtlsSerivce.couponList(couponVO, "03");

			model.addAttribute("untCouponList", untCouponList);
			model.addAttribute("dlvyCouponList", dlvyCouponList);

			/* 페이백 기능 추가 2024/02/14 */
			//회원_업체 등급 기준 구매 수량
			MbEntrpsGradVO mbEntrpsGradStdrPurchsQy = dashboardService.selectMbEntrpsGradStdrPurchsQy();
			model.addAttribute("mbEntrpsGradStdrPurchsQy", mbEntrpsGradStdrPurchsQy);
			//등급 할인 금액 리스트
			List<MbEntrpsGradVO> mbGradDscntAmountList = dashboardService.selectMbGradDscntAmountList();
			model.addAttribute("mbGradDscntAmountList", mbGradDscntAmountList);
			//당월 구매 수량
			int totRealOrderWtSum = dashboardService.selectMbTotRealOrderWtSum(userInfoUtil.getAccountInfo().getEntrpsNo());
			model.addAttribute("totRealOrderWtSum", totRealOrderWtSum);
			//전월 기준 구매 정보(MB_ENTRPS_MNBY_PURCHS_BNEF_BAS)
			MbEntrpsGradVO mbEntrpsMnbyPurchsInfo = dashboardService.mbEntrpsMnbyPurchsInfo(userInfoUtil.getAccountInfo().getEntrpsNo());
			model.addAttribute("mbEntrpsMnbyPurchsInfo", mbEntrpsMnbyPurchsInfo);
			//상시 할인 금액 리스트(3000,4000,5000)
			List<MbEntrpsGradVO> cpAtmcIsuCouponInfoList= dashboardService.selectcpAtmcIsuCouponInfoList();
			model.addAttribute("cpAtmcIsuCouponInfoList", cpAtmcIsuCouponInfoList);
			/* 페이백 기능 추가 끝 */
			
			// 11. 회원 등급별 즉시할인 데이터
			MbEntrpsGradVO mbEntrpsGradVO = new MbEntrpsGradVO();
			mbEntrpsGradVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());
			mbEntrpsGradVO.setMetalCode(metalCode);

			model.addAttribute("mbEntrpsGradVO", itemPriceService.getDscntAmount(mbEntrpsGradVO));

			//지정가 야간장 선택 가능한 일자
			String limitOrderNightTime = itemPriceService.getMinLimitOrderNightTime(metalCode, DateUtil.getNowDate(), 2);

			model.addAttribute("limitOrderNightTime", limitOrderNightTime);

			//운영 종료 시간(지정가 야간장 시간)
			RltmEndTimeVO rltmEndTimeVO = bsnInfoService.getRltmEndTime();

			model.addAttribute("rltmEndTimeVO", rltmEndTimeVO);
		}

		// 업체 결제 수단 정보 가져오기
		// : 업체의 증거금과 전자상거래보증 사용 권한(증거금 총 사용 여부, 전자상거래보증 또는 케이지크레딧 총 사용 여부), 증거금 신청
		// 여부(화면단 별도 체크), 담보 보증 신청 여부(화면단 별도 체크), 연체 및 사고 건수
		// : 증거금 최소 결제 예정일 조건
		// : 판매 단위 중량 (주문 가능 MIN 중량 및 주문 단위), 1회 구매 중량 한도 (주문 가능 MAX 중량)
		// : 업체 별 평가 등급 정보(여신 구간, 담보 보증 허용 상환 기간)
		// : 업체 구매성향 등급정보(업체 구매성향등급, 업체 구매성향등급 명, 증거금 권한 비율)
		// : 구매성향등급에 따른 단계별 금액(LME 전일 종가[케이지몰일 경우 현재 단가], 구간 종료 금액, 구간 평균 금액)
		// : 업체의 선택 가능한 구매등급을 표시한 전체 정보 리스트
		// : 여신 정보(금리 정보, 패널티 정보)
		if (userInfoUtil.getAccountInfo() != null) {
			Account accountInfo = userInfoUtil.getAccountInfo();
			String entrpsNo = accountInfo.getEntrpsNo() != null ? accountInfo.getEntrpsNo() : "";
			String entrpsPayBackDscntUseAt = accountInfo.getEntrpsPayBackDscntUseAt() != null ? accountInfo.getEntrpsPayBackDscntUseAt() : "Y";
			String entrpsMnbyPurchsBnefUseAt = accountInfo.getEntrpsMnbyPurchsBnefUseAt() != null ? accountInfo.getEntrpsMnbyPurchsBnefUseAt() : "Y";
			String secode = accountInfo.getSecode() != null ? accountInfo.getSecode() : "";
			OrderEntrpsSetleMnVO entrpsSetleMnInfo = orderService.getEntrpsSetleMnInfo(entrpsNo, returnItemPriceSelectVo.getSleMthdCode(), returnItemPriceSelectVo.getMetalCode(),
					returnItemPriceSelectVo.getItmSn(), returnItemPriceSelectVo.getDstrctLclsfCode(), returnItemPriceSelectVo.getBrandGroupCode(), returnItemPriceSelectVo.getBrandCode(), null);
			
			// 24-08-30 변경사항 : 가단가구매 여부가 Y 일 시, 부분 출고 상환 여부를 "N"으로 세팅
			if(StringUtils.equals(itemPriceSelectVo.getPrvsnlUntpcPurchsSetupAt(), "Y")) {	// 가단가구매 여부가 Y 일시
				entrpsSetleMnInfo.setPartDlivyRepyAt("N");
			}
			
			model.addAttribute("entrpsSetleMnInfo", entrpsSetleMnInfo);

			// 판매가능중량조회(최적BL적용)
			returnItemPriceSelectVo.setEntrpsNo(entrpsNo);
			ItemPriceMatchingSelectVO itemPriceMatchingSelectVO = itemPriceService.getItemPriceCompare(returnItemPriceSelectVo, isJustBuyProcess);

			// 20220203 배송지 등록관련 조회 추가
			List<DeliveryRegionMngVO> mbDlvrgSeDtlList = deliveryRegionMngService.selectMbDlvrgSeDtlListList(entrpsNo);
			List<CommonCodeVO> domainList = deliveryRegionMngService.selectemailDomainList();

			model.addAttribute("itemPriceMatchingSelectVO", itemPriceMatchingSelectVO);
			model.addAttribute("mbDlvrgSeDtlList", mbDlvrgSeDtlList);
			model.addAttribute("domainList", domainList);
			model.addAttribute("entrpsNo", entrpsNo);
			model.addAttribute("entrpsPayBackDscntUseAt", entrpsPayBackDscntUseAt);
			model.addAttribute("entrpsMnbyPurchsBnefUseAt", entrpsMnbyPurchsBnefUseAt);
			model.addAttribute("mberSeCode", secode);
		}

		List<DeliveryRegionMngVO> mbDlvrgSeDtlList2 = deliveryRegionMngService.selectMbDlvrgSeDtlListList("all");

		model.addAttribute("mbDlvrgSeDtlList2", mbDlvrgSeDtlList2);
		// 23-07-05 변경사항 : 고객 센터 전화 번호 추가
		model.addAttribute("csTel", commonCodeService.getSubCodesRetVo("SORIN_SETUP_CODE", "CS_TEL").get("CS_TEL").getCodeDcone());
		model.addAttribute("preEndPc", itemPriceService.getOrderPreEndPc(returnItemPriceSelectVo));
	}

	/**
	 * <pre>
	 * 처리내용: 검색 조건에 맞는 ItemBL을 검색하고 매칭 Algorithm을 사용하여 값을 반환한다. 또한 검색 내용을 OrderPricing 테이블에 저장한다.
	 * </pre>
	 *
	 * @date 2021. 7. 15.
	 * @author Kwon sun hyung
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 15.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param itemPriceVO
	 * @return List<ItemPriceVO>
	 * @throws Exception
	 */
	@PostMapping("/searchItemBLWithMatcingList")
	@ResponseBody
	public ResponseEntity<Object> insertSearchItemBLWithMatcingList(@RequestBody ItemPriceSelectVO itemPriceSelectVo, ModelMap model) throws Exception {
		Account account = userInfoUtil.getAccountInfo();

		int ordSleUnitWt, ordOnceSlePossWt, ordMaxCnt = 0;

		HashMap<String, String> resultMap = itemPriceService.getOrderWeightLimit(account, itemPriceSelectVo, true);

		if ("itemOnce".equals(resultMap.get("type"))) {  
			return new ResponseEntity<>("상품별 1회 구매중량 한도가 초과 되었습니다.\n문의 사항은 고객센터(02-6952-5905)로 연락 주시기 바랍니다", HttpStatus.BAD_REQUEST);
		} else if ("itemOnede".equals(resultMap.get("type"))) {
			return new ResponseEntity<>("상품별 1일 구매중량 한도가 초과 되었습니다.\n내일 다시 구매해주세요.\n문의 사항은 고객센터(02-6952-5905)로 연락 주시기 바랍니다", HttpStatus.BAD_REQUEST);
		} else if ("entrpsOnce".equals(resultMap.get("type"))) {
			return new ResponseEntity<>("업체별 1회 구매중량 한도가 초과 되었습니다.\n문의 사항은 고객센터(02-6952-5905)로 연락 주시기 바랍니다.", HttpStatus.BAD_REQUEST);
		} else if ("entrpsOnede".equals(resultMap.get("type"))) {
			return new ResponseEntity<>("업체별 1일 구매중량 한도가 초과 되었습니다.\n내일 다시 구매해주세요.\n문의 사항은 고객센터(02-6952-5905)로 연락 주시기 바랍니다", HttpStatus.BAD_REQUEST);
		} else if ("empty".equals(resultMap.get("type"))) {
			return new ResponseEntity<>("업체등급 중량정보가 없습니다.", HttpStatus.NO_CONTENT);
		} else {
			// 브랜드 무관일 경우
			if (itemPriceSelectVo.getBrandCode().equals("0000000000")) {
				List<String> brandCodeList = new ArrayList<>();
				List<BrandCodeVO> brandCodeVoList = brandCodeService.getBrandCodeList(itemPriceSelectVo.getBrandGroupCode(), userInfoUtil.getEntripsNo());

				for (BrandCodeVO brandCodeVo : brandCodeVoList) {
					brandCodeList.add(brandCodeVo.getSubCode());
				}

				itemPriceSelectVo.setBrandCodeList(brandCodeList);
			}

			ItemPriceMatchingSelectVO itemPriceMatchingSelectVo = new ItemPriceMatchingSelectVO();
			itemPriceMatchingSelectVo.setOrderWeight(itemPriceSelectVo.getOrderWeight());
			itemPriceMatchingSelectVo.setDistrictLargeCode(itemPriceSelectVo.getDstrctLclsfCode());
			itemPriceMatchingSelectVo.setMetalCode(itemPriceSelectVo.getMetalCode());
			itemPriceMatchingSelectVo.setItemSn(itemPriceSelectVo.getItmSn());
			itemPriceMatchingSelectVo.setBrandGroupCode(itemPriceSelectVo.getBrandGroupCode());
			itemPriceMatchingSelectVo.setBrandCode(itemPriceSelectVo.getBrandCode());
			itemPriceMatchingSelectVo.setBrandCodeList(itemPriceSelectVo.getBrandCodeList());
			itemPriceMatchingSelectVo.setEnterpriseNo(userInfoUtil.getEntripsNo());
			itemPriceMatchingSelectVo.setSleUnitWt(itemPriceSelectVo.getSleUnitWt());
			itemPriceMatchingSelectVo.setOnceSlePossWt(itemPriceSelectVo.getOnceSlePossWt());

			// 지정 BL 명
			itemPriceMatchingSelectVo.setBlNo(itemPriceSelectVo.getBlNo());
			itemPriceMatchingSelectVo.setSmlqyPurchsAt(itemPriceSelectVo.getSmlqyPurchsAt()); // 소량구매 여부
			// List<ItemPriceMatchingBlInfoVO> blInfo =
			// itemPriceMatchingService.itemBLWithMatchingList(itemPriceMatchingSelectVo,
			// 25, 100, 4, 1);
			//
			Map<String, Object> returnMap = new HashMap<>();
			//
			// returnMap.put("itemPriceMatchingBlInfoVoList", blInfo);

			List<ItemPriceMatchingBlInfoVO> blInfo = null;

			if (itemPriceSelectVo.getSleMthdCode().equals("01")) {
				PrSelVO prSelVO = pcInfoService.getNewestPrSelRltm(itemPriceSelectVo.getMetalCode(), itemPriceSelectVo.getItmSn(), itemPriceSelectVo.getDstrctLclsfCode(),
						itemPriceSelectVo.getBrandGroupCode(), itemPriceSelectVo.getBrandCode(), DateUtil.getNowDate());

				if (prSelVO == null) {
					return new ResponseEntity<>("조건에 맞는 실시간 판매가격 정보가 없습니다.", HttpStatus.BAD_REQUEST);
				}
				// log.warn("returnList---------------------------!!!!!!!!!!!!!!!!!!!!!!!!!!! VO
				// = " + itemPriceMatchingSelectVo.toString());
				// log.warn("returnList---------------------------!!!!!!!!!!!!!!!!!!!!!!!!!!!
				// weightUnit = " + 25);
				// log.warn("returnList---------------------------!!!!!!!!!!!!!!!!!!!!!!!!!!!
				// onceSlePossWt = " + 100);
				// log.warn("returnList---------------------------!!!!!!!!!!!!!!!!!!!!!!!!!!! ??
				// = " + 4);

				itemPriceMatchingSelectVo.setSellMethodCode(itemPriceSelectVo.getSleMthdCode());

				ordSleUnitWt = itemPriceMatchingSelectVo.getSleUnitWt();
				ordOnceSlePossWt = itemPriceMatchingSelectVo.getOnceSlePossWt();
				ordMaxCnt = ordOnceSlePossWt / ordSleUnitWt ;

				blInfo = itemPriceMatchingService.itemBLWithMatchingList(itemPriceMatchingSelectVo, ordSleUnitWt, ordOnceSlePossWt, ordMaxCnt, ordSleUnitWt);
				returnMap.put("itemPriceMatchingBlInfoVoList", blInfo);
				returnMap.put("endPc", prSelVO.getEndPc());
				returnMap.put("premiumNo", prSelVO.getPremiumNo()); // 실시간일 경우 주문 시 사용할 프리미엄번호를 여기서 넘겨준다. OR_ORDER_BAS의 고객프리미엄번호에 들어감, 20211210 추가
				returnMap.put("slePcRltmSn", prSelVO.getSlePcRltmSn()); // 실시간일 경우 주문 시 사용할 판매 가격 실시간 순번를 여기서 넘겨준다. OR_ORDER_BAS의 고객 판매 가격 실시간 순번에 들어감,
																		// 20211210 추가
				returnMap.put("lmePcRltmSn", prSelVO.getLmePcRltmSn()); // 실시간일 경우 주문 시 사용할 LME 가격 실시간 순번를 여기서 넘겨준다. OR_ORDER_BAS의 고객 LME 가격 실시간 순번에
																		// 들어감, 20211210 추가
				returnMap.put("ehgtPcRltmSn", prSelVO.getEhgtPcRltmSn()); // 실시간일 경우 주문 시 사용할 환율 가격 실시간 순번를 여기서 넘겨준다. OR_ORDER_BAS의 고객 환율 가격 실시간 순번에 들어감,
																			// 20211210 추가

				returnMap.put("getTotRealOrderWtByItm", resultMap.get("getTotRealOrderWtByItm"));	//실제주문중량
			} else if (itemPriceSelectVo.getSleMthdCode().equals("02")) {

				FixPriceVO fixPriceVO = pcInfoService.hasEntrpsFixPriceData(itemPriceSelectVo.getMetalCode(), itemPriceSelectVo.getItmSn(), itemPriceSelectVo.getDstrctLclsfCode(),
						itemPriceSelectVo.getBrandGroupCode(), itemPriceSelectVo.getBrandCode(), account.getEntrpsNo(), DateUtil.getNowDateTime("yyyyMM"));

				if (fixPriceVO == null) {
					return new ResponseEntity<>("조건에 맞는 케이지몰 판매가격 정보가 없습니다.", HttpStatus.BAD_REQUEST);
				}

				itemPriceMatchingSelectVo.setSellMethodCode(itemPriceSelectVo.getSleMthdCode());
				blInfo = itemPriceMatchingService.itemBLWithMatchingList(itemPriceMatchingSelectVo, 1, 25, 4, 1);

				returnMap.put("itemPriceMatchingBlInfoVoList", blInfo);
				returnMap.put("endPc", fixPriceVO.getSlePc());
				returnMap.put("premiumNo", fixPriceVO.getPremiumNo()); // 고정가일 경우 주문 시 사용할 프리미엄번호를 여기서 넘겨준다. OR_ORDER_BAS의 고객프리미엄번호에 들어감, 20211210 추가
			}

			int sumWrhousngOrderWeight = 0;
			int sumOrderWeight = 0;
			
			
			Date today = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			String minDate = sdf.format(today);

			if (blInfo.size() > 0) {
				if(!blInfo.get(0).getLeftOverExistYn()) {
					for (int i = 0; i < blInfo.size(); i++) {
						//가재고 시
						if ("4".equals(blInfo.get(i).getWrhousngSeCode())) {
							sumWrhousngOrderWeight = blInfo.get(i).getOrderWeight().intValue();
						} else {
							sumOrderWeight += blInfo.get(i).getOrderWeight().intValue();
						}
					}
				}
			}

			//배송요청일
			List<ItemPriceMatchingBlInfoVO> dlvyRqestdeAdjust =	blInfo.stream()
																						.filter(h -> (h.getDlvyRqestdeAdjust() != null))
																						.filter(h -> (h.getDlvyRqestdeAdjust().length() > 0 ))
																						.sorted(Comparator.comparing(ItemPriceMatchingBlInfoVO :: getDlvyRqestdeAdjust).reversed())
																						.collect(Collectors.toList());
			//판매가능일
			List<ItemPriceMatchingBlInfoVO> slePossde =	blInfo.stream()
																			.filter(h -> (h.getSlePossde() != null && h.getWrhousngPrearngeInvntryAt() != null))
																			.filter(h -> (h.getSlePossde().length() > 0 ))
																			.sorted(Comparator.comparing(ItemPriceMatchingBlInfoVO :: getSlePossde).reversed())
																			.collect(Collectors.toList());
					
			//배송 요청일 조정(우선순위), 판매가능일 중 배송요청일이 현재 날짜보다 클때 (입고 예정 재고 여부 != null)
			if(dlvyRqestdeAdjust.size() > 0 ) {
				if(sdf.parse(minDate).before(sdf.parse(dlvyRqestdeAdjust.get(0).getDlvyRqestdeAdjust().replaceAll("-", "")))){
					minDate = dlvyRqestdeAdjust.get(0).getDlvyRqestdeAdjust().replaceAll("-", "");
				}
			}else if(slePossde.size() > 0 && slePossde.get(0).getWrhousngPrearngeInvntryAt().equals("Y")) {
				if(sdf.parse(minDate).before(sdf.parse(slePossde.get(0).getSlePossde().replaceAll("-", "")))){
					minDate = slePossde.get(0).getSlePossde().replaceAll("-", "");
				}
			}
			
			returnMap.put("sumWrhousngOrderWeight", sumWrhousngOrderWeight);
			returnMap.put("sumOrderWeight", sumOrderWeight);
			returnMap.put("minDate", minDate);

			return new ResponseEntity<>(returnMap, HttpStatus.OK);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 브랜드 그룹에 맞는 브랜드 리스트를 가져온다.
	 * </pre>
	 *
	 * @date 2021. 7. 15.
	 * @author Kwon sun hyung
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 15.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param itemPriceVO
	 * @return List<BrandCodeVO>
	 * @throws Exception
	 */
	@PostMapping("/selectBrandCodeList")
	@ResponseBody
	public List<BrandCodeVO> selectBrandCodeList(@RequestBody ItemPriceSelectVO itemPriceSelectVo) throws Exception {
		List<BrandCodeVO> rtnBrandCodeList = new ArrayList<BrandCodeVO>();

		try {
			String brandGroupCode = itemPriceSelectVo.getBrandGroupCode();
			boolean clickAt = false;
			if(itemPriceSelectVo.getClickbutton() == null || itemPriceSelectVo.getClickbutton().isEmpty()) {
				clickAt = false;
			}else {
				if(itemPriceSelectVo.getClickbutton().equals("Y")) {
					clickAt = true;
				}else {
					clickAt = false;
				}
			}
			
			List<BrandCodeVO> brandCodeList = brandCodeService.getBrandCodeList(brandGroupCode, userInfoUtil.getEntripsNo(), clickAt);

			// 실재고 체크로직 & 최소중량체크 추가
			itemPriceSelectVo.setSubBrandCodeList(brandCodeList);

			rtnBrandCodeList.addAll(itemPriceService.selectRealStockBrandList(itemPriceSelectVo));
			int remainCnt = 0;
			for (BrandCodeVO brandCodeVO : brandCodeList) {
				if ("20".equals(brandCodeVO.getBlRemain())) {
					// 체크 해당 BL 인지
					itemPriceSelectVo.setBlNo(brandCodeVO.getRemainBlNo());
					itemPriceSelectVo.setNationFlagImgUrl(brandCodeVO.getNationFlagUrl());
					if (itemPriceService.isSelectItemBL(itemPriceSelectVo)) {
						brandCodeVO.setBlRemainCnt(++remainCnt);
						rtnBrandCodeList.add(brandCodeVO);
					}
				}
			}

			/* 1회 최대 주문 LOT(횟수) */
			itemPriceSelectVo.setEntrpsNo(userInfoUtil.getAccountInfo() != null ? userInfoUtil.getAccountInfo().getEntrpsNo() : "");
			int mxmmOrderWt = itemPriceService.selectMxmmOrderWt(itemPriceSelectVo);
			if(mxmmOrderWt==0) {
				rtnBrandCodeList.clear();
			}

		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		}

		return rtnBrandCodeList;
	}

	/**
	 * <pre>
	 * 처리내용: 브랜드 그룹에 맞는 B/L 과 성적서다운로드정보를 가져온다.
	 * </pre>
	 *
	 * @date 2022. 7. 29.
	 * @author srec0067
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 7. 29.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param paramMap
	 * @return Map<String, Object>
	 * @throws Exception
	 */
	@PostMapping("/selectScreofeList")
	@ResponseBody
	public Map<String, Object> selectScreofeList(@RequestBody List<String> blNoList) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		// 성적서조회
		List<Map<String, Object>> screofeList = itemPriceService.selectScreofeList(blNoList);

		map.put("screofeList", screofeList);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 프리미엄가격정보에 따른 우선 유무체크를 한다.
	 * </pre>
	 *
	 * @date 2021. 8. 11.
	 * @author srec0067
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 15.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param itemPriceVO
	 * @return List<ItemPriceVO>
	 * @throws Exception
	 */
	@PostMapping("/validateFnPremiumInfoEmptyYn")
	@ResponseBody
	public ResponseEntity<Object> validateFnPremiumInfoEmptyYn(@RequestBody(required = false) String pricingNo, HttpServletRequest request, ModelMap model) throws Exception {
		try {
			String entrpsNo = userInfoUtil.getAccountInfo() != null ? userInfoUtil.getAccountInfo().getEntrpsNo() : "";
			ItemPriceSelectVO itemPriceSelectVo = new ItemPriceSelectVO();
			itemPriceSelectVo.setEntrpsNo(entrpsNo);
			itemPriceSelectVo.setPricingNo(pricingNo);
			itemPriceSelectVo.setDeleteAt("N");

			ItemPriceSelectVO returnItemPriceSelectVo = itemPriceService.selectOrderBasketList(itemPriceSelectVo).get(0);

			returnItemPriceSelectVo.setEntrpsNo(entrpsNo);

			if (returnItemPriceSelectVo.getSleMthdCode().equals("01")) {

				PrSelVO prSelVO = pcInfoService.getNewestPrSelRltm(returnItemPriceSelectVo.getMetalCode(), returnItemPriceSelectVo.getItmSn(), returnItemPriceSelectVo.getDstrctLclsfCode(),
						returnItemPriceSelectVo.getBrandGroupCode(), returnItemPriceSelectVo.getBrandCode(), DateUtil.getNowDate());

				if (prSelVO == null) {
					return new ResponseEntity<>("조건에 맞는 실시간 판매가격 정보가 없습니다.", HttpStatus.BAD_REQUEST);
				}

			} else if (returnItemPriceSelectVo.getSleMthdCode().equals("02")) {

				FixPriceVO fixPriceVO = pcInfoService.hasEntrpsFixPriceData(returnItemPriceSelectVo.getMetalCode(), returnItemPriceSelectVo.getItmSn(), returnItemPriceSelectVo.getDstrctLclsfCode(),
						returnItemPriceSelectVo.getBrandGroupCode(), returnItemPriceSelectVo.getBrandCode(), returnItemPriceSelectVo.getEntrpsNo(), DateUtil.getNowDateTime("yyyyMM"));

				if (fixPriceVO == null) {
					return new ResponseEntity<>("조건에 맞는 케이지몰 판매가격 정보가 없습니다.", HttpStatus.BAD_REQUEST);
				}
			}
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		}

		return new ResponseEntity<>(HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 입고예정정보를 조회한다(메탈,권역기준)
	 * </pre>
	 *
	 * @date 2022. 11. 16.
	 * @author srec0067
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 16.
	 *          srec0067 최초작성 ------------------------------------------------
	 * @param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectStockInfoList")
	@ResponseBody
	public String selectStockInfoList(@RequestBody(required = false) ItemPriceSelectVO itemPriceSelectVo) throws Exception {
		JSONArray stockInfoList = itemPriceService.selectStockInfoList(itemPriceSelectVo);
//		log.debug("stockInfoList : " + stockInfoList);

		return stockInfoList.toString();
	}

	/**
	 * <pre>
	 * 처리내용: 케이지몰 아이템 정보에 맞는 옵션 리스트를 가져온다.
	 * </pre>
	 *
	 * @date 2022. 11. 14.
	 * @author srec0068
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			    작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 11. 14.	srec0068		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param IsecoCommVO
	 * @return List<CommonCodeVO>
	 * @throws Exception
	 */
	@PostMapping("/selectFixOptions")
	@ResponseBody
	public List<IsecoCommVO> selectFixOptions(@RequestBody IsecoCommVO isecoCommVO) throws Exception {
		String entrpsNo = userInfoUtil.getEntripsNo();
		int itmSn = isecoCommVO.getItmSn();
		String srhGubunCode = isecoCommVO.getSrhGubunCode();

		isecoCommVO.setEntrpsNo(entrpsNo);
		List<IsecoCommVO> optionList = isecoCommService.getIsEcoSearchList(isecoCommVO);
		List<IsecoCommVO> resultOptionList = new ArrayList<IsecoCommVO>();

		for(IsecoCommVO option : optionList) {
			String brandGroupCode = option.getBrandGroupCode() != null ? option.getBrandGroupCode() : "00";
			String brandCode = option.getBrandCode() != null ? option.getBrandCode() : "0000000000";

			List<FixPriceVO> stdrFixPriceList = pcInfoService.hasEntrpsFixPriceDataList(isecoCommVO.getMetalCode(), isecoCommVO.getMetalClCode(), itmSn, option.getDstrctLclsfCode(),
					brandGroupCode, brandCode, entrpsNo, DateUtil.getNowDateTime("yyyyMM"));

			if(stdrFixPriceList != null) {
				for(FixPriceVO stdrFixPrice : stdrFixPriceList) {
					String fixingPcOrderPossWtYn = orderService.getFixingPcOrderPossWtCeck(stdrFixPrice.getDstrctLclsfCode(), stdrFixPrice.getItmSn()
							, entrpsNo, stdrFixPrice.getSorinmallUnitPdCode(), stdrFixPrice.getLmttWt(), 0, isecoCommVO.getSleMthdCode());

					Boolean srchRequire = "Y".equals(fixingPcOrderPossWtYn);

					if("03".equals(srhGubunCode)) {
						srchRequire = "Y".equals(fixingPcOrderPossWtYn) && option.getDstrctLclsfCode().equals(stdrFixPrice.getDstrctLclsfCode());
					} else if("04".equals(srhGubunCode)) {
						srchRequire = "Y".equals(fixingPcOrderPossWtYn) && isecoCommVO.getDstrctLclsfCode().equals(stdrFixPrice.getDstrctLclsfCode())
								&& brandGroupCode.equals(stdrFixPrice.getBrandGroupCode());
					} else if("05".equals(srhGubunCode)) {
						srchRequire = "Y".equals(fixingPcOrderPossWtYn) && isecoCommVO.getDstrctLclsfCode().equals(stdrFixPrice.getDstrctLclsfCode())
								&& brandGroupCode.equals(stdrFixPrice.getBrandGroupCode()) && brandCode.equals(stdrFixPrice.getBrandCode());
					}

					if(srchRequire) {
						resultOptionList.add(option);
					}
				}
			}
		}

		return resultOptionList;
	}

	/**
	 * <pre>
	 * 처리내용: 케이지몰 금속의 재고 정보를 확인한다
	 * </pre>
	 *
	 * @date 2022. 11. 18.
	 * @author srec0067
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 18.
	 *          srec0068 최초작성 ------------------------------------------------
	 * @param Map<String, Object>
	 * @return int
	 * @throws Exception
	 */
	@PostMapping("/selectIsecoStock")
	@ResponseBody
	public int selectIsecoStock(@RequestBody IsecoCommVO param) throws Exception {
		int stock = isecoCommService.getSleInvntryUnsleBundleBnt(param);
		return stock;
	}

	/**
	 * <pre>
	 * 처리내용: 케이지몰 가격정보 및 업체/아이템별 구매제한중량과 주문중량을 체크해서 주문가능여부를 조회한다.
	 * </pre>
	 *
	 * @date 2021. 8. 11.
	 * @author srec0067
	 * @history
	 *
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 11.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 *
	 * @param itemPriceVO
	 * @return List<ItemPriceVO>
	 * @throws Exception
	 */
	@PostMapping("/selectFixPriceDataByUnavailableCheck")
	@ResponseBody
	public ResponseEntity<Object> selectFixPriceDataByUnavailableCheck(@RequestBody(required = false) FixPriceVO fixPriceVO) throws Exception {
		Map<String, Object> returnMap = new HashMap<>();

		try {
			String entrpsNo = userInfoUtil.getEntripsNo();
			FixPriceVO stdrFixPrice = pcInfoService.hasEntrpsFixPriceData(fixPriceVO.getMetalCode(), fixPriceVO.getItmSn(), fixPriceVO.getDstrctLclsfCode()
					, fixPriceVO.getBrandGroupCode(), fixPriceVO.getBrandCode(), entrpsNo, DateUtil.getNowDateTime("yyyyMM"));

			if(stdrFixPrice != null) {
				String fixingPcOrderPossWtYn = orderService.getFixingPcOrderPossWtCeck(stdrFixPrice.getDstrctLclsfCode(), stdrFixPrice.getItmSn()
						, entrpsNo, stdrFixPrice.getSorinmallUnitPdCode(), stdrFixPrice.getLmttWt(), fixPriceVO.getOrderWeight(), "02");

				returnMap.put("fixingPcOrderPossWtYn", fixingPcOrderPossWtYn);
				returnMap.put("slePc", stdrFixPrice.getSlePc());
				returnMap.put("premiumNo", stdrFixPrice.getPremiumNo());
				returnMap.put("lmttWt", stdrFixPrice.getLmttWt() != null ? Double.valueOf(stdrFixPrice.getLmttWt()).intValue() : stdrFixPrice.getLmttWt());
			} else {
				returnMap.put("fixingPcOrderPossWtYn", "N");
				returnMap.put("slePc", 0);
				returnMap.put("premiumNo", "");
				returnMap.put("lmttWt", "0");
			}

		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		}
		return new ResponseEntity<>(returnMap, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 상품검색 메탈종목별 검색조건리스트조회(아이템, 권역, 브랜드그룹, 브랜드)
	 * </pre>
	 * @date 2023. 10. 16.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 16.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/getMetalItemSrchList")
	ResponseEntity<Object> getMetalItemSrchList(@RequestBody(required = false) ItemPriceSelectVO itemPriceSelectVO) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();

		try {

			if(SRCH_CODE_ITEM.equals(itemPriceSelectVO.getGoodsSrchcode())) {
				List<ItemCodeVO> itemList = itemCodeService.getItemFtrsProcessAtCodeList(itemPriceSelectVO.getMetalCode(), "Y");
				rtnMap.put("itmSnList", itemList);
			} else if(SRCH_CODE_BRAND.equals(itemPriceSelectVO.getGoodsSrchcode()) || SRCH_CODE_ITEM_BRAND_SRCH.equals(itemPriceSelectVO.getGoodsSrchcode())) {
				List<BrandCodeVO> returnBrandCodeList = new ArrayList<BrandCodeVO>();

				/* 1회 최대 주문 LOT(횟수) */
				itemPriceSelectVO.setEntrpsNo(userInfoUtil.getEntripsNo());
				int mxmmOrderWt = itemPriceService.selectMxmmOrderWt(itemPriceSelectVO);
				if(mxmmOrderWt==0) {
					returnBrandCodeList.clear();
				} else {
					
					List<BrandCodeVO> brandCodeList = brandCodeService.getBrandCodeList(itemPriceSelectVO.getMetalCode(), itemPriceSelectVO.getBrandGroupCode(), userInfoUtil.getEntripsNo());
					itemPriceSelectVO.setSubBrandCodeList(brandCodeList);

					// 실재고 체크로직 & 최소중량체크 추가
					itemPriceSelectVO.setEntrpsNo(userInfoUtil.getEntripsNo());
					returnBrandCodeList.addAll(itemPriceService.selectRealStockBrandList(itemPriceSelectVO));

					AtomicInteger remainCnt = new AtomicInteger(0);

					returnBrandCodeList.stream()
					.filter(data -> {
						if ("20".equals(data.getBlRemain())) {
							itemPriceSelectVO.setBlNo(data.getRemainBlNo());
							itemPriceSelectVO.setNationFlagImgUrl(data.getNationFlagUrl());

							try {
								if (itemPriceService.isSelectItemBL(itemPriceSelectVO)) {
									data.setBlRemainCnt(remainCnt.incrementAndGet());
								}
							} catch (Exception e) {
								log.error("[ItemPriceController][isSelectItemBL]" + ExceptionUtils.getStackTrace(e));
							}
						}
						return true;
					})
					.collect(Collectors.toList());
				}

				returnBrandCodeList.sort(Comparator.comparing(BrandCodeVO::getItmSn).thenComparing(BrandCodeVO::getDstrctLclsfCode).thenComparing(BrandCodeVO::getDstrctMlsfcCode).thenComparing(BrandCodeVO::getBrandGroupCode));
				rtnMap.put("brandCodeList", returnBrandCodeList);
			}
		} catch (Exception e) {
			log.error("[ItemPriceController][getMetalItemSrchList]" + ExceptionUtils.getStackTrace(e));
		}

		return new ResponseEntity<>(rtnMap, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 소량구매 상품 목록 조회
	 * </pre>
	 * @date 2024. 5. 14.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 5. 14.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	@RequestMapping("/getMetalSmlqySrchList")
	public ResponseEntity<Object> getMetalSmlqySrchList(@RequestBody(required = false) ItemPriceSelectVO itemPriceSelectVO) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		try {

			List<BrandCodeVO> returnBrandCodeList = new ArrayList<BrandCodeVO>();

			List<BrandCodeVO> brandCodeList = brandCodeService.getBrandCodeList(itemPriceSelectVO.getMetalCode(), itemPriceSelectVO.getBrandGroupCode(), userInfoUtil.getEntripsNo());
			itemPriceSelectVO.setSubBrandCodeList(brandCodeList);
			itemPriceSelectVO.setEntrpsNo(userInfoUtil.getEntripsNo());

			// 소량구매 재고 체크		
			returnBrandCodeList.addAll(itemPriceService.selectRealStockSmlqyPurchsList(itemPriceSelectVO));
			
			returnBrandCodeList.stream()
			.filter(data -> {
				if ("N".equals(data.getSmlqySleFtrsAt()) || data.getRemainQy() < 1) {
					// 선물 잔량 없음 or 소량 판매 선물 여부-N => [번들 선택 구매] 영역으로 노출
					data.setSmlqySleFtrsAt("N");
					data.setRemainQy(0);
				}
				return true;
			})
			.collect(Collectors.toList());
			
			// 데이터 정렬 - 선물 체결 여부, 아이템 순번, 권역, 물류 센터
			returnBrandCodeList.sort(Comparator.comparing(BrandCodeVO::getSmlqySleFtrsAt).thenComparing(BrandCodeVO::getItmSn).thenComparing(BrandCodeVO::getDstrctLclsfCode).thenComparing(BrandCodeVO::getDstrctMlsfcCode).thenComparing(BrandCodeVO::getWrhousCode).thenComparing(BrandCodeVO::getBrandGroupCode));
			rtnMap.put("brandCodeList", returnBrandCodeList);
		} catch (Exception e) {
			log.error("[ItemPriceController][getMetalSmlqySrchList]" + ExceptionUtils.getStackTrace(e));
		}

		return new ResponseEntity<>(rtnMap, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 새로고침 등의 잘못된 페이지 접근의 예외를 처리하기 위한 핸들러 메소드
	 *
	 * 22-12-13 변경사항 : 공통에서 처리되도록 수정, Controller 내부 Handler 는 주석 처리
	 * </pre>
	 *
	 * @date 2022. 12. 8.
	 * @author srec0053
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 12. 8.
	 *          srec0053 최초작성 ------------------------------------------------
	 * @param e
	 * @return
	 */
//	@ExceptionHandler(HttpMessageNotReadableException.class)
//    public Object CustomHttpMessageNotReadableException(Exception e) {
//        log.error("HttpMessageNotReadableException ---- :" + e);
//        log.error("e.getMessage() : " + e.getMessage());
//
//        String errorMessage = e.getMessage();
//
//        /*
//         * 예외 처리 대상 페이지 호출 메소드 목록, error/400 페이지 리턴
//         * viewJustBuySearchItemController	<- 상품 직접 구매 시 호출
//         * viewItemPriceMakeOrderController	<- 관심 상품 목록에서 구매 시 호출
//         */
//        if(errorMessage.indexOf("viewJustBuySearchItemController") > -1 || errorMessage.indexOf("viewItemPriceMakeOrderController") > -1) {
//            return "error/400.tiles";
//        } else {
//            log.error("Exception CustomHttpMessageNotReadableException ---- :" + e);
//
//            if (null==(e.getCause())) {
//                return new ResponseEntity<>("CustomHttpMessageNotReadableException : " + e.getMessage(), HttpStatus.BAD_REQUEST);
//            }
//
//            if(e.getCause().getClass() == InvalidFormatException.class) {
//                return new ResponseEntity<>("잘못된 형태의 값이 입력되었습니다.", HttpStatus.BAD_REQUEST);
//            } else {
//                return new ResponseEntity<>("CustomHttpMessageNotReadableException : " + e.getMessage(), HttpStatus.BAD_REQUEST);
//            }
//        }
//    }
}
