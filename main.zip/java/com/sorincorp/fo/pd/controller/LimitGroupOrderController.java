package com.sorincorp.fo.pd.controller;

import java.util.concurrent.CompletableFuture;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.comm.order.model.CommLimitGroupModel;
import com.sorincorp.fo.pd.comm.constant.PdCommConstant;
import com.sorincorp.fo.pd.comm.entity.PdResponseEntity;
import com.sorincorp.fo.pd.service.AsyncLimitOrderService;

import lombok.extern.slf4j.Slf4j;

/**
 * LimitGroupOrderController.java
 * 지정가 그룹 주문 Controller 클래스
 * 
 * @version
 * @since 2023. 4. 27.
 * @author srec0049
 */
@Slf4j
@RequestMapping("/fo/pd/limit")
@RestController
public class LimitGroupOrderController {
	
	@Autowired
	AsyncLimitOrderService asyncLimitOrderService;
	
	
	/**
	 * <pre>
	 * 처리내용: 지정가 그룹 주문 진행
	 *  1) 비동기로 응답을 줄 때까지 대기하지 않는다.
	 *  2) 서비스 단계에서 병렬로 그룹 내 주문을 한꺼번에 처리한다.
	 * </pre>
	 * @date 2023. 5. 9.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 9.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commLimitGroupModel
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/groupOrder")
	public CompletableFuture<ResponseEntity<PdResponseEntity>> groupOrder(@RequestBody CommLimitGroupModel commLimitGroupModel, HttpServletRequest request) throws Exception {
		log.info(">> limitGroupOrderController doLimitGroupOrder commLimitGroupModel : " + String.valueOf(commLimitGroupModel));
		
		// 지정가 그룹 주문 진행
		asyncLimitOrderService.doLimitGroupOrder(commLimitGroupModel);
		
		return CompletableFuture.completedFuture(ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, null)));
	}

	/**
	 * <pre>
	 * 처리내용: 가단가 지정가 그룹 주문 진행
	 * </pre>
	 * @date 2024. 8. 27.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 8. 27.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param commLimitGroupModel
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/groupPrvsnlOrder")
	public CompletableFuture<ResponseEntity<PdResponseEntity>> groupPrvsnlOrder(@RequestBody CommLimitGroupModel commLimitGroupModel, HttpServletRequest request) throws Exception {
		log.info(">> limitGroupOrderController doPrvsnlLimitGroupOrder commLimitGroupModel : " + String.valueOf(commLimitGroupModel));

		// 가단가 지정가 그룹 주문 진행
		asyncLimitOrderService.doPrvsnlLimitGroupOrder(commLimitGroupModel);

		return CompletableFuture.completedFuture(ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, null)));
	}

	///////////////////////////////
	// 아래 로직 쓰레드 테스트용 //
	///////////////////////////////
	
	/**
	 * <pre>
	 * 처리내용: 지정가 그룹 주문 진행 쓰레드 테스트 (로직은 빈 껍데기)
	 * </pre>
	 * @date 2023. 5. 23.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 23.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commLimitGroupModel
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/groupOrderThreadTest")
	public CompletableFuture<ResponseEntity<PdResponseEntity>> groupOrderThreadTest(@RequestBody CommLimitGroupModel commLimitGroupModel, HttpServletRequest request) throws Exception {
		//log.info(">> limitGroupOrderController doLimitGroupOrderThreadTest commLimitGroupModel : " + String.valueOf(commLimitGroupModel));
		
		for(int a=0; a<commLimitGroupModel.getTempInvntryCeckWt(); a++) {
			// 지정가 그룹 주문 진행 (로직은 빈 껍데기)
			asyncLimitOrderService.doLimitGroupOrderThreadTest(commLimitGroupModel);
			Thread.sleep(10);
		}
		
		return CompletableFuture.completedFuture(ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, null)));
	}
}
