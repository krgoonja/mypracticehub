package com.sorincorp.fo.pd.service;

import java.util.concurrent.CompletableFuture;

import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.order.model.CommLimitGroupModel;
import com.sorincorp.comm.order.model.OrderModel;

/**
 * AsyncLimitOrderService.java
 * 지정가 그룹 주문 Service 인터페이스
 * 
 * @version
 * @since 2023. 4. 28.
 * @author srec0049
 */
public interface AsyncLimitOrderService {
	
	/**
	 * <pre>
	 * 처리내용: 지정가 그룹 주문 진행
	 * </pre>
	 * @date 2023. 5. 9.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 9.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commLimitGroupModel
	 * @return
	 * @throws Exception
	 */
	public void doLimitGroupOrder(CommLimitGroupModel commLimitGroupModel) throws CommCustomException, Exception;
	
	/**
	 * <pre>
	 * 처리내용: 가단가 지정가 그룹 주문 진행
	 * </pre>
	 * @date 2024. 8. 27.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 8. 27.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public void doPrvsnlLimitGroupOrder(CommLimitGroupModel commLimitGroupModel) throws CommCustomException, Exception;

	/**
	 * <pre>
	 * 처리내용: 지정가 그룹 주문 진행 쓰레드 테스트 (로직은 빈 껍데기)
	 * </pre>
	 * @date 2023. 5. 23.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 23.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commLimitGroupModel
	 * @return
	 * @throws CommCustomException
	 * @throws Exception
	 */
	public void doLimitGroupOrderThreadTest(CommLimitGroupModel commLimitGroupModel) throws CommCustomException, Exception;
}
