package com.sorincorp.fo.pd.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.bsnInfo.model.RltmEndTimeVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.entrpsgrade.model.EntrpsGradeVO;
import com.sorincorp.comm.entrpsgrade.service.EntrpsGradeService;
import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.invntry.model.InvntrySttusVO;
import com.sorincorp.comm.invntry.service.InvntrySttusService;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.message.mapper.CdtlnMessageMapper;
import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.model.OrderInfoVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.CdtlnMessageService;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.constant.CommFtrsConstant;
import com.sorincorp.comm.order.model.CnAvrgpcFshgBasVO;
import com.sorincorp.comm.order.model.CnAvrgpcFtrsBasVO;
import com.sorincorp.comm.order.model.CnCntrctOrderBasVO;
import com.sorincorp.comm.order.model.CommAvrgPcInvntryVO;
import com.sorincorp.comm.order.model.CommFtrsFshgMngVO;
import com.sorincorp.comm.order.model.CommOrOrderFtrsBasVO;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.comm.order.model.ItPurchsInfoBas;
import com.sorincorp.comm.order.model.OrOrderAvrgpcDtlVO;
import com.sorincorp.comm.order.model.OrderEntrpsSetleMnVO;
import com.sorincorp.comm.order.model.OrderMbEntrpsMlgInfoDtlVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.comm.order.model.OrderPurchsInclnGradeVO;
import com.sorincorp.comm.order.service.CommAvrgPcInvntryService;
import com.sorincorp.comm.order.service.CommAvrgpcOrderService;
import com.sorincorp.comm.order.service.CommDashboardWebsocketService;
import com.sorincorp.comm.order.service.CommFrontOrderWebsocketService;
import com.sorincorp.comm.order.service.CommFtrsFshgMngService;
import com.sorincorp.comm.order.service.CommLimitOrderRedisPubService;
import com.sorincorp.comm.order.service.CommLimitOrderService;
import com.sorincorp.comm.order.service.CommOrderService;
import com.sorincorp.comm.order.service.CommPrvsnlOrderService;
import com.sorincorp.comm.pcInfo.model.FixPriceVO;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.chart.service.PcMntrngService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.model.MbEntrpsGradVO;
import com.sorincorp.fo.mb.service.EntrpsEtrService;
import com.sorincorp.fo.my.model.CouponDtlVO;
import com.sorincorp.fo.my.service.DashboardService;
import com.sorincorp.fo.my.service.MyCouponDtlsSerivce;
import com.sorincorp.fo.pd.comm.constant.PdCommConstant;
import com.sorincorp.fo.pd.comm.constant.PdPropertyConstant;
import com.sorincorp.fo.pd.mapper.OrderMapper;
import com.sorincorp.fo.pd.model.CredtCdtlnInfoVO;
import com.sorincorp.fo.pd.model.FixingPcOrderPossWtCeckVO;
import com.sorincorp.fo.pd.model.ItemDtlInfoVO;
import com.sorincorp.fo.pd.model.ItemPriceSelectVO;
import com.sorincorp.fo.pd.model.LimitOrderModel;
import com.sorincorp.fo.pd.model.OrGrntyInfoVO;
import com.sorincorp.fo.pd.model.OrUntpcDcsnDeChangeDtlVO;
import com.sorincorp.fo.pd.model.OrderEtcPrice;
import com.sorincorp.fo.pd.model.OrderItWrtmStdrAmoutMangeVO;
import com.sorincorp.fo.pd.model.OrderLimitReceiptVO;
import com.sorincorp.fo.pd.model.SettleSttusDeVO;

import lombok.extern.slf4j.Slf4j;

/**
 * OrderServiceImpl.java
 * 주문 Service 구현체 클래스
 * @version
 * @since 2022. 9. 21.
 * @author srec0049
 */
@Slf4j
@Service
public class OrderServiceImpl implements OrderService {

    /** 주문 스레드 풀 */
    @Resource(name = "orderThreadPool")
    private ThreadPoolTaskExecutor taskExecutor;

    /** 공통 채번 서비스 */
    @Autowired
    private AssignService assignService;

    /** 이메일 발송 서비스 */
    @Autowired
    private MailService mailService;

    /** SMS 발송 서비스 */
    @Autowired
    private SMSService smsService;

    /** 실시간 판매 가격 서비스 */
    @Autowired
    private PcInfoService pcInfoService;

    /** 사이트 운영 설정 서비스 */
    @Autowired
    private BsnInfoService bsnInfoService;

    /** 공통 코드 서비스 */
    @Autowired
    private CommonCodeService commonCodeService;

    /** 아이템 코드 서비스 */
    @Autowired
    private ItemCodeService itemCodeService;

    /** 선물 선물환 관리 서비스 */
    @Autowired
    private CommFtrsFshgMngService commFtrsFshgMngService;

    /** 쿠폰 서비스 */
    @Autowired
    private MyCouponDtlsSerivce myCouponDtlsSerivce;

    /** 업체별 등급 서비스 */
    @Autowired
    private EntrpsGradeService entrpsGradeService;

    /** 공통 서비스 */
    @Autowired
    private CommonService commonService;

    /** 주문 공통 Service */
    @Autowired
    private CommOrderService commOrderService;

    /** 평균가 주문 공통 Service  */
    @Autowired
    private CommAvrgpcOrderService commAvrgpcOrderService;

    /** 평균가 재고 공통 Service  */
    @Autowired
    private CommAvrgPcInvntryService commAvrgPcInvntryService;

    @Autowired
    private InvntrySttusService invntrySttusService;

    /** 주문 매퍼 */
    @Autowired
    private OrderMapper orderMapper;

    /** 이메일 발송 매퍼 */
    @Autowired
    private MailMapper mailMapper;

    /** 외부 연계 api 호출 모듈 */
    @Autowired
    private HttpClientHelper httpClientHelper;

    /** 프로퍼티 상수 */
    @Autowired
    private PdPropertyConstant orProperty;

    /** 공통 여신 메시지/이메일 발송 공통 매퍼*/
    @Autowired
    private CdtlnMessageMapper cdtlnMessageMapper;


    /** 공통 여신 메시지/이메일 발송 공통 서비스*/
    @Autowired
    private CdtlnMessageService cdtlnMessageService;

    @Autowired
    private CommLimitOrderRedisPubService commLimitOrderRedisPubService;

    /**
     * 지정가 주문 공통 Service
     */
    @Autowired
    CommLimitOrderService commLimitOrderService;

    /** 지정가 주문 FO 구독 웹소켓 서비스 */
    @Autowired
    private CommFrontOrderWebsocketService commFrontOrderWebsocketService;

    /** 지정가 주문 BO 구독 웹소켓 서비스 */
    @Autowired
    private CommDashboardWebsocketService commDashboardWebsocketService;

    /** MO 서브도메인 */
    @Value("${spring.mfo.domain}")
    private String mfoDomain;

    @Autowired
    private ItemPriceService itemPriceService;

    @Autowired
    private UserInfoUtil userInfoUtil;

    @Autowired
    private EntrpsEtrService entrpsEtrService;

    @Autowired
    private PcMntrngService pcMntrngService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
	private DashboardService dashboardService;
    
    /**
     * 가단가 주문 공통 Service
     */
    @Autowired
    private CommPrvsnlOrderService commPrvsnlOrderService;

    @Value("${redisPubsub.uri.invntry}")
	private String invntryUri;

    /**
     * 주문 모달창 화면으로 보내는 배송비 계산 값
     */
    @Override
    public HashMap<String, Object> getDlvyPrice(OrderModel orderModel) throws CommCustomException, Exception {
        // 주문 초기 데이터 설정
        initOrderData(orderModel);

        return commOrderService.getCheckDataDlvyTariff(orderModel, orderModel.getOrderWt(), true);
    }


    /**
     * 주문 모달창 화면으로 보내는 쿠폰할인이 적용되는 최종 계산 값
     * 쿠폰 할인 가격 조회
     */
    @Override
    public HashMap<String, Object> getDiscntCouponPrice(OrderModel orderModel) throws CommCustomException, Exception {

        // 쿠폰 할인 가격 조회
        initPriceData(orderModel);

        return commOrderService.getCheckDataDlvyTariff(orderModel, orderModel.getOrderWt(), true);
    }

    /**
     * <pre>
     * 처리내용: 주문 초기 데이터 설정
     * </pre>
     * @date 2022. 4. 12.
     * @author srec0049
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 4. 12.         srec0049            최초작성
     * ------------------------------------------------
     * @param orderModel
     * @throws CommCustomException
     * @throws Exception
     */
    public void initPriceData(OrderModel orderModel) throws CommCustomException, Exception {

    }

    /**
     * <pre>
     * 처리내용: (판매 방식 코드 , 배송 수단 코드, 금속 코드) 조건에 의한 현재 시각, 당일배송 불가능 상태 및 당일배송 종료 시간을 맵으로 가져온다.
     * 당일배송 가능 여부 값도 여기서 set
     * </pre>
     * @date 2022. 3. 8.
     * @author srec0049
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 3. 8.          srec0049            최초작성
     * ------------------------------------------------
     * @param orderModel
     * @return
     * @throws CommCustomException
     * @throws Exception
     */
    public Map<String, Object> getSameDayDeliveryInfo(OrderModel orderModel) throws CommCustomException, Exception {
        Map<String, Object> resultMap = new HashMap<String, Object>();

        String dlivyRequstDe = orderModel.getDlivyRequstDe().replaceAll("-", ""); // 배송요청일
        String getNowDate = DateUtil.getNowDate(); // 현재날짜
        log.debug(">> getNowDate : " + getNowDate + ", dlivyRequstDe : " + dlivyRequstDe + ", orderModel.getMetalCode : " + orderModel.getMetalCode()
            + ", orderModel.getDlvyMnCode : " + orderModel.getDlvyMnCode() + ", orderModel.getSleMthdCode : " + orderModel.getSleMthdCode() + ", orderModel.getEntrpsNo() : " + orderModel.getEntrpsNo());

        boolean sameDayDeliveryStatus = true; // 가능 상태
        String sameDayDeliveryCloseTime = null; // 당일배송 종료 시간

        String todayDlvyAt = "N"; // 당일배송 가능 여부

        // 판매방식이 LIVE/평균가일 경우에 당일배송 체크, 서린몰은 체크하지 않는다.
        if(StringUtils.equals(orderModel.getSleMthdCode(), "01") 
        		|| StringUtils.equals(orderModel.getSleMthdCode(), "04")
        		|| StringUtils.equals(orderModel.getSleMthdCode(), "05")) {
            // 당일배송 날짜에 불가능한 시각일 경우 불가능 상태(false)를 준다.
            // 당일배송 날짜가 아닐 경우 가능 상태(true), 당일배송 날짜에 가능한 시각일 경우 가능 상태(true)를 준다.
            if(StringUtils.equals(getNowDate, dlivyRequstDe)) { // 당일배송일 경우
                if(orderMapper.chkSameDayDelivery(orderModel) == 0) { // 당일배송이 불가능한 시각
                    sameDayDeliveryStatus = false; // 불가능 상태

                    // 당일배송 종료 시간 가져오기
                    sameDayDeliveryCloseTime = orderMapper.getSameDayDeliveryCloseTime(orderModel);
                } else {
                    todayDlvyAt = "Y";
                }
            }
        }

        resultMap.put("sameDayDeliveryStatus", sameDayDeliveryStatus); // 가능 상태
        resultMap.put("sameDayDeliveryCloseTime", sameDayDeliveryCloseTime); // 당일배송 종료 시간
        resultMap.put("todayDlvyAt", todayDlvyAt); // 당일배송 가능 여부

        //orderModel.getDstrctMlsfcCode(orderMapper.getDstrctMlsfcCode(orderModel);)

        //getCheckDataDlvyTariff(orderModel, orderModel.getOrderWt(), true);

        String lastSvcSeCode = ""; // 서비스 구분 코드 [00:정상, 01:배송불가, 02:서비스가능지역아님]
        String dstrctMlsfcNm = ""; // 권역 중분류 코드명
        long sectionPrice = 0; // 구간금액

        if(StringUtils.equals(orderModel.getDlvyMnCode(), "01")) {
            // 배송 요율 조회를 위한 기본조건 설정
            commOrderService.setDlvyTariffBaseInfo(orderModel);

            long dlvyPrice = 0L;

            Map<String, String> selectDlvyTariffInfo = commOrderService.selectDlvyTariffInfo(orderModel);
            log.warn(">> getCheckDataDlvyTariff selectDlvyTariffInfo : " + selectDlvyTariffInfo);
            if(selectDlvyTariffInfo != null) {
                dlvyPrice = Long.parseLong(Optional.ofNullable(String.valueOf(selectDlvyTariffInfo.get("DLVY_TARIFF"))).orElse("0"));
                lastSvcSeCode = String.valueOf(selectDlvyTariffInfo.get("SVC_SE_CODE")); // 서비스 구분 코드
                dstrctMlsfcNm = String.valueOf(selectDlvyTariffInfo.get("DSTRCT_MLSFC_NM")); // 권역 중분류 코드명
                sectionPrice = dlvyPrice; // 구간금액
            }
        }
        resultMap.put("dlvyMnCode", orderModel.getDlvyMnCode());
        resultMap.put("lastSvcSeCode", lastSvcSeCode);
        resultMap.put("dstrctMlsfcNm", dstrctMlsfcNm);
        resultMap.put("sectionPrice", sectionPrice);

        // 쿠폰 리스트 가져오는 부분
        CouponDtlVO couponVO = new CouponDtlVO();
        couponVO.setEntrpsNo(orderModel.getEntrpsNo());
        couponVO.setSearchPmgId("PD");// PD쪽 조회임
        couponVO.setDlvyMnCode(orderModel.getDlvyMnCode());// PD쪽 조회임

        List<CouponDtlVO> couponDtlsList = myCouponDtlsSerivce.selectCouponDtlsList(couponVO);

        resultMap.put("totalCnt", couponDtlsList.size() == 0? 0 : couponDtlsList.size());
        resultMap.put("couponList", couponDtlsList);

        return resultMap;
    }

    /**
     * 주문 초기 데이터 설정
     */
    @Override
    public void initOrderData(OrderModel orderModel) throws CommCustomException, Exception {
        // 주문 홀딩 사용 여부
        orderModel.setOrderHoldingUseAt(Optional.ofNullable(orProperty.getOrderHoldingUseAt()).orElse("N"));
        // 주문 CAPA 관리 여부
        orderModel.setOrderCapaManageAt(Optional.ofNullable(orProperty.getOrderCapaManageAt()).orElse("N"));

        String metalCode = orderModel.getMetalCode();
        CommonCodeVO metalCodeInfo = Optional.ofNullable(commonCodeService.getCodeValueRetVo("METAL_CODE", metalCode)).orElseThrow(() -> {
            log.info("OrderServiceImpl initOrderData line-475 vo.toString() >> " + orderModel.toString());
            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
            return new CommCustomException("공통코드_메탈코드 정보가 없습니다.");});

        // 평균가-평균가 주문은 제외
        if(!StringUtils.equals(orderModel.getSleMthdCode(), "04")) {
            // lme 수집 시간 간격 값
            log.warn(">> orProperty.getLmeColctTimeIntrvlVal() : " + orProperty.getLmeColctTimeIntrvlVal());
            int lmeColctTimeIntrvlVal = Optional.ofNullable(orProperty.getLmeColctTimeIntrvlVal()).orElseThrow(() -> {
                log.info("OrderServiceImpl initOrderData line-451 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                return new CommCustomException("lme 수집 시간 간격 값이 없습니다.");});
            orderModel.setLmeColctTimeIntrvlVal(lmeColctTimeIntrvlVal);

            // 환율 수집 시간 간격 값
            log.warn(">> orProperty.getEhgColctTimeIntrvlVal() : " + orProperty.getEhgColctTimeIntrvlVal());
            int ehgColctTimeIntrvlVal = Optional.ofNullable(orProperty.getEhgColctTimeIntrvlVal()).orElseThrow(() -> {
                log.info("OrderServiceImpl initOrderData line-458 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                return new CommCustomException("환율 수집 시간 간격 값이 없습니다.");});
            orderModel.setEhgColctTimeIntrvlVal(ehgColctTimeIntrvlVal);
        }

        // 삼성선물 주문 타입
        // C : 청산번호가 있으면 청산번호로 요청청산포지션번호 셋, 없으면 만기일자로 셋
        // N : 무조건 만기일자로 셋
        log.warn(">> orProperty.getSamsungOrdertype() : " + orProperty.getSamsungOrdertype());
        String samsungOrdertype = orProperty.getSamsungOrdertype();
        if(StringUtils.isEmpty(samsungOrdertype) || samsungOrdertype.equals("null")) {
            log.info("OrderServiceImpl initOrderData line-468 vo.toString() >> " + orderModel.toString());
            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
            throw new CommCustomException("선물사 주문 타입 설정이 없습니다.");
        }
        orderModel.setSamsungOrdertype(samsungOrdertype);

        String samsungStockCode = metalCodeInfo.getCodeRefrnone(); // 요청 선물 종목 코드
        if(StringUtils.isEmpty(samsungStockCode)) {
            log.info("OrderServiceImpl initOrderData line-480 vo.toString() >> " + orderModel.toString());
            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
            throw new CommCustomException("요청 선물 종목 코드 값이 없습니다.");
        }

        orderModel.setSamsungStockCode(samsungStockCode); // 요청 선물 종목 코드

        BigDecimal samsungOrderWt = Optional.ofNullable(metalCodeInfo.getCodeNumberRefrnone()).orElse(BigDecimal.ZERO); // 삼성선물 주문 단위 중량
        if(samsungOrderWt.compareTo(BigDecimal.ZERO) == 0) {
            log.info("OrderServiceImpl initOrderData line-488 vo.toString() >> " + orderModel.toString());
            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
            throw new CommCustomException("선물사 주문 단위 중량이 null이거나 0입니다.");
        }

        orderModel.setSamsungOrderWt(samsungOrderWt.intValue()); // 삼성선물 주문 단위 중량

        // 판매단위중량(상품별)가져오기
        ItemDtlInfoVO sleWtInfo = Optional.ofNullable(orderMapper.getSleWtInfo(orderModel.getItmSn())).orElseThrow(() -> {
            log.info("OrderServiceImpl initOrderData line-496 vo.toString() >> " + orderModel.toString());
            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
            return new CommCustomException("해당 상품_아이템 정보가 없습니다.");});

        BigDecimal sleUnitWt = Optional.ofNullable(sleWtInfo.getSleUnitWt()).orElse(BigDecimal.ZERO); // 판매 단위 중량
        if(sleUnitWt.compareTo(BigDecimal.ZERO) == 0) {
            log.info("OrderServiceImpl initOrderData line-501 vo.toString() >> " + orderModel.toString());
            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
            throw new CommCustomException("판매 단위 중량이 null이거나 0입니다.");
        }

        // 평균가 주문은 제외
        if(!StringUtils.equals(orderModel.getSleMthdCode(), "04") && StringUtils.isEmpty(orderModel.getSleMthdDetailCode())) {
            // 최대구매가능중량(상품별) 가져오기
            BigDecimal onceSlePossWt = Optional.ofNullable(sleWtInfo.getOnceSlePossWt()).orElse(BigDecimal.ZERO); // 1회 판매 가능 중량
            if(onceSlePossWt.compareTo(BigDecimal.ZERO) == 0) {
                log.info("OrderServiceImpl initOrderData line-507 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException("1회 판매 가능 중량(상품별)이 null이거나 0입니다.");
            }

            BigDecimal mxmmPurchsPossWt = Optional.ofNullable(sleWtInfo.getMxmmPurchsPossWt()).orElse(BigDecimal.ZERO); // 최대 구매 가능 중량
            if(mxmmPurchsPossWt.compareTo(BigDecimal.ZERO) == 0) {
                log.info("OrderServiceImpl initOrderData line-513 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException("최대 구매 가능 중량(상품별)이 null이거나 0입니다.");
            }

            orderModel.setOnceSlePossWt(onceSlePossWt.intValue() / 1000); // 1회 판매 가능 중량 kg -> MT로 변환
            orderModel.setMxmmPurchsPossWt(mxmmPurchsPossWt.intValue() / 1000); // 최대 구매 가능 중량 kg -> MT로 변환
        }
        orderModel.setSleUnitWt(sleUnitWt.intValue() / 1000); // 판매 단위 중량 kg -> MT로 변환

        // 지정 BL 관련 - 소량구매일 경우 제외
        if(!StringUtils.equals(orderModel.getSmlqyPurchsAt(), "Y") && StringUtils.isNotEmpty(orderModel.getReMainBlNo())) {
            int result = orderMapper.isMbEntrpsSpcifyBrandRls(orderModel);
            if(result == 0) {
                log.info("OrderServiceImpl initOrderData line-525 vo.toString() >> " + orderModel.toString());
                throw new CommCustomException("해당 BL은 고객님이 구매하실수 없습니다.");
            }
        }

        // 계약_발주 기본 데이터 가져오기
        CnCntrctOrderBasVO cntrctOrderBasInfo = new CnCntrctOrderBasVO();
        if(StringUtils.equals(orderModel.getSleMthdCode(), "04") || StringUtils.isNotEmpty(orderModel.getSleMthdDetailCode())) {
            // 계약_발주 기본 조회
            cntrctOrderBasInfo = Optional.ofNullable(orderMapper.selectCnCntrctOrderBas(orderModel)).orElseThrow(() -> {
                log.info("OrderServiceImpl initOrderData line-594 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                return new CommCustomException("계약_발주 기본 정보가 없습니다.");});

            // 평균가 확정 단가 여부 설정
            commAvrgpcOrderService.setAvrgpcDcsnUntpcAt(cntrctOrderBasInfo);
            orderModel.setAvrgpcDcsnUntpcAt(cntrctOrderBasInfo.getAvrgpcDcsnUntpcAt());
        } else {
            // 평균가 확정 단가 여부 (평균가 이외 판매 방식은 'Y'를 기본값으로 설정)
            orderModel.setAvrgpcDcsnUntpcAt("Y");
        }
        orderModel.setCntrctOrderBasInfo(cntrctOrderBasInfo);// 계약_발주 기본 데이터
        
        // 24-09-12 변경사항 : 가단가(05) 주문일 경우, 회원_업체 정보 기본 테이블의 가단가 주문 관련 설정값을 조회하여 세팅해준다
        if(StringUtils.equals(orderModel.getSleMthdCode(), "05")) {
        	OrderModel prvsnlUntpcInfo = Optional.ofNullable(orderMapper.getPrvsnlUntpcInfo(orderModel)).orElseThrow(() -> {
        		return new CommCustomException("업체의 가단가 구매 관련 설정 정보가 없습니다.");
        	});
        	
        	orderModel.setUntpcSepratDcsnAt(prvsnlUntpcInfo.getUntpcSepratDcsnAt());			// 단가 분리 확정 여부
        	orderModel.setUntpcDcsnMxmmPdCode(prvsnlUntpcInfo.getUntpcDcsnMxmmPdCode());		// 단가 확정 최대 기간 코드
        	orderModel.setUntpcDcsnMxmmDe(prvsnlUntpcInfo.getUntpcDcsnMxmmDe());				// 단가 확정 최대 일자
        }
    }

    /**
     * 주문로직을 실행 시킨다.
     */
    @Override
    public void doOrder(OrderModel orderModel) throws CommCustomException, Exception {
        // 세금계산서보기 URL 세팅
        orderModel.setDocumentViewDomain("https://www.kztraders.com/my/papersManage/viewPapersManage"); // 20220401 이현진 세금계산서 url추가

        // 주문 초기 데이터 설정
        initOrderData(orderModel);

        log.warn(">> orderModel : " + String.valueOf(orderModel));

        try {
            /** 업체 결제 수단 정보 가져오기
             * : 업체의 증거금과 (전자상거래보증 or 케이지크레딧) 사용 권한(증거금 총 사용 여부, (전자상거래보증 or 케이지크레딧) 총 사용 여부), 증거금 신청 여부(화면단 별도 체크), (전자상거래보증 or 케이지크레딧) 신청 여부(화면단 별도 체크), 연체 및 사고 건수
             * : 증거금 최소 결제 예정일 조건
             * : 판매 단위 중량 (주문 가능 MIN 중량 및 주문 단위), 1회 구매 중량 한도 (주문 가능 MAX 중량)
             * : 업체 별 평가 등급 정보(여신 구간, 담보 보증 허용 상환 기간)
             * : 업체 구매성향 등급정보(업체 구매성향등급, 업체 구매성향등급 명, 증거금 권한 비율)
             * : 구매성향등급에 따른 단계별 금액(LME 전일 종가[케이지몰일 경우 현재 단가], 구간 종료 금액, 구간 평균 금액)
             * : 업체의 선택 가능한 구매등급을 표시한 전체 정보 리스트
             * : 여신 정보(금리 정보, 패널티 정보)
             * : 담보 보증 보험 요율(마일리지에 사용)
             * **/
            log.debug(">> orderModel.getRealBrandCode() : " + orderModel.getRealBrandCode());
            OrderEntrpsSetleMnVO entrpsSetleMnInfo = this.getEntrpsSetleMnInfo(orderModel.getEntrpsNo()
                    , orderModel.getSleMthdCode(), orderModel.getMetalCode(), orderModel.getItmSn(), orderModel.getDstrctLclsfCode()
                    , orderModel.getBrandGroupCode(), orderModel.getRealBrandCode(), orderModel.getSleMthdDetailCode());

            orderModel.setEntrpsSetleMnInfo(entrpsSetleMnInfo);

            log.debug(">> [OrderServiceImpl][doOrder] entrpsSetleMnInfo : " + String.valueOf(entrpsSetleMnInfo));

            /**
             * 최적의 BL리스트 가져오기 및 상품 재고 검색 체크
             *  1) 상품 재고 검색 체크
             *  2) 브랜드 검색 오류 (단일 브랜드이어야 한다)
             * **/
            orderBlList(orderModel);

            // 테스트 step 1 start
//          orderModel.setMberNo("P0493");
            // 테스트 step 1 end

            /** 주문 정합성 체크 1단계
             * 1. 증거금 주문 또는 (전자상거래보증 or 케이지크레딧) 주문일 경우 여신 관리 패널티 연체 건수 및 사고 건수 체크
             * 2. 증거금 주문일 경우 구매성향등급 존재 여부 및 증거금 사용 여부 유효성 체크
             * 3. 증거금 최소 결제 예정일 조건 체크
             * 4. (전자상거래보증 or 케이지크레딧) 주문일 경우 담보 보증 사용 여부 및 담보 보증 계약 여부 유효성 및 (전자상거래보증 or 케이지크레딧) 한도 설정 여부 체크
             *   4-1. 케이지크레딧일 경우 여신 계약 번호 및 총 한도 유효성 체크 추가
             * 5. 해당 고객사의 메탈사용여부를 체크
             * 6. 휴일에 따른 유효성 체크
             * 7. 당일배송 여부 체크
             * 8. 회원구분코드가 자금담당(04)일 경우 체크
             * 9. LME 사이드카 발동여부
             * 10. 환율 사이드카 발동여부
             * 11. 업체 동시 -> 오늘날짜 기준
             * 12. 회원 및 업체, 배송지 정보 가져오기 및 존재 여부 체크
             * 13. 기업뱅킹 환불 요청 여부 유효성 체크[진행중(1), 완료(0)]
             * 14. 케이지트레이딩 환불 요청 유효성 체크 [01:요청, 05:처리중]
             * 15. 중량 변동 가져오기[유효성은 아니지만 계산 전에 가져오기 위해 넣음]
             * 16. 상품별 최대 구매 가능 중량(오늘날짜 기준) 한도 유효성 체크
             * 17. 업체별 1회 구매 중량, 1일 구매 중량(오늘날짜 기준) 한도 유효성 체크
             * 18. 주문 프라이싱 정보 가져오기 및 프라이싱 존재 체크
             * 19. 판매 가격 및 프리미엄 가격에 따른 주문 금액 정보 계산 및 체크
             *  1) LIVE일 경우
             *   (1) 실시간 판매 가격 정보 조회 및 체크
             *   (2) 선물 SKIP 여부, 선물 틱 설정 값 등 정보 조회
             *   (3) LME 순번 값 체크 및 LME 수집 시간 간격 체크
             *   (4) 환률 순번 값 체크 및 환률 수집 시간 간격 체크
             *   (5) 프리미엄 가격 정보 조회 및 체크
             *   (6) 가격 정보 셋팅 (배송비, 공급가, 부가세, 판매가 계산 제외 - 배송비 때문)[유효성은 아니지만 계산하기 위해 넣음]
             *   7
             *  2) 고정가일 경우
             *   (1) 고정가 판매 가격 정보  및 프리미엄 가격 조회, 체크
             *   (2) 가격 정보 셋팅 (배송비, 공급가, 부가세, 판매가 계산 제외 - 배송비 때문)[유효성은 아니지만 계산하기 위해 넣음]
             * 99. 배송비 쿠폰 적용
             * **/
            orderValidation(orderModel);

            /** 배송비, 공급가, 부가세, 판매가 구하기 및 주문 정합성 체크 2단계 (판매가와 비교해야하기 위해)
             * 20. 이월렛 잔액 체크 또는 담보 보증 남은 한도 체크
             *  1) 이월렛 잔액 체크일 경우
             *   (1) 이월렛 잔금 조회 API 호출 체크
             *   (2) 이월렛 금액 부족 체크
             *  2) 담보 보증 남은 한도 체크일 경우
             *   (1) 담보 보증 남은 한도 부족 체크
             * **/
            /** 배송비, 공급가, 부가세, 판매가 구하기 20211112 **/
            setPriceInfoByExpectDlvrf(orderModel, true, orderModel.getOrderWt(), false);

            // 테스트 step 2 start
//          orderModel.setOrderNo("20230104-S00027");
//          callSms(orderModel);
//          callMail(orderModel);
//          callAppPush(orderModel);
            // 테스트 step 2 end

            /** 최적의 BL리스트 기준으로 입고예정재고여부(입고구분에의한) 파악 및 WMS 실시간 재고 파악 및 재고 차감, 주문 정합성 체크 3단계 (최적의 BL에서 BL번호 필요)
             * 21. 배송요율 유효성 체크
             *  1) 배송요율 정보 및 회원_배송지 정보 체크
             *  2) 배송 불가 및 서비스 불가능 지역 체크
             * 22. 실시간 물류 CAPA 확인[SOREC-IF-126] 유효성 체크
             * 23. WMS 실시간 재고 체크
             *  1) 실시간 재고 API 호출 체크 (현재 사용하지 않음)
             *  2) 실시간 재고 수량 체크 (현재 사용하지 않음)
             * **/
            /** 재고 체크 **/
            orderInvntryChk(orderModel);

            /** 주문 테이블 생성 **/
            orderInstTblBase(orderModel);

            if(StringUtils.equals(orderModel.getSleMthdCode(), "01")){
                /** 실시간 가격일시 삼성선물 호출 **/
                callSamsung(orderModel);
            }else {
                /** 고정가 가격일시 **/
                if(StringUtils.equals(orderModel.getPaymentMn(), "ewallet") || StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
                    // 이월렛 호출
                    callZnEwallet(orderModel);
                } else if(StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty")) {
                    // B2B 전자상거래보증 호출
                    callMrtgg(orderModel);
                }
            }
            log.info("OrderServiceImpl doOrder line-648 vo.toString() >> " + orderModel.toString());
            /** 주문 성공 후 처리 **/
            orderComplete(orderModel);
        } catch(Exception e) {
            log.error("doOrder() error : " + e);
            orderModel.setOrderFailrResn(e.getMessage());
            orderFail(orderModel);
            log.info("OrderServiceImpl doOrder line-655 vo.toString() >> " + orderModel.toString());

            throw new CommCustomException(e);
        }

    }

    /**
     * 주문 정합성 체크 1단계
     * 1. 증거금 주문 또는 B2B 전자상거래보증 주문일 경우 여신 관리 패널티 연체 건수 및 사고 건수 체크
     * 2. 증거금 주문일 경우 구매성향등급 존재 여부 및 증거금 사용 여부 유효성 체크
     * 3. 증거금 최소 결제 예정일 조건 체크
     * 4. B2B 전자상거래보증 주문일 경우 담보 보증 사용 여부 및 담보 보증 계약 여부 유효성 및 전자상거래보증 한도 설정 여부 체크
     *   4-1. 케이지크레딧일 경우 여신 계약 번호 및 총 한도 유효성 체크 추가
     * 5. 해당 고객사의 메탈사용여부를 체크
     * 6. 휴일에 따른 유효성 체크
     * 7. 당일배송 여부 체크
     * 8. 회원구분코드가 자금담당(04)일 경우 체크
     * 9. LME 사이드카 발동여부
     * 10. 환율 사이드카 발동여부
     * 11. 업체 동시 -> 오늘날짜 기준
     * 12. 회원 및 업체, 배송지 정보 가져오기 및 존재 여부 체크
     * 13. 기업뱅킹 환불 요청 여부 유효성 체크[진행중(1), 완료(0)]
     * 14. 케이지트레이딩 환불 요청 유효성 체크 [01:요청, 05:처리중]
     * 15. 중량 변동 가져오기[유효성은 아니지만 계산 전에 가져오기 위해 넣음]
     * 16. 상품별 최대 구매 가능 중량(오늘날짜 기준) 한도 유효성 체크
     * 17. 업체별 1회 구매 중량, 1일 구매 중량(오늘날짜 기준) 한도 유효성 체크
     * 18. 주문 프라이싱 정보 가져오기 및 프라이싱 존재 체크
     * 19. 판매 가격 및 프리미엄 가격에 따른 주문 금액 정보 계산 및 체크
     *  1) LIVE일 경우
     *   (1) 실시간 판매 가격 정보 조회 및 체크
     *   (2) 선물 SKIP 여부, 선물 틱 설정 값 등 정보 조회
     *   (3) LME 순번 값 체크 및 LME 수집 시간 간격 체크
     *   (4) 환률 순번 값 체크 및 환률 수집 시간 간격 체크
     *   (5) 프리미엄 가격 정보 조회 및 체크
     *   (6) 가격 정보 셋팅 (배송비, 공급가, 부가세, 판매가 계산 제외 - 배송비 때문)[유효성은 아니지만 계산하기 위해 넣음]
     *  2) 고정가일 경우
     *   (1) 고정가 판매 가격 정보  및 프리미엄 가격 조회, 체크
     *   (2) 가격 정보 셋팅 (배송비, 공급가, 부가세, 판매가 계산 제외 - 배송비 때문)[유효성은 아니지만 계산하기 위해 넣음]
     */
    @Override
    public void orderValidation(OrderModel orderModel) throws CommCustomException, Exception {

        // 평균가 주문인 경우, 결제 수단 이월렛 사용 여부(계약_견적 기본) 체크
        if((StringUtils.equals(orderModel.getSleMthdCode(), "04") || StringUtils.isNotEmpty(orderModel.getSleMthdDetailCode())) && StringUtils.equals(orderModel.getPaymentMn(), "ewallet")) {
            if(StringUtils.equals(orderModel.getCntrctOrderBasInfo().getSetleMnEwalletUseAt(), "N")) {
                log.info("OrderServiceImpl orderValidation line-784 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException("이월렛 사용이 허용되지 않은 계약 건 입니다,\n관리자에게 문의 바랍니다.");
            }
        }

        // 평균가 주문인 경우, 평균가 거래 금액 비율 코드/세금 계산서 발행 시점 코드 체크
        if(StringUtils.equals(orderModel.getSleMthdCode(), "04")) {
            if(StringUtils.isEmpty(orderModel.getEntrpsSetleMnInfo().getAvrgpcDelngAmountRateCode()) || StringUtils.isEmpty(orderModel.getEntrpsSetleMnInfo().getAvrgpcTaxBillIsuPnttmCode())) {
                throw new CommCustomException("해당 업체의 계약 관리 설정 값이 존재하지 않습니다,\n관리자에게 문의 바랍니다.");
            }
        }

        // 증거금 주문 또는 (전자상거래보증 or 케이지크레딧) 주문일 경우 여신 관리 패널티 연체 건수 및 사고 건수 체크
        if(StringUtils.equals(orderModel.getPaymentMn(), "wrtm") || StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty")) {
            int cdtlnManagePntArrrgCo = orderModel.getEntrpsSetleMnInfo().getCdtlnManagePntArrrgCo(); // 여신관리 패널티 연체 건수
            int cdtlnManagePntAcdntCo = orderModel.getEntrpsSetleMnInfo().getCdtlnManagePntAcdntCo(); // 여신관리 패널티 사고 건수

            int arrrgCo = orderModel.getEntrpsSetleMnInfo().getArrrgCo(); // 연체 건수
            int acdntCo = orderModel.getEntrpsSetleMnInfo().getAcdntCo(); // 사고 건수

            // 연체 건수 체크
            if(arrrgCo != 0 && arrrgCo >= cdtlnManagePntArrrgCo) {
                log.info("OrderServiceImpl orderValidation line-717 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException("연체 건수가 " + arrrgCo + "건 이상으로 이월렛 단독 결제만 가능합니다.");
            }
            // 사고 건수 체크
            if(acdntCo != 0 && acdntCo >= cdtlnManagePntAcdntCo) {
                log.info("OrderServiceImpl orderValidation line-722 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException("사고 건수가 " + acdntCo + "건 이상으로 이월렛 단독 결제만 가능합니다.");
            }
        }

        // 증거금 주문일 경우 구매성향등급 존재 여부 및 증거금 사용 여부 유효성 체크
        // 증거금 최소 결제 예정일 조건 체크
        if(StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
            // 증거금 최소 결제 예정일 조건 체크
            int wrtmMummSetlePrarndeCnd = orderModel.getEntrpsSetleMnInfo().getWrtmMummSetlePrarndeCnd(); // 증거금 최소 결제 예정일 조건
            log.warn(">> 증거금 최소 결제 예정일 조건(wrtmMummSetlePrarndeCnd) : " + wrtmMummSetlePrarndeCnd);
            SettleSttusDeVO settleSttusDeVO = new SettleSttusDeVO();
            settleSttusDeVO.setStdde(DateUtil.getNowDate()); // 주문일자
            settleSttusDeVO.setCalcDay(wrtmMummSetlePrarndeCnd); // 증거금 최소 결제 예정일 조건
            String dlivyRequstDe = orderModel.getDlivyRequstDe().replaceAll("-", ""); // 배송요청일
            String wrtmMummSetlePrarnde = this.getSettleSttusDe(settleSttusDeVO); // 증거금 최소 결제 예정일
            int getIntervalDay = DateUtil.intervalDay(wrtmMummSetlePrarnde, dlivyRequstDe); // 증거금 최소 결제 예정일과 배송요청일의 차이(일)
            log.warn(">> 배송요청일과 증거금 최소 결제 예정일의 차이(일)(getIntervalDay) : " + getIntervalDay);
            log.warn(">> 증거금 최소 결제 예정일(wrtmMummSetlePrarnde) : " + StringUtil.formatDate(wrtmMummSetlePrarnde));
            // 차이가 0보다 작거나 같으면 주문 불가
            if(getIntervalDay <= 0) {
                log.info("OrderServiceImpl orderValidation line-743 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException("배송 요청일을 증거금 최소 결제 예정일(" + StringUtil.formatDate(wrtmMummSetlePrarnde) + ")\n이후로 변경해 주세요.");
            }

            // 업체 구매성향등급 존재 여부를 체크한다.
            Optional.ofNullable(orderModel.getEntrpsSetleMnInfo().getPurchsInclnGrad()).orElseThrow(() -> {
                log.info("OrderServiceImpl orderValidation line-749 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                return new CommCustomException("업체 구매성향등급이 존재하지 않습니다,\n관리자에게 문의 바랍니다.");});
            // 증거금 총 사용 여부(증거금 신청 여부, 증거금 사용 여부, 증거금 해지 여부 체크)를 체크한다, 사용여부가 Y가 아닐 시 주문 불가
            if(!StringUtils.equals(orderModel.getEntrpsSetleMnInfo().getWrtmTotUseAt(), "Y")) {
                log.info("OrderServiceImpl orderValidation line-753 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException("증거금 총 사용 조건에 충족되지 않습니다,\n관리자에게 문의 바랍니다.");
            }

            // 평균가 주문인 경우, 결제 수단 증거금 사용 여부(계약_견적 기본) 체크
            if(StringUtils.isNotEmpty(orderModel.getSleMthdDetailCode())) {
                if(StringUtils.equals(orderModel.getCntrctOrderBasInfo().getSetleMnWrtmUseAt(), "N")) {
                    log.info("OrderServiceImpl orderValidation line-896 vo.toString() >> " + orderModel.toString());
                    orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                    throw new CommCustomException("증거금 사용이 허용되지 않은 계약 건 입니다,\n관리자에게 문의 바랍니다.");
                }
            }
        }

        // (전자상거래보증 or 케이지크레딧) 주문일 경우 담보 보증 사용 여부 및 담보 보증 계약 여부 유효성 및 (전자상거래보증 or 케이지크레딧) 한도 설정 여부 체크
        // 주문 모달창에 선택된 결제 수단 값이 (전자상거래보증 or 케이지크레딧)일 때
        if(StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty")) {
            // (전자상거래보증 or 케이지크레딧) 총 사용 여부(담보 보증 신청 여부, 담보 보증 사용 여부, 담보 보증 승인 여부 , 담보 보증 해지 여부 체크)를 체크한다, 사용여부가 Y가 아닐 시 주문 불가
            if(!StringUtils.equals(orderModel.getEntrpsSetleMnInfo().getMrtggGrntyTotUseAt(), "Y")) {
                log.info("OrderServiceImpl orderValidation line-763 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException(orderModel.getEntrpsSetleMnInfo().getViewCdtlnSvcSeNm() + " 총 사용 조건에 충족되지 않습니다,\n관리자에게 문의 바랍니다.");
            }
            // 연간뱅킹데이 체크
            if(orderModel.getEntrpsSetleMnInfo().getMrtggGrntyFyerBankingDaycnt() == 0) {
                log.info("OrderServiceImpl orderValidation line-768 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException("연간뱅킹데이 값이 존재하지 않습니다,\n관리자에게 문의 바랍니다.");
            }

            // (전자상거래보증 or 케이지크레딧) 한도조회 가져오기, (전자상거래보증 or 케이지크레딧) 한도 설정 여부 체크
            // MRTGG_GRNTY_LMT_STATUS((전자상거래보증 or 케이지크레딧) 한도 상태)
            //   00 : (전자상거래보증 or 케이지크레딧) 한도 설정 정상
            //   01 : (전자상거래보증 or 케이지크레딧) 한도가 설정되어 있지 않음
            //   02 : (전자상거래보증 or 케이지크레딧) 한도가 설정되어 있으나 계약정보가 없음
            //   EMPTY : 업체 정보가 존재하지 않음
            //
            OrderEtcPrice mrtggGrntyLmtInqire = this.getMrtggGrntyLmtInqire(orderModel);
            log.warn(">> (전자상거래보증 or 케이지크레딧) 한도 설정 체크 : " + mrtggGrntyLmtInqire.getMrtggGrntyLmtStatus());
            if(StringUtils.equals(mrtggGrntyLmtInqire.getMrtggGrntyLmtStatus(),"00")) {
                // (전자상거래보증 or 케이지크레딧) 한도 설정이 정상일 경우 값 담기
                orderModel.setGrntyNo(orderModel.getEntrpsSetleMnInfo().getGrntyNo()); // 보증 번호
                orderModel.setEntrpsMrtggCntrctSn(orderModel.getEntrpsSetleMnInfo().getEntrpsMrtggCntrctSn()); // 업체 담보 계약 순번
                orderModel.setMrtggGrntyFeeBndMbyAt(orderModel.getEntrpsSetleMnInfo().getMrtggGrntyFeeBndMbyAt()); // 담보 보증 수수료 부담 주체 여부
                orderModel.setGrntyTmlmtBeginDe(orderModel.getEntrpsSetleMnInfo().getGrntyTmlmtBeginDe()); // 보증 기한 시작 일자
                orderModel.setGrntyTmlmtEndDe(orderModel.getEntrpsSetleMnInfo().getGrntyTmlmtEndDe()); // 보증 기한 종료 일자
                orderModel.setGrntyAmount(mrtggGrntyLmtInqire.getGrntyAmount()); // 보증 금액
            } else {
                //if(StringUtils.equals("01", mrtggGrntyLmtInqire.getMrtggGrntyLmtStatus())
                log.info("OrderServiceImpl orderValidation line-792 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException(orderModel.getEntrpsSetleMnInfo().getViewCdtlnSvcSeNm() + " 한도 설정 오류[" + mrtggGrntyLmtInqire.getMrtggGrntyLmtStatus() + "],\n관리자에게 문의 바랍니다.");
            }

            // 케이지크레딧일 경우 여신 계약 번호 및 총 한도 유효성 체크 추가
            if(StringUtils.equals(orderModel.getCdtlnSvcSeCode(), "02")) {
                log.warn(">> 케이지크레딧일 경우 여신 계약 번호 유효성 체크 : " + orderModel.getEntrpsSetleMnInfo().getCdtlnCntrctNo());
                if(StringUtils.isEmpty(orderModel.getEntrpsSetleMnInfo().getCdtlnCntrctNo())) {
                    log.info("OrderServiceImpl orderValidation line-800 vo.toString() >> " + orderModel.toString());
                    orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                    throw new CommCustomException("여신 계약 번호가 없습니다.");
                }

                log.warn(">> 케이지크레딧일 경우 총 한도 유효성 체크");
                if(StringUtils.equals(orderModel.getEntrpsSetleMnInfo().getSorinCredtUseAt(), "N")) {
                    log.info("OrderServiceImpl orderValidation line-806 vo.toString() >> " + orderModel.toString());
                    orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                    throw new CommCustomException("케이지크레딧 총 한도초과,\n관리자에게 문의 바랍니다.");
                }
            }

            // 평균가 주문인 경우, 결제 수단 여신 사용 여부(계약_견적 기본) 체크
            if(StringUtils.equals(orderModel.getSleMthdCode(), "04") || StringUtils.isNotEmpty(orderModel.getSleMthdDetailCode())) {
                if(StringUtils.equals(orderModel.getCntrctOrderBasInfo().getSetleMnCdtlnUseAt(), "N")) {
                    log.info("OrderServiceImpl orderValidation line-896 vo.toString() >> " + orderModel.toString());
                    orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                    throw new CommCustomException("여신 사용이 허용되지 않은 계약 건 입니다,\n관리자에게 문의 바랍니다.");
                }
            }

        }

        // 휴일에 따른 유효성 체크(휴일 여부 있으면 false, 없으면 true)
        log.warn(">>  orderModel.getDlivyRequstDe() : " +  orderModel.getDlivyRequstDe());
        if(StringUtils.isBlank(orderModel.getDlivyRequstDe())) {
            throw new CommCustomException("배송요청일이 존재하지 않습니다,\n관리자에게 문의 바랍니다.");
        }
        String dlivyRequstDe = orderModel.getDlivyRequstDe().replaceAll("-", ""); // 배송요청일
        String getNowDate = DateUtil.getNowDate(); // 현재날짜
        String minLimitOrderNightTime = itemPriceService.getMinLimitOrderNightTime(orderModel.getMetalCode(), DateUtil.getNowDate(), 2).replaceAll("-", "");

        // 지정가인경우 유효시간을 체크한다.
        // 수정 시 OrderLimitServiceImpl.java 파일도 함께 수정 필수(동일로직 사용)
        if (StringUtils.equals("03", orderModel.getSleMthdCode())) {
            RltmEndTimeVO rltmEndTimeVO = bsnInfoService.getRltmEndTime();
            if (rltmEndTimeVO.getRltmMidTimeValue().equals(orderModel.getLimitOrderValidTime())) {	// 1. 지정가 유효 시간이 17시인 경우
                if (Integer.parseInt(DateUtil.getNowDateTime("HH")) >= rltmEndTimeVO.getRltmMidTimeValue2()) {	// 현재 시간이 유효시간 이후일 때 유효성 검사 실패 처리
                    log.info("OrderServiceImpl orderValidation line-858 vo.toString() >> " + orderModel.toString());
                    orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                    throw new CommCustomException(rltmEndTimeVO.getRltmMidTimeValue2()+"시 이전에만 선택 가능합니다.");
                }

            } else if (rltmEndTimeVO.getRltmEndTimeValue().equals(orderModel.getLimitOrderValidTime())) {	// 2. 지정가 유효 시간이 22시인 경우
                if (Integer.parseInt(minLimitOrderNightTime) > Integer.parseInt(dlivyRequstDe)) {	// XXX : 야간장 신청시 2일 신청 체크 (commit id: f0dcc2)
                    log.info("OrderServiceImpl orderValidation line-865 vo.toString() >> " + orderModel.toString());
                    orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                    if(StringUtils.isNotEmpty(orderModel.getSleMthdDetailCode())) {
                    	throw new CommCustomException("배송요청일이 당일 또는 익일일 경우\n지정가 주문이 불가능합니다.\n발주 취소 후 재발주해 주십시오.");
                    } else {
                    	throw new CommCustomException("배송요청일이 익일일 경우\n당일 저녁 "+rltmEndTimeVO.getViewRltmEndTime()+"로 선택하실 수 없습니다.\n배송요청일을 수정하고 주문해 주십시오.");
                    }
                }
            }
        } else if (StringUtils.equals("01", orderModel.getSleMthdCode()) 
        			|| StringUtils.equals("04", orderModel.getSleMthdCode()) 
        			|| StringUtils.equals("05", orderModel.getSleMthdCode())) {
            RltmEndTimeVO rltmEndTimeVO = bsnInfoService.getRltmEndTime();
            if (Integer.parseInt(DateUtil.getNowDateTime("HH")) >= rltmEndTimeVO.getRltmMidTimeValue2()) {
                if (Integer.parseInt(minLimitOrderNightTime) > Integer.parseInt(dlivyRequstDe)) {
                    log.info("OrderServiceImpl orderValidation line-888 vo.toString() >> " + orderModel.toString());
                    orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                    if(StringUtils.equals("04", orderModel.getSleMthdCode()) || StringUtils.isNotEmpty(orderModel.getSleMthdDetailCode())) {
                        throw new CommCustomException("야간장("+rltmEndTimeVO.getRltmMidTime()+") 구매 시\n배송요청일이 익일일 경우 배송이 불가능합니다.\n발주 취소 후 재발주해 주십시오.");
                    } else {
                        throw new CommCustomException("야간장("+rltmEndTimeVO.getRltmMidTime()+") 구매 시\n배송요청일이 익일일 경우 배송이 불가능합니다.\n배송요청일을 수정하고 주문해 주십시오.");
                    }
                }
            }
        }

//      // 해당 고객사의 메탈사용여부를 체크 (업체코드와 메탈코드로 업체에 설정된 판매메탈코드를 조회하여 TRUE/FALSE를 반환한다.)
//      if(!itemCodeService.getEntrpsMetalCodeAt(orderModel.getEntrpsNo(), orderModel.getMetalCode())) throw new CommCustomException("주문 가능한 판매 금속이 아닙니다,\n관리자에게 문의 바랍니다.");

        itemCodeService.getMbEntrpsMetalAcctoAuthorSetupBasList(orderModel.getEntrpsNo()).forEach(data -> {
            log.warn(">> 메탈사용여부 체크용 리스트 : " + String.valueOf(data));
        });
        // 해당 고객사의 메탈사용여부를 체크
        List<ItemCodeVO> getAcctoAuthorByMetalCodeList = itemCodeService.getMbEntrpsMetalAcctoAuthorSetupBasList(orderModel.getEntrpsNo()).stream()
                .filter(data -> (StringUtils.equals(orderModel.getMetalCode(), data.getMetalCode())))
                .collect(Collectors.toList());
        log.warn(">> 메탈사용여부 체크용 리스트 필터 사이즈 : " + getAcctoAuthorByMetalCodeList.size());
        if(getAcctoAuthorByMetalCodeList.size() > 0) {
            if(getAcctoAuthorByMetalCodeList.size() == 1) {
                boolean metalAcctoAuthorChk = false;
                ItemCodeVO getAcctoAuthorByMetalCode = getAcctoAuthorByMetalCodeList.get(0);
                log.warn(">> 메탈사용여부 체크용 리스트 필터 : " + String.valueOf(getAcctoAuthorByMetalCode));

                if(StringUtils.equals("01", orderModel.getSleMthdCode()) || StringUtils.equals("05", orderModel.getSleMthdCode())) {
                    if(StringUtils.equals("0104", orderModel.getSleMthdDetailCode())) {
                    	// 평균가-LIVE일 경우, 평균가 사용 여부 체크
                    	if(StringUtils.equals("Y", getAcctoAuthorByMetalCode.getAvrgPcAt())) {
                    		metalAcctoAuthorChk = true;
                    	}
                    } else {
                    	// 판매방식코드 01: LIVE
                        if(StringUtils.equals("Y", getAcctoAuthorByMetalCode.getLivePcAt())) {
                            metalAcctoAuthorChk = true;
                        }
                    }
                } else if(StringUtils.equals("02", orderModel.getSleMthdCode())) {
                    // 판매방식코드 02: 케이지몰
                    if(StringUtils.equals("Y", getAcctoAuthorByMetalCode.getFixingPcAt())) {
                        metalAcctoAuthorChk = true;
                    }
                } else if(StringUtils.equals("03", orderModel.getSleMthdCode())) {
                	 if(StringUtils.equals("0304", orderModel.getSleMthdDetailCode())) {
                     	// 평균가-지정가일 경우, 평균가 사용 여부 체크
                     	if(StringUtils.equals("Y", getAcctoAuthorByMetalCode.getAvrgPcAt())) {
                     		metalAcctoAuthorChk = true;
                     	}
                     } else {
                    	// 판매방식코드 03: 지정가
                         if(StringUtils.equals("Y", getAcctoAuthorByMetalCode.getAppnPcAt())) {
                             metalAcctoAuthorChk = true;
                         }
                     }
                } else if(StringUtils.equals("04", orderModel.getSleMthdCode())) {
                    // 판매방식코드 04: 평균가
                    if(StringUtils.equals("Y", getAcctoAuthorByMetalCode.getAvrgPcAt())) {
                        metalAcctoAuthorChk = true;
                    }
                }

                if(!metalAcctoAuthorChk) {
                    log.info("OrderServiceImpl orderValidation line-845 vo.toString() >> " + orderModel.toString());
                    orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                    throw new CommCustomException("주문 가능한 판매 금속이 아닙니다,\n관리자에게 문의 바랍니다.");
                }
            } else {
                log.info("OrderServiceImpl orderValidation line-849 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException("메탈 사용 여부 조회결과가 여러 건입니다,\n관리자에게 문의 바랍니다.");
            }
        } else {
            log.info("OrderServiceImpl orderValidation line-853 vo.toString() >> " + orderModel.toString());
            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
            throw new CommCustomException("메탈 사용 여부를 조회할 수 없습니다,\n관리자에게 문의 바랍니다.");
        }

        // 금일 휴일에 따른 유효성 체크
        // (판매방식이 지정가 or 평균가일 경우 isRestDeLive  메소드 호출하고 isRestDeLive  안에서는 01(LIVE)로 움직인다, 20230510
        // 공통함수 변경 (isRestDeLive -> isRestDeByMetal) 20230831
        boolean restdeYn = false;
        if(!StringUtils.equals("02", orderModel.getSleMthdCode())) {
            restdeYn = bsnInfoService.isRestDeByMetal(orderModel.getMetalCode(),  "01");
        } else {
            restdeYn = bsnInfoService.isRestDeByMetal(orderModel.getMetalCode(),  "02");
        }

        log.warn(">> 금일 휴일에 따른 유효성 체크 : " + restdeYn);
        if(!restdeYn) {
            log.info("OrderServiceImpl orderValidation line-866 vo.toString() >> " + orderModel.toString());
            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
            throw new CommCustomException("영업시간을 확인해주세요.");
        }

        if(StringUtils.equals(getNowDate, dlivyRequstDe)) {
            orderModel.setSameDayDeliveryAt("Y"); // 당일배송 여부(동일날짜인지만 체크) Y

            // (판매 방식 코드 , 배송 수단 코드, 금속 코드) 조건에 의한 현재 시각, 당일배송 불가능 상태 및 당일배송 종료 시간을 맵으로 가져온다. (당일배송 가능 여부 값도 여기서 set)
            Map<String, Object> sameDayDeliveryInfo = this.getSameDayDeliveryInfo(orderModel);
            boolean sameDayDeliveryStatus = Boolean.parseBoolean(String.valueOf(sameDayDeliveryInfo.get("sameDayDeliveryStatus"))); // 가능 상태
            if(!sameDayDeliveryStatus) {
                String sameDayDeliveryCloseTime = String.valueOf(sameDayDeliveryInfo.get("sameDayDeliveryCloseTime")); // 당일배송 종료 시간
                log.info("OrderServiceImpl orderValidation line-878 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                if(StringUtils.equals("04", orderModel.getSleMthdCode()) || StringUtils.isNotEmpty(orderModel.getSleMthdDetailCode())) {
                    throw new CommCustomException(sameDayDeliveryCloseTime + " 이후로 당일배송이 마감되었습니다,\n발주 취소 후 재발주해 주십시오.");
                } else {
                	throw new CommCustomException(sameDayDeliveryCloseTime + " 이후로 당일배송이 마감되었습니다,\n주문검색화면에서 배송요청일을 다시 선택해주세요.");
                }
            }

            String todayDlvyAt = String.valueOf(sameDayDeliveryInfo.get("todayDlvyAt")); // 당일배송 가능 여부
            // 당일배송 가능 여부 값 set
            orderModel.setTodayDlvyAt(todayDlvyAt);
        } else {
            orderModel.setSameDayDeliveryAt("N"); // 당일배송 여부(동일날짜인지만 체크) N

            // 당일배송 가능 여부 값 set
            orderModel.setTodayDlvyAt("N"); // 동일 날짜가 아닌 경우 당일 배송 가능 여부는 N

//          RestdeVO getRestdeInfo = bsnInfoService.getRestdeInfo(dlivyRequstDe); 20211223 제거, 물류 휴일만 체크한다.
//          log.debug(">> 배송요청일이 현재 날짜와 다름 - getRestdeInfo : " + String.valueOf(getRestdeInfo)); 20211223 제거, 물류 휴일만 체크한다.
//          if(getRestdeInfo.getDeAcctoRestdeAt() != null && StringUtils.equals(getRestdeInfo.getDeAcctoRestdeAt(), "Y")) throw new CommCustomException("영업시간을 확인해주세요."); 20211223 제거, 물류 휴일만 체크한다.
            if(orderMapper.chkRestdeByDlivyRequstDe(orderModel) > 0) {
                log.info("OrderServiceImpl orderValidation line-895 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException("영업시간[물류 휴일]을 확인해주세요.");
            }
        }

        // 회원구분코드가 자금담당(04)일 경우 체크
        if(orderMapper.chkMberSeCodeByOrder(orderModel) > 0) {
            log.info("OrderServiceImpl orderValidation line-902 vo.toString() >> " + orderModel.toString());
            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
            throw new CommCustomException("회원구분코드가 자금담당입니다.");
        }

        // 평균가-평균가 주문은 제외
        if(!StringUtils.equals(orderModel.getSleMthdCode(), "04")) {
            log.info("OrderServiceImpl orderValidation 평균가-평균가 주문은 LME, 환율 사이드카 발동여부 조회 제외");
        } else if(StringUtils.equals("01", orderModel.getSleMthdCode()) 
        			|| StringUtils.equals("03", orderModel.getSleMthdCode())
        			|| StringUtils.equals("05", orderModel.getSleMthdCode())) {
            // LME 사이드카 발동여부 (지정가일 경우 추가, 20230510)(가단가일 경우 추가, 20240911)
            if(orderMapper.chkLmeSidecar(orderModel) > 0 ) {
                log.info("OrderServiceImpl orderValidation line-908 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException("사이드카[LME] 발동");
            }

            // 환율 사이드카 발동여부 (지정가일 경우 추가, 20230510)
            if(orderMapper.chkFxSidecar(orderModel) > 0 ) {
                log.info("OrderServiceImpl orderValidation line-914 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException("사이드카[환율] 발동");
            }
        }

        // 업체 동시 -> 오늘날짜 기준 (지정가일 경우 제외, 20230510)
        if(!StringUtils.equals("03", orderModel.getSleMthdCode())) {
            if(orderMapper.getOrderEntrpsCnt(orderModel) > 0) {
                log.info("OrderServiceImpl orderValidation line-920 vo.toString() >> " + orderModel.toString());
                throw new CommCustomException("동일 업체 주문중");
            }
        }

        // 지정가 가격 도달 시 진행되는 주문은 제외, 이미 세팅되어 있음, 20230510
        if(!StringUtils.equals("touch", orderModel.getLimitSection())) {

            // 회원 및 업체, 배송지 정보 가져오기 및 존재 여부 체크
            orderModel.setMbDlvrgBas(Optional.ofNullable(orderMapper.selectOrMbEntrpsDlvrgInfo(orderModel)).orElseThrow(() -> {
                log.info("OrderServiceImpl orderValidation line-926 vo.toString() >> " + orderModel.toString());
                return new CommCustomException("배송지 및 기본정보 미존재");}));

            // 평균가 주문인 경우, 일일 여신 구매 중량 한도(MB_ENTRPS_INFO_BAS - DAIL_CDTLN_PURCHS_WT_LMT) 무제한으로 설정
            if(StringUtils.equals("04", orderModel.getSleMthdCode()) || StringUtils.isNotEmpty(orderModel.getSleMthdDetailCode())) {
                orderModel.getMbDlvrgBas().setDailCdtlnPurchsWtLmt(0);
            }
        }

//      String refndAcnutNo = orderModel.getMbDlvrgBas().getRefndAcnutNo(); // 환불 계좌 번호
//      // 기업뱅킹 환불 요청 여부 유효성 체크[진행중(1), 완료(0)]
//      if(dashboardMapper.selectRefndProgrsCnt(refndAcnutNo) > 0) throw new CommCustomException("기업뱅킹 환불 요청중");
//
//      // 케이지트레이딩 환불 요청 유효성 체크 [01:요청, 05:처리중]
//      if(orderMapper.chkSorinRefnd(orderModel) > 0) throw new CommCustomException("케이지트레이딩 환불 요청중");

        // 이월렛과 증거금 시 이월렛 환불 상태 체크 (지정가일 경우 제외, 20230510, 아직 협의중)
        if(!StringUtils.equals("03", orderModel.getSleMthdCode())) {
            // 이월렛과 증거금 시 이월렛 환불 상태 체크(구분자(1 : FO 주문, 2 : FO 출금, 3 : VA 기업뱅킹), 업체코드)
            if(StringUtils.equals(orderModel.getPaymentMn(), "ewallet") || StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
                Map<String, String> chkEwalletRefndSttus = orderMapper.chkEwalletRefndSttus("1", orderModel.getEntrpsNo());
                log.warn(">> chkEwalletRefndSttus : " + chkEwalletRefndSttus);
                if(chkEwalletRefndSttus.size() <= 0) {
                    log.info("OrderServiceImpl orderValidation line-941 vo.toString() >> " + orderModel.toString());
                    throw new CommCustomException("이월렛 환불 상태 체크 오류");
                }
                String refndSttus = Optional.ofNullable(chkEwalletRefndSttus.get("RETURN_STTUS")).orElse("N");
                log.warn(">> refndSttus : " + refndSttus);
                if(StringUtils.equals(refndSttus, "N")) {
                    log.info("OrderServiceImpl orderValidation line-947 vo.toString() >> " + orderModel.toString());
                    throw new CommCustomException("이월렛 환불 요청중");
                }
            }
        }

        // 중량 변동 가져오기
        double wtChange = commOrderService.getWtChange(orderModel);
        log.warn(">> wtChange : " + wtChange);
//      if(wtChange == 0) {
//          orderModel.setWtChange(1.5); // null이거나 0일 경우 기본값 1.5로 설정한다.
//      } else {
//          orderModel.setWtChange(wtChange);
//      }

        // 중량 변동 데이터 없을 경우에만 에러 처리(0 허용)
        if(wtChange < 0) {
            log.warn(">> wtChangeErr : " + wtChange);
            log.info("OrderServiceImpl orderValidation line-967 vo.toString() >> " + orderModel.toString());
            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
            throw new CommCustomException("구매 불가한 상품입니다. 자세한 사항은 고객센터(02-6952-5095)로 문의바랍니다.");
        }
        orderModel.setWtChange(wtChange);
        
        // 24-09-19 변경사항 : 가단가 구매(05)일 경우, 가단가 출고 최대 수량 초과 여부를 체크
        if(StringUtils.equals("05", orderModel.getSleMthdCode())) {
        	// 가단가 구매 정보
			Map<String, Object> prvsnlUntpcInfo = itemPriceService.getPrvsnlUntpcInfo(orderModel.getEntrpsNo());
			
			if(!CollectionUtils.isEmpty(prvsnlUntpcInfo)) {
				// 가단가 출고 수량 제한 (=잠정 단가 출고 최대 수량)
				int prvsnlUntpcDlivyMxmmQy = (int) Optional.ofNullable(prvsnlUntpcInfo.get("prvsnlUntpcDlivyMxmmQy")).orElse(0);
				
				// 단가 미확정 중량
				int pcUnDcsnWt = (int) Optional.ofNullable(prvsnlUntpcInfo.get("pcUnDcsnWt")).orElse(0);
				
				log.info("가단가 출고 수량 제한 : {}MT, 현재 단가 미확정 중량 : {}MT, 현재 주문 중량 : {}MT", prvsnlUntpcDlivyMxmmQy, pcUnDcsnWt, orderModel.getOrderWt());
				
				if(prvsnlUntpcDlivyMxmmQy < pcUnDcsnWt + orderModel.getOrderWt()) {
					log.info("OrderServiceImpl orderValidation >> " + orderModel.toString());
					throw new CommCustomException("가단가 구매 방식으로 구매 가능한 중량을 초과하였습니다.\n관리자에게 문의 바랍니다.");
				}
			} else {
				log.info("OrderServiceImpl orderValidation >> " + orderModel.toString());
                throw new CommCustomException("가단가 구매 관련 정보를 찾을 수 없습니다.\n관리자에게 문의 바랍니다.");
			}
        }

        // 평균가 주문인 경우, 체크 제외
        if(!StringUtils.equals("04", orderModel.getSleMthdCode()) && StringUtils.isEmpty(orderModel.getSleMthdDetailCode())) {
            // 상품별 최대 구매 가능 중량(오늘날짜 기준) 한도 유효성 체크
            orderModel.setTodayTotRealOrderWtCnd("item"); // 상품별 조건을 넣기 위함
            // [상품별 하루 총 실제 주문 중량] 또는 [업체 단위 메탈코드별 하루 총 실제 주문 중량] 또는 [업체 단위 케이지크레딧 하루 총 실제 주문 중량] 가져오기
            int getTotRealOrderWtByItm = orderMapper.getTotRealOrderWt(orderModel);
            log.warn(">> [orderValidation] 상품별 getTotRealOrderWtByItm : " + getTotRealOrderWtByItm);
            int mxmmPurchsPossWt = orderModel.getMxmmPurchsPossWt(); // 상품별 최대 구매 가능 중량 한도
            log.warn(">> 최대 구매 가능 중량 한도 체크, mxmmPurchsPossWt : " + mxmmPurchsPossWt + ", getTotRealOrderWtByItm : " + getTotRealOrderWtByItm + ", orderWt : " + orderModel.getOrderWt());
            if(mxmmPurchsPossWt >= (getTotRealOrderWtByItm + orderModel.getOrderWt())) {
                log.warn(">> 최대 구매 가능 중량 한도, 주문 가능");
            } else {
                log.info("OrderServiceImpl orderValidation line-983 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException("상품별 최대 구매 가능 중량["+StringUtil.formatMoney(String.valueOf(mxmmPurchsPossWt))+"] 한도초과\n[상품별 총 주문 중량 합 : "+StringUtil.formatMoney(String.valueOf(getTotRealOrderWtByItm))+"]");
            }
        }

        // 업체별 1회 구매 중량, 1일 구매 중량(오늘날짜 기준) 한도 유효성 체크
        //  1) 1회 구매 중량 한도(ONCE_PURCHS_WT_LMT) 값 체크 [-1: 데이터 없음, 0: 무제한, 0 초과 시 한도초과 체크]
        //  2) 1일 구매 중량 한도(ONEDE_PURCHS_WT_LMT) 값 체크 [-1: 데이터 없음, 0: 무제한, 0 초과 시 한도초과 체크]
        //  3) 케이지크레딧일 경우 추가로 체크 : 일일 여신 구매 중량 한도(MB_ENTRPS_INFO_BAS - DAIL_CDTLN_PURCHS_WT_LMT) 값 체크 [-1(NULL): 체크 안함, 0: 체크안함, 0 초과 시 한도초과 체크]
        // ** 1,2, 3번 둘 중 하나라도 [03:한도초과]가 발생하면 주문 막음

        int oncePurchsWtLmt = orderModel.getEntrpsSetleMnInfo().getOncePurchsWtLmt(); // 1회 구매 중량 한도 (주문 가능 MAX 중량)
        log.warn(">> [orderValidation] 1회 구매 중량 한도 (oncePurchsWtLmt) : " + oncePurchsWtLmt);
        int onedePurchsWtLmt = orderModel.getEntrpsSetleMnInfo().getOnedePurchsWtLmt(); // 1일 구매 중량 한도
        log.warn(">> [orderValidation] 1일 구매 중량 한도 (onedePurchsWtLmt) : " + onedePurchsWtLmt);

        orderModel.setTodayTotRealOrderWtCnd("entrpsMetal"); // 업체별 메탈코드별 조건을 넣기 위함
        // [상품별 하루 총 실제 주문 중량] 또는 [업체 단위 메탈코드별 하루 총 실제 주문 중량] 또는 [업체 단위 케이지크레딧 하루 총 실제 주문 중량] 가져오기
        int getTotRealOrderWtByEntrps = orderMapper.getTotRealOrderWt(orderModel);
        log.warn(">> [orderValidation] 업체별 getTotRealOrderWtByEntrps : " + getTotRealOrderWtByEntrps);

        if(oncePurchsWtLmt == -1 || onedePurchsWtLmt == -1) {
            log.info("OrderServiceImpl orderValidation line-1004 vo.toString() >> " + orderModel.toString());
            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
            throw new CommCustomException("업체별 1회 구매 중량 한도 및 1일 구매 중량 한도 기준 미존재,\n관리자에게 문의 바랍니다.");
        } else {
            // 평균가 주문은 업체별 1회 구매 중량 한도, 1일 구매 중량 한도 무제한이므로 유효성 검사 통과
            if(StringUtils.equals("04", orderModel.getSleMthdCode()) || StringUtils.isNotEmpty(orderModel.getSleMthdDetailCode())) {
            	log.warn(">> 평균가 주문:: 1회 구매 중량 한도 체크, 1일 구매 중량 한도 유효성 검사 통과");
            } else {
            	log.warn(">> 1회 구매 중량 한도 체크, oncePurchsWtLmt : " + oncePurchsWtLmt + ", orderWt : " + orderModel.getOrderWt());
                if(oncePurchsWtLmt >= orderModel.getOrderWt()) {
                    log.warn(">> 1회 구매 중량 한도, 주문 가능");
                } else {
                    log.info("OrderServiceImpl orderValidation line-1011 vo.toString() >> " + orderModel.toString());
                    orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                    throw new CommCustomException("업체별 1회 구매 중량["+StringUtil.formatMoney(String.valueOf(oncePurchsWtLmt))+"] 한도초과\n[주문 중량 : "+StringUtil.formatMoney(String.valueOf(orderModel.getOrderWt()))+"]");
                }

                log.warn(">> 1일 구매 중량 한도 체크, onedePurchsWtLmt : " + onedePurchsWtLmt + ", getTotRealOrderWtByEntrps : " + getTotRealOrderWtByEntrps + ", orderWt : " + orderModel.getOrderWt());
                if(onedePurchsWtLmt >= (getTotRealOrderWtByEntrps + orderModel.getOrderWt())) {
                    log.warn(">> 1일 구매 중량 한도, 주문 가능");
                } else {
                    log.info("OrderServiceImpl orderValidation line-1018 vo.toString() >> " + orderModel.toString());
                    orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                    throw new CommCustomException("업체별 1일 구매 중량["+StringUtil.formatMoney(String.valueOf(onedePurchsWtLmt))+"] 한도초과\n[업체별 총 주문 중량 합 : "+StringUtil.formatMoney(String.valueOf(getTotRealOrderWtByEntrps))+"]");
                }
            }
        }

        int dailCdtlnPurchsWtLmt = orderModel.getMbDlvrgBas().getDailCdtlnPurchsWtLmt(); // 일일 여신 구매 중량 한도, 케이지크레딧일 경우에만 체크
        log.warn(">> [orderValidation] 일일 여신 구매 중량 한도 (dailCdtlnPurchsWtLmt) : " + dailCdtlnPurchsWtLmt);

        // 케이지크레딧일 경우 추가로 체크 : 일일 여신 구매 중량 한도(MB_ENTRPS_INFO_BAS - DAIL_CDTLN_PURCHS_WT_LMT) 값 체크 [-1(NULL): 체크 안함, 0: 체크안함, 0 초과 시 한도초과 체크]
        if(StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty") && StringUtils.equals(orderModel.getCdtlnSvcSeCode(), "02")) {
            // 케이지크레딧인 경우
            if(dailCdtlnPurchsWtLmt == -1 || dailCdtlnPurchsWtLmt == 0) {
                log.warn(">> 일일 여신 구매 중량 한도가 null(-1)이거나 0이면 유효성 체크하지 않는다.");
            } else {
                orderModel.setTodayTotRealOrderWtCnd("entrpsSorincredt"); // 업체 단위 케이지크레딧 조건을 넣기 위함
                // [상품별 하루 총 실제 주문 중량] 또는 [업체 단위 메탈코드별 하루 총 실제 주문 중량] 또는 [업체 단위 케이지크레딧 하루 총 실제 주문 중량] 가져오기
                int getTotRealOrderWtByEntrpsSorincredt = orderMapper.getTotRealOrderWt(orderModel);
                log.warn(">> 일일 여신 구매 중량 한도 체크, dailCdtlnPurchsWtLmt : " + dailCdtlnPurchsWtLmt + ", getTotRealOrderWtByEntrpsSorincredt : " + getTotRealOrderWtByEntrpsSorincredt + ", orderWt : " + orderModel.getOrderWt());
                if(dailCdtlnPurchsWtLmt >= (getTotRealOrderWtByEntrpsSorincredt + orderModel.getOrderWt())) {
                    log.warn(">> 일일 여신 구매 중량 한도, 주문 가능");
                } else {
                    log.info("OrderServiceImpl orderValidation line-1039 vo.toString() >> " + orderModel.toString());
                    orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                    throw new CommCustomException("업체별 일일 여신 구매 중량["+StringUtil.formatMoney(String.valueOf(dailCdtlnPurchsWtLmt))+"] 한도초과\n[업체별 총 주문 중량 합 : "+StringUtil.formatMoney(String.valueOf(getTotRealOrderWtByEntrpsSorincredt))+"]");
                }
            }
        }

        // 주문 프라이싱 정보 가져오기 및 프라이싱 존재 체크
        orderModel.setOrPricingBas(Optional.ofNullable(orderMapper.selectOrPricingInfo(orderModel)).orElseThrow(() -> {
            log.info("OrderServiceImpl orderValidation line-1047 vo.toString() >> " + orderModel.toString());
            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
            return new CommCustomException("프라이싱 정보 미존재,\n관리자에게 문의 바랍니다.");}));

        // 판매 가격 및 프리미엄 가격에 따른 주문 금액 정보 계산
        if(!StringUtils.equals(orderModel.getSleMthdCode(), "02")) {
//          // 지정가 가격 도달 시 진행되는 주문은 브랜드 무관일 경우를 제외하고 실시간 판매 가격 정보를 set 하지 않는다, 이미 세팅되어 있음
//          // 지정가 가격 도달 시 진행되는 주문이 아닐 경우
//          if(!StringUtils.equals("touch", orderModel.getLimitSection())) {
            String brandCode = ""; // 브랜드코드
            if(!StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals(orderModel.getSleMthdCode(), "03")) {
                brandCode = orderModel.getRealBrandCode(); // 화면에서 넘겨준 브랜드코드, 예시) 브랜드무관이면 브랜드무관으로
            } else {
                brandCode = orderModel.getBrandCodeByPremium(); // 최적의 bl로 결정된 브랜드코드
            }

            // 평균가-평균가 주문
            if(StringUtils.equals(orderModel.getSleMthdCode(), "04")) {
                // 조정계수 세팅을 위해 판매가격 정보 빈 객체 생성
                orderModel.setPrSelVO(new PrSelVO());
                // 실시간 프리미엄 정보를 조회하지 않으므로 평균가 프리미엄 세팅을 위해 빈 객체 생성
                orderModel.setLivePremiumVO(new LivePremiumVO());
            } else {
                // 실시간 판매 가격 정보 조회 및 체크
                orderModel.setPrSelVO(Optional.ofNullable(pcInfoService.getNewestPrSelRltm(orderModel.getMetalCode(), orderModel.getItmSn(), orderModel.getDstrctLclsfCode(), orderModel.getBrandGroupCode(), brandCode, DateUtil.getNowDateTime("yyyyMMdd"))).orElseThrow(() -> {
                    log.info("OrderServiceImpl orderValidation line-1054 vo.toString() >> " + orderModel.toString());
                    return new CommCustomException("실시간 판매가격 정보 미존재");
                }));

                log.warn(">> 실시간 판매 가격 정보 조회 orderModel.getPrSelVO() 존재 확인 : " + orderModel.getPrSelVO());

                // LIVE와 고정가가 DB에 넣을 때 같이 쓰기에 담아준다, 지정가는 프리미엄 아이디가 필요
                orderModel.setPremiumNo(orderModel.getPrSelVO().getPremiumNo());

                // 지정가 체결이 아닐 경우 체크, 체결 시에는 체크하지 않는다 20231017
                if(!StringUtils.equals("touch", orderModel.getLimitSection())) {
                    String lmePcRltmSn = orderModel.getPrSelVO().getLmePcRltmSn();  // LME 가격 실시간 순번
                    String ehgtPcRltmSn = orderModel.getPrSelVO().getEhgtPcRltmSn(); // 환율 가격 실시간 순번

                    log.warn(">> lmePcRltmSn : " + lmePcRltmSn + ", " + lmePcRltmSn.substring(0, 14));
                    log.warn(">> ehgtPcRltmSn : " + ehgtPcRltmSn + ", " + ehgtPcRltmSn.substring(0, 14));

                    long currentTime = System.currentTimeMillis();
                    log.warn(">> currentTime : " + currentTime);
                    SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmss");

                    // LME 순번 값 체크 및 LME 수집 시간 간격 체크
                    if(StringUtils.isEmpty(lmePcRltmSn)) {
                        throw new CommCustomException("[1]현재 일시적인 문제로 주문 및 시세 제공이 불가능합니다,\n관리자에게 문의 바랍니다.");
                    } else {
                        Date lmeDate = dateTimeFormat.parse(lmePcRltmSn.substring(0, 14));
                        long lmeTime = lmeDate.getTime();
                        log.warn(">> lmeTime calc : " + lmeTime + ", " + (currentTime - lmeTime) + ", " + orderModel.getLmeColctTimeIntrvlVal());
                        if((currentTime - lmeTime) > (orderModel.getLmeColctTimeIntrvlVal()*1000)) {
                            throw new CommCustomException("[2]현재 일시적인 문제로 주문 및 시세 제공이 불가능합니다,\n관리자에게 문의 바랍니다.");
                        }
                    }

                    // 환률 순번 값 체크 및 환률 수집 시간 간격 체크
                    if(StringUtils.isEmpty(ehgtPcRltmSn)) {
                        throw new CommCustomException("[3]현재 일시적인 문제로 주문 및 시세 제공이 불가능합니다,\n관리자에게 문의 바랍니다.");
                    } else {
                        Date ehgtDate = dateTimeFormat.parse(ehgtPcRltmSn.substring(0, 14));
                        long ehgtTime = ehgtDate.getTime();
                        log.warn(">> ehgtTime calc : " + ehgtTime + ", " + (currentTime - ehgtTime) + ", " + orderModel.getEhgColctTimeIntrvlVal());
                        if((currentTime - ehgtTime) > (orderModel.getEhgColctTimeIntrvlVal()*1000)) {
                            throw new CommCustomException("[4]현재 일시적인 문제로 주문 및 시세 제공이 불가능합니다,\n관리자에게 문의 바랍니다.");
                        }
                    }
                }

                // 프리미엄 가격 정보 조회 및 체크
            	if(StringUtils.equals("0104", orderModel.getSleMthdDetailCode())) { // 계약구매-지정가는 실시간 프리미엄 데이터 등록하므로 제외
                    // 실시간 프리미엄 정보를 조회하지 않으므로 평균가 프리미엄 세팅을 위해 빈 객체 생성
                    orderModel.setLivePremiumVO(new LivePremiumVO());
                    orderModel.setPremiumNo(null);
                    // 단가 계산시점에 실제 사용한 조정계수 데이터 세팅해줌
                    orderModel.getPrSelVO().setLmeMdatCffcnt(null);
                    orderModel.getPrSelVO().setFxMdatCffcnt(null);
                } else {
                    // 실시간 프리미엄 조회
                    orderModel.setLivePremiumVO(
                            Optional.ofNullable(
                                    pcInfoService.getLivePremiumInfo("present", orderModel.getPremiumNo())
                            ).orElseThrow(() -> {return new CommCustomException("프리미엄 가격 미존재,\n관리자에게 문의 바랍니다.");})
                    );
                }

            log.warn(">> 실시간 판매 가격 정보 조회 orderModel.getPrSelVO() 존재 확인 : " + orderModel.getPrSelVO());

            // 선물 SKIP 여부, 선물 틱 설정 값 등 정보 조회
            BigDecimal threemonthLmePc = Optional.ofNullable(orderModel.getPrSelVO().getThreemonthLmePc()).orElse(BigDecimal.ZERO); // 3개월 LME 가격(3M 가격)
            orderModel.setCommFtrsFshgMngVO(Optional.ofNullable(commFtrsFshgMngService.getFtrsFshgMngRetVo(orderModel.getMetalCode(), "B", threemonthLmePc)).orElseThrow(() -> {return new CommCustomException("선물 SKIP 여부, 선물 틱 설정 값 등 정보 미존재");}));
            log.warn(">> 실시간 판매 가격 정보 조회 (선물 SKIP 여부, 선물 틱 설정 값 등 정보 조회) orderModel.getCommFtrsFshgMngVO() : " + orderModel.getCommFtrsFshgMngVO());

//            // 지정가 가격 도달 시 진행되는 주문인지
//            if(StringUtils.equals("touch", orderModel.getLimitSection())) {
//                // 프리미엄 가격 정보 조회 및 체크, 프리미엄 아이디 및 관련 조건으로 프리미엄 가격 정보 조회
//                orderModel.setLivePremiumVO(
//                    Optional.ofNullable(
//                            pcInfoService.getLivePremiumInfo(
//                            "past", orderModel.getPrSelVO().getPremiumId(), orderModel.getMetalCode()
//                            , orderModel.getItmSn(), orderModel.getDstrctLclsfCode(), orderModel.getBrandGroupCode()
//                            , orderModel.getBrandCodeByPremium(), null
//                        )
//                    ).orElseThrow(() -> {return new CommCustomException("프리미엄 가격 미존재,\n관리자에게 문의 바랍니다.");})
//                );
//
//                orderModel.setPremiumNo(orderModel.getLivePremiumVO().getPremiumNo()); // 프리미엄 번호 set
//            }
            }

            // 평균가 주문인 경우, 판매 프리미엄을 평균가 프리미엄 가격으로 재설정
            // 평균가-지정가의 경우, 실시간 프리미엄 사용함
            if(StringUtils.equals("04", orderModel.getSleMthdCode()) || StringUtils.equals("0104", orderModel.getSleMthdDetailCode())) {
                orderModel.getLivePremiumVO().setSlePremiumAmount(orderModel.getCntrctOrderBasInfo().getPremiumPc());
            }

            log.warn(">> 프리미엄 가격 정보 조회 orderModel.getLivePremiumVO() 존재 확인 : " + orderModel.getLivePremiumVO());

            // LIVE와 고정가가 DB에 넣을 때 같이 쓰기에 담아준다.
            if(orderModel.getLivePremiumVO() != null) {
                log.warn(">> 프리미엄 가격 정보 조회 orderModel.getLivePremiumVO() : " + String.valueOf(orderModel.getLivePremiumVO()));

                BigDecimal premiumStdrAmount = Optional.ofNullable(orderModel.getLivePremiumVO().getPremiumStdrAmount()).orElse(BigDecimal.ZERO); // 프리미엄 기준 금액
                BigDecimal dstrctChangeAmount = Optional.ofNullable(orderModel.getLivePremiumVO().getDstrctChangeAmount()).orElse(BigDecimal.ZERO); // 권역 변동 금액
                BigDecimal brandGroupChangeAmount = Optional.ofNullable(orderModel.getLivePremiumVO().getBrandGroupChangeAmount()).orElse(BigDecimal.ZERO); // 브랜드 그룹 변동 금액
                BigDecimal brandChangeAmount = Optional.ofNullable(orderModel.getLivePremiumVO().getBrandChangeAmount()).orElse(BigDecimal.ZERO); // 브랜드 변동 금액
                BigDecimal compPremiumSum = premiumStdrAmount.add(dstrctChangeAmount).add(brandGroupChangeAmount).add(brandChangeAmount); // 판매 프리미엄 금액과 비교용

                log.warn(">> 판매 프리미엄 금액과 비교 : " + compPremiumSum.longValue() + ", " + orderModel.getLivePremiumVO().getSlePremiumAmount());

                // 프리미엄 기준 금액 + 권역 변동 금액 + 브랜드 그룹 변동 금액 + 브랜드 변동 금액의 합이 판매 프리미엄 금액과 다르면 주문 불가
                // 2023-10-20: 평균가 주문인 경우 제외, 평균가 프리미엄은 실시간 프리미엄과 별도로 설정함, 평균가-지정가는 실시간 프리미엄 사용하므로 체크필요
            	if(!(StringUtils.equals(orderModel.getSleMthdCode(), "04") || StringUtils.equals(orderModel.getSleMthdDetailCode(), "0104"))) {
                    if(compPremiumSum.longValue() != orderModel.getLivePremiumVO().getSlePremiumAmount()) {
                        orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                        throw new CommCustomException("판매 가격 설정을 확인해야 합니다,\n관리자에게 문의 바랍니다.");
                    }
                }
                orderModel.setPremiumPc(new BigDecimal(String.valueOf(orderModel.getLivePremiumVO().getSlePremiumAmount()))); // 판매 프리미엄 금액

                // 지정가 가격 도달 시 진행되는 주문인지

                if(StringUtils.equals("touch", orderModel.getLimitSection())) {
                    BigDecimal tempBrandPremium = BigDecimal.ZERO; // 브랜드 변동 금액

                    // 브랜드 무관이 아닐 경우
                    if(!StringUtils.equals("0000000000", orderModel.getRealBrandCode())) {
                        tempBrandPremium = brandChangeAmount; // 브랜드 변동 금액
                    }

                    // 프리미엄 기준 금액 + 권역 변동 금액 + 브랜드 그룹 변동 금액 + 브랜드 변동 금액
                    BigDecimal tempPremiumSumExceptBrand = BigDecimal.ZERO;
                	tempPremiumSumExceptBrand = premiumStdrAmount.add(dstrctChangeAmount).add(brandGroupChangeAmount).add(tempBrandPremium);

                    orderModel.getPrSelVO().setNonPremiumEndPc(orderModel.getLimitInputAmount() - tempPremiumSumExceptBrand.longValue()); // 프리미엄 제외 금액 구하기
                }
            }

            // 23-05-17 변경사항 : 지정가 주문 등록일 경우, 상품 단가를 주문 모달창에서 입력 받은 "최종 상품 단가"로 대체한다.
            long calcGoodsUntpc = 0;
        	if(StringUtils.equals("03", orderModel.getSleMthdCode()) && !StringUtils.equals("touch", orderModel.getLimitSection())) {
                calcGoodsUntpc = ((LimitOrderModel)orderModel).getLastGoodsUntpc();	// 지정가 주문 시점
            } else if(StringUtils.equals("03", orderModel.getSleMthdCode()) && StringUtils.equals("0304", orderModel.getSleMthdDetailCode()) && StringUtils.equals("touch", orderModel.getLimitSection())) {
            	calcGoodsUntpc = orderModel.getCntrctPurchsLastGoodsUntpc(); 		// 계약구매-지정가 체결 시점
            } else if(StringUtils.equals(orderModel.getSleMthdCode(), "04") || StringUtils.equals("0104", orderModel.getSleMthdDetailCode())) {
                calcGoodsUntpc = commOrderService.getAvrgpcGoodsUntpc(orderModel);  // 평균가 단가 계산
            } else {    // endPc(종료 가격) + slePremiumAmount(판매 프리미엄 금액)
                calcGoodsUntpc = orderModel.getPrSelVO().getNonPremiumEndPc() + orderModel.getLivePremiumVO().getSlePremiumAmount();
            }

            // 가격 정보 셋팅 (배송비, 공급가, 부가세, 판매가 계산 제외 - 배송비 때문)
            commOrderService.setPriceInfo(orderModel, calcGoodsUntpc, orderModel.getOrderWt());

        } else {
            // 케이지몰 판매 가격 정보 및 프리미엄 가격 조회, 체크
            orderModel.setFixPriceVO(
//                  Optional.ofNullable(
//                          pcInfoService.hasEntrpsFixPriceData(orderModel.getMetalCode(), orderModel.getItmSn(), orderModel.getDstrctLclsfCode()
//                                  , orderModel.getBrandGroupCode(), orderModel.getRealBrandCode(), orderModel.getEntrpsNo()
//                                  , DateUtil.getNowDateTime("yyyyMM"))
//                  ).orElseThrow(() -> {return new CommCustomException("케이지몰 판매가격 정보 미존재");})
                    Optional.ofNullable(
                            pcInfoService.hasEntrpsFixPriceData(orderModel.getMetalCode(), orderModel.getItmSn(), orderModel.getDstrctLclsfCode()
                                    , orderModel.getBrandGroupCode(), orderModel.getBrandCodeByPremium(), orderModel.getEntrpsNo()
                                    , DateUtil.getNowDateTime("yyyyMM"))
                    ).orElseThrow(() -> {return new CommCustomException("케이지몰 판매가격 정보 미존재");})
            );
            log.warn(">> 케이지몰 판매 가격 정보 조회 orderModel.getFixPriceVO() 존재 확인 : " + orderModel.getFixPriceVO());

            // LIVE와 고정가가 DB에 넣을 때 같이 쓰기에 담아준다.
            if(orderModel.getFixPriceVO() != null) {
                log.warn(">> 케이지몰 판매 가격 정보 조회 orderModel.getFixPriceVO() : " + String.valueOf(orderModel.getFixPriceVO()));
                orderModel.setPremiumNo(orderModel.getFixPriceVO().getPremiumNo());

                log.warn(">> 제한 중량 : " + orderModel.getFixPriceVO().getLmttWt());
                String lmttWtStr = orderModel.getFixPriceVO().getLmttWt();

                FixingPcOrderPossWtCeckVO fixingPcOrderPossWtCeckInfo = this.getFixingPcOrderPossWtCeckInfo(orderModel.getDstrctLclsfCode(), orderModel.getItmSn(), orderModel.getEntrpsNo()
                        , orderModel.getFixPriceVO().getSorinmallUnitPdCode(), lmttWtStr, orderModel.getOrderWt()
                        , orderModel.getSleMthdCode());

                log.warn(">> fixingPcOrderPossWtCeckInfo : " + String.valueOf(fixingPcOrderPossWtCeckInfo));

                if(StringUtils.equals("N", fixingPcOrderPossWtCeckInfo.getOrderPossYn())) {

                    if(fixingPcOrderPossWtCeckInfo.getTotRealOrderWt() == -1) {
                        throw new CommCustomException("제한 중량 미존재");
                    } else {
                        throw new CommCustomException("주문 가능 중량 ["+ ((fixingPcOrderPossWtCeckInfo.getTotRealOrderWt()+orderModel.getOrderWt()) - Double.parseDouble(lmttWtStr)) + "] 초과");
                    }
                }

//              BigDecimal hghnetprcDstrctChangeAmount = Optional.ofNullable(orderModel.getFixPriceVO().getHghnetprcDstrctChangeAmount()).orElse(BigDecimal.ZERO); // 고정가 권역 변동 금액, 20230310 제거
//              BigDecimal hghnetprcBrandGroupChangeAmount = Optional.ofNullable(orderModel.getFixPriceVO().getHghnetprcBrandGroupChangeAmount()).orElse(BigDecimal.ZERO); // 고정가 브랜드그룹 변동 금액, 20230310 제거
//              BigDecimal hghnetprcBrandChangeAmount = Optional.ofNullable(orderModel.getFixPriceVO().getHghnetprcBrandChangeAmount()).orElse(BigDecimal.ZERO); // 고정가 브랜드 변동 금액, 20230310 제거
//              BigDecimal premiumPc = hghnetprcDstrctChangeAmount.add(hghnetprcBrandGroupChangeAmount).add(hghnetprcBrandChangeAmount);, 20230310 제거
//
//              orderModel.setPremiumPc(premiumPc); // 고정가 권역 변동 금액 + 고정가 브랜드그룹 변동 금액 + 고정가 브랜드 변동 금액, 20230310 제거

//              // 프리미엄 가격 정보 조회 , 가져올 정보가 없음.. 제거해야 하나???? 제거로 결정
//              orderModel.setPremiumNo(orderModel.getFixSelVO().getPremiumNo());
//              orderModel.setFixPriceVO(Optional.ofNullable(pcInfoService.getFixPriceNo(orderModel.getPremiumNo())).orElseThrow(() -> {return new CommCustomException("프리미엄 가격 미존재");}));
//              log.debug(">> orderModel.getFixPriceVO() : " + String.valueOf(orderModel.getFixPriceVO()));
                // 가격 정보 셋팅 (배송비, 공급가, 부가세, 판매가 계산 제외 - 배송비 때문)
//              setPriceInfo(orderModel, Optional.ofNullable(orderModel.getFixPriceVO().getHghnetprcSleAmount()).orElse(BigDecimal.ZERO).longValue(), orderModel.getOrderWt()); 20230310 제거

                // 판매금액 변경, 20230310 hghnetprcSleAmount에서 slePc로 변경
                commOrderService.setPriceInfo(orderModel, Optional.ofNullable(orderModel.getFixPriceVO().getSlePc()).orElse(BigDecimal.ZERO).longValue(), orderModel.getOrderWt());
            }
        }

        // LME 마크업 설정 값
    	String lmeMarkUpAt = orderMapper.selectLmeMarkUpAt();
    	orderModel.setLmeMarkUpAt(lmeMarkUpAt);
    	if(StringUtils.equals(lmeMarkUpAt, "Y")) {
    		BigDecimal gainValue = orderMapper.selectGainValue();
			orderModel.setGainValue(gainValue);
    	}
    }

    /**
     * 최적의 BL리스트 가져오기 및 상품 재고 검색 체크
     *  1) 상품 재고 검색 체크
     *  2) 브랜드 검색 오류 (단일 브랜드이어야 한다)
     */
    @Override
    public void orderBlList(OrderModel orderModel) throws CommCustomException, Exception {
        // 새로 최적의 BL 가져오기 사용
        List<ItemPriceMatchingBlInfoVO> blList = getBlList(orderModel);
        log.info(">> orderBlList blList : " + String.valueOf(blList));

        // 상품 재고 검색 체크
        if(blList.isEmpty()) throw new CommCustomException("상품 재고 검색 실패");
        //ObjectMapper mapper = new ObjectMapper();
        //log.debug(mapper.writeValueAsString(blList));

        List<String> duplRemoveBrandCodeList = blList.stream().map(ItemPriceMatchingBlInfoVO::getBrandCode).distinct().collect(Collectors.toList());
        log.info(">> blList brandCode : " + String.valueOf(duplRemoveBrandCodeList));
        if(duplRemoveBrandCodeList.size() > 1) {
            throw new CommCustomException("브랜드 검색 오류["+String.valueOf(duplRemoveBrandCodeList)+"],\n관리자에게 문의 바랍니다.");
        }

        orderModel.setBlList(blList); // 최적의 bl 리스트 set
        log.info(">> orderBlList duplRemoveBrandCodeList.get(0) : " + duplRemoveBrandCodeList.get(0));
        orderModel.setBrandCodeByPremium(duplRemoveBrandCodeList.get(0)); // 프리미엄 가격을 위한 브랜드코드 (가격정보 가져올때 사용)

    	if(StringUtils.equals("Y", orderModel.getSmlqyPurchsAt())) {
    		// 소량구매일 경우, 조회된 BL의 자투리 할인 정보 재세팅
    		orderModel.setRmndrDscnt(blList.get(0).getRmndrDscnt());
        }
    }

    /**
     * 최적의 BL리스트 기준으로 입고예정재고여부(입고구분에의한) 파악 및 WMS 실시간 재고 파악 및 재고 차감, 주문 정합성 체크 3단계 (최적의 BL에서 BL번호 필요)
     * 21. 배송요율 유효성 체크
     *  1) 배송요율 정보 및 회원_배송지 정보 체크
     *  2) 배송 불가 및 서비스 불가능 지역 체크
     * 22. 실시간 물류 CAPA 확인[SOREC-IF-126] 유효성 체크
     * 23. WMS 실시간 재고 체크
     *  1) 실시간 재고 API 호출 체크 (현재 사용하지 않음)
     *  2) 실시간 재고 수량 체크 (현재 사용하지 않음)
     */
    @Override
    public void orderInvntryChk(OrderModel orderModel) throws CommCustomException, Exception {
        // BL 함수 조회 및 재고 체크
        int totBundleQy = 0;
//      List<ItemPriceMatchingBlInfoVO> blList = getBlList(orderModel);
        List<ItemPriceMatchingBlInfoVO> blList = orderModel.getBlList(); // 미리 호출하여 구성된 최적의 BL
        log.info(">> orderInvntryChk blList : " + String.valueOf(blList));

        // 24-02-27 변경사항 : 계약구매 - 평균가 주문도 해당 로직을 실행하도록 변경
        if(StringUtils.equals("04", orderModel.getSleMthdCode()) || StringUtils.isNotEmpty(orderModel.getSleMthdDetailCode())) {

            // 평균가 주문인 경우, 할당된 BL 리스트에서 BL별로 재고 파악
            for(ItemPriceMatchingBlInfoVO  bl : blList) {
            	 log.warn(">> orderInvntryChk dstrctMlsfcCode : " + bl.getDstrctMlsfcCode());
                 log.warn(">> bl : " + String.valueOf(bl));

                 log.warn(">> bl.getWrhousngSeCode() : " + bl.getWrhousngSeCode());
                 log.warn(">> bl.getWrhousngPrearngeInvntryAt() : " + bl.getWrhousngPrearngeInvntryAt());

                 // 입고 구분 코드가 4(입고예정재고 입고)이고 입고 예정 재고 여부가 Y일 경우
                 if(StringUtils.equals("4", bl.getWrhousngSeCode()) && StringUtils.equals("Y", bl.getWrhousngPrearngeInvntryAt()) ) {
                     // 입고 예정 재고 여부에 의한 주문 홀딩 여부, 주문 홀딩 여부 중에서 우선순위 최상위
                     orderModel.setOrderHoldingByWrhousngPrearngeInvntryUseAt("Y");
                 }

                 // selectSvcSeCode   배송요율 유효성 체크
                 // 배송요율 서비스 구분에 따른 주문 유효성 체크, 권역 중분류 중 하나라도 발생 시 주문 불가
                 // 서비스 구분 코드 01, 02일때 주문을 막는다 [01:배송불가, 02:서비스가능지역아님]
                 orderModel.setDstrctMlsfcCode(bl.getDstrctMlsfcCode()); // 권역 중분류 코드
                if(StringUtils.equals(orderModel.getDlvyMnCode(), "01")) {
                    // 배송 요율 조회를 위한 기본조건 설정
                    commOrderService.setDlvyTariffBaseInfo(orderModel);

                    Map<String, String> selectDlvyTariffInfo = commOrderService.selectDlvyTariffInfo(orderModel);
                    log.warn(">> orderInvntryChk > selectDlvyTariffInfo : " + selectDlvyTariffInfo);
                    // 배송요율 정보 및 회원_배송지 정보 체크
                    if(selectDlvyTariffInfo == null) {
                        throw new CommCustomException("배송요율 정보가 없거나 회원_배송지 정보가 적합하지 않습니다.");
                    } else {
                        String svcSeCode = String.valueOf(selectDlvyTariffInfo.get("SVC_SE_CODE")); // 서비스 구분 코드
                        log.warn(">> orderInvntryChk > svcSeCode : " + svcSeCode);
                        // 배송 불가 및 서비스 불가능 지역 체크
                        if(StringUtils.equals(svcSeCode, "01") || StringUtils.equals(svcSeCode, "02")) {
                            // 서비스 구분 코드 01, 02일때 주문을 막는다 [01:배송불가, 02:서비스가능지역아님]
                            String msg = "";
                            switch(svcSeCode) {
                                case "01" : msg = "배송 불가 지역입니다."; break;
                                case "02" : msg = "서비스 가능 지역이 아닙니다."; break;
                            }

                            log.warn(">> orderInvntryChk > svcSeCode msg : " + msg);

                            throw new CommCustomException(msg);
                        }
                    }
                }

                // 선택된 bl를 객체에 담기
                orderModel.setBlDetail(bl);

                // 할당된 BL에서 받아온 주문 할 번들 수
                BigDecimal searchBundleCntTemp = Optional.ofNullable(bl.getMatchedSleInvntryUnsleBundleBnt()).orElse(BigDecimal.ZERO);
                Double searchBundleCnt = searchBundleCntTemp.doubleValue();

                // 해당 BL의 실제 주문 번들 및 중량 셋팅
                bl.setRealMatchedOrderedBnt(bl.getMatchedOrderedBnt());
                bl.setRealMatchedSleInvntryUnsleBnt(bl.getMatchedSleInvntryUnsleBnt());
                bl.setRealMatchedSleInvntryUnsleBundleBnt(bl.getMatchedSleInvntryUnsleBundleBnt());
                // 실제 주문 번들 수 증가
                totBundleQy += searchBundleCnt.intValue();

                log.warn(">> totBundleQy : " + totBundleQy);

            } // for end
        } else {

             // 최적의 BL에서 준 리스트에서 BL별로 재고 파악 및 재고 차감
            for(ItemPriceMatchingBlInfoVO  bl : blList) {
                log.warn(">> orderInvntryChk dstrctMlsfcCode : " + bl.getDstrctMlsfcCode());
                log.warn(">> bl : " + String.valueOf(bl));

                log.warn(">> bl.getWrhousngSeCode() : " + bl.getWrhousngSeCode());
                log.warn(">> bl.getWrhousngPrearngeInvntryAt() : " + bl.getWrhousngPrearngeInvntryAt());

                // 입고 구분 코드가 4(입고예정재고 입고)이고 입고 예정 재고 여부가 Y일 경우
                if(StringUtils.equals("4", bl.getWrhousngSeCode()) && StringUtils.equals("Y", bl.getWrhousngPrearngeInvntryAt()) ) {
                    // 입고 예정 재고 여부에 의한 주문 홀딩 여부, 주문 홀딩 여부 중에서 우선순위 최상위
                    orderModel.setOrderHoldingByWrhousngPrearngeInvntryUseAt("Y");
                }

                // selectSvcSeCode   배송요율 유효성 체크
                // 배송요율 서비스 구분에 따른 주문 유효성 체크, 권역 중분류 중 하나라도 발생 시 주문 불가
                // 서비스 구분 코드 01, 02일때 주문을 막는다 [01:배송불가, 02:서비스가능지역아님]
                orderModel.setDstrctMlsfcCode(bl.getDstrctMlsfcCode()); // 권역 중분류 코드
                if(StringUtils.equals(orderModel.getDlvyMnCode(), "01")) {
                    // 배송 요율 조회를 위한 기본조건 설정
                    commOrderService.setDlvyTariffBaseInfo(orderModel);

                    Map<String, String> selectDlvyTariffInfo = commOrderService.selectDlvyTariffInfo(orderModel);
                    log.warn(">> orderInvntryChk > selectDlvyTariffInfo : " + selectDlvyTariffInfo);
                    // 배송요율 정보 및 회원_배송지 정보 체크
                    if(selectDlvyTariffInfo == null) {
                        orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                        throw new CommCustomException("배송요율 정보가 없거나 회원_배송지 정보가 적합하지 않습니다.");
                    } else {
                        String svcSeCode = String.valueOf(selectDlvyTariffInfo.get("SVC_SE_CODE")); // 서비스 구분 코드
                        log.warn(">> orderInvntryChk > svcSeCode : " + svcSeCode);
                        // 배송 불가 및 서비스 불가능 지역 체크
                        if(StringUtils.equals(svcSeCode, "01") || StringUtils.equals(svcSeCode, "02")) {
                            // 서비스 구분 코드 01, 02일때 주문을 막는다 [01:배송불가, 02:서비스가능지역아님]
                            String msg = "";
                            switch(svcSeCode) {
                                case "01" : msg = "배송 불가 지역입니다."; break;
                                case "02" : msg = "서비스 가능 지역이 아닙니다."; break;
                            }

                            log.warn(">> orderInvntryChk > svcSeCode msg : " + msg);

                            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                            throw new CommCustomException(msg);
                        }
                    }
                }

                // 선택된 bl를 객체에 담기
                orderModel.setBlDetail(bl);

                // 실시간 물류 CAPA 확인[SOREC-IF-126] 유효성 체크 start
                String orderCapaManageAt = orderModel.getOrderCapaManageAt(); // 주문 CAPA 관리 여부
                log.warn(">> orderCapaManageAt : " + orderCapaManageAt);
                log.warn(">> bl.getMatchedOrderedBnt() : " + bl.getMatchedOrderedBnt());
                String nfCapaUseAt = Optional.ofNullable(orderMapper.getNfCapaUseAt(bl.getWrhousCode())).orElse("N"); // 비철 CAPA 사용 여부 가져오기
                log.warn(">> nfCapaUseAt : " + nfCapaUseAt);

                if(StringUtils.equals("N", orderCapaManageAt)) {
                    // 실시간 CAPA 호출할 필요 없음(skip)
                } else {
                    // 호출 전 물류창고테이블에 해당 창고의 CAPA사용여부 체크
                    if(StringUtils.equals("N", nfCapaUseAt)) {
                        // 실시간 CAPA 호출할 필요 없음(skip)
                    } else {
                        // 실시간 CAPA 호출, SOREC-IF-126 IF 호출
                        Map<String, Object> reqMap = new HashMap<String, Object>();
                        reqMap.put("wrhousCode", bl.getWrhousCode()); // 창고코드
                        reqMap.put("dlvyRqestde", orderModel.getDlivyRequstDe().replaceAll("-", "")); // 배송요청일
                        log.warn(">> [CAPA] reqMap : " + reqMap);
                        log.warn(">> [CAPA] orProperty.getLgistCnfirm() : " + orProperty.getLgistCnfirm());
                        // 물류 실시간 CAPA 정보 조회
                        Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getLgistCnfirm(), reqMap);
                        log.warn(">> [CAPA] resObj : " + resObj);
                        if(resObj != null && resObj.get("nfUsefulCapa") != null) {
                            BigDecimal nfUsefulCapa = new BigDecimal(Optional.ofNullable(String.valueOf(resObj.get("nfUsefulCapa"))).orElse("0")); // 비철 가용 CAPA
                            log.warn(">> [CAPA] nfUsefulCapa : " + nfUsefulCapa);
                            // 주문톤수가 비철 가용 CAPA보다 많으면 주문 불가
                            if(bl.getMatchedOrderedBnt().compareTo(nfUsefulCapa) > 0) {
                                log.warn(">> [CAPA] 해당 물류센터["+bl.getWrhousCode()+"]에 CAPA["+nfUsefulCapa+"MT] 부족합니다.");
                                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                                throw new CommCustomException("해당 물류센터에 CAPA 부족합니다,\n배송요청일을 변경하시거나 고객센터로 연락해주세요");
                            }
                        } else {
                            log.warn(">> [CAPA] 실시간 CAPA 호출 실패");
                            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                            throw new CommCustomException("실시간 CAPA 호출 실패,\n관리자에게 문의 바랍니다.");
                        }
                    }
                }
                // 실시간 물류 CAPA 확인[SOREC-IF-126] 유효성 체크 end


                // 지정가 가격 도달 시 진행되는 주문은 제외, 20230510
                if(!StringUtils.equals("touch", orderModel.getLimitSection())) {
                    // WMS 재고 API 호출 MAP 생성
                    Map<String, Object> apiMap = new HashMap<String, Object>();
                    apiMap.put("wrhousCode", bl.getWrhousCode());
                    apiMap.put("itmCode", bl.getItmCode());
                    apiMap.put("blNo", bl.getBlNo());

                    Map<String, Object> resObj = new HashMap<String, Object>(); // 주석처리 test 용도
                    // WMS 실시간 재고 체크
        //          Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getLoInvntryUrl(), apiMap);
                    // 응답 받은 MAP에서 QY가 현재 BL의 남은 실시간 번들 수 -> API 명세서 확인
                    resObj.put("qy", "10000000"); // 주석처리 test 용도
        //          log.debug(">> 재고 체크 : " + String.valueOf(resObj));

                    log.warn(">> 재고 체크 resObj 존재 확인 : " + resObj);

                    // 실시간 재고 API 호출 체크
                    if(resObj != null) {
                        log.warn(">> 재고 체크 : " + String.valueOf(resObj));
                        log.warn(">> qy : " + resObj.get("qy"));

                        // 최적의 BL에서 받아온 주문 할 번들 수
        //              int searchBundleCnt = bl.getMatchedSleInvntryUnsleBundleBnt().intValue();
                        BigDecimal searchBundleCntTemp = Optional.ofNullable(bl.getMatchedSleInvntryUnsleBundleBnt()).orElse(BigDecimal.ZERO);
                        Double searchBundleCnt = searchBundleCntTemp.doubleValue();

                        // WMS 실시간 재고 에서 받아온 주문 가능한 총 번들 수 (double로 넘어옴)
                        double wmsBundleCnt = NumberUtils.toDouble(String.valueOf(resObj.get("qy")));

                        log.warn(">> searchBundleCnt : " + searchBundleCnt);
                        log.warn(">> wmsBundleCnt : " + wmsBundleCnt);

                        // 실시간 재고 수량 체크
                        if(wmsBundleCnt < searchBundleCnt) {
                            throw new CommCustomException("실시간 재고 수량 부족");
                        }else {
                            // 해당 BL의 실제 주문 번들 및 중량 셋팅
                            bl.setRealMatchedOrderedBnt(bl.getMatchedOrderedBnt());
                            bl.setRealMatchedSleInvntryUnsleBnt(bl.getMatchedSleInvntryUnsleBnt());
                            bl.setRealMatchedSleInvntryUnsleBundleBnt(bl.getMatchedSleInvntryUnsleBundleBnt());
                            // 실제 주문 번들 수 증가
                            totBundleQy += searchBundleCnt.intValue();
                        }
                    } else {
                        throw new CommCustomException("실시간 재고 호출 실패");
                    }

                    log.warn(">> totBundleQy : " + totBundleQy);

                    // 재고 차감 및 재고 차감 FLAG ( TRUE ) 변경 -> 추후 에러 발생시 해당 BL 원복을 위해
                    commOrderService.updateMinusInvntryBlInfoBas(orderModel);
                    bl.setInvntryUdt(true); // 실재 재고 변경 확인
                }
            } // for end
        }

        // 지정가 가격 도달 시 진행되는 주문은 제외, 20230510
        // 24-02-27 변경사항 : 계약구매 지정가 주문(0304)은 해당 로직 수행하도록 조건문 변경
        if(!StringUtils.equals("touch", orderModel.getLimitSection()) || StringUtils.equals("0304", orderModel.getSleMthdDetailCode())) {
            // 실제 주문 총 중량 셋팅
            orderModel.setTotBundleQy(totBundleQy);
            // 재조회를 안하기 위해 최적의 BL 리스트 객체에 주소값 저장 (수정된 blList를 다시 덮어 쓴다)
            orderModel.setBlList(blList);

            // 지정 BL 삭제 추가 - 소량구매일 경우 제외
            if(!StringUtils.equals(orderModel.getSmlqyPurchsAt(), "Y") && StringUtil.isNotEmpty(orderModel.getReMainBlNo())) {
                // 지정 BL 일때 지정한 [지정 BL 판매관리] 화면 의 내용을 삭제
                // 톨로런스 범위 이하일때만 삭제 토록
                BigDecimal bnt = Optional.ofNullable(orderModel.getBlDetail().getMatchedSleInvntryUnsleBnt()).orElse(BigDecimal.ZERO);//
                // 25 * (100 - orderModel.getBlDetail().getCtrtcBeginPermWtRate()) / 100);  ---> HST 처리 추가~
                BigDecimal bnt2 = new BigDecimal(orderModel.getSleUnitWt() * (100 - orderModel.getBlDetail().getCtrtcBeginPermWtRate()) / 100);
            // 1.톨러런스 이하이거나
            // OR
            // 2. 재고 차감후 실제 번들이 0
            // OR
            // 3. 선물잔량이 0 (선물잔량이 차감 전일수 있음.)
            // -> (0 == orderModel.getBlDetail().getRemainQy() - orderModel.getBlDetail().getMatchedOrderedBnt().intValue() / orderModel.getSamsungOrderWt())
            if(bnt.compareTo(bnt2) < 0
                || 0 == orderModel.getAfterSleInvntryUnsleBnt()
                || 0 == orderModel.getBlDetail().getRemainQy()) {
                orderMapper.deleteMbEntrpsSpcifyBrandRls(orderModel);
                    //orderMapper.insertMbEntrpsSpcifyBrandRls(orderModel);
                    //commonService.insertTableHistory("EV_COUPON_ISU", orderModel);
                }
            }
        }
    }

    /**
     * 배송비, 공급가, 부가세, 판매가 구하기 및 주문 정합성 체크 2단계 (판매가와 비교해야하기 위해)
     * 20. 이월렛 잔액 체크 또는 담보 보증 남은 한도 체크
     *  1) 이월렛 잔액 체크일 경우
     *   (1) Ewallet 잔금 조회 API 통신 체크
     *   (2) Ewallet 금액 부족 체크
     *  2) (전자상거래보증 or 케이지크레딧) 남은 한도 체크일 경우
     *   (1) (전자상거래보증 or 케이지크레딧) 남은 한도 부족 체크
     *
     *  23-06-09 변경사항 : 이월렛 잔액 체크 또는 담보 보증 남은 한도 체크 시, 지정가 주문으로 발생한 예수금도 포함하여 체크하도록 변경
     */
    @Override
    public void setPriceInfoByExpectDlvrf(OrderModel orderModel, boolean ewalletMoneyCheckStatus, int orderWt, boolean newGetBlListUseStatus) throws CommCustomException, Exception {

        commOrderService.setOrderPcWithDlvrfAndCoupon(orderModel, orderWt, newGetBlListUseStatus);
        
        // 24-10-15 변경사항 : 가단가(05) 주문 시, 가단가 거래 불가 여부를 체크하고, 추가로 받는 금액에 대하여 조회 및 세팅(최초 가격 변동 금액, 유지 변동금, 가격 변동금)
        // 24-10-23 변경사항 : 상품_가격 변동금 관리 기본에서 관련 설정값 조회 시, 할인이 적용된 최종 주문 단가로 조회를 하도록 로직 위치 이동 및 수정
        //						공급가, 부가세, 판매가도 추가로 계산하도록 로직 추가
    	if(StringUtils.equals(orderModel.getSleMthdCode(), "05")) {
    		// 상품_가격 변동금 관리 기본에서 단가 구간에 따른 설정값(가격 변동금, 유지 변동금, 거래 불가 여부) 조회
    		OrderModel pcChangegldManageInfo = Optional.ofNullable(orderMapper.selectItPcChangegldManageBas(orderModel, orderModel.getGoodsUntpc()))
    													.orElseThrow(() -> {return new CommCustomException("가격 변동금 설정 미존재.\r\n관리자에게 문의 바랍니다.");});
    		
    		// 거래 불가 여부가 Y 일 시, 거래 불가 예외 처리
    		if(StringUtils.equals(pcChangegldManageInfo.getDelngImprtyAt(), "Y")) {
    			throw new CommCustomException("현재 상품 단가로 가단가 구매가 불가능 합니다.\n관리자에게 문의 바랍니다.");
    		}
    		
    		// 가격 변동금 세팅, 유지 변동금, 최초 가격 변동 금액
    		long pcChangegld = pcChangegldManageInfo.getFrstPcChangeAmount() * orderModel.getOrderWt();
    		
    		orderModel.setPcChangegld(pcChangegld);	// 가격 변동금 = 최초 가격 변동 금액 * 주문 중량
    		orderModel.setMntncChangeAmount(pcChangegldManageInfo.getMntncChangeAmount());						// 유지 변동금
    		orderModel.setFrstPcChangeAmount(pcChangegldManageInfo.getFrstPcChangeAmount());					// 최초 가격 변동 금액
    		
    		// 24-10-23 변경사항 : 공급가, 부가세, 판매가에 가격 변동금 추가 계산
    		long splpc = orderModel.getSplpc() + pcChangegld;
    		long vat = (long) (splpc * 0.1);
    		long slepc = splpc + vat;
    		
    		orderModel.setSplpc(splpc);
    		orderModel.setVat(vat);
    		orderModel.setSlepc(slepc);
    	}

        long slepc = orderModel.getSlepc();

        // 이월렛 잔액 체크 또는 담보 보증 남은 한도 체크
        if (StringUtils.equals(orderModel.getPaymentMn(), "ewallet") || StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
            // 주문 모달창에 선택된 결제 수단 값이 e-Wallet, 증거금일 경우에 이월렛 잔액 체크를 한다.

            long chkAmount = 0l; // 잔액 체크할 금액 (이월렛일 경우 판매가, 증거금으로 주문하기일 경우 증거금 비율 금액)

            // 증거금으로 주문하기일 경우 증거금 비율 금액으로 체크 금액을 세팅하고 orderModel 객체에 담는다.
            if (StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
                // 증거금 비율 선택 값으로 증거금 비율 금액이 있는 객체를 찾는다.
                OrderPurchsInclnGradeVO entrpsPurchsInclnGradeInfo = orderModel.getEntrpsSetleMnInfo().getEntrpsPurchsInclnGradeInfoAllList().stream()
                        .filter(data -> ( data.getPurchsInclnStepRate() == orderModel.getPurchsInclnStepRate() )).collect(Collectors.toList()).get(0);

                orderModel.setPurchsInclnStepAmount(entrpsPurchsInclnGradeInfo.getPurchsInclnStepAmount()); // 증거금 비율 금액을 주문객체에 담는다.
                chkAmount = Long.valueOf(entrpsPurchsInclnGradeInfo.getPurchsInclnStepAmount()*orderWt); // 증거금 비율 금액 * 주문중량
                orderModel.setMummSetleAmount(chkAmount); // 최소 결제 금액
            } else {
                chkAmount = orderModel.getSlepc(); // 판매가

                //지정가 주문 & 쿠폰 사용 여부 Y 인 경우 or 계약구매-지정가 주문인 경우 or 소량구매인 경우
                //예수금 = 쿠폰할인금액, 등급할인금액, 자투리할인 제외된 금액으로 저장
                if(("03").equals(orderModel.getSleMthdCode())) {
                	if(("Y").equals(orderModel.getCouponApplcAt())
                	 || orderModel.getGradApplcAmount() != 0
                	 || StringUtils.equals("0304", orderModel.getSleMthdDetailCode())
                	 || StringUtils.equals("Y", orderModel.getSmlqyPurchsAt())) {
                		chkAmount = orderModel.getReSlepc();
                	}
                }
                orderModel.setAdvrcvAmount(chkAmount);
            }

            //String dlvrfDscntAt = String.valueOf(expectDlvrfMap.get("dlvrfDscntAt")); //할인여부 ( N 일경우 할인 전 )

            // 2022-08-17 jhcha  할인금액 쿠폰할인금액으로 변경
            //if(expectDlvrf == 0) { //배송비가 0원일 경우 배송비 할인 X
            //  orderModel.setDlvrfDscntAt("N");
            //}else{
            //  if(dlvrfDscntAt.equals("N")){
            //expectDlvrf = expectDlvrf - dscntExpectDlvrf ;
            //      orderModel.setDlvrfDscntAt("Y");
            //  }else {
            //      orderModel.setDlvrfDscntAt("N");
            //  }
            //}

            //long expectDlvrf = Long.parseLong(Optional.ofNullable(String.valueOf(getCheckDataDlvyTariff(orderModel, orderWt, newGetBlListUseStatus).get("expectDlvrf"))).orElse("0"));

            if (ewalletMoneyCheckStatus) {
                Map<String, Object> ewalletMap = new HashMap<>();
                ewalletMap.put("entrpsNo", orderModel.getEntrpsNo());
                ewalletMap.put("limitSection", orderModel.getLimitSection());

                // 이월렛 잔금 조회
                long ewalletMoney = 0;
                boolean ewalletBlceInqireSuccesSttus = false; // 이월렛 잔액 조회 상태 (true : 성공, false : 실패)

                Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getEwalletMoneyUrl(), ewalletMap);
                log.warn(">> E-WALLET 잔금 조회 resObj : " + resObj);
                // 이월렛 잔금 조회 API 호출 체크
                if (resObj == null) {
                    log.warn(">> [setPriceInfoByExpectDlvrf] 이월렛 잔금 조회 호출 실패");
                    log.info("OrderServiceImpl setPriceInfoByExpectDlvrf line-1536 vo.toString() >> " + orderModel.toString());

                    // 지정가 주문 touch 시점이 아닐 경우 예외 처리
                    if(!StringUtils.equals("touch", orderModel.getLimitSection())) {
                        orderModel.setLimitOrderSttusCode("95"); // 지정가 주문 상태 코드[95.체결실패(기타)] set
                        throw new CommCustomException("이월렛 잔금 조회 호출 실패,\n관리자에게 문의 바랍니다.");
                    }

                } else {
                    if (resObj.get(PdCommConstant.EWALLET_DATA_KEY) != null) {
                        ewalletBlceInqireSuccesSttus = true; // 이월렛 잔액 조회 성공

                        Map<String, Object> dataObj = (Map<String, Object>) resObj.get(PdCommConstant.EWALLET_DATA_KEY);
                        ewalletMoney =  NumberUtils.toLong(String.valueOf(dataObj.get(PdCommConstant.EWALLET_MONNY_KEY)));
                    } else {
                        log.info("OrderServiceImpl setPriceInfoByExpectDlvrf line-1543 vo.toString() >> " + orderModel.toString());

                        // 지정가 주문 touch 시점이 아닐 경우 예외 처리
                        if(!StringUtils.equals("touch", orderModel.getLimitSection())) {
                            orderModel.setLimitOrderSttusCode("95"); // 지정가 주문 상태 코드[95.체결실패(기타)] set
                            throw new CommCustomException("Ewallet 잔금 조회 실패 (사유 : " + resObj.get("resultMsg") + ")");
                        }
                    }
                }

                log.warn(">> 1. 잔액조회 체크 > ewalletMoney : {}, paymentMn : {}, chkAmount : {}, ewalletBlceInqireSuccesSttus : {}, limitSection : {}",
                        ewalletMoney, orderModel.getPaymentMn(), chkAmount, ewalletBlceInqireSuccesSttus, orderModel.getLimitSection());

                // 지정가 주문 touch 시점일 때, [하나은행] 잔액 조회 실패하면 [케이지트레이딩] 이월렛 잔액을 조회한다.
                if (StringUtils.equals("touch", orderModel.getLimitSection()) && !ewalletBlceInqireSuccesSttus) {
                    // 내부 관리용 이월렛 잔액 가져오기
                    ewalletMoney = orderMapper.getEwalletBlceInnerManagePrpos(orderModel.getEntrpsNo());
                }

                log.warn(">> 2. 잔액조회 체크 > ewalletMoney : {}, paymentMn : {}, chkAmount : {}, ewalletBlceInqireSuccesSttus : {}, limitSection : {}",
                        ewalletMoney, orderModel.getPaymentMn(), chkAmount, ewalletBlceInqireSuccesSttus, orderModel.getLimitSection());

                // 지정가 주문으로 발생한 예수금 조회
                long totalAdvrcvAmount = 0;

                // 지정가 주문 touch 시점이 아닐때만 예수금을 포함하여 체크한다.
                if (!StringUtils.equals("touch", orderModel.getLimitSection())) {
                    totalAdvrcvAmount = orderMapper.getTotalAdvrcvAmount(orderModel);
                    log.warn(">> 조회된 예수금의 총합 > totalAdvrcvAmount : {}", totalAdvrcvAmount);
                }

                // 이월렛 금액 부족 체크
                // 이월렛 잔액 - 동일한 결제 수단으로 주문된 미체결 지정가 주문의 예수금 총합 < 잔액 체크할 금액
                if (ewalletMoney - totalAdvrcvAmount < chkAmount) {
                    log.info("OrderServiceImpl setPriceInfoByExpectDlvrf line-1550 vo.toString() >> " + orderModel.toString());
                    orderModel.setLimitOrderSttusCode("92"); // 지정가 주문 상태 코드[92(체결실패(잔액 부족))] set

                    if (totalAdvrcvAmount == 0) {
                        throw new CommCustomException("Ewallet 금액 부족");
                    } else {
                        throw new CommCustomException(""
                                + "현재 지정가 주문에 따른 결제 대기 금액("
                                + StringUtil.formatMoney(String.valueOf(totalAdvrcvAmount))
                                + "원)이 존재합니다. \r\n"
                                + "주문하기를 희망하시면, 접수된 지정가 주문 건을 취소 후 진행하여 주세요");
                    }
                }
            }

        } else if (StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty")) {
            // 주문 모달창에 선택된 결제 수단 값이 (전자상거래보증 or 케이지크레딧)일 경우에 남은 한도를 체크한다.

            // 지정가 주문으로 발생한 예수금 조회
            long totalAdvrcvAmount = 0;

            // 지정가 주문 touch 시점이 아닐때만 예수금을 포함하여 체크한다.
            if (!StringUtils.equals("touch", orderModel.getLimitSection())) {
                totalAdvrcvAmount = orderMapper.getTotalAdvrcvAmount(orderModel);
                log.warn(">> 조회된 예수금의 총합 > totalAdvrcvAmount : {}", totalAdvrcvAmount);
            }

            //지정가 주문 & 쿠폰 사용 여부 Y 인 경우 or 계약구매-지정가 주문인 경우 or 소량구매인 경우
            //예수금 = 쿠폰할인금액, 등급할인금액, 자투리할인 제외된 금액으로 저장
            if(("03").equals(orderModel.getSleMthdCode())) {
            	if(("Y").equals(orderModel.getCouponApplcAt())
        		 || orderModel.getGradApplcAmount() != 0
        		 || StringUtils.equals("0304", orderModel.getSleMthdDetailCode())
        		 || StringUtils.equals("Y", orderModel.getSmlqyPurchsAt())) {
            		slepc = orderModel.getReSlepc();
            	}
            }
            orderModel.setAdvrcvAmount(slepc);

            Long mrtggBlce = 0L; // 담보 잔액
            OrderEtcPrice mrtggGrntyLmtInqire = this.getMrtggGrntyLmtInqire(orderModel);
            log.warn(">> (전자상거래보증 or 케이지크레딧) 담보 잔액 체크 : " + mrtggGrntyLmtInqire.getMrtggGrntyLmtStatus());

            if (StringUtils.equals(mrtggGrntyLmtInqire.getMrtggGrntyLmtStatus(), "00")) {
                // (전자상거래보증 or 케이지크레딧) 한도 설정이 정상일 경우 값 담기 (담보 잔액)
                mrtggBlce = Long.parseLong(mrtggGrntyLmtInqire.getMrtggBlce()); // 담보 잔액
            } else {
                log.info("OrderServiceImpl setPriceInfoByExpectDlvrf orderModel >> " + String.valueOf(orderModel));
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new CommCustomException("[담보 잔액 조회] " + orderModel.getEntrpsSetleMnInfo().getViewCdtlnSvcSeNm() + " 한도 설정 오류[" + mrtggGrntyLmtInqire.getMrtggGrntyLmtStatus() + "],\n관리자에게 문의 바랍니다.");
            }

            log.warn(">> 담보잔액조회 체크 > mrtggBlce : " + mrtggBlce + ", slepc : " + slepc);

            // (전자상거래보증 or 케이지크레딧) 남은 한도 부족 체크
            // (전자상거래보증 or 케이지크레딧) 남은 한도 - 주문된 미체결 지정가 주문의 예수금 총합 < 잔액 체크할 금액
            if (mrtggBlce - totalAdvrcvAmount < slepc) {
                log.info("OrderServiceImpl setPriceInfoByExpectDlvrf line-1559 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("92"); // 지정가 주문 상태 코드[92(체결실패(잔액 부족))] set
                if(totalAdvrcvAmount == 0) {
                    throw new CommCustomException(orderModel.getEntrpsSetleMnInfo().getViewCdtlnSvcSeNm() + " 남은 한도 부족");
                } else {
                    throw new CommCustomException(""
                            + "현재 지정가 주문에 따른 결제 대기 금액("
                            + StringUtil.formatMoney(String.valueOf(totalAdvrcvAmount))
                            + "원)이 존재합니다. \r\n"
                            + "주문하기를 희망하시면, 접수된 지정가 주문 건을 취소 후 진행하여 주세요");
                }
            }
        }
    }

    /**
     * 주문에 필요한 데이터를 DB에 INSERT 한다.
     */
    @Override
    public void orderInstTblBase(OrderModel orderModel) throws CommCustomException, Exception {
        // 주문 번호 채번
        orderModel.setOrderNo(DateUtil.getNowDate()+ "-S" + assignService.selectAssignValue("OR", "ORDER_NO", DateUtil.calDate("yyyy"), orderModel.getMberNo(), 5));

        // 주문_주문 기본 정보 등록하기
        orderMapper.insertOrOrderBas(orderModel);

        // BL별 주문_주문 상세 정보 등록하기
        for(ItemPriceMatchingBlInfoVO bl : orderModel.getBlList()) {
            orderModel.setBlDetail(bl);
            orderModel.setCstmrOrderWt(bl.getMatchedOrderedBnt().intValue());
            orderModel.setRealOrderWt(bl.getMatchedOrderedBnt().intValue());
            // 주문_주문 상세 정보 등록하기
            orderMapper.insertOrOrderDtl(orderModel);

            // 주문에 사용한 PO 테이블의 정보를 주문 PO 테이블에 담는다.
            try {
                // 주문_PO 정보 기본 등록하기
                orderMapper.insertOrPurchsInfoBas(orderModel);
            } catch (Exception e) {
                log.error(">> OR_PURCHS_INFO_BAS(주문_PO 정보 기본) 테이블 등록 실패 orderNo : " + orderModel.getOrderNo() + ", " + orderModel.getBlDetail().getBlNo());
            }
        }
        // 주문_배송지 기본 정보 등록하기
        orderMapper.insertOrDlvrgBas(orderModel);

        /** 01 : 케이지 배송일때만 Insert **/
        if(StringUtils.equals(orderModel.getDlvyMnCode(), "01")) {
            // 주문_배송비 기본 정보 등록하기
            orderMapper.insertOrDlvrfBas(orderModel);
        }

        // 회원_업체 (전자상거래보증 or 케이지크레딧) 한도 상세 테이블 등록 및 (전자상거래보증 or 케이지크레딧) 기본 테이블 등록
        if(StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty")) {
            // 담보 번호 채번
            String mrtggNo = DateUtil.getNowDateTime("yyyyMMdd")+ "-" + assignService.selectAssignValue("OR", "MRTGG_NO", DateUtil.getNowDate(), orderModel.getMberNo(), 5);
            orderModel.setMrtggNo(mrtggNo); // 담보 번호

            // 주문_(전자상거래보증 or 케이지크레딧) 기본 정보 등록
            orderMapper.insertOrMrtggBas(orderModel);
        }
    }

    /**
     * 삼성선물에 공통코드(CO_CMMN_CD-CODE_NUMBER_REFRNONE)의 삼성선물 주문 단위 중량 단위로 주문 호출한다.
     */
    @Override
    public void callSamsung(OrderModel orderModel) throws CommCustomException, Exception {
    	/** 삼성선물 신규 생성 Key 리스트 **/
        List<String> ftrnNoList = new ArrayList<String>();
        
        /** 삼성선물 계좌 번호 **/
//      String requstAcnutNo = CryptoUtil.encryptAES256(orProperty.getSamsungAcnutNo());
//      orderModel.setRequstAcnutNo(requstAcnutNo);

//      int ftrsTick = orderModel.getCommFtrsFshgMngVO().getFtrsTick(); // 선물 live 틱
        int ftrsTick = 0;
        // 지정가일 경우
        if(StringUtils.equals("03", orderModel.getSleMthdCode())) {
            ftrsTick = orderModel.getCommFtrsFshgMngVO().getFtrsLimitTick(); // 선물 지정가 틱
        } else if(StringUtils.equals("05", orderModel.getSleMthdCode())) {
        	// 가단가일 경우
        	String dcsnSelMthd = orderModel.getDcsnSelMthd(); // 가단가 확정 - 판매 방식 [live: 라이브, limit: 지정가]
        	// 가단가 확정 - 판매 방식이 라이브이거나 판매 방식이 지정가이고 터치된 후일 경우
        	if(StringUtils.equals("live", dcsnSelMthd) || (StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", dcsnSelMthd))) {
        		switch(dcsnSelMthd) {
		        	case "live" : 
		        		// 라이브일 경우
		        		ftrsTick = orderModel.getCommFtrsFshgMngVO().getFtrsTick();      // 선물 live 틱
		        		break;
		        	case "limit" : 
		        		// 지정가일 경우
		        		ftrsTick = orderModel.getCommFtrsFshgMngVO().getFtrsLimitTick(); // 선물 지정가 틱
		        		break;
	        	}
        	}
        } else {
            ftrsTick = orderModel.getCommFtrsFshgMngVO().getFtrsTick();      // 선물 live 틱
        }

        double quoteUnitFtrsTick = (orderModel.getCommFtrsFshgMngVO().getQuoteUnit() * ftrsTick); // 삼성선물 호가단위 * (선물 live 틱 or 선물 지정가 틱)

        // 삼성선물 마스터 테이블 생성
        // 선택된 BL별로 해당 BL의 삼성선물 주문 단위 중량(ex. 메탈코드 7 알루미늄 25톤) 단위씩 삼성선물 호출 로직
        for(ItemPriceMatchingBlInfoVO bl : orderModel.getBlList()) {

        	int orderQy = 0;
        	// [소량구매]일 경우
        	if(StringUtils.equals(orderModel.getSmlqyPurchsAt(), "Y")) {
        		// 선물 잔량 존재 & 소량 판매 선물 여부-Y : 두 조건 모두 만족하는 경우만 선물체결 진행
        		if(bl.getRemainQy() > 0 && StringUtils.equals(bl.getSmlqySleFtrsAt(), "Y")) {
        			// 선물 잔량 있는 경우, 선물 1건으로 호출
        			orderQy = 1;
        		} else {
        			// 선물 잔량 없는 경우, 선물 skip 설정 (선물 호출 pass)
        			orderModel.getCommFtrsFshgMngVO().setSkipAt("Y");
        		}
        	} else {
            	// 삼성선물은 삼성선물 주문 단위 중량(ex. 메탈코드 7 알루미늄 25톤) 단위로 주문 하기때문에 삼성선물 주문 단위 중량으로 나눠서 1건씩 호출
        		orderQy = bl.getMatchedOrderedBnt().intValue() / orderModel.getSamsungOrderWt();
        	}
        	orderModel.setOrderQy(orderQy);
            orderModel.setBlDetail(bl);

            /**
            1. PO테이블 조회, 20220412 PO 테이블에 선물 삼성 계약 번호가 없을 때 로직 추가를 위한 PO정보 활용

            IT_PURCHS_INFO_BAS(상품_PO 정보 기본) - FTRS_THSEX_CNTRCT_NO(선물 삼성 계약 번호)가 없으면
              IT_PURCHS_INFO_BAS(상품_PO 정보 기본) - FTRS_EXPRTN_DE(선물 만기 일자)를
              OR_ORDER_FTRS_BAS(주문_주문 선물 기본) - REQUST_LQD_POSTN_NO(요청 청산 포지션 번호)에 넣고
              OR_ORDER_FTRS_BAS(주문_주문 선물 기본) - REQUST_LQD_ORDER_AT(요청 청산 주문 여부)는 'N' 값을 넣는다.

            IT_PURCHS_INFO_BAS(상품_PO 정보 기본) - FTRS_THSEX_CNTRCT_NO(선물 삼성 계약 번호)가 있으면
              IT_PURCHS_INFO_BAS(상품_PO 정보 기본) -  FTRS_THSEX_CNTRCT_NO(선물 삼성 계약 번호)를
              OR_ORDER_FTRS_BAS(주문_주문 선물 기본) - REQUST_LQD_POSTN_NO(요청 청산 포지션 번호)에 넣고
              OR_ORDER_FTRS_BAS(주문_주문 선물 기본) - REQUST_LQD_ORDER_AT(요청 청산 주문 여부)는 'C' 값을 넣는다.

            2. 20220621 PO 테이블에 선물환 관리 번호가 없을 때 로직 추가를 위한 PO정보 활용

            IT_PURCHS_INFO_BAS(상품_PO 정보 기본) - FSHG_MANAGE_NO(선물환 관리 번호)가 없으면
              NULL 값을
              OR_ORDER_FSHG_BAS(주문_주문 선물환 기본) - REQUST_LQD_NO(요청 청산 번호)에 넣고
              OR_ORDER_FSHG_BAS(주문_주문 선물환 기본) - REQUST_MSSAGE_SE(요청 메시지 구분)은 'NO' 신규 값을 넣는다.
            IT_PURCHS_INFO_BAS(상품_PO 정보 기본) - FSHG_MANAGE_NO(선물환 관리 번호)가 있으면
              IT_PURCHS_INFO_BAS(상품_PO 정보 기본) - FSHG_MANAGE_NO(선물환 관리 번호)를
              OR_ORDER_FSHG_BAS(주문_주문 선물환 기본) - REQUST_LQD_NO(요청 청산 번호)에 넣고
              OR_ORDER_FSHG_BAS(주문_주문 선물환 기본) - REQUST_MSSAGE_SE(요청 메시지 구분)은 'TO' 청산 값을 넣는다.
             **/
            // 상품_PO 정보 가져오기
            orderModel.setItPurchsInfoBas(Optional.ofNullable(orderMapper.selectItPurchsInfoBas(orderModel)).orElseThrow(() -> {
                log.info("OrderServiceImpl callSamsung line-1679 vo.toString() >> " + orderModel.toString());
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                return new CommCustomException("[callSamsung] PO 테이블 미존재");}));

            String ftrsCmpnyTrgetCode = orderModel.getItPurchsInfoBas().getFtrsCmpnyTrgetCode();
            if(StringUtil.isEmpty(ftrsCmpnyTrgetCode)) {
              throw new CommCustomException("[callSamsung] 선물사 대상 코드 미존재");
            }

            // 선물사 다중화로 선물사 대성코드에 따라 계좌가 변경됨.
            if(StringUtils.equals(CommFtrsConstant.FTRS_SAMSUNG_CMPNY_CODE, ftrsCmpnyTrgetCode)){
                orderModel.setRequstAcnutNo(CryptoUtil.encryptAES256(orProperty.getSamsungAcnutNo()));      //삼성증권
            }else if(StringUtils.equals(CommFtrsConstant.FTRS_EBEST_CMPNY_CODE, ftrsCmpnyTrgetCode)){
                orderModel.setRequstAcnutNo(CryptoUtil.encryptAES256(orProperty.getEbestAcnutNo()));        //이베스트증권
            }else {
                throw new CommCustomException("[callSamsung] 선물사 대상 코드 오류 [" + ftrsCmpnyTrgetCode + "]");
            }


            for(int i = 0 ;  i < orderQy ; i++) {
                // 채번
                String ftrsRequstOrderNo = DateUtil.getNowDateTime("yyyyMMdd")+ "-" + "1" + assignService.selectAssignValue("OR", "FTRS_REQUST_ORDER_NO", DateUtil.getNowDate(), orderModel.getMberNo(), 10);
                // 선물 주문 가격 3M 가격에서 10틱을 올려서 구매하는게 현재 정책 -> 유동적으로 변경될 수 있는 사항이라 PROPERTY 관리 -> DB에서 관리하는 것으로 변경(개발시점 20220609)
                String requstOrderUntpc = "";
                // LME MARKUP 활성화 시
                if(StringUtils.equals(orderModel.getLmeMarkUpAt(), "Y") && StringUtils.equals(orderModel.getMetalCode(),"7")) {
                	requstOrderUntpc = String.valueOf(orderModel.getPrSelVO().getThreemonthLmePc().subtract(orderModel.getGainValue()));
                } else {
                	requstOrderUntpc = String.valueOf(orderModel.getPrSelVO().getThreemonthLmePc().add(BigDecimal.valueOf( quoteUnitFtrsTick )));
                }
                orderModel.setFtrsRequstOrderNo(ftrsRequstOrderNo);
                // 아래의 1은 삼성선물 주문 단위 중량(ex. 메탈코드 7 알루미늄 25톤)을 의미, 삼성선물 주문 단위 중량 단위로 호출하는 방식으로 정책 변경
                orderModel.setRequstOrderQy(1);
                orderModel.setRequstOrderUntpc(requstOrderUntpc);
                // 주문_주문 선물 기본 정보 등록하기, skip사용여부(commFtrsFshgMngVO.skiptAt)가 'Y'값 이면 응답선물상태코드를 90으로 준다. 그 외에는 NULL 값
                orderMapper.insertOrOrderFtrsBas(orderModel);
                // 호출한 KEY값 저장 -> 추후 실패했는지 성공했는지 파악하기 위해
                
                //마크업 주문 정보 저장 테이블 insert
                if(StringUtils.equals(orderModel.getLmeMarkUpAt(), "Y") && StringUtils.equals(orderModel.getMetalCode(),"7")) {
                	 // history
                	Map<String, String> keyValues = new HashMap<String, String>();
                	int keyVal = orderMapper.insertMarkUpOrderNo(orderModel);
                	keyValues.put("MARK_UP_SN", String.valueOf(orderModel.getMarkUpSn()));
                	commonService.insertTableHistory("OR_ORDER_LME_MARK_UP", keyValues);
                }
                
                ftrnNoList.add(ftrsRequstOrderNo);
            }
        }
        orderModel.setFtrnNoList(ftrnNoList);

        if(StringUtils.equals(Optional.ofNullable(orderModel.getCommFtrsFshgMngVO().getSkipAt()).orElse("N"), "Y")) {
            // skip 사용 여부인 경우, 삼성 선물 주문 요청을 하지 않는다.
            log.warn(">> callSamsung > 삼성선물 주문 요청 call : skip사용, 삼성 선물 주문 요청하지 않음");

            // 가단가일 경우
            if(StringUtils.equals("05", orderModel.getSleMthdCode())) {
            	// 가단가 확정 - 판매 방식 [live: 라이브, limit: 지정가]이 지정가이고 터치된 후일 경우
            	if(StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", orderModel.getDcsnSelMthd())) {
            		// 가단가-지정가 터치된 주문 체결 처리
            		orderModel.setLimitOrderSttusCode("30"); // 지정가 체결(30)
            		this.procLimitOrderCnclsByPrvsnl(orderModel);
            	}
            } else {
            	//  skip 사용일 경우 정상으로 주문 성공
                orderModel.setOrderSttusCode("10"); // 주문완료
                orderMapper.updateLastOrderMaster(orderModel); // 주문_주문 기본의 주문상태코드 및 주문완료일시, OMS접수 번호, 주문 실패 사유 등을 값에 따라 업데이트
                orderMapper.updateCnCntrctOrderBas(orderModel); // 평균가 주문의 경우, 계약_발주 기본의 주문번호 업데이트

                // 지정가 주문 체결(부분체결) 처리
                this.procLimitOrderCncls(orderModel);
            }

            try {
                // 마일리지 처리 (적립예정, 달성률 처리)
                // 1. 전자상거래보증 주문에 따른 적립예정 처리
                // 2. 전자상거래보증 주문에 따른 달성률 처리
                // 3. 달성률 100% 달성 시 적립예정 등록 안함
                // 4. 달성률 100% 달성 시 적립예정을 적립으로 변경
                this.procOrderMlg(orderModel);
            } catch(Exception e) {
                String stacktrace = ExceptionUtils.getStackTrace(e);
                log.error("[Exception][stacktrace] callSamsung skip Y : " + stacktrace);
                log.error("마일리지 처리 실패");
            }
        } else {
            // skip 사용 여부가 아닌 경우, 삼성 선물 주문 요청 및 취소 로직 수행

        	//호출 전 FS서버 확인
        	//FS서버 상태 확인 ( Link 상태 )
            boolean isFsLinkStatus = Optional.ofNullable(orderMapper.getFsLinkStatus()).orElse(false);
            if( !isFsLinkStatus ) {
            	throw new CommCustomException("[callSamsung] FS서버 장애 ( LINK 상태 불량 ) ");
            }
        	
            // 삼성선물 호출
            // 삼성선물 성공 여부 플래그
            boolean isSuccess = false;
            Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getSamsungOrderUrl(), Collections.singletonMap("orderNo", orderModel.getOrderNo()));
            log.warn(">> callSamsung > 삼성선물 주문 요청 call : " + String.valueOf(resObj));

            // 삼성선물 장애가 있을 때 사용, 선물 자동 승인 여부 가져오기, 삼성선물에 API는 호출하고 주문 성공으로 처리 여부 값, 20230202 추가
            String futureAutoYn = Optional.ofNullable(orderMapper.getFutureAutoYn()).orElse("");
            log.warn(">> callSamsung > futureAutoYn : " + futureAutoYn);

            // MARKUP 사용할 시, 삼성선물 API 주문 신청 후, 주문 진행.
            if(StringUtils.equals("Y", orderModel.getLmeMarkUpAt())) {
                isSuccess = true;
                // 삼성선물 성공
                
                // 가단가일 경우
                if(StringUtils.equals("05", orderModel.getSleMthdCode())) {
                	// 가단가 확정 - 판매 방식 [live: 라이브, limit: 지정가]이 지정가이고 터치된 후일 경우
                	if(StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", orderModel.getDcsnSelMthd())) {
                		// 가단가-지정가 터치된 주문 체결 처리
                		orderModel.setLimitOrderSttusCode("30"); // 지정가 체결(30)
                		this.procLimitOrderCnclsByPrvsnl(orderModel);
                	}
                } else {
	                // 삼성선물이 성공이면 주문은 성공
	                orderModel.setOrderSttusCode("10"); // 주문완료
	                orderMapper.updateLastOrderMaster(orderModel); // 주문_주문 기본의 주문상태코드 및 주문완료일시, OMS접수 번호, 주문 실패 사유 등을 값에 따라 업데이트
	                orderMapper.updateCnCntrctOrderBas(orderModel); // 평균가 주문의 경우, 계약_발주 기본의 주문번호 업데이트
	
	                // 지정가 주문 체결(부분체결) 처리
	                this.procLimitOrderCncls(orderModel);
                }
                
                try {
                    // 마일리지 처리 (적립예정, 달성률 처리)
                    // 1. 전자상거래보증 주문에 따른 적립예정 처리
                    // 2. 전자상거래보증 주문에 따른 달성률 처리
                    // 3. 달성률 100% 달성 시 적립예정 등록 안함
                    // 4. 달성률 100% 달성 시 적립예정을 적립으로 변경
                    this.procOrderMlg(orderModel);
                } catch(Exception e) {
                    String stacktrace = ExceptionUtils.getStackTrace(e);
                    log.error("[Exception][stacktrace] callSamsung skip N : " + stacktrace);
                    log.error("마일리지 처리 실패");
                }
            // 삼성선물 장애가 있을 때 사용, 삼성선물에 API는 호출하고 주문 성공으로 처리, 20230202 추가
            } else if(StringUtils.equals("Y", futureAutoYn)) {
                isSuccess = true;

                // 삼성선물 성공
                
                // 가단가일 경우
                if(StringUtils.equals("05", orderModel.getSleMthdCode())) {
                	// 가단가 확정 - 판매 방식 [live: 라이브, limit: 지정가]이 지정가이고 터치된 후일 경우
                	if(StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", orderModel.getDcsnSelMthd())) {
                		// 가단가-지정가 터치된 주문 체결 처리
                		orderModel.setLimitOrderSttusCode("30"); // 지정가 체결(30)
                		this.procLimitOrderCnclsByPrvsnl(orderModel);
                	}
                } else {
	                // 삼성선물이 성공이면 주문은 성공
	                orderModel.setOrderSttusCode("10"); // 주문완료
	                orderMapper.updateLastOrderMaster(orderModel); // 주문_주문 기본의 주문상태코드 및 주문완료일시, OMS접수 번호, 주문 실패 사유 등을 값에 따라 업데이트
	                orderMapper.updateCnCntrctOrderBas(orderModel); // 평균가 주문의 경우, 계약_발주 기본의 주문번호 업데이트
	
	                // 지정가 주문 체결(부분체결) 처리
	                this.procLimitOrderCncls(orderModel);
                }

                try {
                    // 마일리지 처리 (적립예정, 달성률 처리)
                    // 1. 전자상거래보증 주문에 따른 적립예정 처리
                    // 2. 전자상거래보증 주문에 따른 달성률 처리
                    // 3. 달성률 100% 달성 시 적립예정 등록 안함
                    // 4. 달성률 100% 달성 시 적립예정을 적립으로 변경
                    this.procOrderMlg(orderModel);
                } catch(Exception e) {
                    String stacktrace = ExceptionUtils.getStackTrace(e);
                    log.error("[Exception][stacktrace] callSamsung skip N : " + stacktrace);
                    log.error("마일리지 처리 실패");
                }
            } else {
                if( resObj!= null && StringUtils.equals(String.valueOf(resObj.get(PdCommConstant.SAMSUNG_RESULT_KEY)), PdCommConstant.SAMSUNG_SUCCESS_CODE)) {
                    // 삼성선물 실패 건을 담을 List
                    List<CommOrOrderFtrsBasVO> selectFtrsOrderResFailList = new ArrayList<CommOrOrderFtrsBasVO>();

                    // 0.5초씩 쉬면서 설정 시간 초만큼 주문 요청 성공여부 체크
                    for(int i = 0 ; i < orProperty.getSamsungTimeoutsec() * 2  ; i ++) {
                        Thread.sleep(500);
                        // 선물 주문 응답 실패 리스트 가져오기, 응답 선물 상태 코드가 체결(30)이 아닌 것 또는 NULL인 것을 조회하여 실패 건 갯수를 파악 -> 아까 위에서 담은 FtrnNoList를이용
                        selectFtrsOrderResFailList = orderMapper.selectFtrsOrderResFailList(orderModel);
                        if(selectFtrsOrderResFailList.size() == 0){
                            isSuccess = true;
                            break;
                        };
                    }

                    log.warn(">> callSamsung > 삼성선물 응답성공 코드 '30'이 아닌것을 조회하여 실패 건 개수 samsungFailList.size()/ftrnNoList.size() : " + selectFtrsOrderResFailList.size() + "/" + ftrnNoList.size());

                    if(!isSuccess) {
                        // 삼성선물 실패 로직 구현
                        if(selectFtrsOrderResFailList.size() > 0) {
                            orderModel.setSamsungFailList(selectFtrsOrderResFailList);
                            cancelCallSamsung(orderModel);
                        }
                    }
                    // 삼성선물 성공
                    
                    // 가단가일 경우
                    if(StringUtils.equals("05", orderModel.getSleMthdCode())) {
                    	// 가단가 확정 - 판매 방식 [live: 라이브, limit: 지정가]이 지정가이고 터치된 후일 경우
                    	if(StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", orderModel.getDcsnSelMthd())) {
                    		// 가단가-지정가 터치된 주문 체결 처리
                    		orderModel.setLimitOrderSttusCode("30"); // 지정가 체결(30)
                    		this.procLimitOrderCnclsByPrvsnl(orderModel);
                    	}
                    } else {
	                    // 삼성선물이 성공이면 주문은 성공
	                    orderModel.setOrderSttusCode("10"); // 주문완료
	                    orderMapper.updateLastOrderMaster(orderModel); // 주문_주문 기본의 주문상태코드 및 주문완료일시, OMS접수 번호, 주문 실패 사유 등을 값에 따라 업데이트
	                    orderMapper.updateCnCntrctOrderBas(orderModel); // 평균가 주문의 경우, 계약_발주 기본의 주문번호 업데이트
	
	                    // 지정가 주문 체결(부분체결) 처리
	                    this.procLimitOrderCncls(orderModel);
                    }

                    try {
                        // 마일리지 처리 (적립예정, 달성률 처리)
                        // 1. 전자상거래보증 주문에 따른 적립예정 처리
                        // 2. 전자상거래보증 주문에 따른 달성률 처리
                        // 3. 달성률 100% 달성 시 적립예정 등록 안함
                        // 4. 달성률 100% 달성 시 적립예정을 적립으로 변경
                        this.procOrderMlg(orderModel);
                    } catch(Exception e) {
                        String stacktrace = ExceptionUtils.getStackTrace(e);
                        log.error("[Exception][stacktrace] callSamsung skip N : " + stacktrace);
                        log.error("마일리지 처리 실패");
                    }
                } else {
                    // 템플릿에 따라 SMS 전송을 처리한다.
                    procSms(orderModel, "77", "삼성선물 주문 호출 실패");
                    // 삼성선물 주문 호출 실패
                    log.info("OrderServiceImpl callSamsung line-1798 vo.toString() >> " + orderModel.toString());
                    orderModel.setLimitOrderSttusCode("90"); // 지정가 주문 상태 코드[90(체결실패(선물 실패))] set
                    throw new CommCustomException("선물사 주문 호출 실패");
                }
            }
        }
    }

    /**
     *  평균가 주문일 경우, 선물 데이터를 생성한다. (삼성선물은 호출하지 않는다.)
     */
    private synchronized void callAvrgpcSamsung(OrderModel orderModel) {
        log.warn("[OrderServiceImpl][callAvrgpcSamsung] IN");
        Runnable avrgpcFtrsRun = () -> {
            try {
                // 삼성선물 마스터 테이블 생성
                // 선택된 BL별로 해당 BL의 삼성선물 주문 단위 중량(ex. 메탈코드 7 알루미늄 25톤) 단위씩 삼성선물 호출 로직
                for(ItemPriceMatchingBlInfoVO bl : orderModel.getBlList()) {
                    // 삼성선물은 삼성선물 주문 단위 중량(ex. 메탈코드 7 알루미늄 25톤) 단위로 주문 하기때문에 삼성선물 주문 단위 중량으로 나눠서 1건씩 호출
                    int orderQy = bl.getMatchedOrderedBnt().intValue() / orderModel.getSamsungOrderWt();

                    orderModel.setBlDetail(bl);
                    log.info("[callAvrgpcSamsung] orderQy : " + orderQy + ", bl : " + bl);

                    int lotQy = 0; // LOT수량 초기화
                    CnAvrgpcFtrsBasVO avrgpcFtrsInfo = new CnAvrgpcFtrsBasVO(); // 계약_평균가 선물 기본 초기화

                    for(int i = 0 ;  i < orderQy ; i++) {

                        // 계약_평균가 선물 기본 정보 가져오기
                        if(lotQy <= 0) {

                            avrgpcFtrsInfo = Optional.ofNullable(orderMapper.selectCnAvrgpcFtrsBas(orderModel))
                                                     .orElseThrow(() -> {return new CommCustomException("평균가 선물 기본 데이터 미존재");});

                            lotQy = avrgpcFtrsInfo.getLotQy(); // 등록 가능한 LOT수량
                            log.info("[callAvrgpcSamsung] 최초 평균가 선물 기본 테이블 조회 성공 - lotQy: " + lotQy);
                        } else {
                            log.info("[callAvrgpcSamsung] 기존 평균가 선물데이터 재사용(LOT 잔여수량 존재).");
                        }
                        log.info("[callAvrgpcSamsung] selectCnAvrgpcFtrsBas avrgpcFtrsInfo >> " + avrgpcFtrsInfo.toString());

                        // 선물사 대상 코드
                        String ftrsCmpnyTrgetCode = avrgpcFtrsInfo.getFtrsCmpnyTrgetCode();
                        if(StringUtil.isEmpty(ftrsCmpnyTrgetCode)) {
                            throw new CommCustomException("선물사 대상 코드 미존재");
                        }

                        // 공통코드_요청선물종목코드 조회
                        CommonCodeVO itemCodeInfo = Optional.ofNullable(commonCodeService.getCodeValueRetVo("REQUST_FTRS_ITEM_CODE", orderModel.getSamsungStockCode()))
                                                            .orElseThrow(() -> {return new CommCustomException("선물사 요청 선물 종목 코드 오류 [" + orderModel.getSamsungStockCode() + "]");});

                        // 선물사 다중화로 선물사 대성코드에 따라 계좌, 종목 코드가 변경됨.
                        if(StringUtils.equals(CommFtrsConstant.FTRS_SAMSUNG_CMPNY_CODE, ftrsCmpnyTrgetCode)){
                            //삼성증권
                            orderModel.setRequstAcnutNo(CryptoUtil.encryptAES256(orProperty.getSamsungAcnutNo()));
                            avrgpcFtrsInfo.setItemCode(itemCodeInfo.getCodeChrctrRefrnone());
                        }else if(StringUtils.equals(CommFtrsConstant.FTRS_EBEST_CMPNY_CODE, ftrsCmpnyTrgetCode)){
                            //이베스트증권
                            orderModel.setRequstAcnutNo(CryptoUtil.encryptAES256(orProperty.getEbestAcnutNo()));
                            avrgpcFtrsInfo.setItemCode(itemCodeInfo.getCodeChrctrRefrntwo());
                        }else {
                            throw new CommCustomException("선물사 대상 코드 오류 [" + ftrsCmpnyTrgetCode + "]");
                        }

                        orderModel.setCnAvrgpcFtrsBas(avrgpcFtrsInfo);

                        // 채번: 선물 요청 주문번호
                        String ftrsRequstOrderNo = DateUtil.getNowDateTime("yyyyMMdd")+ "-" + "1" + assignService.selectAssignValue("OR", "FTRS_REQUST_ORDER_NO", DateUtil.getNowDate(), orderModel.getMberNo(), 10);
                        orderModel.setFtrsRequstOrderNo(ftrsRequstOrderNo);
                        // 채번: 응답 선물 주문번호
                        String rspnsFtrsOrderNo = avrgpcFtrsInfo.getCntrctYm() + "FS" + assignService.selectAssignValue("OR", "CN_RSPNS_FTRS_NO", DateUtil.getNowDate(), orderModel.getMberNo(), 7);
                        orderModel.setRspnsFtrsOrderNo(rspnsFtrsOrderNo);
                        // 아래의 1은 삼성선물 주문 단위 중량(ex. 메탈코드 7 알루미늄 25톤)을 의미, 삼성선물 주문 단위 중량 단위로 호출하는 방식으로 정책 변경
                        orderModel.setRequstOrderQy(1);

                        // 1. 주문_주문 선물 기본 정보 등록하기, 응답선물상태코드는 30(체결 완료)으로 처리.
                        orderMapper.insertOrOrderFtrsBas(orderModel);

                        // 2. 계약_평균가 선물 처리 상세 등록 (사용한 LOT 데이터에 대한 이력 등록)
                        orderMapper.insertCnAvrgpcFtrsProcessDtl(orderModel);

                        for(int j = 0; j < 2 ; j++) {

                            // 실행아이디- 공통규칙으로 채번 (사실상 더미 데이터임)
                            String executId = avrgpcFtrsInfo.getCntrctYm() + "FS" + assignService.selectAssignValue("OR", "CN_RSPNS_FTRS_NO", DateUtil.getNowDate(), orderModel.getMberNo(), 7);
                            avrgpcFtrsInfo.setExecutId(executId);
                            avrgpcFtrsInfo.setIndex(j);
                            // 등록할 선물 데이터 세팅
                            orderModel.setCnAvrgpcFtrsBas(avrgpcFtrsInfo);

                            // 3. 주문_주문 선물 상세 등록, 총 2개 - 체결/만기 데이터를 등록한다.
                            orderMapper.insertOrOrderFtrsDtl(orderModel);
                        }

                       lotQy--; // LOT수량 차감
                    } // for orderQy END
                }// for bl END

                // 평균가 주문 성공 여부는 결제 성공 여부로 결정됨
                log.info("[OrderServiceImpl][callAvrgpcSamsung] 평균가 주문 선물 데이터 등록 완료.");

            } catch (Exception e) {
                log.error("[OrderServiceImpl][callAvrgpcSamsung] 평균가 선물 데이터 등록 error: " + ExceptionUtils.getStackTrace(e));
            }
        };
        taskExecutor.execute(avrgpcFtrsRun);
    }

    /**
     * <pre>
     * 처리내용: 마일리지 처리 (적립예정, 달성률 처리)
     *         : 대상(전자상거래보증), 케이지크레딧 제외
     *  01. 전자상거래보증 주문에 따른 적립예정 처리
     *  02. 전자상거래보증 주문에 따른 달성률 처리
     *  03. 달성률 100% 달성 시 적립예정 등록 안함
     *  04. 달성률 100% 달성 시 적립예정을 적립으로 변경
     * </pre>
     * @date 2022. 8. 29.
     * @author srec0049
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 8. 29.         srec0049            최초작성
     * ------------------------------------------------
     * @param orderModel
     * @throws CommCustomException
     * @throws Exception
     */
    private void procOrderMlg(OrderModel orderModel) throws CommCustomException, Exception {
        log.warn("procOrderMlg() start");

        // 주문 모달창에 선택된 결제 수단 값이 (전자상거래보증 or 케이지크레딧) 일 때
        if(StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty")) {
            if(StringUtils.equals(orderModel.getCdtlnSvcSeCode(), "02")) {
                log.warn("procOrderMlg() 케이지크레딧은 마일리지 적립 대상 아님");
            } else {
                BigDecimal tmpMrtgggrntyScritsissuFeeCmpnstnRate = orderModel.getEntrpsSetleMnInfo().getMrtgggrntyScritsissuFeeCmpnstnRate(); // 지원 비율(전자상거래보증 증권발급 수수료 보상 비율)
                log.warn("[procOrderMlg] 지원 비율(tempMrtgggrntyScritsissuFeeCmpnstnRate) 소수점 : " + tmpMrtgggrntyScritsissuFeeCmpnstnRate);
                BigDecimal ptMrtgggrntyScritsissuFeeCmpnstnRate = tmpMrtgggrntyScritsissuFeeCmpnstnRate.multiply(BigDecimal.valueOf(100)); // 지원 비율(퍼센트)
                log.warn("[procOrderMlg] 지원 비율(ptMrtgggrntyScritsissuFeeCmpnstnRate) 퍼센트 : " + ptMrtgggrntyScritsissuFeeCmpnstnRate);

                BigDecimal tmpMrtgggrntyScritsissuFeeCmpnstnCsbyRate = orderModel.getEntrpsSetleMnInfo().getMrtgggrntyScritsissuFeeCmpnstnCsbyRate(); // 건당 인정 비율(전자상거래보증 증권발급 수수료 보상 건당 인정 비율)
                log.warn("[procOrderMlg] 건당 인정 비율(tmpMrtgggrntyScritsissuFeeCmpnstnCsbyRate) 소수점 : " + tmpMrtgggrntyScritsissuFeeCmpnstnCsbyRate);
                BigDecimal ptMrtgggrntyScritsissuFeeCmpnstnCsbyRate = tmpMrtgggrntyScritsissuFeeCmpnstnCsbyRate.multiply(BigDecimal.valueOf(100)); // 건당 인정 비율(퍼센트)
                log.warn("[procOrderMlg] 건당 인정 비율(ptMrtgggrntyScritsissuFeeCmpnstnCsbyRate) 퍼센트 : " + ptMrtgggrntyScritsissuFeeCmpnstnCsbyRate);

                BigDecimal grntyAmount = new BigDecimal(orderModel.getGrntyAmount()); // 한도(보증 금액)
                log.warn("[procOrderMlg] 한도(grntyAmount) : " + grntyAmount);

                BigDecimal tmpMrtggGrntyInsrncTariffDcmlpoint = orderModel.getEntrpsSetleMnInfo().getMrtggGrntyInsrncTariffDcmlpoint(); // 보험료율(담보 보증 보험 요율)
                log.warn("[procOrderMlg] 보험료율(tmpMrtggGrntyInsrncTariffDcmlpoint) 소수점 : " + tmpMrtggGrntyInsrncTariffDcmlpoint);
                BigDecimal ptMrtggGrntyInsrncTariffDcmlpoint = tmpMrtggGrntyInsrncTariffDcmlpoint.multiply(BigDecimal.valueOf(100)); // 보험료율(퍼센트)
                log.warn("[procOrderMlg] 보험료율(ptMrtggGrntyInsrncTariffDcmlpoint) 퍼센트 : " + ptMrtggGrntyInsrncTariffDcmlpoint);

                BigDecimal irncf = grntyAmount.multiply(ptMrtggGrntyInsrncTariffDcmlpoint).divide(BigDecimal.valueOf(100)); // 보험료[한도 * 보험료율(퍼센트) / 100]
                log.warn("[procOrderMlg] 보험료(irncf) : " + irncf);

                BigDecimal ptLcBndRate = ptMrtgggrntyScritsissuFeeCmpnstnRate.multiply(ptMrtggGrntyInsrncTariffDcmlpoint).divide(BigDecimal.valueOf(100)); // 케이지트레이딩 부담비율[지원 비율(퍼센트) * 보험료율(퍼센트) / 100]
                log.warn("[procOrderMlg] 케이지트레이딩 부담비율(ptLcBndRate) 퍼센트 : " + ptLcBndRate);
                BigDecimal roundPtLcBndRate = ptLcBndRate.setScale(2, BigDecimal.ROUND_HALF_UP); // 케이지트레이딩 부담비율(반올림(퍼센트에서 반올림한다))
                log.warn("[procOrderMlg] 케이지트레이딩 부담비율(roundPtLcBndRate) 퍼센트 반올림 : " + roundPtLcBndRate);

                BigDecimal trnov = BigDecimal.ZERO; // 회전율
                if(ptMrtgggrntyScritsissuFeeCmpnstnCsbyRate.compareTo(BigDecimal.ZERO) <= 0) {
                    // 건당인정비율이 0이면
                    trnov = roundPtLcBndRate; // 회전율[케이지트레이딩 부담비율(퍼센트) 반올림]
                } else {
                    // 건당인정비율이 0이 아니면
                    trnov = roundPtLcBndRate.divide(ptMrtgggrntyScritsissuFeeCmpnstnCsbyRate, 4, BigDecimal.ROUND_HALF_UP).multiply(BigDecimal.valueOf(100)); // 회전율[케이지트레이딩 부담비율(퍼센트) 반올림 / 건당 인정 비율(퍼센트) * 100]
                }
                log.warn("[procOrderMlg] 회전율(trnov) 퍼센트 소수점 둘째자리에서 반올림하려면 퍼센트 나누기 계산 후 넷째자리에서 반올림 후 * 100 : " + trnov);


                BigDecimal demandRvamt = BigDecimal.ZERO; // 요구매출액
                if(trnov.compareTo(BigDecimal.ZERO) <= 0) {
                    // 회전율이 0이면
                    demandRvamt = grntyAmount; // 요구매출액[한도]
                } else {
                    // 회전율이 0이 아니면
                    demandRvamt = trnov.multiply(grntyAmount).divide(BigDecimal.valueOf(100)); // 요구매출액[회전율 * 한도 / 100]
                }
                log.warn("[procOrderMlg] 요구매출액(demandRvamt) : " + demandRvamt);

                BigDecimal sorinCtBndAmount = grntyAmount.multiply(roundPtLcBndRate).divide(BigDecimal.valueOf(100)); // 케이지트레이딩 비용 부담액[한도 * 케이지트레이딩 부담비율(퍼센트)]
                log.warn("[procOrderMlg] 케이지트레이딩 비용 부담액(sorinCtBndAmount) : " + sorinCtBndAmount);

                BigDecimal realOccrrncMrtggRvamt = Optional.ofNullable(orderMapper.getRealOccrrncMrtggRvamt(orderModel)).orElse(BigDecimal.ZERO); // 실제발생담보매출액[회원_업체 담보 한도 상세(SUM(담보 거래 금액))]
                log.warn("[procOrderMlg] 실제발생담보매출액[회원_업체 담보 한도 상세(SUM(담보 거래 금액))](realOccrrncMrtggRvamt) : " + realOccrrncMrtggRvamt);

                BigDecimal tmpAchivRate = realOccrrncMrtggRvamt.divide(demandRvamt, 4, BigDecimal.ROUND_HALF_UP).multiply(BigDecimal.valueOf(100)); // 달성율[실제발생담보매출액 / 요구매출액 * 100]
                log.warn("[procOrderMlg] 달성율(tmpAchivRate) 퍼센트 소수점 둘째자리에서 반올림하려면 퍼센트 나누기 계산 후 넷째자리에서 반올림 후 * 100 : " + tmpAchivRate);
                BigDecimal achivRate =  BigDecimal.ZERO;
                // 달성율이 100% 넘을 시 100%로 처리
                if(tmpAchivRate.compareTo(BigDecimal.valueOf(100)) >= 0) {
                    achivRate = BigDecimal.valueOf(100);
                } else {
                    achivRate = tmpAchivRate;
                }
                orderModel.setSelngAchivrt(achivRate); // 매출 달성율에 달성율 set
                log.warn("[procOrderMlg] 달성율(tmpAchivRate) 100% 이상일 시 보정 : " + achivRate);

                BigDecimal presvAmount = sorinCtBndAmount.multiply(achivRate).divide(BigDecimal.valueOf(100)); // 보전금액[케이지트레이딩 비용 부담액 * 달성율]
                log.warn("[procOrderMlg] 보전금액(presvAmount) : " + presvAmount);

                BigDecimal orderSlepc = new BigDecimal(String.valueOf(orderModel.getSlepc())); // 주문금액 - 판매가, 담보 거래 금액
                log.warn("[procOrderMlg] 주문금액(orderSlepc) : " + orderSlepc);
                BigDecimal orderAchivRate = orderSlepc.divide(demandRvamt, 4, BigDecimal.ROUND_HALF_UP).multiply(BigDecimal.valueOf(100)); // 주문 달성율[주문금액 / 요구매출액 * 100]
                log.warn("[procOrderMlg] 주문 달성율(orderAchivRate) : " + orderAchivRate);
                BigDecimal mlgAmount = sorinCtBndAmount.multiply(orderAchivRate).divide(BigDecimal.valueOf(100)); // 주문금액에 대한 마일리지 적립 예정 금액
                log.warn("[procOrderMlg] 주문금액에 대한 마일리지 적립 예정 금액(mlgAmount) : " + mlgAmount);
                BigDecimal roundMlgAmount = mlgAmount.setScale(0, BigDecimal.ROUND_HALF_UP); // 주문금액에 대한 마일리지 적립 예정 금액(반올림)
                log.warn("[procOrderMlg] 주문금액에 대한 마일리지 적립 예정 금액(roundMlgAmount)(반올림) : " + roundMlgAmount);

                BigDecimal nowTotMlgAccmlAmount = Optional.ofNullable(orderMapper.getNowTotMlgAccmlAmount(orderModel)).orElse(BigDecimal.ZERO); // 현재 총 마일리지 적립 예정 금액[현재 총 마일리지 적립 금액 + 총 마일리지 적립 예정 금액] 가져오기
                log.warn("[procOrderMlg] 총 마일리지 적립 예정 금액[현재 총 마일리지 적립 금액 + 총 마일리지 적립 예정 금액] : " + nowTotMlgAccmlAmount);

                // 총 마일리지 적립 대상 금액[총 마일리지 적립 예정 금액 + 주문금액에 대한 마일리지 적립 예정 금액]이 보전금액보다 크면
                // [보전금액 - (총 마일리지 적립 예정 금액)]이 주문금액에 대한 마일리지 적립 예정 금액이 된다.
                BigDecimal totMlgAccmlTrgetAmount = nowTotMlgAccmlAmount.add(roundMlgAmount); // 총 마일리지 적립 대상 금액[총 마일리지 적립 예정 금액 + 주문금액에 대한 마일리지 적립 예정 금액]
                log.warn("[procOrderMlg] 총 마일리지 적립 대상 금액[총 마일리지 적립 예정 금액 + 주문금액에 대한 마일리지 적립 예정 금액](totMlgAccmlTrgetAmount) : " + totMlgAccmlTrgetAmount);
                if(totMlgAccmlTrgetAmount.compareTo(presvAmount) > 0) {
                    // 총 마일리지 적립 대상 금액[총 마일리지 적립 예정 금액 + 주문금액에 대한 마일리지 적립 예정 금액]이 보전금액보다 크면
                    roundMlgAmount = presvAmount.subtract(nowTotMlgAccmlAmount); // [보전금액 - (총 마일리지 적립 예정 금액)]이 주문금액에 대한 마일리지 적립 예정 금액이 된다.
                }
                log.warn("[procOrderMlg] 최종 주문금액에 대한 마일리지 적립 예정 금액(roundMlgAmount) : " + roundMlgAmount);

                // MB_ENTRPS_MRTGG_CNTRCT_BAS(회원_업체 담보 기본)의 SELNG_ACHIVRT(매출 달성율) 가져와서 100% 넘으면 마일리지 처리 하지 않는 조건 추가
                BigDecimal mrtggSelngAchivrt = Optional.ofNullable(orderMapper.selectMrtggSelngAchivrt(orderModel)).orElse(BigDecimal.ZERO); // 회원_업체 담보 기본의 매출 달성율 가져오기
                log.warn("[procOrderMlg] 매출 달성율(mrtggSelngAchivrt) : " + mrtggSelngAchivrt);

                if(mrtggSelngAchivrt.compareTo(BigDecimal.valueOf(100)) >= 0) {
                    // 매출 달성율이 100 이상이면 마일리지 처리를 하지 않는다.
                    log.warn("[procOrderMlg] 매출 달성율(mrtggSelngAchivrt)이 100보다 크거나 100이면 마일리지 처리 안함 : " + mrtggSelngAchivrt);
                } else {
                    if(roundMlgAmount.compareTo(BigDecimal.ZERO) <= 0) {
                        // 마일리지 적립 예정 금액이 0보다 작으면 마일리지 처리 하지 않는다.
                        log.warn("[procOrderMlg] 마일리지 적립 예정 금액이 0보다 작거나 0이면 마일리지 처리 안함 : " + roundMlgAmount);
                    } else {
                        // 마일리지 적립 예정 금액이 0보다 클때 마일리지 처리
                        OrderMbEntrpsMlgInfoDtlVO orderMbEntrpsMlgInfoDtlVO = new OrderMbEntrpsMlgInfoDtlVO();
                        if(achivRate.compareTo(BigDecimal.valueOf(100)) < 0) {
                            // 달성율이 100% 미만일 때 적립 예정으로 등록
                            orderMbEntrpsMlgInfoDtlVO.setMlgSe("02"); // 마일리지 구분 (02: 적립 예정)
                            orderMbEntrpsMlgInfoDtlVO.setMlgTy("08"); // 마일리지 유형 (08: 보증수수료)
                            orderMbEntrpsMlgInfoDtlVO.setMlgDetailDtls("보증수수료 마일리지 적립 예정"); // 마일리지 상세 내역
                            orderMbEntrpsMlgInfoDtlVO.setDelngMlg(roundMlgAmount.intValue()); // 거래 마일리지
                            orderModel.setOrderMbEntrpsMlgInfoDtlVO(orderMbEntrpsMlgInfoDtlVO);

                            // 회원_업체 마일리지 내역 상세 등록 (적립예정)
                            orderMapper.insertMbEntrpsMlgInfoDtl(orderModel);
                        } else {
                            // 달성율이 100% 미만일 때 적립 예정으로 등록
                            orderMbEntrpsMlgInfoDtlVO.setMlgSe("02"); // 마일리지 구분 (02: 적립 예정)
                            orderMbEntrpsMlgInfoDtlVO.setMlgTy("08"); // 마일리지 유형 (08: 보증수수료)
                            orderMbEntrpsMlgInfoDtlVO.setMlgDetailDtls("보증수수료 마일리지 적립 예정"); // 마일리지 상세 내역
                            orderMbEntrpsMlgInfoDtlVO.setDelngMlg(roundMlgAmount.intValue()); // 거래 마일리지
                            orderModel.setOrderMbEntrpsMlgInfoDtlVO(orderMbEntrpsMlgInfoDtlVO);

                            // 회원_업체 마일리지 내역 상세 등록 (적립예정)
                            orderMapper.insertMbEntrpsMlgInfoDtl(orderModel);


                            List<Long> getMlgSnList = new ArrayList<Long>(); // 마일리지 적립 예정에서 적립으로 변환 대상 리스트

                            // 달성율이 100% 이상일 때 적립 예정인 건이 있으면 적립으로 새로 등록
                            // 마일리지 적립 예정에서 적립으로 변환 대상 가져오기
                            List<OrderMbEntrpsMlgInfoDtlVO> mlgAccmlCnvrTrget = orderMapper.selectMlgAccmlCnvrTrget(orderModel);
                            mlgAccmlCnvrTrget.forEach(data -> {
                                log.warn(">> 마일리지 적립예정에서 적립으로 변환 대상 : " + String.valueOf(data));

                                getMlgSnList.add(data.getMlgSn()); // 마일리지 순번

                                orderMbEntrpsMlgInfoDtlVO.setMlgEndDe(data.getMlgEndDe()); // 마일리지 만료 일자
                                orderMbEntrpsMlgInfoDtlVO.setMlgSe("01"); // 마일리지 구분 (01: 적립)
                                orderMbEntrpsMlgInfoDtlVO.setMlgTy("08"); // 마일리지 유형 (08: 보증수수료)
                                orderMbEntrpsMlgInfoDtlVO.setMlgDetailDtls("보증수수료 마일리지 적립"); // 마일리지 상세 내역
                                orderMbEntrpsMlgInfoDtlVO.setDelngMlg(data.getDelngMlg()); // 거래 마일리지
                                orderMbEntrpsMlgInfoDtlVO.setOrderNo(data.getOrderNo()); // 주문번호
                                orderModel.setOrderMbEntrpsMlgInfoDtlVO(orderMbEntrpsMlgInfoDtlVO);

                                // 회원_업체 마일리지 내역 상세 등록 (적립)
                                try {
                                    orderMapper.insertMbEntrpsMlgInfoDtl(orderModel);
                                } catch(Exception e) {
                                    String stacktrace = ExceptionUtils.getStackTrace(e);
                                    log.error("[Exception][stacktrace] insertMbEntrpsMlgInfoDtl : " + stacktrace);
                                    log.error(">> 회원_업체 마일리지 내역 상세 등록 (적립) 실패 마일리지 순번 : " + data);
                                }
                            });
                        }

                        // 회원_업체 담보 기본의 매출 달성율 업데이트
                        orderMapper.updateMrtggSelngAchivrt(orderModel);

                        // 회원_업체 마일리지 내역 상세 등록 후 등록된 키가 있을 경우 이력 등록
                        if(Optional.ofNullable(orderModel.getMlgSn()).orElse(0L) > 0) {
                            // 회원_업체 마일리지 내역 상세 이력 등록
                            orderMapper.insertMbEntrpsMlgInfoDtlHst(orderModel);
                        }
                        // 회원_업체 담보 기본 이력 등록
                        orderMapper.insertMbEntrpsMrtggCntrctBasHst(orderModel);
                    }
                }
            }
        }
    }

    /**
     * <pre>
     * 처리내용: 삼성선물에 최초 호출 된 건준 시간초과 (PROPERTY) 된 건에 대해서 삼성선물 취소요청을 보낸다.
     * </pre>
     * @date 2021. 10. 25.
     * @author srec0043
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 10. 25.            srec0043            최초작성
     * ------------------------------------------------
     * @param orderModel
     * @throws Exception
     */
    private void cancelCallSamsung(OrderModel orderModel) throws CommCustomException, Exception {
        log.warn("cancelCallSamsung() start");
        List<String> cancelFtrnNoList = new ArrayList<String>();
        List<String> requstWonOrderNoListByCancel = new ArrayList<String>(); // 실패 건들의 원주문번호 리스트

        int ftrnNoListSize = orderModel.getFtrnNoList().size(); // 선물 주문 요청 건수
        int samsungFailListSize = orderModel.getSamsungFailList().size(); // 선물 주문 체결(30)이 아닌 (요청 실패 및 요청상태, null) 건수
        boolean allFailStatus = false; // (true : 전부다 실패인 경우, false : 한 건이라도 성공이 있는 경우)
        if( ftrnNoListSize == samsungFailListSize ) {
            // 전부다 실패인 경우
            allFailStatus = true;
        }
        log.warn(">> allFailStatus : " + allFailStatus);

        for(CommOrOrderFtrsBasVO failVo : orderModel.getSamsungFailList()) {
            log.warn(">> cancelCallSamsung > failVo.getRspnsFtrsSttusCode() : " + failVo.getRspnsFtrsSttusCode());
            // 삼성선물 실패건 중에서 상태가 '10'인 건만 취소 요청을 보냄
            // 2021.12.08 삼성선물 5초 동안 응답 코드 없는 CASE 발생해서 NULL 건 추가
            if (StringUtils.isBlank(failVo.getRspnsFtrsSttusCode()) || StringUtils.equals(failVo.getRspnsFtrsSttusCode(), "10")) {
                // 채번
                String ftrsRequstOrderNo = DateUtil.getNowDateTime("yyyyMMdd")+ "-" + "1" + assignService.selectAssignValue("OR", "FTRS_REQUST_ORDER_NO", DateUtil.getNowDate(), orderModel.getMberNo(), 10);
                // 해당 취소건의 원 주문 Key값 셋팅
                orderModel.setRequstWonOrderNo(failVo.getFtrsRequstOrderNo());
                requstWonOrderNoListByCancel.add(failVo.getFtrsRequstOrderNo()); // 실패 건들의 원주문번호 리스트 담기, 실패로 분류된 선물요청주문의 체결을 확인하기 위함

                orderModel.setFtrsRequstOrderNo(ftrsRequstOrderNo);
                // 정상 실패 여부를 확인하기 위해 키값 저장 -> 정책변경으로 실패 성공여부를 파악하지않아 필요는 없지만 살려둠 -> 파악하는 것으로 정책 다시 변경 20220517
                cancelFtrnNoList.add(ftrsRequstOrderNo);
                orderMapper.insertSamsungCancel(orderModel);
            }
        }
        orderModel.setCancelFtrnNoList(cancelFtrnNoList); // 취소 주문 요청 키 값 리스트 orderModel에 담기
        orderModel.setRequstWonOrderNoListByCancel(requstWonOrderNoListByCancel); // 실패 건들의 원주문번호 리스트 orderModel에 담기

        // 삼성선물 취소 콜
        if(cancelFtrnNoList.size() > 0 ) {
            try {
                String requstWonOrderNoListByCancelStr = StringUtils.join(requstWonOrderNoListByCancel, ",");
                log.warn(">> cancelCallSamsung > 삼성선물 취소 요청 > 선물요청주문번호(원주문) : " + requstWonOrderNoListByCancelStr);
                // 취소 요청 발생 SMS 전송, 템플릿에 따라 SMS 전송을 처리한다.
                procSms(orderModel, "73", requstWonOrderNoListByCancelStr);
            } catch(Exception e) {
                log.error("선물사 취소 요청 발생에 의한 SMS전송 실패");
            }

            Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getSamsungCancelUrl(), Collections.singletonMap("orderNo", orderModel.getOrderNo()));
            log.warn(">> cancelCallSamsung > 삼성선물 취소 요청 call : " + String.valueOf(resObj));
            if( resObj!= null && StringUtils.equals(String.valueOf(resObj.get(PdCommConstant.SAMSUNG_RESULT_KEY)), PdCommConstant.SAMSUNG_SUCCESS_CODE)) {
                // 취소 에서 60 실패 코드가 뜨면? -> 고려 하지않기로 했다 20210915 -> 다시 고려하기로.. 20220517

                /*
                 *  전부다 실패인 경우에만 5초간 응답 체크, 한건이라도 성공이 있는 경우 5초간 체크를 하지 않는다
                 *  실패 건들의 원주문 건(requstWonOrderNoListByCancel) 응답 선물 상태 코드가 체결인지 아닌지를 확인한다.
                 */
                if(allFailStatus) {
                    // 실패 건들의 원주문 건(requstWonOrderNoListByCancel) 응답 선물 상태 코드 중 체결된 건을 담는다, 아직 활용 계획은 없지만 추후 활용을 대비, 담아 놓는다.
                    List<CommOrOrderFtrsBasVO> samsungCancelFailList = new ArrayList<CommOrOrderFtrsBasVO>();
                    // 0.5초씩 쉬면서 설정 시간 초만큼 실패 건들의 원주문 건(requstWonOrderNoListByCancel) 응답 선물 상태 코드가 체결인지 아닌지를 확인
                    for(int i = 0 ; i < orProperty.getSamsungTimeoutsec() * 2  ; i ++) {
                        Thread.sleep(500);
                        // 실패 건들의 원주문 건(requstWonOrderNoListByCancel) 응답 선물 상태 코드가 체결인지 아닌지를 확인한다, 응답선물상태코드가 30인 것을 조회하여 성공 건 개수 파악
                        samsungCancelFailList = orderMapper.selectCancelSamsungResponse(orderModel);
                        if(samsungCancelFailList.size() > 0) {
                            allFailStatus = false; // 한 건이라도 성공이 있는 경우로 변경
                            break;
                        };
                    }
                }
            }else {
                // 삼성선물 취소 호출 실패 -> 고려 하지않기로 했다 20210915 -> 다시 고려하기로 했지만 로직 상 변화 없음.. 20220517
                log.error("선물사 취소 호출 실패");
            }
        }

        // 전부다 실패인 경우에만 실패건에 대한 재고 및 실주문중량 수정, 한건이라도 성공이 있는 경우 실패건에 대한 재고 및 실주문중량은 고려하지 않는다.
        if(allFailStatus) {
        	// 가단가일 경우
            if(StringUtils.equals("05", orderModel.getSleMthdCode())) {
	        	// 가단가 확정 - 판매 방식이 라이브이거나 판매 방식이 지정가이고 터치된 후일 경우
	        	if(StringUtils.equals("live", orderModel.getDcsnSelMthd()) || (StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", orderModel.getDcsnSelMthd()))) {
	        		// 가단가일 경우 주문 실패 처리
	        		updateCancelSamsungByPrvsnl(orderModel);
	        	}
            } else {
	        	// 주문 가격 및 수량 전체 수정
	            // 실패된 건에 대해서 재고 및 실주문중량 수정을 위한 함수
	            updateCancelSamsung(orderModel);
            }
        }
    }

    /**
     * <pre>
     * 처리내용: 가단가일 경우 주문 실패 처리
     * </pre>
     * @date 2024. 10. 14.
     * @author srec0049
     * @history 
     * ------------------------------------------------
     * 변경일                 작성자          변경내용
     * ------------------------------------------------
     * 2024. 10. 14.          srec0049         최초작성
     * ------------------------------------------------
     * @param orderModel
     * @throws Exception
     */
    public void updateCancelSamsungByPrvsnl(OrderModel orderModel) throws Exception {
    	/** 실제 주문 중량 **/
        int realOrderWt = orderModel.getOrderWt();
        int samsungOrderWt = orderModel.getSamsungOrderWt(); // 삼성선물 주문 단위 중량
        
     // 실제 삼성선물에 주문을 요청한 테이블 조회
        List<CommOrOrderFtrsBasVO> samsungWonList = orderMapper.selectSamsungWonList(orderModel);
        for(CommOrOrderFtrsBasVO ft : samsungWonList) {
            // 삼성선물 호출 건에 대해 30이 제외된 10, 50, 60 상태값은 모두 실패 이므로 재고 증가 및 실주문 중량 감소 로직 진행, 20220616 취소완료에 대한 50 응답 코드 로직 추가
            // 2021.12.08 삼성선물 5초 동안 응답 코드 없는 CASE 발생해서 NULL 건 추가
            if (StringUtils.isBlank(ft.getRspnsFtrsSttusCode())
                    || StringUtils.equals("10", ft.getRspnsFtrsSttusCode())
                    || StringUtils.equals("50", ft.getRspnsFtrsSttusCode())
                    || StringUtils.equals("60", ft.getRspnsFtrsSttusCode())) {
                // 해당 BL DETAIL 실제 주문 초기화
                for(ItemPriceMatchingBlInfoVO bl : orderModel.getBlList()) {
                    if(StringUtils.equals(bl.getBlNo(), ft.getBlNo())) {
                    	// 삼성선물 주문 실패 시 삼성선물 주문 단위 중량(ex. 메탈코드 7 알루미늄 25톤) 단위이므로 실제 주문 중량을 삼성선물 주문 단위 중량씩 감소 시킨다
                        realOrderWt -= samsungOrderWt;
                    }
                }
            }
        }
        
        if(realOrderWt == 0) {
            // 템플릿에 따라 SMS 전송을 처리한다.
            procSms(orderModel, "77", "선물사 주문 전체 실패");
            log.info("OrderServiceImpl updateCancelSamsung line-2117 vo.toString() >> " + orderModel.toString());
            orderModel.setLimitOrderSttusCode("90"); // 지정가 주문 상태 코드[90(체결실패(선물 실패))] set
            throw new Exception("선물사 주문 전체 실패");
        }
    }
    
    /**
     * <pre>
     * 처리내용: 삼성선물 취소 처리된 건에 대해서 재고 재파악 및 실제 주문 중량수정을 한다.
     * </pre>
     * @date 2021. 10. 25.
     * @author srec0043
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 10. 25.            srec0043            최초작성
     * ------------------------------------------------
     * @param orderModel
     * @throws Exception
     */
    private void updateCancelSamsung(OrderModel orderModel) throws CommCustomException, Exception {
        // 삼성선물 원 요청 조회
        /** 실제 주문 중량 **/
        int realOrderWt = orderModel.getOrderWt();
        int totBundleQy = orderModel.getTotBundleQy();

        int samsungOrderWt = orderModel.getSamsungOrderWt(); // 삼성선물 주문 단위 중량
    	if(StringUtils.equals(orderModel.getSmlqyPurchsAt(), "Y")) {
    		// [소량구매]일 경우, 주문 중량(번들)이 기준
    		samsungOrderWt = orderModel.getOrderWt();
    	}

        // 실제 삼성선물에 주문을 요청한 테이블 조회
        List<CommOrOrderFtrsBasVO> samsungWonList = orderMapper.selectSamsungWonList(orderModel);
        for(CommOrOrderFtrsBasVO ft : samsungWonList) {
            // 삼성선물 호출 건에 대해 30이 제외된 10, 50, 60 상태값은 모두 실패 이므로 재고 증가 및 실주문 중량 감소 로직 진행, 20220616 취소완료에 대한 50 응답 코드 로직 추가
            // 2021.12.08 삼성선물 5초 동안 응답 코드 없는 CASE 발생해서 NULL 건 추가
            if (StringUtils.isBlank(ft.getRspnsFtrsSttusCode())
                    || StringUtils.equals("10", ft.getRspnsFtrsSttusCode())
                    || StringUtils.equals("50", ft.getRspnsFtrsSttusCode())
                    || StringUtils.equals("60", ft.getRspnsFtrsSttusCode())) {
                // 해당 BL DETAIL 실제 주문 초기화
                for(ItemPriceMatchingBlInfoVO bl : orderModel.getBlList()) {
                    if(StringUtils.equals(bl.getBlNo(), ft.getBlNo())) {
                    	int bundle = 0;
                    	double bundleWt = 0.0;
                    	if(StringUtils.equals(orderModel.getSmlqyPurchsAt(), "Y")) {
                    		// 소량구매일 경우, 주문 번들 수/net 평균 중량 적용
                    		bundle = bl.getMatchedSleInvntryUnsleBundleBnt().intValue();
                            bundleWt = bl.getMatchedSleInvntryUnsleBnt().doubleValue();
                    	} else {
                    		// 이론 번들수/이론중량
                            bundle = bl.getWeightMappingCalculateValues().get(BigDecimal.valueOf(samsungOrderWt)).getCollectBundle().intValue();
                            bundleWt = bl.getWeightMappingCalculateValues().get(BigDecimal.valueOf(samsungOrderWt)).getCollectLogicalWeight().doubleValue();
                    	}

                        // 삼성선물 주문 실패 시 삼성선물 주문 단위 중량(ex. 메탈코드 7 알루미늄 25톤) 단위이므로 실제 주문 중량을 삼성선물 주문 단위 중량씩 감소 시킨다
                        realOrderWt -= samsungOrderWt;
                        totBundleQy -= bundle;
                        orderModel.setOrderSn(ft.getOrderSn());
                        orderModel.setRealOrderWt(samsungOrderWt);
                        orderModel.setBundleQy(bundle);
                        orderMapper.updateOrderDetail(orderModel);

                        // 재고 차감
                        // 실제 주문 데이터에서 실패한 주문의 데이터 만큼 차감
                        bl.setRealMatchedOrderedBnt(bl.getRealMatchedOrderedBnt().subtract(BigDecimal.valueOf(samsungOrderWt)));
                        bl.setRealMatchedSleInvntryUnsleBnt(bl.getRealMatchedSleInvntryUnsleBnt().subtract(BigDecimal.valueOf(bundleWt)));
                        bl.setRealMatchedSleInvntryUnsleBundleBnt(bl.getRealMatchedSleInvntryUnsleBundleBnt().subtract(BigDecimal.valueOf(bundle)));
                    }
                }
            }
        }
        //실제 주문 된 총 중량 셋팅
        orderModel.setTotRealOrderWt(realOrderWt);
        //실제 주문된 번들 수 셋팅
        orderModel.setTotBundleQy(totBundleQy);

        long calcGoodsUntpc = 0;
        if(StringUtils.equals("0104", orderModel.getSleMthdDetailCode())) {
            // 평균가-라이브
            calcGoodsUntpc = orderModel.getAvrgpcGoodsUntpc();
        } else if(StringUtils.equals("0304", orderModel.getSleMthdDetailCode())) {
        	// 평균가-지정가
        	calcGoodsUntpc = orderModel.getCntrctPurchsLastGoodsUntpc();
        } else {
            calcGoodsUntpc = orderModel.getPrSelVO().getNonPremiumEndPc() + orderModel.getLivePremiumVO().getSlePremiumAmount();
        }

        //가격 정보 재계산 (배송비, 공급가, 부가세, 판매가 계산 제외 - 배송비 때문)
        //setPriceInfo(orderModel, orderModel.getPrSelVO().getEndPc(), realOrderWt);
        commOrderService.setPriceInfo(orderModel, calcGoodsUntpc, realOrderWt);

        /** 배송비, 공급가, 부가세, 판매가 구하기 20211112 **/
        setPriceInfoByExpectDlvrf(orderModel, false, realOrderWt, false);

        // 주문 마스터 수정
        orderMapper.updateOrderMaster(orderModel);
        if(StringUtils.equals(orderModel.getDlvyMnCode(), "01")) {
            // 케이지배송일때 배송비 테이블 업데이트
            orderMapper.updateOrderDlvrf(orderModel);
        }

        if(realOrderWt == 0) {
            // 템플릿에 따라 SMS 전송을 처리한다.
            procSms(orderModel, "77", "선물사 주문 전체 실패");
            log.info("OrderServiceImpl updateCancelSamsung line-2117 vo.toString() >> " + orderModel.toString());
            orderModel.setLimitOrderSttusCode("90"); // 지정가 주문 상태 코드[90(체결실패(선물 실패))] set
            throw new CommCustomException("선물사 주문 전체 실패");
        }
    }

    /**
     * <pre>
     * 처리내용: 라이브 가격이 아니라 고정가 일때 이월렛 결제 요청을 보낸다.
     * </pre>
     * @date 2021. 10. 25.
     * @author srec0043
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 10. 25.            srec0043            최초작성
     * ------------------------------------------------
     * @param orderModel
     * @throws Exception
     */
    private void callZnEwallet(OrderModel orderModel) throws CommCustomException, Exception {
        log.warn("[OrderServiceImpl][callZnEwallet] IN");

        // 결제 기본 테이블 생성
        // 고정가는 이월렛 결제가 완료 되어야 주문 성공
        String setleNo = DateUtil.getNowDateTime("yyyyMMdd")+ "-" + assignService.selectAssignValue("OR", "SETLE_NO", DateUtil.getNowDate(), orderModel.getMberNo(), 5);
        orderModel.setSetleNo(setleNo);
        orderMapper.insertEwalletSetle(orderModel);
        Map<String, Object> ewalletMap = new HashMap<String, Object>();
        ewalletMap.put("entrpsNo", orderModel.getEntrpsNo());
        // 거래구분 코드 0001 셋팅 하나은행 전문 참고
        ewalletMap.put("iemSeCode", "0001");
        // 증거금으로 주문하기일 경우 거래금액은 최소결제금액, 선수금 여부 Y 값을 준다.
        if(StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
            ewalletMap.put("delngAmount", orderModel.getMummSetleAmount());
            ewalletMap.put("precdntAt", "Y"); // 선수금 여부
        } else {
            ewalletMap.put("delngAmount", orderModel.getSlepc());
            ewalletMap.put("precdntAt", "N"); // 선수금 여부
        }
        // 결제 테이블 키값을 전달 후 이월렛 서버에서 응답 처리 후 업데이트 진행
        ewalletMap.put("setleNo", setleNo);
        ewalletMap.put("ewalletExcclcTyCode", "03"); // 이월렛 정산 유형 코드 20211108 추가
        // 주문번호 전달 후 이월렛 서버에서 응답 처리 후에 회원_업체 이월렛 상세 테이블의 주문 번호로 들어간다. 20211108 추가
        ewalletMap.put("orderNo", orderModel.getOrderNo());

        Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getEwalletOrderUrl(), ewalletMap);
        log.warn(">> 이월렛 resObj : " + resObj);
        if(resObj != null && StringUtils.equals(String.valueOf(resObj.get(PdCommConstant.EWALLET_RESULT_KEY)), PdCommConstant.EWALLET_SUCCESS_CODE) && resObj.get(PdCommConstant.EWALLET_DATA_KEY) != null){
            boolean isSuccess = false;
            Map<String, Object> resultData = (Map<String, Object>) resObj.get(PdCommConstant.EWALLET_DATA_KEY);
            orderModel.setDelngSeqNo(String.valueOf(resultData.get("delngSeqNo")));
            // 이월렛 서버에서 결제테이블 정상 성공으로 업데이트 되었는지 체크 현재 5초 설정
            for(int i = 0 ; i < orProperty.getEwalletTimeoutsec() * 2  ; i ++) {
                Thread.sleep(500);
                //호출 건 응답 코드 확인
                String rspnsCode = orderMapper.selectEwalletRspnCode(orderModel);
                log.warn(">> rspnsCode : " + rspnsCode);
                if(!StringUtils.isEmpty(rspnsCode)) {
                    //응답 코드가 000 일때 거래 완료 -> 전문설계서 응답코드 확인
                    if(StringUtils.equals(rspnsCode, "000")) {
                        isSuccess = true;
                    }
                    log.warn(">> rspnsCode : " + rspnsCode + ", isSuccess : " + isSuccess);
                    break;
                }
            }
            log.warn(">> finally isSuccess : " + isSuccess);
            if(!isSuccess) {
                // 템플릿에 따라 SMS 전송을 처리한다.
                procSms(orderModel, "77", "이월렛 주문 실패");
                log.info("OrderServiceImpl callZnEwallet line-2254 vo.toString() >> " + orderModel.toString());
                throw new CommCustomException("이월렛 주문 실패");
            }

            orderMapper.updateCnCntrctOrderBas(orderModel); // 평균가 주문의 경우, 계약_발주 기본의 주문번호 업데이트

              // 23-06-20 변경사항 : 전문 수신 결과에 맞춰서 세금계산서 호출하도록 변경하기 위해 로직을 VA Project로 옮김
//            if(StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
//                log.warn("[OrderServiceImpl][callZnEwallet] 증거금 주문하기, 세금계산서 미 호출");
//            } else {
//                log.warn("[OrderServiceImpl][callZnEwallet] 이월렛 단독 결제, 세금계산서 호출");
//                try {
//                    Map<String, Object> paramVo = new HashMap<String, Object>();
//                    paramVo.put("canclExchngRtngudNo", null);
//                    paramVo.put("jobSe", "ORDER");
//                    paramVo.put("orderNo", orderModel.getOrderNo());
//                    Map<String, Object> taxbillResMap = httpClientHelper.postCallApi(orProperty.getTaxbillUrl(), paramVo);
//                    log.warn("taxbill response = "+ String.valueOf(taxbillResMap));
//
//                    // 세금계산서 호출까지 완료된 건만 완료 처리
//                    if (null != taxbillResMap && StringUtils.equals(String.valueOf(taxbillResMap.get("responseCode")), "200")) {
//                        log.warn(">> 세금계산서 호출 성공");
//                    } else {
//                        log.info("OrderServiceImpl callZnEwallet line-2277 vo.toString() >> " + orderModel.toString());
//                        throw new CommCustomException("세금계산서 호출 실패");
//                    }
//
//                } catch (Exception e) {
//                    log.info("OrderServiceImpl callZnEwallet line-2282 vo.toString() >> " + orderModel.toString());
//                    //throw new CommCustomException("세금계산서 오류 실패");
//                }
//            }
        } else {
            // 템플릿에 따라 SMS 전송을 처리한다.
            procSms(orderModel, "77", "이월렛 호출 실패");
            log.info("OrderServiceImpl callZnEwallet line-2289 vo.toString() >> " + orderModel.toString());
            throw new CommCustomException("이월렛 호출 실패");
        }
    }

    /**
     * <pre>
     * 처리내용: 공통제공 최적의 BL 리스트를 호출한다.
     * </pre>
     * @date 2021. 10. 25.
     * @author srec0043
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 10. 25.            srec0043            최초작성
     * ------------------------------------------------
     * @param orderModel
     * @return
     * @throws Exception
     */
    private List<ItemPriceMatchingBlInfoVO> getBlList(OrderModel orderModel) throws CommCustomException, Exception {
        // 최적의 BL 리스트를 가져온다 (leftOverWtRetrunBlEmptyYn 재고없음처리 리턴여부 사용 안함)
        return commOrderService.getOptimalBlList(orderModel.getEntrpsNo(), orderModel.getMetalCode(), orderModel.getItmSn(), orderModel.getDstrctLclsfCode()
                , orderModel.getBrandGroupCode(), orderModel.getRealBrandCode(), orderModel.getSleMthdCode(), orderModel.getOrderWt()
                , orderModel.getSleUnitWt(), orderModel.getOnceSlePossWt(), orderModel.getReMainBlNo(), "N", orderModel.getSleMthdDetailCode()
                , orderModel.getCntrctOrderBasInfo().getCntrctOrderNo(), orderModel.getSmlqyPurchsAt());
    }

    /**
     * 주문완료시 후처리 작업으로 별로의 스레드를 통해 각자 서비스들이 움직인다.
     */
    @Override
    public void orderComplete(OrderModel orderModel) {
        log.warn("[OrderServiceImpl][orderComplete] IN");
        try {
            ObjectMapper objectMapper = new ObjectMapper();

            // VO 객체 내부의 VO객체 공유 현상에 따른 객체 복사 방식으로 변경 (20231005 추가)
            OrderModel orderModelByFx = objectMapper.readValue(objectMapper.writeValueAsString(orderModel), OrderModel.class);
            log.info("TestOrder orderComplete orderModelByFx.toString() >> " + orderModelByFx.toString());
            OrderModel orderModelByOrderInvntryUdt = objectMapper.readValue(objectMapper.writeValueAsString(orderModel), OrderModel.class);
            log.info("TestOrder orderComplete orderModelByOrderInvntryUdt.toString() >> " + orderModelByOrderInvntryUdt.toString());
            // 평균가 선물 등록시 VO객체 공유 현상 방지를 위해 객체 복사
            OrderModel orderModelByAvrgpcSamsung = objectMapper.readValue(objectMapper.writeValueAsString(orderModel), OrderModel.class);
            log.info("TestOrder orderComplete orderModelByAvrgpcSamsung.toString() >> " + orderModelByFx.toString());

            if(StringUtils.equals("01", orderModel.getSleMthdCode()) || StringUtils.equals("03", orderModel.getSleMthdCode())){

                // FX 호출, 복사한 객체 전달 (20231005 수정)
            	// 선물 체결 대상건이 있던 경우만 진행
            	if(orderModel.getOrderQy() > 0) {
            		callFX(orderModelByFx);
            	}

                if(StringUtils.equals(orderModel.getPaymentMn(), "ewallet") || StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
                    // 이월렛 호출
                    callEwallet(orderModel);
                } else if(StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty")) {
                    // B2B 전자상거래보증 호출
                    callMrtgg(orderModel);
                }

                if(StringUtils.equals("01", orderModel.getSleMthdCode()) && !StringUtils.equals(orderModel.getSleMthdDetailCode(), "0104")) {
                    // 2023-04-21 변경사항 : 라이브 주문정보 websocket publish, 평균가-라이브 주문은 제외
                    publishLiveOrder(orderModel);
                }
            } else if(StringUtils.equals("04", orderModel.getSleMthdCode())) {
                // 선물 데이터 등록
                callAvrgpcSamsung(orderModelByAvrgpcSamsung);

                // 선물환 데이터 등록
                callAvrgpcFX(orderModelByFx);
            }

            //배송비 할인 여부 확인 후 업데이트
            //dscntExpectDlvrfUpd(orderModel);
            // 쿠폰테이블 업데이트
            updateCouponIsuBas(orderModel);
            // 재고 차감, 복사한 객체 전달 (20231005 수정)
            orderInvntryUdt(orderModelByOrderInvntryUdt);
            // Oms 통신
            callOms(orderModel);
            // 프라이싱 테이블을 등록[프라이싱 단계 코드 : 03(결제완료)]한다. 20211123 수정
            instPricingByStepCode(orderModel);
            // 대쉬보드 호출
            callDashboard(orderModel);
            // 메일 발송 20211214 주석처리
            callMail(orderModel);
            // 앱푸시 발송, 20220211 주문완료 시 앱푸시 제외됨, 주석처리
//          callAppPush(orderModel);
            // 카카오톡 발송
//          callKakao(orderModel);
            // SMS 발송
            callSms(orderModel);
            // 판매 브랜드 잔량 탐색 (최적BL 탐색)
            getBlInvtry(orderModel);
            // 세금계산서 호출
//          callTaxBill(orderModel); // 20211210 이월렛 성공 시 세금계산서 발행으로 변경되어 제거
            //2024 설날 복주머니 이벤트 : 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
            //복주머니 이벤트 종료로 주석처리(추후 사용 가능)
            /*if(selectCntEvNewYearPromtn() < 200) {
            	insertEvNewYearPromtn(orderModel);
            }*/
            // History 생성
            instHistory(orderModel);

        }catch (Exception e) {
            log.info("OrderServiceImpl orderComplete line-2492 vo.toString() >> " + orderModel.toString());
            log.error("[OrderServiceImpl][orderComplete] " + ExceptionUtils.getStackTrace(e));
        }
    }

    /**
     * 주문완료시 후처리 작업으로 별로의 스레드를 통해 각자 서비스들이 움직인다. (로직은 빈 껍데기)
     */
    @Override
    public void orderCompleteThreadTest(OrderModel orderModel) {
        //log.warn("[OrderServiceImpl][orderCompleteThreadTest] IN");
        try {
            if(StringUtils.equals("01", orderModel.getSleMthdCode()) || StringUtils.equals("03", orderModel.getSleMthdCode())){
                // FX 호출
                callThreadTest(1);
                if(StringUtils.equals(orderModel.getPaymentMn(), "ewallet") || StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
                    // 이월렛 호출
                    callThreadTest(2);
                } else if(StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty")) {
                    // B2B 전자상거래보증 호출
                    callThreadTest(2);
                }
                // 2023-04-21 변경사항 : 라이브 주문정보 websocket publish
                callThreadTest(3);
            }
            //배송비 할인 여부 확인 후 업데이트
            callThreadTest(4);
            // 재고 차감
            callThreadTest(5);
            // Oms 통신
            callThreadTest(6);
            // 프라이싱 테이블을 등록[프라이싱 단계 코드 : 03(결제완료)]한다. 20211123 수정
            callThreadTest(7);
            // 대쉬보드 호출
            callThreadTest(8);
            // 메일 발송 20211214 주석처리
            callThreadTest(9);
            // 앱푸시 발송, 20220211 주문완료 시 앱푸시 제외됨, 주석처리
//          callAppPush(orderModel);
            // 카카오톡 발송
//          callKakao(orderModel);
            // SMS 발송
            callThreadTest(10);
            // 세금계산서 호출
//          callTaxBill(orderModel); // 20211210 이월렛 성공 시 세금계산서 발행으로 변경되어 제거
            // History 생성
            callThreadTest(11);

        }catch (Exception e) {
            log.info("OrderServiceImpl orderComplete line-2492 vo.toString() >> " + orderModel.toString());
            log.error("[OrderServiceImpl][orderComplete] " + ExceptionUtils.getStackTrace(e));
        }
    }

    private synchronized void callThreadTest(int callNum) {
        //log.warn("[OrderServiceImpl][callThreadTest] IN callNum : " + callNum);
        Runnable callThreadTestRun = () -> {
            try {
                //long threadId = Thread.currentThread().getId();
                //String threadName = Thread.currentThread().getName();

                //log.warn("[OrderServiceImpl][callThreadTest] threadId : " + threadId + ", threadName : " + threadName);

                log.warn("[callThreadTest][callNum(" + callNum + ")] "
                        + ", poolSize : " + taskExecutor.getPoolSize()
                        + ", activeCount : " + taskExecutor.getActiveCount()
                        + ", queueSize : " + taskExecutor.getThreadPoolExecutor().getQueue().size()
                );

                Thread.sleep(1000);

            } catch (Exception e) {
                log.error("[OrderServiceImpl][callThreadTest] " + ExceptionUtils.getStackTrace(e));
            }
        };
        taskExecutor.execute(callThreadTestRun);
    }

    /**
     * <pre>
     * 처리내용: 하나은행 FX를 호출한다.
     * </pre>
     * @date 2021. 10. 25.
     * @author srec0043
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 10. 25.            srec0043            최초작성
     * ------------------------------------------------
     * @param orderModel
     */
    private synchronized void callFX(OrderModel orderModel) {
        log.warn("[OrderServiceImpl][callFX] IN");
        Runnable fxRun = () -> {
            try {
                // 주문 디테일 테이블 생성
                for(ItemPriceMatchingBlInfoVO bl : orderModel.getBlList()) {
                    if(bl.getRealMatchedOrderedBnt().compareTo(BigDecimal.ZERO) > 0) {
                        String fshgRequstOrderNo = DateUtil.getNowDateTime("yyyyMMdd")+ "-" + "2" + assignService.selectAssignValue("OR", "FSHG_REQUST_ORDER_NO", DateUtil.getNowDate(), orderModel.getMberNo(), 10);
                        orderModel.setFshgRequstOrderNo(fshgRequstOrderNo);
                        orderModel.setBlDetail(bl);
                        // 상품_PO 정보 가져오기
                        orderModel.setItPurchsInfoBas(Optional.ofNullable(orderMapper.selectItPurchsInfoBas(orderModel)).orElseThrow(() -> {
                            log.info("OrderServiceImpl callFX line-2535 vo.toString() >> " + orderModel.toString());
                            return new CommCustomException("callFX > PO 테이블 미존재");}));

                        // 주문_주문 선물환 기본 정보 등록하기
                        orderMapper.insertOrOrderFshgBas(orderModel);
                    }
                }
                Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getFxOrderUrl(), Collections.singletonMap("orderNo", orderModel.getOrderNo()));
                log.warn(">> 하나은행 fx resObj : " + resObj);
            } catch (Exception e) {
                log.error("[OrderServiceImpl][callFX] " + ExceptionUtils.getStackTrace(e));
            }
        };
        taskExecutor.execute(fxRun);
    }
    
    /**
     * 외부 하나은행 FX를 호출
     */
    @Override
    public void extrlCallFx(OrderModel orderModel) {
    	this.callFX(orderModel);
    }

    /**
     * <pre>
     * 처리내용: 평균가 주문일 경우, 선물환 데이터를 생성한다. (하나은행 FX는 호출하지 않는다.)
     * </pre>
     * @date 2023. 11. 23.
     * @author srec0066
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 11. 23.            srec0066            최초작성
     * ------------------------------------------------
     * @param orderModel
     */
    private synchronized void callAvrgpcFX(OrderModel orderModel) {
        log.warn("[OrderServiceImpl][callAvrgpcFX] IN");
        Runnable avrgpcFxRun = () -> {
            try {

                for(ItemPriceMatchingBlInfoVO bl : orderModel.getBlList()) {
                    String fshgRequstOrderNo = DateUtil.getNowDateTime("yyyyMMdd")+ "-" + "2" + assignService.selectAssignValue("OR", "FSHG_REQUST_ORDER_NO", DateUtil.getNowDate(), orderModel.getMberNo(), 10);
                    orderModel.setFshgRequstOrderNo(fshgRequstOrderNo);
                    orderModel.setBlDetail(bl);
                    // 상품_PO 정보 가져오기
                    ItPurchsInfoBas itPurchsInfoBas = Optional.ofNullable(orderMapper.selectItPurchsInfoBas(orderModel)).orElseThrow(() -> {
                                                      log.info("OrderServiceImpl callAvrgpcFX line-2923 vo.toString() >> " + orderModel.toString());
                                                      return new CommCustomException("callAvrgpcFX > PO 테이블 미존재");});
                    orderModel.setItPurchsInfoBas(itPurchsInfoBas);

                    // 계약_평균가 선물한 기본 정보 가져오기
                    CnAvrgpcFshgBasVO cnAvrgpcFshgBas = Optional.ofNullable(orderMapper.selectCnAvrgpcFshgBas(orderModel)).orElseThrow(() -> {
                                                        log.info("OrderServiceImpl callAvrgpcFX line-2930 vo.toString() >> " + orderModel.toString());
                                                        return new CommCustomException("평균가 선물환 기본 데이터 미존재");});
                    orderModel.setCnAvrgpcFshgBas(cnAvrgpcFshgBas);

                    // 1. 계약_평균가 선물환 기본 정보 등록하기, 응답선물환상태코드는 2(주문 체결)로 처리.
                    orderMapper.insertOrOrderFshgBas(orderModel);

                    // 2. 계약_평균가 선물환 처리 상세 등록
                    orderMapper.insertCnAvrgpcFshgProcessDtl(orderModel);
                }
            } catch (Exception e) {
                log.error("[OrderServiceImpl][callAvrgpcFX] 평균가 선물환 데이터 등록 error:" + ExceptionUtils.getStackTrace(e));
            }
        };
        taskExecutor.execute(avrgpcFxRun);
    }

    /**
     * <pre>
     * 처리내용: 하나은행 이월렛을 호출한다.
     * </pre>
     * @date 2021. 10. 25.
     * @author srec0043
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 10. 25.            srec0043            최초작성
     * ------------------------------------------------
     * @param orderModel
     */
    private synchronized void callEwallet(OrderModel orderModel) {
        log.warn("[OrderServiceImpl][callEwallet] IN");
        Runnable ewalletRun = () -> {
            try {
                // 결제 기본 테이블 생성
                String setleNo = DateUtil.getNowDateTime("yyyyMMdd")+ "-" + assignService.selectAssignValue("OR", "SETLE_NO", DateUtil.getNowDate(), orderModel.getMberNo(), 5);
                orderModel.setSetleNo(setleNo);
                orderMapper.insertEwalletSetle(orderModel);
                Map<String, Object> ewalletMap = new HashMap<String, Object>();
                ewalletMap.put("entrpsNo", orderModel.getEntrpsNo());
                ewalletMap.put("iemSeCode", "0001");
                // 증거금으로 주문하기일 경우 거래금액은 최소결제금액, 선수금 여부 Y 값을 준다.
                if(StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
                    ewalletMap.put("delngAmount", orderModel.getMummSetleAmount());
                    ewalletMap.put("precdntAt", "Y"); // 선수금 여부
                } else {
                    ewalletMap.put("delngAmount", orderModel.getSlepc());
                    ewalletMap.put("precdntAt", "N"); // 선수금 여부
                }
                ewalletMap.put("setleNo", setleNo);
                ewalletMap.put("ewalletExcclcTyCode", "03"); // 이월렛 정산 유형 코드
                // 주문번호 전달 후 이월렛 서버에서 응답 처리 후에 회원_업체 이월렛 상세 테이블의 주문 번호로 들어간다. 20211108 추가
                ewalletMap.put("orderNo", orderModel.getOrderNo());

                Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getEwalletOrderUrl(), ewalletMap);
                log.warn(">> 이월렛 resObj : " + resObj);
                if(resObj != null && StringUtils.equals(String.valueOf(resObj.get(PdCommConstant.EWALLET_RESULT_KEY)), PdCommConstant.EWALLET_SUCCESS_CODE) && resObj.get(PdCommConstant.EWALLET_DATA_KEY) != null){
                    boolean isSuccess = false;
                    Map<String, Object> resultData = (Map<String, Object>) resObj.get(PdCommConstant.EWALLET_DATA_KEY);
                    orderModel.setDelngSeqNo(String.valueOf(resultData.get("delngSeqNo")));
                    // 이월렛 서버에서 결제테이블 정상 성공으로 업데이트 되었는지 체크 현재 5초 설정
                    for(int i = 0 ; i < orProperty.getEwalletTimeoutsec() * 2  ; i ++) {
                        Thread.sleep(500);
                        //호출 건 응답 코드 확인
                        String rspnsCode = orderMapper.selectEwalletRspnCode(orderModel);
                        log.warn(">> rspnsCode : " + rspnsCode);
                        if(!StringUtils.isEmpty(rspnsCode)) {
                            //응답 코드가 000 일때 거래 완료 -> 전문설계서 응답코드 확인
                            if(StringUtils.equals(rspnsCode, "000")) {
                                isSuccess = true;
                            }
                            log.warn(">> rspnsCode : " + rspnsCode + ", isSuccess : " + isSuccess);
                            break;
                        }
                    }
                    log.warn(">> finally isSuccess : " + isSuccess);
                    if(!isSuccess) {
                        log.info("OrderServiceImpl callEwallet line-2612 vo.toString() >> " + orderModel.toString());
                        throw new CommCustomException("이월렛 주문 실패");
                    }

                    // OMS가 15로 업뎃 치는데 병행으로 실행되는 것이라 실시간일 경우 결제완료로 치는 것을 막는다. 20211215
//                  orderModel.setOrderSttusCode("10");
//                  orderMapper.updateLastOrderMaster(orderModel);

                    // 23-06-20 변경사항 : 전문 수신 결과에 맞춰서 세금계산서 호출하도록 변경하기 위해 로직을 VA Project로 옮김
//                  if(StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
//                      log.warn("[OrderServiceImpl][callZnEwallet] 증거금 주문하기, 세금계산서 미 호출");
//                  } else {
//                      log.warn("[OrderServiceImpl][callZnEwallet] 이월렛 단독 결제, 세금계산서 호출");
//                      try {
//                          Map<String, Object> paramVo = new HashMap<String, Object>();
//                          paramVo.put("canclExchngRtngudNo", null);
//                          paramVo.put("jobSe", "ORDER");
//                          paramVo.put("orderNo", orderModel.getOrderNo());
//                          Map<String, Object> taxbillResMap = httpClientHelper.postCallApi(orProperty.getTaxbillUrl(), paramVo);
//                          log.warn("taxbill response = "+ String.valueOf(taxbillResMap));
//
//                          // 세금계산서 호출까지 완료된 건만 완료 처리
//                          if (null != taxbillResMap && StringUtils.equals(String.valueOf(taxbillResMap.get("responseCode")), "200")) {
//                              log.warn(">> 세금계산서 호출 성공");
//                          } else {
//                              log.info("OrderServiceImpl callEwallet line-2636 vo.toString() >> " + orderModel.toString());
//                              throw new CommCustomException("세금계산서 호출 실패");
//                          }
//                      } catch (Exception e) {
//                          log.info("OrderServiceImpl callEwallet line-2640 vo.toString() >> " + orderModel.toString());
//                          throw new CommCustomException("세금계산서 오류 실패");
//                      }
//                  }
                } else {
                    log.info("OrderServiceImpl callEwallet line-2645 vo.toString() >> " + orderModel.toString());
                    throw new CommCustomException("이월렛 호출 실패");
                }

            } catch (Exception e) {
                log.error("[OrderServiceImpl][callEwallet] " + ExceptionUtils.getStackTrace(e));
            }
        };
        taskExecutor.execute(ewalletRun);
    }

    /**
     * <pre>
     * 처리내용: B2B 전자상거래보증을 호출한다.
     * </pre>
     * @date 2022. 7. 28.
     * @author srec0049
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 7. 28.         srec0049            최초작성
     * ------------------------------------------------
     * @param orderModel
     */
    private synchronized void callMrtgg(OrderModel orderModel) {
        log.warn("[OrderServiceImpl][callMrtgg] IN");
        Runnable mrtggRun = () -> {
            try {
                try {
                    // 주문 모달창에 선택된 결제 수단 값이 (전자상거래보증 or 케이지크레딧) 중에 전자상거래보증일 때
                    if(StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty")) {
                        // 회원_업체 (전자상거래보증 or 케이지크레딧) 한도 상세 테이블 등록 후 업체 담보 순번 리턴
                        orderMapper.insertMbEntrpsMrtggLmtDtl(orderModel); // return 업체 담보 순번
                        // (전자상거래보증 or 케이지크레딧) - 회원_업체 담보 한도 상세 이력
                        orderMapper.insertMbEntrpsMrtggLmtDtlHst(orderModel);
                        // 주문_담보 기본 정보의 업체 담보 순번 값 및 주문 시점 잔여 한도 금액 추가
                        orderMapper.updateOrMrtggBas(orderModel);

                        // 고정가일 경우 전자상거래보증과 케이지크레딧은 이 시점에서 주문 성공으로 본다
                        // , 주문상태코드가 10이하일 때 주문상태코드와 주문완료일시를, 10초과일 때 주문완료일시를 업데이트
                        // 24-09-11 변경사항 : 가단가(05) 주문 case 추가
                        if(StringUtils.equals(orderModel.getSleMthdCode(), "02") 
                        		|| StringUtils.equals(orderModel.getSleMthdCode(), "04")
                        		|| StringUtils.equals(orderModel.getSleMthdCode(), "05")) {
                            log.warn("[OrderServiceImpl][callMrtgg] 고정가, 평균가 or 가단가일 경우 전자상거래보증과 서린크레딧은 이 시점에서 주문 성공으로 본다, 주문상태코드가 10이하일 때 주문상태코드와 주문완료일시를, 10초과일 때 주문완료일시를 업데이트");
                            orderModel.setOrderSttusCode("10");
                            orderMapper.updateLastOrderMasterByOrderSttusCode(orderModel); // 주문_주문 기본의 주문상태코드 및 주문완료일시를 주문상태코드 조건에 따라 업데이트
                        }

                       orderMapper.updateCnCntrctOrderBas(orderModel); // 평균가 주문의 경우, 계약_발주 기본의 주문번호 업데이트

                        if(StringUtils.equals(orderModel.getCdtlnSvcSeCode(), "02")) {
                            log.warn("[OrderServiceImpl][callMrtgg] 케이지크레딧은 B2B 전자상거래보증 호출 대상 아님");
                        } else {
                            // 담보 보증 api 호출
                            Map<String, Object> trnsmisVo = new HashMap<String, Object>();
                            trnsmisVo.put("mrtggNo", orderModel.getMrtggNo()); // 담보 번호
                            trnsmisVo.put("mrtggSttusCode", "10"); // 담보 상태 코드 [매매계약 전송요청: 10]
                            trnsmisVo.put("orderNo", orderModel.getOrderNo()); // 주문 번호
                            Map<String, Object> credtMrtggTrnsmisResMap = httpClientHelper.postCallApi(orProperty.getRepyMrtggUrl(), trnsmisVo);
                            log.warn("credtMrtggTrnsmisResMap response = "+ String.valueOf(credtMrtggTrnsmisResMap));

                            // 담보 보증 api 호출까지 완료된 건만 완료 처리
                            if (null != credtMrtggTrnsmisResMap && StringUtils.equals(String.valueOf(credtMrtggTrnsmisResMap.get("rspnsCode")), "200")) {
                                log.warn(">> 담보 보증 호출 성공");
                            } else {
                                log.info("OrderServiceImpl callMrtgg line-2707 vo.toString() >> " + orderModel.toString());
                                throw new CommCustomException("담보 보증 호출 실패");
                            }
                        }
                    }
                } catch (Exception e) {
                    log.info("OrderServiceImpl callMrtgg line-2713 vo.toString() >> " + orderModel.toString());
                    throw new CommCustomException("담보 보증 오류 실패 e.getMessage() : " + e.getMessage());
                }

                // 서린몰 or 평균가 주문일 경우, 결제 성공 후 마일리지 적립
                // 24-09-11 변경사항 : 가단가(05) 주문 case 추가
                if(StringUtils.equals(orderModel.getSleMthdCode(), "02") 
                		|| StringUtils.equals(orderModel.getSleMthdCode(), "04")
                		|| StringUtils.equals(orderModel.getSleMthdCode(), "05")) {
                    try {
                        // 마일리지 처리 (적립예정, 달성률 처리)
                        // 1. 전자상거래보증 주문에 따른 적립예정 처리
                        // 2. 전자상거래보증 주문에 따른 달성률 처리
                        // 3. 달성률 100% 달성 시 적립예정 등록 안함
                        // 4. 달성률 100% 달성 시 적립예정을 적립으로 변경
                        this.procOrderMlg(orderModel);
                    } catch(Exception e) {
                        String stacktrace = ExceptionUtils.getStackTrace(e);
                        log.error("[Exception][stacktrace] callMrtgg : " + stacktrace);
                        log.error("마일리지 처리 실패");
                    }
                }

                try {
                    Map<String, Object> paramVo = new HashMap<String, Object>();
                    paramVo.put("canclExchngRtngudNo", null);
                    paramVo.put("jobSe", "ORDER");
                    paramVo.put("orderNo", orderModel.getOrderNo());
                    Map<String, Object> taxbillResMap = httpClientHelper.postCallApi(orProperty.getTaxbillUrl(), paramVo);
                    log.warn("taxbill response = "+ String.valueOf(taxbillResMap));

                    // 세금계산서 호출까지 완료된 건만 완료 처리
                    if (null != taxbillResMap && StringUtils.equals(String.valueOf(taxbillResMap.get("responseCode")), "200")) {
                        log.warn(">> 세금계산서 호출 성공");
                    } else {
                        log.info("OrderServiceImpl callMrtgg line-2729 vo.toString() >> " + orderModel.toString());
                        throw new CommCustomException("세금계산서 호출 실패");
                    }

                } catch (Exception e) {
                    log.info("OrderServiceImpl callMrtgg line-2734 vo.toString() >> " + orderModel.toString());
                    throw new CommCustomException("세금계산서 오류 실패 e.getMessage() : " + e.getMessage());
                }

            } catch (Exception e) {
                log.info("OrderServiceImpl callMrtgg line-2738 vo.toString() >> " + orderModel.toString());
                log.error("[OrderServiceImpl][callMrtgg] " + ExceptionUtils.getStackTrace(e));
            }
        };
        taskExecutor.execute(mrtggRun);
    }

    /**
     * <pre>
     * 처리내용: 배송비 할인 여부 확인 후 업데이트
     * </pre>
     * @date 2022. 05. 30.
     * @author jdrttl
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 05. 30.        jdrttl              최초작성
     * 2022. 08. 17.        jhcha               수정
     * ------------------------------------------------
     * @param orderModel
     */
    private void dscntExpectDlvrfUpd(OrderModel orderModel) {
        log.warn("[OrderServiceImpl][dscntExpectDlvrfUpd] IN "+ Integer.parseInt(orderModel.getCouponDscntPrice()));
        //Runnable pricingRun = () -> {
            try {
                // 사용쿠폰 사용으로 처리
                List<CouponVO> couponList = orderModel.getCouponList();

                if(null != orderModel.getCouponList()) {
                    if(couponList.size() > 0) {
                        for(CouponVO vo :  couponList) {
                            // 쿠폰 사용으로 변경
                            orderMapper.updateDlvrfDscntAt(vo.getCouponSeqNo(),  Integer.toString(vo.getCouponDscntAmount()), orderModel.getOrderNo(), orderModel.getMberId());
                        }
                    }
                }
                log.warn("[OrderServiceImpl][dscntExpectDlvrfUpd] Update");

            } catch (Exception e) {
                log.error("[OrderServiceImpl][dscntExpectDlvrfUpd] " + ExceptionUtils.getStackTrace(e));
            }
        //};
        //taskExecutor.execute(pricingRun);
    }

    /**
     * <pre>
     * 처리내용: 재고를 차감하고 재고 테이블을 수정한다.
     * </pre>
     * @date 2021. 10. 25.
     * @author srec0043
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 10. 25.            srec0043            최초작성
     * ------------------------------------------------
     * @param orderModel
     */
    private synchronized void orderInvntryUdt(OrderModel orderModel) {
        log.warn("[OrderServiceImpl][orderInvntryUdt] IN");
        Runnable invntryRun = () -> {
            try {
                int invntryPubChkNum = 0; // 재고 데이터 변경이 있는지 체크할 값

                // 평균가 주문일 경우
            	if(StringUtils.equals("04", orderModel.getSleMthdCode()) || StringUtils.isNotEmpty(orderModel.getSleMthdDetailCode())) {
                    CommAvrgPcInvntryVO commAvrgPcInvntryVO = CommAvrgPcInvntryVO.builder()
                                                            .avrgSe("SETLE")                                                 // 평균가구분(avrgSe) [ASGN(할당), ORDER(발주), SETLE(결제)]
                                                            .processSe("INCRS")                                              // 처리구분(processSe) [DDCT(차감), INCRS(증가)]
                                                            .cntrctNo(orderModel.getCntrctOrderBasInfo().getCntrctNo())      // 계약 번호
                                                            .cntrctYm(orderModel.getCntrctOrderBasInfo().getCntrctYm())      // 계약 년월
                                                            .cntrctYmSn(orderModel.getCntrctOrderBasInfo().getCntrctYmSn())  // 계약 년월 순번
                                                            .orderNo(orderModel.getOrderNo())                                // 주문 번호
                                                            .lastChangerId(orderModel.getMberId())                           // 최종 변경자 아이디
                                                            .invntryAsgnSeCode(StringUtils.equals("04", orderModel.getSleMthdCode()) ? "20" : "10") // 재고 할당 구분 코드 [10(LIVE), 20(평균가)]
                                                            .build();

                    for(ItemPriceMatchingBlInfoVO bl : orderModel.getBlList()) {
                        orderModel.setBlDetail(bl);

                        if(bl.getRealMatchedOrderedBnt().compareTo(BigDecimal.ZERO) > 0) {
                            commAvrgPcInvntryVO.setBlNo(bl.getBlNo());                                                        // BL 번호
                            commAvrgPcInvntryVO.setCalcWt(bl.getRealMatchedOrderedBnt().intValue());                          // 계산 중량 (할당 중량)
                            commAvrgPcInvntryVO.setCalcInvntry(bl.getRealMatchedSleInvntryUnsleBnt());                        // 계산 재고 (할당 재고)
                            commAvrgPcInvntryVO.setCalcBundleInvntry(bl.getRealMatchedSleInvntryUnsleBundleBnt().intValue()); // 계산 번들 재고 (할당 번들 재고)

                            // 평균가 재고 공통 Service - 재고차감 및 이력 등록
                            commAvrgPcInvntryService.insertAndUpdateAvrgPcInvntryDdctIncrs(commAvrgPcInvntryVO);

                            invntryPubChkNum++; // 변경이 있을 시 증가
                        }
                    }
                } else {
                    for(ItemPriceMatchingBlInfoVO bl : orderModel.getBlList()) {
                        if(bl.isInvntryUdt()) {
                            orderModel.setBlDetail(bl);
                            // 최초 로 원복 후 작업 재고 정리 시작
                            orderMapper.updateRecoverInvntryBlInfoBas(orderModel);
                            if(bl.getRealMatchedOrderedBnt().compareTo(BigDecimal.ZERO) > 0) {
                                // IT_BL_INFO_BAS
                                orderMapper.updateInvntryBlInfoBas(orderModel);
                                // IT_BL_INFO_HIST_DTL(화면에서 관리 하는 이력 테이블), 04-주문으로 코드 생성,
                                orderMapper.insertInvntryBlInfoHistDtl(orderModel);
                                // IT_BL_INFO_BAS_HST (시스템 이력)
                                orderMapper.insertBlInfoBasHst(orderModel);

                                invntryPubChkNum++; // 변경이 있을 시 증가
                            }
                        }
                    }
                }

                // 재고가 변경된 사항이 한건이라도 있을 시
                if(invntryPubChkNum > 0) {
                    // Redis에 재고 데이터 변경 메세지 발행하기
                    invntrySttusService.invntrySttusMsgPublish();
                }

            } catch (Exception e) {
                log.error("[OrderServiceImpl][orderInvntryUdt] " + ExceptionUtils.getStackTrace(e));
            }
        };
        taskExecutor.execute(invntryRun);
    }

    /**
     * <pre>
     * 처리내용: OMS를 호출한다.
     * </pre>
     * @date 2021. 10. 25.
     * @author srec0043
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 10. 25.            srec0043            최초작성
     * ------------------------------------------------
     * @param orderModel
     */
    private synchronized void callOms(OrderModel orderModel) {
        log.warn("[OrderServiceImpl][callOms] IN");
        Runnable omsRun = () -> {
            try {
                log.warn(">> orProperty.getLoOmsUrl() : " + orProperty.getLoOmsUrl());
                log.warn(">> orderModel.getOrderNo() : " + orderModel.getOrderNo());
                // OMS 송신
                String orderSttusCode = ""; // 주문 상태 코드
                String realOrderCode = ""; // 실주문(1), 가주문(0) 여부

                // 입고 예정 재고 여부에 의한 주문 홀딩 여부, 주문 홀딩 여부 중에서 우선순위 최상위
                if(StringUtils.equals("Y", orderModel.getOrderHoldingByWrhousngPrearngeInvntryUseAt())) {
                    orderSttusCode = "13"; // 배송대기

                    // 주문 홀딩 사용 여부가 Y이고, 증거금 주문하기일 경우
                    orderModel.setOrderSttusCode(orderSttusCode);
                    orderMapper.updateLastOrderMaster(orderModel); // 주문_주문 기본의 주문상태코드 및 주문완료일시, OMS접수 번호, 주문 실패 사유 등을 값에 따라 업데이트
                    orderMapper.updateCnCntrctOrderBas(orderModel); // 평균가 주문의 경우, 계약_발주 기본의 주문번호 업데이트
                } else {
                    if(StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
                        // 증거금으로 주문하기일 경우
                        orderSttusCode = "13"; // 배송대기
                        realOrderCode = "0"; // 가주문
                    } else {
                        // 이월렛 주문 또는 담보 보증 주문일 경우
                        orderSttusCode = "15"; // [15(배송 준비)], 물류접수번호 받았을 시 배송준비 코드로 변경
                        realOrderCode = "1"; // 실주문
                    }

                    // 주문 홀딩일 경우 증거금 주문 시 배송대기로 데이터 생성, 물류 API 송신은 하지 않는다.
                    if(StringUtils.equals(orderModel.getOrderHoldingUseAt(), "Y") && StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
                        // 주문 홀딩 사용 여부가 Y이고, 증거금 주문하기일 경우
                        orderModel.setOrderSttusCode(orderSttusCode);
                        orderMapper.updateLastOrderMaster(orderModel); // 주문_주문 기본의 주문상태코드 및 주문완료일시, OMS접수 번호, 주문 실패 사유 등을 값에 따라 업데이트
                        orderMapper.updateCnCntrctOrderBas(orderModel); // 평균가 주문의 경우, 계약_발주 기본의 주문번호 업데이트
                    } else {
                        Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getLoOmsUrl() + "/SetleInfo/" + orderModel.getOrderNo() + "/1" + "/" + realOrderCode, null);
                        log.warn(">> OMS 송신 : " + String.valueOf(resObj));
//                      if(resObj != null && resObj.get("omsOrderRceptNo") != null) {
//                          orderModel.setOmsRceptNo(String.valueOf(resObj.get("omsOrderRceptNo")));
//                          // 증거금으로 주문하기일 경우 배송대기(13)으로 머물러있는다. 배송준비는 실주문 시 처리됨 125번 IF에 의해
//                          orderModel.setOrderSttusCode(orderSttusCode);
//                          orderMapper.updateLastOrderMaster(orderModel); // 주문_주문 기본의 주문상태코드 및 주문완료일시, OMS접수 번호, 주문 실패 사유 등을 값에 따라 업데이트
//                      } else {
//                          log.error("[OrderServiceImpl][callOms][물류 OMS번호 수신 실패] " + String.valueOf(resObj));
//                          // 템플릿에 따라 SMS 전송을 처리한다.
//                          procSms(orderModel, "44", "물류 OMS번호 수신 실패");
//                      }
                    }
                }
            } catch (Exception e) {
                log.error("[OrderServiceImpl][callOms][물류 API호출 실패] " + ExceptionUtils.getStackTrace(e));
                // 템플릿에 따라 SMS 전송을 처리한다.
                procSms(orderModel, "44", "물류 API호출 실패");
            }
        };
        taskExecutor.execute(omsRun);
    }

    /**
     * <pre>
     * 처리내용: 프라이싱 테이블을 등록[프라이싱 단계 코드 : 03(결제완료)]한다. 20211123 수정
     * </pre>
     * @date 2021. 10. 25.
     * @author srec0043
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 10. 25.            srec0043            최초작성
     * ------------------------------------------------
     * @param orderModel
     */
    private synchronized void instPricingByStepCode(OrderModel orderModel) {
        log.warn("[OrderServiceImpl][instPricingByStepCode] IN");
        Runnable pricingRun = () -> {
            try {
                String dateTimeNow = DateUtil.getNowDateTime("yyyyMMddHHmmss");

                String dateNow = DateUtil.getNowDate();
                String pricingNo = "P" + dateNow + "-" + assignService.selectAssignValue("PD", "PRICING_NO", dateNow, "SYSTEM", 6);

                // SELECT INSERT, 등록 시 필요한 값만 만들어서 넘긴다.
                orderModel.setNewPricingNo(pricingNo);
                orderModel.setApplcDt(dateTimeNow);
                orderModel.setPricingStepCode("03"); // 01:가격탐색, 02:장바구니, 03:걸제완료

                // 프라이싱 테이블을 등록[프라이싱 단계 코드 : 03(결제완료)]한다. 20211123 수정
                orderMapper.insertOrderPricingByStepCode(orderModel); // SELECT INSERT
            } catch (Exception e) {
                log.error("[OrderServiceImpl][instPricingByStepCode] " + ExceptionUtils.getStackTrace(e));
            }
        };
        taskExecutor.execute(pricingRun);
    }

    /**
     * <pre>
     * 처리내용: 대쉬보드에 현재 주문이 성공했다고 소켓을 호출한다.
     * </pre>
     * @date 2021. 10. 25.
     * @author srec0043
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 10. 25.            srec0043            최초작성
     * ------------------------------------------------
     * @param orderModel
     */
    private synchronized void callDashboard(OrderModel orderModel) {
        log.warn("[OrderServiceImpl][callDashboard] IN");
        Runnable dashboardRun = () -> {
            try {
                // 대쉬 보드 호출
//              httpClientHelper.getCallApi(orProperty.getDashboardUrl() + "/" + orderModel.getOrderNo());
                // 23-05-26 변경사항 : BO Dashboard call 공통 서비스 호출로 변경
                commDashboardWebsocketService.publishLiveOrder(orderModel.getOrderNo(), true);
            } catch (Exception e) {
                log.error("[OrderServiceImpl][callDashboard] " + ExceptionUtils.getStackTrace(e));
            }
        };
        taskExecutor.execute(dashboardRun);
    }

    /**
     * <pre>
     * 처리내용: 메일 서비스를 호출한다.
     * </pre>
     * @date 2021. 10. 25.
     * @author srec0043
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 10. 25.            srec0043            최초작성
     * ------------------------------------------------
     * @param orderModel
     */
    private synchronized void callMail(OrderModel orderModel) {
        log.warn("[OrderServiceImpl][callMail] IN");

        // MAIL 수신 동의 체크는 임시 주석 -> 추후에 MAIL 수신동의 체크해야 한다고 하면 아래 주석 풀고 진행
        //if(StringUtils.equals(orderModel.getMbDlvrgBas().getMberEmailRecptnAgreAt(), "Y"))    {
        Runnable mailRun = () -> {
            try {
                // 평균가 주문인 경우, 이메일 발송 제외
            	// 24-11-12 변경사항 : 가단가 주문(05)일 경우에도 이메일 발송 제외 처리되도록 조건문 수정
                if( ( !StringUtils.equals("04", orderModel.getSleMthdCode()) && !StringUtils.equals("05", orderModel.getSleMthdCode()) )
                		&& StringUtils.isEmpty(orderModel.getSleMthdDetailCode())) {

                    MailVO mailVo = new MailVO();
                    mailVo.setMailTmptSeq(15);                                      // 템플릿 번호
                    mailVo.setEmail(orderModel.getMbDlvrgBas().getMberEmail());     // 이메일 (수신자)(주문자)

                    MailVO selectMailTmpt = mailMapper.selectMailTmpt(15);          // 발신자 이메일 가져오기
                    mailVo.setMailSendEmail(selectMailTmpt.getSntoEmail());         // 발신자 이메일 주소 (로그인)
                    mailVo.setMailSendUserId("system");                             // 발신자 아이디 (로그인)
                    mailVo.setMemberNo(orderModel.getMberNo());                     // 회원 번호 (로그인)
                    mailVo.setEntrpsNo(orderModel.getEntrpsNo());                   // 업체 번호 (로그인)
                    log.debug("[OrderServiceImpl][callMail] mailVo : " + String.valueOf(mailVo));

                    Map<String, String> mailMap = orderMapper.selectMailInfo(orderModel); // 메일 내용 정보 가져오기

                    // OR_DLVRG_BAS(주문_배송지 기본) - RECEPT_ENTRPS_MOBLPHON_NO(수취 업체 휴대폰 번호) 복호화
                    String receptEntrpsMoblphonNo = String.valueOf(mailMap.get("hp"));
                    if(StringUtils.isNotEmpty(receptEntrpsMoblphonNo) && !receptEntrpsMoblphonNo.equals("null")) {
                        try {
                            log.debug("수취 업체 휴대폰 번호 복호화 전 ==================>" + receptEntrpsMoblphonNo);
                            receptEntrpsMoblphonNo = CryptoUtil.decryptAES256(receptEntrpsMoblphonNo);
                            log.debug("수취 업체 휴대폰 번호 복호화 후 ==================>" + receptEntrpsMoblphonNo);
                            /** 수취 업체 휴대폰 번호 셋팅 **/
                            mailMap.put("hp", receptEntrpsMoblphonNo);
                        } catch(Exception e) {
                            log.error("OrderServiceImpl mailMap RECEPT_ENTRPS_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
                        }
                    }

                    // 결제정보 동적 영역
                    final String separator = System.lineSeparator();
                    final String THEAD_TD_STYLE = "style=\"background: #efefef; border: 1px solid #ebebeb; color: #333; font-size: 12px; line-height: 35px;\"";
                    final String TBODY_TD_STYLE = "style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"";
                    final String TR_OPEN = "<tr>";
                    final String TR_CLOSE = "</tr>";
                    final String TD_CLOSE = "</td>";
                    final String TD_CENTER = "<td align=\"center\" ";
                    final String TD_RIGHT = "<td align=\"right\" ";
                    final String GT_SIGN = ">"; // GREATER_THAN_SIGN

                    String TD_ROWSPAN = "";
                    String TD_STR = "";
                    StringBuilder payArea = new StringBuilder();

                    // table start
                    payArea.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"border-collapse:collapse; \" width=\"100%\">").append(separator);
                        // thead start
                        payArea.append("<thead>").append(separator);
                            payArea.append("<tr style=\"height: 36px;\">").append(separator);
                                payArea.append("<th align=\"center\" ").append(THEAD_TD_STYLE).append(GT_SIGN).append("구분").append("</th>").append(separator);
                                payArea.append("<th align=\"center\" ").append(THEAD_TD_STYLE).append(GT_SIGN).append("항목").append("</th>").append(separator);
                                payArea.append("<th align=\"center\" ").append(THEAD_TD_STYLE).append(GT_SIGN).append("주문").append("</th>").append(separator);
                            payArea.append(TR_CLOSE).append(separator);
                        payArea.append("</thead>").append(separator);
                        // thead end
                        // tbody start
                        payArea.append("<tbody>").append(separator);
                            // 주문 정보
                            payArea.append(TR_OPEN).append(separator);
                                payArea.append(TD_CENTER).append("rowspan=\"2\" ").append(TBODY_TD_STYLE).append(GT_SIGN).append("<strong>주문 정보</strong>").append(TD_CLOSE).append(separator);
                                payArea.append(TD_CENTER).append(TBODY_TD_STYLE).append(GT_SIGN).append("수량").append(TD_CLOSE).append(separator);
                                payArea.append(TD_RIGHT).append(TBODY_TD_STYLE).append(GT_SIGN).append(String.valueOf(mailMap.get("totRealOrderWt"))).append(TD_CLOSE).append(separator);
                            payArea.append(TR_CLOSE).append(separator);
                            payArea.append(TR_OPEN).append(separator);
                                payArea.append(TD_CENTER).append(TBODY_TD_STYLE).append(GT_SIGN).append("상품단가").append(TD_CLOSE).append(separator);
                                payArea.append(TD_RIGHT).append(TBODY_TD_STYLE).append(GT_SIGN).append(String.valueOf(mailMap.get("goodsUntpc"))).append(TD_CLOSE).append(separator);
                            payArea.append(TR_CLOSE).append(separator);
                            // 주문 금액
                            payArea.append(TR_OPEN).append(separator);
                                payArea.append(TD_CENTER).append("rowspan=\"3\" ").append(TBODY_TD_STYLE).append(GT_SIGN).append("<strong>주문 금액</strong>").append(TD_CLOSE).append(separator);
                                payArea.append(TD_CENTER).append(TBODY_TD_STYLE).append(GT_SIGN).append("①상품금액").append(TD_CLOSE).append(separator);
                                payArea.append(TD_RIGHT).append(TBODY_TD_STYLE).append(GT_SIGN).append(String.valueOf(mailMap.get("orderPc"))).append(TD_CLOSE).append(separator);
                            payArea.append(TR_CLOSE).append(separator);
                            payArea.append(TR_OPEN).append(separator);
                                payArea.append(TD_CENTER).append(TBODY_TD_STYLE).append(GT_SIGN).append("②중량변동금").append(TD_CLOSE).append(separator);
                                payArea.append(TD_RIGHT).append(TBODY_TD_STYLE).append(GT_SIGN).append(String.valueOf(mailMap.get("wtChangegld"))).append(TD_CLOSE).append(separator);
                            payArea.append(TR_CLOSE).append(separator);
                            payArea.append(TR_OPEN).append(separator);
                                payArea.append(TD_CENTER).append(TBODY_TD_STYLE).append(GT_SIGN).append("③배송비").append(TD_CLOSE).append(separator);
                                payArea.append(TD_RIGHT).append(TBODY_TD_STYLE).append(GT_SIGN).append(String.valueOf(mailMap.get("expectDlvrf"))).append(TD_CLOSE).append(separator);
                            payArea.append(TR_CLOSE).append(separator);
                            // 결제 요청 금액
                            payArea.append(TR_OPEN).append(separator);
                                payArea.append(TD_CENTER).append("rowspan=\"3\" ").append(TBODY_TD_STYLE).append(GT_SIGN).append("<strong>결제 요청 금액</strong>").append(TD_CLOSE).append(separator);
                                payArea.append(TD_CENTER).append(TBODY_TD_STYLE).append(GT_SIGN).append("공급가액(①+②+③)").append(TD_CLOSE).append(separator);

                                // 증거금으로 주문하기일 경우
                                if(StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
                                    TD_ROWSPAN = "rowspan=\"3\" ";
                                    TD_STR = "계산서 발행 없음";
                                } else {
                                    TD_ROWSPAN = "";
                                    TD_STR = String.valueOf(mailMap.get("splpc"));
                                }
                                payArea.append(TD_RIGHT).append(TD_ROWSPAN).append(TBODY_TD_STYLE).append(GT_SIGN).append(TD_STR).append(TD_CLOSE).append(separator);

                            payArea.append(TR_CLOSE).append(separator);
                            payArea.append(TR_OPEN).append(separator);
                                payArea.append(TD_CENTER).append(TBODY_TD_STYLE).append(GT_SIGN).append("VAT").append(TD_CLOSE).append(separator);
                                // 증거금 주문이 아닐 경우
                                if(!StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
                                    payArea.append(TD_RIGHT).append(TBODY_TD_STYLE).append(GT_SIGN).append(String.valueOf(mailMap.get("vat"))).append(TD_CLOSE).append(separator);
                                }
                            payArea.append(TR_CLOSE).append(separator);
                            payArea.append(TR_OPEN).append(separator);
                                payArea.append(TD_CENTER).append(TBODY_TD_STYLE).append(GT_SIGN).append("결제 요청금액").append(TD_CLOSE).append(separator);
                                // 증거금 주문이 아닐 경우
                                if(!StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
                                    payArea.append(TD_RIGHT).append(TBODY_TD_STYLE).append(GT_SIGN).append(String.valueOf(mailMap.get("slepc"))).append(TD_CLOSE).append(separator);
                                }
                            payArea.append(TR_CLOSE).append(separator);

                            // 증거금 주문 또는 (전자상거래보증 or 케이지크레딧) 주문일 경우 결제 금액 및 결제 예정 금액 영역 추가
                            if( StringUtils.equals(orderModel.getPaymentMn(), "wrtm") || StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty") ) {
                                // 증거금 주문일 경우
                                if(StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
                                    // 결제 금액
                                    payArea.append(TR_OPEN).append(separator);
                                        payArea.append(TD_CENTER).append(TBODY_TD_STYLE).append(GT_SIGN).append("<strong>결제 금액</strong>").append(TD_CLOSE).append(separator);
                                        payArea.append(TD_CENTER).append(TBODY_TD_STYLE).append(GT_SIGN).append("결제금액(1차)").append(TD_CLOSE).append(separator);
                                        payArea.append(TD_RIGHT).append(TBODY_TD_STYLE).append(GT_SIGN).append(String.valueOf(mailMap.get("frstSetleAmount"))).append(TD_CLOSE).append(separator);
                                    payArea.append(TR_CLOSE).append(separator);
                                }
                                // 결제 예정 금액
                                payArea.append(TR_OPEN).append(separator);
                                    payArea.append("<td align=\"center\" rowspan=\"3\" ").append(TBODY_TD_STYLE).append(GT_SIGN).append("<strong>결제 예정 금액</strong>").append(TD_CLOSE).append(separator);
                                    payArea.append(TD_CENTER).append(TBODY_TD_STYLE).append(GT_SIGN).append("결제예정일").append(TD_CLOSE).append(separator);
                                    payArea.append(TD_RIGHT).append(TBODY_TD_STYLE).append(GT_SIGN).append(String.valueOf(mailMap.get("setlePrearngeDe"))).append(TD_CLOSE).append(separator);
                                payArea.append(TR_CLOSE).append(separator);
                                payArea.append(TR_OPEN).append(separator);
                                    payArea.append(TD_CENTER).append(TBODY_TD_STYLE).append(GT_SIGN).append("결제예정금액").append(TD_CLOSE).append(separator);
                                    payArea.append(TD_RIGHT).append(TBODY_TD_STYLE).append(GT_SIGN).append(String.valueOf(mailMap.get("unSetleAmount"))).append(TD_CLOSE).append(separator);
                                payArea.append(TR_CLOSE).append(separator);
                            }
                        payArea.append("</tbody>").append(separator);
                        // tbody end
                    payArea.append("</table>");
                    // table end

                    mailMap.put("payArea", payArea.toString()); // 결제정보 동적 영역

                    payArea = null; // StringBuilder 메모리 해제 유도

                    log.debug(">> mailMap : " + String.valueOf(mailMap));

                    int templateNo = mailVo.getMailTmptSeq(); //템플릿번호



                    String titleMsg = "";

                    if(templateNo == 15) {
                        titleMsg = "<span style=\"color: #1D5FD0;\">"+ String.valueOf(mailMap.get("sleMthdNm"))+ " 주문/결제가 완료</span>";
                        mailMap.put("titleMsg", titleMsg);
                        mailMap.put("sorinCreditTableInfo", "");

                        // 예외 발송 옵션 여부, N일 경우 메일 수신자, 웹마스터, 추가 담당자만 발송한다.
                        // 내부사용자만 타이틀을 달리 보내고 싶은 특수한 경우에 발송 여부를 조절하여 사용됨
                        mailVo.setExcpSndngOptnAt("N");

                        //주문 모달창 값이 케이지크레딧 일 때
                        if("mrtggGrnty".equals(orderModel.getPaymentMn()) && "02".equals(orderModel.getCdtlnSvcSeCode())) {

                            OrderInfoVO ovo = new OrderInfoVO();
                            ovo.setOrderNo(orderModel.getOrderNo());
                            ovo.setGrntyNo(orderModel.getGrntyNo());
                            ovo.setEntrpsNo(orderModel.getEntrpsNo());
                            List<OrderInfoVO> selectSorinCredtList = cdtlnMessageMapper.selectSorinCredtInfo(ovo); //케이지크레딧 거래정보를 가져온다.

                            if(selectSorinCredtList != null) {
                                //사용 가능액 가져오기
                                long totalMrtggBlce = Optional.ofNullable(cdtlnMessageMapper.selectTotalMrtggBlce(ovo)).orElse(0L);

                                // 케이지크레딧 테이블 정보 동적 출력
                                String sorinCreditTableInfo = cdtlnMessageService.getSorinCreditTableInfo(selectSorinCredtList, totalMrtggBlce);
                                mailMap.put("sorinCreditTableInfo", sorinCreditTableInfo);
                            }

                            // 1차 발송
                            mailService.insertMailSend(mailVo, mailMap);

                            // 2차 발송
                            titleMsg = "<span style=\"color: #1D5FD0;\">"+ String.valueOf(mailMap.get("sleMthdNm"))+ " 케이지크레딧 주문이 발생</span>";
                            mailMap.put("titleMsg", titleMsg);
                            // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
                            // 내부사용자만 타이틀을 달리 보내고 싶은 특수한 경우에 발송 여부를 조절하여 사용됨
                            mailVo.setExcpSndngOptnAt("Y");
                            mailService.insertMailSend(mailVo, mailMap);
                        } else {
                            // 케이지크레딧 이외 결제일 경우 메일 수신자, 웹마스터, 추가 담당자만 발송한다.
                            mailService.insertMailSend(mailVo, mailMap);
                        }
                    }
                }
            } catch (Exception e) {
                log.error("[OrderServiceImpl][callMail] " + ExceptionUtils.getStackTrace(e));
            }
        };
        taskExecutor.execute(mailRun);
        //}
    }

//  /**
//   * <pre>
//   * 처리내용: 앱푸쉬를 호출한다.
//   * </pre>
//   * @date 2021. 10. 25.
//   * @author srec0043
//   * @history
//   * ------------------------------------------------
//   * 변경일                  작성자             변경내용
//   * ------------------------------------------------
//   * 2021. 10. 25.            srec0043            최초작성
//   * ------------------------------------------------
//   * @param orderModel
//   */
//  private synchronized void callAppPush(OrderModel orderModel) {
//      log.debug("[OrderServiceImpl][callAppPush] IN");
//      Runnable appPushRun = () -> {
//          try {
//              AppPushQueueVO appPushQueueVO = new AppPushQueueVO();
//              appPushQueueVO.setMsgTitle("주문 완료"); // 메시지 제목, 여기서 넣는 것인지 모르겠지만 추가 20211221
//              Map<String, String> appPushMap = orderMapper.selectSmsInfo(orderModel);
//              appPushMap.put("templateNum", "15");
//              String identify = null;
//              //String type = null;
//              String url = null;
//              if(appPushMap != null && !appPushMap.isEmpty()) {
//                  identify = String.valueOf(appPushMap.get("identify"));
//                  //type = "1";
//                  url = orderModel.getDomain() + "/my/order/orderDtls";
//              }
//              appPushQueueVO.setIdentify(identify); // 운영_앱 설치 기본(OP_APP_INSTL_BAS)의 디바이스 ID(DEVICE_ID) [MBER_NO 조건으로 가져올 수 있다]
//              //appPushQueueVO.setType(type);
//              appPushQueueVO.setUrl(url);
//              appPushMap.put("commerceNtcnCn", "[케이지트레이딩] 고객님의 주문/결제가 완료되었습니다."); // 알림 메세지
//
//              smsService.insertAppPush(appPushQueueVO, appPushMap);
//          } catch (Exception e) {
//              log.error("[OrderServiceImpl][callAppPush] " + ExceptionUtils.getStackTrace(e));
//          }
//      };
//      taskExecutor.execute(appPushRun);
//  }

//  /**
//   * <pre>
//   * 처리내용: 카카오 알림톡을 호출한다.
//   * </pre>
//   * @date 2021. 10. 25.
//   * @author srec0043
//   * @history
//   * ------------------------------------------------
//   * 변경일                  작성자             변경내용
//   * ------------------------------------------------
//   * 2021. 10. 25.            srec0043            최초작성
//   * ------------------------------------------------
//   * @param orderModel
//   */
//  private synchronized void callKakao(OrderModel orderModel) {
//      log.debug("[OrderServiceImpl][callKakao] IN");
//      Runnable kakaoRun = () -> {
//          try {
//              smsService.insertKkoMsg(null, null);
//          } catch (Exception e) {
//              log.error("[OrderServiceImpl][callKakao] " + ExceptionUtils.getStackTrace(e));
//          }
//      };
//      taskExecutor.execute(kakaoRun);
//  }

    /**
     * <pre>
     * 처리내용: 템플릿에 따라 SMS 전송을 처리한다.
     * </pre>
     * @date 2022. 4. 21.
     * @author srec0049
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 4. 21.         srec0049            최초작성
     * ------------------------------------------------
     * @param orderModel
     * @param templateNum 템플릿번호
     * @param addStr 추가문자열
     */
    private void procSms(OrderModel orderModel, String templateNum, String addStr) {
        log.warn("[OrderServiceImpl][procSms] IN");

        try {
            SMSVO smsVO = new SMSVO();
            smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
            smsVO.setPhone(orderModel.getMbDlvrgBas().getMoblphonNo());

            // MB_MBER_INFO_BAS(회원_회원 정보 기본) - MOBLPHON_NO(휴대전화 번호) 복호화
            String phone = String.valueOf(smsVO.getPhone());
            if(StringUtils.isNotEmpty(phone) && !phone.equals("null")) {
                try {
                    log.debug("휴대전화 번호 복호화 전 ==================>" + phone);
                    phone = CryptoUtil.decryptAES256(phone);
                    log.debug("휴대전화 번호 복호화 후 ==================>" + phone);
                    /** 휴대전화 번호 셋팅 **/
                    smsVO.setPhone(phone);
                } catch(Exception e) {
                    log.error("OrderServiceImpl procSms MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
                }
            }

            smsVO.setMberNo(orderModel.getMbDlvrgBas().getMberNo());
//          smsVO.setPhone("테스트번호");
            smsVO.setCommerceNtcnAt("Y"); // 커머스 알림 여부, 20211116 추가

            Map<String, String> smsMap = null;

            switch(templateNum) {
                case "118" :
                    /** 주문완료(자차배송) */
                case "15" :
                    /** 주문완료(케이지배송) */
                    smsMap = orderMapper.selectSmsInfo(orderModel); // SMS 내용 정보 가져오기
                    // 주문정보 치환: 평균가 주문인 경우, 계약정보 추가 노출
                    smsMap.put("orderNo", commAvrgpcOrderService.getOrderInfoString(orderModel.getOrderNo(), orderModel.getCntrctOrderBasInfo().getCntrctOrderNo()));
                    // 결제정보 동적 영역
                    StringBuilder payArea = new StringBuilder();
                    payArea.append("결제방법 : ").append(String.valueOf(smsMap.get("payMethod"))).append(System.lineSeparator()); // 결제방법
                    payArea.append("결제단가 : ").append(String.valueOf(smsMap.get("goodsUntpc")));
                    payArea.append(StringUtils.equals(orderModel.getAvrgpcDcsnUntpcAt(), "N") || StringUtils.equals(orderModel.getSleMthdCode(), "05") ? "(가단가)": "").append(System.lineSeparator()); // 결제단가
                    payArea.append("주문금액 : ").append(String.valueOf(smsMap.get("payAmount"))).append(System.lineSeparator()); // 주문금액
                    if(StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
                        // 증거금 주문하기일 경우
                        payArea.append("결제금액(1차) : ").append(String.valueOf(smsMap.get("frstSetleAmount"))).append(System.lineSeparator()); // 결제금액(1차)
                        payArea.append("결제예정금액 : ").append(String.valueOf(smsMap.get("unSetleAmount"))).append(System.lineSeparator()); // 결제예정금액
                        payArea.append("결제예정일 : ").append(String.valueOf(smsMap.get("setlePrearngeDe"))).append(System.lineSeparator()); // 결제예정일
                    } else if(StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty")) {
                        // 전자상거래보증일 경우
                        payArea.append("결제예정금액 : ").append(String.valueOf(smsMap.get("unSetleAmount"))).append(System.lineSeparator()); // 결제예정금액
                        payArea.append("결제예정일 : ").append(String.valueOf(smsMap.get("setlePrearngeDe"))).append(System.lineSeparator()); // 결제예정일
                    }
                    smsMap.put("payArea", payArea.toString()); // 결제정보 동적 영역

                    payArea = null; // StringBuilder 메모리 해제 유도

                    if(StringUtils.equals(String.valueOf(smsMap.get("dlvyMnCode")), "02")) {
                        smsMap.put("dlvyMnGuidMsg", "출고일 전일 4시 전까지 차량입고일 미확정 및 차량정보 미입력시\r\n"
                                + "배송요청일자 출고 지연 및 배송이 불가할 수 있습니다.\r\n"
                                + "케이지트레이딩 마이페이지에서 차량과 기사정보를 반드시 입력 부탁드립니다."); // 자차배송 시 알림 메세지
                    } else {
                        smsMap.put("dlvyMnGuidMsg", "");
                    }
                    smsMap.put("vhcleURL", mfoDomain+"/vhcleInfoRegist/selectVhcleInfoRegist?orderNo="+orderModel.getOrderNo()); // 차량 정보 등록 URL
                    smsMap.put("commerceNtcnCn", "[케이지트레이딩] 고객님의 주문/결제가 완료되었습니다."); // 알림 메세지
                    break;
                case "44" :
                    smsMap = new HashMap<>();
                    smsMap.put("commerceNtcnCn", "물류(결제정보) 송신 실패"); // 알림 메세지
                    smsMap.put("orderNo", orderModel.getOrderNo()); // 주문번호
                    smsMap.put("returnMsg", addStr); // 주문 데이터 물류IF시 오류 발생
                    break;
                case "73" :
                    smsMap = new HashMap<>();
                    smsMap.put("commerceNtcnCn", "선물 취소 요청"); // 알림 메세지
                    smsMap.put("orderNo", orderModel.getOrderNo()); // 주문번호
                    smsMap.put("returnMsg", addStr); // 선물요청주문번호(복수)
                    break;
                case "77" :
                    smsMap = new HashMap<>();
                    smsMap.put("commerceNtcnCn", "주문 실패"); // 알림 메세지
                    smsMap.put("orderNo", orderModel.getOrderNo()); // 주문번호
                    smsMap.put("errMsg", addStr); // 실패 사유
                    break;
                default:
                    log.error("Not found templateNum");
                    break;
            }

            if(smsMap != null) {
                smsMap.put("templateNum", templateNum);

                // 주문 시에만 주문자에게 SMS전송한다.
                if(StringUtils.equals(templateNum, "15") || StringUtils.equals(templateNum, "118")) {
                    // OR_DLVRG_BAS(주문_배송지 기본) - RECEPT_ENTRPS_MOBLPHON_NO(수취 업체 휴대폰 번호) 복호화
                    String receptEntrpsMoblphonNo = String.valueOf(smsMap.get("hp"));
                    if(StringUtils.isNotEmpty(receptEntrpsMoblphonNo) && !receptEntrpsMoblphonNo.equals("null")) {
                        try {
                            log.debug("수취 업체 휴대폰 번호 복호화 전 ==================>" + receptEntrpsMoblphonNo);
                            receptEntrpsMoblphonNo = CryptoUtil.decryptAES256(receptEntrpsMoblphonNo);
                            log.debug("수취 업체 휴대폰 번호 복호화 후 ==================>" + receptEntrpsMoblphonNo);
                            /** 수취 업체 휴대폰 번호 셋팅 **/
                            smsMap.put("hp", receptEntrpsMoblphonNo);
                        } catch(Exception e) {
                            log.error("OrderServiceImpl procSms RECEPT_ENTRPS_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
                        }
                    }
                    log.debug(">> smsMap : " + String.valueOf(smsMap));
                    smsMap.put("excpSndngOptnAt", "N"); // 예외 발송 옵션 여부, N일 경우 SMS 수신자만 발송한다.
                    smsService.insertSMS(smsVO, smsMap);
                }

                // 내부사용자 별도 전송
                smsMap.put("commerceNtcnAt", "Y"); // 추가 수신사 커머스 알림 여부 따로 설정
                smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
                smsService.insertSMS(null, smsMap);
            }
        } catch (Exception e) {
            log.error("[OrderServiceImpl][procSms] " + ExceptionUtils.getStackTrace(e));
        }
    }

    /**
     * <pre>
     * 처리내용: SMS 서비스를 호출한다.
     * </pre>
     * @date 2021. 10. 25.
     * @author srec0043
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 10. 25.            srec0043            최초작성
     * ------------------------------------------------
     * @param orderModel
     */
    private synchronized void callSms(OrderModel orderModel) {
        log.warn("[OrderServiceImpl][callSms] IN");
        Runnable smsRun = () -> {
            // 템플릿에 따라 SMS 전송을 처리한다.

            String templateNum = ""; // 템플릿 번호
            // 배송수단코드에 따라 템플릿 번호를 결정 [케이지배송01: 15, 자차배송02: 118]
            switch(orderModel.getDlvyMnCode()) {
                case "01": templateNum = "15"; break;
                case "02": templateNum = "118"; break;
            }

            if(!StringUtils.isEmpty(templateNum)) {
                procSms(orderModel, templateNum, null);
            }
        };
        taskExecutor.execute(smsRun);
    }

//  /**
//   * <pre>
//   * 처리내용: 세금계산서를 호출한다. ( 신형철 주임 )
//   * </pre>
//   * @date 2021. 10. 25.
//   * @author srec0043
//   * @history
//   * ------------------------------------------------
//   * 변경일                  작성자             변경내용
//   * ------------------------------------------------
//   * 2021. 10. 25.            srec0043            최초작성
//   * ------------------------------------------------
//   * @param orderModel
//   */
//  private synchronized void callTaxBill(OrderModel orderModel) {
//      Runnable taxBillRun = () -> {
//          try {
//              Map<String, Object> paramVo = new HashMap<String, Object>();
//              paramVo.put("canclExchngRtngudNo", null);
//              paramVo.put("jobSe", "ORDER");
//              paramVo.put("orderNo", orderModel.getOrderNo());
//              httpClientHelper.postCallApi(orProperty.getTaxbillUrl(), paramVo);
//          } catch (Exception e) {
//              log.error("callTaxBill() error : " + e);
//          }
//      };
//      taskExecutor.execute(taxBillRun);
//  }

    /**
     * <pre>
     * 처리내용: 주문쪽 테이블변경 건에 대하여 히스트 테이블에 INSERT 한다.
     * </pre>
     * @date 2021. 10. 25.
     * @author srec0043
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 10. 25.            srec0043            최초작성
     * ------------------------------------------------
     * @param orderModel
     */
    private synchronized void instHistory(OrderModel orderModel) {
        log.warn("[OrderServiceImpl][instHistory] IN");
        Runnable historyRun = () -> {
            try {
                // 주문_주문 기본 이력 정보 등록하기
                orderMapper.insertOrOrderBasHst(orderModel);
                // 주문_주문 정보 기본 이력 정보 등록하기
                orderMapper.insertOrOrderInfoBasHst(orderModel);
                // 주문_주문 평균가 상세 이력 등록하기
                orderMapper.insertOrOrderAvrgpcDtlHst(orderModel);
                // 주문_주문 상세 이력 정보 등록하기
                orderMapper.insertOrOrderDtlHst(orderModel);
                // 주문_배송지 기본 이력 정보 등록하기
                orderMapper.insertOrDlvrgBasHst(orderModel);
                // 주문_배송비 기본 이력 정보 등록하기
                orderMapper.insertOrDlvrfBasHst(orderModel);
                // 결제 수단에 따른 히스토리 테이블 적재
                if(StringUtils.equals(orderModel.getPaymentMn(), "ewallet") || StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
                    // 이월렛, 증거금 - 주문_결제 기본
                    orderMapper.insertEwalletSetleHist(orderModel);
                } else if(StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty")) {
                    // (전자상거래보증 or 케이지크레딧) - 주문_담보 기본 이력 등록
                    orderMapper.insertMrtggBasHst(orderModel);
                }
                // 이벤트_쿠폰 이력 정보 등록하기
                if(orderModel.getCouponApplcAt().equals("Y")) {
                    for(CouponVO vo :  orderModel.getCouponList()) {
                        if (vo.getCouponTyCode().equals("03")) {
                            //배송비 쿠폰 테이블 이력
                            orderMapper.insertEvCouponIsuHst(vo);
                        } else if (vo.getCouponTyCode().equals("01")) {
                            //단가 쿠폰 테이블 이력
                            commonService.insertTableHistory("CP_COUPON_ISU_BAS", vo);
                        }
                    }
                }

                // 지정 BL 이력정보 등록하기 - 소량구매일 경우 제외
                if(!StringUtils.equals(orderModel.getSmlqyPurchsAt(), "Y") && StringUtil.isNotEmpty(orderModel.getReMainBlNo())) {
                    // 지정 BL 일때 지정한 [지정 BL 판매관리] 화면 의 내용을 삭제
                    // 톨로런스 범위 이하일때만 삭제 토록
                    BigDecimal bnt = Optional.ofNullable(orderModel.getBlDetail().getMatchedSleInvntryUnsleBnt()).orElse(BigDecimal.ZERO);//
                    BigDecimal bnt2 = new BigDecimal(orderModel.getSleUnitWt() * (100 - orderModel.getBlDetail().getCtrtcBeginPermWtRate()) / 100);

                    // 1.톨러런스 이하이거나
                    // OR
                    // 2. 재고 차감후 실제 번들이 0
                    // OR
                    // 3. 선물잔량이 0 (선물잔량이 차감 전일수 있음.)
                    // -> (0 == orderModel.getBlDetail().getRemainQy() - orderModel.getBlDetail().getMatchedOrderedBnt().intValue() / orderModel.getSamsungOrderWt())
                    if(bnt.compareTo(bnt2) < 0
                        || 0 == orderModel.getAfterSleInvntryUnsleBnt()
                        || 0 == orderModel.getBlDetail().getRemainQy()) {
                        //이력추가
                        orderMapper.insertMbEntrpsSpcifyBrandRlsHst(orderModel);
                    }
                }
            } catch (Exception e) {
                log.error("[OrderServiceImpl][instHistory] " + ExceptionUtils.getStackTrace(e));
            }
        };
        taskExecutor.execute(historyRun);
    }

    /**
     * 주문 실패 시 재고 원복 및 원장 테이블 수정을 진행한다.
     */
    @Override
    public void orderFail(OrderModel orderModel) {
        log.warn("[OrderServiceImpl][orderFail] IN");
        try {
            // 주문 마스터 수정
            log.warn("[OrderServiceImpl][orderFail] 주문 마스터 수정");
            orderModel.setOrderSttusCode("01");
            orderMapper.updateLastOrderMaster(orderModel); // 주문_주문 기본의 주문상태코드 및 주문완료일시, OMS접수 번호, 주문 실패 사유 등을 값에 따라 업데이트

            // 재고 원복: 평균가 주문인 경우 재고차감은 최종 성공 시점에 1번만 진행하므로, 원복 과정은 필요없음
            if(!StringUtils.equals(orderModel.getSleMthdCode(), "04") && StringUtils.isEmpty(orderModel.getSleMthdDetailCode()) && orderModel.getBlList() != null) {
                for(ItemPriceMatchingBlInfoVO bl : orderModel.getBlList()) {
                    if(bl.isInvntryUdt()) {
                        // 최초 로 원복 후 작업 재고 정리 시작
                        log.warn("[OrderServiceImpl][orderFail] 재고 원복");
                        orderModel.setBlDetail(bl);
                        orderMapper.updateRecoverInvntryBlInfoBas(orderModel);
                    }
                }
            }
        }catch (Exception e) {
            log.error("[OrderServiceImpl][orderFail] " + ExceptionUtils.getStackTrace(e));
        }
        // 히스토리 테이블 생성
        instHistory(orderModel);
    }

    /**
     * 주문 완료 정보를 조회한다<br>
     * 2023.05.18 지정가 고도화 추가
     */
    @Override
    public OrderLimitReceiptVO selectOrderReceipt(OrderModel orderModel) throws Exception {
        OrderLimitReceiptVO orderReceiptVO = null;
        String orderNo = orderModel.getOrderNo();
        Boolean isLimitOrder = false;

        // 지정가 주문 구분 여부
        if (orderNo.indexOf("L") > -1) {
            isLimitOrder = Boolean.TRUE;
        }

        if (Boolean.FALSE.equals(isLimitOrder)) {
            // 주문
            orderReceiptVO = Optional.ofNullable(orderMapper.selectOrderReceipt(orderModel)).orElseThrow(() -> {
                log.info("OrderServiceImpl selectOrderReceipt line-3536 vo.toString() >> " + orderModel.toString());
                return new CommCustomException("주문 정보 미존재");
                });

        } else {
            // 지정가 주문
            orderReceiptVO = Optional.ofNullable(orderMapper.selectLimitOrderReceipt(orderModel)).orElseThrow(() -> {
                log.info("OrderServiceImpl selectOrderReceipt line-3536 vo.toString() >> " + orderModel.toString());
                return new CommCustomException("지정가 주문 정보 미존재");
                });

            orderReceiptVO.setLimitOrderNo(orderNo);
        }

        // ORDRR_MOBLPHON_NO(주문자 휴대폰 번호) 복호화
        String ordrrMoblphonNo = orderReceiptVO.getOrdrrMoblphonNo();
        if (StringUtils.isNotEmpty(ordrrMoblphonNo)) {
            try {
                log.debug("주문자 휴대폰 번호 복호화 전 ==================>" + ordrrMoblphonNo);
                ordrrMoblphonNo = CryptoUtil.decryptAES256(ordrrMoblphonNo);
                log.debug("주문자 휴대폰 번호 복호화 후 ==================>" + ordrrMoblphonNo);
                /** 주문자 휴대폰 번호 셋팅 **/
                orderReceiptVO.setOrdrrMoblphonNo(ordrrMoblphonNo);
            } catch(Exception e) {
                log.error("OrderServiceImpl selectOrderReceipt ORDRR_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
            }
        }

        // RECEPT_ENTRPS_MOBLPHON_NO(수취 업체 휴대폰 번호) 복호화
        String receptEntrpsMoblphonNo = orderReceiptVO.getReceptEntrpsMoblphonNo();
        if (StringUtils.isNotEmpty(receptEntrpsMoblphonNo)) {
            try {
                log.debug("수취 업체 휴대폰 번호 복호화 전 ==================>" + receptEntrpsMoblphonNo);
                receptEntrpsMoblphonNo = CryptoUtil.decryptAES256(receptEntrpsMoblphonNo);
                log.debug("수취 업체 휴대폰 번호 복호화 후 ==================>" + receptEntrpsMoblphonNo);
                /** 수취 업체 휴대폰 번호 셋팅 **/
                orderReceiptVO.setReceptEntrpsMoblphonNo(receptEntrpsMoblphonNo);
            } catch(Exception e) {
                log.error("OrderServiceImpl selectOrderReceipt RECEPT_ENTRPS_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
            }
        }

        if (Boolean.FALSE.equals(isLimitOrder)) {
            // 배송창고번호로 물류창고정보기본T 조회 TODO: 지정가는 창고번호 없음
            orderReceiptVO.setDlivyWrhousList(orderMapper.selectOrderReceiptWrhous(orderModel));
            // 주문번호에 해당하는 BL번호 모두를 한줄로 가져온다 TODO: 지정가는 bl 번호 없음
            orderReceiptVO.setBlNos(orderMapper.selectBlNos(orderModel));
        }

        return orderReceiptVO;
    }

    /**
     * 이월렛 정보를 가저온다 ( EC DB 기준 )
     */
    @Override
    public OrderEtcPrice getEwalletInfo(OrderModel orderModel) throws Exception {
        OrderEtcPrice getEwalletInfo = orderMapper.getEwalletInfo(orderModel);

        if(getEwalletInfo != null) {
            // MB_ENTRPS_INFO_BAS(회원_업체 정보 기본) - EWALLET_ACNUT_NO(이월렛 계좌 번호) 복호화
            String acnutNo = getEwalletInfo.getEwalletAcnutNo();
            if(StringUtils.isNotEmpty(acnutNo)) {
                try {
                    log.debug("이월렛 계좌 번호 복호화 전 ==================>" + acnutNo);
                    acnutNo = CryptoUtil.decryptAES256(acnutNo);
                    log.debug("이월렛 계좌 번호 복호화 후 ==================>" + acnutNo);
                    /** 이월렛 계좌 번호 셋팅 **/
                    if(acnutNo.length() == 14) {
                        String fisrtAcnut = acnutNo.substring(0, 3);
                        String secondAcnut = acnutNo.substring(3, 9);
                        String thirdAcnut = acnutNo.substring(9, 14);
                        getEwalletInfo.setEwalletAcnutNo(fisrtAcnut + "-" + secondAcnut + "-" + thirdAcnut);
                    }
                } catch(Exception e) {
                    log.error("OrderServiceImpl getEwalletInfo EWALLET_ACNUT_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
                }
            }
        }

        return getEwalletInfo;
    }

    /**
     * 전자상거래보증 한도조회 가져오기
     *  MRTGG_GRNTY_LMT_STATUS(담보 보증 한도 상태)
     *   00 : 담보 보증 한도 설정 정상
     *   01 : 담보 보증 한도가 설정되어 있지 않음
     *   02 : 담보 보증 한도가 설정되어 있으나 계약정보가 없음
     *   99 : 기타 상황
     *   EMPTY : 업체 정보가 존재하지 않음
     */
    @Override
    public OrderEtcPrice getMrtggGrntyLmtInqire(OrderModel orderModel) throws Exception {
        OrderEtcPrice mrtggGrntyLmtInqire = orderMapper.getMrtggGrntyLmtInqire(orderModel);
        log.warn(">> mrtggGrntyLmtInqire 1 : " + String.valueOf(mrtggGrntyLmtInqire));
        if(mrtggGrntyLmtInqire == null) {
            mrtggGrntyLmtInqire = new OrderEtcPrice();
            mrtggGrntyLmtInqire.setMrtggGrntyLmtStatus("EMPTY"); // 업체 정보가 존재하지 않음
        } else {
            if(mrtggGrntyLmtInqire.getGrntyAmount() != null && mrtggGrntyLmtInqire.getMrtggBlce() != null) {
                mrtggGrntyLmtInqire.setMrtggGrntyLmtStatus("00"); // 담보 보증 한도 설정 정상
            } else {
                if(mrtggGrntyLmtInqire.getGrntyAmount() == null) {
                    mrtggGrntyLmtInqire.setMrtggGrntyLmtStatus("01"); // 담보 보증 한도가 설정되어 있지 않음
                } else {
                    if(mrtggGrntyLmtInqire.getMrtggBlce() == null) {
                        mrtggGrntyLmtInqire.setMrtggGrntyLmtStatus("02"); // 담보 보증 한도가 설정되어 있으나 계약정보가 없음
                    } else {
                        mrtggGrntyLmtInqire.setMrtggGrntyLmtStatus("99"); // 기타 상황
                    }
                }
            }
            mrtggGrntyLmtInqire.setGrntyAmount(Optional.ofNullable(mrtggGrntyLmtInqire.getGrntyAmount()).orElse("0")); // 보증 금액
            mrtggGrntyLmtInqire.setMrtggBlce(Optional.ofNullable(mrtggGrntyLmtInqire.getMrtggBlce()).orElse("0")); // 담보 잔액
        }
        log.warn(">> mrtggGrntyLmtInqire 2 : " + String.valueOf(mrtggGrntyLmtInqire));
        return mrtggGrntyLmtInqire;
    }

    /**
     * 업체 결제 수단 정보 가져오기
     * : 업체의 증거금과 (전자상거래보증 or 케이지크레딧) 사용 권한(증거금 총 사용 여부, (전자상거래보증 or 케이지크레딧) 총 사용 여부), 증거금 신청 여부(화면단 별도 체크), (전자상거래보증 or 케이지크레딧) 신청 여부(화면단 별도 체크), 연체 및 사고 건수
     * : 증거금 최소 결제 예정일 조건
     * : 판매 단위 중량 (주문 가능 MIN 중량 및 주문 단위), 1회 구매 중량 한도 (주문 가능 MAX 중량)
     * : 업체 별 평가 등급 정보(여신 구간, 담보 보증 허용 상환 기간)
     * : 업체 구매성향 등급정보(업체 구매성향등급, 업체 구매성향등급 명, 증거금 권한 비율)
     * : 구매성향등급에 따른 단계별 금액(LME 전일 종가[케이지몰일 경우 현재 단가], 구간 종료 금액, 구간 평균 금액)
     * : 업체의 선택 가능한 구매등급을 표시한 전체 정보 리스트
     * : 여신 정보(금리 정보, 패널티 정보)
     * : 담보 보증 보험 요율(마일리지에 사용)
     * : 보증 정보(보증 번호, 업체 담보 계약 순번, 담보 보증 수수료 부담 주체 여부, 보증 기한 시작 일자, 보증 기한 종료 일자)
     */
    @Override
    public OrderEntrpsSetleMnVO getEntrpsSetleMnInfo(String entrpsNo, String sleMthdCode, String metalCode, int itmSn, String dstrctLclsfCode, String brandGroupCode, String brandCode, String sleMthdDetailCode) throws Exception {
        // 업체의 증거금과 (전자상거래보증 or 케이지크레딧) 사용 권한(증거금 총 사용 여부, (전자상거래보증 or 케이지크레딧) 총 사용 여부), 증거금 신청 여부(화면단 별도 체크), (전자상거래보증 or 케이지크레딧) 신청 여부(화면단 별도 체크), 연체 및 사고 건수 가져오기
        // : 증거금 총 사용 여부(증거금 신청 여부, 증거금 사용 여부, 증거금 해지 여부 체크)
        // : (전자상거래보증 or 케이지크레딧) 총 사용 여부(담보 보증 신청 여부, 담보 보증 사용 여부, 담보 보증 승인 여부 , 담보 보증 해지 여부 체크)
        OrderEntrpsSetleMnVO entrpsSetleMnInfo = orderMapper.getWrtmMrtggUseAuthor(entrpsNo);
        if(StringUtils.equals("01", entrpsSetleMnInfo.getViewCdtlnSvcSeCode())) {
            entrpsSetleMnInfo.setCdtlnSvcSeKeyForCss("b2b"); // 여신 서비스 구분 css class keyword
        } else if(StringUtils.equals("02", entrpsSetleMnInfo.getViewCdtlnSvcSeCode())) {
            entrpsSetleMnInfo.setCdtlnSvcSeKeyForCss("scredit"); // 여신 서비스 구분 css class keyword
        }
        log.warn(">> 여신 서비스 구분 코드 (cdtlnSvcSeCode) : " + entrpsSetleMnInfo.getCdtlnSvcSeCode());
        log.warn(">> 여신 서비스 구분 코드(화면탭명용) (viewCdtlnSvcSeCode) : " + entrpsSetleMnInfo.getViewCdtlnSvcSeCode());
        log.warn(">> 여신 서비스 구분 명(화면탭명용) (viewCdtlnSvcSeNm) : " + entrpsSetleMnInfo.getViewCdtlnSvcSeNm());
        log.warn(">> 여신 서비스 구분 css class keyword (cdtlnSvcSeKeyForCss) : " + entrpsSetleMnInfo.getCdtlnSvcSeKeyForCss());

        // 증거금 최소 결제 예정일 조건
        CommonCodeVO getWrtmCommonCodeInfo = Optional.ofNullable(commonCodeService.getCodeValueRetVo("SETLE_MTHD_CODE", "90")).orElse(new CommonCodeVO());
        String getWrtmMummSetlePrarndeCnd = Optional.ofNullable(getWrtmCommonCodeInfo.getCodeRefrnone()).orElse("0");
        entrpsSetleMnInfo.setWrtmMummSetlePrarndeCnd(Integer.parseInt(getWrtmMummSetlePrarndeCnd));
        log.warn(">> 증거금 최소 결제 예정일 조건 (wrtmMummSetlePrarndeCnd) : " + entrpsSetleMnInfo.getWrtmMummSetlePrarndeCnd());

        ItemDtlInfoVO sleWtInfo = Optional.ofNullable(orderMapper.getSleWtInfo(itmSn)).orElse(new ItemDtlInfoVO());
        BigDecimal sleUnitWt = Optional.ofNullable(sleWtInfo.getSleUnitWt()).orElse(BigDecimal.ZERO); // 판매 단위 중량 (주문 가능 MIN 중량 및 주문 단위)
        entrpsSetleMnInfo.setSleUnitWt(sleUnitWt.intValue() / 1000); // 판매 단위 중량 (주문 가능 MIN 중량 및 주문 단위) kg -> MT로 변환
        log.warn(">> 판매 단위 중량 (sleUnitWt) : " + entrpsSetleMnInfo.getSleUnitWt());

        int oncePurchsWtLmt = -1; // 업체별 1회 구매 중량 한도 (주문 가능 MAX 중량), -1이면 데이터가 없는 경우, 0일때 무제한 설정이라 초기값 -1 필요
        int onedePurchsWtLmt = -1; // 업체별 1일 구매 중량 한도, -1이면 데이터가 없는 경우, 0일때 무제한 설정이라 초기값 -1 필요
        // 업체 등급 별 혜택을 리스트로 조회하여 반환한다
        List<EntrpsGradeVO> entrpsGradeBnefInfoList = entrpsGradeService.getEntrpsGradeBnefInfoList(entrpsNo);
        if(entrpsGradeBnefInfoList.size() > 0) {
            List<EntrpsGradeVO> entrpsGradeBnefInfoListByFilter = entrpsGradeBnefInfoList.stream().filter(data -> ( StringUtils.equals(data.getMetalCode(), metalCode) )).collect(Collectors.toList()); // 해당 메탈코드의 혜택 리스트를 가져온다
            if(entrpsGradeBnefInfoListByFilter.size() > 0) {
                EntrpsGradeVO entrpsGradeBnefInfo = entrpsGradeBnefInfoListByFilter.get(0); // 해당 메탈코드의 혜택을 가져온다
                oncePurchsWtLmt = entrpsGradeBnefInfo.getOncePurchsWtLmt(); // 1회 구매 중량 한도 (주문 가능 MAX 중량)
                onedePurchsWtLmt = entrpsGradeBnefInfo.getOnedePurchsWtLmt(); // 1일 구매 중량 한도
            }
        }

        // 케이지몰일 경우 1회 구매 중량 한도 대신 1회 판매 가능 중량을 쓴다.
        // 케이지몰 아연일 경우 라이브 아연이랑 설정이 분리되어 있지 않아서...
        if(StringUtils.equals("02", sleMthdCode)) {
            log.warn(">> 케이지몰 1회 구매 중량 한도 (oncePurchsWtLmt)에 1회 판매 가능 중량(onceSlePossWt) 세팅");
            BigDecimal onceSlePossWt = Optional.ofNullable(sleWtInfo.getOnceSlePossWt()).orElse(BigDecimal.ZERO); // 1회 판매 가능 중량
            entrpsSetleMnInfo.setOncePurchsWtLmt(onceSlePossWt.intValue() / 1000); // 1회 판매 가능 중량 kg -> MT로 변환
            log.warn(">> 케이지몰 1회 구매 중량 한도 (oncePurchsWtLmt)에 1회 판매 가능 중량(onceSlePossWt) 세팅한 값 : " + entrpsSetleMnInfo.getOncePurchsWtLmt());
        } else {
            log.warn(">> 라이브 1회 구매 중량 한도 (oncePurchsWtLmt) : " + oncePurchsWtLmt);
            entrpsSetleMnInfo.setOncePurchsWtLmt(oncePurchsWtLmt); // 1회 구매 중량 한도 (주문 가능 MAX 중량)
        }

        log.warn(">> 1일 구매 중량 한도 (onedePurchsWtLmt) : " + onedePurchsWtLmt);
        entrpsSetleMnInfo.setOnedePurchsWtLmt(onedePurchsWtLmt); // 1일 구매 중량 한도

        // 업체 별 평가 등급 정보를 VO로 조회하여 반환한다.
        EntrpsGradeVO entrpsEvlGradeInfo = Optional.ofNullable(entrpsGradeService.getEntrpsEvlGradeInfo(entrpsNo)).orElse(new EntrpsGradeVO());
        log.warn(">> 업체 별 평가 등급 정보 (entrpsEvlGradeInfo) : " + String.valueOf(entrpsEvlGradeInfo));
        entrpsSetleMnInfo.setCdtlnSctn(Optional.ofNullable(entrpsEvlGradeInfo.getCdtlnSctn()).orElse(0)); // 여신 구간
        entrpsSetleMnInfo.setMrtggGrntyPermBeginPd(Optional.ofNullable(entrpsEvlGradeInfo.getMrtggGrntyPermBeginPd()).orElse(0)); // 담보 보증 허용 시작 기간
        entrpsSetleMnInfo.setMrtggGrntyPermRepyPd(Optional.ofNullable(entrpsEvlGradeInfo.getMrtggGrntyPermRepyPd()).orElse(0)); // 담보 보증 허용 상환 기간

        // 업체 별 구매성향 등급정보를 조회하여 VO로 반환한다, 업체의 구매등급 정보
        EntrpsGradeVO entrpsPurchsInclnGradeInfo = Optional.ofNullable(entrpsGradeService.getEntrpsPurchsInclnGradeInfo(entrpsNo)).orElse(new EntrpsGradeVO());
        log.warn(">> 업체 별 구매성향 등급정보 (entrpsPurchsInclnGradeInfo) : " + String.valueOf(entrpsPurchsInclnGradeInfo));
        entrpsSetleMnInfo.setPurchsInclnGrad(entrpsPurchsInclnGradeInfo.getPurchsInclnGrad()); // 업체 구매성향등급
        entrpsSetleMnInfo.setPurchsInclnGradNm(entrpsPurchsInclnGradeInfo.getPurchsInclnGradNm()); // 업체 구매성향등급 명
        entrpsSetleMnInfo.setWrtmAuthorRateDcmlpoint(new BigDecimal(String.valueOf(entrpsPurchsInclnGradeInfo.getWrtmAuthorRateDcmlpoint())).multiply(BigDecimal.valueOf(100))); // 증거금 권한 비율

        // 구매성향등급 전체 정보를 조회하여 리스트로 반환한다.
        List<EntrpsGradeVO> tempEntrpsPurchsInclnGradeInfoAllList = entrpsGradeService.getEntrpsPurchsInclnGradeInfoAllList();
        tempEntrpsPurchsInclnGradeInfoAllList.stream().forEach(obj -> {
            log.warn(">> 구매성향등급 전체 정보 (tempEntrpsPurchsInclnGradeInfoAllList) : " + String.valueOf(obj));
        });

        // 구매성향등급에 따른 단계별 금액 가져오기(LME 전일 종가[케이지몰일 경우 현재 단가] 포함)
        OrderItWrtmStdrAmoutMangeVO stepAmountByPurchsInclnGrade = this.getStepAmountByPurchsInclnGrade(sleMthdCode, metalCode, itmSn, dstrctLclsfCode, brandGroupCode, brandCode, entrpsNo);
        entrpsSetleMnInfo.setEndPcAgo(Math.round(Optional.ofNullable(stepAmountByPurchsInclnGrade.getEndPcAgo()).orElse(0f))); // LME 전일 종가[케이지몰일 경우 현재 단가]
        entrpsSetleMnInfo.setSctnBeginAmount(Optional.ofNullable(stepAmountByPurchsInclnGrade.getSctnBeginAmount()).orElse(BigDecimal.ZERO).intValue()); // 구간 시작 금액
        entrpsSetleMnInfo.setSctnEndAmount(Optional.ofNullable(stepAmountByPurchsInclnGrade.getSctnEndAmount()).orElse(BigDecimal.ZERO).intValue()); // 구간 종료 금액
        entrpsSetleMnInfo.setSctnAvrgAmount(Optional.ofNullable(stepAmountByPurchsInclnGrade.getSctnAvrgAmount()).orElse(BigDecimal.ZERO).intValue()); // 구간 평균 금액

        // 업체의 선택 가능한 구매등급을 표시한 전체 정보 리스트로 새로 만든다.
        List<OrderPurchsInclnGradeVO> entrpsPurchsInclnGradeInfoAllList = new ArrayList<OrderPurchsInclnGradeVO>();

        for(int i=0; i<tempEntrpsPurchsInclnGradeInfoAllList.size(); i++) {
            EntrpsGradeVO entrpsGradeVO = tempEntrpsPurchsInclnGradeInfoAllList.get(i);

            OrderPurchsInclnGradeVO orderPurchsInclnGradeVO = new OrderPurchsInclnGradeVO();

            orderPurchsInclnGradeVO.setPurchsInclnGrad(entrpsGradeVO.getPurchsInclnGrad()); // 구매성향등급
            orderPurchsInclnGradeVO.setPurchsInclnGradNm(entrpsGradeVO.getPurchsInclnGradNm()); // 구매성향등급 명
            orderPurchsInclnGradeVO.setWrtmAuthorRateDcmlpoint(new BigDecimal(String.valueOf(entrpsGradeVO.getWrtmAuthorRateDcmlpoint())).multiply(BigDecimal.valueOf(100))); // 증거금 권한 비율
            // 선택 가능한 구매등급 표시
            if(entrpsGradeVO.getWrtmAuthorRate() < entrpsPurchsInclnGradeInfo.getWrtmAuthorRate()) {
                orderPurchsInclnGradeVO.setSelectableAt("N"); // 선택 불가
            } else {
                orderPurchsInclnGradeVO.setSelectableAt("Y"); // 선택 가능
            }

            // 단계와 헷갈리지 않게 일치시켜서 보기위해 +1 시킴
            switch(i+1) {
            case 1:
                orderPurchsInclnGradeVO.setBeginStepRate(Optional.ofNullable(stepAmountByPurchsInclnGrade.getBegin1StepRate()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 1단계 범위 시작 비율
                orderPurchsInclnGradeVO.setEndStepRate(Optional.ofNullable(stepAmountByPurchsInclnGrade.getEnd1StepRate()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 1단계 범위 종료 비율
                orderPurchsInclnGradeVO.setPurchsInclnStepRate(Optional.ofNullable(stepAmountByPurchsInclnGrade.getPurchsIncln1StepRate()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 1단계 비율
                orderPurchsInclnGradeVO.setPurchsInclnStepAmount(Optional.ofNullable(stepAmountByPurchsInclnGrade.getPurchsIncln1StepAmount()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 1단계 금액
                break;
            case 2:
                orderPurchsInclnGradeVO.setBeginStepRate(Optional.ofNullable(stepAmountByPurchsInclnGrade.getBegin2StepRate()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 2단계 범위 시작 비율
                orderPurchsInclnGradeVO.setEndStepRate(Optional.ofNullable(stepAmountByPurchsInclnGrade.getEnd2StepRate()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 2단계 범위 종료 비율
                orderPurchsInclnGradeVO.setPurchsInclnStepRate(Optional.ofNullable(stepAmountByPurchsInclnGrade.getPurchsIncln2StepRate()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 2단계 비율
                orderPurchsInclnGradeVO.setPurchsInclnStepAmount(Optional.ofNullable(stepAmountByPurchsInclnGrade.getPurchsIncln2StepAmount()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 2단계 금액
                break;
            case 3:
                orderPurchsInclnGradeVO.setBeginStepRate(Optional.ofNullable(stepAmountByPurchsInclnGrade.getBegin3StepRate()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 3단계 범위 시작 비율
                orderPurchsInclnGradeVO.setEndStepRate(Optional.ofNullable(stepAmountByPurchsInclnGrade.getEnd3StepRate()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 3단계 범위 종료 비율
                orderPurchsInclnGradeVO.setPurchsInclnStepRate(Optional.ofNullable(stepAmountByPurchsInclnGrade.getPurchsIncln3StepRate()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 3단계 비율
                orderPurchsInclnGradeVO.setPurchsInclnStepAmount(Optional.ofNullable(stepAmountByPurchsInclnGrade.getPurchsIncln3StepAmount()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 3단계 금액
                break;
            case 4:
                orderPurchsInclnGradeVO.setBeginStepRate(Optional.ofNullable(stepAmountByPurchsInclnGrade.getBegin4StepRate()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 4단계 범위 시작 비율
                orderPurchsInclnGradeVO.setEndStepRate(Optional.ofNullable(stepAmountByPurchsInclnGrade.getEnd4StepRate()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 4단계 범위 종료 비율
                orderPurchsInclnGradeVO.setPurchsInclnStepRate(Optional.ofNullable(stepAmountByPurchsInclnGrade.getPurchsIncln4StepRate()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 4단계 비율
                orderPurchsInclnGradeVO.setPurchsInclnStepAmount(Optional.ofNullable(stepAmountByPurchsInclnGrade.getPurchsIncln4StepAmount()).orElse(BigDecimal.ZERO).intValue()); // 구매 성향 4단계 금액
                break;
            default : break;
            }

            // E0? 안정형? 100%?? 존재하는게 맞는지???? 일단 제거함 20220721
            if( !StringUtils.equals(orderPurchsInclnGradeVO.getPurchsInclnGrad(), "E0") ) {
                entrpsPurchsInclnGradeInfoAllList.add(orderPurchsInclnGradeVO);
            }
        }

        entrpsPurchsInclnGradeInfoAllList.stream().forEach(obj -> {
            log.warn(">> 최종 구매성향등급 전체 정보 리스트 (entrpsPurchsInclnGradeInfoAllList) : " + String.valueOf(obj));
        });

        entrpsSetleMnInfo.setEntrpsPurchsInclnGradeInfoAllList(entrpsPurchsInclnGradeInfoAllList); // 구매성향등급 전체 정보 리스트 set

        // 여신 정보(금리 정보, 패널티 정보, 여신 증권 발급 수수료 정보) 가져오기
        //     여신 금리 정보(CD금리, 케이지트레이딩 가산금리, 연간뱅킹데이, CD 금리 사용 여부, 담보보증 무이자 일수)
        //         CD금리는 CD 금리 사용 여부에 따라 미사용(N)일 경우 0으로 반환한다
        //     여신 패널티 정보(여신관리 패널티 연체 건수, 여신관리 패널티 사고 건수)
        //     여신 증권 발급 수수료 정보(전자상거래보증 증권발급 수수료 보상 비율, 전자상거래보증 증권발급 수수료 보상 건당 인정 비율)
        // CD금리, 케이지트레이딩 가산금리, 연간뱅킹데이는 값이 0이 아닌 최근 적용일자의 데이터로 가져온다, 그래도 값이 없으면 0
        // 여신관리 패널티 연체 건수, 여신관리 패널티 사고 건수, 전자상거래보증 증권발급 수수료 보상 비율, 전자상거래보증 증권발급 수수료 보상 건당 인정 비율는 값이 없으면 0
        // CD금리, 케이지트레이딩 가산금리는 0값 허용, 연간뱅킹데이는 0인 경우를 체크해야한다.
        CredtCdtlnInfoVO cdtlnInrstInfo = this.getCredtCdtlnInfo();

        entrpsSetleMnInfo.setCdtlnManagePntArrrgCo(cdtlnInrstInfo.getCdtlnManagePntArrrgCo()); // 여신관리 패널티 연체 건수
        entrpsSetleMnInfo.setCdtlnManagePntAcdntCo(cdtlnInrstInfo.getCdtlnManagePntAcdntCo()); // 여신관리 패널티 사고 건수
        entrpsSetleMnInfo.setCdInrst(cdtlnInrstInfo.getCdInrst()); // CD금리
        entrpsSetleMnInfo.setCdInrstUseAt(cdtlnInrstInfo.getCdInrstUseAt()); // CD 금리 사용 여부

        // 임시 하드코딩 (20230131, 특정 업체(C0277[삼보산업(주)])만 무이자 없음)
        // 20240124: C0254[린노알미늄(주)] => 15일(무이자)/30일/45일
        // 참조 : 수정시 commOrderService 같이 수정 필수
        if(StringUtils.equals("C0277", entrpsNo)) {
            entrpsSetleMnInfo.setMrtggGrntyNintrDaycnt(0); // 담보보증 무이자 일수 0
        } else if(StringUtils.equals("C0254", entrpsNo)) {
        	entrpsSetleMnInfo.setMrtggGrntyNintrDaycnt(15); // 담보보증 무이자 일수 15
        } else {
            entrpsSetleMnInfo.setMrtggGrntyNintrDaycnt(cdtlnInrstInfo.getMrtggGrntyNintrDaycnt()); // 담보보증 무이자 일수
        }

        entrpsSetleMnInfo.setMrtggGrntySorinsuprrAddiInrst(cdtlnInrstInfo.getMrtggGrntySorinsuprrAddiInrst()); // 케이지트레이딩 가산금리
        entrpsSetleMnInfo.setTotCdtlnInrstPt(cdtlnInrstInfo.getCdInrst().add(cdtlnInrstInfo.getMrtggGrntySorinsuprrAddiInrst()).multiply(BigDecimal.valueOf(100)).stripTrailingZeros()); // 총 여신 금리 퍼센트
        entrpsSetleMnInfo.setMrtggGrntyFyerBankingDaycnt(cdtlnInrstInfo.getMrtggGrntyFyerBankingDaycnt()); // 연간뱅킹데이
        entrpsSetleMnInfo.setMrtgggrntyScritsissuFeeCmpnstnRate(cdtlnInrstInfo.getMrtgggrntyScritsissuFeeCmpnstnRate()); // 전자상거래보증 증권발급 수수료 보상 비율
        entrpsSetleMnInfo.setMrtgggrntyScritsissuFeeCmpnstnCsbyRate(cdtlnInrstInfo.getMrtgggrntyScritsissuFeeCmpnstnCsbyRate()); // 전자상거래보증 증권발급 수수료 보상 건당 인정 비율

        // 담보 보증 보험 요율 가져오기
        entrpsSetleMnInfo.setMrtggGrntyInsrncTariffDcmlpoint(Optional.ofNullable(orderMapper.getMrtggGrntyInsrncTariffDcmlpoint(entrpsNo)).orElse(BigDecimal.ZERO));

        // 처리내용: 보증 정보 가져오기
        // (보증 번호, 업체 담보 계약 순번, 담보 보증 수수료 부담 주체 여부, 보증 기한 시작 일자, 보증 기한 종료 일자)
        OrGrntyInfoVO getGrntyInfo = this.getGrntyInfo(entrpsNo, entrpsSetleMnInfo.getCdtlnSvcSeCode());
        entrpsSetleMnInfo.setGrntyNo(getGrntyInfo.getGrntyNo()); // 보증 번호
        entrpsSetleMnInfo.setEntrpsMrtggCntrctSn(getGrntyInfo.getEntrpsMrtggCntrctSn()); // 업체 담보 계약 순번
        entrpsSetleMnInfo.setMrtggGrntyFeeBndMbyAt(getGrntyInfo.getMrtggGrntyFeeBndMbyAt()); // 담보 보증 수수료 부담 주체 여부
        entrpsSetleMnInfo.setGrntyTmlmtBeginDe(getGrntyInfo.getGrntyTmlmtBeginDe()); // 보증 기한 시작 일자
        entrpsSetleMnInfo.setGrntyTmlmtEndDe(getGrntyInfo.getGrntyTmlmtEndDe()); // 보증 기한 종료 일자

        // 주문_여신 기본 테이블의 여신 계약 번호를 가져온다. (케이지크레딧에서 사용), 보증 번호 조건 필요
        String cdtlnCntrctNo = Optional.ofNullable(orderMapper.getCdtlnCntrctNo(getGrntyInfo.getGrntyNo())).orElse("");
        entrpsSetleMnInfo.setCdtlnCntrctNo(cdtlnCntrctNo); // 여신 계약 번호

        String sorinCredtUseAt = Optional.ofNullable(orderMapper.getSorinCredtUseAt(cdtlnCntrctNo)).orElse("N"); // 케이지크레딧 사용 여부(SORIN CREDIT ON/OFF)
        entrpsSetleMnInfo.setSorinCredtUseAt(sorinCredtUseAt); // 케이지크레딧 사용 여부(SORIN CREDIT ON/OFF)

        // 평균가 거래 금액 비율 코드, 세금 계산서 발행 시점 코드 가져오기
        if(StringUtils.equals(sleMthdCode, "04")) {
            OrderEntrpsSetleMnVO avrgpcDelngAmountTaxbillInfo = orderMapper.getAvrgpcDelngAmountRateCode(entrpsNo);
            if(StringUtils.isEmpty(avrgpcDelngAmountTaxbillInfo.getAvrgpcDelngAmountRateCode()) || StringUtils.isEmpty(avrgpcDelngAmountTaxbillInfo.getAvrgpcTaxBillIsuPnttmCode())) {
                throw new CommCustomException("해당 업체의 계약 관리 설정 값이 존재하지 않습니다,\n관리자에게 문의 바랍니다.");
            }

            // 데이터 세팅
            entrpsSetleMnInfo.setAvrgpcDelngAmountRateCode(avrgpcDelngAmountTaxbillInfo.getAvrgpcDelngAmountRateCode()); // 평균가 거래 금액 비율 코드
            double avrgpcDelngAmountRate = Integer.parseInt(commonCodeService.getCodeValueRetVo("AVRGPC_DELNG_AMOUNT_RATE_CODE",
                                                            entrpsSetleMnInfo.getAvrgpcDelngAmountRateCode()).getCodeNm().replace("%", "")) / 100.0;
            entrpsSetleMnInfo.setAvrgpcDelngAmountRate(avrgpcDelngAmountRate);                                           // 평균가 거래 금액 비율
            entrpsSetleMnInfo.setAvrgpcTaxBillIsuPnttmCode(avrgpcDelngAmountTaxbillInfo.getAvrgpcTaxBillIsuPnttmCode()); // 평균가 세금 계산서 발행 시점 코드
        }

        log.warn(">> 업체 결제 수단 정보 가져오기(entrpsSetleMnInfo) : " + String.valueOf(entrpsSetleMnInfo));

        return entrpsSetleMnInfo;
    }


    /**
     * <pre>
     * 처리내용: 구매성향등급에 따른 단계별 금액 가져오기(LME 전일 종가[케이지몰일 경우 현재 단가] 포함)
     * </pre>
     * @date 2023. 3. 14.
     * @author srec0049
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 3. 14.         srec0049            최초작성
     * ------------------------------------------------
     * @param sleMthdCode
     * @param metalCode
     * @param itmSn
     * @param dstrctLclsfCode
     * @param brandGroupCode
     * @param brandCode
     * @param entrpsNo
     * @return
     * @throws Exception
     */
    public OrderItWrtmStdrAmoutMangeVO getStepAmountByPurchsInclnGrade(String sleMthdCode, String metalCode, int itmSn
            , String dstrctLclsfCode, String brandGroupCode, String brandCode, String entrpsNo) throws Exception {

        float endPcAgo = this.getEndPcAgo(sleMthdCode, metalCode, itmSn, dstrctLclsfCode, brandGroupCode, brandCode, entrpsNo); // LME 전일 종가[케이지몰일 경우 현재 단가] 가져오기

        OrderItWrtmStdrAmoutMangeVO stepAmountByPurchsInclnGrade = Optional.ofNullable(orderMapper.getStepAmountByPurchsInclnGrade(metalCode, endPcAgo)).orElse(new OrderItWrtmStdrAmoutMangeVO()); // 구매성향등급에 따른 단계별 금액 가져오기
        log.warn(">> [getStepAmountByPurchsInclnGrade] stepAmountByPurchsInclnGrade : " + String.valueOf(stepAmountByPurchsInclnGrade));

        return stepAmountByPurchsInclnGrade;
    }


    /**
     * <pre>
     * 처리내용: LME 전일 종가[케이지몰일 경우 현재 단가] 가져오기
     * </pre>
     * @date 2023. 3. 14.
     * @author srec0049
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 3. 14.         srec0049            최초작성
     * ------------------------------------------------
     * @param sleMthdCode
     * @param metalCode
     * @param itmSn
     * @param dstrctLclsfCode
     * @param brandGroupCode
     * @param brandCode
     * @param entrpsNo
     * @return
     * @throws Exception
     */
    public float getEndPcAgo(String sleMthdCode, String metalCode, int itmSn, String dstrctLclsfCode, String brandGroupCode, String brandCode, String entrpsNo) throws Exception {
        log.warn(">> [getEndPcAgo] param >> metalCode : " + metalCode + ", sleMthdCode : " + sleMthdCode + ", itmSn : " + itmSn
                 + ", dstrctLclsfCode : " + dstrctLclsfCode + ", brandGroupCode : " + brandGroupCode + ", brandCode : " + brandCode + ", entrpsNo : " + entrpsNo);

        // LME 전일 종가[케이지몰일 경우 현재 단가] 가져오기
        float endPcAgo = 0f;
        if(StringUtils.equals("02", sleMthdCode)) {
            // 케이지몰일 경우 현재 단가 가져오기
            FixPriceVO hasEntrpsFixPriceData = pcInfoService.hasEntrpsFixPriceData(metalCode, itmSn, dstrctLclsfCode, brandGroupCode, brandCode, entrpsNo, DateUtil.getNowDateTime("yyyyMM"));
            BigDecimal slePc = Optional.ofNullable(hasEntrpsFixPriceData.getSlePc()).orElse(BigDecimal.ZERO);
            endPcAgo = slePc.floatValue(); // 케이지몰일 경우 현재 단가를 전일 종가에 세팅
        } else {
            // LME 전일 종가 가져오기
            endPcAgo = Float.parseFloat(Optional.ofNullable(orderMapper.getPreEndPc(metalCode, sleMthdCode)).orElse("0"));
        }

        log.warn("[OrderServiceImpl][getEndPcAgo] 전일 종가(endPcAgo), 케이지몰일 경우 현재 단가를 전일 종가에 세팅 : " + endPcAgo);

        return endPcAgo;
    }

    /**
     * 케이지트레이딩 직인 정보를 가저온다.
     */
    @Override
    public void getSorinSign(HttpServletResponse response) throws Exception {
        byte[] signByte = (byte[]) orderMapper.selectSorinSign();
        response.setContentType("image/jpeg");
        response.setContentLength(signByte.length);
        response.getOutputStream().write(signByte);
        response.getOutputStream().flush();
        response.getOutputStream().close();
    }


    /**
     * 이벤트 휴일 관리 기반 기준일에 영업 일자 만큼 계산된 날짜 리턴(기준일 포함), 리턴 대상 날짜가 휴일이면 그 다음 날짜를 리턴한다.
     */
    @Override
    public String getSettleSttusDe(SettleSttusDeVO settleSttusDeVO) throws Exception {
        String settleSttusDe = orderMapper.getSettleSttusDe(settleSttusDeVO);
        return settleSttusDe;
    }

    /**
     * <pre>
     * 처리내용: 여신 정보(금리 정보, 패널티 정보, 여신 증권 발급 수수료 정보) 가져오기
     *     여신 금리 정보(CD금리, 케이지트레이딩 가산금리, 연간뱅킹데이, CD 금리 사용 여부, 담보보증 무이자 일수)
     *         CD금리는 CD 금리 사용 여부에 따라 미사용(N)일 경우 0으로 반환한다
     *     여신 패널티 정보(여신관리 패널티 연체 건수, 여신관리 패널티 사고 건수)
     *     여신 증권 발급 수수료 정보(전자상거래보증 증권발급 수수료 보상 비율, 전자상거래보증 증권발급 수수료 보상 건당 인정 비율)
     * CD금리, 케이지트레이딩 가산금리, 연간뱅킹데이는 값이 0이 아닌 최근 적용일자의 데이터로 가져온다, 그래도 값이 없으면 0
     * 여신관리 패널티 연체 건수, 여신관리 패널티 사고 건수, 전자상거래보증 증권발급 수수료 보상 비율, 전자상거래보증 증권발급 수수료 보상 건당 인정 비율는 값이 없으면 0
     * CD금리, 케이지트레이딩 가산금리는 0값 허용, 연간뱅킹데이는 0인 경우를 체크해야한다.
     * </pre>
     * @date 2022. 11. 23.
     * @author srec0049
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 11. 23.            srec0049            최초작성
     * ------------------------------------------------
     * @return
     * @throws Exception
     */
    public CredtCdtlnInfoVO getCredtCdtlnInfo() throws Exception {
        // 여신 정보(금리 정보, 패널티 정보, 여신 증권 발급 수수료 정보) 가져오기
        //     여신 금리 정보(CD금리, 케이지트레이딩 가산금리, 연간뱅킹데이, CD 금리 사용 여부, 담보보증 무이자 일수)
        //         CD금리는 CD 금리 사용 여부에 따라 미사용(N)일 경우 0으로 반환한다
        //     여신 패널티 정보(여신관리 패널티 연체 건수, 여신관리 패널티 사고 건수)
        //     여신 증권 발급 수수료 정보(전자상거래보증 증권발급 수수료 보상 비율, 전자상거래보증 증권발급 수수료 보상 건당 인정 비율)
        CredtCdtlnInfoVO credtCdtlnInfo = Optional.ofNullable(orderMapper.getCdtlnInrstInfo()).orElse(new CredtCdtlnInfoVO());
        credtCdtlnInfo.setCdInrst(Optional.ofNullable(credtCdtlnInfo.getIntRateSell()).orElse(BigDecimal.ZERO)); // CD금리, 값이 없으면 0으로 리턴

        log.warn("[getCdtlnInrstInfo] credtCdtlnInfo : " + String.valueOf(credtCdtlnInfo));

        return credtCdtlnInfo;
    }

    /**
     * <pre>
     * 처리내용: 보증 정보 가져오기
     * (보증 번호, 업체 담보 계약 순번, 담보 보증 수수료 부담 주체 여부, 보증 기한 시작 일자, 보증 기한 종료 일자)
     * </pre>
     * @date 2022. 11. 23.
     * @author srec0049
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 11. 23.            srec0049            최초작성
     * ------------------------------------------------
     * @param entrpsNo
     * @param cdtlnSvcSeCode
     * @return
     * @throws Exception
     */
    public OrGrntyInfoVO getGrntyInfo(String entrpsNo, String cdtlnSvcSeCode) throws Exception {

        // 보증 정보 가져오기
        // (보증 번호, 업체 담보 계약 순번, 담보 보증 수수료 부담 주체 여부, 보증 기한 시작 일자, 보증 기한 종료 일자)
        OrGrntyInfoVO grntyInfo = Optional.ofNullable(orderMapper.getGrntyInfo(entrpsNo, cdtlnSvcSeCode)).orElse(new OrGrntyInfoVO());

        log.warn("[getGrntyInfo] grntyInfo : " + String.valueOf(grntyInfo));

        return grntyInfo;
    }

    /**
     * 권역 대분류별 아이템별 업체별 케이지몰 주문 가능 중량을 체크하여 주문 가능 여부와 총 실제 주문 중량을 반환한다[Y : 주문 가능, N : 주문 불가능]
     */
    @Override
    public FixingPcOrderPossWtCeckVO getFixingPcOrderPossWtCeckInfo(String dstrctLclsfCode, int itmSn, String entrpsNo, String sorinmallUnitPdCode
            , String lmttWtStr, int orderWt, String sleMthdCode) throws Exception {

        double lmttWt = 0d;
        String orderPossYn = "Y";
        // 제한 중량 null이면 무제한
        if(lmttWtStr == null) {
            orderPossYn = "Y";
        } else {
            if(StringUtils.isEmpty(lmttWtStr)) {
                orderPossYn = "N";
            } else {
                // 0일 경우 주문 불가
                lmttWt = Double.parseDouble(lmttWtStr);
                if(lmttWt == 0d) orderPossYn = "N";
            }
        }
        log.warn(">> getFixingPcOrderPossWtCeckInfo orderPossYn : " + orderPossYn);

        FixingPcOrderPossWtCeckVO fixingPcOrderPossWtCeck = new FixingPcOrderPossWtCeckVO();
        if(lmttWtStr == null && StringUtils.equals("Y", orderPossYn)) {
            fixingPcOrderPossWtCeck.setOrderPossYn(orderPossYn);
        } else {
            if(StringUtils.equals("N", orderPossYn)) {
                fixingPcOrderPossWtCeck.setOrderPossYn(orderPossYn);
                fixingPcOrderPossWtCeck.setTotRealOrderWt(-1); // 제한 중량이 빈 값 이거나 0이면 총 주문중량 값을 -1로 세팅한다.
            } else {
                fixingPcOrderPossWtCeck = Optional.ofNullable(
                        orderMapper.getFixingPcOrderPossWtCeckInfo(
                                FixingPcOrderPossWtCeckVO.builder()
                                    .dstrctLclsfCode(dstrctLclsfCode)
                                    .itmSn(itmSn)
                                    .entrpsNo(entrpsNo)
                                    .sorinmallUnitPdCode(sorinmallUnitPdCode)
                                    .lmttWt(lmttWt)
                                    .orderWt(orderWt)
                                    .sleMthdCode(sleMthdCode)
                                    .build()
                        )
                ).orElse(new FixingPcOrderPossWtCeckVO());
            }
        }

        return fixingPcOrderPossWtCeck;
    }


    /**
     * 권역 대분류별 아이템별 업체별 케이지몰 주문 가능 중량을 체크하여 가능 여부를 Y, N 값으로 반환한다[Y : 주문 가능, N : 주문 불가능]
     */
    @Override
    public String getFixingPcOrderPossWtCeck(String dstrctLclsfCode, int itmSn, String entrpsNo, String sorinmallUnitPdCode
            , String lmttWtStr, int orderWt, String sleMthdCode) throws Exception {

        FixingPcOrderPossWtCeckVO fixingPcOrderPossWtCeckInfo = this.getFixingPcOrderPossWtCeckInfo(dstrctLclsfCode, itmSn
                , entrpsNo, sorinmallUnitPdCode, lmttWtStr, orderWt, sleMthdCode);

        return Optional.ofNullable(fixingPcOrderPossWtCeckInfo.getOrderPossYn()).orElse("Y");
    }

    /**
     * <pre>
     * 처리내용: 지정가 주문 체결(부분체결) 처리
     *  1) 지정가 가격 도달 시 진행되는 주문일 경우에만 처리
     * </pre>
     * @date 2023. 5. 17.
     * @author srec0049
     * @history
     * ------------------------------------------------
     * 변경일                 작성자          변경내용
     * ------------------------------------------------
     * 2023. 5. 17.          srec0049         최초작성
     * ------------------------------------------------
     * @param orderModel
     * @throws Exception
     */
    public void procLimitOrderCncls(OrderModel orderModel) throws Exception {
        // 지정가 가격 도달 시 진행되는 주문일 경우, 20230517
        if(StringUtils.equals("touch", orderModel.getLimitSection())) {
            String limitOrderSttusCode = "30"; // 체결
            // 재고 부분 체결 여부가 Y일 경우
            if(StringUtils.equals("Y", orderModel.getInvntryPartCnclsAt())) {
                limitOrderSttusCode = "31"; // 부분 체결
            }
            // DB, 지정가 주문 상태 코드[체결(30), 부분 체결(31)] 변경
            commLimitOrderService.updateCommLimitOrderSttusCode(orderModel.getLimitOrderNo(), limitOrderSttusCode, null, orderModel.getMberId(), orderModel.getOrderNo(), orderModel.getOrderWt());

            // 지정가 주문 정보 소켓 통신(송신)
            commLimitOrderService.publishLimitOrder(orderModel.getLimitOrderNo(), "C", false, true); // 취소 (제거요청)

            // 주문_지정가 주문 기본 이력 정보 등록하기
            commLimitOrderService.insertOrLimitOrderBasHst(orderModel.getLimitOrderNo());
        }
    }
    
    /**
     * 가단가-지정가 터치된 주문 체결 처리
     */
    @Override
    public void procLimitOrderCnclsByPrvsnl(OrderModel orderModel) throws Exception {
    	// 가단가일 경우
        if(StringUtils.equals("05", orderModel.getSleMthdCode())) {
        	// 가단가 확정 - 판매 방식 [live: 라이브, limit: 지정가]이 지정가이고 터치된 후일 경우
        	if(StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", orderModel.getDcsnSelMthd())) {
        		// 해당 가단가 지정가 주문 번호의 지정가 주문 상태 코드를 변경 [단일]
        		commPrvsnlOrderService.updateCommPrvsnlLimitOrderSttusCode(orderModel.getLimitOrderNo(), orderModel.getLimitOrderSttusCode(), null, orderModel.getMberId());
        	}
        }
    }

    /**
     * 지정가 주문로직을 실행 시킨다.
     */
    @Override
    public void doLimitOrder(@Valid LimitOrderModel limitOrderModel) throws CommCustomException, Exception {
        // 23-06-23 변경사항 : 당일 지정가 주문 제한 횟수 초과 여부 체크 로직 추가
    	// 24-02-19 변경사항 : 계약구매-지정가일 경우, 체크 제외
        Map<String, Object> orderLimitCheckInfo = orderMapper.getOrderLimitCheckInfo(limitOrderModel.getEntrpsNo());
        if(StringUtils.isEmpty(limitOrderModel.getSleMthdDetailCode()) && StringUtils.equals(orderLimitCheckInfo.get("rceptYn").toString(), "N")) {    // 당일 지정가 주문 제한 횟수 초과 시
            throw new CommCustomException("당일 지정가 주문 횟수가 초과 되었습니다.\r\n(지정가 주문 횟수 : "+ orderLimitCheckInfo.get("orderTotCnt") +"회)");
        }

        initOrderData(limitOrderModel);

        // 1. 업체 결제 수단 정보 세팅
        OrderEntrpsSetleMnVO entrpsSetleMnInfo = this.getEntrpsSetleMnInfo(limitOrderModel.getEntrpsNo()
                , limitOrderModel.getSleMthdCode(), limitOrderModel.getMetalCode(), limitOrderModel.getItmSn(), limitOrderModel.getDstrctLclsfCode()
                , limitOrderModel.getBrandGroupCode(), limitOrderModel.getRealBrandCode(), null);

        limitOrderModel.setEntrpsSetleMnInfo(entrpsSetleMnInfo);

        // 2. 최적 BL Search & Setting
        limitOrderModel.setBlList(getBlList(limitOrderModel));

        if(StringUtils.equals("Y", limitOrderModel.getSmlqyPurchsAt())) {
    		// 소량구매일 경우, 조회된 BL의 자투리 할인 정보 재세팅
        	limitOrderModel.setRmndrDscnt(limitOrderModel.getBlList().get(0).getRmndrDscnt());
        }

        // 3. 주문 정합성 체크 (회원 정보 등등)
        orderValidation(limitOrderModel);

        // 4. 배송비, 공급가, 부가세, 판매가 계산 및 주문 정합성 체크2
        setPriceInfoByExpectDlvrf(limitOrderModel, true, limitOrderModel.getOrderWt(), false);

        // 5. 지정가 주문 테이블 insert
        limitOrderInstTblBase(limitOrderModel);

        // 6. 쿠폰 테이블 update (지정가 주문번호, 쿠폰 상태코드 등)
        updateCouponIsuBas(limitOrderModel);

        // 7. redis publish
        commLimitOrderRedisPubService.limitOrderMsgPublish(limitOrderModel.getLimitOrderNo(), "I");

        // 8. 지정가 주문정보 websocket publish
        commLimitOrderService.publishLimitOrder(limitOrderModel.getLimitOrderNo(), "O", false, true);

        // 7. 지정가 주문정보 bo dashboard 호출
        // 23-05-18 변경사항 : 6. 지정가 주문정보 websocket publish 로직(바로 위의 로직)에 포함됨에 따라 주석 처리
//      httpClientHelper.getCallApi(orProperty.getDashboardUrlForLimitOrder() + "/" + limitOrderModel.getLimitOrderNo());
    }


    /**
     * <pre>
     * 처리내용: 지정가 주문 정보 Table Insert
     * </pre>
     * @date 2023. 5. 3.
     * @author srec0053
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 5. 3.          srec0053            최초작성
     * ------------------------------------------------
     * @param limitOrderModel
     * @throws CommCustomException
     * @throws Exception
     */
    private void limitOrderInstTblBase(LimitOrderModel limitOrderModel) throws CommCustomException, Exception {
        // 1. VO setting
        limitOrderModel.setLimitOrderNo(DateUtil.getNowDate()+ "-L" + assignService.selectAssignValue("OR", "LIMIT_ORDER_NO", DateUtil.calDate("yyyy"), limitOrderModel.getMberNo(), 5));

        // 지정가 주문 기본 테이블 insert
        orderMapper.insertOrLimitOrderBas(limitOrderModel);

        // 지정가 주문 기본 이력 관리 테이블 insert
        commLimitOrderService.insertOrLimitOrderBasHst(limitOrderModel.getLimitOrderNo());

        // 계약구매-지정가인 경우, 계약_계약 발주 기본 테이블 update
        if(StringUtils.isNotEmpty(limitOrderModel.getSleMthdDetailCode())) {
	        orderMapper.updateCnCntrctOrderBas(limitOrderModel);
        }
    }

    /**
     * <pre>
     * 처리내용: 주문 성공 정보 소켓 통신(송신)
     * </pre>
     * @date 2023. 4. 21.
     * @author srec0053
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 4. 21.         srec0053            최초작성
     * ------------------------------------------------
     * @param orderModel
     */
    private void publishLiveOrder(OrderModel orderModel) {
        Runnable publishLiveOrder = () -> {
            try {
                Map<String, Object> sendTarget = new HashMap<>();

                // 구독 uri 구성
                putPublishUriData(sendTarget, orderModel);

                // publish 대상 data setting
                sendTarget.put("orderNo", orderModel.getOrderNo());
                sendTarget.put("goodsUntpc", orderModel.getOrgGoodsUntpc());
                sendTarget.put("realOrderWt", orderModel.getRealOrderWt());
                sendTarget.put("orderTm", DateUtil.calDate("HH:mm:ss"));

                commFrontOrderWebsocketService.publishLiveOrder(sendTarget, false);
            } catch (Exception e) {
                log.error("[OrderServiceImpl][publishLiveOrder] " + ExceptionUtils.getStackTrace(e));
            }
        };

        taskExecutor.execute(publishLiveOrder);
    }

    /**
     * <pre>
     * 처리내용: 구독 uri 구성 메소드
     * </pre>
     * @date 2023. 5. 3.
     * @author srec0053
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 5. 3.          srec0053            최초작성
     * ------------------------------------------------
     * @param sendTarget
     * @param orderModel
     */
    private void putPublishUriData(Map<String, Object> sendTarget, OrderModel orderModel) {
        // 구독 uri 구성요소
        sendTarget.put("metalCode", orderModel.getMetalCode());
        sendTarget.put("itmSn", orderModel.getItmSn());
        sendTarget.put("dstrctLclsfCode", orderModel.getDstrctLclsfCode());
        sendTarget.put("brandGroupCode", orderModel.getBrandGroupCode());
        sendTarget.put("brandCode", orderModel.getRealBrandCode());
    }

    /**
     * <pre>
     * 처리내용: 단가 쿠폰 할인 여부 확인 후, 쿠폰발행테이블 정보 등록
     * </pre>
     * @date 2023. 7. 24.
     * @author sumin
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 05. 30.        jdrttl              최초작성
     * 2022. 08. 17.        jhcha               수정
     * 2023. 07. 31.        sumin               수정
     * 2024. 01. 11.        sein                  수정
     * ------------------------------------------------
     * @param orderModel
     */
    private void updateCouponIsuBas(OrderModel orderModel) throws CommCustomException, Exception {
        log.warn("[OrderServiceImpl][updateCouponIsuBas] IN "+ orderModel.getCouponList());

        String orderNo = "";                    //주문번호
            try {
                // 사용쿠폰 사용으로 처리
                List<CouponVO> couponList = orderModel.getCouponList();

                Map<String, Object> expectDlvrfMap = commOrderService.getCheckDataDlvyTariff(orderModel, orderModel.getOrderWt(), false);
                //long expectDlvrf = Long.parseLong(Optional.ofNullable(String.valueOf(expectDlvrfMap.get("expectDlvrf"))).orElse("0")); //배송비
                long dscntExpectDlvrf = Long.parseLong(Optional.ofNullable(String.valueOf(expectDlvrfMap.get("dscntExpectDlvrf"))).orElse("0")); //할인된 배송비 금액
                String sectionPrice = String.valueOf(expectDlvrfMap.get("sectionPrice")); //배송 요율

                    if(null != orderModel.getCouponList()) {
                        if(couponList.size() > 0) {
                            for(CouponVO vo :  couponList) {
                                //배송비 쿠폰
                                if (("03").equals(vo.getCouponTyCode())) {
                                    //지정가 주문
                                    if(StringUtils.equals(orderModel.getSleMthdCode(), "03")){
                                        if(!StringUtils.equals("touch", orderModel.getLimitSection())){
                                            vo.setCouponSttusCode("05");        //COUPON_STTUS_CODE : (05)사용중
                                            orderNo = orderModel.getLimitOrderNo();

                                        //지정가 주문 & 가격 도달
                                        } else if(StringUtils.equals("touch", orderModel.getLimitSection())){
                                            vo.setCouponSttusCode("02");        //COUPON_STTUS_CODE :(02)사용완료
                                            orderNo = orderModel.getOrderNo();
                                        }
                                    //지정가 외 주문
                                    } else {
                                        vo.setCouponSttusCode("02");        //COUPON_STTUS_CODE :(02)사용완료
                                        orderNo = orderModel.getOrderNo();
                                    }
                                    // 쿠폰 발행테이블 update
//                                      orderMapper.updateCouponIsuBas(vo.getCouponSttusCode(), orderNo, Integer.toString(orderModel.getOrderWt()), orderModel.getRealDscntApplcAmount(), orderModel.getMberId(), vo.getCouponSn());
                                    orderMapper.updateCouponIsuBas(vo.getCouponSttusCode(), orderNo, Integer.toString(orderModel.getSleUnitWt()), sectionPrice, orderModel.getMberId(), vo.getCouponSn());
                                    commonService.insertTableHistory("CP_COUPON_ISU_BAS", vo);
                                //단가쿠폰
                                } else {
                                    //지정가 주문
                                    if(StringUtils.equals(orderModel.getSleMthdCode(), "03")){

                                        if(!StringUtils.equals("touch", orderModel.getLimitSection())){
                                            vo.setCouponSttusCode("05");        //COUPON_STTUS_CODE : (05)사용중
                                            orderNo = orderModel.getLimitOrderNo();

                                        //지정가 주문 & 가격 도달
                                        } else if(StringUtils.equals("touch", orderModel.getLimitSection())){
                                            vo.setCouponSttusCode("02");        //COUPON_STTUS_CODE :(02)사용완료
                                            orderNo = orderModel.getOrderNo();
                                        }

                                    //지정가 외 주문
                                    } else {
                                        vo.setCouponSttusCode("02");        //COUPON_STTUS_CODE :(02)사용완료
                                        orderNo = orderModel.getOrderNo();
                                    }

                                    // 쿠폰 발행테이블 update
                                    orderMapper.updateCouponIsuBas(vo.getCouponSttusCode(), orderNo, Integer.toString(orderModel.getOrderWt()), orderModel.getRealDscntApplcAmount(), orderModel.getMberId(), vo.getCouponSn());
                                    //상시할인 : 자동 재발행 여부 Y일 시 사용 완료일 때만
                                    if(vo.getAtmIsgnAt().equals("Y") && vo.getCouponSttusCode().equals("02")){
                                    	vo.setCouponSn("CP-"+DateUtil.getNowDateTime("yyyyMM")+"-"+ assignService.selectAssignValue("CP", "COUPON_SN", DateUtil.calDate("yyyy"), "SYSTEM", 5));
                                    	//단가 할인액 * 100(MT)
                                    	vo.setCouponDscntApplcAmount(vo.getUntpcDscntAmount()*100);
                                    	orderMapper.insertReCouponIsuBas(vo);
                                    	//할인 금액에 맞게 업데이트
                                    	orderMapper.updateCpCouponInfoBas(vo.getCouponDtlNo(), orderModel.getRealDscntApplcAmount(),orderModel.getMberId());
                                    	//CP_COUPON_INFO_BAS_HST
//                                    	commonService.insertTableHistory("CP_COUPON_INFO_BAS", vo);
                                    }
                                    //CP_COUPON_ISU_BAS_HST
                                    commonService.insertTableHistory("CP_COUPON_ISU_BAS", vo);
                                }
                            }
                        }
                    }
                log.warn("[OrderServiceImpl][updateCouponIsuBas] END");

            } catch (Exception e) {
                log.error("[OrderServiceImpl][updateCouponIsuBas] " + ExceptionUtils.getStackTrace(e));
            }
    }

    /**
     * 평균가 주문로직을 실행 시킨다.
     */
    @Override
    public void doAvrgpcOrder(@Valid OrderModel orderModel) throws CommCustomException, Exception {
        // 세금계산서보기 URL 세팅
        orderModel.setDocumentViewDomain("https://www.kztraders.com/my/papersManage/viewPapersManage"); // 20220401 이현진 세금계산서 url추가

        // 주문 초기 데이터 설정
        initOrderData(orderModel);

        log.warn(">> orderModel : " + String.valueOf(orderModel));

        try {
            /** 업체 결제 수단 정보 가져오기
             * : 업체의 증거금과 (전자상거래보증 or 케이지크레딧) 사용 권한(증거금 총 사용 여부, (전자상거래보증 or 케이지크레딧) 총 사용 여부), 증거금 신청 여부(화면단 별도 체크), (전자상거래보증 or 케이지크레딧) 신청 여부(화면단 별도 체크), 연체 및 사고 건수
             * : 증거금 최소 결제 예정일 조건
             * : 판매 단위 중량 (주문 가능 MIN 중량 및 주문 단위), 1회 구매 중량 한도 (주문 가능 MAX 중량)
             * : 업체 별 평가 등급 정보(여신 구간, 담보 보증 허용 상환 기간)
             * : 업체 구매성향 등급정보(업체 구매성향등급, 업체 구매성향등급 명, 증거금 권한 비율)
             * : 구매성향등급에 따른 단계별 금액(LME 전일 종가[케이지몰일 경우 현재 단가], 구간 종료 금액, 구간 평균 금액)
             * : 업체의 선택 가능한 구매등급을 표시한 전체 정보 리스트
             * : 여신 정보(금리 정보, 패널티 정보)
             * : 담보 보증 보험 요율(마일리지에 사용)
             * : 평균가 거래 금액 비율(평균가 주문에만 사용)
             * **/
            OrderEntrpsSetleMnVO entrpsSetleMnInfo = this.getEntrpsSetleMnInfo(orderModel.getEntrpsNo()
                    , orderModel.getSleMthdCode(), orderModel.getMetalCode(), orderModel.getItmSn(), orderModel.getDstrctLclsfCode()
                    , orderModel.getBrandGroupCode(), orderModel.getRealBrandCode(), orderModel.getSleMthdDetailCode());

            orderModel.setEntrpsSetleMnInfo(entrpsSetleMnInfo);

            log.info(">> [OrderServiceImpl][doAvrgpcOrder] entrpsSetleMnInfo : " + String.valueOf(entrpsSetleMnInfo));

            /**
             * 발주 완료된 할당 BL리스트정보 가져오기
             * **/
            orderBlList(orderModel);

            /**
             * 주문 정합성 체크 1단계
             * 1. 증거금 주문 또는 B2B 전자상거래보증 주문일 경우 여신 관리 패널티 연체 건수 및 사고 건수 체크
             * 2. 증거금 주문일 경우 구매성향등급 존재 여부 및 증거금 사용 여부 유효성 체크
             * 3. 증거금 최소 결제 예정일 조건 체크
             * 4. B2B 전자상거래보증 주문일 경우 담보 보증 사용 여부 및 담보 보증 계약 여부 유효성 및 전자상거래보증 한도 설정 여부 체크
             *   4-1. 케이지크레딧일 경우 여신 계약 번호 및 총 한도 유효성 체크 추가
             * 5. 해당 고객사의 메탈사용여부를 체크
             * 6. 휴일에 따른 유효성 체크
             * 7. 당일배송 여부 체크
             * 8. 회원구분코드가 자금담당(04)일 경우 체크
             * 9. LME 사이드카 발동여부
             * 10. 환율 사이드카 발동여부
             * 11. 업체 동시 -> 오늘날짜 기준
             * 12. 회원 및 업체, 배송지 정보 가져오기 및 존재 여부 체크
             * 13. 기업뱅킹 환불 요청 여부 유효성 체크[진행중(1), 완료(0)]
             * 14. 케이지트레이딩 환불 요청 유효성 체크 [01:요청, 05:처리중]
             * 15. 중량 변동 가져오기[유효성은 아니지만 계산 전에 가져오기 위해 넣음]
             * 16. 상품별 최대 구매 가능 중량(오늘날짜 기준) 한도 유효성 체크
             * 17. 업체별 1회 구매 중량, 1일 구매 중량(오늘날짜 기준) 한도 유효성 체크
             * 18. 주문 프라이싱 정보 가져오기 및 프라이싱 존재 체크
             * 19. 판매 가격 및 프리미엄 가격에 따른 주문 금액 정보 계산 및 체크
             *  1) LIVE/평균가-LIVE일 경우
             *   (1) 실시간 판매 가격 정보 조회 및 체크
             *   (2) 선물 SKIP 여부, 선물 틱 설정 값 등 정보 조회
             *   (3) LME 순번 값 체크 및 LME 수집 시간 간격 체크
             *   (4) 환률 순번 값 체크 및 환률 수집 시간 간격 체크
             *   (5) 실시간 프리미엄 or 평균가 프리미엄 가격 정보 조회 및 체크
             *   (6) 가격 정보 셋팅 (배송비, 공급가, 부가세, 판매가 계산 제외 - 배송비 때문)[유효성은 아니지만 계산하기 위해 넣음]
             *  2) 고정가일 경우
             *   (1) 고정가 판매 가격 정보 및 프리미엄 가격 조회, 체크
             *   (2) 가격 정보 셋팅 (배송비, 공급가, 부가세, 판매가 계산 제외 - 배송비 때문)[유효성은 아니지만 계산하기 위해 넣음]
             *  3) 평균가일 경우
             *   (1) 평균가 프리미엄 정보 셋팅
             *   (2) 가격 정보 셋팅 (배송비, 공급가, 부가세, 판매가 계산 제외 - 배송비 때문)[유효성은 아니지만 계산하기 위해 넣음]
             *     : 평균 LME, 환율 정보 조회 및 체크 (가단가 or 확정가 여부는 '평균가 확정단가 여부'에 따라 상이)
             *     : 통화 구분 코드, 단가 산식 코드에 따라 평균단가 계산
             * 99. 배송비 쿠폰 적용
             */
            orderValidation(orderModel);

            /** 배송비, 공급가, 부가세, 판매가 구하기 및 주문 정합성 체크 2단계 (판매가와 비교해야하기 위해)
             * 20. 이월렛 잔액 체크 또는 담보 보증 남은 한도 체크
             *  1) 이월렛 잔액 체크일 경우
             *   (1) 이월렛 잔금 조회 API 호출 체크
             *   (2) 이월렛 금액 부족 체크
             *  2) 담보 보증 남은 한도 체크일 경우
             *   (1) 담보 보증 남은 한도 부족 체크
             * **/
            /** 배송비, 공급가, 부가세, 판매가 구하기 **/
            setPriceInfoByExpectDlvrf(orderModel, true, orderModel.getOrderWt(), false);

            /** 평균가 재고 체크
             * : 이미 할당된 재고이므로 재고차감은 최종 성공시점에 진행
             * **/
            orderInvntryChk(orderModel);

            /** 주문 테이블 생성 **/
            avrgpcOrderInstTblBase(orderModel);

            // 24-09-11 변경사항 : 평균가(04) 주문과 동일한 로직을 가지는 가단가(05) 주문의 처리를 위한 조건문 추가
            if(!StringUtils.equals(orderModel.getSleMthdCode(), "04")
            		&& !StringUtils.equals(orderModel.getSleMthdCode(), "05")) {
                /** [평균가-라이브] 주문일시 **/
                // 평균가-라이브 주문의 걍우, 삼성 선물 체결 여부로 주문성공 여부를 체크한다.
                callSamsung(orderModel);
            } else {

                /** [평균가 || 가단가] 주문일시 **/
                // 평균가-평균가 or 가단가 주문의 경우, 결제 완료 여부로 주문성공 여부를 체크한다.
                if(StringUtils.equals(orderModel.getPaymentMn(), "ewallet") || StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
                    // 이월렛 호출
                    callZnEwallet(orderModel);
                } else if(StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty")) {
                    // B2B 전자상거래보증 호출
                    callMrtgg(orderModel);
                }
            }
            log.info("OrderServiceImpl doAvrgpcOrder line-5177 vo.toString() >> " + orderModel.toString());
            /** 주문 성공 후 처리 **/
            orderComplete(orderModel);
        } catch (Exception e) {
            log.error("doAvrgpcOrder() error : " + e);
            orderModel.setOrderFailrResn(e.getMessage());
            orderFail(orderModel);
            log.info("OrderServiceImpl doAvrgpcOrder line-5184 vo.toString() >> " + orderModel.toString());

            throw new CommCustomException(e);
        }
    }

    /**
     *  평균가 주문 정보 Table Insert
     */
    @Override
    public void avrgpcOrderInstTblBase(@Valid OrderModel orderModel) throws CommCustomException, Exception {
        // 주문 테이블 insert
        this.orderInstTblBase(orderModel);

        // 주문_주문 정보 기본 테이블 insert (평균가) : 가격관련 컬럼들은 가단가일 경우만 들어감
        // 24-09-11 변경사항 : 가단가(05) 주문의 최초 생성 데이터도 주문_주문 정보 기본 테이블에 insert 함. (테이블을 평균가와 같이 사용)
        orderMapper.insertOrOrderInfoBas(orderModel);

        if(StringUtils.equals(orderModel.getSleMthdCode(), "04")) {
            // 단가 구분 코드 [10: 가단가, 20: 확정단가]
            String untpcSeCode = (StringUtils.equals(orderModel.getAvrgpcDcsnUntpcAt() , "Y") ?  PdCommConstant.DCSN_PC : PdCommConstant.AVRG_PC);
            orderModel.setUntpcSeCode(untpcSeCode);

            for(OrOrderAvrgpcDtlVO avrgpcDtl : orderModel.getAccmltAvrgpcList()) {
                avrgpcDtl.setOrderNo(orderModel.getOrderNo());
                avrgpcDtl.setMberId(orderModel.getMberId());
                avrgpcDtl.setUntpcSeCode(untpcSeCode);

                // 주문_주문 평균가 상세 테이블 insert
                commAvrgpcOrderService.insertOrOrderAvrgpcDtl(avrgpcDtl);
            }
        } else if(StringUtils.equals(orderModel.getSleMthdCode(), "05")) {	// 24-10-15 변경사항 : 주문_단가 확정 일자 변경 상세 테이블 1row insert
        	OrUntpcDcsnDeChangeDtlVO orUntpcDcsnDeChangeDtlVO = new OrUntpcDcsnDeChangeDtlVO();
        	
        	orUntpcDcsnDeChangeDtlVO.setOrderNo(orderModel.getOrderNo());
        	orUntpcDcsnDeChangeDtlVO.setUntpcDcsnMxmmDe(orderModel.getUntpcDcsnMxmmDe());
        	orUntpcDcsnDeChangeDtlVO.setMberId(orderModel.getMberId());
        	
        	orderMapper.insertOrUntpcDcsnDeChangeDtl(orUntpcDcsnDeChangeDtlVO);
        	
        	Map<String, String> keyValueMap = new HashMap<>();
        	keyValueMap.put("ORDER_NO", orUntpcDcsnDeChangeDtlVO.getOrderNo());
        	keyValueMap.put("CHANGE_SN", String.valueOf(orUntpcDcsnDeChangeDtlVO.getChangeSn()));
        	commonService.insertTableHistory("OR_UNTPC_DCSN_DE_CHANGE_DTL", keyValueMap);
        }
    }

    /**
     * <pre>
     * 처리내용: 주문완료시 판매 BL에 대한 판매 가능 잔량 조회
     *          , 판매 잔량 부족 시 지정가 주문 데이터 확인 후 알림메시지 발송
     * </pre>
     * @date 2023. 10. 20.
     * @author hyunjin0512
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 10. 20.        hyunjin0512         최초작성
     * ------------------------------------------------
     * @param orderModel
     * @return
     */
    private synchronized void getBlInvtry(OrderModel orderModel) throws CommCustomException, Exception {
        try {

        	String reMainBlNo = "";
        	// 소량구매일 경우, 해당 BL의 잔량 탐색하도록 파라미터 세팅
        	if(StringUtils.equals("Y", orderModel.getSmlqyPurchsAt())) {
        		reMainBlNo = orderModel.getReMainBlNo();
    		}

        	// 평균가 주문은 제외
            if(!StringUtils.equals(orderModel.getSleMthdCode(), "04") && StringUtils.isEmpty(orderModel.getSleMthdDetailCode())) {
                commLimitOrderService.getBlInvtry(orderModel.getMetalCode(), orderModel.getDstrctLclsfCode(), orderModel.getItmSn()
                        , orderModel.getBrandGroupCode(), orderModel.getRealBrandCode(), orderModel.getSleMthdCode(), orderModel.getOrderWt() //orderModel.getSleUnitWt()
                        , orderModel.getSleUnitWt(), orderModel.getOnceSlePossWt(), reMainBlNo, "Y");
            }
        } catch (Exception e) {
            // TODO: handle exception
            log.info("[OrderServiceImpl] [getBlInvtry] 주문 완료 시  >> " + orderModel.toString());
        }
        return;
    }

    /**
     *  평균가 주문 모달창 공통사용 데이터 세팅(진입시점)
     */
    @Override
    public void setAvrgpcOrderBaseData(OrderModel orderModel, ModelMap model) throws Exception {

        // 계약_발주 정보
        CnCntrctOrderBasVO cntrctInfo = Optional.ofNullable(orderMapper.selectCnCntrctOrderBas(orderModel))
                                                .orElseThrow(() -> {return new CommCustomException("계약_발주 기본 정보가 없습니다.");});
        model.addAttribute("cntrctVO", cntrctInfo);
        String entrpsNo = cntrctInfo.getEntrpsNo();

        // 영업시간 체크
        boolean restdeYn = bsnInfoService.isRestDeByMetal(cntrctInfo.getMetalCode(),  "01");
        if(!restdeYn) {
            throw new CommCustomException("영업시간을 확인해주세요.");
        }

        // 장바구니 데이터 조회를 위한 세팅
        ItemPriceSelectVO itemPriceSelectVo = new ItemPriceSelectVO();
        itemPriceSelectVo.setPricingNo(cntrctInfo.getPricingNo());
        itemPriceSelectVo.setEntrpsNo(cntrctInfo.getEntrpsNo());

        List<ItemPriceSelectVO> orderBasketList = Optional.ofNullable(itemPriceService.selectOrderBasketList(itemPriceSelectVo)).orElseGet(Collections::emptyList);
        if(orderBasketList.size() > 0) {
            itemPriceSelectVo = orderBasketList.get(0);
        } else {
            throw new CommCustomException("장바구니 데이터가 존재하지 않습니다.");
        }

        itemPriceSelectVo.setSleMthdCode(cntrctInfo.getSleMthdCode()); // 평균가 분기처리
        if(StringUtils.equals(orderModel.getSleMthdCode(), "01")) {
            itemPriceSelectVo.setSleMthdDetailCode("0104"); // LIVE(계약구매) or 지정가(계약구매): 최초 모달 진입시 LIVE가 기본세팅
        }
        model.addAttribute("itemPriceSelectVo", itemPriceSelectVo);

        // 업체별 결제 수단 정보
        OrderEntrpsSetleMnVO entrpsSetleMnInfo =  this.getEntrpsSetleMnInfo(entrpsNo, cntrctInfo.getSleMthdCode(), cntrctInfo.getMetalCode(),
                cntrctInfo.getItmSn(), cntrctInfo.getDstrctLclsfCode(), cntrctInfo.getBrandGroupCode(), cntrctInfo.getBrandCode(), itemPriceSelectVo.getSleMthdDetailCode());
        entrpsSetleMnInfo.setPartDlivyRepyAt("N"); // 평균가 주문은 중도상환 제공하지 않음
        model.addAttribute("entrpsSetleMnInfo", entrpsSetleMnInfo);
        model.addAttribute("entrpsNo", entrpsNo);

        if(StringUtils.equals(orderModel.getSleMthdCode(), "04")) {
        	// [평균가]
            orderModel.setMetalCode(itemPriceSelectVo.getMetalCode());
            orderModel.setItmSn(itemPriceSelectVo.getItmSn());
            orderModel.setDstrctLclsfCode(itemPriceSelectVo.getDstrctLclsfCode());
            orderModel.setBrandGroupCode(itemPriceSelectVo.getBrandGroupCode());
            orderModel.setCntrctOrderBasInfo(cntrctInfo);

            // 확정 단가 여부, 평균 LME/환율 데이터 세팅
            model.addAttribute("bsnDeAvrgpc", commAvrgpcOrderService.selectPrevBsnDeAvrgpc(cntrctInfo));
            model.addAttribute("avrgpcDcsnUntpcAt", cntrctInfo.getAvrgpcDcsnUntpcAt());
        } else {
        	 // [평균가-라이브 or 지정가]
            PrSelVO prSelVO = Optional.ofNullable(pcInfoService.getNewestPrSelRltm(itemPriceSelectVo.getMetalCode(), itemPriceSelectVo.getItmSn(), itemPriceSelectVo.getDstrctLclsfCode(),
                                                                                   itemPriceSelectVo.getBrandGroupCode(), itemPriceSelectVo.getBrandCode(), DateUtil.getNowDate()))
                                      .orElseThrow(() -> {return new CommCustomException("조건에 맞는 실시간 판매가격 정보가 없습니다.");});

            // 차트 리스트 구성에 필요한 데이터 조회
            Map<String, Object> chartList = pcMntrngService.getItemChartDate(itemPriceSelectVo.getMetalCode(), itemPriceSelectVo.getSleMthdCode(), itemPriceSelectVo.getMetalClCode());
            // 스크립트에서 사용 하기위한 JSON데이터로 변환
            String jsonMainChart = objectMapper.writeValueAsString(chartList);

            model.addAttribute("metalCode", itemPriceSelectVo.getMetalCode());
            model.addAttribute("chartList", chartList);
            model.addAttribute("jsonChartList", jsonMainChart);

            // 금일 Live 주문 중, 브랜드까지 동일한 주문 리스트(가격, 수량, 시간)
 			model.addAttribute("liveOrderList", itemPriceService.selectLiveOrderList(itemPriceSelectVo));

 			// 금일 체결된 지정가 주문 중, 브랜드까지 동일한 지정가 주문 관련 데이터 추가
			Map<String, Object> limitOrderData = itemPriceService.selectLimitOrderData(itemPriceSelectVo);
			model.addAttribute("limitOrderTotalCnt", limitOrderData.get("limitOrderTotalCnt"));
			model.addAttribute("limitOrderListMap", limitOrderData.get("limitOrderListMap"));

			// 지정가 주문 가능 여부 check
			// 23-06-23 변경사항 : 지정가 주문 불가능 사유 항목 추가 (Front 단에서 지정가 radio 버튼 mouseover 시, 툴팁으로 안내)
			model.addAttribute("limitOrderPossAt", itemPriceService.getLimitOrderPossAt(itemPriceSelectVo));

			// 실시간 재고 데이터 수신 uri
			model.addAttribute("invntryUri", invntryUri);

			// 실시간 재고 데이터
			String key = String.join("_"
					, itemPriceSelectVo.getMetalCode()
					, String.valueOf(itemPriceSelectVo.getItmSn())
					, itemPriceSelectVo.getDstrctLclsfCode()
					, itemPriceSelectVo.getBrandGroupCode()
					, itemPriceSelectVo.getBrandCode());
			InvntrySttusVO invntrySttusVO = invntrySttusService.getInvntrySttusInfoMap(itemPriceSelectVo.getMetalCode()).get(key);
			long totSleInvntryUnsleBundleBnt = invntrySttusVO == null ? 0 : invntrySttusVO.getTotSleInvntryUnsleBundleBnt();
			model.addAttribute("totSleInvntryUnsleBundleBnt", totSleInvntryUnsleBundleBnt);

 			// 지정가 야간장 선택 가능한 일자
 			String limitOrderNightTime = itemPriceService.getMinLimitOrderNightTime(orderModel.getMetalCode(), DateUtil.getNowDate(), 2);
 			model.addAttribute("limitOrderNightTime", limitOrderNightTime);
 			// 출고요청일 기준 지정가 유효 일자
 			String maxLimitOrderValideDe = itemPriceService.getMinLimitOrderNightTime(orderModel.getMetalCode(), cntrctInfo.getDlivyRequstDe(), -2);
 			model.addAttribute("maxLimitOrderValideDe", maxLimitOrderValideDe.replaceAll("-", ""));

 			// 지정가 사용 가능 단가 산식 코드 목록
 			List<CommonCodeVO> untpcMntnfrmlaCodeList = Optional.ofNullable(commonCodeService.getSubCodesToCommonCode("UNTPC_MNTNFRMLA_CODE")).orElseGet(ArrayList<CommonCodeVO>::new).stream()
			 													.filter(data -> (StringUtils.equals(data.getCodeChrctrRefrntwo(), "Y")))
			 													.collect(Collectors.toList());
 			model.addAttribute("untpcMntnfrmlaCodeList", untpcMntnfrmlaCodeList);
        }

        // 서비스 약관 데이터 조회 및 세팅
        List<EntrpsEtrVO> selectOrderStplat = entrpsEtrService.selectEntrpsEtrStplat();
        if (selectOrderStplat == null || selectOrderStplat.size() == 0) {
            model.addAttribute("orderStplatInfo", new EntrpsEtrVO());
            model.addAttribute("limitsOrderStplat", new EntrpsEtrVO());
        } else {
            EntrpsEtrVO orderStplatInfo = Optional.ofNullable(selectOrderStplat.stream().filter(data -> (StringUtils.equals(data.getStplatSeCode(), "01")))
                                                   .collect(Collectors.toList()).get(0)).orElse(new EntrpsEtrVO());
            model.addAttribute("orderStplatInfo", orderStplatInfo); // 01 : 기본 서비스 약관

            EntrpsEtrVO limitsOrderStplat = Optional.ofNullable(selectOrderStplat.stream().filter(data -> (StringUtils.equals(data.getStplatSeCode(), "11")))
                    .collect(Collectors.toList()).get(0)).orElse(new EntrpsEtrVO()); // 11 : 지정가 서비스 약관
            model.addAttribute("limitsOrderStplat", limitsOrderStplat);
        }

        // 쿠폰 리스트
        CouponVO couponVO = new CouponVO();
        couponVO.setEntrpsNo(entrpsNo);
        couponVO.setMetalCode(cntrctInfo.getMetalCode());
        List<CouponVO> untCouponList = myCouponDtlsSerivce.couponList(couponVO, "01");
        List<CouponVO> dlvyCouponList = myCouponDtlsSerivce.couponList(couponVO, "03");

        model.addAttribute("untCouponList", untCouponList);
        model.addAttribute("dlvyCouponList", dlvyCouponList);

        /* 페이백 기능 추가 2024/02/14 */
		//회원_업체 등급 기준 구매 수량
		MbEntrpsGradVO mbEntrpsGradStdrPurchsQy = dashboardService.selectMbEntrpsGradStdrPurchsQy();
		model.addAttribute("mbEntrpsGradStdrPurchsQy", mbEntrpsGradStdrPurchsQy);
		//등급 할인 금액 리스트
		List<MbEntrpsGradVO> mbGradDscntAmountList = dashboardService.selectMbGradDscntAmountList();
		model.addAttribute("mbGradDscntAmountList", mbGradDscntAmountList);
		//당월 구매 수량
		int totRealOrderWtSum = dashboardService.selectMbTotRealOrderWtSum(userInfoUtil.getAccountInfo().getEntrpsNo());
		model.addAttribute("totRealOrderWtSum", totRealOrderWtSum);
		//전월 기준 구매 정보(MB_ENTRPS_MNBY_PURCHS_BNEF_BAS)
		MbEntrpsGradVO mbEntrpsMnbyPurchsInfo = dashboardService.mbEntrpsMnbyPurchsInfo(userInfoUtil.getAccountInfo().getEntrpsNo());
		model.addAttribute("mbEntrpsMnbyPurchsInfo", mbEntrpsMnbyPurchsInfo);
		//상시 할인 금액 리스트(3000,4000,5000)
		List<MbEntrpsGradVO> cpAtmcIsuCouponInfoList= dashboardService.selectcpAtmcIsuCouponInfoList();
		model.addAttribute("cpAtmcIsuCouponInfoList", cpAtmcIsuCouponInfoList);

		if (userInfoUtil.getAccountInfo() != null) {
			String entrpsPayBackDscntUseAt = userInfoUtil.getAccountInfo().getEntrpsPayBackDscntUseAt() != null ? userInfoUtil.getAccountInfo().getEntrpsPayBackDscntUseAt() : "Y";
			String entrpsMnbyPurchsBnefUseAt = userInfoUtil.getAccountInfo().getEntrpsMnbyPurchsBnefUseAt() != null ? userInfoUtil.getAccountInfo().getEntrpsMnbyPurchsBnefUseAt() : "Y";
			
			model.addAttribute("entrpsPayBackDscntUseAt", entrpsPayBackDscntUseAt);
			model.addAttribute("entrpsMnbyPurchsBnefUseAt", entrpsMnbyPurchsBnefUseAt);
		}
		/* 페이백 기능 추가 끝 */

        // 회원 등급별 즉시할인 데이터
        MbEntrpsGradVO mbEntrpsGradVO = new MbEntrpsGradVO();
        mbEntrpsGradVO.setEntrpsNo(entrpsNo);
        mbEntrpsGradVO.setMetalCode(cntrctInfo.getMetalCode());
        model.addAttribute("mbEntrpsGradVO", itemPriceService.getDscntAmount(mbEntrpsGradVO));

        // 조정계수 조회
        CommFtrsFshgMngVO ftrsFshgMngVO = Optional.ofNullable(commFtrsFshgMngService.commFtrsFshgManageDtlListByToday("B").stream()
                                                  .filter(data -> ( StringUtils.equals(data.getMetalCode(), cntrctInfo.getMetalCode()))).collect(Collectors.toList()).get(0))
                                                  .orElseThrow(() -> {return new CommCustomException("LME, 환율 조정계수 정보가 없습니다.");});
        model.addAttribute("ftrsFshgMngVO", ftrsFshgMngVO);

        //운영 종료 시간(야간장 시간)
        RltmEndTimeVO rltmEndTimeVO = bsnInfoService.getRltmEndTime();
        model.addAttribute("rltmEndTimeVO", rltmEndTimeVO);

        // 영엽시간
     	model.addAttribute("rltmTime", itemPriceService.selectSalesTime());

        // 평균가 주문 여부
        model.addAttribute("avrgpcYn", "Y");
    }

    /**
     *  누적 평균 가격 목록 조회
     */
    @Override
    public Map<String, Object> getAccmltAvrgpcList(OrderModel orderModel) throws Exception {
        Map<String, Object> returnMap = new HashMap<>();

        List<OrOrderAvrgpcDtlVO> accmltAvrgpcList = commAvrgpcOrderService.selectAccmltAvrgpcList(orderModel.getCntrctOrderNo());
        returnMap.put("accmltAvrgpcList", accmltAvrgpcList);

        return returnMap;
    }

    /**
     * <pre>
     * 처리내용: 2024 설날 복주머니 이벤트 추첨권 총 수 확인
     * 		 : 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
     * </pre>
     * @date 2024. 01. 26.
     * @author hyunjin05
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 01. 26.		hyunjin05			최초작성
     * ------------------------------------------------
     * @param orderModel
     */
    private synchronized int selectCntEvNewYearPromtn() {
    	log.warn("[OrderServiceImpl][insertNewYearEv] IN");
    	int returnCnt = 0;
    	try {
    		returnCnt = orderMapper.selectCntEvNewYearPromtn();
    	} catch (Exception e) {
    		// TODO: handle exception
    		log.error("[OrderServiceImpl][insertNewYearEv] " + ExceptionUtils.getStackTrace(e));
    	}
    	return returnCnt;
    }
    /**
     * <pre>
     * 처리내용: 2024 설날 복주머니 이벤트 추첨권 등록
     * 		 : 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
     * </pre>
     * @date 2024. 01. 26.
     * @author hyunjin05
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 01. 26.		hyunjin05			최초작성
     * ------------------------------------------------
     * @param orderModel
     */
    private synchronized void insertEvNewYearPromtn(OrderModel orderModel) {
    	log.warn("[OrderServiceImpl][insertNewYearEv] IN");
//    	PromtnNewYearVO newYearVO = new PromtnNewYearVO();

    	try {
//    		newYearVO.setEntrpsNo(orderModel.getEntrpsNo());

			orderMapper.insertEvNewYearPromtn(orderModel);

		} catch (Exception e) {
			// TODO: handle exception
			log.error("[OrderServiceImpl][insertEvNewYearPromtn] " + ExceptionUtils.getStackTrace(e));
		}
    }
}
