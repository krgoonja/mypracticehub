package com.sorincorp.fo.pd.service;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingWeightCalculateValuesVO;
import com.sorincorp.comm.order.model.CommFtrsFshgMngVO;
import com.sorincorp.comm.order.model.ItPurchsInfoBas;
import com.sorincorp.comm.order.model.MbDlvrgBasVO;
import com.sorincorp.comm.order.model.OrPricingBasVO;
import com.sorincorp.comm.order.model.OrderEntrpsSetleMnVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.comm.order.model.OrderPurchsInclnGradeVO;
import com.sorincorp.comm.pcInfo.model.FixPriceVO;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;

import lombok.extern.slf4j.Slf4j;

/**
 * TestOrder.java
 * @version
 * @since 2023. 9. 27.
 * @author srec0049
 */
@Slf4j
public class TestOrder {
	
	final ObjectMapper objectMapper = new ObjectMapper();
	
	public void doOrder(OrderModel orderModel, ThreadPoolTaskExecutor threadPoolTaskExecutor) throws CommCustomException, Exception {
		
		log.info("TestOrder doOrder orderModel.toString() >> " + orderModel.toString());
		/** 주문 성공 후 처리 **/
		orderComplete(orderModel, threadPoolTaskExecutor);
	}
	
	public void orderComplete(OrderModel orderModel, ThreadPoolTaskExecutor threadPoolTaskExecutor) {
		log.warn("[TestOrder][orderComplete] IN");
		try {
			
			OrderModel orderModelByFx = objectMapper.readValue(objectMapper.writeValueAsString(orderModel), OrderModel.class);
			log.info("TestOrder orderComplete orderModelByFx.toString() >> " + orderModelByFx.toString());
			OrderModel orderModelByOrderInvntryUdt = objectMapper.readValue(objectMapper.writeValueAsString(orderModel), OrderModel.class);
			log.info("TestOrder orderComplete orderModelByOrderInvntryUdt.toString() >> " + orderModelByOrderInvntryUdt.toString());
			
			if(StringUtils.equals("01", orderModel.getSleMthdCode()) || StringUtils.equals("03", orderModel.getSleMthdCode())){
				// FX 호출
				callFX(orderModelByFx, threadPoolTaskExecutor);
//				if(StringUtils.equals(orderModel.getPaymentMn(), "ewallet") || StringUtils.equals(orderModel.getPaymentMn(), "wrtm")) {
//					// 이월렛 호출
//					callEwallet(orderModel);
//				} else if(StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty")) {
//					// B2B 전자상거래보증 호출
//					callMrtgg(orderModel);
//				}
//
//				if(StringUtils.equals("01", orderModel.getSleMthdCode())) {
//					// 2023-04-21 변경사항 : 라이브 주문정보 websocket publish
//					publishLiveOrder(orderModel);
//				}
			}
//			//배송비 할인 여부 확인 후 업데이트
//			//dscntExpectDlvrfUpd(orderModel);
//			//쿠폰테이블 업데이트
//			updateCouponIsuBas(orderModel);
			// 재고 차감
			orderInvntryUdt(orderModelByOrderInvntryUdt, threadPoolTaskExecutor);
//			// Oms 통신
//			callOms(orderModel);
//			// 프라이싱 테이블을 등록[프라이싱 단계 코드 : 03(결제완료)]한다. 20211123 수정
//			instPricingByStepCode(orderModel);
//			// 대쉬보드 호출
//			callDashboard(orderModel);
//			// 메일 발송 20211214 주석처리
//			callMail(orderModel);
//			// 앱푸시 발송, 20220211 주문완료 시 앱푸시 제외됨, 주석처리
////			callAppPush(orderModel);
//			// 카카오톡 발송
////			callKakao(orderModel);
//			// SMS 발송
//			callSms(orderModel);
//			// 세금계산서 호출
////			callTaxBill(orderModel); // 20211210 이월렛 성공 시 세금계산서 발행으로 변경되어 제거
//			// History 생성
//			instHistory(orderModel);
//
		}catch (Exception e) {
			log.info("Exception TestOrder orderComplete orderModel.toString() >> " + orderModel.toString());
			log.error("[TestOrder][orderComplete] " + ExceptionUtils.getStackTrace(e));
		}
	}
	
	private synchronized void callFX(OrderModel orderModel, ThreadPoolTaskExecutor threadPoolTaskExecutor) {
		log.warn("[TestOrder][callFX] IN");
		log.info(">> callFX getBlNo : " + orderModel.getBlDetail().getBlNo());
		
		Runnable fxRun = () -> {
			try {
				int a = 0;
				// 주문 디테일 테이블 생성
				for(ItemPriceMatchingBlInfoVO bl : orderModel.getBlList()) {
					if(bl.getRealMatchedOrderedBnt().compareTo(BigDecimal.ZERO) > 0) {
						String fshgRequstOrderNo = "TEST" + (++a);
						orderModel.setFshgRequstOrderNo(fshgRequstOrderNo);
						
						//log.info(">> set pre callFX : " + fshgRequstOrderNo + ", bl : " + orderModel.getBlDetail().getBlNo());;
						
						log.info(">> set callFX");
						orderModel.setBlDetail(bl);
						
						if(a==2) { Thread.sleep(2); }
						
						log.info(">> set after callFX : " + fshgRequstOrderNo + ", bl : " + orderModel.getBlDetail().getBlNo());
//						
//						
////						// 상품_PO 정보 가져오기
////						orderModel.setItPurchsInfoBas(Optional.ofNullable(orderMapper.selectItPurchsInfoBas(orderModel)).orElseThrow(() -> {
////							log.info("OrderServiceImpl callFX line-2535 vo.toString() >> " + orderModel.toString());
////							return new CommCustomException("callFX > PO 테이블 미존재");}));
////
////						// 주문_주문 선물환 기본 정보 등록하기
////						orderMapper.insertOrOrderFshgBas(orderModel);
					}
				}
//				Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getFxOrderUrl(), Collections.singletonMap("orderNo", orderModel.getOrderNo()));
//				log.warn(">> 하나은행 fx resObj : " + resObj);
			} catch (Exception e) {
				log.error("[TestOrder][callFX] " + ExceptionUtils.getStackTrace(e));
			}
		};
		
		threadPoolTaskExecutor.execute(fxRun);
	}
	
	private synchronized void orderInvntryUdt(OrderModel orderModel, ThreadPoolTaskExecutor threadPoolTaskExecutor) {
		log.warn("[TestOrder][orderInvntryUdt] IN");
		log.info(">> orderInvntryUdt getBlNo : " + orderModel.getBlDetail().getBlNo());
		
		Runnable invntryRun = () -> {
			try {
				int invntryPubChkNum = 0; // 재고 데이터 변경이 있는지 체크할 값
//
				for(ItemPriceMatchingBlInfoVO bl : orderModel.getBlList()) {
					if(bl.isInvntryUdt()) {
						
						//log.info(">> set pre orderInvntryUdt : " + invntryPubChkNum + ", bl : " + orderModel.getBlDetail().getBlNo());
						
						log.info(">> set orderInvntryUdt");
						orderModel.setBlDetail(bl);
						
						if(invntryPubChkNum==0) { Thread.sleep(1); }
						if(invntryPubChkNum==1) { Thread.sleep(3); }
						
						log.info(">> set after orderInvntryUdt : " + invntryPubChkNum + ", bl : " + orderModel.getBlDetail().getBlNo());
						
//						// 최초 로 원복 후 작업 재고 정리 시작
//						orderMapper.updateRecoverInvntryBlInfoBas(orderModel);
//						if(bl.getRealMatchedOrderedBnt().compareTo(BigDecimal.ZERO) > 0) {
//							// IT_BL_INFO_BAS
//							orderMapper.updateInvntryBlInfoBas(orderModel);
//							// IT_BL_INFO_HIST_DTL(화면에서 관리 하는 이력 테이블), 04-주문으로 코드 생성,
//							orderMapper.insertInvntryBlInfoHistDtl(orderModel);
//							// IT_BL_INFO_BAS_HST (시스템 이력)
//							orderMapper.insertBlInfoBasHst(orderModel);
//
							invntryPubChkNum++; // 변경이 있을 시 증가
//						}
					}
				}
//
//				// 재고가 변경된 사항이 한건이라도 있을 시
//				if(invntryPubChkNum > 0) {
//					// Redis에 재고 데이터 변경 메세지 발행하기
//					invntrySttusService.invntrySttusMsgPublish();
//				}
//
			} catch (Exception e) {
				log.error("[TestOrder][orderInvntryUdt] " + ExceptionUtils.getStackTrace(e));
			}
		};
		
		threadPoolTaskExecutor.execute(invntryRun);
	}
	
	
	public static void main(String[] args) {
		TestOrder testOrder = new TestOrder();
		
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setAllowCoreThreadTimeOut(true);
		threadPoolTaskExecutor.setKeepAliveSeconds(30);	
		threadPoolTaskExecutor.setCorePoolSize(1000);
		threadPoolTaskExecutor.setMaxPoolSize(1500);
		threadPoolTaskExecutor.setQueueCapacity(1000);
		threadPoolTaskExecutor.setThreadNamePrefix("testOrder_");
		
		/** 최대 스레드로 최대 queue 값 만큼 증가 됫을때 처리 방법 정의 **/
		threadPoolTaskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
		/** 서버 강제 종료 시 대기하고 있는 쓰레드를 처리할지 여부 **/
		threadPoolTaskExecutor.setWaitForTasksToCompleteOnShutdown(true);
		/** 서버 강제 종료 시 대기 중인 스래드를 처리할 최대 시간 **/
		threadPoolTaskExecutor.setAwaitTerminationSeconds(60);
		
		threadPoolTaskExecutor.initialize();
		
		ObjectMapper objectMapper = new ObjectMapper();
		
		String orderModelStr = "{\"bsktNo\":\"B20230926-000155\",\"pricingNo\":\"P20230926-000347\",\"slePcRltmSn\":null,\"premiumNo\":\"PN0720230620086829\",\"premiumPc\":213000,\"metalCode\":\"7\",\"itmSn\":434,\"dstrctLclsfCode\":\"10\",\"dstrctMlsfcCode\":\"1010\",\"vhcleTonCode\":\"25000\",\"brandGroupCode\":\"02\",\"brandCode\":\"HINDAD\",\"realBrandCode\":\"HINDAD\",\"orderWt\":50,\"sleUnitWt\":25,\"onceSlePossWt\":100,\"mxmmPurchsPossWt\":9999,\"samsungOrderWt\":25,\"samsungStockCode\":\"LAL\",\"dlvrgNo\":\"345\",\"rceptMediaSeCode\":\"01\",\"sleMthdCode\":\"01\",\"dlvyMnCode\":\"01\",\"dlivyRequstDe\":\"2023-10-12\",\"dlvyRequstCn\":\"\",\"orderNo\":\"20230926-S05447\",\"orderSn\":null,\"setleNo\":null,\"omsRceptNo\":null,\"orderSttusCode\":10,\"condOrderSttusCode\":\"0\",\"orderFailrResn\":null,\"canclExchngRtngudNo\":null,\"ftrsRequstOrderNo\":\"20230926-10000000098\",\"executId\":null,\"requstWonOrderNo\":null,\"fshgRequstOrderNo\":null,\"ewalletAcnutNo\":null,\"mberNo\":\"P0641\",\"entrpsNo\":\"C0240\",\"entrpsGradNo\":null,\"mberId\":\"sorin002006\",\"mberEmail\":\"jdrttl@sorincorp.com\",\"totBundleQy\":50,\"totCstmrOrderWt\":0,\"totRealOrderWt\":0,\"totAmtTariff\":null,\"goodsUntpc\":3173000,\"orderPc\":158650000,\"wtChange\":2.35,\"wtChangegld\":7456550,\"splpc\":166744550,\"vat\":16674455,\"slepc\":183419005,\"expectDlvrf\":638000,\"requstAcnutNo\":\"IvieiLEgzMFhbvwIUxo0ng==\",\"requstOrderUntpc\":\"2236.000000\",\"requstOrderQy\":1,\"cstmrOrderWt\":25,\"realOrderWt\":25,\"bundleQy\":0,\"ftrnNoList\":[\"20230926-10000000097\",\"20230926-10000000098\"],\"cancelFtrnNoList\":null,\"samsungFailList\":null,\"requstWonOrderNoListByCancel\":null,\"orderInvntryBlNo\":null,\"orderInvntry\":0.0,\"orderBundleInvntry\":0,\"delngSeqNo\":null,\"orderBlList\":null,\"orderBlDetail\":null,\"claimDetail\":null,\"newPricingNo\":null,\"applcDt\":null,\"pricingStepCode\":null,\"cstmrSlePcRltmSn\":\"20230926160352089326\",\"cstmrLmePcRltmSn\":null,\"cstmrPremiumNo\":\"PN0720230620086829\",\"cstmrEhgtPcRltmSn\":null,\"documentViewDomain\":\"https://www.metalsorin.com/my/papersManage/viewPapersManage\",\"domain\":\"http://st.metalsorin.com:28085\",\"sameDayDeliveryStatus\":false,\"sameDayDeliveryAt\":\"N\",\"todayDlvyAt\":\"N\",\"samsungOrdertype\":\"N\",\"dlvrfDscntAt\":null,\"couponSeqNo\":\"\",\"couponDscntPrice\":\"\",\"couponDplctUseLmttQyAt\":null,\"couponIsuRnno\":null,\"paymentMn\":\"mrtggGrnty\",\"purchsInclnStepRate\":0,\"purchsInclnStepAmount\":0,\"mrtggGrntyRepyPd\":10,\"orderHoldingUseAt\":\"N\",\"mummSetleAmount\":0,\"grntyAmount\":\"200000000000\",\"mrtggBlce\":null,\"grntyNo\":\"SORIN20111125-03\",\"entrpsMrtggCntrctSn\":7,\"mrtggGrntyFeeBndMbyAt\":null,\"grntyTmlmtBeginDe\":\"20230609\",\"grntyTmlmtEndDe\":\"20240630\",\"intrt\":0.0,\"untpcIncrse\":0,\"entrpsMrtggSn\":0,\"mrtggNo\":\"20230926-00044\",\"orderMbEntrpsMlgInfoDtlVO\":null,\"selngAchivrt\":null,\"mlgSn\":0,\"orderCapaManageAt\":\"N\",\"couponList\":null,\"todayTotRealOrderWtCnd\":\"entrpsSorincredt\",\"cdtlnSvcSeCode\":\"02\",\"reMainBlNo\":\"\",\"orderHoldingByWrhousngPrearngeInvntryUseAt\":null,\"lmeColctTimeIntrvlVal\":10800,\"ehgColctTimeIntrvlVal\":10800,\"brandCodeByPremium\":\"HINDAD\",\"limitOrderNo\":null,\"limitSection\":null,\"dlvrgPostNo\":null,\"limitOrderSttusCode\":null,\"invntryPartCnclsAt\":null,\"limitOrderStdrSlePc\":null,\"afterSleInvntryUnsleBnt\":0,\"limitOrderTmByFormat\":null,\"limitInputAmount\":0,\"orderPnttmRemndrLmtAmount\":0,\"requstFtrsCmpnySeCode\":null,\"requstFtrsCmpnyTrgetCode\":null,\"couponApplcAt\":\"N\",\"couponTyCode\":\"\",\"orgGoodsUntpc\":3175000,\"totalCouponDscntAmount\":0,\"realDscntApplcAmount\":null}";
		String itPurchsInfoBasStr = "{\"blNo\":\"JT_HINDAD_AL_0001\",\"purchsOrderNo\":null,\"purchsLineNo\":null,\"purchsBsnm\":null,\"purchsCmmrcCnd\":null,\"purchsLcNm\":null,\"purchsQy\":null,\"purchsLmeDollarPc\":null,\"purchsPremiumDollarAmount\":null,\"purchsUnitDollarPc\":null,\"purchsDollarAmount\":null,\"purchsWonAmount\":null,\"ftrsCntrctNo\":null,\"ftrsThsexCntrctNo\":null,\"ftrsDelngDt\":null,\"ftrsDelngLotQy\":0,\"ftrsDelngOptn\":null,\"ftrsDelngBeginDe\":null,\"ftrsDelngEndDe\":null,\"ftrsLmeDollarPc\":0.00,\"ftrsSpreadDollarPc\":0.00,\"ftrsEndDollarPc\":0.00,\"ftrsDollarFee\":null,\"ftrsExprtnDe\":\"20231018\",\"fshgCntrctNo\":null,\"fshgDelngDt\":null,\"fshgDlryWt\":0,\"fshgDelngCrncy\":null,\"fshgDelngDollarAmount\":119500000.00,\"fshgWonEhgt\":null,\"fshgWonSpread\":null,\"fshgEndWonPc\":null,\"fshgWonAmount\":null,\"fshgExprtnDe\":\"20231018\",\"fshgManageNo\":null,\"lgistTrminlUseWonCt\":0,\"lgistTrnsprtWonCt\":0,\"lgistLnlWonCt\":0,\"lgistCstdyWonCt\":0,\"lgistEtcWonCt\":0,\"entrFeeWonCt\":0,\"fnncIntrWonCt\":0,\"fnncEtcWonCt\":0,\"shipngDe\":null,\"prloadNm\":null,\"arvlhangNm\":null,\"screofeFileCours\":null,\"packngListFileCours\":null,\"wrhousngDe\":null,\"tariffVal\":0,\"freeTime\":0,\"deleteAt\":\"N\",\"deleteDt\":null,\"frstRegisterId\":\"SOREC-IF-112(793)\",\"lastChangerId\":\"parksw\",\"ftrsDelngWt\":0,\"ftrsDelngLotOrgQy\":2000,\"fshgDlryOrgWt\":50000,\"fshgDelngDollarOrgAmount\":119500000.00,\"ftrsprofsSeCode\":\"T3000759\",\"ftrsCmpnyTrgetCode\":\"EBEST\"}";
		String prSelVOStr = "{\"metalCode\":\"7\",\"itmSn\":434,\"dstrctLclsfCode\":\"10\",\"dstrctLclsfName\":null,\"brandGroupCode\":\"02\",\"brandCode\":\"HINDAD\",\"occrrncDe\":\"20230926\",\"occrrncTime\":\"160352\",\"occrrncSn\":\"089326\",\"slePcRltmSn\":\"20230926160352089326\",\"slePcDeSn\":null,\"occrrncYyweek\":null,\"slePcYyWeekSn\":null,\"occrrncYm\":null,\"slePcYyMtSn\":null,\"occrrncQu\":null,\"slePcYyQuSn\":null,\"beginPc\":3155000,\"endPc\":3175000,\"topPc\":3180000,\"lwetPc\":3094000,\"nonPremiumBeginPc\":2942000,\"nonPremiumEndPc\":2962000,\"nonPremiumTopPc\":2967000,\"nonPremiumLwetPc\":2881000,\"threemonthLmePc\":2226.500000,\"lmePc\":2185.750000,\"lmeExcclcPc\":2233.500000,\"ehgtPc\":1353.300000,\"premiumPc\":213000,\"lmePcRltmSn\":\"20230926160333000007\",\"ehgtPcRltmSn\":\"20230926160352597636\",\"premiumId\":\"PI07001889\",\"premiumNo\":\"PN0720230620086829\",\"lmeMdatCffcnt\":1.000000,\"fxMdatCffcnt\":1.000000,\"delngQy\":0,\"accmltDelngQy\":0,\"pastEndPc\":0,\"versusPc\":0,\"versusRate\":0.000000,\"deleteDt\":null,\"deleteAt\":\"N\",\"frstRegisterId\":\"system\",\"lastChangerId\":\"system\",\"avgSelPc\":null,\"accmltLmeCsp\":null,\"accmltUsdCvtrate\":null,\"selMetalCodeList\":null}";
		String fixSelVOStr = "{\"premiumId\":null,\"hghnetprcAvrgPurchsPrmpc\":null,\"hghnetprcDstrctChangeAmount\":null,\"hghnetprcBrandGroupChangeAmount\":null,\"hghnetprcBrandChangeAmount\":null,\"gradChangeAmount\":null,\"avrgProfitAmount\":null,\"slePc\":null,\"hghnetprcSleAmount\":null,\"premiumNo\":null,\"metalCode\":null,\"itmSn\":0,\"dstrctLclsfCode\":null,\"dstrctLclsFName\":null,\"brandGroupCode\":null,\"brandCode\":null,\"entrpsNo\":null,\"entrpsGradNo\":0,\"puchasPc\":null,\"occrrncDe\":null,\"termType\":null,\"termValue\":null,\"sorinmallUnitPdCode\":null,\"lmttWt\":null,\"ntfcAmount\":null,\"lrgetrnsprtctAmount\":null,\"marginAmount\":null,\"itmCode\":null,\"goodsNm\":null,\"dspyGoodsNm\":null,\"dstrctLclsfNm\":null,\"brandGroupNm\":null,\"brandNm\":null,\"applcYm\":null,\"metalClCode\":null,\"orderWeight\":0}";
		String orPricingBasVOStr = "{\"pricingNo\":\"P20230926-000347\",\"metalCode\":\"7\",\"itmSn\":434,\"sleMthdCode\":\"01\",\"dstrctLclsfCode\":\"10\",\"brandGroupCode\":\"02\",\"brandCode\":\"HINDAD\",\"entrpsNo\":\"C0240\",\"mberNo\":\"P0641\",\"pricingStepCode\":\"02\",\"itmNm\":\"Primary Aluminium Ingot (p1020)_434 [SLS0017_434]\",\"goodsNm\":\"Primary Aluminium Ingot (p1020)_434\",\"goodsUntpc\":3174000,\"slePcRltmSn\":\"20230926160258088433\",\"lmePcRltmSn\":\"20230926160247000007\",\"ehgtPcRltmSn\":\"20230926160258600264\",\"premiumNo\":\"PN0720230620086829\",\"bsktNo\":\"B20230926-000155\",\"wonPricingNo\":\"P20230926-000346\",\"orderWt\":0,\"dlvyMnCode\":null,\"dlvrgNo\":null,\"dlivyRequstDe\":null,\"orderNo\":null,\"orderPc\":0,\"wtChangegld\":0,\"dlvrf\":0,\"vat\":0,\"slepc\":0,\"deleteDt\":null,\"deleteAt\":\"N\",\"frstRegisterId\":\"sorin002006\",\"lastChangerId\":\"sorin002006\"}";
		String livePremiumVOStr = "{\"premiumId\":\"PI07001889\",\"metalCode\":\"7\",\"itmSn\":434,\"validBeginDt\":\"20230922180000\",\"validEndDt\":\"99991231235959\",\"sleMthdCode\":\"01\",\"premiumStdrAmount\":100000,\"stdrItmAt\":null,\"premiumStdrDstrctLclsfCode\":\"20\",\"premiumStdrBrandGroupCode\":\"02\",\"hghnetprcAvrgPurchsPrmpc\":0,\"brandGroupCode\":\"02\",\"brandGroupChangeAmount\":1000,\"brandCode\":\"HINDAD\",\"brandNm\":\"HINDALCO AD\",\"brandChangeAmount\":2000,\"hghnetprcSleAmount\":0,\"slePremiumAmount\":213000,\"dstrctLclsfCode\":\"10\",\"dstrctChangeAmount\":110000,\"occrrncDe\":null,\"premiumNo\":\"PN0720230620086829\",\"termType\":null,\"termValue\":null,\"groupKey\":null,\"newSelPrice\":0,\"timePointCode\":null}";
		String fixPriceVOStr = "{\"premiumId\":null,\"hghnetprcAvrgPurchsPrmpc\":null,\"hghnetprcDstrctChangeAmount\":null,\"hghnetprcBrandGroupChangeAmount\":null,\"hghnetprcBrandChangeAmount\":null,\"gradChangeAmount\":null,\"avrgProfitAmount\":null,\"slePc\":null,\"hghnetprcSleAmount\":null,\"premiumNo\":null,\"metalCode\":null,\"itmSn\":0,\"dstrctLclsfCode\":null,\"dstrctLclsFName\":null,\"brandGroupCode\":null,\"brandCode\":null,\"entrpsNo\":null,\"entrpsGradNo\":0,\"puchasPc\":null,\"occrrncDe\":null,\"termType\":null,\"termValue\":null,\"sorinmallUnitPdCode\":null,\"lmttWt\":null,\"ntfcAmount\":null,\"lrgetrnsprtctAmount\":null,\"marginAmount\":null,\"itmCode\":null,\"goodsNm\":null,\"dspyGoodsNm\":null,\"dstrctLclsfNm\":null,\"brandGroupNm\":null,\"brandNm\":null,\"applcYm\":null,\"metalClCode\":null,\"orderWeight\":0}";
		String mbDlvrgBasStr = "{\"mberNo\":\"P0641\",\"entrpsNo\":\"C0240\",\"mberId\":\"sorin002006\",\"mberNm\":\"정대룡\",\"moblphonNo\":\"UZddw5rDHxtAAXbgw3+lDg==\",\"mberEmail\":\"jdrttl@sorincorp.com\",\"mberEmailRecptnAgreAt\":null,\"mberChrctrRecptnAgreAt\":null,\"entrpsnmKorean\":\"하임메탈\",\"entrpsnmEng\":null,\"cmpnyTlphonNo\":\"02-1588-1233\",\"postNo\":\"06110\",\"adres\":\"서울 강남구 논현동 142\",\"detailAdres\":\"7층 케이지트레이딩\",\"rnAdres\":\"서울 강남구 강남대로 542\",\"rnDetailAdres\":\"7층 케이지트레이딩\",\"refndAcnutNo\":\"YBt0rfEss846IChEXiYMxw==\",\"ewalletAcnutNo\":\"10byjAzQoTup8i4slg1GXw==\",\"entrpsGradNo\":null,\"dlvrgNm\":\"천안1창고\",\"receptPostNo\":\"31067\",\"receptAdres\":\"충남 천안시 동남구 신부동 42-9\",\"receptDetailAdres\":\" (신부동)?본사창고(천안1창고) 1층\",\"receptRnAdresas\":\"충남 천안시 동남구 가마골1길 5\",\"receptRnDetailAdres\":\"본사창고(천안1창고) 1층\",\"legaldongCode\":\"4413111800\",\"dlvrgCharger\":\"이재형\",\"dlvrgChargerCttpc\":\"LDaXkGjEklVLFVQ/4HIDMQ==\",\"dlvrgChargerEmail\":\"srec0006@sorincorp.com\",\"dailCdtlnPurchsWtLmt\":99999}";
		String itemPriceMatchingBlInfoVOStr1 = "{\"blNo\":\"CN_PMB_AL_0001\",\"wrhousCode\":\"SINL01\",\"dstrctLclsfCode\":\"10\",\"dstrctMlsfcCode\":\"1010\",\"wrhousCellLc\":\"AA\",\"metalCode\":\"7\",\"itmCode\":\"SLS0017_434\",\"brandCode\":\"HINDAD\",\"prductNm\":\"프라이머리 알루미늄 INGOT (P1020)\",\"chcy\":null,\"cstdyDeCo\":0,\"bsisWrhousngInvntry\":50000.000,\"bsisWrhousngBundleInvntry\":50000,\"bsisMaliciousBadnInvntry\":null,\"bsisMaliciousBadnBundleInvntry\":0,\"bsisInvntry\":50000.000,\"bsisBundleInvntry\":50000,\"sleSetupBundleCo\":450,\"sleSetupWt\":450.000,\"sleInvntryUnsleBnt\":25.000,\"sleInvntryUnsleBundleBnt\":25,\"ecSleComptInvntry\":425.000,\"ecSleComptBundleInvntry\":425,\"ecExchngOrderInvntry\":null,\"ecExchngOrderBundleInvntry\":0,\"ecDlivyInvntry\":null,\"ecDlivyBundleInvntry\":0,\"ecNootgInvntry\":425.000,\"ecNootgBundleInvntry\":425,\"wrhousNootgInvntry\":50000.000,\"wrhousNootgBundleInvntry\":50000,\"wrhousSleUnsetupInvntry\":49550.000,\"wrhousSleUnsetupBundleInvntry\":49550,\"trmendInvntry\":49575.000,\"trmendBundleInvntry\":49575,\"wrhousngDe\":\"2023-04-28\",\"entrDe\":null,\"arvlPrearngeDt\":null,\"netWt\":50000.000,\"grossWt\":50000.0000,\"netAvrgWt\":1.000,\"lotQy\":50000,\"sleSttusCode\":\"02\",\"purchsOrderNo\":\"14158_1\",\"purchsLineNo\":\"4\",\"frghtManageNo\":\"14158_100010001\",\"wrhousngSeCode\":\"1\",\"deleteAt\":\"N\",\"deleteDt\":null,\"frstRegisterId\":\"SOREC-IF-112(781)\",\"lastChangerId\":\"jaylee\",\"wrhousngPrearngeInvntryAt\":null,\"goodsNm\":\"PRIMARY AL INGOT P1020\",\"sleUnitCode\":\"01\",\"itmPrdlstKorean\":\"프라이머리 알루미늄 INGOT (P1020)\",\"brandGroupCode\":\"02\",\"brandNm\":\"HINDALCO AD\",\"itmSn\":434,\"priorRank\":126,\"ctrtcBeginPermWtRate\":5,\"ctrtcEndPermWtRate\":5,\"matchedOrderedBnt\":25,\"matchedSleInvntryUnsleBnt\":25.000,\"matchedSleInvntryUnsleBundleBnt\":25,\"realMatchedOrderedBnt\":25,\"realMatchedSleInvntryUnsleBnt\":25.000,\"realMatchedSleInvntryUnsleBundleBnt\":25,\"invntryUdt\":true,\"orderWeight\":25,\"slePossde\":null,\"sumSleInvntryUnsleBundleBnt\":null,\"remainQy\":0,\"leftOverWeight\":0,\"leftOverExistYn\":false}";
		String itemPriceMatchingBlInfoVOStr2 = "{\"blNo\":\"JT_HINDAD_AL_0001\",\"wrhousCode\":\"SINL01\",\"dstrctLclsfCode\":\"10\",\"dstrctMlsfcCode\":\"1010\",\"wrhousCellLc\":\"AA\",\"metalCode\":\"7\",\"itmCode\":\"SLS0017_434\",\"brandCode\":\"HINDAD\",\"prductNm\":\"프라이머리 알루미늄 INGOT (P1020)\",\"chcy\":null,\"cstdyDeCo\":0,\"bsisWrhousngInvntry\":50000.000,\"bsisWrhousngBundleInvntry\":50000,\"bsisMaliciousBadnInvntry\":null,\"bsisMaliciousBadnBundleInvntry\":0,\"bsisInvntry\":50000.000,\"bsisBundleInvntry\":50000,\"sleSetupBundleCo\":21225,\"sleSetupWt\":21225.000,\"sleInvntryUnsleBnt\":25.000,\"sleInvntryUnsleBundleBnt\":25,\"ecSleComptInvntry\":21200.000,\"ecSleComptBundleInvntry\":21200,\"ecExchngOrderInvntry\":null,\"ecExchngOrderBundleInvntry\":0,\"ecDlivyInvntry\":904.636,\"ecDlivyBundleInvntry\":900,\"ecNootgInvntry\":20295.400,\"ecNootgBundleInvntry\":20300,\"wrhousNootgInvntry\":49095.364,\"wrhousNootgBundleInvntry\":49100,\"wrhousSleUnsetupInvntry\":28774.964,\"wrhousSleUnsetupBundleInvntry\":28775,\"trmendInvntry\":28799.964,\"trmendBundleInvntry\":28800,\"wrhousngDe\":\"2023-06-08\",\"entrDe\":null,\"arvlPrearngeDt\":null,\"netWt\":50000.000,\"grossWt\":50000.0000,\"netAvrgWt\":1.000,\"lotQy\":50000,\"sleSttusCode\":\"02\",\"purchsOrderNo\":\"16000_1\",\"purchsLineNo\":\"4\",\"frghtManageNo\":\"16000_100010001\",\"wrhousngSeCode\":\"1\",\"deleteAt\":\"N\",\"deleteDt\":null,\"frstRegisterId\":\"SOREC-IF-112(793)\",\"lastChangerId\":\"jaylee\",\"wrhousngPrearngeInvntryAt\":null,\"goodsNm\":\"PRIMARY AL INGOT P1020\",\"sleUnitCode\":\"01\",\"itmPrdlstKorean\":\"프라이머리 알루미늄 INGOT (P1020)\",\"brandGroupCode\":\"02\",\"brandNm\":\"HINDALCO AD\",\"itmSn\":434,\"priorRank\":126,\"ctrtcBeginPermWtRate\":5,\"ctrtcEndPermWtRate\":5,\"matchedOrderedBnt\":25,\"matchedSleInvntryUnsleBnt\":25.000,\"matchedSleInvntryUnsleBundleBnt\":25,\"realMatchedOrderedBnt\":25,\"realMatchedSleInvntryUnsleBnt\":25.000,\"realMatchedSleInvntryUnsleBundleBnt\":25,\"invntryUdt\":true,\"orderWeight\":25,\"slePossde\":null,\"sumSleInvntryUnsleBundleBnt\":null,\"remainQy\":0,\"leftOverWeight\":0,\"leftOverExistYn\":false}";
		
		String commFtrsFshgMngVOStr = "{\"applcDe\":\"20220701\",\"postnCode\":\"B\",\"metalCode\":\"7\",\"ftrsSkipBeloAt\":\"N\",\"ftrsSkipBeloAmount\":2000.000000,\"ftrsSkipExcessAt\":\"N\",\"ftrsSkipExcessAmount\":2000.000000,\"ftrsTick\":10,\"ftrsLimitTick\":15,\"lmeMdatCffcntAmount\":1.000000,\"ehgtMdatCffcntAmount\":1.000000,\"deleteDt\":null,\"deleteAt\":\"N\",\"frstRegisterId\":\"parksw\",\"lastChangerId\":\"parksw\",\"skipAt\":\"N\",\"quoteUnit\":0.5}";
		String entrpsSetleMnInfoStr = "{\"wrtmTotUseAt\":\"Y\",\"mrtggGrntyTotUseAt\":\"Y\",\"wrtmReqstAt\":\"Y\",\"mrtggGrntyReqstAt\":\"Y\",\"arrrgCo\":0,\"acdntCo\":0,\"sleUnitWt\":25,\"oncePurchsWtLmt\":100,\"onedePurchsWtLmt\":10000,\"cdtlnManagePntArrrgCo\":3,\"cdtlnManagePntAcdntCo\":1,\"cdInrst\":0.013900000,\"cdInrstUseAt\":\"Y\",\"mrtggGrntyNintrDaycnt\":15,\"mrtggGrntySorinsuprrAddiInrst\":0.015000,\"mrtggGrntyFyerBankingDaycnt\":365,\"cdtlnSctn\":10,\"mrtggGrntyPermBeginPd\":0,\"mrtggGrntyPermRepyPd\":45,\"purchsInclnGrad\":\"A0\",\"purchsInclnGradNm\":\"대량구매형(19~21%)\",\"wrtmAuthorRateDcmlpoint\":21.00,\"endPcAgo\":3046000,\"sctnBeginAmount\":3000000,\"sctnEndAmount\":3250000,\"sctnAvrgAmount\":3125000,\"wrtmMummSetlePrarndeCnd\":2,\"mrtgggrntyScritsissuFeeCmpnstnRate\":1.000000,\"mrtgggrntyScritsissuFeeCmpnstnCsbyRate\":0.001000,\"mrtggGrntyInsrncTariffDcmlpoint\":0.000000,\"cdtlnSvcSeCode\":\"02\",\"viewCdtlnSvcSeCode\":\"02\",\"viewCdtlnSvcSeNm\":\"케이지크레딧\",\"cdtlnSvcSeKeyForCss\":\"scredit\",\"totCdtlnInrstPt\":2.89,\"grntyNo\":\"SORIN20111125-03\",\"entrpsMrtggCntrctSn\":7,\"mrtggGrntyFeeBndMbyAt\":null,\"grntyTmlmtBeginDe\":\"20230609\",\"grntyTmlmtEndDe\":\"20240630\",\"sorinCredtUseAt\":\"Y\",\"cdtlnCntrctNo\":\"640488\"}";
		
		OrderModel orderModel;
		ItPurchsInfoBas itPurchsInfoBas;
		PrSelVO prSelVO;
		FixPriceVO fixSelVO;
		OrPricingBasVO orPricingBas;
		LivePremiumVO livePremiumVO;
		FixPriceVO fixPriceVO;
		MbDlvrgBasVO mbDlvrgBas;
		
		ItemPriceMatchingBlInfoVO itemPriceMatchingBlInfoVO1;
		ItemPriceMatchingBlInfoVO itemPriceMatchingBlInfoVO2;
		List<ItemPriceMatchingBlInfoVO> blList = new ArrayList<ItemPriceMatchingBlInfoVO>();
		
		ItemPriceMatchingBlInfoVO blDetail;
		CommFtrsFshgMngVO commFtrsFshgMngVO;
		
		OrderEntrpsSetleMnVO entrpsSetleMnInfo;
		
		try {
			orderModel = objectMapper.readValue(orderModelStr, OrderModel.class);
				itPurchsInfoBas = objectMapper.readValue(itPurchsInfoBasStr, ItPurchsInfoBas.class);
				itPurchsInfoBas.setFrstRegistDt(Timestamp.valueOf("2023-06-09 12:09:32.803"));
				itPurchsInfoBas.setLastChangeDt(Timestamp.valueOf("2023-09-25 15:47:54.07"));
			orderModel.setItPurchsInfoBas(itPurchsInfoBas);
				prSelVO = objectMapper.readValue(prSelVOStr, PrSelVO.class);
				prSelVO.setFrstRegistDt(Timestamp.valueOf("2023-09-26 16:03:52.647"));
				prSelVO.setLastChangeDt(Timestamp.valueOf("2023-09-26 16:03:52.647"));
			orderModel.setPrSelVO(prSelVO);
				fixSelVO = objectMapper.readValue(fixSelVOStr, FixPriceVO.class);
			orderModel.setFixSelVO(fixSelVO);
				orPricingBas = objectMapper.readValue(orPricingBasVOStr, OrPricingBasVO.class);
				orPricingBas.setFrstRegistDt(Timestamp.valueOf("2023-09-26 16:03:00.807"));
				orPricingBas.setLastChangeDt(Timestamp.valueOf("2023-09-26 16:03:00.807"));
			orderModel.setOrPricingBas(orPricingBas);
				livePremiumVO = objectMapper.readValue(livePremiumVOStr, LivePremiumVO.class);
			orderModel.setLivePremiumVO(livePremiumVO);
				fixPriceVO = objectMapper.readValue(fixPriceVOStr, FixPriceVO.class);
			orderModel.setFixPriceVO(fixPriceVO);
				mbDlvrgBas = objectMapper.readValue(mbDlvrgBasStr, MbDlvrgBasVO.class);
			orderModel.setMbDlvrgBas(mbDlvrgBas);
				itemPriceMatchingBlInfoVO1 = objectMapper.readValue(itemPriceMatchingBlInfoVOStr1, ItemPriceMatchingBlInfoVO.class);
				itemPriceMatchingBlInfoVO1.setFrstRegistDt(Timestamp.valueOf("2023-05-10 17:27:12.567"));
				itemPriceMatchingBlInfoVO1.setLastChangeDt(Timestamp.valueOf("2023-09-26 16:02:05.01"));
				
				Map<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO> weightMappingCalculateValues1 = new HashMap<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO>();
				ItemPriceMatchingWeightCalculateValuesVO itemPriceMatchingWeightCalculateValuesVO1;
				String itemPriceMatchingWeightCalculateValuesVOStr1 = "{\"avgNum\":1.0,\"logicalWeight\":25.0,\"collectLogicalWeight\":25.0,\"minTonWeight\":23.75,\"maxTonWeight\":26.25,\"minBundle\":24.0,\"maxBundle\":26.0,\"collectBundle\":25.0,\"collectBundleLogicalWeight\":25.0}";
				itemPriceMatchingWeightCalculateValuesVO1 = objectMapper.readValue(itemPriceMatchingWeightCalculateValuesVOStr1, ItemPriceMatchingWeightCalculateValuesVO.class);
				weightMappingCalculateValues1.put(BigDecimal.valueOf(25), itemPriceMatchingWeightCalculateValuesVO1);
				itemPriceMatchingWeightCalculateValuesVOStr1 = "{\"avgNum\":1.0,\"logicalWeight\":25.0,\"collectLogicalWeight\":50.0,\"minTonWeight\":47.5,\"maxTonWeight\":52.5,\"minBundle\":48.0,\"maxBundle\":52.0,\"collectBundle\":50.0,\"collectBundleLogicalWeight\":50.0}";
				itemPriceMatchingWeightCalculateValuesVO1 = objectMapper.readValue(itemPriceMatchingWeightCalculateValuesVOStr1, ItemPriceMatchingWeightCalculateValuesVO.class);
				weightMappingCalculateValues1.put(BigDecimal.valueOf(50), itemPriceMatchingWeightCalculateValuesVO1);
				itemPriceMatchingWeightCalculateValuesVOStr1 = "{\"avgNum\":1.0,\"logicalWeight\":25.0,\"collectLogicalWeight\":75.0,\"minTonWeight\":71.25,\"maxTonWeight\":78.75,\"minBundle\":71.0,\"maxBundle\":78.0,\"collectBundle\":75.0,\"collectBundleLogicalWeight\":75.0}";
				itemPriceMatchingWeightCalculateValuesVO1 = objectMapper.readValue(itemPriceMatchingWeightCalculateValuesVOStr1, ItemPriceMatchingWeightCalculateValuesVO.class);
				weightMappingCalculateValues1.put(BigDecimal.valueOf(75), itemPriceMatchingWeightCalculateValuesVO1);
				itemPriceMatchingWeightCalculateValuesVOStr1 = "{\"avgNum\":1.0,\"logicalWeight\":25.0,\"collectLogicalWeight\":100.0,\"minTonWeight\":95.0,\"maxTonWeight\":105.0,\"minBundle\":95.0,\"maxBundle\":105.0,\"collectBundle\":100.0,\"collectBundleLogicalWeight\":100.0}";
				itemPriceMatchingWeightCalculateValuesVO1 = objectMapper.readValue(itemPriceMatchingWeightCalculateValuesVOStr1, ItemPriceMatchingWeightCalculateValuesVO.class);
				weightMappingCalculateValues1.put(BigDecimal.valueOf(100), itemPriceMatchingWeightCalculateValuesVO1);
				
				itemPriceMatchingBlInfoVO1.setWeightMappingCalculateValues(weightMappingCalculateValues1);
				
				blList.add(itemPriceMatchingBlInfoVO1);
				
				itemPriceMatchingBlInfoVO2 = objectMapper.readValue(itemPriceMatchingBlInfoVOStr2, ItemPriceMatchingBlInfoVO.class);
				itemPriceMatchingBlInfoVO2.setFrstRegistDt(Timestamp.valueOf("2023-06-09 12:09:32.727"));
				itemPriceMatchingBlInfoVO2.setLastChangeDt(Timestamp.valueOf("2023-09-26 16:02:19.65"));
				
				Map<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO> weightMappingCalculateValues2 = new HashMap<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO>();
				ItemPriceMatchingWeightCalculateValuesVO itemPriceMatchingWeightCalculateValuesVO2;
				String itemPriceMatchingWeightCalculateValuesVOStr2 = "{\"avgNum\":1.0,\"logicalWeight\":25.0,\"collectLogicalWeight\":25.0,\"minTonWeight\":23.75,\"maxTonWeight\":26.25,\"minBundle\":24.0,\"maxBundle\":26.0,\"collectBundle\":25.0,\"collectBundleLogicalWeight\":25.0}";
				itemPriceMatchingWeightCalculateValuesVO2 = objectMapper.readValue(itemPriceMatchingWeightCalculateValuesVOStr2, ItemPriceMatchingWeightCalculateValuesVO.class);
				weightMappingCalculateValues2.put(BigDecimal.valueOf(25), itemPriceMatchingWeightCalculateValuesVO2);
				itemPriceMatchingWeightCalculateValuesVOStr2 = "{\"avgNum\":1.0,\"logicalWeight\":25.0,\"collectLogicalWeight\":50.0,\"minTonWeight\":47.5,\"maxTonWeight\":52.5,\"minBundle\":48.0,\"maxBundle\":52.0,\"collectBundle\":50.0,\"collectBundleLogicalWeight\":50.0}";
				itemPriceMatchingWeightCalculateValuesVO2 = objectMapper.readValue(itemPriceMatchingWeightCalculateValuesVOStr2, ItemPriceMatchingWeightCalculateValuesVO.class);
				weightMappingCalculateValues2.put(BigDecimal.valueOf(50), itemPriceMatchingWeightCalculateValuesVO2);
				itemPriceMatchingWeightCalculateValuesVOStr2 = "{\"avgNum\":1.0,\"logicalWeight\":25.0,\"collectLogicalWeight\":75.0,\"minTonWeight\":71.25,\"maxTonWeight\":78.75,\"minBundle\":71.0,\"maxBundle\":78.0,\"collectBundle\":75.0,\"collectBundleLogicalWeight\":75.0}";
				itemPriceMatchingWeightCalculateValuesVO2 = objectMapper.readValue(itemPriceMatchingWeightCalculateValuesVOStr2, ItemPriceMatchingWeightCalculateValuesVO.class);
				weightMappingCalculateValues2.put(BigDecimal.valueOf(75), itemPriceMatchingWeightCalculateValuesVO2);
				itemPriceMatchingWeightCalculateValuesVOStr2 = "{\"avgNum\":1.0,\"logicalWeight\":25.0,\"collectLogicalWeight\":100.0,\"minTonWeight\":95.0,\"maxTonWeight\":105.0,\"minBundle\":95.0,\"maxBundle\":105.0,\"collectBundle\":100.0,\"collectBundleLogicalWeight\":100.0}";
				itemPriceMatchingWeightCalculateValuesVO2 = objectMapper.readValue(itemPriceMatchingWeightCalculateValuesVOStr2, ItemPriceMatchingWeightCalculateValuesVO.class);
				weightMappingCalculateValues2.put(BigDecimal.valueOf(100), itemPriceMatchingWeightCalculateValuesVO2);
				
				itemPriceMatchingBlInfoVO2.setWeightMappingCalculateValues(weightMappingCalculateValues2);
				
				blList.add(objectMapper.readValue(itemPriceMatchingBlInfoVOStr2, ItemPriceMatchingBlInfoVO.class));
				
			orderModel.setBlList(blList);
			
				blDetail = blList.get(0);
			orderModel.setBlDetail(blDetail);
			
				commFtrsFshgMngVO = objectMapper.readValue(commFtrsFshgMngVOStr, CommFtrsFshgMngVO.class);
				commFtrsFshgMngVO.setFrstRegistDt(Timestamp.valueOf("2022-06-02 14:44:41.817"));
				commFtrsFshgMngVO.setLastChangeDt(Timestamp.valueOf("2022-06-15 17:44:00.82"));
			orderModel.setCommFtrsFshgMngVO(commFtrsFshgMngVO);
				entrpsSetleMnInfo = objectMapper.readValue(entrpsSetleMnInfoStr, OrderEntrpsSetleMnVO.class);
				List<OrderPurchsInclnGradeVO> entrpsPurchsInclnGradeInfoAllList = new ArrayList<OrderPurchsInclnGradeVO>();
				String orderPurchsInclnGradeVOStr = "{\"purchsInclnGrad\":\"A0\",\"purchsInclnGradNm\":\"대량구매형(19~21%)\",\"wrtmAuthorRateDcmlpoint\":21.00,\"selectableAt\":\"Y\",\"beginStepRate\":19,\"endStepRate\":21,\"purchsInclnStepRate\":20,\"purchsInclnStepAmount\":625000}";
				OrderPurchsInclnGradeVO orderPurchsInclnGradeVO;
				orderPurchsInclnGradeVO = objectMapper.readValue(orderPurchsInclnGradeVOStr, OrderPurchsInclnGradeVO.class);
				entrpsPurchsInclnGradeInfoAllList.add(orderPurchsInclnGradeVO);
				orderPurchsInclnGradeVOStr = "{\"purchsInclnGrad\":\"B0\",\"purchsInclnGradNm\":\"자주구매형(28~32%)\",\"wrtmAuthorRateDcmlpoint\":31.00,\"selectableAt\":\"Y\",\"beginStepRate\":29,\"endStepRate\":31,\"purchsInclnStepRate\":30,\"purchsInclnStepAmount\":937500}";
				orderPurchsInclnGradeVO = objectMapper.readValue(orderPurchsInclnGradeVOStr, OrderPurchsInclnGradeVO.class);
				entrpsPurchsInclnGradeInfoAllList.add(orderPurchsInclnGradeVO);
				orderPurchsInclnGradeVOStr = "{\"purchsInclnGrad\":\"C0\",\"purchsInclnGradNm\":\"계획구매형(38~42%)\",\"wrtmAuthorRateDcmlpoint\":40.0,\"selectableAt\":\"Y\",\"beginStepRate\":38,\"endStepRate\":42,\"purchsInclnStepRate\":40,\"purchsInclnStepAmount\":1250000}";
				orderPurchsInclnGradeVO = objectMapper.readValue(orderPurchsInclnGradeVOStr, OrderPurchsInclnGradeVO.class);
				entrpsPurchsInclnGradeInfoAllList.add(orderPurchsInclnGradeVO);
				orderPurchsInclnGradeVOStr = "{\"purchsInclnGrad\":\"D0\",\"purchsInclnGradNm\":\"안정구매형(48~52%)\",\"wrtmAuthorRateDcmlpoint\":50.0,\"selectableAt\":\"Y\",\"beginStepRate\":48,\"endStepRate\":52,\"purchsInclnStepRate\":50,\"purchsInclnStepAmount\":1562500}";
				orderPurchsInclnGradeVO = objectMapper.readValue(orderPurchsInclnGradeVOStr, OrderPurchsInclnGradeVO.class);
				entrpsPurchsInclnGradeInfoAllList.add(orderPurchsInclnGradeVO);
				entrpsSetleMnInfo.setEntrpsPurchsInclnGradeInfoAllList(entrpsPurchsInclnGradeInfoAllList);
			orderModel.setEntrpsSetleMnInfo(entrpsSetleMnInfo);
				
			testOrder.doOrder(orderModel, threadPoolTaskExecutor);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
