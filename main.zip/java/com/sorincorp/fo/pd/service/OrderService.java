package com.sorincorp.fo.pd.service;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.ui.ModelMap;

import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.order.model.OrderEntrpsSetleMnVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.fo.pd.model.FixingPcOrderPossWtCeckVO;
import com.sorincorp.fo.pd.model.LimitOrderModel;
import com.sorincorp.fo.pd.model.OrderEtcPrice;
import com.sorincorp.fo.pd.model.OrderLimitReceiptVO;
import com.sorincorp.fo.pd.model.SettleSttusDeVO;

/**
 * OrderService.java
 * 주문 Service 인터페이스
 * @version
 * @since 2022. 9. 21.
 * @author srec0049
 */
public interface OrderService {

	/**
	 * <pre>
	 * 처리내용: 현재 MT기준 배송비를 가저온다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	HashMap<String, Object> getDlvyPrice(OrderModel orderModel) throws CommCustomException, Exception;

	/**
	 * <pre>
	 * 처리내용: 쿠폰 할인 가격 조회
	 * </pre>
	 * @date 2022. 8. 16.
	 * @author jhcha
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 16.			jhcha			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	HashMap<String, Object> getDiscntCouponPrice(OrderModel orderModel) throws CommCustomException, Exception;

	/**
	 * <pre>
	 * 처리내용: (판매 방식 코드 , 배송 수단 코드, 금속 코드) 조건에 의한 현재 시각, 당일배송 불가능 상태 및 당일배송 종료 시간을 맵으로 가져온다.
	 * </pre>
	 * @date 2022. 3. 10.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 3. 10.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws CommCustomException
	 * @throws Exception
	 */
	public Map<String, Object> getSameDayDeliveryInfo(OrderModel orderModel) throws CommCustomException, Exception;

	/**
	 * <pre>
	 * 처리내용: 주문 초기 데이터 설정
	 * </pre>
	 * @date 2023. 5. 10.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws CommCustomException
	 * @throws Exception
	 */
	public void initOrderData(OrderModel orderModel) throws CommCustomException, Exception;

	/**
	 * <pre>
	 * 처리내용: 최적의 BL리스트 가져오기 및 상품 재고 검색 체크
	 * </pre>
	 * @date 2023. 5. 10.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws CommCustomException
	 * @throws Exception
	 */
	public void orderBlList(OrderModel orderModel) throws CommCustomException, Exception;

	/**
	 * <pre>
	 * 처리내용: 주문로직을 실행 시킨다.
	 * </pre>
	 * @date 2021. 8. 24.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 24.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	void doOrder(OrderModel orderModel) throws CommCustomException, Exception;

	/**
	 * <pre>
	 * 처리내용: 주문 정합성 체크 1단계
	 * 1. 증거금 주문 또는 B2B 전자상거래보증 주문일 경우 여신 관리 패널티 연체 건수 및 사고 건수 체크
	 * 2. 증거금 주문일 경우 구매성향등급 존재 여부 및 증거금 사용 여부 유효성 체크
	 * 3. 증거금 최소 결제 예정일 조건 체크
	 * 4. B2B 전자상거래보증 주문일 경우 담보 보증 사용 여부 및 담보 보증 계약 여부 유효성 및 전자상거래보증 한도 설정 여부 체크
	 *   4-1. 케이지크레딧일 경우 여신 계약 번호 및 총 한도 유효성 체크 추가
	 * 5. 해당 고객사의 메탈사용여부를 체크
	 * 6. 휴일에 따른 유효성 체크
	 * 7. 당일배송 여부 체크
	 * 8. 회원구분코드가 자금담당(04)일 경우 체크
	 * 9. LME 사이드카 발동여부
	 * 10. 환율 사이드카 발동여부
	 * 11. 업체 동시 -> 오늘날짜 기준
	 * 12. 회원 및 업체, 배송지 정보 가져오기 및 존재 여부 체크
	 * 13. 기업뱅킹 환불 요청 여부 유효성 체크[진행중(1), 완료(0)]
	 * 14. 케이지트레이딩 환불 요청 유효성 체크 [01:요청, 05:처리중]
	 * 15. 중량 변동 가져오기[유효성은 아니지만 계산 전에 가져오기 위해 넣음]
	 * 16. 상품별 최대 구매 가능 중량(오늘날짜 기준) 한도 유효성 체크
	 * 17. 업체별 1회 구매 중량, 1일 구매 중량(오늘날짜 기준) 한도 유효성 체크
	 * 18. 주문 프라이싱 정보 가져오기 및 프라이싱 존재 체크
	 * 19. 판매 가격 및 프리미엄 가격에 따른 주문 금액 정보 계산 및 체크
	 *  1) LIVE일 경우
	 *   (1) 실시간 판매 가격 정보 조회 및 체크
	 *   (2) 선물 SKIP 여부, 선물 틱 설정 값 등 정보 조회
	 *   (3) LME 순번 값 체크 및 LME 수집 시간 간격 체크
	 *   (4) 환률 순번 값 체크 및 환률 수집 시간 간격 체크
	 *   (5) 프리미엄 가격 정보 조회 및 체크
	 *   (6) 가격 정보 셋팅 (배송비, 공급가, 부가세, 판매가 계산 제외 - 배송비 때문)[유효성은 아니지만 계산하기 위해 넣음]
	 *  2) 고정가일 경우
	 *   (1) 고정가 판매 가격 정보  및 프리미엄 가격 조회, 체크
	 *   (2) 가격 정보 셋팅 (배송비, 공급가, 부가세, 판매가 계산 제외 - 배송비 때문)[유효성은 아니지만 계산하기 위해 넣음]
	 * </pre>
	 * @date 2023. 5. 10.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws CommCustomException
	 * @throws Exception
	 */
	public void orderValidation(OrderModel orderModel) throws CommCustomException, Exception;

	/**
	 * <pre>
	 * 처리내용: 배송비, 공급가, 부가세, 판매가 구하기 및 주문 정합성 체크 2단계 (판매가와 비교해야하기 위해)
	 * 20. 이월렛 잔액 체크 또는 담보 보증 남은 한도 체크
	 *  1) 이월렛 잔액 체크일 경우
	 *   (1) Ewallet 잔금 조회 API 통신 체크
	 *   (2) Ewallet 금액 부족 체크
	 *  2) (전자상거래보증 or 케이지크레딧) 남은 한도 체크일 경우
	 *   (1) (전자상거래보증 or 케이지크레딧) 남은 한도 부족 체크
	 * </pre>
	 * @date 2023. 5. 11.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 11.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @param ewalletMoneyCheckStatus
	 * @param orderWt
	 * @param newGetBlListUseStatus
	 * @throws CommCustomException
	 * @throws Exception
	 */
	public void setPriceInfoByExpectDlvrf(OrderModel orderModel, boolean ewalletMoneyCheckStatus, int orderWt, boolean newGetBlListUseStatus) throws CommCustomException, Exception;

	/**
	 * <pre>
	 * 처리내용: 최적의 BL리스트 기준으로 입고예정재고여부(입고구분에의한) 파악 및 WMS 실시간 재고 파악 및 재고 차감, 주문 정합성 체크 3단계 (최적의 BL에서 BL번호 필요)
	 * 21. 배송요율 유효성 체크
	 *  1) 배송요율 정보 및 회원_배송지 정보 체크
	 *  2) 배송 불가 및 서비스 불가능 지역 체크
	 * 22. 실시간 물류 CAPA 확인[SOREC-IF-126] 유효성 체크
	 * 23. WMS 실시간 재고 체크
	 *  1) 실시간 재고 API 호출 체크 (현재 사용하지 않음)
	 *  2) 실시간 재고 수량 체크 (현재 사용하지 않음)
	 * </pre>
	 * @date 2023. 5. 11.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 11.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws CommCustomException
	 * @throws Exception
	 */
	public void orderInvntryChk(OrderModel orderModel) throws CommCustomException, Exception;

	/**
	 * <pre>
	 * 처리내용: 주문에 필요한 데이터를 DB에 INSERT 한다.
	 * </pre>
	 * @date 2023. 5. 11.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 11.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws CommCustomException
	 * @throws Exception
	 */
	public void orderInstTblBase(OrderModel orderModel) throws CommCustomException, Exception;

	/**
	 * <pre>
	 * 처리내용: 삼성선물에 공통코드(CO_CMMN_CD-CODE_NUMBER_REFRNONE)의 삼성선물 주문 단위 중량 단위로 주문 호출한다.
	 * </pre>
	 * @date 2023. 5. 11.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 11.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws CommCustomException
	 * @throws Exception
	 */
	public void callSamsung(OrderModel orderModel) throws CommCustomException, Exception;

	/**
	 * <pre>
	 * 처리내용: 주문완료시 후처리 작업으로 별로의 스레드를 통해 각자 서비스들이 움직인다.
	 * </pre>
	 * @date 2023. 5. 11.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 11.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 */
	public void orderComplete(OrderModel orderModel);

	/**
	 * <pre>
	 * 처리내용: 주문완료시 후처리 작업으로 별로의 스레드를 통해 각자 서비스들이 움직인다. (로직은 빈 껍데기)
	 * </pre>
	 * @date 2023. 5. 23.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 23.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 */
	public void orderCompleteThreadTest(OrderModel orderModel);

	/**
	 * <pre>
	 * 처리내용: 주문 실패 시 재고 원복 및 원장 테이블 수정을 진행한다.
	 * </pre>
	 * @date 2023. 5. 11.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 11.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 */
	public void orderFail(OrderModel orderModel);

	/**
	 * <pre>
	 * 처리내용: 주문 완료 정보를 조회한다.
	 * </pre>
	 * @date 2021. 9. 8.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 8.			srec0043		최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	OrderLimitReceiptVO selectOrderReceipt(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이월렛 정보를 가저온다 ( EC DB 기준 )
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	OrderEtcPrice getEwalletInfo(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 전자상거래보증 한도조회 가져오기
	 *  MRTGG_GRNTY_LMT_STATUS(담보 보증 한도 상태)
	 *   00 : 담보 보증 한도 설정 정상
	 *   01 : 담보 보증 한도가 설정되어 있지 않음
	 *   02 : 담보 보증 한도가 설정되어 있으나 사용 내역이 없음
	 *   99 : 기타 상황
	 *   EMPTY : 업체 정보가 존재하지 않음
	 * </pre>
	 * @date 2022. 6. 30.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 30.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	OrderEtcPrice getMrtggGrntyLmtInqire(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체 결제 수단 정보 가져오기
	 * : 업체의 증거금과 전자상거래보증 사용 권한(증거금 총 사용 여부, 전자상거래보증 또는 케이지크레딧 총 사용 여부), 증거금 신청 여부(화면단 별도 체크), 담보 보증 신청 여부(화면단 별도 체크), 연체 및 사고 건수
	 * : 증거금 최소 결제 예정일 조건
	 * : 판매 단위 중량 (주문 가능 MIN 중량 및 주문 단위), 1회 구매 중량 한도 (주문 가능 MAX 중량)
	 * : 업체 별 평가 등급 정보(여신 구간, 담보 보증 허용 상환 기간)
	 * : 업체 구매성향 등급정보(업체 구매성향등급, 업체 구매성향등급 명, 증거금 권한 비율)
	 * : 구매성향등급에 따른 단계별 금액(LME 전일 종가[케이지몰일 경우 현재 단가], 구간 종료 금액, 구간 평균 금액)
	 * : 업체의 선택 가능한 구매등급을 표시한 전체 정보 리스트
	 * : 여신 정보(금리 정보, 패널티 정보)
	 * </pre>
	 * @date 2022. 7. 1.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 1.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	OrderEntrpsSetleMnVO getEntrpsSetleMnInfo(String entrpsNo, String sleMthdCode, String metalCode, int itmSn, String dstrctLclsfCode, String brandGroupCode, String brandCode, String sleMthdDetailCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지트레이딩 직인 정보를 가저온다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param response
	 * @throws Exception
	 */
	void getSorinSign(HttpServletResponse response) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이벤트 휴일 관리 기반 기준일에 영업 일자 만큼 계산된 날짜 리턴(기준일 포함), 리턴 대상 날짜가 휴일이면 그 다음 날짜를 리턴한다.
	 * </pre>
	 * @date 2022. 8. 1.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 1.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param settleSttusDeVO
	 * @return
	 * @throws Exception
	 */
	String getSettleSttusDe(SettleSttusDeVO settleSttusDeVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 권역 대분류별 아이템별 업체별 케이지몰 주문 가능 중량을 체크하여 주문 가능 여부와 총 실제 주문 중량을 반환한다[Y : 주문 가능, N : 주문 불가능]
	 * </pre>
	 * @date 2023. 3. 17.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 17.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param dstrctLclsfCode
	 * @param itmSn
	 * @param entrpsNo
	 * @param sorinmallUnitPdCode
	 * @param lmttWtStr
	 * @param orderWt
	 * @param sleMthdCode
	 * @return
	 * @throws Exception
	 */
	public FixingPcOrderPossWtCeckVO getFixingPcOrderPossWtCeckInfo(String dstrctLclsfCode, int itmSn, String entrpsNo, String sorinmallUnitPdCode
			, String lmttWtStr, int orderWt, String sleMthdCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 권역 대분류별 아이템별 업체별 케이지몰 주문 가능 중량을 체크하여 가능 여부를 Y, N 값으로 반환한다[Y : 주문 가능, N : 주문 불가능]
	 * </pre>
	 * @date 2023. 3. 7.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 7.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param dstrctLclsfCode
	 * @param itmSn
	 * @param entrpsNo
	 * @param sorinmallUnitPdCode
	 * @param lmttWtStr
	 * @param orderWt
	 * @param sleMthdCode
	 * @return
	 * @throws Exception
	 */
	public String getFixingPcOrderPossWtCeck(String dstrctLclsfCode, int itmSn, String entrpsNo, String sorinmallUnitPdCode
			, String lmttWtStr, int orderWt, String sleMthdCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 지정가 주문로직을 실행 시킨다.
	 * </pre>
	 * @date 2023. 4. 28.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 28.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param limitOrderModel
	 */
	void doLimitOrder(@Valid LimitOrderModel limitOrderModel) throws CommCustomException, Exception;

	/**
	 * <pre>
	 * 처리내용: 평균가 주문로직을 실행 시킨다.
	 * </pre>
	 * @date 2023. 10. 19.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 19.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws CommCustomException
	 * @throws Exception
	 */
	void doAvrgpcOrder(OrderModel orderModel) throws CommCustomException, Exception;

	/**
	 * <pre>
	 * 처리내용: 평균가 주문용 기본 모달창 호출 시 공통사용 데이터 세팅
	 * </pre>
	 * @date 2023. 11. 2.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 2.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @param model
	 * @throws Exception
	 */
	void setAvrgpcOrderBaseData(OrderModel orderModel, ModelMap model) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 누적 평균 가격 목록 조회
	 * </pre>
	 * @date 2023. 11. 2.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 2.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> getAccmltAvrgpcList(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 평균가 주문 정보 Table Insert
	 * </pre>
	 * @date 2023. 11. 2.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 2.			srec0066			최초작성
	 * 2024. 2. 21.			srec0053			서비스 메소드의 접근지정자를 public 으로 변경
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws CommCustomException
	 * @throws Exception
	 */
	void avrgpcOrderInstTblBase(@Valid OrderModel orderModel) throws CommCustomException, Exception;
	
	/**
	 * <pre>
	 * 처리내용: 가단가-지정가 터치된 주문 체결 처리
	 * </pre>
	 * @date 2024. 11. 14.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 14.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	public void procLimitOrderCnclsByPrvsnl(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 외부 하나은행 FX를 호출
	 * </pre>
	 * @date 2024. 10. 7.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 7.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 */
	public void extrlCallFx(OrderModel orderModel);
}
