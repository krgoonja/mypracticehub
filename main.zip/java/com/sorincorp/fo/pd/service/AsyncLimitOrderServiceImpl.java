package com.sorincorp.fo.pd.service;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.order.model.CommLimitGroupModel;
import com.sorincorp.comm.order.model.CommLimitOrderModel;
import com.sorincorp.comm.order.model.CommOrLimitOrderBasVO;
import com.sorincorp.comm.order.model.MbDlvrgBasVO;
import com.sorincorp.comm.order.model.OrderEntrpsSetleMnVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.comm.order.service.CommLimitOrderService;
import com.sorincorp.comm.order.service.CommPrvsnlOrderService;
import com.sorincorp.fo.my.model.OrderPrvsnlDcsnProcessVO;
import com.sorincorp.fo.my.service.OrderPrvsnlDcsnService;

import lombok.extern.slf4j.Slf4j;

/**
 * AsyncLimitOrderServiceImpl.java
 * 지정가 그룹 주문 Service 구현체 클래스
 *
 * @version
 * @since 2023. 4. 28.
 * @author srec0049
 */
@Slf4j
@Service
public class AsyncLimitOrderServiceImpl implements AsyncLimitOrderService {

	/**
	 * 지정가 그룹 스레드 풀
	 */
	@Resource(name = "limitGroupThreadPool")
	private ThreadPoolTaskExecutor limitGroupTaskExecutor;

	/**
	 * 지정가 주문 스레드 풀
	 */
	@Resource(name = "limitOrderThreadPool")
	private ThreadPoolTaskExecutor limitOrderTaskExecutor;

	/**
	 * 지정가 주문 공통 Service
	 */
	@Autowired
	CommLimitOrderService commLimitOrderService;

	/**
	 * 가단가 주문 공통 Service
	 */
	@Autowired
	CommPrvsnlOrderService commPrvsnlOrderService;

	/**
	 * 주문 Service
	 */
	@Autowired
	OrderService orderService;
	
	/**
	 * 단가확정하기 관련 Service
	 */
	@Autowired
	OrderPrvsnlDcsnService orderPrvsnlDcsnService;


	/**
	 * 지정가 그룹 주문 진행
	 */
	@Override
	public void doLimitGroupOrder(CommLimitGroupModel commLimitGroupModel) throws CommCustomException, Exception {
		Runnable limitGroupRun = () -> {
			try {
				log.info(">> [doLimitGroupOrder] commLimitGroupModel : " + String.valueOf(commLimitGroupModel));

				// 타겟 지정가 주문 번호 리스트 가져오기
				List<String> targetLimitOrderNoList = commLimitGroupModel.getTargetLimitOrderNoList();

				for(String targetLimitOrderNo : targetLimitOrderNoList) {
					CommLimitOrderModel getLimitOrderModel = commLimitGroupModel.getLimitOrderModelMap().get(targetLimitOrderNo);

					// 지정가 주문 번호로 해당 지정가 주문 내역 가져오기 [단일]
					CommOrLimitOrderBasVO selectCommOrLimitOrderBas = commLimitOrderService.selectCommOrLimitOrderBas(targetLimitOrderNo);

					MbDlvrgBasVO selectOrMbEntrpsInfoByLimitOrder = commLimitOrderService.selectOrMbEntrpsInfoByLimitOrder(selectCommOrLimitOrderBas.getMberNo());

					// 지정가 주문 번호에 해당하는 지정가 주문 내역으로 주문 VO 객체를 재구성한다
					OrderModel orderModel = getLimitOrderModel.getOrderModel(selectCommOrLimitOrderBas);
					// 지정가 구분 [가격 도달 시 진행되는 주문: touch, 그 외: null]
					orderModel.setLimitSection("touch");
					// 멤버 아이디 set
					orderModel.setMberId(commLimitGroupModel.getSystemId());
					// 멤버 정보 보충
					orderModel.getMbDlvrgBas().setDailCdtlnPurchsWtLmt(selectOrMbEntrpsInfoByLimitOrder.getDailCdtlnPurchsWtLmt()); // 일일 여신 구매 중량 한도
					orderModel.getMbDlvrgBas().setEntrpsGradNo(selectOrMbEntrpsInfoByLimitOrder.getEntrpsGradNo()); // 업체 등급 번호
					// 최적의 bl 리스트 set (바로구매 지정가 주문에서만 세팅되고, 계약구매 지정가 주문은 추후에 따로 세팅)
					orderModel.setBlList(getLimitOrderModel.getBlList());

					// 사용 쿠폰 내역 조회
					if(StringUtils.equals(orderModel.getCouponApplcAt(), "Y")){
						orderModel.setCouponList(commLimitOrderService.selectUsedCouponInfo(targetLimitOrderNo));
					}

					// 개별 지정가 주문 처리
					this.procEachLimitOrder(orderModel);
				}
			} catch (Exception e) {
				log.error("[doLimitGroupOrderThreadTest] exception commLimitGroupModel : " + String.valueOf(commLimitGroupModel));

				log.error("[doLimitGroupOrderThreadTest] e : " + e.getMessage());
				String stacktrace = ExceptionUtils.getStackTrace(e);
				log.error("[doLimitGroupOrderThreadTest] stacktrace : " + stacktrace);
			}
		};

		limitGroupTaskExecutor.execute(limitGroupRun);
	}

	/**
	 * <pre>
	 * 처리내용: 개별 지정가 주문 처리
	 * </pre>
	 * @date 2023. 5. 9.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 9.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws CommCustomException
	 * @throws Exception
	 */
	public void procEachLimitOrder(OrderModel orderModel) throws CommCustomException, Exception {
		Runnable limitOrderRun = () -> {
			log.info("[procEachLimitOrder] in~~");
			try {
				log.info("[procEachLimitOrder] orderModel : " + String.valueOf(orderModel));

				// 세금계산서보기 URL 세팅
				orderModel.setDocumentViewDomain("https://www.kztraders.com/my/papersManage/viewPapersManage"); // 20220401 이현진 세금계산서 url추가

				// 주문 초기 데이터 설정
				orderService.initOrderData(orderModel);

				log.warn("[procEachLimitOrder] initOrderData 설정 후 orderModel : " + String.valueOf(orderModel));

				/**
				 * 업체 결제 수단 정보 가져오기
				 * : 업체의 증거금과 (전자상거래보증 or 케이지크레딧) 사용 권한(증거금 총 사용 여부, (전자상거래보증 or 케이지크레딧) 총 사용 여부), 증거금 신청 여부(화면단 별도 체크), (전자상거래보증 or 케이지크레딧) 신청 여부(화면단 별도 체크), 연체 및 사고 건수
				 * : 증거금 최소 결제 예정일 조건
				 * : 판매 단위 중량 (주문 가능 MIN 중량 및 주문 단위), 1회 구매 중량 한도 (주문 가능 MAX 중량)
				 * : 업체 별 평가 등급 정보(여신 구간, 담보 보증 허용 상환 기간)
				 * : 업체 구매성향 등급정보(업체 구매성향등급, 업체 구매성향등급 명, 증거금 권한 비율)
				 * : 구매성향등급에 따른 단계별 금액(LME 전일 종가[케이지몰일 경우 현재 단가], 구간 종료 금액, 구간 평균 금액)
				 * : 업체의 선택 가능한 구매등급을 표시한 전체 정보 리스트
				 * : 여신 정보(금리 정보, 패널티 정보)
				 * : 담보 보증 보험 요율(마일리지에 사용)
				 * **/
				OrderEntrpsSetleMnVO entrpsSetleMnInfo = orderService.getEntrpsSetleMnInfo(orderModel.getEntrpsNo()
						, orderModel.getSleMthdCode(), orderModel.getMetalCode(), orderModel.getItmSn(), orderModel.getDstrctLclsfCode()
						, orderModel.getBrandGroupCode(), orderModel.getRealBrandCode(), orderModel.getSleMthdDetailCode());

				orderModel.setEntrpsSetleMnInfo(entrpsSetleMnInfo);

				// 최적의 BL은 지정가 그룹 처리 단계에서 가져옴, pass
				// 24-02-21 변경사항 : 계약구매 - 지정가 주문(0304)은 지정가 그룹 처리 단계에서 BL을 안 가져옴에 따라 해당 로직을 조건부로 추가
				if(StringUtils.equals(orderModel.getSleMthdDetailCode(), "0304")) {
					/**
		             * 계약구매 - 발주 완료된 할당 BL리스트정보 가져오기
		             * **/
					orderService.orderBlList(orderModel);
				}

				/** 주문 정합성 체크 1단계
				 * 1. 증거금 주문 또는 (전자상거래보증 or 케이지크레딧) 주문일 경우 여신 관리 패널티 연체 건수 및 사고 건수 체크
				 * 2. 증거금 주문일 경우 구매성향등급 존재 여부 및 증거금 사용 여부 유효성 체크
				 * 3. 증거금 최소 결제 예정일 조건 체크
				 * 4. (전자상거래보증 or 케이지크레딧) 주문일 경우 담보 보증 사용 여부 및 담보 보증 계약 여부 유효성 및 (전자상거래보증 or 케이지크레딧) 한도 설정 여부 체크
				 *   4-1. 케이지크레딧일 경우 여신 계약 번호 및 총 한도 유효성 체크 추가
				 * 5. 해당 고객사의 메탈사용여부를 체크
				 * 6. 휴일에 따른 유효성 체크
				 * 7. 당일배송 여부 체크
				 * 8. 회원구분코드가 자금담당(04)일 경우 체크
				 * 9. LME 사이드카 발동여부
				 * 10. 환율 사이드카 발동여부
				 * 11. 업체 동시 -> 오늘날짜 기준
				 * 12. 회원 및 업체, 배송지 정보 가져오기 및 존재 여부 체크
				 * 13. 기업뱅킹 환불 요청 여부 유효성 체크[진행중(1), 완료(0)]
				 * 14. 케이지트레이딩 환불 요청 유효성 체크 [01:요청, 05:처리중]
				 * 15. 중량 변동 가져오기[유효성은 아니지만 계산 전에 가져오기 위해 넣음]
				 * 16. 상품별 최대 구매 가능 중량(오늘날짜 기준) 한도 유효성 체크
				 * 17. 업체별 1회 구매 중량, 1일 구매 중량(오늘날짜 기준) 한도 유효성 체크
				 * 18. 주문 프라이싱 정보 가져오기 및 프라이싱 존재 체크
				 * 19. 판매 가격 및 프리미엄 가격에 따른 주문 금액 정보 계산 및 체크
				 *  1) LIVE일 경우
				 *   (1) 실시간 판매 가격 정보 조회 및 체크
				 *   (2) 선물 SKIP 여부, 선물 틱 설정 값 등 정보 조회
				 *   (3) LME 순번 값 체크 및 LME 수집 시간 간격 체크
				 *   (4) 환률 순번 값 체크 및 환률 수집 시간 간격 체크
				 *   (5) 프리미엄 가격 정보 조회 및 체크
				 *   (6) 가격 정보 셋팅 (배송비, 공급가, 부가세, 판매가 계산 제외 - 배송비 때문)[유효성은 아니지만 계산하기 위해 넣음]
				 *  2) 고정가일 경우
				 *   (1) 고정가 판매 가격 정보  및 프리미엄 가격 조회, 체크
				 *   (2) 가격 정보 셋팅 (배송비, 공급가, 부가세, 판매가 계산 제외 - 배송비 때문)[유효성은 아니지만 계산하기 위해 넣음]
				 * 99. 배송비 쿠폰 적용
				 * **/
				orderService.orderValidation(orderModel);

				/** 배송비, 공급가, 부가세, 판매가 구하기 및 주문 정합성 체크 2단계 (판매가와 비교해야하기 위해)
				 * 20. 쿠폰 적용여부 체크 및 금액계산
				 * 21. 이월렛 잔액 체크 또는 담보 보증 남은 한도 체크
				 *  1) 이월렛 잔액 체크일 경우
				 *   (1) 이월렛 잔금 조회 API 호출 체크
				 *   (2) 이월렛 금액 부족 체크
				 *  2) 담보 보증 남은 한도 체크일 경우
				 *   (1) 담보 보증 남은 한도 부족 체크
				 * **/
				/** 배송비, 공급가, 부가세, 판매가 구하기 20211112 **/
				orderService.setPriceInfoByExpectDlvrf(orderModel, true, orderModel.getOrderWt(), false);

				/** 최적의 BL리스트 기준으로 입고예정재고여부(입고구분에의한) 파악 및 WMS 실시간 재고 파악 및 재고 차감, 주문 정합성 체크 3단계 (최적의 BL에서 BL번호 필요)
				 * 22. 배송요율 유효성 체크
				 *  1) 배송요율 정보 및 회원_배송지 정보 체크
				 *  2) 배송 불가 및 서비스 불가능 지역 체크
				 * 23. 실시간 물류 CAPA 확인[SOREC-IF-126] 유효성 체크
				 * 24. WMS 실시간 재고 체크
				 *  1) 실시간 재고 API 호출 체크 (현재 사용하지 않음)
				 *  2) 실시간 재고 수량 체크 (현재 사용하지 않음)
				 * **/
				orderService.orderInvntryChk(orderModel);

				/**
				 * 주문 테이블 생성, 주문에 필요한 데이터를 DB에 INSERT 한다.
				 * 24-02-21 변경사항 : 계약구매 - 지정가 주문(0304)일 경우 수행되는 로직 분기 처리
				 * **/
				if(StringUtils.equals(orderModel.getSleMthdDetailCode(), "0304")) {
					orderService.avrgpcOrderInstTblBase(orderModel);
				} else {
					orderService.orderInstTblBase(orderModel);
				}

				/**
				 * 실시간 가격일시 삼성선물 호출
				 * **/
				orderService.callSamsung(orderModel);

				/**
				 * 주문 성공 후 처리, 주문완료시 후처리 작업으로 별로의 스레드를 통해 각자 서비스들이 움직인다.
				 * **/
				orderService.orderComplete(orderModel);
			} catch (Exception e) {
				log.error("[procEachLimitOrder] exception orderModel : " + String.valueOf(orderModel));

				log.error("[procEachLimitOrder] e : " + e.getMessage());
				String stacktrace = ExceptionUtils.getStackTrace(e);
				log.error("[procEachLimitOrder] stacktrace : " + stacktrace);
				orderModel.setOrderFailrResn(e.getMessage());
				orderService.orderFail(orderModel); // 주문 실패 시

				if(StringUtils.isEmpty(orderModel.getLimitOrderSttusCode())) {
					orderModel.setLimitOrderSttusCode("94"); // 지정된 예외를 제외한 예외는 상태코드를 [94: 유효성 검사 실패]로 set한다
				}

				String limitOrderFailrResn = "";
				if(StringUtils.equals("94", orderModel.getLimitOrderSttusCode()) || StringUtils.equals("95", orderModel.getLimitOrderSttusCode())) {
					limitOrderFailrResn = orderModel.getOrderFailrResn();
				}

				// 지정가 주문 번호[단일] 지정가 주문 실패 시
				commLimitOrderService.limitOrderFail(orderModel.getLimitOrderNo(), orderModel.getLimitOrderSttusCode(), limitOrderFailrResn
						, orderModel.getMberId(), orderModel.getOrderNo(), orderModel.getOrderWt()
						, "Y", false, true);
			}
		};

		limitOrderTaskExecutor.execute(limitOrderRun);
	}

	/**
	 * 가단가 지정가 그룹 주문 진행
	 */
	@Override
	public void doPrvsnlLimitGroupOrder(CommLimitGroupModel commLimitGroupModel) throws CommCustomException, Exception {
		Runnable limitGroupRun = () -> {
			try {
				log.info(">> [doPrvsnlLimitGroupOrder] commLimitGroupModel : " + String.valueOf(commLimitGroupModel));

				// 타겟 지정가 주문 번호 리스트 가져오기
				List<String> targetLimitOrderNoList = commLimitGroupModel.getTargetLimitOrderNoList();

				for(String targetLimitOrderNo : targetLimitOrderNoList) {
					CommLimitOrderModel getLimitOrderModel = commLimitGroupModel.getLimitOrderModelMap().get(targetLimitOrderNo);

					// 지정가 주문 번호로 해당 지정가 주문 내역 가져오기 [단일]
					CommOrLimitOrderBasVO selectCommOrLimitOrderBas = commPrvsnlOrderService.selectCommOrPrvsnlOrderBas(targetLimitOrderNo);

					// 지정가 주문 번호에 해당하는 지정가 주문 내역으로 주문 VO 객체를 재구성한다
					OrderModel orderModel = getLimitOrderModel.getPrvsnlOrderModel(selectCommOrLimitOrderBas);
					// 지정가 구분 [가격 도달 시 진행되는 주문: touch, 그 외: null]
					orderModel.setLimitSection("touch");
					// 멤버 아이디 set
					orderModel.setMberId(commLimitGroupModel.getSystemId());
					// 주문 bl 리스트 set
					orderModel.setBlList(getLimitOrderModel.getBlList());

					// 사용 쿠폰 내역 조회
					if(StringUtils.equals(orderModel.getCouponApplcAt(), "Y")){
						orderModel.setCouponList(commLimitOrderService.selectUsedCouponInfo(targetLimitOrderNo));
					}

					// 개별 가단가 지정가 주문 처리
					this.procEachPrvsnlLimitOrder(orderModel);
				}
			} catch (Exception e) {
				log.error("[doLimitGroupOrderThreadTest] exception commLimitGroupModel : " + String.valueOf(commLimitGroupModel));

				log.error("[doLimitGroupOrderThreadTest] e : " + e.getMessage());
				String stacktrace = ExceptionUtils.getStackTrace(e);
				log.error("[doLimitGroupOrderThreadTest] stacktrace : " + stacktrace);
			}
		};

		limitGroupTaskExecutor.execute(limitGroupRun);
	}

	/**
	 * <pre>
	 * 처리내용: 개별 가단가 지정가 주문 처리
	 * </pre>
	 * @date 2024. 9. 10.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 10.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	private void procEachPrvsnlLimitOrder(OrderModel orderModel) throws CommCustomException, Exception {
		log.info("[procEachPrvsnlLimitOrder] in~~");
		try {
			log.info("[procEachPrvsnlLimitOrder] orderModel : " + String.valueOf(orderModel));
			
			OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO = new OrderPrvsnlDcsnProcessVO();

			// 지정가 구분 코드 [F: LME/X: 환율/R: KRW]
			String limitSeCode = orderModel.getLimitSeCode();

			if(StringUtils.equals("F", limitSeCode) ) {
				// [LME] - 선물 체결
				// 가단가 확정 처리하기 위한 구분 및 판매 방식 변수 세팅
				orderModel.setDcsnSection("lme"); 	// 가단가 확정 - 구분 [lme: LME 분리확정, fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]
				orderModel.setDcsnSelMthd("limit"); // 가단가 확정 - 판매 방식 [live: 라이브, limit: 지정가]
				orderPrvsnlDcsnProcessVO.setSection("lme"); // 구분 [lme: LME 분리확정, fx: FX 분리확정, singl: 단일확정, smtm: 동시확정]
			} else if(StringUtils.equals("X", limitSeCode)) {
				// [환율] - 선물환 체결
				// 가단가 확정 처리하기 위한 구분 및 판매 방식 변수 세팅
				orderModel.setDcsnSection("fx"); 	// 가단가 확정 - 구분 [lme: LME 분리확정, fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]
				orderModel.setDcsnSelMthd("limit"); // 가단가 확정 - 판매 방식 [live: 라이브, limit: 지정가]
				orderPrvsnlDcsnProcessVO.setSection("fx"); // 구분 [lme: LME 분리확정, fx: FX 분리확정, singl: 단일확정, smtm: 동시확정]
			} else if(StringUtils.equals("R", limitSeCode)) {
				// [KRW] - 선물, 선물환 체결
				// 가단가 확정 처리하기 위한 구분 및 판매 방식 변수 세팅
				orderModel.setDcsnSection("singl"); // 가단가 확정 - 구분 [lme: LME 분리확정, fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]
				orderModel.setDcsnSelMthd("limit"); // 가단가 확정 - 판매 방식 [live: 라이브, limit: 지정가]
				orderPrvsnlDcsnProcessVO.setSection("singl"); // 구분 [lme: LME 분리확정, fx: FX 분리확정, singl: 단일확정, smtm: 동시확정]
			}

			// 가단가 확정 처리
			orderPrvsnlDcsnService.procPrvsnlDcsn(orderModel);

			// 가단가 확정 websocket 처리
			orderPrvsnlDcsnProcessVO.setSttusCode("I"); // 상태 코드 [I: 등록, U: 수정, D: 취소]
			orderPrvsnlDcsnProcessVO.setOrderNo(orderModel.getOrderNo()); // 주문 번호 set
			// 단가확정하기 정보 및 주문 번호에 대한 공통 가단가 확정 여부 정보 가져오기, 구분 및 판매 방식, 상태 코드에 따른 등록, 수정, 취소 진행 후 정보 가져오기
			orderPrvsnlDcsnService.getOrderPrvsnlDcsnProcessInfo(orderPrvsnlDcsnProcessVO);
			// 가단가 확정하기 정보 websocket publish, FO에 해당 확정 여부 전파 전달 (SimpMessagingTemplate) [확정, 체결, 수정, 취소] 모두 대상
			orderPrvsnlDcsnService.websocketPublishPrvsnlDcsnSimpMsg(orderPrvsnlDcsnProcessVO);

		} catch (Exception e) {
			log.error("[procEachPrvsnlLimitOrder] exception orderModel : " + String.valueOf(orderModel));

			log.error("[procEachPrvsnlLimitOrder] e : " + e.getMessage());
			String stacktrace = ExceptionUtils.getStackTrace(e);
			log.error("[procEachPrvsnlLimitOrder] stacktrace : " + stacktrace);
			orderModel.setOrderFailrResn(e.getMessage());
//			orderService.orderFail(orderModel); // 주문 실패 시

			if(StringUtils.isEmpty(orderModel.getLimitOrderSttusCode())) {
				orderModel.setLimitOrderSttusCode("94"); // 지정된 예외를 제외한 예외는 상태코드를 [94: 유효성 검사 실패]로 set한다
			}

			String limitOrderFailrResn = "";
			if(StringUtils.equals("94", orderModel.getLimitOrderSttusCode()) || StringUtils.equals("95", orderModel.getLimitOrderSttusCode())) {
				limitOrderFailrResn = orderModel.getOrderFailrResn();
			}

			// 지정가 주문 번호[단일] 지정가 주문 실패 시
			commPrvsnlOrderService.prvsnlLimitOrderFail(orderModel.getLimitOrderNo(), orderModel.getLimitOrderSttusCode(), limitOrderFailrResn, orderModel.getMberId());
		}

	}

	///////////////////////////////
	// 아래 로직 쓰레드 테스트용 //
	///////////////////////////////

	/**
	 * 지정가 그룹 주문 진행 쓰레드 테스트 (로직은 빈 껍데기)
	 */
	@Override
	public void doLimitGroupOrderThreadTest(CommLimitGroupModel commLimitGroupModel) throws CommCustomException, Exception {
		Runnable limitGroupRun = () -> {
			try {
				//log.info(">> [doLimitGroupOrderThreadTest] commLimitGroupModel : " + String.valueOf(commLimitGroupModel));
				log.warn("[doLimitGroupOrderThreadTest] "
						+ ", poolSize : " + limitGroupTaskExecutor.getPoolSize()
						+ ", activeCount : " + limitGroupTaskExecutor.getActiveCount()
						+ ", queueSize : " + limitGroupTaskExecutor.getThreadPoolExecutor().getQueue().size()
				);

				// 타겟 지정가 주문 번호 리스트 가져오기
				List<String> targetLimitOrderNoList = commLimitGroupModel.getTargetLimitOrderNoList();

				for(String targetLimitOrderNo : targetLimitOrderNoList) {

					OrderModel orderModel = new OrderModel();
					orderModel.setSleMthdCode("03");
					orderModel.setPaymentMn("ewallet");
					orderModel.setLimitOrderNo(targetLimitOrderNo);

					Thread.sleep(1000);

//					log.info(">> [doLimitGroupOrderThreadTest] " + targetLimitOrderNo + " orderModel : " + String.valueOf(orderModel));

					// 개별 지정가 주문 처리 (로직은 빈 껍데기)
					this.procEachLimitOrderThreadTest(orderModel);
				}
			} catch (Exception e) {
				log.error("[doLimitGroupOrderThreadTest] exception commLimitGroupModel : " + String.valueOf(commLimitGroupModel));

				log.error("[doLimitGroupOrderThreadTest] e : " + e.getMessage());
				String stacktrace = ExceptionUtils.getStackTrace(e);
				log.error("[doLimitGroupOrderThreadTest] stacktrace : " + stacktrace);
			}
		};

		limitGroupTaskExecutor.execute(limitGroupRun);
	}

	/**
	 * <pre>
	 * 처리내용: 개별 지정가 주문 처리 (로직은 빈 껍데기)
	 * </pre>
	 * @date 2023. 5. 23.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 23.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws CommCustomException
	 * @throws Exception
	 */
	public void procEachLimitOrderThreadTest(OrderModel orderModel) throws CommCustomException, Exception {
		Runnable limitOrderRun = () -> {
			//log.info("[procEachLimitOrderThreadTest] in~~");
			try {
				log.warn("[procEachLimitOrderThreadTest] "
						+ ", poolSize : " + limitOrderTaskExecutor.getPoolSize()
						+ ", activeCount : " + limitOrderTaskExecutor.getActiveCount()
						+ ", queueSize : " + limitOrderTaskExecutor.getThreadPoolExecutor().getQueue().size()
				);

				Thread.sleep(10000);
				/**
				 * 주문 성공 후 처리, 주문완료시 후처리 작업으로 별로의 스레드를 통해 각자 서비스들이 움직인다. (로직은 빈 껍데기)
				 * **/
				orderService.orderCompleteThreadTest(orderModel);
			} catch (Exception e) {
				log.error("[procEachLimitOrderThreadTest] exception orderModel : " + String.valueOf(orderModel));

				log.error("[procEachLimitOrderThreadTest] e : " + e.getMessage());
				String stacktrace = ExceptionUtils.getStackTrace(e);
				log.error("[procEachLimitOrderThreadTest] stacktrace : " + stacktrace);
			}
		};

		limitOrderTaskExecutor.execute(limitOrderRun);
	}
}
