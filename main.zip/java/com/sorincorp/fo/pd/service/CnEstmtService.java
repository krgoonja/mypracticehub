package com.sorincorp.fo.pd.service;

import java.util.List;

import com.sorincorp.fo.pd.model.CnEstmtVO;

public interface CnEstmtService {

	List<CnEstmtVO> selectCnEstmtList(CnEstmtVO cnEstmtVO) throws Exception;

	String getAuthCheckInsertCnEstmt(CnEstmtVO cnEstmtVO) throws Exception;
	
	int insertCnEstmtList(CnEstmtVO cnEstmtVO) throws Exception;
}
