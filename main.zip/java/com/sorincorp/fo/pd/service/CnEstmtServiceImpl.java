package com.sorincorp.fo.pd.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.pd.mapper.CnEstmtMapper;
import com.sorincorp.fo.pd.model.CnEstmtVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CnEstmtServiceImpl implements CnEstmtService{

	@Autowired
	private CnEstmtMapper cnEstmtMapper;

	@Autowired
	private AssignService assignService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private SMSService smsService;

	@Override
	public List<CnEstmtVO> selectCnEstmtList(CnEstmtVO cnEstmtVO) throws Exception {
		List<CnEstmtVO> cnEstmtList = cnEstmtMapper.selectCnEstmtList(cnEstmtVO);
		return cnEstmtList;
	}
	
	/*
	 * Purchase Contract Auth Check
	 */
	@Override
	public String getAuthCheckInsertCnEstmt(CnEstmtVO cnEstmtVO) throws Exception {
		return cnEstmtMapper.getAuthCheckInsertCnEstmt(cnEstmtVO);
	}

	@Override
	public int insertCnEstmtList(CnEstmtVO cnEstmtVO) throws Exception {
		int result = 0;
		String userId = "";
		String entrpsNo = "";
		String moblphonNo = "";

		Account account = userInfoUtil.getAccountInfo();
		if(account != null) {
			userId = account.getId();
			entrpsNo = account.getEntrpsNo();
		}

		if (StringUtils.isNotBlank(account.getPhonenum())) {
			moblphonNo = CryptoUtil.encryptAES256(account.getPhonenum());
		}

		String entrpsnmKoreanShort = cnEstmtMapper.selectEntrpsnmKoreanShort(entrpsNo);

		//견적번호 생성
		String estmtNo = "Q-" + cnEstmtVO.getMetalCodeNm() + "-" + entrpsnmKoreanShort + "-" + DateUtil.calDate("yyMMdd") + "-" +assignService.selectAssignValue("CN", "ESTMT_NO", DateUtil.calDate("yyyy"), "SYSTEM", 3);

		cnEstmtVO.setEstmtNo(estmtNo);
		cnEstmtVO.setMberNo(account.getMberNo());
		cnEstmtVO.setEntrpsNo(account.getEntrpsNo());
		cnEstmtVO.setOrderEntrpsNm(account.getEntrpsnmKorean());
		cnEstmtVO.setOrdrrNm(account.getName());
		cnEstmtVO.setOrdrrMoblphonNo(moblphonNo);
		cnEstmtVO.setOrdrrEmail(account.getEmail());
		cnEstmtVO.setFrstRegisterId(userId);
		cnEstmtVO.setLastChangerId(userId);

		result = cnEstmtMapper.insertCnEstmt(cnEstmtVO);
		if(result > 0) {
			cnEstmtMapper.insertCnEstmtHst(cnEstmtVO);

			// 아이템 리스트
			List<CnEstmtVO> itmList = cnEstmtVO.getItmList();
			// 권역 리스트
			List<CnEstmtVO> avrgpcDstrctLclsfList = cnEstmtVO.getAvrgpcDstrctLclsfCodeList();
			// 브랜드 그룹 리스트
			List<CnEstmtVO> brandGroupList = cnEstmtVO.getBrandGroupCodeList();
			// 월별 주문 리스트
			List<CnEstmtVO> orderList = cnEstmtVO.getOrderList();

			if(itmList.size() > 0) {
				for(CnEstmtVO vo : itmList) {
					vo.setEstmtNo(estmtNo);
					vo.setMetalCode(cnEstmtVO.getMetalCode());
					vo.setFrstRegisterId(userId);
					vo.setLastChangerId(userId);
					cnEstmtMapper.insertCnEstmtItmDtl(vo);
					cnEstmtMapper.insertCnEstmtItmDtlHst(vo);
				}
			}

			if(avrgpcDstrctLclsfList.size() > 0) {
				for(CnEstmtVO vo : avrgpcDstrctLclsfList) {
					vo.setEstmtNo(estmtNo);
					vo.setFrstRegisterId(userId);
					vo.setLastChangerId(userId);
					cnEstmtMapper.insertCnEstmtDstrctDtl(vo);
					cnEstmtMapper.insertCnEstmtDstrctDtlHst(vo);
				}
			}

			if(brandGroupList.size() > 0) {
				for(CnEstmtVO vo : brandGroupList) {
					vo.setEstmtNo(estmtNo);
					vo.setFrstRegisterId(userId);
					vo.setLastChangerId(userId);
					cnEstmtMapper.insertCnEstmtBrandGroupDtl(vo);
					cnEstmtMapper.insertCnEstmtBrandGroupDtlHst(vo);
				}
			}

		    if(orderList.size() > 0) {
				for(CnEstmtVO vo : orderList) {
					vo.setEstmtNo(estmtNo);
					vo.setFrstRegisterId(userId);
					vo.setLastChangerId(userId);
					cnEstmtMapper.insertCnEstmtMtOrderWtDtl(vo);
					cnEstmtMapper.insertCnEstmtMtOrderWtDtlHst(vo);
				}
			}

		    try {
		    	Date today = new Date();
		        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		        String regDate = simpleDateFormat.format(today);
			    String csTel = cnEstmtMapper.selectCsTel();

			    SMSVO smsVO = new SMSVO();
			    Map<String, String> smsMap = new HashMap<>();
			    smsMap.put("templateNum", "132");
			    smsMap.put("estmtNo", estmtNo);
			    smsMap.put("estmtRceptDt", regDate);
			    smsMap.put("csTel", csTel);

			    smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
			    smsVO.setPhone(account.getPhonenum());
			    smsVO.setMberNo(account.getMberNo());
			    smsService.insertSMS(smsVO, smsMap);

		    }catch(Exception e) {
		    	log.error(ExceptionUtils.getStackTrace(e));
		    }

		}

		return result;
	}





}
