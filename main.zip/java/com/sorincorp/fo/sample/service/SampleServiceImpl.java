/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sorincorp.fo.sample.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.sample.mapper.SampleMapper;
import com.sorincorp.fo.sample.model.SampleVO;

import lombok.extern.slf4j.Slf4j;
import net.bytebuddy.utility.RandomString;

@Slf4j
@Service
public class SampleServiceImpl implements SampleService {

	@Autowired
	private SampleMapper sampleMapper;
	
	@Autowired
	UserInfoUtil userInfoUtil;
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 SampleVO
	 * @return 등록 결과
	 * @exception Exception
	 */
	@Override
	public String insertSample(SampleVO vo) throws Exception {
		log.debug("insertSample log sample 1 : " + vo.toString());
		
		//sample random ID
		RandomString random = new RandomString(5);
		vo.setId(random.nextString());
		
		log.debug("insertSample log sample 2 : " + vo.toString());
		
		sampleMapper.insertSample(vo);
		return vo.getId();
	}

	/**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 SampleVO
	 * @return void형
	 * @exception Exception
	 */
	@Override
	public void updateSample(SampleVO vo) throws Exception {
		sampleMapper.updateSample(vo);
	}

	/**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 SampleVO
	 * @return void형
	 * @exception Exception
	 */
	@Override
	public void deleteSample(SampleVO vo) throws Exception {
		sampleMapper.deleteSample(vo);
	}

	/**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 SampleVO
	 * @return 조회한 글
	 * @exception Exception
	 */
	@Override
	@Cacheable(value="SampleVO")
	public SampleVO selectSample(SampleVO vo) throws Exception {
		SampleVO resultVO = sampleMapper.selectSample(vo);
		
		if (resultVO == null)
			throw new Exception("result is null");
		
		return resultVO;
	}

	/**
	 * 글 목록을 조회한다.
	 * @param SampleVO - 조회할 정보가 담긴 VO
	 * @return 글 목록
	 * @exception Exception
	 */
	@Override
	//@Cacheable(value="SampleList")
	public List<SampleVO> selectSampleList(SampleVO sampleVO) throws Exception {
		return sampleMapper.selectSampleList(sampleVO);
	}


	/**
	 * 글 총 갯수를 조회한다.
	 * @param SampleVO - 조회할 정보가 담긴 VO
	 * @return 글 총 갯수
	 * @exception
	 */
	@Override
	public int selectSampleListTotCnt(SampleVO sampleVO) {
		return sampleMapper.selectSampleListTotCnt(sampleVO);
	}

	@Override
	public List<SampleVO> selectSampleList(SampleVO searchVO, HttpServletRequest request) throws Exception {
		// TODO Auto-generated method stub
		log.debug(userInfoUtil.getEntripsNo(request));
		return sampleMapper.selectSampleList(searchVO);
	}
}
