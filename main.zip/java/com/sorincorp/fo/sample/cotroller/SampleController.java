package com.sorincorp.fo.sample.cotroller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;

import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.order.service.CommLimitOrderService;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.comm.websocket.model.SocketDataVO;
import com.sorincorp.fo.config.LoginTokenProvider;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.login.service.AccountServiceImpl;
import com.sorincorp.fo.login.service.LoginInfoService;
import com.sorincorp.fo.op.model.HopePcNtcnSndngVO;
import com.sorincorp.fo.sample.model.SampleVO;
import com.sorincorp.fo.sample.service.SampleService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Controller
@ComponentScan(basePackages= {"com.sorincorp.comm.*"})
@EnableScheduling
public class SampleController {

	@Autowired
	private AccountServiceImpl accountService;

	@Autowired
	private LoginInfoService loginInfoService;

	@Autowired
	private LoginTokenProvider loginTokenProvider;

	@Autowired
	private RedisUtil redisUtil;

	@Autowired
	private AssignService assignService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	MessageUtil mesasgeUtil;

	@Autowired
	private SampleService sampleService;

	@Autowired
	private SimpMessagingTemplate simpMessagingTemplate;

//	@Autowired
//	private MainService mainService;

	@Autowired
	private CommLimitOrderService commLimitOrderService;


	/**
	 * <pre>
	 * 카카오 로그인 Sample
	 * - 카카오 인증코드가 없으면 '카카오 로그인' 버튼이 보이는 화면으로 이동
	 * - 인증코드는 있으나 회원가입이 안되어 있는 경우 -카카오 사용자 정보를 이용한 회원 가입화면으로 이동
	 * - 인증코드도 있고 회원가입도 되어 있는 경우 - JWT 로그인 Token을 생성하여 쿠키에 등록하고 Token에 해당하는 회원 정보를 SecurityHolder의 Context에 저장
	 * </pre>
	 * @date 2021. 6. 28.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param code : 카카오 인증 코드
	 * @param model : 카카오 회원정보를 화면에 전달하기 위한 ModelMap
	 * @param session : 로그인 여부를 확인하기 위한 Session 값
	 * @param response : 쿠키값을 저장할 Response
	 * @return
	 * @throws Exception
	 */
//	@RequestMapping("/kakaoLogin")
//	public String kakaoLogin(@RequestParam(required=false) String code, ModelMap model, HttpSession session, HttpServletRequest request, HttpServletResponse response) throws Exception {
//	System.out.println("code-----------"+code);
//		if ( code != null ) {
//			KakaoService kakaoService = new KakaoServiceImpl();
//
//			String access_token = kakaoService.getAccessToken(code, CommonConstants.KAKAO_REDIRECT_URL);
//			HashMap<String, Object> userInfo = kakaoService.getUserInfo(access_token);
//
//			if ( userInfo.get("email") != null ) {
//				session.setAttribute("userId", userInfo.get("email"));
//			}
//
//			// 회원여부 확인JSP
//			Account account = accountService.selectAccount(userInfo.get("email").toString());
//			if ( account == null ) {
//				// 회원가입 화면 이동
//				model.addAttribute("email", userInfo.get("email"));
//				model.addAttribute("name", userInfo.get("nickname"));
//				model.addAttribute("phone_number", userInfo.get("phone_number"));
//				model.addAttribute("account", new Account());
//
//				return "login/kakaoRegister";
//			} else {
//				final String access = loginTokenProvider.generateAccessToken(account);
//				final String refresh = loginTokenProvider.generateRefreshToken(account);
//
////				Cookie accessToken = loginTokenProvider.createCookie(CommonConstants.ACCESS_TOKEN_NAME, access, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);
////				Cookie refreshToken = loginTokenProvider.createCookie(CommonConstants.REFRESH_TOKEN_NAME, refresh, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND);
//				ResponseCookie accessToken = loginTokenProvider.createSecureCookie(CommonConstants.ACCESS_TOKEN_NAME, access, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);
//				ResponseCookie refreshToken = loginTokenProvider.createSecureCookie(CommonConstants.REFRESH_TOKEN_NAME, refresh, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND);
//
//				redisUtil.setDataExpire(CommonConstants.REDIS_KEY_FO_REFRESH+refresh, account.getId(), CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND);
//
////				response.addCookie(accessToken);
////				response.addCookie(refreshToken);
//				response.addHeader(HttpHeaders.SET_COOKIE, accessToken.toString());
//				response.addHeader(HttpHeaders.SET_COOKIE, refreshToken.toString());
//
//				UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(account, null, account.getAuthorities());
//				usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
//				SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
//				if(account.getMberSttusCode().equals("05")) {
//					return "login/askMemberActive";
//				}
//				return "sample/sampleIndex.tiles";
//			}
//		}
//
//		return "login/loginKakao";
//	}

	/**
	 * <pre>
	 * 카카오 회원정보로 간편회원 가입을 한다.
	 * </pre>
	 * @date 2021. 6. 28.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 28.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param sampleVO : 간편회원 가입정보 VO
	 * @param bindingResult
	 * @param model
	 * @param status
	 * @return
	 * @throws Exception
	 */
//	@Transactional
//	@PostMapping("/insertKakaoSample")
//	public String insertKakao(@ModelAttribute("account") @Valid Account account, BindingResult bindingResult, Model model, SessionStatus status,
//			HttpServletRequest request, HttpServletResponse response) throws Exception {
//
//		if (bindingResult.hasErrors()) {
//			model.addAttribute("account", account);
//			return "sample/sampleKakaoRegister";
//		}
//
//		String mberNo = assignService.selectAssignValue("MB", "MBER_NO", "MBER_NO", "SYSTEM", 10);
//		account.setMberNo(mberNo);
//		String accountId = accountService.insertAccount(account);
//		//System.out.println("accountId---------"+accountId);
//		final String access = loginTokenProvider.generateAccessToken(account, account.getId());
//		final String refresh = loginTokenProvider.generateRefreshToken(account.getId());
//
//		Cookie accessToken = loginTokenProvider.createCookie(CommonConstants.ACCESS_TOKEN_NAME, access, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);
//		Cookie refreshToken = loginTokenProvider.createCookie(CommonConstants.REFRESH_TOKEN_NAME, refresh, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND);
//
//		redisUtil.setDataExpire(CommonConstants.REDIS_KEY_FO_REFRESH+refresh, accountId, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND);
//
//		response.addCookie(accessToken);
//		response.addCookie(refreshToken);
//
//		UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(account, null, account.getAuthorities());
//		usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
//		SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
//
//		status.setComplete();
//		return "redirect:/selectSampleList";
//	}

    /**
     * 우편번호 조회
     * @param sampleVO - 조회할 정보가 담긴 sampleVO
     * @param model
     * @return "sampleVO"
     * @exception Exception
     */
    @RequestMapping("/samplePostCode")
    public String samplePostCode(HttpServletRequest request) throws Exception {
//    	Cookie cookie = loginTokenProvider.getCookie(request, "accessToken");
//    	Account account;
//		if(cookie == null) {
//			account = null;
//		}
//		else {
//			account = (Account) accountService.loadUserByUsername(cookie.getValue());
//		}
		Account account = userInfoUtil.getAccountInfo(request);
		String userName = userInfoUtil.getMemberName();
		String entNo = userInfoUtil.getEntripsNo();

		log.debug(userInfoUtil.getType());
		log.debug(userName);
		log.debug(entNo);

//		log.debug(loginInfoService.getEntrpsNo());
//		String test1 = com.sorincorp.fo.comm.crypto.CryptoUtil.aes256Encode("테스트 중입니다.");
//		String test2 = CryptoUtil.aes256Encode("This is xptmxm 중입니다. 12312 &^*&&*%#%$#");
//
//
//		log.debug(test1);
//		log.debug(com.sorincorp.fo.comm.crypto.CryptoUtil.aes256Decode(test1));
//		log.debug(test2);
//		log.debug(com.sorincorp.fo.comm.crypto.CryptoUtil.aes256Decode(test2));.

		log.debug(loginInfoService.getEntrpsNo());
		String test1 = com.sorincorp.comm.util.CryptoUtil.encryptAES("테스트 중입니다.");
		String test2 = com.sorincorp.comm.util.CryptoUtil.encryptAES("This is xptmxm 중입니다. 12312 &^*&&*%#%$#");


		log.debug(test1);
		log.debug(com.sorincorp.comm.util.CryptoUtil.decryptAES(test1));
		log.debug(test2);
		log.debug(com.sorincorp.comm.util.CryptoUtil.decryptAES(test2));


        return "sample/samplePostCode.tiles";
    }

    @ResponseBody
    @RequestMapping("/sampleAccount")
    public Account getAccount(HttpServletRequest request) throws Exception {
    	Account account = userInfoUtil.getAccountInfo(request) != null ? userInfoUtil.getAccountInfo(request) : new Account();
    	return account;
    }

	/**
	 *
	 * <pre>
	 * 처리내용: 메시지 처리 샘플
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param sampleVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/messageSample")
	public String selectListSample() throws Exception {

		String nonParamType = mesasgeUtil.getMessage("co.validation.requiredDateRange");

		String defaultParamType = mesasgeUtil.getMessage("co.validation.requiredDateRange12313123","이거슨 default 메시지 입니다.");

		Object[] objs = {"테스트",3};
		String paramType = mesasgeUtil.getMessage("co.validation.maxSize",objs);

		String defaultObjsParamType = mesasgeUtil.getMessage("co.validation.maxSize1111111",objs,"이거슨 default 메시지 입니다.");

		log.debug(nonParamType);
		log.debug(defaultParamType);
		log.debug(paramType);
		log.debug(defaultObjsParamType);

		return "sample/sampleMessage";
	}

	@GetMapping("/samplePaging")
	public String selectCsfFaqViews(SampleVO sampleVO, ModelMap model) throws Exception {
		model.addAttribute("totalRowCount", sampleService.selectSampleListTotCnt(sampleVO));
		model.addAttribute("pageIndex", 1);
		model.addAttribute("pageSize", 3);
		model.addAttribute("rowCountPerPage", 2);

		return "sample/samplePaging.tiles";
	}

	@ResponseBody
	@PostMapping("/selectSampleListByPaging")
	public Map<String,Object> selectSampleListByPaging(@RequestBody SampleVO sampleVO, ModelMap model) throws Exception {

		model.addAttribute("totalRowCount", sampleService.selectSampleListTotCnt(sampleVO));

		List<SampleVO> list = sampleService.selectSampleList(sampleVO);
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("dataList", list);

		return map;
	}

	@GetMapping("/sample/taglibSample")
    public String sample() {
        return "sample/taglibSample.tiles";
    }

	@PostMapping("/sample/popup")
	public String selectMainSample() throws Exception {
		return "sample/samplePopup";
	}


	@RequestMapping("/sampleValidation")
	public String sampleValidation() throws Exception {
		return "sample/sampleValidation.tiles";
	}


	@RequestMapping("/sample/sampleInputKeyEvent")
	public String sampleInputKeyEvent() throws Exception {
		return "sample/sampleInputKeyEvent.tiles";
	}

	/**
	 * <pre>
	 * 처리내용: sockJS와 stomp를 사용한 소켓 통신 sample
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 2.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 */
	@RequestMapping("/stompSocketSample")
    public String stompSocketSample(){
        return "sample/stompSocketSample";
    }

	/**
	 * <pre>
	 * 처리내용: stomp subscribe와 message 처리 sample
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 2.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@MessageMapping("/stompSendToAlarmSubscriber") // 해당 annotation은 client가 정보를 보낼 메소드의 주소를 정한다. client가 보낼 값이 없다면 쓰지 않는다.
	public void alarmSubscriber() throws Exception {

		//구독하는 URI로 해당 메시지를 보낸다. 메시지 값은 object이다.
		simpMessagingTemplate.convertAndSend("/subscriber/alarmSubscriber", "알람을 위한 구독입니다.");
	}

	/*
	기준 URI

	-가격-
	판매가격 : /selpc/{금속코드}/{아이템순번}/{권역}/{브랜드그룹}/{브랜드}
	LME : /lmepc/{금속코드}
	환율 : /fxpc/{통화코드}

	-알림-
	지수(LME) : /lmeAlram/{금속코드}/{업체번호}
	희망가 : /wishAlram/{금속코드}/{아이템순번}/{권역}/{브랜드그룹}/{브랜드}/{업체번호}
	재고 : /stockAlram/{금속코드}/{아이템순번}/{권역}/{브랜드그룹}/{브랜드}/{업체번호}
	*/

	@MessageMapping("/stompSendToTestReceiver") // 해당 annotation은 client가 정보를 보낼 메소드의 주소를 정한다. client가 보낼 값이 없다면 쓰지 않는다.
	public void testReceiver(SocketDataVO vo) throws Exception {

		vo.setId("receive1");
		vo.setMessage("받은 메시지 : " +vo.getMessage() + " 를 다시 보냅니다.");

		//구독하는 URI로 해당 메시지를 보낸다. 메시지 값은 object이다.
		simpMessagingTemplate.convertAndSend("/subscriber/testReceiver", vo);
	}

	@MessageMapping("/wishAlram/7/433/25/06/ABRA5/C0050") // 해당 annotation은 client가 정보를 보낼 메소드의 주소를 정한다. client가 보낼 값이 없다면 쓰지 않는다.
	public void testReceiverAndSend(SocketDataVO vo) throws Exception {
		System.out.println("testReceiverAndSend receive");
		vo.setId("receive1");
		vo.setMessage("받은 메시지 : " +vo.getMessage() + " 를 다시 보냅니다.");

		HopePcNtcnSndngVO sndingVO = new HopePcNtcnSndngVO();
		sndingVO.setMetalCode("7");
		sndingVO.setItmSn(433);
		sndingVO.setDstrctLclsfCode("25");
		sndingVO.setBrandCode("06");
		sndingVO.setBrandCode("ABRAS");
		sndingVO.setEntrpsNo("C0050");
		sndingVO.setHopepc(new BigDecimal(10000));
		sndingVO.setNtcnSndngRgsde("2021-09-07 13:49:49");


		//구독하는 URI로 해당 메시지를 보낸다. 메시지 값은 object이다.
		simpMessagingTemplate.convertAndSend("/wishAlram/7/433/25/06/ABRA5/C0050", sndingVO);
	}
//	@Scheduled(fixedRate = 1000)
//	public void stompSendBy() throws Exception {
//		SocketDataVO vo = new SocketDataVO();
//		vo.setId("receive1");
//		vo.setMessage("받은 메시지 : " +vo.getMessage() + " 를 다시 보냅니다.");
//
//		simpMessagingTemplate.convertAndSend("/subscriber/alarmSubscriber", "receive schedule");
//	}

	/**
	 * 암호화 미리보기
	 */
	@RequestMapping("/sample/crypt/enc/{str}")
	public ResponseEntity<?> getEncryptStr(@PathVariable("str") String str) {
		Map<String,String> map = new HashMap<>();
		String encstr = null;
		try {
			encstr = com.sorincorp.comm.util.CryptoUtil.encryptAES256(str);
		} catch (Exception e) {
			encstr = e.getMessage();
			log.error(e.getMessage());
		}
		map.put("str", encstr);
		return ResponseEntity.status(HttpStatus.OK).body(map);
	}

	/**
	 * 복호화 미리보기
	 */
	@RequestMapping("/sample/crypt/dec/{str}")
	public ResponseEntity<?> getDecryptStr(@PathVariable("str") String str) {
		Map<String,String> map = new HashMap<>();
		String decstr = null;
		try {
			decstr = com.sorincorp.comm.util.CryptoUtil.decryptAES256(str);
		} catch (Exception e) {
			decstr = e.getMessage();
			log.error(e.getMessage());
		}
		map.put("str", decstr);
		return ResponseEntity.status(HttpStatus.OK).body(map);
	}

	/**
	 * SMS 미리보기
	 */
	@RequestMapping("/sample/sms/{orderNo}")
	public ResponseEntity<?> sendSms(@PathVariable("orderNo") String orderNo) {

		commLimitOrderService.limitOrderFailSendSms(orderNo);
		return ResponseEntity.status(HttpStatus.OK).body(null);
	}
}
