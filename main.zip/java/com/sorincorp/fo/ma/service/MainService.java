package com.sorincorp.fo.ma.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.fo.cs.model.PchrgArticlVO;
import com.sorincorp.fo.ma.model.BbscttVO;
import com.sorincorp.fo.ma.model.ClosingPcVO;
import com.sorincorp.fo.ma.model.EventHolidayVO;
import com.sorincorp.fo.ma.model.HeaderMenuVO;
import com.sorincorp.fo.ma.model.MetalWorldVO;
import com.sorincorp.fo.ma.model.NoticeVO;
import com.sorincorp.fo.ma.model.PopupDocVO;
import com.sorincorp.fo.ma.model.YoutubeVO;

public interface MainService {

	/**
	 * <pre>
	 * 처리내용: 헤더 상단 공지사항을 보여준다.
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public abstract List<NoticeVO> selectTopNotice();

	/**
	 * <pre>
	 * 처리내용: 로그인한 회원의 이웰렛 잔고를 조회한다.
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	public abstract String selectEWalletAccount(String entrpsNo);

	/**
	 * <pre>
	 * 처리내용: 이번 달 이벤트를 조회한다.
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param month
	 * @return
	 */
	public abstract List<EventHolidayVO> selectMonthlyEvent(String month, String day);

	/**
	 * <pre>
	 * 처리내용: 뉴스 클리핑을 조회한다.
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public abstract List<BbscttVO> selectNewsClipping();

	/**
	 * <pre>
	 * 처리내용: 최신 뉴스를 조회한다.
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public abstract List<PchrgArticlVO> selectNewsArticle();

	/**
	 * <pre>
	 * 처리내용: 주요 뉴스를 조회한다.
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public abstract List<PchrgArticlVO> selectMainNews();

	/**
	 * <pre>
	 * 처리내용: 헤더 메뉴를 조회한다.
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception 
	 */
//	public abstract List<HeaderMenuVO> selectHeaderMenu() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 헤더 타이머 최초값 조회 - 시간을 조회한다.
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public abstract List<Map<String, Object>> selectRestDtTimeSet();

	/**
	 * <pre>
	 * 처리내용: 헤더 - 휴일, 실시간 고정가 영업 여부
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
//	public abstract Map<String, Object> headerRestInfo();

	/**
	 * <pre>
	 * 처리내용: 3분마다 조회 헤더 타이머 - 시간을 조회한다.
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public abstract Map<String, Object> restDtTimeSetSchdule();

	/**
	 * <pre>
	 * 배송중 건수 조회
	 * </pre>
	 * @date 2022. 1. 20.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 20.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 */
	public abstract String selectDlvyIngCnt(Map<String, Object> param);

	/**
	 * <pre>
	 * 팝업 리스트 가져오기
	 * </pre>
	 * @date 2022. 05. 26.
	 * @author jdrttl
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 05. 26.		jdrttl				최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception 
	 */
	public abstract List<PopupDocVO> selectMainPopupNoticeDocCourse();
	public abstract PopupDocVO selectMainLargePopup();
	
	
	/**
	 * <pre>
	 * 조달청 가격 가져오기
	 * </pre>
	 * @date 2022. 05. 26.
	 * @author jdrttl
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 05. 26.		jdrttl				최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public abstract List<Map<String, Object>> getSarokPcList(String getNowDate);
	
	/**
	 * <pre>
	 * 처리내용: 회원별 메탈 및 판매방식이 적용된 헤더 메뉴를 조회한다.
	 * </pre>
	 * @date 2022. 06. 30.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 06. 30.			srec0067			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception 
	 */
	public abstract List<HeaderMenuVO> selectHeaderMenu() throws Exception;

	/**
	 * <pre>
	 * 운영중인지 체크
	 * </pre>
	 * @date 2022. 09. 22.
	 * @author jhcha
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 09. 22.		jhcha				최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public abstract String getWorkCheck();

	/**
	 * <pre>
	 * 처리내용: 메탈월드 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 10. 7.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 7.			srec0072			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public abstract List<MetalWorldVO> selectMetalWorldList();
	
    /**
     * <pre>
     * 처리내용:전일종가 영역 데이터 조회
     * </pre>
     * @date 2024. 02. 14.
     * @author sumin
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 02. 14.            sumin            최초작성
     * ------------------------------------------------
     * @return
     */
	public abstract List<ClosingPcVO> selectClosingPcList();
	
    /**
     * <pre>
     * 처리내용:유튜브 리스트 조회
     * </pre>
     * @date 2024. 10. 16.
     * @author jdrttl
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 10. 16.         jdrttl            최초작성
     * ------------------------------------------------
     * @return
     */
	public abstract List<YoutubeVO> selectYoutubeList();
}
