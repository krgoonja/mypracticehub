package com.sorincorp.fo.ma.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.bsnInfo.model.RestTermVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.pcInfo.model.FixPriceVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.chart.mapper.PcMntrngMapper;
import com.sorincorp.fo.chart.model.PreminumInfoDto;
import com.sorincorp.fo.chart.model.PreminumSelVO;
import com.sorincorp.fo.chart.model.SelMetalVO;
import com.sorincorp.fo.chart.service.PcMntrngService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.cs.model.PchrgArticlVO;
import com.sorincorp.fo.ma.mapper.MainMapper;
import com.sorincorp.fo.ma.model.BbscttVO;
import com.sorincorp.fo.ma.model.ClosingPcVO;
import com.sorincorp.fo.ma.model.EventHolidayVO;
import com.sorincorp.fo.ma.model.HeaderMenuVO;
import com.sorincorp.fo.ma.model.MetalWorldVO;
import com.sorincorp.fo.ma.model.NoticeVO;
import com.sorincorp.fo.ma.model.PopupDocVO;
import com.sorincorp.fo.ma.model.YoutubeVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MainServiceImpl implements MainService {

	@Autowired
	MainMapper mainMapper;

	@Autowired
	BsnInfoService bsnInfoService;

	@Autowired
	CommonCodeService commonCodeService;

	@Autowired
	FileDocService fileDocService;
	
	@Autowired
	UserInfoUtil userInfoUtil;

	@Autowired
	ItemCodeService itemCodeService;
	
	@Autowired
	PcMntrngService pcMntrngService;
	
	@Autowired
	PcMntrngMapper pcMntrngMapper;
	

	@Autowired
	private PcInfoService pcInfoService;
	
	public List<NoticeVO> selectTopNotice() {
		return mainMapper.selectTopNotice();
	}

	@Override
	public String selectEWalletAccount(String entrpsNo) {
		return mainMapper.selectEWalletAccount(entrpsNo);
	}

	@Override
	public List<EventHolidayVO> selectMonthlyEvent(String month, String day) {
		EventHolidayVO eventHolidayVO = new EventHolidayVO();
		eventHolidayVO.setMonth(month);
		eventHolidayVO.setDay(day);
//		eventHolidayVO.setEventRestdeSeCode("06");
		return mainMapper.selectMonthlyEvent(eventHolidayVO);
	}

	@Override
	public List<BbscttVO> selectNewsClipping() {
		return mainMapper.selectNewsClipping();
	}

	@Override
	@Cacheable(cacheNames = "News_Info", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public List<PchrgArticlVO> selectNewsArticle() {

		List<PchrgArticlVO> pchrgArticlVo = mainMapper.selectNewsArticle();
		String articlOrginl = "";
		for(int pos=0; pos < pchrgArticlVo.size(); pos++) {
			articlOrginl = StringUtil.encodingHTML(StringEscapeUtils.unescapeHtml4(pchrgArticlVo.get(pos).getArticlOrginl()));
			pchrgArticlVo.get(pos).setArticlOrginl(articlOrginl);
		}
		return pchrgArticlVo;
	}

	@Override
	@Cacheable(cacheNames = "News_Info", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public List<PchrgArticlVO> selectMainNews() {
		return mainMapper.selectMainNews();
	}
	
	@Override
	public List<Map<String, Object>> selectRestDtTimeSet() {

		List<Map<String,Object>> returnMap = new ArrayList<Map<String,Object>>();
		
		returnMap.addAll(getRestTermInfoBySleMthd("01")); //라이브
		returnMap.addAll(getRestTermInfoBySleMthd("02")); //케이지몰

		return returnMap;
	}
	
	public List<Map<String,Object>> getRestTermInfoBySleMthd(String sleMthdCode) {
		List<Map<String,Object>> returnMap = new ArrayList<Map<String,Object>>();
		
		try {
			List<RestTermVO> restTermListVO = bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), sleMthdCode);
			for (RestTermVO restTermVO : restTermListVO) {
				Map<String,Object> map = new HashMap<String,Object>();
				
				map.put("metalCode", restTermVO.getMetalCode());
				map.put("restWaitTerm",restTermVO.getWaitTerm()); // 영업 시작, 종료 시간까지 초단위
				map.put("restWaitNm", restTermVO.getWaitNm()); // 타이머 문구
				map.put("openTimeCode",restTermVO.getOpenTimeCode()); // 개장시간 범위 코드
				map.put("chartStTitle",restTermVO.getChartStTitle());
				map.put("chartEdTitle",restTermVO.getChartEdTitle());
				map.put("topWaitTerm", restTermVO.getTopWaitTerm());
				map.put("topWaitNm", restTermVO.getTopWaitNm());
				map.put("sleMthdCode", restTermVO.getSleMthdCode());
				
				if("01".equals(sleMthdCode)) {
					map.put("restDeLive", restTermVO.getRestdeAt());
				} else {
					map.put("restDeFixed", restTermVO.getRestdeAt());
				}

				returnMap.add(map);
			}

			return returnMap;
		} catch (Exception e) {
			log.error("selectRestDtTimeSet Error ====> {}", ExceptionUtils.getStackTrace(e));
			return null;
		}

	}

	@Override
	public Map<String, Object> restDtTimeSetSchdule() {
		MDC.put("scheduled", "true");
		Map<String,Object> map = new HashMap<>();
		map.put("restDtTime",selectRestDtTimeSet());
		return map;
	}

	@Override
	public String selectDlvyIngCnt(Map<String, Object> param) {
		return mainMapper.selectDlvyIngCnt(param);
	}

	@Override
	public List<PopupDocVO> selectMainPopupNoticeDocCourse() {
		
		List<PopupDocVO> docNo =  new ArrayList<PopupDocVO>();
		List<PopupDocVO> returnMap = new ArrayList<>();
		
		docNo =	mainMapper.selectMainPopupNoticeDocNo();
		
		if(docNo == null) {
			return null;
		}
			try {
				for(int i=0; i<docNo.size(); i++) {
					FileDocVO noticeDoc;
					PopupDocVO PopupDocVO = new PopupDocVO();
					noticeDoc = fileDocService.selectDocInfo(docNo.get(i).getDocNo());
					
					if(noticeDoc.getDocFileRealCours() != null) {
						PopupDocVO.setNoticNo(docNo.get(i).getNoticNo());
						PopupDocVO.setDocImageUrl(noticeDoc.getDocFileRealCours());
						PopupDocVO.setEmergencyAt(docNo.get(i).getEmergencyAt());
						PopupDocVO.setMainpopupSizeCode(docNo.get(i).getMainpopupSizeCode());
						PopupDocVO.setMainpopupTopPosition(docNo.get(i).getMainpopupTopPosition());
						PopupDocVO.setMainpopupRightPosition(docNo.get(i).getMainpopupRightPosition());
						PopupDocVO.setMainpopupInnerPageLink (docNo.get(i).getMainpopupInnerPageLink());
						PopupDocVO.setMainpopupOuterPageLink(docNo.get(i).getMainpopupOuterPageLink());
						PopupDocVO.setMainpopupMberShowAt(docNo.get(i).getMainpopupMberShowAt());
					}
					
					returnMap.add(PopupDocVO);
				}

				
			} catch (Exception e) {
				// TODO Auto-generated catch block

				log.error(e.toString());
			}

		return returnMap;
	}
	
	@Override
	public PopupDocVO selectMainLargePopup() {
		PopupDocVO docNo = new PopupDocVO();
		
		docNo =	mainMapper.selectMainLargePopup();
		
		return docNo;
	}
	
	/**
	 * 조달청 가격을 가져온다
	 */
	@Override
	public List<Map<String, Object>> getSarokPcList(String getNowDate) {

		List<Map<String, Object>> returnValue = new ArrayList<Map<String, Object>>();

		Map<String, Object> params = new HashMap<>();

		params.put("getNowDate", getNowDate);

		returnValue = mainMapper.getSarokPcList(params);

		return returnValue;
	}
	
	@Override
	public List<HeaderMenuVO> selectHeaderMenu() throws Exception {
		List<HeaderMenuVO> headerVo = mainMapper.selectEntrpsMetalHeaderMenu();
		List<HeaderMenuVO> returnVo = new ArrayList<>();
		String type = userInfoUtil.getEntripsNo() == null ? "main" : "login";
		List<SelMetalVO> entrpsSelMetalList = pcMntrngService.getEntrpsSelMetalList(userInfoUtil.getEntripsNo(), null, null, null, type);
		List<PreminumSelVO> stdrPreminumInfoList = new ArrayList<>();

		for (SelMetalVO entrpsSelMetal : entrpsSelMetalList) {
			if("01".equals(entrpsSelMetal.getSleMthdCode())) {
				PreminumInfoDto preminumInfoDto = new PreminumInfoDto();
				preminumInfoDto.setStdDt(DateUtil.getNowDate()); // 오늘날짜
				preminumInfoDto.setSleMthdCode(entrpsSelMetal.getSleMthdCode());
				preminumInfoDto.setMetalCode(entrpsSelMetal.getMetalCode());	 // 금속코드
				preminumInfoDto.setItmSn(Integer.parseInt(entrpsSelMetal.getItmSn()));
				preminumInfoDto.setDstrctLclsfCode(entrpsSelMetal.getDstrctLclsfCode());
				preminumInfoDto.setBrandGroupCode(entrpsSelMetal.getBrandGroupCode());
				preminumInfoDto.setBrandCode(entrpsSelMetal.getBrandCode());
				preminumInfoDto.setValidBeginDt(DateUtil.getNowDateTime("yyyyMMddHHmmss"));
				preminumInfoDto.setValidEndDt(DateUtil.getNowDateTime("yyyyMMddHHmmss"));
				List<PreminumSelVO> stdrPreminumInfo = pcMntrngMapper.getFnPreminumInfoList(preminumInfoDto);
	
				if(stdrPreminumInfo.size() > 0) {
					stdrPreminumInfoList.add(stdrPreminumInfo.get(0));
				}
			}
		}
		
		for(HeaderMenuVO header : headerVo) {
			if(header.getMetalCode() == null || header.getMetalCode().equals("")) {
				returnVo.add(header);
			} else {
				if(userInfoUtil.getEntripsNo() == null || userInfoUtil.getEntripsNo().isEmpty()) {
					// 24-08-30 변경사항 : 신규 메뉴 "가단가구매" 추가.
					// 해당 구매 방식에 대한 설정이 있는 업체 대상으로만 노출 되는 메뉴로, 비로그인 시에는 노출하지 않음
					if(header.getCtgryNm().equals("가단가구매")) {
						continue;	// returnVo 에 추가하지 않고 다음 반복문 진행
					}
					
					if("Y".equals(header.getLiveSleAt())) {
						header.setSleMthdCode(CommonConstants.LIVE_SLE_MTHD_CODE);
						
						for (PreminumSelVO stdrPreminumInfo : stdrPreminumInfoList) {
							if(header.getMetalCode().equals(stdrPreminumInfo.getMetalCode()) && header.getSleMthdCode().equals(stdrPreminumInfo.getSleMthdCode())) {
								returnVo.add(header);
							}
							
						}
					} else if("Y".equals(header.getAvrgpcSleAt())) {
						for (SelMetalVO entrpsSelMetal : entrpsSelMetalList) {
							if(header.getMetalCode().equals(entrpsSelMetal.getMetalCode()) && "Y".equals(entrpsSelMetal.getAvrgpcSleAt())) {
								returnVo.add(header);
							}
						}
					}
				} else {
					// 24-08-30 변경사항 : 신규 메뉴 "가단가구매" 추가.
					// 해당 구매 방식에 대한 설정이 있는 업체 대상으로만 노출 되는 메뉴로, 구매 설정이 없으면 노출하지 않음
					if(header.getCtgryNm().equals("가단가구매")) {
						// "가단가구매" 구매 설정 조회 및 체크
						if(!mainMapper.getPrvsnlUntpcPurchsSetupAt(userInfoUtil.getEntripsNo())) {	// 구매 설정이 없으면
							continue;	// returnVo 에 추가하지 않고 다음 반복문 진행
						}
					}
					
					//판매방식코드 셋팅
					if("Y".equals(header.getLiveSleAt())) {
						header.setSleMthdCode(CommonConstants.LIVE_SLE_MTHD_CODE);
					} else if ("Y".equals(header.getHghnetprcSleAt())) {
						header.setSleMthdCode(CommonConstants.HGHNETPRC_SLE_MTHD_CODE);
					} else if ("Y".equals(header.getLimitsSleAt())) {
						header.setSleMthdCode(CommonConstants.LIMITS_SLE_MTHD_CODE);
					} else if ("Y".equals(header.getAvrgpcSleAt())) {
						header.setSleMthdCode(CommonConstants.AVRGPC_SLE_MTHD_CODE);
					}
					
					//헤더메뉴 표시 최종확인
					if(!returnVo.contains(header)) {
						boolean chkHeaderMenu = false;
						if("Y".equals(header.getLiveSleAt())) {
							for (PreminumSelVO stdrPreminumInfo : stdrPreminumInfoList) {
									if(header.getMetalCode().equals(stdrPreminumInfo.getMetalCode()) && header.getSleMthdCode().equals(stdrPreminumInfo.getSleMthdCode())) {
										chkHeaderMenu = true;
									}
							}
						} else if ("Y".equals(header.getHghnetprcSleAt())) {
							List<FixPriceVO> stdrFixPriceList = pcInfoService.hasEntrpsFixPriceDataList(header.getMetalCode(), "000", 0, "00",
									"00", "0000000000", userInfoUtil.getEntripsNo(), DateUtil.getNowDateTime("yyyyMM"));
							
							for (FixPriceVO fixPriceVO : stdrFixPriceList) {
								if(header.getMetalCode().equals(fixPriceVO.getMetalCode()) && header.getMetalClCode().equals(fixPriceVO.getMetalClCode())) {
									chkHeaderMenu = true;
								}
							}
						} else if("Y".equals(header.getAvrgpcSleAt()) || "N".equals(header.getAvrgpcSleAt())) {
							for (SelMetalVO entrpsSelMetal : entrpsSelMetalList) {
								if(header.getMetalCode().equals(entrpsSelMetal.getMetalCode())) {
									header.setAvrgpcSleAt(entrpsSelMetal.getAvrgpcSleAt());
									chkHeaderMenu = true;
								}
							}
						}
						if(chkHeaderMenu) {
							returnVo.add(header);
						}
					}
					
					// 24-08-30 변경사항 : 신규 메뉴 "가단가구매" 의 판매방식코드 세팅
					if(header.getCtgryNm().equals("가단가구매")) { 
						header.setSleMthdCode(CommonConstants.PRVSNL_UNTPC_SLE_MTHD_CODE);
					}
				}
			}
		}

		return returnVo;
	}
	
	/**
	 * <pre>
	 * 운영중인지 체크
	 * </pre>
	 * @date 2022. 09. 22.
	 * @author jhcha
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 09. 22.		jhcha				최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public String getWorkCheck() {
		
		return mainMapper.getWorkCheck();		
	}

	/**
	 * <pre>
	 * 처리내용: 메탈월드 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 10. 7.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 7.			srec0072			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@Override
	@Cacheable(cacheNames = "News_Info", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public List<MetalWorldVO> selectMetalWorldList() {
		return mainMapper.selectMetalWorldList();
	}
	
	/**
	 * <pre>
	 * 처리내용:전일종가 영역 데이터 조회
	 * </pre>
	 * @date 2024. 02. 14.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일                  작성자             변경내용
	 * ------------------------------------------------
	 * 2024. 02. 14.            sumin            최초작성
	 * ------------------------------------------------
	 * @return
	*/
	@Override
	public List<ClosingPcVO> selectClosingPcList() {
		return mainMapper.selectClosingPcList();
	}
	
	/**
	 * <pre>
	 * 처리내용:전일종가 영역 데이터 조회
	 * </pre>
	 * @date 2024. 02. 14.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일                  작성자             변경내용
	 * ------------------------------------------------
	 * 2024. 02. 14.            sumin            최초작성
	 * ------------------------------------------------
	 * @return
	*/
	@Override
	public List<YoutubeVO> selectYoutubeList() {
		return mainMapper.selectYoutubeList();
	}
}
