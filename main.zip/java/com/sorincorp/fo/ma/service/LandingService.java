package com.sorincorp.fo.ma.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.fo.cs.model.PchrgArticlVO;
import com.sorincorp.fo.ma.model.BbscttVO;
import com.sorincorp.fo.ma.model.NoticeVO;
import com.sorincorp.fo.pd.model.ItemDtlInfoVO;

public interface LandingService {

	/**
	 * <pre>
	 * 처리내용: 뉴스 클리핑을 조회한다.
	 * </pre>
	 * 
	 * @date 2023. 02. 07.
	 * @author cuko
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 02. 07.			cuko				최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public abstract List<BbscttVO> selectNewsClipping();

	/**
	 * <pre>
	 * 처리내용: 주요 뉴스를 조회한다.
	 * </pre>
	 * @date 2023. 02. 10.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 02. 10.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	PchrgArticlVO selectMainNewsVo() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 공지사항을 조회한다.
	 * </pre>
	 * @date 2023. 02. 10.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 02. 10.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	NoticeVO selectTopNotice() throws Exception;
	
	/**
	 * <pre>
	 * 특정 계정 전용 차트 화면
	 * </pre>
	 * @date 2023. 02. 15.
	 * @author sumin
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 02. 07.		sumin		최초작성
	 * -------------------------------------------------------------------------
	 * @param metalCode
	 * @param sleMthdCode
	 * @param type
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> getMainChartDate(String metalCode, String sleMthdCode, String type, String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 랜딩페이지 실시간 가격 조회한다.
	 * 
	 * @date 2023. 02. 15.
	 * @author sumin
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 02. 15.	sumin			최초작성 
	 * -------------------------------------------------------------------------
	 * @param PcMntrngSelVO
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> getLandingPcDate(String metalCode, String sleMthdCode, String metalClCode, String type, String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 입고알림 아이템을 조회한다.
	 * </pre>
	 * 
	 * @date 2023. 02. 10.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 02. 10.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	ItemDtlInfoVO selectItemNotice() throws Exception;

}
