package com.sorincorp.fo.ma.model;

import lombok.Data;

@Data
public class PopupDocVO {

	/******  JAVA VO CREATE : OP_NOTICE_BAS(운영_공지사항 팝업) ******/

	    /*** 공지사항 번호 */
	    private int noticNo;
	    /*** 문서 번호 */
	    private int docNo;
	    /*** 문서 이미지 url */
	    private String docImageUrl;
	    /*** 문서 이미지 url */
	    private String emergencyAt;
	    
	    /*** X 버튼 컬러 */
	    private String closeBtnColor;
	    /*** 오늘 하루 보지 않기 문구 컬러 */
	    private String todayWordColor;
	    private String popWidth;
	    private String popHeight; 
	    
	    /*** 
	     * 메인팝업 사이즈 코드 
	     */
	    private String mainpopupSizeCode;
	
	    /*** 
	     * 메인팝업 닫기 버튼 색상 
	     */
	    private String mainpopupCloseBtnColor;
	    
	    /*** 
	     * 메인팝업 스킵 체크박스 색상
	     */
	    private String mainpopupSkipChkboxColor;

	    /**
		 * 메인팝업 상단 포지션
		 */
		private String mainpopupTopPosition;

		/**
		 * 메인팝업 우측 포지션
		 */
		private String mainpopupRightPosition;
		
		/**
		 * 메인팝업 내부 페이지 링크
		 */
		private String mainpopupInnerPageLink;
		
		/**
		 * 메인팝업 외부 페이지 링크
		 */
		private String mainpopupOuterPageLink;
		
		/**
		 * 메인팝업 회원 노출 여부
		 */
		private String mainpopupMberShowAt ;


}
