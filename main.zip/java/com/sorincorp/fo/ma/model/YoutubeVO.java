package com.sorincorp.fo.ma.model;

import lombok.Data;

@Data
public class YoutubeVO {
	/**
	 * 유튜브링크 번호
	 */
	private String youtubeLinkSn;
	/**
	 * 유튜브링크 순번
	 */
	private String youtubeOrderBy;
	/**
	 * 유튜브링크
	 */
	private String youtubeLink;
	/**
	 * 유튜브제목
	 */
	private String youtubeTitle;
	/**
	 * 유튜브설명
	 */
	private String youtubeDesc;
}
