package com.sorincorp.fo.ma.model;

import lombok.Data;

@Data
public class EventHolidayVO {

	/******  JAVA VO CREATE : IT_EVENT_RESTDE_MANAGE_BAS()                                                                                   ******/
	    /**
	     * 이벤트 휴일 순번
	    */
	    private long eventRestdeSn;
	    /**
	     * 이벤트 휴일 명칭
	    */
	    private String eventRestdeNm;
	    /**
	     * 이벤트 휴일 구분 코드
	    */
	    private String eventRestdeSeCode;
	    /**
	     * 휴일 여부
	    */
	    private String restdeAt;
	    /**
	     * 적용 시작 일자
	    */
	    private String applcBeginDe;
	    /**
	     * 적용 종료 일자
	    */
	    private String applcEndDe;
	    /**
	     * 비고
	    */
	    private String rm;
	    /**
	     * 삭제 일시
	    */
	    private String deleteDt;
	    /**
	     * 삭제 여부
	    */
	    private String deleteAt;
	    /**
	     * 최초 등록자 아이디
	    */
	    private String frstRegisterId;
	    /**
	     * 최초 등록 일시
	    */
	    private String frstRegistDt;
	    /**
	     * 최종 변경자 아이디
	    */
	    private String lastChangerId;
	    /**
	     * 최종 변경 일시
	    */
	    private String lastChangeDt;
	    /**
	     * 월
	     */
	    private String month;
	    /**
	     * 일
	     */
	    private String day;
	    /**
	     * 국가 이미지
	     */
	    private String nationImageUrl;
	 
}