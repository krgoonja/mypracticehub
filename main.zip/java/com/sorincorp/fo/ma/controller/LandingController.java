package com.sorincorp.fo.ma.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.sidecar.service.SidecarService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.fo.chart.service.PcMntrngService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.cs.model.PchrgArticlVO;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.ma.model.NoticeVO;
import com.sorincorp.fo.ma.service.LandingService;
import com.sorincorp.fo.ma.service.MainService;
import com.sorincorp.fo.pd.model.ItemDtlInfoVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class LandingController {

	@Autowired
	LandingService landingService;

	@Autowired
	UserInfoUtil userInfoUtil;

	@Autowired
	MessageUtil messageUtil;

	@Autowired
	PcMntrngService pcMntrngService;

	@Autowired
	BsnInfoService bsnInfoService;

	@Autowired
	SimpMessagingTemplate simpMessagingTemplate;

	@Autowired
	SidecarService sidecarSerivce;
	
	@Autowired
	MainService mainService;

	@Autowired
	private HttpClientHelper httpClientHelper;
	
	@Value("${spring.fo.subDomain}")
	private String FO_SUBDOMAIN;
	
	@Value("${spring.fo.oldDomain}")
	private String OLD_FO_DOMAIN;
	
	/**
	 * <pre>
	 * 처리내용: 랜딩페이지 정보를 조회한다.
	 * </pre>
	 *
	 * @date 2023. 02. 07.
	 * @author cuko
	 * @history
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 02. 07.			cuko				최초작성
	 * 2023. 02. 10.			hyunjin05			노출데이터 추가
	 * 2023. 02. 15.			sumin				차트데이터 추가
     * 2023. 06. 22.            srec077             30일간 보지않기 추가
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/landing")
	public String landing(Model model, HttpServletRequest request, @RequestHeader(value="Host") String host) {
		
		if(host.indexOf(FO_SUBDOMAIN) > -1) {
			//return "redirect:/bid";
			return "bdTiles/bdMain";
		} else if(host.indexOf(OLD_FO_DOMAIN) > -1) {
			//도메인 변경 안내 페이지 이동
			//return "noTiles/svcChgInfo";
		}
		
	        // 쿠키 가져오기
	        Cookie[] cookies = request.getCookies();
	        boolean loadLandingPage = true;
		try {
            // 30일간 보지않기 쿠키 확인
            if (cookies != null) {
                for (Cookie cookie : cookies) {
                    String name = cookie.getName();
                    String value = cookie.getValue();

                    if(name.equals("popupShown")) {
                        if(value.equals("false")) {
                            loadLandingPage = false;
                        }
                    }
                }
            }

            Account account = userInfoUtil.getAccountInfo(request);
            Map<String,Object> loginStatusMap = new HashMap<String,Object>();
            Map<String, Object> resultMap = new HashMap<String,Object>();
            
		    if(!loadLandingPage) {
				if ( account == null) {
					loginStatusMap.put("loginYn","N");
				}else {
					loginStatusMap.put("loginYn","Y");
				}
				
				model.addAttribute("account", account);
				model.addAttribute("loginStatusMap", loginStatusMap); // 로그인 여부
				model.addAttribute("sidcar", sidecarSerivce.getSidecarOnList());
				model.addAttribute("noticeImage", mainService.selectMainPopupNoticeDocCourse());
				model.addAttribute("noticeLargeImage", mainService.selectMainLargePopup());
				
				return "ma/main";
		    } else {
				PchrgArticlVO mainNews = landingService.selectMainNewsVo();
				NoticeVO mainNotice = landingService.selectTopNotice();
				ItemDtlInfoVO itemNotice = landingService.selectItemNotice();
	
				if (account == null) {
					loginStatusMap.put("loginYn", "N");
				} else {
					loginStatusMap.put("loginYn", "Y");
				}
	
				resultMap = landingService.getMainChartDate(null, null, "landing", null);
	
				model.addAttribute("account", account);
				model.addAttribute("loginStatusMap", loginStatusMap); // 로그인 여부
				model.addAttribute("mainNews", mainNews); // 철강신문 - 헤드라인 뉴스
				model.addAttribute("mainNotice", mainNotice); // 공지사항 - 전체 공지 - 최신공지
				model.addAttribute("itemNotice", itemNotice); // 입고알림
				model.addAttribute("chartList", resultMap);			//차트 데이터
	
				return "noTiles/landing";
		    }
		} catch (Exception e) {
			log.error("[LandingController][landing]" + ExceptionUtils.getStackTrace(e));
            return "noTiles/landing";
		}
	}
	/**
	 * <pre>
	 * 처리내용: 랜딩페이지 에서 페이지 이동 시 사용
	 * </pre>
	 *
	 * @date 2023. 02. 15.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 02. 10.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/redirect")
	public String redirect(Model model, HttpServletRequest request, @RequestParam(value = "redirectUrl", required = false) String redirectUrl, @RequestParam(value = "redirectParam", required = false) String redirectParam, @RequestParam(value = "redirectParamData", required = false) String redirectParamData, @RequestParam(value = "redirectMenuActiveIdenty", required = false) String redirectMenuActiveIdenty) {
		String data = "";
		String[] param;
		String[] paramData;
		Map<String, Object> mainChart = new HashMap<String,Object>();
		try {
			Map<String, Object> loginStatusMap = new HashMap<String, Object>();
			Account account = userInfoUtil.getAccountInfo(request);
			Map<String, Object> map = new HashMap<String, Object>();
			if (account == null) {
				loginStatusMap.put("loginYn", "N");
				mainChart = pcMntrngService.getItemChartDate(null,null,"main", null);
			} else {
				loginStatusMap.put("loginYn", "Y");
				mainChart = pcMntrngService.getItemChartDate(null,null,"login",account.getEntrpsNo());
			}

			if(!isStringEmpty(redirectUrl)) {
				map.put("redirectUrl", redirectUrl);
			}
			if(!isStringEmpty(redirectMenuActiveIdenty)) {
				map.put("redirectMenuActiveIdenty", redirectMenuActiveIdenty);
			}

			param = redirectParam.split(",");
			redirectParamData = redirectParamData.replaceAll("&quot;", "");
			paramData = redirectParamData.split(",");

			if(!isStringEmpty(redirectParam)) {
				data += '{';
				for (int i = 0; i < param.length; i++) {
					if (i == param.length - 1) {
						data += "'" + param[i] + "':'" + paramData[i] + "'";
					} else {
						data += "'" + param[i] + "':'" + paramData[i] + "',";
					}
				}
				data += '}';
				model.addAttribute("data", data); // 페이지 이동 파라메타
			}

			model.addAttribute("account", account);
			model.addAttribute("loginStatusMap", loginStatusMap); // 로그인 여부
			model.addAttribute("map", map); // 데이터
			model.addAttribute("chartList", mainChart);  // 차트 데이터
			
			//JS파일에서 사용 하기위한 JSON데이터로 변환
			ObjectMapper objectMapper = new ObjectMapper();
			String jsonMainChart = objectMapper.writeValueAsString(mainChart);
			
			model.addAttribute("jsonChartList", jsonMainChart);

		} catch (Exception e) {
			log.error("[LandingController][redirect]" + ExceptionUtils.getStackTrace(e));
			// TODO: handle exception
		}
		return "la/redirect";
	}

	/**
	 * <pre>
	 * 처리내용: 메인화면 정보를 조회한다.
	 * </pre>
	 * @date 2022. 10. 7.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 7.			srec0072			메탈월드 리스트 조회 추가
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/mainForVrsc")
	public String mainForVrsc(@RequestParam(value="mberId") String mberId, Model model) {
//    public String mainForVrsc(@RequestParam(value="mberid") String mberid
//    					, @RequestParam(value="vrscYn") Boolean vrscYn
//    					,  Model model, HttpServletRequest request, HttpServletResponse response) {
		try {			
			model.addAttribute("mberId", mberId);
			return "noTiles/vrscWorkPopup";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	

	
	//데이터 유무 확인
	private boolean isStringEmpty(String redirectParamData) {
		return redirectParamData == "" || redirectParamData == null || redirectParamData.isEmpty();
	}

}