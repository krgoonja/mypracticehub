package com.sorincorp.fo.ma.controller;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.map.HashedMap;
import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import com.sorincorp.comm.bsnInfo.model.RltmEndTimeVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.sidecar.service.SidecarService;
import com.sorincorp.fo.op.service.PromtnBannerService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.chart.service.PcMntrngService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.cs.model.PchrgArticlVO;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.ma.model.ClosingPcVO;
import com.sorincorp.fo.ma.model.EventHolidayVO;
import com.sorincorp.fo.ma.model.MetalWorldVO;
import com.sorincorp.fo.ma.model.NoticeVO;
import com.sorincorp.fo.ma.service.MainService;
import com.sorincorp.fo.op.model.PromtnBannerVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class MainController {

	@Autowired
	MainService mainService;
	
	@Autowired
	PromtnBannerService promtnBannerService;

	@Autowired
	UserInfoUtil userInfoUtil;

	@Autowired
	MessageUtil messageUtil;

	@Autowired
	PcMntrngService pcMntrngService;

	@Autowired
	BsnInfoService bsnInfoService;

	@Autowired
	SimpMessagingTemplate simpMessagingTemplate;

	@Autowired
	SidecarService sidecarSerivce;

	@Value("${spring.bo.domain}")
	private String boDomain;

	@Value("${spring.fo.subDomain}")
	private String FO_SUBDOMAIN;

	@Value("${spring.fo.oldDomain}")
	private String OLD_FO_DOMAIN;

	@Autowired
	private HttpClientHelper httpClientHelper;

	/**
	 * <pre>
	 * 처리내용: 메인화면 정보를 조회한다.
	 * </pre>
	 * @date 2022. 10. 7.
	 * @author srec0072
	 * @history
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 7.			srec0072			메탈월드 리스트 조회 추가
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/")
    public String main( Model model, HttpServletRequest request, @RequestHeader(value="Host") String host) {

		if(host.indexOf(FO_SUBDOMAIN) > -1) {
			//return "redirect:/bid";
			return "bdTiles/bdMain";
		} else if(host.indexOf(OLD_FO_DOMAIN) > -1) {
			//도메인 변경 안내 페이지 이동
			//return "noTiles/svcChgInfo";
		}

		try {
		    Map<String,Object> loginStatusMap = new HashMap<String,Object>();
			Account account = userInfoUtil.getAccountInfo(request);

			if ( account == null) {
				loginStatusMap.put("loginYn","N");
			}else {
				loginStatusMap.put("loginYn","Y");
			}

			model.addAttribute("account", account);
			model.addAttribute("loginStatusMap", loginStatusMap); // 로그인 여부
			model.addAttribute("sidcar", sidecarSerivce.getSidecarOnList());
			model.addAttribute("noticeImage", mainService.selectMainPopupNoticeDocCourse());
			model.addAttribute("noticeLargeImage", mainService.selectMainLargePopup());
//			model.addAttribute("youtubeList", mainService.selectYoutubeList());
			model.addAttribute("youtubeList", promtnBannerService.selectRelmBannerList("EB"));
			model.addAttribute("subBannerList", promtnBannerService.selectRelmBannerList("MB"));

		} catch (Exception e) {
			log.error("[MainController][main]" + ExceptionUtils.getStackTrace(e));
		}

		return "ma/main";
	}

	@RequestMapping("/fsHttpHealthTest")
	public ResponseEntity<Object> fsHttpHealthTest() {
		try {
			Map<String, Object> resObj = httpClientHelper.getCallApi("http://10.207.0.10:28089/samsung/ftrs/health");

			if(resObj == null) {
				return new ResponseEntity<>("null", HttpStatus.BAD_REQUEST);
			}

			return new ResponseEntity<>(resObj, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping("/fxHttpHealthTest")
	public ResponseEntity<Object> fxHttpHealthTest() {
		try {
			Map<String, Object> resObj = httpClientHelper.getCallApi("http://10.202.0.10:28090/hanafx/fshg/health");

			if(resObj == null) {
				return new ResponseEntity<>("null", HttpStatus.BAD_REQUEST);
			}

			return new ResponseEntity<>(resObj, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping("/vaHttpHealthTest")
	public ResponseEntity<Object> vaHttpHealthTest() {
		try {
			Map<String, Object> resObj = httpClientHelper.postCallApi("http://10.202.0.10:28088/api/ewallet/money", "");

			if(resObj == null) {
				return new ResponseEntity<>("null", HttpStatus.BAD_REQUEST);
			}

			return new ResponseEntity<>(resObj, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping("/apiHttpHealthTest")
	public ResponseEntity<Object> apiHttpHealthTest(@Value("${order.api.lo.oms.url}") String apiLoUrl) {
		log.debug(">> apiLoUrl : " + apiLoUrl);

		String url = apiLoUrl + "/vaConnectTest?test=money";

		try {
			Map<String, Object> resObj = httpClientHelper.getCallApi(url);
			log.debug(">> resObj : " + resObj);

			if(resObj == null) {
				return new ResponseEntity<>("null", HttpStatus.BAD_REQUEST);
			}

			return new ResponseEntity<>(resObj, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 이번 달 이벤트 조회
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param month
	 * @return
	 */
	@ResponseBody
	@GetMapping("/main/monthly-event")
	public ResponseEntity<Object> selectMonthlyEvent(String month, String day) {
		List<EventHolidayVO> monthlyEventList = mainService.selectMonthlyEvent(month, day);
		return new ResponseEntity<>(monthlyEventList, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 헤더 - 공지사항 조회
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@ResponseBody
	@GetMapping("/main/topnotice")
	public ResponseEntity<Object> selectTopNotice() {
		List<NoticeVO> topNoticeList = mainService.selectTopNotice();
		return new ResponseEntity<>(topNoticeList, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 헤더 - 이웰렛 잔액 조회
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	@ResponseBody
	@GetMapping("/main/eWalletAccount")
	public ResponseEntity<Object> selectEWalletAccount(String entrpsNo) {
		String ewalletBlce = mainService.selectEWalletAccount(entrpsNo);
		return new ResponseEntity<>(ewalletBlce, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 헤더 - 영업시간 여부, 고정가 실시간가 운영 여부 조회
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
//	@ResponseBody
//	@PostMapping("/main/headerRestInfo")
//	public ResponseEntity<Object>  headerRestInfo() {
//		Map<String,Object> restInfo = mainService.headerRestInfo();
//		return new ResponseEntity<>(restInfo, HttpStatus.OK);
//	}


	/**
	 * <pre>
	 * 처리내용: 헤더 타이머 최초값 조회 - 타이머 문구, 시간차, 개장시간 범위 코드
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@ResponseBody
	@PostMapping("/main/restDtTimeSet")
	public ResponseEntity<Object> restDtTimeSet(){

		Map<String,Object> restDtTimeMap = new HashMap<>();

		try {
			restDtTimeMap.put("restDtTime",mainService.selectRestDtTimeSet());
		} catch (Exception e) {
			log.error("[MainController][restDtTimeSet]" + ExceptionUtils.getStackTrace(e));
		}

		return new ResponseEntity<>(restDtTimeMap, HttpStatus.OK);

	}


    /**
     * <pre>
     * 처리내용: 서버시간 리턴
     * </pre>
     * @date 2023. 06. 26.
     * @author srec0004
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 06. 26.            srec0004            최초작성
     * ------------------------------------------------
     * @return
     */
    @ResponseBody
    @GetMapping("/getServerTime")
    public ResponseEntity<Object> getServerTime(){
        return new ResponseEntity<>(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"), HttpStatus.OK);

    }


	/**
	 * <pre>
	 * 처리내용: 스케줄 (1분에 한번 씩 호출)
	 * 			 헤더 타이머 조회 - 타이머 문구, 시간차, 개장시간 범위 코드
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
    @Scheduled(cron = "0 * * * * *")
	public void restDtTimeSetSchdule() throws Exception {
		// 1분에 한번 씩 호출
		Map<String,Object> timeSetMap = mainService.restDtTimeSetSchdule();
		simpMessagingTemplate.convertAndSend("/selectHeaderTimeSet",timeSetMap);
	}

	/**
	 * <pre>
	 * 처리내용: 헤더 메뉴를 조회한다.
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@ResponseBody
	@PostMapping("/selectHeaderMenu")
	public ResponseEntity<Object> selectHeaderMenu(){
		Map<String,Object> headerMenuMap = new HashMap<>();

		try {
			headerMenuMap.put("headerMenuList", mainService.selectHeaderMenu());
			return new ResponseEntity<>(headerMenuMap, HttpStatus.OK);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error("[MainController][selectHeaderMenu]" + ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}


	@ResponseBody
	@GetMapping("/main/dlvyIngCnt")
	public ResponseEntity<Object> dlvyIngCnt(HttpServletRequest request) {
		Account account = userInfoUtil.getAccountInfo(request); // 세션정보
		if (null == account || StringUtil.isBlank(userInfoUtil.getEntripsNo())) {
			return new ResponseEntity<>("0", HttpStatus.OK);
		}

		Map<String, Object> param = new HashMap<String, Object>();
		param.put("mberNo", account.getMberNo()); // 회원번호
		param.put("entrpsNo" , userInfoUtil.getEntripsNo()); // 업체번호
		param.put("memberSecode", userInfoUtil.getMemberSecode()); // 권한 구분 코드

		String cnt = mainService.selectDlvyIngCnt(param);
		return new ResponseEntity<>(cnt, HttpStatus.OK);
	}

	@RequestMapping("/main/getSarokPcList")
	@ResponseBody
	public List<Map<String, Object>> getSarokPcList() throws Exception {
		return mainService.getSarokPcList(DateUtil.getNowDate());
	}

    /**
     * <pre>
     * 처리내용: 메인배너를 조회한다.
     * </pre>
     * @date 2022. 11. 04.
     * @author srec0004
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 11. 04.            srec0004            최초작성
     * ------------------------------------------------
     * @return
     */
    @PostMapping("/getMainBanner")
    public String getMainBanner(ModelMap model) {
        try {
        	RltmEndTimeVO nightTimeVO = bsnInfoService.getRltmEndTime();
        	List<PromtnBannerVO> promoVO = promtnBannerService.selectRelmBannerList("VB");
        	model.addAttribute("bannerList", promoVO);
        	model.addAttribute("nightTimeVO", nightTimeVO);
            return "ma/mainBanner";
        } catch (Exception e) {

            log.error(e.getMessage());
            return "error/503";
        }
    }

    /**
     * <pre>
     * 처리내용: 메인주요뉴스를 조회한다.
     * </pre>
     * @date 2022. 11. 04.
     * @author srec0004
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 11. 04.            srec0004            최초작성
     * ------------------------------------------------
     * @return
     */
    @PostMapping("/getMainNewsList")
    public String getMainNewsList(ModelMap model) {
        try {
            List<PchrgArticlVO> mainNewsList = mainService.selectMainNews();
            model.addAttribute("mainNewsList", mainNewsList); //주요 뉴스
            return "ma/mainNewsList";
        } catch (Exception e) {

            log.error(e.getMessage());
            return "error/503";
        }
    }

    /**
     * <pre>
     * 처리내용: 메탈월드 월간지를 조회한다.
     * </pre>
     * @date 2022. 11. 04.
     * @author srec0004
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 11. 04.            srec0004            최초작성
     * ------------------------------------------------
     * @return
     */
    @PostMapping("/getMainMetalWorldList")
    public String getMainMetalWorldList(ModelMap model) {
        try {
            List<MetalWorldVO> metalWorldList = mainService.selectMetalWorldList();
            model.addAttribute("metalWorldList", metalWorldList); //메탈 월드 데이터
            return "ma/mainMetalWorldList";
        } catch (Exception e) {

            log.error(e.getMessage());
            return "error/503";
        }
    }

    /**
     * <pre>
     * 처리내용: 최신뉴스를 조회한다.
     * </pre>
     * @date 2022. 11. 04.
     * @author srec0004
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 11. 04.            srec0004            최초작성
     * ------------------------------------------------
     * @return
     */
    @PostMapping("/getMainNewsClippingList")
    public String getMainNewsClippingList(ModelMap model) {
        try {
            List<PchrgArticlVO> newsClippingList = mainService.selectNewsArticle();
            model.addAttribute("newsClippingList", newsClippingList); //최신 뉴스
            return "ma/mainNewsClippingList";
        } catch (Exception e) {

            log.error(e.getMessage());
            return "error/503";
        }
    }
    
    /**
     * <pre>
     * 처리내용: 원자제캘린더를 조회한다.
     * </pre>
     * @date 
     * @author hanjook
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 
     * ------------------------------------------------
     * @return
     */
    @RequestMapping("/getMainMetalCalendarList")    
    public String getMainMetalCalendarList(@RequestBody(required = false) EventHolidayVO vo, ModelMap model) {
        try {
        	//List<EventHolidayVO> monthlyEventList = mainService.selectMonthlyEvent(vo.getMonth(), vo.getDay());
            //model.addAttribute("monthlyEventList", monthlyEventList); //최신 뉴스
            model.addAttribute("month", vo.getMonth());
            model.addAttribute("day", vo.getDay());
            
            //캘린더 레이아웃 용 달의 마지막 날짜 return
            DateTimeFormatter formatter = new DateTimeFormatterBuilder()
                    .appendPattern("yyyyMM")
                    .parseDefaulting(ChronoField.DAY_OF_MONTH, 1)
                    .toFormatter();
            LocalDate date = LocalDate.parse(vo.getMonth(), formatter);
            LocalDate lastMonDate = date.withDayOfMonth(date.lengthOfMonth());       
            String lastDate = Integer.toString(lastMonDate.getDayOfMonth());
            model.addAttribute("lastDate", lastDate);
            
            return "ma/mainMetalCalendar";
        } catch (Exception e) {
            log.error(e.getMessage());
            return "error/503";
        }
    }
    
    /**
     * <pre>
     * 처리내용: 원자제캘린더를 조회한다.
     * </pre>
     * @date 
     * @author hanjook
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 
     * ------------------------------------------------
     * @return
     */
    @RequestMapping("/getMainMetalCalendarAjax")
    @ResponseBody
    public Map<String, Object> getMainMetalCalendarAjax(@RequestBody EventHolidayVO vo, ModelMap model) {                
    	Map<String, Object> map = new HashedMap<>();
		List<EventHolidayVO> eventList = mainService.selectMonthlyEvent(vo.getMonth(), vo.getDay());
		map.put("eventList",eventList);
    	return map;
    }


    /**
     * <pre>
     * 처리내용: 케이지트레이딩 소개를 조회한다.
     * </pre>
     * @date 2022. 11. 04.
     * @author srec0004
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 11. 04.            srec0004            최초작성
     * ------------------------------------------------
     * @return
     */
    @PostMapping("/getMainSorinIntroduce")
    public String getMainSorinIntroduce(ModelMap model) {
        try {
            return "ma/mainSorinIntroduce";
        } catch (Exception e) {

            log.error(e.getMessage());
            return "error/503";
        }
    }

    /**
     * <pre>
     * 처리내용: 케이지트레이딩 소개/견적문의/협력사 소개를 조회한다.
     * </pre>
     * @date 2022. 11. 04.
     * @author srec0004
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 11. 04.            srec0004            최초작성
     * ------------------------------------------------
     * @return
     */
    @PostMapping("/getMainIntroduce")
    public String getMainIntroduce(ModelMap model) {
        try {
            return "ma/mainIntroduce";
        } catch (Exception e) {

            log.error(e.getMessage());
            return "error/503";
        }
    }

    /**
     * <pre>
     * 처리내용:전일종가 영역 데이터 조회
     * </pre>
     * @date 2024. 02. 14.
     * @author sumin
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2024. 02. 14.            sumin            최초작성
     * ------------------------------------------------
     * @return
     */
    @PostMapping("/selectClosingPc")
    public String selectClosingPc(ModelMap model) {
        try {
        	List<ClosingPcVO> closingPcList = mainService.selectClosingPcList();
        	model.addAttribute("closingPcList", closingPcList);
            return "ma/closingPcListNew";
        } catch (Exception e) {

            log.error(e.getMessage());
            return "error/503";
        }
    }
}