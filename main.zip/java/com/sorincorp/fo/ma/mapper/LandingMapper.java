package com.sorincorp.fo.ma.mapper;

import java.util.List;

import com.sorincorp.fo.cs.model.PchrgArticlVO;
import com.sorincorp.fo.ma.model.BbscttVO;
import com.sorincorp.fo.ma.model.NoticeVO;
import com.sorincorp.fo.pd.model.ItemDtlInfoVO;

public interface LandingMapper {

	public abstract List<BbscttVO> selectNewsClipping();

	PchrgArticlVO selectMainNews() throws Exception;

	NoticeVO selectTopNotice() throws Exception;

	ItemDtlInfoVO selectItemNotice() throws Exception;

}
