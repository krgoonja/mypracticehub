package com.sorincorp.fo.extrl.service;

import java.util.Map;

/**
 * ExtrlPcProvdService.java
 * 
 * @version
 * @since 2023. 01. 19.
 * @author sumin95
 */
public interface ExtrlPcProvdService {

	/**
	 * <pre>
	 * 특정 계정 전용 차트 화면
	 * </pre>
	 * 
	 * @date 2023. 01. 19.
	 * @author sumin95
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 9. 15.		sumin95			최초작성 
	 * -------------------------------------------------------------------------
	 * @param PcMntrngSelVO
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> getMainChartDate(String metalCode, String sleMthdCode, String type, String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 철강신문 실시간 가격 페이지를 조회한다.
	 * 
	 * @date 2023. 01. 19.
	 * @author sumin95
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 9. 15.		sumin95			최초작성 
	 * -------------------------------------------------------------------------
	 * @param PcMntrngSelVO
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> getSteelPcDate(String metalCode, String sleMthdCode, String metalClCode, String type, String entrpsNo) throws Exception;

}
