package com.sorincorp.fo.extrl.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.codehaus.plexus.util.ExceptionUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.bsnInfo.model.RestTermVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.pcInfo.model.PrPremiumSelVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.model.PreminumSelInfoVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.fo.chart.mapper.PcMntrngMapper;
import com.sorincorp.fo.chart.model.MainPriceListVO;
import com.sorincorp.fo.chart.model.PrLmePblntfPcBasVO;
import com.sorincorp.fo.chart.model.SelMetalVO;
import com.sorincorp.fo.chart.service.PcMntrngServiceImpl;
import com.sorincorp.fo.extrl.mapper.ExtrlPcProvdMapper;

import lombok.extern.slf4j.Slf4j;

/**
 * ExtrlPcProvdService.java
 * 
 * @version
 * @since 2023. 01. 19.
 * @author sumin
 */
@Slf4j
@Service
public class ExtrlPcProvdServiceImpl implements ExtrlPcProvdService {

	@Autowired
	ExtrlPcProvdMapper extrlPcProvdMapper;

	@Autowired
	PcMntrngMapper pcMntrngMapper;

	@Autowired
	PcMntrngServiceImpl pcMntrngServiceImpl;

	@Autowired
	CommonCodeService commonCodeService;

	@Autowired
	private BsnInfoService bsnInfoService;

	@Autowired
	private PcInfoService pcInfoService;

	@Autowired
	private ItemCodeService itemCodeService;

	@Override
	public Map<String, Object> getMainChartDate(String metalCode, String sleMthdCode, String type, String entrpsNo) throws Exception {
		return getSteelPcDate(null, null, null, "main", null);
	}

	/**
	 * <pre>
	 * 처리내용: 철강신문 실시간 가격 페이지를 조회한다.
	 * </pre>
	 * 
	 * @date 2023. 01. 19.
	 * @author sumin
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 01. 19.	sumin			최초작성
	 * -------------------------------------------------------------------------
	 * @param metalCode
	 * @param sleMthdCode
	 * @param metalClCode
	 * @param type
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> getSteelPcDate(String metalCode, String sleMthdCode, String metalClCode, String type, String entrpsNo) throws Exception {
		Map<String, Object> returnChartData = new HashMap<String, Object>();
		List<MainPriceListVO> liveListVo = new ArrayList<MainPriceListVO>();

		// 휴일 여부 조회
		List<RestTermVO> restTermListVO = bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");

		// 권역 조회
		Map<String, CommonCodeVO> brandCode = commonCodeService.getSubCodesRetVo("BRAND_GROUP_CODE");
		Map<String, CommonCodeVO> dstrctLclsfCode = commonCodeService.getSubCodesRetVo("DSTRCT_LCLSF_CODE");

		// 기업회원 메탈 및 판매방식 리스트호출
		List<SelMetalVO> selMetalList = getSelMetalList(entrpsNo, metalCode, metalClCode, sleMthdCode, type);
		List<SelMetalVO> matalCodeLiveList = new ArrayList<SelMetalVO>();

		for (int i = 0; i < selMetalList.size(); i++) {
			matalCodeLiveList.add(selMetalList.get(i));
		}

		//프리미엄정보 조회
		List<PreminumSelInfoVO> premiumInfoListByRedisData = pcInfoService.getPremiumInfoListByRedisData();
		
		// 실시간 가격
		for (SelMetalVO liveCode : matalCodeLiveList) {
			List<PreminumSelInfoVO> preminumInfoList = null;
			preminumInfoList = premiumInfoListByRedisData.stream().filter(preminumInfo -> 
				preminumInfo.getMetalCode().equals(liveCode.getMetalCode()) 
				&& preminumInfo.getItmSn() == Integer.parseInt(liveCode.getItmSn())
				&& preminumInfo.getBrandCode().equals(liveCode.getBrandCode())
			).collect(Collectors.toList());
			
			// 실시간
			MainPriceListVO paramVO = new MainPriceListVO();
			
			PreminumSelInfoVO stdrPreminumInfo = null;
			if(preminumInfoList != null) {
				for (PreminumSelInfoVO stdrPreminum : preminumInfoList) {
					if(stdrPreminum.getMetalCode().equals(liveCode.getMetalCode()) 
					&& stdrPreminum.getItmSn() == Integer.parseInt(liveCode.getItmSn())
					&& stdrPreminum.getDstrctLclsfCode().equals(liveCode.getDstrctLclsfCode()) 
					&& stdrPreminum.getBrandGroupCode().equals(liveCode.getBrandGroupCode())
					&& stdrPreminum.getBrandCode().equals(liveCode.getBrandCode())) {
						stdrPreminumInfo = stdrPreminum;
					}
				}
			}
			
			if(stdrPreminumInfo != null) {
				// 실시간 기준 가격 파라미터 세팅
				paramVO.setMetalCode(liveCode.getMetalCode()); // 금속 코드*
				paramVO.setItmSn(Integer.parseInt(liveCode.getItmSn())); // 아이탬 순번*
				paramVO.setDstrctLclsfCode(liveCode.getDstrctLclsfCode()); // 권역코드*
				paramVO.setBrandGroupCode(liveCode.getBrandGroupCode()); // 브랜드 그룹코드*
				paramVO.setBrandCode("0000000000"); // 브랜드 코드
				paramVO.setSleMthdCode(liveCode.getSleMthdCode());
				paramVO.setCodeNm(liveCode.getCodeNm());
				paramVO.setMetalClCode(liveCode.getMetalClCode());

				// 기준아이템 문구
				paramVO.setCodeDcone(liveCode.getCodeDcone()); // 금속코드 영문명
				paramVO.setCodeChrctrRefrnsix(liveCode.getCodeChrctrRefrnsix()); // 금속코드 한글명
				paramVO.setCodeChrctrRefrntwo(liveCode.getCodeChrctrRefrntwo());
				paramVO.setBrandGroupNm(brandCode.get(stdrPreminumInfo.getBrandGroupCode()).getCodeDcone());
				paramVO.setDstrctLclsfName(dstrctLclsfCode.get(stdrPreminumInfo.getDstrctLclsfCode()).getCodeNm());
				
				List<ItemCodeVO> itemCodeList = itemCodeService.getItemCodeList(liveCode.getMetalCode());
				
				for(ItemCodeVO itemCodeVO : itemCodeList) {
					if(itemCodeVO.getSubCode().equals(liveCode.getItmSn())) {
						paramVO.setGoodsNm(itemCodeVO.getDspyGoodsNm());
					}
				}

				// 기준아이템 제원 (P1020)
				String str = paramVO.getGoodsNm();
				String specifications[] = str.split("[(|)]");
				
				if (specifications.length > 1) {
					if(specifications[1] != null) {
						paramVO.setSpecifications(specifications[1]);
					}
				}
					
				// 기준 매매가 조회
				PrSelVO avgCspVo = pcInfoService.getAvgDeEndPrice(paramVO.getMetalCode(), paramVO.getItmSn(), paramVO.getDstrctLclsfCode(), paramVO.getBrandGroupCode(), paramVO.getBrandCode());

				if (avgCspVo != null) {
					paramVO.setAvgSelPc(avgCspVo.getAvgSelPc());
					paramVO.setAccmltLmeCsp(avgCspVo.getAccmltLmeCsp());
					paramVO.setAccmltUsdCvtrate(avgCspVo.getAccmltUsdCvtrate());
				} else {
					paramVO.setAvgSelPc("0");
					paramVO.setAccmltLmeCsp("0");
					paramVO.setAccmltUsdCvtrate("0");
				}
				
				//실시간 기준가 조회
				List<PrPremiumSelVO> chartTitleInfoByRedisDataList = (List<PrPremiumSelVO>) pcInfoService.getChartTitleInfoByRedisData(paramVO.getMetalCode());
				
				for (PrPremiumSelVO chartTitleInfoByRedisData : chartTitleInfoByRedisDataList) {
					if(chartTitleInfoByRedisData.getMetalCode().equals(paramVO.getMetalCode()) 
						&& chartTitleInfoByRedisData.getItmSn() == paramVO.getItmSn()
						&& chartTitleInfoByRedisData.getDstrctLclsfCode().equals(paramVO.getDstrctLclsfCode()) 
						&& chartTitleInfoByRedisData.getBrandGroupCode().equals(paramVO.getBrandGroupCode())
						&& chartTitleInfoByRedisData.getBrandCode().equals(paramVO.getBrandCode())) {
							
						paramVO.setEndPc(chartTitleInfoByRedisData.getEndPc() > 0 ? chartTitleInfoByRedisData.getEndPc() : chartTitleInfoByRedisData.getPastEndPc()); // 현재가격
						paramVO.setTopPc(chartTitleInfoByRedisData.getTopPc()); // 현재 고가
						paramVO.setLwetPc(chartTitleInfoByRedisData.getLwetPc()); // 현재 저가
						paramVO.setBeginPc(chartTitleInfoByRedisData.getBeginPc()); // 현재 시가
						paramVO.setEndPcAgo(chartTitleInfoByRedisData.getPastEndPc());	// 전날 종가
						paramVO.setFluctuationRate(chartTitleInfoByRedisData.getVersusRate().floatValue());// 등락률
						paramVO.setVersusPc(chartTitleInfoByRedisData.getVersusPc());						 // 대비가격	
						paramVO.setOccrrncDe(chartTitleInfoByRedisData.getSlePcRltmSn().substring(0, 8));
						paramVO.setOccrrncTime(chartTitleInfoByRedisData.getSlePcRltmSn().substring(8, 14));
						
						//프리미엄 기준정보 세팅
						stdrPreminumInfo.setAgoEndPc((long) chartTitleInfoByRedisData.getPastEndPc());
						paramVO.setPreminumSelVO(stdrPreminumInfo);
					}
					
					// 케이지트레이딩 시세
					if(preminumInfoList != null) {
						for (int i = 0; i < preminumInfoList.size(); i++) {
							if(chartTitleInfoByRedisData.getMetalCode().equals(paramVO.getMetalCode()) 
								&& chartTitleInfoByRedisData.getItmSn() == preminumInfoList.get(i).getItmSn()
								&& chartTitleInfoByRedisData.getDstrctLclsfCode().equals(preminumInfoList.get(i).getDstrctLclsfCode()) 
								&& chartTitleInfoByRedisData.getBrandGroupCode().equals(preminumInfoList.get(i).getBrandGroupCode())
								&& "0000000000".equals(chartTitleInfoByRedisData.getBrandCode())) {
								
								preminumInfoList.get(i).setEndPc(chartTitleInfoByRedisData.getEndPc() > 0 ? chartTitleInfoByRedisData.getEndPc() : chartTitleInfoByRedisData.getPastEndPc()); //아이탬별 종가
								preminumInfoList.get(i).setVersusPc(chartTitleInfoByRedisData.getVersusPc());
								preminumInfoList.get(i).setVersusRate(chartTitleInfoByRedisData.getVersusRate().floatValue());
								preminumInfoList.get(i).setAgoEndPc(chartTitleInfoByRedisData.getPastEndPc());
								preminumInfoList.get(i).setBrandGroupNm(brandCode.get(preminumInfoList.get(i).getBrandGroupCode()).getCodeDcone());
								preminumInfoList.get(i).setDstrctLclsfNm(dstrctLclsfCode.get(preminumInfoList.get(i).getDstrctLclsfCode()).getCodeNm());
							}
						}
					}
				}
				
				paramVO.setPreminumSelListVO(preminumInfoList);

				// LME 가격 조회
				PrLmePblntfPcBasVO prLmePblntfPcBasVO = new PrLmePblntfPcBasVO();
				prLmePblntfPcBasVO.setMetalCode(paramVO.getMetalCode());
				prLmePblntfPcBasVO.setGicName(liveCode.getGicName());
				PrLmePblntfPcBasVO lmePriceVO = pcMntrngMapper.getPrLmePblntfPc(prLmePblntfPcBasVO);

				paramVO.setPrLmePblntfPcBasVO(lmePriceVO);

				liveListVo.add(paramVO);
			}
		}

		// 휴일 관련
		returnChartData.put("restdeInfoList", restTermListVO);

		// 라이브 시세 리스트
		returnChartData.put("liveList", liveListVo);

		return returnChartData;
	}

	// list<map> 을 json 형태로 변형.
	public static JSONArray convertListToJson(List<Map<String, Object>> bankCdList) {
		JSONArray jsonArray = new JSONArray();
		for (Map<String, Object> map : bankCdList) {
			jsonArray.add(convertMapToJson(map));
		}
		return jsonArray;
	}

	// map 을 json 형태로 변형
	public static JSONObject convertMapToJson(Map<String, Object> map) {
		JSONObject json = new JSONObject();
		for (Map.Entry<String, Object> entry : map.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			// json.addProperty(key, value);
			json.put(key, value);
		}
		return json;
	}

	// 기준메탈리스트 조회
	public List<SelMetalVO> getSelMetalList(String entrpsNo, String metalCode, String sleMthdCode, String metalClCode, String type) {
		List<SelMetalVO> selMetalList = new ArrayList<SelMetalVO>();
		try {
			List<ItemCodeVO> itemCodeList = new ArrayList<ItemCodeVO>();
			Map<String, List<String>> itemMetalList = new HashMap<>();

			for (ItemCodeVO itemCodeVO : itemCodeList) {
				List<String> sleMthdCodeList = new ArrayList<>();

				sleMthdCodeList.add("01");

				itemMetalList.put(itemCodeVO.getMetalCode(), sleMthdCodeList);
			}
			selMetalList = pcMntrngMapper.selectEntrpsSelMetalList(metalCode, sleMthdCode, metalClCode, type, itemMetalList);
		} catch (Exception e) {
			log.error("getEntrpsSelMetalList Error=====>" + ExceptionUtils.getStackTrace(e));
		}
		return selMetalList;
	}

	private float getVersusRate(long agoEndPcL, long nowEndPcL, long premiumAmountL) {
		float agoEndPcF = (float) agoEndPcL;
		float nowEndPcF = (float) nowEndPcL;
		float premiumAmountF = (float) premiumAmountL;

		float vsusRate = 0;

		if (agoEndPcF == 0) {
			vsusRate = 100;
		} else {
			vsusRate = ((nowEndPcF + premiumAmountF) - agoEndPcF) / agoEndPcF * 100;
		}

		String vsusRateStr = String.format("%.2f", vsusRate);

		return Float.parseFloat(vsusRateStr);
	}

	private String getPreviousDay() {
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.add(cal.DATE, -1); // 하루전

		return df.format(cal.getTime());
	}

}
