package com.sorincorp.fo.extrl.mapper;

import java.util.List;

import com.sorincorp.comm.pcInfo.model.PcMntrngSelVO;

/**
 * ExtrlPcProvdMapper.java
 * @version
 * @since 2023. 01. 19.
 * @author sumin95
 */
public interface ExtrlPcProvdMapper {
	
	/**
	 * <pre>
	 * 처리내용: 철강신문 실시간 가격 페이지를 조회한다.
	 * </pre>
	 * @date 2023. 01. 19.
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 01. 19.			sumin				최초작성
	 * ------------------------------------------------
	 * @param pcMntrngSelVO
	 * @return
	 * @throws Exception
	 */
	List<PcMntrngSelVO> selectSvcStplatList(PcMntrngSelVO pcMntrngSelVO) throws Exception;
}
