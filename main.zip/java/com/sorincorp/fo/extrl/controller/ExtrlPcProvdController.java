package com.sorincorp.fo.extrl.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.fo.chart.service.PcMntrngService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.extrl.service.ExtrlPcProvdService;
import com.sorincorp.fo.login.model.Account;

import lombok.extern.slf4j.Slf4j;

/**
 * ExtrlPcProvdController.java
 * 
 * @version
 * @since 2023. 01. 19.
 * @author sumin
 */
@Slf4j
@Controller
@RequestMapping("/fo/extrlPcProvd")
public class ExtrlPcProvdController {

	@Autowired
	private ExtrlPcProvdService extrlPcProvdService;

	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired
	UserInfoUtil userInfoUtil;
	
	@Autowired
	PcMntrngService pcMntrngService;


	/**
	 * <pre>
	 * 처리내용: 금속 코드를 가져온다
	 * </pre>
	 * 
	 * @date 2023. 01. 19.
	 * @author sumin
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 01. 19.	sumin			최초작성
	 * -------------------------------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping(value = "/getMetalCode")
	@ResponseBody
	public Map<String, Object> getMetalCode() throws Exception {
		Map<String, Object> returnMap = new HashMap<String, Object>();
		returnMap.put("metalCode", commonCodeService.getFilterCodeRetVo("METAL_CODE", null, "CODE_DCTWO", "Y"));
		return returnMap;
	}
//
//	/**
//	 * <pre>
//	 * 처리내용: 철강신문 실시간 가격 페이지를 조회한다.
//	 * </pre>
//	 * 
//	 * @date 2023. 01. 19.
//	 * @author sumin
//	 * @history
//	 * -------------------------------------------------------------------------
//	 * 변경일 					작성자				변경내용
//	 * -------------------------------------------------------------------------
//	 * 2023. 01. 19.			sumin				최초작성
//	 * -------------------------------------------------------------------------
//	 * @param session
//	 * @param model
//	 * @return
//	 * @throws Exception
//	 */
//	@RequestMapping("/rltmPcInfo")
//	public String rltmPcInfo(HttpSession session, ModelMap model, HttpServletRequest request) throws Exception {
//		try {
//			Map<String, Object> resultMap = new HashMap<>();
//		//	PcMntrngSelVO pcMntrngSelVO = new PcMntrngSelVO();
//			
//			Map<String,Object> loginStatusMap = new HashMap<String,Object>();
//			Account account = userInfoUtil.getAccountInfo(request);
//
//			if ( account == null) {
//				loginStatusMap.put("loginYn","N");
//			}else {
//				loginStatusMap.put("loginYn","Y");
//			}
//
//			resultMap = extrlPcProvdService.getMainChartDate(null, null, "main", null);
//
//			model.addAttribute("chartList", resultMap);
//			
//			return "noTiles/rltmPcInfo";
//		} catch (Exception e) {
//			log.debug(ExceptionUtils.getStackTrace(e));
//			return "error/503";
//		}
//	}

}
