package com.sorincorp.fo.my.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.my.model.InqryDtlsVO;
import com.sorincorp.fo.my.service.InqryDtlsService;

import lombok.extern.slf4j.Slf4j;

/**
 * InqryDtlsController.java
 * @version
 * @since 2021. 7. 28.
 * @author srec0048
 */
@Slf4j
@Controller
@RequestMapping("/my/inqry")
public class InqryDtlsController {

	@Autowired
	private InqryDtlsService inqryDtlsService;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private CustomValidator customValidator;

    @Autowired
    private UserInfoUtil userInfoUtil;


    private Account getAccountInfo() throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
			throw new Exception("로그인 정보를 확인해주세요.");
		}
		return account;
	}

    /**
     * <pre>
     * 고객센터 문의내역
     * </pre>
     * @date 2022. 1. 11.
     * @author srec0051
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2022. 1. 11.			srec0051			최초작성
     * ------------------------------------------------
     * @param model
     * @return
     */
	@RequestMapping("/inqryDtls")
	public String InqryDtls(ModelMap model) {
		try {
			InqryDtlsVO inqryDtlsVO = new InqryDtlsVO();

			String mberType = StringUtil.nvl(userInfoUtil.getType());
			String dashboardUrl = null;

			// 문의 구분 대분류 코드
			model.addAttribute("inqrySeCode"	, inqryDtlsService.getCommCodeListStr(commonCodeService.getSubCodes("INQRY_SE_CODE"), ""));
			// 문의내역 총 건수
			model.addAttribute("inqryDtlsTotCnt", inqryDtlsService.selectInqryDtlsListTotCnt(inqryDtlsVO));
			// 문의내역 리스트
			model.addAttribute("inqryDtlsList"	, inqryDtlsService.selectInqryDtlsList(inqryDtlsVO));
			// 화면 구분 코드
			model.addAttribute("scrinSeCode"	, "inqry");

			if ("01".equals(mberType)) { // 기업회원
				dashboardUrl = "my/inqryDtls";

			} else if ("02".equals(mberType)) { // 간편회원
				dashboardUrl = "my/simplMberInqryDtls";
			}

			model.addAttribute("mberType", mberType);

			return dashboardUrl;

        } catch(Exception e) {
            log.error(e.getMessage());
            return "error/503";
    	}

	}

	/**
	 * <pre>
	 * 문의내역 더보기
	 * </pre>
	 * @date 2022. 1. 11.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 11.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param inqryDtlsVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectInqryDtlsList")
	@ResponseBody
	public Map<String, Object> selectInqryDtlsList(@RequestBody InqryDtlsVO inqryDtlsVO) throws Exception {
	    log.debug("==================> InqryDtlsController.selectInqryDtlsList ::: "+ inqryDtlsVO);
		Map<String, Object> map = new HashMap<String, Object>();

		inqryDtlsVO.setEntrpsNo(StringUtil.nvl(userInfoUtil.getEntripsNo()));	// 업체번호

		// 문의 내역 총건수
		int inqryDtlsTotCnt = inqryDtlsService.selectInqryDtlsListTotCnt(inqryDtlsVO);
		// 문의 내역 리스트
		List<InqryDtlsVO> inqryDtlsList = inqryDtlsService.selectInqryDtlsList(inqryDtlsVO);

		map.put("inqryDtlsTotCnt", inqryDtlsTotCnt);
		map.put("inqryDtlsList"	 , inqryDtlsList);

		return map;
	}

	/**
	 * <pre>
	 * 문의내역 상세
	 * </pre>
	 * @date 2022. 1. 11.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 11.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param inqryDtlsVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectInqryDtlsDetail")
	@ResponseBody
	public Map<String, Object> selectInqryDtlsDetail(@RequestBody InqryDtlsVO inqryDtlsVO) throws Exception {
	    log.debug("==================> InqryDtlsController.selectInqryDtlsDetail ::: "+ inqryDtlsVO);
		Map<String, Object> map = new HashMap<String, Object>();

		// 문의 내역 상세 조회
		InqryDtlsVO inqryDtls = inqryDtlsService.selectInqryDtlsDetail(inqryDtlsVO);
		// 첨부파일 리스트 조회
		List<FileDocVO> fileList = inqryDtlsService.selectAtchFileList(inqryDtlsVO.getInqrySn());

		map.put("inqryDtls", inqryDtls);	// 문의 상세 내역
		map.put("fileList" , fileList);		// 첨부파일 리스트

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 문의구분 중분류를 조회한다.
	 * </pre>
	 * @date 2021. 8. 5.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 5.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqrySeCode
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/selectInqrySeDetailCode")
	@ResponseBody
	public Map<String, Object> selectInqrySeDetailCode(String inqrySeCode, String scrinSeCode) throws Exception {
	    log.debug("==================> InqryDtlsController.selectInqrySeDetailCode ::: ");
		log.debug("==================> InqryDtlsController.selectInqrySeDetailCode inqrySeCode ::: "+ inqrySeCode);
		log.debug("==================> InqryDtlsController.selectInqrySeDetailCode scrinSeCode ::: "+ scrinSeCode);
		Map<String, Object> map = new HashMap<String, Object>();
		Map<String, String> param = new HashMap<String, String>();

		param.put("inqrySeCode", inqrySeCode);	// 문의 구문 대분류 코드
		param.put("scrinSeCode", scrinSeCode);	// 화면 구분 코드

		List<CommonCodeVO> inqrySeDetailCode = inqryDtlsService.selectInqrySeDetailCode(param);

		// 문의 구분 중분류 코드
		map.put("inqrySeDetailCode", inqrySeDetailCode);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 첨부파일 업로드한다.
	 * </pre>
	 * @date 2021. 8. 5.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 5.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param mRequest
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertInqryFileSave")
	@ResponseBody
	public ResponseEntity<?> insertInqryFileSave(MultipartHttpServletRequest mRequest) throws Exception {
		Map<String,Object> map = new HashMap<String,Object>();

		try {
			map = inqryDtlsService.saveAttachFile(mRequest);
		}catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<>(map,HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 첨부파일 삭제한다.
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param docNo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/deleteAttachFile", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<?> deleteAttachFile(@RequestBody FileDocVO vo) throws Exception {

		Map<String,Object> map = inqryDtlsService.deleteAttachFile(vo);

		return new ResponseEntity<>(map,HttpStatus.OK);

	}

	/**
	 * <pre>
	 * 처리내용: 문의내용을 저장한다.
	 * </pre>
	 * @date 2021. 8. 20.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 20.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqryDtlsVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertInqrySave")
	@ResponseBody
	public ResponseEntity<?> insertInqrySave(@RequestBody InqryDtlsVO inqryDtlsVO, BindingResult bindingResult) throws Exception {
		// 문의 내용 유효성 검사
		if(inqryDtlsVO.isValidation()) {
			customValidator.validate(inqryDtlsVO, bindingResult, InqryDtlsVO.InsertAndUpdate.class);
		}

		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		// 문의내용 등록
		inqryDtlsService.insertInqrySave(inqryDtlsVO);

		return new ResponseEntity<>(HttpStatus.OK);
	}


	/**
	 * <pre>
	 * 처리내용: 문의내역을 삭제한다.
	 * </pre>
	 * @date 2021. 8. 20.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 20.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqryDtlsVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/deleteInqryDetail")
	@ResponseBody
	public ResponseEntity<?> deleteInqryDetail(@RequestBody InqryDtlsVO inqryDtlsVO) throws Exception {
		log.debug("==================> InqryDtlsController.deleteInqryDetail ::: "+ inqryDtlsVO);

		inqryDtlsService.deleteInqryDetail(inqryDtlsVO);

		return new ResponseEntity<>(HttpStatus.OK);
	}


}
