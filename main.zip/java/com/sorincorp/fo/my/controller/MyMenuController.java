package com.sorincorp.fo.my.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.my.model.MyPageMenuVO;
import com.sorincorp.fo.my.service.MyMenuService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/fo/my")
public class MyMenuController {

	@Autowired
	private MyMenuService myMenuService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@ResponseBody
	@RequestMapping("/mySideMenu")
	public ResponseEntity<Object> selectMySideMenu(Model model) {
		List<MyPageMenuVO> myPageMenuList = myMenuService.selectMenuList();
		//List<MyPageMenuVO> myPageMenuList = myMenuService.selectMenuList(authorNo);
		String mberSttusCode = "";
		String mberType = "";
		String mberSeCode = "";

		if(userInfoUtil.getAccountInfo() != null) {
			mberSttusCode = userInfoUtil.getAccountInfo().getMberSttusCode();
			mberType = userInfoUtil.getType();
			mberSeCode = userInfoUtil.getMemberSecode();
		}

		Map<String, Object> map = new HashMap<String, Object>();

		map.put("myPageMenuList", myPageMenuList);
		map.put("mberSttusCode", mberSttusCode);
		map.put("mberType", mberType);
		map.put("mberSeCode",mberSeCode);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}
}
