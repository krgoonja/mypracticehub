package com.sorincorp.fo.my.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.mb.model.MbCmnCodeVO;
import com.sorincorp.fo.mb.service.MbCmnCodeService;
import com.sorincorp.fo.my.model.MileageMngVO;
import com.sorincorp.fo.my.service.MileageMngService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/my/mileage")
public class MileageMngController {

	@Autowired
	private MileageMngService mileageMngService;

	@Autowired
	private UserInfoUtil userInfoUtil;


	@RequestMapping("/selectMileageMngList")
	public String selectMileageMngList(Model model, MileageMngVO mileageMngVO) {

		if(userInfoUtil.getAccountInfo() == null) {
			return "error/503";
		}

		try {
			mileageMngVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());

			MileageMngVO mbMileageSeList = mileageMngService.selectMbMileageMngSeList(mileageMngVO);
			int totalDataCnt = mileageMngService.selectMbMileageMngListCnt(mileageMngVO);

			model.addAttribute("mbMileageSeList",mbMileageSeList);
			model.addAttribute("totalDataCnt",totalDataCnt);
			return "my/mileageMngList";

		} catch(Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	@RequestMapping("/selectMileageMngListAjax")
	@ResponseBody
	public ResponseEntity<Object> selectMileageMngListAjax(@RequestBody MileageMngVO mileageMngVO) throws Exception {

		Map<String, Object> retVal = new HashMap<String, Object>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put("result", "F");
			retVal.put("errMsg", "로그인되지 않은 사용자입니다.");
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		mileageMngVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());

		List<MileageMngVO> myMileageMngList = mileageMngService.selectMbMileageMngList(mileageMngVO);
		int totalDataCnt = mileageMngService.selectMbMileageMngListCnt(mileageMngVO);

		retVal.put("myMileageMngList", myMileageMngList);
		retVal.put("totalDataCnt", totalDataCnt);

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}



}
