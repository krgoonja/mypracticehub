package com.sorincorp.fo.my.controller;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.service.EntrpsEtrService;
import com.sorincorp.fo.my.model.CntrctMtAsgnInvntryDtlVO;
import com.sorincorp.fo.my.model.CntrctMtDtlVO;
import com.sorincorp.fo.my.model.CntrctOrderBasVO;
import com.sorincorp.fo.my.model.OrderAvrgVO;
import com.sorincorp.fo.my.service.DeliveryRegionMngService;
import com.sorincorp.fo.my.service.OrderAvrgService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Controller
@RequestMapping("/my/order")
public class OrderAvrgContorller {
	
	@Autowired
	private OrderAvrgService orderAvrgService;
	
	@Autowired
	private EntrpsEtrService entrpsEtrService;
	
	@Autowired
	private DeliveryRegionMngService deliveryRegionMngService;
	
	@Value("${oz.connection.reportname}")
	private String reportName;
	
	@Value("${oz.db.alias}")
	private String dbAlias;
	
	@RequestMapping("/avrg")
	public String getOrderAvrgList() {
		try {
			return "my/orderAvrgList";
		} catch (Exception e) {
			log.error(e.getMessage());
            return "error/503";
		}
	}
	
	@RequestMapping("/selectOrderArvgList")
	@ResponseBody
	public List<OrderAvrgVO> selectOrderArvgList(@RequestBody OrderAvrgVO orderAvrgVO) throws Exception {
		return orderAvrgService.selectOrderArvgList(orderAvrgVO);
	}
	
	@RequestMapping("/avrgDetail")
	public String getOrderAvrgDetail(@RequestBody OrderAvrgVO orderAvrgVO, ModelMap map) {
		try {
			if(StringUtils.isNotBlank(orderAvrgVO.getCntrctNo())) {	// 계약 완료 후 화면
				map.addAttribute("cntrctBaseInfo", orderAvrgService.selectCntrctBaseInfo(orderAvrgVO.getCntrctNo()));
				map.addAttribute("cntrctMtList", orderAvrgService.selectCntrctMtList(orderAvrgVO.getCntrctNo()));
				map.addAttribute("selectedCntrctYm", orderAvrgVO.getCntrctYm());
				map.addAttribute("mbDlvrgSeDtlList2", deliveryRegionMngService.selectMbDlvrgSeDtlListList("all"));
				map.addAttribute("domainList", deliveryRegionMngService.selectemailDomainList());
				
				return "my/orderAvrgDetailAfterContract";
			} else {												// 계약 완료 전 화면
				OrderAvrgVO avrgDetail = orderAvrgService.selectOrderArvgDetail(orderAvrgVO.getEstmtNo());
				map.addAttribute("avrgDetail", avrgDetail);
				
				// 평균가 서비스 약관 추가
				List<EntrpsEtrVO> selectOrderStplat = entrpsEtrService.selectEntrpsEtrStplat();
				if (selectOrderStplat == null || selectOrderStplat.size() == 0) {
					map.addAttribute("orderStplatInfo", new EntrpsEtrVO());
				} else {
					List<EntrpsEtrVO> filterSelectOrderStplat = selectOrderStplat.stream().filter(data -> (StringUtils.equals(data.getStplatSeCode(), "12"))).collect(Collectors.toList());
					if (filterSelectOrderStplat == null || filterSelectOrderStplat.size() == 0) {
						map.addAttribute("orderStplatInfo", new EntrpsEtrVO());
					} else {
						map.addAttribute("orderStplatInfo", filterSelectOrderStplat.get(0));
					}
				}
				
				String estmtSttusCode = avrgDetail.getEstmtSttusCode();
				
				if(StringUtils.equals(estmtSttusCode, "10") 
						|| StringUtils.equals(estmtSttusCode, "20") 
						|| (StringUtils.equals(estmtSttusCode, "90") && StringUtils.equals(avrgDetail.getPropseActvtyAt(), "N"))){
					map.addAttribute("estmtMtOrderWtDtlList", orderAvrgService.selectCnEstmtMtOrderWtDtlList(orderAvrgVO.getEstmtNo()));
				} else {
					map.addAttribute("estmtPropseMtDtlList", orderAvrgService.selectCnEstmtPropseMtDtlList(orderAvrgVO.getEstmtNo()));
				}
				
				map.addAttribute("REPORT_NAME", reportName);
				map.addAttribute("DB_ALIAS"	, dbAlias);
				
				return "my/orderAvrgDetailBeforeContract";
			}
		} catch (Exception e) {
			log.error(e.getMessage());
            return "error/503";
		}
	}
	
	@RequestMapping("/avrgDetailConfirm")
	@ResponseBody
	public ResponseEntity<?> updateOrderArvg(@RequestBody OrderAvrgVO orderAvrgVO) throws Exception {
		// 계약 승인 만료일 표기 제공
		String cntrctConfmEndDe = orderAvrgService.updateOrderAvrg(orderAvrgVO);
		
		return ResponseEntity.ok().body(cntrctConfmEndDe);
	}
	
	@RequestMapping("/getContractInfo")
	@ResponseBody
	public Map<String, Object> getContractInfo(@RequestBody CntrctMtDtlVO cntrctMtDtlVO) throws Exception {
		return orderAvrgService.getContractInfo(cntrctMtDtlVO);
	}
	
	@RequestMapping("/pricingDcsn")
	@ResponseBody
	public ResponseEntity<?> pricingDcsn(@RequestBody List<CntrctMtDtlVO> cntrctMtDtlVOList) throws Exception {
		orderAvrgService.updateCnCntrctMtDtl(cntrctMtDtlVOList);
		
		return ResponseEntity.ok().build();
	}
	
	@RequestMapping("/getNewAsgnInfo")
	@ResponseBody
	public Map<String, Object> getNewAsgnInfo(@RequestBody CntrctMtDtlVO cntrctMtDtlVO) throws Exception {
		return orderAvrgService.getNewAsgnInfo(cntrctMtDtlVO);
	}
	
	@RequestMapping("/getScreofeList")
	@ResponseBody
	public Map<String, Object> getScreofeList(@RequestBody CntrctMtAsgnInvntryDtlVO cntrctMtAsgnInvntryDtlVO) throws Exception {
		return orderAvrgService.getScreofeList(cntrctMtAsgnInvntryDtlVO);
	}
	
	@RequestMapping("/getNewAsgnInfoHst")
	@ResponseBody
	public List<CntrctMtDtlVO> getNewAsgnInfoHst(@RequestBody CntrctMtDtlVO cntrctMtDtlVO) throws Exception {
		return orderAvrgService.getNewAsgnInfoHst(cntrctMtDtlVO);
	}
	
	@RequestMapping("/getAvgOrderModalData")
	@ResponseBody
	public Map<String, Object> getAvgOrderModalData(@RequestBody CntrctOrderBasVO cntrctOrderBasVO) throws Exception {
		return orderAvrgService.getAvgOrderModalData(cntrctOrderBasVO);
	}
	
	@RequestMapping("/ordering")
	@ResponseBody
	public Map<String, Object> ordering(@RequestBody CntrctOrderBasVO cntrctOrderBasVO) throws Exception {
		return orderAvrgService.insertCntrctOrder(cntrctOrderBasVO);
	}
	
	@RequestMapping("/cancelOrdering")
	@ResponseBody
	public ResponseEntity<?> cancelOrdering(@RequestBody CntrctOrderBasVO cntrctOrderBasVO) throws Exception {
		orderAvrgService.cancelOrdering(cntrctOrderBasVO);
		
		return ResponseEntity.ok().build();
	}
	
	@RequestMapping("/getSetleTmlmtDe")
	@ResponseBody
	public String getSetleTmlmtDe(@RequestBody CntrctOrderBasVO cntrctOrderBasVO) throws Exception {
		return orderAvrgService.getSetleTmlmtDe(cntrctOrderBasVO);
	}
}
