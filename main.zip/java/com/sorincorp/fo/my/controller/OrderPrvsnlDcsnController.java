package com.sorincorp.fo.my.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.my.model.OrderPrvsnlDcsnProcessVO;
import com.sorincorp.fo.my.service.OrderPrvsnlDcsnService;
import com.sorincorp.fo.pd.comm.constant.PdCommConstant;
import com.sorincorp.fo.pd.comm.entity.PdResponseEntity;

import lombok.extern.slf4j.Slf4j;

/**
 * OrderPrvsnlDcsnController.java
 * 단가확정하기 관련 Controller 클래스
 * 
 * @version
 * @since 2024. 9. 5.
 * @author srec0049
 */
@Slf4j
@Controller
@RequestMapping("/my/prvsnlDcsn")
public class OrderPrvsnlDcsnController {

	/**
	 * 단가확정하기 관련 Service
	 */
	@Autowired
	private OrderPrvsnlDcsnService orderPrvsnlDcsnService;
	
	/**
	 * 사용자정의 유효성 검사
	 */
	@Autowired
	private CustomValidator customValidator;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	
	/**
	 * <pre>
	 * 처리내용: 단가확정하기 or 확정내역보기 모달창을 호출한다.
	 * </pre>
	 * @date 2024. 9. 9.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 9.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param params
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/callOrderPrvsnlDcsnModal")
	public String callOrderPrvsnlDcsnModal(@RequestBody OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO, ModelMap model) throws Exception {
		log.info("callOrderPrvsnlDcsnModal orderNo : " + orderPrvsnlDcsnProcessVO.getOrderNo());
		
		// 단가확정하기 정보 및 주문 번호에 대한 공통 가단가 확정 여부 정보 가져오기
		orderPrvsnlDcsnService.getOrderPrvsnlDcsnProcessInfo(orderPrvsnlDcsnProcessVO);
		log.info(">> orderPrvsnlDcsnProcessVO : " + String.valueOf(orderPrvsnlDcsnProcessVO));
		
		model.addAttribute("orderPrvsnlDcsnInfo", orderPrvsnlDcsnProcessVO.getOrderPrvsnlDcsnInfoVO()); // 단가확정하기 정보
		model.addAttribute("prvsnlDcsnAtInfo", orderPrvsnlDcsnProcessVO.getCommPrvsnlDcsnInfoVO()); // 가단가 확정 여부 정보
		model.addAttribute("mdat", "Y"); // LME 차트에서 LME 조정 항목 사용 여부 (mdat 단어 포함 항목)
		
		return "my/orderPrvsnlDcsnModalBase";
	}
	
	/**
	 * <pre>
	 * 처리내용: 구분 및 판매 방식, 상태 코드에 따른 확정 [라이브, 지정가] 등록 진행
	 * </pre>
	 * @date 2024. 9. 26.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 26.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param orderPrvsnlDcsnProcessVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/registPrvsnlDcsnProcess")
	public ResponseEntity<?> registPrvsnlDcsnProcess(HttpServletRequest request, @RequestBody @Valid OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO, BindingResult bindingResult) throws Exception {
		log.info(">> registPrvsnlDcsnProcess in : " + String.valueOf(orderPrvsnlDcsnProcessVO));
		
		customValidator.validate(orderPrvsnlDcsnProcessVO, bindingResult);

		if(bindingResult.hasErrors()) {
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(this.customGetBindingResultError(bindingResult.getAllErrors(), new Object(){}.getClass()));
		}
		
		Account account = userInfoUtil.getAccountInfo();
		orderPrvsnlDcsnProcessVO.setMberNo(account.getMberNo());
		orderPrvsnlDcsnProcessVO.setMberId(account.getId());
		
		
		// 구분 및 판매 방식, 상태 코드에 따른 확정 [라이브, 지정가] 등록 진행
		OrderPrvsnlDcsnProcessVO returnInfo = orderPrvsnlDcsnService.registPrvsnlDcsnProcess(orderPrvsnlDcsnProcessVO);
		
		
		return ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, returnInfo));
	}
	
	/**
	 * <pre>
	 * 처리내용: 구분 및 판매 방식, 상태 코드에 따른 지정가 수정 진행
	 * </pre>
	 * @date 2024. 9. 26.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 26.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param orderPrvsnlDcsnProcessVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/updatePrvsnlDcsnProcess")
	public ResponseEntity<?> updatePrvsnlDcsnProcess(HttpServletRequest request, @RequestBody @Valid OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO, BindingResult bindingResult) throws Exception {
		log.info("updatePrvsnlDcsnProcess orderNo : " + orderPrvsnlDcsnProcessVO.getOrderNo());
		
		customValidator.validate(orderPrvsnlDcsnProcessVO, bindingResult);

		if(bindingResult.hasErrors()) {
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(this.customGetBindingResultError(bindingResult.getAllErrors(), new Object(){}.getClass()));
		}
		
		Account account = userInfoUtil.getAccountInfo();
		orderPrvsnlDcsnProcessVO.setMberNo(account.getMberNo());
		orderPrvsnlDcsnProcessVO.setMberId(account.getId());
		
		// 구분 및 판매 방식, 상태 코드에 따른 지정가 수정 진행
		OrderPrvsnlDcsnProcessVO returnInfo = orderPrvsnlDcsnService.updatePrvsnlDcsnProcess(orderPrvsnlDcsnProcessVO);
		
		
		return ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, returnInfo));
	}
	
	/**
	 * <pre>
	 * 처리내용: 구분 및 판매 방식, 상태 코드에 따른 지정가 취소 진행
	 * </pre>
	 * @date 2024. 9. 26.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 26.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param orderPrvsnlDcsnProcessVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/cancelPrvsnlDcsnProcess")
	public ResponseEntity<?> cancelPrvsnlDcsnProcess(HttpServletRequest request, @RequestBody @Valid OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO, BindingResult bindingResult) throws Exception {
		log.info("cancelPrvsnlDcsnProcess orderNo : " + orderPrvsnlDcsnProcessVO.getOrderNo());
		
		customValidator.validate(orderPrvsnlDcsnProcessVO, bindingResult);

		if(bindingResult.hasErrors()) {
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(this.customGetBindingResultError(bindingResult.getAllErrors(), new Object(){}.getClass()));
		}
		
		Account account = userInfoUtil.getAccountInfo();
		orderPrvsnlDcsnProcessVO.setMberNo(account.getMberNo());
		orderPrvsnlDcsnProcessVO.setMberId(account.getId());
		
		orderPrvsnlDcsnProcessVO.setLimitOrderSttusCode("40"); // 지정가 주문 상태 코드 [40 : 지정가 주문취소(본인)]
		
		// 구분 및 판매 방식, 상태 코드에 따른 지정가 취소 진행
		OrderPrvsnlDcsnProcessVO returnInfo = orderPrvsnlDcsnService.deletePrvsnlDcsnProcess(orderPrvsnlDcsnProcessVO);
		
		
		return ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, returnInfo));
	}
	
	
	
	
	
	
	
	
	/**
	 * <pre>
	 * 처리내용: 매개변수 바인딩 검증 후 에러 발생 시 에러 객체 반환 전에 로그 추가
	 * </pre>
	 * @date 2024. 9. 26.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 26.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param getAllErrors
	 * @param ObjectClass
	 * @return
	 */
	public String customGetBindingResultError(List<ObjectError> getAllErrors, Class<?> ObjectClass) {
		ObjectError customAllError = new ObjectError("undefinedError", "undefined Error");

		StringBuffer sb = new StringBuffer();

		if(ObjectClass != null && ObjectClass.getEnclosingClass() != null) {
			String getSimpleName = ObjectClass.getEnclosingClass().getSimpleName() != null ? ObjectClass.getEnclosingClass().getSimpleName() : "";

			sb.append("[").append(getSimpleName).append("]");
		}

		if(ObjectClass != null && ObjectClass.getEnclosingMethod() != null) {
			String getName = ObjectClass.getEnclosingMethod().getName() != null ? ObjectClass.getEnclosingMethod().getName() : "";

			sb.append("[").append(getName).append("]");
		}

		if(getAllErrors != null && getAllErrors.size() > 0) {
			customAllError = getAllErrors.get(0);
			String getObjectName = customAllError.getObjectName() != null ? customAllError.getObjectName() : "";
			String getCode = customAllError.getCode() != null ? customAllError.getCode() : "";
			String getDefaultMessage = customAllError.getDefaultMessage() != null ? customAllError.getDefaultMessage() : "";

			sb.append("[").append(getObjectName).append("]");
			sb.append("[").append(getCode).append("]").append(" ");
			sb.append(getDefaultMessage);
		}

		log.error(sb.toString());

		return customAllError.getDefaultMessage();
	}
}
