package com.sorincorp.fo.my.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.deliveryCarMng.model.DeliveryCarMngCommVO;
import com.sorincorp.comm.deliveryCarMng.service.DeliveryCarMngCommService;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.order.model.OrOrderAvrgpcDtlVO;
import com.sorincorp.comm.order.model.OrderDtlsClaimVO;
import com.sorincorp.comm.order.service.CommAvrgpcOrderService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.my.model.CntrctOrderBasVO;
import com.sorincorp.fo.my.model.DlivyVO;
import com.sorincorp.fo.my.model.DlvyVO;
import com.sorincorp.fo.my.model.OrSetleInfoVO;
import com.sorincorp.fo.my.model.OrderDtlsVO;
import com.sorincorp.fo.my.model.VhcleInfoVO;
import com.sorincorp.fo.my.service.ClaimService;
import com.sorincorp.fo.my.service.CntrctOrderService;
import com.sorincorp.fo.my.service.DashboardService;
import com.sorincorp.fo.my.service.InqryDtlsService;
import com.sorincorp.fo.my.service.OrderDtlsDetailService;
import com.sorincorp.fo.pd.service.ItemPriceService;

import lombok.extern.slf4j.Slf4j;

/**
 * DlvyController.java
 * @version
 * @since 2021. 7. 16.
 * @author srec0048
 */
@Slf4j
@Controller
@RequestMapping("/my/orderDetail")
public class OrderDtlsDetailController {

    @Autowired
    private ClaimService claimService;

    @Autowired
    private OrderDtlsDetailService orderDtlsDetailService;

    @Autowired
    private InqryDtlsService inqryDtlsService;

    @Autowired
    private CommonCodeService commonCodeService;

    @Autowired
    private DashboardService dashboardService;

    @Autowired
    private UserInfoUtil userInfoUtil;

    @Autowired
    private FileDocService fileDocService;
    @Autowired
    private BsnInfoService bsnInfoService;
    @Autowired
    private ItemPriceService itemPriceService;
    @Autowired
    private DeliveryCarMngCommService deliveryCarMngCommService;
    @Autowired
    private CntrctOrderService cntrctOrderService;
    @Autowired
    private CommAvrgpcOrderService commAvrgpcOrderService;


    /**
     * <pre>
     * 처리내용: 세션 계정 정보 조회
     * </pre>
     * @date 2021. 11. 18.
     * @author srec0051
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 11. 18.            srec0051            최초작성
     * ------------------------------------------------
     * @return
     * @throws Exception
     */
    private Account getAccountInfo() throws Exception {
        Account account = userInfoUtil.getAccountInfo();
        if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
            throw new Exception("로그인 정보를 확인해주세요.");
        }
        return account;
    }

    /**
     * <pre>
     * 처리내용: 마이페이지 > 주문내역 상세보기를 조회한다.
     * </pre>
     * @date 2021. 7. 12.
     * @author srec0048
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 7. 21.         srec0048            최초작성
     * 2023. 7				srec0051		고도화 자차배송
     * ------------------------------------------------
     * @param searchVo
     * @param model
     * @return
     * @throws Exception
     */
    @RequestMapping(value="/selectOrderDtlsDetail", method={RequestMethod.GET, RequestMethod.POST})
    public String selectOrderDtlsDetail(@RequestBody OrderDtlsVO searchVo, ModelMap model) {
        log.debug("==================== selectorderDtlsDetail ======================" + searchVo);

        try {
            String entrpsNo = userInfoUtil.getEntripsNo();
            // 주문번호와 클레임번호 합쳐진 형태로 파라미터 받음 (ex : 20210906-000001,00000000-000000)
            String[] arrNo = searchVo.getOrderNo().split(",");
            String orderNo = arrNo[0];
            String canclExchngRtngudNo = arrNo[1];
            int vhcleCnt = searchVo.getVhcleCnt();

            searchVo.setOrderNo(orderNo);
            searchVo.setCanclExchngRtngudNo(canclExchngRtngudNo);
            searchVo.setEntrpsNo(entrpsNo);

            // 주문 정보
            OrderDtlsVO orderDtlsInfo = Optional.ofNullable(orderDtlsDetailService.selectOrderDtlsDetail(searchVo))
                    .orElseThrow(()->{
                        return new Exception("주문 정보를 확인할 수 없습니다.");
                    });

            orderDtlsInfo.setWtChange(orderDtlsInfo.getWtChange().stripTrailingZeros());

            // 결제 정보를 조회
            OrSetleInfoVO orderSetleInfo = orderDtlsDetailService.selectOrSetleInfo(orderNo);
            // 매매계약서 내부 거래명세서, 세금계산서 ozReport 실행시 필요한 파라미터 조회
            Map<String, Object> taxBillInfo = orderDtlsDetailService.selectTaxBillInfo(orderNo);
            // 출고 정보
            List<DlivyVO> dlivyInfoList = orderDtlsDetailService.selectDlivyList(orderNo);
            // 배송지 정보
            DlvyVO dlvrgInfo = orderDtlsDetailService.selectDlvrg(orderNo);
            // 물류휴일정보
            List<String> holidayList = orderDtlsDetailService.selectHolidayList(orderNo);
            // 케이지트레이딩 고객센터 전화번호
            Map<String, CommonCodeVO> csTelNo = commonCodeService.getSubCodesRetVo("SORIN_SETUP_CODE", "CS_TEL");

            model.addAttribute("orderDtlsInfo"  , orderDtlsInfo);       // 주문 정보
            model.addAttribute("orderSetleInfo" , orderSetleInfo);      // 결제 정보(결제상세 내역포함)
            //model.addAttribute("rcpmnyCnfrmnInfo", rcpmnyCnfrmnInfo);     // 입금확인서 정보

            // 은행코드 (업체에 포함된 은행코드)
            model.addAttribute("listBankCode", dashboardService.selectListEntrpsBank(Collections.singletonMap("entrpsNo", entrpsNo)));

            model.addAttribute("taxBillInfo"    , taxBillInfo);         // 거래명세서, 세금계산서 ozReport 정보
            model.addAttribute("dlivyInfoList"  , dlivyInfoList);       // 출고정보
            model.addAttribute("dlvrgInfo"      , dlvrgInfo);           // 배송지 정보
            // 문의 구분 대분류 코드
            model.addAttribute("inqrySeCode"    , inqryDtlsService.getCommCodeListStr(commonCodeService.getFilterCode("INQRY_SE_CODE", null, "CODE_CHRCTR_REFRNONE", "OR"), ""));
            model.addAttribute("scrinSeCode"    , "order");                                             // 화면 구분 코드
            model.addAttribute("holidayList"    , holidayList);											// 물류휴일정보
            model.addAttribute("vhcleFocus", vhcleCnt);                                                 // 0보다 크면 출고정보 영역으로 이동
            model.addAttribute("csTelNo", csTelNo.get("CS_TEL").getCodeDcone());                        // 케이지트레이딩 고객센터 전화번호


            //신용보증 주문의 상환버튼 노출 여부를 조회한다.
            model.addAttribute("repyAt", orderDtlsDetailService.getRepyPossibleAt(orderNo));
            //금속코드에 대한 영업관리 (시간)
            model.addAttribute("deliveryRequestDateList", new ObjectMapper().writeValueAsString(itemPriceService.selectDeliveryRequestDate(orderDtlsInfo.getMetalCode())));


            // 자차배송
            if (StringUtils.equals(orderDtlsInfo.getDlvyMnCode(), "02")) {
	            // 차량종류 공통코드
            	// 202308 알루미늄, 아연 25톤 / 니켈, 주석 분리
	            List<CommonCodeVO> vhcleGroupCodeList = orderDtlsDetailService.selectVhcleGroupCodeList(orderDtlsInfo.getSleMthdCode(), orderDtlsInfo.getMetalCode());
	            // 업체 차량 정보 (최근 10개)
	            List<DeliveryCarMngCommVO> carList = this.getMbVhcleListTen();
	            // 업체 기사 정보 (최근 10개)
	            List<DeliveryCarMngCommVO> driverList = this.getMbDrvArticlListTen();
	            // 해당 주문건에 등록된 차량의 배송차수 조회 (쿠폰에서 사용됨)
	            Map<String, Boolean> dlvyOdrInfo = orderDtlsDetailService.selectDlvyOdrList(orderNo);

	            model.addAttribute("vhcleGroupCodeList", new ObjectMapper().writeValueAsString(vhcleGroupCodeList));
	            model.addAttribute("carList" , new ObjectMapper().writeValueAsString(carList));
	            model.addAttribute("driverList" , new ObjectMapper().writeValueAsString(driverList));
	            model.addAttribute("dlvyOdrInfo"    , dlvyOdrInfo);
            }


            // 평균가 정보
            if (orderDtlsInfo.getSleMthdCode().equals("04")
            		|| (!StringUtils.equals(orderDtlsInfo.getSleMthdCode(), "04") && StringUtil.isNotBlank(orderDtlsInfo.getSleMthdDetailCode()))
            		) {

            	CntrctOrderBasVO cntrctOrderInfo = new CntrctOrderBasVO();
            	cntrctOrderInfo.setOrderNo(orderNo);
            	cntrctOrderInfo = Optional.ofNullable(cntrctOrderService.selectCntrctOrderInfo(cntrctOrderInfo))
            			.orElseThrow(()->{
            				log.error("평균가 발주 정보를 확인할 수 없습니다.");
                            return new Exception("평균가 발주 정보를 확인할 수 없습니다.");
                        });

            	// 1. 주문결제 정보 영역 타임라인 단계 하이라이트 설정 (active)
            	// 2. 주문결제 정보 영역 타임라인 출고, 평균가확정 동적 타입 설정
            	String timelineType = "dlivyFirst"; 									// 기본 step 은 출고일이 우선인 것으로 설정 한다
            	int timelineActive = 1; 												// 기본 active 는 주문일로 설정 한다
            	int dlivyRequstDe = 0;													// 배송완료일 //1순위 배송완료일, 2순위 입고일(MAX-자차만), 3순위 배송요청일 순으로 값을 가져와서 비교
            	int untpcDcsnDe = 0;													// 단가확정일자

            	// 2023.12.19 주문상태코드에 따라 출고, 확정가 우선순위 설정
            	int orderSttusCode = Integer.parseInt(orderDtlsInfo.getOrderSttusCode());
            	// 2023.12.19 가/확정 단가 여부
            	boolean isAvrgFakePrice = true;

            	if (null != orderDtlsInfo.getGoodsUntpc() && orderDtlsInfo.getGoodsUntpc().intValue() > 0) {
            		isAvrgFakePrice = false;
            	}

            	if (StringUtil.isNotBlank(orderDtlsInfo.getDlvyComptDe())) {
            		dlivyRequstDe = Integer.parseInt(orderDtlsInfo.getDlvyComptDe());
            	}

            	if (StringUtil.isNotBlank(cntrctOrderInfo.getUntpcDcsnDe())) {
            		untpcDcsnDe = Integer.parseInt(cntrctOrderInfo.getUntpcDcsnDe());
            	}

            	// 기본 step type 설정
            	if (untpcDcsnDe <= dlivyRequstDe) {
            		timelineType = "untpcFirst";
            	}

            	// 출고일이 우선 step 경우 active 영역 설정
            	if (timelineType.equals("dlivyFirst")) {
            		// 배송완료 이상 이면 2 step
            		if (orderSttusCode >= 30) {
            			timelineActive = 2;
            		}

            		// 확정단가 라면 3 step
            		if (!isAvrgFakePrice) {
            			timelineActive = 3;
            		}
            	}

            	// 단가확정 우선 step 경우 active 영역 설정
            	if (timelineType.equals("untpcFirst")) {
            		// 확정단가 라면 2 step
            		if (!isAvrgFakePrice) {
            			timelineActive = 2;
            		}

            		// 배송완료 이상 이면 3 step
            		if (orderSttusCode >= 30) {
            			timelineActive = 3;
            		}
            	}

            	// 누적 평균가 가격 목록 조회
            	// 가단가 = 5영업일, 확정단가 = 적용 월 조회
            	List<OrOrderAvrgpcDtlVO> avrgpcDtlVoList = null;
            	if (isAvrgFakePrice) {
            		// 가단가
            		avrgpcDtlVoList = commAvrgpcOrderService.selectAccmltAvrgpcListTopCnt(cntrctOrderInfo.getCntrctOrderNo(), 5);
            	} else {
            		// 확정단가
            		avrgpcDtlVoList = commAvrgpcOrderService.selectAccmltAvrgpcList(cntrctOrderInfo.getCntrctOrderNo());
            	}

            	// 누적 평균가 LmeCsp 평균
            	double avgLmeCsp = commAvrgpcOrderService.getAveragingLmeCsp(avrgpcDtlVoList);

            	// 누적 평균가 달러환산률 평균
            	double avgUsdCvtrate = commAvrgpcOrderService.getAveragingUsdCvtrate(avrgpcDtlVoList);

            	/**
            	 * 환불 내역 조회 seCode 값 정의
            	 * 이월렛, 증거금 	= 01:중량, 02:단가
            	 * 여신, 담보 		= 01:중량, 03:단가
            	 */
//            	List<OrSetleDtlsInfoVO> avrgRefundSetleList = orderDtlsDetailService.getAvrgRefundSetleList(setleInfo);
//            	if (!avrgRefundSetleList.isEmpty()) {
//            		model.addAttribute("avrgRefundSize", avrgRefundSetleList.size());
//            		OrSetleDtlsInfoVO avrgWtRefundSetleInfo;	// 중량 환불 내역
//            		OrSetleDtlsInfoVO avrgPcRefundSetleInfo;	// 단가 환불 내역
//
//            		for (OrSetleDtlsInfoVO vo : avrgRefundSetleList) {
//            			if (vo.getSeCode().equals("01")) {
//            				avrgWtRefundSetleInfo = vo;
//            				model.addAttribute("avrgWtRefundSetleInfo", avrgWtRefundSetleInfo);
//            			} else {
//            				avrgPcRefundSetleInfo = vo;
//            				model.addAttribute("avrgPcRefundSetleInfo", avrgPcRefundSetleInfo);
//            			}
//            		}
//            	}

            	model.addAttribute("cntrctOrderInfo"  	, cntrctOrderInfo);
            	model.addAttribute("timelineType"		, timelineType);
            	model.addAttribute("timelineActive"  	, timelineActive);
            	model.addAttribute("avrgpcDtlVoList"  	, avrgpcDtlVoList);
            	model.addAttribute("avgLmeCsp"			, avgLmeCsp);
            	model.addAttribute("avgUsdCvtrate"		, avgUsdCvtrate);
            	model.addAttribute("isAvrgFakePrice"	, isAvrgFakePrice);
            }

            return "my/orderDtlsDetail";

        } catch(Exception e) {
            log.error(e.getMessage(), e);
            return "error/503";
        }
    }


    /**
     * <pre>
     * 처리내용: 차량정보를 조회한다.
     * </pre>
     * @date 2021. 7. 21.
     * @author srec0048
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 7. 21.         srec0048            최초작성
     * 2022. 12.            srec0051        고정가 관련 수정
     * 2023. 07				srec0051		고도화 자차배송
     * 2024. 05				srec0053		소량구매 고도화
     * ------------------------------------------------
     * @param vhcleInfoVO
     * @return
     * @throws Exception
     */
    @PostMapping("/selectDeliveryCarMngInfo")
    @ResponseBody
    public Map<String, Object> selectDeliveryCarMngInfo(@RequestBody VhcleInfoVO vhcleInfoVO) throws Exception {
        Map<String, Object> map = new HashMap<>();
        
        // 주문 정보 조회에 사용될 객체 생성 및 데이터 세팅
        OrderDtlsVO searchVo = new OrderDtlsVO();
        searchVo.setOrderNo(vhcleInfoVO.getOrderNo());
        searchVo.setEntrpsNo(userInfoUtil.getEntripsNo());
        
		// 주문 정보 조회
        OrderDtlsVO orderInfo = Optional.ofNullable(orderDtlsDetailService.selectOrderDtlsDetail(searchVo))
                .orElseThrow(()->{
                    return new Exception("주문 정보를 확인할 수 없습니다.");
                });

        orderInfo.setWtChange(orderInfo.getWtChange().stripTrailingZeros());
        
        // 주문 정보
        map.put("orderInfo", orderInfo);
        
        // 물류휴일정보
        map.put("holidayList", orderDtlsDetailService.selectHolidayList(vhcleInfoVO.getOrderNo()));
        
        //금속코드에 대한 영업관리 (시간)
        map.put("deliveryRequestDateList", itemPriceService.selectDeliveryRequestDate(orderInfo.getMetalCode()));
        
        // 차량종류 공통코드
        map.put("vhcleGroupCodeList", orderDtlsDetailService.selectVhcleGroupCodeList(null, null));
        // 업체 차량 정보 (최근 10개)
        map.put("carList", this.getMbVhcleListTen());
        // 업체 기사 정보 (최근 10개)
        map.put("driverList", this.getMbDrvArticlListTen());
        
        // 출고 정보
        List<DlivyVO> dlivyInfoList = orderDtlsDetailService.selectDlivyList(vhcleInfoVO.getOrderNo());
        Map<String, DlivyVO> dlivyInfoGroupList = dlivyInfoList.stream()
        		.collect(Collectors.toMap(DlivyVO::getOrderSn, Function.identity(), (o1,o2) -> o1, LinkedHashMap::new));
        
        map.put("dlivyInfoList", dlivyInfoGroupList);

        // 모든 등록 차량 조회 (차수파악을 위함 - 고정가용)
        List<VhcleInfoVO> vhcleInfoList = orderDtlsDetailService.selectVhcleInfoList(vhcleInfoVO);

        map.put("vhcleInfoList" , vhcleInfoList);

        return map;
    }

    /**
     * <pre>
     * 업체 등록 차량 조회
     * </pre>
     * @date 2023. 7. 21.
     * @author srec0051
     * @return
     * @throws Exception
     */
    @PostMapping("/reloadMbVhcleList")
    @ResponseBody
    public Map<String, Object> reloadMbVhcleList() throws Exception {
    	Map<String, Object> map = new HashMap<>();
        map.put("carList" , this.getMbVhcleListTen());

    	return map;
    }

    /** 업체 차량 정보 (최근 10개) */
    private List<DeliveryCarMngCommVO> getMbVhcleListTen() throws Exception {
    	String entrpsNo = userInfoUtil.getEntripsNo();
    	int maxCnt = 9;
        List<DeliveryCarMngCommVO> carList = new ArrayList<>();

        for (DeliveryCarMngCommVO vo : deliveryCarMngCommService.selectMbVhcleInfoBas(entrpsNo)) {
        	carList.add(vo);
        	if (maxCnt == 0) break;
        	maxCnt--;
        }

    	return carList;
    }

    /**
     * <pre>
     * 업체 등록 기사정보 조회
     * </pre>
     * @date 2023. 7. 21.
     * @author srec0051
     * @return
     * @throws Exception
     */
    @PostMapping("/reloadMbDrvArticlList")
    @ResponseBody
    public Map<String, Object> reloadMbDrvArticlList() throws Exception {
    	Map<String, Object> map = new HashMap<>();
        map.put("driverList" , this.getMbDrvArticlListTen());

    	return map;
    }

    /** 업체 기사 정보 (최근 10개) */
    private List<DeliveryCarMngCommVO> getMbDrvArticlListTen() throws Exception {
    	String entrpsNo = userInfoUtil.getEntripsNo();
    	int maxCnt = 9;
    	List<DeliveryCarMngCommVO> driverList = new ArrayList<>();

        for (DeliveryCarMngCommVO vo : deliveryCarMngCommService.selectMbDrvArticlInfoBas(entrpsNo)) {
        	driverList.add(vo);
        	if (maxCnt == 0) break;
        	maxCnt--;
        }

        return driverList;
    }

    /**
     * <pre>
     * 처리내용: 배송정보를 수정한다.
     * </pre>
     * @date 2021. 7. 20.
     * @author srec0048
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 7. 20.         srec0048            최초작성
     * ------------------------------------------------
     * @param dlvyVO
     * @return
     * @throws Exception
     */
    @PostMapping("/insertNewDlvrgInfo")
    @ResponseBody
    public Map<String, Object> insertNewDlvrgInfo(@RequestBody DlvyVO dlvyVO) throws Exception {
        Map<String, Object> map = new HashMap<>();

        // 세션정보
        Account account = getAccountInfo();

        dlvyVO.setMberId(account.getId()); // 회원id
        dlvyVO.setEntrpsNo(account.getEntrpsNo());

        // 배송지 수정
        Map<String, Object> result = orderDtlsDetailService.insertNewDlvrgInfo(dlvyVO);
        // 배송지 정보
        DlvyVO dlvrgInfo = orderDtlsDetailService.selectDlvrg(dlvyVO.getOrderNo());

        map.put("result"   , result);     // 배송지 수정 결과 데이터
        map.put("dlvrgInfo", dlvrgInfo);  // 배송지 정보

        return map;
    }

    /**
     * <pre>
     * 처리내용: 차량정보를 등록 및 수정한다.
     * </pre>
     * @date 2021. 7. 22.
     * @author srec0048
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 7. 22.         srec0048            최초작성
     * 2023. 11. 21.        hyunjin05           16시로 변경
     * ------------------------------------------------
     * @param vhcleInfoVO
     * @throws Exception
     */
    @PostMapping("/insertVhcleInfoList")
    @ResponseBody
    public Map<String, Object> insertVhcleInfoList(@RequestBody List<VhcleInfoVO> vhcleInfoArr) throws Exception {
        // 세션정보
        Account account = getAccountInfo();
        Map<String, Object> rtnMap = new HashMap<>();
        rtnMap.put("result", "E");
        rtnMap.put("resultMsg", "차량입고일을 확인해주세요.");


        /**
         * 20230802
         * 입고일 익일 입력 당일 오후 15시 까지
         * 월요일 입력 금요일 오후 15시 까지 (오늘이 금요일이라면 차주 월요일만 해당)
         * 20231121
         * -- 16시 까지
         */

        String today = DateUtil.getNowDateTime("yyyy-MM-dd");// 당일
        String tohh = DateUtil.getNowDateTime("HH");// 당일 시간
        for (VhcleInfoVO vo : vhcleInfoArr) {
            vo.setMberId(account.getId());

            //StringUtils.equals("02", vo.getSleMthdCode())
            //StringUtils.equals("saved", vo.getMode())
            // 삭제일 때는 체크 안함
            if (StringUtils.equals("Y", vo.getDeleteAt())) {
                continue;
            }

            if (StringUtil.isEmpty(vo.getVhcleWrhousngDe())) {
            	return rtnMap;
            }
        }

        for (VhcleInfoVO vo : vhcleInfoArr) {
        	vo.setMberId(account.getId());
        }

        // 차량정보를 등록 및 수정
        try {
        	rtnMap = orderDtlsDetailService.modifyVhcleInfoList(vhcleInfoArr);
        } catch (Exception e) {
        	log.error(e.getMessage(), e);
        	return rtnMap;
		}

        return rtnMap;
    }

    /**
     * <pre>
     * 처리내용: 성적서&패킹리스트를 조회한다.
     * </pre>
     * @date 2021. 9. 13.
     * @author srec0048
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 9. 13.         srec0048            최초작성
     * ------------------------------------------------
     * @param orderNo
     * @return
     * @throws Exception
     */
    @PostMapping("/selectScreofePackngList")
    @ResponseBody
    public Map<String, Object> selectScreofePackngList(@RequestBody String orderNo) throws Exception {
        Map<String, Object> map = new HashMap<>();

        // 성적서&패킹리스트 조회
        List<Map<String, Object>> screofePackngList = orderDtlsDetailService.selectScreofePackngList(orderNo);

        map.put("screofePackngList", screofePackngList);

        return map;
    }

    @PostMapping("/reqClaim")
    @ResponseBody
    public ResponseEntity<?> reqClaim(@RequestBody OrderDtlsClaimVO claimVo) throws Exception {

        // 세션정보
        Account account = getAccountInfo();
        claimVo.setMberId(account.getId());
        claimVo.setMberNo(account.getMberNo());
        claimVo.setEntrpsNo(account.getEntrpsNo());

        Map<String, Object> map = new HashMap<>();

        // 휴무, 휴일 유무 체크
        boolean restdeYn = false;

        //2023.08.30 함수 호출부분 없어 임시 하드코딩 처리
        restdeYn = bsnInfoService.isRestDeByMetal("7", claimVo.getSleMthdCode());

        if (!restdeYn) {
            map.put("responseCode", -1);
            map.put("msg", "영업시간을 확인해주세요.");
            return new ResponseEntity<>(map, HttpStatus.OK);
        }

        int ret = claimService.requestClaim(claimVo);
        map.put("responseCode", ret);
        if (ret == 99) {
            map.put("msg", "취소 가능한 시간이 지났습니다. (관리자에게 문의하세요)");
        }
        if (ret == -1) {
            map.put("msg", "신청 실패 (관리자에게 문의하세요)");
        }
        if (ret == 0) {
            map.put("msg", "신청이 완료되었습니다.");
        }

        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    /**
     * <pre>
     * 처리내용: 케이지트레이딩 직인을 조회한다.
     * </pre>
     * @date 2021. 10. 19.
     * @author srec0048
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 10. 19.            srec0048            최초작성
     * ------------------------------------------------
     * @param request
     * @param response
     * @throws Exception
     */
    @GetMapping(value="/sorinSign")
    public void selectSorinSign(HttpServletRequest request, HttpServletResponse response) throws Exception {
        log.debug("==================== selectSorinSign ======================"+ request);
        orderDtlsDetailService.selectSorinSign(response);
    }

    @RequestMapping("/insertFile")
    @ResponseBody
    public ResponseEntity<?> insertFile(MultipartHttpServletRequest mrequest) throws Exception {
        // 세션정보
        getAccountInfo();
        Map<String,Object> map = new HashMap<>();

        try {
            // Upload할 파일의 MultipartServletRequest을 파라미터로 보내면
            // 공통 문서 기본 테이블에 문서 정보를 insert
            // Table에 등록된 문서 FileDocVO 리스트를 return
            List<FileDocVO> list = fileDocService.uploadAttachFilesVoList("OR", mrequest);// 파일 저장
            map.put("list", list);

        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    /**
     * <pre>
     * 첨부 파일 삭제
     * </pre>
     * @date 2022. 1. 11.
     * @author srec0051
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 1. 11.         srec0051            최초작성
     * ------------------------------------------------
     * @param vo
     * @return
     * @throws Exception
     */
    @RequestMapping("/deleteFile")
    @ResponseBody
    public ResponseEntity<?> deleteFile(@RequestBody FileDocVO vo) throws Exception {
        // 세션정보
        Account account = getAccountInfo();
        vo.setLastChangerId(account.getId());

        Map<String,Object> map = new HashMap<>();
        //공통_문서 기본 - 문서 사용 여부 'N'으로 수정
        fileDocService.deleteCommonDoc(vo.getDocNo());
        map.put("docNo", vo.getDocNo());
        map.put("result","success");

        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    /**
     * <pre>
     * 클레임 첨부파일 조회
     * </pre>
     * @date 2022. 1. 11.
     * @author srec0051
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 1. 11.         srec0051            최초작성
     * ------------------------------------------------
     * @param vo
     * @return
     * @throws Exception
     */
    @RequestMapping("/getListClaimFile")
    @ResponseBody
    public ResponseEntity<?> getListClaimFile(@RequestBody OrderDtlsClaimVO vo) throws Exception {
        Map<String,Object> map = new HashMap<>();
        map.put("file", claimService.selectListFileDocInfo(vo));

        return new ResponseEntity<>(map,HttpStatus.OK);
    }

    /**
     * <pre>
     * 이벤트 휴일에 포함되는지 조회
     * </pre>
     * @date 2022. 2. 8.
     * @author srec0051
     * @history
     * @param vhcleInfoVO
     * @return
     * @throws Exception
     */
    @PostMapping("/holidayCheck")
    @ResponseBody
    public Map<String, Object> holidayCheck(@RequestBody VhcleInfoVO vhcleInfoVO) throws Exception {
        int i = orderDtlsDetailService.checkHolidayYn(vhcleInfoVO);
        return Collections.singletonMap("yn", i);
    }

    /**
     * <pre>
     * 처리내용: 입금확인서 데이터 조회
     * </pre>
     * @date 2022. 10. 4.
     * @author srec0066
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 10. 4.         srec0066            최초작성
     * ------------------------------------------------
     * @param orderNo
     * @return
     * @throws Exception
     */
    @PostMapping("/selectRcpmnyCnfrmnInfo")
    @ResponseBody
    public OrSetleInfoVO selectRcpmnyCnfrmnInfo(@RequestBody OrderDtlsVO dtlsVo) throws Exception  {
        return orderDtlsDetailService.selectRcpmnyCnfrmnInfo(dtlsVo.getOrderNo());
    }

    /**
     * <pre>
     * 처리내용: 기준일자, 일수를 받아 계산된 영업일과 날짜변경가능여부를 리턴
     * </pre>
     * @date 2022. 10. 19.
     * @author srec0066
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 10. 19.            srec0066            최초작성
     * ------------------------------------------------
     * @param dlvyVO
     * @return {yn : boolean, returnDe : yyyyMMMdd}
     * @throws Exception
     */
    @PostMapping("/getSettleSttusDe")
    @ResponseBody
    public Map<String,Object> getSettleSttusDe(@RequestBody DlvyVO dlvyVO) throws Exception  {
        return orderDtlsDetailService.getSettleSttusDe(dlvyVO);
    }

    /**
     * <pre>
     * 처리내용: 쿠폰 차감내역 조회.
     * </pre>
     * @date 2023. 5. 12.
     * @author hamyoonsic
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 5. 12.         hamyoonsic            최초작성
     * ------------------------------------------------
     * @param orderNo
     * @return
     * @throws Exception
     */
    @PostMapping("/selectCouponDdctList")
    @ResponseBody
    public Map<String, Object> selectCouponDdctList(@RequestBody OrderDtlsVO dtlsVo) throws Exception  {
        return orderDtlsDetailService.selectCouponDdctList(dtlsVo.getOrderNo());
    }
    
    /**
     * <pre>
     * 처리내용: 주문 상세 화면 > 결제 정보 영역 refresh를 위한 화면 부분 호출
     * </pre>
     * @date 2024. 11. 20.
     * @author srec0053
     * @history 
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2024. 11. 20.			srec0053			최초작성
     * ------------------------------------------------
     * @param searchVo
     * @param model
     * @return
     * @throws Exception
     */
    @PostMapping("/getSetleInfoSection")
    public String getSetleInfoSection(@RequestBody OrderDtlsVO searchVo, ModelMap model) throws Exception  {
    	String orderNo = searchVo.getOrderNo();
    	String entrpsNo = userInfoUtil.getEntripsNo();
    	
    	searchVo.setEntrpsNo(entrpsNo);
    	
    	// 주문 정보
        OrderDtlsVO orderDtlsInfo = Optional.ofNullable(orderDtlsDetailService.selectOrderDtlsDetail(searchVo))
                .orElseThrow(()->{
                    return new Exception("주문 정보를 확인할 수 없습니다.");
                });

        orderDtlsInfo.setWtChange(orderDtlsInfo.getWtChange().stripTrailingZeros());
    	
    	// 결제 정보를 조회
        OrSetleInfoVO orderSetleInfo = orderDtlsDetailService.selectOrSetleInfo(orderNo);
        
        model.addAttribute("orderDtlsInfo"  , orderDtlsInfo);       // 주문 정보
        model.addAttribute("orderSetleInfo" , orderSetleInfo);      // 결제 정보(결제상세 내역포함)
    	
        return "my/orderDtlsDetailSetleInfoSection";
    }
}
