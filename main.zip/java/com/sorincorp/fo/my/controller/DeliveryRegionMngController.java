package com.sorincorp.fo.my.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.deliveryCarMng.model.DeliveryCarMngCommVO;
import com.sorincorp.comm.deliveryCarMng.service.DeliveryCarMngCommService;
import com.sorincorp.comm.entrpsdlvrg.service.EntrpsDlvrgService;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.my.model.DeliveryRegionMngVO;
import com.sorincorp.fo.my.service.DeliveryRegionMngService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/my/delivery")
public class DeliveryRegionMngController {

	@Autowired
	private DeliveryRegionMngService deliveryRegionMngService;
	@Autowired
	private DeliveryCarMngCommService deliveryCarMngCommService;
	@Autowired
	private EntrpsDlvrgService entrpsDlvrgService;
	@Autowired
	private CustomValidator customValidator;
	@Autowired
	private UserInfoUtil userInfoUtil;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	@RequestMapping("/selectDeliveryRegionMngList")
	public String selectDeliveryRegionMngList(ModelMap model, String menuNm) {

		try {
			String entrpsNo = "";
			String mberSeCode = "";
			String jspPath = "";

			if (userInfoUtil.getAccountInfo() != null) {
				entrpsNo = userInfoUtil.getAccountInfo().getEntrpsNo();
				mberSeCode = userInfoUtil.getAccountInfo().getSecode();
			}

			if ("car".equals(menuNm)) {

				List<DeliveryCarMngCommVO> mbVhcleInfoBasList = deliveryCarMngCommService.selectMbVhcleInfoBas(entrpsNo);
				List<DeliveryCarMngCommVO> mbDrvArticlInfoBasList = deliveryCarMngCommService.selectMbDrvArticlInfoBas(entrpsNo);
				model.addAttribute("mbVhcleInfoBasList", mbVhcleInfoBasList);
				model.addAttribute("mbVhcleInfoBasCnt", mbVhcleInfoBasList.size());
				model.addAttribute("mbDrvArticlInfoBasList", mbDrvArticlInfoBasList);
				model.addAttribute("mbDrvArticlInfoBasCnt", mbDrvArticlInfoBasList.size());
				model.addAttribute("entrpsNo", entrpsNo);
				model.addAttribute("mberSeCode", mberSeCode);
				model.addAttribute("menuNm", menuNm);

				jspPath = "my/deliveryCarMngList";

			} else {

				menuNm = "delivery";

				List<DeliveryRegionMngVO> mbDlvrgSeDtlList = deliveryRegionMngService.selectMbDlvrgSeDtlListList(entrpsNo);
				List<DeliveryRegionMngVO> mbDlvrgSeDtlList2 = deliveryRegionMngService.selectMbDlvrgSeDtlListList("all");
				List<CommonCodeVO> domainList = deliveryRegionMngService.selectemailDomainList();
				model.addAttribute("mbDlvrgSeDtlList", mbDlvrgSeDtlList);
				model.addAttribute("mbDlvrgSeDtlList2", mbDlvrgSeDtlList2);
				model.addAttribute("domainList", domainList);
				model.addAttribute("entrpsNo", entrpsNo);
				model.addAttribute("mberSeCode", mberSeCode);
				model.addAttribute("menuNm", menuNm);

				jspPath = "my/deliveryRegionMngList";
			}

			return jspPath;

		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			return "error/503";
		}
	}

	@RequestMapping("/selectDeliveryRegionMngListAjax")
	@ResponseBody
	public Map<String, Object> selectDeliveryRegionMngListAjax(@RequestBody DeliveryRegionMngVO deliveryRegionMngVO) throws Exception {
		// log.debug("deliveryRegionMngVO =======>" + deliveryRegionMngVO.toString());
		List<DeliveryRegionMngVO> deliveryRegionMngList = deliveryRegionMngService.selectDeliveryRegionMngList(deliveryRegionMngVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("dataList", deliveryRegionMngList);

		return map;
	}

	@RequestMapping("/selectMbDlvrgSeDtlListList")
	public ResponseEntity<Object> selectMbDlvrgSeDtlListList(ModelMap model) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		if (userInfoUtil.getAccountInfo() == null) {
			return new ResponseEntity<>(map, HttpStatus.BAD_REQUEST);
		}
		List<DeliveryRegionMngVO> mbDlvrgSeDtlList = deliveryRegionMngService.selectMbDlvrgSeDtlListList(userInfoUtil.getAccountInfo().getEntrpsNo());

		map.put("mbDlvrgSeDtlList", mbDlvrgSeDtlList);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@Transactional
	@RequestMapping("/updateBassDlvrgAt")
	@ResponseBody
	public ResponseEntity<Object> updateBassDlvrgAt(@RequestBody DeliveryRegionMngVO deliveryRegionMngVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		// log.debug(deliveryRegionMngVO.toString());
//		customValidator.validate(deliveryRegionMngVO, bindingResult, DeliveryRegionMngVO.Update.class);
//		if (bindingResult.hasErrors()) {
//			// validation 을 통과하지 못했을 경우
//			log.debug("bindingResult.hasErrors() =============>" + bindingResult.getAllErrors());
//			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
//		}

		int result = deliveryRegionMngService.updateBassDlvrgAt(deliveryRegionMngVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@Transactional
	@RequestMapping("/deleteDeliveryRegion")
	@ResponseBody
	public ResponseEntity<Object> deleteDeliveryRegion(@RequestBody DeliveryRegionMngVO deliveryRegionMngVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		// log.debug(deliveryRegionMngVO.toString());
		customValidator.validate(deliveryRegionMngVO, bindingResult, DeliveryRegionMngVO.Delete.class);
		if (bindingResult.hasErrors()) {
			// validation 을 통과하지 못했을 경우
			// log.debug("bindingResult.hasErrors() =============>" +
			// bindingResult.getAllErrors());
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = deliveryRegionMngService.deleteDeliveryRegion(deliveryRegionMngVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@Transactional
	@RequestMapping("/insertDeliveryRegion")
	@ResponseBody
	public ResponseEntity<Object> insertDeliveryRegion(@RequestBody DeliveryRegionMngVO deliveryRegionMngVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();
		String entrpsNo = "";
		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		} else {
			entrpsNo = userInfoUtil.getAccountInfo().getEntrpsNo();
		}

		// log.debug(deliveryRegionMngVO.toString());
		customValidator.validate(deliveryRegionMngVO, bindingResult, DeliveryRegionMngVO.Insert.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			// log.debug("bindingResult.hasErrors() =============>" +
			// bindingResult.getAllErrors());
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = deliveryRegionMngService.insertDeliveryRegion(deliveryRegionMngVO);

		retVal.put("entrpsDlvrg", entrpsDlvrgService.getEntrpsDlvrgList(entrpsNo));

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@Transactional
	@RequestMapping("/updateDeliveryRegion")
	@ResponseBody
	public ResponseEntity<Object> updateDeliveryRegion(@RequestBody DeliveryRegionMngVO deliveryRegionMngVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		// log.debug(deliveryRegionMngVO.toString());
		customValidator.validate(deliveryRegionMngVO, bindingResult, DeliveryRegionMngVO.Update.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			// log.debug("bindingResult.hasErrors() =============>" +
			// bindingResult.getAllErrors());
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = deliveryRegionMngService.updateDeliveryRegion(deliveryRegionMngVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

}
