package com.sorincorp.fo.my.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.my.model.MemberMgrVO;
import com.sorincorp.fo.my.service.DeliveryRegionMngService;
import com.sorincorp.fo.my.service.MemberMgrService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/my/member")
public class MemberMgrController {

	@Autowired
	private MemberMgrService memberMgrService;
	@Autowired
	private DeliveryRegionMngService deliveryRegionMngService;
	@Autowired
	private CustomValidator customValidator;
	@Autowired
    private UserInfoUtil userInfoUtil;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";


	@RequestMapping("/selectMyCorpMemberList")
	public String selectMyCorpMemberList(ModelMap model) {

		try {
			String entrpsNo = "";
			String mberNo = "";
			String mberSeCode = "";

			if(userInfoUtil.getAccountInfo() != null) {
				entrpsNo = userInfoUtil.getAccountInfo().getEntrpsNo();
				mberNo = userInfoUtil.getAccountInfo().getMberNo();
				mberSeCode = userInfoUtil.getAccountInfo().getSecode();
			}

			List<MemberMgrVO> mberSeCodeList = memberMgrService.getMberSeCodeList();
			List<CommonCodeVO> domainList = deliveryRegionMngService.selectemailDomainList();
			model.addAttribute("mberSeCodeList", mberSeCodeList);
			model.addAttribute("domainList", domainList);
			model.addAttribute("entrpsNo", entrpsNo);
			model.addAttribute("mberNo", mberNo);
			model.addAttribute("mberSeCode", mberSeCode);

			return "my/memberMgr";
		} catch(Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}


	@RequestMapping("/selectMyCorpMemberListAjax")
	@ResponseBody
	public ResponseEntity<Object> selectMyCorpMemberListAjax(@RequestBody MemberMgrVO memberMgrVO)
			throws Exception {
		//log.debug("memberMgrVO =======>" + memberMgrVO.toString());
		List<MemberMgrVO> myCorpMemberList = memberMgrService.selectMyCorpMemberList(memberMgrVO);

		// 리턴값
		Map<String, Object> map = new HashMap<String, Object>();

		map.put("memberList", myCorpMemberList);
		map.put("memberCnt", myCorpMemberList.size());

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@RequestMapping("/selectMemberDetailInfo")
	@ResponseBody
	public ResponseEntity<Object> selectMemberDetailInfo(@RequestBody MemberMgrVO memberMgrVO, BindingResult bindingResult)
			throws Exception {
		//log.debug("memberMgrVO =======>" + memberMgrVO.toString());
		customValidator.validate(memberMgrVO, bindingResult, MemberMgrVO.Search.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			//log.debug("bindingResult.hasErrors() =============>" + bindingResult.getAllErrors());
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		MemberMgrVO memberDetailInfo = memberMgrService.selectMemberDetailInfo(memberMgrVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("memberDetailInfo", memberDetailInfo);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@RequestMapping("/selectMberIdDupYn")
	@ResponseBody
	public ResponseEntity<Object> selectMberIdDupYn(@RequestBody MemberMgrVO memberMgrVO)
			throws Exception {
		//log.debug("memberMgrVO =======>" + memberMgrVO.toString());
		String dupYn = memberMgrService.selectMberIdDupYn(memberMgrVO);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("dupYn", dupYn);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@Transactional
	@RequestMapping("/insertMberInfo")
	@ResponseBody
	public ResponseEntity<Object> insertMberInfo(@RequestBody MemberMgrVO memberMgrVO, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		//log.debug("memberMgrVO =======>" + memberMgrVO.toString());
		customValidator.validate(memberMgrVO, bindingResult, MemberMgrVO.Insert.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			//log.debug("bindingResult.hasErrors() =============>" + bindingResult.getAllErrors());
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		int result = memberMgrService.insertMberInfo(memberMgrVO);


		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@Transactional
	@RequestMapping("/updateMberInfo")
	@ResponseBody
	public ResponseEntity<Object> updateMberInfo(@RequestBody MemberMgrVO memberMgrVO, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		//log.debug("memberMgrVO =======>" + memberMgrVO.toString());
		customValidator.validate(memberMgrVO, bindingResult, MemberMgrVO.Update.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			//log.debug("bindingResult.hasErrors() =============>" + bindingResult.getAllErrors());
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		int result = memberMgrService.updateMberInfo(memberMgrVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put("msg", "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put("msg", "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
}
