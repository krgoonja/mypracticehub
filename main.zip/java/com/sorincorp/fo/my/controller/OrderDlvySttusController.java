package com.sorincorp.fo.my.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.bsnInfo.model.RltmEndTimeVO;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.order.service.CommLimitOrderService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.my.model.DlivyVO;
import com.sorincorp.fo.my.model.OrderDlvySttusVO;
import com.sorincorp.fo.my.model.OrderLimitValidVO;
import com.sorincorp.fo.my.service.OrderDlvySttusService;
import com.sorincorp.fo.my.service.OrderLimitService;

import lombok.extern.slf4j.Slf4j;

/**
 * 마이페이지 > 주문 배송 내역 > 배송현황조회
 * @author hanjook
 *
 */
@Slf4j
@Controller
@RequestMapping("/my/order")
public class OrderDlvySttusController {

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private OrderDlvySttusService orderDlvySttusService;
	
	@Value("${dlvy.trace.url}")
    private String dlvyTraceUrl;


	/**
	 * @return
	 * @throws Exception
	 */
	private Account getAccountInfo() throws Exception {
        Account account = userInfoUtil.getAccountInfo();
        if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
            throw new Exception("로그인 정보를 확인해주세요.");
        }
        return account;
    }

	/**
	 * @param flag
	 * @param model
	 * @return
	 */
	@RequestMapping("/dlvySttus")
	public String dlvySttus(@RequestBody(required = false) String flag, ModelMap model) {
		try {
			Account account = userInfoUtil.getAccountInfo();
	        if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
	        	return "us/loginMain";
	        }

	        log.debug("flag ; ", flag);
	        if ("1".equals(flag)) {
	        	model.addAttribute("flag", flag);
	        }
			return "my/orderDlvySttusList";

        } catch(Exception e) {
            log.error(e.getMessage());
            return "error/503";
    	}
	}

	/**
	 * @param searchVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/dlvySttus/list")
	@ResponseBody
	public ResponseEntity<?> dlvySttusList(@RequestBody OrderDlvySttusVO searchVo) throws Exception {
		Account account = getAccountInfo();
		Map<String, Object> retmap = new HashMap<>();

        searchVo.setMberNo(account.getMberNo()); // 회원번호
        searchVo.setEntrpsNo(account.getEntrpsNo()); // 업체번호
        searchVo.setMberSeCode(account.getSecode()); //회원구분코드

        List<OrderDlvySttusVO> dlvySttusList = orderDlvySttusService.selectDlvySttusList(searchVo);
        int totCnt = orderDlvySttusService.selectOrderDlvySttusTotCnt(searchVo);

        retmap.put("dlvySttusListTotCnt", totCnt);
        retmap.put("dlvySttusList", dlvySttusList);        

        return new ResponseEntity<>(retmap, HttpStatus.OK);
	}
	
	/**
	 * @param searchVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/dlvySttus/vhcleDtl")
	@ResponseBody
	public ResponseEntity<?> dlvyVhcleDtl(@RequestBody OrderDlvySttusVO searchVo) throws Exception {
		Account account = getAccountInfo();
		Map<String, Object> retmap = new HashMap<>();

        searchVo.setMberNo(account.getMberNo()); // 회원번호
        searchVo.setEntrpsNo(account.getEntrpsNo()); // 업체번호
        searchVo.setMberSeCode(account.getSecode()); //회원구분코드

        List<OrderDlvySttusVO> vhcleList = orderDlvySttusService.selectOrderDlvySttusVhcleDtl(searchVo);
                
        retmap.put("vhcleList", vhcleList);
        retmap.put("dlvyTraceUrl", dlvyTraceUrl);
        
        return new ResponseEntity<>(retmap, HttpStatus.OK);
	}
}
