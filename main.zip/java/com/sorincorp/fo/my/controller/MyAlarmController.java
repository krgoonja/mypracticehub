package com.sorincorp.fo.my.controller;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.sidecar.service.SidecarService;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.login.service.AccountServiceImpl;
import com.sorincorp.fo.my.model.MyCmmrcAlarmVO;
import com.sorincorp.fo.my.model.MyHopePcAlarmVO;
import com.sorincorp.fo.my.model.MyInvntryAlarmVO;
import com.sorincorp.fo.my.service.MyAlarmService;
import com.sorincorp.fo.op.model.HopePcNtcnSetupVO;
import com.sorincorp.fo.op.model.InvntryNtcnSetupVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/my/alarm")
@ComponentScan(basePackages = {"com.sorincorp.comm.*"})
public class MyAlarmController {
	
	@Autowired
	MyAlarmService myAlarmService;
	
	@Autowired
	UserInfoUtil userInfoUtil;

	@Autowired
	AccountServiceImpl accountService;
	
	@Autowired
	MessageUtil messageUtil;
	
	@Autowired
	private CustomValidator customValidator;
	
	@Autowired
	CommonCodeService commonCodeService;
	
	@Autowired
	SidecarService sidecarSerivce;
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 희망가 알림 화면을 조회한다.
	 * </pre>
	 * @date 2021. 9. 8.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 8.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@RequestMapping("/alarmList")
	public String hopePc(@RequestBody(required=false) Map<String, String> paramMap, ModelMap model) {
	
		try {
			 String entrpsNo = "";
			 String mberNo = "";
			 if(userInfoUtil.getAccountInfo() != null) {
				 entrpsNo = userInfoUtil.getAccountInfo().getEntrpsNo() != null ? userInfoUtil.getAccountInfo().getEntrpsNo() : "";
				 mberNo = userInfoUtil.getAccountInfo().getMberNo() != null ?  userInfoUtil.getAccountInfo().getMberNo() : "";
			 }
			 
			 List<MyHopePcAlarmVO> myHopePcAlarmVo = myAlarmService.selectHopePcAlarm(entrpsNo);
			 List<MyInvntryAlarmVO> myInvntryAlarmVo = myAlarmService.selectInvntryAlarm(entrpsNo);
			 List<MyCmmrcAlarmVO> myCmmrcAlarmVo = myAlarmService.selectCmmrcAlarm(mberNo);
			 
			 model.put("myHopePcAlarmVoList", myHopePcAlarmVo); // 희망가 알림 내역 조회
			 model.put("myInvntryAlarmVoList", myInvntryAlarmVo); // 재고 알림 내역 조회
			 model.put("myCmmrcAlarmVoList", myCmmrcAlarmVo); // 커머스 알림 내역 조회
			 model.addAttribute("sidcar", sidecarSerivce.getSidecarOnList()); //사이드카 정보
			 
			 model.put("tab", paramMap.get("map"));
			return "my/myHopePcAlarm";
			
		}catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 희망가 알림을 수정을 위한 최초 실시간 판매 가격 가져오기
	 * </pre>
	 * @date 2021. 12. 1.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 1.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param updateVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/selectRealTimeSellHopePc")
	public ResponseEntity<Object> selectRealTimeSellHopePc(@RequestBody HopePcNtcnSetupVO updateVO,BindingResult bindingResult) throws Exception{
		
	 	Map<String,Object> map = new HashMap<String,Object>();
	 	
	 	customValidator.validate(updateVO, bindingResult, HopePcNtcnSetupVO.selectRlTmSllHopePc.class);
	 	
	 	if(bindingResult.hasErrors()) {
	 		return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
	 	}
	 	
	 	
	 	map = myAlarmService.selectRealTimeSellAlarm(updateVO);
	 			
	 	return new ResponseEntity<>(map,HttpStatus.OK);	
	}
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 희망가 알림을 수정한다.
	 * </pre>
	 * @date 2021. 9. 23.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 23.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/updateHopePc")
	public ResponseEntity<Object> updateHopePc(@RequestBody HopePcNtcnSetupVO updateVO,BindingResult bindingResult) {
		
	 	 Map<String,Object> map = new HashMap<String,Object>();
	 	 
	 	 int result = 0;
	 	 
	 	customValidator.validate(updateVO, bindingResult, HopePcNtcnSetupVO.updateHopePc.class);
	 	
	 	if(bindingResult.hasErrors()) {
	 		return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
	 	}
	 	
		//메탈별 최소금액 확인
		try {
			List<CommonCodeVO> metalCodeList = commonCodeService.getMultiFilterCodeRetVo("METAL_CODE",updateVO.getMetalCode(),	//MAIN_CODE가 "METAL_CODE"인 공통 코드
					  "CODE_DCTWO","Y", null, null	//CODE_DCTWO(코드 설명2, EC 판매 대상 여부)가 Y인 METAL_CODE
					, "CODE_CHRCTR_REFRNTHREE", "1", "0", "1")//CODE_CHRCTR_REFRNTHREE(코드 문자 참조3, 판매비트)의 첫번째 값(LIVE)이 1(TRUE)인 METAL_CODE
					.values().stream().collect(Collectors.toList());
			
			for(CommonCodeVO metalCode : metalCodeList) {
				if(metalCode.getCodeNumberRefrntwo() != null && Integer.parseInt(updateVO.getHopepc()) < metalCode.getCodeNumberRefrntwo().intValue()) {
					
					DecimalFormat decFormat = new DecimalFormat("###,###원 ");
					String minPrice = decFormat.format(metalCode.getCodeNumberRefrntwo());
					
					Object[] obj = {"희망가격", minPrice};
					return new ResponseEntity<>(messageUtil.getMessage("co.validation.min", obj),HttpStatus.BAD_REQUEST);
				}
			}
		} catch (Exception e) {
			return new ResponseEntity<>("오류가 발생하였습니다.", HttpStatus.BAD_REQUEST);
		}
		
		 try {
			 
			 Account account = userInfoUtil.getAccountInfo();
			 String acId = "";
			 
			 if(account != null) {
				 acId = account.getId();
			 }
			 
			 updateVO.setFrstRegisterId(acId);
			 updateVO.setLastChangerId(acId);
			 
			 result = myAlarmService.updateHopePcAlarm(updateVO);

			 if(result == 0) {
				 return new ResponseEntity<>(messageUtil.getMessage("fo.op.hopePrice.alarm.result.fail"),HttpStatus.BAD_REQUEST);
			 } 
		 }
		 catch (DuplicateKeyException e) {
			 return new ResponseEntity<>(messageUtil.getMessage("fo.op.hopePrice.alarm.result.fail.duplication"),HttpStatus.BAD_REQUEST);
		}
		

		return new ResponseEntity<>(map,HttpStatus.OK);	
		
	}
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 희망가 알림을 삭제한다.
	 * </pre>
	 * @date 2021. 9. 23.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 23.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/deleteHopePc")
	public ResponseEntity<Object> deleteHopePc(@RequestBody HopePcNtcnSetupVO vo,BindingResult bindingResult) {
		
	 	 Map<String,Object> map = new HashMap<String,Object>();
	 	 int result = 0;
		
	 	customValidator.validate(vo, bindingResult, HopePcNtcnSetupVO.deleteHopePc.class);
	 	
	 	if(bindingResult.hasErrors()) {
	 		return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
	 	}
	 	 
	 	 
		try {
			Account account = userInfoUtil.getAccountInfo();
			String acId = "";
			 
			if(account != null) {
				acId = account.getId();
			}
			 
			vo.setLastChangerId(acId);
			result = myAlarmService.deleteHopePcAlarm(vo);
		}
		catch (Exception e) {
			return new ResponseEntity<>(messageUtil.getMessage("fo.or.result.error"),HttpStatus.BAD_REQUEST);
		}
		
		if(result == 1) {
			map.put("result", "success");
		}
		
		return new ResponseEntity<>(map,HttpStatus.OK);			
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 알림 내역 조회 - 헤더
	 * </pre>
	 * @date 2021. 9. 30.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 30.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception 
	 */
	@ResponseBody
	@RequestMapping("/selectHeaderAlarm")
	public ResponseEntity<Object> selectHeaderAlarm(@RequestBody MyHopePcAlarmVO vo,BindingResult bindingResult) {
		List<MyHopePcAlarmVO> headerAlarm = new ArrayList<MyHopePcAlarmVO>();
		Map<String,Object> map = new HashMap<>();
		
		customValidator.validate(vo, bindingResult, MyHopePcAlarmVO.selectHeaderAlarm.class);
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		try {
			
			String entrpsNo = vo.getEntrpsNo();
			headerAlarm = myAlarmService.selectHeaderAlarm(entrpsNo);			
		}
		catch (Exception e) {
			return new ResponseEntity<>(messageUtil.getMessage("fo.or.result.error"),HttpStatus.BAD_REQUEST);
		}
		
		
		map.put("headerAlarmList",headerAlarm);
		
		return new ResponseEntity<>(map,HttpStatus.OK);
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 재고 알림을 삭제한다.
	 * </pre>
	 * @date 2021. 10. 18.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 18.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/deleteInvntryAlarm")
	public ResponseEntity<Object> deleteInvntryAlarm(@RequestBody InvntryNtcnSetupVO vo,BindingResult bindingResult) {
	 	
		Map<String,Object> map = new HashMap<String,Object>();
	 	int result = 0;
	 	
	 	customValidator.validate(vo, bindingResult, InvntryNtcnSetupVO.updateInvntry.class);
		
	 	if(bindingResult.hasErrors()) {
	 		return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
	 	}
	 	
	 	
		try {
			
			Account account = userInfoUtil.getAccountInfo();
			String acId = "";
			 
			if(account != null) {
				acId = account.getId();
			}
			vo.setLastChangerId(acId);
			result = myAlarmService.deleteInvntryAlarm(vo);
			
			if(result == 0) {
				 return new ResponseEntity<>(messageUtil.getMessage("fo.or.result.error"),HttpStatus.BAD_REQUEST);
			}
		}
		catch (Exception e) {
			return new ResponseEntity<>(messageUtil.getMessage("fo.or.result.error"),HttpStatus.BAD_REQUEST);
		}
		
		return new ResponseEntity<>(map,HttpStatus.OK);			
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 재고 알림 상태를 수정한다.
	 * </pre>
	 * @date 2021. 10. 18.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 18.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/updateInvntryUseAt")
	public ResponseEntity<Object> updateInvntryUseAt(@RequestBody InvntryNtcnSetupVO vo,BindingResult bindingResult) {
	 	 Map<String,Object> map = new HashMap<String,Object>();

	 	 int result = 0;
		 	
	 	customValidator.validate(vo, bindingResult, InvntryNtcnSetupVO.updateInvntry.class);
		
	 	if(bindingResult.hasErrors()) {
	 		return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
	 	}
	 	 
		 try {
			 Account account = userInfoUtil.getAccountInfo();
			 String acId = "";
			 
			 if(account != null) {
			 	acId = account.getId();
			 }
			 vo.setLastChangerId(acId);
			 result = myAlarmService.updateInvntryUseAt(vo);
			 
			 if(result == 0) {
				 return new ResponseEntity<>(messageUtil.getMessage("fo.op.invntry.alarm.result.fail.modify"),HttpStatus.BAD_REQUEST);
			 } 

		 }
		 catch (Exception e) {
			 return new ResponseEntity<>(messageUtil.getMessage("fo.op.invntry.alarm.result.fail.modify"),HttpStatus.BAD_REQUEST);
		 }
		

		return new ResponseEntity<>(map,HttpStatus.OK);	
		
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 희망가 알림 상태를 수정한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/updateHopePcUseAt")
	public ResponseEntity<Object> updateHopePcUseAt(@RequestBody MyHopePcAlarmVO vo,BindingResult bindingResult) {
	 	 Map<String,Object> map = new HashMap<String,Object>();

	 	 int result = 0;
		 	
	 	customValidator.validate(vo, bindingResult, MyHopePcAlarmVO.updateHopeUseAt.class);
		
	 	if(bindingResult.hasErrors()) {
	 		return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
	 	}
	 	 
		 try {
			 
			 Account account = userInfoUtil.getAccountInfo();
			 String acId = "";
			 
			 if(account != null) {
				 acId = account.getId();
			 }
			 vo.setLastChangerId(acId);
			 result = myAlarmService.updateHopePcUseAt(vo);

			 if(result == 0) {
				 return new ResponseEntity<>(messageUtil.getMessage("fo.op.invntry.alarm.result.fail.modify"),HttpStatus.BAD_REQUEST);
			 } 
		 }
		 catch (Exception e) {
			 return new ResponseEntity<>(messageUtil.getMessage("fo.op.invntry.alarm.result.fail.modify"),HttpStatus.BAD_REQUEST);
		 }
		

		return new ResponseEntity<>(map,HttpStatus.OK);	
		
	}
}
