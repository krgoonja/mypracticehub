package com.sorincorp.fo.my.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.my.model.PapersManageDetailVO;
import com.sorincorp.fo.my.model.PapersManageVO;
import com.sorincorp.fo.my.service.PapersManageService;

import lombok.extern.slf4j.Slf4j;

/**
 *
 * 서류 관리 Controller.java
 * @version
 * @since 2021. 9. 8.
 * @author srec0054
 */
@Slf4j
@Controller
@RequestMapping("/my/papersManage")
public class PapersManageController {

	@Autowired
	private PapersManageService papersManageService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	FileDocService fileDocService;

	@Value("${oz.connection.reportname}")
	private String reportName;

	@Value("${oz.db.alias}")
	private String dbAlias;

	/**
	 *
	 * <pre>
	 * 마이페이지 > 서류 관리 : 페이지 로드
	 * </pre>
	 * @date 2021. 9. 8.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 8.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	ModelMap model
	 * @return	String
	 * @throws 	Exception
	 */
	@RequestMapping("/viewPapersManage")
	public String viewPapersManage(ModelMap model) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
			throw new Exception("로그인 정보를 확인해주세요.");
		}

		try {
			return "my/papersManage";

		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}

	}//end viewPapersManage()

	/**
	 *
	 * <pre>
	 * 마이페이지 > 서류 관리 : 리스트 조회
	 * </pre>
	 * @date 2021. 9. 8.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 8.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param	PapersManageVO paramVo
	 * @return	Map<String, Object>
	 * @throws 	Exception
	 */
	@ResponseBody
	@PostMapping("/selectPapersManage")
	public Map<String, Object> selectPapersManage(@RequestBody PapersManageVO paramVo) throws Exception {
		log.debug("selectPapersManage Start paramVo.toString() = " + paramVo.toString());
		Account account 		= userInfoUtil.getAccountInfo();
		if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
			throw new Exception("로그인 정보를 확인해주세요.");
		}
		paramVo.setMberNo(account.getMberNo());
		paramVo.setEntrpsNo(account.getEntrpsNo());

		Map<String, Object> map = new HashMap<>();

		Integer papersManageListCnt 			= papersManageService.selectPapersManageCnt(paramVo);	//서류관리 리스트 카운트
		List<PapersManageVO> papersManageList 	= papersManageService.selectPapersManage(paramVo);		//서류관리 리스트 조회

		map.put("papersManageListCnt", papersManageListCnt);
		map.put("papersManageList", papersManageList);

		return map;
	}//end selectPapersManage()

	/**
	 *
	 * <pre>
	 * 마이페이지 > 서류 관리 > 서류 관리 상세 : 페이지 로드
	 * </pre>
	 * @date 2021. 9. 13.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 13.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	ModelMap model
	 * @return	String
	 * @throws 	Exception
	 */
	@RequestMapping(value = "/viewPapersManageDetail", method={RequestMethod.GET, RequestMethod.POST})
	public String viewPapersManageDetail(@RequestBody(required = false) PapersManageDetailVO paramVo, ModelMap model) {
		log.debug("viewPapersManageDetail paramVo.toString() = " + paramVo.toString());

		try {
			model.addAttribute("orderNo", paramVo.getOrderNo()); // 주문번호

			return "my/papersManageDetail";

		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}

	}//end viewPapersManageDetail()

	/**
	 *
	 * <pre>
	 * 마이페이지 > 서류 관리 > 서류 관리 상세 : 상세 조회
	 * </pre>
	 * @date 2021. 9. 13.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 13.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	PapersManageDetailVO paramVo
	 * @return	Map<String, Object>
	 * @throws 	Exception
	 */
	@ResponseBody
	@PostMapping("/selectPapersManageDetail")
	public Map<String, Object> selectPapersManageDetail(@RequestBody PapersManageDetailVO paramVo) throws Exception {
		log.debug("selectPapersManage Start paramVo.toString() = " + paramVo.toString());

		Account account = userInfoUtil.getAccountInfo();
		if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
			throw new Exception("로그인 정보를 확인해주세요.");
		}
		paramVo.setMberNo(account.getMberNo());
		paramVo.setEntrpsNo(account.getEntrpsNo());

		Map<String, Object> map = new HashMap<>();

		List<PapersManageDetailVO> orderPayInfoList = papersManageService.selectPapersManageDetailList(paramVo);	//주문&결제 정보 리스트
		List<PapersManageDetailVO> selectPapersManageDetailList = papersManageService.selectPapersManage(paramVo);	//서류관리 상세 리스트 조회

		map.put("orderPayInfoList", orderPayInfoList);
		map.put("selectPapersManageDetailListCnt", selectPapersManageDetailList.size());
		map.put("selectPapersManageDetailList", selectPapersManageDetailList);

		return map;
	}

	/**
	 *
	 * <pre>
	 * 마이페이지 > 서류 관리 > 오즈리포트 호출
	 * </pre>
	 * @date 2021. 9. 24.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 24.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	PapersManageDetailVO paramVo
	 * @param 	ModelMap model
	 * @return	String
	 * @throws 	Exception
	 */
	@RequestMapping(value = "/papersManageOzReport", method={RequestMethod.GET, RequestMethod.POST})
	public String papersManageOzReport(PapersManageDetailVO paramVo, ModelMap model) throws Exception {
		log.debug("papersManageOzReport START");

		log.debug("param1 = " + paramVo.getParam1());
		log.debug("param2 = " + paramVo.getParam2());
		log.debug("param3 = " + paramVo.getParam3());
		log.debug("param4 = " + paramVo.getParam4());
		log.debug("tabDiv = " + paramVo.getTabDiv());
		log.debug("reportName 	= " + reportName);	// "DEV" or "REAL"
		log.debug("dbAlias 		= " + dbAlias);		// "SC_ECDV" or "SC_PRD"

		String frghtAddrseMoblphonNo = "";

		/**2022-04-19 추가 수정*/
		//출고지시서인 경우
		if (StringUtils.equals("instr", paramVo.getTabDiv())) {
			//출고지시서 화물수취인 전화번호 복호화
			frghtAddrseMoblphonNo = papersManageService.updateMoblphonNoDecryption(paramVo);
		}
		
		// 24-08-06 변경사항 : 거래내역서(입금증빙) 일 경우, 고객 계좌번호를 조회, 복호화하여 세팅해준다.
		if(StringUtils.equals(paramVo.getTabDiv(), "rcptPruf")) {
			paramVo.setParam2(papersManageService.getMberEwalletAcntNo(paramVo.getParam1()));
			paramVo.setParam3("03");
		}
		
		// 24-11-08 변경사항 : 변동금 확인서 목록일 경우 대상 변동금 확인서 목록 조회
		if(StringUtils.equals(paramVo.getTabDiv(), "changegldList")) {
			model.addAttribute("paramListJson", papersManageService.getAllChangegldCnfrmn(paramVo.getParam1()));
		}
		
		model.addAttribute("PARAM1"		, paramVo.getParam1());
		model.addAttribute("PARAM2"		, paramVo.getParam2());
		model.addAttribute("PARAM3"		, paramVo.getParam3());
		model.addAttribute("PARAM4"		, paramVo.getParam4());
		model.addAttribute("PARAM5"		, frghtAddrseMoblphonNo);

		model.addAttribute("TAB_DIV"	, paramVo.getTabDiv());
		model.addAttribute("REPORT_NAME", reportName);
		model.addAttribute("DB_ALIAS"	, dbAlias);

		log.debug("papersManageOzReport END ");

		return "my/papersManageOzReport";
	}//end papersManageOzReport()
	/**
	 *
	 * <pre>
	 * 마이페이지 > 주문 배송 내역 > 매매계약서 출력 > 거래명세서, 세금계산서 오즈리포트 호출
	 * </pre>
	 * @date 2024. 2. 27.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 2. 27.			sein					최초작성
	 * ------------------------------------------------
	 * @param 	PapersManageDetailVO paramVo
	 * @param 	ModelMap model
	 * @return	String
	 * @throws 	Exception
	 */
	@RequestMapping(value = "/papersDtlsManageOzReport", method={RequestMethod.GET, RequestMethod.POST})
	public String papersDtlsManageOzReport(PapersManageDetailVO paramVo, ModelMap model) throws Exception {
		log.debug("papersManageOzReport START");

		log.debug("param1 = " + paramVo.getParam1());
		log.debug("param2 = " + paramVo.getParam2());
		log.debug("param3 = " + paramVo.getParam3());
		log.debug("param4 = " + paramVo.getParam4());
		log.debug("tabDiv = " + paramVo.getTabDiv());
		log.debug("reportName 	= " + reportName);	// "DEV" or "REAL"
		log.debug("dbAlias 		= " + dbAlias);		// "SC_ECDV" or "SC_PRD"

		String frghtAddrseMoblphonNo = "";

		/**2022-04-19 추가 수정*/
		//출고지시서인 경우
		if (StringUtils.equals("instr", paramVo.getTabDiv())) {
			//출고지시서 화물수취인 전화번호 복호화
			frghtAddrseMoblphonNo = papersManageService.updateMoblphonNoDecryption(paramVo);
		}
		
		// 24-08-06 변경사항 : 거래내역서(입금증빙) 일 경우, 고객 계좌번호를 조회, 복호화하여 세팅해준다.
		if(StringUtils.equals(paramVo.getTabDiv(), "rcptPruf")) {
			paramVo.setParam2(papersManageService.getMberEwalletAcntNo(paramVo.getParam1()));
			paramVo.setParam3("03");
		}
		
		// 24-11-08 변경사항 : 변동금 확인서 목록일 경우 대상 변동금 확인서 목록 조회
		if(StringUtils.equals(paramVo.getTabDiv(), "changegldList")) {
			model.addAttribute("paramListJson", papersManageService.getAllChangegldCnfrmn(paramVo.getParam1()));
		}
		
		//거래 명세서, 세금계산서(1,2차 분기)
		if(paramVo.getTabDiv().equals("tax") || paramVo.getTabDiv().equals("trade")) {
			List<Map<String, Object>> taxTradeBillInfo = papersManageService.selectTaxTradeBillInfo(paramVo.getParam1()); //paramVo.getParam1() - 주문번호
			//1차 거래 명세서, 세금계산서 내용
			model.addAttribute("PARAM1"		, taxTradeBillInfo.get(0).get("orderNo"));
			model.addAttribute("PARAM2"		, taxTradeBillInfo.get(0).get("taxBillReqstNo"));
			model.addAttribute("PARAM3"		, taxTradeBillInfo.get(0).get("taxBillReqstDetailSn"));
			model.addAttribute("PARAM4"		, taxTradeBillInfo.get(0).get("canclExchngRtngudNo"));
			model.addAttribute("PARAM5"		, frghtAddrseMoblphonNo);

			if(taxTradeBillInfo.size()==2) {
				//2차 거래 명세서, 세금계산서 내용
				model.addAttribute("PARAM6"		, taxTradeBillInfo.get(1).get("orderNo"));
				model.addAttribute("PARAM7"		, taxTradeBillInfo.get(1).get("taxBillReqstNo"));
				model.addAttribute("PARAM8"		, taxTradeBillInfo.get(1).get("taxBillReqstDetailSn"));
				model.addAttribute("PARAM9"		, taxTradeBillInfo.get(1).get("canclExchngRtngudNo"));
			}

			model.addAttribute("TAX_TRADE_BILL_INFO_SIZE" , taxTradeBillInfo.size());
		//나머지 OZREPORT
		}else {
			model.addAttribute("PARAM1"		, paramVo.getParam1());
			model.addAttribute("PARAM2"		, paramVo.getParam2());
			model.addAttribute("PARAM3"		, paramVo.getParam3());
			model.addAttribute("PARAM4"		, paramVo.getParam4());
			model.addAttribute("PARAM5"		, frghtAddrseMoblphonNo);
			model.addAttribute("TAX_TRADE_BILL_INFO_SIZE" , 1);
		}
		model.addAttribute("TAB_DIV"	, paramVo.getTabDiv());
		model.addAttribute("REPORT_NAME", reportName);
		model.addAttribute("DB_ALIAS"	, dbAlias);

		log.debug("papersManageOzReport END ");

		return "my/papersManageOzReport";
	}//end papersManageOzReport()
	
	@RequestMapping(value = "/relatePapersOzReportList", method={RequestMethod.GET, RequestMethod.POST})
	public String relatePapersOzReportList(PapersManageDetailVO papersManageDetailVO, ModelMap model) throws Exception {
		try {
			List<PapersManageDetailVO> relatePapersInfoList = papersManageService.getRelatePapersInfo(papersManageDetailVO);

			List<Map<String, Object>> paramList = new ArrayList<>();
			for(PapersManageDetailVO relatePapersInfo : relatePapersInfoList) {
				Map<String, Object> map = new HashMap<>();

				String frghtAddrseMoblphonNo = "";

				/**2022-04-19 추가 수정*/
				//출고지시서인 경우
				if(StringUtils.equals("instr", relatePapersInfo.getTabDiv()) || StringUtils.equals("tax_selng_sle", relatePapersInfo.getTabDiv())) {
					//출고지시서 화물수취인 전화번호 복호화
					frghtAddrseMoblphonNo = papersManageService.updateMoblphonNoDecryption(relatePapersInfo);
				}//end if()

				map.put("PAPERSNM"		, relatePapersInfo.getPapersNm());
				map.put("OZNM"			, relatePapersInfo.getOzNm());
				map.put("PCOUNT"		, relatePapersInfo.getPCount());
				map.put("PARAM1"		, relatePapersInfo.getParam1());
				map.put("PARAMNM2"		, relatePapersInfo.getParamNm2());
				map.put("PARAM2"		, relatePapersInfo.getParam2());
				map.put("PARAMNM3"		, relatePapersInfo.getParamNm3());
				map.put("PARAM3"		, relatePapersInfo.getParam3());
				map.put("PARAMNM4"		, relatePapersInfo.getParamNm4());
				map.put("PARAM4"		, relatePapersInfo.getParam4());
				map.put("PARAM5"		, relatePapersInfo.getParam5());
				map.put("PARAM6"		, relatePapersInfo.getParam6());
				map.put("PHONE_NO"	    , frghtAddrseMoblphonNo);
				map.put("TAB_DIV"	    , relatePapersInfo.getTabDiv());
				paramList.add(map);
			}
			// 관련서류 - 일괄출력 구분
			String flag = "all_relate_papers_output";
			model.addAttribute("flag", flag);
			
			ObjectMapper objectMapper = new ObjectMapper();
			String paramListJson = objectMapper.writeValueAsString(paramList);
			
			model.addAttribute("paramListJson", paramListJson);
			model.addAttribute("REPORT_NAME"  , reportName);
			model.addAttribute("DB_ALIAS"	  , dbAlias);
		} catch (Exception e) {
			log.error("PapersManageController::relatePapersOzReportList exception = " + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}

		return "my/papersManageOzReport";
	}//end relatePapersOzReport()

	/**
	 *
	 * <pre>
	 * 성적서&패킹리스트 리스트 조회
	 * </pre>
	 * @date 2021. 9. 24.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 24.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	PapersManageDetailVO paramVo
	 * @return	Map<String, Object>
	 * @throws 	Exception
	 */
	@ResponseBody
	@PostMapping("/selectScreofePackngList")
	public Map<String, Object> selectScreofePackngList(@RequestBody PapersManageDetailVO paramVo) throws Exception {
		log.debug("PapersManageController::selectScreofePackngList Start");
		log.debug("paramVo.toString() = " + paramVo.toString());

		Map<String, Object> map = new HashMap<String, Object>();

		//성적서&패킹리스트 리스트 조회
		List<PapersManageDetailVO> selectScreofePackngList 	= papersManageService.selectScreofePackngList(paramVo);

		map.put("selectScreofePackngList", selectScreofePackngList);

		return map;
	}//end selectScreofePackngList()

	/**
	 *
	 * <pre>
	 * 성적서 & 패킹리스트 다운로드
	 * </pre>
	 * @date 2021. 10. 12.
	 * @author srec0054
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 12.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	FileDocVO vo
	 * @param 	HttpServletRequest request
	 * @param 	HttpServletResponse response
	 * @throws 	Exception
	 */
	@RequestMapping("/downLoad")
	public void commonDownLoad(FileDocVO vo, HttpServletRequest request, HttpServletResponse response) throws Exception {
		fileDocService.fileDocDownload(request, response, vo);
	}//end commonDownLoad()

}//end class()
