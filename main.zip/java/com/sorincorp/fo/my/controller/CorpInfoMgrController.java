package com.sorincorp.fo.my.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.mb.model.MbCmnCodeVO;
import com.sorincorp.fo.mb.service.MbCmnCodeService;
import com.sorincorp.fo.mb.service.NiceSelfCrtfctService;
import com.sorincorp.fo.my.model.CorpInfoMgrVO;
import com.sorincorp.fo.my.model.CorpKycInfoMgrVO;
import com.sorincorp.fo.my.service.CorpInfoMgrService;
import com.sorincorp.fo.my.service.DeliveryRegionMngService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/my/corpInfoMgr")
public class CorpInfoMgrController {

	@Autowired
	private CorpInfoMgrService corpInfoMgrService;

	@Autowired
	private DeliveryRegionMngService deliveryRegionMngService;

	@Autowired
	private CustomValidator customValidator;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private NiceSelfCrtfctService niceSelfCrtfctService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	@Autowired
	public FileDocService fileDocService;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	@RequestMapping("/selectCorpInfoMgr")
	public String selectCorpInfoMgr(HttpSession session, ModelMap model) {

		if (userInfoUtil.getAccountInfo() == null) {
			return "error/503";
		}

		try {

			CorpInfoMgrVO corpInfoMgrVO = new CorpInfoMgrVO();
			CorpKycInfoMgrVO corpKycInfoMgrVO = new CorpKycInfoMgrVO(); // 케이지크레딧_kyc정보

			String entrpsNo = userInfoUtil.getAccountInfo().getEntrpsNo();
			String userNm = userInfoUtil.getAccountInfo().getName();

			if (entrpsNo == null) {
				return "error/503";
			}

			corpInfoMgrVO.setEntrpsNo(entrpsNo);
			corpKycInfoMgrVO.setEntrpsNo(entrpsNo);

			int kycInfoCount = corpInfoMgrService.selectKycCorpInfoCount(corpInfoMgrVO);

			if (kycInfoCount != 0) {
				model.addAttribute("corpKycInfoMgrVO", corpInfoMgrService.selectKycCorpInfo(corpKycInfoMgrVO));
			}

			model.addAttribute("userNm", userNm);
			model.addAttribute("corpInfoMgrVO", corpInfoMgrService.selectCorpInfoDetail(corpInfoMgrVO));
			model.addAttribute("entrpsNo", userInfoUtil.getAccountInfo().getEntrpsNo());

			Map<Object, Object> map = niceSelfCrtfctService.niceSelfCrtfct(session, "wrtm");
			model.addAttribute("sEncData", map.get("sEncData"));

			String today = DateUtil.getNowDateTime("yyyy-MM-dd");
			model.addAttribute("today", today);

			List<MbCmnCodeVO> mrtggGrntyCntrctSttusCodeList = mbCmnCodeService.selectCmnCodeList("MRTGG_GRNTY_CNTRCT_STTUS_CODE");
			model.addAttribute("mrtggGrntyCntrctSttusCodeList", mrtggGrntyCntrctSttusCodeList);

			// 대출은행 리스트 조회
			List<CorpInfoMgrVO> lonGrntyBankUseAtList = corpInfoMgrService.selectLonGrntyBankUseAtList(entrpsNo);
			model.addAttribute("lonGrntyBankUseAtList", lonGrntyBankUseAtList);

			List<MbCmnCodeVO> bankList = mbCmnCodeService.selectCmnCodeList("BANK_CODE");

			for (int i = 0; i < bankList.size(); i++) {
				if ("0".equals(bankList.get(i).getSubCode())) {
					bankList.remove(i);
				}
			}

			model.addAttribute("bankList", bankList);

			String bankStr = "";
			String useAt = "";
			int cnt = 0;

			if (lonGrntyBankUseAtList != null) {
				for (int i = 0; i < lonGrntyBankUseAtList.size(); i++) {
					useAt = lonGrntyBankUseAtList.get(i).getUseAt();

					if ("Y".equals(useAt)) {
						if (cnt == 0) {
							bankStr += lonGrntyBankUseAtList.get(i).getBankCodeNm();
						} else {
							bankStr += ", " + lonGrntyBankUseAtList.get(i).getBankCodeNm();
						}
						cnt++;
					}
				}
			}

			model.addAttribute("bankStr", bankStr);
			model.addAttribute("mberSeCode", userInfoUtil.getMemberSecode());

			List<MbCmnCodeVO> domainList = mbCmnCodeService.selectCmnCodeList("EMAIL_DOMAIN");
			model.addAttribute("domainList", domainList);

			return "my/corpInfoMgr";
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			return "error/503";
		}
	}

	@Transactional
	@RequestMapping("/updateCorpInfoMgr")
	@ResponseBody
	public ResponseEntity<Object> updateCorpInfoMgr(@RequestBody CorpInfoMgrVO corpInfoMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		customValidator.validate(corpInfoMgrVO, bindingResult, CorpInfoMgrVO.Update.class);

		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			// log.info("bindingResult.hasErrors() =============>" +
			// bindingResult.getAllErrors());
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = corpInfoMgrService.updateCorpInfoMgr(corpInfoMgrVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/insertAttachFile")
	@ResponseBody
	public ResponseEntity<Object> insertAttachFile(MultipartHttpServletRequest mRequest) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		Map<String, Object> fileMap = corpInfoMgrService.uploadAttachFile(mRequest);

		String result = (String) fileMap.get(RESULT);

		if (SUCCESS.equals(result)) {
			retVal.put(RESULT, SUCCESS);
			retVal.put("fileMap", fileMap);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, (String) fileMap.get("errMsg"));
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/checkPassWord")
	@ResponseBody
	public ResponseEntity<Object> checkPassWord(@RequestBody CorpInfoMgrVO corpInfoMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		int result = corpInfoMgrService.checkPassWord(corpInfoMgrVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/selectTrmnatPossibleAt")
	@ResponseBody
	public ResponseEntity<Object> selectTrmnatPossibleAt(@RequestBody CorpInfoMgrVO corpInfoMgrVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		String result = corpInfoMgrService.selectTrmnatPossibleAt(corpInfoMgrVO);

		if (result != null && !"".equals(result)) {
			retVal.put(RESULT, SUCCESS);
			retVal.put("trmnatAt", result);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@RequestMapping("/corpKycInfoInput")
	public String corpKycInfoInput(HttpSession session, Model model) {

		if (userInfoUtil.getAccountInfo() == null) {
			return "error/503";
		}

		try {
			CorpInfoMgrVO corpInfoMgrVO = new CorpInfoMgrVO();
			CorpKycInfoMgrVO corpKycInfoMgrVO = new CorpKycInfoMgrVO(); // 케이지크레딧_kyc정보

			String entrpsNo = userInfoUtil.getAccountInfo().getEntrpsNo();
			String userNm = userInfoUtil.getAccountInfo().getName();

			if (entrpsNo == null) {
				return "error/503";
			}

			corpInfoMgrVO.setEntrpsNo(entrpsNo);
			corpKycInfoMgrVO.setEntrpsNo(entrpsNo);

			List<MbCmnCodeVO> kycCompanyCode = mbCmnCodeService.selectCmnCodeList("KYC_COMPNY_STRCT"); // 기업구조 코드
			List<MbCmnCodeVO> kycListType = mbCmnCodeService.selectCmnCodeList("KYC_LIST_TYPE"); // 상장정보 코드
			List<MbCmnCodeVO> emailDomain = mbCmnCodeService.selectCmnCodeList("EMAIL_DOMAIN"); // 이메일도메인 코드

			model.addAttribute("kycCompanyCode", kycCompanyCode);
			model.addAttribute("kycListType", kycListType);
			model.addAttribute("emailDomain", emailDomain);
			model.addAttribute("userNm", userNm);
			model.addAttribute("corpInfoMgrVO", corpInfoMgrService.selectCorpInfoDetail(corpInfoMgrVO));
			model.addAttribute("corpKycInfoMgrVO", corpInfoMgrService.selectKycCorpInfo(corpKycInfoMgrVO));
			model.addAttribute("entrpsNo", userInfoUtil.getAccountInfo().getEntrpsNo());

			return "my/corpKycInfoInput";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@SuppressWarnings("finally")

	@RequestMapping("/updEntrpsKycAtchFile")
	@ResponseBody
	public ResponseEntity<Object> fileUploadTest(MultipartHttpServletRequest mRequest) throws Exception {
		String errMsg = "";
		HashMap<String, String> fileMap = new HashMap<>();
		try {
			fileMap = corpInfoMgrService.saveAttachFile(mRequest);
		} catch (Exception e) {
			errMsg = fileMap.get("errMsg");
			log.info("errMsg ======>" + errMsg);
			log.error(e.toString());
		} finally {
			errMsg = fileMap.get("errMsg");
			if (errMsg != null && !"".equals(errMsg)) {
				log.error("ERROR ===============>" + errMsg);
				return new ResponseEntity<>(errMsg, HttpStatus.BAD_REQUEST);
			} else {
				return new ResponseEntity<>(fileMap, HttpStatus.OK);
			}
		}
	}

	@Transactional
	@RequestMapping("/updateCorpKycDetail")
	@ResponseBody
	public ResponseEntity<Object> updateCorpKycDetail(@RequestBody CorpKycInfoMgrVO corpKycInfoMgrVO) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		corpKycInfoMgrVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo()); // 기업코드
		corpKycInfoMgrVO.setKycRequstSttusCode("12"); // KYC 요청상태코드(KYC 접수완료) //요청승인상태코드
		corpKycInfoMgrVO.setLastChangerId(userInfoUtil.getAccountInfo().getId()); // 최종변경자 아이디

		// 전화번호 암호화
		corpKycInfoMgrVO.setRprsntvTelno(CryptoUtil.encryptAES256(corpKycInfoMgrVO.getRprsntvTelno())); // 대표자 전화번호
		corpKycInfoMgrVO.setCptalCharherTel(CryptoUtil.encryptAES256(corpKycInfoMgrVO.getCptalCharherTel())); // 자금담당자 전화번호
		corpKycInfoMgrVO.setJobChargerTel(CryptoUtil.encryptAES256(corpKycInfoMgrVO.getJobChargerTel())); // 업무담당자 전화번호

		boolean result = corpInfoMgrService.updateCorpKycInfoDetail(corpKycInfoMgrVO);

		if (result == true) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity(retVal, HttpStatus.OK);
	}

}
