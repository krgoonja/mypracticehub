/**
 *
 */
package com.sorincorp.fo.my.controller;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.microsoft.sqlserver.jdbc.StringUtils;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.mb.service.MbCmnCodeService;
import com.sorincorp.fo.my.model.EwalletMngVO;
import com.sorincorp.fo.my.service.EwalletMngService;

import lombok.extern.slf4j.Slf4j;



/**
 * MyInfoMngController.java
 * @version
 * @since 2021. 8. 23.
 * @author srec0009
 */
@Slf4j
@Controller
@RequestMapping("/fo/ewalletMng")
public class EwalletMngController {

	@Autowired
	private EwalletMngService ewalletMngService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	public EwalletMngVO setDefDate(EwalletMngVO ewalletMngVO) {
		//최대 조회기간 12개월
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		// 오늘 날짜
		String endDate = sdf.format(cal.getTime());
		// 1년전 날짜
		cal.add(cal.YEAR, -1);
		String startDate = sdf.format(cal.getTime());

		ewalletMngVO.setStartDate(startDate);
		ewalletMngVO.setEndDate(endDate);

		return ewalletMngVO;
	}

	/**
	 * <pre>
	 * 처리내용: 이월렛 환불 요청 내역 조회
	 * </pre>
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 16.			srec0009			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectRefndRequstDtls")
	public String selectRefndRequstDtls(ModelMap model) {

		if(userInfoUtil.getAccountInfo() == null) {
			return "error/503";
		}

		try {
			EwalletMngVO ewalletMngVO = new EwalletMngVO();
			ewalletMngVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());

			if(StringUtils.isEmpty(ewalletMngVO.getStartDate())) {
				setDefDate(ewalletMngVO);
			}
			//List<EwalletMngVO> refndRequstList = ewalletMngService.selectRefndRequstDtls(ewalletMngVO);
			//List<MbCmnCodeVO> tyCodeList = mbCmnCodeService.selectCmnCodeList("EWALLET_EXCCLC_TY_CODE");
			//List<EwalletMngVO> ewalletMngList = ewalletMngService.selectEwalletMng(ewalletMngVO);

			//model.addAttribute("tyCodeList", tyCodeList);
			//model.addAttribute("ewalletMngList", ewalletMngList);
			//model.addAttribute("refndRequstList", refndRequstList);
			//model.addAttribute("refndRequstListCnt", refndRequstList.size());
			//return "my/refndRequstDtls";

			List<EwalletMngVO> ewalletMngList = ewalletMngService.selectEwalletMng(ewalletMngVO);
			model.addAttribute("ewalletMngList", ewalletMngList);
			model.addAttribute("ewalletMngListCnt", ewalletMngList.size());

			return "my/ewalletMngList";
		} catch(Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}//end try ~ catch()
	}


	/**
	 * <pre>
	 * 처리내용: 환불 요청 검색
	 * </pre>
	 * @date 2021. 9. 29.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 29.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param ewalletMngVO
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/selectRefndRequstDtlsSearch")
	public ResponseEntity<Object> selectRefndRequstDtlsSearch(@RequestBody EwalletMngVO ewalletMngVO) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put("result", "F");
			retVal.put("errMsg", "로그인되지 않은 사용자입니다.");
			retVal.put("refndRequstList", null);
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		ewalletMngVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());

		/*
		 * if(StringUtils.isEmpty(ewalletMngVO.getStartDate())) {
		 * setDefDate(ewalletMngVO); }
		 */
		List<EwalletMngVO> refndRequstList = ewalletMngService.selectRefndRequstDtls(ewalletMngVO);
		retVal.put("result", "S");
		retVal.put("errMsg", "");
		retVal.put("refndRequstList", refndRequstList);
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 이월렛 내역 검색
	 * </pre>
	 * @date 2021. 9. 29.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 29.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param ewalletMngVO
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/selectEwalletDtlsSearch")
	public ResponseEntity<Object> selectEwalletDtlsSearch(@RequestBody(required=false) EwalletMngVO ewalletMngVO) throws Exception {

		Map<String, Object> retVal = new HashMap<>();
		String startDate = "";

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put("result", "F");
			retVal.put("errMsg", "로그인되지 않은 사용자입니다.");
			retVal.put("ewalletList", null);
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		ewalletMngVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());
		if(StringUtils.isEmpty(ewalletMngVO.getStartDate())) {
		}

		List<EwalletMngVO> ewalletList = ewalletMngService.selectEwalletMng(ewalletMngVO);
		retVal.put("result", "S");
		retVal.put("errMsg", "");
		retVal.put("ewalletList", ewalletList);

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 이월렛 내역 엑셀 다운
	 * </pre>
	 * @date 2022. 06. 21.
	 * @author sumin95
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 06. 21.			sumin95				최초작성
	 * ------------------------------------------------
	 * @param ewalletMngVO
	 * @return
	 * @throws Exception
	 */

	@RequestMapping("/excel")
	public ResponseEntity<Object> downloadExcel(Model model, HttpServletResponse response, HttpServletRequest request, EwalletMngVO ewalletMngVO) throws Exception{

		Map<String, Object> retVal = new HashMap<>();

		int rowNo = 0;

		if (userInfoUtil.getAccountInfo() != null) {
			ewalletMngVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());
		}

		List<EwalletMngVO> ewalletList = ewalletMngService.selectExcelEwalletMng(ewalletMngVO);			//이월렛 엑셀 리스트
		retVal.put("result", "S");
		retVal.put("errMsg", "");
		retVal.put("ewalletList", ewalletList);

		Workbook workbook = new HSSFWorkbook();															//엑셀 파일 생성
		Sheet sheet = workbook.createSheet("이월렛조회내역");											//엑셀 시트 생성
		String[] titleArr = {"거래일자", "유형", "금액", "잔액", "주문번호", "적요"};					//엑셀 타이틀 지정

		////엑셀 스타일
		CellStyle headStyle = workbook.createCellStyle();
		headStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.GREY_25_PERCENT.getIndex());		//헤더폰트색상
		headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		headStyle.setAlignment(HorizontalAlignment.CENTER);
		headStyle.setBorderTop(BorderStyle.THIN);
		headStyle.setBorderBottom(BorderStyle.THIN); 													// 셀 아래 테두리 실선 적용

		Font headerFont = workbook.createFont();
		Font rowFont = workbook.createFont();
		headerFont.setFontHeightInPoints((short) 12);
		headerFont.setBold(true);
		rowFont.setFontHeightInPoints((short) 11);
		headStyle.setFont(headerFont);

		CellStyle rowStyle = workbook.createCellStyle();
		DataFormat format = workbook.createDataFormat();
		rowStyle.setAlignment(HorizontalAlignment.CENTER);

		CellStyle rowStyle2 = workbook.createCellStyle();
		rowStyle2.setAlignment(HorizontalAlignment.RIGHT);

		CellStyle rowStyle3 = workbook.createCellStyle();
		rowStyle3.setAlignment(HorizontalAlignment.RIGHT);

		rowStyle.setFont(rowFont);

		Row headerRow = sheet.createRow(rowNo++);

		for (int i=0; i<titleArr.length; i++){
			headerRow.createCell(i).setCellValue(titleArr[i]);						//헤더 셀 생성
			headerRow.getCell(i).setCellStyle(headStyle);							//헤더 스타일 적용
			headerRow.setHeight((short)330);
		}


		for (EwalletMngVO ewallet : ewalletList) {
			Row row = sheet.createRow(rowNo++);

			row.createCell(0).setCellValue(ewallet.getEwalletDelngDt());			//거래일자
			row.createCell(1).setCellValue(ewallet.getEwalletDelngSeCodeNm());		//유형
			row.createCell(2).setCellValue(ewallet.getEwalletDelngAmount());		//금액
			row.createCell(3).setCellValue(ewallet.getEwalletBlce());				//잔액
			row.createCell(4).setCellValue(ewallet.getOrderNo());					//주문번호
			row.createCell(5).setCellValue(ewallet.getEwalletSumry());				//적요

			row.getCell(0).setCellStyle(rowStyle);
			row.getCell(1).setCellStyle(rowStyle);
			row.getCell(2).setCellStyle(rowStyle2);
			row.getCell(3).setCellStyle(rowStyle2);
			row.getCell(4).setCellStyle(rowStyle);
			row.getCell(5).setCellStyle(rowStyle);
			row.setHeight((short)300);
		}

		sheet.setColumnWidth(0, 3500);
		sheet.setColumnWidth(1, 3500);
		sheet.setColumnWidth(2, 4000);
		sheet.setColumnWidth(3, 4000);
		sheet.setColumnWidth(4, 5000);
		sheet.setColumnWidth(5, 5000);

		response.setContentType("ms-vnd/excel");
		response.setHeader("Content-Disposition", "attachment;filename=EwalletList.xls");

		workbook.write(response.getOutputStream());
		workbook.close();

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}


}
