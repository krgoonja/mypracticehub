/**
 *
 */
package com.sorincorp.fo.my.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.service.SimplMberEtrService;
import com.sorincorp.fo.my.model.SimplMberMyInfoMngVO;
import com.sorincorp.fo.my.service.SimplMberMyInfoMngService;

import lombok.extern.slf4j.Slf4j;

/**
 * MyInfoMngController.java
 *
 * @version
 * @since 2021. 8. 23.
 * @author srec0009
 */
@Slf4j
@Controller
@RequestMapping("/fo/simplMyPage")
public class SimplMberMyInfoMngController {

	@Autowired
	private SimplMberMyInfoMngService simplMbermyInfoMngService;

	@Autowired
	private SimplMberEtrService simplMberEtrService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	/**
	 * <pre>
	 * 처리내용: 간편회원 내정보관리
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectSimplMberMyInfoMng")
	public String selectEntrpsEtrStplat(Model model) {
		if (userInfoUtil.getAccountInfo() == null) {
			return "error/503";
		}
		try {
			String simplMberNo = userInfoUtil.getAccountInfo().getMberNo();

			SimplMberMyInfoMngVO simplMberInfoList = simplMbermyInfoMngService.selectSimplMberInfo(simplMberNo);
			List<EntrpsEtrVO> stplatList = simplMberEtrService.selectEntrpsEtrStplat();

			model.addAttribute("simplMberInfoList", simplMberInfoList);
			model.addAttribute("stplatList", stplatList);
			return "my/simplMberMyInfoMng";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 간편회원 비밀번호 확인
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param mberSecretNo
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/selectChkPw")
	public String selectChkPw(@RequestBody String mberSecretNo) throws Exception {
		if (userInfoUtil.getAccountInfo() == null) {
			return "F";
		}
		String result = "";
		// 로그인 세션에서 회원 번호
		String mberNo = userInfoUtil.getAccountInfo().getMberNo();
		result = simplMbermyInfoMngService.selectChkPw(mberNo, mberSecretNo);
		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param mberSecretNo
	 * @return
	 * @throws Exception
	 */

	@ResponseBody
	@PostMapping("/updateNewPw")
	public String updateNewPw(@RequestBody String mberSecretNo) throws Exception {
		if (userInfoUtil.getAccountInfo() == null) {
			return "F";
		}
		String result = "";
		String mberNo = userInfoUtil.getAccountInfo().getMberNo();
		result = simplMbermyInfoMngService.updateNewPw(mberNo, mberSecretNo);
		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 간편회원 정보 수정
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param simplMberMyInfoMngVO
	 * @return
	 * @throws Exception
	 */

	@ResponseBody
	@PostMapping("/updateSimplMberMyInfoDtl")
	public String updateSimplMberMyInfoDtl(@RequestBody SimplMberMyInfoMngVO simplMberMyInfoMngVO) throws Exception {
		if (userInfoUtil.getAccountInfo() == null) {
			return "F";
		}
		String result = "";
		String mberNo = userInfoUtil.getAccountInfo().getMberNo();
		simplMberMyInfoMngVO.setSimplMberNo(mberNo);
		// SimplMberMyInfoMngVO agreAt =
		// simplMbermyInfoMngService.selectAgreAt(simplMberMyInfoMngVO);

		result = simplMbermyInfoMngService.updateSimplMberMyInfoDtl(mberNo, simplMberMyInfoMngVO);
		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 간편회원 탈퇴 화면
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/deleteSimplMberView")
	public String deleteSimplMberView(Model model) {
		try {
			return "my/simplMberSecsn";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 간편회원 탈퇴
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param simplMberMyInfoMngVO
	 * @return
	 * @throws Exception
	 */

	@PostMapping("/deleteSimplMber")
	@ResponseBody
	public int deleteSimplMber(@RequestBody SimplMberMyInfoMngVO simplMberMyInfoMngVO) throws Exception {

		if (userInfoUtil.getAccountInfo() == null) {
			return 0;
		}

		String simplMberNo = userInfoUtil.getAccountInfo().getMberNo();
		simplMberMyInfoMngVO.setSimplMberNo(simplMberNo);
		int result = simplMbermyInfoMngService.deleteSimplMber(simplMberMyInfoMngVO);
		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 간편회원 탈퇴 완료 화면 출력
	 * </pre>
	 *
	 * @date 2021. 11. 10.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 11. 10.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectSimplMberSecsnEnd")
	public String selectSimplMberSecsnEnd() {
		try {
			return "my/simplMberSecsnEnd";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	// 기능 삭제 - 2021/11/10
	/**
	 * <pre>
	 * 처리내용: 계정 탈퇴 거부 화면 출력
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @return
	 */
//	@RequestMapping("/selectSimplMberSecsnRefuse")
//	public String selectMberSecsnRefuse() {
//		return "my/simplMberSecsnRefuse";
//	}

}
