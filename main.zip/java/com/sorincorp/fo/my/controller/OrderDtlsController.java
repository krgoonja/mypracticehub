package com.sorincorp.fo.my.controller;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.order.model.OrderDtlsClaimVO;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.my.model.BankInfoVO;
import com.sorincorp.fo.my.model.DlivyVO;
import com.sorincorp.fo.my.model.DlvyDetailVO;
import com.sorincorp.fo.my.model.DlvyVO;
import com.sorincorp.fo.my.model.OrderDtlsVO;
import com.sorincorp.fo.my.service.DashboardService;
import com.sorincorp.fo.my.service.OrderDtlsDetailService;
import com.sorincorp.fo.my.service.OrderDtlsService;

import lombok.extern.slf4j.Slf4j;

/**
 * OrderDtlsController.java
 * @version
 * @since 2021. 7. 8.
 * @author srec0048
 */
@Slf4j
@Controller
@RequestMapping("/my/order")
public class OrderDtlsController {

	@Autowired
	private OrderDtlsService orderDtlsService;

	@Autowired
	private OrderDtlsDetailService orderDtlsDetailService;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private DashboardService dashboardService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Value("${dlvy.trace.url}")
	private String dlvyTraceUrl;


	/**
	 * <pre>
	 * 처리내용: 마이페이지 > 주문내역 페이지를 조회한다.
	 * </pre>
	 * @date 2021. 7. 8.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0048			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/orderDtls")
	public String orderDtls(@RequestBody(required = false) String flag, ModelMap model) {
		try {
			// 주문진행상태 공통코드
			Map<String, String> filterCode = commonCodeService.getFilterCode("ORDER_STTUS_CODE", null, "CODE_DCTWO", "Y");
			String commCodeListStr = orderDtlsService.getCommCodeListStr(filterCode);

			// 은행코드 (업체에 포함된 은행코드)
			Map<String, Object> param = Collections.singletonMap("entrpsNo", userInfoUtil.getEntripsNo());
			List<BankInfoVO> listBankCode = dashboardService.selectListEntrpsBank(param);

			// 케이지트레이딩 고객센터 전화번호
			String csTelNo = commonCodeService.getSubCodesRetVo("SORIN_SETUP_CODE", "CS_TEL").get("CS_TEL").getCodeDcone();


			model.addAttribute("sbxOrderSttusCode", commCodeListStr);
			model.addAttribute("listBankCode", listBankCode);
			model.addAttribute("csTelNo", csTelNo);

			// 주문상세에서 주문내역 버튼 클릭 시 flag
			if ("1".equals(flag)) {
				model.addAttribute("flag", flag);
			}

			return "my/orderDtls";

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 마이페이지 > 주문내역 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0048			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectOrderDtlsList")
	@ResponseBody
	public Map<String, Object> selectOrderDtlsList(@RequestBody OrderDtlsVO seachVo) throws Exception {
		Map<String, Object> map = new HashMap<>();

		// 세션정보
		Account account = userInfoUtil.getAccountInfo();
		if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
			throw new Exception("로그인 정보를 확인해주세요.");
		}

		String mberNo = account.getMberNo(); // 회원번호
		String entNo = account.getEntrpsNo(); // 업체번호
		String mberSecode = userInfoUtil.getMemberSecode(); // 권한 구분 코드

		seachVo.setMberNo(mberNo);
		seachVo.setEntrpsNo(entNo);
		seachVo.setMemberSecode(mberSecode);

		// 회원구분코드가 '03'(구매담당)인 경우, 본인이 구매한 주문건만 보임. 그 외는 소속 업체 주문건 모두 조회 가능
		int orderDtlsTotCnt = orderDtlsService.selectOrderDtlsListTotCnt(seachVo);
		List<OrderDtlsVO> orderDtlsList = null;
		if (orderDtlsTotCnt > 0) {
			orderDtlsList = orderDtlsService.selectOrderDtlsList(seachVo);
		}

		map.put("orderDtlsTotCnt", orderDtlsTotCnt);
		map.put("orderDtlsList", orderDtlsList);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 최근 30일 주문내역을 조회한다.
	 * </pre>
	 * @date 2021. 8. 10.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 10.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param orderSttusNm
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/recentOrderDtls")
	public String recentOrderDtls(@RequestBody String orderSttusNm, ModelMap model) {
		try {
			String orderSttusCode = ""; // 주문 상태 코드

			if ("orderCompt".equals(orderSttusNm)) { // 주문완료
				orderSttusCode = "10";
			} else if ("dlvyWait".equals(orderSttusNm)) { // 배송대기
				orderSttusCode = "13";
			} else if ("dlvyPrpare".equals(orderSttusNm)) {// 배송준비
				orderSttusCode = "15";
			} else if ("dlvyDrct".equals(orderSttusNm)) { // 출고지시
				orderSttusCode = "20";
			} else if ("caralcing".equals(orderSttusNm)) { // 배차중
				orderSttusCode = "21";
			} else if ("dlvying".equals(orderSttusNm)) { // 배송중
				orderSttusCode = "22";
			} else if ("dlvyCompt".equals(orderSttusNm)) { // 배송완료
				orderSttusCode = "30";
			} else if ("credt".equals(orderSttusNm)) {
				// 마이페이지 메인에서 결제내역 관련 리스트를 조회하는 파라미터
				orderSttusCode = "";
			}

			// 주문진행상태 공통코드
			Map<String, String> filterCode = commonCodeService.getFilterCode("ORDER_STTUS_CODE", null, "CODE_DCTWO", "Y");
			String commCodeListStr = orderDtlsService.getCommCodeListStr(filterCode);

			// 은행코드 (업체에 포함된 은행코드)
			Map<String, Object> param = Collections.singletonMap("entrpsNo", userInfoUtil.getEntripsNo());
			List<BankInfoVO> listBankCode = dashboardService.selectListEntrpsBank(param);

			// 케이지트레이딩 고객센터 전화번호
			String csTelNo = commonCodeService.getSubCodesRetVo("SORIN_SETUP_CODE", "CS_TEL").get("CS_TEL").getCodeDcone();


			model.addAttribute("sbxOrderSttusCode", commCodeListStr);
			model.addAttribute("orderSttusCode", orderSttusCode);
			model.addAttribute("listBankCode", listBankCode);
			model.addAttribute("csTelNo", csTelNo);

			return "my/orderDtls";

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 배송상세내역을 조회한다.
	 * </pre>
	 * @date 2021. 8. 10.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 10.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectDlvyDetail")
	@ResponseBody
	public Map<String, Object> selectDlvyDetail(@RequestBody Map<String, Object> orderInfo) throws Exception {
		Map<String, Object> map = new HashMap<>();

		String orderNo = (String) orderInfo.get("orderNo"); // 주문번호
		String section = (String) orderInfo.get("section"); // 해당 주문번호에 배송상세 버튼의 최초 클릭인지 아닌지에 대한 구분

		if ("init".equals(section)) { // 초기 배송 상세 정보를 조회할 때 배송차수를 조회한다.
			List<Map<String, Object>> dlvyOdr = orderDtlsService.selectDlvyOdr(orderNo); // 주문번호의 배송차수 모두 조회
			map.put("dlvyOdr", dlvyOdr);
		}

		DlvyDetailVO dlvyDetail = orderDtlsService.selectDlvyDetail(orderInfo); // 배송차수 상세정보 조회

		map.put("dlvyDetail", dlvyDetail);
		map.put("dlvyTraceUrl", dlvyTraceUrl);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 지급확인서 데이터를 조회한다.
	 * </pre>
	 * @date 2022. 10. 21.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 21.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectCanclCnfrmnInfo")
	@ResponseBody
	public OrderDtlsClaimVO selectCanclCnfrmnInfo(@RequestBody OrderDtlsVO vo) throws Exception {
		return orderDtlsService.selectCanclCnfrmnInfo(vo);
	}

	/**
	 * <pre>
	 * 처리내용: 지급확인서 상세 데이터 조회
	 * </pre>
	 * @date 2022. 10. 28.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 28.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectCanclCnfrmnDtl")
	@ResponseBody
	public Map<String, Object> selectCanclCnfrmnDtl(@RequestBody OrderDtlsVO vo) throws Exception {
		Map<String, Object> result = new HashMap<>();

		OrderDtlsClaimVO orderDtlsClaimVO = orderDtlsService.selectCanclCnfrmnDtl(vo);

		result.put("canclCnfrmnDtl", orderDtlsClaimVO);

		if (orderDtlsClaimVO != null && orderDtlsClaimVO.getExcclcDfnnt() < 0) {
			result.put("pcCalcBasis", orderDtlsService.selectPcCalcBasis(orderDtlsClaimVO.getCanclExchngRtngudNo()));
		}

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 매매계약서 데이터를 조회한다.
	 * </pre>
	 * @date 2022. 12. 12.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 12.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param searchVo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectContractsInfo")
	@ResponseBody
	public Map<String, Object> selectOrderDtlsDetail(@RequestBody OrderDtlsVO vo) throws Exception {
		Map<String, Object> result = new HashMap<>();

		OrderDtlsVO contractsInfo = orderDtlsService.selectContractsInfo(vo); // 매매계약서 정보
		DlvyVO dlvrgInfo = orderDtlsDetailService.selectDlvrg(vo.getOrderNo()); // 배송지 정보
		List<DlivyVO> dlivyInfoList = orderDtlsDetailService.selectDlivyList(vo.getOrderNo()); // 출고 정보
		result.put("contractsInfo", contractsInfo);
		result.put("dlvrgInfo", dlvrgInfo);
		result.put("dlivyInfoList", dlivyInfoList);

		return result;
	}
	
	/**
	 * <pre>
	 * 처리내용: 주문 정보를 조회한다.
	 * </pre>
	 * @date 2024. 4. 15.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 4. 15.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectOrderDtls")
	@ResponseBody
	public OrderDtlsVO selectOrderDtls(@RequestBody OrderDtlsVO vo) throws Exception {
		return orderDtlsService.selectOrderDtls(vo);
	}

	/**
	 * <pre>
	 * 평균가 확인 팝업
	 * </pre>
	 * @date 2023. 10. 4.
	 * @author srec0051
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectAvrgPrice")
	@ResponseBody
	public Map<String, Object> selectAvrgPrice(@RequestBody String orderNo) throws Exception {
		Map<String, Object> result = new HashMap<>();

		String html = "";
		result.put("result", html);

		return result;
	}
}
