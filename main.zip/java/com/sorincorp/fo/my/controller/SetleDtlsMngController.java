/**
 *
 */
package com.sorincorp.fo.my.controller;


import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.sqlserver.jdbc.StringUtils;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.service.EntrpsInfoService;
import com.sorincorp.fo.my.model.GrntySummaryDtlVO;
import com.sorincorp.fo.my.model.SetleDtlsMngVO;
import com.sorincorp.fo.my.service.SetleDtlsMngService;

import lombok.extern.slf4j.Slf4j;



/**
 * SetleDtlsMngController.java
 * @version
 * @since 2021. 8. 10.
 * @author srec0073
 */
@Slf4j
@Controller
@RequestMapping("/fo/setleDtlsMng")
public class SetleDtlsMngController {

	@Autowired
	private SetleDtlsMngService setleDtlsMngService;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	EntrpsInfoService entrpsInfoService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	/** 조회기간 기본설정 */
	public SetleDtlsMngVO setDefDate(SetleDtlsMngVO setleDtlsMngVO) {
		//최대 조회기간 6개월
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		// 오늘 날짜
		String endDate = sdf.format(cal.getTime());
		// 조회기간 최대 6개월
		cal.add(cal.MONTH, -6);
		String startDate = sdf.format(cal.getTime());

		setleDtlsMngVO.setStartDate(startDate);
		setleDtlsMngVO.setEndDate(endDate);

		return setleDtlsMngVO;
	}

	/**
	 * <pre>
	 * 처리내용: 결제내역 조회
	 * </pre>
	 * @date 2022. 8. 10.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 10. 		srec0073			최초작성
	 * ------------------------------------------------
	 * @param tabNm(all, eWallet, mrtgg, loan)
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectSetleDtls")
	public String selectSetleDtls(@RequestBody(required=false) Map<String, String> params, ModelMap model) {

		if(userInfoUtil.getAccountInfo() == null) {
			return "error/503";
		}

		try {
			SetleDtlsMngVO setleDtlsMngVO = new SetleDtlsMngVO();
			// 기업정보
			setleDtlsMngVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());

			// 보증 내역 카운트
			int[] grntyListCntList = setleDtlsMngService.getGrntyListCnt(setleDtlsMngVO);
			// 전자상거래보증 사용 여부(내역이 있으면 사용여부 "Y")
			String mrtggGrntyUseAt = grntyListCntList[0] > 0 ? "Y" : "N";
			String cdtlnSvcSeCode = "";
			// 구매자금 사용 여부(내역이 있으면 사용여부 "Y")
			String lonGrntyUseAt = grntyListCntList[1] > 0 ? "Y" : "N";
			// 초기탭 정보
			String tabNm = params != null ? params.get("tabNm") : "";

			if(StringUtils.isEmpty(setleDtlsMngVO.getStartDate())) {
				setDefDate(setleDtlsMngVO);
			}

			// 전자상거래보증 사용 여부가 "Y"인 경우, 여신 구분코드 조회.
			if (mrtggGrntyUseAt == "Y") {
				cdtlnSvcSeCode = setleDtlsMngService.getCdtlnSvcSeCode(setleDtlsMngVO);
			}

			model.addAttribute("mrtggGrntyUseAt", mrtggGrntyUseAt);
			model.addAttribute("lonGrntyUseAt", lonGrntyUseAt);
			model.addAttribute("activeTabNm", tabNm);
		    model.addAttribute("cdtlnSvcSeCode", cdtlnSvcSeCode);

			return "my/setleDtlsMngList";
		} catch(Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}//end try ~ catch()
	}




	/**
	 * <pre>
	 * 처리내용: 결제내역 조회
	 * </pre>
	 * @date 2022. 8. 10.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 10.			srec0073			최초작성
	 * ------------------------------------------------
	 * @param setleDtlsMngVO
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/selectSetleDtlsSearch")
	public ResponseEntity<Object> selectSetleDtlsSearch(@RequestBody(required=false) SetleDtlsMngVO setleDtlsMngVO) throws Exception {

		Map<String, Object> retVal = new HashMap<>();
//		String startDate = "";

		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put("result", "F");
			retVal.put("errMsg", "로그인되지 않은 사용자입니다.");
			retVal.put("setleDtlsList", null);
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		setleDtlsMngVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());

		if(StringUtils.isEmpty(setleDtlsMngVO.getStartDate())) {
			setDefDate(setleDtlsMngVO);
		}

		int totalCnt = setleDtlsMngService.selectSetleDtlsMngTotCnt(setleDtlsMngVO);
		List<SetleDtlsMngVO> setleDtlsList = setleDtlsMngService.selectSetleDtlsMng(setleDtlsMngVO);

		retVal.put("result", "S");
		retVal.put("errMsg", "");
		retVal.put("totalCnt", totalCnt);
		retVal.put("setleDtlsList", setleDtlsList);

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 결제내역 엑셀 다운
	 * </pre>
	 * @date 2022. 8. 10.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 10.		 	srec0073			최초작성
	 * ------------------------------------------------
	 * @param setleDtlsMngVO
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/excel")
	public ResponseEntity<Object> downloadExcel(HttpServletResponse response, HttpServletRequest request, SetleDtlsMngVO setleDtlsMngVO) throws Exception{

		Map<String, Object> retVal = new HashMap<>();
		ObjectMapper mapper = new ObjectMapper();

		// submit으로 받아온 정열정보(컬럼, 정렬순서) 매핑.
		String srchSortInfoJson = setleDtlsMngVO.getSrchSortInfoForExcel().replaceAll("&quot;", "\"");
		Map<String, Object> srchSortInfoMap = mapper.readValue(srchSortInfoJson, Map.class);
		setleDtlsMngVO.setSrchSortInfo(srchSortInfoMap);

		// 여신 구분 코드
		String cdtlnSvcSeCode = setleDtlsMngVO.getCdtlnSvcSeCode() == null ? "01" : setleDtlsMngVO.getCdtlnSvcSeCode();

		int rowNo = 0;

		Date nowDate = new Date();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd"); //원하는 데이터 포맷 지정
		String regDate = simpleDateFormat.format(nowDate); //지정한 포맷으로 변환

		// 로그인 체크
		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put("result", "F");
			retVal.put("errMsg", "로그인되지 않은 사용자입니다.");
			retVal.put("setleDtlsList", null);
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		// 업체명
		String entrpsNmKorean = "";

		// 기업정보
		String entrpsNo = userInfoUtil.getAccountInfo().getEntrpsNo();
		setleDtlsMngVO.setEntrpsNo(entrpsNo);
		if(entrpsInfoService.selectAccountEntrpsInfo(entrpsNo) != null) {
			entrpsNmKorean = entrpsInfoService.selectAccountEntrpsInfo(entrpsNo).getEntrpsnmKorean();//기업명
		}

		// 조회기간
		if(StringUtils.isEmpty(setleDtlsMngVO.getStartDate())) {
			setDefDate(setleDtlsMngVO);
		}

		//결제내역 리스트
		List<SetleDtlsMngVO> setleDtlsList = setleDtlsMngService.selectSetleDtlsMng(setleDtlsMngVO);
		retVal.put("result", "S");
		retVal.put("errMsg", "");
		retVal.put("setleDtlsList", setleDtlsList);

		// 조회한 탭 이름
		String tabNm = setleDtlsMngVO.getTabNm();

		// 거래수단별로 다른 템플릿을 사용
		String sheetNm = "전체_거래내역";
		int[] colWidth = new int[]{5000, 5000, 3500, 4000, 4000, 4000, 5000};
		switch (tabNm) {
		case "e-Wallet":
			sheetNm = "가상계좌_거래내역";
			colWidth = new int[]{5000, 3500, 4000, 4000, 4000, 5000, 5000};
			break;
		case "전자상거래보증":
			if ("01".equals(cdtlnSvcSeCode)) {
				sheetNm = "전자상거래보증_거래내역";
			} else {
				sheetNm = "케이지크레딧_거래내역";
			}
			colWidth = new int[]{5000, 3500, 4000, 4000, 4000, 5000, 5000};
			break;
		case "구매자금":
			sheetNm = "구매자금_거래내역";
			colWidth = new int[]{5000, 3500, 4000, 4000, 5000, 5000};
			break;
		}

		// 파일명
		String fileName = entrpsNmKorean+"_"+regDate+"_"+sheetNm;
		fileName = URLEncoder.encode(fileName,"UTF-8");

		Workbook workbook = new HSSFWorkbook();					//엑셀 파일 생성
		Sheet sheet = workbook.createSheet(sheetNm);			//엑셀 시트 생성
		String[] titleArr = setleDtlsMngVO.getTitleArr();		//엑셀 타이틀 지정

		////엑셀 스타일
		CellStyle headStyle = workbook.createCellStyle();
		headStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.GREY_25_PERCENT.getIndex());		//헤더폰트색상
		headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		headStyle.setAlignment(HorizontalAlignment.CENTER);
		headStyle.setBorderTop(BorderStyle.THIN);
		headStyle.setBorderBottom(BorderStyle.THIN); 													// 셀 아래 테두리 실선 적용

		Font headerFont = workbook.createFont();
		Font rowFont = workbook.createFont();
		headerFont.setFontHeightInPoints((short) 12);
		headerFont.setBold(true);
		rowFont.setFontHeightInPoints((short) 11);
		headStyle.setFont(headerFont);

		CellStyle rowStyle = workbook.createCellStyle();
		DataFormat format = workbook.createDataFormat();
		rowStyle.setAlignment(HorizontalAlignment.CENTER);

		CellStyle rowStyle2 = workbook.createCellStyle();
		rowStyle2.setAlignment(HorizontalAlignment.RIGHT);

		CellStyle rowStyle3 = workbook.createCellStyle();
		rowStyle3.setAlignment(HorizontalAlignment.RIGHT);

		rowStyle.setFont(rowFont);

		Row headerRow = sheet.createRow(rowNo++);

		for (int i=0; i<titleArr.length; i++){
			headerRow.createCell(i).setCellValue(titleArr[i]);						//헤더 셀 생성
			headerRow.getCell(i).setCellStyle(headStyle);							//헤더 스타일 적용
			headerRow.setHeight((short)330);

			sheet.setColumnWidth(i, colWidth[i]);
		}

		// 거래수단별 엑셀 row 생성
		for (SetleDtlsMngVO setleDtl : setleDtlsList) {
			Row row = sheet.createRow(rowNo++);
			switch (tabNm) {
			case "e-Wallet":
				row.createCell(0).setCellValue(setleDtl.getDelngDt());			        //거래일자
				row.createCell(1).setCellValue(setleDtl.getDelngSe());          		//유형
				if (setleDtl.getDelngSeCode().equals("01") || setleDtl.getDelngSeCode().equals("04") || setleDtl.getDelngSeCode().equals("05") || setleDtl.getDelngSeCode().equals("07") || setleDtl.getDelngSeCode().equals("09")) {
					row.createCell(2).setCellValue("");	                                //입금
					row.createCell(3).setCellValue(setleDtl.getDelngAmount());		    //출금
				} else {
					row.createCell(2).setCellValue(setleDtl.getDelngAmount());	        //입금
					row.createCell(3).setCellValue("");                                 //출금
				}
				row.createCell(4).setCellValue(setleDtl.getBlce());     				//잔액
				row.createCell(5).setCellValue(setleDtl.getOrderNo());					//주문번호
				row.createCell(6).setCellValue(setleDtl.getSumry());				    //적요

				row.getCell(0).setCellStyle(rowStyle);
				row.getCell(1).setCellStyle(rowStyle);
				row.getCell(2).setCellStyle(rowStyle2);
				row.getCell(3).setCellStyle(rowStyle2);
				row.getCell(4).setCellStyle(rowStyle2);
				row.getCell(5).setCellStyle(rowStyle);
				row.getCell(6).setCellStyle(rowStyle);
				break;
			case "전자상거래보증":
				row.createCell(0).setCellValue(setleDtl.getDelngDt());			        //거래일자
				row.createCell(1).setCellValue(setleDtl.getDelngSe());          		//유형
				if (setleDtl.getDelngSeCode().equals("01") || setleDtl.getDelngSeCode().equals("03") || setleDtl.getDelngSeCode().equals("04") || setleDtl.getDelngSeCode().equals("06")) {
					row.createCell(2).setCellValue("");	                                //사용
					row.createCell(3).setCellValue(setleDtl.getDelngAmount());          //충전(상환)
				} else {
					row.createCell(2).setCellValue(setleDtl.getDelngAmount());	        //사용
					row.createCell(3).setCellValue("");                                 //충전(상환)
				}
				row.createCell(4).setCellValue(setleDtl.getBlce());     				//잔액
				row.createCell(5).setCellValue(setleDtl.getOrderNo());					//주문번호
				row.createCell(6).setCellValue(setleDtl.getSumry());				    //적요

				row.getCell(0).setCellStyle(rowStyle);
				row.getCell(1).setCellStyle(rowStyle);
				row.getCell(2).setCellStyle(rowStyle2);
				row.getCell(3).setCellStyle(rowStyle2);
				row.getCell(4).setCellStyle(rowStyle2);
				row.getCell(5).setCellStyle(rowStyle);
				row.getCell(6).setCellStyle(rowStyle);
				break;
			case "구매자금":
				row.createCell(0).setCellValue(setleDtl.getDelngDt());			        //거래일자
				row.createCell(1).setCellValue(setleDtl.getDelngSe());					//유형
				row.createCell(2).setCellValue(setleDtl.getBankNm());					//은행명
				row.createCell(3).setCellValue(setleDtl.getDelngAmount());				//금액
				row.createCell(4).setCellValue(setleDtl.getOrderNo());					//주문번호
				row.createCell(5).setCellValue(setleDtl.getSumry());					//적요

				row.getCell(0).setCellStyle(rowStyle);
				row.getCell(1).setCellStyle(rowStyle);
				row.getCell(2).setCellStyle(rowStyle);
				row.getCell(3).setCellStyle(rowStyle2);
				row.getCell(4).setCellStyle(rowStyle);
				row.getCell(5).setCellStyle(rowStyle);
				break;
			default:
				row.createCell(0).setCellValue(setleDtl.getDelngDt());			        //거래일자
				row.createCell(1).setCellValue(setleDtl.getOrderNo());		            //주문번호
				row.createCell(2).setCellValue(setleDtl.getDelngSe());		            //유형
				row.createCell(3).setCellValue(setleDtl.getSetleMthd());				//결제방식
				row.createCell(4).setCellValue(setleDtl.getSetleMn());					//결제수단
				row.createCell(5).setCellValue(setleDtl.getDelngAmount());				//금액
				row.createCell(6).setCellValue(setleDtl.getSumry());				    //적요

				row.getCell(0).setCellStyle(rowStyle);
				row.getCell(1).setCellStyle(rowStyle);
				row.getCell(2).setCellStyle(rowStyle);
				row.getCell(3).setCellStyle(rowStyle);
				row.getCell(4).setCellStyle(rowStyle);
				row.getCell(5).setCellStyle(rowStyle2);
				row.getCell(6).setCellStyle(rowStyle);
				break;
			}
			row.setHeight((short)300);
		}

		response.setContentType("ms-vnd/excel");
		response.setHeader("Content-Disposition", "attachment;filename="+fileName+".xls");

		workbook.write(response.getOutputStream());
		workbook.close();

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}


	/**
	 * <pre>
	 * 처리내용: 전자상거래보증 보증번호 조회
	 * </pre>
	 * @date 2022. 08. 17.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 08. 17.		srec0073			최초작성
	 * ------------------------------------------------
	 * @param setleDtlsMngVO
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/selectGrntyNoListAjax")
	public ResponseEntity<Object> selectGrntyNoListAjax() throws Exception {
		Map<String, Object> retVal = new HashMap<>();
		List<Map<String, Object>> grntyNoList = new ArrayList<>();
		SetleDtlsMngVO setleDtlsMngVO = new SetleDtlsMngVO();

		// 로그인 체크
		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put("result", "F");
			retVal.put("errMsg", "로그인되지 않은 사용자입니다.");
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		// 기업정보
		setleDtlsMngVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());

		// 업체의 전자상거래보증 리스트 조회
		grntyNoList = setleDtlsMngService.selectGrntyNoList(setleDtlsMngVO);

		retVal.put("result", "S");
		retVal.put("errMsg", "");
		retVal.put("grntyNoList", grntyNoList);

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 전자상거래보증 요약정보 조회
	 * </pre>
	 * @date 2022. 08. 17.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 08. 17.		srec0073			최초작성
	 * ------------------------------------------------
	 * @param setleDtlsMngVO
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/selectGrntySummaryAjax")
	public ResponseEntity<Object> selectGrntySummaryAjax(@RequestBody SetleDtlsMngVO setleDtlsMngVO) throws Exception {
		Map<String, Object> retVal = new HashMap<>();
		SetleDtlsMngVO grntySummary = new SetleDtlsMngVO();
		GrntySummaryDtlVO grntySummaryDtl = new GrntySummaryDtlVO();

		// 로그인 체크
		if(userInfoUtil.getAccountInfo() == null) {
			retVal.put("result", "F");
			retVal.put("errMsg", "로그인되지 않은 사용자입니다.");
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		}

		// 기업정보
		setleDtlsMngVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());

		// 전자상거래 보증번호의 요약정보 조회
		grntySummary = setleDtlsMngService.selectGrntySummary(setleDtlsMngVO);

		if (!StringUtils.isEmpty(setleDtlsMngVO.getGrntyNo()) && "01".equals(grntySummary.getCdtlnSvcSeCode())) {
			// 전자상거래 보증번호의 상세 요약정보 조회
			grntySummaryDtl = setleDtlsMngService.selectGrntySummaryDtl(setleDtlsMngVO);
		} else {
			grntySummaryDtl = null;
		}

		retVal.put("result", "S");
		retVal.put("errMsg", "");
		retVal.put("grntySummary", grntySummary);
		retVal.put("grntySummaryDtl", grntySummaryDtl);

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 구매자금 조회조건 은행리스트 조회
	 * </pre>
	 * @date 2022. 08. 17.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 08. 17.		srec0073			최초작성
	 * ------------------------------------------------
	 * @param setleDtlsMngVO
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/selectBankListAjax")
	public ResponseEntity<Object> selectBankListAjax() throws Exception {
		Map<String, Object> retVal = new HashMap<>();
		Map<String, String> bankList = commonCodeService.getFilterCode("BANK_CODE", null, null, null);
		retVal.put("result", "S");
		retVal.put("errMsg", "");
		retVal.put("bankList", bankList);
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 결제수단별 결제유형 조회조건 리스트 조회
	 * </pre>
	 * @date 2022. 08. 17.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 08. 17.		srec0073			최초작성
	 * ------------------------------------------------
	 * @param setleDtlsMngVO
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/selectSetleTypeDtlAjax")
	public ResponseEntity<Object> selectSetleTypeDtlAjax() throws Exception {
		Map<String, Object> retVal = new HashMap<>();
		Map<String, String> delngSeCode = new HashMap<String, String>();
		// 이월렛 거래구분 코드 조회.
		Map<String, CommonCodeVO> ewalletDelngSeCode = commonCodeService.getFilterCodeRetVo("EWALLET_DELNG_SE_CODE", null, "CODE_REFRNONE", "Y");
		ewalletDelngSeCode.forEach((key, value) -> {
			delngSeCode.put(value.getSubCode(), value.getCodeChrctrRefrnone());
		});
		// 담보 거래유형 코드 조회.
		Map<String, String> mrtggDelngTyCode = commonCodeService.getFilterCode("MRTGG_DELNG_TY_CODE", null, null, null);
		// 대출 거래유형 코드 조회.
		Map<String, String> lonDelngTyCode = commonCodeService.getFilterCode("LON_DELNG_TY_CODE", null, null, null);
		retVal.put("result", "S");
		retVal.put("errMsg", "");
		retVal.put("ewalletDelngSeCode", delngSeCode);
		retVal.put("mrtggDelngTyCode", mrtggDelngTyCode);
		retVal.put("lonDelngTyCode", lonDelngTyCode);
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
}
