package com.sorincorp.fo.my.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.mb.model.MbEntrpsGradVO;
import com.sorincorp.fo.mb.service.MbCmnGradService;
import com.sorincorp.fo.my.model.BankInfoVO;
import com.sorincorp.fo.my.model.DashboardVO;
import com.sorincorp.fo.my.model.InqryDtlsVO;
import com.sorincorp.fo.my.model.OrPcChangegldBasVO;
import com.sorincorp.fo.my.model.PaytEsamtVO;
import com.sorincorp.fo.my.model.SetleDtlsDetailVO;
import com.sorincorp.fo.my.model.SimplMberMyInfoMngVO;
import com.sorincorp.fo.my.service.DashboardService;
import com.sorincorp.fo.my.service.SimplMberMyInfoMngService;

import lombok.extern.slf4j.Slf4j;

/**
 * DashboardController.java
 *
 * @version
 * @since 2021. 9. 14.
 * @author srec0048
 */
@Slf4j
@Controller
@RequestMapping("/my/mypage")
public class DashboardController {

	@Autowired
	private DashboardService dashboardService;
	@Autowired
	private SimplMberMyInfoMngService simplMbermyInfoMngService;
	@Autowired
	private UserInfoUtil userInfoUtil;
	@Autowired
	private CommonCodeService commonCodeService;
	@Autowired
	private MbCmnGradService mbCmnGradService;
	@Autowired
	private ObjectMapper objectMapper;


	private Account getAccountInfo() throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		if (null == account || StringUtil.isBlank(account.getMberNo())) {
			throw new Exception("로그인 정보를 확인해주세요.");
		}
		return account;
	}

	/**
	 * <pre>
	 * 처리내용: 마이페이지 대시보드를 조회한다.
	 * </pre>
	 *
	 * @date 2021. 7. 27.
	 * @author srec0048
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 27.
	 *          srec0048 최초작성 ------------------------------------------------
	 * @param seachVo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/dashboard")
	public String dashboard(DashboardVO seachVo, ModelMap model) {
		log.debug(seachVo.toString());

		try {
			Map<String, Object> param = new HashMap<>();
			Account account = getAccountInfo(); // 세션정보
			String mberNo = StringUtil.nvl(account.getMberNo()); // 회원번호
			String entrpsNo = StringUtil.nvl(account.getEntrpsNo()); // 업체번호
			String memberSecode = StringUtil.nvl(userInfoUtil.getMemberSecode()); // 권한 구분 코드
			String mberType = StringUtil.nvl(userInfoUtil.getType());
			String dashboardUrl = null;

			List<InqryDtlsVO> recentInqryAnswer = null;

			param.put("mberNo", mberNo);
			param.put("entrpsNo", entrpsNo);
			param.put("memberSecode", memberSecode);
			param.put("mberType", mberType);

			if ("01".equals(mberType)) {
				// 최근 30일 거래내역, 상단 대시보드 주문현황
				DashboardVO recentOrderDtls = dashboardService.selectRecentOrderDtls(param);
				// 최근 24시간 내 3개 알림 내역
				List<DashboardVO> recentNtcn = dashboardService.selectRecentNtcn(entrpsNo);
				// 최근 7일내 3개 문의/답변 내역
				recentInqryAnswer = dashboardService.selectRecentInqryAnswer(param);
				// 결제내역 목록
				List<PaytEsamtVO> listUnSetleAmountDtl = dashboardService.selectListUnSetleAmountDtl(param);
				String jsonUnSetleAmountDtl = objectMapper.writeValueAsString(listUnSetleAmountDtl);
				// 은행코드 (업체에 포함된 은행코드)
				List<BankInfoVO> listBankCode = dashboardService.selectListEntrpsBank(param);
				// 케이지트레이딩 고객센터 전화번호
				Map<String, CommonCodeVO> csTelNo = commonCodeService.getSubCodesRetVo("SORIN_SETUP_CODE", "CS_TEL");

				model.addAttribute("recentOrderDtls", recentOrderDtls);
				model.addAttribute("recentNtcn", recentNtcn);
				model.addAttribute("listUnSetleAmountDtl", listUnSetleAmountDtl);
				model.addAttribute("jsonUnSetleAmountDtl", jsonUnSetleAmountDtl);
				model.addAttribute("listBankCode", listBankCode);
				model.addAttribute("csTel", csTelNo.get("CS_TEL").getCodeDcone());

				dashboardUrl = "my/dashboard";

			} else if ("02".equals(mberType)) {
				// 최근 7일내 3개 문의/답변 내역
				recentInqryAnswer = dashboardService.selectRecentInqryAnswer(param);

				dashboardUrl = "my/simplMberDashboard";
			}

			model.addAttribute("mberType", mberType);
			model.addAttribute("recentInqryAnswer", recentInqryAnswer); // 3개 문의/답변 내역

			return dashboardUrl;

		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 대시보드 상단 회원정보, 결제수단, 주문현황을 조회한다.
	 * </pre>
	 *
	 * @date 2021. 9. 14.
	 * @author srec0048
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 14.
	 *          srec0048 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectDashboardTop")
	public String selectDashboardTop(ModelMap model) {
		try {
			Map<String, Object> param = new HashMap<>();
			Account account = getAccountInfo(); // 세션정보
			String mberNo = account.getMberNo(); // 회원번호
			String entrpsNo = StringUtil.nvl(account.getEntrpsNo()); // 업체번호
			String memberSecode = StringUtil.nvl(userInfoUtil.getMemberSecode()); // 권한 구분 코드
			String mberType = StringUtil.nvl(userInfoUtil.getType());
			String entrpsMnbyPurchsBnef = StringUtil.nvl(account.getEntrpsMnbyPurchsBnef());
			String entrpsPayBackDscnt = StringUtil.nvl(account.getEntrpsPayBackDscnt());
			String entrpsMnbyPurchsBnefUseAt = account.getEntrpsMnbyPurchsBnefUseAt();
			String entrpsPayBackDscntUseAt = account.getEntrpsPayBackDscntUseAt();

			// 20220812 srec0030 회원등급 산정안내 팝업 추가
			int gradCalcSn = 0;
			int entrpsGradSn = 0;

			param.put("mberNo", mberNo);
			param.put("entrpsNo", entrpsNo);
			param.put("memberSecode", memberSecode);
			
			/* 페이백 기능 추가 2024/02/14 */
			//회원_업체 등급 기준 구매 수량
			MbEntrpsGradVO mbEntrpsGradStdrPurchsQy = dashboardService.selectMbEntrpsGradStdrPurchsQy();
			model.addAttribute("mbEntrpsGradStdrPurchsQy", mbEntrpsGradStdrPurchsQy);
			//등급 할인 금액 리스트
			List<MbEntrpsGradVO> mbGradDscntAmountList = dashboardService.selectMbGradDscntAmountList();
			model.addAttribute("mbGradDscntAmountList", mbGradDscntAmountList);
			//당월 구매 수량
			int totRealOrderWtSum = dashboardService.selectMbTotRealOrderWtSum(entrpsNo);
			model.addAttribute("totRealOrderWtSum", totRealOrderWtSum);
			//전월 기준 구매 정보(MB_ENTRPS_MNBY_PURCHS_BNEF_BAS)
			MbEntrpsGradVO mbEntrpsMnbyPurchsInfo = dashboardService.mbEntrpsMnbyPurchsInfo(entrpsNo);
			model.addAttribute("mbEntrpsMnbyPurchsInfo", mbEntrpsMnbyPurchsInfo);
			//상시 할인 금액 리스트(3000,4000,5000)
			List<MbEntrpsGradVO> cpAtmcIsuCouponInfoList= dashboardService.selectcpAtmcIsuCouponInfoList();
			model.addAttribute("cpAtmcIsuCouponInfoList", cpAtmcIsuCouponInfoList);
			/* 페이백 기능 추가 끝 */
			
			if ("01".equals(mberType)) {
				// 2022.11 담보 케이지크레딧 추가
				// 상단 대시보드 결제수단
				Map<String, Object> setleMnInfo = dashboardService.selectSetleMnInfo(entrpsNo);
				// 결제예정액
				Map<String, Object> unSetleAmountInfo = dashboardService.selectUnSetleAmount(param);

				model.addAttribute("setleMnInfo", setleMnInfo);
				model.addAttribute("unSetleAmountInfo", unSetleAmountInfo);

				// 20220812 srec0030 회원등급 산정안내 팝업 추가
				model.addAttribute("entrpsNo", entrpsNo);
				// 회원등급 산정 데이터 조회
				MbEntrpsGradVO gradCalcDtlVO = mbCmnGradService.selectMbEntrpsGradCalcDtl(entrpsNo);
				// 케이지트레이딩 고객센터 전화번호
                Map<String, CommonCodeVO> csTelNo = commonCodeService.getSubCodesRetVo("SORIN_SETUP_CODE", "CS_TEL");
                model.addAttribute("csTel", csTelNo.get("CS_TEL").getCodeDcone());

				List<MbEntrpsGradVO> mbEntrpsGradManageDtlList = null;

				if (gradCalcDtlVO != null) {
					gradCalcSn = gradCalcDtlVO.getGradCalcSn();
					if (gradCalcSn > 0) {
						mbEntrpsGradManageDtlList = mbCmnGradService.selectMbEntrpsGradManageDtlList(gradCalcSn);
					}
				}

				MbEntrpsGradVO mbEntrpsGradMetalAcctoManageDtlVO = mbCmnGradService.selectMbEntrpsGradMetalAcctoManageDtl(entrpsNo);
				List<MbEntrpsGradVO> mbEntrpsGradMetalAcctoManageDtlList = null;

				if (mbEntrpsGradMetalAcctoManageDtlVO != null) {
					entrpsGradSn = mbEntrpsGradMetalAcctoManageDtlVO.getEntrpsGradSn();

					if (entrpsGradSn > 0) {
						mbEntrpsGradMetalAcctoManageDtlList = mbCmnGradService.selectMbEntrpsGradMetalAcctoManageDtlList(entrpsGradSn);
					}
				}

				model.addAttribute("gradCalcSn", gradCalcSn);
				model.addAttribute("gradCalcDtlVO", gradCalcDtlVO);
				model.addAttribute("mbEntrpsGradManageDtlList", mbEntrpsGradManageDtlList);
				model.addAttribute("mbEntrpsGradMetalAcctoManageDtlVO", mbEntrpsGradMetalAcctoManageDtlVO);
				model.addAttribute("mbEntrpsGradMetalAcctoManageDtlList", mbEntrpsGradMetalAcctoManageDtlList);
				model.addAttribute("entrpsMnbyPurchsBnef", entrpsMnbyPurchsBnef);
				model.addAttribute("entrpsPayBackDscnt", entrpsPayBackDscnt);
				model.addAttribute("entrpsMnbyPurchsBnefUseAt", entrpsMnbyPurchsBnefUseAt);
				model.addAttribute("entrpsPayBackDscntUseAt", entrpsPayBackDscntUseAt);

			} else if ("02".equals(mberType)) {
				// 상단 대시보드 간편회원정보
				SimplMberMyInfoMngVO simplMberMyInfoMngVO = simplMbermyInfoMngService.selectSimplMberInfo(mberNo);

				model.addAttribute("setleSimpleMnInfo", simplMberMyInfoMngVO);
			}

			model.addAttribute("mberType", mberType);
			model.addAttribute("mberSeCode", memberSecode);

			return "my/dashboardTop";

		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 결제수단 e-wallet금액을 새로고침한다.
	 * </pre>
	 *
	 * @date 2021. 9. 23.
	 * @author srec0048
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 23.
	 *          srec0048 최초작성 ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectSetleMnInfo")
	@ResponseBody
	public Map<String, Object> selectSetleMnInfo(@RequestBody String flag) throws Exception {
		Account account = getAccountInfo(); // 세션정보
		String entrpsNo = StringUtil.nvl(account.getEntrpsNo()); // 업체번호
		// 상단 대시보드 결제수단
		Map<String, Object> setleMnInfo = dashboardService.selectSetleMnInfo(entrpsNo);

		Map<String, Object> map = new HashMap<>();
		map.put("setleMnInfo", setleMnInfo);
		map.put("flag", flag); // 클릭 버튼 구분 flag

		return map;
	}

	/**
	 * <pre>
	 * 출금(상환)요청 전, 예수금(지정가주문)을 체크<br>
	 * 마이페이지 출금, 마이페이지 홈 상환, 주문목록 상환, 주문상세 상환 공통으로 사용하므로 수정시 주의
	 * </pre>
	 * @date 2023. 5. 16.
	 * @author srec0051
	 * @param params {refndRequstAmount: 요청금액, type: 출금 or 상환}
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertRefundRequst/before")
	@ResponseBody
	public Map<String, Object> validFinalBlce(@RequestBody Map<String, Object> params) throws Exception {
		Account account = getAccountInfo(); // 세션정보
		params.put("mberId", StringUtil.nvl(account.getId())); // 회원id
		params.put("entrpsNo", StringUtil.nvl(account.getEntrpsNo())); // 업체번호

		return dashboardService.createRefundRequstBefore(params);
	}

	/**
	 * <pre>
	 * 출금요청
	 * </pre>
	 *
	 * @date 2021. 10. 26.
	 * @author srec0048
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 10. 26.
	 *          srec0048 최초작성 ------------------------------------------------
	 * @param orderInfo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertRefundRequst")
	@ResponseBody
	public Map<String, Object> insertRefundRequst(@RequestBody Map<String, Object> refundRequstInfo) throws Exception {
		Account account = getAccountInfo(); // 세션정보

		refundRequstInfo.put("mberId", StringUtil.nvl(account.getId())); // 회원id
		refundRequstInfo.put("entrpsNo", StringUtil.nvl(account.getEntrpsNo())); // 업체번호

		return dashboardService.createRefundRequst(refundRequstInfo);
	}

	/**
	 * <pre>
	 * 결제 내역 상세 목록 조회
	 * </pre>
	 * @date 2022. 8. 2.
	 * @author srec0051
	 * @param paramVo
	 * @return
	 * @throws Exception
	 * @history 2024. 1. 2. 고도화 평균가로 수정
	 */
	@PostMapping("/setleDtlsList")
	@ResponseBody
	public List<SetleDtlsDetailVO> setleDtlsList(@RequestBody SetleDtlsDetailVO paramVo) throws Exception {

		Account account = getAccountInfo(); // 세션정보
		paramVo.setMberNo(StringUtil.nvl(account.getId()));
		paramVo.setEntrpsNo(StringUtil.nvl(account.getEntrpsNo()));
		
		return dashboardService.setleDtlsList(paramVo);
	}

	@RequestMapping("/ewalletDefrayRequestForPcChangegld")
	@ResponseBody
	public Map<String, Object> ewalletDefrayRequestForPcChangegld(@RequestBody OrPcChangegldBasVO defrayRequstInfo) throws Exception {
		Account account = getAccountInfo(); // 세션정보

		defrayRequstInfo.setMberId(StringUtil.nvl(account.getId())); // 회원id
		defrayRequstInfo.setEntrpsNo(StringUtil.nvl(account.getEntrpsNo())); // 업체번호

		return dashboardService.doEwalletDefrayRequestForPcChangegld(defrayRequstInfo);
	}
}
