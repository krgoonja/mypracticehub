/**
 *
 */
package com.sorincorp.fo.my.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.model.MbCmnCodeVO;
import com.sorincorp.fo.mb.service.MbCmnCodeService;
import com.sorincorp.fo.mb.service.NiceSelfCrtfctService;
import com.sorincorp.fo.mb.service.SimplMberEtrService;
import com.sorincorp.fo.my.model.MyInfoMngVO;
import com.sorincorp.fo.my.service.MyInfoMngService;

import lombok.extern.slf4j.Slf4j;

/**
 * MyInfoMngController.java
 *
 * @version
 * @since 2021. 8. 23.
 * @author srec0009
 */
@Slf4j
@Controller
@RequestMapping("/fo/myPage")
public class MyInfoMngController {

	@Autowired
	private MyInfoMngService myInfoMngService;

	@Autowired
	private SimplMberEtrService simplMberEtrService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private NiceSelfCrtfctService niceSelfCrtfctService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	/**
	 * <pre>
	 * 처리내용: 대시보드 > 내정보관리(비밀번호 확인)
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectMyInfoMng")
	public String selectMyInfoMng(ModelMap model) {
		try {
			model.addAttribute("mberSeCode", userInfoUtil.getMemberSecode());
			return "my/myInfoMng";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 비밀번호 확인
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param mberSecretNo
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/selectChkPw")
	public String selectChkPw(@RequestBody String mberSecretNo) throws Exception {
		if (userInfoUtil.getAccountInfo() == null) {
			return "F";
		}
		String result = "";
		// 로그인 세션에서 회원 번호
		log.debug("mberSecretNo :: " + mberSecretNo);
		String mberNo = userInfoUtil.getAccountInfo().getMberNo();
		log.debug("mberNo" + mberNo);
		result = myInfoMngService.selectChkPw(mberNo, mberSecretNo);
		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 대시보드 > 내정보관리(상세)
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param session
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectMyInfoMngDtl")
	public String selectMyInfoMngDtl(HttpSession session, ModelMap model) {
		try {
			List<MbCmnCodeVO> domainList = mbCmnCodeService.selectCmnCodeList("EMAIL_DOMAIN");
			model.addAttribute("domainList", domainList);

			Map<Object, Object> map = niceSelfCrtfctService.niceSelfCrtfct(session, "myInfo");
			model.addAttribute("sEncData", map.get("sEncData"));

			List<EntrpsEtrVO> stplatList = simplMberEtrService.selectEntrpsEtrStplat();

			String mberNo = userInfoUtil.getAccountInfo().getMberNo();
			MyInfoMngVO myInfoMngVO = myInfoMngService.selectMyInfoMngDtl(mberNo);
			model.addAttribute("myInfoMngVO", myInfoMngVO);
			model.addAttribute("mberSeCode", userInfoUtil.getMemberSecode());
			model.addAttribute("stplatList", stplatList);
			return "my/myInfoMngDtl";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param mberSecretNo
	 * @return
	 * @throws Exception
	 */
	@ResponseBody

	@PostMapping("/updateNewPw")
	public String updateNewPw(@RequestBody String mberSecretNo) throws Exception {
		String result = "";
		String mberNo = userInfoUtil.getAccountInfo().getMberNo();
		result = myInfoMngService.updateNewPw(mberNo, mberSecretNo);
		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 마이페이지 >  정보 수정
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param myInfoMngVO
	 * @return
	 * @throws Exception
	 */
	@ResponseBody

	@PostMapping("/updateMyInfoDtl")
	public String updateMyInfoDtl(@RequestBody MyInfoMngVO myInfoMngVO) throws Exception {
		if (userInfoUtil.getAccountInfo() == null) {
			return "F";
		}
		String result = "";
		String mberNo = userInfoUtil.getAccountInfo().getMberNo();
		myInfoMngVO.setMberNo(mberNo);

		// 동의 여부 날짜 update 막기 위해
		MyInfoMngVO agreAt = myInfoMngService.selectAgreAt(myInfoMngVO);

		result = myInfoMngService.updateMyInfoDtl(mberNo, myInfoMngVO);

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 회원사 회원 탈퇴 화면
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @return
	 */
	@RequestMapping("/deleteEntrpsMberView")
	public String deleteEntrpsMberView() {
		try {
			return "my/entrpsSecsn";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 회원사 회원 탈퇴
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param myInfoMngVO
	 * @return
	 * @throws Exception
	 */

	@RequestMapping("/deleteEntrpsMber")
	@ResponseBody
	public String deleteEntrpsMber(@RequestBody MyInfoMngVO myInfoMngVO) throws Exception {
		if (userInfoUtil.getAccountInfo() == null) {
			return "Error";
		}
		String entrpsNo = userInfoUtil.getAccountInfo().getEntrpsNo();
		myInfoMngVO.setEntrpsNo(entrpsNo);
		String result = myInfoMngService.deleteEntrpsMber(myInfoMngVO);
		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 회원사 회원 탈퇴 "신청" 완료 화면
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param myInfoMngVO
	 * @return
	 */
	@RequestMapping("/deleteEntrpsMberEnd")
	public String deleteEntrpsMberEnd() {
		try {
			return "my/entrpsSecsnEnd";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 회원 탈퇴 화면
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @return
	 */
	@RequestMapping("/deleteMberView")
	public String deleteMberView() {
		try {
			return "my/mberSecsn";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * 처리내용: 회원 탈퇴
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param myInfoMngVO
	 * @return
	 * @throws Exception
	 */

	@RequestMapping("/deleteMber")
	@ResponseBody
	public String deleteMber(@RequestBody MyInfoMngVO myInfoMngVO) throws Exception {
		String mberNo = userInfoUtil.getAccountInfo().getMberNo();
		myInfoMngVO.setMberNo(mberNo);
		String result = myInfoMngService.deleteMber(myInfoMngVO);
		return result;
	}

	@RequestMapping("/deleteMberEnd")
	public String deleteMberEnd() {
		try {
			return "my/mberSecsnEnd";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 계정 탈퇴 거부 화면 출력
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @return
	 */
	@RequestMapping("/selectMberSecsnRefuse")
	public String selectMberSecsnRefuse(ModelMap model) {

		String secsnPossCodeNm = "";
		String mberNo = "";

		try {

			if (userInfoUtil.getAccountInfo() != null) {
				mberNo = userInfoUtil.getAccountInfo().getMberNo();
				secsnPossCodeNm = myInfoMngService.selectSecsnPossCodeNm(mberNo);
			}

			model.addAttribute("secsnPossCodeNm", secsnPossCodeNm);
			return "my/mberSecsnRefuse";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}
}
