package com.sorincorp.fo.my.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.my.model.DeliveryDtlsVO;
import com.sorincorp.fo.my.service.DeliveryDtlsService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping("/my/deliveryDtls")
public class DeliveryDtlsController {
	
	@Autowired
	private DeliveryDtlsService deliveryDtlsService;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Value("${dlvy.trace.url}")
	private String dlvyTraceUrl;
	
	@RequestMapping("/deliveryDtls")
	public String getDeliveryDtls(Model model) {
		try {
			model.addAttribute("dlvyTraceUrl", dlvyTraceUrl);
			
			return "my/deliveryDtls";
		} catch (Exception e) {
			log.error(e.getMessage());
            return "error/503";
		}
	}
	
	@RequestMapping("/deliveryDtlsList")
	@ResponseBody
	public Map<String, Object> selectDeliveryDtlsList(@RequestBody DeliveryDtlsVO deliveryDtlsVO)  throws Exception {
		// 세션정보
		Account account = userInfoUtil.getAccountInfo();
		if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
			throw new Exception("로그인 정보를 확인해주세요.");
		}

		deliveryDtlsVO.setMberNo(account.getMberNo());
		deliveryDtlsVO.setEntrpsNo(account.getEntrpsNo());
		deliveryDtlsVO.setMemberSecode(userInfoUtil.getMemberSecode());
		
		Map<String, Object> result = new HashMap<>();
		
		List<DeliveryDtlsVO> deliveryDtlsList = deliveryDtlsService.selectDeliveryDtlsList(deliveryDtlsVO);
		int deliveryDtlsTotCnt = deliveryDtlsService.selectDeliveryDtlsTotCnt(deliveryDtlsVO);
		
		result.put("deliveryDtlsList", deliveryDtlsList);
		result.put("deliveryDtlsTotCnt", deliveryDtlsTotCnt);
		
		return result;
	}
	
	
}
