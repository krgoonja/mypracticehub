package com.sorincorp.fo.my.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.fo.my.model.CouponDtlVO;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.my.service.MyCouponDtlsSerivce;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/my/coupon")
public class CouponDtlsController {

    @Autowired
    MyCouponDtlsSerivce myCouponDtlsSerivce;

    @Autowired
    private UserInfoUtil userInfoUtil;


    private static String RESULT = "result";
    private static String ERRMSG = "errorMsg";
    private static String SUCCESS = "S";
    private static String FAIL = "F";


    /**
     * <pre>
     * 처리내용: 마이페이지 쿠폰 목록 페이지 호출
     * </pre>
     * @date 2023. 5. 9.
     * @author hamyoonsic
     * @history
     * -----------------------------------------------------
     * 변경일					작성자				변경내용
     * -----------------------------------------------------
     * 2022. 5. 9.				hamyoonsic			최초작성
     * -----------------------------------------------------
     * @param model
     * @param requestVO
     * @return
     * @throws Exception
     */
    @RequestMapping("/selectCouponDtlsList")
    public String selectCouponList(CouponVO couponVO, ModelMap model) throws Exception {
        try {
            Account account = userInfoUtil.getAccountInfo(); // 세션정보
            String mberType = userInfoUtil.getType();		// 회원 구분
            String mberNo = account.getMberNo(); 			//회원 번호
            String entrpsNo = account.getEntrpsNo();		// 기업 코드

            couponVO.setMberNo(mberNo);
            couponVO.setEntrpsNo(entrpsNo);
            Map<String, Object> couponInfo = myCouponDtlsSerivce.selectCouponList(couponVO);
            model.addAttribute("mberType", mberType);
            model.addAttribute("couponInfo", couponInfo);
            return "my/couponDtlsList";
        } catch( Exception e ) {
            log.error(e.getMessage());
            return "error/503";
        }
    }


    /**
     * <pre>
     * 처리내용: 마이페이지 쿠폰 등록
     * </pre>
     * @date 2022. 07. 25.
     * @author suminYun
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 07. 25.            SuminYun            최초작성
     * ------------------------------------------------
     * @return
     */
    @Transactional
    @RequestMapping("/updateCouponDtlsList")
    @ResponseBody
    public ResponseEntity<Object> updateCouponDtlsList(@RequestBody CouponDtlVO couponDtlVo, String couponIsuRnno) throws Exception {
        int result = 0;

        Map<String, Object> retVal = new HashMap<String, Object>();

        Account account = userInfoUtil.getAccountInfo();

        couponDtlVo.setMberNo(account.getMberNo());
        couponDtlVo.setMberId(account.getId());
        couponDtlVo.setEntrpsNo(account.getEntrpsNo());

        try {
        	result = myCouponDtlsSerivce.updateCouponDtlsList(couponDtlVo);

        	if(result > 0) {
                retVal.put(RESULT, SUCCESS);
                retVal.put(ERRMSG, "등록 완료 되었습니다");
            } else if(result == -99) {
                retVal.put(RESULT, FAIL);
                retVal.put(ERRMSG, "이미 등록된 쿠폰입니다.");
            } else if(result == -98) {
                retVal.put(RESULT, FAIL);
                retVal.put(ERRMSG, "해당하는 쿠폰이 없습니다.");
            } else if(result == -97) {
                retVal.put(RESULT, FAIL);
                retVal.put(ERRMSG, "중복 두개 이상의 쿠폰이 존재 합니다. 관리자에 문의 하시기 바랍니다.");
            } else if(result == -96) {
                retVal.put(RESULT, FAIL);
                retVal.put(ERRMSG, "나머지 쿠폰 정책 오픈안됨. 관리자에 문의 하시기 바랍니다.");
            } else if(result == -95) {
                retVal.put(RESULT, FAIL);
                retVal.put(ERRMSG, "입력쿠폰 정책 오픈 안됨. 관리자에 문의 하시기 바랍니다.");
            } else if(result == -94) {
                retVal.put(RESULT, FAIL);
                retVal.put(ERRMSG, "해당하는 쿠폰이 없습니다.");
            } else {
            	retVal.put(RESULT, FAIL);
                retVal.put(ERRMSG, "관리자에 문의 하시기 바랍니다.");
            }

        } catch (Exception e) {
            log.error(e.getMessage());
            result = -1;
            retVal.put(RESULT, FAIL);
            retVal.put(ERRMSG, e.getMessage());
            return new ResponseEntity<>(retVal, HttpStatus.OK);
        }

        return new ResponseEntity<>(retVal, HttpStatus.OK);
    }

}



