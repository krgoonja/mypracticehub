package com.sorincorp.fo.my.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.deliveryCarMng.model.DeliveryCarMngCommVO;
import com.sorincorp.comm.deliveryCarMng.service.DeliveryCarMngCommService;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.fo.config.UserInfoUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/my/delivery")
public class DeliveryCarMngController {

	@Autowired
	private DeliveryCarMngCommService deliveryCarMngCommService;
	@Autowired
	private CustomValidator customValidator;
	@Autowired
	private UserInfoUtil userInfoUtil;

	private static String RESULT = "result";
	private static String ERRMSG = "errorMsg";
	private static String SUCCESS = "S";
	private static String FAIL = "F";

	@Transactional
	@RequestMapping("/insertDeliveryCar")
	@ResponseBody
	public ResponseEntity<Object> insertDeliveryCar(@RequestBody DeliveryCarMngCommVO deliveryCarMngCommVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		} else {
			deliveryCarMngCommVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
			deliveryCarMngCommVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		}

		customValidator.validate(deliveryCarMngCommVO, bindingResult, DeliveryCarMngCommVO.Insert.class);

		if (bindingResult.hasErrors()) {
			// validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = deliveryCarMngCommService.insertDeliveryCar(deliveryCarMngCommVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);

			if (result == -99) {
				retVal.put(ERRMSG, "최대 5개까지 등록 가능합니다.");
			} else if (result == -98) {
				retVal.put(ERRMSG, "중복된 차량번호가 존재합니다.");
			} else {
				retVal.put(ERRMSG, "");
			}
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@Transactional
	@RequestMapping("/updateDeliveryCar")
	@ResponseBody
	public ResponseEntity<Object> updateDeliveryCar(@RequestBody DeliveryCarMngCommVO deliveryCarMngCommVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		} else {
			deliveryCarMngCommVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		}

		customValidator.validate(deliveryCarMngCommVO, bindingResult, DeliveryCarMngCommVO.Update.class);

		if (bindingResult.hasErrors()) {
			// validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = deliveryCarMngCommService.updateDeliveryCar(deliveryCarMngCommVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);

			if (result == -98) {
				retVal.put(ERRMSG, "중복된 차량번호가 존재합니다.");
			} else {
				retVal.put(ERRMSG, "");
			}
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@Transactional
	@RequestMapping("/deleteDeliveryCar")
	@ResponseBody
	public ResponseEntity<Object> deleteDeliveryCar(@RequestBody DeliveryCarMngCommVO deliveryCarMngCommVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		} else {
			deliveryCarMngCommVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		}

		customValidator.validate(deliveryCarMngCommVO, bindingResult, DeliveryCarMngCommVO.Delete.class);

		if (bindingResult.hasErrors()) {
			// validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = deliveryCarMngCommService.deleteDeliveryCar(deliveryCarMngCommVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@Transactional
	@RequestMapping("/insertDeliveryDriver")
	@ResponseBody
	public ResponseEntity<Object> insertDeliveryDriver(@RequestBody DeliveryCarMngCommVO deliveryCarMngCommVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		} else {
			deliveryCarMngCommVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
			deliveryCarMngCommVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		}

		customValidator.validate(deliveryCarMngCommVO, bindingResult, DeliveryCarMngCommVO.Insert2.class);

		if (bindingResult.hasErrors()) {
			// validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = deliveryCarMngCommService.insertDeliveryDriver(deliveryCarMngCommVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);

			if (result == -99) {
				retVal.put(ERRMSG, "최대 5개까지 등록 가능합니다.");
			} else if (result == -98) {
				retVal.put(ERRMSG, "중복된 기사정보(전화번호)가 존재합니다.");
			} else {
				retVal.put(ERRMSG, "");
			}
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@Transactional
	@RequestMapping("/updateDeliveryDriver")
	@ResponseBody
	public ResponseEntity<Object> updateDeliveryDriver(@RequestBody DeliveryCarMngCommVO deliveryCarMngCommVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		} else {
			deliveryCarMngCommVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		}

		customValidator.validate(deliveryCarMngCommVO, bindingResult, DeliveryCarMngCommVO.Update2.class);

		if (bindingResult.hasErrors()) {
			// validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = deliveryCarMngCommService.updateDeliveryDriver(deliveryCarMngCommVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);

			if (result == -98) {
				retVal.put(ERRMSG, "중복된 기사정보(전화번호)가 존재합니다.");
			} else {
				retVal.put(ERRMSG, "");
			}
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

	@Transactional
	@RequestMapping("/deleteDeliveryDriver")
	@ResponseBody
	public ResponseEntity<Object> deleteDeliveryDriver(@RequestBody DeliveryCarMngCommVO deliveryCarMngCommVO, Model model, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();

		if (userInfoUtil.getAccountInfo() == null) {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "로그인되지 않은 사용자입니다.");
			retVal.put("userInfoUtil", userInfoUtil.getAccountInfo());
			return new ResponseEntity<>(retVal, HttpStatus.OK);
		} else {
			deliveryCarMngCommVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		}

		customValidator.validate(deliveryCarMngCommVO, bindingResult, DeliveryCarMngCommVO.Delete2.class);

		if (bindingResult.hasErrors()) {
			// validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		int result = deliveryCarMngCommService.deleteDeliveryDriver(deliveryCarMngCommVO);

		if (result > 0) {
			retVal.put(RESULT, SUCCESS);
			retVal.put(ERRMSG, "");
		} else {
			retVal.put(RESULT, FAIL);
			retVal.put(ERRMSG, "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
}
