package com.sorincorp.fo.my.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.constants.ExceptionConstants;
import com.sorincorp.comm.order.model.CommBlceInfoVO;
import com.sorincorp.comm.order.service.CommDashboardWebsocketService;
import com.sorincorp.comm.order.service.CommFinalBlceCheckService;
import com.sorincorp.comm.order.service.CommLimitOrderService;
import com.sorincorp.comm.order.service.CommPrvsnlOrderService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.mb.model.MbEntrpsGradVO;
import com.sorincorp.fo.my.mapper.DashboardMapper;
import com.sorincorp.fo.my.model.BankInfoVO;
import com.sorincorp.fo.my.model.DashboardVO;
import com.sorincorp.fo.my.model.InqryDtlsVO;
import com.sorincorp.fo.my.model.OrPcChangegldBasVO;
import com.sorincorp.fo.my.model.PaytEsamtVO;
import com.sorincorp.fo.my.model.SetleDtlsDetailVO;
import com.sorincorp.fo.pd.comm.constant.PdCommConstant;
import com.sorincorp.fo.pd.comm.constant.PdPropertyConstant;

import lombok.extern.slf4j.Slf4j;

/**
 * DashboardServiceImpl.java
 * @version
 * @since 2021. 7. 27.
 * @author srec0048
 */
@Slf4j
@Service
public class DashboardServiceImpl implements DashboardService {

	@Autowired
	DashboardMapper dashboardMapper;

    /** 외부 연계 api 호출 모듈 **/
    @Autowired
    private HttpClientHelper httpClientHelper;

    /** 프로퍼티 상수 모음 **/
    @Autowired
    private PdPropertyConstant orProperty;

	@Autowired
	private MessageUtil messageUtil;

	/** 예수금 포함 최종 잔액 조회 서비스 */
	@Autowired
	private CommFinalBlceCheckService commFinalBlceCheckService;

	/** 지정가 주문 공통 서비스 */
	@Autowired
	private CommLimitOrderService commLimitOrderService;
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
    private AssignService assignService;
	
	@Autowired
	private CommDashboardWebsocketService commDashboardWebsocketService;
	
	@Autowired
	private CommPrvsnlOrderService commPrvsnlOrderService;
	
	@Autowired
	private ObjectMapper objectMapper;

	/**
	 * 상단 대시보드 결제수단을 조회한다.
	 * 암복호화 로직 추가
	 */
	@Override
	public Map<String, Object> selectSetleMnInfo(String entrpsNo) throws Exception {
		Map<String, Object> retMap = dashboardMapper.selectSetleMnInfo(entrpsNo);
		String refndAcnutNo = retMap.get("refndAcnutNo").toString();	//환불계좌번호
		String ewalletAcnutNo = retMap.get("ewalletAcnutNo").toString();	//이월렛계좌번호

		if (StringUtils.isNotBlank(refndAcnutNo)) {
			try {
				String decStrNo = CryptoUtil.decryptAES256(refndAcnutNo);
				retMap.put("refndAcnutNo", StringUtil.formatBankAccountNo(decStrNo));
			} catch (Exception e) {
				log.error("복호화 오류 : "+ e.getMessage());
				retMap.put("refndAcnutNo", "*******");
			}
		}

		if (StringUtils.isNotBlank(ewalletAcnutNo)) {
			try {
				String decStrNo = CryptoUtil.decryptAES256(ewalletAcnutNo);
				retMap.put("ewalletAcnutNo", StringUtil.formatBankAccountNo(decStrNo));
			} catch (Exception e) {
				log.error("복호화 오류 : "+ e.getMessage());
				retMap.put("ewalletAcnutNo", "*******");
			}
		}

		return retMap;
	}
	/**
	 * 마이페이지 최근 30일 거래내역을 조회한다.
	 */
	@Override
	public DashboardVO selectRecentOrderDtls(Map<String, Object> param) throws Exception {
		return dashboardMapper.selectRecentOrderDtls(param);
	}

	/**
	 * 마이페이지 최근 24시간 내 3개 알림 내역 조회한다.
	 */
	@Override
	public List<DashboardVO> selectRecentNtcn(String entrpsNo) throws Exception {
		return dashboardMapper.selectRecentNtcn(entrpsNo);
	}

	/**
	 * 마이페이지 최근 7일내 3개 문의/답변 내역 조회한다.
	 */
	@Override
	public List<InqryDtlsVO> selectRecentInqryAnswer(Map<String, Object> param) throws Exception {
		List<InqryDtlsVO> list = new ArrayList<>();
		String mberType = StringUtil.nvl(String.valueOf(param.get("mberType")), "");

		if(mberType.equals("02")) {
			String mberNo = String.valueOf(param.get("mberNo"));
			list = dashboardMapper.selectRecentSimpleInqryAnswer(mberNo);
		} else if(mberType.equals("01")) {
			String entrpsNo = String.valueOf(param.get("entrpsNo"));
			list = dashboardMapper.selectRecentInqryAnswer(entrpsNo);
		}

		return list;
	}

	/**
	 * 출금(상환)요청 전, 예수금(지정가주문)을 체크
	 */
	@Override
	public Map<String, Object> createRefundRequstBefore(Map<String, Object> params) throws Exception {
		long delngExpectAmount = NumberUtils.toLong(String.valueOf(params.get("refndRequstAmount"))); // 출금요청금액

		Map<String, Object> retMap = new HashMap<>();
		retMap.put(CommonConstants.RESULT_CODE, CommonConstants.RESULT_CODE_FAIL);  // resultCode = F
		retMap.put(CommonConstants.RESULT_MSG, "");

		try {
			CommBlceInfoVO commBlceInfoVO = commFinalBlceCheckService
					.selectFinalBlceInfoBySetleMn(String.valueOf(params.get("entrpsNo")), "", "", delngExpectAmount);

			// 가능
			if (commBlceInfoVO.isDelngPossAt()) {
				retMap.put(CommonConstants.RESULT_CODE, CommonConstants.RESULT_CODE_SUCCESS); // resultCode = S
			}
			// 불가능
			else {
				String type = String.valueOf(params.get("type"));
				String finalBlce = StringUtil.formatMoney(String.valueOf(commBlceInfoVO.getTotAdvrcvAmount()));
				StringBuilder resultMsg = new StringBuilder();
				resultMsg.append("현재 지정가 주문에 따른 결제 대기 금액("+ finalBlce)
					.append("원)이 존재합니다. "+ type+ "하기를 희망하시면, 접수된 지정가 주문 건은 자동으로 취소 됩니다.")
					.append("\n(자동 취소 기준 : "+ type+ " 실행 금액 만큼 최근 지정가 주문부터 자동 취소)")
					.append("\n\n계속하시겠습니까?");

				retMap.put(CommonConstants.RESULT_MSG, resultMsg.toString());
			}

		} catch (Exception e) {
			retMap.put(CommonConstants.RESULT_MSG, messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
		}

		return retMap;
	}

	/**
	 * 출금요청<br>
	 * 2022.12 체크로직 및 가능 여부를 함수로 대체 fn_getEwalletRefndSttus('2', '업체번호')<br>
	 * 2023.05.16 지정가 자동 취소 로직 추가
	 */
	@Override
	public Map<String, Object> createRefundRequst(Map<String, Object> refundRequstInfo) throws Exception {
	    /*
	     * 환불요청에서 자동환불로 정책변경에 따라 인출요청 테이블에 데이터 적재 후 환불api 호출
	     * 환불 가능 여부 확인
	     * 주문 진행건이 존재하는 경우와 기업뱅킹(하나은행 앱)을 통해서 환불 진행중인 건이 있을 경우 환불 불가
	     */
	    Map<String, Object> rtnMap = new HashMap<>();
	    rtnMap.put("result", CommonConstants.RESULT_CODE_FAIL);

	    String orderCancelAt = String.valueOf(refundRequstInfo.get("orderCancelAt")); // 지정가 주문 자동 취소 여부
	    String entrpsNo = String.valueOf(refundRequstInfo.get("entrpsNo")); // 업체번호
	    String mberId = String.valueOf(refundRequstInfo.get("mberId"));
	    long refndRequstAmount = NumberUtils.toLong(String.valueOf(refundRequstInfo.get("refndRequstAmount"))); // 환불요청금액

	    // 업체 결제 정보
        Map<String, Object> setleMnInfo = dashboardMapper.selectSetleMnInfo(entrpsNo);
        if (ObjectUtils.isEmpty(setleMnInfo)) {
        	log.error("업체 결제 정보 확인 불가");
            rtnMap.put(CommonConstants.RESULT_MSG, messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
            return rtnMap;
        }

        // 2023.05.16 지정가 자동 취소
        if (CommonConstants.YN_Y.equals(orderCancelAt)) {
        	commLimitOrderService.limitOrderAutoCancel(mberId, entrpsNo, "47", refndRequstAmount);
        }

        // 2022.12 출금 가능 여부 체크 함수
        String returnSttus = String.valueOf(setleMnInfo.get("returnSttus"));
        String returnMsg = String.valueOf( setleMnInfo.get("returnMsg"));
        String rcpmnyAcnutNo = String.valueOf(setleMnInfo.get("refndAcnutNo")); // 고객 환불 계좌 번호
        long ewalletBlce = (long) setleMnInfo.get("ewalletBlce");

        if (!"Y".equals(StringUtil.nvl(returnSttus))) {
        	log.error("출금 불가능. setleMnInfo : {}", setleMnInfo);
        	if (StringUtil.isNotBlank(returnMsg)) {
        		rtnMap.put(CommonConstants.RESULT_MSG, returnMsg);
        	} else {
        		rtnMap.put(CommonConstants.RESULT_MSG, messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
        	}

        	return rtnMap;
        }

        refundRequstInfo.put("rcpmnyAcnutNo", rcpmnyAcnutNo);         // 고객 환불 계좌 번호
        refundRequstInfo.put("refndRequstHourBlce", ewalletBlce);    // 이월렛 잔액

        // 인출요청 테이블에 적재
        dashboardMapper.insertRefundRequst(refundRequstInfo);
        String refndRequstDt = (String) refundRequstInfo.get("refndRequstDt");

        // ======================================================= 환불 api =======================================================
        Map<String, Object> ewalletMap = new HashMap<>();

        ewalletMap.put("delngAmount"         , refndRequstAmount); // 거래금액(환불요청금액)
        ewalletMap.put("entrpsNo"            , entrpsNo);       // 업체번호
        ewalletMap.put("iemSeCode"           , "0002");         // 항목구분코드 : 0001(구매), 0002(고객 환불), 0003(이체), 0004(기업뱅킹 환불)
        ewalletMap.put("refndRequstDt"       , refndRequstDt);  // 환불 요청일시
        ewalletMap.put("ewalletExcclcTyCode" , "02");

        // 환불 api 콜
        Map<String, Object> ewalletResMap = httpClientHelper.postCallApi(orProperty.getEwalletOrderUrl(), ewalletMap);
        if (ObjectUtils.isEmpty(ewalletResMap)) {
        	log.error("환불 api 통신 에러");
            /*
             * api 통신 에러가 났을 경우, MB_REFND_REQUST_HST(회원_환불 요청 이력) 테이블에
             * REFND_REQUST_STTUS_CODE(환불 요청 상태 코드)를 04(실패)로 업데이트 한다.
             */
            dashboardMapper.updateRefundRequstSttu(refundRequstInfo);
            rtnMap.put(CommonConstants.RESULT_MSG, messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
            return rtnMap;
        }

     // 이월렛 서버에서 결제테이블 정상 성공으로 업데이트 되었는지 체크 (60초)
        boolean isSuccess = false;
        Map<String, Object> resultData = (Map<String, Object>) ewalletResMap.get(PdCommConstant.EWALLET_DATA_KEY);
        String delngSeqNo = String.valueOf(resultData.get("delngSeqNo"));
		for (int i = 0; i < orProperty.getEwalletTimeoutsec() * 2; i++) {
			Thread.sleep(500);
			//호출 건 응답 코드 확인
			String rspnsCode = dashboardMapper.selectEwalletRspnCode(delngSeqNo);
			log.debug(">> rspnsCode : " + rspnsCode);
			if(!StringUtils.isEmpty(rspnsCode)) {
				//응답 코드가 000 일때 거래 완료 -> 전문설계서 응답코드 확인
				if(StringUtils.equals(rspnsCode, "000")) {
					isSuccess = true;
				}
				log.debug(">> rspnsCode : " + rspnsCode + ", isSuccess : " + isSuccess);
				break;
			}
		}

		log.debug(">> finally isSuccess : " + isSuccess);
		if (!isSuccess) {
			log.error("이월렛 환불 실패 delngSeqNo : {}", delngSeqNo);
			rtnMap.put(CommonConstants.RESULT_MSG, messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
            return rtnMap;
		}

		rtnMap.put("result", CommonConstants.RESULT_CODE_SUCCESS);
		rtnMap.put(CommonConstants.RESULT_MSG, "인출요청이 완료되었습니다.");
        // ===================================================== // 환불 api =======================================================

		return rtnMap;
	}

	@Override
	public Map<String, Object> selectUnSetleAmount(Map<String, Object> param) throws Exception {
		String entrpsNo = String.valueOf(param.get("entrpsNo"));
		Map<String, Object> unSetleAmountInfo = dashboardMapper.selectUnSetleAmount(entrpsNo);
		return unSetleAmountInfo;
	}

	@Override
	public List<PaytEsamtVO> selectListUnSetleAmountDtl(Map<String, Object> param) throws Exception {
		String entrpsNo = String.valueOf(param.get("entrpsNo"));
		List<PaytEsamtVO> list = dashboardMapper.selectListUnSetleAmountDtl(entrpsNo);
		return list;
	}

	@Override
	public List<BankInfoVO> selectListEntrpsBank(Map<String, Object> param) throws Exception {
		String entrpsNo = String.valueOf(param.get("entrpsNo"));
		return dashboardMapper.selectListEntrpsBank(entrpsNo);
	}

	@Override
	public List<SetleDtlsDetailVO> setleDtlsList(SetleDtlsDetailVO paramVo) throws Exception {
		return dashboardMapper.setleDtlsList(paramVo);
	}
	
	@Override
	public MbEntrpsGradVO selectMbEntrpsGradStdrPurchsQy() throws Exception {
		return dashboardMapper.selectMbEntrpsGradStdrPurchsQy();
	}
	
	@Override
	public List<MbEntrpsGradVO> selectMbGradDscntAmountList() throws Exception {
		return dashboardMapper.selectMbGradDscntAmountList();
	}
	@Override
	public int selectMbTotRealOrderWtSum(String entrpsNo) throws Exception {
		return dashboardMapper.selectMbTotRealOrderWtSum(entrpsNo);
	}
	@Override
	public MbEntrpsGradVO mbEntrpsMnbyPurchsInfo(String entrpsNo) throws Exception {
		return dashboardMapper.mbEntrpsMnbyPurchsInfo(entrpsNo);
	}
	@Override
	public List<MbEntrpsGradVO> selectcpAtmcIsuCouponInfoList() throws Exception {
		return dashboardMapper.selectcpAtmcIsuCouponInfoList();
	}
	@Override
	public Map<String, Object> doEwalletDefrayRequestForPcChangegld(OrPcChangegldBasVO defrayRequstInfo) throws Exception {
		Map<String, Object> rtnMap = new HashMap<>();
	    rtnMap.put("result", CommonConstants.RESULT_CODE_FAIL);
	    
	    // 발생 순번 별로 데이터 조회
	    List<OrPcChangegldBasVO> requestVOList = dashboardMapper.selectOrPcChangegldBas(defrayRequstInfo);
	    
	    // 데이터 조회 결과 확인
	    if(CollectionUtils.isEmpty(requestVOList)) {
	    	rtnMap.put(CommonConstants.RESULT_MSG, "출금 대상 정보가 존재하지 않습니다.\r\n\r\n" + messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
	    	return rtnMap;
	    }
	    
	    // 조회된 출금 대상 금액의 총합
	    long sumOfDefrayAmount = requestVOList.stream().mapToLong(OrPcChangegldBasVO::getRcppayTrgetAmount).sum();
	    
	    // 출금 요청 금액과 실제 조회된 출금 요청 금액이 일치하는지 확인
	    if(sumOfDefrayAmount != defrayRequstInfo.getRcppayTrgetAmount()) {
	    	rtnMap.put(CommonConstants.RESULT_MSG, "출금 요청 금액이 올바르지 않습니다.\r\n\r\n" + messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
	    	return rtnMap;
	    }
	    
	    for (OrPcChangegldBasVO requestVO : requestVOList) {
	    	requestVO.setMberId(defrayRequstInfo.getMberId());
			requestVO.setEntrpsNo(defrayRequstInfo.getEntrpsNo());
	    	
	    	Map<String, Object> ewalletTransferMap = objectMapper.convertValue(requestVO, Map.class);
	    	
	    	// 이월렛 출금 처리
	    	String setleNo = doEwalletTransfer(ewalletTransferMap);
	    	
	    	commPrvsnlOrderService.updateOrPcOrPcChangegldBasByDefray(requestVO.getOrderNo(), (int)requestVO.getOccrrncSn(), setleNo, defrayRequstInfo.getMberId());
	    	commonService.insertTableHistory("OR_PC_CHANGEGLD_BAS", requestVO);
	    	
	    	// BO 대시보드 실시간 반영
	    	commDashboardWebsocketService.publishRcpmnyEvent(requestVO.getOrderNo(), true);
		}
	    
	    rtnMap.put("result", CommonConstants.RESULT_CODE_SUCCESS);
	    rtnMap.put(CommonConstants.RESULT_MSG, "출금 처리가 완료되었습니다.");
		
		return rtnMap;
	}
	/**
	 * <pre>
	 * 처리내용: 환불 처리 메소드
	 * </pre>
	 * @date 2024. 10. 29.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 10. 29.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param ewalletTransferMap
	 * @throws Exception
	 */
	public String doEwalletTransfer(Map<String, Object> ewalletTransferMap) throws Exception {
		String setleNo = null;
		
		try {
	    	setleNo = DateUtil.getNowDateTime("yyyyMMdd") 
	    						+ "-" + assignService.selectAssignValue("OR", "SETLE_NO", DateUtil.getNowDate(), String.valueOf(ewalletTransferMap.get("mberId")), 5);
	    	
	    	ewalletTransferMap.put("setleNo", setleNo);
	    	
	    	dashboardMapper.insertOrSetleBas(ewalletTransferMap);
	    	commonService.insertTableHistory("OR_SETLE_BAS", Collections.singletonMap("SETLE_NO", setleNo));
	    	
	    	Map<String, Object> ewalletMap = new HashMap<String, Object>();
            ewalletMap.put("entrpsNo", ewalletTransferMap.get("entrpsNo"));
            ewalletMap.put("iemSeCode", "0003");			// 항목구분코드 : 0001(구매), 0002(고객 환불), 0003(이체), 0004(기업뱅킹 환불)
            ewalletMap.put("ewalletExcclcTyCode", "02");	// E-Wallet 정산 유형 코드 02 : 고객환불
            ewalletMap.put("setleNo", setleNo);
            ewalletMap.put("delngAmount", ewalletTransferMap.get("rcppayTrgetAmount"));
            ewalletMap.put("precdntAt", "A");               //선수금 여부
            
            Map<String, Object> ewalletResMap = httpClientHelper.postCallApi(orProperty.getEwalletOrderUrl(), ewalletMap);
            log.debug(ewalletResMap.toString()); // log

            // 이월렛 서버에서 결재테이블 정상 성공으로 업데이트 되었는지 체크
            if (null != ewalletResMap && StringUtils.equals("200", ewalletResMap.get("resultCode").toString())
                    && ewalletResMap.get("data") != null) {
                boolean isSuccess = false;
                Map<String, Object> resultData = (Map<String, Object>) ewalletResMap.get("data");
                String delngSeqNo = String.valueOf(resultData.get("delngSeqNo"));

                for (int i = 0; i < orProperty.getEwalletTimeoutsec() * 2; i++) {
                    Thread.sleep(500);
                    // 호출 건 응답 코드 확인
                    String rspnsCode = dashboardMapper.selectEwalletRspnCode(delngSeqNo);
                    log.debug(">> rspnsCode : " + rspnsCode);
                    if (!StringUtils.isEmpty(rspnsCode)) {
                        // 응답 코드가 000 일때 거래 완료 -> 전문설계서 응답코드 확인
                        if (StringUtils.equals(rspnsCode, "000")) {
                            isSuccess = true;
                        }
                        log.debug(">> rspnsCode : " + rspnsCode + ", isSuccess : " + isSuccess);
                        break;
                    }
                } // end for
                log.debug(">> finally isSuccess : " + isSuccess);

                if (!isSuccess) {
                	throw new Exception("이월렛 주문 실패");
                }
            } else {
            	throw new Exception("이월렛 호출 실패");
            }
		} catch (Exception e) {
			throw new Exception("이월렛 환불처리 실패 :: " + e.getMessage());
		}
		
		return setleNo;
	}

}
