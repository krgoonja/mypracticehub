package com.sorincorp.fo.my.service;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.my.mapper.DeliveryDtlsMapper;
import com.sorincorp.fo.my.model.DeliveryDetailDtlsVO;
import com.sorincorp.fo.my.model.DeliveryDtlsVO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DeliveryDtlsServiceImpl implements DeliveryDtlsService {
	
	@Autowired
	private DeliveryDtlsMapper deliveryDtlsMapper;

	@Override
	public List<DeliveryDtlsVO> selectDeliveryDtlsList(DeliveryDtlsVO deliveryDtlsVO) throws Exception {
		// 리스트로 조회되는 기본 배송 내역 조회
		List<DeliveryDtlsVO> deliveryDtlsList = deliveryDtlsMapper.selectDeliveryDtlsList(deliveryDtlsVO);
		
		// 조회된 주문 별로 배송 상세 내역 조회
		for (DeliveryDtlsVO vo : deliveryDtlsList) {
			List<DeliveryDetailDtlsVO> deliveryDetailDtlsList = deliveryDtlsMapper.selectDeliveryDetailDtlsList(vo.getOrderNo());
			
			// 조회 결과가 없으면 다음 주문 건으로 진행
			if(deliveryDetailDtlsList.isEmpty()) continue;
			
			// 자차배송 > 상세내역 > 요청 정보 세팅
			if(StringUtils.equals(vo.getDlvyMnCode(), "02")) {						// 확정 정보 아님 == 요청 정보임
				vo.setDeliveryDetailDtlsRequstList(deliveryDetailDtlsList.stream().filter(dtls -> !dtls.isDcsnInfoAt()).collect(Collectors.toList()));
			}
			
			// 자차배송 > 상세내역 > 확정 정보 세팅
			// 케이지배송 > 상세내역 세팅															확정 정보임
			vo.setDeliveryDetailDtlsDcsnList(deliveryDetailDtlsList.stream().filter(dtls -> dtls.isDcsnInfoAt()).collect(Collectors.toList()));
		}
		
		return deliveryDtlsList;
	}

	@Override
	public int selectDeliveryDtlsTotCnt(DeliveryDtlsVO deliveryDtlsVO) throws Exception {
		return deliveryDtlsMapper.selectDeliveryDtlsTotCnt(deliveryDtlsVO);
	}

}
