package com.sorincorp.fo.my.service;

import java.util.List;

import com.sorincorp.fo.my.model.DeliveryDtlsVO;

public interface DeliveryDtlsService {
	/**
	 * <pre>
	 * 처리내용: 주문 별 배송 내역과 상세 내역을 목록으로 조회
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param deliveryDtlsVO
	 * @return
	 * @throws Exception
	 */
	List<DeliveryDtlsVO> selectDeliveryDtlsList(DeliveryDtlsVO deliveryDtlsVO) throws Exception;
	/**
	 * <pre>
	 * 처리내용: 배송 내역 총 건수 조회
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param deliveryDtlsVO
	 * @return
	 * @throws Exception
	 */
	int selectDeliveryDtlsTotCnt(DeliveryDtlsVO deliveryDtlsVO) throws Exception;
}
