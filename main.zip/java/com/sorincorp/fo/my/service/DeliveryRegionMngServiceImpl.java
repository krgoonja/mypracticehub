package com.sorincorp.fo.my.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.my.mapper.DeliveryRegionMngMapper;
import com.sorincorp.fo.my.model.DeliveryRegionMngVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DeliveryRegionMngServiceImpl implements DeliveryRegionMngService {

	@Autowired
	private DeliveryRegionMngMapper deliveryRegionMngMapper;
	@Autowired
	private UserInfoUtil userInfoUtil;

	@Override
	public List<DeliveryRegionMngVO> selectMbDlvrgSeDtlListList(String entrpsNo) throws Exception {
		// TODO Auto-generated method stub
//		if(entrpsNo == null || "".equals(entrpsNo)) {
//			entrpsNo = ENTRPS_NO;
//		} else if("all".equals(entrpsNo)) {
//			entrpsNo = "";
//		}
		DeliveryRegionMngVO deliveryRegionMngVO = new DeliveryRegionMngVO();
		deliveryRegionMngVO.setEntrpsNo(entrpsNo);
		return deliveryRegionMngMapper.selectMbDlvrgSeDtlListList(deliveryRegionMngVO);
	}

	@Override
	public List<DeliveryRegionMngVO> selectDeliveryRegionMngList(DeliveryRegionMngVO deliveryRegionMngVO)
			throws Exception {
		// TODO Auto-generated method stub
		List<DeliveryRegionMngVO> list = deliveryRegionMngMapper.selectDeliveryRegionMngList(deliveryRegionMngVO);
		DeliveryRegionMngVO vo = null;
		String dlvrgChargerCttpc = "";
		String regEx = "(\\d{3})(\\d{3,4})(\\d{4})";

		if(list != null) {
			for(int i=0;i<list.size();i++) {
				vo = list.get(i);

				dlvrgChargerCttpc = vo.getDlvrgChargerCttpc();

				if(dlvrgChargerCttpc != null && !"".equals(dlvrgChargerCttpc)) {
					try {
	                    log.debug("배송지 목록조회 배송담당자 연락처 복호화 전 ===========>" + dlvrgChargerCttpc);
	                    dlvrgChargerCttpc = CryptoUtil.decryptAES256(dlvrgChargerCttpc);
	                    log.debug("배송지 목록조회 배송담당자 연락처 복호화 후 ===========>" + dlvrgChargerCttpc);
	                    vo.setDlvrgChargerCttpc(dlvrgChargerCttpc.replaceAll(regEx, "$1-$2-$3"));
	                    list.set(i, vo);
	                } catch (Exception e) {
	                    // TODO: handle exception
	                    log.error("selectDeliveryRegionMngList DLVRG_CHARGER_CTTPC CryptoUtil.decryptAES256 ERROR " + e.getMessage());
	                }
				}
			}
		}
		return list;
	}

	@Override
	public int updateBassDlvrgAt(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception {
		// TODO Auto-generated method stub
		//기본배송지 건수 조회
		String bassDlvrgNo = deliveryRegionMngMapper.selectBassDlvrgNo(deliveryRegionMngVO);
		String dlvrgNo = deliveryRegionMngVO.getDlvrgNo();
		int result = 0;

		deliveryRegionMngVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

		if (bassDlvrgNo != null && !"".equals(bassDlvrgNo)) {
			//기본배송지 일괄 N처리
			deliveryRegionMngVO.setBassDlvrgAt("N");
			deliveryRegionMngVO.setDlvrgNo(bassDlvrgNo);

			result = deliveryRegionMngMapper.updateBassDlvrgAt(deliveryRegionMngVO);
			if(result > 0) {
				deliveryRegionMngMapper.insertMbDlvrgBasHst(deliveryRegionMngVO);
			} else {
				return -1;
			}

			//기본배송지 설정
			deliveryRegionMngVO.setBassDlvrgAt("Y");
			deliveryRegionMngVO.setDlvrgNo(dlvrgNo);

			result = deliveryRegionMngMapper.updateBassDlvrgAt(deliveryRegionMngVO);
			if(result > 0) {
				deliveryRegionMngMapper.insertMbDlvrgBasHst(deliveryRegionMngVO);
			} else {
				return -1;
			}

		} else {
			//기본배송지 설정
			deliveryRegionMngVO.setBassDlvrgAt("Y");
			deliveryRegionMngVO.setDlvrgNo(dlvrgNo);
			result = deliveryRegionMngMapper.updateBassDlvrgAt(deliveryRegionMngVO);
			if(result > 0) {
				deliveryRegionMngMapper.insertMbDlvrgBasHst(deliveryRegionMngVO);
			} else {
				return -1;
			}
		}

		return result;
	}

	@Override
	public int deleteDeliveryRegion(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception {
		// TODO Auto-generated method stub
		int result = 0;

		deliveryRegionMngVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

		result = deliveryRegionMngMapper.deleteMbDlvrgBas(deliveryRegionMngVO);
		deliveryRegionMngMapper.insertMbDlvrgBasHst(deliveryRegionMngVO);

		return result;
	}

	@Override
	public int updateDeliveryRegion(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception {
		// TODO Auto-generated method stub
		//전화번호 하이푼(-) 제거
		String dlvrgChargerCttpc = deliveryRegionMngVO.getDlvrgChargerCttpc().replaceAll("-", "");
		String dlvrgChargerCttpcEnc = dlvrgChargerCttpc;

		if(dlvrgChargerCttpcEnc != null && !"".equals(dlvrgChargerCttpcEnc)) {
			try {
				log.debug("배송지 수정 배송담당자 연락처 암호화 전 ===========>" + dlvrgChargerCttpcEnc);
				dlvrgChargerCttpcEnc = CryptoUtil.encryptAES256(dlvrgChargerCttpcEnc);
				log.debug("배송지 수정 배송담당자 연락처 암호화 후 ===========>" + dlvrgChargerCttpcEnc);
			} catch (Exception e) {
				// TODO: handle exception
				log.error("updateDeliveryRegion DLVRG_CHARGER_CTTPC CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}

		int result = 0;

		//deliveryRegionMngVO.setDlvrgChargerCttpc(dlvrgChargerCttpc);
		deliveryRegionMngVO.setDlvrgChargerCttpc(dlvrgChargerCttpcEnc);
		deliveryRegionMngVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

		result = deliveryRegionMngMapper.updateDeliveryRegion(deliveryRegionMngVO);
		deliveryRegionMngMapper.insertMbDlvrgBasHst(deliveryRegionMngVO);

		if (result < 0) {
			return -1;
		}
		return result;
	}

	@Override
	public int insertDeliveryRegion(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception {
		// TODO Auto-generated method stub
		//전화번호 하이푼(-) 제거
		String dlvrgChargerCttpc = deliveryRegionMngVO.getDlvrgChargerCttpc().replaceAll("-", "");
		String dlvrgChargerCttpcEnc = dlvrgChargerCttpc;

		if(dlvrgChargerCttpcEnc != null && !"".equals(dlvrgChargerCttpcEnc)) {
			try {
				log.debug("배송지 등록 배송담당자 연락처 암호화 전 ===========>" + dlvrgChargerCttpcEnc);
				dlvrgChargerCttpcEnc = CryptoUtil.encryptAES256(dlvrgChargerCttpcEnc);
				log.debug("배송지 등록 배송담당자 연락처 암호화 후 ===========>" + dlvrgChargerCttpcEnc);
			} catch (Exception e) {
				// TODO: handle exception
				log.error("insertDeliveryRegion DLVRG_CHARGER_CTTPC CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}

		int result = 0;

		//deliveryRegionMngVO.setDlvrgChargerCttpc(dlvrgChargerCttpc);
		deliveryRegionMngVO.setDlvrgChargerCttpc(dlvrgChargerCttpcEnc);
		deliveryRegionMngVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
		deliveryRegionMngVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		//기본배송지여부 N으로 초기값 세팅
		deliveryRegionMngVO.setBassDlvrgAt("N");

		result = deliveryRegionMngMapper.insertDeliveryRegion(deliveryRegionMngVO);
		deliveryRegionMngMapper.insertMbDlvrgBasHst(deliveryRegionMngVO);

		if (result < 0) {
			return -1;
		}
		return result;
	}

	@Override
	public List<CommonCodeVO> selectemailDomainList() throws Exception {
		// TODO Auto-generated method stub
		return deliveryRegionMngMapper.selectemailDomainList();
	}

}
