
package com.sorincorp.fo.my.service;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.bsnInfo.model.RltmEndTimeVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.invntry.model.InvntrySttusVO;
import com.sorincorp.comm.invntry.service.InvntrySttusService;
import com.sorincorp.comm.order.model.CnCntrctOrderBasVO;
import com.sorincorp.comm.order.model.CommFtrsFshgMngVO;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.comm.order.model.OrderEntrpsSetleMnVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.comm.order.service.CommDashboardWebsocketService;
import com.sorincorp.comm.order.service.CommFrontOrderWebsocketService;
import com.sorincorp.comm.order.service.CommFtrsFshgMngService;
import com.sorincorp.comm.order.service.CommLimitOrderRedisPubService;
import com.sorincorp.comm.order.service.CommLimitOrderService;
import com.sorincorp.comm.order.service.CommOrderService;
import com.sorincorp.comm.order.service.CommPrvsnlOrderService;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.chart.service.PcMntrngService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.model.MbEntrpsGradVO;
import com.sorincorp.fo.mb.service.EntrpsEtrService;
import com.sorincorp.fo.my.mapper.OrderLimitMapper;
import com.sorincorp.fo.my.model.OrderLimitVO;
import com.sorincorp.fo.my.model.OrderLimitValidVO;
import com.sorincorp.fo.pd.comm.constant.PdCommConstant;
import com.sorincorp.fo.pd.comm.constant.PdPropertyConstant;
import com.sorincorp.fo.pd.mapper.OrderMapper;
import com.sorincorp.fo.pd.model.ItemPriceSelectVO;
import com.sorincorp.fo.pd.model.LimitOrderModel;
import com.sorincorp.fo.pd.service.ItemPriceService;
import com.sorincorp.fo.pd.service.OrderService;

import lombok.extern.slf4j.Slf4j;

/**
 * 마이페이지 지정가 주문 서비스
 * @author srec0051
 *
 */
@Slf4j
@Service
public class OrderLimitServiceImpl implements OrderLimitService {

    @Autowired
    private OrderLimitMapper orderLimitMapper;

    @Autowired
    private OrderMapper orderMapper;

    /** websocket FO 수정 내역 전송을 위한 서비스 */
	@Autowired
	private CommFrontOrderWebsocketService commFrontOrderWebsocketService;
	/** websocket BO 수정 내역 전송을 위한 서비스 */
	@Autowired
	private CommDashboardWebsocketService commDashboardWebsocketService;

    @Autowired
	private PcInfoService pcInfoService;

    @Autowired
    private ItemPriceService itemPriceService;

    @Autowired
	private OrderService orderService;

    @Autowired
	private EntrpsEtrService entrpsEtrService;

    @Autowired
	private PcMntrngService pcMntrngService;

    @Autowired
	private MyCouponDtlsSerivce myCouponDtlsSerivce;

    @Autowired
    private CommonService commonService;

    @Autowired
    private ObjectMapper objectMapper;

    /** Redis 수정 내역 전송을 위한 서비스 */
    @Autowired
    private CommLimitOrderRedisPubService commLimitOrderRedisPubService;

    /** 지정가 주문 공통 서비스 */
    @Autowired
    private CommLimitOrderService commLimitOrderService;

    /** 외부 연계 api 호출 모듈 */
	@Autowired
	private HttpClientHelper httpClientHelper;

	/** 프로퍼티 상수 */
	@Autowired
	private PdPropertyConstant orProperty;

	@Autowired
	private InvntrySttusService invntrySttusService;

	@Value("${redisPubsub.uri.invntry}")
	private String invntryUri;

	@Autowired
	private BsnInfoService bsnInfoService;

	@Autowired
	private CommOrderService commOrderService;

	@Autowired
	private DashboardService dashboardService;

	@Autowired
    private UserInfoUtil userInfoUtil;

    @Autowired
    private CommFtrsFshgMngService commFtrsFshgMngService;

	@Autowired
	private CommPrvsnlOrderService commPrvsnlOrderService;


    /**
     * <pre>
     * 1. 지정가 주문정보 websocket publish<br>
     * 2. 지정가 주문정보 call api bo dashboard
     * </pre>
     * @date 2023. 3. 21.
     * @author srec0051
     * @param paramVo
     * @throws Exception
     */
    private void pubulishLimitOrder(OrderLimitVO paramVo) throws Exception {
        OrderLimitVO orderLimitVo = orderLimitMapper.selectOrderLimit(paramVo);

        Map<String,Object> param = new HashMap<>();
        param.put("limitOrderNo", orderLimitVo.getLimitOrderNo());

        /**
         * 주문 유형 구분을 위해 type 키 추가 수정:U 기존 ori*** 변수 필요
         */
        param.put("type", paramVo.getType());

        if (paramVo.getType().equals("U")) {
	        param.put("oriWt", paramVo.getOriLimitOrderWt());
	        param.put("oriAmount", paramVo.getOriLimitInputAmount());
        }

        // 지정가 주문정보 fo websocket 호출
        commFrontOrderWebsocketService.publishLimitOrder(param, false);

        // 지정가 주문정보 bo dashboard websocket 호출
		commDashboardWebsocketService.publishLimitOrder(paramVo.getLimitOrderNo(), true);
    }

    /**
     * 지정가 목록 총 카운트
     */
    @Override
    public int getOrderLimitTotCnt(OrderLimitVO searchVo) throws Exception {
    	if(StringUtils.equals("05", searchVo.getSleMthdCode())) {
    		// 가단가
    		return orderLimitMapper.getOrderPrvsnlLimitTotCnt(searchVo);
    	} else {
    		// 지정가
    		return orderLimitMapper.getOrderLimitTotCnt(searchVo);
    	}
    }

    /**
     * 지정가 목록 조회
     */
    @Override
    public List<OrderLimitVO> listOrderLimit(OrderLimitVO searchVo) throws Exception {
    	if(StringUtils.equals("05", searchVo.getSleMthdCode())) {
    		// 가단가
    		List<OrderLimitVO> listOrderPrvsnlLimit = orderLimitMapper.listOrderPrvsnlLimit(searchVo);

    		// 그룹코드별 실시간 가격 매핑
    		Map<String, PrSelVO> groupCodeMap = new HashMap<>();
    		for (OrderLimitVO order : listOrderPrvsnlLimit) {
    			if(groupCodeMap.containsKey(order.getGroupCode())) {
    				continue;
    			} else {
    				// 가장 최근 가격정보 조회 (프리미엄 제외 endPc)
    				PrSelVO prSelVO = Optional.ofNullable(commPrvsnlOrderService.getPreRealEndPc(order.getMetalCode(),
    																 order.getItmSn(),
    																 order.getDstrctLclsfCode(),
    																 order.getBrandGroupCode(),
    																 order.getBrandCode())).orElse(new PrSelVO());

    				groupCodeMap.put(order.getGroupCode(), prSelVO);
    			}
    		}

    		for (OrderLimitVO order : listOrderPrvsnlLimit) {
    			PrSelVO prSelVO = groupCodeMap.get(order.getGroupCode());

    			order.setRealEndpc(prSelVO.getNonPremiumEndPc()); // 프리미엄 제외 가격 세팅
    		}

    		return listOrderPrvsnlLimit;
    	} else {
    		// 지정가
    		return orderLimitMapper.listOrderLimit(searchVo);
    	}
    }

    /**
     * 지정가 취소하기
     */
    @Override
    public int doCancelOrderLimit(OrderLimitVO paramVo) throws Exception {
        paramVo.setLimitOrderSttusCode("40"); // 주문취소 (본인)
        int ret = orderLimitMapper.cancelOrderLimit(paramVo);
        orderLimitMapper.insertOrderLimitHst(paramVo);

        if (ret > 0) {
        	// 레디스 전송 로직
            try {
        		commLimitOrderRedisPubService.limitOrderMsgPublish(paramVo.getLimitOrderNo(), "D");
			} catch (Exception e) {
				log.error(e.getMessage());
				throw new Exception("지정가 주문 전송 실패\r\n관리자에게 문의 바랍니다.");
			}

            // 웹소켓 전송 로직 (fo + bo)
            paramVo.setType("C");	// type "C" : 취소
            pubulishLimitOrder(paramVo);

            // 지정가 주문취소시 사용된 쿠폰 리셋처리
            commLimitOrderService.limitOrderCouponUpdate(paramVo.getLimitOrderNo(), paramVo.getMberId());

            // 지정가 주문 취소 SMS 전송
            commLimitOrderService.limitOrderCancelSendSms(paramVo.getLimitOrderNo(), "N");

        } else {
        	throw new Exception("취소가 불가능한 상태입니다.\r\n관리자에게 문의 바랍니다.");
        }

        return ret;
    }

    /**
     * 지정가 수정하기
     */
    @Override
    public int doModifyOrderLimit(OrderLimitVO paramVo) throws Exception {
    	log.info("updateOrderLimit ::: IN");
        String type2 = paramVo.getType2();	// 1: 가격, 톤 / 2: 가격 / 3: 톤수 / 4: 쿠폰 / 5: 유효기간
        String couponApplcAt = paramVo.getCouponApplcAt();	// 쿠폰 사용 여부
        String usedCouponChangeAt = paramVo.getUsedCouponChangeAt();	// 사용 쿠폰 변경 여부
        String gradApplcAmount = paramVo.getGradApplcAmount();
        String[] couponSeqNoArray = {};	//사용 쿠폰 번호 리스트
        int ret = 0;
        long goodsUntpc = 0; 		// 단가
        long wtChangegld = 0; 		// 중량변동금
        long splpc = 0;				// 공급가

        //쿠폰 사용 , 등급할인 지정가 주문건 예수금
    	long reSlepc = 0;

        // 지정가 주문 정보 조회 (기준 프리미엄 환산 금액은 실시간 기준 프리미엄 기준 값을 대상으로 조회하므로 주의가 필요)
        OrderLimitVO orderLimitVo = Optional.ofNullable(selectOrderLimit(paramVo))
        		.orElseThrow(() -> {
        			log.error("지정가 주문 정보 조회 실패");
        			return new Exception("지정가 주문 정보 조회 실패\r\n관리자에게 문의 바랍니다.");
        		});
        log.debug(">> 기존 지정가 주문 정보 : {}", orderLimitVo);

        // 23-10-17 변경사항 : 최초 지정가 주문 등록시 프리미엄 데이터를 사용 안 하는 정책으로 변경됨에 따라, 기존 프리미엄 데이터도 최신 데이터로 업데이트
    	// 실시간 가격 조회
		PrSelVO prSelVO = getRealTimePrice(orderLimitVo.getMetalCode(),
				orderLimitVo.getItmSn(),
				orderLimitVo.getDstrctLclsfCode(),
				orderLimitVo.getBrandGroupCode(),
				orderLimitVo.getBrandCode());

		// 프리미엄 가격 정보 조회
		LivePremiumVO livePremiumVO = Optional.ofNullable(
				pcInfoService.getLivePremiumInfo("present", prSelVO.getPremiumNo())).orElseThrow(() -> {
					log.error("프리미엄 가격 조회 실패");
					return new Exception("프리미엄 가격 조회 실패\r\n관리자에게 문의 바랍니다.");
				});
		long premiumAmount = livePremiumVO.getSlePremiumAmount();

		// 프리미엄 가격 정보 갱신
		paramVo.setPremiumId(prSelVO.getPremiumId());													// 프리미엄 ID
		paramVo.setLimitPremiumStdrAmount(livePremiumVO.getPremiumStdrAmount().longValue());			// 지정가 프리미엄 기준 금액
		paramVo.setLimitDstrctChangeAmount(livePremiumVO.getDstrctChangeAmount().longValue());			// 지정가 권역 변동 금액
		paramVo.setLimitBrandGroupChangeAmount(livePremiumVO.getBrandGroupChangeAmount().longValue());	// 지정가 브랜드 그룹 변동 금액
		paramVo.setLimitBrandChangeAmount(livePremiumVO.getBrandChangeAmount().longValue());			// 지정가 브랜드 변동 금액
		paramVo.setLimitPremiumExclAmount(paramVo.getLimitInputAmount() - premiumAmount);				// 지정가 프리미엄 제외 금액 (지정가 - 프리미엄)

		paramVo.setSleUnitWt(orderLimitVo.getSleUnitWt());

        /** 가격,톤수 or 가격 수정일때만 실시간 가격 체크 (= 1, 2) */
        if(type2.equals("1") || type2.equals("2")) {

        	// 천원 단위 반올림
        	long limitInputAmount = Math.round(paramVo.getLimitInputAmount() / 1000.0) * 1000;
        	paramVo.setLimitInputAmount(limitInputAmount);

			// 지정가 VS 실시간 가격 비교 (지정가가 실시간 가격 이상이면 불가)
			goodsUntpc = prSelVO.getNonPremiumEndPc() + premiumAmount;
			log.info("실시간 가격 = {}, 입력 지정가 가격 = {}", goodsUntpc, paramVo.getLimitInputAmount());

			if (goodsUntpc <= paramVo.getLimitInputAmount()) {
				log.error("현재 실시간 가격 보다 지정가는 낮게 입력해주세요. 실시간 가격 = {}, 입력 지정가 가격 = {}", goodsUntpc, paramVo.getLimitInputAmount());
				throw new Exception("현재 실시간 가격 보다 지정가는 낮게 입력해주세요.");
			}

			// 20230504 설계변경
//			// 기준 프리미엄 환산 금액 (fn_getStdrPremiumCnvrsnAmount)
//			paramVo.setStdrPremiumCnvrsnAmount(orderLimitVo.getStdrPremiumCnvrsnAmount());

			/**
			 * 2023.05.19 최초 지정가 주문 등록시 프리미엄ID 기준
			 * 23-10-17 변경사항 : 최초 지정가 주문 등록시 프리미엄 데이터를 사용 안 하는 정책으로 변경, 실시간 프리미엄 데이터 사용
			 */
//			LivePremiumVO limitPremiumVo = Optional.ofNullable(pcInfoService.getLivePremiumInfo(
//					"past"
//					, orderLimitVo.getPremiumId()
//					, orderLimitVo.getMetalCode()
//					, orderLimitVo.getItmSn(), orderLimitVo.getDstrctLclsfCode()
//					, orderLimitVo.getBrandGroupCode()
//					, orderLimitVo.getBrandCode()
//					, null
//					)).orElseThrow(() -> {
//						log.error("지정가 프리미엄 가격 조회 실패");
//						return new Exception("지정가 프리미엄 가격 조회 실패\r\n관리자에게 문의 바랍니다.");
//					});

			// 가격만 수정일때 기존 톤수 설정
			if (type2.equals("2")) {
				paramVo.setLimitOrderWt(orderLimitVo.getLimitOrderWt());
			}

		/** 톤수만 수정 (=3) */
        } else if(type2.equals("3"))  {
    		// 기존 가격으로 설정
    		paramVo.setLimitInputAmount(orderLimitVo.getLimitInputAmount());
//        	// 기존 지정가 프리미엄 제외 금액
//        	paramVo.setLimitPremiumExclAmount(orderLimitVo.getLimitPremiumExclAmount());
    	}

        /** 톤수 수정시 예상배송비 재계산 (=1, 3)
         * - 단, 주문의 주문단위가 동일해야 가능
         *  */
		if(type2.equals("1") || type2.equals("3")) {
        		// 주문단위
				long orderUnit = orderLimitVo.getSleUnitWt();
        		// 기존수량
        		long orderWt = orderLimitVo.getLimitOrderWt();
        		// 수정수량
        		long newOrderWt = paramVo.getLimitOrderWt();

        		// 1. 최초주문의 배송비단가를 구한다 (예상배송비 / (최초수량 / 주문단위))
        		long expectDlvrfUntPc = orderLimitVo.getExpectDlvrf() / (orderWt / orderUnit);
        		// 2. 최초주문의 배송비단가를 기준으로 재계산 ((감량수량/주문단위) * 배송비단가)
        		long newExpectDlvrf = (newOrderWt / orderUnit) * expectDlvrfUntPc;

        		log.info("기존수량 : {}, 수정수량 : {}, 배송비단가 : {}, 예상배송비 : {}", orderWt, newOrderWt, expectDlvrfUntPc, newExpectDlvrf);

        		paramVo.setExpectDlvrf(newExpectDlvrf);
        } else {
        	// 톤수 수정이 아니라면 기존 톤수로 설정
        	paramVo.setExpectDlvrf(orderLimitVo.getExpectDlvrf());
        }

        // 아이템순번에 해당하는 중량변동금 설정 = 최종상품단가 * 중량변동
    	paramVo.setItmSn(orderLimitVo.getItmSn());
    	double wtChange = orderLimitMapper.getWtChange(paramVo);
    	wtChangegld = (long) (paramVo.getLastGoodsUntpc() * wtChange);
    	paramVo.setWtChange(BigDecimal.valueOf(wtChange));
    	paramVo.setWtChangegld(wtChangegld);


        /** 공급가, 부가세, 판매가
         * (결제수단에 따른 인상금액 등 미포함 - 주문 실행시 다시 들어감)
         *
         * 23-05-19 변경사항 : "최종 상품 단가"로 계산 되도록 변경
         * */

        // 주문가
        long orderPc = paramVo.getLastGoodsUntpc() * paramVo.getLimitOrderWt();

        // 공급가 = 주문가 + 중량변동금 + 예상배송비

       //쿠폰 사용 여부 확인
//       if(Boolean.TRUE.equals(type2.equals("4"))) {
           String couponTyCode = paramVo.getCouponTyCode();	// 쿠폰 사용 여부
           CouponVO dlvyVo = new CouponVO();

    	   if(Boolean.TRUE.equals(couponApplcAt.equals("Y"))) {
    		   // 사용 쿠폰 변경 여부 확인
    		   if(Boolean.TRUE.equals(usedCouponChangeAt.equals("Y"))) {
    			   // 기존 사용 쿠폰 초기화
    			   commLimitOrderService.limitOrderCouponUpdate(paramVo.getLimitOrderNo(), paramVo.getMberId());
    			   couponSeqNoArray = paramVo.getCouponSeqNo().split(",");
    			   for (int pos = 0; pos < couponSeqNoArray.length; pos++) {
    				   if(couponTyCode.equals("01")) {
    					   dlvyVo.setCouponSn(couponSeqNoArray[pos]);
    					   orderMapper.updateCouponIsuBas("05", paramVo.getLimitOrderNo(), "0", "0", paramVo.getMberId(), couponSeqNoArray[pos]);
    					   commonService.insertTableHistory("CP_COUPON_ISU_BAS", dlvyVo);
    				   }else {
    					   dlvyVo.setCouponSn(couponSeqNoArray[pos]);
    					   orderMapper.updateCouponIsuBas("05", paramVo.getLimitOrderNo(), "0", "0", paramVo.getMberId(), couponSeqNoArray[pos]);
    					   commonService.insertTableHistory("CP_COUPON_ISU_BAS", dlvyVo);
    				   }
    			   }
    		   }
    	   }else {
    		   // 기존 사용 쿠폰 초기화
    		   commLimitOrderService.limitOrderCouponUpdate(paramVo.getLimitOrderNo(), paramVo.getMberId());
    	   }
//       }
//        if(Boolean.TRUE.equals(type2.equals("4"))) {
//    		//쿠폰로직 수행
//        	orderService.couponSelectList(orderModel, orderWt);
//			splpc = orderService.couponUse(orderModel, orderWt, newGetBlListUseStatus);
//
//    	} else {
    		splpc = orderPc + wtChangegld + paramVo.getExpectDlvrf();
//    	}

        // 부가세
        long vat = (long) (splpc * 0.1);
        // 판매가
        long slepc = splpc + vat;

        log.info("주문가 : {}, 공급가 : {}, 부가세 : {}, 판매가 : {}", orderPc, splpc, vat, slepc);

        paramVo.setOrderPc(orderPc);
        paramVo.setSplpc(splpc);
        paramVo.setVat(vat);
        paramVo.setSlepc(slepc);

        // 업체 결제 수단 정보 가져오기
        OrderEntrpsSetleMnVO entrpsSetleMnInfo = orderService.getEntrpsSetleMnInfo(orderLimitVo.getEntrpsNo(), "03", orderLimitVo.getMetalCode(),
        		orderLimitVo.getItmSn(), orderLimitVo.getDstrctLclsfCode(), orderLimitVo.getBrandGroupCode(), orderLimitVo.getBrandCode(), orderLimitVo.getSleMthdDetailCode());

        // 실제 결제 금액
        long chkAmount = 0;

        //쿠폰 사용 지정가 주문건 예수금
        reSlepc = getReAdvrcvAmount(paramVo);

        // 23-05-19 변경사항 : 예수 금액 세팅 로직 추가
        // 증거금 주문일 경우, 예수 금액으로 "최초 결제 금액"을 넣어주고, 그 외의 경우 판매가로 넣어준다.
        if(StringUtils.equals(orderLimitVo.getSetleMthdCode(), "90")) {
        	// 업체 결제 수단 정보에서 증거금 비율 금액 get
        	long purchsInclnStepAmount = entrpsSetleMnInfo.getEntrpsPurchsInclnGradeInfoAllList().stream()
				.filter(data -> ( data.getPurchsInclnStepRate() == orderLimitVo.getWrtmMummWrtmRate() )).collect(Collectors.toList()).get(0).getPurchsInclnStepAmount();

        	// 최초 결제 금액 = 증거금 비율 금액 * 주문중량
        	chkAmount = purchsInclnStepAmount * paramVo.getLimitOrderWt();
        } else {
        	if(Boolean.TRUE.equals(couponApplcAt.equals("Y"))) {
        		chkAmount = reSlepc;
        	}else if((gradApplcAmount != null) && !gradApplcAmount.equals("")) {
        		chkAmount = reSlepc;
        	}else if(StringUtils.equals("0304", paramVo.getSleMthdDetailCode())) {
        		chkAmount = reSlepc;
        	}else if(StringUtils.equals("Y", orderLimitVo.getSmlqyPurchsAt())) {
        		chkAmount = reSlepc;
        	}else {
        		chkAmount = slepc;
        	}
        }

        paramVo.setAdvrcvAmount(chkAmount);

        // 23-06-12 변경사항 : 결제 가능 금액 체크 로직 추가
        // 결제 수단 별 결제 가능 금액(ewallet 잔액, 담보보증 남은 한도)을 체크한다.
        // 체크 시, 현재 지정가 주문의 예수금을 제외하고, 결제 수단이 동일한 미결제 지정가 주문들의 총 예수금을 고려하여 체크한다.

        // 지정가 주문으로 발생한 예수금 조회, 현재 지정가 주문의 예수금은 제외한다.
     	long totalAdvrcvAmount = orderLimitMapper.getTotalAdvrcvAmount(orderLimitVo);

        if(StringUtils.equals(orderLimitVo.getSetleMthdCode(), "10") || StringUtils.equals(orderLimitVo.getSetleMthdCode(), "90")) {

			// 이월렛 잔금 조회
			long ewalletMoney = 0;
			Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getEwalletMoneyUrl(), Collections.singletonMap("entrpsNo", orderLimitVo.getEntrpsNo()));
			log.warn(">> E-WALLET 잔금 조회 resObj : " + resObj);
			// 이월렛 잔금 조회 API 호출 체크
			if(resObj == null) {
				throw new CommCustomException("이월렛 잔금 조회 호출 실패,\n관리자에게 문의 바랍니다.");
			} else {
				if(resObj.get(PdCommConstant.EWALLET_DATA_KEY) != null) {
					Map<String, Object> dataObj = (Map<String, Object>) resObj.get(PdCommConstant.EWALLET_DATA_KEY);
					ewalletMoney =  NumberUtils.toLong(String.valueOf(dataObj.get(PdCommConstant.EWALLET_MONNY_KEY)));
				} else {
					log.info("OrderServiceImpl setPriceInfoByExpectDlvrf line-1543 vo.toString() >> " + orderLimitVo.toString());
					throw new CommCustomException("Ewallet 잔금 조회 실패 (사유 : " + resObj.get("resultMsg") + ")");
				}
			}

			// 이월렛 금액 부족 체크
			// 이월렛 잔액 - 동일한 결제 수단으로 주문된 미체결 지정가 주문의 예수금 총합 < 잔액 체크할 금액
			if(ewalletMoney - totalAdvrcvAmount < chkAmount) {
				if(totalAdvrcvAmount == 0) {
					throw new CommCustomException("Ewallet 금액 부족");
				} else {
					throw new CommCustomException(""
							+ "현재 지정가 주문에 따른 결제 대기 금액("
							+ StringUtil.formatMoney(String.valueOf(totalAdvrcvAmount))
							+ "원)이 존재합니다. \r\n"
							+ "수정하기를 희망하시면, 접수된 지정가 주문 건을 취소 후 진행하여 주세요");
				}
			}
        } else if(StringUtils.equals(orderLimitVo.getSetleMthdCode(), "20") || StringUtils.equals(orderLimitVo.getSetleMthdCode(), "40")) {
        	// 담보 보증 정보 조회를 위한 OrderModel 객체 생성 및 데이터 세팅
        	OrderModel orderModel = new OrderModel();
        	orderModel.setEntrpsNo(orderLimitVo.getEntrpsNo());
        	orderModel.setCdtlnSvcSeCode(entrpsSetleMnInfo.getCdtlnSvcSeCode());

        	// 담보 보증 정보 조회 & 담보 잔액 get
        	String mrtggBlce = orderService.getMrtggGrntyLmtInqire(orderModel).getMrtggBlce();

			// (전자상거래보증 or 케이지크레딧) 남은 한도 부족 체크
			// (전자상거래보증 or 케이지크레딧) 남은 한도 - 주문된 미체결 지정가 주문의 예수금 총합 < 잔액 체크할 금액
			if(Long.parseLong(mrtggBlce) - totalAdvrcvAmount < slepc) {
				if(totalAdvrcvAmount == 0) {
					throw new CommCustomException(entrpsSetleMnInfo.getViewCdtlnSvcSeNm() + " 남은 한도 부족");
				} else {
					throw new CommCustomException(""
							+ "현재 지정가 주문에 따른 결제 대기 금액("
							+ StringUtil.formatMoney(String.valueOf(totalAdvrcvAmount))
							+ "원)이 존재합니다. \r\n"
							+ "수정하기를 희망하시면, 접수된 지정가 주문 건을 취소 후 진행하여 주세요");
				}
			}
        }

        /** 유효 기간(시간 or 일자) 변경 시 체크 */
        // 수정 시 OrderServiceImpl.java 파일도 함께 수정 필수(동일로직 사용)
        if(paramVo.getValidPdChangeAt().equals("Y")) {
        	String dlivyRequstDe = orderLimitVo.getDlivyRequstDe().replaceAll("-", ""); // 배송요청일
        	String minLimitOrderNightTime = itemPriceService.getMinLimitOrderNightTime(orderLimitVo.getMetalCode(), DateUtil.getNowDate(), 2).replaceAll("-", "");

        	RltmEndTimeVO rltmEndTimeVO = bsnInfoService.getRltmEndTime();
        	if (rltmEndTimeVO.getRltmMidTimeValue().equals(paramVo.getLimitOrderValidTime())) {	// 1. 지정가 유효 시간이 17시인 경우
        		if (Integer.parseInt(DateUtil.getNowDateTime("HH")) >= rltmEndTimeVO.getRltmMidTimeValue2()) {	// 현재 시간이 유효시간 이후일 때 유효성 검사 실패 처리
        			throw new CommCustomException(rltmEndTimeVO.getRltmMidTimeValue2()+"시 이전에만 선택 가능합니다.");
        		}

        	} else if (rltmEndTimeVO.getRltmEndTimeValue().equals(paramVo.getLimitOrderValidTime())) {	// 2. 지정가 유효 시간이 22시인 경우
        		if (Integer.parseInt(minLimitOrderNightTime) > Integer.parseInt(dlivyRequstDe)) {	// XXX : 야간장 신청시 2일 신청 체크 (commit id: f0dcc2)
        			if(StringUtils.isNotEmpty(orderLimitVo.getCntrctOrderNo())) {
        				// 계약구매일 경우
        				throw new CommCustomException("배송요청일이 당일 또는 익일일 경우\n지정가 주문이 불가능합니다.\n발주 취소 후 재발주해 주십시오.");
        			} else {
        				throw new CommCustomException("배송요청일이 익일일 경우\n당일 저녁 "+rltmEndTimeVO.getViewRltmEndTime()+"로 선택하실 수 없습니다.\n배송요청일을 수정하여 재주문해 주십시오.");
        			}
        		}
        	}
        }

        ret = orderLimitMapper.updateOrderLimitAmtWithWt(paramVo);
        orderLimitMapper.insertOrderLimitHst(paramVo);

        if (ret > 0) {
        	// 레디스 전송 로직
        	try {
        		commLimitOrderRedisPubService.limitOrderMsgPublish(paramVo.getLimitOrderNo(), "U");
			} catch (Exception e) {
				log.error(e.getMessage());
				throw new Exception("지정가 주문 전송 실패\r\n관리자에게 문의 바랍니다.");
			}

            // 웹소켓 전송 로직 + bo dashboard
        	paramVo.setType("U");	// type "U" : 수정
            pubulishLimitOrder(paramVo);

        } else {
        	throw new Exception("수정이 불가능한 상태입니다.\r\n관리자에게 문의 바랍니다.");
        }

        log.info("updateOrderLimit ::: OUT");

        return ret;
    }

	/**
	 * 실시간 판매 가격 정보 조회
	 * */
	private PrSelVO getRealTimePrice(String metalCode, int itmSn, String dstrctLclsfCode, String brandGroupCode,
			String brandCode) throws Exception {
		PrSelVO prSelVO = Optional.ofNullable(pcInfoService.getNewestPrSelRltm(
				metalCode, itmSn, dstrctLclsfCode, brandGroupCode, brandCode, DateUtil.getNowDate()
				)).orElseThrow(() -> {
					log.error("실시간 판매가격 정보 조회 실패");
					return new Exception("실시간 판매가격 정보 조회 실패\r\n관리자에게 문의 바랍니다.");
				});

		log.debug(">> 실시간 판매 가격 정보 조회 : {}", prSelVO);

		return prSelVO;
	}

	/**
	 * 지정가 주문, 취소 제한 (업체 공통)
	 */
	@Override
	public OrderLimitValidVO validCreateAndCancel(String entrpsNo) throws Exception {
		return orderLimitMapper.validCreateAndCancel(entrpsNo);
	}

	/**
	 * 지정가 미체결 여부
	 */
	@Override
	public int validOrderLimitSttusCode(OrderLimitVO paramVo) throws Exception {
		return orderLimitMapper.validOrderLimitSttusCode(paramVo);
	}

	/**
	 * 지정가 주문 조회
	 */
	@Override
	public OrderLimitVO selectOrderLimit(OrderLimitVO paramVo) throws Exception {
		return orderLimitMapper.selectOrderLimit(paramVo);
	}

	/**
	 * 모달창에서 사용되는 데이터를 조회하여 model 객체에 세팅한다
	 */
	@Override
	public void setOrderLimitData(OrderLimitVO orderLimitVO, ModelMap model) throws Exception {
		String entrpsNo = orderLimitVO.getEntrpsNo();
		String pricingNo = orderLimitVO.getPricingNo();

		// 수정 모달창 여부 세팅, 주문 모달창과의 로직 분기를 위해 필수
		model.addAttribute("isUpdate", "update");

		// 장바구니 데이터 조회를 위한 세팅
		ItemPriceSelectVO itemPriceSelectVo = new ItemPriceSelectVO();
		itemPriceSelectVo.setPricingNo(pricingNo);

		// 과부하 테스트 주문일 경우 pricingNo 가 null 값이기 때문에 추가 검색 조건 세팅
		// 23-06-01 변경사항 : 과부하 테스트 여부 판단 조건 변경 : 장바구니 번호가 "TEST_LIMIT-" 로 시작하는 주문
		// 23-06-05 변경사항 : 과부하 테스트 주문 조회 조건 변경 - 하드 코딩된 pricingNo만 사용
		if (!StringUtils.startsWith(orderLimitVO.getBsktNo(), "TEST_LIMIT-")) {
			itemPriceSelectVo.setEntrpsNo(entrpsNo);
		}

		List<ItemPriceSelectVO> orderBasketList = itemPriceService.selectOrderBasketList(itemPriceSelectVo);

		if (orderBasketList.isEmpty()) {
			log.info("OrderLimitServiceImpl.java - 장바구니 관련 데이터 조회 실패");
			throw new CommCustomException("에러 발생\n관리자에게 문의 바랍니다.");
		}

		itemPriceSelectVo = orderBasketList.get(0);
		itemPriceSelectVo.setSmlqyPurchsAt(orderLimitVO.getSmlqyPurchsAt());
		itemPriceSelectVo.setBlNo(orderLimitVO.getBlNo());

		// 계약구매일 경우
		if(StringUtils.isNotEmpty(orderLimitVO.getCntrctOrderNo())) {
			itemPriceSelectVo.setSleMthdDetailCode("0304");

			// 계산보기 팝업 공통 스크립트 사용위해 데이터 세팅
			// 1. 계약_발주 정보
	        CnCntrctOrderBasVO cntrctInfo = new CnCntrctOrderBasVO();
	        cntrctInfo.setCrncySeCode(orderLimitVO.getCrncySeCode());
	        cntrctInfo.setCrncySeNm(orderLimitVO.getCrncySeNm());
	        cntrctInfo.setUntpcMntnfrmlaCode(orderLimitVO.getUntpcMntnfrmlaCode());
	        cntrctInfo.setUntpcMntnfrmlaNm(orderLimitVO.getUntpcMntnfrmlaNm());
	        cntrctInfo.setPremiumPc(orderLimitVO.getCntrctPremiumPc());
	        model.addAttribute("cntrctVO", cntrctInfo);

			// 2. 조정계수 조회
	        CommFtrsFshgMngVO ftrsFshgMngVO = Optional.ofNullable(commFtrsFshgMngService.commFtrsFshgManageDtlListByToday("B").stream()
	                                                  .filter(data -> ( StringUtils.equals(data.getMetalCode(), orderLimitVO.getMetalCode()))).collect(Collectors.toList()).get(0))
	                                                  .orElseThrow(() -> {return new CommCustomException("LME, 환율 조정계수 정보가 없습니다.");});
	        model.addAttribute("ftrsFshgMngVO", ftrsFshgMngVO);

	        // 3. 평균가 주문 여부
	        model.addAttribute("avrgpcYn", "Y");

	        // 4. 출고요청일 기준 지정가 유효 일자
 			String maxLimitOrderValideDe = itemPriceService.getMinLimitOrderNightTime(orderLimitVO.getMetalCode(), orderLimitVO.getDlivyRequstDe().replaceAll("-", ""), -2);
 			model.addAttribute("maxLimitOrderValideDe", maxLimitOrderValideDe.replaceAll("-", ""));
		}

		model.addAttribute("entrpsNo", entrpsNo);	// 호가 영역에서 "본인 주문" 구분을 위해 세팅
		model.addAttribute("itemPriceSelectVo", itemPriceSelectVo);	// 지정가 주문 시와 동일한 로직으로 화면 구성하기 위해 관련 장바구니 데이터 세팅

		Map<String, Object> limitOrderData = itemPriceService.selectLimitOrderData(itemPriceSelectVo);	// 호가 영역 구성 데이터 조회
		model.addAttribute("limitOrderTotalCnt", limitOrderData.get("limitOrderTotalCnt"));	// 조건에 맞는 지정가 주문 총 갯수
		model.addAttribute("limitOrderListMap", limitOrderData.get("limitOrderListMap"));	// 조건에 맞는 지정가 주문 목록

		// 현재 내 순위(currentMyRank) 조회 및 세팅
		List<LimitOrderModel> limitOrderList = ((Map<Long, List<LimitOrderModel>>)limitOrderData.get("limitOrderListMap")).get(orderLimitVO.getLimitInputAmount());

		if(limitOrderList != null && !limitOrderList.isEmpty()) {
			for (LimitOrderModel limitOrderModel : limitOrderList) {
				if(StringUtils.equals(limitOrderModel.getLimitOrderNo(), orderLimitVO.getLimitOrderNo())) {
					model.put("currentMyRank", limitOrderModel.getLimitsCnclsPriorRank());
					break;
				}
			}
		} else {
			log.info("OrderLimitServiceImpl.java - 현재 내 순위 데이터 조회 실패");
			throw new CommCustomException("에러 발생\n관리자에게 문의 바랍니다.");
		}

		// 지정가 주문 시점의 브랜드 변동금 목록 조회
		// 23-10-17 변경사항 : 최초 지정가 주문 등록시 프리미엄 데이터를 사용 안 하는 정책으로 변경, 실시간 프리미엄 데이터 사용
		List<LivePremiumVO> brandChangeAmountList = Optional.ofNullable(
				pcInfoService.getLivePremiumInfoList(
					"present", null, orderLimitVO.getMetalCode()
					, orderLimitVO.getItmSn(), orderLimitVO.getDstrctLclsfCode(), orderLimitVO.getBrandGroupCode()
					, null, DateUtil.getNowDateTime("yyyyMMddHHmmss")
				)
			).orElseThrow(() -> {return new CommCustomException("프리미엄 가격 미존재,\n관리자에게 문의 바랍니다.");})
			.stream().filter(livePremiumVO -> !StringUtils.equals(livePremiumVO.getBrandCode(), "0000000000")).collect(Collectors.toList());

		model.addAttribute("brandChangeAmountList", brandChangeAmountList);

		// 브랜드 변동 금액 조회
		if (StringUtils.equals(orderLimitVO.getBrandCode(), "0000000000")) {	// "브랜드 무관"일 시 지정가 주문 시점의 제일 비싼 브랜드 변동금을 세팅
			model.addAttribute("brandChangeAmount", brandChangeAmountList.get(0).getBrandChangeAmount());
		} else {	// 해당하는 브랜드의 변동금을 세팅
			for (LivePremiumVO livePremiumVO : brandChangeAmountList) {
				if (StringUtils.equals(livePremiumVO.getBrandCode(), orderLimitVO.getBrandCode())) {
					model.addAttribute("brandChangeAmount", livePremiumVO.getBrandChangeAmount());
					break;
				}
			}
		}

		// 결제 정보 관련 데이터 세팅
		OrderEntrpsSetleMnVO entrpsSetleMnInfo = orderService.getEntrpsSetleMnInfo(entrpsNo, itemPriceSelectVo.getSleMthdCode(), itemPriceSelectVo.getMetalCode(),
				itemPriceSelectVo.getItmSn(), itemPriceSelectVo.getDstrctLclsfCode(), itemPriceSelectVo.getBrandGroupCode(), itemPriceSelectVo.getBrandCode(), null);
		entrpsSetleMnInfo.setPartDlivyRepyAt(orderLimitVO.getPartDlivyRepyAt()); // 부분 출고 상환 여부
		model.addAttribute("entrpsSetleMnInfo", entrpsSetleMnInfo);

		// 서비스 약관 데이터 조회 및 세팅
		List<EntrpsEtrVO> selectOrderStplat = entrpsEtrService.selectEntrpsEtrStplat();

		if (CollectionUtils.isEmpty(selectOrderStplat)) {
			model.addAttribute("orderStplatInfo", new EntrpsEtrVO());
			model.addAttribute("limitsOrderStplat", new EntrpsEtrVO());
		} else {
			for (EntrpsEtrVO entrpsEtrVO : selectOrderStplat) {
				if (StringUtils.equals(entrpsEtrVO.getStplatSeCode(), "01")) { // 01 : 기본 서비스 약관
					model.addAttribute("orderStplatInfo", entrpsEtrVO);
				} else if (StringUtils.equals(entrpsEtrVO.getStplatSeCode(), "11")) { // 11 : 지정가 서비스 약관
					model.addAttribute("limitsOrderStplat", entrpsEtrVO);
				}
			}
		}

		// 차트 리스트 구성에 필요한 데이터 조회
		Map<String, Object> chartList = pcMntrngService.getItemChartDate(itemPriceSelectVo.getMetalCode(), itemPriceSelectVo.getSleMthdCode(), itemPriceSelectVo.getMetalClCode());

		// 스크립트에서 사용 하기위한 JSON데이터로 변환
		String jsonMainChart = objectMapper.writeValueAsString(chartList);

		model.addAttribute("metalCode", itemPriceSelectVo.getMetalCode());
		model.addAttribute("chartList", chartList);
		model.addAttribute("jsonChartList", jsonMainChart);


		// ---배송비 관련 항목 표시를 위한 데이터 조회 및 세팅
		OrderModel orderModel = new OrderModel();
		orderModel.setSameDayDeliveryAt(CommonConstants.YN_N);
		orderModel.setDlivyRequstDe(orderLimitVO.getDlivyRequstDe());
		orderModel.setDstrctMlsfcCode(orderLimitVO.getDstrctMlsfcCode());
		orderModel.setDlvrgPostNo(orderLimitVO.getReceptEntrpsPostNo());

		String lastSvcSeCode = StringUtils.EMPTY; // 서비스 구분 코드 [00:정상, 01:배송불가, 02:서비스가능지역아님]
		String dstrctMlsfcNm = StringUtils.EMPTY; // 권역 중분류 코드명
		long sectionPrice = 0; // 구간금액

		if (StringUtils.equals(orderLimitVO.getDlvyMnCode(), "01")) {
			// 배송 요율 조회를 위한 기본조건 설정
			orderModel.setMetalCode(orderLimitVO.getMetalCode());
			orderModel.setItmSn(orderLimitVO.getItmSn());
			orderModel.setOrderWt(orderLimitVO.getLimitOrderWt());
			commOrderService.setDlvyTariffBaseInfo(orderModel);

			Map<String, String> selectDlvyTariffInfo = commOrderService.selectDlvyTariffInfo(orderModel);
			sectionPrice = Long.parseLong(Optional.ofNullable(String.valueOf(selectDlvyTariffInfo.get("DLVY_TARIFF"))).orElse("0"));
			lastSvcSeCode = String.valueOf(selectDlvyTariffInfo.get("SVC_SE_CODE"));
			dstrctMlsfcNm = String.valueOf(selectDlvyTariffInfo.get("DSTRCT_MLSFC_NM"));
		}

		model.put("sectionPrice", Optional.ofNullable(sectionPrice).orElse(0L));
		model.put("lastSvcSeCode", lastSvcSeCode);
		model.put("dstrctMlsfcNm", dstrctMlsfcNm);
		// ---배송비 관련 항목 표시를 위한 데이터 조회 및 세팅 끝

		// 23-07-10 변경사항 : 실시간 재고 데이터 수신 uri 및 실시간 재고 데이터 추가
		// 8. 실시간 재고 데이터 수신 uri
		model.addAttribute("invntryUri", invntryUri);

		// 9. 실시간 재고 데이터 : 해당 브랜드 전체에 대한 실시간 재고 조회
		String key = String.join("_"
				, itemPriceSelectVo.getMetalCode()
				, String.valueOf(itemPriceSelectVo.getItmSn())
				, itemPriceSelectVo.getDstrctLclsfCode()
				, itemPriceSelectVo.getBrandGroupCode()
				, itemPriceSelectVo.getBrandCode());
		// 소량구매일 경우, 해당 BL에 대한 실시간 재고 조화
		if("Y".equals(itemPriceSelectVo.getSmlqyPurchsAt())) {
			key += "_" + orderLimitVO.getBlNo();
		}
		InvntrySttusVO invntrySttusVO = invntrySttusService.getInvntrySttusInfoMap(itemPriceSelectVo.getMetalCode()).get(key);
		long totSleInvntryUnsleBundleBnt = invntrySttusVO == null ? 0 : invntrySttusVO.getTotSleInvntryUnsleBundleBnt();
		model.addAttribute("totSleInvntryUnsleBundleBnt", totSleInvntryUnsleBundleBnt);
		model.addAttribute("invntrySttusVO", invntrySttusVO);

		// 10. 쿠폰 리스트
		CouponVO couponVO = new CouponVO();
		couponVO.setEntrpsNo(entrpsNo);
		couponVO.setMetalCode(orderLimitVO.getMetalCode());
		couponVO.setCouponApplcOrderNo(orderLimitVO.getLimitOrderNo());
//		couponVO.setSearchPmgId("PD");// PD쪽 조회임

		List<CouponVO> untCouponList = myCouponDtlsSerivce.couponList(couponVO, "01");
		List<CouponVO> dlvyCouponList = myCouponDtlsSerivce.couponList(couponVO, "03");

		model.addAttribute("untCouponList", untCouponList);
		model.addAttribute("dlvyCouponList", dlvyCouponList);

		 /* 페이백 기능 추가 2024/02/14 */
		//회원_업체 등급 기준 구매 수량
		MbEntrpsGradVO mbEntrpsGradStdrPurchsQy = dashboardService.selectMbEntrpsGradStdrPurchsQy();
		model.addAttribute("mbEntrpsGradStdrPurchsQy", mbEntrpsGradStdrPurchsQy);
		//등급 할인 금액 리스트
		List<MbEntrpsGradVO> mbGradDscntAmountList = dashboardService.selectMbGradDscntAmountList();
		model.addAttribute("mbGradDscntAmountList", mbGradDscntAmountList);
		//당월 구매 수량
		int totRealOrderWtSum = dashboardService.selectMbTotRealOrderWtSum(userInfoUtil.getAccountInfo().getEntrpsNo());
		model.addAttribute("totRealOrderWtSum", totRealOrderWtSum);
		//전월 기준 구매 정보(MB_ENTRPS_MNBY_PURCHS_BNEF_BAS)
		MbEntrpsGradVO mbEntrpsMnbyPurchsInfo = dashboardService.mbEntrpsMnbyPurchsInfo(userInfoUtil.getAccountInfo().getEntrpsNo());
		model.addAttribute("mbEntrpsMnbyPurchsInfo", mbEntrpsMnbyPurchsInfo);
		//상시 할인 금액 리스트(3000,4000,5000)
		List<MbEntrpsGradVO> cpAtmcIsuCouponInfoList= dashboardService.selectcpAtmcIsuCouponInfoList();
		model.addAttribute("cpAtmcIsuCouponInfoList", cpAtmcIsuCouponInfoList);
		
		if (userInfoUtil.getAccountInfo() != null) {
			String entrpsPayBackDscntUseAt = userInfoUtil.getAccountInfo().getEntrpsPayBackDscntUseAt() != null ? userInfoUtil.getAccountInfo().getEntrpsPayBackDscntUseAt() : "Y";
			String entrpsMnbyPurchsBnefUseAt = userInfoUtil.getAccountInfo().getEntrpsMnbyPurchsBnefUseAt() != null ? userInfoUtil.getAccountInfo().getEntrpsMnbyPurchsBnefUseAt() : "Y";
			
			model.addAttribute("entrpsPayBackDscntUseAt", entrpsPayBackDscntUseAt);
			model.addAttribute("entrpsMnbyPurchsBnefUseAt", entrpsMnbyPurchsBnefUseAt);
		}
		/* 페이백 기능 추가 끝 */

		// 11. 회원 등급별 즉시할인 데이터
		MbEntrpsGradVO mbEntrpsGradVO = new MbEntrpsGradVO();
		mbEntrpsGradVO.setDscntAmount(orderLimitVO.getGradApplcAmount());

		model.addAttribute("mbEntrpsGradVO", mbEntrpsGradVO);

		//지정가 야간장 선택 가능한 일자
		String limitOrderNightTime = itemPriceService.getMinLimitOrderNightTime(orderLimitVO.getMetalCode(), DateUtil.getNowDate(), 2);

		model.addAttribute("limitOrderNightTime", limitOrderNightTime);

		//운영 종료 시간(지정가 야간장 시간)
		RltmEndTimeVO rltmEndTimeVO = bsnInfoService.getRltmEndTime();

		model.addAttribute("rltmEndTimeVO", rltmEndTimeVO);

		// 실시간 판매 가격 정보 - 수정시 실시간 가격 바로 조회되지 않는 경우 때문에 가장 최근 데이터 기본세팅
        PrSelVO prSelVO = pcInfoService.getNewestPrSelRltm(orderLimitVO.getMetalCode(), orderLimitVO.getItmSn(), orderLimitVO.getDstrctLclsfCode(),
        								 orderLimitVO.getBrandGroupCode(), orderLimitVO.getBrandCode(), DateUtil.getNowDateTime("yyyyMMdd"));
        model.addAttribute("prSelVO", prSelVO);
	}

	/**
	 * <pre>
	 * 처리내용: 쿠폰 사용여부에 따라 지정가 할인 금액 재 계산 (예수금 - 할인금액 을 위함)
	 * </pre>
	 * @date 2023. 12. 08.
	 * @auther hyunjin
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 12. 08.		hyunjin 			최초등록
	 * -----------------------------------------------
	 * @param orderModel
	 * @throws CommCustomException
	 * @throws Exception
	 */
	private long getReAdvrcvAmount(OrderLimitVO paramVo) throws CommCustomException, Exception {

		long reSplpc = 0;
		long reVat = 0;
		long reSlepc = 0;
		long reWtChangePc = 0;
		long reOrderPc = 0;

		long reDsCntGoodsUntPc = 0;				//할인 후 단가
		long rePdDscntAmount = 0;				//단가 할인금액
//		long reCpDscntAmount = 0;				//총액 할인금액
		long reGradeDscAmount = 0;				//등급 할인금액
		long reDscntExpectDlvrf = 0;				//배송비 할인금액
		long reExpectDlvrf = paramVo.getExpectDlvrf();					//할인 전 배송비

		double wtChange = paramVo.getWtChange().doubleValue();
		long rmndrDscnt = paramVo.getRmndrDscnt(); //자투리 할인금액

		CouponVO couponvo = new CouponVO();

		if(!paramVo.getCouponApplcAt().equals("Y")) {
			//배송비 할인 금액
			reDscntExpectDlvrf = 0;
			//단가 할인 금액
			rePdDscntAmount = 0;
		} else {
			String[] couponSeqNoArray = {};
			couponSeqNoArray = paramVo.getCouponSeqNo().split(",");
			for (int pos = 0; pos < couponSeqNoArray.length; pos++) {
				couponvo = orderLimitMapper.selectCouponInfo(couponSeqNoArray[pos]);
				//단가 할인 쿠폰
				if(couponvo.getCouponTyCode().equals("01")) {
					rePdDscntAmount += couponvo.getUntpcDscntAmount();
				//배송비 할인 쿠폰
				}else{
					reDscntExpectDlvrf += (reExpectDlvrf / (paramVo.getLimitOrderWt()/paramVo.getSleUnitWt()));
				}
			}
		}

		if(paramVo.getGradApplcAmount() != null && paramVo.getGradApplcAmount() != "") {
			reGradeDscAmount = Long.parseLong(paramVo.getGradApplcAmount());
		}

		reExpectDlvrf = reExpectDlvrf - reDscntExpectDlvrf;
//		reDsCntGoodsUntPc = paramVo.getLimitInputAmount() - pdDscntAmount - reGradeDscAmount;
		if(StringUtils.equals("0304", paramVo.getSleMthdDetailCode())) {
			// 계약구매-지정가일 경우, '계약 구매 최종 상품 단가' 기준으로 예수금 계산
			reDsCntGoodsUntPc = paramVo.getCntrctPurchsLastGoodsUntpc() - rePdDscntAmount - reGradeDscAmount - rmndrDscnt;
		} else {
			reDsCntGoodsUntPc = paramVo.getLimitInputAmount() - rePdDscntAmount - reGradeDscAmount - rmndrDscnt;
		}

		reWtChangePc = Double.valueOf(reDsCntGoodsUntPc * wtChange).longValue();
		reOrderPc = reDsCntGoodsUntPc * paramVo.getLimitOrderWt();

		reSplpc = reOrderPc + reWtChangePc + reExpectDlvrf;
		reVat =  (long) (reSplpc * 0.1);

		reSlepc = reSplpc + reVat;

		return reSlepc;
	}

	/**
	 *  분리 or 동시확정 내역 조회
	 */
	@Override
	public Map<String, Object> selectDcsnInfoList(OrderLimitVO searchVo) throws Exception {
		Map<String, Object> retmap = new HashMap<>();

		if(StringUtils.equals("Y", searchVo.getUntpcSepratDcsnAt())) {
			// 분리확정 (LME, 환율)
			retmap.put("lmeDcsnInfo", orderLimitMapper.selectSepratDcsnLmeList(searchVo));
			retmap.put("fxDcsnInfo", orderLimitMapper.selectSepratDcsnFxList(searchVo));
		} else {
			// 동시확정 (KRW)
			retmap.put("krwDcsnInfo", orderLimitMapper.selectSmtmDcsnList(searchVo));
		}

		return retmap;
	}

	/**
	 * 주문 별 변동금 상세내역 정보 조회
	 */
	public List<OrderLimitVO> selectChangegldDtlInfoList(OrderLimitVO searchVo) throws Exception {
		return orderLimitMapper.selectChangegldDtlInfoList(searchVo);
	}

	/**
	 * 변동금 상세내역 차트 데이터 조회
	 */
	public List<OrderLimitVO> selectChangegldDtlChartInfo(OrderLimitVO searchVo) throws Exception {
		return orderLimitMapper.selectChangegldDtlChartInfo(searchVo);
	}
}
