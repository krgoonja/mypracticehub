/**
 *
 */
package com.sorincorp.fo.my.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.fo.my.model.GrntySummaryDtlVO;
import com.sorincorp.fo.my.model.SetleDtlsMngVO;

/**
 * SetleDtlsMngService.java
 * @version
 * @since 2022. 8. 10.
 * @author srec0073
 */
public interface SetleDtlsMngService {

	/**
	 * <pre>
	 * 처리내용: 결제내역 총건수 조회
	 * </pre>
	 * @date 2022. 8. 12.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 12.			srec0073			최초작성
	 * ------------------------------------------------
	 * @param setleDtlsMngVO
	 * @return
	 * @throws Exception
	 */
	int selectSetleDtlsMngTotCnt(SetleDtlsMngVO setleDtlsMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 결제내역 조회
	 * </pre>
	 * @date 2022. 8. 10.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 10.			srec0073			최초작성
	 * ------------------------------------------------
	 * @param setleDtlsMngVO
	 * @return
	 * @throws Exception
	 */
	List<SetleDtlsMngVO> selectSetleDtlsMng(SetleDtlsMngVO setleDtlsMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 전자상거래보증 보증번호 조회
	 * </pre>
	 * @date 2022. 08. 17.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 08. 17.		srec0073			최초작성
	 * ------------------------------------------------
	 * @param setleDtlsMngVO
	 * @return
	 * @throws Exception
	 */
	List<Map<String, Object>> selectGrntyNoList(SetleDtlsMngVO setleDtlsMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 전자상거래보증 요약정보 조회
	 * </pre>
	 * @date 2022. 08. 17.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 08. 17.		srec0073			최초작성
	 * ------------------------------------------------
	 * @param setleDtlsMngVO
	 * @return
	 * @throws Exception
	 */
	SetleDtlsMngVO selectGrntySummary(SetleDtlsMngVO setleDtlsMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 전자상거래보증, 구매자금 내역 카운트
	 * </pre>
	 * @date 2022. 09. 28.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 09. 28.		srec0073			최초작성
	 * ------------------------------------------------
	 * @param
	 * @return
	 * @throws Exception
	 */
	int[] getGrntyListCnt(SetleDtlsMngVO setleDtlsMngVO) throws Exception;


	/**
	 * <pre>
	 * 처리내용: 전자상거래보증 상세 요약정보 조회
	 * </pre>
	 * @date 2022. 09. 28.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 09. 28.		srec0073			최초작성
	 * ------------------------------------------------
	 * @param setleDtlsMngVO
	 * @return
	 * @throws Exception
	 */
	GrntySummaryDtlVO selectGrntySummaryDtl(SetleDtlsMngVO setleDtlsMngVO);

	/**
	 * <pre>
	 * 처리내용: 전자상거래보증 여신 구분 코드 조회
	 * </pre>
	 * @date 2022. 11. 16.
	 * @author srec0073
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 16.		srec0073			최초작성
	 * ------------------------------------------------
	 * @param setleDtlsMngVO
	 * @return
	 * @throws Exception
	 */
	String getCdtlnSvcSeCode(SetleDtlsMngVO setleDtlsMngVO) throws Exception;
}
