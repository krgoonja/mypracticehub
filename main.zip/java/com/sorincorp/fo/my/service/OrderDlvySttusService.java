package com.sorincorp.fo.my.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.fo.my.model.DlivyVO;
import com.sorincorp.fo.my.model.DlvyVO;
import com.sorincorp.fo.my.model.OrSetleInfoVO;
import com.sorincorp.fo.my.model.OrderDlvySttusVO;
import com.sorincorp.fo.my.model.OrderDtlsVO;
import com.sorincorp.fo.my.model.VhcleInfoVO;

public interface OrderDlvySttusService {

	

	/**
	 * <pre>
	 * 처리내용: 출고 정보 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 19.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param searchVo
	 * @return
	 * @throws Exception
	 */
	public List<OrderDlvySttusVO> selectDlvySttusList(OrderDlvySttusVO searchVo) throws Exception;	
	
	public int selectOrderDlvySttusTotCnt(OrderDlvySttusVO orderDlvySttusVO) throws Exception;

	public List<OrderDlvySttusVO> selectOrderDlvySttusVhcleDtl(OrderDlvySttusVO searchVo) throws Exception;
	
}
