package com.sorincorp.fo.my.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.fo.my.model.CnEstmtPropseMtDtlVO;
import com.sorincorp.fo.my.model.CntrctMtAsgnInvntryDtlVO;
import com.sorincorp.fo.my.model.CntrctMtDtlVO;
import com.sorincorp.fo.my.model.CntrctOrderBasVO;
import com.sorincorp.fo.my.model.OrderAvrgVO;

public interface OrderAvrgService {
	List<OrderAvrgVO> selectOrderArvgList(OrderAvrgVO orderAvrgVO) throws Exception;

	OrderAvrgVO selectOrderArvgDetail(String estmtNo) throws Exception;
	
	List<Map<String, Object>> selectCnEstmtMtOrderWtDtlList(String estmtNo) throws Exception;

	List<CnEstmtPropseMtDtlVO> selectCnEstmtPropseMtDtlList(String estmtNo) throws Exception;

	String updateOrderAvrg(OrderAvrgVO orderAvrgVO) throws Exception;

	OrderAvrgVO selectCntrctBaseInfo(String cntrctNo) throws Exception;

	List<Map<String, String>> selectCntrctMtList(String cntrctNo) throws Exception;

	Map<String, Object> getContractInfo(CntrctMtDtlVO cntrctMtDtlVO) throws Exception;

	void updateCnCntrctMtDtl(List<CntrctMtDtlVO> cntrctMtDtlVOList) throws Exception;

	Map<String, Object> getAvgOrderModalData(CntrctOrderBasVO cntrctOrderBasVO) throws Exception;

	Map<String, Object> insertCntrctOrder(CntrctOrderBasVO cntrctOrderBasVO) throws Exception;

	Map<String, Object> getNewAsgnInfo(CntrctMtDtlVO cntrctMtDtlVO) throws Exception;

	List<CntrctMtDtlVO> getNewAsgnInfoHst(CntrctMtDtlVO cntrctMtDtlVO) throws Exception;

	Map<String, Object> getScreofeList(CntrctMtAsgnInvntryDtlVO cntrctMtAsgnInvntryDtlVO) throws Exception;

	void cancelOrdering(CntrctOrderBasVO cntrctOrderBasVO) throws Exception;

	String getSetleTmlmtDe(CntrctOrderBasVO cntrctOrderBasVO) throws Exception;

}
