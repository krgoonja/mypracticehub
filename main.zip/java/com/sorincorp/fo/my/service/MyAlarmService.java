package com.sorincorp.fo.my.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.fo.my.model.MyCmmrcAlarmVO;
import com.sorincorp.fo.my.model.MyHopePcAlarmVO;
import com.sorincorp.fo.my.model.MyInvntryAlarmVO;
import com.sorincorp.fo.op.model.HopePcNtcnSetupVO;
import com.sorincorp.fo.op.model.InvntryNtcnSetupVO;

/**
 * MyAlarmService.java
 * @version
 * @since 2021. 9. 8.
 * @author srec0042
 */
public interface MyAlarmService {

	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 희망가 알림 내역을 조회한다.
	 * </pre>
	 * @date 2021. 9. 8.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 8.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @return
	 */
	public List<MyHopePcAlarmVO> selectHopePcAlarm(String entrpsNo);

	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 희망가 알림을 수정한다.
	 * </pre>
	 * @date 2021. 9. 23.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 23.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	public int updateHopePcAlarm(HopePcNtcnSetupVO vo);

	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 희망가 알림을 삭제한다.
	 * </pre>
	 * @date 2021. 9. 23.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 23.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param deleteVo
	 * @return
	 */
	public int deleteHopePcAlarm(HopePcNtcnSetupVO deleteVo);

	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 목표가 알림 내역을 조회한다.
	 * </pre>
	 * @date 2021. 9. 30.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 30.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	public List<MyHopePcAlarmVO> selectHopePcAlarmList(String entrpsNo);

	/**
	 * <pre>
	 * 처리내용: 헤더 - 알림 내역 조회 
	 * </pre>
	 * @date 2021. 9. 30.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 30.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	public List<MyHopePcAlarmVO> selectHeaderAlarm(String entrpsNo);

	/**
	 * <pre>
	 * 처리내용: 헤더 - 알림 개수 count
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	public int countHeaderAlarm(String entrpsNo);

	/**
	 * <pre>
	 * 처리내용: 재고 알림 설정 내역을 조회한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	public List<MyInvntryAlarmVO> selectInvntryAlarm(String entrpsNo);

	/**
	 * <pre>
	 * 처리내용: 재고 알림을 삭제한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	public int deleteInvntryAlarm(InvntryNtcnSetupVO vo);

	/**
	 * <pre>
	 * 처리내용: 재고 알림 상태를 수정한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	public int updateInvntryUseAt(InvntryNtcnSetupVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 희망가 알림 상태를 수정한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	public int updateHopePcUseAt(MyHopePcAlarmVO vo);

	public List<MyCmmrcAlarmVO> selectCmmrcAlarm(String entrpsNo);

	public Map<String,Object> selectRealTimeSellAlarm(HopePcNtcnSetupVO updateVO) throws Exception;

}
