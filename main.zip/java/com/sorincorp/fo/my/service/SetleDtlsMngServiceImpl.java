/**
 *
 */
package com.sorincorp.fo.my.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.my.mapper.SetleDtlsMngMapper;
import com.sorincorp.fo.my.model.GrntySummaryDtlVO;
import com.sorincorp.fo.my.model.SetleDtlsMngVO;

import lombok.extern.slf4j.Slf4j;

/**
 * SetleDtlsMngServiceImpl.java
 * @version
 * @since 2022. 8. 10.
 * @author srec0073
 */
@Slf4j
@Service
public class SetleDtlsMngServiceImpl implements SetleDtlsMngService{

	@Autowired
	private SetleDtlsMngMapper setleDtlsMngMapper;

	@Override
	public int selectSetleDtlsMngTotCnt(SetleDtlsMngVO setleDtlsMngVO) throws Exception {
		setSetleMnParams(setleDtlsMngVO);
		return setleDtlsMngMapper.selectSetleDtlsMngTotCnt(setleDtlsMngVO);
	}

	@Override
	public List<SetleDtlsMngVO> selectSetleDtlsMng(SetleDtlsMngVO setleDtlsMngVO) throws Exception {
		setSetleMnParams(setleDtlsMngVO);
		List<SetleDtlsMngVO> result = setleDtlsMngMapper.selectSetleDtlsMng(setleDtlsMngVO);
		return result;
	}

	@Override
	public List<Map<String, Object>> selectGrntyNoList(SetleDtlsMngVO setleDtlsMngVO) throws Exception {
		List<Map<String, Object>> result = setleDtlsMngMapper.selectGrntyNoList(setleDtlsMngVO);
		return result;
	}

	@Override
	public SetleDtlsMngVO selectGrntySummary(SetleDtlsMngVO setleDtlsMngVO) throws Exception {
		SetleDtlsMngVO result = setleDtlsMngMapper.selectGrntySummary(setleDtlsMngVO);
		return result;
	}

	// 결제수단 조회조건 셋팅.
	public void setSetleMnParams(SetleDtlsMngVO setleDtlsMngVO) throws Exception {
		// 결제수단
		String setleMn = setleDtlsMngVO.getSetleMn();
		// 담보 보증 사용 여부
		String mrtggGrntyUseAt = setleDtlsMngVO.getMrtggGrntyUseAt();
		// 대출 보증 사용 여부
		String lonGrntyUseAt = setleDtlsMngVO.getLonGrntyUseAt();
		// 미사용 보증 리스트
		List<String> grntyNoUseLis = new ArrayList<>();

		// 전체탭 조회시
		if (StringUtil.isBlank(setleMn)) {
			// 미사용 보증정보
			if (!"Y".equals(mrtggGrntyUseAt)) { grntyNoUseLis.add(setleDtlsMngVO.getMrtggGrnty()); }
			if (!"Y".equals(lonGrntyUseAt)) { grntyNoUseLis.add(setleDtlsMngVO.getLonGrnty()); }
		}
		setleDtlsMngVO.setNoUseGrntyList(grntyNoUseLis);
	}

	@Override
	public int[] getGrntyListCnt(SetleDtlsMngVO setleDtlsMngVO) throws Exception {
		return setleDtlsMngMapper.getGrntyListCnt(setleDtlsMngVO);
	}

	@Override
	public GrntySummaryDtlVO selectGrntySummaryDtl(SetleDtlsMngVO setleDtlsMngVO) {
		return setleDtlsMngMapper.selectGrntySummaryDtl(setleDtlsMngVO);
	}

	@Override
	public String getCdtlnSvcSeCode(SetleDtlsMngVO setleDtlsMngVO) throws Exception {
		return setleDtlsMngMapper.getCdtlnSvcSeCode(setleDtlsMngVO);
	}
}
