package com.sorincorp.fo.my.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.fo.mb.model.MbEntrpsGradVO;
import com.sorincorp.fo.my.model.BankInfoVO;
import com.sorincorp.fo.my.model.DashboardVO;
import com.sorincorp.fo.my.model.InqryDtlsVO;
import com.sorincorp.fo.my.model.OrPcChangegldBasVO;
import com.sorincorp.fo.my.model.PaytEsamtVO;
import com.sorincorp.fo.my.model.SetleDtlsDetailVO;


/**
 * DashboardService.java
 * @version
 * @since 2021. 7. 27.
 * @author srec0048
 */
public interface DashboardService {

	/**
	 * <pre>
	 * 처리내용: 결제수단 e-wallet금액을 조회한다.
	 * </pre>
	 * @date 2021. 9. 23.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 23.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> selectSetleMnInfo(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 상단 대시보드 결제수단을 조회한다.
	 * </pre>
	 * @date 2021. 7. 27.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 27.			srec0048			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public DashboardVO selectRecentOrderDtls(Map<String, Object> param) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 마이페이지 최근 24시간 내 3개 알림 내역 조회한다.
	 * </pre>
	 * @date 2021. 8. 12.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 12.			srec0048			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public List<DashboardVO> selectRecentNtcn(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 마이페이지 최근 7일내 3개 문의/답변 내역 조회한다.
	 * </pre>
	 * @date 2021. 8. 12.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 12.			srec0048			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public List<InqryDtlsVO> selectRecentInqryAnswer(Map<String, Object> param) throws Exception;

	/**
	 * <pre>
	 * 출금요청 전, 예수금(지정가주문)을 체크
	 * </pre>
	 * @date 2023. 5. 16.
	 * @author srec0051
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public Map<String,Object> createRefundRequstBefore(Map<String, Object> params) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 인출 요청한다.
	 * </pre>
	 * @date 2021. 10. 26.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 26.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param refundRequstInfo
	 * @throws Exception
	 */
	public Map<String, Object> createRefundRequst(Map<String, Object> refundRequstInfo) throws Exception;

	/**
	 * <pre>
	 * 결졔예정액 영역 조회
	 * </pre>
	 * @date 2022. 7. 15.
	 * @author srec0051
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> selectUnSetleAmount(Map<String, Object> param) throws Exception;

	/**
	 * <pre>
	 * 결제예정 내역 목록
	 * </pre>
	 * @date 2022. 7. 15.
	 * @author srec0051
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public List<PaytEsamtVO> selectListUnSetleAmountDtl(Map<String, Object> param) throws Exception;

	/**
	 * <pre>
	 * 회원_업체 대출 보증 은행 정보
	 * </pre>
	 * @date 2022. 7. 22.
	 * @author srec0051
	 * @param param
	 * @return
	 */
	public List<BankInfoVO> selectListEntrpsBank(Map<String, Object> param) throws Exception;

	/**
	 * <pre>
	 * 결제 내역 상세 목록
	 * </pre>
	 * @date 2022. 8. 2.
	 * @author srec0051
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	public List<SetleDtlsDetailVO> setleDtlsList(SetleDtlsDetailVO paramVo) throws Exception;
	
	/**
	 * <pre>
	 * 회원_업체 등급 기준 구매 수량
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author sein
	 * @param 
	 * @return
	 * @throws Exception
	 */
	public MbEntrpsGradVO selectMbEntrpsGradStdrPurchsQy() throws Exception;
	
	/**
	 * <pre>
	 * 회원 등급 할인 금액
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author sein
	 * @param 
	 * @return
	 * @throws Exception
	 */
	public List<MbEntrpsGradVO> selectMbGradDscntAmountList() throws Exception;

	/**
	 * <pre>
	 * 당월 구매 수량
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author sein
	 * @param entrpsNo
	 * @return totRealOrderWtSum
	 * @throws Exception
	 */
	public int selectMbTotRealOrderWtSum(String entrpsNo)throws Exception;
	
	/**
	 * <pre>
	 * 전월 기준 구매 정보(MB_ENTRPS_MNBY_PURCHS_BNEF_BAS)
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author sein
	 * @param 
	 * @return
	 * @throws Exception
	 */
	public MbEntrpsGradVO mbEntrpsMnbyPurchsInfo(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 상시 할인 금액 리스트(3000,4000,5000)
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author sein
	 * @param 
	 * @return
	 * @throws Exception
	 */
	public List<MbEntrpsGradVO> selectcpAtmcIsuCouponInfoList() throws Exception;

	public Map<String, Object> doEwalletDefrayRequestForPcChangegld(OrPcChangegldBasVO defrayRequstInfo) throws Exception;

}
