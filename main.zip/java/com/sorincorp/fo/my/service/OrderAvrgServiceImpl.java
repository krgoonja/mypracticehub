package com.sorincorp.fo.my.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.mock.web.MockMultipartHttpServletRequest;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.entrpsdlvrg.service.EntrpsDlvrgService;
import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.model.CommAvrgPcInvntryVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.comm.order.service.CommAvrgPcInvntryService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.my.mapper.OrderAvrgMapper;
import com.sorincorp.fo.my.model.CnEstmtPropseMtDtlVO;
import com.sorincorp.fo.my.model.CntrctMtAsgnInvntryDtlVO;
import com.sorincorp.fo.my.model.CntrctMtDtlVO;
import com.sorincorp.fo.my.model.CntrctOrderBasVO;
import com.sorincorp.fo.my.model.CntrctOrderDtlVO;
import com.sorincorp.fo.my.model.OrderAvrgVO;
import com.sorincorp.fo.pd.model.ItemPriceSelectVO;
import com.sorincorp.fo.pd.service.ItemPriceService;
import com.sorincorp.fo.pd.service.OrderService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class OrderAvrgServiceImpl implements OrderAvrgService {
	
	@Autowired
	private AssignService assignService;
	
	@Autowired
	private ItemPriceService itemPriceService;
	
	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired
	private EntrpsDlvrgService entrpsDlvrgService;
	
	@Autowired
	private OrderService orderService;
	
	@Autowired
	private CommAvrgPcInvntryService commAvrgPcInvntryService;
	
	@Autowired
    private SMSService smsService;
	
	@Autowired
	public FileDocService fileDocService;
	
	@Autowired
	private OrderAvrgMapper orderAvrgMapper;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@Autowired
	private Environment env;

	@Override
	public List<OrderAvrgVO> selectOrderArvgList(OrderAvrgVO orderAvrgVO) throws Exception {
		log.info("OrderAvrgServiceImpl :: selectOrderArvgList Start");
		log.info("OrderAvrgServiceImpl :: selectOrderArvgList params : {}", objectMapper.writeValueAsString(orderAvrgVO));
		
		List<OrderAvrgVO> result = null;
		
		try {
			int pageIndex = orderAvrgVO.getPageIndex();							// default : 1
			int recordCountPerPage = orderAvrgVO.getRecordCountPerPage();		// default : 10
			
			orderAvrgVO.setFirstIndex((pageIndex-1)*recordCountPerPage+1);
			orderAvrgVO.setLastIndex(pageIndex*recordCountPerPage);
			orderAvrgVO.setMberNo(userInfoUtil.getAccountInfo().getMberNo());	// 회원 번호
			orderAvrgVO.setEntrpsNo(userInfoUtil.getEntripsNo());				// 업체 번호
			orderAvrgVO.setMemberSecode(userInfoUtil.getMemberSecode());		// 권한 구분 코드
			
			result = orderAvrgMapper.selectOrderArvgList(orderAvrgVO);
			
			// 계약 완료된 건에 한해서 추가로 표현해야하는 "주문 정보"(월별 계약 정보) 조회 및 세팅
			for (OrderAvrgVO resultVO : result) {
				if(StringUtils.equals(resultVO.getEstmtSttusCode(), "50")) {
					resultVO.setOrderInfoList(orderAvrgMapper.selectCntrctOrderInfoList(resultVO.getCntrctNo(), null));
				}
			}
			
			log.info("select result :: {}", objectMapper.writeValueAsString(result));
		} catch (Exception e) {
			throw new CommCustomException("조회에 실패하였습니다.\r\n\r\n관리자에게 문의바랍니다.");
		}
		
		return result;
	}

	@Override
	public OrderAvrgVO selectOrderArvgDetail(String estmtNo) throws Exception {
		log.info("OrderAvrgServiceImpl :: selectOrderArvgDetail Start");
		log.info("OrderAvrgServiceImpl :: selectOrderArvgDetail params : {}", objectMapper.writeValueAsString(estmtNo));
		
		return orderAvrgMapper.selectOrderArvgDetail(estmtNo);
	}
	
	@Override
	public List<Map<String, Object>> selectCnEstmtMtOrderWtDtlList(String estmtNo) throws Exception {
		return orderAvrgMapper.selectCnEstmtMtOrderWtDtlList(estmtNo);
	}

	@Override
	public List<CnEstmtPropseMtDtlVO> selectCnEstmtPropseMtDtlList(String estmtNo) throws Exception {
		log.info("OrderAvrgServiceImpl :: selectCnEstmtPropseMtDtlList Start");
		log.info("OrderAvrgServiceImpl :: selectCnEstmtPropseMtDtlList params : {}", objectMapper.writeValueAsString(estmtNo));
		
		List<CnEstmtPropseMtDtlVO> result = orderAvrgMapper.selectCnEstmtPropseMtDtlList(estmtNo);
		
		if(result == null || result.isEmpty()) {
			throw new CommCustomException("오류가 발생했습니다.\r\n\r\n관리자에게 문의바랍니다.");
		}
		
		return result;
	}

	@Override
	public String updateOrderAvrg(OrderAvrgVO orderAvrgVO) throws Exception {
		String cntrctConfmEndDe = null;
		
		orderAvrgVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		
		// 현재 구동 환경 
		String nowProfile = env.getActiveProfiles()[0];
		
		// 계약서 서류(오즈 리포트) upload 처리
		// 개발 환경이거나, 운영 환경에서 계약서 승인 시, 서류 upload 처리
		if ( ("local".equals(nowProfile) || "dev".equals(nowProfile))
				|| StringUtils.equals(orderAvrgVO.getEstmtSttusCode(), "50") ) {
			try {

				// 서류 PDF 파일 upload 처리
				int uploadedFileNo = this.convertAndUploadPdfFile(orderAvrgVO);
				
				// 파일 번호 세팅
				orderAvrgVO.setDocNo(uploadedFileNo);
			} catch (Exception e) {
				log.info("PDF 업로드 처리 중 에러 발생 : " + e.getMessage());
			}

		}
		
		// 견적 상태 코드 및 [견적 확인 일시 또는 계약 승인 일시] update
		int updateResult = orderAvrgMapper.updateEstmtSttus(orderAvrgVO);
		
		if(updateResult <= 0) {
			throw new CommCustomException("오류가 발생했습니다.\r\n\r\n관리자에게 문의바랍니다.");
		}
		
		orderAvrgMapper.insertCnEstmtBasHst(orderAvrgVO.getEstmtNo());
		
		// 메세지 발송 처리를 위한 기본 데이터 세팅
		Map<String, String> smsMap = null;
		String templateNum = "";
		
		if(StringUtils.equals(orderAvrgVO.getEstmtSttusCode(), "40")) {	// 견적서 확인 시, 계약 정보 생성
			cntrctConfmEndDe = insertCntrctFromEstmt(orderAvrgVO.getEstmtNo());
			templateNum = "136";	// "견적서 확정"(136) 
		} else if(StringUtils.equals(orderAvrgVO.getEstmtSttusCode(), "50") && orderAvrgVO.getCntrctNo() != null) {	// 계약 승인 시, 계약 승인 정보 update
			orderAvrgMapper.updateCntrctConfmInfo(orderAvrgVO);
			orderAvrgMapper.insertCnCntrctBasHst(orderAvrgVO.getCntrctNo());
			templateNum = "139";	// "계약서 승인"(139) 
		}
		
		smsMap = orderAvrgMapper.selectMessageData(orderAvrgVO.getEstmtNo());
		
		this.sendSMSToInnerDepartment(templateNum, smsMap);	// 메세지 발송 처리
		
		return cntrctConfmEndDe;
	}
	
	private int convertAndUploadPdfFile(OrderAvrgVO orderAvrgVO) throws Exception {
		String fileName = "";
		String pdfString = orderAvrgVO.getPdfString();
		
		if(StringUtils.isBlank(pdfString)) {
			throw new Exception("업로드 대상 PDF 파일이 존재하지 않습니다.");
		}
		
		if(StringUtils.equals(orderAvrgVO.getEstmtSttusCode(), "40")) {
			fileName = orderAvrgVO.getEstmtNo();
		} else if(StringUtils.equals(orderAvrgVO.getEstmtSttusCode(), "50") && orderAvrgVO.getCntrctNo() != null) {
			fileName = orderAvrgVO.getCntrctNo();
		}
		
		fileName += ".pdf";
		
		String base64 = pdfString.substring(pdfString.indexOf(",") + 1);
	    byte[] bt = Base64.getMimeDecoder().decode(base64);
	    
	    MockMultipartFile mf = new MockMultipartFile(fileName, fileName, null, bt);
	    
	    MockMultipartHttpServletRequest sr = new MockMultipartHttpServletRequest();
	    
	    sr.addFile(mf);
	    
	    FileDocVO uploadedFileVO = fileDocService.uploadAttachFilesVoList("CN", sr).get(0);
	    
	    return uploadedFileVO.getDocNo();
	}

	private String insertCntrctFromEstmt(String estmtNo) throws Exception {
		String mberId = userInfoUtil.getAccountInfo().getId();
		
		// 1. 견적 기본 테이블에서 계약 기본 테이블에 넣을 데이터 조회
		OrderAvrgVO orderAvrgVO = orderAvrgMapper.selectCnEstmtBas(estmtNo);
		
		// 2. 계약 번호 채번
		// 채번 규칙 : C - METAL 2자리 - 업체명약어 - 등록일자 YYMMDD - 000(년도별 채번 3자리)
		StringBuilder sb = new StringBuilder("C");
		sb.append("-");
		sb.append(orderAvrgVO.getPropseMetalNm());
		sb.append("-");
		
		// 업체명약어가 없을 경우, 임시로 업체번호 세팅
		String entrpsnmKoreanShort = orderAvrgVO.getEntrpsnmKoreanShort();
		if(StringUtils.isNotBlank(entrpsnmKoreanShort)) {
			sb.append(entrpsnmKoreanShort);
		} else {
			sb.append(orderAvrgVO.getEntrpsNo());
		}
		
		sb.append("-");
		sb.append(DateUtil.calDate("yyMMdd"));
		sb.append("-");
		sb.append(assignService.selectAssignValue("CN", "CNTRCT_NO", DateUtil.calDate("yyyy"), "SYSTEM", 3));
		
		String cntrctNo = sb.toString();
		
		// 3. 견적 제안 월 상세 테이블에서 계약 월 상세 테이블에 넣을 데이터 조회
		List<CnEstmtPropseMtDtlVO> cnEstmtPropseMtDtlList = orderAvrgMapper.selectCnEstmtPropseMtDtlList(estmtNo);
		
		// 4. 계약 기본 테이블 insert
		orderAvrgVO.setCntrctNo(cntrctNo);
		orderAvrgVO.setFrstRegisterId(mberId);
		orderAvrgVO.setLastChangerId(mberId);
		
		orderAvrgMapper.insertCnCntrctBas(orderAvrgVO);
		orderAvrgMapper.insertCnCntrctBasHst(cntrctNo);
		
		// 5. 계약 월 상세 테이블 insert
		for (CnEstmtPropseMtDtlVO cnEstmtPropseMtDtlVO : cnEstmtPropseMtDtlList) {
			cnEstmtPropseMtDtlVO.setCntrctNo(cntrctNo);
			cnEstmtPropseMtDtlVO.setFrstRegisterId(mberId);
			cnEstmtPropseMtDtlVO.setLastChangerId(mberId);
			
			orderAvrgMapper.insertCnCntrctMtDtl(cnEstmtPropseMtDtlVO);
			orderAvrgMapper.insertCnCntrctMtDtlHst(cntrctNo, cnEstmtPropseMtDtlVO.getPropseYm(), cnEstmtPropseMtDtlVO.getPropseYmSn());
		}
		
		return orderAvrgVO.getCntrctConfmEndDe();
	}

	@Override
	public OrderAvrgVO selectCntrctBaseInfo(String cntrctNo) throws Exception {
		OrderAvrgVO orderAvrgVO = Optional.ofNullable(orderAvrgMapper.selectCntrctBaseInfo(cntrctNo))
										.orElseThrow(() -> {return new CommCustomException("잘못된 접근입니다.");});
		
		orderAvrgVO.setEntrpsNo(userInfoUtil.getEntripsNo());
		
		return orderAvrgVO;
	}

	@Override
	public List<Map<String, String>> selectCntrctMtList(String cntrctNo) throws Exception {
		return orderAvrgMapper.selectCntrctMtList(cntrctNo);
	}

	@Override
	public Map<String, Object> getContractInfo(CntrctMtDtlVO cntrctMtDtlVO) throws Exception {
		Map<String, Object> result = new HashMap<>();
		
		cntrctMtDtlVO.setEntrpsNo(userInfoUtil.getEntripsNo());	// 업체 번호
		
		// 1. 진행 상태 (상단 프로그래스 바)
		CntrctMtDtlVO progressSttus = orderAvrgMapper.selectCntrctOrderInfoList(cntrctMtDtlVO.getCntrctNo(), cntrctMtDtlVO.getCntrctYm()).get(0);
		result.put("progressSttus", progressSttus);
		
		// 2. 프라이싱 확정 정보
		CntrctMtDtlVO pricingDcsnInfo = orderAvrgMapper.selectPricingDcsnInfo(cntrctMtDtlVO);
		result.put("pricingDcsnInfo", pricingDcsnInfo);
		
		// 3. 계약 정보
		result.put("cntrctInfo", orderAvrgMapper.selectCntrctInfo(cntrctMtDtlVO));
		
		// 프라이싱 확정 전 상태면, 이후의 데이터는 조회 안해도 됨
		if(!StringUtils.equals(pricingDcsnInfo.getPricingDcsnAt(), "Y")) {
			// 프라이싱 확정 전에만 필요한 데이터인 평균가 라이브 구매 가능 중량 정보 세팅
			result.put("avrgpcLiveWt", orderAvrgMapper.selectAvrgpcLiveWt(cntrctMtDtlVO));
			
			return result;
		}
		
		// 4. 상품 할당 정보 (sum 처리된 할당 내역)
		result.put("goodsAsgnInfo", orderAvrgMapper.selectGoodsAsgnInfo(cntrctMtDtlVO));
		
		// 5. 할당 내역
		List<CntrctMtDtlVO> asgnInvntryList = orderAvrgMapper.selectAsgnInvntryList(cntrctMtDtlVO);
		
		// 5-1. LIVE 할당 내역
		result.put("liveAsgnDtlList", asgnInvntryList.stream()
				.filter(asgnDtlVO -> StringUtils.equals(asgnDtlVO.getInvntryAsgnSeCode(), "10"))
				.collect(Collectors.toList()));
		
		// 5-2. 평균가 할당 내역
		result.put("avrgpcAsgnDtlList", asgnInvntryList.stream()
				.filter(asgnDtlVO -> StringUtils.equals(asgnDtlVO.getInvntryAsgnSeCode(), "20"))
				.collect(Collectors.toList()));

		// 6. 발주/출고 업무 내역
		List<CntrctOrderBasVO> cntrctOrderList = orderAvrgMapper.selectCntrctOrderList(cntrctMtDtlVO);
		
		// 6-1. LIVE 구매계획
		result.put("livePurchsPlanList", cntrctOrderList.stream()
				.filter(cntrctOrderBasVO -> StringUtils.equals(cntrctOrderBasVO.getSleMthdCode(), "01"))
				.collect(Collectors.toList()));
		
		// 6-2. 평균가 구매계획
		result.put("avrgpcPurchsPlanList", cntrctOrderList.stream()
				.filter(cntrctOrderBasVO -> StringUtils.equals(cntrctOrderBasVO.getSleMthdCode(), "04"))
				.collect(Collectors.toList()));
		
		return result;
	}

	@Override
	public void updateCnCntrctMtDtl(List<CntrctMtDtlVO> cntrctMtDtlVOList) throws Exception {
		Map<String, String> smsMap = null;
		int livePurchsWt = 0; 
		int avrgpcPurchsWt = 0;
		
		for (CntrctMtDtlVO cntrctMtDtlVO : cntrctMtDtlVOList) {
			cntrctMtDtlVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			
			int updateResult = orderAvrgMapper.updateCnCntrctMtDtl(cntrctMtDtlVO);
			
			if(updateResult <= 0) {
				throw new CommCustomException("오류가 발생했습니다.\r\n\r\n관리자에게 문의바랍니다.");
			}
			
			orderAvrgMapper.insertCnCntrctMtDtlHst(cntrctMtDtlVO.getCntrctNo(), 
													cntrctMtDtlVO.getCntrctYm(), 
													cntrctMtDtlVO.getCntrctYmSn());
			
			// 메세지 발송 처리를 위한 기본 데이터 세팅
			livePurchsWt = cntrctMtDtlVO.getLivePurchsWt(); 
			avrgpcPurchsWt = cntrctMtDtlVO.getAvrgpcPurchsWt(); 
			
			StringBuilder stb = new StringBuilder();
			
			if(livePurchsWt > 0) {
				stb.append("LIVE : ");
				stb.append(StringUtil.formatMoney(String.valueOf(livePurchsWt)));
				
				if(avrgpcPurchsWt > 0) {
					stb.append(", ");
				}
			}
			
			if(avrgpcPurchsWt > 0) {
				stb.append("평균가 : ");
				stb.append(StringUtil.formatMoney(String.valueOf(avrgpcPurchsWt)));
			}
			
			smsMap = new HashMap<>();
			
			smsMap.put("cntrctNo", cntrctMtDtlVO.getCntrctNo());
			smsMap.put("cntrctYm", cntrctMtDtlVO.getCntrctYm());
			smsMap.put("purchsWt", stb.toString());
			
			this.sendSMSToInnerDepartment("140", smsMap);	// "프라이싱 확정"(140) 메세지 발송 처리
		}
	}
	
	@Override
	public Map<String, Object> getNewAsgnInfo(CntrctMtDtlVO cntrctMtDtlVO) throws Exception {
		Map<String, Object> result = new HashMap<>();
		
		cntrctMtDtlVO.setEntrpsNo(userInfoUtil.getEntripsNo());	// 업체 번호
		
		// 1. 상품 할당 정보 (sum 처리된 할당 내역)
		result.put("goodsAsgnInfo", orderAvrgMapper.selectGoodsAsgnInfo(cntrctMtDtlVO));
		
		// 2. 할당 내역
		List<CntrctMtDtlVO> asgnInvntryList = orderAvrgMapper.selectAsgnInvntryList(cntrctMtDtlVO);
		
		// 2-1. LIVE 할당 내역
		result.put("liveAsgnDtlList", asgnInvntryList.stream()
				.filter(asgnDtlVO -> StringUtils.equals(asgnDtlVO.getInvntryAsgnSeCode(), "10"))
				.collect(Collectors.toList()));
		
		// 2-2. 평균가 할당 내역
		result.put("avrgpcAsgnDtlList", asgnInvntryList.stream()
				.filter(asgnDtlVO -> StringUtils.equals(asgnDtlVO.getInvntryAsgnSeCode(), "20"))
				.collect(Collectors.toList()));
		
		return result;
	}
	
	@Override
	public Map<String, Object> getScreofeList(CntrctMtAsgnInvntryDtlVO cntrctMtAsgnInvntryDtlVO) throws Exception {
		Map<String, Object> result = new HashMap<>();
		
		List<CntrctMtAsgnInvntryDtlVO> screofeList = orderAvrgMapper.selectScreofeList(cntrctMtAsgnInvntryDtlVO);
		
		// 같은 창고에 적재된 재고인지 여부 체크
		boolean isSameWrhous = true;

		// 제일 처음 BL의 창고 코드 GET
		String wrhousCode = screofeList.get(0).getWrhousCode();
		
		// 위에서 GET한 창고 코드와 비교, 같지 않은 데이터를 대상으로 filtering
		List<CntrctMtAsgnInvntryDtlVO> temp = screofeList.stream()
														.filter((vo)->{
															if(!StringUtils.equals(wrhousCode, vo.getWrhousCode())) {
																return true;
															} else {
																return false;
															}
														}).collect(Collectors.toList());
		
		// 창고 코드가 같지 않은 데이터가 하나라도 있다면 false 처리
		if(!temp.isEmpty()) {
			isSameWrhous = false;
		}
		
		result.put("screofeList", screofeList);
		result.put("isSameWrhous", isSameWrhous);
		
		return result;
	}
	
	@Override
	public List<CntrctMtDtlVO> getNewAsgnInfoHst(CntrctMtDtlVO cntrctMtDtlVO) throws Exception {
		cntrctMtDtlVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		
		// 신규 할당 여부 N 으로 update
		orderAvrgMapper.updateNewAsgnAt(cntrctMtDtlVO);
		
		cntrctMtDtlVO.setAsgnEventTyCode("60"); // 할당 이벤트 유형 코드 
		orderAvrgMapper.insertCnCntrctMtAsgnInvntryDtlHst(cntrctMtDtlVO);
		
		return orderAvrgMapper.selectNewAsgnInfoHst(cntrctMtDtlVO);
	}

	@Override
	public Map<String, Object> getAvgOrderModalData(CntrctOrderBasVO cntrctOrderBasVO) throws Exception {
		Map<String, Object> result = new HashMap<>();
		
		// 배송방식 구성 데이터
		result.put("dlvyMnCode", itemPriceService.getCodeListAfterRemoveSubName(commonCodeService.getSubCodes("DLVY_MN_CODE")));
		// 배송지 정보 구성 데이터
		result.put("entrpsDlvrg", entrpsDlvrgService.getEntrpsDlvrgList(userInfoUtil.getEntripsNo()));
		// 한국 공휴일 데이터 - 배송 일자 달력 구성 시 사용
		result.put("koreaWeekendList", itemPriceService.selectKoreaWeekendList());
		
		ItemPriceSelectVO itemPriceSelectVO = new ItemPriceSelectVO();
		itemPriceSelectVO.setItmSn(cntrctOrderBasVO.getItmSn());
		
		// 주문 톤수 선택 영역 구성 데이터
		result.put("itmInfo", itemPriceService.selectItmInfoBas(itemPriceSelectVO));
		
		return result;
	}

	@Override
	public Map<String, Object> insertCntrctOrder(CntrctOrderBasVO cntrctOrderBasVO) throws Exception {
		Map<String, Object> result = new HashMap<>();
		
		cntrctOrderBasVO.setMberNo(userInfoUtil.getAccountInfo().getMberNo());		// 회원 번호
		cntrctOrderBasVO.setEntrpsNo(userInfoUtil.getEntripsNo());					// 업체 번호
		cntrctOrderBasVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());	// 회원 ID
		cntrctOrderBasVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());	// 회원 ID
		
		// 로직 수행 및 데이터 insert 시 필요한 데이터 조회
		CntrctOrderBasVO queryResultVO = orderAvrgMapper.selectCntrctOrder(cntrctOrderBasVO);
		
		// 조회 결과를 param VO에 copy
		cntrctOrderBasVO.copyCntrctOrderData(queryResultVO);
		
		// 발주 처리할 재고 선택 및 데이터 세팅
		List<CntrctMtAsgnInvntryDtlVO> orderingBlList = selectOrderingBlList(cntrctOrderBasVO);
		
		// 선택된 재고 중, 첫번째 BL의 권역 중분류 코드를 세팅
		cntrctOrderBasVO.setDstrctMlsfcCode(orderingBlList.get(0).getDstrctMlsfcCode());
		
		// 재고 할당 구분 코드(invntryAsgnSeCode)를 판매 방식 코드(sleMthdCode)로 치환
		String invntryAsgnSeCode = cntrctOrderBasVO.getInvntryAsgnSeCode();
		String sleMthdCode = null;
		
		if(StringUtils.equals(invntryAsgnSeCode, "10")) {
			sleMthdCode = "01";
		} else if(StringUtils.equals(invntryAsgnSeCode, "20")) {
			sleMthdCode = "04";
		}
		
		if(sleMthdCode == null) {
			throw new CommCustomException("오류가 발생했습니다.\r\n\r\n관리자에게 문의바랍니다.");
		}
		
		cntrctOrderBasVO.setSleMthdCode(sleMthdCode);
		
		result.put("sleMthdCode", sleMthdCode);
		
		// validation check : 배송요청일 check 및 케이지배송 배송 가능 여부 check
		// 관련 서비스 호출을 위해 parameter로 쓸 객체 생성 및 데이터 세팅
		OrderModel orderModel = new OrderModel();
		BeanUtils.copyProperties(cntrctOrderBasVO, orderModel);
		
		Map<String, Object> validationResult = orderService.getSameDayDeliveryInfo(orderModel);
		
		// 케이지 배송(01)일 때 배송 가능 지역(00)이 아니거나, 
		// 당일 배송이 불가능한 경우
		// 유효성 검사 실패로 validationResult 값을 return
		if( (StringUtils.equals(cntrctOrderBasVO.getDlvyMnCode(),"01") && !StringUtils.equals(String.valueOf(validationResult.get("lastSvcSeCode")), "00"))
				|| !(boolean)validationResult.get("sameDayDeliveryStatus") ) {
			validationResult.put("validationResult", false);
			return validationResult;
		} else {
			// 유효성 검사 성공
			result.put("validationResult", true);
		}
		
		// 단가 확정 일자 계산 및 세팅
		Calendar cntrctYm = DateUtil.getCalendar(cntrctOrderBasVO.getCntrctYm()+"01");
		
		int qpCode = Integer.parseInt(cntrctOrderBasVO.getQpCode());
		cntrctYm.add(Calendar.MONTH, qpCode);
		
		int dayOfMonth = cntrctYm.getActualMaximum(Calendar.DAY_OF_MONTH);
		cntrctYm.set(Calendar.DAY_OF_MONTH, dayOfMonth);
		
		cntrctOrderBasVO.setUntpcDcsnDe(DateUtil.getCalendar(cntrctYm));
		
		// 발주 번호 채번
		// 채번 규칙 : YYYYMMDD-A00000(숫자 5자리(MAX)) : 년도에 따라 5자리 채번 증가
		StringBuilder sb = new StringBuilder(DateUtil.calDate("yyyyMMdd"));
		sb.append("-P");
		sb.append(assignService.selectAssignValue("CN", "CNTRCT_ORDER_NO", DateUtil.calDate("yyyy"), "SYSTEM", 5));
		
		String cntrctOrderNo = sb.toString();
		
		cntrctOrderBasVO.setCntrctOrderNo(cntrctOrderNo);
		
		result.put("cntrctOrderNo", cntrctOrderNo);
		
		// 프라이싱 번호 및 장바구니 번호 생성 및 세팅
		getAndSetOrderInfo(cntrctOrderBasVO);
		
		// 데이터 insert & update
		orderAvrgMapper.insertCnCntrctOrderBas(cntrctOrderBasVO);
		orderAvrgMapper.insertCnCntrctOrderBasHst(cntrctOrderBasVO.getCntrctOrderNo());
		
		CommAvrgPcInvntryVO commAvrgPcInvntryVO;
		
		for (CntrctMtAsgnInvntryDtlVO cntrctMtAsgnInvntryDtlVO : orderingBlList) {
			cntrctMtAsgnInvntryDtlVO.setCntrctOrderNo(cntrctOrderNo);
			cntrctMtAsgnInvntryDtlVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());	// 회원 ID
			cntrctMtAsgnInvntryDtlVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());	// 회원 ID
			
			// 월 할당 재고 처리 공통 메소드 호출을 위한 parameter VO 생성 및 데이터 세팅
			commAvrgPcInvntryVO = new CommAvrgPcInvntryVO();
			BeanUtils.copyProperties(cntrctMtAsgnInvntryDtlVO, commAvrgPcInvntryVO);
			commAvrgPcInvntryVO.setAvrgSe("ORDER");
			commAvrgPcInvntryVO.setProcessSe("INCRS");
			commAvrgPcInvntryVO.setCalcWt(cntrctMtAsgnInvntryDtlVO.getOrderingWt());
			commAvrgPcInvntryVO.setCalcInvntry(cntrctMtAsgnInvntryDtlVO.getBundleWt());
			commAvrgPcInvntryVO.setCalcBundleInvntry(cntrctMtAsgnInvntryDtlVO.getBundleQy());
			
			// 월 할당 재고 처리 공통 메소드 호출
			commAvrgPcInvntryService.insertAndUpdateAvrgPcInvntryDdctIncrs(commAvrgPcInvntryVO);
			
			// 계약_계약 발주 상세 데이터 insert
			orderAvrgMapper.insertCnCntrctOrderDtl(cntrctMtAsgnInvntryDtlVO);
			orderAvrgMapper.insertCnCntrctOrderDtlHst(cntrctMtAsgnInvntryDtlVO.getCntrctOrderNo(), cntrctMtAsgnInvntryDtlVO.getBlNo());
		}
		
		return result;
	}

	private List<CntrctMtAsgnInvntryDtlVO> selectOrderingBlList(CntrctOrderBasVO cntrctOrderBasVO) throws Exception {
		StringBuilder sb = new StringBuilder("선택된 BL : ");	// 로그 처리
		List<CntrctMtAsgnInvntryDtlVO> returnBlList = new ArrayList<>();
		/**
		 * * 할당된 BL 리스트를 하기된 우선순위, 정렬조건에 따라 정렬하여 조회 (우선순위가 높은 BL 먼저 사용)
		 * 
		 * 1. 해당 BL의 미발주 중량(UNORDER_WT) - 현재 발주 중량(cntrctOrderBasVO.getOrderWt()) 의 절대값(ABS)이 가장 작은 순
		 * 2. BL의 미발주 중량(UNORDER_WT) 이 큰 순
		 * 3. BL의 브랜드 코드(BRAND_CODE) 알파벳 순
		 * 4. BL의 자체 "우선 순위(PRIOR_RANK)"가 높은 순
		 * 5. BL의 입고일자가 빠른 순
		 * */
		List<CntrctMtAsgnInvntryDtlVO> asgnBlList = orderAvrgMapper.selectAsgnBlList(cntrctOrderBasVO);
		
		int remainOrderWt = cntrctOrderBasVO.getOrderWt();	// 남은 발주 중량, 0이되면 로직 종료
		float sleUnitWt = cntrctOrderBasVO.getSleUnitWt();	// 판매 단위 중량
		
		if(remainOrderWt <= 0) {
			throw new CommCustomException("중량이 선택 또는 입력되지 않았습니다.");
		}
		
		if(asgnBlList.isEmpty()) {
			throw new CommCustomException("사용 가능한 재고가 존재하지 않습니다.\r\n\r\n관리자에게 문의바랍니다.");
		}
		
		// 첫번째 BL의 창고 코드
		// 발주 한 건당 "같은 창고의 BL이여야함"으로 사용되는 BL별 창고 코드가 같은지 체크 필요
		String wrhousCode = asgnBlList.get(0).getWrhousCode();
		
		// 우선순위에 따라 정렬되어 조회된 BL 순서대로 로직 수행, 남은 발주 중량(remainOrderWt)이 0이 되면 로직 종료
		for (CntrctMtAsgnInvntryDtlVO asgnBl : asgnBlList) {
			// 같은 창고의 BL이 아니면 사용하지 않고 로직 SKIP
			if(!StringUtils.equals(wrhousCode, asgnBl.getWrhousCode())) {
				log.info("현재 사용하고자 하는 BL의 창고 코드가 첫 번째로 사용된 BL의 창고 코드와 달라서,\r\n"
						+ "현재 BL을 사용하지 않고 로직 SKIP\r\n"
						+ "첫 번째 BL의 창고 코드 : {}\r\n"
						+ "현재 BL의 창고 코드 : {}", wrhousCode, asgnBl.getWrhousCode());
				
				continue;
			}
			
			sb.append(asgnBl.getBlNo());	// 사용 BL 로그 처리
			
			int unorderWt = asgnBl.getUnorderWt();	// 해당 BL의 미발주 중량
			
			if(remainOrderWt >= unorderWt ) {	// 남은 발주 중량이 해당 BL의 미발주 중량보다 크거나 같은 경우, 해당 BL 재고를 전부 사용
				// 1. 발주 관련 데이터들에 미발주 관련 데이터들을 더해서 세팅 
				// 23-12-04 변경사항 : 재고 처리 로직을 공통 메소드로 처리함에 따라 관련 로직 제거
//				asgnBl.setOrderWt(asgnBl.getOrderWt() + unorderWt);
//				asgnBl.setOrderInvntry(asgnBl.getOrderInvntry() + asgnBl.getUnorderInvntry());
//				asgnBl.setOrderBundleInvntry(asgnBl.getOrderBundleInvntry() + asgnBl.getUnorderBundleInvntry());
				
				// 2. 계약_계약 발주 상세(CN_CNTRCT_ORDER_DTL) Table Insert 용 데이터 세팅
				asgnBl.setOrderingWt(unorderWt);
				asgnBl.setBundleWt(asgnBl.getUnorderInvntry());
				asgnBl.setBundleQy(asgnBl.getUnorderBundleInvntry());
				
				// 3. 미발주 관련 데이터들을 0으로 세팅
				// 23-12-04 변경사항 : 재고 처리 로직을 공통 메소드로 처리함에 따라 관련 로직 제거
//				asgnBl.setUnorderWt(0);
//				asgnBl.setUnorderInvntry(0);
//				asgnBl.setUnorderBundleInvntry(0);
				
				// 4. 해당 BL을 return 해주기 위해 return 리스트에 add
				returnBlList.add(asgnBl);
				
				// 5. 남은 발주 중량(remainOrderWt)에서 미발주 중량(unorderWt)만큼 차감
				//    남은 발주 중량(remainOrderWt)이 있을 경우, 현재 반복문에서 다음 BL로 넘어가서 로직 재수행
				//    남은 발주 중량(remainOrderWt)이 0일 경우, 로직 종료
				remainOrderWt -= unorderWt;
			} else {	// 남은 발주 중량이 해당 BL의 미발주 중량보다 클 경우, 해당 BL에서 남은 발주 중량에 대한 재고 차감 처리
				
				// 1. 발주 번들 수량 계산 (소수 첫째 자리에서 반올림)
				// 계산식 : ROUND( (해당BL 미발주 번들 재고 / ( 해당BL 미발주 중량 / 판매 단위 중량 )) * ( 남은 발주 중량 / 판매 단위 중량 ) )
				int orderingBundleQy = Math.round(
												( asgnBl.getUnorderBundleInvntry() / (asgnBl.getUnorderWt() / sleUnitWt) )
												* (remainOrderWt / sleUnitWt)
											);
				
				// 2. 발주 재고 중량 계산
				// 계산식 : 위에서 계산된 발주 번들 수량(orderingBundleQy) * 해당 BL의 평균 중량
				BigDecimal orderingInvntryWt = BigDecimal.valueOf(orderingBundleQy).multiply(asgnBl.getNetAvrgWt());
				
				// 3. 기존 발주 관련 데이터에, 위에서 계산된 발주 관련 데이터를 더해서 세팅
				// 23-12-04 변경사항 : 재고 처리 로직을 공통 메소드로 처리함에 따라 관련 로직 제거
//				asgnBl.setOrderWt(asgnBl.getOrderWt() + remainOrderWt);
//				asgnBl.setOrderInvntry(asgnBl.getOrderInvntry() + orderingInvntryWt);
//				asgnBl.setOrderBundleInvntry(asgnBl.getOrderBundleInvntry() + orderingBundleQy);
				
				// 4. 계약_계약 발주 상세(CN_CNTRCT_ORDER_DTL) Table Insert 용 데이터 세팅
				asgnBl.setOrderingWt(remainOrderWt);
				asgnBl.setBundleWt(orderingInvntryWt);
				asgnBl.setBundleQy(orderingBundleQy);
				
				// 5. 기존 미발주 관련 데이터에, 계산된 발주 관련 데이터를 빼서 세팅 
				// 23-12-04 변경사항 : 재고 처리 로직을 공통 메소드로 처리함에 따라 관련 로직 제거
//				asgnBl.setUnorderWt(asgnBl.getUnorderWt() - remainOrderWt);
//				asgnBl.setUnorderInvntry(asgnBl.getUnorderInvntry() - orderingInvntryWt);
//				asgnBl.setUnorderBundleInvntry(asgnBl.getUnorderBundleInvntry() - orderingBundleQy);
				
				// 6. 해당 BL을 return 해주기 위해 return 리스트에 add
				returnBlList.add(asgnBl);
				
				// 7. 해당 BL에서 남은 발주 중량을 전부 발주 처리했으니, 0으로 세팅하고 로직 종료
				remainOrderWt = 0;
			}
			
			if(remainOrderWt == 0) break;
			
			sb.append(", ");	// 사용 BL 로그 처리
		}
		
		log.info(sb.toString());	// 사용 BL 로그 처리
		
		if(remainOrderWt > 0) {
			throw new CommCustomException("현재 사용 가능한 재고가 부족합니다.\r\n\r\n관리자에게 문의바랍니다.");
		}
		
		return returnBlList;
	}
	
	private void getAndSetOrderInfo(CntrctOrderBasVO cntrctOrderBasVO) throws Exception {
		ItemPriceSelectVO itemPriceSelectVO = new ItemPriceSelectVO();	// 프라이싱 번호, 장바구니 번호 등의 주문 정보 생성을 위한 param VO
		
		// 주문 정보 생성 parameter copy
		BeanUtils.copyProperties(cntrctOrderBasVO, itemPriceSelectVO);
		
		// 프라이싱 번호 생성 시 필요한 데이터 세팅
		itemPriceSelectVO.setPremiumNo("");
		itemPriceSelectVO.setGoodsUntpc(0);
		
		// 장바구니 번호 생성 및 세팅
		String bsktNo = itemPriceService.insertOrderBasket(itemPriceSelectVO);
		itemPriceSelectVO.setBsktNo(bsktNo);
		cntrctOrderBasVO.setBsktNo(bsktNo);
		
		// 프라이싱 번호 생성 및 세팅
		cntrctOrderBasVO.setPricingNo(itemPriceService.insertOrderPricing(itemPriceSelectVO).getPricingNo());
	}

	@Override
	public void cancelOrdering(CntrctOrderBasVO cntrctOrderBasVO) throws Exception {
		cntrctOrderBasVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());	// 회원 ID
		
		CommAvrgPcInvntryVO commAvrgPcInvntryVO;
		
		// 재고 원복 처리를 위해 대상 발주 주문의 재고 정보 select
		List<CntrctOrderDtlVO> invntryList = orderAvrgMapper.selectCntrctOrderDtl(cntrctOrderBasVO.getCntrctOrderNo());
		
		// 조회된 재고 정보로 재고 테이블 update
		for (CntrctOrderDtlVO cntrctOrderDtlVO : invntryList) {
			cntrctOrderDtlVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());	// 회원 ID
			
			// 월 할당 재고 처리 공통 메소드 호출을 위한 parameter VO 생성 및 데이터 세팅
			commAvrgPcInvntryVO = new CommAvrgPcInvntryVO();
			BeanUtils.copyProperties(cntrctOrderDtlVO, commAvrgPcInvntryVO);
			commAvrgPcInvntryVO.setAvrgSe("ORDER");
			commAvrgPcInvntryVO.setProcessSe("DDCT");
			commAvrgPcInvntryVO.setCalcWt((int)cntrctOrderDtlVO.getOrderWt());
			commAvrgPcInvntryVO.setCalcInvntry(cntrctOrderDtlVO.getBundleWt());
			commAvrgPcInvntryVO.setCalcBundleInvntry(cntrctOrderDtlVO.getBundleQy());
			
			// 월 할당 재고 처리 공통 메소드 호출
			commAvrgPcInvntryService.insertAndUpdateAvrgPcInvntryDdctIncrs(commAvrgPcInvntryVO);
		}
		
		// 발주 테이블에서 대상 발주 건 삭제 처리 (update)
		orderAvrgMapper.deleteCntrctOrderBas(cntrctOrderBasVO);
		orderAvrgMapper.insertCnCntrctOrderBasHst(cntrctOrderBasVO.getCntrctOrderNo());
		
		orderAvrgMapper.deleteCntrctOrderDtl(cntrctOrderBasVO);
		orderAvrgMapper.insertCnCntrctOrderDtlHst(cntrctOrderBasVO.getCntrctOrderNo(), null);
	}

	@Override
	public String getSetleTmlmtDe(CntrctOrderBasVO cntrctOrderBasVO) throws Exception {
		String dlivyRequstDe = cntrctOrderBasVO.getDlivyRequstDe();
		String cntrctYm = cntrctOrderBasVO.getCntrctYm() + "01";
		String invntryAsgnSeCode = cntrctOrderBasVO.getInvntryAsgnSeCode();
		String nowDate = DateUtil.getNowDate();	// yyyyMMdd
		
		if(StringUtils.equals(dlivyRequstDe, nowDate)) {
			return DateUtil.getFormatDate(nowDate, "yy-MM-dd");
		}
		
		// 계약월의 바로 다음달(익월) 첫날로 세팅
		cntrctYm = DateUtil.addMonths(cntrctYm, 1).replaceAll("-", "");
		
		// 평균가 발주의 경우 && 배송요청일이 익월 둘째영업일~말일 일 경우 
		// 결제일을 전월 마지막 영업일로 강제 자동 설정함
		// 위의 경우, 결제일 계산을 위해 배송요청일을 익월 첫날로 설정
		if(StringUtils.equals(invntryAsgnSeCode, "20") && DateUtil.compareToCalerdar(dlivyRequstDe, cntrctYm) > 0) {
			dlivyRequstDe = cntrctYm;
		}
		
		return orderAvrgMapper.getSetleTmlmtDe(dlivyRequstDe);
	}
	
	// 내부담당자 SMS 전송
	private void sendSMSToInnerDepartment(String templateNum, Map<String, String> smsMap) {
		smsMap.put("templateNum", templateNum);
		smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
		
		SMSVO smsVo = new SMSVO();
		
		smsService.insertSMS(smsVo, smsMap);
	}
}
