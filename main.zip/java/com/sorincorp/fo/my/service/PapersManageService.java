package com.sorincorp.fo.my.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.fo.my.model.PapersManageDetailVO;
import com.sorincorp.fo.my.model.PapersManageVO;

/**
 * 
 * 서류 관리 Service.java
 * @version
 * @since 2021. 9. 8.
 * @author srec0054
 */
public interface PapersManageService {

	/**
	 * 
	 * <pre>
	 * 서류관리 리스트 카운트
	 * </pre>
	 * @date 2021. 9. 8.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 8.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	PapersManageVO paramVo
	 * @return	Integer
	 */
	Integer selectPapersManageCnt(PapersManageVO paramVo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 서류관리 리스트 조회 
	 * </pre>
	 * @date 2021. 9. 8.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 8.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	PapersManageVO paramVo
	 * @return	List<PapersManageVO>
	 */
	List<PapersManageVO> selectPapersManage(PapersManageVO paramVo) throws Exception;
	
	/**
	 * 	
	 * <pre>
	 * 마이페이지 > 서류 관리 > 서류 관리 상세 : 페이지 로드
	 * </pre>
	 * @date 2021. 9. 13.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 13.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	PapersManageDetailVO paramVo
	 * @return	List<PapersManageDetailVO>
	 */
	List<PapersManageDetailVO> selectPapersManageDetailList(PapersManageDetailVO paramVo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 서류관리 상세 리스트 카운트
	 * </pre>
	 * @date 2021. 9. 13.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 13.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	PapersManageDetailVO paramVo
	 * @return	Integer
	 * @throws 	Exception
	 */
	Integer selectPapersManageDetailListCnt(PapersManageDetailVO paramVo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 서류관리 상세 리스트 조회
	 * </pre>
	 * @date 2021. 9. 13.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 13.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	PapersManageDetailVO paramVo
	 * @return	List<PapersManageDetailVO>
	 * @throws 	Exception
	 */
	List<PapersManageDetailVO> selectPapersManage(PapersManageDetailVO paramVo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 성적서&패킹리스트 리스트 조회
	 * </pre>
	 * @date 2021. 9. 24.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 24.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	PapersManageDetailVO paramVo
	 * @return	List<PapersManageDetailVO>
	 * @throws 	Exception
	 */
	List<PapersManageDetailVO> selectScreofePackngList(PapersManageDetailVO paramVo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용:1차, 2차 매매계약서 내부 거래명세서, 세금계산서 ozReport 실행시 필요한 파라미터를 다시 조회한다.
	 * </pre>
	 * @date 2024. 01. 24.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 24.		sein					최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	List<Map<String, Object>> selectTaxTradeBillInfo(String orderNo)throws Exception;
	
	
	/**
	 * 
	 * <pre>
	 * 상단 대시보드 결제수단 조회
	 * </pre>
	 * @date 2021. 10. 1.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 1.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	PapersManageVO dashBoardParamVo
	 * @return	PapersManageVO
	 * @throws 	Exception
	 */
	PapersManageVO selectSetleMnInfo(PapersManageVO dashBoardParamVo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 최근 30일 거래내역, 상단 대시보드 주문현황
	 * </pre>
	 * @date 2021. 10. 5.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 5.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param 	PapersManageVO dashBoardParamVo
	 * @return	PapersManageVO
	 * @throws 	Exception
	 */
	PapersManageVO selectRecentOrderDtls(PapersManageVO dashBoardParamVo) throws Exception; 
			
	/**
	 * 
	 * <pre>
	 * 출고지시서 화물수취인 전화번호 복호화
	 * </pre>
	 * @date 2022. 4. 19.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 4. 19.			srec0054			최초작성
	 * ------------------------------------------------
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	String updateMoblphonNoDecryption(PapersManageDetailVO paramVo) throws Exception;

	List<PapersManageDetailVO> getRelatePapersInfo(PapersManageDetailVO papersManageDetailVO) throws Exception;

	String getMberEwalletAcntNo(String orderNo) throws Exception;
	
	String getAllChangegldCnfrmn(String orderNo) throws Exception;
	
}//end interface()