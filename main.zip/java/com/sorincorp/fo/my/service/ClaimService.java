package com.sorincorp.fo.my.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.fo.my.model.OrderDtlsVO;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.order.model.OrderDtlsClaimVO;

public interface ClaimService {

	/**
	 * <pre>
	 * 클레임 데이터 조회
	 * </pre>
	 * @date 2021. 9. 27.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 27.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param searchVo
	 * @return
	 */
	OrderDtlsClaimVO getClaimData(OrderDtlsVO searchVo) throws Exception;

	/**
	 * <pre>
	 * 클레임 신청 처리
	 * </pre>
	 * @date 2021. 10. 5.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 5.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param claimVo
	 * @throws Exception
	 */
	int requestClaim(OrderDtlsClaimVO claimVo) throws Exception;

	/**
	 * <pre>
	 * 첨부파일 조회
	 * </pre>
	 * @date 2021. 11. 16.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 16.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<FileDocVO> selectListFileDocInfo(OrderDtlsClaimVO vo) throws Exception;

	/**
	 * <pre>
	 * 거래명세서, 세금계산서 ozReport 정보 조회
	 * </pre>
	 * @date 2021. 12. 1.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 1.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param searchVo
	 * @return
	 */
	Map<String, Object> getTaxBillInfo(OrderDtlsVO searchVo) throws Exception;

}
