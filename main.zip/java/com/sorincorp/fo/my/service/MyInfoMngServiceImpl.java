/**
 *
 */
package com.sorincorp.fo.my.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.mb.service.MbCmnCodeService;
import com.sorincorp.fo.my.mapper.MyInfoMngMapper;
import com.sorincorp.fo.my.model.MyInfoMngVO;

import lombok.extern.slf4j.Slf4j;

/**
 * MyInfoMngServiceImpl.java
 *
 * @version
 * @since 2021. 8. 23.
 * @author srec0009
 */
@Slf4j
@Service
public class MyInfoMngServiceImpl implements MyInfoMngService {

	@Autowired
	private MyInfoMngMapper myInfoMngMapper;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private MailService mailService;

	@Autowired
	private SMSService smsService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	@Autowired
	private CommonService commonService;
	
	/** 이메일 발송 매퍼 */
    @Autowired
    private MailMapper mailMapper;
    
	@Override
	public String selectChkPw(String mberNo, String mberSecretNo) {

		String chkPw = myInfoMngMapper.selectChkPw(mberNo);
		String result = "";
		log.debug(result);
		log.debug(chkPw);
		log.debug(CryptoUtil.encryptSHA256(mberSecretNo));
		if (CryptoUtil.encryptSHA256(mberSecretNo).matches(chkPw)) {
			result = "S";
		} else {
			result = "F";
		}
		return result;
	}

	@Override
	public MyInfoMngVO selectMyInfoMngDtl(String mberNo) {
		MyInfoMngVO vo = myInfoMngMapper.selectMyInfoMngDtl(mberNo);

		String moblphonNo = vo.getMoblphonNo();

		if (moblphonNo != null && !"".equals(moblphonNo)) {
			try {
				log.debug("휴대폰 복호화 전 ===============>" + moblphonNo);
				moblphonNo = CryptoUtil.decryptAES256(moblphonNo);
				log.debug("휴대폰 복호화 후 ===============>" + moblphonNo);
				vo.setMoblphonNo(moblphonNo);
			} catch (Exception e) {
				// TODO: handle exception
				log.error("selectMyInfoMngDtl MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}
		return vo;
	}

	@Override
	public String updateNewPw(String mberNo, String mberSecretNo) {

		if (userInfoUtil.getAccountInfo() == null) {
			return "F";
		}

		String data = "";

		MyInfoMngVO myInfoMngVO = new MyInfoMngVO();

		myInfoMngVO.setMberNo(mberNo);
		myInfoMngVO.setMberSecretNo(CryptoUtil.encryptSHA256(mberSecretNo));
		myInfoMngVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());

		int result = myInfoMngMapper.updateNewPw(myInfoMngVO);
		myInfoMngMapper.insertMberInfoHst(mberNo);

		if (result < 1) {
			data = "F";
		} else {
			data = "S";
		}
		return data;
	}

	@Override
	public String updateMyInfoDtl(String mberNo, MyInfoMngVO myInfoMngVO) {
		if (userInfoUtil.getAccountInfo() == null) {
			return "F";
		}
		String data = "F";
		myInfoMngVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
		myInfoMngVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		myInfoMngVO.setMberNo(mberNo);
		String crtfcAt = myInfoMngVO.getSelfCrtfcDt();

		String moblphonNo = "";
		int result = 0;
		int marktResult = 0;

		try {
			// 핸드폰 번호 변경 안한 경우
			if ("".equals(crtfcAt) || crtfcAt == null) {
				if (myInfoMngVO.getMarktRecptnSms().equals("N") && myInfoMngVO.getMarktRecptnPush().equals("N") && myInfoMngVO.getMarktRecptnEmail().equals("N")) {
					myInfoMngVO.setAdvrtsRecptnAgreAt("N");
				} else {
					myInfoMngVO.setAdvrtsRecptnAgreAt("Y");
				}

				marktResult = myInfoMngMapper.updateMberMarktRecptnMediaBas(myInfoMngVO); // 마케팅 수신동의 여부
				result = myInfoMngMapper.updateMyInfoDtl(myInfoMngVO);
				if (result > 0 && marktResult > 0) {
					data = "S";
					commonService.insertTableHistory("MB_MBER_INFO_BAS", myInfoMngVO);
					commonService.insertTableHistory("MB_MBER_MARKT_RECPTN_MEDIA_BAS", myInfoMngVO);
				}
			} else {

				moblphonNo = myInfoMngVO.getMoblphonNo();

				if (moblphonNo != null && !"".equals(moblphonNo)) {
					moblphonNo = moblphonNo.replaceAll("[^0-9]", "");

					try {
						log.debug("휴대폰 암호화 전 ===============>" + moblphonNo);
						moblphonNo = CryptoUtil.encryptAES256(moblphonNo);
						log.debug("휴대폰 암호화 후 ===============>" + moblphonNo);
						myInfoMngVO.setMoblphonNo(moblphonNo);
					} catch (Exception e) {
						// TODO: handle exception
						log.error("updateMyInfoDtl MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
					}
				}

				if (myInfoMngVO.getMarktRecptnSms().equals("N") && myInfoMngVO.getMarktRecptnPush().equals("N") && myInfoMngVO.getMarktRecptnEmail().equals("N")) {
					myInfoMngVO.setAdvrtsRecptnAgreAt("N");
				} else {
					myInfoMngVO.setAdvrtsRecptnAgreAt("Y");
				}

				marktResult = myInfoMngMapper.updateMberMarktRecptnMediaBas(myInfoMngVO); // 마케팅 수신동의 여부
				result = myInfoMngMapper.updateMyInfoDtlMob(myInfoMngVO);

				if (result > 0 && marktResult > 0) {
					data = "S";
					commonService.insertTableHistory("MB_MBER_INFO_BAS", myInfoMngVO);
				}
			}
		} catch (Exception e) {
			data = "F";
		}
		return data;
	}

	@Override
	public String deleteEntrpsMber(MyInfoMngVO myInfoMngVO) throws Exception {

		if (userInfoUtil.getAccountInfo() == null) {
			return "Error";
		}
		String retVal = "";
		String secsnAt = myInfoMngMapper.selectMembWithdrawCheck(userInfoUtil.getAccountInfo().getMberNo());

		if ("Y".equals(secsnAt) || "00".equals(secsnAt)) {
			try {
				// 회원 상태 업데이트
				myInfoMngVO.setMberNo(userInfoUtil.getAccountInfo().getMberNo());
				myInfoMngVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
				myInfoMngMapper.deleteEntrpsMber(myInfoMngVO);

				MyInfoMngVO vo = myInfoMngMapper.selectSecsnMber(userInfoUtil.getAccountInfo().getMberNo());
				// 탈퇴 신청 코드
				vo.setSecsnTyCode("03");
				vo.setEtcSecsnResn(myInfoMngVO.getEtcSecsnResn());
				// 탈퇴 회원 테이블 - 암호화 데이터를 조회한 후에 다시 insert하기 때문에 복호화나 암호화를 따로 하지 않는다.
				myInfoMngMapper.insertMbSecsnMberBas(vo);
				// 회원 이력 테이블
				myInfoMngMapper.insertMberInfoHst(vo.getMberNo());
				retVal = "S";
			} catch (Exception e) {
				retVal = "Error";
			}
		} else {
			// retVal = "F";
			if ("N".equals(secsnAt)) {
				retVal = "F";
			} else if ("01".equals(secsnAt) || "02".equals(secsnAt)) {
				// 01:주문 진행건 존재, 02:가상계좌 잔액존재
				retVal = secsnAt;
			}
		}
		return retVal;
	}

	@Override
	public String deleteMber(MyInfoMngVO myInfoMngVO) throws Exception {

		if (userInfoUtil.getAccountInfo() == null) {
			return "Error";
		}

		String result = "";
		String serviceDomain = "www.kztraders.com";
		// 진행 중인 주문 건 or 상담 건 있는지 체크
		String secsnAt = myInfoMngMapper.selectMembWithdrawCheck(userInfoUtil.getAccountInfo().getMberNo());

		String moblphonNo = "";

		if ("Y".equals(secsnAt) || "00".equals(secsnAt)) {
			try {
				// 탈퇴 사유 세팅
				myInfoMngVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
				// 멤버 테이블 upd
				myInfoMngMapper.deleteMber(myInfoMngVO);
				MyInfoMngVO mberInfo = myInfoMngMapper.selectSecsnMber(myInfoMngVO.getMberNo());
				// 탈퇴 유형 코드 - 일반
				mberInfo.setSecsnTyCode("01");
				mberInfo.setEtcSecsnResn(myInfoMngVO.getEtcSecsnResn());
				mberInfo.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
				mberInfo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
				// 탈퇴 테이블 insert
				myInfoMngMapper.insertMbSecsnMberBas(mberInfo);
				// 회원 이력 테이블
				myInfoMngMapper.insertMberInfoHst(mberInfo.getMberNo());

				// 휴대폰 번호 복호화 20220118 srec0030
				moblphonNo = mberInfo.getMoblphonNo();

				if (moblphonNo != null && !"".equals(moblphonNo)) {

					try {
						log.debug("휴대폰 복호화 전 ===============>" + moblphonNo);
						moblphonNo = CryptoUtil.decryptAES256(moblphonNo);
						log.debug("휴대폰 복호화 전 ===============>" + moblphonNo);
						moblphonNo = moblphonNo.replaceAll("[^0-9]", "");
					} catch (Exception e) {
						// TODO: handle exception
						log.error("deleteMber MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
					}
				}

				String templateNum = "42";
				String title = mbCmnCodeService.selectMssageSj(templateNum);

				Map<String, String> msgMap = new HashMap<>();
				SMSVO smsVO = new SMSVO();
				msgMap.put("templateNum", templateNum); // 메시지 템플릿 번호
				msgMap.put("entrpsnmKorean", mberInfo.getEntrpsnmKorean());
				msgMap.put("mberNm", mberInfo.getMberNm());
				msgMap.put("mberId", mberInfo.getMberId());
				msgMap.put("secessionDt", mberInfo.getSecsnDt());
				msgMap.put("Servicedomain", serviceDomain);
				// smsVO.setPhone(mberInfo.getMoblphonNo()); // 받는사람 번호
				smsVO.setPhone(moblphonNo); // 받는사람 번호(복호화)
				smsVO.setMberNo(mberInfo.getMberNo());
				smsVO.setMsgTitle(title);
				smsService.insertSMS(smsVO, msgMap); // 메소드 호출

				Map<String, String> mailMap = new HashMap<>();
				MailVO mailVO = new MailVO();
				MailVO selectMailTmpt = mailMapper.selectMailTmpt(42);          // 발신자 이메일 가져오기
                mailVO.setMailTmptSeq(42); // 사용할 템플릿 번호 지정
				mailVO.setEmail(mberInfo.getMberEmail()); // 수신자 메일 주소
				mailVO.setMailSendUserId("admin"); // 보내는 사람 아이디
				mailVO.setMailSendEmail(selectMailTmpt.getSntoEmail()); // 보내는 사람 이메일
				mailVO.setMemberNo(userInfoUtil.getAccountInfo().getMberNo());
				mailMap.put("entrpsnmKorean", mberInfo.getEntrpsnmKorean());
				mailMap.put("mberNm", mberInfo.getMberNm());
				mailMap.put("mberId", mberInfo.getMberId());
				mailMap.put("secessionDt", mberInfo.getSecsnDt());
				mailService.insertMailSend(mailVO, mailMap);

				result = "S";
			} catch (Exception e) {
				result = "Error";
			}
		} else {
			// result = "F";
			if ("N".equals(secsnAt)) {
				result = "F";
			} else if ("01".equals(secsnAt) || "02".equals(secsnAt)) {
				// 01:주문 진행건 존재, 02:가상계좌 잔액존재
				result = secsnAt;
			}
		}
		return result;
	}

	@Override
	public MyInfoMngVO selectAgreAt(MyInfoMngVO myInfoMngVO) {
		return myInfoMngMapper.selectAgreAt(myInfoMngVO);
	}

	@Override
	public String selectSecsnPossCodeNm(String mberNo) throws Exception {
		// TODO Auto-generated method stub
		String secsnPossCodeNm = "";
		String secsnAt = myInfoMngMapper.selectMembWithdrawCheck(mberNo);

		if ("01".equals(secsnAt) || "02".equals(secsnAt)) {
			secsnPossCodeNm = myInfoMngMapper.selectSecsnPossCodeNm(secsnAt);
		}

		return secsnPossCodeNm;
	}

}
