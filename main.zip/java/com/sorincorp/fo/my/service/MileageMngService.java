package com.sorincorp.fo.my.service;

import java.util.List;

import com.sorincorp.fo.my.model.MileageMngVO;

public interface MileageMngService {

	List<MileageMngVO> selectMbMileageMngList(MileageMngVO mileageMngVO) throws Exception;

	Integer selectMbMileageMngListCnt(MileageMngVO mileageMngVO) throws Exception;

	MileageMngVO selectMbMileageMngSeList(MileageMngVO mileageMngVO) throws Exception;

}
