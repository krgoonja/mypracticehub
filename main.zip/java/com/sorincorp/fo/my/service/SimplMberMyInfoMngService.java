/**
 *
 */
package com.sorincorp.fo.my.service;

import com.sorincorp.fo.my.model.SimplMberMyInfoMngVO;

/**
 * MyInfoMngService.java
 * @version
 * @since 2021. 8. 23.
 * @author srec0009
 */
public interface SimplMberMyInfoMngService{

	/**
	 * <pre>
	 * 처리내용: 간편회원 내정보관리
	 * </pre>
	 * @date 2021. 8. 31.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 31.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simplMberNo
	 * @return
	 */
	SimplMberMyInfoMngVO selectSimplMberInfo(String simplMberNo);

	/**
	 * <pre>
	 * 처리내용: 간편회원 비밀번호 확인
	 * </pre>
	 * @date 2021. 9. 1.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 1.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @param mberSecretNo
	 * @return
	 */
	String selectChkPw(String mberNo, String mberSecretNo);

	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경
	 * </pre>
	 * @date 2021. 9. 1.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 1.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @param mberSecretNo
	 * @return
	 */
	String updateNewPw(String mberNo, String mberSecretNo);

	/**
	 * <pre>
	 * 처리내용: 간편회원 정보 수정
	 * </pre>
	 * @date 2021. 9. 1.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 1.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param myInfoMngVO
	 * @return
	 */
	String updateSimplMberMyInfoDtl(String mberNo, SimplMberMyInfoMngVO simplMberMyInfoMngVO);

	/**
	 * <pre>
	 * 처리내용: 간편회원 탈퇴
	 * </pre>
	 * @date 2021. 9. 6.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 6.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simplMberMyInfoMngVO
	 * @return
	 */
	int deleteSimplMber(SimplMberMyInfoMngVO simplMberMyInfoMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 22.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 22.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simplMberMyInfoMngVO
	 * @return
	 */
	SimplMberMyInfoMngVO selectAgreAt(SimplMberMyInfoMngVO simplMberMyInfoMngVO);


}
