package com.sorincorp.fo.my.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.cs.model.InqryRegistVO;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.my.mapper.InqryDtlsMapper;
import com.sorincorp.fo.my.model.InqryDtlsVO;

import lombok.extern.slf4j.Slf4j;

/**
 * InqryDtlsServiceImpl.java
 * @version
 * @since 2021. 7. 28.
 * @author srec0048
 */
@Slf4j
@Service
public class InqryDtlsServiceImpl implements InqryDtlsService {

	@Autowired
	InqryDtlsMapper inqryDtlsMapper;
	@Autowired
	public FileDocService fileDocService;
	@Autowired
	private UserInfoUtil userInfoUtil;
	@Autowired
	MessageUtil messageUtil;


	/**
	 * 공통코드 스트링으로 변환한다.
	 */
	@Override
	public String getCommCodeListStr(Map<String, String> commonCode, String gb) throws Exception{
		StringBuilder codeTaglibStr = new StringBuilder();

		codeTaglibStr.append("");
		codeTaglibStr.append(CommonConstants.COLONE);
		if ("emailDomain".equals(gb)) {
			codeTaglibStr.append("직접입력");
		} else {
			codeTaglibStr.append("선택해 주세요.");
		}
		codeTaglibStr.append(CommonConstants.SEMI_COLONE);

		for (Map.Entry<String,String> entry : commonCode.entrySet()) {
		    codeTaglibStr.append(entry.getKey());
			codeTaglibStr.append(CommonConstants.COLONE);
			codeTaglibStr.append(entry.getValue());
			codeTaglibStr.append(CommonConstants.SEMI_COLONE);
		}

		return codeTaglibStr.toString();
	}

	/**
	 * 문의내역 총건수를 조회한다.
	 */
	@Override
	public int selectInqryDtlsListTotCnt(InqryDtlsVO inqryDtlsVO) throws Exception {
		Account account = userInfoUtil.getAccountInfo();

		int result = 0;
		String mberNo   = null != account ? StringUtil.nvl(account.getMberNo()) : "";		// 회원 번호
		String entrpsNo = null != account ? StringUtil.nvl(account.getEntrpsNo()) : "";	// 업체 번호
		String uType = null != account ? StringUtil.nvl(account.getType()) : "";

		inqryDtlsVO.setInqryAnswerMberNo(mberNo);
		inqryDtlsVO.setEntrpsNo(entrpsNo);

		if (uType.equals("02")) { // 간편회원
			result = inqryDtlsMapper.selectSimpleInqryDtlsListTotCnt(inqryDtlsVO);
		} else if (uType.equals("01")) { // 일반회원
			result = inqryDtlsMapper.selectInqryDtlsListTotCnt(inqryDtlsVO);
		}

		return result;
	}

	/**
	 * 문의내역 리스트를 조회한다.
	 */
	@Override
	public List<InqryDtlsVO> selectInqryDtlsList(InqryDtlsVO inqryDtlsVO) throws Exception {
		// 세션정보
		Account account = userInfoUtil.getAccountInfo();

		List<InqryDtlsVO> list = new ArrayList<>();

		String mberNo   = null != account ? StringUtil.nvl(account.getMberNo()) : "";		// 회원 번호
		String entrpsNo = null != account ? StringUtil.nvl(account.getEntrpsNo()) : "";	// 업체 번호
		String uType = null != account ? StringUtil.nvl(account.getType()) : "";

		inqryDtlsVO.setInqryAnswerMberNo(mberNo);
		inqryDtlsVO.setEntrpsNo(entrpsNo);
		inqryDtlsVO.setMberNo(mberNo);

		if (uType.equals("02")) { // 간편회원
			list = inqryDtlsMapper.selectSimpleInqryDtlsList(inqryDtlsVO);
		} else if (uType.equals("01")) { // 일반회원
			list = inqryDtlsMapper.selectInqryDtlsList(inqryDtlsVO);
		}

		return list;
	}

	/**
	 * 문의내역 상세를 조회한다.
	 */
	@Override
	public InqryDtlsVO selectInqryDtlsDetail(InqryDtlsVO inqryDtlsVO) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		InqryDtlsVO result = null;
		String uType = null != account ? StringUtil.nvl(account.getType()) : "";

		if (uType.equals("02")) { // 간편회원
			result = inqryDtlsMapper.selectSimpleInqryDtlsDetail(inqryDtlsVO);
		} else if (uType.equals("01")) { // 일반회원
			result = inqryDtlsMapper.selectInqryDtlsDetail(inqryDtlsVO);
		}

		return result;
	}

	/**
	 * 문의내역 첨부파일 리스트 조회한다.
	 */
	@Override
	public List<FileDocVO> selectAtchFileList(long inqrySn) throws Exception {
		return inqryDtlsMapper.selectAtchFileList(inqrySn);
	}

	/**
	 * 문의구분 중분류 조회한다.
	 */
	@Override
	public List<CommonCodeVO> selectInqrySeDetailCode(Map<String, String> param) throws Exception {
		return inqryDtlsMapper.selectInqrySeDetailCode(param);
	}

	/**
	 * 첨부파일 업로드한다.
	 */
	@SuppressWarnings("finally")
	@Override
	public Map<String,Object> saveAttachFile(MultipartHttpServletRequest mRequest) throws Exception {
		Map<String,Object> map = new HashMap<>();

		// Upload할 파일의 MultipartServletRequest을 파라미터로 보내면
		// 공통 문서 기본 테이블에 문서 정보를 insert
		// Table에 등록된 문서 FileDocVO 리스트를 return
		List<FileDocVO> list = fileDocService.uploadAttachFilesVoList("CS", mRequest);// 파일 저장
		log.debug("list.get(0) ::: "+ list.get(0));

		map.put("list", list);
		return map;
//
//		int fileKeys[] = null;
//		FileDocVO fileDocVO = new FileDocVO();
//		HashMap<String, String> fileMap = new HashMap<>();
//
//		//String itmSn = mRequest.getParameter("itmSn");
//		String errMsg = "";
//
//		try {
//			fileKeys = fileDocService.uploadAttachFiles("CS", mRequest);
//			fileDocVO = fileDocService.selectDocInfo(fileKeys[0]);
//
//			fileMap.put("docNo", Integer.toString(fileKeys[0]));
//			fileMap.put("fileName", fileDocVO.getDocFileNm());
//			fileMap.put("filePath", fileDocVO.getDocFileRealCours());
//			fileMap.put("result", "S");
//
//		} catch (Exception e) {
//			log.error(e.toString());
//			errMsg = messageUtil.getMessage(e.getMessage());
//			fileMap.put("result", "F");
//		} finally {
//			fileMap.put("errMsg", errMsg);
//			return fileMap;
//		}
	}

	/**
	 * 첨부파일 삭제한다.
	 */
	@Override
	public Map<String,Object> deleteAttachFile(FileDocVO fileVO) throws Exception {
		Map<String,Object> map = new HashMap<>();

		//공통_문서 기본 - 문서 사용 여부 'N'으로 수정
		fileDocService.deleteCommonDoc(fileVO.getDocNo());
		map.put("docNo", fileVO.getDocNo());
		map.put("result","success");

		return map;
	}

	/**
	 * 문의내역을 저장한다.
	 */
	@Override
	public void insertInqrySave(InqryDtlsVO inqryDtlsVO) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		String uType= null != account ? StringUtil.nvl(account.getType()) : "";

		if( account != null ) {	// 회원일 경우
			String mberNo = StringUtil.nvl(account.getMberNo());	// 회원 번호
			String mberId = StringUtil.nvl(account.getId());	    // 회원 id
			inqryDtlsVO.setInqryAnswerMberNo(mberNo);
			inqryDtlsVO.setMberId(mberId);
		}

		if( "order".equals(inqryDtlsVO.getScrinSeCode()) ) {		// 주문상세에서 문의했을 경우
			// 문의 상담 구분 코드 - 주문문의
			inqryDtlsVO.setInqryCnsltSeCode("02");
		} else if( "item".equals(inqryDtlsVO.getScrinSeCode()) ) {	// 상품상세에서 문의했을 경우
			// 문의 상담 구분 코드 - 상품문의
			inqryDtlsVO.setInqryCnsltSeCode("03");
		} else if( "inqry".equals(inqryDtlsVO.getScrinSeCode()) ) {	// 문의내역, 고객센터-문의하기에서 문의했을 경우
			// 문의 상담 구분 코드 - 1:1문의
			inqryDtlsVO.setInqryCnsltSeCode("05");
		} else if( "estmt".equals(inqryDtlsVO.getScrinSeCode()) ) {	// 견적문의에서 문의했을 경우
			// 문의 상담 구분 코드 - 견적문의
			inqryDtlsVO.setInqryCnsltSeCode("07");
		}

		// 부모 문의 답변 순번이 없는 경우(= 추가문의가 아닌 경우)
		log.debug("insertInqrySave - inqryDtlsVO.getParntsInqryAnswerSn()  :::::  "+ inqryDtlsVO.getParntsInqryAnswerSn());
		if( inqryDtlsVO.getParntsInqryAnswerSn() == null ) {
			inqryDtlsVO.setParntsInqryAnswerSn(null);	// 부모 문의 답변 순번
			inqryDtlsVO.setInqryAnswerDp(1);			// 문의 답변 깊이
		}

		inqryDtlsVO.setInqryAnswerOrdr(1);			// 문의 답변 순서

		if (StringUtil.isNotBlank(inqryDtlsVO.getInqryTelno())) {
			inqryDtlsVO.setInqryTelno(CryptoUtil.encryptAES256(inqryDtlsVO.getInqryTelno())); // 암호화
		}

		// 문의내용 저장
		if (uType.equals("02")) { // 간편회원
			inqryDtlsMapper.insertSimpleInqrySave(inqryDtlsVO);
		} else if (uType.equals("01")) { // 일반회원
			inqryDtlsMapper.insertInqrySave(inqryDtlsVO);
		}

		long inqrySn =  inqryDtlsVO.getInqrySn();	// 문의순번
		log.debug("insertInqrySave  :::::  "+ inqrySn);
		// 문의기본이력 테이블 저장
		inqryDtlsMapper.insertCsInqryBasHst(inqrySn);

		// 문의내용 첨부파일 등록
		int[] docNos = inqryDtlsVO.getDocNos();
		for( int i = 0; i < docNos.length; i++ ) {
			inqryDtlsVO.setDocNo(docNos[i]);
			// 문서기본 첨부파일 저장
			inqryDtlsMapper.insertInqryAtchmnfile(inqryDtlsVO);
		}
		// 문서기본 첨부파일이력 테이블 저장
		inqryDtlsMapper.insertCsInqryAtchmnflBasHst(inqrySn);

	}

	/**
	 * 문의내용을 삭제한다.
	 */
	@Override
	public void deleteInqryDetail(InqryDtlsVO inqryDtlsVO) throws Exception {
		long inqrySn = inqryDtlsVO.getInqrySn();
	      // 세션정보
		Account account = null != userInfoUtil.getAccountInfo() ? userInfoUtil.getAccountInfo() : new Account();
		if (account != null) { // 회원일 경우
            String mberId = account.getId();        // 회원 id
            inqryDtlsVO.setMberId(mberId);
        }

		// 문의내역 삭제
		inqryDtlsMapper.deleteInqryDetail(inqryDtlsVO);
		// 문의내역 변경 이력을 문의 기본 이력 테이블에 저장
		inqryDtlsMapper.insertCsInqryBasHst(inqrySn);
		// 문의 첨부파일 삭제
		inqryDtlsMapper.deleteInqryDetailAtchFile(inqryDtlsVO);
		// 문의기본 첨부파일의 변경 이력을 문의 첨부파일 기본 테이블에 저장
		inqryDtlsMapper.insertCsInqryAtchmnflBasHst(inqrySn);

		FileDocVO fileVO = new FileDocVO();
		int[] docNoList = inqryDtlsVO.getDocNos();	// 문의 상세 내역에 첨부된 문서번호 리스트

		// 공통 문서 테이블에 첨부파일 삭제
		for ( int i=0; i<docNoList.length; i++ ) {
			fileVO.setDocNo(docNoList[i]);
			deleteAttachFile(fileVO);
		}
	}

	/**
	 * 개인정보 수집 및 이용 동의에 대한 안내 (약관 내용1)
	 */
	@Override
	public InqryRegistVO selectStplatCnOne() throws Exception {
		InqryRegistVO InqryRegistVo = inqryDtlsMapper.selectStplatCnOne();
		return InqryRegistVo;
	}

}
