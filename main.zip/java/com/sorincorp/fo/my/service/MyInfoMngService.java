/**
 *
 */
package com.sorincorp.fo.my.service;

import com.sorincorp.fo.my.model.MyInfoMngVO;

/**
 * MyInfoMngService.java
 * @version
 * @since 2021. 8. 23.
 * @author srec0009
 */
public interface MyInfoMngService{

	/**
	 * <pre>
	 * 처리내용: 비밀번호 확인
	 * </pre>
	 * @date 2021. 8. 23.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 23.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param data
	 * @return
	 */
	public String selectChkPw(String mberNo, String mberSecretNo);

	/**
	 * <pre>
	 * 처리내용: 내 정보 조회
	 * </pre>
	 * @date 2021. 8. 23.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 23.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @return
	 */
	public MyInfoMngVO selectMyInfoMngDtl(String mberNo);

	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경
	 * </pre>
	 * @date 2021. 8. 24.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 24.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberSecretNo
	 * @return
	 */
	public String updateNewPw(String mberNo, String mberSecretNo);

	/**
	 * <pre>
	 * 처리내용: 내정보 수정
	 * </pre>
	 * @date 2021. 8. 24.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 24.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param myInfoMngVO
	 * @return
	 */
	public String updateMyInfoDtl(String mberNo, MyInfoMngVO myInfoMngVO);

	/**
	 * <pre>
	 * 처리내용: 회원사 회원 탈퇴
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param myInfoMngVO
	 * @return
	 * @throws Exception
	 */
	public String deleteEntrpsMber(MyInfoMngVO myInfoMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원 탈퇴
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param myInfoMngVO
	 * @return
	 * @throws Exception
	 */
	public String deleteMber(MyInfoMngVO myInfoMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 22.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 22.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param myInfoMngVO
	 * @return
	 */
	public MyInfoMngVO selectAgreAt(MyInfoMngVO myInfoMngVO);

	public String selectSecsnPossCodeNm(String mberNo) throws Exception;

}
