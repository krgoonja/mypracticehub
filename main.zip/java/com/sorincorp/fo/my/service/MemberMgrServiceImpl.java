package com.sorincorp.fo.my.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.my.mapper.MemberMgrMapper;
import com.sorincorp.fo.my.model.MemberMgrVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MemberMgrServiceImpl implements MemberMgrService {

	@Autowired
	private MemberMgrMapper memberMgrMapper;
	@Autowired
	private UserInfoUtil userInfoUtil;
	@Autowired
	private AssignService assignService;

	@Override
	public List<MemberMgrVO> selectMyCorpMemberList(MemberMgrVO memberMgrVO) throws Exception {
		// TODO Auto-generated method stub
		List<MemberMgrVO> list = memberMgrMapper.selectMyCorpMemberList(memberMgrVO);
		String moblphonNo = "";
		String regEx = "(\\d{3})(\\d{3,4})(\\d{4})";

		if (list != null && list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				moblphonNo = list.get(i).getMoblphonNo();

				if (moblphonNo != null && !"".equals(moblphonNo)) {
					try {
						// 휴대폰 파라미터 복호화 20220118 srec0030
						log.debug("휴대폰 복호화 전 ===============>" + moblphonNo);
						moblphonNo = CryptoUtil.decryptAES256(moblphonNo);
						log.debug("휴대폰 복호화 후 ===============>" + moblphonNo);
						list.get(i).setMoblphonNo(moblphonNo.replaceAll(regEx, "$1-$2-$3"));
					} catch (Exception e) {
						// TODO: handle exception
						log.error("selectMyCorpMemberList MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
					}
				}
			}
		}
		return list;
	}

	@Override
	public MemberMgrVO selectMemberDetailInfo(MemberMgrVO memberMgrVO) throws Exception {
		// TODO Auto-generated method stub
		MemberMgrVO vo = memberMgrMapper.selectMemberDetailInfo(memberMgrVO);
		String moblphonNo = vo.getMoblphonNo();
		String regEx = "(\\d{3})(\\d{3,4})(\\d{4})";

		if (moblphonNo != null && !"".equals(moblphonNo)) {
			try {
				// 휴대폰 파라미터 복호화 20220118 srec0030
				log.debug("휴대폰 복호화 전 ===============>" + moblphonNo);
				moblphonNo = CryptoUtil.decryptAES256(moblphonNo);
				log.debug("휴대폰 복호화 후 ===============>" + moblphonNo);
				vo.setMoblphonNo(moblphonNo.replaceAll(regEx, "$1-$2-$3"));
			} catch (Exception e) {
				// TODO: handle exception
				log.error("selectMemberDetailInfo MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}

		return vo;
	}

	@Override
	public List<MemberMgrVO> getMberSeCodeList() throws Exception {
		// TODO Auto-generated method stub
		return memberMgrMapper.getMberSeCodeList();
	}

	@Override
	public String selectMberIdDupYn(MemberMgrVO memberMgrVO) throws Exception {
		// TODO Auto-generated method stub
		return memberMgrMapper.selectMberIdDupYn(memberMgrVO);
	}

	@Override
	public int insertMberInfo(MemberMgrVO memberMgrVO) throws Exception {
		// TODO Auto-generated method stub

		if (userInfoUtil.getAccountInfo() == null) {
			return 0;
		}

		int result = 0;
		// 회원 번호 채번
		String mberNo = "P" + assignService.selectAssignValue("MB", "MBER_NO", "MBER_NO", "SYSTEM", 4);
		String userId = userInfoUtil.getAccountInfo().getId();
		memberMgrVO.setMberNo(mberNo);
		memberMgrVO.setMberSecretNo(memberMgrVO.getMberId());
		memberMgrVO.setMberConfmSttusCode("02"); // 회원요청상태코드 02:가입승인요청
		memberMgrVO.setFrstRegisterId(userId);
		memberMgrVO.setLastChangerId(userId);
		// log.debug(memberMgrVO.toString());

		String moblphonNo = memberMgrVO.getMoblphonNo();

		if (moblphonNo != null && !"".equals(moblphonNo)) {
			moblphonNo = moblphonNo.replaceAll("[^0-9]", "");
			try {
				// 휴대폰 파라미터 암호화 20220118 srec0030
				log.debug("휴대폰 암호화 전 ===============>" + moblphonNo);
				moblphonNo = CryptoUtil.encryptAES256(moblphonNo);
				log.debug("휴대폰 암호화 후 ===============>" + moblphonNo);
				memberMgrVO.setMoblphonNo(moblphonNo);
			} catch (Exception e) {
				// TODO: handle exception
				log.error("insertMberInfo MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		// 신규멤버 등록
		result = memberMgrMapper.insertMberInfo(memberMgrVO);
		// 회원기본 이력등록
		memberMgrMapper.insertmberInfoHst(memberMgrVO);
		return result;
	}

	@Override
	public int updateMberInfo(MemberMgrVO memberMgrVO) throws Exception {
		// TODO Auto-generated method stub

		if (userInfoUtil.getAccountInfo() == null) {
			return 0;
		}

		int result = 0;
		String userId = userInfoUtil.getAccountInfo().getId();

		if ("03".equals(memberMgrVO.getMberSttusCode())) {
			memberMgrVO.setMberSecretNo(memberMgrVO.getMberId());
		} else {
			memberMgrVO.setMberSecretNo("");
		}

		memberMgrVO.setFrstRegisterId(userId);
		memberMgrVO.setLastChangerId(userId);

		String moblphonNo = memberMgrVO.getMoblphonNo();

		if (moblphonNo != null && !"".equals(moblphonNo)) {
			moblphonNo = moblphonNo.replaceAll("[^0-9]", "");
			try {
				// 휴대폰 파라미터 암호화 20220118 srec0030
				log.debug("휴대폰 암호화 전 ===============>" + moblphonNo);
				moblphonNo = CryptoUtil.encryptAES256(moblphonNo);
				log.debug("휴대폰 암호화 후 ===============>" + moblphonNo);
				memberMgrVO.setMoblphonNo(moblphonNo);
			} catch (Exception e) {
				// TODO: handle exception
				log.error("updateMberInfo MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}

		result = memberMgrMapper.updateMberInfo(memberMgrVO);
		// 회원기본 이력등록
		memberMgrMapper.insertmberInfoHst(memberMgrVO);

		if (memberMgrVO.isMasterChg()) {
			// 마스터 권한 변경 시 구매총괄로 권한 업데이트
			memberMgrVO.setMberNo(userInfoUtil.getAccountInfo().getMberNo());
			memberMgrVO.setMberSeCode("02");
			result = memberMgrMapper.updateMasterMember(memberMgrVO);
			// 회원기본 이력등록
			memberMgrMapper.insertmberInfoHst(memberMgrVO);
		}

		return result;
	}

}
