package com.sorincorp.fo.my.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.mbLog.mapper.MbLogMapper;
import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.KkoMsgVO;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.cs.mapper.SvcStplatMapper;
import com.sorincorp.fo.cs.model.SvcStplatVO;
import com.sorincorp.fo.my.mapper.CorpInfoMgrMapper;
import com.sorincorp.fo.my.model.AtchVO;
import com.sorincorp.fo.my.model.CorpInfoMgrVO;
import com.sorincorp.fo.my.model.CorpKycInfoMgrVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CorpInfoMgrServiceImpl implements CorpInfoMgrService {

	@Autowired
	private CorpInfoMgrMapper corpInfoMgrMapper;
	@Autowired
	private SvcStplatMapper svcStplatMapper;
	@Autowired
	private MbLogMapper mbLogMapper;
	@Autowired
	private FileDocService fileDocService;
	@Autowired
	private UserInfoUtil userInfoUtil;
	@Autowired
	private MailService mailService;
	@Autowired
	private SMSService smsService;
	@Autowired
	MessageUtil messageUtil;
	@Autowired
	CommonService commonService;
	
	/** 이메일 발송 매퍼 */
    @Autowired
    private MailMapper mailMapper;
    
	static String SCRN_ID = "SOREC-SC-MBB-002";

	@Override
	public CorpInfoMgrVO selectCorpInfoDetail(CorpInfoMgrVO corpInfoMgrVO) throws Exception {
		// TODO Auto-generated method stub
		CorpInfoMgrVO vo = corpInfoMgrMapper.selectCorpInfoDetail(corpInfoMgrVO);

		String refndAcnutNo = vo.getRefndAcnutNo();
		String ewalletAcnutNo = vo.getEwalletAcnutNo();
		String moblphonNoEnc = vo.getMoblphonNo();
		String moblphonNoDec = "";
		String cmpnyTlphonNo = vo.getCmpnyTlphonNo();
		String cmpnyFaxNo = vo.getCmpnyFaxNo();
		// String regEx = "(\\d{3})(\\d{6})(\\d{5})";
		String regEx = "";

		if (refndAcnutNo != null && !"".equals(refndAcnutNo)) {
			// 환불계좌 암복호화 20220119 srec0030
			try {
				log.info("환불계좌 복호화 전 ==========>" + refndAcnutNo);
				refndAcnutNo = CryptoUtil.decryptAES256(refndAcnutNo).trim();
				log.info("환불계좌 복호화 후 ==========>" + refndAcnutNo);
				if (refndAcnutNo.length() == 11) {
					// xxx-xxxxx-xxx
					regEx = "(\\d{3})(\\d{5})(\\d{3})";
					vo.setRefndAcnutNo(refndAcnutNo.replaceAll(regEx, "$1-$2-$3"));
				} else if (refndAcnutNo.length() == 12) {
					// xxx-xxxxxx-xxx
					regEx = "(\\d{3})(\\d{6})(\\d{3})";
					vo.setRefndAcnutNo(refndAcnutNo.replaceAll(regEx, "$1-$2-$3"));
				} else if (refndAcnutNo.length() == 14) {
					// xxx-xxxxxx-xxxxx
					regEx = "(\\d{3})(\\d{6})(\\d{5})";
					vo.setRefndAcnutNo(refndAcnutNo.replaceAll(regEx, "$1-$2-$3"));
				} else {
					vo.setRefndAcnutNo(refndAcnutNo);
				}

			} catch (Exception e) {
				// TODO: handle exception
				log.error("selectCorpInfoDetail REFND_ACNUT_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}

		if (ewalletAcnutNo != null && !"".equals(ewalletAcnutNo)) {
			// 가상계좌 암복호화 20220119 srec0030
			try {
				log.info("가상계좌 복호화 전 ==========>" + ewalletAcnutNo);
				ewalletAcnutNo = CryptoUtil.decryptAES256(ewalletAcnutNo).trim();
				log.info("가상계좌 복호화 후 ==========>" + ewalletAcnutNo);
				if (ewalletAcnutNo.length() == 11) {
					// xxx-xxxxx-xxx
					regEx = "(\\d{3})(\\d{5})(\\d{3})";
					vo.setEwalletAcnutNo(ewalletAcnutNo.replaceAll(regEx, "$1-$2-$3"));
				} else if (refndAcnutNo.length() == 12) {
					// xxx-xxxxxx-xxx
					regEx = "(\\d{3})(\\d{6})(\\d{3})";
					vo.setEwalletAcnutNo(ewalletAcnutNo.replaceAll(regEx, "$1-$2-$3"));
				} else if (refndAcnutNo.length() == 14) {
					// xxx-xxxxxx-xxxxx
					regEx = "(\\d{3})(\\d{6})(\\d{5})";
					vo.setEwalletAcnutNo(ewalletAcnutNo.replaceAll(regEx, "$1-$2-$3"));
				} else {
					vo.setEwalletAcnutNo(ewalletAcnutNo);
				}
			} catch (Exception e) {
				// TODO: handle exception
				log.error("selectCorpInfoDetail EWALLET_ACNUT_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}

		regEx = "(\\d{3})(\\d{3,4})(\\d{4})";
		if (moblphonNoEnc != null && !"".equals(moblphonNoEnc)) {
			moblphonNoDec = CryptoUtil.decryptAES256(moblphonNoEnc);
			vo.setMoblphonNo(moblphonNoDec.replaceAll(regEx, "$1-$2-$3"));
		}

		log.info("휴대폰 복호화 =============>" + vo.getMoblphonNo());

		// 전화번호 하이픈 추가
		if ((cmpnyTlphonNo != null && !"".equals(cmpnyTlphonNo))) {
			vo.setCmpnyTlphonNo(numberformat(cmpnyTlphonNo));
		}

		// 팩스번호 하이픈 추가
		if ((cmpnyFaxNo != null && !"".equals(cmpnyFaxNo))) {
			vo.setCmpnyFaxNo(numberformat(cmpnyFaxNo));
		}

		SvcStplatVO param = new SvcStplatVO();
		// 약관 구분코드 07(증거금 약관)
		param.setStplatSeCode("07");
		List<SvcStplatVO> svcStplatList = svcStplatMapper.selectSvcStplatList(param);

		if (svcStplatList != null && svcStplatList.size() > 0) {
			vo.setStplatCnOne(svcStplatList.get(0).getStplatCnOne());
		}

		return vo;
	}

	@Override
	public int selectKycCorpInfoCount(CorpInfoMgrVO corpInfoMgrVO) throws Exception {
		int kycCount = corpInfoMgrMapper.selectKycCorpInfoCount(corpInfoMgrVO);
		return kycCount;
	}

	@Override
	public int updateCorpInfoMgr(CorpInfoMgrVO corpInfoMgrVO) throws Exception {
		// TODO Auto-generated method stub
		// log.info(corpInfoMgrVO.toString());
		int result = 0;

		CorpInfoMgrVO vo = corpInfoMgrMapper.selectCorpInfoDetail(corpInfoMgrVO);

		String refndAcnutNo = "";
		String refndAcnutSttus = vo.getRefndAcnutSttusCode();
		String moblphonNoEnc = vo.getMoblphonNo();
		String moblphonNoDec = "";
		// String regEx = "(\\d{3})(\\d{6})(\\d{5})";
		String regEx = "(\\d{3})(\\d{3,4})(\\d{4})";
		if (moblphonNoEnc != null && !"".equals(moblphonNoEnc)) {
			moblphonNoDec = CryptoUtil.decryptAES256(moblphonNoEnc);
			vo.setMoblphonNo(moblphonNoDec.replaceAll(regEx, "$1-$2-$3"));
		}

		try {
			// 업체 기본정보 수정여부
			Boolean isUpdate01 = corpInfoMgrVO.isUpdate01();
			// 업체 전화번호 수정여부 - 미사용
			Boolean isUpdate02 = corpInfoMgrVO.isUpdate02();
			// 업체 계좌정보 수정여부
			Boolean isUpdate03 = corpInfoMgrVO.isUpdate03();
			// 업체 추가결제수단 증거금 수정여부
			Boolean isUpdate04 = corpInfoMgrVO.isUpdate04();
			// 업체 추가결제수단 전자상거래보증 수정여부
			Boolean isUpdate05 = corpInfoMgrVO.isUpdate05();
			// 업체 추가결제수단 대출보증 수정여부
			Boolean isUpdate06 = corpInfoMgrVO.isUpdate06();
			// 업체 케이지크레딧 수정여부
			Boolean isUpdate07 = corpInfoMgrVO.isUpdate07();
			log.info("isUpdate01 :" + isUpdate01);
			log.info("isUpdate02 :" + isUpdate02);
			log.info("isUpdate03 :" + isUpdate03);
			log.info("isUpdate04 :" + isUpdate04);
			log.info("isUpdate05 :" + isUpdate05);
			log.info("isUpdate06 :" + isUpdate06);
			log.info("isUpdate07 :" + isUpdate07);
			int docNo1 = corpInfoMgrVO.getDocNo1();
			int docNo2 = corpInfoMgrVO.getDocNo2();
			String docSj1 = corpInfoMgrVO.getDocSj1();
			String docSj2 = corpInfoMgrVO.getDocSj2();

			// 증거금
			String wrtmTrmnatAt = corpInfoMgrVO.getWrtmTrmnatAt();
			String wrtmReqstAt = corpInfoMgrVO.getWrtmReqstAt();
			//			String wrtmUseAt = corpInfoMgrVO.getWrtmUseAt();
			String wrtmUseAt = "N";
			String wrtmStplatAgreAt = corpInfoMgrVO.getWrtmStplatAgreAt();

			// 전자상거래보증 & 케이지크래딧
			String mrtggGrntyReqstAt = corpInfoMgrVO.getMrtggGrntyReqstAt();
			String mrtggGrntyTrmnatAt = corpInfoMgrVO.getMrtggGrntyTrmnatAt();
			String mrtggGrntyUseAt = "N";
			String mrtggGrntyCntrctAt = "";
			String cdtlnSvcSeCode = corpInfoMgrVO.getCdtlnSvcSeCode();
			String requstSttusCode = "";

			//			if (corpInfoMgrVO.getCorpKycInfoMgrVO() != null) {
			//				requstSttusCode = corpInfoMgrVO.getCorpKycInfoMgrVO().getKycRequstSttusCode(); // KYC 승인상태코드 (30:승인완료)
			//			}

			//			if (!"Y".equals(mrtggGrntyReqstAt) || "Y".equals(mrtggGrntyTrmnatAt)) {
			//				// 전자상거래보증, 케이지크래딧 신청이 아니거나 사용해지 일 경우 여신서비스구분코드 공백으로 초기화
			//				cdtlnSvcSeCode = "";
			//				corpInfoMgrVO.setCdtlnSvcSeCode(cdtlnSvcSeCode);
			//			}

			//			// 케이지크레딧 신청인 경우에만
			//			if ("Y".equals(mrtggGrntyReqstAt) && "02".equals(cdtlnSvcSeCode)) {
			//				// 케이지크레딧 KYC 세팅
			//				if (requstSttusCode.equals("30")) {
			//					mrtggGrntyReqstAt = "Y";
			//				} else {
			//					mrtggGrntyReqstAt = "N";
			//					vo.setMrtggGrntyReqstAt("N");
			//				}
			//			}

			// 대출보증
			String lonGrntyReqstAt = corpInfoMgrVO.getLonGrntyReqstAt();
			String lonGrntyTrmnatAt = corpInfoMgrVO.getLonGrntyTrmnatAt();
			String lonGrntyUseAt = "N";

			// 대출보증 은행 사용여부리스트
			ArrayList<CorpInfoMgrVO> bankUseAtList = corpInfoMgrVO.getBankCodeList();

			String mberConfmSttusCode = corpInfoMgrVO.getMberConfmSttusCode();
			// log.info("mberConfmSttusCode : " + mberConfmSttusCode);
			String mberNo = userInfoUtil.getAccountInfo().getMberNo();
			String mberId = userInfoUtil.getAccountInfo().getId();
			String secessionPossibleYn = selectMemeberSecessionPossibleYn(mberNo);
			// log.info("mberNo : " + mberNo);
			// log.info("secessionPossibleYn : " + secessionPossibleYn);

			corpInfoMgrVO.setLastChangerId(mberId);

			if ("N".equals(secessionPossibleYn) || !"00".equals(secessionPossibleYn)) {
				// 탈퇴불가능(주문,배송건 있는 업체) 업체는 계좌정보를 업데이트 하지 않는다.
				isUpdate03 = false;
			}

			if (!isUpdate01) {
				corpInfoMgrVO.setEntrprsBizcndCode("");
				corpInfoMgrVO.setEntrprsItemCode("");
				corpInfoMgrVO.setRprsntvNm("");
				corpInfoMgrVO.setPostNo("");
				corpInfoMgrVO.setRnAdres("");
				corpInfoMgrVO.setRnDetailAdres("");
				corpInfoMgrVO.setAdres("");
				corpInfoMgrVO.setDetailAdres("");
				corpInfoMgrVO.setPurchschargerEmail("");
			}

			if(!isUpdate02) {
				corpInfoMgrVO.setCmpnyTlphonNo("");
				corpInfoMgrVO.setCmpnyFaxNo("");
			}

			if (isUpdate03) {
				// 환불계좌 변경 시 정합성 여부 N으로 수정(환불계좌, 환불계좌주명, 가상계좌번호 NULL로 업데이트)
				corpInfoMgrVO.setRefndAcnutRgrsynthAt("N");
				if (refndAcnutSttus == null || "".equals(refndAcnutSttus) || "05".equals(refndAcnutSttus)) {

					// 계좌등록/변경 시 환불계좌상태 "01"로 설정
					corpInfoMgrVO.setRefndAcnutSttusCode("01");
				} else {
					// 페이지 오류
					// (상태값 01, 02, 03, 04)의 경우 오류 표출
					return -1;
				}

				// 누락으로 인해 다시 추가 20220425 srec0030
				refndAcnutNo = corpInfoMgrVO.getRefndAcnutNo().trim().replace("-", "");
				log.info("refndAcnutNo =======================>" + refndAcnutNo);

				if (refndAcnutNo != null && !"".equals(refndAcnutNo)) {
					refndAcnutNo = refndAcnutNo.trim();
					// 환불계좌 암복호화 20220119 srec0030
					try {
						log.info("환불계좌 암호화 전 ============>" + refndAcnutNo);
						refndAcnutNo = CryptoUtil.encryptAES256(refndAcnutNo);
						log.info("환불계좌 암호화 후 ============>" + refndAcnutNo);
						corpInfoMgrVO.setRefndAcnutNo(refndAcnutNo);
						corpInfoMgrVO.setAcnutUnregistEmailSndngAt("Y");
					} catch (Exception e) {
						// TODO: handle exception
						log.error("updateCorpInfoMgr REFND_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
					}
				}

			} else {

				corpInfoMgrVO.setRefndAcnutNm("");
				corpInfoMgrVO.setRefndAcnutNo("");
				corpInfoMgrVO.setRefndAcnutRgrsynthAt("");

				if (isUpdate04) {

					if ("Y".equals(wrtmTrmnatAt)) {
						// 해지 신청시 사용신청 N, 사용여부 N
						wrtmReqstAt = "N";
						wrtmUseAt = "N";

						// 증거금 이용약관 동의여부
						wrtmStplatAgreAt = "N";
					} else if ("Y".equals(wrtmReqstAt)) {
						// 사용신청시 사용여부 W, 해지여부 N
						wrtmUseAt = "W";
						wrtmTrmnatAt = "N";
						// 증거금 이용약관 동의여부
						wrtmStplatAgreAt = "Y";
					} else if ("N".equals(wrtmReqstAt)) {
						// 사용 미신청시 사용여부 N, 해지여부 N
						wrtmUseAt = "N";
						wrtmTrmnatAt = "N";
					}

					corpInfoMgrVO.setWrtmTrmnatAt(wrtmTrmnatAt);
					corpInfoMgrVO.setWrtmReqstAt(wrtmReqstAt);
					corpInfoMgrVO.setWrtmUseAt(wrtmUseAt);
					corpInfoMgrVO.setWrtmStplatAgreAt(wrtmStplatAgreAt);
					corpInfoMgrVO.setWrtmConfmAt("N");
				}

				// 전자상거래보증 또는 케이지크래딧
				if (isUpdate05 || isUpdate07) {

					if (!"Y".equals(mrtggGrntyReqstAt) || "Y".equals(mrtggGrntyTrmnatAt)) {
						// 전자상거래보증, 케이지크래딧 신청이 아니거나 사용해지 일 경우 여신서비스구분코드 공백으로 초기화
						cdtlnSvcSeCode = "";
						corpInfoMgrVO.setCdtlnSvcSeCode(cdtlnSvcSeCode);
					}

					// 전자상거래보증
					if (isUpdate05) {
						// 전자상거래보증에 kycVO에 세팅이 필요한지 확인필요
						corpInfoMgrVO.getCorpKycInfoMgrVO().setFrstRegisterId(mberId);
						corpInfoMgrVO.getCorpKycInfoMgrVO().setLastChangerId(mberId);

						if ("Y".equals(mrtggGrntyTrmnatAt)) {
							// 해지 신청시 사용신청 N, 사용여부 N
							mrtggGrntyReqstAt = "N";
							mrtggGrntyUseAt = "N";
							mrtggGrntyCntrctAt = "";

						} else if ("Y".equals(mrtggGrntyReqstAt)) {
							// 사용신청시 사용여부 W, 해지여부 N
							mrtggGrntyUseAt = "W";
							mrtggGrntyTrmnatAt = "N";
							// 계약여부
							mrtggGrntyCntrctAt = corpInfoMgrVO.getMrtggGrntyCntrctAt();

							if ("01".equals(cdtlnSvcSeCode)) {
								corpInfoMgrVO.setSorinHopeLmtAmount(0);
							} else if ("02".equals(cdtlnSvcSeCode)) {
								corpInfoMgrVO.setMrtggGrntyIrncf(0);
							} else if ("02".equals(cdtlnSvcSeCode) && "N".equals(corpInfoMgrVO.getMrtggGrntyUseAt())) {
								// 필요한 조건인지 확인필요
							}
						} else if ("N".equals(mrtggGrntyReqstAt)) {
							// 사용 미신청시 사용여부 N, 해지여부 N
							mrtggGrntyUseAt = "N";
							mrtggGrntyTrmnatAt = "N";
							mrtggGrntyCntrctAt = "";
						}

						if ("02".equals(cdtlnSvcSeCode)) {
							// 케이지 크레딧일 경우 계약여부 N
							mrtggGrntyCntrctAt = "N";
						}

						corpInfoMgrVO.setMrtggGrntyTrmnatAt(mrtggGrntyTrmnatAt);
						corpInfoMgrVO.setMrtggGrntyReqstAt(mrtggGrntyReqstAt);
						corpInfoMgrVO.setMrtggGrntyUseAt(mrtggGrntyUseAt);
						corpInfoMgrVO.setMrtggGrntyCntrctAt(mrtggGrntyCntrctAt);
						corpInfoMgrVO.setMrtggGrntyConfmAt("N");

						// 케이지 크레딧
					} else if (isUpdate07) {

						// KYC 상태코드
						if (corpInfoMgrVO.getCorpKycInfoMgrVO() != null) {
							requstSttusCode = corpInfoMgrVO.getCorpKycInfoMgrVO().getKycRequstSttusCode(); // KYC승인상태코드(30 : 승인완료)
						}

						// 케이지크레딧 신청인 경우에만
						if ("Y".equals(mrtggGrntyReqstAt) && "02".equals(cdtlnSvcSeCode)) {
							if ("30".equals(requstSttusCode)) {
								// 케이지크레딧 KYC 상태코드가 30(승인완료)인 경우만 사용신청 Y로 세팅
								mrtggGrntyReqstAt = "Y";
							} else {
								mrtggGrntyReqstAt = "N";
								vo.setMrtggGrntyReqstAt("N");
							}
						}

						corpInfoMgrVO.getCorpKycInfoMgrVO().setFrstRegisterId(mberId);
						corpInfoMgrVO.getCorpKycInfoMgrVO().setLastChangerId(mberId);
						corpInfoMgrVO.getCorpKycInfoMgrVO().setBankCode("0810000"); // 하나은행

						// 계좌번호 암호화
						refndAcnutNo = corpInfoMgrVO.getCorpKycInfoMgrVO().getAcnutNo().trim().replace("-", "");
						log.info("refndAcnutNo =======================>" + refndAcnutNo);

						if (refndAcnutNo != null && !"".equals(refndAcnutNo)) {
							corpInfoMgrVO.getCorpKycInfoMgrVO().setAcnutNo(CryptoUtil.encryptAES256(refndAcnutNo));
						}

						// kyc 희망한도금액 및 기존 회원정보 업데이트
						corpInfoMgrMapper.insertEntrpsKycInfo(corpInfoMgrVO.getCorpKycInfoMgrVO());
						commonService.insertTableHistory("MB_ENTRPS_KYC_INFO_BAS", corpInfoMgrVO);
					}
				}

				// 구매자금
				if (isUpdate06) {

					if ("Y".equals(lonGrntyTrmnatAt)) {
						// 해지 신청시 사용신청 N, 사용여부 N
						lonGrntyReqstAt = "N";
						lonGrntyUseAt = "N";
						// 해지 신청 시 업체 대출보증 은행 테이블 일괄 삭제
						corpInfoMgrMapper.deleteMbEntrpsLonGrntyBankInfoBas(corpInfoMgrVO);
						corpInfoMgrMapper.insertMbEntrpsLonGrntyBankInfoBasHst(corpInfoMgrVO);

					} else if ("Y".equals(lonGrntyReqstAt)) {
						// 사용신청시 사용여부 W, 해지여부 N
						lonGrntyUseAt = "W";
						lonGrntyTrmnatAt = "N";

						if (bankUseAtList != null) {
							if (bankUseAtList.size() > 0) {
								// 사용 신청 시 업체 대출보증 은행 테이블 일괄 삭제
								corpInfoMgrMapper.deleteMbEntrpsLonGrntyBankInfoBas(corpInfoMgrVO);
								corpInfoMgrMapper.insertMbEntrpsLonGrntyBankInfoBasHst(corpInfoMgrVO);

								for (CorpInfoMgrVO bankUseVO : bankUseAtList) {
									bankUseVO.setEntrpsNo(corpInfoMgrVO.getEntrpsNo());
									bankUseVO.setFrstRegisterId(mberId);
									bankUseVO.setLastChangerId(mberId);

									// bankCnt = corpInfoMgrMapper.selectMbEntrpsLonGrntyBankInfoBasCnt(bankUseVO);
									corpInfoMgrMapper.insertMbEntrpsLonGrntyBankInfoBas(bankUseVO);
									corpInfoMgrMapper.insertMbEntrpsLonGrntyBankInfoBasHst(bankUseVO);
								}
							}
						}

					} else if ("N".equals(lonGrntyReqstAt)) {
						// 사용 미신청시 사용여부 N, 해지여부 N
						lonGrntyUseAt = "N";
						lonGrntyTrmnatAt = "N";
					}

					corpInfoMgrVO.setLonGrntyTrmnatAt(lonGrntyTrmnatAt);
					corpInfoMgrVO.setLonGrntyReqstAt(lonGrntyReqstAt);
					corpInfoMgrVO.setLonGrntyUseAt(lonGrntyUseAt);
					corpInfoMgrVO.setLonGrntyConfmAt("N");
				}
			}

			if (isUpdate03) {
				// 가입승인요청 - 환불계좌 등록(초기등록)
				if(mberConfmSttusCode.equals("02")) {
					corpInfoMgrVO.setChangeConfmDetailCode("13");
					corpInfoMgrVO.setChangeRequstResn("환불계좌 등록");
				}
				else {
					// 변경 승인 상세 코드 01(환불계좌) 
					corpInfoMgrVO.setChangeConfmDetailCode("01");
					corpInfoMgrVO.setChangeRequstResn("환불계좌 변경");
				}
			} else { // 증거금, 전자상거래, 구매자금 변경승인 요청 상세코드 설정
				//				log.info("isUpdate05 : " + isUpdate05);
				//				log.info("isUpdate06 : " + isUpdate06);
				//				log.info("mrtggGrntyReqstAt : " + vo.getMrtggGrntyReqstAt());
				//				log.info("mrtggGrntyConfmAt : " + vo.getMrtggGrntyConfmAt());
				//				log.info("lonGrntyReqstAt : " + vo.getLonGrntyReqstAt());
				//				log.info("lonGrntyConfmAt : " + vo.getLonGrntyConfmAt());

				List<String> changeRequstResnList = new ArrayList<String>(); // 변경승인 요청 사유 리스트
				List<String> changeConfmDetailCodeList = new ArrayList<String>(); // 변경승인 요청 상세코드 리스트

				if ("Y".equals(wrtmReqstAt) || "Y".equals(vo.getWrtmReqstAt())) { // 증거금 사용요청이 있고
					if (!"Y".equals(vo.getWrtmConfmAt())
							|| (("Y".equals(vo.getWrtmConfmAt()) && "N".equals(vo.getWrtmUseAt()))
									&& "Y".equals(wrtmReqstAt))) { // 미승인 상태 이거나 반려 상태일 경우
						changeRequstResnList.add("증거금");
						changeConfmDetailCodeList.add("05"); // 증거금 사용요청
					}
				}
				if ("Y".equals(mrtggGrntyReqstAt) || "Y".equals(vo.getMrtggGrntyReqstAt())) { // 전자상거래보증 사용요청이 있고
					if (!"Y".equals(vo.getMrtggGrntyConfmAt())
							|| (("Y".equals(vo.getMrtggGrntyConfmAt()) && "N".equals(vo.getMrtggGrntyUseAt()))
									&& "Y".equals(mrtggGrntyReqstAt))) { // 미승인 상태 이거나 반려
						// log.debug("cdtlnSvcSeCode =============>>>> " + cdtlnSvcSeCode);

						if ("01".equals(cdtlnSvcSeCode)) {
							changeRequstResnList.add("전자상거래보증");
							changeConfmDetailCodeList.add("02"); // 전자상거래보증 사용요청
						} else if ("02".equals(cdtlnSvcSeCode)) {
							changeRequstResnList.add("케이지 크레딧");
							changeConfmDetailCodeList.add("09"); // 케이지크레딧 사용요청
						} else if ("Y".equals(vo.getMrtggGrntyReqstAt())) {
							// 여신서비스구분코드(화면)가 없고 사용신청여부(db)가 Y일때 여신서비스구분코드(db) 값으로 구분
							if ("01".equals(vo.getCdtlnSvcSeCode())) {
								changeRequstResnList.add("전자상거래보증");
								changeConfmDetailCodeList.add("02"); // 전자상거래보증 사용요청
							} else if ("02".equals(vo.getCdtlnSvcSeCode())) {
								changeRequstResnList.add("케이지 크레딧");
								changeConfmDetailCodeList.add("09"); // 케이지크레딧 사용요청
							}
						}
					}
				}

				if ("Y".equals(lonGrntyReqstAt) || "Y".equals(vo.getLonGrntyReqstAt())) { // 구매자금 사용요청이 있고
					if ("Y".equals(lonGrntyReqstAt) || !"Y".equals(vo.getLonGrntyConfmAt())
							|| (("Y".equals(vo.getLonGrntyConfmAt()) && "N".equals(vo.getLonGrntyUseAt()))
									&& "Y".equals(lonGrntyReqstAt))) { // 미승인 상태 이거나 반려 상태일 경우
						changeRequstResnList.add("구매자금");
						changeConfmDetailCodeList.add("03"); // 구매자금 사용요청
					}
				}

				log.info("추가결제수단 사용요청 건수 :: " + changeRequstResnList.size());

				if (changeRequstResnList.size() > 0) {
					String changeRequstResn = String.join("/", changeRequstResnList).concat(" 사용신청"); // 변경승인 요청 사유 문구
																										// 생성
					log.info("변경승인 요청 사유 :: " + changeRequstResn);
					corpInfoMgrVO.setChangeRequstResn(changeRequstResn); // 변경승인 요청 사유 파라미터 설정
				}

				if (changeConfmDetailCodeList.size() > 0) {
					String changeConfmDetailCode = String.join("", changeConfmDetailCodeList); // 변경승인 요청 상세코드
					if (changeConfmDetailCodeList.size() > 1) {

						if ("".equals(cdtlnSvcSeCode) && "Y".equals(vo.getMrtggGrntyReqstAt())) {
							cdtlnSvcSeCode = vo.getCdtlnSvcSeCode();
						}

						// 요청이 다건인 경우 '변경 승인 상세 코드 - CHANGE_CONFM_DETAIL_CODE' 공통코드로 치환
						if ("01".equals(cdtlnSvcSeCode)) {
							if (!changeConfmDetailCodeList.contains("05") && changeConfmDetailCodeList.contains("03")
									&& changeConfmDetailCodeList.contains("02")) {
								changeConfmDetailCode = "04"; // 전자상거래보증, 구매자금 사용요청
							} else if (changeConfmDetailCodeList.contains("05")
									&& !changeConfmDetailCodeList.contains("03")
									&& changeConfmDetailCodeList.contains("02")) {
								changeConfmDetailCode = "06"; // 증거금, 전자상거래보증 사용요청
							} else if (changeConfmDetailCodeList.contains("05")
									&& changeConfmDetailCodeList.contains("03")
									&& !changeConfmDetailCodeList.contains("02")) {
								changeConfmDetailCode = "07"; // 증거금, 구매자금 사용요청
							} else if (changeConfmDetailCodeList.contains("05")
									&& changeConfmDetailCodeList.contains("03")
									&& changeConfmDetailCodeList.contains("02")) {
								changeConfmDetailCode = "08"; // 증거금, 전자상거래보증, 구매자금 사용요청
							}
						} else {
							if (!changeConfmDetailCodeList.contains("05") && changeConfmDetailCodeList.contains("03")
									&& changeConfmDetailCodeList.contains("09")) {
								changeConfmDetailCode = "10"; // 케이지크래딧, 구매자금 사용요청
							} else if (changeConfmDetailCodeList.contains("05")
									&& !changeConfmDetailCodeList.contains("03")
									&& changeConfmDetailCodeList.contains("09")) {
								changeConfmDetailCode = "11"; // 증거금, 케이지크래딧 사용요청
							} else if (changeConfmDetailCodeList.contains("05")
									&& changeConfmDetailCodeList.contains("03")
									&& !changeConfmDetailCodeList.contains("09")) {
								changeConfmDetailCode = "07"; // 증거금, 구매자금 사용요청
							} else if (changeConfmDetailCodeList.contains("05")
									&& changeConfmDetailCodeList.contains("03")
									&& changeConfmDetailCodeList.contains("09")) {
								changeConfmDetailCode = "12"; // 증거금, 케이지크래딧, 구매자금 사용요청
							}
						}
					}
					log.info("변경승인 요청 상세코드 :: " + changeConfmDetailCode);
					corpInfoMgrVO.setChangeConfmDetailCode(changeConfmDetailCode); // 변경승인 요청 상세코드 파라미터 설정
				}
			}
			// 업체정보기본 수정
			result = corpInfoMgrMapper.updateMbEntrpsInfoBas(corpInfoMgrVO);
			// 업체정보기본이력
			//			corpInfoMgrMapper.insertMbEntrpsInfoBasHst(corpInfoMgrVO);
			mbLogMapper.insertMbEntrpsInfoBasHst(corpInfoMgrVO.getEntrpsNo());

			if (!"".equals(corpInfoMgrVO.getGrntyNo()) && !"".equals(corpInfoMgrVO.getGrntyReqstNo())) {
				// 케이지크레딧 해지 시 주문업체여신상세 삭제
				corpInfoMgrMapper.deleteOrCdtlnEntrpsDtl(corpInfoMgrVO);
				corpInfoMgrMapper.insertOrCdtlnEntrpsDtlHst(corpInfoMgrVO);
			}

			if (isUpdate03) {

				switch (mberConfmSttusCode) {
				case "01":
					mberConfmSttusCode = "06"; // 가입승인정상 -> 변경승인요청
					break;
				case "02":
					mberConfmSttusCode = "02"; // 가입승인요청 -> 가입승인요청
					break;
				case "03":
					mberConfmSttusCode = "02"; // 가입승인보류 -> 가입승인요청
					break;
				case "04":
					mberConfmSttusCode = "02"; // 가입승인거절 -> 가입승인요청
					break;
				case "05":
					mberConfmSttusCode = "06"; // 변경승인정상 -> 변경승요청
					break;
				case "06":
					mberConfmSttusCode = "06"; // 변경승인요청 -> 변경승요청
					break;
				case "07":
					mberConfmSttusCode = "06"; // 변경승인보류 -> 변경승요청
					break;
				case "08":
					mberConfmSttusCode = "06"; // 변경승인거절 -> 변경승요청
					break;
				default:
					mberConfmSttusCode = "06";
					break;
				}

				corpInfoMgrVO.setMberConfmSttusCode(mberConfmSttusCode);

				// 업체 회원들 모두 임시회원(03)으로 변경
				corpInfoMgrVO.setMberSttusCode("03");
				// 증거금 이용약관 동의여부
				corpInfoMgrVO.setWrtmStplatAgreAt("");

				// 환불계좌 변경 첨부파일
				if (isUpdate03 && docNo2 > 0) {
					corpInfoMgrVO.setDocNo(docNo2);
					corpInfoMgrVO.setDocSj(docSj2);
					corpInfoMgrVO.setScrinId(SCRN_ID);
					corpInfoMgrVO.setJobSeCode("MB");
					result = corpInfoMgrMapper.insertMbEntrpsAtchFileRls(corpInfoMgrVO);
					corpInfoMgrMapper.insertMbEntrpsAtchFileRelateHst(corpInfoMgrVO);
				}
			} else if (isUpdate04 || isUpdate05 || isUpdate06) {

				// 사용신청일 경우만 변경승인 요청 상태로 업데이트
				if ("Y".equals(wrtmReqstAt) || "Y".equals(mrtggGrntyReqstAt) || "Y".equals(lonGrntyReqstAt)) {
					// 전자상거래보증, 대출보증 신청시 승인상태코드 승인요청
					corpInfoMgrVO.setMberConfmSttusCode("06");
					corpInfoMgrVO.setMberSttusCode("");
				}

			} else if (docNo2 > 0) {
				// 환불계좌번호 변경없고 첨부파일만 추가된경우
				corpInfoMgrVO.setDocNo(docNo2);
				corpInfoMgrVO.setDocSj(docSj2);
				corpInfoMgrVO.setScrinId(SCRN_ID);
				corpInfoMgrVO.setJobSeCode("MB");
				result = corpInfoMgrMapper.insertMbEntrpsAtchFileRls(corpInfoMgrVO);
				corpInfoMgrMapper.insertMbEntrpsAtchFileRelateHst(corpInfoMgrVO);
			}

			// 회원정보기본 승인상태 및 요청사유 요청일시 update
			result = corpInfoMgrMapper.updateMbMberInfoBas(corpInfoMgrVO);
			// 회원정보기본 이력
			corpInfoMgrMapper.insertMbMberInfoBasHst(corpInfoMgrVO);
			// 변경사업자등록증 첨부파일
			if (isUpdate01 && docNo1 > 0) {
				corpInfoMgrVO.setDocNo(docNo1);
				corpInfoMgrVO.setDocSj(docSj1);
				corpInfoMgrVO.setScrinId(SCRN_ID);
				corpInfoMgrVO.setJobSeCode("MB");
				result = corpInfoMgrMapper.insertMbEntrpsAtchFileRls(corpInfoMgrVO);
				corpInfoMgrMapper.insertMbEntrpsAtchFileRelateHst(corpInfoMgrVO);
			}

			if ((isUpdate05 && "Y".equals(mrtggGrntyReqstAt)) || (isUpdate06 && "Y".equals(lonGrntyReqstAt))
					|| isUpdate07) {
				// 비투비모아 메일발송
				MailVO mail = new MailVO();
				Map<String, String> emailMap = new HashedMap<>();
				Map<String, String> kkoMap = new HashedMap<>();
				KkoMsgVO kkoVO = new KkoMsgVO();
				MailVO selectMailTmpt = mailMapper.selectMailTmpt(62);   // 발신자 이메일 가져오기
				mail.setMailTmptSeq(62);
				mail.setEmail("skc@b2bmore.com");
				mail.setName("비투비모아");
				mail.setMailSendUserId("b2bmoa");
				mail.setMailSendEmail(selectMailTmpt.getSntoEmail());

				if (isUpdate05 && "Y".equals(mrtggGrntyReqstAt) && "01".equals(cdtlnSvcSeCode)) {
					// 전자상거래보증 사용신청
					// 공통정보 세팅
					emailMap.put("reqGubun", "전자상거래보증");
					emailMap.put("templateNum", Integer.toString(mail.getMailTmptSeq()));
					emailMap.put("entrpsnmKorean", vo.getEntrpsnmKorean());
					emailMap.put("bsnmRegistNo", vo.getBsnmRegistNo());
					emailMap.put("cprRegistNo", vo.getCprRegistNo());
					emailMap.put("rprsntvNm", vo.getRprsntvNm());
					emailMap.put("cmpnyTlphonNo", vo.getCmpnyTlphonNo());
					emailMap.put("moblphonNo", vo.getMoblphonNo());
					emailMap.put("adres", vo.getAdres() + " " + vo.getDetailAdres());
					emailMap.put("rnadres", vo.getRnAdres() + " " + vo.getRnDetailAdres());
					emailMap.put("mberEtrDt", vo.getMberEtrDt());
					// emailMap.put("servicedomain", "https://www.metalsorin.com");
					// 이메일 발송
					mailService.insertMailSend(mail, emailMap);
				}

				if (isUpdate06 && "Y".equals(lonGrntyReqstAt)) {
					// 구매자금 사용신청
					// 공통정보 세팅
					emailMap.put("reqGubun", "구매자금");
					emailMap.put("templateNum", Integer.toString(mail.getMailTmptSeq()));
					emailMap.put("entrpsnmKorean", vo.getEntrpsnmKorean());
					emailMap.put("bsnmRegistNo", vo.getBsnmRegistNo());
					emailMap.put("cprRegistNo", vo.getCprRegistNo());
					emailMap.put("rprsntvNm", vo.getRprsntvNm());
					emailMap.put("cmpnyTlphonNo", vo.getCmpnyTlphonNo());
					emailMap.put("moblphonNo", vo.getMoblphonNo());
					emailMap.put("adres", vo.getAdres() + " " + vo.getDetailAdres());
					emailMap.put("rnadres", vo.getRnAdres() + " " + vo.getRnDetailAdres());
					emailMap.put("mberEtrDt", vo.getMberEtrDt());
					// emailMap.put("servicedomain", "https://www.metalsorin.com");
					// 이메일 발송
					mailService.insertMailSend(mail, emailMap);
				}

				if (isUpdate07 && "10".equals(requstSttusCode)) {
					// 케이지크레딧 사용 신청 시 알림톡 발송

					// corpKycInfoMgrVO.setRprsntvTelno(CryptoUtil.encryptAES256(corpKycInfoMgrVO.getRprsntvTelno()));
					// corpKycInfoMgrVO.setJobChargerTel(CryptoUtil.encryptAES256(corpKycInfoMgrVO.getJobChargerTel()));
					//        				    kkoVO.setPhone(corpInfoMgrVO.getCorpKycInfoMgrVO().getJobChargerTel());		//업무 담당자
					//        				    kkoMap.put("templateNum", "99");
					//        				    kkoMap.put("moblPhonNo", userInfoUtil.getAccountInfo().getId());
					//        				    kkoMap.put("SERVICEDOMAIN", "www.metalsorin.com");
					//
					//        				    smsService.insertKkoMsg(kkoVO, kkoMap);

					if (moblphonNoEnc != null && !"".equals(moblphonNoEnc)) {
						moblphonNoDec = CryptoUtil.decryptAES256(moblphonNoEnc);
					}

					SMSVO smsVO = new SMSVO();
					smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
					smsVO.setPhone(moblphonNoDec);
					smsVO.setMberNo(vo.getMberNo());

					Map<String, String> smsMap = new HashMap<>();
					smsMap.put("templateNum", "99");
					//템플릿 {{entrpsnmKorean}} : 기업명
					smsMap.put("entrpsnmKorean", vo.getEntrpsnmKorean());

					smsService.insertSMS(smsVO, smsMap);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			return -1;
		}

		return result;
	}

	@Override
	public Map<String, Object> uploadAttachFile(MultipartHttpServletRequest mRequest) throws Exception {
		// TODO Auto-generated method st\

		Map<String, Object> map = new HashMap<String, Object>();
		List<FileDocVO> list = fileDocService.uploadAttachFilesVoList("MB", mRequest);// 파일 저장

		HashMap<String, Object> fileMap = new HashMap<>();

		if (list != null && !list.isEmpty()) {
			fileMap.put("result", "S");
			fileMap.put("list", list);
		} else {
			fileMap.put("result", "F");
		}

		map.put("result", list);
		return fileMap;
	}

	@Override
	public String selectMemeberSecessionPossibleYn(String mberNo) throws Exception {
		// TODO Auto-generated method stub
		return corpInfoMgrMapper.selectMemeberSecessionPossibleYn(mberNo);
	}

	@Override
	public int checkPassWord(CorpInfoMgrVO corpInfoMgrVO) throws Exception {
		// TODO Auto-generated method stub
		String mberSecretNoDec = corpInfoMgrVO.getMberSecretNo();
		String mberSecretNoEnc = "";

		if (mberSecretNoDec != null && !"".equals(mberSecretNoDec)) {
			mberSecretNoEnc = CryptoUtil.encryptSHA256(mberSecretNoDec);
		}

		// 패스워드 암호화
		corpInfoMgrVO.setMberSecretNo(mberSecretNoEnc);
		return corpInfoMgrMapper.checkPassWord(corpInfoMgrVO);
	}

	@Override
	public List<CorpInfoMgrVO> selectLonGrntyBankUseAtList(String entrpsNo) throws Exception {
		// TODO Auto-generated method stub
		return corpInfoMgrMapper.selectLonGrntyBankUseAtList(entrpsNo);
	}

	@Override
	public String selectTrmnatPossibleAt(CorpInfoMgrVO corpInfoMgrVO) throws Exception {
		// TODO Auto-generated method stub
		String result = corpInfoMgrMapper.selectTrmnatPossibleAt(corpInfoMgrVO);
		//		int cnt = 0;
		//
		//		if ("02".equals(corpInfoMgrVO.getCdtlnSvcSeCode())) {
		//			cnt = corpInfoMgrMapper.selectTrmnatSttusCnt(corpInfoMgrVO);
		//
		//			if (cnt < 1) {
		//				result = "N2";
		//			}
		//		}

		return result;
	}

	@Override
	public CorpKycInfoMgrVO selectKycCorpInfo(CorpKycInfoMgrVO corpKycInfoMgrVO) throws Exception {
		CorpKycInfoMgrVO vo = new CorpKycInfoMgrVO();
		vo = corpInfoMgrMapper.selectKycCorpInfo(corpKycInfoMgrVO);

		String moblphonNoEnc = vo.getCptalCharherTel();
		String rprsntvTelnoEnc = vo.getRprsntvTelno();

		if (moblphonNoEnc != null && !"".equals(moblphonNoEnc)) {
			moblphonNoEnc = CryptoUtil.decryptAES256(moblphonNoEnc);
			vo.setCptalCharherTel(numberformat(moblphonNoEnc));
		}

		if (rprsntvTelnoEnc != null && !"".equals(rprsntvTelnoEnc)) {
			rprsntvTelnoEnc = CryptoUtil.decryptAES256(rprsntvTelnoEnc);
			vo.setRprsntvTelno(rprsntvTelnoEnc);
		}
		return vo;
	}

	// 첨부파일 업로드
	@SuppressWarnings("finally")
	@Override
	public HashMap<String, String> saveAttachFile(MultipartHttpServletRequest mRequest) {
		List<FileDocVO> fileKeys = null;
		FileDocVO fileDocVO = new FileDocVO();
		HashMap<String, String> fileMap = new HashMap<>();

		String errMsg = "";

		try {
			fileKeys = fileDocService.uploadAttachFilesVoList("mb", "kyc", mRequest);
			fileDocVO = fileKeys.get(0);
			fileMap.put("docNo", Integer.toString(fileDocVO.getDocNo()));
			fileMap.put("fileName", fileDocVO.getDocFileNm());
			fileMap.put("filePath", fileDocVO.getDocFileRealCours());
			fileMap.put("result", "S");

		} catch (Exception e) {
			log.error(e.toString());
			errMsg = messageUtil.getMessage(e.getMessage());
			fileMap.put("result", "F");
		} finally {
			fileMap.put("errMsg", errMsg);
			return fileMap;
		}
	}

	@Override
	public Map<String, Object> deleteFileDoc(FileDocVO fileVO) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();

		// 공통_문서 기본 - 문서 사용 여부 'N'으로 수정
		fileDocService.deleteCommonDoc(fileVO.getDocNo());
		map.put("docNo", fileVO.getDocNo());
		map.put("result", "success");

		return map;
	}

	// 하이픈 추가 함수
	public String numberformat(String str) throws Exception {
		str = str.trim();
		if (str.length() == 11) {
			str = str.replaceAll("(\\d{3})(\\d{4})(\\d{4})", "$1-$2-$3");
		} else if (str.length() == 8) {
			str = str.replaceAll("(\\d{4})(\\d{4})", "$1-$2");
		} else {
			if (str.indexOf("02") == 0) {
				str = str.replaceAll("(\\d{2})(\\d{3})(\\d{4})", "$1-$2-$3");
			} else {
				str = str.replaceAll("(\\d{3})(\\d{3})(\\d{4})", "$1-$2-$3");
			}
		}
		return str;
	}

	@Override
	public boolean updateCorpKycInfoDetail(CorpKycInfoMgrVO corpKycInfoMgrVO) throws Exception {
		boolean result = false;
		try {
			for (AtchVO vo : corpKycInfoMgrVO.getAtchArray()) {
				vo.setEntrpsNo(corpKycInfoMgrVO.getEntrpsNo());
				vo.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
				vo.setLastChangerId(userInfoUtil.getAccountInfo().getId());
				corpInfoMgrMapper.insertKycAtchFileRls(vo);
			}

			corpKycInfoMgrVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
			corpInfoMgrMapper.updateCorpKycInfoDetail(corpKycInfoMgrVO);
			commonService.insertTableHistory("MB_ENTRPS_KYC_INFO_BAS", corpKycInfoMgrVO);

		} catch (Exception e) {
			log.error(e.toString());
			result = false;
		}
		return result;
	}
}
