/**
 *
 */
package com.sorincorp.fo.my.service;

import java.security.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.my.mapper.EwalletMngMapper;
import com.sorincorp.fo.my.model.EwalletMngVO;

import lombok.extern.slf4j.Slf4j;

/**
 * EwalletMngServiceImpl.java
 * @version
 * @since 2021. 9. 24.
 * @author srec0009
 */
@Slf4j
@Service
public class EwalletMngServiceImpl implements EwalletMngService{

	@Autowired
	private EwalletMngMapper ewalletMngMapper;

	@Override
	public List<EwalletMngVO> selectRefndRequstDtls(EwalletMngVO ewalletMngVO) {
		return ewalletMngMapper.selectRefndRequstDtls(ewalletMngVO);
	}

	@Override
	public List<EwalletMngVO> selectEwalletMng(EwalletMngVO ewalletMngVO) {
		List<EwalletMngVO> result =  ewalletMngMapper.selectEwalletMng(ewalletMngVO);
//		for(int i = 0; i < result.size(); i++) {
//			if("04".equals( result.get(i).getEwalletDelngSeCode()) && result.get(i).getEwalletExcclcTyCode() != null) {
//				result.get(i).setEwalletDelngSeCodeNm(result.get(i).getEwalletExcclcTyCodeNm());
//			}
//		}
		return result;
	}
	
	@Override
	public List<EwalletMngVO> selectExcelEwalletMng(EwalletMngVO ewalletMngVO) {
		List<EwalletMngVO> result =  ewalletMngMapper.selectExcelEwalletMng(ewalletMngVO);
		return result;
	}



}
