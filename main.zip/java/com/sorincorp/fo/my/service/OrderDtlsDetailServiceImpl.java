package com.sorincorp.fo.my.service;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.my.mapper.OrderDtlsDetailMapper;
import com.sorincorp.fo.my.model.DlivyVO;
import com.sorincorp.fo.my.model.DlvyVO;
import com.sorincorp.fo.my.model.OrMrtggMdstrmRepyVO;
import com.sorincorp.fo.my.model.OrPcChangegldBasVO;
import com.sorincorp.fo.my.model.OrSetleDtlsInfoVO;
import com.sorincorp.fo.my.model.OrSetleInfoVO;
import com.sorincorp.fo.my.model.OrderCouponDdctVO;
import com.sorincorp.fo.my.model.OrderDtlsVO;
import com.sorincorp.fo.my.model.VhcleInfoVO;
import com.sorincorp.fo.pd.comm.constant.PdPropertyConstant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OrderDtlsDetailServiceImpl implements OrderDtlsDetailService {

	@Autowired
	private OrderDtlsDetailMapper orderDtlsDetailMapper;

	/** 외부 연계 api 호출 모듈 **/
	@Autowired
	private HttpClientHelper httpClientHelper;

	/** 프로퍼티 상수 모음 **/
	@Autowired
	private PdPropertyConstant orProperty;

	/** SMS 발송 서비스 **/
	@Autowired
	private SMSService smsService;

	/** 공통  **/
	@Autowired
	private CommonService commonService;


	/**
	 * 주문상세내역을 조회한다.
	 */
	@Override
	public OrderDtlsVO selectOrderDtlsDetail(OrderDtlsVO seachVo) throws Exception {
		return orderDtlsDetailMapper.selectOrderDtlsDetail(seachVo);
	}

	/**
	 * 매매계약서 내부 거래명세서, 세금계산서 ozReport 실행시 필요한 파라미터 조회
	 */
	@Override
	public Map<String, Object> selectTaxBillInfo(String orderNo) throws Exception {
		return orderDtlsDetailMapper.selectTaxBillInfo(orderNo);
	}

	/**
	 * 출고 정보 리스트를 조회한다.
	 */
	@Override
	public List<DlivyVO> selectDlivyList(String seachVo) throws Exception {

		return orderDtlsDetailMapper.selectDlivyList(seachVo);
	}

	/**
	 * 차량종류 공통코드를 조회한다.
	 */
	@Override
	public List<CommonCodeVO> selectVhcleGroupCodeList(String sleMthdCode, String metalCode) throws Exception {
		return orderDtlsDetailMapper.selectVhcleGroupCodeList(sleMthdCode, metalCode);
	}

	/**
	 * 차량정보를 조회한다.
	 */
	@Override
	public List<VhcleInfoVO> selectVhcleInfoList(VhcleInfoVO vhcleInfoVO) throws Exception {
		List<VhcleInfoVO> list = orderDtlsDetailMapper.selectVhcleInfoList(vhcleInfoVO);
		if (!CollectionUtils.isEmpty(list)) {
			for (VhcleInfoVO vo : list) {
				if (StringUtils.isBlank(vo.getDrverTlphonNo())) continue;

				String drverTlpphonNo = CryptoUtil.decryptAES256(vo.getDrverTlphonNo());
				vo.setDrverTlphonNo(StringUtil.formatPhone(drverTlpphonNo)); // 복호화
			}
		}

		return list;
	}

	/**
	 * 배송지 정보를 조회한다.
	 */
	@Override
	public DlvyVO selectDlvrg(String seachVo) throws Exception {
		DlvyVO selectDlvrg = orderDtlsDetailMapper.selectDlvrg(seachVo);

		// OR_DLVRG_BAS(주문_배송지 기본) - RECEPT_ENTRPS_MOBLPHON_NO(수취 업체 휴대폰 번호) 복호화
		String receptEntrpsMoblphonNo = selectDlvrg.getReceptEntrpsMoblphonNo();
		if(StringUtils.isNotEmpty(receptEntrpsMoblphonNo)) {
			try {
				receptEntrpsMoblphonNo = CryptoUtil.decryptAES256(receptEntrpsMoblphonNo);
				/** 수취 업체 휴대폰 번호 셋팅 **/
				selectDlvrg.setReceptEntrpsMoblphonNo(StringUtil.formatPhone(receptEntrpsMoblphonNo));
			} catch(Exception e) {
				log.error("OrderDtlsDetailServiceImpl selectDlvrg RECEPT_ENTRPS_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}

		return selectDlvrg;
	}

	/**
	 * 배송지 정보를 수정한다.
	 */
	@Override
	public Map<String, Object> insertNewDlvrgInfo(DlvyVO dlvyVO) throws Exception {
	    Map<String, Object> rtnMap = new HashMap<>();

	    // 휴대폰번호 암복호화 추가
	    if (StringUtils.isNotBlank(dlvyVO.getReceptEntrpsMoblphonNo())) {
	    	dlvyVO.setReceptEntrpsMoblphonNo(CryptoUtil.encryptAES256(dlvyVO.getReceptEntrpsMoblphonNo()));
	    }
		// 기존 주문 배송지 번호는 삭제 처리한다. (삭제 여부와 삭제 일시, 최종 변경자 아이디, 최종 변경자 일시 업데이트)
		int updateOrDlvrgBasForDelete = orderDtlsDetailMapper.updateOrDlvrgBasForDelete(dlvyVO);
		log.debug(">> UnityOrderDetailServiceImpl > updateOrderDtlsChange > updateOrDlvrgBasForDelete : " + updateOrDlvrgBasForDelete);

		// 주문 배송지 번호를 새로 채번(+1증가)하여 변경 구분(changeSection)에 따른 변경 정보를 등록한 후 증가한 주문 배송지 번호를 리턴한다.
		DlvyVO newDlvyVO = orderDtlsDetailMapper.selectOrDlvrgBas(dlvyVO);  //1. 기존 배송지 정보 조회
		newDlvyVO.setDlvyRequstCn(dlvyVO.getDlvyRequstCn()); 				//2. 수정한 배송요청내용 저장
		newDlvyVO.setMberId(dlvyVO.getMberId()); 	 // 회원id
		newDlvyVO.setEntrpsNo(dlvyVO.getEntrpsNo()); //기업 번호
		orderDtlsDetailMapper.insertNewDlvrgInfo(newDlvyVO);				//3. 신규 배송지 정보로 저장
		orderDtlsDetailMapper.insertOrDlvrgBasHst(newDlvyVO); // 배송지 이력
		log.debug(">> UnityOrderDetailServiceImpl > updateOrderDtlsChange > orderDlvrgNoKey : " + newDlvyVO.getOrderDlvrgNoKey());

		/* 2023.01.31 출고요청일 변경 로직 주석처리_(SOREC-IF-106 물류에서 수신불가)
		 출고요청일 변경 유무 확인
	    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
		// 날짜 비교위해 데이터 convert
	    int compare = 0;
	    if("01".equals(dlvyVO.getDlvyMnCode())) {
	        Date originDe = simpleDateFormat.parse(dlvyVO.getDlivyRequstDe());     //기존 출고요청일
	        Date changeDe = simpleDateFormat.parse(dlvyVO.getNewDlivyRequstDe());  //변경 출고요청일
	        compare = changeDe.compareTo(originDe);
	        log.debug("출고요청일 변경 >> 기존출고요청일 : " + originDe + ", 변경출고요청일 : " + changeDe);
	    }  */

        /** 실제로 기존 출고요청일과 다른 날짜로 변경시에만 API 전송
         	2022.3.8 배송지수정 API 전송 금지 요청
		 	2022.10.17 출고요청일 변경 API 전송 재개
		 	2023.01.31 출고요청일 수정 API 전송 금지 재요청 **/
        //if(compare != 0) {
			try {
	            // 배송지 수정 api
				String dlvrgChangeUrl = orProperty.getLoOmsUrl()+"/DlvrgChange/"+dlvyVO.getOrderNo()+"/"+newDlvyVO.getOrderDlvrgNoKey()+"/"+1; //+"/"+dlvyVO.getNewDlivyRequstDe()+"/"+1;
	            Map<String, Object> resObj = httpClientHelper.postCallApi(dlvrgChangeUrl, null);

	            if (resObj == null || resObj.isEmpty()) {
					throw new Exception("통신장애");
				}
	        } catch (Exception e) {
	            log.error("OrderDtlsDetailServiceImpl.insertNewDlvrgInfo ===> ", e.getMessage());
	            rtnMap.put("result", "E");
	            rtnMap.put("resultMsg", "일부 통신장애가 발생하였습니다. 관리자에게 문의하세요.");

	            return rtnMap;
	        } finally {
	        	// 주문_주문 기본(OR_ORDER_BAS) 테이블 변경(배송지 변경시 주문 배송지 번호 update) : api 통신결과에 상관없이 이미 신규 배송지번호가 등록되었기때문에 업데이트 필수
	    		orderDtlsDetailMapper.updateOrOrderBas(newDlvyVO);
	        }
        //} else {
        // 주문_주문 기본(OR_ORDER_BAS) 테이블 변경(배송지 변경시 주문 배송지 번호 update) : 배송요청내용만 변경되는 경우에도 이미 신규 배송지번호가 등록되었기때문에 업데이트 필수
    	//	orderDtlsDetailMapper.updateOrOrderBas(newDlvyVO);
        //}

		rtnMap.put("result"   , "S");
		rtnMap.put("resultMsg", "배송지 정보 수정이 완료되었습니다.");

		return rtnMap;
	}

	/**
	 * 배송차수 리스트을 조회
	 */
	@Override
	public Map<String, Boolean> selectDlvyOdrList(String orderNo) throws Exception {
		Map<String, Boolean> object = new LinkedHashMap<>();
		object.put("dlvyOdrStat1", false);
		object.put("dlvyOdrStat2", false);
		object.put("dlvyOdrStat3", false);
		object.put("dlvyOdrStat4", false);

		String dlvyOdr = "";

		List<Map<String, Object>> dlvyOdrList = orderDtlsDetailMapper.selectDlvyOdrList(orderNo);
		for( int i=0; i<dlvyOdrList.size(); i++ ) {
			dlvyOdr = "dlvyOdrStat" + String.valueOf(dlvyOdrList.get(i).get("dlvyOdr"));
			object.put(dlvyOdr, true);
		}

		return object;
	}

	/**
	 * 차량정보를 등록 및 수정한다.
	 * 20230724 차량 고도화
	 */
	@Override
	public Map<String, Object> modifyVhcleInfoList(List<VhcleInfoVO> vhcleInfoArr) throws Exception {
	    Map<String, Object> rtnMap = new HashMap<>();
	    rtnMap.put("result", "E");
        rtnMap.put("resultMsg", "일부 통신장애가 발생하였습니다. 관리자에게 문의하세요.");

        String dlivyRequstDe = "";
	    int vhcleCnt = 0;
		for (VhcleInfoVO vo : vhcleInfoArr) {
			vhcleCnt++;

			// 기사연락처 암호화
			if (StringUtils.isNotBlank(vo.getDrverTlphonNo())) {
				vo.setDrverTlphonNo(CryptoUtil.encryptAES256(vo.getDrverTlphonNo().replace("-", "")));
			}

			//기존출고요청일 조회
			dlivyRequstDe = orderDtlsDetailMapper.selectDlivyRequstDe(vo.getOrderNo());
			// 차량정보 등록 및 수정
			try {
				
				// update 로직 대응을 위한 기존 key값 backup
				int originVhclOrderSn = vo.getDlvyOdr();
				int originVhcleSn = vo.getVhcleSn();
				
				orderDtlsDetailMapper.insertVhcleBas(vo);
				orderDtlsDetailMapper.insertVhcleOrderDtl(vo);
				
				// update 대상일 시, update 하면서 가져온 최신 key값을 기존 key값으로 대체
				if(StringUtils.equals(vo.getMode(), "saved")) {
					vo.setDlvyOdr(originVhclOrderSn);
					vo.setVhcleSn(originVhcleSn);
				}
				
				//히스토리 생성
				Map<String,String> keyValue = new HashMap<>();
				keyValue.put("VHCLE_SN",String.valueOf(vo.getVhcleSn()));
				commonService.insertTableHistory("OR_VHCLE_BAS", keyValue);
				
				keyValue = new HashMap<>();
				keyValue.put("VHCLE_ORDER_SN",String.valueOf(vo.getDlvyOdr()));
				commonService.insertTableHistory("OR_VHCLE_ORDER_DTL", keyValue);

				//기존 출고요청일과 업데이트하려는 차량입고일 비교
				int result = DateUtil.intervalDay(dlivyRequstDe,vo.getVhcleWrhousngDe());
				//하루이상 차이날 경우(result가 양수면 차량입고일이 미래, 음수면 과거)
				if(result != 0) {
					//출고요청일 업데이트
					orderDtlsDetailMapper.updateDlivyRequstDe(vo);
					dlivyRequstDe = vo.getVhcleWrhousngDe();
					//히스토리 생성
					keyValue = new HashMap<>();
					keyValue.put("ORDER_NO",vo.getOrderNo());
					commonService.insertTableHistory("OR_ORDER_BAS", keyValue);
				}
				
				// 24-06-04 변경사항 : 메세지에서 차수 정보를 기존의 차수 정보(1차수, 2차수..)와 동일하게 구성할 수 있도록 메세지 처리용 차수 데이터 세팅
				vo.setDlvyOdrForMsg(vhcleCnt);
			} catch (Exception e) {
				log.error(e.getMessage());
				return rtnMap;
			}
		}

		try {
			if (vhcleCnt < 1) {
				throw new Exception("등록할 차량정보가 없습니다.");
			}

			// 차량정보 등록 및 수정 고객 SMS
			sendMessageToCustomer(vhcleInfoArr, "50");
			// 배송기사 SMS 발송
			sendMessageToDriver(vhcleInfoArr, "107");

		    // 자차 자량정보 등록 및 수정 api
			// FO/BO 호출 구분 (1:FO, 2:BO)
			Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getLoOmsUrl() + "/sendDlvyVhcleInfo/1", vhcleInfoArr);
			if (resObj.isEmpty()) {
				throw new Exception("통신장애");
			}

        } catch (Exception e) {
            log.error("차량정보 API 실패 ===> ", e.getMessage());
			// 자차 자량정보 등록 및 수정 api 오류 SMS
			callSms(vhcleInfoArr.get(0));
            return rtnMap;
        }

		rtnMap.put("result", "S");
		rtnMap.put("resultMsg", "차량정보가 등록되었습니다.");
		rtnMap.put("dlivyRequstDe", dlivyRequstDe);

		return rtnMap;
	}

	/**
	 * 성적서&패킹리스트를 조회
	 */
	@Override
	public List<Map<String, Object>> selectScreofePackngList(String orderNo) throws Exception {
		return orderDtlsDetailMapper.selectScreofePackngList(orderNo);
	}

	/**
	 * 케이지트레이딩 직인을 조회
	 */
	@Override
	public void selectSorinSign(HttpServletResponse response) throws Exception {
		response.setContentType("image/jpeg");
		byte[] imageFile = (byte[]) orderDtlsDetailMapper.selectSorinSign();
		InputStream is = new ByteArrayInputStream(imageFile);
		IOUtils.copy(is, response.getOutputStream());
	}

	/**
	 * 물류 휴일 정보 조회
	 */
	@Override
	public List<String> selectHolidayList(String orderNo) {
		return orderDtlsDetailMapper.selectHolidayList(orderNo);
	}

	/**
	 * 이벤트 휴일에 포함되는지 조회
	 */
	@Override
	public int checkHolidayYn(VhcleInfoVO vhcleInfoVO) {
		return orderDtlsDetailMapper.checkHolidayYn(vhcleInfoVO);
	}

	/**
	 * 템플릿에 따라 SMS 전송 처리. (내부 사용자 SMS)
	 */
	private void procSms(VhcleInfoVO vhcleInfoVO, String templateNum, String addStr) {
		log.warn("[OrderDtlsDetailServiceImpl][procSms] IN");

		try {
			Map<String, String> smsMap = new HashMap<>();

			switch (templateNum) {
				case "49":
					smsMap.put("orderNo", vhcleInfoVO.getOrderNo()); // 주문번호
					smsMap.put("returnMsg", addStr); // 자차 자량정보 등록 및 수정 IF시 오류발생
					break;
			}

			smsMap.put("templateNum", templateNum);

			// 자차 자량정보 등록 및 수정 api 오류 SMS 전송
			smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
			smsService.insertSMS(null, smsMap);
		} catch (Exception e) {
			log.error("[OrderDtlsDetailServiceImpl][procSms] " + ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 * 고객 대상 메세지 발송 메소드
	 */
	private void sendMessageToCustomer(List<VhcleInfoVO> vhcleInfoArr, String templateNum) throws Exception {
		log.warn("[OrderDtlsDetailServiceImpl][sendMessageToCustomer] IN");
		try {
			SMSVO smsVO = new SMSVO();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));

			Map<String, String> smsMap = new HashMap<>();
			VhcleInfoVO vo = null;
			String smsList = "";
			
			// 메세지 내용에 1부터 시작하는 차수를 생성하여 보여주도록 하기 위해 소스 변경
			// 임시배송차수 For 메세지
			int tempDlvyOdrForMsg = 1;

			for(VhcleInfoVO voInfoVO : vhcleInfoArr) {
				// 삭제 대상 차수 정보는 내용으로 포함되지 않도록 로직 skip 처리
				if(StringUtils.equals(voInfoVO.getDeleteAt(), "Y")) {
					continue;
				}
				
				smsList += tempDlvyOdrForMsg++ + "회차";	// db에 등록된 배송차수 말고, 임시배송차수로 내용 구성
				if(!String.valueOf(voInfoVO.getDlvyOdrForMsg()).isEmpty() && !voInfoVO.getVhcleWrhousngDe().isEmpty() && !voInfoVO.getDrverNm().isEmpty() && !voInfoVO.getVhcleNo().isEmpty() && !voInfoVO.getDrverTlphonNo().isEmpty()) {
					smsList += "(차량입고일: " + voInfoVO.getVhcleWrhousngDe() + ")" + "\n"
							+	voInfoVO.getDrverNm() + "-" + voInfoVO.getVhcleNo() + " (" + StringUtil.formatPhone(CryptoUtil.decryptAES256(voInfoVO.getDrverTlphonNo())) + ")" + "\n" + "\n";
				}else {
					smsList += "(미등록)" + "\n" + "\n";
				}
				vo = voInfoVO;
			}

			//고객 전화번호
			OrderDtlsVO orderDtlsVO = orderDtlsDetailMapper.selectSmsUserInfo(vo);

			// ORDRR_MOBLPHON_NO(주문자 휴대폰 번호) 복호화
			String ordrrMoblphonNo = String.valueOf(orderDtlsVO.getOrdrrMoblphonNo());
			if(StringUtils.isNotEmpty(ordrrMoblphonNo)) {
				try {
					log.debug("주문자 휴대폰 번호 복호화 전 ==================>" + ordrrMoblphonNo);
					ordrrMoblphonNo = CryptoUtil.decryptAES256(ordrrMoblphonNo);
					log.debug("주문자 휴대폰 번호 복호화 후 ==================>" + ordrrMoblphonNo);
					/** 주문자 휴대폰 번호 셋팅 **/
					orderDtlsVO.setOrdrrMoblphonNo((ordrrMoblphonNo));
				} catch (Exception e) {
					log.error("OrderDtlsDetailServiceImpl sendMessageToCustomer ORDRR_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
			}
			smsVO.setPhone(orderDtlsVO.getOrdrrMoblphonNo());
			smsVO.setCommerceNtcnAt("N"); // 커머스 알림 여부

			switch(templateNum) {
			case "50" :
				smsMap = orderDtlsDetailMapper.selectSmsInfo(vo);
				smsMap.put("smsList", smsList);

				break;
			}

			smsMap.put("templateNum", templateNum);

			log.debug(">> smsMap toString : " + smsMap.toString());

			smsService.insertSMS(smsVO, smsMap);

		} catch (Exception e) {
			log.error("[OrderDtlsDetailServiceImpl][sendMessageToCustomer] " + ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 * 배송기사 대상 메세지 발송 메소드
	 */
	private void sendMessageToDriver(List<VhcleInfoVO> vhcleInfoArr, String templateNum) throws Exception {
		log.warn("[OrderDtlsDetailServiceImpl][sendMessageToDriver] IN");
		try {
			for(VhcleInfoVO voInfoVO : vhcleInfoArr) {
				SMSVO smsVO = new SMSVO();
				smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
				smsVO.setCommerceNtcnAt("N"); // 커머스 알림 여부

				VhcleInfoVO vo = null;
				Map<String, String> smsMap = new HashMap<>();

				String status = "";
				String prevPhoneNo = "";

				String newSmsList = "";
				String prevSmsList = "";

				//내부사용자 전송용 메시지 내용 별도로 세팅
				String innerDepartmentSmsList = "";

				if(voInfoVO.getMode().equals("new")) {
					status = "등록";
				}else if(voInfoVO.getMode().equals("saved")) {
					if(voInfoVO.getDeleteAt().equals("Y")) {
						status = "삭제";
					}else if(voInfoVO.getDeleteAt().equals("N")) {
						VhcleInfoVO vhclHist = orderDtlsDetailMapper.selectOrVhcleInfoHst(voInfoVO);
						
						if(vhclHist == null)
							continue;
						
						//기저장되어있는 휴대폰 번호 하이픈 제거 후 재복호화
						vhclHist.setDrverTlphonNo(CryptoUtil.encryptAES256(CryptoUtil.decryptAES256(vhclHist.getDrverTlphonNo()).replace("-", "")));
						
						//배송완료된 차수 정보 문자 전송 제외
						if(vhclHist != null && vhclHist.getDlvyProgrsSttusCode() < 30
								&& (!vhclHist.getDrverNm().equals(voInfoVO.getDrverNm())
								|| !vhclHist.getDrverTlphonNo().equals(voInfoVO.getDrverTlphonNo())
								|| !vhclHist.getVhcleNo().equals(voInfoVO.getVhcleNo())
								|| !vhclHist.getVhcleWrhousngDe().equals(voInfoVO.getVhcleWrhousngDe()))) {//배송정보 변경된 경우
							status = "변경";

							//변경전 폰번호
							prevPhoneNo = vhclHist.getDrverTlphonNo();

							//변경전 차량등록정보
							prevSmsList += voInfoVO.getDlvyOdrForMsg() + "회차";
							prevSmsList += "(차량입고일: " + vhclHist.getVhcleWrhousngDe() + ")" + "\n"
										+	vhclHist.getDrverNm() + "-" + vhclHist.getVhcleNo() + " (" + StringUtil.formatPhone(CryptoUtil.decryptAES256(vhclHist.getDrverTlphonNo())) + ")" + "\n" + "\n";
						}else {
							continue;
						}
					}
				}
				//변경된 차량등록정보
				newSmsList += voInfoVO.getDlvyOdrForMsg() + "회차";
				newSmsList += "(차량입고일: " + voInfoVO.getVhcleWrhousngDe() + ")" + "\n"
						   +	voInfoVO.getDrverNm() + "-" + voInfoVO.getVhcleNo() + " (" + StringUtil.formatPhone(CryptoUtil.decryptAES256(voInfoVO.getDrverTlphonNo())) + ")" + "\n" + "\n";

				vo = voInfoVO;

				String phoneNo = String.valueOf(voInfoVO.getDrverTlphonNo());
				if(StringUtils.isNotEmpty(phoneNo)) {
					try {
						phoneNo = CryptoUtil.decryptAES256(phoneNo);
						voInfoVO.setDrverTlphonNo((phoneNo));
						if(StringUtils.isNotEmpty(prevPhoneNo)) prevPhoneNo = CryptoUtil.decryptAES256(prevPhoneNo);
					} catch (Exception e) {
						log.error("OrderDtlsDetailServiceImpl sendMessageToDriver DRVER_TLPHON_NO CryptoUtil.decryptAES256 ERROR " + ExceptionUtils.getStackTrace(e));
					}
				}

				smsMap = orderDtlsDetailMapper.selectDriverSmsInfo(vo);
				smsMap.put("templateNum", templateNum);
				smsMap.put("excpSndngOptnAt", "N"); // 예외 발송 옵션 여부, N일 경우 SMS 수신자만 발송한다.

				//배송기사 메시지 전송
				if(status.equals("변경")) {
					if(StringUtils.isNotEmpty(prevPhoneNo)) {
						smsMap.put("smsList", prevSmsList);
						smsMap.put("status", "삭제");
						smsVO.setPhone(prevPhoneNo);

						smsService.insertSMS(smsVO, smsMap);
					}

					if(StringUtils.isNotEmpty(voInfoVO.getDrverTlphonNo())) {
						smsVO = new SMSVO();
						smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
						smsVO.setCommerceNtcnAt("N");

						smsMap.put("smsList", newSmsList);
						smsMap.put("status", "등록");
						smsVO.setPhone(voInfoVO.getDrverTlphonNo());

						smsService.insertSMS(smsVO, smsMap);
					}

					innerDepartmentSmsList = StringUtils.removeEnd(prevSmsList, "\n") + "[변경]" + "\n" + newSmsList;
				}else {
					if(StringUtils.isNotEmpty(voInfoVO.getDrverTlphonNo())) {
						smsMap.put("smsList", newSmsList);
						smsMap.put("status", status);
						smsVO.setPhone(voInfoVO.getDrverTlphonNo());

						smsService.insertSMS(smsVO, smsMap);
					}

					innerDepartmentSmsList = newSmsList;
				}

				log.debug(">> smsMap toString : " + smsMap.toString());

				// 내부사용자 별도 전송
				smsMap.put("smsList", innerDepartmentSmsList);
				smsMap.put("status", status);
				smsMap.put("commerceNtcnAt", "N"); // 추가 수신사 커머스 알림 여부 따로 설정
				smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
				smsService.insertSMS(null, smsMap);
			}
		} catch (Exception e) {
			log.error("[OrderDtlsDetailServiceImpl][sendMessageToDriver] " + ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 * SMS 서비스를 호출
	 */
	private synchronized void callSms(VhcleInfoVO vhcleInfoVO) {
		log.warn("[OrderDtlsDetailServiceImpl][callSms] IN");
		// 템플릿에 따라 SMS 전송을 처리한다.
		procSms(vhcleInfoVO, "49", "자차 자량정보 등록 및 수정 api 실패");
	}

	/**
	 * 결제 정보 조회
	 */
	@Override
	public OrSetleInfoVO selectOrSetleInfo(String orderNo) throws Exception {
		OrSetleInfoVO orSetleInfoVO = orderDtlsDetailMapper.selectOrSetleInfo(orderNo);
		
		// 세금계산서 발행일자 조회
		List<Map<String, Object>> taxBillRequestDeList = orderDtlsDetailMapper.selectTaxBillRequestDeList(orderNo);
		
		String taxBillClCode = null;
		String taxBillReqstDe = null;
		
		for (Map<String, Object> map : taxBillRequestDeList) {
			taxBillClCode = (String) map.get("taxBillClCode");
			taxBillReqstDe = (String) map.get("taxBillReqstDe");
			
			if(StringUtils.equals(taxBillClCode, "01")) {
				orSetleInfoVO.setTaxBillReqstDe(taxBillReqstDe);
			} else if(StringUtils.equals(taxBillClCode, "02")) {
				orSetleInfoVO.setModifiedTaxBillReqstDe(taxBillReqstDe);
			}
		}
		
		// 결제 상세 정보 조회
		List<OrSetleDtlsInfoVO> setleDtlsList = orderDtlsDetailMapper.selectSetleDtlsList(orderNo);
		orSetleInfoVO.setSetleDtlsList(setleDtlsList);
		
		// 24-07-04 변경사항 : 부분 출고 상환 여부에 따라 결제 정보 영역을 구성하는 데이터 조회 및 세팅하는 로직 추가
		if(StringUtils.equals(orSetleInfoVO.getPartDlivyRepyAt(), "Y")) {	// 부분 출고 상환 대상인 주문일 시
			// 추가 금액 결제 완료 여부
			boolean isAditAmountSetled = setleDtlsList.stream().anyMatch((setleDtl) -> {return StringUtils.equals(setleDtl.getHeader(), "추가결제");});
			
			orSetleInfoVO.setAditAmountSetled(isAditAmountSetled);
			
			// 주문_담보 중도 상환 데이터 조회
			List<OrMrtggMdstrmRepyVO> mdstrmRepyList = orderDtlsDetailMapper.selectOrMrtggMdstrmRepyDtl(orSetleInfoVO);
			
			// 중도 상환 확정 정보 목록 : 확정 금액(dcsnAmount)이 존재하는 데이터로만 filtering 하여 list 구성
			//							  해당 데이터는 물류에서 차수별 확정 데이터(배송 차수, 확정 금액 등) 수신 시 생성됨
			orSetleInfoVO.setMdstrmRepyDcsnInfoList(mdstrmRepyList.stream().filter(vo -> {return vo.getDcsnAmount() != null;}).collect(Collectors.toList()));
			
			// 중도 상환 입금 정보 목록 : 입금 요청 금액(rcpmnyRequstAmount)이 존재하는 데이터로만 filtering 하여 list 구성
			//							  해당 데이터는 물류에서 차수별 확정 데이터 수신 및 미출고 상환 처리 시점에 생성됨
			orSetleInfoVO.setMdstrmRepyRcpmnyInfoList(mdstrmRepyList.stream().filter(vo -> {return vo.getRcpmnyRequstAmount() != null;}).collect(Collectors.toList()));
			
			// 상환 가능한 데이터가 없으면 주문 상세 화면에서 상환버튼 disable 처리 
			orSetleInfoVO.setMdstrmRepyPossAt(mdstrmRepyList.stream().anyMatch((vo) -> {return StringUtils.equals(vo.getRepyComptCode(), "N");}));
			
			// 미출고 상환 존재 여부. 미출고 상환 건이 존재할 때만 정산, 추가결제 데이터를 표시함
			// 미출고 상환 데이터는 배송 차수가 NULL, 즉 조회된 배송 차수 값이 0이다
			orSetleInfoVO.setNootgRepyExstAt(mdstrmRepyList.stream().anyMatch((vo) -> {return vo.getDlvyOdr() == 0;}));
		}
		
		// 24-10-25 변경사항 : 가단가 주문(05)에서 발생한 "추가 변동금"에 대한 정보를 조회 및 세팅하는 로직 추가
		if(StringUtils.equals(orSetleInfoVO.getSleMthdCode(), "05")) {
			List<OrPcChangegldBasVO> pcChangegldInfoList = orderDtlsDetailMapper.selectOrPcChangegldInfo(orderNo);
			
			orSetleInfoVO.setPcChangegldInfoList(pcChangegldInfoList);
			
			// 입금요망, 출금가능 
			boolean pcChangegldRcpmnyAt = pcChangegldInfoList.stream().anyMatch(vo -> {return StringUtils.equals(vo.getPcChangegldSttusCode(), "10");});
			
			orSetleInfoVO.setPcChangegldRcpmnyAt(pcChangegldRcpmnyAt);
		}
		
		return orSetleInfoVO;
	}

	/**
	 * 결제 수단에 따른 결제 정보를 조회
	 */
	@Override
	public OrSetleInfoVO selectOrSetleInfo(OrSetleInfoVO setleInfo) throws Exception {

		//해당 주문번호의 결제 상세내역 리스트
		List<OrSetleDtlsInfoVO> setleDtlsList = new ArrayList<>();

		//전자상거래보증 or 케이지크레딧
		if ("20".equals(setleInfo.getSetleMthdCode()) || "40".equals(setleInfo.getSetleMthdCode())) {
			setleDtlsList = orderDtlsDetailMapper.selectOrSetleDtlsMrtggList(setleInfo);

		}

		if ("90".equals(setleInfo.getSetleMthdCode())) {
			if ("9030".equals(setleInfo.getSetleMthdDetailCode())) { // 계약금(구매자금)
				setleDtlsList = orderDtlsDetailMapper.selectOrSetleDtlsWrtmLonList(setleInfo);
			} else {
				setleDtlsList = orderDtlsDetailMapper.selectOrSetleDtlsWrtmList(setleInfo);
			}
		}

		setleInfo.setSetleDtlsList(setleDtlsList);

		return setleInfo;
	}

	/**
	 *	입금확인서 정보를 조회한다.
	 */
	@Override
	public OrSetleInfoVO selectRcpmnyCnfrmnInfo(String orderNo)  throws Exception{
		return orderDtlsDetailMapper.selectRcpmnyCnfrmnInfo(orderNo);
	}

	/**
	 *  신용보증 주문의 상환버튼 노출 여부를 조회한다.
	 */
	@Override
	public String getRepyPossibleAt(String orderNo) throws Exception {
		//2022-09-22 공통function 사용으로 수정
		return orderDtlsDetailMapper.getRepyPossAt(orderNo);
	}

	/**
	 * 기준일자, 일수를 받아 계산된 영업일과 날짜변경가능여부를 리턴

	 	returnDe : 고객이 변경하려는 출고요청일 기준으로 계산한 예상 결제예정일
	 				- 담보보증 : 변경출고요청일(미포함) + 담보상환기간
				    - 증거금  : 변경출고요청일 -1 (바로 이전 영업일)
	 */
	@Override
	public Map<String, Object> getSettleSttusDe(DlvyVO dlvyVO) throws Exception {
		Map<String, Object> map = new HashMap<>();
		boolean result = false; //변경가능한 출고예정일이면 true, 변경불가하면 false 리턴

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
		String strToday = DateUtil.getNowDate();
		dlvyVO.setDayCnt(orderDtlsDetailMapper.selectDayCntBySetleMthd(dlvyVO)); //반환날짜 계산을 위한 계산일수 조회
		String bsnDe = orderDtlsDetailMapper.getSettleSttusDe(dlvyVO); 			 //계산된 반환날짜 = 변경될 결제예정일

		// 날짜 비교위해 데이터 convert
		Date payDe = simpleDateFormat.parse(bsnDe);							   //결제예정일(예상)
        Date today = simpleDateFormat.parse(strToday);         				   //변경시점(현재)

        int compare = payDe.compareTo(today);
		if(compare > 0) { //결제예정일(예상) > 현재
			result = true;
		}

		map.put("yn", result);
        map.put("returnDe", bsnDe);

		return map;
	}

	/**
	 * 쿠폰 차감내역 조회.
	 */
	@Override
	public Map<String, Object> selectCouponDdctList(String orderNo)  throws Exception{
		Map<String, Object> map = new HashMap<>();
		List<OrderCouponDdctVO> couponlist  = orderDtlsDetailMapper.selectCouponDdctList(orderNo);
		List<OrderCouponDdctVO> untpcDscntlist  = new ArrayList<>();
		List<OrderCouponDdctVO> Dlvrflist  = new ArrayList<>();
		for(OrderCouponDdctVO vo : couponlist) {
			if("01".equals(vo.getCouponTyCode())){
				untpcDscntlist.add(vo);
			} else if("03".equals(vo.getCouponTyCode())){
				Dlvrflist.add(vo);
			}
		}
		map.put("untpcDscntlist",untpcDscntlist);
		map.put("Dlvrflist",Dlvrflist);
		return map;
	}
	@Override
	public List<OrSetleDtlsInfoVO> getAvrgRefundSetleList(OrSetleInfoVO setleInfo) throws Exception {

//		if("20".equals(setleInfo.getSetleMthdCode()) || "40".equals(setleInfo.getSetleMthdCode())) {//전자상거래보증 or 케이지크레딧
//
//			setleDtlsList = orderDtlsDetailMapper.selectOrSetleDtlsMrtggList(setleInfo);
//		} else if("90".equals(setleInfo.getSetleMthdCode())) {	//계약금
//			if("9030".equals(setleInfo.getSetleMthdDetailCode())) { //계약금(구매자금)
//				setleDtlsList = orderDtlsDetailMapper.selectOrSetleDtlsWrtmLonList(setleInfo);
//			} else {
//				setleDtlsList = orderDtlsDetailMapper.selectOrSetleDtlsWrtmList(setleInfo);
//			}
//		}

		return orderDtlsDetailMapper.getAvrgRefundSetleList(setleInfo);
	}
}