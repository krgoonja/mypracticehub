package com.sorincorp.fo.my.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingWeightCalculateValuesVO;
import com.sorincorp.comm.itemprice.service.ItemPriceMatchingService;
import com.sorincorp.comm.message.model.AppPushQueueVO;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.model.CommFtrsFshgMngVO;
import com.sorincorp.comm.order.model.CommOrOrderFtrsBasVO;
import com.sorincorp.comm.order.model.OrOrderDtlVO;
import com.sorincorp.comm.order.model.OrderDtlsClaimVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.comm.order.service.CommFtrsFshgMngService;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.my.mapper.ClaimMapper;
import com.sorincorp.fo.my.model.OrderDtlsVO;
import com.sorincorp.fo.pd.comm.constant.PdCommConstant;
import com.sorincorp.fo.pd.comm.constant.PdPropertyConstant;
import com.sorincorp.fo.pd.mapper.OrderMapper;
import com.sorincorp.fo.pd.model.OrderReceiptVO;

import lombok.extern.slf4j.Slf4j;

import com.sorincorp.fo.my.model.OrOrderFtrsVO;

@Slf4j
@Service
public class ClaimServiceImpl implements ClaimService {

	/** comm, utils */
	@Autowired
	private HttpClientHelper httpClientHelper;
	@Resource(name = "orderThreadPool")
	private ThreadPoolTaskExecutor taskExecutor;

	/** service */
	@Autowired
	private AssignService assignService;
	@Autowired
	private PcInfoService pcInfoService;	/** 실시간 판매 가격 함수 서비스 **/
	@Autowired
	private ItemPriceMatchingService itemPriceMatchingService;
	@Autowired
	private SMSService smsService;	/** SMS 발송 서비스 **/
	@Autowired
	private MailService mailService;	/** 이메일 발송 서비스 **/
	@Autowired
	private CommFtrsFshgMngService commFtrsFshgMngService;    /** 선물 선물환 관리 서비스 **/

	/** mapper */
	@Autowired
	private ClaimMapper claimMapper;
	@Autowired
	private OrderMapper orderMapper;

	/** 프로퍼티 상수 모음 **/
	@Autowired
	private PdPropertyConstant orProperty;

	/** 상수 */
	final String CLAIM_TY_CODE_CANCEL = "01"; //취소
	final String CLAIM_TY_CODE_RETURN = "02"; //반품
	final String CLAIM_TY_CODE_EXCHANGE = "03"; //교환

	/**
	 * 클레임 데이터 조회
	 */
	@Override
	public OrderDtlsClaimVO getClaimData(OrderDtlsVO searchVo) throws Exception {
		OrderDtlsClaimVO vo = claimMapper.getClaimData(searchVo);
		// 2022.2.10 담당자 연락처 암호화 추가
		if (null != vo && StringUtils.isNotBlank(vo.getNtcnChargerMoblphonNo())) {
			vo.setNtcnChargerMoblphonNo(CryptoUtil.decryptAES256(vo.getNtcnChargerMoblphonNo()));
		}

		return vo;
	}

	/**
	 * 클레임 신청 처리
	 */
	@Override
	public int requestClaim(OrderDtlsClaimVO paramClaimVo) throws Exception {

		log.debug("::: requestClaim START");

		//클레임 기본 데이터 조회
		OrderDtlsVO searchVo = new OrderDtlsVO();
		searchVo.setOrderNo(paramClaimVo.getOrderNo());
		searchVo.setCanclExchngRtngudNo(paramClaimVo.getCanclExchngRtngudNo());
		OrderDtlsClaimVO claimVo = claimMapper.getClaimData(searchVo);
		claimVo.setRtngudExchngRtrvlPrearngeDe(paramClaimVo.getRtngudExchngRtrvlPrearngeDe());
		claimVo.setCstmrPremiumNo(paramClaimVo.getCstmrPremiumNo());
		claimVo.setCstmrSlePcRltmSn(paramClaimVo.getCstmrSlePcRltmSn());
		claimVo.setCstmrLmePcRltmSn(paramClaimVo.getCstmrLmePcRltmSn());
		claimVo.setCstmrEhgtPcRltmSn(paramClaimVo.getCstmrEhgtPcRltmSn());
		claimVo.setMberId(paramClaimVo.getMberId());

		//클레임 처리 프로세스 주문 객체
		OrderModel orderModel = new OrderModel();
		orderModel.setOrderNo(paramClaimVo.getOrderNo());
		orderModel.setCanclExchngRtngudNo(paramClaimVo.getCanclExchngRtngudNo());
		orderModel.setMberId(paramClaimVo.getMberId());
		orderModel.setMberNo(paramClaimVo.getMberNo());
		orderModel.setEntrpsNo(paramClaimVo.getEntrpsNo());
		orderModel.setClaimDetail(claimVo);

		// 취소 가능일시 지남
		if (StringUtils.equals("01", claimVo.getCanclExchngRtngudTyCode()) && claimVo.getCanclPossYn() < 0) {
			orderModel.setOrderSttusCode("99");
			orderModel.setOrderFailrResn("취소신청기한만료");
			claimMapper.updateLastClaimMaster(orderModel);
			instHistory(orderModel);
			return 99;
		}

		log.debug(paramClaimVo.getDocNo());

		//첨부 파일 처리
		if (StringUtil.isNotBlank(paramClaimVo.getDocNo())) {
			String[] arrDocNo = paramClaimVo.getDocNo().split(",");
			if (null != arrDocNo && 0 < arrDocNo.length) {
				for (String docNo : arrDocNo) {
					OrderDtlsClaimVO fileVo = new OrderDtlsClaimVO();
					fileVo.setOrderNo(paramClaimVo.getOrderNo());
					fileVo.setCanclExchngRtngudNo(paramClaimVo.getCanclExchngRtngudNo());
					fileVo.setDocNo(docNo);
					fileVo.setMberId(paramClaimVo.getMberId());
					claimMapper.insertOrCanclExchngRtngudAtchmnflBas(fileVo);
				}
			}
		}

		try {
			/** 주문 정합성 체크
			 * 1. 주문기본정보
			 * 2. 배송지
			 * 3. 프리미엄 + 가격 설정
			 * **/
			chkValidAndSetBaseInfo(orderModel);

			/** 클레임 데이터 업데이트 (상태 및 가격) **/
			orderModel.setOrderSttusCode("03");
			claimMapper.updateClaimMaster(orderModel);

			/** 실시간 가격일시 삼성선물 호출 - 알루미늄(01) 아연(02) **/
			if (StringUtils.equals(orderModel.getSleMthdCode(), "01")) {
				// 선물 SKIP 여부, 선물 틱 설정 값 등 정보 조회
				BigDecimal threemonthLmePc = Optional.ofNullable(orderModel.getPrSelVO().getThreemonthLmePc()).orElse(BigDecimal.valueOf(0)); // 3개월 LME 가격(3M 가격)
				CommFtrsFshgMngVO getFtrsFshgMngRetVo = commFtrsFshgMngService.getFtrsFshgMngRetVo(orderModel.getMetalCode(), "B", threemonthLmePc);
				orderModel.setCommFtrsFshgMngVO(getFtrsFshgMngRetVo);
				log.warn(">> 실시간 판매 가격 정보 조회 (선물 SKIP 여부, 선물 틱 설정 값 등 정보 조회) orderModel.getCommFtrsFshgMngVO() : " + orderModel.getCommFtrsFshgMngVO());

				callSamsung(orderModel);
			}
			/** 고정가 가격일시 이월렛 호출 **/
			else if (StringUtils.equals(orderModel.getSleMthdCode(), "02")) {
				/** 판매방식 고정가 일때 (별도 배치로 실행)
				 * 취소 - 당일 오후 5시 처리
				 * 반품 - 입고 후 다음날 오전 10시 처리
				 * 교환 - 신청시 입고 + 출고는...? (로직 확인 필요)
				 */
				orderModel.setOrderSttusCode("04");
				claimMapper.updateLastClaimMaster(orderModel);

			} else {
				log.info("ClaimServiceImpl requestClaim line-198 vo.toString() >> " + paramClaimVo.toString());
				throw new CommCustomException("판매방식 미존재");
			}

			/** 선물 성공 후 클레임 완료 처리
			 * 이월렛 처리 후 최종 완료(05) 처리
			 * **/
			if (StringUtils.equals("04", orderModel.getOrderSttusCode())) {
				claimComplete(orderModel);
			}

		} catch (Exception e) {
			log.error("::: requestClaim error "+ ExceptionUtils.getStackTrace(e));
			orderModel.setOrderFailrResn(e.getMessage());
			claimFail(orderModel);

			log.debug("::: requestClaim END");
			return -1;
		}

		log.debug("::: requestClaim END");

		return 0;
	}

	private void chkValidAndSetBaseInfo(OrderModel orderModel) throws Exception {
		log.debug("::: chkValidAndSetBaseInfo START");

		/** 클레임 BL 기준으로 원주문 BL 정보 조회
		 * - 교환일때는 교환 bl 기준으로 조회하여 필요한 데이터를 가져와야 하므로 로직 보완 필요 (교환 X)
		 *  **/
		orderModel.setOrderBlList(Optional
				.ofNullable(claimMapper.getListOrOrderDtl(orderModel.getClaimDetail()))
				.orElseThrow(() -> {
					log.info("ClaimServiceImpl chkValidAndSetBaseInfo line-232 vo.toString() >> " + orderModel.toString());
					return new CommCustomException("클레임 BL 정보 미존재");
				}));

		// 주문 기본 정보 조회
		OrderReceiptVO orderReVo = Optional.ofNullable(orderMapper.selectOrderReceipt(orderModel)).orElseThrow(() -> {
			log.info("ClaimServiceImpl chkValidAndSetBaseInfo line-238 vo.toString() >> " + orderModel.toString());
			return new CommCustomException("주문 정보 미존재");
		});
		log.debug("주문기본정보 조회전 orderModel : "+ orderModel.toString());
		BeanUtils.copyProperties(orderReVo, orderModel);
		orderModel.setOmsRceptNo(null);	//OMS 접수번호 초기화

		log.debug("주문기본정보 : "+ orderReVo.toString());
		log.debug("주문기본정보 조회후 orderModel : "+ orderModel.toString());

		// 회원 및 업체, 배송지 정보 가져오기
		orderModel.setMbDlvrgBas(Optional.ofNullable(orderMapper.selectOrMbEntrpsDlvrgInfo(orderModel)).orElseThrow(() -> {
			log.info("ClaimServiceImpl chkValidAndSetBaseInfo line-250 vo.toString() >> " + orderModel.toString());
			return new CommCustomException("배송지 및 기본정보 미존재");
		}));
		orderModel.setMberId(orderModel.getMbDlvrgBas().getMberId());

		/** 프리미엄 정보 설정 */
		setPricePremiumInfo(orderModel, orderReVo);

		// 가격 정보 셋팅 (현재 기준 상품 단가 기준으로 재계산)
		setPriceInfo(orderModel, orderReVo);

		//교환일때만
		// TODO E-WALLET 잔금 조회 (클레임 불필요)
		if (StringUtils.equals(CLAIM_TY_CODE_EXCHANGE, orderModel.getClaimDetail().getCanclExchngRtngudTyCode())) {
			long ewalletMoney = 0;
			Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getEwalletMoneyUrl(),
					Collections.singletonMap("entrpsNo", orderModel.getEntrpsNo()));
			if (!ObjectUtils.isEmpty(resObj) && resObj.get(PdCommConstant.EWALLET_DATA_KEY) != null) {
				Map<String, Object> dataObj = (Map<String, Object>) resObj.get(PdCommConstant.EWALLET_DATA_KEY);
				ewalletMoney =  NumberUtils.toLong(String.valueOf(dataObj.get(PdCommConstant.EWALLET_MONNY_KEY)));
			}
			if (ewalletMoney < orderModel.getSlepc()) {
				log.info("ClaimServiceImpl chkValidAndSetBaseInfo line-272 vo.toString() >> " + orderModel.toString());
				throw new CommCustomException("Ewallet 금액 부족");
			}
		}

		log.debug("::: chkValidAndSetBaseInfo END");
	}

	/**
	 * <pre>
	 * 처리내용: 삼성선물을 호출한다.
	 * </pre>
	 * @date 2021. 9. 13.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 13.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	private void callSamsung(OrderModel orderModel) throws Exception {
		log.debug("::: callSamsung START");

		String nowDateTime = DateUtil.getNowDateTime("yyyyMMdd");
		/** 삼성선물 신규 생성 Key 리스트 **/
		List<String> ftrnNoList = new ArrayList<String>();
		/** 삼성선물 계좌 번호 **/
		String requstAcnutNo = CryptoUtil.encryptAES256(orProperty.getSamsungAcnutNo());
		orderModel.setRequstAcnutNo(requstAcnutNo);
		/** 삼성선물 마스터 테이블 생성 sell 포지션이므로 -10틱 -> 유동적으로 변경될 수 있는 사항이라 PROPERTY 관리 */
		BigDecimal threemonthLmePc = orderModel.getPrSelVO().getThreemonthLmePc()
				.subtract(BigDecimal.valueOf(orderModel.getCommFtrsFshgMngVO().getQuoteUnit() * orderModel.getCommFtrsFshgMngVO().getFtrsTick()));
		/** 사용한 삼성선물 실행 ID 리스트 */
		List<String> usedExecutIdList = new ArrayList<>();

		log.debug("threemonthLmePc : "+ String.valueOf(threemonthLmePc));

		/**
		 * 만기조정 전 / 후 바인딩 되는 삼성선물 실행 ID 가 달라지므로 만기 여부 확인
		 */
		boolean adjustmentFlg = false; 	// 만기여부
		if (0 < claimMapper.getCntOrderFtrsAdjustment(orderModel.getOrderNo())) {
			adjustmentFlg = true;
		}

		for (OrOrderDtlVO bl : orderModel.getOrderBlList()) {
			// 삼성선물 실행 ID 데이터 조회
			if (!adjustmentFlg) {
				bl.setRejectResn("filled");
			} else {
				bl.setRejectResn("Adjustment");
			}

			List<OrOrderFtrsVO> listOriFtrsVo = claimMapper.getListOrderFtrsExecut(bl);
			if (CollectionUtils.isEmpty(listOriFtrsVo)) {
				log.info("ClaimServiceImpl callSamsung line-330 vo.toString() >> " + orderModel.toString());
				throw new CommCustomException("삼성선물 주문 데이터 조회 실패");
			}

			orderModel.setOrderBlDetail(bl);
			// 삼성선물은 25톤 단위로 주문 하기때문에 25를 나눠서 1건씩 호출
			// TODO 기본 정책은 BL 단위 반품이라고 하지만 같은 BL 부분 반품(중량) 이라면 추가 로직이 필요할 수 있다
			int orderQy = bl.getRealOrderWt() / orderModel.getSleUnitWt();

			// 선물 원주문 데이터와 선물 클레임 날릴 데이터 row 수가 맞지 않으면 오류
			if (listOriFtrsVo.size() != orderQy) {
				log.info("ClaimServiceImpl callSamsung line-341 vo.toString() >> " + orderModel.toString());
				throw new CommCustomException("삼성선물 원주문 데이터와 클레임 데이터 확인 필요");
			}

			for (int i = 0 ;  i < orderQy ; i++) {
				// 채번 선물(1), FX(2)
				String newFtrsRequstOrderNo = nowDateTime + "-1" + assignService.selectAssignValue("OR",
						"FTRS_REQUST_ORDER_NO", nowDateTime, orderModel.getMberNo(), 10);
				orderModel.setFtrsRequstOrderNo(newFtrsRequstOrderNo);
				orderModel.setRequstOrderQy(1); // 1은 25톤을 의미, 25톤 단위로 호출하는 방식으로 정책 변경
				orderModel.setRequstOrderUntpc(String.valueOf(threemonthLmePc));

				String executId = listOriFtrsVo.get(i).getExecutId();
				/** 삼성선물 실행 ID 바인딩
				 * TODO 이미 바인딩된 executId 는 사용하지 않도록 방어로직 필요할수도..
				 */
//				for (String useEcId : usedExecutIdList) {
//					if (StringUtils.equals(useEcId, executId)) {
//						if ((listOriFtrsVo.size() - 1) > i) {
//							executId = listOriFtrsVo.get(i+1).getExecutId();
//							break;
//						}
//					}
//				}
				orderModel.setExecutId(executId);
				usedExecutIdList.add(executId);

				// 삼성선물 마스터 등록
				claimMapper.insertOrOrderFtrsBas(orderModel);

				// 호출한 KEY값 저장 -> 추후 실패했는지 성공했는지 파악하기 위해
				ftrnNoList.add(newFtrsRequstOrderNo);
			}
		} // end for

		orderModel.setFtrnNoList(ftrnNoList);

		/** 삼성선물 호출 */
		boolean isLooping = true;
		boolean isFail = false;
		Map<String, Object> rqsObj = new HashMap<String, Object>();
		rqsObj.put("canclExchngRtngudNo", orderModel.getClaimDetail().getCanclExchngRtngudNo());
		rqsObj.put("userId", orderModel.getMberNo());
		Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getSamsungClaimUrl(), rqsObj);

		log.debug("callSamsung api response : "+ resObj.toString());

		if (resObj != null
				&& StringUtils.equals(String.valueOf(resObj.get("code")), PdCommConstant.SAMSUNG_SUCCESS_CODE)) {
			/** 1건 이상 '성공'이라면 모두 성공으로 보고 로직 처리
			 * - 시간제한 없음
			 * - 모두 실패시 실패 처리 추가
			 * - 부분성공시 오프라인 재처리 하기로 함
			 * - 체결완료(30) 만 체크해야 할지...
			 * */
			while (isLooping) {
				Thread.sleep(500);
				List<CommOrOrderFtrsBasVO> samsungResList = claimMapper.selectOrderSamsungResponse(orderModel);
				if (CollectionUtils.isEmpty(samsungResList)) {
					log.info("ClaimServiceImpl callSamsung line-400 vo.toString() >> " + orderModel.toString());
					throw new CommCustomException("삼성선물 주문 데이터 조회 실패");
				}

				int failCnt = 0;
				int samsungFtrsCnt = samsungResList.size();
				for (CommOrOrderFtrsBasVO vo : samsungResList) {
					if (StringUtils.equals("30", vo.getRspnsFtrsSttusCode())) {
						isLooping = false;
						break;
					} else if (StringUtils.equals("60", vo.getRspnsFtrsSttusCode())) {
						failCnt++;
					} else {
						log.debug("loop...");
					}
				}

				// 모두 실패 일때 실패처리
				if (failCnt == samsungFtrsCnt) {
					isLooping = false;
					isFail = true;
				}
			}// end while

			if (!isFail) {
				// 삼성선물 성공
				orderModel.setOrderSttusCode("04");
				claimMapper.updateLastClaimMaster(orderModel);
			} else {
				log.info("ClaimServiceImpl callSamsung line-429 vo.toString() >> " + orderModel.toString());
				throw new CommCustomException("삼성선물 주문 체결 실패");
			}
		} else {
			log.error(resObj != null ? resObj.toString() : "resObj is null");
			// TODO api 실패시 기존건 삭제 처리 필요 (방어로직)
			claimMapper.deleteSamsungBase(orderModel);

			log.info("ClaimServiceImpl callSamsung line-437 vo.toString() >> " + orderModel.toString());
			throw new CommCustomException("삼성선물 주문 호출 실패");
		}

		log.debug("::: callSamsung END");
	}

	private void setPricePremiumInfo(OrderModel orderModel, OrderReceiptVO orderReVo) throws Exception {
		log.debug("::: setPricePremiumInfo START");

		String metalCode = orderModel.getMetalCode();
		Integer itmSn = orderModel.getItmSn();
		String dstrctLclsfCode = orderModel.getDstrctLclsfCode();
		String brandGroupCode = orderModel.getBrandGroupCode();
		String brandCode = orderReVo.getBrandCode();
		String premiumNo = null;
		String nowDate = DateUtil.getNowDate();
//		nowDate = "20211110";	// TODO 실시간 판매 가격 정보 조회 DateUtil.getNowDate() -> test

		// TODO 판매 가격 실시간 순번 (라이브, 고정 포함)을 구한다
		orderModel.setPrSelVO(Optional
				.ofNullable(pcInfoService.getNewestPrSelRltm(metalCode, itmSn, dstrctLclsfCode, brandGroupCode, brandCode, nowDate))
				.orElseThrow(() -> {
					log.info("ClaimServiceImpl setPricePremiumInfo line-460 vo.toString() >> " + orderModel.toString() + orderReVo.toString());
					return new CommCustomException("실시간 판매가격 정보 미존재");
				}));

		// 실시간 판매 가격 정보 조회
		if (StringUtils.equals(orderModel.getSleMthdCode(), "01")) {
			// 프리미엄 가격 정보 조회
			premiumNo = orderModel.getPrSelVO().getPremiumNo();
			orderModel.setPremiumNo(premiumNo);
			orderModel.setLivePremiumVO(Optional
				.ofNullable(pcInfoService.getLivePremiumInfo("present", premiumNo))
				.orElseThrow(() -> {
					log.info("ClaimServiceImpl setPricePremiumInfo line-472 vo.toString() >> " + orderModel.toString() + orderReVo.toString());
					return new CommCustomException("프리미엄 가격 미존재");
				}));

			// 프리미엄가
			long premiumPc = orderModel.getLivePremiumVO().getSlePremiumAmount();
			orderModel.setPremiumPc(new BigDecimal(premiumPc));
			// 상품단가 = endPc(종료 가격) + slePremiumAmount(판매 프리미엄 금액)
			orderModel.setGoodsUntpc(orderModel.getPrSelVO().getNonPremiumEndPc() + orderModel.getLivePremiumVO().getSlePremiumAmount());

			log.debug("실시간판매가격정보 : "+ orderModel.getPrSelVO().toString());
			log.debug("프리미엄번호 : "+ premiumNo);
			log.debug("프리미엄가격정보 : "+ orderModel.getLivePremiumVO().toString());
			log.debug("프리미엄가 : "+ String.valueOf(premiumPc));
			log.debug("상품단가 : "+ String.valueOf(orderModel.getGoodsUntpc()));
		}
		// 고정가 판매 가격 정보 조회
		else {
			orderModel.setFixPriceVO(Optional
				.ofNullable(pcInfoService.hasFixPriceData(metalCode, itmSn, dstrctLclsfCode, brandGroupCode, brandCode, DateUtil.getNowDateTime("yyyyMMddHHmmss")))
				.orElseThrow(() -> {
					log.info("ClaimServiceImpl setPricePremiumInfo line-493 vo.toString() >> " + orderModel.toString() + orderReVo.toString());
					return new CommCustomException("고정가 판매가격 정보 및 프리미엄 가격 미존재");
				}));

			orderModel.setPremiumNo(orderModel.getFixPriceVO().getPremiumNo());
			// 프리미엄가 = 고정가 권역 변동 금액 + 고정가 브랜드그룹 변동 금액 + 고정가 브랜드 변동 금액
			BigDecimal hghnetprcDstrctChangeAmount = Optional.ofNullable(orderModel.getFixPriceVO().getHghnetprcDstrctChangeAmount()).orElse(BigDecimal.valueOf(0)); // 고정가 권역 변동 금액
			BigDecimal hghnetprcBrandGroupChangeAmount = Optional.ofNullable(orderModel.getFixPriceVO().getHghnetprcBrandGroupChangeAmount()).orElse(BigDecimal.valueOf(0)); // 고정가 브랜드그룹 변동 금액
			BigDecimal hghnetprcBrandChangeAmount = Optional.ofNullable(orderModel.getFixPriceVO().getHghnetprcBrandChangeAmount()).orElse(BigDecimal.valueOf(0)); // 고정가 브랜드 변동 금액
			BigDecimal premiumPc = hghnetprcDstrctChangeAmount.add(hghnetprcBrandGroupChangeAmount).add(hghnetprcBrandChangeAmount);
			orderModel.setPremiumPc(premiumPc);

			// 상품단가 = 고정가 판매 금액
			orderModel.setGoodsUntpc(orderModel.getFixPriceVO().getHghnetprcSleAmount().longValue());

			log.debug("고정판매가격정보 : "+ orderModel.getFixPriceVO().toString());
			log.debug("프리미엄번호 : "+ premiumPc.toString());
			log.debug("프리미엄가 : "+ String.valueOf(orderModel.getPremiumPc()));
			log.debug("상품단가 : "+ String.valueOf(orderModel.getGoodsUntpc()));
		}

		log.debug("::: setPricePremiumInfo END");
	}


	/**
	 * <pre>
	 * 처리내용: 가격 정보를 세팅한다.
	 * </pre>
	 * @date 2021. 8. 24.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 24.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 */
	private void setPriceInfo(OrderModel orderModel, OrderReceiptVO orderReVo) throws Exception {
		log.debug("::: setPriceInfo START");

		long goodsUntpc = 0; 	/** 상품단가 */
		long orderPc;			/** 상품금액 */
		long wtChangegld = 0; 	/** 중량변동금 (원주문단가 * 1.5) **/
		long expectDlvrf = 0; 	/** 배송비 */
		long splpc;				/** 공급가 */
		long vat;				/** 부가세 */
		long slepc;				/** 판매가 */

		/** 클레임 구분에 따라 분기 */
		// 취소
		if (StringUtils.equals(CLAIM_TY_CODE_CANCEL, orderModel.getClaimDetail().getCanclExchngRtngudTyCode())) {
			log.debug("단가계산 취소");
			long claimOrderWt;		/** 클레임 중량 */
			long canclUntpcDiffPc = 0;	/** 취소 상품단가단순차액 (원주문단가 - 현재단가) */
			long canclUntpcDfnnt = 0;	/** 취소 단가차액 (중량 * 단순차액) */
			long premiumDfnlosAmount = 0; /** 프리미엄 차손 금액 (원주문프리미엄가 - 취소시프리미엄가 * 클레임중량) */
			long lgistPc = orderModel.getClaimDetail().getLgistPc(); //물류비
			long penltyAmount = orderModel.getClaimDetail().getPenltyAmount(); //패널티

			if (StringUtils.equals(orderModel.getDlvyMnCode(), "01")) {
				expectDlvrf = orderModel.getClaimDetail().getRealDlvyCt();
			}

			/** 취소는 실제주문중량을 사용하므로 확정중량인 경우 오류
			 * - 취소시 중량은 정수이지만 테스트 데이터 때문에 math 처리함
			 * */
			if (orderModel.getClaimDetail().getTotCanclExchngRtngudDcsnWt() % 1 > 0) {
				claimOrderWt = Math.round(orderModel.getClaimDetail().getTotCanclExchngRtngudDcsnWt());
			} else {
				claimOrderWt = (long)orderModel.getClaimDetail().getTotCanclExchngRtngudDcsnWt();
			}

			// 실시간, 고정가 분기
			if (StringUtils.equals(orderModel.getSleMthdCode(), "01")) {
				log.debug("라이브");
				goodsUntpc = Math.round(orderModel.getGoodsUntpc() / 1000.0) * 1000;

			} else {
				log.debug("고정가");
				// 고정가는 할증요율을 불러와서 계산
				BigDecimal totAmtTariff = Optional.ofNullable(claimMapper.selectTotAmtTariff(orderModel)).orElse(BigDecimal.valueOf(0));
				log.debug(">> totAmtTariff : " + totAmtTariff);
				log.debug(">> totAmtTariff : " + totAmtTariff.doubleValue());
				orderModel.setTotAmtTariff(totAmtTariff);
				goodsUntpc = Math.round((orderModel.getGoodsUntpc() + (orderModel.getGoodsUntpc() * (totAmtTariff.doubleValue() / 100))) / 1000.0) * 1000;
			}

			orderPc = goodsUntpc * claimOrderWt;
			/** 클레임은 중량변동금 없음
			 * wtChangegld = Math.round((orderModel.getGoodsUntpc() * 1.5) / 1000.0) * 1000;
			 */
			canclUntpcDiffPc = orderReVo.getGoodsUntpc() - goodsUntpc;
			canclUntpcDfnnt = claimOrderWt * canclUntpcDiffPc;
			premiumDfnlosAmount = (orderReVo.getPremiumPc().longValue() - orderModel.getPremiumPc().longValue()) * claimOrderWt;

			splpc = orderReVo.getSplpc()
					+ (canclUntpcDfnnt > 0 ? 0 : canclUntpcDfnnt)
					- lgistPc
					- penltyAmount;
			vat = (long) (splpc * 0.1);
			slepc = splpc + vat;

			log.debug("상품단가단순차액 (원주문단가 - 현재단가) : {} ({} - {})", canclUntpcDiffPc, orderReVo.getGoodsUntpc(), goodsUntpc);
			log.debug("단가차액 (중량 * 단순차액) : {} ({} * {})", canclUntpcDfnnt, claimOrderWt, canclUntpcDiffPc);
			log.debug("프리미엄 차손 금액 (원주문프리미엄가 - 취소시프리미엄가 * 클레임중량) : "+ premiumDfnlosAmount);
			log.debug("공급가액 (원주문공급가 +(단가차액) - 물류비 - 패널티) : {} + ({}) - {} - {}", orderReVo.getSplpc(), (canclUntpcDfnnt > 0 ? 0 : canclUntpcDfnnt), lgistPc, penltyAmount);

			orderModel.getClaimDetail().setGoodsUntpcClaim(goodsUntpc);
			orderModel.getClaimDetail().setOrderPc(orderPc);
			orderModel.getClaimDetail().setWtChangegld(0);
			orderModel.getClaimDetail().setRealDlvyCt(0);
			orderModel.getClaimDetail().setSplpc(splpc);
			orderModel.getClaimDetail().setVat(vat);
			orderModel.getClaimDetail().setSlepc(slepc);


			// TODO 정산 및 세금계산서에서 참조하는 필드이므로 수정 가능성 있음
			orderModel.getClaimDetail().setExcclcSorinDlvrf(0);	//정산케이지배송비
			orderModel.getClaimDetail().setExcclcSplpc(splpc);	//정산공급가
			orderModel.getClaimDetail().setExcclcVat(vat);	//정산부가세
			orderModel.getClaimDetail().setExcclcSlepc(slepc);	//정산판매가

			orderModel.getClaimDetail().setPremiumDfnlosAmount(premiumDfnlosAmount);
			//취소차액은 +금액이라면 1원 처리 (화면상에서는 1원 일때 0원 표기)
			orderModel.getClaimDetail().setCanclUntpcDfnnt(canclUntpcDfnnt > -1 ? 1 : canclUntpcDfnnt);
			//취소 정산상품단가 (취소는 단순 차액을 기입)
			orderModel.getClaimDetail().setExcclcGoodsUntpc(canclUntpcDiffPc);
			//취소 정산상품금액 (취소는 단순 차액 * 수량)
			orderModel.getClaimDetail().setExcclcGoodsAmount(canclUntpcDfnnt > -1 ? 0 : canclUntpcDfnnt);
			//취소 정산패널티
			orderModel.getClaimDetail().setExcclcPenltyAmount(penltyAmount);

		}
		// 반품, 교환
		else {
			log.debug("단가계산 반품");
			if (StringUtils.equals(orderModel.getDlvyMnCode(), "01")) {
				expectDlvrf = orderModel.getClaimDetail().getRealDlvyCt();
			}

			double claimOrderWt = orderModel.getClaimDetail().getTotCanclExchngRtngudDcsnWt();
			// 반품시에는 원주문 상품단가로
//			goodsUntpc = Math.round(orderModel.getGoodsUntpc() / 1000.0) * 1000;
			goodsUntpc = orderModel.getClaimDetail().getGoodsUntpcOrder();
			orderPc = Math.round((goodsUntpc * claimOrderWt) / 1000.0) * 1000;
			splpc = orderPc + expectDlvrf;
			vat = (long) (splpc * 0.1);
			slepc = splpc + vat;

			orderModel.getClaimDetail().setGoodsUntpcClaim(goodsUntpc);
			orderModel.getClaimDetail().setOrderPc(orderPc);
			orderModel.getClaimDetail().setWtChangegld(wtChangegld);
			orderModel.getClaimDetail().setRealDlvyCt(expectDlvrf);
			orderModel.getClaimDetail().setSplpc(splpc);
			orderModel.getClaimDetail().setVat(vat);
			orderModel.getClaimDetail().setSlepc(slepc);

			orderModel.getClaimDetail().setExcclcSorinDlvrf(expectDlvrf);	//정산케이지배송비
			orderModel.getClaimDetail().setExcclcSplpc(splpc);	//정산공급가
			orderModel.getClaimDetail().setExcclcVat(vat);	//정산부가세
			orderModel.getClaimDetail().setExcclcSlepc(slepc);	//정산판매가

			orderModel.getClaimDetail().setCanclUntpcDfnnt(0);	//취소차액
			orderModel.getClaimDetail().setExcclcGoodsUntpc(goodsUntpc);	//정산상품단가
			orderModel.getClaimDetail().setExcclcGoodsAmount(orderPc);	//정산상품금액
			orderModel.getClaimDetail().setExcclcPenltyAmount(0);	//취소 정산패널티
		}

		log.debug("claimDetail VO : "+ orderModel.getClaimDetail().toString());
		log.debug("goodsUntpc : "+ String.valueOf(goodsUntpc));
		log.debug("orderPc : "+ String.valueOf(orderPc));
		log.debug("expectDlvrf : "+ String.valueOf(expectDlvrf));
		log.debug("splpc : "+ String.valueOf(splpc));
		log.debug("vat : "+ String.valueOf(vat));
		log.debug("slepc : "+ String.valueOf(slepc));

		log.debug("::: setPriceInfo END");
	}


	/**
	 * <pre>
	 * 처리내용: 주문이 성공 일시 후처리 및 선물환, ewallt 등을 호출한다.
	 * </pre>
	 * @date 2021. 9. 13.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 13.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	private void claimComplete(OrderModel orderModel) throws Exception {
		log.debug("::: claimComplete START");

		try {
			/** 20211112 교환주석
			// LIVE 알루미늄(01), 아연(02)
			if (StringUtils.equals(orderModel.getSleMthdCode(), "01")) {
				// FX 호출
				callFX(orderModel);
			}
			*/
			// 재고 증감
			orderInvntryUdt(orderModel);
			// Oms 통신
			callOms(orderModel);
			// TODO 메일 발송
			callMail(orderModel);
			// TODO 앱푸시 발송 (푸시 내용 미확정)
			callAppPush(orderModel);
			// SMS 발송
			callSms(orderModel);
			// History 생성
			instHistory(orderModel);
		} catch (Exception e) {
			log.error("::: claimComplete error : " + ExceptionUtils.getStackTrace(e));
		}

		log.debug("::: claimComplete END");
	}

	/** 20211112 교환주석
	 * 20211208 선물환관리번호 -> 요청청산번호 필드 추가
	private synchronized void callFX(OrderModel orderModel) {
		log.debug("callFX START");
		Runnable fxRun = () -> {
			try {
				// 주문 디테일 테이블 생성
				for (OrOrderDtlVO bl : orderModel.getOrderBlList()) {
//					* PO테이블 조회
//					 * 선물 만기 일자 (FTRS_EXPRTN_DE)
//					 * 요청 주문 일자 = 선물 달러 수수료 (FTRS_DOLLAR_FEE) * 실제 주문 수량 (real_order_wt) / 선물 거래 중량 (FTRS_DELNG_WT)
//					 *
					orderModel.setItPurchsInfoBas(Optional.ofNullable(claimMapper.selectItPurchsInfoBas(bl)).orElseThrow(() -> {
						return new CommCustomException("PO 테이블 미존재");
					}));

					String fshgRequstOrderNo = DateUtil.getNowDateTime("yyyyMMdd")+ "-2" +
							assignService.selectAssignValue("OR", "FSHG_REQUST_ORDER_NO", DateUtil.getNowDate(), orderModel.getMberNo(), 10);
					orderModel.setFshgRequstOrderNo(fshgRequstOrderNo);
					orderModel.setOrderBlDetail(bl);

					// 하나은행 fx
					claimMapper.insertOrOrderFshgBas(orderModel);
				}

				Map<String, Object> rqsObj = new HashMap<String, Object>();
				rqsObj.put("canclExchngRtngudNo", orderModel.getClaimDetail().getCanclExchngRtngudNo());
				rqsObj.put("userId", orderModel.getMberNo());
				Map<String, Object> resMap = httpClientHelper.postCallApi(orProperty.getFxClaimUrl(), rqsObj);

				log.debug("callFX response : "+ resMap.toString());

			} catch (Exception e) {
				log.error("callFX error : " + e);
			}
		};
		taskExecutor.execute(fxRun);
		log.debug("callFX END");
	}
	*/

	private synchronized void orderInvntryUdt(OrderModel orderModel) {
		log.debug("::: orderInvntryUdt START");
		Runnable invntryRun = () -> {
			try {
				/**
				 * BL 이력 이벤트 유형 코드
					03-주문, 04-주문취소, 11-교환입고, 12-교환주문, 13-교환출고, 14-반품입고
				 */
				String eventTyCode = "";
				// 클레임 구분
				if (StringUtils.equals(CLAIM_TY_CODE_CANCEL, orderModel.getClaimDetail().getCanclExchngRtngudTyCode())) {
					eventTyCode = "04"; //주문취소
				} else if (StringUtils.equals(CLAIM_TY_CODE_RETURN, orderModel.getClaimDetail().getCanclExchngRtngudTyCode())) {
					eventTyCode = "14"; //반품입고
				}

				int maxWeight = orderModel.getOnceSlePossWt();
				int weightUnit = orderModel.getSleUnitWt();
				// 알루미늄 01, 아연 02 분기
				if (StringUtils.equals(orderModel.getSleMthdCode(), "01")) {
					weightUnit = 1;
				}

				for (OrOrderDtlVO bl : orderModel.getOrderBlList()) {
					orderModel.setOrderBlDetail(bl);
					bl.setBlHistEventTyCode(eventTyCode);

					// 주문 번들에 맞는 이론 중량을 구하기
					Map<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO> mapVo = setMathcingValuesMap(bl, weightUnit, maxWeight, weightUnit);
					bl.setNetAvrgWt(mapVo.get(BigDecimal.valueOf(weightUnit)).getCollectLogicalWeight());

					// IT_BL_INFO_BAS
					claimMapper.updateInvntryBlInfoBas(orderModel);
					// IT_BL_INFO_HIST_DTL(화면에서 관리 하는 이력 테이블), 04-주문취소로 코드 생성
					claimMapper.insertInvntryBlInfoHistDtl(orderModel);
					// IT_BL_INFO_BAS_HST (시스템 이력)
					claimMapper.insertBlInfoBasHst(orderModel);

					// 재고 변경 플래그
					bl.setInvntryUdt(true);
				}

			} catch (Exception e) {
				log.error("::: orderInvntryUdt error : " + ExceptionUtils.getStackTrace(e));
			}
		};
		taskExecutor.execute(invntryRun);
		log.debug("::: orderInvntryUdt END");
	}

	private Map<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO> setMathcingValuesMap(
			OrOrderDtlVO bl, int minWeight, int maxWeight, int weightUnit) throws Exception {
		ItemPriceMatchingBlInfoVO vo = Optional.ofNullable(claimMapper.getItBlInfo(bl)).orElseThrow(() -> {
			log.info("ClaimServiceImpl setMathcingValuesMap line-814 vo.toString() >> " + bl.toString());
			return new CommCustomException("상품 BL 정보 기본 미존재");
		});

		return itemPriceMatchingService.setMathcingValuesMap(vo, minWeight, maxWeight, weightUnit);
	}

	private synchronized void callOms(OrderModel orderModel) {
		log.debug("::: callOms START");
		Runnable omsRun = () -> {
			try {
				// OMS 송신
				String claimNo = orderModel.getClaimDetail().getCanclExchngRtngudNo();
				String apiUrlTy = null;

				// 클레임 구분
				if (StringUtils.equals(CLAIM_TY_CODE_CANCEL, orderModel.getClaimDetail().getCanclExchngRtngudTyCode())) {
					apiUrlTy = "/2";
				} else if (StringUtils.equals(CLAIM_TY_CODE_RETURN, orderModel.getClaimDetail().getCanclExchngRtngudTyCode())) {
					apiUrlTy = "/3";
				} else if (StringUtils.equals(CLAIM_TY_CODE_EXCHANGE, orderModel.getClaimDetail().getCanclExchngRtngudTyCode())) {
					// TODO 교환은 입교, 출고 분기 필요
					apiUrlTy = "/4"; //입고
//					apiUrlTy = "/5"; //출고
				} else {
					throw new Exception("클레임 구분 확인 필요");
				}

				Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getLoOmsUrl() + "/SetleInfo/" + claimNo + apiUrlTy, null);

				log.debug("::: callOms response : "+ resObj.toString());

				if (resObj != null && resObj.get("omsOrderRceptNo") != null) {
					orderModel.setOmsRceptNo(String.valueOf(resObj.get("omsOrderRceptNo")));
					// 클레임 마스터 수정, OMS 접수번호 받기
					claimMapper.updateLastClaimMaster(orderModel);
				} else {
					throw new Exception("oms response is null or check omsRceptNo");
				}
			} catch (Exception e) {
				log.error("::: callOms error : " + ExceptionUtils.getStackTrace(e));
			}
		};
		taskExecutor.execute(omsRun);
		log.debug("::: callOms END");
	}

	/**
	 * <pre>
	 * 메일 발송
	 * </pre>
	 * @date 2021. 12. 6.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 6.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 */
	private synchronized void callMail(OrderModel orderModel) {
		log.debug("::: callMail START");
		// MAIL 수신 동의 체크는 임시 주석 -> 추후에 MAIL 수신동의 체크해야 한다고 하면 아래 주석 풀고 진행
		//if(StringUtils.equals(orderModel.getMbDlvrgBas().getMberEmailRecptnAgreAt(), "Y"))	{
			Runnable mailRun = () -> {
				try {
					MailVO mailVo = new MailVO();
					mailVo.setMailTmptSeq(16);										// 템플릿 번호 TODO 미정
					mailVo.setEmail(orderModel.getMbDlvrgBas().getMberEmail());		// 이메일 (수신자)(주문자)
					mailVo.setMailSendEmail(orderModel.getMberEmail());				// 발신자 이메일 주소 (로그인)
					mailVo.setMailSendUserId(orderModel.getMberId());				// 발신자 아이디 (로그인)
					mailVo.setMemberNo(orderModel.getMberNo());						// 회원 번호 (로그인)
					log.debug("::: mailVo : " + mailVo);

					Map<String, String> mailMap = claimMapper.selectMailInfo(orderModel);
					log.debug("::: mailMap : "+ mailMap.toString());

					mailService.insertMailSend(mailVo, mailMap);
				} catch (Exception e) {
					log.error("::: callMail error : " + ExceptionUtils.getStackTrace(e));
				}
			};
			taskExecutor.execute(mailRun);
		//}
			log.debug("::: callMail START");
	}

	/**
	 * <pre>
	 * 앱푸쉬를 호출한다.
	 * </pre>
	 * @date 2021. 12. 6.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 6.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 */
	private synchronized void callAppPush(OrderModel orderModel) {
		log.debug("::: callAppPush START");
		Runnable appPushRun = () -> {
			try {
				AppPushQueueVO appPushQueueVO = new AppPushQueueVO();
				appPushQueueVO.setMsgTitle("주문취소신청"); // TODO 메시지 제목, 여기서 넣는 것인지 모르겠지만 추가 20211221
				Map<String, String> appPushMap = claimMapper.selectSmsInfo(orderModel);
				appPushMap.put("templateNum", "16");	//OP_MSSAGE_TMPLAT_BAS 테이블 조회 번호
				if (appPushMap != null && !appPushMap.isEmpty()) {
					appPushQueueVO.setIdentify(String.valueOf(appPushMap.get("identify"))); // 운영_앱 설치 기본(OP_APP_INSTL_BAS)의 디바이스 ID(DEVICE_ID) [MBER_NO 조건으로 가져올 수 있다]
				}
				appPushMap.put("commerceNtcnCn", "[케이지트레이딩] 고객님의 주문/결제가 완료되었습니다."); // 알림 메세지

				smsService.insertAppPush(appPushQueueVO, appPushMap);
			} catch (Exception e) {
				log.error("::: callAppPush error : " + ExceptionUtils.getStackTrace(e));
			}
		};
		taskExecutor.execute(appPushRun);
		log.debug("::: callAppPush END");
	}

	/**
	 * <pre>
	 * SMS 서비스를 호출한다
	 * </pre>
	 * @date 2021. 12. 6.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 6.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 */
	private synchronized void callSms(OrderModel orderModel) {
		log.debug("::: callSms START");
		// SMS 수신 동의 체크는 임시 주석 -> 추후에 SMS 수신동의 체크해야 한다고 하면 아래 주석 풀고 진행
		//if(StringUtils.equals(orderModel.getMbDlvrgBas().getMberChrctrRecptnAgreAt(), "Y"))	{
			Runnable smsRun = () -> {
				try {
					SMSVO smsVO = new SMSVO();
					smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
					smsVO.setPhone(orderModel.getMbDlvrgBas().getMoblphonNo());
					smsVO.setCommerceNtcnAt("Y"); // 커머스 알림 여부, 20211116 추가
					smsVO.setMberNo(orderModel.getMberNo());

					Map<String, String> smsMap = claimMapper.selectSmsInfo(orderModel);
					smsMap.put("templateNum", "16");
					smsMap.put("commerceNtcnCn", "[케이지트레이딩] 취소 접수가 되었습니다.");

					smsService.insertSMS(smsVO, smsMap);
				} catch (Exception e) {
					log.error("::: callSms error : " + ExceptionUtils.getStackTrace(e));
				}
			};
			taskExecutor.execute(smsRun);
		//}
		log.debug("::: callSms END");
	}

	/**
	 * <pre>
	 * 클레임 기본 이력 등록
	 * </pre>
	 * @date 2021. 12. 6.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 6.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 */
	private synchronized void instHistory(OrderModel orderModel) {
		log.debug("::: instHistory START");
		Runnable historyRun = () -> {
			try {
				// 클레임 마스터 이력
				claimMapper.insertClaimMasterHst(orderModel);
//				// TODO 주문 디테일 (불필요)
//				orderMapper.insertOrOrderDtlHst(orderModel);
//				// TODO 배송지 (불필요)
//				orderMapper.insertOrDlvrgBasHst(orderModel);
//				// TODO 배송비 (불필요)
//				orderMapper.insertOrDlvrfBasHst(orderModel);
//				// TODO 결재 (배치로 변경 예정 )
//				orderMapper.insertEwalletSetleHist(orderModel);
			} catch (Exception e) {
				log.error("::: instHistory error : " + ExceptionUtils.getStackTrace(e));
			}
		};
		taskExecutor.execute(historyRun);
		log.debug("::: instHistory END");
	}

	private void claimFail(OrderModel orderModel) throws Exception {
		log.debug("::: claimFail START");
		orderModel.setOrderSttusCode("90"); //클레임 실패
		claimMapper.updateLastClaimMaster(orderModel);

		// 재고 원복
		if (!CollectionUtils.isEmpty(orderModel.getOrderBlList())) {
			for (OrOrderDtlVO bl : orderModel.getOrderBlList()) {
				if (bl.isInvntryUdt()) {
					orderModel.setOrderBlDetail(bl);
					claimMapper.updateRecoverInvntryBlInfoBas(orderModel);
				}
			}
		}

		// History 생성
		instHistory(orderModel);
		log.debug("::: claimFail END");
	}

	@Override
	public List<FileDocVO> selectListFileDocInfo(OrderDtlsClaimVO vo) throws Exception {
		return claimMapper.selectListFileDocInfo(vo);
	}

	@Override
	public Map<String, Object> getTaxBillInfo(OrderDtlsVO searchVo) throws Exception {
		return claimMapper.getTaxBillInfo(searchVo);
	}
}
