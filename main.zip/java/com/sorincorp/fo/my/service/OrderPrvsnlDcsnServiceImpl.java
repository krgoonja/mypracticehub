package com.sorincorp.fo.my.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.bsnInfo.model.RestTermVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.mapper.CommPrvsnlOrderMapper;
import com.sorincorp.comm.order.model.CommFtrsFshgMngVO;
import com.sorincorp.comm.order.model.CommPrvsnlDcsnInfoVO;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.comm.order.service.CommDashboardWebsocketService;
import com.sorincorp.comm.order.service.CommFrontOrderWebsocketService;
import com.sorincorp.comm.order.service.CommFtrsFshgMngService;
import com.sorincorp.comm.order.service.CommOrderService;
import com.sorincorp.comm.order.service.CommPrvsnlLimitOrderRedisPubService;
import com.sorincorp.comm.order.service.CommPrvsnlOrderService;
import com.sorincorp.comm.pcInfo.model.LmePcVO;
import com.sorincorp.comm.pcInfo.model.PrEhgtRltmVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.BsnInfoUtil;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.fo.my.mapper.OrderPrvsnlDcsnMapper;
import com.sorincorp.fo.my.model.OrderPrvsnlDcsnInfoVO;
import com.sorincorp.fo.my.model.OrderPrvsnlDcsnProcessVO;
import com.sorincorp.fo.pd.comm.constant.PdPropertyConstant;
import com.sorincorp.fo.pd.mapper.OrderMapper;
import com.sorincorp.fo.pd.model.ItemDtlInfoVO;
import com.sorincorp.fo.pd.service.OrderService;

import lombok.extern.slf4j.Slf4j;

/**
 * OrderPrvsnlDcsnServiceImpl.java
 * 단가확정하기 관련 Service 구현체 클래스
 * 
 * @version
 * @since 2024. 9. 9.
 * @author srec0049
 */
@Slf4j
@Service
public class OrderPrvsnlDcsnServiceImpl implements OrderPrvsnlDcsnService {

    /**
     * 공통 코드 서비스
     */
    @Autowired
    private CommonCodeService commonCodeService;
    
    /**
     * 공통 서비스
     */
    @Autowired
    private CommonService commonService;
    
    /**
     * 공통 채번 서비스
     */
    @Autowired
    private AssignService assignService;
    
    /**
     * 주문 스레드 풀
     */
    @Resource(name = "orderThreadPool")
    private ThreadPoolTaskExecutor taskExecutor;
    
    /**
     * 사이트 운영 설정 서비스
     */
    @Autowired
    private BsnInfoService bsnInfoService;
    
    /**
     * SMS 발송 서비스
     */
    @Autowired
    private SMSService smsService;
    
    /**
     * FO 구독 웹소켓 서비스
     */
    @Autowired
    private CommFrontOrderWebsocketService commFrontOrderWebsocketService;
    
    /**
     * 주문 BO 구독 웹소켓 서비스
     */
    @Autowired
    private CommDashboardWebsocketService commDashboardWebsocketService;
    
    /**
     * 가단가 지정가 주문 Redis Publish 공통 서비스
     */
    @Autowired
    private CommPrvsnlLimitOrderRedisPubService commPrvsnlLimitOrderRedisPubService;
    
    /**
     * 주문 공통 서비스
     */
    @Autowired
	private CommOrderService commOrderService;
    
    /**
	 * 가단가 주문 공통 서비스
	 */
	@Autowired
	private CommPrvsnlOrderService commPrvsnlOrderService;
	
    /**
     * 실시간 판매 가격 서비스
     */
    @Autowired
    private PcInfoService pcInfoService;
    
    /**
     * 선물 선물환 관리 서비스
     */
    @Autowired
    private CommFtrsFshgMngService commFtrsFshgMngService;
	
    /**
     * 프로퍼티 상수
     */
    @Autowired
    private PdPropertyConstant orProperty;
	
	/**
	 * 주문 서비스
	 */
	@Autowired
	OrderService orderService;
    
	/**
	 * 단가확정하기 관련 Mapper
	 */
	@Autowired
    private OrderPrvsnlDcsnMapper orderPrvsnlDcsnMapper;
	
	/**
	 * 가단가 주문 공통 Mapper
	 */
	@Autowired
	private CommPrvsnlOrderMapper commPrvsnlOrderMapper;
	
    /**
     * 주문 Mapper
     */
    @Autowired
    private OrderMapper orderMapper;
	
	
	/**
	 * 단가확정하기 정보 가져오기
	 */
	@Override
	public OrderPrvsnlDcsnInfoVO getOrderPrvsnlDcsnInfo(String orderNo) throws Exception {
		// 단가확정하기 정보 가져오기
		OrderPrvsnlDcsnInfoVO getOrderPrvsnlDcsnInfo = Optional.ofNullable(orderPrvsnlDcsnMapper.getOrderPrvsnlDcsnInfo(orderNo)).orElseThrow(() -> {
			return new Exception("해당 가단가 구매 주문 정보가 없습니다.");
		});
		
		// 가단가 구매 주문 여부, 판매 방식 코드가 가단가(05)인지 체크
		if(!StringUtils.equals("05", getOrderPrvsnlDcsnInfo.getSleMthdCode())) {
			throw new Exception("가단가 구매 주문이 아닙니다.");
		}
		
		OrderModel orderModel = new OrderModel();
		orderModel.setOrderNo(orderNo);
		orderModel.setOrderWt(Integer.parseInt(getOrderPrvsnlDcsnInfo.getTotRealOrderWt())); // commOrderService.couponUse을 사용하기 위한 의미 없는 값
		orderModel.setBlList(new ArrayList<ItemPriceMatchingBlInfoVO>()); // commOrderService.couponUse을 사용하기 위한 의미 없는 값
		orderModel.setDlivyRequstDe(getOrderPrvsnlDcsnInfo.getDlivyRequstDe()); // commOrderService.couponUse을 사용하기 위한 의미 없는 값
		orderModel.setSleUnitWt(1); // commOrderService.couponUse을 사용하기 위한 의미 없는 값
		long pdDscntAmount = 0L; // 상품할인 금액 (단가 할인 상품)
		
		// 사용쿠폰 리스트 조회
        if(StringUtils.equals("Y", getOrderPrvsnlDcsnInfo.getCouponApplcAt())) {
        	orderModel.setCouponList(commPrvsnlOrderMapper.selectCouponList(orderModel.getOrderNo()));
        	orderModel.setCouponDplctUseLmttQyAt("N");
        } else {
        	orderModel.setCouponList(new ArrayList<CouponVO>());
        }
        
        if(orderModel.getCouponList().size() > 0) {
	        // 쿠폰 적용 후 금액 조회
	        CouponVO couponvo = commOrderService.couponUse(orderModel, orderModel.getOrderWt(), false);
	        pdDscntAmount = couponvo.getPdDscntAmount();
        }
        
        getOrderPrvsnlDcsnInfo.setPdDscntAmount(pdDscntAmount); // 단가 할인 금액 set
        
		return getOrderPrvsnlDcsnInfo;
	}
	
	/**
	 * <pre>
	 * 처리내용: 확정 초기 데이터 설정
	 * </pre>
	 * @date 2024. 10. 10.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	public void initDcsnData(OrderModel orderModel) throws Exception {
		String dcsnSection = orderModel.getDcsnSection(); // 가단가 확정 - 구분 [lme: LME 분리확정, fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]
		
		// 가단가 확정 - 구분이 [lme: LME 분리확정, smtm: 동시확정, singl: 단일(단가)확정]일 경우
		if(StringUtils.equals("lme", dcsnSection) || StringUtils.equals("smtm", dcsnSection) || StringUtils.equals("singl", dcsnSection)) {
	        CommonCodeVO metalCodeInfo = Optional.ofNullable(commonCodeService.getCodeValueRetVo("METAL_CODE", orderModel.getMetalCode())).orElseThrow(() -> {
	            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
	            return new Exception("공통코드_메탈코드 정보가 없습니다.");
	        });
	        
	        // 판매단위중량(상품별)가져오기
	        ItemDtlInfoVO sleWtInfo = Optional.ofNullable(orderMapper.getSleWtInfo(orderModel.getItmSn())).orElseThrow(() -> {
	            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
	            return new Exception("해당 상품_아이템 정보가 없습니다.");});
	        BigDecimal sleUnitWt = Optional.ofNullable(sleWtInfo.getSleUnitWt()).orElse(BigDecimal.ZERO); // 판매 단위 중량
	        if(sleUnitWt.compareTo(BigDecimal.ZERO) == 0) {
	            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
	            throw new Exception("판매 단위 중량이 null이거나 0입니다.");
	        }
	        orderModel.setSleUnitWt(sleUnitWt.intValue() / 1000); // 판매 단위 중량 kg -> MT로 변환
	        
	        // 삼성선물 주문 타입
	        // C : 청산번호가 있으면 청산번호로 요청청산포지션번호 셋, 없으면 만기일자로 셋
	        // N : 무조건 만기일자로 셋
	        String samsungOrdertype = orProperty.getSamsungOrdertype();
	        if(StringUtils.isEmpty(samsungOrdertype) || samsungOrdertype.equals("null")) {
	            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
	            throw new Exception("선물사 주문 타입 설정이 없습니다.");
	        }
	        orderModel.setSamsungOrdertype(samsungOrdertype);

	        String samsungStockCode = metalCodeInfo.getCodeRefrnone(); // 요청 선물 종목 코드
	        if(StringUtils.isEmpty(samsungStockCode)) {
	            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
	            throw new Exception("요청 선물 종목 코드 값이 없습니다.");
	        }
	        orderModel.setSamsungStockCode(samsungStockCode); // 요청 선물 종목 코드

	        BigDecimal samsungOrderWt = Optional.ofNullable(metalCodeInfo.getCodeNumberRefrnone()).orElse(BigDecimal.ZERO); // 삼성선물 주문 단위 중량
	        if(samsungOrderWt.compareTo(BigDecimal.ZERO) == 0) {
	            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
	            throw new Exception("선물사 주문 단위 중량이 null이거나 0입니다.");
	        }
	        orderModel.setSamsungOrderWt(samsungOrderWt.intValue()); // 삼성선물 주문 단위 중량
	        
	        
	        // lme 수집 시간 간격 값
            int lmeColctTimeIntrvlVal = Optional.ofNullable(orProperty.getLmeColctTimeIntrvlVal()).orElseThrow(() -> {
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                return new Exception("lme 수집 시간 간격 값이 없습니다.");
            });
            orderModel.setLmeColctTimeIntrvlVal(lmeColctTimeIntrvlVal);
		}
		
		
		// 가단가 확정 - 구분이 [fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]일 경우
		if(StringUtils.equals("fx", dcsnSection) || StringUtils.equals("smtm", dcsnSection) || StringUtils.equals("singl", dcsnSection)) {
			orderModel.setSleUnitWt(1); // commOrderService.couponUse을 사용하기 위한 의미 없는 값
			
			// 환율 수집 시간 간격 값
            int ehgColctTimeIntrvlVal = Optional.ofNullable(orProperty.getEhgColctTimeIntrvlVal()).orElseThrow(() -> {
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                return new Exception("환율 수집 시간 간격 값이 없습니다.");
            });
            orderModel.setEhgColctTimeIntrvlVal(ehgColctTimeIntrvlVal);
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 확정 유효성 검사 및 데이터 세팅
	 * </pre>
	 * @date 2024. 10. 10.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	public void dcsnValidation(OrderModel orderModel) throws Exception {
		String dcsnSection = orderModel.getDcsnSection(); // 가단가 확정 - 구분 [lme: LME 분리확정, fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]
		String dcsnSelMthd = orderModel.getDcsnSelMthd(); // 가단가 확정 - 판매 방식 [live: 라이브, limit: 지정가]
		
		// 라이브 영업시간 리스트를 가져온다.
		List<RestTermVO> restDeLiveList = bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");
		Optional<RestTermVO> restDeLiveOp = Optional.ofNullable(restDeLiveList).orElse(Collections.emptyList())
				.stream()
				.filter(restTerm -> "N".equals(restTerm.getRestdeAt())
						&& (orderModel.getMetalCode()).equals(restTerm.getMetalCode()) 
						&& BsnInfoUtil.OperateSttusCode.OPERATE_AT.getValues().contains(restTerm.getOpenTimeCode())
				)
				.findFirst();
		
		boolean restStatus = restDeLiveOp.isPresent(); // 영업시간 체크(true: 영업시간, false: 휴일)
		
		// 금일 휴일에 따른 유효성 체크
		//log.warn(">> 금일 휴일에 따른 유효성 체크 : " + restStatus);
        if(!restStatus) {
            orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
            throw new Exception("영업시간을 확인해주세요.");
        }
        
        // 판매 방식이 터치가 아닌 지정가일 경우, 중복 체크
        if(!StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", dcsnSelMthd)) {
        	// 지정가 등록 시 [지정가 미체결(10), 지정가 주문처리중(20), 지정가 체결(30)] 중복 체크
            int chkDuplLimitOrder = 0;
            
            String dcsnSectionStr = "";
        	switch(dcsnSection) {
	            case "lme" : 
	            	dcsnSectionStr = "LME";
	            	// LME 지정가 등록 시 [지정가 미체결, 지정가 주문처리중, 지정가 체결] 중복 체크
	            	chkDuplLimitOrder = orderPrvsnlDcsnMapper.getChkDuplLmeLimitOrder(orderModel);
	            	break;
	            case "fx" : 
	            	dcsnSectionStr = "환율";
	            	// 환율 지정가 등록 시 [지정가 미체결, 지정가 주문처리중, 지정가 체결] 중복 체크
	            	chkDuplLimitOrder = orderPrvsnlDcsnMapper.getChkDuplEhgtLimitOrder(orderModel);
	            	break;
	            case "singl" : 
	            	dcsnSectionStr = "단일(단가)";
	            	// KRW 지정가 등록 시 [지정가 미체결, 지정가 주문처리중, 지정가 체결] 중복 체크
	            	chkDuplLimitOrder = orderPrvsnlDcsnMapper.getChkDuplKrwLimitOrder(orderModel);
	            	break;
            
            }
        	log.info(">> "+dcsnSectionStr+" chkDuplLimitOrder : " + chkDuplLimitOrder);
        	if(chkDuplLimitOrder > 0) {
            	throw new Exception("중복된 " + dcsnSectionStr + " 지정가 주문이 존재합니다.");
            }
        }
        
        // 휴일 영업 종료 시간 세팅
        orderModel.setApplcEndTime(restDeLiveOp.get().getApplcEndTime());
        
		// BL별 주문_주문 상세 정보로 선물과 선물환 등록에 필요한 최적의 BL 데이터 가져오기 
		List<ItemPriceMatchingBlInfoVO> getMatchedOrderedInfo = Optional.ofNullable(orderPrvsnlDcsnMapper.getMatchedOrderedInfo(orderModel.getOrderNo())).orElseThrow(() -> {
			return new Exception("해당 BL별 주문 상세 정보가 없습니다.");
		});
		orderModel.setBlList(getMatchedOrderedInfo);
		
		// 조정계수 조회
        CommFtrsFshgMngVO ftrsFshgMngVO = Optional.ofNullable(
        			commFtrsFshgMngService.commFtrsFshgManageDtlListByToday("B").stream()
        				.filter(data -> (StringUtils.equals(data.getMetalCode(), orderModel.getMetalCode())))
        				.collect(Collectors.toList()).get(0)
        ).orElseThrow(() -> {return new Exception("LME, 환율 조정계수 정보가 없습니다.");});
        
        
        // 지정가 터치가 아닐 경우, 실시간 판매 가격 정보 세팅
     	if(!StringUtils.equals("touch", orderModel.getLimitSection())) {
     		PrSelVO prSelVO = new PrSelVO();
     		
     		// 가단가 확정 - 구분이 [lme: LME 분리확정, smtm: 동시확정, singl: 단일(단가)확정]일 경우
            if(StringUtils.equals("lme", dcsnSection) || StringUtils.equals("smtm", dcsnSection) || StringUtils.equals("singl", dcsnSection)) {
            	// 가단가 확정 - 판매 방식이 라이브이거나 터치가 아닌 지정가일 경우, 구분에 따른 가격 정보 조회 및 체크
                if( StringUtils.equals("live", dcsnSelMthd) || (!StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", dcsnSelMthd)) ) {
                	// 실시간 LME 가격 정보 조회 및 체크 (조정된 테이블이 아닌 LME 가격 데이터를 가져온다, 여기서 3M 값으로 선물 진행)
                	LmePcVO lmePcVO = Optional.ofNullable(pcInfoService.getNewestPrLmeRltm(orderModel.getMetalCode(), DateUtil.getNowDateTime("yyyyMMdd"))).orElseThrow(() -> {
                        return new Exception("실시간 LME 가격 정보 미존재");
                    });
                    
            		prSelVO.setLmePcRltmSn(lmePcVO.getLmePcRltmSn()); // LME 가격 실시간 순번
            		prSelVO.setLmePc(lmePcVO.getEndPc()); // LME 현금
            		prSelVO.setLmeMdatCffcnt(ftrsFshgMngVO.getLmeMdatCffcntAmount()); // LME 조정 계수
            		prSelVO.setThreemonthLmePc(lmePcVO.getThreemonthEndPc()); // LME 3M
                }
            }
            
            // 가단가 확정 - 구분이 [fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]일 경우
         	if(StringUtils.equals("fx", dcsnSection) || StringUtils.equals("smtm", dcsnSection) || StringUtils.equals("singl", dcsnSection)) {
         		// 가단가 확정 - 판매 방식이 라이브이거나 터치가 아닌 지정가일 경우, 구분에 따른 가격 정보 조회 및 체크
                if( StringUtils.equals("live", dcsnSelMthd) || (!StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", dcsnSelMthd)) ) {
                	// 실시간 환율 가격 정보 조회 및 체크
                	PrEhgtRltmVO prEhgtRltmVO = Optional.ofNullable(pcInfoService.getNewestPrEhgtRltm("SPTUSD/KRW")).orElseThrow(() -> {
                        return new Exception("실시간 환율 가격 정보 미존재");
                    });
                    
            		prSelVO.setEhgtPcRltmSn(prEhgtRltmVO.getEhgtPcRltmSn()); // 환율 가격 실시간 순번
            		prSelVO.setEhgtPc(prEhgtRltmVO.getEndPc()); // 현물환
            		prSelVO.setFxMdatCffcnt(ftrsFshgMngVO.getEhgtMdatCffcntAmount()); // 현물환 조정 계수
                }
         	}
         	
         	// 가단가 확정 - 구분이 [singl: 단일(단가)확정]일 경우
         	if(StringUtils.equals("singl", dcsnSection)) {
         		// 가단가 확정 - 판매 방식이 라이브이거나 터치가 아닌 지정가일 경우, 구분에 따른 가격 정보 조회 및 체크
                if( StringUtils.equals("live", dcsnSelMthd) || (!StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", dcsnSelMthd)) ) {
                	// 실시간 판매 가격 정보 조회 및 체크
                	prSelVO = Optional.ofNullable(pcInfoService.getNewestPrSelRltm(orderModel.getMetalCode(), orderModel.getItmSn(), orderModel.getDstrctLclsfCode(), orderModel.getBrandGroupCode(), orderModel.getRealBrandCode(), DateUtil.getNowDateTime("yyyyMMdd"))).orElseThrow(() -> {
                        return new Exception("실시간 판매가격 정보 미존재");
                    });
                }
         	}
     		
         	// 실시간 판매 가격 정보 SET
         	orderModel.setPrSelVO(prSelVO);
     	}
        
        // 가단가 확정 - 구분이 [lme: LME 분리확정, smtm: 동시확정, singl: 단일(단가)확정]일 경우
        if(StringUtils.equals("lme", dcsnSection) || StringUtils.equals("smtm", dcsnSection) || StringUtils.equals("singl", dcsnSection)) {
        	// LME 사이드카 발동여부 (지정가일 경우 추가, 20230510)(가단가일 경우 추가, 20240911)
            if(orderMapper.chkLmeSidecar(orderModel) > 0 ) {
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new Exception("사이드카[LME] 발동");
            }
        }
        
        // 가단가 확정 - 구분이 [fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]일 경우
     	if(StringUtils.equals("fx", dcsnSection) || StringUtils.equals("smtm", dcsnSection) || StringUtils.equals("singl", dcsnSection)) {
     		// 환율 사이드카 발동여부 (지정가일 경우 추가, 20230510)
            if(orderMapper.chkFxSidecar(orderModel) > 0 ) {
                orderModel.setLimitOrderSttusCode("94"); // 지정가 주문 상태 코드[94(체결실패(유효성 검사 실패))] set
                throw new Exception("사이드카[환율] 발동");
            }
     	}
     	
     	// 가단가 확정 - 구분이 [lme: LME 분리확정, smtm: 동시확정, singl: 단일(단가)확정]일 경우
 		if(StringUtils.equals("lme", dcsnSection) || StringUtils.equals("smtm", dcsnSection) || StringUtils.equals("singl", dcsnSection)) {
 			// 선물 SKIP 여부, 선물 틱 설정 값 등 정보 조회
            BigDecimal threemonthLmePc = Optional.ofNullable(orderModel.getPrSelVO().getThreemonthLmePc()).orElse(BigDecimal.ZERO); // 3개월 LME 가격(3M 가격)
            orderModel.setCommFtrsFshgMngVO(Optional.ofNullable(commFtrsFshgMngService.getFtrsFshgMngRetVo(orderModel.getMetalCode(), "B", threemonthLmePc)).orElseThrow(() -> {return new Exception("선물 SKIP 여부, 선물 틱 설정 값 등 정보 미존재");}));
            log.warn(">> 실시간 판매 가격 정보 조회 (선물 SKIP 여부, 선물 틱 설정 값 등 정보 조회) orderModel.getCommFtrsFshgMngVO() : " + orderModel.getCommFtrsFshgMngVO());
 		}
 		
     	// 지정가 터치가 아닐 경우, [LME, FX] 순번 값 체크 및 [LME, FX] 수집 시간 간격 체크
     	if(!StringUtils.equals("touch", orderModel.getLimitSection())) {
     		long currentTime = System.currentTimeMillis();
            //log.warn(">> currentTime : " + currentTime);
            SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyyMMddHHmmss");
            
     		// 가단가 확정 - 구분이 [lme: LME 분리확정, smtm: 동시확정, singl: 단일(단가)확정]일 경우
     		if(StringUtils.equals("lme", dcsnSection) || StringUtils.equals("smtm", dcsnSection) || StringUtils.equals("singl", dcsnSection)) {
     			String lmePcRltmSn = orderModel.getPrSelVO().getLmePcRltmSn();
     			
     			// LME 순번 값 체크 및 LME 수집 시간 간격 체크
                if(StringUtils.isEmpty(lmePcRltmSn)) {
                    throw new Exception("[1]현재 일시적인 문제로 주문 및 시세 제공이 불가능합니다,\n관리자에게 문의 바랍니다.");
                } else {
                    Date lmeDate = dateTimeFormat.parse(lmePcRltmSn.substring(0, 14));
                    long lmeTime = lmeDate.getTime();
                    //log.warn(">> lmeTime calc : " + lmeTime + ", " + (currentTime - lmeTime) + ", " + orderModel.getLmeColctTimeIntrvlVal());
                    if((currentTime - lmeTime) > (orderModel.getLmeColctTimeIntrvlVal()*1000)) {
                        throw new Exception("[2]현재 일시적인 문제로 주문 및 시세 제공이 불가능합니다,\n관리자에게 문의 바랍니다.");
                    }
                }
     		}
     		
     		if(StringUtils.equals("fx", dcsnSection) || StringUtils.equals("smtm", dcsnSection) || StringUtils.equals("singl", dcsnSection)) {
     			String ehgtPcRltmSn = orderModel.getPrSelVO().getEhgtPcRltmSn();
     			
     			// 환률 순번 값 체크 및 환률 수집 시간 간격 체크
                if(StringUtils.isEmpty(ehgtPcRltmSn)) {
                    throw new Exception("[3]현재 일시적인 문제로 주문 및 시세 제공이 불가능합니다,\n관리자에게 문의 바랍니다.");
                } else {
                    Date ehgtDate = dateTimeFormat.parse(ehgtPcRltmSn.substring(0, 14));
                    long ehgtTime = ehgtDate.getTime();
                    //log.warn(">> ehgtTime calc : " + ehgtTime + ", " + (currentTime - ehgtTime) + ", " + orderModel.getEhgColctTimeIntrvlVal());
                    if((currentTime - ehgtTime) > (orderModel.getEhgColctTimeIntrvlVal()*1000)) {
                        throw new Exception("[4]현재 일시적인 문제로 주문 및 시세 제공이 불가능합니다,\n관리자에게 문의 바랍니다.");
                    }
                }
     		}
     	}
     	
     	// LME 마크업 설정 값
    	String lmeMarkUpAt = orderMapper.selectLmeMarkUpAt();
    	orderModel.setLmeMarkUpAt(lmeMarkUpAt);
    	if(StringUtils.equals(lmeMarkUpAt, "Y")) {
    		BigDecimal gainValue = orderMapper.selectGainValue();
			orderModel.setGainValue(gainValue);
    	}
	}
	
	/**
	 * 가단가 확정 처리
	 */
	@Override
	public void procPrvsnlDcsn(OrderModel orderModel) throws Exception {
		String dcsnSection = orderModel.getDcsnSection(); // 가단가 확정 - 구분 [lme: LME 분리확정, fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]
		String dcsnSelMthd = orderModel.getDcsnSelMthd(); // 가단가 확정 - 판매 방식 [live: 라이브, limit: 지정가]
		
		// 확정 초기 데이터 설정
		this.initDcsnData(orderModel);
		
		// 확정 유효성 검사 및 데이터 세팅
		this.dcsnValidation(orderModel);
		
		// 가단가 확정 - 구분이 [lme: LME 분리확정, smtm: 동시확정, singl: 단일(단가)확정]일 경우
		if(StringUtils.equals("lme", dcsnSection) || StringUtils.equals("smtm", dcsnSection) || StringUtils.equals("singl", dcsnSection)) {
			// 가단가 확정 - 판매 방식이 라이브이거나 판매 방식이 지정가이고 터치된 후일 경우 선물 호출
			if(StringUtils.equals("live", dcsnSelMthd) || (StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", dcsnSelMthd))) {
				if(orderModel.getBlList() == null || orderModel.getBlList().size() == 0) {
					// BL별 주문_주문 상세 정보로 선물과 선물환 등록에 필요한 최적의 BL 데이터 가져오기 
					List<ItemPriceMatchingBlInfoVO> getMatchedOrderedInfo = Optional.ofNullable(orderPrvsnlDcsnMapper.getMatchedOrderedInfo(orderModel.getOrderNo())).orElseThrow(() -> {
						return new Exception("해당 BL별 주문 상세 정보가 없습니다.");
					});
					orderModel.setBlList(getMatchedOrderedInfo);
				}
				
				// 실시간 가격일시 선물 호출
	            orderService.callSamsung(orderModel);
			}
		}
		
		if(StringUtils.equals("live", dcsnSelMthd) || (StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", dcsnSelMthd))) {
			// 가단가 확정 - 판매 방식이 라이브이거나 판매 방식이 지정가이고 터치된 후일 경우
			
			// 가단가 확정 - 구분이 [fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]일 경우
			if(StringUtils.equals("fx", dcsnSection) || StringUtils.equals("smtm", dcsnSection) || StringUtils.equals("singl", dcsnSection)) {
				// 가단가 확정 - 판매 방식 [live: 라이브, limit: 지정가]이 지정가이고 터치된 후일 경우
	        	if(StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", orderModel.getDcsnSelMthd())) {
	        		orderModel.setLimitOrderSttusCode("30"); // 지정가 체결(30)
	        		// 가단가-지정가 터치된 주문 체결 처리
	        		orderService.procLimitOrderCnclsByPrvsnl(orderModel);
	        	}
			}
			
			// 판매 방식이 라이브이고 구분이 singl(단일(단가)확정)일 경우 상품 단가를 계산한다 (OR_ORDER_BAS의 상품 단가에 넣어주기 위함)
			if(StringUtils.equals("live", dcsnSelMthd) && StringUtils.equals("singl", dcsnSection)) {
				// 상품 단가 계산 [프리미엄 제외 종료 가격 + 프리미엄 - 등급 할인 금액 - 단가 할인 금액]
				long calcGoodsUntpc = orderModel.getPrSelVO().getNonPremiumEndPc() + orderModel.getPremiumPc().longValue() - orderModel.getGradApplcAmount() - orderModel.getPdDscntAmount();
				//log.info(">> 판매방식 라이브, 구분 단일(단가)확정일 경우 단가 계산 : " + calcGoodsUntpc + ", orderModel : " + orderModel.toString());
				orderModel.setGoodsUntpc(calcGoodsUntpc); // 상품 단가 set
			}
			
			// 해당 가단가 확정 - 구분[lme: LME 분리확정, fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]에 따른 주문_주문 기본 데이터 변경
			orderPrvsnlDcsnMapper.updateOrOrderBasByDcsnSection(orderModel);
			
			// 단가 확정 및 정산 프로세스 실행
			commPrvsnlOrderService.executeUntpcDcsnExcclcProcess(orderModel);
			
			// OR_ORDER_BAS(주문_주문 기본) 이력 등록 (단가 확정 및 정산 프로세스 실행 메소드 수행 상관 없이 이력 등록)
			commonService.insertTableHistory("OR_ORDER_BAS", Collections.singletonMap("ORDER_NO", orderModel.getOrderNo()));
			
			// 라이브 주문정보 websocket publish, BO 대시보드의 가단가 미확정 리스트 갱신을 위한 발행
			this.callBoDashBoard(orderModel);
			
			// 가단가 구매 확정 SMS 호출
			callPrvsnlDcsnSms(orderModel);
		} else if((!StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", dcsnSelMthd))) {
			// 가단가 확정 - 판매 방식이 지정가이고 터치 전일 경우
			
			// 각 지정가 등록 및 단가 확정, Redis에 메시지 발행
			switch(dcsnSection) {
				case "lme" : 
					// 지정가 LME 주문 번호 채번
			        orderModel.setLimitLmeOrderNo(DateUtil.getNowDate()+ "-F" + assignService.selectAssignValue("OR", "LIMIT_LME_ORDER_NO", DateUtil.calDate("yyyy"), orderModel.getMberNo(), 5));
			        // 주문_지정가 주문 LME 기본 테이블 등록
			        orderPrvsnlDcsnMapper.insertOrLimitLmeOrderBas(orderModel);
			        
			        // OR_LIMIT_ORDER_LME_BAS(주문_지정가 주문 LME 기본) 이력 등록
					commonService.insertTableHistory("OR_LIMIT_ORDER_LME_BAS", Collections.singletonMap("LIMIT_ORDER_NO", orderModel.getLimitLmeOrderNo()));
			        
					// LME/KRW - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
					commPrvsnlLimitOrderRedisPubService.prvsnlLimitOrderMsgLmePublish(orderModel.getLimitLmeOrderNo(), "I");
					break;
				case "fx" : 
					// 지정가 환율 주문 번호 채번
					orderModel.setLimitEhgtOrderNo(DateUtil.getNowDate()+ "-X" + assignService.selectAssignValue("OR", "LIMIT_EHGT_ORDER_NO", DateUtil.calDate("yyyy"), orderModel.getMberNo(), 5));
			        // 주문_지정가 주문 환율 기본 테이블 등록
					orderPrvsnlDcsnMapper.insertOrLimitEhgtOrderBas(orderModel);
					
					// OR_LIMIT_ORDER_EHGT_BAS(주문_지정가 주문 환율 기본) 이력 등록
					commonService.insertTableHistory("OR_LIMIT_ORDER_EHGT_BAS", Collections.singletonMap("LIMIT_ORDER_NO", orderModel.getLimitEhgtOrderNo()));
			        
					// FX - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
					commPrvsnlLimitOrderRedisPubService.prvsnlLimitOrderMsgFxPublish(orderModel.getLimitEhgtOrderNo(), "I");
					break;
				case "singl" : 
					// 지정가 KRW 주문 번호 채번
					orderModel.setLimitKrwOrderNo(DateUtil.getNowDate()+ "-R" + assignService.selectAssignValue("OR", "LIMIT_KRW_ORDER_NO", DateUtil.calDate("yyyy"), orderModel.getMberNo(), 5));
			        // 주문_지정가 주문 KRW 기본 테이블 등록
					orderPrvsnlDcsnMapper.insertOrLimitKrwOrderBas(orderModel);
					
					// OR_LIMIT_ORDER_KRW_BAS(주문_지정가 주문 KRW 기본) 이력 등록
					commonService.insertTableHistory("OR_LIMIT_ORDER_KRW_BAS", Collections.singletonMap("LIMIT_ORDER_NO", orderModel.getLimitEhgtOrderNo()));
			        
					// LME/KRW - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
					commPrvsnlLimitOrderRedisPubService.prvsnlLimitOrderMsgLmePublish(orderModel.getLimitKrwOrderNo(), "I");
					break;
			}
		}
		
		// 가단가 확정 - 구분이 [fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]일 경우
		if(StringUtils.equals("fx", dcsnSection) || StringUtils.equals("smtm", dcsnSection) || StringUtils.equals("singl", dcsnSection)) {
			// 가단가 확정 - 판매 방식이 라이브이거나 판매 방식이 지정가이고 터치된 후일 경우 선물환 호출
			if(StringUtils.equals("live", dcsnSelMthd) || (StringUtils.equals("touch", orderModel.getLimitSection()) && StringUtils.equals("limit", dcsnSelMthd)) ) {
				if(orderModel.getBlList() == null || orderModel.getBlList().size() == 0) {
					// BL별 주문_주문 상세 정보로 선물과 선물환 등록에 필요한 최적의 BL 데이터 가져오기 
					List<ItemPriceMatchingBlInfoVO> getMatchedOrderedInfo = Optional.ofNullable(orderPrvsnlDcsnMapper.getMatchedOrderedInfo(orderModel.getOrderNo())).orElseThrow(() -> {
						return new Exception("해당 BL별 주문 상세 정보가 없습니다.");
					});
					orderModel.setBlList(getMatchedOrderedInfo);
				}
				
				// 외부 하나은행 FX를 호출
				orderService.extrlCallFx(orderModel);
			}
		}
		
		//log.info(">> registPrvsnlDcsnProcess orderModel : " + orderModel.toString());
	}
	
	/**
	 * <pre>
	 * 처리내용: 라이브 주문정보 websocket publish, BO 대시보드의 가단가 미확정 리스트 갱신을 위한 발행
	 * </pre>
	 * @date 2024. 10. 29.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 29.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 */
	private void callBoDashBoard(OrderModel orderModel) {
		Runnable dashboardRun = () -> {
            try {
                // 라이브 주문정보 websocket publish, BO 대시보드의 가단가 미확정 리스트 갱신을 위한 발행
                commDashboardWebsocketService.publishLiveOrder(orderModel.getOrderNo(), true);
            } catch (Exception e) {
                log.error("[OrderPrvsnlDcsnServiceImpl][callBoDashBoard] " + ExceptionUtils.getStackTrace(e));
            }
        };
        taskExecutor.execute(dashboardRun);
	}
	
	/**
	 * <pre>
	 * 처리내용: 가단가 구매 확정 SMS 호출
	 * </pre>
	 * @date 2024. 10. 17.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 17.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 */
	private void callPrvsnlDcsnSms(OrderModel orderModel) {
		Runnable smsRun = () -> {
			try {
				// 가단가 구매 확정 SMS 내용 정보 가져오기
				Map<String, String> smsMap = orderPrvsnlDcsnMapper.selectPrvsnlDcsnSmsInfo(orderModel);
				
				boolean goodsUntpcStatus = false; // 상품 단가 존재 상태 (true : 상품 단가 존재)
				String goodsUntpc = String.valueOf(smsMap.get("goodsUntpc")); // 상품 단가
	            if(StringUtils.isNotEmpty(goodsUntpc) && !goodsUntpc.equals("null")) {
	            	goodsUntpcStatus = true;
	            }
				
				String dcsnPhrase = ""; // 확정 문구
				String dcsnSection = orderModel.getDcsnSection(); // 가단가 확정 - 구분 [lme: LME 분리확정, fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]
				
				smsMap.put("templateNum", "150"); // 템플릿 번호
				
				// 확정 단가 동적 영역
	            StringBuilder dcsnArea = new StringBuilder();
	            
	            switch(dcsnSection) {
					case "lme" : 
						dcsnPhrase = "LME가 확정 되었습니다."; // 확정 문구
						dcsnArea.append("LME : ").append(String.valueOf(smsMap.get("lmePc"))).append(System.lineSeparator()); // LME 확정 단가
						if(goodsUntpcStatus) {
							dcsnArea.append("환율 : ").append(String.valueOf(smsMap.get("ehgtPc"))).append(System.lineSeparator()); // 환율 가격
							dcsnArea.append("프리미엄 : ").append(String.valueOf(smsMap.get("premiumPc"))).append(System.lineSeparator()); // 프리미엄
							dcsnArea.append("확정단가 : ").append(String.valueOf(smsMap.get("goodsUntpc"))).append(System.lineSeparator()); // 확정 단가
						} else {
							dcsnArea.append("환율 : ").append("미확정").append(System.lineSeparator()); // 환율 가격
							dcsnArea.append("프리미엄 : ").append(String.valueOf(smsMap.get("premiumPc"))).append(System.lineSeparator()); // 프리미엄
							dcsnArea.append("확정단가 : ").append("미확정").append(System.lineSeparator()); // 확정 단가
						}
						break;
					case "fx" : 
						dcsnPhrase = "환율이 확정 되었습니다."; // 확정 문구
						if(goodsUntpcStatus) {
							dcsnArea.append("LME : ").append(String.valueOf(smsMap.get("lmePc"))).append(System.lineSeparator()); // LME 확정 단가
							dcsnArea.append("환율 : ").append(String.valueOf(smsMap.get("ehgtPc"))).append(System.lineSeparator()); // 환율 가격
							dcsnArea.append("프리미엄 : ").append(String.valueOf(smsMap.get("premiumPc"))).append(System.lineSeparator()); // 프리미엄
							dcsnArea.append("확정단가 : ").append(String.valueOf(smsMap.get("goodsUntpc"))).append(System.lineSeparator()); // 확정 단가
						} else {
							dcsnArea.append("LME : ").append("미확정").append(System.lineSeparator()); // LME 확정 단가
							dcsnArea.append("환율 : ").append(String.valueOf(smsMap.get("ehgtPc"))).append(System.lineSeparator()); // 환율 가격
							dcsnArea.append("프리미엄 : ").append(String.valueOf(smsMap.get("premiumPc"))).append(System.lineSeparator()); // 프리미엄
							dcsnArea.append("확정단가 : ").append("미확정").append(System.lineSeparator()); // 확정 단가
						}
						break;
					case "smtm" : 
						dcsnPhrase = "LME/환율이 확정 되었습니다."; // 확정 문구
						dcsnArea.append("LME : ").append(String.valueOf(smsMap.get("lmePc"))).append(System.lineSeparator()); // LME 가격
						dcsnArea.append("환율 : ").append(String.valueOf(smsMap.get("ehgtPc"))).append(System.lineSeparator()); // 환율 가격
						dcsnArea.append("프리미엄 : ").append(String.valueOf(smsMap.get("premiumPc"))).append(System.lineSeparator()); // 프리미엄
						dcsnArea.append("확정단가 : ").append(String.valueOf(smsMap.get("goodsUntpc"))).append(System.lineSeparator()); // 확정 단가
						break;
					case "singl" : 
						dcsnPhrase = "원화단가가 확정 되었습니다."; // 확정 문구
						dcsnArea.append("원화단가 : ").append(String.valueOf(smsMap.get("goodsUntpc"))).append(System.lineSeparator()); // 원화 단가
						dcsnArea.append("프리미엄 : ").append(String.valueOf(smsMap.get("premiumPc"))).append(System.lineSeparator()); // 프리미엄
						dcsnArea.append("확정단가 : ").append(String.valueOf(smsMap.get("goodsUntpc"))).append(System.lineSeparator()); // 확정 단가
						break;
				}
	            
	            smsMap.put("dcsnPhrase", dcsnPhrase); // 확정 문구
	            
	            smsMap.put("dcsnArea", dcsnArea.toString()); // 확정 단가 동적 영역
	            dcsnArea = null; // StringBuilder 메모리 해제 유도
	            
	            Map<String, CommonCodeVO> csTelNo = commonCodeService.getSubCodesRetVo("SORIN_SETUP_CODE", "CS_TEL");
	            smsMap.put("csTelNo", csTelNo.get("CS_TEL").getCodeDcone()); // 고객센터번호
				
				SMSVO smsVO = new SMSVO();
	            smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
	            smsVO.setMberNo(String.valueOf(smsMap.get("mberNo"))); // 회원 번호
	            
	            String phone = String.valueOf(smsMap.get("ordrrMoblphonNo"));
	            if(StringUtils.isNotEmpty(phone) && !phone.equals("null")) {
	                try {
	                    log.debug("휴대전화 번호 복호화 전 ==================>" + phone);
	                    phone = CryptoUtil.decryptAES256(phone);
	                    log.debug("휴대전화 번호 복호화 후 ==================>" + phone);
	                    /** 휴대전화 번호 셋팅 **/
	                    smsVO.setPhone(phone);
	                } catch(Exception e) {
	                    log.error("OrderPrvsnlDcsnServiceImpl callPrvsnlDcsnSms ORDRR_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
	                }
	            }
	            
	            // SMS 또는 LMS 발송 및 알림톡 발송
	            smsService.insertSMS(smsVO, smsMap);
				
			} catch(Exception e) {
				log.error("[OrderPrvsnlDcsnServiceImpl][callPrvsnlDcsnSms] " + ExceptionUtils.getStackTrace(e));
			}
		};
        taskExecutor.execute(smsRun);
	}
	
	/**
	 * 구분 및 판매 방식, 상태 코드에 따른 확정 [라이브, 지정가] 등록 진행
	 */
	@Override
	public OrderPrvsnlDcsnProcessVO registPrvsnlDcsnProcess(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO) throws Exception {
		if(!StringUtils.equals("I", orderPrvsnlDcsnProcessVO.getSttusCode())) {
			throw new Exception("가단가 확정 등록 코드가 아닙니다.");
		}
		
		OrderModel orderModel = new OrderModel();
		orderModel.setOrderNo(orderPrvsnlDcsnProcessVO.getOrderNo()); // 주문 번호
		orderModel.setMberNo(orderPrvsnlDcsnProcessVO.getMberNo()); // 회원 번호
		orderModel.setMberId(orderPrvsnlDcsnProcessVO.getMberId()); // 회원 ID
		orderModel.setDcsnSection(orderPrvsnlDcsnProcessVO.getSection()); // 가단가 확정 - 구분 [lme: LME 분리확정, fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]
		orderModel.setDcsnSelMthd(orderPrvsnlDcsnProcessVO.getSelMthd()); // 가단가 확정 - 판매 방식 [live: 라이브, limit: 지정가]
		orderModel.setLimitSection(null); // 지정가 구분 [가격 도달 시 진행되는 주문: touch, 그 외: null]
		orderModel.setCstmrLmePcRltmSn(orderPrvsnlDcsnProcessVO.getLmePcRltmSn()); // 고객 LME 가격 실시간 순번
		orderModel.setCstmrEhgtPcRltmSn(orderPrvsnlDcsnProcessVO.getEhgtPcRltmSn()); // 고객 환율 가격 실시간 순번
		orderModel.setCstmrSlePcRltmSn(orderPrvsnlDcsnProcessVO.getSlePcRltmSn()); // 고객 판매 가격 실시간 순번
		orderModel.setLimitLmeInputAmount(orderPrvsnlDcsnProcessVO.getLimitLmeInputAmount()); // 지정가 LME 입력 금액
		orderModel.setLimitEhgtInputAmount(orderPrvsnlDcsnProcessVO.getLimitEhgtInputAmount()); // 지정가 환율 입력 금액
		orderModel.setLimitKrwInputAmount(orderPrvsnlDcsnProcessVO.getLimitKrwInputAmount()); // 지정가 KRW 입력 금액
		orderModel.setLimitLmeOrderValidDe(orderPrvsnlDcsnProcessVO.getLimitLmeOrderValidDe()); // 지정가 LME 주문 유효 일자
		orderModel.setLimitEhgtOrderValidDe(orderPrvsnlDcsnProcessVO.getLimitEhgtOrderValidDe()); // 지정가 환율 주문 유효 일자
		orderModel.setLimitKrwOrderValidDe(orderPrvsnlDcsnProcessVO.getLimitKrwOrderValidDe()); // 지정가 KRW 주문 유효 일자
		
		// 단가확정하기 정보 가져오기
		OrderPrvsnlDcsnInfoVO getOrderPrvsnlDcsnInfo = this.getOrderPrvsnlDcsnInfo(orderModel.getOrderNo());
		
		orderModel.setEntrpsNo(getOrderPrvsnlDcsnInfo.getEntrpsNo()); // 업체 번호
		orderModel.setMetalCode(getOrderPrvsnlDcsnInfo.getMetalCode()); // 금속 코드
		orderModel.setSleMthdCode(getOrderPrvsnlDcsnInfo.getSleMthdCode()); // 판매 방식 코드 - 가단가구매(05)
		orderModel.setItmSn(getOrderPrvsnlDcsnInfo.getItmSn()); // 아이템 순번
		orderModel.setDstrctLclsfCode(getOrderPrvsnlDcsnInfo.getDstrctLclsfCode()); // 권역 대분류 코드
		orderModel.setBrandGroupCode(getOrderPrvsnlDcsnInfo.getBrandGroupCode()); // 브랜드 그룹 코드
		orderModel.setRealBrandCode(getOrderPrvsnlDcsnInfo.getBrandCode()); // 브랜드 코드
		orderModel.setOrderWt(Integer.parseInt(getOrderPrvsnlDcsnInfo.getTotRealOrderWt())); // 주문 중량 (총 실제 주문 중량)
		orderModel.setPremiumPc(getOrderPrvsnlDcsnInfo.getPremiumPc()); // 프리미엄 가격
		orderModel.setDlvyMnCode(getOrderPrvsnlDcsnInfo.getDlvyMnCode()); // 배송 수단 코드
		orderModel.setDlivyRequstDe(getOrderPrvsnlDcsnInfo.getDlivyRequstDe()); // 출고 요청 일자
		orderModel.setDlvrgNo(getOrderPrvsnlDcsnInfo.getOrderDlvrgNo()); // 주문 배송지 번호
		orderModel.setWtChange(getOrderPrvsnlDcsnInfo.getWtChange()); // 중량 변동
		orderModel.setGradApplcAmount(getOrderPrvsnlDcsnInfo.getGradApplcAmount()); // 등급 할인 금액
		orderModel.setPdDscntAmount(getOrderPrvsnlDcsnInfo.getPdDscntAmount()); // 단가 할인 금액
		orderModel.setCouponApplcAt(getOrderPrvsnlDcsnInfo.getCouponApplcAt()); // 쿠폰 적용 여부
		
		// 가단가 확정 처리
		this.procPrvsnlDcsn(orderModel);
		
		//log.info(">> registPrvsnlDcsnProcess orderModel1 : " + orderModel.toString());
		
		
		// 단가확정하기 정보 및 주문 번호에 대한 공통 가단가 확정 여부 정보 가져오기, 구분 및 판매 방식, 상태 코드에 따른 등록, 수정, 취소 진행 후 정보 가져오기
		this.getOrderPrvsnlDcsnProcessInfo(orderPrvsnlDcsnProcessVO);
		// 가단가 확정하기 정보 websocket publish, FO에 해당 확정 여부 전파 전달 (SimpMessagingTemplate) [확정, 체결, 수정, 취소] 모두 대상
		this.websocketPublishPrvsnlDcsnSimpMsg(orderPrvsnlDcsnProcessVO);
        
        return orderPrvsnlDcsnProcessVO;
	}
	
	/**
	 * 구분 및 판매 방식, 상태 코드에 따른 지정가 수정 진행
	 */
	@Override
	public OrderPrvsnlDcsnProcessVO updatePrvsnlDcsnProcess(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO) throws Exception {
		if(!StringUtils.equals("U", orderPrvsnlDcsnProcessVO.getSttusCode())) {
			throw new Exception("지정가 수정 코드가 아닙니다.");
		}
		
		// 라이브 영업시간 리스트를 가져온다.
		List<RestTermVO> restDeLiveList = bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");
		Optional<RestTermVO> restDeLiveOp = Optional.ofNullable(restDeLiveList).orElse(Collections.emptyList())
				.stream()
				.filter(restTerm -> "N".equals(restTerm.getRestdeAt())
						&& (orderPrvsnlDcsnProcessVO.getMetalCode()).equals(restTerm.getMetalCode()) 
						&& BsnInfoUtil.OperateSttusCode.OPERATE_AT.getValues().contains(restTerm.getOpenTimeCode())
				)
				.findFirst();
		
		boolean restStatus = restDeLiveOp.isPresent(); // 영업시간 체크(true: 영업시간, false: 휴일)
		
		// 금일 휴일에 따른 유효성 체크
		//log.warn(">> 금일 휴일에 따른 유효성 체크 : " + restStatus);
        if(!restStatus) {
            throw new Exception("영업시간을 확인해주세요.");
        }
		
		//log.info(">> orderPrvsnlDcsnProcessVO updatePrvsnlDcsnProcess : " + orderPrvsnlDcsnProcessVO.toString());
		String section = orderPrvsnlDcsnProcessVO.getSection(); // 구분 [lme: LME 분리확정, fx: FX 분리확정, singl: 단일확정, smtm: 동시확정]
		switch(section) {
			case "lme" : 
				// 주문_지정가 주문 LME 기본 테이블 변경
				orderPrvsnlDcsnMapper.updateOrLimitLmeOrderBas(orderPrvsnlDcsnProcessVO);
				
				// LME/KRW - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
				commPrvsnlLimitOrderRedisPubService.prvsnlLimitOrderMsgLmePublish(orderPrvsnlDcsnProcessVO.getLimitLmeOrderNo(), "U");
				break;
			case "fx" : 
				// 주문_지정가 주문 환율 기본 테이블 변경
				orderPrvsnlDcsnMapper.updateOrLimitEhgtOrderBas(orderPrvsnlDcsnProcessVO);
				
				// FX - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
				commPrvsnlLimitOrderRedisPubService.prvsnlLimitOrderMsgFxPublish(orderPrvsnlDcsnProcessVO.getLimitEhgtOrderNo(), "U");
				break;
			case "singl" : 
				// 주문_지정가 주문 KRW 기본 테이블 변경
				orderPrvsnlDcsnMapper.updateOrLimitKrwOrderBas(orderPrvsnlDcsnProcessVO);
				
				// LME/KRW - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
				commPrvsnlLimitOrderRedisPubService.prvsnlLimitOrderMsgLmePublish(orderPrvsnlDcsnProcessVO.getLimitKrwOrderNo(), "U");
				break;
		}
		
		// 단가확정하기 정보 및 주문 번호에 대한 공통 가단가 확정 여부 정보 가져오기, 구분 및 판매 방식, 상태 코드에 따른 등록, 수정, 취소 진행 후 정보 가져오기
		this.getOrderPrvsnlDcsnProcessInfo(orderPrvsnlDcsnProcessVO);
		// 가단가 확정하기 정보 websocket publish, FO에 해당 확정 여부 전파 전달 (SimpMessagingTemplate) [확정, 체결, 수정, 취소] 모두 대상
		this.websocketPublishPrvsnlDcsnSimpMsg(orderPrvsnlDcsnProcessVO);
		
		return orderPrvsnlDcsnProcessVO;
	}
	
	/**
	 * 구분 및 판매 방식, 상태 코드에 따른 지정가 취소 진행
	 */
	@Override
	public OrderPrvsnlDcsnProcessVO deletePrvsnlDcsnProcess(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO) throws Exception {
		if(!StringUtils.equals("D", orderPrvsnlDcsnProcessVO.getSttusCode())) {
			throw new Exception("지정가 취소 코드가 아닙니다.");
		}
		
		// 라이브 영업시간 리스트를 가져온다.
		List<RestTermVO> restDeLiveList = bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");
		Optional<RestTermVO> restDeLiveOp = Optional.ofNullable(restDeLiveList).orElse(Collections.emptyList())
				.stream()
				.filter(restTerm -> "N".equals(restTerm.getRestdeAt())
						&& (orderPrvsnlDcsnProcessVO.getMetalCode()).equals(restTerm.getMetalCode()) 
						&& BsnInfoUtil.OperateSttusCode.OPERATE_AT.getValues().contains(restTerm.getOpenTimeCode())
				)
				.findFirst();
		
		boolean restStatus = restDeLiveOp.isPresent(); // 영업시간 체크(true: 영업시간, false: 휴일)
		
		// 금일 휴일에 따른 유효성 체크
		//log.warn(">> 금일 휴일에 따른 유효성 체크 : " + restStatus);
        if(!restStatus) {
            throw new Exception("영업시간을 확인해주세요.");
        }
		
		//log.info(">> orderPrvsnlDcsnProcessVO deletePrvsnlDcsnProcess : " + orderPrvsnlDcsnProcessVO.toString());
		String section = orderPrvsnlDcsnProcessVO.getSection(); // 구분 [lme: LME 분리확정, fx: FX 분리확정, singl: 단일확정, smtm: 동시확정]
		
		switch(section) {
			case "lme" : 
				// 주문_지정가 주문 LME 기본 테이블 취소
				orderPrvsnlDcsnMapper.cancelOrLimitLmeOrderBas(orderPrvsnlDcsnProcessVO);
				
				// LME/KRW - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
				commPrvsnlLimitOrderRedisPubService.prvsnlLimitOrderMsgLmePublish(orderPrvsnlDcsnProcessVO.getLimitLmeOrderNo(), "D");
				break;
			case "fx" : 
				// 주문_지정가 주문 환율 기본 테이블 취소
				orderPrvsnlDcsnMapper.cancelOrLimitEhgtOrderBas(orderPrvsnlDcsnProcessVO);
				
				// FX - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
				commPrvsnlLimitOrderRedisPubService.prvsnlLimitOrderMsgFxPublish(orderPrvsnlDcsnProcessVO.getLimitEhgtOrderNo(), "D");
				break;
			case "singl" : 
				// 주문_지정가 주문 KRW 기본 테이블 취소
				orderPrvsnlDcsnMapper.cancelOrLimitKrwOrderBas(orderPrvsnlDcsnProcessVO);
				
				// LME/KRW - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
				commPrvsnlLimitOrderRedisPubService.prvsnlLimitOrderMsgLmePublish(orderPrvsnlDcsnProcessVO.getLimitKrwOrderNo(), "D");
				break;
		}
		
		// 단가확정하기 정보 및 주문 번호에 대한 공통 가단가 확정 여부 정보 가져오기, 구분 및 판매 방식, 상태 코드에 따른 등록, 수정, 취소 진행 후 정보 가져오기
		this.getOrderPrvsnlDcsnProcessInfo(orderPrvsnlDcsnProcessVO);
		// 가단가 확정하기 정보 websocket publish, FO에 해당 확정 여부 전파 전달 (SimpMessagingTemplate) [확정, 체결, 수정, 취소] 모두 대상
		this.websocketPublishPrvsnlDcsnSimpMsg(orderPrvsnlDcsnProcessVO);
		
		return orderPrvsnlDcsnProcessVO;
	}
	
	/**
	 * 가단가 확정하기 정보 websocket publish, FO에 해당 확정 여부 전파 전달 (SimpMessagingTemplate) [확정, 체결, 수정, 취소] 모두 대상
	 */
	@Override
	public void websocketPublishPrvsnlDcsnSimpMsg(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO) {
		//log.info(">> websocketPublishPrvsnlDcsnSimpMsg orderPrvsnlDcsnProcessVO : " + String.valueOf(orderPrvsnlDcsnProcessVO));
		
		ObjectMapper objectMapper = new ObjectMapper();
		
		Map<String, Object> sendTarget = new HashMap<String, Object>();
		
		try {
			String jsonStr = objectMapper.writeValueAsString(orderPrvsnlDcsnProcessVO);
			sendTarget = objectMapper.readValue(jsonStr, Map.class);
		} catch (Exception e) {
			log.error("[OrderPrvsnlDcsnServiceImpl][websocketPublishPrvsnlDcsnSimpMsg] error >> " , e);
		}
		
        // 가단가 확정하기 정보 websocket publish, FO에 해당 확정 여부 전파 전달 (SimpMessagingTemplate) [확정, 체결, 수정, 취소] 모두 대상
        commFrontOrderWebsocketService.publishPrvsnlDcsnSimpMsg(sendTarget);
	}
	
	/**
	 * 단가확정하기 정보 및 주문 번호에 대한 공통 가단가 확정 여부 정보 가져오기
	 */
	@Override
	public void getOrderPrvsnlDcsnProcessInfo(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO) throws Exception {
		// 단가확정하기 정보 가져오기
		OrderPrvsnlDcsnInfoVO getOrderPrvsnlDcsnInfo = this.getOrderPrvsnlDcsnInfo(orderPrvsnlDcsnProcessVO.getOrderNo());
		//log.info(">> getOrderPrvsnlDcsnProcessInfo : " + String.valueOf(getOrderPrvsnlDcsnInfo));
		
		// 주문 번호에 대한 공통 가단가 확정 여부 정보 가져오기
		CommPrvsnlDcsnInfoVO getPrvsnlDcsnAtInfo = commPrvsnlOrderService.getPrvsnlDcsnAtInfo(orderPrvsnlDcsnProcessVO.getOrderNo());
		//log.info(">> getOrderPrvsnlDcsnProcessInfo : " + String.valueOf(getPrvsnlDcsnAtInfo));
		
		orderPrvsnlDcsnProcessVO.setOrderPrvsnlDcsnInfoVO(getOrderPrvsnlDcsnInfo); // 단가확정하기 정보
		orderPrvsnlDcsnProcessVO.setCommPrvsnlDcsnInfoVO(getPrvsnlDcsnAtInfo); // 주문 번호에 대한 공통 가단가 확정 여부 정보
	}
	
}
