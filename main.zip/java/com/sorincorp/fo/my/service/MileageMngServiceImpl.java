package com.sorincorp.fo.my.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.my.mapper.MileageMngMapper;
import com.sorincorp.fo.my.model.MileageMngVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MileageMngServiceImpl implements MileageMngService{

	@Autowired
	private MileageMngMapper mileageMngMapper;

	@Override
	public List<MileageMngVO> selectMbMileageMngList(MileageMngVO mileageMngVO) throws Exception {
		return mileageMngMapper.selectMbMileageMngList(mileageMngVO);
	}

	@Override
	public Integer selectMbMileageMngListCnt(MileageMngVO mileageMngVO) throws Exception {
		return mileageMngMapper.selectMbMileageMngListCnt(mileageMngVO);
	}

	@Override
	public MileageMngVO selectMbMileageMngSeList(MileageMngVO mileageMngVO) throws Exception {
		MileageMngVO mbMileageSeList = mileageMngMapper.selectMbMileageMngSeList(mileageMngVO);
		List<MileageMngVO> list = mileageMngMapper.selectMbMileageMngList(mileageMngVO);
		int delPrearngeMlg = 0; // 소멸예정 마일리지

		for(MileageMngVO vo : list) {
			if( 0 < vo.getMlgDateDiff() && vo.getMlgDateDiff() < 30) {
				if(vo.getMlgSe().equals("01") && !vo.getMlgTy().equals("05") && vo.getAccmlExtshAt().equals("N")) {
					delPrearngeMlg += vo.getDelngMlg() - vo.getUseMlg() ;
				}
			}
		}

		if(mbMileageSeList.getUseAbleMlg() < delPrearngeMlg) {
			mbMileageSeList.setDelPrearngeMlg(mbMileageSeList.getUseAbleMlg());
		}else {
			mbMileageSeList.setDelPrearngeMlg(delPrearngeMlg);
		}

		return mbMileageSeList;
	}

}
