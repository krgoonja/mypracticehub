package com.sorincorp.fo.my.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.my.mapper.MyMenuMapper;
import com.sorincorp.fo.my.model.MyPageMenuVO;

@Service
public class MyMenuServiceImpl implements MyMenuService {

	@Autowired
	private MyMenuMapper myMenuMapper;
	@Autowired
	private UserInfoUtil userInfoUtil;

	private static String MBER_SE_CODE_01 = "FO_MASTR";
	private static String MBER_SE_CODE_02 = "FO_PURCHS_SMRIZE";
	private static String MBER_SE_CODE_03 = "FO_PURCHS_CHRG";
	private static String MBER_SE_CODE_04 = "FO_CPTAL_CHRG";

	@Override
	public List<MyPageMenuVO> selectMenuList() {
		// TODO Auto-generated method stub
		String authorId = "";
		String mberSeCode = userInfoUtil.getMemberSecode();
		String mberSttusCode = "";

		if ("01".equals(mberSeCode)) {
			// 마스터
			authorId = MBER_SE_CODE_01;
		} else if ("02".equals(mberSeCode)) {
			// 구매총괄
			authorId = MBER_SE_CODE_02;
		} else if ("03".equals(mberSeCode)) {
			// 구매담당
			authorId = MBER_SE_CODE_03;
		} else if ("04".equals(mberSeCode)) {
			// 자금담당
			authorId = MBER_SE_CODE_04;
		}

		// 간편회원은 se코드가 없으므로 임시로 마스터 권한부여(메뉴에만 적용됨)
		if ("02".equals(userInfoUtil.getType())) {
			authorId = MBER_SE_CODE_01;
		}

		// author id 변경될경우 메뉴리스트 못가져옴
		return myMenuMapper.selectMenuList(authorId);
	}

//	@Override
//	public List<MyPageMenuVO> selectMenuList(String authorNo) {
//		return myMenuMapper.selectMenuList(authorNo);
//	}
}
