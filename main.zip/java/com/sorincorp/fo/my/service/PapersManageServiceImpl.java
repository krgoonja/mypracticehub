package com.sorincorp.fo.my.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.my.mapper.PapersManageMapper;
import com.sorincorp.fo.my.model.PapersManageDetailVO;
import com.sorincorp.fo.my.model.PapersManageVO;

import lombok.extern.slf4j.Slf4j;

/**
 *
 * 서류 관리 ServiceImpl.java
 * @version
 * @since 2021. 9. 8.
 * @author srec0054
 */
@Slf4j
@Service
public class PapersManageServiceImpl implements PapersManageService {

	@Autowired
	private PapersManageMapper papersManageMapper;

	private static final String SALES	= "sales";		//판매계약서
	private static final String TRADE 	= "trade";		//거래명세서
    private static final String TAX 	= "tax";		//전자세금계산서
    private static final String INSTR 	= "instr";		//출고지시서
    private static final String DETAILS = "details";	//출고명세서
    private static final String TAKE 	= "take"; 		//인수증
    private static final String RCPMNYR = "rcpmnyr"; 	//입금확인서
    private static final String PYMNT = "pymnt"; 		//지급확인서
    private static final String PRQUDO = "prqudo";		//평균가 견적서
    private static final String CTRTC = "ctrtc";		//평균가 계약서
    private static final String SCREOFE = "screofe";		//성적서
    private static final String RCPT_PRUF = "rcptPruf";		//거래내역서
    private static final String CHANGEGLD_RCPMNY_LOREQ = "changegldRcpmnyLoreq";		//변동금 입금요청서
    private static final String CHANGEGLD_RCPMNY_CNFRMN = "changegldRcpmnyCnfrmn";	//변동금 입금확인서
    private static final String CHANGEGLD_DEFRAY_CNFRMN = "changegldDefrayCnfrmn";	//변동금 출금확인서


	/**서류관리 리스트 카운트*/
	@Override
	public Integer selectPapersManageCnt(PapersManageVO paramVo) throws Exception{
		log.debug("PapersManageServiceImpl::selectPapersManageCnt (서류관리 리스트 카운트) Start");
		Integer resultCnt 	= 0;					//리스트 카운트
		String tabDiv 		= paramVo.getTabDiv();	//탭 구분

		try {

			if(SALES.equals(tabDiv)) 		resultCnt = papersManageMapper.selectPapersManageSalesCnt(paramVo);		//판매계약서
			else if(TRADE.equals(tabDiv)) 	resultCnt = papersManageMapper.selectPapersManageTradeCnt(paramVo);		//거래명세서
			else if (TAX.equals(tabDiv)) 	resultCnt = papersManageMapper.selectPapersManageTaxCnt(paramVo);		//전자세금계산서
			else if (INSTR.equals(tabDiv)) 	resultCnt = papersManageMapper.selectPapersManageInstrCnt(paramVo);		//출고지시서
			else if (DETAILS.equals(tabDiv))resultCnt = papersManageMapper.selectPapersManageDetailsCnt(paramVo);	//출고명세서
			else if (TAKE.equals(tabDiv)) 	resultCnt = papersManageMapper.selectPapersManageTakeCnt(paramVo);		//인수증
			else if (RCPMNYR.equals(tabDiv))resultCnt = papersManageMapper.selectRcpmnyrCnt(paramVo);				//입금확인서
			else if (PYMNT.equals(tabDiv))  resultCnt = papersManageMapper.selectPymntCnt(paramVo);						//지급확인서
			else if (PRQUDO.equals(tabDiv)) resultCnt = papersManageMapper.selectPrqudoCnt(paramVo);					//평균가견적서
			else if (CTRTC.equals(tabDiv))  resultCnt = papersManageMapper.selectCtrtcCnt(paramVo);						//평균가계약서
			else if (SCREOFE.equals(tabDiv))  resultCnt = papersManageMapper.selectScreofeCnt(paramVo);					//성적서
			else if (RCPT_PRUF.equals(tabDiv))  resultCnt = papersManageMapper.selectRcptPrufCnt(paramVo);				//거래내역서
			else if (CHANGEGLD_RCPMNY_LOREQ.equals(tabDiv)) {	//변동금 입금요청서
				resultCnt = papersManageMapper.selectChangegldCnt(paramVo, "10");
			} else if (CHANGEGLD_RCPMNY_CNFRMN.equals(tabDiv)) {	//변동금 입금확인서
				resultCnt = papersManageMapper.selectChangegldCnt(paramVo, "20");
			} else if (CHANGEGLD_DEFRAY_CNFRMN.equals(tabDiv)) {	//변동금 출금확인서
				resultCnt = papersManageMapper.selectChangegldCnt(paramVo, "50");
			}
			else log.debug("selectPapersManage::tabDiv IS NULL");

		} catch (Exception e) {
			log.error("PapersManageServiceImpl::selectPapersManageCnt exception = " + e.getMessage());
		}

		log.debug("PapersManageServiceImpl::selectPapersManageCnt (서류관리 리스트 카운트) End");

		return resultCnt;
	}//end selectPapersManageCnt()

	/**서류관리 리스트 조회*/
	@Override
	public List<PapersManageVO> selectPapersManage(PapersManageVO paramVo) throws Exception {
		log.debug("::selectPapersManage (서류관리 리스트 조회) Start");
		List<PapersManageVO> resultList = new ArrayList<>();
		String tabDiv = paramVo.getTabDiv();
		try {

			if(SALES.equals(tabDiv)) 		resultList = papersManageMapper.selectPapersManageSales(paramVo);	//판매계약서
			else if(TRADE.equals(tabDiv)) 	resultList = papersManageMapper.selectPapersManageTrade(paramVo);	//거래명세서
			else if (TAX.equals(tabDiv)) 	resultList = papersManageMapper.selectPapersManageTax(paramVo);		//전자세금계산서
			else if (INSTR.equals(tabDiv)) 	resultList = papersManageMapper.selectPapersManageInstr(paramVo);	//출고지시서
			else if (DETAILS.equals(tabDiv))resultList = papersManageMapper.selectPapersManageDetails(paramVo);	//출고명세서
			else if (TAKE.equals(tabDiv)) 	resultList = papersManageMapper.selectPapersManageTake(paramVo);	//인수증
			else if (RCPMNYR.equals(tabDiv))resultList = papersManageMapper.selectRcpmnyr(paramVo);				//입금확인서
			else if (PYMNT.equals(tabDiv))  resultList = papersManageMapper.selectPymnt(paramVo);				//지급확인서
			else if (PRQUDO.equals(tabDiv)) resultList = papersManageMapper.selectPrqudo(paramVo);				//평균가견적서
			else if (CTRTC.equals(tabDiv)) resultList = papersManageMapper.selectCtrtc(paramVo);				//평균가계약서
			else if (SCREOFE.equals(tabDiv)) resultList = papersManageMapper.selectScreofe(paramVo);				//성적서
			else if (RCPT_PRUF.equals(tabDiv)) resultList = papersManageMapper.selectRcptPruf(paramVo);				//거래내역서
			else if (CHANGEGLD_RCPMNY_LOREQ.equals(tabDiv)) {	//변동금 입금요청서
				resultList = papersManageMapper.selectChangegld(paramVo, "10");
			} else if (CHANGEGLD_RCPMNY_CNFRMN.equals(tabDiv)) {	//변동금 입금확인서
				resultList = papersManageMapper.selectChangegld(paramVo, "20");
			} else if (CHANGEGLD_DEFRAY_CNFRMN.equals(tabDiv)) {	//변동금 출금확인서
				resultList = papersManageMapper.selectChangegld(paramVo, "50");
			}
			else log.debug("selectPapersManage::tabDiv IS NULL");

			log.debug("selectPapersManage resultList.toString() ===============> " + resultList.toString());
		} catch (Exception e) {
			log.error("::selectPapersManage exception = " + e.getMessage());
		}

		log.debug("::selectPapersManage (서류관리 리스트 조회) End");
		return resultList;
	}//end selectPapersManage()

	/**마이페이지 > 서류 관리 > 서류 관리 상세 : 페이지 로드*/
	@Override
	public List<PapersManageDetailVO> selectPapersManageDetailList(PapersManageDetailVO paramVo) throws Exception {
		log.debug("::selectPapersManageDetailList (페이지 로드) Start");
		List<PapersManageDetailVO> papersManageDetail = new ArrayList<>();

		try {
			papersManageDetail = papersManageMapper.selectPapersManageDetailList(paramVo);
		} catch (Exception e) {
			log.error("PapersManageServiceImpl::selectPapersManageDetailList exception = " + e.getMessage());
		}

		log.debug("::selectPapersManageDetailList (페이지 로드) End");
		return papersManageDetail;
	}


	/**서류관리 상세 리스트 카운트*/
	@Override
	public Integer selectPapersManageDetailListCnt(PapersManageDetailVO paramVo) throws Exception {
		log.debug("PapersManageServiceImpl::selectPapersManageDetailListCnt (서류관리 상세 리스트 카운트) Start");
		Integer selectPapersManageCnt = 0;

		try {
			selectPapersManageCnt = papersManageMapper.selectPapersManageDetailListCnt(paramVo);
		} catch (Exception e) {
			log.error("PapersManageServiceImpl::selectPapersManageDetailListCnt exception = " + e.getMessage());
		}

		log.debug("PapersManageServiceImpl::selectPapersManageDetailListCnt (서류관리 상세 리스트 카운트) End");
		return selectPapersManageCnt;
	}//end selectPapersManageDetailListCnt()

	/**서류관리 상세 리스트 조회*/
	@Override
	public List<PapersManageDetailVO> selectPapersManage(PapersManageDetailVO paramVo) throws Exception {
		log.debug("::selectPapersManage (서류관리 상세 리스트 조회) Start");
		List<PapersManageDetailVO> orderPayInfoList = new ArrayList<>();

		try {
			orderPayInfoList = papersManageMapper.selectPapersManage(paramVo);
		} catch (Exception e) {
			log.error("::selectPapersManage exception = " + e.getMessage());
		}

		log.debug("::selectPapersManage (서류관리 상세 리스트 조회) End");
		return orderPayInfoList;
	}
	
	@Override
    public List<PapersManageDetailVO> getRelatePapersInfo(PapersManageDetailVO unityOrderPapersVo) throws Exception {
         log.debug("UnityOrderDetailServiceImpl::getRelatePapersInfo (관련 서류 데이터 조회) Start");
         List<PapersManageDetailVO> relatePapersInfoList = new ArrayList<PapersManageDetailVO>();

         try {
              relatePapersInfoList = papersManageMapper.getRelatePapersInfo(unityOrderPapersVo);

              // 24-08-06 변경사항 : 거래내역서(입금증빙) 항목의 추가에 따라, param2 로 조회되는 계좌번호를 복호화하는 로직 추가
              PapersManageDetailVO rcptPrufVo = relatePapersInfoList.stream()
           		   												.filter((vo)->{return StringUtils.equals(vo.getTabDiv(), "rcptPruf");})
           		   												.findFirst()
           		   												.orElse(null);
              
              if(rcptPrufVo != null && rcptPrufVo.getParam2() != null) {
            	  rcptPrufVo.setParam2(CryptoUtil.decryptAES256(rcptPrufVo.getParam2()));
              }
         } catch (Exception e) {
              log.error("::getRelatePapersInfo exception = " + e.getMessage());
              throw new Exception(e.getMessage());
         }

         log.debug("UnityOrderDetailServiceImpl::getRelatePapersInfo (관련 서류 데이터 조회) End");
         return relatePapersInfoList;
    }//end getRelatePapersInfo()

	/**성적서&패킹리스트 리스트 조회*/
	@Override
	public List<PapersManageDetailVO> selectScreofePackngList(PapersManageDetailVO paramVo) throws Exception {
		log.debug("PapersManageServiceImpl::selectScreofePackngList (성적서&패킹리스트 리스트 조회) Start");
		List<PapersManageDetailVO> selectScreofePackngList = new ArrayList<PapersManageDetailVO>();

		try {
			selectScreofePackngList = papersManageMapper.selectScreofePackngList(paramVo);
		} catch (Exception e) {
			log.error("PapersManageServiceImpl::selectScreofePackngList exception = " + e.getMessage());
		}

		log.debug("PapersManageServiceImpl::selectScreofePackngList (성적서&패킹리스트 리스트 조회) End");
		return selectScreofePackngList;
	}//end selectScreofePackngList()

	/**처리내용:1차, 2차 매매계약서 내부 거래명세서, 세금계산서 ozReport 실행시 필요한 파라미터를 다시 조회*/
	public List<Map<String, Object>> selectTaxTradeBillInfo(String orderNo)throws Exception {
		log.debug("PapersManageServiceImpl::selectTaxTradeBillInfo (1차, 2차 매매계약서 내부 거래명세서, 세금계산서 ozReport 실행시 필요한 파라미터를 다시 조회) End");
		return papersManageMapper.selectTaxTradeBillInfo(orderNo);
	}

	/**상단 대시보드 결제수단 조회*/
	@Override
	public PapersManageVO selectSetleMnInfo(PapersManageVO dashBoardParamVo) throws Exception {
		log.debug("PapersManageServiceImpl::selectSetleMnInfo (상단 대시보드 결제수단 조회) Start");
		PapersManageVO setleMnInfo = papersManageMapper.selectSetleMnInfo(dashBoardParamVo);

		/**복호화 - 환불계좌번호*/
		String refndAcnutNo 		= setleMnInfo.getRefndAcnutNo();
		String decryptRefndAcnutNo	= null;

		if(StringUtils.isNotEmpty(refndAcnutNo)) {
			decryptRefndAcnutNo = CryptoUtil.decryptAES256(refndAcnutNo);
			setleMnInfo.setRefndAcnutNo(decryptRefndAcnutNo);
		}//end if()

		log.debug("PapersManageServiceImpl::selectSetleMnInfo (상단 대시보드 결제수단 조회) End");
		return setleMnInfo;
	}//end selectSetleMnInfo()

	/**최근 30일 거래내역, 상단 대시보드 주문현황*/
	@Override
	public PapersManageVO selectRecentOrderDtls(PapersManageVO dashBoardParamVo) throws Exception {
		return papersManageMapper.selectRecentOrderDtls(dashBoardParamVo);
	}//endselectRecentOrderDtls

	/**출고지시서 화물수취인 전화번호 복호화*/
	@Override
	public String updateMoblphonNoDecryption(PapersManageDetailVO paramVo) throws Exception {

		String resultStr = "";

		try {
			//출고지시서 화물수취인 전화번호 조회
			String frghtAddrseMoblphonNo = papersManageMapper.selectMoblphonNoDecryption(paramVo);

			if (!StringUtils.isEmpty(frghtAddrseMoblphonNo)) {
				String decryptStr 	= CryptoUtil.decryptAES256(frghtAddrseMoblphonNo);	//복호화
				resultStr			= StringUtil.formatPhone(decryptStr);	//전화번호 하이픈 포멧 적용
//						papersManageMapper.selectFnGetTelNo(decryptStr);	//전화번호 하이픈 포맷 적용

			} else {
				log.debug("updateMoblphonNoDecryption frghtAddrseMoblphonNo is empty");
			}

		} catch (Exception e) {

			log.error("updateMoblphonNoDecryption exception = " + e.getMessage());

		}

		return resultStr;
	}//end updateMoblphonNoDecryption()

	@Override
	public String getMberEwalletAcntNo(String orderNo) throws Exception {
		String ewalletAcntNo = papersManageMapper.selectMberEwalletAcntNo(orderNo);
		
		if(StringUtils.isEmpty(ewalletAcntNo)) {
			throw new Exception("해당 고객에게 등록된 계좌번호가 존재하지 않습니다.");
		}
		
		return CryptoUtil.decryptAES256(ewalletAcntNo);
	}
	
	@Override
	public String getAllChangegldCnfrmn(String orderNo) throws Exception {
		List<Map<String, String>> changegldList = papersManageMapper.getAllChangegldCnfrmn(orderNo);
		
		return new ObjectMapper().writeValueAsString(changegldList);
	}

}//end class()
