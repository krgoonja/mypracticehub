package com.sorincorp.fo.my.service;

import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.fo.my.model.OrderPrvsnlDcsnInfoVO;
import com.sorincorp.fo.my.model.OrderPrvsnlDcsnProcessVO;

/**
 * OrderPrvsnlDcsnService.java
 * 단가확정하기 관련 Service 인터페이스
 * 
 * @version
 * @since 2024. 9. 9.
 * @author srec0049
 */
public interface OrderPrvsnlDcsnService {

	/**
	 * <pre>
	 * 처리내용: 단가확정하기 정보 가져오기
	 * </pre>
	 * @date 2024. 9. 10.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderPrvsnlDcsnInfoVO
	 * @return
	 * @throws Exception
	 */
	public OrderPrvsnlDcsnInfoVO getOrderPrvsnlDcsnInfo(String orderNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 가단가 확정 처리
	 * </pre>
	 * @date 2024. 10. 8.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 8.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	public void procPrvsnlDcsn(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 구분 및 판매 방식, 상태 코드에 따른 확정 [라이브, 지정가] 등록 진행
	 * </pre>
	 * @date 2024. 9. 30.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 30.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderPrvsnlDcsnProcessVO
	 * @throws Exception
	 */
	public OrderPrvsnlDcsnProcessVO registPrvsnlDcsnProcess(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 구분 및 판매 방식, 상태 코드에 따른 지정가 수정 진행
	 * </pre>
	 * @date 2024. 9. 30.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 30.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderPrvsnlDcsnProcessVO
	 * @return
	 * @throws Exception
	 */
	public OrderPrvsnlDcsnProcessVO updatePrvsnlDcsnProcess(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 구분 및 판매 방식, 상태 코드에 따른 지정가 취소 진행
	 * </pre>
	 * @date 2024. 10. 2.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 2.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderPrvsnlDcsnProcessVO
	 * @return
	 * @throws Exception
	 */
	public OrderPrvsnlDcsnProcessVO deletePrvsnlDcsnProcess(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 가단가 확정하기 정보 websocket publish, FO에 해당 확정 여부 전파 전달 (SimpMessagingTemplate) [확정, 체결, 수정, 취소] 모두 대상
	 * </pre>
	 * @date 2024. 10. 10.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderPrvsnlDcsnProcessVO
	 */
	public void websocketPublishPrvsnlDcsnSimpMsg(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO);
	
	/**
	 * <pre>
	 * 처리내용: 단가확정하기 정보 및 주문 번호에 대한 공통 가단가 확정 여부 정보 가져오기
	 * </pre>
	 * @date 2024. 9. 30.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 30.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderPrvsnlDcsnProcessVO
	 * @return
	 * @throws Exception
	 */
	public void getOrderPrvsnlDcsnProcessInfo(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO) throws Exception;
}
