package com.sorincorp.fo.my.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.fo.cs.model.InqryRegistVO;
import com.sorincorp.fo.my.model.InqryDtlsVO;

/**
 * InqryDtlsService.java
 * @version
 * @since 2021. 7. 28.
 * @author srec0048
 */
public interface InqryDtlsService {

	/**
	 * <pre>
	 * 처리내용: 공통코드 스트링으로 변환한다.
	 * </pre>
	 * @date 2021. 7. 29.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 29.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param commonCodeList
	 * @param val
	 * @return
	 * @throws Exception
	 */
	public String getCommCodeListStr(Map<String, String> commonCodeList, String gb) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문의내역 총건수를 조회한다.
	 * </pre>
	 * @date 2021. 7. 30.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 30.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqryDtlsVO
	 * @return
	 * @throws Exception
	 */
	public int selectInqryDtlsListTotCnt(InqryDtlsVO inqryDtlsVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문의내역 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 7. 30.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 30.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqryDtlsVO
	 * @return
	 * @throws Exception
	 */
	public List<InqryDtlsVO> selectInqryDtlsList(InqryDtlsVO inqryDtlsVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문의내역 상세를 조회한다.
	 * </pre>
	 * @date 2021. 7. 30.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 30.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqryDtlsVO
	 * @return
	 */
	public InqryDtlsVO selectInqryDtlsDetail(InqryDtlsVO inqryDtlsVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문의내역 첨부파일 리스트 조회한다.
	 * </pre>
	 * @date 2021. 8. 19.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 19.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqrySn
	 * @return
	 * @throws Exception
	 */
	public List<FileDocVO> selectAtchFileList(long inqrySn) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문의구분 중분류를 조회한다.
	 * </pre>
	 * @date 2021. 8. 5.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 5.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqrySeCode
	 * @return
	 */
	public List<CommonCodeVO> selectInqrySeDetailCode(Map<String, String> param) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 첨부파일 업로드한다.
	 * </pre>
	 * @date 2021. 8. 5.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 5.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param mRequest
	 * @return
	 * @throws Exception
	 */
	public Map<String,Object> saveAttachFile(MultipartHttpServletRequest mRequest) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 첨부파일 삭제한다.
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param docNo
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> deleteAttachFile(FileDocVO fileVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문의내용을 저장한다.
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqryDtlsList
	 * @throws Exception
	 */
	public void insertInqrySave(InqryDtlsVO inqryDtlsVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문의내용을 삭제한다.
	 * </pre>
	 * @date 2021. 8. 20.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 20.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqryDtlsVO
	 * @throws Exception
	 */
	public void deleteInqryDetail(InqryDtlsVO inqryDtlsVO) throws Exception;

	/**
	 * 
	 * <pre>
	 * 개인정보 수집 및 이용 동의에 대한 안내 (약관 내용1)
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 14.			srec0054			최초작성
	 * ------------------------------------------------
	 * @return	InqryRegistVO
	 */
	public InqryRegistVO selectStplatCnOne() throws Exception;
	
}
