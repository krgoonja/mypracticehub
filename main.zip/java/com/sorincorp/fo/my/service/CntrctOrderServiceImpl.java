package com.sorincorp.fo.my.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.my.mapper.CntrctOrderMapper;
import com.sorincorp.fo.my.model.CntrctOrderBasVO;
import com.sorincorp.fo.my.model.CntrctOrderDtlVO;

import lombok.extern.slf4j.Slf4j;

/**
 * 계약 발주 서비스
 * @author srec0051
 *
 */
@Slf4j
@Service
public class CntrctOrderServiceImpl implements CntrctOrderService {

	@Autowired
	private CntrctOrderMapper cntrctOrderMapper;


	@Override
	public CntrctOrderBasVO selectCntrctOrderInfo(CntrctOrderBasVO paramVo) throws Exception {
		CntrctOrderBasVO cntrctOrderBasVO = cntrctOrderMapper.selectCntrctOrderInfo(paramVo);

		int cntrctMm = Integer.parseInt(cntrctOrderBasVO.getUntpcDcsnDe().substring(4, 6));
		cntrctOrderBasVO.setCntrctMm(cntrctMm);

		return cntrctOrderBasVO;
	}

	@Override
	public List<CntrctOrderDtlVO> selectListCntrctOrderDtl(CntrctOrderDtlVO paramVo) throws Exception {
		return cntrctOrderMapper.selectListCntrctOrderDtl(paramVo);
	}


}
