/**
 *
 */
package com.sorincorp.fo.my.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.mb.service.MbCmnCodeService;
import com.sorincorp.fo.my.mapper.SimplMberMyInfoMngMapper;
import com.sorincorp.fo.my.model.SimplMberMyInfoMngVO;

import lombok.extern.slf4j.Slf4j;

/**
 * MyInfoMngServiceImpl.java
 *
 * @version
 * @since 2021. 8. 23.
 * @author srec0009
 */
@Slf4j
@Service
public class SimplMberMyInfoMngServiceImpl implements SimplMberMyInfoMngService {

	@Autowired
	private SimplMberMyInfoMngMapper simplMbermyInfoMngMapper;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private MailService mailService;

	@Autowired
	private SMSService smsService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;
	
	/** 이메일 발송 매퍼 */
    @Autowired
    private MailMapper mailMapper;
    
	@Override
	public SimplMberMyInfoMngVO selectSimplMberInfo(String simplMberNo) {
		SimplMberMyInfoMngVO vo = simplMbermyInfoMngMapper.selectSimplMberInfo(simplMberNo);
		String moblphonNo = vo.getMoblphonNo();

		if (moblphonNo != null && !"".equals(moblphonNo)) {
			// 휴대폰 번호 복호화 20220118 srec0030
			try {
				log.debug("휴대폰 복호화 전 ===============>" + moblphonNo);
				moblphonNo = CryptoUtil.decryptAES256(moblphonNo);
				log.debug("휴대폰 복호화 후 ===============>" + moblphonNo);
				vo.setMoblphonNo(moblphonNo);
			} catch (Exception e) {
				// TODO: handle exception
				log.error("SimplMberMyInfoMngVO MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}
		return vo;
	}

	@Override
	public String selectChkPw(String simplMberNo, String mberSecretNo) {

		String chkPw = simplMbermyInfoMngMapper.selectSimplChkPw(simplMberNo);
		log.debug("chkPw :: " + chkPw.toString());
		String result = "";
		if (CryptoUtil.encryptSHA256(mberSecretNo).matches(chkPw)) {
			result = "S";
		} else {
			result = "F";
		}
		return result;
	}

	@Override
	public String updateNewPw(String simplMberNo, String mberSecretNo) {
		if (userInfoUtil.getAccountInfo() == null) {
			return "F";
		}
		SimplMberMyInfoMngVO simplMberMyInfoMngVO = new SimplMberMyInfoMngVO();
		simplMberMyInfoMngVO.setSimplMberNo(simplMberNo);
		simplMberMyInfoMngVO.setSimplMberSecretNo(CryptoUtil.encryptSHA256(mberSecretNo));
		simplMberMyInfoMngVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		int result = simplMbermyInfoMngMapper.updateNewPw(simplMberMyInfoMngVO);
		String data = "";
		simplMbermyInfoMngMapper.insertSimplMberInfoHst(simplMberNo);
		if (result < 1) {
			data = "F";
		} else {
			data = "S";
		}
		return data;
	}

	@Override
	public String updateSimplMberMyInfoDtl(String mberNo, SimplMberMyInfoMngVO simplMberMyInfoMngVO) {

		if (userInfoUtil.getAccountInfo() == null) {
			return "F";
		}

		String data = "";
		simplMberMyInfoMngVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		simplMberMyInfoMngVO.setSimplMberNo(mberNo);

		String moblphonNo = simplMberMyInfoMngVO.getMoblphonNo();

		try {
			// 핸드폰 번호 변경 안한 경우
			if (moblphonNo != null && !"".equals(moblphonNo)) {
				moblphonNo = moblphonNo.replaceAll("[^0-9]", "");
				if (simplMberMyInfoMngVO.getMarktRecptnSms().equals("N") && simplMberMyInfoMngVO.getMarktRecptnPush().equals("N") && simplMberMyInfoMngVO.getMarktRecptnEmail().equals("N")) {
					simplMberMyInfoMngVO.setAdvrtsRecptnAgreAt("N");
				} else {
					simplMberMyInfoMngVO.setAdvrtsRecptnAgreAt("Y");
				}

				try {
					log.debug("휴대폰 암호화 전 ===============>" + moblphonNo);
					moblphonNo = CryptoUtil.encryptAES256(moblphonNo);
					log.debug("휴대폰 암호화 후 ===============>" + moblphonNo);

					simplMberMyInfoMngVO.setMoblphonNo(moblphonNo);
					simplMbermyInfoMngMapper.updateMberMarktRecptnMediaBas(simplMberMyInfoMngVO); // 마케팅 수신동의 여부
					simplMbermyInfoMngMapper.insertMberMarktRecptnMediaHst(simplMberMyInfoMngVO);

					int result = simplMbermyInfoMngMapper.updateSimplMberMyInfoDtl(simplMberMyInfoMngVO);

					if (result > 0) {
						data = "S";
						simplMbermyInfoMngMapper.insertSimplMberInfoHst(simplMberMyInfoMngVO.getSimplMberNo());
					}

				} catch (Exception e1) {
					// TODO: handle exception
					log.error("updateSimplMberMyInfoDtl MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e1.getMessage());
				}
			} else {
				if (simplMberMyInfoMngVO.getMarktRecptnSms().equals("N") && simplMberMyInfoMngVO.getMarktRecptnPush().equals("N") && simplMberMyInfoMngVO.getMarktRecptnEmail().equals("N")) {
					simplMberMyInfoMngVO.setAdvrtsRecptnAgreAt("N");
				} else {
					simplMberMyInfoMngVO.setAdvrtsRecptnAgreAt("Y");
				}

				simplMbermyInfoMngMapper.updateMberMarktRecptnMediaBas(simplMberMyInfoMngVO); // 마케팅 수신동의 여부
				simplMbermyInfoMngMapper.insertMberMarktRecptnMediaHst(simplMberMyInfoMngVO);

				simplMbermyInfoMngMapper.insertSimplMberInfoHst(simplMberMyInfoMngVO.getSimplMberNo());
				data = "S";
			}
		} catch (Exception e) {
			data = "F";
		}

		return data;
	}

	@Override
	public int deleteSimplMber(SimplMberMyInfoMngVO simplMberMyInfoMngVO) throws Exception {

		if (userInfoUtil.getAccountInfo() == null) {
			return 0;
		}

		String secessionDt = simplMbermyInfoMngMapper.selectToday();
		String serviceDomain = "www.kztraders.com";

		SimplMberMyInfoMngVO vo = simplMbermyInfoMngMapper.selectSimplMberInfo(simplMberMyInfoMngVO.getSimplMberNo());
		simplMberMyInfoMngVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
		simplMberMyInfoMngVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
		int result = simplMbermyInfoMngMapper.deleteSimplMber(simplMberMyInfoMngVO);

		simplMbermyInfoMngMapper.insertSimplMberInfoHst(simplMberMyInfoMngVO.getSimplMberNo());

		log.debug("userInfo=====================>" + userInfoUtil.getAccountInfo());
		try {

			// String moblphonNo = userInfoUtil.getAccountInfo().getPhonenum();
			String moblphonNo = vo.getMoblphonNo();
			log.debug("moblphonNo ====================>" + moblphonNo);

			if (moblphonNo != null && !"".equals(moblphonNo)) {
				try {
					log.debug("휴대폰 복호화 전 ===============>" + moblphonNo);
					moblphonNo = CryptoUtil.decryptAES256(moblphonNo);
					log.debug("휴대폰 복호화 후 ===============>" + moblphonNo);
					moblphonNo = moblphonNo.replaceAll("[^0-9]", "");
				} catch (Exception e1) {
					// TODO: handle exception
					log.error("deleteSimplMber MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e1.getMessage());
				}
			}

			String templateNum = "41";
			String title = mbCmnCodeService.selectMssageSj(templateNum);

			Map<String, String> msgMap = new HashMap<>();
			SMSVO smsVO = new SMSVO();
			msgMap.put("templateNum", templateNum); // 메시지 템플릿 번호
			msgMap.put("mberId", userInfoUtil.getAccountInfo().getId());
			msgMap.put("mberNm", userInfoUtil.getAccountInfo().getName());
			msgMap.put("secessionDt", secessionDt);
			msgMap.put("Servicedomain", serviceDomain);
			// smsVO.setPhone(userInfoUtil.getAccountInfo().getPhonenum()); // 받는사람 번호
			smsVO.setPhone(moblphonNo); // 받는사람 번호
			smsVO.setMberNo(userInfoUtil.getAccountInfo().getMberNo());
			smsVO.setMsgTitle(title);
			smsService.insertSMS(smsVO, msgMap); // 메소드 호출

			Map<String, String> mailMap = new HashMap<>();
			MailVO mailVO = new MailVO();
			MailVO selectMailTmpt = mailMapper.selectMailTmpt(41);          // 발신자 이메일 가져오기
            mailVO.setMailTmptSeq(41); // 사용할 템플릿 번호 지정
			mailVO.setEmail(userInfoUtil.getAccountInfo().getId()); // 수신자 메일 주소
			mailVO.setMailSendUserId("admin"); // 보내는 사람 아이디
			mailVO.setMailSendEmail(selectMailTmpt.getSntoEmail()); // 보내는 사람 이메일
			mailVO.setMemberNo(userInfoUtil.getAccountInfo().getMberNo());
			mailMap.put("mberId", userInfoUtil.getAccountInfo().getId());
			mailMap.put("mberNm", userInfoUtil.getAccountInfo().getName());
			mailMap.put("secessionDt", secessionDt);
			mailService.insertMailSend(mailVO, mailMap);
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
		}

		return result;
	}

	@Override
	public SimplMberMyInfoMngVO selectAgreAt(SimplMberMyInfoMngVO simplMberMyInfoMngVO) {
		return simplMbermyInfoMngMapper.selectAgreAt(simplMberMyInfoMngVO);
	}

}
