package com.sorincorp.fo.my.service;

import java.util.ArrayList;
import java.util.List;
import com.sorincorp.fo.my.model.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.fo.my.mapper.OrderDlvySttusMapper;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OrderDlvySttusServiceImpl implements OrderDlvySttusService {

	@Autowired
	private OrderDlvySttusMapper orderDlvySttusMapper;

	/**
	 * 출고 정보 리스트를 조회한다.
	 */
	@Override
	public List<OrderDlvySttusVO> selectDlvySttusList(OrderDlvySttusVO searchVo) throws Exception {				
		return orderDlvySttusMapper.selectOrderDlvySttusList(searchVo);
	}
	
	@Override
	public int selectOrderDlvySttusTotCnt(OrderDlvySttusVO orderDlvySttusVO) throws Exception {		
		return orderDlvySttusMapper.selectOrderDlvySttusTotCnt(orderDlvySttusVO);
	}
		
	@Override
	public List<OrderDlvySttusVO> selectOrderDlvySttusVhcleDtl(OrderDlvySttusVO searchVo) throws Exception {		

		List<OrderDlvySttusVO> dlivyList = orderDlvySttusMapper.selectOrderDlvySttusVhcleDtl(searchVo);
		List<OrderDlvySttusVO> retList = new ArrayList<OrderDlvySttusVO>();

		if (!CollectionUtils.isEmpty(dlivyList)) {
			for (OrderDlvySttusVO vo : dlivyList) {
//				log.debug("원본데이터 "+ vo.getDrverTlphonNo());
				if (StringUtils.isNotBlank(vo.getDrverTlphonNo())) {
					String decNo = CryptoUtil.decryptAES256(vo.getDrverTlphonNo());
//					log.debug("암호화데이터 : "+ decNo);
					vo.setDrverTlphonNo(decNo);
				}
				retList.add(vo);
			}
		}
		return retList;
	}
	
}