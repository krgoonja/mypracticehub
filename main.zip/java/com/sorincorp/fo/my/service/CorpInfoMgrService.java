package com.sorincorp.fo.my.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.fo.my.model.CorpInfoMgrVO;
import com.sorincorp.fo.my.model.CorpKycInfoMgrVO;

public interface CorpInfoMgrService {

	/**
	 * <pre>
	 * 업체 상세정보를 조회한다.
	 * </pre>
	 *
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 10.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param corpInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	CorpInfoMgrVO selectCorpInfoDetail(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체정보를 수정한다.
	 * </pre>
	 *
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 10.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param corpInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	int updateCorpInfoMgr(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체정보 관련 첨부파일을 upload한다.
	 * </pre>
	 *
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 10.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param mRequest
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> uploadAttachFile(MultipartHttpServletRequest mRequest) throws Exception;

	String selectMemeberSecessionPossibleYn(String mberNo) throws Exception;

	int checkPassWord(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	List<CorpInfoMgrVO> selectLonGrntyBankUseAtList(String entrpsNo) throws Exception;

	String selectTrmnatPossibleAt(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 업체 KYC 정보를 조회한다.
	 * </pre>
	 *
	 * @date 2022. 12. 20.
	 * @author sumin95
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 12. 20.
	 *          sumin95 최초작성 ------------------------------------------------
	 * @param corpInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	CorpKycInfoMgrVO selectKycCorpInfo(CorpKycInfoMgrVO corpKycInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 업체 KYC 정보를 카운트한다.
	 * </pre>
	 *
	 * @date 2022. 12. 20.
	 * @author sumin95
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 12. 20.
	 *          sumin95 최초작성 ------------------------------------------------
	 * @param corpInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	int selectKycCorpInfoCount(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 업체 KYC 첨부파일 업로드
	 * </pre>
	 *
	 * @date 2022. 12. 20.
	 * @author sumin95
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 12. 20.
	 *          sumin95 최초작성 ------------------------------------------------
	 * @param MultipartHttpServletRequest
	 * @return
	 * @throws Exception
	 */
	HashMap<String, String> saveAttachFile(MultipartHttpServletRequest mRequest) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 11. 17.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 11. 17.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> deleteFileDoc(FileDocVO vo) throws Exception;

	/**
	 * <pre>
	 * 업체 KYC 정보 UPDATE
	 * </pre>
	 *f
	 * @date 2022. 12. 20.
	 * @author sumin95
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 12. 20.
	 *          sumin95 최초작성 ------------------------------------------------
	 * @param CorpKycInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	boolean updateCorpKycInfoDetail(CorpKycInfoMgrVO corpKycInfoMgrVO) throws Exception;
}
