package com.sorincorp.fo.my.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.order.model.OrderDtlsClaimVO;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.my.mapper.OrderDtlsMapper;
import com.sorincorp.fo.my.model.DlvyDetailVO;
import com.sorincorp.fo.my.model.OrderDtlsVO;

import io.jsonwebtoken.lang.Collections;

@Service
public class OrderDtlsServiceImpl implements OrderDtlsService {

	@Autowired
	private OrderDtlsMapper orderDtlsMapper;
	
	@Autowired
	private UserInfoUtil userInfoUtil;

	/**
	 * 공통코드 스트링으로 변환한다.
	 */
	@Override
	public String getCommCodeListStr(Map<String, String> commonCode) throws Exception{

		StringBuilder codeTaglibStr = new StringBuilder(StringUtils.EMPTY);

		codeTaglibStr.append("");
		codeTaglibStr.append(CommonConstants.COLONE);
		codeTaglibStr.append("전체");
		codeTaglibStr.append(CommonConstants.SEMI_COLONE);

		for( String code : commonCode.keySet() ) {
			codeTaglibStr.append(code);
			codeTaglibStr.append(CommonConstants.COLONE);
			codeTaglibStr.append(commonCode.get(code));
			codeTaglibStr.append(CommonConstants.SEMI_COLONE);
		}

		return codeTaglibStr.toString();
	}

	/**
	 * 주문내역 총 건수를 조회한다.
	 */
	@Override
	public int selectOrderDtlsListTotCnt(OrderDtlsVO seachVo) throws Exception {
		return orderDtlsMapper.selectOrderDtlsListTotCnt(seachVo);
	}

	/**
	 * 주문내역 리스트를 조회한다.
	 */
	@Override
	public List<OrderDtlsVO> selectOrderDtlsList(OrderDtlsVO seachVo) throws Exception {
		return orderDtlsMapper.selectOrderDtlsList(seachVo);
	}

	/**
	 * 해당 주문번호의 배차수를 조회한다.
	 */
	@Override
	public List<Map<String, Object>> selectDlvyOdr(String orderNo) throws Exception {
		return orderDtlsMapper.selectDlvyOdr(orderNo);
	}

	/**
	 * 해당 배차수의 배송상세 정보를 조회한다.
	 */
	@Override
	public DlvyDetailVO selectDlvyDetail(Map<String, Object> orderInfo) throws Exception {
		DlvyDetailVO vo = orderDtlsMapper.selectDlvyDetail(orderInfo);

		if (StringUtils.isNotBlank(vo.getDrverTlphonNo())) {
			vo.setDrverTlphonNo(CryptoUtil.decryptAES256(vo.getDrverTlphonNo()));
		}

		if (StringUtils.isNotBlank(vo.getReceptEntrpsMoblphonNo())) {
			vo.setReceptEntrpsMoblphonNo(CryptoUtil.decryptAES256(vo.getReceptEntrpsMoblphonNo()));
		}

		return vo;
	}

	/**
	 * 지급확인서 데이터를 조회한다.
	 */
	@Override
	public OrderDtlsClaimVO selectCanclCnfrmnInfo(OrderDtlsVO vo) throws Exception {
		return orderDtlsMapper.selectCanclCnfrmnInfo(vo);
	}

	/**
	 * 지급확인서 상세 데이터 조회
	 */
	@Override
	public OrderDtlsClaimVO selectCanclCnfrmnDtl(OrderDtlsVO vo) throws Exception {
		return orderDtlsMapper.selectCanclCnfrmnDtl(vo.getOrderNo());
	}

	@Override
	public List<Map<String, Object>> selectPcCalcBasis(String canclExchngRtngudNo) throws Exception {
		return orderDtlsMapper.selectPcCalcBasis(canclExchngRtngudNo);
	}

	/**
	 *	매매계약서 데이터를 조회한다.
	 */
	@Override
	public OrderDtlsVO selectContractsInfo(OrderDtlsVO vo) throws Exception {
		return orderDtlsMapper.selectContractsInfo(vo);
	}

	@Override
	public OrderDtlsVO selectOrderDtls(OrderDtlsVO vo) throws Exception {
		// 특정 주문번호에 대한 주문 정보를 가져오기 위해, 쿼리문 조건에 필요한 데이터 추가
		vo.setOrderNoType("01");
		vo.setEntrpsNo(userInfoUtil.getEntripsNo());
		
		OrderDtlsVO orderDtls = orderDtlsMapper.selectOrderDtls(vo);
		
		// 24-07-08 변경사항 : 중도 상환 처리를 위한 로직 추가
		if(!Collections.isEmpty(vo.getMdstrmRepySnList())				// 파라미터로 받아온 데이터 객체에 중도 상환 순번 목록이 존재하거나 
				|| StringUtils.equals(vo.getAditAmountRepyAt(), "Y")) {	// 									추가 금액 상환 여부가 Y 값이면
			// 1. 미 결제 금액 변수 선언 
			long unSetleAmount = 0;
			
			// 2. 중도 상환 순번 목록이 존재하면, 해당 중도 상환 순번에 해당하는 입금 요청 금액(RCPMNY_REQUST_AMOUNT)의 총 합을 조회하여 더하기
			if(!Collections.isEmpty(vo.getMdstrmRepySnList())) {
				vo.setMrtggNo(orderDtls.getMrtggNo());
				unSetleAmount += orderDtlsMapper.getTotRcpmnyRequstAmount(vo);
			}
			
			// 3. 추가 금액 상환 여부가 Y 값이면, 기존에 조회된 데이터(orderDtls) 중, 추가 금액(aditAmount) 값을 가져와서 더하기
			if(StringUtils.equals(vo.getAditAmountRepyAt(), "Y")) {
				unSetleAmount += orderDtls.getAditAmount();
			}
			
			// 4. 반환해줄 결과값 객체에 위에서 계산된 미 결제 금액을 세팅
			orderDtls.setUnSetleAmount(BigDecimal.valueOf(unSetleAmount));
		}
		
		return orderDtls;
	}
}
