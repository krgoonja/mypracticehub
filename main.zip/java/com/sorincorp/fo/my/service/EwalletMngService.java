/**
 *
 */
package com.sorincorp.fo.my.service;

import java.text.ParseException;
import java.util.List;

import com.sorincorp.fo.my.model.EwalletMngVO;

/**
 * EwalletMngService.java
 * @version
 * @since 2021. 9. 24.
 * @author srec0009
 */
public interface EwalletMngService {

	/**
	 * <pre>
	 * 처리내용: 이월렛 환불 요청 내역 조회
	 * </pre>
	 * @date 2021. 9. 24.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 24.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param ewalletMngVO
	 * @return
	 */
	List<EwalletMngVO> selectRefndRequstDtls(EwalletMngVO ewalletMngVO);

	/**
	 * <pre>
	 * 처리내용: 이월렛 내역 조회
	 * </pre>
	 * @date 2021. 9. 24.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 24.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param ewalletMngVO
	 * @return
	 */
	List<EwalletMngVO> selectEwalletMng(EwalletMngVO ewalletMngVO);
	
	/**
	 * <pre>
	 * 처리내용: 이월렛 엑셀용 내역 조회
	 * </pre>
	 * @date 2022. 06. 28.
	 * @author sumin95
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 06. 28.			sumin95				최초작성
	 * ------------------------------------------------
	 * @param ewalletMngVO
	 * @return
	 */
	List<EwalletMngVO> selectExcelEwalletMng(EwalletMngVO ewalletMngVO);

}
