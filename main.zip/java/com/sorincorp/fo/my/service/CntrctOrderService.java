package com.sorincorp.fo.my.service;

import java.util.List;

import com.sorincorp.fo.my.model.CntrctOrderBasVO;
import com.sorincorp.fo.my.model.CntrctOrderDtlVO;
import com.sorincorp.fo.my.model.CntrctOrderMtDtlVO;

/**
 * 계약 발주 서비스
 * @author srec0051
 *
 */
public interface CntrctOrderService {

	/**
	 * <pre>
	 * 계약 발주 기본 조회
	 * </pre>
	 * @date 2023. 10. 11.
	 * @author srec0051
	 * @param paramVo
	 * @return
	 */
	CntrctOrderBasVO selectCntrctOrderInfo(CntrctOrderBasVO paramVo) throws Exception;

	/**
	 * <pre>
	 * 계약 발주 상세 조회
	 * </pre>
	 * @date 2023. 10. 11.
	 * @author srec0051
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	List<CntrctOrderDtlVO> selectListCntrctOrderDtl(CntrctOrderDtlVO paramVo) throws Exception;

}
