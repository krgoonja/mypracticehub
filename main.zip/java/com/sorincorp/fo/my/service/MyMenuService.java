package com.sorincorp.fo.my.service;

import java.util.List;

import com.sorincorp.fo.my.model.MyPageMenuVO;

public interface MyMenuService {

	/**
	 * <pre>
	 * 처리내용: 메뉴 리스트 조회
	 * </pre>
	 * @date 2021. 9. 8.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 8.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param authorNo
	 * @return
	 */
	//public List<MyPageMenuVO> selectMenuList(String authorNo);
	public List<MyPageMenuVO> selectMenuList();
}
