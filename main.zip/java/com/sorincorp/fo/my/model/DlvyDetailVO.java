package com.sorincorp.fo.my.model;

import java.io.Serializable;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class DlvyDetailVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 124493570525070036L;
	/* 주문_배송 차수 BL 상세, 주문_배송 차수 기본, 주문_주문 상세, 물류_창고 정보 기본, 주문_배송지 기본 */
	/**
     * 배송 차수
    */
    private int dlvyOdr;
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * OMS 주문 번호(배송번호)
     */
    private String omsOrderNo;
    /**
     * 계획 번호
     */
    private String planNo;
    /**
     * 출고 완료 일시
    */
    private String dlivyComptDt;
    /**
     * 기사 서명 등록 일시(인수완료일)
    */
    private String articlSignRegistDt;
    /**
     * 기사 서명 파일 구분 코드
    */
    private String articlSignFileSeCode;
    /**
     * 기사 서명 파일 URL
    */
    private String articlSignFileUrl;
    /**
     * 배송 진행 상태 코드
    */
    private String dlvyProgrsSttusCode;
    /**
     * 배송 수단 코드
    */
    private String dlvyMnCode;
    /**
     * 배송 수단 코드
     */
    private String dlvyMnNm;
    /**
     * 납기 예정 일자
    */
    private String dedtPrearngeDe;
    /**
     * 차량 그룹 코드
     */
    private String vhcleGroupCode;
    /**
     * 차량 그룹명
     */
    private String vhcleGroupNm;
    /**
     * 운송 회사명
    */
    private String trnsprtCmpnyNm;
    /**
     * 차량 번호
    */
    private String vhcleNo;
    /**
     * 운전자 명
    */
    private String drverNm;
    /**
     * 운전자 전화 번호
    */
    private String drverTlphonNo;
    /**
     * 창고 코드
    */
    private String wrhousCode;
    /**
     * 창고 명
     */
    private String wrhousNm;
    /**
     * 창고 주소
     */
    private String wrhousAdres;
    /**
     * 창고 담당자
    */
    private String wrhousCharger;
    /**
     * 창고 담당자 전화 번호
    */
    private String wrhousChargerTlphonNo;
    /**
     * 수취 주소
     */
    private String receptAdres;
    /**
     * 수취 업체 담당자 명
    */
    private String receptEntrpsChargerNm;
    /**
     * 수취 업체 휴대폰 번호
    */
    private String receptEntrpsMoblphonNo;
    /**
     * 배송 요청 내용
    */
    private String dlvyRequstCn;
    /**
     * 금속 명
    */
    private String metalNm;
    /**
     * 상품 명
     */
    private String goodsNm;
    /**
     * 브랜드 그룹명
     */
    private String brandGroupNm;
    /**
     * NET 확정 중량
    */
    private java.math.BigDecimal netDcsnWt;

}
