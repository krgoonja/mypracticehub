package com.sorincorp.fo.my.model;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * DeliveryRegionMngVO.java
 * 
 * @version
 * @since 2021. 8. 30.
 * @author srec0030
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class DeliveryRegionMngVO implements Serializable {
	/**
	*
	*/
	private static final long serialVersionUID = 3794177937949430064L;

	/**
	 * Search</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface Search {
	};

	/**
	 * InsertAndUpdate</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface InsertAndUpdate {
	};

	public interface Insert {
	};

	public interface Update {
	};

	public interface Delete {
	};

	/****** JAVA VO CREATE : MB_DLVRG_BAS(회원_배송지 기본) ******/
	/**
	 * 회원 번호
	 */
	private String mberNo;
	/**
	 * 배송지 번호
	 */
	@NotEmpty(groups = Search.class, message = "배송지 번호가 존재하지 않습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Update.class, message = "배송지 번호가 존재하지 않습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Delete.class, message = "배송지 번호가 존재하지 않습니다.") // /message/validation.properties 에 등록된 메시지
	private String dlvrgNo;
	/**
	 * 배송지 구분 상세 순번
	 */
	private String dlvrgSeDetailSn;
	/**
	 * 기본 배송지 여부
	 */
	private String bassDlvrgAt;
	/**
	 * 배송지 명
	 */
	@Size(groups = InsertAndUpdate.class, max = 100, message = "배송지명는 최대 입력값은 10자리 입니다.") // /message/validation.properties 에 등록된 메시지
	@Size(groups = Insert.class, max = 100, message = "배송지명는 최대 입력값은 10자리 입니다.") // /message/validation.properties 에 등록된 메시지
	@Size(groups = Update.class, max = 100, message = "배송지명는 최대 입력값은 10자리 입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = InsertAndUpdate.class, message = "배송지명은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Insert.class, message = "배송지명은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Update.class, message = "배송지명은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String dlvrgNm;
	/**
	 * 우편 번호
	 */
	@Size(groups = InsertAndUpdate.class, max = 6, message = "우편번호는 최대 입력값은 10자리 입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = InsertAndUpdate.class, message = "우편번호는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String postNo;
	/**
	 * 주소
	 */
	@Size(groups = InsertAndUpdate.class, max = 300, message = "주소는 최대30자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = InsertAndUpdate.class, message = "주소는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String adres;
	/**
	 * 상세 주소
	 */
	private String detailAdres;
	/**
	 * 도로명 주소
	 */
	@Size(groups = InsertAndUpdate.class, max = 300, message = "도로명주소는 최대30자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = InsertAndUpdate.class, message = "도로명주소는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String rnAdres;
	/**
	 * 도로명 상세 주소
	 */
	private String rnDetailAdres;

	/**
	 * 도로명 + 상세 주소
	 */
	private String rnAdresDetailAdres;

	private String adresDetailAdres;
	/**
	 * 좌표 위도
	 */
	private String crdntLa;
	/**
	 * 좌표 경도
	 */
	private String crdntLo;
	/**
	 * 법정동 코드
	 */
	private String legaldongCode;
	/**
	 * 배송지 담당자
	 */
	@Size(groups = InsertAndUpdate.class, max = 100, message = "배송지 담당자는 최대10자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	@Size(groups = Insert.class, max = 100, message = "배송지 담당자는 최대10자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	@Size(groups = Update.class, max = 100, message = "배송지 담당자는 최대10자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = InsertAndUpdate.class, message = "배송지 담당자는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Insert.class, message = "배송지 담당자는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Update.class, message = "배송지 담당자는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String dlvrgCharger;
	/**
	 * 배송지 담당자 연락처
	 */
	@Size(groups = InsertAndUpdate.class, max = 30, message = "배송지 담당자 연락처는 최대30자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	@Size(groups = Insert.class, max = 30, message = "배송지 담당자 연락처는 최대30자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	@Size(groups = Update.class, max = 30, message = "배송지 담당자 연락처는 최대30자리 이상 입력 할 수 없습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = InsertAndUpdate.class, message = "배송지 담당자 연락처는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Insert.class, message = "배송지 담당자 연락처는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Update.class, message = "배송지 담당자 연락처는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String dlvrgChargerCttpc;
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;

	/****** JAVA VO CREATE : MB_DLVRG_SE_DTL(회원_배송지 구분 상세) ******/
	/**
	 * 배송지 구분 명
	 */
	private String dlvrgSeNm;

	/**
	 * 업체번호
	 */
	@NotEmpty(groups = Insert.class, message = "업체번호가 유효하지 않습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Update.class, message = "업체번호가 유효하지 않습니다.") // /message/validation.properties 에 등록된 메시지
	private String entrpsNo;
	/**
	 * 엑셀다운여부
	 */
	private String excelYn;

	/**
	 * 순번
	 */
	private String seq;

	/**
	 * 담당자 이메일
	 */
	private String dlvrgChargerEmail;

}
