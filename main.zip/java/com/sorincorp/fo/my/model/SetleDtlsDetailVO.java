package com.sorincorp.fo.my.model;

import lombok.Data;

@Data
public class SetleDtlsDetailVO {

	/** 주문번호 */
	private String orderNo;
	/** 결제방식코드 */
	private String setleMthdCode;
	/** 결제방식상세코드 */
	private String setleMthdDetailCode;

	/** 순번 */
	private int rownum;
	/** 유형 */
	private String delngSe;
	/** 결제방식 */
	private String setleMthd;	//
	/** 결제수단 */
	private String setleMn;
	/** 결제일시 */
	private String delngDt;
	/** 결제금액 */
	private long delngAmount;
	/** 미납금액 (판매가 - 결제금액) */
	private long unSetleAmount;
	/** 주문 판매가 */
	private long slepc;
	/** 적요 */
	private String sumry;

	/** 회원번호 */
	private String mberNo;
	/** 업체번호 */
	private String entrpsNo;
}
