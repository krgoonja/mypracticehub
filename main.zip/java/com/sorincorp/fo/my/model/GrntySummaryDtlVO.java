/**
 *
 */
package com.sorincorp.fo.my.model;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.annotation.MaskingClass;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * GrntySummaryDtlVO.java
 * @version
 * @since 2022. 9. 29.
 * @author srec0073
 */
@Data
@EqualsAndHashCode(callSuper=false)
@Validated
@MaskingClass
public class GrntySummaryDtlVO {
	/** 보증 기한 시작 일자 */
	private String grntyTmlmtBeginDe;
	/** 보증 기한 종료 일자 */
	private String grntyTmlmtEndDe;
	/** 요구매출액 */
	private String demandRvamt;
	/** 누적매출액 */
	private String realOccrrncMrtggRvamt;
	/** 달성률 */
	private double achivRate;
	/** 보증수수료 */
	private String mrtggGrntyCnfirmIrncf;
	/** 지원금액 */
	private String sorinCtBndAmount;
	/** 달성금액 */
	private String presvAmount;
	/** 남은금액 */
	private String remainAmount;
}
