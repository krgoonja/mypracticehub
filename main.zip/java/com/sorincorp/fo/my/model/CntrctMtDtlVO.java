package com.sorincorp.fo.my.model;

import lombok.Data;

@Data
public class CntrctMtDtlVO {
	/******  JAVA VO CREATE : CN_CNTRCT_MT_DTL(계약_계약 월 상세)                                                                            ******/
    /**
     * 계약 번호
    */
    private String cntrctNo;
    /**
     * 계약 년월
    */
    private String cntrctYm;
    /**
     * 계약 년월 순번
    */
    private int cntrctYmSn;
    /**
     * 평균가 권역 대분류 코드
    */
    private String avrgpcDstrctLclsfCode;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 주문 중량
    */
    private int orderWt;
    /**
     * 프라이싱 확정 일시
    */
    private String pricingDcsnDt;
    /**
     * 프라이싱 확정 여부
    */
    private String pricingDcsnAt;
    /**
     * 라이브 구매 중량
    */
    private int livePurchsWt;
    /**
     * 평균가 구매 중량
    */
    private int avrgpcPurchsWt;
    /**
     * 통화 구분 코드
    */
    private String crncySeCode;
    /**
     * 프리미엄 가격
    */
    private long premiumPc;
    /**
     * QP 코드
    */
    private String qpCode;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    
    /**
     * 평균가 라이브 구매 가능 중량
     */
    private long avrgpcLiveWt;
    
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 총 주문 중량
     */
    private long totOrderWt;
    /**
     * 프라이싱 확정기한
     */
    private String pricingDcsnLmt;
    /**
     * 프라이싱 확정기한차이(D-Day의 Day값)
     */
    private String pricingDcsnLmtDiff;
    /**
     * 발주 처리 기한
     */
    private String orderProcessLmt;
    /**
     * 권역 대분류 코드
     */
    private String dstrctLclsfCode;
    /**
     * 권역 대분류 명
     */
    private String dstrctLclsfNm;
    /**
     * 브랜드 그룹 명
     */
    private String brandGroupNm;
    /**
     * 브랜드 명
     */
    private String brandNm;
    
    /**
     * 원산지
     */
    private String nationFlagImgUrl;
    
    /* 상품(재고) 할당 정보 관련 */
    /**
     * 재고 할당 구분 코드
     */
    private String invntryAsgnSeCode;
    /**
     * 구매 중량
     */
    private int purchsWt;
    /**
     * 할당 중량
     */
    private int asgnWt;
    /**
     * 미할당 중량
     */
    private int unasgnWt;
    /**
     * 발주 중량
     */
    private int orderingWt;
    /**
     * 미발주 중량
     */
    private int unorderingWt;
    /**
     * 최대 발주 가능 중량
     */
    private int mxmmOrderingPossWt;
    /**
     * 신규 할당 여부
     */
    private boolean newAsgnAt;
    /**
     * 결제 중량
     */
    private int setleWt;
    /**
     * 배송 중량
     */
    private int dlvyWt;
    /**
     * 배송 완료 중량
     */
    private int dlvyComptWt;
    
    /* 상품(재고) 할당 내역 관련 */
    
    /**
     * 판매 가능일
     */
    private String slePossde;
    /**
     * 입고 [예정일자|일자]
     */
    private String wrhousngDe;
    /**
     * 입고 예정 재고 여부
     */
    private boolean wrhousngPrearngeInvntryAt;
    /**
     * 성적서 조회 가능 여부
     */
    private boolean screofeFileOpenAt;
    /**
     * 할당된 일자(시간)
     */
    private String asgnDt;
    /**
     * 누적 할당 톤 수
     */
    private int accmltAsgnWt;
    /**
     * 할당된 총 톤 수
     */
    private int totAsgnedWt;
    
    /**
     * 할당 이벤트 유형 코드 
     */
    private String asgnEventTyCode;
    
    /**
     * 할당 이벤트 중량
     */
    private Integer asgnEventWt;
}
