package com.sorincorp.fo.my.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.order.model.CommOrOrderFtrsBasVO;
import com.sorincorp.comm.order.model.ItPurchsInfoBas;
import com.sorincorp.comm.order.model.MbDlvrgBasVO;
import com.sorincorp.comm.order.model.OrOrderDtlVO;
import com.sorincorp.comm.order.model.OrPricingBasVO;
import com.sorincorp.comm.order.model.OrderDtlsClaimVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.fo.pd.model.ItPremiumBasVO;

import lombok.Data;

@Data
public class ClaimModel {
	
	/** 프라이싱 번호 **/
	private String pricingNo;
	
	/** 판매 가격 실시간 순번 **/
	private long slePcRltmSn;
	
	/** 화면단 가격 **/
	private long slepcView;
	
	/** 화면단 가격 **/
	private long goodsUntpcView;
	
	/** 프리미엄 번호 **/
	private String premiumNo;
	
	/** 금속코드 **/
    private String metalCode;
	
	/** 아이템 순번 **/
    private Integer itmSn;
	
	/** 권역 대분류 코드 **/
    private String dstrctLclsfCode;
	
	/** 브랜드 그룹 코드 **/
    private String brandGroupCode;

    /** 브랜드 코드 **/
    private String brandCode;
	
	/** 주문 중량 **/
	private int orderWt;
	
	/** 배송지 번호 **/
    private String dlvrgNo;
    
    /** 접수 매체 구분 코드 **/
    private String rceptMediaSeCode;
    
    /** 판매 방식 코드 **/
    private String sleMthdCode;
    
    /** 배송 수단 코드 **/
    private String dlvyMnCode;
    
    /** 출고 요청 일자 **/
    private String dlivyRequstDe;
	
    /** 배송 요청 사항 **/
    private String dlvyRequstCn;
    
	/** 주문번호 **/
	private String orderNo;
	
	/** 주문 상세 번호 **/
	private String orderSn;
	
	/** 주문번호 **/
	private String setleNo;
	
	/** OMS 접수 번호 **/
	private String omsRceptNo;
	
	/** 주문 상태 코드 **/
	private String orderSttusCode;
	
	/** 주문 실패 사유 **/
	private String orderFailrResn;
	
	/** 취소교환 반품번호 **/
	private String canclExchngRtngudNo;
	
	/** 선물 요청 주문 번호 **/
	private String ftrsRequstOrderNo;
	
	/** 선물 원 요청 주문 번호 **/
	private String requstWonOrderNo;
	
	/** 선물환 요청 주문 번호 **/
	private String fshgRequstOrderNo;
	
	/** Ewallet 가상 계좌 번호 **/
	private String ewalletAcnutNo;
	
	/** 로그인 유저 No **/
	private String mberNo;
	
	/** 로그인 유저 업체 No **/
	private String entrpsNo;
	
	/** 로그인 업체 등급 번호 **/
	private String  entrpsGradNo;
	
	/** 로그인 유저 ID **/
	private String mberId;
	
	/** 총 번들 수량 **/
	private int totBundleQy;
	
	/** 총 고객 주문 중량 **/
	private int totCstmrOrderWt;
	
	/** 총 실제 주문 중량 **/
	private int totRealOrderWt;
	
    /** 상품 단가 **/
    private long goodsUntpc;
    
    /** 주문 가격 **/
    private long orderPc;
    
    /** 중량 변동금 **/
    private long wtChangegld;
    
    /** 공급가 **/
    private long splpc;
    
    /** 부가세 **/
    private long vat;
    
    /** 판매가 **/
    private long slepc;
    
    /** 예상배송비 **/
    private long expectDlvrf;
    
    /** 삼성성물 계좌번호 **/
	private String requstAcnutNo;
	
	/** 요청 주문 단가 **/
	private String requstOrderUntpc;
	
	/** BL QY 수량 **/
	private int requstOrderQy;
	
	/** BL PO 테이블 **/
	private ItPurchsInfoBas itPurchsInfoBas;

	/** 실시간 판매가격 정보 **/
	private PrSelVO prSelVO;
	
	/** 프라이싱 기본 **/
	private OrPricingBasVO orPricingBas;
	
	/** 프리미엄 가격 정보 **/
	private ItPremiumBasVO itPremiumBas;
	
	/** 배송지 및 회원 기본 **/
	private MbDlvrgBasVO mbDlvrgBas;
	
	/** 최적의 BL 리스트 **/
	private List<ItemPriceMatchingBlInfoVO> blList;
	
	/** 최적의 BL 상세 **/
	private ItemPriceMatchingBlInfoVO blDetail;
	
	/** 고객 주문 수량 **/
    private int cstmrOrderWt;
    
    /** 실제 주문 수량 **/
    private int realOrderWt;
    
    /** 번들 수량 **/
    private int bundleQy;

	/** 삼성선물 키 값 리스트 **/
	private List<String> ftrnNoList;
	
	/** 삼성선물 취소 키 값 리스트 **/
	private List<String> cancelFtrnNoList;
	
	/** 삼성선물 실패 리스트 **/
	private List<CommOrOrderFtrsBasVO> samsungFailList;
	
	/** 재고 BL No **/
    private String orderInvntryBlNo;
	
    /** 재고 실제 번들 이론 중량 **/
    private double orderInvntry;
    
    /** 재고 실제 번들 수량 **/
    private int orderBundleInvntry;

    /** 원주문 BL 목록 */
    private List<OrOrderDtlVO> orderBlList;
    /** 원주문 BL 상세 */
    private OrOrderDtlVO orderBlDetail;
    /** 클레임 정보 */
    private OrderDtlsClaimVO claimDetail;
    
}
