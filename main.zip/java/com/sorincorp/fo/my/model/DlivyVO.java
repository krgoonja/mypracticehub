package com.sorincorp.fo.my.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class DlivyVO extends CommonVO {

	/**
     *
     */
    private static final long serialVersionUID = 7118316233413419696L;
    /* 주문_주문 상세 */
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 주문 순번
    */
    private String orderSn;
    /**
     * 판매 가능일 계산
     */
    private String slePossdeCnt;
    
    /**
     * BL 번호
    */
    private String blNo;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 아이템 명
    */
    private String itmNm;
    /**
     * 창고 코드
    */
    private String wrhousCode;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 그룹 코드
     */
    private String brandGroupNm;
    /**
     * 브랜드 명
     */
    private String brandNm;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 상품 명
    */
    private String goodsNm;
    /**
     * 실제 주문 수량
    */
    private int realOrderWt;
    /**
     * 번들 수량
    */
    private int bundleQy;
    /**
     * 확정 중량
    */
    private java.math.BigDecimal dcsnWt;
    /**
     * 공급가
    */
    private java.math.BigDecimal splpc;
    /**
     * 부가세
    */
    private java.math.BigDecimal vat;
    /**
     * 판매가
    */
    private java.math.BigDecimal slepc;
    /**
     * 취소 수량
    */
    private int canclQy;
    /**
     * 교환 수량
    */
    private int exchngQy;
    /**
     * 반품 수량
    */
    private int rtngudQy;
    /**
     * OMS 주문 번호
    */
    private String omsOrderNo;
    /**
     * 선물 요청 주문 번호
    */
    private String ftrsRequstOrderNo;
    /**
     * 선물환 요청 주문 번호
    */
    private String fshgRequstOrderNo;
    /**
     * 단위 명
     */
    private String sleUnitNm;
    /* 물류_창고 정보 기본           */
    /**
     * 창고 명
    */
    private String wrhousNm;
    /**
     * 대분류 출고 권역 코드
    */
    private String lclsfDlivyDstrctCode;
    /**
     * 대분류 출고 권역명
     */
    private String lclsfDlivyDstrctNm;
    /**
     * 창고 도로명 전체 주소
    */
    private String wrhousAdres;
    /**
     * 창고 담당자
    */
    private String wrhousCharger;
    /**
     * 창고 담당자 전화 번호
    */
    private String wrhousChargerTlphonNo;

    /** 차량등록 가능 여부 */
    private String vhcleRegistPossYn;
    /** BL별 차량 등록 수 */
    private int vhcleCnt;
    /** BL별 차량 수 */
    private int totVhcleCnt;

    /* 셀 머지용 */
    /**
     *
    */
    private String rowNum;
    /**
     *
    */
    private String partCnt;

}
