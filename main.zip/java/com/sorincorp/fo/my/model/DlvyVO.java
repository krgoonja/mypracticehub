package com.sorincorp.fo.my.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class DlvyVO extends CommonVO {

	/**
	 *
	 */
	private static final long serialVersionUID = -2605525188450418397L;

	/* 배송지 기본 */
	/**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 취소 교환 반품 번호
    */
    private String canclExchngRtngudNo;
    /**
     * 주문 배송지 번호
    */
    private String orderDlvrgNo;
    /**
     * 주문 배송지 번호 채번(+1)
     */
    private String orderDlvrgNoKey;
    /**
     * 배송 구분 코드
    */
    private String dlvySeCode;
    /**
     * 배송 수단 코드
    */
    private String dlvyMnCode;
    /**
     * 배송 수단 명
     */
    private String dlvyMnNm;
    /**
     * 배송 차량 적재 중량
    */
    private int dlvyVhcleLdadngWt;
    /**
     * 차량 그룹 코드
    */
    private String vhcleGroupCode;
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    /**
     * 출고 요청 일자
    */
    private String dlivyRequstDe;
    /**
     * 변경할 출고 요청 일자
    */
    private String newDlivyRequstDe;
    /**
     * 영업일 계산을 위한 날짜일수
    */
    private int dayCnt;
    /**
     * 우편번호
    */
    private String postcode;
    /**
     * 배송지 명
     */
    private String dlvrgNm;
    /**
     * 수취 업체 명
    */
    private String receptEntrpsNm;
    /**
     * 수취 업체 우편 번호
    */
    private String receptEntrpsPostNo;
    /**
     * 수취 업체 주소
    */
    private String receptEntrpsAdres;
    /**
     * 수취 업체 상세 주소
    */
    private String receptEntrpsDetailAdres;
    /**
     * 수취 업체 도로명 주소
    */
    private String receptEntrpsRnAdres;
    /**
     * 수취 업체 도로명 상세 주소
    */
    private String receptEntrpsRnDetailAdres;
    /**
     * 업체 전체 주소
     */
    private String receptAdres;
    /**
     * 수취 업체 법정동 코드
    */
    private String receptEntrpsLegaldongCode;
    /**
     * 수취 업체 휴대폰 번호
    */
    private String receptEntrpsMoblphonNo;
    /**
     * 수취 업체 담당자 명
    */
    private String receptEntrpsChargerNm;
    /**
     * 수취 업체 담당자 이메일
     */
    private String receptEntrpsChargerEmail;
    /**
     * 배송 요청 내용
    */
    private String dlvyRequstCn;
    /**
     * 관리자 배송 요청 내용
    */
    private String mngrDlvyRequstCn;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 등록자 아이디
    */
    private String mberId;
    /**
     * 등록자 업체NO
     */
    private String entrpsNo;

    /* 주문_배송 차수 기본 */
    /**
     * 배송 차수
    */
    private int dlvyOdr;
    /**
     * OMS 주문 번호
    */
    private String omsOrderNo;
    /**
     * 배송 진행 상태 코드
    */
    private String dlvyProgrsSttusCode;
    /**
     * 계획 번호
    */
    private String planNo;
    /**
     * 납기 예정 일자
    */
    private java.sql.Date dedtPrearngeDe;
    /**
     * 운송 회사 코드
    */
    private String trnsprtCmpnyCode;
    /**
     * 운송 회사 명
    */
    private String trnsprtCmpnyNm;
    /**
     * 운송 회사 전화 번호
    */
    private String trnsprtCmpnyTlphonNo;
    /**
     * 배차 일시
    */
    private java.sql.Timestamp caralcDt;
    /**
     * 차량 번호
    */
    private String vhcleNo;
    /**
     * 운전자 코드
    */
    private String drverCode;
    /**
     * 운전자 명
    */
    private String drverNm;
    /**
     * 운전자 전화 번호
    */
    private String drverTlphonNo;
    /**
     * 실제 배송 비용
    */
    private java.math.BigDecimal realDlvyCt;
    /**
     * 확정 배송 비용
    */
    private java.math.BigDecimal dcsnDlvyCt;
    /**
     * 이동 거리
    */
    private String mvmnDstnc;
    /**
     * 배송 완료 일자
    */
    private java.sql.Date dlvyComptDe;
    /**
     * 상차 완료 일자
    */
    private java.sql.Date loadComptDe;
    /**
     * 마지막 차수 여부
    */
    private String lastOdrAt;
    /**
     * 창고 코드
    */
    private String wrhousCode;
    /**
     * 상차 하차 비용
    */
    private java.math.BigDecimal loadGffCt;
    /**
     * 보관 비용
    */
    private java.math.BigDecimal cstdyCt;
    /**
     * 조작 비용
    */
    private java.math.BigDecimal hndlCt;
    /**
     * 왕복 비용
    */
    private java.math.BigDecimal shuttleCt;
    /**
     * 검수 비용
    */
    private java.math.BigDecimal acptncCt;
    /**
     * 할증 비용
    */
    private java.math.BigDecimal totAmtCt;
    /**
     * 조출 비용
    */
    private java.math.BigDecimal earlyCt;
    /**
     * 인도 서명 정보 파일 URL
    */
    private String delySignInfoFileUrl;
    /**
     * 인도 서명 정보 등록 일시
    */
    private java.sql.Timestamp delySignInfoRegistDt;
    /**
     * 인수 서명 정보 파일 URL
    */
    private String undtakeSignInfoFileUrl;
    /**
     * 인수 서명 정보 등록 일시
    */
    private java.sql.Timestamp undtakeSignInfoRegistDt;

    /* 주문_주문 상세 */
    /**
     * 주문 순번
    */
    private String orderSn;
    /**
     * BL 번호
    */
    private String blNo;
    /**
     * BL 번호 리스트
     */
    private String[] blArr;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 주문 수량
    */
    private int orderQy;
    /**
     * 번들 수량
    */
    private int bundleQy;

    /* 물류_창고 정보 기본 */
    /**
     * 창고 명
    */
    private String wrhousNm;
    /**
     * 창고 우편 번호
    */
    private String wrhousPostNo;
    /**
     * 창고 도로명 주소
    */
    private String wrhousAdres;
    /**
     * 창고 담당자
    */
    private String wrhousCharger;
    /**
     * 창고 담당자 전화 번호
    */
    private String wrhousChargerTlphonNo;

    /* 주문_배송 차수 진행 상태 상세     */

    /**
     * 배송지 수정 가능 여부
     */
    private String dlvrgUpdtPossYn;

}
