package com.sorincorp.fo.my.model;

import java.util.List;

import lombok.Data;

@Data
public class DeliveryDtlsVO {
	/**
	 * 주문 번호
	 */
	private String orderNo;
	/**
	 * 운송방식 (배송방식)
	 */
	private String dlvyMn;
	/**
	 * 출고상태
	 */
	private String dlvySttus;
	/**
	 * 주문중량 (총 실제 주문 중량)
	 */
	private int totRealOrderWt;
	/**
	 * 확정중량 (총 확정 중량)
	 * (소숫점 세 자리까지 표기하기 위해 String으로 선언)
	 */
	private String totDcsnWt;
	/**
	 * 번들수량 (총 번들 수량)
	 */
	private int totBundleQy;
	/**
	 * 확정번들 (총 확정 번들 수량)
	 */
	private int totDcsnBundleQy;
	/**
	 * 진행률
	 */
	private float dlvyProgress;
	/**
	 * 브랜드 이름
	 */
	private String brandNm;
	/**
	 * 물류센터 (창고 이름)
	 */
	private String wrhousNm;
	/**
	 * 배송 상세 내역 - 요청 정보 목록 (자차 배송일 시에만 사용)
	 */
	private List<DeliveryDetailDtlsVO> deliveryDetailDtlsRequstList;
	/**
	 * 배송 상세 내역 - 확정 정보 목록 (케이지 배송일 때 단독 상세 내역으로도 사용)
	 */
	private List<DeliveryDetailDtlsVO> deliveryDetailDtlsDcsnList;
	/**
	 * 인도지
	 */
	private String receptAdres;
	
	
	/** 검색 조건 */
	/**
	 * 검색 키워드(주문번호)
	 */
	private String keyword;
	/**
	 * 배송 수단
	 */
	private String dlvyMnCode;
	/**
	 * 출고상태 (화면에서 선택된 값들)
	 */
	private List<String> dlvySttusList;
	/**
	 * 기간조회 시작일
	 */
	private String searchDateFrom;
	/**
	 * 기간조회 종료일
	 */
	private String searchDateTo;
    /**
     * 조회 대상 처음 Index
     */
    private int startIndex = 1;
    /**
     * 조회 대상 마지막 Index
     */
    private int endIndex = 10;
    
    /**
     * 회원 번호
     */
    private String mberNo;
    /**
     * 업체 번호
     */
    private String entrpsNo;
    /**
     * 회원 구분 코드
     */
    private String memberSecode;
}
