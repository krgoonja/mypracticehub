package com.sorincorp.fo.my.model;

import java.util.List;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * 서류 관리 상세 VO.java
 * @version
 * @since 2021. 9. 13.
 * @author srec0054
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class PapersManageDetailVO extends CommonVO {
	
	private static final long serialVersionUID = -4762516788256478565L;

	/**주문 번호*/
	private String orderNo;
	
	/**주문 일자*/
	private String orderDe;
	
	/**회원 번호*/
	private String mberNo;
	
	/**회원 아이디*/
	private String mberId;
	
	/**업체 번호*/
	private String entrpsNo;
	
	/**사업자 등록 번호*/
	private String bsnmRegistNo;
	
	/**업체 대표자 명*/
	private String rprsntvNm;
	
	/**업체 등급 번호*/
	private String entrpsGradNo;
	
	/**접수 매체 구분 코드*/
	private String rceptMediaSeCode;
	
	/**판매 방식 코드*/
	private String sleMthdCode;
	
	/**판매 방식 명*/
	private String sleMthdNm;
	
	/**주문자 명*/
	private String ordrrNm;
	
	/**주문 업체 명*/
	private String orderEntrpsNm;
	
	/**주문 상태 코드*/
	private String orderSttusCode;
	
	/**주문 상태명*/
	private String orderSttusNm;
	
	/**주문 배송지 번호*/
	private String orderDlvrgNo;
	
	/**주문 배송비 번호*/
	private String orderDlvrfNo;
	
	/**문서 파일 경로*/
	private String docFileCours;
	
	/**금속 명*/
	private String metalNm;
	
	/**상품 명*/
	private String goodsNm;
	
	/**아이템 명*/
	private String itmNm;
	
	/**브랜드 명*/
	private String brandNm;
	
	/**브랜드 그룹명*/
	private String brandGroupNm;
	
	/**총 실제 주문 중량*/
	private String totRealOrderWt;
	
	/**총 번들 수량*/
	private String totBundleQy;
	
	/**총 확정 중량*/
	private String totDcsnWt;
	
	/**단위 명*/
	private String sleUnitNm;
	
	/**상품 단가*/
	private String goodsUntpc;
	
	/**상품가(상품 단가 * 주문수량)*/
	private String goodsPc;
	
	/**중량 변동금*/
	private String wtChangegld;
	
	/**공급가*/
	private String splpc;
	
	/**부가세*/
	private String vat;
	
	/**판매가*/
	private String slepc;
	
	/**예상 배송비*/
	private String expectDlvrf;
	
	/**E-Wallet*/
	private String ewalletAmount;
	
	/**E-Wallet 결제 완료 일시*/
	private String ewalletSetleComptDt;
	
	/**총 확정 금액(정산 금액)*/
	private String totDcsnOrderPc;
	
	/**총 확정 일시(정산 일시)*/
	private String totDcsnDt;
	
	/**환불 금액*/
	private String refndAmount;
	
	/**환불 금액 결제 완료 일시*/
	private String refndAmountSetleComptDt;
	
	/**대표 판매자*/
	private String repSeler;
	
	/**대표 사업자등록번호*/
	private String repSelerBsnmRegistNo;
	
	/**대표 이사명*/
	private String repSelerRprsntvNm;
	
	/**대표 소재지*/
	private String repSelerAdres;

	/**결제 수수료*/
	private String fee;
	
	/**서류관리 상세 조회 - 설명*/
	private String explan;
	
	/**BL 번호*/
	private String blNo;
	
	/**서류명*/
	private String papersNm;
	
	/**내용*/
	private String contents;
	
	/**발행일자*/
	private String publishDe;
	
	/**출고일자*/
	private String dlivyDe;
	
	/**상태-이론/탈리*/
	private String sttus;
	
	/**ozr 파일명*/
	private String ozNm;
	
	 /**파라미터 설정*/
	private String pCount;
	
	/**오즈 리포트 호출 파라미터*/
	private String param1;
	private String param2;
	private String param3;
	private String param4;
	private String param5;
    private String param6;
	private String tabDiv;
	private List<String> tabDivList;
	
	private String paramNm2;
    private String paramNm3;
    private String paramNm4;
    
    private String flag;
	
	/**성적서&패킹리스트*/
	/**성적서 파일 경로*/
	private String screofeFileCours;
	
	/**포장 리스트 파일 경로*/
	private String packngListFileCours;

	/**
	 * 대시보드
	 */
	/**업체명 한글*/
	private String entrpsnmKorean;
	
	/**이월렛 잔액*/
	private String ewalletBlce;
	
	/**입금 계좌 번호*/
	private String refndAcnutNo;
	
	/**주문완료*/
	private String orderCompt;
	
	/**배송지시*/
	private String dlvyDrct;
	
	/**배차중*/
	private String caralcing;
	
	/**배송중*/
	private String dlvying;
	
	/**배송완료*/
	private String dlvyCompt;
    
	/**권한 구분 코드*/
	private String memberSecode;
}//end class()
