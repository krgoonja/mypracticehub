package com.sorincorp.fo.my.model;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class CntrctOrderDtlVO {

	/******  JAVA VO CREATE : CN_CNTRCT_ORDER_DTL(계약_계약 발주 상세)                                                                       ******/
    /**
     * 계약 발주 번호
    */
    private String cntrctOrderNo;
    /**
	* 계약 번호
	*/
	private String cntrctNo;
	/**
	 * 계약 년월
	 */
	private String cntrctYm;
	/**
	 * 계약 년월 순번
	 */
	private int cntrctYmSn;
    /**
     * BL 번호
    */
    private String blNo;
    /**
     * 주문 중량
    */
    private long orderWt;
    /**
     * 번들 수량
    */
    private int bundleQy;
    /**
     * 번들 중량
    */
    private BigDecimal bundleWt;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    
    /**
	* 재고 할당 구분 코드
	*/
	private String invntryAsgnSeCode;
}
