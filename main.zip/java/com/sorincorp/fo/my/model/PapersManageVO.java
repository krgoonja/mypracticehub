package com.sorincorp.fo.my.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 *
 * 서류 관리 VO.java
 * @version
 * @since 2021. 9. 8.
 * @author srec0054
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class PapersManageVO extends CommonVO {

	private static final long serialVersionUID = 646539282129411140L;

	/**
	 * 조회 조건 
	 */
	
	/**시작일시*/
	private String searchStartDate;
	
	/**종료일시*/
	private String searchEndDate;
	
	/**탭 구분*/
	private String tabDiv;
	
	/**로그인 유저 번호*/
	private String mberNo;
	
	/**업체번호*/
	private String entrpsNo; 
	
	/**권한 구분 코드*/
	private String mberSttusCode; 
	
	/**주문번호*/
	private String searchOrderNo;
	
	
	/**
	 * 조회 리스트
	 */
	
	/**서류명*/
	private String papersNm;
	
	/**주문일자*/
	private String orderDe;
	
	/**주문번호*/
	private String orderNo;
	
	/**주문순번*/
	private String orderSn;
	
	/**취소교환반품 번호*/
	private String canclExchngRtngudNo;
	
	/**세금 계산서 분류 코드*/
	private String taxBillClCode;
	
	/**상태-이론/탈리*/
	private String sttus;
	
	/**서류*/
	private String papers;

	/**세금계산서 신청번호*/
	private String taxBillReqstNo;
	
	/**세금 계산서 신청 상세 순번*/
	private String taxBillReqstDetailSn;
	
	/**배송차수*/
	private String dlvyOdr;
	
	/**BL 번호*/
	private String blNo;
	
	/**인터페이스 순번*/
	private String intrfcSn;
	
	/**인터페이스 번호*/
	private String intrfcNo;
	
	/**창고 코드*/
	private String wrhousCode;
	
	/**견적서 번호*/
	private String estmtNo;
	
	/**계약서 번호*/
	private String cntrctNo;
	
	/**발생 순번*/
	private String occrrncSn;
	/**변동금 상태 코드*/
	private String pcChangegldSttusCode;
	
	/**
	 * 오즈 리토프
	 */
	
	/**파일 타입 구분*/
	private String fileType;
	
	/**
	 * 대시보드
	 */
	/**업체명 한글*/
	private String entrpsnmKorean;
	
	/**이월렛 잔액*/
	private String ewalletBlce;
	
	/**입금 계좌 번호*/
	private String refndAcnutNo;
	
	/**주문완료*/
	private String orderCompt;
	
	/**배송지시*/
	private String dlvyDrct;
	
	/**배차중*/
	private String caralcing;
	
	/**배송중*/
	private String dlvying;
	
	/**배송완료*/
	private String dlvyCompt;
    
	/**권한 구분 코드*/
	private String memberSecode;

	/**작성일자*/
	private String writingDe;
	
	/**브랜드 이름*/
	private String brandNm;
	
	/**성적서 URL*/
	private String screofeFileCours;
	
	/**패킹리스트 URL*/
	private String packngListFileCours;
	
	
}//end class()
