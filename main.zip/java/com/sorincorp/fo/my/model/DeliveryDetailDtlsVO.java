package com.sorincorp.fo.my.model;

import org.apache.commons.lang3.StringUtils;

import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.Data;

@Data
public class DeliveryDetailDtlsVO {
	/**
	 * BL 번호
	 */
	private String blNo;
	/**
	 * 차량 종류
	 */
	private String vhcleGroupNm;
	/**
	 * 차수 번들 수량
	 */
	private int odrBundleQy;
	/**
	 * 차량 입고일
	 */
	private String vhcleWrhousngDe;
	/**
	 * 상차 일시(yyyy-MM-dd HH:mm)
	 */
	private String pickDt;
	/**
	 * 배송 진행 상태
	 */
	private String dlvyProgrsSttus;
	
	/**
	 * 차량번호
	 */
	private String vhcleNo;
	/**
	 * 기사정보 - 이름
	 */
	private String drverNm;
	/**
	 * 기사정보 - 연락처
	 */
	private String drverTlphonNo;
	/**
	 * 출고일자
	 */
	private String dlivyComptDt;
	/**
	 * 출고 번들수
	 */
	private int totDcsnBundleQy;
	/**
	 * 확정중량
	 * (소숫점 세 자리까지 표기하기 위해 String으로 선언)
	 */
	private String totDcsnWt;
	/**
	 * 확정 정보 여부
	 * 자차배송 상세내역 중, 확정 정보인 Data Row 구분자
	 * Java Logic에서만 사용
	 */
	private boolean dcsnInfoAt;
	/**
	 * 계획 번호(케이지배송 - 배송 추적 시 사용)
	 */
	private String planNo;
	
	public void setDrverTlphonNo(String drverTlphonNo) {
		try {
			if (StringUtils.isNotBlank(drverTlphonNo)) {
				this.drverTlphonNo = StringUtil.formatPhone(CryptoUtil.decryptAES256(drverTlphonNo));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
