package com.sorincorp.fo.my.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class MyInvntryAlarmVO  implements Serializable{
	
	private static final long serialVersionUID = 6663401685354220421L;
	
	/******  JAVA VO CREATE : OP_INVNTRY_NTCN_SETUP_BAS(운영_재고_알림_설정_기본) ******/
     /**
     * 회원 번호
    */
    private String mberNo; 
     /**
     * 금속 코드
    */
    private String metalCode; 
     /**
     * 아이템 순번
    */
    private int itmSn; 
     /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode; 
    
	/** 출고권역 대분류 */
	private String dstrctLclsfNm;
    
	/**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode; 
    
	/** 브랜드 그룹명*/
	private String brandGroupNm;
	
	
	/** 브랜드명 */
	private String brandNm;
	
     /**
     * 브랜드 코드
    */
    private String brandCode; 
     /**
     * 재고수량
    */
    private int invntryqy; 
     /**
     * 업체 번호
    */
    private String entrpsNo; 
     /**
     * 사용 여부
    */
    private String useAt; 
     /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt; 
     /**
     * 삭제 여부
    */
    private String deleteAt; 
     /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId; 
     /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt; 
     /**
     * 최종 변경자 아이디
    */
    private String lastChangerId; 
     /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt; 
    
    /**
     * 프라이싱 번호
     */
    private String pricingNo;
    
    /**
     * 배송 수단 코드
     */
    private String dlvyMnCode;
    
	/** 배송구분명 */
	private String dlvyMnNm;
 
	/**
	*	상품명 
	*/
	private String goodsNm;
	
	/**
	*	판매 방식 코드 
	*/
	private String sleMthdCode;
}
