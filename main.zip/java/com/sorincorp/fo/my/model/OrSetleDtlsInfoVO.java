package com.sorincorp.fo.my.model;

import lombok.Data;

/**
 * OrSetleDetailInfo.java : 결제상세내역 VO
 * @version
 * @since 2022. 8. 5.
 * @author srec0066
 */
@Data
public class OrSetleDtlsInfoVO {

	/** 주문 번호 */
    private String orderNo;
    /** 결제 번호 */
    private String setleNo;
    /** 결제일시 */
    private java.sql.Timestamp setleComptDt;
    /** 결제일(yyyy-MM-dd)*/
    private String setleComptDe;
    /** 결제액 */
    private long delngAmount;
    /** 적요 */
    private String sumry;

    /** 타입 */
    private String seCode;
    /** 결제 방식 코드 */
    private String setleMthdCode;
    /** 결제 방식 상세 코드 */
    private String setleMthdDetailCode;
    
    /**
     * 결제 정보 최하단 테이블 헤더 정보
     */
    private String header;
    
    /**
     * 최초 발생 일자(발생 일자 표현에 사용)
     */
    private String frstRegistDe;
}
