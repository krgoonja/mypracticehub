package com.sorincorp.fo.my.model;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * OrderAvrgVO.java
 * @version
 * @since 2023. 12. 8.
 * @author srec0053
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class OrderAvrgVO extends CommonVO {
	private static final long serialVersionUID = 771171209843278561L;
	/******  JAVA VO CREATE : CN_ESTMT_BAS(계약_견적 기본)                                                                                   ******/
    /**
     * 견적 번호
    */
    private String estmtNo;
    /**
     * 견적 접수 일시
    */
    private String estmtRceptDt;
    /**
     * 견적 상태 코드
    */
    private String estmtSttusCode;
    /**
     * 견적 관리자 등록 여부
    */
    private String estmtMngrRegistAt;
    /**
     * 회원 번호
    */
    private String mberNo;
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 주문자 명
    */
    private String ordrrNm;
    /**
     * 주문자 휴대폰 번호
    */
    private String ordrrMoblphonNo;
    /**
     * 주문자 이메일
    */
    private String ordrrEmail;
    /**
     * 주문 업체 명
    */
    private String orderEntrpsNm;
    /**
     * 주문 개월 수 코드
    */
    private String orderMonthCoCode;
    /**
     * 제안 표제
    */
    private String propseTitle;
    /**
     * 제안 금속 코드
    */
    private String propseMetalCode;
    /**
     * 제안 아이템 순번
    */
    private int propseItmSn;
    /**
     * 제안 아이템 텍스트
    */
    private String propseItmText;
    /**
     * 제안 사양 자동 여부
    */
    private String propseSpecAtmcAt;
    /**
     * 제안 사양 코드
    */
    private String propseSpecCode;
    /**
     * 제안 사양 텍스트
    */
    private String propseSpecText;
    /**
     * 제안 브랜드 자동 여부
    */
    private String propseBrandAtmcAt;
    /**
     * 제안 브랜드 코드
    */
    private String propseBrandCode;
    /**
     * 제안 브랜드 텍스트
    */
    private String propseBrandText;
    /**
     * 제안 중량 자동 여부
    */
    private String propseWtAtmcAt;
    /**
     * 제안 중량 텍스트
    */
    private String propseWtText;
    /**
     * 제안 계약 기간 자동 여부
    */
    private String propseCntrctPdAtmcAt;
    /**
     * 제안 계약 기간 텍스트
    */
    private String propseCntrctPdText;
    /**
     * 제안 인도 조건 자동 여부
    */
    private String propseDelyCndAtmcAt;
    /**
     * 제안 인도 조건 텍스트
    */
    private String propseDelyCndText;
    /**
     * 제안 단가 산식 코드
     */
    private String propseUntpcMntnfrmlaCode;
    /**
     * 제안 단가 산식
     */
    private String propseUntpcMntnfrmla;
    /**
     * 제안 프리미엄 자동 여부
    */
    private String propsePremiumAtmcAt;
    /**
     * 제안 프리미엄 텍스트
    */
    private String propsePremiumText;
    /**
     * 결제 수단 이월렛 사용 여부
    */
    private String setleMnEwalletUseAt;
    /**
     * 결제 수단 증거금 사용 여부
    */
    private String setleMnWrtmUseAt;
    /**
     * 결제 수단 여신 사용 여부
    */
    private String setleMnCdtlnUseAt;
    /**
     * 제안 활성 여부
    */
    private String propseActvtyAt;
    /**
     * 견적 기한 만료 일
    */
    private String estmtTmlmtEndDe;
    /**
     * 견적 기한 만료 시간
     */
    private String estmtTmlmtEndTm;
    /**
     * 계약 승인 기한 코드
    */
    private String cntrctConfmTmlmtCode;
    /**
     * 계약 승인 만료 일
    */
    private String cntrctConfmEndDe;
    /**
     * 계약 승인 만료 시간
     */
    private String cntrctConfmEndTm;
    /**
     * 임시 저장 일시
    */
    private String tmprStreDt;
    /**
     * 견적 확정 일시
    */
    private String estmtDcsnDt;
    /**
     * 견적 승인 일시
    */
    private String estmtConfmDt;
    /**
     * 반려 사유
    */
    private String returnResn;
    /**
     * 반려 일시
    */
    private String returnDt;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    /**
     * 견적 접수일
     */
    private String estmtRceptDe;
    
    /* 조회 조건 */
    /**
     * 권한 구분 코드
     */
    private String memberSecode;
    /**
     * 구분
     */
    private String searchSe;
    /**
     * 검색 시작 년도
     */
    private String searchStartYear;
    /**
     * 검색 시작 월
     */
    private String searchStartMonth;
    /**
     * 검색 마지막 년도
     */
    private String searchEndYear;
    /**
     * 검색 마지막 월
     */
    private String searchEndMonth;
    /**
     * 상태
     */
    private String searchState;
    
    /* 평균가 계약 관리 화면 표시 항목 */
    /**
     * 아이템 텍스트
     */
    private String itmText;
    /**
     * 권역 텍스트
     */
    private String dstrctLclsfText;
    /**
     * 브랜드 텍스트
     */
    private String brandText;
    /**
     * 계약수량 텍스트
     */
    private String wtText;
    /**
     * 계약 기간 텍스트
     */
    private String cntrctPdText;
    /**
     * 결제 조건
     */
    private String setleCnd;
    /**
     * 관리자 검토기한 일자
     */
    private String mngrExmntTmlmtDe;
    /**
     * 관리자 검토기한 시간
     */
    private String mngrExmntTmlmtTm;
    
    /* 견적서 및 계약서 추가 항목 */
    /**
     * 제안 총 중량
     */
    private String totOrderWt;
    /**
     * 판매자
     */
    private String repSeler;               
    /**
     * 사업자등록번호
     */
    private String repSelerBsnmRegistNo;
    /**
     * 대표이사
     */
    private String repSelerRprsntvNm;    
    /**
     * 대표 전화 번호
     */
    private String repSelerTlphon;    
    /**
     * 소재지
     */
    private String repSelerAdres;         
    /**
     * 팩스 번호
     */
    private String repSelerFaxNo;
    /**
     * 견적 제시 일
     */
    private String estmtPrsentDe;
    /**
     * 결제 수단 이월렛
    */
    private String setleMnEwallet;
    /**
     * 결제 수단 증거금
    */
    private String setleMnWrtm;
    /**
     * 결제 수단 여신
    */
    private String setleMnCdtln;
    
    /* 계약 관련 항목 */
    /**
     * 계약 번호
     */
    private String cntrctNo;
    /**
     * 계약 년월
     */
    private String cntrctYm;
    /**
     * 제안 금속 코드명
     */
    private String propseMetalNm;
    /**
     * 업체명 한글 약어
     */
    private String entrpsnmKoreanShort;
    /**
     * 계약 제시 일
     */
    private String cntrctPrsentDe;
    
    /* 구매자 정보 */
    /**
     * 사업자 등록 번호
     */
    private String bsnmRegistNo;
    /**
     * 업체 대표자 명
     */
    private String rprsntvNm;
    /**
     * 주문 업체 주소
     */
    private String orderEntrpsAdres;
    
    
    /**
     * 금속 코드
     */
    private String metalCode;
    /**
     * 아이템 순번
     */
    private String itmSn;
    /**
	 * 판매 단위 중량
	 */
	private int sleUnitWt;
	/**
	 * 발주 가능 최대 중량
	 */
	private long orderPossMxmmWt;
	/**
	 * Stringified PDF File
	 */
	private String pdfString;
	/**
	 * uploaded file doc no
	 */
	private int docNo;
    
    /**
     * 주문 정보(월별 계약 정보)
     */
    private List<CntrctMtDtlVO> orderInfoList;
    
    public void setEstmtNo (String estmtNo) throws UnsupportedEncodingException {
    	this.estmtNo = URLDecoder.decode(estmtNo, "UTF-8");
    }
    
    public void setCntrctNo (String cntrctNo) throws UnsupportedEncodingException {
    	this.cntrctNo = URLDecoder.decode(cntrctNo, "UTF-8");
    }
    
    public void setCntrctYm (String cntrctYm) throws UnsupportedEncodingException {
    	this.cntrctYm = URLDecoder.decode(cntrctYm, "UTF-8");
    }
}
