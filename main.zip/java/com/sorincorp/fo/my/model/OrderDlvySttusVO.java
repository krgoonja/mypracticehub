package com.sorincorp.fo.my.model;

import java.util.List;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class OrderDlvySttusVO extends CommonVO {

	private static final long serialVersionUID = -1032006048916951512L;		
	/** 
	 * 회원번호 
	 */
	private String mberNo;
	/** 
	 * 회원권한구분코드 
	 */
	private String mberSeCode;
	/** 
	 * 순번 
	 */
	private String rownum;
	/** 
	 * 금속 명 
	 */
	private String metalNm;
	/** 
	 * 아이템 명 
	 */
	private String itmNm;
	/**
	 * 브랜드 명
	 */
	private String brandNm;
	/**
	 * 브랜드 그룹명
	 */
	private String brandGroupNm;
	/**
	 * 업체 번호
	 */
	private String entrpsNo;
	/**
	 * 총 고객 주문 중량
	 */
	private int totCstmrOrderWt;
	/**
	 * BL 번호
	 */
	private String blNo;
	/**
	 * 주문 번호
	 */
	private String orderNo;
	/**
	 * oms 번호
	 */
	private String omsNo;
	/**
	 * 주문 일자
	 */
	private String orderDe;
	/**
	 * 출고 요청 일자
	 */
	private String dlivyRequstDe;
	/**
	 * 주문 상태 코드
	 */
	private String orderSttusCode;
	/**
	 * 배송 수단 코드
	 */
	private String dlvyMnCode;
	/**
	 * 배송 수단 명
	 */
	private String dlvyMnNm;
	/**
	 * 총 고객 주문 중량
	 */
	private int maxDlvyOdr;
	/**
	 * 납기 예정 일자
	 */
	private String dedtPrearngeDe;
	/**
	 * 등록 차량 수
	 */
	private int vhcleCnt;
	/**
	 * 최대 차수
	 */
	private int vhcleCnt2;
	/**
	 * 주문 기업 명
	 */
	private String orderEntrpsNm;
	/**
	 * 배송지 명
	 */
	private String dlvrgNm;
	/**
	 * 배송지 주소
	 */
	private String receptEntrpsAdres;
	/**
	 * 배송 기업 주소 상세
	 */
	private String receptEntrpsDetailAdres;
	/**
	 * 창고명
	 */
	private String wrhousNm;
	/**
	 * 창고주소
	 */
	private String wrhousRnAdres;
	/**
	 * 창고 도로명 주소
	 */
	private String wrhousRnAdresDetail;
	/**
	 * 창고 담당자
	 */
	private String wrhousCharger;
	/**
	 * 창고 담당자 번호
	 */
	private String wrhousChargerTlphonNo;	
	
	/* 페이징(더보기) */
	/** startIndex */
	private int startIndex = 1;
	/** endIndex */
	private int endIndex = 10;

	/* 추가(조회조건) */
	/** 
	 * 기간조회 시작일 
	 */
	private String searchDateFrom;
	/** 
	 * 기간조회 종료일 
	 */
	private String searchDateTo;
	/**
	 * 문서파일실제경로
	 */
	private String docFileRealCours;
	/**
	 * 국가이미지
	 */
	private String nationFlagImgUrl;
	/** 
	 * 결제상태 목록 
	 */
	private List<String> settleSttusList;

	private int dlvyOdr;

	private String vhcleWrhousngDe;

	private String vhcleNo;

	private String vhcleGroupCode;

	private String drverNm;

	private String drverTlphonNo;

	private String dlvyProgrsSttusCode;

	private String dlvyProgrsSttusCodeNm;

	private String pickDt;

	private String planNo;
	
}
