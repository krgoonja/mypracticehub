package com.sorincorp.fo.my.model;

import lombok.Data;

@Data
public class OrMrtggMdstrmRepyVO {
	/******  JAVA VO CREATE : OR_MRTGG_MDSTRM_REPY_DTL(주문_담보 중도 상환 상세)                                                             ******/
    /**
     * 담보 번호
    */
    private String mrtggNo;
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 중도 상환 순번
    */
    private long mdstrmRepySn;
    /**
     * 배송 차수
    */
    private int dlvyOdr;
    /**
     * 확정 금액
    */
    private Long dcsnAmount;
    /**
     * 입금 요청 금액
    */
    private Long rcpmnyRequstAmount;
    /**
     * 결제 예정 일자
    */
    private String setlePrearngeDe;
    /**
     * 확정 중량
    */
    private java.math.BigDecimal dcsnWt;
    /**
     * 배송비
    */
    private long dlvrf;
    /**
     * 상환 완료 코드
    */
    private String repyComptCode;
    /**
     * 결제 완료 일자
     */
    private String setleComptDe;
    /**
     * 상차 일자
     */
    private String pickDe;
    /**
     * 최초 등록 일자(발생 일자 표현에 사용)
     */
    private String frstRegistDe;
    
    /**
     * 담보 상세 순번
    */
    private long mrtggDetailSn;
}
