package com.sorincorp.fo.my.model;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.annotation.MaskingClass;
import com.sorincorp.comm.annotation.MaskingField;
import com.sorincorp.comm.annotation.MaskingField.MaskingType;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Validated
@MaskingClass
public class MemberMgrVO implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 1658046897534492103L;

	public interface Search {
	};

	public interface Insert {
	};

	public interface Update {
	};

	/**
	 * 회원번호
	 */
	@NotEmpty(groups = Search.class, message = "회원번호가 존재하지 않습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Update.class, message = "회원번호가 존재하지 않습니다.") // /message/validation.properties 에 등록된 메시지
	private String mberNo;
	/**
	 * 기업번호
	 */
	@NotEmpty(groups = Search.class, message = "기업번호가 존재하지 않습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Insert.class, message = "기업번호가 존재하지 않습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Update.class, message = "기업번호가 존재하지 않습니다.") // /message/validation.properties 에 등록된 메시지
	private String entrpsNo;
	/**
	 * 회원아이디
	 */
	@NotEmpty(groups = Insert.class, message = "회원아이디는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Update.class, message = "회원아이디는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String mberId;
	/**
	 * 회원이름
	 */
	@NotEmpty(groups = Insert.class, message = "회원이름은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Update.class, message = "회원이름은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String mberNm;
	/**
	 * 회원휴대폰번호
	 */
	@NotEmpty(groups = Insert.class, message = "회원휴대폰번호는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Update.class, message = "회원휴대폰번호는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@Size(groups = Insert.class, min = 11, message = "회원휴대폰번호가 유효하지 않습니다.")
	@Size(groups = Update.class, min = 11, message = "회원휴대폰번호가 유효하지 않습니다.")
	private String moblphonNo;
	/**
	 * 회원전화번호
	 */
	private String tlphonNo;
	/**
	 * 회원이메일
	 */
	@Pattern(groups = Insert.class, message = "이메일 형식이 아닙니다.", regexp = "[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+")
	@Pattern(groups = Update.class, message = "이메일 형식이 아닙니다.", regexp = "[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+")
	private String mberEmail;
	/**
	 * 회원가입일시
	 */
	private String mberEtrDt;
	/**
	 * 최근방문일시
	 */
	private String mberRecentVisitDt;

	/**
	 * 최근접속일시
	 */
	private String recentConectDt;
	/**
	 * 회원 권한갯수
	 */
	private int registAuthCnt;
	/**
	 * 회원상태코드
	 */
	private String mberSttusCode;
	/**
	 * 회원상태코드명
	 */
	private String mberSttusCodeNm;
	/**
	 * 회원구분코드
	 */
	@NotEmpty(groups = Insert.class, message = "멤버권한은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Update.class, message = "멤버권한은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String mberSeCode;
	/**
	 * 회원구분코드명
	 */
	private String mberSeCodeNm;
	/**
	 * 회원승인상태코드
	 */
	private String mberConfmSttusCode;
	/**
	 * 회원패스워드
	 */
	@MaskingField(MaskingType.ENCRYPT)
	private String mberSecretNo;
	/**
	 * 마스터권한 변경여부
	 */
	private boolean masterChg;
	/**
	 * 최초등록자아이디
	 */
	private String frstRegisterId;
	/**
	 * 최종변경자 아이디
	 */
	private String lastChangerId;

	private String mberOrderPoss;
	private String mberPossDesc;

}
