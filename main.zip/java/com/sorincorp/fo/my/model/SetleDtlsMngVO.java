/**
 *
 */
package com.sorincorp.fo.my.model;

import java.util.List;
import java.util.Map;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.annotation.MaskingClass;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * SetleDtlsMngVO.java
 * @version
 * @since 2022. 8. 10.
 * @author srec0073
 */
@Data
@EqualsAndHashCode(callSuper=false)
@Validated
@MaskingClass
public class SetleDtlsMngVO {
	/** 업체 번호 */
	private String entrpsNo;
	/** 미사용 보증 리스트 */
	private List<String> noUseGrntyList;
	/** 전자상거래보증 */
	private String mrtggGrnty = "전자상거래보증";
	/** 구매자금 */
	private String lonGrnty = "구매자금";
	/** 전자상거래보증 사용 여부 */
	private String mrtggGrntyUseAt;
	/** 구매자금 사용 여부 */
	private String lonGrntyUseAt;
	/** 결제방식 */
	private String setleMthd;
	/** 결제수단 */
	private String setleMn;
	/** 주문 번호 */
	private String orderNo;
	/** 취소 교환 반품 번호 */
	private String canclExchngRtngudNo;
	/** 기간검색조건 - 시작일 */
	private String startDate;
	/** 기간검색조건 - 종료일 */
	private String endDate;
	/** 거래 일시 */
	private String delngDt;
	/** 거래 구분 코드 */
	private String delngSeCode;
	/** 거래 유형 */
	private String delngSe;
	/** 거래 금액 */
	private String delngAmount;
	/** 적요 */
	private String sumry;
	/** 삭제 여부 */
	private String deleteAt;
	/** 삭제 일시 */
	private String deleteDt;
	/** 최초 등록자 아이디 */
	private String frstRegisterId;
	/** 최초 등록 일시 */
	private String frstRegistDt;
	/** 최종 변경자 아이디 */
	private String lastChangerId;
	/** 최종 변경 일시 */
	private String lastChangeDt;
	/** 잔액 */
	private String blce;
	/** 은행 코드 */
	private String bankCode;
	/** 은행명 */
	private String bankNm;
	/** 검색구분 */
	private String srchSection;
	/** 검색키워드 */
	private String srchKeyWord;

	/* 페이징(더보기) */
	/** startIndex */
	private int startIndex = 1;
	/** endIndex */
	private int endIndex = 10;

	/* 엑셀조회 */
	/** 엑셀 조회여부 */
	private boolean excelYn = false;
	/** 엑셀 타이틀 */
	private String[] titleArr;
	/** 탭명 */
	private String tabNm;

	/* 전자상거래보증 요약내역 */
	/** 전자상거래보증 만료여부 */
	private String endAt;
	/** 전자상거래보증 번호 */
	private String grntyNo;
	/** 보증 계약한도 */
	private String grntyAmount;
	/** 남은 보증한도 */
	private String mrtggBlce;
	/** 사용 보증한도 */
	private String mrtggUseAmount;
	/** 여신 구분 코드 */
	private String cdtlnSvcSeCode;

	/* 정렬 조건 */
	private Map<String, Object> srchSortInfo;
	private String srchSortInfoForExcel;
}
