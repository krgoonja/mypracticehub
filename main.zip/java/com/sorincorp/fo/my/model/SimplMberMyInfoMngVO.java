/**
 *
 */
package com.sorincorp.fo.my.model;

import java.util.List;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * MyInfoMngVO.java
 * @version
 * @since 2021. 8. 23.
 * @author srec0009
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class SimplMberMyInfoMngVO extends CommonVO{
	/******  JAVA VO CREATE : MB_SIMPL_MBER_INFO_BAS(회원_간편 회원 정보 기본)                                                               ******/
	    /**
	     * 간편 회원 번호
	    */
	    private String simplMberNo;
	    /**
	     * 간편 회원 아이디
	    */
	    private String simplMberId;
	    /**
	     * 간편 회원 비밀 번호
	    */
	    private String simplMberSecretNo;
	    /**
	     * 간편 회원 가입 일시
	    */
	    private String simplMberEtrDt;
	    /**
	     * 간편 회원 최근 방문 일시
	    */
	    private String simplMberRecentVisitDt;
	    /**
	     * 간편 회원 이름
	    */
	    private String simplMberNm;
	    /**
	     * 휴대전화 번호
	    */
	    private String moblphonNo;
	    /**
	     * 뉴스레터 신청 여부
	    */
	    private String nsltReqstAt;
	    /**
	     * 뉴스레터 신청 일시
	    */
	    private String nsltReqstDt;
	    /**
	     * 앱 알림 여부
	    */
	    private String appNtcnAt;
	    /**
	     * 이메일 알림 여부
	    */
	    private String emailNtcnAt;
	    /**
	     * WEB 알림 여부
	    */
	    private String webNtcnAt;
	    /**
	     * 로그인 실패 회수
	    */
	    private int loginFailrRtrvl;
	    /**
	     * 비밀 번호 오류 횟수
	    */
	    private int secretNoErrorCo;
	    /**
	     * 비밀 번호 수정 일시
	    */
	    private String secretNoUpdtDt;
	    /**
	     * 최근 접속 일시
	    */
	    private String recentConectDt;
	    /**
	     * 간편 회원 상태 코드
	    */
	    private String simplMberSttusCode;
	    /**
	     * 휴면 일시
	    */
	    private String drmncyDt;
	    /**
	     * 탈퇴 일시
	    */
	    private String secsnDt;
	    /**
	     * 탈퇴 유형 코드
	    */
	    private String secsnTyCode;
	    /**
	     * 탈퇴 사유 코드
	    */
	    private String secsnResnCode;
	    /**
	     * 기타 탈퇴 사유
	    */
	    private String etcSecsnResn;
	    /**
	     * 삭제 여부
	    */
	    private String deleteAt;
	    /**
	     * 삭제 일시
	    */
	    private String deleteDt;
	    /**
	     * 최초 등록자 아이디
	    */
	    private String frstRegisterId;
	    /**
	     * 최초 등록 일시
	    */
	    private String frstRegistDt;
	    /**
	     * 최종 변경자 아이디
	    */
	    private String lastChangerId;
	    /**
	     * 최종 변경 일시
	    */
	    private String lastChangeDt;
	    /**
	     * 코드_회원 간편 회원 가입 구분 코드
	    */
	    private String simplMberEtrSeCode;
	    /**
	     * 다음 비밀 번호 변경 일시
	    */
	    private String nextSecretNoChangeDt;

	    private String emailAtFlag;
	    private String smsAtFlag;
	    private String nsltAtFlag;

	    /**
	     * 마케팅 수신 동의 SMS
	    */
	    private String marktRecptnSms;
	    /**
	     * 마케팅 수신 동의 PUSH
	    */
	    private String marktRecptnPush;
	    /**
	     * 마케팅 수신 동의 이메일
	    */
	    private String marktRecptnEmail;
	    /**
	     * 마케팅 수신 동의 여부
	    */
	    private String advrtsRecptnAgreAt;
	    /**
	     * 마케팅 수신 동의 일시
	    */
	    private String advrtsRecptnAgreDt;

}
