/**
 *
 */
package com.sorincorp.fo.my.model;

import java.sql.Timestamp;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.annotation.MaskingClass;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * EwalletMngVO.java
 * @version
 * @since 2021. 9. 24.
 * @author srec0009
 */
@Data
@EqualsAndHashCode(callSuper=false)
@Validated
@MaskingClass
public class EwalletMngVO {
	/******  JAVA VO CREATE : MB_REFND_REQUST_HST(회원_환불 요청 이력) ******/
	/**
	 * 업체 번호
	*/
	private String entrpsNo;
	/**
	 * 환불 요청 일시
	*/
	private String refndRequstDt;
	private String refndRequstDtPk;
	/**
	 * 환불 요청 금액
	*/
	private String refndRequstAmount;
	/**
	 * 환불 요청 상태 코드
	*/
	private String refndRequstSttusCode;
	/**
	 * 환불 요청 상태 코드명
	 */
	private String refndRequstSttusCodeNm;
	/**
	 * 환불 요청 처리 일시
	*/
	private String refndRequstProcessDt;
	/**
	 * 삭제 여부
	*/
	private String deleteAt;
	/**
	 * 삭제 일시
	*/
	private String deleteDt;
	/**
	 * 최초 등록자 아이디
	*/
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	*/
	private String frstRegistDt;
	/**
	 * 최종 변경자 아이디
	*/
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	*/
	private String lastChangeDt;
	 /******  JAVA VO CREATE : MB_ENTRPS_EWALLET_DTL(회원_업체 이월렛 상세)******/
	 /**
	  * 이월렛 거래 일시
	 */
	private String ewalletDelngDt;
	/**
	 * 이월렛 적요
	*/
	private String ewalletSumry;
	/**
	 * 이월렛 거래 금액
	*/
	private String ewalletDelngAmount;
	/**
	 * 이월렛 잔액
	*/
	private String ewalletBlce;

	/**
	 * 이월렛 거래 구분 코드
	*/
	private String ewalletDelngSeCode;
	/**
	 * 이월렛 거래 구분 코드2
	*/
	private String ewalletDelngSeCode2;
	/**
	 * 거래 일련 번호
	*/
	private String delngSeqNo;
	/**
	 * 이월렛 정산 유형 코드
	*/
	private String ewalletExcclcTyCode;
	/**
	 * 주문 번호
	*/
	private String orderNo;
	/**
	 * 취소 교환 반품 번호
	*/
	private String canclExchngRtngudNo;
	/**
	 * 이월렛 정산 유형 코드명
	 */
	private String ewalletExcclcTyCodeNm;
	/**
	 * 기간검색조건 - 시작일
	 */
	private String startDate;
	/**
	 * 기간검색조건 - 종료일
	 */
	private String endDate;
	/**
	 * 거래구분코드명
	 */
	private String ewalletDelngSeCodeNm;
}
