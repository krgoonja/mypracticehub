package com.sorincorp.fo.my.model;

import com.sorincorp.comm.order.model.CommPrvsnlDcsnInfoVO;

import lombok.Data;

/**
 * OrderPrvsnlDcsnProcessVO.java
 * 단가확정하기 진행 VO 객체
 * 
 * @version
 * @since 2024. 9. 26.
 * @author srec0049
 */
@Data
public class OrderPrvsnlDcsnProcessVO {

	/**
	 * 주문 번호
	 */
	private String orderNo;
	
	/**
	 * 업체 번호
	 */
	private String entrpsNo;
	
	/**
	 * 금속 코드
	 */
	private String metalCode;
	
	/**
	 * 판매 방식 코드
	 */
	private String sleMthdCode;
	
	/**
     * 아이템 순번
     */
    private int itmSn;
    
    /**
     * 권역 대분류 코드
     */
    private String dstrctLclsfCode;
	
    /**
     * 브랜드 그룹 코드
     */
    private String brandGroupCode;
    
    /**
     * 브랜드 코드
     */
    private String brandCode;
    
    /**
     * 판매 가격 실시간 순번
     */
    private String slePcRltmSn;
    
	/**
	 * LME 가격 실시간 순번
	 */
	private String lmePcRltmSn;
	
	/**
	 * 환율 가격 실시간 순번
	 */
	private String ehgtPcRltmSn;
	
	
	/**
	 * 구분 [lme: LME 분리확정, fx: FX 분리확정, singl: 단일확정, smtm: 동시확정]
	 */
	private String section;
	
	/**
	 * 판매 방식 [live: 라이브, limit: 지정가]
	 */
	private String selMthd;
	
	/**
	 * 상태 코드 [I: 등록, U: 수정, D: 취소]
	 */
	private String sttusCode;
	
	/**
	 * 회원 번호
	 */
	private String mberNo;
	
	/**
	 * 회원 ID
	 */
	private String mberId;
	
	/**
     * 지정가 LME 주문 번호
     */
    private String limitLmeOrderNo;
    
    /**
     * 지정가 환율 주문 번호
     */
    private String limitEhgtOrderNo;
    
    /**
     * 지정가 KRW 주문 번호
     */
    private String limitKrwOrderNo;
    
    /**
     * 지정가 LME 입력 금액
     */
    private double limitLmeInputAmount;
    
    /**
     * 지정가 환율 입력 금액
     */
    private double limitEhgtInputAmount;
    
    /**
     * 지정가 KRW 입력 금액
     */
    private long limitKrwInputAmount;
    
    /**
     * 지정가 LME 주문 유효 일자
     */
    private String limitLmeOrderValidDe;
    
    /**
     * 지정가 환율 주문 유효 일자
     */
    private String limitEhgtOrderValidDe;
    
    /**
     * 지정가 KRW 주문 유효 일자
     */
    private String limitKrwOrderValidDe;
    
    /**
     * 지정가 주문 상태 코드
     */
    private String limitOrderSttusCode;
	
	/**
	 * 단가확정하기 정보 VO 객체
	 */
	private OrderPrvsnlDcsnInfoVO orderPrvsnlDcsnInfoVO;
	
	/**
	 * 공통 가단가 확정 여부 정보 VO 객체
	 */
	private CommPrvsnlDcsnInfoVO commPrvsnlDcsnInfoVO;
}
