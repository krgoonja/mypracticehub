package com.sorincorp.fo.my.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class MileageMngVO extends CommonVO {/**
	 *
	 */
	private static final long serialVersionUID = -8362354793555145626L;
	/**
     * 마일리지 순번
    */
	private int mlgSn;
	/**
     * 업체 번호
    */
	private String entrpsNo;
	/**
     * 마일리지 거래 일시
    */
	private String mlgDelngDt;
	/**
     * 마일리지 만료 일자
    */
	private String mlgEndDe;
	/**
     * 마일리지 구분
    */
	private String mlgSe;
	/**
     * 마일리지 유형
    */
	private String mlgTy;
	/**
     * 마일리지 구분 코드명
    */
	private String mlgSeNm;
	/**
     * 마일리지 유형 코드명
    */
	private String mlgTyNm;
	/**
     * 마일리지 상세 내역
    */
	private String mlgDetailDtls;
	/**
     * 거래 마일리지
    */
	private int delngMlg;
	/**
     * 잔여 마일리지
    */
	private int remndrMlg;
	/**
     * 삭제 여부
    */
	private String deleteAt;
	/**
     * 삭제 일시
    */
	private String deleteDt;
	/**
     * 최초 등록자 아이디
    */
	private String frstRegisterId;
	/**
     * 최초 등록 일시
    */
	private String frstRegistDt;
	/**
     * 최종 변경자 아이디
    */
	private String lastChangerId;
	/**
     * 최종 변경 일시
    */
	private String lastChangeDt;
	/**
     * 주문 번호
    */
	private String orderNo;
	/**
     * 취소 교환 반품 번호
    */
	private String cancelExchngRtngudNo;
	/**
     * 보증 번호
    */
	private String grntyNo;
	/**
     * 적립 소멸 여부
    */
	private String accmlExtshAt;
	/**
     * 업체명
    */
	private String entrpsnmKorean;
	/**
     * 시작 날짜
    */
	private String startDate;
	/**
     * 종료 날짜
    */
	private String endDate;
	private int seq;
	/**
     * 적립 마일리지
    */
	private int accmlMlg;
	/**
     * 적립 예정 마일리지
    */
	private int accmlPrearngeMlg;
	/**
     * 사용 가능 마일리지
    */
	private int useAbleMlg;
	/**
     * 사용 마일리지
    */
	private int useMlg;
	/**
     * 총 사용 마일리지
    */
	private int totUseMlg;
	/**
     * 총 적립 마일리지
    */
	private int totAccmlMlg;
	/**
     * 총 적립 예정 마일리지
    */
	private int totAccmlPrearngeMlg;
	/**
     * 마일리지 만료 일자
    */
	private int mlgDateDiff;
	/**
     * 소멸 예정 마일리지
    */
	private int delPrearngeMlg;

	/**
     *
    */
	private int startIndex = 1;
	/**
     *
    */
	private int endIndex = 10;

}
