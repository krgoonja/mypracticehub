package com.sorincorp.fo.my.model;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.fo.op.model.HopePcNtcnSetupVO.updateHopePc;

import lombok.Data;

/**
 * MyHopePcAlarmVO.java
 * @version
 * @since 2021. 9. 8.
 * @author srec0042
 */
@Data
@Validated
public class MyHopePcAlarmVO implements Serializable{

	private static final long serialVersionUID = 5672413247194079464L;
	
	/**
	 *  selectHeaderAlarm
	 *  Validation groups를 지정하기 위한 빈 interface
	 */
	public interface selectHeaderAlarm{};
	
	/**
	 *  updateHopeUseAt
	 *  Validation groups를 지정하기 위한 빈 interface
	 */
	public interface updateHopeUseAt{};
	
	/**
	*	상품명 
	*/
	private String goodsNm;

	/**
	*	아이템 순번
	*/
	private String itmSn;
	
    /**
    * 업체 번호
   */
	@NotEmpty(groups = updateHopeUseAt.class, message="로그인 후 이용해 주세요." )
	@NotEmpty(groups = selectHeaderAlarm.class, message="로그인 후 이용해 주세요." )
	private String entrpsNo;
	
    /**
    * 금속 코드
   */
	@NotEmpty(groups = updateHopeUseAt.class, message="수정할 금속 코드를 선택해 주세요." )
	private String metalCode;
	
    /**
    * 권역 대분류 코드
   */
	@NotEmpty(groups = updateHopeUseAt.class, message="수정할 금속 코드를 선택해 주세요." )
	private String dstrctLclsfCode;
	
    /**
    * 브랜드 그룹 코드
   */
	@NotEmpty(groups = updateHopeUseAt.class, message="수정할 금속 코드를 선택해 주세요." )
	private String brandGroupCode;
	
    /**
    * 브랜드 코드
   */
	@NotEmpty(groups = updateHopeUseAt.class, message="수정할 금속 코드를 선택해 주세요." )
	private String brandCode;
	
	/**
	*	희망가격
	*/
	@NotEmpty(groups = updateHopeUseAt.class, message="수정할 금속 코드를 선택해 주세요." )
	private String hopepc; 
		
	/**
	*	사용 여부
	*/
	@NotEmpty(groups = updateHopeUseAt.class, message="사용 여부를 선택해 주세요." )
	private String useAt; 
	  
	/**
	 *  회원 번호
	 */
	private String mberNo;

    /**
    * 최초 등록 일시
   */
	private String frstRegistDt;
	
    /**
    * 최종 변경 일시
   */
	private String lastChangeDt;
	
	/**
	 * 알림 발송 완료일
	 */
	private String ntcnSndngComptde;

	/**
	 * 알림 발송 등록일
	 */
	private String ntcnSndngRgsde;
	
	/**
	 * 선물 처리 여부
	 */
	private String ftrsProcessAt;

    /**
    * 최종 변경자 아이디
   */
   private String lastChangerId; 
   /**
    * 아이디
    */
   private String id; 

}
