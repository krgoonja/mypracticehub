package com.sorincorp.fo.my.model;

import com.sorincorp.comm.model.CommonVO;
import lombok.Data;

@Data
public class OrderCouponDdctVO extends CommonVO {

    private static final long serialVersionUID = -3664678749339665626L;
	/******  JAVA VO CREATE : OR_ORDER_DTL(주문_주문 상세)   ******/
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 총 실제 주문 중량
    */
    private String totRealOrderWt;
    /**
     * 상품 단가
     */
    private String goodsUntpc;
    /**
     * 중량 변동금
     */
    private String wtChangeGld;
    /**
     * 주문가격
     */
    private String orderPc;
    /**
     * 공급가
     */
    private String splpc;
    /**
     * 판매가
     */
    private String slepc;
    /**
     * 부가세
     */
    private String vat;
    /**
     * 쿠폰 상태 코드
     */
    private String couponSttusCode;
    /**
     * 쿠폰 할인 적용 금액
     */
    private String couponDscntApplcAmount;
    /**
     * 쿠폰 타입 코드
     */
    private String couponTyCode;
    /**
     * 단가 할인 금액
     */
    private String untpcDscntAmount;
    /**
     * 단가 쿠폰 총 할인 금액
     */
    private String untpcCouponTotalAmount;
    /**
     * 배송비 적용 차수
     */
    private String dlvrfApplcOdr;
    /**
     * 총배송비
     */
    private String expectDlvrf;
    /**
     * 배송차수(MAX)
     */
    private String dlvyOdr;
    /**
     * 판매 단위 코드명
     */
    private String sleUnitNm;
    /**
     * 삭제 여부
    */
    private String deleteAt;

}
