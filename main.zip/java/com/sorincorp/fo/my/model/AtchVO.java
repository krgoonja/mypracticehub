package com.sorincorp.fo.my.model;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * AtchVO.java
 *
 * @version
 * @since 2023. 01. 06.
 * @author sumin95
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class AtchVO implements Serializable {

	private static final long serialVersionUID = -3489488821575254711L;

	public interface Search {
	};

	public interface Update {
	};
		
	/******  JAVA VO CREATE : MB_ENTRPS_KYC_ATCH_FILE_RLS()                                                                                  ******/
	     /**
	     * 문서 순번
	    */
	    private long atchSn; 
	     /**
	     * 업체 번호
	    */
	    private String entrpsNo; 
	     /**
	     * 첨부 파일 코드
	    */
	    private String atchFileCode; 
	     /**
	     * 첨부 파일 제목
	    */
	    private String atchFileSj; 
	     /**
	     * 삭제 여부
	    */
	    private String deleteAt; 
	     /**
	     * 삭제 일시
	    */
	    private java.sql.Timestamp deleteDt; 
	     /**
	     * 최초 등록자 아이디
	    */
	    private String frstRegisterId; 
	     /**
	     * 최초 등록 일시
	    */
	    private java.sql.Timestamp frstRegistDt; 
	     /**
	     * 최종 수정자 아이디
	    */
	    private String lastChangerId; 
	     /**
	     * 최종 변경 일시
	    */
	    private java.sql.Timestamp lastChangeDt; 
	     /**
	     * 문서 번호
	    */
	    private int docNo; 
}
