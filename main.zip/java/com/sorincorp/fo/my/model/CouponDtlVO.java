package com.sorincorp.fo.my.model;

import com.sorincorp.comm.model.CommonVO;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.Date;

@Data
public class CouponDtlVO extends CommonVO {

    private static final long serialVersionUID = -1032006748916951512L;

    /**회원 번호*/
    private String mberNo;

    /**회원 아이디*/
    private String mberId;

    /** 업체 번호*/
    private String entrpsNo;

    /** 권한 구분 코드*/
    private String memberSecode;

    /** 쿠폰이벤트 번호  **/
    @NotEmpty(message = "쿠폰 이벤트번호 미존재")
    private int prcouponEventNo;

    /** 프로모션 번호   **/
    @NotEmpty(message = "프로모션 번호 미존재")
    private int promtnNo;

    /**  쿠폰 명        **/
    @NotEmpty(message = "쿠폰명 미존재")
    private String couponNm;

    /** 쿠폰 타입       **/
    @NotEmpty(message = "쿠폰타입 미존재")
    private String couponType;

    /** 쿠폰 구분 코드  **/
    @NotEmpty(message = "쿠폰 구분코드 미존재")
    private String couponSeCode;

    /** 쿠폰 구분 코드  **/
    private String couponSeCodeNm;

    /** 쿠폰 적용 브랜드 코드  **/
    private String couponApplcBrandCode;

    /** 쿠폰 할인 금액       **/
    private int couponDscntAmount;

    /** 쿠폰 할인율      **/
    private int couponDscntRt;

    /** 쿠폰 발급 제한 수량 여부      **/
    @NotEmpty
    private String couponIssuLmttQyAt;

    /** 쿠폰 발급 제한 수량       **/
    private int couponIssuLmttQy;

    /** 쿠폰 중복 사용 제한 수량     **/
    @NotEmpty
    private int couponDplctUseLmttQy;

    /** 쿠폰 적용 메탈 코드    **/
    private String couponApplcMetalCode;

    /** 할인 최대 금액 제한    **/
    private int dscntMxmmAmountLmtt;

    /** 배송비 쿠폰일 경우 적용차수    **/
    private int dlvrfCouponApplcOdr;

    /** 쿠폰의 중복가능 여부(배송비+상품)   **/
    @NotEmpty
    private String couponDplctUseLmttQyAt;

    /** 쿠폰 시작 날짜  **/
    @NotEmpty
    private String couponBeginDe;

    /** 쿠폰 종료 날짜  **/
    @NotEmpty
    private String couponEndDe;

    /** 최초 등록자 아이디  **/
    @NotEmpty
    private String frstRegisterId;

    /** 최초 등록 일시**/
    @NotEmpty
    private Date frstRegistDt;

    /** 최종 변경자 아이디 **/
    private String lastChangerId;

    /** 최종 변경 일시 **/
    private Date lastChangeDt;

    /** 프로모션 사용여부 **/
    @NotEmpty
    private String promtnCouponUseAt;

    /** 프로모션명 **/
    private String promtnNm;

    /** 프로모션코드 **/
    private String promtnSeCode;

    /** 쿠폰사용여부 **/
    private String couponUseAt;

    /** 쿠폰등록일시 **/
    private String registAt;

    /** 쿠폰난수 **/
    private String couponIsuRnno;

    /** 입력쿠폰난수 **/
    private String inputCouponIsuRnno;

    /** 쿠폰이벤트번호 **/
    private String couponEventNo;

    /** 조회 화면 ID **/
    private String searchPmgId;

    /** 조회 화면 ID **/
    private String dlvyMnCode;

    /** 쿠폰 일련 번호 **/
    private String couponSeqNo;
    /**
     * 주문번호
     */
    private String orderNo;
    /**
     * 주문중량
     */
    private int orderWt;
    /**
     * 순번
     */
    private int rownum;
    /**
     * 쿠폰 구분 코드
     */
    private String couponTyCode;
    /**
     * 쿠폰 일련 번호
     */
    private String couponSn;
    /**
     * 메탈 코드
     */
    private String metalCode;
    /**
     * 메탈 코드명
     */
    private String metalNm;
    /**
     * 브랜드 코드
     */
    private String brandCode;
    /**
     * 브랜드 코드명
     */
    private String brandNm;
    /**
     * 쿠폰 상태 코드
     */
    private String couponSttusCode;
    /**
     * 단가 할인 금액
     */
    private String untpcDscntAmount;
    /**
     * 쿠폰 시작 일자
     */
    private String couponBgnde;
    /**
     * 쿠폰 종료 일자
     */
    //private String couponEndde;
    /**
     * 톤수
     */
    private String mt;
    /**
     * 삭제 여부
     */
    private String deleteAt;
    /**
     * 삭제 일시
     */
    private String deleteDt;
    /**
     * 쿠폰 사용 날짜
     */
    private String orderDe;
    
    
    // newCoupon
    /**
     * 쿠폰 번호
     */
    private String couponNo;
    
    /**
     * 쿠폰 상세 번호
     */
    private String couponDtlNo;
    
    /**
     * 쿠폰 할인 적용 금액
     */
    private int couponDscntApplcAmount;    

    /**
     * 발행자 아이디
     */
    private String isuId; 

    /**
     * 쿠폰 발급 코드
     */
   private String couponIssuCode;  
   
   /**
   * (쿠폰)발급 금액
   */
   private int issuAmount;
   /**
   * (쿠폰)발급 수량
   */
   private int issuQy;
   /**
    * (쿠폰)사용 주문 타입
    */
   private String orderTyCode;
   /**
    * (쿠폰)사용 주문 타입 명
    */
   private String orderTyCodeNm;
   /**
    * (쿠폰) 사용 타입 명
    */
   private String useType;
   /**
    * (쿠폰) 사용 유효기간
    */
   private String couponUseDate;

}
