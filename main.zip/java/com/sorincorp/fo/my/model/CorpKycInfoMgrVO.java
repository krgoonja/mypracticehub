package com.sorincorp.fo.my.model;

import java.io.Serializable;
import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CorpInfoMgrVO.java
 *
 * @version
 * @since 2022. 8. 25.
 * @author srec0030
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class CorpKycInfoMgrVO implements Serializable {

	public interface Search {
	};

	public interface Update {
	};

	/**
	 * 업체번호
	 */
	private String entrpsNo;
	/**
	 * 요청상태코드
	 */
	private String kycRequstSttusCode;
	/**
	 * 신청 희망금액
	 */
	private String requstHopeAmount;
	/**
	 * 업체명 한글
	 */
	private String entrpsnmKorean;
	/**
	 * 창립일
	 */
	private String foundationDay;
	/**
	 * 종업원 수
	 */
	private String emplyNumber;
	/**
	 * 우편번호
	 */
	private String postNo;
	/**
	 * 주소
	 */
	private String adress;
	/**
	 * 상세 주소
	 */
	private String detailAdres;
	/**
	 * 도로명 주소
	 */
	private String rnAdres;
	/**
	 * 도로명 상세주소
	 */
	private String rnDetailAdres;
	/**
	 * 전화번호
	 */
	private String cmpnyTlphonNo;
	/**
	 * 팩스번호
	 */
	private String cmpnyFaxNo;
	/**
	 * 웹사이트주소
	 */
	private String websiteAddress;
	/**
	 * 회사구조
	 */
	private String kycCompnyStrct;
	/**
	 * 상장구분
	 */
	private String kycListType;
	/**
	 * 상장사명
	 */
	private String listCompanyName;
	/**
	 * 대표자 이름
	 */
	private String rprsntvNm;
	/**
	 * 대표자 전화번호
	 */
	private String rprsntvTelno;
	/**
	 * 대표자 이메일
	 */
	private String rprsntvEmail;
	/**
	 * 자금 담당자 이름
	 */
	private String cptalCharherName;
	/**
	 * 자금 담당자 연락처
	 */
	private String cptalCharherTel;
	/**
	 * 자금 담당자 이메일
	 */
	private String cptalCharherEmailAdres;
	/**
	 * 자금 담당자 이메일
	 */
	private String cptalCharherEmailDomain;
	/**
	 * 자금 담당자 이메일
	 */
	private String cptalCharherEmail;
	/**
	 * 업무 담당자 이름
	 */
	private String jobChargerName;
	/**
	 * 업무 담당자 연락처
	 */
	private String jobChargerTel;
	/**
	 * 업무 담당자 이메일
	 */
	private String jobChargerEmail;
	/**
	 * 신청일시
	 */
	private java.sql.Timestamp etrDt;
	/**
	 * KYC입력일시
	 */
	private java.sql.Timestamp reuqstDt;
	/**
	 * 기업 업종
	 */
	private String entrprsItemCode;
	/**
	 * 기업 업태
	 */
	private String entrprsBizcndCode;
	/**
	 * 매출액
	 */
	private String netRevenue;
	/**
	 * 자기자본금
	 */
	private String horderEquity;
	/**
	 * 총 매출액
	 */
	private String totalLiabilities;
	/**
	 * 계좌주명
	 */
	private String acntrNm;
	/**
	 * 계좌번호
	 */
	private String acnutNo;
	/**
	 * 접수 거절사유
	 */
	private String rceptRejectResn;
	/**
	 * 처리자
	 */
	private String processNm;
	/**
	 * 처리일시
	 */
	private java.sql.Timestamp processDt;
	/**
	 * 처리여부
	 */
	private String processYn;
	/**
	 * 접수 동의 여부
	 */
	private java.sql.Timestamp rceptArgeDt;
	/**
	 * 접수 동의 일시
	 */
	private String rceptArgeAt;
	/**
	 * 은행코드
	 */
	private String bankCode;
	/**
	 * 삭제여부
	 */
	private String deleteAt;
	/**
	 * 삭제일시
	 */
	private java.sql.Timestamp deleteDt;
	/**
	 * 최초 등록 일시
	 */
	private java.sql.Timestamp frstRegistDt;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최종 변경 일시
	 */
	private java.sql.Timestamp lastChangeDt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 첨부파일 리스트
	 */
	private List<AtchVO> atchArray;
	/**
	 * 첨부파일코드
	 */
	private String atchFileCode;
	/**
	 * 첨부파일 문서번호
	 */
	private int docNo;
	/**
	 * 첨부파일 제목
	 */
	private String atchFileSj;
	/**
	 * 이메일 아이디
	 */
	private String emailId;
	/**
	 * 이메일 도메인
	 */
	private String emailDomain;

}
