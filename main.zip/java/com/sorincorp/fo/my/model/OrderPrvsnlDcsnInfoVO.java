package com.sorincorp.fo.my.model;

import lombok.Data;

/**
 * OrderPrvsnlDcsnInfoVO.java
 * 단가확정하기 정보 VO 객체
 * 
 * @version
 * @since 2024. 9. 9.
 * @author srec0049
 */
@Data
public class OrderPrvsnlDcsnInfoVO {

	/**
	 * 주문 번호
	 */
	private String orderNo;
	
	/**
	 * 업체 번호
	 */
	private String entrpsNo;
	
	/**
	 * 판매 방식 코드
	 */
	private String sleMthdCode;
	
	/**
	 * 금속 코드
	 */
	private String metalCode;
	
	/**
	 * 금속 명
	 */
	private String metalNm;
	
    /**
     * 아이템 순번
     */
    private int itmSn;
	
    /**
     * 권역 대분류 코드
     */
    private String dstrctLclsfCode;
	
	/**
	 * 권역 대분류 명
	 */
	private String dstrctLclsfNm;
	
	/**
	 * 창고 명
	 */
	private String wrhousNm;
	
    /**
     * 브랜드 그룹 코드
     */
    private String brandGroupCode;
    
    /**
     * 브랜드 코드
     */
    private String brandCode;
	
	/**
	 * 브랜드 그룹 명
	 */
	private String brandGroupNm;
	
	/**
	 * 브랜드 명
	 */
	private String brandNm;
	
	/**
	 * 주문 중량 (주문수량)
	 */
	private String totRealOrderWt;
	
	/**
	 * 총 확정 중량 (출고수량)
	 */
	private String totDcsnWt;
	
	/**
	 * 출고일자
	 */
	private String dlivyDe;
	
	/**
	 * 배송 수단 코드
	 */
	private String dlvyMnCode;
	
	/**
	 * 출고 요청 일자
	 */
	private String dlivyRequstDe;
	
	/**
	 * 주문 배송지 번호
	 */
	private String orderDlvrgNo;
	
	/**
	 * 중량 변동
	 */
	private double wtChange;
	
	/**
	 * 프리미엄 가격
	 */
	private java.math.BigDecimal premiumPc;
	
	/**
     * 등급 할인 금액
     */
    private Long gradApplcAmount;
    
    /**
     * 쿠폰 적용여부
     */
    private String couponApplcAt;
    
    /**
     * 단가 할인 금액
     */
    private Long pdDscntAmount;
    
    /**
     * 확정 LME 가격
     */
    private java.math.BigDecimal dcsnLmePc;
    
    /**
     * 확정 환율 가격
     */
    private java.math.BigDecimal dcsnEhgtPc;
    
    /**
     * 확정 상품 단가
     */
    private java.math.BigDecimal dcsnGoodsUntpc;
    
    /**
     * 주문 가격
     */
    private long orderPc;
    
    /**
     * 총 확정 주문 가격
     */
    private long totDcsnOrderPc;
    
    /**
     * 공급가
     */
    private long splpc;
    
    /**
     * 총 확정 공급가
     */
    private long totDcsnSplpc;
    
	/**
	 * LME 분리 확정 일시
	 */
	private String lmeDcsnDt;
	
	/**
	 * 환율 분리 확정 일시
	 */
	private String fxDcsnDt;
	
	/**
	 * 단일 확정 일시
	 */
	private String singlDcsnDt;
	
    /**
     * 평균가 상품 단가
     */
    private long avrgpcGoodsUntpc;
    
    /**
     * 원 평균가 상품 단가
     */
    private long orgAvrgpcGoodsUntpc;
    
    /**
     * LME 현금
     */
    private java.math.BigDecimal lmeCash;
    
    /**
     * LME 가격
     */
    private java.math.BigDecimal lmePc;
    
    /**
     * 현물환
     */
    private java.math.BigDecimal spex;
    
    /**
     * 환율 가격
     */
    private java.math.BigDecimal ehgtPc;
    
    /**
     * 평균가 주문 가격
     */
    private long avrgpcOrderPc;
    
    /**
     * 평균가 중량 변동금
     */
    private long avrgpcWtChangegld;
    
    /**
     * 예상 배송비
     */
    private java.math.BigDecimal expectDlvrf;
    
    /**
     * 평균가 공급가
     */
    private long avrgpcSplpc;
    
    /**
     * 평균가 부가세
     */
    private long avrgpcVat;
    
    /**
     * 평균가 판매가
     */
    private long avrgpcSlepc;
    
    /**
     * 가격 변동금
     */
    private long pcChangegld;
    
    /**
     * 단가 분리 확정 여부
     */
    private String untpcSepratDcsnAt;
    
    /**
     * 단가 확정 최대 일자
     */
    private String untpcDcsnMxmmDe;
    
    /**
     * 결제일 (YYYY-MM-DD)
     */
    private String setleDe;
    
    
    
	
    /**
     * 판매 가격 실시간 순번
     */
    private String slePcRltmSn;
    
	/**
	 * LME 가격 실시간 순번
	 */
	private String lmePcRltmSn;
	
	/**
	 * 환율 가격 실시간 순번
	 */
	private String ehgtPcRltmSn;
	
	
	/**
     * 지정가 LME 주문 번호
     */
    private String limitLmeOrderNo;
    
    /**
     * 지정가 환율 주문 번호
     */
    private String limitEhgtOrderNo;
    
    /**
     * 지정가 KRW 주문 번호
     */
    private String limitKrwOrderNo;
    
    /**
     * 지정가 LME 입력 금액
     */
    private double limitLmeInputAmount;
    
    /**
     * 지정가 환율 입력 금액
     */
    private double limitEhgtInputAmount;
    
    /**
     * 지정가 KRW 입력 금액
     */
    private long limitKrwInputAmount;
    
    /**
     * 지정가 LME 주문 유효 일자
     */
    private String limitLmeOrderValidDe;
    
    /**
     * 지정가 환율 주문 유효 일자
     */
    private String limitEhgtOrderValidDe;
    
    /**
     * 지정가 KRW 주문 유효 일자
     */
    private String limitKrwOrderValidDe;
    
    /**
     * 영업 시작 시간 (00:00 형태)
     */
    private String rltmBeginTimeStr;
    
    /**
     * 영업 종료 시간 (00:00 형태)
     */
    private String rltmEndTimeStr;
    
    /**
     * 전일 영업 종료 시간 순번 형태
     */
    private String preRestEndTimeSn;
    
    /**
     * 금일 영업 종료 시간 순번 형태
     */
    private String todayRestEndTimeSn;
}
