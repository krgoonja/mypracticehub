package com.sorincorp.fo.my.model;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class CntrctMtAsgnInvntryDtlVO {
	/******  JAVA VO CREATE : CN_CNTRCT_MT_ASGN_INVNTRY_DTL(계약_계약 월 할당 재고 상세)                                                     ******/
    /**
     * 계약 번호
    */
    private String cntrctNo;
    /**
     * 계약 년월
    */
    private String cntrctYm;
    /**
     * 계약 년월 순번
    */
    private int cntrctYmSn;
    /**
     * BL 번호
    */
    private String blNo;
    /**
     * 재고 할당 구분 코드
    */
    private String invntryAsgnSeCode;
    /**
     * 할당 중량
    */
    private int asgnWt;
    /**
     * 할당 재고
    */
    private BigDecimal asgnInvntry;
    /**
     * 할당 번들 재고
    */
    private int asgnBundleInvntry;
    /**
     * 발주 중량
    */
    private int orderWt;
    /**
     * 발주 재고
    */
    private BigDecimal orderInvntry;
    /**
     * 발주 번들 재고
    */
    private int orderBundleInvntry;
    /**
     * 미발주 중량
    */
    private int unorderWt;
    /**
     * 미발주 재고
    */
    private BigDecimal unorderInvntry;
    /**
     * 미발주 번들 재고
    */
    private int unorderBundleInvntry;
    /**
     * 결제 중량
    */
    private int setleWt;
    /**
     * 결제 재고
    */
    private BigDecimal setleInvntry;
    /**
     * 결제 번들 재고
    */
    private int setleBundleInvntry;
    /**
     * 신규 할당 여부
    */
    private String newAsgnAt;
    /**
     * 재고 할당 번호
    */
    private String invntryAsgnNo;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    
    /**
     * 권역 중분류 코드
     */
    private String dstrctMlsfcCode;
    /**
     * NET 평균 중량
     */
    private BigDecimal netAvrgWt;
    /**
     * 성적서 파일 경로
     */
    private String screofeFileCours;
    /**
     * 창고 코드
     */
    private String wrhousCode;
    /**
     * 창고 이름
     */
    private String wrhousNm;
 
    // 계약 발주 상세 Table Insert 용 Field
    /**
     * 계약 발주 번호
     */
    private String cntrctOrderNo;
    /**
     * 발주 중량
    */
    private int orderingWt;
    /**
     * 번들 중량
    */
    private BigDecimal bundleWt;
    /**
     * 번들 수량
    */
    private int bundleQy;
}
