package com.sorincorp.fo.my.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class MyPageMenuVO implements Serializable {
	
	private static final long serialVersionUID = 8498429212264363431L;

	/****** JAVA VO CREATE : CO_MENU_BAS(공통_메뉴 기본) ******/
	/**
	 * 메뉴 번호
	 */
	private int menuNo;
	/**
	 * 시스템 구분 코드
	 */
	private String sysSeCode;
	/**
	 * 메뉴 설명
	 */
	private String menuDc;
	/**
	 * 상위 메뉴 번호
	 */
	private int upperMenuNo;
	/**
	 * 메뉴 레벨
	 */
	private int menuLevel;
	/**
	 * 메뉴 명칭
	 */
	private String menuNm;
	/**
	 * 메뉴 URL
	 */
	private String menuUrl;
	/**
	 * 메뉴 순서
	 */
	private int menuOrdr;
	/**
	 * 사용 여부
	 */
	private String useAt;
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;

}
