package com.sorincorp.fo.my.model;

import lombok.Data;

@Data
public class OrPcChangegldBasVO {
	/******  JAVA VO CREATE : OR_PC_CHANGEGLD_BAS(주문_가격 변동금 기본)                                                                     ******/
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 발생 순번
    */
    private long occrrncSn;
    /**
     * 발생 일시
    */
    private String occrrncDt;
    /**
     * 평가 금액
    */
    private long evlAmount;
    /**
     * 가격 변동금 상태 코드
    */
    private String pcChangegldSttusCode;
    /**
     * 가격 변동금 상태
     */
    private String pcChangegldSttusNm;
    /**
     * 단가 기준 기 납입 금액
    */
    private long untpcStdrPrePayAmount;
    /**
     * 기 납입 금액
    */
    private long prePayAmount;
    /**
     * 변동 단가
    */
    private long changeUntpc;
    /**
     * 확정 변동 단가
    */
    private long dcsnChangeUntpc;
    /**
     * 입출금 대상 금액
    */
    private long rcppayTrgetAmount;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 멤버 아이디
     */
    private String mberId;
    private long mntncChangeAmount;
    /**
     * 단위 구간 값
     */
    private int unitSctnVal;
    /**
     * 업체 번호
     */
    private String entrpsNo;
    /**
     * 발생 순번 (여러개)
     */
    private long[] occrrncSns;
}
