package com.sorincorp.fo.my.model;

import lombok.Data;

@Data
public class BankInfoVO {

	/******  JAVA VO CREATE : MB_ENTRPS_LON_GRNTY_BANK_INFO_BAS(회원_업체 대출 보증 은행 정보)                                               ******/
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 은행 코드
    */
    private String bankCode;
    /** 은행 명 */
    private String bankNm;
    /**
     * 업체 은행 순번
    */
    private long entrpsBankSn;
    /**
     * 사용 여부
    */
    private String useAt;
    /**
     * 대출 보증 사용 신청 일시
    */
    private java.sql.Timestamp lonGrntyUseReqstDt;
    /**
     * 대출 보증 사용 해지 일시
    */
    private java.sql.Timestamp lonGrntyUseTrmnatDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;

}
