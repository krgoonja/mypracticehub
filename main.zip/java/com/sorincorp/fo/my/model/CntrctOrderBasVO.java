package com.sorincorp.fo.my.model;

import lombok.Data;

/******  JAVA VO CREATE : CN_CNTRCT_ORDER_BAS(계약_계약 발주 기본)                                                                       ******/
@Data
public class CntrctOrderBasVO {

	/** 견적 번호 */
	private String estmtNo;
	/**
	* 계약 발주 번호
	*/
	private String cntrctOrderNo;
	/**
	* 계약 번호
	*/
	private String cntrctNo;
	/**
	 * 계약 년월
	 */
	private String cntrctYm;
	/**
	 * 계약 년월 순번
	 */
	private int cntrctYmSn;
    /**
     * 회원 번호
    */
    private String mberNo;
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 발주 일시
    */
    private String orderDt;
	/**
	* 판매 방식 코드
	*/
	private String sleMthdCode;
	/**
	* 금속 코드
	*/
	private String metalCode;
	/**
	* 아이템 순번
	*/
	private int itmSn;
	/**
	* 권역 대분류 코드
	*/
	private String dstrctLclsfCode;
	/**
	 * 권역 대분류
	 */
	private String dstrctLclsfNm;
	/**
	* 브랜드 그룹 코드
	*/
	private String brandGroupCode;
	/**
	 * 브랜드 그룹
	 */
	private String brandGroupNm;
	/**
	* 브랜드 코드
	*/
	private String brandCode;
	/**
     * 브랜드 명
     */
    private String brandNm;
	/**
	* 주문 중량
	*/
	private int orderWt;
	/**
	* 총 번들 수량
	*/
	private int totBundleQy;
	/**
	* 배송 수단 코드
	*/
	private String dlvyMnCode;
	/**
	 * 배송 수단
	 */
	private String dlvyMn;
	/**
	* 출고 요청 일자
	*/
	private String dlivyRequstDe;
    /**
     * 권역 중분류 코드
    */
    private String dstrctMlsfcCode;
	/**
	* 배송지 명
	*/
	private String dlvrgNm;
	/**
	* 배송 요청 내용
	*/
	private String dlvyRequstCn;
	/**
	* 단가 산식 코드
	*/
	private String untpcMntnfrmlaCode;
	/**
	* 통화 구분 코드
	*/
	private String crncySeCode;
	/**
	* 프리미엄 가격
	*/
	private long premiumPc;
	/**
	 * QP 코드
	 */
	private String qpCode;
	/**
	 * 단가 확정 일자
	 */
	private String untpcDcsnDe;
    /**
     * 프라이싱 번호
    */
    private String pricingNo;
    /**
     * 장바구니 번호
    */
    private String bsktNo;
    /**
     * 결제 기한 일자
     */
    private String setleTmlmtDe;
	/**
	* 주문 번호
	*/
	private String orderNo;
	/**
	 * 취소 교환 반품 번호
	 */
	private String canclExchngRtngudNo;
	/**
	* 지정가 주문 번호
	*/
	private String limitOrderNo;
	/**
	* 미결제 사유
	*/
	private String unsetlResn;
	/**
	* 삭제 일시
	*/
	private String deleteDt;
	/**
	* 삭제 여부
	*/
	private String deleteAt;
	/**
	* 최초 등록자 아이디
	*/
	private String frstRegisterId;
	/**
	* 최초 등록 일시
	*/
	private String frstRegistDt;
	/**
	* 최종 변경자 아이디
	*/
	private String lastChangerId;
	/**
	* 최종 변경 일시
	*/
	private String lastChangeDt;


	/**
	* LME 평균
	*/
	private java.math.BigDecimal lmeAvrg;
	/**
	* 환율 평균
	*/
	private java.math.BigDecimal ehgtAvrg;
	/**
	* LME 조정 계수 평균
	*/
	private java.math.BigDecimal lmeMdatCffcntAvrg;
	/**
	* FX 조정 계수 평균
	*/
	private java.math.BigDecimal fxMdatCffcntAvrg;
	/**
	* 평균가 상품 단가
	*/
	private long avrgpcGoodsUntpc;
	/** 계약 월 */
	private int cntrctMm;
	/** 계약 승인 일시 */
	private String cntrctConfmDt;
	/** 주문자 명 */
	private String ordrrNm;

	/**
	* 평균가 확정 단가 여부
	*/
	private String avrgpcDcsnUntpcAt;

	/**
	 * 결제기한
	 */
	private String setleLmt;
	/**
	 * 지정가 주문 상태 코드
	 */
	private String limitOrderSttusCode;
	/**
	 * 지정가 주문 상태명
	 */
	private String limitOrderSttusNm;
	/**
	 * 주문 상태 코드
	 */
	private String orderSttusCode;
	/**
	 * 주문 상태
	 */
	private String orderSttusNm;

	/**
	 * 배송지 번호
	 */
	private String dlvrgNo;
	/**
	 * 재고 할당 구분 코드
	 * 10 : LIVE
	 * 20 : 평균가
	 */
	private String invntryAsgnSeCode;
	/**
	 * 평균가 권역 대분류 코드
	 * 00 : 권역 무관(인천 또는 부산)
	 * 10 : 인천
	 * 20 : 부산
	 */
	private String avrgpcDstrctLclsfCode;
	/**
	 * 판매 단위 중량
	 */
	private int sleUnitWt;
	/**
	 * 상품 명
	 */
	private String goodsNm;
	/**
	 * 아이템 명
	 */
	private String itmNm;

	public void copyCntrctOrderData(CntrctOrderBasVO cntrctOrderBasVO) {
		this.metalCode = cntrctOrderBasVO.getMetalCode();
		this.itmSn = cntrctOrderBasVO.getItmSn();
		this.untpcMntnfrmlaCode = cntrctOrderBasVO.getUntpcMntnfrmlaCode();
		this.crncySeCode = cntrctOrderBasVO.getCrncySeCode();
		this.premiumPc = cntrctOrderBasVO.getPremiumPc();
		this.qpCode = cntrctOrderBasVO.getQpCode();
		this.sleUnitWt = cntrctOrderBasVO.getSleUnitWt();
		this.goodsNm = cntrctOrderBasVO.getGoodsNm();
		this.itmNm = cntrctOrderBasVO.getItmNm();
	}
}
