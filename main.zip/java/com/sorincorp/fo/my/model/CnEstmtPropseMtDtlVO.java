package com.sorincorp.fo.my.model;

import lombok.Data;

@Data
public class CnEstmtPropseMtDtlVO {
    /******  JAVA VO CREATE : CN_ESTMT_PROPSE_MT_DTL(계약_견적 제안 월 상세)                                                                 ******/
    /**
     * 견적 번호
    */
    private String estmtNo;
    /**
     * 제안 년월
    */
    private String propseYm;
    /**
     * 제안 년월 텍스트
     */
    private String propseYmText;
    /**
     * 제안 년월 순번
    */
    private int propseYmSn;
    /**
     * 평균가 권역 대분류 코드
    */
    private String avrgpcDstrctLclsfCode;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 주문 중량
    */
    private int orderWt;
    /**
     * 통화 구분 코드
    */
    private String crncySeCode;
    /**
     * 통화 구분
    */
    private String crncySe;
    /**
     * 프리미엄 가격
    */
    private long premiumPc;
    /**
     * QP 코드
    */
    private String qpCode;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    
    /* 계약 관련 항목 */
    /**
     * 계약 번호
     */
    private String cntrctNo;
}
