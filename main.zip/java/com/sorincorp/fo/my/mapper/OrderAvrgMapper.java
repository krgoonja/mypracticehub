package com.sorincorp.fo.my.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.fo.my.model.CnEstmtPropseMtDtlVO;
import com.sorincorp.fo.my.model.CntrctMtAsgnInvntryDtlVO;
import com.sorincorp.fo.my.model.CntrctMtDtlVO;
import com.sorincorp.fo.my.model.CntrctOrderBasVO;
import com.sorincorp.fo.my.model.CntrctOrderDtlVO;
import com.sorincorp.fo.my.model.OrderAvrgVO;

public interface OrderAvrgMapper {

	List<OrderAvrgVO> selectOrderArvgList(OrderAvrgVO orderAvrgVO) throws Exception;
	
	List<CntrctMtDtlVO> selectCntrctOrderInfoList(String cntrctNo, String cntrctYm) throws Exception;

	OrderAvrgVO selectOrderArvgDetail(String estmtNo) throws Exception;
	
	List<Map<String, Object>> selectCnEstmtMtOrderWtDtlList(String estmtNo) throws Exception;

	List<CnEstmtPropseMtDtlVO> selectCnEstmtPropseMtDtlList(String estmtNo) throws Exception;

	int updateEstmtSttus(OrderAvrgVO orderAvrgVO) throws Exception;
	
	int insertCnEstmtBasHst(String estmtNo) throws Exception;
	
	Map<String, String> selectMessageData(String estmtNo) throws Exception;

	OrderAvrgVO selectCnEstmtBas(String estmtNo) throws Exception;

	void insertCnCntrctBas(OrderAvrgVO orderAvrgVO) throws Exception;

	void insertCnCntrctMtDtl(CnEstmtPropseMtDtlVO cnEstmtPropseMtDtlVO) throws Exception;
	
	void insertCnCntrctMtDtlHst(String cntrctNo, String cntrctYm, int cntrctYmSn) throws Exception;
	
	void updateCntrctConfmInfo(OrderAvrgVO orderAvrgVO) throws Exception;
	
	void insertCnCntrctBasHst(String cntrctNo) throws Exception;

	OrderAvrgVO selectCntrctBaseInfo(String cntrctNo) throws Exception;

	List<Map<String, String>> selectCntrctMtList(String cntrctNo) throws Exception;

	CntrctMtDtlVO selectPricingDcsnInfo(CntrctMtDtlVO cntrctMtDtlVO) throws Exception;
	
	List<CntrctMtDtlVO> selectCntrctInfo(CntrctMtDtlVO cntrctMtDtlVO) throws Exception;

	List<CntrctOrderBasVO> selectCntrctOrderList(CntrctMtDtlVO cntrctMtDtlVO) throws Exception;

	int updateCnCntrctMtDtl(CntrctMtDtlVO cntrctMtDtlVO) throws Exception;

	List<CntrctMtDtlVO> selectGoodsAsgnInfo(CntrctMtDtlVO cntrctMtDtlVO) throws Exception;

	List<CntrctMtDtlVO> selectAsgnInvntryList(CntrctMtDtlVO cntrctMtDtlVO) throws Exception;

	CntrctOrderBasVO selectCntrctOrder(CntrctOrderBasVO cntrctOrderBasVO) throws Exception;

	List<CntrctMtAsgnInvntryDtlVO> selectAsgnBlList(CntrctOrderBasVO cntrctOrderBasVO) throws Exception;

	void insertCnCntrctOrderBas(CntrctOrderBasVO cntrctOrderBasVO) throws Exception;
	
	void insertCnCntrctOrderBasHst(String cntrctNo) throws Exception;

	void insertCnCntrctOrderDtl(CntrctMtAsgnInvntryDtlVO cntrctMtAsgnInvntryDtlVO) throws Exception;
	
	void insertCnCntrctOrderDtlHst(String cntrctOrderNo, String blNo) throws Exception;

	List<CntrctMtDtlVO> selectNewAsgnInfoHst(CntrctMtDtlVO cntrctMtDtlVO) throws Exception;

	void updateNewAsgnAt(CntrctMtDtlVO cntrctMtDtlVO) throws Exception;
	
	void insertCnCntrctMtAsgnInvntryDtlHst(CntrctMtDtlVO cntrctMtDtlVO) throws Exception;

	List<CntrctMtAsgnInvntryDtlVO> selectScreofeList(CntrctMtAsgnInvntryDtlVO cntrctMtAsgnInvntryDtlVO) throws Exception;

	List<CntrctOrderDtlVO> selectCntrctOrderDtl(String cntrctOrderNo) throws Exception;

	void deleteCntrctOrderBas(String cntrctOrderNo) throws Exception;

	void deleteCntrctOrderDtl(String cntrctOrderNo) throws Exception;

	void deleteCntrctOrderBas(CntrctOrderBasVO cntrctOrderBasVO) throws Exception;

	void deleteCntrctOrderDtl(CntrctOrderBasVO cntrctOrderBasVO) throws Exception;

	String getSetleTmlmtDe(String dlivyRequstDe) throws Exception;

	long selectAvrgpcLiveWt(CntrctMtDtlVO cntrctMtDtlVO) throws Exception;
}
