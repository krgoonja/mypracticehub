package com.sorincorp.fo.my.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.fo.mb.model.MbEntrpsGradVO;
import com.sorincorp.fo.my.model.BankInfoVO;
import com.sorincorp.fo.my.model.DashboardVO;
import com.sorincorp.fo.my.model.InqryDtlsVO;
import com.sorincorp.fo.my.model.OrPcChangegldBasVO;
import com.sorincorp.fo.my.model.PaytEsamtVO;
import com.sorincorp.fo.my.model.SetleDtlsDetailVO;

/**
 * DashboardMapper.java
 * @version
 * @since 2021. 7. 27.
 * @author srec0048
 */
public interface DashboardMapper {

	/**
	 * <pre>
	 * 처리내용: 상단 대시보드 결제수단을 조회한다.
	 * </pre>
	 * @date 2021. 9. 13.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 13.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> selectSetleMnInfo(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 마이페이지 최근 30일 거래내역을 조회한다.
	 * </pre>
	 * @date 2021. 7. 27.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 27.			srec0048			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	DashboardVO selectRecentOrderDtls(Map<String, Object> param) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 마이페이지 최근 24시간 내 3개 알림 내역 조회한다.
	 * </pre>
	 * @date 2021. 8. 12.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 12.			srec0048			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<DashboardVO> selectRecentNtcn(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 마이페이지 최근 7일내 3개 문의/답변 내역 조회한다.
	 * </pre>
	 * @date 2021. 8. 12.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 12.			srec0048			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<InqryDtlsVO> selectRecentInqryAnswer(String entrpsNo) throws Exception;		//일반회원
	List<InqryDtlsVO> selectRecentSimpleInqryAnswer(String mberNo) throws Exception;	//간편회원
	/**
	 * <pre>
	 * 처리내용: 주문 진행중인 건을 조회한다.
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 3.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> selectOrderProgrsInfo(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기업뱅킹(하나은행 앱)을 통해서 환불 진행중인 건을 조회한다.
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 3.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param rcpmnyAcnutNo
	 * @return
	 * @throws Exception
	 */
	int selectRefndProgrsCnt(String rcpmnyAcnutNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 인출 요청한다.
	 * </pre>
	 * @date 2021. 10. 26.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 26.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param refundRequstInfo
	 * @throws Exception
	 */
	void insertRefundRequst(Map<String, Object> refundRequstInfo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 환붕 api 통신 장애 시 인출 요청 실패로 업데이트한다.
	 * </pre>
	 * @date 2021. 11. 26.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 26.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param refundRequstInfo
	 * @throws Exception
	 */
	void updateRefundRequstSttu(Map<String, Object> refundRequstInfo) throws Exception;

	/**
	 * <pre>
	 * 결제예정액 영역 조회
	 * </pre>
	 * @date 2022. 7. 15.
	 * @author srec0051
	 * @param param
	 * @return
	 */
	Map<String, Object> selectUnSetleAmount(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 결제예정 내역 목록 조회
	 * </pre>
	 * @date 2022. 7. 15.
	 * @author srec0051
	 * @param param
	 * @return
	 */
	List<PaytEsamtVO> selectListUnSetleAmountDtl(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 회원_업체 대출 보증 은행 정보 조회
	 * </pre>
	 * @date 2022. 7. 22.
	 * @author srec0051
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	List<BankInfoVO> selectListEntrpsBank(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 결제 내역 상세 목록
	 * </pre>
	 * @date 2022. 8. 2.
	 * @author srec0051
	 * @param paramVo
	 * @return List 
	 * @history 2024. 1. 2. 고도화 평균가로 수정
	 */
	List<SetleDtlsDetailVO> setleDtlsList(SetleDtlsDetailVO paramVo) throws Exception;

	/**
	 * <pre>
	 * 호출 건 응답 코드 확인
	 * </pre>
	 * @date 2022. 12. 14.
	 * @author srec0051
	 * @param delngSeqNo
	 * @return
	 * @throws Exception
	 */
	String selectEwalletRspnCode(String delngSeqNo) throws Exception;
	
	/**
	 * <pre>
	 * 회원_업체 등급 기준 구매 수량
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author sein
	 * @param 
	 * @return
	 * @throws Exception
	 */
	MbEntrpsGradVO selectMbEntrpsGradStdrPurchsQy() throws Exception;

	/**
	 * <pre>
	 * 회원 등급 할인 금액
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author sein
	 * @param 
	 * @return
	 * @throws Exception
	 */
	List<MbEntrpsGradVO> selectMbGradDscntAmountList() throws Exception;
	
	/**
	 * <pre>
	 * 당월 구매 수량
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author sein
	 * @param entrpsNo
	 * @return totRealOrderWtSum
	 * @throws Exception
	 */
	int selectMbTotRealOrderWtSum(String entrpsNo) throws Exception ;
		
	/**
	 * <pre>
	 * 전월 기준 구매 정보(MB_ENTRPS_MNBY_PURCHS_BNEF_BAS)
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author sein
	 * @param 
	 * @return
	 * @throws Exception
	 */
	MbEntrpsGradVO mbEntrpsMnbyPurchsInfo(String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 상시 할인 금액 리스트(3000,4000,5000)
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author sein
	 * @param 
	 * @return
	 * @throws Exception
	 */
	List<MbEntrpsGradVO> selectcpAtmcIsuCouponInfoList() throws Exception;

	void insertOrSetleBas(Map<String, Object> refundRequstInfo) throws Exception;

	List<OrPcChangegldBasVO> selectOrPcChangegldBas(OrPcChangegldBasVO defrayRequstInfo);

	void updateOrPcChangegldBas(OrPcChangegldBasVO orPcChangegldBasVO);

}
