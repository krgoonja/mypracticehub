package com.sorincorp.fo.my.mapper;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.sorincorp.fo.my.model.OrderDtlsVO;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.order.model.CommOrOrderFtrsBasVO;
import com.sorincorp.comm.order.model.ItPurchsInfoBas;
import com.sorincorp.comm.order.model.OrOrderDtlVO;
import com.sorincorp.comm.order.model.OrderDtlsClaimVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.fo.my.model.OrOrderFtrsVO;

public interface ClaimMapper {

	/**
	 * <pre>
	 * 클레임 데이터 조회
	 * </pre>
	 * @date 2021. 9. 27.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 27.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param searchVo
	 * @return
	 */
	OrderDtlsClaimVO getClaimData(OrderDtlsVO searchVo) throws Exception;

	/**
	 * <pre>
	 * BL 상세 데이터 조회
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param claimVo
	 * @return
	 */
	List<OrOrderDtlVO> getListOrOrderDtl(OrderDtlsClaimVO claimVo) throws Exception;

	/**
	 * <pre>
	 * 클레임 마스터 업데이트
	 * </pre>
	 * @date 2021. 10. 13.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 13.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 */
	int updateClaimMaster(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 삼성선물 마스터 등록
	 * </pre>
	 * @date 2021. 10. 17.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 17.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	int insertOrOrderFtrsBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 삼성선물 마스터 삭제
	 * </pre>
	 * @date 2021. 11. 29.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 29.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param ftrnNoList
	 * @return
	 */
	int deleteSamsungBase(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 삼성 선물 만기 조정 데이터
	 * </pre>
	 * @date 2021. 11. 4.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 4.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param bl
	 * @return
	 */
	List<OrOrderFtrsVO> getListOrderFtrsExecut(OrOrderDtlVO bl) throws Exception;

	/**
	 * <pre>
	 * 삼성 선물 만기 조정 데이터 여부 확인 카운트
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	int getCntOrderFtrsAdjustment(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 삼성선물 체결건 확인
	 * </pre>
	 * @date 2021. 10. 18.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 18.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 */
	List<CommOrOrderFtrsBasVO> selectOrderSamsungResponse(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 상품 PO 정보 기본 조회
	 * </pre>
	 * @date 2021. 10. 18.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 18.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param bl
	 * @return
	 */
	ItPurchsInfoBas selectItPurchsInfoBas(OrOrderDtlVO bl) throws Exception;

	/**
	 * <pre>
	 * 하나은행 FX 마스터 등록
	 * </pre>
	 * @date 2021. 10. 18.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 18.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 */
	int insertOrOrderFshgBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 상품_BL 정보 기본 재고 원복
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 */
	int updateRecoverInvntryBlInfoBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 상품_BL 정보 기본 재고 수정
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 */
	int updateInvntryBlInfoBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 상품_BL 정보이력 상세 등록
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 */
	int insertInvntryBlInfoHistDtl(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 상품_BL 정보 기본 재고 수정 이력 등록
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 */
	int insertBlInfoBasHst(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param bl
	 * @return
	 */
	ItemPriceMatchingBlInfoVO getItBlInfo(OrOrderDtlVO bl) throws Exception;

	/**
	 * <pre>
	 * 클레임 마스터 수정
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 */
	int updateLastClaimMaster(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 클레임 마스터 이력 등록
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 */
	int insertClaimMasterHst(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 첨부파일 등록
	 * </pre>
	 * @date 2021. 11. 1.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 1.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param fileVo
	 * @return
	 */
	int insertOrCanclExchngRtngudAtchmnflBas(OrderDtlsClaimVO fileVo) throws Exception;

	/**
	 * <pre>
	 * 첨부파일 조회
	 * </pre>
	 * @date 2021. 11. 16.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 16.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	List<FileDocVO> selectListFileDocInfo(OrderDtlsClaimVO vo) throws Exception;

	/**
	 * <pre>
	 * 고정가는 할증요율 조회
	 * </pre>
	 * @date 2021. 11. 19.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 19.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 */
	BigDecimal selectTotAmtTariff(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 거래명세서, 세금계산서 ozReport 정보 조회
	 * </pre>
	 * @date 2021. 12. 1.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 1.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param searchVo
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> getTaxBillInfo(OrderDtlsVO searchVo) throws Exception;

	/**
	 * <pre>
	 * SMS 내용 조회
	 * </pre>
	 * @date 2021. 12. 6.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 6.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 */
	Map<String, String> selectSmsInfo(OrderModel orderModel);

	/**
	 * <pre>
	 * Email 내용 조회
	 * </pre>
	 * @date 2021. 12. 17.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 17.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 */
	Map<String, String> selectMailInfo(OrderModel orderModel);

}
