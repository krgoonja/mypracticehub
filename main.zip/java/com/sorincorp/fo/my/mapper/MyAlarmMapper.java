package com.sorincorp.fo.my.mapper;

import java.util.List;

import com.sorincorp.fo.my.model.MyCmmrcAlarmVO;
import com.sorincorp.fo.my.model.MyHopePcAlarmVO;
import com.sorincorp.fo.my.model.MyInvntryAlarmVO;
import com.sorincorp.fo.op.model.HopePcNtcnSetupVO;
import com.sorincorp.fo.op.model.InvntryNtcnSetupVO;

/**
 * MyAlarmMapper.java
 * @version
 * @since 2021. 9. 8.
 * @author srec0042
 */
public interface MyAlarmMapper {

	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 희망가 알림 내역을 조회한다.
	 * </pre>
	 * @date 2021. 9. 23.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 23.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @return
	 */
	List<MyHopePcAlarmVO> selectHopePcAlarm(String entrpsNo);

	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 희망가 알림 가격을 수정한다.
	 * </pre>
	 * @date 2022. 2. 11.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 2. 11.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 */
	int updateHopePcAlarm(HopePcNtcnSetupVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 희망가 알림 사용 상태를 수정한다.
	 * </pre>
	 * @date 2022. 2. 11.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 2. 11.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 */
	int updateHopePcUseAt(MyHopePcAlarmVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 희망가 알림을 삭제한다.
	 * </pre>
	 * @date 2021. 9. 23.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 23.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param deleteVo
	 * @return
	 */
	int deleteHopePcAlarm(HopePcNtcnSetupVO deleteVo);
	
	
	int deleteInvntryAlarm(InvntryNtcnSetupVO deleteVo);
	
	//void updateInvntryAlarm(InvntryNtcnSndngVO updateVo);
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 목표가 알림을 조회한다.
	 * </pre>
	 * @date 2021. 9. 30.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 30.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	List<MyHopePcAlarmVO> selectHopePcAlarmList(String entrpsNo);

	/**
	 * <pre>
	 * 처리내용: 헤더 - 알림 내역 조회 
	 * </pre>
	 * @date 2021. 9. 30.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 30.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	List<MyHopePcAlarmVO> selectHeaderAlarm(String entrpsNo);
	
	/**
	 * <pre>
	 * 처리내용: 헤더 - 알림 개수 count
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	int countHeaderAlarm(String entrpsNo);

	List<MyInvntryAlarmVO> selectInvntryAlarm(String entrpsNo);

	int updateInvntryUseAt(InvntryNtcnSetupVO vo);
	
	List<MyCmmrcAlarmVO> selectCmmrcAlarm(String entrpsNo);

}
