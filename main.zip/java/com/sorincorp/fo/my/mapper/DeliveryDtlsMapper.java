package com.sorincorp.fo.my.mapper;

import java.util.List;

import com.sorincorp.fo.my.model.DeliveryDetailDtlsVO;
import com.sorincorp.fo.my.model.DeliveryDtlsVO;

public interface DeliveryDtlsMapper {
	/**
	 * <pre>
	 * 처리내용: 기본 배송 내역 조회
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param deliveryDtlsVO
	 * @return
	 * @throws Exception
	 */
	List<DeliveryDtlsVO> selectDeliveryDtlsList(DeliveryDtlsVO deliveryDtlsVO) throws Exception;
	/**
	 * <pre>
	 * 처리내용: 배송 내역 총 건수 조회
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param deliveryDtlsVO
	 * @return
	 * @throws Exception
	 */
	int selectDeliveryDtlsTotCnt(DeliveryDtlsVO deliveryDtlsVO) throws Exception;
	/**
	 * <pre>
	 * 처리내용: 배송 상세 내역 조회
	 * </pre>
	 * @date 2024. 5. 22.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 22.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	List<DeliveryDetailDtlsVO> selectDeliveryDetailDtlsList(String orderNo) throws Exception;
}
