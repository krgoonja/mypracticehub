/**
 *
 */
package com.sorincorp.fo.my.mapper;

import org.springframework.data.repository.query.Param;

import com.sorincorp.fo.my.model.SimplMberMyInfoMngVO;


/**
 * MyInfoMngMapper.java
 * @version
 * @since 2021. 8. 23.
 * @author srec0009
 */
public interface SimplMberMyInfoMngMapper {

	/**
	 * <pre>
	 * 처리내용: 간편회원 내정보관리
	 * </pre>
	 * @date 2021. 8. 31.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 31.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simplMberNo
	 * @return
	 */
	SimplMberMyInfoMngVO selectSimplMberInfo(@Param("simplMberNo") String simplMberNo);

	/**
	 * <pre>
	 * 처리내용: 간편회원 비밀번호 확인
	 * </pre>
	 * @date 2021. 9. 1.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 1.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @return
	 */
	String selectSimplChkPw(@Param("simplMberNo") String mberNo);

	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경
	 * </pre>
	 * @date 2021. 9. 1.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 1.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @param mberSecretNo
	 * @return
	 */
	int updateNewPw(SimplMberMyInfoMngVO simplMberMyInfoMngVO);

	/**
	 * <pre>
	 * 처리내용: 간편회원 정보 이력 입력
	 * </pre>
	 * @date 2021. 9. 1.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 1.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 */
	void insertSimplMberInfoHst(@Param("simplMberNo") String simplMberNo);

	/**
	 * <pre>
	 * 처리내용: 간편회원 정보 수정
	 * </pre>
	 * @date 2021. 9. 1.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 1.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simplMberMyInfoMngVO
	 * @return
	 */
	int updateSimplMberMyInfoDtl(SimplMberMyInfoMngVO simplMberMyInfoMngVO);


	/**
	 * <pre>
	 * 처리내용: 간편회원 탈퇴
	 * </pre>
	 * @date 2021. 9. 6.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 6.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simplMberNo
	 * @return
	 */
	int deleteSimplMber(SimplMberMyInfoMngVO simplMberMyInfoMngVO);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 22.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 22.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simplMberMyInfoMngVO
	 * @return
	 */
	SimplMberMyInfoMngVO selectAgreAt(SimplMberMyInfoMngVO simplMberMyInfoMngVO);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 12. 6.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 6.			srec0009			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	String selectToday();

	/**
	 * <pre>
	 * 처리내용: 마케팅수신동의 정보 수정
	 * </pre>
	 * @date 2022. 6. 9.
	 * @author sumin95
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 9.				sumin95				최초작성
	 * ------------------------------------------------
	 * @return
	 */
	int updateMberMarktRecptnMediaBas(SimplMberMyInfoMngVO simplMberMyInfoMngVO);
	
	/**
	 * <pre>
	 * 처리내용: 마케팅수신동의 정보 이력 저장
	 * </pre>
	 * @date 2022. 6. 9.
	 * @author sumin95
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 9.				sumin95				최초작성
	 * ------------------------------------------------
	 * @return
	 */
	void insertMberMarktRecptnMediaHst(SimplMberMyInfoMngVO simplMberMyInfoMngVO);
}
