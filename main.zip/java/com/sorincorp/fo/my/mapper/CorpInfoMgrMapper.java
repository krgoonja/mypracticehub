package com.sorincorp.fo.my.mapper;

import java.util.List;

import com.sorincorp.fo.my.model.AtchVO;
import com.sorincorp.fo.my.model.CorpInfoMgrVO;
import com.sorincorp.fo.my.model.CorpKycInfoMgrVO;

public interface CorpInfoMgrMapper {

	/**
	 * <pre>
	 * 처리내용 : 업체 상세정보를 조회한다.
	 * </pre>
	 *
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 10.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param corpInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	CorpInfoMgrVO selectCorpInfoDetail(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체정보를 수정한다.
	 * </pre>
	 *
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 10.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param corpInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	int updateMbEntrpsInfoBas(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체정보 이력을 insert한다
	 * </pre>
	 *
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 10.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param corpInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	int insertMbEntrpsInfoBasHst(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체 회원정보를 수정한다.
	 * </pre>
	 *
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 10.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param corpInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	int updateMbMberInfoBas(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체회원 이력정보를 insert한다.
	 * </pre>
	 *
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 10.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param corpInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	int insertMbMberInfoBasHst(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체정보 첨부파일을 insert한다.
	 * </pre>
	 *
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 10.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param corpInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	int insertMbEntrpsAtchFileRls(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체첨부파일 이력을 insert한다.
	 * </pre>
	 *
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 10.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param corpInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	int insertMbEntrpsAtchFileRelateHst(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	String selectMemeberSecessionPossibleYn(String mberNo) throws Exception;

	int checkPassWord(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	List<CorpInfoMgrVO> selectLonGrntyBankUseAtList(String entrpsNo) throws Exception;

	int selectMbEntrpsLonGrntyBankInfoBasCnt(CorpInfoMgrVO bankUseVO) throws Exception;

	int insertMbEntrpsLonGrntyBankInfoBas(CorpInfoMgrVO bankUseVO) throws Exception;

	int insertMbEntrpsLonGrntyBankInfoBasHst(CorpInfoMgrVO bankUseVO) throws Exception;

	int deleteMbEntrpsLonGrntyBankInfoBas(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	String selectTrmnatPossibleAt(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	int selectTrmnatSttusCnt(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	int deleteOrCdtlnEntrpsDtl(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	int insertOrCdtlnEntrpsDtlHst(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용 : KYC 입력 정보 조회
	 * </pre>
	 *
	 * @date 2022. 12. 4.
	 * @author sumin95
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------2022. 12. 4. sumin95
	 *          최초작성 ------------------------------------------------
	 * @param CorpKycInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	CorpKycInfoMgrVO selectKycCorpInfo(CorpKycInfoMgrVO corpKycInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용 : KYC 테이블 정보 카운트
	 * </pre>
	 *
	 * @date 2022. 12. 4.
	 * @author sumin95
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------2022. 12. 4. sumin95
	 *          최초작성 ------------------------------------------------
	 * @param CorpInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	int selectKycCorpInfoCount(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용 : KYC 입력 정보 저장
	 * </pre>
	 *
	 * @date 2022. 12. 4.
	 * @author sumin95
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------2022. 12. 4. sumin95
	 *          최초작성 ------------------------------------------------
	 * @param CorpKycInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	int updateCorpKycInfoDetail(CorpKycInfoMgrVO corpKycInfoMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용 : KYC 첨부파일 정보 저장
	 * </pre>
	 *
	 * @date 2022. 12. 4.
	 * @author sumin95
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 12. 4.
	 *          sumin95 최초작성 ------------------------------------------------
	 * @param AtchVO
	 * @return
	 * @throws Exception
	 */
	boolean insertKycAtchFileRls(AtchVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용 : KYC 첨부파일 정보 저장
	 * </pre>
	 *
	 * @date 2022. 12. 4.
	 * @author sumin95
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 12. 4.
	 *          sumin95 최초작성 ------------------------------------------------
	 * @param CorpKycInfoMgrVO
	 * @return
	 * @throws Exception
	 */
	boolean insertEntrpsKycInfo(CorpKycInfoMgrVO corpKycInfoMgrVO) throws Exception;
}