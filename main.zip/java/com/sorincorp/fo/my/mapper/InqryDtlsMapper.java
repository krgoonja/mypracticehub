package com.sorincorp.fo.my.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.fo.cs.model.InqryRegistVO;
import com.sorincorp.fo.my.model.InqryDtlsVO;

/**
 * InqryDtlsMapper.java
 * @version
 * @since 2021. 7. 28.
 * @author srec0048
 */
/**
 * InqryDtlsMapper.java
 * @version
 * @since 2021. 8. 20.
 * @author srec0048
 */
public interface InqryDtlsMapper {

	/**
	 * <pre>
	 * 처리내용: 문의내역 총건수를 조회한다.
	 * </pre>
	 * @date 2021. 7. 30.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 30.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqryDtlsVO
	 * @return
	 * @throws Exception
	 */
	int selectInqryDtlsListTotCnt(InqryDtlsVO inqryDtlsVO) throws Exception;
	int selectSimpleInqryDtlsListTotCnt(InqryDtlsVO inqryDtlsVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문의내역 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 7. 30.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 30.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqryDtlsVO
	 * @return
	 * @throws Exception
	 */
	List<InqryDtlsVO> selectSimpleInqryDtlsList(InqryDtlsVO inqryDtlsVO) throws Exception;
	List<InqryDtlsVO> selectInqryDtlsList(InqryDtlsVO inqryDtlsVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문의내역 상세를 조회한다.
	 * </pre>
	 * @date 2021. 7. 30.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 30.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqryDtlsVO
	 * @return
	 */
	InqryDtlsVO selectInqryDtlsDetail(InqryDtlsVO inqryDtlsVO) throws Exception;
	InqryDtlsVO selectSimpleInqryDtlsDetail(InqryDtlsVO inqryDtlsVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문의 내역 첨부파일 리스트 조회한다.
	 * </pre>
	 * @date 2021. 8. 19.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 19.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqrySn
	 * @return
	 */
	List<FileDocVO> selectAtchFileList(long inqrySn);

	/**
	 * <pre>
	 * 처리내용: 문의구분 중분류를 조회한다.
	 * </pre>
	 * @date 2021. 8. 5.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 5.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqrySeCode
	 * @return
	 */
	List<CommonCodeVO> selectInqrySeDetailCode(Map<String, String> param) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문의내용을 등록한다.
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqryDtlsVO
	 */
	void insertInqrySave(InqryDtlsVO inqryDtlsVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문의기본이력 테이블 저장한다.
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqrySn
	 * @throws Exception
	 */
	
	void insertSimpleInqrySave(InqryDtlsVO inqryDtlsVO) throws Exception;
	void insertCsInqryBasHst(long inqrySn) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문서기본 첨부파일 저장한다.(문의 첨부파일 기본)
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqryDtlsVO
	 * @throws Exception
	 */
	void insertInqryAtchmnfile(InqryDtlsVO inqryDtlsVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문서기본 첨부파일 저장한다.(문의 첨부파일 이력)
	 * </pre>
	 * @date 2021. 10. 13.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 13.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqryDtlsVO
	 * @throws Exception
	 */
	void insertCsInqryAtchmnflBasHst(long inqrySn) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문의내역을 삭제한다.
	 * </pre>
	 * @date 2021. 8. 20.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 20.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqrySn
	 * @throws Exception
	 */
	void deleteInqryDetail(InqryDtlsVO inqryDtlsVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 문의내역의 첨부파일을 삭제한다.(문의 첨부파일 기본)
	 * </pre>
	 * @date 2021. 8. 20.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 20.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param inqrySn
	 * @throws Exception
	 */
	void deleteInqryDetailAtchFile(InqryDtlsVO inqryDtlsVO) throws Exception;

	/**
	 * 
	 * <pre>
	 * 개인정보 수집 및 이용 동의에 대한 안내 (약관 내용1)
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author srec0054
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 14.			srec0054			최초작성
	 * ------------------------------------------------
	 * @return	InqryRegistVO
	 * @throws 	Exception
	 */
	InqryRegistVO selectStplatCnOne() throws Exception;
	
}
