package com.sorincorp.fo.my.mapper;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.sorincorp.fo.my.model.PapersManageDetailVO;
import com.sorincorp.fo.my.model.PapersManageVO;

/**
 * 
 * 서류 관리 Mapper.java
 * @version
 * @since 2021. 9. 8.
 * @author srec0054
 */
public interface PapersManageMapper {

	/**판매계약서 카운트*/
	Integer selectPapersManageSalesCnt(PapersManageVO paramVo);
	
	/**거래명세서 카운트*/
	Integer selectPapersManageTradeCnt(PapersManageVO paramVo); 		
	
	/**전자세금계산서 카운트*/
	Integer selectPapersManageTaxCnt(PapersManageVO paramVo);		
	
	/**출고지시서 카운트*/
	Integer selectPapersManageInstrCnt(PapersManageVO paramVo);		
	
	/**출고명세서 카운트*/
	Integer selectPapersManageDetailsCnt(PapersManageVO paramVo);	
	
	/**인수증 카운트*/
	Integer selectPapersManageTakeCnt(PapersManageVO paramVo);
	
	/**입금확인서 카운트*/
	Integer selectRcpmnyrCnt(PapersManageVO paramVo);
	
	/**입금확인서 카운트*/
	Integer selectPymntCnt(PapersManageVO paramVo);
	
	/**평균가견적서 카운트*/
	Integer selectPrqudoCnt(PapersManageVO paramVo);
	
	/**평균가계약서 카운트*/
	Integer selectCtrtcCnt(PapersManageVO paramVo);
	
	/**성적서 카운트*/
	Integer selectScreofeCnt(PapersManageVO paramVo);
	
	/**판매계약서 조회*/
	List<PapersManageVO> selectPapersManageSales(PapersManageVO paramVo);	
	
	/**거래명세서 조회*/
	List<PapersManageVO> selectPapersManageTrade(PapersManageVO paramVo);	
	
	/**전자세금계산서 조회*/
	List<PapersManageVO> selectPapersManageTax(PapersManageVO paramVo);		
	
	/**출고지시서 조회*/
	List<PapersManageVO> selectPapersManageInstr(PapersManageVO paramVo);	
	
	/**출고명세서 조회*/
	List<PapersManageVO> selectPapersManageDetails(PapersManageVO paramVo);	
	
	/**인수증 조회*/
	List<PapersManageVO> selectPapersManageTake(PapersManageVO paramVo);
	
	/**입금확인서 조회*/
	List<PapersManageVO> selectRcpmnyr(PapersManageVO paramVo);
	
	/**입금확인서 조회*/
	List<PapersManageVO> selectPymnt(PapersManageVO paramVo);
	
	/** 평균가 견적서 조회*/
	List<PapersManageVO> selectPrqudo(PapersManageVO paramVo);
	
	/** 평균가 계약서 조회*/
	List<PapersManageVO> selectCtrtc(PapersManageVO paramVo);

	/** 성적서 조회*/
	List<PapersManageVO> selectScreofe(PapersManageVO paramVo);
	
	/**상세 내역 조회 (주문)*/
	List<PapersManageDetailVO> selectPapersManageDetailList(PapersManageDetailVO paramVo);

	/**서류관리 상세 리스트 카운트*/
	Integer selectPapersManageDetailListCnt(PapersManageDetailVO paramVo);
	
	/**서류관리 상세 리스트 조회*/
	LinkedList<PapersManageDetailVO> selectPapersManage(PapersManageDetailVO paramVo);
	
	/**성적서&패킹리스트 리스트 조회*/
	List<PapersManageDetailVO> selectScreofePackngList(PapersManageDetailVO paramVo);

	/**처리내용:1차, 2차 매매계약서 내부 거래명세서, 세금계산서 ozReport 실행시 필요한 파라미터를 다시 조회*/
	List<Map<String, Object>> selectTaxTradeBillInfo(String orderNo);
	
	/**상단 대시보드 결제수단 조회*/
	PapersManageVO selectSetleMnInfo(PapersManageVO dashBoardParamVo);

	/**최근 30일 거래내역, 상단 대시보드 주문현황*/
	PapersManageVO selectRecentOrderDtls(PapersManageVO dashBoardParamVo);
	
	/**출고지시서 화물수취인 전화번호 복호화*/
	String selectMoblphonNoDecryption(PapersManageDetailVO paramVo);
	
	/**출고지시서 화물수취인 전화번호 포맷*/
	String selectFnGetTelNo(String decryptStr);

	List<PapersManageDetailVO> getRelatePapersInfo(PapersManageDetailVO unityOrderPapersVo);

	/**업체 이월렛 계좌 번호 조회*/
	String selectMberEwalletAcntNo(String orderNo);

	/**거래내역서 카운트*/
	Integer selectRcptPrufCnt(PapersManageVO paramVo);

	List<PapersManageVO> selectRcptPruf(PapersManageVO paramVo);

	List<PapersManageVO> selectChangegld(PapersManageVO paramVo, String pcChangegldSttusCode);
	
	Integer selectChangegldCnt(PapersManageVO paramVo, String pcChangegldSttusCode);
	
	List<Map<String, String>> getRecentChangegldCnfrmn(String orderNo);
	
	List<Map<String, String>> getAllChangegldCnfrmn(String orderNo);


}//end interface()
