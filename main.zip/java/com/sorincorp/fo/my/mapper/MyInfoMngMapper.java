/**
 *
 */
package com.sorincorp.fo.my.mapper;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.sorincorp.fo.my.model.MyInfoMngVO;
import com.sorincorp.fo.my.model.MyPageMenuVO;


/**
 * MyInfoMngMapper.java
 * @version
 * @since 2021. 8. 23.
 * @author srec0009
 */
public interface MyInfoMngMapper {

	/**
	 * <pre>
	 * 처리내용: 비밀번호 확인
	 * </pre>
	 * @date 2021. 9. 29.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 29.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @return
	 */
	String selectChkPw(String mberNo);

	/**
	 * <pre>
	 * 처리내용: 대시보드 > 내정보관리(상세)
	 * </pre>
	 * @date 2021. 8. 23.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 23.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @return
	 */
	MyInfoMngVO selectMyInfoMngDtl(String mberNo);

	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경
	 * </pre>
	 * @date 2021. 8. 24.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 24.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberSecretNo
	 * @return
	 */
	int updateNewPw(MyInfoMngVO myInfoMngVO);

	/**
	 * <pre>
	 * 처리내용: 멤버 정보 이력
	 * </pre>
	 * @date 2021. 8. 24.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 24.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @param mberSecretNo
	 */
	void insertMberInfoHst(@Param("mberNo") String mberNo);

	/**
	 * <pre>
	 * 처리내용: 마이페이지 >  정보 수정
	 * </pre>
	 * @date 2021. 8. 24.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 24.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param myInfoMngVO
	 * @return
	 */
	int updateMyInfoDtl(MyInfoMngVO myInfoMngVO);
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 >  정보 수정(마케팅동의여부)
	 * </pre>
	 * @date 2022. 6. 8.
	 * @author sumin95
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 8.				sumin95			최초작성
	 * ------------------------------------------------
	 * @param myInfoMngVO
	 * @return
	 */
	int updateMberMarktRecptnMediaBas(MyInfoMngVO myInfoMngVO);

	/**
	 * <pre>
	 * 처리내용: 마이페이지 >  정보 수정(마케팅동의여부이력)
	 * </pre>
	 * @date 2022. 6. 8.
	 * @author sumin95
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 8.				sumin95			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @return
	 */
	void insertMberMarktRecptnMediaHst(@Param("mberNo") String mberNo);
	
	/**
	 * <pre>
	 * 처리내용: 회원사 회원 탈퇴
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 */
	int deleteEntrpsMber(MyInfoMngVO myInfoMngVO);

	/**
	 * <pre>
	 * 처리내용: 탈퇴 요청 회원사 회원 조회
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	MyInfoMngVO selectSecsnEntrpsMber(String entrpsNo);

	/**
	 * <pre>
	 * 처리내용: 탈퇴 회원 정보 입력
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param myInfoMngVO
	 * @return
	 */
	int insertMbSecsnMberBas(MyInfoMngVO myInfoMngVO);

	/**
	 * <pre>
	 * 처리내용: 회원 탈퇴
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param myInfoMngVO
	 */
	int deleteMber(MyInfoMngVO myInfoMngVO);

	/**
	 * <pre>
	 * 처리내용: 회원 정보 조회 (탈퇴 테이블 insert하기 위해)
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @return
	 */
	MyInfoMngVO selectSecsnMber(String mberNo);
	
	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param myInfoMngVO
	 */
	int updateMyInfoDtlMob(MyInfoMngVO myInfoMngVO);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 22.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 22.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param myInfoMngVO
	 * @return
	 */
	MyInfoMngVO selectAgreAt(MyInfoMngVO myInfoMngVO);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 3.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @return
	 */
	String selectMembWithdrawCheck(String mberNo);

	String selectSecsnPossCodeNm(String secsnAt) throws Exception;


}
