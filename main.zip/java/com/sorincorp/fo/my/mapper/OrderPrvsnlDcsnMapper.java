package com.sorincorp.fo.my.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.fo.my.model.OrderPrvsnlDcsnInfoVO;
import com.sorincorp.fo.my.model.OrderPrvsnlDcsnProcessVO;

/**
 * OrderPrvsnlDcsnMapper.java
 * 단가확정하기 관련 Mapper 인터페이스
 * 
 * @version
 * @since 2024. 9. 9.
 * @author srec0049
 */
public interface OrderPrvsnlDcsnMapper {

	/**
	 * <pre>
	 * 처리내용: 단가확정하기 정보 가져오기
	 * </pre>
	 * @date 2024. 9. 10.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderPrvsnlDcsnInfoVO
	 * @return
	 * @throws Exception
	 */
	public OrderPrvsnlDcsnInfoVO getOrderPrvsnlDcsnInfo(String orderNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: LME 지정가 등록 시 [지정가 미체결, 지정가 주문처리중, 지정가 체결] 중복 체크
	 * </pre>
	 * @date 2024. 11. 26.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 26.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	public int getChkDuplLmeLimitOrder(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 환율 지정가 등록 시 [지정가 미체결, 지정가 주문처리중, 지정가 체결] 중복 체크
	 * </pre>
	 * @date 2024. 11. 26.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 26.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	public int getChkDuplEhgtLimitOrder(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: KRW 지정가 등록 시 [지정가 미체결, 지정가 주문처리중, 지정가 체결] 중복 체크
	 * </pre>
	 * @date 2024. 11. 26.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 26.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	public int getChkDuplKrwLimitOrder(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: BL별 주문_주문 상세 정보로 선물과 선물환 등록에 필요한 최적의 BL 데이터 가져오기 
	 * </pre>
	 * @date 2024. 10. 7.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 7.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	public List<ItemPriceMatchingBlInfoVO> getMatchedOrderedInfo(String orderNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 해당 가단가 확정 - 구분[lme: LME 분리확정, fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]에 따른 주문_주문 기본 데이터 변경
	 * </pre>
	 * @date 2024. 10. 8.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 8.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	public void updateOrOrderBasByDcsnSection(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 LME 기본 테이블 등록
	 * </pre>
	 * @date 2024. 10. 8.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 8.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	public void insertOrLimitLmeOrderBas(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 환율 기본 테이블 등록
	 * </pre>
	 * @date 2024. 10. 8.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 8.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	public void insertOrLimitEhgtOrderBas(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 KRW 기본 테이블 등록
	 * </pre>
	 * @date 2024. 10. 8.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 8.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	public void insertOrLimitKrwOrderBas(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 LME 기본 테이블 변경
	 * </pre>
	 * @date 2024. 10. 10.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderPrvsnlDcsnProcessVO
	 * @throws Exception
	 */
	public void updateOrLimitLmeOrderBas(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 환율 기본 테이블 변경
	 * </pre>
	 * @date 2024. 10. 10.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderPrvsnlDcsnProcessVO
	 * @throws Exception
	 */
	public void updateOrLimitEhgtOrderBas(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 KRW 기본 테이블 변경
	 * </pre>
	 * @date 2024. 10. 10.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderPrvsnlDcsnProcessVO
	 * @throws Exception
	 */
	public void updateOrLimitKrwOrderBas(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 LME 기본 테이블 취소
	 * </pre>
	 * @date 2024. 10. 10.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderPrvsnlDcsnProcessVO
	 * @throws Exception
	 */
	public void cancelOrLimitLmeOrderBas(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 환율 기본 테이블 취소
	 * </pre>
	 * @date 2024. 10. 10.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderPrvsnlDcsnProcessVO
	 * @throws Exception
	 */
	public void cancelOrLimitEhgtOrderBas(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 KRW 기본 테이블 취소
	 * </pre>
	 * @date 2024. 10. 10.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderPrvsnlDcsnProcessVO
	 * @throws Exception
	 */
	public void cancelOrLimitKrwOrderBas(OrderPrvsnlDcsnProcessVO orderPrvsnlDcsnProcessVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 가단가 구매 확정 SMS 내용 정보 가져오기
	 * </pre>
	 * @date 2024. 10. 17.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 10. 17.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectPrvsnlDcsnSmsInfo(OrderModel orderModel) throws Exception;
	
}
