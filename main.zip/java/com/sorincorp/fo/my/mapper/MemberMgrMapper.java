package com.sorincorp.fo.my.mapper;

import java.util.List;

import com.sorincorp.fo.my.model.MemberMgrVO;

public interface MemberMgrMapper {

	/**
	 * <pre>
	 * 처리내용: 업체소속 회원 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param memberMgrVO
	 * @return
	 * @throws Exception
	 */
	List<MemberMgrVO> selectMyCorpMemberList(MemberMgrVO memberMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체소속 회원 상세정보를 조회한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param memberMgrVO
	 * @return
	 * @throws Exception
	 */
	MemberMgrVO selectMemberDetailInfo(MemberMgrVO memberMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 공통코드 회원 권한구분코드 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<MemberMgrVO> getMberSeCodeList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기존회원아이디 중복여부를 조회한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param memberMgrVO
	 * @return
	 * @throws Exception
	 */
	String selectMberIdDupYn(MemberMgrVO memberMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 신규회원정보를 insert한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param memberMgrVO
	 * @return
	 * @throws Exception
	 */
	int insertMberInfo(MemberMgrVO memberMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원정보이력을 insert한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param memberMgrVO
	 * @return
	 * @throws Exception
	 */
	int insertmberInfoHst(MemberMgrVO memberMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기존회원정보를 수정한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param memberMgrVO
	 * @return
	 * @throws Exception
	 */
	int updateMberInfo(MemberMgrVO memberMgrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체 마스터권한을 변경한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param memberMgrVO
	 * @return
	 * @throws Exception
	 */
	int updateMasterMember(MemberMgrVO memberMgrVO) throws Exception;

}
