package com.sorincorp.fo.my.mapper;

import java.util.List;

import com.sorincorp.fo.my.model.CntrctOrderBasVO;
import com.sorincorp.fo.my.model.CntrctOrderDtlVO;
import com.sorincorp.fo.my.model.CntrctOrderMtDtlVO;

public interface CntrctOrderMapper {

	/**
	 * <pre>
	 * 계약 발주 기본 조회
	 * </pre>
	 * @date 2023. 10. 11.
	 * @author srec0051
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	CntrctOrderBasVO selectCntrctOrderInfo(CntrctOrderBasVO paramVo) throws Exception;

	/**
	 * <pre>
	 * 계약 발주 상세 조회
	 * </pre>
	 * @date 2023. 10. 11.
	 * @author srec0051
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	List<CntrctOrderDtlVO> selectListCntrctOrderDtl(CntrctOrderDtlVO paramVo) throws Exception;
}
