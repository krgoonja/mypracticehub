package com.sorincorp.fo.my.mapper;

import java.util.List;

import com.sorincorp.fo.my.model.MileageMngVO;

public interface MileageMngMapper {

	List<MileageMngVO> selectMbMileageMngList(MileageMngVO mileageMngVO) throws Exception;

	Integer selectMbMileageMngListCnt(MileageMngVO mileageMngVO) throws Exception;

	MileageMngVO selectMbMileageMngSeList(MileageMngVO mileageMngVO) throws Exception;

}
