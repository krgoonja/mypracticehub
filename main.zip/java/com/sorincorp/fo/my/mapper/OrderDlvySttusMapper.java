package com.sorincorp.fo.my.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.fo.my.model.OrderDlvySttusVO;
import com.sorincorp.fo.my.model.OrderDtlsVO;

public interface OrderDlvySttusMapper {

	/**
	 * <pre>
	 * 처리내용: 주문내역 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0048			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<OrderDlvySttusVO> selectOrderDlvySttusList(OrderDlvySttusVO orderDlvySttusVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문내역 총 건수를 조회한다.
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0048			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	int selectOrderDlvySttusTotCnt(OrderDlvySttusVO orderDlvySttusVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문내역 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0048			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<OrderDlvySttusVO> selectOrderDlvySttusVhcleDtl(OrderDlvySttusVO orderDlvySttusVO) throws Exception;

}
