package com.sorincorp.fo.ev.controller;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.cs.model.PchrgArticlVO;
import com.sorincorp.fo.ev.model.LoanCnsltReqstInfoVO;
import com.sorincorp.fo.ev.model.MobileEntryEventVO;
import com.sorincorp.fo.ev.service.evService;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;

import lombok.extern.slf4j.Slf4j;

/**
 * evController.java
 * @version
 * @since 2022. 9. 15.
 * @author jdrttl
 */
@Slf4j
@Controller
@RequestMapping("/fo/ev")
public class evController {

	@Autowired
	private evService evService;

	@Autowired
	private UserInfoUtil userInfoUtil;
	
	/**
	 * <pre>
	 * 처리내용: 대출 상담 사전 예약 페이지
	 * </pre>
	 * @date 2022. 9. 15.
	 * @author jdrttl
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 15.			jdrttl				최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/loanCnsltReqstInfo")
	public String loanCnsltReqstInfo(@RequestBody(required = false) PchrgArticlVO vo, ModelMap model) {
		try {
			Map<String,Object> loginStatusMap = new HashMap<String,Object>();
			Account account = userInfoUtil.getAccountInfo();
			if ( account != null) {
				loginStatusMap.put("mberNo", account.getMberNo());
				loginStatusMap.put("name", account.getName());
				loginStatusMap.put("phonenum", account.getPhonenum());
				loginStatusMap.put("mberSeCode", account.getSecode());
				loginStatusMap.put("mberType", account.getType());
				
				EntrpsEtrVO entrpsEtrVO = evService.selectEntrpsEtr(userInfoUtil.getEntripsNo());
				if (entrpsEtrVO != null) {
					loginStatusMap.put("entrpsnmKorean", entrpsEtrVO.getEntrpsnmKorean());
					loginStatusMap.put("bsnmRegistNo", entrpsEtrVO.getBsnmRegistNo());
				}
			}
			
			model.addAttribute("loginStatusMap", loginStatusMap); // 로그인 여부
			if( vo != null ) {
				model.addAttribute("pageOption", vo.getOption()); // 화면 접근 후 이동
			}
			
			return "ev/loanCnsltReqstInfo";
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 대출 상담 사전 예약 페이지 저장 
	 * </pre>
	 * @date 2022. 9. 15.
	 * @author jdrttl
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 15.					jdrttl				최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/saveLoanCnsltReqstInfo")
	@ResponseBody
	public ResponseEntity<Object> saveLoanCnsltReqstInfo(@RequestBody LoanCnsltReqstInfoVO loanCnsltReqstInfoVO, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();
		
		String result = evService.saveLoanCnsltReqstInfo(loanCnsltReqstInfoVO);

		if (result.equals("200")) {
			retVal.put("RESULT", "SUCCESS");
			retVal.put("RESULT_CODE", result);
			retVal.put("ERRMSG", "");
		} else {
			retVal.put("RESULT", "FAIL");
			retVal.put("RESULT_CODE", result);
			retVal.put("ERRMSG", "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
	

	
	/**
	 * <pre>
	 * 처리내용: 여신서비스 신청 페이지
	 * </pre>
	 * @date 2022. 11. 30.
	 * @author sumin95
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 30.				sumin95				최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/loanCreditUseReqstInfo")
	public String loanCreditUseReqstInfo(@RequestBody(required = false) Map<String, Object> paramMap, ModelMap model) {
		try {
			if( paramMap != null )
				model.addAttribute("loanCredit", paramMap.get("loanCredit"));
			
			return "ev/loanCreditUseReqstInfo";
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return "error/503";
		}
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 여신서비스 신청 
	 * </pre>
	 * @date 2022. 11. 30.
	 * @author sumin95
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 30.				sumin95				최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/loanCreditUse")
	@ResponseBody
	public ResponseEntity<Object>loanCnsltSvcReqst(@RequestBody LoanCnsltReqstInfoVO loanCnsltReqstInfoVO, ModelMap model) throws Exception {

		Map<String,Object> retVal = new HashMap<>();
		Account account = userInfoUtil.getAccountInfo();
		String result = "200";
		
		if(account == null) {
		    result = "996";
		    retVal.put("RESULT", "FAIL");
		    retVal.put("RESULT_CODE", result);
		} else if(account != null && account.getSecode().equals("01")) {
		    result = "200";
		    retVal.put("RESULT", "SUCCESS");
		    retVal.put("RESULT_CODE", result);
		} else {
		   result = "998";
		   retVal.put("RESULT", "FAIL");
		   retVal.put("RESULT_CODE", result);
		   retVal.put("ERRMSG", "해당 서비스는 마스터 회원만 신청 가능합니다");
		}
		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 모바일 체험 이벤트 페이지 뷰
	 * </pre>
	 * @date 2024. 09. 05.
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 09. 05.			sumin				최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/mobileEntryEvent")
	public String mobileEntryEventInfo(ModelMap model) {
		try {
			return "ev/mobileEntryEventInfo";
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 모바일 이벤트 기업정보 저장
	 * </pre>
	 * @date 2024. 09. 05.
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 09. 05.			sumin				최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/saveMobileEntrInfo")
	@ResponseBody
	public ResponseEntity<Object> saveMobileEntrInfo(@RequestBody MobileEntryEventVO mobileEntryEventVO, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();
		
		String result = evService.saveMobileEntrInfo(mobileEntryEventVO);

		if (result.equals("200")) {
			retVal.put("RESULT", "SUCCESS");
			retVal.put("RESULT_CODE", result);
			retVal.put("ERRMSG", "");
		} else {
			retVal.put("RESULT", "FAIL");
			retVal.put("RESULT_CODE", result);
			retVal.put("ERRMSG", "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 모바일 이벤트 접속링크 알림톡 발송
	 * </pre>
	 * @date 2024. 09. 24.
	 * @author hanjook
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 09. 24.			hanjook				최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/sendMobileEntrInfo")
	@ResponseBody
	public ResponseEntity<Object> sendMobileEntrInfo(@RequestBody MobileEntryEventVO mobileEntryEventVO, BindingResult bindingResult) throws Exception {

		Map<String, Object> retVal = new HashMap<>();
		
		String result = evService.sendMobileEntrInfo(mobileEntryEventVO);

		if (result.equals("200")) {
			retVal.put("RESULT", "SUCCESS");
			retVal.put("RESULT_CODE", result);
			retVal.put("ERRMSG", "");
		} else {
			retVal.put("RESULT", "FAIL");
			retVal.put("RESULT_CODE", result);
			retVal.put("ERRMSG", "");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}
	
	
}
