
package com.sorincorp.fo.ev.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.ev.model.PromtnInfoVO;
import com.sorincorp.fo.ev.model.PromtnNewYearVO;
import com.sorincorp.fo.ev.service.PromtnEventService;
import com.sorincorp.fo.login.model.Account;

import lombok.extern.slf4j.Slf4j;

/**
 * promtnEventController.java
 * @version
 * @since 2023. 4. 7.
 * @author sein
 */
@Slf4j
@Controller
@RequestMapping("/fo/promtnEvent")
public class PromtnEventController {

	@Autowired
	private PromtnEventService promtnEventService;

    @Autowired
    private UserInfoUtil userInfoUtil;
    
    private Account getAccountInfo() throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		if (null == account || StringUtil.isBlank(account.getMberNo())) {
			throw new Exception("로그인 정보를 확인해주세요.");
		}
		return account;
	}

	/**
	 * <pre>
	 * 처리내용: 프로모션 이벤트 View
	 * </pre>
	 * @date 2023. 4. 7.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 7.			sein					최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/promtnEventList")
	public String promtnEventList(@RequestBody(required = false) PromtnInfoVO vo, ModelMap model) {
		try {

			model.addAttribute("totalRowCount", promtnEventService.selectPromtnInfoListTotCnt(vo));
			model.addAttribute("pageIndex", 1);
			model.addAttribute("pageSize", 10);
			model.addAttribute("rowCountPerPage",9);

			return "ev/promtnEventList";
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 프로모션 이벤트 목록을 조회한다.
	 * </pre>
	 * @date 2023. 4. 7.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 7.			sein					최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectPromtnInfoList")
	@ResponseBody
	public Map<String, Object> selectPromtnInfoList(@RequestBody PromtnInfoVO vo) throws Exception {
		Map<String, Object> map = new HashedMap<>();
		try {
			List<PromtnInfoVO> promtnEventList = promtnEventService.selectPromtnInfoList(vo);
			int totDataCnt = promtnEventService.selectPromtnInfoListTotCnt(vo);

			map.put("dataList", promtnEventList);
			map.put("totalRowCount", totDataCnt);
			map.put("vo",vo);

		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			// 에러 설정 필요 return "error/503";
		}
		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 프로모션을 상세 조회한다.
	 * </pre>
	 * @date 2023. 4. 10.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 10.			sein					최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/promtnInfoDetail")
	public String promtnInfoDetail(@RequestBody PromtnInfoVO vo, ModelMap model) throws Exception {

		try {
			
			 PromtnInfoVO promtns = promtnEventService.selectPromtnInfo(vo);
			 promtns.setPageIndex(vo.getPageIndex());
			 promtns.setPageSize(vo.getPageSize());
			 promtns.setRecordCountPerPage(vo.getRecordCountPerPage());
			 promtns.setRowCountPerPage(vo.getRowCountPerPage());
			 
			 int recomendrIdPossAt = 0;
			 Account account = userInfoUtil.getAccountInfo();

			 if(account != null) {
			     vo.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());
			     recomendrIdPossAt = promtnEventService.selectRecomendrIdPossAt(vo);
			     model.addAttribute("account", account);
		      } else {
		          recomendrIdPossAt = 2;
		      }
			 
			model.addAttribute("promtns", promtns);
            model.addAttribute("recomendrIdPossAt", recomendrIdPossAt);

			return "ev/promtnEventDetail";
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return "error/503";
		}
	}
	
   @ResponseBody
   @PostMapping("/insertRecomendrId")
    public String insertRecomendrId(@RequestBody PromtnInfoVO vo) throws Exception {
        if (userInfoUtil.getAccountInfo() == null) {
            return "F";
        }
        String result = "";

        result = promtnEventService.insertRecomendrId(vo);

        return result;
    }
	
	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 이벤트 추첨권 조회
	 * 		 : 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 01. 26.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 26.		hyunjin05 			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/chkHasTicket")
	@ResponseBody
	public Map<String, Object> chkHasTicket(@RequestBody String entrpsNo) throws Exception {
		HashMap<String, Object> result = new HashMap<>();
		try {
			result.put("hasTicket", promtnEventService.chkHasTicket(entrpsNo));
			result.put("totTicket", promtnEventService.chkTotTicket());
		} catch (Exception e) {
			// TODO: handle exception
			log.error(ExceptionUtils.getStackTrace(e));
		}
		return result;
	}
	
	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 이벤트 추첨권 리스트 조회
	 * 		 : 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 01. 26.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 26.		hyunjin05 			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectAllNewYearPromtnList")
	@ResponseBody
	public Map<String, Object> selectAllNewYearPromtnList(@RequestBody String entrpsNo) throws Exception {
		Map<String, Object> map = new HashMap<>();
		List<PromtnNewYearVO> selectAllNewYearPromtnList = new ArrayList<PromtnNewYearVO>();
		try {
			selectAllNewYearPromtnList = promtnEventService.selectAllNewYearPromtnList(entrpsNo);
			map.put("selectAllNewYearPromtnList", selectAllNewYearPromtnList);
		} catch (Exception e) {
			// TODO: handle exception
			log.error(ExceptionUtils.getStackTrace(e));
		}
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 추첨권 존재 확인 및 가장 오랜된 추첨권 번호 가져오기
	 * 		 : 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 01. 26.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 26.		hyunjin05 			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/selectTicketIDX")
	public Map<String, Object> selectTicketIDX(@RequestBody PromtnNewYearVO promtnNewYearVO) throws Exception {
		Map<String, Object> map = new HashMap<>();

		try {
			map.put("idx", promtnEventService.selectTicketIDX(promtnNewYearVO));
		} catch (Exception e) {
			// TODO: handle exception
			log.error(ExceptionUtils.getStackTrace(e));
		}
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 이벤트 당첨 확인 및 추첨권 업데이트
	 * 		 : 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 01. 26.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 26.		hyunjin05 			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/updateEvNewYearPromtn")
	public Map<String, Object> updateEvNewYearPromtn(@RequestBody PromtnNewYearVO promtnNewYearVO) throws Exception {
		Map<String, Object> map = new HashMap<>();
		try {
			map.put("returnVo", promtnEventService.updateEvNewYearPromtn(promtnNewYearVO));
		} catch (Exception e) {
			// TODO: handle exception
			log.error(ExceptionUtils.getStackTrace(e));
		}
		return map;
	}

}
