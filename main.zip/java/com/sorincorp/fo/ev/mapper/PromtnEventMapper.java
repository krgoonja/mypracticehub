package com.sorincorp.fo.ev.mapper;

import java.util.List;

import com.sorincorp.fo.ev.model.PromtnInfoVO;
import com.sorincorp.fo.ev.model.PromtnNewYearVO;

/**
 * PromtnEventMapper.java
 * @version
 * @since 2023. 4. 7.
 * @author sein
 */
public interface PromtnEventMapper {
	/**
	 * <pre>
	 * 처리내용: 프로모션 목록 총 개수를 조회한다.
	 * </pre>
	 * @date 2023. 4. 7.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 03. 30.			sein					최초작성
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return int
	 * @throws Exception
	 */
	int selectPromtnInfoListTotCnt(PromtnInfoVO promtnInfoVO);

	/**
	 * <pre>
	 * 처리내용: 프로모션 목록 총 개수를 조회한다.
	 * </pre>
	 * @date 2023. 4. 7.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 03. 30.			sein					최초작성
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return List : PromtnInfoVO
	 * @throws Exception
	 */
	List<PromtnInfoVO> selectPromtnInfoList(PromtnInfoVO promtnInfoVO);

	/**
	 * <pre>
	 * 처리내용: 프로모션을 조회한다.
	 * </pre>
	 * @date 2023. 4. 10.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 10.			sein					최초작성
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return promtnInfoVO
	 * @throws Exception
	 */
	public PromtnInfoVO selectPromtnInfo(PromtnInfoVO promtnInfoVO);
	
	int selectRecomendrIdPossAt(PromtnInfoVO promtnInfoVO);
	
	int insertRecomendrId(PromtnInfoVO promtnInfoVO);
	
	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 이벤트 추첨권 조회
	 * 		 : 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 01. 26.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 26.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	public int chkHasTicket(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 이벤트 추첨권 조회
	 * 		 : 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 01. 26.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 26.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	public int chkTotTicket() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 이벤트 추첨 이력 조회
	 * 		: 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 01. 26.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 26.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	List<PromtnNewYearVO> selectAllNewYearPromtnList(String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 이벤트 추첨 이력 조회
	 * 		: 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 01. 26.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 26.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param PromtnNewYearVO
	 * @return
	 * @throws Exception
	 */
	int selectAllTicketCnt(PromtnNewYearVO promtnNewYearVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 발행할 추첨권 번호 확인
	 * 		: 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 *
	 * @param PromtnNewYearVO
	 * @return
	 * @throws Exception
	 * @date 2024. 01. 26.
	 * @author hyunjin05
	 * @history ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 26.		hyunjin05			최초작성
	 * ------------------------------------------------
	 */
	int selectTicketIDX(PromtnNewYearVO promtnNewYearVO);
	
	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 발행
	 * 		: 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 01. 26.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 26.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param PromtnNewYearVO
	 * @return
	 * @throws Exception
	 */
	int updateEvNewYearPromtn(PromtnNewYearVO promtnNewYearVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 이벤트 최고 보상 획득 여부 조회
	 * 		: 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 02. 01.
	 * @author cuko
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 02. 1.				cuko				최초작성
	 * ------------------------------------------------
	 * @param PromtnNewYearVO
	 * @return
	 * @throws Exception
	 */
	boolean chkBestPrz(PromtnNewYearVO promtnNewYearVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 이벤트 사용 번호 여부 조회
	 * 		: 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 02. 01.
	 * @author cuko
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 02. 01.			cuko				최초작성
	 * ------------------------------------------------
	 * @param PromtnNewYearVO
	 * @return
	 * @throws Exception
	 */
	boolean isUsedNumber(PromtnNewYearVO promtnNewYearVO) throws Exception;
}
