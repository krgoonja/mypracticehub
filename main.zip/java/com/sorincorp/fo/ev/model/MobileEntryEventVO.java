package com.sorincorp.fo.ev.model;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.annotation.MaskingClass;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@Validated
@MaskingClass
public class MobileEntryEventVO implements Serializable {
	
	private static final long serialVersionUID = 1658046897534492103L;
    /**
     *	기업명
     */
    private String entrpsNm;
    
    /**
     *	이름
     */
    private String nm;
    
    /**
     *	휴대폰 번호
     */
    private String mbtlnum;
    
    /** 
     * 최초 등록자 아이디 
     */
    private String frstRegisterId;
    
    /** 
     * 최초 등록 일시 
     */
    private String frstRegistDt;

    /** 
     * 최종 변경자 아이디
     */
    private String lastChangerId;

    /** 
     * 최종 변경 일시 
     */
    private String lastChangeDt;
}
