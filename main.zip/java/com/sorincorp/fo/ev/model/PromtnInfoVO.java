package com.sorincorp.fo.ev.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class PromtnInfoVO extends CommonVO {

	private static final long serialVersionUID = 8844595686043453196L;

	/** 순번 */
	private int rownum;

	/** 프로모션 번호 */
    private int promtnNo;

	/** 프로모션 명 */
    @NotBlank( message = "프로모션 명을 입력해 주세요.")
    @Size( min=0, max=100, message = "프로모션 명은 100자 이하로 입력해 주세요.")
    private String promtnNm;

    /** 프로모션 구분 코드 */
    @NotBlank( message = "프로모션 구분 코드는 필수 입니다.")
    private String promtnSeCode;

    /** 프로모션 사용 여부 */
    private String promtnUseAt;

    /** 프로모션 시작 날짜 */
    @NotBlank( message = "프로모션 시작일을 입력해 주세요.")
    private String promtnBeginDe;

    /** 프로모션 종료 날짜 */
    @NotBlank( message = "프로모션 종료일을 입력해 주세요.")
    private String promtnEndDe;

    /** 최초 등록자 아이디 */
    private String frstRegisterId;

    /** 최초 등록 일시 */
    private String frstRegistDt;

    /** 최종 변경자 아이디 */
    private String lastChangerId;

    /** 최종 변경 일시 */
    private String lastChangeDt;

    /** URL */
    private String url;

    /** 시작썸네일 문서 번호 */
    @NotNull( message = "시작썸네일을 등록해 주세요.")
    private Integer beginThumbDocNo;

    /** 시작썸네일 문서 이름 */
    @NotBlank( message = "시작썸네일을 등록해 주세요.")
    private String beginThumbDocPath;

    /** 종료썸네일 문서 번호 */
    @NotNull(message = "종료썸네일을 등록해 주세요.")
    private Integer endThumbDocNo;

    /** 종료썸네일 문서 이름 */
    @NotBlank(message = "종료썸네일을 등록해 주세요.")
    private String endThumbDocPath;

    /** 프로모션 내용 */
    @NotBlank(message = "프로모션 내용을 입력해 주세요.")
    private String promtnCn;

    /** 상시 노출 여부 */
    @NotBlank( message = "상시 노출 여부는 필수 입니다.")
    private String ordtmExpsrAt;
    /** 상시 노출 여부 */
    @NotBlank( message = "FO 노출 여부는 필수 입니다.")
    private String foExpsrAt;

    /** 삭제 여부 */
    private String deleteAt;

    /** 삭제 일시 */
    private String deleteDt;

    /**
     *	이전 이벤트(프로모션) 번호
     */
    private long prePromtnSn;
    /**
     *	다음 이벤트(프로모션) 번호
     */
    private long nextPromtnSn;
    
    private String entrpsNo;
    private String mberNo;
    private String recomendrId;
    
    private int recomendrIdCnt;

}
