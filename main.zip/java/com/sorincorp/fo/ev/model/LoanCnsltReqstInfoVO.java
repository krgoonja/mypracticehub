package com.sorincorp.fo.ev.model;

import java.io.Serializable;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.annotation.MaskingClass;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@Validated
@MaskingClass
public class LoanCnsltReqstInfoVO implements Serializable {
	
	private static final long serialVersionUID = 1658046897534492103L;
	/**
	 * 사업자 등록 번호
	 */
	private String bsnmRegistNo;
	/**
	 * 업체명
	 */
	private String entrpsnmKorean;
	/**
	 * 대출 요청자
	 */
	private String loanRequstNm;
	/**
	 * 대출 요청자 전화번호
	 */
	private String loanRequstTlphonNo;
	/**
	 * 회원번호
	 */
	private String mberNo;
}
