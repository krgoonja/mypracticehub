package com.sorincorp.fo.ev.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.fo.ev.model.PromtnInfoVO;
import com.sorincorp.fo.ev.model.PromtnNewYearVO;

/**
 * promtnEventService.java
 * @version
 * @since 2023. 4. 7.
 * @author sein
 */
public interface PromtnEventService {



	/**
	 * <pre>
	 * 처리내용: 프로모션 목록 총 개수를 조회한다.
	 * </pre>
	 * @date 2023. 4. 7.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 7.			sein					최초작성
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return int
	 * @throws Exception
	 */
	public int selectPromtnInfoListTotCnt(PromtnInfoVO promtnInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 프로모션 목록을 조회한다.
	 * </pre>
	 * @date 2023. 4. 7.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 7.			sein					최초작성
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return List
	 * @throws Exception
	 */
	public List<PromtnInfoVO> selectPromtnInfoList(PromtnInfoVO promtnInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 프로모션을 조회한다.
	 * </pre>
	 * @date 2023. 4. 10.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 10.			sein					최초작성
	 * ------------------------------------------------
	 * @param promtnInfoVO
	 * @return promtnInfoVO
	 * @throws Exception
	 */
	public PromtnInfoVO selectPromtnInfo(PromtnInfoVO promtnInfoVO) throws Exception;

	public int selectRecomendrIdPossAt(PromtnInfoVO promtnInfoVO) throws Exception;
	
	public String insertRecomendrId(PromtnInfoVO promtnInfoVO);
	
	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 이벤트 기업별 추첨권 조회
	 * 		 : 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 01. 26.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 26.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	public int chkHasTicket(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 이벤트 전체 추첨권 조회
	 * 		 : 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 1. 30.
	 * @author cuko
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2024. 01. 30.		cuko			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	public int chkTotTicket() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 이벤트 추첨 이력 조회
	 * 		 : 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 01. 26.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 26.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	public List<PromtnNewYearVO> selectAllNewYearPromtnList(String entrpsNo) throws Exception;
	
	/**
     * <pre>
     * 처리내용: 2024 설날 복주머니 이벤트 당첨 확인 및 추첨권 업데이트
     * 		 : 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
     * </pre>
     *
     * @param vo
     * @param model
     * @return
     * @throws Exception
     * @date 2024. 01. 26.
     * @author hyunjin05
     * @history ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2024. 01. 26.		hyunjin05 			최초작성
     * ------------------------------------------------
     */
	public int selectTicketIDX(PromtnNewYearVO promtnNewYearVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 이벤트 당첨 확인 및 추첨권 업데이트
	 * 		 : 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 01. 26.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 26.		hyunjin05 			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	public PromtnNewYearVO updateEvNewYearPromtn(PromtnNewYearVO promtnNewYearVO) throws Exception;
}
