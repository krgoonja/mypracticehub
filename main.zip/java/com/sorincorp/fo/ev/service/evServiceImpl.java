package com.sorincorp.fo.ev.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.ev.mapper.evMapper;
import com.sorincorp.fo.ev.model.LoanCnsltReqstInfoVO;
import com.sorincorp.fo.ev.model.MobileEntryEventVO;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.service.MbCmnCodeService;

import lombok.extern.slf4j.Slf4j;

/**
 * evServiceImpl.java
 * @version
 * @since 2022. 9. 15.
 * @author jdrttl
 */
@Slf4j
@Service
public class evServiceImpl implements evService {
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Autowired
	private evMapper evMapper;

	@Autowired
	SMSService smsService;
	
	@Autowired
	MbCmnCodeService mbCmnCodeService;
	
	/**
	 * 대출 상담 요청 사업자 등록 번호 확인
	 * @throws Exception
	 */
	@Override
	public int selectBsnmRegistNo(LoanCnsltReqstInfoVO loanCnsltReqstInfoVO) throws Exception {
		
		int cntbsnmRegistNo = evMapper.selectBsnmRegistNo(loanCnsltReqstInfoVO);
		
		return cntbsnmRegistNo;
	}
	
	@Override
	public String saveLoanCnsltReqstInfo(LoanCnsltReqstInfoVO loanCnsltReqstInfoVO) throws Exception {
		// TODO Auto-generated method stub
		String result = "200";

		int cntbsnmRegistNo = evMapper.selectBsnmRegistNo(loanCnsltReqstInfoVO);
		
		if( cntbsnmRegistNo > 0 ) {
			result = "998";
			return result;
		}
		
		String moblphonNo = loanCnsltReqstInfoVO.getLoanRequstTlphonNo();
		String encryptMoblphonNo = moblphonNo;

		if(moblphonNo != null && !"".equals(moblphonNo)) {
			moblphonNo = moblphonNo.replaceAll("[^0-9]", "");
			try {
				log.debug("암호화 전 ===============>" + moblphonNo);
				encryptMoblphonNo = CryptoUtil.encryptAES256(moblphonNo);
				log.debug("암호화 후 ===============>" + encryptMoblphonNo);
				loanCnsltReqstInfoVO.setLoanRequstTlphonNo(encryptMoblphonNo);
			} catch (Exception e) {
				// TODO: handle exception
				log.error("insertMberInfo MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		int cnt = evMapper.saveLoanCnsltReqstInfo(loanCnsltReqstInfoVO);
		
		if( cnt > 0 ) {
			System.out.println("문자전송");
			Map<String, String> msgMap = new HashMap<>();
		    SMSVO smsVO = new SMSVO();
		    msgMap.put("templateNum", "75");                                                 // 메시지 템플릿 번호
		    msgMap.put("Servicedomain", "https://www.kztraders.com/");
		    smsVO.setPhone(moblphonNo);   // 받는사람 번호
		    smsVO.setMsgTitle("상담 신청완료");
		    msgMap.put("excpSndngOptnAt", "N"); // 예외 발송 옵션 여부, N일 경우 SMS 수신자만 발송한다.
		    smsService.insertSMS(smsVO, msgMap);  // 메소드 호출
		    
			// 주문 시 SMS 전송 수신자 추가 리스트 가져오기[SMS_SNDNG_GROUP_CODE:21,22,27 or 40 or 41]
		    msgMap.put("commerceNtcnAt", "Y"); // 추가 수신사 커머스 알림 여부 따로 설정
		    msgMap.put("msg", "케이지트레이딩에서 고객 접수건 알려드립니다. \n"
		    							 + loanCnsltReqstInfoVO.getEntrpsnmKorean()+"("+ loanCnsltReqstInfoVO.getLoanRequstNm() +","+moblphonNo+")에서 여신관련 신규 결제수단 상담 신청을 접수하였습니다."); // 알림 메세지
		    msgMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
			smsService.insertSMS(null, msgMap);
		}else {
			result = "999";
		}
		
		return result;
	}
	
	@Override
	public EntrpsEtrVO selectEntrpsEtr(String entrpsNo) throws Exception {
		
		EntrpsEtrVO entrpsEtrVO = evMapper.selectEntrpsEtr(entrpsNo);
		
		return entrpsEtrVO;
	}
	
	
	@Override
	public String saveMobileEntrInfo(MobileEntryEventVO mobileEntryEventVO) throws Exception {
		String result = "200";
		
		String moblphonNo = mobileEntryEventVO.getMbtlnum();
		String encryptMoblphonNo = moblphonNo;
		String userId = userInfoUtil.getAccountInfo().getId() == null ? mobileEntryEventVO.getNm() :  userInfoUtil.getAccountInfo().getId();
		
		mobileEntryEventVO.setFrstRegisterId(userId);
		mobileEntryEventVO.setLastChangerId(userId);

		if(moblphonNo != null && !"".equals(moblphonNo)) {
			moblphonNo = moblphonNo.replaceAll("[^0-9]", "");
			try {
				log.debug("암호화 전 ===============>" + moblphonNo);
				encryptMoblphonNo = CryptoUtil.encryptAES256(moblphonNo);
				log.debug("암호화 후 ===============>" + encryptMoblphonNo);
				mobileEntryEventVO.setMbtlnum(encryptMoblphonNo);
			} catch (Exception e) {
				log.error("insertMberInfo MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
	
		//이벤트 중복 참여 확인(핸드폰 번호 조회)
		int cntbsnmRegistNo = evMapper.selectMobileNo(mobileEntryEventVO.getMbtlnum(), mobileEntryEventVO.getEntrpsNm());
		
		if( cntbsnmRegistNo > 0 ) {
			result = "998";
		} else {
			evMapper.saveMobileEntrInfo(mobileEntryEventVO);
		}
		return result;
	}
	
	@Override
	public String sendMobileEntrInfo(MobileEntryEventVO mobileEntryEventVO) throws Exception {
		String result = "200";		
		String moblphonNo = mobileEntryEventVO.getMbtlnum();		
		
		SMSVO smsVO = new SMSVO();	// 알림톡 발송 VO
		Map<String, String> map = new HashMap<>(); // 알림톡 발송 hashmap
		
		// 메시지 템플릿 번호
		String templateNum = "149";
		String title = mbCmnCodeService.selectMssageSj(templateNum);
		
		map.put("templateNum", templateNum);
		
		smsVO.setPhone(moblphonNo.replaceAll("[^0-9]", ""));
		smsVO.setMsgTitle(title);
		
		try {
			// 알림톡 발송
			smsService.insertSMS(smsVO, map);
		} catch (Exception e){
			log.error("sendMobileEntrInfo - smsService.insertSMS(smsVO, map) ERROR :" + e.getMessage());
		}
		
		return result;
	}
	
	
	
}
