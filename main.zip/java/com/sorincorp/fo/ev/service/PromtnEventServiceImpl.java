package com.sorincorp.fo.ev.service;


import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.ev.mapper.PromtnEventMapper;
import com.sorincorp.fo.ev.model.PromtnInfoVO;
import com.sorincorp.fo.ev.model.PromtnNewYearVO;
import com.sorincorp.fo.mb.mapper.EntrpsEtrMapper;
import com.sorincorp.fo.my.mapper.CouponDtlsMapper;
import com.sorincorp.fo.my.model.CouponDtlVO;

import lombok.extern.slf4j.Slf4j;

/**
 * PromtnEventServiceImpl.java
 * @version
 * @since 2023. 04. 7.
 * @author sein
 */
@Slf4j
@Service
public class PromtnEventServiceImpl implements PromtnEventService {

	@Autowired
	private PromtnEventMapper promtnEventMapper;

    @Autowired
    private UserInfoUtil userInfoUtil;

    @Autowired
    private CommonService commonService;

    @Autowired
    private EntrpsEtrMapper entrpsEtrMapper;

    @Autowired
    private AssignService assignService;

    @Autowired
    private CouponDtlsMapper couponDtlsMapper;
    

	/**
	 *	프로모션 목록 총 개수를 조회한다.
	 */
	@Override
	public int selectPromtnInfoListTotCnt(PromtnInfoVO promtnInfoVO) throws Exception {
		return promtnEventMapper.selectPromtnInfoListTotCnt(promtnInfoVO);
	}

	/**
	 *	프로모션 목록을 조회한다.
	 */
	@Override
	public List<PromtnInfoVO> selectPromtnInfoList(PromtnInfoVO promtnInfoVO)  throws Exception {
		return promtnEventMapper.selectPromtnInfoList(promtnInfoVO);
	}

	/**
	 *	프로모션을 상세 조회한다.
	 */
	@Override
	public PromtnInfoVO selectPromtnInfo(PromtnInfoVO promtnInfoVO) throws Exception {
		List<PromtnInfoVO> list = promtnEventMapper.selectPromtnInfoList(promtnInfoVO);

		long prePromtnSn = 0; //이전글 번호
		long nextPromtnSn = 0; //다음글 번호

		int size = list.size() - 1;

		// 리스트 사이즈가 3개 이상 일 경우
		if (size >= 2) {
			for (int i = 0; i <= size; i++) {
				if (list.get(i).getPromtnNo() == promtnInfoVO.getPromtnNo()) {
					if (i == 0) {
						prePromtnSn = list.get(size).getPromtnNo();
						nextPromtnSn = list.get(i + 1).getPromtnNo();
					} else if (i == size) {
						prePromtnSn = list.get(i - 1).getPromtnNo();
						nextPromtnSn = list.get(0).getPromtnNo();
					} else {
						prePromtnSn = list.get(i - 1).getPromtnNo();
						nextPromtnSn = list.get(i + 1).getPromtnNo();
					}
				}
			}
			// 리스트 사이즈가 2개 일 경우
		} else if (size == 1) {
			for (int i = 0; i <= size; i++) {
				if (list.get(i).getPromtnNo() == promtnInfoVO.getPromtnNo()) {
					if (i == 0) {
						prePromtnSn  = 0;
						nextPromtnSn = list.get(i + 1).getPromtnNo();
					}else{
						prePromtnSn  =  list.get(i - 1).getPromtnNo();
						nextPromtnSn = 0;
					}
				}
			}
		}


		PromtnInfoVO result = promtnEventMapper.selectPromtnInfo(promtnInfoVO);
		result.setPrePromtnSn(prePromtnSn);
		result.setNextPromtnSn(nextPromtnSn);

		return result;
	}
	
   @Override
    public int selectRecomendrIdPossAt(PromtnInfoVO promtnInfoVO) throws Exception {
        return promtnEventMapper.selectRecomendrIdPossAt(promtnInfoVO);
    }
   
   @Override
   public String insertRecomendrId(PromtnInfoVO promtnInfoVO) {
       if (userInfoUtil.getAccountInfo() == null) {
           return "F";
       }
       String data = "F";
       int result = 0;
       promtnInfoVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
       promtnInfoVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());

       try {
           result = promtnEventMapper.insertRecomendrId(promtnInfoVO);
           if (result > 0) {
               data = "S";
               // 친구추천 이벤트
               if(promtnInfoVO.getRecomendrId() != null && !"".equals(promtnInfoVO.getRecomendrId())) {
                   
                   // 추천인아이디 업체번호 조회
                   String recomendrEntrpsNo = entrpsEtrMapper.selectEntrpsNo(promtnInfoVO.getRecomendrId()); 
                   
                   for(int i=0; i < 2; i++) {
                       CouponDtlVO eventCouponVO = new CouponDtlVO();
                       eventCouponVO.setCouponSn("CP-"+DateUtil.getNowDateTime("yyyyMM")+"-"+ assignService.selectAssignValue("CP", "COUPON_SN", DateUtil.calDate("yyyy"), userInfoUtil.getAccountInfo().getId(), 5));
                       eventCouponVO.setCouponDtlNo("20230817-C00008");
                       eventCouponVO.setEntrpsNo(userInfoUtil.getAccountInfo().getEntrpsNo());
                       eventCouponVO.setCouponSttusCode("01");
                       eventCouponVO.setCouponDscntApplcAmount(125000);
                       eventCouponVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
                       eventCouponVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
                       couponDtlsMapper.insertCouponIsuNew(eventCouponVO);
                       
                       // history
                       List<String> primaryKeyList = new ArrayList<>();
                       primaryKeyList.add("COUPON_DTL_NO");
                       commonService.insertTableHistory("CP_COUPON_ISU_BAS", eventCouponVO, primaryKeyList);
                       
                       // 쿠폰 정보 기본 발급 수량,금액 수정
                       eventCouponVO.setIssuAmount(125000);
                       eventCouponVO.setIssuQy(1);
                       eventCouponVO.setCouponNo("20230817-P00006");
                       couponDtlsMapper.updateCouponPolicyInfo(eventCouponVO);
                   }
                   
                   for(int k=0; k < 2; k++) {
                       CouponDtlVO eventCouponVO = new CouponDtlVO();
                       eventCouponVO.setCouponSn("CP-"+DateUtil.getNowDateTime("yyyyMM")+"-"+ assignService.selectAssignValue("CP", "COUPON_SN", DateUtil.calDate("yyyy"), recomendrEntrpsNo, 5));
                       eventCouponVO.setCouponDtlNo("20230817-C00008");
                       eventCouponVO.setEntrpsNo(recomendrEntrpsNo);
                       eventCouponVO.setCouponSttusCode("01");
                       eventCouponVO.setCouponDscntApplcAmount(125000);
                       eventCouponVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
                       eventCouponVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
                       couponDtlsMapper.insertCouponIsuNew(eventCouponVO);
                       
                       // history
                       List<String> primaryKeyList = new ArrayList<>();
                       primaryKeyList.add("COUPON_DTL_NO");
                       commonService.insertTableHistory("CP_COUPON_ISU_BAS", eventCouponVO, primaryKeyList);
                       
                       // 쿠폰 정보 기본 발급 수량,금액 수정
                       eventCouponVO.setIssuAmount(125000);
                       eventCouponVO.setIssuQy(1);
                       eventCouponVO.setCouponNo("20230817-P00006");
                       couponDtlsMapper.updateCouponPolicyInfo(eventCouponVO);
                   }
               }
               commonService.insertTableHistory("MB_ENTRPS_INFO_BAS", promtnInfoVO);
           }
          
       } catch (Exception e) {
           data = "F";
       }
       return data;
   }

	/*
	 *  처리내용	: 2024 설날 복주머니 이벤트 추첨권 조회
	 			: 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 */
	@Override
	public int chkHasTicket(String entrpsNo) throws Exception{
		int result = 0;
		try {
			result = promtnEventMapper.chkHasTicket(entrpsNo);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return result;
	}

	/*
	 *  처리내용	: 2024 설날 복주머니 이벤트 추첨권 조회
	 			: 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 */
	@Override
	public int chkTotTicket() throws Exception{
		int result = 0;
		try {
			result = promtnEventMapper.chkTotTicket();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return result;
	}

	/*
	 *  처리내용	: 2024 설날 복주머니 이벤트 추첨 이력 조회
	 			: 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 */
	@Override
	public List<PromtnNewYearVO> selectAllNewYearPromtnList(String entrpsNo) throws Exception{
		List<PromtnNewYearVO> selectAllNewYearPromtnList = new ArrayList<PromtnNewYearVO>();
		try {
			selectAllNewYearPromtnList = promtnEventMapper.selectAllNewYearPromtnList(entrpsNo);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return selectAllNewYearPromtnList;
	}
	
	/*
	 *  처리내용	: 2024 설날 복주머니 추첨권 존재 확인 및 가장 오랜된 추첨권 번호 가져오기
	 			: 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 */
	@Override
	public int selectTicketIDX(PromtnNewYearVO promtnNewYearVO) throws Exception{
		return promtnEventMapper.selectTicketIDX(promtnNewYearVO);
	}
	/*
	 *  처리내용	:  2024 설날 복주머니 이벤트 당첨 확인 및 추첨권 업데이트
	 			: 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 */
	@Override
	public PromtnNewYearVO updateEvNewYearPromtn(PromtnNewYearVO promtnNewYearVO) throws Exception{
		
		PromtnNewYearVO returnVo = new PromtnNewYearVO();
		PromtnNewYearVO tempVo = new PromtnNewYearVO();
		String moblphonNo = promtnNewYearVO.getPrzwnerMoblphonNo();
		int allTicketCnt;	//모든 추첨권 발급 장수
		int returnResult = 0;

		try {
			promtnNewYearVO.setPrzwinAmount(0);
			// 추첨권 당첨 이력 확인
			allTicketCnt = promtnEventMapper.selectAllTicketCnt(promtnNewYearVO);
			if(allTicketCnt <= 200) {
				tempVo = makeRandom(promtnNewYearVO);
				promtnNewYearVO.setPrzwinAmount(tempVo.getPrzwinAmount());
				promtnNewYearVO.setPrzNum(tempVo.getPrzNum());
			}
			
			//휴대폰 암호화
			if (moblphonNo != null && !"".equals(moblphonNo)) {
				moblphonNo = moblphonNo.replaceAll("[^0-9]", "");
				try {
						moblphonNo = CryptoUtil.encryptAES256(moblphonNo);
						promtnNewYearVO.setPrzwnerMoblphonNo(moblphonNo);
				} catch (Exception e) {
					// TODO: handle exception
					log.error("updateEvNewYearPromtn moblphonNo CryptoUtil.encryptAES256 ERROR " + e.getMessage());
				}
			}
			
			returnResult = promtnEventMapper.updateEvNewYearPromtn(promtnNewYearVO);

			if(returnResult > 0) {
				returnVo = promtnNewYearVO;
				returnVo.setSuccesAt("Y");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return returnVo;
	}
	
	/**
	 * <pre>
	 * 처리내용: 2024 설날 복주머니 이벤트 랜덤 금액 생성
	 * 		 : 2024-02-01 ~ 2024-02-29 23:59:59 동안 진행, 이후 제거 필요
	 * </pre>
	 * @date 2024. 01. 26.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일                  작성자             변경내용
	 * ------------------------------------------------
	 * 2024. 01. 26.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return 
	 */
	private synchronized PromtnNewYearVO makeRandom(PromtnNewYearVO promtnNewYearVO) {
		PromtnNewYearVO returnVO = new PromtnNewYearVO(); 
		
		int chkTicket1 = 0;	// 	1만원		: 최대 100장
		int chkTicket2 = 0;	// 	3만원		: 최대 50장
		int chkTicket3 = 0;	// 	5만원		: 최대 30장
		int chkTicket4 = 0;	// 	10만원		: 최대 20장
		boolean chkBestPrz = false;
		int randomResult = 0;
		int result = 0;

		Random random = new Random();
		try {
			promtnNewYearVO.setPrzwinAmount(10000);
			chkTicket1 = promtnEventMapper.selectAllTicketCnt(promtnNewYearVO);
			promtnNewYearVO.setPrzwinAmount(30000);
			chkTicket2 = promtnEventMapper.selectAllTicketCnt(promtnNewYearVO);
			promtnNewYearVO.setPrzwinAmount(50000);
			chkTicket3 = promtnEventMapper.selectAllTicketCnt(promtnNewYearVO);
			promtnNewYearVO.setPrzwinAmount(100000);
			chkTicket4 = promtnEventMapper.selectAllTicketCnt(promtnNewYearVO);

			chkBestPrz = promtnEventMapper.chkBestPrz(promtnNewYearVO);

			while(true){
				randomResult = random.ints(1,201)
								.findFirst()
								.getAsInt();

				promtnNewYearVO.setPrzNum(randomResult);
				if(promtnEventMapper.isUsedNumber(promtnNewYearVO)){

					continue;
				}

				if(randomResult <= 20){
					if(!chkBestPrz){
						if(chkTicket4 < 20){
							result = 100000;
							break;
						}
					}
				} else if (randomResult > 20 && randomResult <= 50) {
					if(chkTicket3 < 30){
						result = 50000;
						break;
					}
				} else if (randomResult > 50 && randomResult <= 100) {
					if(chkTicket2 < 50){
						result = 30000;
						break;
					}
				} else if (randomResult > 100 && randomResult <= 200) {
					if(chkTicket1 < 100){
						result = 10000;
						break;
					}
				}
			}

			returnVO.setPrzwinAmount(result);
			returnVO.setPrzNum(randomResult);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return returnVO;
	}
	
}
