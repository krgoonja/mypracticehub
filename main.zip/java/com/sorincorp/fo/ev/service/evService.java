package com.sorincorp.fo.ev.service;

import com.sorincorp.fo.ev.model.LoanCnsltReqstInfoVO;
import com.sorincorp.fo.ev.model.MobileEntryEventVO;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;

/**
 * evService.java
 * @version
 * @since 2022. 9. 15.
 * @author jdrttl
 */
public interface evService {
	
	/**
	 * <pre>
	 * 처리내용: 대출 상담 사전 예약 저장
	 * </pre>
	 * @date 2022. 9. 15.
	 * @author jdrttl
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 15.			jdrttl				최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	String saveLoanCnsltReqstInfo(LoanCnsltReqstInfoVO loanCnsltReqstInfoVO) throws Exception;
	
	/**
	 * 사업자 등록 번호 중복 확인
	 * @param loanCnsltReqstInfoVO
	 * @return
	 * @throws Exception
	 */
	int selectBsnmRegistNo(LoanCnsltReqstInfoVO loanCnsltReqstInfoVO) throws Exception;
	
	/**
	 * 기업정보 조회 
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	EntrpsEtrVO selectEntrpsEtr(String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 모바일 이벤트 기업정보 저장
	 * </pre>
	 * @date 2024. 09. 05.
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 *  2024. 09. 05.			sumin				최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	String saveMobileEntrInfo(MobileEntryEventVO mobileEntryEventVO) throws Exception;

	String sendMobileEntrInfo(MobileEntryEventVO mobileEntryEventVO) throws Exception;
}
