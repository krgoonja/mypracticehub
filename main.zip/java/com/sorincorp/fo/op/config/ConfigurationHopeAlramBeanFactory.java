package com.sorincorp.fo.op.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sorincorp.fo.op.model.HopeAlarmVO;

@Configuration
public class ConfigurationHopeAlramBeanFactory {

	@Bean(name="hopeAlram")
	public HopeAlarmVO hopeAlram () {
		return new HopeAlarmVO();
	}
}
