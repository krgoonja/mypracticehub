package com.sorincorp.fo.op.mapper;

import java.util.List;

import com.sorincorp.fo.op.model.PromtnBannerVO;

/**
 * PromtnBannerMapper.java
 * @version
 * @since 2023. 4. 12.
 * @author srec0077
 */
public interface PromtnBannerMapper {

    /**
     * <pre>
     * 처리내용: 배너존 리스트를 가져온다.
     * </pre>
     * @date 2023. 4. 12.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 4. 12.         srec0077            최초작성
     * ------------------------------------------------
     * @return
     * @throws Exception
     */
	List<PromtnBannerVO> selectPromtnBannerList(int promtnBannerZoneNo) throws Exception;
	
	PromtnBannerVO selectBannerZoneDtl(int promtnBannerZoneNo) throws Exception;

	List<PromtnBannerVO> selectRelmBannerList(String bannerZoneCode) throws Exception;

}
