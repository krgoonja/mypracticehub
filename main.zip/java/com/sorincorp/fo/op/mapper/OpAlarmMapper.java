package com.sorincorp.fo.op.mapper;

import java.util.List;

import com.sorincorp.fo.op.model.HopePcNtcnSetupVO;
import com.sorincorp.fo.op.model.HopePcNtcnSndngVO;
import com.sorincorp.fo.op.model.InvntryNtcnSetupVO;
import com.sorincorp.fo.op.model.InvntryNtcnSndngVO;

public interface OpAlarmMapper {
	
	/**
	 * <pre>
	 * 처리내용: 등록된 희망가격 알림 개수 조회한다. 
	 * </pre>
	 * @date 2021. 9. 23.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 23.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	 int countPriceAlarm(String entrpsNo);
	 
	 
	/**
	 * <pre>
	 * 처리내용: 희망가격 알림을 등록한다.
	 * </pre>
	 * @date 2021. 9. 23.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 23.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	 int insertPriceAlarm(HopePcNtcnSetupVO vo);
	 
	 /**
	 * <pre>
	 * 처리내용: 희망가격 알림을 등록한다.
	 * </pre>
	 * @date 2021. 9. 23.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 23.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	 int updateHopePcUseAlarm(HopePcNtcnSetupVO vo);
	 
	 

	/**
	 * <pre>
	 * 처리내용: 희망가격 알림 설정정보를 가져온다
	 * </pre>
	 * @date 2021. 9. 7.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<HopePcNtcnSetupVO> selectHopePcNtcnSetupListByEntrpsNo(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 재고 알림 설정정보를 가져온다
	 * </pre>
	 * @date 2021. 9. 7.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<InvntryNtcnSetupVO> selectInvntryNtcnSetupListByEntrpsNo(String entrpsNo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 희망가 알림의 수신 상태를 설정한다.
	 * </pre>
	 * @date 2021. 9. 8.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 8.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void updateHopeAlarmReturn(HopePcNtcnSndngVO vo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 재고 알림의 수신 상태를 설정한다.
	 * </pre>
	 * @date 2021. 9. 8.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 8.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void updateInvenAlarmReturn(InvntryNtcnSndngVO vo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 재고 알림을 설정한다.
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int insertInvntryAlarmSetup(InvntryNtcnSetupVO vo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 해당 업체의 재고 알림을 갯수를 조회한다.
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	int countInvntryAlarmSetup(String entrpsNo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 희망가격 알림 발송 대상을 등록한다.
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	 int insertHopePcSending(HopePcNtcnSndngVO vo) throws Exception;
	 
	 /**
	 * 
	 * <pre>
	 * 처리내용: 재고 알림 발송 대상을 등록한다.
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	 int insertInvtSending(InvntryNtcnSndngVO vo) throws Exception;
	 
	 
	/**
	 * 
	 * <pre>
	 * 처리내용: 희망가 알림의 푸시의 발송 완료 상태로 설정한다.
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	void updateHopeAlarmPushSended(HopePcNtcnSndngVO vo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 재고 알림의 푸시의 발송 완료 상태로 설정한다.
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	void updateInvenAlarmPushSended(InvntryNtcnSndngVO vo) throws Exception;
	

	 /**
	 * <pre>
	 * 처리내용: 등록된 재고 알림 개수를 조회한다.
	 * </pre>
	 * @date 2021. 10. 20.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 20.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	int countInvntryAlarm(String entrpsNo);


	 /**
	 * <pre>
	 * 처리내용: 재고 알림을 생성한다.
	 * </pre>
	 * @date 2021. 10. 20.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 20.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int insertInvntryAlarm(InvntryNtcnSetupVO vo);

	 /**
	 * <pre>
	 * 처리내용: 이미 등록된 재고 알림이 있는지 조회한다.
	 * </pre>
	 * @date 2023. 01. 11.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 01. 11.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	int duplicateKeyCheckInvntryAlarm(InvntryNtcnSetupVO vo);
}
