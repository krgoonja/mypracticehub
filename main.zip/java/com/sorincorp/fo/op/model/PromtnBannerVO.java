package com.sorincorp.fo.op.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * PromtnBannerVO.java
 * @version
 * @since 2023. 4. 12.
 * @author srec0077
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class PromtnBannerVO extends CommonVO {

    private static final long serialVersionUID = -983980066867916262L;

    /**
     * 프로모션 배너 번호
    */
    private int promtnBannerNo;

    /**
     * 프로모션 배너 구역 번호
    */
    private int promtnBannerZoneNo;
    
    /**
     * 프로모션 번호
    */
    private int promtnNo;
    
    /**
     * 전시 시작일
    */
    private String dspyBeginDt;

    /**
     * 전시 종료일
    */
    private String dspyEndDt;
    
    private String dspyDt;
    
    /**
     * 상시 노출 여부
    */
    private String ordtmExpsrAt;
    
    /**
     * 사용 여부
    */
    private String useAt;
    
    /**
     * 프로모션 배너전시 구역 - 최대 전시 수
    */
    private int mxmmDspyCo;    

    /**
     * 삭제 여부
    */
    private String deleteAt;
    
    /**
     * 배너 이미지 문서 번호
     */
    private Integer bannerImageDocNo;

    /**
     * 기본 이미지 사용 여부
    */
    private String basImageUseAt;
    
    /**
     * 기본 이미지 문서 번호
     */
    private Integer basImageDocNo;

    /**
     * 프로모션 배너 구역 이름
    */
    private String promtnBannerZoneNm;
    
    /**
     * 전시 배너 수(게시 수)
    */
    private int dspyBannerCo;
    

    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;

    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;

    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;

    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;

	/**
	 * Grid 상태
	 */
	private String gridRowStatus;

	/**
	 * modalPageStatus 상태
	 */
	private String modalPageStatus;
	
	/**
	 * 프로모션 시작일
	 */
	private String promtnBeginDe;

	/**
	 * 프로모션 종료일
	 */
	private String promtnEndDe;
	
	/**
	 * 프로모션 명
	 */
	private String promtnNm;

	/**
	 * 프로모션 구분
	 */
	private String promtnSeCode;
	
    /**
     * 프로모션 사용 여부
     */
    private String promtnUseAt;
	
	/**
	 * 전시상태
	 */
	private String dspySe;
	
	/**
	 * 파일명
	 */
	private String docFileNm;

    /**
     * 업무구분코드
     */
    private String jobSeCode;
    
    /**
     * 문서 파일 실제 경로
     */
    private String docFileRealCours;
    
    /**
     * 프로모션 이미지 사용 여부
     */
    private String promtnImageUseAt;
    

    /**
     * ROWNUM
     */
    private String ROWNUM;
    
    /* 2024-10-22 변경 */
    /* 신규 테이블 전용 변수 */
    
    private int bannerZoneNo;
    
    private String bannerZoneCode;
    
    private String bannerZoneNm;
    
    private String bannerSe;
    
    private String rm;
    
    private int bannerNo;
    
    private int bannerOrderBy;
    
    private String dspyAt;
    
    private String bannerNm;
    
    private String beginDt;
    
    private String endDt;
    
    private String ordtmProgrsAt;
    
    private String linkAdres;   
    
    private String linkYn;
    
    private String upDown;
    
    private String bannerZoneCodeNm;
    
}
