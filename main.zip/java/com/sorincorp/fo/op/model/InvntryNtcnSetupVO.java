package com.sorincorp.fo.op.model;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
public class InvntryNtcnSetupVO implements Serializable{

		
		private static final long serialVersionUID = 3643346783287532280L;
	
		/**
		 *  updateInvntry
		 *  Validation groups를 지정하기 위한 빈 interface
		 */
		public interface updateInvntry{};
		
		/**
		 *  insertInvntry
		 *  Validation groups를 지정하기 위한 빈 interface
		 */
		public interface insertInvntry{};
		
		/******  JAVA VO CREATE : OP_INVNTRY_NTCN_SETUP_BAS(운영_재고_알림_설정_기본) ******/
	     /**
	     * 회원 번호
	    */
		@NotEmpty(groups = updateInvntry.class, message="로그인 후 이용해 주세요.")
	    private String mberNo; 
	     /**
	     * 금속 코드
	    */
		@NotEmpty(groups = updateInvntry.class, message="금속 코드를 선택해 주세요." )
		@NotEmpty(groups = insertInvntry.class, message="금속 코드를 선택해 주세요." )
	    private String metalCode; 
	     /**
	     * 아이템 순번
	    */
		@NotNull(groups = updateInvntry.class, message="금속 코드를 선택해 주세요." )
		@NotNull(groups = insertInvntry.class, message="금속 코드를 선택해 주세요." )
		private int itmSn; 
	     /**
	     * 권역 대분류 코드
	    */
		@NotEmpty(groups = updateInvntry.class, message="금속 코드를 선택해 주세요." )
		@NotEmpty(groups = insertInvntry.class, message="금속 코드를 선택해 주세요." )
	    private String dstrctLclsfCode; 
	     /**
	     * 브랜드 그룹 코드
	    */
		@NotEmpty(groups = updateInvntry.class, message="금속 코드를 선택해 주세요." )
		@NotEmpty(groups = insertInvntry.class, message="금속 코드를 선택해 주세요." )
	    private String brandGroupCode; 
	     /**
	     * 브랜드 코드
	    */
		@NotEmpty(groups = updateInvntry.class, message="금속 코드를 선택해 주세요." )
		@NotEmpty(groups = insertInvntry.class, message="금속 코드를 선택해 주세요." )
	    private String brandCode; 
	     /**
	     * 재고수량
	    */
		@NotNull(groups = updateInvntry.class, message="재고 수량을 선택해 주세요." )
		@NotNull(groups = insertInvntry.class, message="재고 수량을 선택해 주세요." )
	    private int invntryqy; 
	     /**
	     * 업체 번호
	    */
		@NotEmpty(groups = updateInvntry.class, message="금속 코드를 선택해 주세요." )
	    private String entrpsNo; 
	     /**
	     * 사용 여부
	    */
		@NotEmpty(groups = updateInvntry.class, message="사용 여부를 선택해 주세요." )
	    private String useAt; 
	     /**
	     * 삭제 일시
	    */
	    private java.sql.Timestamp deleteDt; 
	     /**
	     * 삭제 여부
	    */
	    private String deleteAt; 
	     /**
	     * 최초 등록자 아이디
	    */
	    private String frstRegisterId; 
	     /**
	     * 최초 등록 일시
	    */
	    private java.sql.Timestamp frstRegistDt; 
	     /**
	     * 최종 변경자 아이디
	    */
	    private String lastChangerId; 
	     /**
	     * 최종 변경 일시
	    */
	    private java.sql.Timestamp lastChangeDt; 
	    
	    /**
	     * 프라이싱 번호
	     */
	    @NotEmpty(groups = updateInvntry.class, message="금속 코드를 선택해 주세요." )
	    private String pricingNo;
	    
	     /**
	     * 이전 재고수량
	    */
	    @NotNull(groups = updateInvntry.class, message="금속 코드를 선택해 주세요." )
	    private int oldInvntryqy; 

}
