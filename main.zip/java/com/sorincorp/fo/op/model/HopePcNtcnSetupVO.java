package com.sorincorp.fo.op.model;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@Validated
public class HopePcNtcnSetupVO implements Serializable {
	/******  JAVA VO CREATE : OP_HOPE_PC_NTCN_SETUP_BAS(운영_희망_가격_알림_설정_기본)  ******/
	
	private static final long serialVersionUID = 6598466395822671354L;
	
	/**
	 *  selectRlTmSllHopePc
	 *  Validation groups를 지정하기 위한 빈 interface
	 */
	public interface selectRlTmSllHopePc{};
	/**
	 *  updateHopePc
	 *  Validation groups를 지정하기 위한 빈 interface
	 */
	public interface updateHopePc{};
	
	/**
	 *  deleteHopePc
	 *  Validation groups를 지정하기 위한 빈 interface
	 */
	public interface deleteHopePc{};
	
	/**
	 *  insertHopePc
	 *  Validation groups를 지정하기 위한 빈 interface
	 */
	public interface insertHopePc{};
	
	/**
    * 회원 번호
   */
   @NotEmpty(groups = updateHopePc.class, message="로그인 후 이용해 주세요." )
   private String mberNo; 
    /**
    * 금속 코드
   */
   @NotEmpty(groups = selectRlTmSllHopePc.class, message="수정할 알림 정보를 불러올 수 없습니다.\n다시 시도해주세요.")
   @NotEmpty(groups = updateHopePc.class, message="알람 설정 수정에 실패했습니다." )
   @NotEmpty(groups = deleteHopePc.class, message="알람 설정 삭제에 실패했습니다." )
   @NotEmpty(groups = insertHopePc.class, message="알람 설정 등록에 실패했습니다." )
   private String metalCode; 
    /**
    * 아이템 순번
   */
   @NotNull(groups = selectRlTmSllHopePc.class, message="수정할 알림 정보를 불러올 수 없습니다.\n다시 시도해주세요.")
   @NotNull(groups = updateHopePc.class, message="알람 설정 수정에 실패했습니다." )
   @NotNull(groups = deleteHopePc.class, message="알람 설정 삭제에 실패했습니다." )
   @NotNull(groups = insertHopePc.class, message="알람 설정 등록에 실패했습니다." )
   private int itmSn; 
    /**
    * 권역 대분류 코드
   */
   @NotEmpty(groups = selectRlTmSllHopePc.class, message="수정할 알림 정보를 불러올 수 없습니다.\n다시 시도해주세요.")
   @NotEmpty(groups = updateHopePc.class, message="알람 설정 수정에 실패했습니다." )
   @NotEmpty(groups = deleteHopePc.class, message="알람 설정 삭제에 실패했습니다." )
   @NotEmpty(groups = insertHopePc.class, message="알람 설정 등록에 실패했습니다." )
   private String dstrctLclsfCode; 
    /**
    * 브랜드 그룹 코드
   */
   @NotEmpty(groups = selectRlTmSllHopePc.class, message="수정할 알림 정보를 불러올 수 없습니다.\n다시 시도해주세요.")
   @NotEmpty(groups = updateHopePc.class, message="알람 설정 수정에 실패했습니다." )
   @NotEmpty(groups = deleteHopePc.class, message="알람 설정 삭제에 실패했습니다." )
   @NotEmpty(groups = insertHopePc.class, message="알람 설정 등록에 실패했습니다." )
   private String brandGroupCode; 
    /**
    * 브랜드 코드
   */
   @NotEmpty(groups = selectRlTmSllHopePc.class, message="수정할 알림 정보를 불러올 수 없습니다.\n다시 시도해주세요.")
   @NotEmpty(groups = updateHopePc.class, message="알람 설정 수정에 실패했습니다." )
   @NotEmpty(groups = deleteHopePc.class, message="알람 설정 삭제에 실패했습니다." )
   @NotEmpty(groups = insertHopePc.class, message="알람 설정 등록에 실패했습니다." )
   private String brandCode; 
   
   /**
    * 고정가 현재 가격
   */
   private long sleStdrPc;
   
   /**
    *  고정가 현재영업 시작일시 (하루 영업 시작일시를 기준으로는 동일한 값이 됨) 
    */
   private String stdDt;
   
   /**
   * 고정가 등락률
   */
   private float sleStdrPcRate;
   
   /**
   * 고정가 이전 가격
   */
   private long sleStdrPcAgo;
   
   /**
   * 고정가 versusPc
   */
   private long versusPc;
   
    /**
    * 희망가격
   */
   @NotEmpty(groups = updateHopePc.class, message="알람 설정 수정에 실패했습니다." )
   @NotEmpty(groups = deleteHopePc.class, message="알람 설정 삭제에 실패했습니다." )
   @NotEmpty(groups = insertHopePc.class, message="알람 설정 등록에 실패했습니다." )
   private String hopepc; 
    /**
    * 업체 번호
   */
   @NotEmpty(groups = updateHopePc.class, message="알람 설정 수정에 실패했습니다." )
   @NotEmpty(groups = deleteHopePc.class, message="알람 설정 삭제에 실패했습니다." )
   private String entrpsNo; 
    /**
    * 사용 여부
   */
   @NotEmpty(groups = updateHopePc.class, message="알람 설정 수정에 실패했습니다." )
   private String useAt; 
    /**
    * 삭제 일시
   */
   private java.sql.Timestamp deleteDt; 
    /**
    * 삭제 여부
   */
   private String deleteAt; 
    /**
    * 최초 등록자 아이디
   */
   private String frstRegisterId; 
    /**
    * 최초 등록 일시
   */
   private java.sql.Timestamp frstRegistDt; 
    /**
    * 최종 변경자 아이디
   */
   private String lastChangerId; 
    /**
    * 최종 변경 일시
   */
   private java.sql.Timestamp lastChangeDt; 
   /**
   *  기존 희망 가격
   */
   @NotEmpty(groups = updateHopePc.class, message="알람 설정 수정에 실패했습니다." )
   private String oldHopepc;
}
