package com.sorincorp.fo.op.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class HopePcNtcnSndngVO implements Serializable {
	
		
		private static final long serialVersionUID = -7511209372298684727L;
	
		/******  JAVA VO CREATE : OP_HOPE_PC_NTCN_SNDNG_BAS(운영_희망_가격_알림_발송_기본)    ******/
	     /**
	     * 회원 번호
	    */
	    private String mberNo; 
	     /**
	     * 금속 코드
	    */
	    private String metalCode; 
	     /**
	     * 아이템 순번
	    */
	    private int itmSn; 
	     /**
	     * 권역 대분류 코드
	    */
	    private String dstrctLclsfCode; 
	     /**
	     * 브랜드 그룹 코드
	    */
	    private String brandGroupCode; 
	     /**
	     * 브랜드 코드
	    */
	    private String brandCode; 
	     /**
	     * 희망가격
	    */
	    private java.math.BigDecimal hopepc; 
	     /**
	     * 푸시 여부
	    */
	    private String pushAt; 
	     /**
	     * 알림 발송 등록일
	    */
	    private String ntcnSndngRgsde; 
	     /**
	     * 알림 발송 완료일
	    */
	    private String ntcnSndngComptde; 
	     /**
	     * 업체 번호
	    */
	    private String entrpsNo; 
	     /**
	     * 메시지 제목
	    */
	    private String msgtitle; 
	     /**
	     * 메시지 내용
	    */
	    private String msgcontents; 
	     /**
	     * 사용 여부
	    */
	    private String useAt; 
	     /**
	     * 삭제 일시
	    */
	    private java.sql.Timestamp deleteDt; 
	     /**
	     * 삭제 여부
	    */
	    private String deleteAt; 
	     /**
	     * 최초 등록자 아이디
	    */
	    private String frstRegisterId; 
	     /**
	     * 최초 등록 일시
	    */
	    private java.sql.Timestamp frstRegistDt; 
	     /**
	     * 최종 변경자 아이디
	    */
	    private String lastChangerId; 
	     /**
	     * 최종 변경 일시
	    */
	    private java.sql.Timestamp lastChangeDt; 
	    /**
	     *  기존 희망 가격
	     */
	     private String oldHopepc;
	 

}
