package com.sorincorp.fo.op.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.my.mapper.MyAlarmMapper;
import com.sorincorp.fo.op.mapper.OpAlarmMapper;
import com.sorincorp.fo.op.model.HopePcNtcnSetupVO;
import com.sorincorp.fo.op.model.HopePcNtcnSndngVO;
import com.sorincorp.fo.op.model.InvntryNtcnSetupVO;
import com.sorincorp.fo.op.model.InvntryNtcnSndngVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OpAlarmServiceImpl implements OpAlarmService {
	
	@Autowired 
	private OpAlarmMapper opAlarmMapper;
	
	@Autowired 
	private MyAlarmMapper myAlarmMapper;
	
	@Autowired
	UserInfoUtil userInfoUtil;

	@Override
	public int insertPriceAlarm(HopePcNtcnSetupVO vo) {
		int result = 0;
		
		if( opAlarmMapper.countPriceAlarm(vo.getEntrpsNo()) < 5) { // 등록된 알람 개수			
			result = opAlarmMapper.insertPriceAlarm(vo);
		}
		
		return result;
	}

	@Override
	public List<HopePcNtcnSetupVO> selectHopePcNtcnSetupListByEntrpsNo(String entrpsNo) throws Exception {
		// TODO Auto-generated method stub
		return opAlarmMapper.selectHopePcNtcnSetupListByEntrpsNo(entrpsNo);
	}

	@Override
	public List<InvntryNtcnSetupVO> selectInvntryNtcnSetupListByEntrpsNo() throws Exception {
		// TODO Auto-generated method stub
		return opAlarmMapper.selectInvntryNtcnSetupListByEntrpsNo(userInfoUtil.getEntripsNo() != null ? userInfoUtil.getEntripsNo() : "");
	}

	@Override
	public void updateHopeAlarmReturn(HopePcNtcnSndngVO vo) throws Exception {
		try {
			opAlarmMapper.updateHopeAlarmReturn(vo);
		}
		catch(NumberFormatException ne) {
			log.error(ne.getMessage());
		}
	}

	@Override
	public void updateInvenAlarmReturn(String targetUri) throws Exception {
		// TODO 업체단위 일떄는 업체번호로 개인 단위 일때는 추가로 회원번호를 받아서 처리해야함
		// /stockAlram/{금속코드}/{아이템순번}/{권역}/{브랜드그룹}/{브랜드}/{업체번호}/{알림발송등록일}/재고수량/userId
		String[] splitTarget = targetUri.split("/");
		if (splitTarget.length!=11) {
			//정상적인 데이터가 아님 
			return;
		}
		try {
			InvntryNtcnSndngVO vo = new InvntryNtcnSndngVO();
			
			vo.setMetalCode(splitTarget[2]);
			vo.setItmSn(Integer.parseInt(splitTarget[3]));
			vo.setDstrctLclsfCode(splitTarget[4]);
			vo.setBrandGroupCode(splitTarget[5]);
			vo.setBrandCode(splitTarget[6]);
			vo.setEntrpsNo(splitTarget[7]);
			vo.setNtcnSndngComptde(splitTarget[8]);
			vo.setInvntryqy(Integer.parseInt(splitTarget[9]));
			vo.setLastChangerId(splitTarget[10]);
			
			opAlarmMapper.updateInvenAlarmReturn(vo);
		}
		catch(NumberFormatException ne) {
			log.error(ne.getMessage());
		}
	}

	@Override
	public int insertInvntryAlarmSetup(InvntryNtcnSetupVO vo) throws Exception {
		// TODO Auto-generated method stub
		int result = 0;
		
		int countAlarm = opAlarmMapper.countInvntryAlarmSetup(vo.getEntrpsNo());
		
		if(countAlarm < 5) {
				result = opAlarmMapper.insertInvntryAlarmSetup(vo);
		}
		return result;
	}

	@Override
	public int insertHopePcSending(HopePcNtcnSndngVO vo) throws Exception {
		// TODO Auto-generated method stub
		return opAlarmMapper.insertHopePcSending(vo);
	}

	@Override
	public int insertInvtSending(InvntryNtcnSndngVO vo) throws Exception {
		// TODO Auto-generated method stub
		return opAlarmMapper.insertInvtSending(vo);
	}

	@Override
	public void updateHopeAlarmPushSended(HopePcNtcnSndngVO vo) throws Exception {
		// TODO Auto-generated method stub
		opAlarmMapper.updateHopeAlarmPushSended(vo);
	}

	@Override
	public void updateInvenAlarmPushSended(InvntryNtcnSndngVO vo) throws Exception {
		// TODO Auto-generated method stub
		opAlarmMapper.updateInvenAlarmPushSended(vo);
	}

	@Override
	public int insertInvntryAlarm(InvntryNtcnSetupVO vo) throws Exception{
		
		int result = 0;
		if( opAlarmMapper.countInvntryAlarm(vo.getEntrpsNo()) < 5) { // 등록된 알람 개수			
			result = opAlarmMapper.insertInvntryAlarm(vo);
		}
		
		return result;
	}

	@Override
	public int updateInvntryAlarm(InvntryNtcnSetupVO vo) {
		
		int result = 0;
		int invntryqy = vo.getInvntryqy();
		
		vo.setInvntryqy(vo.getOldInvntryqy());
		myAlarmMapper.deleteInvntryAlarm(vo);
		
		vo.setInvntryqy(invntryqy);
		result = opAlarmMapper.insertInvntryAlarm(vo);
		
		return result;
	}
	
	@Override
	public int duplicateKeyCheckInvntryAlarm(InvntryNtcnSetupVO vo) throws Exception {
		return opAlarmMapper.duplicateKeyCheckInvntryAlarm(vo);
	}
}
