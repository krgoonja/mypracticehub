package com.sorincorp.fo.op.service;

import java.util.List;

import com.sorincorp.fo.op.model.HopePcNtcnSetupVO;
import com.sorincorp.fo.op.model.HopePcNtcnSndngVO;
import com.sorincorp.fo.op.model.InvntryNtcnSetupVO;
import com.sorincorp.fo.op.model.InvntryNtcnSndngVO;

public interface OpAlarmService {
	
	/**
	 * <pre>
	 * 처리내용: 희망가 도달 알람설정 등록
	 * </pre>
	 * @date 2021. 8. 30.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 30.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int insertPriceAlarm(HopePcNtcnSetupVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 재고  알람설정 등록
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 9.		  srec0012			    최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int insertInvntryAlarmSetup(InvntryNtcnSetupVO vo) throws Exception;
	
	
	/**
	 * <pre>
	 * 처리내용: 희망가격 알림 설정정보를 가져온다
	 * </pre>
	 * @date 2021. 9. 7.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<HopePcNtcnSetupVO> selectHopePcNtcnSetupListByEntrpsNo(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 재고 알림 설정정보를 가져온다
	 * </pre>
	 * @date 2021. 9. 7.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<InvntryNtcnSetupVO> selectInvntryNtcnSetupListByEntrpsNo() throws Exception;

	/**
	 * 
	 * <pre>
	 * 처리내용: 희망가 알림의 수신 상태를 설정한다.
	 * </pre>
	 * @date 2021. 9. 8.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 8.			srec0012			최초작성
	 * 2021. 2. 10.			Kwon sun hyung			수정
	 * ------------------------------------------------
	 * @param targetUri
	 * @throws Exception
	 */
	void updateHopeAlarmReturn(HopePcNtcnSndngVO vo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 희망가 알림의 푸시의 발송 완료 상태로 설정한다.
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	void updateHopeAlarmPushSended(HopePcNtcnSndngVO vo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 재고 알림의 수신 상태를 설정한다.
	 * </pre>
	 * @date 2021. 9. 8.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 8.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param targetUri
	 * @throws Exception
	 */
	void updateInvenAlarmReturn(String targetUri) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 재고 알림의 푸시의 발송 완료 상태로 설정한다.
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	void updateInvenAlarmPushSended(InvntryNtcnSndngVO vo) throws Exception;
	
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 희망가격 알림 발송 대상을 등록한다.
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int insertHopePcSending(HopePcNtcnSndngVO vo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 재고 알림 발송 대상을 등록한다.
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int insertInvtSending(InvntryNtcnSndngVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 재고 알림을 생성한다.
	 * </pre>
	 * @date 2021. 10. 20.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 20.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int insertInvntryAlarm(InvntryNtcnSetupVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 재고 알림을 수정한다.
	 * </pre>
	 * @date 2021. 10. 20.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 20.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	int updateInvntryAlarm(InvntryNtcnSetupVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 이미 등록된 재고 알림이 있는지 조회한다.
	 * </pre>
	 * @date 2023. 01. 11.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 01. 11.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	int duplicateKeyCheckInvntryAlarm(InvntryNtcnSetupVO vo)  throws Exception;
}
