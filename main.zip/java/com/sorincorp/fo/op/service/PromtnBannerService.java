package com.sorincorp.fo.op.service;

import java.util.List;

import com.sorincorp.fo.op.model.PromtnBannerVO;


public interface PromtnBannerService {
	
	/**
	 * <pre>
	 * 처리내용: 배너존 리스트를 가져온다.
	 * </pre>
	 * @date 2023. 4. 12.
	 * @author srec0077
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 12.			srec0077			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<PromtnBannerVO> selectPromtnBannerList(int promtnBannerZoneNo) throws Exception;
	
	/**
     * <pre>
     * 처리내용: 배너존 정보를 불러온다.
     * </pre>
     * @date 2023. 4. 19.
     * @author srec0077
     * @history 
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 4. 19.         srec0077            최초작성
     * ------------------------------------------------
     * @param vo
     * @return
     * @throws Exception
     */
    PromtnBannerVO selectBannerZoneDtl(int promtnBannerZoneNo) throws Exception;

	List<PromtnBannerVO> selectRelmBannerList(String bannerZoneCode) throws Exception;

	
}
