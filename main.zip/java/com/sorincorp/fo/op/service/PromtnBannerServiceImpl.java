package com.sorincorp.fo.op.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.op.mapper.PromtnBannerMapper;
import com.sorincorp.fo.op.model.PromtnBannerVO;

import lombok.extern.slf4j.Slf4j;

/**
 * PromtnBannerServiceImpl.java
 * @version
 * @since 2023. 3. 21.
 * @author srec0077
 */
@Slf4j
@Service
public class PromtnBannerServiceImpl implements PromtnBannerService{

    @Autowired
    private PromtnBannerMapper  promtnBannerMapper;

    @Autowired
    private FileDocService fileDocService;

    @Autowired
    private UserInfoUtil userInfoUtil;
    
    @Autowired
    private CommonService commonService;

    /**
     * 배너 목록을 조회한다.
     */
    @Override
    public List<PromtnBannerVO> selectPromtnBannerList(int promtnBannerZoneNo) throws Exception {
        return promtnBannerMapper.selectPromtnBannerList(promtnBannerZoneNo);
    }
    
    /**
     * 배너존 정보를 조회한다.
     */
    @Override
    public PromtnBannerVO selectBannerZoneDtl(int promtnBannerZoneNo) throws Exception {
        return promtnBannerMapper.selectBannerZoneDtl(promtnBannerZoneNo);
    }
    
    @Override
    public List<PromtnBannerVO> selectRelmBannerList(String bannerZoneCode) throws Exception {
        return promtnBannerMapper.selectRelmBannerList(bannerZoneCode);
    }
    
   
    
}
