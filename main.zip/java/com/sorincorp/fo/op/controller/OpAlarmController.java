package com.sorincorp.fo.op.controller;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.op.model.HopePcNtcnSetupVO;
import com.sorincorp.fo.op.model.HopePcNtcnSndngVO;
import com.sorincorp.fo.op.model.InvntryNtcnSetupVO;
import com.sorincorp.fo.op.service.OpAlarmService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping("/op")
public class OpAlarmController {
	
	@Autowired
	OpAlarmService opAlarmService;
	
	@Autowired
	UserInfoUtil userInfoUtil;
	
	@Autowired
	MessageUtil messageUtil;
	
	@Autowired
	CustomValidator customValidator;

	@Autowired
	CommonCodeService commonCodeService;

	/**
	 * <pre>
	 * 처리내용: 희망가 도달 알람을 등록한다.
	 * </pre>
	 * @date 2021. 8. 30.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 30.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param bindingResult
	 * @return 알람 등록 성공 여부 
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/setPriceAlarm")
	public ResponseEntity<Object> priceAlarm(@RequestBody HopePcNtcnSetupVO vo,BindingResult bindingResult) {
	
		Map<String,Object> map = new HashMap<String,Object>();
		Account account = userInfoUtil.getAccountInfo();
		int result = 0;
		
		customValidator.validate(vo,bindingResult,HopePcNtcnSetupVO.insertHopePc.class);
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
		}
		
		//메탈별 최소금액 확인
		try {
			List<CommonCodeVO> metalCodeList = commonCodeService.getMultiFilterCodeRetVo("METAL_CODE",vo.getMetalCode(),	//MAIN_CODE가 "METAL_CODE"인 공통 코드
					  "CODE_DCTWO","Y", null, null	//CODE_DCTWO(코드 설명2, EC 판매 대상 여부)가 Y인 METAL_CODE
					, "CODE_CHRCTR_REFRNTHREE", "1", "0", "1")//CODE_CHRCTR_REFRNTHREE(코드 문자 참조3, 판매비트)의 첫번째 값(LIVE)이 1(TRUE)인 METAL_CODE
					.values().stream().collect(Collectors.toList());
			
			for(CommonCodeVO metalCode : metalCodeList) {
				if(metalCode.getCodeNumberRefrntwo() != null && Integer.parseInt(vo.getHopepc()) < metalCode.getCodeNumberRefrntwo().intValue()) {
					
					DecimalFormat decFormat = new DecimalFormat("###,###원 ");
					String minPrice = decFormat.format(metalCode.getCodeNumberRefrntwo());
					
					Object[] obj = {"희망가격", minPrice};
					return new ResponseEntity<>(messageUtil.getMessage("co.validation.min", obj),HttpStatus.BAD_REQUEST);
				}
			}
		} catch (Exception e) {
			return new ResponseEntity<>("오류가 발생하였습니다.",HttpStatus.BAD_REQUEST);
		}

		if (account != null) {
			vo.setMberNo(account.getMberNo());
			vo.setFrstRegisterId(account.getId());
			vo.setLastChangerId(account.getId());
			vo.setEntrpsNo(account.getEntrpsNo());
		}
		
		try {
			result = opAlarmService.insertPriceAlarm(vo);
			
			if(result == 1) {
				map.put("result", "success");
			} else if(result == 0) {
				return new ResponseEntity<>(messageUtil.getMessage("fo.op.hopePrice.alarm.result.fail"),HttpStatus.BAD_REQUEST);
			}
		} 
		
		catch (DuplicateKeyException e) {
			return new ResponseEntity<>(messageUtil.getMessage("fo.op.hopePrice.alarm.result.fail.duplication"),HttpStatus.BAD_REQUEST);
		}
	
		return new ResponseEntity<>(map,HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 희망가 알림에 대한 리턴을 받아 수신 확인 처리한다.
	 * </pre>
	 * @date 2021. 9. 8.
	 * @author srec0012
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 8.		srec0012		최초작성
	 * 2021. 2. 10.			Kwon sun hyung			수정
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@MessageMapping("/op/alarm/hopeReturnInfo") 
	public void hopeReturnInfo(HopePcNtcnSndngVO vo) throws Exception {
		opAlarmService.updateHopeAlarmReturn(vo);
	}
	
	/**
	 * <pre>
	 * 처리내용: 재고 알림에 대한 리턴을 받아 수신 확인 처리한다.
	 * </pre>
	 * @date 2021. 9. 8.
	 * @author srec0012
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 8.		srec0012		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@MessageMapping("/op/alarm/ivenReturnInfo") 
	public void ivenReturnInfo(String targetUri) throws Exception {
		opAlarmService.updateInvenAlarmReturn(targetUri);
	}
	
	/**
	 * <pre>
	 * 처리내용: 재고 알림을 생성한다.
	 * </pre>
	 * @date 2021. 10. 20.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 20.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/alarm/insertInvntryAlarm")
	public ResponseEntity<Object> insertInvnAlarm(@RequestBody InvntryNtcnSetupVO vo, BindingResult bindingResult) {
		
		customValidator.validate(vo, bindingResult, InvntryNtcnSetupVO.insertInvntry.class);
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		
		Account account = userInfoUtil.getAccountInfo();
		int result = 0;
		
		if (account != null) {
			vo.setMberNo(account.getMberNo());
			vo.setFrstRegisterId(account.getId());
			vo.setLastChangerId(account.getId());
			vo.setEntrpsNo(account.getEntrpsNo());
		}
		
//		vo.setMetalCode("7");
//		vo.setItmSn(433);
//		vo.setDstrctLclsfCode("10");
//		vo.setBrandGroupCode("01");
//		vo.setBrandCode("ABCQ");
//		vo.setInvntryqy(75);
//		vo.setPricingNo("P20210826-000003");
//		vo.setUseAt("Y");		
		
		try {
			
			int dupChkInvAlCnt = opAlarmService.duplicateKeyCheckInvntryAlarm(vo);
			
			if( dupChkInvAlCnt == 0) {
				result = opAlarmService.insertInvntryAlarm(vo);
				
				if(result == 0) {
					return new ResponseEntity<>(messageUtil.getMessage("fo.op.invntry.alarm.result.fail"),HttpStatus.BAD_REQUEST);
				} else {
					return new ResponseEntity<>(messageUtil.getMessage("fo.op.invntry.alarm.result.success"),HttpStatus.OK);
				}
			} else {
				return new ResponseEntity<>(messageUtil.getMessage("fo.op.invntry.alarm.result.fail.duplication"),HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return null;
		}
		
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 재고 알림을 수정한다.
	 * </pre>
	 * @date 2021. 10. 20.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 20.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/alarm/updateInvntryAlarm")
	public ResponseEntity<Object> updateInvntryAlarm(@RequestBody InvntryNtcnSetupVO vo, BindingResult bindingResult) {
		
		Map<String,Object> map = new HashMap<String,Object>();
		
		customValidator.validate(vo, bindingResult, InvntryNtcnSetupVO.updateInvntry.class);
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		
		Account account = userInfoUtil.getAccountInfo();
		int result = 0;
		
		if (account != null) {
			vo.setMberNo(account.getMberNo());
			vo.setFrstRegisterId(account.getId());
			vo.setLastChangerId(account.getId());
			vo.setEntrpsNo(account.getEntrpsNo());
		}
		
//		vo.setMetalCode("7");
//		vo.setItmSn(433);
//		vo.setDstrctLclsfCode("10");
//		vo.setBrandGroupCode("01");
//		vo.setBrandCode("ABCQ");
//		vo.setInvntryqy(75);
//		vo.setPricingNo("P20210826-000003");
//		vo.setUseAt("Y");		
		
		try {
			result = opAlarmService.updateInvntryAlarm(vo);
			
			if(result == 0) {
				return new ResponseEntity<>(messageUtil.getMessage("fo.op.invntry.alarm.result.fail"),HttpStatus.BAD_REQUEST);
			}
		} 
		
		catch (DuplicateKeyException e) {
			return new ResponseEntity<>(messageUtil.getMessage("fo.op.invntry.alarm.result.fail.duplication"),HttpStatus.BAD_REQUEST);
		}
		
		return new ResponseEntity<>(map,HttpStatus.OK);
	
	}
	
	/**
	 * <pre>
	 * 처리내용: 재고 알림 설정정보를 가져온다
	 * </pre>
	 * @date 2021. 9. 7.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/alarm/selectInvntryNtcnSetupListByEntrpsNo") 
	public List<InvntryNtcnSetupVO> selectInvntryNtcnSetupListByEntrpsNo() throws Exception {
		return opAlarmService.selectInvntryNtcnSetupListByEntrpsNo();
	}
}
