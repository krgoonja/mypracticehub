package com.sorincorp.fo.pr.mapper;

import java.util.List;

import com.sorincorp.fo.pr.model.EvlPcVO;
import com.sorincorp.fo.pr.model.StdrMetalVO;

/**
 * evMapper.java
 * 
 * @version
 * @since 2022. 11. 23.
 * @author hyujin05
 */
public interface EvlPcMapper {

	/**
	 * <pre>
	 * 처리내용: 기준가 적용 메탈 조회
	 * </pre>
	 * 
	 * @date 2022. 11. 23
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 23.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	List<EvlPcVO> selectMetalList(EvlPcVO evlPcVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 권역 조회
	 * </pre>
	 * 
	 * @date 2022. 11. 23
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 23.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	List<EvlPcVO> selectDstrctList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 브랜드 조회
	 * </pre>
	 * 
	 * @date 2022. 11. 23
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 23.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	List<EvlPcVO> selectBrandGroupList(EvlPcVO evlPcVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 원자재 판매가격 년월 조회
	 * </pre>
	 * 
	 * @date 2023. 01. 26.
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 01. 26.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	List<EvlPcVO> selectEvlDateYear(EvlPcVO evlPcVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 원자재 판매가격 년월 조회
	 * </pre>
	 * 
	 * @date 2023. 01. 26.
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 01. 26.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	List<EvlPcVO> selectEvlDateMth(EvlPcVO evlPcVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기준 아이템 정보 조회
	 * </pre>
	 * 
	 * @date 2022. 11. 23
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 23.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	List<StdrMetalVO> selectStdrBas() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 월별 시장평균가 조회
	 * </pre>
	 * 
	 * @date 2022. 11. 23
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 23.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	List<EvlPcVO> selectEvlPcList(EvlPcVO evlPcVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 시장평균가 조회 월 평균 조회
	 * </pre>
	 * 
	 * @date 2022. 11. 23
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 23.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	List<EvlPcVO> selectMthAvgEvlList(EvlPcVO evlPcVO) throws Exception;

}
