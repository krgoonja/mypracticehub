package com.sorincorp.fo.pr.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.fo.pr.mapper.EvlPcMapper;
import com.sorincorp.fo.pr.model.EvlPcVO;

import lombok.extern.slf4j.Slf4j;

/**
 * evController.java
 * 
 * @version
 * @since 2022. 10. 28.
 * @author hyunjin05
 */
@Slf4j
@Service
public class EvlPcServiceImpl implements EvlPcService {

	@Autowired
	private EvlPcMapper evlPcMapper;

	@Autowired
	SMSService smsService;

	@Override
	public List<EvlPcVO> selectMetalList(EvlPcVO evlPcVO) throws Exception {
		return evlPcMapper.selectMetalList(evlPcVO);
	}

	@Override
	public List<EvlPcVO> selectDstrctList() throws Exception {
		return evlPcMapper.selectDstrctList();
	}

	@Override
	public List<EvlPcVO> selectBrandGroupList(EvlPcVO evlPcVO) throws Exception {
		try {
			List<EvlPcVO> list = new ArrayList<>();
			if (evlPcVO.getMetalCode() != null) {
				list = evlPcMapper.selectBrandGroupList(evlPcVO);
			} else if (evlPcVO.getMetalCode() == null) {
				evlPcVO.setMetalCode("7");
				evlPcVO.setItmSn(434);
				evlPcVO.setDstrctLclsfCode("20");
				evlPcVO.setBrandCode("02");
				list = evlPcMapper.selectBrandGroupList(evlPcVO);
			}
			return list;
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			return null;
		}
	}

	@Override
	public List<EvlPcVO> selectEvlDateYear(EvlPcVO evlPcVO) throws Exception {
		List<EvlPcVO> list = evlPcMapper.selectEvlDateYear(evlPcVO);
		if(list != null) {
			evlPcVO.setOccrrncDeYear(list.get(list.size() - 1).getOccrrncDeYear());
		}
		return list;
	}

	@Override
	public List<EvlPcVO> selectEvlDateMth(EvlPcVO evlPcVO) throws Exception {
		EvlPcVO evlPcVO2 = new EvlPcVO();
		List<EvlPcVO> list = new ArrayList<>();
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat newDtFormat = new SimpleDateFormat("yyyy");

		String nowdate = newDtFormat.format(cal.getTime());
		try {
			if (evlPcVO.getOccrrncDeYear() != null) {
				evlPcVO2.setOccrrncDeYear(evlPcVO.getOccrrncDeYear());
				list = evlPcMapper.selectEvlDateMth(evlPcVO2);
			} else if (evlPcVO.getOccrrncDeYear() == null) {
				evlPcVO2.setOccrrncDeYear(nowdate);
				list = evlPcMapper.selectEvlDateMth(evlPcVO2);
			}
			if(list.size() > 0) {
				String lastMnth = list.get(list.size()-1).getOccrrncDeMth();
				evlPcVO.setOccrrncDe(evlPcVO.getOccrrncDeYear() + "-" + lastMnth);
			}else {
				SimpleDateFormat newDtMnthFormat = new SimpleDateFormat("yyyy-MM");
				evlPcVO.setOccrrncDe(newDtMnthFormat.format(cal));
			}
			return list;
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			return null;
		}
	}

	@Override
	public List<EvlPcVO> selectEvlPcList(EvlPcVO evlPcVO) throws Exception {
		EvlPcVO evlPcVO2 = new EvlPcVO();
		List<EvlPcVO> list = new ArrayList<>();
		List<EvlPcVO> metalList = new ArrayList<>();// OccrrncDe
		//		Date date = Calendar.getInstance().getTime();
		try {
			if (evlPcVO.getMetalCode() != null) {
				evlPcVO2.setMetalCode(evlPcVO.getMetalCode());
				evlPcVO2.setDstrctLclsfCode(evlPcVO.getDstrctLclsfCode());
				evlPcVO2.setOccrrncDe(evlPcVO.getOccrrncDe());
				metalList = evlPcMapper.selectMetalList(evlPcVO2);
				evlPcVO2.setItmSn(metalList.get(0).getItmSn());
				//				evlPcVO2.setBrandGroupCode(metalList.get(0).getBrandGroupCode());
				evlPcVO2.setBrandCode(metalList.get(0).getBrandCode());
				if (evlPcVO.getBrandGroupCode() != null) {
					evlPcVO2.setBrandGroupCode(evlPcVO.getBrandGroupCode());
				} else {
					evlPcVO2.setBrandGroupCode(metalList.get(0).getBrandGroupCode());
				}

				list = evlPcMapper.selectEvlPcList(evlPcVO2);
			} else if (evlPcVO.getMetalCode() == null) {
				evlPcVO2.setMetalCode("7");
				metalList = evlPcMapper.selectMetalList(evlPcVO2);
				evlPcVO2.setMetalCode(metalList.get(0).getMetalCode());
				evlPcVO2.setItmSn(metalList.get(0).getItmSn());
				evlPcVO2.setDstrctLclsfCode(metalList.get(0).getDstrctLclsfCode());
				evlPcVO2.setBrandGroupCode(metalList.get(0).getBrandGroupCode());
				evlPcVO2.setBrandCode(metalList.get(0).getBrandCode());
				//				evlPcVO2.setOccrrncDe(nowdate);
				evlPcVO2.setOccrrncDe(evlPcVO.getOccrrncDe());
				list = evlPcMapper.selectEvlPcList(evlPcVO2);
			}
			return list;
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			return null;
		}
	}

	@Override
	public List<EvlPcVO> selectMthAvgEvlList(EvlPcVO evlPcVO) throws Exception {
		EvlPcVO evlPcVO2 = new EvlPcVO();
		List<EvlPcVO> list = new ArrayList<>();
		List<EvlPcVO> metalList = new ArrayList<>();
		//		Date date = Calendar.getInstance().getTime();  
		try {
			if (evlPcVO.getMetalCode() != null) {
				evlPcVO2.setMetalCode(evlPcVO.getMetalCode());
				evlPcVO2.setDstrctLclsfCode(evlPcVO.getDstrctLclsfCode());
				evlPcVO2.setOccrrncDe(evlPcVO.getOccrrncDe());
				//				evlPcVO2.setOccrrncDe(evlPcVO.getOccrrncDe());
				metalList = evlPcMapper.selectMetalList(evlPcVO2);
				evlPcVO2.setItmSn(metalList.get(0).getItmSn());
				//				evlPcVO2.setBrandGroupCode(metalList.get(0).getBrandGroupCode());
				//				evlPcVO2.setBrandGroupCode(evlPcVO.getBrandGroupCode());
				evlPcVO2.setBrandCode(metalList.get(0).getBrandCode());
				if (evlPcVO.getBrandGroupCode() != null) {
					evlPcVO2.setBrandGroupCode(evlPcVO.getBrandGroupCode());
				} else {
					evlPcVO2.setBrandGroupCode(metalList.get(0).getBrandGroupCode());
				}

				list = evlPcMapper.selectMthAvgEvlList(evlPcVO2);
			} else if (evlPcVO.getMetalCode() == null) {
				evlPcVO2.setMetalCode("7");
				metalList = evlPcMapper.selectMetalList(evlPcVO2);
				evlPcVO2.setMetalCode(metalList.get(0).getMetalCode());
				evlPcVO2.setItmSn(metalList.get(0).getItmSn());
				evlPcVO2.setDstrctLclsfCode(metalList.get(0).getDstrctLclsfCode());
				evlPcVO2.setBrandGroupCode(metalList.get(0).getBrandGroupCode());
				evlPcVO2.setBrandCode(metalList.get(0).getBrandCode());

				// OccrrncDe
				//				evlPcVO2.setOccrrncDe(nowdate);
				evlPcVO2.setOccrrncDe(evlPcVO.getOccrrncDe());
				list = evlPcMapper.selectMthAvgEvlList(evlPcVO2);
			}
			return list;
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.getMessage());
			return null;
		}
	}

}
