package com.sorincorp.fo.pr.service;

import java.util.List;

import com.sorincorp.fo.pr.model.EvlPcVO;

/**
 * evController.java
 * 
 * @version
 * @since 2022. 10. 28.
 * @author hyunjin05
 */
public interface EvlPcService {

	/**
	 * <pre>
	 * 처리내용: 기준가 적용 메탈 조회
	 * </pre>
	 * 
	 * @date 2022. 11. 22.
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 22.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	List<EvlPcVO> selectMetalList(EvlPcVO evlPcVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 권역 조회
	 * </pre>
	 * 
	 * @date 2022. 11. 23
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 23.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	List<EvlPcVO> selectDstrctList() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 브랜드 조회
	 * </pre>
	 * 
	 * @date 2022. 11. 23
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 23.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	List<EvlPcVO> selectBrandGroupList(EvlPcVO evlPcVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 원자재 판매가격 년 조회
	 * </pre>
	 * 
	 * @date 2023. 01. 26.
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 01. 26.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	List<EvlPcVO> selectEvlDateYear(EvlPcVO evlPcVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 원자재 판매가격 년 조회
	 * </pre>
	 * 
	 * @date 2023. 01. 26.
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 01. 26.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	List<EvlPcVO> selectEvlDateMth(EvlPcVO evlPcVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 시장평균가 조회 월 기준으로 조회
	 * </pre>
	 * 
	 * @date 2022. 11. 22.
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 22.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	List<EvlPcVO> selectEvlPcList(EvlPcVO evlPcVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 시장평균가 평균을 조회 월 기준으로 조회
	 * </pre>
	 * 
	 * @date 2022. 11. 22.
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 22.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	List<EvlPcVO> selectMthAvgEvlList(EvlPcVO evlPcVO) throws Exception;

}
