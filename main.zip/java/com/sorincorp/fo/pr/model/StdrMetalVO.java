package com.sorincorp.fo.pr.model;

import lombok.Data;

@Data
public class StdrMetalVO {
	
	/******  JAVA VO CREATE : IT_METAL_ITM_STDR_BAS()                                                                                        ******/

    /**
     * 금속 코드
    */
    private String metalCode;


    /**
     * 판매 방식 코드
    */
    private String sleMthdCode;


    /**
     * 기준 아이템 여부
    */
    private String stdrItmAt;


    /**
     * 아이템 순번
    */
    private int itmSn;


    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;


    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;


    /**
     * 브랜드 코드
    */
    private String brandCode;


    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;


    /**
     * 삭제 여부
    */
    private String deleteAt;


    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;


    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;


    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;


    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;


    /**
     * 금속 분류 코드
    */
    private String metalClCode;


}
