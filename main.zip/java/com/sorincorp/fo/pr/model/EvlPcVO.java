package com.sorincorp.fo.pr.model;

import lombok.Data;

@Data
public class EvlPcVO {

	/****** JAVA VO CREATE : ST_EVEMTH_ACCMLT_DALY_AVG_PC_BAS() ******/

	/**
	 * 발생 일자
	 */
	private String occrrncDe;

	/**
	 * 발생 일자 (년)
	 */
	private String occrrncDeYear;

	/**
	 * 발생 일자 (월)
	 */
	private String occrrncDeMth;

	/**
	 * 발생 일자
	 */
	private String codeNm;

	/**
	 * 금속 코드
	 */
	private String metalCode;

	/**
	 * 금속 이름
	 */
	private String metalNm;

	/**
	 * 아이템 순번
	 */
	private Integer itmSn;

	/**
	 * 권역 대분류 코드
	 */
	private String dstrctLclsfCode;

	/**
	 * 권역 대분류 코드
	 */
	private String dstrctLclsfNm;

	/**
	 * 브랜드 그룹 코드
	 */
	private String brandGroupCode;

	/**
	 * 브랜드 그룹 코드
	 */
	private String brandGroupNm;

	/**
	 * 브랜드 코드
	 */
	private String brandCode;

	/**
	 * LME CSP 가격
	 */
	private String lmeCsp;

	/**
	 * 달러환산률
	 */
	private String usdCvtrate;

	/**
	 * 누적 평균 가격
	 */
	private String avgSelPc;

	/**
	 * 시작 가격
	 */
	private String beginPc;

	/**
	 * 최고 가격
	 */
	private String topPc;

	/**
	 * 최저 가격
	 */
	private String lwetPc;

	/**
	 * 종료 가격
	 */
	private String endPc;

	/**
	 * 중간 가격
	 */
	private String middlePc;

	/**
	 * 조달청 가격
	 */
	private String sarokPc;

	/**
	 * 조달청 가격 VAT
	 */
	private String nonVatSarokPc;

	/**
	 * 삭제 날짜
	 */
	private java.sql.Timestamp deleteDt;

	/**
	 * 삭제 여부
	 */
	private String deleteAt;

	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;

	/**
	 * 최초 등록 일시
	 */
	private java.sql.Timestamp frstRegistDt;

	/**
	 * LME 조정 계수
	 */
	private String lmeMdatCffcnt;

	/**
	 * FX 조정 계수
	 */
	private String fxMdatCffcnt;

	/**
	 * 프리미엄 가격
	 */
	private String premiumPc;

	/**
	 * 누적 LME CSP
	 */
	private String accmltLmeCsp;

	/**
	 * 누적 달러 환산률
	 */
	private String accmltUsdCvtrate;

	/**
	 * 검색버튼 클릭 여부
	 */
	private String serchChk;

	/**
	 * 메탈 코드 문자 참조 2
	 */
	private String codeChrctrRefrntwo;

	/**
	 * 기준 아이템 여부
	 */
	private String stdrItmAt;

}
