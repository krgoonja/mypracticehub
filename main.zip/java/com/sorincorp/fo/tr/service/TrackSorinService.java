package com.sorincorp.fo.tr.service;

import com.sorincorp.fo.tr.model.TrackDetailVo;
import com.sorincorp.fo.tr.model.TrackVo;

/**
 * @ClassName: TrackSorinService
 * @Author: chajeeman
 * @Date: 2023. 5. 19.
 */
public interface TrackSorinService {

	/**
	 * <pre>
	 * 처리내용:
	 * </pre>
	 * 
	 * @date 2023. 5. 19.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2023. 5. 19.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @return
	 * @throws Exception
	 */
	int trackSorin(TrackVo trackVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 방문자 트래킹 헬스체크
	 * </pre>
	 * @date 2023. 08. 30.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 30.		hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param trackVo
	 * @return
	 * @throws Exception
	 */
	void trackHealthCheck(TrackVo trackVo) throws Exception;

}
