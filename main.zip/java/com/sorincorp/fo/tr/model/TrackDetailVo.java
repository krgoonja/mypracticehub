package com.sorincorp.fo.tr.model;

import lombok.Data;

@Data
public class TrackDetailVo {

	/**
     * 방문자 이동 일련 번호
    */
    private long visitrMvmnSeqNo;
    /**
     * 방문자 기본 일련 번호
    */
    private long visitrBassSeqNo;
    /**
     * 이전 화면
    */
    private String beforeScrin;
    /**
     * 현재 화면
    */
    private String nowScreen;
    /**
     * 버튼명
    */
    private String button;
    /**
     * 전환 코드
    */
    private String cnvrsCode;
    /**
     * 파라메터
    */
    private String params;
    /**
     * 로그인 여부
    */
    private String loginYn;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
}
