package com.sorincorp.fo.tr.controller;

import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.tr.model.TrackDetailVo;
import com.sorincorp.fo.tr.model.TrackVo;
import com.sorincorp.fo.tr.service.TrackSorinService;

import lombok.extern.slf4j.Slf4j;

/**
 * @ClassName: TrackSorinController
 * @Author: chajeeman
 * @Date: 2023. 5. 19.
 */
@Slf4j
@Controller
@RequestMapping("/fo/tr")
public class TrackSorinController {

	@Autowired
	TrackSorinService trackSorinService;

	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Autowired
	private CommonService commonService;

	/**
	 * <pre>
	 * 처리내용:
	 * </pre>
	 *
	 * @date 2023. 5. 19.
	 * @auther chajeeman
	 * @history ----------------------------------------------- 변경일 작성자 변경내용
	 *          ----------------------------------------------- 2023. 5. 19.
	 *          chajeeman 최초작성 -----------------------------------------------
	 * @param model
	 * @param request
	 */
	@ResponseBody
	@RequestMapping("/trackSorin")
	public int trackSorin(@RequestBody TrackVo trackVo, Model model, HttpServletRequest request) {
		int result = 0;
		try {

			String visitrId = null;
			String loginYn = null;
			Account account = userInfoUtil.getAccountInfo(request); // 세션정보

			if (null == account || (StringUtil.isBlank(userInfoUtil.getEntripsNo()) && StringUtil.isBlank(userInfoUtil.getMemberEmail()))) {
				visitrId = request.getSession().getId();
				loginYn = "N";
			} else {
				visitrId = account.getId();
				trackVo.setMberNo(account.getMberNo());
				trackVo.setEntrpsNo(account.getEntrpsNo());
				loginYn = "Y";
			}

			trackVo.setVisitrId(trackVo.getVisitrId() != null ? trackVo.getVisitrId() : visitrId);// 방문자 아이디
			trackVo.setVisitrIp(commonService.getClientIpAddressIfServletRequestExist());// 방문자 IP
			trackVo.setConectEnvrn(request.getHeader("User-Agent"));
			
			//내부 사용자 IP 제외
			if( trackVo.getVisitrIp().indexOf("168.126.230.") > -1
					|| trackVo.getVisitrIp().indexOf("165.225.97.") > -1
					|| trackVo.getVisitrIp().indexOf("165.225.228.") > -1
					|| trackVo.getVisitrIp().indexOf("165.225.229.") > -1) {
				return result;
			}
			//내부 사용자 제외(업체 번호)
			if(StringUtils.isNotEmpty(trackVo.getEntrpsNo()) && !trackVo.getEntrpsNo().equals("null")){
				if(StringUtils.equals(trackVo.getEntrpsNo(), "C0121")
					|| StringUtils.equals(trackVo.getEntrpsNo(), "C0122")
					|| StringUtils.equals(trackVo.getEntrpsNo(), "C0133")){
					return result;
				}
			}

			TrackDetailVo trackDetailVo = trackVo.getTrackDetailVo();
			if(trackDetailVo == null) {
				trackDetailVo = new TrackDetailVo();
			}
			trackDetailVo.setLoginYn(trackDetailVo.getLoginYn() != null ? trackDetailVo.getLoginYn() : loginYn);
			trackDetailVo.setFrstRegisterId(trackVo.getNewVisitrId() != null ? trackVo.getNewVisitrId() : trackVo.getVisitrId());

			if (trackVo.getInflowCours() != null && !"".equals(trackVo.getInflowCours())) {
				trackVo.setInflowCours(URLDecoder.decode(trackVo.getInflowCours(), "UTF-8"));
			}

			result = trackSorinService.trackSorin(trackVo);

		} catch (Exception e) {
			log.error("[TrackSorinController][loanCnsltReqstInfo]" + ExceptionUtils.getStackTrace(e));
		}
		return result;
	}


	@ResponseBody
	@RequestMapping("/trackHealthCheck")
	public Map<String, Object> trackHealthCheck(HttpServletRequest request) {
		Map<String, Object> resMap= new HashMap<>();
		try {
			String visitrId = null;
			Account account = userInfoUtil.getAccountInfo(request);
			if (null == account && null != request.getSession()) {//비로그인
				visitrId = request.getSession().getId();	//세션아이디
			} else {//로그인
				visitrId = account.getId();	//계정 아이디
			}
			TrackVo trackVo = new TrackVo();
			trackVo.setVisitrId(visitrId);// 방문자 아이디
			trackSorinService.trackHealthCheck(trackVo);
			resMap.put("msg","S");
		} catch (Exception e) {
			log.error("[TrackSorinController][trackHealthCheck]" + ExceptionUtils.getStackTrace(e));
			resMap.put("msg","F");
		}
		return resMap;
	}
}
