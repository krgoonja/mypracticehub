package com.sorincorp.fo.login.model;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import org.springframework.validation.annotation.Validated;

import lombok.Data;

@Data
@Validated
public class LoginVO implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -5698846760103762738L;


	/**
	 *  loginInfo
	 *  Validation groups를 지정하기 위한 빈 interface
	 */
	public interface loginInfo{};

	/**
	 *  loginAuth
	 *  Validation groups를 지정하기 위한 빈 interface
	 *  회원사 로그인만 해당
	 */
	public interface loginAuth{};

	/** 아이디 */
	@NotEmpty(groups = loginInfo.class, message="아이디를 입력해 주세요.")
	private String id;

	/** 비밀번호 */
	@NotEmpty(groups = loginInfo.class, message="비밀번호를 입력해 주세요.")
	@NotEmpty(message="비밀번호를 입력해 주세요.")
	private String password;

	/** 인증 토큰 */
	@NotEmpty(groups = loginAuth.class, message="인증되지 않은 계정입니다.")
	private String token;

	/** 인증 번호 */
	@NotEmpty(groups = loginAuth.class, message="인증번호를 입력해주세요.")
	private String authNum;

	/** 아이디 저장 여부 */
	private Boolean saveId;
	
	/**  대행 업무 여부 */
	private Boolean vrscYn = false;


	/****** JAVA VO CREATE : MB_LOGIN_INFO_HST(회원_로그인 정보 이력) ******/

	/**
	 * 회원 번호
	 */
	private String mberNo;
	/**
	 * 간편 회원 번호
	 */
	private String simplMberNo;
	/**
	 * 로그인 정보 이력 순번
	 */
	private long loginInfoHistSn;
	/**
	 * 로그인 일시
	 */
	private String loginDt;
	/**
	 * 로그인 IP
	 */
	private String loginIp;
	/**
	 * 접속 환경 코드
	 */
	private String conectEnvrnCode;
	/**
	 * 유저 에이전트 정보
	 */
	private String userAgntInfo;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;
	/**
	 * 로그인 상태 코드
	 */
	private String loginSttusCode;
	/**
	 * 환불계좌 상태 코드
	 */
	private String refndAcnutSttusCode;
	/**
	 * 업체명 한글
	 */
	private String entrpsnmKorean;
	/**
	 * 업체 등급
	 */
	private String entrpsGrad;
	/**
	 * 회원_업체 월별 구매 혜택 기본 (상시할인)
	 */
	private String entrpsMnbyPurchsBnef;
	
	/**
	 * 회원_업체 등급 금속 별 관리 상세 (등급할인)
	 */
	private String entrpsPayBackDscnt;
	
	/**
	 * 회원_업체 월별 구매 혜택 기본 (상시할인) 사용여부
	 */
	private String entrpsMnbyPurchsBnefUseAt;
	
	/**
	 * 회원_업체 등급 금속 별 관리 상세 (등급할인) 사용여부
	 */
	private String entrpsPayBackDscntUseAt;
	
}
