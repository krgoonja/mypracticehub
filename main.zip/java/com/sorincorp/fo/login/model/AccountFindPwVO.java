package com.sorincorp.fo.login.model;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import org.springframework.validation.annotation.Validated;

import lombok.Data;

/**
 * AccountFindVO.java
 * @version
 * @since 2021. 10. 27.
 * @author srec0042
 */
@Data
@Validated
public class AccountFindPwVO implements Serializable{
	

		/**
		 * serialVersionUID
		 */
		private static final long serialVersionUID = 5520517016503563459L;

		/**
		 * findPw
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface findPw{};
		
		/**
		 * changePw
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface changePw{};
		
		/**
		 * findPwGetToken
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface findPwGetToken{};
		
		/**
		 * noticeChangePw
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface noticeChangePw{};
		
		/**
		 * noticeNextDatePw
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface noticeNextDatePw{};
	
		/** 아이디 */
		@NotEmpty(groups = findPw.class, message="아이디를 입력해 주세요.")
		@NotEmpty(groups = findPwGetToken.class, message="아이디를 입력해 주세요.")
		@NotEmpty(groups = changePw.class, message="인증되지 않은 계정입니다.")
		@NotEmpty(groups = noticeNextDatePw.class, message="인증되지 않은 계정입니다.")
		private String id;
		
		/** 비밀번호 */
		@NotEmpty(groups = changePw.class, message="비밀번호를 입력해 주세요.")
		@NotEmpty(groups = noticeChangePw.class, message="변경할 비밀번호를 입력해 주세요.")
		private String password;
		
		/** 이전 비밀번호 */
		@NotEmpty(groups = noticeChangePw.class, message="기존 비밀번호를 입력해 주세요.")
		private String oldPassword;
		
		/** 인증 토큰 */
		@NotEmpty(groups = findPwGetToken.class, message="인증되지 않은 계정입니다.")
		private String token;
	
		/** 인증 번호 */
		@NotEmpty(groups = findPwGetToken.class, message="인증번호를 입력해 주세요.")
		private String authNum;

		/** 전화 번호 */
		@NotEmpty(groups = findPw.class, message="휴대폰번호를 입력해 주세요.")
		private String phoneNum;

}    
