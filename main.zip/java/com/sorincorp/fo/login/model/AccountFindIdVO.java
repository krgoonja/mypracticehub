package com.sorincorp.fo.login.model;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import org.springframework.validation.annotation.Validated;

import lombok.Data;

/**
 * AccountFindVO.java
 * @version
 * @since 2021. 10. 27.
 * @author srec0042
 */
@Data
@Validated
public class AccountFindIdVO implements Serializable{
	

		/**
		 * serialVersionUID
		 */
		private static final long serialVersionUID = 5520517016503563459L;

		/**
		 * findId
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface findId{};
		
		/**
		 * findId
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface confirmId{};
		
		/**
		 * findIdResult
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface findIdResult{};
		
		/** 인증 토큰 */
		@NotEmpty(groups = confirmId.class, message="인증되지 않은 계정입니다.")
		private String token;
	
		/** 인증 번호 */
		@NotEmpty(groups = confirmId.class, message="인증번호를 입력해 주세요.")
		private String authNum;

		/** 전화 번호 */
		@NotEmpty(groups = findId.class, message="휴대폰번호를 입력해 주세요.")
		@NotEmpty(groups = confirmId.class, message="인증되지 않은 계정입니다.")
		private String phoneNum;
		
		/** 마스킹 아이디 */
		@NotEmpty(groups = findIdResult.class, message="인증되지 않은 계정입니다.")
		private String maskingId;
		
		/** 가입일 */
		@NotEmpty(groups = findIdResult.class, message="인증되지 않은 계정입니다.")
		private String signUpDate;
		
		/**
		 * 아이디 찾기 : 간편회원, 회원사인지 체크
		 */
		@NotEmpty(groups = findId.class, message="인증되지 않은 계정입니다.")
		@NotEmpty(groups = confirmId.class, message="인증되지 않은 계정입니다.")
		private String type;

}    
