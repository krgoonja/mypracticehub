package com.sorincorp.fo.login.model;

import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;

import org.apache.ibatis.javassist.SerialVersionUID;
import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.annotation.MaskingClass;
import com.sorincorp.comm.annotation.MaskingField;
import com.sorincorp.comm.annotation.MaskingField.MaskingType;
import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * AccountEntrpsInfoVO.java
 *
 * @version
 * @since 2022. 7. 6.
 * @author srec0067
 */
@Data
public class AccountEntrpsInfoVO implements Serializable {/**
	 * 
	 */
	private static final long serialVersionUID = -7866527781928530880L;

	/****** JAVA VO CREATE : MB_ENTRPS_INFO_BAS(회원_업체 정보 기본) ******/
	
	/**
	 * 업체 번호
	 */
	private String entrpsNo;
	
	/**
	 * 업체명 한글
	 */
	private String entrpsnmKorean;
	
	/**
	 * 신용 등급
	 */
	private String credtGrad;
	
	/**
	 * 업체 등급
	 */
	private String entrpsGrad;
	
	/**
	 * 업체 평가 등급
	 */
	private String entrpsEvlGrad;
	
	/**
	 * 업체 구매 성향 등급
	 */
	private String entrpsPurchsInclnGrad;
	
	/**
	 * 증거금 사용 여부
	 */
	private String wrtmUseAt;
	
	/**
	 * 증거금 신청 일시
	 */
	private String wrtmReqstDt;
	
	/**
	 * 증거금 해지 일시
	 */
	private String wrtmTrmnatDt;
	
	/**
	 * 담보 보증 사용 여부
	 */
	private String mrtggGrntyUseAt;
	
	/**
	 * 담보 보증 신청 일시
	 */
	private String mrtggGrntyReqstDt;
	
	/**
	 * 담보 보증 해지 일시
	 */
	private String mrtggGrntyTrmnatDt;
	
	/**
	 * 담보 보증 보험 요율
	 */
	private String mrtggGrntyInsrncTariff;
	
	/**
	 * 담보 보증 상환 기간
	 */
	private String mrtggGrntyRepyPd;
	
	/**
	 * 담보 보증 계약 여부
	 */
	private String mrtggGrntyCntrctAt;
	
	/**
	 * 담보 보증 수수료 부담 주체 여부
	 */
	private String mrtggGrntyFeeBndMbyAt;
	
	/**
	 * 담보 보증 한도
	 */
	private String mrtggGrntyLmt;
	
	/**
	 * 담보 보증 보험료
	 */
	private String mrtggGrntyIrncf;
	
	/**
	 * 대출 보증 사용 여부
	 */
	private String lonGrntyUseAt;
	
	/**
	 * 대출 보증 수수료 부담 주체 여부
	 */
	private String lonGrntyFeeBndMbyAt;
	
	/**
	 * 증거금 신청 여부
	 */
	private String wrtmReqstAt;
	
	/**
	 * 담보 보증 신청 여부
	 */
	private String mrtggGrntyReqstAt;
	
	/**
	 * 대출 보증 신청 여부
	 */
	private String lonGrntyReqstAt;
	
	/**
	 * 담보 보증 지원 보험료
	 */
	private String mrtggGrntySportIrncf;
	
	/**
	 * 담보 보증 지원 수수료
	 */
	private String mrtggGrntySportFee;
	
	/**
	 * 대표자명
	 */
	private String rprsntvNm;
}
