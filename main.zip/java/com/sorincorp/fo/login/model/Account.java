package com.sorincorp.fo.login.model;

import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.fo.op.model.HopePcNtcnSetupVO;
import com.sorincorp.fo.op.model.InvntryNtcnSetupVO;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class Account implements UserDetails {
	private String id;
	private String password;
	private String mberNo;		// 회원번호
	private String name;		// 회원 이름
	private String phonenum;	// 회원 전화번호
	private String email;		// 회원 이메일
	private String secode;		// 업무구분
	private String entrpsNo;	// 회원사 번호
	private String mberSttusCode; // 회원 상태 코드
	private String type;  		// 회원 구분 (일반 회원 : 01, 간편 회원 : 02)
	private String authorNo;	// 회원 권한
	private int secretNoErrorCo;// 비밀 번호 오류 횟수
	private String loginSttusCode; // 로그인 상태 코드
	private String refndAcnutSttusCode; // 환불계좌상태 코드
	private String mberConfmProcessDt; // 회원승인일자
	private String currentDt; // 현재일자
	private String scndCrtfcMnAt; // 2차 승인 여부
	private String confmToFirstLogin; // 최초 로그인 확인 ( 회원승인이후)
	private String entrpsnmKorean;	//기업명
	private String entrpsGrad; // 업체 등급
	private String entrpsMnbyPurchsBnef; // 회원_업체 월별 구매 혜택 기본 (상시할인)
	private String entrpsPayBackDscnt; // 회원_업체 등급 금속 별 관리 상세 (등급할인)
	private String entrpsMnbyPurchsBnefUseAt; // 회원_업체 월별 구매 혜택 기본 (상시할인) 사용여부
	private String entrpsPayBackDscntUseAt; // 회원_업체 등급 금속 별 관리 상세 (등급할인) 사용여부
	private String advrtsRecptnAgreAt;      //회원_마케팅 수신 동의 여부

//	private List<HopePcNtcnSetupVO> hopeSetupList;		//희망가 설정 목록
//	private List<InvntryNtcnSetupVO> inveSetupList;		//재고 설정 목록

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return null;
		/* ROLE을 사용하는 경우
		return this.roles.stream()
				.map(SimpleGrantedAuthority::new)
				.collect(Collectors.toList());
		*/
	}
	@Override
	public String getPassword() {
		return this.password;
	}
	@Override
	public String getUsername() {
		return this.id;
	}
	@Override
	public boolean isAccountNonExpired() {
		return true;
	}
	@Override
	public boolean isAccountNonLocked() {
		return true;
	}
	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}
	@Override
	public boolean isEnabled() {
		return true;
	}
}
