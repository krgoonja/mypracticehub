package com.sorincorp.fo.login.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.fo.config.LoginTokenProvider;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.login.model.AccountFindIdVO;
import com.sorincorp.fo.login.model.AccountFindPwVO;
import com.sorincorp.fo.login.service.AccountServiceImpl;

import io.jsonwebtoken.ExpiredJwtException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Controller
@Slf4j
@RequestMapping("/account/find")
public class AccountFindController {

	private final LoginTokenProvider loginTokenProvider;
	private final LoginTokenProvider jwtTokenProvider;
	private final AccountServiceImpl accountService;
	private final MessageUtil messageUtil;
	private final RedisUtil redisUtil;
	
	@Autowired
	private CustomValidator customValidator;
	
	@Value("${spring.profiles.active}")
	private String profiles;
	
	/**
	 * <pre>
	 * 처리내용: 아이디 찾기 화면으로 이동
	 * </pre>
	 * @date 2021. 8. 3.
	 * @author srec0041
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 3.			srec0041			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@RequestMapping("/id")
	public String findId() {
		
		try {
			return "us/findId";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
		
	}
	
	/**
	 * <pre>
	 * 처리내용: 아이디찾기 휴대폰 인증번호 발송
	 * </pre>
	 * @date 2021. 8. 3.
	 * @author srec0041
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 3.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param phoneNum
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/id/getAuthNum")
	public ResponseEntity<Object> findIdAuth(@RequestBody AccountFindIdVO accountFindVO, BindingResult bindingResult) {
		
		Map<String,Object> map = new HashMap<>();
		
		customValidator.validate(accountFindVO, bindingResult, AccountFindIdVO.findId.class);
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
		}
		
		
		try {
			Account account = new Account();
			if(accountFindVO.getType().equals("02")) {
				account = accountService.selectSimpleAccountByPhone(accountFindVO.getPhoneNum());
			}
			else if(accountFindVO.getType().equals("01")) {
				account = accountService.selectAccountByPhone(accountFindVO.getPhoneNum());
			}
			
			if(account == null) {
				return new ResponseEntity<>(messageUtil.getMessage("co.validation.phone"), HttpStatus.BAD_REQUEST);
			}
			
			String authNum = accountService.phoneAuth(account);
			String token = jwtTokenProvider.generateSmsToken(authNum);

			if(profiles.equals("local") || profiles.equals("dev")) {
				map.put("authNum", authNum);
			}
			
			map.put("token", token);
			
		}catch (Exception e) {
			return new ResponseEntity<>("존재하지 않는 회원입니다.", HttpStatus.BAD_REQUEST);
		}
		//else {
		
		
			//String json = "{\"authNum\": \"" + authNum + "\", \"token\": \"" + token + "\"}";
			//return new ResponseEntity<>(json, HttpStatus.OK);
		//}
		//return token;
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 인증번호 확인
	 * </pre>
	 * @date 2021. 8. 3.
	 * @author srec0041
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 3.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param json
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/id/confirm")
	public ResponseEntity<Object> confirmAuth(@RequestBody AccountFindIdVO accountFindVO, BindingResult bindingResult) throws Exception {
		
		customValidator.validate(accountFindVO, bindingResult, AccountFindIdVO.confirmId.class);
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
		}
		
		String token = accountFindVO.getToken();
		String authNum = accountFindVO.getAuthNum();
		String phoneNum = accountFindVO.getPhoneNum();
		
		Map<String, Object> map = new HashMap<>();
		try {
			Account account = new Account();
		
			if(accountFindVO.getType().equals("02")) {
				account = accountService.selectSimpleAccountByPhone(phoneNum);
			}
			else if(accountFindVO.getType().equals("01")) {
				account = accountService.selectAccountByPhone(phoneNum);
			} 
			if(authNum.equals(jwtTokenProvider.getUsername(token))) {
				
				map.put("id", account.getId());
				map.put("signUpDate", accountService.selectSignUpDate(account));
			}
			else {
				return new ResponseEntity<>("인증번호를 확인해 주세요.", HttpStatus.BAD_REQUEST);
			}
		} catch(ExpiredJwtException e) {
			return new ResponseEntity<>("인증번호를 입력한 시간이 초과되었습니다.\n 다시 시도하려면 새로운 인증번호를 요청하세요.", HttpStatus.BAD_REQUEST);
		} catch(Exception e) {
			log.error(e.toString());
			return new ResponseEntity<>("시스템 오류가 발생했습니다.\n 관리자에게 문의해주세요.", HttpStatus.BAD_REQUEST);
		}
		
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 아이디 찾기 결과화면으로 이동
	 * </pre>
	 * @date 2021. 8. 3.
	 * @author srec0041
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 3.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param maskingId
	 * @param model
	 * @return
	 */
	
	@RequestMapping("/id/result")
	public String findIdResult(@RequestBody AccountFindIdVO accountFindVO, Model model, BindingResult bindingResult) {
		
		customValidator.validate(accountFindVO,bindingResult,AccountFindIdVO.findIdResult.class);
		
		if(bindingResult.hasErrors()) {
			throw new IllegalArgumentException("인증되지 않은 계정입니다.");
		}
		
		try {
			model.addAttribute("maskingId", accountFindVO.getMaskingId());
			model.addAttribute("signUpDate", accountFindVO.getSignUpDate());
			return "/us/findIdResult";
			
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
		
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 비밀번호 찾기 화면으로 이동한다.
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@RequestMapping(value = "/pw")
	public String findPw(){
		
		try {
			return "us/findPw";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 간편 회원 - 비밀번호 찾기 화면으로 이동한다.
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@RequestMapping(value = "/simplePw")
	public String findSimplePw() {
		
		try {
			return "us/simpleFindPw";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경 화면으로 이동한다.
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param id
	 * @param model
	 * @return changePw
	 */
	@RequestMapping(value = "/pw/change")
	public String changePw() {
		
		try {
			return "us/changePw";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}

	}
	
	/**
	 * <pre>
	 * 처리내용: 간편 회원 - 비밀번호 변경 화면으로 이동한다.
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@RequestMapping(value = "/simplePw/change")
	public String changeSimplePw() {
		
		try {
			return "us/simpleChangePw";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
		
	}
	
	/**
	 * <pre>
	 * 처리내용: 간편 회원 - 비밀번호 변경 결과 화면으로 이동한다.
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@RequestMapping(value = "/simplePw/result")
	public String ResultSimplePw() {
		
		try {
			return "us/simpleChangePwResult";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
		
	}
	
	/**
	 * <pre>
	 * 처리내용: 비밀번호를 변경한다.
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return 비밀번호 변경 성공 여부
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value ="/pw/new")
	public ResponseEntity<Object> getNewPassword(@RequestBody AccountFindPwVO accountFindVO, BindingResult bindingResult) {
		
		customValidator.validate(accountFindVO,bindingResult,AccountFindPwVO.changePw.class);
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		
		
		Map<String, Object> map = new HashMap<String,Object>();
		
		Account account = new Account();
		account.setPassword(accountFindVO.getPassword());
		account.setId(accountFindVO.getId());
		
		try {
			account = cryptAccount(account);
			accountService.updatePw(account);
			accountService.insertMbInfoBasHst(account); // 회원 히스토리 테이블 INSERT
			map.put("result", "success");
		}
		catch (Exception e) {
			return new ResponseEntity<>("비밀번호 변경이 실패했습니다.", HttpStatus.BAD_REQUEST);
		}
		
		
		return new ResponseEntity<>(map,HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value ="/simplePw/new")
	public ResponseEntity<Object> getNewSimplePassword(@RequestBody AccountFindPwVO accountFindVO, BindingResult bindingResult) {
		Map<String, Object> map = new HashMap<String,Object>();
		
		customValidator.validate(accountFindVO, bindingResult,AccountFindPwVO.changePw.class);
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.hasErrors(),HttpStatus.BAD_REQUEST);
		}
	
		try {
			
			Account account = new Account();
			account.setId(accountFindVO.getId());
			account.setPassword(accountFindVO.getPassword());
			
			account = cryptAccount(account);
			accountService.updateSimplPw(account);
			accountService.insertSimplMbInfoBasHst(account); // 간편 회원 히스토리 테이블 INSERT
			map.put("result", "success");
		}
		catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>("비밀번호 변경이 실패했습니다.", HttpStatus.BAD_REQUEST);
		}
		
		return new ResponseEntity<>(map,HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경 안내 화면으로 이동한다.
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return changePwNotice
	 */
	@RequestMapping(value = "/pw/notice")
	public String notice() {
		
		try {
			return "us/changePwNotice";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
		
	}
	

	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경 안내 - 비밀번호 변경
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param json
	 * @return 비밀번호 변경 성공 여부
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping(value="/pw/notice/change")
	public ResponseEntity<Object> changePwnotice(@RequestBody AccountFindPwVO accountFindVO, BindingResult bindingResult) throws Exception {
		
		customValidator.validate(accountFindVO, bindingResult, AccountFindPwVO.noticeChangePw.class);
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
		}
		
		Account account = new Account();
		Map<String,Object> map = new HashMap<>();
		account = accountService.selectAccount(accountFindVO.getId());
		
		String oldPassword = accountFindVO.getOldPassword();
		String newPassword =  Optional.of(accountFindVO.getPassword()).map(CryptoUtil::encryptSHA256).get();
		
		String accountPassword = account.getPassword();
		
		account.setPassword(oldPassword);
		account = cryptAccount(account);
		if(accountService.selectChangePw(account) != 1){
			return new ResponseEntity<>("기존 비밀번호가 일치하지 않습니다.",HttpStatus.BAD_REQUEST);	
		}
		
		if(accountPassword.equals(newPassword)){
			return new ResponseEntity<>("기존 비밀번호와 다른 비밀번호를 입력해주십시오.",HttpStatus.BAD_REQUEST);	
		}
	
//		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//		if ( !"anonymousUser".equals(auth.getPrincipal())) {
//			account = (Account)auth.getPrincipal(); 
//			account.setPassword(oldPassword);
//			account = cryptAccount(account);
//		}

		
		account.setPassword(newPassword);	

		if(account.getType().equals("02")) {
			accountService.updateSimplPw(account);
			accountService.insertSimplMbInfoBasHst(account); // 간편 회원 히스토리 테이블 INSERT
			map.put("result", "success");
		}

		else if(account.getType().equals("01")) {
			accountService.updatePw(account);
			accountService.insertMbInfoBasHst(account); // 회원 히스토리 테이블 INSERT
			map.put("result", "success");
		}
			
		
		return new ResponseEntity<>(map,HttpStatus.OK);
	}

	
	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경 안내 - 30일 이후 비밀번호 변경 처리
	 * </pre>
	 * @date 2021. 7. 29.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 29.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unused")
	@ResponseBody
	@RequestMapping("/pw/notice/nextDate")
	public ResponseEntity<Object> changeNextDate(@RequestBody AccountFindPwVO accountFindVO
			, HttpServletRequest request, HttpServletResponse response, BindingResult bindingResult) {
		
		Map<String,Object> map = new HashMap<String,Object>();
		
		customValidator.validate(accountFindVO, bindingResult,AccountFindPwVO.noticeNextDatePw.class);
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
		}
		
		Account account = new Account();

		try {
			account = accountService.selectAccount(accountFindVO.getId());
			
			if(account.getType().equals("02")) {
				accountService.updateSimplNextPwChgDate(account);
				accountService.insertSimplMbInfoBasHst(account); // 간편 회원 히스토리 테이블 INSERT
			}
			
			else if(account.getType().equals("01")){
				accountService.updateNextPwChgDate(account);
				accountService.insertMbInfoBasHst(account); // 회원 히스토리 테이블 INSERT
			}
			
			if(account != null) {
				final String access = loginTokenProvider.generateAccessToken(account, account.getId());
				final String refresh = loginTokenProvider.generateRefreshToken(account.getId());
				
				ResponseCookie accessToken = loginTokenProvider.createSecureCookie(CommonConstants.ACCESS_TOKEN_NAME, access, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);
				ResponseCookie refreshToken = loginTokenProvider.createSecureCookie(CommonConstants.REFRESH_TOKEN_NAME, refresh, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND);
		
				// Token을 Redis에 저장(만료기간 지정)
				redisUtil.setDataExpire(CommonConstants.REDIS_KEY_FO_ACCESS + account.getId(), access, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);
				redisUtil.setDataExpire(CommonConstants.REDIS_KEY_FO_REFRESH + account.getId(), refresh, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND);
			
				response.addHeader(HttpHeaders.SET_COOKIE, accessToken.toString());
				response.addHeader(HttpHeaders.SET_COOKIE, refreshToken.toString());
				
				map.put("result", "success");
		    } else {
		    	log.error("Account정보가 없습니다.");
		    	return new ResponseEntity<>("Account정보가 없습니다.",HttpStatus.BAD_REQUEST);
		    }
			
		}catch (Exception e) {
			return new ResponseEntity<>("비밀번호 다음에 변경하기 설정이 실패했습니다.",HttpStatus.BAD_REQUEST);
		}
		
		return new ResponseEntity<>(map,HttpStatus.OK);
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 비밀번호 재설정 화면으로 이동한다.
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return 비밀번호 재설정 화면
	 */
	@RequestMapping(value = "/pw/notice/result")
	public String changePwnoticeResult() {
		
		try {
			return "us/changePwNoticeResult";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	
	}

	
	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경 결과 화면으로 이동한다.
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return changePwResult
	 */
	@RequestMapping(value = "/pw/result")
	public String changePwResult() {
		
		try {
			return "us/changePwResult";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}

	}

	/**
	 * <pre>
	 * 처리내용: 문자 본인 인증 번호 및 토큰 생성
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return token
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/pw/getAuthNum")
	public ResponseEntity<Object> getAuthNum(@RequestBody AccountFindPwVO accountFindVO, BindingResult bindingResult) throws Exception {
		
		customValidator.validate(accountFindVO,bindingResult,AccountFindPwVO.findPw.class);
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
		}
		
		Account account = accountService.selectAccount(accountFindVO.getId());
		
		if( account == null ) { 
			return new ResponseEntity<>(messageUtil.getMessage("co.text.invalid.user"), HttpStatus.BAD_REQUEST);
		}
		 
		if(!account.getPhonenum().equals(accountFindVO.getPhoneNum())) {
			return new ResponseEntity<>(messageUtil.getMessage("co.validation.phone"), HttpStatus.BAD_REQUEST);
		}

		String authNum =  accountService.phoneAuth(account);
		String token = jwtTokenProvider.generateSmsToken(authNum);
		  
		Map<String,Object> map = new HashMap<>();
		  
		if(profiles.equals("local") || profiles.equals("dev")) {
			map.put("authNum", authNum);
		}
		  
		map.put("token", token);
		
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	
	/**
	 * <pre>
	 * 처리내용:  문자 본인 인증 번호 토큰 확인
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param json
	 * @return 문자 본인 인증 번호 토큰 확인 결과
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/pw/getToken")
	public ResponseEntity<Object> getToken(@RequestBody AccountFindPwVO accountFindVO, BindingResult bindingResult) throws Exception {

		Map<String,Object> map = new HashMap<String,Object>();

		customValidator.validate(accountFindVO, bindingResult, AccountFindPwVO.findPwGetToken.class);
		
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
		}
		
		String token = accountFindVO.getToken();
		String authNum = accountFindVO.getAuthNum();
		String id = accountFindVO.getId();
		
		try {
			if ( !authNum.equals(jwtTokenProvider.getUsername(token)) ) {
				return new ResponseEntity<>(messageUtil.getMessage("fo.co.text.invalid.authnum"),HttpStatus.BAD_REQUEST);
			}

			map.put("result", "success");
			map.put("id", id);
		} catch(ExpiredJwtException e) {
			return new ResponseEntity<>("인증번호를 입력한 시간이 초과되었습니다.\n 다시 시도하려면 새로운 인증번호를 요청하세요.", HttpStatus.BAD_REQUEST);
		} catch(Exception e) {
			log.error(e.toString());
			return new ResponseEntity<>("시스템 오류가 발생했습니다.\n 관리자에게 문의해주세요.", HttpStatus.BAD_REQUEST);
		}
		
		return  new ResponseEntity<>(map,HttpStatus.OK);
	}


	public Account cryptAccount(Account account) {
		account.setPassword(Optional.of(account.getPassword()).map(CryptoUtil::encryptSHA256).get());
		return account;
	}
}
