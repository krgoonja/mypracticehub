package com.sorincorp.fo.login.controller;

import java.io.IOException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.codehaus.jettison.json.JSONException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.fo.config.LoginTokenProvider;
import com.sorincorp.fo.login.mapper.AccountMapper;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.smsTest.service.AlimTestServiceImpl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Controller
@RequestMapping(value = "/login")
public class LoginControllerOld {
	private final PasswordEncoder passwordEncoder;
	private final LoginTokenProvider loginTokenProvider;
	private final AccountMapper accountMapper;
	private final MessageUtil messageUtil;
	private final RedisUtil redisUtil;
	
	/**
	 * <pre>
	 * 로그인 화면으로 이동한다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@RequestMapping(value = "/loginView")
	public String login() {
		return "sample/sampleLogin";
	}
	
	/**
	 * <pre>
	 * 로그인 처리. Token 생성 -> Cookie에 저장 -> Refresh Token Redis에 저장 -> Response에 Cookie 저장
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param id
	 * @param password
	 * @param response
	 * @throws JSONException
	 * @throws IOException
	 */
	@GetMapping(value = "/getToken")
	public void login(@RequestParam("id") String id, @RequestParam("password") String password, HttpServletResponse response) throws JSONException, IOException {
		try {
			// 회원 정보 조회
			Account account = accountMapper.selectAccount(id);
			// 회원정보가 없으면 Exception 발생
			if ( account == null ) {
				throw new IllegalArgumentException(messageUtil.getMessage("fo.co.text.invalid.user"));
			}
			// 비밀번호가 다르면 Exception 발생
			if ( !passwordEncoder.matches(password, "{noop}" + account.getPassword()) ) {
				throw new IllegalArgumentException(messageUtil.getMessage("fo.co.text.invalid.password"));
			}
			
			//Token 생성전에 패스워드정보를 제외한다.
			account.setPassword(null);
			
			// Access Token, Refresh Token 생성
			final String access = loginTokenProvider.generateAccessToken(account, account.getId());
			final String refresh = loginTokenProvider.generateRefreshToken(account.getId());
			
			// Access Token, Refresh Token을 저장할 Cookie 생성
			//Cookie accessToken = loginTokenProvider.createCookie(CommonConstants.ACCESS_TOKEN_NAME, access, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);
			//Cookie refreshToken = loginTokenProvider.createCookie(CommonConstants.REFRESH_TOKEN_NAME, refresh, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND);
			ResponseCookie accessToken = loginTokenProvider.createSecureCookie(CommonConstants.ACCESS_TOKEN_NAME, access, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);
			ResponseCookie refreshToken = loginTokenProvider.createSecureCookie(CommonConstants.REFRESH_TOKEN_NAME, refresh, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND);
			
			
			// Refresh Token을 Redis에 저장(만료기간 지정)
			redisUtil.setDataExpire(CommonConstants.REDIS_KEY_FO_REFRESH+refresh, id, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND);

			// Token Cookie를 Response에 추가
//			response.addCookie(accessToken);
//			response.addCookie(refreshToken);
			response.addHeader(HttpHeaders.SET_COOKIE, accessToken.toString());
			response.addHeader(HttpHeaders.SET_COOKIE, refreshToken.toString());
			
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		}
	}
	
	@RequestMapping(value = "/logout")
	public void logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// Access Token Cookie 조회
		Cookie accessToken = loginTokenProvider.getCookie(request, CommonConstants.ACCESS_TOKEN_NAME);
		if ( accessToken != null ) {
			// Cookie가 있으면 Cookie 삭제
//			accessToken.setValue(null);
//			accessToken.setPath("/");
//			accessToken.setMaxAge(0);
//			response.addCookie(accessToken);
			ResponseCookie responseAccesstoken = loginTokenProvider.createSecureCookie(CommonConstants.ACCESS_TOKEN_NAME,null,0);
			response.addHeader(HttpHeaders.SET_COOKIE, responseAccesstoken.toString());
		}

		// Refresh Token Cookie 조회
		Cookie refreshToken = loginTokenProvider.getCookie(request, CommonConstants.REFRESH_TOKEN_NAME);
		if ( refreshToken != null ) {
			// Cookie가 있으면 Cookie 삭제
			String refreshKey = refreshToken.getValue();
//			refreshToken.setValue(null);
//			refreshToken.setPath("/");
//			refreshToken.setMaxAge(0);
//			response.addCookie(refreshToken);
			
			ResponseCookie responseRefreshToken = loginTokenProvider.createSecureCookie(CommonConstants.REFRESH_TOKEN_NAME,null,0);
			response.addHeader(HttpHeaders.SET_COOKIE, responseRefreshToken.toString());
			
			// Redis에서 Refresh Token 삭제
			redisUtil.deleteData(CommonConstants.REDIS_KEY_FO_REFRESH+refreshKey);
		}
	}
}
