package com.sorincorp.fo.login.service;

import java.security.Key;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.itemcode.service.ItemCodeService;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.fo.bd.mapper.BdAccountMapper;
import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.config.LoginTokenProvider;
import com.sorincorp.fo.login.mapper.AccountMapper;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.mb.service.MbCmnCodeService;
import com.sorincorp.fo.op.service.OpAlarmService;

import io.jsonwebtoken.Jwts;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Service
public class AccountServiceImpl implements UserDetailsService {
	@Autowired
	AccountMapper accountMapper;
	
    @Autowired
    BdAccountMapper bdAccountMapper;

	@Autowired
	SMSService smsService;

	@Autowired
	LoginTokenProvider loginTokenProvider;

	@Autowired
	MbCmnCodeService mbCmnCodeService;
	/**
	 * UserDetailsService에서 Override
	 * JWT Token에 저장되어 있는 정보를 UserDetails Type으로 반환한다.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public UserDetails loadUserByUsername(String token) throws UsernameNotFoundException {
		String secretKey = CommonConstants.JWT_SECRET_KEY;
		Key secret = loginTokenProvider.getSigningKey(secretKey);
		HashMap<String, String> accountObj = (HashMap<String, String>)Jwts.parserBuilder().setSigningKey(secret).build().parseClaimsJws(token).getBody().get("account");
		// JWT Token의 claims 값(HashMap)을 AccountVO로 변경
		Account account = new Account();
		account.setId(accountObj.get("id"));
		account.setMberNo(accountObj.get("mberNo"));
		account.setPassword(accountObj.get("password"));
		account.setName(accountObj.get("name"));
		account.setPhonenum(accountObj.get("phonenum"));
		account.setEmail(accountObj.get("email"));
		account.setSecode(accountObj.get("secode"));
		account.setEntrpsNo(accountObj.get("entrpsNo"));
		account.setMberSttusCode(accountObj.get("mberSttusCode"));
		account.setType(accountObj.get("type"));
		account.setAuthorNo(accountObj.get("authorNo"));
		account.setRefndAcnutSttusCode(accountObj.get("refndAcnutSttusCode"));
		account.setMberConfmProcessDt(accountObj.get("mberConfmProcessDt"));
		account.setCurrentDt(accountObj.get("currentDt"));
		account.setConfmToFirstLogin(accountObj.get("confmToFirstLogin"));
		account.setEntrpsnmKorean(accountObj.get("entrpsnmKorean"));
		account.setEntrpsGrad(accountObj.get("entrpsGrad"));
		account.setEntrpsMnbyPurchsBnef(accountObj.get("entrpsMnbyPurchsBnef"));
		account.setEntrpsPayBackDscnt(accountObj.get("entrpsPayBackDscnt"));
		account.setEntrpsMnbyPurchsBnefUseAt(accountObj.get("entrpsMnbyPurchsBnefUseAt"));
		account.setEntrpsPayBackDscntUseAt(accountObj.get("entrpsPayBackDscntUseAt"));
		
		return account;
	}
	
	@SuppressWarnings("unchecked")
    public UserDetails loadBdUserByUsername(String token) throws UsernameNotFoundException {
        String secretKey = CommonConstants.JWT_BD_SECRET_KEY;
        Key secret = loginTokenProvider.getSigningKey(secretKey);
        HashMap<String, String> bdAccountObj = (HashMap<String, String>)Jwts.parserBuilder().setSigningKey(secret).build().parseClaimsJws(token).getBody().get("bdAccount");
        // log.info("bdAccountObj =====> " + bdAccountObj);
        // JWT Token의 claims 값(HashMap)을 AccountVO로 변경
        BdAccount bdAccount = new BdAccount();
        bdAccount.setBidEntrpsNo(bdAccountObj.get("bidEntrpsNo"));
        bdAccount.setBidMberId(bdAccountObj.get("bidMberId"));
        bdAccount.setBidMberSecretNo(bdAccountObj.get("bidMberSecretNo"));
        bdAccount.setEntrpsNm(bdAccountObj.get("entrpsNm"));
        bdAccount.setBsnmRegistNo(bdAccountObj.get("bsnmRegistNo"));
        bdAccount.setBidMberEmail(bdAccountObj.get("bdMberEmail"));
        bdAccount.setMoblphonNo2(bdAccountObj.get("moblphonNo2"));
        bdAccount.setAditIem(bdAccountObj.get("aditIem"));
        bdAccount.setFrntnEntrpsAt(bdAccountObj.get("frntnEntrpsAt"));
        bdAccount.setVrscEntrpsNm(bdAccountObj.get("vrscEntrpsNm"));
        bdAccount.setVrscBsnmRegistNo(bdAccountObj.get("vrscBsnmRegistNo"));
        bdAccount.setVrscBidMberEmail(bdAccountObj.get("vrscBidMberEmail"));
        bdAccount.setVrscMoblphonNo(bdAccountObj.get("vrscMoblphonNo"));
        bdAccount.setAditIem2(bdAccountObj.get("aditIem2"));
        bdAccount.setBidEtrConfmSttusCode(bdAccountObj.get("bdEtrConfmSttusCode"));
        bdAccount.setUseStplatAgreAt(bdAccountObj.get("useStplatAgreAt"));
        bdAccount.setUseStplatAgreDt(bdAccountObj.get("useStplatAgreDt"));
        bdAccount.setMberEmailRecptnAgreAt(bdAccountObj.get("mberEmailRecptnAgreAt"));
        bdAccount.setMberEmailRecptnAgreDt(bdAccountObj.get("mberEmailRecptnAgreDt"));
        bdAccount.setMberChrctrRecptnAgreAt(bdAccountObj.get("mberChrctrRecptnAgreAt"));
        bdAccount.setMberChrctrRecptnAgreDt(bdAccountObj.get("mberChrctrRecptnAgreDt"));
        return bdAccount;
    }

	/**
	 * <pre>
	 * userId에 맞는 사용자 정보를 가져온다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public Account selectAccount(String userId) throws Exception {
		Account account = accountMapper.selectAccount(userId);
		String phonenum = "";

		if(account != null) {
			phonenum = account.getPhonenum();

			if(phonenum != null && !"".equals(phonenum)) {
				try {
					//휴대폰 파라미터 복호화 20220118 srec0030
					log.debug("휴대폰 복호화 전 ===============>" + phonenum);
					phonenum = CryptoUtil.decryptAES256(phonenum);
					log.debug("휴대폰 복호화 후 ===============>" + phonenum);
					account.setPhonenum(phonenum);
				} catch (Exception e) {
					// TODO: handle exception
					log.error("selectAccount MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
			}
		}
		return account;
	}

	/**
	 * <pre>
	 * 간편회원 신규등록을 진행한다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 * @throws Exception
	 */
	public String insertAccount(Account account) throws Exception {
		String phonenum = account.getPhonenum();

		if(phonenum != null && !"".equals(phonenum)) {
			//암호화하기전에 평문 번호에서 하이푼 제거
			phonenum = phonenum.replaceAll("[^0-9]", "");

			//휴대폰 파라미터 암호화 20220118 srec0030
			try {
				log.debug("휴대폰 암호화 전 ===============>" + phonenum);
				phonenum = CryptoUtil.encryptAES256(phonenum);
				log.debug("휴대폰 암호화 후 ===============>" + phonenum);
				account.setPhonenum(phonenum);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.error("insertAccount MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		accountMapper.insertSimpleAccount(account);

		return account.getId();
	}

	public Account selectAccountByPhone(String phoneNum) throws Exception {

		if(phoneNum != null && !"".equals(phoneNum)) {
			if(phoneNum != null && !"".equals(phoneNum)) {
				phoneNum = phoneNum.replaceAll("[^0-9]", "");
				try {
					//휴대폰 파라미터 암호화 20220118 srec0030
					log.debug("휴대폰 암호화 전 ===============>" + phoneNum);
					phoneNum = CryptoUtil.encryptAES256(phoneNum);
					log.debug("휴대폰 암호화 후 ===============>" + phoneNum);
				} catch (Exception e) {
					// TODO: handle exception
					log.error("selectAccountByPhone MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
				}
			}
		}

		Account account = accountMapper.selectAccountByPhone(phoneNum);

		String phoneNo = "";

		if(account != null) {
			phoneNo = account.getPhonenum();

			if(phoneNo != null && !"".equals(phoneNo)) {
				if(phoneNo != null && !"".equals(phoneNo)) {
					try {
						//휴대폰 파라미터 복호화 20220118 srec0030
						log.debug("휴대폰 복호화 전 ===============>" + phoneNo);
						phoneNo = CryptoUtil.decryptAES256(phoneNo);
						log.debug("휴대폰 복호화 후 ===============>" + phoneNo);
						account.setPhonenum(phoneNo);
					} catch (Exception e) {
						// TODO: handle exception
						log.error("selectAccountByPhone MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
					}
				}
			}
		}
		return account;
	}

	public String phoneAuth(Account account) throws Exception {
		SMSVO smsVO = new SMSVO();

		Map<String, String> map = new HashMap<>();

		// 메시지 템플릿 번호
		String templateNum = "4";
		String title = mbCmnCodeService.selectMssageSj(templateNum);

		SecureRandom sr = new SecureRandom();
		StringBuilder authNum = new StringBuilder();
		for(int i=0; i<6; i++) {
			authNum.append(sr.nextInt(10));
		}

		map.put("templateNum", templateNum);
		map.put("certiNumber", authNum.toString());

		smsVO.setPhone(account.getPhonenum().replaceAll("[^0-9]", ""));
		smsVO.setMberNo(account.getMberNo());
		smsVO.setMberKndSeCode(account.getSecode());
		smsVO.setMsgTitle(title);

		smsService.insertSMS(smsVO, map); //나중에 주석 풀어야 문자 발송 가능
		return authNum.toString();
	}

	public void updateMberSttusCode(Account account) {
		accountMapper.updateMberSttusCode(account);
		accountMapper.deleteMberDrmncy(account);
		accountMapper.updateLoginLogSttusCd(account);
	}

	public void updateRecentLoginDate(Account account) {
		accountMapper.updateRecentLoginDate(account);
	}

	public void updatePw(Account account) throws Exception {
		accountMapper.updatePw(account);

	}

	public int selectPwNotice(Account account) throws Exception {
		return accountMapper.selectPwNotice(account);
	}

	public int selectSearchPw(Account account) throws Exception {
		String phonenum = account.getPhonenum();

		if(phonenum != null && !"".equals(phonenum)) {
			//암호화하기전에 평문 번호에서 하이푼 제거
			phonenum = phonenum.replaceAll("[^0-9]", "");

			//휴대폰 파라미터 암호화 20220118 srec0030
			try {
				log.debug("휴대폰 암호화 전 ===============>" + phonenum);
				phonenum = CryptoUtil.encryptAES256(phonenum);
				log.debug("휴대폰 암호화 후 ===============>" + phonenum);
				account.setPhonenum(phonenum);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.error("selectSearchPw MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		return accountMapper.selectSearchPw(account);
	}

	public String selectSignUpDate(Account account) {
		return accountMapper.selectSignUpdate(account);
	}

	public void updateNextPwChgDate(Account account) throws Exception {
		accountMapper.updateNextPwChgDate(account);
	}

	public int selectNextPwChgDate(Account account) throws Exception{
		return accountMapper.selectNextPwChgDate(account);
	}

	public int selectChangePw(Account account) {
		return accountMapper.selectChangePw(account);
	}

	public void updateSimplPw(Account account) throws Exception{
		accountMapper.updateSimplPw(account);

	}

	public void updateSimplNextPwChgDate(Account account) {
		accountMapper.updateSimplNextPwChgDate(account);

	}

	public void updateLoginFailCount(Account account) {
		accountMapper.updateLoginFailCount(account);

	}

	public void updateMberSttusCd(Account account) {
		accountMapper.updateMberSttusCd(account);

	}

	public void updateMberSttusCdHist(Account account) {
		accountMapper.updateMberSttusCdHist(account);

	}

	public void resetLoginFailCount(Account account) {
		accountMapper.resetLoginFailCount(account);

	}

	public Account selectSimpleAccountByPhone(String phoneNum) {

		if(phoneNum != null && !"".equals(phoneNum)) {
			phoneNum = phoneNum.replaceAll("[^0-9]", "");

			//휴대폰 파라미터 암호화 20220118 srec0030
			try {
				log.debug("휴대폰 암호화 전 ===============>" + phoneNum);
				phoneNum = CryptoUtil.encryptAES256(phoneNum);
				log.debug("휴대폰 암호화 후 ===============>" + phoneNum);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.error("selectSimpleAccountByPhone MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}

		Account account = accountMapper.selectSimpleAccountByPhone(phoneNum);
		String phoneNo = "";

		if(account != null) {
			phoneNo = account.getPhonenum();

			if(phoneNo != null && !"".equals(phoneNo)) {
				//휴대폰 파라미터 복호화 20220118 srec0030
				try {
					log.debug("휴대폰 복호화 전 ===============>" + phoneNum);
					phoneNo = CryptoUtil.decryptAES256(phoneNo);
					log.debug("휴대폰 복호화 후 ===============>" + phoneNo);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					log.error("selectSimpleAccountByPhone MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
				account.setPhonenum(phoneNo);
			}
		}

		return account;
	}

	public void insertMbInfoBasHst(Account account) {
		accountMapper.insertMbInfoBasHst(account);
	}

	public void insertSimplMbInfoBasHst(Account account) {
		accountMapper.insertSimplMbInfoBasHst(account);
	}
	
	
	
	/********************* 구매입찰 ***********************/
	/**
     * userId에 맞는 사용자 정보를 가져온다.
     */
    public BdAccount selectBdAccount(String userId) throws Exception {
        BdAccount account = bdAccountMapper.selectBdAccount(userId);
        return account;
    }

}
