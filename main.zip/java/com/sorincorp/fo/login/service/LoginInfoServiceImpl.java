package com.sorincorp.fo.login.service;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.login.model.Account;

@Service
public class LoginInfoServiceImpl implements LoginInfoService {
	
	@Override
	public Account getAccount() throws Exception {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Account account = new Account();
		if ( !"anonymousUser".equals(auth.getPrincipal()) ) account = (Account)auth.getPrincipal();

		return account;
	}
	
	@Override
	public String getUserId() throws Exception {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Account account = new Account();
		if ( !"anonymousUser".equals(auth.getPrincipal()) ) account = (Account)auth.getPrincipal();

		return account.getId();
	}

	@Override
	public String getUserName() throws Exception {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Account account = new Account();
		if ( !"anonymousUser".equals(auth.getPrincipal()) ) account = (Account)auth.getPrincipal();

		return account.getName();
	}

	@Override
	public String getPhoneNum() throws Exception {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Account account = new Account();
		if ( !"anonymousUser".equals(auth.getPrincipal()) ) account = (Account)auth.getPrincipal();

		return account.getPhonenum();
	}

	@Override
	public String getEmail() throws Exception {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Account account = new Account();
		if ( !"anonymousUser".equals(auth.getPrincipal()) ) account = (Account)auth.getPrincipal();

		return account.getEmail();
	}

	@Override
	public String getEntrpsNo() throws Exception {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		Account account = new Account();
		if ( !"anonymousUser".equals(auth.getPrincipal()) ) account = (Account)auth.getPrincipal();

		return account.getEntrpsNo();
	}
}
