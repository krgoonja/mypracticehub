package com.sorincorp.fo.login.service;

import com.sorincorp.fo.login.model.AccountEntrpsInfoVO;

/**
 * 로그인회원의 업체정보를 조회하는 Service 
 * LoginInfoService.java
 * @version
 * @since 2022. 7. 08.
 * @author srec0012
 */
public interface EntrpsInfoService {
	/**
	 * <pre>
	 * 회원 업체정보를 조회한다. 
	 * </pre>
	 * @date 2022. 7. 08.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 08.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return : accountEntrpsInfoVO
	 * @throws Exception
	 */
	public AccountEntrpsInfoVO selectAccountEntrpsInfo(String entrpsNo) throws Exception;
	
}
