package com.sorincorp.fo.login.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.login.mapper.AccountMapper;
import com.sorincorp.fo.login.model.AccountEntrpsInfoVO;

@Service
public class EntrpsInfoServiceImpl implements EntrpsInfoService {
	@Autowired
	AccountMapper accountMapper;
	
	@Override
	public AccountEntrpsInfoVO selectAccountEntrpsInfo(String entrpsNo) throws Exception {
		return accountMapper.selectAccountEntrpsInfo(entrpsNo);
	}
	
}
