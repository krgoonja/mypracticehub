package com.sorincorp.fo.login.service;

import com.sorincorp.fo.login.model.Account;

/**
 * 로그인 Token 값에 맞는 Authentication 정보를 조회하는 Service 
 * LoginInfoService.java
 * @version
 * @since 2021. 6. 24.
 * @author srec0012
 */
public interface LoginInfoService {
	/**
	 * <pre>
	 * Login Token으로 인증된 Authentication 정보 전체를 AccountVO에 담아서 반환한다.
	 * </pre>
	 * @date 2021. 6. 24.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 24.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return : Authentication 정보
	 * @throws Exception
	 */
	public Account getAccount() throws Exception;
	
	/**
	 * <pre>
	 * Login Token으로 인증된 Authentication 정보 중에서 회원 ID를 반환한다.
	 * </pre>
	 * @date 2021. 7. 13.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 13.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public String getUserId() throws Exception;
	
	/**
	 * <pre>
	 * Login Token으로 인증된 Authentication 정보 중에서 회원 이름을 반환한다.
	 * </pre>
	 * @date 2021. 6. 24.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 24.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public String getUserName() throws Exception;
	
	/**
	 * <pre>
	 * Login Token으로 인증된 Authentication 정보 중에서 회원 전화번로를 반환한다.
	 * </pre>
	 * @date 2021. 6. 24.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 24.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public String getPhoneNum() throws Exception;
	
	/**
	 * <pre>
	 * Login Token으로 인증된 Authentication 정보 중에서 회원 E-mail을 반환한다.
	 * </pre>
	 * @date 2021. 6. 24.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 24.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public String getEmail() throws Exception;
	
	/**
	 * <pre>
	 * Login Token으로 인증된 Authentication 정보 중에서 회원사 번호를 반환한다.
	 * </pre>
	 * @date 2021. 6. 24.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 24.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public String getEntrpsNo() throws Exception;
}
