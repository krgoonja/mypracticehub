package com.sorincorp.fo.credt.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.constants.ExceptionConstants;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.credt.comm.ValueReturnException;
import com.sorincorp.fo.credt.model.CredtRepyVO;
import com.sorincorp.fo.credt.service.CredtEwalletService;
import com.sorincorp.fo.credt.service.CredtLonService;
import com.sorincorp.fo.login.model.Account;

import lombok.extern.slf4j.Slf4j;

/**
 * 신용보증 담보, 대출, 증거금 관련
 * @author srec0051
 *
 */
@Slf4j
@Controller
@RequestMapping("/credt")
public class CredtController {

	/** 외부 연계 api 호출 모듈 **/
	@Autowired
	HttpClientHelper httpClientHelper;
	@Autowired
	MessageUtil messageUtil;
	@Autowired
	private UserInfoUtil userInfoUtil;
	@Autowired
	private CredtEwalletService credtEwalletService;
	@Autowired
	private CredtLonService credtLonService;


	final String RESPONSE_CODE = "rspnsCode";
	final String RESPONSE_MESSAGE = "rspnsMssage";
	final String RETURN_DE = "returnDe";


	/**
	 * <pre>
	 * 로그인 계정 정보
	 * </pre>
	 * @date 2022. 7. 22.
	 * @author srec0051
	 * @return
	 * @throws Exception
	 */
	private Account getAccountInfo() throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		if (null == account || StringUtil.isBlank(account.getId())) {
			throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_LOGIN_REQUIRED));
		}
		return account;
	}

	/**
	 * <pre>
	 * 미납 주문의 상환 가능 여부 기준 반환 (Y/N)
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0051
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/repy/possAt/{orderNo}")
	@ResponseBody
	public ResponseEntity<?> repyPossAt(@PathVariable String orderNo) throws Exception {

		Map<String,Object> resObj = new HashMap<>();
		String ret;

		try {
			ret = credtEwalletService.getRepyPossibleAt(orderNo) ? "Y" : "N";

		} catch (Exception e) {
			log.error(e.getMessage());
			resObj.put(RESPONSE_CODE, HttpStatus.BAD_REQUEST.value());
			resObj.put(RESPONSE_MESSAGE, "N");
			return ResponseEntity.status(HttpStatus.OK).body(resObj);
		}

		resObj.put(RESPONSE_CODE, HttpStatus.OK.value());
		resObj.put(RESPONSE_MESSAGE, ret);

		return ResponseEntity.status(HttpStatus.OK).body(resObj);
	}

	/**
	 * <pre>
	 * 이월렛 상환 요청 (이월렛, 담보)
	 * </pre>
	 * @date 2022. 7. 22.
	 * @author srec0051
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/repy/ewallet")
	@ResponseBody
	public ResponseEntity<?> repyewallet(@RequestBody CredtRepyVO param) throws Exception {

		log.debug(param.toString());
		Map<String,Object> resObj = new HashMap<>();

		try {
			Account account = getAccountInfo();
			param.setMberId(account.getId());
			param.setMberNo(account.getMberNo());
			param.setEntrpsNo(account.getEntrpsNo());
			param.setMberSeCode(userInfoUtil.getMemberSecode());	// 권한 구분 코드

			//서비스 호출
			credtEwalletService.repyEwallet(param);

			resObj.put(RESPONSE_CODE, HttpStatus.OK.value());
			resObj.put(RESPONSE_MESSAGE, "정상적으로 입금처리 되었습니다.");

		} catch (Exception e) {
			log.error(e.getMessage());
			resObj.put(RESPONSE_CODE, HttpStatus.BAD_REQUEST.value());
			resObj.put(RESPONSE_MESSAGE, messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT)+ " ("+ e.getMessage()+ ")");
//			resObj.put(RESPONSE_MESSAGE, e.getMessage());
			return ResponseEntity.status(HttpStatus.OK).body(resObj);
		}

		return ResponseEntity.status(HttpStatus.OK).body(resObj);
	}

	/**
	 * <pre>
	 * 처리내용: 변동금 입금요청 (이월렛)
	 * </pre>
	 * @date 2024. 11. 7.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 11. 7.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	@PostMapping("/repy/changegld")
	@ResponseBody
	public ResponseEntity<?> repyChangegld(@RequestBody CredtRepyVO param) throws Exception {
		log.debug(param.toString());
		Map<String,Object> resObj = new HashMap<>();

		try {
			Account account = getAccountInfo();
			param.setMberId(account.getId());
			param.setMberNo(account.getMberNo());
			param.setEntrpsNo(account.getEntrpsNo());
			param.setMberSeCode(userInfoUtil.getMemberSecode());	// 권한 구분 코드

			//서비스 호출
			credtEwalletService.repyChangegld(param);

			resObj.put(RESPONSE_CODE, HttpStatus.OK.value());
			resObj.put(RESPONSE_MESSAGE, "정상적으로 입금처리 되었습니다.");

		} catch (Exception e) {
			log.error(e.getMessage());
			resObj.put(RESPONSE_CODE, HttpStatus.BAD_REQUEST.value());
			resObj.put(RESPONSE_MESSAGE, messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT)+ " ("+ e.getMessage()+ ")");
//			resObj.put(RESPONSE_MESSAGE, e.getMessage());
			return ResponseEntity.status(HttpStatus.OK).body(resObj);
		}

		return ResponseEntity.status(HttpStatus.OK).body(resObj);
	}

	/**
	 * <pre>
	 * 대출보증 상환 (매매계약)
	 * </pre>
	 * @date 2022. 7. 27.
	 * @author srec0051
	 * @param param { orderNo, exprtnDe, bankCode }
	 * @param sttusCode {10:요청, 30:취소}
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/repy/lon/{sttusCode}")
	@ResponseBody
	public ResponseEntity<?> repylon(@RequestBody CredtRepyVO param, @PathVariable String sttusCode) throws Exception {

		log.debug("repylon param : "+ param.toString());
		Map<String,Object> resObj = new HashMap<>();

		try {
			param.setMberNo(getAccountInfo().getMberNo());
			param.setEntrpsNo(userInfoUtil.getEntripsNo());
			param.setSttusCode(sttusCode);

			// 매매계약 요청
			if ("10".equals( sttusCode)) {
				if (StringUtil.isBlank(param.getOrderNo()) || StringUtil.isBlank(param.getExprtnDe()) || StringUtil.isBlank(param.getBankCode())) {
					throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
				}

				credtLonService.repyLon(param);
				resObj.put(RESPONSE_MESSAGE, "정상적으로 요청 되었습니다.");
			}
			// 매매계약 취소 요청
			else if ("30".equals( sttusCode)) {
				credtLonService.repyLonCancel(param);
				resObj.put(RESPONSE_MESSAGE, "정상적으로 취소 요청 되었습니다.");
			}
			// 오류
			else {
				throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
			}

			resObj.put(RESPONSE_CODE, HttpStatus.OK.value());

		} catch (Exception e) {
			log.error(e.getMessage());
			resObj.put(RESPONSE_CODE, HttpStatus.BAD_REQUEST.value());
			resObj.put(RESPONSE_MESSAGE, e.getMessage());
			return ResponseEntity.status(HttpStatus.OK).body(resObj);
		}

		return ResponseEntity.status(HttpStatus.OK).body(resObj);
	}

	/**
	 * <pre>
	 * 대출 한도 조회
	 * </pre>
	 * @date 2022. 7. 22.
	 * @author srec0051
	 * @param param {orderNo, bankCode}
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/lon/lmt")
	@ResponseBody
	public ResponseEntity<?> getLonLmt(@RequestBody CredtRepyVO param) throws Exception {

		log.debug(param.toString());
		Map<String, Object> resObj = new HashMap<>();

		try {
			getAccountInfo();
			resObj = credtLonService.getLonLmt(param);

			log.debug("respopnse "+ resObj.toString());

			resObj.put(RESPONSE_CODE, resObj.get(RESPONSE_CODE));	// 코드에 잔액이 Integer 형태로 올 예정
			resObj.put(RESPONSE_MESSAGE, "");

		} catch (Exception e) {
			log.error(e.getMessage());
			resObj.put(RESPONSE_CODE, HttpStatus.BAD_REQUEST.value());
			resObj.put(RESPONSE_MESSAGE, e.getMessage());
			return ResponseEntity.status(HttpStatus.OK).body(resObj);
		}

		return ResponseEntity.status(HttpStatus.OK).body(resObj);
	}


	/**
	 * <pre>
	 * 구매자금 만기일자 체크
	 * </pre>
	 * @date 2022. 9. 1.
	 * @author srec0051
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/lon/exprtnDe")
	@ResponseBody
	public ResponseEntity<?> exprtnDe(@RequestBody CredtRepyVO param) throws Exception {

		log.debug(param.toString());
		Map<String, Object> resObj = new HashMap<>();

		try {
			if (StringUtil.isBlank(param.getExprtnDe())) {
				throw new Exception("만기일자를 확인해주세요.");
			}

			String returnDe = credtLonService.checkExprtnDe(param);

			resObj.put(RESPONSE_CODE, "200");
			resObj.put(RESPONSE_MESSAGE, "");
			resObj.put(RETURN_DE, returnDe);

		} catch (ValueReturnException e) {
			log.error(e.getMessage());
			resObj.put(RESPONSE_CODE, HttpStatus.BAD_REQUEST.value());
			resObj.put(RESPONSE_MESSAGE, e.getMessage());
			resObj.put(RETURN_DE, e.getValue());
			return ResponseEntity.status(HttpStatus.OK).body(resObj);
		}

		return ResponseEntity.status(HttpStatus.OK).body(resObj);
	}
	
	
	
	/**
	 * <pre>
	 * 처리내용: 중도 상환 대상인 주문의 다중 상환 처리
	 * </pre>
	 * @date 2024. 7. 10.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 7. 10.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/repy/mrtggMdstrmRepy", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	@ResponseBody
	public SseEmitter mrtggMdstrmRepy(@ModelAttribute CredtRepyVO param) throws Exception {
		log.debug(param.toString());

		try {
			Account account = getAccountInfo();
			param.setMberId(account.getId());
			param.setMberNo(account.getMberNo());
			param.setEntrpsNo(account.getEntrpsNo());
			param.setMberSeCode(userInfoUtil.getMemberSecode());	// 권한 구분 코드

			return credtEwalletService.mrtggMdstrmRepy(param);
		} catch (Exception e) {
			log.error(e.getMessage());
			
			throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
		} finally {
			log.debug("CredtController::mrtggMdstrmRepy method returned SseEmitter");
		}
	}
}
