package com.sorincorp.fo.credt.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 대출 보증 대상 은행의 수수료 및 OTP 가능 공통 정보
 * @author srec0051
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LonBankInfoVO {

	/** 주문번호 */
	private String orderNo;

	/** 은행코드 */
	private String bankCode;

	/** 요청 MP 수수료 */
	private long reqMpFee;

	/** 요청 은행 수수료 */
	private long reqBankFee;

	/** OTP 가능 시작 시간 */
	private int otpStartTime;

	/** OTP 가능 종료 시간 */
	private int otpEndTime;

	/** OTP 가능여부 (Y, N) */
	private String otpYn;
}
