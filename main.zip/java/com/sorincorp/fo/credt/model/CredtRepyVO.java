package com.sorincorp.fo.credt.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CredtRepyVO {

	/** 주문번호 */
	private String orderNo;
	/** 결제번호 */
	private String setleNo;
	/** 담보번호 */
	private String mrtggNo;
	/** 담보순번 */
	private String mrtggDetailSn;
	/** 대출번호 */
	private String lonNo;

	/** 대출결제수단코드 {2:카드, 3:론, 4:자금} */
	private String sanctnMnCode;
	/** 상태코드 */
	private String sttusCode;
	/** 만기일 */
	private String exprtnDe;
	/** 은행코드 */
	private String bankCode;

	/** 총한도 */
	private Long bankLimitAmt;
	/** 남은한도 */
	private Long bankLimitSpare;

	/** 회원아이디 */
	private String mberId;
	/** 회원번호 */
	private String mberNo;
	/** 업체번호 */
	private String entrpsNo;
	/** 회원권한구분코드 */
	private String mberSeCode;

	/** 주문 상태 코드 */
	private String orderSttusCode;
	/** OMS 접수 번호 */
	private String omsRceptNo;
	/** 결제 방식 코드 */
	private String setleMthdCode;
	/** 결제 방식 상세 코드 */
	private String setleMthdDetailCode;
	/** 미 결제 금액 */
	private long unSetleAmount;
	/** 주문 홀딩 사용 여부 */
	private String orderHoldingUseAt;
	/** 결제 예정 일자 */
	private String wrtmSetlePrearngeDe;

	/** 지정가 주문 취소 여부 */
	private String orderCancelAt;
	
	/**
	 * 담보 상태 코드
	 */
	private String mrtggSttusCode;
	
	/**
     * (화면에서 선택한)중도 상환 순번 목록
     */
    private List<Integer> mdstrmRepySnList;
    /**
     * 추가 금액 상환 여부
     * 화면에서 상환 대상으로 선택 시 "Y"값으로 넘어옴
     */
    private String aditAmountRepyAt;
    /**
     * 중도 상환 순번
     */
    private Integer mdstrmRepySn;

    /** 변동금 발생 순번 */
    private int occrrncSn;
    /** 변동금 여부 */
	private String changegldYn;
	
	/**
	 * 판매 방식 코드
	 */
	private String sleMthdCode;
}
