package com.sorincorp.fo.credt.model;

import lombok.Data;

@Data
public class OrLonBasVO {

	/******  JAVA VO CREATE : OR_LON_BAS(주문_대출 기본)   ******/
    /**
     * 대출 번호
    */
    private String lonNo;
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 대출 상태 코드
    */
    private String lonSttusCode;
    /**
     * 은행 코드
    */
    private String bankCode;
    /**
     * 주문 시점 한도 금액
    */
    private long orderPnttmLmtAmount;
    /**
     * 대출 보증 신청 일자
    */
    private String lonGrntyReqstDe;
    /**
     * 결제 예정 금액
    */
    private long setlePrearngeAmount;
    /**
     * 결제 예정 일자
    */
    private String setlePrearngeDe;
    /**
     * 만기 일자
    */
    private String exprtnDe;
    /**
     * 요청 MP 수수료
    */
    private long requstMpFee;
    /**
     * 요청 은행 수수료
    */
    private long requstBankFee;
    /**
     * 세금계산서 승인 번호
    */
    private String taxbilConfmNo;
    /**
     * 세금계산서 발행 일자
    */
    private String taxbilIsuDe;
    /**
     * 세금계산서 발행 금액
    */
    private long taxbilIsuAmount;
    /**
     * 세금계산서 공급가
    */
    private long taxbilSplpc;
    /**
     * 세금계산서 일련 번호
    */
    private String taxbilSeqNo;
    /**
     * 공급가
    */
    private long splpc;
    /**
     * 부가세
    */
    private long vat;
    /**
     * 판매가
    */
    private long slepc;
    /**
     * 통보 구분 코드
    */
    private String dspthSeCode;
    /**
     * 결재 수단 코드
    */
    private String sanctnMnCode;
    /**
     * 결제 일자
    */
    private String setleDe;
    /**
     * 결제 금액
    */
    private long setleAmount;
    /**
     * MP 수수료
    */
    private long mpFee;
    /**
     * 은행 수수료
    */
    private long bankFee;
    /**
     * MP 수수료 조정 금액
    */
    private long mpFeeMdatAmount;
    /**
     * MP 수수료 조정 사유
    */
    private String mpFeeMdatResn;
    /**
     * 대출 보증 수수료 부담 주체 여부
    */
    private String lonGrntyFeeBndMbyAt;
    /**
     * 비용 정산 요청 번호
    */
    private String ctExcclcRequstNo;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;

}
