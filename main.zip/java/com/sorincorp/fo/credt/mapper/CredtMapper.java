package com.sorincorp.fo.credt.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.fo.credt.model.CredtRepyVO;
import com.sorincorp.fo.credt.model.LonBankInfoVO;
import com.sorincorp.fo.credt.model.OrLonBasVO;

public interface CredtMapper {

	/**
	 * <pre>
	 * 주문 기본 조회
	 * </pre>
	 * @date 2022. 8. 1.
	 * @author srec0051
	 * @param param
	 * @return
	 */
	CredtRepyVO selectOrder(CredtRepyVO param);

	/**
	 * <pre>
	 * 주문 정보 조회 (대출기본)
	 * </pre>
	 * @date 2022. 7. 26.
	 * @author srec0051
	 * @param param
	 * @return
	 */
	OrLonBasVO selectLonOrder(CredtRepyVO param);

	/**
	 * <pre>
	 * 세금계산서 확인 조회
	 * </pre>
	 * @date 2022. 7. 26.
	 * @author srec0051
	 * @param orderNo
	 * @return
	 */
	int getCntTaxbill(String orderNo);

	/**
	 * <pre>
	 * 요청 MP/은행 수수료 조회
	 * </pre>
	 * @date 2022. 7. 26.
	 * @author srec0051
	 * @param paramVo
	 * @return
	 */
	LonBankInfoVO getLonRequstBankInfo(LonBankInfoVO paramVo);

	/**
	 * <pre>
	 * 대출 기본 등록
	 * </pre>
	 * @date 2022. 7. 27.
	 * @author srec0051
	 * @param lonBasVo
	 * @return
	 */
	int insertOrLonBas(OrLonBasVO lonBasVo);
	int insertOrLonBasHst(OrLonBasVO lonBasVo);

	/**
	 * <pre>
	 * 주문의 대출번호 조회
	 * </pre>
	 * @date 2022. 7. 27.
	 * @author srec0051
	 * @param param
	 * @return
	 */
	String getOrderLonNo(CredtRepyVO param);

	/**
	 * <pre>
	 * 대출기본 취소요청
	 * </pre>
	 * @date 2022. 8. 29.
	 * @author srec0051
	 * @param lonVo
	 * @return
	 */
	int updatelonSttusCode(OrLonBasVO lonVo);

	/**
	 * <pre>
	 * 대출보증 만기일자 여부 체크, 만기일자 리턴
	 * </pre>
	 * @date 2022. 9. 1.
	 * @author srec0051
	 * @param param
	 * @return
	 */
	Map<String, String> exprtnDeOverAndHoliDayCheck(CredtRepyVO param);

	/**
	 * <pre>
	 * 처리내용: 결제예정일자 조회
	 * </pre>
	 * @date 2022. 9. 19.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 19.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	String getSetlePrearngeDe(String orderNo);

	/**
	 * <pre>
	 * 미납 주문의 상환 가능 여부 기준 반환 (Y/N)
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0051
	 * @param orderNo
	 * @return
	 */
	boolean getRepyPossibleAt(String orderNo);

	void updateOrMrtggBas(CredtRepyVO param);
	
	List<CredtRepyVO> selectMdstrmRepyInfo(CredtRepyVO param);
}
