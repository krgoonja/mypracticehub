package com.sorincorp.fo.credt.constant;


public class MrtggConstant {

	/** 등록자, 수정자
	public static final String REGISTER_ID = "SORIN";
	*/

	/** 결제 방식 코드 */
	public enum SetleMthdCode {
		/** 이월렛 */
		EWALLET("10")
		/** 전자상거래보증 */
		,MRTGG("20")
		/** 구매자금 */
		,LON("30")
		/** 여신 */
		,CDTLN("40")
		/** 증거금 */
		,WRTM("90")
		;

		private String code;
		private SetleMthdCode(String code){
			this.code = code;
		}
		public String getCode() {
			return code;
		}
		public static SetleMthdCode codeOf(String code) {
			if (null == code) {
				throw new IllegalArgumentException("SetleMthdCode Name must not be null.");
			}
			SetleMthdCode type = null;
			for (SetleMthdCode currentType : SetleMthdCode.values()) {
				if (currentType.getCode().equals(code)) {
					type = currentType;
					break;
				}
			}
			if (null == type) {
				throw new IllegalArgumentException("This SetleMthdCode[ code : " + code + " ] is not supported.");
	        } else {
	            return type;
	        }
		}
	}

	/** 결제 방식 상세 코드 */
	public enum SetleMthdDetailCode {
		/** 케이지크레딧 */
		SORIN_CREDT_MARSH("4010")
		/** 이월렛+이월렛 */
		,EWALLET_EWALLET("9010")
		/** 이월렛+구매자금 */
		,EWALLET_LON("9030")
		;

		private String code;
		private SetleMthdDetailCode(String code){
			this.code = code;
		}
		public String getCode() {
			return code;
		}
		public static SetleMthdDetailCode codeOf(String code) {
			if (null == code) {
				throw new IllegalArgumentException("SetleMthdDetailCode Name must not be null.");
			}
			SetleMthdDetailCode type = null;
			for (SetleMthdDetailCode currentType : SetleMthdDetailCode.values()) {
				if (currentType.getCode().equals(code)) {
					type = currentType;
					break;
				}
			}
			if (null == type) {
				throw new IllegalArgumentException("This SetleMthdDetailCode[ code : " + code + " ] is not supported.");
	        } else {
	            return type;
	        }
		}
	}

	/** 담보상태코드 */
	public enum MrtggSttusCode {
		/** 매매계약 요청 */
		REQUEST("10")
		/** 매매계약 성공 */
		,SUCCESS("20")
		/** 부분상환 */
		,PARTREPY("30")
		/** 상환완료 */
		,REPYCOMPT("50")
		/** 매매계약 실패 */
		,FAILR("90")
		;

		private String code;
		private MrtggSttusCode(String code){
			this.code = code;
		}
		public String getCode() {
			return code;
		}
		public static MrtggSttusCode codeOf(String code) {
			if (null == code) {
				throw new IllegalArgumentException("MrtggSttusCode Name must not be null.");
			}
			MrtggSttusCode type = null;
			for (MrtggSttusCode currentType : MrtggSttusCode.values()) {
				if (currentType.getCode().equals(code)) {
					type = currentType;
					break;
				}
			}
			if (null == type) {
				throw new IllegalArgumentException("This MrtggSttusCode[ code : " + code + " ] is not supported.");
	        } else {
	            return type;
	        }
		}
	}


	/** 담보상환상태코드 */
	public enum MrtggRepySttusCode {
		/** 요청 */
		REQUEST("10")
		/** 성공 */
		,SUCCESS("20")
		/** 실패 */
		,FAILR("90")
		/** SKIP */
		,SKIP("99")
		;

		private String code;
		private MrtggRepySttusCode(String code){
			this.code = code;
		}
		public String getCode() {
			return code;
		}
		public static MrtggRepySttusCode codeOf(String code) {
			if (null == code) {
				throw new IllegalArgumentException("MrtggRepySttusCode Name must not be null.");
			}
			MrtggRepySttusCode type = null;
			for (MrtggRepySttusCode currentType : MrtggRepySttusCode.values()) {
				if (currentType.getCode().equals(code)) {
					type = currentType;
					break;
				}
			}
			if (null == type) {
				throw new IllegalArgumentException("This MrtggRepySttusCode[ code : " + code + " ] is not supported.");
	        } else {
	            return type;
	        }
		}
	}

	/** 상환구분코드 */
	public enum RepySeCode {
		/** 중량정산 */
		WT_EXCCLC("01")
		/** 상환입금 */
		,RCPMNY("02")
		/** 단가정산		23-11-23 추가*/
		,UNTPC_EXCCLC("03")
		/** 중량/단가정산	24-01-17 추가*/
		,WT_AND_UNTPC_EXCCLC("04")
		/** 미납상환(이월렛잔고) */
		,NYP_REPY("10")
		;

		private String code;
		private RepySeCode(String code){
			this.code = code;
		}
		public String getCode() {
			return code;
		}
		public static RepySeCode codeOf(String code) {
			if (null == code) {
				throw new IllegalArgumentException("RepySeCode Name must not be null.");
			}
			RepySeCode type = null;
			for (RepySeCode currentType : RepySeCode.values()) {
				if (currentType.getCode().equals(code)) {
					type = currentType;
					break;
				}
			}
			if (null == type) {
				throw new IllegalArgumentException("This RepySeCode[ code : " + code + " ] is not supported.");
            } else {
                return type;
            }
		}
	}
}
