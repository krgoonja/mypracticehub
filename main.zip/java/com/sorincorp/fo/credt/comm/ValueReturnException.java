package com.sorincorp.fo.credt.comm;

@SuppressWarnings("serial")
public class ValueReturnException extends Exception {
	
	final Object value;
	
	public Object getValue() {
        return value;
    }
	
	public ValueReturnException(String message, Object value) {
        super(message);
        this.value = value;
    }
}
