package com.sorincorp.fo.credt.service;

import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.sorincorp.fo.credt.model.CredtRepyVO;

public interface CredtEwalletService {

	/**
	 * <pre>
	 * 이월렛 상환 처리
	 * </pre>
	 * @date 2022. 7. 25.
	 * @author srec0051
	 * @param param
	 * @throws Exception
	 */
	void repyEwallet(CredtRepyVO param) throws Exception;

	/**
	 * <pre>
	 * 미납 주문의 상환 가능 여부 기준 반환 (Y/N)
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0051
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	boolean getRepyPossibleAt(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 중도 상환 대상인 주문의 다중 상환 처리
	 * </pre>
	 * @date 2024. 7. 10.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 7. 10.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	SseEmitter mrtggMdstrmRepy(CredtRepyVO param) throws Exception;

	/**
	 * <pre>
	 * 변동금 입금 처리
	 * </pre>
	 * @date 2024. 11. 7.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 11. 7.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	void repyChangegld(CredtRepyVO param) throws Exception;
}
