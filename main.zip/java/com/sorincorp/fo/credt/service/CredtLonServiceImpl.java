package com.sorincorp.fo.credt.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.constants.ExceptionConstants;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.credt.comm.ValueReturnException;
import com.sorincorp.fo.credt.mapper.CredtMapper;
import com.sorincorp.fo.credt.model.CredtRepyVO;
import com.sorincorp.fo.credt.model.LonBankInfoVO;
import com.sorincorp.fo.credt.model.OrLonBasVO;
import com.sorincorp.fo.pd.comm.constant.PdPropertyConstant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CredtLonServiceImpl implements CredtLonService {

	/** 외부 연계 api 호출 모듈 **/
	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private MessageUtil messageUtil;

	/** 프로퍼티 상수 모음 **/
	@Autowired
	private PdPropertyConstant orProperty;

	/** 공통 채번 서비스 **/
	@Autowired
	private AssignService assignService;

	@Autowired
	private TaxbillService taxbillService;

	@Autowired
	private CredtMapper credtMapper;


	public static final String RESPONSE_CODE = "rspnsCode";
	public static final String RESPONSE_MESSAGE = "rspnsMssage";
	public static final String RESPONSE_CONTENT = "rspnsCont";

	@Override
	public void repyLon(CredtRepyVO param) throws Exception {

		Map<String, Object> resObj = null;

		// 22-09-19 변경사항 : 결제 예정일의 17시 이후로는 상환 처리 불가 로직 추가
		if(!getRepyPossibleAt(param.getOrderNo())) {
			log.debug("결제 예정일 17시 이후로는 처리 불가");
			throw new Exception("결제예정일의 17시 이후로는 상환이 불가능합니다.");
		}

		// 대출 은행 정보 조회
		LonBankInfoVO lonBankInfoVo = getLonRequstBankInfo(
				LonBankInfoVO.builder()
				.orderNo(param.getOrderNo())
				.bankCode(param.getBankCode())
				.build());

		// 대출 은행 OTP 가능 시간 확인
		if (!"Y".equals(lonBankInfoVo.getOtpYn())) {
			/** String appendEndTimeDesc = "";
			if (0 < lonBankInfoVo.getOtpEndTime()) {
				String endTime = String.valueOf( lonBankInfoVo.getOtpEndTime() );
				if (endTime.length() == 3) {
					endTime = StringUtil.padLeft(endTime, "0", 4);
				}
				appendEndTimeDesc = "(마감시간 : "+ endTime.substring(0, 1) + "시"+ endTime.substring(2, 4)+ "분)";
			} */

			throw new Exception("은행 OTP 이용 가능 시간이 아닙니다.");
		}

		// 만기일자 체크
		checkExprtnDe(param);

		// 1. 한도조회 (결제은행 잔고 확인)
		resObj = getLonLmt(param);
		Map<String, Object> cont = (Map<String, Object>) resObj.get(RESPONSE_CONTENT);
		long bankLimitSpare = Long.parseLong(String.valueOf(cont.get("bankLimitSpare")));

		// 2. 세금계산서 처리
		try {
			taxbillService.excuteTaxbill(param.getOrderNo());
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
		}

		// 3. 대출기본 등록 데이터 조회
		OrLonBasVO lonBasVo = Optional.ofNullable(credtMapper.selectLonOrder(param))
				.orElseThrow(() -> {
					log.error("주문 정보 확인 불가");
					return new Exception("주문 정보 확인 불가"+ messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
				});

		// 4. 데이터 입력
		lonBasVo.setLonNo(DateUtil.getNowDate()+ "-"+ assignService.selectAssignValue("OR", "LON_NO", DateUtil.calDate("yyyy"), param.getMberNo(), 5));
		lonBasVo.setOrderPnttmLmtAmount(bankLimitSpare);
		lonBasVo.setRequstMpFee(lonBankInfoVo.getReqMpFee());
		lonBasVo.setRequstBankFee(lonBankInfoVo.getReqBankFee());
		lonBasVo.setFrstRegisterId(param.getMberNo());
		lonBasVo.setLastChangerId(param.getMberNo());

		// 대출 기본 등록
		if (1 > credtMapper.insertOrLonBas(lonBasVo)) {
			log.error("대출 정보 등록 실패");
			throw new Exception("대출 정보 등록 실패"+ messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
		}

		// 대출 기본 이력 등록
		credtMapper.insertOrLonBasHst(lonBasVo);

		Map<String,Object> lonRequstMap = new HashMap<String, Object>();
		lonRequstMap.put("orderNo", param.getOrderNo());
		lonRequstMap.put("lonNo", lonBasVo.getLonNo());

		resObj = httpClientHelper.postCallApi(orProperty.getRepyLonUrl(), lonRequstMap);
		log.debug(null != resObj ? resObj.toString() : "resObj is null");

		if (null == resObj || StringUtil.isBlank(String.valueOf(resObj.get(RESPONSE_CODE))) ) {
			log.error("API 실패");
			throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
		}

		if (!"200".equals(String.valueOf(resObj.get(RESPONSE_CODE)))) {
			log.error("API 실패");
			throw new Exception(String.valueOf(resObj.get(RESPONSE_MESSAGE)));
		}
	}

	@Override
	public void repyLonCancel(CredtRepyVO param) throws Exception {

		Map<String, Object> resObj = null;

		String lonNo = Optional.ofNullable(credtMapper.getOrderLonNo(param))
				.orElseThrow(() -> {
					return new Exception("요청하신 대출 정보를 확인할 수 없습니다. (관리자에게 문의 바랍니다)");		// TODO 메세지는?
				});

		Map<String,Object> lonRequstMap = new HashMap<String, Object>();
		lonRequstMap.put("orderNo", param.getOrderNo());
		lonRequstMap.put("lonNo", lonNo);

		// 대출기본 T 상태값 수정 (취소요청)
		OrLonBasVO lonVo = new OrLonBasVO();
		lonVo.setOrderNo(param.getOrderNo());
		lonVo.setLonNo(lonNo);
		lonVo.setLonSttusCode("30");
		lonVo.setLastChangerId(param.getMberNo());

		if (1 > credtMapper.updatelonSttusCode(lonVo)) {
			throw new Exception("대출기본 상태값 수정 실패");
		}


		resObj = httpClientHelper.postCallApi(orProperty.getRepyLonCancelUrl(), lonRequstMap);
		log.debug(null != resObj ? resObj.toString() : "resObj is null");

		if (null == resObj || StringUtil.isBlank(String.valueOf(resObj.get(RESPONSE_CODE))) ) {
			log.error("API 실패");
			throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
		}

		if (!"200".equals(String.valueOf(resObj.get(RESPONSE_CODE)))) {
			log.error("API 실패");
			throw new Exception(String.valueOf(resObj.get(RESPONSE_MESSAGE)));
		}
	}

	@Override
	public LonBankInfoVO getLonRequstBankInfo(LonBankInfoVO paramVo) throws Exception {

		// 대출보증 MP 수수료 = MP수수료 + MP수수료의 부가세(10%)
		LonBankInfoVO lonBankInfoVo = Optional.ofNullable(credtMapper.getLonRequstBankInfo(paramVo))
				.orElseThrow(() -> {
					log.error("은행 정보를 확인 불가");
					return new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
				});

		return lonBankInfoVo;
	}

	@Override
	public Map<String, Object> getLonLmt(CredtRepyVO param) throws Exception {

		param.setSanctnMnCode("4");
		Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getLonLmtUrl(), param);
		log.debug(null != resObj ? resObj.toString() : "resObj is null");


		if (null == resObj || StringUtil.isBlank(String.valueOf(resObj.get(RESPONSE_CODE))) ) {
			log.error("API 실패");
			throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
		}

		if (!"200".equals(String.valueOf(resObj.get(RESPONSE_CODE)))) {
			log.error("API 실패");
			throw new Exception(String.valueOf(resObj.get(RESPONSE_MESSAGE)));
		}

		// TODO 성공시 map 형태로 데이터 포함
		Map<String, Object> cont = (Map<String, Object>) resObj.get(RESPONSE_CONTENT);

		log.debug("은행잔고 response : {}", String.valueOf(cont));
		/**
{responseCode=0000, responseMsg=, bankLimitAmt=000001100000000, bankLimitSpare=000001100000000}
		 */

		if (StringUtil.isBlank(String.valueOf(cont.get("bankLimitAmt"))) || StringUtil.isBlank(String.valueOf(cont.get("bankLimitSpare")))
				|| 0 == Long.parseLong(String.valueOf(cont.get("bankLimitAmt"))) || 0 == Long.parseLong(String.valueOf(cont.get("bankLimitSpare")))) {
			throw new Exception("대출 한도 금액을 확인해주세요.");
		}

		return resObj;
	}

	@Override
	public String checkExprtnDe(CredtRepyVO param) throws Exception {

		/**
		 * PASS_AT 0 : 정상 		 		 >> 선택한 만기일자 그대로 리턴(정상)
		 *
		 * 		   1 : 공휴일		 		 >> 선택한 만기일자 바로 이전 영업일 리턴
		 *  	   2 : 180일 초과			 >> 최대 만기일자로 리턴(180일)
		 *  	   3 : 공휴일 + 180일 초과   >> 최대 만기일자로 리턴(180일, 공휴일이지만 바로 이전영업일이 아니라 최대만기일자로 리턴해야함)
		 *
		 */
		Map<String, String> result = credtMapper.exprtnDeOverAndHoliDayCheck(param);
		String returnDe =  (null != result ? result.get("returnDe") : ""); //리턴할 만기일자 데이터
		int ret = Integer.parseInt(String.valueOf(null != result ? result.get("passAt") : "0"));  //전달한 메세지 구분

		if (1 == ret) {
			throw new ValueReturnException("만기일은 은행영업일에만 가능 합니다.", returnDe);
		} else if (2 == ret) {
			throw new ValueReturnException("만기일은 최대 180일 이내에서 설정 가능 합니다.", returnDe);
		}

		return returnDe;
	}

	/**
	 * 미납 주문의 상환 가능 여부 기준 반환 (Y/N)
	 *  1. 케이지배송
	 * 	2. 결제예정일: D ~ D+5 일 까지
	 */
	public boolean getRepyPossibleAt(String orderNo) throws Exception {

		return credtMapper.getRepyPossibleAt(orderNo);
	}
}
