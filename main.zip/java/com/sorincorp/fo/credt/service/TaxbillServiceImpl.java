package com.sorincorp.fo.credt.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.fo.credt.mapper.CredtMapper;
import com.sorincorp.fo.pd.comm.constant.PdPropertyConstant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TaxbillServiceImpl implements TaxbillService {

	/** 외부 연계 api 호출 모듈 **/
	@Autowired
	private HttpClientHelper httpClientHelper;

	/** 프로퍼티 상수 모음 **/
	@Autowired
	private PdPropertyConstant orProperty;

	@Autowired
	private CredtMapper credtMapper;


	@Override
	public void excuteTaxbill(String orderNo) throws Exception {
		Map<String, Object> reqObj = new HashMap<>();
		reqObj.put("canclExchngRtngudNo", null);
		reqObj.put("jobSe", "ORDER");
		reqObj.put("orderNo", orderNo);

		Map<String, Object> resObj = httpClientHelper.postCallApi(orProperty.getTaxbillUrl(), reqObj);

		if (null != resObj && StringUtils.equals("200", resObj.get("responseCode").toString())) {
			log.debug(">> 세금계산서 호출 성공");
		} else {
			throw new Exception("세금계산서 API 호출 실패");
		}

		// 세금계산서 확인 조회
		if (1 > credtMapper.getCntTaxbill(orderNo)) {
			throw new Exception("세금계산서 조회 실패");
		}
	}

}
