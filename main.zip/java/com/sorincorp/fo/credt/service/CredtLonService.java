package com.sorincorp.fo.credt.service;

import java.util.Map;

import com.sorincorp.fo.credt.model.CredtRepyVO;
import com.sorincorp.fo.credt.model.LonBankInfoVO;

public interface CredtLonService {

	/**
	 * <pre>
	 * 대출보증 상환 (매매계약 요청)
	 * </pre>
	 * @date 2022. 7. 25.
	 * @author srec0051
	 * @param param
	 * @throws Exception
	 */
	void repyLon(CredtRepyVO param) throws Exception;

	/**
	 * <pre>
	 * 대출보증 매매계약 취소 요청
	 * </pre>
	 * @date 2022. 7. 27.
	 * @author srec0051
	 * @param param
	 * @throws Exception
	 */
	void repyLonCancel(CredtRepyVO param) throws Exception;

	/**
	 * <pre>
	 * 대출보증 결제금액 한도 조회 <br>
	 * response : {
	 * "responseCode": "0000",
	 * "responseMsg": "정상",
	 * "bankLimitAmt": "100000000",
	 * "bankLimitSpare": "100000000"
	 * }
	 * </pre>
	 * @date 2022. 7. 25.
	 * @author srec0051
	 * @param param
	 * @return
	 */
	Map<String, Object> getLonLmt(CredtRepyVO param) throws Exception;

	/**
	 * <pre>
	 * 주문의 대출 은행 수수료 및 OTP 가능 시간 데이터 조회<br>
	 * !은행공통코드 변경시 수정해야 함
	 * </pre>
	 * @date 2022. 7. 26.
	 * @author srec0051
	 * @param paramVo {orderNo, bankCode}
	 * @return
	 */
	LonBankInfoVO getLonRequstBankInfo(LonBankInfoVO paramVo) throws Exception;

	/**
	 * <pre>
	 * 대출보증 만기일자 체크 <br>
	 * 만기일은 공휴일 또는 180일을 초과할 수 없다
	 * </pre>
	 * @date 2022. 9. 1.
	 * @author srec0051
	 * @param param
	 */
	String checkExprtnDe(CredtRepyVO param) throws Exception;
}
