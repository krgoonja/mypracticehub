package com.sorincorp.fo.credt.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.constants.ExceptionConstants;
import com.sorincorp.comm.order.model.CommPrvsnlOrderVO;
import com.sorincorp.comm.order.service.CommDashboardWebsocketService;
import com.sorincorp.comm.order.service.CommLimitOrderService;
import com.sorincorp.comm.order.service.CommPrvsnlOrderService;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.credt.constant.MrtggConstant;
import com.sorincorp.fo.credt.mapper.CredtMapper;
import com.sorincorp.fo.credt.model.CredtRepyVO;
import com.sorincorp.fo.pd.comm.constant.PdPropertyConstant;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CredtEwalletServiceImpl implements CredtEwalletService {

	/** 외부 연계 api 호출 모듈 **/
	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private MessageUtil messageUtil;

	/** 프로퍼티 상수 모음 **/
	@Autowired
	private PdPropertyConstant orProperty;

	@Autowired
	private CredtMapper credtMapper;

	/** 지정가 주문 공통 서비스 */
	@Autowired
	private CommLimitOrderService commLimitOrderService;

	@Autowired
	private CommPrvsnlOrderService commPrvsnlOrderService;

	@Autowired
	private CommDashboardWebsocketService commDashboardWebsocketService;

	private static final String RESPONSE_CODE = "rspnsCode";
	private static final String RESPONSE_MESSAGE = "rspnsMssage";
	private static final String RSPNS_CONT = "rspnsCont";

	/**
	 * 이월렛 상환 처리 <br>
	 * 2023.05.16 지정가 자동 취소 로직 추가
	 */
	@Override
	public void repyEwallet(CredtRepyVO param) throws Exception {

		Map<String, Object> requstObj = null;
		Map<String, Object> rspnsObj = null;


		// 주문 기본 조회
		CredtRepyVO credtRepyVo = Optional.ofNullable(credtMapper.selectOrder(param))
				.orElseThrow(()->{ return new Exception("주문 기본 조회 실패"); });


		// 2022-09-19 변경사항 : 결제 예정일의 17시 이후로는 상환 처리 불가 로직 추가 (결제방식 : 증거금 만 해당)
		boolean repyAt = getRepyPossibleAt(credtRepyVo.getOrderNo());
		if (MrtggConstant.SetleMthdCode.WRTM.getCode().equals(credtRepyVo.getSetleMthdCode()) && !repyAt) {
			log.error("결제 예정일 17시 이후로는 처리 불가");
			throw new Exception("결제예정일의 17시 이후로는 상환이 불가능합니다.");
		}

		// 2023.05.16 지정가 자동 취소
		// DashboardController 의 예수금(지정가주문) 체크 로직(/insertRefundRequst/before)을 먼저 실행하여 도출된 취소 여부(orderCancelAt)에 따라 로직 실행
		if (StringUtils.equals(param.getOrderCancelAt(), CommonConstants.YN_Y)) {
			commLimitOrderService.limitOrderAutoCancel(param.getMberId(), param.getEntrpsNo(), "42", credtRepyVo.getUnSetleAmount());
		}

//		long unSetleAmount = credtRepyVo.getUnSetleAmount(); // 미납금
//		// 이월렛 잔액 조회 (이중 체크로 제거)
//		rspnsObj = httpClientHelper.postCallApi(orProperty.getEwalletMoneyUrl(), Collections.singletonMap("entrpsNo", credtRepyVo.getEntrpsNo()));
//		log.warn(">> E-WALLET 잔금 조회 resObj : " + rspnsObj);
//		if (rspnsObj != null && rspnsObj.get(PdCommConstant.EWALLET_DATA_KEY) != null) {
//			Map<String, Object> dataObj = (Map<String, Object>) rspnsObj.get(PdCommConstant.EWALLET_DATA_KEY);
//			long ewalletMoney =  NumberUtils.toLong(String.valueOf(dataObj.get(PdCommConstant.EWALLET_MONNY_KEY)));
//			if (ewalletMoney < unSetleAmount) {
//				throw new Exception("Ewallet 금액 부족");
//			}
//		} else {
//			throw new Exception("Ewallet 잔금 조회 실패");
//		}


		// 1. call ewallet
		requstObj = new HashMap<>();
		requstObj.put("orderNo", credtRepyVo.getOrderNo());

		rspnsObj = httpClientHelper.postCallApi(orProperty.getRepyEwalletUrl(), requstObj);

		log.debug("getRepyEwalletUrl rspnsObj = {}", rspnsObj.toString());

		if (null == rspnsObj || StringUtil.isBlank(String.valueOf(rspnsObj.get(RESPONSE_CODE))) ) {
			throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
		}
		if ("500".equals(String.valueOf(rspnsObj.get(RESPONSE_CODE)))) {
			throw new Exception(String.valueOf(rspnsObj.get(RESPONSE_MESSAGE)));
		}


		// 2. call mrtgg
		// *** 이월렛 처리가 완료된 건은 성공으로 노출 후 BO 에서 재처리 ***
		// 증거금 아닐때 담보상환 API 호출
		// 24-04-16 변경사항 : 전자상거래보증(20) or 여신(40) 일 때 호출하도록 조건문 변경
		// 24-05-03 변경사항 : 추가 결제 금액에 대한 분기 처리 추가
		if (MrtggConstant.SetleMthdCode.MRTGG.getCode().equals(credtRepyVo.getSetleMthdCode())
				|| MrtggConstant.SetleMthdCode.CDTLN.getCode().equals(credtRepyVo.getSetleMthdCode())) {
			
			// 이미 담보 상환이 완료되었으나, 결제된 case ==> 평균가 + 여신 방식으로 결제된 주문의 추가 결제 금액에 대한 결제 처리
			// 24-11-18 변경사항 : 평균가 주문일 때만 추가 금액에 대한 처리를 하도록 조건 추가
			if(StringUtils.equals(credtRepyVo.getMrtggSttusCode(), "50") && StringUtils.equals(credtRepyVo.getSleMthdCode(), "04")){
				// 담보 기본 테이블 추가 금액 처리
				credtMapper.updateOrMrtggBas(credtRepyVo);
			} else {
				requstObj = new HashMap<>();
				requstObj.put("orderNo", credtRepyVo.getOrderNo());
				requstObj.put("mrtggSttusCode", MrtggConstant.MrtggSttusCode.PARTREPY.getCode());
				requstObj.put("repySeCode", MrtggConstant.RepySeCode.RCPMNY.getCode()); // 담보상환 구분코드 - 01:중량정산, 02:상환입금, 10:미납상환(모두)
				
				rspnsObj = httpClientHelper.postCallApi(orProperty.getRepyMrtggUrl(), requstObj);
				log.debug("getRepyMrtggUrl rspnsObj = {}", rspnsObj.toString());
				
				if (null == rspnsObj || StringUtil.isBlank(String.valueOf(rspnsObj.get(RESPONSE_CODE))) ) {
					throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
				}
				if ("500".equals(String.valueOf(rspnsObj.get(RESPONSE_CODE)))) {
					throw new Exception(String.valueOf(rspnsObj.get(RESPONSE_MESSAGE)));
				}
			}
		}
	}

	/**
	 * 미납 주문의 상환 가능 여부 기준 반환 (Y/N)
	 *  1. 케이지배송
	 * 	2. 결제예정일: D ~ D+5 일 까지
	 */
	public boolean getRepyPossibleAt(String orderNo) throws Exception {

		return credtMapper.getRepyPossibleAt(orderNo);
	}

	@Override
	public SseEmitter mrtggMdstrmRepy(CredtRepyVO param) throws Exception {
		// SSE 통신을 위한 SseEmitter 객체를 timeout(60초) 값을 포함하여 생성
		SseEmitter emitter = new SseEmitter((long) 60000);
		
		// 503 Error 방지용 Dummy Event Send
		emitter.send(SseEmitter.event().id("connect").name("connect").data("connected"));
		
		Runnable repyTask = () -> {
			log.debug("CredtEwalletServiceImpl::mrtggMdstrmRepy repyTask Thread Start");
			
			Map<String, Object> requstObj = null;
			Map<String, Object> rspnsObj = null;
			
			// 1. 화면에서 선택한 중도 상환 대상 조회
			List<CredtRepyVO> mdstrmRepyInfoList = credtMapper.selectMdstrmRepyInfo(param);
			
			// 2. 건 별로 상환 금액만큼 지정가 자동 취소 및 상환 처리를 위한 이월렛, 담보보증 api 호출 (건 별로 호출)
			//    건 별로 상환 처리까지 완료될 때마다 FO에 상환 완료 데이터 전달
			int currentCounter = 1;
			for (CredtRepyVO credtRepyVo : mdstrmRepyInfoList) {
				try {
					log.debug("CredtEwalletServiceImpl::mrtggMdstrmRepy repyTask target orderNo : {}, mdstrmRepySn : {}", credtRepyVo.getOrderNo(), credtRepyVo.getMdstrmRepySn());
					// 상환 금액만큼 지정가 자동 취소
					// DashboardController 의 예수금(지정가주문) 체크 로직(/insertRefundRequst/before)을 먼저 실행하여 도출된 취소 여부(orderCancelAt)에 따라 로직 실행
					if (StringUtils.equals(param.getOrderCancelAt(), CommonConstants.YN_Y)) {
						commLimitOrderService.limitOrderAutoCancel(param.getMberId(), param.getEntrpsNo(), "42", credtRepyVo.getUnSetleAmount());
					}
					
					// 1. call ewallet
					requstObj = new HashMap<>();
					requstObj.put("orderNo", credtRepyVo.getOrderNo());
					
					if(StringUtils.equals(credtRepyVo.getAditAmountRepyAt(), "Y")) {	// 추가 금액에 대한 상환 데이터일 경우
						requstObj.put("aditAmountRepyAt", credtRepyVo.getAditAmountRepyAt());	// 추가 금액 상환 여부를 포함
					} else if(credtRepyVo.getMdstrmRepySn() != null && credtRepyVo.getMdstrmRepySn() > 0) {	// 중도 상환에 대한 상환 데이터일 경우
						requstObj.put("mdstrmRepySn", credtRepyVo.getMdstrmRepySn());	// 중도 상환 순번 데이터를 포함
					}
	
					rspnsObj = httpClientHelper.postCallApi(orProperty.getRepyEwalletUrl(), requstObj);
	
					if (null == rspnsObj || StringUtil.isBlank(String.valueOf(rspnsObj.get(RESPONSE_CODE))) ) {
						throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
					}
					if ("500".equals(String.valueOf(rspnsObj.get(RESPONSE_CODE)))) {
						throw new Exception(String.valueOf(rspnsObj.get(RESPONSE_MESSAGE)));
					}
					log.debug("getRepyEwalletUrl rspnsObj = {}", rspnsObj.toString());
					
					// 2. call mrtgg
					requstObj = new HashMap<>();
					requstObj.put("orderNo", credtRepyVo.getOrderNo());
					requstObj.put("mrtggSttusCode", MrtggConstant.MrtggSttusCode.PARTREPY.getCode());
					requstObj.put("repySeCode", MrtggConstant.RepySeCode.NYP_REPY.getCode()); // 담보상환 구분코드 - 01:중량정산, 02:상환입금, 10:미납상환(모두)
					requstObj.put("mdstrmRepySn", credtRepyVo.getMdstrmRepySn());	// 중도 상환 순번
					
					rspnsObj = httpClientHelper.postCallApi(orProperty.getRepyMrtggUrl(), requstObj);
					
					if (null == rspnsObj || StringUtil.isBlank(String.valueOf(rspnsObj.get(RESPONSE_CODE))) ) {
						throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
					}
					if ("500".equals(String.valueOf(rspnsObj.get(RESPONSE_CODE)))) {
						throw new Exception(String.valueOf(rspnsObj.get(RESPONSE_MESSAGE)));
					}
					log.debug("getRepyMrtggUrl rspnsObj = {}", rspnsObj.toString());
					
					// 3. FO에 비동기식 데이터 전송
					emitter.send(SseEmitter.event().id("count").data(currentCounter++));
				} catch (Exception e) {
					try {
						emitter.send(SseEmitter.event().id("connect").data("error"));
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					
					log.error("[CredtEwalletServiceImpl][mrtggMdstrmRepy] " + ExceptionUtils.getStackTrace(e));
				}
			}
			
			// 모든 상환 건 처리 완료 후, SSE 통신 완료 처리
			emitter.complete();
			
			log.debug("CredtEwalletServiceImpl::mrtggMdstrmRepy repyTask Thread End");
		};
		
		new Thread(repyTask).start();
		
		return emitter;
	}

	/**
	 * 변동금 입금 처리
	 */
	@Override
	public void repyChangegld(CredtRepyVO param) throws Exception {
		Map<String, Object> requstObj = null;
		Map<String, Object> rspnsObj = null;

		// 1. 입금대상 변동금 내역 조회
		CommPrvsnlOrderVO credtRepyVo =  Optional.ofNullable(commPrvsnlOrderService.selectOrPcChangegldBas(param.getOrderNo(), param.getOccrrncSn()))
				.orElseThrow(()->{ return new Exception("가격 변동금 기본 조회 실패"); });

		// 2023.05.16 지정가 자동 취소
		// DashboardController 의 예수금(지정가주문) 체크 로직(/insertRefundRequst/before)을 먼저 실행하여 도출된 취소 여부(orderCancelAt)에 따라 로직 실행
		if (StringUtils.equals(param.getOrderCancelAt(), CommonConstants.YN_Y)) {
			commLimitOrderService.limitOrderAutoCancel(param.getMberId(), param.getEntrpsNo(), "42", credtRepyVo.getDelngAmount());
		}

		// 2. call ewallet
		requstObj = new HashMap<>();
		requstObj.put("orderNo", credtRepyVo.getOrderNo());	   	 // 주문 번호
		requstObj.put("occrrncSn", credtRepyVo.getOccrrncSn());  // 발생 순번
		requstObj.put("changegldRepyAt", "Y");                   // 변동금 상환 여부

		rspnsObj = httpClientHelper.postCallApi(orProperty.getRepyEwalletUrl(), requstObj);

		log.debug("getRepyEwalletUrl rspnsObj = {}", rspnsObj.toString());

		if (null == rspnsObj || StringUtil.isBlank(String.valueOf(rspnsObj.get(RESPONSE_CODE))) ) {
			throw new Exception(messageUtil.getMessage(ExceptionConstants.ERROR_CODE_DEFAULT));
		}
		if ("500".equals(String.valueOf(rspnsObj.get(RESPONSE_CODE)))) {
			throw new Exception(String.valueOf(rspnsObj.get(RESPONSE_MESSAGE)));
		}

		// 3. BO 대시보드(변동금 입금 대상 목록) 갱신용 웹소켓 호출
		commDashboardWebsocketService.publishRcpmnyEvent(credtRepyVo.getOrderNo(), true);
	}

}
