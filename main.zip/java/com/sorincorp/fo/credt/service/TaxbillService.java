package com.sorincorp.fo.credt.service;

public interface TaxbillService {

	/**
	 * <pre>
	 * 세금계산서 발행 (기발행시 성공으로 리턴, 미발행시 발행) / api 호출 후 세금계산서 조회까지 되어야 성공
	 * </pre>
	 * @date 2022. 7. 26.
	 * @author srec0051
	 * @param param
	 * @throws Exception
	 */
	void excuteTaxbill(String orderNo) throws Exception;

}
