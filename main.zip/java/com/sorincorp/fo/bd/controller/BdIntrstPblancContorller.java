package com.sorincorp.fo.bd.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.ui.Model;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.bd.model.BdIntrstPblancVO;
import com.sorincorp.fo.bd.service.BdIntrstPblancService;
import com.sorincorp.fo.config.UserInfoUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * BdIntrstPblancContorller.java
 * @version
 * @since 2023. 9. 12.
 * @author bok3117
 */
@Slf4j
@Controller
@RequestMapping(value = "/bid/intrst")
public class BdIntrstPblancContorller {
	
	@Autowired
	BdIntrstPblancService bdIntrstPblancService;
	
	@Autowired
	UserInfoUtil userInfoUtil;
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 > 관심 공고 페이지 조회
	 * </pre>
	 * @date 2023. 9. 14.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 14.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectIntrstPblanc")
	public String selectIntrstPblanc(@RequestParam(required = false) String bidEntrpsNo, Model model) {
		try {
			BdAccount account = userInfoUtil.getBdAccountInfo();
			
			if(account != null) {
				BdIntrstPblancVO intrstPblancVO = new BdIntrstPblancVO();
				intrstPblancVO.setBidEntrpsNo(account.getBidEntrpsNo());
				
				int totalDataCount = bdIntrstPblancService.selectIntrstPblancCnt(intrstPblancVO);
				List<BdIntrstPblancVO> intrstList = null;
				
				if(totalDataCount > 0) {
					intrstList = bdIntrstPblancService.selectIntrstPblancList(intrstPblancVO);
					model.addAttribute("intrstList", intrstList);
				}
				model.addAttribute("totalDataCount", totalDataCount);
			}
			return "bd/bidIntrstPblanc";
		} catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 관심공고 리스트 저장
	 * </pre>
	 * @date 2023. 9. 12.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 12.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertIntrstPblanc")
	@ResponseBody
	public ResponseEntity<?> insertIntrstPblanc(@RequestBody BdIntrstPblancVO intrstPblancVO) throws Exception {
		BdAccount account = userInfoUtil.getBdAccountInfo();
		
		if(account != null) {
			String bidMberID = account.getBidMberId();
			intrstPblancVO.setFrstRegisterId(bidMberID);
			intrstPblancVO.setLastChangerId(bidMberID);
			intrstPblancVO.setBidEntrpsNo(account.getBidEntrpsNo());

			bdIntrstPblancService.insertIntrstPblanc(intrstPblancVO);
			return new ResponseEntity<>(intrstPblancVO, HttpStatus.OK);
		} else {
			return new ResponseEntity<>("로그인되어 있지 않습니다.", HttpStatus.BAD_REQUEST);
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 관심공고 리스트 삭제
	 * </pre>
	 * @date 2023. 9. 12.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 12.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/deleteIntrstPblanc")
	@ResponseBody
	public ResponseEntity<?> deleteIntrstPblanc(@RequestBody BdIntrstPblancVO intrstPblancVO) throws Exception {
		BdAccount account = userInfoUtil.getBdAccountInfo();
		
		if(account != null) {
			String bidMberID = account.getBidMberId();
			intrstPblancVO.setLastChangerId(bidMberID);
			intrstPblancVO.setBidEntrpsNo(account.getBidEntrpsNo());

			bdIntrstPblancService.deleteIntrstPblanc(intrstPblancVO);
			return new ResponseEntity<>(intrstPblancVO, HttpStatus.OK);
		} else {
			return new ResponseEntity<>("로그인되어 있지 않습니다.", HttpStatus.BAD_REQUEST);
		}
	}
	
}
