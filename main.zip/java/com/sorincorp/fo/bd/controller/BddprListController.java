package com.sorincorp.fo.bd.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nimbusds.oauth2.sdk.Request;
import com.nimbusds.oauth2.sdk.http.HTTPRequest;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.bd.model.BddprListVO;
import com.sorincorp.fo.bd.service.BddprListService;
import com.sorincorp.fo.config.UserInfoUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * BddprListController.java
 * @version
 * @since 2023. 8. 21.
 * @author bok3117
 */
@Slf4j
@Controller
@RequestMapping(value = "/bid/bddpr")
public class BddprListController {
	
	@Autowired
	private BddprListService bddprListService;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 > 투찰 목록 페이지 조회
	 * </pre>
	 * @date 2023. 8. 21.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 8. 21.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectBddprList")
	public String selectBddprList(ModelMap model, HttpServletRequest request) {
		try {
		    String tabParam = request.getParameter("tab");
		    
		    model.addAttribute("tabParam", tabParam);
			return "bd/bidBddprList";
		} catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 > 투찰 목록 조회
	 * </pre>
	 * @date 2023. 8. 22.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 8. 22.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param bddprListVO
	 * @return map
	 * @throws Exception
	 */
	  @RequestMapping("/selectBddprListData")
	  @ResponseBody 
	  public Map<String, Object> selectBddprListData(@RequestBody BddprListVO bddprListVO) throws Exception { 
		  Map<String, Object> map = new HashMap<String, Object>(); 
			
		  try {
			  BdAccount account = getBdAccount();
			  String bidEntrpsNo = account.getBidEntrpsNo(); // 입찰 업체번호
			  bddprListVO.setBidEntrpsNo(bidEntrpsNo);
			  
			  int totalDataCount = bddprListService.selectBddprListTotcnt(bddprListVO);
			  List<BddprListVO> bddprList = null;

			  // 투찰 내역이 존재하는 경우 리스트에 담아서 노출
			  if (totalDataCount > 0) { 
				  bddprList = bddprListService.selectBddprList(bddprListVO);
			  }

			  map.put("totalDataCount", totalDataCount);
			  map.put("bddprList", bddprList); 
			  
		  } catch (Exception e) {
				log.error(ExceptionUtils.getStackTrace(e));
		  }
		  return map;
	  }

	/**
	 * <pre>
	 * 처리내용: 마이페이지 > 투찰 목록 개수
	 * </pre>
	 * @date 2023. 8. 24.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 8. 24.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param bddprListVO
	 * @return map
	 * @throws Exception
	 */
	@PostMapping("/selectBddprListCnt")
	@ResponseBody
	public Map<String, Object> selectBddprListCnt(BddprListVO bddprListVO) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		BdAccount account = getBdAccount();
		String bidEntrpsNo = account.getBidEntrpsNo(); // 입찰 업체번호
		
		bddprListVO.setBidEntrpsNo(bidEntrpsNo);
		map.put("bddrListCnt", bddprListService.selectBddprCnt(bddprListVO));
		
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 접근 시 로그인 정보 확인
	 * </pre>
	 * @date 2023. 8. 30.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 8. 30.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @return 
	 * @param 
	 * @throws Exception
	 */
	public BdAccount getBdAccount() throws Exception {
		BdAccount account = userInfoUtil.getBdAccountInfo();
		
		if(null == account || StringUtil.isBlank(account.getBidMberId()) || StringUtil.isBlank(account.getBidEntrpsNo())) {
			throw new Exception("로그인 정보를 확인해주세요.");
		}
		return account;
	}
}
