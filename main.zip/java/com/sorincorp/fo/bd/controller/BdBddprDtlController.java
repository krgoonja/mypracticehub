package com.sorincorp.fo.bd.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.bd.model.BdBddprVO;
import com.sorincorp.fo.bd.model.BdBidUpdtVO;
import com.sorincorp.fo.bd.model.BdBidVO;
import com.sorincorp.fo.bd.model.BdScsAtcDocVO;
import com.sorincorp.fo.bd.service.BdDetailService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.service.AccountServiceImpl;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bid")
public class BdBddprDtlController {
	
	@Autowired
    UserInfoUtil userInfoUtil;
 
	@Autowired
	AccountServiceImpl accountService;
	
    @Autowired
	BdDetailService bdDetailService;
    

    @Autowired
    private CommonCodeService commonCodeService;

 
    /**
     * <pre>
     * 처리내용: 투찰 상세 페이지로 변환
     * </pre>
    *  @date 2023. 08. 22.
     * @author sein
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2023. 08. 22.		sein    			최초작성
     * ------------------------------------------------
     * @param bidVO
     * @return 
     * @throws Exception
     */
    @RequestMapping("/bddprDtl")
    public String bddprDtl(@RequestBody BdBidVO bdBidVO, Model model, HttpServletRequest request) throws Exception {
		try {
			
			BdAccount account = userInfoUtil.getBdAccountInfo();
			String bidMber = "";
			//로그인 여부 확인
			if (account != null) {
				bidMber = account.getBidMberId();
				// 입찰 공고 가져오기 (bidPblancId, bidEntrpsNo)
				bdBidVO = bdDetailService.selectBdBddprInfo(bdBidVO);
				model.addAttribute("bdBidVO", bdBidVO);
				
				// 투찰 정보 가져오기 (bidPblancId)
                /*
                 * List<BdBddprVO> bdBddprList = bdDetailService.selectBdBddprList(bdBidVO);
                 * model.addAttribute("bdBddprList", bdBddprList);
                 */
				
				//BdBddprVO bddprVO = bdDetailService.selectBdBddprInfo(bdBidVO);
				
				//입찰 수정 내용
				List<BdBidUpdtVO> bdBidUpdtList = bdDetailService.selectBdBidUpdtList(bdBidVO);
				model.addAttribute("bdBidUpdtList", bdBidUpdtList);
				BdBddprVO bdAccBddprVO = new BdBddprVO();
				bdAccBddprVO.setBidPblancId(bdBidVO.getBidPblancId());
                // 투찰 공고가 있는 아이디 확인
                if (bdBidVO.getBidEntrpsNo().equals(account.getBidEntrpsNo())) { // account.getEntrpsNo()
                    //입찰 예정, 투찰 중이 아니면서 1등 기업 서류제출 가져오기
                    if(bdBidVO.getOpengRank() != null && bdBidVO.getOpengRank().equals("1") && !(bdBidVO.getBidSttusCode().equals("12") || bdBidVO.getBidSttusCode().equals("13"))) {
                        List<BdScsAtcDocVO> bdDocList = new ArrayList<BdScsAtcDocVO>(); //BD_SCSBID_DTL 받아와서 00~09 분류 후 jsp설정
                        bdDocList = bdDetailService.selectBdDocList(bdAccBddprVO);
                        model.addAttribute("bdDocList", bdDocList);
                    }
                }
                // 인도조건 리스트
                List<BdBidVO> bidDelyCndList = bdDetailService.selectBidDelyCndList(bdBidVO);
                model.addAttribute("bidDelyCndList", bidDelyCndList);
                
                // 입찰 가격 지정 방법 코드 리스트
                model.addAttribute("pcAppnMthCodeList", commonCodeService.getSubCodesToCommonCode("PC_APPN_MTH_CODE"));
	            model.addAttribute("bidDelyCndStdrPcList", commonCodeService.getSubCodesToCommonCode("BID_DELY_CND_STDR_PC"));
				model.addAttribute("bdAccBddprVO", bdAccBddprVO);
			} else {
				return "bdTiles/bdMain";
			}
		} catch (Exception e) {
			log.error("bidDetail Error ====> {}", ExceptionUtils.getStackTrace(e));
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);

			return "error/503";
		}

		return "bd/bidBddprDtl";
	}

    /**
     * <pre>
     * 처리내용: 심사 접수중 1위 기업 파일 접수, 재접수
     * </pre>
    *  @date 2023. 08. 22.
     * @author sein
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2023. 08. 22.		sein    			최초작성
     * ------------------------------------------------
     * @param bdScsAtcDocVO
     * @return 
     * @throws Exception
     */
    /*
     * @RequestMapping("/modalDocInfoAjax")
     * 
     * @ResponseBody public ResponseEntity<?> modalDocInfoAjax(@RequestBody
     * BdScsAtcDocVO bdScsAtcDocVO) throws Exception { try { Map<String,Object> map
     * = bdDetailService.modalDocInfoAjax(bdScsAtcDocVO);
     * 
     * return new ResponseEntity<>(map,HttpStatus.OK); } catch (Exception e) {
     * log.error(e.getMessage()); return new ResponseEntity<>(e.getMessage(),
     * HttpStatus.BAD_REQUEST); }
     * 
     * }
     */

    /**
     * <pre>
     * 처리내용: 서류 적합, 부적합, 개수 체크
     * </pre>
    *  @date 2023. 08. 22.
     * @author sein
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2023. 08. 22.		sein    			최초작성
     * ------------------------------------------------
     * @param bdScsAtcDocVO
     * @return 
     * @throws Exception
     */
    /*
     * @RequestMapping("/modalDocCheck")
     * 
     * @ResponseBody public ResponseEntity<?> modalDocCheck(@RequestBody
     * BdScsAtcDocVO bdScsAtcDocVO) throws Exception { try { Map<String,Object> map
     * = bdDetailService.modalDocCheck(bdScsAtcDocVO);
     * 
     * return new ResponseEntity<>(map,HttpStatus.OK); } catch (Exception e) {
     * log.error(e.getMessage()); return new ResponseEntity<>(e.getMessage(),
     * HttpStatus.BAD_REQUEST); }
     * 
     * }
     */
    /**
     * <pre>
     * 처리내용: 투찰 기업 정보 등록
     * </pre>
    *  @date 2023. 08. 29.
     * @author sein
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2023. 08. 29.		sein    			최초작성
     * ------------------------------------------------
     * @param bddprVO
     * @return 
     * @throws Exception
     */
    /*
     * @RequestMapping("/insertBdBddpr") public ResponseEntity<?>
     * insertBdBddpr(@RequestBody BdBddprVO bdBddprVO) throws Exception { // 투찰 기간이
     * 지나면 투찰x String resultMsg = ""; try { //투찰 insert resultMsg =
     * bdDetailService.insertBdBddpr(bdBddprVO);
     * 
     * return new ResponseEntity<>(resultMsg, HttpStatus.OK); // ajax success 데이터 전달
     * 
     * } catch (Exception e) { // TODO: handle exception log.error(e.getMessage());
     * return new ResponseEntity<>("insertBdBddpr 오류.", HttpStatus.BAD_REQUEST); } }
     */
	
	/**
	 * <pre>
	 * 처리내용: 투찰 취소 기업 개수
	 * </pre>
	 * 
	 * @date 2023. 08. 29.
	 * @author sein
	 * @history 
	 * ------------------------------------------------ 
	 * 변경일 			작성자 			변경내용
	 * ------------------------------------------------ 
	 * 2023. 08. 29.	 sein				최초작성
	 * ------------------------------------------------
	 * @param bdBidVO
	 * @return ResponseEntity<?>
	 * @throws Exception
	 */
    /*
     * @RequestMapping("/selectBddprCanclCountAjax") public ResponseEntity<?>
     * selectBddprCanclCountAjax(@RequestBody BdBidVO bdBidVO) throws Exception {
     * 
     * try {
     * 
     * int num = bdDetailService.selectBddprCanclCount(bdBidVO); //투찰 취소 갯수 return
     * new ResponseEntity<>(Integer.toString(num), HttpStatus.OK);
     * 
     * } catch (Exception e) { log.error(e.getMessage()); return new
     * ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST); } }
     */
	
	/**
     * <pre>
     * 처리내용: 투찰 기업 정보 취소
     * </pre>
    *  @date 2023. 08. 31.
     * @author sein
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2023. 08. 31		sein    			최초작성
     * ------------------------------------------------
     * @param bdBddprVO
     * @return ResponseEntity<?>
     * @throws Exception
     */
    /*
     * @RequestMapping("/deleteBdBddpr") public ResponseEntity<?>
     * deleteBdBddpr(@RequestBody BdBddprVO bdBddprVO) throws Exception {
     * 
     * boolean isBdCancl = false; try { //update 완료 : true, 실패 : false isBdCancl =
     * bdDetailService.deleteBdBddpr(bdBddprVO); } catch (Exception e) {
     * log.error(e.getMessage()); return new ResponseEntity<>(e.getMessage(),
     * HttpStatus.BAD_REQUEST); } return new ResponseEntity<>(isBdCancl,
     * HttpStatus.OK); }
     */
	
    /**
     * <pre>
     * 처리내용: 서류 심사중 상태 1위기업 서류 접수
     * </pre>
    *  @date 2023. 08. 22.
     * @author sein
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2023. 08. 22.		sein    			최초작성
     * ------------------------------------------------
     * @param bdScsAtcDocVO
     * @return 
     * @throws Exception
     */
    /*
     * @RequestMapping("/fileUploads")
     * 
     * @ResponseBody public ResponseEntity<?>
     * fileUploads(MultipartHttpServletRequest mRequest) throws Exception {
     * Map<String,Object> fileMap = new HashMap<String,Object>(); fileMap =
     * bdDetailService.saveAttachFile(mRequest); log.info(fileMap.toString());
     * return new ResponseEntity<>(fileMap,HttpStatus.OK); }
     */
	
    /**
     * <pre>
     * 처리내용: 서류 심사중 상태 1위기업 서류 삭제
     * </pre>
    *  @date 2023. 08. 22.
     * @author sein
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2023. 08. 22.		sein    			최초작성
     * ------------------------------------------------
     * @param bdScsAtcDocVO
     * @return 
     * @throws Exception
     */
    /*
     * @RequestMapping("/deleteAttachFile")
     * 
     * @ResponseBody public ResponseEntity<?> deleteAttachFile(@RequestBody
     * FileDocVO vo) throws Exception { try { Map<String,Object> map =
     * bdDetailService.deleteAttachFile(vo);
     * 
     * return new ResponseEntity<>(map,HttpStatus.OK); } catch (Exception e) {
     * log.error(e.getMessage()); return new ResponseEntity<>(e.getMessage(),
     * HttpStatus.BAD_REQUEST); }
     * 
     * }
     */
	
    /**
     * <pre>
     * 처리내용: 서류 심사중 상태 1위기업 서류 접수
     * </pre>
    *  @date 2023. 08. 22.
     * @author sein
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2023. 08. 22.		sein    			최초작성
     * ------------------------------------------------
     * @param bdScsAtcDocVO
     * @return 
     * @throws Exception
     */
    /*
     * @RequestMapping("/insertBdScsAtcDoc") public ResponseEntity<?>
     * insertBdScsAtcDoc(@RequestBody BdScsAtcDocVO bdScsAtcDocVO) throws Exception
     * {
     * 
     * String resultMsg = ""; try { //입찰 낙찰 첨부파일 insert resultMsg =
     * bdDetailService.insertBdScsAtcDoc(bdScsAtcDocVO);
     * 
     * return new ResponseEntity<>(resultMsg, HttpStatus.OK); // ajax success 데이터 전달
     * 
     * } catch (Exception e) { log.error(e.getMessage()); return new
     * ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST); } }
     */
	
    /**
     * <pre>
     * 처리내용: 서류 접수중 > 서류 심사중 변경 
     * </pre>
    *  @date 2023. 08. 22.
     * @author sein
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2023. 08. 22.		sein    			최초작성
     * ------------------------------------------------
     * @param bdScsAtcDocVO
     * @return ResponseEntity
     * @throws Exception
     */
    /*
     * @RequestMapping("/bdDocSubmit") public ResponseEntity<?>
     * bdDocSubmit(@RequestBody BdScsAtcDocVO bdScsAtcDocVO) throws Exception {
     * String resultMsg = ""; try { resultMsg =
     * bdDetailService.bdDocSubmit(bdScsAtcDocVO); //로그인 여부 확인 return new
     * ResponseEntity<>(resultMsg, HttpStatus.OK); // ajax success 데이터 전달
     * 
     * } catch (Exception e) { log.error(e.getMessage()); return new
     * ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST); }
     * 
     * }
     */
	
	/**
     * <pre>
     * 처리내용: 인도조건창고 목록 리스트
     * </pre>
    *  @date 2023. 09. 15.
     * @author bok3117
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2023. 09. 15.		bok3117    			최초작성
     * ------------------------------------------------
     * @param bdBddprVO, model
     * @return 
     * @throws Exception
     */
    /*
     * @RequestMapping("/selectLgistCnterList")
     * 
     * @ResponseBody public ResponseEntity<?> selectLgistCnterList(@RequestBody
     * BdBidVO bdBidVO, Model model) throws Exception { Map<String, Object> map =
     * new HashMap<String, Object>();
     * 
     * try { List<BdBidVO> lgistList =
     * bdDetailService.selectLgistCnterList(bdBidVO); int totalDataCount =
     * bdDetailService.selectLgistCnterCnt(bdBidVO); map.put("totalRowCount",
     * totalDataCount); map.put("lgistList", lgistList); return new
     * ResponseEntity<>(map, HttpStatus.OK); } catch(Exception e) {
     * log.error(e.getMessage()); HttpUtil.setErrorMsgToRequestAttribute("errMsg",
     * e); return new ResponseEntity<>(map, HttpStatus.BAD_GATEWAY); } }
     */
	
}
