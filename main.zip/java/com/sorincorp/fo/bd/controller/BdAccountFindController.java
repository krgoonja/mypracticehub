package com.sorincorp.fo.bd.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

import com.sorincorp.comm.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.fo.bd.model.BdAccountFindIdVO;
import com.sorincorp.fo.bd.model.BdAccountFindPwVO;
import com.sorincorp.fo.bd.model.BdEtrVO;
import com.sorincorp.fo.bd.service.BdAccountFindService;
import com.sorincorp.fo.config.LoginTokenProvider;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.model.AccountFindIdVO;

import io.jsonwebtoken.ExpiredJwtException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Slf4j
@Controller
@RequestMapping("/bid")
public class BdAccountFindController {

	private final LoginTokenProvider jwtTokenProvider;
	private final MessageUtil messageUtil;
	private final MessageSourceAccessor messageSourceAccessor;

	@Autowired
    UserInfoUtil userInfoUtil;

	@Autowired
	private BdAccountFindService bdAccountFindService;

	@Autowired
	private CustomValidator customValidator;

	@Value("${spring.profiles.active}")
	private String profiles;

	/**
	 * <pre>
	 * 처리내용: 아이디 찾기 화면 이동
	 * </pre>
	 * @date 2023. 09. 14.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 14.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@RequestMapping("/id")
	public String findId() {
		try {
			return "bd/bidFindId";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}

	}

	/**
	 * <pre>
	 * 처리내용: 아이디찾기 휴대폰 인증번호 발송
	 * </pre>
	 * @date 2023. 09. 14.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 14.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdAccountFindIdVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/id/getBidAuthNum")
	public ResponseEntity<Object> findIdAuth(@RequestBody BdAccountFindIdVO bdAccountFindIdVO, BindingResult bindingResult) {
		Map<String,Object> map = new HashMap<>();
		String phoneNum = bdAccountFindIdVO.getBidPhoneNum();
		customValidator.validate(bdAccountFindIdVO, bindingResult, AccountFindIdVO.findId.class);
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
		}
		try {
			BdEtrVO bdAccount = new BdEtrVO();
			bdAccount.setMoblphonNo2(phoneNum);
			List<BdEtrVO> bdAccountList = bdAccountFindService.selectBidAccountByPhone(phoneNum);
			if(bdAccountList.size() <= 0) {
//				return new ResponseEntity<>(messageUtil.getMessage("co.validation.phone"), HttpStatus.BAD_REQUEST);
				return new ResponseEntity<>(messageSourceAccessor.getMessage("co.validation.phone", Locale.US),HttpStatus.BAD_REQUEST);
				
			}
			String bidAuthNum = bdAccountFindService.bidPhoneAuth(bdAccount);
			String token = jwtTokenProvider.generateSmsToken(bidAuthNum);
			if(profiles.equals("local") || profiles.equals("dev")) {
				map.put("bidAuthNum", bidAuthNum);
			}
			map.put("token", token);
		}catch (Exception e) {
			return new ResponseEntity<>("시스템 오류가 발생했습니다. \n고객센터에 문의 바랍니다.", HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 아이디 찾기 인증번호 확인
	 * </pre>
	 * @date 2023. 09. 14.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 14.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdAccountFindIdVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/id/bidConfirm")
	public ResponseEntity<Object> bidConfirmAuth(@RequestBody BdAccountFindIdVO bdAccountFindIdVO, BindingResult bindingResult) throws Exception {

		customValidator.validate(bdAccountFindIdVO, bindingResult, AccountFindIdVO.confirmId.class);
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
		}
		String token = bdAccountFindIdVO.getToken();
		String authNum = bdAccountFindIdVO.getBidAuthNum();
		String phoneNum = bdAccountFindIdVO.getBidPhoneNum();
		

		List<Map<String, Object>> idList = new ArrayList<>(); //계정 리스트
		try {
			List<BdEtrVO> bdAccountList = bdAccountFindService.selectBidAccountByPhone(phoneNum);
			for(BdEtrVO bdAccount : bdAccountList){
				// 개별 계정 정보
				if(authNum.equals(jwtTokenProvider.getUsername(token))) {
					String bidMberId = bdAccount.getBidMberId();
					String bidMberEtrDt = String.valueOf(bdAccount.getBidMberEtrDt());
					
					Map<String, Object> map = new HashMap<>();
					if (!StringUtil.isNotEmpty(bidMberEtrDt) || bidMberEtrDt.equals("null")){
						bidMberEtrDt = "";
					}
					map.put("id", bidMberId);
					map.put("signUpDate", bidMberEtrDt);
					idList.add(map);
				}
				else {
					return new ResponseEntity<>("인증번호를 확인해 주세요.", HttpStatus.BAD_REQUEST);
				}
			}
		} catch(ExpiredJwtException e) {
			return new ResponseEntity<>("인증번호를 입력한 시간이 초과되었습니다.\n 다시 시도하려면 새로운 인증번호를 요청하세요.", HttpStatus.BAD_REQUEST);
		} catch(Exception e) {
			log.error(e.toString());
			return new ResponseEntity<>("시스템 오류가 발생했습니다.\n 관리자에게 문의해주세요.", HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(idList, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 아이디 찾기 결과화면 이동
	 * </pre>
	 * @date 2023. 09. 14.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 14.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdAccountFindIdList
	 * @param model
	 * @param bindingResult
	 * @return
	 */

	@RequestMapping("/id/bidResult")
	public String findIdResult(@RequestBody List<BdAccountFindIdVO> bdAccountFindIdList, Model model, BindingResult bindingResult) {
		customValidator.validate(bdAccountFindIdList,bindingResult,AccountFindIdVO.findIdResult.class);
		if(bindingResult.hasErrors()) {
			throw new IllegalArgumentException("인증되지 않은 계정입니다.");
		}
		try {
			model.addAttribute("bdAccountFindIdList", bdAccountFindIdList);
			return "/bd/bidFindIdResult";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}


	/**
	 * <pre>
	 * 처리내용: 비밀번호 찾기 화면 이동.
	 * </pre>
	 * @date 2023. 9. 14
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 14				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@RequestMapping(value = "/pw")
	public String findPw(){
		try {
			return "bd/bidFindPw";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 문자 본인 인증 번호 및 토큰 생성
	 * </pre>
	 * @date 2023. 9. 14
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 14				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdAccountFindPwVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/pw/getBidAuthNum")
	public ResponseEntity<Object> getAuthNum(@RequestBody BdAccountFindPwVO bdAccountFindPwVO, BindingResult bindingResult) throws Exception {
		customValidator.validate(bdAccountFindPwVO,bindingResult,BdAccountFindPwVO.findPw.class);
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
		}
		BdEtrVO account = bdAccountFindService.selectBidAccount(bdAccountFindPwVO.getId());
		if( account == null ) {
//			return new ResponseEntity<>(messageUtil.getMessage("co.text.invalid.user"), HttpStatus.BAD_REQUEST);
			return new ResponseEntity<>(messageSourceAccessor.getMessage("co.text.invalid.user", Locale.US),HttpStatus.BAD_REQUEST);
		}
		if(!account.getMoblphonNo2().equals(bdAccountFindPwVO.getBidPhoneNum())) {
//			return new ResponseEntity<>(messageUtil.getMessage("co.validation.phone"), HttpStatus.BAD_REQUEST);
			return new ResponseEntity<>(messageSourceAccessor.getMessage("co.validation.phone", Locale.US),HttpStatus.BAD_REQUEST);
		}
		String bidAuthNum =  bdAccountFindService.bidPhoneAuth(account);
		String token = jwtTokenProvider.generateSmsToken(bidAuthNum);
		String bidEntrpsNo = account.getBidEntrpsNo();

		Map<String,Object> map = new HashMap<>();

		if(profiles.equals("local") || profiles.equals("dev")) {
			map.put("bidAuthNum", bidAuthNum);
		}
		map.put("token", token);
		map.put("bidEntrpsNo",bidEntrpsNo);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}


	/**
	 * <pre>
	 * 처리내용:  문자 본인 인증 번호 토큰 확인
	 * </pre>
	 * @date 2023. 9. 14
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 14				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdAccountFindPwVO
	 * @param bindingResult
	 * @return 
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/pw/getBidToken")
	public ResponseEntity<Object> getToken(@RequestBody BdAccountFindPwVO bdAccountFindPwVO, BindingResult bindingResult) throws Exception {
		Map<String,Object> map = new HashMap<String,Object>();
		customValidator.validate(bdAccountFindPwVO, bindingResult, BdAccountFindPwVO.findPwGetToken.class);
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
		}
		String token = bdAccountFindPwVO.getToken();
		String authNum = bdAccountFindPwVO.getBidAuthNum();
		String bidEntrpsNo = bdAccountFindPwVO.getBidEntrpsNo();

		try {
			if ( !authNum.equals(jwtTokenProvider.getUsername(token)) ) {
//				return new ResponseEntity<>(messageUtil.getMessage("fo.co.text.invalid.authnum"),HttpStatus.BAD_REQUEST);
				return new ResponseEntity<>(messageSourceAccessor.getMessage("fo.co.text.invalid.authnum", Locale.US),HttpStatus.BAD_REQUEST);
			}
			map.put("result", "success");
			map.put("bidEntrpsNo", bidEntrpsNo);
		} catch(ExpiredJwtException e) {
			return new ResponseEntity<>("인증번호 입력시간이 초과되었습니다.\n 다시 시도하려면 새로운 인증번호를 요청하세요.", HttpStatus.BAD_REQUEST);
		} catch(Exception e) {
			log.error(e.toString());
			return new ResponseEntity<>("시스템 오류가 발생했습니다.\n 관리자에게 문의해주세요.", HttpStatus.BAD_REQUEST);
		}
		return  new ResponseEntity<>(map,HttpStatus.OK);
	}


	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경 화면으로 이동.
	 * </pre>
	 * @date 2023. 9. 14
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 14				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdAccountFindPwVO
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/pw/change")
	public String changePw(@RequestBody BdAccountFindPwVO bdAccountFindPwVO, Model model) {
		try {
			Optional<String> bidEntrpsNoOptional = Optional.ofNullable(bdAccountFindPwVO.getBidEntrpsNo());
			model.addAttribute("bidEntrpsNo", bidEntrpsNoOptional.orElse(""));
			Optional<String> bidMberIdOptional = Optional.ofNullable(bdAccountFindPwVO.getBidMberId());
			model.addAttribute("bidMberId", bidMberIdOptional.orElse(""));
			return "bd/bidChangePw";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경.
	 * </pre>
	 * @date 2023. 9. 14
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 14				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdAccountFindPwVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping(value ="/pw/new")
	public ResponseEntity<Object> getNewPassword(@RequestBody BdEtrVO bdAccountFindPwVO, BindingResult bindingResult) {

		customValidator.validate(bdAccountFindPwVO,bindingResult);
		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		Map<String, Object> map = new HashMap<String,Object>();
		try {
			bdAccountFindPwVO = cryptAccount(bdAccountFindPwVO);
			bdAccountFindService.bidUpdatePw(bdAccountFindPwVO);
			map.put("result", "success");
		}
		catch (Exception e) {
			return new ResponseEntity<>("비밀번호 변경이 실패했습니다.", HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(map,HttpStatus.OK);
	}
	public BdEtrVO cryptAccount(BdEtrVO account) {
		account.setBidMberSecretNo(Optional.of(account.getBidMberSecretNo()).map(CryptoUtil::encryptSHA256).get());
		return account;
	}

	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경 결과 화면이동.
	 * </pre>
	 * @date 2023. 9. 14
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 14				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@RequestMapping(value = "/pw/result")
	public String changePwResult() {
		try {
			return "bd/bidChangePwResult";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}
}


