package com.sorincorp.fo.bd.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.bd.model.BdBidVO;
import com.sorincorp.fo.bd.model.BdFaqVO;
import com.sorincorp.fo.bd.model.BdNoticeVO;
import com.sorincorp.fo.bd.service.BdFaqService;
import com.sorincorp.fo.bd.service.BdMainService;
import com.sorincorp.fo.bd.service.BdNoticeService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.service.AccountServiceImpl;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class BdMainController {
    
    @Autowired
    UserInfoUtil userInfoUtil;
    
    @Autowired(required=false)
    BdMainService bdMainService;
    
    @Autowired
    BdNoticeService bdNoticeService; 
    
    @Autowired
    BdFaqService bdFaqService;
    
    @Autowired
	AccountServiceImpl accountService;
    
    /**
     * <pre>
     * 처리내용: 케이지트레이딩 구매입찰 메인 호출 컨트롤러
     * </pre>
     * @date 2023. 08. 21.
     * @author sein
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 08. 21.        sein                최초작성
     * 2023. 08. 25.        srec0077            로그인처리
     * ------------------------------------------------
     * @param vo
     * @param model
     * @return
     * @throws Exception
     */
    @RequestMapping("/bid")
    public String bidMain(Model model, HttpServletRequest request) throws Exception {

    	Map<String,Object> bdLoginStatusMap = new HashMap<String,Object>();
        BdAccount account = userInfoUtil.getBdAccountInfo(request);
        
        BdAccount mainDashboard = new BdAccount();
        int mainBdIntrstBidCnt = 0;

        if ( account == null) {
            bdLoginStatusMap.put("loginYn","N");
        }else {
            bdLoginStatusMap.put("loginYn","Y");
            if(account.getBidEntrpsNo() != null)  {
                String entrpsNo = account.getBidEntrpsNo();
                mainDashboard.setBidEntrpsNo(entrpsNo);
                bdLoginStatusMap.put("entrpsNo", entrpsNo);
                mainDashboard = bdMainService.getBdUserDashboardData(mainDashboard);
                mainBdIntrstBidCnt = bdMainService.getBdIntrstBidCnt(entrpsNo);
            }
        }

        BdNoticeVO noticeVo = new BdNoticeVO();                                                 // 공지사항 VO
        BdFaqVO faqVo = new BdFaqVO();                                            // FAQ VO               
        
        List<BdNoticeVO> showNotice = bdNoticeService.showNotice(noticeVo);                 //공지사항 최근 게시글 제목 4개 가져오기
        model.addAttribute("showNotice", showNotice);
                    
        List<BdFaqVO> showFaq = bdFaqService.showFaq(faqVo);                  //faq 최근 질문 4개 가져오기
        model.addAttribute("showFaq",showFaq);  

        model.addAttribute("bdAccount", account);
        model.addAttribute("mainBdIntrstBidCnt", mainBdIntrstBidCnt);
        model.addAttribute("bdLoginStatusMap", bdLoginStatusMap); // 로그인 여부
        model.addAttribute("mainDashboard", mainDashboard);
        
        
        return "bdTiles/bdMain";

    }
    
	@RequestMapping("/selectBdMainInfoList")
	public ResponseEntity<?> selectBdMainInfoList(@RequestBody BdBidVO bdBidVO, Model model) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			List<BdBidVO> mainBdList = bdMainService.selectBdMainList(bdBidVO);
			List<BdBidVO> mainBdCnt = bdMainService.selectBdMainCnt(bdBidVO);

			int totalCnt = 0;
			int expectCnt = 0;
			int bidingCnt = 0;
			int endCnt = 0;
			//입찰예정,투찰중,(마감,서류접수중,서류심사중,유찰)
			for (BdBidVO vo : mainBdCnt) {
				if (vo.getBidSttusCode().equals("12")) {
					expectCnt += vo.getMainBdCnt();
				} else if (vo.getBidSttusCode().equals("13")) {
					bidingCnt += vo.getMainBdCnt();
				} else if (vo.getBidSttusCode().equals("31") || vo.getBidSttusCode().equals("22") || vo.getBidSttusCode().equals("23") || vo.getBidSttusCode().equals("32")) {
					endCnt += vo.getMainBdCnt();
				}
				totalCnt += vo.getMainBdCnt();
			}

			map.put("mainBdList", mainBdList);
			map.put("totalCnt", totalCnt);
			map.put("expectCnt", expectCnt);
			map.put("bidingCnt", bidingCnt);
			map.put("endCnt", endCnt);

			return new ResponseEntity<>(map, HttpStatus.OK);

		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping("/bidSttusChk")
	public ResponseEntity<?> bidSttusChk(@RequestBody BdBidVO bdBidVO, Model model) throws Exception {
		BdAccount account = userInfoUtil.getBdAccountInfo();
		System.out.println("account:::"+account);
	   try {
		   if ( account != null) {
			   BdAccount sttusChk = accountService.selectBdAccount(account.getBidMberId());
			   System.out.println("sttusChk:::"+sttusChk);
				if(sttusChk.getBidMberSttusCode().equals("03") && sttusChk.getBidConfmSttusCode().equals("01") && sttusChk.getBidConfmDetailSttusCode().equals("01")) {
					return new ResponseEntity<>("관리자 승인 대기 상태입니다. 승인후 로그인 가능합니다.(관리자에게 문의하세요)", HttpStatus.BAD_REQUEST);
				}else if(sttusChk.getBidMberSttusCode().equals("02")){
					return new ResponseEntity<>("귀사의 계정이 차단되었습니다. 관리자에게 문의하세요.", HttpStatus.BAD_REQUEST);
				}
		   }else {
			   return new ResponseEntity<>("로그인 후 열람하실 수 있습니다", HttpStatus.BAD_REQUEST);
	        }
		   return new ResponseEntity<>(true, HttpStatus.OK);

		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}
}
