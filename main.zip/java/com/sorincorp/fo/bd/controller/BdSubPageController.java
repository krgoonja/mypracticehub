package com.sorincorp.fo.bd.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.bd.model.BdBidVO;
import com.sorincorp.fo.bd.model.BdFaqVO;
import com.sorincorp.fo.bd.model.BdNoticeVO;
import com.sorincorp.fo.bd.service.BdFaqService;
import com.sorincorp.fo.bd.service.BdMainService;
import com.sorincorp.fo.bd.service.BdNoticeService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.service.AccountServiceImpl;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/bid")
public class BdSubPageController {
    
    @Autowired
    UserInfoUtil userInfoUtil;
    
    @Autowired
    AccountServiceImpl accountService;

    /**
     * <pre>
     * 처리내용: 구매입찰 소개 화면.
     * </pre>
     * @date 2023. 9. 27.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일               작성자            변경내용
     * ------------------------------------------------
     * 2023. 9. 27.         srec0077         최초작성
     * ------------------------------------------------
     * @return
     * @throws Exception
     */
     @RequestMapping("/info")
     public String showBidInfoPage(ModelMap model) {
         try {

             return "bd/bidInfo";
         } catch (Exception e) {

             log.error(e.getMessage());
             return "error/503";
         }
     }

}
