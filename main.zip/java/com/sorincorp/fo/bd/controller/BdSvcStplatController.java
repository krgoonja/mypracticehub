package com.sorincorp.fo.bd.controller;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.fo.cs.model.SvcStplatVO;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.service.EntrpsEtrService;

import lombok.extern.slf4j.Slf4j;

/**
 * BdSvcStplatController.java
 * @version
 * @since 2023. 10. 10.
 * @author bok3117
 */
@Slf4j
@Controller
@RequestMapping("/bid/svcstplat")
public class BdSvcStplatController {
	
	@Autowired
	private EntrpsEtrService entrpsEtrService;
	
	/**
	 * <pre>
	 * 처리내용: 구매입찰 서비스약관 조회 화면을 보여준다.
	 * </pre>
	 * @date 2023. 10. 10.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 10.		bok3117				최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/showSvcStplatList")
	public String showSvcStplatList(ModelMap model) {
		try {
			return "bd/bidSvcStplatList";
		} catch(Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 구매입찰 서비스약관 조회 화면을 조회한다.
	 * </pre>
	 * @date 2023. 10. 10.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 10.		bok3117				최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectSvcStplatList")
	@ResponseBody
	public Map<String, Object> selectSvcStplatList() throws Exception {
		Map<String, Object> map = new HashedMap<>();
		List<EntrpsEtrVO> stplatList = entrpsEtrService.selectEntrpsEtrStplat();
		map.put("dataList", stplatList);

		return map;
	}
	
}
