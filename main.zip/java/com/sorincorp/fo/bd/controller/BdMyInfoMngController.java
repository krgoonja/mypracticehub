package com.sorincorp.fo.bd.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.fo.bd.model.BdMyInfoMngVO;
import com.sorincorp.fo.bd.service.BdMyInfoMngService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.service.EntrpsEtrService;

import lombok.extern.slf4j.Slf4j;

/**
 * BdMyInfoMngController.java
 * @version
 * @since 2023. 9. 6.
 * @author bok3117
 */
@Slf4j
@Controller
@RequestMapping("/bid/myPage")
public class BdMyInfoMngController {
	
	@Autowired
	private BdMyInfoMngService bdMyInfoMngService;
	
	@Autowired
	private EntrpsEtrService entrpsEtrService;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 > 내정보관리 페이지 조회 (비밀번호 확인)
	 * </pre>
	 * @date 2023. 9. 6.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 6.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectBdMyInfoMng")
	public String electMyInfoMng(ModelMap model) {
		try {
			return "bd/bidMyInfoMng";
		} catch(Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 > 내정보관리 페이지 조회 (내정보관리 페이지)
	 * </pre>
	 * @date 2023. 9. 7.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 7.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectMyInfoMngDtl")
	public String selectMyInfoMngDtl(ModelMap model) {
		try {
			String bidEntrpsNo = userInfoUtil.getBdAccountInfo().getBidEntrpsNo();
			BdMyInfoMngVO myInfoMngVO = bdMyInfoMngService.selectMyInfoMngDtl(bidEntrpsNo);
			String bsnmRegistNo = myInfoMngVO.getBsnmRegistNo();
			String vrscBsnmRegistNo = myInfoMngVO.getVrscBsnmRegistNo();
			List<EntrpsEtrVO> stplatList = entrpsEtrService.selectEntrpsEtrStplat();

			//사업자 등록증 파일 경로 조회
			String bsnmFilePath = bdMyInfoMngService.selectDocNo(myInfoMngVO.getBsnmRegistDocNo1());
			String vrscBsnmFilePath = bdMyInfoMngService.selectDocNo(myInfoMngVO.getBsnmRegistDocNo2());

			// 사업자 등록 번호 형식 변경
			if(StringUtil.isNotEmpty(bsnmRegistNo)) {
				String formattedBsnmRegistNo = bsnmRegistNo.substring(0, 3) + "-" + bsnmRegistNo.substring(3, 5) + "-" + bsnmRegistNo.substring(5);
				myInfoMngVO.setBsnmRegistNo(formattedBsnmRegistNo);
			}
			if(StringUtil.isNotEmpty(vrscBsnmRegistNo)) {
				String formattedVrscBsnmRegistNo = vrscBsnmRegistNo.substring(0, 3) + "-" + vrscBsnmRegistNo.substring(3, 5) + "-" + vrscBsnmRegistNo.substring(5);
				myInfoMngVO.setVrscBsnmRegistNo(formattedVrscBsnmRegistNo);
			}
			
			model.addAttribute("stplatList", stplatList);
			model.addAttribute("myInfoMngVO", myInfoMngVO);
			model.addAttribute("bsnmFilePath", bsnmFilePath);
			model.addAttribute("vrscBsnmFilePath", vrscBsnmFilePath);

			return "bd/bidMyInfoMngDtl";
		} catch(Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 휴대폰 번호 변경
	 * </pre>
	 * @date 2023. 9. 11.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 11.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/updateMoblphonNo")
	@ResponseBody
	public void updateMoblphonNo(@RequestBody BdMyInfoMngVO myInfoMngVo) throws Exception {
		if(userInfoUtil.getBdAccountInfo() != null) {
			String bidEntrpsNo = userInfoUtil.getBdAccountInfo().getBidEntrpsNo();
			myInfoMngVo.setBidEntrpsNo(bidEntrpsNo);
			bdMyInfoMngService.updateMoblphonNo(myInfoMngVo);
		}
	}
}
