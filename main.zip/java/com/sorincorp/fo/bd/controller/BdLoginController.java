package com.sorincorp.fo.bd.controller;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.bd.model.BdLoginVO;
import com.sorincorp.fo.config.LoginTokenProvider;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.service.AccountServiceImpl;

import org.springframework.context.support.MessageSourceAccessor;
import io.jsonwebtoken.ExpiredJwtException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Controller
@RequestMapping("/bid")
@Slf4j
public class BdLoginController {
    private final PasswordEncoder passwordEncoder;
    private final LoginTokenProvider loginTokenProvider;
    private final AccountServiceImpl accountService;
    private final MessageSourceAccessor messageSourceAccessor;
    private final MessageUtil messageUtil;
    private final RedisUtil redisUtil;

    @Autowired
    UserInfoUtil userInfoUtil;
    
    @Value("${spring.profiles.active}")
    private String profiles;

    @RequestMapping("/bdLogin")
    public String bdLogin(HttpServletRequest request, HttpServletResponse response) {
        try {
            return "bd/bdLoginMain";
        } catch (Exception e) {
            log.error("bdLogin Error ====> {}", ExceptionUtils.getStackTrace(e));
            return "error/503";
        }
    }

    @ResponseBody
    @PostMapping("/bdLogin/memberVal")
    public ResponseEntity<Object> memberVal(@RequestBody BdLoginVO loginVO, BindingResult bindingResult) throws Exception {
        Map<String,Object> map = new HashMap<>();

        //customValidator.validate(loginVO, bindingResult, BdLoginVO.loginInfo.class);

        /*if(bindingResult.hasErrors()) {
            return new ResponseEntity<>(bindingResult.getAllErrors(),HttpStatus.BAD_REQUEST);
        }*/

        BdAccount account = accountService.selectBdAccount(loginVO.getId());

        if ( account == null ) {
            //return new ResponseEntity<>(messageUtil.getMessage("fo.co.text.invalid.user"),HttpStatus.BAD_REQUEST);
            return new ResponseEntity<>(messageSourceAccessor.getMessage("fo.co.text.invalid.user", Locale.US),HttpStatus.BAD_REQUEST);
        }

        if ( !passwordEncoder.matches(CryptoUtil.encryptSHA256(loginVO.getPassword()), "{noop}" + account.getPassword()) ) {

            if(account.getBidMberSttusCode().equals("02")) { // 잠금 회원(02)일 경우에만 체크
//                return new ResponseEntity<>(messageUtil.getMessage("fo.bid.exception.user.cancl.pnt"),HttpStatus.BAD_REQUEST);
            	return new ResponseEntity<>(messageSourceAccessor.getMessage("fo.bid.exception.user.cancl.pnt", Locale.US),HttpStatus.BAD_REQUEST);
            }


//            return new ResponseEntity<>(messageUtil.getMessage("fo.co.text.invalid.password"),HttpStatus.BAD_REQUEST);
            return new ResponseEntity<>(messageSourceAccessor.getMessage("fo.co.text.invalid.password", Locale.US),HttpStatus.BAD_REQUEST);
            
        }
        return new ResponseEntity<>(map,HttpStatus.OK);
    }
    
    @ResponseBody
    @PostMapping("/bdLogin/getToken")
    public ResponseEntity<Object> getToken(@RequestBody BdLoginVO loginVO, HttpServletRequest request
            , HttpServletResponse response, BindingResult bindingResult) {
        //customValidator.validate(loginVO, bindingResult, LoginVO.loginAuth.class);

        try {
            BdAccount account = accountService.selectBdAccount(loginVO.getId());

            if ( account == null ) {
//                return new ResponseEntity<>(messageUtil.getMessage("co.text.invalid.user"), HttpStatus.BAD_REQUEST);
                return new ResponseEntity<>(messageSourceAccessor.getMessage("fo.co.text.invalid.user", Locale.US),HttpStatus.BAD_REQUEST);
            }

            if ( !passwordEncoder.matches(CryptoUtil.encryptSHA256(loginVO.getPassword()), "{noop}" + account.getPassword()) ) {
//                return new ResponseEntity<>(messageUtil.getMessage("co.text.invalid.password"), HttpStatus.BAD_REQUEST);
                return new ResponseEntity<>(messageSourceAccessor.getMessage("fo.co.text.invalid.password", Locale.US),HttpStatus.BAD_REQUEST);
            }

            if(account.getBidMberSttusCode().equals("03") && account.getBidConfmDetailSttusCode().equals("01")) { // 승인 대기 회원 && 회원가입요청회원
//                return new ResponseEntity<>(messageUtil.getMessage("bid.exception.user.confm.wait"), HttpStatus.BAD_REQUEST); 
                return new ResponseEntity<>(messageSourceAccessor.getMessage("bid.exception.user.confm.wait", Locale.US),HttpStatus.BAD_REQUEST);
            } else if(account.getBidMberSttusCode().equals("02") && account.getBddprCnt() > 3) { // 차단 회원 (투찰취소횟수 초과)
//                return new ResponseEntity<>(messageUtil.getMessage("bid.exception.user.cancl.pnt"), HttpStatus.BAD_REQUEST);
                return new ResponseEntity<>(messageSourceAccessor.getMessage("fo.bid.exception.user.cancl.pnt", Locale.US),HttpStatus.BAD_REQUEST);
            } else if(account.getBidMberSttusCode().equals("02")) {
//                return new ResponseEntity<>(messageUtil.getMessage("bid.exception.user.login.intrcp"), HttpStatus.BAD_REQUEST); 
                return new ResponseEntity<>(messageSourceAccessor.getMessage("bid.exception.user.login.intrcp", Locale.US),HttpStatus.BAD_REQUEST);
            }
            
            BdLoginVO logVo = new BdLoginVO();
            logVo.setLoginIp(HttpUtil.getClientIp(request));
            logVo.setBidEntrpsNo(account.getBidEntrpsNo());
            logVo.setId(account.getBidMberId());

            //Token 생성전에 패스워드정보를 제외한다.
            account.setBidMberSecretNo(null);

           /* if(account.getMberSttusCode().equals("05")) {
                Map<String,Object> map = new HashMap<>();
                logVo.setLoginSttusCode("03"); //계정 잠금
                map.put("result", "inActive");
                map.put("account", account);
                accountMapper.insertLoginHist(logVo);
                return new ResponseEntity<>(map, HttpStatus.OK);
            }

            if(accountService.selectNextPwChgDate(account) <= 0) {
                Map<String,Object> map = new HashMap<>();
                logVo.setLoginSttusCode("03");  // 로그인 로그 계정 잠금
                accountMapper.insertLoginHist(logVo);
                map.put("result", "pwUpdate");
                map.put("id",account.getId());
                return new ResponseEntity<>(map, HttpStatus.OK);
            }
            
            if (account.getMberSttusCode().equals("02")) { // 정회원 계정잠김(02)
                account.setMberSttusCode("01"); // 회원 기본 정회원
                account.setLoginSttusCode("04"); // 히스토리 계정 잠김 해제
                accountService.updateMberSttusCd(account); // 회원 상태 정회원으로 수정 (01)
                accountService.updateMberSttusCdHist(account);// 히스토리 계정 잠김 해제 (04)
                accountService.resetLoginFailCount(account); // 비밀번호 오류횟수 0으로 리셋
            }
            */
            
            // Access Token, Refresh Token 생성
            final String access = loginTokenProvider.generateBdAccessToken(account, account.getBidMberId());
            final String refresh = loginTokenProvider.generateBdRefreshToken(account.getBidMberId());

            // Access Token, Refresh Token을 저장할 Cookie 생성
            ResponseCookie accessToken = loginTokenProvider.createSecureCookie(CommonConstants.BID_ACCESS_TOKEN_NAME, access, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);
            ResponseCookie refreshToken = loginTokenProvider.createSecureCookie(CommonConstants.BID_REFRESH_TOKEN_NAME, refresh, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND);

            // Token을 Redis에 저장(만료기간 지정)
            redisUtil.setDataExpire(CommonConstants.REDIS_KEY_BID_ACCESS + account.getBidMberId(), access, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND+5000L);
            redisUtil.setDataExpire(CommonConstants.REDIS_KEY_BID_REFRESH + account.getBidMberId(), refresh, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND+5000L);

            // 아이디저장 쿠키 제거, 생성은 bdMain.jsp
            if(!loginVO.getSaveId()) {
                ResponseCookie saveIdCookie = loginTokenProvider.createSecureCookie("saveBidId",null,0);
                response.addHeader(HttpHeaders.SET_COOKIE, saveIdCookie.toString());
            }

            // Token Cookie를 Response에 추가
            response.addHeader(HttpHeaders.SET_COOKIE, accessToken.toString());
            response.addHeader(HttpHeaders.SET_COOKIE, refreshToken.toString());

            return new ResponseEntity<>("bdLogin", HttpStatus.OK);
         
        } catch (ExpiredJwtException e) {
//            return new ResponseEntity<>(messageUtil.getMessage("co.text.invalid.authtime.expired"), HttpStatus.BAD_REQUEST);
            return new ResponseEntity<>(messageSourceAccessor.getMessage("co.text.invalid.authtime.expired", Locale.US),HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
            return null;
        }
    }

    /**
     * <pre>
     * 처리내용: 로그아웃
     * </pre>
     * @date 2023. 8. 25.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 8. 25.         srec0077            최초작성
     * ------------------------------------------------
     * @return
     */
   @GetMapping("/bdLogin/bdLogout")
    public void logout(HttpServletRequest request, HttpServletResponse response) throws Exception {

        // Access Token Cookie 조회
        Cookie accessToken = loginTokenProvider.getCookie(request, CommonConstants.BID_ACCESS_TOKEN_NAME);
        if ( accessToken != null ) {
            ResponseCookie responseAccesstoken = loginTokenProvider.createSecureCookie(CommonConstants.BID_ACCESS_TOKEN_NAME,null,0);
            response.addHeader(HttpHeaders.SET_COOKIE, responseAccesstoken.toString());

            redisUtil.deleteData(CommonConstants.REDIS_KEY_BID_ACCESS + loginTokenProvider.getUsername(accessToken.getValue()));
        }

        // Refresh Token Cookie 조회
        Cookie refreshToken = loginTokenProvider.getCookie(request, CommonConstants.BID_REFRESH_TOKEN_NAME);
        if ( refreshToken != null ) {
            // Cookie가 있으면 Cookie 삭제
            ResponseCookie responseRefreshToken = loginTokenProvider.createSecureCookie(CommonConstants.BID_REFRESH_TOKEN_NAME,null,0);
            response.addHeader(HttpHeaders.SET_COOKIE, responseRefreshToken.toString());
            // Redis에서 Refresh Token 삭제
            redisUtil.deleteData(CommonConstants.REDIS_KEY_BID_REFRESH + loginTokenProvider.getUsername(refreshToken.getValue()));
        }
    }
   
  /**
   * <pre>
   * 처리내용: 비밀번호 확인
   * </pre>
  *  @date 2023. 08. 29.
   * @author sein
   * @history
   * ------------------------------------------------
   * 변경일                   작성자             변경내용
   * ------------------------------------------------
   * 2023. 08. 29.     sein                최초작성
   * ------------------------------------------------
   * @param String
   * @return 
   * @throws Exception
   */
   @ResponseBody
   @RequestMapping("/bidcheckPwAjax")
   public ResponseEntity<?> bidcheckPwAjax(@RequestBody String bidchkPw) throws Exception {
       try {
           
           BdAccount account = userInfoUtil.getBdAccountInfo();
           
           //로그인 상태 여부
           if (account != null) {
               // JSON을 String변환
               JSONObject jObject = new JSONObject(bidchkPw);
               String password = jObject.getString("password");
               // 비밀 번호가 일치하면 true
               if (CryptoUtil.encryptSHA256(password)
                       .matches(accountService.selectBdAccount(account.getBidMberId()).getBidMberSecretNo())) {
                   return new ResponseEntity<>("success", HttpStatus.OK); // ajax success 데이터 전달
               } else {
                   // 비밀 번호가 일치 안하면 false
                   return new ResponseEntity<>("fail", HttpStatus.OK); // ajax success 데이터 전달
               }
           } else {
               // 로그아웃 시
               return new ResponseEntity<>("logout", HttpStatus.OK); // ajax success 데이터 전달
           }
       } catch (Exception e) {
           e.printStackTrace();
           log.error(e.getMessage());
           return new ResponseEntity<>("bidcheckPwAjax 오류.", HttpStatus.BAD_REQUEST);

       }
   }
   
   
}
