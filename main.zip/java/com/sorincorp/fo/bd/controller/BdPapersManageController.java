package com.sorincorp.fo.bd.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.fo.my.model.PapersManageDetailVO;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * oz호출 Controller.java
 * @version
 * @since 2023. 10. 05.
 * @author srec0077
 */
@Slf4j
@Controller
@RequestMapping("/bid/papersManage")
public class BdPapersManageController {
	
	@Autowired
	FileDocService fileDocService;
	
	@Value("${oz.connection.reportname}")
	private String reportName;
	
	@Value("${oz.db.alias}")
	private String dbAlias;
	
	/**
	 * 
	 * <pre>
	 * 마이페이지 > 낙찰 확인서 > 오즈리포트 호출
	 * </pre>
	 * @date 2023. 10. 05.
	 * @author srec0077
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 05.			srec0077			최초작성
	 * ------------------------------------------------
	 * @param 	PapersManageDetailVO paramVo
	 * @param 	ModelMap model
	 * @return	String
	 * @throws 	Exception
	 */
	@RequestMapping(value = "/papersManageOzReport", method={RequestMethod.GET, RequestMethod.POST})
	public String papersManageOzReport(PapersManageDetailVO paramVo, ModelMap model) throws Exception {
		log.debug("PapersManageController::papersManageOzReport Start");
		log.debug("param1 = " + paramVo.getParam1());
		log.debug("param2 = " + paramVo.getParam2());
		log.debug("tabDiv = " + paramVo.getTabDiv());
		log.debug("reportName 	= " + reportName);
		log.debug("dbAlias 		= " + dbAlias);
		
		
		model.addAttribute("PARAM1"		, paramVo.getParam1());
		model.addAttribute("PARAM2"		, paramVo.getParam2());
		model.addAttribute("TAB_DIV"	, paramVo.getTabDiv());
		model.addAttribute("REPORT_NAME", reportName);
		model.addAttribute("DB_ALIAS"	, dbAlias);
		
		log.debug("PapersManageController::papersManageOzReport End");
		return "bd/bidOzReport";
	}//end papersManageOzReport()
	
}//end class()
