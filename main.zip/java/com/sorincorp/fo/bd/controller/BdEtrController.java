package com.sorincorp.fo.bd.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.service.EntrpsEtrService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.fo.bd.model.BdEtrVO;
import com.sorincorp.fo.bd.service.BdEtrService;
//import com.sorincorp.fo.bd.service.BdMainService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.mb.model.MbCmnCodeVO;
import com.sorincorp.fo.mb.service.MbCmnCodeService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartHttpServletRequest;

@RequiredArgsConstructor
@Slf4j
@Controller
@RequestMapping("/bid")
public class BdEtrController {

	@Autowired
	private EntrpsEtrService entrpsEtrService;

	@Autowired
    UserInfoUtil userInfoUtil;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	@Autowired
	private BdEtrService bdEtrService;

	
	/**
	 * <pre>
	 * 처리내용: 회원가입 페이지 호출
	 * </pre>
	 * @date 2023. 08. 24.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 24.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/bidEtr")
	public String bidEtr(ModelMap model) {
		try {
			List<EntrpsEtrVO> stplatList = entrpsEtrService.selectEntrpsEtrStplat();
			model.addAttribute("stplatList", stplatList);
			return "bd/bidEtr";
			//return "bd/newEtrInfo";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 구매입찰 회원정보 입력페이지 이동
	 * </pre>
	 * @date 2023. 08. 24.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 24.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdEtrVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/bidEtrInfo")
	public String bidEtrInfo(@RequestBody BdEtrVO bdEtrVO, ModelMap model) {
		try {
			List<MbCmnCodeVO> domainList = mbCmnCodeService.selectCmnCodeList("EMAIL_DOMAIN");
			List<MbCmnCodeVO> nationNoCodeList = bdEtrService.selectNationNoCodeList();
			model.addAttribute("domainList", domainList);
			model.addAttribute("nationNoCodeList", nationNoCodeList);
			model.addAttribute("bdEtrVO", bdEtrVO);
			return "bd/bidEtrInfo";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 회원가입 insert
	 * </pre>
	 * @date 2023. 08. 24.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 24.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdEtrVO
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/insertBidEtrInfo")
	@ResponseBody
	public ResponseEntity<Object> bidEtrInfo(@RequestBody BdEtrVO bdEtrVO) {
		Map<String, String>	resMap = new HashMap<>();
		String res = "";
		try {
			res = bdEtrService.insertBidEtrInfo(bdEtrVO);
			resMap.put("res",res);

		} catch (Exception e) {
			log.error(e.getMessage());
			resMap.put("res",res);
			return new ResponseEntity<>(resMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(resMap, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 회원가입 약관 동의 페이지 이동
	 * </pre>
	 * @date 2023. 08. 24.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 24.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/bidEtrRes")
	public String bidEtrRes() {
		return "bd/bidEtrRes";
	}


	/**
	 * <pre>
	 * 처리내용: 구매입찰 아이디 찾기 페이지 호출
	 * </pre>
	 * @date 2023. 09. 07.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 07.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/bidFindId")
	public String bidFindId() {
		return "bd/bidFindId";
	}

	/**
	 * <pre>
	 * 처리내용: 회원가입 아이디, 사업자 등록 번호 중복체크
	 * </pre>
	 *
	 * @date 2023. 09. 07.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 07.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdEtrVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/checkEtrInfo")
	@ResponseBody
	public ResponseEntity<Object> checkEtrInfo(@RequestBody BdEtrVO bdEtrVO) throws Exception {
		Map<String, String>	resMap = new HashMap<>();
		try {
			String bsnmRegistNo = bdEtrVO.getBsnmRegistNo();
			String vrscBsnmRegistNo = bdEtrVO.getVrscBsnmRegistNo();
			log.debug("BdEtrController ::  bidCheckBsnmRegistNo bsnmRegistNo : " + bsnmRegistNo + "bsnmRegistNo : " + vrscBsnmRegistNo);
			String msg = bdEtrService.checkEtrInfo(bdEtrVO);
			resMap.put("res","S");
			resMap.put("msg",msg);
		} catch (Exception e) {
			log.error(e.getMessage());
			resMap.put("res","F");
			return new ResponseEntity<>(resMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(resMap, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 사업자 등록번호 중복체크
	 * </pre>
	 *
	 * @date 2023. 09. 07.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 07.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdEtrVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/checkRegistNo")
	@ResponseBody
	public ResponseEntity<Object> checkRegistNo(@RequestBody BdEtrVO bdEtrVO) throws Exception {
		Map<String, String>	resMap = new HashMap<>();
		try {
			String bsnmRegistNo = bdEtrVO.getBsnmRegistNo();
			log.debug("BdEtrController ::  bidCheckBsnmRegistNo bsnmRegistNo : " + bsnmRegistNo);
			String msg = bdEtrService.checkRegistNo(bdEtrVO);
			resMap.put("res","S");
			resMap.put("msg",msg);
		} catch (Exception e) {
			log.error(e.getMessage());
			resMap.put("res","F");
			return new ResponseEntity<>(resMap, HttpStatus.OK);
		}
		return new ResponseEntity<>(resMap, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 파일 업로드
	 * </pre>
	 *
	 * @date 2023. 09. 07.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 07.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param mRequest
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@RequestMapping("/bidEtrFileUpload")
	public ResponseEntity<Object> bidEtrFileUpload(MultipartHttpServletRequest mRequest) throws Exception {
		String errMsg = "";
		HashMap<String, String> fileMap = new HashMap<>();
		try {
			fileMap = bdEtrService.bidEtrFileUpload(mRequest);
		} catch (Exception e) {
			errMsg = fileMap.get("errMsg");
			log.debug("errMsg ======>" + errMsg);
			log.error(e.toString());
		} finally {
			errMsg = fileMap.get("errMsg");
			if (errMsg != null && !"".equals(errMsg)) {
				log.error("ERROR ===============>" + errMsg);
				return new ResponseEntity<>(errMsg, HttpStatus.BAD_REQUEST);
			} else {
				return new ResponseEntity<>(fileMap, HttpStatus.OK);
			}
		}
	}

	/**
	 * <pre>
	 * 처리내용: 파일 삭제
	 * </pre>
	 * @date 2023. 09. 07.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 09. 07.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdEtrVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/deleteBidFile")
	@ResponseBody
	public ResponseEntity<?> deleteBidFile(@RequestBody BdEtrVO bdEtrVO) throws Exception {
		// 리턴값
		Map<String, Object> retVal = new HashMap<String, Object>();

		int resultDelCoAt = bdEtrService.deleteBidFile(bdEtrVO);
		if(resultDelCoAt > 0) {
			retVal.put("code", "S");
		}else {
			retVal.put("code", "F");
		}

		return new ResponseEntity<>(retVal, HttpStatus.OK);
	}

}


