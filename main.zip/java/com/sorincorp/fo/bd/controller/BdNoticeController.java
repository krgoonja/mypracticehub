package com.sorincorp.fo.bd.controller;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.fo.bd.model.BdNoticeVO;
import com.sorincorp.fo.bd.service.BdNoticeService;

import lombok.extern.slf4j.Slf4j;

/**
 * BidNoticeController.java
 * 
 */

@Slf4j
@Controller
@RequestMapping("/bid/notice")
public class BdNoticeController {
	
	@Autowired
	private BdNoticeService BidnoticeService;

   /**
    * <pre>
    * 처리내용: 공지사항 목록 화면을 조회한다.
    * </pre>
    * @date 2021. 8. 25.
    * @author srec0033
    * @history
    * ------------------------------------------------
    * 변경일               작성자            변경내용
    * ------------------------------------------------
    * 2021. 8. 25.         srec0033         최초작성
    * ------------------------------------------------
    * @return
    * @throws Exception
    */
	@RequestMapping("/showNoticeList")
	public String showNoticeList(@RequestBody(required = false) BdNoticeVO vo, ModelMap model) {
		try {
			model.addAttribute("notice", vo);
			model.addAttribute("totalRowCount", BidnoticeService.selectNoticeListTotcnt(vo));
			model.addAttribute("pageIndex", 1);
			model.addAttribute("pageSize", 10);
			model.addAttribute("rowCountPerPage", 10);

			return "bd/bidNoticeList";
		} catch (Exception e) {

			log.error(e.getMessage());
			return "error/503";
		}
	}
   /**
    * <pre>
    * 처리내용: 공지사항 목록을 조회한다.
    * </pre>
    * @date 2021. 8. 25.
    * @author srec0033
    * @history
    * ------------------------------------------------
    * 변경일               작성자            변경내용
    * ------------------------------------------------
    * 2021. 8. 25.         srec0033         최초작성
    * ------------------------------------------------
    * @param vo
    * @return
    * @throws Exception
    */
	@PostMapping("/searchListNotice")
	@ResponseBody
	public Map<String, Object> searchListNotice(@RequestBody BdNoticeVO vo) throws Exception {
		Map<String, Object> map = new HashedMap<>();
		List<BdNoticeVO> expsrList = BidnoticeService.selectListNoticeUpendexpsr();
		List<BdNoticeVO> noticeList = BidnoticeService.searchListNotice(vo);
		int noticeTotCnt = BidnoticeService.selectNoticeListTotcnt(vo);

		map.put("expsrList", expsrList);
		map.put("dataList", noticeList);
		map.put("totalRowCount", noticeTotCnt);
		return map;
	}
   
   /**
    * <pre>
    * 처리내용: 공지사항을 상세조회한다.
    * </pre>
    * @date 2021. 8. 25.
    * @author srec0033
    * @history
    * ------------------------------------------------
    * 변경일               작성자            변경내용
    * ------------------------------------------------
    * 2021. 8. 25.         srec0033         최초작성
    * ------------------------------------------------
    * @return
    * @throws Exception
    */
	@PostMapping("/noticeDtls")
	public String noticeDtls(@RequestBody BdNoticeVO vo, ModelMap model) {

		try {
			BdNoticeVO notice = BidnoticeService.selectNotice(vo);
			List<FileDocVO> fileList = BidnoticeService.selectListNoticeAtchmnfl(notice);
			log.info("noticeDtls notice ===> " + notice);
			log.info("noticeDtls fileList ===> " + fileList);

			model.put("notice", notice);
			model.put("fileList", fileList);

			return "bd/bidNoticeDtls";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

}
