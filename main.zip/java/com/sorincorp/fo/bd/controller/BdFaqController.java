package com.sorincorp.fo.bd.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.fo.bd.model.BdFaqVO;
import com.sorincorp.fo.bd.service.BdFaqService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * CsfFaqController.java
 * @version
 * @since 2022. 12. 08.
 * @author bok young
 */
@Slf4j
@Controller
@RequestMapping("/bid/faq")
public class BdFaqController {
	
	@Autowired
	private CommonCodeService cmnCodeService;

	@Autowired
	private BdFaqService csfFaqService;
	
	/**
	 * <pre>
	 * 처리내용: FAQ 내용을 조회한다.
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 13.			srec0067			최초작성
	 * 2022.12. 08.			bok young			최종수정
	 * ------------------------------------------------
	 * @param seachVo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/csfFaqViews")
	public String selectCsfFaqViews(BdFaqVO seachVo, ModelMap model, HttpServletRequest request) throws Exception {
		String faqIdx = request.getParameter("reqNo");
		
		try {
			if (faqIdx != null && faqIdx != "") {
				model.addAttribute("faqIdx", faqIdx);
			} else {
				model.addAttribute("faqIdx", "0");
			}
			Map<String, String> mainGubunCodeMap = cmnCodeService.getSubCodes("BID_FAQ_SE_CODE");
			int totalCnt = csfFaqService.selectFaqListTotCnt(seachVo);
			
			model.addAttribute("totalRowCount", totalCnt);
			model.addAttribute("mainGubunCodeMap", mainGubunCodeMap);
			model.addAttribute("pageIndex", 1);
			model.addAttribute("pageSize", 10);
			model.addAttribute("rowCountPerPage", 10);

			return "bd/bidCsfFaqViews";
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: FAQ 목록을 조회한다.
	 * </pre>
	 * @date 2022. 9. 13.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 13.			srec0067			최초작성
	 * 2022.12. 08.			bok young			최종수정
	 * ------------------------------------------------
	 * @param seachVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectCsfFaqListData")
	@ResponseBody
	public ResponseEntity<?> selectFaqListData(@RequestBody BdFaqVO seachVo, ModelMap model) throws Exception {

		List<BdFaqVO> faqList = csfFaqService.selectFaqList(seachVo);
		Map<String,Object> map = new HashMap<String, Object>();
		
		try {
			int totalCnt = csfFaqService.selectFaqListTotCnt(seachVo);
			model.addAttribute("totalRowCount", totalCnt);

			map.put("dataList", faqList);
			map.put("totalRowCount", totalCnt);
			
			return new ResponseEntity<>(map, HttpStatus.OK);
		} catch(Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return new ResponseEntity<>(map, HttpStatus.BAD_GATEWAY);
		}
	}
}