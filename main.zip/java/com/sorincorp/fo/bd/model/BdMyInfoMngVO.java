package com.sorincorp.fo.bd.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * BdMyInfoMngVO.java
 *
 * @version
 * @since 2023. 09. 07.
 * @author bok3117
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class BdMyInfoMngVO extends CommonVO {
	
	private static final long serialVersionUID = 7402433857088043650L;
	
    /**
     * 입찰 업체 번호
    */
    private String bidEntrpsNo;
    
    /**
     * 입찰 회원 아이디
    */
    private String bidMberId;
    
    /**
     * 입찰 회원 비밀 번호
    */
    private String bidMberSecretNo;
    
    /**
     * 업체 명
    */
    private String entrpsNm;
    
    /**
     * 사업자 등록 번호
    */
    private String bsnmRegistNo;
    
    /**
     * 입찰 회원 이메일
    */
    private String bidMberEmail;
    
    /**
     * 휴대폰 번호
    */
    private String moblphonNo2;
    
    /**
     * 추가 항목
    */
    private String aditIem;
    
    /**
     * 대행 업체 명
    */
    private String vrscEntrpsNm;
    
    /**
     * 대행 사업자 등록 번호
    */
    private String vrscBsnmRegistNo;
    
    /**
     * 대행 입찰 회원 이메일
    */
    private String vrscBidMberEmail;
    
    /**
     * 대행 휴대폰 번호
    */
    private String vrscMoblphonNo;
    
    /**
     * 추가 항목2
    */
    private String aditIem2;
    
    /**
     * 변경 휴대폰 번호
    */
    private String changeMoblphonNo2;
    
    /**
     * 변경 대행 휴대폰 번호
    */
    private String changeVrscMoblphonNo;
    
    /**
     * 변경 입찰 회원 비밀 번호
    */
    private String changeBidMberSecretNo;
    
    /**
     * 입찰 승인 상태 코드
    */
    private String bidConfmSttusCode;
    
    /**
     * 입찰 승인 상세 상태 코드
    */
    private String bidConfmDetailSttusCode;
    
    /**
     * 변경 승인 요청 일시
    */
    private java.sql.Timestamp changeConfmRequstDt;
    
    /**
     * 회사 / 입찰 정보 구분값
    */
    private String modalId;
    
    /**
     * 입력 휴대폰 번호
    */
    private String inputMoblphonNo;
    
    /**
     * 입력 사유
    */
    private String inputAditIem;

    /**
     * 업체 전화 번호
     */

    private String entrpsTlphonNo;
    /**
     * 대행 전화 번호
     */
    private String vrscTlphonNo;

    /**
     * 사업자등록증 문서 번호1
     */
    private String bsnmRegistDocNo1;

    /**
     * 사업자등록증 문서 번호2
     */
    private String bsnmRegistDocNo2;

    /**
     * 우편 번호
     */
    private String postNo;
    /**
     * 주소
     */
    private String adres;
    /**
     * 상세 주소
     */
    private String detailAdres;
    /**
     * 도로명 주소
     */
    private String rnAdres;
    /**
     * 도로명 상세 주소
     */
    private String rnDetailAdres;
}
