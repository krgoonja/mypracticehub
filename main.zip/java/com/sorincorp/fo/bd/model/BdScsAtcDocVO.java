package com.sorincorp.fo.bd.model;

import java.util.List;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class BdScsAtcDocVO extends CommonVO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7435362650126947785L;
	/**
	 * 입찰 업체 번호
	 */
	private String bidEntrpsNo;
	/**
	 * 입찰 업체 명 
	 */
	private String entrpsNm;
	/**
	 * 입찰 공고 아이디
	 */
	private String bidPblancId;
	/**
	 * 문서 타입 코드 
	 */
	private String bidDocTyCodeNm;

	/*
	 * 심사 상태 코드 
	 */
	private String jdgmnSttusCode;
	/*
	 * 심사 요청 일시 
	 */
	private String jdgmnRequstDt;
	/*
	 * 심사 완료 일시
	 */
	private String jdgmnComptDt;
	/*
	 * 심사 내역
	 */
	private String jdgmnDtls;

	
	/*
	 * 입찰 문서 순번
	 */
	private int bidDocSn;
	/*
	 * 입찰 문서 타입 코드
	 */
	private String bidDocTyCode;
	/**
	 * 문서 번호
	 */
	private int docNo;
	/**
	 * 입찰 문서 심사 현황 코드
	 */
	private String bidDocJdgmnSttusCode;
	/**
	 * 재요청 대상 여부
	 */
	private String reRequstTrgetAt;
	/**
	 * 접수 일시
	 */
	private String rceptDt;
	/**
	 * 승인 일시
	 */
	private String confmDt;
	
	/**
	 * 사용 여부
	 */
	private String useAt;

	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	
	/**
	 * 삭제 여부 
	 */
	private String deleteAt;
	
	/**
	 * 문서 파일 명
	 */
	private String docFileNm;
	/**
	 * 문서 파일 경로
	 */
	private String docFileCours;
	/**
	 * 문서 파일 실제 경로
	 */
	private String docFileRealCours;
	/**
	 * 문서 제출 상태
	 */
	private String docStatus;
	
	/**
	 * 문서 크기
	 */
	private String docFileMg;
	
	
	/**
	 * 문서 제출 상태
	 */
	private List<String> docTyCode;
	
	/**
	 * 문서 제출 상태
	 */
	private List<String> docTyNo;
	
	/*
	 * 낙찰 서류 개수
	 */
	private int bidDocCnt;

}
