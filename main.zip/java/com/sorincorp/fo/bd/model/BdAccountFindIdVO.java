package com.sorincorp.fo.bd.model;

import lombok.Data;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

/**
 * @version
 * @since 2023. 09. 14.
 * @author hamyoonsic
 */
@Data
@Validated
public class BdAccountFindIdVO implements Serializable{
	

		/**
		 * serialVersionUID
		 */
		private static final long serialVersionUID = 5520517016503563459L;

		/**
		 * findId
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface findId{};
		
		/**
		 * findId
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface confirmId{};
		
		/**
		 * findIdResult
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface findIdResult{};
		
		/** 인증 토큰 */
		@NotEmpty(groups = confirmId.class, message="인증되지 않은 계정입니다.")
		private String token;
	
		/** 인증 번호 */
		@NotEmpty(groups = confirmId.class, message="인증번호를 입력해 주세요.")
		private String bidAuthNum;

		/** 전화 번호 */
		@NotEmpty(groups = findId.class, message="휴대폰번호를 입력해 주세요.")
		@NotEmpty(groups = confirmId.class, message="인증되지 않은 계정입니다.")
		private String bidPhoneNum;
		
		/** 마스킹 아이디 */
		@NotEmpty(groups = findIdResult.class, message="인증되지 않은 계정입니다.")
		private String maskingId;
		
		/** 가입일 */
		@NotEmpty(groups = findIdResult.class, message="인증되지 않은 계정입니다.")
		private String signUpDate;
		
		/**
		 * 아이디 찾기 : 간편회원, 회원사인지 체크
		 */
		@NotEmpty(groups = findId.class, message="인증되지 않은 계정입니다.")
		@NotEmpty(groups = confirmId.class, message="인증되지 않은 계정입니다.")
		private String type;

}    
