package com.sorincorp.fo.bd.model;

import lombok.Data;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

/**
 * @version
 * @since 2023. 09. 14.
 * @author hamyoonsic
 */
@Data
@Validated
public class BdAccountFindPwVO implements Serializable{
	

		/**
		 * serialVersionUID
		 */
		private static final long serialVersionUID = 5520517016503563459L;

		/**
		 * findPw
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface findPw{};
		
		/**
		 * changePw
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface changePw{};
		
		/**
		 * findPwGetToken
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface findPwGetToken{};
		
		/**
		 * noticeChangePw
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface noticeChangePw{};
		
		/**
		 * noticeNextDatePw
		 * Validation groups를 지정하기 위한 빈 interface
		 */
		public interface noticeNextDatePw{};
	
		/** 아이디 */
		@NotEmpty(groups = findPw.class, message="아이디를 입력해 주세요.")
		@NotEmpty(groups = findPwGetToken.class, message="아이디를 입력해 주세요.")
		@NotEmpty(groups = changePw.class, message="인증되지 않은 계정입니다.")
		@NotEmpty(groups = noticeNextDatePw.class, message="인증되지 않은 계정입니다.")
		private String id;
		
		/** 비밀번호 */
		@NotEmpty(groups = changePw.class, message="비밀번호를 입력해 주세요.")
		@NotEmpty(groups = noticeChangePw.class, message="변경할 비밀번호를 입력해 주세요.")
		private String password;
		
		/** 이전 비밀번호 */
		@NotEmpty(groups = noticeChangePw.class, message="기존 비밀번호를 입력해 주세요.")
		private String oldPassword;
		
		/** 인증 토큰 */
		@NotEmpty(groups = findPwGetToken.class, message="인증되지 않은 계정입니다.")
		private String token;
	
		/** 인증 번호 */
		@NotEmpty(groups = findPwGetToken.class, message="인증번호를 입력해 주세요.")
		private String bidAuthNum;

		/** 전화 번호 */
		@NotEmpty(groups = findPw.class, message="휴대폰번호를 입력해 주세요.")
		private String bidPhoneNum;

		/** 입찰 업체 번호 */
		private String bidEntrpsNo;

		/** 입찰 회원 아이디 */
		private String bidMberId;

}    
