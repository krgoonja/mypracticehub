package com.sorincorp.fo.bd.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;
/**
 * BdEtrVO.java
 *
 * @version
 * @since 2023. 09. 05.
 * @author hamyoonsic
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class BdEtrVO extends CommonVO {
	/******  JAVA VO CREATE : BD_ENTRPS_INFO_BAS()                                                                                           ******/
    /**
	* 입찰 업체 번호
    */
	private String bidEntrpsNo;
	/**
	* 입찰 회원 아이디
    */
	private String bidMberId;
	/**
	* 입찰 회원 비밀 번호
    */
	private String bidMberSecretNo;
	/**
	* 업체 명
    */
	private String entrpsNm;
	/**
	* 사업자 등록 번호
    */
	private String bsnmRegistNo;
	/**
	* 입찰 회원 이메일
    */
	private String bidMberEmail;
	/**
	* 휴대폰 번호
    */
	private String moblphonNo2;
	/**
	* 추가 항목
    */
	private String aditIem;
	/**
	* 외국 업체 여부
    */
	private String frntnEntrpsAt;
    /**
	* 대행 업체 명
    */
	private String vrscEntrpsNm;
	/**
	* 대행 사업자 등록 번호
    */
	private String vrscBsnmRegistNo;
	/**
	* 대행 입찰 회원 이메일
    */
	private String vrscBidMberEmail;
	/**
	* 대행 휴대폰 번호
    */
	private String vrscMoblphonNo;
	/**
	* 추가 항목2
    */
	private String aditIem2;
	/**
	* 입찰 회원 상태 코드
    */
	private String bidMberSttusCode;
	/**
	* 입찰 승인 상태 코드
    */
	private String bidConfmSttusCode;
	/**
	* 입찰 승인 상세 상태 코드
    */
	private String bidConfmDetailSttusCode;
	/**
	* 가입 승인 요청 일시
    */
	private java.sql.Timestamp etrConfmRequstDt;
	/**
	* 가입 승인 처리 일시
    */
	private java.sql.Timestamp etrConfmProcessDt;
	/**
	* 변경 승인 요청 일시
    */
	private java.sql.Timestamp changeConfmRequstDt;
	/**
	* 변경 승인 처리 일시
    */
	private java.sql.Timestamp changeConfmProcessDt;
	/**
	* 입찰 회원 가입 일시
    */
	private java.sql.Timestamp bidMberEtrDt;
	/**
	* 입찰 회원 차단 일시
    */
	private java.sql.Timestamp bidMberIntrcpDt;
	/**
	* 입찰 회원 차단 내용
    */
	private String bidMberIntrcpCn;
	/**
	* 이용 약관 동의 여부
    */
	private String useStplatAgreAt;
	/**
	* 이용 약관 동의 일시
    */
	private java.sql.Timestamp useStplatAgreDt;
	/**
	* 개인 정보 3자 제공 동의 여부
    */
	private String indvdlInfoThreemanProvdAgreAt;
	/**
	* 개인 정보 3자 제공 동의 일시
    */
	private java.sql.Timestamp indvdlInfoThreemanProvdAgreDt;
	/**
	* 개인 정보 처리 방침 동의 여부
    */
	private String indvdlInfoProcessPolcyAgreAt;
	/**
	* 개인 정보 처리 방침 동의 일시
    */
	private java.sql.Timestamp indvdlInfoProcessPolcyAgreDt;
	/**
	* 마케팅 수신 동의 여부
    */
	private String marktRecptnAgreAt;
	/**
	* 마케팅 수신 동의 일시
    */
	private java.sql.Timestamp marktRecptnAgreDt;
	 /**
	* 회원 문자 수신 동의 여부
    */
	private String mberChrctrRecptnAgreAt;
	/**
	* 회원 문자 수신 동의 일시
    */
	private java.sql.Timestamp mberChrctrRecptnAgreDt;
	/**
	* 회원 메일 수신 동의 여부
    */
	private String mberEmailRecptnAgreAt;
	/**
	* 회원 메일 수신 여부 일시
    */
	private java.sql.Timestamp mberEmailRecptnAgreDt;
	/**
	* 회원 푸시 수신 동의 여부
    */
	private String mberPushRecptnAgreAt;
    /**
	* 회원 푸시 수신 동의 일시
    */
	private java.sql.Timestamp mberPushRecptnAgreDt;
    /**
	* 투찰 취소 건수
    */
	private int bddprCanclCo;
    /**
	* 삭제 여부
    */
	private String deleteAt;
    /**
	* 삭제 일시
    */
	private java.sql.Timestamp deleteDt;
    /**
	* 최초 등록자 아이디
    */
	private String frstRegisterId;
    /**
	* 최초 등록 일시
    */
	private java.sql.Timestamp frstRegistDt;
    /**
	* 최종 변경자 아이디
    */
	private String lastChangerId;
    /**
	* 최종 변경 일시
    */
	private java.sql.Timestamp lastChangeDt;
    /**
	* 변경 휴대폰 번호
    */
	private String changeMoblphonNo2;
    /**
	* 변경 대행 휴대폰 번호
    */
	private String changeVrscMoblphonNo;
    /**
	* 변경 입찰 회원 비밀 번호
    */
	private String changeBidMberSecretNo;
	/**
	 * 문서 번호
	 */
	private int docNo;
	/**
	 * 문서 파일 명
	 */
	private String docFileNm;
	/**
	 * 문서 파일 경로
	 */
	private String docFileCours;
	/**
	 * 문서 파일 실제 경로
	 */
	private String docFileRealCours;
	/**
	 * 우편 번호
	 */
	private String postNo;
	/**
	 * 주소
	 */
	private String adres;
	/**
	 * 상세 주소
	 */
	private String detailAdres;
	/**
	 * 도로명 주소
	 */
	private String rnAdres;
	/**
	 * 사업자등록증 문서 번호1
	 */
	private String bsnmRegistDocNo1;
	/**
	 * 사업자등록증 문서 번호2
	 */
	private String bsnmRegistDocNo2;
	/**
	 * 업체 전화 번호
	 */
	private String entrpsTlphonNo;
	/**
	 * 대행 전화 번호
	 */
	private String vrscTlphonNo;
	/**
	 * 국가 코드1
	 */
	private String nationCode1;
	/**
	 * 국가 코드2
	 */
	private String nationCode2;
	/**
	 * 국가 코드3
	 */
	private String nationCode3;
	/**
	 * 국가 코드4
	 */
	private String nationCode4;


}
