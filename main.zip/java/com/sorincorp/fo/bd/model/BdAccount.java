package com.sorincorp.fo.bd.model;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class BdAccount implements UserDetails {
	private String bidEntrpsNo;					// 입찰 업체 번호
	private String bidMberId;					// 입찰 회원 아이디
	private String bidMberSecretNo;				// 입찰 회원 비밀 번호
	private String entrpsNm;					// 업체 명
	private String bsnmRegistNo;				// 사업자 등록 번호
	private String bidMberEmail;				// 입찰 회원 이메일
	private String moblphonNo2;					// 휴대폰 번호
	private String aditIem;						// 추가 항목
	private String frntnEntrpsAt;				// 외국 업체 여부
	private String vrscEntrpsNm;				// 대행 업체 명
	private String vrscBsnmRegistNo;			// 대행 사업자 등록 번호
	private String vrscBidMberEmail;			// 대행 입찰 회원 이메일
	private String vrscMoblphonNo;				// 대행 휴대폰 번호
	private String aditIem2;					// 추가 항목2
	private String bidEtrConfmSttusCode;		// 입찰 가입 승인 상태 코드
	private String useStplatAgreAt;				// 이용 약관 동의 여부
	private String useStplatAgreDt;				// 이용 약관 동의 일시
	private String mberEmailRecptnAgreAt;		// 회원 메일 수신 동의 여부
	private String mberEmailRecptnAgreDt;		// 회원 메일 수신 여부 일시
	private String mberChrctrRecptnAgreAt;		// 회원 문자 수신 동의 여부
	private String mberChrctrRecptnAgreDt;		// 회원 문자 수신 동의 일시
	
	private String bidMberSttusCode;            // 입찰 회원 상태 코드
    private String bidConfmSttusCode;           // 입찰 회원 승인 상태 코드
    private String bidConfmDetailSttusCode;     // 입찰 회원 승인 상세 상태 코드
    
    /**********************사용자 대시보드(메인)***************************/
    private int bddprCnt;                       // 투찰 건(수)
    private int scsbidCnt;                      // 낙찰 건(수)
    private int defeatCnt;                      // 패찰 건(수)
    private int intrstBidCnt;                   // 관심공고 건(수)
    private String dspyAt;						// 전시 여부
    
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return null;
		/* ROLE을 사용하는 경우
		return this.roles.stream()
				.map(SimpleGrantedAuthority::new)
				.collect(Collectors.toList());
		*/
	}
	@Override
	public String getPassword() {
		return this.bidMberSecretNo;
	}
	@Override
	public String getUsername() {
		return this.bidMberId;
	}
	@Override
	public boolean isAccountNonExpired() {
		return true;
	}
	@Override
	public boolean isAccountNonLocked() {
		return true;
	}
	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}
	@Override
	public boolean isEnabled() {
		return true;
	}
}
