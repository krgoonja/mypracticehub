package com.sorincorp.fo.bd.model;

import java.util.List;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class BdFaqVO extends CommonVO {
	
	private static final long serialVersionUID = -8844195686045139146L;
	/**
	* FAQ 번호
	*/
    private int faqNo;
    /**
	* FAQ 문서 번호
	*/
	private int docNo;
	/**
	* FAQ 업무 구분 코드
	*/
	private String faqJobSeCode;
	/**
	* FAQ 업무 구분 코드명
	*/
	private String faqJobSeCodeNm;
	/**
	* FAQ 질문
	*/
    private String faqQestn;
    /**
	* FAQ 답변
	*/
    private String faqAnswer;
    /**
	* FAQ 노출 여부
	*/
    private String faqExpsrAt;
    /**
   	* FAQ 순서
   	*/
    private int faqOrdr;
    /**
   	* 삭제 여부
   	*/
    private String deleteAt;
    /**
   	* 삭제 일시
   	*/
    private String deleteDt;
    /**
   	* 최초 등록자 아이디
   	*/
    private String frstRegisterId;
    /**
   	* 최초 등록 일시
   	*/
    private String frstRegistDt;
    /**
   	* 최종 변경자 아이디
   	*/
    private String lastChangerId;
    /**
   	* 최종 변경 일시
   	*/
    private String lastChangeDt;
    /**
   	* FAQ 기본 이력 순번
   	*/
    private String faqBassHistSn;
    /**
   	* Grid 상태
   	*/
	private String gridRowStatus;
	/**
   	* modalPageStatus 상태
   	*/
	private String modalPageStatus;
	/**
   	* 등록자
   	*/
	private String regUser;
	/**
   	* 검색조건
   	*/
	private String searchCondition1;
	private String searchCondition2;
	private String searchCondition3;
	private String searchCondition4;
	/**
   	* 검색Keyword
   	*/
	private String searchKeyword1;
	private String searchKeyword2;
	private String excelYn;
	/**
   	* Faq 파일 정보
   	*/
	private List<FileDocVO> attachFiles;
	/**
   	* 총 숫자
   	*/
	private int totalCnt;
}
