package com.sorincorp.fo.bd.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class BdBidVO extends CommonVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7435360650166947785L;
	/**
	 * 입찰 업체 번호 
	 */
	private String bidEntrpsNo;
	
	/**
	 * 입찰 공고 아이디
	 */
	private String bidPblancId;

   
   /**
	 * Insert,Update</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */ 
	public interface InsertAndUpdate {};
  
   
   /* 정렬 순서 */
   private String rownum;
   /**
    * 입찰 공고 아이디 배열
    */
   private String[] bidPblancIdArr;
   
//////////////////////////////////////////////////////////////////////////////////
   /**
    * 금속 코드
    */
   @NotEmpty(message = "메탈 구분 선택은 필수 입니다.")  
   private String metalCode;
   /**
    * 금속 코드 명
    */
   private String metalCodeNm;
   /**
    * 브랜드 그룹 코드
    */
   @NotEmpty(message = "브랜드 그룹 선택은 필수 입니다.")  
   private String brandGroupCode;
   /**
    * 브랜드 그룹 코드 명
    */
   private String brandGroupCodeNm;
   /**
    * 브랜드 코드
    */ 
   private String brandCode;
   /**
    * 브랜드 코드 (Seller)
    */
   private String partcptnBrandCode;
   /**
    * 아이템 순번
    */
   @NotEmpty(message = "아이템 상품명 선택은 필수 입니다.")
   private String itmSn;
   /**
    * 아이템 순번 명
    */
   private String goodsNm;
   /**
    * 전시 상품 명
    */
   private String dspyGoodsNm;
   /**
    * 아이템 이미지
    */
   private String pcImageOneNm;
   /**
    * 권역 대분류 코드
    */
   @NotEmpty(message = "권역 선택은 필수 입니다.")
   private String dstrctLclsfCode;
   
   /**
    * 권역 대분류 코드 명
    */
   private String dstrctNm;
	
   /**
    * 입찰 중량
    */
   @NotEmpty(message = "수량 선택은 필수 입니다.")
   private String bidWt;
   /**
    * 허용 중량 비율
    */
   @NotEmpty(message = "중량허용공차 선택은 필수 입니다.")
   private String permWtRate;
   
   /**
    * 인도 조건 선택값
    */
   private String shippingAddr;
   /**
    * 인도 조건 01 적용 여부
    */
   private String delyCnd01ApplcAt;
   /**
    * 인도 조건 01 기준 가격
    */
   private double delyCnd01StdrPc;
   /**
    * 인도 조건 01 프리미엄 가격
    */
   private double delyCnd01PremiumPc;
   /**
    * 인도 조건 02 적용 여부
    */
   private String delyCnd02ApplcAt;
   /**
    * 인도 조건 02 기준 가격
    */
   private double delyCnd02StdrPc;
   /**
    * 인도 조건 02 프리미엄 가격
    */
   private double delyCnd02PremiumPc;
   /**
    * 인도 조건 03 적용 여부
    */
   private String delyCnd03ApplcAt;
   /**
    * 인도 조건 03 기준 가격
    */
   private double delyCnd03StdrPc;
   /**
    * 인도 조건 03 프리미엄 가격
    */
   private double delyCnd03PremiumPc;
   /**
    * 인도 시작 일자
    */
   @NotEmpty(message = "인도 시작일 지정은 필수 입니다.")
   private String delyBeginDe;
   /**
    * 인도 종료 일자
    */
   @NotEmpty(message = "인도 종료일 지정은 필수 입니다.")
   private String delyEndDe;
   /**
    * 가격 지정 시작 일자
    */
   @NotEmpty(message = "가격 지정 시작일 지정은 필수 입니다.")
   private String pcAppnBeginDe;
   /**
    * 가격 지정 종료 일자
    */
   @NotEmpty(message = "가격 지정 종료일 지정은 필수 입니다.")
   private String pcAppnEndDe;
   /**
    * 가격 지정 방법 코드
    */
   @NotEmpty(message = "가격 지정 방법은 필수 입니다.")
   private String pcAppnMthCode;
   /**
    * 가격 지정 방법 코드 명
    */
   private String pcAppnMthCodeNm;
   /**
    * 결제 통화 코드
    */
   @NotEmpty(message = "결제 통화(Cur) 선택은 필수 입니다.")
   private String setleCrncyCode;
   /**
    * 결제 통화 코드 명
    */
   private String setleCrncyCodeNm;
   /**
    * 결제 방법 코드
    */
   @NotEmpty(message = "결제 방법(Method) 선택은 필수 입니다.")
   private String setleMthCode;
   /**
    * 결제 방법 코드 명
    */
   private String setleMthCodeNm;
   /**
    * 결제 기간 코드
    */
   @NotEmpty(message = "결제 기간(Term) 선택은 필수 입니다.")
   private String setlePdCode;
   /**
    * 결제 기간 코드 명
    */
   private String setlePdCodeNm;
   /**
    * 기타 내용
    */ 
   private String etcCn;
   /**
    * 인도기한 내용
    */ 
   private String delyPdCn;
   /**
    * 서류 선화 증권 제출 여부
    */
   private String papersBlScritsPresentnAt;
   /**
    * 서류 성적서 제출 여부
    */
   private String papersScreofePresentnAt;
   /**
    * 서류 포장 명세서 제출 여부
    */
   private String papersPackngDtstmnPresentnAt;
   /**
    * 서류 원산지 증명서 제출 여부
    */
   private String papersOrgplceCrtfPresentnAt;
   /**
    * 서류 CRIW 제출 여부
    */
   private String papersCriwPresentnAt;
   /**
    * 서류 수입 통관 면장 제출 여부
    */
   private String papersImportEntrMyeonhedPresentnAt;
   /**
    * 서류 최종 송장 제출 여부
    */
   private String papersLastInvcPresentnAt;
   /**
    * 서류 가송장 제출 여부
    */
   private String papersPcinvcPresentnAt;
   /**
    * 서류 분할 증명서 제출 여부
    */
   private String papersPartitnCrtfPresentnAt;
   /**
    * 투찰 시작 일시
    */
   @NotEmpty(message = "투찰 시작일 지정은 필수 입니다.")
   @Size(min=14, max=14, message = "투찰 시작일이 올바르지 않습니다.")
   private String bddprBeginDt;
   /**
    * 투찰 종료 일시
    */
   @NotEmpty(message = "투찰 종료일 지정은 필수 입니다.")
   @Size(min=14, max=14, message = "투찰 종료일이 올바르지 않습니다.")
   private String bddprEndDt;
   /**
    * 투찰 취소 가능 여부
    */
   private String bddprCanclPossAt;
   /**
    * 투찰 취소 제한 일자
    */
   @Size(min=0, max=14, message = "투찰 취소 제한일이 올바르지 않습니다.")
   private String bddprCanclLmttDe;
   /**
    * 입찰 상태 코드
    */
   private String bidSttusCode;
   /**
    * 입찰 상태 코드 명
    */
   private String bidSttusNm;
   /**
    * 참여 업체 수량
    */
   private int partcptnEntrpsQy;
   /**
    * 관심 업체 수량
    */
   private int intrstEntrpsQy;
   /**
    * 전시 여부
    */
   private String dspyAt;
   /**
    * 공고 취소 여부
    */
   private String pblancCanclAt;
   /**
    * 개찰 일시
    */
   private String opengDt;
   /**
    * 삭제 여부
    */
   private String deleteAt;
   /**
    * 삭제 일시
    */
   private String deleteDt;
   /**
    * 최초 등록자 아이디
    */
   private String frstRegisterId;
   /**
    * 최초 등록 일시
    */
   private String frstRegistDt;
   /**
    * 최종 변경자 아이디
    */
   private String lastChangerId;
   /**
    * 최종 변경 일시
    */
   private String lastChangeDt;
//////////////////////////////////////////////////////////////////////////////////
   
   /** 검색Keyword */
   private String searchKeyword;
   
   private String searchCondition1;
   private String searchCondition2;
   /** 상태코드 **/
   private String jdgmnSttusCode;
   
   /** 탭 스태터스 **/
   private String tabCondition;
   

   
   /** 상품코드 **/
   private String brandNm;
	
  
   
   /**
    * 대분류 출고 권역 이름
    */
   private String lclsfDlivyDstrct;
   /**
    * 인도 조건 코드 이름
    */
   private String delyCndCodeNm;
   /**
    * 인도 조건 코드
    */
   private String delyCndCode;
   /**
    * 창고 코드
    */
   private String wrhousCode;
   /**
    * 창고 명
    */
   private String wrhousNm;
   /**
    * 운영 업체 명
    */
   private String operEntrpsNm; /**
    * 창고 우편 번호
    */
   private String wrhousPostNo;
   /**
    * 창고 도로명 주소
    */
   private String wrhousRnAdres;
   /**
    * 창고 도로명 주소 상세
    */
   private String wrhousRnAdresDetail;
   /**
    * 창고 계약 형태 코드
    */
   private String wrhousCntrctStleCode;
   
   /* 관심공고 N/Y */
   private String intrstAt;
   
   private int intrstCnt = 0;

   private int bddprCnt = 0;
   
   /**
    * PageStatus 상태
   */ 
   private String PageStatus;
   /**
    * 투찰프리미엄 가격 
    *  BDDPR_PREMIUM_PC
   */
   private double bddprPremiumPc;
   
   /** 국가 코드 **/
   private String nationCd;
   /** 권역 지역 이름 **/
   private String nationUrl;
   
   /** 공고일 검색 조건1 **/
   private String searchDateFrom;
   
   /** 마감일 검색 조건1 **/
   private String searchDateTo;
   /** 공고(공고일,마감일) **/
   
   private String filter;
   /** 브랜드 선택 **/
   private String brand;
   /** 권역 선택 **/
   private String area;
   /** 디데이(D-Day dd일 HH시간 mm분 ss초)  **/
   private String dday;
   
   /** 디데이(서버시간) **/
   private String allDday;
   
   /** 디데이 배열 **/
   private String timeArr [];
   
   /** 투찰 취소 여부 **/
   private String canclAt;
   
   /** 검색조건 (서류심사상태코드) **/
   private String jdgmnSttus;
   
   /** 개찰 순위 **/
   private String opengRank;
   private String opengRankCn;
   
   /** 데이터 그레이처리 여부 **/
   private String grayCheck;
   
   /** 서버시간 **/
   private String serverDt;
 
   /** 메인 공고 개수 **/
   private int mainBdCnt;
   
   /** 관심공고 설정 삭제 여부 **/
   private String intrstDeleteAt;
   
   /**
    * 대분류 출고 권역 코드
   */
   private String lclsfDlivyDstrctCode;
   
   /**
    * 대분류 출고 권역 코드명
   */
   private String lclsfDlivyDstrctCodeNm;
   
   /**
    * 중분류 출고 권역 코드
   */
   private String mlsfcDlivyDstrctCode;
   
   /**
    * 중분류 출고 권역 코드명
   */
   private String mlsfcDlivyDstrctCodeNm;
   
   /**
    * 로그인 여부
   */
   private String loginYn;
   
   /**
	 * 유찰사유
	 */
	private String rejectBidResn;
	

    /**
     * 인도 조건 Seller/Buyer
     */
    private String delyCndSb;
    
    /**
     * 프리미엄 가격 Seller/Buyer
     */
    private String premiumPcSb;
    
    /**
     * 프리미엄 가격 코드
     */
    private String premiumPcCode;
    
    /**
     * 가격 지정 기간 Seller/Buyer
     */
    private String pcAppnPdSb;
    
    /**
     * 가격 지정 방법 Seller/Buyer
     */
    private String pcAppnMthSb;
    
    /**
     * 브랜드 Seller/Buyer
     */
    private String brandSb;
   /**
    * 비고
    */
   private String remark;
}
