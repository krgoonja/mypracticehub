package com.sorincorp.fo.bd.model;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import org.springframework.validation.annotation.Validated;

import lombok.Data;

@Data
@Validated
public class BdLoginVO implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 3632788478635368549L;

	/**
	 *  loginInfo
	 *  Validation groups를 지정하기 위한 빈 interface
	 */
	public interface loginInfo{};

	/** 아이디 */
	@NotEmpty(groups = loginInfo.class, message="아이디를 입력해 주세요.")
	private String id;

	/** 비밀번호 */
	@NotEmpty(groups = loginInfo.class, message="비밀번호를 입력해 주세요.")
	@NotEmpty(message="비밀번호를 입력해 주세요.")
	private String password;

	/****** JAVA VO CREATE : BID_LOGIN_INFO_HST(입찰_로그인 정보 이력) ******/

	/**
	 * 입찰 업체 번호
	 */
	private String bidEntrpsNo;
	/**
	 * 로그인 정보 이력 순번
	 */
	private long loginInfoHistSn;
	/**
	 * 로그인 일시
	 */
	private String loginDt;
	/**
	 * 로그인 IP
	 */
	private String loginIp;
	/**
	 * 로그인 상태 코드
	 */
	private String loginSttusCode;
	/**
	 * 접속 환경 코드
	 */
	private String conectEnvrnCode;
	/**
	 * 유저 에이전트 정보
	 */
	private String userAgntInfo;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;

    /**
     * 아이디 저장
     */
    private Boolean saveId; 
}
