package com.sorincorp.fo.bd.model;

import java.util.List;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * BddprListVO.java
 *
 * @version
 * @since 2023. 08. 22.
 * @author bok3117
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class BddprListVO extends CommonVO {
	
	private static final long serialVersionUID = 7402433857088043650L;
	
	/**
     * 입찰 공고 아이디
    */
    private String bidPblancId;
    
    /**
     * 금속 코드
    */
    private String metalCode;
    
    /**
     * 금속 코드명
    */
    private String metalNm;
    
    /**
     * 아이템 순번
    */
    private int itmSn;
    
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    
    /**
     * 브랜드 코드
    */
    private String brandCode;
    
    /**
     * 브랜드 그룹 코드명
    */
    private String brandGroupNm;
    
    /**
     * 상품명
    */
    private String goodsNm;

    /**
     * 전시 상품 명
     */
    private String dspyGoodsNm;
    
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    
    /**
     * 권역 대분류 코드명
    */
    private String dstrctLclsfNm;
    
    /**
     * 입찰 중량
    */
    private int bidWt;
    
    /**
     * 투찰 시작 일시
    */
    private String bddprBeginDt;
    
    /**
     * 투찰 종료 일시
    */
    private String bddprEndDt;
	
    /**
     * 입찰 상태 코드
    */
    private String bidSttusCode;
    
    /**
     * 공고 취소 여부
    */
    private String pblancCanclAt;
    
    /**
     * 입찰 업체 번호
    */
    private String bidEntrpsNo;
    
    /**
     * 개찰 순위
    */
    private String opengRank;
    
    /**
     * 투찰 일시
    */
    private String bddprDt;
    
    /**
     * 취소 여부
    */
    private String canclAt;
    
    /**
     * 낙찰 여부
    */
    private String scsbidAt;
    
    /**
     * 심사 상태 코드
    */
    private String jdgmnSttusCode;
    
    /**
     * 투찰가
    */
    private java.math.BigDecimal bddprPc;
    
    /**
     * 국기 이미지 URL
     */
    private String nationFlagImgUrl;
    
    /**
     * PageStatus 상태
    */ 
    private String pageStatus;
    
    /**
     * PageSubStatus 상태
    */ 
    private String pageSubStatus;
    
    /**
     * 투찰 건수
    */
    private int bddprCnt;
    
    /**
     * 낙찰 건수
    */
    private int scsbidCnt;
    
    /**
     * 패찰 건수
    */
    private int loseCnt;
    
    /**
     * 유찰 건수
    */
    private int canclCnt;
    
    /**
     * 기간조회 설정
    */
    private String pdSetup;
    
    /**
     * 기간조회 시작일
    */
    private String searchDateFrom;
    
    /**
     * 기간조회 종료일
    */
    private String searchDateTo;
    
    /**
     * 아이템 이미지
     */
    private String pcImageOneNm;
    
}
