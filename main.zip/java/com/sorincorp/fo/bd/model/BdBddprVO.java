package com.sorincorp.fo.bd.model;

import javax.validation.constraints.NotEmpty;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class BdBddprVO extends BdBidVO{
 
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7435360650166947605L;
	/**
	 * 입찰 업체 명 
	 */
	private String entrpsNm;
	/**
	/**
	 * 입찰 업체 번호 
	 */
	private String bidEntrpsNo;
	/**
	 * 입찰 공고 아이디
	 */
	 @NotEmpty(message = "입찰공고 아이디는 필수입니다.")
	private String bidPblancId;
	
 
   
   /**
     * Insert,Update</br>
     * validation groups를 지정하기 위한 빈 interface
     */ 
    public interface InsertAndUpdate {};
  
    /**
     * 인도 조건 코드
     */
    private String delyCndCode;
    /**
     * 인도 조건 기준 가격
     */
    private double delyCndStdrPc;
    /**
     * 전환 프리미엄 금액 
     */
    private double cnvrsPremiumAmount;
    /**
     * 투찰 프리미엄 가격
     */
    private double bddprPremiumPc;
    /**
     * 투찰 프리미엄 가격 콤마
     */
    private String bddprPremiumPcComma;
    /**
     * 투찰 중량
     */
    private String bddprWt;
    /**
     * 참여 동의 여부 
     */
    private String partcptnAgreAt;
    /**
     * 투찰 일시 
     */
    private String bddprDt;
    /**
     * 투찰 정상 여부
     */
    private String bddprNrmltAt;
    /**
     * 개찰 순위 
     */
    private String opengRank;
    /**
     * 개찰 일시 
     */
    private String opengDt;
    /**
     * 낙찰 여부 
     */
    private String scsbidAt;
    /**
     * 낙찰 일시 
     */
    private String scsbidDt;
    /**
     * 취소 여부 
     */
    private String canclAt;
    /**
     * 취소 일시 
     */
    private String canclDt;
    /**
     * 취소 사유
     */
    private String canclResn;
    /**
     * 삭제 여부
     */
    private String deleteAt;
    /**
     * 삭제 일시
     */
    private String deleteDt;
    /**
    * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
    * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
    * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
    * 최종 변경 일시
    */
    private String lastChangeDt;

    /**
     * 인도 조건 코드 이름
     */
    private String delyCndCodeNm;
    
    
    private String pcAppnMthCode;
    private String premiumPcCode;

    /**
     * 인도 조건 Seller/Buyer
     */
    private String delyCndSb;
    
    /**
     * 프리미엄 가격 Seller/Buyer
     */
    private String premiumPcSb;
    
    /**
     * 가격 지정 기간 Seller/Buyer
     */
    private String pcAppnPdSb;
    
    /**
     * 가격 지정 방법 Seller/Buyer
     */
    private String pcAppnMthSb;
    

    private String setleCrncyCode;
    /**
     * 결제 통화 코드 명
     */
    private String setleCrncyCodeNm;
    /**
     * 결제 방법 코드
     */
    private String setleMthCode;
    /**
     * 결제 방법 코드 명
     */
    private String setleMthCodeNm;
    /**
     * 결제 기간 코드
     */
    private String setlePdCode;
    /**
     * 결제 기간 코드 명
     */
    private String setlePdCodeNm;
    
    /**
     * 심사 상태 코드
     */
    private String jdgmnSttusCode;

    /**
     * 브랜드 그룹 코드
     */
    private String brandGroupCode;

    /**
     * 브랜드 코드
     */
    private String brandCode;

    /**
     * 비고
     */
    private String remark;
    
}