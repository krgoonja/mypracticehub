package com.sorincorp.fo.bd.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * BdIntrstPblancVO.java
 *
 * @version
 * @since 2023. 09. 12.
 * @author bok3117
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class BdIntrstPblancVO extends CommonVO {
	
	private static final long serialVersionUID = 7402433857088043650L;
	
	/**
     * 입찰 공고 아이디
    */
    private String bidPblancId;
    
    /**
     * 금속 코드
    */
    private String metalCode;
    
    /**
     * 금속 코드명
    */
    private String metalNm;
    
    /**
     * 아이템 순번
    */
    private int itmSn;
    
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    
    /**
     * 브랜드 코드
    */
    private String brandCode;
    
    /**
     * 브랜드 그룹 코드명
    */
    private String brandGroupNm;
    
    /**
     * 상품명
    */
    private String goodsNm;

    /**
     * 전시 상품 명
     */
    private String dspyGoodsNm;
    
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    
    /**
     * 권역 대분류 코드명
    */
    private String dstrctLclsfNm;
    
    /**
     * 입찰 중량
    */
    private int bidWt;
    
    /**
     * 투찰 시작 일시
    */
    private String bddprBeginDt;
    
    /**
     * 투찰 종료 일시
    */
    private String bddprEndDt;
	
    /**
     * 입찰 상태 코드
    */
    private String bidSttusCode;
    
    /**
     * 입찰 업체 번호
    */
    private String bidEntrpsNo;
    
    /**
     * 국기 이미지 URL
     */
    private String nationFlagImgUrl;
	
    /**
     * 삭제 여부
    */
    private String deleteAt;
    
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
    
    /**
     * 참여 업체 수량
     */
    private int partcptnEntrpsQy;
    
    /**
     * 관심 업체 수량
     */
    private int intrstEntrpsQy;
    
    /**
     * 전시 여부
    */
    private String dspyAt;
    
    /**
     * 아이템 이미지
     */
    private String pcImageOneNm;

}
