package com.sorincorp.fo.bd.mapper;

import java.util.List;

import com.sorincorp.fo.bd.model.BdIntrstPblancVO;

public interface BdIntrstPblancMapper {

	/**
	 * <pre>
	 * 처리내용: 마이페이지 < 관심공고 페이지에 관심공고를 추가한다.
	 * </pre>
	 * @date 2023. 9. 12.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 12.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param intrstPblancVO
	 * @throws Exception
	 */
	void insertIntrstPblanc(BdIntrstPblancVO intrstPblancVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 < 관심공고 페이지에 관심공고를 삭제한다.
	 * </pre>
	 * @date 2023. 9. 12.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 12.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param intrstPblancVO
	 * @throws Exception
	 */
	void deleteIntrstPblanc(BdIntrstPblancVO intrstPblancVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 < 관심공고 리스트를 조회한다.
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param intrstPblancVO
	 * @throws Exception
	 */
	List<BdIntrstPblancVO> selectIntrstPblancList(BdIntrstPblancVO intrstPblancVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 < 관심공고 리스트 개수를 조회한다.
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param intrstPblancVO
	 * @throws Exception
	 */
	int selectIntrstPblancCnt(BdIntrstPblancVO intrstPblancVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 관심설정 버튼 클릭 시 관심 업체 수량을 증가한다.
	 * </pre>
	 * @date 2023. 9. 14.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 14.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param intrstPblancVO
	 * @throws Exception
	 */
	void updateIntrstEntrpsQyPlus(BdIntrstPblancVO intrstPblancVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 관심설정 버튼 해제 시 관심 업체 수량을 감소한다.
	 * </pre>
	 * @date 2023. 9. 14.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 14.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param intrstPblancVO
	 * @throws Exception
	 */
	void updateIntrstEntrpsQyMinus(BdIntrstPblancVO intrstPblancVO) throws Exception;
	
}
