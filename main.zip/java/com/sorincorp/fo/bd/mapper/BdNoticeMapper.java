package com.sorincorp.fo.bd.mapper;

import java.util.List;

import com.sorincorp.fo.bd.model.BdNoticeVO;

/**
 * BidNoticeMapper.java
 * 
 */

public interface BdNoticeMapper {

	/**
	 * <pre>
	 * 처리내용: 공지사항 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<BdNoticeVO> searchListNotice(BdNoticeVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용:  공지사항 목록 총개수를 조회한다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int selectNoticeListTotcnt(BdNoticeVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 필독으로 설정된 공지사항 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 27.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	 List<BdNoticeVO> selectListNoticeUpendexpsr() throws Exception; 
	
	/**
	 * <pre>
	 * 처리내용: 공지사항 첨부파일 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<BdNoticeVO> selectListNoticeAtchmnfl(BdNoticeVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공지사항을 상세조회한다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	BdNoticeVO selectNotice(BdNoticeVO vo) throws Exception;

	void updateNoticeViewCount(BdNoticeVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공지사항 최근 게시글 4개를 조회한다. 
	 * </pre>
	 * @date 2022. 12. 06.
	 * @author seyeon
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 06.		seyeon			최초작성
	 * ------------------------------------------------
	 * @param 
	 * @return
	 * @throws Exception
	 */
	
	List<BdNoticeVO> showNotice(BdNoticeVO vo) throws Exception;
}
