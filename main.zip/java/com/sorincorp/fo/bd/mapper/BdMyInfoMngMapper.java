package com.sorincorp.fo.bd.mapper;

import java.util.List;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.fo.bd.model.BdMyInfoMngVO;

/**
 * BdMyInfoMngMapper.java
 *
 * @version
 * @since 2023. 09. 07.
 * @author bok3117
 */
public interface BdMyInfoMngMapper {
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 < 내정보관리 리스트를 조회한다.
	 * </pre>
	 * @date 2023. 9. 7.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 7.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param bidEntrpsNo
	 * @throws Exception
	 */
	BdMyInfoMngVO selectMyInfoMngDtl(String bidEntrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 휴대폰 번호 변경 신청을 한다.
	 * </pre>
	 * @date 2023. 9. 8.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 8.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param myInfoMngVO
	 * @throws Exception
	 */
	void updateMoblphonNo(BdMyInfoMngVO myInfoMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 사업자 등록증 조회
	 * </pre>
	 * @date 2023. 9. 8.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 8.	  	hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param docNo
	 * @throws Exception
	 */
	FileDocVO selectDocNo(String docNo) throws Exception;
	
}
