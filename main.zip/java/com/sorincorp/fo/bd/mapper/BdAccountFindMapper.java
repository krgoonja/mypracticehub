package com.sorincorp.fo.bd.mapper;

import com.sorincorp.fo.bd.model.BdEtrVO;

import java.util.List;

public interface BdAccountFindMapper {

	/**
	 * <pre>
	 * 구매입찰 회원 조회
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param phoneNum
	 * @return
	 * @throws Exception
	 */
	List<BdEtrVO> selectBidAccountByPhone(String phoneNum);

	/**
	 * <pre>
	 * 회원 가입 일시 조회
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 * @throws Exception
	 */
	String selectBidSignUpDate(BdEtrVO account);

	/**
	 * <pre>
	 * userId에 맞는 사용자 정보를 가져온다.
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bidMberId
	 * @return
	 * @throws Exception
	 */
	public BdEtrVO selectBidAccount(String bidMberId) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdAccount
	 * @throws Exception
	 */
	void bidUpdatePw(BdEtrVO bdAccount) throws Exception;

}
