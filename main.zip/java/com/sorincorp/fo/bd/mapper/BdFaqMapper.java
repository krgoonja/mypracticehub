package com.sorincorp.fo.bd.mapper;

import java.util.List;

import com.sorincorp.fo.bd.model.BdFaqVO;
import com.sorincorp.comm.filedoc.model.FileDocVO;

/**
 * CsfFaqMapper.java
 * @version
 * @since 2022. 12. 08.
 * @author bok young
 */
public interface BdFaqMapper {
	
	/**
	 * <pre>
	 * 처리내용: Faq 전체 카운트를 조회한다.
	 * </pre>
	 * @date 2021. 8. 20.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 20.			srec0032			최초작성
	 * 2022.12. 08.			bok young			최종수정
	 * ------------------------------------------------
	 * @param seachVo
	 * @return
	 */
	int selectFaqListTotCnt(BdFaqVO seachVo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: Faq 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 20.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 20.			srec0032			최초작성
	 * 2022.12. 08.			bok young			최종수정
	 * ------------------------------------------------
	 * @param seachVo
	 * @return
	 */
	List<BdFaqVO> selectFaqList(BdFaqVO seachVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: FAQ 관련 파일 정보를 조회한다.
	 * </pre>
	 * @date 2021. 9. 3.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 3.			srec0032			최초작성
	 * 2022.12. 08.			bok young			최종수정
	 * ------------------------------------------------
	 * @param faqNos
	 * @return
	 * @throws Exception
	 */
	List<FileDocVO> selectDocInfoList(int faqNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: FAQ 최근 질문 4개를 조회한다. 
	 * </pre>
	 * @date 2022. 12. 07.
	 * @author seyeon
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 07.	   seyeon			    최초작성
	 * ------------------------------------------------
	 * @param faqNos
	 * @return
	 * @throws Exception
	 */
	List<BdFaqVO> showFaq(BdFaqVO seachVo) throws Exception;
}
