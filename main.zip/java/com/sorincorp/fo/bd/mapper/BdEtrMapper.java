package com.sorincorp.fo.bd.mapper;

import com.sorincorp.fo.bd.model.BdEtrVO;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.model.MbCmnCodeVO;

import java.util.List;
import java.util.Map;


public interface BdEtrMapper {

	/**
	 * <pre>
	 * 처리내용: 회원가입
	 * </pre>
	 * @date 2023. 9. 5.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * @param bdEtrVO
	 * @return
	 * @throws Exception
	 */
	public void insertBidEtrInfo(BdEtrVO bdEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 아이디 중복체크
	 * </pre>
	 * @date 2023. 9. 5.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * @param bdEtrVO
	 * @return
	 * @throws Exception
	 */
	int checkEtrInfo(BdEtrVO bdEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 사업자 번호 확인
	 * </pre>
	 * @date 2023. 9. 5.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * @param bdEtrVO
	 * @return
	 * @throws Exception
	 */
	int checkRegistNo(BdEtrVO bdEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 국가 번호 리스트 조회
	 * </pre>
	 * @date 2023. 9. 5.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * @return
	 * @throws Exception
	 */
	List<MbCmnCodeVO> selectNationNoCodeList() throws Exception;

}
