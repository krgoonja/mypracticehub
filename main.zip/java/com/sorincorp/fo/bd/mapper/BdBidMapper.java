package com.sorincorp.fo.bd.mapper;

import java.util.List;

import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.bd.model.BdBddprVO;
import com.sorincorp.fo.bd.model.BdBidUpdtVO;
import com.sorincorp.fo.bd.model.BdBidVO;
import com.sorincorp.fo.bd.model.BdScsAtcDocVO;


public interface BdBidMapper {

	

	BdBidVO selectBdBid(BdBidVO bdBidVO) throws Exception ;

	List<BdBddprVO> selectBdBddprList(BdBidVO bdBidVO) throws Exception ;
	
	/**
	 * <pre>
	 * 처리내용: 업체 투찰 데이터 등록한다 
	 * </pre>
	 * @date 2023. 08. 29.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 29.		sein			최초작성
	 * @param bdBddprVO
	 * @return  
	 * @throws Exception
	 */
	void insertBdBddpr(BdBddprVO bdBddprVO) throws Exception ;
	
	/**
	 * <pre>
	 * 처리내용: 업체 투찰 취소 정보 수
	 * </pre>
	 * @date 2022. 12. 06.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 06.		sein			최초작성
	 * @param String
	 * @return int
	 * @throws Exception
	 */
	int selectBddprCanclCount(String bidEntrpsNo) throws Exception ;
	
	int updateBdEntrps(BdAccount bdAccount) throws Exception ;
	
	int updateBdBddpr(BdBddprVO bdBddprVO) throws Exception ;
	
	List<BdScsAtcDocVO> selectBdDocList(BdBddprVO bdBddprVO) throws Exception ;
	
	List<BdScsAtcDocVO> selectBdScsAtcList(BdScsAtcDocVO bdScsAtcDocVO) throws Exception;

	void insertBdScsAtcDoc(BdScsAtcDocVO bdScsAtcDocVO) throws Exception;
	
	void deleteBdScsAtcDoc(BdScsAtcDocVO bdScsAtcDocVO)throws Exception;
	
	List<BdScsAtcDocVO> bdDocSubmit(BdScsAtcDocVO bdScsAtcDocVO) throws Exception;
	
	void updateBdBidBasSttus(BdScsAtcDocVO bdScsAtcDocVO)throws Exception;
	void updateBdScsbidDtlSttus(BdScsAtcDocVO bdScsAtcDocVO)throws Exception;
	void updateBdScsbidAtcSttus(BdScsAtcDocVO bdScsAtcDocVO)throws Exception;

	void updateBdBidPartcptnQyPlus(BdBddprVO bdBddprVO)throws Exception;
	void updateBdBidPartcptnQyMinus(BdBddprVO bdBddprVO)throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 입찰 수정 사유 리스트
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.	  	sein			최초작성
	 * ------------------------------------------------
	 * @param bdBidVO
	 * @return List<BdBidUpdtVO>
	 * @throws Exception
	 */
	public List<BdBidUpdtVO> selectBdBidUpdtList(BdBidVO bdBidVO) throws Exception ;
	/**
	 * <pre>
	 * 처리내용: 각 공고 및 업체의 관심공고 체크 여부를 확인한다.
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param bdBidVO
	 * @return BdBidVO
	 * @throws Exception
	 */
	BdBidVO selectIntrstPblancCheck(BdBidVO bdBidVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 인도조건창고 목록 리스트를 확인한다.
	 * </pre>
	 * @date 2023. 9. 15.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 15.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param bdBidVO
	 * @return BdBidVO
	 * @throws Exception
	 */
	List<BdBidVO> selectLgistCnterList(BdBidVO bdBidVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 인도조건창고 목록 개수를 확인한다.
	 * </pre>
	 * @date 2023. 9. 15.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 15.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param bdBidVO
	 * @return int
	 * @throws Exception
	 */
	int selectLgistCnterCnt(BdBidVO bdBidVO) throws Exception;
	
	BdScsAtcDocVO selectBdDoc(BdScsAtcDocVO bdScsAtcDocVO) throws Exception;
	
	List<BdScsAtcDocVO> selectModalDocCheck(BdScsAtcDocVO bdScsAtcDocVO) throws Exception;
	
	BdBidVO selectBdBddprInfo(BdBidVO bdBidVO) throws Exception;
	
	List<BdBidVO> selectBidDelyCndList(BdBidVO bdBidVO) throws Exception;
	
}
