package com.sorincorp.fo.bd.mapper;

import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.bd.model.BdLoginVO;
import com.sorincorp.fo.login.model.Account;

public interface BdAccountMapper {
	/**
	 * <pre>
	 * User ID로 사용자의 정보를 가져온다.
	 * </pre>
	 * @date 2022. 8. 24.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 24.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param id
	 * @return
	 * @throws Exception
	 */
	BdAccount selectBdAccount(String id) throws Exception;

	/**
	 * <pre>
	 * 로그인정보를 로그인이력에 저장한다.
	 * </pre>
	 * @date 2022. 8. 25.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 25.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param id
	 * @return
	 * @throws Exception
	 */
	void insertBdLoginHist(BdLoginVO logVo);

}
