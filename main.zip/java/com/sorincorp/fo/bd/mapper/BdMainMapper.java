package com.sorincorp.fo.bd.mapper;

import java.util.List;

import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.bd.model.BdBidVO;

public interface BdMainMapper {
    /**
     * <pre>
     * 처리내용: 메인 사용자 대시보드 정보를 조회한다.
     * </pre>
     * @date 2023. 8. 28.
     * @author srec0077
     * @history
     * ------------------------------------------------
     * 변경일                  작성자          변경내용
     * ------------------------------------------------
     * 2023. 8. 28.         srec0077            최초작성
     * ------------------------------------------------
     * @param vo
     * @return
     * @throws Exception
     */
    BdAccount getBdUserDashboardData(BdAccount vo) throws Exception;
    
    int getBdIntrstBidCnt(String bidEntrpsNo) throws Exception;
    
    List<BdBidVO> selectBdMainList(BdBidVO bdBidVO) throws Exception;
    
    List<BdBidVO> selectBdMainCnt(BdBidVO bdBidVO) throws Exception;
    
}
