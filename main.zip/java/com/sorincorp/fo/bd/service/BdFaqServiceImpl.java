package com.sorincorp.fo.bd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.bd.mapper.BdFaqMapper;
import com.sorincorp.fo.bd.model.BdFaqVO;
import com.sorincorp.fo.bd.service.BdFaqServiceImpl;
import lombok.extern.slf4j.Slf4j;

/**
 * BdFaqServiceImpl.java
 * @version
 * @since 2021. 12. 15.
 * @author bok young
 */
@Service
@Slf4j
public class BdFaqServiceImpl implements BdFaqService {
	
	@Autowired
	BdFaqMapper csfFaqMapper;
	
	/**
	 * <pre>
	 * Faq 전체 Count 조회한다.
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * 2022. 12.15.			bok young			최종수정
	 * ------------------------------------------------
	 * @param seachVo
	 * @return int
	 * @throws Exception
	 */
	@Override
	public int selectFaqListTotCnt(BdFaqVO seachVo) throws Exception {
		return csfFaqMapper.selectFaqListTotCnt(seachVo);
	}

	/**
	 * <pre>
	 * Faq 목록을 조회한다
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * 2022. 12.15.			bok young			최종수정
	 * ------------------------------------------------
	 * @param seachVo
	 * @return list BdFaqVO
	 * @throws Exception
	 */
	@Override
	public List<BdFaqVO> selectFaqList(BdFaqVO seachVo) throws Exception {
		List<BdFaqVO> faqList = csfFaqMapper.selectFaqList(seachVo);
		
		try {
			if(faqList != null && faqList.size() > 0) {
				for(BdFaqVO faqVo : faqList) {
					int faqNo = faqVo.getFaqNo();
					faqVo.setAttachFiles(csfFaqMapper.selectDocInfoList(faqNo));
				}
			}
		} catch(Exception e) {
            log.error("BdFaqServiceImpl selectFaqList ERROR " + e.getMessage());
       }
		return faqList;
	}
	
	/**
	 * FAQ 최근 질문 4개를 조회한다. 
	 * */
	@Override
	public List<BdFaqVO> showFaq(BdFaqVO seachVo) throws Exception {
		return csfFaqMapper.showFaq(seachVo);
	}
}
