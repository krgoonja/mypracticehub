package com.sorincorp.fo.bd.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.fo.bd.mapper.BdBidMapper;
import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.bd.model.BdBddprVO;
import com.sorincorp.fo.bd.model.BdBidUpdtVO;
import com.sorincorp.fo.bd.model.BdBidVO;
import com.sorincorp.fo.bd.model.BdScsAtcDocVO;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.login.service.AccountServiceImpl;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BdDetailServiceImpl implements BdDetailService {

	@Autowired
	BdBidMapper bdBidMapper;
	@Autowired
	AccountServiceImpl accountService;
	@Autowired
	UserInfoUtil userInfoUtil;
	@Autowired
	private CommonService commonService;
	
	@Autowired
    public FileDocService fileDocService;
	@Override
	public BdBidVO selectBdBid(BdBidVO bdBidVO) throws Exception {
		return bdBidMapper.selectBdBid(bdBidVO);
	}
	
	@Override
	public List<BdBddprVO> selectBdBddprList(BdBidVO bdBidVO) throws Exception {
		return bdBidMapper.selectBdBddprList(bdBidVO);
	}
	
	/**
	 * <pre>
	 * 처리내용: 업체 투찰 데이터를 등록한다 
	 * </pre>
	 * @date 2023. 08. 29.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 29.		sein			최초작성
	 * @param bddprVO
	 * @return  
	 * @throws Exception
	 */
	@Override
	public String insertBdBddpr(BdBddprVO bdBddprVO) throws Exception {

		BdAccount account = userInfoUtil.getBdAccountInfo();

		if (account != null) {

			// 입찰 공고 가져오기
			BdBidVO bdBidVO = new BdBidVO();
			bdBidVO.setBidPblancId(bdBddprVO.getBidPblancId());
			bdBidVO = selectBdBid(bdBidVO);
			
			// 현재 일시yyyyMMddHHmmss
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
			Date time = new Date();
			String nowTime = dateFormat.format(time);
			// 투찰중 상태일때만 가능
			if (bdBidVO.getBidSttusCode().equals("13") && (Long.parseLong(bdBidVO.getBddprBeginDt())<Long.parseLong(nowTime) && Long.parseLong(bdBidVO.getBddprEndDt())>Long.parseLong(nowTime))) {
				

				// 인도 조건 코드에 따라 인도 조건 기준 가격, 전환 프리미엄 금액 설정
				switch (bdBddprVO.getDelyCndCode()) {
				case "01":
					bdBddprVO.setDelyCndStdrPc(bdBidVO.getDelyCnd01StdrPc());
					bdBddprVO.setCnvrsPremiumAmount(bdBidVO.getDelyCnd01PremiumPc());
					break;
				case "02":
					bdBddprVO.setDelyCndStdrPc(bdBidVO.getDelyCnd02StdrPc());
					bdBddprVO.setCnvrsPremiumAmount(bdBidVO.getDelyCnd02PremiumPc());
					break;
				case "03":
					bdBddprVO.setDelyCndStdrPc(bdBidVO.getDelyCnd03StdrPc());
					bdBddprVO.setCnvrsPremiumAmount(bdBidVO.getDelyCnd03PremiumPc());
					break;
				}

				// 투찰 기업 정보 등록
				// 투찰 중량
				bdBddprVO.setBddprWt(bdBidVO.getBidWt());
				// 입찰 업체 번호
				bdBddprVO.setBidEntrpsNo(account.getBidEntrpsNo());
				// 투찰 일시
				bdBddprVO.setBddprDt(nowTime);
				// 투찰 정상 여부
				bdBddprVO.setBddprNrmltAt("Y");
				// 최초 등록자 아이디
				bdBddprVO.setFrstRegisterId(account.getBidMberId());
				// 최종 변경자 아이디
				bdBddprVO.setLastChangerId(account.getBidMberId());
				// 낙찰 여부
				bdBddprVO.setScsbidAt("N");
				// 취소 여부
				bdBddprVO.setCanclAt("N");
				// 삭제 여부
				bdBddprVO.setDeleteAt("N");

				// 알림,문자,메시저 전송(낙찰, 패찰)
				// bdBddprVO = bdDetailService.selectBddpr(bddprVO);
				// bidKkoSmsAlaService.BidKkoSmsAlaSend(bddprVO);
				
				//투찰 기업 insert
				bdBidMapper.insertBdBddpr(bdBddprVO);
				commonService.insertTableHistory("BD_BDDPR_DTL", bdBddprVO);
				
				//참여 업체 수량 +1 update(BD_BID_BAS)
				bdBidMapper.updateBdBidPartcptnQyPlus(bdBddprVO);
				commonService.insertTableHistory("BD_BID_BAS", bdBddprVO);
				
				return "success";
			}else {
				return "fail";
			}
		} else {
			return "logout";
		}

	}
	
	/**
	 * 투찰 취소 개수를 센다.
	 */
	@Override
	public int selectBddprCanclCount(BdBidVO bdBidVO) throws Exception {

		BdAccount account = userInfoUtil.getBdAccountInfo();
		// 현재 일시yyyyMMddHHmmss
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date time = new Date();
		String nowTime = dateFormat.format(time);
		// 로그인 여부 확인
		if (account != null) {
			// 입찰 공고 가져오기
			bdBidVO = selectBdBid(bdBidVO);

			// 투찰중 상태, 투찰취소 기간안에 취소가능
			if (bdBidVO.getBidSttusCode().equals("13") && (Long.parseLong(bdBidVO.getBddprBeginDt())<Long.parseLong(nowTime) && Long.parseLong(bdBidVO.getBddprEndDt())>Long.parseLong(nowTime)) && Long.parseLong(bdBidVO.getBddprCanclLmttDe())>Long.parseLong(nowTime)) {
				int num = bdBidMapper.selectBddprCanclCount(account.getBidEntrpsNo());
				// 투찰 취소 갯수
				if (num < 4) {
					return num;
				} else {
					throw new Exception("투찰취소 가능 횟수를 초과했습니다.");
				}
			} else {
				throw new Exception("투찰취소 기간이 지났습니다.");
			}
		} else {
			throw new Exception("로그아웃 되었습니다. 다시 로그인 해주세요.");
		}
	}
	
	@Transactional(rollbackFor = Exception.class)
	@Override
	public boolean deleteBdBddpr(BdBddprVO bdBddprVO) throws Exception {

		BdAccount account = userInfoUtil.getBdAccountInfo();
		BdBidVO bdBidVO = new BdBidVO();

		// 로그인 여부 확인
		if (account != null) {
			// 입찰 업체 번호
			bdBddprVO.setBidEntrpsNo(account.getBidEntrpsNo());
			
			// 입찰 공고 가져오기
			bdBidVO.setBidPblancId(bdBddprVO.getBidPblancId());
			bdBidVO = selectBdBid(bdBidVO);

			// 투찰중 상태일때만 가능
			if (bdBidVO.getBidSttusCode().equals("13")) {
				bdBddprVO.setLastChangerId(account.getBidMberId());
				// 기업 투찰 취소 카운드 +1
				int updateBdEntrpsNum = updateBdEntrps(account);
				// 투찰 업체 취소
				int updateBdBddprNum = updateBdBddpr(bdBddprVO);
				// 하나라도 업데이트 안 될 시 로직 구현 필요
				if (updateBdEntrpsNum > 0 && updateBdBddprNum > 0) {
					// history
					commonService.insertTableHistory("BD_BDDPR_DTL", bdBddprVO);
					commonService.insertTableHistory("BD_ENTRPS_INFO_BAS", account);
					
					//참여 업체 수량 -1 update(BD_BID_BAS)
					bdBidMapper.updateBdBidPartcptnQyMinus(bdBddprVO);
					commonService.insertTableHistory("BD_BID_BAS", bdBddprVO);
					//투찰 횟수 체크 
					account = accountService.selectBdAccount(account.getBidMberId());
					if(!account.getBidMberSttusCode().equals("02")){
						return true;
					//(3회 초과시 로그아웃)
					}else {
						return false;
					}
				} else {
					throw new Exception("deleteBdBddpr : update 중 rollback처리");
				}
			} else {
				throw new Exception("투찰취소 기간이 지나서 투찰(취소)가 불가능합니다.");
			}
		} else {
			throw new Exception("로그아웃 되었습니다. 다시 로그인 해주세요.");
		}
	}
	
	@Override
	public int updateBdEntrps(BdAccount bdAccount) throws Exception {
		return  bdBidMapper.updateBdEntrps(bdAccount);
	}

	@Override
	public int updateBdBddpr(BdBddprVO bdBddprVO) throws Exception {
		return bdBidMapper.updateBdBddpr(bdBddprVO);
	}
	
	@Override
	public List<BdScsAtcDocVO> selectBdDocList(BdBddprVO bdBddprVO) throws Exception {
		return bdBidMapper.selectBdDocList(bdBddprVO);
	} 
	
	@Override
    public Map<String, Object> saveAttachFile(MultipartHttpServletRequest mRequest) throws Exception {
        Map<String,Object> map = new HashMap<String,Object>();
        List<FileDocVO> list = new ArrayList<FileDocVO>();

        list = fileDocService.uploadPublicAttachFilesVoList("BD", mRequest);// 파일 저장

        map.put("list", list);
        return map;
    }
	
	@Transactional(rollbackFor = Exception.class)
	@Override
	public Map<String,Object> deleteAttachFile(FileDocVO fileVO) throws Exception {
		BdAccount account = userInfoUtil.getBdAccountInfo();
		BdScsAtcDocVO bdScsAtcDocVO = new BdScsAtcDocVO();
		
		bdScsAtcDocVO.setDocNo(fileVO.getDocNo());
		bdScsAtcDocVO.setEntrpsNm(account.getBidMberId());

		Map<String,Object> map = new HashMap<>();
		// 로그인 여부 확인
		if (account != null) {
	
			//공통_문서 기본 - 문서 사용 여부 'N'으로 수정
			fileDocService.deleteCommonDoc(fileVO.getDocNo());
	
			//입찰 낙찰 첨부파일 - 문서 사용 여부 'N'으로 수정
			bdBidMapper.deleteBdScsAtcDoc(bdScsAtcDocVO);

			List<String> hstList = new ArrayList<String>() ;
			hstList.add("DOC_NO");
			
			commonService.insertTableHistory("BD_SCSBID_ATCHMNFL_BAS", fileVO , hstList);
			
			map.put("docNo", fileVO.getDocNo());
			map.put("result","success");
		}else {
			throw new Exception("로그아웃 되었습니다. 다시 로그인 해주세요.");
		}
		
		return map;
	}
	
	public Map<String,Object> modalDocInfoAjax(BdScsAtcDocVO bdScsAtcDocVO) throws Exception {
		BdAccount account = userInfoUtil.getBdAccountInfo();

		if (account != null) {
			Map<String,Object> map = new HashMap<>();
			
			List<BdScsAtcDocVO> bdScsAtcList = new ArrayList<BdScsAtcDocVO>(); //BD_SCSBID_DTL 받아와서 00~09 분류 후 jsp설정
			bdScsAtcList = bdBidMapper.selectBdScsAtcList(bdScsAtcDocVO);
			BdScsAtcDocVO bdDoc =bdBidMapper.selectBdDoc(bdScsAtcDocVO);
			map.put("bdScsAtcList", bdScsAtcList);
			map.put("bdDoc", bdDoc);

			return map;
		}else {
			throw new Exception("로그아웃 되었습니다. 다시 로그인 해주세요.");
		}
	}
	
	public Map<String,Object> modalDocCheck(BdScsAtcDocVO bdScsAtcDocVO) throws Exception {
		BdAccount account = userInfoUtil.getBdAccountInfo();
		BdBddprVO tmp = new BdBddprVO();
		if (account != null) {
			Map<String,Object> map = new HashMap<>();
			
			List<BdScsAtcDocVO> bdDocList = new ArrayList<BdScsAtcDocVO>(); //BD_SCSBID_DTL 받아와서 00~09 분류 후 jsp설정
			List<BdScsAtcDocVO> bdDocTyCodeList = new ArrayList<BdScsAtcDocVO>(); //BD_SCSBID_DTL 받아와서 00~09 분류 후 jsp설정
			tmp.setBidPblancId(bdScsAtcDocVO.getBidPblancId());
			bdDocList = bdBidMapper.selectModalDocCheck(bdScsAtcDocVO);
			bdDocTyCodeList = bdBidMapper.selectBdDocList(tmp);
			
			List<BdScsAtcDocVO> bdDocCntTySttusList = new ArrayList<BdScsAtcDocVO>();
			
			for(BdScsAtcDocVO tyCode : bdDocTyCodeList) {
				int docTy02Code = 0;
				int docTy03Code = 0;
				BdScsAtcDocVO addBd = new BdScsAtcDocVO();
				//입찰 문서 타입코드 
				addBd.setBidDocTyCode(tyCode.getBidDocTyCode());
				//심사현황(적합 셋팅)
				addBd.setBidDocJdgmnSttusCode("01");
				for(BdScsAtcDocVO docVo : bdDocList) {
					//문서 타입 비교
					if(tyCode.getBidDocTyCode().equals(docVo.getBidDocTyCode())) {
						//서류 등록 개수(서류접수중)
						if(docVo.getBidDocJdgmnSttusCode().equals("02")) {
							docTy02Code+=docVo.getBidDocCnt();
						}
						//서류 등록 개수(적합)
						if(docVo.getBidDocJdgmnSttusCode().equals("03")) {
							docTy03Code+=docVo.getBidDocCnt();
						}
						//서류 등록 개수(전체)
						addBd.setBidDocCnt(addBd.getBidDocCnt()+docVo.getBidDocCnt());
						//심사현황(제출:01))
						if(docVo.getBidDocJdgmnSttusCode().equals("01") && !addBd.getBidDocJdgmnSttusCode().equals("04")) {
							addBd.setBidDocJdgmnSttusCode("01");
						//심사현황(부적합:02))
						}else if(docVo.getBidDocJdgmnSttusCode().equals("04")) {
							addBd.setBidDocJdgmnSttusCode("04");
						}
					}
				}
				//서류접수증 == 서류 등록 개수
				if(addBd.getBidDocCnt() == docTy02Code + docTy03Code){
					addBd.setBidDocJdgmnSttusCode("02");
				}
				
				//적합 == 서류 등록 개수
				if(addBd.getBidDocCnt()==docTy03Code){
					addBd.setBidDocJdgmnSttusCode("03");
				}
				//서류제출 개수가 0이면 
				if(addBd.getBidDocCnt()==0) {
					addBd.setBidDocJdgmnSttusCode("01");
				}
				bdDocCntTySttusList.add(addBd);		
			}
			
			map.put("bdDocCntTySttusList", bdDocCntTySttusList);
			
			return map;
		}else {
			throw new Exception("로그아웃 되었습니다. 다시 로그인 해주세요.");
		}
	}
	
	@Transactional(rollbackFor = Exception.class)
	@Override
	public String insertBdScsAtcDoc(BdScsAtcDocVO bdScsAtcDocVO) throws Exception {
		
		BdAccount account = userInfoUtil.getBdAccountInfo();

		if (account != null) {
			bdScsAtcDocVO.setEntrpsNm(account.getBidMberId());
			bdBidMapper.insertBdScsAtcDoc(bdScsAtcDocVO);
			commonService.insertTableHistory("BD_SCSBID_ATCHMNFL_BAS", bdScsAtcDocVO);
			return "success"; 
		}else {
			throw new Exception("로그아웃 되었습니다. 다시 로그인 해주세요.");
		}
		
	}
	@Transactional(rollbackFor = Exception.class)
	@Override
	public String bdDocSubmit(BdScsAtcDocVO bdScsAtcDocVO) throws Exception {
	
		BdAccount account = userInfoUtil.getBdAccountInfo();
		BdBidVO bdBidVO = new BdBidVO();
		try {
			
			//로그인 여부 확인
			if (account != null) {
				bdScsAtcDocVO.setBidEntrpsNo(account.getBidEntrpsNo());
				bdScsAtcDocVO.setEntrpsNm(account.getEntrpsNm());
				// 입찰 공고 가져오기
				bdBidVO.setBidPblancId(bdScsAtcDocVO.getBidPblancId());
				bdBidVO = selectBdBid(bdBidVO);
							
				// 서류 접수중 상태일때만 가능
				//if (bdBidVO.getBidSttusCode().equals("22")) {
				//입찰_낙찰 상세 - 심사 상태 코드가 "승인"이 아닐 경우 문서수정 가능
				if( StringUtils.isEmpty(bdScsAtcDocVO.getJdgmnSttusCode()) ) {
					bdScsAtcDocVO.setJdgmnSttusCode("20"); //심사요청
				}
				
				if(!bdScsAtcDocVO.getJdgmnSttusCode().equals("40")) {
					//서류 현황 가져오기
					List<BdScsAtcDocVO> checkDocList = bdBidMapper.bdDocSubmit(bdScsAtcDocVO);
					
					//서류 제출 확인
					for(BdScsAtcDocVO vo : checkDocList) {
						//서류 존재 x
						if(vo.getDeleteAt()==null || vo.getDeleteAt() == "") {
							throw new Exception("제출되지 않은 서류가 존재합니다.");
						//재요청 서류 존재 o
						}else if(vo.getDeleteAt().equals("N") && vo.getReRequstTrgetAt().equals("Y")){
							throw new Exception("다시 제출 해야하는 서류가 존재합니다.");
						}
					}
					//상태 값 업데이트
					bdBidMapper.updateBdBidBasSttus(bdScsAtcDocVO);
					commonService.insertTableHistory("BD_BID_BAS", bdScsAtcDocVO);
					bdBidMapper.updateBdScsbidDtlSttus(bdScsAtcDocVO);
					commonService.insertTableHistory("BD_SCSBID_DTL", bdScsAtcDocVO);
					bdBidMapper.updateBdScsbidAtcSttus(bdScsAtcDocVO);
					commonService.insertTableHistory("BD_SCSBID_ATCHMNFL_BAS", bdScsAtcDocVO);

					return "success";
				} else {
					throw new Exception("Not available yet.");
				}
				
			}else {
				throw new Exception("로그아웃 되었습니다. 다시 로그인 해주세요.");
			}
		}catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}		
	
	/**
	 * 입찰 수정 사유 리스트
	 */
	@Override
	public List<BdBidUpdtVO> selectBdBidUpdtList(BdBidVO bdBidVO) throws Exception {
		return bdBidMapper.selectBdBidUpdtList(bdBidVO);
	}
	
	/**
	 * 각 공고 및 업체의 관심공고 체크 여부를 확인한다.
	 */
	@Override
	public BdBidVO selectIntrstPblancCheck(BdBidVO bdBidVO) throws Exception {
		BdAccount account = userInfoUtil.getBdAccountInfo();
		bdBidVO.setBidEntrpsNo(account.getBidEntrpsNo());
		return bdBidMapper.selectIntrstPblancCheck(bdBidVO);
	}
	
	/**
	 * 인도조건창고 목목 리스트를 확인한다.
	 */
	@Override
	public List<BdBidVO> selectLgistCnterList(BdBidVO bdBidVO) throws Exception {
		return bdBidMapper.selectLgistCnterList(bdBidVO);
	}
	
	/**
	 * 인도조건창고 목록 리스트 개수를 확인한다.
	 */
	@Override
	public int selectLgistCnterCnt(BdBidVO bdBidVO) throws Exception {
		int lgistCnt = bdBidMapper.selectLgistCnterCnt(bdBidVO);
		return lgistCnt;
	}
	

    @Override
    public BdBidVO selectBdBddprInfo(BdBidVO bdBidVO) throws Exception {
        BdAccount account = userInfoUtil.getBdAccountInfo();
        bdBidVO.setBidEntrpsNo(account.getBidEntrpsNo());
        return bdBidMapper.selectBdBddprInfo(bdBidVO);
    }
    
    /**
     * 인도조건 목록을 조회한다.
     */
    @Override
    public List<BdBidVO> selectBidDelyCndList(BdBidVO bdBidVO) throws Exception {
        return bdBidMapper.selectBidDelyCndList(bdBidVO);
    }
}
