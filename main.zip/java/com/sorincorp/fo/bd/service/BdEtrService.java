package com.sorincorp.fo.bd.service;

import com.sorincorp.fo.bd.model.BdEtrVO;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.model.MbCmnCodeVO;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface BdEtrService {


	/**
	 * <pre>
	 * 처리내용: 회원가입
	 * </pre>
	 * @date 2023. 9. 5.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdEtrVO
	 * @return  
	 * @throws Exception
	 */
	public String insertBidEtrInfo(BdEtrVO bdEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 아이디 중복 확인
	 * </pre>
	 *
	 * @date 2023. 9. 5.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdEtrVO
	 * @return
	 * @throws Exception
	 */
	String checkEtrInfo(BdEtrVO bdEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 사업자 등록번호 중복확인
	 * </pre>
	 *
	 * @date 2023. 9. 5.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdEtrVO
	 * @return
	 * @throws Exception
	 */
	String checkRegistNo(BdEtrVO bdEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 파일 업로드
	 * </pre>
	 *
	 * @date 2023. 9. 5.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param mRequest
	 * @return
	 */
	HashMap<String, String> bidEtrFileUpload(MultipartHttpServletRequest mRequest) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 파일 삭제
	 * </pre>
	 * @date 2023. 9. 5.
	 * @author hamyoonsic
	 * @history
	 * <pre>
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdEtrVO
	 * @return
	 * @throws Exception
	 */
	int deleteBidFile(BdEtrVO bdEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 국가 번호 리스트 조회
	 * </pre>
	 * @date 2023. 9. 5.
	 * @author hamyoonsic
	 * @history
	 * <pre>
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<MbCmnCodeVO> selectNationNoCodeList() throws Exception;

}
