package com.sorincorp.fo.bd.service;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.fo.mb.model.MbCmnCodeVO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.fo.bd.mapper.BdAccountMapper;
import com.sorincorp.fo.bd.mapper.BdEtrMapper;
import com.sorincorp.fo.bd.model.BdEtrVO;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class BdEtrServiceImpl implements BdEtrService {

	@Autowired
	BdAccountMapper bdAccountMapper;

	@Autowired
	BdEtrMapper bdEtrMapper;

	@Autowired
	AssignService assignService;

	@Autowired
	private CommonService commonService;

	@Autowired
	public FileDocService fileDocService;

	@Autowired
	MessageUtil messageUtil;
	/**
	 * <pre>
	 * 처리내용: 회원가입
	 * </pre>
	 * @date 2023. 9. 5.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdEtrVO
	 * @return
	 * @throws Exception
	 */
	@Transactional(rollbackFor = Exception.class)
	@Override
	public String insertBidEtrInfo(BdEtrVO bdEtrVO) throws Exception {
		log.debug("BdEtrServiceImpl:insertBidEtrInfo 구매입찰 회원가입 Start");
		String res = "F";
		try {
			//입찰 업체 번호 BID_ENTRPS_NO 채번
			String bidEntrpsNo = assignService.selectAssignValue("BD", "BID_ENTRPS_NO", "BID_ENTRPS_NO", "SYSTEM", 4);
			bdEtrVO.setBidEntrpsNo("B" + bidEntrpsNo);
			//비밀번호 암호화
			String bidMberSecretNo = bdEtrVO.getBidMberSecretNo();
			if (StringUtils.isNotEmpty(bidMberSecretNo) && !bidMberSecretNo.equals("null")) {
				try {
					log.debug("비밀번호 암호화 전 ==================>" + bidMberSecretNo);
					bidMberSecretNo = CryptoUtil.encryptSHA256(bidMberSecretNo);
					log.debug("비밀번호 암호화 후 ==================>" + bidMberSecretNo);
					/** 비밀번호 셋팅 **/
					bdEtrVO.setBidMberSecretNo(bidMberSecretNo);
				} catch (Exception e) {
					log.error("BdEtrServiceImpl :: insertBidEtrInfo BidMberSecretNo CryptoUtil.encryptAES256 ERROR " + e.getMessage());
				}
			}
			//휴대전화 번호 암호화
			String moblphonNo2 = bdEtrVO.getMoblphonNo2();
			String vrscMoblphonNo = bdEtrVO.getVrscMoblphonNo();
			if (StringUtils.isNotEmpty(moblphonNo2) && !moblphonNo2.equals("null")) {
				try {
					log.debug("휴대전화 번호 암호화 전 ==================>" + moblphonNo2);
					moblphonNo2 = CryptoUtil.encryptAES256(moblphonNo2);
					log.debug("휴대전화 번호 암호화 후 ==================>" + moblphonNo2);
					/** 휴대전화 번호 셋팅 **/
					bdEtrVO.setMoblphonNo2(moblphonNo2);
				} catch (Exception e) {
					log.error("BdEtrServiceImpl :: insertBidEtrInfo moblphonNo2 CryptoUtil.encryptAES256 ERROR " + e.getMessage());
				}
			}
			//입찰 대리인 휴대전화 번호 암호화
			if (StringUtils.isNotEmpty(vrscMoblphonNo) && !vrscMoblphonNo.equals("null")) {
				try {
					log.debug("휴대전화 번호 암호화 전 ==================>" + vrscMoblphonNo);
					vrscMoblphonNo = CryptoUtil.encryptAES256(vrscMoblphonNo);
					log.debug("휴대전화 번호 암호화 후 ==================>" + vrscMoblphonNo);
					/** 입찰 대리인 휴대전화 번호 셋팅 **/
					bdEtrVO.setVrscMoblphonNo(vrscMoblphonNo);
				} catch (Exception e) {
					log.error("BdEtrServiceImpl :: insertBidEtrInfo vrscMoblphonNo CryptoUtil.encryptAES256 ERROR " + e.getMessage());
				}
			}
			String entrpsTlphonNo = bdEtrVO.getEntrpsTlphonNo();
			String vrscTlphonNo = bdEtrVO.getVrscTlphonNo();
			if(entrpsTlphonNo != null && !"".equals(entrpsTlphonNo)){
				log.info("업체 회사번호 복호화 전 ===============>" + entrpsTlphonNo);
				entrpsTlphonNo = CryptoUtil.encryptAES256(entrpsTlphonNo);
				log.info("업체 회사번호 복호화 후 ===============>" + entrpsTlphonNo);
				bdEtrVO.setEntrpsTlphonNo(entrpsTlphonNo);
			}
			if(vrscTlphonNo != null && !"".equals(vrscTlphonNo)){
				log.info("대행업체 회사번호 복호화 전 ===============>" + vrscTlphonNo);
				vrscTlphonNo = CryptoUtil.encryptAES256(vrscTlphonNo);
				log.info("대행업체 회사번호 복호화 후 ===============>" + vrscTlphonNo);
				bdEtrVO.setVrscTlphonNo(vrscTlphonNo);
			}
			bdEtrVO.setFrstRegisterId(bdEtrVO.getBidMberId());
			bdEtrVO.setLastChangerId(bdEtrVO.getBidMberId());
			bdEtrVO.setBidMberSttusCode("03");//입찰 회원 상태 코드 01 정상 02 차단 03 승인 대기
			bdEtrVO.setBidConfmSttusCode("01");//입찰 승인 상태 코드 01 승인 요청  02 승인 거절 03 승인 정상
			bdEtrVO.setBidConfmDetailSttusCode("01");//입찰 승인 상세 상태 코드 01 회원가입 02 회원정보 변경
			bdEtrMapper.insertBidEtrInfo(bdEtrVO);
			commonService.insertTableHistory("BD_ENTRPS_INFO_BAS", bdEtrVO);
			res = "S";
		} catch (Exception e) {
			log.error("BdEtrServiceImpl :: insertBidEtrInfo 구매입찰 회원가입 ERROR " + e.getMessage());
			res = "F";
			return res;
		}
		return res;
	}

	/**
	 * <pre>
	 * 처리내용: 아이디 중복 확인
	 * </pre>
	 *
	 * @date 2023. 9. 5.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdEtrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public String checkEtrInfo(BdEtrVO bdEtrVO) throws Exception {
		String msg = "";
		try {
			int dpCnt = bdEtrMapper.checkEtrInfo(bdEtrVO);
			if(dpCnt > 0) {
				msg = "이미 가입된 아이디 입니다.";
				return msg;
			}
		} catch (Exception e) {
			log.error("BdEtrServiceImpl :: checkEtrInfo 구매입찰 회원가입 ERROR " + e.getMessage());
			msg = "아이디 중복 체크 도중 오류가 발생했습니다.";
			return msg;
		}
		return msg;
	}

	/**
	 * <pre>
	 * 처리내용: 사업자 등록번호 중복 확인
	 * </pre>
	 *
	 * @date 2023. 9. 5.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdEtrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public String checkRegistNo(BdEtrVO bdEtrVO) throws Exception {
		String msg = "";
		try {
			int dpCnt = bdEtrMapper.checkRegistNo(bdEtrVO);
			if(dpCnt > 0) {
				msg = "이미 사용중인 사업자 등록번호 입니다.";
				return msg;
			}
		} catch (Exception e) {
			log.error("BdEtrServiceImpl :: checkRegistNo 구매입찰 회원가입 사업자 등록번호 확인 ERROR " + e.getMessage());
			msg = "사업자 등록번호 확인 중 오류가 발생했습니다.";
			return msg;
		}
		return msg;
	}

	/**
	 * <pre>
	 * 처리내용: 파일 업로드
	 * </pre>
	 *
	 * @date 2023. 9. 5.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param mRequest
	 * @return
	 * @throws Exception
	 */
	@Override
	public HashMap<String, String> bidEtrFileUpload(MultipartHttpServletRequest mRequest) {
		List<FileDocVO> fileKeys = null;
		FileDocVO fileDocVO = new FileDocVO();
		HashMap<String, String> fileMap = new HashMap<>();

		String errMsg = "";

		try {
			fileKeys = fileDocService.uploadAttachFilesVoList("BD", mRequest);
			fileDocVO = fileKeys.get(0);
			fileMap.put("docNo", Integer.toString(fileDocVO.getDocNo()));
			fileMap.put("fileName", fileDocVO.getDocFileNm());
			fileMap.put("filePath", fileDocVO.getDocFileRealCours());
			fileMap.put("result", "S");

		} catch (Exception e) {
			log.error(e.toString());
			errMsg = messageUtil.getMessage(e.getMessage());
			fileMap.put("result", "F");
		} finally {
			fileMap.put("errMsg", errMsg);
			return fileMap;
		}
	}

	/**
	 * <pre>
	 * 처리내용: 파일 삭제
	 * </pre>
	 * @date 2023. 9. 16.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bdEtrVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int deleteBidFile(BdEtrVO bdEtrVO) throws Exception {
		int docNo = bdEtrVO.getDocNo();
		int resultDelCoAt = -1;
		try {
			fileDocService.deleteCommonDoc(docNo);
			resultDelCoAt = 1;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw e;
		}
		return resultDelCoAt;
	}

	/**
	 * <pre>
	 * 처리내용: 국가 번호 리스트 조회
	 * </pre>
	 * @date 2023. 9. 16.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 5.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<MbCmnCodeVO> selectNationNoCodeList() throws Exception {
		return bdEtrMapper.selectNationNoCodeList();
	}
}
