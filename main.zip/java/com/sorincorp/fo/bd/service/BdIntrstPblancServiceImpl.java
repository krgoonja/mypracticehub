package com.sorincorp.fo.bd.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.fo.bd.mapper.BdIntrstPblancMapper;
import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.bd.model.BdIntrstPblancVO;
import com.sorincorp.fo.config.UserInfoUtil;

/**
 * BdIntrstPblancServiceImpl.java
 *
 * @version
 * @since 2023. 09. 12.
 * @author bok3117
 */
@Service
public class BdIntrstPblancServiceImpl implements BdIntrstPblancService {
	
	@Autowired
	BdIntrstPblancMapper bdIntrstPblancMapper;
	
	@Autowired
	CommonService commonService;
	
	@Autowired
	UserInfoUtil userInfoUtil;
	
	/**
	 * 마이페이지 < 관심공고 페이지에 저장한다.
	 */
	@Override
	public void insertIntrstPblanc(BdIntrstPblancVO intrstPblancVO) throws Exception {
		String bidPblancId = intrstPblancVO.getBidPblancId();
		
		if(bidPblancId != null) {
			intrstPblancVO.setDeleteAt("N");
			bdIntrstPblancMapper.insertIntrstPblanc(intrstPblancVO);
			bdIntrstPblancMapper.updateIntrstEntrpsQyPlus(intrstPblancVO);
			commonService.insertTableHistory("BD_INTRST_DTL", intrstPblancVO);
		}
	}
	
	/**
	 * 마이페이지 < 관심공고 페이지에 삭제한다.
	 */
	@Override
	public void deleteIntrstPblanc(BdIntrstPblancVO intrstPblancVO) throws Exception {
		String bidPblancId = intrstPblancVO.getBidPblancId();

		if(bidPblancId != null) {
			intrstPblancVO.setDeleteAt("Y");
			bdIntrstPblancMapper.deleteIntrstPblanc(intrstPblancVO);
			bdIntrstPblancMapper.updateIntrstEntrpsQyMinus(intrstPblancVO);
			commonService.insertTableHistory("BD_INTRST_DTL", intrstPblancVO);
		}
	}

	/**
	 * 마이페이지 < 관심공고 리스트 개수를 조회한다.
	 */
	@Override
	public int selectIntrstPblancCnt(BdIntrstPblancVO intrstPblancVO) throws Exception {
		int intrstCnt = bdIntrstPblancMapper.selectIntrstPblancCnt(intrstPblancVO);
		return intrstCnt;
	}
	
	/**
	 * 마이페이지 < 관심공고 리스트를 조회한다.
	 */
	@Override
	public List<BdIntrstPblancVO> selectIntrstPblancList(BdIntrstPblancVO intrstPblancVO) throws Exception {
		List<BdIntrstPblancVO> intrstList = new ArrayList<>();
		intrstList = bdIntrstPblancMapper.selectIntrstPblancList(intrstPblancVO);
		return intrstList;
	}
	
	
}
