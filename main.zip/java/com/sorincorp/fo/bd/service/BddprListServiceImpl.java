package com.sorincorp.fo.bd.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.bd.mapper.BddprListMapper;
import com.sorincorp.fo.bd.model.BddprListVO;

/**
 * BddprListServiceImpl.java
 *
 * @version
 * @since 2023. 08. 22.
 * @author bok3117
 */
@Service
public class BddprListServiceImpl implements BddprListService {
	
	@Autowired
	private BddprListMapper bddprListMapper;
	
	/**
	 * 마이페이지 < 투찰 건별 개수를 조회한다.
	 */
	public List<Map<String, Object>> selectBddprCnt(BddprListVO bddprListVO) throws Exception {
		return bddprListMapper.selectBddprCnt(bddprListVO);
	}
	
	/**
	 * 마이페이지 < 투찰 목록 개수를 조회한다.
	 */
	@Override
	public int selectBddprListTotcnt(BddprListVO bddprListVO) throws Exception {
		String pageStatus = bddprListVO.getPageStatus();
		String pageSubStatus = bddprListVO.getPageSubStatus();
		int searchCnt = 0;
		
		setPageStatusAndSubStatus(bddprListVO, pageStatus, pageSubStatus);
		searchCnt = bddprListMapper.selectBddprListTotcnt(bddprListVO);
		return searchCnt;
	}
	
	/**
	 * 마이페이지 < 투찰 목록 리스트를 조회한다.
	 */
	@Override
	public List<BddprListVO> selectBddprList(BddprListVO bddprListVO) throws Exception {
		List<BddprListVO> searchList = new ArrayList<>();
		String pageStatus = bddprListVO.getPageStatus();
		String pageSubStatus = bddprListVO.getPageSubStatus();
		
		setPageStatusAndSubStatus(bddprListVO, pageStatus, pageSubStatus);
		searchList = bddprListMapper.selectBddprList(bddprListVO);
		
		return searchList;
	}
	
	/**
	 * 각 탭이나 라디오 버튼에 따라 상태값을 지정한다.
	 */
	public void setPageStatusAndSubStatus(BddprListVO bddprListVO, String pageStatus, String pageSubStatus) {

		if(pageStatus.equals("bddprTab") || pageSubStatus.equals("allBddpr")) { // 투찰
			bddprListVO.setScsbidAt("N");
			
			if(pageSubStatus.equals("bddprProgrs")) { // 투찰 중
				bddprListVO.setCanclAt("N");
			} else if(pageSubStatus.equals("bddprCancl")) { // 투찰접수 취소
				bddprListVO.setCanclAt("Y");
			} 
		} else if(pageStatus.equals("scsbidTab")) { // 낙찰
			bddprListVO.setCanclAt("N");
			bddprListVO.setScsbidAt("Y");
		} else if(pageStatus.equals("loseTab") || pageStatus.equals("failTab")) { // 패찰, 유찰
			bddprListVO.setCanclAt("N");
			bddprListVO.setScsbidAt("N");
		}
	}
}
