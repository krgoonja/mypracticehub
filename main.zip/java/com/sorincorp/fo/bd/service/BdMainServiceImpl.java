package com.sorincorp.fo.bd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.bd.mapper.BdMainMapper;
import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.bd.model.BdBidVO;
import com.sorincorp.fo.config.UserInfoUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BdMainServiceImpl implements BdMainService {

	@Autowired(required=false)
	BdMainMapper bdMainMapper;
 
	@Autowired
	UserInfoUtil userInfoUtil;
	
	/**
     *  메인 사용자 대시보드 정보를 조회한다.
     */
    @Override
    public BdAccount getBdUserDashboardData(BdAccount vo) throws Exception {
        return bdMainMapper.getBdUserDashboardData(vo);
    }
    
    @Override
    public int getBdIntrstBidCnt(String bidEntrpsNo) throws Exception {
        return bdMainMapper.getBdIntrstBidCnt(bidEntrpsNo);
    }
    @Override
    public List<BdBidVO> selectBdMainList(BdBidVO bdBidVO) throws Exception {
    	return bdMainMapper.selectBdMainList(bdBidVO);
    }
    @Override
    public List<BdBidVO> selectBdMainCnt(BdBidVO bdBidVO) throws Exception {
    	return bdMainMapper.selectBdMainCnt(bdBidVO);
    }
}
