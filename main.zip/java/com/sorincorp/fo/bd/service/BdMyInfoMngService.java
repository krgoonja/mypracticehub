package com.sorincorp.fo.bd.service;

import com.sorincorp.fo.bd.model.BdMyInfoMngVO;

/**
 * BdMyInfoMngService.java
 *
 * @version
 * @since 2023. 09. 07.
 * @author bok3117
 */
public interface BdMyInfoMngService {

	/**
	 * <pre>
	 * 처리내용: 마이페이지 < 내정보관리 리스트를 조회한다.
	 * </pre>
	 * @date 2023. 9. 7.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 7.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param bidEntrpsNo
	 * @throws Exception
	 */
	public BdMyInfoMngVO selectMyInfoMngDtl(String bidEntrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 휴대폰 번호를 변경한다.
	 * </pre>
	 * @date 2023. 9. 11.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 11.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param myInfoMngVO
	 * @throws Exception
	 */
	public void updateMoblphonNo(BdMyInfoMngVO myInfoMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 사업자 등록증 조회
	 * </pre>
	 * @date 2023. 9. 11.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 11.	  	hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param docNo
	 * @throws Exception
	 */
	String selectDocNo(String docNo) throws Exception;

}
