package com.sorincorp.fo.bd.service;

import java.security.SecureRandom;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.fo.bd.mapper.BdAccountFindMapper;
import com.sorincorp.fo.bd.model.BdEtrVO;
import com.sorincorp.fo.mb.service.MbCmnCodeService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BdAccountFindServiceImpl implements BdAccountFindService {

	@Autowired
	BdAccountFindMapper bdAccountFindMapper;

	@Autowired
	AssignService assignService;

	@Autowired
	MbCmnCodeService mbCmnCodeService;

	@Autowired
	SMSService smsService;

	@Autowired
	private CommonService commonService;


	/**
	 * <pre>
	 * 처리내용: 휴대폰 번호로 계정 리스트 조회
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param phoneNum
	 * @return
	 * @throws Exception
	 */
	public List<BdEtrVO> selectBidAccountByPhone(String phoneNum) throws Exception {

		if (StringUtils.isNotEmpty(phoneNum) && !phoneNum.equals("null")) {
			phoneNum = phoneNum.replaceAll("[^0-9]", "");
			try {
				log.debug("휴대폰 암호화 전 ===============>" + phoneNum);
				phoneNum = CryptoUtil.encryptAES256(phoneNum);
				log.debug("휴대폰 암호화 후 ===============>" + phoneNum);
			} catch (Exception e) {
				// TODO: handle exception
				log.error("BdAccountServiceImpl :: selectBidAccountByPhone phoneNum CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}

		List<BdEtrVO> bdAccountList = bdAccountFindMapper.selectBidAccountByPhone(phoneNum);
		for(BdEtrVO bdAccount : bdAccountList) {
			String moblphonNo2 = "";

			if(bdAccount != null) {
				moblphonNo2 = bdAccount.getMoblphonNo2();

				if (StringUtils.isNotEmpty(moblphonNo2) && !moblphonNo2.equals("null")) {
					try {
						//휴대폰 파라미터 복호화 20220118 srec0030
						log.debug("휴대폰 복호화 전 ===============>" + moblphonNo2);
						moblphonNo2 = CryptoUtil.decryptAES256(moblphonNo2);
						log.debug("휴대폰 복호화 후 ===============>" + moblphonNo2);
						bdAccount.setMoblphonNo2(moblphonNo2);
					} catch (Exception e) {
						// TODO: handle exception
						log.error("BdAccountServiceImpl :: selectBidAccountByPhone MOBLPHON_NO2 CryptoUtil.decryptAES256 ERROR " + e.getMessage());
					}
				}
			}
		}

		return bdAccountList;
	}

	/**
	 * <pre>
	 * 처리내용: 인증번호 발송
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 * @throws Exception
	 */
	public String bidPhoneAuth(BdEtrVO account) throws Exception {
		SMSVO smsVO = new SMSVO();

		Map<String, String> map = new HashMap<>();

		// 메시지 템플릿 번호
		String templateNum = "4";
		String title = mbCmnCodeService.selectMssageSj(templateNum);

		SecureRandom sr = new SecureRandom();
		StringBuilder authNum = new StringBuilder();
		for(int i=0; i<6; i++) {
			authNum.append(sr.nextInt(10));
		}

		map.put("templateNum", templateNum);
		map.put("certiNumber", authNum.toString());

		if (StringUtils.isNotEmpty(account.getMoblphonNo2()) && !account.getMoblphonNo2().equals("null")) {
			try {
				String moblphonNo2 = account.getMoblphonNo2();
				//휴대폰 파라미터 복호화 20220118 srec0030
				log.debug("휴대폰 복호화 전 ===============>" + moblphonNo2);
				moblphonNo2 = CryptoUtil.decryptAES256(moblphonNo2);
				log.debug("휴대폰 복호화 후 ===============>" + moblphonNo2);
				account.setMoblphonNo2(moblphonNo2);
			} catch (Exception e) {
				// TODO: handle exception
				log.error("BdAccountServiceImpl :: selectBidAccountByPhone moblphonNo2 CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		} else if (!StringUtils.isNotEmpty(account.getMoblphonNo2()) && account.getMoblphonNo2().equals("null")){
			try {
				String vrscMoblphonNo = account.getVrscMoblphonNo();
				//휴대폰 파라미터 복호화 20220118 srec0030
				log.debug("휴대폰 복호화 전 ===============>" + vrscMoblphonNo);
				vrscMoblphonNo = CryptoUtil.decryptAES256(vrscMoblphonNo);
				log.debug("휴대폰 복호화 후 ===============>" + vrscMoblphonNo);
				account.setVrscMoblphonNo(vrscMoblphonNo);
			} catch (Exception e) {
				// TODO: handle exception
				log.error("BdAccountServiceImpl :: selectBidAccountByPhone vrscMoblphonNo CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}

		smsVO.setPhone(account.getMoblphonNo2().replaceAll("[^0-9]", ""));
		smsVO.setMberNo(account.getBidMberId());
		smsVO.setMsgTitle(title);

		smsService.insertSMS(smsVO, map); //나중에 주석 풀어야 문자 발송 가능
		return authNum.toString();
	}

	/**
	 * <pre>
	 * 처리내용: 회원 가입 일시 조회
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 * @throws Exception
	 */
	public String selectBidSignUpDate(BdEtrVO account) {
		return bdAccountFindMapper.selectBidSignUpDate(account);
	}

	/**
	 * <pre>
	 * userId에 맞는 사용자 정보를 가져온다.
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bidMberId
	 * @return
	 * @throws Exception
	 */
	public BdEtrVO selectBidAccount(String bidMberId) throws Exception {
		BdEtrVO account = bdAccountFindMapper.selectBidAccount(bidMberId);
		String moblphonNo2 = "";

		if(account != null) {
			moblphonNo2 = account.getMoblphonNo2();

			if(moblphonNo2 != null && !"".equals(moblphonNo2)) {
				try {
					//휴대폰 파라미터 복호화 20220118 srec0030
					log.debug("휴대폰 복호화 전 ===============>" + moblphonNo2);
					moblphonNo2 = CryptoUtil.decryptAES256(moblphonNo2);
					log.debug("휴대폰 복호화 후 ===============>" + moblphonNo2);
					account.setMoblphonNo2(moblphonNo2);
				} catch (Exception e) {
					// TODO: handle exception
					log.error("BdAccountFindServiceImpl :: selectBidAccount MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
			}
		}
		return account;
	}

	/**
	 * <pre>
	 * 비밀번호 변경
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 * @throws Exception
	 */
	@Transactional(rollbackFor = Exception.class)
	public void bidUpdatePw(BdEtrVO bdAccount) throws Exception {
		try{
			bdAccountFindMapper.bidUpdatePw(bdAccount);
			commonService.insertTableHistory("BD_ENTRPS_INFO_BAS", bdAccount);
		} catch (Exception e){
			log.error("BdAccountFindServiceImpl :: bidUpdatePw CryptoUtil.decryptAES256 ERROR " + e.getMessage());
		}
	}
}
