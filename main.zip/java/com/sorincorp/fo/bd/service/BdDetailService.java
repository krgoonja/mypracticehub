package com.sorincorp.fo.bd.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.fo.bd.model.BdAccount;
import com.sorincorp.fo.bd.model.BdBddprVO;
import com.sorincorp.fo.bd.model.BdBidUpdtVO;
import com.sorincorp.fo.bd.model.BdBidVO;
import com.sorincorp.fo.bd.model.BdScsAtcDocVO;

public interface BdDetailService {

		
	public BdBidVO selectBdBid(BdBidVO bdBidVO) throws Exception ;

	public List<BdBddprVO> selectBdBddprList(BdBidVO bdBidVO) throws Exception ;
	
	/**
	 * <pre>
	 * 처리내용: 업체 투찰 데이터를 등록한다 
	 * </pre>
	 * @date 2022. 11. 18.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 18.		sein			최초작성
	 * @param bddprVO
	 * @return  
	 * @throws Exception
	 */
	public String insertBdBddpr(BdBddprVO bdBddprVO) throws Exception;
	/**
	 * <pre>
	 * 처리내용: 업체 투찰 취소 정보 수
	 * </pre>
	 * @date 2022. 12. 06.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 06.		sein			최초작성
	 * @param String
	 * @return int
	 * @throws Exception
	 */
	public int selectBddprCanclCount(BdBidVO bdBidVO) throws Exception;
	
	public boolean deleteBdBddpr(BdBddprVO bdBddprVO)throws Exception;
	
	int updateBdEntrps(BdAccount bdAccount) throws Exception;
	
	int updateBdBddpr(BdBddprVO bdBddprVO) throws Exception;
	
	public List<BdScsAtcDocVO> selectBdDocList(BdBddprVO bdBddprVO) throws Exception;
		

	Map<String, Object> saveAttachFile(MultipartHttpServletRequest mRequest) throws Exception;
	
	public Map<String, Object> deleteAttachFile(FileDocVO fileVO) throws Exception;

	String insertBdScsAtcDoc(BdScsAtcDocVO bdScsAtcDocVO) throws Exception;
	
	String bdDocSubmit(BdScsAtcDocVO bdScsAtcDocVO) throws Exception ;
		
	/**
	 * <pre>
	 * 처리내용: 입찰 수정 사유 리스트
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author sein
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.	  	sein			최초작성
	 * ------------------------------------------------
	 * @param bdBidVO
	 * @return List<BdBidUpdtVO>
	 * @throws Exception
	 */
	public List<BdBidUpdtVO> selectBdBidUpdtList(BdBidVO bdBidVO) throws Exception;
	/**
	 * <pre>
	 * 처리내용: 각 공고 및 업체의 관심공고 체크 여부를 확인한다.
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param bdBidVO
	 * @return BdBidVO
	 * @throws Exception
	 */
	public BdBidVO selectIntrstPblancCheck(BdBidVO bdBidVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 인도조건창고 목록 리스트를 확인한다.
	 * </pre>
	 * @date 2023. 9. 15.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 15.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param bdBidVO
	 * @return BdBidVO
	 * @throws Exception
	 */
	public List<BdBidVO> selectLgistCnterList(BdBidVO bdBidVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 인도조건창고 목록 개수를 확인한다.
	 * </pre>
	 * @date 2023. 9. 15.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 9. 15.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @param bdBidVO
	 * @return int
	 * @throws Exception
	 */
	int selectLgistCnterCnt(BdBidVO bdBidVO) throws Exception;
	//등록시 모달창
	Map<String,Object> modalDocInfoAjax(BdScsAtcDocVO bdScsAtcDocVO) throws Exception ;
	//모달찰에서 확인,취소 클릭 시
	 Map<String,Object> modalDocCheck(BdScsAtcDocVO bdScsAtcDocVO) throws Exception ;
	 
	// 투찰 정보 상세
	public BdBidVO selectBdBddprInfo(BdBidVO bdBddprVO) throws Exception;
	
	public List<BdBidVO> selectBidDelyCndList(BdBidVO bdBidVO) throws Exception;
	 
}
