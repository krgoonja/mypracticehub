package com.sorincorp.fo.bd.service;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.fo.bd.mapper.BdNoticeMapper;
import com.sorincorp.fo.bd.model.BdNoticeVO;

import lombok.extern.slf4j.Slf4j;

/**
 * BidNoticeServiceImpl.java
 * 
 */
@Slf4j
@Service
public class BdNoticeServiceImpl implements BdNoticeService {

	@Autowired
	private BdNoticeMapper bidnoticeMapper;

	@Autowired
	public FileDocService fileDocService;

	/**
	 * 공지사항 목록을 조회한다.
	 */
	
	@Override
	public List<BdNoticeVO> searchListNotice(BdNoticeVO vo) throws Exception {
		List<BdNoticeVO> list = bidnoticeMapper.searchListNotice(vo);
		for (int i = 0; i < list.size(); i++) {
			List<FileDocVO> fileList = selectListNoticeAtchmnfl(list.get(i));
			list.get(i).setDocNo(fileList.size());
		}
		return list;
	}

	/**
	 * 공지사항 목록 총개수를 조회한다.
	 */
	
	@Override
	public int selectNoticeListTotcnt(BdNoticeVO vo) throws Exception {
		return bidnoticeMapper.selectNoticeListTotcnt(vo);
	}

	/**
	 * 필독으로 설정된 공지사항 목록을 조회한다.
	 */
	
	@Override
	public List<BdNoticeVO> selectListNoticeUpendexpsr() throws Exception {
		List<BdNoticeVO> list = bidnoticeMapper.selectListNoticeUpendexpsr();
		for (int i = 0; i < list.size(); i++) {
			List<FileDocVO> fileList = selectListNoticeAtchmnfl(list.get(i));
			list.get(i).setDocNo(fileList.size());
		}
		return list;
	}

	/**
	 * 공지사항 첨부파일 목록을 조회한다.
	 */
	
	@Override
	public List<FileDocVO> selectListNoticeAtchmnfl(BdNoticeVO vo) throws Exception {
		List<FileDocVO> fileList = new ArrayList<>();
		List<BdNoticeVO> atchList = bidnoticeMapper.selectListNoticeAtchmnfl(vo);

		for (int i = 0; i < atchList.size(); i++) {
			FileDocVO file = fileDocService.selectDocInfo(atchList.get(i).getDocNo());
			System.out.println("file ===> " + file);

			fileList.add(file);
		}

		return fileList;
	}

	/**
	 * 공지사항을 상세조회한다.
	 */
	
	@Override
	public BdNoticeVO selectNotice(BdNoticeVO vo) throws Exception {
		log.info("selectNotice vo >>> " + vo);
		String searchKeyword = URLDecoder.decode(vo.getSearchKeyword(), "UTF-8");
		vo.setSearchKeyword(searchKeyword);

		BdNoticeVO notice = bidnoticeMapper.selectNotice(vo);
		notice.setNoticeAt(vo.getNoticeAt());
		notice.setSearchKeyword(vo.getSearchKeyword());
		log.info("selectNotice 검색어 ===> " + vo.getSearchKeyword());
		if (vo.getNoticeAt() == 1) {
			notice.setPreNoticeNo(0);
			notice.setNextNoticeNo(0);
		}

		// 2022-01-07 공지사항 관련 개선사항 추가 반영 - 조회 수 기능 추가
		bidnoticeMapper.updateNoticeViewCount(vo);

		return notice;
	}
	/**
	 * 공지사항 최근 게시글 4개를 조회한다. 
	 */
	@Override
	public List<BdNoticeVO> showNotice(BdNoticeVO vo) throws Exception {
		 return bidnoticeMapper.showNotice(vo);
		
	}
}
