package com.sorincorp.fo.bd.service;

import com.sorincorp.fo.bd.model.BdEtrVO;

import java.util.List;

public interface BdAccountFindService {



	/**
	 * <pre>
	 * 처리내용: 휴대폰 번호로 계정 리스트 조회
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param phoneNum
	 * @return
	 * @throws Exception
	 */
	public List<BdEtrVO> selectBidAccountByPhone(String phoneNum) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 인증번호 발송
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 * @throws Exception
	 */
	public String bidPhoneAuth(BdEtrVO account) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원 가입 일시 조회
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 * @throws Exception
	 */
	public String selectBidSignUpDate(BdEtrVO account) throws Exception;

	/**
	 * <pre>
	 * userId에 맞는 사용자 정보를 가져온다.
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param bidMberId
	 * @return
	 * @throws Exception
	 */
	public BdEtrVO selectBidAccount(String bidMberId) throws Exception;

	/**
	 * <pre>
	 * 비밀번호 변경
	 * </pre>
	 * @date 2023. 9. 13.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 13.				hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 * @throws Exception
	 */
	public void bidUpdatePw(BdEtrVO account) throws Exception;

}
