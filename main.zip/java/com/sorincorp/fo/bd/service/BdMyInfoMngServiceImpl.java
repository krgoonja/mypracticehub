package com.sorincorp.fo.bd.service;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.fo.bd.mapper.BdMyInfoMngMapper;
import com.sorincorp.fo.bd.model.BdMyInfoMngVO;

import lombok.extern.slf4j.Slf4j;

/**
 * BdMyInfoMngServiceImpl.java
 *
 * @version
 * @since 2023. 09. 07.
 * @author bok3117
 */
@Slf4j
@Service
public class BdMyInfoMngServiceImpl implements BdMyInfoMngService {
	
	@Autowired
	CommonService commonService;
	
	@Autowired
	BdMyInfoMngMapper bdMyInfoMngMapper;
	
	/**
	 * 마이페이지 < 내정보관리 페이지를 조회한다.
	 */
	@Override
	public BdMyInfoMngVO selectMyInfoMngDtl(String bidEntrpsNo) throws Exception {
		BdMyInfoMngVO myInfoMngVO = bdMyInfoMngMapper.selectMyInfoMngDtl(bidEntrpsNo);
		String moblphonNo = myInfoMngVO.getMoblphonNo2();
		String vrscMoblphonNo = myInfoMngVO.getVrscMoblphonNo();
		String entrpsTlphonNo = myInfoMngVO.getEntrpsTlphonNo();
		String vrscTlphonNo = myInfoMngVO.getVrscTlphonNo();



		try {
			if((moblphonNo != null && !"".equals(moblphonNo)) || (vrscMoblphonNo != null && !"".equals(vrscMoblphonNo))) { // 휴대폰 번호 복호화
				log.info("휴대폰 복호화 전 ===============>" + moblphonNo);
				moblphonNo = CryptoUtil.decryptAES256(moblphonNo);
				log.info("휴대폰 복호화 후 ===============>" + moblphonNo);
				myInfoMngVO.setMoblphonNo2(moblphonNo);
				
				log.info("대행 휴대폰 복호화 전 ===============>" + vrscMoblphonNo);
				vrscMoblphonNo = CryptoUtil.decryptAES256(vrscMoblphonNo);
				log.info("대행 휴대폰 복호화 후 ===============>" + vrscMoblphonNo);
				myInfoMngVO.setVrscMoblphonNo(vrscMoblphonNo);
			}
			if(entrpsTlphonNo != null && !"".equals(entrpsTlphonNo)){
				log.info("업체 회사번호 복호화 전 ===============>" + entrpsTlphonNo);
				entrpsTlphonNo = CryptoUtil.decryptAES256(entrpsTlphonNo);
				log.info("업체 회사번호 복호화 후 ===============>" + entrpsTlphonNo);
				myInfoMngVO.setEntrpsTlphonNo(entrpsTlphonNo);
			}
			if(vrscTlphonNo != null && !"".equals(vrscTlphonNo)){
				log.info("대행업체 회사번호 복호화 전 ===============>" + vrscTlphonNo);
				vrscTlphonNo = CryptoUtil.decryptAES256(vrscTlphonNo);
				log.info("대행업체 회사번호 복호화 후 ===============>" + vrscTlphonNo);
				myInfoMngVO.setVrscTlphonNo(vrscTlphonNo);
			}
		} catch(Exception e) {
			log.error("selectMyInfoMngDtl MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
		}
		return myInfoMngVO;
	}
	
	/**
	 * 휴대폰 번호를 변경한다.
	 */
	@Override
	public void updateMoblphonNo(BdMyInfoMngVO myInfoMngVO) throws Exception {
		String changeMoblphonNo = myInfoMngVO.getInputMoblphonNo();
		String changeAditIem = myInfoMngVO.getInputAditIem();
		
		try {
			// 변경 휴대폰 번호 암호화
			log.info("휴대폰 암호화 전 ===============>" + changeMoblphonNo);
			changeMoblphonNo = CryptoUtil.encryptAES256(changeMoblphonNo);
			log.info("휴대폰 암호화 후 ===============>" + changeMoblphonNo);
			
			// 휴대폰 번호 변경 구분하여 DB에 저장
			if(myInfoMngVO.getModalId().equals("sorinModalAlert1")) { // 회사 
				myInfoMngVO.setChangeMoblphonNo2(changeMoblphonNo);
			} else if(myInfoMngVO.getModalId().equals("sorinModalAlert2")) { // 입찰 대리
				myInfoMngVO.setChangeVrscMoblphonNo(changeMoblphonNo);
			} 
			myInfoMngVO.setAditIem2(changeAditIem);
			
			bdMyInfoMngMapper.updateMoblphonNo(myInfoMngVO);
			commonService.insertTableHistory("BD_ENTRPS_INFO_BAS", myInfoMngVO);
		}  catch(Exception e) {
			log.error("updateMoblphonNo MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
		}
		
	}

	/**
	 * 사업자 등록증 조회
	 */
	@Override
	public String selectDocNo(String docNo) throws Exception {
		String filePath = "";
		try {
			FileDocVO bsnmFile = bdMyInfoMngMapper.selectDocNo(docNo);
			filePath = bsnmFile.getDocFileRealCours();
		}  catch(Exception e) {
			log.error("BdMyInfoMngServiceImpl :: selectDocNo ERROR " + e.getMessage());
		}
		return filePath;
	}

}
