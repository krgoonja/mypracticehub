package com.sorincorp.fo.bd.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.RequestBody;

import com.sorincorp.fo.bd.model.BddprListVO;

/**
 * BddprListService.java
 *
 * @version
 * @since 2023. 08. 22.
 * @author bok3117
 */
public interface BddprListService {
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 < 투찰 건별 개수를 조회한다.
	 * </pre>
	 * @date 2023. 8. 30.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 8. 30.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @return bddprListVO
	 * @param 
	 * @throws Exception
	 */
	public List<Map<String, Object>> selectBddprCnt(BddprListVO bddprListVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 < 투찰 목록 리스트를 조회한다.
	 * </pre>
	 * @date 2023. 8. 30.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 8. 30.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @return bddprListVO
	 * @param 
	 * @throws Exception
	 */
	public List<BddprListVO> selectBddprList(BddprListVO bddprListVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 < 투찰 목록 개수를 조회한다.
	 * </pre>
	 * @date 2023. 8. 30.
	 * @author bok3117
	 * @history
	 * ------------------------------------------------
	 * 변경일           	작성자			변경내용
	 * ------------------------------------------------
	 * 2023. 8. 30.	  	bok3117			최초작성
	 * ------------------------------------------------
	 * @return bddprListVO
	 * @param 
	 * @throws Exception
	 */
	public int selectBddprListTotcnt(BddprListVO bddprListVO) throws Exception;

}
