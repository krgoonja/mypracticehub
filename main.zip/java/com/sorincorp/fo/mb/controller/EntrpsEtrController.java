package com.sorincorp.fo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.model.MbCmnCodeVO;
import com.sorincorp.fo.mb.service.EntrpsEtrService;
import com.sorincorp.fo.mb.service.MbCmnCodeService;
import com.sorincorp.fo.mb.service.NiceSelfCrtfctService;
import com.sorincorp.fo.my.model.CorpInfoMgrVO;
import com.sorincorp.fo.my.service.CorpInfoMgrService;
import com.sorincorp.fo.my.service.DeliveryRegionMngService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/fo/Member")
@ComponentScan(basePackages = { "com.sorincorp.comm.*" })
public class EntrpsEtrController {

	@Value("${spring.sts.api.chkBsnmRegistNo}")
	private String apiUrl;

	@Autowired
	private EntrpsEtrService entrpsEtrService;

	@Autowired
	private CorpInfoMgrService corpInfoMgrService;

	@Autowired
	private DeliveryRegionMngService deliveryRegionMngService;

	@Autowired
	private NiceSelfCrtfctService niceSelfCrtfctService;

	@Autowired
	private MbCmnCodeService mbCmnCodeService;

	@Autowired
	private UserInfoUtil userInfoUtil;

	@RequestMapping("/niceTest")
	public String checkplusMain() throws Exception {
		return "mb/checkplus_main.tiles";
	}

	/**
	 * <pre>
	 * 처리내용: 회원사가입 > 약관동의 화면
	 * </pre>
	 *
	 * @date 2021. 7. 19.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 19.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsEtr")
	public String selectEntrpsEtrStplat(ModelMap model) {
		try {
			List<EntrpsEtrVO> stplatList = entrpsEtrService.selectEntrpsEtrStplat();
			model.addAttribute("stplatList", stplatList);
			return "mb/entrpsEtrStplat";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}

	}

	/**
	 * <pre>
	 * 처리내용: 회원사가입 > 회원사 정보입력 화면
	 * </pre>
	 *
	 * @date 2021. 7. 19.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 19.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsEtrInfo")
	public String selectEntrpsEtr(ModelMap model) {
		try {
			List<MbCmnCodeVO> domainList = mbCmnCodeService.selectCmnCodeList("EMAIL_DOMAIN");
			model.addAttribute("domainList", domainList);
			model.addAttribute("apiUrl", apiUrl);
			return "mb/entrpsEtr";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 회원사가입 > 마스터 계정 발급 신청 화면
	 * </pre>
	 *
	 * @date 2021. 7. 19.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 19.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsEtrMasterReg")
	public String selectEntrpsEtrMasterReg(HttpSession session, ModelMap model) {
		try {
            
              Map<Object, Object> map = niceSelfCrtfctService.niceSelfCrtfct(session, "entrps"); 
              model.addAttribute("sEncData", map.get("sEncData"));
             

			List<MbCmnCodeVO> domainList = mbCmnCodeService.selectCmnCodeList("EMAIL_DOMAIN");
			model.addAttribute("domainList", domainList);

			return "mb/entrpsEtrMasterReg";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 회원사가입 > 회원사 가입 신청 완료 화면
	 * </pre>
	 *
	 * @date 2021. 7. 19.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 19.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@Transactional
	@RequestMapping("/insertEntrpsEtr")
	@ResponseBody
	public ResponseEntity<Object> insertEntrpsEtr(@RequestBody EntrpsEtrVO entrpsEtrVO, ModelMap model) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		String result = "";

		try {
			result = entrpsEtrService.insertEntrpsEtr(entrpsEtrVO);
			map.put("result", result);
			map.put("entrpsNo", entrpsEtrVO.getEntrpsNo());
			
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.toString());
			result = "F";
			map.put("result", result);
			return new ResponseEntity<>(map, HttpStatus.OK);
		}

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@RequestMapping("/selectEntrpsEtrEnd")
	public String selectEntrpsEtrEnd() {
		try {
			return "mb/entrpsEtrEnd";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 회원사가입 > 회원사 가입 신청 완료 화면 > 계좌등록화면
	 * </pre>
	 *
	 * @date 2022. 2. 21.
	 * @author heehoonc
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 2. 21.
	 *          heehoonc 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectEntrpsAccntReg")
	public String selectEntrpsAccntReg(ModelMap model) {
		try {

			CorpInfoMgrVO corpInfoMgrVO = new CorpInfoMgrVO();
			String entrpsNo = userInfoUtil.getEntripsNo();

			if (entrpsNo == null) {
				return "error/503";
			}

			// 현재 기업 인증상태를 기준으로 페이지 접근 제한 여부

			String RefndAccntSattus = entrpsEtrService.selectRefndAccntSattus(entrpsNo);

			if (!"".equals(RefndAccntSattus)) {
				return "mb/entrpsAccntEnd";
			}

			corpInfoMgrVO.setEntrpsNo(entrpsNo);

			model.addAttribute("corpInfoMgrVO", corpInfoMgrService.selectCorpInfoDetail(corpInfoMgrVO));
			model.addAttribute("entrpsNo", userInfoUtil.getAccountInfo().getEntrpsNo());
			model.addAttribute("domainList", deliveryRegionMngService.selectemailDomainList());

			return "mb/entrpsAccntReg";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	@RequestMapping("/selectEntrpsAccntEnd")
	public String selectEntrpsAccntEnd() {
		try {
			return "mb/entrpsAccntEnd";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 회원사가입 > 사업자 등록 번호 체크
	 * </pre>
	 *
	 * @date 2021. 7. 19.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 19.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/checkBsnmRegistNo")
	@ResponseBody
	public String checkBsnmRegistNo(@RequestBody EntrpsEtrVO entrpsEtrVO, ModelMap model) throws Exception {

		String bsnmRegistNo = entrpsEtrVO.getBsnmRegistNo();
		log.debug("컨트롤러 사업자 등록 번호 " + bsnmRegistNo);
		String result = entrpsEtrService.checkBsnmRegistNo(entrpsEtrVO);

		model.addAttribute("result", result);
		log.debug("result :: " + result);
		return result;
	}

	@PostMapping("/checkCprRegistNo")
	@ResponseBody
	public int checkCprRegistNo(@RequestBody EntrpsEtrVO entrpsEtrVO, ModelMap model) throws Exception {

		String cprRegistNo = entrpsEtrVO.getCprRegistNo();
		int result = entrpsEtrService.checkCprRegistNo(entrpsEtrVO);

		model.addAttribute("result", result);
		log.debug("result :: " + result);
		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 회원사가입 > 마스터계정 발급 신청 > 아이디 중복확인
	 * </pre>
	 *
	 * @date 2021. 7. 19.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 19.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectMberId")
	@ResponseBody
	public int selectMberId(@RequestBody String mberId) throws Exception {
		int result = 0;
		log.debug("mberId : " + mberId);
		result = entrpsEtrService.selectMberId(mberId);
		return result;
	}

	@PostMapping("/selectMberMobNo")
	@ResponseBody
	public int selectMberMobNo(@RequestBody EntrpsEtrVO entrpsEtrVO) {
		int result = 0;
		log.debug("mberId : " + entrpsEtrVO.getMoblphonNo());
		log.debug("mberId : " + entrpsEtrVO.getMberNm());
		try {
			result = entrpsEtrService.selectMberMobNo(entrpsEtrVO);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 파일 업로드
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param mRequest
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("finally")

	@ResponseBody
	@RequestMapping("/updEntrpsEtrFile")
	public ResponseEntity<Object> fileUploadTest(MultipartHttpServletRequest mRequest) throws Exception {
		String errMsg = "";
		HashMap<String, String> fileMap = new HashMap<>();
		try {
			fileMap = entrpsEtrService.saveAttachFile(mRequest);
		} catch (Exception e) {
			errMsg = fileMap.get("errMsg");
			log.debug("errMsg ======>" + errMsg);
			log.error(e.toString());
		} finally {
			errMsg = fileMap.get("errMsg");
			if (errMsg != null && !"".equals(errMsg)) {
				log.error("ERROR ===============>" + errMsg);
				return new ResponseEntity<>(errMsg, HttpStatus.BAD_REQUEST);
			} else {
				return new ResponseEntity<>(fileMap, HttpStatus.OK);
			}
		}
	}

	@RequestMapping("/deleteFile")
	@ResponseBody
	public ResponseEntity<Object> deleteFile(@RequestBody FileDocVO vo) throws Exception {

		Map<String, Object> map = entrpsEtrService.deleteFileDoc(vo);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}
}
