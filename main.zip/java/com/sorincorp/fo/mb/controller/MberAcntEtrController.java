package com.sorincorp.fo.mb.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.model.MberAcntEtrVO;
import com.sorincorp.fo.mb.service.EntrpsEtrService;
import com.sorincorp.fo.mb.service.MberAcntEtrService;
import com.sorincorp.fo.mb.service.NiceSelfCrtfctService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Controller
@RequestMapping("/fo/Member")
@ComponentScan(basePackages= {"com.sorincorp.comm.*"})
public class MberAcntEtrController {

	@Autowired
	private EntrpsEtrService entrpsEtrService;

	@Autowired
	private NiceSelfCrtfctService niceSelfCrtfctService;

	@Autowired
	private MberAcntEtrService mberAcntEtrService;

	/**
	 * <pre>
	 * 처리내용: 멤버계정 시작하기> 멤버 약관동의
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 19.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectMberAcntEtr")
	public String selectMberAcntEtr(ModelMap model) {
		try {
			List<EntrpsEtrVO> stplatList = entrpsEtrService.selectEntrpsEtrStplat();
			model.addAttribute("stplatList" , stplatList);
			return "mb/mberAcntEtrStplat";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}


	/**
	 * <pre>
	 * 처리내용: 멤버계정 시작하기 > 약관동의 > 회원 정보입력 화면
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 19.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectMberAcntEtrInfo")
	public String selectMberAcntEtrInfo(HttpSession session, ModelMap model) {
		try {
			Map<Object,Object> map = niceSelfCrtfctService.niceSelfCrtfct(session, "mberAcnt");
			List<EntrpsEtrVO> stplatList = entrpsEtrService.selectEntrpsEtrStplat();
			model.addAttribute("stplatList", stplatList);
			model.addAttribute("sEncData", map.get("sEncData"));
			return "mb/mberAcntEtr";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 멤버계정 시작하기 > 계정확인
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 19.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectMberAcntEtrId")
	@ResponseBody
	public String selectMberAcntEtrId(@RequestBody EntrpsEtrVO entrpsEtrVO) {
		String result = "";
		//log.debug("mberId : " + mberId);
		result = mberAcntEtrService.selectMberAcntEtrId(entrpsEtrVO);
		return result;
	}


	/**
	 * <pre>
	 * 처리내용: 멤버계정 시작하기 > 인증완료
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 19.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */

	@RequestMapping("/updateMberAcntInfo")
	@ResponseBody
	public String updateMberAcntInfo(@RequestBody EntrpsEtrVO entrpsEtrVO) throws Exception {

		String result = "F";
		
		// 계정확인 추가수행
		result = mberAcntEtrService.selectMberAcntEtrId(entrpsEtrVO);
		log.debug("updateMberAcntInfo > selectMberAcntEtrId :: {}", result);
		
		// 멤버계정 시작하기 > 인증완료 
		if("S".equals(result)) {
			result = "F";
			result = mberAcntEtrService.updateMberAcntInfo(entrpsEtrVO);
			log.debug("updateMberAcntInfo :: {}", result);
		}
		
		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 멤버 계정 신청 완료 화면
	 * </pre>
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 28.			srec0009			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectMberAcntEnd")
	public String selectMberAcntEnd() {
		try {
			return "mb/mberAcntEtrEnd";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 멤버계정 인증하기 > 마스터 계정인 경우 인증 불가
	 * </pre>
	 * @date 2022. 3. 22.
	 * @author sjham
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 3. 22.			sjham				최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectCntMberSeCode")
	@ResponseBody
	public int selectCntMberSeCode(@RequestBody MberAcntEtrVO mberAcntEtrVO) {
		
		int result = 0;
		
		try {
			result = mberAcntEtrService.selectCntMberSeCode(mberAcntEtrVO);
			log.debug("selectCntMberSeCode :: {}", result);
		} catch (Exception e) {
			log.error("selectCntMberSeCode error:: {}", e.getMessage());
			result = -1;
		}
		
		return result;
	}

}
