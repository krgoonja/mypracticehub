/**
 *
 */
package com.sorincorp.fo.mb.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.model.SimplMberEtrInfoVO;
import com.sorincorp.fo.mb.service.NiceSelfCrtfctService;
import com.sorincorp.fo.mb.service.SimplMberEtrService;

import lombok.extern.slf4j.Slf4j;

/**
 * SimplMberEtr.java
 * @version
 * @since 2021. 8. 11.
 * @author srec0009
 */
@Slf4j
@Controller
@RequestMapping("/fo/Member")
@ComponentScan(basePackages= {"com.sorincorp.comm.*"})
public class SimplMberEtrController {

	@Autowired
	private SimplMberEtrService simplMberEtrService;

	@Autowired
	private NiceSelfCrtfctService niceSelfCrtfctService;

	@Autowired
	private CustomValidator customValidator;
	/**
	 * <pre>
	 * 처리내용: 간편회원 가입 페이지 호출
	 * </pre>
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 16.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsEtrVO
	 * @param session
	 * @param model
	 * @return
	 *
	 * @throws Exception
	 */
	@RequestMapping("/selectSimplMberEtr")
	public String selectSimplMberEtr(HttpSession session, ModelMap model ) throws Exception {
		try {
			Map<Object,Object> map = niceSelfCrtfctService.niceSelfCrtfct(session, "simple");
			List<EntrpsEtrVO> stplatList = simplMberEtrService.selectEntrpsEtrStplat();
			model.addAttribute("sEncData", map.get("sEncData"));
			model.addAttribute("stplatList", stplatList);
			return "mb/simplMberEtr";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 간편회원 가입 이메일 체크
	 * </pre>
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 16.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberEmail
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectSimplMberEmail")
	@ResponseBody
	public int selectSimplMberEmail(@RequestBody  String mberEmail) throws Exception {
		log.debug(mberEmail);
		int result = simplMberEtrService.selectSimplMberEmail(mberEmail);
		return result;
	}
	/**
	 * <pre>
	 * 처리내용: 간편회원 중복 가입 체크
	 * </pre>
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 16.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberEmail
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectSimplMberMobNo")
	@ResponseBody
	public int selectSimplMberMobNo(@RequestBody SimplMberEtrInfoVO simplMberEtrInfoVO) throws Exception {
		int result = simplMberEtrService.selectSimplMberMobNo(simplMberEtrInfoVO);
		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 간편 회원가입
	 * </pre>
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 16.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simplMberEtrInfoVO
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertSimplMberEtr")
	public ResponseEntity<Object> insertSimplMberEtr(@RequestBody SimplMberEtrInfoVO simplMberEtrInfoVO, BindingResult bindingResult) throws Exception {

		customValidator.validate(simplMberEtrInfoVO, bindingResult, SimplMberEtrInfoVO.Insert.class);
		if (bindingResult.hasErrors()) { // validation 을 통과하지 못했을 경우
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}
		//log.debug("simplMberEtrInfoVO :: "+simplMberEtrInfoVO.toString());
		int result = 0;
		Map<String,Object> map = new HashMap<String, Object>();

		result = simplMberEtrService.insertSimplMberEtr(simplMberEtrInfoVO);
		map.put("result", result);
		return new ResponseEntity<>(map,HttpStatus.OK);
		//return "mb/simplMberEtrEnd.tiles";
	}

	@RequestMapping("/selectSimplMberEtrEnd")
	public String selectSimplMberEtrEnd(EntrpsEtrVO entrpsEtrVO) throws Exception {
		return "mb/simplMberEtrEnd";
	}
}
