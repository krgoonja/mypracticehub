/**
 *
 */
package com.sorincorp.fo.mb.model;

import javax.validation.constraints.NotEmpty;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.annotation.MaskingClass;
import com.sorincorp.comm.annotation.MaskingField;
import com.sorincorp.comm.annotation.MaskingField.MaskingType;
import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * SimplMberEtrInfoVO.java
 * @version
 * @since 2021. 8. 12.
 * @author srec0009
 */
@Data
@EqualsAndHashCode(callSuper=false)
@Validated
@MaskingClass
public class SimplMberEtrInfoVO extends CommonVO {
    /**
     * InsertAndUpdate</br>
     * validation groups를 지정하기 위한 빈 interface
     */
    public interface Insert {};
    /**
     * 간편 회원 번호
    */
    private String simplMberNo;
    /**
     * 간편 회원 아이디
    */
    @NotEmpty(groups=Insert.class, message="ID를 입력해 주세요.")
    private String simplMberId;
    /**
     * 간편 회원 비밀 번호
    */
    @NotEmpty(groups=Insert.class, message="비밀번호를 입력해 주세요.")
    private String simplMberSecretNo;
    /**
     * 간편 회원 가입 일시
    */
    private String simplMberEtrDt;
    /**
     * 간편 회원 최근 방문 일시
    */
    private String simplMberRecentVisitDt;
    /**
     * 간편 회원 이름
    */
    @NotEmpty(groups=Insert.class, message="본인인증을 진행해 주세요.")
    private String simplMberNm;
    /**
     * 휴대전화 번호
    */
    @NotEmpty(groups=Insert.class, message="본인인증을 진행해 주세요.")
    private String moblphonNo;
   
    /**
     * 뉴스레터 신청 여부
    */
    private String nsltReqstAt;
    /**
     * 뉴스레터 신청 일시
    */
    private String nsltReqstDt;
    /**
     * 앱 알림 여부
    */
    private String appNtcnAt;
    /**
     * 이메일 알림 여부
    */
    private String emailNtcnAt;
    /**
     * WEB 알림 여부
    */
    private String webNtcnAt;
    /**
     * 로그인 실패 회수
    */
    private int loginFailrRtrvl;
    /**
     * 비밀 번호 오류 횟수
    */
    private int secretNoErrorCo;
    /**
     * 비밀 번호 수정 일시
    */
    private String secretNoUpdtDt;
    /**
     * 최근 접속 일시
    */
    private String recentConectDt;
    /**
     * 간편 회원 상태 코드
    */
    private String simplMberSttusCode;
    /**
     * 휴면 일시
    */
    private String drmncyDt;
    /**
     * 탈퇴 일시
    */
    private String secsnDt;
    /**
     * 탈퇴 유형 코드
    */
    private String secsnTyCode;
    /**
     * 탈퇴 사유 코드
    */
    private String secsnResnCode;
    /**
     * 기타 탈퇴 사유
    */
    private String etcSecsnResn;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    /**
     * 코드_회원 간편 회원 가입 구분 코드
    */
    private String simplMberEtrSeCode;
    /**
     * 다음 비밀 번호 변경 일시
    */
    private String nextSecretNoChangeDt;

   /**
    * 본인인증일시
    */
    private String selfCrtfcDt;

    /**
     * 회원 마케팅 수신 동의 여부
     */
    @NotEmpty(message = "회원 마케팅 동의 여부는 필수값입니다.")
    private String advrtsRecptnAgreAt;
    /**
     * 회원 메일 수신 동의 여부
     */
    @NotEmpty(message = "회원 메일 수신 동의 여부는 필수값입니다.")
    private String marktRecptnEmail;
    /**
     * 회원 문자 수신 동의 여부
     */
    @NotEmpty(message = "회원 문자 수신 동의 여부는 필수값입니다.")
    private String marktRecptnSms;
    /**
     * 회원 push 수신 동의 여부
     */
    @NotEmpty(message = "회원 PUSH 수신 동의 여부는 필수값입니다.")
    private String marktRecptnPush;

}
