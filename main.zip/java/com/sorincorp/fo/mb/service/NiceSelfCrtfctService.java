/**
 *
 */
package com.sorincorp.fo.mb.service;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

/**
 * NiceSelfCrtgctService.java
 * @version
 * @since 2021. 9. 15.
 * @author srec0009
 */
public interface NiceSelfCrtfctService {

	// niceMian
	public Map<Object, Object> niceSelfCrtfct(HttpSession session, String seCode);

}
