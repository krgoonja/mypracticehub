/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sorincorp.fo.mb.service;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.mbLog.mapper.MbLogMapper;
import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.fo.mb.mapper.EntrpsEtrMapper;
import com.sorincorp.fo.mb.model.DocInfoVO;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.my.mapper.CouponDtlsMapper;
import com.sorincorp.fo.my.model.CorpInfoMgrVO;
import com.sorincorp.fo.my.model.CouponDtlVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EntrpsEtrServiceImpl implements EntrpsEtrService {

    @Autowired
    private EntrpsEtrMapper entrpsEtrMapper;

    @Autowired
    private CouponDtlsMapper couponDtlsMapper;

    @Autowired
    private MbLogMapper mbLogMapper;

    @Autowired
    public FileDocService fileDocService;

    @Autowired
    private AssignService assignService;

    @Autowired
    private SMSService smsService;

    @Autowired
    private MailService mailService;

    @Autowired
    MessageUtil messageUtil;

    @Autowired
    private CommonService commonService;

    @Autowired
    private MbCmnCodeService mbCmnCodeService;
    
    /** 이메일 발송 매퍼 */
    @Autowired
    private MailMapper mailMapper;
    
    static String SCRN_ID = "SOREC-SC-MBB-002";

    /**
     * 회원사 회원가입 > 사업자 번호 확인
     * 
     * @throws Exception
     */
    @Override
    public String checkBsnmRegistNo(EntrpsEtrVO entrpsEtrVO) throws Exception {
        String result = "";
        int cntbsnmRegistNo = entrpsEtrMapper.checkBsnmRegistNo(entrpsEtrVO);

        // 회원 승인 상태 코드 01 정상 02 승인 요청 03 보류 04 거절 05 변경승인정상
        String seCode = entrpsEtrMapper.selectMberSeCode(entrpsEtrVO);

        // 신규 회원
        if (0 == cntbsnmRegistNo) {
            String bsnmRegistNo = (entrpsEtrVO.getBsnmRegistNo()).substring(3, 5);
            for (int lawCode = 81; lawCode < 89; lawCode++) {
                // 법인 사업자
                if (bsnmRegistNo.equals(Integer.toString(lawCode))) {
                    result = "01";
                    break;
                    // 일반 사업자
                } else {
                    result = "02";
                }
            }
            // 기존 EC 가입 회원
        } else if (0 < cntbsnmRegistNo && ("01".equals(seCode) || "05".equals(seCode))) {
            result = "EC";
            // 임시 회원
        } else if (0 < cntbsnmRegistNo && "02".equals(seCode)) {
            result = "TM";
            // 중복됐을 때
        } else if (0 < cntbsnmRegistNo) {
            result = "DP";
        }
        return result;

    }

    @Override
    public int checkCprRegistNo(EntrpsEtrVO entrpsEtrVO) throws Exception {
        // TODO Auto-generated method stub
        return entrpsEtrMapper.checkCprRegistNo(entrpsEtrVO);
    }

    /**
     * ID 중복 체크
     * 
     * @throws Exception
     */
    @Override
    public int selectMberId(String mberId) throws Exception {
        return entrpsEtrMapper.selectMberId(mberId);
    }

    /**
     * 회원 가입 insert 2022-08-18 jhcha 쿠폰수정
     */
    @Override
    @Transactional(rollbackFor = SQLException.class)
    public String insertEntrpsEtr(EntrpsEtrVO entrpsEtrVO) throws Exception {
        String result = "";
        String entrpsNo = assignService.selectAssignValue("MB", "ENTRPS_NO", "ENTRPS_NO", "SYSTEM", 4);
        String mberNo = assignService.selectAssignValue("MB", "MBER_NO", "MBER_NO", "SYSTEM", 4);

        entrpsEtrVO.setEntrpsNo("C" + entrpsNo);
        entrpsEtrVO.setMberNo("P" + mberNo);
        entrpsEtrVO.setFrstRegisterId(entrpsEtrVO.getMberId());
        entrpsEtrVO.setLastChangerId(entrpsEtrVO.getMberId());
        entrpsEtrVO.setMberSecretNo(CryptoUtil.encryptSHA256(entrpsEtrVO.getMberSecretNo()));
        // String secretNo = entrpsEtrVO.getMberSecretNo();

        // 핸드폰 번호 하이픈 제거
        String mobNo = (entrpsEtrVO.getMoblphonNo()).replaceAll("[^0-9]", "");
        String moblphonNo = mobNo;
        String refndAcnutNo = entrpsEtrVO.getRefndAcnutNo();

        String bsnmRegistNo = entrpsEtrVO.getBsnmRegistNo().replaceAll("[^0-9]", "");

        int rtn = 0;
        Exception ex = new Exception();

        if (refndAcnutNo != null && !"".equals(refndAcnutNo)) {

            try {
                // 환불계좌 파라미터 암호화 20220207 srec0030
                log.debug("환불계좌 암호화 전 ===============>" + refndAcnutNo);
                refndAcnutNo = CryptoUtil.encryptAES256(refndAcnutNo);
                log.debug("환불계좌 암호화 후 ===============>" + refndAcnutNo);
                entrpsEtrVO.setRefndAcnutNo(refndAcnutNo);
                entrpsEtrVO.setAcnutUnregistEmailSndngAt("Y");
            } catch (Exception e) {
                // TODO: handle exception
                log.error("insertEntrpsEtr REFNDACNUTNO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
            }
        }

        // 회원사 테이블
        entrpsEtrMapper.insertMbEntrpsInfoBas(entrpsEtrVO);
//		entrpsEtrMapper.insertMbEntrpsInfoBasHst(entrpsEtrVO);
        mbLogMapper.insertMbEntrpsInfoBasHst(entrpsEtrVO.getEntrpsNo());

        if (moblphonNo != null && !"".equals(moblphonNo)) {
            moblphonNo = moblphonNo.replaceAll("[^0-9]", "");

            try {
                // 휴대폰 파라미터 암호화 20220118 srec0030
                log.debug("회원가입 휴대폰 암호화 전 ===============>" + moblphonNo);
                moblphonNo = CryptoUtil.encryptAES256(moblphonNo);
                log.debug("회원가입 휴대폰 암호화 후 ===============>" + moblphonNo);
                entrpsEtrVO.setMoblphonNo(moblphonNo);
            } catch (Exception e) {
                // TODO: handle exception
                log.error("insertEntrpsEtr MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
            }
        }

        // 마케팅 수신동의 여부
        entrpsEtrMapper.insertMberMarktRecptnMediaBas(entrpsEtrVO);
        entrpsEtrMapper.insertMberMarktRecptnMediaHst(entrpsEtrVO);

        if (entrpsEtrVO.getMarktRecptnSms().equals("N") && entrpsEtrVO.getMarktRecptnPush().equals("N")
                && entrpsEtrVO.getMarktRecptnEmail().equals("N")) {
            entrpsEtrVO.setAdvrtsRecptnAgreAt("N");
        } else {
            entrpsEtrVO.setAdvrtsRecptnAgreAt("Y");
        }

        // 회원 테이블
        entrpsEtrMapper.insertMbMberInfoBas(entrpsEtrVO);
        entrpsEtrMapper.insertMbMberInfoBasHst(entrpsEtrVO);

        // 배송지 테이블
        entrpsEtrMapper.insertMbDlvrgBas(entrpsEtrVO);
        entrpsEtrMapper.insertMbDlvrgBasHst(entrpsEtrVO);

        for (int i = 0; i < entrpsEtrVO.getDocInfo().size(); i++) {
            DocInfoVO docInfo = entrpsEtrVO.getDocInfo().get(i);
            docInfo.setEntrpsNo(entrpsEtrVO.getEntrpsNo());
            docInfo.setScrinId(SCRN_ID);
            docInfo.setJobSeCode("Mb");
            docInfo.setDocNo(docInfo.getDocNo());
            docInfo.setFrstRegisterId(entrpsEtrVO.getMberId());
            docInfo.setLastChangerId(entrpsEtrVO.getMberId());

            rtn = entrpsEtrMapper.insertAttachFile(docInfo);
            if (rtn < 1) {
                throw ex;
            }
        }

        // 전자상거래보증계약 확인
        List<CorpInfoMgrVO> mbEntrpsMrtggCntrctBasList = entrpsEtrMapper
                .selectMbEntrpsMrtggCntrctBasUnMatchList(bsnmRegistNo);
        int mrtggBasResult = 0;
        int mrtggDtlResult = 0;
        long grntyAmount = 0;
        long mrtggBlce = 0;

        if (mbEntrpsMrtggCntrctBasList != null && mbEntrpsMrtggCntrctBasList.size() > 0) {
            for (CorpInfoMgrVO corpInfoMgrVO : mbEntrpsMrtggCntrctBasList) {

                corpInfoMgrVO.setLastChangerId(entrpsEtrVO.getMberId());
                corpInfoMgrVO.setEntrpsNo(entrpsEtrVO.getEntrpsNo());
                corpInfoMgrVO.setEntrpsnmKorean(entrpsEtrVO.getEntrpsnmKorean());
                // 전자상거래보증계약 테이블에 업체번호 UPDATE
                mrtggBasResult = entrpsEtrMapper.updateMbEntrpsMrtGGCntrctBasEntrpsNo(corpInfoMgrVO);

                if (mrtggBasResult > 0) {
                    // 전자상거래보증계약 이력 테이블 INSERT
                    entrpsEtrMapper.insertMbEntrpsMrtGGCntrctBasHst(corpInfoMgrVO);

                    if (!"".equals(corpInfoMgrVO.getMrtggProgrsSttusCode())
                            && ("30".equals(corpInfoMgrVO.getMrtggProgrsSttusCode())
                                    || "50".equals(corpInfoMgrVO.getMrtggProgrsSttusCode()))) {
                        // 30발급, 50해지만 MB_ENTRPS_MRTGG_LMT_DTL 테이블 insert
                        if ("30".equals(corpInfoMgrVO.getMrtggProgrsSttusCode())) {
                            // 30발급, 50해지만 MB_ENTRPS_MRTGG_LMT_DTL 테이블 insert
                            // 담보 거래 유형 코드 01계약
                            corpInfoMgrVO.setMrtggDelngTyCode("01");
                            // 거래금액
                            corpInfoMgrVO.setMrtggDelngAmount(corpInfoMgrVO.getGrntyAmount());
                            // 발급일경우 남은 한도에 담보거래 금액 적용
                            corpInfoMgrVO.setMrtggBlce(corpInfoMgrVO.getGrntyAmount());
                            // 적요
                            corpInfoMgrVO.setMrtggSumry("보증서 발급");

                        } else if ("50".equals(corpInfoMgrVO.getMrtggProgrsSttusCode())) {
                            // 담보 거래 유형 코드 07해지
                            corpInfoMgrVO.setMrtggDelngTyCode("07");
                            // 거래금액
                            corpInfoMgrVO.setMrtggDelngAmount(corpInfoMgrVO.getGrntyAmount());
                            // 잔액조회
                            mrtggBlce = entrpsEtrMapper.selectMrtggBlce(corpInfoMgrVO);
                            // 잔액계산 갱신전 잔액 - 현재한도
                            mrtggBlce = mrtggBlce - corpInfoMgrVO.getGrntyAmount();
                            // 잔액
                            corpInfoMgrVO.setMrtggBlce(mrtggBlce);
                            // 적요
                            corpInfoMgrVO.setMrtggSumry("보증서 해지");
                        }

                        mrtggDtlResult = entrpsEtrMapper.insertMbEntrpsMbEntrpsMrtggLmtDtl(corpInfoMgrVO);

                        if (mrtggDtlResult > 0) {
                            entrpsEtrMapper.insertMbEntrpsMbEntrpsMrtggLmtDtlHst(corpInfoMgrVO);
                        }
                    }
                } else {
                    // throw ex;
                }
            }
        }

        // 회원가입 이메일, 푸시, 문자 발송
        Date today = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy년 MM월 dd일"); // 원하는 데이터 포맷 지정
        String regDate = simpleDateFormat.format(today); // 지정한 포맷으로 변환

        String serviceDomain = "https://www.kztraders.com";
        String templateNum = "27";
        String title = mbCmnCodeService.selectMssageSj(templateNum);
        String mberEmail = entrpsEtrVO.getMberEmail();
        // String purchschargerEmail = entrpsEtrVO.getPurchschargerEmail();

        Map<String, String> msgMap = new HashMap<>();
        SMSVO smsVO = new SMSVO();
        msgMap.put("templateNum", templateNum); // 메시지 템플릿 번호
        msgMap.put("companyName", entrpsEtrVO.getEntrpsnmKorean());
        msgMap.put("companyCeoName", entrpsEtrVO.getRprsntvNm());
        msgMap.put("userId", entrpsEtrVO.getMberId());
        msgMap.put("regDate", regDate);
        msgMap.put("Servicedomain", serviceDomain);
        smsVO.setPhone(mobNo); // 받는사람 번호
        smsVO.setMberNo(entrpsEtrVO.getMberNo());
        smsVO.setMsgTitle(title);
        smsService.insertSMS(smsVO, msgMap); // 메소드 호출

        //기업회원가입 알림발송 (케이지트레이딩 내부관리자)
        Map<String, String> smsMap = new HashMap<>();
        smsMap.put("templateNum", "130");
        smsMap.put("companyName", entrpsEtrVO.getEntrpsnmKorean());
        smsMap.put("chargerNm", entrpsEtrVO.getMberNm());
        smsMap.put("userId", entrpsEtrVO.getMberEmail());
        String chargerTlphonNo = mobNo;
        if (chargerTlphonNo.length() == 11) {
            chargerTlphonNo = chargerTlphonNo.substring(0, 3) + "-" + chargerTlphonNo.substring(3, 7) + "-" + chargerTlphonNo.substring(7, 11);
        }
        smsMap.put("chargerTlphonNo", chargerTlphonNo);
        smsMap.put("rprsntvNm", entrpsEtrVO.getRprsntvNm());
        smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
        smsService.insertSMS(null, smsMap);

        Map<String, String> mailMap = new HashMap<>();
        MailVO mailVO = new MailVO();
        MailVO selectMailTmpt = mailMapper.selectMailTmpt(27);          // 발신자 이메일 가져오기
        mailVO.setMailTmptSeq(27); // 사용할 템플릿 번호 지정
        mailVO.setEmail(mberEmail); // 수신자 메일 주소
        mailVO.setMemberNo(entrpsEtrVO.getMberNo());
        mailVO.setMailSendUserId("admin"); // 보내는 사람 아이디
        mailVO.setMailSendEmail(selectMailTmpt.getSntoEmail()); // 보내는 사람 이메일
        // 구매담당자 이메일 전송위해 파라미터 세팅
        mailVO.setEntrpsNo(entrpsEtrVO.getEntrpsNo()); // 업체 번호 (로그인)

        mailMap.put("userId", entrpsEtrVO.getMberId());
        mailMap.put("entrpsnmKorean", entrpsEtrVO.getEntrpsnmKorean()); // 20220323 회원가입 기업명 추가 (이현진 사원)
        mailMap.put("regDate", regDate);
        mailService.insertMailSend(mailVO, mailMap);

//			//구매담당자 이메일이 존재하고 수신자 이메일과 다른이메일일 경우 구매담당자 이메일주소로 같이 메일전송
//			if(purchschargerEmail != null && !"".equals(purchschargerEmail) && !mberEmail.equals(purchschargerEmail)) {
//				mailVO.setEmail(entrpsEtrVO.getPurchschargerEmail()); // 수신자 메일 주소
//				mailService.insertMailSend(mailVO, mailMap);
//			}

        // [추가] 회원등록시 회원등록쿠폰 쿠폰리스트 추가
 		// 등록 가기전에 [가입축하 이벤트 쿠폰] 추가
 		// 2023.11 -배송비 쿠폰 변경
 		/*
 		 * CouponDtlVO couponVO = new CouponDtlVO();
 		 * couponVO.setCouponEventNo("1");// 가입축하 이벤트 쿠폰
 		 * couponVO.setEntrpsNo(entrpsEtrVO.getEntrpsNo());
 		 * couponVO.setMberNo(entrpsEtrVO.getMberNo());
 		 * couponVO.setMberId(entrpsEtrVO.getMberId());
 		 * couponDtlsMapper.insertCouponIsu(couponVO);
 		 */
 		// TODO : 가입축하 쿠폰 -> 배송비 쿠폰 추가 시 BO 먼저 선행되어야함 : 프로모션 선 등록 필요
 		// 그 외 데이터는 아래 친구추천 이벤트 와 동일하게 진행 필요 : 현진
 		CouponDtlVO dlvyCouponVO = new CouponDtlVO();
 		dlvyCouponVO.setCouponSn("CP-" + DateUtil.getNowDateTime("yyyyMM") + "-"
 				+ assignService.selectAssignValue("CP", "COUPON_SN",
 						DateUtil.calDate("yyyy"), entrpsEtrVO.getMberId(), 5));
 		dlvyCouponVO.setCouponDtlNo("20231201-C00107");
 		dlvyCouponVO.setEntrpsNo(entrpsEtrVO.getEntrpsNo());
 		dlvyCouponVO.setCouponSttusCode("01");
 		dlvyCouponVO.setFrstRegisterId(entrpsEtrVO.getMberId());
 		dlvyCouponVO.setLastChangerId(entrpsEtrVO.getMberId());
 		couponDtlsMapper.insertCouponIsuNew(dlvyCouponVO);

 		// history
 		List<String> primaryKeyListdlvy = new ArrayList<>();
 		primaryKeyListdlvy.add("COUPON_DTL_NO");
 		commonService.insertTableHistory("CP_COUPON_ISU_BAS", dlvyCouponVO, primaryKeyListdlvy);

 		// 쿠폰 정보 기본 발급 수량 수정
 		dlvyCouponVO.setIssuQy(1);
 		dlvyCouponVO.setCouponNo("20231130-P00019");
 		couponDtlsMapper.updateCouponPolicyInfo(dlvyCouponVO);
 		commonService.insertTableHistory("CP_COUPON_INFO_BAS", dlvyCouponVO);
        
        
        // 친구추천 이벤트
        if(entrpsEtrVO.getRecomendrId() != null && !"".equals(entrpsEtrVO.getRecomendrId())) {
            
            // 추천인아이디 업체번호 조회
            String recomendrEntrpsNo = entrpsEtrMapper.selectEntrpsNo(entrpsEtrVO.getRecomendrId()); 
            
            for(int i=0; i < 2; i++) {
                CouponDtlVO eventCouponVO = new CouponDtlVO();
                eventCouponVO.setCouponSn("CP-"+DateUtil.getNowDateTime("yyyyMM")+"-"+ assignService.selectAssignValue("CP", "COUPON_SN", DateUtil.calDate("yyyy"), entrpsEtrVO.getMberId(), 5));
                eventCouponVO.setCouponDtlNo("20230817-C00008");
                eventCouponVO.setEntrpsNo(entrpsEtrVO.getEntrpsNo());
                eventCouponVO.setCouponSttusCode("01");
                eventCouponVO.setCouponDscntApplcAmount(125000);
                eventCouponVO.setFrstRegisterId(entrpsEtrVO.getMberId());
                eventCouponVO.setLastChangerId(entrpsEtrVO.getMberId());
                couponDtlsMapper.insertCouponIsuNew(eventCouponVO);
                
                // history
                List<String> primaryKeyList = new ArrayList<>();
                primaryKeyList.add("COUPON_DTL_NO");
                commonService.insertTableHistory("CP_COUPON_ISU_BAS", eventCouponVO, primaryKeyList);
                
                // 쿠폰 정보 기본 발급 수량,금액 수정
                eventCouponVO.setIssuAmount(125000);
                eventCouponVO.setIssuQy(1);
                eventCouponVO.setCouponNo("20230817-P00006");
                couponDtlsMapper.updateCouponPolicyInfo(eventCouponVO);
            }
            
            for(int k=0; k < 2; k++) {
                CouponDtlVO eventCouponVO = new CouponDtlVO();
                eventCouponVO.setCouponSn("CP-"+DateUtil.getNowDateTime("yyyyMM")+"-"+ assignService.selectAssignValue("CP", "COUPON_SN", DateUtil.calDate("yyyy"), recomendrEntrpsNo, 5));
                eventCouponVO.setCouponDtlNo("20230817-C00008");
                eventCouponVO.setEntrpsNo(recomendrEntrpsNo);
                eventCouponVO.setCouponSttusCode("01");
                eventCouponVO.setCouponDscntApplcAmount(125000);
                eventCouponVO.setFrstRegisterId(entrpsEtrVO.getMberId());
                eventCouponVO.setLastChangerId(entrpsEtrVO.getMberId());
                couponDtlsMapper.insertCouponIsuNew(eventCouponVO);

                // history
                List<String> primaryKeyList = new ArrayList<>();
                primaryKeyList.add("COUPON_DTL_NO");
                commonService.insertTableHistory("CP_COUPON_ISU_BAS", eventCouponVO, primaryKeyList);
                
                // 쿠폰 정보 기본 발급 수량,금액 수정
                eventCouponVO.setIssuAmount(125000);
                eventCouponVO.setIssuQy(1);
                eventCouponVO.setCouponNo("20230817-P00006");
                couponDtlsMapper.updateCouponPolicyInfo(eventCouponVO);

                //단가 할인 쿠폰 발행 알림톡
                procSms(eventCouponVO, "122");
            }
        }

        result = "S";

        return result;
    }

    /**
     * 이용약관 조회
     * 
     * @throws Exception
     */
    @Override
    public List<EntrpsEtrVO> selectEntrpsEtrStplat() throws Exception {
        List<EntrpsEtrVO> resultList = entrpsEtrMapper.selectEntrpsEtrStplat();
        return resultList;
    }

    /**
     * 파일 업로드
     */
    @SuppressWarnings("finally")
    @Override
    public HashMap<String, String> saveAttachFile(MultipartHttpServletRequest mRequest) {
        List<FileDocVO> fileKeys = null;
        FileDocVO fileDocVO = new FileDocVO();
        HashMap<String, String> fileMap = new HashMap<>();

        String errMsg = "";

        try {
            fileKeys = fileDocService.uploadAttachFilesVoList("MB", mRequest);
            fileDocVO = fileKeys.get(0);
            fileMap.put("docNo", Integer.toString(fileDocVO.getDocNo()));
            fileMap.put("fileName", fileDocVO.getDocFileNm());
            fileMap.put("filePath", fileDocVO.getDocFileRealCours());
            fileMap.put("result", "S");

        } catch (Exception e) {
            log.error(e.toString());
            errMsg = messageUtil.getMessage(e.getMessage());
            fileMap.put("result", "F");
        } finally {
            fileMap.put("errMsg", errMsg);
            return fileMap;
        }
    }

    @Override
    public Map<String, Object> deleteFileDoc(FileDocVO fileVO) throws Exception {
        Map<String, Object> map = new HashMap<String, Object>();

        // 공통_문서 기본 - 문서 사용 여부 'N'으로 수정
        fileDocService.deleteCommonDoc(fileVO.getDocNo());
        map.put("docNo", fileVO.getDocNo());
        map.put("result", "success");

        return map;
    }

    @Override
    public int selectMberMobNo(EntrpsEtrVO entrpsEtrVO) throws Exception {
        String moblphonNo = entrpsEtrVO.getMoblphonNo();

        if (moblphonNo != null && !"".equals(moblphonNo)) {
            // 암호화 전 하이푼 제거
            moblphonNo = moblphonNo.replaceAll("[^0-9]", "");

            try {
                // 휴대폰 파라미터 암호화 20220118 srec0030
                log.debug("휴대폰 암호화 전 ===============>" + moblphonNo);
                moblphonNo = CryptoUtil.encryptAES256(moblphonNo);
                log.debug("휴대폰 암호화 후 ===============>" + moblphonNo);
            } catch (Exception e) {
                // TODO: handle exception
                log.error("selectMberMobNo MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
            }

            entrpsEtrVO.setMoblphonNo(moblphonNo);
        }
        int reslt = entrpsEtrMapper.selectMberMobNo(entrpsEtrVO);
        return reslt;
    }

    @Override
    public String selectRefndAccntSattus(String entrpsNo) throws Exception {

        String refndSttus = (String) entrpsEtrMapper.selectRefndAccntSattus(entrpsNo);

        if (refndSttus == null || "".equals(refndSttus)) {

            refndSttus = "";
        }

        return refndSttus;
    }

	/** 쿠폰발행 알림톡 발송 */
	private void procSms(CouponDtlVO couponSmsVO, String templateNum) throws Exception {

		log.debug("EntrpsCouponServiceImpl::procSms 업체 지정 쿠폰 : 쿠폰 발행 알림톡 발송 Start");
		try {
			SMSVO smsVO = new SMSVO();
			String entrpsNo = couponSmsVO.getEntrpsNo();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
			smsVO.setCommerceNtcnAt("Y"); //커머스 전송 여부
			
			//업체 정보 조회
			List<EntrpsEtrVO> mberList = entrpsEtrMapper.getEntrpsInfo(entrpsNo);
			//쿠폰 정보 조회
			CouponDtlVO couponVO = couponDtlsMapper.getCouponInfo(couponSmsVO);

			//같은 업체명을 가진 모든 회원에게 알림톡 전송
			for(EntrpsEtrVO vo : mberList){
				smsVO.setMberNo(vo.getMberNo());
				smsVO.setPhone(vo.getMoblphonNo());
				// MB_MBER_INFO_BAS(회원_회원 정보 기본) - MOBLPHON_NO(휴대전화 번호) 복호화
				String phone = String.valueOf(smsVO.getPhone());
				if(StringUtils.isNotEmpty(phone) && !phone.equals("null")) {
					try {
						log.debug("휴대전화 번호 복호화 전 ==================>" + phone);
						phone = CryptoUtil.decryptAES256(phone);
						log.debug("휴대전화 번호 복호화 후 ==================>" + phone);
						/** 휴대전화 번호 셋팅 **/
						smsVO.setPhone(phone);
					} catch(Exception e) {
						log.error("EntrpsCouponServiceImpl procSms MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
					}
				}

				Map<String, String> smsMap = new HashMap<>();
				//EntrpsCouponVO dataVO = entrpsCouponMapper.getSmsInfo(entprsIsu); //쿠폰 SMS발송을 위한 데이터 조회

				smsMap.put("couponNm",couponVO.getCouponNm());		//쿠폰명
				smsMap.put("metalName",couponVO.getMetalCode());				//메탈명
				smsMap.put("mt", String.valueOf(couponVO.getMt()));	//톤수
				smsMap.put("couponTyName",couponVO.getCouponTyCode());			//쿠폰타입
				smsMap.put("orderTyName",couponVO.getOrderTyCode());			//쿠폰타입
				smsMap.put("couponBgnde",couponVO.getCouponBgnde());	//쿠폰시작일자
				smsMap.put("couponEndde",couponVO.getCouponEndDe());	//쿠폰마감일자
				smsMap.put("templateNum", templateNum); 		// 템플릿 번호
				smsMap.put("excpSndngOptnAt","N");			//예외 발송 여부
				smsService.insertSMS(smsVO, smsMap);
			}
		} catch (Exception e) {
			log.debug("EntrpsCouponServiceImpl::procSms exception = " + e.getMessage());
		}
	}
    
}
