/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sorincorp.fo.mb.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.fo.mb.mapper.MberAcntEtrMapper;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.model.MberAcntEtrVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MberAcntEtrServiceImpl implements MberAcntEtrService {

	@Autowired
	private MberAcntEtrMapper mberAcntEtrMapper;

	@Autowired
	MessageUtil messageUtil;

	/**
	 * 멤버 계정 정합성 확인
	 */
	@Override
	public String selectMberAcntEtrId(EntrpsEtrVO entrpsEtrVO) {
		String result = "";
		String moblphonNo = entrpsEtrVO.getMoblphonNo();

		if(moblphonNo != null && !"".equals(moblphonNo)) {
			moblphonNo = moblphonNo.replaceAll("[^0-9]", "");

			//휴대폰 파라미터 암호화 20220118 srec0030
			try {
				log.debug("휴대폰 암호화 전 ===============>" + moblphonNo);
				moblphonNo = CryptoUtil.encryptAES256(moblphonNo);
				log.debug("휴대폰 암호화 후 ===============>" + moblphonNo);
				entrpsEtrVO.setMoblphonNo(moblphonNo);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.error("selectMberAcntEtrId MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}

		int cnt = mberAcntEtrMapper.selectMberAcntEtrId(entrpsEtrVO);
		if(cnt == 1) {
			result = "S";
		}else{
			result = "F";
		}
		return result;
	}

	/**
	 * 멤버 계정 시작
	 * @throws Exception 
	 */
	@Override
	public String updateMberAcntInfo(EntrpsEtrVO entrpsEtrVO) throws Exception {
		String result = "";
		entrpsEtrVO.setLastChangerId(entrpsEtrVO.getMberId());
		entrpsEtrVO.setMberConfmSttusCode("01");
		entrpsEtrVO.setMberSecretNo(CryptoUtil.encryptSHA256(entrpsEtrVO.getMberSecretNo()));
		//String pw = entrpsEtrVO.getMberSecretNo();

		int updResult = mberAcntEtrMapper.updateMberAcntInfo(entrpsEtrVO);
		//entrpsEtrVO.setMberSecretNo(pw);
		int hstResult = mberAcntEtrMapper.insertMberAcntInfoHst(entrpsEtrVO);
		
		// 마케팅 수신동의 여부
		entrpsEtrVO.setFrstRegisterId(entrpsEtrVO.getMberId());
		entrpsEtrVO.setMberNo(mberAcntEtrMapper.selectMberNo(entrpsEtrVO));
		mberAcntEtrMapper.insertMberMarktRecptnMediaBas(entrpsEtrVO);
		mberAcntEtrMapper.insertMberMarktRecptnMediaHst(entrpsEtrVO);
		if(updResult == 1 && hstResult == 1) {
			result = "S";
		}else {
			result = "F";
		}
		return result;
	}

	/**
	 * 멤버 계정 구분코드 확인
	 */
	@Override
	public int selectCntMberSeCode(MberAcntEtrVO mberAcntEtrVO) {
		
		int selResult = 0;
		
		try {
			String mberId = mberAcntEtrVO.getMberId();
			
			if(log.isDebugEnabled()) {
				log.debug("mberId : {}", mberId);
			}
			if("".equals(mberId)) {
				return -1;
			}
			
			selResult = mberAcntEtrMapper.selectCntMberSeCode(mberAcntEtrVO);
		} catch (Exception e) {
			log.error("selectCntMberSeCode ERROR {}", e.getMessage());
			selResult = -1;
		}
		
		return selResult;
	}


}
