/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sorincorp.fo.mb.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.model.MberAcntEtrVO;

public interface MberAcntEtrService {

	/**
	 * <pre>
	 * 처리내용: 멤버계정 시작하기 > 계정확인
	 * </pre>
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 16.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	String selectMberAcntEtrId(EntrpsEtrVO entrpsEtrVO);

	/**
	 * <pre>
	 * 처리내용: 멤버 계정 등록
	 * </pre>
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 16.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 * @throws Exception 
	 */
	String updateMberAcntInfo(EntrpsEtrVO entrpsEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 멤버계정 인증하기 > 마스터 계정인 경우 인증 불가
	 * </pre>
	 * @date 2022. 3. 22.
	 * @author sjham
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 3. 22.			sjham				최초작성
	 * ------------------------------------------------
	 * @param MberAcntEtrVO
	 * @return
	 */
	int selectCntMberSeCode(MberAcntEtrVO mberAcntEtrVO);
}
