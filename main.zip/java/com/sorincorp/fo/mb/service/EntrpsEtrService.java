/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sorincorp.fo.mb.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;

public interface EntrpsEtrService {

	/**
	 * <pre>
	 * 처리내용: 사업자 번호 확인
	 * </pre>
	 *
	 * @date 2021. 7. 19.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 19.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param bsnmRegistNo
	 * @return
	 */
	String checkBsnmRegistNo(EntrpsEtrVO entrpsEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원 아이디 중복 검사
	 * </pre>
	 *
	 * @date 2021. 7. 19.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 19.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param mberId
	 * @return
	 */
	int selectMberId(String mberId) throws Exception;

	/**
	 * <pre>
	 * 처리내용:
	 * </pre>
	 *
	 * @date 2021. 7. 20.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 20.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 * @throws Exception
	 */
	String insertEntrpsEtr(EntrpsEtrVO entrpsEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용:
	 * </pre>
	 *
	 * @date 2021. 7. 26.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 26.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	List<EntrpsEtrVO> selectEntrpsEtrStplat() throws Exception;

	/**
	 * <pre>
	 * 처리내용:
	 * </pre>
	 *
	 * @date 2021. 8. 3.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 8. 3.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param mRequest
	 * @return
	 */
	HashMap<String, String> saveAttachFile(MultipartHttpServletRequest mRequest) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 11. 17.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 11. 17.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> deleteFileDoc(FileDocVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 11. 24.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 11. 24.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	int selectMberMobNo(EntrpsEtrVO entrpsEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 페이지 접근시 계좌등록 프로세스 제한
	 * </pre>
	 *
	 * @date 2022. 04. 29.
	 * @author heehoonc
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 11. 24.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	String selectRefndAccntSattus(String entrpsNo) throws Exception;

	int checkCprRegistNo(EntrpsEtrVO entrpsEtrVO) throws Exception;

}
