/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sorincorp.fo.mb.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.MailService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.mb.mapper.SimplMberEtrMapper;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.model.SimplMberEtrInfoVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SimplMberEtrServiceImpl implements SimplMberEtrService {

	@Autowired
	private SimplMberEtrMapper simplMberEtrMapper;

	@Autowired
	private AssignService assignService;

	@Autowired
	private UserInfoUtil userInfoUtil;

    @Autowired
    private SMSService smsService;

    @Autowired
    private MailService mailService;

    @Autowired
    private MbCmnCodeService mbCmnCodeService;
    
    /** 이메일 발송 매퍼 */
    @Autowired
    private MailMapper mailMapper;
    
	/**
	 * 간편 회원 이메일 확인
	 */
	@Override
	public int selectSimplMberEmail(String mberEmail) {
		int result = simplMberEtrMapper.selectSimplMberEmail(mberEmail);
		return result;
	}

	/**
	 * 간편 회원 가입
	 */
	@Override
	public int insertSimplMberEtr(SimplMberEtrInfoVO simplMberEtrInfoVO) throws Exception {
		int result = 0;
		String simplMberNo = assignService.selectAssignValue("MB", "SIMPL_MBER_NO", "SIMPL_MBER_NO", "SYSTEM", 4);

		// 핸드폰 번호 하이픈 제거
		String mobNo = (simplMberEtrInfoVO.getMoblphonNo()).replaceAll("[^0-9]", "");
		String moblphonNo = mobNo;

		simplMberEtrInfoVO.setSimplMberNo("S"+simplMberNo);
		simplMberEtrInfoVO.setSimplMberEtrSeCode("01");
		//simplMberEtrInfoVO.setMoblphonNo(simplMberEtrInfoVO.getMoblphonNo().replace("-", ""));
		if(moblphonNo != null && !"".equals(moblphonNo)) {
			try {
				log.debug("휴대폰 암호화 전 ===============>" + moblphonNo);
				moblphonNo = CryptoUtil.encryptAES256(moblphonNo);
				log.debug("휴대폰 암호화 후 ===============>" + moblphonNo);
			} catch (Exception e) {
				// TODO: handle exception
				log.error("insertSimplMberEtr MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		simplMberEtrInfoVO.setMoblphonNo(moblphonNo);
		simplMberEtrInfoVO.setFrstRegisterId(simplMberEtrInfoVO.getSimplMberId());
		simplMberEtrInfoVO.setLastChangerId(simplMberEtrInfoVO.getSimplMberId());
		simplMberEtrInfoVO.setSimplMberSecretNo(CryptoUtil.encryptSHA256(simplMberEtrInfoVO.getSimplMberSecretNo()));

		//String pw = simplMberEtrInfoVO.getSimplMberSecretNo();
		try {
			// 마케팅 수신동의 여부
			simplMberEtrMapper.insertMberMarktRecptnMediaBas(simplMberEtrInfoVO);
			simplMberEtrMapper.insertMberMarktRecptnMediaHst(simplMberEtrInfoVO);
			
			if(simplMberEtrInfoVO.getMarktRecptnSms().equals("N") && simplMberEtrInfoVO.getMarktRecptnPush().equals("N") && simplMberEtrInfoVO.getMarktRecptnEmail().equals("N")) {
				simplMberEtrInfoVO.setAdvrtsRecptnAgreAt("N");
			} else {
				simplMberEtrInfoVO.setAdvrtsRecptnAgreAt("Y");
			}
			
			result = simplMberEtrMapper.insertSimplMberEtr(simplMberEtrInfoVO);
			//simplMberEtrInfoVO.setSimplMberSecretNo(pw);
			simplMberEtrMapper.insertSimplMberHst(simplMberEtrInfoVO);
			// 회원가입 이메일, 푸시, 문자 발송
			Date today = new Date();
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy년 MM월 dd일"); //원하는 데이터 포맷 지정
			String regDate = simpleDateFormat.format(today); //지정한 포맷으로 변환

			String serviceDomain = "https://www.kztraders.com";
			// 비밀번호 초기화 시 알림 톡 발송
//			Map<String, String> kkoMap = new HashMap<>();
//			kkoMap.put("templateNum", "32");
//			kkoMap.put("{userId}", simplMberEtrInfoVO.getSimplMberId());
//			kkoMap.put("{regDate}", regDate);
//			kkoMap.put("{Servicedomain}", serviceDomain);
//			KkoMsgVO kkoVO = new KkoMsgVO();
//			kkoVO.setPhone(mobNo);
//			kkoVO.setMberNo(simplMberNo);
//			smsService.insertKkoMsg(kkoVO, kkoMap);
			String templateNum = "1";
			String title = mbCmnCodeService.selectMssageSj(templateNum);

			Map<String, String> msgMap = new HashMap<>();
		    SMSVO smsVO = new SMSVO();
		    msgMap.put("templateNum", templateNum);                                                 // 메시지 템플릿 번호
		    msgMap.put("userId", simplMberEtrInfoVO.getSimplMberId());
		    msgMap.put("regDate", regDate);
		    msgMap.put("Servicedomain", serviceDomain);
		    smsVO.setPhone(mobNo);   // 받는사람 번호
		    smsVO.setMberNo(simplMberEtrInfoVO.getSimplMberNo());
		    smsVO.setMsgTitle(title);
		    smsService.insertSMS(smsVO, msgMap);  // 메소드 호출

		    Map<String, String> mailMap = new HashMap<>();
		    MailVO mailVO = new MailVO();
		    MailVO selectMailTmpt = mailMapper.selectMailTmpt(1);          // 발신자 이메일 가져오기
		    mailVO.setMailTmptSeq(1); // 사용할 템플릿 번호 지정
		    mailVO.setEmail(simplMberEtrInfoVO.getSimplMberId()); // 수신자 메일 주소
		    mailVO.setMemberNo(simplMberEtrInfoVO.getSimplMberNo());

		    mailVO.setMailSendUserId("admin"); // 보내는 사람 아이디
		    mailVO.setMailSendEmail(selectMailTmpt.getSntoEmail()); //보내는 사람 이메일

		    mailMap.put("userId", simplMberEtrInfoVO.getSimplMberId());
		    mailMap.put("simplMberNm", simplMberEtrInfoVO.getSimplMberNm());		// 20220321 회원가입 이름 추가 (이현진 사원)
		    mailMap.put("regDate", regDate);
			mailService.insertMailSend(mailVO, mailMap);

		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return result;
	}

	@Override
	public int selectSimplMberMobNo(SimplMberEtrInfoVO simplMberEtrInfoVO) {
		String moblphonNo = simplMberEtrInfoVO.getMoblphonNo();

		if(moblphonNo != null && !"".equals(moblphonNo)) {
			moblphonNo = moblphonNo.replaceAll("[^0-9]", "");

			//휴대폰 파라미터 암호화 20220118 srec0030
			try {
				log.debug("휴대폰 암호화 전 ===============>" + moblphonNo);
				moblphonNo = CryptoUtil.encryptAES256(moblphonNo);
				log.debug("휴대폰 암호화 후 ===============>" + moblphonNo);
				simplMberEtrInfoVO.setMoblphonNo(moblphonNo);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.error("selectSimplMberMobNo MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		int result = simplMberEtrMapper.selectSimplMberMobNo(simplMberEtrInfoVO);
		return result;
	}

	@Override
	public List<EntrpsEtrVO> selectEntrpsEtrStplat() {
		return simplMberEtrMapper.selectEntrpsEtrStplat();
	}
}
