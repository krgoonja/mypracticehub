package com.sorincorp.fo.mb.service;

import java.util.List;

import com.sorincorp.fo.mb.model.MbCmnCodeVO;

/**
 * MbCmnCodeService.java
 *
 * @version
 * @since 2021. 6. 14.
 * @author srec0030
 */
public interface MbCmnCodeService {

	/**
	 * <pre>
	 * 회원 공통코드 리스트를 조회한다.
	 * </pre>
	 *
	 * @date 2021. 6. 14.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 14.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param string mainCd
	 * @return 공통코드 리스트
	 * @throws Exception
	 */
	List<MbCmnCodeVO> selectCmnCodeList(String mainCd) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 템픞릿 제목을 가져온다.
	 * </pre>
	 *
	 * @date 2021. 12. 14.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 12. 14.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param templateNum
	 * @return
	 */
	String selectMssageSj(String templateNum);

}
