package com.sorincorp.fo.mb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.mb.mapper.MbCmnCodeMapper;
import com.sorincorp.fo.mb.model.MbCmnCodeVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MbCmnCodeServiceImpl implements MbCmnCodeService {

	@Autowired
	private MbCmnCodeMapper mbCmnCodeMapper;

	/**
	 * <pre>
	 * 회원 공통코드 리스트를 조회한다.
	 * </pre>
	 *
	 * @date 2021. 6. 14.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 6. 14.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param string mainCd
	 * @return 공통코드 리스트
	 * @throws Exception
	 */
	@Override
	public List<MbCmnCodeVO> selectCmnCodeList(String mainCd) throws Exception {
		return mbCmnCodeMapper.selectCmnCodeList(mainCd);
	}

	/**
	 * <pre>
	 * 처리내용: 메세지 템플릿 제목을 조회한다.
	 * </pre>
	 *
	 * @date 2021. 12. 14.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 12. 14.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param templateNum
	 * @return
	 */
	@Override
	public String selectMssageSj(String templateNum) {
		return mbCmnCodeMapper.selectMssageSj(templateNum);
	}
}
