package com.sorincorp.fo.mb.service;

import java.util.List;

import com.sorincorp.fo.mb.model.MbEntrpsGradVO;

public interface MbCmnGradService {

	/**
	 * <pre>
	 * 회원등급 산정 상세 정보를 조회한다.
	 * </pre>
	 *
	 * @date 2022. 8. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 8. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	MbEntrpsGradVO selectMbEntrpsGradCalcDtl(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 회원등급 산정 기준 정보 리스트를 조회한다.
	 * </pre>
	 *
	 * @date 2022. 8. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 8. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param gradCalcSn
	 * @return
	 * @throws Exception
	 */
	List<MbEntrpsGradVO> selectMbEntrpsGradManageDtlList(int gradCalcSn) throws Exception;

	/**
	 * <pre>
	 * 회원등급별 혜택 기본 정보를 조회한다.
	 * </pre>
	 *
	 * @date 2022. 8. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 8. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	MbEntrpsGradVO selectMbEntrpsGradMetalAcctoManageDtl(String entrpsNo) throws Exception;

	List<MbEntrpsGradVO> selectMbEntrpsGradMetalAcctoManageDtlList(int entrpsGradSn) throws Exception;
}
