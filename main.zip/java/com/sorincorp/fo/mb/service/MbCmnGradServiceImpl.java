package com.sorincorp.fo.mb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.mb.mapper.MbCmnGradMapper;
import com.sorincorp.fo.mb.model.MbEntrpsGradVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MbCmnGradServiceImpl implements MbCmnGradService {

	@Autowired
	MbCmnGradMapper mbCmnGradMapper;

	@Override
	public MbEntrpsGradVO selectMbEntrpsGradCalcDtl(String entrpsNo) throws Exception {
		// TODO Auto-generated method stub
		return mbCmnGradMapper.selectMbEntrpsGradCalcDtl(entrpsNo);
	}

	@Override
	public List<MbEntrpsGradVO> selectMbEntrpsGradManageDtlList(int gradCalcSn) throws Exception {
		// TODO Auto-generated method stub
		return mbCmnGradMapper.selectMbEntrpsGradManageDtlList(gradCalcSn);
	}

	@Override
	public MbEntrpsGradVO selectMbEntrpsGradMetalAcctoManageDtl(String entrpsNo) throws Exception {
		// TODO Auto-generated method stub
		return mbCmnGradMapper.selectMbEntrpsGradMetalAcctoManageDtl(entrpsNo);
	}

	@Override
	public List<MbEntrpsGradVO> selectMbEntrpsGradMetalAcctoManageDtlList(int entrpsGradSn) throws Exception {
		// TODO Auto-generated method stub
		return mbCmnGradMapper.selectMbEntrpsGradMetalAcctoManageDtlList(entrpsGradSn);
	}

}
