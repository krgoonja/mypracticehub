/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.sorincorp.fo.mb.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.model.SimplMberEtrInfoVO;

public interface SimplMberEtrService {

	/**
	 * <pre>
	 * 처리내용: 간편회원 가입 이메일 중복 확인
	 * </pre>
	 * @date 2021. 8. 12.
	 * @author srec0009
	 * @param mberEmail
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 12.			srec0009			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	int selectSimplMberEmail(String mberEmail) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 간편회원 가입
	 * </pre>
	 * @date 2021. 8. 12.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 12.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simplMberEtrInfoVO
	 * @throws Exception
	 */
	int insertSimplMberEtr(SimplMberEtrInfoVO simplMberEtrInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 25.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 25.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simplMberEtrInfoVO
	 * @return
	 */
	int selectSimplMberMobNo(SimplMberEtrInfoVO simplMberEtrInfoVO);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 30.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 30.			srec0009			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<EntrpsEtrVO> selectEntrpsEtrStplat();

}
