package com.sorincorp.fo.mb.mapper;

import java.util.List;

import com.sorincorp.fo.mb.model.MbEntrpsGradVO;

public interface MbCmnGradMapper {

	MbEntrpsGradVO selectMbEntrpsGradCalcDtl(String entrpsNo) throws Exception;

	List<MbEntrpsGradVO> selectMbEntrpsGradManageDtlList(int gradCalcSn) throws Exception;

	MbEntrpsGradVO selectMbEntrpsGradMetalAcctoManageDtl(String entrpsNo) throws Exception;

	List<MbEntrpsGradVO> selectMbEntrpsGradMetalAcctoManageDtlList(int entrpsGradSn) throws Exception;
}
