/**
 *
 */
package com.sorincorp.fo.mb.mapper;

import java.util.List;

import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.model.SimplMberEtrInfoVO;

/**
 * SimplMberEtrMapper.java
 * @version
 * @since 2021. 8. 12.
 * @author srec0009
 */
public interface SimplMberEtrMapper {

	/**
	 * <pre>
	 * 처리내용: 간편회원 가입 이메일 중복 확인
	 * </pre>
	 * @date 2021. 8. 12.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 12.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param mberEmail
	 * @return
	 */
	int selectSimplMberEmail(String mberEmail);

	/**
	 * <pre>
	 * 처리내용: 간편회원 가입
	 * </pre>
	 * @date 2021. 8. 12.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 12.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simplMberEtrInfoVO
	 * @return
	 */
	int insertSimplMberEtr(SimplMberEtrInfoVO simplMberEtrInfoVO);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 13.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 13.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simplMberEtrInfoVO
	 */
	void insertSimplMberHst(SimplMberEtrInfoVO simplMberEtrInfoVO);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 25.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 25.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param simplMberEtrInfoVO
	 * @return
	 */
	int selectSimplMberMobNo(SimplMberEtrInfoVO simplMberEtrInfoVO);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 30.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 30.			srec0009			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<EntrpsEtrVO> selectEntrpsEtrStplat();
	
	/**
	 * <pre>
	 * 처리내용: 간편회원가입 마케팅 수신동의 저장
	 * </pre>
	 * @date 2022. 6. 8.
	 * @author sumin95
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 8.				sumin95 			최초작성
	 * ------------------------------------------------
	 * @param simplMberEtrInfoVO
	 */
	void insertMberMarktRecptnMediaBas(SimplMberEtrInfoVO simplMberEtrInfoVO);
	
	/**
	 * <pre>
	 * 처리내용: 간편회원가입 마케팅 수신동의 이력 저장
	 * </pre>
	 * @date 2022. 6. 8.
	 * @author sumin95
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 8.				sumin95 			최초작성
	 * ------------------------------------------------
	 * @param simplMberEtrInfoVO
	 */
	void insertMberMarktRecptnMediaHst(SimplMberEtrInfoVO simplMberEtrInfoVO);

}
