package com.sorincorp.fo.mb.mapper;

import java.util.List;

import com.sorincorp.fo.mb.model.DocInfoVO;
import com.sorincorp.fo.mb.model.EntrpsEtrVO;
import com.sorincorp.fo.mb.model.MberAcntEtrVO;

public interface MberAcntEtrMapper {

	/**
	 * <pre>
	 * 처리내용: 멤버계정 시작하기 > 계정확인
	 * </pre>
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 16.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	int selectMberAcntEtrId(EntrpsEtrVO entrpsEtrVO);

	/**
	 * <pre>
	 * 처리내용: 멤버 계정 등록
	 * </pre>
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 16.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsEtrVO
	 */
	int updateMberAcntInfo(EntrpsEtrVO entrpsEtrVO);

	/**
	 * <pre>
	 * 처리내용: 멤버 계정 등록 이력 업데이트
	 * </pre>
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 16.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	int insertMberAcntInfoHst(EntrpsEtrVO entrpsEtrVO);

	/**
	 * <pre>
	 * 처리내용: 멤버계정 인증하기 > 마스터 계정인 경우 인증 불가
	 * </pre>
	 * @date 2022. 3. 22.
	 * @author sjham
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 3. 22.			sjham				최초작성
	 * ------------------------------------------------
	 * @param MberAcntEtrVO
	 * @return
	 */
	int selectCntMberSeCode(MberAcntEtrVO mberAcntEtrVO);
	
	/**
	 * <pre>
	 * 처리내용: 마케팅 수신 동의를 위한 멤버 넘버 조회
	 * 처리내용: 마케팅 수신 동의 여부
	 * 처리내용: 마케팅 수신 동의 여부 이력
	 * </pre>
	 * @date 2022. 11. 22.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 22			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	String selectMberNo(EntrpsEtrVO entrpsEtrVO) throws Exception;
	int insertMberMarktRecptnMediaBas(EntrpsEtrVO entrpsEtrVO) throws Exception;
	int insertMberMarktRecptnMediaHst(EntrpsEtrVO entrpsEtrVO) throws Exception;
}
