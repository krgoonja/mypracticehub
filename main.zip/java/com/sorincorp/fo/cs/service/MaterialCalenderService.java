package com.sorincorp.fo.cs.service;

import java.util.List;

import org.codehaus.jettison.json.JSONArray;

import com.sorincorp.fo.cs.model.MaterialCalenderVO;

public interface MaterialCalenderService {

	/**
	 * <pre>
	 * 처리내용: 원자재 캘린더 리스트 조회
	 * </pre>
	 * @date 2022. 1. 12.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 12.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param materialCalenderVO
	 * @return
	 * @throws Exception
	 */
	JSONArray getMaterialCalenderList(MaterialCalenderVO materialCalenderVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 메인화면 원자재 캘린더 이벤트 조회
	 * </pre>
	 * @date 2022. 1. 12.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 12.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param materialCalenderVO
	 * @return
	 * @throws Exception
	 */
	List<String> getMaterialCalenderListDates(MaterialCalenderVO materialCalenderVO) throws Exception;

}
