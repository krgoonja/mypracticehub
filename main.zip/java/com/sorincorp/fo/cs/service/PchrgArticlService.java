package com.sorincorp.fo.cs.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.fo.cs.model.PchrgArticlVO;

/**
 * NsltService.java
 * @version
 * @since 2021. 8. 30.
 * @author srec0033
 */
public interface PchrgArticlService {
	
	/**
	 * <pre>
	 * 처리내용: 유료기사 목록을 조회한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<PchrgArticlVO> searchListPchrgArticl(PchrgArticlVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 유료기사 목록 총 개수를 조회한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int selectPchrgArticlListTotcnt(PchrgArticlVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 유료기사를 상세조회한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	PchrgArticlVO selectPchrgArticl(PchrgArticlVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 기사 구분 코드 목록을 조회한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectListArticlClCode(PchrgArticlVO vo) throws Exception;
	
}
