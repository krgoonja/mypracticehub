package com.sorincorp.fo.cs.service;

import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.cs.mapper.PchrgArticlMapper;
import com.sorincorp.fo.cs.model.PchrgArticlVO;

import lombok.extern.slf4j.Slf4j;

/**
 * NsltServiceImpl.java
 * @version
 * @since 2021. 8. 30.
 * @author srec0033
 */
@Slf4j
@Service
public class PchrgArticlServiceImpl implements PchrgArticlService {

	@Autowired
	private PchrgArticlMapper pchrgArticlMapper;
	
	/**
	 *  유료기사 목록을 조회한다.
	 */
	@Override
	public List<PchrgArticlVO> searchListPchrgArticl(PchrgArticlVO vo) throws Exception {
		return pchrgArticlMapper.searchListPchrgArticl(vo);
	}

	/**
	 *	유료기사 목록 총 개수를 조회한다.
	 */
	@Override
	public int selectPchrgArticlListTotcnt(PchrgArticlVO vo) throws Exception {
		return pchrgArticlMapper.selectPchrgArticlListTotcnt(vo);
	}

	/**
	 *	유료기사를 상세조회한다.
	 */
	@Override
	public PchrgArticlVO selectPchrgArticl(PchrgArticlVO vo) throws Exception {
		String searchKeyword = URLDecoder.decode(vo.getSearchKeyword(), "UTF-8");
		vo.setSearchKeyword(searchKeyword);
		
		List<PchrgArticlVO> list = pchrgArticlMapper.selectPreNextPchrgArticl(vo);
		long preArticlSn = 0; //이전글 번호
		long nextArticlSn = 0; //다음글 번호
		log.debug("현재글 번호 ===> " + vo.getArticlSn());
		int size = list.size();
		if(size == 2) {
			if(vo.getArticlSn() == list.get(0).getArticlSn() ) {
				preArticlSn = list.get(1).getArticlSn();
			} else {
				nextArticlSn = list.get(0).getArticlSn();
			}
		} else if(size == 3) {
			nextArticlSn = list.get(0).getArticlSn(); //다음글
			preArticlSn = list.get(2).getArticlSn();  //이전글
		}
		
		log.debug("이전글 ===> " + preArticlSn);
		log.debug("다음글 ===> " + nextArticlSn);
		
		PchrgArticlVO result = pchrgArticlMapper.selectPchrgArticl(vo);
		result.setPreArticlSn(preArticlSn);
		result.setNextArticlSn(nextArticlSn);
		result.setCatecoryCheckAt(vo.getCatecoryCheckAt());
		result.setSearchKeyword(vo.getSearchKeyword());
		
		return result;
	}

	/**
	 *	 기사 구분 코드 목록을 조회한다.
	 */
	@Override
	public Map<String, String> selectListArticlClCode(PchrgArticlVO vo) throws Exception {
		 Map<String, String> map = new HashMap<>();
		 
		 List<PchrgArticlVO> codeList = pchrgArticlMapper.selectListArticlClCode(vo);
		 for (int i = 0; i < codeList.size(); i++) {
			map.put(codeList.get(i).getSubCode(), codeList.get(i).getCodeNm());
		}
		 
		return map;
	}

}
