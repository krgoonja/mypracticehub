package com.sorincorp.fo.cs.service;

import java.util.List;

import com.sorincorp.fo.cs.model.SvcStplatVO;

/**
 * SvcStplatService.java
 * @version
 * @since 2021. 8. 27.
 * @author srec0033
 */
public interface SvcStplatService {
	
	/**
	 * <pre>
	 * 처리내용: 서비스약관 목록을 조회할 수 있다.(게시중, 만료) 
	 * </pre>
	 * @date 2021. 8. 30.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 30.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<SvcStplatVO> selectSvcStplatList(SvcStplatVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 서비스약관을 상세조회한다.
	 * </pre>
	 * @date 2021. 8. 30.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 30.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	SvcStplatVO selectSvcStplat(SvcStplatVO vo) throws Exception;

}
