package com.sorincorp.fo.cs.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.cs.mapper.CoprtnReqstMapper;
import com.sorincorp.fo.cs.model.CoprtnReqstVO;
import com.sorincorp.fo.login.model.Account;

import lombok.extern.slf4j.Slf4j;

/**
 * CoprtnReqstServiceImpl.java
 * @version
 * @since 2021. 8. 31.
 * @author srec0033
 */
@Slf4j
@Service
public class CoprtnReqstServiceImpl implements CoprtnReqstService {
	
	@Autowired
	private CoprtnReqstMapper reqstMapper;

	@Autowired
	private FileDocService fileDocService;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	/**
	 *	제휴신청을 등록한다.
	 */
	@Override
	public Map<String, Object> insertCoprtnReqst(CoprtnReqstVO reqst) throws Exception {
		// 세션정보
		Account account= userInfoUtil.getAccountInfo();
		String userId = "";
		String mberNo = "";
		if(account != null) {
			userId = account.getId();
			mberNo = account.getMberNo();
		}
		reqst.setInqryAnswerMberNo(mberNo);
		reqst.setFrstRegisterId(userId);
		reqst.setLastChangerId(userId);
		if(StringUtils.isNotBlank(reqst.getInqryTelno())) {
			reqst.setInqryTelno(CryptoUtil.encryptAES256(reqst.getInqryTelno().replace("-", "")));	//암호화
		}
		
		Map<String, Object> map = new HashedMap<>();
		int result = 0;
		result = reqstMapper.insertCoprtnReqst(reqst);
		if(result == 1) {
			map.put("result", "success");
			map.put("msg", "신청 내용이 정상 등록 되었습니다.");
		} else {
			map.put("result", "fail");
			map.put("msg", "신청 내용 등록에 실패하였습니다.");
		}
		
		//insert 성공후 key리턴 => 이력등록
		long inqrySn = reqst.getInqrySn();
		reqst.setInqrySn(inqrySn);
		reqstMapper.insertCoprtnReqstHst(reqst);
		
		//첨부파일 저장
		insertCoprtnReqstAtchmnfl(reqst);
//		int docNos[] = reqst.getDocNos();
//		for (int i = 0; i < docNos.length; i++) {
//			reqst.setDocNo(docNos[i]);
//		}
		
		return map;
	}
	
	/**
	 *	제휴신청 첨부파일을 등록한다.
	 */
	@Override
	public void insertCoprtnReqstAtchmnfl(CoprtnReqstVO reqst) throws Exception {
		reqstMapper.insertCoprtnReqstAtchmnfl(reqst);
		reqstMapper.insertCoprtnReqstAtchmnflHst(reqst);
	}

	/**
	 *	이메일 도메인리스트를 조회한다.
	 */
	@Override
	public List<String> selectListEmailDomain() throws Exception {
		List<String> domainList = new ArrayList<>();
		List<CoprtnReqstVO> codeList = reqstMapper.selectListEmailDomain();
		
		for (int i = 0; i < codeList.size(); i++) {
			domainList.add(codeList.get(i).getCodeNm());
		} 
		
		return domainList;
	}
	
	/**
	 *	첨부파일을 등록한다.(CO_DOC_BAS)
	 */
	@Override
	public Map<String, Object> uploadFileDoc(MultipartHttpServletRequest mrequest) throws Exception {
		Map<String,Object> map = new HashMap<String,Object>();
		List<FileDocVO> fileList = fileDocService.uploadAttachFilesVoList("CS", mrequest);
		map.put("list", fileList);
		
		return map;
	}

	/**
	 *	첨부파일을 삭제한다.(CO_DOC_BAS)
	 */
//	@Override
//	public Map<String, Object> deleteFileDoc(FileDocVO fileVO) throws Exception {
//
//		return null;
//	}


}
