package com.sorincorp.fo.cs.service;

import java.util.List;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.fo.cs.model.NoticeVO;

/**
 * NoticeService.java
 * @version
 * @since 2021. 8. 25.
 * @author srec0033
 */
public interface NoticeService {
	/**
	 * <pre>
	 * 처리내용: 공지사항 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<NoticeVO> searchListNotice(NoticeVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용:  공지사항 목록 총개수를 조회한다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int selectNoticeListTotcnt(NoticeVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 필독으로 설정된 공지사항 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 27.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 27.			srec0033			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<NoticeVO> selectListNoticeUpendexpsr() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공지사항 첨부파일 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<FileDocVO> selectListNoticeAtchmnfl(NoticeVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 공지사항을 상세조회한다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	NoticeVO selectNotice(NoticeVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 전광판 설정 목록 조회한다.
	 * </pre>
	 * @date 2024. 10. 18.
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 10. 18.			sumin			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	NoticeVO selectDisplayBoardCn(NoticeVO vo) throws Exception;
}
