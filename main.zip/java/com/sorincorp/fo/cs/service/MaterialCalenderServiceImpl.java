package com.sorincorp.fo.cs.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.cs.mapper.MaterialCalenderMapper;
import com.sorincorp.fo.cs.model.MaterialCalenderVO;

import lombok.extern.slf4j.Slf4j;

/**
 * NoticeServiceImpl.java
 * @version
 * @since 2021. 9. 27.
 * @author srec0031
 */
@Slf4j
@Service
public class MaterialCalenderServiceImpl implements MaterialCalenderService{
	@Autowired
	private MaterialCalenderMapper materialCalenderMapper;

	public JSONArray getMaterialCalenderList(MaterialCalenderVO materialCalenderVO) throws Exception {
		//이벤트 휴일 원자재 캘린더 뉴스 코드값 추가
		materialCalenderVO.setSearchEventRestdeSeCode("06");
		
		List<MaterialCalenderVO> resultList = materialCalenderMapper.getMaterialCalenderList(materialCalenderVO);
		JSONArray eventSourcesList = new JSONArray();
		for (int i = 0; i < resultList.size(); i++) {
			JSONObject eventData = new JSONObject();
			
			// 캘린더 데이터
			eventData.put("image"	, resultList.get(i).getNationImageUrl());	//국기이미지
			eventData.put("title"	, resultList.get(i).getEventRestdeNm());	//이벤트명
			eventData.put("start"	, resultList.get(i).getApplcBeginDe());		//이벤트 시작일시
			eventData.put("end"		, resultList.get(i).getApplcEndDe());		//이벤트 종료일시
			
			String eventRestdeSeCode = resultList.get(i).getEventRestdeSeCode();		//이벤트 휴일 구분 코드
			
//			//휴일 색상
//			EVENT_RESTDE_SE_CODE	COMMON_NM			COLOR	TEXTCOLOR	BACKGROUND	휴일유무	비고
//			01						한국공휴일				빨강		#FF5F5F		#FFEBEB		Y	　
//			02						국가별 공휴일 (한국제외)	빨강		#FF5F5F		#FFEBEB		N	　
//			03						한국금융이벤트			보라		#3C0368		#E9EBFF		N		한국금융이벤트
//			04						전세계금융이벤트 (한국제외)	파랑		#1D5FD0		#E7F6FF		N		세계금융이벤트
//			05						기념일, 행사			노랑		#937C05		#FFF7CC		N		각 사, 관계사 기념일
//			06						기타					회색		#666666		#EAEAEA 	N		기타
//			-1						케이지트레이딩 휴일		빨강		#FF5F5F		#FFEBEB		Y		등록은 각 사, 관계사 기념일 코드이나 케이지트레이딩  휴일이 따로 -1로 처리되고 있다면 휴일로 처리
//			-2						LME 휴일				빨강		#FF5F5F		#FFEBEB		Y	　
//			-3						기타 휴무				빨강		#FF5F5F		#FFEBEB		Y	　

			String backgroundColor 	= null;
			String borderColor		= null;
			String textColor		= null;
			
			if(eventRestdeSeCode.equals("-1")
					|| eventRestdeSeCode.equals("-2")
					|| eventRestdeSeCode.equals("-3")
					|| eventRestdeSeCode.equals("01")
					|| eventRestdeSeCode.equals("02")) {
				backgroundColor = "#FFCBCB";
				borderColor 	= "#FFCBCB";
				textColor 		= "#ffffff";
			} else if(eventRestdeSeCode.equals("03")) {
				backgroundColor = "#E9EBFF";
				borderColor 	= "#E9EBFF";
				textColor 		= "#3C0368";
			} else if(eventRestdeSeCode.equals("04")) {
				backgroundColor = "#E7F6FF";
				borderColor 	= "#E7F6FF";
				textColor 		= "#1D5FD0";
			} else if(eventRestdeSeCode.equals("05")) {
				backgroundColor = "#FFF7CC";
				borderColor 	= "#FFF7CC";
				textColor 		= "#937C05";
			} else if(eventRestdeSeCode.equals("06")) {
				backgroundColor = "#EAEAEA";
				borderColor 	= "#EAEAEA";
				textColor 		= "#666666";
			}else if(eventRestdeSeCode.equals("07")) {
				backgroundColor = "#FFEBEB";
				borderColor 	= "#FFEBEB";
				textColor 		= "#FF5F5F";
			}
			
			
			//end if()
			
			eventData.put("backgroundColor"	, backgroundColor);
			eventData.put("borderColor"		, borderColor);
			eventData.put("textColor"		, textColor);
			
			if(resultList.get(i).getApplcBeginDe().equals(resultList.get(i).getApplcEndDe())) {
				// 시작일과 종료일이 같으면 날짜만
				eventData.put("end", resultList.get(i).getApplcEndDe());
			} else {
				// 시작일과 종료일이 다르면 종료일에 시간 추가
				eventData.put("end", resultList.get(i).getApplcEndDe()+"T23:59:00");
			}//end if()
			eventSourcesList.put(eventData);
		}//end for()
		
		return eventSourcesList;
	}
	
	public List<String> getMaterialCalenderListDates(MaterialCalenderVO materialCalenderVO) throws Exception {

		List<MaterialCalenderVO> resultList = materialCalenderMapper.getMaterialCalenderListDates(materialCalenderVO);
		List<String> eventSourcesList = new ArrayList<String>();
		
		for (int i = 0; i < resultList.size(); i++) {
			
			if(resultList.get(i).getApplcBeginDe().equals(resultList.get(i).getApplcEndDe())) {
				// 시작일과 종료일이 같으면 시작일만
				if(!eventSourcesList.contains(resultList.get(i).getApplcBeginDe())) {
					eventSourcesList.add(resultList.get(i).getApplcBeginDe());
				}
			} else {
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

				Date d1 = df.parse( resultList.get(i).getApplcBeginDe() );
				Date d2 = df.parse( resultList.get(i).getApplcEndDe() );

				Calendar c1 = Calendar.getInstance();
				Calendar c2 = Calendar.getInstance();

				//Calendar 타입으로 변경 add()메소드로 1일씩 추가해 주기위해 변경
				c1.setTime( d1 );
				c2.setTime( d2 );

				//시작날짜가 끝날짜보다 작은 경우 리스트에 추가 
				while( c1.compareTo( c2 ) !=1 ){
					if(!eventSourcesList.contains(df.format(c1.getTime()))) {
						eventSourcesList.add(df.format(c1.getTime()));
					}
				    
				    //시작날짜 + 1 일
				    c1.add(Calendar.DATE, 1);
			    }
			}
		}
		return eventSourcesList;
	}
	
}
