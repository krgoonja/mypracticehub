package com.sorincorp.fo.cs.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.fo.cs.model.CoprtnReqstVO;

/**
 * CoprtnReqstService.java
 * @version
 * @since 2021. 8. 31.
 * @author srec0033
 */
public interface CoprtnReqstService {
	
	/**
	 * <pre>
	 * 처리내용: 제휴신청을 등록한다.
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param reqst
	 * @throws Exception
	 */
	public Map<String, Object> insertCoprtnReqst(CoprtnReqstVO reqst) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 제휴신청 첨부파일을 등록한다.
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param reqst
	 * @throws Exception
	 */
	public void insertCoprtnReqstAtchmnfl(CoprtnReqstVO reqst) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 첨부파일을 등록한다.(CO_DOC_BAS)
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param mrequest
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> uploadFileDoc(MultipartHttpServletRequest mrequest) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이메일 도메인리스트를 조회한다.
	 * </pre>
	 * @date 2021. 10. 7.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 7.			srec0033			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public List<String> selectListEmailDomain() throws Exception;
	
//	/**
//	 * <pre>
//	 * 처리내용: 첨부파일을 삭제한다.(CO_DOC_BAS)
//	 * </pre>
//	 * @date 2021. 10. 6.
//	 * @author srec0033
//	 * @history 
//	 * ------------------------------------------------
//	 * 변경일					작성자				변경내용
//	 * ------------------------------------------------
//	 * 2021. 10. 6.			srec0033			최초작성
//	 * ------------------------------------------------
//	 * @param fileVO
//	 * @return
//	 * @throws Exception
//	 */
//	public Map<String, Object> deleteFileDoc(FileDocVO fileVO) throws Exception;
	
}
