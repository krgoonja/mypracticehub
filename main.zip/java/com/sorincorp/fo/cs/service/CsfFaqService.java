package com.sorincorp.fo.cs.service;

import java.util.List;

import com.sorincorp.fo.cs.model.CsfFaqVO;


/**
 * CsfFaqService.java
 * @version
 * @since 2021. 7. 27.
 * @author srec0032
 */
public interface CsfFaqService {

	/**
	 * <pre>
	 * 처리내용: Faq 전체 Count 조회한다.
	 * </pre>
	 * @date 2021. 8. 20.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 20.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param seachVo
	 * @return
	 */
	public int selectFaqListTotCnt(CsfFaqVO seachVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: Faq 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 20.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 20.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param seachVo
	 * @return
	 */
	public List<CsfFaqVO> selectFaqList(CsfFaqVO seachVo)  throws Exception;
}
