package com.sorincorp.fo.cs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.fo.cs.mapper.CsfFaqMapper;
import com.sorincorp.fo.cs.model.CsfFaqVO;

import lombok.extern.slf4j.Slf4j;

/**
 * CsfFaqServiceImpl.java
 * @version
 * @since 2021. 7. 27.
 * @author srec0032
 */
@Slf4j
@Service
public class CsfFaqServiceImpl implements CsfFaqService {

	@Autowired
	CsfFaqMapper csfFaqMapper;
	/**
	 * Faq 전체 Count 조회한다.
	 * @throws Exception
	 */
	@Override
	public int selectFaqListTotCnt(CsfFaqVO seachVo) throws Exception {
		return csfFaqMapper.selectFaqListTotCnt(seachVo);
	}

	/**
	 * Faq 목록을 조회한다
	 */
	@Override
	public List<CsfFaqVO> selectFaqList(CsfFaqVO seachVo) throws Exception {
		List<CsfFaqVO> faqList = csfFaqMapper.selectFaqList(seachVo);
		if(faqList != null && faqList.size() > 0) {
			for(CsfFaqVO faqVo : faqList) {
				int faqNo = faqVo.getFaqNo();
				faqVo.setAttachFiles(csfFaqMapper.selectDocInfoList(faqNo));
			}
		}
		return faqList;
	}

}
