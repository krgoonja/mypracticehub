package com.sorincorp.fo.cs.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sorincorp.comm.bsnInfo.model.RltmEndTimeVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.util.HttpUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * OrderLimitsController.java
 * @version
 * @since 2023. 6. 27.
 * @author tpdls7080
 */

@Slf4j
@Controller
@RequestMapping("/cs/limits")
public class OrderLimitsController {
	
	@Autowired
	private BsnInfoService bsnInfoService;


	/**
	 * <pre>
	 * 처리내용: 지정가 내용을 조회한다.
	 * </pre>
	 * @date 2023. 06. 27.
	 * @author tpdls7080
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 06. 27.			tpdls7080			최초작성
	 * ------------------------------------------------
	 * @param 
	 * @param 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/orderLimitsInfo")
	public String orderLimitsInfo(ModelMap model) throws Exception {
		try {
			List<RltmEndTimeVO> list = bsnInfoService.getLiveOperTimeAll();
			RltmEndTimeVO summerSeason = null;
			RltmEndTimeVO winterSeason = null;
			Optional<RltmEndTimeVO> s = 
				list
				.stream()
				.filter(vo -> vo.getSubCode().equals("01"))
				.findFirst();
			
			summerSeason = s.get();
			
			Optional<RltmEndTimeVO> w = 
					list
					.stream()
					.filter(vo -> vo.getSubCode().equals("02"))
					.findFirst();
			
			winterSeason = w.get();
			
			model.put("summerSeason", summerSeason);
			model.put("winterSeason", winterSeason);
			
			return "cs/orderLimitsInfo";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}
 
}
