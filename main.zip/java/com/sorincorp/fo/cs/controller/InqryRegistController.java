package com.sorincorp.fo.cs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.cs.model.InqryRegistVO;
import com.sorincorp.fo.login.model.Account;
import com.sorincorp.fo.my.service.InqryDtlsService;

import lombok.extern.slf4j.Slf4j;

/**
 * InqryRegistController.java
 * @version
 * @since 2021. 8. 23.
 * @author srec0048
 */
@Slf4j
@Controller
@RequestMapping("/cs")
public class InqryRegistController {

	@Autowired
	private InqryDtlsService inqryDtlsService;

	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired
	private UserInfoUtil userInfoUtil;

	/**
	 * <pre>
	 * 커뮤니티 견적문의
	 * </pre>
	 * @date 2022. 1. 11.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 11.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 */
	@RequestMapping("/inqryRegist")
	public String inqryRegist(ModelMap model) {
		try {
			Account account = userInfoUtil.getAccountInfo(); // 세션정보
			
			String mberType = userInfoUtil.getType();
			
			// 문의 구분 대분류 코드
			model.addAttribute("inqrySeCode"	, inqryDtlsService.getCommCodeListStr(commonCodeService.getSubCodes("INQRY_SE_CODE"), ""));
			// 이메일 주소 공통코드
			model.addAttribute("sbxEmailDomain"	, inqryDtlsService.getCommCodeListStr(commonCodeService.getSubCodes("EMAIL_DOMAIN"), "emailDomain"));
			// 화면 구분 코드
			model.addAttribute("scrinSeCode"	, "inqry");
			// 회원 구분 코드
			model.addAttribute("mberType", mberType);
			
			// 개인정보 수집 및 이용 동의에 대한 안내 (약관 내용1)
			InqryRegistVO stplatCnOneVO 		= inqryDtlsService.selectStplatCnOne();
			
			model.addAttribute("stplatCnOne"	, stplatCnOneVO);
			
			return "cs/inqryRegist";

		} catch( Exception e ) {

			log.error(e.getMessage());
			return "error/503";

		}
	}

	/**
	 * <pre>
	 * 고객센터 문의하기
	 * </pre>
	 * @date 2022. 1. 11.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 11.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @return
	 */
	@RequestMapping("/estmtInqryRegist")
	public String estmtInqryRegist(ModelMap model) {
		try {
			Account account = userInfoUtil.getAccountInfo(); // 세션정보

			String mberType = userInfoUtil.getType();
			
			// 이메일 주소 공통코드
			model.addAttribute("sbxEmailDomain"	, inqryDtlsService.getCommCodeListStr(commonCodeService.getSubCodes("EMAIL_DOMAIN"), "emailDomain"));
			// 화면 구분 코드
			model.addAttribute("scrinSeCode"	, "estmt");
			// 회원 구분 코드
			model.addAttribute("mberType", mberType);	
			// 개인정보 수집 및 이용 동의에 대한 안내 (약관 내용1)
			InqryRegistVO stplatCnOneVO 		= inqryDtlsService.selectStplatCnOne();
			
			model.addAttribute("stplatCnOne"	, stplatCnOneVO);
						
			return "cs/estmtInqryRegist";

		} catch( Exception e ) {

			log.error(e.getMessage());
			return "error/503";

		}
	}

}
