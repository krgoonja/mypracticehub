package com.sorincorp.fo.cs.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.fo.config.UserInfoUtil;
import com.sorincorp.fo.cs.model.PchrgArticlVO;
import com.sorincorp.fo.cs.service.PchrgArticlService;
import com.sorincorp.fo.login.model.Account;

import lombok.extern.slf4j.Slf4j;

/**
 * NsltController.java
 * @version
 * @since 2021. 8. 30.
 * @author srec0033
 */
/**
 * NsltController.java
 * @version
 * @since 2021. 8. 30.
 * @author srec0033
 */
@Slf4j
@Controller
@RequestMapping("/fo/pchrgArticl")
public class PchrgArticlController {

	@Autowired
	private PchrgArticlService pchrgAriclService;

	@Autowired
	private UserInfoUtil userInfoUtil;
	
	/**
	 * <pre>
	 * 처리내용: 철강신문 목록 페이지를 조회한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/snmnews")
	public String snmnews(@RequestBody(required = false) PchrgArticlVO vo, ModelMap model) {
		try {
			
			Map<String,Object> loginStatusMap = new HashMap<String,Object>();
			Account account = userInfoUtil.getAccountInfo();
			String loginYn = "";
			if ( account == null) {
				loginYn ="N";
			}else {
				loginYn ="Y";
			}		
			loginStatusMap.put("loginYn",loginYn);
			
			model.addAttribute("news", vo);
			model.addAttribute("totalRowCount", pchrgAriclService.selectPchrgArticlListTotcnt(vo));
			model.addAttribute("pageIndex", 1);
			model.addAttribute("pageSize", 10);
			model.addAttribute("rowCountPerPage",9);
			model.addAttribute("loginStatusMap", loginStatusMap); // 로그인 여부
			
			return "cs/pchrgArticlListSnmnews";
		} catch (Exception e) {
			
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 메탈월드 목록 페이지를 조회한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/emetalworld")
	public String emetalworld(@RequestBody(required = false) PchrgArticlVO vo, ModelMap model) {
		try {
			
			Map<String,Object> loginStatusMap = new HashMap<String,Object>();
			Account account = userInfoUtil.getAccountInfo();
			String loginYn = "";
			if ( account == null) {
				loginYn ="N";
			}else {
				loginYn ="Y";
			}		
			loginStatusMap.put("loginYn",loginYn);
			
			model.addAttribute("news", vo);
			model.addAttribute("totalRowCount", pchrgAriclService.selectPchrgArticlListTotcnt(vo));
			model.addAttribute("pageIndex", 1);
			model.addAttribute("pageSize", 10);
			model.addAttribute("rowCountPerPage",9);
			model.addAttribute("loginStatusMap", loginStatusMap); // 로그인 여부
			
			return "cs/pchrgArticlListEmetalworld";
		} catch (Exception e) {
			
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 유료기사 데이터 목록을 조회한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/searchListPchrgArticl")
	@ResponseBody
	public Map<String, Object> searchListpchrgAricl(@RequestBody PchrgArticlVO vo) throws Exception {
		Map<String, Object> map = new HashedMap<>();
		List<PchrgArticlVO> nsltList = pchrgAriclService.searchListPchrgArticl(vo);
		int totDataCnt = pchrgAriclService.selectPchrgArticlListTotcnt(vo);
		
		map.put("dataList", nsltList);
		map.put("totalRowCount", totDataCnt);
		
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 유료기사를 상세조회한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/pchrgArticlDtls")
	public String pchrgArticlDtls(@RequestBody PchrgArticlVO vo, ModelMap model) {
		try {
			PchrgArticlVO news = pchrgAriclService.selectPchrgArticl(vo);
			model.put("news", news);
			log.debug("pchrgArticlDtls vo2 ===> " + news);
			
			return "cs/pchrgArticlDtls";
		}catch (Exception e) {
			log.error(e.getMessage());
            return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 기사 구분 코드 목록을 조회한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/selectListArticlClCode")
	@ResponseBody
	public Map<String,String> selectListArticlClCode(@RequestBody PchrgArticlVO vo) throws Exception {
		return pchrgAriclService.selectListArticlClCode(vo);
	}
	
}
