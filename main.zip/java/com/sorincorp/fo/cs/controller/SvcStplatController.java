package com.sorincorp.fo.cs.controller;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.fo.cs.model.SvcStplatVO;
import com.sorincorp.fo.cs.service.SvcStplatService;

import lombok.extern.slf4j.Slf4j;

/**
 * SvcStplatController.java
 * @version
 * @since 2021. 8. 27.
 * @author srec0033
 */
@Slf4j
@Controller
public class SvcStplatController {

	@Autowired
	private SvcStplatService stplatService;

	/**
	 * <pre>
	 * 처리내용: 서비스약관 조회 화면을 보여준다.
	 * </pre>
	 * @date 2021. 8. 30.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 30.			srec0033			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/fo/svcstplat/showSvcStplatList")
	public String showSvcStplatList(@RequestBody(required = false) SvcStplatVO vo, ModelMap model) {
		try {
			model.addAttribute("stplat", vo);

			return "cs/svcStplatList";
		}catch(Exception e){
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 메일의 이용약관 연결링크
	 * </pre>
	 * @date 2021. 12. 2.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 2.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/revisionTerms")
	public String revisionTerms(ModelMap model) {
		try {
			SvcStplatVO vo = new SvcStplatVO();
			vo.setStplatSeCode("01");
			model.addAttribute("stplat", vo);
			return "cs/svcStplatList";
		}catch(Exception e){
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 메일의 개인회원 이용약관 연결링크
	 * </pre>
	 * @date 2022. 06. 15.
	 * @author sumin95
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 06. 15.			sumin95				최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/revisionSimpleTerms")
	public String revisionSimpleTerms(ModelMap model) {
		try {
			SvcStplatVO vo = new SvcStplatVO();
			vo.setStplatSeCode("02");
			model.addAttribute("stplat", vo);
			return "cs/svcStplatList";
		}catch(Exception e){
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용:  개인정보 제 3자 제공 동의방침 연결링크
	 * </pre>
	 * @date 2022. 05. 31.
	 * @author sumin95
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 05. 31.			sumin95				최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	
	@GetMapping("/revisionPolicyThirdParties")
	public String indivdlInfoProvdPolicy(ModelMap model) {
		try {
			SvcStplatVO vo = new SvcStplatVO();
			vo.setStplatSeCode("03");
			model.addAttribute("stplat", vo);
			return "cs/svcStplatList";
		}catch(Exception e){
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	/**
	 * <pre>
	 * 처리내용:  개인정보수집 및 이용동의 정책 개정
	 * </pre>
	 * @date 2022. 06. 15.
	 * @author sumin95
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 06. 15.			sumin95				최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/revisionIndvdlPolicyColct")
	public String revisionIndvdlPolicyColctUrl(ModelMap model) {
		try {
			SvcStplatVO vo = new SvcStplatVO();
			vo.setStplatSeCode("05");
			model.addAttribute("stplat", vo);
			return "cs/svcStplatList";
		}catch(Exception e){
			log.error(e.getMessage());
			return "error/503";
		}
	}
	

	/**
	 * <pre>
	 * 처리내용:  메일의 마케팅동의이용약관 연결링크
	 * </pre>
	 * @date 2022. 05. 26.
	 * @authors sumin95
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 05. 26.			sumin95			 	최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/revisionMarktPolicy")
	public String revisionMarktPolicy(ModelMap model) {
		try {
			SvcStplatVO vo = new SvcStplatVO();
			vo.setStplatSeCode("06");
			model.addAttribute("stplat", vo);
			return "cs/svcStplatList";
		}catch(Exception e){
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	@GetMapping("/revisionWarrantPolicy")
	public String revisionWarrantPolicy(ModelMap model) {
		try {
			SvcStplatVO vo = new SvcStplatVO();
			vo.setStplatSeCode("07");
			model.addAttribute("stplat", vo);
			return "cs/svcStplatList";
		}catch(Exception e){
			log.error(e.getMessage());
			return "error/503";
		}
	}
	/**
	 * <pre>
	 * 처리내용: 서비스약관 목록을 조회한다.(게시중, 만료)
	 * </pre>
	 * @date 2021. 8. 30.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 30.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/fo/svcstplat/selectSvcStplatList")
	@ResponseBody
	public Map<String, Object> selectSvcStplatList(@RequestBody SvcStplatVO vo) throws Exception {
		Map<String, Object> map = new HashedMap<>();
		List<SvcStplatVO> stplatList = stplatService.selectSvcStplatList(vo);
		map.put("dataList", stplatList);

		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 서비스약관을 상세조회한다.
	 * </pre>
	 * @date 2021. 8. 30.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 30.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/fo/svcstplat/selectSvcStplat")
	@ResponseBody
	public SvcStplatVO selectSvcStplat(@RequestBody SvcStplatVO vo) throws Exception {
		SvcStplatVO stplat = stplatService.selectSvcStplat(vo);
		return stplat;
	}

}
