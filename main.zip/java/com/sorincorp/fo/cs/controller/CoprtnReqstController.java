package com.sorincorp.fo.cs.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.fo.cs.model.CoprtnReqstVO;
import com.sorincorp.fo.cs.service.CoprtnReqstService;

import lombok.extern.slf4j.Slf4j;

/**
 * CoprtnReqstController.java
 * @version
 * @since 2021. 8. 30.
 * @author srec0033
 */
@Slf4j
@Controller
@RequestMapping("/fo/coprtnreqst")
public class CoprtnReqstController {

	@Autowired
	private CoprtnReqstService reqstService;

	@Autowired
	private CustomValidator customValidator;

	/**
	 * <pre>
	 * 처리내용: 제휴신청 페이지를 조회한다.
	 * </pre>
	 * @date 2021. 9. 29.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 29.			srec0033			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/showCoprtnReqst")
	public String showCoprtnReqst() {
		try {

			return "cs/coprtnReqstRegister";
		}catch(Exception e){
			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 제휴신청을 등록한다.
	 * </pre>
	 * @date 2021. 9. 29.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 29.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param reqst
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/insertCoprtnReqst")
	@ResponseBody
	public ResponseEntity<?> insertCoprtnReqst(@RequestBody CoprtnReqstVO reqst, BindingResult bindingResult) throws Exception {
		log.debug("insertCoprtnReqst reqst ===> " + reqst);
		if(reqst.isValidation()) {
			customValidator.validate(reqst, bindingResult);
		}

		if(bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		Map<String, Object> map = reqstService.insertCoprtnReqst(reqst);

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 처리내용: 이메일 도메인리스트를 조회한다.
	 * </pre>
	 * @date 2021. 10. 7.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 7.			srec0033			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/selectListEmailDomain")
	@ResponseBody
	public List<String> selectListEmailDomain() throws Exception {
		return reqstService.selectListEmailDomain();
	}

	/**
	 * <pre>
	 * 처리내용: 첨부파일을 등록한다.
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param mrequest
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/insertFile")
	@ResponseBody
	public ResponseEntity<?> insertFile(MultipartHttpServletRequest mrequest) throws Exception {
		Map<String,Object> map = reqstService.uploadFileDoc(mrequest);

		return new ResponseEntity<>(map, HttpStatus.OK);//(HttpStatus.OK);//map, HttpStatus.OK);
	}
}
