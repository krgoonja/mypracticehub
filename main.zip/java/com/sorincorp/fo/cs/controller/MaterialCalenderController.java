package com.sorincorp.fo.cs.controller;

import java.util.List;

import org.codehaus.jettison.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.fo.cs.model.MaterialCalenderVO;
import com.sorincorp.fo.cs.service.MaterialCalenderService;

import lombok.extern.slf4j.Slf4j;

/**
 * CsfFaqController.java
 * @version
 * @since 2021. 9. 29.
 * @author srec0031
 */
@Slf4j
@Controller
@RequestMapping("/fo/cs")
public class MaterialCalenderController {
	
	@Autowired
	MaterialCalenderService materialCalenderService;
	
	/**
	 * <pre>
	 * 처리내용: 원자재 캘린더 화면 이동
	 * </pre>
	 * @date 2022. 1. 12.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 12.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/materialCalender")
	public String getLmeClndrPage() throws Exception {
		try {
			return "cs/materialCalender";	

		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	@RequestMapping("/materialCalender/getCalender")
	@ResponseBody
	public String getListDistributionHoliday(@RequestBody MaterialCalenderVO materialCalenderVO) throws Exception {
		
		JSONArray resultList = materialCalenderService.getMaterialCalenderList(materialCalenderVO);
		
		return resultList.toString();
	}
	
	@RequestMapping("/materialCalender/getCalenderDates")
	@ResponseBody
	public List<String> getListDistributionHolidayDates(@RequestBody MaterialCalenderVO materialCalenderVO) throws Exception {
		
		List<String> resultList = materialCalenderService.getMaterialCalenderListDates(materialCalenderVO);
		
		return resultList;
	}
}
