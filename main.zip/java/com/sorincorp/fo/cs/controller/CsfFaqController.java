package com.sorincorp.fo.cs.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.fo.cs.model.CsfFaqVO;
import com.sorincorp.fo.cs.service.CsfFaqService;

import lombok.extern.slf4j.Slf4j;

/**
 * CsfFaqController.java
 * @version
 * @since 2021. 7. 8.
 * @author srec0032
 */

@Slf4j
@Controller
@RequestMapping("/cs/faq")
public class CsfFaqController {

	@Autowired
	private CommonCodeService cmnCodeService;

	@Autowired
	private CsfFaqService csfFaqService;

	/**
	 * <pre>
	 * 처리내용: FAQ 내용을 조회한다.
	 * </pre>
	 * @date 2021. 7. 27.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 27.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param seachVo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/csfFaqViews")
	public String selectCsfFaqViews(CsfFaqVO seachVo, ModelMap model) throws Exception {
		try {
			Map<String, String> mainGubunCodeMap = cmnCodeService.getSubCodes("FAQ_JOB_SE_CODE");
			model.addAttribute("mainGubunCodeMap", mainGubunCodeMap);

			int totalCnt           = csfFaqService.selectFaqListTotCnt(seachVo);
			model.addAttribute("totalRowCount", totalCnt);
			model.addAttribute("pageIndex", 1);
			model.addAttribute("pageSize", 10);
			model.addAttribute("rowCountPerPage", 10);

			return "cs/csfFaqViews";
		} catch (Exception e) {
			log.error(e.getMessage());
			HttpUtil.setErrorMsgToRequestAttribute("errMsg", e);
			return "error/503";
		}
	}

	@ResponseBody
	@RequestMapping("/selectCsfFaqListData")
	public Map<String,Object> selectFaqListData(@RequestBody CsfFaqVO seachVo, ModelMap model) throws Exception {

		int totalCnt           = csfFaqService.selectFaqListTotCnt(seachVo);
		model.addAttribute("totalRowCount", totalCnt);

		List<CsfFaqVO> faqList    = csfFaqService.selectFaqList(seachVo);

		Map<String,Object> map = new HashMap<String, Object>();
		map.put("dataList", faqList);
		map.put("totalRowCount", totalCnt);

		return map;
	}
}
