package com.sorincorp.fo.cs.mapper;

import java.util.List;

import com.sorincorp.fo.cs.model.MaterialCalenderVO;

public interface MaterialCalenderMapper {

	/**
	 * <pre>
	 * 처리내용: 원자재 캘린더 조회
	 * </pre>
	 * @date 2022. 1. 12.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 12.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param materialCalenderVO
	 * @return
	 */
	List<MaterialCalenderVO> getMaterialCalenderList(MaterialCalenderVO materialCalenderVO);
	
	/**
	 * <pre>
	 * 처리내용: 메인화면 원자재 캘린더 이벤트 리스트 조회
	 * </pre>
	 * @date 2022. 1. 12.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 12.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param materialCalenderVO
	 * @return
	 */
	List<MaterialCalenderVO> getMaterialCalenderListDates(MaterialCalenderVO materialCalenderVO);

}
