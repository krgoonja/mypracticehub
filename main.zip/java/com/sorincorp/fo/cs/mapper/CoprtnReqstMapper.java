package com.sorincorp.fo.cs.mapper;

import java.util.List;

import com.sorincorp.fo.cs.model.CoprtnReqstVO;

/**
 * CoprtnReqstMapper.java
 * @version
 * @since 2021. 8. 31.
 * @author srec0033
 */
public interface CoprtnReqstMapper {
	
	/**
	 * <pre>
	 * 처리내용: 제휴신청을 등록한다.
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param reqst
	 * @throws Exception
	 */
	public int insertCoprtnReqst(CoprtnReqstVO reqst) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 제휴신청 첨부파일을 등록한다.
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param reqst
	 * @throws Exception
	 */
	public void insertCoprtnReqstAtchmnfl(CoprtnReqstVO reqst) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 이메일 도메인리스트를 조회한다.
	 * </pre>
	 * @date 2021. 10. 7.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 7.			srec0033			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public List<CoprtnReqstVO> selectListEmailDomain() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 제휴신청 이력을 등록한다.
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param reqst
	 * @throws Exception
	 */
	public void insertCoprtnReqstHst(CoprtnReqstVO reqst) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 제휴신청 첨부파일 이력을 등록한다.
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param reqst
	 * @throws Exception
	 */
	public void insertCoprtnReqstAtchmnflHst(CoprtnReqstVO reqst) throws Exception;
	
}
