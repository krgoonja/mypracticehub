package com.sorincorp.fo.cs.mapper;

import java.util.List;

import com.sorincorp.fo.cs.model.PchrgArticlVO;

/**
 * PchrgArticlMapper.java
 * @version
 * @since 2021. 8. 30.
 * @author srec0033
 */
public interface PchrgArticlMapper {
	
	/**
	 * <pre>
	 * 처리내용: 유료기사 목록을 조회한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<PchrgArticlVO> searchListPchrgArticl(PchrgArticlVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 유료기사 목록 총 개수를 조회한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int selectPchrgArticlListTotcnt(PchrgArticlVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 유료기사를 상세조회한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	PchrgArticlVO selectPchrgArticl(PchrgArticlVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 해당 유료기사의 이전글, 다음글 정보를 조회한다. 
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<PchrgArticlVO> selectPreNextPchrgArticl(PchrgArticlVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 기사 구분 코드 목록을 조회한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0033
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<PchrgArticlVO> selectListArticlClCode(PchrgArticlVO vo) throws Exception;
	
}
