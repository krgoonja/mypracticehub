package com.sorincorp.fo.cs.mapper;

import java.util.List;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.fo.cs.model.CsfFaqVO;

/**
 * CsfFaqMapper.java
 * @version
 * @since 2021. 7. 27.
 * @author srec0032
 */
public interface CsfFaqMapper {

	/**
	 * <pre>
	 * 처리내용: Faq 전체 카운트를 조회한다.
	 * </pre>
	 * @date 2021. 8. 20.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 20.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param seachVo
	 * @return
	 */
	int selectFaqListTotCnt(CsfFaqVO seachVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: Faq 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 20.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 20.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param seachVo
	 * @return
	 */
	List<CsfFaqVO> selectFaqList(CsfFaqVO seachVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: FAQ 관련 파일 정보를 조회한다.
	 * </pre>
	 * @date 2021. 9. 3.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 3.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param faqNo
	 * @return
	 * @throws Exception
	 */
	List<FileDocVO> selectDocInfoList(int faqNo) throws Exception;
}
