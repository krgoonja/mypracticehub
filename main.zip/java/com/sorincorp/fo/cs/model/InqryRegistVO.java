package com.sorincorp.fo.cs.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

/**
 * 
 * 고객센터 > 문의하기 > 이용약관 InqryRegistVO.java
 * @version
 * @since 2022. 1. 14.
 * @author srec0054
 */
@Data
public class InqryRegistVO extends CommonVO {

	private static final long serialVersionUID = 7834872780348960644L;
	
	/**약관 번호*/
	private String stplatNo;
	
	/**약관 구분 코드*/
	private String stplatSeCode;
	
	/**약관 내용1*/
	private String stplatCnOne;
	
	/**약관 내용2*/
	private String stplatCnTwo;
	
	/**약관개정 공지 일자*/
	private String stplatreformNoticeDe;
	
	/**약관개정 시작 일자*/
	private String stplatreformBeginDe;
	 
}
