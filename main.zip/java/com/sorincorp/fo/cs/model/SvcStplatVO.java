package com.sorincorp.fo.cs.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

/**
 * SvcStplat.java
 * @version
 * @since 2021. 8. 27.
 * @author srec0033
 */
@Data
public class SvcStplatVO extends CommonVO {
	
	private static final long serialVersionUID = 6882956165304862133L;
	
	   /**
	     * 약관 번호
	    */
	    private int stplatNo;
	   /**
	     * 약관 구분 코드
	    */
	    private String stplatSeCode;
	   /**
	     * 약관 내용 1
	    */
	    private String stplatCnOne;
	   /**
	     * 약관 내용 2
	    */
	    private String stplatCnTwo;
	   /**
	     * 약관개정 공지 일자
	    */
	    private String stplatreformNoticeDe;
	   /**
	     * 약관개정 시작 일자
	    */
	    private String stplatreformBeginDe;
	   /**
	     * 삭제 여부
	    */
	    private String deleteAt;
	   /**
	     * 삭제 일시
	    */
	    private java.sql.Timestamp deleteDt;
	   /**
	     * 최초 등록자 아이디
	    */
	    private String frstRegisterId;
	   /**
	     * 최초 등록 일시
	    */
	    private java.sql.Timestamp frstRegistDt;
	   /**
	     * 최종 변경자 아이디
	    */
	    private String lastChangerId;
	   /**
	     * 최종 변경 일시
	    */
	    private java.sql.Timestamp lastChangeDt;
	    /**
	     * 약관 상태
	    */
	    private String stplatSttus;
	 
	
}
