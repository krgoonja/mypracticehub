package com.sorincorp.fo.cs.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

/**
 * CoprtnReqstVO.java
 * @version
 * @since 2021. 8. 31.
 * @author srec0033
 */
@Data
public class CoprtnReqstVO extends CommonVO {

	private static final long serialVersionUID = 6882956165304862133L;
   /**
     * 문의 순번
    */
    private long inqrySn;
   /**
     * 문의 답변 구분 코드 - 01:문의
    */
    private String inqryAnswerSeCode;
   /**
     * 문의 답변 회원 번호
    */
    private String inqryAnswerMberNo;
   /**
     * 문의 답변 자
    */
    private String inqryAnswerMan;
   /**
     * 문의 전화번호
    */
    private String inqryTelno;
   /**
     * 문의 이메일
    */
    private String inqryEmail;
   /**
     * 문의 회사명
    */
    private String inqryCmpnynm;
   /**
     * 문의 상담 구분 코드 - 06:제휴문의
    */
    private String inqryCnsltSeCode;
   /**
     * 문의 구분 코드 - 80:기타?
    */
    private String inqrySeCode;
   /**
     * 문의 구분 상세 코드 - 8030:제휴문의
    */
    private String inqrySeDetailCode;
   /**
     * 문의 주문 번호
    */
//	    private String inqryOrderNo;
   /**
     * 문의 상품 코드
    */
//	    private String inqryGoodsCode;
   /**
     * 문의 답변 제목
    */
	    private String inqryAnswerSj;
   /**
     * 문의 답변 내용
    */
	    private String inqryAnswerCn;
   /**
     * 문의 처리 상태 코드 - 10:답변대기
    */
    private String inqryProcessSttusCode;
   /**
     * 문의 답변 일시
    */
    private String inqryAnswerDt;
   /**
     * 답변 메일 수신 동의 여부
    */
//	    private String answerEmailRecptnAgreAt;
   /**
     * 부모 문의 답변 순번
    */
//	    private int parntsInqryAnswerSn;
   /**
     * 문의 답변 깊이
    */
//	    private int inqryAnswerDp;
   /**
     * 문의 답변 순서
    */
//	    private int inqryAnswerOrdr;
   /**
     * 개인 정보 수집 동의 여부
    */
    private String indvdlInfoColctAgreAt;
   /**
     * 삭제 여부
    */
    private String deleteAt;
   /**
     * 삭제 일시
    */
    private String deleteDt;
   /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
   /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
   /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
   /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
   /**
    * 코드 명(이메일 도메인)
   */
   private String codeNm;
   /**
	* 문서 번호 
	*/
   private int docNo;
   /** 
	* 문서 번호 배열 - 프론트단에서 받아오는 값
	*/
   private int[] docNos;
	 
}
