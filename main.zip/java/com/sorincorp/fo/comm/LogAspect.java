package com.sorincorp.fo.comm;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;


/**
 *  로그를 컨트롤러 Class의 RequestMapping단위로 분리 하여 저장하기 위한 AOP 
 * LogAspect.java
 * @version
 * @since 2021. 8. 9.
 * @author srec0012
 */
@Component
@Aspect
public class LogAspect {
	
	@Pointcut("execution(* com.sorincorp.fo..*Controller.*(..))")
	public void logMDCPointCut() {
	}
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 컨트롤러의 메소드 실행전에 컨트롤러 클래스의 RequestMapping 정보를 MDC에 추가한다.
	 * </pre>
	 * @date 2021. 8. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param joinPoint
	 */
	@SuppressWarnings("unchecked")
	@Before("logMDCPointCut()")
	public void setControllerMDC(JoinPoint joinPoint) {
		Class clazz = joinPoint.getTarget().getClass();
		RequestMapping requestMapping = (RequestMapping) clazz.getAnnotation(RequestMapping.class);
		if (null!=requestMapping)
		MDC.put("business", requestMapping.value()[0]);
	}
	

}
