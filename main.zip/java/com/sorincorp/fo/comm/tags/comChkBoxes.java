package com.sorincorp.fo.comm.tags;

import java.io.IOException;
import java.util.StringTokenizer;
import java.util.stream.Stream;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.fo.config.UserInfoUtil;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
@Data
public class comChkBoxes extends SimpleTagSupport{
	
	private String id; // 엘리먼트 id
	private String codeStr; // 코드 데이터 문자열 예)':전체;Y:동의;N:거부’ 체크박스 value : label span 태그의 텍스트 형태로 입력됨
	private String name; // 체크박스 태그명
	private String idPrefix; // 체크박스 태그 ID 접두어
	private String value; // 체크박스 태그의 value
	private String compareValue; // 초기 체크 여부 결정을 위한 값
	private String grades; // 회원 권한
	private String chkClass; // 체크박스의 class
	private String chkLabelClass; // 체크박스 label의 class
	private String desc; // validation desc
	private boolean disabled = false; // 체크박스 비활성화 true/false
	private String style; // inline style
	private String onclick; // 체크박스의 onclick
	
	UserInfoUtil userInfoUtil;
	
	@Override
	public void doTag() throws JspException, IOException {
		
		PageContext pageContext = (PageContext)this.getJspContext();
		
		WebApplicationContext context = WebApplicationContextUtils.getRequiredWebApplicationContext(pageContext.getServletContext());
		
		userInfoUtil = context.getBean(UserInfoUtil.class);
		
		String memberSeCode = userInfoUtil.getMemberSecode();
		long checker = Stream.of(grades.split(","))
				.map(String::toString)
				//.filter(s->s.equals(memberSecode))
				.filter(s->s==null || s.toLowerCase().equals("all") || s.equals(memberSeCode))
				.count();
		
		StringTokenizer codeListToken = new StringTokenizer(codeStr, CommonConstants.SEMI_COLONE);
		String code[];
		String token;
		int index=1;
		String input;
		StringBuilder sb = new StringBuilder("");
		
		if(checker > 0) {
			
			while(codeListToken.hasMoreTokens()) {
				token = codeListToken.nextToken();
				code = token.split(CommonConstants.COLONE);
				id = idPrefix + "_" + index++;
				input = "<input type='checkbox'";
				input += " name='" + name + "'";
				input += " id='" + id  + "'";
				input += " value='" +  code[0] + "'";
				
				if(code[0].equals(compareValue)) {
					input += " checked";
				}
				
			    if(chkClass != null && !chkClass.equals("")) {
			    	input += " class='" +  chkClass + "'";
			    }
			    
			    if(style != null && !style.equals("")) {
			    	input += " style='" +  style + "'";
			    }
			    
				if(desc != null && !desc.equals("") ) {
					input += " desc='" + desc + "'";
				}
			    
				if(disabled) {
					input += " disabled";
				}
				
				if(onclick != null && !onclick.equals("")) {
					onclick = onclick.replaceAll("\"", "\'");
					input += " onclick=\"" + onclick + "\"";
				}
				
				input += "/>";
								
				sb.append(input)
				  .append("<label for ='"+ id +"'");
				
				if(style != null && !style.equals("") ) {
					sb.append(" style='" + style + "'");
				}
				
				if(chkLabelClass != null && !chkLabelClass.equals("") ) {
					sb.append(" class='" + chkLabelClass + "'");
				}
			
				sb.append(">")
				  .append("<span");
				
				if(style != null && !style.equals("") ) {
						sb.append(" style='" + style + "'");
				}
				
				sb.append(">"+code[1]+"</span>")
				  .append("</label>");
			}
			JspWriter out = getJspContext().getOut();
			out.print(sb.toString());
		}
		
		super.doTag();
	}
	
}
