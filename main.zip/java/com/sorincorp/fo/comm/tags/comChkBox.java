package com.sorincorp.fo.comm.tags;

import java.io.IOException;
import java.util.stream.Stream;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.sorincorp.fo.config.UserInfoUtil;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
@Data
public class comChkBox extends SimpleTagSupport{ 
	private String id; // 엘리먼트 id
	private String name; // 엘리먼트 name
	private String value; // 엘리먼트 value
	private boolean checkYn = false; // 초기 체크 여부
	private String text; // 체크박스 텍스트
	private String grades; // 회원 권한 
	private String chkClass; // 체크박스의 class
	private String chkLabelClass; // 체크박스 label의 class
	private boolean disabled = false; // 체크박스 비활성화 true/false
	private String desc; // validation desc
	private String style; // 체크박스의 style
	private String onclick; // 체크박스의 onclick
	
	UserInfoUtil userInfoUtil;
	
	@Override
	public void doTag() throws JspException, IOException {
		
		PageContext pageContext = (PageContext)this.getJspContext();
		
		WebApplicationContext context = WebApplicationContextUtils.getRequiredWebApplicationContext(pageContext.getServletContext());
		
		userInfoUtil = context.getBean(UserInfoUtil.class);
		
		String memberSeCode = userInfoUtil.getMemberSecode();
		long checker = Stream.of(grades.split(","))
				.map(String::toString)
				//.filter(s->s.equals(memberSecode))
				.filter(s->s==null || s.toLowerCase().equals("all") || s.equals(memberSeCode))
				.count();
		
		if(checker > 0) {
			  StringBuilder sb  = new StringBuilder("");
			  
		       sb.append("<input type='checkbox'")
		       	 .append(" name='" + name + "'")
		       	 .append(" id='" + id + "'")
		       	 .append(" value='" + value + "'");
			  
			    if(checkYn) {
			      sb.append("checked = 'checked'");
			    }
			    
			    if(chkClass != null && !chkClass.equals("")) {
			    	sb.append("class='" +  chkClass + "'");
			    }
			    
				if(desc != null && !desc.equals("") ) {
					sb.append(" desc='" + desc + "'");
				}
				
				if(style != null && !style.equals("") ) {
					sb.append(" style='" + style + "'");
				}
				
				if(disabled) {
					sb.append(" disabled");
				}
				
				if(onclick != null && !onclick.equals("")) {
					onclick = onclick.replaceAll("\"", "\'");
					sb.append(" onclick=\"" + onclick + "\"");
				}
			    
			    sb.append("/>")
			      .append("<label for='" + id+"'");
			    
				if(style != null && !style.equals("") ) {
						sb.append(" style='" + style + "'");
				}
				
				if(chkLabelClass != null && !chkLabelClass.equals("") ) {
					sb.append(" class='" + chkLabelClass + "'");
				}
				
				sb.append(">")
			      .append("<span");
			  	
				if(style != null && !style.equals("") ) {
					sb.append(" style='" + style + "'");
				}
				
				sb.append(">");
				
				if(text != null && !text.equals("") ) {
					sb.append(text);
				}

				sb.append("<span>")
			      .append("</label>");	  
				
			    JspWriter out = getJspContext().getOut();
				out.print(sb.toString());
		}
		super.doTag();
	}
	
}
