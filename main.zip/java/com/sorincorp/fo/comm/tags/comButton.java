package com.sorincorp.fo.comm.tags;

import java.io.IOException;
import java.util.stream.Stream;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.sorincorp.fo.config.UserInfoUtil;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
@Data
public class comButton extends SimpleTagSupport{

	private String id; // 엘리먼트 아이디
	private String btnClass; // 버튼의 class
	private String message; // 버튼에 표시될 메시지
	private String onclick; // 클릭 이벤트
	private boolean disabled = false; // 버튼 비활성화 true/false
	private String dataDismiss; // dataDismiss
	private String ariaLabel; // aria-label
	private String grades; // 회원 권한
	private String desc; // validation desc
	private String name; // 버튼의 name
	private String style; // inline style
	private String dataPopup; // data-popup
	private String dataTarget; // data-target
	private String value; //버튼 value

	UserInfoUtil userInfoUtil;

	@Override
	public void doTag() throws JspException, IOException {
		// TODO Auto-generated method stub
		PageContext pageContext = (PageContext)this.getJspContext();

		WebApplicationContext context = WebApplicationContextUtils.getRequiredWebApplicationContext(pageContext.getServletContext());
		//HttpServletRequest request =  (HttpServletRequest)pageContext.getRequest();
		userInfoUtil = context.getBean(UserInfoUtil.class);

		//String memberSecode = userInfoUtil.getMemberSecode(request);

		String memberSecode = userInfoUtil.getMemberSecode();
		long checker = Stream.of(grades.split(","))
							.map(String::toString)
							//.filter(s->s.equals(memberSecode))
							.filter(s->s==null || s.toLowerCase().equals("all") || s.equals(memberSecode))
							.count();

		if (checker>0) {
			StringBuilder sb = new StringBuilder("");
			sb.append("<button type='button'")
			  .append(" id='" + id + "'")
			  .append(" class='" + btnClass + "'");

			if(onclick != null && !onclick.equals("")) {
				onclick = onclick.replaceAll("\"", "\'");
				sb.append(" onclick=\"" + onclick + "\"");
			}
			if(dataDismiss != null && !dataDismiss.equals("")) {
				sb.append(" data-dismiss='" + dataDismiss + "'");
			}
			if(ariaLabel != null && !ariaLabel.equals("")) {
				sb.append(" aria-label='" + ariaLabel + "'");
			}

			if(style != null && !style.equals("")) {
				sb.append("style='" + style + "'");
			}

			if(desc != null && !desc.equals("") ) {
				sb.append(" desc='" + desc + "'");
			}

			if(name != null && !name.equals("") ) {
				sb.append(" name='" + name + "'");
			}

			if(dataPopup != null && !dataPopup.equals("") ) {
				sb.append(" data-popup='" + dataPopup + "'");
			}

			if(dataTarget != null && !dataTarget.equals("") ) {
				sb.append(" data-target='" + dataTarget + "'");
			}
			
			if(value != null && !value.equals("") ) {
				sb.append(" value='" + value + "'");
			}
			
			if(disabled) {
				sb.append(" disabled");
			}

			sb.append(">" + message + "</button>");

			JspWriter out = getJspContext().getOut();
			out.print(sb.toString());
		}
		super.doTag();
	}


}
