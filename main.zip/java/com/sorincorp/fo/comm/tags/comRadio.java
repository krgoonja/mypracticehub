package com.sorincorp.fo.comm.tags;

import java.io.IOException;
import java.util.StringTokenizer;
import java.util.stream.Stream;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.fo.config.UserInfoUtil;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
@Data
public class comRadio extends SimpleTagSupport{
	
	private String codeStr; // 코드 데이터 문자열 예) ':전체;Y:동의;N:거부’ input 태그 value : label span 태그 텍스트 형태로 제공 
	private String name; // 엘리먼트 name
	private String idPrefix; // 엘리먼트 id 접두어
	private String compareValue; // 초기 체크 여부 결정을 위한 값
	private String grades; // 회원 권한
	private String radioClass; // 라디오 버튼의 class
	private String desc; // validation desc
	private boolean disabled = false; // 라디오 버튼 비활성화 true/false
	private String style; // inline style
	private String onclick; // onclick
	private String radioId; // id 단일 radio 생성 시 
	private String checked; // 체크 여부 단일 radio 생성 시 
	
	UserInfoUtil userInfoUtil;
	
	@Override
	public void doTag() throws JspException, IOException {
		
		PageContext pageContext = (PageContext)this.getJspContext();
		
		WebApplicationContext context = WebApplicationContextUtils.getRequiredWebApplicationContext(pageContext.getServletContext());
		
		userInfoUtil = context.getBean(UserInfoUtil.class);
		
		String memberSeCode = userInfoUtil.getMemberSecode();
		long checker = Stream.of(grades.split(","))
				.map(String::toString)
				//.filter(s->s.equals(memberSecode))
				.filter(s->s==null || s.toLowerCase().equals("all") || s.equals(memberSeCode))
				.count();
		
		if(checker > 0) {
			StringBuilder sb  = new StringBuilder("");
			int index=1;
			
		    StringTokenizer codeListToken = new StringTokenizer(codeStr, CommonConstants.SEMI_COLONE);
		    String token;
		    String code[];
			String id = "";
			
		    while(codeListToken.hasMoreTokens()) {
		        token = codeListToken.nextToken();
		        code = token.split(":");
		      
		        sb.append("<input type=\"radio\"")
			       .append(" name=\"" + name + "\"");
			   
		        if(radioId != null && !radioId.equals("")) {
		        	 sb.append(" id=\"" + radioId + "\"");
		        }   
		        
		        if(idPrefix != null && !idPrefix.equals("")) {
		        	id = idPrefix + "-" + index++;
		        	sb.append(" id=\"" + id + "\"");
		        }   
			    
		        sb.append(" value=\"" + code[0] + "\"");
		       
		        if(code[0].equals(compareValue)) {
		            sb.append(" checked");
		        } 
		        
		        if(radioClass != null && !radioClass.equals("")) {
		        	 sb.append(" class="+ radioClass+"");
		        }
		       
		        
				if(desc != null && !desc.equals("") ) {
					sb.append(" desc='" + desc + "'");
				}
				
				if(style != null && !style.equals("") ) {
					sb.append(" style='" + style + "'");
				}
				
				if(onclick != null && !onclick.equals("")) {
					onclick = onclick.replaceAll("\"", "\'");
					sb.append(" onclick=\"" + onclick + "\"");
				}
				
				if(checked != null && !checked.equals("")) {
					sb.append(" checked");
				}
			    
				if(disabled) {
					sb.append(" disabled");
				}

		        sb.append(" />")
		          .append("<label");
		        
		        if(radioId != null && !radioId.equals("")) {
		        	sb.append(" for='"+ radioId+ "'");
		        }  
		        
		        if(idPrefix != null && !idPrefix.equals("")) {
		        	sb.append(" for='"+ id+"'");
		        }
		        
				if(style != null && !style.equals("") ) {
					sb.append(" style='" + style + "'");
				}
				
				sb.append(">")
				  .append("<span");
				
				if(style != null && !style.equals("") ) {
					sb.append(" style='" + style + "'");
				}
				
				sb.append(">"+code[1]+"</span>")
		          .append("</label>");
		    }
		    
		    JspWriter out = getJspContext().getOut();
			out.print(sb.toString());
		}	
		
		super.doTag();
	}
	
	
}
