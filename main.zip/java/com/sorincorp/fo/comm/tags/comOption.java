package com.sorincorp.fo.comm.tags;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.StringTokenizer;
import java.util.stream.Stream;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.fo.config.UserInfoUtil;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
@Data
public class comOption extends SimpleTagSupport{
	
	private String id; // 엘리먼트 id
	private String codeStr; // 코드 데이터 문자열 예) ':전체;Y:동의;N:거부’ option 태그 value : option 텍스트 형태로 제공 
	private String value; // option 태그의 value
	private String grades; // 회원 권한
	private String optClass; // 셀렉트 박스의 class
	private String getCodes; // 공통 메인 코드 - 공통코드 값(codeValue)을 가져옴
	private String onChange; // onChange 이벤트
	private String desc; // validation desc
	private boolean disabled = false; // 셀렉트박스 비활성화 true/false
	private String name; // option 태그의 name
	private String style; // inline style
	
	UserInfoUtil userInfoUtil;
	
	CommonCodeService commonCodeService;
	
	@Override
	public void doTag() throws JspException, IOException {
		
		PageContext pageContext = (PageContext)this.getJspContext();
		
		WebApplicationContext context = WebApplicationContextUtils.getRequiredWebApplicationContext(pageContext.getServletContext());
		
		userInfoUtil = context.getBean(UserInfoUtil.class);
		
		commonCodeService = context.getBean(CommonCodeService.class);
		
		String memberSeCode = userInfoUtil.getMemberSecode();
		
		long checker = Stream.of(grades.split(","))
				.map(String::toString)
				//.filter(s->s.equals(memberSecode))
				.filter(s->s==null || s.toLowerCase().equals("all") || s.equals(memberSeCode))
				.count();
		
		StringBuilder sb = new StringBuilder("");
		StringTokenizer codeListToken = new StringTokenizer(codeStr, CommonConstants.SEMI_COLONE);
		String token;
		String selected;
		String code[];
		String input = "";
		int index = 0;
		
		if(checker > 0) {
			
			input += "<select";
			
			if(id != null && !id.equals("")) {
				input += " id = '" + id + "'";
			}
			
			if(optClass != null && !optClass.equals("")) {
				input += " class = '"+ optClass +"'";
			}
			
			
			if(onChange != null && !onChange.equals("")) {
				input += " onChange = '"+ onChange +"'";
			}
			
			if(desc != null && !desc.equals("") ) {
				input += " desc='" + desc + "'";
			}
			
			if(style != null && !style.equals("") ) {
				input += " style='" + style + "'";
			}
			
			if(name != null && !name.equals("") ) {
				input += " name='" + name + "'";
			}
		    
			if(disabled) {
				input += " disabled";
			}
			
			input += ">";
			
			sb.append(input);
			
			if(getCodes != null && !getCodes.equals("")) { // 공통 코드 불러오는 경우
				
				Map<String,String> map = new HashMap<>();
			
				try {
					map = commonCodeService.getSubCodes(getCodes);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				for(Entry<String, String> key : map.entrySet()) {

					if(!key.getValue().equals(map.get(map.keySet().toArray()[0]))) {
						
						sb.append(" <option value='"+ key.getKey() +"'");
					
						   if(key.getValue().equals(map.get(map.keySet().toArray()[0]))) {
							   selected = " selected";
						   }
						   else {
							   selected = "";
						   }
						   
						  sb.append( selected + ">")
						    .append(key.getValue()+"</option>");
						  
						index++;
					}
				}
			}
			
			else { // 일반 셀렉트 박스
		
				while(codeListToken.hasMoreTokens()) {
						token = codeListToken.nextToken();
						code = token.split(CommonConstants.COLONE);
						
						if(value == null && index == 0 || code[0].equals(value)) {
							selected = "selected= selected";
						}else {
							selected = "";
						}
	
						sb.append(" <option value='"+code[0]+"'")
						  .append(selected+">")
						  .append(code[1]+"</option>");
						
						index++;
						
				}
			}
			
			sb.append("</select>"); 
	
			
			JspWriter out = getJspContext().getOut(); 
			out.print(sb.toString());
		}
		
		super.doTag();
	}
	
}
