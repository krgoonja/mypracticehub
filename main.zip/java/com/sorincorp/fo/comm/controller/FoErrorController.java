package com.sorincorp.fo.comm.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpStatus;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class FoErrorController implements ErrorController{
	
	@RequestMapping("/error")
	public String handleError(HttpServletRequest request) {
		Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
		if (null!=status) {
			int statusCode = Integer.valueOf(status.toString());
			switch(statusCode) {
				case HttpStatus.SC_NOT_FOUND:
					return "error/404";
				case HttpStatus.SC_BAD_REQUEST:		// 22-12-13 변경사항 : 400 error에 대응하는 에러 페이지 추가
					return "error/400";
			}
		}
		return "error/503";
	}
	
	
	@Override
	public String getErrorPath() {
		// TODO Auto-generated method stub
		log.debug("getErrorPath");
		return null;
	}
	
	

}
