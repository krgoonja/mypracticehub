// -----------------------------------------------------------------------------
// rMate Chart H5 License Key 
// Product Name : rMate Chart for HTML5 v6.0
// License Type : Enterprise Trial license
// Product No : FCF6-6B15-4B84-55FW
// Authenticated server Info : the number of server= 1,  Access Domain= www.kztraders.com, adm.kztraders.com
// Expiration date : 2023/12/31
var rMateChartH5License = "";
if(document.domain == "10.202.0.6" || document.domain == "stb.kztraders.com" || document.domain == "st.kztraders.com" || document.domain == "stm.kztraders.com") {
    rMateChartH5License = "9e2a1ca1391eedea2e8e47a738b07b0f0b8e203eff4623ddc754652c2929c980:3700640b6248443a4f4220504c20565a3a4532382e31302d2037504456443a32432d35422d4445374e302d2d36432e4330422d43453a564c41204c312033452f4c313a30742f203543323a303232303a32453420312a303a334831";
} else {
    rMateChartH5License = "89734d7f3b1f76987ed820786f8ef4ae434a2a7d29d86ce29ba2c68d9713ef85:6200310b35434646363a2d4c3620422a313a35452d20346d426f3863342e2d73357235654664576120725074427a3a6b482e446d4f6420614c2c566d3a6f32632e2e30732072506556643a61437235742d7a456b4e2c2d6d366f2e63302e207345724c653a646661207243743a7a326b302e327734773077383a314832";
}
// -----------------------------------------------------------------------------
