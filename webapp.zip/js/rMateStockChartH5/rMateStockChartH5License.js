
// -----------------------------------------------------------------------------
// rMate Stock Chart for HTML5 License Key 
//
// Product Name : rMate Stock Chart for HTML5 v2.0
// License Type : Enterprise License
// Customer : �������(E-commerce �ý��� �� Trading �ý���)
// Product No :E6E9-5CC1-0096-A25R
// Authenticated server Info : the number of server= 1,  Access Domain= www.kztraders.com, adm.kztraders.com
// Expiration date : unlimited
//
var rMateStockChartH5License = '';

// 스테이징 라이센스 기한 2024/12/31
if(document.domain =="sorinfo-staging.azurewebsites.net" || document.domain == "10.202.0.6" || document.domain == "stb.kztraders.com" || document.domain == "st.kztraders.com" || document.domain == "stm.kztraders.com") {
	rMateStockChartH5License = "dee8b55617503295a46d6d57024c7daa722ddc9f23c933f64e0c6e1b686632bc:6300640b313a484244504f20205a4c4256413a38322d2e31304120425030562d3a31534443432d39322d2e4530382d374533563a414c4c20203145334c2f3a327431202f43343a3232303032323a34453020362a313a3848";
} else {
	rMateStockChartH5License = "f91baac556bb41b82850aa67c87e8e616197a55ac66cc98487285d7195629d6d:3900340b3045423a454c31202d2a353a39453420306d2d6f3063372e367338722d653764426145723574207a506b422e3a6d486444614f2c206d4c6f56633a2e32732e7230652064506156723a74537a436b2d2c326d2e6f3063202e45734c723a656664206143723a74327a306b322e347730773877313a3248";
}
//-------------------------------------------------------------------------------