'use strict';

var fxProps;

$(function() {
    //차트 유형 클릭 이벤트
    $("#fxChart_type > ul > li").click(function (e) {
        var txt = e.currentTarget.innerText;
        $("#fxChart_type > ul > li").removeClass("selected");
        $(e.currentTarget).addClass("selected");
        var chartType = "";

        //hloc, line, bar, hloc , baseLine
        if (txt.indexOf("캔들차트") >= 0) {
            chartType = "hloc";
        } else if (txt.indexOf("바차트") >= 0) {
            chartType = "bar";
        } else if (txt.indexOf("종가선차트") >= 0) {
            chartType = "line";
        } else if (txt.indexOf("삼선전환") >= 0) {
            chartType = "lineBreak";
        } else if (txt.indexOf("P&F") >= 0) {
            chartType = "pnf";
        } else if (txt.indexOf("BaseLine") >= 0) {
            chartType = "baseLine";
        } else if (txt.indexOf("BaseArea") >= 0) {
            chartType = "baseArea";
        } else if (txt.indexOf("Area") >= 0) {
            chartType = "area";
        } else {
            chartType = "hloc";
        }

        rMateStock.setChartType("fxChart", chartType);
    });

    // 확대 클릭 핸들러
    $("#fxZoomInBtn").click(function () {
        rMateStock.zoomIn("fxChart");
    });

    // 축소 클릭 핸들러
    $("#fxZoomOutBtn").click(function () {
        rMateStock.zoomOut("fxChart");
    });
});

function fxCreateProps(movingAvgLine) {
    fxProps = {
            sideChart: {
                common: {
                    gutterRight: 65,
                    titleStyle: {
                        bgColor: "#cccccc",
                        stroke: {
                            "color": "#aaaaaa",
                            "weight": 1
                        },
                        fontSize: 11,
                        fontWeight: "normal",
                        fontFamily: "Noto Sans regular",
                        fontStyle: "normal",
                        color: "#666"
                    },
                    labelStyle: {
                        fontSize: 11,
                        color: "#666",
                        fontFamily: "Noto Sans regular",
                        fontWeight: "normal",
                        fontStyle: "normal"
                    }
                },
                volumeChart: {
                    show: false
                }
            },
            scrollNavi: {
                visibleItemSize: 150,
                maxVisibleItemSize: 2400,
            },
            overlay: {
                movingAvgLine: {
                    show: movingAvgLine
                },
            },
            mainChart: {
                dataTipMode: "titleDepth", //툴팁 모드
                legendY: -25,
                legendX: 20,
                recentSizeLeft: 0,
                showRecentTip: true,
                recentTipColor: "#073763",
                recentTipDashed: {
                    dashed: true,
                    dashLength: 2
                },
                titleStyle: {
                    color: "rgba(255,255,255,0)"
                },
                pnfValue: 500,
                gutterRight: 65,
                mainSeries: {
                    baseValue: 4548000,
                    lineChartStroke: {
                        "color": "#ff0000",
                        "weight": 1
                    },
                    declineStroke: {
                        "color": "#2548fb",
                        "weight": 1
                    },
                    raiseFill: "#ff0000",
                    fallFill: "#2548fb",
                },
                crossHairStroke: {
                    "color": "#939393",
                    "weight": 1
                },
                baseLineStroke: {
                    color: "#E2E2E2",
                    weight: 1
                },
                labelStyle: {
                    fontSize: 12,
                    color: "#666666",
                    fontFamily: "Noto Sans regular",
                    fontWeight: "normal",
                    fontStyle: "normal"
                },
                dataTipFormatter: {
                    "useThousandsSeparator": true,
                    "useNegativeSign": true,
                    "precision": 2,
                    "thousandsSeparatorTo": ",",
                    "decimalSeparatorTo": ".",
                    "rounding": "none"
                },
				formatter: {
					"precision": 2,
					"rounding":"nearest",
				},
				vAxisTipFormatter: {
					"precision": 2,
					"rounding":"nearest",
				},
                gridStroke: {
                    "color": "#eeeeee",
                    "weight": 1
                },
                gridBoxStroke: {
                    "color": "#eeeeee",
                    "weight": 1
                },
            },
            callback: {
                getLegendData: function (id, title, names, colors, prefixTag, suffixTag) {
                    var len = Math.min(names.length, colors.length);
                    if (isNull(prefixTag))
                        prefixTag = "";
                    if (isNull(suffixTag))
                        suffixTag = "";
                    var str = prefixTag;

                    str += '<span class="legend_main noto">' + '<span class="legend_title">' + title + '</span>';

                    for (var i = 0; i < len; i++) {
                        str += '<span class="legend_marker" style="background-color:' + colors[i].color + ';" ></span>';
                        str += '<span class="legend_name" style="color:' + colors[i].color + ';">' + names[i] + '</span>';
                    }
                    str += '</span>';
                    str += suffixTag;
                    return str;
                },
                overlayAddedEventHandler: function (uid, name) {
                    $("input[name=" + name + "]").prop("checked", true);
                },
                overlayRemovedEventHandler: function (uid, name) {
                    $("input[name=" + name + "]").prop("checked", false);
                },
                sideChartAddedEventHandler: function (uid, name) {
                    //trace("sideChartAddedEventHandler");
                    $("input[name=" + name + "]").prop("checked", true);
                },
                sideChartRemovedEventHandler: function (uid, name) {
                    //trace("sideChartRemovedEventHandler");
                    $("input[name=" + name + "]").prop("checked", false);
                },
                itemOverChangeHandler: function (uid, item, focusFieldName, focusDisplayName) {
                    var str = dateFormat(item.Date);
                    str += "&nbsp;&nbsp;&nbsp;<b>시가:</b> " + commafy(item.Open);
                    str += "&nbsp;&nbsp;&nbsp;<b>고가:</b> " + commafy(item.High);
                    str += "&nbsp;&nbsp;&nbsp;<b>저가:</b> " + commafy(item.Low);
                    str += "&nbsp;&nbsp;&nbsp;<b>종가:</b> " + commafy(item.Close) + "&nbsp;&nbsp;&nbsp;";

                    if (item.Change > 0) {
                        str += "<span class=\"raise\"> ▲" + commafy(item.Change.toFixed(2)) + "<span style=\"margin-left:10px;\"></span> " + item.Rate.toFixed(2) + "%</span>";
                    } else {
                        str += "<span class=\"fall\"> ▼" + commafy(item.Change.toFixed(2)) + "<span style=\"margin-left:10px;\"></span> " + item.Rate.toFixed(2) + "%</span>";
                    }
                    if (focusFieldName && focusFieldName != "")
                        str += ", (" + focusDisplayName + ": " + commafy(item[focusFieldName]) + ")";

                    str += "&nbsp;&nbsp;&nbsp;<b>거래량:</b> " + commafy(item.Volume);

                    document.getElementById("chart_info").innerHTML = "<div class='noto item_over'>" + str + "</div>";
                },
                dataTipFunction: function (id, item, fieldName, displayName) {
                    var precision = 100;
                    var tipText = "날짜 : " + dateFormat(item.Date) + "<br>";
                    var value;
                    var timeFrame = rMateStock.getTimeFrame("fxChart");
                    if (timeFrame == "minute") {
                        tipText += "시간 : " + dateFormat(item.Date, "H:i") + "<br>";
                    }

                    if (isNull(fieldName) || isNull(displayName)) {
                        for (var p in item) {
                            if (p == "Date")
                                continue;
                            value = item[p];
                            if (!isNaN2(value)) {
                                value = fxFormatter((value * precision) / precision);
                                value = (Number(value.replaceAll(",", "")).toFixed(2)).toLocaleString(); // 소수점 제거
                                if (!isNull(rMateStock.dataKeyMap[p])) {
                                    if (p == "High") {
                                        tipText += '<span style="width:80px; color:#ff0000">' + rMateStock.dataKeyMap[p] + " : " + value + "</span><br>";
                                    } else if (p == "Low") {
                                        tipText += '<span style="width:80px; color:#0000ff">' + rMateStock.dataKeyMap[p] + " : " + value + "</span><br>";
                                    } else if (p == "Close") {
                                        if (item["Change"] > 0) {
                                            tipText += '<span style="width:80px; color:#ff0000">' + rMateStock.dataKeyMap[p] + " : " + value + " (" + item["Rate"].toFixed(2) + "%)</span><br>";
                                        } else if (item["Change"] <= 0) {
                                            tipText += '<span style="width:80px; color:#0000ff">' + rMateStock.dataKeyMap[p] + " : " + value + " (" + item["Rate"].toFixed(2) + "%)</span><br>";
                                        }
                                    } else if (p == "Volume") {
                                        continue;
                                    } else {
                                        tipText += '<span style="width:80px;">' + rMateStock.dataKeyMap[p] + " : " + value + "</span><br>";
                                    }
                                }
                            }
                        }
                    } else {
                        var tipValue = item[fieldName];
                        tipValue = fxFormatter((tipValue * precision) / precision);
                        tipText += displayName + " : " + tipValue;
                    }

                    return tipText;
                },
            } // end of callback
        };

    return fxProps;
};

function fxFormatter(value) {
    var t = $(this);
    t.useThousandsSeparator = true;
    t.useNegativeSign = true;
    t.precision = 2;
    t.thousandsSeparatorTo = ",";
    t.decimalSeparatorTo = ".";
    t.rounding = "none";
    t.returnValueWhenError = false;

    var n = parseFloat(value),
        c = t.precision == -1 ? 0 : Math.abs(t.precision),
        d = t.decimalSeparatorTo,
        s = t.useThousandsSeparator ? t.thousandsSeparatorTo : "";



    n = t.rounding == "down" ? t.precision > -1 && c > 0 ? Math.floor(n * Math.pow(10, c)) / Math.pow(10, c) : Math.floor(n) :
        (t.rounding == "up" ? t.precision > -1 && c > 0 ? Math.ceil(n * Math.pow(10, c)) / Math.pow(10, c) : Math.ceil(n) :
            (t.rounding == "nearest" ? t.precision > -1 && c > 0 ? Math.round(n * Math.pow(10, c)) / Math.pow(10, c) : Math.round(n) : n));

    var sign = (n < 0) ? (t.useNegativeSign ? '-' : '(') : "",
        //extracting the absolute value of the integer part of the number and converting to string
        i = parseInt(n = t.precision > -1 ? Math.abs(n).toFixed(c + 1) : Math.abs(n)) + '';

    var j = i.length;
    j = ((j) > 3) ? j % 3 : 0;
    var f = n - i,
        ff = "";

    t.error = undefined;

    if (isNaN(f)) {
        t.error = "invalid number";
        if (t.returnValueWhenError)
            return value;
        else
            return "";
    }

    if (f > 0)
        ff = d + n.toString().slice(i.toString().length + 1);
    else if (c > 0)
        ff = d + f.toFixed(c + 1).slice(2);

    return sign + (j ? i.substr(0, j) + s : '') +
        i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + s) +
        (t.precision > -1 ? c ? ff.substr(0, c + d.length) : "" : ff) +
        (sign == "(" ? ")" : "");
};

function isNull(obj) {
	return obj == null || typeof obj === "undefined" || obj === "undefined";
}












//차트 시간 기준 변경
function fxChartTime(type) {
	fxChartObj.type = type;
    setNewFxData(); //차트 호출
}

/**
 * rMate 주식차트를 최초 생성합니다.
 */
function rMateStockInitFxCreate() {
	let metalCode = sorin.chart.metalCode;    
//실시간 소켓 연결
    fxChartObj.type = "1minute";

    let type = fxChartObj.type;

	// FX 초기 가격 정보 데이터 가져오기 (실시간 FX 가격 정보 가져오기 전)
	fxRequestAjax(type, metalCode, "Y", function (data) {
		let result = data.result;
		
		if(!sorin.validation.isEmpty(result)) {
			fxChartObj.currentFxPrice = Number(result.endPc); // FX endPc
			fxChartObj.fxVersusPc = Number(result.versusPc); // FX 대비 가격
			fxChartObj.fxVersusRate = Number(result.versusRate); // FX 대비율
			fxChartObj.ehgtPcRltmSn = result.ehgtPcRltmSn; // FX 실시간 순번
			
			// FX 가격 정보 적용 함수 호출
			fnSettingFxPrice();
		}
	});
    
    //차트 데이터 시작
    rMateStock.showPreloader("fxChart", "fxChartHolder");

    fxRequestAjax(type, metalCode, "N", function(data) {
        let result = data.result;
        
        let chartData = [];
        // 값이 없을경우 차트를 그리지 않음
        if(!sorin.validation.isEmpty(result)) {
            for(let i = 0; i < result.length; i++) {
				
				if(i == 0) {
					let sqlChartFxTime = date_to_str_fx_realTime(new Date(result[i].chartFxTime));
 					let resultFxCurrentData = fxChartObj.currentFxList;
					let currentFxTime;
					
					if(resultFxCurrentData.currentFxTime != undefined) {
						currentFxTime = date_to_str_fx_realTime(new Date(resultFxCurrentData.chartFxTime));
					}
					
					if(new Date(sqlChartFxTime).getTime() < new Date(currentFxTime).getTime()) {
						chartData.push(currentFxTime + "|" + resultFxCurrentData.beginPc + "|" + resultFxCurrentData.topPc + "|" + resultFxCurrentData.lwetPc + "|" + resultFxCurrentData.endPc + "|0");
// 						console.log("1. 실시간 마지막 봉(SQL보다 나중시간 추가 시고저종) \t", currentFxTime + "\t" + resultFxCurrentData.beginPc + "\t" + resultFxCurrentData.topPc + "\t" + resultFxCurrentData.lwetPc + "\t" + resultFxCurrentData.endPc + "\t" + resultFxCurrentData.delngQy + "\t");
						checkFxPriceData("sqlData", resultFxCurrentData, currentFxTime, type);
					} else {
// 						console.log("1. SQL 마지막 봉(시고저종) \t", sqlChartFxTime + "\t" + result[i].beginPc + "\t" + result[i].topPc + "\t" + result[i].lwetPc + "\t" + result[i].endPc + "\t" + result[i].delngQy + "\t");
						checkFxPriceData("sqlData", result[i], sqlChartFxTime, type);
					}
                }
                
				chartData.push(""+sorin.chart.date_to_str(new Date(result[i].chartFxTime))+"|"+result[i].beginPc+"|"+result[i].topPc+"|"+result[i].lwetPc+"|"+result[i].endPc+"|0");
            }
        }
        // 증권 차트 속성 설정
        let movingAvgLine = true;
        
        fxCreateProps(movingAvgLine); 

        // rMate 증권 차트를 생성합니다.
        // 파라메터 설명 (순서대로)
        // 1. 차트의 id (임의로 지정하십시오. 단, 중복불가)
        // 2. 차트가 위치할 div 의 id (즉, 차트의 부모 div 의 id 입니다.)
        // 3. 차트의 상세 속성 설정 Object ( 현재는 디폴트로 출력하겠다는 의미임 )
        // 4. 차트의 데이터
        if($("#fxChart").length > 0) {
        	rMateStock.destroy("fxChart");
        }
        
        rMateStock.create("fxChart", "fxChartHolder", fxProps, chartData.reverse());
        //rMateStock.setPropertys("fxChart", fxProps, true);

        //rMateStock.setHorizontalAxisInterval("fxChart", 5); // x축 차트 간격 조정
        rMateStock.removePreloader("fxChart"); // 프리로더 제거
        
        //금속 코드 구분
        rMateStock.setTimeFrame("fxChart", "minute");

        rMateStock.setChartType("fxChart", "hloc");

		rMateStock.zoomIn("fxChart");
		
		newFxChartComplateYn = true;
    });
    //차트생성 완료 후 화면 노출
    $(".rcharts-wrap.nodata").hide().siblings().show();
}

//차트 화면 변경
function setNewFxData() {
	//차트타입변경시 완료Flag 초기화
	newFxChartComplateYn = false;
	
	let metalCode = sorin.chart.metalCode;
	let type = fxChartObj.type;

	// FX 초기 가격 정보 데이터 가져오기 (실시간 FX 가격 정보 가져오기 전)
	fxRequestAjax(type, metalCode, "Y", function (data) {
		let result = data.result;
		
		if(!sorin.validation.isEmpty(result)) {
			fxChartObj.currentFxPrice = Number(result.endPc); // FX endPc
			fxChartObj.fxVersusPc = Number(result.versusPc); // FX 대비 가격
			fxChartObj.fxVersusRate = Number(result.versusRate); // FX 대비율
			fxChartObj.ehgtPcRltmSn = result.ehgtPcRltmSn; // FX 실시간 순번
			
			// FX 가격 정보 적용 함수 호출
			fnSettingFxPrice();
		}
	});

    rMateStock.showPreloader("fxChart"); // 요청 중 지연을 위해 프리로더 표시

    fxRequestAjax(type, metalCode, "N", function (data) { // Ajax 요청해서 데이터 갱신
        let result = data.result;
        let chartData = [];

        rMateStock.setData("fxChart", chartData);	// 차트 초기화

        // 값이 없을경우 차트를 그리지 않음
        if (!sorin.validation.isEmpty(result)) {
            for(let i = 0; i < result.length; i++) {
                
				if(i == 0) {
					let sqlChartFxTime = date_to_str_fx_realTime(new Date(result[i].chartFxTime));
 					let resultFxCurrentData = fxChartObj.currentFxList;
					let currentFxTime;
					
					if(resultFxCurrentData.currentFxTime != undefined) {
						currentFxTime = date_to_str_fx_realTime(new Date(resultFxCurrentData.chartFxTime));
					}
					
					if(new Date(sqlChartFxTime).getTime() < new Date(currentFxTime).getTime()) {
						chartData.push(currentFxTime + "|" + resultFxCurrentData.beginPc + "|" + resultFxCurrentData.topPc + "|" + resultFxCurrentData.lwetPc + "|" + resultFxCurrentData.endPc + "|0");
// 						console.log("1. 실시간 마지막 봉(SQL보다 나중시간 추가 시고저종) \t", currentFxTime + "\t" + resultFxCurrentData.beginPc + "\t" + resultFxCurrentData.topPc + "\t" + resultFxCurrentData.lwetPc + "\t" + resultFxCurrentData.endPc + "\t" + resultFxCurrentData.delngQy + "\t");
						checkFxPriceData("sqlData", resultFxCurrentData, currentFxTime, type);
					} else {
// 						console.log("1. SQL 마지막 봉(시고저종) \t", sqlChartFxTime + "\t" + result[i].beginPc + "\t" + result[i].topPc + "\t" + result[i].lwetPc + "\t" + result[i].endPc + "\t" + result[i].delngQy + "\t");
						checkFxPriceData("sqlData", result[i], sqlChartFxTime, type);
					}
                }

                chartData.push(""+sorin.chart.date_to_str(new Date(result[i].chartFxTime))+"|"+result[i].beginPc+"|"+result[i].topPc+"|"+result[i].lwetPc+"|"+result[i].endPc+"|0");

                let chartData1 = chartData[0].split("|");

                //차트별 이동평균선 그리기
                let movingAvgLineType = true;

                fxProps.mainChart.mainSeries.baseValue = chartData1[4];
                fxProps.overlay.movingAvgLine.show = movingAvgLineType;
            }
        }

        rMateStock.setPropertys("fxChart", fxProps, true);
        
		switch (type) {
			case "1minute":
					rMateStock.setTimeFrame("fxChart", "minute"); // 일봉인지, 주봉인지, 월봉인지 알림
					rMateStock.setChartType("fxChart", "hloc");
					//rMateStock.setHorizontalAxisInterval("fxChart", 5); // x축 차트 간격 조정
				break;
					
			case "30minute":
					rMateStock.setTimeFrame("fxChart", "minute"); // 일봉인지, 주봉인지, 월봉인지 알림
					rMateStock.setChartType("fxChart", "hloc");
					//rMateStock.setHorizontalAxisInterval("fxChart", 1); // x축 차트 간격 조정
				break;
					
			case "60minute":
					rMateStock.setTimeFrame("fxChart", "minute"); // 일봉인지, 주봉인지, 월봉인지 알림
					rMateStock.setChartType("fxChart", "hloc");
					//rMateStock.setHorizontalAxisInterval("fxChart", 1); // x축 차트 간격 조정
				break;
					
			case "day":
					rMateStock.setTimeFrame("fxChart", "day"); // 일봉인지, 주봉인지, 월봉인지 알림
					rMateStock.setChartType("fxChart", "hloc");
				break;
					
			case "month":
					rMateStock.setTimeFrame("fxChart", "month"); // 일봉인지, 주봉인지, 월봉인지 알림
					rMateStock.setChartType("fxChart", "hloc");
					//rMateStock.setHorizontalAxisInterval("fxChart", 1); // x축 차트 간격 조정
				break;

			default:
					rMateStock.setTimeFrame("fxChart", "minute"); // 일봉인지, 주봉인지, 월봉인지 알림
					rMateStock.setChartType("fxChart", "hloc");
				break;
		}
		
		rMateStock.setData("fxChart", chartData.reverse());
		rMateStock.removePreloader("fxChart");  // 프리로더 제거
		rMateStock.redraw("fxChart"); 
		rMateStock.zoomIn("fxChart");
		
		newFxChartComplateYn = true;
	});
}

/**
 * Ajax 요청하는 대표 함수입니다.
 * succesFunc : 성공 시 처리할 핸들러
 *
 * initAt : 초기 호출 여부 (Y, N)
 */
function fxRequestAjax(type, metalCode, initAt, succesFunc) {
    // url 분기
    let url = "/chart/pcMngtrngFxList"; // 시간별 환율 차트 데이터 가져오기
	if(initAt == "Y") {
		url = "/chart/pcMngtrngFxInitInfo"; // 환율 초기 가격 정보 데이터 가져오기 (실시간 환율 가격 정보 가져오기 전)
	}

    let data = {
        chartCount: 1000,
        type: type,
		metalCode: metalCode,
		ehgtPcRltmSn: fxChartObj.searchEhgtPcRltmSn,
    };
	
	sorin.ajax.customErrorCallback("post", url, JSON.stringify(data), "json", "application/json", true, succesFunc, function () {
		rMateStock.removePreloader("fxChart");
	});
}

//차트 자동 리사이즈
$(window).off('resize').on('resize', function () {
    if ($("#rCharts").length > 0) {
        rMateStock.redraw("fxChart");
    }
});