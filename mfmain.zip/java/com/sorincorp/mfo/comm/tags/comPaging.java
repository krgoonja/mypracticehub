package com.sorincorp.mfo.comm.tags;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@RequiredArgsConstructor
@Component
public class comPaging extends SimpleTagSupport{
	
	private int pageIndex; // 현재 페이지 번호
	private int pageSize; // 보여줄 최대 페이지
	private int rowCountPerPage; // 한 페이지에 게시될 최대 게시물 건 수
	private int totalRowCount; // 전체 게시물 건 수
	
	private String clickEvent; // javacript function name

	private String firstTagClass; // 첫 페이지 Class Tag 값
	private String prevTagClass; // 이전 페이지 Class Tag 값
	private String nextTagClass; // 다음 페이지 Class Tag 값
	private String lastTagClass; // 마지막 페이지 Class Tag 값
	private String tagClass; // 페이지 Class Tag 값
	
	//UserInfoUtil userInfoUtil;
	
	@Override
	public void doTag() throws JspException, IOException {
		
		int remainder = 0;
		if((totalRowCount % rowCountPerPage) > 0) {
			remainder = 1;
		}
		
		int totalPage = (totalRowCount / rowCountPerPage) + remainder;
		int showFirstPage = pageIndex / pageSize;
		
		if((pageIndex % pageSize) == 0) {
			showFirstPage = (pageIndex / pageSize) - 1;
		}
		
		if(showFirstPage < 1) { 
			showFirstPage = 1;
		} else {
			showFirstPage = (showFirstPage * pageSize) + 1;
		}
		
		int showLastPage = showFirstPage + (pageSize - 1);
		
		if(totalPage <= pageSize) {
			showLastPage = totalPage;
		} 
		
		if(totalPage < showLastPage) {
			showLastPage = totalPage;
		}
		
		int prevIndex = pageIndex - 1;
		int nextIndex = pageIndex + 1;
		
		if(prevIndex < 1) {
			prevIndex = 1;
		}
		
		if(nextIndex >= totalPage) {
			nextIndex = totalPage;
		}
		
		StringBuffer sb = new StringBuffer();
		sb.append("<a href='javascript:;' class='")
			.append(firstTagClass)
			.append("' aria-label='첫 페이지' onclick='")
			.append("javascript:;" + clickEvent + "(1," + pageSize + "," + rowCountPerPage + "," + totalRowCount + ")")
			.append("'></a>");
		sb.append("<a href='javascript:;' class='")
			.append(prevTagClass)
			.append("' aria-label='이전 페이지' onclick='")
			.append("javascript:;" + clickEvent + "(" + prevIndex + "," + pageSize + "," + rowCountPerPage + "," + totalRowCount + ")")
			.append("'></a>");
		
		for(int i=showFirstPage; i<=showLastPage; i++) {
			if(pageIndex == i) {
				sb.append("<strong aria-label='현재 페이지'>")
					.append(i)
					.append("</strong>");
			} else {
				sb.append("<a href='javascript:;' class='")
					.append(tagClass)
					.append("' onclick='")
					.append("javascript:;" + clickEvent + "(" + i + "," + pageSize + "," + rowCountPerPage + "," + totalRowCount + ")")
					.append("'>")
					.append(i)
					.append("</a>");
			}
		}
		
		sb.append("<a href='javascript:;' class='")
			.append(nextTagClass)
			.append("' aria-label='다음 페이지' onclick='")
			.append("javascript:;" + clickEvent + "(" + nextIndex + "," + pageSize + "," + rowCountPerPage + "," + totalRowCount + ")")
			.append("'></a>");
		sb.append("<a href='javascript:;' class='")
			.append(lastTagClass)
			.append("' aria-label='마지막 페이지' onclick='")
			.append("javascript:;" + clickEvent + "(" + totalPage + "," + pageSize + "," + rowCountPerPage + "," + totalRowCount + ")")
			.append("'></a>");

		JspWriter out = getJspContext().getOut();
		out.print(sb.toString());
		
		super.doTag();
	}

	
}