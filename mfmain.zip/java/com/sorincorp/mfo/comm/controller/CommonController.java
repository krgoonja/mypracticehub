package com.sorincorp.mfo.comm.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.mfo.config.UserInfoUtil;
import com.sorincorp.mfo.login.model.Account;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class CommonController {

	@Autowired
	UserInfoUtil userInfoUtil;

	@Autowired
	CommonCodeService commonCodeService;

	@Autowired
	FileDocService fileDocService;

	/**
	 * <pre>
	 * 처리내용: 공통코드 메인코드를 조회한다
	 * </pre>
	 * @date 2021. 8. 5.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 5.			srec0041			최초작성
	 * ------------------------------------------------
	 * @return 공통코드 map
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/Common/getMainCodes")
	public Map<String, String> getMainCodes() throws Exception {
		return commonCodeService.getMainCodes();
	}

	/**
	 * <pre>
	 * 처리내용: 공통코드 서브코드를 조회한다
	 * </pre>
	 * @date 2021. 8. 5.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 5.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @return 공통코드 서브 map
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/Common/getSubCodes")
	public Map<String, String> getSubCodes(String mainCode) throws Exception {
		return commonCodeService.getSubCodes(mainCode);
	}

	/**
	 * <pre>
	 * 처리내용: 공통코드 값을 조회한다
	 * </pre>
	 * @date 2021. 8. 5.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 5.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @param subCode
	 * @return 공통코드 값
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/Common/getCodeValue")
	public String getCodeValue(String mainCode, String subCode) throws Exception {
		return commonCodeService.getCodeValue(mainCode, subCode);
	}

	/**
	 * <pre>
	 * Redis에 있는 공통코드 목록 중 해당 조건으로 Filtering해서 반환한다
	 * mainCode 는 필수값 *
	 * </pre>
	 * @date 2022. 9. 2.
	 * @author srec0051
	 * @param mainCode
	 * @param subCode
	 * @param columKey
	 * @param columnValue
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/Common/getFilterCode")
	public Map<String, String> getFilterCode(String mainCode, String subCode, String columKey, String columnValue) throws Exception {
		return commonCodeService.getFilterCode(mainCode, subCode, columKey, columnValue);
	}

	/**
	 * <pre>
	 * 공통코드 서브코드를 CommonCodeVO 반환으로 변경한 메소드
	 * </pre>
	 * @date 2022. 9. 2.
	 * @author srec0051
	 * @param mainCode
	 * @param subCode
	 * @return
	 * @throws Exception
	 */
	@ResponseBody
	@PostMapping("/Common/getSubCodesRetVo")
	public Map<String, CommonCodeVO> getSubCodesRetVo(String mainCode, String subCode) throws Exception {
		return commonCodeService.getSubCodesRetVo(mainCode, subCode);
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 로그인한 회원정보를 가져온다.
	 * </pre>
	 * @date 2021. 9. 7.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @return
	 */
	@ResponseBody
	@PostMapping("/Common/getUserInfo")
	public Account getUserInfo(HttpServletRequest request) {
		return userInfoUtil.getAccountInfo(request);
	}

	/**
	 *
	 * <pre>
	 * 처리내용: BlobStorage에 있는 파알를 다운로드 한다.
	 * </pre>
	 * @date 2021. 9. 3.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 3.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping("/Common/commonDownLoad")
	public void commonDownLoad(FileDocVO vo, HttpServletRequest request, HttpServletResponse response) throws Exception {
		fileDocService.fileDocDownload(request, response, vo);
//		System.out.println(vo.toString());
//		System.out.println(vo.getDocFileRealCours());
	}

}
