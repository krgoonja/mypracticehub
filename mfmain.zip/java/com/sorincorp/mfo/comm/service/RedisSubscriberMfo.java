package com.sorincorp.mfo.comm.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.redis.config.RedisPubSubMessage;
import com.sorincorp.mfo.my.model.MyHopePcAlarmVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@RequiredArgsConstructor
@Service
public class RedisSubscriberMfo implements MessageListener {	// RedisPubSubListener<String, Object>

	@Autowired
	private SimpMessagingTemplate simpMessagingTemplate;

	@Value("${redisPubsub.uri.fx}")
	private String fxpcUri;

	@Value("${redisPubsub.uri.wishAlram}")
	private String wishAlramUri;

	@Value("${redisPubsub.crncyCode.KRW}")
	private String fxpcKRW;

	@Value("${redisPubsub.uri.restTime}")
	private String restTimeUri;

	@Value("${redisPubsub.uri.startLmeData}")
	private String startLmeDataUri;

	@Value("${redisPubsub.uri.spread}")
	private String spreadUri;

	@Value("${redisPubsub.uri.sel}")
	private String selPcUri;

	@Value("${redisPubsub.uri.invntry}")
	private String invntryUri;
	
	@Value("${redisPubsub.uri.selpcAll}")
	private String selpcAll;
	
	@Value("${redisPubsub.uri.lme}")
	private String lmePcUri;

	@SuppressWarnings("unchecked")
	@Override
	public void onMessage(Message message, byte[] pattern) {
		// TODO Auto-generated method stub
		//log.debug("FO :"+message);
		byte[] messageBody = message.getBody();
		ByteArrayInputStream in = new ByteArrayInputStream(messageBody);
		//ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ObjectInputStream is =null;
		RedisPubSubMessage pubSubMsg = null;
		try {
			is = new ObjectInputStream(in);
			pubSubMsg = (RedisPubSubMessage) is.readObject();
			//log.debug("getChannelId() :"+pubSubMsg.getChannelId());
			String channel = pubSubMsg.getChannelId();

			if(channel.equals(fxpcUri + "/" + fxpcKRW)) {
				Map<String, String> map = new HashedMap<>();
				map = objMapper.readValue(pubSubMsg.getMessage().toString(), Map.class);
				simpMessagingTemplate.convertAndSend(fxpcUri + "/" + fxpcKRW, map);

			} else if(channel.equals(wishAlramUri)) {
				List<MyHopePcAlarmVO> hopeAlramVoList = new ArrayList<>();
				hopeAlramVoList = objMapper.readValue(pubSubMsg.getMessage().toString(), new TypeReference<List<MyHopePcAlarmVO>>(){});
				for(int i = 0; i < hopeAlramVoList.size(); i++) {
					///wishAlram/{회원번호}
//					String msgId = wishAlramUri + "/" + hopeAlramVoList.get(i).getMetalCode() + "/" + hopeAlramVoList.get(i).getItmSn()
//							          + "/" + hopeAlramVoList.get(i).getDstrctLclsfCode() + "/" + hopeAlramVoList.get(i).getBrandGroupCode()
//							          + "/" + hopeAlramVoList.get(i).getBrandCode() + "/" + hopeAlramVoList.get(i).getEntrpsNo();

					String msgId = wishAlramUri + "/" + hopeAlramVoList.get(i).getMberNo();
					simpMessagingTemplate.convertAndSend(msgId , hopeAlramVoList.get(i));
				}

			} else if(channel.equals(restTimeUri)) {
				if("setRestTime".equals(pubSubMsg.getMessage().toString())){
					simpMessagingTemplate.convertAndSend(channel , pubSubMsg.getMessage().toString());
				}
			} else if(channel.equals(startLmeDataUri)) {
				if(pubSubMsg.getMessage().toString().contains("startLmeData")){
					simpMessagingTemplate.convertAndSend(channel , pubSubMsg.getMessage().toString());
				}
			} else if(channel.equals(spreadUri)) {
				if("notMatchedSpread".equals(pubSubMsg.getMessage().toString())){
					simpMessagingTemplate.convertAndSend(channel , pubSubMsg.getMessage().toString());
				}
			} else if(channel.contains(selPcUri)) {
				if (channel.startsWith(selPcUri + "/")) {
				    simpMessagingTemplate.convertAndSend(channel , pubSubMsg.getMessage().toString());
				} else if(channel.contains(selpcAll)) {
					if (channel.startsWith(selpcAll + "/")) {
					    simpMessagingTemplate.convertAndSend(channel , pubSubMsg.getMessage().toString());
					}
				}
			}  else if(channel.contains(invntryUri)) {
				if(channel.startsWith(invntryUri + "/")) {
					simpMessagingTemplate.convertAndSend(channel, pubSubMsg.getMessage().toString());
				}
			} else if(channel.equals(lmePcUri)) {
				if (channel.startsWith(lmePcUri + "/")) {
					simpMessagingTemplate.convertAndSend(channel , pubSubMsg.getMessage().toString());
				}
			} else {
				simpMessagingTemplate.convertAndSend(channel, pubSubMsg.getMessage().toString());
			}


//			is = new ObjectInputStream(in);
//			pubSubMsg = (RedisPubSubMessage) is.readObject();
//			log.debug(pubSubMsg.toString());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.error(message.toString());
		}
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			log.error(message.toString());
		}
	}

}
