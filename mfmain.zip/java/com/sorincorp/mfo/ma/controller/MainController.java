package com.sorincorp.mfo.ma.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.sorincorp.mfo.ma.model.ClosingPcVO;
import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.bsnInfo.model.RltmEndTimeVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.sidecar.service.SidecarService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.mfo.chart.service.PcMntrngService;
import com.sorincorp.mfo.config.UserInfoUtil;
import com.sorincorp.mfo.login.model.Account;
import com.sorincorp.mfo.ma.model.EventHolidayVO;
import com.sorincorp.mfo.ma.model.MetalWorldVO;
import com.sorincorp.mfo.ma.model.NoticeVO;
import com.sorincorp.mfo.ma.service.MainService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class MainController {

	@Autowired
	MainService mainService;

	@Autowired
	UserInfoUtil userInfoUtil;

	@Autowired
	MessageUtil messageUtil;

	@Autowired
	PcMntrngService pcMntrngService;

	@Autowired
	BsnInfoService bsnInfoService;

	@Autowired
	SimpMessagingTemplate simpMessagingTemplate;

	@Autowired
	SidecarService sidecarSerivce;

	@Autowired
	private HttpClientHelper httpClientHelper;
	
	/**
	 * 올드도메인
	 */
	@Value("${spring.mfo.oldDomain}")
	private String MFO_OLDDOMAIN ;
	/**
	 * 올드도메인
	 */
	@Value("${spring.mfo.subDomain}")
	private String MFO_SUBDOMAIN ;
	
	/**
	 * <pre>
	 * 처리내용: 메인화면 정보를 조회한다.
	 * </pre>
	 * @date 2022. 10. 7.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 7.			srec0072			메탈월드 리스트 조회 추가
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/")
    public String main(Model model, HttpServletRequest request,@RequestHeader(value="Host") String host) {
		
		if(host.indexOf(MFO_OLDDOMAIN) > -1 || host.indexOf(MFO_SUBDOMAIN) > -1) {
			model.addAttribute("oldDomainAt", 'Y');
			return "my/svcChgInfo";
		}
		
		try {
		    Map<String,Object> loginStatusMap = new HashMap<String,Object>();
			Account account = userInfoUtil.getAccountInfo(request);

			if ( account == null) {
				loginStatusMap.put("loginYn","N");
			}else {
				loginStatusMap.put("loginYn","Y");
			}
			
			model.addAttribute("account", account);
			model.addAttribute("loginStatusMap", loginStatusMap); // 로그인 여부
			model.addAttribute("sidcar", sidecarSerivce.getSidecarOnList());
			model.addAttribute("noticeImage", mainService.selectMainPopupNoticeDocCourse());
		//	model.addAttribute("noticeLargeImage", mainService.selectMainLargePopup());
			if (account != null && account.getSecode().equals("05")) {
				model.addAttribute("seCode", account.getSecode());
				return "my/vhcleInfoRegistList";
			}
			
		} catch (Exception e) {
			log.error("[MainController][main]" + ExceptionUtils.getStackTrace(e));
		}
		
		return "ma/main";
	}

	@RequestMapping("/fsHttpHealthTest")
	public ResponseEntity<Object> fsHttpHealthTest() {
		try {
			Map<String, Object> resObj = httpClientHelper.getCallApi("http://10.207.0.10:28089/samsung/ftrs/health");

			if(resObj == null) {
				return new ResponseEntity<>("null", HttpStatus.BAD_REQUEST);
			}

			return new ResponseEntity<>(resObj, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping("/fxHttpHealthTest")
	public ResponseEntity<Object> fxHttpHealthTest() {
		try {
			Map<String, Object> resObj = httpClientHelper.getCallApi("http://10.202.0.10:28090/hanafx/fshg/health");

			if(resObj == null) {
				return new ResponseEntity<>("null", HttpStatus.BAD_REQUEST);
			}

			return new ResponseEntity<>(resObj, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping("/vaHttpHealthTest")
	public ResponseEntity<Object> vaHttpHealthTest() {
		try {
			Map<String, Object> resObj = httpClientHelper.postCallApi("http://10.202.0.10:28088/api/ewallet/money", "");

			if(resObj == null) {
				return new ResponseEntity<>("null", HttpStatus.BAD_REQUEST);
			}

			return new ResponseEntity<>(resObj, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping("/apiHttpHealthTest")
	public ResponseEntity<Object> apiHttpHealthTest(@Value("${order.api.lo.oms.url}") String apiLoUrl) {
		log.debug(">> apiLoUrl : " + apiLoUrl);

		String url = apiLoUrl + "/vaConnectTest?test=money";

		try {
			Map<String, Object> resObj = httpClientHelper.getCallApi(url);
			log.debug(">> resObj : " + resObj);

			if(resObj == null) {
				return new ResponseEntity<>("null", HttpStatus.BAD_REQUEST);
			}

			return new ResponseEntity<>(resObj, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 헤더 - 공지사항 조회
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@ResponseBody
	@GetMapping("/main/topnotice")
	public ResponseEntity<Object> selectTopNotice() {
		List<NoticeVO> topNoticeList = mainService.selectTopNotice();
		return new ResponseEntity<>(topNoticeList, HttpStatus.OK);
	}
	
	@ResponseBody
	@GetMapping("/main/account")
	public ResponseEntity<Object> selectAccount() {
		Account account = userInfoUtil.getAccountInfo();
		return new ResponseEntity<>(account, HttpStatus.OK);
	}

	/*
	 * <pre>
	 * 처리내용: 헤더 - 이웰렛 잔액 조회
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */

	@ResponseBody
	@GetMapping("/main/eWalletAccount")
	public ResponseEntity<Object> selectEWalletAccount(String entrpsNo) {
		String ewalletBlce = mainService.selectEWalletAccount(entrpsNo);
		return new ResponseEntity<>(ewalletBlce, HttpStatus.OK);
	}


	/**
	 * <pre>
	 * 처리내용: 헤더 - 영업시간 여부, 고정가 실시간가 운영 여부 조회
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
//	@ResponseBody
//	@PostMapping("/main/headerRestInfo")
//	public ResponseEntity<Object>  headerRestInfo() {
//		Map<String,Object> restInfo = mainService.headerRestInfo();
//		return new ResponseEntity<>(restInfo, HttpStatus.OK);
//	}


	/**
	 * <pre>
	 * 처리내용: 헤더 타이머 최초값 조회 - 타이머 문구, 시간차, 개장시간 범위 코드
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@ResponseBody
	@PostMapping("/main/restDtTimeSet")
	public ResponseEntity<Object> restDtTimeSet(){

		Map<String,Object> restDtTimeMap = new HashMap<>();

		try {
			restDtTimeMap.put("restDtTime",mainService.selectRestDtTimeSet());
		} catch (Exception e) {
			log.error("[MainController][restDtTimeSet]" + ExceptionUtils.getStackTrace(e));
		}

		return new ResponseEntity<>(restDtTimeMap, HttpStatus.OK);

	}
	
    /**
     * <pre>
     * 처리내용: 서버시간 리턴
     * </pre>
     * @date 2023. 06. 26.
     * @author srec0004
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 06. 26.            srec0004            최초작성
     * ------------------------------------------------
     * @return
     */
    @ResponseBody
    @GetMapping("/getServerTime")
    public ResponseEntity<Object> getServerTime(){
        return new ResponseEntity<>(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"), HttpStatus.OK);

    }	
	

	/**
	 * <pre>
	 * 처리내용: 스케줄 (1분에 한번 씩 호출)
	 * 			 헤더 타이머 조회 - 타이머 문구, 시간차, 개장시간 범위 코드
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
    @Scheduled(cron = "0 * * * * *")
	public void restDtTimeSetSchdule() throws Exception {
		// 1분에 한번 씩 호출
		Map<String,Object> timeSetMap = mainService.restDtTimeSetSchdule();
		simpMessagingTemplate.convertAndSend("/selectHeaderTimeSet",timeSetMap);
	}

	/**
	 * <pre>
	 * 처리내용: 헤더 메뉴를 조회한다.
	 * </pre>
	 * @date 2021. 12. 24.
	 * @author srec0042
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 24.			srec0042			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@ResponseBody
	@PostMapping("/selectHeaderMenu")
	public ResponseEntity<Object> selectHeaderMenu(){
		Map<String,Object> headerMenuMap = new HashMap<>();

		try {
			headerMenuMap.put("headerMenuList", mainService.selectHeaderMenu());
			return new ResponseEntity<>(headerMenuMap, HttpStatus.OK);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error("[MainController][selectHeaderMenu]" + ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	@RequestMapping("/main/getSarokPcList")
	@ResponseBody
	public List<Map<String, Object>> getSarokPcList() throws Exception {
		return mainService.getSarokPcList(DateUtil.getNowDate());
	}

	/**
	 * <pre>
	 * 처리내용:전일종가 영역 데이터 조회
	 * </pre>
	 * @date 2024. 02. 14.
	 * @author
	 * @history
	 * ------------------------------------------------
	 * 변경일                  작성자             변경내용
	 * ------------------------------------------------
	 * 2024. 02. 14.            sumin            최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@RequestMapping("/main/selectClosingPc")
	public ResponseEntity<Object> selectClosingPc(ModelMap model) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		try {
			List<ClosingPcVO> closingPcList = mainService.selectClosingPcList();
			rtnMap.put("closingPcList", closingPcList);
			return new ResponseEntity<>(rtnMap, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
}