package com.sorincorp.mfo.ma.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class ClosingPcVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 *  메탈코드
	 */
	private String metalCode;

	/**
	 * 영역 구분자
	 */
	private String part;

	/**
	 * 영역 구분자
	 */
	private String subPart;

	/**
	 * 표출 이름
	 */
	private String displayNm;

	/**
	 * 표출 가격
	 */
	private String displayAmount;

	/**
	 * 기타 가격1
	 */
	private String etcAmount1;

	/**
	 * 기타 가격2
	 */
	private String etcAmount2;


}
