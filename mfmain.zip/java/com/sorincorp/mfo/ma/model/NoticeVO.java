package com.sorincorp.mfo.ma.model;

import lombok.Data;

@Data
public class NoticeVO {

	/******  JAVA VO CREATE : OP_NOTICE_BAS(운영_공지사항 기본) ******/
	    /*** 공지사항 번호 */
	    private int noticeNo;
	    /*** 공지사항 제목 */
	    private String noticeSj;
	    /*** 공지사항 내용 */
	    private String noticeCn;
	    /*** 공지사항 상단노출 여부 */
	    private String noticeUpendexpsrAt;
	    /*** 공지사항 상단노출 시작일 */
	    private String noticeUpendexpsrBgnde;
	    /*** 공지사항 상단노출 종료일 */
	    private String noticeUpendexpsrEndde;
	    /*** 공지사항 메인팝업 여부 */
	    private String noticeMainpopupAt;
	    /*** 공지사항 메인팝업 시작일 */
	    private String noticeMainpopupBgnde;
	    /*** 공지사항 메인팝업 종료일 */
	    private String noticeMainpopupEndde;
	    /*** 사용 여부 */
	    private String useAt;
	    /*** 삭제 여부 */
	    private String deleteAt;
	    /*** 삭제 일시 */
	    private String deleteDt;
	    /*** 최초 등록자 아이디 */
	    private String frstRegisterId;
	    /*** 최초 등록 일시 */
	    private String frstRegistDt;
	    /*** 최종 변경자 아이디 */
	    private String lastChangerId;
	    /*** 최종 변경 일시 */
	    private String lastChangeDt;
}
