package com.sorincorp.mfo.ma.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class BbscttVO implements Serializable {

	private static final long serialVersionUID = -4987731266365713090L;
	
	/******  JAVA VO CREATE : OP_UNITY_BBS_DTL(운영_통합 게시판 상세)  ******/
	/**
	 * 게시판 ID
	 */
	private String bbsId;
	/**
	 * 게시글 번호
	 */
	private int bbscttNo;
	/**
	 * 게시글 제목
	 */
	private String bbscttSj;
	/**
	 * 게시글 내용
	 */
	private String bbscttCn;
	/**
	 * 게시글 공지 설정 여부
	 */
	private String bbscttNoticeSetupAt;
	/**
	 * 부모 게시글 번호
	 */
	private int parntsBbscttNo;
	/**
	 * 게시글 깊이
	 */
	private int bbscttDp;
	/**
	 * 게시글 순서
	 */
	private int bbscttOrdr;
	/**
	 * 답변 댓글 구분
	 */
	private String answerAnswerSe;
	/**
	 * 조회수
	 */
	private int rdcnt;
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;

}
