package com.sorincorp.mfo.ma.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.mfo.ma.model.*;

public interface MainMapper {

	public abstract List<NoticeVO> selectTopNotice();

	public abstract List<EventHolidayVO> selectMonthlyEvent(EventHolidayVO eventHolidayVO);

	public abstract List<EventHolidayVO> selectTodayEvent(String date);

	public abstract String selectEWalletAccount(String entrpsNo);

	public abstract List<BbscttVO> selectNewsClipping();


	public abstract List<HeaderMenuVO> selectHeaderMenu();

	public abstract String selectDlvyIngCnt(Map<String, Object> param);

	public abstract List<PopupDocVO> selectMainPopupNoticeDocNo();
	
	public abstract PopupDocVO selectMainLargePopup();

	public abstract List<Map<String, Object>> getSarokPcList(Map<String, Object> param);

	public abstract List<HeaderMenuVO> selectEntrpsMetalHeaderMenu();

	/**
	 * <pre>
	 * 운영중인지 체크
	 * </pre>
	 * @date 2022. 09. 22.
	 * @author jhcha
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 09. 22.		jhcha				최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public abstract String getWorkCheck();

	/**
	 * <pre>
	 * 처리내용: 메탈월드 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 10. 7.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 7.			srec0072			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public abstract List<MetalWorldVO> selectMetalWorldList();

	/**
	 * <pre>
	 * 처리내용:전일종가 영역 데이터 조회
	 * </pre>
	 * @date 2024. 02. 14.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일                  작성자             변경내용
	 * ------------------------------------------------
	 * 2024. 02. 14.            sumin            최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public abstract List<ClosingPcVO> selectClosingPcList();
}
