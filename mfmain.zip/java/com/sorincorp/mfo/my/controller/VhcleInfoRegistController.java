package com.sorincorp.mfo.my.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.deliveryCarMng.model.DeliveryCarMngCommVO;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.mfo.config.LoginTokenProvider;
import com.sorincorp.mfo.config.UserInfoUtil;
import com.sorincorp.mfo.login.model.Account;
import com.sorincorp.mfo.login.service.AccountServiceImpl;
import com.sorincorp.mfo.my.model.OrderDtlsVO;
import com.sorincorp.mfo.my.model.VhcleInfoRegistVO;
import com.sorincorp.mfo.my.model.VhcleInfoVO;
import com.sorincorp.mfo.my.service.VhcleInfoRegistService;
import com.sorincorp.mfo.pd.service.ItemPriceService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/vhcleInfoRegist")
public class VhcleInfoRegistController {
	
	@Autowired
	private VhcleInfoRegistService vhcleInfoRegistService;
	
	@Autowired
    private ItemPriceService itemPriceService;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	/**
	 * 차량등록 서브도메인
	 */
	@Value("${spring.mfo.subDomain}")
	private String MFO_SUBDOMAIN ;
	/**
	 * 차량등록 올드도메인
	 */
	@Value("${spring.mfo.oldDomain}")
	private String MFO_OLDDOMAIN ;
	
	@RequestMapping("/getVhcleInfoRegistList")
	public String getVhcleInfoRegist(@Nullable @RequestParam String orderNo, ModelMap map) throws Exception {
		try {
			Account account = userInfoUtil.getAccountInfo();
			Map<String,Object> loginStatusMap = new HashMap<String,Object>();
			
	        if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
	        	return "us/loginMain";
	        }  else {
				loginStatusMap.put("loginYn","Y");
			}
	        map.put("seCode", account.getSecode());
			map.put("orderNo", orderNo);
			map.addAttribute("loginStatusMap", loginStatusMap);
			return "my/vhcleInfoRegistList";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	@RequestMapping("/selectVhcleInfoRegistList")
	@ResponseBody
	public Map<String, Object> selectVhcleInfoRegistList(@RequestBody VhcleInfoRegistVO vhcleInfoRegistVO) throws Exception {
		
		
		Map<String, Object> returnmap = new HashMap<>();

		//주문내역 총 건수
		int vhcleInfoRegistListTotCnt = 0;
		//주문내역 리스트		
		List<VhcleInfoRegistVO> vhcleInfoRegistList = new ArrayList<VhcleInfoRegistVO>();
		
		try {
			// 세션정보
			Account account = userInfoUtil.getAccountInfo();
			if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
				throw new Exception("로그인 정보를 확인해주세요.");
			}

			String mberNo = StringUtil.nvl(account.getMberNo()); // 회원번호
			String entrpsNo = StringUtil.nvl(account.getEntrpsNo()); // 업체번호
			String memberSecode = StringUtil.nvl(userInfoUtil.getMemberSecode()); // 권한 구분 코드

			vhcleInfoRegistVO.setMberNo(mberNo);
			vhcleInfoRegistVO.setEntrpsNo(entrpsNo);
			vhcleInfoRegistVO.setSecode(memberSecode);
						
			vhcleInfoRegistListTotCnt = vhcleInfoRegistService.selectVhcleInfoRegistListTotCnt(vhcleInfoRegistVO);
			
			if (vhcleInfoRegistListTotCnt > 0) {
				vhcleInfoRegistList = vhcleInfoRegistService.selectVhcleInfoRegistList(vhcleInfoRegistVO);
			}
			
			returnmap.put("vhcleInfoRegistListTotCnt", vhcleInfoRegistListTotCnt);
			returnmap.put("vhcleInfoRegistList", vhcleInfoRegistList);		
			
		} catch (Exception e) {
			log.error("[OrderDtlsController][orderDtls]" + e.getMessage());
		}
		
		return returnmap;
	}
	
	@RequestMapping("/selectVhcleInfoRegist")
	public String selectVhcleInfoRegist(ModelMap model,@RequestParam String orderNo, @Nullable @RequestParam String orderSn, ModelMap map,@RequestHeader(value="Host") String host) throws Exception {
		String entrpsNo = userInfoUtil.getEntripsNo();
		
		try {
			//md.kztraders, md.metalsorin -> m.kztraders redirect
			if(host.indexOf(MFO_SUBDOMAIN) > -1 || host.indexOf(MFO_OLDDOMAIN) > -1) {
				model.put("orderNo", orderNo);
				model.put("oldDomainAt", 'N');
				return "my/svcChgInfo";
			}
			
			// orderSn 값이 null일 경우(메세지나 알림톡으로 유입), 첫번째 주문 순번(001)으로 값 세팅
			if(orderSn == null) {
				orderSn = "001";
			}
			
			VhcleInfoRegistVO vhcleInfoRegistVO = vhcleInfoRegistService.selectOrOrderBas(orderNo, orderSn);
			// 23-08-11 변경사항 : alert 창을 띄워주는 페이지로 노출
			if(entrpsNo == null || vhcleInfoRegistVO == null 
					|| !StringUtils.equals(entrpsNo, vhcleInfoRegistVO.getEntrpsNo())) {
				return "my/wrongApproach";
			}
			
			map.put("order", vhcleInfoRegistVO);
			map.put("orderSn", orderSn);
			map.put("vhcleInfoList", vhcleInfoRegistService.selectOrVhcleInfoBas(orderNo, orderSn));
			map.put("vhcleGroupCodeList", vhcleInfoRegistService.selectVhcleGroupCodeList(vhcleInfoRegistVO));
			map.put("mbVhcleInfoList", vhcleInfoRegistService.selectMbVhcleInfoBas());
			map.put("mbDrvArticlInfoList", vhcleInfoRegistService.selectMbDrvArticlInfoBas());
			map.put("deliveryRequestDateList", new ObjectMapper().writeValueAsString(itemPriceService.selectDeliveryRequestDate(vhcleInfoRegistVO.getMetalCode())));
			map.put("holidayList", vhcleInfoRegistService.selectHolidayList(orderNo));
			
			
			return "my/vhcleInfoRegist";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	@RequestMapping("/insertVhcleInfo")
	@ResponseBody
	public ResponseEntity<?> insertVhcleInfo(@RequestBody List<VhcleInfoVO> vhcleInfoList) throws Exception {
		boolean result = vhcleInfoRegistService.insertVhcleInfo(vhcleInfoList);
		
		return ResponseEntity.ok(result);
	}
	
	@RequestMapping("/insertDeliveryCar")
	@ResponseBody
	public ResponseEntity<?> insertDeliveryCar(@RequestBody DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception {
		return ResponseEntity.ok(vhcleInfoRegistService.insertDeliveryCar(deliveryCarMngCommVO));
	}
	
	@RequestMapping("/insertDeliveryDriver")
	@ResponseBody
	public ResponseEntity<?> insertDeliveryDriver(@RequestBody DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception {
		return ResponseEntity.ok(vhcleInfoRegistService.insertDeliveryDriver(deliveryCarMngCommVO));
	}
	
	@RequestMapping("/getSettleSttusDe")
    @ResponseBody
    public Map<String,Object> getSettleSttusDe(@RequestBody VhcleInfoRegistVO vhcleInfoRegistVO) throws Exception  {
        return vhcleInfoRegistService.getSettleSttusDe(vhcleInfoRegistVO);
    }
	
    @PostMapping("/holidayCheck")
    @ResponseBody
    public Map<String, Object> holidayCheck(@RequestBody VhcleInfoVO vhcleInfoVO) throws Exception {
        log.debug("::: holidayCheck start - "+ vhcleInfoVO.toString());

        Map<String, Object> map = new HashMap<>();
        map.put("yn", vhcleInfoRegistService.checkHolidayYn(vhcleInfoVO));

        return map;
    }
}
