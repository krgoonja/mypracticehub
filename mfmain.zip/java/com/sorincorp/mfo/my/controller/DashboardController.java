package com.sorincorp.mfo.my.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.mfo.my.model.InqryDtlsVO;
import com.sorincorp.mfo.my.model.DashboardVO;
import com.sorincorp.mfo.config.UserInfoUtil;
import com.sorincorp.mfo.login.model.Account;
import com.sorincorp.mfo.my.model.CorpInfoMgrVO;
import com.sorincorp.mfo.my.model.MyInfoMngVO;
import com.sorincorp.mfo.my.model.PaytEsamtVO;
import com.sorincorp.mfo.my.service.DashboardService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/my/mypage")
public class DashboardController {

	@Autowired
	UserInfoUtil userInfoUtil;

	@Autowired
	MessageUtil messageUtil;
	
	@Autowired
	DashboardService dashboardService;


	private Account getAccountInfo() throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		if (null == account || StringUtil.isBlank(account.getMberNo())) {
			throw new Exception("로그인 정보를 확인해주세요.");
		}
		return account;
	}
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지(대시보드)를 호출한다.
	 * </pre>
	 * @date 2024. 01. 03.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일 				작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 03.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/dashboard")
	public String main(Model model, HttpServletRequest request) {
		Map<String, Object> param = new HashMap<>();
		Map<String,Object> loginStatusMap = new HashMap<String,Object>();
		
		//회원 정보
		MyInfoMngVO myInfoMngVO = new MyInfoMngVO();
		//업체 정보
		CorpInfoMgrVO corpInfoMgrVO= new CorpInfoMgrVO();
		//결제 정보 - 이월렛
		Map<String, Object> setleMnInfo = new HashMap<>();
		//결제 예정액
		Map<String, Object> unSetleAmountInfo = new HashMap<>();
		//최근 30일 거래내역
		DashboardVO recentOrderDtls = new DashboardVO();
		//결제 내역 - 미납, 대기, 예정
		List<PaytEsamtVO> listUnSetleAmountDtl = new ArrayList<PaytEsamtVO>();
		// 최근 7일내 3개 문의/답변 내역
		List<InqryDtlsVO> recentInqryAnswer = new ArrayList<InqryDtlsVO>();
		
		try {
			// 세션정보
			Account account = userInfoUtil.getAccountInfo();
	        if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
	        	return "us/loginMain";
	        } else {
				loginStatusMap.put("loginYn","Y");
			}
			
			String mberNo = StringUtil.nvl(account.getMberNo()); // 회원번호
			String entrpsNo = StringUtil.nvl(account.getEntrpsNo()); // 업체번호
			String memberSecode = StringUtil.nvl(userInfoUtil.getMemberSecode()); // 권한 구분 코드
			String mberType = StringUtil.nvl(userInfoUtil.getType());
			
			param.put("mberNo", mberNo);
			param.put("entrpsNo", entrpsNo);
			param.put("memberSecode", memberSecode);
			
			//회원 기본 정보 (업체명)
			corpInfoMgrVO = dashboardService.getCorpInfoMgrVO(mberNo);
			model.addAttribute("corpInfoMgrVO", corpInfoMgrVO);
			
			// 상단 대시보드 결제수단
			setleMnInfo = dashboardService.selectSetleMnInfo(entrpsNo);
			model.addAttribute("setleMnInfo", setleMnInfo);
			
			//결제 예정액
			unSetleAmountInfo = dashboardService.selectUnSetleAmount(param);
			model.addAttribute("unSetleAmountInfo", unSetleAmountInfo);
			
			//최근 30일 거래내역
			recentOrderDtls = dashboardService.selectRecentOrderDtls(param);
			model.addAttribute("recentOrderDtls", recentOrderDtls);
			
			// 결제내역 목록
			listUnSetleAmountDtl = dashboardService.selectListUnSetleAmountDtl(param);
//			String jsonUnSetleAmountDtl = ObjectMapper.writeValueAsString(listUnSetleAmountDtl);
			model.addAttribute("listUnSetleAmountDtl", listUnSetleAmountDtl);
			
			// 최근 7일내 3개 문의/답변 내역
			recentInqryAnswer = dashboardService.selectRecentInqryAnswer(param);
			model.addAttribute("recentInqryAnswer", recentInqryAnswer);
			
			model.addAttribute("loginStatusMap", loginStatusMap);
			
			return "my/mypage";
			
		} catch (Exception e) {
			log.error("[DashBoardController][dashBoard]" + e.getMessage());
			return "error/503";
		}
		
	}
	
	/**
	 * <pre>
	 * 처리내용: 결제수단 e-wallet금액을 새로고침한다.
	 * </pre>
	 * @date 2024. 01. 03.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일 				작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 03.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@PostMapping("/selectSetleMnInfo")
	@ResponseBody
	public Map<String, Object> selectSetleMnInfo(@RequestBody String flag) throws Exception {
		Account account = getAccountInfo(); // 세션정보
		String entrpsNo = StringUtil.nvl(account.getEntrpsNo()); // 업체번호
		// 상단 대시보드 결제수단
		Map<String, Object> setleMnInfo = dashboardService.selectSetleMnInfo(entrpsNo);

		Map<String, Object> map = new HashMap<>();
		map.put("setleMnInfo", setleMnInfo);
		map.put("flag", flag); // 클릭 버튼 구분 flag

		return map;
	}
}