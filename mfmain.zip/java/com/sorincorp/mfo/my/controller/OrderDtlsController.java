package com.sorincorp.mfo.my.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.mfo.my.model.OrderLimitVO;
import com.sorincorp.mfo.config.UserInfoUtil;
import com.sorincorp.mfo.login.model.Account;
import com.sorincorp.mfo.my.model.OrderDtlsVO;
import com.sorincorp.mfo.my.service.OrderDtlsService;
import com.sorincorp.mfo.my.service.OrderLimitService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/my/order")
public class OrderDtlsController {

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private OrderDtlsService orderDtlsService;

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	private OrderLimitService orderLimitService;



	/**
	 * <pre>
	 * 처리내용: 마이페이지 > 주문내역 페이지를 조회한다.
	 * </pre>
	 * @date 2024. 01. 05.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일 				작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 05.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/orderDtls")
	public String orderDtls(@RequestBody(required = false) String flag, ModelMap model) {

//		Map<String, Object> map = new HashMap<>();
		// 주문배송상태
		Map<String, String> orderSttusCode = new HashMap<>();
		// 가격주문방식
		Map<String, String> sleMthdCode = new HashMap<>();
		Map<String,Object> loginStatusMap = new HashMap<String,Object>();

		try {
			// 세션정보
			Account account = userInfoUtil.getAccountInfo();
			if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
				return "us/loginMain";
			} else {
				loginStatusMap.put("loginYn","Y");
			}
			orderSttusCode = commonCodeService.getFilterCode("ORDER_STTUS_CODE", null, "CODE_DCTWO", "Y");
			String orderSttusCodeList = orderDtlsService.getCommCodeListStr(orderSttusCode);

			sleMthdCode = commonCodeService.getFilterCode("SLE_MTHD_CODE", null, "CODE_DCTWO", "Y");
			String sleMthdCodeList = orderDtlsService.getCommCodeListStr(sleMthdCode);

			model.addAttribute("orderSttusCodeList", orderSttusCodeList);
			model.addAttribute("sleMthdCodeList", sleMthdCodeList);
			model.addAttribute("loginStatusMap", loginStatusMap);
			// 주문상세에서 주문내역 버튼 클릭 시 flag
			if ("1".equals(flag)) {
				model.addAttribute("flag", flag);
			}
						
			return "my/orderList";
		} catch (Exception e) {
			log.error("[OrderDtlsController][orderDtls]" + e.getMessage());
			return "error/503";
		}

	}

	/**
	 * <pre>
	 * 처리내용: 마이페이지 > 주문내역 리스트를 조회한다.
	 * </pre>
	 * @date 2024. 01. 05.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일 				작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 05.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping("/selectOrderDtlsList")
	@ResponseBody
	public Map<String, Object> selectOrderDtlsList(@RequestBody OrderDtlsVO seachVo) throws Exception {

		Map<String, Object> returnmap = new HashMap<>();

		//주문내역 총 건수
		int orderDtlsTotCnt = 0;
		//주문내역 리스트
		List<OrderDtlsVO> orderDtlsList = new ArrayList<OrderDtlsVO>();
		try {
			// 세션정보
			Account account = userInfoUtil.getAccountInfo();
			if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
				throw new Exception("로그인 정보를 확인해주세요.");
			}

			String mberNo = StringUtil.nvl(account.getMberNo()); // 회원번호
			String entrpsNo = StringUtil.nvl(account.getEntrpsNo()); // 업체번호
			String memberSecode = StringUtil.nvl(userInfoUtil.getMemberSecode()); // 권한 구분 코드

			seachVo.setMberNo(mberNo);
			seachVo.setEntrpsNo(entrpsNo);
			seachVo.setMemberSecode(memberSecode);

			// 회원구분코드가 '03'(구매담당)인 경우, 본인이 구매한 주문건만 보임. 그 외는 소속 업체 주문건 모두 조회 가능
			orderDtlsTotCnt = orderDtlsService.selectOrderDtlsListTotCnt(seachVo);
			if (orderDtlsTotCnt > 0) {
				orderDtlsList = orderDtlsService.selectOrderDtlsList(seachVo);
			}

			returnmap.put("orderDtlsTotCnt", orderDtlsTotCnt);
			returnmap.put("orderDtlsList", orderDtlsList);

		} catch (Exception e) {
			log.error("[OrderDtlsController][orderDtls]" + e.getMessage());
		}
		return returnmap;

	}


	private Account getAccountInfo() throws Exception {
        Account account = userInfoUtil.getAccountInfo();
        if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
            throw new Exception("로그인 정보를 확인해주세요.");
        }
        return account;
    }
}
