package com.sorincorp.mfo.my.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.deliveryCarMng.model.DeliveryCarMngCommVO;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.mfo.login.model.Account;
import com.sorincorp.mfo.login.model.LoginVO;
import com.sorincorp.mfo.login.service.AccountServiceImpl;
import com.sorincorp.mfo.pd.service.ItemPriceService;
import com.sorincorp.mfo.config.LoginTokenProvider;
import com.sorincorp.mfo.config.UserInfoUtil;
import com.sorincorp.mfo.my.model.VhcleInfoRegistVO;
import com.sorincorp.mfo.my.model.VhcleInfoVO;
import com.sorincorp.mfo.my.service.VhcleInfoRegistService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/vhcleInfoRegist_old")
public class VhcleInfoRegistController_old {
	
	@Autowired
	private VhcleInfoRegistService vhcleInfoRegistService;
	
	@Autowired
    private ItemPriceService itemPriceService;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Autowired
	private AccountServiceImpl accountService;
	
	@Autowired
	private LoginTokenProvider loginTokenProvider;
	
	@Autowired
	private RedisUtil redisUtil;
	
	@RequestMapping("/getVhcleInfoRegistList")
	public String getVhcleInfoRegist(@Nullable @RequestParam String orderNo, ModelMap map) throws Exception {
		try {
			map.put("orderNo", orderNo);
			
			return "my/vhcleInfoRegistModal";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	@RequestMapping("/getVhcleInfoRegistListLogin")
	public String getVhcleInfoRegistListLogin(String vhcleFormId, @Nullable @RequestParam String orderNo, ModelMap map, HttpServletResponse response) throws Exception {
		try {
			
			// MO -> MFO 이동 후 로그인 세션 생성 필요 없음.
			/*
			LoginVO loginVo = new LoginVO();
			loginVo.setId(CryptoUtil.decryptAES256(vhcleFormId.trim()));
			
			Account account = accountService.selectAccount(loginVo.getId());
			
			// Access Token, Refresh Token 생성
			
			final String access = loginTokenProvider.generateAccessToken(account);
			final String refresh = loginTokenProvider.generateRefreshToken(account);
			
			ResponseCookie accessToken = loginTokenProvider.createSecureCookie(CommonConstants.MO_ACCESS_TOKEN_NAME, access, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);
			ResponseCookie refreshToken = loginTokenProvider.createSecureCookie(CommonConstants.MO_REFRESH_TOKEN_NAME, refresh, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND);

			redisUtil.setDataExpire(CommonConstants.REDIS_KEY_MO_ACCESS + account.getId(), access, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);
			redisUtil.setDataExpire(CommonConstants.REDIS_KEY_MO_REFRESH + account.getId(), refresh, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND);

			// Token Cookie를 Response에 추가
			response.addHeader(HttpHeaders.SET_COOKIE, accessToken.toString());
			response.addHeader(HttpHeaders.SET_COOKIE, refreshToken.toString());
			*/
			map.put("orderNo", orderNo);
			
			return "my/vhcleInfoRegistList";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}
	
	@RequestMapping("/selectVhcleInfoRegistList")
	@ResponseBody
	public List<VhcleInfoRegistVO> selectVhcleInfoRegistList(@RequestBody VhcleInfoRegistVO vhcleInfoRegistVO) throws Exception {
		return vhcleInfoRegistService.selectVhcleInfoRegistList(vhcleInfoRegistVO);
	}
	
	@PostMapping("/selectVhcleInfoRegist")
	@ResponseBody
	public Map<String, Object> selectVhcleInfoRegist(@RequestParam String orderNo, @Nullable @RequestParam String orderSn) throws Exception {
		Map<String, Object> map = new HashMap<>();
		String entrpsNo = userInfoUtil.getEntripsNo();

			// orderSn 값이 null일 경우(메세지나 알림톡으로 유입), 첫번째 주문 순번(001)으로 값 세팅
			if(orderSn == null) {
				orderSn = "001";
			}
			
			VhcleInfoRegistVO vhcleInfoRegistVO = vhcleInfoRegistService.selectOrOrderBas(orderNo, orderSn);
			
			map.put("order", vhcleInfoRegistVO);
			map.put("orderSn", orderSn);
			map.put("vhcleInfoList", vhcleInfoRegistService.selectOrVhcleInfoBas(orderNo, orderSn));
			map.put("vhcleGroupCodeList", vhcleInfoRegistService.selectVhcleGroupCodeList(vhcleInfoRegistVO));
			map.put("mbVhcleInfoList", vhcleInfoRegistService.selectMbVhcleInfoBas());
			map.put("mbDrvArticlInfoList", vhcleInfoRegistService.selectMbDrvArticlInfoBas());
			map.put("deliveryRequestDateList", new ObjectMapper().writeValueAsString(itemPriceService.selectDeliveryRequestDate(vhcleInfoRegistVO.getMetalCode())));
			map.put("holidayList", vhcleInfoRegistService.selectHolidayList(orderNo));
			
			return map;
		
	}
	
	@RequestMapping("/insertVhcleInfo")
	@ResponseBody
	public ResponseEntity<?> insertVhcleInfo(@RequestBody List<VhcleInfoVO> vhcleInfoList) throws Exception {
		boolean result = vhcleInfoRegistService.insertVhcleInfo(vhcleInfoList);
		
		return ResponseEntity.ok(result);
	}
	
	@RequestMapping("/insertDeliveryCar")
	@ResponseBody
	public ResponseEntity<?> insertDeliveryCar(@RequestBody DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception {
		return ResponseEntity.ok(vhcleInfoRegistService.insertDeliveryCar(deliveryCarMngCommVO));
	}
	
	@RequestMapping("/insertDeliveryDriver")
	@ResponseBody
	public ResponseEntity<?> insertDeliveryDriver(@RequestBody DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception {
		return ResponseEntity.ok(vhcleInfoRegistService.insertDeliveryDriver(deliveryCarMngCommVO));
	}
	
	@RequestMapping("/getSettleSttusDe")
    @ResponseBody
    public Map<String,Object> getSettleSttusDe(@RequestBody VhcleInfoRegistVO vhcleInfoRegistVO) throws Exception  {
        return vhcleInfoRegistService.getSettleSttusDe(vhcleInfoRegistVO);
    }
	
    @PostMapping("/holidayCheck")
    @ResponseBody
    public Map<String, Object> holidayCheck(@RequestBody VhcleInfoVO vhcleInfoVO) throws Exception {
        log.debug("::: holidayCheck start - "+ vhcleInfoVO.toString());

        Map<String, Object> map = new HashMap<>();
        map.put("yn", vhcleInfoRegistService.checkHolidayYn(vhcleInfoVO));

        return map;
    }
}
