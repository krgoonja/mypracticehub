package com.sorincorp.mfo.my.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.mfo.config.UserInfoUtil;
import com.sorincorp.mfo.login.model.Account;
import com.sorincorp.mfo.my.model.OrderLimitVO;
import com.sorincorp.mfo.my.model.OrderLimitValidVO;
import com.sorincorp.mfo.my.service.OrderLimitService;

import lombok.extern.slf4j.Slf4j;

/**
 * 마이페이지 > 주문/지정가
 * @author srec0051
 *
 */
@Slf4j
@Controller
@RequestMapping("/my/order")
public class OrderLimitController {

	@Autowired
	private UserInfoUtil userInfoUtil;

	@Autowired
	private OrderLimitService orderLimitService;

//	@Autowired
//	private CommLimitOrderService commLimitOrderService;


	private Account getAccountInfo() throws Exception {
        Account account = userInfoUtil.getAccountInfo();
        if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
            throw new Exception("로그인 정보를 확인해주세요.");
        }
        return account;
    }


	private String getCommCodeListStr(Map<String, String> commonCode) throws Exception{
		StringBuilder codeTaglibStr = new StringBuilder(StringUtils.EMPTY);
		codeTaglibStr.append("");
		codeTaglibStr.append(CommonConstants.COLONE);
		codeTaglibStr.append("전체");
		codeTaglibStr.append(CommonConstants.SEMI_COLONE);

		for (String code : commonCode.keySet()) {
			codeTaglibStr.append(code);
			codeTaglibStr.append(CommonConstants.COLONE);
			codeTaglibStr.append(commonCode.get(code));
			codeTaglibStr.append(CommonConstants.SEMI_COLONE);
		}

		return codeTaglibStr.toString();
	}

	/**
	 * <pre>
	 * 지정가 페이지
	 * </pre>
	 * @date 2023. 3. 9.
	 * @author srec0051
	 * @param flag 이전 검색 조건 로드 여부
	 * @param model
	 * @return
	 */
	@RequestMapping("/limit")
	public String orderLimit(@RequestBody(required = false) String flag, ModelMap model) {
		try {
			Map<String,Object> loginStatusMap = new HashMap<String,Object>();
			Account account = userInfoUtil.getAccountInfo();
			
	        if (null == account || StringUtil.isBlank(account.getMberNo()) || StringUtil.isBlank(account.getEntrpsNo())) {
	        	return "us/loginMain";
	        } else {
				loginStatusMap.put("loginYn","Y");
			}

	        log.debug("flag ; ", flag);

//	        // 주문진행상태 공통코드
//	        model.addAttribute("sbxOrderSttusCode", getCommCodeListStr(commonCodeService.getFilterCode("ORDER_STTUS_CODE", null, "CODE_DCTWO", "Y")));

	        if ("1".equals(flag)) {
	        	model.addAttribute("flag", flag);
	        }
	        model.addAttribute("loginStatusMap", loginStatusMap);
			return "my/orderLimitList";
        } catch(Exception e) {
            log.error(e.getMessage());
            return "error/503";
    	}
	}

	/**
	 * <pre>
	 * 지정가 주문 목록 조회
	 * </pre>
	 * @date 2023. 3. 10.
	 * @author srec0051
	 * @param searchVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/limit/list")
	@ResponseBody
	public ResponseEntity<?> orderLimitList(@RequestBody OrderLimitVO searchVo) throws Exception {
		Account account = getAccountInfo();
		Map<String, Object> retmap = new HashMap<>();

        searchVo.setMberNo(account.getMberNo()); // 회원번호
        searchVo.setEntrpsNo(account.getEntrpsNo()); // 업체번호
        searchVo.setMberSecode(account.getSecode()); //회원구분코드

        List<OrderLimitVO> orderLimitList = null;
        int totCnt = orderLimitService.getOrderLimitTotCnt(searchVo);
        if (totCnt > 0) {
        	orderLimitList = orderLimitService.listOrderLimit(searchVo);
        }

        retmap.put("orderLimitListTotCnt", totCnt);
        retmap.put("orderLimitList", orderLimitList);

        return new ResponseEntity<>(retmap, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 지정가 취소
	 * </pre>
	 * @date 2023. 3. 14.
	 * @author srec0051
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/limit/cancel")
	@ResponseBody
	public ResponseEntity<?> orderLimitCancel(@RequestBody OrderLimitVO paramVo) throws Exception {
		Account account = getAccountInfo();
		Map<String, Object> retmap = new HashMap<>();
		retmap.put(CommonConstants.RESULT_CODE, HttpStatus.OK.value());
		paramVo.setMberId(account.getId());
		paramVo.setEntrpsNo(account.getEntrpsNo());
		paramVo.setMberNo(account.getMberNo());

		try {
			int ret = orderLimitService.doCancelOrderLimit(paramVo);
			if (ret > 0) {
				retmap.put(CommonConstants.RESULT_MSG, "주문이 취소 되었습니다.");
			}

		} catch (Exception e) {
			retmap.put(CommonConstants.RESULT_CODE, HttpStatus.BAD_REQUEST.value());
			retmap.put(CommonConstants.RESULT_MSG, e.getMessage());
		}

		return new ResponseEntity<>(retmap, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 지정가 주문/취소 가능 체크 (I:등록, U:수정, C:취소)
	 * </pre>
	 * @date 2023. 4. 6.
	 * @author srec0051
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/limit/valid")
	@ResponseBody
	public ResponseEntity<?> orderLimitValid(@RequestBody OrderLimitVO paramVo) throws Exception {
		Account account = getAccountInfo();
		Map<String, Object> retmap = new HashMap<>();
		retmap.put(CommonConstants.RESULT_CODE, HttpStatus.OK.value());

		paramVo.setMberId(account.getId());
		paramVo.setEntrpsNo(account.getEntrpsNo());

		try {
			if (StringUtil.isBlank(paramVo.getType())
					|| (!paramVo.getType().equals("C") && !paramVo.getType().equals("U") && !paramVo.getType().equals("I"))) {
				throw new Exception("잘못된 요청입니다.");
			}

			/** 취소 or 등록 가능 체크 */
			if (paramVo.getType().equals("C") || paramVo.getType().equals("I")) {
				validCreateAndCancel(paramVo, retmap);
			}
			/** 수정 가능 체크 (모달 오픈시 / 수정 이벤트시) */
			else {
				validSttusCodeNotSigned(paramVo);
			}

		} catch (Exception e) {
			retmap.put(CommonConstants.RESULT_CODE, HttpStatus.BAD_REQUEST.value());
			retmap.put(CommonConstants.RESULT_MSG, e.getMessage());
		}

		return new ResponseEntity<>(retmap, HttpStatus.OK);
	}

	/**
	 * <pre>
	 * 수정 가능(미체결) 여부 조회
	 * </pre>
	 * @date 2023. 4. 18.
	 * @author srec0051
	 * @param paramVo
	 * @throws Exception
	 */
	private void validSttusCodeNotSigned(OrderLimitVO paramVo) throws Exception {
		if (StringUtil.isBlank(paramVo.getLimitOrderNo())) {
			throw new Exception("잘못된 요청입니다.");
		}

		int ret = orderLimitService.validOrderLimitSttusCode(paramVo);
		if (ret < 1) {
			throw new Exception("주문을 수정할 수 없습니다.\r\n(주문의 상태가 변경되었습니다.)");
		}
	}

	/**
	 * <pre>
	 * 등록, 취소 가능 여부 조회
	 * </pre>
	 * @date 2023. 4. 18.
	 * @author srec0051
	 * @param paramVo
	 * @param retmap
	 * @throws Exception
	 */
	private void validCreateAndCancel(OrderLimitVO paramVo, Map<String, Object> retmap) throws Exception {
		OrderLimitValidVO limitCheckVo = orderLimitService.validCreateAndCancel(paramVo.getEntrpsNo());
		retmap.put("limitCheck", limitCheckVo);

		if (paramVo.getType().equals("C")) {
			if (StringUtils.equals(limitCheckVo.getCanclYn(), CommonConstants.YN_Y)) {
				retmap.put(CommonConstants.RESULT_MSG, StringUtils.EMPTY);
			} else if (StringUtils.equals(limitCheckVo.getCanclYn(), CommonConstants.YN_N)) {
				String totCnt = String.valueOf(limitCheckVo.getCancelTotCnt());
				throw new Exception("당일 지정가 주문 취소 횟수가 초과 되었습니다.\r\n(지정가 주문 취소 횟수 : "+ totCnt +"회)");
			} else {
				throw new Exception("오류가 발생하였습니다.\r\n관리자에게 문의 바랍니다.");
			}
		}
		else  {	//if (paramVo.getType().equals("I"))
			if (StringUtils.equals(limitCheckVo.getRceptYn(), CommonConstants.YN_Y)) {
				retmap.put(CommonConstants.RESULT_MSG, StringUtils.EMPTY);
			} else if (StringUtils.equals(limitCheckVo.getRceptYn(), CommonConstants.YN_N)) {
				String totCnt = String.valueOf(limitCheckVo.getOrderTotCnt());
				throw new Exception("당일 지정가 주문 횟수가 초과 되었습니다.\r\n(지정가 주문 횟수 : "+ totCnt +"회)");
			} else {
				throw new Exception("오류가 발생하였습니다.\r\n관리자에게 문의 바랍니다.");
			}
		}
	}

	/**
	 * <pre>
	 * 지정가 수정
	 * </pre>
	 * @date 2023. 3. 14.
	 * @author srec0051
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/limit/update")
	@ResponseBody
	public ResponseEntity<?> orderLimitUpdate(@RequestBody OrderLimitVO paramVo) throws Exception {
		log.info("orderLimitUpdate ::: IN ");
		log.debug("paramVo = {}", paramVo);
		Account account = getAccountInfo();
		Map<String, Object> retmap = new HashMap<>();
		paramVo.setMberId(account.getId());
		paramVo.setEntrpsNo(account.getEntrpsNo());

		/**
		 * 1. 입력한 지정가가 실시간 가격 이상이면 불가 (service 단에서 실시간 가격 체크 )
		 * 2. 톤수 수정은 감량만 가능
		 * 3. 미체결(10) 상태만 수정 가능
		 */
		try {
			String type2 = StringUtil.nvl(paramVo.getType2());
			/*
			if (StringUtil.isBlank(type2) || !(type2.equals("1") || type2.equals("2") || type2.equals("3"))) {
				log.error("잘못된 요청입니다.");
				throw new Exception("잘못된 요청입니다.");
			}
			*/
			if (StringUtil.isBlank(type2) && paramVo.getUsedCouponChangeAt().isEmpty()){
				log.error("잘못된 요청입니다.");
				throw new Exception("잘못된 요청입니다.");
			}

			//쿠폰 수정
			if (StringUtil.isBlank(type2) && !paramVo.getUsedCouponChangeAt().isEmpty()){
				if(paramVo.getUsedCouponChangeAt().equals("N")) {
					throw new Exception("선택한 쿠폰이 주문 쿠폰과 동일합니다.");
				}else {
					paramVo.setType2("4");
				}
			}

			if(!(type2.equals("1") || type2.equals("2") || type2.equals("3") || type2.equals("5") || !paramVo.getUsedCouponChangeAt().isEmpty())) {
				log.error("잘못된 요청입니다.");
				throw new Exception("잘못된 요청입니다.");
			}

			// 이전 가격과 동일 체크
			if ((type2.equals("1") || type2.equals("2"))
					&& paramVo.getLimitInputAmount() > 0
					&& paramVo.getLimitInputAmount() == paramVo.getOriLimitInputAmount()) {
				log.error("입력한 가격이 주문 가격과 동일합니다.");
				throw new Exception("입력한 가격이 주문 가격과 동일합니다.");
			}

			// 가격,톤수 or 톤수
			if ((type2.equals("1") || type2.equals("3"))
					&& paramVo.getLimitOrderWt() > 0) {
				if (paramVo.getLimitOrderWt() == paramVo.getOriLimitOrderWt()) {
					log.error("선택한 톤수가 주문 톤수와 동일합니다.");
					throw new Exception("선택한 톤수가 주문 톤수와 동일합니다.");
				}
				if (paramVo.getLimitOrderWt() > paramVo.getOriLimitOrderWt()) {
					log.error("톤수 수정은 감량만 가능합니다.");
					throw new Exception("톤수 수정은 감량만 가능합니다.");
				}
			}

			// 지정가 유효 기간
			if(paramVo.getValidPdChangeAt().equals("Y")) {
				if(paramVo.getLimitOrderValidDe().equals(paramVo.getOriLimitOrderValidDe()) &&
				   paramVo.getLimitOrderValidTime().equals(paramVo.getOriLimitOrderValidTime())) {
					throw new Exception("선택한 유효기간이 주문 유효기간과 동일합니다.");
				}
			}

			int ret = orderLimitService.doModifyOrderLimit(paramVo);
			if (ret > 0) {
				retmap.put(CommonConstants.RESULT_CODE, HttpStatus.OK.value());
				retmap.put(CommonConstants.RESULT_MSG, "주문이 수정되었습니다.");
			}

		} catch (Exception e) {
			retmap.put(CommonConstants.RESULT_CODE, HttpStatus.BAD_REQUEST.value());
			retmap.put(CommonConstants.RESULT_MSG, e.getMessage());
		}

		log.info("orderLimitUpdate ::: OUT ");

		return new ResponseEntity<>(retmap, HttpStatus.OK);
	}

	@RequestMapping("/limit/openOrderLimitModal")
	public String openOrderLimitModal(@RequestBody OrderLimitVO paramVo, ModelMap model) throws Exception {
		Account account = getAccountInfo();
		paramVo.setEntrpsNo(account.getEntrpsNo());
		OrderLimitVO orderLimitVO = orderLimitService.selectOrderLimit(paramVo);
		model.addAttribute("orderLimitVO", orderLimitVO);

		orderLimitService.setOrderLimitData(orderLimitVO, model);

		return "my/orderLimitModal";
	}

}
