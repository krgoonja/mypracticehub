package com.sorincorp.mfo.my.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.mfo.op.model.HopePcNtcnSetupVO;
import com.sorincorp.mfo.my.model.MyHopePcAlarmVO;

/**
 * MyAlarmService.java
 * @version
 * @since 2021. 9. 8.
 * @author srec0042
 */
public interface MyAlarmService {

	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 희망가 알림 내역을 조회한다.
	 * </pre>
	 * @date 2024. 01. 16.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 16.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @return
	 */
	public List<MyHopePcAlarmVO> selectHopePcAlarm(String entrpsNo);

	/**
	 * <pre>
	 * 처리내용: 마이페이지 희망가 알림을 수정을 위한 최초 실시간 판매 가격 가져오기
	 * </pre>
	 * @date 2024. 01. 16.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 16.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param updateVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	public Map<String,Object> selectRealTimeSellAlarm(HopePcNtcnSetupVO updateVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 희망가 알림 상태를 수정한다.
	 * </pre>
	 * @date 2024. 01. 17
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 17.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	public int updateHopePcUseAt(MyHopePcAlarmVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 희망가 알림을 수정한다.
	 * </pre>
	 * @date 2024. 01. 22.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 22.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception 
	 */
	public int updateHopePcAlarm(HopePcNtcnSetupVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 희망가 알림을 삭제한다.
	 * </pre>
	 * @date 2024. 01. 22.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 22.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param deleteVo
	 * @return
	 */
	public int deleteHopePcAlarm(HopePcNtcnSetupVO deleteVo);
	

}
