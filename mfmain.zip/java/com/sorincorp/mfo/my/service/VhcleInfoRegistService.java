package com.sorincorp.mfo.my.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.deliveryCarMng.model.DeliveryCarMngCommVO;
import com.sorincorp.mfo.my.model.VhcleInfoRegistVO;
import com.sorincorp.mfo.my.model.VhcleInfoVO;

public interface VhcleInfoRegistService {
	List<VhcleInfoRegistVO> selectVhcleInfoRegistList(VhcleInfoRegistVO vhcleInfoRegistVO) throws Exception;
	
	int getMultiBlListSize(String orderNo) throws Exception;
	
	VhcleInfoRegistVO selectOrOrderBas(String orderNo, String orderSn) throws Exception;
	
	List<VhcleInfoVO> selectOrVhcleInfoBas(String orderNo, String orderSn) throws Exception;
	
	List<CommonCodeVO> selectVhcleGroupCodeList(VhcleInfoRegistVO vhcleInfoRegistVO) throws Exception;
	
	List<DeliveryCarMngCommVO> selectMbVhcleInfoBas() throws Exception;
	
	List<DeliveryCarMngCommVO> selectMbDrvArticlInfoBas() throws Exception;
	
	boolean insertVhcleInfo(List<VhcleInfoVO> vhcleInfoList) throws Exception;
	
	List<DeliveryCarMngCommVO> insertDeliveryCar(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception;
	
	List<DeliveryCarMngCommVO> insertDeliveryDriver(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception;

	Map<String, Object> getSettleSttusDe(VhcleInfoRegistVO vhcleInfoRegistVO) throws Exception;

	List<String> selectHolidayList(String orderNo);

	int checkHolidayYn(VhcleInfoVO vhcleInfoVO);

	int selectVhcleInfoRegistListTotCnt(VhcleInfoRegistVO vhcleInfoRegistVO) throws Exception;
}
