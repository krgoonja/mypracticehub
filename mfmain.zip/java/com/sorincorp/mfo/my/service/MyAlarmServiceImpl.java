package com.sorincorp.mfo.my.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.pcInfo.model.PcMntrngSelVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.mfo.chart.model.PreminumInfoDto;
import com.sorincorp.mfo.chart.model.PreminumSelVO;
import com.sorincorp.mfo.op.model.HopePcNtcnSetupVO;
import com.sorincorp.mfo.chart.mapper.PcMntrngMapper;
import com.sorincorp.mfo.my.mapper.MyAlarmMapper;
import com.sorincorp.mfo.my.model.MyHopePcAlarmVO;

import lombok.extern.slf4j.Slf4j;

/**
 * MyAlarmServiceImpl.java
 * @version
 * @since 2021. 9. 8.
 * @author srec0042
 */
@Slf4j
@Service
public class MyAlarmServiceImpl implements MyAlarmService{
	
	@Autowired
	MyAlarmMapper myAlarmMapper;
	
	@Autowired
	PcInfoService pcInfoService;
	
	@Autowired
	PcMntrngMapper pcMntrngMapper;
	
	@Autowired
	CommonCodeService commonCodeService;
	
	private String getPreviousDay() {
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance( );
		cal.add ( cal.DATE, - 1 ); // 하루전
		
		return df.format(cal.getTime());
	}
	
	private float getVersusRate(long agoEndPcL,long nowEndPcL,long premiumAmountL) {
		float agoEndPcF = (float) agoEndPcL;
		float nowEndPcF = (float) nowEndPcL;
		float premiumAmountF = (float) premiumAmountL; 
		
		float vsusRate = ((nowEndPcF + premiumAmountF) - agoEndPcF) / agoEndPcF * 100;
		
		String vsusRateStr = String.format("%.2f", vsusRate); 
		
		return Float.parseFloat(vsusRateStr);
	}
	
	/*
	 * 마이페이지 - 희망가 알림 내역을 조회한다.
	 */
	@Override
	public List<MyHopePcAlarmVO> selectHopePcAlarm(String entrpsNo) {
		List<MyHopePcAlarmVO> myAlarmList =  myAlarmMapper.selectHopePcAlarm(entrpsNo);
		return myAlarmList;
	}
	

	/*
	 * 희망가 알림 상태를 수정한다.
	 */
	@Override
	public int updateHopePcUseAt(MyHopePcAlarmVO vo) throws Exception{
		return myAlarmMapper.updateHopePcUseAt(vo);
	}
	
	/*
	 * 마이페이지 희망가 알림을 수정을 위한 최초 실시간 판매 가격 가져오기
	 */
	@Override
	public Map<String, Object> selectRealTimeSellAlarm(HopePcNtcnSetupVO updateVO) throws Exception {
		Map<String,Object> rltmSllHpcMap = new HashMap<>();
		
			Map<String, CommonCodeVO> metalCodeMap = commonCodeService.getFilterCodeRetVo("METAL_CODE",updateVO.getMetalCode(),"CODE_DCTWO","Y");
			
			String key = updateVO.getMetalCode();
			
			// 판매 방식 별 분기
			if("1".equals(metalCodeMap.get(key).getCodeChrctrRefrnthree().substring(0, 1))) {
				
				//프리미엄 기준아이템 정보 조회
				PreminumInfoDto preminumInfoDto = new PreminumInfoDto();
				preminumInfoDto.setStdDt(DateUtil.getNowDate()); // 오늘날짜
				preminumInfoDto.setSleMthdCode("01");
				preminumInfoDto.setMetalCode(updateVO.getMetalCode());	// 금속코드
				preminumInfoDto.setItmSn(updateVO.getItmSn());
				preminumInfoDto.setDstrctLclsfCode(updateVO.getDstrctLclsfCode());
				preminumInfoDto.setBrandGroupCode(updateVO.getBrandGroupCode());
				preminumInfoDto.setBrandCode(updateVO.getBrandCode());
				preminumInfoDto.setValidBeginDt(DateUtil.getNowDateTime("yyyyMMddHHmmss"));
				preminumInfoDto.setValidEndDt(DateUtil.getNowDateTime("yyyyMMddHHmmss"));
				
				List<PreminumSelVO> stdrPreminumInfoList = pcMntrngMapper.getFnPreminumInfoList(preminumInfoDto);
				
				if(stdrPreminumInfoList.size() > 0) {
					//실시간 기준가 조회 
					PrSelVO prSelRltmVo = 
					pcInfoService.getNewestPrSelRltm(updateVO.getMetalCode(),updateVO.getItmSn(), updateVO.getDstrctLclsfCode(), 
							updateVO.getBrandGroupCode(), updateVO.getBrandCode(),DateUtil.getNowDate());
					
					if (prSelRltmVo != null) {
						//전날 가격 조회
						PcMntrngSelVO pcMntrngSelVO = new PcMntrngSelVO();
						pcMntrngSelVO.setChartCount(1);
						pcMntrngSelVO.setMetalCode(updateVO.getMetalCode());
						pcMntrngSelVO.setItmSn(updateVO.getItmSn());
						pcMntrngSelVO.setDstrctLclsfCode(updateVO.getDstrctLclsfCode());
						pcMntrngSelVO.setBrandGroupCode(updateVO.getBrandGroupCode());
						pcMntrngSelVO.setBrandCode(updateVO.getBrandCode());
						pcMntrngSelVO.setOccrrncDe(getPreviousDay());
			
						//기준정보 가격 가져오기
						List<PcMntrngSelVO> pcMntrngSelAgoVO = pcInfoService.getPcMngtrngSelDeList(pcMntrngSelVO);
			
						float versusRate = 0;
						long versusPc = 0;
						float agoEndPc = 0;
						float endPc = (float) (prSelRltmVo.getNonPremiumEndPc() + stdrPreminumInfoList.get(0).getSlePremiumAmount());
						
						if(prSelRltmVo != null) {
							// 0보다 크면 up, 0보다 작으면 down
							versusRate = getVersusRate(pcMntrngSelAgoVO.get(0).getEndPc(), prSelRltmVo.getNonPremiumEndPc(), stdrPreminumInfoList.get(0).getSlePremiumAmount());
							agoEndPc = pcMntrngSelAgoVO.get(0).getEndPc();
							versusPc = ((long)(endPc - agoEndPc));
						}
						
						rltmSllHpcMap.put("liveResultMap", prSelRltmVo);
						rltmSllHpcMap.put("versusRate", versusRate);
						rltmSllHpcMap.put("agoEndPc", agoEndPc);
						rltmSllHpcMap.put("versusPc", versusPc);
					}
				}
			}
		
			return rltmSllHpcMap;
		
	}
	
	/*
	 * 마이페이지 - 희망가 알림을 수정한다.
	 */
	@Override
	public int updateHopePcAlarm(HopePcNtcnSetupVO updateVo) throws Exception{
		return myAlarmMapper.updateHopePcAlarm(updateVo);
	}
	
	/*
	 * 마이페이지 - 희망가 알림을 삭제한다.
	 */
	@Override
	public int deleteHopePcAlarm(HopePcNtcnSetupVO deleteVo) {
		return myAlarmMapper.deleteHopePcAlarm(deleteVo);
	}

}
