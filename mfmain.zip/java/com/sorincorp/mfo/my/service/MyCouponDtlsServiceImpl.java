package com.sorincorp.mfo.my.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.mfo.my.mapper.CouponDtlsMapper;
import com.sorincorp.mfo.my.model.CouponDtlVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class MyCouponDtlsServiceImpl implements MyCouponDtlsSerivce {
    
    @Autowired
    CouponDtlsMapper couponDtlsMapper;
    
	@Autowired
	private CommonService commonService;
    
    /**
     * 쿠폰내역 리스트를 조회한다.
     */
    @Override
    public List<CouponDtlVO> selectCouponDtlsList(CouponDtlVO couponDtlVo) {
    	// 최조 조회시 현재 날짜로 비교 하는 부분 삭제.
    	// 업체지정 쿠폰 조회 부분 삭제 
        return couponDtlsMapper.selectCouponDtlsList(couponDtlVo);
    }
    
    /**
     * 쿠폰내역을 업데이트한다.
     */
    @Override
    public int updateCouponDtlsList(CouponDtlVO couponDtlVo) throws Exception {
		int result = 0;
		
		// 1. 난수 값이 프로모션 쿠폰 정보(PROMTN_COUPON_INFO_BAS) 에 있는지 확인 
		List<CouponDtlVO> checkCouponList  = couponDtlsMapper.selectCouponRnnoList(couponDtlVo);
	
		// 해당 쿠폰이 있는지 확인 후 있으면 OK 
		if(checkCouponList.size() == 1) {
			
			// 2. 내 쿠폰 리스트에 있는지 확인 (중복여부 확인 -> 일단 현재는 중복이 안되도록 처리
			List<CouponDtlVO> myCouponList =  couponDtlsMapper.selectCouponDtlsList(couponDtlVo);
			
			// 2-1. 같은 난수로 등록된 쿠폰이 있는경우
			if(myCouponList.size() > 0) {
				
				result = -99 ;//이미 등록된 쿠폰입니다.
			    
			// 2-2. 등록한다.   
			}else {
				
				// 쿠폰 정보들 들어있는 Vo
				CouponDtlVO checkCouponDtlVO = checkCouponList.get(0);// checkCouponVO 이걸 가지고 나머지 여러 조건을 적용

				//int isuResult = 0;
				
				// couponEvent 번호 셋팅  
				couponDtlVo.setCouponEventNo(checkCouponDtlVO.getCouponEventNo());
				
				// 1.CouponType 관련 체크	
				result = checkCouponType(checkCouponDtlVO.getCouponType(), couponDtlVo, result);
				
				// 2.SeCode 관련 체크
				result = checkSeCode(checkCouponDtlVO.getCouponSeCode(), couponDtlVo, result);
				
				// 3.MetalCode 값에 따른 체크
				result = checkSeCode(checkCouponDtlVO.getCouponSeCode(), couponDtlVo, result);

				// 결과값이 1이면 인서트 
				if(result > 0) {
					couponDtlsMapper.insertCouponIsu(couponDtlVo);
					//commonService.insertTableHistory("COUPON_ISU", couponVo);  -> 1. 나중에 추가
				}
				
			}
			
		// 중복 두개 이상의 쿠폰이 존재
		} else if(checkCouponList.size() > 1){
			
			result = -97 ;
		
		// 쿠폰이 없음
		} else {
			result = -98 ;//
		}
	
		return result;
    }
    
    // 쿠폰 타입 : CouponType 관련 처리
    public int checkCouponType(String couponType, CouponDtlVO couponDtlVo, int result) throws Exception {
    	    	
    	if("03".equals(couponType)) {
    		// 쿠폰업체 지정 테이블 조회(COUPON_ENTRPS_APPN_BAS)
    		int entResult = couponDtlsMapper.selectCouponEntrpsAppn(couponDtlVo);
			
			if(entResult > 0) {
				result = 1;
			}else {
				result = -94 ;
				log.debug("result : " + "해당쿠폰을 등록할수 있는 업체가 아닙니다.");
			}
    	}else if("01".equals(couponType)) {
    		result = -95 ;
			log.debug("result : " + "입력쿠폰 정책 오픈 안됨. 관리자에 문의 하시기 바랍니다.");
    	}else {
    		result = -96 ;
    		log.debug("result : " + "나머지 쿠폰 정책 오픈안됨. 관리자에 문의 하시기 바랍니다.");
    	}
    	
    	return result;
    }

    
    // 구분 코드 : CouponSeCode 관련 처리
    public int checkSeCode(String couponType, CouponDtlVO couponDtlVo, int result) throws Exception {

    	return result;
    }
    
    
    // 쿠폰 타입 : CouponSeCode 관련 처리
    public int checkMetalCode(String couponType, CouponDtlVO couponDtlVo, int result) throws Exception {

    	return result;
    }

	/**
	 * <pre>
	 * 처리내용: 마이페이지 쿠폰 목록 조회
	 * </pre>
	 * @date 2023. 5. 9.
	 * @author hamyoonsic
	 * @history
	 * -----------------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------------
	 * 2022. 5. 9.				hamyoonsic			최초작성
	 * -----------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@Override
	public Map<String, Object> selectCouponList(CouponVO couponVO) throws Exception {
		Map<String, Object> couponInfoMap = new HashMap<>();
		//마이페이지에서 호출시
		couponVO.setOpenPage("MyPage");
		CouponDtlVO vo = new CouponDtlVO();
		vo.setEntrpsNo(couponVO.getEntrpsNo());
		
		//List<CouponVO> couponList = couponDtlsMapper.getCouponListForMypage(couponVO);
		List<CouponDtlVO> couponList = couponDtlsMapper.selectCouponDtlsList(vo);
		int possiblilityCount=0;
		int closingCount =0;
		if(couponList != null) {
			for(CouponDtlVO resultVO : couponList){
				Optional<String> sttusCode = Optional.ofNullable(resultVO.getCouponSttusCode());
				if (sttusCode.isPresent()) {
					//null이 아닌 경우
					String value = sttusCode.get();
					if("01".equals(value) || "N".equals(value)) {
						if("N".equals(resultVO.getCouponSttusCode())){
							resultVO.setCouponSttusCode("01");
						}
						possiblilityCount++;
					} else {
						if ("Y".equals(resultVO.getCouponSttusCode())){
							resultVO.setCouponSttusCode("02");
						}
						closingCount++;
					}
				} else {
					throw new Exception("COUPON STTUS NULL ERROR :: CouponServiceImpl >> selectCouponList");
				}
			}
		}
		couponInfoMap.put("couponList",couponList);
		
		if(couponList != null) { //SPARROW 372657: null-check 추가
			couponInfoMap.put("totCount", couponList.size());
		} else {
			couponInfoMap.put("totCount", 0);
		}
		
		couponInfoMap.put("possiblilityCount",possiblilityCount);
		couponInfoMap.put("closingCount",closingCount);
		return couponInfoMap;
	}
	
	/**
     * <pre>
     * 처리내용: 미사용, 사용중 할인 쿠폰 목록 조회
     * </pre>
     * @date 2023. 7. 18.
     * @author hyunjin05
     * @history
     * -----------------------------------------------------
     * 변경일					작성자				변경내용
     * -----------------------------------------------------
     * 2023. 7. 18.			hyunjin05			최초작성
     * 2023. 11. 13.		hyunjin0512			쿠폰 조회 테이블 수정
     * -----------------------------------------------------
     * @param CouponVO
     * @return
     * @throws Exception
     */
    @Override
    public List<CouponVO> couponList(CouponVO couponVO, String couponTyCode) throws Exception {
    	List<CouponVO> couponList = new ArrayList<CouponVO>();
    		couponVO.setCouponTyCode(couponTyCode);
    	try {
    		couponList.addAll(couponDtlsMapper.getCouponList(couponVO));
		} catch (Exception e) {
			// TODO: handle exception
		}
    	
        return couponList;
    }
}
