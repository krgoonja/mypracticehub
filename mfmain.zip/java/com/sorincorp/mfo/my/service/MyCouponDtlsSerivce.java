package com.sorincorp.mfo.my.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.mfo.my.model.CouponDtlVO;

public interface MyCouponDtlsSerivce {
    
    /**
     * <pre>
     * 처리내용: 마이페이지 쿠폰내역 리스트 조회
     * </pre>
     * @date 2022. 7. 26.
     * @author sumin95
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 7. 26.             sumin95             최초작성
     * ------------------------------------------------
     * @return
     * @throws Exception
     */
    List<CouponDtlVO> selectCouponDtlsList(CouponDtlVO couponDtlVo);
    
    /**
     * <pre>
     * 처리내용: 마이페이지 사용자지정쿠폰 등록
     * </pre>
     * @date 2022. 7. 26.
     * @author sumin95
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 7. 26.             sumin95             최초작성
     * ------------------------------------------------
     * @return
     * @throws Exception
     */
    int updateCouponDtlsList(CouponDtlVO couponDtlVo) throws Exception;

    /**
     * <pre>
     * 처리내용: 마이페이지 쿠폰 목록 조회
     * </pre>
     * @date 2023. 5. 9.
     * @author hamyoonsic
     * @history
     * -----------------------------------------------------
     * 변경일					작성자				변경내용
     * -----------------------------------------------------
     * 2022. 5. 9.				hamyoonsic			최초작성
     * 2023. 11. 13.			hyunjin0512			쿠폰 조회 테이블 수정
     * -----------------------------------------------------
     * @param vo
     * @return
     * @throws Exception
     */
    Map<String, Object> selectCouponList(CouponVO couponVO) throws Exception;

//	int checkCouponType(String couponType, CouponVO couponVo) throws Exception;
     

    /**
     * <pre>
     * 처리내용: 미사용, 사용중 상태의 단가, 배송비 할인 쿠폰 목록 조회
     * </pre>
     * @date 2023. 7. 18.
     * @author hyunjin05
     * @history
     * -----------------------------------------------------
     * 변경일					작성자				변경내용
     * -----------------------------------------------------
     * 2023. 7. 18.			hyunjin05			최초작성
     * 2023. 11. 13.		hyunjin0512			쿠폰 조회 테이블 수정
     * -----------------------------------------------------
     * @param CouponVO
     * @return
     * @throws Exception
     */
    List<CouponVO> couponList(CouponVO couponVO, String couponTyCode) throws Exception;
}
