package com.sorincorp.mfo.my.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
//import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.mfo.my.model.DlivyVO;
import com.sorincorp.mfo.my.model.DlvyVO;
import com.sorincorp.mfo.my.model.OrSetleDtlsInfoVO;
import com.sorincorp.mfo.my.model.OrSetleInfoVO;
import com.sorincorp.mfo.my.model.OrderDtlsVO;
import com.sorincorp.mfo.my.model.VhcleInfoVO;

public interface OrderDtlsDetailService {

	/**
	 * <pre>
	 * 처리내용: 주문상세내역을 조회한다.
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param seachVo
	 * @return
	 * @throws Exception
	 */
	public OrderDtlsVO selectOrderDtlsDetail(OrderDtlsVO seachVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 매매계약서 내부 거래명세서, 세금계산서 ozReport 실행시 필요한 파라미터 조회한다.
	 * </pre>
	 * @date 2021. 9. 27.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 27.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> selectTaxBillInfo(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 출고 정보 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 19.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param seachVo
	 * @return
	 * @throws Exception
	 */
	public List<DlivyVO> selectDlivyList(String seachVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 차량종류 공통코드 초회
	 * </pre>
	 * @date 2021. 7. 21.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 21.			srec0048			최초작성
	 * 2022. 12. 			srec0051		쿼리수정
	 * 2023. 07				srec0051		차량 고도화
	 * ------------------------------------------------
	 * @param vhcleInfoVO
	 * @return
	 * @throws Exception
	 */
	public List<CommonCodeVO> selectVhcleGroupCodeList(String sleMthdCode, String metalCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 등록 차량 조회
	 * </pre>
	 * @date 2021. 7. 21.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 21.			srec0048			최초작성
	 * 2023. 07				srec0051		차량 고도화
	 * ------------------------------------------------
	 * @param vhcleInfoVO
	 * @return
	 * @throws Exception
	 */
	public List<VhcleInfoVO> selectVhcleInfoList(VhcleInfoVO vhcleInfoVO) throws Exception;


	/**
	 * <pre>
	 * 처리내용: 배송지 정보를 조회한다.
	 * </pre>
	 * @date 2021. 7. 16.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 16.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param seachVo
	 * @return
	 * @throws Exception
	 */
	public DlvyVO selectDlvrg(String seachVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 배송지 정보를 수정한다.
	 * </pre>
	 * @date 2021. 7. 16.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 16.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param dlvyVO
	 * @throws Exception
	 */
	public Map<String, Object> insertNewDlvrgInfo(DlvyVO dlvyVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 배송차수 리스트을 조회한다.
	 * </pre>
	 * @date 2021. 7. 22.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 22.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoVO
	 * @return
	 */
	public Map<String, Boolean> selectDlvyOdrList(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 차량정보를 등록 및 수정한다.
	 * </pre>
	 * @date 2021. 7. 22.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 22.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoArr
	 */
	public Map<String, Object> modifyVhcleInfoList(List<VhcleInfoVO> vhcleInfoArr) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 성적서&패킹리스트를 조회한다.
	 * </pre>
	 * @date 2021. 9. 13.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 13.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	public List<Map<String, Object>> selectScreofePackngList(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 직인을 조회한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param response
	 * @throws Exception
	 */
	void selectSorinSign(HttpServletResponse response) throws Exception;

	/**
	 * <pre>
	 * 물류 휴일 목록 조회
	 * </pre>
	 * @date 2022. 2. 8.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 8.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	public List<String> selectHolidayList(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 이벤트 휴일에 포함되는지 조회
	 * </pre>
	 * @date 2022. 2. 8.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 8.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoVO
	 * @return
	 * @throws Exception
	 */
	int checkHolidayYn(VhcleInfoVO vhcleInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 결제 수단 정보를 조회
	 * </pre>
	 * @date 2022. 8. 5.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 5.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param searchVo
	 * @return
	 */
	public OrSetleInfoVO selectOrSetleInfo(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 결제 수단에 따른 결제 정보를 조회한다.
	 * </pre>
	 * @date 2023. 12. 8.
	 * @author srec0051
	 * @param setleInfo
	 * @return
	 * @throws Exception
	 */
	public OrSetleInfoVO selectOrSetleInfo(OrSetleInfoVO setleInfo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 입금확인서 정보를 조회한다.
	 * </pre>
	 * @date 2022. 8. 9.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 9.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	public OrSetleInfoVO selectRcpmnyCnfrmnInfo(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 신용보증 주문의 상환버튼 노출 여부를 조회한다.
	 * </pre>
	 * @date 2022. 9. 16.
	 * @author srec0066
	 * @param orderSetleInfo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 16.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public String getRepyPossibleAt(OrSetleInfoVO orderSetleInfo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기준일자, 일수를 받아 계산된 영업일과 날짜변경가능여부를 리턴
	 * </pre>
	 * @date 2022. 10. 19.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 19.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param dlvyVO
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> getSettleSttusDe(DlvyVO dlvyVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 쿠폰 차감내역 조회.
	 * </pre>
	 *
	 * @param orderNo
	 * @return
	 * @date 2023. 5. 12.
	 * @author hamyoonsic
	 * @history ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ---------------------------------------------------------
	 * 2023. 5. 12.			hamyoonsic				최초작성
	 * ---------------------------------------------------------
	 */

//	public Map<String, Object> selectCouponDdctList(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 평균가 환불 내역 조회
	 * </pre>
	 * @date 2023. 12. 8.
	 * @author srec0051
	 * @param setleInfo
	 * @return
	 */
	public List<OrSetleDtlsInfoVO> getAvrgRefundSetleList(OrSetleInfoVO setleInfo) throws Exception;

}
