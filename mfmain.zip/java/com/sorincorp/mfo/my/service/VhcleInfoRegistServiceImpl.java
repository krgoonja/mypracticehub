package com.sorincorp.mfo.my.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.deliveryCarMng.model.DeliveryCarMngCommVO;
import com.sorincorp.comm.deliveryCarMng.service.DeliveryCarMngCommService;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.mfo.config.UserInfoUtil;
import com.sorincorp.mfo.login.model.Account;
import com.sorincorp.mfo.my.mapper.VhcleInfoRegistMapper;
import com.sorincorp.mfo.my.model.VhcleInfoRegistVO;
import com.sorincorp.mfo.my.model.VhcleInfoVO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class VhcleInfoRegistServiceImpl implements VhcleInfoRegistService {
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Autowired
	private HttpClientHelper httpClientHelper;

	@Autowired
	private DeliveryCarMngCommService deliveryCarMngCommService;
	
	/** SMS 발송 서비스 **/
	@Autowired
	private SMSService smsService;
	
	/** 공통  **/
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private VhcleInfoRegistMapper vhcleInfoRegistMapper;
	
	/** oms 송신 url **/
	@Value("${order.api.lo.oms.url}")
	private String loOmsUrl;

	@Override
	public List<VhcleInfoRegistVO> selectVhcleInfoRegistList(VhcleInfoRegistVO vhcleInfoRegistVO) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		
		if(account == null) {
			throw new Exception("로그인 정보가 존재하지 않습니다.");
		}
		
		//int pageIndex = vhcleInfoRegistVO.getPageIndex();					// default : 1
		//int recordCountPerPage = vhcleInfoRegistVO.getRecordCountPerPage();	// default : 10
		
		vhcleInfoRegistVO.setEntrpsNo(account.getEntrpsNo());
		vhcleInfoRegistVO.setSecode(account.getSecode());
		vhcleInfoRegistVO.setMberNo(account.getMberNo());
		//vhcleInfoRegistVO.setFirstIndex((pageIndex-1)*recordCountPerPage+1);
		//vhcleInfoRegistVO.setLastIndex(pageIndex*recordCountPerPage);
		
		List<VhcleInfoRegistVO> vhcleInfoRegistList = vhcleInfoRegistMapper.selectVhcleInfoRegistList(vhcleInfoRegistVO);
		
		for (VhcleInfoRegistVO vhcleInfoRegistVO2 : vhcleInfoRegistList) {
			if(vhcleInfoRegistVO2.getIsMultiBl()) {
				vhcleInfoRegistVO2.setMultiBlList(vhcleInfoRegistMapper.selectMultiBlList(vhcleInfoRegistVO2.getOrderNo()));
			}
		}
		
		return vhcleInfoRegistList;
	}
	
	@Override
	public int selectVhcleInfoRegistListTotCnt(VhcleInfoRegistVO vhcleInfoRegistVO) throws Exception {
		return vhcleInfoRegistMapper.selectVhcleInfoRegistListTotCnt(vhcleInfoRegistVO);
	}
	
	@Override
	public int getMultiBlListSize(String orderNo) throws Exception {
		return vhcleInfoRegistMapper.getMultiBlListSize(orderNo);
	}

	@Override
	public VhcleInfoRegistVO selectOrOrderBas(String orderNo, String orderSn) throws Exception {
		return vhcleInfoRegistMapper.selectOrOrderBas(orderNo, orderSn);
	}

	@Override
	public List<VhcleInfoVO> selectOrVhcleInfoBas(String orderNo, String orderSn) throws Exception {
		List<VhcleInfoVO> result = vhcleInfoRegistMapper.selectOrVhcleInfoBas(orderNo, orderSn);
		
		if (!result.isEmpty()) {
			for (VhcleInfoVO vhcleInfoVO : result) {
				if (StringUtils.isNotBlank(vhcleInfoVO.getDrverTlphonNo())) {
					vhcleInfoVO.setDrverTlphonNo(StringUtil.formatPhone(CryptoUtil.decryptAES256(vhcleInfoVO.getDrverTlphonNo())));
				}
			}
		}
		
		return result;
	}

	@Override
	public List<CommonCodeVO> selectVhcleGroupCodeList(VhcleInfoRegistVO vhcleInfoRegistVO) throws Exception{
		return vhcleInfoRegistMapper.selectVhcleGroupCodeList(vhcleInfoRegistVO);
	}

	@Override
	public List<DeliveryCarMngCommVO> selectMbVhcleInfoBas() throws Exception{
		List<DeliveryCarMngCommVO> mbVhcleInfoList = deliveryCarMngCommService.selectMbVhcleInfoBas(userInfoUtil.getEntripsNo());
		
		int listSize = mbVhcleInfoList.size();
		
		return mbVhcleInfoList.subList(0, listSize <= 10 ? listSize : 10);
	}

	@Override
	public List<DeliveryCarMngCommVO> selectMbDrvArticlInfoBas() throws Exception {
		List<DeliveryCarMngCommVO> mbDrvArticlInfoList = deliveryCarMngCommService.selectMbDrvArticlInfoBas(userInfoUtil.getEntripsNo());
		
		int listSize = mbDrvArticlInfoList.size();
		
		return mbDrvArticlInfoList.subList(0, listSize <= 10 ? listSize : 10);
	}

	@Override
	public boolean insertVhcleInfo(List<VhcleInfoVO> vhcleInfoList) throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		String dlivyRequstDe = "";
		
		if(account == null) {
			throw new Exception("로그인 정보가 존재하지 않습니다.");
		}
		
		String mberId = account.getId();
		
		if (vhcleInfoList.isEmpty()) {
			throw new Exception("등록할 차량정보가 없습니다.");
		}
		
		// 24-06-11 변경사항 : 해당 주문번호에 대한 모든 차수 정보를 SMS 내용에 담기 위해 주문번호를 조건으로 나머지 차수 정보도 조회
		List<VhcleInfoVO> vhcleOrderDtlList = vhcleInfoRegistMapper.selectOrVhcleOrderDtlList(vhcleInfoList.get(0).getOrderNo(), vhcleInfoList);
		
		for (VhcleInfoVO vo : vhcleOrderDtlList) {
			vo.setDrverTlphonNo(CryptoUtil.decryptAES256(vo.getDrverTlphonNo()));	// 복호화
		}
		
		vhcleInfoList.addAll(vhcleOrderDtlList);
		
		// 24-06-11 변경사항 : 입력된 값이 빈 값일 시, 대체 데이터를 INSERT하도록 세팅
		for (VhcleInfoVO vhcleInfoVO : vhcleInfoList) {
			if (StringUtils.isNotBlank(vhcleInfoVO.getDrverTlphonNo())) {
				vhcleInfoVO.setDrverTlphonNo(CryptoUtil.encryptAES256(vhcleInfoVO.getDrverTlphonNo().replace("-", ""))); // 암호화
			} else {	
				vhcleInfoVO.setDrverTlphonNo(CryptoUtil.encryptAES256("00000000000")); // 암호화
			}
			
			if (StringUtils.isBlank(vhcleInfoVO.getVhcleNo())) {
				vhcleInfoVO.setVhcleNo("미지정");
			}
			
			if (StringUtils.isBlank(vhcleInfoVO.getDrverNm())) {
				vhcleInfoVO.setDrverNm("미지정");
			}
			
			vhcleInfoVO.setMberId(mberId);
			
			//기존출고요청일 조회
			dlivyRequstDe = vhcleInfoRegistMapper.selectDlivyRequstDe(vhcleInfoVO.getOrderNo());
			// 차량정보 등록 및 수정
			try {
				
				// update 로직 대응을 위한 기존 key값 backup
				int originVhclOrderSn = vhcleInfoVO.getDlvyOdr();
				int originVhcleSn = vhcleInfoVO.getVhcleSn();
				
				vhcleInfoRegistMapper.insertVhcleBas(vhcleInfoVO);
				vhcleInfoRegistMapper.insertVhcleOrderDtl(vhcleInfoVO);
				
				// update 대상일 시, update 하면서 가져온 최신 key값을 기존 key값으로 대체
				if(StringUtils.equals(vhcleInfoVO.getMode(), "saved")) {
					vhcleInfoVO.setDlvyOdr(originVhclOrderSn);
					vhcleInfoVO.setVhcleSn(originVhcleSn);
				}
				
				//히스토리 생성
				Map<String,String> keyValue = new HashMap<>();
				keyValue.put("VHCLE_SN",String.valueOf(vhcleInfoVO.getVhcleSn()));
				commonService.insertTableHistory("OR_VHCLE_BAS", keyValue);
				
				keyValue = new HashMap<>();
				keyValue.put("VHCLE_ORDER_SN",String.valueOf(vhcleInfoVO.getDlvyOdr()));
				commonService.insertTableHistory("OR_VHCLE_ORDER_DTL", keyValue);

				//기존 출고요청일과 업데이트하려는 차량입고일 비교
				int result = DateUtil.intervalDay(dlivyRequstDe,vhcleInfoVO.getVhcleWrhousngDe());
				//하루이상 차이날 경우(result가 양수면 차량입고일이 미래, 음수면 과거)
				if(result != 0) {
					//출고요청일 업데이트
					vhcleInfoRegistMapper.updateDlivyRequstDe(vhcleInfoVO);
					dlivyRequstDe = vhcleInfoVO.getVhcleWrhousngDe();
					//히스토리 생성
					keyValue = new HashMap<>();
					keyValue.put("ORDER_NO",vhcleInfoVO.getOrderNo());
					commonService.insertTableHistory("OR_ORDER_BAS", keyValue);
				}
			} catch (Exception e) {
				log.error(e.getMessage());
				return false;
			}
		}

		// 차수 순서대로 이후 로직을 실행하기 위해 정렬
		vhcleInfoList.sort((vo1, vo2) -> {
			if(vo1.getDlvyOdr() > vo2.getDlvyOdr())
				return 1;
			else
				return -1;
		});

		// 24-06-12 변경사항 : 메세지에서 차수 정보를 기존의 차수 정보(1차수, 2차수..)와 동일하게 구성할 수 있도록 메세지 처리용 차수 데이터 세팅
		int dlvyOdrForMsg = 0;
		
		for (VhcleInfoVO vo : vhcleInfoList) {
			vo.setDlvyOdrForMsg(++dlvyOdrForMsg);
		}
		
		Map<String, Object> resObj = null;
		try {
			// 차량정보 등록 및 수정 고객 SMS
			sendMessageToCustomer(vhcleInfoList, "50");
			// 배송기사 SMS 발송
			sendMessageToDriver(vhcleInfoList, "107");

		    // 자차 자량정보 등록 및 수정 api
			// FO/BO 호출 구분 (1:FO, 2:BO)
			resObj = httpClientHelper.postCallApi(loOmsUrl + "/sendDlvyVhcleInfo/1", vhcleInfoList);
			log.debug("차량정보 등록 및 수정 api resObj ::: "+ resObj);
			if (resObj.isEmpty()) {
				throw new Exception("통신장애");
			}

        } catch (Exception e) {
            log.error("차량정보 API 실패 ===> ", e.getMessage());
			// 자차 자량정보 등록 및 수정 api 오류 SMS
			callSms(vhcleInfoList.get(0));
            return false;
        }
		
		return true;
	}

	@Override
	public List<DeliveryCarMngCommVO> insertDeliveryCar(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception {
		// SPARROW 372662: NULL-CHECK
		if (userInfoUtil.getAccountInfo() == null) {
        	throw new NullPointerException("NULL EXCEPTION: Account Info is NULL");
        } else {
        	deliveryCarMngCommVO.setEntrpsNo(userInfoUtil.getEntripsNo());
    		deliveryCarMngCommVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
    		deliveryCarMngCommVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
        }
		
		int result = deliveryCarMngCommService.insertDeliveryCar(deliveryCarMngCommVO);
		
		if(result > 0) {
			return selectMbVhcleInfoBas();
		} else {
			return null;
		}
	}

	@Override
	public List<DeliveryCarMngCommVO> insertDeliveryDriver(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception {
		// SPARROW 372662: NULL-CHECK
		if (userInfoUtil.getAccountInfo() == null) {
        	throw new NullPointerException("NULL EXCEPTION: Account Info is NULL");
        } else {
        	deliveryCarMngCommVO.setEntrpsNo(userInfoUtil.getEntripsNo());
    		deliveryCarMngCommVO.setFrstRegisterId(userInfoUtil.getAccountInfo().getId());
    		deliveryCarMngCommVO.setLastChangerId(userInfoUtil.getAccountInfo().getId());
        }
		
		int result = deliveryCarMngCommService.insertDeliveryDriver(deliveryCarMngCommVO);
		
		if(result > 0) {
			return selectMbDrvArticlInfoBas();
		} else {
			return null;
		}
	}

	@Override
	public Map<String, Object> getSettleSttusDe(VhcleInfoRegistVO vhcleInfoRegistVO) throws Exception {
		Map<String, Object> map = new HashMap<>();
		boolean result = false; //변경가능한 출고예정일이면 true, 변경불가하면 false 리턴

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
		String strToday = DateUtil.getNowDate();
		int dayCnt = vhcleInfoRegistMapper.selectDayCntBySetleMthd(vhcleInfoRegistVO.getOrderNo()); //반환날짜 계산을 위한 계산일수 조회
		String bsnDe = vhcleInfoRegistMapper.getSettleSttusDe(vhcleInfoRegistVO.getDlivyRequstDe(), dayCnt); 			 //계산된 반환날짜 = 변경될 결제예정일
		log.debug("변경예정 결제일 >>> " + bsnDe);

		// 날짜 비교위해 데이터 convert
		Date payDe = simpleDateFormat.parse(bsnDe);							   //결제예정일(예상)
        Date today = simpleDateFormat.parse(strToday);         				   //변경시점(현재)

        int compare = payDe.compareTo(today);
		if(compare > 0) { //결제예정일(예상) > 현재
			result = true;
		}

		map.put("yn", result);
        map.put("returnDe", bsnDe);

		return map;
	}
	
	/**
	 * 고객 대상 메세지 발송 메소드
	 */
	private void sendMessageToCustomer(List<VhcleInfoVO> vhcleInfoArr, String templateNum) throws Exception {
		log.warn("[VhcleInfoRegistServiceImpl][sendMessageToCustomer] IN");
		try {
			SMSVO smsVO = new SMSVO();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));

			Map<String, String> smsMap = new HashMap<>();
			VhcleInfoVO vo = null;
			String smsList = "";
			
			// 메세지 내용에 1부터 시작하는 차수를 생성하여 보여주도록 하기 위해 소스 변경
			// 임시배송차수 For 메세지
			int tempDlvyOdrForMsg = 1;

			for(VhcleInfoVO voInfoVO : vhcleInfoArr) {
				// 삭제 대상 차수 정보는 내용으로 포함되지 않도록 로직 skip 처리
				if(StringUtils.equals(voInfoVO.getDeleteAt(), "Y")) {
					continue;
				}
				
				smsList += tempDlvyOdrForMsg++ + "회차";
				if(!String.valueOf(voInfoVO.getDlvyOdrForMsg()).isEmpty() && !voInfoVO.getVhcleWrhousngDe().isEmpty() && !voInfoVO.getDrverNm().isEmpty() && !voInfoVO.getVhcleNo().isEmpty() && !voInfoVO.getDrverTlphonNo().isEmpty()) {
					smsList += "(차량입고일: " + voInfoVO.getVhcleWrhousngDe() + ")" + "\n"
							+	voInfoVO.getDrverNm() + "-" + voInfoVO.getVhcleNo() + " (" + StringUtil.formatPhone(CryptoUtil.decryptAES256(voInfoVO.getDrverTlphonNo())) + ")" + "\n" + "\n";
				}else {
					smsList += "(미등록)" + "\n" + "\n";
				}
				vo = voInfoVO;
			}

			//고객 전화번호
			String ordrrMoblphonNo = vhcleInfoRegistMapper.selectSmsUserInfo(vo);

			// ORDRR_MOBLPHON_NO(주문자 휴대폰 번호) 복호화
			if(StringUtils.isNotEmpty(ordrrMoblphonNo)) {
				try {
					log.debug("주문자 휴대폰 번호 복호화 전 ==================>" + ordrrMoblphonNo);
					ordrrMoblphonNo = CryptoUtil.decryptAES256(ordrrMoblphonNo);
					log.debug("주문자 휴대폰 번호 복호화 후 ==================>" + ordrrMoblphonNo);
				} catch (Exception e) {
					log.error("VhcleInfoRegistServiceImpl sendMessageToCustomer ORDRR_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
			}
			smsVO.setPhone(ordrrMoblphonNo);
			smsVO.setCommerceNtcnAt("N"); // 커머스 알림 여부

			switch(templateNum) {
			case "50" :
				smsMap = vhcleInfoRegistMapper.selectSmsInfo(vo);
				smsMap.put("smsList", smsList);

				break;
			}

			smsMap.put("templateNum", templateNum);

			log.debug(">> smsMap toString : " + smsMap.toString());

			smsService.insertSMS(smsVO, smsMap);

		} catch (Exception e) {
			log.error("[VhcleInfoRegistServiceImpl][sendMessageToCustomer] " + ExceptionUtils.getStackTrace(e));
		}
	}
	
	/**
	 * 배송기사 대상 메세지 발송 메소드
	 */
	private void sendMessageToDriver(List<VhcleInfoVO> vhcleInfoArr, String templateNum) throws Exception {
		log.warn("[VhcleInfoRegistServiceImpl][sendMessageToDriver] IN");
		try {
			for(VhcleInfoVO voInfoVO : vhcleInfoArr) {
				SMSVO smsVO = new SMSVO();
				smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
				smsVO.setCommerceNtcnAt("N"); // 커머스 알림 여부

				VhcleInfoVO vo = null;
				Map<String, String> smsMap = new HashMap<>();

				String status = "";
				String prevPhoneNo = "";

				String newSmsList = "";
				String prevSmsList = "";

				//내부사용자 전송용 메시지 내용 별도로 세팅
				String innerDepartmentSmsList = "";

				if(voInfoVO.getMode().equals("new")) {
					status = "등록";
				}else if(voInfoVO.getMode().equals("saved")) {
					if(voInfoVO.getDeleteAt().equals("Y")) {
						status = "삭제";
					}else if(voInfoVO.getDeleteAt().equals("N")) {
						VhcleInfoVO vhclHist = vhcleInfoRegistMapper.selectOrVhcleInfoHst(voInfoVO);
						
						if(vhclHist == null)
							continue;
						
						//기저장되어있는 휴대폰 번호 하이픈 제거 후 재복호화
						vhclHist.setDrverTlphonNo(CryptoUtil.encryptAES256(CryptoUtil.decryptAES256(vhclHist.getDrverTlphonNo()).replace("-", "")));
						
						//배송완료된 차수 정보 문자 전송 제외
						if(vhclHist.getDlvyProgrsSttusCode() < 30
								&& (!vhclHist.getDrverNm().equals(voInfoVO.getDrverNm())
								|| !vhclHist.getDrverTlphonNo().equals(voInfoVO.getDrverTlphonNo())
								|| !vhclHist.getVhcleNo().equals(voInfoVO.getVhcleNo())
								|| !vhclHist.getVhcleWrhousngDe().equals(voInfoVO.getVhcleWrhousngDe()))) {//배송정보 변경된 경우
							status = "변경";

							//변경전 폰번호
							prevPhoneNo = vhclHist.getDrverTlphonNo();

							//변경전 차량등록정보
							prevSmsList += voInfoVO.getDlvyOdrForMsg() + "회차";
							prevSmsList += "(차량입고일: " + vhclHist.getVhcleWrhousngDe() + ")" + "\n"
										+	vhclHist.getDrverNm() + "-" + vhclHist.getVhcleNo() + " (" + StringUtil.formatPhone(CryptoUtil.decryptAES256(vhclHist.getDrverTlphonNo())) + ")" + "\n" + "\n";
						}else {
							continue;
						}
					}
				}
				//변경된 차량등록정보
				newSmsList += voInfoVO.getDlvyOdrForMsg() + "회차";
				newSmsList += "(차량입고일: " + voInfoVO.getVhcleWrhousngDe() + ")" + "\n"
						   +	voInfoVO.getDrverNm() + "-" + voInfoVO.getVhcleNo() + " (" + StringUtil.formatPhone(CryptoUtil.decryptAES256(voInfoVO.getDrverTlphonNo())) + ")" + "\n" + "\n";

				vo = voInfoVO;

				String phoneNo = String.valueOf(voInfoVO.getDrverTlphonNo());
				if(StringUtils.isNotEmpty(phoneNo)) {
					try {
						phoneNo = CryptoUtil.decryptAES256(phoneNo);
						voInfoVO.setDrverTlphonNo((phoneNo));
						if(StringUtils.isNotEmpty(prevPhoneNo)) prevPhoneNo = CryptoUtil.decryptAES256(prevPhoneNo);
					} catch (Exception e) {
						log.error("VhcleInfoRegistServiceImpl sendMessageToDriver DRVER_TLPHON_NO CryptoUtil.decryptAES256 ERROR " + ExceptionUtils.getStackTrace(e));
					}
				}

				smsMap = vhcleInfoRegistMapper.selectDriverSmsInfo(vo);
				smsMap.put("templateNum", templateNum);
				smsMap.put("excpSndngOptnAt", "N"); // 예외 발송 옵션 여부, N일 경우 SMS 수신자만 발송한다.

				//배송기사 메시지 전송
				if(status.equals("변경")) {
					if(StringUtils.isNotEmpty(prevPhoneNo)) {
						smsMap.put("smsList", prevSmsList);
						smsMap.put("status", "삭제");
						smsVO.setPhone(prevPhoneNo);

						log.debug(">> smsMap toString : " + smsMap.toString());
						smsService.insertSMS(smsVO, smsMap);
					}

					if(StringUtils.isNotEmpty(voInfoVO.getDrverTlphonNo())) {
						smsVO = new SMSVO();
						smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
						smsVO.setCommerceNtcnAt("N");

						smsMap.put("smsList", newSmsList);
						smsMap.put("status", "등록");
						smsVO.setPhone(voInfoVO.getDrverTlphonNo());

						log.debug(">> smsMap toString : " + smsMap.toString());
						smsService.insertSMS(smsVO, smsMap);
					}

					innerDepartmentSmsList = StringUtils.removeEnd(prevSmsList, "\n") + "[변경]" + "\n" + newSmsList;
				}else {
					if(StringUtils.isNotEmpty(voInfoVO.getDrverTlphonNo())) {
						smsMap.put("smsList", newSmsList);
						smsMap.put("status", status);
						smsVO.setPhone(voInfoVO.getDrverTlphonNo());

						log.debug(">> smsMap toString : " + smsMap.toString());
						smsService.insertSMS(smsVO, smsMap);
					}

					innerDepartmentSmsList = newSmsList;
				}

				// 내부사용자 별도 전송
				smsMap.put("smsList", innerDepartmentSmsList);
				smsMap.put("status", status);
				smsMap.put("commerceNtcnAt", "N"); // 추가 수신사 커머스 알림 여부 따로 설정
				smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
				smsService.insertSMS(null, smsMap);
			}
		} catch (Exception e) {
			log.error("[VhcleInfoRegistServiceImpl][sendMessageToDriver] " + ExceptionUtils.getStackTrace(e));
		}
	}
	
	/**
	 * SMS 서비스를 호출
	 */
	private synchronized void callSms(VhcleInfoVO vhcleInfoVO) {
		log.warn("[VhcleInfoRegistServiceImpl][callSms] IN");
		// 템플릿에 따라 SMS 전송을 처리한다.
		procSms(vhcleInfoVO, "49", "자차 자량정보 등록 및 수정 api 실패");
	}
	
	/**
	 * 템플릿에 따라 SMS 전송 처리. (내부 사용자 SMS)
	 */
	private void procSms(VhcleInfoVO vhcleInfoVO, String templateNum, String addStr) {
		log.warn("[VhcleInfoRegistServiceImpl][procSms] IN");

		try {
			Map<String, String> smsMap = new HashMap<>();

			switch (templateNum) {
				case "49":
					smsMap.put("orderNo", vhcleInfoVO.getOrderNo()); // 주문번호
					smsMap.put("returnMsg", addStr); // 자차 자량정보 등록 및 수정 IF시 오류발생
					break;
			}

			smsMap.put("templateNum", templateNum);

			// 자차 자량정보 등록 및 수정 api 오류 SMS 전송
			smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
			smsService.insertSMS(null, smsMap);
		} catch (Exception e) {
			log.error("[VhcleInfoRegistServiceImpl][procSms] " + ExceptionUtils.getStackTrace(e));
		}
	}

	@Override
	public List<String> selectHolidayList(String orderNo) {
		return vhcleInfoRegistMapper.selectHolidayList(orderNo);
	}

	@Override
	public int checkHolidayYn(VhcleInfoVO vhcleInfoVO) {
		return vhcleInfoRegistMapper.checkHolidayYn(vhcleInfoVO);
	}
}
