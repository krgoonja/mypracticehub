package com.sorincorp.mfo.my.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.mfo.my.model.InqryDtlsVO;
import com.sorincorp.mfo.mb.model.MbEntrpsGradVO;
import com.sorincorp.mfo.my.mapper.DashboardMapper;
import com.sorincorp.mfo.my.model.CorpInfoMgrVO;
import com.sorincorp.mfo.my.model.DashboardVO;
import com.sorincorp.mfo.my.model.PaytEsamtVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DashboardServiceImpl implements DashboardService {

	@Autowired
	private DashboardMapper dashboardMapper;
	
	/**
	 * 회원 기본 정보를 조회한다.
	 */
	@Override
	public CorpInfoMgrVO getCorpInfoMgrVO(String mberNo) throws Exception {
		CorpInfoMgrVO returnvo = new CorpInfoMgrVO();
		try {
			returnvo = dashboardMapper.getCorpInfoMgrVO(mberNo);
		} catch (Exception e) {
		
		}
		return returnvo;
	}
	
	/**
	 * 상단 대시보드 결제수단을 조회한다.
	 * 암복호화 로직 추가
	 */
	@Override
	public Map<String, Object> selectSetleMnInfo(String entrpsNo) throws Exception {
		Map<String, Object> retMap = dashboardMapper.selectSetleMnInfo(entrpsNo);
		String refndAcnutNo = retMap.get("refndAcnutNo").toString();	//환불계좌번호
		String ewalletAcnutNo = retMap.get("ewalletAcnutNo").toString();	//이월렛계좌번호

		if (StringUtils.isNotBlank(refndAcnutNo)) {
			try {
				String decStrNo = CryptoUtil.decryptAES256(refndAcnutNo);
				retMap.put("refndAcnutNo", StringUtil.formatBankAccountNo(decStrNo));
			} catch (Exception e) {
				log.error("복호화 오류 : "+ e.getMessage());
				retMap.put("refndAcnutNo", "*******");
			}
		}

		if (StringUtils.isNotBlank(ewalletAcnutNo)) {
			try {
				String decStrNo = CryptoUtil.decryptAES256(ewalletAcnutNo);
				retMap.put("ewalletAcnutNo", StringUtil.formatBankAccountNo(decStrNo));
			} catch (Exception e) {
				log.error("복호화 오류 : "+ e.getMessage());
				retMap.put("ewalletAcnutNo", "*******");
			}
		}

		return retMap;
	}

	/**
	 * 결제내역 목록을 조회한다.
	 */
	@Override
	public List<PaytEsamtVO> selectListUnSetleAmountDtl(Map<String, Object> param) throws Exception {
		String entrpsNo = String.valueOf(param.get("entrpsNo"));
		List<PaytEsamtVO> list = dashboardMapper.selectListUnSetleAmountDtl(entrpsNo);
		return list;
	}

	/**
	 * 최근 30일 거래내역을 조회한다.
	 */
	@Override
	public DashboardVO selectRecentOrderDtls(Map<String, Object> param) throws Exception {
		// TODO Auto-generated method stub
		return dashboardMapper.selectRecentOrderDtls(param);
	}
	
	/**
	 * 결졔예정액 목록을 조회한다.
	 */
	@Override
	public Map<String, Object> selectUnSetleAmount(Map<String, Object> param) throws Exception {
		String entrpsNo = String.valueOf(param.get("entrpsNo"));
		Map<String, Object> unSetleAmountInfo = dashboardMapper.selectUnSetleAmount(entrpsNo);
		return unSetleAmountInfo;
	}
	
	/**
	 * 마이페이지 최근 7일내 3개 문의/답변 내역 조회한다.
	 */
	@Override
	public List<InqryDtlsVO> selectRecentInqryAnswer(Map<String, Object> param) throws Exception {
		List<InqryDtlsVO> list = new ArrayList<>();

		String entrpsNo = String.valueOf(param.get("entrpsNo"));
		list = dashboardMapper.selectRecentInqryAnswer(entrpsNo);

		return list;
	}
	@Override
	public MbEntrpsGradVO selectMbEntrpsGradStdrPurchsQy() throws Exception {
		return dashboardMapper.selectMbEntrpsGradStdrPurchsQy();
	}
	
	@Override
	public List<MbEntrpsGradVO> selectMbGradDscntAmountList() throws Exception {
		return dashboardMapper.selectMbGradDscntAmountList();
	}
	@Override
	public int selectMbTotRealOrderWtSum(String entrpsNo) throws Exception {
		return dashboardMapper.selectMbTotRealOrderWtSum(entrpsNo);
	}
	@Override
	public MbEntrpsGradVO mbEntrpsMnbyPurchsInfo(String entrpsNo) throws Exception {
		return dashboardMapper.mbEntrpsMnbyPurchsInfo(entrpsNo);
	}
	@Override
	public List<MbEntrpsGradVO> selectcpAtmcIsuCouponInfoList() throws Exception {
		return dashboardMapper.selectcpAtmcIsuCouponInfoList();
	}
}
