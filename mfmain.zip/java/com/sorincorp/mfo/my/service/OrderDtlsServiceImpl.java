package com.sorincorp.mfo.my.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.order.model.OrderDtlsClaimVO;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.mfo.my.mapper.OrderDtlsMapper;
import com.sorincorp.mfo.my.model.DlvyDetailVO;
import com.sorincorp.mfo.my.model.OrderDtlsVO;

@Service
public class OrderDtlsServiceImpl implements OrderDtlsService {

	@Autowired
	OrderDtlsMapper orderDtlsMapper;


	/**
	 * 공통코드 스트링으로 변환한다.
	 */
	@Override
	public String getCommCodeListStr(Map<String, String> commonCode) throws Exception{

		StringBuilder codeTaglibStr = new StringBuilder(StringUtils.EMPTY);

		codeTaglibStr.append("");
		codeTaglibStr.append(CommonConstants.COLONE);
		codeTaglibStr.append("전체");
		codeTaglibStr.append(CommonConstants.SEMI_COLONE);

		for( String code : commonCode.keySet() ) {
			codeTaglibStr.append(code);
			codeTaglibStr.append(CommonConstants.COLONE);
			codeTaglibStr.append(commonCode.get(code));
			codeTaglibStr.append(CommonConstants.SEMI_COLONE);
		}

		return codeTaglibStr.toString();
	}

	/**
	 * 주문내역 총 건수를 조회한다.
	 */
	@Override
	public int selectOrderDtlsListTotCnt(OrderDtlsVO seachVo) throws Exception {
		return orderDtlsMapper.selectOrderDtlsListTotCnt(seachVo);
	}

	/**
	 * 주문내역 리스트를 조회한다.
	 */
	@Override
	public List<OrderDtlsVO> selectOrderDtlsList(OrderDtlsVO seachVo) throws Exception {
		return orderDtlsMapper.selectOrderDtlsList(seachVo);
	}

	/**
	 * 해당 주문번호의 배차수를 조회한다.
	 */
	@Override
	public List<Map<String, Object>> selectDlvyOdr(String orderNo) throws Exception {
		return orderDtlsMapper.selectDlvyOdr(orderNo);
	}

	/**
	 * 해당 배차수의 배송상세 정보를 조회한다.
	 */
	@Override
	public DlvyDetailVO selectDlvyDetail(Map<String, Object> orderInfo) throws Exception {
		DlvyDetailVO vo = orderDtlsMapper.selectDlvyDetail(orderInfo);

		if (StringUtils.isNotBlank(vo.getDrverTlphonNo())) {
			vo.setDrverTlphonNo(CryptoUtil.decryptAES256(vo.getDrverTlphonNo()));
		}

		if (StringUtils.isNotBlank(vo.getReceptEntrpsMoblphonNo())) {
			vo.setReceptEntrpsMoblphonNo(CryptoUtil.decryptAES256(vo.getReceptEntrpsMoblphonNo()));
		}

		return vo;
	}

	/**
	 * 지급확인서 데이터를 조회한다.
	 */
	@Override
	public OrderDtlsClaimVO selectCanclCnfrmnInfo(OrderDtlsVO vo) throws Exception {
		return orderDtlsMapper.selectCanclCnfrmnInfo(vo);
	}

	/**
	 * 지급확인서 상세 데이터 조회
	 */
	@Override
	public OrderDtlsClaimVO selectCanclCnfrmnDtl(OrderDtlsVO vo) throws Exception {
		return orderDtlsMapper.selectCanclCnfrmnDtl(vo.getOrderNo());
	}

	@Override
	public List<Map<String, Object>> selectPcCalcBasis(String canclExchngRtngudNo) throws Exception {
		return orderDtlsMapper.selectPcCalcBasis(canclExchngRtngudNo);
	}

	/**
	 *	매매계약서 데이터를 조회한다.
	 */
	@Override
	public OrderDtlsVO selectContractsInfo(OrderDtlsVO vo) throws Exception {
		return orderDtlsMapper.selectContractsInfo(vo);
	}
}
