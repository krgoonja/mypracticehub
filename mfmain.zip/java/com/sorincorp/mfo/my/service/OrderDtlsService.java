package com.sorincorp.mfo.my.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.order.model.OrderDtlsClaimVO;
import com.sorincorp.mfo.my.model.DlvyDetailVO;
import com.sorincorp.mfo.my.model.OrderDtlsVO;

public interface OrderDtlsService {

	/**
	 * <pre>
	 * 처리내용: 공통코드 스트링으로 변환한다.
	 * </pre>
	 * @date 2024. 01. 05.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일 				작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 05.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param commonCodeList
	 * @param val
	 * @return
	 * @throws Exception
	 */
	public String getCommCodeListStr(Map<String, String> commonCodeList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문내역 총 건수를 조회한다.
	 * </pre>
	 * @date 2024. 01. 05.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일 				작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 05.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public int selectOrderDtlsListTotCnt(OrderDtlsVO seachVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문내역 리스트를 조회한다.
	 * </pre>
	 * @date 2024. 01. 05.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일 				작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 05.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public List<OrderDtlsVO> selectOrderDtlsList(OrderDtlsVO seachVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 해당 주문번호의 배차수를 조회한다.
	 * </pre>
	 * @date 2021. 8. 10.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 10.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	public List<Map<String, Object>> selectDlvyOdr(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 해당 배차수의 배송상세 정보를 조회한다.
	 * </pre>
	 * @date 2021. 8. 10.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 10.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public DlvyDetailVO selectDlvyDetail(Map<String, Object> orderInfo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 지급확인서 데이터를 조회한다.
	 * </pre>
	 * @date 2022. 10. 21.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 21.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public OrderDtlsClaimVO selectCanclCnfrmnInfo(OrderDtlsVO vo)  throws Exception;

	/**
	 * <pre>
	 * 처리내용: 지급확인서 상세 데이터 조회
	 * </pre>
	 * @date 2022. 10. 28.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 28.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public OrderDtlsClaimVO selectCanclCnfrmnDtl(OrderDtlsVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 가격 산정 근거 데이터 조회
	 * </pre>
	 * @date 2022. 10. 31.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 31.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param canclExchngRtngudNo
	 * @return
	 * @throws Exception
	 */
	public List<Map<String, Object>> selectPcCalcBasis(String canclExchngRtngudNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 매매계약서 데이터를 조회한다.
	 * </pre>
	 * @date 2022. 12. 12.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 12.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public OrderDtlsVO selectContractsInfo(OrderDtlsVO vo) throws Exception;
}
