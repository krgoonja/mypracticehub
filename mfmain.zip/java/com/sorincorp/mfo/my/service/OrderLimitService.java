package com.sorincorp.mfo.my.service;

import java.util.List;

import org.springframework.ui.ModelMap;

import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.mfo.my.model.OrderLimitVO;
import com.sorincorp.mfo.my.model.OrderLimitValidVO;

/**
 * 마이페이지 지정가 주문 서비스 인터페이스
 * @author srec0051
 *
 */
public interface OrderLimitService {

    /**
     * <pre>
     * 주문/지정가 목록 카운트
     * </pre>
     * @date 2023. 3. 9.
     * @author srec0051
     * @param searchVo
     * @return
     * @throws Exception
     */
    int getOrderLimitTotCnt(OrderLimitVO searchVo) throws Exception;

    /**
     * <pre>
     * 주문/지정가 목록 조회
     * </pre>
     * @date 2023. 3. 9.
     * @author srec0051
     * @param searchVo
     * @return
     * @throws Exception
     */
    List<OrderLimitVO> listOrderLimit(OrderLimitVO searchVo) throws Exception;

    /**
     * <pre>
     * 주문/지정가 취소
     * </pre>
     * @date 2023. 3. 13.
     * @author srec0051
     * @param paramVo
     */
    int doCancelOrderLimit(OrderLimitVO paramVo) throws Exception;

    /**
     * <pre>
     * 주문/지정가 수정
     * </pre>
     * @date 2023. 3. 14.
     * @author srec0051
     * @param paramVo
     * @return
     */
    int doModifyOrderLimit(OrderLimitVO paramVo) throws Exception;

//    //TEST
//    void pubulishLimitOrder(OrderLimitVO paramVo) throws Exception;

    /**
     * <pre>
     * 주문/지정가 주문, 취소 제한 (업체 공통)
     * </pre>
     * @date 2023. 4. 10.
     * @author srec0051
     * @param entrpsNo
     * @return
     * @throws Exception
     */
	OrderLimitValidVO validCreateAndCancel(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 주문/지정가 미체결 여부
	 * </pre>
	 * @date 2023. 4. 13.
	 * @author srec0051
	 * @param paramVo
	 * @return
	 * @throws Exception
	 */
	int validOrderLimitSttusCode(OrderLimitVO paramVo) throws Exception;

	/**
	 * <pre>
	 * 지정가 주문 조회
	 * </pre>
	 * @date 2023. 4. 18.
	 * @author srec0051
	 * @param paramVo
	 * @return
	 */
	OrderLimitVO selectOrderLimit(OrderLimitVO paramVo) throws Exception;

	/**
	 * <pre>
	 * 모달창에서 사용되는 데이터를 조회하여 model 객체에 세팅한다.
	 * </pre>
	 * @date 2023. 5. 10.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 10.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param bsktNo
	 * @param model
	 * @throws Exception
	 */
	void setOrderLimitData(OrderLimitVO orderLimitVO, ModelMap model) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 사용 쿠폰 금액 계산
	 * </pre>
	 * @date 2023. 08. 02.
	 * @author sumin
	 * @return
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 02.		sumin			최초작성
	 * ------------------------------------------------
	 *
	 */
	//long couponUse(OrderLimitVO orderLimitVO, int orderWt, boolean newGetBlListUseStatus) throws CommCustomException, Exception;

}
