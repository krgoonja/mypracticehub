package com.sorincorp.mfo.my.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.mfo.my.model.PaytEsamtVO;
import com.sorincorp.mfo.my.model.InqryDtlsVO;
import com.sorincorp.mfo.mb.model.MbEntrpsGradVO;
import com.sorincorp.mfo.my.model.CorpInfoMgrVO;
import com.sorincorp.mfo.my.model.DashboardVO;

public interface DashboardMapper {

	/**
	 * <pre>
	 * 처리내용: 회원 기본 정보를 조회한다.
	 * </pre>
	 * @date 2024. 01. 03.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일 				작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 03.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @return corpInfoMgrVO
	 */
	CorpInfoMgrVO getCorpInfoMgrVO(String mberNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 회원 기본 정보를 조회한다.
	 * </pre>
	 * @date 2024. 01. 03.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일 				작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 03.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return map
	 */
	Map<String, Object> selectSetleMnInfo(String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 결졔예정액 목록을 조회한다.
	 * </pre>
	 * @date 2024. 01. 03.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일 				작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 03.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> selectUnSetleAmount(String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 최근 30일 거래내역을 조회한다.
	 * </pre>
	 * @date 2024. 01. 04.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일 				작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 04.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	DashboardVO selectRecentOrderDtls(Map<String, Object> param) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 회원 기본 정보를 조회한다.
	 * </pre>
	 * @date 2024. 01. 03.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일 				작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 03.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return map
	 */
	List<PaytEsamtVO> selectListUnSetleAmountDtl(String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 최근 7일내 3개 문의/답변 내역 조회한다.
	 * </pre>
	 * @date 2024. 01. 03.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일 				작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 03.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return map
	 */
	List<InqryDtlsVO> selectRecentInqryAnswer(String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 회원_업체 등급 기준 구매 수량
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author sein
	 * @param 
	 * @return
	 * @throws Exception
	 */
	MbEntrpsGradVO selectMbEntrpsGradStdrPurchsQy() throws Exception;

	/**
	 * <pre>
	 * 회원 등급 할인 금액
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author sein
	 * @param 
	 * @return
	 * @throws Exception
	 */
	List<MbEntrpsGradVO> selectMbGradDscntAmountList() throws Exception;
	
	/**
	 * <pre>
	 * 당월 구매 수량
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author sein
	 * @param entrpsNo
	 * @return totRealOrderWtSum
	 * @throws Exception
	 */
	int selectMbTotRealOrderWtSum(String entrpsNo) throws Exception ;
		
	/**
	 * <pre>
	 * 전월 기준 구매 정보(MB_ENTRPS_MNBY_PURCHS_BNEF_BAS)
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author sein
	 * @param 
	 * @return
	 * @throws Exception
	 */
	MbEntrpsGradVO mbEntrpsMnbyPurchsInfo(String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 상시 할인 금액 리스트(3000,4000,5000)
	 * </pre>
	 * @date 2024. 02. 13.
	 * @author sein
	 * @param 
	 * @return
	 * @throws Exception
	 */
	List<MbEntrpsGradVO> selectcpAtmcIsuCouponInfoList() throws Exception;
}
