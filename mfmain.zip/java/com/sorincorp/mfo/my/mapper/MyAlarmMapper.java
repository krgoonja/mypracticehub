package com.sorincorp.mfo.my.mapper;

import java.util.List;

import com.sorincorp.mfo.my.model.MyCmmrcAlarmVO;
import com.sorincorp.mfo.my.model.MyHopePcAlarmVO;
import com.sorincorp.mfo.my.model.MyInvntryAlarmVO;
import com.sorincorp.mfo.op.model.HopePcNtcnSetupVO;

/**
 * MyAlarmMapper.java
 * @version
 * @since 2021. 9. 8.
 * @author srec0042
 */
public interface MyAlarmMapper {

	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 희망가 알림 내역을 조회한다.
	 * </pre>
	 * @date 2021. 9. 23.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 23.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @return
	 */
	List<MyHopePcAlarmVO> selectHopePcAlarm(String entrpsNo);

	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 목표가 알림을 조회한다.
	 * </pre>
	 * @date 2021. 9. 30.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 30.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	List<MyHopePcAlarmVO> selectHopePcAlarmList(String entrpsNo);

	/**
	 * <pre>
	 * 처리내용: 헤더 - 알림 내역 조회 
	 * </pre>
	 * @date 2021. 9. 30.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 30.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	List<MyHopePcAlarmVO> selectHeaderAlarm(String entrpsNo);

	/**
	 * <pre>
	 * 처리내용: 희망가 알림 상태를 수정한다.
	 * </pre>
	 * @date 2024. 01. 17.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 17.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	int updateHopePcUseAt(MyHopePcAlarmVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 희망가 알림을 수정한다.
	 * </pre>
	 * @date 2024. 01. 22.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 22.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	int updateHopePcAlarm(HopePcNtcnSetupVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 마이페이지 - 희망가 알림을 삭제한다.
	 * </pre>
	 * @date 2024. 01. 22.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 22.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param deleteVo
	 * @return
	 */
	int deleteHopePcAlarm(HopePcNtcnSetupVO deleteVo);
}
