package com.sorincorp.mfo.my.mapper;

import java.util.List;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.mfo.my.model.DeliveryRegionMngVO;

public interface DeliveryRegionMngMapper {

	/**
	 * <pre>
	 * 처리내용: 등록된 배송지구분코드 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return
	 * @throws Exception
	 */
	List<DeliveryRegionMngVO> selectMbDlvrgSeDtlListList(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체가 등록한 배송지 목록을 조회한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return
	 * @throws Exception
	 */
	List<DeliveryRegionMngVO> selectDeliveryRegionMngList(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 기본배송지 번호를 조회한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return
	 * @throws Exception
	 */
	String selectBassDlvrgNo(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기본배송지여부를 변경한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return
	 * @throws Exception
	 */
	int updateBassDlvrgAt(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 배송지 이력정보를 insert한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @throws Exception
	 */
	void insertMbDlvrgBasHst(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 배송지 정보를 삭제한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return
	 * @throws Exception
	 */
	int deleteMbDlvrgBas(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 배송지 정보를 수정한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return
	 * @throws Exception
	 */
	int updateDeliveryRegion(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 배송지정보를 insert한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param deliveryRegionMngVO
	 * @return
	 * @throws Exception
	 */
	int insertDeliveryRegion(DeliveryRegionMngVO deliveryRegionMngVO) throws Exception;

	List<CommonCodeVO> selectemailDomainList() throws Exception;


}
