package com.sorincorp.mfo.my.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.mfo.my.model.*;

public interface OrderDtlsDetailMapper {

	/**
	 * <pre>
	 * 처리내용: 주문상세내역을 조회한다.
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param seachVo
	 * @return
	 * @throws Exception
	 */
	OrderDtlsVO selectOrderDtlsDetail(OrderDtlsVO seachVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 매매계약서 내부 거래명세서, 세금계산서 ozReport 실행시 필요한 파라미터 조회한다.
	 * </pre>
	 * @date 2021. 9. 27.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 27.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> selectTaxBillInfo(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 상차도 정보 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 19.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param seachVo
	 * @return
	 * @throws Exception
	 */
	List<DlivyVO> selectDlivyList(String seachVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 차량종류 공통코드를 조회한다.
	 * </pre>
	 * @date 2021. 7. 21.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 21.			srec0048			최초작성
	 * 2022. 12. 			srec0051		차량공통코드 수정
	 * 2023. 07. 			srec0051		차량 고도화
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<CommonCodeVO> selectVhcleGroupCodeList(@Param("sleMthdCode") String sleMthdCode, @Param("metalCode") String metalCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 차량정보를 조회한다.
	 * </pre>
	 * @date 2021. 7. 21.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 21.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoVO
	 * @return
	 * @throws Exception
	 */
	List<VhcleInfoVO> selectVhcleInfoList(VhcleInfoVO vhcleInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 배송지 정보를 조회한다.
	 * </pre>
	 * @date 2021. 7. 16.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 16.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param seachVo
	 * @return
	 * @throws Exception
	 */
	DlvyVO selectDlvrg(String seachVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기존 주문 배송지 번호는 삭제 처리한다. (삭제 여부와 삭제 일시, 최종 변경자 아이디, 최종 변경자 일시 업데이트)
	 * </pre>
	 * @date 2021. 9. 15.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 15.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param dlvyVO
	 * @return
	 * @throws Exception
	 */
	int updateOrDlvrgBasForDelete(DlvyVO dlvyVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 배송지 정보를 수정한다.
	 * </pre>
	 * @date 2021. 7. 16.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 16.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param dlvyVO
	 * @throws Exception
	 */
	void insertNewDlvrgInfo(DlvyVO dlvyVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 배송지 이력을 저장한다.
	 * </pre>
	 * @date 2021. 7. 22.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 22.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param dlvyVO
	 */
	void insertOrDlvrgBasHst(DlvyVO dlvyVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문기본 테이블에 주문 배송지 번호 update한다.
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 21.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param dlvyVO
	 * @return
	 * @throws Exception
	 */
	int updateOrOrderBas(DlvyVO dlvyVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 배송차수 리스트을 조회
	 * </pre>
	 * @date 2021. 7. 22.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 22.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoVO
	 * @return
	 */
	List<Map<String, Object>> selectDlvyOdrList(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 차량정보를 등록 및 수정한다.
	 * </pre>
	 * @date 2021. 7. 22.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 22.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoVO
	 */
	void insertVhcleOrderDtl(VhcleInfoVO vhcleInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_차량 정보 기본 이력 등록한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 23.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoVO
	 */
	void insertOrVhcleInfoHst(VhcleInfoVO vhcleInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 성적서&패킹리스트를 조회한다.
	 * </pre>
	 * @date 2021. 9. 13.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 13.			srec0048			최초작성
	 * ------------------------------------------------
	 * @param orderNO
	 * @return
	 * @throws Exception
	 */
	List<Map<String, Object>> selectScreofePackngList(String orderNO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 직인을 조회한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0048
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0048			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	Object selectSorinSign() throws Exception;

	/**
	 * <pre>
	 * 물류 휴일 목록
	 * </pre>
	 * @date 2022. 2. 8.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 8.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	List<String> selectHolidayList(String orderNo);

	/**
	 * <pre>
	 * 이벤트 휴일에 포함되는지 조회
	 * </pre>
	 * @date 2022. 2. 8.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 8.			srec0051			최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoVO
	 * @return
	 */
	int checkHolidayYn(VhcleInfoVO vhcleInfoVO);

	/**
	 * <pre>
	 * 처리내용: 자차 자량정보 등록 및 수정 api 오류 SMS 전송 수신자 추가 리스트 가져오기[SMS_SNDNG_GROUP_CODE:50]
	 * </pre>
	 * @date 2022. 5. 27.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 5. 27.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param smsSndngGroupCode
	 * @return
	 * @throws Exception
	 */
	List<Map<String, String>> selectReceiverList(String smsSndngGroupCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 자차 자량정보 등록 및 수정 고객 SMS 전송 수신자
	 * </pre>
	 * @date 2022. 5. 30.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 5. 27.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param smsSndngGroupCode
	 * @return
	 * @throws Exception
	 */
	OrderDtlsVO selectSmsUserInfo(VhcleInfoVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 자차 자량정보 등록 및 수정 고객 SMS 전송 데이터
	 * </pre>
	 * @date 2022. 5. 30.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 5. 27.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param smsSndngGroupCode
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectSmsInfo(VhcleInfoVO vo) throws Exception;


	/**
	 * <pre>
	 * 처리내용: 결제 수단에 따른 결제 정보를 조회한다.
	 * </pre>
	 * @date 2022. 8. 5.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 5.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param searchVo
	 * @return
	 */
	OrSetleInfoVO selectOrSetleInfo(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 전자상거래보증 상세 결제내역 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 8. 8.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 8.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param setleInfo
	 * @return
	 */
	List<OrSetleDtlsInfoVO> selectOrSetleDtlsMrtggList(OrSetleInfoVO setleInfo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 계약금(구매자금) 상세 결제내역 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 8. 22.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 22.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param setleInfo
	 * @return
	 * @throws Exception
	 */
	List<OrSetleDtlsInfoVO> selectOrSetleDtlsWrtmLonList(OrSetleInfoVO setleInfo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 계약금(이월렛) 상세 결제내역 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 8. 8.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 8.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param setleInfo
	 * @return
	 */
	List<OrSetleDtlsInfoVO> selectOrSetleDtlsWrtmList(OrSetleInfoVO setleInfo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 입금확인서 정보를 조회한다.
	 * </pre>
	 * @date 2022. 8. 9.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 9.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	OrSetleInfoVO selectRcpmnyCnfrmnInfo(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 배송지 데이터를 조회한다.
	 * </pre>
	 * @date 2022. 9. 6.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 6.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param dlvyVO
	 * @return
	 * @throws Exception
	 */
	DlvyVO selectOrDlvrgBas(DlvyVO dlvyVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 신용보증 주문의 상환버튼 노출 여부를 조회한다.
	 * </pre>
	 * @date 2022. 9. 22.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 22.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	String getRepyPossAt(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기준일자, 일수를 받아 계산된 영업일을 리턴
	 * </pre>
	 * @date 2022. 10. 19.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 19.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param dlvyVO
	 * @return
	 * @throws Exception
	 */
	String getSettleSttusDe(DlvyVO dlvyVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 결제수단에 따른 계산할 영업일수를 조회한다.
	 * 		  담보보증 : 상환기간(담보_기본 테이블)
	 * 		  증거금  : -1 (바로 이전 영업을 조회를 위함)
	 *        그외    : 0
	 * </pre>
	 * @date 2022. 10. 19.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 19.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param dlvyVO
	 * @return
	 * @throws Exception
	 */
	int selectDayCntBySetleMthd(DlvyVO dlvyVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_차량 정보 기본 이력을 조회한다.
	 * </pre>
	 * @date 2023. 4. 11.
	 * @author srec0068
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 11.			srec0068			최초작성
	 * ------------------------------------------------
	 * @param vhcleInfoVO
	 */
	VhcleInfoVO selectOrVhcleInfoHst(VhcleInfoVO vhcleInfoVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 자차 자량정보 등록 및 수정 기사 SMS 전송 데이터
	 * </pre>
	 * @date 2023. 4. 11.
	 * @author srec0068
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 11.			srec0068			최초작성
	 * ------------------------------------------------
	 * @param smsSndngGroupCode
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectDriverSmsInfo(VhcleInfoVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기등록된 차량 정보 확인
	 * </pre>
	 * @date 2023. 5. 4.
	 * @author srec0068
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 4.			srec0068			최초작성
	 * ------------------------------------------------
	 * @param
	 * @return
	 * @throws Exception
	 */
	int selectOneVhcleInfo(VhcleInfoVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 쿠폰 차감내역 조회.
	 * </pre>
	 * @date 2023. 5. 12.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 12.			hamyoonsic				최초작성
	 * ------------------------------------------------
	 * @param orderNO
	 * @return
	 * @throws Exception
	 */

	List<OrderCouponDdctVO> selectCouponDdctList(String orderNO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 출고(배송) 요청일 업데이트
	 * </pre>
	 * @date 2023. 8. 16.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 16.			hamyoonsic				최초작성
	 * ------------------------------------------------
	 * @param VhcleInfoVO
	 * @return
	 * @throws Exception
	 */

	void updateDlivyRequstDe(VhcleInfoVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문 기본 테이블 히스토리 등록
	 * </pre>
	 * @date 2023. 8. 16.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 16.			hamyoonsic				최초작성
	 * ------------------------------------------------
	 * @param VhcleInfoVO
	 * @return
	 * @throws Exception
	 */

	void insertOrderBasHst(VhcleInfoVO vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기존 출고요청일 조회
	 * </pre>
	 * @date 2023. 8. 18.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 18.			hamyoonsic				최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	String selectDlivyRequstDe(String orderNo) throws Exception;

	List<OrSetleDtlsInfoVO> getAvrgRefundSetleList(OrSetleInfoVO setleInfo) throws Exception;
	
	List<Map<String, Object>> selectTaxBillRequestDeList(String orderNo) throws Exception;

	List<OrSetleDtlsInfoVO> selectSetleDtlsList(String orderNo) throws Exception;
	
	List<OrMrtggMdstrmRepyVO> selectOrMrtggMdstrmRepyDtl(OrSetleInfoVO setleInfo) throws Exception;

	int insertVhcleBas(VhcleInfoVO vo) throws Exception;
}

