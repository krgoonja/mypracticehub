package com.sorincorp.mfo.my.mapper;

import java.util.List;

import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.mfo.my.model.OrderLimitVO;
import com.sorincorp.mfo.my.model.OrderLimitValidVO;

/**
 * 마이페이지 지정가 주문 매퍼 인터페이스
 * @author srec0051
 *
 */
public interface OrderLimitMapper {

    /**
     * <pre>
     * 주문/지정가 목록 카운트
     * </pre>
     * @date 2023. 3. 9.
     * @author srec0051
     * @param searchVo
     * @return
     * @throws Exception
     */
    int getOrderLimitTotCnt(OrderLimitVO searchVo) throws Exception;

    /**
     * <pre>
     * 주문/지정가 목록 조회
     * </pre>
     * @date 2023. 3. 9.
     * @author srec0051
     * @param searchVo
     * @return
     */
    List<OrderLimitVO> listOrderLimit(OrderLimitVO searchVo) throws Exception;

    /**
     * <pre>
     * 주문/지정가 취소
     * </pre>
     * @date 2023. 3. 13.
     * @author srec0051
     * @param paramVo
     * @return
     * @throws Exception
     */
    int cancelOrderLimit(OrderLimitVO paramVo) throws Exception;

    /**
     * <pre>
     * 주문/지정가 수정 이력 등록
     * </pre>
     * @date 2023. 3. 13.
     * @author srec0051
     * @param paramV
     * @return
     */
    int insertOrderLimitHst(OrderLimitVO paramVo) throws Exception;

    /**
     * <pre>
     * 주문/지정가 수정
     * </pre>
     * @date 2023. 3. 14.
     * @author srec0051
     * @param paramVo
     * @return
     */
    int updateOrderLimitAmtWithWt(OrderLimitVO paramVo) throws Exception;
//    int updateOrderLimitAmt(OrderLimitVO paramVo) throws Exception;
//    int updateOrderLimitWt(OrderLimitVO paramVo) throws Exception;

    /**
     * <pre>
     * 지정가 주문 조회
     * </pre>
     * @date 2023. 3. 21.
     * @author srec0051
     * @param paramVo
     * @return
     * @throws Exception
     */
    OrderLimitVO selectOrderLimit(OrderLimitVO paramVo) throws Exception;

    /**
     * <pre>
     * 주문/지정가 주문, 취소 제한 (업체 공통)
     * </pre>
     * @date 2023. 4. 10.
     * @author srec0051
     * @param entrpsNo
     * @return
     * @throws Exception
     */
	OrderLimitValidVO validCreateAndCancel(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 주문/지정가 미체결 여부
	 * </pre>
	 * @date 2023. 4. 13.
	 * @author srec0051
	 * @param paramVo
	 * @return
	 */
	int validOrderLimitSttusCode(OrderLimitVO paramVo) throws Exception;

	/**
	 * <pre>
	 * 아이템순번에 해당하는 중량변동 값 조회
	 * </pre>
	 * @date 2023. 4. 24.
	 * @author srec0051
	 * @param orderLimitVo
	 * @return
	 */
	double getWtChange(OrderLimitVO orderLimitVo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 지정가 주문 수정을 위해 지정가 주문으로 발생한 결제수단 별 예수금의 총합을 조회한다.
	 * 			 조회 시, 수정 대상인 지정가 주문의 예수금은 제외한다.
	 * </pre>
	 * @date 2023. 6. 12.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 12.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	long getTotalAdvrcvAmount(OrderLimitVO orderLimitVo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 사용 쿠폰 조회
	 * </pre>
	 * @date 2023. 12. 08.
	 * @author hyunjin0512
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 12. 08.		hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	CouponVO selectCouponInfo(String couponSn) throws Exception;
}
