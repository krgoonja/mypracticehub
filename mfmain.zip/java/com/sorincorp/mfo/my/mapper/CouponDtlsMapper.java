package com.sorincorp.mfo.my.mapper;

import java.util.List;

import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.mfo.my.model.CouponDtlVO;

public interface CouponDtlsMapper {
    
    /**
     * <pre>
     * 처리내용: 마이페이지 쿠폰내역 조회
     * </pre>
     * @date 2022. 7. 26.
     * @author sumin95
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 7. 26.             sumin95             최초작성
     * ------------------------------------------------
     * @return
     * @throws Exception
     */
    List<CouponDtlVO> selectCouponDtlsList(CouponDtlVO couponDtlVo);
    
    /**
     * <pre>
     * 처리내용: 마이페이지 업체지장쿠폰 입력
     * </pre>
     * @date 2022. 7. 26.
     * @author sumin95
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 7. 26.             sumin95             최초작성
     * ------------------------------------------------
     * @return
     * @throws Exception
     */
    int updateCouponDtlsList(CouponDtlVO couponDtlVo);
    
    /**
     * <pre>
     * 처리내용:쿠폰 등록여부 변경 (03.업체지정 쿠폰 / N -> Y)
     * * </pre>
     * @date 2022. 7. 26.
     * @author sumin95
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 7. 26.             sumin95             최초작성
     * ------------------------------------------------
     * @return
     * @throws Exception
     */
    int updateCouponRegisAt(CouponDtlVO couponDtlVo);
    
    
    /**
     * <pre>
     * 처리내용: 쿠폰번호 내역 조회
     * </pre>
     * @date 2022. 7. 26.
     * @author sumin95
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 7. 26.             sumin95             최초작성
     * ------------------------------------------------
     * @return
     * @throws Exception
     */
    List<CouponDtlVO> selectCouponRnnoList(CouponDtlVO couponDtlVo);
    
    
    
    /**
     * <pre>
     * 처리내용: 입력쿠폰 내역 조회
     * </pre>
     * @date 2022. 7. 26.
     * @author sumin95
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 7. 26.             sumin95             최초작성
     * ------------------------------------------------
     * @return
     * @throws Exception
     */
    String findCouponType(CouponDtlVO couponDtlVo);
    
    
    /**
     * <pre>
     * 처리내용: 입력쿠폰 내역 조회
     * </pre>
     * @date 2022. 7. 26.
     * @author sumin95
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2022. 7. 26.             sumin95             최초작성
     * ------------------------------------------------
     * @return
     * @throws Exception
     */
    void insertCouponIsu(CouponDtlVO couponDtlVo);
    
    int selectCouponEntrpsAppn(CouponDtlVO couponDtlVo);

    /**
     * <pre>
     * 처리내용: 마이페이지 쿠폰 목록 조회
     * </pre>
     * @date 2023. 5. 9.
     * @author hamyoonsic
     * @history
     * -----------------------------------------------------
     * 변경일					작성자				변경내용
     * -----------------------------------------------------
     * 2022. 5. 9.				hamyoonsic			최초작성
     * -----------------------------------------------------
     * @param vo
     * @return
     * @throws Exception
     */
    List<CouponDtlVO> selectCouponList(CouponDtlVO vo) throws Exception;

    /**
     * <pre>
     * 처리내용: 미사용, 사용중 할인 쿠폰 목록 조회
     * </pre>
     * @date 2023. 7. 18.
     * @author hyunjin05
     * @history
     * -----------------------------------------------------
     * 변경일					작성자				변경내용
     * -----------------------------------------------------
     * 2023. 7. 18.			hyunjin05			최초작성
     * 2023. 11. 13.		hyunjin0512			쿠폰 조회 테이블 수정
     * -----------------------------------------------------
     * @param CouponVO
     * @return
     * @throws Exception
     */
    List<CouponVO> getCouponList(CouponVO couponVO) throws Exception;
    List<CouponVO> getCouponListForMypage(CouponVO couponVO) throws Exception;

    /**
     *  (신규)쿠폰 발행 테이블 데이터 입력 
     **/
    void insertCouponIsuNew(CouponDtlVO couponDtlVo);

    public void updateCouponPolicyInfo(CouponDtlVO couponDtlVo) throws Exception;
	
	CouponDtlVO getCouponInfo(CouponDtlVO couponDtlVo) throws Exception;
}
