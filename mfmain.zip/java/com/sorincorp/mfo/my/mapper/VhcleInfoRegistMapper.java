package com.sorincorp.mfo.my.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.mfo.my.model.VhcleInfoRegistVO;
import com.sorincorp.mfo.my.model.VhcleInfoVO;

public interface VhcleInfoRegistMapper {
	List<VhcleInfoRegistVO> selectVhcleInfoRegistList(VhcleInfoRegistVO vhcleInfoRegistVO);
	
	VhcleInfoRegistVO selectOrOrderBas(@Param("orderNo") String orderNo, @Param("orderSn") String orderSn);
	
	List<VhcleInfoVO> selectOrVhcleInfoBas(@Param("orderNo") String orderNo, @Param("orderSn") String orderSn);
	
	List<CommonCodeVO> selectVhcleGroupCodeList(VhcleInfoRegistVO vhcleInfoRegistVO);

	void insertVhcleOrderDtl(VhcleInfoVO vhcleInfoVO);
	
	void insertVhcleBas(VhcleInfoVO vhcleInfoVO);
	
	void insertVhcleInfoHst(VhcleInfoVO vhcleInfoVO);

	int selectDayCntBySetleMthd(String orderNo);

	String getSettleSttusDe(@Param("dlivyRequstDe") String dlivyRequstDe, @Param("dayCnt") int dayCnt);

	String selectSmsUserInfo(VhcleInfoVO vo);

	Map<String, String> selectSmsInfo(VhcleInfoVO vo);

	VhcleInfoVO selectOrVhcleInfoHst(VhcleInfoVO voInfoVO);

	Map<String, String> selectDriverSmsInfo(VhcleInfoVO vo);

	int getMultiBlListSize(String orderNo);
	
	List<VhcleInfoRegistVO> selectMultiBlList(String orderNo);

	List<String> selectHolidayList(String orderNo);

	int checkHolidayYn(VhcleInfoVO vhcleInfoVO);

	String selectDlivyRequstDe(String orderNo);

	void updateDlivyRequstDe(VhcleInfoVO vhcleInfoVO);
	
	List<VhcleInfoVO> selectOrVhcleOrderDtlList(String orderNo, List<VhcleInfoVO> vhcleInfoList);

	int selectVhcleInfoRegistListTotCnt(VhcleInfoRegistVO vhcleInfoRegistVO);
}
