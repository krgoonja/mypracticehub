package com.sorincorp.mfo.my.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class VhcleInfoVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -78902290435640674L;

	/* 주문_차량 정보 기본 */
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 주문 순번
    */
    private String orderSn;
    /**
     * 배송 차수
    */
    private int dlvyOdr;
    /**
     * 차량 순번
     */
    private int vhcleSn;
    /**
     * BL 번호
     */
    private String blNo;
    /**
     * 차량 그룹 코드
    */
    private String vhcleGroupCode;
    /**
     * 차량 그룹명
     */
    private String vhcleGroupNm;
    /**
     * 차량 입고 일자
    */
    private String vhcleWrhousngDe;
    /**
     * 운전자 명
    */
    private String drverNm;
    /**
     * 차량 번호
    */
    private String vhcleNo;
    /**
     * 운전자 전화 번호
    */
    private String drverTlphonNo;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최종 변경 일시
     */
    private String lastChangeDt;
    /**
     * 차수 번들 수량
    */
    private int odrBundleQy;
    /**
     * 수정인지 신규저장인지 구문
    */
    private String mode;

    /**
     * 회원 id
     */
    private String mberId;
    /**
     * 실제 주문 중량
     */
    private String realOrderWt;
    /**
     * 금속 코드
     */
    private String metalCode;
    /**
     * 출고 요청일
     */
    private String dlivyRequstDe;
    /**
     * 인터페이스 구분
     */
    private String intrfcSe;

    /** 차량 등록 제한 여부 */
    private String vhcleInfoRegistAt;
    /** EC 배송 차수 */
    private int ecDlvyOdr;
    /** 물류 배송 진행 상태 코드 */
    private int lgistDlvyProgrsSttusCode;
    
    /**
     * 배송 상태 코드
     */
    private int dlvyProgrsSttusCode;
    
    /**
     * 메세지 내용 구성을 위한 임시 차수 정보
     */
    private int dlvyOdrForMsg;
}
