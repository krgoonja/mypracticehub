package com.sorincorp.mfo.my.model;

import java.util.List;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class VhcleInfoRegistVO_old extends CommonVO {
	private static final long serialVersionUID = -4514876154123704519L;
	/**
	 * 주문 번호
	 */
	private String orderNo;
	/**
	 * 주문 일자
	 */
	private String orderDe;
	/**
	 * 금속 코드
	 */
	private String metalCode;
	/**
	 * 금속 이름
	 */
	private String metalNm;
	/**
	 * 총 실제 주문 중량
	 */
	private int totRealOrderWt;
	/**
	 * 모든 차량정보 등록 여부
	 */
	private Boolean isFullyRegistered;
	/**
	 * 다중 BL 여부
	 */
	private Boolean isMultiBl;
	
	/**
	 * 업체 번호
	 */
	private String entrpsNo;
	/**
	 * 사용자 권한 코드
	 */
	private String secode;
	/**
	 * 회원 번호
	 */
	private String mberNo;

	/**
	 * 판매 방식 코드
     */
	private String sleMthdCode;
	/**
	 * 결제 방식 코드
	 */
	private String setleMthdCode;
	/**
	 * 결제 예정 일자
	 */
	private String setlePrearngeDe;
	/**
     * 출고 요청 일자
     */
	private String dlivyRequstDe;
	/**
	 * 차량 등록 제한 여부
	 */
	private String vhcleInfoRegistAt;
	/**
	 * 등록 가능 최대 차수
	 */
	private int dlvyOdrLimit;
	/**
	 * 판매 단위 중량
	 */
	private int sleUnitWt;
	/**
	 * 등록된 모든 차수 정보
	 */
	private String dlvOdrs;
	/**
	 * 남은 번들 수량
	 */
	private int remainOdrBundleQy;
	
	/**
	 * 다중 BL 목록
	 */
	private List<VhcleInfoRegistVO> multiBlList;
	/**
	 * 주문 순번
	 */
	private String orderSn;
	/**
	 * BL 번호
	 */
	private String blNo;
	/**
	 * 실제 주문 중량
	 */
	private int realOrderWt;
	/**
	 * 번들 수량
	 */
	private int bundleQy;
	
	/**
	 * 미 결제 금액
	 */
	private long unSetleAmount;
	/**
	 * 계약 년월
	 */
	private String cntrctYm;
}
