package com.sorincorp.mfo.my.model;

import java.util.List;

import com.sorincorp.comm.order.model.CouponVO;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/******  JAVA VO CREATE : OR_LIMIT_ORDER_BAS(주문_지정가 주문 기본) ******/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderLimitVO  {

    /**
     * 지정가 주문 번호
    */
    private String limitOrderNo;
    /**
     * 지정가 주문 일자
    */
    private String limitOrderDe;
    /**
     * 지정가 주문 시각
    */
    private String limitOrderTm;
    /**
     * 지정가 주문 상태 코드
    */
    private String limitOrderSttusCode;
    /** 지정가 주문 상태 코드 명 */
    private String limitOrderSttusNm;
    /**
     * 회원 번호
    */
    private String mberNo;
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 접수 매체 구분 코드
    */
    private String rceptMediaSeCode;
    /**
     * 지정가 주문 중량
    */
    private int limitOrderWt;
    /**
     * 지정가 입력 금액
    */
    private long limitInputAmount;

    /**
     * 결제 방식 코드
    */
    private String setleMthdCode;
    /**
     * 결제 방식 코드 명
     */
    private String setleMthdNm;
    /**
     * 결제 방식 상세 코드
    */
    private String setleMthdDetailCode;
    /**
     * 권역 중분류 코드
    */
    private String dstrctMlsfcCode;
    /**
     * 프라이싱 번호
    */
    private String pricingNo;
    /**
     * 장바구니 번호
    */
    private String bsktNo;
    /**
     * 주문자 명
    */
    private String ordrrNm;
    /**
     * 주문자 휴대폰 번호
    */
    private String ordrrMoblphonNo;
    /**
     * 주문자 이메일
    */
    private String ordrrEmail;
    /**
     * 주문 업체 명
    */
    private String orderEntrpsNm;
    /**
     * 주문 업체 전화번호
    */
    private String orderEntrpsTelno;
    /**
     * 주문 업체 우편번호
    */
    private String orderEntrpsZip;
    /**
     * 주문 업체 주소
    */
    private String orderEntrpsAdres;
    /**
     * 주문 업체 상세 주소
    */
    private String orderEntrpsDetailAdres;
    /**
     * 주문 업체 도로명 주소
    */
    private String orderEntrpsRnAdres;
    /**
     * 주문 업체 도로명 상세 주소
    */
    private String orderEntrpsRnDetailAdres;
    /**
     * 배송 수단 코드
    */
    private String dlvyMnCode;
    /**
     * 배송 수단 코드 명
    */
    private String dlvyMnNm;
    /**
     * 출고 요청 일자
    */
    private String dlivyRequstDe;
    /**
     * 판매 단위 코드
    */
    private String sleUnitCode;
    /** 판매 단위 명 */
    private String sleUnitNm;
    /** 판매 단위 중량 */
    private long sleUnitWt;
    /**
     * 주문 가격
    */
    private long orderPc;
    /**
     * 중량 변동금
    */
    private float wtChangegld;
    /**
     * 공급가
    */
    private long splpc;
    /**
     * 부가세
    */
    private long vat;
    /**
     * 판매가
    */
    private long slepc;
    /**
     * 상환 기간
    */
    private int repyPd;
    /**
     * 증거금 최소 증거금 비율
    */
    private long wrtmMummWrtmRate;
    /**
     * 예상 배송비
    */
    private long expectDlvrf;
    /**
     * 배송지 명
    */
    private String dlvrgNm;
    /** 수취 주소 */
    private String receptAdres;
    /**
     * 수취 업체 명
    */
    private String receptEntrpsNm;
    /**
     * 수취 업체 우편 번호
    */
    private String receptEntrpsPostNo;
    /**
     * 수취 업체 주소
    */
    private String receptEntrpsAdres;
    /**
     * 수취 업체 상세 주소
    */
    private String receptEntrpsDetailAdres;
    /**
     * 수취 업체 도로명 주소
    */
    private String receptEntrpsRnAdres;
    /**
     * 수취 업체 도로명 상세 주소
    */
    private String receptEntrpsRnDetailAdres;
    /**
     * 수취 업체 법정동 코드
    */
    private String receptEntrpsLegaldongCode;
    /**
     * 수취 업체 휴대폰 번호
    */
    private String receptEntrpsMoblphonNo;
    /**
     * 수취 업체 담당자 명
    */
    private String receptEntrpsChargerNm;
    /**
     * 수취 업체 담당자 이메일
    */
    private String receptEntrpsChargerEmail;
    /**
     * 배송 요청 내용
    */
    private String dlvyRequstCn;
    /**
     * 중량 변동
    */
    private java.math.BigDecimal wtChange;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 금속 코드 명
    */
    private String metalNm;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 아이템 명
    */
    private String itmNm;
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    private String dstrctLclsfNm;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /** 브랜드 그룹 코드 명 */
    private String brandGroupNm;

    /** 브랜드 그룹 코드 명  - 설명 1*/
    private String brandGroupDcone;

    /**
     * 브랜드 코드
    */
    private String brandCode;
    /** 브랜드 코드 명 */
    private String brandNm;
    /**
     * 지정가 주문 로그 순번
    */
    private long limitOrderLogSn;
    /**
     * 지정가 주문 요청 일시
    */
    private String limitOrderRequstDt;
    /**
     * 지정가 주문 기준 판매 가격
    */
    private java.math.BigDecimal limitOrderStdrSlePc;
    /**
     * 판매 가격 실시간 순번
    */
    private String slePcRltmSn;
    /**
     * LME 가격 실시간 순번
    */
    private String lmePcRltmSn;
    /**
     * LME 3M
    */
    private java.math.BigDecimal lme3m;
    /**
     * LME 현금
    */
    private java.math.BigDecimal lmeCash;
    /**
     * LME 조정 계수
    */
    private java.math.BigDecimal lmeMdatCffcnt;
    /**
     * 환율 가격 실시간 순번
    */
    private String ehgtPcRltmSn;
    /**
     * 현물환
    */
    private java.math.BigDecimal spex;
    /**
     * 현물환 조정 계수
    */
    private java.math.BigDecimal spexMdatCffcnt;
    /**
     * 프리미엄 번호
    */
    private String premiumNo;
    /**
     * 프리미엄 기준 금액
    */
    private long premiumStdrAmount;
    /**
     * 권역 변동 금액
    */
    private long dstrctChangeAmount;
    /**
     * 브랜드 그룹 변동 금액
    */
    private long brandGroupChangeAmount;
    /**
     * 브랜드 변동 금액
    */
    private long brandChangeAmount;
    /**
     * 프리미엄 가격
    */
    private java.math.BigDecimal premiumPc;
    /**
     * 재고 체크 중량
    */
    private int invntryCeckWt;
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 실제 체결 중량
    */
    private int realCnclsWt;
    /**
     * 주문 실패 사유
    */
    private String orderFailrResn;
    /**
     * 허수 주문 여부
    */
    private String imaginaryOrderAt;
    /**
     * 지정가 취소 시각
    */
    private String limitCanclTm;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    /**
     * 예수 금액
     */
    private long advrcvAmount;
    /**
     * 최대 브랜드 변동 금액
     */
    private long mxmmBrandChangeAmount;
    /**
     * 프리미엄 ID
     */
    private String premiumId;
    /**
     * 최종 상품 단가
     */
    private long lastGoodsUntpc;
    /**
     * 기준 프리미엄 환산 금액
     */
    private long stdrPremiumCnvrsnAmount;
    /**
     * 지정가 프리미엄 기준 금액
     */
    private long limitPremiumStdrAmount;
    /**
     * 지정가 권역 변동 금액
     */
    private long limitDstrctChangeAmount;
    /**
     * 지정가 브랜드 그룹 변동 금액
     */
    private long limitBrandGroupChangeAmount;
    /**
     * 지정가 브랜드 변동 금액
     */
    private long limitBrandChangeAmount;
    /**
     * 지정가 프리미엄 제외 금액 (지정가 입력 금액 - 프리미엄)
     */
    private long limitPremiumExclAmount;
    /**
     * 메탈 구분 코드
     */
    private String metalClCode;


    /**
     * 회원 아이디
     */
    private String mberId;
    /**
     * 회원구분코드
     */
    private String mberSecode;
    /* 페이징(더보기) */
    /** startIndex */
    private int startIndex = 1;

    /** endIndex */
    private int endIndex = 2;
    /**
     * 문서파일경로
     */
    private String docFileCours;
    /**
     * 문서파일실제경로
     */
    private String docFileRealCours;
    /**
     * 국가이미지
     */
    private String nationFlagImgUrl;
    /**
     * 주문, 취소 타입 (U: 수정, C: 취소)
     */
    private String type;
    /**
     * 수정모드 1: 가격,톤수 / 2: 가격 / 3: 톤수 / 4: 쿠폰 / 5: 유효기간
     */
    private String type2;

    // 수정 건 publish 를 위한 추가 변수 선언 - 화면 단에서 받아옴
    /**
     * 수정 전 지정가 체결 중량
    */
    private int oriLimitOrderWt;
    /**
     * 수정 전 지정가 입력 금액
    */
    private long oriLimitInputAmount;

    /** 기간조회 시작일 */
    private String searchDateFrom;
    /** 기간조회 종료일 */
    private String searchDateTo;

    //쿠폰 관련 변수 선언

    /**
     * 수정전 쿠폰 일련번호
     */
    private String oriCouponSeqNo;

    /**
     * 쿠폰 일련번호
     */
    private String couponSeqNo;

    /**
     * 쿠폰 할인 금액
     */
    private String couponDscntPrice;

    /**
     * 쿠폰 중복 사용 제한
     */
    private String couponDplctUseLmttQyAt;

    /**
     * 쿠폰 번호
     */
    private String couponIsuRnno;

    /**
     * 쿠폰 적용여부
     */
    private String couponApplcAt;

    /**
     * 쿠폰 타입코드
     */
    private String CouponTyCode;

    /**
     * 원 상품단가
     */
    private long OrgGoodsUntpc;

    /**
     * 쿠폰 리스트
     */
    private List<CouponVO> couponList;

    /**
     * 사용 쿠폰 변경 여부
     */
    private String usedCouponChangeAt;

    /**
     * 지정가 주문 유효 시간
     */
    private String limitOrderValidTime;

    /**
     * 등급 할인 금액
     */
    private String gradApplcAmount;

    /** 지정가 주문 유효 일자 */
    private String limitOrderValidDe;
    /** 계약 발주 번호 */
    private String cntrctOrderNo;
    /** 계약번호 */
    private String cntrctNo;
    /** 계약 년월 */
    private String cntrctYm;
	/** 계약 년월 순번 */
    private Integer cntrctYmSn;
	/** QP 코드 */
    private String qpCode;
    /** 계약 구매 최종 상품 단가 */
    private Long cntrctPurchsLastGoodsUntpc;
    /**
     * 단가 산식 코드
    */
    private String untpcMntnfrmlaCode;
    /**
     * 단가 산식 코드 명
    */
    private String untpcMntnfrmlaNm;
    /**
     * 통화 구분 코드
    */
    private String crncySeCode;
    /**
     * 통화 구분 코드 명
    */
    private String crncySeNm;
    /**
     * 계약 프리미엄 가격
    */
    private long cntrctPremiumPc;
    /**
     * 수정 전 지정가 주문 유효 시간
     */
    private String oriLimitOrderValidTime;
    /**
     * 수정 전 지정가 주문 유효 일자
     */
    private String oriLimitOrderValidDe;
    /**
     * 유효 기간 변경 여부 (지정가 유효 시간 or 일자)
     */
    private String validPdChangeAt;
    /**
     * 판매 방식 상세 코드
     */
    private String sleMthdDetailCode;
    /**
     * 주문 상태명
     */
    private String orderSttusNm;
    /**
     * 주문 상태 코드
     */
    private String orderSttusCode;
    /**
     * 결제 예정일
     */
    private String setlePrearngeDe;
    /**
     * 소량 구매 여부
     */
   	private String smlqyPurchsAt;
    /**
     * BL 번호
     */
    private String blNo;
    /**
     * 자투리 할인(추가할인)
     */
    private long rmndrDscnt;
    /**
     *  부분 출고 상환 여부
     */
    private String partDlivyRepyAt;
}
