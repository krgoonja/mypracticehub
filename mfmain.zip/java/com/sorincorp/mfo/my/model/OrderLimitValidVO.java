package com.sorincorp.mfo.my.model;

import lombok.Data;

@Data
public class OrderLimitValidVO {

	/** 업체번호 */
	private String entrpsNo;
	/** 지정가 주문 제한 횟수 */
	private long limitRceptLmttCo;
	/** 지정가 취소 제한 횟수 */
	private long limitCanclLmttCo;
	/** 지정가 당일 주문 횟수 */
	private int orderTotCnt;
	/** 지정가 당일 취소 횟수 */
	private int cancelTotCnt;
	/** 지정가 주문 가능 여부 */
	private String rceptYn;
	/** 지정가 취소 가능 여부 */
	private String canclYn;
}
