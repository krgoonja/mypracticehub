package com.sorincorp.mfo.my.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class MyCmmrcAlarmVO implements Serializable{
	
	private static final long serialVersionUID = 6982563038731458654L;
	
	      /**
	      * 메시지 제목
	     */
	     private String mssageSj; 

	      /**
	      * 최초 등록 일시
	     */
	     private String frstRegistDt; 
	     
	      /**
	      * 커머스 알림 내용
	     */
	     private String commerceNtcnCn; 
	  
}
