package com.sorincorp.mfo.my.model;

import java.util.List;

import com.sorincorp.mfo.my.model.OrMrtggMdstrmRepyVO;
import com.sorincorp.mfo.my.model.OrSetleDtlsInfoVO;

import lombok.Data;

/**
 * OrSetleInfoVO.java : 결제 정보 VO
 * @version
 * @since 2022. 8. 5. 
 * @author srec0066
 */
@Data
public class OrSetleInfoVO {
	
	/**
     * 주문 번호
     */
    private String orderNo;
    /**
     * 결제 상태
     */
    private String setleSttus;
    /**
     * 결제 방식 코드
    */
    private String setleMthdCode;
   /**
     * 결제 방식 상세 코드
    */
    private String setleMthdDetailCode;
    /**
     * 결제 방식
     */
    private String setleMthd;
    /**
     * 주문 일자
     */
    private String orderDe;
    /**
     * 주문 금액
     */
    private long slepc;
    /**
     * 최초 결제액
     */
    private long frstSetleAmount;
    /**
     * 결제 예정액(남은 결제액)
     */
    private long unSetleAmount;
    /**
     * 결제 예정일
     */
    private  java.sql.Timestamp setlePrearngeDe;
    /**
     * 결제 예정일(yyyymmdd)
     */
    private String baseSetlePrearngeDe;
    /**
     * 주문 상태 코드
     */
    private String orderSttusCode;
    /**
     * 배송 수단 코드
     */
    private String dlvyMnCode;
    
    /**
     * 총 실제 주문 중량
    */
    private int totRealOrderWt;
    /**
     * 상품 단가
    */
    private Long goodsUntpc;
    /**
     * 주문 가격
    */
    private Long orderPc;
    /**
     * 중량 변동금
    */
    private Long wtChangegld;
    /**
     * 예상 배송비
     */
    private Long expectDlvrf;
    /**
     * 공급가
    */
    private Long splpc;
    /**
     * 부가세
    */
    private Long vat;
    /**
     * 주문 세금계산서 신청일
     */
    private String taxBillReqstDe;
    /**
     * 총 확정 중량
    */
    private java.math.BigDecimal totDcsnWt;
    /**
     * 확정 상품 단가
    */
    private Long dcsnGoodsUntpc;
    /**
     * 총 확정 주문 가격
    */
    private Long totDcsnOrderPc;
    /**
     * 총 확정 공급가
    */
    private Long totDcsnSplpc;
    /**
     * 총 확정 부가세
     */
    private Long totDcsnVat;
    /**
     * 총 확정 판매가
     */
    private Long totDcsnSlepc;
    /**
     * 수정 세금계산서 신청일
     */
    private String modifiedTaxBillReqstDe;
    /**
     * 정산 금액
    */
    private Long excclcAmount;
    /**
     * 추가 금액
    */
    private Long aditAmount;
    /**
     * 담보 상태 코드
     */
    private String mrtggSttusCode;
    /**
     * 평균가 - 여신 결제일 경우, 단가 확정보다 상환이 먼저 됐으면 true, 아니면 false
     * Default : false
     */
    private boolean alreadySettled;
    /**
     * 결제 정보 - 단계 Column 마지막 순서 이름
     */
    private String lastStep;
    /**
     * 결제 정보 - 단계 Column 마지막 순서의 발생일자
     */
    private String lastStepOccrrncDe;
    
	/**
	 * 결제상세내역 리스트
	 */
    private List<OrSetleDtlsInfoVO> setleDtlsList;
    /** 
     * 증거금사용여부 
     */
    private String wrtmUseAt;
    /** 
     * 전자상거래보증사용여부 
     */
    private String mrtggGrntyUseAt;
    /** 
     * 대출보증사용여부 
	 */
    private String lonGrntyUseAt;
    /**
     * 대출사용코드 
     */
    private String lonSttusCode;
    /* 입금확인서 */
    /**
     * 결제일시
     */
    private java.sql.Timestamp setleComptDt;
    /**
     * 결제일시
     */
    private String strSetleComptDt;
    /**
     *	업체명 
     */
    private String orderEntrpsNm;
    /**
     * 결제액
     */
    private String delngAmount;
    /**
     * 증거금 최소 증거금 비율
    */
    private int wrtmMummWrtmRate;
    /**
     * 주문 상품
     */
    private String goodsNm;
    /* 대표 정보 */
    /**
     * 대표 판매자
     */
    private String repSeler;
    /**
     * 대표 사업자등록번호
     */
    private String repSelerBsnmRegistNo;
    /**
     * 대표 이사
     */
    private String repSelerRprsntvNm;
    /**
     * 오늘 날짜
     */
    private String today;
    
    /**
     * 상환 기간
     */
    private int repyPd;
    
    /**
     * 담보 번호
     */
    private String mrtggNo;
    /**
     * 부분 출고 상환 여부
     */
    private String partDlivyRepyAt;
    
    
    /**
     * 추가 금액 결제 완료 여부
     */
    private boolean isAditAmountSetled = false;
    /**
     * 중도 상환 확정 목록
     */
    private List<OrMrtggMdstrmRepyVO> mdstrmRepyDcsnInfoList;
    /**
     * 중도 상환 입금 목록
     */
    private List<OrMrtggMdstrmRepyVO> mdstrmRepyRcpmnyInfoList;
    
    /**
     * 중도 상환 가능 여부
     */
    private boolean isMdstrmRepyPossAt;
    
    /**
     * 미출고 상환 존재 여부
     */
    private boolean nootgRepyExstAt;
}
