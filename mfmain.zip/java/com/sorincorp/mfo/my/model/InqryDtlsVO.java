package com.sorincorp.mfo.my.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class InqryDtlsVO extends CommonVO {

    /**
	 *
	 */
	private static final long serialVersionUID = 2084391152206613228L;

	/**
	 * InsertAndUpdate</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface InsertAndUpdate {};

	/**
     * 화면 구분 코드
    */
    private String scrinSeCode;

    /**
     * 문의 순번
     */
    private long inqrySn;
    /**
     * 문의 답변 구분 코드
    */
    private String inqryAnswerSeCode;
    /**
     * 문의 답변 회원 번호
     */
    private String inqryAnswerMberNo;
    /**
     * 문의 답변 자
     */
    private String inqryAnswerMan;
    /**
     * 문의 회원 ID
     */
    private String mberId;
    /**
     * 문의 회원 No
     */
    private String mberNo;
    /**
     * 문의 전화번호
    */
    private String inqryTelno;
    /**
     * 문의 이메일
    */
    private String inqryEmail;
    /**
     * 문의 업체번호
    */
    private String entrpsNo;
    /**
     * 문의 회사명
     */
    private String inqryCmpnynm;
    /**
     * 문의 상담 구분 코드
    */
    private String inqryCnsltSeCode;
    /**
     * 문의 구분 코드
    */
    private String inqrySeCode;
    /**
     * 문의 구분명
     */
    private String inqrySeNm;
    /**
     * 문의 구분 상세 코드
    */
    private String inqrySeDetailCode;
    /**
     * 문의 구분 상세명
     */
    private String inqrySeDetailNm;
    /**
     * 문의 주문 번호
    */
    private String inqryOrderNo;
    /**
     * 문의 상품 코드
    */
    private String inqryGoodsCode;
    /**
     * 문의 답변 제목
    */
    @NotBlank(groups=InsertAndUpdate.class, message = "제목을 입력해 주세요.")
    @Size(groups=InsertAndUpdate.class, min=0, max=20, message = "제목은 20자 이내로 입력해 주세요.")
    private String inqryAnswerSj;
    /**
     * 문의 답변 내용
    */
    @NotBlank(groups=InsertAndUpdate.class, message = "내용을 입력해 주세요.")
    @Size(groups=InsertAndUpdate.class, min=0, max=200, message = "내용은 200자 이내로 입력해 주세요.")
    private String inqryAnswerCn;

    /**
     * 문의 내용
    */
    private String inqryCn;
    /**
     * 답변 내용
    */
    private String answerCn;
    /**
     * 문의 처리 상태 코드
    */
    private String inqryProcessSttusCode;
    /**
     * 문의 처리 상태명
    */
    private String inqryProcessSttusNm;
    /**
     * 문의 답변 일시
     */
    private String inqryAnswerDt;
    /**
     * 부모 문의 답변 순번
    */
    private Integer parntsInqryAnswerSn;
    /**
     * 문의 답변 깊이
    */
    private int inqryAnswerDp;
    /**
     * 문의 답변 순서
    */
    private int inqryAnswerOrdr;
    /**
     * 추가문의 수
     */
    private int aditInqryCnt;
    /**
     * 답변 메일 수신 동의 여부
    */
    private String answerEmailRecptnAgreAt;
    /**
     * 개인 정보 수집 동의 여부
    */
    private String indvdlInfoColctAgreAt;
    /**
     * 삭제 여부
     */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;

	/* 페이징(더보기) */
	/** startIndex */
	private int startIndex = 1;

	/** endIndex */
	private int endIndex = 5;

	/**
	 * 문서 번호 배열
	 */
	private int[] docNos;

	/**
	 * 문서 번호
	 */
	private int docNo;

	/** validation 유무 */
	private boolean validation = false;


}
