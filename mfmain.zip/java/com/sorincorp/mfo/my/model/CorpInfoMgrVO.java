package com.sorincorp.mfo.my.model;

import java.io.Serializable;
import java.util.ArrayList;

import javax.validation.constraints.NotEmpty;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CorpInfoMgrVO.java
 *
 * @version
 * @since 2022. 8. 25.
 * @author srec0030
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class CorpInfoMgrVO implements Serializable {

	private static final long serialVersionUID = -3489488821575254711L;

	public interface Search {
	};

	public interface Update {
	};

	/**
	 * 업체번호 ENTRPS_MRTGG_CNTRCT_SN
	 */
	@NotEmpty(groups = Search.class, message = "회원번호가 존재하지 않습니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Update.class, message = "회원번호가 존재하지 않습니다.") // /message/validation.properties 에 등록된 메시지
	private String entrpsNo;
	/**
	 * 업체명(한글)
	 */
	private String entrpsnmKorean;
	/**
	 * 업체명(영문)
	 */
	private String entrpsnmEng;
	/**
	 * 대표자명
	 */
	@NotEmpty(groups = Update.class, message = "대표자명은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String rprsntvNm;
	/**
	 * 사업자등록번호
	 */
	private String bsnmRegistNo;
	/**
	 * 법인등록번호
	 */
	private String cprRegistNo;
	/**
	 * 업태코드
	 */
	@NotEmpty(groups = Update.class, message = "업태코드는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String entrprsBizcndCode;
	/**
	 * 업종코드
	 */
	@NotEmpty(groups = Update.class, message = "업종코드는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String entrprsItemCode;
	/**
	 * 업체전화번호
	 */
	// @NotEmpty(groups = Update.class, message = "업체전화번호는 필수 입력입니다.") //
	// /message/validation.properties 에 등록된 메시지
	private String cmpnyTlphonNo;
	/**
	 * 업체fax번호
	 */
	private String cmpnyFaxNo;
	/**
	 * 업체 우편번호
	 */
	@NotEmpty(groups = Update.class, message = "우편번호는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String postNo;
	/**
	 * 업체 지번주소
	 */
	private String adres;
	/**
	 * 업체 지번상세주소
	 */
	private String detailAdres;
	/**
	 * 업체 도로명주소
	 */
	@NotEmpty(groups = Update.class, message = "도로명주소는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String rnAdres;
	/**
	 * 업체 도로명 상세주소
	 */
	@NotEmpty(groups = Update.class, message = "도로명 상세주소는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String rnDetailAdres;
	/**
	 * 환불계좌주명
	 */
	@NotEmpty(groups = Update.class, message = "환불계좌주명은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String refndAcnutNm;
	/**
	 * 환불계좌번호
	 */
	@NotEmpty(groups = Update.class, message = "환불계좌번호는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String refndAcnutNo;

	private String ewalletAcnutNo;
	/**
	 * 회원번호
	 */
	private String mberNo;
	/**
	 * 회원명
	 */
	private String mberNm;
	/**
	 * 회원 패스워드
	 */
	private String mberSecretNo;
	/**
	 * 회원 휴대폰번호
	 */
	private String moblphonNo;
	/**
	 * 권한구분코드
	 */
	private String mberSeCode;
	/**
	 * 환불계좌정합성여부
	 */
	private String refndAcnutRgrsynthAt;
	/**
	 * 환불계좌 상태코드
	 */
	private String refndAcnutSttusCode;
	/**
	 * 회원상태코드
	 */
	private String mberConfmSttusCode;
	/**
	 * 요청사유
	 */
	private String requstResn;
	/**
	 * 승인처리일시
	 */
	private String mberConfmProcessDt;
	/**
	 * 승인요청일시
	 */
	private String requstDt;
	/**
	 * 가입일
	 */
	private String mberEtrDt;
	/**
	 * 요청상태코드명
	 */
	private String mberConfmSttusCodeNm;
	/**
	 * 승인요청일시-승인처리일시
	 */
	private int dayDiff;
	/**
	 * 업체 기본정보 수정여부
	 */
	private boolean update01 = false;
	/**
	 * 업체 전화번호 수정여부
	 */
	private boolean update02 = false;
	/**
	 * 업체 계좌정보 수정여부
	 */
	private boolean update03 = false;
	/**
	 * 업체 추가결제수단 증거금 수정여부
	 */
	private boolean update04 = false;
	/**
	 * 업체 추가결제수단 전자상거래보증 수정여부
	 */
	private boolean update05 = false;
	/**
	 * 업체 추가결제수단 대출보증 수정여부
	 */
	private boolean update06 = false;
	/**
	 * 업체 케이지크레딧 수정여부
	 */
	private boolean update07 = false;
	/**
	 * 첨부파일 문서번호
	 */
	private int docNo;
	/**
	 * 사업자등록증 첨부파일 문서번호
	 */
	private int docNo1;
	/**
	 * 환불계좌 통장 첨부파일 문서번호
	 */
	private int docNo2;
	/**
	 * 첨부파일 문서명
	 */
	private String docSj;
	/**
	 * 사업자등록증 첨부파일 문서명
	 */
	private String docSj1;
	/**
	 * 환불계좌 통장 첨부파일 문서명
	 */
	private String docSj2;
	/**
	 * 첨부파일 업무구분코드
	 */
	private String jobSeCode;
	/**
	 * 첨부파일 화면아이디
	 */
	private String scrinId;
	/**
	 * 최종변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 최초등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 업체 탈퇴 가능여부
	 */
	private String secessionPossibleYn;
	/**
	 * 회원 승인상태코드
	 */
	private String mberSttusCode;

	/**
	 * 구매담당자 이메일
	 */
	private String purchschargerEmail;

	/**
	 * 계좌 미등록 메일 발송 여부
	 */
	private String acnutUnregistEmailSndngAt;

	/**
	 * 계좌 미등록 메일 발송 일시
	 */
	private String acnutUnregistEmailSndngDt;
	/**
	 * 업체 평가등급
	 */
	private String entrpsEvlGrad;
	/**
	 * 업체 평가등급명
	 */
	private String entrpsEvlGradNm;
	/**
	 * 회원_업체 투자 성향 등급
	 */
	private String entrpsPurchsInclnGrad;
	/**
	 * 회원_업체 투자 성향 등급명
	 */
	private String entrpsPurchsInclnGradNm;
	/**
	 * 증거금 권한비율
	 */
	private double wrtmAuthorRate;
	/**
	 * 증거금 사용여부
	 */
	private String wrtmUseAt;
	/**
	 * 증거금 신청일시
	 */
	private String wrtmReqstAt;
	/**
	 * 증거금 신청일시
	 */
	private String wrtmReqstDt;
	/**
	 * 증거금 해지여부
	 */
	private String wrtmTrmnatAt;
	/**
	 * 증거금 해지일시
	 */
	private String wrtmTrmnatDt;
	/**
	 * 전자상거래보증 사용여부
	 */
	private String mrtggGrntyUseAt;
	/**
	 * 전자상거래보증 신청여부
	 */
	private String mrtggGrntyReqstAt;
	/**
	 * 전자상거래보증 신청일시
	 */
	private String mrtggGrntyReqstDt;
	/**
	 * 전자상거래보증 보험료율
	 */
	private double mrtggGrntyInsrncTariff;
	/**
	 * 전자상거래보증 수수료 부담 주체
	 */
	private String mrtggGrntyFeeBndMbyAt;
	/**
	 * 전자상거래보증 보험료
	 */
	private long mrtggGrntyIrncf;
	/**
	 * 전자상거래보증 지원금액
	 */
	private long mrtggGrntyIrncfSportStdrAmount;
	/**
	 * 전자상거래보증 확인보험료
	 */
	private long mrtggGrntyCnfirmIrncf;
	/**
	 * 전자상거래보증 해지여부
	 */
	private String mrtggGrntyTrmnatAt;
	/**
	 * 전자상거래보증 해지일시
	 */
	private String mrtggGrntyTrmnatDt;
	/**
	 * 전자상거래보증 보증번호
	 */
	private String grntyNo;
	/**
	 * 전자상거래보증 계약시작일자
	 */
	private String grntyTmlmtBeginDe;
	/**
	 * 전자상거래보증 계약종료일자
	 */
	private String grntyTmlmtEndDe;
	/**
	 * 담보 보증금액
	 */
	private long grntyAmount;
	/**
	 * 잔액
	 */
	private long mrtggBlce;
	/**
	 * 여신구간
	 */
	private int cdtlnSctn;
	/**
	 * 상환기간
	 */
	private int mrtggGrntyPermRepyPd;
	/**
	 * 전자상거래보증 계약 여부
	 */
	private String mrtggGrntyCntrctAt;
	/**
	 * 전자상거래보증 만료여부
	 */
	private String endAt;
	/**
	 * 업체 전자상거래보증 계약 순번
	 */
	private int entrpsMrtggCntrctSn;
	/**
	 * 전자상거래보증 계약 진행상태 코드
	 */
	private String mrtggProgrsSttusCode;
	/**
	 * 전자상거래보증 거래유형코드
	 */
	private String mrtggDelngTyCode;
	/**
	 * 전자상거래보증 적요
	 */
	private String mrtggSumry;
	/**
	 * 전자상거래보증 거래금액
	 */
	private long mrtggDelngAmount;
	/**
	 * 업체 전자상거래보증 순번
	 */
	private int entrpsMrtggSn;
	/**
	 * 구매자금 사용여부
	 */
	private String lonGrntyUseAt;
	/**
	 * 구매자금 신청여부
	 */
	private String lonGrntyReqstAt;
	/**
	 * 구매자금 신청일시
	 */
	private String lonGrntyReqstDt;
	/**
	 * 구매자금 수수료 부담주체
	 */
	private String lonGrntyFeeBndMbyAt;
	/**
	 * 구매자금 해지여부
	 */
	private String lonGrntyTrmnatAt;
	/**
	 * 구매자금 해지일시
	 */
	private String lonGrntyTrmnatDt;
	/**
	 * 은행코드
	 */
	private String bankCode;
	/**
	 * 은행명
	 */
	private String bankCodeNm;
	/**
	 * 업체 은행 순번
	 */
	private int entrpsBankSn;
	/**
	 * 구매자금 은행 사용여부
	 */
	private String useAt;
	/**
	 * 구매자금 신청일시
	 */
	private String lonGrntyUseReqstDt;
	/**
	 * 구매자금 해지일시
	 */
	private String lonGrntyUseTrmnatDt;
	/**
	 * 구매자금 신청 은행목록
	 */
	private ArrayList<CorpInfoMgrVO> bankCodeList;
	/**
	 * 변경승인요청 상세코드
	 */
	private String changeConfmDetailCode;
	/**
	 * 변경승인요청사유
	 */
	private String changeRequstResn;
	/**
	 * 증거금 이용약관 동의 여부
	 */
	private String wrtmStplatAgreAt;
	/**
	 * 증거금 사용신청 승인여부
	 */
	private String wrtmConfmAt;
	/**
	 * 전자상거래보증 사용신청 승인여부
	 */
	private String mrtggGrntyConfmAt;
	/**
	 * 구매자금 사용신청 승인여부
	 */
	private String lonGrntyConfmAt;
	/**
	 * 총 주문 실적금액
	 */
	private long totSlepcAm;
	/**
	 * 총 구매자금 사용금액
	 */
	private long totLonUseAm;
	/**
	 * 증거금 약관 내용1
	 */
	private String stplatCnOne;
	/**
	 * 회원 가입연도
	 */
	private String mberEtrYear;
	/**
	 * 회원 가입달
	 */
	private String mberEtrMonth;
	/**
	 * 회원 가입일
	 */
	private String mberEtrDay;
	/**
	 * 회원 이메일 아이디
	 */
	private String emailId;
	/**
	 * 회원 이메일 도메인
	 */
	private String emailDomain;
	/**
	 * 여신서비스구분코드
	 */
	private String cdtlnSvcSeCode;
	private long sorinHopeLmtAmount;
	private String grntyReqstNo;
}
