package com.sorincorp.mfo.my.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DashboardVO extends CommonVO {

	/**
	 *
	 */
	private static final long serialVersionUID = -3191725947833794905L;
	/* 최근 30일 거래내역 */
    /**
     * 주문완료
    */
    private String orderCompt;
    /** 배송대기 */
    private String dlvyWait;
    /**
     * 배송준비
    */
    private String dlvyPrpare;
    /**
     * 배송지시
     */
    private String dlvyDrct;
    /**
     * 배차중
    */
    private String caralcing;
    /**
     * 배송중
     */
    private String dlvying;
    /**
     * 배송완료
     */
    private String dlvyCompt;

    /* 최근 24시간 내 3개 알림 내역 */
    /**
     * 메시지 제목
     */
    private String mssageSj;
    /**
     * 커머스 알림 내용
     */
    private String commerceNtcnCn;
    /**
     * 최초 등록 일시
     */
    private String frstRegistDt;


}
