package com.sorincorp.mfo.my.model;

import lombok.Data;

@Data
public class PaytEsamtVO {

	/******  JAVA VO CREATE : OR_ORDER_BAS(주문_주문 기본)                                                                                   ******/
	/** 순번 */
    private String rownum;
	/** 주문 번호 */
    private String orderNo;
    /** 주문 일자 */
    private String orderDe;
    /** 주문 시각 */
    private String orderTm;
    /** 장바구니 번호 */
    private String bsktNo;
    /** 회원 번호 */
    private String mberNo;
    /** 업체 번호 */
    private String entrpsNo;
    /** 업체 등급 번호 */
    private String entrpsGradNo;
    /** 접수 매체 구분 코드 */
    private String rceptMediaSeCode;
    /** 판매 방식 코드 */
    private String sleMthdCode;
    /** * 주문자 명 */
    private String ordrrNm;
    /** * 주문자 휴대폰 번호 */
    private String ordrrMoblphonNo;
    /** * 주문자 이메일 */
    private String ordrrEmail;
    /** * 주문 업체 명 */
    private String orderEntrpsNm;
    /** * 주문 업체 전화번호 */
    private String orderEntrpsTelno;
    /** * 주문 업체 우편번호 */
    private String orderEntrpsZip;
    /** * 주문 업체 주소 */
    private String orderEntrpsAdres;
    /** * 주문 업체 상세 주소 */
    private String orderEntrpsDetailAdres;
    /** * 주문 업체 도로명 주소 */
    private String orderEntrpsRnAdres;
    /** * 주문 업체 도로명 상세 주소 */
    private String orderEntrpsRnDetailAdres;
    /** * 주문 상태 코드 */
    private String orderSttusCode;
    /** * 배송 수단 코드 */
    private String dlvyMnCode;
    /** * 권역 대분류 코드 */
    private String dstrctLclsfCode;
    /** * 출고 요청 일자 */
    private String dlivyRequstDe;
    /** * 주문 배송지 번호 */
    private String orderDlvrgNo;
    /** * 주문 배송비 번호 */
    private String orderDlvrfNo;
    /** * 금속 코드 */
    private String metalCode;
    /** * 금속 코드명 */
    private String metalCodeNm;
    private String metalCodeNmEn;
    /** * 아이템 순번 */
    private int itmSn;
    /** * 아이템 명 */
    private String itmNm;
    /** * 상품 명 */
    private String goodsNm;
    /** * 브랜드 그룹 코드 */
    private String brandGroupCode;
    /** * 브랜드 코드 */
    private String brandCode;
    /** * 판매 단위 코드 */
    private String sleUnitCode;
    /** * 총 고객 주문 중량 */
    private int totCstmrOrderWt;
    /** * 총 실제 주문 중량 */
    private int totRealOrderWt;
    /** * 총 번들 수량 */
    private int totBundleQy;
    /** * 판매 가격 실시간 순번 */
    private String slePcRltmSn;
    /** * LME 가격 실시간 순번 */
    private String lmePcRltmSn;
    /** * 프리미엄 번호 */
    private String premiumNo;
    /** * 환율 가격 실시간 순번 */
    private String ehgtPcRltmSn;
    /** * 프리미엄 기준 금액 */
    private long premiumStdrAmount;
    /** * 권역 변동 금액 */
    private long dstrctChangeAmount;
    /** * 고정가 권역 변동 금액 */
    private long hghnetprcDstrctChangeAmount;
    /** * 브랜드 그룹 변동 금액 */
    private long brandGroupChangeAmount;
    /** * 고정가 브랜드 그룹 변동 금액 */
    private long hghnetprcBrandGroupChangeAmount;
    /** * 브랜드 변동 금액 */
    private long brandChangeAmount;
    /** * 고정가 브랜드 변동 금액 */
    private long hghnetprcBrandChangeAmount;
    /** * 프리미엄 가격 */
    private java.math.BigDecimal premiumPc;
    /** * LME 3M */
    private java.math.BigDecimal lme3m;
    /** * LME 현금 */
    private java.math.BigDecimal lmeCash;
    /** * LME 조정 계수 */
    private java.math.BigDecimal lmeMdatCffcnt;
    /** * 현물환 */
    private java.math.BigDecimal spex;
    /** * 현물환 조정 계수 */
    private java.math.BigDecimal spexMdatCffcnt;
    /** * 상품 단가 */
    private long goodsUntpc;
    /** * 주문 가격 */
    private long orderPc;
    /** * 중량 변동금 */
    private long wtChangegld;
    /** * 공급가 */
    private long splpc;
    /** * 부가세 */
    private long vat;
    /** * 판매가 */
    private long slepc;
    /** * 주문 완료 일시 */
    private java.sql.Timestamp orderComptDt;
    /** * 정산 처리 여부 */
    private String excclcProcessAt;
    /** * 정산 처리 일시 */
    private java.sql.Timestamp excclcProcessDt;
    /** * OMS 접수 번호 */
    private String omsRceptNo;
    /** * 주문 실패 사유 */
    private String orderFailrResn;
    /** * 총 확정 중량 */
    private java.math.BigDecimal totDcsnWt;
    /** * 총 확정 주문 가격 */
    private long totDcsnOrderPc;
    /** * 총 확정 공급가 */
    private long totDcsnSplpc;
    /** * 총 확정 일시 */
    private java.sql.Timestamp totDcsnDt;
    /** * 정산 공급가 */
    private long excclcSplpc;
    /** * 정산 부가세 */
    private long excclcVat;
    /** * 정산 금액 */
    private long excclcAmount;
    /** * 삭제 일시 */
    private java.sql.Timestamp deleteDt;
    /** * 삭제 여부 */
    private String deleteAt;
    /** * 최초 등록자 아이디 */
    private String frstRegisterId;
    /** * 최초 등록 일시 */
    private String frstRegistDt;
    /** * 최종 변경자 아이디 */
    private String lastChangerId;
    /** * 최종 변경 일시 */
    private String lastChangeDt;
    /** * */
    private java.math.BigDecimal hghnetprcTotAmtTariff;
    /** * */
    private long hghnetprcAvrgPurchsPrmpc;
    /** * */
    private long hghnetprcSleAmount;
    /** * 고객 판매 가격 실시간 순번 */
    private String cstmrSlePcRltmSn;
    /** * 고객 LME 가격 실시간 순번 */
    private String cstmrLmePcRltmSn;
    /** * */
    private String cstmrPremiumNo;
    /** * 고객 환율 가격 실시간 순번 */
    private String cstmrEhgtPcRltmSn;
    /** * 중량 변동 */
    private java.math.BigDecimal wtChange;
    /** * 차량 정보 등록 여부 */
    private String vhcleInfoRegistAt;
    /** * 당일 배송 여부 */
    private String todayDlvyAt;
    /** * */
    private String ordrrMoblphonNoOld;
    /** * 결제 방식 코드 */
    private String setleMthdCode;
    /** * 결제 방식 상세 코드 */
    private String setleMthdDetailCode;
    /** * 최초 결제 금액 */
    private long frstSetleAmount;
    /** * 미 결제 금액 */
    private long unSetleAmount;
    /** * 증거금 최소 증거금 비율 */
    private java.math.BigDecimal wrtmMummWrtmRate;
    /** * 증거금 결제 예정 일자 */
    private String wrtmSetlePrearngeDe;
    /** * 결제 예정일 */
    private String setlePrearngeDe;
    /** * 관리 번호(PK) */
    private String manageNo;
    /** * 입금일시 */
    private String setleDt;
    /** * 입금액 */
    private long setleAmount;
    /** * 결제 상태 */
    private String setleSttus;
    /** * 결제 종류 */
    private String setleKnd;
    /** 증거금사용여부 */
    private String wrtmUseAt;
    /** 전자상거래보증사용여부 */
    private String mrtggGrntyUseAt;
    /** 전자상거래보증승인여부 */
    private String mrtggGrntyConfmAt;
    /** 대출보증사용여부 */
    private String lonGrntyUseAt;
    /** 대출보증승인여부 */
    private String lonGrntyConfmAt;
    /** 대출상태코드 */
    private String lonSttusCode;
    /** 결제예정 카운트 */
    private int setleCntPrearnge;
    /** 결제미납 카운트 */
    private int setleCntNpy;
    /** 결제연체 카운트 */
    private int setleCntArrrg;
    /** 당일출고 결제가능 시간 */
    private String closTime;
    /** 대출은행코드 */
    private String bankCode;
    /** 대출은행 url */
    private String bankUrl;
    /** 상환가능여부 (결제예정일 당일 이후) */
    private String repyPossAt;
    /** 이미지 src */
    private String itmImgSrc;
    /** 계약번호 */
    private String cntrctNo;
}
