package com.sorincorp.mfo.tr.model;

import lombok.Data;

@Data
public class TrackVo {

	/**
	 * 방문자 기본 일련 번호
	 */
	private long visitrBassSeqNo;

	/**
	 * 방문자 아이디
	 */
	private String visitrId;

	/**
	 * 방문자 IP
	 */
	private String visitrIp;

	/**
	 * 회원 번호
	 */
	private String mberNo;

	/**
	 * 업체 번호
	 */
	private String entrpsNo;

	/**
	 * 접속 환경
	 */
	private String conectEnvrn;

	/**
	 * 로그인 방문자 아이디
	 */
	private String newVisitrId;

	/**
	 * 방문 상세 정보
	 */
	private TrackDetailVo trackDetailVo;
	
	/**
	 * 회원 전환 정보
	 */
	private TrackMemberVo trackMemberVo;

	/**
	 * 유입 경로
	 */
	private String inflowCours;
	
	/**
	 * 구매 전환 정보
	 */
	private TrackOrderVo trackOrderVo;
	
}