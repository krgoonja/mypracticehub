package com.sorincorp.mfo.tr.model;

import lombok.Data;

@Data
public class TrackOrderVo {

    /**
     * 방문자 이동 일련 번호
    */
    private long visitrMvmnSeqNo;
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 판매 방식 코드
    */
    private String sleMthdCode;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 순번
    */
    private String itmSn;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    /**
     * 상품 명
    */
    private String goodsNm;
    /**
     * 번들 수량
    */
    private int bundleQy;
    /**
     * 총 실제 주문 중량
    */
    private int totRealOrderWt;
    /**
     * 공급가
    */
    private long splpc;
    /**
     * 결제 방식 코드
    */
    private String setleMthdCode;
    /**
     * 결제 방식 상세 코드
    */
    private String setleMthdDetailCode;
    /**
     * 배송 수단 코드
    */
    private String dlvyMnCode;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
}
