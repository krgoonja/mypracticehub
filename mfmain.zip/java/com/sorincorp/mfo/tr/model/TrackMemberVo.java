package com.sorincorp.mfo.tr.model;

import lombok.Data;

@Data
public class TrackMemberVo {

    /**
     * 방문자 이동 일련 번호
    */
    private long visitrMvmnSeqNo;
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 업체명 한글
    */
    private String entrpsnmKorean;
    /**
     * 대표자 명
    */
    private String rprsntvNm;
    /**
     * 우편 번호
    */
    private String postNo;
    /**
     * 주소
    */
    private String adres;
    /**
     * 상세 주소
    */
    private String detailAdres;
    /**
     * 도로명 주소
    */
    private String rnAdres;
    /**
     * 도로명 상세 주소
    */
    private String rnDetailAdres;
    /**
     * 회사 전화 번호
    */
    private String cmpnyTlphonNo;
    /**
     * 회원 이메일
    */
    private String mberEmail;
    /**
     * 휴대전화 번호
    */
    private String moblphonNo;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
}
