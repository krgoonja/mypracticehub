package com.sorincorp.mfo.tr.service;

import java.net.URLDecoder;
import java.util.Map;

import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.mfo.tr.mapper.TrackMapper;
import com.sorincorp.mfo.tr.model.TrackDetailVo;
import com.sorincorp.mfo.tr.model.TrackMemberVo;
import com.sorincorp.mfo.tr.model.TrackOrderVo;
import com.sorincorp.mfo.tr.model.TrackVo;

import lombok.extern.slf4j.Slf4j;
/**
 * @ClassName: TrackSorinServiceImpl
 * @Author: chajeeman
 * @Date: 2023. 5. 19.
 */

@Slf4j
@Service
public class TrackSorinServiceImpl implements TrackSorinService {

	@Value("${redisPubsub.uri.track}")
	private String trackUri;

	@Autowired
	private RedisPubSubService redisPubSubService;

	/* 공통 서비스 */
	@Autowired
	private CommonService commonService;

	@Autowired
	private TrackMapper trackMapper;

	@Override
	public int trackSorin(TrackVo trackVo) throws Exception {
		int result = 0;

		trackMapper.insertVisitrTrackBas(trackVo);

		TrackDetailVo trackDetailVo = trackVo.getTrackDetailVo();
		trackDetailVo.setVisitrBassSeqNo(trackVo.getVisitrBassSeqNo());
		trackMapper.insertVisitrTrackDetail(trackDetailVo);


		Map<String, Object> trackMsgMap = trackMapper.selectTrackMsg(trackDetailVo);
		//PC, 모바일 분류
		boolean isMobile = ((String) trackMsgMap.get("conectEnvrn")).matches(".*(iPhone|iPod|iPad|BlackBerry|Android|Windows CE|LG|MOT|SAMSUNG|SonyEricsson).*");
		if(isMobile) {
			trackMsgMap.put("rceptMediaSeCode", "02");
		}else {
			trackMsgMap.put("rceptMediaSeCode", "01");
		}
		trackMsgMap.put("newVisitrId", trackVo.getNewVisitrId());
		trackMsgMap.put("visitrId", trackVo.getVisitrId());
		redisPubSubService.publishMessage(trackUri, "/track", trackMsgMap);

		// 전환정보 저장
		if (trackVo.getTrackMemberVo() != null) {
			TrackMemberVo memberVo = trackVo.getTrackMemberVo();
			memberVo.setVisitrMvmnSeqNo(trackDetailVo.getVisitrMvmnSeqNo());

			trackMapper.insertTrackMber(memberVo);
		}
		if (trackVo.getTrackOrderVo() != null) {
			TrackOrderVo orderVo = trackVo.getTrackOrderVo();
			orderVo.setVisitrMvmnSeqNo(trackDetailVo.getVisitrMvmnSeqNo());
			if (orderVo.getGoodsNm() != null && !"".equals(orderVo.getGoodsNm())) {
				orderVo.setGoodsNm(URLDecoder.decode(orderVo.getGoodsNm(), "UTF-8"));
			}
			trackMapper.insertTrackOrder(orderVo);
		}

		return result;
	}

	public void trackHealthCheck(TrackVo trackVo) throws Exception {
		try {
			//방문자 IP 저장
			String visitrIp = commonService.getClientIpAddressIfServletRequestExist();
			trackVo.setVisitrIp(visitrIp);
			// 최종 변경 일시 업데이트
			trackMapper.trackHealthCheck(trackVo);
		} catch (Exception e) {
			log.error("[TrackSorinServiceImpl][trackHealthCheck]" + ExceptionUtils.getStackTrace(e));
		}
	}

}