package com.sorincorp.mfo.tr.mapper;

import java.util.Map;

import com.sorincorp.mfo.tr.model.TrackDetailVo;
import com.sorincorp.mfo.tr.model.TrackMemberVo;
import com.sorincorp.mfo.tr.model.TrackOrderVo;
import com.sorincorp.mfo.tr.model.TrackVo;

/**
 * @ClassName: TrackMapper
 * @Author: chajeeman
 * @Date: 2023. 5. 19.
 */
public interface TrackMapper {
	
	/**
	 * <pre>
	 * 처리내용: 방문자 트래킹 기본정보 추가
	 * </pre>
	 * @date 2023. 05. 22.
	 * @author srec0068
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 05. 22.		srec0068			최초작성
	 * ------------------------------------------------
	 * @param trackVo
	 * @return
	 * @throws Exception
	 */
	void insertVisitrTrackBas(TrackVo trackVo) throws Exception;
	
	
	/**
	 * <pre>
	 * 처리내용: 방문자 트래킹 상세정보 추가
	 * </pre>
	 * @date 2023. 05. 22.
	 * @author srec0068
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 05. 22.		srec0068			최초작성
	 * ------------------------------------------------
	 * @param trackVo
	 * @return
	 * @throws Exception
	 */
	void insertVisitrTrackDetail(TrackDetailVo trackDetailVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 방문자 트래킹 - 회원전환
	 * </pre>
	 * @date 2023. 05. 22.
	 * @author srec0068
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 05. 22.		srec0068			최초작성
	 * ------------------------------------------------
	 * @param trackVo
	 * @return
	 * @throws Exception
	 */
	void insertTrackMber(TrackMemberVo trackVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 방문자 트래킹 - 구매전환
	 * </pre>
	 * @date 2023. 05. 26.
	 * @author srec0068
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 05. 26.		srec0068			최초작성
	 * ------------------------------------------------
	 * @param trackVo
	 * @return
	 * @throws Exception
	 */
	void insertTrackOrder(TrackOrderVo trackVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 방문자 트래킹 - 전송할 정보 조회
	 * </pre>
	 * @date 2023. 05. 26.
	 * @author srec0068
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 05. 26.		srec0068			최초작성
	 * ------------------------------------------------
	 * @param trackVo
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> selectTrackMsg(TrackDetailVo trackVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 방문자 트래킹 헬스체크
	 * </pre>
	 * @date 2023. 08. 30.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 08. 30.		hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param trackVo
	 * @return
	 * @throws Exception
	 */
	void trackHealthCheck(TrackVo trackVo) throws Exception;
	
}
