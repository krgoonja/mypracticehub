package com.sorincorp.mfo.login.mapper;

import com.sorincorp.mfo.login.model.Account;
import com.sorincorp.mfo.login.model.LoginVO;

public interface AccountMapper {
	/**
	 * <pre>
	 * User ID로 사용자의 정보를 가져온다.
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 21.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param id
	 * @return
	 * @throws Exception
	 */
	Account selectAccount(String id) throws Exception;
	

	Account selectAccountByPhone(String phoneNum);
	
	
	/**
	 * <pre>
	 * 처리내용: 비밀번호 찾기를 위한 계정 조회
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 * @throws Exception
	 */
	int selectSearchPw(Account account) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @throws Exception
	 */
	void updatePw(Account account) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 비밀번호 변경 안내를 위한 계정 조회
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 * @throws Exception
	 */
	int selectPwNotice(Account account) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원 상태 코드 변경
	 * </pre>
	 * @date 2021. 9. 3.
	 * @author srec0041
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 3.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param account
	 */
	void updateMberSttusCode(Account account);

	/**
	 * <pre>
	 * 처리내용: 휴면 회원 삭제
	 * </pre>
	 * @date 2021. 9. 3.
	 * @author srec0041
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 3.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param account
	 */
	void deleteMberDrmncy(Account account);
	
	void updateRecentLoginDate(Account account);

	String selectSignUpdate(Account account);
	
	/**
	 * <pre>
	 * 처리내용: 다음 비밀번호 변경일 조회
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 */
	int selectNextPwChgDate(Account account);
	
	/**
	 * <pre>
	 * 처리내용: 다음 비밀번호 변경일 수정
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param account
	 */
	void updateNextPwChgDate(Account account) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 비밀번호 수정을 위한 계정 조회
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param account
	 * @return
	 */
	int selectChangePw(Account account);

	void insertLoginHist(LoginVO logVo);

	void updateLoginLogSttusCd(Account account);

	void updateLoginFailCount(Account account);

	void updateMberSttusCd(Account account);
	
	void updateMberSttusCdHist(Account account);

	void resetLoginFailCount(Account account);

	void insertMbInfoBasHst(Account account);

	/**
	 * <pre>
	 * 회원 업체정보를 조회한다.
	 * </pre>
	 * @date 2022. 7. 08.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 08.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return : accountEntrpsInfoVO
	 * @throws Exception
	 */
	//AccountEntrpsInfoVO selectAccountEntrpsInfo(String entrpsNo) throws Exception;
}
