package com.sorincorp.mfo.login.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sorincorp.mfo.login.mapper.AccountMapper;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.HttpUtil;
import com.sorincorp.comm.util.MessageUtil;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.mfo.config.LoginTokenProvider;
import com.sorincorp.mfo.login.model.Account;
import com.sorincorp.mfo.login.model.LoginVO;
import com.sorincorp.mfo.login.service.AccountServiceImpl;

import io.jsonwebtoken.ExpiredJwtException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor
@Controller
@RequestMapping("/account")
@Slf4j
public class LoginController {
	private final PasswordEncoder passwordEncoder;
	private final LoginTokenProvider loginTokenProvider;
	private final AccountServiceImpl accountService;
	private final SMSService smsService;
	private final AccountMapper accountMapper;
	private final MessageUtil messageUtil;
	private final RedisUtil redisUtil;

	@Autowired
	private CustomValidator customValidator;

	@Autowired
	private CommonService commonService;

	/**
	 * <pre>
	 * 처리내용: 로그인 페이지를 조회한다.
	 * </pre>
	 *
	 * @date 2023.12.13.
	 * @author sumin
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023.12.13. sumin
	 *          최초작성 ------------------------------------------------
	 * @return
	 */
	@RequestMapping("/login")
	public String login(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
		try {

			return "us/loginMain";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

	@ResponseBody
	@PostMapping("/login/memberVal")
	public ResponseEntity<Object> memberVal(@RequestBody LoginVO loginVO, BindingResult bindingResult) throws Exception {
		Map<String, Object> map = new HashMap<>();


		customValidator.validate(loginVO, bindingResult, LoginVO.loginInfo.class);

		if (bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		Account account = accountService.selectAccount(loginVO.getId());

		if (account == null) {
			return new ResponseEntity<>(messageUtil.getMessage("mfo.co.text.invalid.user"), HttpStatus.BAD_REQUEST);
		}


		if (!passwordEncoder.matches(CryptoUtil.encryptSHA256(loginVO.getPassword()), "{noop}" + account.getPassword())) {

			if (account.getMberSttusCode().equals("02")) { // 잠금 회원(02)일 경우에만 체크
				return new ResponseEntity<>(messageUtil.getMessage("mfo.mb.validaion.is_locked"), HttpStatus.BAD_REQUEST);
			}

			if (account.getMberSttusCode().equals("01")) { // 정회원(01)일 경우에만 체크
				accountService.updateLoginFailCount(account); // 로그인 실패 횟수
				if (account.getSecretNoErrorCo() >= 4) {

					account.setMberSttusCode("02"); // 회원 기본 계정 잠김
					account.setLoginSttusCode("03"); // 히스토리 계정 잠김
					accountService.updateMberSttusCd(account); // 회원 상태 잠금회원으로 수정 정회원 계정잠김(02)
					accountService.updateMberSttusCdHist(account);// 히스토리 계정 잠김
					commonService.insertTableHistory("MB_MBER_INFO_BAS", account);
					// accountService.insertMbInfoBasHst(account);// 회원 히스토리 테이블 INSERT
					return new ResponseEntity<>(messageUtil.getMessage("mfo.co.text.invalid.password"), HttpStatus.BAD_REQUEST);
				}
			}
			return new ResponseEntity<>(messageUtil.getMessage("mfo.co.text.invalid.password"), HttpStatus.BAD_REQUEST);
		}


		String authNum = "";
		if (account.getScndCrtfcMnAt().equals("Y")) {
			authNum = accountService.phoneAuth(account);
		} else {
			authNum = "047291";
			map.put("authNum", authNum);
		}

		String token = loginTokenProvider.generateSmsToken(authNum);

		map.put("token", token);
		map.put("scndCrtfcMnAt", account.getScndCrtfcMnAt()); // 2차인증여부

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@ResponseBody
	@PostMapping("/login/getToken")
	public ResponseEntity<Object> getToken(@RequestBody LoginVO loginVO, HttpServletRequest request, HttpServletResponse response, BindingResult bindingResult) {
		customValidator.validate(loginVO, bindingResult, LoginVO.loginAuth.class);

		if (bindingResult.hasErrors()) {
			return new ResponseEntity<>(bindingResult.getAllErrors(), HttpStatus.BAD_REQUEST);
		}

		try {
			Account account = accountService.selectAccount(loginVO.getId());

			if (account == null) {
				return new ResponseEntity<>(messageUtil.getMessage("co.text.invalid.user"), HttpStatus.BAD_REQUEST);
			}

			if (!passwordEncoder.matches(CryptoUtil.encryptSHA256(loginVO.getPassword()), "{noop}" + account.getPassword())) {
				return new ResponseEntity<>(messageUtil.getMessage("co.text.invalid.password"), HttpStatus.BAD_REQUEST);
			}
			if (!loginVO.getAuthNum().equals(loginTokenProvider.getUsername(loginVO.getToken()))) {
				return new ResponseEntity<>(messageUtil.getMessage("co.text.invalid.authnum"), HttpStatus.BAD_REQUEST);
			}

			LoginVO logVo = new LoginVO();
			logVo.setLoginIp(HttpUtil.getClientIp(request));
			logVo.setMberNo(account.getMberNo());
			logVo.setId(account.getId());

			// Token 생성전에 패스워드정보를 제외한다.
			account.setPassword(null);

			if (account.getMberSttusCode().equals("05")) {
				Map<String, Object> map = new HashMap<>();
				logVo.setLoginSttusCode("03"); // 계정 잠금
				map.put("result", "inActive");
				map.put("account", account);

				accountMapper.insertLoginHist(logVo);
				return new ResponseEntity<>(map, HttpStatus.OK);
			}

			/* 비밀번호 재설정 주석처리
			 * if (accountService.selectNextPwChgDate(account) <= 0) { Map<String, Object>
			 * map = new HashMap<>(); logVo.setLoginSttusCode("03"); // 로그인 로그 계정 잠금
			 * commonService.insertTableHistory("MB_LOGIN_INFO", logVo); //
			 * accountMapper.insertLoginHist(logVo); map.put("result", "pwUpdate");
			 * map.put("id", account.getId()); return new ResponseEntity<>(map,
			 * HttpStatus.OK); }
			 */

			if (account.getMberSttusCode().equals("02")) { // 정회원 계정잠김(02)
				account.setMberSttusCode("01"); // 회원 기본 정회원
				account.setLoginSttusCode("04"); // 히스토리 계정 잠김 해제
				accountService.updateMberSttusCd(account); // 회원 상태 정회원으로 수정 (01)
				accountService.updateMberSttusCdHist(account);// 히스토리 계정 잠김 해제 (04)
				accountService.resetLoginFailCount(account); // 비밀번호 오류횟수 0으로 리셋
			}

			// Access Token, Refresh Token 생성
			final String access = loginTokenProvider.generateAccessToken(account, account.getId());
			final String refresh = loginTokenProvider.generateRefreshToken(account.getId());

			// Access Token, Refresh Token을 저장할 Cookie 생성
			ResponseCookie accessToken = loginTokenProvider.createSecureCookie(CommonConstants.ACCESS_TOKEN_NAME, access, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND);
			ResponseCookie refreshToken = loginTokenProvider.createSecureCookie(CommonConstants.REFRESH_TOKEN_NAME, refresh, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND);

			// Token을 Redis에 저장(만료기간 지정)
			redisUtil.setDataExpire(CommonConstants.REDIS_KEY_FO_ACCESS + account.getId(), access, CommonConstants.ACCESS_TOKEN_VALIDATION_SECOND + 5000L);
			redisUtil.setDataExpire(CommonConstants.REDIS_KEY_FO_REFRESH + account.getId(), refresh, CommonConstants.REFRESH_TOKEN_VALIDATION_SECOND + 5000L);

			// 아이디저장 쿠키 제거, 생성은 loginMain.jsp
			if (!loginVO.getSaveId()) {
				ResponseCookie saveIdCookie = loginTokenProvider.createSecureCookie("saveId", null, 0);
				response.addHeader(HttpHeaders.SET_COOKIE, saveIdCookie.toString());
			}

			// Token Cookie를 Response에 추가
			response.addHeader(HttpHeaders.SET_COOKIE, accessToken.toString());
			response.addHeader(HttpHeaders.SET_COOKIE, refreshToken.toString());

			accountService.updateRecentLoginDate(account);
			logVo.setLoginSttusCode("01"); // 정상
			accountMapper.insertLoginHist(logVo);// 로그인 로그
			accountMapper.insertMbInfoBasHst(account);// 회원 히스토리 테이블 INSERT

			//로그인성공,마케팅수신 동의여부 Y,대행업무 제외 알림톡 전송
			if(("01").equals(logVo.getLoginSttusCode()) && ("Y").equals(account.getAdvrtsRecptnAgreAt()) && !("03").equals(loginVO.getConectEnvrnCode())) {
				Map<String, String> smsMap = new HashMap<String, String>();
				SMSVO smsVO = new SMSVO();

				smsMap.put("commerceNtcnCn", "로그인 알림"); // 알림 메세지
				smsMap.put("templateNum", "148");
				smsMap.put("excpSndngOptnAt", "N"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
				smsVO.setPhone(account.getPhonenum());
			    smsVO.setMberNo(account.getMberNo());

				smsService.insertSMS(smsVO, smsMap);
			}

			return new ResponseEntity<>("login", HttpStatus.OK);

		} catch (ExpiredJwtException e) {
			return new ResponseEntity<>(messageUtil.getMessage("co.text.invalid.authtime.expired"), HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			// e.printStackTrace();
			log.error(ExceptionUtils.getStackTrace(e));
			return null;
		}
	}

	@GetMapping("/logout")
	public ResponseEntity<Object> logout(HttpServletRequest request, HttpServletResponse response) throws Exception {

		Map<String,Object> map = new HashMap<>();
		map.put("result", "login");

		// Access Token Cookie 조회
		Cookie accessToken = loginTokenProvider.getCookie(request, CommonConstants.ACCESS_TOKEN_NAME);
		if ( accessToken != null ) {
			ResponseCookie responseAccesstoken = loginTokenProvider.createSecureCookie(CommonConstants.ACCESS_TOKEN_NAME,null,0);
			response.addHeader(HttpHeaders.SET_COOKIE, responseAccesstoken.toString());

			redisUtil.deleteData(CommonConstants.REDIS_KEY_MFO_ACCESS + loginTokenProvider.getUsername(accessToken.getValue()));
		}

		// Refresh Token Cookie 조회
		Cookie refreshToken = loginTokenProvider.getCookie(request, CommonConstants.REFRESH_TOKEN_NAME);
		if ( refreshToken != null ) {
			// Cookie가 있으면 Cookie 삭제
			ResponseCookie responseRefreshToken = loginTokenProvider.createSecureCookie(CommonConstants.REFRESH_TOKEN_NAME,null,0);
			response.addHeader(HttpHeaders.SET_COOKIE, responseRefreshToken.toString());
			// Redis에서 Refresh Token 삭제
			redisUtil.deleteData(CommonConstants.REDIS_KEY_MFO_REFRESH + loginTokenProvider.getUsername(refreshToken.getValue()));
		}

		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@RequestMapping("/login/inactive")
	public String inActive() {
		try {
			return "us/askMemberActive"; //휴면 계정 안내 화면
//			return "error/503";
		} catch (Exception e) {
			log.error(e.getMessage());
			return "error/503";
		}
	}

}
