package com.sorincorp.mfo.config;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

public class HttpMethodInterceptor implements HandlerInterceptor {

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// TODO Auto-generated method stub
		if (null != modelAndView) {
			String viewName = modelAndView.getViewName();
			
			if ("GET".equals(request.getMethod())) {
				// 서브도메인에 따른 분기(customTiles) [차랑등록], 20230717 추가
				if (viewName.indexOf(".tiles") == -1) {
					modelAndView.setViewName(viewName + ".tiles");
				} 
			} else if ("POST".equals(request.getMethod())) {
				if (viewName.indexOf("redirect") > -1) {
					modelAndView.setViewName(viewName + ".tiles");
				}
			}
		}

		HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
	}

}
