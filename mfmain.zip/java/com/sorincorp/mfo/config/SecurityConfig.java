package com.sorincorp.mfo.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.mfo.login.service.AccountServiceImpl;

import lombok.RequiredArgsConstructor;

/**
 * JWT를 사용할 수 있도록 SecurityConfig를 수정
 * @version
 * @since 2021. 7. 7.
 * @author srec0012
 */
@RequiredArgsConstructor
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	private final LoginTokenProvider loginTokenProvider;
	private final AccountServiceImpl accountService;
	private final RedisUtil redisUtil;
	private final CommonCodeService commonCodeService;
	
	/**
	 * 차량등록 서브도메인
	 */
	@Value("${spring.mfo.subDomain}")
	private String MFO_SUBDOMAIN;
	
	/**
	 * 로그인이 필요한 URL 지정
	 */
	private static final String[] LOGIN_LIST = {
			"/messageSample"
	};

	/**
	 * 로그인 체크가 필요없는 URL 지정
	 */
	private static final String[] IGNORE_LIST = {
			"/images/**", 
			"/css/**", 
			"/js/**",
			"/fonts/*",
			"/guide/*",
			"/error/*",
			"/properties/*"
	};
	
	/**
	 * <pre>
	 * 암호화에 필요한 PasswordEncoder를 Bean 등록
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@Bean
	public PasswordEncoder passwordEncoder() {
		return PasswordEncoderFactories.createDelegatingPasswordEncoder();
	}
	
	/**
	 * authenticationMannger를 Bean 등록
	 */
	@Bean
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}
	
	/**
	 * Spring Security Configuration 설정. 로그인이 필요한 경우 JWT Token 체크를 위한 Filter를 거치도록 지정
	 */
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http.headers().frameOptions().sameOrigin().and()
		.httpBasic().disable()
		.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
		.and()
		.authorizeRequests()
		/* ROLE을 사용하는 경우만 처리
		.antMatchers("/admin/**").hasRole("ADMIN") 
		*/		
		.antMatchers("/**").permitAll()
		.and().csrf().disable()
		.addFilterBefore(new LoginAuthenticationFilter(loginTokenProvider, accountService, redisUtil,commonCodeService, MFO_SUBDOMAIN), UsernamePasswordAuthenticationFilter.class);
	}
	
	/**
	 * 로그인 체크가 필요없는 URL 지정
	 */
	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers(IGNORE_LIST);
	}
	
}
