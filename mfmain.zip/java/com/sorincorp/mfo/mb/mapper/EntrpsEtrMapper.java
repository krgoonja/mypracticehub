package com.sorincorp.mfo.mb.mapper;

import java.util.List;

import com.sorincorp.mfo.mb.model.DocInfoVO;
import com.sorincorp.mfo.mb.model.EntrpsEtrVO;
import com.sorincorp.mfo.my.model.CorpInfoMgrVO;

public interface EntrpsEtrMapper {

	/**
	 * <pre>
	 * 처리내용: 사업자 번호 확인
	 * </pre>
	 *
	 * @date 2021. 7. 19.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 19.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param bsnmRegistNo
	 */
	int checkBsnmRegistNo(EntrpsEtrVO entrpsEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원 구분 코드 조회
	 * </pre>
	 *
	 * @date 2021. 9. 28.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 28.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	String selectMberSeCode(EntrpsEtrVO entrpsEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용:
	 * </pre>
	 *
	 * @date 2021. 7. 19.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 19.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param mberId
	 * @return
	 */
	int selectMberId(String mberId) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원가입(회원사 테이블 입력)
	 * </pre>
	 *
	 * @date 2021. 7. 20.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 20.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	int insertMbEntrpsInfoBas(EntrpsEtrVO entrpsEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원가입(회원 테이블 입력)
	 * </pre>
	 *
	 * @date 2021. 7. 20.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 20.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	int insertMbMberInfoBas(EntrpsEtrVO entrpsEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원가입(배송지 테이블 입력)
	 * </pre>
	 *
	 * @date 2021. 7. 20.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 20.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	int insertMbDlvrgBas(EntrpsEtrVO entrpsEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용:
	 * </pre>
	 *
	 * @date 2021. 7. 26.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 26.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	List<EntrpsEtrVO> selectEntrpsEtrStplat() throws Exception;

	/**
	 * <pre>
	 * 처리내용:
	 * </pre>
	 *
	 * @date 2021. 8. 3.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 8. 3.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param docInfo
	 * @return
	 */
	int insertAttachFile(DocInfoVO docInfo) throws Exception;

	/**
	 * <pre>
	 * 처리내용:
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 */
	int insertMbEntrpsInfoBasHst(EntrpsEtrVO entrpsEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용:
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 */
	int insertMbMberInfoBasHst(EntrpsEtrVO entrpsEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용:
	 * </pre>
	 *
	 * @date 2021. 9. 16.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 9. 16.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 */
	int insertMbDlvrgBasHst(EntrpsEtrVO entrpsEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 11. 24.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 11. 24.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	int selectMberMobNo(EntrpsEtrVO entrpsEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 11. 24.
	 * @author srec0009
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 11. 24.
	 *          srec0009 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	String selectRefndAccntSattus(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 마케팅 수신 동의 여부
	 * </pre>
	 *
	 * @date 2022. 06. 03.
	 * @author : sumin95
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 06. 03.
	 *          sumin95 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	int insertMberMarktRecptnMediaBas(EntrpsEtrVO entrpsEtrVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 마케팅 수신 동의 여부 이력
	 * </pre>
	 *
	 * @date 2022. 06. 03.
	 * @author : sumin95
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 06. 03.
	 *          sumin95 최초작성 ------------------------------------------------
	 * @param entrpsEtrVO
	 * @return
	 */
	int insertMberMarktRecptnMediaHst(EntrpsEtrVO entrpsEtrVO) throws Exception;

	List<CorpInfoMgrVO> selectMbEntrpsMrtggCntrctBasUnMatchList(String bsnmRegistNo) throws Exception;

	int updateMbEntrpsMrtGGCntrctBasEntrpsNo(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	int insertMbEntrpsMrtGGCntrctBasHst(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	long selectMrtggBlce(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	int insertMbEntrpsMbEntrpsMrtggLmtDtl(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	int insertMbEntrpsMbEntrpsMrtggLmtDtlHst(CorpInfoMgrVO corpInfoMgrVO) throws Exception;

	int checkCprRegistNo(EntrpsEtrVO entrpsEtrVO) throws Exception;
	
	String selectEntrpsNo(String mberId) throws Exception;
	
	List<EntrpsEtrVO> getEntrpsInfo(String mberId) throws Exception;

}
