/**
 *
 */
package com.sorincorp.mfo.mb.model;

import java.util.List;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * EntrpsMbVO.java
 *
 * @version
 * @since 2021. 6. 7.
 * @author srec0009
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class DocInfoVO extends CommonVO {
	/**
	 * serialVersion UID
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 업체 번호
	 */
	private String entrpsNo;

	/**
	 * 화면번호
	 */
    private String scrinId;

    /**
     * 업무 구분 코드
    */
    private String jobSeCode;

    /**
     * 파일 실제경로
     */
    private String docFileRealCours;
    /**
     * 사업자 등록증 파일 번호
    */
    private int docNo;
    /**
     * 사업자 등록증 파일 이름
    */
    private String docSj;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;


}
