/**
 *
 */
package com.sorincorp.mfo.mb.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.annotation.MaskingClass;
import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * EntrpsMbVO.java
 *
 * @version
 * @since 2021. 6. 7.
 * @author srec0009
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Validated
@MaskingClass
public class EntrpsEtrVO extends CommonVO {
	/**
	 * serialVersion UID
	 */
	private static final long serialVersionUID = 1L;

	/****** JAVA VO CREATE : MB_ENTRPS_INFO_BAS(회원_업체 정보 기본) ******/
	/**
	 * vo 리스트
	 */
	////////////////////[[ 업체 기본 정보 ]]///////////////////
	/**
	 * 업체 번호
	 */
	@NotEmpty(message = "업체 번호는 필수값입니다.")
	private String entrpsNo;
	/**
	 * 업체 등급 레벨
	 */
	private String entrpsGradLevel;
	/**
	 * 업체 등급명
	 */
	private String entrpsGradNm;
	/**
	 * 업체명 한글
	 */
	@NotEmpty(message = "업체명 한글은 필수값입니다.")
	private String entrpsnmKorean;
	/**
	 * 업체명 영문
	 */
	private String entrpsnmEng;
	/**
	 * 대표자 명
	 */
	@NotEmpty(message = "대표자 명은 필수값입니다.")
	private String rprsntvNm;
	/**
	 * 사업자 등록 번호
	 */
	@NotEmpty(message = "사업자 등록 번호는 필수값입니다.")
	private String bsnmRegistNo;
	/**
	 * 법인 등록 번호
	 */
	private String cprRegistNo;
	/**
	 * 기업 업태 코드
	 */
	private String entrprsBizcndCode;
	/**
	 * 기업 종목 코드
	 */
	private String entrprsItemCode;
	/**
	 * 사업자 유형 코드
	 */
	private String bsnmTyCode;
	/**
	 * 회사 전화 번호
	 */
	private String cmpnyTlphonNo;
	/**
	 * 회사 팩스 번호
	 */
	private String cmpnyFaxNo;
	/**
	 * 환불 계좌 번호
	 */
	private String refndAcnutNo;
	/**
	 * 환불 계좌명
	 */
	private String refndAcnutNm;
	/**
	 * 이월렛 계좌 번호
	 */
	private String ewalletAcnutNo;
	/**
	 * 환불 계좌 상태 코드
	 */
	private String refndAcnutSttusCode;
	/**
	 * 환불 계좌 상태 설명
	 */
	private String refndAcnutSttusDc;
	/**
	 * 환불 계좌 정합성 여부
	 */
	private String refndAcnutRgrsynthAt;
	/**
	 * 환불 계좌 정합성 일시
	 */
	private String refndAcnutRgrsynthDt;
	/**
	 * 고객 등록 주체 코드
	 */
	private String cstmrRegistMbyCode;
	/**
	 * 업체 등급 번호
	 */
	private String entrpsGradNo;
	/**
	 * 삭제 여부
	 */
	@NotEmpty(message = "삭제 여부는 필수값입니다.")
	private String deleteAt;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	/**
	 * 최초 등록자 아이디
	 */
	@NotEmpty(message = "최초 등록자 아이디는 필수값입니다.")
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	@NotEmpty(message = "최초 등록 일시는 필수값입니다.")
	private String frstRegistDt;
	/**
	 * 최종 변경자 아이디
	 */
	@NotEmpty(message = "최종 변경자 아이디는 필수값입니다.")
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	@NotEmpty(message = "최종 변경 일시는 필수값입니다.")
	private String lastChangeDt;
	/**
     * 우편 번호
     */
    private String postcode;
    /**
     * 주소
     */
    private String jibunAddress;
    /**
     * 상세 주소
     */
    private String detailAdres;
    /**
     * 도로명 주소
     */
    private String roadAddress;

    /**
     * 임시 계좌주 명
     */
    private String ipAccountHolder;

	/****** JAVA VO CREATE : MB_MBER_INFO_BAS(회원_회원 정보 기본) ******/
	/**
	 * 회원 번호
	 */
    @NotEmpty(message = "회원 번호는 필수값입니다.")
	private String mberNo;

	/**
	 * 회원 아이디
	 */
    @NotEmpty(message = "회원 아이디는 필수값입니다.")
	private String mberId;
	/**
	 * 회원 비밀 번호
	 */
    @NotEmpty(message = "회원 비밀번호는 필수값입니다.")
	private String mberSecretNo;
	/**
	 * 회원 가입 일시
	 */
    @NotEmpty(message = "회원 가입 일시는 필수값입니다.")
	private String mberEtrDt;
	/**
	 * 회원 최근 방문 일시
	 */
    @NotEmpty(message = "회원 최근 방문 일시는 필수값입니다.")
	private String mberRecentVisitDt;
	/**
	 * 회원 승인 상태 코드
	 */
	private String mberConfmSttusCode;
	/**
	 * 회원 승인 처리 일시
	 */
	@NotEmpty(message = "회원 승인 처리 일시는 필수값입니다.")
	private String mberConfmProcessDt;
	/**
	 * 승인자 명
	 */
	private String confmerNm;
	/**
	 * 요청 사유
	 */
	private String requstResn;
	/**
	 * 승인 사유
	 */
	private String confmResn;
	/**
	 * 회원 이름
	 */
	private String mberNm;
	/**
	 * 휴대전화 번호
	 */
	private String moblphonNo;
	/**
	 * 회원 이메일
	 */
	@NotEmpty(message = "회원 이메일는 필수값입니다.")
	private String mberEmail;
	/**
	 * 회원 마케팅 수신 동의 여부
	 */
	@NotEmpty(message = "회원 마케팅 동의 여부는 필수값입니다.")
	private String advrtsRecptnAgreAt;
	/**
	 * 회원 메일 수신 동의 여부
	 */
	@NotEmpty(message = "회원 메일 수신 동의 여부는 필수값입니다.")
	private String marktRecptnEmail;
	/**
	 * 회원 문자 수신 동의 여부
	 */
	@NotEmpty(message = "회원 문자 수신 동의 여부는 필수값입니다.")
	private String marktRecptnSms;
	/**
	 * 회원 push 수신 동의 여부
	 */
	@NotEmpty(message = "회원 PUSH 수신 동의 여부는 필수값입니다.")
	private String marktRecptnPush;
	/**
	 * 뉴스레터 신청 여부
	 */
	private String nsltReqstAt;
	/**
	 * 뉴스레터 신청 일시
	 */
	private String nsltReqstDt;
	/**
	 * 본인 인증 여부
	 */
	@NotEmpty(message = "본인 인증 여부는 필수값입니다.")
	private String selfCrtfcAt;
	/**
	 * 본인 인증 일시
	 */
	private String selfCrtfcDt;
	/**
	 * 로그인 실패 회수
	 */
	private int loginFailrRtrvl;
	/**
	 * 비밀 번호 오류 횟수
	 */
	private int secretNoErrorCo;
	/**
	 * 비밀 번호 수정 일시
	 */
	private String secretNoUpdtDt;
	/**
	 * 최근 접속 일시
	 */
	private String recentConectDt;
	/**
	 * 회원 상태 코드
	 */
	private String mberSttusCode;
	/**
	 * 회원 구분 코드
	 */
	private String mberSeCode;
	/**
	 * 권한 변경 동의 여부
	 */
	private String authorChangeAgreAt;
	/**
	 * ewallet 잔액
	 */
	private int ewalletBlce;
	/**
	 * 기업 신용 등급명
	 */
	private String entrprsCredtNm;
	/**
     * 계좌 미등록 메일 발송 여부
     */
    private String acnutUnregistEmailSndngAt;
    
    /**
     * 계좌 미등록 메일 발송 일시
     */
    private String acnutUnregistEmailSndngDt;
	
	////////////////////[[ 회원 기본 정보 ]]///////////////////
    /**
    * 회원 메일 수신 일시
   */
    private String mberEmailRecptnAgreDt;

    /**
    * 전화 번호
   */
    private String tlphonNo;
	/**
	 * 이용 약관 동의 여부
	*/
    @NotEmpty(message = "이용 약관 동의 여부는 필수값입니다.")
	private String useStplatAgreAt;
	/**
	 * 이용 약관 동의 일시
	*/
    @NotEmpty(message = "이용 약관 동의 일시는 필수값입니다.")
	private String useStplatAgreDt;
	/**
	 * 전자 금융 거래 약관 동의 여부
	 */
    @NotEmpty(message = "전자 금융 거래 약관 동의 여부는 필수값입니다.")
	private String elctrnFnncDelngStplatAgreAt;
	/**
	 * 전자 금융 거래 약관 동의 일시
	*/
    @NotEmpty(message = "전자 금융 거래 약관 동의 일시는 필수값입니다.")
	private String elctrnFnncDelngStplatAgreDt;
	/**
	 * 개인 정보 처리 방침 동의 여부
	*/
    @NotEmpty(message = "개인 정보 처리 방침 동의 여부는 필수값입니다.")
	private String indvdlInfoProcessPolcyAgreAt;
	/**
	 * 개인 정보 처리 방침 동의 일시
	*/
    @NotEmpty(message = "개인 정보 처리 방침 동의 일시는 필수값입니다.")
	private String indvdlInfoProcessPolcyAgreDt;
	/**
	 * 전체 동의 여부
	 */
	private String agreeAll;

	/**
	 * 서비스 약관 동의 여부
	 */
    private String agreAt;
    /**
     * 서비스 약관 동의 일시
     */
    private String agreDt;
    ///////////////////[[ 배송지 정보 ]]////////////////
    /**
     *  기본 배송지 여부
     */
    private String bassDlvrgAt;
    /**
     * 배송지 명
    */
    private String dlvrgNm ;
    /**
     * [배송지]우편 번호
     */
    private String dlvrgPostNo;
    /**
     * [배송지]주소
     */
    private String dlvrgAdres;
    /**
     * [배송지]상세 주소
     */
    private String dlvrgDetailAdres;
    /**
     * [배송지]도로명 주소
     */
    private String dlvrgRnAdres;

    /**
     * 법정동 코드
     */
    private String legaldongCode;
    /**
     * 배송지 담당자
     */
    private String dlvrgCharger;
    /**
     * 배송지 담당자 연락처
     */
    private String dlvrgChargerCttpc;
    /**
     * 배송지 담당자 이메일
     */
    private String dlvrgChargerEmail;
    /**
     * 구매 담당자 이메일
     */
    private String purchschargerEmail;
    /**
     * ERP 업체 코드
     */
    private String erpEntrpsCode;
    /**
     * 배송지 번호
     */
    private String dlvrgNo;
    /**
     * 배송지 순번
     */
    private String dlvrgSeDetailSn;
    /**
     * 참고 항목
     */
    private String extraAddress;
    /**
     * 법정동 코드
     */
    private String bcode;
    /**
     * 배송지 참고항목 (컬럼 없는데 js 필수코드)
     */
    private String dlvrgExtraAddress;
    /////////////////////////////[[ 이용 약관 관련 vo ]] ////////////////////////////
    /**
     * 이용 약관 구분 코드
     */
    private String stplatSeCode;
    /**
     * 이용 약관 구분 코드 명
     */
    private String stplatSeCodeNm;
   /**
    * 이용 약관 번호
    */
    private String stplatNo;
    /**
     * 이용 약관1
     */
    private String stplatCnOne;
    /**
     * 이용 약관2
     */
    private String stplatCnTwo;
    /**
     * 약관개정 시작 일자
    */
    private String stplatreformBeginDe;
    /**
     * tcode
     */
    private String tcode;
    /**
     * 추천인 아이디
     */
    private String recomendrId;
    


    ///////////////////// [[ 파일첨부 ]] ////////////////////////////

    /**
     * 첨부파일
     */
    private List<DocInfoVO> DocInfo;



}
