package com.sorincorp.mfo.mb.model;

import java.io.Serializable;

import lombok.Data;

/**
 * MbEntrpsGradVO.java
 *
 * @version
 * @since 2022. 8. 12.
 * @author srec0030
 */
@Data
public class MbEntrpsGradVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 4250300603336387158L;

	/**
	 *
	 */
	private String entrpsNo;
	/**
	 *
	 */
	private String entrpsGrad;
	private int entrpsGradSn;
	/**
	 *
	 */
	private String entrpsGradNm;

	/**
	 *
	 */
	private int gradCalcSn;
	/**
	 *
	 */
	private String gradEvlDt;
	/**
	 *
	 */
	private String gradEvlQu;
	/**
	 *
	 */
	private String gradEvlMthcode;
	/**
	 *
	 */
	private int tonCoBeforeQuAcmtl;
	/**
	 *
	 */
	private int tonCoPrtintAccmlt;
	/**
	 *
	 */
	private int orderTonCoScore;
	/**
	 *
	 */
	private int fqBeforeQuAcmtl;
	/**
	 *
	 */
	private int fqPrtintAccmlt;
	/**
	 *
	 */
	private int orderFqScore;
	/**
	 *
	 */
	private int evlStdrSmScore;

	/**
	 *
	 */
	private int gradIemSn;
	/**
	 *
	 */
	private int beginOrderTonCo;
	/**
	 *
	 */
	private int endOrderTonCo;
	/**
	 *
	 */
	private int orderTonCoStdrScore;
	/**
	 *
	 */
	private int beginFqCo;
	/**
	 *
	 */
	private int endFqCo;
	/**
	 *
	 */
	private int orderFqStdrScore;
	/**
	 *
	 */
	private int beginSmScore;
	/**
	 *
	 */
	private int endSmScore;

	/**
	 *
	 */
	private String opertnDe;
	/**
	 *
	 */
	private String invntryIndictAt;
	/**
	 *
	 */
	private String spcltyusefulEmailringSvcAt;
	/**
	 *
	 */
	private int totOnedePurchsWtLmt;
	/**
	 *
	 */
	private int totOncePurchsWtLmt;
	/**
	 *
	 */
	private int totAccmlMlg;

	/**
	 *
	 */
	private String metalCode;
	/**
	 *
	 */
	private String metalCodeNm;
	/**
	 *
	 */
	private int onedePurchsWtLmt;
	/**
	 *
	 */
	private int oncePurchsWtLmt;
	/**
	 *
	 */
	private int accmlMlg;

	/**
	 * 할인 금액
	 */
	private String dscntAmount;
	
	/* 페이백,상시 할인 관련 */
	private int firstGradPurchsQy;
	private int scndGradPurchsQy;
	private int thirdGradPurchsQy;
	private int fourthGradPurchsQy;
	/**
     * 전월까지 최대 구매 수량
     */
    private int toLsmthMxmmPurchsMt;
    
    /**
     * 전월까지 최저 구매 수량
     */
    private int toLsmthMinPurchsMt;
    
    /**
     * 구매 시작일부터 전월까지 합산 구매 수량
     */
    private int toLsmthAdupPurchsMt;

    /**
     * 전월까지 평균 구매 수량
     */
    private int toLsmthAvrgPurchsMt;
    
    /**
     * 당월 합산 구매 수량
     */
    private int thsmonAdupPurchsMt;
  
    /**
     * 올림(전체 기간에 대한 평균 중량 / 25) * 25 
     */
    private int ceilAvgTotRealOrderWt;
    
    /**
     * 버림(전체 기간에 대한 평균 중량 / 25) * 25 
     */
    private int floorAvgTotRealOrderWt;
    /**
     * 최대 구매 수량 달성 여부
     */
    private String mxmmPurchsMtAchivAt;
    /**
     * 평균 수량 상승 여부
     */
    private String avrgPurchsMtRisingAt;
    /**
     * 평균 구매 수량 유지 여부
     */
    private String avrgPurchsMtMntmcAt;
    /**
     * 상시할인 - 단가 할인 금액
     */
    private String untpcDscntAmount;
   
}
