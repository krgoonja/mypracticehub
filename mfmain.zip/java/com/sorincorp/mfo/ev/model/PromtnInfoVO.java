package com.sorincorp.mfo.ev.model;

import javax.validation.constraints.NotBlank;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class PromtnInfoVO extends CommonVO {

	private static final long serialVersionUID = 8844595686043453196L;
    
    /** 상시 노출 여부 */
    @NotBlank( message = "이름은 필수입니다.")
    private String entrpsNm;
    
    /** 상시 노출 여부 */
    @NotBlank( message = "이름은 필수입니다.")
    private String nm;

    /** 상시 노출 여부 */
    @NotBlank( message = "휴대폰 번호는 필수입니다.")
    private String mbtlNum;
    
}
