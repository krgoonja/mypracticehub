
package com.sorincorp.mfo.ev.controller;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.mfo.config.UserInfoUtil;
import com.sorincorp.mfo.ev.model.PromtnInfoVO;
import com.sorincorp.mfo.ev.service.PromtnEventService;
import com.sorincorp.mfo.login.model.Account;

import lombok.extern.slf4j.Slf4j;

/**
 * promtnEventController.java
 * @version
 * @since 2024. 9. 4.
 * @author hanjook
 */
@Slf4j
@Controller
@RequestMapping("/mfo/promtnEvent")
public class PromtnEventController {

	@Autowired
	private PromtnEventService promtnEventService;

    @Autowired
    private UserInfoUtil userInfoUtil;
    
    private Account getAccountInfo() throws Exception {
		Account account = userInfoUtil.getAccountInfo();
		if (null == account || StringUtil.isBlank(account.getMberNo())) {
			throw new Exception("로그인 정보를 확인해주세요.");
		}
		return account;
	}

	/**
	 * <pre>
	 * 처리내용: 모바일 프로모션 이벤트 View
	 * </pre>
	 * @date 2024. 9. 4.
	 * @author hanjook
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 9. 4.		hanjook		최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/moPromtnEvent")
	public String promtnEventList(@RequestBody(required = false) PromtnInfoVO vo, ModelMap model) {
		try {
			return "ev/moPromtn";
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
			return "error/503";
		}
	}	
	
   @ResponseBody
   @PostMapping("/insertPromtnDtl")
    public String insertPromtnDtl(@RequestBody PromtnInfoVO vo) throws Exception {
        String result = "";
        result = promtnEventService.insertPromtnDtl(vo);

        return result;
    }

}
