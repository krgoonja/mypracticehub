package com.sorincorp.mfo.ev.service;

import com.sorincorp.mfo.ev.model.PromtnInfoVO;

/**
 * promtnEventService.java
 * @version
 * @since 2024. 9. 4.
 * @author hanjook
 */
public interface PromtnEventService {

	String insertPromtnDtl(PromtnInfoVO vo);

}
