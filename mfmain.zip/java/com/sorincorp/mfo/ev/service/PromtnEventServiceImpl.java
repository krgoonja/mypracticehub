package com.sorincorp.mfo.ev.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.mfo.ev.mapper.PromtnEventMapper;
import com.sorincorp.mfo.ev.model.PromtnInfoVO;

import lombok.extern.slf4j.Slf4j;

/**
 * PromtnEventServiceImpl.java
 * @version
 * @since 2024. 9. 4.
 * @author hanjook
 */
@Slf4j
@Service
public class PromtnEventServiceImpl implements PromtnEventService {

	@Autowired
	private PromtnEventMapper promtnEventMapper;    
   
   @Override
   public String insertPromtnDtl(PromtnInfoVO promtnInfoVO) {

       String data = "F";
       int result = 0;
       String mbtlNum = promtnInfoVO.getMbtlNum();
       String encryptMbtlNum = "";
       try {
	   		if(mbtlNum != null && !"".equals(mbtlNum)) {
	   			mbtlNum = mbtlNum.replaceAll("[^0-9]", "");
				try {
					log.debug("암호화 전 ===============>" + mbtlNum);
					encryptMbtlNum = CryptoUtil.encryptAES256(mbtlNum);
					log.debug("암호화 후 ===============>" + mbtlNum);
					promtnInfoVO.setMbtlNum(encryptMbtlNum);
				} catch (Exception e) {
					log.error("insertMberInfo MOBLPHON_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
				}
			}
           result = promtnEventMapper.insertPromtnDtl(promtnInfoVO);
           if (result > 0) {
               data = "S";                            
           }          
       } catch (Exception e) {
           data = "F";
       }
       return data;
   }	
	
}
