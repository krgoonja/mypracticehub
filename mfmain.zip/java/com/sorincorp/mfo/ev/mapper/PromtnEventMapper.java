package com.sorincorp.mfo.ev.mapper;

import com.sorincorp.mfo.ev.model.PromtnInfoVO;

/**
 * PromtnEventMapper.java
 * @version
 * @since 2024. 9. 4.
 * @author hanjook
 */
public interface PromtnEventMapper {

	int insertPromtnDtl(PromtnInfoVO promtnInfoVO);
	
}
