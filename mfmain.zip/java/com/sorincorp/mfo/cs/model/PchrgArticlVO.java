package com.sorincorp.mfo.cs.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

/**
 * NsltVO.java
 * @version
 * @since 2021. 8. 30.
 * @author srec0033
 */
@Data
public class PchrgArticlVO extends CommonVO {
	
	private static final long serialVersionUID = 6882956165304862133L;

	/**
     * 기사 순번
    */
    private long articlSn;
   /**
     * 채널 구분 코드
    */
    private String chnnlSeCode;
   /**
     * 기사 번호
    */
    private long articlNo;
   /**
     * 기사 제목
    */
    private String articlSj;
   /**
     * 기사 링크
    */
    private String articlLink;
   /**
     * 기사 원문
    */
    private String articlOrginl;
   /**
     * 기사 내용
    */
    private String articlCn;
   /**
     * 이미지 URL
    */
    private String imageUrl;
   /**
     * 기사 구분 코드
    */
    private String articlSeCode;
   /**
     * 기사 분류 명
    */
    private String articlClNm;
   /**
     * 기사 분류 코드
    */
    private String articlClCode;
   /**
     * 작성 기자 명
    */
    private String writngJrnlstNm;
   /**
     * 발행 일시
    */
    private String isuDt;
   /**
     * 게시 여부
    */
    private String ntceAt;
   /**
     * 삭제 여부
    */
    private String deleteAt;
   /**
     * 삭제 일시
    */
    private String deleteDt;
   /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
   /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
   /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
   /**
     * 최종 변경 일시
    */
    private String lastChangeDt;

    /**
     *	순번 
     */
    private int rownum;
    /**
     *	이전 뉴스 번호 
     */
    private long preArticlSn;
    /**
     *	다음 뉴스 번호
     */
    private long nextArticlSn;
    /**
     *	카테고리 선택 여부(화면) 
     */
    private String catecoryCheckAt;
    /**
     * 코드명
     */
    private String codeNm;
    /**
     * 	서브코드
     */
    private String subCode;
   /**
     * 발행 호
    */
    private long isuHo;
   /**
     * 발행 월
    */
    private String isuMt;
 
   /**
     * 게시 일자
    */
    private String ntceDe;
    
    /**
     * 화면 접근 후 이동
    */
    private String option;
}
