package com.sorincorp.mfo.cs.service;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.filedoc.service.FileDocService;
import com.sorincorp.mfo.cs.mapper.NoticeMapper;
import com.sorincorp.mfo.cs.model.NoticeVO;

import lombok.extern.slf4j.Slf4j;

/**
 * NoticeServiceImpl.java
 * @version
 * @since 2021. 8. 25.
 * @author srec0033
 */
@Slf4j
@Service
public class NoticeServiceImpl implements NoticeService {

	@Autowired
	private NoticeMapper noticeMapper;

	@Autowired
	public FileDocService fileDocService;

	/**
	 *	공지사항 목록을 조회한다.
	 */
	@Override
	public List<NoticeVO> searchListNotice(NoticeVO vo) throws Exception {
		List<NoticeVO> list = noticeMapper.searchListNotice(vo);
		for (int i = 0; i < list.size(); i++) {
			List<FileDocVO> fileList = selectListNoticeAtchmnfl(list.get(i));
			list.get(i).setDocNo(fileList.size());
		}
		return list;
	}

	/**
	 *	공지사항 목록 총개수를 조회한다.
	 */
	@Override
	public int selectNoticeListTotcnt(NoticeVO vo) throws Exception {
		return noticeMapper.selectNoticeListTotcnt(vo);
	}

	/**
	 *	필독으로 설정된 공지사항 목록을 조회한다.
	 */
	@Override
	public List<NoticeVO> selectListNoticeUpendexpsr() throws Exception {
		List<NoticeVO> list = noticeMapper.selectListNoticeUpendexpsr();
		for (int i = 0; i < list.size(); i++) {
			List<FileDocVO> fileList = selectListNoticeAtchmnfl(list.get(i));
			list.get(i).setDocNo(fileList.size());
		}
		return list;
	}

	/**
	 *	공지사항 첨부파일 목록을 조회한다.
	 */
	@Override
	public List<FileDocVO> selectListNoticeAtchmnfl(NoticeVO vo) throws Exception {
		List<FileDocVO> fileList = new ArrayList<>();
		List<NoticeVO> atchList = noticeMapper.selectListNoticeAtchmnfl(vo);

		for (int i = 0; i < atchList.size(); i++) {
			FileDocVO file = fileDocService.selectDocInfo(atchList.get(i).getDocNo());
			System.out.println("file ===> " + file);

			fileList.add(file);
		}

		return fileList;
	}

	/**
	 *	공지사항을 상세조회한다.
	 */
	@Override
	public NoticeVO selectNotice(NoticeVO vo) throws Exception {
		log.debug("selectNotice vo >>> " + vo);
		String searchKeyword = URLDecoder.decode(vo.getSearchKeyword(), "UTF-8");
		vo.setSearchKeyword(searchKeyword);

		NoticeVO notice = noticeMapper.selectNotice(vo);
		notice.setNoticeAt(vo.getNoticeAt());
		notice.setSearchKeyword(vo.getSearchKeyword());
		log.debug("selectNotice 검색어 ===> " + vo.getSearchKeyword());
		if(vo.getNoticeAt() == 1) {
			notice.setPreNoticeNo(0);
			notice.setNextNoticeNo(0);
		}

		//2022-01-07 공지사항 관련 개선사항 추가 반영 - 조회 수 기능 추가
		noticeMapper.updateNoticeViewCount(vo);

		return notice;
	}

}
