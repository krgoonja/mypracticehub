package com.sorincorp.mfo.cs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.mfo.cs.mapper.SvcStplatMapper;
import com.sorincorp.mfo.cs.model.SvcStplatVO;

import lombok.extern.slf4j.Slf4j;

/**
 * SvcStplatServiceImpl.java
 * @version
 * @since 2021. 8. 27.
 * @author srec0033
 */
@Slf4j
@Service
public class SvcStplatServiceImpl implements SvcStplatService {
	
	@Autowired
	private SvcStplatMapper stplatMapper;

	/**
	 *	서비스약관 목록을 조회할 수 있다.(게시중, 만료) 
	 */
	@Override
	public List<SvcStplatVO> selectSvcStplatList(SvcStplatVO vo) throws Exception {
		return stplatMapper.selectSvcStplatList(vo);
	}

	/**
	 * 서비스약관을 상세조회한다.
	 */
	@Override
	public SvcStplatVO selectSvcStplat(SvcStplatVO vo) throws Exception {
		return stplatMapper.selectSvcStplat(vo);
	}
	
}
