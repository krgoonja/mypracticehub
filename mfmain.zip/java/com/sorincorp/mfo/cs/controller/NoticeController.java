package com.sorincorp.mfo.cs.controller;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.mfo.cs.model.NoticeVO;
import com.sorincorp.mfo.cs.service.NoticeService;

import lombok.extern.slf4j.Slf4j;

/**
 * NoticeController.java
 * @version
 * @since 2021. 8. 25.
 * @author srec0033
 */

@Slf4j
@Controller
@RequestMapping("/mfo/notice")
public class NoticeController {

	@Autowired
	private NoticeService noticeService;

	/**
	 * <pre>
	 * 처리내용: 공지사항 목록 화면을 조회한다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0033			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/showNoticeList")
	public String showNoticeList(@RequestBody(required = false) NoticeVO vo, ModelMap model) {
		try {
			model.addAttribute("notice", vo);
			model.addAttribute("totalRowCount", noticeService.selectNoticeListTotcnt(vo));
			model.addAttribute("pageIndex", 1);
			model.addAttribute("pageSize", 10);
			model.addAttribute("rowCountPerPage", 10);

			return "cs/noticeList";
		} catch (Exception e) {

			log.error(e.getMessage());
			return "error/503";
		}
	}

	/**
	 * <pre>
	 * 처리내용: 공지사항 목록을 조회한다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0033			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/searchListNotice")
	@ResponseBody
	public Map<String, Object> searchListNotice(@RequestBody NoticeVO vo) throws Exception {
		Map<String, Object> map = new HashedMap<>();
		List<NoticeVO> expsrList = noticeService.selectListNoticeUpendexpsr();
		List<NoticeVO> noticeList = noticeService.searchListNotice(vo);
		int noticeTotCnt = noticeService.selectNoticeListTotcnt(vo);

		map.put("expsrList", expsrList);
		map.put("dataList", noticeList);
		map.put("totalRowCount", noticeTotCnt);
		return map;
	}

	/**
	 * <pre>
	 * 처리내용: 공지사항을 상세조회한다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0033
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 25.			srec0033			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/noticeDtls")
	public String noticeDtls(@RequestBody NoticeVO vo, ModelMap model) {
		try {
			NoticeVO notice = noticeService.selectNotice(vo);
			//List<FileDocVO> fileList = noticeService.selectListNoticeAtchmnfl(notice);
			log.debug("noticeDtls notice ===> " + notice);
			//log.debug("noticeDtls fileList ===> " + fileList);

			model.put("notice", notice);
			//model.put("fileList", fileList);

			return "cs/noticeDtls";
		}catch(Exception e){
			log.error(e.getMessage());
			return "error/503";
		}
	}

}
