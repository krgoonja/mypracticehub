package com.sorincorp.mfo.pd.comm.exception;

@SuppressWarnings("serial")
public class CustomEmptyLoginUserException extends Exception {
	
	public CustomEmptyLoginUserException() {}
	
	public CustomEmptyLoginUserException(String message) {
		super(message);
	}
	
	public CustomEmptyLoginUserException(Exception e) {
		super(e);
	}
}

