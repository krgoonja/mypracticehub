package com.sorincorp.mfo.pd.comm.constant;

public class PdCommConstant {

	public static final int SUCCESS_RESULT_CODE = 200;

	public static final String SUCCESS_RESULT_MSG = "Success";

	public static final int FAIL_RESULT_CODE = 400;

	public static final int ERROR_RESULT_CODE = 500;

	public static final String ERROR_RESULT_MSG = "Error";

	public static final String SAMSUNG_SUCCESS_CODE = "200";

	/** web socket **/
	public static final String WEBSOCKET_SUBSCRIBER= "/subscriber/live";
	public static final String WEBSOCKET_RECIEVE_URL= "/live";

	/** order constants **/
	public static final String EWALLET_DATA_KEY = "data";

	public static final String EWALLET_MONNY_KEY = "delngAmount";

	public static final String EWALLET_RESULT_KEY = "resultCode";

	public static final String EWALLET_SUCCESS_CODE = "200";

	public static final String SAMSUNG_RESULT_KEY = "code";

	public static final String ORDER_EMPTY_MAP_STRING = "{}";

	/** 단가 구분 코드 */
	public static final String AVRG_PC = "10"; // 가단가
	public static final String DCSN_PC = "20"; // 확정단가
}
