package com.sorincorp.mfo.pd.comm.constant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Getter;

@Getter
@Component
public class PdPropertyConstant {

	/** 주문 홀딩 사용 여부 **/
	@Value("${order.holding.use}")
	private String orderHoldingUseAt;

	/** 주문 CAPA 관리 여부 **/
	@Value("${order.capa.manage}")
	private String orderCapaManageAt;

	/** 삼성선물 계좌번호 **/
	@Value("${order.samsung.acnut}")
	private String samsungAcnutNo;

	/** 이베스트증권 계좌번호 **/
	@Value("${order.ebest.acnut}")
	private String ebestAcnutNo;

	/** 삼성선물 타임아웃 **/
	@Value("${order.samsung.timeoutsec}")
	private int samsungTimeoutsec;

	/** 삼성선물 주문 타입 **/
	@Value("${order.samsung.ordertype}")
	private String samsungOrdertype;

	/** 이월렛 타임아웃 **/
	@Value("${order.ewallet.timeoutsec}")
	private int ewalletTimeoutsec;

	/** 삼성선물 주문 url **/
	@Value("${order.api.samsung.order.url}")
	private String samsungOrderUrl;

	/** 삼성선물 취소 url **/
	@Value("${order.api.samsung.cancel.url}")
	private String samsungCancelUrl;

	/** 삼성선물 클레임 url **/
	@Value("${order.api.samsung.claim.url}")
	private String samsungClaimUrl;

	/** 선물환 주문 url **/
	@Value("${order.api.fx.order.url}")
	private String fxOrderUrl;

//	/** 선물환 클레임 url **/
//	@Value("${order.api.fx.claim.url}")
//	private String fxClaimUrl;

	/** 이월렛 잔고 확인 url **/
	@Value("${order.api.ewallet.money.url}")
	private String ewalletMoneyUrl;

	/** 이월렛 주문 url **/
	@Value("${order.api.ewallet.order.url}")
	private String ewalletOrderUrl;

	/** 이월렛 환불 url **/
	@Value("${order.api.ewallet.refund.url}")
	private String ewalletRefundUrl;

	/** 물류 재고 파악 url **/
	@Value("${order.api.lo.invntry.url}")
	private String loInvntryUrl;

	/** 실시간 물류 CAPA 확인 url **/
	@Value("${order.api.lo.lgistCnfirm.url}")
	private String lgistCnfirm;

	/** oms 송신 url **/
	@Value("${order.api.lo.oms.url}")
	private String loOmsUrl;

	/** 대쉬보드 호출 url **/
	@Value("${order.api.dashboard.url}")
	private String dashboardUrl;

	/** 세금계산서 호출 **/
	@Value("${order.api.taxbill.url}")
	private String taxbillUrl;

	/** 대출보증 상환 url */
	@Value("${credit.loan.repy.url}")
	private String repyLonUrl;

	/** 대출보증 상환 취소 url */
	@Value("${credit.loan.cancel.url}")
	private String repyLonCancelUrl;

	/** 대출보증 한도 조회 url */
	@Value("${credit.loan.limit.url}")
	private String lonLmtUrl;

	/** 이월렛 상환 url */
	@Value("${credit.ewallet.repy.url}")
	private String repyEwalletUrl;

	/** 전자상거래보증 상환 url */
	@Value("${credit.mrtgg.repy.url}")
	private String repyMrtggUrl;

	/**
	 * lme 수집 시간 간격 값
	 */
	@Value("${order.intrvl.colctTime.lme}")
	private int lmeColctTimeIntrvlVal;

	/**
	 * 환율 수집 시간 간격 값
	 */
	@Value("${order.intrvl.colctTime.ehg}")
	private int ehgColctTimeIntrvlVal;


}
