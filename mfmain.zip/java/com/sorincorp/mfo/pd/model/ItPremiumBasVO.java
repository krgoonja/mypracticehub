package com.sorincorp.mfo.pd.model;

import lombok.Data;

@Data
public class ItPremiumBasVO {
	
	/**
     * 프리미엄 기준 금액
    */
    private long premiumStdrAmount;
    /**
     * 권역 변동 금액
    */
    private long dstrctChangeAmount;
    /**
     * 고정가 권역 변동 금액
    */
    private long hghnetprcDstrctChangeAmount;
    /**
     * 브랜드 그룹 변동 금액
    */
    private long brandGroupChangeAmount;
    /**
     * 고정가 브랜드 그룹 변동 금액
    */
    private long hghnetprcBrandGroupChangeAmount;
    /**
     * 브랜드 변동 금액
    */
    private long brandChangeAmount;
    /**
     * 고정가 브랜드 변동 금액
    */
    private long hghnetprcBrandChangeAmount;
    /**
     * 등급 변동 금액
    */
    private long gradChangeAmount;
    /**
     * 프리미엄 번호
    */
    private String premiumNo;
    /**
     * 프리미엄 가격
    */
    private long premiumPc;
	
}
