package com.sorincorp.mfo.pd.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class BsnManageLgistDateVO extends CommonVO {

	private static final long serialVersionUID = 2824211391905317808L;

	private String applcDe;
	
	private String dayYn;
	
	private int dayInt;
	
}