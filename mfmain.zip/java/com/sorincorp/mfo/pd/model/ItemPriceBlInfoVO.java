package com.sorincorp.mfo.pd.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ItemPriceBlInfoVO extends CommonVO {

	private static final long serialVersionUID = 6882956165304862133L;

	/******  JAVA VO CREATE : IT_BL_INFO_BAS(상품_BL 정보 기본)                                                                              ******/
    /**       * BL 번호      */      private String blNo;
    /**       * 창고 코드      */      private String wrhousCode;
    /**       * 권역 대분류 코드      */      private String dstrctLclsfCode;
    /**       * 권역 중분류 코드      */      private String dstrctMlsfcCode;
    /**       * 창고 CELL 위치      */      private String wrhousCellLc;
    /**       * 금속 코드      */      private String metalCode;
    /**       * 아이템 코드      */      private String itmCode;
    /**       * 브랜드 코드      */      private String brandCode;
    /**       * 제품 명      */      private String prductNm;
    /**       * 보관료      */      private java.math.BigDecimal chcy;
    /**       * 보관 일 수      */      private int cstdyDeCo;
    /**       * 기초 입고 재고      */      private java.math.BigDecimal bsisWrhousngInvntry;
    /**       * 기초 입고 번들 재고      */      private int bsisWrhousngBundleInvntry;
    /**       * 기초 악성 불량 재고      */      private java.math.BigDecimal bsisMaliciousBadnInvntry;
    /**       * 기초 악성 불량 번들 재고      */      private int bsisMaliciousBadnBundleInvntry;
    /**       * 기초 악성 반출 재고            private java.math.BigDecimal bsisMaliciousTkoutInvntry;*/
    /**       * 기초 악성 반출 번들 재고            private int bsisMaliciousTkoutBundleInvntry;*/
    /**       * 기초 재고      */      private java.math.BigDecimal bsisInvntry;
    /**       * 기초 번들 재고      */      private int bsisBundleInvntry;
    /**       * 판매 설정 번들 수      */      private int sleSetupBundleCo;
    /**       * 판매 설정 중량      */      private java.math.BigDecimal sleSetupWt;
    /**       * 판매 재고 미판매 잔량      */      private java.math.BigDecimal sleInvntryUnsleBnt;
    /**       * 판매 재고 미판매 번들 잔량      */      private int sleInvntryUnsleBundleBnt;
    /**       * EC 판매 완료 재고      */      private java.math.BigDecimal ecSleComptInvntry;
    /**       * EC 판매 완료 번들 재고      */      private int ecSleComptBundleInvntry;
    /**       * EC 교환 주문 재고      */      private java.math.BigDecimal ecExchngOrderInvntry;
    /**       * EC 교환 주문 번들 재고      */      private int ecExchngOrderBundleInvntry;
    /**       * EC 출고 재고      */      private java.math.BigDecimal ecDlivyInvntry;
    /**       * EC 출고 번들 재고      */      private int ecDlivyBundleInvntry;
    /**       * EC 미출고 재고      */      private java.math.BigDecimal ecNootgInvntry;
    /**       * EC 미출고 번들 재고      */      private int ecNootgBundleInvntry;
    /**       * 창고 미출고 재고      */      private java.math.BigDecimal wrhousNootgInvntry;
    /**       * 창고 미출고 번들 재고      */      private int wrhousNootgBundleInvntry;
    /**       * 창고 판매 미설정 재고      */      private java.math.BigDecimal wrhousSleUnsetupInvntry;
    /**       * 창고 판매 미설정 번들 재고      */      private int wrhousSleUnsetupBundleInvntry;
    /**       * 기말 재고      */      private java.math.BigDecimal trmendInvntry;
    /**       * 기말 번들 재고      */      private int trmendBundleInvntry;
    /**       * 입고 일자      */      private java.sql.Date wrhousngDe;
    /**       * 통관 일자      */      private java.sql.Date entrDe;
    /**       * 도착 예정 일시      */      private java.sql.Timestamp arvlPrearngeDt;
    /**       * NET 중량      */      private java.math.BigDecimal netWt;
    /**       * GROSS 중량      */      private java.math.BigDecimal grossWt;
    /**       * 평균 중량            private java.math.BigDecimal avrgWt;*/
    /**       * LOT 수량      */      private int lotQy;
    /**       * 판매 상태 코드      */      private String sleSttusCode;
    /**       * 구매 주문 번호      */      private String purchsOrderNo;
    /**       * 구매 라인 번호      */      private String purchsLineNo;
    /**       * 화물 관리 번호      */      private String frghtManageNo;
    /**       * 삭제 여부      */      private String deleteAt;
    /**       * 삭제 일시      */      private java.sql.Timestamp deleteDt;
    /**       * 최초 등록자 아이디      */      private String frstRegisterId;
    /**       * 최초 등록 일시      */      private java.sql.Timestamp frstRegistDt;
    /**       * 최종 변경자 아이디      */      private String lastChangerId;
    /**       * 최종 변경 일시      */      private java.sql.Timestamp lastChangeDt;
 
    /** 우선순위 IT_BRAND_INFO_BAS */ private int itmSn;
    /** 우선순위 IT_BRAND_INFO_BAS */ private int priorRank;

}