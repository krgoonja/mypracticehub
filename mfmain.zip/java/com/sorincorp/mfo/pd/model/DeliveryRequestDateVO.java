package com.sorincorp.mfo.pd.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class DeliveryRequestDateVO extends CommonVO {

	private static final long serialVersionUID = 2824211391905317808L;

	/**
	 * 자차 출고 요청 시작 일
	 */
	private int manatmbDlivyRequstBeginDe;
	
	/**
	 * 자차 출고 요청 종료 일
	 */
	private int manatmbDlivyRequstEndDe;
	
	/**
	 * 자차 당일 출고 마감 시간
	 */
	private String manatmbTodayDlivyClosTime;
	
	/**
	 * 케이지트레이딩 출고 요청 시작 일
	 */
	private int sorinDlivyRequstBeginDe;
	
	/**
	 * 케이지트레이딩 출고 요청 종료 일
	 */
	private int sorinDlivyRequstEndDe;
	
	/**
	 * 케이지트레이딩 당일 출고 마감 시간
	 */
	private String sorinTodayDlivyClosTime;
	
}