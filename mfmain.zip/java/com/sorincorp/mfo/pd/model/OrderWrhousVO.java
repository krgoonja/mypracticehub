package com.sorincorp.mfo.pd.model;

import lombok.Data;

@Data
public class OrderWrhousVO {

	private String wrhousNm;
	
	private String wrhousAdres;
	
	private String wrhousCharger;
	
	private String wrhousChargerTlphonNo;
}
