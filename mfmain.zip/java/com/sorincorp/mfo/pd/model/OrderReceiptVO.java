package com.sorincorp.mfo.pd.model;

import java.util.List;

import lombok.Data;

@Data
public class OrderReceiptVO {
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 주문 일자
    */
    private String orderDe;
    /**
     * 주문 시각
    */
    private String orderTm;
    /**
     * 장바구니 번호
    */
    private String bsktNo;
    /**
     * 회원 번호
    */
    private String mberNo;
    /**
     * 업체 번호
    */
    private String entrpsNo;
    /**
     * 업체 대표자명
    */
    private String rprsntvNm;
    /**
     * 업체 사업자번호
    */
    private String bsnmRegistNo;
    /**
     * 업체 등급 번호
    */
    private String entrpsGradNo;
    /**
     * 접수 매체 구분 코드
    */
    private String rceptMediaSeCode;
    /**
     * 판매 방식 코드
    */
    private String sleMthdCode;
    /**
     * 주문자 명
    */
    private String ordrrNm;
    /**
     * 주문자 휴대폰 번호
    */
    private String ordrrMoblphonNo;
    /**
     * 주문자 이메일
    */
    private String ordrrEmail;
    /**
     * 주문 업체 명
    */
    private String orderEntrpsNm;
    /**
     * 주문 업체 전화번호
    */
    private String orderEntrpsTelno;
    /**
     * 주문 업체 우편번호
    */
    private String orderEntrpsZip;
    /**
     * 주문 업체 주소
    */
    private String orderEntrpsAdres;
    /**
     * 주문 업체 상세 주소
    */
    private String orderEntrpsDetailAdres;
    /**
     * 주문 업체 도로명 주소
    */
    private String orderEntrpsRnAdres;
    /**
     * 주문 업체 도로명 상세 주소
    */
    private String orderEntrpsRnDetailAdres;
    /**
     * 수취 업체 휴대폰 번호
    */
    private String receptEntrpsMoblphonNo;
    /**
     * 수취 업체 담당자 명
    */
    private String receptEntrpsChargerNm;
    /**
     * 주문 상태 코드
    */
    private String orderSttusCode;
    /**
     * 배송 수단 코드
    */
    private String dlvyMnCode;

    /**
     * 배송지 전체 주소
    */
    private String receptAdres;

    /**
     * 차량 그룹 코드
    */
    private String vhcleGroupCode;
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    /**
     * 권역 대분류 명
    */
    private String dstrctLclsfNm;
    /**
     * 출고 요청 일자
    */
    private String dlivyRequstDe;
    /**
     * 주문 배송지 번호
    */
    private String orderDlvrgNo;
    /**
     * 주문 배송비 번호
    */
    private String orderDlvrfNo;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 아이템 명
    */
    private String itmNm;
    /**
     * 상품 명
    */
    private String goodsNm;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 그룹 명
    */
    private String brandGroupNm;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 브랜드 코드 명
    */
    private String brandNm;
    /**
     * 판매 단위 코드
    */
    private String sleUnitCode;
    /**
     * 총 고객 주문 중량
    */
    private int totCstmrOrderWt;
    /**
     * 총 실제 주문 중량
    */
    private int totRealOrderWt;
    /**
     * 총 번들 수량
    */
    private int totBundleQy;
    /**
     * 판매 가격 실시간 순번
    */
    private String slePcRltmSn;
    /**
     * LME 가격 실시간 순번
    */
    private String lmePcRltmSn;
    /**
     * 프리미엄 번호
    */
    private String premiumNo;
    /**
     * 환율 가격 실시간 순번
    */
    private String ehgtPcRltmSn;
    /**
     * 프리미엄 기준 금액
    */
    private long premiumStdrAmount;
    /**
     * 권역 변동 금액
    */
    private long dstrctChangeAmount;
    /**
     * 고정가 권역 변동 금액
    */
    private long hghnetprcDstrctChangeAmount;
    /**
     * 브랜드 그룹 변동 금액
    */
    private long brandGroupChangeAmount;
    /**
     * 고정가 브랜드 그룹 변동 금액
    */
    private long hghnetprcBrandGroupChangeAmount;
    /**
     * 브랜드 변동 금액
    */
    private long brandChangeAmount;
    /**
     * 고정가 브랜드 변동 금액
    */
    private long hghnetprcBrandChangeAmount;
    /**
     * 등급 변동 금액
    */
    private long gradChangeAmount;
    /**
     * 프리미엄 가격
    */
    private java.math.BigDecimal premiumPc;
    /**
     * LME 3M
    */
    private java.math.BigDecimal lme3m;
    /**
     * LME 현금
    */
    private java.math.BigDecimal lmeCash;
    /**
     * LME 조정 계수
    */
    private java.math.BigDecimal lmeMdatCffcnt;
    /**
     * 현물환
    */
    private java.math.BigDecimal spex;
    /**
     * 현물환 조정 계수
    */
    private java.math.BigDecimal spexMdatCffcnt;
    /**
     * 결제 방식 코드
    */
    private String setleMthdCode;

    /**
     * 결제 방식(상세) 코드 명
     */
    private String setleMthdNm;
    /**
     * 단가 인상 금액
    */
    private long untpcIncrseAmount;
    /**
     * 상품 단가
    */
    private long goodsUntpc;
    /**
     * 주문 가격
    */
    private long orderPc;
    /**
     * 중량 변동금
    */
    private long wtChangegld;
    /**
     * 중량 변동
     */
    private java.math.BigDecimal wtChange;
    /**
     * 배송비
    */
    private long expectDlvrf;
    /**
     * 공급가
    */
    private long splpc;
    /**
     * 부가세
    */
    private long vat;
    /**
     * 판매가
    */
    private long slepc;
    /**
     * 주문 완료 일시
    */
    private String orderComptDt;
    /**
     * 정산 처리 여부
    */
    private String excclcProcessAt;
    /**
     * 정산 처리 일시
    */
    private java.sql.Timestamp excclcProcessDt;
    /**
     * OMS 접수 번호
    */
    private String omsRceptNo;
    /**
     * 주문 실패 사유
    */
    private String orderFailrResn;
    /**
     * 총 확정 중량
    */
    private java.math.BigDecimal totDcsnWt;
    /**
     * 총 확정 주문 가격
    */
    private long totDcsnOrderPc;
    /**
     * 총 확정 공급가
    */
    private long totDcsnSplpc;
    /**
     * 총 확정 일시
    */
    private java.sql.Timestamp totDcsnDt;
    /**
     * 정산 공급가
    */
    private long excclcSplpc;
    /**
     * 정산 부가세
    */
    private long excclcVat;
    /**
     * 정산 금액
    */
    private long excclcAmount;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
    /**
     * 배송 창고 정보
    */
    private List<OrderWrhousVO> dlivyWrhousList;
    /**
     * 한글 사업장 명
    */
    private String sorinKoreanBplcNm;
    /**
     * 사업자 등록 번호
    */
    private String sorinBsnmRegistNo;
    /**
     * 대표자 명
    */
    private String sorinRprsntvNm;
    /**
     * 대표자 주소
    */
    private String sorinRprsntvAdres;
    /**
     * BL 번호 (복수, 구분자 콤마)
    */
    private String blNos;
    /**
     * 쿠폰 일련 번호
    */
    //private String couponSeqNo;
    /**
     * 쿠폰 할인금액
    */
    //private String couponDscntApplcAmount;
    /**
     * 쿠폰 적용전 배송비
    */
    //private String asisDelvCoopuon;
    /**
     * 쿠폰 적용 여부
    */
    private String couponApplcAt;
    /**
     * 최초 결제 금액
    */
    private long frstSetleAmount;
    /**
     * 미 결제 금액
    */
    private long unSetleAmount;
    /**
     * 증거금 최소 증거금 비율
    */
    private java.math.BigDecimal wrtmMummWrtmRate;
    /**
     * 증거금 결제 예정 일자
    */
    private String wrtmSetlePrearngeDe;
    /**
     * 쿠폰 구분 코드
    */
    //private String couponSeCode;

    /**
     * 원 배송비
    */
    private String asIsDscntAmout1;
    /**
     * 배송비 쿠폰금액 할인 금
    */
    private String dscntAmout1;
    /**
     * 원 상품금액
    */
    private String asIsDscntAmout2;
    /**
     * 단가 할인금
    */
    private String dscntAmout2;
    /**
     * 원 총액
    */
    private String asIsDscntAmout3;
    /**
     * 총액 할인금
    */
    private String dscntAmout3;
    /**
     * 판매단위
     */
    private long sleUnitWt;
    /**
     * 단가할인총액
     */
    private long priceDscAmt;
    /**
     * 등급할인금액
     */
    private long gradApplcAmount;
    
    /**
     * 지정가 유효시간
     */
    private String limitOrderValidTime;
    
    /**
     * 배송비 총 할인 가격
     */
    private String dlvyDsc;
    
    /**
     * 배송비 총 갯수
     */
    private String dlvyDscCnt;
    
}
