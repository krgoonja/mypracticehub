package com.sorincorp.mfo.pd.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * FixingPcOrderPossWtCeckVO.java
 * 케이지몰 주문 가능 중량 체크 VO 객체
 * @version
 * @since 2023. 3. 7.
 * @author srec0049
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FixingPcOrderPossWtCeckVO {
	
	/**
	 * 권역 대분류 코드
	 */
	private String dstrctLclsfCode;
	
	/**
	 * 아이템 순번
	 */
	private int itmSn;
	
	/**
	 * 업체 번호
	 */
	private String entrpsNo;
	
	/**
	 * 케이지몰 단위 기간 코드
	 */
	private String sorinmallUnitPdCode;
	
	/**
	 * 제한 중량
	 */
	private double lmttWt;
	
	/**
	 * 주문 중량
	 */
	private int orderWt;
	
	/**
	 * 판매 방식 코드
	 */
	private String sleMthdCode;
	
	/**
	 * 총 실제 주문 중량
	 */
	private int totRealOrderWt;
	
	/**
	 * 주문 가능 여부[Y: 가능, N: 불가능]
	 */
	private String orderPossYn;
}
