package com.sorincorp.mfo.pd.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class StockInfoVO {
	
	/** 입고예정정보 명칭 */
	private String stockInfoNm;
	
	/** 판매 가능일 */
	private String slePossde;
}