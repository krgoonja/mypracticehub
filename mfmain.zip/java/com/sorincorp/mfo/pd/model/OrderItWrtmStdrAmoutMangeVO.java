package com.sorincorp.mfo.pd.model;

import lombok.Data;

/**
 * OrderItWrtmStdrAmoutMangeVO.java
 * @version
 * @since 2022. 7. 21.
 * @author srec0049
 */
@Data
public class OrderItWrtmStdrAmoutMangeVO {
	
	/**
	 * LME 전일 종가
	 */
	private float endPcAgo;
	
	/**
     * 증거금 기준 순번
    */
    private long wrtmStdrSn;
    
    /**
     * 구간 시작 금액
    */
    private java.math.BigDecimal sctnBeginAmount;
    
    /**
     * 구간 종료 금액
    */
    private java.math.BigDecimal sctnEndAmount;
    
    /**
     * 구간 평균 금액
    */
    private java.math.BigDecimal sctnAvrgAmount;
    
    /**
     * 구매 성향 1단계 범위 시작 비율
    */
    private java.math.BigDecimal begin1StepRate;
    
    /**
     * 구매 성향 1단계 범위 종료 비율
    */
    private java.math.BigDecimal end1StepRate;
    
    /**
     * 구매 성향 1단계 비율
    */
    private java.math.BigDecimal purchsIncln1StepRate;
    
    /**
     * 구매 성향 1단계 금액
    */
    private java.math.BigDecimal purchsIncln1StepAmount;
    
    /**
     * 구매 성향 2단계 범위 시작 비율
    */
    private java.math.BigDecimal begin2StepRate;
    
    /**
     * 구매 성향 2단계 범위 종료 비율
    */
    private java.math.BigDecimal end2StepRate;
    
    /**
     * 구매 성향 2단계 비율
    */
    private java.math.BigDecimal purchsIncln2StepRate;
    
    /**
     * 구매 성향 2단계 금액
    */
    private java.math.BigDecimal purchsIncln2StepAmount;
    
    /**
     * 구매 성향 3단계 범위 시작 비율
    */
    private java.math.BigDecimal begin3StepRate;
    
    /**
     * 구매 성향 3단계 범위 종료 비율
    */
    private java.math.BigDecimal end3StepRate;
    
    /**
     * 구매 성향 3단계 비율
    */
    private java.math.BigDecimal purchsIncln3StepRate;
    
    /**
     * 구매 성향 3단계 금액
    */
    private java.math.BigDecimal purchsIncln3StepAmount;
    
    /**
     * 구매 성향 4단계 범위 시작 비율
    */
    private java.math.BigDecimal begin4StepRate;
    
    /**
     * 구매 성향 4단계 범위 종료 비율
    */
    private java.math.BigDecimal end4StepRate;
    
    /**
     * 구매 성향 4단계 비율
    */
    private java.math.BigDecimal purchsIncln4StepRate;
    
    /**
     * 구매 성향 4단계 금액
    */
    private java.math.BigDecimal purchsIncln4StepAmount;
}
