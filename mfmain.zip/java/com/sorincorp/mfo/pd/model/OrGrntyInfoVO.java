package com.sorincorp.mfo.pd.model;

import lombok.Data;

/**
 * OrGrntyInfoVO.java
 * 보증 정보 VO 객체
 * @version
 * @since 2022. 11. 23.
 * @author srec0049
 */
@Data
public class OrGrntyInfoVO {
	
	/**
	 * 보증 번호
	 */
	private String grntyNo;
	
	/**
	 * 업체 담보 계약 순번
	 */
	private int entrpsMrtggCntrctSn;
	
	/**
	 * 담보 보증 수수료 부담 주체 여부
	 */
	private String mrtggGrntyFeeBndMbyAt;
	
	/**
	 * 보증 기한 시작 일자
	 */
	private String grntyTmlmtBeginDe;
	
	/**
	 * 보증 기한 종료 일자
	 */
	private String grntyTmlmtEndDe;
}
