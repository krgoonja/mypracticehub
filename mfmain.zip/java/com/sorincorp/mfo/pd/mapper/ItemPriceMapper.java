package com.sorincorp.mfo.pd.mapper;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.mfo.pd.model.ItemPriceSelectVO;
import com.sorincorp.mfo.pd.model.OrderPriceBasketVO;
import com.sorincorp.mfo.pd.model.OrderPricePricingVO;

import com.sorincorp.mfo.cs.model.MaterialCalenderVO;
import com.sorincorp.mfo.mb.model.MbEntrpsGradVO;
import com.sorincorp.mfo.pd.model.BsnManageLgistDateVO;
import com.sorincorp.mfo.pd.model.DeliveryRequestDateVO;
import com.sorincorp.mfo.pd.model.ItemPriceSelectVO;
import com.sorincorp.mfo.pd.model.LimitOrderModel;
import com.sorincorp.mfo.pd.model.OrderPriceBasketVO;
import com.sorincorp.mfo.pd.model.OrderPricePricingVO;
import com.sorincorp.mfo.pd.model.OrderReceiptVO;
import com.sorincorp.mfo.pd.model.StockInfoVO;

public interface ItemPriceMapper {

	/**
	 * <pre>
	 * 처리내용: 조건에 맞는 출고 요청일을 가져온다.
	 * </pre>
	 * @date 2021. 7. 16.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 16.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @return DeliveryRequestDateVO
	 */
	//DeliveryRequestDateVO selectDeliveryRequestDate(String metalCode);
	DeliveryRequestDateVO selectDeliveryRequestDate(String metalCode);
	
	
	/**
	 * <pre>
	 * 처리내용: OrderPricingVO 내용을 Pricing Table에 저장한다.
	 * </pre>
	 * @date 2021. 8. 4.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 4.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itemPriceSearchVO
	 * @return void
	 */
	void insertOrderPricing(OrderPricePricingVO orderPricingVO);

	/**
	 * <pre>
	 * 처리내용: OrderBasketVO 내용을 Basket Table에 저장한다.
	 * </pre>
	 * @date 2021. 8. 4.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 4.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itemPriceSearchVO
	 * @return void
	 */
	 void insertOrderBasket(OrderPriceBasketVO orderBasketVO);
	
	/**
	 * <pre>
	 * 처리내용: OrderBasketVO 내용을 Basket history Table에 저장한다.
	 * </pre>
	 * @date 2021. 8. 4.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 4.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itemPriceSearchVO
	 * @return void
	 */
	 void insertOrderBasketHistory(OrderPriceBasketVO orderBasketVO);


	/**
	 * <pre>
	 * 처리내용: OR_PRICING_BAS에 정보를 update한다.
	 * </pre>
	 * @date 2021. 8. 10.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 10.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itemPriceSelectVO
	 * @return void
	 */
	void updateOrderPricing(OrderPricePricingVO orderPricePricingVo);


	/**
	 * <pre>
	 * 처리내용: 장바구니 정보를 가져온다.
	 * </pre>
	 * @date 2021. 8. 11.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 11.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itemPriceSelectVo
	 * @return List<ItemPriceSelectVO>
	 */
	List<ItemPriceSelectVO> selectOrderBasketList(ItemPriceSelectVO itemPriceSelectVo);
	
	/**
	 * <pre>
	 * 처리내용: bsktNo를 키값으로 관심목록을 삭제한다.
	 * </pre>
	 * @date 2021. 8. 23.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 23.		Kwon sun hyung		최초작성
	 * 2022. 2. 16.		Kwon sun hyung		수정
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param bsktNo
	 */
	void deleteOrderBasket(ItemPriceSelectVO itemPriceSelectVo);


	/**
	 * <pre>
	 * 처리내용: 업체번호를 기준으로 관심목록의 갯수를 가져온다.
	 * </pre>
	 * @date 2021. 9. 29.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 29.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param string
	 * @return
	 */
	int selectOrderBasketCount(ItemPriceSelectVO itemPriceSelectVo);


	/**
	 * <pre>
	 * 처리내용: 사용중인 관심품목 중 오래된 항목을 삭제한다.
	 * </pre>
	 * @date 2021. 12. 27.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 27.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 */
	void deleteOlderOrderBasket(ItemPriceSelectVO itemPriceSelectVo);


	/**
	 * <pre>
	 * 처리내용: 실시간 현재 재고를 파악한다.
	 * </pre>
	 * @date 2022. 03. 30.
	 * @author heehoonc
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 03. 30.		heehoonc		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 */
	BigDecimal selectRealStock(ItemPriceSelectVO itemPriceSelectVo);
	
	List<BrandCodeVO> selectRealStockBrandList(ItemPriceSelectVO itemPriceSelectVo);
	
	List<BrandCodeVO> selectRealStockRemainList(ItemPriceSelectVO itemPriceSelectVo);
	
	/**
	 * <pre>
	 * 처리내용: 실시간 현재 재고를 파악한다.(브랜드무관일때 브랜드별 실시간재고)
	 * </pre>
	 * @date 2023. 03. 31.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 03. 31.	    srec0067		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 */
	BigDecimal selectRealStockByBrandCodeIrrelevant(ItemPriceSelectVO itemPriceSelectVo);

	/**
	 * <pre>
	 * 처리내용: 소량구매 실시간 현재 재고를 파악한다.
	 * </pre>
	 * @date 2024. 5. 14.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 5. 14.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	List<BrandCodeVO> selectRealStockSmlqyPurchsList(ItemPriceSelectVO itemPriceSelectVo);

	/**
	 * <pre>
	 * 처리내용: 실시간 현재 재고를 최소중량 계수를 파악한다.
	 * </pre>
	 * @date 2022. 05. 04.
	 * @author heehoonc
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 03. 30.		heehoonc		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 */
	ItemPriceSelectVO selectItmInfoBas(ItemPriceSelectVO itemPriceSelectVo);
	
	/**
	 * <pre>
	 * 처리내용: 성적서를 조회한다.
	 * </pre>
	 * @date 2022. 7. 28
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 28.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param orderNO
	 * @return
	 * @throws Exception
	 */
	List<Map<String, Object>> selectScreofeList(List<String> blNoList) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 한국 공휴일을 가져온다.
	 * </pre>
	 * @date 2022. 10. 13.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 13.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param 
	 * @return
	 * @throws Exception
	 */	
	List<MaterialCalenderVO> selectKoreaWeekendList() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 입고예정정보를 조회한다(메탈,권역기준)
	 * </pre>
	 * @date 2022. 11. 16.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 16.		srec0067			최초작성
	 * ------------------------------------------------
	 * @param 
	 * @return
	 * @throws Exception
	 */	
	List<StockInfoVO> selectStockInfoList(ItemPriceSelectVO itemPriceSelectVo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 해당 BL 이 선택값과 맞는지 체크
	 * </pre>
	 * @date 2022. 12. 1.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 1.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 * @throws Exception
	 */
	int isSelectItemBL(ItemPriceSelectVO itemPriceSelectVo) throws Exception;

	BigDecimal selectBlinfoBas(ItemPriceSelectVO itemPriceSelectVo);
	
	/**
	 * <pre>
	 * 업체번호별 1회 최대 주문 가능 중량을 조회한다.
	 * </pre>
	 * @date 2023. 2. 28.
	 * @author srec0077
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 2. 28.		  srec0077				최초작성
	 * ------------------------------------------------
	 */
	int selectMxmmOrderWt(ItemPriceSelectVO itemPriceSelectVo);


	/**
	 * <pre>
	 * 처리내용: 브랜드 변동금액 목록을 조회한다.
	 * </pre>
	 * @date 2023. 4. 19.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 19.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 */	
	List<OrderReceiptVO> selectBrandChangeAmountList(ItemPriceSelectVO itemPriceSelectVo);


	/**
	 * <pre>
	 * 처리내용: 금일 Live 주문 중, 브랜드까지 동일한 주문 리스트(가격, 수량, 시간) 를 조회한다.
	 * </pre>
	 * @date 2023. 4. 19.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 19.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 */	
	List<OrderReceiptVO> selectLiveOrderList(ItemPriceSelectVO itemPriceSelectVo);


	/**
	 * <pre>
	 * 처리내용: 금일 지정가 주문 중, 브랜드까지 동일한 주문 리스트를 조회한다.
	 * </pre>
	 * @date 2023. 5. 3.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 3.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 */	
	List<LimitOrderModel> selectLimitOrderList(ItemPriceSelectVO itemPriceSelectVo);
	
	/**
	 * <pre>
	 * 처리내용: 해당 업체의 현재 구매하고자 하는 금속의 지정가 주문 가능 여부를 조회한다.
	 * </pre>
	 * @date 2023. 5. 17.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 17.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 */
	boolean getAppnPcAt(ItemPriceSelectVO itemPriceSelectVo);
	
	/**
	 * <pre>
	 * 처리내용: 해당 업체의 일일 지정가 주문 가능 횟수를 체크하여 주문 가능 여부를 조회한다.
	 * </pre>
	 * @date 2023. 5. 17.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 17.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	boolean getOrderLimitCheck(String entrpsNo);
	

	/**
	 * <pre>
	 * 처리내용: 영업시간 조회
	 * </pre>
	 * @date 2023. 7. 5.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 5.			sumin				최초작성
	 * ------------------------------------------------
	 * @return String
	 * @throws Exception
	 */
	String selectSalesTime() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 전일종가 조회
	 * </pre>
	 * @date 2023. 7. 25.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 7. 25.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 */
	String getOrderPreEndPc(String metalCode, String dstrctLclsfCode, Integer itmSn, String brandGroupCode, String brandCode);
	
	/**
	 * <pre>
	 * 처리내용: 회원의 등급별 할인 데이터 조회.
	 * </pre>
	 * @date 2023. 9. 15.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 15.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param MbEntrpsGradVO
	 * @return
	 * @throws Exception
	 */
	MbEntrpsGradVO getDscntAmount(MbEntrpsGradVO mbEntrpsGradVO) throws Exception;
	
	List<BsnManageLgistDateVO> selectBsnManageLgistDate() throws Exception;
}
