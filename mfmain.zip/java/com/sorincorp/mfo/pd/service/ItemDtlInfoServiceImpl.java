package com.sorincorp.mfo.pd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.mfo.pd.mapper.ItemDtlInfoMapper;
import com.sorincorp.mfo.pd.model.ItemDtlInfoVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ItemDtlInfoServiceImpl implements ItemDtlInfoService {

	@Autowired
	private ItemDtlInfoMapper itemDtlInfoMapper;

	@Override
	public ItemDtlInfoVO selectItemDtlInfo(ItemDtlInfoVO itemDtlInfoVO) throws Exception {
		// TODO Auto-generated method stub
		ItemDtlInfoVO vo = itemDtlInfoMapper.selectItemDtlInfo(itemDtlInfoVO);
		String chargerMoblphon = vo.getChargerMoblphon();
		String chargerCttpc = vo.getChargerCttpc();
		String regEx = "(\\d{3})(\\d{3,4})(\\d{4})";
		String regEx2 = "(\\d{2})(\\d{3,4})(\\d{4})";

		//담당자 휴대폰, 연락처 복호화 20220222 srec0030
		if(chargerMoblphon != null && !"".equals(chargerMoblphon)) {
			try {
				log.debug("담당자 휴대폰 번호 복호화 전 =============> " + chargerMoblphon);
				chargerMoblphon = CryptoUtil.decryptAES256(chargerMoblphon);
				log.debug("담당자 휴대폰 번호 복호화 후 =============> " + chargerMoblphon);
				vo.setChargerMoblphon(chargerMoblphon.replaceAll(regEx, "$1-$2-$3"));
			} catch (Exception e) {
				// TODO: handle exception
				log.error("selectItemDtlInfo CHARGER_MOBLPHON CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}

		if(chargerCttpc != null && !"".equals(chargerCttpc)) {
			try {
				log.debug("담당자 연락처 번호 복호화 전 =============> " + chargerCttpc);
				chargerCttpc = CryptoUtil.decryptAES256(chargerCttpc);
				log.debug("담당자 연락처 번호 복호화 후 =============> " + chargerCttpc);

				if("02".equals(chargerCttpc.substring(0, 2))) {
					vo.setChargerCttpc(chargerCttpc.replaceAll(regEx2, "$1-$2-$3"));
				} else {
					vo.setChargerCttpc(chargerCttpc.replaceAll(regEx, "$1-$2-$3"));
				}
			} catch (Exception e) {
				// TODO: handle exception
				log.error("selectItemDtlInfo CHARGER_CTTPC CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}

		return vo;
	}

	@Override
	public List<ItemDtlInfoVO> selectBrandStdSpecDtlList(ItemDtlInfoVO itemDtlInfoVO) throws Exception {
		// TODO Auto-generated method stub
		return itemDtlInfoMapper.selectBrandStdSpecDtlList(itemDtlInfoVO);
	}

	@Override
	public List<ItemDtlInfoVO> selectItmStdSpecDtlList(ItemDtlInfoVO itemDtlInfoVO) throws Exception {
		// TODO Auto-generated method stub
		return itemDtlInfoMapper.selectItmStdSpecDtlList(itemDtlInfoVO);
	}

}
