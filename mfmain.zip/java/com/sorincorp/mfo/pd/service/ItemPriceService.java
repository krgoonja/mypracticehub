package com.sorincorp.mfo.pd.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingSelectVO;
import com.sorincorp.mfo.chart.model.PreminumSelVO;
import com.sorincorp.mfo.login.model.Account;
import com.sorincorp.mfo.mb.model.MbEntrpsGradVO;
import com.sorincorp.mfo.pd.model.DeliveryRequestDateVO;
import com.sorincorp.mfo.pd.model.ItemPriceSelectVO;
import com.sorincorp.mfo.pd.model.OrderPricePricingVO;
import com.sorincorp.mfo.pd.model.OrderReceiptVO;

public interface ItemPriceService {

	/**
	 * <pre>
	 * 처리내용: 코드리스트를 select taglib에 사용할 수 있도록 String 값으로 변환한다.
	 * </pre>
	 * @date 2021. 7. 15.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 15.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param CodeList - 변환할 값이 담긴 Map
	 * @param firstSelectName - 맨 처음 select 값 명칭
	 * @return 변환한 String
	 * @throws Exception
	 */
	String getCodeListToStr(Map<String, String> CodeList, String firstSelectName) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 검색 조건에 맞는 ItemBL을 검색하고 매칭 Algorithm을 사용하여 값을 반환한다.
	 * </pre>
	 * @date 2021. 7. 15.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 15.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itemPriceVO
	 * @return 조건에 맞는 List<ItemPriceVO>
	 * @throws Exception
	 */
	List<ItemPriceMatchingBlInfoVO> searchItemBLWithMatcingList(ItemPriceMatchingSelectVO itemPriceVO) throws Exception;
	
	
	/**
	 * <pre>
	 * 처리내용: metalCode에 맞는 출고 요청일을 가져온다.
	 * </pre>
	 * @date 2021. 7. 16.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 16.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @return DeliveryRequestDateVO
	 * @throws Exception
	 */
	@ResponseBody
	DeliveryRequestDateVO selectDeliveryRequestDate(String metalCode) throws Exception;

	
	/**
	 * <pre>
	 * 처리내용: 코드리스트의 subCode에 이름값을 지우고 반환한다.
	 * </pre>
	 * @date 2021. 7. 26.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 26.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param codeList
	 * @return Map<String, String>
	 * @throws Exception
	 */
	Map<String, String> getCodeListAfterRemoveSubName(Map<String, String> codeList) throws Exception;

	
	/**
	 * <pre>
	 * 처리내용: OrderPricingVO 내용을 Pricing Table에 저장한다.
	 * </pre>
	 * @date 2021. 8. 4.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 4.		Kwon sun hyung		최초작성
	 * 2022. 2. 21.		Kwon sun hyung		메소드 분리, 통합 
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param ItemPriceSelectVO
	 * @throws Exception
	 */
	OrderPricePricingVO insertOrderPricing(ItemPriceSelectVO itemPriceSelectVO) throws Exception;
	

	/**
	 * <pre>
	 * 처리내용: OrderPriceBasketVO 내용을 Basket Table에 저장하고 basketNo를 리턴한다.
	 * </pre>
	 * @date 2021. 8. 9.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 9.		Kwon sun hyung		최초작성
	 * 2022. 2. 21.		Kwon sun hyung		메소드 분리
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param ItemPriceSelectVO
	 * @return String
	 * @throws Exception
	 */
	String insertOrderBasket(ItemPriceSelectVO itemPriceSelectVo) throws Exception;

	
	/**
	 * <pre>
	 * 처리내용: 장바구니 정보를 가져온다.
	 * </pre>
	 * @date 2021. 8. 11.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 11.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param ItemPriceSelectVO
	 * @return List<ItemPriceSelectVO>
	 * @throws Exception
	 */
	List<ItemPriceSelectVO> selectOrderBasketList(ItemPriceSelectVO itemPriceSelectVo) throws Exception;

	
	/**
	 * <pre>
	 * 처리내용: 오늘 날짜의 해당 프리미엄 정보를 가져온다.
	 * </pre>
	 * @date 2021. 11. 18.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 18.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itemPriceSelectVo
	 * @return
	 * @throws Exception
	 */
	long getFnPreminumPrice(ItemPriceSelectVO itemPriceSelectVo) throws Exception;
	
	
	/**
	 * <pre>
	 * 처리내용: 오늘 날짜의 해당 프리미엄 정보 리트스를 가져온다.
	 * </pre>
	 * @date 2021. 12. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itemPriceSelectVoList
	 * @return
	 * @throws Exception
	 */
	List<PreminumSelVO> getFnPreminumPriceVoList(List<ItemPriceSelectVO> itemPriceSelectVoList) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 선택한 관심목록을 삭제한다.
	 * </pre>
	 * @date 2021. 8. 23.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 23.		Kwon sun hyung		최초작성
	 * 2022. 2. 16.		Kwon sun hyung		수정
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itemPriceSelectVO
	 */

	void deleteOrderBasket(ItemPriceSelectVO itemPriceSelectVO);

	
	/**
	 * <pre>
	 * 처리내용: 업체번호를 기준으로 관심목록의 갯수를 가져온다.
	 * </pre>
	 * @date 2021. 9. 29.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 29.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param string
	 * @return
	 */
	int selectOrderBasketCount(ItemPriceSelectVO itemPriceSelectVo);


	/**
	 * <pre>
	 * 처리내용: 사용하는 관심품목 중 오래된 관심품목을 삭제한다.
	 * </pre>
	 * @date 2021. 12. 27.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 27.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 */
	void deleteOlderOrderBasket(ItemPriceSelectVO itemPriceSelectVo);

	/**
	 * <pre>
	 * 처리내용: 실시간 현재 재고를 파악한다.
	 * </pre>
	 * @date 2022. 03. 30.
	 * @author heehoonc
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 03. 30.		heehoonc		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 */
	BigDecimal selectRealStock(ItemPriceSelectVO itemPriceSelectVo);
	
	List<BrandCodeVO> selectRealStockBrandList(ItemPriceSelectVO itemPriceSelectVo);
	
	List<BrandCodeVO> selectRealStockRemainList(ItemPriceSelectVO itemPriceSelectVo);
	/**
	 * <pre>
	 * 처리내용: 실시간 현재 재고를 파악한다.(브랜드무관일때 브랜드별 실시간재고)
	 * </pre>
	 * @date 2023. 03. 31.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 03. 31.	    srec0067		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 */
	BigDecimal selectRealStockByBrandCodeIrrelevant(ItemPriceSelectVO itemPriceSelectVo);

	/**
	 * <pre>
	 * 처리내용: 소량구매 실시간 현재 재고를 파악한다.
	 * </pre>
	 * @date 2024. 5. 14.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 5. 14.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	List<BrandCodeVO> selectRealStockSmlqyPurchsList(ItemPriceSelectVO itemPriceSelectVo);
	
	/**
	 * <pre>
	 * 처리내용: 실시간 현재 재고를 최소중량 계수를 파악한다.
	 * </pre>
	 * @date 2022. 05. 04.
	 * @author heehoonc
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 05. 04.		heehoonc		최초작성
	 * 2023. 08. 11			jdrttl		 	리턴값 VO로 변경
	 * -------------------------------------------------------------------------
	 * </pre>
	 */
	ItemPriceSelectVO selectItmInfoBas(ItemPriceSelectVO itemPriceSelectVo);
	
	/**
	 * <pre>
	 * 처리내용: 브랜드 그룹에 맞는 B/L 과 성적서다운로드정보를 가져온다.
	 * </pre>
	 * @date 2022. 7. 29.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 29.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	public List<Map<String, Object>> selectScreofeList(List<String> blNoList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 한국 공휴일을 가져온다.
	 * </pre>
	 * @date 2022. 10. 13.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 13.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param 
	 * @return
	 * @throws Exception
	 */
	public List<String> selectKoreaWeekendList() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 입고예정정보를 조회한다(메탈,권역기준)
	 * </pre>
	 * @date 2022. 11. 16.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 16.		srec0067			최초작성
	 * ------------------------------------------------
	 * @param 
	 * @return
	 * @throws Exception
	 */
	public JSONArray selectStockInfoList(ItemPriceSelectVO itemPriceSelectVo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 최적BL 및 아이템구매중량 한도를 적용한 버튼비활성화중량 제한을 조회한다.
	 * </pre>
	 * @date 2022. 11. 23.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 23.		srec0067				최초작성
	 * ------------------------------------------------
	 * @param 
	 * @return
	 * @throws Exception
	 */
	ItemPriceMatchingSelectVO getItemPriceCompare(ItemPriceSelectVO returnItemPriceSelectVo, boolean isJustBuyProcess) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 아이템 또는 업체별 구매한도를 조회한다.
	 * </pre>
	 * @date 2022. 11. 23.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 23.		srec0067				최초작성
	 * ------------------------------------------------
	 * @param 
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, String> getOrderWeightLimit(Account account, ItemPriceSelectVO itemPriceSelectVo, boolean checkYn) throws Exception;

/**
	 * <pre>
	 * 처리내용: 해당 BL 이 선택값과 맞는지 체크
	 * </pre>
	 * @date 2022. 12. 1.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 1.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 * @throws Exception
	 */
	boolean isSelectItemBL(ItemPriceSelectVO itemPriceSelectVo) throws Exception;
	
		
	/**
	 * <pre>
	 * 처리내용: 해당 BL 이 선택값과 맞는지 체크
	 * </pre>
	 * @date 2022. 12. 1.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 1.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 * @throws Exception
	 */
	BigDecimal selectBlinfoBas(ItemPriceSelectVO itemPriceSelectVo) throws Exception;
	

	/**
	 * <pre>
	 * 업체번호별 1회 최대 주문 가능 중량을 조회한다.
	 * </pre>
	 * @date 2023. 2. 28.
	 * @author srec0077
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 2. 28.		  srec0077				최초작성
	 * ------------------------------------------------
	 */
	int selectMxmmOrderWt(ItemPriceSelectVO itemPriceSelectVo);
	
	/**
	 * <pre>
	 * 처리내용: 브랜드 변동금액 목록을 조회한다.
	 * </pre>
	 * @date 2023. 4. 19.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 19.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 */
	List<OrderReceiptVO> selectBrandChangeAmountList(ItemPriceSelectVO itemPriceSelectVo);
	
	/**
	 * <pre>
	 * 처리내용: 금일 Live 주문 중, 브랜드까지 동일한 주문 리스트(가격, 수량, 시간) 를 조회한다.
	 * </pre>
	 * @date 2023. 4. 19.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 19.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 */
	List<OrderReceiptVO> selectLiveOrderList(ItemPriceSelectVO itemPriceSelectVo);
	
	/**
	 * <pre>
	 * 처리내용: 금일 지정가 주문 중, 브랜드까지 동일한 주문 리스트를 조회한다.
	 * </pre>
	 * @date 2023. 5. 3.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 3.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 */
	Map<String, Object> selectLimitOrderData(ItemPriceSelectVO itemPriceSelectVo);
	
	
	/**
	 * <pre>
	 * 처리내용: 오늘 날짜의 해당 브랜드 변동금을 가져온다.
	 * </pre>
	 * @date 2023. 4. 21.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 21.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 * @throws Exception
	 */
	long getBrandChangeAmount(ItemPriceSelectVO itemPriceSelectVo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 지정가 주문 가능 여부를 조회한다. (주문 모달창에서만 활용 가능)
	 * </pre>
	 * @date 2023. 5. 17.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 17.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> getLimitOrderPossAt(ItemPriceSelectVO itemPriceSelectVo) throws Exception;
	

	/**
	 * <pre>
	 * 처리내용: 영업시간 조회
	 * </pre>
	 * @date 2023. 7. 5.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 5.			sumin				최초작성
	 * ------------------------------------------------
	 * @return String
	 * @throws Exception
	 */
	String selectSalesTime() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 전일 종가 가져오기
	 * </pre>
	 * @date 2023. 7. 25.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 7. 25.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 * @throws Exception
	 */
	String getOrderPreEndPc(ItemPriceSelectVO itemPriceSelectVo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 회원의 등급별 할인 데이터 조회.
	 * </pre>
	 * @date 2023. 9. 15.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 15.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param MbEntrpsGradVO
	 * @return
	 * @throws Exception
	 */
	MbEntrpsGradVO getDscntAmount(MbEntrpsGradVO mbEntrpsGradVO) throws Exception;
	
	String getMinLimitOrderNightTime(String metalCode, String nowDate, int maxNextCnt) throws Exception;
}
