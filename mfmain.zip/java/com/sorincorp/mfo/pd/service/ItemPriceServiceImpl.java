package com.sorincorp.mfo.pd.service;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.brandcode.service.BrandCodeService;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.entrpsgrade.model.EntrpsGradeVO;
import com.sorincorp.comm.entrpsgrade.service.EntrpsGradeService;
import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.itemprice.mapper.ItemPriceMatchingMapper;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingSelectVO;
import com.sorincorp.comm.itemprice.service.ItemPriceMatchingService;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.comm.pcInfo.model.FixPriceVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.mfo.chart.mapper.PcMntrngMapper;
import com.sorincorp.mfo.chart.model.PreminumInfoDto;
import com.sorincorp.mfo.chart.model.PreminumSelVO;
import com.sorincorp.mfo.config.UserInfoUtil;
import com.sorincorp.mfo.cs.model.MaterialCalenderVO;
import com.sorincorp.mfo.login.model.Account;
import com.sorincorp.mfo.mb.model.MbEntrpsGradVO;
import com.sorincorp.mfo.pd.mapper.ItemPriceMapper;
import com.sorincorp.mfo.pd.mapper.OrderMapper;
import com.sorincorp.mfo.pd.model.BsnManageLgistDateVO;
import com.sorincorp.mfo.pd.model.DeliveryRequestDateVO;
import com.sorincorp.mfo.pd.model.ItemDtlInfoVO;
import com.sorincorp.mfo.pd.model.ItemPriceSelectVO;
import com.sorincorp.mfo.pd.model.LimitOrderModel;
import com.sorincorp.mfo.pd.model.OrderPriceBasketVO;
import com.sorincorp.mfo.pd.model.OrderPricePricingVO;
import com.sorincorp.mfo.pd.model.OrderReceiptVO;
import com.sorincorp.mfo.pd.model.StockInfoVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ItemPriceServiceImpl implements ItemPriceService {

	public static final String SEARCH_PRICE = "01"; //가격탐색
	public static final String INSERT_BASKET = "02"; // 장바구니

	@Autowired
	private ItemPriceMapper itemPriceMapper;

	@Autowired
	private AssignService assignService;

	@Autowired
	private PcInfoService pcInfoService;

	@Autowired
	private ItemPriceMatchingService itemPriceMatchingService;

	@Autowired
	private PcMntrngMapper pcMntrngMapper;
	
	@Autowired
	private OrderMapper orderMapper;
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private EntrpsGradeService entrpsGradeService;
	
	@Autowired
	private BrandCodeService brandCodeService;
	
	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired
	private UserInfoUtil userInfoUtil;
	
	@Autowired
	private ItemPriceMatchingMapper itemPriceMatchingMapper;


	@Override
	public String getCodeListToStr(Map<String, String> codeListToStr, String firstSelectName) throws Exception {
		StringBuilder codeTaglibStr = new StringBuilder(StringUtils.EMPTY);

		if(!firstSelectName.equals("")) {
			codeTaglibStr.append("");
			codeTaglibStr.append(CommonConstants.COLONE);
			codeTaglibStr.append(firstSelectName);
			codeTaglibStr.append(CommonConstants.SEMI_COLONE);
		}

		for(Map.Entry<String, String> entry : codeListToStr.entrySet()) {
			if(!entry.getKey().equals("@")) {
				codeTaglibStr.append(entry.getKey());
				codeTaglibStr.append(CommonConstants.COLONE);
				codeTaglibStr.append(entry.getValue());
				codeTaglibStr.append(CommonConstants.SEMI_COLONE);
			}
		}

		return codeTaglibStr.toString();
	}

	@Override
	public List<ItemPriceMatchingBlInfoVO> searchItemBLWithMatcingList(ItemPriceMatchingSelectVO itemPriceMatchingSelectVO) throws Exception {
		int minSearchBoundaryWeight = itemPriceMatchingSelectVO.getSleUnitWt(); //최소 중량 탐색 범위
		int maxSearchBoundaryWeight = itemPriceMatchingSelectVO.getOnceSlePossWt(); //최대 중량 탐색 범위
		int maxBlSearchCount = 4; // 최대 탐색 BL 개수
		int weightUnit = itemPriceMatchingSelectVO.getSleUnitWt(); // 탐색 중량 단위
		return itemPriceMatchingService.itemBLWithMatchingList(itemPriceMatchingSelectVO, minSearchBoundaryWeight, maxSearchBoundaryWeight, maxBlSearchCount, weightUnit);
	}

	@Override
	public DeliveryRequestDateVO selectDeliveryRequestDate(String metalCode) throws Exception {
		return itemPriceMapper.selectDeliveryRequestDate(metalCode);
	}

	@Override
	public OrderPricePricingVO insertOrderPricing(ItemPriceSelectVO itemPriceSelectVo) throws Exception {

		String dateTimeNow = DateUtil.getNowDateTime("yyyyMMddHHmmss");

		String dateNow = DateUtil.getNowDate();
		String pricingNo = "P" + dateNow + "-" + assignService.selectAssignValue("PD", "PRICING_NO", dateNow, "SYSTEM", 6);

		OrderPricePricingVO orderPricePricingVo = new OrderPricePricingVO();
		orderPricePricingVo.setPricingNo(pricingNo);
		orderPricePricingVo.setMetalCode(itemPriceSelectVo.getMetalCode());
		orderPricePricingVo.setItmSn(itemPriceSelectVo.getItmSn());
		orderPricePricingVo.setSleMthdCode(itemPriceSelectVo.getSleMthdCode());
		orderPricePricingVo.setDstrctLclsfCode(itemPriceSelectVo.getDstrctLclsfCode());
		orderPricePricingVo.setBrandGroupCode(itemPriceSelectVo.getBrandGroupCode());
		orderPricePricingVo.setBrandCode(itemPriceSelectVo.getBrandCode());
		orderPricePricingVo.setApplcDt(dateTimeNow);
		orderPricePricingVo.setEntrpsNo(itemPriceSelectVo.getEntrpsNo());
		orderPricePricingVo.setMberNo(itemPriceSelectVo.getMberNo());
		orderPricePricingVo.setPricingStepCode(SEARCH_PRICE); //01:가격탐색, 02:장바구니, 03:걸제완료
		orderPricePricingVo.setItmNm(itemPriceSelectVo.getItmNm());
		orderPricePricingVo.setGoodsNm(itemPriceSelectVo.getGoodsNm());
		orderPricePricingVo.setGoodsUntpc(itemPriceSelectVo.getGoodsUntpc());
		orderPricePricingVo.setSlePcRltmSn(itemPriceSelectVo.getSlePcRltmSn());
		orderPricePricingVo.setLmePcRltmSn(itemPriceSelectVo.getLmePcRltmSn());
		orderPricePricingVo.setEhgtPcRltmSn(itemPriceSelectVo.getEhgtPcRltmSn());
		orderPricePricingVo.setPremiumNo(itemPriceSelectVo.getPremiumNo());

		int orderWeight = 0;
		if (itemPriceSelectVo.getOrderWeight() != null) {
			orderWeight = itemPriceSelectVo.getOrderWeight().intValue();
		}

		if (itemPriceSelectVo.getPricingNo() != null) {
			orderPricePricingVo.setWonPricingNo(itemPriceSelectVo.getPricingNo());
		}

		if (itemPriceSelectVo.getBsktNo() != null) {
			orderPricePricingVo.setBsktNo(itemPriceSelectVo.getBsktNo());
			orderPricePricingVo.setPricingStepCode(INSERT_BASKET); // 01:가격탐색, 02:장바구니, 03:걸제완료
		}

		orderPricePricingVo.setOrderWt(orderWeight);
		orderPricePricingVo.setDeleteAt("N");
		orderPricePricingVo.setFrstRegisterId(itemPriceSelectVo.getFrstRegisterId());
		orderPricePricingVo.setLastChangerId(itemPriceSelectVo.getLastChangerId());

		itemPriceMapper.insertOrderPricing(orderPricePricingVo);

		return orderPricePricingVo;
	}

	@Override
	public int selectOrderBasketCount(ItemPriceSelectVO itemPriceSelectVo) {
		return itemPriceMapper.selectOrderBasketCount(itemPriceSelectVo);
	}
	@Override
	public String insertOrderBasket(ItemPriceSelectVO itemPriceSelectVo) throws Exception {

		String dateNow = DateUtil.getNowDate();
		String basketNo = "B" + dateNow + "-" + assignService.selectAssignValue("PD", "BSKT_NO", dateNow, "SYSTEM", 6);

		OrderPriceBasketVO orderBasketVo = new OrderPriceBasketVO();
		orderBasketVo.setBsktNo(basketNo);
		orderBasketVo.setApplcDe(dateNow);
		orderBasketVo.setMetalCode(itemPriceSelectVo.getMetalCode());
		orderBasketVo.setItmSn(itemPriceSelectVo.getItmSn());
		orderBasketVo.setSleMthdCode(itemPriceSelectVo.getSleMthdCode());
		orderBasketVo.setDstrctLclsfCode(itemPriceSelectVo.getDstrctLclsfCode());
		orderBasketVo.setBrandGroupCode(itemPriceSelectVo.getBrandGroupCode());
		orderBasketVo.setBrandCode(itemPriceSelectVo.getBrandCode());
		orderBasketVo.setEntrpsNo(itemPriceSelectVo.getEntrpsNo());
		orderBasketVo.setMberNo(itemPriceSelectVo.getMberNo());
		orderBasketVo.setGoodsUntpc(itemPriceSelectVo.getGoodsUntpc());
		orderBasketVo.setPremiumNo(itemPriceSelectVo.getPremiumNo());
		orderBasketVo.setSlePcRltmSn(itemPriceSelectVo.getSlePcRltmSn());
		orderBasketVo.setLmePcRltmSn(itemPriceSelectVo.getLmePcRltmSn());
		orderBasketVo.setEhgtPcRltmSn(itemPriceSelectVo.getEhgtPcRltmSn());
		orderBasketVo.setDeleteAt("N");
		orderBasketVo.setFrstRegisterId(itemPriceSelectVo.getFrstRegisterId());
		orderBasketVo.setLastChangerId(itemPriceSelectVo.getLastChangerId());

		itemPriceMapper.insertOrderBasket(orderBasketVo);
		itemPriceMapper.insertOrderBasketHistory(orderBasketVo);
		
		return basketNo;
	}
	

	@Override
	public List<ItemPriceSelectVO> selectOrderBasketList(ItemPriceSelectVO itemPriceSelectVO) throws Exception {
		List<ItemPriceSelectVO> returnItemPriceSelectVO = itemPriceMapper.selectOrderBasketList(itemPriceSelectVO);

		for(ItemPriceSelectVO vo : returnItemPriceSelectVO) {
			if("01".equals(vo.getSleMthdCode())) {
				PrSelVO prSelVO = pcInfoService.getNewestPrSelRltm(vo.getMetalCode(), vo.getItmSn(), vo.getDstrctLclsfCode(),
													vo.getBrandGroupCode(), vo.getBrandCode(), DateUtil.getNowDate());
	
				if(prSelVO != null) {
					vo.setGoodsUntpc(prSelVO.getEndPc());
					vo.setSlePcRltmSn(prSelVO.getSlePcRltmSn());
					vo.setEhgtPcRltmSn(prSelVO.getEhgtPcRltmSn());
					vo.setLmePcRltmSn(prSelVO.getLmePcRltmSn());
				}
			} else {
				String entrpsNo = userInfoUtil.getEntripsNo();
				
				FixPriceVO fixPriceVO = pcInfoService.hasEntrpsFixPriceData(vo.getMetalCode(), vo.getItmSn(), vo.getDstrctLclsfCode(),
						vo.getBrandGroupCode(), vo.getBrandCode(), entrpsNo, DateUtil.getNowDateTime("yyyyMM"));
				
				if(fixPriceVO != null) {
					vo.setPremiumNo(fixPriceVO.getPremiumNo());
					vo.setGoodsUntpc(fixPriceVO.getSlePc().longValue());
					vo.setEntrpsNo(entrpsNo);
				}
			}
		}
		return returnItemPriceSelectVO;
	}
	
	@Override
	public long getFnPreminumPrice(ItemPriceSelectVO itemPriceSelectVo) throws Exception {
		long sleAmount = 0;
		
		if (itemPriceSelectVo.getSleMthdCode().equals("01")) {
			List<PreminumSelVO> retunPreminumSelVoList = getFnPreminumInfo(itemPriceSelectVo);
			
			if(retunPreminumSelVoList.size() > 0) {
				sleAmount = retunPreminumSelVoList.get(0).getSlePremiumAmount();
			}
			
		} else {
			
			FixPriceVO fixPriceVO = pcInfoService.hasEntrpsFixPriceData(itemPriceSelectVo.getMetalCode(), itemPriceSelectVo.getItmSn(), itemPriceSelectVo.getDstrctLclsfCode(),
					itemPriceSelectVo.getBrandGroupCode(), itemPriceSelectVo.getBrandCode(), itemPriceSelectVo.getEntrpsNo(), DateUtil.getNowDateTime("yyyyMM"));
			
			if(fixPriceVO != null) {
				sleAmount = fixPriceVO.getSlePc().longValue();
			}
		}

		return sleAmount;
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2023. 4. 21.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 21.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 */
	private List<PreminumSelVO> getFnPreminumInfo(ItemPriceSelectVO itemPriceSelectVo) {
		PreminumInfoDto preminumInfoDto = new PreminumInfoDto();
		preminumInfoDto.setStdDt(DateUtil.getNowDate()); // 오늘날짜
		preminumInfoDto.setSleMthdCode(itemPriceSelectVo.getSleMthdCode());
		preminumInfoDto.setMetalCode(itemPriceSelectVo.getMetalCode());
		preminumInfoDto.setItmSn(itemPriceSelectVo.getItmSn());
		preminumInfoDto.setDstrctLclsfCode(itemPriceSelectVo.getDstrctLclsfCode());
		preminumInfoDto.setBrandGroupCode(itemPriceSelectVo.getBrandGroupCode());
		preminumInfoDto.setBrandCode(itemPriceSelectVo.getBrandCode());
		preminumInfoDto.setValidBeginDt(DateUtil.getNowDateTime("yyyyMMddHHmmss"));
		preminumInfoDto.setValidEndDt(DateUtil.getNowDateTime("yyyyMMddHHmmss"));

		List<PreminumSelVO> retunPreminumSelVoList = pcMntrngMapper.getFnPreminumInfoList(preminumInfoDto);
		return retunPreminumSelVoList;
	}


	@Override
	public List<PreminumSelVO> getFnPreminumPriceVoList(List<ItemPriceSelectVO> itemPriceSelectVoList) throws Exception {

		List<PreminumSelVO> lisVo = new ArrayList<PreminumSelVO>();

		for(ItemPriceSelectVO vo : itemPriceSelectVoList) {
			if("01".equals(vo.getSleMthdCode())) {
				PreminumInfoDto preminumInfoDto = new PreminumInfoDto();
				preminumInfoDto.setMetalCode(vo.getMetalCode());
				preminumInfoDto.setSleMthdCode(vo.getSleMthdCode());
				preminumInfoDto.setItmSn(vo.getItmSn());
				preminumInfoDto.setDstrctLclsfCode(vo.getDstrctLclsfCode());
				preminumInfoDto.setBrandGroupCode(vo.getBrandGroupCode());
				preminumInfoDto.setBrandCode(vo.getBrandCode());
				preminumInfoDto.setValidBeginDt(DateUtil.getNowDateTime("yyyyMMddHHmmss"));
				preminumInfoDto.setValidEndDt(DateUtil.getNowDateTime("yyyyMMddHHmmss"));
				
				List<PreminumSelVO> resultFnPremiumInfoList = pcMntrngMapper.getFnPreminumInfoList(preminumInfoDto);
								
				if(resultFnPremiumInfoList == null || resultFnPremiumInfoList.size() == 0) {
					PreminumSelVO resultPreminumSelVO = new PreminumSelVO();
					resultPreminumSelVO.setMetalCode(vo.getMetalCode());
					resultPreminumSelVO.setSleMthdCode(vo.getSleMthdCode());
					resultPreminumSelVO.setItmSn(vo.getItmSn());
					resultPreminumSelVO.setDstrctLclsfCode(vo.getDstrctLclsfCode());
					resultPreminumSelVO.setBrandGroupCode(vo.getBrandGroupCode());
					resultPreminumSelVO.setBrandCode(vo.getBrandCode());
					
					lisVo.add(resultPreminumSelVO);
				} else {
					lisVo.addAll(resultFnPremiumInfoList);
				}
			} else {
				FixPriceVO fixPriceVO = pcInfoService.hasEntrpsFixPriceData(vo.getMetalCode(), vo.getItmSn(), vo.getDstrctLclsfCode(),
						vo.getBrandGroupCode(), vo.getBrandCode(), vo.getEntrpsNo(), DateUtil.getNowDateTime("yyyyMM"));
				
				PreminumSelVO resultPreminumSelVO = new PreminumSelVO();
				
				resultPreminumSelVO.setMetalCode(vo.getMetalCode());
				resultPreminumSelVO.setSleMthdCode(vo.getSleMthdCode());
				resultPreminumSelVO.setItmSn(vo.getItmSn());
				resultPreminumSelVO.setDstrctLclsfCode(vo.getDstrctLclsfCode());
				resultPreminumSelVO.setBrandGroupCode(vo.getBrandGroupCode());
				resultPreminumSelVO.setBrandCode(vo.getBrandCode());
				
				if(fixPriceVO != null) {
					resultPreminumSelVO.setMetalClCode(fixPriceVO.getMetalClCode());
					resultPreminumSelVO.setSleMthdCode(vo.getSleMthdCode());
					resultPreminumSelVO.setItmSn(fixPriceVO.getItmSn());
					resultPreminumSelVO.setDstrctLclsfCode(vo.getDstrctLclsfCode());
					resultPreminumSelVO.setBrandGroupCode(vo.getBrandGroupCode());
					resultPreminumSelVO.setBrandCode(vo.getBrandCode());
					resultPreminumSelVO.setDstrctLclsfNm(vo.getDstrctLclsfNm());
					resultPreminumSelVO.setBrandGroupNm(vo.getBrandGroupNm());
					resultPreminumSelVO.setHghnetprcSleAmount(fixPriceVO.getSlePc().longValue());
					resultPreminumSelVO.setEndPc(fixPriceVO.getSlePc().longValue());
				}
				
				lisVo.add(resultPreminumSelVO);
			}
		}

		return lisVo;
	}


	@Override
	public void deleteOrderBasket(ItemPriceSelectVO itemPriceSelectVO) {
		itemPriceMapper.deleteOrderBasket(itemPriceSelectVO);
	}
	

	@Override
	public void deleteOlderOrderBasket(ItemPriceSelectVO itemPriceSelectVo) {
		itemPriceMapper.deleteOlderOrderBasket(itemPriceSelectVo);
	}

	/**
	 * <pre>
	 * 처리내용: SubName의 '@'으로 되어있는 이름을 지운다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param Map<String, String>
	 * @return Map<String, String>
	 */
	@Override
	public Map<String, String> getCodeListAfterRemoveSubName(Map<String, String> codeList) throws Exception {
		codeList.remove("@");
		return codeList;
	}


	/**
	 * <pre>
	 * 처리내용: 실시간 현재 재고를 파악한다.
	 * </pre>
	 * @date 2022. 03. 30.
	 * @author heehoonc
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 03. 30.		heehoonc		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 */
	@Override
	public BigDecimal selectRealStock(ItemPriceSelectVO itemPriceSelectVo) {
		return itemPriceMapper.selectRealStock(itemPriceSelectVo);
	}
	
	@Override
	public List<BrandCodeVO> selectRealStockBrandList(ItemPriceSelectVO itemPriceSelectVo) {
		return itemPriceMapper.selectRealStockBrandList(itemPriceSelectVo);
	}
	
	@Override
	public List<BrandCodeVO> selectRealStockRemainList(ItemPriceSelectVO itemPriceSelectVo) {
		return itemPriceMapper.selectRealStockRemainList(itemPriceSelectVo);
	}
	
	/**
	 * <pre>
	 * 처리내용: 실시간 현재 재고를 파악한다.(브랜드무관일때 브랜드별 실시간재고)
	 * </pre>
	 * @date 2023. 03. 31.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 03. 31.	    srec0067		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 */
	@Override
	public BigDecimal selectRealStockByBrandCodeIrrelevant(ItemPriceSelectVO itemPriceSelectVo) {
		return itemPriceMapper.selectRealStockByBrandCodeIrrelevant(itemPriceSelectVo);
	}

	/**
	 *  소량구매 실시간 현재 재고를 파악한다.
	 */
	@Override
	public List<BrandCodeVO> selectRealStockSmlqyPurchsList(ItemPriceSelectVO itemPriceSelectVo) {
		return itemPriceMapper.selectRealStockSmlqyPurchsList(itemPriceSelectVo);
	}
	
	/**
	 * <pre>
	 * 처리내용: 실시간 현재 재고를 최소중량 계수를 파악한다.
	 * </pre>
	 * @date 2022. 05. 04.
	 * @author heehoonc
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 03. 30.		heehoonc		최초작성
	 * 2023. 08. 11			jdrttl		 	리턴값 VO로 변경
	 * -------------------------------------------------------------------------
	 * </pre>
	 */
	@Override
	public ItemPriceSelectVO selectItmInfoBas(ItemPriceSelectVO itemPriceSelectVo) {
		return itemPriceMapper.selectItmInfoBas(itemPriceSelectVo);
	}

	/**
	 * <pre>
	 * 처리내용: 브랜드 그룹에 맞는 B/L 과 성적서다운로드정보를 가져온다.
	 * </pre>
	 * @date 2022. 7. 29.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 29.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<Map<String, Object>> selectScreofeList(List<String> blNoList) throws Exception {
		return itemPriceMapper.selectScreofeList(blNoList);
	}

	/**
	 * <pre>
	 * 처리내용: 한국 공휴일을 가져온다.
	 * </pre>
	 * @date 2022. 10. 13.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 13.		hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param 
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<String> selectKoreaWeekendList() throws Exception {
		
		List<MaterialCalenderVO> koreaWeekendList = itemPriceMapper.selectKoreaWeekendList();
		List<String> eventSourcesList = new ArrayList<String>();
		
		for(int i = 0 ; i < koreaWeekendList.size(); i++) {
			if(koreaWeekendList.get(i).getApplcBeginDe().equals(koreaWeekendList.get(i).getApplcEndDe())) {
				// 시작일과 종료일이 같으면 시작일만
				if(!eventSourcesList.contains(koreaWeekendList.get(i).getApplcBeginDe())) {
					eventSourcesList.add(koreaWeekendList.get(i).getApplcBeginDe());
				}
			} else {
				DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

				Date d1 = df.parse( koreaWeekendList.get(i).getApplcBeginDe() );
				Date d2 = df.parse( koreaWeekendList.get(i).getApplcEndDe() );

				Calendar c1 = Calendar.getInstance();
				Calendar c2 = Calendar.getInstance();

				//Calendar 타입으로 변경 add()메소드로 1일씩 추가해 주기위해 변경
				c1.setTime( d1 );
				c2.setTime( d2 );

				//시작날짜가 끝날짜보다 작은 경우 리스트에 추가 
				while( c1.compareTo( c2 ) !=1 ){
					if(!eventSourcesList.contains(df.format(c1.getTime()))) {
						eventSourcesList.add(df.format(c1.getTime()));
					}
				    
				    //시작날짜 + 1 일
				    c1.add(Calendar.DATE, 1);
			    }
			}
		}
		
		return eventSourcesList;
	}
	
	@Override
	public JSONArray selectStockInfoList(ItemPriceSelectVO itemPriceSelectVo) throws Exception {
		List<StockInfoVO> stockInfoList = itemPriceMapper.selectStockInfoList(itemPriceSelectVo);
		JSONArray calendarSourcesList = new JSONArray();
		
		for (int i = 0; i < stockInfoList.size(); i++) {
			JSONObject calendarData = new JSONObject();
			
			// 캘린더 데이터
			calendarData.put("title"	, stockInfoList.get(i).getStockInfoNm());	//이벤트명
			calendarData.put("start"	, stockInfoList.get(i).getSlePossde());		//이벤트 시작일시
			
			calendarSourcesList.put(calendarData);
		}//end for()
		
		return calendarSourcesList;
	}
	
	/**
	 * <pre>
	 * 처리내용: 
	 * </pre>
	 * @date 2022. 11. 23.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 23.		srec0067				최초작성
	 * ------------------------------------------------
	 * @param 
	 * @return
	 * @throws Exception
	 */
	
	@Override
	public ItemPriceMatchingSelectVO getItemPriceCompare(ItemPriceSelectVO itemPriceSelectVo, boolean isJustBuyProcess) throws Exception {
	
	    ItemPriceMatchingSelectVO itemPriceMatchingSelectVO = initItemPriceData(itemPriceSelectVo,isJustBuyProcess);

		log.warn(">> getBlList orderModel.getEntrpsNo() : " + itemPriceSelectVo.getEntrpsNo());
		log.warn(">> getBevlList ItemPriceMatchingSelectVO : " + String.valueOf(itemPriceMatchingSelectVO));
		
		if("20".equals(itemPriceSelectVo.getBlRemain())){
			itemPriceMatchingSelectVO.setBlNo(itemPriceSelectVo.getBlNo());
		}	

		int weightUnit = itemPriceMatchingSelectVO.getSleUnitWt(); // 판매 단위 중량
		int onceSlePossWt = itemPriceMatchingSelectVO.getOnceSlePossWt(); // 1회 판매 가능 중량

		List<ItemPriceMatchingBlInfoVO> returnList = new ArrayList<>();
		
		if(onceSlePossWt > 0 && weightUnit > 0) {
			for(int i=onceSlePossWt; i>=weightUnit; i-=weightUnit) {
			    BigDecimal biggestWt = new BigDecimal(i);
			    itemPriceMatchingSelectVO.setOrderWeight(biggestWt);

		    //if(biggestWt != BigDecimal.valueOf(onceSlePossWt)) {
		    	//log.warn("!!!returnList---------------------------!!!!!!!!!!!!!!!!!!!!!!!!!!! biggestWt = " + biggestWt);
		    	//log.warn("!!!returnList---------------------------!!!!!!!!!!!!!!!!!!!!!!!!!!! onceSlePossWt = " + onceSlePossWt);
		    //	throw new Exception("아이템 설정이 제대로 되지 않았습니다.");
		    //}
			    itemPriceMatchingSelectVO.setSellMethodCode(itemPriceSelectVo.getSleMthdCode());
			    itemPriceMatchingSelectVO.setLeftOverWtRetrunBlEmptyYn("N");
			    returnList =  itemPriceMatchingService.itemBLWithMatchingList(itemPriceMatchingSelectVO, weightUnit, onceSlePossWt, 4, weightUnit);

			    if (returnList.size() != 0) {
			    	int blOrderWeight = 0;
			    	
			    	if(!itemPriceSelectVo.getBrandCode().equals("0000000000")) {
				    	for(ItemPriceMatchingBlInfoVO itemPriceMatchingBlInfoVO : returnList) {
				    		blOrderWeight += itemPriceMatchingBlInfoVO.getSleInvntryUnsleBundleBnt();
				    	}
			    	} else {
			    		List<String> brandCodeList = new ArrayList<>();
						List<BrandCodeVO> brandCodeVoList = brandCodeService.getBrandCodeList(itemPriceSelectVo.getBrandGroupCode(), userInfoUtil.getEntripsNo(), true);

						for (BrandCodeVO brandCodeVo : brandCodeVoList) {
							brandCodeList.add(brandCodeVo.getSubCode());
						}

						itemPriceMatchingSelectVO.setBrandCodeList(brandCodeList);
						
			    		List<ItemPriceMatchingBlInfoVO> itemBlByBrandList =itemPriceMatchingMapper.selectListItemBlByBrand(itemPriceMatchingSelectVO);
		    			
		    			for(ItemPriceMatchingBlInfoVO itemBlByBrand : itemBlByBrandList) {
		    				if(itemBlByBrand.getSumSleInvntryUnsleBundleBnt().intValue() > blOrderWeight) {
		    					blOrderWeight = itemBlByBrand.getSumSleInvntryUnsleBundleBnt().intValue();
		    				}
		    			}
			    	}
			    	
			    	//최적 BL에서 단건을 내려줬을 경우 중량버튼수량과 매칭 될 때까지 컨티뉴
			    	if( returnList.size() == 1 ) {
			    		if(!returnList.get(0).getMatchedOrderedBnt().equals(biggestWt)) {
			    			continue;
			    		}
			    	}

			    	if (blOrderWeight < biggestWt.intValue()) {
			    		itemPriceMatchingSelectVO.setOrderWeight(biggestWt);
			    	} else {
			    		itemPriceMatchingSelectVO.setOrderWeight(new BigDecimal(blOrderWeight));
			    	}
			    	break;
			    } else {
					BigDecimal wt = new BigDecimal(weightUnit);
					itemPriceMatchingSelectVO.setOrderWeight(biggestWt.subtract(wt));
					continue;
			    }
			}
		} else {
			onceSlePossWt = "01".equals(itemPriceSelectVo.getSleMthdCode()) ? itemPriceSelectVo.getOnceSlePossWt() : itemPriceSelectVo.getSleUnitWt();
			BigDecimal biggestWt = new BigDecimal(onceSlePossWt);
			itemPriceMatchingSelectVO.setOrderWeight(biggestWt);
	    }
		
		return itemPriceMatchingSelectVO;
	}
	
	public ItemPriceMatchingSelectVO initItemPriceData(ItemPriceSelectVO itemPriceSelectVo, boolean isJustBuyProcess) throws Exception {
		
	    ItemPriceMatchingSelectVO itemPriceMatchingSelectVo = new ItemPriceMatchingSelectVO();
	    ItemPriceSelectVO returnItemPriceSelectVo = selectOrderBasketList(itemPriceSelectVo).get(0);
		
	    if(isJustBuyProcess) {
			deleteOrderBasket(returnItemPriceSelectVo);
			returnItemPriceSelectVo.setJustBuy(null);
	    }

	    //브랜드 무관일 경우
	    if(itemPriceSelectVo.getBrandCode().equals("0000000000")) {
			List<String> brandCodeList = new ArrayList<>();
			List<BrandCodeVO> brandCodeVoList = brandCodeService.getBrandCodeList(itemPriceSelectVo.getBrandGroupCode(), userInfoUtil.getEntripsNo(), true);
	
			for(BrandCodeVO brandCodeVo : brandCodeVoList) {
			    brandCodeList.add(brandCodeVo.getSubCode());
			}

			itemPriceSelectVo.setBrandCodeList(brandCodeList);
	    }
	    
	    itemPriceMatchingSelectVo.setOrderWeight(returnItemPriceSelectVo.getOrderWeight());
	    itemPriceMatchingSelectVo.setDistrictLargeCode(returnItemPriceSelectVo.getDstrctLclsfCode());
	    itemPriceMatchingSelectVo.setMetalCode(returnItemPriceSelectVo.getMetalCode());
	    itemPriceMatchingSelectVo.setItemSn(returnItemPriceSelectVo.getItmSn());
	    itemPriceMatchingSelectVo.setBrandGroupCode(itemPriceSelectVo.getBrandGroupCode());
	    itemPriceMatchingSelectVo.setBrandCode(itemPriceSelectVo.getBrandCode());
	    itemPriceMatchingSelectVo.setBrandCodeList(itemPriceSelectVo.getBrandCodeList());
	    itemPriceMatchingSelectVo.setEnterpriseNo(userInfoUtil.getEntripsNo());

	    Account account = userInfoUtil.getAccountInfo();
	 
	    // SPARROW 372671: NULL-CHECK
 		if (account == null) {
         	throw new NullPointerException("NULL EXCEPTION: Account Info is NULL");
         } else {
			HashMap<String, String> resultMap = getOrderWeightLimit(account, itemPriceSelectVo, false);
			itemPriceMatchingSelectVo.setSleUnitWt(Integer.parseInt(resultMap.get("sleUnitWt"))); // 판매 단위 중량 kg -> MT로 변환
			itemPriceMatchingSelectVo.setOnceSlePossWt(Integer.parseInt(resultMap.get("onceSlePossWt"))); // 1회 판매 가능 중량 kg -> MT로 변환
			itemPriceMatchingSelectVo.setMxmmPurchsPossWt(Integer.parseInt(resultMap.get("mxmmPurchsPossWt"))); // 최대 구매 가능 중량 kg -> MT로 변환
         }
	    
	    return itemPriceMatchingSelectVo;
	}
	
	public HashMap<String, String> getOrderWeightLimit(Account account, ItemPriceSelectVO itemPriceSelectVo, boolean checkYn) throws Exception {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		
		// 구매중량한도조회
		String entrpsNo = account.getEntrpsNo();
		String metalCode = itemPriceSelectVo.getMetalCode();
		BigDecimal orderWeight = itemPriceSelectVo.getOrderWeight();
		OrderModel orderModel = new OrderModel();
		int itmSn = itemPriceSelectVo.getItmSn();
	
		try {
			orderModel.setTodayTotRealOrderWtCnd("item"); // 업체별 메탈코드별 조건을 넣기 위함
			orderModel.setMetalCode(metalCode);
			orderModel.setItmSn(itmSn);
			
			//주문가능 잔여중량
			BigDecimal leftOrderWt = BigDecimal.ZERO;
			
			// [상품별 하루 총 실제 주문 중량] 또는 [업체 단위 메탈코드별 하루 총 실제 주문 중량] 또는 [업체 단위 케이지크레딧 하루 총 실제 주문 중량] 가져오기
			int getTotRealOrderWtByItm = orderMapper.getTotRealOrderWt(orderModel);
			
			ItemDtlInfoVO sleWtInfo = Optional.ofNullable(orderMapper.getSleWtInfo(itmSn)).orElseThrow(() -> {
				log.info("ItemPriceServiceImpl getOrderWeightLimit line-657 vo.toString() >> " + itemPriceSelectVo.toString());
				return new CommCustomException("해당 상품_아이템 정보가 없습니다.");});
			
			BigDecimal sleUnitWt = Optional.ofNullable(sleWtInfo.getSleUnitWt()).orElse(BigDecimal.ZERO); // 판매 단위 중량
			if(sleUnitWt.compareTo(BigDecimal.ZERO) == 0) {
				log.info("ItemPriceServiceImpl getOrderWeightLimit line-662 vo.toString() >> " + itemPriceSelectVo.toString());
				throw new CommCustomException("판매 단위 중량이 null이거나 0입니다.");
			}
			
			//최대 판매 가능 중량(상품별)
			BigDecimal mxmmPurchsPossWt = Optional.ofNullable(sleWtInfo.getMxmmPurchsPossWt()).orElse(BigDecimal.ZERO);
			if(mxmmPurchsPossWt.compareTo(BigDecimal.ZERO) == 0) {
				log.info("ItemPriceServiceImpl getOrderWeightLimit line-672 vo.toString() >> " + itemPriceSelectVo.toString());
				throw new CommCustomException("최대 구매 가능 중량(상품별)이 null이거나 0입니다.");
			}
			
			//1회 판매 가능 중량(상품별)
			BigDecimal onceSlePossWt = Optional.ofNullable(sleWtInfo.getOnceSlePossWt()).orElse(BigDecimal.ZERO);
			if(onceSlePossWt.compareTo(BigDecimal.ZERO) == 0) {
				log.info("ItemPriceServiceImpl getOrderWeightLimit line-667 vo.toString() >> " + itemPriceSelectVo.toString());
				throw new CommCustomException("1회 판매 가능 중량(상품별)이 null이거나 0입니다.");
			}
			
			if(checkYn) {
				//1회 구매 중량 한도 체크
				if(onceSlePossWt.compareTo(orderWeight) < 0) {
					resultMap.put("type", "itemOnce");
					return resultMap;
				}
				
				List<EntrpsGradeVO> entrpsGradeBnefInfoList = entrpsGradeService.getEntrpsGradeBnefInfoList(entrpsNo);
				//1일 구매 중량 한도 체크
				if(mxmmPurchsPossWt.compareTo(new BigDecimal(getTotRealOrderWtByItm).add(orderWeight)) < 0) {
					resultMap.put("type", "itemOnede");
					return resultMap;
				}
				
				if(onceSlePossWt.compareTo(BigDecimal.ZERO) > 0) {
					leftOrderWt =  mxmmPurchsPossWt;
				}
				
				if(mxmmPurchsPossWt.compareTo(new BigDecimal(getTotRealOrderWtByItm)) < 0) {
					leftOrderWt = leftOrderWt.compareTo(mxmmPurchsPossWt) < -1 ? mxmmPurchsPossWt : leftOrderWt;
				}
				
				if(entrpsGradeBnefInfoList.size() > 0) {	
					BigDecimal oncePurchsWtLmt = Optional.ofNullable(new BigDecimal(entrpsGradeBnefInfoList.get(0).getOncePurchsWtLmt())).orElse(BigDecimal.ZERO);
					
					//1회 구매 중량 한도 체크
					if(oncePurchsWtLmt.compareTo(orderWeight) < 0) {
						resultMap.put("type", "entrpsOnce");
						return resultMap;
					}
					
					BigDecimal onedePurchsWtLmt = Optional.ofNullable(new BigDecimal(entrpsGradeBnefInfoList.get(0).getOnedePurchsWtLmt())).orElse(BigDecimal.ZERO);
					
					orderModel.setTodayTotRealOrderWtCnd("entrpsMetal"); // 업체별 메탈코드별 조건을 넣기 위함
					orderModel.setMetalCode(metalCode);
					orderModel.setEntrpsNo(entrpsNo);				
					int getTotCstmrOrderWtByEntrps = orderMapper.getTotRealOrderWt(orderModel);
					
					//1일 구매 중량 한도 체크
					if(onedePurchsWtLmt.compareTo(new BigDecimal(getTotCstmrOrderWtByEntrps).add(orderWeight)) < 0) {
						resultMap.put("type", "entrpsOnede");
						return resultMap;
					}
					
					if(oncePurchsWtLmt.compareTo(BigDecimal.ZERO) > 0) {
						leftOrderWt = leftOrderWt.compareTo(oncePurchsWtLmt) < -1 ? oncePurchsWtLmt : leftOrderWt;
					}
					
					if(onedePurchsWtLmt.compareTo(new BigDecimal(getTotCstmrOrderWtByEntrps)) > 0) {
						leftOrderWt =  leftOrderWt.compareTo(onedePurchsWtLmt) < -1 ? onedePurchsWtLmt : leftOrderWt;
					}
				}

				resultMap.put("leftOrderWt", String.valueOf(leftOrderWt.intValue() / 1000));
			} else  {
				resultMap.put("sleUnitWt", String.valueOf(sleUnitWt.intValue() / 1000));
				resultMap.put("onceSlePossWt", String.valueOf(onceSlePossWt.intValue() / 1000));
				resultMap.put("mxmmPurchsPossWt", String.valueOf(mxmmPurchsPossWt.intValue() / 1000));
			}
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		}
		
		resultMap.put("type", "collect");
		return resultMap;
	}
	
	/**
	 * <pre>
	 * 처리내용: 해당 BL 이 선택값과 맞는지 체크
	 * </pre>
	 * @date 2022. 12. 1.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 1.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 * @throws Exception
	 */
	public boolean isSelectItemBL(ItemPriceSelectVO itemPriceSelectVo) throws Exception {
		boolean isBoolBl = false; 
		//int isBl = itemPriceMapper.selectMinToleranceRate(itemPriceSelectVo);
		int isBl = itemPriceMapper.isSelectItemBL(itemPriceSelectVo);
		log.debug(">> [ItemPriceServiceImpl][isSelectItemBL] isBoolBl : " + isBoolBl);
		if(isBl > 0) {
			isBoolBl = true;
		}
		
		return isBoolBl;
	}

	@Override
	public BigDecimal selectBlinfoBas(ItemPriceSelectVO itemPriceSelectVo) throws Exception {
		return itemPriceMapper.selectBlinfoBas(itemPriceSelectVo);
	}
	
	/**
	 * <pre>
	 * 업체번호별 1회 최대 주문 가능 중량을 조회한다.
	 * </pre>
	 * @date 2023. 2. 28.
	 * @author srec0077
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 2. 28.		  srec0077				최초작성
	 * ------------------------------------------------
	 */
	@Override
	public int selectMxmmOrderWt(ItemPriceSelectVO itemPriceSelectVo) {
		return itemPriceMapper.selectMxmmOrderWt(itemPriceSelectVo);
	}

	@Override
	public List<OrderReceiptVO> selectBrandChangeAmountList(ItemPriceSelectVO itemPriceSelectVo) {
		return itemPriceMapper.selectBrandChangeAmountList(itemPriceSelectVo);
	}
	
	@Override
	public List<OrderReceiptVO> selectLiveOrderList(ItemPriceSelectVO itemPriceSelectVo) {
		return itemPriceMapper.selectLiveOrderList(itemPriceSelectVo);
	}
	
	@Override
	public String getOrderPreEndPc(ItemPriceSelectVO itemPriceSelectVo) {
		return Optional.ofNullable(itemPriceMapper.getOrderPreEndPc(itemPriceSelectVo.getMetalCode(),
				itemPriceSelectVo.getDstrctLclsfCode(), itemPriceSelectVo.getItmSn(), itemPriceSelectVo.getBrandGroupCode(), itemPriceSelectVo.getBrandCode())).orElse("0");
	}
	
	@Override
	public Map<String, Object> selectLimitOrderData(ItemPriceSelectVO itemPriceSelectVo) {
		List<LimitOrderModel> limitOrderList = itemPriceMapper.selectLimitOrderList(itemPriceSelectVo);
		
		// 조건을 만족하는 지정가 주문의 총 갯수
		int limitOrderTotalCnt = limitOrderList.size();
		
		// 지정가 입력 금액을 기준으로 Key 값을 가지는 Map 형태로 변경후 return
		// Key값으로 역순 정렬을 위해 TreeMap 사용
		Map<Long, List<LimitOrderModel>> limitOrderListMap = limitOrderList.stream()
			.collect(Collectors.groupingBy(LimitOrderModel::getLimitInputAmount, () -> new TreeMap<>(Comparator.reverseOrder()), Collectors.toList()));
		
		Map<String, Object> result = new HashMap<>();
		
		result.put("limitOrderTotalCnt", limitOrderTotalCnt);
		result.put("limitOrderListMap", limitOrderListMap);
		
		return result;
	}

	@Override
	public long getBrandChangeAmount(ItemPriceSelectVO itemPriceSelectVo) throws Exception {
		long brandChangeAmount = 0;
		
		List<PreminumSelVO> retunPreminumSelVoList = getFnPreminumInfo(itemPriceSelectVo);
		
		if(!retunPreminumSelVoList.isEmpty()) {
			brandChangeAmount = retunPreminumSelVoList.get(0).getBrandChangeAmount();
		}
		
		return brandChangeAmount;
	}

	@Override
	public Map<String, Object> getLimitOrderPossAt(ItemPriceSelectVO itemPriceSelectVo) throws Exception {
		Map<String, Object> returnMap = new HashMap<>();
		boolean limitOrderPossAt = true;		// 지정가 주문 가능 여부
		String reason = "";						// 지정가 주문 불가능 사유
		String csTelNo = commonCodeService.getSubCodesRetVo("SORIN_SETUP_CODE", "CS_TEL").get("CS_TEL").getCodeDcone();

		if(!itemPriceMapper.getAppnPcAt(itemPriceSelectVo)) {
			// 해당 업체의 현재 구매하고자 하는 금속의 지정가 주문 가능 여부가 'N'일 시
			limitOrderPossAt = false;
			reason = "회원님은 지정가로 주문하실 수 없습니다.<br><br>문의 사항은 고객센터("+csTelNo+")로 연락 주시기 바랍니다.";
		} else if(!StringUtils.equals(itemPriceSelectVo.getSmlqyPurchsAt(), "Y") && StringUtils.isNotBlank(itemPriceSelectVo.getBlNo())) {
			// 해당 BL이 "상품 검색" 화면에서 선택한 지정 BL일 시 (지정 BL로 선택해서 들어오면 blNo가 있음) - 소량구매일 경우 제외
			limitOrderPossAt = false;
			reason = "해당 상품은 지정가로 주문하실 수 없습니다.<br><br>문의 사항은 고객센터("+csTelNo+")로 연락 주시기 바랍니다.";
		} else if(!itemPriceMapper.getOrderLimitCheck(itemPriceSelectVo.getEntrpsNo())) {
			// 당일 지정가 주문 제한 횟수 초과 시
			limitOrderPossAt = false;
			reason = "당일 지정가 주문 횟수가 초과 되었습니다.<br><br>문의 사항은 고객센터("+csTelNo+")로 연락 주시기 바랍니다.";
		}

		returnMap.put("limitOrderPossAt", limitOrderPossAt);
		returnMap.put("reason", reason);

		return returnMap;
	}
	

	@Override
	public String selectSalesTime() throws Exception {

		String rltmTime = itemPriceMapper.selectSalesTime();	//영업시간 데이터 조회

		return rltmTime;
	}
	

	@Override
	public MbEntrpsGradVO getDscntAmount(MbEntrpsGradVO mbEntrpsGradVO) throws Exception {
//		List<MbEntrpsGradVO> mbEntrpsGradList = new ArrayList<MbEntrpsGradVO>();
		MbEntrpsGradVO vo = new MbEntrpsGradVO();
		
		try {
//			mbEntrpsGradList = itemPriceMapper.getDscntAmount(mbEntrpsGradVO);
			vo = itemPriceMapper.getDscntAmount(mbEntrpsGradVO);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return vo;
	}

	@Override
	public String getMinLimitOrderNightTime(String metalCode, String nowDate, int maxNextCnt) throws Exception {
		
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMdd");		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String minDate = "";
		
		try {
			Calendar todayCalendar = Calendar.getInstance();
			
			todayCalendar.setTime(sdf2.parse(nowDate));

			List<String> koreaWeekendList = this.selectKoreaWeekendList();
			
			List<BsnManageLgistDateVO> bsnManageLgistDateList = itemPriceMapper.selectBsnManageLgistDate();
			
			int nextCnt = 0;
			int loopCnt = Math.abs(maxNextCnt);
			
			while (true) {

				if (nextCnt == loopCnt) {
					break;
				}

				if(maxNextCnt < 0) {
					todayCalendar.add(Calendar.DATE, -1); // 기준일 이전 영업일
				} else {
					todayCalendar.add(Calendar.DATE, 1);
				}

				minDate = sdf.format(todayCalendar.getTime());

				int dayNum = todayCalendar.get(Calendar.DAY_OF_WEEK);

				Optional<BsnManageLgistDateVO> lgist = bsnManageLgistDateList
												.stream()
												.filter(bsnManageLgistDate -> bsnManageLgistDate.getDayInt() == dayNum)
												.findFirst();

				if (lgist.isPresent()) {
					BsnManageLgistDateVO b = lgist.get();
					if ("N".equals(b.getDayYn())) {
						continue;
					}
				}
				
				/*
				 * if (dayNum == 1 || dayNum == 7) { continue; }
				 */
				
				if (koreaWeekendList.contains(minDate)) {
					continue;
				}
				nextCnt++;
			}
			
		} catch (Exception e) {
			log.error("getMinLimitOrderNightTime error",e);
		}
		
		return minDate;
	}
}
