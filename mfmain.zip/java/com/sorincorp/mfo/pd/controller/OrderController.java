package com.sorincorp.mfo.pd.controller;

import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sorincorp.comm.bsnInfo.model.RltmEndTimeVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.comm.order.service.CommOrderService;
import com.sorincorp.comm.validation.CustomValidator;
import com.sorincorp.mfo.pd.comm.constant.PdCommConstant;
import com.sorincorp.mfo.pd.comm.entity.PdErrorResponseEntity;
import com.sorincorp.mfo.pd.comm.entity.PdResponseEntity;
import com.sorincorp.mfo.pd.comm.exception.CustomEmptyLoginUserException;
import com.sorincorp.mfo.pd.model.LimitOrderModel;
import com.sorincorp.mfo.pd.model.OrderEtcPrice;
import com.sorincorp.mfo.pd.model.SettleSttusDeVO;
import com.sorincorp.mfo.pd.service.OrderService;

import lombok.extern.slf4j.Slf4j;

/**
 * OrderController.java
 * 주문 Controller 클래스
 * @version
 * @since 2022. 9. 21.
 * @author srec0049
 */
@Controller
@RequestMapping("/fo/pd")
@Slf4j
public class OrderController {

	@Autowired
	private OrderService orderService;
	
	@Autowired
	private CommOrderService commOrderService;

	@Autowired
	private CustomValidator customValidator;

	@Autowired
	private BsnInfoService bsnInfoService;

	/**
	 * <pre>
	 * 처리내용: 현재 로그인한 유저의 계좌 번호로 EWALLET 잔액 조회 ( EC DB )
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/ewallet")
	public ResponseEntity<?> getEwalletMoney(HttpServletRequest request, OrderModel orderModel) throws Exception {
		OrderEtcPrice getEwalletInfo = orderService.getEwalletInfo(orderModel);
		return ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, getEwalletInfo));
	}

	/**
	 * <pre>
	 * 처리내용: (전자상거래보증 or 케이지크레딧) 한도조회 가져오기
	 *  MRTGG_GRNTY_LMT_STATUS(담보 보증 한도 상태)
	 *   00 : 담보 보증 한도 설정 정상
	 *   01 : 담보 보증 한도가 설정되어 있지 않음
	 *   02 : 담보 보증 한도가 설정되어 있으나 사용 내역이 없음
	 *   99 : 기타 상황
	 *   EMPTY : 업체 정보가 존재하지 않음
	 * </pre>
	 * @date 2022. 6. 30.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 30.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/mrtggGrntyLmtInqire")
	public ResponseEntity<?> getMrtggGrntyLmtInqire(HttpServletRequest request, OrderModel orderModel) throws Exception {
		OrderEtcPrice getMrtggGrntyLmtInqire = orderService.getMrtggGrntyLmtInqire(orderModel);
		log.warn("control getMrtggGrntyLmtInqire : " + String.valueOf(getMrtggGrntyLmtInqire));
		return ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, getMrtggGrntyLmtInqire));
	}

	/**
	 * <pre>
	 * 처리내용: 배송비 조회
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/dlvyPrice")
	public ResponseEntity<?> getEtcPrice(HttpServletRequest request, OrderModel orderModel) throws Exception{
		return ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, orderService.getDlvyPrice(orderModel)));
	}


	/**
	 * <pre>
	 * 처리내용: 쿠폰 할인 가격 조회
	 * </pre>
	 * @date 2022. 8. 16.
	 * @author jhcha
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 16.			jhcha			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/getDiscntCouponPrice")
	public ResponseEntity<?> getDiscntCouponPrice(HttpServletRequest request, OrderModel orderModel) throws Exception{
		return ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, orderService.getDiscntCouponPrice(orderModel)));
	}

	/**
	 * <pre>
	 * 처리내용: 중량 변동 가져오기
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 1. 14.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/getWtChange")
	public ResponseEntity<?> getWtChange(HttpServletRequest request, OrderModel orderModel) throws Exception{
		return ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, commOrderService.getWtChange(orderModel)));
	}

	/**
	 * <pre>
	 * 처리내용: (판매 방식 코드 , 배송 수단 코드, 금속 코드) 조건에 의한 현재 시각, 당일배송 불가능 상태 및 당일배송 종료 시간을 맵으로 가져온다.
	 * </pre>
	 * @date 2022. 3. 10.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 3. 10.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/getSameDayDeliveryInfo")
	public ResponseEntity<?> getSameDayDeliveryInfo(HttpServletRequest request, OrderModel orderModel) throws Exception{
		return ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, orderService.getSameDayDeliveryInfo(orderModel)));
	}

	/**
	 * <pre>
	 * 처리내용: 주문을 진행한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param orderModel
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/order")
	public ResponseEntity<?> doOrder(HttpServletRequest request, @RequestBody @Valid OrderModel orderModel, BindingResult bindingResult) throws Exception{

		customValidator.validate(orderModel, bindingResult);

		if(bindingResult.hasErrors()) {
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(this.customGetBindingResultError(bindingResult.getAllErrors(), new Object(){}.getClass()));
		}

		String getDomain = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort();
		log.debug(">> doOrder getDomain : " + getDomain);
		orderModel.setDomain(getDomain);

		orderService.doOrder(orderModel);
		return ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, orderModel.getOrderNo()));
	}

	/**
	 * <pre>
	 * 처리내용: 구매 완료 후 매매계약서 페이지로 진입한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.		srec0043		최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param model
	 * @param orderNo
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/receipt/{orderNo}")
	public String selectReceipt(HttpServletRequest request, Model model, @PathVariable("orderNo") String orderNo, OrderModel orderModel) throws Exception{
		orderModel.setOrderNo(orderNo);
		//운영 종료 시간(지정가 야간장 시간)
		RltmEndTimeVO rltmEndTimeVO = bsnInfoService.getRltmEndTime();
		model.addAttribute("rltmEndTimeVO", rltmEndTimeVO);
		model.addAttribute("orderReceipt", orderService.selectOrderReceipt(orderModel));
		return "pd/orderReceipt";
	}

	/**
	 * <pre>
	 * 처리내용: 직인 정보를 조회한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@GetMapping("/sorinSign")
	public void getSorinSign(HttpServletRequest request, HttpServletResponse response) throws Exception{
		orderService.getSorinSign(response);
	}

	

	/**
	 * <pre>
	 * 처리내용: 지정가 주문을 진행한다.
	 * </pre>
	 * @date 2023. 4. 28.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 28.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param limitOrderModel
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/limitOrder")
	public ResponseEntity<?> doLimitOrder(HttpServletRequest request, @RequestBody @Valid LimitOrderModel limitOrderModel, BindingResult bindingResult) throws Exception{

		customValidator.validate(limitOrderModel, bindingResult);

		if(bindingResult.hasErrors()) {
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(this.customGetBindingResultError(bindingResult.getAllErrors(), new Object(){}.getClass()));
		}

		String getDomain = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort();
		log.debug(">> doLimitOrder getDomain : " + getDomain);
		limitOrderModel.setDomain(getDomain);

		orderService.doLimitOrder(limitOrderModel);
		return ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, limitOrderModel.getLimitOrderNo()));
	}

	/**
	 * <pre>
	 * 처리내용: 평균가 주문용 기본 모달창을 호출한다.
	 * </pre>
	 * @date 2023. 10. 24.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 24.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/avrgpcOrderBaseModal")
	public String openAvrgpcOrderBaseModal(@RequestBody OrderModel orderModel, ModelMap model) throws Exception {

		orderService.setAvrgpcOrderBaseData(orderModel, model);

		return "pd/avrgpcOrderBaseModal";
	}

	/**
	 * <pre>
	 * 처리내용: 평균가 주문 모달창 진입후 필요한 데이터를 조회한다.
	 * </pre>
	 * @date 2023. 11. 2.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 2.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param orderModel
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/getAccmltAvrgpcList")
	public ResponseEntity<?> getAccmltAvrgpcList(HttpServletRequest request, @RequestBody OrderModel orderModel, BindingResult bindingResult) throws Exception{
		return ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, orderService.getAccmltAvrgpcList(orderModel)));
	}

	/**
	 * <pre>
	 * 처리내용: 평균가 주문을 진행한다.
	 * </pre>
	 * @date 2023. 9. 19.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 19.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param orderModel
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/avrgpcOrder")
	public ResponseEntity<?> doAvrgpcOrder(HttpServletRequest request, @RequestBody @Valid OrderModel orderModel, BindingResult bindingResult) throws Exception{

		customValidator.validate(orderModel, bindingResult);

		if(bindingResult.hasErrors()) {
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(this.customGetBindingResultError(bindingResult.getAllErrors(), new Object(){}.getClass()));
		}

		String getDomain = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort();
		log.debug(">> doAvrgpcOrder getDomain : " + getDomain);
		orderModel.setDomain(getDomain);

		orderService.doAvrgpcOrder(orderModel);
		return ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, orderModel.getOrderNo()));
	}

	/**
	 * <pre>
	 * 처리내용: 매개변수 바인딩 검증 후 에러 발생 시 에러 객체 반환 전에 로그 추가
	 * </pre>
	 * @date 2022. 8. 1.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 1.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param getAllErrors
	 * @return
	 */
	public String customGetBindingResultError(List<ObjectError> getAllErrors, Class<?> ObjectClass) {
		ObjectError customAllError = new ObjectError("undefinedError", "undefined Error");

		StringBuffer sb = new StringBuffer();

		if(ObjectClass != null && ObjectClass.getEnclosingClass() != null) {
			String getSimpleName = ObjectClass.getEnclosingClass().getSimpleName() != null ? ObjectClass.getEnclosingClass().getSimpleName() : "";

			sb.append("[").append(getSimpleName).append("]");
		}

		if(ObjectClass != null && ObjectClass.getEnclosingMethod() != null) {
			String getName = ObjectClass.getEnclosingMethod().getName() != null ? ObjectClass.getEnclosingMethod().getName() : "";

			sb.append("[").append(getName).append("]");
		}

		if(getAllErrors != null && getAllErrors.size() > 0) {
			customAllError = getAllErrors.get(0);
			String getObjectName = customAllError.getObjectName() != null ? customAllError.getObjectName() : "";
			String getCode = customAllError.getCode() != null ? customAllError.getCode() : "";
			String getDefaultMessage = customAllError.getDefaultMessage() != null ? customAllError.getDefaultMessage() : "";

			sb.append("[").append(getObjectName).append("]");
			sb.append("[").append(getCode).append("]").append(" ");
			sb.append(getDefaultMessage);
		}

		log.error(sb.toString());

		return customAllError.getDefaultMessage();
	}

	/**
	 * <pre>
	 * 처리내용: 로그인 정보없을시 Exception 처리 -> OrderAccountAop.java 에서 체크
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param ex
	 * @return
	 */
	@ExceptionHandler({ CustomEmptyLoginUserException.class })
	public ResponseEntity<?> customEmptyLoginUserException(final CustomEmptyLoginUserException ex) {
		log.error("[CustomEmptyLoginUserException][ex.getMessage()] : " + ex.getMessage());

		String stacktrace = ExceptionUtils.getStackTrace(ex);
		log.error("[CustomEmptyLoginUserException][stacktrace] : " + stacktrace);

		// TODO 메세지 PROPERTY 관리 시 변경
		String alertMsg = "로그인 정보가 없습니다.";
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.singletonList(new PdErrorResponseEntity(PdCommConstant.FAIL_RESULT_CODE, alertMsg, null)));
	}

	/**
	 * <pre>
	 * 처리내용: 주문중 에러 발생시 Exception 처리 -> 공통 script 에서 list형식의 에러를 받기 때문에 list로 호출
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param ex
	 * @return
	 */
	@ExceptionHandler({ CommCustomException.class })
	public ResponseEntity<?> commCustomException(final CommCustomException ex) {
		String alertMsg = ex.getMessage();
		log.error("[CommCustomException][ex.getMessage()] : " + alertMsg);

		if(alertMsg.indexOf(ex.getClass().getName()) > -1) {
			alertMsg = alertMsg.replace(ex.getClass().getName(), "").replace(": ", "");
		}

		String stacktrace = ExceptionUtils.getStackTrace(ex);
		log.error("[CommCustomException][stacktrace] : " + stacktrace);

		log.error("[CommCustomException][alertMsg] : " + alertMsg);

		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.singletonList(new PdErrorResponseEntity(PdCommConstant.FAIL_RESULT_CODE, alertMsg, null)));
	}

	/**
	 * <pre>
	 * 처리내용: 예기치 못한 Exception 처리
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param ex
	 * @return
	 */
	@ExceptionHandler({ Exception.class })
    public ResponseEntity<?> handleAccessDeniedException(final Exception ex) {
		String alertMsg = ex.getMessage();
		log.error("[Exception][ex.getMessage()] : " + alertMsg);

		String stacktrace = ExceptionUtils.getStackTrace(ex);
		log.error("[Exception][stacktrace] : " + stacktrace);

		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new PdErrorResponseEntity(PdCommConstant.ERROR_RESULT_CODE, PdCommConstant.ERROR_RESULT_MSG, null));
    }

	/**
	 * <pre>
	 * 처리내용: 이벤트 휴일 관리 기반 기준일에 영업 일자 만큼 계산된 날짜 리턴(기준일 포함), 리턴 대상 날짜가 휴일이면 그 다음 날짜를 리턴한다.
	 * </pre>
	 * @date 2022. 8. 1.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 1.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param settleSttusDeVO
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/getSettleSttusDe")
	public ResponseEntity<?> getSettleSttusDe(HttpServletRequest request, SettleSttusDeVO settleSttusDeVO, BindingResult bindingResult) throws Exception {

		customValidator.validate(settleSttusDeVO, bindingResult);

		if(bindingResult.hasErrors()) {
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(this.customGetBindingResultError(bindingResult.getAllErrors(), new Object(){}.getClass()));
		}

		return ResponseEntity.status(HttpStatus.OK).body(new PdResponseEntity(PdCommConstant.SUCCESS_RESULT_CODE, PdCommConstant.SUCCESS_RESULT_MSG, orderService.getSettleSttusDe(settleSttusDeVO)));
	}
}
