package com.sorincorp.mfo.chart.model;

import com.sorincorp.comm.model.CommonVO;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * PreminumSelVO.java
 * @version
 * @since 2021. 11. 15.
 * @author srec0008
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class PreminumSelVO extends CommonVO {

	private static final long serialVersionUID = 1L;

	/**
	 * 프리미엄 가격
	 */
	private long slePremiumAmount;
	/**
	 * 금속코드
	 */
	private String metalCode;
	/**
	 * 금속코드
	 */
	private String metalClCode;
	/**
	 * 아이템 코드
	 */
	private int itmSn;
	/**
	 * 프리미엄 기준 지역코드
	 */
	private String premiumStdrDstrctLclsfCode;
	/**
	 * 프리미엄 기준 브랜드 그룹 코드
	 */
	private String premiumStdrBrandGroupCode;
	/**
	 * 지역코드
	 */
	private String dstrctLclsfCode;
	/**
	 * 그룹 코드
	 */
	private String brandGroupCode;
	/**
	 * 브랜드 코드
	 */
	private String brandCode;
	/**
	 * 종가
	 */
	private long endPc;
	/**
	 * 전일자 종가
	 */
	private long agoEndPc;
	/**
	 * 대비가격
	 */
	private long versusPc;
	/**
	 * 대비 비율
	 */
	private float versusRate;
	/**
	 * 상품명
	 */
	private String goodsNm;
	/**
	 * 전시상품명
	 */
	private String dspyGoodsNm;
	/**
	 * 권역명 한글
	 */
	private String dstrctLclsfNm;
	/**
	 * 브랜드 그룹명 한글
	 */
	private String brandGroupNm;
	/**
	 * 판매방식코드
	 */
	private String sleMthdCode;
	
	/**
	 * 고정가 가격
	 */
	private long hghnetprcSleAmount;
	
	/**
	 * 브랜드 변동금
	 */
	private long brandChangeAmount;
}
