package com.sorincorp.mfo.chart.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class EntrpsMetalItmStdrVO implements Serializable {

	private static final long serialVersionUID = 3068517972366324612L;
	/**
	* 금속 코드
	*/
	private String metalCode;
	/**
	* 금속 분류 코드
	*/
	private String metalClCode;
	/**
	* 금속 코드 영문명
	*/
	private String codeDcone;
	/**
	* 금속 코드 한글명
	*/
	private String codeChrctrRefrnsix;
	/**
	* 아이탬 순번
	*/
	private int itmSn;
	/**
	* 금속코드 인덱스명
	*/
	private String codeChrctrRefrntwo;
	/**
	* 권역 코드
	*/
	private String dstrctLclsfCode;
	/**
	* 권역 이름
	*/
	private String dstrctLclsfName;
	/**
	* 브랜드 그룹 코드
	*/
	private String brandGroupCode;
	/**
	* 브랜드 그룹 이름
	*/
	private String brandGroupNm;
	/**
	* 브랜드 코드
	*/
	private String brandCode;
	/**
	 * 업체 코드
	 */
	private String entrpsNo;
	/**
	 * 멤버 코드
	 */
	private String mberId;
	/**
	* 판매방식코드
	*/
	private String sleMthdCode;
    /**
     * 삼성선물 종목코드
     */
    private String gicName;
    /**
     * 금속 기호
     */
    private String codeNm;
}
