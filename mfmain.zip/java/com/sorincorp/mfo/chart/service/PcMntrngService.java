package com.sorincorp.mfo.chart.service;

import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;

import com.sorincorp.comm.pcInfo.model.PreminumSelInfoVO;
import com.sorincorp.mfo.chart.model.EntrpsMetalItmStdrVO;
import com.sorincorp.mfo.chart.model.ItHghnetprcPurchsPrmpcDtlVO;
import com.sorincorp.mfo.chart.model.MetalInfoListVO;
import com.sorincorp.mfo.chart.model.PrLmePblntfPcBasVO;
import com.sorincorp.mfo.chart.model.PrMetalDisplayVO;
import com.sorincorp.mfo.chart.model.SelMetalVO;
import com.sorincorp.mfo.chart.model.SelPcChartVO;

public interface PcMntrngService {
	
	/**
	 * <pre>
	 * 금속 코드에 해당되는 차트 데시보드 정보를 가져온다.
	 * </pre>
	 * @date 2021. 11. 9.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 9.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> getItemChartDate(String metalCode, String sleMthdCode, String metalClCode) throws Exception;
	
	/**
	 * <pre>
	 * 특정 계정 전용 차트 화면
	 * </pre>
	 * @date 2022. 5. 10.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 10.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @param sleMthdCode
	 * @param type
	 * @return
	 * @throws Exception
	 */
	Map<String, Object> getItemChartDate(String metalCode, String sleMthdCode,String type, String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 월 기준 고정가 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 11. 1.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 1.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itHghnetprcPurchsPrmpcDtlVO
	 * @return
	 * @throws Exception
	 */
	List<ItHghnetprcPurchsPrmpcDtlVO> getItHghnetprcPurchsPrmpcDtlMonth(ItHghnetprcPurchsPrmpcDtlVO itHghnetprcPurchsPrmpcDtlVO) throws Exception;

	/**
	 * <pre>
	 * 분기 기준 고정가 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itHghnetprcPurchsPrmpcDtlVO
	 * @return
	 * @throws Exception
	 */
	List<ItHghnetprcPurchsPrmpcDtlVO> getItHghnetprcPurchsPrmpcDtlQuarter(ItHghnetprcPurchsPrmpcDtlVO itHghnetprcPurchsPrmpcDtlVO) throws Exception;
	
	/**
	 * <pre>
	 * 분기 기준 고정가 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itHghnetprcPurchsPrmpcDtlVO
	 * @return
	 * @throws Exception
	 */
	List<ItHghnetprcPurchsPrmpcDtlVO> getItHghnetprcPurchsPrmpcDtlHalfYear(ItHghnetprcPurchsPrmpcDtlVO itHghnetprcPurchsPrmpcDtlVO) throws Exception;
	
	/**
	 * <pre>
	 * 년 기준 고정가 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itHghnetprcPurchsPrmpcDtlVO
	 * @return
	 * @throws Exception
	 */
	List<ItHghnetprcPurchsPrmpcDtlVO> getItHghnetprcPurchsPrmpcDtlYear(ItHghnetprcPurchsPrmpcDtlVO itHghnetprcPurchsPrmpcDtlVO) throws Exception;
	
	/**
	 * <pre>
	 * 휴일 정보 리스트를 JSONArray 형태로 가져온다
	 * </pre>
	 * @date 2022. 4. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 4. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	JSONArray getRestdeInfoJson() throws Exception;
	
	/**
	 * <pre>
	 * 업체 메탈권한리스트를 조회한다.
	 * </pre>
	 * @date 2022. 4. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 4. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	List<SelMetalVO> getEntrpsSelMetalList(String entrpsNo, String metalCode, String metalClCode, String sleMthdCode ,String type);
	
	/**
	 * <pre>
	 * 특정 계정 전용 차트 화면
	 * </pre>
	 * @date 2023. 9. 8.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 10.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @param sleMthdCode
	 * @param metalClCode
	 * @param type
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	List<MetalInfoListVO> getLiveList(String metalCode, String sleMthdCode, String type ,String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * LME 대비가격 리스트
	 * </pre>
	 * @date 2023. 9. 8.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 9. 8.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	PrLmePblntfPcBasVO getPrLmePblntfPc(PrLmePblntfPcBasVO prLmePblntfPcBasVO)  throws Exception;
	
	/**
	 * <pre>
	 * 판매방식에 따른 금속명을 가져온다.
	 * </pre>
	 * @date 2023. 9. 8.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 9. 8.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	List<PrMetalDisplayVO> selectMetalDisplayList(PrMetalDisplayVO metalDisplayVo) throws Exception;
	
	/**
	 * <pre>
	 * 판매방식에 따른 금속명을 가져온다.
	 * </pre>
	 * @date 2023. 9. 8.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 9. 8.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	SelPcChartVO getSelPcChartList(SelPcChartVO selPcChartVO) throws Exception;
	
	/**
	 * <pre>
	 * 판매방식에 따른 금속명을 가져온다.
	 * </pre>
	 * @date 2023. 9. 26.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 9. 26.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	EntrpsMetalItmStdrVO getEntrpsMetalItmStdr(String entrpsNo) throws Exception;
	
	
	/**
	 * <pre>
	 * 메탈별 권역/브랜드그룹을 조회한다.
	 * </pre>
	 * @date 2023. 9. 26.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 9. 26.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	List<PreminumSelInfoVO> getSelMetalList(String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 로그인한 업체 기준아이템 설정를 저장한다.
	 * </pre>
	 * @date 2023. 10. 10.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 10. 10.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	int insertEntrpsMetalItmStdr(EntrpsMetalItmStdrVO entrpsMetalItmStdrVO) throws Exception;
	
	/**
	 * <pre>
	 * 로그인한 업체 기준아이템 설정을 이력에 저장한다.
	 * </pre>
	 * @date 2023. 10. 10.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 10. 10.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	int insertEntrpsMetalItmStdrHst(EntrpsMetalItmStdrVO entrpsMetalItmStdrVO) throws Exception;
}
