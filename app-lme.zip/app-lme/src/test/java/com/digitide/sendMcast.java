package com.digitide;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class sendMcast extends Thread{
	
	
	int sequence;
	public static void main(String args[]) throws Exception {
		sendMcast mCaster = new sendMcast();
		mCaster.start();
	}

	public void run() {
	
		while(true) {
			try {
				
				Random r = new Random();
				int price = 2882 + (r.nextInt(50) - r.nextInt(50));
				
				String nowPrice = price + ".00          ";
				
				sendData(nowPrice);
				sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
    public void sendData(String nowPrice){
    	try {
    		//LB
    		//String msgData = "20210917085000204430LBLCUM03                          CUM03               F2021101220211011LCULME34.7                                      32.12            35.84            30.07            20211007202110062021122820211014123018";
    		//String msgData = "20210916100051900766LCLALM03                          CMAL3               F20210916202109161000512904.00          2890.00          2904.00          2890.00          14.00     0.48      -22.00           2882.00          2868.00          2882.00          2868.00          14.00     0.49      62        1         ";
    		//LC
    		Date now = new Date();
    		SimpleDateFormat simpleDate = new SimpleDateFormat("yyyyMMddHHmmss");
    		SimpleDateFormat simpleDate_de = new SimpleDateFormat("yyyyMMdd");
    		Random r = new Random();
    		
    		String date = simpleDate.format(now) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9); 
    		
    		String msgData = date + "LCLALM03                          CMAL3               F" + simpleDate_de.format(now) + simpleDate_de.format(now) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + r.nextInt(9) + "2904.00          2890.00          2904.00          2890.00          14.00     0.48      -22.00           " + nowPrice + "2868.00          2882.00          2868.00          14.00     0.49      62        1         ";
            System.out.println(("########## Sample Chart Send DATA ###################"));
            System.out.println(("send data : "+msgData));
            
            /* Java Multicast Send Example*/
            String mcastIp = "224.10.10.80";
            int mcastPort = 9810;

            MulticastSocket socket = new MulticastSocket();

            InetAddress address = InetAddress.getByName(mcastIp);

            socket.joinGroup(address);

            DatagramPacket packet = new DatagramPacket(
            	msgData.getBytes()
               ,msgData.length()
               ,address
               ,mcastPort
            );

            socket.send(packet);
                        
		} catch (Exception e) {
			// TODO: handle exception
		}
    	
    }
}