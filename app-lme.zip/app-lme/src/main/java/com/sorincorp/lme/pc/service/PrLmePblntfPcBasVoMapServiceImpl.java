package com.sorincorp.lme.pc.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.sorincorp.lme.pc.model.PrLmePblntfPcBasVo;

@Service
public class PrLmePblntfPcBasVoMapServiceImpl implements PrLmePblntfPcBasVoMapService{
	
	private Map<String, PrLmePblntfPcBasVo> prLmePblntfPcBasVoMap;
	
	public PrLmePblntfPcBasVoMapServiceImpl() {
		if(prLmePblntfPcBasVoMap == null) {
			this.prLmePblntfPcBasVoMap = new HashMap<String, PrLmePblntfPcBasVo>();
		}
	}
	
	public PrLmePblntfPcBasVo getPrLmePblntfPcBasVo(String metalCodeByProperties) {
		
		if(!prLmePblntfPcBasVoMap.containsKey(metalCodeByProperties)) {
			prLmePblntfPcBasVoMap.put(metalCodeByProperties, new PrLmePblntfPcBasVo());
		} 
		
		return prLmePblntfPcBasVoMap.get(metalCodeByProperties);
	}
	
}