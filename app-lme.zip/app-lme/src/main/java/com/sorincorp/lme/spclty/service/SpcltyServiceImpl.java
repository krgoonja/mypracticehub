package com.sorincorp.lme.spclty.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.lme.spclty.mapper.SpcltyMapper;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLaVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLbVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLcVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLeVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLgVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLhVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLoVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLsVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLvVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyVo;

@Service
public class SpcltyServiceImpl implements SpcltyService {
	
	@Autowired
	private SpcltyMapper spcltyMapper;
			
	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertIfLmeSpclty(IfLmeSpcltyVo vo) throws Exception {
		spcltyMapper.insertIfLmeSpclty(vo);
	}
	
	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertIfLmeSpcltyLa(IfLmeSpcltyLaVo vo) throws Exception {
		spcltyMapper.insertIfLmeSpcltyLa(vo);
	}
	
	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertIfLmeSpcltyLb(IfLmeSpcltyLbVo vo) throws Exception {
		spcltyMapper.insertIfLmeSpcltyLb(vo);
	}
	
	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertIfLmeSpcltyLc(IfLmeSpcltyLcVo vo) throws Exception {
		spcltyMapper.insertIfLmeSpcltyLc(vo);
	}
	
	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertIfLmeSpcltyLe(IfLmeSpcltyLeVo vo) throws Exception {
		spcltyMapper.insertIfLmeSpcltyLe(vo);
	}
	
	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertIfLmeSpcltyLh(IfLmeSpcltyLhVo vo) throws Exception {
		spcltyMapper.insertIfLmeSpcltyLh(vo);
	}
	
	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertIfLmeSpcltyLg(IfLmeSpcltyLgVo vo) throws Exception {
		spcltyMapper.insertIfLmeSpcltyLg(vo);
	}
	
	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertIfLmeSpcltyLo(IfLmeSpcltyLoVo vo) throws Exception {
		spcltyMapper.insertIfLmeSpcltyLo(vo);
	}
	
	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertIfLmeSpcltyLs(IfLmeSpcltyLsVo vo) throws Exception {
		spcltyMapper.insertIfLmeSpcltyLs(vo);
	}
	
	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertIfLmeSpcltyLv(IfLmeSpcltyLvVo vo) throws Exception {
		spcltyMapper.insertIfLmeSpcltyLv(vo);
	}
}