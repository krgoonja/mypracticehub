package com.sorincorp.lme.pc.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.pcInfo.model.RvcmpnVO;
import com.sorincorp.lme.pc.model.OpFallNumPcBasVo;
import com.sorincorp.lme.pc.model.OpFallSelPcBasVo;
import com.sorincorp.lme.pc.model.PrLmeEvlPcBasVo;
import com.sorincorp.lme.pc.model.PrLmePblntfPcBasVo;
import com.sorincorp.lme.pc.model.PrLmePcStdrBasVo;
import com.sorincorp.lme.pc.model.SelPrimiumAmountVo;

public interface PcService {

	/**
	 * <pre>
	 * LME 기준 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePcStdrBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * LME 실시간 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePcRltmBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * LME 가격 01분 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePc01MinBas(PrLmePcStdrBasVo lmeStdrAl) throws Exception;

	/**
	 * <pre>
	 * Lme 가격 30분 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePc30MinBas(PrLmePcStdrBasVo lmeStdrAl) throws Exception;

	/**
	 * <pre>
	 * Lme 가격 60분 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePc60MinBas(PrLmePcStdrBasVo lmeStdrAl) throws Exception;

	/**
	 * <pre>
	 * LME 가격 일 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePcDeBas(PrLmePcStdrBasVo lmeStdrAl) throws Exception;

	/**
	 * <pre>
	 * LME 가격 주 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePcWeekBas(PrLmePcStdrBasVo lmeStdrAl) throws Exception;

	/**
	 * <pre>
	 * LME 가격 년 월 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePcYyMtBas(PrLmePcStdrBasVo lmeStdrAl) throws Exception;

	/**
	 * <pre>
	 * LME 가격 년 분기 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePcYyQuBas(PrLmePcStdrBasVo lmeStdrAl) throws Exception;

	/**
	 * <pre>
	 * LME 가격 년 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePcYyBas(PrLmePcStdrBasVo lmeStdrAl) throws Exception;


	/**
	 * <pre>
	 * 처리내용: 가격_LME 공시 가격 기본 저장
	 * </pre>
	 * @date 2021. 11. 2.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 2.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePblntfPcBas(PrLmePblntfPcBasVo vo) throws Exception;


	/**
	 * <pre>
	 * 처리내용: 가격_LME 평가 가격 기본 저장
	 * </pre>
	 * @date 2021. 11. 2.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 2.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 */
	void insertPrLmeEvlPcBas(PrLmeEvlPcBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePcStdrBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void selectTopPrLmePcStdrBas() throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePcRltmBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void selectTopPrLmePcRltmBas() throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePc01MinBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void selectTopPrLmePc01MinBas() throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePc30MinBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void selectTopPrLmePc30MinBas() throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePc60MinBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void selectTopPrLmePc60MinBas() throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePcDeBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void selectTopPrLmePcDeBas() throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePcWeekBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void selectTopPrLmePcWeekBas() throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePcYyMtBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void selectTopPrLmePcYyMtBas() throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePcYyQuBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void selectTopPrLmePcYyQuBas() throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePcYyBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void selectTopPrLmePcYyBas() throws Exception;


	/**
	 * <pre>
	 * 처리내용: PrLmePblntfPcBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void selectTopPrLmePblntfPcBas() throws Exception;


	/**
	 * <pre>
	 * 처리내용: PrLmeEvlPcBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void selectTopPrLmeEvlPcBas() throws Exception;

	/**
	 * <pre>
	 * 처리내용: DB정보가 없을경우 singleTon vo 초기화
	 * </pre>
	 * @date 2021. 12. 13.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 13.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param returnNowLmeStdrBasVoFromIf
	 */
	void initializePrLmePcStdrBasVo(PrLmePcStdrBasVo returnNowLmeStdrBasVoFromIf) throws Exception;

	void insertPrLmePcDeBasForProcedure(Map<String, String> map) throws Exception;

	void insertPrLmePcWeekBasForProcedure(Map<String, String> map) throws Exception;

	void insertPrLmePcYyMtBasForProcedure(Map<String, String> map) throws Exception;

	void insertPrLmePcYyQuBasForProcedure(Map<String, String> map) throws Exception;

	void insertPrLmePcYyBasForProcedure(Map<String, String> map) throws Exception;


	/**
	 * <pre>
	 * 처리내용: LME, 판매가격 데이터 중 이전 데이터 주기적 삭제 프로세스
	 * </pre>
	 * @date 2022. 03. 16.
	 * @author srec0004
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 03. 16.		srec0004		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param returnNowLmeStdrBasVoFromIf
	 */
	public void deletePrLmeSelOldDataProcedure() throws Exception;

	/**
	 * <pre>
	 * 월단위 일자별 누적평균가 현황 테이블에 데이터 저장
	 * </pre>
	 * @date 2022. 10. 31.
	 * @author hyunjin05
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 10. 31.		hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertStEvemthAccmlDalyAvgPcBas() throws Exception;

	/**
	 * <pre>
	 * 조달청 대비 가격하락 비교
	 * </pre>
	 * @date 2023. 04. 27.
	 * @author srec0068
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 04. 27.		srec0068		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	List<OpFallSelPcBasVo> selectFallSelPc() throws Exception;

	/**
	 * <pre>
	 * 판매가격 하락일자 업데이트
	 * </pre>
	 * @date 2023. 04. 27.
	 * @author srec0068
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 04. 27.		srec0068		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void updateFallSelPcBas(String fallSeqNo) throws Exception;

	/**
	 * <pre>
	 * 금속권한 설정된 회원 번호 조회
	 * </pre>
	 * @date 2023. 04. 28.
	 * @author srec0068
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 04. 28.		srec0068		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	List<Map<String, String>> selectMemberSmsByMetalCode(String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 조달청 가격 조회
	 * </pre>
	 * @date 2023. 5. 23.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 5. 23.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<RvcmpnVO> selectItRvcmpnPcManageBas() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 판매가격 하락 조회 
	 * </pre>
	 * @date 2023. 5. 23.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 5. 23.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<OpFallSelPcBasVo> selectFallSelPcBas() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 프리미엄 가격 조회
	 * </pre>
	 * @date 2023. 5. 23.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 5. 23.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<SelPrimiumAmountVo> selectSelPremiumAmount() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용 : 시초가 가격 비교 데이터 조회
	 * </pre>
	 * @date 2023. 06. 29.
	 * @author bok3117
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 06. 29.		bok3117			최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	List<OpFallNumPcBasVo> selectFallNumPc() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 과거 LME 데이터 조회
	 * </pre>
	 * @date 2023. 7. 31.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 31.			srec0064			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	PrLmePcStdrBasVo selectPastLmePc(Map<String, String> map) throws Exception;
}