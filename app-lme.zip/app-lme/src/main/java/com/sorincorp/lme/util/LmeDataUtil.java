package com.sorincorp.lme.util;

public class LmeDataUtil {
	
	public final static String SEL_PC_ALL_LIST = "selpcAllList";	// 프리미엄 적용 판매가격 (레디스에 저장할 이름)
	public final static int DURATION = 70000;
	
	// 멤버 변수
    public static int    pos;
    public static String recept_datetime;            
    public static String type;            
    
    public static String to_string (String str, int length) {
      byte[] bytes = str.getBytes();

      String ret = new String (bytes, pos , length) ;
    	
      int i = ret.length()-1;
      
      while (i >= 0 && Character.isWhitespace(ret.charAt(i))) {
        i--;
      }
      
      ret = ret.substring(0,i+1);
       
      pos = pos + length ;
            
      return ret ;      
    }

    public static double to_double (String str, int length) {
      byte[] bytes = str.getBytes();

      String ret = new String (bytes, pos , length) ;

      int i = ret.length()-1;
      
      while (i >= 0 && Character.isWhitespace(ret.charAt(i))) {
        i--;
      }
      
      ret = ret.substring(0,i+1);

      double d ;
      
      if (ret.length() == 0 ) {
        d = 0 ;
      } else {          
        d = Double.parseDouble(ret);
      }

      pos = pos + length ;
            
      return d ;      
    }
	
    public static int to_int (String str, int length) 
    {
      byte[] bytes = str.getBytes();

      String ret = new String (bytes, pos , length) ;

      int i = ret.length()-1;
      
      while (i >= 0 && Character.isWhitespace(ret.charAt(i))) {
        i--;
      }
      
      ret = ret.substring(0,i+1);
      
      int d ;
      
      if (ret.length() == 0 ) {
        d = 0 ;
      } else {          
        d = Integer.parseInt(ret);
      }

      pos = pos + length ;
            
      return d ;      
    }
}
