package com.sorincorp.lme.spclty.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class IfLmeSpcltyLhVo implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = -9105817323353784521L;
	/**
     * 수신일시
    */
    private String receptDatetime;
    /**
     * 전문타입
    */
    private String type;
    /**
     * 종목코드(삼성선물용)
    */
    private String gicName;
    /**
     * 종목코드(로이터)
    */
    private String ricName;
    /**
     * 선물현물스프레드구분
    */
    private String kind;
    /**
     * 영국영업일자
    */
    private String tradeDate;
    /**
     * 수신일자
    */
    private String receptDate;
    /**
     * 수신시각
    */
    private String receptTime;
    /**
     * 거래소
    */
    private String marketCode;
    /**
     * 매수호가1
    */
    private String bestBid1;
    /**
     * 매수호가2
    */
    private String bestBid2;
    /**
     * 매수호가3
    */
    private String bestBid3;
    /**
     * 매수호가4
    */
    private String bestBid4;
    /**
     * 매수호가5
    */
    private String bestBid5;
    /**
     * 매도호가1
    */
    private String bestAsk1;
    /**
     * 매도호가2
    */
    private String bestAsk2;
    /**
     * 매도호가3
    */
    private String bestAsk3;
    /**
     * 매도호가4
    */
    private String bestAsk4;
    /**
     * 매도호가5
    */
    private String bestAsk5;
    /**
     * 매도호가잔량1
    */
    private String bestBsiz1;
    /**
     * 매도호가잔량2
    */
    private String bestBsiz2;
    /**
     * 매도호가잔량3
    */
    private String bestBsiz3;
    /**
     * 매도호가잔량4
    */
    private String bestBsiz4;
    /**
     * 매도호가잔량5
    */
    private String bestBsiz5;
    /**
     * 매수호가잔량1
    */
    private String bestAsiz1;
    /**
     * 매수호가잔량2
    */
    private String bestAsiz2;
    /**
     * 매수호가잔량3
    */
    private String bestAsiz3;
    /**
     * 매수호가잔량4
    */
    private String bestAsiz4;
    /**
     * 매수호가잔량5
    */
    private String bestAsiz5;
}