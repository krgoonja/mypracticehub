package com.sorincorp.lme.spclty.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class IfLmeSpcltyLvVo implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = -968543198612870799L;
	/**
     * 수신일시
    */
    private String receptDatetime;
    /**
     * 전문타입
    */
    private String type;
    /**
     * 품목코드
    */
    private String metalCode;
    /**
     * 영국영업일자
    */
    private String tradeDate;
    /**
     * 세션코드
    */
    private String sessionCode;
    /**
     * volumeusd
    */
    private String volumeusd;
    /**
     * volumeeur
    */
    private String volumeeur;
    /**
     * volumegbp
    */
    private String volumegbp;
    /**
     * volumeyen
    */
    private String volumeyen;
}