package com.sorincorp.lme.sel.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.comm.bsnInfo.model.RestdeVO;
import com.sorincorp.comm.it.model.ItFtrsFshgManageDtlVo;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.lme.constant.PrPcStdrBasVoConstant;
import com.sorincorp.lme.ehgt.model.PrEhgtPcStdrBasVo;
import com.sorincorp.lme.pc.model.PrLmeEvlPcBasVo;
import com.sorincorp.lme.pc.model.PrLmePcStdrBasVo;
import com.sorincorp.lme.sel.model.PrSelPcStdrBasVo;
import com.sorincorp.lme.util.FallSelPc;
import com.sorincorp.lme.util.RestDateTime;
import com.sorincorp.lme.util.SerialUtils;

import lombok.extern.slf4j.Slf4j;

/*
 * LC 타입의 전문 data를 기준으로 판매가격 data vo를 만들어 반환하는 method 정의 Clas
 */
@Slf4j
@Component
public class ReturnNewSelVo {
	
	@Autowired
	private FallSelPc fallSelPc;
	
	@Autowired
	private RestDateTime restDateTime;
	//private PrSelPcStdrBasVoMapService prSelPcStdrBasVoMapService;
	private final PrSelPcStdrBasVoMapService prSelPcStdrBasVoMapService;
	
	public ReturnNewSelVo(PrSelPcStdrBasVoMapService prSelPcStdrBasVoMapService) {
		this.prSelPcStdrBasVoMapService = prSelPcStdrBasVoMapService;
	}
	
	/*
	 * parsing하여 LME 정보에 맞게 만든 전문 실시간 data, 평가가격, 실시간 환율 가격, LME 조정계수, 환율 조정계수, 방금 전 전문 data를 기준으로 계산하여
	 * 실시간 판매가격 singleTone data를 만든다.
	 */
    public PrSelPcStdrBasVo process_PrSelPcStdrBasVo (PrLmePcStdrBasVo nowLmeStdrVo, PrLmeEvlPcBasVo evlVo, PrEhgtPcStdrBasVo ehgtVo, ItFtrsFshgManageDtlVo itVo
    													,PrSelPcStdrBasVo pastSelStdrVo) throws Exception {
    	
    	String yyyymmdd = DateUtil.getNowDateTime("yyyyMMdd");
    	String hhmmss = DateUtil.getNowDateTime("HHmmss");
    	
    	PrSelPcStdrBasVo returnVo = new PrSelPcStdrBasVo();
		returnVo.setMetalCode(nowLmeStdrVo.getMetalCode());
		returnVo.setItmSn(0);
		returnVo.setDstrctLclsfCode("00");
		returnVo.setBrandGroupCode("00");
		returnVo.setBrandCode("0000000000");
		returnVo.setOccrrncDe(yyyymmdd);
		returnVo.setOccrrncTime(hhmmss);
		
		String serialNum = SerialUtils.getSerial();
		
		returnVo.setOccrrncSn(serialNum);
		//returnVo.setSlePcRltmSn(nowLmeStdrVo.getLmePcRltmSn().substring(0, 14) + serialNum);
		returnVo.setSlePcRltmSn(yyyymmdd + hhmmss + serialNum);
		
		if(nowLmeStdrVo.getEndPc() == null) {
			nowLmeStdrVo.setEndPc(BigDecimal.ZERO);
		}
		
		long calculateEndPc = (long) (((nowLmeStdrVo.getEndPc().add(itVo.getLmeMdatCffcntAmount())
														) .multiply(ehgtVo.getEndPc().add(itVo.getEhgtMdatCffcntAmount()))
													).divide(new BigDecimal(1000)).setScale(0, RoundingMode.DOWN).longValue()) * 1000;
		returnVo.setEndPc(calculateEndPc);

		// 휴무시간 판별 후 sms 전송
		if(!restDateTime.checkTodayHvofTime()) {
			fallSelPc.calculateSmsPrice(nowLmeStdrVo.getMetalCode(), calculateEndPc, yyyymmdd + hhmmss);
		}
		
		if(restDateTime.getReadytoStartLmeData(nowLmeStdrVo.getMetalCode())) {
			returnVo.setBeginPc(calculateEndPc);
			returnVo.setTopPc(calculateEndPc);
			returnVo.setLwetPc(calculateEndPc);
			
			returnVo.setVersusPc(0);
			returnVo.setVersusRate(BigDecimal.ZERO);
		} else {
			returnVo.setBeginPc(pastSelStdrVo.getBeginPc());
			returnVo.setTopPc(pastSelStdrVo.getTopPc());
			returnVo.setLwetPc(pastSelStdrVo.getLwetPc());
			
			if(calculateEndPc >= pastSelStdrVo.getTopPc()) {
				returnVo.setTopPc(calculateEndPc);
			} 
			
			if(calculateEndPc <= pastSelStdrVo.getLwetPc()) {
				returnVo.setLwetPc(calculateEndPc);
			}
			
			if(returnVo.getBeginPc() > returnVo.getTopPc()) {
				returnVo.setTopPc(returnVo.getBeginPc());
			}
			
			if(returnVo.getBeginPc() < returnVo.getLwetPc()) {
				returnVo.setLwetPc(returnVo.getBeginPc());
			}
			
			returnVo.setVersusPc(calculateEndPc - pastSelStdrVo.getEndPc());
			
			if(pastSelStdrVo.getEndPc() == 0) {
				returnVo.setVersusRate(BigDecimal.ZERO);
			} else {
				returnVo.setVersusRate(((new BigDecimal(calculateEndPc - pastSelStdrVo.getEndPc())).divide(new BigDecimal(pastSelStdrVo.getEndPc()), 6, RoundingMode.DOWN)).multiply(new BigDecimal(100)));
			}
		}
		
		String hlafMinutes = "";
		int current30Minute = Integer.parseInt(DateUtil.getNowDateTime("mm"));
		
		if(1 <= current30Minute && current30Minute <= 29) {
			hlafMinutes = "00"; 
		} else if (31 <= current30Minute && current30Minute <= 59) {
			hlafMinutes = "30"; 
		} else {
			hlafMinutes = DateUtil.getNowDateTime("mm");
		}
		
		returnVo.setSlePc01MinSn(yyyymmdd + DateUtil.getNowDateTime("HHmm") + "00" + serialNum);
		returnVo.setSlePc30MinSn(yyyymmdd + DateUtil.getNowDateTime("HH") + hlafMinutes + "00" + serialNum);
		returnVo.setSlePc60MinSn(yyyymmdd + DateUtil.getNowDateTime("HH") + "0000" + serialNum);
		
		returnVo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
		returnVo.setSlePcDeSn(yyyymmdd + "000000" + serialNum);
		
		returnVo.setOccrrncYyWeek(DateUtil.getNowDateTime("yyyy") + DateUtil.getWeekOfYearByISO(DateUtil.getNowDateTime("yyyyMMdd")));
		returnVo.setSlePcYyWeekSn(yyyymmdd + DateUtil.getNowDateTime("HH") + "0000" + serialNum);
		
		returnVo.setOccrrncYm(DateUtil.getNowDateTime("yyyyMM"));
		returnVo.setSlePcYyMtSn(DateUtil.getNowDateTime("yyyyMM") + "01000000" + serialNum);
		
		returnVo.setOccrrncQu(DateUtil.getNowDateTime("yyyy") + "0" + DateUtil.getQuarterOfYear(DateUtil.getNowDateTime("yyyyMMdd")));
		returnVo.setSlePcYyQuSn(yyyymmdd + DateUtil.getNowDateTime("HH") + "0000" + serialNum);
		
		returnVo.setOccrrncYy(DateUtil.getNowDateTime("yyyy"));
		returnVo.setSlePcYySn(yyyymmdd + DateUtil.getNowDateTime("HH") + "0000" + serialNum);
		
		
		returnVo.setThreemonthLmePc(nowLmeStdrVo.getThreemonthEndPc());
		returnVo.setLmePc(nowLmeStdrVo.getEndPc());
		returnVo.setLmeExcclcPc(evlVo.getEvlPc());
		returnVo.setEhgtPc(ehgtVo.getEndPc());
		returnVo.setPremiumPc(0);
		returnVo.setLmePcRltmSn(nowLmeStdrVo.getLmePcRltmSn());
		returnVo.setEhgtPcRltmSn(ehgtVo.getEhgtPcRltmSn());
		returnVo.setPremiumNo("000000000000000000");
		returnVo.setLmeMdatCffcnt(itVo.getLmeMdatCffcntAmount());
		returnVo.setFxMdatCffcnt(itVo.getEhgtMdatCffcntAmount());
		
		returnVo.setDelngQy(0);
		returnVo.setAccmltDelngQy(0);

		// LME 조정 가격
		returnVo.setLmeMdatPc(nowLmeStdrVo.getEndPc().add(itVo.getLmeMdatCffcntAmount()));

		if(returnVo.getMetalCode().equals("7")) {
			log.info("rltm endPc(): " + returnVo.getEndPc() );
		}
		
		return returnVo;
    }
    
    public PrSelPcStdrBasVo process_CopyNewSelStdrVo (PrSelPcStdrBasVo vo) throws Exception {
    	PrSelPcStdrBasVo returnVo = new PrSelPcStdrBasVo();
		BeanUtils.copyProperties(vo, returnVo);
		
		return returnVo;
    }
    
    /*
     * parsing하여 LME 정보에 맞게 만든 전문 실시간 data, 평가가격, 실시간 환율 가격, LME 조정계수, 환율 조정계수, 방금 전 전문 data, 이전 분기별 data를 기준으로 계산하여
     * 해당 분기의 판매가격 singleTone data를 만든다.
     */
    // (pje) DB에 넣고 실시간차트에 보여주기 위해 전문으로 판매 가격 계산
    public PrSelPcStdrBasVo process_MinuteScheduleVo(PrLmePcStdrBasVo nowLmeStdrVo, PrLmeEvlPcBasVo evlVo, PrEhgtPcStdrBasVo ehgtVo, ItFtrsFshgManageDtlVo itVo
														, PrSelPcStdrBasVo justBeforeSelVo, PrSelPcStdrBasVo pastSelMinuteVo, String tickTime, Map<String, Boolean> changeAt) throws Exception {
		/*
		 * (pje)
		 * nowLmeStdrVo: 전문 실시간 data
		 * evlVo: 안씀
		 * ehgtVo: 실시간 환율 가격
		 * itVo: LME 조정계수, 환율 조정계수
		 * justBeforeSelVo: 방금 전 전문 data
		 * pastSelMinuteVo: 이전 분기별 data
		 */
    	
    	PrSelPcStdrBasVo returnVo = new PrSelPcStdrBasVo();
		PrSelPcStdrBasVo returnJustBeforeSelVo = process_CopyNewSelStdrVo(justBeforeSelVo);
		PrSelPcStdrBasVo returnPastSelMinuteVo = process_CopyNewSelStdrVo(pastSelMinuteVo);
		
		String yyyymmdd = DateUtil.getNowDateTime("yyyyMMdd");
		
		returnVo.setMetalCode(nowLmeStdrVo.getMetalCode());
		returnVo.setItmSn(0);
		returnVo.setDstrctLclsfCode("00");
		returnVo.setBrandGroupCode("00");
		returnVo.setBrandCode("0000000000");
		
		String serialNum = SerialUtils.getSerial();
		
		String hlafMinutes = "";
		int current30Minute = Integer.parseInt(DateUtil.getNowDateTime("mm"));
		
		if(1 <= current30Minute && current30Minute <= 29) {
			hlafMinutes = "00"; 
		} else if (31 <= current30Minute && current30Minute <= 59) {
			hlafMinutes = "30"; 
		} else {
			hlafMinutes = DateUtil.getNowDateTime("mm");
		}
		
		switch(tickTime) {
			case "01":
				returnVo.setOccrrncTime(DateUtil.getNowDateTime("HHmm") + "00");
				break;
			case "30":
				returnVo.setOccrrncTime(DateUtil.getNowDateTime("HH") + hlafMinutes + "00");
				break;
			case "60":
				returnVo.setOccrrncTime(DateUtil.getNowDateTime("HH") + "0000");
				break;
			default :
				break;
		}
		
		returnVo.setSlePc01MinSn(yyyymmdd + DateUtil.getNowDateTime("HHmm") + "00" + serialNum);
		returnVo.setSlePc30MinSn(yyyymmdd + DateUtil.getNowDateTime("HH") + hlafMinutes + "00" + serialNum);
		returnVo.setSlePc60MinSn(yyyymmdd + DateUtil.getNowDateTime("HH") + "0000" + serialNum);
		
		returnVo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
		returnVo.setSlePcDeSn(yyyymmdd + "000000" + serialNum);
		
		returnVo.setOccrrncYyWeek(DateUtil.getNowDateTime("yyyy") + DateUtil.getWeekOfYearByISO(DateUtil.getNowDateTime("yyyyMMdd")));
		returnVo.setSlePcYyWeekSn(yyyymmdd + DateUtil.getNowDateTime("HH") + "0000" + serialNum);
		
		returnVo.setOccrrncYm(DateUtil.getNowDateTime("yyyyMM"));
		returnVo.setSlePcYyMtSn(DateUtil.getNowDateTime("yyyyMM") + "01000000" + serialNum);
		
		returnVo.setOccrrncQu(DateUtil.getNowDateTime("yyyy") + "0" + DateUtil.getQuarterOfYear(DateUtil.getNowDateTime("yyyyMMdd")));
		returnVo.setSlePcYyQuSn(yyyymmdd + DateUtil.getNowDateTime("HH") + "0000" + serialNum);
		
		returnVo.setOccrrncYy(DateUtil.getNowDateTime("yyyy"));
		returnVo.setSlePcYySn(yyyymmdd + DateUtil.getNowDateTime("HH") + "0000" + serialNum);
		
		// 판매가 계산부분
		long calculateEndPc = (long) (((nowLmeStdrVo.getEndPc().add(itVo.getLmeMdatCffcntAmount())
														) .multiply(ehgtVo.getEndPc().add(itVo.getEhgtMdatCffcntAmount()))
													).divide(new BigDecimal(1000)).setScale(0, RoundingMode.DOWN).longValue()) * 1000;
		
		if(restDateTime.getChecktoSelStartData(justBeforeSelVo.getMetalCode())) {
			returnVo.setEndPc(calculateEndPc);
			returnVo.setBeginPc(calculateEndPc);
			returnVo.setTopPc(calculateEndPc);
			returnVo.setLwetPc(calculateEndPc);
			
			returnVo.setVersusPc(0);
			returnVo.setVersusRate(BigDecimal.ZERO);
			
			returnVo.setDelngQy(1);
			
			restDateTime.setChecktoSelStartData(justBeforeSelVo.getMetalCode(), false);
		} else if (Boolean.TRUE.equals(changeAt.get(returnVo.getMetalCode()))) {
			returnVo.setEndPc(calculateEndPc);
			returnVo.setBeginPc(calculateEndPc);
			returnVo.setTopPc(calculateEndPc);
			returnVo.setLwetPc(calculateEndPc);
			
			returnVo.setVersusPc(0);
			returnVo.setVersusRate(BigDecimal.ZERO);
			
			returnVo.setDelngQy(1);
			
			if(tickTime.equals("01") && returnVo.getMetalCode().equals("7")) {
				log.info("changeAt metalCode: " + returnVo.getMetalCode() + ", beginPc: " + returnVo.getBeginPc() + ", lwetPc: " + returnVo.getLwetPc());
			}
			
		} else if(justBeforeSelVo.getEndPc() == 0) {
			returnVo.setEndPc(calculateEndPc);
			returnVo.setBeginPc(calculateEndPc);
			returnVo.setTopPc(calculateEndPc);
			returnVo.setLwetPc(calculateEndPc);
			
			returnVo.setVersusPc(0);
			returnVo.setVersusRate(BigDecimal.ZERO);
			
			returnVo.setDelngQy(1);
			
			if(returnVo.getMetalCode().equals("7") && tickTime.equals("01")) {
				log.info("justBeforeSelVo.getEndPc() == 0: " + returnVo.getEndPc() );
			}
			
			// 이전 1분 데이터 세팅
			//setPastData(tickTime, returnVo);
		}
		else {
			returnVo.setEndPc(calculateEndPc);
			returnVo.setBeginPc(returnJustBeforeSelVo.getBeginPc());	// [pje] 위에서 초기화한 값으로 세팅
			returnVo.setTopPc(returnJustBeforeSelVo.getTopPc());
			returnVo.setLwetPc(returnJustBeforeSelVo.getLwetPc());
			
			if(calculateEndPc >= returnJustBeforeSelVo.getTopPc()) {
				returnVo.setTopPc(calculateEndPc);
			} 
			
			if(calculateEndPc <= returnJustBeforeSelVo.getLwetPc() && calculateEndPc != 0) {
				returnVo.setLwetPc(calculateEndPc);
			}
			
			if(returnVo.getBeginPc() > returnVo.getTopPc()) {
				returnVo.setTopPc(returnVo.getBeginPc());
			}
			
			if(returnVo.getBeginPc() < returnVo.getLwetPc() && returnVo.getBeginPc() != 0) {
				returnVo.setLwetPc(returnVo.getBeginPc());
			}
			
			returnVo.setVersusPc(calculateEndPc - returnPastSelMinuteVo.getEndPc());
			
			if(returnPastSelMinuteVo.getEndPc() == 0) {
				returnVo.setVersusRate(BigDecimal.ZERO);
			} else {
				returnVo.setVersusRate(((new BigDecimal(calculateEndPc - returnPastSelMinuteVo.getEndPc())).divide(new BigDecimal(returnPastSelMinuteVo.getEndPc()), 6, RoundingMode.DOWN)).multiply(new BigDecimal(100)));
			}

			returnVo.setDelngQy(justBeforeSelVo.getDelngQy() + 1);
		}
		
		if((returnVo.getMetalCode().equals("8") && tickTime.equals("01")) || returnVo.getMetalCode().equals("7") && tickTime.equals("01") || returnVo.getMetalCode().equals("5") && tickTime.equals("01")) {
			log.info("[returnNewSelVo returnVO] metalCode:"+ returnVo.getMetalCode() +  ", BeginPc: " + returnVo.getBeginPc() + ", EndPc:"+ returnVo.getEndPc());
			log.info("returnNewSelVo PAST_ONE_MINUTE END_PC: " + Long.toString( prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(returnVo.getMetalCode(), PrPcStdrBasVoConstant.PAST_ONE_MINUTE).getEndPc()) );
		}
		return returnVo;
	}

	private void setPastData(String tickTime, PrSelPcStdrBasVo returnVo) {
		switch(tickTime) {
		case "01":
			PrSelPcStdrBasVo prSelPcStdrBasVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(returnVo.getMetalCode(), PrPcStdrBasVoConstant.PAST_ONE_MINUTE);
			if (prSelPcStdrBasVo != null && returnVo != null) {
				if(returnVo.getSlePc01MinSn() != null && prSelPcStdrBasVo.getSlePc01MinSn() != null) {
					prSelPcStdrBasVo.setSlePc01MinSn(returnVo.getSlePc01MinSn());
					prSelPcStdrBasVo.setBeginPc(returnVo.getBeginPc());
					//BeanUtils.copyProperties(returnVo, prSelPcStdrBasVo);
				}
			}
			break;
		case "30":
			PrSelPcStdrBasVo prSel30PcStdrBasVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(returnVo.getMetalCode(), PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE);
			if (prSel30PcStdrBasVo != null && returnVo != null) {
				if(returnVo.getSlePc30MinSn() != null && prSel30PcStdrBasVo.getSlePc30MinSn() != null) {
					BeanUtils.copyProperties(returnVo, prSel30PcStdrBasVo);
				}
			}
		case "60":
			PrSelPcStdrBasVo prSel60PcStdrBasVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(returnVo.getMetalCode(), PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE);
			if (prSel60PcStdrBasVo != null && returnVo != null) {
				if(returnVo.getSlePc60MinSn() != null && prSel60PcStdrBasVo.getSlePc60MinSn() != null) {
					BeanUtils.copyProperties(returnVo, prSel60PcStdrBasVo);
				}
			}
		default :
			break;
		}
	}
	
	public Map<String, Boolean> checkChangeSel(String metalCode, String currentTime, String timeData, String tickTime) {
		Map<String, Boolean> result = new HashMap<>();
		
		if(timeData == null) {
			result.put(metalCode, false);
			return result;
		}
		
		String currentHour = currentTime.substring(0, 2);
		String currentMinutes = currentTime.substring(2, 4);
		String memoryMinutes = timeData.substring(2, 4);
		String memoryHour = timeData.substring(0, 2);

		switch (tickTime) {
			case "01":
				result.put(metalCode, !currentMinutes.equals(memoryMinutes));
				break;
			case "30":
				String current30Minutes = String.valueOf((Integer.parseInt(currentMinutes) / 30) * 30);
				if(current30Minutes.equals("0")) current30Minutes = "00";
				result.put(metalCode, !current30Minutes.equals(memoryMinutes));
				break;
			case "60":
				result.put(metalCode, !currentHour.equals(memoryHour));
				break;
			default:
				result.put(metalCode, !currentHour.equals(memoryHour));
				break;
		}
		
		if(tickTime.equals("01"))
			log.info("checkChangeSel metalCode: " + metalCode + ", currentMinutes: " + currentMinutes + ", memoryMinutes: " + memoryMinutes + ", result: " + result);
		return result;
	}
	
	public boolean isWithinTimeRange(String hhmmss, RestdeVO restdeVO) {
	    int intHHmmss = Integer.parseInt(hhmmss);
	    int beginTime = Integer.parseInt(restdeVO.getTimeAcctoRestdeBeginTime());
	    int endTime = Integer.parseInt(restdeVO.getTimeAcctoRestdeEndTime());

	    return intHHmmss >= beginTime && intHHmmss <= endTime;
	}
}