package com.sorincorp.lme.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import com.nhncorp.lucy.security.xss.CommonUtils;
import com.sorincorp.comm.bsnInfo.model.RestdeFxLmeVO;
import com.sorincorp.comm.bsnInfo.model.RestdeVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.CommonUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.lme.etc.model.ClosedHoursVo;
import com.sorincorp.lme.etc.service.EtcService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@ComponentScan("com.sorincorp.comm.*")
public class RestDateTime {
	
	public enum Operator {
		PLUS, MINUS
	}
	
	public enum LmeStatus {
		SUCCESS(0), FAIL(1), AFTERSUCCESS(2);
		
		public final int value;
		
		LmeStatus(int value) {
			this.value = value;
		}
	}
	
	public enum EhgtStatus {
		SUCCESS(0), FAIL(1), AFTERSUCCESS(2);
		
		public final int value;
		
		EhgtStatus(int value) {
			this.value = value;
		}
	}
	
	public enum NickelStatus {
		SUCCESS(0), FAIL(1);
		
		public final int value;
		
		NickelStatus(int value) {
			this.value = value;
		}
	}
	
	@Autowired 
	private BsnInfoService bsnInfoService;
	
	@Autowired
	private EtcService etcService;
	
	@Autowired
	private RedisPubSubService redisPubSubService;
	
	@Value("${redisPubsub.uri.restTime}")
	private String restTimeUri;
	
	private static boolean isLmeRestDay = false;
	
	private static boolean isRestDay = false;
	private static boolean isRestTime = false;
	private static String restBeginTime = "";
	private static String restEndTime = "";
	private static boolean isRealTimeSellRestDay = false;
	private static String realSellBeginTime = "";
	private static String realSellEndTime = ""; 
	private static String hvofApplcDe = "";
	private static String applcBeginTime = "";
	private static String applcEndTime = "";
	
	private static Map<String, Boolean> isReadytoStartLmeDataMap;
	private static Map<String, Boolean> isReadytoCheckSelDataMap;
	private static Map<String, Boolean> isPubMessageStartLmeDataMap;
	private static Map<String, Boolean> isReadytoStartGroupDataMap;	// 종목별 시초가 여부
	private static int lmeStatusCode = 1;		//Fail을 초기값으로
	private static int ehgtStatusCode = 1;		//Fail을 초기값으로
	private static int nickelStatusCode = 1;	//Fail을 조기값으로
	
	private static int isLmeReceive = 0; //Success를 초기값으로
	private static int isEhgtReceive = 0; //Success를 초기값으로
	
	@Value("${metalCode.list}") private List<String> metalCodeList;
	
	public void initialize() throws Exception {
		RestdeVO restdeVO = bsnInfoService.getRestdeInfoWithoutHvofTime(DateUtil.getNowDateTime("yyyyMMdd"));	//[pje]수정
		RestdeFxLmeVO restdeFxLmeVO = bsnInfoService.getRestdeFxLmeInfo(DateUtil.getNowDateTime("yyyyMMdd"));
		
		isLmeRestDay = "Y".equals(restdeFxLmeVO.getLmeRestdeAt()) ? true : false;
		
		isRestDay = "Y".equals(restdeVO.getDeAcctoRestdeAt()) ? true : false;
		
		isRestTime = "Y".equals(restdeVO.getTimeAcctoRestdeAt()) ? true : false;
		restBeginTime = restdeVO.getTimeAcctoRestdeBeginTime();
		restEndTime = restdeVO.getTimeAcctoRestdeEndTime();
		
		isRealTimeSellRestDay = "Y".equals(restdeVO.getRltmRestdeAt()) ? true : false;
		realSellBeginTime = restdeVO.getRltmBeginTime();
		realSellEndTime = restdeVO.getRltmEndTime();
		
		setTodayHvof(); // 휴무시간 초기화
		
		log.info("============================RestDate============================");
		log.info(" restdeVO : " + restdeVO);
		log.info(" restdeFxLmeVO : " + restdeFxLmeVO);
		log.info(" isLmeRestDay : " + isLmeRestDay);
		log.info(" isRestDay : " + isRestDay);
		log.info(" isRestTime : " + isRestTime);
		log.info(" restBeginTime : " + restBeginTime + " / restEndTime : " + restEndTime);
		log.info(" isRealTimeSellRestDay : " + isRealTimeSellRestDay);
		log.info(" realSellBeginTime : " + realSellBeginTime + " / realSellEndTime : " + realSellEndTime);
		log.info(" [pje] ehgtStatusCode : " + getEhgtStatusCode());
		log.info(" nickelStatusCode: " + getNickelStatusCode());
		log.info(" hvofApplcDe: " + hvofApplcDe + " / applcBeginTime : " + applcBeginTime + " / applcEndTime : " + applcEndTime);
		log.info("================================================================");
	}
	
	/**
	 * <pre>
	 * 처리내용: 휴무시간을 초기화한다.
	 * </pre>
	 * @date 2023. 12. 20.
	 * @author bok3117
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일				작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 12. 20.	bok3117			최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	public void setTodayHvof() throws Exception {
		RestdeVO todayHvofVO = bsnInfoService.getTodayTodayHvofTime();
		
		if(CommonUtil.isNotEmpty(todayHvofVO)) {
			hvofApplcDe = todayHvofVO.getHvofApplcDe();
			applcBeginTime = todayHvofVO.getApplcBeginTime();
			applcEndTime = todayHvofVO.getApplcEndTime();			
		}
		
		redisPubSubService.publishMessage(restTimeUri, restTimeUri, ""); // redis 초기화 작업
		
		log.info(" hvofApplcDe: " + hvofApplcDe + " / applcBeginTime : " + applcBeginTime + " / applcEndTime : " + applcEndTime);
	}
	
	/**
	 * <pre>
	 * 처리내용: 기준시간에서 초를 더하거나 뺀 값을 반환한다.
	 * </pre>
	 * @date 2022. 5. 20.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 20.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param HHmmss
	 * @param second
	 * @param operator
	 * @return
	 * @throws Exception
	 */
	public String calculateTime(String HHmmss, int second, Operator operator) throws Exception {
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("HHmmss");
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateFormat.parse(HHmmss));
		
		String endTime = "";
		
		switch(operator) {
			case PLUS :
				cal.add(Calendar.SECOND, second);
				endTime = dateFormat.format(cal.getTime());
				break;
			case MINUS :
				cal.add(Calendar.SECOND, -second);
				endTime = dateFormat.format(cal.getTime());
				break;
		}
		
		return endTime;
	}
	
	public String calculateDate(String yyyyMMdd, int date, Operator operator) throws Exception {
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateFormat.parse(yyyyMMdd));
		
		String endTime = "";
		
		switch(operator) {
			case PLUS :
				cal.add(Calendar.DATE, date);
				endTime = dateFormat.format(cal.getTime());
				break;
			case MINUS :
				cal.add(Calendar.DATE, -date);
				endTime = dateFormat.format(cal.getTime());
				break;
		}
		
		return endTime;
	}
	
	/**
	 * <pre>
	 * 처리내용: 휴무시간을 update한다.
	 * </pre>
	 * @date 2022. 5. 20.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 20.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param restSecond
	 * @param rm
	 * @throws Exception
	 */
	public void updateRestTime(int restSecond, String rm) throws Exception {
		ClosedHoursVo vo = new ClosedHoursVo();
		vo.setApplcDe(DateUtil.getNowDateTime("yyyyMMdd"));
		vo.setApplcBeginTime(DateUtil.getNowDateTime("HHmmss"));
		vo.setApplcEndTime(calculateTime(DateUtil.getNowDateTime("HHmmss"), restSecond, Operator.PLUS));
		vo.setHvofTyCode("05");	// 휴무유형코드- 05: LME 수신 오류
		vo.setRm(rm);
		
		etcService.insertItHvofTimeManageBas(vo);
	}
	
	/**
	 * <pre>
	 * 처리내용: BO의 LME 신호등 상태값을 바꾼다.
	 * </pre>
	 * @date 2022. 5. 20.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 20.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param status
	 * @throws Exception
	 */
	public void updateCntcStts(int status) throws Exception {
		etcService.updateCntcStts(status);
	}
	
	/**
	 * <pre>
	 * 처리내용: 오늘이 LME휴일인지 아닌지 확인한다.
	 * </pre>
	 * @date 2022. 5. 20.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 20.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 */
	public boolean isLmeWorkTime() {
		if(!isLmeRestDay) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * <pre>
	 * 처리내용: 오늘이 케이지트레이딩 휴일인지 아닌지 확인한다.
	 * </pre>
	 * @date 2022. 5. 20.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 20.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	public boolean isSorinWorkTime() throws Exception {
		if(!isRestDay) {
			if(isRestTime) {
				if(!"".equals(restBeginTime) && !"".equals(restEndTime)) {
					int nowTime = Integer.parseInt(DateUtil.getNowDateTime("HHmmss"));
					if(Integer.parseInt(restBeginTime) <= nowTime && nowTime <= Integer.parseInt(restEndTime)) {
						return false;
					}
				}
			} 
			
			return isRealSellTime();
		}
		
		return false;
	}
	
	/**
	 * <pre>
	 * 처리내용: 지금이 케이지트레이딩 판매 시간인지 아닌지 확인한다.
	 * </pre>
	 * @date 2022. 5. 20.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 20.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	private boolean isRealSellTime() throws Exception {
		if(!isRealTimeSellRestDay) {
			if(!"".equals(realSellBeginTime) && !"".equals(realSellEndTime)) {
				int nowTime = Integer.parseInt(DateUtil.getNowDateTime("HHmmss"));
				int beginTime = Integer.parseInt(realSellBeginTime);
				int endTime = Integer.parseInt(calculateTime(realSellEndTime, 58, Operator.PLUS)); //마지막 58초까지는 허가
				
				if(beginTime <= nowTime && nowTime <= endTime) {
					return true;
				}
			}
		}
		
		return false;
	}
	
	public boolean isSorinRltmWorkTime() throws Exception {
		if(!isRestDay) {
			if(isRestTime) {
				if(!"".equals(restBeginTime) && !"".equals(restEndTime)) {
					int nowTime = Integer.parseInt(DateUtil.getNowDateTime("HHmmss"));
					if(Integer.parseInt(restBeginTime) <= nowTime && nowTime <= Integer.parseInt(restEndTime)) {
						return false;
					}
				}
			} 
			
			return isRealRltmSellTime();
		}
		
		return false;
	}
	
	public boolean isRealRltmSellTime() throws Exception {
		if(!isRealTimeSellRestDay) {
			if(!"".equals(realSellBeginTime) && !"".equals(realSellEndTime)) {
				int nowTime = Integer.parseInt(DateUtil.getNowDateTime("HHmmss"));
				int beginTime = Integer.parseInt(realSellBeginTime);
				int endTime = Integer.parseInt(realSellEndTime);
				
				if(beginTime <= nowTime && nowTime <= endTime) {
					return true;
				}
			}
		}
		
		return false;
	}
	
	/**
	 * <pre>
	 * 처리내용: 지금이 케이지트레이딩 개장시간(-1초, +58초) 범위 인지 아닌지 확인한다.
	 * </pre>
	 * @date 2022. 5. 20.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 20.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	public boolean isSorinRealSellBeginTime() throws Exception {
		if(!isRealTimeSellRestDay) {
			if(!"".equals(realSellBeginTime) && !"".equals(realSellEndTime)) {
				int nowTime = Integer.parseInt(DateUtil.getNowDateTime("HHmmss"));
				int beginTime = Integer.parseInt(calculateTime(realSellBeginTime, 1, Operator.MINUS));
				int endTime = Integer.parseInt(calculateTime(realSellBeginTime, 58, Operator.PLUS));
				
				if(beginTime <= nowTime && nowTime <= endTime) {
					return true;
				}
			}
		}
		
		return false;
	}
	
	/**
	 * <pre>
	 * 처리내용: 지금이 케이지트레이딩 폐장시간(-1초, +58초) 범위 인지 아닌지 확인한다.
	 * </pre>
	 * @date 2022. 5. 20.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 20.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	public boolean isSorinRealSellEndTime() throws Exception {
		if(!isRealTimeSellRestDay) {
			if(!"".equals(realSellBeginTime) && !"".equals(realSellEndTime)) {
				int nowTime = Integer.parseInt(DateUtil.getNowDateTime("HHmmss"));
				int beginTime = Integer.parseInt(calculateTime(realSellEndTime, 1, Operator.MINUS));
				int endTime = Integer.parseInt(calculateTime(realSellEndTime, 58, Operator.PLUS));
				
				if(beginTime <= nowTime && nowTime <= endTime) {
					return true;
				}
			}
		}
		
		return false;
	}
	
	/**
	 * <pre>
	 * 처리내용: 지금이 케이지트레이딩 개장시간 1분 뒤 범위 인지 아닌지 확인한다.
	 * </pre>
	 * @date 2022. 5. 20.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 20.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	public boolean isSorinRealSellBeginAfterOneMinuteTime() throws Exception {
		if(!isRealTimeSellRestDay) {
			if(!"".equals(realSellBeginTime) && !"".equals(realSellEndTime)) {
				int nowTime = Integer.parseInt(DateUtil.getNowDateTime("HHmmss"));
				int beginTime = Integer.parseInt(calculateTime(realSellBeginTime, 59, Operator.PLUS));
				int endTime = Integer.parseInt(calculateTime(realSellBeginTime, 118, Operator.PLUS));
				
				if(beginTime <= nowTime && nowTime <= endTime) {
					return true;
				}
			}
		}
		
		return false;
	}
	
	/**
	 * <pre>
	 * 처리내용: 개장 후 LME 데이터 최초 수신인지에 대한 확인값을 setting 한다.
	 * </pre>
	 * @date 2022. 5. 20.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 20.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @param set
	 */
	public void setReadytoLmeStartData(String metalCode, boolean set) {
		
		if(isReadytoStartLmeDataMap == null) {
			isReadytoStartLmeDataMap = new HashMap<String, Boolean>();
		}
		
		if(!isReadytoStartLmeDataMap.containsKey(metalCode)) {
			isReadytoStartLmeDataMap.put(metalCode, set);
		} else {
			isReadytoStartLmeDataMap.replace(metalCode, set);
		}
		
		log.info("==================Set ready to LME start data===================");
		log.info("metalCode : " + metalCode + ",isReadytoStartLmeData : " + set);
		log.info("================================================================");
	}
	
	/**
	 * <pre>
	 * 처리내용: 개장 후 LME 데이터의 최초 수인인지 확인값을 가져온다.
	 * </pre>
	 * @date 2022. 5. 20.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 20.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @return
	 */
	public boolean getReadytoStartLmeData(String metalCode) {
		if(isReadytoStartLmeDataMap == null) {
			isReadytoStartLmeDataMap = new HashMap<String, Boolean>();
		}
		
		if(!isReadytoStartLmeDataMap.containsKey(metalCode)) {
			isReadytoStartLmeDataMap.put(metalCode, false);
		} 
		
		return isReadytoStartLmeDataMap.get(metalCode);
	}
	
	/**
	 * <pre>
	 * 처리내용: 개장 후 가격 데이터 최초 생성인지에 대한 확인값을 setting 한다.
	 * </pre>
	 * @date 2023. 11. 20.
	 * @author bok3117	
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일				작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 11. 20.	bok3117			최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @param set
	 */
	public void setChecktoSelStartData(String metalCode, boolean set) {
		
		if(isReadytoCheckSelDataMap == null) {
			isReadytoCheckSelDataMap = new HashMap<String, Boolean>();
		}
		
		if(!isReadytoCheckSelDataMap.containsKey(metalCode)) {
			isReadytoCheckSelDataMap.put(metalCode, set);
		} else {
			isReadytoCheckSelDataMap.replace(metalCode, set);
		}
		
		log.info("==================Set ready to Sel check data===================");
		log.info("metalCode : " + metalCode + ", isReadytoCheckSelData: " + set);
		log.info("================================================================");
	}
	
	/**
	 * <pre>
	 * 처리내용: 개장 후 가격 데이터 최초 생성인지에 대한 확인값을 가져온다.
	 * </pre>
	 * @date 2023. 11. 20.
	 * @author bok3117	
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일				작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 11. 20.	bok3117			최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @param set
	 */
	public boolean getChecktoSelStartData(String metalCode) {
		if(isReadytoCheckSelDataMap == null) {
			isReadytoCheckSelDataMap = new HashMap<String, Boolean>();
		}
		
		if(!isReadytoCheckSelDataMap.containsKey(metalCode)) {
			isReadytoCheckSelDataMap.put(metalCode, false);
		} 
		
		return isReadytoCheckSelDataMap.get(metalCode);
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 당일 휴무시간 유무를 판단한다.
	 * </pre>
	 * @date 2023. 12. 15.
	 * @author bok3117	
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일				작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 12. 15.	bok3117			최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param 
	 * @return boolean
	 */
	public boolean checkTodayHvofTime() throws Exception {
		SimpleDateFormat yyyyMMdd = new SimpleDateFormat("yyyyMMdd");
		Date date = new Date();
		String today = yyyyMMdd.format(date);
		
		if(hvofApplcDe.equals(today)) {
			int nowTime = Integer.parseInt(DateUtil.getNowDateTime("HHmmss"));
			int applcBeginTimeIntgr = Integer.parseInt(applcBeginTime);
			int applcEndTimeIntgr = Integer.parseInt(applcEndTime);
			
			if(applcBeginTimeIntgr <= nowTime && nowTime <= applcEndTimeIntgr) {
				log.info("==================휴무시간 O===================");
				return true;
			}
		}
		return false;
	}
	
	/**
	 * <pre>
	 * 처리내용: BO에 쓰일 신호등 값을 setting 한다.
	 * </pre>
	 * @date 2022. 5. 20.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 20.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param status
	 */
	public void setLmeStatusCode(LmeStatus status) {
		lmeStatusCode = status.value;
		
		log.info("======================Set LME status Code=======================");
		log.info("lmeStatusCode : " + lmeStatusCode);
		log.info("================================================================");
	}
	
	/**
	 * <pre>
	 * 처리내용: BO에 쓰일 신호등 값을 가져온다.
	 * </pre>
	 * @date 2022. 5. 20.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 20.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 */
	public int getLmeStatusCode() {
		return lmeStatusCode;
	}
	
	/**
	 * <pre>
	 * 처리내용: spread 변동분 오휴에 휴식시간(마감시간까지)을 계산하여 반환한다.
	 * </pre>
	 * @date 2022. 5. 20.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 20.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	public int getRestRealSellEndTimeSecond() throws Exception {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd HHmmss");
		
		Calendar calCurrentTime = Calendar.getInstance();
		calCurrentTime.setTime(dateFormat.parse(DateUtil.getNowDateTime("yyyyMMdd HHmmss")));
		
		Calendar calEndTime = Calendar.getInstance();
		calEndTime.setTime(dateFormat.parse(DateUtil.getNowDateTime("yyyyMMdd " + realSellEndTime)));
		
		return (int)((calEndTime.getTimeInMillis() - calCurrentTime.getTimeInMillis()) / 1000);
	}
	
	/**
	 * <pre>
	 * 처리내용: 환율 상태 코드를 설정한다.
	 * </pre>
	 * @date 2022. 6. 14.
	 * @author srec0064
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 6. 14.		srec0064		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param status
	 */
	public void setEhgtStatusCode(EhgtStatus status) {
		ehgtStatusCode = status.value;
	}
	
	/**
	 * <pre>
	 * 처리내용: 환율 상태 코드를 가져온다.
	 * </pre>
	 * @date 2022. 6. 14.
	 * @author srec0064
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 6. 14.		srec0064		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 */
	public int getEhgtStatusCode() {
		return ehgtStatusCode;
	}
	
	/**
	 * <pre>
	 * 처리내용: lme(테스트를 위한 변수)
	 * </pre>
	 * @date 2022. 10. 6.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 6.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param status
	 */
	public void setIsLmeReceive(int status) {
		isLmeReceive = status;
	}
	
	public int getIsLmeReceive() {
		return isLmeReceive;
	}
	
	/**
	 * <pre>
	 * 처리내용: 환율(테스트를 위한 변수)
	 * </pre>
	 * @date 2022. 10. 6.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 6.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param status
	 */
	public void setIsEhgtReceive(int status) {
		isEhgtReceive = status;
	}
	
	public int getIsEhgtReceive() {
		return isEhgtReceive;
	}
	
	/**
	 * <pre>
	 * 처리내용: 휴무시간을 delete한다.
	 * </pre>
	 * @date 2022. 6. 16.
	 * @author srec0064
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 6. 16.		srec0064		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param restSecond
	 * @param rm
	 * @throws Exception
	 */
	public void deleteRestTime(String rm) throws Exception {
		ClosedHoursVo vo = new ClosedHoursVo();
		vo.setApplcDe(DateUtil.getNowDateTime("yyyyMMdd"));
		vo.setDeleteAt("Y");
		vo.setRm(rm);
		
		etcService.deleteItHvofTimeManageBas(vo);
	}
	
	/**
	 * <pre>
	 * 처리내용: LME 데이터 오류 시간을 체크한다.
	 * </pre>
	 * @date 2022. 7. 26.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 23.			srec0064			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public int getGapTime() throws Exception {
		ClosedHoursVo vo = new ClosedHoursVo();
		vo.setApplcDe(DateUtil.getNowDateTime("yyyyMMdd"));
		vo.setApplcBeginTime(DateUtil.getNowDateTime("HHmmss"));
		
		return etcService.getGapTime(vo);
	}
	
	/**
	 * <pre>
	 * 처리내용: startLmeData 메시지 전송에 대한 확인값을 setting 한다.
	 * </pre>
	 * @date 2022. 8. 23.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 23.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @param set
	 */
	public void setPubMessageStartLmeData(String metalCode, boolean set) {
		
		if(isPubMessageStartLmeDataMap == null) {
			isPubMessageStartLmeDataMap = new HashMap<String, Boolean>();
		}
		
		if(!isPubMessageStartLmeDataMap.containsKey(metalCode)) {
			isPubMessageStartLmeDataMap.put(metalCode, set);
		} else {
			isPubMessageStartLmeDataMap.replace(metalCode, set);
		}
		
		log.info("==================publish Message to StartLmeData===================");
		log.info("metalCode : " + metalCode + ", isPubMessageStartLmeData:" + set);
		log.info("================================================================");
	}
	
	/**
	 * <pre>
	 * 처리내용: startLmeData 메시지 전송에 대한 확인값을 가져온다.
	 * </pre>
	 * @date 2022. 8. 23.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 23.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @return
	 */
	public boolean getPubMessageStartLmeData(String metalCode) {
		if(isPubMessageStartLmeDataMap == null) {
			isPubMessageStartLmeDataMap = new HashMap<String, Boolean>();
		}
		
		if(!isPubMessageStartLmeDataMap.containsKey(metalCode)) {
			isPubMessageStartLmeDataMap.put(metalCode, false);
		} 
		
		return isPubMessageStartLmeDataMap.get(metalCode);
	}
	
	/**
	 * <pre>
	 * 처리내용: 개장 후 종목별 데이터 최초 수신인지에 대한 확인값을 setting 한다.
	 * </pre>
	 * @date 2023. 7. 19.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 19.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param groupKey
	 * @param set
	 */
	public void setReadytoGroupStartData(String groupKey, boolean set) {
		
		if(isReadytoStartGroupDataMap == null) {
			isReadytoStartGroupDataMap = new HashMap<String, Boolean>();
		}
		
		if(!isReadytoStartGroupDataMap.containsKey(groupKey)) {
			isReadytoStartGroupDataMap.put(groupKey, set);
		} else {
			isReadytoStartGroupDataMap.replace(groupKey, set);
		}
		
		log.info("==================Set ready to Group start data===================");
		log.info("groupKey : " + groupKey + ", isReadytoStartGroupData : " + set);
		log.info("================================================================");
	}
	
	/**
	 * <pre>
	 * 처리내용: 개장 후 종목별 데이터 최초 수신인지에 대한 확인값을 가져온다.
	 * </pre>
	 * @date 2023. 7. 19.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 19.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param groupKey
	 * @return
	 */
	public boolean getReadytoGroupStartData(String groupKey) {
		if(isReadytoStartGroupDataMap == null) {
			isReadytoStartGroupDataMap = new HashMap<String, Boolean>();
		}
		
		if(!isReadytoStartGroupDataMap.containsKey(groupKey)) {
			isReadytoStartGroupDataMap.put(groupKey, false);
		} 
		
		return isReadytoStartGroupDataMap.get(groupKey);
	}
	
	/**
	 * <pre>
	 * 처리내용: 니켈 상태 코드를 설정한다.
	 * </pre>
	 * @date 2023. 8. 9.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 9.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param status
	 */
	public void setNickelStatusCode(NickelStatus status) {
		nickelStatusCode = status.value;
		
		if(nickelStatusCode == NickelStatus.FAIL.value) {
			log.info("======================Set Nickel status Fail=======================");
			log.info("nickelStatusCode : " + nickelStatusCode);
			log.info("================================================================");
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 니켈 상태코드를 가져온다.
	 * </pre>
	 * @date 2023. 8. 9.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 9.			srec0064			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public int getNickelStatusCode() {
		return nickelStatusCode;
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 한국공휴일 여부 조회
	 * </pre>
	 * @date 2023. 12. 29.
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 12. 29.			sumin			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public Boolean getIsRestDay() throws Exception {
		return isRestDay;
	}
}
