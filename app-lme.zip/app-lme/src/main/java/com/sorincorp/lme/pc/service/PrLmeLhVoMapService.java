package com.sorincorp.lme.pc.service;

import com.sorincorp.lme.spclty.model.IfLmeSpcltyLhVo;

public interface PrLmeLhVoMapService {

	IfLmeSpcltyLhVo getPrLmeSpcltyLhBasVo(String metalCodeByProperties, String prPcStdrBasVoConstant);

	//void clearPrLmePcStdrBasVo();
}