package com.sorincorp.lme.spclty.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class IfLmeSpcltyVo implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = -5690347202915461067L;
	/**
     * 수신 일시
    */
    private String receptDatetime;
    /**
     * 전문 타입
    */
    private String type;
    /**
     * 전문
    */
    private String spclty;
}