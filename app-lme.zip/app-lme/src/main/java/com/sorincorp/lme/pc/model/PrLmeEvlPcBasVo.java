package com.sorincorp.lme.pc.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class PrLmeEvlPcBasVo implements Serializable{	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5631606272296191496L;
	
	/******  JAVA VO CREATE : PR_LME_EVL_PC_BAS(가격_LME 평가 가격 기본)                                                                     ******/
    /**       * 금속 코드      */      private String metalCode;
    /**       * 발생 일자      */      private String occrrncDe;
    /**       * 평가 일자      */      private String evlDe;
    /**       * LME 평가 가격 순번      */      private String lmeEvlPcSn;
    /**       * 평가 가격      */      private java.math.BigDecimal evlPc;
    /**       * 삭제 일시      */      private java.sql.Timestamp deleteDt;
    /**       * 삭제 여부      */      private String deleteAt;
    /**       * 최초 등록자 아이디      */      private String frstRegisterId;
    /**       * 최초 등록 일시      */      private java.sql.Timestamp frstRegistDt;
    /**       * 최종 변경자 아이디      */      private String lastChangerId;
    /**       * 최종 변경 일시      */      private java.sql.Timestamp lastChangeDt;
    
    /**
     * schedule 동작 여부
    */
    private boolean isReadyToSchedule;
    
}