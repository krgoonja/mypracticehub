package com.sorincorp.lme.limit.mapper;

import java.util.List;

import com.sorincorp.comm.order.model.CommLimitOrderRedisMsgVO;

public interface OrLimitManageMapper {
	/**
	 * <pre>
	 * 처리내용: 지정가 주문 초기 정보를 가져온다.
	 * </pre>
	 * @date 2023. 3. 28.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 28.			srec0064			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<CommLimitOrderRedisMsgVO> selectOrLimitOrderBas();
}
