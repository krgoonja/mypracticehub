package com.sorincorp.lme.util;

public class SerialUtils {
	public static int serialNum;

	public static void initial() {
		SerialUtils.serialNum = 0;
	}

	public static String getSerial() {
		serialNum = serialNum + 1;
		if(serialNum == 1000000) {
			initial();
		}
		
		return String.format("%06d", serialNum);
	}
}
