package com.sorincorp.lme.spclty.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class IfLmeSpcltyLaVo  implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 2055558209196056172L;
	/**
     * 수신일시
    */
    private String receptDatetime;
    /**
     * 전문타입
    */
    private String type;
    /**
     * 종목코드(삼성선물용)
    */
    private String gicName;
    /**
     * 종목코드(로이터)
    */
    private String ricName;
    /**
     * 선물현물스프레드구분
    */
    private String kind;
    /**
     * 영국영업일자
    */
    private String tradeDate;
    /**
     * 전영업일자
    */
    private String prevDate;
    /**
     * 선물공시가격매수
    */
    private String futBid;
    /**
     * 선물공시가격매도
    */
    private String futAsk;
    /**
     * 현물공시가격매수
    */
    private String cashBid;
    /**
     * 현물공시가격매도
    */
    private String cashAsk;
    /**
     * 현물만기일자
    */
    private String cashExpirDate;
    /**
     * 수신일자
    */
    private String receptDate;
    /**
     * 수신시각
    */
    private String receptTime;
}