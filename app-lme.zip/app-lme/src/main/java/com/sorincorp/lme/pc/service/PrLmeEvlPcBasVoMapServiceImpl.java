package com.sorincorp.lme.pc.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.sorincorp.lme.pc.model.PrLmeEvlPcBasVo;

@Service
public class PrLmeEvlPcBasVoMapServiceImpl implements PrLmeEvlPcBasVoMapService{
	
	private Map<String, PrLmeEvlPcBasVo> prLmeEvlPcBasVoMap;
	
	public PrLmeEvlPcBasVoMapServiceImpl() {
		if(prLmeEvlPcBasVoMap == null) {
			this.prLmeEvlPcBasVoMap = new HashMap<String, PrLmeEvlPcBasVo>();
		}
	}
	
	public PrLmeEvlPcBasVo getPrLmeEvlPcBasVo(String metalCodeByProperties) {
		
		if(!prLmeEvlPcBasVoMap.containsKey(metalCodeByProperties)) {
			prLmeEvlPcBasVoMap.put(metalCodeByProperties, new PrLmeEvlPcBasVo());
		} 
		
		return prLmeEvlPcBasVoMap.get(metalCodeByProperties);
	}
	
}