package com.sorincorp.lme.spclty.service;

import com.sorincorp.lme.spclty.model.IfLmeSpcltyLaVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLbVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLcVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLeVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLgVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLhVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLoVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLsVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLvVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyVo;

public interface SpcltyService {
	/**
	 * <pre>
	 * 인터페이스 LME 전문
	 * </pre>
	 * @date 2021. 10. 18.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 18.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	void insertIfLmeSpclty(IfLmeSpcltyVo vo) throws Exception; 
	
	/**
	 * <pre>
	 * 인터페이스_LME 전문 LA 공시가격
	 * </pre>
	 * @date 2021. 10. 18.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 18.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	void insertIfLmeSpcltyLa(IfLmeSpcltyLaVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 인터페이스_LME 전문 LB 종목마스터
	 * </pre>
	 * @date 2021. 10. 18.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 18.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	void insertIfLmeSpcltyLb(IfLmeSpcltyLbVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 인터페이스_LME 전문 LC 체결가
	 * </pre>
	 * @date 2021. 10. 18.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 18.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	void insertIfLmeSpcltyLc(IfLmeSpcltyLcVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 인터페이스_LME 전문 LE 평가가격
	 * </pre>
	 * @date 2021. 10. 18.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 18.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	void insertIfLmeSpcltyLe(IfLmeSpcltyLeVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 인터페이스_LME 전문 LH 선물호가
	 * </pre>
	 * @date 2021. 10. 18.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 18.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	void insertIfLmeSpcltyLh(IfLmeSpcltyLhVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 인터페이스_LME 전문 LG 일지역등급별 거래량
	 * </pre>
	 * @date 2021. 10. 18.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 18.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	void insertIfLmeSpcltyLg(IfLmeSpcltyLgVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 인터페이스_LME 전문 LO 미결제
	 * </pre>
	 * @date 2021. 10. 18.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 18.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	void insertIfLmeSpcltyLo(IfLmeSpcltyLoVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 인터페이스_LME 전문 LS 재고량
	 * </pre>
	 * @date 2021. 10. 18.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 18.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	void insertIfLmeSpcltyLs(IfLmeSpcltyLsVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 인터페이스_LME 전문 LV 통화별거래량
	 * </pre>
	 * @date 2021. 10. 18.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 18.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	void insertIfLmeSpcltyLv(IfLmeSpcltyLvVo vo) throws Exception;
	
}
