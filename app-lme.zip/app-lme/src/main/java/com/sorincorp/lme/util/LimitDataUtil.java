package com.sorincorp.lme.util;

public class LimitDataUtil {

	public enum LimitOrderSttusCode {
		INSERT("I"), UPDATE("U"), DELETE("D");
		public final String value;
		
		LimitOrderSttusCode(String value) {
			this.value = value;
		}
	}
	public final static String BRAND_UNRELATED = "0000000000";	// 브랜드 무관
}
