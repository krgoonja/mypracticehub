package com.sorincorp.lme.pc.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.pcInfo.model.PrPremiumSelVO;

public interface PrPremiumSelVOService {

	Map<String, List<PrPremiumSelVO>> getPrPremiumSelVOMap();
	
	List<PrPremiumSelVO> getPrPremiumSelVOMap(String metalCode);
	
	void setPrPremiumSelVOMap(String metalCode, List<PrPremiumSelVO> prPremiumSelVOMap);
}
