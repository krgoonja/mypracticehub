package com.sorincorp.lme.pc.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class PrLmePcStdrBasVo implements Serializable{
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 7669734110808122971L;
	/**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 발생 일자
    */
    private String occrrncDe;
    /**
     * 발생 년 주
    */
    private String occrrncYyWeek;
    /**
     * 발생 년 월
    */
    private String occrrncYyMt;
    /**
     * 발생 년 분기
    */
    private String occrrncYyQu;
    /**
     * 발생 년
    */
    private String occrrncYy;
    /**
     * 발생 시간
    */
    private String occrrncTime;
    /**
     * 발생 순번
    */
    private String occrrncSn;
    /**
     * LME 가격 실시간 순번
    */
    private String lmePcRltmSn;
    /**
     * LME 가격 01 분 순번
     */
    private String lmePc01MinSn;
    /**
     * LME 가격 30 분 순번
     */
    private String lmePc30MinSn;
    /**
     * LME 가격 60분 순번
     */
    private String lmePc60MinSn;
    /**
     * LME 가격 일 순번
     */
    private String lmePcDeSn;
    /**
     * LME 가격 주 순번
     */
    private String lmePcYyWeekSn;
    /**
     * LME 가격 월 순번
     */
    private String lmePcYyMtSn;
    /**
     * LME 가격 분기 순번
     */
    private String lmePcYyQuSn;
    /**
     * LME 가격 년 순번
     */
    private String lmePcYySn;
    
    /**
     * LME 영업 일자
    */
    private String lmeBsnDe;
    /**
     * 시작 가격
    */
    private java.math.BigDecimal beginPc;
    /**
     * 종료 가격
    */
    private java.math.BigDecimal endPc;
    /**
     * 최고 가격
    */
    private java.math.BigDecimal topPc;
    /**
     * 최저 가격
    */
    private java.math.BigDecimal lwetPc;
    /**
     * 대비 가격
    */
    private java.math.BigDecimal versusPc;
    /**
     * 대비 비율
    */
    private java.math.BigDecimal versusRate;
    /**
     * 거래 수량
    */
    private int delngQy;
    /**
     * 누적 거래 수량
    */
    private int accmltDelngQy;
    /**
     * 스프레드
    */
    private java.math.BigDecimal spread;
    /**
     * 3개월 시작 가격
    */
    private java.math.BigDecimal threemonthBeginPc;
    /**
     * 3개월 종료 가격
    */
    private java.math.BigDecimal threemonthEndPc;
    /**
     * 3개월 최고 가격
    */
    private java.math.BigDecimal threemonthTopPc;
    /**
     * 3개월 최저 가격
    */
    private java.math.BigDecimal threemonthLwetPc;
    /**
     * 3개월 대비 가격
    */
    private java.math.BigDecimal threemonthVersusPc;
    /**
     * 3개월 대비 비율
    */
    private java.math.BigDecimal threemonthVersusRate;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;

    /* 하위는 LME 조정 가격 관련 항목들 */
    /**
     * LME 조정 계수
    */
    private java.math.BigDecimal lmeMdatCffcnt;
    /**
     * 시작 조정 가격
    */
    private java.math.BigDecimal beginMdatPc;
    /**
     * 종료 조정 가격
    */
    private java.math.BigDecimal endMdatPc;
    /**
     * 최고 조정 가격
    */
    private java.math.BigDecimal topMdatPc;
    /**
     * 최저 조정 가격
    */
    private java.math.BigDecimal lwetMdatPc;
    /**
     * 3개월 시작 조정 가격
    */
    private java.math.BigDecimal threemonthBeginMdatPc;
    /**
     * 3개월 종료 조정 가격
    */
    private java.math.BigDecimal threemonthEndMdatPc;
    /**
     * 3개월 최고 조정 가격
    */
    private java.math.BigDecimal threemonthTopMdatPc;
    /**
     * 3개월 최저 조정 가격
    */
    private java.math.BigDecimal threemonthLwetMdatPc;
}