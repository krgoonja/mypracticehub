package com.sorincorp.lme.pc.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class PrLmePblntfPcBasVo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1862846254024531739L;
	
	
	/******  JAVA VO CREATE : PR_LME_PBLNTF_PC_BAS(가격_LME 공시 가격 기본)                                                                  ******/
    /**       * 금속 코드      */      private String metalCode;
    /**       * 발생 일자      */      private String occrrncDe;
    /**       * LME 공시 가격 순번      */      private String lmePblntfPcSn;
    /**       * 전 영업 일자      */      private String bfeBsnDe;
    /**       * 현물 공시 매수 가격      */      private java.math.BigDecimal acthngPblntfPrchasPc;
    /**       * 현물 공시 매도 가격      */      private java.math.BigDecimal acthngPblntfSalePc;
    /**       * 선물 공시 매수 가격      */      private java.math.BigDecimal ftrsPblntfPrchasPc;
    /**       * 선물 공시 매도 가격      */      private java.math.BigDecimal ftrsPblntfSalePc;
    /**       * 현물 만기 일자      */      private String acthngExprtnDe;
    /**       * 삭제 일시      */      private java.sql.Timestamp deleteDt;
    /**       * 삭제 여부      */      private String deleteAt;
    /**       * 최초 등록자 아이디      */      private String frstRegisterId;
    /**       * 최초 등록 일시      */      private java.sql.Timestamp frstRegistDt;
    /**       * 최종 변경자 아이디      */      private String lastChangerId;
    /**       * 최종 변경 일시      */      private java.sql.Timestamp lastChangeDt;
    
    /**
     * schedule 동작 여부
    */
    private boolean isReadyToSchedule;
    
}