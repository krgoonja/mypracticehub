package com.sorincorp.lme;

import java.math.BigDecimal;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.dynmDiver.comm.DynmDiverSetup;
import com.sorincorp.comm.it.model.ItFtrsFshgManageDtlVo;
import com.sorincorp.comm.it.service.ItBsnManageBasVoService;
import com.sorincorp.comm.it.service.ItFtrsFshgManageDtlVoService;
import com.sorincorp.comm.it.service.ItService;
import com.sorincorp.comm.it.service.ReturnNewItVo;
import com.sorincorp.comm.limit.service.LimitService;
import com.sorincorp.comm.limit.service.OrLimitOrderBasVoMapService;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.PrPremiumSelVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.premium.service.ItPremiumStdrBasVoService;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.lme.constant.PrPcStdrBasVoConstant;
import com.sorincorp.lme.ehgt.model.PrEhgtPcStdrBasVo;
import com.sorincorp.lme.ehgt.service.EhgtService;
import com.sorincorp.lme.ehgt.service.PrEhgtPcStdrBasVoService;
import com.sorincorp.lme.ehgt.service.ReturnNewEhgtVo;
import com.sorincorp.lme.etc.model.CalculateSpreadVo;
import com.sorincorp.lme.etc.model.TodaySpreadVO;
import com.sorincorp.lme.etc.model.ValidLmeSpreadDateVo;
import com.sorincorp.lme.etc.service.EtcService;
import com.sorincorp.lme.limit.service.FindMatchingLimitPriceThreadService;
import com.sorincorp.lme.pc.model.PrLmeEvlPcBasVo;
import com.sorincorp.lme.pc.model.PrLmePblntfPcBasVo;
import com.sorincorp.lme.pc.model.PrLmePcStdrBasVo;
import com.sorincorp.lme.pc.service.PcService;
import com.sorincorp.lme.pc.service.PrLmeEvlPcBasVoMapService;
import com.sorincorp.lme.pc.service.PrLmeLhVoMapService;
import com.sorincorp.lme.pc.service.PrLmePblntfPcBasVoMapService;
import com.sorincorp.lme.pc.service.PrLmePcStdrBasVoMapService;
import com.sorincorp.lme.pc.service.PrPremiumSelVOService;
import com.sorincorp.lme.pc.service.ReturnNewIfVo;
import com.sorincorp.lme.pc.service.ReturnNewLmeVo;
import com.sorincorp.lme.sel.model.PrSelPcStdrBasVo;
import com.sorincorp.lme.sel.service.PrSelPcStdrBasVoMapService;
import com.sorincorp.lme.sel.service.PrSelPremiumService;
import com.sorincorp.lme.sel.service.ReturnNewSelVo;
import com.sorincorp.lme.sel.service.SelService;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLaVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLbVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLcVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLeVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLgVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLhVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLoVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLsVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLvVo;
import com.sorincorp.lme.spclty.service.ReturnNewSpcltyVo;
import com.sorincorp.lme.spclty.service.SpcltyService;
import com.sorincorp.lme.util.FallSelPc;
import com.sorincorp.lme.util.LmeDataUtil;
import com.sorincorp.lme.util.RestDateTime;
import com.sorincorp.lme.util.RestDateTime.EhgtStatus;
import com.sorincorp.lme.util.RestDateTime.LmeStatus;
import com.sorincorp.lme.util.RestDateTime.Operator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ReciveLmeDataByUdpSocket{

	@Autowired
	private SpcltyService spcltyService;

	@Autowired
	private PcService pcService;

	@Autowired
	private ItService itService;

	@Autowired
	private EhgtService ehgtService;

	@Autowired
	private SelService selService;

	@Autowired
	private RedisPubSubService redisPubSubService;

	@Autowired
	private RestDateTime restDateTime;

	@Autowired
	private ReturnNewIfVo returnNewIfVo;

	@Autowired
	private ReturnNewLmeVo returnNewLmeVo;

	@Autowired
	private ReturnNewSelVo returnNewSelVo;

	@Autowired
	private ReturnNewEhgtVo returnNewEhgtVo;

	@Autowired
	private ReturnNewSpcltyVo returnNewSpcltyVo;

	@Autowired
	private ReturnNewItVo returnNewItVo;

	@Autowired
	private FallSelPc fallSelPc;

	@Autowired
	private DynmDiverSetup dynmDiverSetup;

	@Autowired
	private EtcService etcService;

	@Autowired
	private LimitService limitService;

	@Autowired
	private FindMatchingLimitPriceThreadService findMatchingLimitPriceThreadService;

	@Autowired
	private ItPremiumStdrBasVoService itPremiumStdrBasVoService;

	@Autowired
	private PcInfoService pcInfoService;

	@Autowired
	private PrSelPremiumService prSelPremiumService;

	@Autowired
	private PrPremiumSelVOService prPremiumSelVOService;

	@Autowired
	private RedisUtil redisUtil;

	@Value("${spring.lme.udp.ip}")
	private String lmeIp;

	@Value("${spring.lme.udp.port}")
	private int lmePort;

	@Value("${redisPubsub.uri.sel}")
	private String selPcUri;

	@Value("${redisPubsub.uri.selpcAll}")
	private String selpcAllUri;

	@Value("${redisPubsub.uri.premium}")
	private String premiumUri;

	@Value("${redisPubsub.uri.lme}")
	private String lmePcUri;

	@Value("${redisPubsub.uri.fx}")
	private String fxpcUri;

	@Value("${redisPubsub.crncyCode.KRW}")
	private String fxpcKRW;

	@Value("${redisPubsub.uri.sidecar}")
	private String sidecarUri;

	@Value("${redisPubsub.uri.restTime}")
	private String restTimeUri;

	@Value("${redisPubsub.uri.spread}")
	private String spreadUri;

	@Value("${redisPubsub.uri.startLmeData}")
	private String startLmeDataUri;

	@Value("${redisPubsub.uri.testLme}")
	private String testLmeUri;

	@Value("${redisPubsub.uri.lmeLh}")
	private String lmeLhUri;

	@Value("${redisPubsub.uri.limit}")
	private String limitUri;

	@Value("${redisPubsub.uri.prvsnlLimit}")
	private String prvsnlLimitUri;

	@Value("${redisPubsub.uri.properties}")
	private String propertiesUri;
	
	private String LAST_DATA_LMEPC = "lastDataLmepc"; // 레디스로 발행한 마지막 실시간 LME 정보 이름(레디스에 저장할 이름)


	@Value("${metalCode.Zn}") private String metalCodeZn;
	@Value("${metalCode.Pb}") private String metalCodePb;
	@Value("${metalCode.Cu}") private String metalCodeCu;
	@Value("${metalCode.Al}") private String metalCodeAl;
	@Value("${metalCode.Ni}") private String metalCodeNi;
	@Value("${metalCode.Sn}") private String metalCodeSn;
	@Value("${metalCode.list}") private List<String> metalCodeList;
	public static List<String> receiveMetalCodeList;
	public static List<String> errorSpreadMetalCodeList;	//[pje]메탈코드별 스프레드 오류 리스트
	public static Map<String, java.math.BigDecimal> leSpreadMap;			//[pje]메탈코드별 LE 스프레드 map
	public static java.math.BigDecimal niLcSpread;		// 니켈의 lc spread 값

	@Value("${gicName.Zn}") private String gicNameZn;
	@Value("${gicName.Pb}") private String gicNamePb;
	@Value("${gicName.Cu}") private String gicNameCu;
	@Value("${gicName.Al}") private String gicNameAl;
	@Value("${gicName.Ni}") private String gicNameNi;
	@Value("${gicName.Sn}") private String gicNameSn;
	@Value("${gicName.list}") private List<String> gicNameList;

	public static String lmeWebSocketUri;
	public static String selWebSocketUri;
	public static String selpcAllWebsocketUri;
	public static String premiumWebsocketUri;
	public static String fxWebSocketUri;
	public static String sideCarSocketUri;
	public static String restTimeSocketUri;
	public static String spreadSocketUri;
	public static String startLmeDataSocketUri;
	public static String testLmeWebSocketUri;
	public static String lmeLhSocketUri;
	public static String limitSocketUri;
	public static String prvsnlLimitSocketUri;
	public static String lmePropertiesUri;

	public static boolean isReadyToLmeSchedule;
	public static boolean isReadyToSelSchedule;

	private boolean isSocketReciveRun;
	private MulticastSocket socket;
	private DatagramPacket packet;

	private final PrLmePcStdrBasVoMapService prLmePcStdrBasVoMapService;
	private final PrSelPcStdrBasVoMapService prSelPcStdrBasVoMapService;
	private final PrLmeEvlPcBasVoMapService prLmeEvlPcBasVoMapService;
	private final PrLmePblntfPcBasVoMapService prLmePblntfPcBasVoMapService;
	private final PrEhgtPcStdrBasVoService prEhgtPcStdrBasVoService;
	private final ItBsnManageBasVoService itBsnManageBasVoService;
	private final ItFtrsFshgManageDtlVoService itFtrsFshgManageDtlVoService;
	private final PrLmeLhVoMapService prLmeLhVoMapService;
	private final OrLimitOrderBasVoMapService orderLimitOrderBasVoMapService;

	private boolean isLeSpread = false;

	@Autowired
	public ReciveLmeDataByUdpSocket(PrLmePcStdrBasVoMapService prLmePcStdrBasVoMapService
									, PrLmeEvlPcBasVoMapService prLmeEvlPcBasVoMapService
									, PrSelPcStdrBasVoMapService prSelPcStdrBasVoMapService
									, PrLmePblntfPcBasVoMapService prLmePblntfPcBasVoMapService
									, PrEhgtPcStdrBasVoService prEhgtPcStdrBasVoService
									, ItBsnManageBasVoService itBsnManageBasVoService
									, ItFtrsFshgManageDtlVoService itFtrsFshgManageDtlVoService
									, PrLmeLhVoMapService prLmeLhVoMapService
									, OrLimitOrderBasVoMapService orderLimitOrderBasVoMapService) {
		this.prLmePcStdrBasVoMapService = prLmePcStdrBasVoMapService;
		this.prLmeEvlPcBasVoMapService = prLmeEvlPcBasVoMapService;
		this.prSelPcStdrBasVoMapService = prSelPcStdrBasVoMapService;
		this.prLmePblntfPcBasVoMapService = prLmePblntfPcBasVoMapService;
		this.prEhgtPcStdrBasVoService = prEhgtPcStdrBasVoService;
		this.itBsnManageBasVoService = itBsnManageBasVoService;
		this.itFtrsFshgManageDtlVoService = itFtrsFshgManageDtlVoService;
		this.prLmeLhVoMapService = prLmeLhVoMapService;
		this.orderLimitOrderBasVoMapService = orderLimitOrderBasVoMapService;
	}

	/*
	 * 서버 기동시에 실행된다.
	 * 모든 초기 값을 설정하고 서버가 끊어질 때를 대비하여
	 * LME와 판매가격, 상품 관련 가격을
	 * DB에 저장된 최신의 가격으로 가져와 초기값으로 지정한다
	 */
	@PostConstruct
	public void initializeSocket(){
		try {
			log.info("####################### This LmeInterfaceThreadProcess initialization starts #######################");

			restDateTime.initialize();

			fallSelPc.initialize();

			dynmDiverSetup.initialize();

			if(restDateTime.isSorinRealSellBeginTime()) {
				for(String metalCode : metalCodeList) {
					restDateTime.setReadytoLmeStartData(metalCode, true);
					restDateTime.setChecktoSelStartData(metalCode, true);
					restDateTime.setPubMessageStartLmeData(metalCode, true);
				}

				itPremiumStdrBasVoService.getItPremiumStdrBasVo().keySet().stream().forEach(key -> {
					restDateTime.setReadytoGroupStartData(key, true);
				});
			}

			isSocketReciveRun = true;

			receiveMetalCodeList = new ArrayList<String>();
			errorSpreadMetalCodeList = new ArrayList<String>();
			leSpreadMap = new HashMap<>();
			niLcSpread = new java.math.BigDecimal(0);
			lmeWebSocketUri = lmePcUri;
			selWebSocketUri = selPcUri;
			selpcAllWebsocketUri = selpcAllUri;
			premiumWebsocketUri = premiumUri;
			fxWebSocketUri = fxpcUri + "/" + fxpcKRW;
			sideCarSocketUri = sidecarUri;
			restTimeSocketUri = restTimeUri;
			spreadSocketUri = spreadUri;
			startLmeDataSocketUri = startLmeDataUri;
			testLmeWebSocketUri = testLmeUri;
			lmeLhSocketUri = lmeLhUri;
			limitSocketUri = limitUri;
			prvsnlLimitSocketUri = prvsnlLimitUri;
			lmePropertiesUri = propertiesUri;

			socket = new MulticastSocket(lmePort);
			InetAddress address = InetAddress.getByName(lmeIp);
			socket.joinGroup(address);

			byte[] buf = new byte[2048];
			packet = new DatagramPacket(buf, buf.length);

			//prSelPcStdrBasVoMapService.clearPrSelPcStdrBasVo();
			//prEhgtPcStdrBasVoService.clearPrEhgtPcStdrBasVo();

			restDateTime.setLmeStatusCode(LmeStatus.FAIL);
			restDateTime.setEhgtStatusCode(EhgtStatus.FAIL);
//			restDateTime.setNickelStatusCode(NickelStatus.FAIL);

			// 최초 기동 시 이전 정보 받아옴 (연결이 끊어질 떄를 대비)
			itService.selectTopItFtrsFshgManageDtl(); //[pje]추가
			ehgtService.selectTopPrEhgtPcStdrBas();

			pcService.selectTopPrLmeEvlPcBas();
			pcService.selectTopPrLmePcStdrBas();
			pcService.selectTopPrLmePcRltmBas();
			pcService.selectTopPrLmePc01MinBas();
			pcService.selectTopPrLmePc30MinBas();
			pcService.selectTopPrLmePc60MinBas();
			pcService.selectTopPrLmePcDeBas();
			pcService.selectTopPrLmePcWeekBas();
			pcService.selectTopPrLmePcYyMtBas();
			pcService.selectTopPrLmePcYyQuBas();
			pcService.selectTopPrLmePcYyBas();

			selService.selectTopPrSelPcStdrBas();
			selService.selectTopPrSelPcRltmBas();
			selService.selectTopPrSelPc01MinBas();
			selService.selectTopPrSelPc30MinBas();
			selService.selectTopPrSelPc60MinBas();
			selService.selectTopPrSelPcDeBas();
			selService.selectTopPrSelPcWeekBas();
			selService.selectTopPrSelPcYyMtBas();
			selService.selectTopPrSelPcYyQuBas();
			selService.selectTopPrSelPcYyBas();

			isReadyToLmeSchedule = false;
			isReadyToSelSchedule = false;

			restDateTime.setIsLmeReceive(0);
			restDateTime.setIsEhgtReceive(0);

			// 지정가 초기값 세팅
			orderLimitOrderBasVoMapService.setOrderCommLimitOrderRedisMsgVoMap(limitService.loadInitialLimitData());
			log.info("0-0) initial Order Limit Data: " + orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());
			log.info("0-1) before getLimitOrderNoInputAmountVo: " + orderLimitOrderBasVoMapService.getLimitOrderNoInputAmountVo());

			orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap().values().stream()
		 		.flatMap(Set::stream)
		 		.forEach(msgVO -> orderLimitOrderBasVoMapService.getLimitOrderNoInputAmountVo(msgVO.getLimitOrderNo()).setLimitInputAmount(msgVO.getLimitInputAmount()));

			log.info("0-2) after getLimitOrderNoInputAmountVo: " + orderLimitOrderBasVoMapService.getLimitOrderNoInputAmountVo());

			// 가단가 지정가 초기값 세팅
			orderLimitOrderBasVoMapService.setOrderCommPrvsnlLimitOrderRedisMsgVoMap(limitService.loadInitialPrvsnlLimitData());
			log.info("0-3) initial Order Prvsnl Limit Data: " + orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap());
			log.info("0-4) before getPrvsnlLimitOrderNoInputAmountVo: " + orderLimitOrderBasVoMapService.getPrvsnlLimitOrderNoInputAmountVo());

			orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap().values().stream()
				.flatMap(Set::stream)
				.forEach(msgVO -> orderLimitOrderBasVoMapService.getPrvsnlLimitOrderNoInputAmountVo(msgVO.getLimitOrderNo()).setLimitInputAmount(msgVO.getLimitInputAmount()));

			log.info("0-5) after getPrvsnlLimitOrderNoInputAmountVo: " + orderLimitOrderBasVoMapService.getPrvsnlLimitOrderNoInputAmountVo());

			// 프리미엄 가격 초기값 세팅
			Map<String, TreeSet<LivePremiumVO>> originalMap = pcInfoService.getPremiumInfoMap();
			itPremiumStdrBasVoService.setItPremiumStdrBasVo(originalMap);

			for(String metalCode : metalCodeList) {
				// 차트타이틀 초기값 세팅
				changeChartTitleInfo(metalCode);
			}

			log.info("chart title init: " + prPremiumSelVOService.getPrPremiumSelVOMap("7"));

			// 이전 니켈 초기값 세팅
			Map<String, String> map = new HashMap<>();
			map.put("metalCode", metalCodeNi);
			PrLmePcStdrBasVo originalVo = pcService.selectPastLmePc(map);
			BeanUtils.copyProperties(originalVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(PrPcStdrBasVoConstant.PAST_NICKEL));

			log.info("past nickel init: " + prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(PrPcStdrBasVoConstant.PAST_NICKEL));

			// METAL_CODE, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, SEL_PC
			//fallSelPc.calculateSmsPrice("7", 4070000, "20230718120000");
			//fallSelPc.calculateSmsPrice("7", 1570000, "20230718120000");
			//fallSelPc.calculateSmsPrice("7", 1070000, "20230718120000");

			//[pje]최초 기동시 스프레드 값 재확인
			//lmeSchedulerService.checkMatchedLmeSpreadAndCantCheckGicNamesReturn(gicNameList);

		} catch(Exception e) {
			log.error("initializeSocket : " + e.toString() + " -> message : " + e.getMessage());
		} finally {
			log.info("=============================Socket=============================");
			log.info(" Socket IP : " + lmeIp);
			log.info(" Socket Port : " + lmePort);
			log.info(" lmePc : " + ReciveLmeDataByUdpSocket.lmeWebSocketUri);
			log.info(" selPc : " + ReciveLmeDataByUdpSocket.selWebSocketUri);
			log.info(" fxPc : " + ReciveLmeDataByUdpSocket.fxWebSocketUri);
			log.info(" lmeLhUri : " + ReciveLmeDataByUdpSocket.lmeLhSocketUri);
			log.info("================================================================");

			log.info("==========================MetaCodeValue=========================");
			log.info("metalCodeZn : " + metalCodeZn);
			log.info("metalCodePb : " + metalCodePb);
			log.info("metalCodeCu : " + metalCodeCu);
			log.info("metalCodeAl : " + metalCodeAl);
			log.info("metalCodeNi : " + metalCodeNi);
			log.info("metalCodeSn : " + metalCodeSn);
			String metalCodeElem = "";
			for(String metalCode : metalCodeList) {
				metalCodeElem += metalCode + ",";
			}
			log.info("metalCodeList : " + metalCodeElem);
			log.info("================================================================");

			log.info("==========================gicNameValue=========================");
			log.info("gicNameZn : " + gicNameZn);
			log.info("gicNamePb : " + gicNamePb);
			log.info("gicNameCu : " + gicNameCu);
			log.info("gicNameAl : " + gicNameAl);
			log.info("gicNameNi : " + gicNameNi);
			log.info("gicNameSn : " + gicNameSn);
			String gicNameElem = "";
			for(String gicName : gicNameList) {
				gicNameElem += gicName + ",";
			}
			log.info("gicNameList : " + gicNameElem);
			log.info("================================================================");

			log.info("####################### This LmeInterfaceThreadProcess initialization Done. #######################");
		}
	}

	/*
	 * 차트타이틀 가격 갱신
	 */
	public void changeChartTitleInfo(String metalCode) throws Exception {
		log.info( "metalCode :"+ metalCode + " changeChartTitleInfo RUN ");
		try {
			List<PrPremiumSelVO> prPremiumSelVOList = pcInfoService.getChartTitleInfoList(metalCode);

			//if (metalCode.equals("7"))
			//	log.info("prPremiumSelVOList: " + prPremiumSelVOList);
			prPremiumSelVOService.getPrPremiumSelVOMap().remove(metalCode);
			prPremiumSelVOService.getPrPremiumSelVOMap(metalCode).addAll(prPremiumSelVOList);

			redisUtil.setDataJson(LmeDataUtil.SEL_PC_ALL_LIST + metalCode, prPremiumSelVOService.getPrPremiumSelVOMap(metalCode));
			log.info("changeChartTitleInfo END");
		} catch (Exception e) {
			log.error("changeChartTitleInfo ERROR" + e.getMessage());
		}
	}

	/*
	 * 실제로 socket 값을 받아오는 부분. Async로 동작한다.
	 */
	@Async("lmeThreadPoolExcuter")
	public void startReciveSocketData() {
		log.info("startReciveSocketData()");
		while(this.isSocketReciveRun) {
			try {
				//log.info("check isLmeReceive: " + restDateTime.getIsLmeReceive());

				socket.receive(packet);

				LmeDataUtil.pos = 0;

				String msg = new String(packet.getData(), 0, packet.getLength());

				LmeDataUtil.recept_datetime = LmeDataUtil.to_string (msg,20) ;
				LmeDataUtil.type			= LmeDataUtil.to_string (msg,2)  ;

				if(!LmeDataUtil.type.equals("LH")) {
					log.info(" type [" + LmeDataUtil.type + "] Original Packet [" + msg + "]");
				}

				if(restDateTime.getIsLmeReceive() == 1) {	// TODO [pje]주석처리예정
					continue;
				}

				spcltyService.insertIfLmeSpclty(returnNewSpcltyVo.process_Spclty(msg));

				//타입별 전문 저장
				if (LmeDataUtil.type.equals("LA")) {
					IfLmeSpcltyLaVo returnIfVo = returnNewSpcltyVo.process_LA(msg);
					spcltyService.insertIfLmeSpcltyLa(returnIfVo);

					PrLmePblntfPcBasVo returnNowLmePblntfBasVo = returnNewIfVo.process_PrLmePblntfPcBasVoFromIf(returnIfVo);

					if(returnNowLmePblntfBasVo != null) {
						BeanUtils.copyProperties(returnNowLmePblntfBasVo, prLmePblntfPcBasVoMapService.getPrLmePblntfPcBasVo(returnNowLmePblntfBasVo.getMetalCode()));
						pcService.insertPrLmePblntfPcBas(returnNowLmePblntfBasVo);	// [가격_LME 공시 가격 기본] 테이블에 insert
					}
				} else if (LmeDataUtil.type.equals("LB")) {
					IfLmeSpcltyLbVo ifVo = returnNewSpcltyVo.process_LB(msg);
					spcltyService.insertIfLmeSpcltyLb(ifVo);
				} else if (LmeDataUtil.type.equals("LC")) {

					IfLmeSpcltyLcVo returnIfLcVo = returnNewSpcltyVo.process_LC(msg);	// 전문 정보 set

					if(isLeSpread) {
						log.info("===================isLeSpread RUN===================");
						//LE 테이블 스프레드(Default)를 가져온다
						TodaySpreadVO paramVO = new TodaySpreadVO();
						paramVO.setGicName(returnIfLcVo.getGicName());
						paramVO.setCurrentDate(returnIfLcVo.getTradeDate());
						TodaySpreadVO todaySpreadVO = etcService.getTodaySpread(paramVO);

						//LE 테이블 스프레드로 현재가를 재계산
						BigDecimal futureNow = new BigDecimal(returnIfLcVo.getFuturesNow());
						BigDecimal spread = new BigDecimal(todaySpreadVO.getSpread());
						BigDecimal calcNow = futureNow.add(spread);
						log.info("["+returnIfLcVo.getGicName()+"]returnIfLcVo.getNow()["+ returnIfLcVo.getNow() +"] calcNow.toString()[" + calcNow.toString() + "]");
						returnIfLcVo.setNow(calcNow.toString());
						returnIfLcVo.setSpread(todaySpreadVO.getSpread());
					}else {
					}

					spcltyService.insertIfLmeSpcltyLc(returnIfLcVo);

					////////////////// trade_date가 현재 날짜와 일치하지 않으면 인터페이스 INSERT (O) / LME DB에는 INSERT (X) -> LME DB에 INSERT되어야 receiveMetalCodeList.add

					log.info("returnIfLcVo.getReceptTime(): " + Integer.parseInt(returnIfLcVo.getReceptTime()));

					if(!returnIfLcVo.getTradeDate().equals(DateUtil.getNowDateTime("yyyyMMdd")) && Integer.parseInt(returnIfLcVo.getReceptTime()) >= 90000 )
						continue;

					PrLmePcStdrBasVo returnNowLmeStdrBasVoFromIf = returnNewIfVo.process_PrLmePcStdrBasVoFromIf(returnIfLcVo);

					if(returnNowLmeStdrBasVoFromIf != null) {

						if(!receiveMetalCodeList.contains(returnNowLmeStdrBasVoFromIf.getMetalCode()) ) {
							// 스프레드체크
							checkMatchedLmeSpreadAndCantCheckGicNamesReturn(returnIfLcVo.getGicName());

							if(!getMetalCode(returnIfLcVo.getGicName()).equals(metalCodeNi)) {
								receiveMetalCodeList.add(returnNowLmeStdrBasVoFromIf.getMetalCode());
								log.info("receiveMetalCodeList add: " + returnNowLmeStdrBasVoFromIf.getMetalCode());
							}
						}

						if (!ReciveLmeDataByUdpSocket.leSpreadMap.containsKey(returnNowLmeStdrBasVoFromIf.getMetalCode())) {
							// 스프레드체크
							checkMatchedLmeSpreadAndCantCheckGicNamesReturn(returnIfLcVo.getGicName());
						}

						// 메탈코드가 니켈인 경우 continue (LH에서 가격 생성하기 위해)
						if(getMetalCode(returnIfLcVo.getGicName()).equals(metalCodeNi))
							continue;

						processLcLme(returnNowLmeStdrBasVoFromIf.getMetalCode(), returnNowLmeStdrBasVoFromIf);
						processLcSel(returnNowLmeStdrBasVoFromIf.getMetalCode(), returnNowLmeStdrBasVoFromIf);
					}
				} else if (LmeDataUtil.type.equals("LE")) {
					IfLmeSpcltyLeVo returnIfVo = returnNewSpcltyVo.process_LE(msg);
					spcltyService.insertIfLmeSpcltyLe(returnIfVo);

					PrLmeEvlPcBasVo returnNowLmeEvlBasVo = returnNewIfVo.process_PrLmeEvlPcBasVoFromIf(returnIfVo);

					if(returnNowLmeEvlBasVo != null) {
						BeanUtils.copyProperties(returnNowLmeEvlBasVo, prLmeEvlPcBasVoMapService.getPrLmeEvlPcBasVo(returnNowLmeEvlBasVo.getMetalCode()));
						pcService.insertPrLmeEvlPcBas(returnNowLmeEvlBasVo);
					}
				} else if (LmeDataUtil.type.equals("LH")) {
					IfLmeSpcltyLhVo ifVo = returnNewSpcltyVo.process_LH(msg);
					processLhLme(getMetalCode(ifVo.getGicName()), ifVo);
					spcltyService.insertIfLmeSpcltyLh(ifVo);

				  	// LC에서 니켈 스프레드 값이 들어온 경우에만 진행
				  	if (ReciveLmeDataByUdpSocket.niLcSpread.compareTo(BigDecimal.ZERO) == 0) {
				  		log.info("nickel value is zero");
				  		continue;
				  	}

				  	// 메탈코드가 니켈인 경우 가격 생성
				  	if(ifVo.getGicName().equals(gicNameNi)) {
				  		PrLmePcStdrBasVo returnNowLmeStdrBasVoFromIf = returnNewIfVo.process_PrLmePcStdrBasVoFromIfMetalNi(ifVo);

				  		if(returnNowLmeStdrBasVoFromIf == null)
				  			continue;

				  		//BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(PrPcStdrBasVoConstant.NICKEL));
				  		processLcLme(returnNowLmeStdrBasVoFromIf.getMetalCode(), returnNowLmeStdrBasVoFromIf);
						processLcSel(returnNowLmeStdrBasVoFromIf.getMetalCode(), returnNowLmeStdrBasVoFromIf);
				  	}

				} else if (LmeDataUtil.type.equals("LG")) {
					IfLmeSpcltyLgVo ifVo = returnNewSpcltyVo.process_LG(msg);
					spcltyService.insertIfLmeSpcltyLg(ifVo);
				} else if (LmeDataUtil.type.equals("LO")) {
					IfLmeSpcltyLoVo ifVo = returnNewSpcltyVo.process_LO(msg);
					spcltyService.insertIfLmeSpcltyLo(ifVo);
				} else if (LmeDataUtil.type.equals("LS")) {
					IfLmeSpcltyLsVo ifVo = returnNewSpcltyVo.process_LS(msg);
					spcltyService.insertIfLmeSpcltyLs(ifVo);
				} else if (LmeDataUtil.type.equals("LV")) {
					IfLmeSpcltyLvVo ifVo = returnNewSpcltyVo.process_LV(msg);
					spcltyService.insertIfLmeSpcltyLv(ifVo);
				}

			} catch(Exception e) {
//				log.error("startReciveSocketData : " + e.toString() + " -> message : " + e.getMessage());
				log.error(ExceptionUtils.getStackTrace(e));
			}
		}

		log.info("----------------------- ReciveLmeDataByUdpSocket is Terminated! -----------------------");
	}

	public void socketClose() {
		this.socket.close();
	}

	public void setSocketReciveRun(boolean isRun) {
		this.isSocketReciveRun = isRun;
	}

	public void setLeSpreadRun(boolean isLeSpread) {
		this.isLeSpread = isLeSpread;
	}

	/*
	 * socket으로 받아온 전문 data를 토대로 계산하여
	 * LME 실시간 data와 LME의 각 분기(1분, 30분...) SingleTone data를 만든다.
	 * 만들어진 모든 SingleTone data는 DB에 저장하고 동시에 redis message broker로 publish한다.
	 */
	private void processLcLme(String metalCode, PrLmePcStdrBasVo returnNowLmeStdrBasVoFromIf) throws Exception{
		/*------------------------ LME 가격 부분 ------------------------*/
		pcService.initializePrLmePcStdrBasVo(returnNowLmeStdrBasVoFromIf);

		PrLmePcStdrBasVo oneMinute = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.ONE_MINUTE);
		PrLmePcStdrBasVo pastOneMinute = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE);
		PrLmePcStdrBasVo thirtyMinute = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.THIRTY_MINUTE);
		PrLmePcStdrBasVo pastThirtyMinute = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE);
		PrLmePcStdrBasVo sixtyMinute = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.SIXTY_MINUTE);
		PrLmePcStdrBasVo pastSixtyMinute = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE);
		PrLmePcStdrBasVo day = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.DAY);
		PrLmePcStdrBasVo pastDay = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_DAY);
		PrLmePcStdrBasVo week = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.WEEK);
		PrLmePcStdrBasVo pastWeek = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_WEEK);
		PrLmePcStdrBasVo month = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.MONTH);
		PrLmePcStdrBasVo pastMonth = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_MONTH);
		PrLmePcStdrBasVo quarter = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.QUARTER);
		PrLmePcStdrBasVo pastQuarter = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_QUARTER);
		PrLmePcStdrBasVo year = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.YEAR);
		PrLmePcStdrBasVo pastYear = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_YEAR);

		Map<String, Boolean> oneMinuteChange	= checkChangeLme(returnNowLmeStdrBasVoFromIf.getMetalCode(), returnNowLmeStdrBasVoFromIf.getOccrrncTime(), oneMinute.getOccrrncTime(), "01");
		Map<String, Boolean> thirtyMinuteChange	= checkChangeLme(returnNowLmeStdrBasVoFromIf.getMetalCode(), returnNowLmeStdrBasVoFromIf.getOccrrncTime(), thirtyMinute.getOccrrncTime(), "30");
		Map<String, Boolean> sixtyMinuteChange	= checkChangeLme(returnNowLmeStdrBasVoFromIf.getMetalCode(), returnNowLmeStdrBasVoFromIf.getOccrrncTime(), sixtyMinute.getOccrrncTime(), "60");
		Map<String, Boolean> dayChange			= checkChangeLme(returnNowLmeStdrBasVoFromIf.getMetalCode(), returnNowLmeStdrBasVoFromIf.getOccrrncTime(), day.getOccrrncTime(), "DE");

		PrLmePcStdrBasVo returnLme01Minutes = returnNewLmeVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, oneMinute, pastOneMinute, "01", oneMinuteChange);
		PrLmePcStdrBasVo returnLme30Minutes = returnNewLmeVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, thirtyMinute, pastThirtyMinute, "30", thirtyMinuteChange);
		PrLmePcStdrBasVo returnLme60Minutes = returnNewLmeVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, sixtyMinute, pastSixtyMinute, "60", sixtyMinuteChange);
		PrLmePcStdrBasVo returnLmeDe = returnNewLmeVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, day, pastDay, "DE", dayChange);
		PrLmePcStdrBasVo returnLmeWeek = returnNewLmeVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, week, pastWeek, "WK", dayChange);
		PrLmePcStdrBasVo returnLmeMt = returnNewLmeVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, month, pastMonth, "MT", dayChange);
		PrLmePcStdrBasVo returnLmeQu = returnNewLmeVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, quarter, pastQuarter, "QU", dayChange);
		PrLmePcStdrBasVo returnLmeYy = returnNewLmeVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, year, pastYear, "YY", dayChange);

		// 케이지트레이딩 운영 시작시간에 restDateTime.setReadytoLmeStartData(metalCode, true);
		if(restDateTime.getReadytoStartLmeData(metalCode)) {
			log.info("####################### LME start data recieved in LME area " + metalCode + "#######################");

			pastOneMinute.setBeginPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastOneMinute.setEndPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastOneMinute.setTopPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastOneMinute.setLwetPc(returnNowLmeStdrBasVoFromIf.getEndPc());

			pastThirtyMinute.setBeginPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastThirtyMinute.setEndPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastThirtyMinute.setTopPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastThirtyMinute.setLwetPc(returnNowLmeStdrBasVoFromIf.getEndPc());

			pastSixtyMinute.setBeginPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastSixtyMinute.setEndPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastSixtyMinute.setTopPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastSixtyMinute.setLwetPc(returnNowLmeStdrBasVoFromIf.getEndPc());

			pastDay.setBeginPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastDay.setEndPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastDay.setTopPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastDay.setLwetPc(returnNowLmeStdrBasVoFromIf.getEndPc());

			pastWeek.setBeginPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastWeek.setEndPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastWeek.setTopPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastWeek.setLwetPc(returnNowLmeStdrBasVoFromIf.getEndPc());

			pastMonth.setBeginPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastMonth.setEndPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastMonth.setTopPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastMonth.setLwetPc(returnNowLmeStdrBasVoFromIf.getEndPc());

			pastQuarter.setBeginPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastQuarter.setEndPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastQuarter.setTopPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastQuarter.setLwetPc(returnNowLmeStdrBasVoFromIf.getEndPc());

			pastYear.setBeginPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastYear.setEndPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastYear.setTopPc(returnNowLmeStdrBasVoFromIf.getEndPc());
			pastYear.setLwetPc(returnNowLmeStdrBasVoFromIf.getEndPc());

			// LME 조정 가격 관련 세팅
			pastOneMinute.setBeginMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastOneMinute.setEndMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastOneMinute.setTopMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastOneMinute.setLwetMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());

			pastThirtyMinute.setBeginMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastThirtyMinute.setEndMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastThirtyMinute.setTopMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastThirtyMinute.setLwetMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());

			pastSixtyMinute.setBeginMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastSixtyMinute.setEndMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastSixtyMinute.setTopMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastSixtyMinute.setLwetMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());

			pastDay.setBeginMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastDay.setEndMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastDay.setTopMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastDay.setLwetMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());

			pastWeek.setBeginMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastWeek.setEndMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastWeek.setTopMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastWeek.setLwetMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());

			pastMonth.setBeginMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastMonth.setEndMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastMonth.setTopMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastMonth.setLwetMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());

			pastQuarter.setBeginMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastQuarter.setEndMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastQuarter.setTopMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastQuarter.setLwetMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());

			pastYear.setBeginMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastYear.setEndMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastYear.setTopMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
			pastYear.setLwetMdatPc(returnNowLmeStdrBasVoFromIf.getEndMdatPc());
		}

		PrLmePcStdrBasVo prLmePcStdrBasVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE);
		if (prLmePcStdrBasVo != null && returnLme01Minutes != null) {
			if(returnLme01Minutes.getLmePc01MinSn() != null && prLmePcStdrBasVo.getLmePc01MinSn() != null) {
				String returnLme01MinutesSn = returnLme01Minutes.getLmePc01MinSn().substring(0, 12);
				String prLmePcStdrBasVoSn = prLmePcStdrBasVo.getLmePc01MinSn().substring(0, 12);
				if (returnLme01MinutesSn.equals(prLmePcStdrBasVoSn)) {
					BeanUtils.copyProperties(returnLme01Minutes, prLmePcStdrBasVo);
				}
			}
		}

		PrLmePcStdrBasVo prLme30PcStdrBasVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE);
		if (prLme30PcStdrBasVo != null && returnLme30Minutes != null) {
			if(returnLme30Minutes.getLmePc30MinSn() != null && prLme30PcStdrBasVo.getLmePc30MinSn() != null) {
				String returnLme30MinutesSn = returnLme30Minutes.getLmePc30MinSn().substring(0, 12);
				String prLme30PcStdrBasVoSn = prLme30PcStdrBasVo.getLmePc30MinSn().substring(0, 12);
				if (returnLme30MinutesSn.equals(prLme30PcStdrBasVoSn)) {
					BeanUtils.copyProperties(returnLme30Minutes, prLme30PcStdrBasVo);
				}
			}
		}

		PrLmePcStdrBasVo prLme60PcStdrBasVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE);
		if (prLme60PcStdrBasVo != null && returnLme60Minutes != null) {
			if(returnLme60Minutes.getLmePc60MinSn() != null && prLme60PcStdrBasVo.getLmePc60MinSn() != null) {
				String returnLme60MinutesSn = returnLme60Minutes.getLmePc60MinSn().substring(0, 12);
				String prLme60PcStdrBasVoSn = prLme60PcStdrBasVo.getLmePc60MinSn().substring(0, 12);
				if (returnLme60MinutesSn.equals(prLme60PcStdrBasVoSn)) {
					BeanUtils.copyProperties(returnLme60Minutes, prLme60PcStdrBasVo);
				}
			}
		}

		if(returnNowLmeStdrBasVoFromIf != null) {
			String hlafMinutes = "";

			int current30Minute = Integer.parseInt(returnNowLmeStdrBasVoFromIf.getLmePcRltmSn().substring(10, 12));

			if(1 <= current30Minute && current30Minute <= 29) {
				hlafMinutes = "00";
			} else if (31 <= current30Minute && current30Minute <= 59) {
				hlafMinutes = "30";
			} else {
				hlafMinutes = returnNowLmeStdrBasVoFromIf.getLmePcRltmSn().substring(10, 12);
			}

			returnNowLmeStdrBasVoFromIf.setLmePc01MinSn(returnNowLmeStdrBasVoFromIf.getLmePcRltmSn().substring(0, 12) + "00" + returnNowLmeStdrBasVoFromIf.getLmePcRltmSn().substring(14, 20));
			returnNowLmeStdrBasVoFromIf.setLmePc30MinSn(returnNowLmeStdrBasVoFromIf.getLmePcRltmSn().substring(0, 10) + hlafMinutes + "00" + returnNowLmeStdrBasVoFromIf.getLmePcRltmSn().substring(14, 20));
			returnNowLmeStdrBasVoFromIf.setLmePc60MinSn(returnNowLmeStdrBasVoFromIf.getLmePcRltmSn().substring(0, 10) + "0000" + returnNowLmeStdrBasVoFromIf.getLmePcRltmSn().substring(14, 20));
			returnNowLmeStdrBasVoFromIf.setLmePcDeSn(returnNowLmeStdrBasVoFromIf.getLmePcRltmSn().substring(0, 8) + "000000" + returnNowLmeStdrBasVoFromIf.getLmePcRltmSn().substring(14, 20));
			returnNowLmeStdrBasVoFromIf.setLmePcYyMtSn(returnNowLmeStdrBasVoFromIf.getLmePcRltmSn().substring(0, 6) + "01000000" + returnNowLmeStdrBasVoFromIf.getLmePcRltmSn().substring(14, 20));
		}

		log.info("lme web socket uri: " + ReciveLmeDataByUdpSocket.lmeWebSocketUri + "/" + metalCode);
		
		// 실시간 데이터 발행하기 전에 레디스에 한번 저장한다 (key-value 형태), 레디스로 발행한 마지막 실시간 LME 정보
		ObjectMapper mapper = new ObjectMapper(); 
		String lmeJsonString = mapper.writeValueAsString(returnNowLmeStdrBasVoFromIf);
		redisUtil.setDataJson(LAST_DATA_LMEPC + metalCode, lmeJsonString);
		
		redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.lmeWebSocketUri + "/" + metalCode, ReciveLmeDataByUdpSocket.lmeWebSocketUri + "/" + metalCode, returnNowLmeStdrBasVoFromIf);

		log.info("lme web socket send success");
		/////
		redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.testLmeWebSocketUri + "/" + metalCode, ReciveLmeDataByUdpSocket.testLmeWebSocketUri + "/" + metalCode, "LME_TEST" + returnNowLmeStdrBasVoFromIf);

		// 이전 가격과 비교하기 위해 복사
		BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.STDR));
		BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.RLTM));
		BeanUtils.copyProperties(returnLme01Minutes, oneMinute);		// 계산된1분값을 1분 변수에 넣어서 재계산하기 위함
		BeanUtils.copyProperties(returnLme30Minutes, thirtyMinute);
		BeanUtils.copyProperties(returnLme60Minutes, sixtyMinute);
		BeanUtils.copyProperties(returnLmeDe, day);
		BeanUtils.copyProperties(returnLmeWeek, week);
		BeanUtils.copyProperties(returnLmeMt, month);
		BeanUtils.copyProperties(returnLmeQu, quarter);
		BeanUtils.copyProperties(returnLmeYy, year);

		pcService.insertPrLmePcStdrBas(returnNowLmeStdrBasVoFromIf);	// [가격_LME 가격 기준 기본] 테이블에 insert
		pcService.insertPrLmePcRltmBas(returnNowLmeStdrBasVoFromIf);	// [가격_LME 가격 실시간 기본] 테이블에 insert

		isReadyToLmeSchedule = true;	// DB에 저장하기 위해 (스케줄 초기화)
	}


	private void processLhLme(String metalCode, IfLmeSpcltyLhVo ifVo) throws Exception{
		redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.lmeLhSocketUri + "/" + metalCode, ReciveLmeDataByUdpSocket.lmeLhSocketUri + "/" + metalCode, ifVo);
	}

	/*
	 * socket 으로 받아온 전문 data를 토대로 계산하여
	 * LME 실시간 data와 LME의 각 분기(1분, 30분…) singleTone data를 만든다.
	 * 만들어진 모든 singleTone data는 DB에 저장하고 동시에 redis message borker로 publish한다.
	 */
	private void processLcSel(String metalCode, PrLmePcStdrBasVo returnNowLmeStdrBasVoFromIf) throws Exception{

		/*------------------------ 판매 가격 부분 ------------------------*/
		selService.initializePrSelPcStdrBasVo(returnNowLmeStdrBasVoFromIf);

		if(restDateTime.getEhgtStatusCode() == EhgtStatus.FAIL.value) {
			isReadyToSelSchedule = true;

			log.info("####################### EHGT data is not ready. #######################");

			return;
		}

		//휴일일 떄 가격생성 하지 않음.
		if(restDateTime.getIsRestDay()) {
			isReadyToSelSchedule = true;

			log.info("####################### REST DAY  #######################");

			return;
		}

		//생성된 종가가 100만원 미만일 경우 임시휴장한다.
		/*
		if(returnSelStdrVo.getEndPc() < 1000000) {
			isReadyToSelSchedule = true;

			if(restDateTime.getGapTime() <= 60 && restDateTime.getGapTime() != 0)
				return;

			restDateTime.updateRestTime(64, "판매가격 오류로 인한 64초 연장");
			restDateTime.initialize();
			redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.restTimeSocketUri, ReciveLmeDataByUdpSocket.restTimeSocketUri, "setRestTime");

			log.info("####################### END_PC <= 1000000  #######################");
			return;
		}
		*/

		PrSelPcStdrBasVo oneMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.ONE_MINUTE);
		PrSelPcStdrBasVo pastOneMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE);
		PrSelPcStdrBasVo thirtyMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.THIRTY_MINUTE);
		PrSelPcStdrBasVo pastThirtyMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE);
		PrSelPcStdrBasVo sixtyMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.SIXTY_MINUTE);
		PrSelPcStdrBasVo pastSixtyMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE);
		PrSelPcStdrBasVo day = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.DAY);
		PrSelPcStdrBasVo pastDay = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_DAY);
		PrSelPcStdrBasVo week = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.WEEK);
		PrSelPcStdrBasVo pastWeek = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_WEEK);
		PrSelPcStdrBasVo month = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.MONTH);
		PrSelPcStdrBasVo pastMonth = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_MONTH);
		PrSelPcStdrBasVo quarter = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.QUARTER);
		PrSelPcStdrBasVo pastQuarter = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_QUARTER);
		PrSelPcStdrBasVo year = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.YEAR);
		PrSelPcStdrBasVo pastYear = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_YEAR);

		PrLmeEvlPcBasVo returnPrLmeEvlPcBasVo = returnNewLmeVo.process_CopyNewLmeEvlVo(prLmeEvlPcBasVoMapService.getPrLmeEvlPcBasVo(metalCode));
		PrEhgtPcStdrBasVo returnEhgtVo = returnNewEhgtVo.process_CopyNewVo(prEhgtPcStdrBasVoService.getPrEhgtPcStdrBasVo());
		ItFtrsFshgManageDtlVo returnItVo = returnNewItVo.process_CopyNewVo(itFtrsFshgManageDtlVoService.getItFtrsFshgManageDtlVo(returnNowLmeStdrBasVoFromIf.getMetalCode()));
		PrSelPcStdrBasVo returnPastSelStdrAlVo = returnNewSelVo.process_CopyNewSelStdrVo(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.STDR));

		Map<String, Boolean> oneMinuteChange	= returnNewSelVo.checkChangeSel(returnNowLmeStdrBasVoFromIf.getMetalCode(), DateUtil.getNowDateTime("HHmmss"), oneMinute.getOccrrncTime(), "01");
		Map<String, Boolean> thirtyMinuteChange	= returnNewSelVo.checkChangeSel(returnNowLmeStdrBasVoFromIf.getMetalCode(), DateUtil.getNowDateTime("HHmmss"), thirtyMinute.getOccrrncTime(), "30");
		Map<String, Boolean> sixtyMinuteChange	= returnNewSelVo.checkChangeSel(returnNowLmeStdrBasVoFromIf.getMetalCode(), DateUtil.getNowDateTime("HHmmss"), sixtyMinute.getOccrrncTime(), "60");
		Map<String, Boolean> deChange			= returnNewSelVo.checkChangeSel(returnNowLmeStdrBasVoFromIf.getMetalCode(), DateUtil.getNowDateTime("HHmmss"), day.getOccrrncTime(), "DE");

		PrSelPcStdrBasVo returnSelStdrVo = returnNewSelVo.process_PrSelPcStdrBasVo(returnNowLmeStdrBasVoFromIf, returnPrLmeEvlPcBasVo, returnEhgtVo
																				, returnItVo, returnPastSelStdrAlVo);
		PrSelPcStdrBasVo returnSel01Minutes = returnNewSelVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, returnPrLmeEvlPcBasVo, returnEhgtVo
																						, returnItVo, oneMinute, pastOneMinute, "01", oneMinuteChange);
		PrSelPcStdrBasVo returnSel30Minutes = returnNewSelVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, returnPrLmeEvlPcBasVo, returnEhgtVo
																						, returnItVo, thirtyMinute, pastThirtyMinute, "30", thirtyMinuteChange);
		PrSelPcStdrBasVo returnSel60Minutes = returnNewSelVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, returnPrLmeEvlPcBasVo, returnEhgtVo
																					, returnItVo, sixtyMinute, pastSixtyMinute, "60", sixtyMinuteChange);
		PrSelPcStdrBasVo returnSelDe = returnNewSelVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, returnPrLmeEvlPcBasVo, returnEhgtVo
																					, returnItVo, day, pastDay, "DE", deChange);
		PrSelPcStdrBasVo returnSelWeek = returnNewSelVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, returnPrLmeEvlPcBasVo, returnEhgtVo
																					, returnItVo, week, pastWeek, "WK", deChange);
		PrSelPcStdrBasVo returnSelMt = returnNewSelVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, returnPrLmeEvlPcBasVo, returnEhgtVo
																					, returnItVo, month, pastMonth, "MT", deChange);
		PrSelPcStdrBasVo returnSelQu = returnNewSelVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, returnPrLmeEvlPcBasVo, returnEhgtVo
																					, returnItVo, quarter, pastQuarter, "QU", deChange);
		PrSelPcStdrBasVo returnSelYy = returnNewSelVo.process_MinuteScheduleVo(returnNowLmeStdrBasVoFromIf, returnPrLmeEvlPcBasVo, returnEhgtVo
																					, returnItVo, year, pastYear, "YY", deChange);

		// 여기에 startLmeData 추가
		if(restDateTime.getPubMessageStartLmeData(metalCode)) {
			redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.startLmeDataSocketUri, ReciveLmeDataByUdpSocket.startLmeDataSocketUri, "startLmeData/" + metalCode);
			log.info(metalCode + " startLmeDataSocketUri success / ReciveLmeDataByUdpSocket");
			restDateTime.setPubMessageStartLmeData(metalCode, false);
		}

		if(restDateTime.isSorinRltmWorkTime()) {
			// 프리미엄 적용한 판매가격 publish
			prSelPremiumService.calculatePremiumAddedSelPc(returnSelStdrVo);
		}

		if(restDateTime.getReadytoStartLmeData(metalCode)) {
			log.info("####################### LME start data recieved in SEL area #######################");

			pastOneMinute.setBeginPc(returnSelStdrVo.getEndPc());
			pastOneMinute.setEndPc(returnSelStdrVo.getEndPc());
			pastOneMinute.setTopPc(returnSelStdrVo.getEndPc());
			pastOneMinute.setLwetPc(returnSelStdrVo.getEndPc());

			pastThirtyMinute.setBeginPc(returnSelStdrVo.getEndPc());
			pastThirtyMinute.setEndPc(returnSelStdrVo.getEndPc());
			pastThirtyMinute.setTopPc(returnSelStdrVo.getEndPc());
			pastThirtyMinute.setLwetPc(returnSelStdrVo.getEndPc());

			pastSixtyMinute.setBeginPc(returnSelStdrVo.getEndPc());
			pastSixtyMinute.setEndPc(returnSelStdrVo.getEndPc());
			pastSixtyMinute.setTopPc(returnSelStdrVo.getEndPc());
			pastSixtyMinute.setLwetPc(returnSelStdrVo.getEndPc());

			pastDay.setBeginPc(returnSelStdrVo.getEndPc());
			pastDay.setEndPc(returnSelStdrVo.getEndPc());
			pastDay.setTopPc(returnSelStdrVo.getEndPc());
			pastDay.setLwetPc(returnSelStdrVo.getEndPc());

			pastWeek.setBeginPc(returnSelStdrVo.getEndPc());
			pastWeek.setEndPc(returnSelStdrVo.getEndPc());
			pastWeek.setTopPc(returnSelStdrVo.getEndPc());
			pastWeek.setLwetPc(returnSelStdrVo.getEndPc());

			pastMonth.setBeginPc(returnSelStdrVo.getEndPc());
			pastMonth.setEndPc(returnSelStdrVo.getEndPc());
			pastMonth.setTopPc(returnSelStdrVo.getEndPc());
			pastMonth.setLwetPc(returnSelStdrVo.getEndPc());

			pastQuarter.setBeginPc(returnSelStdrVo.getEndPc());
			pastQuarter.setEndPc(returnSelStdrVo.getEndPc());
			pastQuarter.setTopPc(returnSelStdrVo.getEndPc());
			pastQuarter.setLwetPc(returnSelStdrVo.getEndPc());

			pastYear.setBeginPc(returnSelStdrVo.getEndPc());
			pastYear.setEndPc(returnSelStdrVo.getEndPc());
			pastYear.setTopPc(returnSelStdrVo.getEndPc());
			pastYear.setLwetPc(returnSelStdrVo.getEndPc());

//			redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.startLmeDataSocketUri, ReciveLmeDataByUdpSocket.startLmeDataSocketUri, "startLmeData/" + metalCode);
//
//			log.info(metalCode + "startLmeDataSocketUri success");

			restDateTime.setReadytoLmeStartData(metalCode, false);
		}

		PrSelPcStdrBasVo prSelPcStdrBasVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE);
		if (prSelPcStdrBasVo != null && returnSel01Minutes != null) {
			if(returnSel01Minutes.getSlePc01MinSn() != null && prSelPcStdrBasVo.getSlePc01MinSn() != null) {
				String returnSel01MinutesSn = returnSel01Minutes.getSlePc01MinSn().substring(0, 12);
				String prSelPcStdrBasVoSn = prSelPcStdrBasVo.getSlePc01MinSn().substring(0, 12);
				if (returnSel01MinutesSn.equals(prSelPcStdrBasVoSn)) {
					BeanUtils.copyProperties(returnSel01Minutes, prSelPcStdrBasVo);
				}
			}
		}

		PrSelPcStdrBasVo prSel30PcStdrBasVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE);
		if (prSel30PcStdrBasVo != null && returnSel30Minutes != null) {
			if(returnSel30Minutes.getSlePc30MinSn() != null && prSel30PcStdrBasVo.getSlePc30MinSn() != null) {
				String returnSel30MinutesSn = returnSel30Minutes.getSlePc30MinSn().substring(0, 12);
				String prSel30PcStdrBasVoSn = prSel30PcStdrBasVo.getSlePc30MinSn().substring(0, 12);
				if (returnSel30MinutesSn.equals(prSel30PcStdrBasVoSn)) {
					BeanUtils.copyProperties(returnSel30Minutes, prSel30PcStdrBasVo);
				}
			}
		}

		PrSelPcStdrBasVo prSel60PcStdrBasVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE);
		if (prSel60PcStdrBasVo != null && returnSel60Minutes != null) {
			if(returnSel60Minutes.getSlePc60MinSn() != null && prSel60PcStdrBasVo.getSlePc60MinSn() != null) {
				String returnSel60MinutesSn = returnSel60Minutes.getSlePc60MinSn().substring(0, 12);
				String prSel60PcStdrBasVoSn = prSel60PcStdrBasVo.getSlePc60MinSn().substring(0, 12);
				if (returnSel60MinutesSn.equals(prSel60PcStdrBasVoSn)) {
					BeanUtils.copyProperties(returnSel60Minutes, prSel60PcStdrBasVo);
				}
			}
		}

		BeanUtils.copyProperties(returnSelStdrVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.STDR));
		BeanUtils.copyProperties(returnSelStdrVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.RLTM));
		BeanUtils.copyProperties(returnSel01Minutes, oneMinute);
		BeanUtils.copyProperties(returnSel30Minutes, thirtyMinute);
		BeanUtils.copyProperties(returnSel60Minutes, sixtyMinute);
		BeanUtils.copyProperties(returnSelDe, day);
		BeanUtils.copyProperties(returnSelWeek, week);
		BeanUtils.copyProperties(returnSelMt, month);
		BeanUtils.copyProperties(returnSelQu, quarter);
		BeanUtils.copyProperties(returnSelYy, year);

		// 지정가 체크 스레드
		findMatchingLimitPriceThreadService.findMatchingLimitPriceThread(returnSelStdrVo);

		if(restDateTime.isSorinRltmWorkTime()) {
			PrSelPcStdrBasVo redisSelStdrVo = new PrSelPcStdrBasVo();
			BeanUtils.copyProperties(returnSelStdrVo, redisSelStdrVo);
			redisSelStdrVo.setBeginPc(0);
			redisSelStdrVo.setTopPc(0);
			redisSelStdrVo.setLwetPc(0);

			redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode, ReciveLmeDataByUdpSocket.selWebSocketUri+ "/" + metalCode , returnSelStdrVo);

			redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.testLmeWebSocketUri + "/" + metalCode, ReciveLmeDataByUdpSocket.testLmeWebSocketUri + "/" + metalCode, "SEL_TEST" + returnSelStdrVo);
		}

		selService.insertPrSelPcStdrBas(returnSelStdrVo);	// [가격_판매 가격 기준 기본] 테이블에 insert
		selService.insertPrSelPcRltmBas(returnSelStdrVo);	// [가격_판매 가격 실시간 기본] 테이블에 insert

		isReadyToSelSchedule = true;
	}

	private void checkMatchedLmeSpreadAndCantCheckGicNamesReturn(String gicName) throws Exception {
		List<String> errorGicNames = new ArrayList<String>();
		List<String> cantCheckGicNames = new ArrayList<String>();

		ValidLmeSpreadDateVo ValidVo = new ValidLmeSpreadDateVo();
		ValidVo.setCmpnyCode("10");

		List<String> cldrTyCodeList = new ArrayList<>();
		cldrTyCodeList.add("1");
		cldrTyCodeList.add("2");
		ValidVo.setLmeCldrTyCodeList(cldrTyCodeList);

		String present = DateUtil.getNowDateTime("yyyyMMdd");
		ValidVo.setPast(restDateTime.calculateDate(present, 14, Operator.MINUS));
		ValidVo.setPresent(present);

		ValidLmeSpreadDateVo returValidVo = etcService.selectValidLmeSpreadDate(ValidVo);

		CalculateSpreadVo vo = new CalculateSpreadVo();
		vo.setMetalCode(gicName.substring(0, 3));
		vo.setDateTime(returValidVo.getApplcDe());
		vo.setGicName(gicName);

		CalculateSpreadVo returnVo = etcService.selectInterfaceSpread(vo);

		if (returnVo == null) {
			log.info("----------------- selectInterfaceSpread is null -----------------");
			log.info(" cant Check GicName : " + gicName);
			log.info("-----------------------------------------------------------------");

			cantCheckGicNames.add(gicName);
		} else {

			log.info("==========================SPREAD VALUE==========================");
			log.info(" GicName : " + gicName + ", LC SPREAD : " + returnVo.getLcSpread() + ", LE SPREAD : " + returnVo.getLeSpread());
			log.info("================================================================");

			if (!ReciveLmeDataByUdpSocket.leSpreadMap.containsKey(getMetalCode(vo.getMetalCode()))) {
				ReciveLmeDataByUdpSocket.leSpreadMap.put(getMetalCode(vo.getMetalCode()), returnVo.getLeSpread());

				// 니켈인 경우 niLcSpread에 LeSpread 값 저장
				if(getMetalCode(vo.getMetalCode()).equals(metalCodeNi)) {
					ReciveLmeDataByUdpSocket.niLcSpread = returnVo.getLeSpread();
					log.info("ReciveLmeDataByUdpSocket.niLcSpread: " + ReciveLmeDataByUdpSocket.niLcSpread);
				}
			}

			log.info("first ReciveLmeDataByUdpSocket.leSpreadMap: " + ReciveLmeDataByUdpSocket.leSpreadMap);

			if (returnVo.getLcSpread().compareTo(returnVo.getLeSpread()) != 0) {
				errorGicNames.add(gicName);
				if (!ReciveLmeDataByUdpSocket.errorSpreadMetalCodeList.contains(getMetalCode(vo.getMetalCode()))) { // [pje] 스프레드 값 오류난 메탈코드 저장
					ReciveLmeDataByUdpSocket.errorSpreadMetalCodeList.add(getMetalCode(vo.getMetalCode()));
				}
			}
		}

		if (errorGicNames.size() > 0) {
			restDateTime.updateRestTime(restDateTime.getRestRealSellEndTimeSecond(), "LME 스프레드 변동분 오류");
			restDateTime.initialize();
			redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.spreadSocketUri,
					ReciveLmeDataByUdpSocket.spreadSocketUri, "notMatchedSpread");

			log.info("----------------- Spread data is not matched -----------------");
			for (String errorGicName : errorGicNames) {
				log.info(" Not matched GicName : " + errorGicName);
				log.info(" ReciveLmeDataByUdpSocket.errorSpreadMetalCodeList "
						+ ReciveLmeDataByUdpSocket.errorSpreadMetalCodeList);
			}
			log.info("--------------------------------------------------------------");
		} else {
			log.info("+++++++++++++++++ Spread data is matched +++++++++++++++++");
		}
	}

	private String getMetalCode(String value) {

		if(value.equals(gicNameZn) || value.equals(gicNameZn.substring(0,3))) return metalCodeZn;
		if(value.equals(gicNamePb) || value.equals(gicNamePb.substring(0,3))) return metalCodePb;
		if(value.equals(gicNameCu) || value.equals(gicNameCu.substring(0,3))) return metalCodeCu;
		if(value.equals(gicNameAl) || value.equals(gicNameAl.substring(0,3))) return metalCodeAl;
		if(value.equals(gicNameNi) || value.equals(gicNameNi.substring(0,3))) return metalCodeNi;
		if(value.equals(gicNameSn) || value.equals(gicNameSn.substring(0,3))) return metalCodeSn;

		return null;
	}

	private Map<String, Boolean> checkChangeLme(String metalCode, String currentTime, String timeData, String tickTime) {
		log.info("checkChangeLme metalCode: " + metalCode + ", currentTime: " + currentTime + ", timeData: " + timeData + ", tickTime: " + tickTime);
		Map<String, Boolean> result = new HashMap<>();

		if(timeData == null) {
			result.put(metalCode, false);
			return result;
		}

		String currentHour = currentTime.substring(0, 2);
		String currentMinutes = currentTime.substring(2, 4);
		String memoryMinutes = timeData.substring(2, 4);
		String memoryHour = timeData.substring(0, 2);

		switch (tickTime) {
			case "01":
				result.put(metalCode, !currentMinutes.equals(memoryMinutes));
				break;
			case "30":
				String current30Minutes = String.valueOf((Integer.parseInt(currentMinutes) / 30) * 30);
				if(current30Minutes.equals("0")) current30Minutes = "00";
				result.put(metalCode, !current30Minutes.equals(memoryMinutes));
				break;
			case "60":
				result.put(metalCode, !currentHour.equals(memoryHour));
				break;
			default:
				result.put(metalCode, !currentHour.equals(memoryHour));
				break;
		}
		return result;
	}
}
