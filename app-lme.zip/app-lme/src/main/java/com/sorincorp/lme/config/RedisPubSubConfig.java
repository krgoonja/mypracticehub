package com.sorincorp.lme.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.lme.RedisSubscriberLme;


@Configuration
@ComponentScan("com.sorincorp.comm.*")
public class RedisPubSubConfig {

	@Autowired
	RedisPubSubService redisPubSubService;
	
	@Autowired
	RedisSubscriberLme redisSubscriberLme;
	
	@Value("${redisPubsub.uri.fx}")
	private String fxpcUri;
	
	@Value("${redisPubsub.crncyCode.KRW}")
	private String fxpcKRW;
	
	@Value("${redisPubsub.uri.sidecar}")
	private String sidecarUri;
	
	@Value("${redisPubsub.uri.restTime}")
	private String restTimeUri;

	@Value("${redisPubsub.uri.lmeLh}")
	private String lmeLhUri;
	
	@Value("${redisPubsub.uri.limit}")
	private String limitUri;
	
	@Value("${redisPubsub.uri.premium}")
	private String premiumUri;

	@Value("${redisPubsub.uri.properties}")
	private String propertiesUri;

	@Value("${redisPubsub.uri.prvsnlLimit}")
	private String prvsnlLimitUri;

	@Bean(initMethod="init")
	public void InitSettings() throws Exception{
		redisPubSubService.createChannel(fxpcUri + "/" + fxpcKRW, redisSubscriberLme);
		
		redisPubSubService.createChannel(restTimeUri, redisSubscriberLme);
		redisPubSubService.createChannel(lmeLhUri, redisSubscriberLme);
		
		redisPubSubService.createChannel(limitUri, redisSubscriberLme);
		redisPubSubService.createChannel(prvsnlLimitUri, redisSubscriberLme);

		redisPubSubService.createChannel(premiumUri, redisSubscriberLme);
		// 사이드카
		//redisPubSubService.createChannel(sidecarUri, redisSubscriberLme);

		redisPubSubService.createChannel(propertiesUri, redisSubscriberLme);
	}
	
}
