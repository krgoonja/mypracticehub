package com.sorincorp.lme.etc.service;

import com.sorincorp.lme.etc.model.CalculateSpreadVo;
import com.sorincorp.lme.etc.model.ClosedHoursVo;
import com.sorincorp.lme.etc.model.TodaySpreadVO;
import com.sorincorp.lme.etc.model.ValidLmeSpreadDateVo;

public interface EtcService {

	/**
	 * <pre>
	 * 처리내용: 휴식 시간을 입력한다.
	 * </pre>
	 * @date 2022. 1. 17.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 17.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param closedHoursVo
	 * @throws Exception
	 */
	void insertItHvofTimeManageBas(ClosedHoursVo closedHoursVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: BO의 LME 신호등 상태값을 바꾼다.
	 * </pre>
	 * @date 2022. 1. 27.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 27.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param status
	 * @throws Exception
	 */
	void updateCntcStts(int status) throws Exception;


	/**
	 * <pre>
	 * 처리내용: 계산된 현재의 LE와 LC의 spread 값을 가져온다.
	 * </pre>
	 * @date 2022. 3. 15.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 3. 15.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	CalculateSpreadVo selectInterfaceSpread(CalculateSpreadVo vo) throws Exception;


	/**
	 * <pre>
	 * 처리내용: 가능한 spread값을 가져올 수 있는 날짜에 대한 정보를 가져온다.
	 * </pre>
	 * @date 2022. 5. 12.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 12.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	ValidLmeSpreadDateVo selectValidLmeSpreadDate(ValidLmeSpreadDateVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 휴식 시간을 삭제한다.
	 * </pre>
	 * @date 2022. 6. 16.
	 * @author srec0064
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 6. 16.		srec0064		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param closedHoursVo
	 * @throws Exception
	 */
	public void deleteItHvofTimeManageBas(ClosedHoursVo closedHoursVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: LME 데이터 오류 시간을 체크한다
	 * </pre>
	 * @date 2022. 7. 26.
	 * @author srec0064
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 26.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param closedHoursVo
	 * @return
	 * @throws Exception
	 */
	public int getGapTime(ClosedHoursVo closedHoursVo) throws Exception;

	public void testSetting(int lmeStatus, int ehgtStatus, int initStatus) throws Exception;

	/**
	 * <pre>
	 * 처리내용: Spread 삽입 기능 활성화 여부 및 값 가져오기
	 * </pre>
	 * @date 2022. 11. 03.
	 * @author jdrttl
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 03.		jdrttl				최초작성
	 * ------------------------------------------------
	 * @param  TodaySpreadVO
	 * @return TodaySpreadVO
	 * @throws Exception
	 */
	public TodaySpreadVO getTodaySpread(TodaySpreadVO todaySpreadVO) throws Exception;
}
