package com.sorincorp.lme.pc.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class SelPrimiumAmountVo implements Serializable {

	/**
	 * @Fields field:field:{todo}
	 */
	private static final long serialVersionUID = -4249842516004513179L;

	/**
	 * 프리미엄 가격
	 */
	private int slePremiumAmount;

	/**
	 * 금속 코드
	 */
	private String metalCode;

	/**
	 * 아이템 번호
	 */
	private int itmSn;

	/**
	 * 지역 대분류
	 */
	private String dstrctLclsfCode;

	/**
	 * 브랜드 그룹 코드
	 */
	private String brandGroupCode;

	/**
	 * 프리미엄 ID
	 */
	private String premiumId;

}