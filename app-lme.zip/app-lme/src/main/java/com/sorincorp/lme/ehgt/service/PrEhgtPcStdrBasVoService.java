package com.sorincorp.lme.ehgt.service;

import com.sorincorp.lme.ehgt.model.PrEhgtPcStdrBasVo;

public interface PrEhgtPcStdrBasVoService {
	
	PrEhgtPcStdrBasVo getPrEhgtPcStdrBasVo();
	
	void clearPrEhgtPcStdrBasVo();
}