package com.sorincorp.lme.ehgt.service;

import org.springframework.stereotype.Service;

import com.sorincorp.lme.ehgt.model.PrEhgtPcStdrBasVo;

@Service
public class PrEhgtPcStdrBasVoServiceImpl implements PrEhgtPcStdrBasVoService{
	
	private PrEhgtPcStdrBasVo prEhgtPcStdrBasVo;
	
	public PrEhgtPcStdrBasVoServiceImpl() {
		if(prEhgtPcStdrBasVo == null) {
			this.prEhgtPcStdrBasVo = new PrEhgtPcStdrBasVo();
		}
	}
	
	public PrEhgtPcStdrBasVo getPrEhgtPcStdrBasVo() {
		return prEhgtPcStdrBasVo;
	}
	
	public void clearPrEhgtPcStdrBasVo() {
		prEhgtPcStdrBasVo = new PrEhgtPcStdrBasVo();
	}
	
}