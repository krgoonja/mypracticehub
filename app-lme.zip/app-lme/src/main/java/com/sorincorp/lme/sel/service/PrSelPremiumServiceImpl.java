package com.sorincorp.lme.sel.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.pcInfo.model.PrPremiumSelVO;
import com.sorincorp.comm.premium.service.ItPremiumStdrBasVoService;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.lme.ReciveLmeDataByUdpSocket;
import com.sorincorp.lme.pc.service.PrPremiumSelVOService;
import com.sorincorp.lme.sel.model.PrSelPcStdrBasVo;
import com.sorincorp.lme.util.LmeDataUtil;
import com.sorincorp.lme.util.RestDateTime;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PrSelPremiumServiceImpl implements PrSelPremiumService {
	
	@Autowired
	private ItPremiumStdrBasVoService itPremiumStdrBasVoService;
	
	@Autowired
	private PrPremiumSelVOService prPremiumSelVOService;
	
	@Autowired
	private RedisPubSubService redisPubSubService;
	
	@Autowired
	private RedisUtil redisUtil;
	
	@Autowired
	private RestDateTime restDateTime;

	@Async("lmeThreadPoolExcuter")
	@Override
	public void calculatePremiumAddedSelPc(PrSelPcStdrBasVo vo) {
		List<PrPremiumSelVO> result = new ArrayList<>();								// TODO 전역변수에 저장하기, 00시에 초기화하기
		result = itPremiumStdrBasVoService.getItPremiumStdrBasVo().entrySet().stream()
				.flatMap(entry -> entry.getValue().stream())
				.filter(livePremiumVO -> vo != null && livePremiumVO.getValidBeginDt().compareTo(vo.getOccrrncDe() + vo.getOccrrncTime()) <= 0
						&& livePremiumVO.getValidEndDt().compareTo(vo.getOccrrncDe() + vo.getOccrrncTime()) >= 0
						&& livePremiumVO.getMetalCode().equals(vo.getMetalCode()))
				.map(livePremiumVO -> {
					PrPremiumSelVO resultVo = new PrPremiumSelVO();
					
					// 초기값으로 세팅했던 차트타이틀 내용 set
					Optional.ofNullable(prPremiumSelVOService.getPrPremiumSelVOMap(vo.getMetalCode()))
					.orElseGet(ArrayList::new)
					.stream()
					.filter(prPremiumVo ->
						Objects.equals(prPremiumVo.getItmSn(), livePremiumVO.getItmSn()) &&
						Objects.equals(prPremiumVo.getDstrctLclsfCode(), livePremiumVO.getDstrctLclsfCode()) &&
						Objects.equals(prPremiumVo.getBrandGroupCode(), livePremiumVO.getBrandGroupCode()) &&
						Objects.equals(prPremiumVo.getBrandCode(), livePremiumVO.getBrandCode())
					)
					.findFirst()
					.ifPresent(prPremiumVo -> {
						resultVo.setBeginPc(prPremiumVo.getBeginPc());
						resultVo.setTopPc(prPremiumVo.getTopPc());
						resultVo.setLwetPc(prPremiumVo.getLwetPc());
						resultVo.setPastEndPc(prPremiumVo.getPastEndPc());
					});
					
					long totalAmount = livePremiumVO.getSlePremiumAmount() + vo.getEndPc();
					resultVo.setMetalCode(vo.getMetalCode());							// 메탈코드
					resultVo.setEndPc(totalAmount);										// 프리미엄 가격 + 판매 가격
					resultVo.setItmSn(livePremiumVO.getItmSn());						// 아이템코드
					resultVo.setDstrctLclsfCode(livePremiumVO.getDstrctLclsfCode());	// 권역코드
					resultVo.setBrandGroupCode(livePremiumVO.getBrandGroupCode());		// 브랜드그룹코드
					resultVo.setBrandCode(livePremiumVO.getBrandCode());				// 브랜드코드
					resultVo.setSlePcRltmSn(vo.getSlePcRltmSn());						// 판매가격 실시간 순번
					resultVo.setEhgtPcRltmSn(vo.getEhgtPcRltmSn());						// 환율 실시간 순번
					resultVo.setLmePcRltmSn(vo.getLmePcRltmSn());						// lme 실시간 순번

					// 가단가 구매관련 실시간 데이터 노출을 위해 추가 세팅
					resultVo.setRealEndPc(vo.getEndPc()); 								// 실제 종료 가격 (프리미업 제외 순수 판매가격)

					String groupKey = String.join("_", vo.getMetalCode(), Integer.toString(livePremiumVO.getItmSn()),
							livePremiumVO.getDstrctLclsfCode(), livePremiumVO.getBrandGroupCode(), livePremiumVO.getBrandCode());
					
					if(restDateTime.getReadytoGroupStartData(groupKey)) {
						resultVo.setBeginPc(totalAmount);
						resultVo.setTopPc(totalAmount);
						resultVo.setLwetPc(totalAmount);
						log.info("resultVo.getBeginPc() 1: " + resultVo.getBeginPc());
						
						restDateTime.setReadytoGroupStartData(groupKey, false);
					} else if(resultVo.getBeginPc() == 0) {
						resultVo.setBeginPc(totalAmount);
						resultVo.setTopPc(totalAmount);
						resultVo.setLwetPc(totalAmount);
						log.info("resultVo.getBeginPc() 2: " + resultVo.getBeginPc());
					} else {
						if(resultVo.getEndPc() >= resultVo.getTopPc()) {
							resultVo.setTopPc(resultVo.getEndPc());
						} 
							
						if(resultVo.getEndPc() <= resultVo.getLwetPc()) {
							resultVo.setLwetPc(resultVo.getEndPc());
						}
					}
					
					resultVo.setVersusPc(resultVo.getEndPc() - resultVo.getPastEndPc());
					
					if(resultVo.getPastEndPc() == 0)
						resultVo.setVersusRate(BigDecimal.ZERO);
					else
						resultVo.setVersusRate(((new BigDecimal(resultVo.getEndPc() - resultVo.getPastEndPc())).divide(new BigDecimal(resultVo.getPastEndPc()), 6, RoundingMode.HALF_UP)).multiply(new BigDecimal(100)));
					
					return resultVo;
				})
				.collect(Collectors.toList());

		prPremiumSelVOService.getPrPremiumSelVOMap().remove(vo.getMetalCode());
		prPremiumSelVOService.getPrPremiumSelVOMap(vo.getMetalCode()).addAll(result);
		
		publishPremiumAddedSelPc(vo.getMetalCode());
		saveRedisPremiumAddedSelPc(vo.getMetalCode());
	}

	@Async("lmeThreadPoolExcuter")
	@Override
	public void publishPremiumAddedSelPc(String metalCode){
		if(prPremiumSelVOService.getPrPremiumSelVOMap(metalCode) != null && !prPremiumSelVOService.getPrPremiumSelVOMap(metalCode).isEmpty()) {
			redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.selpcAllWebsocketUri + "/" + metalCode, ReciveLmeDataByUdpSocket.selpcAllWebsocketUri + "/" + metalCode, prPremiumSelVOService.getPrPremiumSelVOMap(metalCode));
			if(metalCode.equals("7")) {		// TODO 로그 삭제 예정 [pje]
				log.info("publishPremiumAddedSelPc: " + ReciveLmeDataByUdpSocket.selpcAllWebsocketUri + "/" + metalCode);
			}
		}
	}

	@Async("lmeThreadPoolExcuter")
	@Override
	public void saveRedisPremiumAddedSelPc(String metalCode) {
		redisUtil.setDataExpireJson(LmeDataUtil.SEL_PC_ALL_LIST + metalCode, prPremiumSelVOService.getPrPremiumSelVOMap(metalCode), LmeDataUtil.DURATION);
	}

}
