package com.sorincorp.lme.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeSet;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.RvcmpnVO;
import com.sorincorp.comm.premium.service.ItPremiumStdrBasVoService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.lme.pc.model.OpFallNumPcBasVo;
import com.sorincorp.lme.pc.model.OpFallSelPcBasVo;
import com.sorincorp.lme.pc.service.PcService;

import lombok.extern.slf4j.Slf4j;

/**
 * @ClassName: FallSelPc
 * @Author: chajeeman
 * @Date: 2023. 6. 12.
 */
@Slf4j
@Component
@ComponentScan("com.sorincorp.comm.*")
public class FallSelPc {

	/** 가격하락문자 발송 스레드 풀 */
	@Resource(name = "lmeThreadPoolExcuter")
	private ThreadPoolTaskExecutor taskExecutor;

	@Autowired
	private RestDateTime restDateTime;

	@Autowired
	private PcService pcService;

	@Autowired
	private SMSService smsService;

	@Autowired
	private CommonService commonService;

	@Autowired
	private ItPremiumStdrBasVoService itPremiumStdrBasVoService;

	private static List<RvcmpnVO> sarokPcList;
	private static List<OpFallSelPcBasVo> opFallSelPc;
	private static List<OpFallNumPcBasVo> opFallNumPc;
	//private static List<SelPrimiumAmountVo> premiumInfo;

	public void initialize() throws Exception {
		// 조달청 가격
		sarokPcList = pcService.selectItRvcmpnPcManageBas();
		// 하락 메세지
		opFallSelPc = pcService.selectFallSelPcBas();
		// 프리미엄 조회
		//premiumInfo = pcService.selectSelPremiumAmount();
		// 시초가 여부, SMS 전송 여부, 설정 가격 조회
		opFallNumPc = pcService.selectFallNumPc();

		log.info("============================SAROK_PC List============================");
		for (RvcmpnVO rvcmpnVO : sarokPcList) {
			Optional<RvcmpnVO> sarok = Optional.ofNullable(rvcmpnVO);
			if (sarok.isPresent()) {
				log.info("METAL_CODE : " + rvcmpnVO.getMetalCode() + " BRAND_GROUP_CODE : "
						+ rvcmpnVO.getBrandGroupCode() + " SAROK_PC : " + rvcmpnVO.getSarokPc());
			}
		}

		log.info("============================OP_FALL_SELL_PC List============================");
		for (OpFallSelPcBasVo opFallSelPcBasVo : opFallSelPc) {
			Optional<OpFallSelPcBasVo> fallPc = Optional.ofNullable(opFallSelPcBasVo);
			if (fallPc.isPresent()) {
				log.info("METAL_CODE : " + opFallSelPcBasVo.getMetalCode() + " ITM_SN : "
						+ opFallSelPcBasVo.getItmSn() + " DSTRCT_LCLSF_CODE : "
						+ opFallSelPcBasVo.getDstrctLclsfCode() + " BRAND_GROUP_CODE : "
						+ opFallSelPcBasVo.getBrandGroupCode() + " FALL_SEL_PC : " + opFallSelPcBasVo.getFallSelPc()
						+ " SMS_YN : " + opFallSelPcBasVo.getSmsYn());
			}
		}

//		log.info("============================PRMIUM_AMOUNT List============================");
//		for (SelPrimiumAmountVo selPrimiumAmountVo : premiumInfo) {
//			Optional<SelPrimiumAmountVo> primiumPc = Optional.ofNullable(selPrimiumAmountVo);
//			if (primiumPc.isPresent()) {
//				log.info("PRIMIUM_ID : " + selPrimiumAmountVo.getPremiumId() + " METAL_CODE : " + selPrimiumAmountVo.getMetalCode() + " ITM_SN : " + selPrimiumAmountVo.getItmSn() + " DSTRCT_LCLSF_CODE : " + selPrimiumAmountVo.getDstrctLclsfCode() + " BRAND_GROUP_CODE : " + selPrimiumAmountVo.getBrandGroupCode() + " SLE_PIMIUM_AMOUNT : " + selPrimiumAmountVo.getSlePremiumAmount());
//			}
//		}
		
		log.info("============================OP_FALL_NUM List============================");
		for (OpFallNumPcBasVo opFallNumPcBasVo : opFallNumPc) {
			Optional<OpFallNumPcBasVo> fallNum = Optional.ofNullable(opFallNumPcBasVo);
			if (fallNum.isPresent()) {
				log.info("START_PRICE_YN : " + opFallNumPcBasVo.getStartPriceYn() + " SMS_SEND_YN : "
						+ opFallNumPcBasVo.getSmsSendYn() + " MAIN_CODE : " + opFallNumPcBasVo.getMainCode());
			}
		}
	}

	public List<RvcmpnVO> initItRvcmpnPcManageBas() throws Exception {
		sarokPcList = pcService.selectItRvcmpnPcManageBas();

		log.info("============================init SAROK_PC List============================");
		for (RvcmpnVO rvcmpnVO : sarokPcList) {
			Optional<RvcmpnVO> sarok = Optional.ofNullable(rvcmpnVO);
			if (sarok.isPresent()) {
				log.info("METAL_CODE : " + rvcmpnVO.getMetalCode() + " BRAND_GROUP_CODE : "
						+ rvcmpnVO.getBrandGroupCode() + " SAROK_PC : " + rvcmpnVO.getSarokPc());
			}
		}

		return sarokPcList;
	}

	public List<OpFallSelPcBasVo> initItFallSelPcBas() throws Exception {
		opFallSelPc = pcService.selectFallSelPcBas();

		log.info("============================init OP_FALL_SELL_PC List============================");
		for (OpFallSelPcBasVo opFallSelPcBasVo : opFallSelPc) {
			Optional<OpFallSelPcBasVo> fallPc = Optional.ofNullable(opFallSelPcBasVo);
			if (fallPc.isPresent()) {
				log.info("METAL_CODE : " + opFallSelPcBasVo.getMetalCode() + " ITM_SN : "
						+ opFallSelPcBasVo.getItmSn() + " DSTRCT_LCLSF_CODE : "
						+ opFallSelPcBasVo.getDstrctLclsfCode() + " BRAND_GROUP_CODE : "
						+ opFallSelPcBasVo.getBrandGroupCode() + " FALL_SEL_PC : " + opFallSelPcBasVo.getFallSelPc()
						+ " SMS_YN : " + opFallSelPcBasVo.getSmsYn());
			}
		}

		return opFallSelPc;
	}

//	public List<SelPrimiumAmountVo> initSelPremiumAmount() throws Exception {
//		premiumInfo = pcService.selectSelPremiumAmount();
//
//		log.info("============================init PRMIUM_AMOUNT List============================");
//		for (SelPrimiumAmountVo selPrimiumAmountVo : premiumInfo) {
//			Optional<SelPrimiumAmountVo> primiumPc = Optional.ofNullable(selPrimiumAmountVo);
//			if (primiumPc.isPresent()) {
//				log.info("PRIMIUM_ID : " + selPrimiumAmountVo.getPremiumId() + " METAL_CODE : " 
//						+ selPrimiumAmountVo.getMetalCode() + " ITM_SN : " + selPrimiumAmountVo.getItmSn() 
//						+ " DSTRCT_LCLSF_CODE : " + selPrimiumAmountVo.getDstrctLclsfCode() + " BRAND_GROUP_CODE : " 
//						+ selPrimiumAmountVo.getBrandGroupCode() + " SLE_PIMIUM_AMOUNT : " 
//						+ selPrimiumAmountVo.getSlePremiumAmount());
//			}
//		}
//
//		return premiumInfo;
//	}

	public void calculateSmsPrice(String metalCode, long selPc, String occrrncDeTime) throws Exception {
//		log.info("<<<<-----------------calculatePrice------------------------>>>");
		try {
			if (restDateTime.isSorinWorkTime()) {
				// 리스트의 갯수를 줄여!
				List<RvcmpnVO> filterSarokPcList = sarokPcList.stream()
						.filter(data -> (StringUtils.equals(data.getMetalCode(), metalCode)))
						.collect(Collectors.toList());

//		for (RvcmpnVO rvcmpnVO : filterSarokPcList) {
//			Optional<RvcmpnVO> sarok = Optional.ofNullable(rvcmpnVO);
//			if (sarok.isPresent()) {
//				log.info("METAL_CODE : " + rvcmpnVO.getMetalCode() + " BRAND_GROUP_CODE : "
//						+ rvcmpnVO.getBrandGroupCode() + " SAROK_PC : " + rvcmpnVO.getSarokPc());
//			}
//		}

				List<OpFallSelPcBasVo> filterOpFallSelPcList = opFallSelPc.stream()
						.filter(data -> (StringUtils.equals(data.getMetalCode(), metalCode)))
						.collect(Collectors.toList());

//		for (OpFallSelPcBasVo opFallSelPcBasVo : filterOpFallSelPcList) {
//			Optional<OpFallSelPcBasVo> fallPc = Optional.ofNullable(opFallSelPcBasVo);
//			if (fallPc.isPresent()) {
//				log.info("METAL_CODE : " + opFallSelPcBasVo.getMetalCode() + " DSTRCT_LCLSF_CODE : "
//						+ opFallSelPcBasVo.getDstrctLclsfCode() + " BRAND_GROUP_CODE : "
//						+ opFallSelPcBasVo.getBrandGroupCode() + " FALL_SEL_PC : " + opFallSelPcBasVo.getFallSelPc()
//						+ " SMS_YN : " + opFallSelPcBasVo.getSmsYn());
//			}
//		}


				boolean boolRltmSmsRun = false;

				for (RvcmpnVO rvcmpnVO : filterSarokPcList) {
					Optional<RvcmpnVO> sarok = Optional.ofNullable(rvcmpnVO);

					if (sarok.isPresent()) {
						for (OpFallSelPcBasVo opFallSelPcBasVo : filterOpFallSelPcList) {

							if (StringUtils.equals("Y", opFallSelPcBasVo.getSmsYn())) {
								Optional<OpFallSelPcBasVo> fallPc = Optional.ofNullable(opFallSelPcBasVo);

								if (fallPc.isPresent()) {

									if (StringUtils.equals(rvcmpnVO.getMetalCode(), opFallSelPcBasVo.getMetalCode())
											&& StringUtils.equals(rvcmpnVO.getBrandGroupCode(), opFallSelPcBasVo.getBrandGroupCode())) {
										
										for (Map.Entry<String, TreeSet<LivePremiumVO>> entry : itPremiumStdrBasVoService.getItPremiumStdrBasVo()
												.entrySet()) {
											TreeSet<LivePremiumVO> value = entry.getValue();
											
											Optional<LivePremiumVO> optionalLivePremiumVO = value.stream()
												.filter(data -> (StringUtils.equals(data.getMetalCode(), metalCode))
														&& data.getValidBeginDt().compareTo(occrrncDeTime) <= 0
														&& data.getValidEndDt().compareTo(occrrncDeTime) >= 0
														&& data.getItmSn() == opFallSelPcBasVo.getItmSn()
														&& (StringUtils.equals(data.getDstrctLclsfCode(), opFallSelPcBasVo.getDstrctLclsfCode()))
														&& (StringUtils.equals(data.getBrandGroupCode(), opFallSelPcBasVo.getBrandGroupCode()))
														&& (StringUtils.equals(data.getBrandCode(), "0000000000"))
											).findFirst();

											if (optionalLivePremiumVO.isPresent()) {
												LivePremiumVO livePremiumVO = optionalLivePremiumVO.get();

												if (rvcmpnVO.getSarokPc().intValue() / 1.1 - (selPc + opFallSelPcBasVo.getFallSelPc() + livePremiumVO.getSlePremiumAmount()) > 0) {
													// 1. 전역변수 직접 접근해서 변경
													setChangeSmsYn(opFallSelPcBasVo.getFallSeqNo());

													// 2. 비동기 업데이트
													updateFallSelPc(opFallSelPcBasVo);

													if (boolRltmSmsRun == false) {
														sendFallPcMessage(opFallSelPcBasVo, selPc, rvcmpnVO.getSarokPc().intValue(), new BigDecimal(livePremiumVO.getSlePremiumAmount()).intValue());
													}
													// 한번만 보내게
													boolRltmSmsRun = true;
												}
											}
										}									
									}
								}
							}
						}
					}
				}

				for (int i = 0; i < opFallNumPc.size(); i++) {
					OpFallNumPcBasVo opFallNumPcBasVo = opFallNumPc.get(i);

					if (StringUtils.equals(opFallNumPcBasVo.getCodeRefrnone(), metalCode)) {

//						log.info("START_PRICE_YN : " + opFallNumPcBasVo.getStartPriceYn() + " SMS_SEND_YN : " 
//						+ opFallNumPcBasVo.getSmsSendYn() + " MAIN_CODE : " + opFallNumPcBasVo.getMainCode() 
//						+ " SUB_CODE : " + opFallNumPcBasVo.getSubCode() + " CODE_NM : " + opFallNumPcBasVo.getCodeNm() 
//						+ " CODE_REFRNONE : " + opFallNumPcBasVo.getCodeRefrnone() + " CODE_NUMBER_REFRNONE  : " 
//						+ opFallNumPcBasVo.getCodeNumberRefrnone() + " CODE_NUMBER_REFRNTWO : " + opFallNumPcBasVo.getCodeNumberRefrntwo());

						for (Map.Entry<String, TreeSet<LivePremiumVO>> entry : itPremiumStdrBasVoService.getItPremiumStdrBasVo().entrySet()) {
							TreeSet<LivePremiumVO> value = entry.getValue();
							Optional<LivePremiumVO> optionalLivePremiumVO = value.stream().filter(
									data -> (StringUtils.equals(data.getMetalCode(), metalCode)) 
									&& data.getValidBeginDt().compareTo(occrrncDeTime) <= 0 
									&& data.getValidEndDt().compareTo(occrrncDeTime) >= 0 
									&& (StringUtils.equals(data.getDstrctLclsfCode(), opFallNumPcBasVo.getCodeNumberRefrntwo())) 
									&& (StringUtils.equals(data.getBrandGroupCode(), opFallNumPcBasVo.getSubCode())) 
									&& (StringUtils.equals(data.getBrandCode(), "0000000000"))).findFirst();

							if (optionalLivePremiumVO.isPresent()) {
								LivePremiumVO livePremiumVO = optionalLivePremiumVO.get();

								if (selPc + livePremiumVO.getSlePremiumAmount() <= Integer.parseInt(opFallNumPcBasVo.getCodeNumberRefrnone()) 
										&& StringUtils.equals(opFallNumPcBasVo.getSmsSendYn(), "N")) { // 3,000,000보다 작고 SMS 전송여부가 N인 경우
									// 전역변수 직접 접근해서 변경
									opFallNumPc.get(i).setSmsSendYn("Y");

									sendFallNumPcMessage(metalCode, opFallNumPcBasVo.getCodeNumberRefrnone(), selPc, opFallNumPc.get(i).getStartPriceYn(), opFallNumPc.get(i).getCodeChrctrRefrnsix());
								}
							}
						}
						opFallNumPc.get(i).setStartPriceYn("N");
					}
				}
				
//			log.info("-----------------calculateSmsPrice after update------------------------");
//			for (OpFallSelPcBasVo opFallSelPcBasVo : opFallSelPc) {
//				Optional<OpFallSelPcBasVo> fallPc = Optional.ofNullable(opFallSelPcBasVo);
//				if (fallPc.isPresent()) {
//					log.info("METAL_CODE : " + opFallSelPcBasVo.getMetalCode() + " DSTRCT_LCLSF_CODE : "
//							+ opFallSelPcBasVo.getDstrctLclsfCode() + " BRAND_GROUP_CODE : "
//							+ opFallSelPcBasVo.getBrandGroupCode() + " FALL_SEL_PC : " + opFallSelPcBasVo.getFallSelPc()
//							+ " SMS_YN : " + opFallSelPcBasVo.getSmsYn());
//				}
//			}
//			log.info("-----------------calculateSmsPrice after end------------------------");
			}
		} catch (Exception e) {
			log.debug("[FallSelPc][calculateSmsPrice] " + ExceptionUtils.getStackTrace(e));
		}
	}
	
	// 값에 직접 접근해서 하향 메시지 전송 여부값(SMS_SEND_YN)을 N 으로 변경
	public void setChangeSmsSendYn(String subCode) {

		List<OpFallNumPcBasVo> copyOpFallNumPcBasVo = new ArrayList<OpFallNumPcBasVo>();

		for (int i = 0; i < copyOpFallNumPcBasVo.size(); i++) {
			if (!StringUtils.equals(copyOpFallNumPcBasVo.get(i).getSubCode(), subCode)) {
				copyOpFallNumPcBasVo.add(copyOpFallNumPcBasVo.get(i));
			}
		}
		opFallNumPc = copyOpFallNumPcBasVo;

	}

	// 값에 직접 접근해서 SMS_YN 값을 N 으로 변경
	public void setChangeSmsYn(String fallSeqNo) {

		List<OpFallSelPcBasVo> copyOpFallSelPc = new ArrayList<OpFallSelPcBasVo>();

		for (int i = 0; i < opFallSelPc.size(); i++) {
			if (!StringUtils.equals(opFallSelPc.get(i).getFallSeqNo(), fallSeqNo)) {
				copyOpFallSelPc.add(opFallSelPc.get(i));
			}
		}
		opFallSelPc = copyOpFallSelPc;
	}

	// FallSelPcBas 업데이트
	public synchronized void updateFallSelPc(OpFallSelPcBasVo opFallSelPcBasVo) {
		Runnable fallSelPcRun = () -> {
			try {
				// db업데이트
				pcService.updateFallSelPcBas(opFallSelPcBasVo.getFallSeqNo());
				commonService.insertTableHistory("OP_FALL_SEL_PC_BAS", opFallSelPcBasVo);
			} catch (Exception e) {
				log.debug("[FallSelPc][updateFallSelPc] " + ExceptionUtils.getStackTrace(e));
			}
		};
		taskExecutor.execute(fallSelPcRun);
	}

	// SMS 발송 업데이트
	private synchronized void sendFallPcMessage(OpFallSelPcBasVo fallSelPc, long selPc, int sarokPc, int premiumAmount) {
		Runnable smsRun = () -> {
			try {
				log.info("-----------------sendFallPcMessag------------------------" + "FALL_SEL_SEQ" + fallSelPc.getFallSeqNo() + "FALL_SEL_PC : " + fallSelPc.getFallSelPc());
				List<Map<String, String>> returnList = pcService.selectMemberSmsByMetalCode(fallSelPc.getMetalCode());

				for (Map<String, String> returnMap : returnList) {
					if (StringUtils.isNotEmpty(returnMap.get("MOBLPHON_NO"))) {
						SMSVO smsVO = new SMSVO();
						smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
						smsVO.setCommerceNtcnAt("N"); // 커머스 알림 여부
						try {
							smsVO.setPhone(CryptoUtil.decryptAES256(returnMap.get("MOBLPHON_NO")));

						} catch (Exception e) {
							log.debug("FallSelPc sendFallPcMessage MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
						}
						Map<String, String> smsMap = new HashMap<>();

						smsMap.put("templateNum", "112");
						smsMap.put("entrpsKorean", returnMap.get("ENTRPSNM_KOREAN"));
						smsMap.put("metalCode", fallSelPc.getMetalName());
						smsMap.put("sarokPc", String.format("%,d", Math.round(sarokPc / 1.1)));
						smsMap.put("lwetPc", String.format("%,d", Math.round(selPc + premiumAmount)));
						smsMap.put("fallSelPc", String.format("%,d", Math.round(fallSelPc.getFallSelPc())));

						smsService.insertSMS(smsVO, smsMap);
					}
				}
			} catch (Exception e) {
				log.debug("[FallSelPc][sendFallPcMessage] " + ExceptionUtils.getStackTrace(e));
			}
		};
		taskExecutor.execute(smsRun);
	}

	// SMS 발송 업데이트
	private synchronized void sendFallPcMessage2(OpFallSelPcBasVo fallSelPc, long selPc, int sarokPc, int premiumAmount) {
		Runnable smsRun = () -> {
			try {
				log.info("-----------------sendFallPcMessag------------------------" + premiumAmount + "FALL_SEL_SEQ" + fallSelPc.getFallSeqNo() + "FALL_SEL_PC : " + fallSelPc.getFallSelPc());
				// List<Map<String, String>> returnList =
				// pcService.selectMemberSmsByMetalCode(fallSelPc.getMetalCode());

				// for (Map<String, String> returnMap : returnList) {
				// if (StringUtils.isNotEmpty(returnMap.get("MOBLPHON_NO"))) {
				SMSVO smsVO = new SMSVO();
				smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
				smsVO.setCommerceNtcnAt("N"); // 커머스 알림 여부
				try {
					smsVO.setPhone("01072026805");// CryptoUtil.decryptAES256(returnMap.get("MOBLPHON_NO")));

				} catch (Exception e) {
					log.debug("FallSelPc sendFallPcMessage MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
				Map<String, String> smsMap = new HashMap<>();

				smsMap.put("templateNum", "112");
				smsMap.put("entrpsKorean", "허허허허");// returnMap.get("ENTRPSNM_KOREAN"));
				smsMap.put("metalCode", fallSelPc.getMetalName());
				smsMap.put("sarokPc", String.format("%,d", Math.round(sarokPc / 1.1)));
				smsMap.put("lwetPc", String.format("%,d", Math.round(selPc + premiumAmount)));
				smsMap.put("fallSelPc", String.format("%,d", Math.round(fallSelPc.getFallSelPc())));

				smsService.insertSMS(smsVO, smsMap);
				// }
				// }
			} catch (Exception e) {
				log.debug("[FallSelPc][sendFallPcMessage] " + ExceptionUtils.getStackTrace(e));
			}
		};
		taskExecutor.execute(smsRun);
	}
	
	// SMS 발송 업데이트
	private synchronized void sendFallNumPcMessage(String metalCode, String primiunPc, long selPc, String StartPriceYn, String metalNm) {
		Runnable smsRun = () -> {
			try {
				//log.info("-----------------sendFallPcMessag------------------------" +
				//premiumAmount + "FALL_SEL_SEQ" + fallSelPc.getFallSeqNo() + "FALL_SEL_PC : "
				//+ fallSelPc.getFallSelPc());
				List<Map<String, String>> returnList = pcService.selectMemberSmsByMetalCode(metalCode);
				
				for (Map<String, String> returnMap : returnList) {
					
					if (StringUtils.isNotEmpty(returnMap.get("MOBLPHON_NO"))) {
						
						SMSVO smsVO = new SMSVO();
						smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
						smsVO.setCommerceNtcnAt("N"); // 커머스 알림 여부
						
						try {
							smsVO.setPhone(CryptoUtil.decryptAES256(returnMap.get("MOBLPHON_NO")));
						} catch (Exception e) {
							log.debug("FallSelPc sendFallNumPcMessage MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
						}
						
						Map<String, String> smsMap = new HashMap<>();
						smsMap.put("templateNum", "113");
						smsMap.put("entrpsKorean", returnMap.get("ENTRPSNM_KOREAN"));
						smsMap.put("metalCode", metalNm);
				
						if (StringUtils.equals(StartPriceYn, "Y")) {
							smsMap.put("lwetPc", StringUtil.formatMoney(primiunPc) + "원 이하에서 시작되었");
						} else {
							smsMap.put("lwetPc", StringUtil.formatMoney(primiunPc) + "원을 하향돌파 하였");
						}
						
						smsService.insertSMS(smsVO, smsMap);
					}
				}
			} catch (Exception e) {
				log.debug("[FallSelPc][sendFallNumPcMessage] " + ExceptionUtils.getStackTrace(e));
			}
		};
		taskExecutor.execute(smsRun);
	}
	
	// SMS 발송 업데이트
	private synchronized void sendFallNumPcMessage2(String metalCode, String primiunPc, long selPc, String StartPriceYn, String metalNm) {
		Runnable smsRun = () -> {
			try {
				// log.info("-----------------sendFallPcMessag------------------------" +
				// premiumAmount + "FALL_SEL_SEQ" + fallSelPc.getFallSeqNo() + "FALL_SEL_PC : "
				// + fallSelPc.getFallSelPc());
				// List<Map<String, String>> returnList =
				// pcService.selectMemberSmsByMetalCode(fallSelPc.getMetalCode());
				// for (Map<String, String> returnMap : returnList) {
				// if (StringUtils.isNotEmpty(returnMap.get("MOBLPHON_NO"))) {
				SMSVO smsVO = new SMSVO();
				smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
				smsVO.setCommerceNtcnAt("N"); // 커머스 알림 여부
					try {
					smsVO.setPhone("01072026805");// CryptoUtil.decryptAES256(returnMap.get("MOBLPHON_NO")));
				} catch (Exception e) {
					log.debug("FallSelPc sendFallPcMessage MOBLPHON_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
				Map<String, String> smsMap = new HashMap<>();
				smsMap.put("templateNum", "113");
				smsMap.put("entrpsKorean", "허허허허");// returnMap.get("ENTRPSNM_KOREAN"));
				smsMap.put("metalCode", metalNm);
				
				if (StringUtils.equals(StartPriceYn, "Y")) {
					smsMap.put("lwetPc", StringUtil.formatMoney(primiunPc) + "원 이하에서 시작되었");
				} else {
					smsMap.put("lwetPc", StringUtil.formatMoney(primiunPc) + "원을 하향돌파 하였");
				}
					smsService.insertSMS(smsVO, smsMap);
				// }
				// }
			} catch (Exception e) {
				log.debug("[FallSelPc][sendFallNumPcMessage] " + ExceptionUtils.getStackTrace(e));
			}
		};
		taskExecutor.execute(smsRun);
	}
}