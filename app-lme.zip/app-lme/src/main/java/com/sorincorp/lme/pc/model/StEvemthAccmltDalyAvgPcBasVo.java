package com.sorincorp.lme.pc.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class StEvemthAccmltDalyAvgPcBasVo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3807685763409755925L;
	
	/******  JAVA VO CREATE : ST_EVEMTH_ACCMLT_DALY_AVG_PC_BAS()	******/
    
	/**
     * 발생 일자
    */
    private String occrrncDe; 
    
    /**
     * 금속 코드
    */
    private String metalCode; 
    
    /**
     * 아이템 순번
    */
    private int itmSn; 
    
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode; 
    
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode; 
    
    /**
     * 브랜드 코드
    */
    private String brandCode; 
    
    /**
     * LME CSP 가격
    */
    private java.math.BigDecimal lmeCsp; 
    
    /**
     * 달러환산률
    */
    private java.math.BigDecimal usdCvtrate; 
    
    /**
     * 누적 평균 가격
    */
    private java.math.BigDecimal avgSelPc; 
    
    /**
     * 시작 가격
    */
    private java.math.BigDecimal beginPc; 
    
    /**
     * 최고 가격
    */
    private java.math.BigDecimal topPc; 
    
    /**
     * 최저 가격
    */
    private java.math.BigDecimal lwetPc; 
    
    /**
     * 종료 가격
    */
    private java.math.BigDecimal endPc; 
    
    /**
     * 중간 가격
    */
    private java.math.BigDecimal middlePc; 
    
    /**
     * 조달청 가격
    */
    private java.math.BigDecimal sarokPc; 
    
    /**
     * 조달청 가격 VAT
    */
    private java.math.BigDecimal nonVatSarokPc; 
    
    /**
     * 삭제 날짜
    */
    private java.sql.Timestamp deleteDt; 
    
    /**
     * 삭제 여부
    */
    private String deleteAt; 
    
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId; 
   
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt; 
    
    /**
     * LME 조정 계수
    */
    private java.math.BigDecimal lmeMdatCffcnt; 
    
    /**
     * FX 조정 계수
    */
    private java.math.BigDecimal fxMdatCffcnt; 
    
    /**
     * 프리미엄 가격
    */
    private long premiumPc; 
	
}
