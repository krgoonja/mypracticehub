package com.sorincorp.lme.spclty.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class IfLmeSpcltyLgVo implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 4737175651831808978L;
	/**
     * 수신일시
    */
    private String receptDatetime;
    /**
     * 전문타입
    */
    private String type;
    /**
     * 품목코드
    */
    private String metalCode;
    /**
     * 내부코드
    */
    private String innerCode;
    /**
     * 국가
    */
    private String countryCd;
    /**
     * 지역
    */
    private String lctncd;
    /**
     * 등급
    */
    private String grdecd;
    /**
     * 초기재고
    */
    private String openvol;
    /**
     * 반입
    */
    private String invol;
    /**
     * 반출
    */
    private String outvol;
    /**
     * 최종재고
    */
    private String closevol;
    /**
     * warrant
    */
    private String onwrnt;
    /**
     * 취소 warrant
    */
    private String cnclwrnt;
    /**
     * 취소 warrant 비중
    */
    private String cnclwrntRate;
    /**
     * 전일대비
    */
    private String netchng;
    /**
     * 영국영업일
    */
    private String tradeDate;
}