package com.sorincorp.lme.pc.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sorincorp.comm.it.model.ItFtrsFshgManageDtlVo;
import com.sorincorp.comm.it.service.ItFtrsFshgManageDtlVoService;
import com.sorincorp.comm.it.service.ReturnNewItVo;
import com.sorincorp.lme.ReciveLmeDataByUdpSocket;
import com.sorincorp.lme.constant.PrPcStdrBasVoConstant;
import com.sorincorp.lme.pc.model.PrLmeEvlPcBasVo;
import com.sorincorp.lme.pc.model.PrLmePblntfPcBasVo;
import com.sorincorp.lme.pc.model.PrLmePcStdrBasVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLaVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLcVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLeVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLhVo;
import com.sorincorp.lme.util.RestDateTime;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ReturnNewIfVo {
	@Autowired
	private RestDateTime restDateTime;
	
	private final PrLmePcStdrBasVoMapService prLmePcStdrBasVoMapService;
	private final ItFtrsFshgManageDtlVoService itFtrsFshgManageDtlVoService;

	@Value("${metalCode.Zn}") private String metalCodeZn;
	@Value("${metalCode.Pb}") private String metalCodePb;
	@Value("${metalCode.Cu}") private String metalCodeCu;
	@Value("${metalCode.Al}") private String metalCodeAl;
	@Value("${metalCode.Ni}") private String metalCodeNi;
	@Value("${metalCode.Sn}") private String metalCodeSn;
	
	@Value("${gicName.Zn}") private String gicNameZn;
	@Value("${gicName.Pb}") private String gicNamePb;
	@Value("${gicName.Cu}") private String gicNameCu;
	@Value("${gicName.Al}") private String gicNameAl;
	@Value("${gicName.Ni}") private String gicNameNi;
	@Value("${gicName.Sn}") private String gicNameSn;
	
	@Value("${gicName.list}") private List<String> gicNameList;	// LZNM03,LPBM03,LCUM03,LALM03,LNIM03,LSNM03
	
	@Autowired
	public ReturnNewIfVo(PrLmePcStdrBasVoMapService prLmePcStdrBasVoMapService, ItFtrsFshgManageDtlVoService itFtrsFshgManageDtlVoService) {
		this.prLmePcStdrBasVoMapService = prLmePcStdrBasVoMapService;
		this.itFtrsFshgManageDtlVoService = itFtrsFshgManageDtlVoService;
	}
	
    public PrLmePcStdrBasVo process_PrLmePcStdrBasVoFromIf (IfLmeSpcltyLcVo vo) throws Exception {
    	//알루미늄
		if (gicNameList.contains(vo.getGicName())) {
			PrLmePcStdrBasVo returnVo = new PrLmePcStdrBasVo();
			
			returnVo.setMetalCode(getMetalCode(vo.getGicName()));
			returnVo.setOccrrncDe(vo.getReceptDate());
			returnVo.setOccrrncTime(vo.getReceptTime());
			returnVo.setOccrrncSn(vo.getReceptDatetime().substring(10, 20));
			returnVo.setLmePcRltmSn(vo.getReceptDatetime());
			returnVo.setLmeBsnDe(vo.getTradeDate());
			returnVo.setBeginPc(new BigDecimal(vo.getStart()));
			returnVo.setEndPc(new BigDecimal(vo.getNow()));
			returnVo.setTopPc(new BigDecimal(vo.getHigh()));
			returnVo.setLwetPc(new BigDecimal(vo.getLow()));
			returnVo.setVersusPc(new BigDecimal(vo.getNetchng()));
			returnVo.setVersusRate(new BigDecimal(vo.getPctchng()));
			returnVo.setDelngQy(Integer.parseInt(vo.getTrdvol()));
			returnVo.setAccmltDelngQy(Integer.parseInt(vo.getAcvol()));
			returnVo.setSpread(new BigDecimal(vo.getSpread()));
			returnVo.setThreemonthBeginPc(new BigDecimal(vo.getFuturesStart()));
			returnVo.setThreemonthEndPc(new BigDecimal(vo.getFuturesNow()));
			returnVo.setThreemonthTopPc(new BigDecimal(vo.getFuturesHigh()));
			returnVo.setThreemonthLwetPc(new BigDecimal(vo.getFuturesLow()));
			returnVo.setThreemonthVersusPc(new BigDecimal(vo.getFuturesNetchng()));
			returnVo.setThreemonthVersusRate(new BigDecimal(vo.getFuturesPctchng()));

			// 선물/선물환 관리 데이터 조회
			ReturnNewItVo returnNewItVo = new ReturnNewItVo();
			ItFtrsFshgManageDtlVo returnItVo = returnNewItVo.process_CopyNewVo(itFtrsFshgManageDtlVoService.getItFtrsFshgManageDtlVo(returnVo.getMetalCode()));

			// LME 조정 계수
			BigDecimal lmeMdatCffcnt = returnItVo.getLmeMdatCffcntAmount();
			returnVo.setLmeMdatCffcnt(lmeMdatCffcnt);

			// LME 조정 가격 정보 세팅
			returnVo.setBeginMdatPc(new BigDecimal(vo.getStart()).add(lmeMdatCffcnt));
			returnVo.setEndMdatPc(new BigDecimal(vo.getNow()).add(lmeMdatCffcnt));
			returnVo.setTopMdatPc(new BigDecimal(vo.getHigh()).add(lmeMdatCffcnt));
			returnVo.setLwetMdatPc(new BigDecimal(vo.getLow()).add(lmeMdatCffcnt));
			returnVo.setThreemonthBeginMdatPc(new BigDecimal(vo.getFuturesStart()).add(lmeMdatCffcnt));
			returnVo.setThreemonthEndMdatPc(new BigDecimal(vo.getFuturesNow()).add(lmeMdatCffcnt));
			returnVo.setThreemonthTopMdatPc(new BigDecimal(vo.getFuturesHigh()).add(lmeMdatCffcnt));
			returnVo.setThreemonthLwetMdatPc(new BigDecimal(vo.getFuturesLow()).add(lmeMdatCffcnt));

			return returnVo;
		}
		
		return null;
    }
    
    public PrLmePblntfPcBasVo process_PrLmePblntfPcBasVoFromIf (IfLmeSpcltyLaVo vo) throws Exception {
    	//알루미늄
		if (gicNameList.contains(vo.getGicName())) {
			PrLmePblntfPcBasVo returnVo = new PrLmePblntfPcBasVo();
			
			returnVo.setMetalCode(getMetalCode(vo.getGicName()));
			returnVo.setOccrrncDe(vo.getTradeDate());
			returnVo.setLmePblntfPcSn(vo.getReceptDatetime());
			returnVo.setBfeBsnDe(vo.getPrevDate());
			returnVo.setActhngPblntfPrchasPc(new BigDecimal(vo.getCashBid()));
			returnVo.setActhngPblntfSalePc(new BigDecimal(vo.getCashAsk()));
			returnVo.setFtrsPblntfPrchasPc(new BigDecimal(vo.getFutBid()));
			returnVo.setFtrsPblntfSalePc(new BigDecimal(vo.getFutAsk()));
			returnVo.setActhngExprtnDe(vo.getCashExpirDate());
			
			return returnVo;
		}
		
		return null;
	}
	
	// 니켈 LME 값 세팅
	public PrLmePcStdrBasVo process_PrLmePcStdrBasVoFromIfMetalNi (IfLmeSpcltyLhVo vo) throws Exception {
		if(gicNameNi.equals(vo.getGicName()) && Double.parseDouble(vo.getBestAsk1()) != 0.0) {
			PrLmePcStdrBasVo stdrVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCodeNi, PrPcStdrBasVoConstant.STDR);
			PrLmePcStdrBasVo pastNickelVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(PrPcStdrBasVoConstant.PAST_NICKEL);
			java.math.BigDecimal pastNickelendPc = new java.math.BigDecimal(0);
			
			if(pastNickelVo == null) {
				pastNickelendPc = new java.math.BigDecimal(0);
			} else {
				pastNickelendPc = pastNickelVo.getEndPc();
			}
			
			PrLmePcStdrBasVo returnVo = new PrLmePcStdrBasVo();
			returnVo.setMetalCode(getMetalCode(vo.getGicName()));
			returnVo.setOccrrncDe(vo.getReceptDate());
			returnVo.setOccrrncTime(vo.getReceptTime());
			returnVo.setOccrrncSn(vo.getReceptDatetime().substring(10, 20));
			returnVo.setLmePcRltmSn(vo.getReceptDatetime());
			returnVo.setLmeBsnDe(vo.getTradeDate());
			
			//returnVo.setEndPc(new BigDecimal(vo.getBestAsk1()));
			returnVo.setSpread(ReciveLmeDataByUdpSocket.niLcSpread);
			returnVo.setEndPc(new BigDecimal(vo.getBestAsk1()).add(returnVo.getSpread()));
			
			if(restDateTime.getReadytoStartLmeData(returnVo.getMetalCode()) || stdrVo == null ) {
				log.info("nickel ready to start lme data");
				returnVo.setBeginPc(returnVo.getEndPc());
				returnVo.setTopPc(returnVo.getEndPc());
				returnVo.setLwetPc(returnVo.getEndPc());
			} else {
				returnVo.setBeginPc(stdrVo.getBeginPc());
				returnVo.setTopPc(stdrVo.getTopPc());
				returnVo.setLwetPc(stdrVo.getLwetPc());
				
				if(returnVo.getEndPc().compareTo(returnVo.getTopPc()) >= 0) {
					returnVo.setTopPc(returnVo.getEndPc());
				} 
				
				if(returnVo.getEndPc().compareTo(returnVo.getLwetPc()) <= 0) {
					returnVo.setLwetPc(returnVo.getEndPc());
				}
			}
			
			returnVo.setVersusPc(returnVo.getEndPc().subtract(pastNickelendPc));
			returnVo.setVersusRate(((returnVo.getEndPc().subtract(pastNickelendPc)).divide(pastNickelendPc, 6, RoundingMode.HALF_UP)).multiply(new BigDecimal(100)));	
			returnVo.setDelngQy(0);
			returnVo.setAccmltDelngQy(0);

			returnVo.setThreemonthBeginPc(returnVo.getBeginPc().subtract(returnVo.getSpread()));
			returnVo.setThreemonthEndPc(new BigDecimal(vo.getBestAsk1()));
			returnVo.setThreemonthTopPc(returnVo.getTopPc().subtract(returnVo.getSpread()));
			returnVo.setThreemonthLwetPc(returnVo.getLwetPc().subtract(returnVo.getSpread()));
			returnVo.setThreemonthVersusPc(returnVo.getVersusPc());
			returnVo.setThreemonthVersusRate(returnVo.getVersusRate());

			// 선물/선물환 관리 데이터 조회
			ReturnNewItVo returnNewItVo = new ReturnNewItVo();
			ItFtrsFshgManageDtlVo returnItVo = returnNewItVo.process_CopyNewVo(itFtrsFshgManageDtlVoService.getItFtrsFshgManageDtlVo(returnVo.getMetalCode()));

			// LME 조정 계수
			BigDecimal lmeMdatCffcnt = returnItVo.getLmeMdatCffcntAmount();
			returnVo.setLmeMdatCffcnt(lmeMdatCffcnt);

			// LME 조정 가격 정보 세팅
			returnVo.setBeginMdatPc(returnVo.getBeginPc().add(lmeMdatCffcnt));
			returnVo.setEndMdatPc(returnVo.getEndPc().add(lmeMdatCffcnt));
			returnVo.setTopMdatPc(returnVo.getTopPc().add(lmeMdatCffcnt));
			returnVo.setLwetMdatPc(returnVo.getLwetPc().add(lmeMdatCffcnt));
			returnVo.setThreemonthBeginMdatPc(returnVo.getThreemonthBeginPc().add(lmeMdatCffcnt));
			returnVo.setThreemonthEndMdatPc(returnVo.getThreemonthEndPc().add(lmeMdatCffcnt));
			returnVo.setThreemonthTopMdatPc(returnVo.getThreemonthTopPc().add(lmeMdatCffcnt));
			returnVo.setThreemonthLwetMdatPc(returnVo.getThreemonthLwetPc().add(lmeMdatCffcnt));

			if(!ReciveLmeDataByUdpSocket.receiveMetalCodeList.contains(returnVo.getMetalCode())) {
				ReciveLmeDataByUdpSocket.receiveMetalCodeList.add(returnVo.getMetalCode());
				log.info("receiveMetalCodeList add: " + returnVo.getMetalCode());
			}
//			restDateTime.setNickelStatusCode(NickelStatus.SUCCESS);
			
			return returnVo;
		}
		return null;
	}
	
	public PrLmeEvlPcBasVo process_PrLmeEvlPcBasVoFromIf (IfLmeSpcltyLeVo vo) throws Exception {
		if (gicNameList.contains(vo.getMetalCode() + "M03")) {
			PrLmeEvlPcBasVo returnVo = new PrLmeEvlPcBasVo();
			
			returnVo.setMetalCode(getMetalCode(vo.getMetalCode()));
			returnVo.setOccrrncDe(vo.getTradeDate());
			returnVo.setEvlDe(vo.getExpirDate());
			returnVo.setLmeEvlPcSn(vo.getReceptDatetime());
			returnVo.setEvlPc(new BigDecimal(vo.getSettle()));
			
			return returnVo;
		}
		
		return null;
	}
	
	public PrLmeEvlPcBasVo process_CopyNewLmeEvlVo (PrLmeEvlPcBasVo vo) throws Exception {
    	PrLmeEvlPcBasVo returnVo = new PrLmeEvlPcBasVo();
		BeanUtils.copyProperties(vo, returnVo);
		
		return returnVo;
    }
    
    public PrLmePcStdrBasVo process_CopyNewLmeStdrVo (PrLmePcStdrBasVo vo) throws Exception {
    	PrLmePcStdrBasVo returnVo = new PrLmePcStdrBasVo();
		BeanUtils.copyProperties(vo, returnVo);
		
		return returnVo;
    }
    
    private String getMetalCode(String value) {
    	
    	if(value.equals(gicNameZn) || value.equals(gicNameZn.substring(0,3))) return metalCodeZn;
    	if(value.equals(gicNamePb) || value.equals(gicNamePb.substring(0,3))) return metalCodePb;
    	if(value.equals(gicNameCu) || value.equals(gicNameCu.substring(0,3))) return metalCodeCu;
    	if(value.equals(gicNameAl) || value.equals(gicNameAl.substring(0,3))) return metalCodeAl;
    	if(value.equals(gicNameNi) || value.equals(gicNameNi.substring(0,3))) return metalCodeNi;
    	if(value.equals(gicNameSn) || value.equals(gicNameSn.substring(0,3))) return metalCodeSn;
    	
    	return null;
    }
    
}
