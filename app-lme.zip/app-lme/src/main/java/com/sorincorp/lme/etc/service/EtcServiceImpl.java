package com.sorincorp.lme.etc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.lme.ReciveLmeDataByUdpSocket;
import com.sorincorp.lme.ehgt.service.PrEhgtPcStdrBasVoService;
import com.sorincorp.lme.etc.mapper.EtcMapper;
import com.sorincorp.lme.etc.model.CalculateSpreadVo;
import com.sorincorp.lme.etc.model.ClosedHoursVo;
import com.sorincorp.lme.etc.model.TodaySpreadVO;
import com.sorincorp.lme.etc.model.ValidLmeSpreadDateVo;
import com.sorincorp.lme.pc.service.PrLmePcStdrBasVoMapService;
import com.sorincorp.lme.sel.service.PrSelPcStdrBasVoMapService;
import com.sorincorp.lme.util.RestDateTime;
import com.sorincorp.lme.util.RestDateTime.EhgtStatus;
import com.sorincorp.lme.util.RestDateTime.LmeStatus;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EtcServiceImpl implements EtcService {

	@Value("${metalCode.list}") private List<String> metalCodeList;

	@Autowired
	private RestDateTime restDateTime;

	@Autowired
	private EtcMapper etcMapper;

	private final PrEhgtPcStdrBasVoService prEhgtPcStdrBasVoService;

	private final PrLmePcStdrBasVoMapService prLmePcStdrBasVoMapService;

	private final PrSelPcStdrBasVoMapService prSelPcStdrBasVoMapService;

	@Autowired
	public EtcServiceImpl(PrEhgtPcStdrBasVoService prEhgtPcStdrBasVoService
			, PrLmePcStdrBasVoMapService prLmePcStdrBasVoMapService
			, PrSelPcStdrBasVoMapService prSelPcStdrBasVoMapService) {
		this.prEhgtPcStdrBasVoService = prEhgtPcStdrBasVoService;
		this.prLmePcStdrBasVoMapService = prLmePcStdrBasVoMapService;
		this.prSelPcStdrBasVoMapService = prSelPcStdrBasVoMapService;
	}

	@Override
	public void insertItHvofTimeManageBas(ClosedHoursVo closedHoursVo) throws Exception {
		etcMapper.insertItHvofTimeManageBas(closedHoursVo);
		etcMapper.insertItHvofTimeManageBasHst(closedHoursVo);
	}

	@Override
	public void updateCntcStts(int status) throws Exception {
		etcMapper.updateCntcStts(status);
	}

	@Override
	public CalculateSpreadVo selectInterfaceSpread(CalculateSpreadVo vo) throws Exception {
		return etcMapper.selectInterfaceSpread(vo);
	}

	@Override
	public ValidLmeSpreadDateVo selectValidLmeSpreadDate(ValidLmeSpreadDateVo vo) throws Exception {
		return etcMapper.selectValidLmeSpreadDate(vo);
	}

	@Override
	public void deleteItHvofTimeManageBas(ClosedHoursVo closedHoursVo) throws Exception {
		etcMapper.deleteItHvofTimeManageBas(closedHoursVo);
		etcMapper.insertItHvofTimeManageBasHst(closedHoursVo);
	}

	@Override
	public int getGapTime(ClosedHoursVo closedHoursVo) throws Exception {
		return etcMapper.getGapTime(closedHoursVo);
	}

	@Override
	public void testSetting(int lmeStatus, int ehgtStatus, int initStatus) throws Exception {
		restDateTime.setIsLmeReceive(lmeStatus);
		restDateTime.setIsEhgtReceive(ehgtStatus);

		log.info("### setIsLmeReceive: " + lmeStatus + ", setIsEhgtRevice: " + ehgtStatus + " ###");

		/***************************************************/
		// initStatus가 1이라면 (false)
		if(initStatus == 1)
			return;

		log.info("####################### This testSetting initialization starts #######################");

		ReciveLmeDataByUdpSocket.receiveMetalCodeList.clear();
		ReciveLmeDataByUdpSocket.errorSpreadMetalCodeList.clear();
		ReciveLmeDataByUdpSocket.leSpreadMap.clear();

		prSelPcStdrBasVoMapService.clearPrSelPcStdrBasVo();
		prEhgtPcStdrBasVoService.clearPrEhgtPcStdrBasVo();

		//BeanUtils.copyProperties(null, prEhgtPcStdrBasVoService.getPrEhgtPcStdrBasVo());
		restDateTime.setEhgtStatusCode(EhgtStatus.FAIL);
		restDateTime.setLmeStatusCode(LmeStatus.FAIL);

		restDateTime.initialize();

		for(String metalCode : metalCodeList) {
			restDateTime.setReadytoLmeStartData(metalCode, true);
			restDateTime.setPubMessageStartLmeData(metalCode, true);
		}

		ReciveLmeDataByUdpSocket.isReadyToLmeSchedule = false;
		ReciveLmeDataByUdpSocket.isReadyToSelSchedule = false;

		log.info("####################### This testSetting initialization Done. #######################");

		/**************************************************/
	}

	@Override
	public TodaySpreadVO getTodaySpread(TodaySpreadVO todaySpreadVO) throws Exception {
		return etcMapper.getTodaySpread(todaySpreadVO);
	}

}