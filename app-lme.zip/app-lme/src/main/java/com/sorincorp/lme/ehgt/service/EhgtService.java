package com.sorincorp.lme.ehgt.service;

public interface EhgtService {
	
	/**
	 * <pre>
	 * 처리내용: 상품 영업관리 기본 테이블(IT_BSN_MANAGE_BAS) 에서 제일 최신 정보를 가져온다.
	 * </pre>
	 * @date 2021. 11. 7.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 7.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void selectTopPrEhgtPcStdrBas() throws Exception;
	
}
