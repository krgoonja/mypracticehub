package com.sorincorp.lme.pc.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class OpFallSelPcBasVo implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = -8058827907884144262L;

	/**
	 * 하락 일련번호
	 */
	private String fallSeqNo;
	/**
	 * 메탈 코드
	 */
	private String metalCode;
	/**
	 * 아이템 순번
	 */
	private int itmSn;
	/**
	 * 권역 대분류 코드
	 */
	private String dstrctLclsfCode;
	/**
	 * 브랜드 그룹 코드
	 */
	private String brandGroupCode;
	/**
	 * 하락 판매가격
	 */
	private long fallSelPc;
	/**
	 * 발생 일자
	 */
	private String occrrncDe;
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;

	/**
	 * 가격비교
	 */
	private long selPc;

	/**
	 * 가격하락 알림 발송여부
	 */
	private String smsYn;

	/**
	 * 조달청 가격
	 */
	private long sarokPc;

	/**
	 * 케이지트레이딩 최저가격
	 */
	private long lwetPc;

	/**
	 * 금속명
	 */
	private String metalName;

}
