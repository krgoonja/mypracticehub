package com.sorincorp.lme.sel.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.pcInfo.model.PrPremiumSelVO;
import com.sorincorp.comm.premium.service.ItPremiumStdrBasVoService;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.CacheUtil;
import com.sorincorp.lme.ReciveLmeDataByUdpSocket;
import com.sorincorp.lme.sel.model.PrSelPcStdrBasVo;
import com.sorincorp.lme.util.LmeDataUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PrSelPcStdrBasVoMapServiceImpl implements PrSelPcStdrBasVoMapService{
	
	@Autowired
	private ItPremiumStdrBasVoService itPremiumStdrBasVoService;
	
	@Autowired
	private RedisPubSubService redisPubSubService;
	
	@Autowired
	private CacheUtil cacheUtil;
	
	private Map<String, Map<String, PrSelPcStdrBasVo>> prSelPcStdrBasVoMap;
	
	public PrSelPcStdrBasVoMapServiceImpl() {
		if(prSelPcStdrBasVoMap == null) {
			this.prSelPcStdrBasVoMap = new HashMap<String, Map<String, PrSelPcStdrBasVo>>();
		}
	}
	
	public PrSelPcStdrBasVo getPrSelPcStdrBasVo(String metalCodeByProperties, String prPcStdrBasVoConstant) {
		
		if(!prSelPcStdrBasVoMap.containsKey(metalCodeByProperties)) {
			prSelPcStdrBasVoMap.put(metalCodeByProperties, new HashMap<String, PrSelPcStdrBasVo>());
		} 
		
		if(!prSelPcStdrBasVoMap.get(metalCodeByProperties).containsKey(prPcStdrBasVoConstant)) {
			prSelPcStdrBasVoMap.get(metalCodeByProperties).put(prPcStdrBasVoConstant, new PrSelPcStdrBasVo());
		}
		
		return prSelPcStdrBasVoMap.get(metalCodeByProperties).get(prPcStdrBasVoConstant);
	}
	
	public void clearPrSelPcStdrBasVo() {
		prSelPcStdrBasVoMap = new HashMap<String, Map<String, PrSelPcStdrBasVo>>();
	}

	@Async("lmeThreadPoolExcuter")
	@Override
	public void publishPremiumAddedSelPc(PrSelPcStdrBasVo vo) {
		List<PrPremiumSelVO> result = new ArrayList<>();
		result = itPremiumStdrBasVoService.getItPremiumStdrBasVo().entrySet().stream()
				.flatMap(entry -> entry.getValue().stream())
				.filter(livePremiumVO -> vo != null && livePremiumVO.getValidBeginDt().compareTo(vo.getOccrrncDe() + vo.getOccrrncTime()) <= 0
						&& livePremiumVO.getValidEndDt().compareTo(vo.getOccrrncDe() + vo.getOccrrncTime()) >= 0
						&& livePremiumVO.getMetalCode().equals(vo.getMetalCode()))
				.map(livePremiumVO -> {
					PrPremiumSelVO resultVo = new PrPremiumSelVO();
					long totalAmount = livePremiumVO.getSlePremiumAmount() + vo.getEndPc();
					resultVo.setMetalCode(vo.getMetalCode());							// 메탈코드
					resultVo.setEndPc(totalAmount);										// 프리미엄 가격 + 판매 가격
					resultVo.setItmSn(livePremiumVO.getItmSn());						// 아이템코드
					resultVo.setDstrctLclsfCode(livePremiumVO.getDstrctLclsfCode());	// 권역코드
					resultVo.setBrandGroupCode(livePremiumVO.getBrandGroupCode());		// 브랜드그룹코드
					resultVo.setBrandCode(livePremiumVO.getBrandCode());				// 브랜드코드
					resultVo.setSlePcRltmSn(vo.getSlePcRltmSn());						// 실시간 순번
					return resultVo;
				})
				.collect(Collectors.toList());
		
		if(result != null && !result.isEmpty()) {
			redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.selpcAllWebsocketUri + "/" + vo.getMetalCode(), ReciveLmeDataByUdpSocket.selpcAllWebsocketUri + "/" + vo.getMetalCode(), result);
			cacheUtil.put(LmeDataUtil.SEL_PC_ALL_LIST, result);
			
			if(vo.getMetalCode().equals("7")) {		// TODO 로그 삭제 예정 [pje]
				log.info("publishPremiumAddedSelPc: " + ReciveLmeDataByUdpSocket.selpcAllWebsocketUri + "/" + vo.getMetalCode());
			}
		}
	}
	
}