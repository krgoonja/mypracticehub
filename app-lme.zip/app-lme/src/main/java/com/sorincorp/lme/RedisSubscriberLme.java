package com.sorincorp.lme;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Map;
import java.util.TreeSet;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.dynmDiver.comm.DynmDiverSetup;
import com.sorincorp.comm.it.model.ItFtrsFshgManageDtlVo;
import com.sorincorp.comm.it.service.ItBsnManageBasVoService;
import com.sorincorp.comm.it.service.ItFtrsFshgManageDtlVoService;
import com.sorincorp.comm.it.service.ReturnNewItVo;
import com.sorincorp.comm.limit.service.LimitService;
import com.sorincorp.comm.limit.service.OrLimitOrderBasVoMapService;
import com.sorincorp.comm.order.model.CommLimitOrderRedisMsgVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderRedisMsgVO;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.premium.service.ItPremiumStdrBasVoService;
import com.sorincorp.comm.redis.config.RedisPubSubMessage;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.lme.constant.PrPcStdrBasVoConstant;
import com.sorincorp.lme.ehgt.model.PrEhgtPcStdrBasVo;
import com.sorincorp.lme.ehgt.service.PrEhgtPcStdrBasVoService;
import com.sorincorp.lme.ehgt.service.ReturnNewEhgtVo;
import com.sorincorp.lme.limit.service.FindMatchingLimitPriceThreadService;
import com.sorincorp.lme.pc.model.PrLmeEvlPcBasVo;
import com.sorincorp.lme.pc.model.PrLmePcStdrBasVo;
import com.sorincorp.lme.pc.service.PrLmeEvlPcBasVoMapService;
import com.sorincorp.lme.pc.service.PrLmeLhVoMapService;
import com.sorincorp.lme.pc.service.PrLmePcStdrBasVoMapService;
import com.sorincorp.lme.pc.service.ReturnNewLmeVo;
import com.sorincorp.lme.sel.model.PrSelPcStdrBasVo;
import com.sorincorp.lme.sel.service.PrSelPcStdrBasVoMapService;
import com.sorincorp.lme.sel.service.PrSelPremiumService;
import com.sorincorp.lme.sel.service.ReturnNewSelVo;
import com.sorincorp.lme.sel.service.SelService;
import com.sorincorp.lme.util.LimitDataUtil;
import com.sorincorp.lme.util.RestDateTime;
import com.sorincorp.lme.util.RestDateTime.EhgtStatus;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class RedisSubscriberLme implements MessageListener {	// RedisPubSubListener<String, Object>

	@Autowired
	private RedisPubSubService redisPubSubService;

	@Autowired
	private SelService selService;

	@Autowired
	private RestDateTime restDateTime;

	@Autowired
	private ReturnNewLmeVo returnNewLmeVo;

	@Autowired
	private ReturnNewEhgtVo returnNewEhgtVo;

	@Autowired
	private ReturnNewSelVo returnNewSelVo;

	@Autowired
	private ReturnNewItVo returnNewItVo;

	@Autowired
	private DynmDiverSetup dynmDiverSetup;

	@Autowired
	private LimitService limitService;

	@Autowired
	private ItPremiumStdrBasVoService itPremiumStdrBasVoService;

	@Autowired
	private PcInfoService pcInfoService;

	@Autowired
	private FindMatchingLimitPriceThreadService findMatchingLimitPriceThreadService;

	@Autowired
	private PrSelPremiumService prSelPremiumService;

	@Value("${metalCode.Ni}") private String metalCodeNi;

	@Value("${redisPubsub.uri.restTime}") private String restTimeUri;

//	@Value("${metalCode.Al}")
//	private String metalCodeAl;

	private final PrLmePcStdrBasVoMapService prLmePcStdrBasVoMapService;
	private final PrLmeEvlPcBasVoMapService prLmeEvlPcBasVoMapService;
	private final PrSelPcStdrBasVoMapService prSelPcStdrBasVoMapService;
	private final PrEhgtPcStdrBasVoService prEhgtPcStdrBasVoService;
	private final ItBsnManageBasVoService itBsnManageBasVoService;
	private final ItFtrsFshgManageDtlVoService itFtrsFshgManageDtlVoService;
	private final PrLmeLhVoMapService prLmeLhVoMapService;
	private final OrLimitOrderBasVoMapService orderLimitOrderBasVoMapService;

	@Autowired
	public RedisSubscriberLme(PrLmePcStdrBasVoMapService prLmePcStdrBasVoMapService
								, PrLmeEvlPcBasVoMapService prLmeEvlPcBasVoMapService
								, PrSelPcStdrBasVoMapService prSelPcStdrBasVoMapService
								, PrEhgtPcStdrBasVoService prEhgtPcStdrBasVoService
								, ItBsnManageBasVoService itBsnManageBasVoService
								, ItFtrsFshgManageDtlVoService itFtrsFshgManageDtlVoService
								, PrLmeLhVoMapService prLmeLhVoMapService
								, OrLimitOrderBasVoMapService orderLimitOrderBasVoMapService
								) {
		this.prLmePcStdrBasVoMapService = prLmePcStdrBasVoMapService;
		this.prLmeEvlPcBasVoMapService = prLmeEvlPcBasVoMapService;
		this.prSelPcStdrBasVoMapService = prSelPcStdrBasVoMapService;
		this.prEhgtPcStdrBasVoService = prEhgtPcStdrBasVoService;
		this.itBsnManageBasVoService = itBsnManageBasVoService;
		this.itFtrsFshgManageDtlVoService = itFtrsFshgManageDtlVoService;
		this.prLmeLhVoMapService = prLmeLhVoMapService;
		this.orderLimitOrderBasVoMapService = orderLimitOrderBasVoMapService;
	}

	// FX에서 환율 받아와서 처리하는 부분
	@Override
	public void onMessage(Message message, byte[] pattern) {
		log.info("check isEhgtReceive: " + restDateTime.getIsEhgtReceive());

		if(restDateTime.getIsEhgtReceive() == 1) // TODO [pje]주석처리예정
			return;



		byte[] messageBody = message.getBody();
		ByteArrayInputStream in = new ByteArrayInputStream(messageBody);
		ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ObjectInputStream is =null;
		RedisPubSubMessage pubSubMsg = null;
		try {
			is = new ObjectInputStream(in);
			pubSubMsg = (RedisPubSubMessage) is.readObject();
			String channel = pubSubMsg.getChannelId();
			if(channel.equals(ReciveLmeDataByUdpSocket.fxWebSocketUri) && !ReciveLmeDataByUdpSocket.isReadyToSelSchedule && restDateTime.isRealRltmSellTime()) {
				// 실시간 환율 가격을 받는다
				PrEhgtPcStdrBasVo vo = objMapper.readValue(pubSubMsg.getMessage().toString(), PrEhgtPcStdrBasVo.class);
				BeanUtils.copyProperties(vo, prEhgtPcStdrBasVoService.getPrEhgtPcStdrBasVo());

				log.info("ehgtStatusCode : " + restDateTime.getEhgtStatusCode());

				restDateTime.setEhgtStatusCode(EhgtStatus.SUCCESS);	// [pje]환율 상태 변경
				log.info("fxWebSocketUri: received the EHGT data");

			}

			// fxWebSocket 채널이면서 processLcSel 함수가 실행된 상태라면(판매 스케줄러가 준비 상태라면)
			else if(channel.equals(ReciveLmeDataByUdpSocket.fxWebSocketUri) && ReciveLmeDataByUdpSocket.isReadyToSelSchedule && restDateTime.isRealRltmSellTime() && !restDateTime.getIsRestDay()) {

				// 실시간 환율 가격을 받는다
				PrEhgtPcStdrBasVo vo = objMapper.readValue(pubSubMsg.getMessage().toString(), PrEhgtPcStdrBasVo.class);
				BeanUtils.copyProperties(vo, prEhgtPcStdrBasVoService.getPrEhgtPcStdrBasVo());

				restDateTime.setEhgtStatusCode(EhgtStatus.SUCCESS);	// [pje]환율 상태 변경

				log.info("isReadyToSelSchedule: received the EHGT data");

				for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {

//					if(metalCode.equals(metalCodeNi) && restDateTime.getNickelStatusCode() == NickelStatus.FAIL.value)
//						continue;

					//log.info("for metal " + metalCode);
					PrSelPcStdrBasVo oneMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.ONE_MINUTE);
					PrSelPcStdrBasVo pastOneMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE);
					PrSelPcStdrBasVo thirtyMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.THIRTY_MINUTE);
					PrSelPcStdrBasVo pastThirtyMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE);
					PrSelPcStdrBasVo sixtyMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.SIXTY_MINUTE);
					PrSelPcStdrBasVo pastSixtyMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE);
					PrSelPcStdrBasVo day = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.DAY);
					PrSelPcStdrBasVo pastDay = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_DAY);
					PrSelPcStdrBasVo week = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.WEEK);
					PrSelPcStdrBasVo pastWeek = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_WEEK);
					PrSelPcStdrBasVo month = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.MONTH);
					PrSelPcStdrBasVo pastMonth = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_MONTH);
					PrSelPcStdrBasVo quarter = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.QUARTER);
					PrSelPcStdrBasVo pastQuarter = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_QUARTER);
					PrSelPcStdrBasVo year = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.YEAR);
					PrSelPcStdrBasVo pastYear = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_YEAR);

					PrLmePcStdrBasVo nowLmeStdrVo = returnNewLmeVo.process_CopyNewLmeStdrVo(prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.STDR));
					PrLmeEvlPcBasVo returnPrLmeEvlPcBasVo = returnNewLmeVo.process_CopyNewLmeEvlVo(prLmeEvlPcBasVoMapService.getPrLmeEvlPcBasVo(metalCode));
					PrEhgtPcStdrBasVo returnEhgtVo = returnNewEhgtVo.process_CopyNewVo(prEhgtPcStdrBasVoService.getPrEhgtPcStdrBasVo());

					ItFtrsFshgManageDtlVo returnItVo = returnNewItVo.process_CopyNewVo(itFtrsFshgManageDtlVoService.getItFtrsFshgManageDtlVo(nowLmeStdrVo.getMetalCode()));
					PrSelPcStdrBasVo returnPastSelStdrAlVo = returnNewSelVo.process_CopyNewSelStdrVo(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.STDR));

					Map<String, Boolean> oneMinuteChange	= returnNewSelVo.checkChangeSel(nowLmeStdrVo.getMetalCode(), DateUtil.getNowDateTime("HHmmss"), oneMinute.getOccrrncTime(), "01");
					Map<String, Boolean> thirtyMinuteChange	= returnNewSelVo.checkChangeSel(nowLmeStdrVo.getMetalCode(), DateUtil.getNowDateTime("HHmmss"), thirtyMinute.getOccrrncTime(), "30");
					Map<String, Boolean> sixtyMinuteChange	= returnNewSelVo.checkChangeSel(nowLmeStdrVo.getMetalCode(), DateUtil.getNowDateTime("HHmmss"), sixtyMinute.getOccrrncTime(), "60");
					Map<String, Boolean> deChange			= returnNewSelVo.checkChangeSel(nowLmeStdrVo.getMetalCode(), DateUtil.getNowDateTime("HHmmss"), day.getOccrrncTime(), "DE");

					PrSelPcStdrBasVo returnSelStdrVo = returnNewSelVo.process_PrSelPcStdrBasVo(nowLmeStdrVo, returnPrLmeEvlPcBasVo, returnEhgtVo
																								, returnItVo, returnPastSelStdrAlVo);

					PrSelPcStdrBasVo returnSel01Minutes = returnNewSelVo.process_MinuteScheduleVo(nowLmeStdrVo, returnPrLmeEvlPcBasVo, returnEhgtVo
																									, returnItVo, oneMinute, pastOneMinute, "01", oneMinuteChange);
					PrSelPcStdrBasVo returnSel30Minutes = returnNewSelVo.process_MinuteScheduleVo(nowLmeStdrVo, returnPrLmeEvlPcBasVo, returnEhgtVo
																									, returnItVo, thirtyMinute, pastThirtyMinute, "30", thirtyMinuteChange);
					PrSelPcStdrBasVo returnSel60Minutes = returnNewSelVo.process_MinuteScheduleVo(nowLmeStdrVo, returnPrLmeEvlPcBasVo, returnEhgtVo
																									, returnItVo, sixtyMinute, pastSixtyMinute, "60", sixtyMinuteChange);
					PrSelPcStdrBasVo returnSelDe = returnNewSelVo.process_MinuteScheduleVo(nowLmeStdrVo, returnPrLmeEvlPcBasVo, returnEhgtVo
																							, returnItVo, day, pastDay, "DE", deChange);
					PrSelPcStdrBasVo returnSelWeek = returnNewSelVo.process_MinuteScheduleVo(nowLmeStdrVo, returnPrLmeEvlPcBasVo, returnEhgtVo
																								, returnItVo,week, pastWeek, "WK", deChange);
					PrSelPcStdrBasVo returnSelMt = returnNewSelVo.process_MinuteScheduleVo(nowLmeStdrVo, returnPrLmeEvlPcBasVo, returnEhgtVo
																							, returnItVo, month, pastMonth, "MT", deChange);
					PrSelPcStdrBasVo returnSelQu = returnNewSelVo.process_MinuteScheduleVo(nowLmeStdrVo, returnPrLmeEvlPcBasVo, returnEhgtVo
																							, returnItVo, quarter, pastQuarter, "QU", deChange);
					PrSelPcStdrBasVo returnSelYy = returnNewSelVo.process_MinuteScheduleVo(nowLmeStdrVo, returnPrLmeEvlPcBasVo, returnEhgtVo
																							, returnItVo, year, pastYear, "YY", deChange);

					// 여기에 startLmeData 추가
					if(restDateTime.getPubMessageStartLmeData(metalCode)) {
						redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.startLmeDataSocketUri, ReciveLmeDataByUdpSocket.startLmeDataSocketUri, "startLmeData/" + metalCode);
						log.info(metalCode + " startLmeDataSocketUri success / RedisSubscriberLme");
						restDateTime.setPubMessageStartLmeData(metalCode, false);
					}

					if(restDateTime.isSorinRltmWorkTime()) {
						// 프리미엄 적용한 판매가격 publish
						prSelPremiumService.calculatePremiumAddedSelPc(returnSelStdrVo);
					}

					if(restDateTime.getReadytoStartLmeData(metalCode)) {
						log.info("####################### EHGT: LME start data recieved in SEL area #######################");

						pastOneMinute.setBeginPc(returnSelStdrVo.getEndPc());
						pastOneMinute.setEndPc(returnSelStdrVo.getEndPc());
						pastOneMinute.setTopPc(returnSelStdrVo.getEndPc());
						pastOneMinute.setLwetPc(returnSelStdrVo.getEndPc());

						pastThirtyMinute.setBeginPc(returnSelStdrVo.getEndPc());
						pastThirtyMinute.setEndPc(returnSelStdrVo.getEndPc());
						pastThirtyMinute.setTopPc(returnSelStdrVo.getEndPc());
						pastThirtyMinute.setLwetPc(returnSelStdrVo.getEndPc());

						pastSixtyMinute.setBeginPc(returnSelStdrVo.getEndPc());
						pastSixtyMinute.setEndPc(returnSelStdrVo.getEndPc());
						pastSixtyMinute.setTopPc(returnSelStdrVo.getEndPc());
						pastSixtyMinute.setLwetPc(returnSelStdrVo.getEndPc());

						pastDay.setBeginPc(returnSelStdrVo.getEndPc());
						pastDay.setEndPc(returnSelStdrVo.getEndPc());
						pastDay.setTopPc(returnSelStdrVo.getEndPc());
						pastDay.setLwetPc(returnSelStdrVo.getEndPc());

						pastWeek.setBeginPc(returnSelStdrVo.getEndPc());
						pastWeek.setEndPc(returnSelStdrVo.getEndPc());
						pastWeek.setTopPc(returnSelStdrVo.getEndPc());
						pastWeek.setLwetPc(returnSelStdrVo.getEndPc());

						pastMonth.setBeginPc(returnSelStdrVo.getEndPc());
						pastMonth.setEndPc(returnSelStdrVo.getEndPc());
						pastMonth.setTopPc(returnSelStdrVo.getEndPc());
						pastMonth.setLwetPc(returnSelStdrVo.getEndPc());

						pastQuarter.setBeginPc(returnSelStdrVo.getEndPc());
						pastQuarter.setEndPc(returnSelStdrVo.getEndPc());
						pastQuarter.setTopPc(returnSelStdrVo.getEndPc());
						pastQuarter.setLwetPc(returnSelStdrVo.getEndPc());

						pastYear.setBeginPc(returnSelStdrVo.getEndPc());
						pastYear.setEndPc(returnSelStdrVo.getEndPc());
						pastYear.setTopPc(returnSelStdrVo.getEndPc());
						pastYear.setLwetPc(returnSelStdrVo.getEndPc());

//						redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.startLmeDataSocketUri, ReciveLmeDataByUdpSocket.startLmeDataSocketUri, "startLmeData/" + metalCode);
//
//						log.info(metalCode + "startLmeDataSocketUri success");

						restDateTime.setReadytoLmeStartData(metalCode, false);
					}

					// 지정가 체크 스레드
					findMatchingLimitPriceThreadService.findMatchingLimitPriceThread(returnSelStdrVo);

					if(restDateTime.isSorinRltmWorkTime()) {
						PrSelPcStdrBasVo redisSelStdrVo = new PrSelPcStdrBasVo();
						BeanUtils.copyProperties(returnSelStdrVo, redisSelStdrVo);
						redisSelStdrVo.setBeginPc(0);
						redisSelStdrVo.setTopPc(0);
						redisSelStdrVo.setLwetPc(0);

						redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode, ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode , returnSelStdrVo);
					}

					PrSelPcStdrBasVo prSelPcStdrBasVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE);
					if (prSelPcStdrBasVo != null && returnSel01Minutes != null) {
						if(returnSel01Minutes.getSlePc01MinSn() != null && prSelPcStdrBasVo.getSlePc01MinSn() != null) {
							String returnSel01MinutesSn = returnSel01Minutes.getSlePc01MinSn().substring(0, 12);
							String prSelPcStdrBasVoSn = prSelPcStdrBasVo.getSlePc01MinSn().substring(0, 12);
							if (returnSel01MinutesSn.equals(prSelPcStdrBasVoSn)) {
								BeanUtils.copyProperties(returnSel01Minutes, prSelPcStdrBasVo);
							}
						}
					}

					PrSelPcStdrBasVo prSel30PcStdrBasVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE);
					if (prSel30PcStdrBasVo != null && returnSel30Minutes != null) {
						if(returnSel30Minutes.getSlePc30MinSn() != null && prSel30PcStdrBasVo.getSlePc30MinSn() != null) {
							String returnSel30MinutesSn = returnSel30Minutes.getSlePc30MinSn().substring(0, 12);
							String prSel30PcStdrBasVoSn = prSel30PcStdrBasVo.getSlePc30MinSn().substring(0, 12);
							if (returnSel30MinutesSn.equals(prSel30PcStdrBasVoSn)) {
								BeanUtils.copyProperties(returnSel30Minutes, prSel30PcStdrBasVo);
							}
						}
					}

					PrSelPcStdrBasVo prSel60PcStdrBasVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE);
					if (prSel60PcStdrBasVo != null && returnSel60Minutes != null) {
						if(returnSel60Minutes.getSlePc60MinSn() != null && prSel60PcStdrBasVo.getSlePc60MinSn() != null) {
							String returnSel60MinutesSn = returnSel60Minutes.getSlePc60MinSn().substring(0, 12);
							String prSel60PcStdrBasVoSn = prSel60PcStdrBasVo.getSlePc60MinSn().substring(0, 12);
							if (returnSel60MinutesSn.equals(prSel60PcStdrBasVoSn)) {
								BeanUtils.copyProperties(returnSel60Minutes, prSel60PcStdrBasVo);
							}
						}
					}

					//log.info("check 7)");

					BeanUtils.copyProperties(returnSelStdrVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.STDR));
		        	BeanUtils.copyProperties(returnSelStdrVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.RLTM));
					BeanUtils.copyProperties(returnSel01Minutes, oneMinute);
					BeanUtils.copyProperties(returnSel30Minutes, thirtyMinute);
					BeanUtils.copyProperties(returnSel60Minutes, sixtyMinute);
					BeanUtils.copyProperties(returnSelDe, day);
					BeanUtils.copyProperties(returnSelWeek, week);
					BeanUtils.copyProperties(returnSelMt, month);
					BeanUtils.copyProperties(returnSelQu, quarter);
					BeanUtils.copyProperties(returnSelYy, year);

					//log.info("check 8)");

					selService.insertPrSelPcStdrBas(returnSelStdrVo);
					selService.insertPrSelPcRltmBas(returnSelStdrVo);

					//log.info("check 9)");
					//log.info(" exchangeRate : " + returnSelStdrVo);
				}

				log.info(" exchangeRate : " + vo);
			} else if(channel.equals(ReciveLmeDataByUdpSocket.sideCarSocketUri)) {
				//List<SidecarVO> voList = objMapper.readValue(pubSubMsg.getMessage().toString(), new TypeReference<List<SidecarVO>>(){});
			} else if(channel.equals(ReciveLmeDataByUdpSocket.restTimeSocketUri)) {
				if("setRestTime".equals(pubSubMsg.getMessage().toString())) {
					//restDateTime.initialize();	[pje]주석처리
					restDateTime.setTodayHvof(); // 휴무시간 초기화
					log.info("============================setTodayHvof============================");
				}
			} else if(channel.equals(ReciveLmeDataByUdpSocket.lmeLhSocketUri)) {
				for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
					redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.lmeLhSocketUri, ReciveLmeDataByUdpSocket.lmeLhSocketUri + "/" + metalCode, "lmeLh/");
				}
			} else if(channel.equals(ReciveLmeDataByUdpSocket.limitSocketUri)) {
				log.info("Receive Limit URI");
				CommLimitOrderRedisMsgVO vo = new CommLimitOrderRedisMsgVO();
				vo = objMapper.readValue(pubSubMsg.getMessage().toString(), CommLimitOrderRedisMsgVO.class);
				saveLimitData(vo);

				dynmDiverSetup.executeDiver();

			} else if(channel.equals(ReciveLmeDataByUdpSocket.prvsnlLimitSocketUri)) {
				log.info("Receive PrvsnlLimitLme URI");
				CommPrvsnlLimitOrderRedisMsgVO vo = new CommPrvsnlLimitOrderRedisMsgVO();
				vo = objMapper.readValue(pubSubMsg.getMessage().toString(), CommPrvsnlLimitOrderRedisMsgVO.class);

				// 가단가 지정가 주문 save (LME, KRW)
				savePrvsnlLimitData(vo);

			} else if(channel.equals(ReciveLmeDataByUdpSocket.premiumWebsocketUri)) {
				if(pubSubMsg.getMessage().toString().contains(LimitDataUtil.LimitOrderSttusCode.UPDATE.value)){
					log.info("Premium info update");
					Map<String, TreeSet<LivePremiumVO>> originalMap = pcInfoService.getPremiumInfoMap();
					itPremiumStdrBasVoService.setItPremiumStdrBasVo(originalMap);
				}
			} else if(channel.equals(ReciveLmeDataByUdpSocket.lmePropertiesUri)) {
				log.info("Receive Diver Init");
				if(pubSubMsg.getMessage().toString().contains(DynmDiverSetup.RequestCode.INIT.value)){
					log.info("diver initialize start");
					dynmDiverSetup.initialize();
				}
			}

		} catch (IOException e) {
			log.error("IOException : " + e.toString() + " -> message : " + message.toString());
		} catch (ClassNotFoundException e) {
			log.error("ClassNotFoundException : " + e.toString() + " -> message : " + message.toString());
		} catch (Exception e) {
			log.error("Exception : " + e.toString() + " -> message : " + message.toString());
		}
	}

	/* ### 수신받은 지정가 데이터 저장 로직 ###
	 * 1. 그룹키 생성
	 * 2. 지정가주문번호-지정가입력금액 map 및 종목별 지정가 주문 리스트 세팅
	 *
	 * 3. 저장된 지정가 주문번호가 없는 경우 insert 되지 않은 상태이므로, 저장하는 로직만 타고 return
	 * 		- 프리미엄 제외 금액 계산하여 저장
	 * 4. 이미 저장된 지정가 주문번호가 있는 경우
	 * 		4-1. Update인 경우
	 * 			- 종목별 지정가 주문 리스트에서 해당 주문번호 데이터 삭제 후, 다시 insert
	 * 			- 지정가주문번호-지정가입력금액 map update
	 * 			- 프리미엄 제외 금액 계산하여 저장
	 * 		4-2. Delete인 경우
	 * 			- 종목별 지정가 주문 리스트와 지정가주문번호-지정가입력금액 map에서 삭제
	 */
	private synchronized void saveLimitData(CommLimitOrderRedisMsgVO redisVo) {
		try {
			log.info("1-0) receive redisVo: " + redisVo);

			// 1. 그룹키 생성
			String groupKey = limitService.generateKey(redisVo);

			// 2. 지정가주문번호-지정가입력금액 map 및 종목별 지정가 주문 리스트 세팅
			CommLimitOrderRedisMsgVO limitOrderNoInputAmountVo = orderLimitOrderBasVoMapService.getLimitOrderNoInputAmountVo(redisVo.getLimitOrderNo());	// 지정가주문번호-지정가입력금액 map

			// 3. 저장된 지정가 주문번호가 없는 경우 - insert 되지 않은 상태이므로, 저장하는 로직만 타고 return
			if(limitOrderNoInputAmountVo.getLimitInputAmount() == 0 &&
					redisVo.getIntrfcSttusCode().equals(LimitDataUtil.LimitOrderSttusCode.INSERT.value)) {
				orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(groupKey).add(redisVo);
				limitOrderNoInputAmountVo.setLimitInputAmount(redisVo.getLimitInputAmount());

				log.info("1-1) limit data insert: " + orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());

				limitOrderNoInputAmountVo.setLimitInputAmount(redisVo.getLimitInputAmount());
				return;
			}

			/* 4-1. Update인 경우
			 * 		- 종목별 지정가 주문 리스트에서 해당 주문번호 데이터 삭제 후, 다시 insert
			 * 		- 지정가주문번호-지정가입력금액 map update
			*/
			if(redisVo.getIntrfcSttusCode().equals(LimitDataUtil.LimitOrderSttusCode.UPDATE.value)) {
				CommLimitOrderRedisMsgVO oldVo = orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(groupKey)
						.stream()
						.filter(vo -> vo.getLimitOrderNo().equals(redisVo.getLimitOrderNo()))
						.findFirst()
						.orElse(null);

				orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(groupKey).remove(oldVo);	// 기존에 존재하는 주문번호 VO를 List에서 삭제
				orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(groupKey).add(redisVo);		// 레디스에서 받은 새로운 가격을 key로 하는 List에서 레디스에서 받은 VO 값 add
				limitOrderNoInputAmountVo.setLimitInputAmount(redisVo.getLimitInputAmount());

				log.info("1-2) limit data update: " + orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());
				return;
			}

			/*
			 * 4-2. Delete인 경우
			 * 	   - 종목별 지정가 주문 리스트와 지정가주문번호-지정가입력금액 map, 시간별 지정가 주문 리스트에서 삭제
			 */
			if(redisVo.getIntrfcSttusCode().equals(LimitDataUtil.LimitOrderSttusCode.DELETE.value)) {
				String limitOrderNoToRemove = redisVo.getLimitOrderNo(); // 삭제하려는 지정가 주문 번호
				orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(groupKey).removeIf(item -> item.getLimitOrderNo().equals(limitOrderNoToRemove));

//				orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(groupKey).remove(redisVo); // 기존에 존재하는 주문번호 VO를 List에서 삭제
				orderLimitOrderBasVoMapService.removeLimitOrderNoInputAmountVo(redisVo.getLimitOrderNo());

				log.info("1-3) limit data delete!: " + orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());
			}
		} catch(Exception e) {
			log.error("[saveLimitData Error] {}", ExceptionUtils.getStackTrace(e));
		}
	}

	/* ### 수신받은 가단가 지정가 데이터 저장 로직 ###
	 * 1. 그룹키 생성 (메탈코드)
	 * 2. 지정가주문번호-지정가입력금액 map 및 종목별 지정가 주문 리스트 세팅
	 *
	 * 3. 저장된 지정가 주문번호가 없는 경우 insert 되지 않은 상태이므로, 저장하는 로직만 타고 return
	 * 		- 프리미엄 제외 금액 계산하여 저장
	 * 4. 이미 저장된 지정가 주문번호가 있는 경우
	 * 		4-1. Update인 경우
	 * 			- 종목별 지정가 주문 리스트에서 해당 주문번호 데이터 삭제 후, 다시 insert
	 * 			- 지정가주문번호-지정가입력금액 map update
	 * 			- 프리미엄 제외 금액 계산하여 저장
	 * 		4-2. Delete인 경우
	 * 			- 종목별 지정가 주문 리스트와 지정가주문번호-지정가입력금액 map에서 삭제
	 */
	private synchronized void savePrvsnlLimitData(CommPrvsnlLimitOrderRedisMsgVO redisVo) {
		try {
			log.info("1-0) receive redisVo: " + redisVo);

			// 1. 그룹키 생성
			String groupKey = redisVo.getMetalCode();

			// 2. 지정가주문번호-지정가입력금액 map 및 종목별 지정가 주문 리스트 세팅
			CommPrvsnlLimitOrderRedisMsgVO prvsnlLimitOrderNoInputAmountVo = orderLimitOrderBasVoMapService.getPrvsnlLimitOrderNoInputAmountVo(redisVo.getLimitOrderNo());	// 지정가주문번호-지정가입력금액 map

			// 3. 저장된 지정가 주문번호가 없는 경우 - insert 되지 않은 상태이므로, 저장하는 로직만 타고 return
			if(prvsnlLimitOrderNoInputAmountVo.getLimitInputAmount() == 0 &&
					redisVo.getIntrfcSttusCode().equals(LimitDataUtil.LimitOrderSttusCode.INSERT.value)) {
				orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap(groupKey).add(redisVo);
				prvsnlLimitOrderNoInputAmountVo.setLimitInputAmount(redisVo.getLimitInputAmount());

				log.info("1-1) prvsnl limit data insert: " + orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap());

				prvsnlLimitOrderNoInputAmountVo.setLimitInputAmount(redisVo.getLimitInputAmount());
				return;
			}

			/* 4-1. Update인 경우
			 * 		- 종목별 지정가 주문 리스트에서 해당 주문번호 데이터 삭제 후, 다시 insert
			 * 		- 지정가주문번호-지정가입력금액 map update
			*/
			if(redisVo.getIntrfcSttusCode().equals(LimitDataUtil.LimitOrderSttusCode.UPDATE.value)) {
				CommPrvsnlLimitOrderRedisMsgVO oldVo = orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap(groupKey)
						.stream()
						.filter(vo -> vo.getLimitOrderNo().equals(redisVo.getLimitOrderNo()))
						.findFirst()
						.orElse(null);

				orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap(groupKey).remove(oldVo);	// 기존에 존재하는 주문번호 VO를 List에서 삭제
				orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap(groupKey).add(redisVo);	// 레디스에서 받은 새로운 가격을 key로 하는 List에서 레디스에서 받은 VO 값 add
				prvsnlLimitOrderNoInputAmountVo.setLimitInputAmount(redisVo.getLimitInputAmount());

				log.info("1-2) prvsnl limit data update: " + orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap());
				return;
			}

			/*
			 * 4-2. Delete인 경우
			 * 	   - 종목별 지정가 주문 리스트와 지정가주문번호-지정가입력금액 map, 시간별 지정가 주문 리스트에서 삭제
			 */
			if(redisVo.getIntrfcSttusCode().equals(LimitDataUtil.LimitOrderSttusCode.DELETE.value)) {
				String limitOrderNoToRemove = redisVo.getLimitOrderNo(); // 삭제하려는 지정가 주문 번호
				orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap(groupKey).removeIf(item -> item.getLimitOrderNo().equals(limitOrderNoToRemove));

//				orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap(groupKey).remove(redisVo); // 기존에 존재하는 주문번호 VO를 List에서 삭제
				orderLimitOrderBasVoMapService.removePrvsnlLimitOrderNoInputAmountVo(redisVo.getLimitOrderNo());

				log.info("1-3) prvsnl limit data delete!: " + orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap());
			}
		} catch(Exception e) {
			log.error("[savePrvsnlLimitOrder Error] {}", ExceptionUtils.getStackTrace(e));
		}
	}

}
