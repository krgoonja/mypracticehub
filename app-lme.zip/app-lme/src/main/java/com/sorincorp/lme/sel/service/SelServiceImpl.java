package com.sorincorp.lme.sel.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.lme.ReciveLmeDataByUdpSocket;
import com.sorincorp.lme.constant.PrPcStdrBasVoConstant;
import com.sorincorp.lme.pc.model.PrLmePcStdrBasVo;
import com.sorincorp.lme.sel.mapper.SelMapper;
import com.sorincorp.lme.sel.model.PrSelPcStdrBasVo;
import com.sorincorp.lme.util.RestDateTime;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SelServiceImpl implements SelService {
	
	@Autowired
	private SelMapper selMapper;
	
	@Autowired
	private RestDateTime restDateTime;
		
//	@Autowired private PrSelPcStdrBasVo selStdrAl;
//	@Autowired private PrSelPcStdrBasVo selRltmAl;
//	@Autowired private PrSelPcStdrBasVo pastSelStdrAl01Minute;
//	@Autowired private PrSelPcStdrBasVo selStdrAl01Minute;
//	@Autowired private PrSelPcStdrBasVo pastSelStdrAl30Minute;
//	@Autowired private PrSelPcStdrBasVo selStdrAl30Minute;
//	@Autowired private PrSelPcStdrBasVo pastSelStdrAl60Minute;
//	@Autowired private PrSelPcStdrBasVo selStdrAl60Minute;
//	@Autowired private PrSelPcStdrBasVo pastSelStdrAlDe;
//	@Autowired private PrSelPcStdrBasVo selStdrAlDe;
//	@Autowired private PrSelPcStdrBasVo pastSelStdrAlWeek;
//	@Autowired private PrSelPcStdrBasVo selStdrAlWeek;
//	@Autowired private PrSelPcStdrBasVo pastSelStdrAlMt;
//	@Autowired private PrSelPcStdrBasVo selStdrAlMt;
//	@Autowired private PrSelPcStdrBasVo pastSelStdrAlQu;
//	@Autowired private PrSelPcStdrBasVo selStdrAlQu;
//	@Autowired private PrSelPcStdrBasVo pastSelStdrAlYy;
//	@Autowired private PrSelPcStdrBasVo selStdrAlYy;
	
//	@Value("${metalCode.Al}")
//	private String metalCodeAl;
	
	@Autowired
	private RedisPubSubService redisPubSubService;
	
	@Value("${metalCode.list}") private List<String> metalCodeList;
	
	@Value("${metalCode.Zn}") private String metalCodeZn;
	@Value("${metalCode.Pb}") private String metalCodePb;
	@Value("${metalCode.Cu}") private String metalCodeCu;
	@Value("${metalCode.Al}") private String metalCodeAl;
	@Value("${metalCode.Ni}") private String metalCodeNi;
	@Value("${metalCode.Sn}") private String metalCodeSn;
	
	@Value("${gicName.Zn}") private String gicNameZn;
	@Value("${gicName.Pb}") private String gicNamePb;
	@Value("${gicName.Cu}") private String gicNameCu;
	@Value("${gicName.Al}") private String gicNameAl;
	@Value("${gicName.Ni}") private String gicNameNi;
	@Value("${gicName.Sn}") private String gicNameSn;
	
	private final PrSelPcStdrBasVoMapService prSelPcStdrBasVoMapService;
	
	@Autowired
	public SelServiceImpl(PrSelPcStdrBasVoMapService prSelPcStdrBasVoMapService) {
		this.prSelPcStdrBasVoMapService = prSelPcStdrBasVoMapService;
	}
	
	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrSelPcStdrBas(PrSelPcStdrBasVo vo) throws Exception {
		if(restDateTime.isRealRltmSellTime() && !ReciveLmeDataByUdpSocket.errorSpreadMetalCodeList.contains(vo.getMetalCode())) {
			selMapper.insertPrSelPcStdrBas(vo);
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrSelPcRltmBas(PrSelPcStdrBasVo vo) throws Exception {
		if(restDateTime.isRealRltmSellTime() && !ReciveLmeDataByUdpSocket.errorSpreadMetalCodeList.contains(vo.getMetalCode())) {
			selMapper.insertPrSelPcRltmBas(vo);
		}
	}
	
	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrSelPc01MinBas(PrSelPcStdrBasVo vo) throws Exception {
		if(restDateTime.isSorinWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			log.info("selService insertPrSelPc01MinBas Before , metalCode: " + vo.getMetalCode() + " , slePc01MinSn: " + vo.getSlePc01MinSn());
			selMapper.insertPrSelPc01MinBas(vo);
			
			log.info("selService insertPrSelPc01MinBas After , metalCode: " + vo.getMetalCode() + " , slePc01MinSn: " + vo.getSlePc01MinSn());
			
			List<PrSelPcStdrBasVo> resultSel01Minutes = selMapper.selectPrSelPc01MinBas(vo);
			redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + vo.getMetalCode() + "/01", ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + vo.getMetalCode() + "/01", resultSel01Minutes);
			
			//log.info("pub message 01 metalCode: " + vo.getMetalCode() + " , resultSel01Minutes: " + resultSel01Minutes);
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrSelPc30MinBas(PrSelPcStdrBasVo vo) throws Exception {
		log.info("sel pc 30 INSERT [metalCode]: " + vo.getMetalCode());
		if(restDateTime.isSorinWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			selMapper.insertPrSelPc30MinBas(vo);	
			
			//log.info("!!!!!!!!!! half hours SEL insert schedule !!!!!!!!!!");
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrSelPc60MinBas(PrSelPcStdrBasVo vo) throws Exception {
		if(restDateTime.isSorinWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			selMapper.insertPrSelPc60MinBas(vo);
			
			//log.info("!!!!!!!!!! 1 hours SEL insert schedule !!!!!!!!!!");
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrSelPcDeBas(PrSelPcStdrBasVo vo) throws Exception {
		if(restDateTime.isSorinWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			selMapper.insertPrSelPcDeBas(vo);
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrSelPcWeekBas(PrSelPcStdrBasVo vo) throws Exception {
		if(restDateTime.isSorinWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			selMapper.insertPrSelPcWeekBas(vo);
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrSelPcYyMtBas(PrSelPcStdrBasVo vo) throws Exception {
		if(restDateTime.isSorinWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			selMapper.insertPrSelPcYyMtBas(vo);
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrSelPcYyQuBas(PrSelPcStdrBasVo vo) throws Exception {
		if(restDateTime.isSorinWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			selMapper.insertPrSelPcYyQuBas(vo);
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrSelPcYyBas(PrSelPcStdrBasVo vo) throws Exception {
		if(restDateTime.isSorinWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			selMapper.insertPrSelPcYyBas(vo);
		}
	}
	
	@Override
	public void selectTopPrSelPcStdrBas() throws Exception {
		PrSelPcStdrBasVo vo = new PrSelPcStdrBasVo();
		
		for(String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);
			
			PrSelPcStdrBasVo returnVo = selMapper.selectTopPrSelPcStdrBas(vo);
			if(returnVo != null) {
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.STDR));		
			}
		}
	}

	@Override
	public void selectTopPrSelPcRltmBas() throws Exception {
		PrSelPcStdrBasVo vo = new PrSelPcStdrBasVo();
		
		for(String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);
			
			PrSelPcStdrBasVo returnVo = selMapper.selectTopPrSelPcRltmBas(vo);
			if(returnVo != null) {
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.RLTM));		
			}
		}
	}

	@Override
	public void selectTopPrSelPc01MinBas() throws Exception {
		PrSelPcStdrBasVo vo = new PrSelPcStdrBasVo();
		
		for(String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);
			
			PrSelPcStdrBasVo returnVo = selMapper.selectTopPrSelPc01MinBas(vo);
			if(returnVo != null) {
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.ONE_MINUTE));
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE));
			}
		}
	}

	@Override
	public void selectTopPrSelPc30MinBas() throws Exception {
		PrSelPcStdrBasVo vo = new PrSelPcStdrBasVo();
		
		for(String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);
			
			PrSelPcStdrBasVo returnVo = selMapper.selectTopPrSelPc30MinBas(vo);
			if(returnVo != null) {
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.THIRTY_MINUTE));
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE));
			}
		}
	}

	@Override
	public void selectTopPrSelPc60MinBas() throws Exception {
		PrSelPcStdrBasVo vo = new PrSelPcStdrBasVo();
		
		for(String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);
			
			PrSelPcStdrBasVo returnVo = selMapper.selectTopPrSelPc60MinBas(vo);
			if(returnVo != null) {
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.SIXTY_MINUTE));
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE));
			}
		}
	}

	@Override
	public void selectTopPrSelPcDeBas() throws Exception {
		PrSelPcStdrBasVo vo = new PrSelPcStdrBasVo();
		
		for(String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);
			
			PrSelPcStdrBasVo returnVo = selMapper.selectTopPrSelPcDeBas(vo);
			if(returnVo != null) {
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.DAY));
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_DAY));
			}
		}
	}

	@Override
	public void selectTopPrSelPcWeekBas() throws Exception {
		PrSelPcStdrBasVo vo = new PrSelPcStdrBasVo();
		
		for(String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);
			
			PrSelPcStdrBasVo returnVo = selMapper.selectTopPrSelPcWeekBas(vo);
			if(returnVo != null) {
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.WEEK));
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_WEEK));
			}
		}
	}

	@Override
	public void selectTopPrSelPcYyMtBas() throws Exception {
		PrSelPcStdrBasVo vo = new PrSelPcStdrBasVo();
		
		for(String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);
			
			PrSelPcStdrBasVo returnVo = selMapper.selectTopPrSelPcYyMtBas(vo);
			if(returnVo != null) {
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.MONTH));
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_MONTH));
			}
		}
	}

	@Override
	public void selectTopPrSelPcYyQuBas() throws Exception {
		PrSelPcStdrBasVo vo = new PrSelPcStdrBasVo();
		
		for(String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);
			
			PrSelPcStdrBasVo returnVo = selMapper.selectTopPrSelPcYyQuBas(vo);
			if(returnVo != null) {
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.QUARTER));
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_QUARTER));
			}
		}
	}

	@Override
	public void selectTopPrSelPcYyBas() throws Exception {
		PrSelPcStdrBasVo vo = new PrSelPcStdrBasVo();
		
		for(String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);
			
			PrSelPcStdrBasVo returnVo = selMapper.selectTopPrSelPcYyBas(vo);
			if(returnVo != null) {
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.YEAR));
				BeanUtils.copyProperties(returnVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_YEAR));
			}
		}
	}
	
	@Override
	public void initializePrSelPcStdrBasVo(PrLmePcStdrBasVo returnNowLmeStdrBasVoFromIf) {
		
		PrSelPcStdrBasVo vo = new PrSelPcStdrBasVo();
		BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, vo);
		vo.setItmSn(0);
		vo.setDstrctLclsfCode("00");
		vo.setBrandGroupCode("00");
		vo.setBrandCode("0000000000");
		
		for(String metalCode : metalCodeList) {
			PrSelPcStdrBasVo oneMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.ONE_MINUTE);
			PrSelPcStdrBasVo pastOneMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE);
			PrSelPcStdrBasVo thirtyMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.THIRTY_MINUTE);
			PrSelPcStdrBasVo pastThirtyMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE);
			PrSelPcStdrBasVo sixtyMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.SIXTY_MINUTE);
			PrSelPcStdrBasVo pastSixtyMinute = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE);
			PrSelPcStdrBasVo day = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.DAY);
			PrSelPcStdrBasVo pastDay = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_DAY);
			PrSelPcStdrBasVo week = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.WEEK);
			PrSelPcStdrBasVo pastWeek = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_WEEK);
			PrSelPcStdrBasVo month = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.MONTH);
			PrSelPcStdrBasVo pastMonth = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_MONTH);
			PrSelPcStdrBasVo quarter = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.QUARTER);
			PrSelPcStdrBasVo pastQuarter = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_QUARTER);
			PrSelPcStdrBasVo year = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.YEAR);
			PrSelPcStdrBasVo pastYear = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_YEAR);
			
			if(oneMinute == null || oneMinute.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, oneMinute);
			}
			
			if(pastOneMinute == null || pastOneMinute.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, pastOneMinute);
			}
			
			if(thirtyMinute == null || thirtyMinute.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, thirtyMinute);
			}
			
			if(pastThirtyMinute == null || pastThirtyMinute.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, pastThirtyMinute);
			}
			
			if(sixtyMinute == null || sixtyMinute.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, sixtyMinute);
			}
			
			if(pastSixtyMinute == null || pastSixtyMinute.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, pastSixtyMinute);
			}
	
			if(day == null || day.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, day);
			}
			
			if(pastDay == null || pastDay.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, pastDay);
			}
			
			if(week == null || week.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, week);
			}
			
			if(pastWeek == null || pastWeek.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, pastWeek);
			}
			
			if(month == null || month.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, month);
			}
			
			if(pastMonth == null || pastMonth.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, pastMonth);
			}
			
			if(quarter == null || quarter.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, quarter);
			}
			
			if(pastQuarter == null || pastQuarter.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, pastQuarter);
			}
			
			if(year == null || year.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, year);
			}
			
			if(pastYear == null || pastYear.getEndPc() == 0) {
				BeanUtils.copyProperties(vo, pastYear);
			}
		}
	}

	@Override
	public void insertPrSelPcDeBasForProcedure(Map<String, String> map) throws Exception{
		log.info("sel pc day INSERT [metalCode]: " + map.get("metalCode"));
		if(ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			selMapper.insertPrSelPcDeBasForProcedure(map);
			
			log.info("!!!!!!!!!! day SEL insert schedule !!!!!!!!!!");
		}
	}

	@Override
	public void insertPrSelPcWeekBasForProcedure(Map<String, String> map) throws Exception{
		if(ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			selMapper.insertPrSelPcWeekBasForProcedure(map);
			
			//log.info("!!!!!!!!!! week SEL insert schedule !!!!!!!!!!");
		}
	}

	@Override
	public void insertPrSelPcYyMtBasForProcedure(Map<String, String> map) throws Exception{
		if(ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			selMapper.insertPrSelPcYyMtBasForProcedure(map);
			
			//log.info("!!!!!!!!!! month SEL insert schedule !!!!!!!!!!");
		}
	}

	@Override
	public void insertPrSelPcYyQuBasForProcedure(Map<String, String> map) throws Exception{
		if(ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			selMapper.insertPrSelPcYyQuBasForProcedure(map);
			
			//log.info("!!!!!!!!!! quarter SEL insert schedule !!!!!!!!!!");
		}
	}

	@Override
	public void insertPrSelPcYyBasForProcedure(Map<String, String> map) throws Exception{
		if(ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			selMapper.insertPrSelPcYyBasForProcedure(map);
			
			//log.info("!!!!!!!!!! year SEL insert schedule !!!!!!!!!!");
		}
	}

	@Override
	public void insertPrSelPc01MinBasForProcedure(Map<String, String> map) throws Exception {
		log.info("sel pc 01 min INSERT [metalCode]: " + map.get("metalCode"));
		if(ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			selMapper.insertPrSelPc01MinBasForProcedure(map);
			
			log.info("!!!!!!!!!! 01 min SEL insert schedule !!!!!!!!!!");
		}
	}
	
	
	@Override
	public List<String> selectMetalCodeList() throws Exception {
		return selMapper.selectMetalCodeList(); 
	}
}