package com.sorincorp.lme.etc.model;

import java.math.BigDecimal;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CalculateSpreadVo.java
 * @version
 * @since 2022. 3. 15.
 * @author srec0026
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class CalculateSpreadVo extends CommonVO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3252896728297036730L;
	/**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 일시
    */
    private String dateTime;
    /**
     * 종목코드
    */
    private String gicName;
    
    /**
     * Le spread 계산값
    */
    private BigDecimal leSpread;
    /**
     * Lc spread 계산값
    */
    private BigDecimal lcSpread;

}