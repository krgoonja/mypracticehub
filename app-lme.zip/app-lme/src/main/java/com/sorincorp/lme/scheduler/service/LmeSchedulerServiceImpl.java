package com.sorincorp.lme.scheduler.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import javax.annotation.Resource;

import com.sorincorp.comm.pcInfo.mapper.PcInfoMapper;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.limit.service.LimitService;
import com.sorincorp.comm.limit.service.OrLimitOrderBasVoMapService;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.model.CommLimitOrderRedisMsgVO;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.PrPremiumSelVO;
import com.sorincorp.comm.pcInfo.model.PreminumSelInfoVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.premium.service.ItPremiumStdrBasVoService;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.dynmDiver.comm.DynmDiverSetup;
import com.sorincorp.comm.it.service.ItBsnManageBasVoService;
import com.sorincorp.comm.it.service.ItFtrsFshgManageDtlVoService;
import com.sorincorp.comm.it.service.ItService;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.lme.ReciveLmeDataByUdpSocket;
import com.sorincorp.lme.constant.PrPcStdrBasVoConstant;
import com.sorincorp.lme.ehgt.service.PrEhgtPcStdrBasVoService;
import com.sorincorp.lme.pc.model.OpFallSelPcBasVo;
import com.sorincorp.lme.pc.model.PrLmePcStdrBasVo;
import com.sorincorp.lme.pc.service.PcService;
import com.sorincorp.lme.pc.service.PrLmePcStdrBasVoMapService;
import com.sorincorp.lme.pc.service.PrPremiumSelVOService;
import com.sorincorp.lme.sel.model.PrSelPcStdrBasVo;
import com.sorincorp.lme.sel.service.PrSelPcStdrBasVoMapService;
import com.sorincorp.lme.sel.service.SelService;
import com.sorincorp.lme.util.FallSelPc;
import com.sorincorp.lme.util.LmeDataUtil;
import com.sorincorp.lme.util.RestDateTime;
import com.sorincorp.lme.util.RestDateTime.EhgtStatus;
import com.sorincorp.lme.util.RestDateTime.LmeStatus;
import com.sorincorp.lme.util.SerialUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@EnableScheduling
@ComponentScan({"com.sorincorp.comm.cntcsttus.*"})
public class LmeSchedulerServiceImpl implements LmeSchedulerService{

	//@Autowired private EhgtBeanFactoryConfig ehgtBeanFactoryConfig;

	/** 가격하락문자 발송 스레드 풀 */
	@Resource(name = "lmeThreadPoolExcuter")
	private ThreadPoolTaskExecutor taskExecutor;

	@Autowired
	private PcService pcService;

	@Autowired
	private SelService selService;

	@Autowired
	private RedisPubSubService redisPubSubService;

	@Autowired
	private RestDateTime restDateTime;

	@Autowired
	private CommonService commonService;

	@Autowired
	private ItService itService;

	@Autowired
	private SMSService smsService;

	@Autowired
	private FallSelPc fallSelPc;

	@Autowired
	private ItPremiumStdrBasVoService itPremiumStdrBasVoService;

	@Autowired
	private PcInfoService pcInfoService;

	@Autowired
	private PrPremiumSelVOService prPremiumSelVOService;

	@Autowired
	private LimitService limitService;

	@Autowired
	PcInfoMapper pcInfoMapper;

	@Autowired
	private RedisUtil redisUtil;

	@Autowired
	private DynmDiverSetup dynmDiverSetup;

	public final static String PREMIUM_INFO_LIST = "premiumInfoList";

	private final PrEhgtPcStdrBasVoService prEhgtPcStdrBasVoService;

	private final ItBsnManageBasVoService itBsnManageBasVoService;
	private final ItFtrsFshgManageDtlVoService itFtrsFshgManageDtlVoService;

	private final OrLimitOrderBasVoMapService orderLimitOrderBasVoMapService;



	@Value("${metalCode.list}") private List<String> metalCodeList;
	@Value("${gicName.list}") private List<String> gicNameList;

	@Value("${metalCode.Zn}") private String metalCodeZn;
	@Value("${metalCode.Pb}") private String metalCodePb;
	@Value("${metalCode.Cu}") private String metalCodeCu;
	@Value("${metalCode.Al}") private String metalCodeAl;
	@Value("${metalCode.Ni}") private String metalCodeNi;
	@Value("${metalCode.Sn}") private String metalCodeSn;

	@Value("${gicName.Zn}") private String gicNameZn;
	@Value("${gicName.Pb}") private String gicNamePb;
	@Value("${gicName.Cu}") private String gicNameCu;
	@Value("${gicName.Al}") private String gicNameAl;
	@Value("${gicName.Ni}") private String gicNameNi;
	@Value("${gicName.Sn}") private String gicNameSn;

	private final PrLmePcStdrBasVoMapService prLmePcStdrBasVoMapService;
	private final PrSelPcStdrBasVoMapService prSelPcStdrBasVoMapService;

	@Autowired
	public LmeSchedulerServiceImpl(PrLmePcStdrBasVoMapService prLmePcStdrBasVoMapService
			, PrSelPcStdrBasVoMapService prSelPcStdrBasVoMapService
			, ItBsnManageBasVoService itBsnManageBasVoService
			, ItFtrsFshgManageDtlVoService itFtrsFshgManageDtlVoService
			, PrEhgtPcStdrBasVoService prEhgtPcStdrBasVoService
			, OrLimitOrderBasVoMapService orderLimitOrderBasVoMapService) {
		this.prEhgtPcStdrBasVoService = prEhgtPcStdrBasVoService;
		this.itFtrsFshgManageDtlVoService = itFtrsFshgManageDtlVoService;
		this.prLmePcStdrBasVoMapService = prLmePcStdrBasVoMapService;
		this.prSelPcStdrBasVoMapService = prSelPcStdrBasVoMapService;
		this.itBsnManageBasVoService = itBsnManageBasVoService;
		this.orderLimitOrderBasVoMapService = orderLimitOrderBasVoMapService;
	}

	@Override
	@Scheduled(cron = "0 0 7 * * *", zone = "Asia/Seoul")
	@Async("lmeThreadPoolExcuter")
	public void initialSchedule() throws Exception {
		restDateTime.initialize();
		fallSelPc.initialize();
		ReciveLmeDataByUdpSocket.receiveMetalCodeList.clear();		// [pje] 메탈 코드 리스트를 초기화한다.
		log.info("==========================receiveMetalCodeList clear==========================");

		log.info("==before errorSpreadMetalCodeList : " + ReciveLmeDataByUdpSocket.errorSpreadMetalCodeList);
		ReciveLmeDataByUdpSocket.errorSpreadMetalCodeList.clear();
		log.info("==after errorSpreadMetalCodeList : " + ReciveLmeDataByUdpSocket.errorSpreadMetalCodeList);

		log.info("==before leSpreadMap : " + ReciveLmeDataByUdpSocket.leSpreadMap);
		ReciveLmeDataByUdpSocket.leSpreadMap.clear();
		ReciveLmeDataByUdpSocket.niLcSpread = new java.math.BigDecimal(0);
		log.info("==after leSpreadMap : " + ReciveLmeDataByUdpSocket.leSpreadMap);

		log.info("==before Ehgt Status: " + restDateTime.getEhgtStatusCode());
		//BeanUtils.copyProperties(null, prEhgtPcStdrBasVoService.getPrEhgtPcStdrBasVo());
		prSelPcStdrBasVoMapService.clearPrSelPcStdrBasVo();
		prEhgtPcStdrBasVoService.clearPrEhgtPcStdrBasVo();
		restDateTime.setEhgtStatusCode(EhgtStatus.FAIL);	// [pje]추가
		log.info("==after Ehgt Status: " + restDateTime.getEhgtStatusCode());

		// 프리미엄 가격 초기값 세팅
		Map<String, TreeSet<LivePremiumVO>> originalMap = pcInfoService.getPremiumInfoMap();
		itPremiumStdrBasVoService.setItPremiumStdrBasVo(originalMap);

		// 이전 니켈 초기값 세팅
		Map<String, String> map = new HashMap<>();
		map.put("metalCode", metalCodeNi);
		PrLmePcStdrBasVo originalVo = pcService.selectPastLmePc(map);
		BeanUtils.copyProperties(originalVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(PrPcStdrBasVoConstant.PAST_NICKEL));

		log.info("past nickel init: " + prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(PrPcStdrBasVoConstant.PAST_NICKEL));
	}

	@Override
	//@Scheduled(cron = "0 * * * * *", zone = "Asia/Seoul")
	@Async("lmeThreadPoolExcuter")
	public void selectLmeStatusSchedule() throws Exception {

//		CntcSttusVO cntcSttusVO = new CntcSttusVO();
//		cntcSttusVO.setLastChangerId("LMESYSTEM");
//		cntcSttusVO.setIntrfcSeCode("10");
//		cntcSttusVO.setCntcSttusCode("0");
//		cntcSttusService.updateCoCntcSttusBas(cntcSttusVO);
	}

	@Override
	@Scheduled(cron = "59 0/1 0-19 * * 1-5", zone = "Europe/London")
	@Async("lmeThreadPoolExcuter")
	public void oneMinutesInsertSchedule() {
		try {
			oneMinutesProcess(false);
		} catch(Exception e) {
			log.error(e.toString() + " -> message : " + e.getMessage());
		}
	}

	@Override
	@Scheduled(cron = "0 0/1 0-20 * * 1-5", zone = "Europe/London")
	@Async("lmeThreadPoolExcuter")
	public void oneMinutesSchedule() {
		try {
			oneMinutesProcess(true);
		} catch(Exception e) {
			log.error(e.toString() + " -> message : " + e.getMessage());
		}
	}

	@Override
	@Scheduled(cron = "59 29,59 0-19 * * 1-5", zone = "Europe/London")
	@Async("lmeThreadPoolExcuter")
	public void halfHoursInsertSchedule()  {
		try {
			halfHoursProcess(false);
		} catch(Exception e) {
			log.error(e.toString() + " -> message : " + e.getMessage());
		}
	}

	@Override
	@Scheduled(cron = "0 0/30 0-20 * * 1-5", zone = "Europe/London")
	@Async("lmeThreadPoolExcuter")
	public void halfHoursSchedule()  {
		try {
			halfHoursProcess(true);
		} catch(Exception e) {
			log.error(e.toString() + " -> message : " + e.getMessage());
		}
	}

	@Override
	@Scheduled(cron = "59 59 0-19 * * 1-5", zone = "Europe/London")
	@Async("lmeThreadPoolExcuter")
	public void oneHoursInsertSchedule() {
		try {
			oneHoursProcess(false);
		} catch(Exception e) {
			log.error(e.toString() + " -> message : " + e.getMessage());
		}
	}

	@Override
	@Scheduled(cron = "0 0 0-20 * * 1-5", zone = "Europe/London")
	@Async("lmeThreadPoolExcuter")
	public void oneHoursSchedule() {
		try {
			oneHoursProcess(true);
		} catch(Exception e) {
			log.error(e.toString() + " -> message : " + e.getMessage());
		}
	}

	@Override
	@Scheduled(cron = "59 59 19 * * *", zone = "Europe/London")
	@Async("lmeThreadPoolExcuter")
	public void overDayInsertScheduleLme() {
		try {
			dayProcessLmeForProcedure(false);
			weekProcessLmeForProcedure(false);
			monthProcessLmeForProcedure(false);
			quarterProcessLmeForProcedure(false);
			yearProcessLmeForProcedure(false);
		} catch(Exception e) {
			log.error(e.toString() + " -> message : " + e.getMessage());
		}
	}

	@Override
	@Scheduled(cron = "0 0 20 * * *", zone = "Europe/London")
	@Async("lmeThreadPoolExcuter")
	public void overDayScheduleLme() {
		try {
			dayProcessLmeForProcedure(true);
			weekProcessLmeForProcedure(true);
			monthProcessLmeForProcedure(true);
			quarterProcessLmeForProcedure(true);
			yearProcessLmeForProcedure(true);
		} catch(Exception e) {
			log.error(e.toString() + " -> message : " + e.getMessage());
		} finally {
			ReciveLmeDataByUdpSocket.isReadyToLmeSchedule = false;
			ReciveLmeDataByUdpSocket.isReadyToSelSchedule = false;
		}
	}

//	@Override
//	@Scheduled(cron = "59 59 */1 * * *", zone = "Asia/Seoul")
//	@Async("lmeThreadPoolExcuter")
//	public void overDayInsertScheduleSel() {
//		try {
//			dayProcessSelForProcedure(false);
//			weekProcessSelForProcedure(false);
//			monthProcessSelForProcedure(false);
//			quarterProcessSelForProcedure(false);
//			yearProcessSelForProcedure(false);
//		} catch(Exception e) {
//			log.error(e.toString() + " -> message : " + e.getMessage());
//		}
//	}

	@Override
	@Scheduled(cron = "0 40 23 * * *", zone = "Asia/Seoul")
	@Async("lmeThreadPoolExcuter")
	public void overDayScheduleSel() {
		try {
			List<PreminumSelInfoVO> premiumList = pcInfoService.getPremiumInfoListByRedisData();
			List<String> MetalCodeList = new ArrayList<>();
			for(PreminumSelInfoVO premiumVO : premiumList) {
				if (!MetalCodeList.contains(premiumVO.getMetalCode())) {
					MetalCodeList.add(premiumVO.getMetalCode());
				}
			}
			dayProcessSel(MetalCodeList);
			weekProcessSel(MetalCodeList);
			monthProcessSel(MetalCodeList);
			quarterProcessSel(MetalCodeList);
			yearProcessSel(MetalCodeList);
//			dayProcessSelForProcedure(true);
//			weekProcessSelForProcedure(true);
//			monthProcessSelForProcedure(true);
//			quarterProcessSelForProcedure(true);
//			yearProcessSelForProcedure(true);
		} catch(Exception e) {
			log.error(e.toString() + " -> message : " + e.getMessage());
		}
	}

	@Override
	@Scheduled(cron = "0 0,1 0 * * *", zone = "Asia/Seoul")
	@Async("lmeThreadPoolExcuter")
	public void chartTitleSchedule() {
		try {
			// 차트타이틀 세팅
			for(String metalCode : metalCodeList) {
				List<PrPremiumSelVO> prPremiumSelVOList = pcInfoService.getChartTitleInfoList(metalCode);
				prPremiumSelVOService.getPrPremiumSelVOMap().remove(metalCode);
				prPremiumSelVOService.getPrPremiumSelVOMap(metalCode).addAll(prPremiumSelVOList);

				redisUtil.setDataJson(LmeDataUtil.SEL_PC_ALL_LIST + metalCode, prPremiumSelVOService.getPrPremiumSelVOMap(metalCode));
			}

			// 지정가 초기값 세팅
			orderLimitOrderBasVoMapService.setOrderCommLimitOrderRedisMsgVoMap(limitService.loadInitialLimitData());
			log.info("0-0) initial Order Limit Data: " + orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());
			log.info("0-1) before getLimitOrderNoInputAmountVo: " + orderLimitOrderBasVoMapService.getLimitOrderNoInputAmountVo());

			orderLimitOrderBasVoMapService.getLimitOrderNoInputAmountVo().clear();

			// TODO: 가단가 지정가 초기값 세팅??

			Map<String, TreeSet<CommLimitOrderRedisMsgVO>> orderCommLimitOrderRedisMsgVoMap = orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap();
			if (orderCommLimitOrderRedisMsgVoMap != null) {
				for (Map.Entry<String, TreeSet<CommLimitOrderRedisMsgVO>> entry : orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap().entrySet()) {
					String limitOrderNo = entry.getKey();
					TreeSet<CommLimitOrderRedisMsgVO> commLimitOrderRedisMsgVOSet = entry.getValue();

					if (!commLimitOrderRedisMsgVOSet.isEmpty()) {
						CommLimitOrderRedisMsgVO commLimitOrderRedisMsgVO = commLimitOrderRedisMsgVOSet.first();
						long limitInputAmount = commLimitOrderRedisMsgVO.getLimitInputAmount();

						CommLimitOrderRedisMsgVO limitOrderNoInputAmountVo = orderLimitOrderBasVoMapService.getLimitOrderNoInputAmountVo(limitOrderNo);
						limitOrderNoInputAmountVo.setLimitInputAmount(limitInputAmount);
					}
				}
			}

			log.info("0-2) after getLimitOrderNoInputAmountVo: " + orderLimitOrderBasVoMapService.getLimitOrderNoInputAmountVo());
		} catch(Exception e) {
			log.error(e.toString() + " -> message : " + e.getMessage());
		}
	}

	@Override
	@Scheduled(cron = "0 */1 * * * *", zone = "Asia/Seoul")
	@Async("lmeThreadPoolExcuter")
	public void checkSorinRealSellBeginTimeSchedule() {
		try {
			if(restDateTime.isSorinRealSellBeginTime()) {
				for(String metalCode : metalCodeList) {
					restDateTime.setReadytoLmeStartData(metalCode, true);
					restDateTime.setChecktoSelStartData(metalCode, true);
					restDateTime.setPubMessageStartLmeData(metalCode, true);
				}

				itPremiumStdrBasVoService.getItPremiumStdrBasVo().keySet().stream().forEach(key -> {
					restDateTime.setReadytoGroupStartData(key, true);
				});

				initializeCffcntAmount();
				//checkMatchedLmeSpreadAndCantCheckGicNamesReturn(gicNameList);
			}

			if(restDateTime.isSorinRealSellBeginAfterOneMinuteTime()) {
				//checkMatchedLmeSpreadAndCantCheckGicNamesReturn(gicNameList);
			}
		} catch(Exception e) {
			log.error(e.toString() + " -> message : " + e.getMessage());
		}
	}

	@Override
	@Scheduled(cron = "*/5 * * * * *", zone = "Asia/Seoul")
	@Async("lmeThreadPoolExcuter")
	public void checkLmeSendDataInOneMinuteSchedule() {
		checkLmeSendDataInOneMinute();
	}

	@Override
	@Scheduled(cron = "0 10 23 * * SUN", zone = "Asia/Seoul")
	@Async("lmeThreadPoolExcuter")
	public void weeklyDataDeleteSchedule() {
		try {
			pcService.deletePrLmeSelOldDataProcedure();
		} catch(Exception e) {
			log.error(e.toString() + " -> message : " + e.getMessage());
		}
	}

	@SuppressWarnings("unused")
	@Override
	public void oneMinutesProcess(boolean isResetProcess) throws Exception {
		log.info("LmeSchedulerServiceImpl oneMinutesProcess  -------------------- start");

		String serialNum = SerialUtils.getSerial();

		boolean isLmePrintLog = false;
		boolean isSelPrintLog = false;

		for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
			PrLmePcStdrBasVo returnLmeStdrBasVo = new PrLmePcStdrBasVo();
			PrSelPcStdrBasVo returnSelStdrBasVo = new PrSelPcStdrBasVo();

			BeanUtils.copyProperties(prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.ONE_MINUTE), returnLmeStdrBasVo);

			BeanUtils.copyProperties(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.ONE_MINUTE), returnSelStdrBasVo);
			// TODO [pje] 23.06.09 주석처리
//			returnSelStdrBasVo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
//			returnSelStdrBasVo.setOccrrncTime(DateUtil.getNowDateTime("HHmm") + "00");
//			returnSelStdrBasVo.setSlePc01MinSn(returnSelStdrBasVo.getSlePc01MinSn().substring(0, 8) + DateUtil.getNowDateTime("HHmm") + "00" + serialNum);

			if(isResetProcess) {
				if(restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule && prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE) != null ) {
					/*String occrrncTimeStr = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE).getOccrrncTime();
					int occrrncHour = Integer.parseInt(occrrncTimeStr.substring(0, 2));
					int occrrncMinute = Integer.parseInt(occrrncTimeStr.substring(2, 4));
					LocalTime occrrncTime = LocalTime.of(occrrncHour, occrrncMinute);

					String nowTime = DateUtil.getNowDateTime("HHmm") + "00"; // 현재 시간

					// 현재 시간에서 1분을 뺀 값을 계산하여 시간과 분 정보로 추출하여 LocalTime 형식으로 만듦
					int nowHour = Integer.parseInt(nowTime.substring(0, 2));
					int nowMinute = Integer.parseInt(nowTime.substring(2, 4));
					LocalTime currentTimeMinusOneMinute = LocalTime.of(nowHour, nowMinute).minusMinutes(1);

					log.info("nowTime: " + nowTime);
					log.info("PastOneMinute: " + occrrncTime);
					log.info("currentTimeMinusOneMinute: " + currentTimeMinusOneMinute);

					// 두 시간 비교
					if (!occrrncTime.equals(currentTimeMinusOneMinute)) {
						log.info("The time is not right.");
						return;
					}*/

					if(prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE).getEndPc().equals(BigDecimal.ZERO)) {
						log.info("The one minute data is zero.");
					} else {
					pcService.insertPrLmePc01MinBas(prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE));

					returnLmeStdrBasVo.setOccrrncDe(returnLmeStdrBasVo.getOccrrncDe());
					returnLmeStdrBasVo.setOccrrncTime(DateUtil.getNowDateTime("HHmm") + "00");
					returnLmeStdrBasVo.setLmePc01MinSn(returnLmeStdrBasVo.getLmePc01MinSn().substring(0, 8) + DateUtil.getNowDateTime("HHmm") + "00" + serialNum);

					PrLmePcStdrBasVo setVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.ONE_MINUTE);
					PrLmePcStdrBasVo getVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE);

					setVo.setDelngQy(0);

					if (!isLmePrintLog) {
						log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " 1 minutes LME schedule !!!!!!!!!!");
						isLmePrintLog = true;
					}
				}
				}

				if (restDateTime.isSorinWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule && prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE) != null
						&& restDateTime.getEhgtStatusCode() == EhgtStatus.SUCCESS.value) {

					log.info("SchedulerService insertPrSelPc01MinBas Before , metalCode: " + returnSelStdrBasVo.getMetalCode() + " , slePc01MinSn: " + returnSelStdrBasVo.getSlePc01MinSn());

					if(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE).getSlePc01MinSn() == null ||
							prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE).getEndPc() == 0) {
						log.info("01min data is zero.");
					} else {
						selService.insertPrSelPc01MinBas(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE));

						log.info("SchedulerService insertPrSelPc01MinBas After , metalCode: " + returnSelStdrBasVo.getMetalCode() + " , slePc01MinSn: " + returnSelStdrBasVo.getSlePc01MinSn());

						returnSelStdrBasVo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
						returnSelStdrBasVo.setOccrrncTime(DateUtil.getNowDateTime("HHmm") + "00");
						returnSelStdrBasVo.setSlePc01MinSn(returnSelStdrBasVo.getSlePc01MinSn().substring(0, 8) + DateUtil.getNowDateTime("HHmm") + "00" + serialNum);

						PrSelPcStdrBasVo setVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.ONE_MINUTE);
						PrSelPcStdrBasVo getVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE);

						setVo.setDelngQy(0);

						returnSelStdrBasVo.setDelngQy(0);

						if(metalCode.equals("7")) {
							log.info("Scheduler WebSocket returnSel01Minutes setVo beginPc: " + setVo.getBeginPc() + ", endPc: " + setVo.getEndPc() + ", topPc: " + setVo.getTopPc() + ", lwetPc: "+ setVo.getLwetPc());
						}

						if(!isSelPrintLog) {
							log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " 1 minutes SEL schedule !!!!!!!!!!");
							isSelPrintLog= true;
						}
					}
				}

			} else {
				if(restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
					BeanUtils.copyProperties(returnLmeStdrBasVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE));
				}

				if(restDateTime.isSorinWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule && prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.ONE_MINUTE) != null) {
					// TODO [pje] 23.06.09 주석처리
//					selService.insertPrSelPc01MinBas(returnSelStdrBasVo);
					BeanUtils.copyProperties(returnSelStdrBasVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE));

					if(metalCode.equals("7"))
						log.info( "SCHEDULER PAST_ONE_MINUTE END_PC: " + Long.toString( prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE).getEndPc()) );
				}
			}
		}
		log.info("[LmeSchedulerServiceImpl][oneMinutesProcess] ---------------------- finish ");
	}

	@Override
	public void halfHoursProcess(boolean isResetProcess) throws Exception {

		String minutes = "";
		String currentMintes = DateUtil.getNowDateTime("mm");
		if(currentMintes.equals("26") || currentMintes.equals("27") || currentMintes.equals("28") || currentMintes.equals("29") ||
				currentMintes.equals("31") || currentMintes.equals("32") || currentMintes.equals("33") || currentMintes.equals("34")) {
			minutes = "00";
		} else if(currentMintes.equals("56") || currentMintes.equals("57") || currentMintes.equals("58") || currentMintes.equals("59") ||
				currentMintes.equals("01") || currentMintes.equals("02") || currentMintes.equals("03") || currentMintes.equals("04")) {
			minutes = "30";
		} else {
			minutes = currentMintes;
		}

		String serialNum = SerialUtils.getSerial();

		boolean isLmePrintLog = false;
		boolean isSelPrintLog = false;

		for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
			PrLmePcStdrBasVo returnLmeStdrBasVo = new PrLmePcStdrBasVo();
			PrSelPcStdrBasVo returnSelStdrBasVo = new PrSelPcStdrBasVo();

			BeanUtils.copyProperties(prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.THIRTY_MINUTE), returnLmeStdrBasVo);

			BeanUtils.copyProperties(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.THIRTY_MINUTE), returnSelStdrBasVo);
			//TODO[pje] 23.06.21 주석처리
//			returnSelStdrBasVo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
//			returnSelStdrBasVo.setOccrrncTime(DateUtil.getNowDateTime("HH") + minutes + "00");
//			returnSelStdrBasVo.setSlePc30MinSn(returnSelStdrBasVo.getSlePc30MinSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + minutes + "00" + serialNum);

			if(isResetProcess) {
				if(restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule && prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE) != null) {

					if(prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE).getEndPc().equals(BigDecimal.ZERO)) {
						log.info("The thirty minute data is zero.");
					} else {
						pcService.insertPrLmePc30MinBas(prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE));

						returnLmeStdrBasVo.setOccrrncDe(returnLmeStdrBasVo.getOccrrncDe());
						returnLmeStdrBasVo.setOccrrncTime(DateUtil.getNowDateTime("HH") + minutes + "00");
						returnLmeStdrBasVo.setLmePc30MinSn(returnLmeStdrBasVo.getLmePc30MinSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + minutes + "00" + serialNum);

						PrLmePcStdrBasVo setVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.THIRTY_MINUTE);
						PrLmePcStdrBasVo getVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE);

						setVo.setDelngQy(0);

						if (!isLmePrintLog) {
							log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " half hours LME schedule !!!!!!!!!!");
							isLmePrintLog = true;
						}
					}
				}

				if (restDateTime.isSorinWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule && prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE) != null
						&& restDateTime.getEhgtStatusCode() == EhgtStatus.SUCCESS.value) {

					if(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE).getSlePc30MinSn() == null ||
							prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE).getEndPc() == 0) {
						log.info("30min data is zero.");
					} else {
						log.info("PAST_THIRTY_MINUTE insert: " + prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE));
					// [pje] 23.06.21 추가
					selService.insertPrSelPc30MinBas(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE));

					// [pje] 23.06.21 수정
					returnSelStdrBasVo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
					returnSelStdrBasVo.setOccrrncTime(DateUtil.getNowDateTime("HH") + minutes + "00");
					returnSelStdrBasVo.setSlePc30MinSn(returnSelStdrBasVo.getSlePc30MinSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + minutes + "00" + serialNum);

					PrSelPcStdrBasVo setVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.THIRTY_MINUTE);
					PrSelPcStdrBasVo getVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE);

					setVo.setDelngQy(0);

					if(!isSelPrintLog) {
						log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " half hours SEL schedule !!!!!!!!!!");
						isSelPrintLog = true;
					}
				}
				}

			} else {
				log.info("29minutes [THIRTY_MINUTE]: " + prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.THIRTY_MINUTE));
				log.info("29minutes [returnSelStdrBasVo]: " + returnSelStdrBasVo);
				if(restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
					BeanUtils.copyProperties(returnLmeStdrBasVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE));
				}

				if(restDateTime.isSorinWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule && prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.THIRTY_MINUTE) != null) {
					log.info("sel pc 30 SCHEDULER [metalCode]: " + returnSelStdrBasVo.getMetalCode());
					// [pje] 23.06.21 주석처리
					//selService.insertPrSelPc30MinBas(returnSelStdrBasVo);
					BeanUtils.copyProperties(returnSelStdrBasVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE));
				}
			}
		}
		log.info("LmeSchedulerServiceImpl halfHoursProcess ---------------------- finish ");
	}

	@Override
	public void oneHoursProcess(boolean isResetProcess) throws Exception {
		log.info("LmeSchedulerServiceImpl oneHoursProcess  ----------------------  start");
		//if(lmeStdrAl60Minute.isReadyToSchedule()) {
		String serialNum = SerialUtils.getSerial();

		boolean isLmePrintLog = false;
		boolean isSelPrintLog = false;

		for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
			PrLmePcStdrBasVo returnLmeStdrBasVo = new PrLmePcStdrBasVo();
			PrSelPcStdrBasVo returnSelStdrBasVo = new PrSelPcStdrBasVo();

			BeanUtils.copyProperties(prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.SIXTY_MINUTE), returnLmeStdrBasVo);

			BeanUtils.copyProperties(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.SIXTY_MINUTE), returnSelStdrBasVo);
//			returnSelStdrBasVo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
//			returnSelStdrBasVo.setOccrrncTime(DateUtil.getNowDateTime("HH") + "0000");
//			returnSelStdrBasVo.setSlePc60MinSn(returnSelStdrBasVo.getSlePc60MinSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

			if(isResetProcess) {
				if(restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule && prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE) != null) {

					if(prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE).getEndPc().equals(BigDecimal.ZERO)) {
						log.info("The sixty minute data is zero.");
					} else {

						pcService.insertPrLmePc60MinBas(prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE));

						returnLmeStdrBasVo.setOccrrncDe(returnLmeStdrBasVo.getOccrrncDe());
						returnLmeStdrBasVo.setOccrrncTime(DateUtil.getNowDateTime("HH") + "0000");
						returnLmeStdrBasVo.setLmePc60MinSn(returnLmeStdrBasVo.getLmePc60MinSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

						PrLmePcStdrBasVo setVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.SIXTY_MINUTE);
						PrLmePcStdrBasVo getVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE);

						setVo.setDelngQy(0);

					if (!isLmePrintLog) {
						log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " 1 hours LME schedule !!!!!!!!!!");
						isLmePrintLog = true;
					}
				}
				}

				if (restDateTime.isSorinWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule && prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE) != null
						&& restDateTime.getEhgtStatusCode() == EhgtStatus.SUCCESS.value) {

					if(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE).getSlePc60MinSn() == null ||
							prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE).getEndPc() == 0) {
						log.info("60min data is zero.");
					} else {

					// [pje] 23.06.21 추가
					selService.insertPrSelPc60MinBas(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE));

					// [pje] 23.06.21 수정
					returnSelStdrBasVo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
					returnSelStdrBasVo.setOccrrncTime(DateUtil.getNowDateTime("HH") + "0000");
					returnSelStdrBasVo.setSlePc60MinSn(returnSelStdrBasVo.getSlePc60MinSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

					PrSelPcStdrBasVo setVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.SIXTY_MINUTE);
					PrSelPcStdrBasVo getVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE);

					setVo.setDelngQy(0);

					if(!isSelPrintLog) {
						log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " 1 hours SEL schedule !!!!!!!!!!");
						isSelPrintLog = true;
					}
				}
				}

			} else {
				if(restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
					BeanUtils.copyProperties(returnLmeStdrBasVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE));
				}

				if(restDateTime.isSorinWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule && prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.SIXTY_MINUTE) != null) {
					// [pje] 23.06.21 주석처리
//					selService.insertPrSelPc60MinBas(returnSelStdrBasVo);
					BeanUtils.copyProperties(returnSelStdrBasVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE));
				}
			}
		}
		//}
		log.info("LmeSchedulerServiceImpl oneHoursProcess  ------------------- finish ");
	}

	@Override
	public void dayProcessLmeForProcedure(boolean isResetProcess) throws Exception {

		if(restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			String serialNum = SerialUtils.getSerial();

			boolean isLmePrintLog = false;

			for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
				PrLmePcStdrBasVo returnLmeStdrBasVo = new PrLmePcStdrBasVo();

				BeanUtils.copyProperties(prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.DAY), returnLmeStdrBasVo);
				returnLmeStdrBasVo.setOccrrncDe(returnLmeStdrBasVo.getLmeBsnDe());
				returnLmeStdrBasVo.setLmePcDeSn(returnLmeStdrBasVo.getLmePcDeSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

				log.info("LmeSchedulerServiceImpl dayProcessLmeForProcedure CALLED ----------------------  metalCode: " + metalCode + ", returnLmeStdrBasVo: " + returnLmeStdrBasVo.toString());

				if(isResetProcess) {
					PrLmePcStdrBasVo setVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.DAY);
					PrLmePcStdrBasVo getVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_DAY);

					setVo.setDelngQy(0);
					setVo.setBeginPc(getVo.getEndPc());
					setVo.setTopPc(getVo.getEndPc());
					setVo.setLwetPc(getVo.getEndPc());
					setVo.setEndPc(getVo.getEndPc());

					setVo.setBeginMdatPc(getVo.getEndMdatPc());
					setVo.setTopMdatPc(getVo.getEndMdatPc());
					setVo.setLwetMdatPc(getVo.getEndMdatPc());
					setVo.setEndMdatPc(getVo.getEndMdatPc());

//					redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.lmeWebSocketUri + "/" + metalCode + "/DE", ReciveLmeDataByUdpSocket.lmeWebSocketUri + "/" + metalCode + "/DE", returnLmeStdrBasVo);
					if(!isLmePrintLog) {
						log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " day LME schedule !!!!!!!!!!");
						isLmePrintLog = true;
					}
				} else {
					//pcService.insertPrLmePcDeBas(returnLmeStdrBasVo);
					Map<String, String> map = new HashMap<>();
					map.put("date", returnLmeStdrBasVo.getLmeBsnDe());
					map.put("metalCode", returnLmeStdrBasVo.getMetalCode());

					pcService.insertPrLmePcDeBasForProcedure(map);
					BeanUtils.copyProperties(returnLmeStdrBasVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_DAY));
				}
			}
		}
	}

	@Override
	public void dayProcessSelForProcedure(boolean isResetProcess) throws Exception {
		if(restDateTime.isSorinWorkTime() && restDateTime.isSorinRealSellEndTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			String serialNum = SerialUtils.getSerial();

			boolean isSelPrintLog = false;

			for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
				//if(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.DAY) == null)
				//	continue;

				PrSelPcStdrBasVo returnSelStdrBasVo = new PrSelPcStdrBasVo();

				BeanUtils.copyProperties(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.DAY), returnSelStdrBasVo);
				returnSelStdrBasVo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
				returnSelStdrBasVo.setSlePcDeSn(returnSelStdrBasVo.getSlePcDeSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

				if(isResetProcess) {
					PrSelPcStdrBasVo setVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.DAY);
					PrSelPcStdrBasVo getVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_DAY);

					setVo.setDelngQy(0);
					setVo.setBeginPc(getVo.getEndPc());
					setVo.setTopPc(getVo.getEndPc());
					setVo.setLwetPc(getVo.getEndPc());
					setVo.setEndPc(getVo.getEndPc());

//					redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode + "/DE", ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode + "/DE", returnSelStdrBasVo);
					if(!isSelPrintLog) {
						log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + "day SEL schedule !!!!!!!!!!");
						isSelPrintLog = true;
					}
				} else {
					log.info("sel pc day SCHEDULER [metalCode]: " + returnSelStdrBasVo.getMetalCode());
					//selService.insertPrSelPcDeBas(returnSelStdrBasVo);
					Map<String, String> map = new HashMap<>();
					map.put("date", DateUtil.getNowDateTime("yyyyMMdd"));
					map.put("metalCode", returnSelStdrBasVo.getMetalCode());

					selService.insertPrSelPcDeBasForProcedure(map);
					BeanUtils.copyProperties(returnSelStdrBasVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_DAY));
				}
			}
		}
	}

	@Override
	public void weekProcessLmeForProcedure(boolean isResetProcess) throws Exception {
		//if(lmeStdrAlWeek.isReadyToSchedule()) {
		if(restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			String serialNum = SerialUtils.getSerial();

			boolean isLmePrintLog = false;

			for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
				PrLmePcStdrBasVo returnLmeStdrBasVo = new PrLmePcStdrBasVo();

				BeanUtils.copyProperties(prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.WEEK), returnLmeStdrBasVo);
				returnLmeStdrBasVo.setOccrrncYyWeek(returnLmeStdrBasVo.getLmeBsnDe().substring(0, 4) + DateUtil.getWeekOfYearByISO(returnLmeStdrBasVo.getLmeBsnDe()));
				returnLmeStdrBasVo.setLmePcYyWeekSn(returnLmeStdrBasVo.getLmePcYyWeekSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

				if(isResetProcess) {
					PrLmePcStdrBasVo setVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.WEEK);
					PrLmePcStdrBasVo getVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_WEEK);

					setVo.setDelngQy(0);
					setVo.setBeginPc(getVo.getEndPc());
					setVo.setTopPc(getVo.getEndPc());
					setVo.setLwetPc(getVo.getEndPc());
					setVo.setEndPc(getVo.getEndPc());

					setVo.setBeginMdatPc(getVo.getEndMdatPc());
					setVo.setTopMdatPc(getVo.getEndMdatPc());
					setVo.setLwetMdatPc(getVo.getEndMdatPc());
					setVo.setEndMdatPc(getVo.getEndMdatPc());

//					redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.lmeWebSocketUri + "/" + metalCode + "/WK", ReciveLmeDataByUdpSocket.lmeWebSocketUri + "/" + metalCode + "/WK", returnLmeStdrBasVo);
					if(!isLmePrintLog) {
						log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + "week LME schedule !!!!!!!!!!");
						isLmePrintLog = true;
					}
				} else {
					//pcService.insertPrLmePcWeekBas(returnLmeStdrBasVo);
					Map<String, String> map = new HashMap<>();
					map.put("date", returnLmeStdrBasVo.getLmeBsnDe());
					map.put("metalCode", returnLmeStdrBasVo.getMetalCode());

					pcService.insertPrLmePcWeekBasForProcedure(map);
					BeanUtils.copyProperties(returnLmeStdrBasVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_WEEK));
				}
			}
		}
		//}
	}

	@Override
	public void weekProcessSelForProcedure(boolean isResetProcess) throws Exception {
		//if(lmeStdrAlWeek.isReadyToSchedule()) {

		if(restDateTime.isSorinWorkTime() && restDateTime.isSorinRealSellEndTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			String serialNum = SerialUtils.getSerial();

			boolean isSelPrintLog = false;

			for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
				//if(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.WEEK) == null)
				//	continue;
				PrSelPcStdrBasVo returnSelStdrBasVo = new PrSelPcStdrBasVo();

				BeanUtils.copyProperties(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.WEEK), returnSelStdrBasVo);
				returnSelStdrBasVo.setOccrrncYyWeek(DateUtil.getNowDateTime("yyyy") + DateUtil.getWeekOfYearByISO(DateUtil.getNowDateTime("yyyyMMdd")));
				returnSelStdrBasVo.setSlePcYyWeekSn(returnSelStdrBasVo.getSlePcYyWeekSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

				if(isResetProcess) {
					PrSelPcStdrBasVo setVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.WEEK);
					PrSelPcStdrBasVo getVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_WEEK);

					setVo.setDelngQy(0);
					setVo.setBeginPc(getVo.getEndPc());
					setVo.setTopPc(getVo.getEndPc());
					setVo.setLwetPc(getVo.getEndPc());
					setVo.setEndPc(getVo.getEndPc());

//					redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode + "/WK", ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode + "/WK", returnSelStdrBasVo);
					if(!isSelPrintLog) {
						log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " week SEL schedule !!!!!!!!!!");
						isSelPrintLog = true;
					}
				} else {
					//selService.insertPrSelPcWeekBas(returnSelStdrBasVo);
					Map<String, String> map = new HashMap<>();
					map.put("date", DateUtil.getNowDateTime("yyyyMMdd"));
					map.put("metalCode", returnSelStdrBasVo.getMetalCode());

					selService.insertPrSelPcWeekBasForProcedure(map);
					BeanUtils.copyProperties(returnSelStdrBasVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_WEEK));
				}
			}
		}
		//}
	}

	@Override
	public void monthProcessLmeForProcedure(boolean isResetProcess) throws Exception {
		//if(lmeStdrAlMt.isReadyToSchedule()) {

		if(restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			String serialNum = SerialUtils.getSerial();

			boolean isLmePrintLog = false;

			for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
				PrLmePcStdrBasVo returnLmeStdrBasVo = new PrLmePcStdrBasVo();

				BeanUtils.copyProperties(prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.MONTH), returnLmeStdrBasVo);
				returnLmeStdrBasVo.setOccrrncYyMt(returnLmeStdrBasVo.getLmeBsnDe().substring(0, 6));
				returnLmeStdrBasVo.setLmePcYyMtSn(returnLmeStdrBasVo.getLmePcYyMtSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

				if(isResetProcess) {

					PrLmePcStdrBasVo setVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.MONTH);
					PrLmePcStdrBasVo getVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_MONTH);

					setVo.setDelngQy(0);
					setVo.setBeginPc(getVo.getEndPc());
					setVo.setTopPc(getVo.getEndPc());
					setVo.setLwetPc(getVo.getEndPc());
					setVo.setEndPc(getVo.getEndPc());

					setVo.setBeginMdatPc(getVo.getEndMdatPc());
					setVo.setTopMdatPc(getVo.getEndMdatPc());
					setVo.setLwetMdatPc(getVo.getEndMdatPc());
					setVo.setEndMdatPc(getVo.getEndMdatPc());

//					redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.lmeWebSocketUri + "/" + metalCode + "/MT", ReciveLmeDataByUdpSocket.lmeWebSocketUri + metalCode + "/MT", returnLmeStdrBasVo);
					if(!isLmePrintLog) {
						log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " month LME schedule !!!!!!!!!!");
						isLmePrintLog = true;
					}
				} else {
					//pcService.insertPrLmePcYyMtBas(returnLmeStdrBasVo);
					Map<String, String> map = new HashMap<>();
					map.put("date", returnLmeStdrBasVo.getLmeBsnDe());
					map.put("metalCode", returnLmeStdrBasVo.getMetalCode());

					pcService.insertPrLmePcYyMtBasForProcedure(map);
					BeanUtils.copyProperties(returnLmeStdrBasVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_MONTH));
				}
			}
		}
		//}
	}

	@Override
	public void monthProcessSelForProcedure(boolean isResetProcess) throws Exception {
		//if(lmeStdrAlMt.isReadyToSchedule()) {

		if(restDateTime.isSorinWorkTime() && restDateTime.isSorinRealSellEndTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			String serialNum = SerialUtils.getSerial();

			boolean isSelPrintLog = false;

			for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
				//if(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.MONTH) == null)
				//	continue;
				PrSelPcStdrBasVo returnSelStdrBasVo = new PrSelPcStdrBasVo();

				BeanUtils.copyProperties(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.MONTH), returnSelStdrBasVo);
				returnSelStdrBasVo.setOccrrncYm(DateUtil.getNowDateTime("yyyyMM"));
				returnSelStdrBasVo.setSlePcYyMtSn(returnSelStdrBasVo.getSlePcYyMtSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

				if(isResetProcess) {
					PrSelPcStdrBasVo setVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.MONTH);
					PrSelPcStdrBasVo getVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_MONTH);

					setVo.setDelngQy(0);
					setVo.setBeginPc(getVo.getEndPc());
					setVo.setTopPc(getVo.getEndPc());
					setVo.setLwetPc(getVo.getEndPc());
					setVo.setEndPc(getVo.getEndPc());

//					redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode + "/MT", ReciveLmeDataByUdpSocket.selWebSocketUri + metalCode + "/MT", returnSelStdrBasVo);
					if(!isSelPrintLog) {
						log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " month SEL schedule !!!!!!!!!!");
						isSelPrintLog = true;
					}
				} else {
					//selService.insertPrSelPcYyMtBas(returnSelStdrBasVo);
					Map<String, String> map = new HashMap<>();
					map.put("date", DateUtil.getNowDateTime("yyyyMMdd"));
					map.put("metalCode", returnSelStdrBasVo.getMetalCode());

					selService.insertPrSelPcYyMtBasForProcedure(map);
					BeanUtils.copyProperties(returnSelStdrBasVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_MONTH));
				}
			}
		}
		//}
	}

	@Override
	public void quarterProcessLmeForProcedure(boolean isResetProcess) throws Exception {
		//if(lmeStdrAlQu.isReadyToSchedule()) {

		if(restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			String serialNum = SerialUtils.getSerial();

			boolean isLmePrintLog = false;

			for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
				PrLmePcStdrBasVo returnLmeStdrBasVo = new PrLmePcStdrBasVo();

				BeanUtils.copyProperties(prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.QUARTER), returnLmeStdrBasVo);
				returnLmeStdrBasVo.setOccrrncYyQu(returnLmeStdrBasVo.getLmeBsnDe().substring(0, 4) + "0" + DateUtil.getQuarterOfYear(returnLmeStdrBasVo.getLmeBsnDe()));
				returnLmeStdrBasVo.setLmePcYyQuSn(returnLmeStdrBasVo.getLmePcYyQuSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

				if(isResetProcess) {

					PrLmePcStdrBasVo setVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.QUARTER);
					PrLmePcStdrBasVo getVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_QUARTER);

					setVo.setDelngQy(0);
					setVo.setBeginPc(getVo.getEndPc());
					setVo.setTopPc(getVo.getEndPc());
					setVo.setLwetPc(getVo.getEndPc());
					setVo.setEndPc(getVo.getEndPc());

					setVo.setBeginMdatPc(getVo.getEndMdatPc());
					setVo.setTopMdatPc(getVo.getEndMdatPc());
					setVo.setLwetMdatPc(getVo.getEndMdatPc());
					setVo.setEndMdatPc(getVo.getEndMdatPc());

//					redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.lmeWebSocketUri + "/" + metalCode + "/QU", ReciveLmeDataByUdpSocket.lmeWebSocketUri + metalCode + "/QU", returnLmeStdrBasVo);
					if(!isLmePrintLog) {
						log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " quarter LME schedule !!!!!!!!!!");
						isLmePrintLog = true;
					}
				} else {
					//pcService.insertPrLmePcYyQuBas(returnLmeStdrBasVo);
					Map<String, String> map = new HashMap<>();
					map.put("date", returnLmeStdrBasVo.getLmeBsnDe());
					map.put("metalCode", returnLmeStdrBasVo.getMetalCode());

					pcService.insertPrLmePcYyQuBasForProcedure(map);
					BeanUtils.copyProperties(returnLmeStdrBasVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_QUARTER));
				}
			}
		}
		//}
	}

	@Override
	public void quarterProcessSelForProcedure(boolean isResetProcess) throws Exception {
		//if(lmeStdrAlQu.isReadyToSchedule()) {

		if(restDateTime.isSorinWorkTime() && restDateTime.isSorinRealSellEndTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			String serialNum = SerialUtils.getSerial();

			boolean isSelPrintLog = false;

			for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
				//if(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.QUARTER) == null)
				//	continue;
				PrSelPcStdrBasVo returnSelStdrBasVo = new PrSelPcStdrBasVo();

				BeanUtils.copyProperties(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.QUARTER), returnSelStdrBasVo);
				returnSelStdrBasVo.setOccrrncQu(DateUtil.getNowDateTime("yyyy") + "0" + DateUtil.getQuarterOfYear(DateUtil.getNowDateTime("yyyyMMdd")));
				returnSelStdrBasVo.setSlePcYyQuSn(returnSelStdrBasVo.getSlePcYyQuSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

				if(isResetProcess) {
					PrSelPcStdrBasVo setVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.QUARTER);
					PrSelPcStdrBasVo getVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_QUARTER);

					setVo.setDelngQy(0);
					setVo.setBeginPc(getVo.getEndPc());
					setVo.setTopPc(getVo.getEndPc());
					setVo.setLwetPc(getVo.getEndPc());
					setVo.setEndPc(getVo.getEndPc());

//					redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode + "/QU", ReciveLmeDataByUdpSocket.selWebSocketUri + metalCode + "/QU", returnSelStdrBasVo);
					if(!isSelPrintLog) {
						log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " quarter SEL schedule !!!!!!!!!!");
						isSelPrintLog = true;
					}
				} else {
					//selService.insertPrSelPcYyQuBas(returnSelStdrBasVo);
					Map<String, String> map = new HashMap<>();
					map.put("date", DateUtil.getNowDateTime("yyyyMMdd"));
					map.put("metalCode", returnSelStdrBasVo.getMetalCode());

					selService.insertPrSelPcYyQuBasForProcedure(map);
					BeanUtils.copyProperties(returnSelStdrBasVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_QUARTER));
				}
			}
		}
		//}
	}

	@Override
	public void yearProcessLmeForProcedure(boolean isResetProcess) throws Exception {
		//if(lmeStdrAlYy.isReadyToSchedule()) {

		if(restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			String serialNum = SerialUtils.getSerial();

			boolean isLmePrintLog = false;

			for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
				PrLmePcStdrBasVo returnLmeStdrBasVo = new PrLmePcStdrBasVo();

				BeanUtils.copyProperties(prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.YEAR), returnLmeStdrBasVo);
				returnLmeStdrBasVo.setOccrrncYy(returnLmeStdrBasVo.getLmeBsnDe().substring(0, 4));
				returnLmeStdrBasVo.setLmePcYySn(returnLmeStdrBasVo.getLmePcYySn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

				if(isResetProcess) {

					PrLmePcStdrBasVo setVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.YEAR);
					PrLmePcStdrBasVo getVo = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_YEAR);

					setVo.setDelngQy(0);
					setVo.setBeginPc(getVo.getEndPc());
					setVo.setTopPc(getVo.getEndPc());
					setVo.setLwetPc(getVo.getEndPc());
					setVo.setEndPc(getVo.getEndPc());

					setVo.setBeginMdatPc(getVo.getEndMdatPc());
					setVo.setTopMdatPc(getVo.getEndMdatPc());
					setVo.setLwetMdatPc(getVo.getEndMdatPc());
					setVo.setEndMdatPc(getVo.getEndMdatPc());

//					redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.lmeWebSocketUri + "/" + metalCode + "/YY", ReciveLmeDataByUdpSocket.lmeWebSocketUri + metalCode + "/YY", returnLmeStdrBasVo);
					if(!isLmePrintLog) {
						log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " year LME schedule !!!!!!!!!!");
						isLmePrintLog = true;
					}
				} else {
					//pcService.insertPrLmePcYyBas(returnLmeStdrBasVo);
					Map<String, String> map = new HashMap<>();
					map.put("date", returnLmeStdrBasVo.getLmeBsnDe());
					map.put("metalCode", returnLmeStdrBasVo.getMetalCode());

					pcService.insertPrLmePcYyBasForProcedure(map);
					BeanUtils.copyProperties(returnLmeStdrBasVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_YEAR));
				}
			}
		}
		//}
	}

	@Override
	public void yearProcessSelForProcedure(boolean isResetProcess) throws Exception {
		//if(lmeStdrAlYy.isReadyToSchedule()) {

		if(restDateTime.isSorinWorkTime() && restDateTime.isSorinRealSellEndTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			String serialNum = SerialUtils.getSerial();

			boolean isSelPrintLog = false;

			for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
				//if(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.YEAR) == null)
				//	continue;

				PrSelPcStdrBasVo returnSelStdrBasVo = new PrSelPcStdrBasVo();

				BeanUtils.copyProperties(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.YEAR), returnSelStdrBasVo);
				returnSelStdrBasVo.setOccrrncYy(DateUtil.getNowDateTime("yyyy"));
				returnSelStdrBasVo.setSlePcYySn(returnSelStdrBasVo.getSlePcYySn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

				if(isResetProcess) {
					PrSelPcStdrBasVo setVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.YEAR);
					PrSelPcStdrBasVo getVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_YEAR);

					setVo.setDelngQy(0);
					setVo.setBeginPc(getVo.getEndPc());
					setVo.setTopPc(getVo.getEndPc());
					setVo.setLwetPc(getVo.getEndPc());
					setVo.setEndPc(getVo.getEndPc());

//					redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode + "/YY", ReciveLmeDataByUdpSocket.selWebSocketUri + metalCode + "/YY", returnSelStdrBasVo);
					if(!isSelPrintLog) {
						log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " year SEL schedule !!!!!!!!!!");
						isSelPrintLog = true;
					}
				} else {
					//selService.insertPrSelPcYyBas(returnSelStdrBasVo);
					Map<String, String> map = new HashMap<>();
					map.put("date", DateUtil.getNowDateTime("yyyyMMdd"));
					map.put("metalCode", returnSelStdrBasVo.getMetalCode());

					selService.insertPrSelPcYyBasForProcedure(map);
					BeanUtils.copyProperties(returnSelStdrBasVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_YEAR));
				}
			}
		}
		//}
	}

	public void checkLmeSendDataInOneMinute() {
		try {
			if(restDateTime.isSorinWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
				boolean isOneMinuteStatus = true;
				String errorMetalCode = "";

				for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
					if(metalCode.equals(metalCodeNi))
						continue;

					PrSelPcStdrBasVo returnSelStdrBasVo = new PrSelPcStdrBasVo();

					BeanUtils.copyProperties(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.STDR), returnSelStdrBasVo);

					if(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.STDR) == null)
						continue;

					if(returnSelStdrBasVo.getOccrrncTime() == null)
						continue;

					int occrrncHour = Integer.parseInt(returnSelStdrBasVo.getOccrrncTime().substring(0, 2));
					int occrrnMinute = Integer.parseInt(returnSelStdrBasVo.getOccrrncTime().substring(2, 4));
					int occrrnSecond = Integer.parseInt(returnSelStdrBasVo.getOccrrncTime().substring(4, 6));

					int nowHour = Integer.parseInt(DateUtil.getNowDateTime("HH"));
					int nowMinute = Integer.parseInt(DateUtil.getNowDateTime("mm"));
					int nowSecond = Integer.parseInt(DateUtil.getNowDateTime("ss"));

					int calculationTime = (nowHour-occrrncHour)*3600 + (nowMinute-occrrnMinute)*60 + (nowSecond-occrrnSecond);

					if(Math.abs(calculationTime) >= 65) {
						isOneMinuteStatus = false;
						errorMetalCode = metalCode;
						log.info("lme data error -> errorMetalCode: " + errorMetalCode
								+ "/ OccrrncTime: " + returnSelStdrBasVo.getOccrrncTime()
								+ "/ calculationTime: " + Math.abs(calculationTime));
						break;
					}
				}

				if(!isOneMinuteStatus) {
					oneMinuteFail(errorMetalCode);
					return;
				} else {
					if(restDateTime.getLmeStatusCode() == LmeStatus.FAIL.value) {
						oneMinuteSuccess();
					}
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			log.error(e.toString() + " -> message : " + e);
		}
	}

	private void oneMinuteFail(String metalCode) throws Exception {
		restDateTime.setLmeStatusCode(LmeStatus.FAIL);
		restDateTime.updateCntcStts(restDateTime.getLmeStatusCode());

		if(restDateTime.getGapTime() <= 60 && restDateTime.getGapTime() != 0)
			return;

		restDateTime.updateRestTime(64, "LME 데이터 오류로 인한 64초 연장");
		restDateTime.initialize();
		redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.restTimeSocketUri, ReciveLmeDataByUdpSocket.restTimeSocketUri, "setRestTime");
		log.info("----------------- LME data was not send in one minute -----------------");
		log.info(" metalCode : " + metalCode);
		log.info("-----------------------------------------------------------------------");
	}

	private void oneMinuteSuccess() throws Exception {
		restDateTime.setLmeStatusCode(LmeStatus.SUCCESS);
		restDateTime.updateCntcStts(restDateTime.getLmeStatusCode());

		log.info("+++++++++++++++++ LME data is send in one minute +++++++++++++++++");
	}


	private void initializeCffcntAmount() throws Exception {
		itService.selectTopItFtrsFshgManageDtl();

		log.info("==========================Cffcnt Amount==========================");

		for(String metalCode : metalCodeList) {
			log.info(metalCode + " EHGT : " + itFtrsFshgManageDtlVoService.getItFtrsFshgManageDtlVo(metalCode).getEhgtMdatCffcntAmount());
			log.info(metalCode + " LME : " + itFtrsFshgManageDtlVoService.getItFtrsFshgManageDtlVo(metalCode).getLmeMdatCffcntAmount());
		}

		log.info("================================================================");
	}

	private String getMetalCode(String value) {

    	if(value.equals(gicNameZn) || value.equals(gicNameZn.substring(0,3))) return metalCodeZn;
    	if(value.equals(gicNamePb) || value.equals(gicNamePb.substring(0,3))) return metalCodePb;
    	if(value.equals(gicNameCu) || value.equals(gicNameCu.substring(0,3))) return metalCodeCu;
    	if(value.equals(gicNameAl) || value.equals(gicNameAl.substring(0,3))) return metalCodeAl;
    	if(value.equals(gicNameNi) || value.equals(gicNameNi.substring(0,3))) return metalCodeNi;
    	if(value.equals(gicNameSn) || value.equals(gicNameSn.substring(0,3))) return metalCodeSn;

    	return null;
    }

	@Override
	@Scheduled(cron = "0 45 23 * * 1-5", zone = "Asia/Seoul")
	@Async("lmeThreadPoolExcuter")
	public void StEvemthAccmlDalyAvgPcInsertSchedule() throws Exception {
		log.info("==========================StEvemthAccmlDalyAvgPcInsertSchedule==========================");
		try {
			pcService.insertStEvemthAccmlDalyAvgPcBas();
		} catch (Exception e) {
			log.info("================"+e.getMessage()+"================");
		}
		log.info("=========================================================================================");
	}

	@Override
	@Scheduled(cron = "0 0 9-17 * * 1-5", zone = "Asia/Seoul")
	@Async("lmeThreadPoolExcuter")
	public void checkFallSelPcSchedule() throws Exception {
		log.debug("==========================checkFallSelPcSchedule==========================");
		try {
//			List<OpFallSelPcBasVo> compareList = pcService.selectFallSelPc();
//			for (OpFallSelPcBasVo fallSelPc : compareList) {
//				if (fallSelPc.getSelPc() >= 0) {
//					// 알림톡 발송
//					if (fallSelPc.getSmsYn().equals("Y")) {
//						sendFallPcMessage(fallSelPc);
//					}
//
//					// db업데이트
//					pcService.updateFallSelPcBas(fallSelPc.getFallSeqNo());
//					commonService.insertTableHistory("OP_FALL_SEL_PC_BAS", fallSelPc);
//				}
//			}
		} catch (Exception e) {
			log.info("[LmeSchedulerServiceImpl][checkFallSelPcSchedule] " + ExceptionUtils.getStackTrace(e));
		}
		log.debug("=========================================================================================");
	}

	private synchronized void sendFallPcMessage(OpFallSelPcBasVo fallSelPc) {
		Runnable smsRun = () -> {
			try {
				List<Map<String, String>> returnList = pcService.selectMemberSmsByMetalCode(fallSelPc.getMetalCode());

				for (Map<String, String> returnMap : returnList) {
					if (StringUtils.isNotEmpty(returnMap.get("MOBLPHON_NO"))) {
						SMSVO smsVO = new SMSVO();
						smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
						smsVO.setCommerceNtcnAt("N"); // 커머스 알림 여부
						try {
							smsVO.setPhone(CryptoUtil.decryptAES256(returnMap.get("MOBLPHON_NO")));
						} catch (Exception e) {
							log.debug("LmeSchedulerServiceImpl sendFallPcMessage MOBLPHON_NO CryptoUtil.decryptAES256 ERROR "+ e.getMessage());
						}
						Map<String, String> smsMap = new HashMap<>();

						smsMap.put("templateNum", "112");
						smsMap.put("entrpsKorean", returnMap.get("ENTRPSNM_KOREAN"));
						smsMap.put("metalCode", fallSelPc.getMetalName());
						smsMap.put("sarokPc", String.format("%,d", Math.round(fallSelPc.getSarokPc())));
						smsMap.put("lwetPc", String.format("%,d", Math.round(fallSelPc.getLwetPc())));
						smsMap.put("fallSelPc", String.format("%,d", Math.round(fallSelPc.getFallSelPc())));

						smsService.insertSMS(smsVO, smsMap);
					}
				}
			} catch (Exception e) {
				log.debug("[LmeSchedulerServiceImpl][sendFallPcMessage] " + ExceptionUtils.getStackTrace(e));
			}
		};
		taskExecutor.execute(smsRun);
	}

	/**
	 * <pre>
	 * 처리내용: 매 시간마다 현재의 프리미엄을 가져와 전역변수로 만든다.
	 * </pre>
	 * @date 2023. 6. 01.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 6. 01.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @return
	 */
//	@Override
//	@Scheduled(cron = "0 0 9-17 * * 1-5", zone = "Asia/Seoul")
//	public void initSelPremiumAmount() throws Exception {
//		log.debug("==========================[LmeSchedulerServiceImpl][initSelPremiumAmount] start==========================");
//		try {
//
//			fallSelPc.initSelPremiumAmount();
//
//		} catch (Exception e) {
//			log.info("[LmeSchedulerServiceImpl][initSelPremiumAmount] " + ExceptionUtils.getStackTrace(e));
//		}
//		log.debug("==========================[LmeSchedulerServiceImpl][initSelPremiumAmount] end============================");
//	}


	@Override
	public void dayProcessSel(List<String> MetalCodeList) throws Exception {
		String serialNum = SerialUtils.getSerial();

		boolean isSelPrintLog = false;

		//for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
		for(String metalCode : MetalCodeList) {
				log.info("sel pc day START [metalCode]: " + metalCode);

				PrSelPcStdrBasVo returnSelStdrBasVo = new PrSelPcStdrBasVo();

				BeanUtils.copyProperties(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.DAY), returnSelStdrBasVo);
				returnSelStdrBasVo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
				returnSelStdrBasVo.setSlePcDeSn(returnSelStdrBasVo.getSlePcDeSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

				log.info("sel pc day SCHEDULER [metalCode]: " + returnSelStdrBasVo.getMetalCode());
				Map<String, String> map = new HashMap<>();
				map.put("date", DateUtil.getNowDateTime("yyyyMMdd"));
				map.put("metalCode", returnSelStdrBasVo.getMetalCode());

				selService.insertPrSelPcDeBasForProcedure(map);
				BeanUtils.copyProperties(returnSelStdrBasVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_DAY));

				// 초기화
				PrSelPcStdrBasVo setVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.DAY);
				PrSelPcStdrBasVo getVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_DAY);

				setVo.setDelngQy(0);
				setVo.setBeginPc(getVo.getEndPc());
				setVo.setTopPc(getVo.getEndPc());
				setVo.setLwetPc(getVo.getEndPc());
				setVo.setEndPc(getVo.getEndPc());

	//			redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode + "/DE", ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode + "/DE", returnSelStdrBasVo);
				if(!isSelPrintLog) {
					log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + "day SEL schedule !!!!!!!!!!");
					isSelPrintLog = true;
				}
			}
		}

	@Override
	public void weekProcessSel(List<String> MetalCodeList) throws Exception {
		String serialNum = SerialUtils.getSerial();

		boolean isSelPrintLog = false;

		//for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
		for(String metalCode : MetalCodeList) {
				PrSelPcStdrBasVo returnSelStdrBasVo = new PrSelPcStdrBasVo();

				BeanUtils.copyProperties(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.WEEK), returnSelStdrBasVo);
				returnSelStdrBasVo.setOccrrncYyWeek(DateUtil.getNowDateTime("yyyy") + DateUtil.getWeekOfYearByISO(DateUtil.getNowDateTime("yyyyMMdd")));
				returnSelStdrBasVo.setSlePcYyWeekSn(returnSelStdrBasVo.getSlePcYyWeekSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

				Map<String, String> map = new HashMap<>();
				map.put("date", DateUtil.getNowDateTime("yyyyMMdd"));
				map.put("metalCode", returnSelStdrBasVo.getMetalCode());

				selService.insertPrSelPcWeekBasForProcedure(map);
				BeanUtils.copyProperties(returnSelStdrBasVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_WEEK));

				// 초기화
				PrSelPcStdrBasVo setVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.WEEK);
				PrSelPcStdrBasVo getVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_WEEK);

				setVo.setDelngQy(0);
				setVo.setBeginPc(getVo.getEndPc());
				setVo.setTopPc(getVo.getEndPc());
				setVo.setLwetPc(getVo.getEndPc());
				setVo.setEndPc(getVo.getEndPc());

	//			redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode + "/WK", ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode + "/WK", returnSelStdrBasVo);
				if(!isSelPrintLog) {
					log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " week SEL schedule !!!!!!!!!!");
					isSelPrintLog = true;
				}
			}
		}

	@Override
	public void monthProcessSel(List<String> MetalCodeList) throws Exception {
		String serialNum = SerialUtils.getSerial();

		boolean isSelPrintLog = false;

		//for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
		for(String metalCode : MetalCodeList) {
				PrSelPcStdrBasVo returnSelStdrBasVo = new PrSelPcStdrBasVo();

				BeanUtils.copyProperties(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.MONTH), returnSelStdrBasVo);
				returnSelStdrBasVo.setOccrrncYm(DateUtil.getNowDateTime("yyyyMM"));
				returnSelStdrBasVo.setSlePcYyMtSn(returnSelStdrBasVo.getSlePcYyMtSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

				Map<String, String> map = new HashMap<>();
				map.put("date", DateUtil.getNowDateTime("yyyyMMdd"));
				map.put("metalCode", returnSelStdrBasVo.getMetalCode());

				selService.insertPrSelPcYyMtBasForProcedure(map);
				BeanUtils.copyProperties(returnSelStdrBasVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_MONTH));

				PrSelPcStdrBasVo setVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.MONTH);
				PrSelPcStdrBasVo getVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_MONTH);

				setVo.setDelngQy(0);
				setVo.setBeginPc(getVo.getEndPc());
				setVo.setTopPc(getVo.getEndPc());
				setVo.setLwetPc(getVo.getEndPc());
				setVo.setEndPc(getVo.getEndPc());

	//			redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode + "/MT", ReciveLmeDataByUdpSocket.selWebSocketUri + metalCode + "/MT", returnSelStdrBasVo);
				if(!isSelPrintLog) {
					log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " month SEL schedule !!!!!!!!!!");
					isSelPrintLog = true;
				}
			}
		}

	@Override
	public void quarterProcessSel(List<String> MetalCodeList) throws Exception {
		String serialNum = SerialUtils.getSerial();

		boolean isSelPrintLog = false;

		//for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
		for(String metalCode : MetalCodeList) {
				PrSelPcStdrBasVo returnSelStdrBasVo = new PrSelPcStdrBasVo();

				BeanUtils.copyProperties(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.QUARTER), returnSelStdrBasVo);
				returnSelStdrBasVo.setOccrrncQu(DateUtil.getNowDateTime("yyyy") + "0" + DateUtil.getQuarterOfYear(DateUtil.getNowDateTime("yyyyMMdd")));
				returnSelStdrBasVo.setSlePcYyQuSn(returnSelStdrBasVo.getSlePcYyQuSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

				Map<String, String> map = new HashMap<>();
				map.put("date", DateUtil.getNowDateTime("yyyyMMdd"));
				map.put("metalCode", returnSelStdrBasVo.getMetalCode());

				selService.insertPrSelPcYyQuBasForProcedure(map);
				BeanUtils.copyProperties(returnSelStdrBasVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_QUARTER));

				// 초기화
				PrSelPcStdrBasVo setVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.QUARTER);
				PrSelPcStdrBasVo getVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_QUARTER);

				setVo.setDelngQy(0);
				setVo.setBeginPc(getVo.getEndPc());
				setVo.setTopPc(getVo.getEndPc());
				setVo.setLwetPc(getVo.getEndPc());
				setVo.setEndPc(getVo.getEndPc());

	//			redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode + "/QU", ReciveLmeDataByUdpSocket.selWebSocketUri + metalCode + "/QU", returnSelStdrBasVo);
				if(!isSelPrintLog) {
					log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " quarter SEL schedule !!!!!!!!!!");
					isSelPrintLog = true;
				}
			}
		}

	@Override
	public void yearProcessSel(List<String> MetalCodeList) throws Exception {
		String serialNum = SerialUtils.getSerial();

		boolean isSelPrintLog = false;

		//for(String metalCode : ReciveLmeDataByUdpSocket.receiveMetalCodeList) {
		for(String metalCode : MetalCodeList) {
				PrSelPcStdrBasVo returnSelStdrBasVo = new PrSelPcStdrBasVo();

				BeanUtils.copyProperties(prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.YEAR), returnSelStdrBasVo);
				returnSelStdrBasVo.setOccrrncYy(DateUtil.getNowDateTime("yyyy"));
				returnSelStdrBasVo.setSlePcYySn(returnSelStdrBasVo.getSlePcYySn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + serialNum);

				Map<String, String> map = new HashMap<>();
				map.put("date", DateUtil.getNowDateTime("yyyyMMdd"));
				map.put("metalCode", returnSelStdrBasVo.getMetalCode());

				selService.insertPrSelPcYyBasForProcedure(map);
				BeanUtils.copyProperties(returnSelStdrBasVo, prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_YEAR));

				// 초기화
				PrSelPcStdrBasVo setVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.YEAR);
				PrSelPcStdrBasVo getVo = prSelPcStdrBasVoMapService.getPrSelPcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_YEAR);

				setVo.setDelngQy(0);
				setVo.setBeginPc(getVo.getEndPc());
				setVo.setTopPc(getVo.getEndPc());
				setVo.setLwetPc(getVo.getEndPc());
				setVo.setEndPc(getVo.getEndPc());

	//			redisPubSubService.publishMessage(ReciveLmeDataByUdpSocket.selWebSocketUri + "/" + metalCode + "/YY", ReciveLmeDataByUdpSocket.selWebSocketUri + metalCode + "/YY", returnSelStdrBasVo);
				if(!isSelPrintLog) {
					log.info("!!!!!!!!!! metalCodeList : " + ReciveLmeDataByUdpSocket.receiveMetalCodeList + " year SEL schedule !!!!!!!!!!");
					isSelPrintLog = true;
				}
			}
		}

	@Override
	@Scheduled(cron = "*/30 * 9-21 * * 1-5", zone = "Asia/Seoul")
	@Async("lmeThreadPoolExcuter")
	public void diverScheduler() {
		try {
			//휴일, 휴무시간 다이버 조건체크 하지 않음.
			if(restDateTime.isSorinWorkTime()) {
				dynmDiverSetup.executeDiver();
			}
		} catch (Exception e) {
			log.debug("diverMotnCndCnfirm 요청 오류 :" + e.getMessage());
		}
	}

	@Override
	@Scheduled(cron = "* * 23 * * 1-5", zone = "Asia/Seoul")
	@Async("lmeThreadPoolExcuter")
	public void redisPremiumInfoClean() {
		try {
			List<LivePremiumVO> premiumInfoList;
			premiumInfoList = (List<LivePremiumVO>) redisUtil.getDataJson(PREMIUM_INFO_LIST);

			if(!premiumInfoList.isEmpty()) {
				redisUtil.deleteData(PREMIUM_INFO_LIST);
			}
			List<LivePremiumVO> premiumInfoMap = pcInfoMapper.getPremiumInfoMap();
			redisUtil.setDataJson(PREMIUM_INFO_LIST , premiumInfoMap);

		} catch (Exception e) {
			log.debug("redisPremiumInfoReset error:" + e.getMessage());
		}
	}
}
