package com.sorincorp.lme.pc.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sorincorp.comm.bsnInfo.model.RestdeFxLmeVO;
import com.sorincorp.comm.bsnInfo.model.RestdeVO;
import com.sorincorp.comm.pcInfo.model.PrPremiumSelVO;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.lme.ReciveLmeDataByUdpSocket;
import com.sorincorp.lme.constant.PrPcStdrBasVoConstant;
import com.sorincorp.lme.etc.model.CalculateSpreadVo;
import com.sorincorp.lme.etc.model.ValidLmeSpreadDateVo;
import com.sorincorp.lme.etc.service.EtcService;
import com.sorincorp.lme.pc.model.PrLmeEvlPcBasVo;
import com.sorincorp.lme.pc.model.PrLmePcStdrBasVo;
import com.sorincorp.lme.util.LmeDataUtil;
import com.sorincorp.lme.util.RestDateTime;
import com.sorincorp.lme.util.RestDateTime.Operator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ReturnNewLmeVo {

	@Value("${metalCode.Zn}")
	private String metalCodeZn;
	@Value("${metalCode.Pb}")
	private String metalCodePb;
	@Value("${metalCode.Cu}")
	private String metalCodeCu;
	@Value("${metalCode.Al}")
	private String metalCodeAl;
	@Value("${metalCode.Ni}")
	private String metalCodeNi;
	@Value("${metalCode.Sn}")
	private String metalCodeSn;

	@Value("${gicName.Zn}")
	private String gicNameZn;
	@Value("${gicName.Pb}")
	private String gicNamePb;
	@Value("${gicName.Cu}")
	private String gicNameCu;
	@Value("${gicName.Al}")
	private String gicNameAl;
	@Value("${gicName.Ni}")
	private String gicNameNi;
	@Value("${gicName.Sn}")
	private String gicNameSn;

	@Autowired
	private RestDateTime restDateTime;

	@Autowired
	private EtcService etcService;

	public PrLmeEvlPcBasVo process_CopyNewLmeEvlVo(PrLmeEvlPcBasVo vo) throws Exception {
		PrLmeEvlPcBasVo returnVo = new PrLmeEvlPcBasVo();
		BeanUtils.copyProperties(vo, returnVo);

		return returnVo;
	}

	public PrLmePcStdrBasVo process_CopyNewLmeStdrVo(PrLmePcStdrBasVo vo) throws Exception {
		PrLmePcStdrBasVo returnVo = new PrLmePcStdrBasVo();
		BeanUtils.copyProperties(vo, returnVo);

		return returnVo;
	}

	/*
	 * parsing하여 LME 정보에 맞게 만든 전문 실시간 데이터, 방금 전 전문 data, 이전 분기별 data를 기준으로 해당 분기의
	 * LME singleTone 데이터를 만든다.
	 */
	// (pje) DB에 넣고 실시간차트에 보여주기 위해 전문으로 LME값 계산
	public PrLmePcStdrBasVo process_MinuteScheduleVo(PrLmePcStdrBasVo nowLmeStdrVo, PrLmePcStdrBasVo justBeforeLmeVo, PrLmePcStdrBasVo pastLmeMinuteVo, String tickTime, Map<String, Boolean> changeAt) throws Exception {
		PrLmePcStdrBasVo returnVo = new PrLmePcStdrBasVo();
		PrLmePcStdrBasVo returnJustBeforeLmeVo = process_CopyNewLmeStdrVo(justBeforeLmeVo);
		PrLmePcStdrBasVo returnPastLmeMinuteVo = process_CopyNewLmeStdrVo(pastLmeMinuteVo);
		
		returnVo.setMetalCode(nowLmeStdrVo.getMetalCode());
		
		String hlafMinutes = "";
		int current30Minute = Integer.parseInt(DateUtil.getNowDateTime("mm"));
		
		if(1 <= current30Minute && current30Minute <= 29) {
			hlafMinutes = "00"; 
		} else if (31 <= current30Minute && current30Minute <= 59) {
			hlafMinutes = "30"; 
		} else {
			hlafMinutes = DateUtil.getNowDateTime("mm");
		}
		
		switch(tickTime) {
			case "01":
				returnVo.setOccrrncDe(nowLmeStdrVo.getOccrrncDe());
				returnVo.setOccrrncTime(DateUtil.getNowDateTime("HHmm") + "00");
				returnVo.setSpread(nowLmeStdrVo.getSpread());
				break;
			case "30":
				returnVo.setOccrrncDe(nowLmeStdrVo.getOccrrncDe());
				returnVo.setOccrrncTime(DateUtil.getNowDateTime("HH") + hlafMinutes + "00");
				break;
			case "60":
				returnVo.setOccrrncDe(nowLmeStdrVo.getOccrrncDe());
				returnVo.setOccrrncTime(DateUtil.getNowDateTime("HH") + "0000");
				break;
			default :
				returnVo.setOccrrncDe(nowLmeStdrVo.getLmeBsnDe());
				break;
		}
		
		returnVo.setLmePc01MinSn(nowLmeStdrVo.getLmePcRltmSn().substring(0, 8) + DateUtil.getNowDateTime("HHmm") + "00" + nowLmeStdrVo.getLmePcRltmSn().substring(14, 20));
		returnVo.setLmePc30MinSn(nowLmeStdrVo.getLmePcRltmSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + hlafMinutes + "00" + nowLmeStdrVo.getLmePcRltmSn().substring(14, 20));
		returnVo.setLmePc60MinSn(nowLmeStdrVo.getLmePcRltmSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + nowLmeStdrVo.getLmePcRltmSn().substring(14, 20));
		
		returnVo.setLmePcDeSn(nowLmeStdrVo.getLmePcRltmSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + nowLmeStdrVo.getLmePcRltmSn().substring(14, 20));
		
		returnVo.setOccrrncYyWeek(nowLmeStdrVo.getLmeBsnDe().substring(0, 4) + DateUtil.getWeekOfYearByISO(nowLmeStdrVo.getLmeBsnDe()));
		returnVo.setLmePcYyWeekSn(nowLmeStdrVo.getLmePcRltmSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + nowLmeStdrVo.getLmePcRltmSn().substring(14, 20));
		
		returnVo.setOccrrncYyMt(nowLmeStdrVo.getLmeBsnDe().substring(0, 6));
		returnVo.setLmePcYyMtSn(nowLmeStdrVo.getLmePcRltmSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + nowLmeStdrVo.getLmePcRltmSn().substring(14, 20));
		
		returnVo.setOccrrncYyQu(nowLmeStdrVo.getLmeBsnDe().substring(0, 4) + "0" + DateUtil.getQuarterOfYear(nowLmeStdrVo.getLmeBsnDe()));
		returnVo.setLmePcYyQuSn(nowLmeStdrVo.getLmePcRltmSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + nowLmeStdrVo.getLmePcRltmSn().substring(14, 20));
		
		returnVo.setOccrrncYy(nowLmeStdrVo.getLmeBsnDe().substring(0, 4));
		returnVo.setLmePcYySn(nowLmeStdrVo.getLmePcRltmSn().substring(0, 8) + DateUtil.getNowDateTime("HH") + "0000" + nowLmeStdrVo.getLmePcRltmSn().substring(14, 20));
				
		returnVo.setLmeBsnDe(nowLmeStdrVo.getLmeBsnDe());
		
		returnVo.setThreemonthBeginPc(nowLmeStdrVo.getThreemonthBeginPc());
		returnVo.setThreemonthEndPc(nowLmeStdrVo.getThreemonthEndPc());
		returnVo.setThreemonthTopPc(nowLmeStdrVo.getThreemonthTopPc());
		returnVo.setThreemonthLwetPc(nowLmeStdrVo.getThreemonthLwetPc());
		returnVo.setThreemonthVersusPc(nowLmeStdrVo.getThreemonthVersusPc());
		returnVo.setThreemonthVersusRate(nowLmeStdrVo.getThreemonthVersusRate());

		// LME 조정 가격 관련 세팅
		returnVo.setThreemonthBeginMdatPc(nowLmeStdrVo.getThreemonthBeginMdatPc());
		returnVo.setThreemonthEndMdatPc(nowLmeStdrVo.getThreemonthEndMdatPc());
		returnVo.setThreemonthTopMdatPc(nowLmeStdrVo.getThreemonthTopMdatPc());
		returnVo.setThreemonthLwetMdatPc(nowLmeStdrVo.getThreemonthLwetMdatPc());


		if(returnJustBeforeLmeVo.getEndPc() == null) {
			returnJustBeforeLmeVo.setEndPc(BigDecimal.ZERO);
		}
		
		if(returnPastLmeMinuteVo.getEndPc() == null) {
			returnPastLmeMinuteVo.setEndPc(BigDecimal.ZERO);
		}

		if(returnJustBeforeLmeVo.getEndMdatPc() == null) {
			returnJustBeforeLmeVo.setEndMdatPc(BigDecimal.ZERO);
		}

		if(returnPastLmeMinuteVo.getEndMdatPc() == null) {
			returnPastLmeMinuteVo.setEndMdatPc(BigDecimal.ZERO);
		}

		// [pje]추가 --> 스프레드값이 달라졌는지 확인
		if(tickTime.equals("01"))
			reCheckLmeSpread(nowLmeStdrVo);
		
		//시초가 일 경우
		if(restDateTime.getReadytoStartLmeData(nowLmeStdrVo.getMetalCode())) {
			returnVo.setEndPc(nowLmeStdrVo.getEndPc());
			returnVo.setBeginPc(nowLmeStdrVo.getEndPc());
			returnVo.setTopPc(nowLmeStdrVo.getEndPc());
			returnVo.setLwetPc(nowLmeStdrVo.getEndPc());

			// LME 조정 가격 관련 세팅
			returnVo.setEndMdatPc(nowLmeStdrVo.getEndMdatPc());
			returnVo.setBeginMdatPc(nowLmeStdrVo.getEndMdatPc());
			returnVo.setTopMdatPc(nowLmeStdrVo.getEndMdatPc());
			returnVo.setLwetMdatPc(nowLmeStdrVo.getEndMdatPc());

			returnVo.setVersusPc(BigDecimal.ZERO);
			returnVo.setVersusRate(BigDecimal.ZERO);
			
			returnVo.setDelngQy(1);
			
			if(returnVo.getMetalCode().equals("7") && tickTime.equals("01")) {
				log.info("lme justBeforeSelVo.getEndPc() == 0: " + returnVo.getEndPc() );
			}
			
		} else if (Boolean.TRUE.equals(changeAt.get(returnVo.getMetalCode()))) {	// 시간이 바뀐 경우
			returnVo.setEndPc(nowLmeStdrVo.getEndPc());
			returnVo.setBeginPc(nowLmeStdrVo.getEndPc());
			returnVo.setTopPc(nowLmeStdrVo.getEndPc());
			returnVo.setLwetPc(nowLmeStdrVo.getEndPc());

			// LME 조정 가격 관련 세팅
			returnVo.setEndMdatPc(nowLmeStdrVo.getEndMdatPc());
			returnVo.setBeginMdatPc(nowLmeStdrVo.getEndMdatPc());
			returnVo.setTopMdatPc(nowLmeStdrVo.getEndMdatPc());
			returnVo.setLwetMdatPc(nowLmeStdrVo.getEndMdatPc());

			returnVo.setVersusPc(BigDecimal.ZERO);
			returnVo.setVersusRate(BigDecimal.ZERO);

			returnVo.setDelngQy(1);

			if(returnVo.getMetalCode().equals("7") && tickTime.equals("01")) {
				log.info("chageAt beginPc: " + returnVo.getBeginPc() );
			}
			
		} else if(justBeforeLmeVo.getEndPc().compareTo(BigDecimal.ZERO) == 0) {
			returnVo.setEndPc(nowLmeStdrVo.getEndPc());
			returnVo.setBeginPc(nowLmeStdrVo.getEndPc());
			returnVo.setTopPc(nowLmeStdrVo.getEndPc());
			returnVo.setLwetPc(nowLmeStdrVo.getEndPc());

			// LME 조정 가격 관련 세팅
			returnVo.setEndMdatPc(nowLmeStdrVo.getEndMdatPc());
			returnVo.setBeginMdatPc(nowLmeStdrVo.getEndMdatPc());
			returnVo.setTopMdatPc(nowLmeStdrVo.getEndMdatPc());
			returnVo.setLwetMdatPc(nowLmeStdrVo.getEndMdatPc());

			returnVo.setVersusPc(BigDecimal.ZERO);
			returnVo.setVersusRate(BigDecimal.ZERO);

			returnVo.setDelngQy(1);

			if(returnVo.getMetalCode().equals("7") && tickTime.equals("01")) {
				log.info("lme justBeforeSelVo.getEndPc() == 0: " + returnVo.getEndPc() );
			}

			// 이전 1분 데이터 세팅
			//setPastData(tickTime, returnVo);
		} else {
			returnVo.setDelngQy(justBeforeLmeVo.getDelngQy() + 1);
			
			returnVo.setEndPc(nowLmeStdrVo.getEndPc());
			returnVo.setBeginPc(returnJustBeforeLmeVo.getBeginPc());
			returnVo.setTopPc(returnJustBeforeLmeVo.getTopPc());
			returnVo.setLwetPc(returnJustBeforeLmeVo.getLwetPc());

			// LME 조정 가격 관련 세팅
			returnVo.setEndMdatPc(nowLmeStdrVo.getEndMdatPc());
			returnVo.setBeginMdatPc(returnJustBeforeLmeVo.getBeginMdatPc());
			returnVo.setTopMdatPc(returnJustBeforeLmeVo.getTopMdatPc());
			returnVo.setLwetMdatPc(returnJustBeforeLmeVo.getLwetMdatPc());

			if(nowLmeStdrVo.getEndPc().compareTo(returnJustBeforeLmeVo.getTopPc()) >= 0) {
				returnVo.setTopPc(nowLmeStdrVo.getEndPc());
				returnVo.setTopMdatPc(nowLmeStdrVo.getEndMdatPc());
			}

			if(nowLmeStdrVo.getEndPc().compareTo(returnJustBeforeLmeVo.getLwetPc()) <= 0) {
				returnVo.setLwetPc(nowLmeStdrVo.getEndPc());
				returnVo.setLwetMdatPc(nowLmeStdrVo.getEndMdatPc());
			}
			
			if(returnVo.getBeginPc().compareTo(returnVo.getTopPc()) > 0) {
				returnVo.setTopPc(returnVo.getBeginPc());
				returnVo.setTopMdatPc(returnVo.getBeginMdatPc());
			}
			
			if(returnVo.getBeginPc().compareTo(returnVo.getLwetPc()) < 0) {
				returnVo.setLwetPc(returnVo.getBeginPc());
				returnVo.setLwetMdatPc(returnVo.getBeginMdatPc());
			}
						
			returnVo.setVersusPc(nowLmeStdrVo.getEndPc().subtract(returnPastLmeMinuteVo.getEndPc()));
			
			// VersusRate = 비교값
			if(returnPastLmeMinuteVo.getEndPc().compareTo(BigDecimal.ZERO) == 0) {
				returnVo.setVersusRate(BigDecimal.ZERO);
			} else {
				returnVo.setVersusRate(((nowLmeStdrVo.getEndPc().subtract(returnPastLmeMinuteVo.getEndPc())).divide(returnPastLmeMinuteVo.getEndPc(), 6, RoundingMode.HALF_UP)).multiply(new BigDecimal(100)));			
			}
		}
		
		if((returnVo.getMetalCode().equals("7") && tickTime.equals("01") || returnVo.getMetalCode().equals("5") && tickTime.equals("01"))) {
			log.info("returnNewLmeVo metalCode: " + returnVo.getMetalCode() + ",returnVO BeginPc: " + returnVo.getBeginPc() +", returnVO EndPc: " + returnVo.getEndPc());
		}
		
		return returnVo;
	}

	private void reCheckLmeSpread(PrLmePcStdrBasVo nowLmeStdrVo) {
		String metalCode = nowLmeStdrVo.getMetalCode();
		try {
			if (!ReciveLmeDataByUdpSocket.errorSpreadMetalCodeList.contains((metalCode)))
				return;

			java.math.BigDecimal leSpread = new BigDecimal("0.0");

			if (nowLmeStdrVo.getSpread() == null) {
				log.info("nowLmeStdrVo.getSpread() is null");
			}
			if (ReciveLmeDataByUdpSocket.leSpreadMap == null) {
				log.info("ReciveLmeDataByUdpSocket.leSpreadMap is null");
			}
			/*****************************/

			if (nowLmeStdrVo.getSpread() == null || ReciveLmeDataByUdpSocket.leSpreadMap == null)
				return;

			leSpread = ReciveLmeDataByUdpSocket.leSpreadMap.get(metalCode);
			log.info("nowSpread value : " + nowLmeStdrVo.getSpread());
			log.info("leSpread value : " + leSpread);
			if (nowLmeStdrVo.getSpread().compareTo(leSpread) == 0) {
				// 스프레드 변동분 재체크
				ValidLmeSpreadDateVo ValidVo = new ValidLmeSpreadDateVo();
				ValidVo.setCmpnyCode("10");

				List<String> cldrTyCodeList = new ArrayList<>();
				cldrTyCodeList.add("1");
				cldrTyCodeList.add("2");
				ValidVo.setLmeCldrTyCodeList(cldrTyCodeList);

				String present = DateUtil.getNowDateTime("yyyyMMdd");
				ValidVo.setPast(restDateTime.calculateDate(present, 14, Operator.MINUS));
				ValidVo.setPresent(present);

				ValidLmeSpreadDateVo returValidVo = etcService.selectValidLmeSpreadDate(ValidVo);

				CalculateSpreadVo vo = new CalculateSpreadVo();
				vo.setMetalCode(getGicName(metalCode).substring(0, 3));
				vo.setDateTime(returValidVo.getApplcDe());
				vo.setGicName(getGicName(metalCode));

				CalculateSpreadVo spreadVo = etcService.selectInterfaceSpread(vo);

				if (spreadVo == null)
					return;

				if (spreadVo.getLcSpread().compareTo(spreadVo.getLeSpread()) == 0) { // 스프레드값 일치하면
					log.info("delete errorSpreadMetalCodeList");

					ReciveLmeDataByUdpSocket.errorSpreadMetalCodeList.remove(metalCode); // 에러 스프레드 리스트에서 해당 메탈코드 삭제
					
					if (ReciveLmeDataByUdpSocket.errorSpreadMetalCodeList.isEmpty()) {
						log.info("errorSpreadMetalCodeList.isEmpty()");
						String rm = "LME 스프레드 변동분 오류";
						restDateTime.deleteRestTime(rm);
						
						restDateTime.initialize();
					}
				}
			}
		}

		catch (Exception e) {
			log.error("reCheckLmeSpread Error: " + e.toString() + " -> message : " + e.getMessage());
		}
	}

	private String getGicName(String value) {
		if (value.equals(metalCodeZn))
			return gicNameZn;
		if (value.equals(metalCodePb))
			return gicNamePb;
		if (value.equals(metalCodeCu))
			return gicNameCu;
		if (value.equals(metalCodeAl))
			return gicNameAl;
		if (value.equals(metalCodeNi))
			return gicNameNi;
		if (value.equals(metalCodeSn))
			return gicNameSn;

		return null;
	}

}
