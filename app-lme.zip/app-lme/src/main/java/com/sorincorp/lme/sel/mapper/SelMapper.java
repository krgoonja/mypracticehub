package com.sorincorp.lme.sel.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.lme.sel.model.PrSelPcStdrBasVo;

public interface SelMapper {

	/**
	 * <pre>
	 * 판매가격 기준 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void insertPrSelPcStdrBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * LME 실시간 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrSelPcRltmBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * LME 가격 01분 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrSelPc01MinBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * Lme 가격 30분 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrSelPc30MinBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * Lme 가격 60분 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrSelPc60MinBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * LME 가격 일 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrSelPcDeBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * LME 가격 주 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrSelPcWeekBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * LME 가격 년 월 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrSelPcYyMtBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * LME 가격 년 분기 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrSelPcYyQuBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * LME 가격 년 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrSelPcYyBas(PrSelPcStdrBasVo vo) throws Exception;
	

	/**
	 * <pre>
	 * 처리내용: PrSelPcStdrBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrSelPcStdrBasVo selectTopPrSelPcStdrBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: PrSelPcRltmBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrSelPcStdrBasVo selectTopPrSelPcRltmBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: PrSelPc01MinBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrSelPcStdrBasVo selectTopPrSelPc01MinBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: PrSelPc30MinBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrSelPcStdrBasVo selectTopPrSelPc30MinBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: PrSelPc60MinBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrSelPcStdrBasVo selectTopPrSelPc60MinBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: PrSelPcDeBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrSelPcStdrBasVo selectTopPrSelPcDeBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: PrSelPcWeekBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrSelPcStdrBasVo selectTopPrSelPcWeekBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: PrSelPcYyMtBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrSelPcStdrBasVo selectTopPrSelPcYyMtBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: PrSelPcYyQuBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrSelPcStdrBasVo selectTopPrSelPcYyQuBas(PrSelPcStdrBasVo vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: PrSelPcYyBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrSelPcStdrBasVo selectTopPrSelPcYyBas(PrSelPcStdrBasVo vo) throws Exception;

	void insertPrSelPcDeBasForProcedure(Map<String, String> map) throws Exception;
	
	void insertPrSelPcWeekBasForProcedure(Map<String, String> map) throws Exception;
	
	void insertPrSelPcYyMtBasForProcedure(Map<String, String> map) throws Exception;
	
	void insertPrSelPcYyQuBasForProcedure(Map<String, String> map) throws Exception;
	
	void insertPrSelPcYyBasForProcedure(Map<String, String> map) throws Exception;
	
	void insertPrSelPc01MinBasForProcedure(Map<String, String> map) throws Exception;
	
	List<PrSelPcStdrBasVo> selectPrSelPc01MinBas(PrSelPcStdrBasVo vo) throws Exception;
	
	List<String> selectMetalCodeList() throws Exception;

}
