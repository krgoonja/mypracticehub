package com.sorincorp.lme.pc.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.pcInfo.model.RvcmpnVO;
import com.sorincorp.lme.pc.model.OpFallNumPcBasVo;
import com.sorincorp.lme.pc.model.OpFallSelPcBasVo;
import com.sorincorp.lme.pc.model.PrLmeEvlPcBasVo;
import com.sorincorp.lme.pc.model.PrLmePblntfPcBasVo;
import com.sorincorp.lme.pc.model.PrLmePcStdrBasVo;
import com.sorincorp.lme.pc.model.SelPrimiumAmountVo;

public interface PcMapper {

	/**
	 * <pre>
	 * LME 기준 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void insertPrLmePcStdrBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * LME 실시간 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePcRltmBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * LME 가격 01분 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePc01MinBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * Lme 가격 30분 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePc30MinBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * Lme 가격 60분 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePc60MinBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * LME 가격 일 테이블 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePcDeBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * LME 가격 주 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePcWeekBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * LME 가격 년 월 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePcYyMtBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * LME 가격 년 분기 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePcYyQuBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * LME 가격 년 저장
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmePcYyBas(PrLmePcStdrBasVo vo) throws Exception;



	/**
	 * <pre>
	 * 처리내용: 가격_LME 공시 가격 기본 저장
	 * </pre>
	 * @date 2021. 11. 2.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 2.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 */
	void insertPrLmePblntfPcBas(PrLmePblntfPcBasVo vo);


	/**
	 * <pre>
	 * 처리내용: 가격_LME 평가 가격 기본 저장
	 * </pre>
	 * @date 2021. 11. 2.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 2.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 */
	void insertPrLmeEvlPcBasVo(PrLmeEvlPcBasVo vo);

	/**
	 * <pre>
	 * 처리내용: PrLmePcStdrBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrLmePcStdrBasVo selectTopPrLmePcStdrBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePcRltmBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrLmePcStdrBasVo selectTopPrLmePcRltmBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePc01MinBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrLmePcStdrBasVo selectTopPrLmePc01MinBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePc30MinBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrLmePcStdrBasVo selectTopPrLmePc30MinBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePc60MinBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrLmePcStdrBasVo selectTopPrLmePc60MinBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePcDeBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrLmePcStdrBasVo selectTopPrLmePcDeBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePcWeekBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrLmePcStdrBasVo selectTopPrLmePcWeekBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePcYyMtBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrLmePcStdrBasVo selectTopPrLmePcYyMtBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePcYyQuBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrLmePcStdrBasVo selectTopPrLmePcYyQuBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: PrLmePcYyBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrLmePcStdrBasVo selectTopPrLmePcYyBas(PrLmePcStdrBasVo vo) throws Exception;


	/**
	 * <pre>
	 * 처리내용: PrLmePblntfPcBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrLmePblntfPcBasVo selectTopPrLmePblntfPcBas(PrLmePblntfPcBasVo vo) throws Exception;


	/**
	 * <pre>
	 * 처리내용: PrLmeEvlPcBas 테이블의 최신값 하나를 가져와서 Bean에 저장
	 * </pre>
	 * @date 2021. 11. 8.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 8.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrLmeEvlPcBasVo selectTopPrLmeEvlPcBas(PrLmeEvlPcBasVo vo) throws Exception;

	void insertPrLmePcDeBasForProcedure(Map<String, String> map) throws Exception;

	void insertPrLmePcWeekBasForProcedure(Map<String, String> map) throws Exception;

	void insertPrLmePcYyMtBasForProcedure(Map<String, String> map) throws Exception;

	void insertPrLmePcYyQuBasForProcedure(Map<String, String> map) throws Exception;

	void insertPrLmePcYyBasForProcedure(Map<String, String> map) throws Exception;

	void deletePrLmeSelOldDataProcedure() throws Exception;

	/**
	 * <pre>
	 * 월단위 일자별 누적평균가 현황 테이블에 데이터조회한 데이터 저장
	 * </pre>
	 * @date 2022. 10. 31.
	 * @author hyunjin05
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 10. 31.		hyunjin05		최초작성
	 * 2022. 12. 23.		jdrttl			프로시저로 변경
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void insertStEvemthAccmlDalyAvgPcBas() throws Exception;

	/**
	 * <pre>
	 * 조달청 대비 가격하락 비교
	 * </pre>
	 * @date 2023. 04. 27.
	 * @author srec0068
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 04. 27.		srec0068		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	List<OpFallSelPcBasVo> selectFallSelPc() throws Exception;

	/**
	 * <pre>
	 * 판매가격 하락일자 업데이트
	 * </pre>
	 * @date 2023. 04. 27.
	 * @author srec0068
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 04. 27.		srec0068		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void updateFallSelPcBas(String fallSeqNo) throws Exception;

	/**
	 * <pre>
	 * 금속권한 설정된 회원 번호 조회
	 * </pre>
	 * @date 2023. 04. 28.
	 * @author srec0068
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 04. 28.		srec0068		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	List<Map<String, String>> selectMemberSmsByMetalCode(String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 조달청 가격 조회
	 * </pre>
	 * @date 2023. 5. 23.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 5. 23.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<RvcmpnVO> selectItRvcmpnPcManageBas() throws Exception;
		
	/**
	 * <pre>
	 * 처리내용: 판매가격 하락 조회
	 * </pre>
	 * @date 2023. 5. 23.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 5. 23.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<OpFallSelPcBasVo> selectFallSelPcBas() throws Exception;
	
	
	/**
	 * <pre>
	 * 처리내용: 프리미엄 가격 조회
	 * </pre>
	 * @date 2023. 5. 23.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 5. 23.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<SelPrimiumAmountVo> selectSelPremiumAmount() throws Exception;

	/**
	 * <pre>
	 * 처리내용 : 시초가 가격 비교 데이터 조회
	 * </pre>
	 * @date 2023. 06. 29.
	 * @author bok3117
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 06. 29.		bok3117			최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	List<OpFallNumPcBasVo> selectFallNumPc() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 과거 LME 데이터 조회
	 * </pre>
	 * @date 2023. 7. 31.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 31.			srec0064			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	PrLmePcStdrBasVo selectPastLmePc(Map<String, String> map) throws Exception;

	/**
	 * <pre>
	 * 처리내용: LME 조정 가격 기준 테이블 저장
	 * </pre>
	 * @date 2024. 8. 13.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 8. 13.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmeMdatPcStdrBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: LME 조정 가격 실시간 테이블 저장
	 * </pre>
	 * @date 2024. 8. 13.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 8. 13.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmeMdatPcRltmBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: LME 조정 가격 01분 테이블 저장
	 * </pre>
	 * @date 2024. 8. 13.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 8. 13.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmeMdatPc01MinBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: LME 조정 가격 30분 테이블 저장
	 * </pre>
	 * @date 2024. 8. 13.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 8. 13.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmeMdatPc30MinBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: LME 조정 가격 60분 테이블 저장
	 * </pre>
	 * @date 2024. 8. 13.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 8. 13.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmeMdatPc60MinBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: LME 조정 가격 일 테이블 저장
	 * </pre>
	 * @date 2024. 8. 13.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 8. 13.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmeMdatPcDeBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: LME 조정 가격 주 테이블 저장
	 * </pre>
	 * @date 2024. 8. 13.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 8. 13.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmeMdatPcWeekBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: LME 조정 가격 년 월 저장
	 * </pre>
	 * @date 2024. 8. 13.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 8. 13.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmeMdatPcYyMtBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: LME 조정 가격 년 분기 저장
	 * </pre>
	 * @date 2024. 8. 13.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 8. 13.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmeMdatPcYyQuBas(PrLmePcStdrBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: LME 조정 가격 년 저장
	 * </pre>
	 * @date 2024. 8. 13.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 8. 13.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertPrLmeMdatPcYyBas(PrLmePcStdrBasVo vo) throws Exception;
}
