package com.sorincorp.lme.util;

public class ChartEhgtConst {
	/* 차트용 환율 RFS   */
	public final static int RECV_SYBOL_LEN = 10;				/*	통화 symbol	S	10	DH_ID, PROD_CD, PAIR_ID 	DZZSPTUSD/KRW	Symbol	*/
																													/*	DZZ 는 고정			*/
	public final static int RECV_QT_DT_LEN = 8;					/*	발생일	S	8	YYYYMMDD		QT_DT	*/
	public final static int RECV_QT_TM_LEN = 6;					/*	발생시간	S	6	HHMMSS	 	QT_TM	*/
	public final static int RECV_QT_SEQ_LEN = 9;				/*	발생순서	S	9	1		QT_SEQ	*/
	public final static int RECV_DH_RATE_LEN = 3;				/*	MID 환율 	S	3	 현재가	 	DH_RATE	*/
	public final static int RECV_DH_RATE_CLS_LEN = 1;			/*	전일 대비 UP DOWN	S	1	상승  = 2 , 보합  =3   하락 = 4		DH_RATE_CLS	*/
	public final static int RECV_DH_RATE_NETCHG_LEN = 10;		/*	전일대비		10.5	전일대비  환율 차이		 DH_RATE_NETCHG	*/
	public final static int RECV_DH_RATE_OPEN_LEN = 10;			/*	시가	N	10.5	당일기준 시가		DH_RATE_OPEN	*/
	public final static int RECV_DH_RATE_HIGH_LEN = 10;			/*	고가	N	10.5	 당일기준 고가		DH_RATE_HIGH	*/
	public final static int RECV_DH_RATE_LOW_LEN = 10;			/*	저가	N	10.5	당일기준 저가		DH_RATE_LOW	*/
}
