package com.sorincorp.lme.util;

import org.springframework.context.ApplicationContext;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BeanUtils {
	public static String getProperty(String propertyName) {
		return getProperty(propertyName, null);
	}

	public static String getProperty(String propertyName, String defaultValue) {
		String value = defaultValue;
		ApplicationContext applicationContext = ApplicationContextProvider.getApplicationContext();
		if (applicationContext.getEnvironment().getProperty(propertyName) == null) {
			log.warn(propertyName + " properties was not loaded.");
		} else {
			value = applicationContext.getEnvironment().getProperty(propertyName).toString();
		}
		return value;
	}

	public static Object getBean(String bean) {
		ApplicationContext applicationContext = ApplicationContextProvider.getApplicationContext();
		if( applicationContext == null ) {
            throw new NullPointerException("Spring의 benan 초기화 안됨");
        }

		return applicationContext.getBean(bean);
	}

	public static Object getBean(Class<?> classType) {
	    ApplicationContext applicationContext = ApplicationContextProvider.getApplicationContext();
		if( applicationContext == null ) {
            throw new NullPointerException("Spring의 benan 초기화 안됨");
        }

	    return applicationContext.getBean(classType);
	}
}