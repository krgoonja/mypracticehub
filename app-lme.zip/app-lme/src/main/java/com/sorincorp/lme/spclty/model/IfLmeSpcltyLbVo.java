package com.sorincorp.lme.spclty.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class IfLmeSpcltyLbVo  implements Serializable{
	   /**
	 * 
	 */
	private static final long serialVersionUID = -1557400184149675944L;
	/**
     * 수신일시
    */
    private String receptDatetime;
    /**
     * 전문타입
    */
    private String type;
    /**
     * 종목코드(삼성선물용)
    */
    private String gicName;
    /**
     * 종목코드(로이터)
    */
    private String ricName;
    /**
     * 선물현물스프레드구분
    */
    private String kind;
    /**
     * 만기일자
    */
    private String expirDate;
    /**
     * 최종거래일자
    */
    private String lastDate;
    /**
     * 품목코드
    */
    private String metalCode;
    /**
     * 거래소
    */
    private String marketCode;
    /**
     * 현재가
    */
    private String now;
    /**
     * 시가
    */
    private String start;
    /**
     * 고가
    */
    private String high;
    /**
     * 저가
    */
    private String low;
    /**
     * 영국영업일자
    */
    private String tradeDate;
    /**
     * 전영업일자
    */
    private String prevDate;
    /**
     * 현물만기일자
    */
    private String cashExpirDate;
    /**
     * 수신일자
    */
    private String receptDate;
    /**
     * 수신시각
    */
    private String receptTime;
}