package com.sorincorp.lme.ehgt.mapper;

import com.sorincorp.lme.ehgt.model.PrEhgtPcStdrBasVo;

public interface EhgtMapper {

	/**
	 * <pre>
	 * 처리내용: 가격_환율 가격 기준 기본 테이블(PR_EHGT_PC_STDR_BAS) 에서 제일 최신 정보를 가져온다.
	 * </pre>
	 * @date 2021. 11. 7.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 7.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	PrEhgtPcStdrBasVo selectTopPrEhgtPcStdrBas() throws Exception;
	
}
