package com.sorincorp.lme.util;

public class FshgConst {
	public final static String HANAFX_DATE_FORMAT1 = "yyyyMMdd";
	public final static String HANAFX_DATE_FORMAT2 = "HHmmss";

	public final static String MSG_TYPE = "I";

	public final static String SEND_MSG_SVC = "AS";
	public final static String SEND_INT_ID = "API_TRD_SND";
	public final static String RECV_INT_ID = "API_TRD_RCV";
	public final static String REQ_TP_NEW_ORDER = "NO";             /* 요청메세지 :신규주문 */
	public final static String REQ_TP_CNCL_ORDER = "CO";             /* 요청메세지 :취소주문 */
	public final static String STAT_TP_UNPROCESSED   = "1";         /* 처리 상태 : 1: 미처리 */
	public final static String STAT_TP_PROCESS_COMPT = "2";         /* 처리 상태 : 2: 처리완료 */

	/* 신규 주문 */
	public final static String SEND_NEW_MSG_TP = "ON";			  /*	주문 유형	2	신규 	ON	*/
	public final static String SEND_NEW_TIF = "FOK";                /*	주문 보조조건	3	Full match or kill	FOK	*/


	public final static int SEND_NEW_MSG_TP_LEN = 2;              /*	주문 유형	2	신규 	ON	*/
	public final static int SEND_NEW_CLI_ORD_NO_LEN = 30;         /*	고객사 주문번호	30	 고객사의 FIX client 의 주문 번호	FXSPT2021010100001	*/
	public final static int SEND_NEW_PROD_CD_LEN = 3;            /*	상품코드	3	상품 코드  (현물환, 선물환,자유만기/ FX 스왑 )	SPT,FWD,FFF, FXS	*/
	public final static int SEND_NEW_PAIR_ID_LEN = 7;            /*	거래 통화 코드	7	USD/KRW, EUR/KRW 등의 거래통화 코드		*/
	public final static int SEND_NEW_VAL_DT_LEN = 8;             /*	Near 결제일	8	결제일 1	20210312	*/
	public final static int SEND_NEW_MAT_DT_LEN = 8;             /*	Far   결제일 	8	결제일 2	20210320	*/
	public final static int SEND_NEW_CURR_CD_LEN = 3;            /*	거래 통화	3	거래 기준 통화  CUR1 또는 CUR2	USD ,   KRW,  EUR ..	*/
	public final static int SEND_NEW_NEAR_AMT_LEN = 20;           /*	near amount1	20	Near 주문 금액  (CURR_CD 기준)	1000000	*/
	public final static int SEND_NEW_FAR_AMT_LEN = 20;            /*	Far  amount	20	Far 주문 금액 (Swap only)		*/
	public final static int SEND_NEW_BS_TP_LEN = 1;              /*	매수/매도 구분	1	B= buy  S=매도	B / O	*/
	public final static int SEND_NEW_COND_TP_LEN = 1;            /*	주문 조건	1	시장가 및 호가지정 조건 	M= 시장가 L= 호가지정 	*/
	public final static int SEND_NEW_TIF_LEN = 3;                /*	주문 보조조건	3	Full match or kill	FOK	*/
	public final static int SEND_NEW_LIM_PX_LEN = 20;             /*	주문 가격 	15	Order price	123.12	*/
	public final static int QT_IDX_LEN = 30;                      /*	환율 index 	100	실시간 제공 환율 의 건별 INDEX (주문 당시)	SPTEUR/USDXXX_2021123123123 	*/
	public final static int SEND_NEW_ENTER_TM_LEN = 25;           /*	요청시간	25	YYYYMMDDHHMMSSMS	2.02103E+15	*/


//	/* 주문 취소 */
//	public final static String SEND_CNCL_MSG_TP = "OC";            /*	주문 유형	2	취소 	OC	*/
//
//	public final static int SEND_CNCL_MSG_TP_LEN = 2;            /*	주문 유형	2	취소 	OC	*/
//	public final static int SEND_CNCL_CLI_ORD_NO_LEN = 30;        /*	고객사 주문번호	30	 고객사의 FIX client 의 주문 번호	FXSPT2021010100002	*/
//	public final static int SEND_CNCL_ORG_CLI_ORD_NO_LEN = 30;    /*	고객사 원주문번호	30	 취소 주문인 경우 	FXSPT2021010100001	*/
//	public final static int SEND_CNCL_ORG_ORD_NO_LEN = 20;        /*	은행 원 주문 번호	20	  취소 주문인 경우 은행 원 주문 번호	20200102_1234	*/
//	public final static int SEND_CNCL_PROD_CD_LEN = 3;           /*	상품코드	3	상품 코드  (현물환, 선물환,자유만기/ FX 스왑 )	SPT,FWD,FFF, FXS	*/
//	public final static int SEND_CNCL_PAIR_ID_LEN = 7;           /*	거래 통화 코드	7	USD/KRW, EUR/KRW 등의 거래통화 코드		*/
//	public final static int SEND_CNCL_BS_TP_LEN = 1;             /*	매수/매도 구분	1	B= buy  S=매도	B / O	*/
//	public final static int SEND_CNCL_ENTER_TM_LEN = 25;          /*	요청시간	25	YYYYMMDDHHMMSSMS	2.02103E+16 */

	/* 주문 응답 */
	public final static String RECV_ACPT_TP_ACPT  	= "0";          /* 접수상태 - 0: 주문 접수, 2: 주문 체결, 4: 주문 취소, 8=주문 거부 */
	public final static String RECV_ACPT_TP_OK  	= "2";
	public final static String RECV_ACPT_TP_CNCL  	= "4";
	public final static String RECV_ACPT_TP_RJCT  	= "8";

	public final static String RECV_TIF = "FOK";                    /*	주문 보조 조건	3	Full or kill match	FOK	*/

	public final static int RECV_MSG_TP_LEN = 2;                 /*	Msg 유형	2	주문 접수 / TICKET 	AO / AT	*/
	public final static int RECV_CLI_ORD_NO_LEN = 30;             /*	고객사 주문번호	30	 고객사의 FIX client 의 주문 번호	FXSPTX971235123123	*/
	public final static int RECV_CLI_ORG_ORD_NO_LEN = 30;         /*	고객사 원주문번호	30	 취소 주문인 경우 고객사의 FIX client 의 원주문 번호	FXSPTX971235123123	*/
	public final static int RECV_ORD_NO_LEN = 20;                 /*	은행  주문 번호	20	 은행 주문 접수 번호	20200102_1234	*/
	public final static int RECV_ORD_TP_LEN = 1;                 /*	주문 구분 	1	신규  / 취소 	N / C	*/
	public final static int RECV_PROD_CD_LEN = 3;                /*	상품코드	3	상품 코드  (현물환, 선물환  /  자유만기 선물환, FX 스왑 )	SPT,FWD,FFF, FXS	*/
	public final static int RECV_PAIR_ID_LEN = 7;                /*	거래 통화 코드	7	USD/KRW, EUR/KRW 등의 거래통화 코드		*/
	public final static int RECV_VAL_DT_LEN = 8;                 /*	Near 결제일	8	결제일 1	20210312	*/
	public final static int RECV_MAT_DT_LEN = 8;                 /*	Far   결제일 	8	결제일 2	20210320	*/
	public final static int RECV_CURR_CD_LEN = 3;                /*	거래통화	3	Amount 기준 통화		*/
	public final static int RECV_CUST_ID_LEN = 10;                /*	고객사 딜러 ID	10	고객사 code (은행 기준)  		*/
	public final static int RECV_BS_TP_LEN = 1;                  /*	매수/매도 구분	1	B= buy,  S=매도	B / S	*/
	public final static int RECV_COND_TP_LEN = 1;                /*	주문 조건	1	M= 시장가 L=지정가	 	*/
	public final static int RECV_LIM_PX_LEN = 15;                 /*	주문 가격 	15	Order price	123.12	*/

	public final static int RECV_TIF_LEN = 3;                   /*	주문 보조 조건	3	Full or kill match	FOK	*/
	public final static int RECV_ORD_AMT_LEN = 20;                /*	주문 금액	20.5		100000	*/
	public final static int RECV_TKT_AMT_LEN = 20;                /*	체결금액	20.5	체결시 ORD_AMT1 과 동일	100000	*/
	public final static int RECV_REM_AMT_LEN = 20;                /*	미체결 금액	20.5	near 미체결 금액	0	*/
	public final static int RECV_ACPT_TP_LEN = 1;                /*	접수상태	1	1: 주문 접수, 2: 주문 체결, 4: 주문 취소, 8=주문 거부		*/
	public final static int RECV_TKT_NO_LEN = 20;                 /*	Ticket 번호	20	체결 번호	2.02105E+12	*/
	public final static int RECV_NEAR_RATE_LEN = 15;              /*	Near 환율	15.5	Spt, fwd  거래 환율 및 swap near 환율		*/
	public final static int RECV_NEAR_AMT_LEN = 20;               /*	Near  금액	20.5	Spt, fwd  거래 금액 및 swap near 금액		*/
	public final static int RECV_FAR_RATE_LEN = 15;               /*	far 환율	15.5	 Swap 에서만 사용		*/
	public final static int RECV_FAR_AMT_LEN = 20;                /*	far  금액	20.5	Swap 에서만 사용		*/
	public final static int RECV_RET_TEXT_LEN = 200;               /*	응답 MSG	200	API 에서 제공된 message		*/
}
