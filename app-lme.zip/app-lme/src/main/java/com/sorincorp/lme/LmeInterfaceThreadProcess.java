package com.sorincorp.lme;

import javax.annotation.PreDestroy;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import ch.qos.logback.classic.LoggerContext;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class LmeInterfaceThreadProcess {
	public static boolean LMEINTERFACE_ENABLE = false;

	@Autowired
	private ReciveLmeDataByUdpSocket reciveLmeDataByUdpSocket;
	
	@Autowired
	private ThreadPoolTaskExecutor lmeThreadPoolExcuter;
	
	public void start() {
		try {
		if(LMEINTERFACE_ENABLE) {
			log.info("####################### This LmeInterfaceThreadProcess App has already started. #####################");
			return;
		}
			reciveLmeDataByUdpSocket.startReciveSocketData();
			LMEINTERFACE_ENABLE = true;
		} catch(Exception e) {
			log.info("####################### This LmeInterfaceThreadProcess App End. #####################");
		}
	}
	
	@PreDestroy
	private void interruptedThread() {
		reciveLmeDataByUdpSocket.socketClose();
		reciveLmeDataByUdpSocket.setSocketReciveRun(false);
		lmeThreadPoolExcuter.shutdown();
		
		log.info("####################### Interrupted thread #######################");
		
		LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
		loggerContext.stop();
	}
}