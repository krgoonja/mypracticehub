package com.sorincorp.lme.pc.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class OpFallNumPcBasVo implements Serializable {
	/**
	* 
	*/
	private static final long serialVersionUID = -8058827907884144262L;
	
	/**
	 * 시초가 구분 코드
	 */
	private String startPriceYn;
	
	/**
	 * SMS 전송 구분 코드
	 */
	private String smsSendYn;
	
	/**
	 * 메인코드
	 */
	private String mainCode;
	
	/**
	 * 서브코드
	 */
	private String subCode;
	
	/**
	 * 코드명
	 */
	private String codeNm;
	
	/**
	 * 코드 참조1
	 */
	private String codeRefrnone;
	
	/**
	 * 코드 숫자 참조1 (기준 가격 설정)
	 */
	private String codeNumberRefrnone;
	
	/**
	 * 코드 숫자 참조2 (대권역 지정)
	 */
	private String codeNumberRefrntwo;
	
	/**
	 * 메탈명
	 */
	private String codeChrctrRefrnsix;

}
