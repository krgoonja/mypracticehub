package com.sorincorp.lme.spclty.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class IfLmeSpcltyLsVo implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = -486282343109684272L;
	/**
     * 수신일시
    */
    private String receptDatetime;
    /**
     * 전문타입
    */
    private String type;
    /**
     * 품목코드
    */
    private String metalCode;
    /**
     * 종목코드(로이터)
    */
    private String ricName;
    /**
     * 선물현물스프레드구분
    */
    private String kind;
    /**
     * 영국영업일자
    */
    private String tradeDate;
    /**
     * 초기재고
    */
    private String initialStock;
    /**
     * 반입
    */
    private String inputStock;
    /**
     * 반출
    */
    private String ouputStock;
    /**
     * 최종재고
    */
    private String currentStock;
    /**
     * 전일대비
    */
    private String stockNetchng;
    /**
     * OnWrnt
    */
    private String onwrnt;
    /**
     * CnclWrnt
    */
    private String cnclwrnt;
}