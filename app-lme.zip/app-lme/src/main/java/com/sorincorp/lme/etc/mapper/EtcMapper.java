package com.sorincorp.lme.etc.mapper;

import com.sorincorp.lme.etc.model.CalculateSpreadVo;
import com.sorincorp.lme.etc.model.ClosedHoursVo;
import com.sorincorp.lme.etc.model.TodaySpreadVO;
import com.sorincorp.lme.etc.model.ValidLmeSpreadDateVo;

public interface EtcMapper {


	/**
	 * <pre>
	 * 처리내용: 휴식 시간을 등록한다.
	 * </pre>
	 * @date 2022. 1. 17.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 17.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void insertItHvofTimeManageBas(ClosedHoursVo closedHoursVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 휴식시간 등록 히스토리
	 * </pre>
	 * @date 2022. 1. 17.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 17.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void insertItHvofTimeManageBasHst(ClosedHoursVo closedHoursVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: BO의 LME 신호등 상태값을 바꾼다.
	 * </pre>
	 * @date 2022. 1. 27.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 27.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param status
	 */
	void updateCntcStts(int status);


	/**
	 * <pre>
	 * 처리내용: 계산된 spread값을 가져온다.
	 * </pre>
	 * @date 2022. 3. 15.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 3. 15.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 */
	CalculateSpreadVo selectInterfaceSpread(CalculateSpreadVo vo);


	/**
	 * <pre>
	 * 처리내용: 가능한 spread값을 가져올 수 있는 날짜에 대한 정보를 가져온다.
	 * </pre>
	 * @date 2022. 5. 12.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 12.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 */
	ValidLmeSpreadDateVo selectValidLmeSpreadDate(ValidLmeSpreadDateVo vo);

	/**
	 * <pre>
	 * 처리내용: 휴식시간 삭제
	 * </pre>
	 * @date 2022. 6. 16.
	 * @author srec0064
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 6. 16.		srec0064		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void deleteItHvofTimeManageBas(ClosedHoursVo closedHoursVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: LME 데이터 오류 시간을 체크한다
	 * </pre>
	 * @date 2022. 7. 26.
	 * @author srec0064
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 26.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param closedHoursVo
	 * @return
	 * @throws Exception
	 */
	int getGapTime(ClosedHoursVo closedHoursVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: Spread 삽입 기능 활성화 여부 및 값 가져오기
	 * </pre>
	 * @date 2022. 11. 03.
	 * @author jdrttl
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 11. 03.		jdrttl				최초작성
	 * ------------------------------------------------
	 * @param TodaySpreadVO
	 * @return TodaySpreadVO
	 * @throws Exception
	 */
	TodaySpreadVO getTodaySpread(TodaySpreadVO todaySpreadVO) throws Exception;
}
