package com.sorincorp.lme.util;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;

import org.springframework.stereotype.Component;

@Component
public class TimerUtils {
	private final long offset;

	private static long calculateOffset() {
		final long nano = System.nanoTime();
		final long nanoFromMilli = System.currentTimeMillis() * 1_000_000;
		return nanoFromMilli - nano;
	}

	public TimerUtils() {
		final int count = 500;
		BigDecimal offsetSum = BigDecimal.ZERO;
		for (int i = 0; i < count; i++) {
			offsetSum = offsetSum.add(BigDecimal.valueOf(calculateOffset()));
		}
		offset = (offsetSum.divide(BigDecimal.valueOf(count), 6, BigDecimal.ROUND_CEILING)).longValue();
	}

	public long nowNano() {
		return offset + System.nanoTime();
	}

	public long nowMicro() {
		return (offset + System.nanoTime()) / 1000;
	}

	public long nowMilli() {
		//return System.currentTimeMillis();
		return (offset + System.nanoTime()) / 1000000;
	}
	
	public String nowNanoStr() {
		long now = nowNano();
		String dateTime = new SimpleDateFormat("yyyyMMddHHmmss").format(now / 1000000);
		String subTime = String.format("%09d", now);
		return dateTime + subTime;
	}

	public String nowMicroStr() {
		long now = nowMicro();
		String dateTime = new SimpleDateFormat("yyyyMMddHHmmss").format(now / 1000);
		String subTime = String.format("%06d", now);
		return dateTime + subTime;
	}

	public String nowMilliStr() {
		long now = nowMilli();
		String dateTime = new SimpleDateFormat("yyyyMMddHHmmss").format(now);
		String subTime = String.format("%03d", now);
		return dateTime + subTime;
	}
}
