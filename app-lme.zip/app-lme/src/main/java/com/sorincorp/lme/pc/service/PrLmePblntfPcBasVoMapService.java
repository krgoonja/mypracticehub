package com.sorincorp.lme.pc.service;

import com.sorincorp.lme.pc.model.PrLmePblntfPcBasVo;

public interface PrLmePblntfPcBasVoMapService {
	
	PrLmePblntfPcBasVo getPrLmePblntfPcBasVo(String metalCodeByProperties);
}