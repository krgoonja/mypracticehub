package com.sorincorp.lme.pc.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.sorincorp.lme.pc.model.PrLmePcStdrBasVo;

@Service
public class PrLmePcStdrBasVoMapServiceImpl implements PrLmePcStdrBasVoMapService{

	private Map<String, Map<String, PrLmePcStdrBasVo>> prLmePcStdrBasVoMap;
	private Map<String, PrLmePcStdrBasVo> prLmePcStdrBasVo;

	public PrLmePcStdrBasVoMapServiceImpl() {
		if(prLmePcStdrBasVoMap == null) {
			this.prLmePcStdrBasVoMap = new HashMap<String, Map<String, PrLmePcStdrBasVo>>();
		}
		
		if(prLmePcStdrBasVo == null) {
			this.prLmePcStdrBasVo = new HashMap<String, PrLmePcStdrBasVo>();
		}
	}

	public PrLmePcStdrBasVo getPrLmePcStdrBasVo(String metalCodeByProperties, String prPcStdrBasVoConstant) {

		if(!prLmePcStdrBasVoMap.containsKey(metalCodeByProperties)) {
			prLmePcStdrBasVoMap.put(metalCodeByProperties, new HashMap<String, PrLmePcStdrBasVo>());
		}

		if(!prLmePcStdrBasVoMap.get(metalCodeByProperties).containsKey(prPcStdrBasVoConstant)) {
			prLmePcStdrBasVoMap.get(metalCodeByProperties).put(prPcStdrBasVoConstant, new PrLmePcStdrBasVo());
		}

		return prLmePcStdrBasVoMap.get(metalCodeByProperties).get(prPcStdrBasVoConstant);
	}
	
	@Override
	public PrLmePcStdrBasVo getPrLmePcStdrBasVo(String prPcStdrBasVoConstant) {
		if(!prLmePcStdrBasVo.containsKey(prPcStdrBasVoConstant))
			prLmePcStdrBasVo.put(prPcStdrBasVoConstant, new PrLmePcStdrBasVo());
		return prLmePcStdrBasVo.get(prPcStdrBasVoConstant);
	}

	public void clearPrLmePcStdrBasVo() {
		prLmePcStdrBasVoMap = new HashMap<String, Map<String, PrLmePcStdrBasVo>>();
		prLmePcStdrBasVo = new HashMap<String, PrLmePcStdrBasVo>();
	}

}