package com.sorincorp.lme.pc.service;

import com.sorincorp.lme.pc.model.PrLmePcStdrBasVo;

public interface PrLmePcStdrBasVoMapService {
	
	PrLmePcStdrBasVo getPrLmePcStdrBasVo(String metalCodeByProperties, String prPcStdrBasVoConstant);
	
	PrLmePcStdrBasVo getPrLmePcStdrBasVo(String prPcStdrBasVoConstant);
	
	void clearPrLmePcStdrBasVo();
}