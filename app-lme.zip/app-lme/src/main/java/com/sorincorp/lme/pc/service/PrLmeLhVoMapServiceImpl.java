package com.sorincorp.lme.pc.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.sorincorp.lme.spclty.model.IfLmeSpcltyLhVo;

@Service
public class PrLmeLhVoMapServiceImpl implements PrLmeLhVoMapService{

	private Map<String, IfLmeSpcltyLhVo> IfLmeSpcltyLhVoMap;

	public PrLmeLhVoMapServiceImpl() {
		if(IfLmeSpcltyLhVoMap == null) {
			this.IfLmeSpcltyLhVoMap = new HashMap<String, IfLmeSpcltyLhVo>();
		}
	}

	public IfLmeSpcltyLhVo getPrLmeSpcltyLhBasVo(String metalCodeByProperties, String prPcStdrBasVoConstant) {

		if(!IfLmeSpcltyLhVoMap.containsKey(metalCodeByProperties)) {
			IfLmeSpcltyLhVoMap.put(metalCodeByProperties, new IfLmeSpcltyLhVo());
		}

		return IfLmeSpcltyLhVoMap.get(metalCodeByProperties);
	}

//	public void clearPrLmePcStdrBasVo() {
//		IfLmeSpcltyLhVoMap = new HashMap<String, Map<String, IfLmeSpcltyLhVo>>();
//	}

}