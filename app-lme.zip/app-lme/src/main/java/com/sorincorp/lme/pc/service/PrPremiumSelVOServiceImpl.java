package com.sorincorp.lme.pc.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.sorincorp.comm.pcInfo.model.PrPremiumSelVO;

@Service
public class PrPremiumSelVOServiceImpl implements PrPremiumSelVOService {
	Map<String, List<PrPremiumSelVO>> prPremiumSelVOListMap;
	
	public PrPremiumSelVOServiceImpl() {
		if(prPremiumSelVOListMap == null) {
			this.prPremiumSelVOListMap = new HashMap<String, List<PrPremiumSelVO>>();
		}
	}

	@Override
	public Map<String, List<PrPremiumSelVO>> getPrPremiumSelVOMap() {
		return prPremiumSelVOListMap;
	}

	@Override
	public List<PrPremiumSelVO> getPrPremiumSelVOMap(String metalCode) {
		if(!prPremiumSelVOListMap.containsKey(metalCode))
			prPremiumSelVOListMap.put(metalCode, new ArrayList<PrPremiumSelVO>());
		return prPremiumSelVOListMap.get(metalCode);
	}

	@Override
	public void setPrPremiumSelVOMap(String metalCode, List<PrPremiumSelVO> prPremiumSelVOMap) {
		this.prPremiumSelVOListMap.put(metalCode, prPremiumSelVOMap);
	}
}
