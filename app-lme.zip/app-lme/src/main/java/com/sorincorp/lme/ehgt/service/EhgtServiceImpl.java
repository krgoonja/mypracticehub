package com.sorincorp.lme.ehgt.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.lme.ehgt.mapper.EhgtMapper;
import com.sorincorp.lme.ehgt.model.PrEhgtPcStdrBasVo;

@Service
public class EhgtServiceImpl implements EhgtService {
	
	@Autowired
	private EhgtMapper ehgtMapper;
	
	private final PrEhgtPcStdrBasVoService prEhgtPcStdrBasVoService;
	
	@Autowired
	public EhgtServiceImpl(PrEhgtPcStdrBasVoService prEhgtPcStdrBasVoService) {
		this.prEhgtPcStdrBasVoService = prEhgtPcStdrBasVoService;
	}
	
	@Override
	public void selectTopPrEhgtPcStdrBas() throws Exception {
		PrEhgtPcStdrBasVo vo = ehgtMapper.selectTopPrEhgtPcStdrBas();
		BeanUtils.copyProperties(vo, prEhgtPcStdrBasVoService.getPrEhgtPcStdrBasVo());
	}
}