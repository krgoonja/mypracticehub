package com.sorincorp.lme.ehgt.service;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.sorincorp.lme.ehgt.model.PrEhgtPcStdrBasVo;

@Component
public class ReturnNewEhgtVo {
	
    public PrEhgtPcStdrBasVo process_CopyNewVo (PrEhgtPcStdrBasVo vo) throws Exception {
    	PrEhgtPcStdrBasVo returnVo = new PrEhgtPcStdrBasVo();
		BeanUtils.copyProperties(vo, returnVo);
		
		return returnVo;
    }
    
}
