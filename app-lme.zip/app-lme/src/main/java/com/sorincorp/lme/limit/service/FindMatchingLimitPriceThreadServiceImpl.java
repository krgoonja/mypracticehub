package com.sorincorp.lme.limit.service;

import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.limit.service.LimitService;
import com.sorincorp.comm.limit.service.OrLimitOrderBasVoMapService;
import com.sorincorp.comm.order.model.CommLimitOrderQueueMsgVO;
import com.sorincorp.comm.order.model.CommLimitOrderRedisMsgVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderQueueMsgVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderRedisMsgVO;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.premium.service.ItPremiumStdrBasVoService;
import com.sorincorp.lme.ReciveLmeDataByUdpSocket;
import com.sorincorp.lme.sel.model.PrSelPcStdrBasVo;
import com.sorincorp.lme.util.RestDateTime;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FindMatchingLimitPriceThreadServiceImpl implements FindMatchingLimitPriceThreadService {
	@Autowired
	private LimitService limitService;
	
	@Autowired
	private RestDateTime restDateTime;
	
	@Autowired
	private OrLimitOrderBasVoMapService orderLimitOrderBasVoMapService;
	
	@Autowired
	private ItPremiumStdrBasVoService itPremiumStdrBasVoService;
	
	@Async("lmeThreadPoolExcuter")
	@Override
	public void findMatchingLimitPriceThread(PrSelPcStdrBasVo returnSelStdrVo) throws Exception {
		// PrSelPcStdrBasVo 타입의 값들을 PrSelVO에 복사 TODO [pje] 제대로 복사되는지 확인
		PrSelVO prSelVo = new PrSelVO();
		try {
			BeanUtils.copyProperties(returnSelStdrVo, prSelVo);
			checkLimitData(prSelVo);
			checkPrvsnlLimitData(prSelVo);
		} catch(Exception e) {
			log.error("findMatchingLimitPriceThread function error : " + ExceptionUtils.getStackTrace(e));
		}
	}
	
	private synchronized void checkLimitData(PrSelVO prSelVo) throws Exception {
		if(restDateTime.isSorinRltmWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			// 1) 큐 레이아웃에 맞는 데이터 설정
			CommLimitOrderQueueMsgVO queueVo = new CommLimitOrderQueueMsgVO();
			queueVo.setLimitOrderRequestDt("" + prSelVo.getOccrrncDe() + prSelVo.getOccrrncTime());	// 지정가 주문 요청 일시
			queueVo.setSlePcRltmSn(prSelVo.getSlePcRltmSn());										// 판매 가격 실시간 순번
			queueVo.setLmePcRltmSn(prSelVo.getLmePcRltmSn());										// LME 가격 실시간 순번
			queueVo.setLme3m(prSelVo.getThreemonthLmePc());											// LME 3M
			queueVo.setLmeCash(prSelVo.getLmePc());													// LME 현금
			queueVo.setLmeMdatCffcnt(prSelVo.getLmeMdatCffcnt());									// LME 조정계수
			queueVo.setEhgtPcRltmSn(prSelVo.getEhgtPcRltmSn());										// 환율 가격 실시간 순번
			queueVo.setSpex(prSelVo.getEhgtPc());													// 환율 가격
			queueVo.setSpexMdatCffcnt(prSelVo.getFxMdatCffcnt());									// 환율 조정계수
			
			log.debug("3-0) check orderLimit Map: " + orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());

			if(orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap().isEmpty())
				return;
			
			orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap().entrySet().stream().forEach(entry -> {
				String key = entry.getKey();
				
				// 지정가 가격 리스트
				TreeSet<CommLimitOrderRedisMsgVO> orderLimitList = orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(key);
	
				/* 
				 * 2) 지정가와 판매가격 비교하여 일치하는 데이터 amountGroupedMap에 저장
				 * 
				 * 시간대별 지정가 가격 리스트에서 수신 받은 판매 데이터의 메탈 코드와 일치하고,
				 * 수신 받은 판매가격보다 큰 지정가 리스트로 필터링
				 */
				Map<String, TreeSet<LivePremiumVO>> premiumData = itPremiumStdrBasVoService.getItPremiumStdrBasVo();

				TreeSet<CommLimitOrderRedisMsgVO> amountGroupedSet = premiumData.values().stream()
						.flatMap(TreeSet::stream)
						.filter(livePremiumVO -> livePremiumVO != null &&
								livePremiumVO.getValidBeginDt().compareTo(prSelVo.getOccrrncDe() + prSelVo.getOccrrncTime()) <= 0 &&
								livePremiumVO.getValidEndDt().compareTo(prSelVo.getOccrrncDe() + prSelVo.getOccrrncTime()) >= 0)
						.flatMap(livePremiumVO -> orderLimitList.stream()
								.filter(order -> order.getLimitInputAmount() >= (prSelVo.getEndPc() + livePremiumVO.getSlePremiumAmount()))
								.filter(order -> order.getMetalCode().equals(prSelVo.getMetalCode()))
								.filter(order -> (String.join("_", order.getMetalCode(), Integer.toString(order.getItmSn()),
										order.getDstrctLclsfCode(), order.getBrandGroupCode(), order.getBrandCode()))
											.equals(String.join("_", livePremiumVO.getMetalCode(), Integer.toString(livePremiumVO.getItmSn()),
													livePremiumVO.getDstrctLclsfCode(), livePremiumVO.getBrandGroupCode(), livePremiumVO.getBrandCode()))))
						.collect(Collectors.toCollection(TreeSet::new));
				/*
				 TreeSet<CommLimitOrderRedisMsgVO> amountGroupedSet = orderLimitList.stream()
						.filter(vo -> vo.getLimitInputAmount() >= prSelVo.getEndPc() && vo.getMetalCode().equals(prSelVo.getMetalCode()))
						.collect(Collectors.toCollection(TreeSet::new));
				*/
	
				if(amountGroupedSet.isEmpty())
					return;
				
				ObjectMapper objectMapper = new ObjectMapper();	// TODO [pje] 테스트용 - 삭제예정
				try {
					String result = objectMapper.writeValueAsString(amountGroupedSet);			// TODO [pje] 테스트용 - 삭제예정
					
					log.debug("3-1) Matching metalCode: " + prSelVo.getMetalCode() + ", prSelVo endPc:" + prSelVo.getEndPc() + ", Matching amount map:" +result);
				} catch(Exception e) {
					
				}
				
				// amountGroupedSet에 있는 주문번호 리스트
				List<String> limitOrderNoList = amountGroupedSet.stream()
						.map(CommLimitOrderRedisMsgVO::getLimitOrderNo)
						.collect(Collectors.toList());
				
				queueVo.setLimitOrderStdrSlePc(prSelVo.getEndPc());
	
				///////////////////////////////////////////////////////////////////////
				log.debug("3-4) key: " + key + ", queueVo:" + queueVo);
				
				
				try {
					// 3) 종목별로 큐에 넘겨줄 최종 데이터를 세팅 후 큐에 전송
					limitService.settingLimitQueueData(amountGroupedSet, queueVo);
					
					// 4) 전송된 데이터 메모리에서 제거
					orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(key).removeIf(item -> limitOrderNoList.contains(item.getLimitOrderNo()));
					orderLimitOrderBasVoMapService.getLimitOrderNoInputAmountVo().keySet().removeIf(item -> limitOrderNoList.contains(item));
					
					String result = objectMapper.writeValueAsString(orderLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());			// TODO [pje] 테스트용 - 삭제예정
					String result2 = objectMapper.writeValueAsString(orderLimitOrderBasVoMapService.getLimitOrderNoInputAmountVo());
					log.info("6-1) After Sending Data to the Queue: " + result);
					log.info("6-2) After Sending Data to the Queue: " + result2);
				} catch (Exception e) {
					log.error("[amountGroupedMap Error] {}", ExceptionUtils.getStackTrace(e));
				}
			});
		}
	}

	// 가단가 지정가 주문 체크
	private synchronized void checkPrvsnlLimitData(PrSelVO prSelVo) throws Exception {
		if(restDateTime.isSorinRltmWorkTime() && ReciveLmeDataByUdpSocket.isReadyToSelSchedule) {
			// 1) 큐 레이아웃에 맞는 데이터 설정
			CommPrvsnlLimitOrderQueueMsgVO queueVo = new CommPrvsnlLimitOrderQueueMsgVO();
			queueVo.setLimitOrderRequestDt("" + prSelVo.getOccrrncDe() + prSelVo.getOccrrncTime());	// 지정가 주문 요청 일시
			queueVo.setSlePcRltmSn(prSelVo.getSlePcRltmSn());										// 판매 가격 실시간 순번
			queueVo.setLmePcRltmSn(prSelVo.getLmePcRltmSn());										// LME 가격 실시간 순번
			queueVo.setLme3m(prSelVo.getThreemonthLmePc());											// LME 3M
			queueVo.setLmeCash(prSelVo.getLmePc());													// LME 현금
			queueVo.setLmeMdatCffcnt(prSelVo.getLmeMdatCffcnt());									// LME 조정계수
			queueVo.setEhgtPcRltmSn(prSelVo.getEhgtPcRltmSn());										// 환율 가격 실시간 순번
			queueVo.setSpex(prSelVo.getEhgtPc());													// 환율 가격
			queueVo.setSpexMdatCffcnt(prSelVo.getFxMdatCffcnt());									// 환율 조정계수

			log.debug("3-0) check orderLimit Map: " + orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap());

			if(orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap().isEmpty())
				return;

			orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap().entrySet().stream().forEach(entry -> {
				String key = entry.getKey();

				// 가단가 지정가 가격 리스트
				TreeSet<CommPrvsnlLimitOrderRedisMsgVO> orderLimitList = orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap(key);

				/*
				 * 2) 지정가와 판매가격 비교하여 일치하는 데이터 amountGroupedMap에 저장
				 *
				 * 시간대별 지정가 가격 리스트에서 수신 받은 판매 데이터의 메탈 코드와 일치하고,
				 *
				 * LME -> 지정가 입력금액이 (실시간 LME + 조정계수) 보다 크거나 같음
				 * KRW -> 지정가 입력금액이 (실시간 판매가격 + 주문시점 프리미엄) 보다 크거나 같음
				 *
				 * 각각의 케이스로 리스트 필터링
				 */
				TreeSet<CommPrvsnlLimitOrderRedisMsgVO> amountGroupedSet = orderLimitList.stream()
						.filter(order -> order.getMetalCode().equals(prSelVo.getMetalCode()))
						.filter(order -> {
							// 지정가 주문번호의 구분자값 추출
							String prefix = order.getLimitOrderNo().substring(9, 10);

							if("F".equals(prefix) && (order.getLimitInputAmount() >= prSelVo.getLmePc().add(prSelVo.getLmeMdatCffcnt()).longValue())) {
								// LME
								return true;
							} else if("R".equals(prefix) && (order.getLimitInputAmount() >= (prSelVo.getEndPc() + order.getPremiumPc()))) {
								// KRW
								return true;
							} else {
								return false;
							}
						})
						.collect(Collectors.toCollection(TreeSet::new));

				if(amountGroupedSet.isEmpty())
					return;

				ObjectMapper objectMapper = new ObjectMapper();	// TODO [pje] 테스트용 - 삭제예정
				try {
					String result = objectMapper.writeValueAsString(amountGroupedSet);			// TODO [pje] 테스트용 - 삭제예정

					log.debug("3-1) Matching metalCode: " + prSelVo.getMetalCode() + ", Matching amount map:" +result);
				} catch(Exception e) {

				}

				// amountGroupedSet에 있는 주문번호 리스트
				List<String> limitOrderNoList = amountGroupedSet.stream()
						.map(CommPrvsnlLimitOrderRedisMsgVO::getLimitOrderNo)
						.collect(Collectors.toList());

				queueVo.setLimitOrderStdrSlePc(prSelVo.getEndPc());

				///////////////////////////////////////////////////////////////////////
				log.debug("3-4) key: " + key + ", queueVo:" + queueVo);


				try {
					// 3) 종목별로 가단가용 큐에 넘겨줄 최종 데이터를 세팅 후 큐에 전송
					limitService.settingPrvsnlLimitQueueData(amountGroupedSet, queueVo);

					// 4) 전송된 데이터 메모리에서 제거
					orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap(key).removeIf(item -> limitOrderNoList.contains(item.getLimitOrderNo()));
					orderLimitOrderBasVoMapService.getPrvsnlLimitOrderNoInputAmountVo().keySet().removeIf(item -> limitOrderNoList.contains(item));

					String result = objectMapper.writeValueAsString(orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap());			// TODO [pje] 테스트용 - 삭제예정
					String result2 = objectMapper.writeValueAsString(orderLimitOrderBasVoMapService.getPrvsnlLimitOrderNoInputAmountVo());
					log.info("6-1) After Sending Data to the Queue: " + result);
					log.info("6-2) After Sending Data to the Queue: " + result2);
				} catch (Exception e) {
					log.error("[amountGroupedMap Error] {}", ExceptionUtils.getStackTrace(e));
				}
			});
		}
	}
}
