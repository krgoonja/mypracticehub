package com.sorincorp.lme.pc.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.pcInfo.model.RvcmpnVO;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.lme.ReciveLmeDataByUdpSocket;
import com.sorincorp.lme.constant.PrPcStdrBasVoConstant;
import com.sorincorp.lme.pc.mapper.PcMapper;
import com.sorincorp.lme.pc.model.OpFallNumPcBasVo;
import com.sorincorp.lme.pc.model.OpFallSelPcBasVo;
import com.sorincorp.lme.pc.model.PrLmeEvlPcBasVo;
import com.sorincorp.lme.pc.model.PrLmePblntfPcBasVo;
import com.sorincorp.lme.pc.model.PrLmePcStdrBasVo;
import com.sorincorp.lme.pc.model.SelPrimiumAmountVo;
import com.sorincorp.lme.util.RestDateTime;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class PcServiceImpl implements PcService {

	@Autowired
	private PcMapper pcMapper;

	@Autowired
	private RestDateTime restDateTime;

	@Value("${metalCode.list}")
	private List<String> metalCodeList;

	private final PrLmePcStdrBasVoMapService prLmePcStdrBasVoMapService;
	private final PrLmeEvlPcBasVoMapService prLmeEvlPcBasVoMapService;
	private final PrLmePblntfPcBasVoMapService prLmePblntfPcBasVoMapService;

	@Autowired
	public PcServiceImpl(PrLmePcStdrBasVoMapService prLmePcStdrBasVoMapService, PrLmeEvlPcBasVoMapService prLmeEvlPcBasVoMapService, PrLmePblntfPcBasVoMapService prLmePblntfPcBasVoMapService) {
		this.prLmePcStdrBasVoMapService = prLmePcStdrBasVoMapService;
		this.prLmeEvlPcBasVoMapService = prLmeEvlPcBasVoMapService;
		this.prLmePblntfPcBasVoMapService = prLmePblntfPcBasVoMapService;
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrLmePcStdrBas(PrLmePcStdrBasVo vo) throws Exception {
		if (restDateTime.isLmeWorkTime()) {
			pcMapper.insertPrLmePcStdrBas(vo);
			pcMapper.insertPrLmeMdatPcStdrBas(vo);
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrLmePcRltmBas(PrLmePcStdrBasVo vo) throws Exception {
		if (restDateTime.isLmeWorkTime()) {
			pcMapper.insertPrLmePcRltmBas(vo);
			pcMapper.insertPrLmeMdatPcRltmBas(vo);
			log.info("[PcServiceImpl][insertPrLmePcRltmBas]=======/metalCode:" + vo.getMetalCode() + " / occrrncSn: " + vo.getOccrrncSn());
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrLmePblntfPcBas(PrLmePblntfPcBasVo vo) throws Exception {
		pcMapper.insertPrLmePblntfPcBas(vo);
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrLmeEvlPcBas(PrLmeEvlPcBasVo vo) throws Exception {
		pcMapper.insertPrLmeEvlPcBasVo(vo);
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrLmePc01MinBas(PrLmePcStdrBasVo vo) throws Exception {
		if (restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			pcMapper.insertPrLmePc01MinBas(vo);
			pcMapper.insertPrLmeMdatPc01MinBas(vo);

			// log.info("!!!!!!!!!! 1 minutes LME insert schedule !!!!!!!!!!");
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrLmePc30MinBas(PrLmePcStdrBasVo vo) throws Exception {
		if (restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			pcMapper.insertPrLmePc30MinBas(vo);
			pcMapper.insertPrLmeMdatPc30MinBas(vo);
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrLmePc60MinBas(PrLmePcStdrBasVo vo) throws Exception {
		if (restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			pcMapper.insertPrLmePc60MinBas(vo);
			pcMapper.insertPrLmeMdatPc60MinBas(vo);
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrLmePcDeBas(PrLmePcStdrBasVo vo) throws Exception {
		if (restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			pcMapper.insertPrLmePcDeBas(vo);
			pcMapper.insertPrLmeMdatPcDeBas(vo);
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrLmePcWeekBas(PrLmePcStdrBasVo vo) throws Exception {
		if (restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			pcMapper.insertPrLmePcWeekBas(vo);
			pcMapper.insertPrLmeMdatPcWeekBas(vo);
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrLmePcYyMtBas(PrLmePcStdrBasVo vo) throws Exception {
		if (restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			pcMapper.insertPrLmePcYyMtBas(vo);
			pcMapper.insertPrLmeMdatPcYyMtBas(vo);
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrLmePcYyQuBas(PrLmePcStdrBasVo vo) throws Exception {
		if (restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			pcMapper.insertPrLmePcYyQuBas(vo);
			pcMapper.insertPrLmeMdatPcYyQuBas(vo);
		}
	}

	@Override
	@Async("lmeThreadPoolExcuter")
	public void insertPrLmePcYyBas(PrLmePcStdrBasVo vo) throws Exception {
		if (restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			pcMapper.insertPrLmePcYyBas(vo);
			pcMapper.insertPrLmeMdatPcYyBas(vo);
		}
	}

	@Override
	public void selectTopPrLmePcStdrBas() throws Exception {
		PrLmePcStdrBasVo vo = new PrLmePcStdrBasVo();

		for (String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);

			PrLmePcStdrBasVo returnVo = pcMapper.selectTopPrLmePcStdrBas(vo);
			if (returnVo != null) {
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.STDR));
			}
		}
	}

	@Override
	public void selectTopPrLmePcRltmBas() throws Exception {
		PrLmePcStdrBasVo vo = new PrLmePcStdrBasVo();

		for (String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);

			PrLmePcStdrBasVo returnVo = pcMapper.selectTopPrLmePcRltmBas(vo);
			if (returnVo != null) {
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.RLTM));
			}
		}
	}

	@Override
	public void selectTopPrLmePblntfPcBas() throws Exception {
		PrLmePblntfPcBasVo vo = new PrLmePblntfPcBasVo();

		for (String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);

			PrLmePblntfPcBasVo returnVo = pcMapper.selectTopPrLmePblntfPcBas(vo);
			if (returnVo != null) {
				BeanUtils.copyProperties(returnVo, prLmePblntfPcBasVoMapService.getPrLmePblntfPcBasVo(metalCode));
			}
		}
	}

	@Override
	public void selectTopPrLmeEvlPcBas() throws Exception {
		PrLmeEvlPcBasVo vo = new PrLmeEvlPcBasVo();

		for (String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);

			PrLmeEvlPcBasVo returnVo = pcMapper.selectTopPrLmeEvlPcBas(vo);
			if (returnVo != null) {
				BeanUtils.copyProperties(returnVo, prLmeEvlPcBasVoMapService.getPrLmeEvlPcBasVo(metalCode));
			}
		}
	}

	@Override
	public void selectTopPrLmePc01MinBas() throws Exception {
		PrLmePcStdrBasVo vo = new PrLmePcStdrBasVo();

		for (String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);

			PrLmePcStdrBasVo returnVo = pcMapper.selectTopPrLmePc01MinBas(vo);
			if (returnVo != null) {
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.ONE_MINUTE));
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE));
			}
		}
	}

	@Override
	public void selectTopPrLmePc30MinBas() throws Exception {
		PrLmePcStdrBasVo vo = new PrLmePcStdrBasVo();

		for (String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);

			PrLmePcStdrBasVo returnVo = pcMapper.selectTopPrLmePc30MinBas(vo);
			if (returnVo != null) {
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.THIRTY_MINUTE));
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE));
			}
		}
	}

	@Override
	public void selectTopPrLmePc60MinBas() throws Exception {
		PrLmePcStdrBasVo vo = new PrLmePcStdrBasVo();

		for (String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);

			PrLmePcStdrBasVo returnVo = pcMapper.selectTopPrLmePc60MinBas(vo);
			if (returnVo != null) {
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.SIXTY_MINUTE));
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE));
			}
		}
	}

	@Override
	public void selectTopPrLmePcDeBas() throws Exception {
		PrLmePcStdrBasVo vo = new PrLmePcStdrBasVo();

		for (String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);

			PrLmePcStdrBasVo returnVo = pcMapper.selectTopPrLmePcDeBas(vo);
			if (returnVo != null) {
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.DAY));
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_DAY));
			}
		}
	}

	@Override
	public void selectTopPrLmePcWeekBas() throws Exception {
		PrLmePcStdrBasVo vo = new PrLmePcStdrBasVo();

		for (String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);

			PrLmePcStdrBasVo returnVo = pcMapper.selectTopPrLmePcWeekBas(vo);
			if (returnVo != null) {
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.WEEK));
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_WEEK));
			}
		}
	}

	@Override
	public void selectTopPrLmePcYyMtBas() throws Exception {
		PrLmePcStdrBasVo vo = new PrLmePcStdrBasVo();

		for (String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);

			PrLmePcStdrBasVo returnVo = pcMapper.selectTopPrLmePcYyMtBas(vo);
			if (returnVo != null) {
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.MONTH));
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_MONTH));
			}
		}
	}

	@Override
	public void selectTopPrLmePcYyQuBas() throws Exception {
		PrLmePcStdrBasVo vo = new PrLmePcStdrBasVo();

		for (String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);

			PrLmePcStdrBasVo returnVo = pcMapper.selectTopPrLmePcYyQuBas(vo);
			if (returnVo != null) {
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.QUARTER));
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_QUARTER));
			}
		}
	}

	@Override
	public void selectTopPrLmePcYyBas() throws Exception {
		PrLmePcStdrBasVo vo = new PrLmePcStdrBasVo();

		for (String metalCode : metalCodeList) {
			vo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			vo.setMetalCode(metalCode);

			PrLmePcStdrBasVo returnVo = pcMapper.selectTopPrLmePcYyBas(vo);
			if (returnVo != null) {
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.YEAR));
				BeanUtils.copyProperties(returnVo, prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_YEAR));
			}
		}
	}

	@Override
	public void initializePrLmePcStdrBasVo(PrLmePcStdrBasVo returnNowLmeStdrBasVoFromIf) throws Exception {

		for (String metalCode : metalCodeList) {
			PrLmePcStdrBasVo oneMinute = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.ONE_MINUTE);
			PrLmePcStdrBasVo pastOneMinute = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_ONE_MINUTE);
			PrLmePcStdrBasVo thirtyMinute = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.THIRTY_MINUTE);
			PrLmePcStdrBasVo pastThirtyMinute = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_THIRTY_MINUTE);
			PrLmePcStdrBasVo sixtyMinute = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.SIXTY_MINUTE);
			PrLmePcStdrBasVo pastSixtyMinute = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_SIXTY_MINUTE);
			PrLmePcStdrBasVo day = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.DAY);
			PrLmePcStdrBasVo pastDay = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_DAY);
			PrLmePcStdrBasVo week = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.WEEK);
			PrLmePcStdrBasVo pastWeek = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_WEEK);
			PrLmePcStdrBasVo month = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.MONTH);
			PrLmePcStdrBasVo pastMonth = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_MONTH);
			PrLmePcStdrBasVo quarter = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.QUARTER);
			PrLmePcStdrBasVo pastQuarter = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_QUARTER);
			PrLmePcStdrBasVo year = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.YEAR);
			PrLmePcStdrBasVo pastYear = prLmePcStdrBasVoMapService.getPrLmePcStdrBasVo(metalCode, PrPcStdrBasVoConstant.PAST_YEAR);

			if (oneMinute == null || oneMinute.getEndPc() == null || oneMinute.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, oneMinute);
			}

			if (pastOneMinute == null || pastOneMinute.getEndPc() == null || pastOneMinute.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, pastOneMinute);
			}

			if (thirtyMinute == null || thirtyMinute.getEndPc() == null || thirtyMinute.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, thirtyMinute);
			}

			if (pastThirtyMinute == null || pastThirtyMinute.getEndPc() == null || pastThirtyMinute.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, pastThirtyMinute);
			}

			if (sixtyMinute == null || sixtyMinute.getEndPc() == null || sixtyMinute.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, sixtyMinute);
			}

			if (pastSixtyMinute == null || pastSixtyMinute.getEndPc() == null || pastSixtyMinute.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, pastSixtyMinute);
			}

			if (day == null || day.getEndPc() == null || day.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, day);
			}

			if (pastDay == null || pastDay.getEndPc() == null || pastDay.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, pastDay);
			}

			if (week == null || week.getEndPc() == null || week.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, week);
			}

			if (pastWeek == null || pastWeek.getEndPc() == null || pastWeek.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, pastWeek);
			}

			if (month == null || month.getEndPc() == null || month.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, month);
			}

			if (pastMonth == null || pastMonth.getEndPc() == null || pastMonth.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, pastMonth);
			}

			if (quarter == null || quarter.getEndPc() == null || quarter.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, quarter);
			}

			if (pastQuarter == null || pastQuarter.getEndPc() == null || pastQuarter.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, pastQuarter);
			}

			if (year == null || year.getEndPc() == null || year.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, year);
			}

			if (pastYear == null || pastYear.getEndPc() == null || pastYear.getEndMdatPc() == null) {
				BeanUtils.copyProperties(returnNowLmeStdrBasVoFromIf, pastYear);
			}
		}
	}

	@Override
	public void insertPrLmePcDeBasForProcedure(Map<String, String> map) throws Exception {
		if (restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			pcMapper.insertPrLmePcDeBasForProcedure(map);

			// log.info("!!!!!!!!!! day LME insert schedule !!!!!!!!!!");
		}
	}

	@Override
	public void insertPrLmePcWeekBasForProcedure(Map<String, String> map) throws Exception {
		if (restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			pcMapper.insertPrLmePcWeekBasForProcedure(map);

			// log.info("!!!!!!!!!! week LME insert schedule !!!!!!!!!!");
		}
	}

	@Override
	public void insertPrLmePcYyMtBasForProcedure(Map<String, String> map) throws Exception {
		if (restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			pcMapper.insertPrLmePcYyMtBasForProcedure(map);

			// log.info("!!!!!!!!!! month LME insert schedule !!!!!!!!!!");
		}
	}

	@Override
	public void insertPrLmePcYyQuBasForProcedure(Map<String, String> map) throws Exception {
		if (restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			pcMapper.insertPrLmePcYyQuBasForProcedure(map);

			// log.info("!!!!!!!!!! quarter LME insert schedule !!!!!!!!!!");
		}
	}

	@Override
	public void insertPrLmePcYyBasForProcedure(Map<String, String> map) throws Exception {
		if (restDateTime.isLmeWorkTime() && ReciveLmeDataByUdpSocket.isReadyToLmeSchedule) {
			pcMapper.insertPrLmePcYyBasForProcedure(map);

			// log.info("!!!!!!!!!! year LME insert schedule !!!!!!!!!!");
		}
	}

	@Override
	public void deletePrLmeSelOldDataProcedure() throws Exception {
		pcMapper.deletePrLmeSelOldDataProcedure();
		log.info("!!!!!!!!!! deletePrLmeSelOldDataProcedure schedule !!!!!!!!!!");
	}

	@Override
	public void insertStEvemthAccmlDalyAvgPcBas() throws Exception {
		pcMapper.insertStEvemthAccmlDalyAvgPcBas();
		log.info("!!!!!!!!!! insertStEvemthAccmlDalyAvgPcBas schedule !!!!!!!!!!");
	}

	@Override
	public List<OpFallSelPcBasVo> selectFallSelPc() throws Exception {
		return pcMapper.selectFallSelPc();
	}

	@Override
	public void updateFallSelPcBas(String fallSeqNo) throws Exception {
		pcMapper.updateFallSelPcBas(fallSeqNo);
	}

	@Override
	public List<Map<String, String>> selectMemberSmsByMetalCode(String metalCode) throws Exception {
		return pcMapper.selectMemberSmsByMetalCode(metalCode);
	}

	@Override
	public List<RvcmpnVO> selectItRvcmpnPcManageBas() throws Exception {
		return pcMapper.selectItRvcmpnPcManageBas();
	}

	@Override
	public List<OpFallSelPcBasVo> selectFallSelPcBas() throws Exception {
		return pcMapper.selectFallSelPcBas();
	}

	@Override
	public List<SelPrimiumAmountVo> selectSelPremiumAmount() throws Exception {
		return pcMapper.selectSelPremiumAmount();
	}

	@Override
	public List<OpFallNumPcBasVo> selectFallNumPc() throws Exception {
		return pcMapper.selectFallNumPc();
	}

	@Override
	public PrLmePcStdrBasVo selectPastLmePc(Map<String, String> map) throws Exception {
		return pcMapper.selectPastLmePc(map);
	}
}