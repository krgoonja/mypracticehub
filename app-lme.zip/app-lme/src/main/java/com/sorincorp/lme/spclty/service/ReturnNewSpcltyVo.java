package com.sorincorp.lme.spclty.service;

import org.springframework.stereotype.Component;

import com.sorincorp.lme.spclty.model.IfLmeSpcltyLaVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLbVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLcVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLeVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLgVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLhVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLoVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLsVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyLvVo;
import com.sorincorp.lme.spclty.model.IfLmeSpcltyVo;
import com.sorincorp.lme.util.LmeDataUtil;

/*
 * socket으로 받아온 모든 전문 원본 data를 Type별로 파싱하여
 * app-lme에서 사용할 Type별 전문 data vo를 만들어 반환하는 method들의 정의
 */
@Component
public class ReturnNewSpcltyVo {
	
	public IfLmeSpcltyVo process_Spclty(String msg) throws Exception{
		IfLmeSpcltyVo vo = new IfLmeSpcltyVo();
		vo.setReceptDatetime(LmeDataUtil.recept_datetime);
		vo.setType(LmeDataUtil.type);
		vo.setSpclty(msg);

		return vo;
	}

	public IfLmeSpcltyLaVo process_LA(String msg) throws Exception{
		IfLmeSpcltyLaVo vo = new IfLmeSpcltyLaVo();
		vo.setReceptDatetime(LmeDataUtil.recept_datetime);
		vo.setType(LmeDataUtil.type);
		vo.setGicName(LmeDataUtil.to_string (msg,32));
		vo.setRicName(LmeDataUtil.to_string (msg,20));
		vo.setKind(LmeDataUtil.to_string (msg,1));
		vo.setTradeDate(LmeDataUtil.to_string (msg,8));
		vo.setPrevDate(LmeDataUtil.to_string (msg,8));
		vo.setFutBid(LmeDataUtil.to_string (msg,17));
		vo.setFutAsk(LmeDataUtil.to_string (msg,17));
		vo.setCashBid(LmeDataUtil.to_string (msg,17));
		vo.setCashAsk(LmeDataUtil.to_string (msg,17));
		vo.setCashExpirDate(LmeDataUtil.to_string (msg,8));
		vo.setReceptDate(LmeDataUtil.to_string (msg,8));
		vo.setReceptTime(LmeDataUtil.to_string (msg,6));
		
		return vo;
	}
	
    public IfLmeSpcltyLbVo process_LB (String msg) throws Exception {
    	IfLmeSpcltyLbVo vo = new IfLmeSpcltyLbVo();
    	vo.setReceptDatetime(LmeDataUtil.recept_datetime);
    	vo.setType(LmeDataUtil.type);
		vo.setGicName(LmeDataUtil.to_string (msg,32));
		vo.setRicName(LmeDataUtil.to_string (msg,20));
		vo.setKind(LmeDataUtil.to_string (msg,1));
		vo.setExpirDate(LmeDataUtil.to_string (msg,8));
		vo.setLastDate(LmeDataUtil.to_string (msg,8));
		vo.setMetalCode(LmeDataUtil.to_string (msg,3));
		vo.setMarketCode(LmeDataUtil.to_string (msg,3));
		vo.setNow(LmeDataUtil.to_string (msg,17));
		LmeDataUtil.to_string (msg,25); // blank
		vo.setStart(LmeDataUtil.to_string (msg,17));
		vo.setHigh(LmeDataUtil.to_string (msg,17));
		vo.setLow(LmeDataUtil.to_string (msg,17));
		vo.setTradeDate(LmeDataUtil.to_string (msg,8));
		vo.setPrevDate(LmeDataUtil.to_string (msg,8));
		vo.setCashExpirDate(LmeDataUtil.to_string (msg,8));
		vo.setReceptDate(LmeDataUtil.to_string (msg,8));
		vo.setReceptTime(LmeDataUtil.to_string (msg,6));
		
		return vo;
	  }
	  
    public IfLmeSpcltyLcVo process_LC (String msg) throws Exception {
    	IfLmeSpcltyLcVo vo = new IfLmeSpcltyLcVo();
    	vo.setReceptDatetime(LmeDataUtil.recept_datetime);
  	  	vo.setType(LmeDataUtil.type);
	  	vo.setGicName(LmeDataUtil.to_string (msg,32));
	    vo.setRicName(LmeDataUtil.to_string (msg,20));
	    vo.setKind(LmeDataUtil.to_string (msg,1));
	    vo.setTradeDate(LmeDataUtil.to_string(msg, 8));
	    vo.setReceptDate(LmeDataUtil.to_string(msg, 8));
	    vo.setReceptTime(LmeDataUtil.to_string(msg, 6));
	    vo.setFuturesNow(LmeDataUtil.to_string(msg, 17));
	    vo.setFuturesStart(LmeDataUtil.to_string(msg, 17));
	    vo.setFuturesHigh(LmeDataUtil.to_string(msg, 17));
	    vo.setFuturesLow(LmeDataUtil.to_string(msg, 17));
	    vo.setFuturesNetchng(LmeDataUtil.to_string(msg, 10));
	    vo.setFuturesPctchng(LmeDataUtil.to_string(msg, 10));
	    vo.setSpread(LmeDataUtil.to_string(msg, 17));
	    vo.setNow(LmeDataUtil.to_string(msg, 17));
	    vo.setStart(LmeDataUtil.to_string(msg, 17));
	    vo.setHigh(LmeDataUtil.to_string(msg, 17));
	    vo.setLow(LmeDataUtil.to_string(msg, 17));
	    vo.setNetchng(LmeDataUtil.to_string(msg, 10));
	    vo.setPctchng(LmeDataUtil.to_string(msg, 10));
	    vo.setAcvol(LmeDataUtil.to_string(msg, 10));
	    vo.setTrdvol(LmeDataUtil.to_string(msg, 10));
	    return vo;
    }
    
    public IfLmeSpcltyLeVo process_LE (String msg) throws Exception {
    	IfLmeSpcltyLeVo vo = new IfLmeSpcltyLeVo();
    	vo.setReceptDatetime(LmeDataUtil.recept_datetime);
    	vo.setType(LmeDataUtil.type);
    	vo.setMetalCode(LmeDataUtil.to_string(msg, 3));
    	vo.setEvalCode(LmeDataUtil.to_string(msg, 20));
    	vo.setTradeDate(LmeDataUtil.to_string(msg, 8));
    	vo.setExpirDate(LmeDataUtil.to_string(msg, 8));
    	vo.setSettle(LmeDataUtil.to_string(msg, 10)); //문서 잘못됨 17->10자리
    	
    	return vo;
    }
    
    public IfLmeSpcltyLhVo process_LH (String msg) throws Exception {
    	IfLmeSpcltyLhVo vo = new IfLmeSpcltyLhVo();
    	vo.setReceptDatetime(LmeDataUtil.recept_datetime);
    	vo.setType(LmeDataUtil.type);
    	vo.setGicName(LmeDataUtil.to_string(msg, 32));
    	vo.setRicName(LmeDataUtil.to_string(msg, 20));
    	vo.setKind(LmeDataUtil.to_string(msg, 1));
    	vo.setTradeDate(LmeDataUtil.to_string(msg, 8));
    	vo.setReceptDate(LmeDataUtil.to_string(msg, 8));
    	vo.setReceptTime(LmeDataUtil.to_string(msg, 6));
    	vo.setMarketCode(LmeDataUtil.to_string(msg, 6));
    	vo.setBestBid1(LmeDataUtil.to_string(msg, 17));
    	vo.setBestBid2(LmeDataUtil.to_string(msg, 17));
    	vo.setBestBid3(LmeDataUtil.to_string(msg, 17));
    	vo.setBestBid4(LmeDataUtil.to_string(msg, 17));
    	vo.setBestBid5(LmeDataUtil.to_string(msg, 17));
    	vo.setBestAsk1(LmeDataUtil.to_string(msg, 17));
    	vo.setBestAsk2(LmeDataUtil.to_string(msg, 17));
    	vo.setBestAsk3(LmeDataUtil.to_string(msg, 17));
    	vo.setBestAsk4(LmeDataUtil.to_string(msg, 17));
    	vo.setBestAsk5(LmeDataUtil.to_string(msg, 17));
    	vo.setBestBsiz1(LmeDataUtil.to_string(msg, 10));
    	vo.setBestBsiz2(LmeDataUtil.to_string(msg, 10));
    	vo.setBestBsiz3(LmeDataUtil.to_string(msg, 10));
    	vo.setBestBsiz4(LmeDataUtil.to_string(msg, 10));
    	vo.setBestBsiz5(LmeDataUtil.to_string(msg, 10));
    	vo.setBestAsiz1(LmeDataUtil.to_string(msg, 10));
    	vo.setBestAsiz2(LmeDataUtil.to_string(msg, 10));
    	vo.setBestAsiz3(LmeDataUtil.to_string(msg, 10));
    	vo.setBestAsiz4(LmeDataUtil.to_string(msg, 10));
    	vo.setBestAsiz5(LmeDataUtil.to_string(msg, 10));
    	
    	return vo;
    }
    
    public IfLmeSpcltyLgVo process_LG (String msg) throws Exception {
    	IfLmeSpcltyLgVo vo = new IfLmeSpcltyLgVo();
    	vo.setReceptDatetime(LmeDataUtil.recept_datetime);
    	vo.setType(LmeDataUtil.type);
    	vo.setMetalCode(LmeDataUtil.to_string(msg, 3));
    	vo.setInnerCode(LmeDataUtil.to_string(msg, 25));
    	vo.setCountryCd(LmeDataUtil.to_string(msg, 10));
    	vo.setLctncd(LmeDataUtil.to_string(msg, 10));
    	vo.setGrdecd(LmeDataUtil.to_string(msg, 10));
    	vo.setOpenvol(LmeDataUtil.to_string(msg, 10));
    	vo.setInvol(LmeDataUtil.to_string(msg, 10));
    	vo.setOutvol(LmeDataUtil.to_string(msg, 10));
    	vo.setClosevol(LmeDataUtil.to_string(msg, 10));
    	vo.setOnwrnt(LmeDataUtil.to_string(msg, 10));
    	vo.setCnclwrnt(LmeDataUtil.to_string(msg, 10));
    	vo.setCnclwrntRate(LmeDataUtil.to_string(msg, 10));
    	vo.setNetchng(LmeDataUtil.to_string(msg, 10));
    	vo.setTradeDate(LmeDataUtil.to_string(msg, 8));
    	
    	return vo;
    }
    
    public IfLmeSpcltyLoVo process_LO (String msg) throws Exception {
    	IfLmeSpcltyLoVo vo = new IfLmeSpcltyLoVo();
    	vo.setReceptDatetime(LmeDataUtil.recept_datetime);
    	vo.setType(LmeDataUtil.type);
    	vo.setMetalCode(LmeDataUtil.to_string(msg, 3));
    	vo.setInnerCode(LmeDataUtil.to_string(msg, 20));
    	vo.setOpint(LmeDataUtil.to_string(msg, 10));
    	vo.setOpintnc(LmeDataUtil.to_string(msg, 10));
    	vo.setOpintDate(LmeDataUtil.to_string(msg, 8));
    	
    	return vo;
    }
    
    public IfLmeSpcltyLsVo process_LS (String msg) throws Exception {
    	IfLmeSpcltyLsVo vo = new IfLmeSpcltyLsVo();
    	vo.setReceptDatetime(LmeDataUtil.recept_datetime);
    	vo.setType(LmeDataUtil.type);
    	vo.setMetalCode(LmeDataUtil.to_string(msg, 3));
    	vo.setRicName(LmeDataUtil.to_string(msg, 20));
    	vo.setKind(LmeDataUtil.to_string(msg, 1));
    	vo.setTradeDate(LmeDataUtil.to_string(msg, 8));
    	vo.setInitialStock(LmeDataUtil.to_string(msg, 17));
    	vo.setInputStock(LmeDataUtil.to_string(msg, 17));
    	vo.setOuputStock(LmeDataUtil.to_string(msg, 17));
    	vo.setCurrentStock(LmeDataUtil.to_string(msg, 17));
    	vo.setStockNetchng(LmeDataUtil.to_string(msg, 17));
    	vo.setOnwrnt(LmeDataUtil.to_string(msg, 10));
    	vo.setCnclwrnt(LmeDataUtil.to_string(msg, 10));
    	
    	return vo;
    }
    
    public IfLmeSpcltyLvVo process_LV (String msg) throws Exception {
    	IfLmeSpcltyLvVo vo = new IfLmeSpcltyLvVo();
    	vo.setReceptDatetime(LmeDataUtil.recept_datetime);
    	vo.setType(LmeDataUtil.type);
    	vo.setMetalCode(LmeDataUtil.to_string(msg, 3));
    	vo.setTradeDate(LmeDataUtil.to_string(msg, 8));
    	vo.setSessionCode(LmeDataUtil.to_string(msg, 2));
    	vo.setVolumeusd(LmeDataUtil.to_string(msg, 10));
    	vo.setVolumeeur(LmeDataUtil.to_string(msg, 10));
    	vo.setVolumegbp(LmeDataUtil.to_string(msg, 10));
    	vo.setVolumeyen(LmeDataUtil.to_string(msg, 10));
    	
    	return vo;
    }
    
}
