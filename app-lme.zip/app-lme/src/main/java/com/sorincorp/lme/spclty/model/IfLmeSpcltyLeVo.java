package com.sorincorp.lme.spclty.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class IfLmeSpcltyLeVo  implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = -4917602877224546049L;
	/**
     * 수신일시
    */
    private String receptDatetime;
    /**
     * 전문타입
    */
    private String type;
    /**
     * 품목코드
    */
    private String metalCode;
    /**
     * 내부코드
    */
    private String evalCode;
    /**
     * 영국영업일자
    */
    private String tradeDate;
    /**
     * 만기일자
    */
    private String expirDate;
    /**
     * 평가가격
    */
    private String settle;
}