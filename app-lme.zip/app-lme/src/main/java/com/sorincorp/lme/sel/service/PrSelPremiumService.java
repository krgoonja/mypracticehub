package com.sorincorp.lme.sel.service;

import com.sorincorp.lme.sel.model.PrSelPcStdrBasVo;

public interface PrSelPremiumService {

	/**
	 * <pre>
	 * 처리내용: 판매가격에 프리미엄 적용하여 저장
	 * </pre>
	 * @date 2023. 7. 14.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 14.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 */
	void saveRedisPremiumAddedSelPc(String metalCode);

	/**
	 * <pre>
	 * 처리내용: 프리미엄 적용된 판매가격 publish
	 * </pre>
	 * @date 2023. 7. 5.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 5.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	void publishPremiumAddedSelPc(String metalCode);

	/**
	 * <pre>
	 * 처리내용: 프리미엄 적용된 판매가격 차트타이틀 형식으로 만들어 레디스에 저장
	 * </pre>
	 * @date 2023. 7. 14.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 14.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	void calculatePremiumAddedSelPc(PrSelPcStdrBasVo vo);
}
