package com.sorincorp.lme.limit.service;

import com.sorincorp.lme.sel.model.PrSelPcStdrBasVo;

public interface FindMatchingLimitPriceThreadService {
	void findMatchingLimitPriceThread(PrSelPcStdrBasVo returnSelStdrVo) throws Exception;
}
