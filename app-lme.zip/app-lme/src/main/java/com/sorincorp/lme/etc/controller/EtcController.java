package com.sorincorp.lme.etc.controller;

import com.sorincorp.comm.dynmDiver.model.DynmDiverCommVO;
import com.sorincorp.comm.dynmDiver.comm.DynmDiverSetup;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sorincorp.lme.ReciveLmeDataByUdpSocket;
import com.sorincorp.lme.etc.model.TodaySpreadVO;
import com.sorincorp.lme.etc.service.EtcService;
import com.sorincorp.lme.util.FallSelPc;
import com.sorincorp.lme.util.RestDateTime;

import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Slf4j
@Controller
@RequestMapping("/lme")
public class EtcController {

	@Autowired
	EtcService etcService;

	@Autowired
	private RestDateTime restDateTime;
	
	@Autowired
	private FallSelPc fallSelPc;

	@Autowired
	private ReciveLmeDataByUdpSocket reciveLmeDataByUdpSocket;

	@Autowired
	private DynmDiverSetup dynmDiverSetup;

	/**
	 * <pre>
	 * 처리내용: lmeHealthCheck용
	 * </pre>
	 * @date 2022. 2. 21.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 2. 21.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 * @throws Exception
	 */
	@GetMapping("/healthCheck")
	@ResponseBody
	public ResponseEntity<Object> healthCheck() {
		try {
			return new ResponseEntity<>("success", HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/lmeEhgtStatus")
	@ResponseBody
	public ResponseEntity<Object> lmeEhgtStatus(@RequestParam("lmeStatus") int lmeStatus, @RequestParam("ehgtStatus") int ehgtStatus, @RequestParam("initStatus") int initStatus) {
		try {
			etcService.testSetting(lmeStatus, ehgtStatus, initStatus);

			return new ResponseEntity<>("success", HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/leSpreadRun")
	@ResponseBody
	public ResponseEntity<Object> leSpreadRun() {
		try {
			reciveLmeDataByUdpSocket.setLeSpreadRun(true);

			return new ResponseEntity<>("success", HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/leSpreadStop")
	@ResponseBody
	public ResponseEntity<Object> leSpreadStop() {
		try {
			reciveLmeDataByUdpSocket.setLeSpreadRun(false);

			return new ResponseEntity<>("success", HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * <pre>
	 * 처리내용: LME restDateTime 초기화
	 * </pre>
	 * @date 2023. 4. 20.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 4. 20.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @return
	 */
	@PostMapping("/lmeInit")
	public ResponseEntity<Object> lmeInit() {
		try {
			restDateTime.initialize();

			return new ResponseEntity<>("success", HttpStatus.OK);
		} catch(Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 조달청 가격 크롤링 후 LME의 조달청 가격리스트가 조회된다. 
	 * </pre>
	 * @date 2023. 6. 01.	
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 6. 01.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @return
	 */
	@PostMapping("/rvcmpnPcInit")
	public ResponseEntity<Object> initItRvcmpnPc() {
		log.debug("==========================[EtcController][initItRvcmpnPc] start==========================");
		try {
	
			fallSelPc.initItRvcmpnPcManageBas();
			log.debug("==========================[EtcController][initItRvcmpnPc] end==========================");
			return new ResponseEntity<>("success", HttpStatus.OK);
			
		} catch(Exception e) {
			log.debug("=======================================[EtcController][initItRvcmpnPc]" + ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		
	}
	
	/**
	 * <pre>
	 * 처리내용: /fallSelPcInit 가 호출될때 마다 하락메세지 테이블을 조회한다. 
	 * </pre>
	 * @date 2023. 6. 01.	
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 6. 01.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @return
	 */
	@PostMapping("/fallSelPcInit")
	public ResponseEntity<Object> initFallSelPc() {
		log.debug("==========================[EtcController][initFallSelPc]==========================");
		try {
	
			fallSelPc.initItFallSelPcBas();
			log.debug("======================================[EtcController][initFallSelPc]===================================================");
			return new ResponseEntity<>("success", HttpStatus.OK);
			
		} catch(Exception e) {
			log.debug("=======================================[EtcController][initFallSelPc]" + ExceptionUtils.getStackTrace(e));
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
		
	}
	
	/**
	 * <pre>
	 * 처리내용: 강제 인서트 LME의 조달청 가격리스트가 조회된다.
	 * </pre>
	 * @date 2023. 6. 14.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 6. 14.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @return
	 */
	@GetMapping("/pushRvcmpnPcInit")
	@ResponseBody
	public ResponseEntity<Object> pushRvcmpnPcInit() {
		try {
			fallSelPc.initItRvcmpnPcManageBas();
			log.debug("==========================[EtcController][pushRvcmpnPcInit] end==========================");
			return new ResponseEntity<>("success", HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 차트타이틀 갱신
	 * </pre>
	 * @date 2023. 11. 6.
	 * @auther hamyoonsic
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자			변경내용
	 * -----------------------------------------------
	 * 2023. 11. 6.			hamyoonsic			최초작성
	 * -----------------------------------------------
	 * @param param
	 * @return
	 */
	@PostMapping("/changeChartTitleInfo")
	@ResponseBody
	public ResponseEntity<?> changeChartTitleInfo(@RequestBody TodaySpreadVO param) {
		log.debug("EtcController changeChartTitleInfo Start metalCode : "+ param.getMetalCode());
		Map<String, String> resultMap = new HashMap<String, String>();
		try {
			reciveLmeDataByUdpSocket.changeChartTitleInfo(param.getMetalCode());
			resultMap.put("resultMsg","success");
			return new ResponseEntity<>(resultMap, HttpStatus.OK);
		} catch (Exception e) {
			log.error("EtcController changeChartTitleInfo ERROR : "+ e.getMessage());
			resultMap.put("resultMsg",e.getMessage());
			return new ResponseEntity<>(resultMap, HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 다이버 발동 조건 확인
	 * </pre>
	 * @date 2024. 1. 24.
	 * @auther hamyoonsic
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자			변경내용
	 * -----------------------------------------------
	 * 2024. 1. 24.			hamyoonsic			최초작성
	 * -----------------------------------------------
	 * @param
	 * @return
	 */
	@PostMapping("/lmeDiverMotnCndCnfirm")
	@ResponseBody
	public ResponseEntity<?> lmeDiverMotnCndCnfirm() {
		log.debug("EtcController LmeDiverMotnCndCnfirm Start");
		Map<String, String> resultMap = new HashMap<String, String>();
		try {
			DynmDiverCommVO resVO = dynmDiverSetup.diverMotnCndCnfirm();

			Optional.ofNullable(resVO).orElseThrow(() -> {
				log.error("LmeDiverMotnCndCnfirm 다이버 발동 조건 없음");
				return new Exception("LmeDiverMotnCndCnfirm 다이버 발동 조건 없음");
			});

			String diverAt = Optional.ofNullable(resVO.getDiverAt()).orElseThrow(() -> {
				log.error("LmeDiverMotnCndCnfirm diverAt 다이버 전원 상태 없음");
				return new Exception("LmeDiverMotnCndCnfirm diverAt 다이버 전원 null");
			});

			int diverStatusCode = Optional.ofNullable(resVO.getDiverStatusCode()).orElseThrow(() -> {
				log.error("LmeDiverMotnCndCnfirm diverStatusCode 다이버 발동 상태 null");
				return new Exception("LmeDiverMotnCndCnfirm diverStatusCode 발동 상태 null");
			});
			resultMap.put("diverAt", diverAt);
			resultMap.put("diverStatusCode", String.valueOf(diverStatusCode));
			
			log.debug("[EtcController] [LmeDiverMotnCndCnfirm] END");
			return new ResponseEntity<>(resultMap, HttpStatus.OK);
		} catch (Exception e) {
			log.error("[EtcController] [changeChartTitleInfo] ERROR : "+ e.getMessage());
			resultMap.put("resultMsg",e.getMessage());
			return new ResponseEntity<>(resultMap, HttpStatus.BAD_REQUEST);
		}
	}
}
