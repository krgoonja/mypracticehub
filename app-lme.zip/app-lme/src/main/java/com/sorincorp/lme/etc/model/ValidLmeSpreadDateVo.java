package com.sorincorp.lme.etc.model;

import java.util.List;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CalculateSpreadVo.java
 * @version
 * @since 2022. 3. 15.
 * @author srec0026
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class ValidLmeSpreadDateVo extends CommonVO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6275806180021272641L;

    /**
     * 회사 코드
    */
    private String cmpnyCode;
    /**
     * 적용 일자
    */
    private String applcDe;
    /**
     * 요일
    */
    private String day;
    /**
     * LME 달력 유형 코드
    */
    private String lmeCldrTyCode;
    
    private List<String> lmeCldrTyCodeList;
    
    private String past;
    
    private String present;
    /**
     * 비고
    */
    private String rm;
    /**
     * 등록 일시
    */
    private java.sql.Timestamp registDt;
    /**
     * 등록자 아이디
    */
    private String registerId;
    /**
     * 수정 일시
    */
    private java.sql.Timestamp updtDt;
    /**
     * 수정자 아이디
    */
    private String updusrId;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
}