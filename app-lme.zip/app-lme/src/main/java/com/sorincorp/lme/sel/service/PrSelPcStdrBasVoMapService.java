package com.sorincorp.lme.sel.service;

import com.sorincorp.lme.sel.model.PrSelPcStdrBasVo;

public interface PrSelPcStdrBasVoMapService {
	
	PrSelPcStdrBasVo getPrSelPcStdrBasVo(String metalCodeByProperties, String prSelPcStdrBasVoConstant);
	
	void clearPrSelPcStdrBasVo();
	
	/**
	 * <pre>
	 * 처리내용: 프리미엄 적용된 판매가격 publish
	 * </pre>
	 * @date 2023. 7. 5.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 5.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	void publishPremiumAddedSelPc(PrSelPcStdrBasVo vo);
}