package com.sorincorp.lme.spclty.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class IfLmeSpcltyLcVo implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = -1402462952266935324L;
	/**
     * 수신일시
    */
    private String receptDatetime;
    /**
     * 전문타입
    */
    private String type;
    /**
     * 종목코드(삼성선물용)
    */
    private String gicName;
    /**
     * 종목코드(로이터)
    */
    private String ricName;
    /**
     * 선물현물스프레드구분
    */
    private String kind;
    /**
     * 영국영업일자
    */
    private String tradeDate;
    /**
     * 수신일자
    */
    private String receptDate;
    /**
     * 수신시각
    */
    private String receptTime;
    /**
     * 선물현재가
    */
    private String futuresNow;
    /**
     * 선물시가
    */
    private String futuresStart;
    /**
     * 선물고가
    */
    private String futuresHigh;
    /**
     * 선물저가
    */
    private String futuresLow;
    /**
     * 선물전일대비
    */
    private String futuresNetchng;
    /**
     * 선물전일대비율
    */
    private String futuresPctchng;
    /**
     * 스프레드
    */
    private String spread;
    /**
     * 현물현재가
    */
    private String now;
    /**
     * 현물시가
    */
    private String start;
    /**
     * 현물고가
    */
    private String high;
    /**
     * 현물저가
    */
    private String low;
    /**
     * 현물전일대비
    */
    private String netchng;
    /**
     * 현물전일대비율
    */
    private String pctchng;
    /**
     * 누적거래량
    */
    private String acvol;
    /**
     * 거래량
    */
    private String trdvol;
}