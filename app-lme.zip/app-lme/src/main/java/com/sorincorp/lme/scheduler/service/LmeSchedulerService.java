package com.sorincorp.lme.scheduler.service;

import java.util.List;

public interface LmeSchedulerService {
	/**
	 * <pre>
	 * 처리내용: 운영시간을 7시에 초기화 한다.
	 * </pre>
	 * @date 2021. 12. 16.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 16.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void initialSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: LME 가격이 제대로 들어오는지 판별하여 BO의 CO_CNTC_STTUS_BAS 테이블에 넣는다.
	 * </pre>
	 * @date 2021. 12. 22.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 22.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void selectLmeStatusSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 월~금 LME 시작 시간에 1분 단위로 저장 (정각 1초전)
	 * </pre>
	 * @date 2021. 11. 16.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 16.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void oneMinutesInsertSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 월~금 LME 시작 시간에 1분 단위로 저장 (정각 소캣)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void oneMinutesSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 월~금 LME 시작 시간에 30분 단위로 저장 (정각 1초전)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void halfHoursInsertSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 월~금 LME 시작 시간에 30분 단위로 저장 (정각 소캣)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void halfHoursSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 월~금 LME 시작 시간에 한시간 단위로 저장 (정각 1초전)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void oneHoursInsertSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 월~금 LME 시작 시간에 한시간 단위로 저장 (정각 소캣)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void oneHoursSchedule() throws Exception;
	
	/**
	
	 * <pre>
	 * 처리내용: 월~금 LME 끝나는 시간에 일 데이터 저장 (정각 1초전)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void dayInsertSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 월~금 LME 끝나는 시간에 일 데이터 저장 (정각 소캣)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void daySchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 월~금 LME 끝나는 시간 후 10분 뒤에 다음날 데이터 들어오기 전까지 schedule insert 방지 (휴일때문)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void closeInsertSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 토요일 시작하는 시간에 일주일 데이터 저장 (정각 1초전)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void weekInsertSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 토요일 시작하는 시간에 일주일 데이터 저장 (정각 소캣)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void weekSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 한달의 첫날 처음 시작@Override
	 시간에 데이터 저장 (정각 1초전)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void monthInsertSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 한달의 첫날 처음 시작 시간에 데이터 저장 (정각 소캣)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void monthSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 분기가 바뀌는 처음 날짜의 첫 시간에 분기 데이터 저장 (정각 1초전)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon @Override
	sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void quarterInsertSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 분기가 바뀌는 처음 날짜의 첫 시간에 분기 데이터 저장 (정각 소캣)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void quarterSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 1월 1월 시작 시간에 년 데이터 저장 (정각 1초전)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void yearInsertSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 1월 1월 시작 시간에 년 데이터 저장 (정각 소캣)
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void yearSchedule() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 일분단위 Process
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * 2021. 11. 16.		Kwon sun hyung		수정
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isInsertProcess
	 * @throws Exception
	 */
	void oneMinutesProcess(boolean isResetProcess) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 30분단위 Process
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void halfHoursProcess(boolean isResetProcess) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 한시간단위 Process
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void oneHoursProcess(boolean isResetProcess) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 하루단위 Process
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void dayProcess(boolean isResetProcess) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주단위 Process
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void weekProcess(boolean isResetProcess) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 한달단위 Process
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void monthProcess(boolean isResetProcess) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 분기단위 Process
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void quarterProcess(boolean isResetProcess) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 년단위 Process
	 * </pre>
	 * @date 2021. 11. 3.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 3.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void yearProcess(boolean isResetProcess) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 하루단위 Sel Process
	 * </pre>
	 * @date 2021. 12. 23.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param dayMetalCodeList
	 * @throws Exception
	 */
	void dayProcessSel(List<String> dayMetalCodeList) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 하루단위 Lme Process
	 * </pre>
	 * @date 2021. 12. 23.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isResetProcess
	 * @throws Exception
	 */
	//void dayProcessLme(boolean isResetProcess) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주단위 LME Process
	 * </pre>
	 * @date 2021. 12. 23.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isResetProcess
	 * @throws Exception
	 */
	//void weekProcessLme(boolean isResetProcess) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주단위 Sel Process
	 * </pre>
	 * @date 2021. 12. 23.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param dayMetalCodeList
	 * @throws Exception
	 */
	void weekProcessSel(List<String> dayMetalCodeList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 달단위 Lme Process
	 * </pre>
	 * @date 2021. 12. 23.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isResetProcess
	 * @throws Exception
	 */
	//void monthProcessLme(boolean isResetProcess) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 달단위 Sel Process
	 * </pre>
	 * @date 2021. 12. 23.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param dayMetalCodeList
	 * @throws Exception
	 */
	void monthProcessSel(List<String> dayMetalCodeList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주기단위 Lme Process
	 * </pre>
	 * @date 2021. 12. 23.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isResetProcess
	 * @throws Exception
	 */
	//void quarterProcessLme(boolean isResetProcess) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주기단위 Sel Process
	 * </pre>
	 * @date 2021. 12. 23.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param dayMetalCodeList
	 * @throws Exception
	 */
	void quarterProcessSel(List<String> dayMetalCodeList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 년단위 Lme Process
	 * </pre>
	 * @date 2021. 12. 23.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isResetProcess
	 * @throws Exception
	 */
	//void yearProcessLme(boolean isResetProcess) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 년단위 Sel Process
	 * </pre>
	 * @date 2021. 12. 23.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param dayMetalCodeList
	 * @throws Exception
	 */
	void yearProcessSel(List<String> dayMetalCodeList) throws Exception;

	
	/**
	 * <pre>
	 * 처리내용: lme가 끝날 시간에 동작하는 insert scheduler
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void overDayInsertScheduleLme() throws Exception;

	
	/**
	 * <pre>
	 * 처리내용: lme가 끝날 시간에 동작하는 scheduler
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void overDayScheduleLme() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 매 분마다 동작하는 판매가격 insert scheduler
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	//void overDayInsertScheduleSel() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 매 분마다 동작하는 판매가격 scheduler
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void overDayScheduleSel() throws Exception;

	/**
	 * <pre>
	 * 처리내용: procedure를 사용하는 lme day process
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isResetProcess
	 * @throws Exception
	 */
	void dayProcessLmeForProcedure(boolean isResetProcess) throws Exception;

	/**
	 * <pre>
	 * 처리내용: procedure를 사용하는 sel day process
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isResetProcess
	 * @throws Exception
	 */
	void dayProcessSelForProcedure(boolean isResetProcess) throws Exception;

	/**
	 * <pre>
	 * 처리내용: procedure를 사용하는 lme week process
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isResetProcess
	 * @throws Exception
	 */
	void weekProcessLmeForProcedure(boolean isResetProcess) throws Exception;

	/**
	 * <pre>
	 * 처리내용: procedure를 사용하는 sel day process
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isResetProcess
	 * @throws Exception
	 */
	void weekProcessSelForProcedure(boolean isResetProcess) throws Exception;

	/**
	 * <pre>
	 * 처리내용: procedure를 사용하는 lme month process
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isResetProcess
	 * @throws Exception
	 */
	void monthProcessLmeForProcedure(boolean isResetProcess) throws Exception;

	/**
	 * <pre>
	 * 처리내용: procedure를 사용하는 sel month process
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isResetProcess
	 * @throws Exception
	 */
	void monthProcessSelForProcedure(boolean isResetProcess) throws Exception;

	/**
	 * <pre>
	 * 처리내용: procedure를 사용하는 lme quarter process
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isResetProcess
	 * @throws Exception
	 */
	void quarterProcessLmeForProcedure(boolean isResetProcess) throws Exception;

	/**
	 * <pre>
	 * 처리내용: procedure를 사용하는 sel quarter process
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isResetProcess
	 * @throws Exception
	 */
	void quarterProcessSelForProcedure(boolean isResetProcess) throws Exception;

	/**
	 * <pre>
	 * 처리내용: procedure를 사용하는 lme year process
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isResetProcess
	 * @throws Exception
	 */
	void yearProcessLmeForProcedure(boolean isResetProcess) throws Exception;

	/**
	 * <pre>
	 * 처리내용: procedure를 사용하는 sel year process
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param isResetProcess
	 * @throws Exception
	 */
	void yearProcessSelForProcedure(boolean isResetProcess) throws Exception;

	/**
	 * <pre>
	 * 처리내용: lme data가 일분 이내에 제대로 들어오는지 확인한다.
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 */
	void checkLmeSendDataInOneMinuteSchedule();

	/**
	 * <pre>
	 * 처리내용: 매 분 시초가의 시기를 결정하는 boolean 타입의 변수를 셋팅하는 스케쥴
	 * </pre>
	 * @date 2022. 1. 24.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 24.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 */
	//void setReadyToLmeStartDataSchedule();
	
	/**
	 * <pre>
	 * 처리내용: 매주 일요일 마다 LME, 판매가격 데이터 delete scheduler
	 * </pre>
	 * @date 2022. 3. 16.
	 * @author srec0004
	 * @history  
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 3. 16.		srec0004		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	void weeklyDataDeleteSchedule();

	/**
	 * <pre>
	 * 처리내용: 케이지트레이딩 운영 시작시간을 체크한다.
	 * </pre>
	 * @date 2022. 5. 11.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 11.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 */
	void checkSorinRealSellBeginTimeSchedule();

	/**
	 * <pre>
	 * 처리내용: 월-금 오전 4시에 동작하는 insert scheduler (월단위 일자별 누적평균가 현황 테이블에 데이터 저장)
	 * </pre>
	 * @date 2022. 10. 31.
	 * @author hyunjin05
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 10. 31.		hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void StEvemthAccmlDalyAvgPcInsertSchedule() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 월-금 1분마다 동작하는 scheduler (조달청 대비 가격하락 비교)
	 * </pre>
	 * @date 2023. 04. 27.
	 * @author srec0068
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일					작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 04. 27.		srec0068		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @throws Exception
	 */
	void checkFallSelPcSchedule() throws Exception;

	//void initSelPremiumAmount() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 차트 타이틀 초기화
	 * </pre>
	 * @date 2023. 7. 12.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 12.			srec0064			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	void chartTitleSchedule() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 다이버 발동 조건 체크
	 * </pre>
	 * @date 2024. 1. 12.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 0. 12.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	void diverScheduler() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 레디스 프리미엄 정보 삭제,재생성
	 * </pre>
	 * @date 2024. 5. 31.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 5. 31.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	void redisPremiumInfoClean() throws Exception;
}
