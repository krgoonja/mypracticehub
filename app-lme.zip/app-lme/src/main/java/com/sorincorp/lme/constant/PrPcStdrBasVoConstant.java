package com.sorincorp.lme.constant;

public class PrPcStdrBasVoConstant {
	
	public static final String STDR = "STDR";
	
	public static final String RLTM = "RLTM";
	
	public static final String ONE_MINUTE = "ONEMINUTE";
	
	public static final String PAST_ONE_MINUTE = "PASTONEMINUTE";
	
	public static final String THIRTY_MINUTE = "THIRTYMINUTE";

	public static final String PAST_THIRTY_MINUTE = "PASTTHIRTYMINUTE";
	
	public static final String SIXTY_MINUTE = "SIXTYMINUTE";
	
	public static final String PAST_SIXTY_MINUTE = "PASTSIXTYMINUTE";
	
	public static final String DAY = "DAY";
	
	public static final String PAST_DAY = "PASTDAY";
	
	public static final String WEEK = "WEEK";
	
	public static final String PAST_WEEK = "PASTWEEK";
	
	public static final String MONTH = "MONTH";
	
	public static final String PAST_MONTH = "PASTMONTH";
	
	public static final String QUARTER = "QUARTER";
	
	public static final String PAST_QUARTER = "PASTQUARTER";
	
	public static final String YEAR = "YEAR";
	
	public static final String PAST_YEAR = "PASTYEAR";
	
	public static final String NICKEL = "NICKEL";
	
	public static final String PAST_NICKEL = "PASTNICKEL";
	
	public static final String ONE_MINUTE_NUMBER = "01";
	
	public static final String THIRTY_MINUTE_NUMBER = "30";
	
	public static final String SIXTY_MINUTE_NUMBER = "60";
}