package com.sorincorp.lme.spclty.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class IfLmeSpcltyLoVo implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = -7297016277924788419L;
	/**
     * 수신일시
    */
    private String receptDatetime;
    /**
     * 전문타입
    */
    private String type;
    /**
     * 품목코드
    */
    private String metalCode;
    /**
     * 내부코드
    */
    private String innerCode;
    /**
     * 미결제
    */
    private String opint;
    /**
     * 미결제중량
    */
    private String opintnc;
    /**
     * 기준일자
    */
    private String opintDate;
}