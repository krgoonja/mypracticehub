package com.sorincorp.lme.pc.service;

import com.sorincorp.lme.pc.model.PrLmeEvlPcBasVo;

public interface PrLmeEvlPcBasVoMapService {
	
	PrLmeEvlPcBasVo getPrLmeEvlPcBasVo(String metalCodeByProperties);
}