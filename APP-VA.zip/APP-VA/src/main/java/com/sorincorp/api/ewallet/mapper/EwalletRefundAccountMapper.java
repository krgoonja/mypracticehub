package com.sorincorp.api.ewallet.mapper;

import com.sorincorp.api.ewallet.comm.entity.EwalletRefundAccountEntity;
import com.sorincorp.api.ewallet.model.EwalletRefundAccountVO;

public interface EwalletRefundAccountMapper {

	void updateRefndAcnutSttusCode(EwalletRefundAccountVO ewalletRefundAccountVO) throws Exception;

	void insertMbEntrpsInfoBasHst(EwalletRefundAccountVO ewalletRefundAccountVO) throws Exception;

	void insertIfEwalletAcnutRegistRequst(EwalletRefundAccountEntity accountEntity) throws Exception;

	void insertIfEwalletAcnutRegistRspns(EwalletRefundAccountVO ifVO) throws Exception;

	void updateIfEwalletAcnutRegistRequst(EwalletRefundAccountVO ifVO) throws Exception;

	void updateOpEwalletAcnutBas(EwalletRefundAccountVO ewalletRefundAccountVO) throws Exception;

	void insertOpEwalletAcnutDtl(EwalletRefundAccountVO ewalletRefundAccountVO) throws Exception;

	void insertOpEwalletAcnutBasHst(EwalletRefundAccountVO ewalletRefundAccountVO) throws Exception;

	void insertOpEwalletAcnutDtlHst(EwalletRefundAccountVO ewalletRefundAccountVO) throws Exception;

	void updateOpEwalletAcnutDtl(EwalletRefundAccountVO ewalletRefundAccountVO) throws Exception;

}
