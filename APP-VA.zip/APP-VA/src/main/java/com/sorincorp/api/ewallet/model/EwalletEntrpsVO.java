package com.sorincorp.api.ewallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EwalletEntrpsVO {
	
	/** 업체번호 **/
	private String entrpsNo;
	
	/** 업체 사업자 등록 번호**/
	private String bsnmRegistNo;

	/** Ewallet 가상 계좌 번호 **/
	private String ewalletAcnutNo;
	
	/** Ewallet 고객 환불 계좌 번호 **/
	private String refndAcnutNo;
	
	/** 서린상사 정산 계좌 **/
	private String sorinAcnutNo;
	
	public EwalletEntrpsVO(String entrpsNo) {
		this.entrpsNo = entrpsNo;
	}
	
}
