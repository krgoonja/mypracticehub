package com.sorincorp.api.ewallet.model;

import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EwalletAccountVO {
	
	/** 업체번호 **/
	@NotEmpty(message = "업체 번호 미존재")
	private String entrpsNo;
	
	/** Ewallet 가상 계좌 번호 **/
	private String ewalletAcnutNo;
	
	/** 거래 일자 **/
	private String delngDe;
	
	/** 거래 일련 번호 **/
	private String delngSeqNo;
	
	/** 거래 금액 ( 잔액 ) **/
	private String delngAmount;
	
	private String testCode; // 테스트 완료 후 제거 20211115
	
	/**
	 * 지정가 구분 [가격 도달 시 진행되는 주문: touch, 그 외: null]
	 */
	private String limitSection;
	
	/**
	 * 잔액 조회 대기 시간 설정(초)
	 * (default : 5초, 지정가 touch 시 3초, accoutWaitSecond 파라미터 설정 시 설정 값을 우선)
	 */
	private Integer accoutWaitSecond;
	
	public EwalletAccountVO(String entrpsNo) {
		this.entrpsNo = entrpsNo;
	}

}
