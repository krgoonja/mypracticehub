package com.sorincorp.api.ewallet.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class EntrpsInfoBasVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -1931941362671251964L;

	private String entrpsNo;
	private String entrpsNm;
	private String mberNm;
	private String mberNo;
	private String moblphonNo;
	private String orderCnt;
	private String cryalTlphonNo;
	private String emplNm;

}
