/**
 *
 */
package com.sorincorp.api.ewallet.mapper;

import com.sorincorp.api.ewallet.comm.entity.AccountRcpmnyEntity;
import com.sorincorp.api.ewallet.model.EntrpsInfoBasVO;
import com.sorincorp.api.ewallet.model.EwalletAcnutDelngVO;
import java.util.List;

import io.lettuce.core.dynamic.annotation.Param;

/**
 * AccountRcpmnyMapper.java
 * @version
 * @since 2021. 8. 27.
 * @author srec0009
 */
public interface EwalletAcnutDelngMapper {
	/**
	 * <pre>
	 * 처리내용: 이월렛 거래 내역 입력
	 * </pre>
	 * @date 2021. 8. 27.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 27.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	int insertEwalletDelng(EwalletAcnutDelngVO vo);


	/**
	 * <pre>
	 * 처리내용: 업체 번호 조회
	 * </pre>
	 * @date 2021. 8. 27.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 27.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param ewalletAcnutNo
	 * @return
	 */
	String selectEntrpsNo(@Param("ewalletAcnutNo") String ewalletAcnutNo);


	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 9. 29.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 29.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param accountRcpmnyEntity
	 */
	void insertIfEwalletDelngRequst(AccountRcpmnyEntity accountRcpmnyEntity);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param accountRcpmnyEntity
	 */
	void insertIfEwalletDelngRspns(AccountRcpmnyEntity accountRcpmnyEntity);


	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param accountRcpmnyEntity
	 */
	void updateIfEwalletDelngRequst(AccountRcpmnyEntity accountRcpmnyEntity);

	EntrpsInfoBasVO selectEntrpsInfoBas(String entrpsNo);

	List<EntrpsInfoBasVO> selectEmplList(String smsSndngGroupCode);


}
