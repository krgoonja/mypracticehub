package com.sorincorp.api.ewallet.comm.entity;

import com.sorincorp.api.ewallet.comm.annotaion.ByteLimit;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = false)
@ToString(callSuper = true)
public class AccountConfmEntity extends EwalletBaseEntity{

	public AccountConfmEntity() {

		/* LENGTH */
		super.setBase1("0350");

		/* 취급기관코드 */
		super.setBase7("00000081");

		/* 전문구분코드(MSG TYPE) */
		super.setBase11("0210");

		/* 거래구분코드 */
		super.setBase12("7360");

		/* 항목구분코드 */
		super.setBase13("0000");

		/* 거래일련번호 */
		super.setBase17("0000000");

		/* 이체거래시 입출기관구분 */
		super.setBase28("0");

	}

    /**
    * 가상 계좌 번호
   */
	@ByteLimit(limit = 16, example = "0", repeat = true)
   private String virtlAcnutNo;
    /**
    * 계좌 확인 여부
   */
	@ByteLimit(limit = 1, example = "N", repeat = true)
   private String acnutCnfirmAt;
    /**
    * 서비스 동의 여부
   */
	@ByteLimit(limit = 1, example = "N", repeat = true)
   private String svcAgreAt;
    /**
    * 필러
   */
   private String fil;
    /**
    * 최초 등록자 아이디
   */
   private String frstRegisterId;
    /**
    * 최초 등록 일시
   */
   private String frstRegistDt;
    /**
    * 최종 변경자 아이디
   */
   private String lastChangerId;
    /**
    * 최종 변경 일시
   */
   private String lastChangeDt;
    /**
    * 응답 상태
    * :초기 0 / 응답 1/ 원장테이블 업데이트 2
   */
   private int rspnsSttus;

   private int intrfcSn;
}
