package com.sorincorp.api.ewallet.service;

import java.text.ParseException;

import com.sorincorp.api.ewallet.comm.entity.EwalletBaseEntity;
import com.sorincorp.api.ewallet.model.EwalletAccountVO;
import com.sorincorp.api.ewallet.model.EwalletAcnutDelngVO;
import com.sorincorp.api.ewallet.model.EwalletManageVO;
import com.sorincorp.api.ewallet.model.EwalletResultVO;
import com.sorincorp.api.ewallet.model.EwalletTransferVO;
import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.pcInfo.model.PrSelVO;

public interface EwalletService {
	
	/**
	 * <pre>
	 * 처리내용: API 서버 호출 테스트
	 * </pre>
	 * @date 2022. 9. 21.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 21.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param ewalletOrderVO
	 * @return
	 * @throws Exception
	 */
	EwalletAccountVO ewalletApiCallTest(EwalletAccountVO ewalletOrderVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 업체번호 기준 가상계좌 잔액조회 전문을 호출한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param ewalletOrderVO
	 * @return
	 * @throws Exception
	 */
	EwalletAccountVO ewalletAccountMoney(EwalletAccountVO ewalletOrderVO) throws Exception;

	public void vaEwalletTest(EwalletTransferVO ewalletTransferVO, int a) throws CommCustomException, Exception;
	
	/**
	 * <pre>
	 * 처리내용: 이월렛 가상계좌 거래 전문을 호출한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param ewalletTransferVO
	 * @throws Exception
	 */
	void ewalletDoTransfer(EwalletTransferVO ewalletTransferVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 현재 가장계좌의 잔액을 응답받는다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param receiveByte
	 * @throws Exception
	 */
	void ewalletResChkAccountMoney(byte[] receiveByte) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이월렛 가상계좌 거래 전문을 응답받는다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param receiveByte
	 * @throws Exception
	 */
	void ewalletResDoTransfer(byte[] receiveByte) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 입금 발생 시 (전자상거래보증 or 서린크레딧) 결제 예정 리스트((전자상거래보증 or 서린크레딧) 및 추가 금액 발생과 (이월렛 or 증거금)의 추가 금액 발생, 결제예정일(+1이상) 주문 결제 건)이 있을 경우, 입금 후 잔액으로 남은 주문 결제 건을 상환한다.
	 * 입금에 의한 담보 보증 상환 처리 및 추가 금액 처리
	 * 대상 : (전자상거래보증 or 서린크레딧) 결제 예정 리스트((전자상거래보증 or 서린크레딧) 및 추가 금액 발생과 (이월렛 or 증거금)의 추가 금액 발생, 결제예정일(+1이상) 주문 결제 건)
	 * </pre>
	 * @date 2022. 8. 18.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 18.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @throws Exception
	 */
	void mrtggGrntyRepyByRcpmny(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이체 처리결과 전문을 호출한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param ewalletResultVO
	 * @return
	 * @throws Exception
	 */
	EwalletResultVO ewalletChkTransfer(EwalletResultVO ewalletResultVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이체 처리결과 전문을 응답받는다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param receiveByte
	 * @throws Exception
	 */
	void ewalletResChkTransfer(byte[] receiveByte) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이체 및 환분거래에대한 하나은행측 전문을 취소하는 요청을 받는다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param receiveByte
	 * @throws Exception
	 */
	void ewalletResCancelTransfer(byte[] receiveByte) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 개시전문을 응답받는다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param receiveByte
	 * @throws Exception
	 */
	void ewalletResStartBank(byte[] receiveByte) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 종료 전문을 응답받는다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param receiveByte
	 * @throws Exception
	 */
	void ewalletResEndBank(byte[] receiveByte) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 응답받은 전문이 폴링 전문인지 체크한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param receiveByte
	 * @return
	 * @throws Exception
	 */
	byte[] ewalletPollingChk(byte[] receiveByte) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 장애전문을 응답받는다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param receiveByte
	 * @throws Exception
	 */
	void ewalletResErrorBank(byte[] receiveByte) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 장애 해제 전문을 응답받는다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param receiveByte
	 * @throws Exception
	 */
	void ewalletResErrorCancelBank(byte[] receiveByte) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 서린상사측 관리전문을 호출한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param ewalletManageVO
	 * @throws Exception
	 */
	void ewalletManage(EwalletManageVO ewalletManageVO) throws Exception;


	/**
	 * <pre>
	 * 처리내용: 서린상사 관리자에게 입금 메시지를 발송한다.
	 * </pre>
	 * @date 2022. 03. 29.
	 * @author sjham
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 03. 29.		sjham				최초작성
	 * ------------------------------------------------
	 * @param1 EwalletAcnutDelngVO
	 * @param2 EwalletBaseEntity
	 * @param3 type("E":EMAIL, "S":SMS)
	 * @throws Exception
	 */
	void sendToAdmAccountRcpmnyMsg(EwalletAcnutDelngVO ewalletAcnutDelngVO, EwalletBaseEntity ewalletEntity, String type) throws Exception;

	PrSelVO getNewestPrSelRltm(String metalCode, Integer itemSn, String dstrcLclsfCode, String brandGroupCode,
			String brandCode, String occrrncDe) throws Exception;

	String dateFormatter(String dateFormat, int formatType) throws ParseException;
}
