package com.sorincorp.api.ewallet.comm.handler;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.api.ewallet.comm.constant.EwalletConstant;
import com.sorincorp.api.ewallet.comm.util.EwalletCommUtil;
import com.sorincorp.api.ewallet.service.EwalletAcnutRcpmnyService;
import com.sorincorp.api.ewallet.service.EwalletRefundAccountService;
import com.sorincorp.api.ewallet.service.EwalletService;
import com.sorincorp.api.ewallet.service.EwalletUseRegistConfmService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ServiceCallHandler implements ServiceCall{

    @Autowired
    private EwalletUseRegistConfmService ewalletUseRegistConfmService;

    @Autowired
    private EwalletAcnutRcpmnyService ewalletAcnutRcpmnyService;

    @Autowired
    private EwalletService ewalletService;

    @Autowired
    private EwalletRefundAccountService ewalletRefundAccountService;


    @Override
    public void serviceCallByClient(byte[] receiveByte) throws Exception {

        /** 수신 받은 전문에서 전문 구분코드(MSG_TYPE) 추출 **/
        String msgType = EwalletCommUtil.getIndexStr(receiveByte
                            , EwalletConstant.EWALLET_TCP_COMMON_MSG_TYPE_INDEX
                            , EwalletConstant.EWALLET_TCP_COMMON_MSG_TYPE_LENGTH);

        /** 수신 받은 전문에서 거래 구분코드(API_TYPE) 추출 **/
        String callType = EwalletCommUtil.getIndexStr(receiveByte
			                , EwalletConstant.EWALLET_TCP_COMMON_API_TYPE_INDEX
			                , EwalletConstant.EWALLET_TCP_COMMON_API_TYPE_LENGTH);

        if(StringUtils.equals("0200", msgType) || StringUtils.equals("0210", msgType)) {
            // TODO 본인의 거래 구분코드에 맞는 로직에 서비스 연결 참고 (하나은행전문설계서 페이지 8 )
            switch(callType) {

                /** 계좌입금 **/
                case "1100" : ewalletAcnutRcpmnyService.insertAccountRcpmny(receiveByte); break;

                /** 잔액조회 **/
                case "2100" : ewalletService.ewalletResChkAccountMoney(receiveByte);break;

                /** 수취조회 **/
                case "4100" :ewalletService.ewalletResChkTransfer(receiveByte);break;

                /** 계좌출금이체 **/
                case "5100" : ewalletService.ewalletResDoTransfer(receiveByte);break;

                /** 에스크로 환불 계좌 등록 **/
                case "7350" :
                	ewalletRefundAccountService.reciveResponseData(receiveByte);
                	break;

                /** 에스크로 가상계좌 사용등록 통지 **/
                case "7360" : ewalletUseRegistConfmService.ewalletUseRegistConfm(receiveByte); break;

                /** 이체처리결과조회 **/
                case "6013" :  ewalletService.ewalletResChkTransfer(receiveByte);break;

            }

        }else if(StringUtils.equals("0400", msgType) || StringUtils.equals("0410", msgType)) {
            // TODO 본인의 거래 구분코드에 서비스 로직 연결  ( 참고 : 하나은행전문설계서 페이지 8 )
            switch(callType) {

                /** 계좌 입금 취소**/
                case "1100" : ewalletAcnutRcpmnyService.insertAcnutRcpmnyCancel(receiveByte); break;
                /** 취소 (환불) **/
                case "5100" : ewalletService.ewalletResCancelTransfer(receiveByte);break;

            }

        }else if(StringUtils.equals("0800", msgType) || StringUtils.equals("0810", msgType)) {
            log.debug(">> 관리 전문 msgType : " + msgType + ", callType : " + callType);
        	// TODO 관리 전문 으로 아직 정책 미정
        	switch(callType) {

	            /** 개시 **/
	            case "2100" : ewalletService.ewalletResStartBank(receiveByte); break;
	            /** 종료 **/
	            case "2400" : ewalletService.ewalletResEndBank(receiveByte);break;
	            /** 장애 **/
	            case "2500" : ewalletService.ewalletResErrorBank(receiveByte);break;
	            /** 장애해제 **/
	            case "2600" : ewalletService.ewalletResErrorCancelBank(receiveByte);break;

        	}
        }

    }


	@Override
	public boolean pollingChk(byte[] receiveByte) throws Exception {
		 boolean isPolling = false;
        /** 전문 POLLING 케이스 **/
        String polling =  EwalletCommUtil.getIndexStr(receiveByte
			                , EwalletConstant.EWALLET_TCP_POLLING_INDEX
			                , EwalletConstant.EWALLET_TCP_POLLING_LENGTH);

        if(StringUtils.equals(polling, EwalletConstant.EWALLET_TCP_POLLING)) {
        	isPolling = true;
        }
        return isPolling;
	}

}