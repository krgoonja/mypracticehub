/**
 *
 */
package com.sorincorp.api.ewallet.service;

/**
 * AccountRcpmnyService.java
 * @version
 * @since 2021. 8. 26.
 * @author srec0009
 */
public interface EwalletAcnutRcpmnyService {

	/**
	 * <pre>
	 * 처리내용: 이월렛 계좌 입금
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 26.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param receiveByte
	 * @throws Exception
	 */
	void insertAccountRcpmny(byte[] receiveByte) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이월렛 계좌 입금 취소
	 * </pre>
	 * @date 2021. 8. 27.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 27.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param receiveByte
	 */
	void insertAcnutRcpmnyCancel(byte[] receiveByte) throws Exception;

}
