package com.sorincorp.api.ewallet.schedule;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.sorincorp.api.ewallet.client.socket.EwalletClientSocket;
import com.sorincorp.api.ewallet.comm.constant.EwalletConstant;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class PollingSchedule {
	
	@Autowired
	private EwalletClientSocket ewalletClientSocket;
	
	@Value("${ewallet.client.polling.req.prefix}")
	private String pollingReqPrefix;
	
	@Scheduled(fixedDelayString = "${ewallet.client.polling.delay}")
	public void doPollingSchedule() {
		String nowDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMddHHmmss"));
		String pollingStr = pollingReqPrefix + nowDate;
		try {
			log.debug("Client Polling Send : " + pollingStr);
			byte[] receiveByte = ewalletClientSocket.sendReceiveEwallet(pollingStr.getBytes(EwalletConstant.EWALLET_DEFAULT_ENCODING));
			log.debug("Client Polling Receive : " + new String(receiveByte, EwalletConstant.EWALLET_DEFAULT_ENCODING));
		}catch (Exception e) {
			log.error("Client Polling Error : " + e);
		}
	}

}
