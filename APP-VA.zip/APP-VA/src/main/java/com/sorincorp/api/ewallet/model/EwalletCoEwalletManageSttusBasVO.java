/**
 * 
 */
package com.sorincorp.api.ewallet.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * EwalletCoEwalletManageSttusBasVO.java
 * @version
 * @since 2021. 12. 13.
 * @author srec0049
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EwalletCoEwalletManageSttusBasVO {
	
	/**
     * 이월렛 인터페이스 구분 코드
    */
    private String ewalletIntrfcSeCode;
    
    /**
     * 이월렛 요청 구분 코드
    */
    private String ewalletRequstSeCode;
    
    /**
     * 이월렛 요청 기관 코드
    */
    private String ewalletRequstInsttCode;
    
    /**
     * 이월렛 연계 상태 구분 코드
    */
    private String ewalletCntcSttusSeCode;
}
