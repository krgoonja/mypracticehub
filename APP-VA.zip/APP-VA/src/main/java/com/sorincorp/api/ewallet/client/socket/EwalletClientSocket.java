package com.sorincorp.api.ewallet.client.socket;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.google.common.io.ByteStreams;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class EwalletClientSocket {
	
	@Value("${ewallet.client.host.outbound}")
	private String outboundHost;
	
	@Value("${ewallet.client.port}")
    private int port;
	
	@Value("${ewallet.client.connect.timeout}")
    private int connectTimeout;
	
	@Value("${ewallet.client.read.timeout}")
    private int readTimeout;
	
	@Value("${ewallet.client.delay.time}")
    private int delayTime;
	
	Socket socket = null;
	SocketAddress address = null;
	
	public Socket socket() throws Exception {
		if(socket == null) {
			log.debug(">> socket is null");
		} else {
			log.debug(">> socket.isClosed() : " + socket.isClosed() + ", socket.isConnected() : " + socket.isConnected());
		}
		
		try {
			if(socket == null || !socket.isConnected()) {
				socket = new Socket();
				address = new InetSocketAddress(outboundHost, port);
		        /** 연결 시간 타임아웃 **/
		    	socket.connect(address, connectTimeout);
		    	/** 읽는 시간 타임아웃 **/
		    	socket.setSoTimeout(readTimeout);
			} else {
				log.debug(">> socket 연결 유지");
			}
		} catch(Exception e) {
			log.debug(">> socket 연결 실패 " + e.getMessage());
		}
        return socket;
	}
	
	/**
	 * <pre>
	 * 처리내용: 소켓 유지를 위한 소스 변경으로 동기화 설정 메소드가 필요하여 공통 사용 메소드 생성
	 * param : receiveStatus[true:보내고 받음, false:보내기만 하고 받지 않음]
	 * param : delayStatus[true:설정된 딜레이 시간 적용, false:딜레이하지 않음]
	 * </pre>
	 * @date 2021. 12. 6.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 06.			srec0049			최초작성
	 * 2023. 06. 22.			srec0049			전문을 설정된 딜레이 시간 단위로 보낸다, 줄세우기
	 * ------------------------------------------------
	 * @param sendByte
	 * @param receiveStatus
	 * @param delayStatus
	 * @return
	 */
	private synchronized byte[] sendCommonEwallet(byte[] sendByte, boolean receiveStatus, boolean delayStatus){
		OutputStream os = null;
		InputStream is = null;
		byte[] receiveByte = null;
		
		try {
			log.debug("sendReceiveEwallet start");
			
			socket = socket();
			
			os = socket.getOutputStream();
			os.write(sendByte);
			os.flush();
			
			// 보내고 받는 용도
			if(receiveStatus) {
				is = socket.getInputStream();
				
				receiveByte = new byte[sendByte.length];
				ByteStreams.read(is, receiveByte, 0, receiveByte.length);
			} else {
				// 설정된 시간 단위 줄세우기
				if(delayStatus) {
					Thread.sleep(delayTime);
				}
			}
			
			log.debug("sendReceiveEwallet end");
		}catch (Exception e) {
			log.error("sendReceiveEwallet Error : " + e);
			
			if(os != null) {
				try {
					os.close();
				} catch(Exception oe) {
					log.error("sendReceiveEwallet OutputStream Close Error : " + oe);
				}
			}
			
			if(is != null) {
				try {
					is.close();
				} catch(Exception ie) {
					log.error("sendReceiveEwallet InputStream Close Error : " + ie);
				}
			}
			
			if(socket != null) {
				try {
					socket.close();
				} catch(Exception se) {
					log.error("sendReceiveEwallet Socket Close Error : " + se);
				}
				
				socket = null;
			}
			
		}
		
		return receiveByte;
	}
	
	// 보내기만 하고 받지 않음, receiveStatus : false
	// 전문을 설정된 딜레이 시간 단위로 보낸다, 줄세우기
	public void sendEwallt(byte[] sendByte, boolean delayStatus){
		sendCommonEwallet(sendByte, false, delayStatus);
	}
	
	// 보내고 받음, receiveStatus : true
	public byte[] sendReceiveEwallet(byte[] sendByte) throws Exception {
		return sendCommonEwallet(sendByte, true, false);
	}
	
	public void sendEwalltTest(byte[] sendByte) throws Exception{
//		log.debug("host : " + "10.202.0.4");
		log.debug("host : " + "127.0.0.1");
		log.debug("port : " + "28011");
		log.debug("Client send : "+ new String(sendByte));
		socket = socket();
//		SocketAddress address = new InetSocketAddress("10.202.0.4", 28011);
//		SocketAddress address = new InetSocketAddress("127.0.0.1", 28011);
//        /** 연결 시간 타임아웃 **/
//    	socket.connect(address, connectTimeout);
//    	/** 읽는 시간 타임아웃 **/
//    	socket.setSoTimeout(readTimeout);
		OutputStream os = null;
		try {
			os = socket.getOutputStream();
			os.write(sendByte);
			os.flush();
		}catch(Exception e) {
			log.error("sendEwallt Error : " + e);
		}finally {
//			try {
//				os.close();
//			} catch (IOException e) {
//				log.error("sendEwallt OutputStream Close Error : " + e);
//			}
//			try {
//				socket.close();
//			} catch (IOException e) {
//				log.error("sendEwallt Socket Close Error : " + e);
//			}
		}
	}
}
