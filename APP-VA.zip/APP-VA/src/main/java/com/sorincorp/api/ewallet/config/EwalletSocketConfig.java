package com.sorincorp.api.ewallet.config;

import java.net.InetSocketAddress;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sorincorp.api.ewallet.server.channel.EwalletChannelInitializer;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelOption;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import lombok.RequiredArgsConstructor;

@Configuration
@RequiredArgsConstructor
public class EwalletSocketConfig {

	@Value("${ewallet.server.host}")
    private String host;
	
    @Value("${ewallet.server.port}")
    private int port;
    
    @Value("${ewallet.server.boss-count}")
    private int bossCount;
    
    @Value("${ewallet.server.worker-count}")
    private int workerCount;
    
    @Value("${ewallet.server.keep-alive}")
    private boolean keepAlive;
    
    @Value("${ewallet.server.backlog}")
    private int backlog;

    @Bean
    public ServerBootstrap serverBootstrap(EwalletChannelInitializer ewalletChannelInitializer) {
        // ServerBootstrap: 서버 설정을 도와주는 class
        ServerBootstrap b = new ServerBootstrap();
        b.group(bossGroup(), workerGroup())
                // NioServerSocketChannel: incoming connections를 수락하기 위해 새로운 Channel을 객체화할 때 사용
                .channel(NioServerSocketChannel.class)
                .handler(new LoggingHandler(LogLevel.DEBUG))
                // ChannelInitializer: 새로운 Channel을 구성할 때 사용되는 특별한 handler. 주로 ChannelPipeline으로 구성
                .childHandler(ewalletChannelInitializer);
        
        /** 
         *  ServerBootstarp에 다양한 Option 추가 가능
            기본적으로 자바에서 설정할 수 있는 모든 소켓 옵션 설정 가능
			TCP_NODELAY: Nagle 알고리즘 비활성화 여부 설정
			SO_KEEPALIVE: 정해진 시간마다 keepalive packet 전송
			SO_SNDBUF: 커널 송신 버퍼 크기
			SO_RCVBUF: 커널 수신 버퍼 크기
			SO_REUSEADDR: TIME_WAIT 상태의 포트에도 bind 가능해짐
			SO_LINGER: 소켓을 닫을 때 송신 버퍼에 남은 데이터 전송 대기 시간
			SO_BACKLOG: 동시에 수용 가능한 소켓 연결 요청 수
         **/
        b.option(ChannelOption.SO_BACKLOG, backlog);
        b.childOption(ChannelOption.SO_REUSEADDR, true);
        b.childOption(ChannelOption.TCP_NODELAY, true);
        b.childOption(ChannelOption.SO_LINGER, 0);

        return b;
    }

    // boss: incoming connection을 수락하고, 수락한 connection을 worker에게 등록(register) 해주는  Thread
    @Bean(destroyMethod = "shutdownGracefully")
    public NioEventLoopGroup bossGroup() {
        return new NioEventLoopGroup(bossCount);
    }

    // worker: boss가 수락한 연결의 트래픽 관리 해주는 Thread
    @Bean(destroyMethod = "shutdownGracefully")
    public NioEventLoopGroup workerGroup() {
        return new NioEventLoopGroup(workerCount);
    }

    // IP 소켓 주소(IP 주소, Port 번호)를 구현
    // 도메인 이름으로 객체 생성 가능
    @Bean
    public InetSocketAddress inetSocketAddress() {
        return new InetSocketAddress(port);
    }
    
}
