/**
 *
 */
package com.sorincorp.api.ewallet.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.ewallet.client.socket.EwalletClientSocket;
import com.sorincorp.api.ewallet.comm.constant.EwalletConstant;
import com.sorincorp.api.ewallet.comm.entity.AccountConfmEntity;
import com.sorincorp.api.ewallet.comm.entity.AccountConfmRspnsEntity;
import com.sorincorp.api.ewallet.comm.util.EwalletCommUtil;
import com.sorincorp.api.ewallet.mapper.EwalletUseRegistConfmMapper;
import com.sorincorp.api.ewallet.model.EwalletUseRegistConfmVO;
import com.sorincorp.comm.util.CryptoUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * EwalletUseRegistConfmServiceImpl.java
 * @version
 * @since 2021. 8. 26.
 * @author srec0009
 */
@Slf4j
@Service
public class EwalletUseRegistConfmServiceImpl implements EwalletUseRegistConfmService{

	@Autowired
	private EwalletClientSocket ewalletClientSocket;

	@Autowired
	private EwalletUseRegistConfmMapper ewalletUseRegistConfmMapper;

	public static String VA_EWALLAT_API_ID = "EWALLET_VA";

	public String dateFormatter(String dateFormat) throws ParseException {
		SimpleDateFormat dtFormat = new SimpleDateFormat("yyyyMMddHHmmss");
 		SimpleDateFormat newDtFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // String 타입을 Date 타입으로 변환
 		Date formatDate = dtFormat.parse(dateFormat); // Date타입의 변수를 새롭게 지정한 포맷으로 변환
 		String strNewDtFormat = newDtFormat.format(formatDate);
		return strNewDtFormat;
	}
	/**
	 * 가상계좌 사용등록 승인 통보 된 회원 이월렛 계좌 업데이트
	 * @throws Exception
	 */
	@Override
	public void ewalletUseRegistConfm(byte[] receiveByte) throws Exception {
		AccountConfmEntity accountConfmEntity = EwalletCommUtil.getObjForBytes(receiveByte, AccountConfmEntity.class);

		accountConfmEntity.setFrstRegisterId(VA_EWALLAT_API_ID);
		accountConfmEntity.setLastChangerId(VA_EWALLAT_API_ID);

		if(StringUtils.equals(accountConfmEntity.getBase11(), "0200")) {
			String virtlAcnutNo = accountConfmEntity.getVirtlAcnutNo();
			String virtlAcnutNoEnc14 = virtlAcnutNo.trim();
			String virtlAcnutNoEnc16 = virtlAcnutNo;

			if(virtlAcnutNoEnc14 != null && !"".equals(virtlAcnutNoEnc14)) {
				try {
					log.debug("가상계좌 암호화 전 ==================>" + virtlAcnutNoEnc14);
					virtlAcnutNoEnc14 = CryptoUtil.encryptAES256(virtlAcnutNoEnc14);
					log.debug("가상계좌 암호화 후 ==================>" + virtlAcnutNoEnc14);
				} catch (Exception e) {
					// TODO: handle exception
					log.error("ewalletUseRegistConfm VIRTL_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
				}
			}

			if(virtlAcnutNoEnc16 != null && !"".equals(virtlAcnutNoEnc16)) {
				try {
					log.debug("가상계좌 암호화 전 ==================>" + virtlAcnutNoEnc16);
					virtlAcnutNoEnc16 = CryptoUtil.encryptAES256(virtlAcnutNoEnc16);
					log.debug("가상계좌 암호화 후 ==================>" + virtlAcnutNoEnc16);
				} catch (Exception e) {
					// TODO: handle exception
					log.error("ewalletUseRegistConfm VIRTL_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
				}
			}
			//String entrpsNo = ewalletUseRegistConfmMapper.selectEntrpsNo(virtlAcnutNo);
			String entrpsNo = ewalletUseRegistConfmMapper.selectEntrpsNo(virtlAcnutNoEnc14);
			// 계좌확인
	        String acnutCnfirmAt = accountConfmEntity.getAcnutCnfirmAt();
	        // 서비스 동의여부
	        String svcAgreAt = accountConfmEntity.getSvcAgreAt();
			// 거래일자(YYYYMMDD)
			String ewalletDelngDate = accountConfmEntity.getBase15();
			// 거래시간(HHMMSS)
			String ewalldtDelngTime = accountConfmEntity.getBase16();
			// 이월렛 거래 일시
			String ewalletDelngDt  = ewalletDelngDate + ewalldtDelngTime;
			ewalletDelngDt = dateFormatter(ewalletDelngDt);

			log.debug("[ 파라미터 ] :virtlAcnutNo => " + virtlAcnutNo);
			log.debug("[ 파라미터 ] :virtlAcnutNoEnc14 => " + virtlAcnutNoEnc14);
			log.debug("[ 파라미터 ] :virtlAcnutNoEnc16 => " + virtlAcnutNoEnc16);

			EwalletUseRegistConfmVO vo = new EwalletUseRegistConfmVO();
			//vo.setVirtlAcnutNo(virtlAcnutNo);
			//암호화 가상계좌번호 세팅
			vo.setVirtlAcnutNo(virtlAcnutNoEnc14);
			vo.setAcnutCnfirmAt(acnutCnfirmAt);
			vo.setSvcAgreAt(svcAgreAt);
			vo.setEntrpsNo(entrpsNo);
			vo.setRefndAcnutRgrsynthAt(acnutCnfirmAt);
			vo.setRefndAcnutRgrsynthDt(ewalletDelngDt);
			vo.setLastChangerId(VA_EWALLAT_API_ID);
			log.debug(acnutCnfirmAt);
			log.debug(svcAgreAt);
			AccountConfmRspnsEntity respnsEntity = EwalletCommUtil.getObjForBytes(receiveByte, AccountConfmRspnsEntity.class);

			// 업체 존재하는지 확인
			try {
				String acuntCnt = ewalletUseRegistConfmMapper.selectEntrpsAcuntNo(vo);
				if("1".equals(acuntCnt)) {
					//IF 테이블에 insert 하기전에 암호화 세팅
					accountConfmEntity.setVirtlAcnutNo(virtlAcnutNoEnc16);
					// 인터페이스 요청 테이블 ins :  respnsSttus 1
					ewalletUseRegistConfmMapper.insertIfEwalletAcnutConfmRequst(accountConfmEntity);
					//암호화 가상계좌 평문으로 다시 원복
					accountConfmEntity.setVirtlAcnutNo(virtlAcnutNo);

					// 계좌 확인 여부, 서비스 동의 여부 Y인 경우
					if("Y".equals(acnutCnfirmAt) && "Y".equals(svcAgreAt)) {
						ewalletUseRegistConfmMapper.updateEwalletAccountNo(vo);
						ewalletUseRegistConfmMapper.insertEwalletAccountNoHst(vo);
						//rspnsSttus update (1 -> 2)
						ewalletUseRegistConfmMapper.updateEwalletAcnutConfmRequst(accountConfmEntity);
						// 계좌 확인 여부 N일 경우
					} else if( "N".equals(acnutCnfirmAt)) {
						ewalletUseRegistConfmMapper.updateEwalletAccountRgrsynthAt(vo);
						ewalletUseRegistConfmMapper.insertEwalletAccountNoHst(vo);
						//rspnsSttus update (1 -> 2)
						ewalletUseRegistConfmMapper.updateEwalletAcnutConfmRequst(accountConfmEntity);
					}

					vo.setIntrfcSn(accountConfmEntity.getIntrfcSn());
					ewalletUseRegistConfmMapper.updateOpEwalletAcnutDtl(vo);

					respnsEntity.setBase14("000");
				// 계좌와 일치하는 업체 개수가 1이 아닌 경우
				}else {
					respnsEntity.setBase14("612");
				}
			} catch (Exception e) {
				log.debug("ERROR===================================================="+e.getMessage());
				log.error(e.getMessage());
				respnsEntity.setBase14("777");
			}

			// 송수신 플래그
			respnsEntity.setBase6("5");
			// 전문구분코드
			respnsEntity.setBase11("0210");
			log.debug("가상계좌번호 :: " + virtlAcnutNo);
			log.debug("respnsEntity :: " + respnsEntity);
			byte[] sendByte = EwalletCommUtil.getByte(respnsEntity, EwalletConstant.EWALLET_ACUNT_CONFM_LENGTH);
			log.debug("sendByte :: " + sendByte);

			ewalletClientSocket.sendEwallt(sendByte, false);


			// IF 응답 테이블 insert
			accountConfmEntity.setBase6("5");
			accountConfmEntity.setBase11("0210");
			accountConfmEntity.setBase14(respnsEntity.getBase14());
			//log.debug("sendByte ikobean" + sendByte);
			//IF 응답 테이벌 insert 하기전에 가상계좌번호 암호화
			accountConfmEntity.setVirtlAcnutNo(virtlAcnutNoEnc16);
			ewalletUseRegistConfmMapper.insertIfEwalletAcnutConfmRspns(accountConfmEntity);
		}
	}


}
