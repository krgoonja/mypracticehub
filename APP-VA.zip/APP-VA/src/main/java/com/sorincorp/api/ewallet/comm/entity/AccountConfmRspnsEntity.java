package com.sorincorp.api.ewallet.comm.entity;

import com.sorincorp.api.ewallet.comm.annotaion.ByteLimit;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = false)
@ToString(callSuper = true)
public class AccountConfmRspnsEntity extends EwalletBaseEntity{

	public AccountConfmRspnsEntity() {

		/* LENGTH */
		super.setBase1("0350");

		/* 취급기관코드 */
		super.setBase7("00000081");

		/* 전문구분코드(MSG TYPE) */
		super.setBase11("0210");

		/* 거래구분코드 */
		super.setBase12("7360");

		/* 항목구분코드 */
		super.setBase13("0000");

		/* 거래일련번호 */
		super.setBase17("0000000");

		/* 이체거래시 입출기관구분 */
		super.setBase28("0");

	}

    /**
    * 가상 계좌 번호
   */
	@ByteLimit(limit = 16, example = "0", repeat = true)
   private String virtlAcnutNo;
    /**
    * 계좌 확인 여부
   */
	@ByteLimit(limit = 1, example = "N", repeat = true)
   private String acnutCnfirmAt;
    /**
    * 서비스 동의 여부
   */
	@ByteLimit(limit = 1, example = "N", repeat = true)
   private String svcAgreAt;
    /**
    * 필러
   */
	@ByteLimit(limit = 32, example = "", repeat = true)
   private String fil;

}
