package com.sorincorp.api.ewallet.comm.entity;

import com.sorincorp.api.ewallet.comm.annotaion.ByteLimit;
import com.sorincorp.api.ewallet.model.EwalletResultVO;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class EwalletResultEntity extends EwalletBaseEntity{
	
	public EwalletResultEntity(EwalletResultVO ewalletResultVO) {
		
		/* LENGTH */
		super.setBase1("0500");
		
		/* 전문구분코드(MSG TYPE) */
		super.setBase11("0200");
		
		/* 거래구분코드 */
		super.setBase12("6013");
		
		/* 항목구분코드 */
		super.setBase13("0000");
		
		/* 거래일련번호 */
		super.setBase17(ewalletResultVO.getDelngSeqNo());
		
		/* 이체거래시 입출기관구분 */
		super.setBase28("0");
		
		this.result1 = ewalletResultVO.getStdrDe();
		this.result2 = ewalletResultVO.getWonDemandSpcltyNo();
	}
	
	/* 거래일자 */
	@ByteLimit(limit = 8, require = true)
	private String result1;
	
	/* 원요구전문번호 */
	@ByteLimit(limit = 15, require = true)
	private String result2;
	
	/* 전문구분 */
	@ByteLimit(limit = 4, example = " ", repeat = true)
	private String result3;
	
	/* 거래구분 */
	@ByteLimit(limit = 4, example = " ", repeat = true)
	private String result4;
	
	/* 거래금액 */
	@ByteLimit(limit = 13, example = "0", repeat = true)
	private String result5;
	
	/* 입금기관코드 */
	@ByteLimit(limit = 8, example = " ", repeat = true)
	private String result6;
	
	/* 입금계좌번호 */
	@ByteLimit(limit = 16, example = " ", repeat = true)
	private String result7;
	
	/* 출금기관코드 */
	@ByteLimit(limit = 8, example = " ", repeat = true)
	private String result8;
	
	/* 출금계좌번호 */
	@ByteLimit(limit = 16, example = " ", repeat = true)
	private String result9;
	
	/* 정상응답코드 */
	@ByteLimit(limit = 3, example = " ", repeat = true)
	private String result10;
	
	/* 처리시간 */
	@ByteLimit(limit = 6, example = " ", repeat = true)
	private String result11;
	
	/* 취소완료시각 */
	@ByteLimit(limit = 6, example = " ", repeat = true)
	private String result12;
	
	/* 취소응답코드 */
	@ByteLimit(limit = 3, example = " ", repeat = true)
	private String result13;
	
	/* 거래관리번호 */
	@ByteLimit(limit = 12, example = " ", repeat = true)
	private String result14;
	
	/* FILLER */
	@ByteLimit(limit = 78, example = " ", repeat = true)
	private String result15;
	
	
	
}
