package com.sorincorp.api.ewallet.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.sorincorp.api.ewallet.client.socket.EwalletClientSocket;
import com.sorincorp.api.ewallet.comm.constant.EwalletConstant;
import com.sorincorp.api.ewallet.comm.entity.EwalletAccountEntity;
import com.sorincorp.api.ewallet.comm.entity.EwalletBaseEntity;
import com.sorincorp.api.ewallet.comm.entity.EwalletManagerEntity;
import com.sorincorp.api.ewallet.comm.entity.EwalletResultEntity;
import com.sorincorp.api.ewallet.comm.entity.EwalletTransferEntity;
import com.sorincorp.api.ewallet.comm.exception.EwalletCustomException;
import com.sorincorp.api.ewallet.comm.util.EwalletCommHelper;
import com.sorincorp.api.ewallet.comm.util.EwalletCommUtil;
import com.sorincorp.api.ewallet.mapper.EwalletMapper;
import com.sorincorp.api.ewallet.model.EntrpsInfoBasVO;
import com.sorincorp.api.ewallet.model.EwalletAccountVO;
import com.sorincorp.api.ewallet.model.EwalletAcnutDelngVO;
import com.sorincorp.api.ewallet.model.EwalletCoEwalletManageSttusBasVO;
import com.sorincorp.api.ewallet.model.EwalletEntrpsVO;
import com.sorincorp.api.ewallet.model.EwalletManageVO;
import com.sorincorp.api.ewallet.model.EwalletMbRefndRequstHstVO;
import com.sorincorp.api.ewallet.model.EwalletMrtggGrntySetlePrearngeVO;
import com.sorincorp.api.ewallet.model.EwalletResultVO;
import com.sorincorp.api.ewallet.model.EwalletTransferVO;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.cntcsttus.model.CntcSttusVO;
import com.sorincorp.comm.cntcsttus.service.CntcSttusServiceImpl;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.model.CommBlceInfoVO;
import com.sorincorp.comm.order.service.CommFinalBlceCheckService;
import com.sorincorp.comm.order.service.CommLimitOrderService;
import com.sorincorp.comm.pcInfo.mapper.PcInfoMapper;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EwalletServiceImpl implements EwalletService {

	/** 외부 연계 api 호출 모듈 **/
	@Autowired
	private HttpClientHelper httpClientHelper;
	
	@Autowired
	private EwalletCommHelper ewalletCommHelper;
	
	@Autowired
	private EwalletClientSocket ewalletClientSocket;
	
	@Autowired
	private CntcSttusServiceImpl cntcSttusServiceImpl;
	
	@Autowired
	private EwalletMapper ewalletMapper;
	
	@Autowired
	private PcInfoMapper pcInfoMapper;

	@Autowired
	private SMSService smsService;
	
	/** 예수금 포함 최종 잔액 조회 서비스 */
	@Autowired
	private CommFinalBlceCheckService commFinalBlceCheckService;

	/** 지정가 주문 공통 서비스 */
	@Autowired
	private CommLimitOrderService commLimitOrderService;
	
	@Autowired
	private CommonService commonService;
	
	/** 서린상사 정상모계좌 **/
	@Value("${ewallet.sorin.acnutno}")
	private String sorinAcnutNo;

	/** 이월렛 잔액 조회 시간 **/
	@Value("${ewallet.account.timeout}")
	private int accoutWaitSecond;

	/** 이체결과 조회 시간 **/
	@Value("${ewallet.result.timeout}")
	private int resultWaitSecond;
	
	/** 이월렛 상환 결제 처리 URL **/
	@Value("${api.credit.ewallet.repy.url}")
	private String apiCreditEwalletRepyUrl;
	
	/** 담보 처리 URL **/
	@Value("${api.credit.mrtgg.repy.url}")
	private String apiCreditMrtggRepyUrl;
	
	/** 세금계산서 호출 **/
	@Value("${api.taxbill.url}")
	private String taxbillUrl;
	
	
	/**
	 * API 서버 호출 테스트
	 */
	public EwalletAccountVO ewalletApiCallTest(EwalletAccountVO ewalletAccountVO) throws EwalletCustomException, Exception {
		EwalletAccountVO accountVo = new EwalletAccountVO();
		
		log.info(">> [EwalletServiceImpl][ewalletApiCallTest] ewalletAccountVO.getEntrpsNo() : " + ewalletAccountVO.getEntrpsNo());
		
		try {
			// 입금에 의한 담보 보증 상환 처리 및 추가 금액 처리
			this.mrtggGrntyRepyByRcpmny(ewalletAccountVO.getEntrpsNo());
		} catch(Exception e) {
			log.error(">> [EwalletServiceImpl][ewalletApiCallTest] mrtggGrntyRepyByRcpmny 테스트 입금에 의한 담보 보증 상환 처리 또는 추가 금액 발생 처리 실패");
			log.error(e.getMessage(), e);
		}
		
		accountVo.setEntrpsNo(ewalletAccountVO.getEntrpsNo());
		
		return accountVo;
	}
	
	@Override
	public EwalletAccountVO ewalletAccountMoney(EwalletAccountVO ewalletAccountVO) throws EwalletCustomException, Exception {
		EwalletAccountVO accountVo = null;

		/** 업체 정보 조회 **/
		EwalletEntrpsVO entrpsInfo = Optional.ofNullable(ewalletMapper.selectEntrpsInfo(new EwalletEntrpsVO(ewalletAccountVO.getEntrpsNo())))
										.orElseThrow(() -> {return new EwalletCustomException("업체 정보 미 존재");});
		
		/** 조회할 계좌번호 셋팅, 업체 정보 조회의 이월렛 계좌 번호 복호화 **/
		String ewalletAcnutNo = entrpsInfo.getEwalletAcnutNo();
		if(StringUtils.isNotEmpty(ewalletAcnutNo)) {
			try {
				log.debug("이월렛 계좌 번호 복호화 전 ==================>" + ewalletAcnutNo);
				ewalletAcnutNo = CryptoUtil.decryptAES256(ewalletAcnutNo);
				log.debug("이월렛 계좌 번호 복호화 후 ==================>" + ewalletAcnutNo);
				/** 조회할 계좌번호 셋팅 **/
				ewalletAccountVO.setEwalletAcnutNo(ewalletAcnutNo);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletAccountMoney EWALLET_ACNUT_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}
		
//		// 테스트 완료 후 제거 20211115
//		if(StringUtils.equals(ewalletAccountVO.getTestCode(), "1")) {
//			log.debug(">> ewalletAccountMoney > Ewallet 가상 계좌 번호를 미등록 가상계좌(12121212121212)로 임시 설정");
//			ewalletAccountVO.setEwalletAcnutNo("12121212121212");
//		}

		/** 거래 일련 번호 채번 **/
		ewalletAccountVO.setDelngSeqNo(ewalletCommHelper.getEwalletAssign("2"));
		
		/** 하나은행 호출 **/
		EwalletAccountEntity accountEntity = new EwalletAccountEntity(ewalletAccountVO);
		
		log.debug(">> ewalletAccountMoney : " + accountEntity.toString());
		
		byte[] sendByte = EwalletCommUtil.getByte(accountEntity, EwalletConstant.EWALLET_TCP_ACCOUNT_LENGTH);
		ewalletClientSocket.sendEwallt(sendByte, false);

		/** 인터페이스 테이블 저장 **/
		EwalletAccountEntity accountModel = EwalletCommUtil.getObjForBytes(sendByte, EwalletAccountEntity.class);
		
		/** 출금 계좌 번호 암호화 **/
		String account11 = accountModel.getAccount11();
		if(StringUtils.isNotEmpty(account11)) {
			try {
				log.debug("출금 계좌 번호 암호화 전 ==================>" + account11);
				account11 = CryptoUtil.encryptAES256(account11);
				log.debug("출금 계좌 번호 암호화 후 ==================>" + account11);
				/** 출금 계좌 번호 셋팅 **/
				accountModel.setAccount11(account11);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletAccountMoney account11 암호화 DEFRAY_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		
		ewalletMapper.insertAccoutMoneyRequest(accountModel);

		/** 호출 응답 대기 **/
		ewalletAccountVO.setDelngDe(accountModel.getBase15());
		
//		// 전자상거래보증 부분상환 테스트 용도 20220916
//		if(StringUtils.equals("C0240", ewalletAccountVO.getEntrpsNo())) {
//			accountVo = new EwalletAccountVO();
//			accountVo.setDelngAmount("50000000"); // 5천만원
//		} else {
		
		int settingAccoutWaitSecond = 0;
		
		// 잔액 조회 대기 시간 설정(초) 파라미터 값이 존재할 경우 (default : 5초, 지정가 touch 시 3초, accoutWaitSecond 파라미터 설정 시 설정 값을 우선)
		if(ewalletAccountVO.getAccoutWaitSecond() != null) {
			settingAccoutWaitSecond = ewalletAccountVO.getAccoutWaitSecond();
			
			log.info(">> 잔액 조회 대기 시간 설정(초) : " + settingAccoutWaitSecond);
		} else {
			// 지정가 주문 touch 시점일 때, accoutWaitSecond(기본값 5초)를 3초로 변경한다.
			if(StringUtils.equals("touch", ewalletAccountVO.getLimitSection())) {
				settingAccoutWaitSecond = 3;
			} else {
				settingAccoutWaitSecond = accoutWaitSecond;
			}
		}
		
		log.debug(">> settingAccoutWaitSecond : " + settingAccoutWaitSecond);
		
			/** 타임아웃 시간 기준으로 응답 DB를 조회하여 RETURN **/
			for(int i = 0 ; i < settingAccoutWaitSecond * 2  ; i ++) {
				Thread.sleep(500);
				// 요청 후 응답이 왔을 때 응답코드가 정상(000)인지 체크
				accountVo = ewalletMapper.selectAccountMoney(ewalletAccountVO);
				log.warn(">> [ewalletAccountMoney] accountVo : " + String.valueOf(accountVo));
				if(accountVo != null) {
					String delngAmountTemp = accountVo.getDelngAmount(); // 거래금액
					accountVo.setDelngAmount(StringUtils.stripStart(delngAmountTemp, "0")); // 앞에 0 제거
					break;
				}
			}
		
//		}
		
		if(accountVo == null) {
			log.error("ewallet 잔액 조회 대기 시간 초과");
			throw new EwalletCustomException("ewallet 잔액 조회 대기 시간 초과");
		}
		
		return accountVo;
	}

	@Override
	public void ewalletResChkAccountMoney(byte[] receiveByte) throws Exception {
		/** 응답받은 BYTE[]을 객체 FIELD로 셋팅 **/
		EwalletAccountEntity accountEntity = EwalletCommUtil.getObjForBytes(receiveByte, EwalletAccountEntity.class);
		
		/** 출금 계좌 번호 암호화 **/
		String account11 = accountEntity.getAccount11();
		if(StringUtils.isNotEmpty(account11)) {
			try {
				log.debug("출금 계좌 번호 암호화 전 ==================>" + account11);
				account11 = CryptoUtil.encryptAES256(account11);
				log.debug("출금 계좌 번호 암호화 후 ==================>" + account11);
				/** 출금 계좌 번호 셋팅 **/
				accountEntity.setAccount11(account11);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletResChkAccountMoney DEFRAY_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		
		ewalletMapper.insertAccoutMoneyResponse(accountEntity);
		//업체 잔액 업데이트 (회원 측에서 이월렛 잔액 업데이트 메소드 제공시 진행) -> 잔액 업데이트는 안하는걸로 결정 20210916
	}
	
	@Resource(name = "ewalletServerThreadPool")
	private ThreadPoolTaskExecutor ewalletServerThreadPool;
	
	public void vaEwalletTest(EwalletTransferVO ewalletTransferVO, int a) throws CommCustomException, Exception {
		Runnable vaEwalletTestRun = () -> {
			log.info("[vaEwalletTest] in~~");
			try {
				ewalletDoTransfer(ewalletTransferVO);
			} catch (Exception e) {
				log.error("[vaEwalletTest] exception ewalletTransferVO : " + String.valueOf(ewalletTransferVO));
				
				log.error("[vaEwalletTest] e : " + e.getMessage());
				String stacktrace = ExceptionUtils.getStackTrace(e);
				log.error("[vaEwalletTest] stacktrace : " + stacktrace);
			}
		};
		
		ewalletServerThreadPool.execute(vaEwalletTestRun);
	}
	

	@Override
	public void ewalletDoTransfer(EwalletTransferVO ewalletTransferVO) throws EwalletCustomException, Exception {
		/** 업체 정보 조회 **/
		EwalletEntrpsVO entrpsInfo = Optional.ofNullable(ewalletMapper.selectEntrpsInfo(new EwalletEntrpsVO(ewalletTransferVO.getEntrpsNo())))
										.orElseThrow(() -> {return new EwalletCustomException("업체 정보 미 존재");});
		
		log.debug(">> ewalletDoTransfer in~~ ewalletTransferVO");
		log.debug(ewalletTransferVO.toString());
		log.debug(">> ewalletDoTransfer in~~ entrpsInfo");
		log.debug(entrpsInfo.toString());
		
		/** 항목구분코드가 0002(환불)이고 환불 요청 일시에 값이 있으면 서린(FO)에서 환불 요청한 전문이다.
		 * 전문 받은 후 환불 요청 상태 코드를 처리중으로 변경한다. **/
		if( StringUtils.equals(ewalletTransferVO.getIemSeCode(), "0002") && StringUtils.isNotEmpty(ewalletTransferVO.getRefndRequstDt()) ) {
			/** 환불 요청 송신 시 회원_환불 요청 이력을 업데이트 한다. 
			 *  [환불 요청 상태 코드, 환불 요청 처리 일시]
			 * **/
			EwalletMbRefndRequstHstVO ewalletMbRefndRequstHstVO = new EwalletMbRefndRequstHstVO();
			ewalletMbRefndRequstHstVO.setEntrpsNo(StringUtils.trim(ewalletTransferVO.getEntrpsNo()));				// 업체번호
			ewalletMbRefndRequstHstVO.setRefndRequstDt(StringUtils.trim(ewalletTransferVO.getRefndRequstDt()));	// 환불 요청 일시
			ewalletMbRefndRequstHstVO.setRefndRequstMbyCode("01");								// 환불 요청 주체 코드 [01(서린)]
			ewalletMbRefndRequstHstVO.setRefndRequstSttusCode("05");							// 환불 요청 상태 코드 [05(처리중)]
			ewalletMapper.updateMbRefndRequstHst(ewalletMbRefndRequstHstVO);
		}
		
		/** 서린상사 계좌번호 셋팅, 복호화 **/
		String getSorinAcnutNo = sorinAcnutNo;
		if(StringUtils.isNotEmpty(getSorinAcnutNo)) {
			try {
				log.debug("서린상사 계좌 번호 복호화 전 ==================>" + getSorinAcnutNo);
				getSorinAcnutNo = CryptoUtil.decryptAES256(getSorinAcnutNo);
				log.debug("서린상사 계좌 번호 복호화 후 ==================>" + getSorinAcnutNo);
				/** 조회할 계좌번호 셋팅 **/
				ewalletTransferVO.setSorinAcnutNo(getSorinAcnutNo); // 암호화 적용하기 전에 프로퍼티에 암호화된 값으로 교체해야 한다!!!!!!!
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletDoTransfer property[ewallet.sorin.acnutno] CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}
		
//		// 테스트 완료 후 제거 20211115
//		if(StringUtils.equals(ewalletTransferVO.getTestCode(), "2")) {
//			log.debug(">> ewalletDoTransfer > Ewallet 등록된 업체 정산계좌와 다른 계좌 - 서린상사 계좌를(13131313131313)로 임시 설정");
//			ewalletTransferVO.setSorinAcnutNo("13131313131313");
//		}
		
		/** 업체 가상계좌 셋팅, 복호화 **/
		String ewalletAcnutNo = entrpsInfo.getEwalletAcnutNo();
		if(StringUtils.isNotEmpty(ewalletAcnutNo)) {
			try {
				log.debug("이월렛 계좌 번호 복호화 전 ==================>" + ewalletAcnutNo);
				ewalletAcnutNo = CryptoUtil.decryptAES256(ewalletAcnutNo);
				log.debug("이월렛 계좌 번호 복호화 후 ==================>" + ewalletAcnutNo);
				/** 조회할 계좌번호 셋팅 **/
				ewalletTransferVO.setEwalletAcnutNo(ewalletAcnutNo);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletDoTransfer EWALLET_ACNUT_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}
		
//		// 테스트 완료 후 제거 20211115
//		if(StringUtils.equals(ewalletTransferVO.getTestCode(), "1")) {
//			log.debug(">> ewalletDoTransfer > Ewallet 가상 계좌 번호를 미등록 가상계좌(12121212121212)로 임시 설정");
//			ewalletTransferVO.setEwalletAcnutNo("12121212121212");
//		}
		
		/** 업체 환불계좌 셋팅, 복호화 **/
		String refndAcnutNo = entrpsInfo.getRefndAcnutNo();
		if(StringUtils.isNotEmpty(refndAcnutNo)) {
			try {
				log.debug("업체 환불계좌 번호 복호화 전 ==================>" + refndAcnutNo);
				refndAcnutNo = CryptoUtil.decryptAES256(refndAcnutNo);
				log.debug("업체 환불계좌 번호 복호화 후 ==================>" + refndAcnutNo);
				/** 조회할 계좌번호 셋팅 **/
				ewalletTransferVO.setRefndAcnutNo(refndAcnutNo);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletDoTransfer REFND_ACNUT_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}
		
//		// 테스트 완료 후 제거 20211115
//		if(StringUtils.equals(ewalletTransferVO.getTestCode(), "3")) {
//			log.debug(">> ewalletDoTransfer > Ewallet 등록된 업체 정산계좌와 다른 계좌 - 업체 환불계좌를(14141414141414)로 임시 설정");
//			ewalletTransferVO.setRefndAcnutNo("14141414141414");
//		}

		/** 사업자 등록 번호 셋팅 **/
		String bsnmRegistNo = entrpsInfo.getBsnmRegistNo();
		ewalletTransferVO.setBsnmRegistNo(bsnmRegistNo);
		
		/** 거래 일련 번호 채번 **/
		ewalletTransferVO.setDelngSeqNo(ewalletCommHelper.getEwalletAssign("5"));
		
//		// 테스트 완료 후 제거 20211115
//		if(StringUtils.equals(ewalletTransferVO.getTestCode(), "4")) {
//			log.debug(">> ewalletDoTransfer > Ewallet 중복된 거래일련번호(2000001)로 임시 설정, 정산 요청");
//			ewalletTransferVO.setDelngSeqNo("2000001");
//		}

		/** 하나은행 호출 **/
		EwalletTransferEntity transferEntity = new EwalletTransferEntity(ewalletTransferVO);
		byte[] sendByte = EwalletCommUtil.getByte(transferEntity, EwalletConstant.EWALLET_TCP_TRANSFER_LENGTH);
		
		if( StringUtils.equals(ewalletTransferVO.getIemSeCode(), "0001") ) {
			try {
				ewalletClientSocket.sendEwallt(sendByte, true);
				log.debug(">> [이월렛 결제 요청] 신호등 주문 전송 성공");
			} catch(Exception e) {
				log.debug(">> [이월렛 결제 요청] 신호등 주문 전송 실패 : " + ExceptionUtils.getStackTrace(e));
				CntcSttusVO cntcSttusVO = new CntcSttusVO();
				cntcSttusVO.setIntrfcSeCode("50"); // 인터페이스 구분 코드 : INTRFC_SE_CODE [10:LME, 20:환율, 30:FS, 40:FX, 50:V/A]
				cntcSttusVO.setLastChangerId("EWALLET-VA");
				// 실패 시
				cntcSttusVO.setCheckResult(false);
				
				cntcSttusServiceImpl.updateCoCntcSttusBas(cntcSttusVO);
				
				// 주문 이월렛 실패 시 SMS 추가 전송
				String orderNo = Optional.ofNullable(ewalletTransferVO.getOrderNo()).orElse("");
				this.innerDepartmentSendSmsByEwallet(orderNo);
			}
		} else {
			ewalletClientSocket.sendEwallt(sendByte, false);
		}
		
		/** 인터페이스 테이블 저장 **/
		EwalletTransferEntity transferModel = EwalletCommUtil.getObjForBytes(sendByte, EwalletTransferEntity.class);
		
		/** 입금 계좌 번호 암호화 **/
		String transfer7 = transferModel.getTransfer7();
		if(StringUtils.isNotEmpty(transfer7)) {
			try {
				log.debug("입금 계좌 번호 암호화 전 ==================>" + transfer7);
				transfer7 = CryptoUtil.encryptAES256(transfer7);
				log.debug("입금 계좌 번호 암호화 후 ==================>" + transfer7);
				/** 입금 계좌 번호 셋팅 **/
				transferModel.setTransfer7(transfer7);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletDoTransfer RCPMNY_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		
		/** 출금 계좌 번호 암호화 **/
		String transfer11 = transferModel.getTransfer11();
		if(StringUtils.isNotEmpty(transfer11)) {
			try {
				log.debug("출금 계좌 번호 암호화 전 ==================>" + transfer11);
				transfer11 = CryptoUtil.encryptAES256(transfer11);
				log.debug("출금 계좌 번호 암호화 후 ==================>" + transfer11);
				/** 출금 계좌 번호 셋팅 **/
				transferModel.setTransfer11(transfer11);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletDoTransfer DEFRAY_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		
		ewalletMapper.insertDoTransferRequest(transferModel);

	}

	@Override
	public void ewalletResDoTransfer(byte[] receiveByte) throws Exception {
		EwalletTransferEntity transferEntity = EwalletCommUtil.getObjForBytes(receiveByte, EwalletTransferEntity.class);
		
		/** 입금 계좌 번호 암호화 **/
		String transfer7Process1 = transferEntity.getTransfer7();
		String transfer7Process1ForTrim = StringUtils.trim(transferEntity.getTransfer7());
		
		if(StringUtils.isNotEmpty(transfer7Process1)) {
			try {
				log.debug("입금 계좌 번호 암호화 전 ==================>" + transfer7Process1);
				transfer7Process1 = CryptoUtil.encryptAES256(transfer7Process1);
				log.debug("입금 계좌 번호 암호화 후 ==================>" + transfer7Process1);
				/** 입금 계좌 번호 셋팅 **/
				transferEntity.setTransfer7(transfer7Process1);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletResDoTransfer transfer7Process1 RCPMNY_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		
		/** 출금 계좌 번호 암호화 **/
		String transfer11Process1 = transferEntity.getTransfer11();
		String transfer11Process1ForTrim = StringUtils.trim(transferEntity.getTransfer11());
		
		if(StringUtils.isNotEmpty(transfer11Process1)) {
			try {
				log.debug("출금 계좌 번호 암호화 전 ==================>" + transfer11Process1);
				transfer11Process1 = CryptoUtil.encryptAES256(transfer11Process1);
				log.debug("출금 계좌 번호 암호화 후 ==================>" + transfer11Process1);
				/** 출금 계좌 번호 셋팅 **/
				transferEntity.setTransfer11(transfer11Process1);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletResDoTransfer transfer11Process1 DEFRAY_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		
		/** 입금 계좌 번호 암호화 trim용 **/
		if(StringUtils.isNotEmpty(transfer7Process1ForTrim)) {
			try {
				log.debug("입금 계좌 번호 암호화 전 (trim ver.) ==================>" + transfer7Process1ForTrim);
				transfer7Process1ForTrim = CryptoUtil.encryptAES256(transfer7Process1ForTrim);
				log.debug("입금 계좌 번호 암호화 후 (trim ver.) ==================>" + transfer7Process1ForTrim);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletResDoTransfer transfer7Process1ForTrim RCPMNY_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		
		/** 출금 계좌 번호 암호화 **/
		if(StringUtils.isNotEmpty(transfer11Process1ForTrim)) {
			try {
				log.debug("출금 계좌 번호 암호화 전 (trim ver.) ==================>" + transfer11Process1ForTrim);
				transfer11Process1ForTrim = CryptoUtil.encryptAES256(transfer11Process1ForTrim);
				log.debug("출금 계좌 번호 암호화 후 (trim ver.) ==================>" + transfer11Process1ForTrim);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletResDoTransfer transfer11Process1ForTrim DEFRAY_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		
		
		
		/** 거래전문은 하나은행이 먼저 보내는 유형 (0200) 과 서린상사가 먼저 보낸 후 응답으로 보내는 유형 (0210)으로 나뉜다. **/
		if(StringUtils.equals(transferEntity.getBase11(), "0210")) {
			/** 서린상사에서 먼저 보내고 응답을 받았을때 **/
			ewalletMapper.insertDoTransferResponse(transferEntity);
			
			/**
			 * 0001(주문)일 경우 base30(응답메세지)는 '이월렛 정산 유형 코드|결제번호|주문번호|선수금여부|부분상환여부|이월렛거래구분코드'로 구분자 '|'로 구분한다.
			 * 0002(환불)일 경우 base30(응답메세지)는 '이월렛 정산 유형 코드|환불 요청 일시'로 구분자 '|'로 구분한다.
			 * 0003(이체)일 경우 base30(응답메세지)는 '이월렛 정산 유형 코드|결제번호'로 구분자 '|'로 구분한다.
			 * **/
			String setleNo = ""; // 결제번호
			String ewalletExcclcTyCode = ""; // 이월렛 정산 유형 코드 [01-고객입금,02-고객환불,03-주문결제,04-중량정산,05-취소정산,06-교환정산,07-반품정산,08-비용정산]
			String refndRequstDt = ""; // 환불 요청 일시
			String orderNo = ""; // 주문번호
			String precdntAt = "N"; // 선수금 여부: [Y : 선수금 O, C : 부분상환, A : 추가변동금, N : 선수금 X]
			String partRepyAt = "N"; // 부분상환 여부: [Y : 부분입금 N : 전체입금]
			String ewalletDelngSeCode = "99"; // 이월렛 거래 구분 코드, 기본으로는 99 (의미 없는 값 설정)
			
			/** 0001(주문), 0003(이체) 일때는 주문 결재테이블을 수정해준다.
			 * 0002(환불)은 결제테이블 관리하지 않는다.  20211104 수정
			 * **/
			if(StringUtils.equals(transferEntity.getBase13(), "0001") || StringUtils.equals(transferEntity.getBase13(), "0003")) {
				transferEntity.setIntrfcSn(transferEntity.getIntrfcSn());
				transferEntity.setEntrpsNo(StringUtils.trim(transferEntity.getBase29()));
				
				if(StringUtils.isNotEmpty(transferEntity.getBase30()) && StringUtils.trim(transferEntity.getBase30()).length() > 0) {
					String base30 = StringUtils.trim(transferEntity.getBase30()); // 응답메세지
					
					ewalletExcclcTyCode = base30.split("\\|")[0]; // 이월렛 정산 유형 코드
					setleNo = base30.split("\\|")[1]; // 결제번호
					
					if(StringUtils.equals(transferEntity.getBase13(), "0001")) {
						orderNo = base30.split("\\|")[2]; // 주문번호
						precdntAt = base30.split("\\|")[3]; // 선수금 여부: [Y : 선수금 O, C : 부분상환, A : 추가변동금, N : 선수금 X]
						partRepyAt = base30.split("\\|")[4]; // 부분상환 여부: [Y : 부분입금 N : 전체입금]
						ewalletDelngSeCode = base30.split("\\|")[5]; // 이월렛 거래 구분 코드, 기본으로는 99 (의미 없는 값 설정)
					} else if(StringUtils.equals(transferEntity.getBase13(), "0003")) {
						precdntAt = base30.split("\\|")[2]; // 선수금 여부: [Y : 선수금 O, C : 부분상환, A : 추가변동금, N : 선수금 X]
					}
				}
				
				transferEntity.setSetleNo(setleNo); // 0001, 0003의 경우 결제번호가 응답메세지로 필요
				ewalletMapper.updateEwalletSetle(transferEntity);
				ewalletMapper.insertEwalletSetleHist(transferEntity);
			} else if(StringUtils.equals(transferEntity.getBase13(), "0002")) {
				if(StringUtils.isNotEmpty(transferEntity.getBase30()) && StringUtils.trim(transferEntity.getBase30()).length() > 0) {
					String base30 = StringUtils.trim(transferEntity.getBase30()); // 응답메세지
					
					ewalletExcclcTyCode = base30.split("\\|")[0]; // 이월렛 정산 유형 코드
					refndRequstDt = base30.split("\\|")[1]; // 환불 요청 일시
				}
			}
			
			// 0001(주문)일 때, 이월렛 
			if(StringUtils.equals(transferEntity.getBase13(), "0001")) {
				CntcSttusVO cntcSttusVO = new CntcSttusVO();
				cntcSttusVO.setIntrfcSeCode("50"); // 인터페이스 구분 코드 : INTRFC_SE_CODE [10:LME, 20:환율, 30:FS, 40:FX, 50:V/A]
				cntcSttusVO.setLastChangerId("EWALLET-VA");
				
				if(StringUtils.equals(transferEntity.getBase14(), "000")) {
					log.debug(">> 신호등 주문 응답 성공 : " + transferEntity.getBase14());
					// 성공 시
					cntcSttusVO.setCheckResult(true);
				} else {
					log.debug(">> 신호등 주문 응답 실패 : " + transferEntity.getBase14());
					// 실패 시
					cntcSttusVO.setCheckResult(false);
					
					// 주문 이월렛 실패 시 SMS 추가 전송
					log.debug(">> 이월렛 실패 응답코드 : " + transferEntity.getBase14());
					try {
						this.innerDepartmentSendSmsByEwallet(orderNo);
					} catch(Exception e) {
						log.error("주문 이월렛 결제 실패에 의한 SMS전송 실패 : " + ExceptionUtils.getStackTrace(e));
					}
				}
				
				cntcSttusServiceImpl.updateCoCntcSttusBas(cntcSttusVO);
			}
			
			// 환불 요청 송신 시 회원_환불 요청 이력을 업데이트 VO
			EwalletMbRefndRequstHstVO ewalletMbRefndRequstHstVO = new EwalletMbRefndRequstHstVO();
	
			/** 응답코드가 000 즉 성공일때는 이월렛 업체 거래 상세 테이블에 INSERT를 시켜준다. **/
			if(StringUtils.equals(transferEntity.getBase14(), "000")) {
				EwalletAcnutDelngVO delngVo = new EwalletAcnutDelngVO();
				delngVo.setEntrpsNo(StringUtils.trim(transferEntity.getBase29()));
				delngVo.setTrtmntInsttCode(StringUtils.trim(transferEntity.getBase7())); // 20211103 취급 기관 코드 추가
				delngVo.setEwalletDelngAmount(NumberUtils.toLong(transferEntity.getTransfer1()));
				delngVo.setEwalletBlce(NumberUtils.toLong(transferEntity.getTransfer3()));
				delngVo.setIemSeCode(transferEntity.getBase13());
				delngVo.setDelngSeqNo(StringUtils.trim(transferEntity.getBase17()));
				delngVo.setEwalletExcclcTyCode(ewalletExcclcTyCode);
				delngVo.setSetleNo(setleNo);
				delngVo.setPrecdntAt(precdntAt);
				delngVo.setPartRepyAt(partRepyAt);
				delngVo.setEwalletDelngSeCode(ewalletDelngSeCode);
				
				// 회원_업체 이월렛 상세 등록하기
				ewalletMapper.insertMbEntrpsEwalletDtl(delngVo);
				
				ewalletMbRefndRequstHstVO.setRefndRequstSttusCode("03");				// 환불 요청 상태 코드 [03(성공)]
			} else {
				ewalletMbRefndRequstHstVO.setRefndRequstSttusCode("04");				// 환불 요청 상태 코드 [04(실패)]
			}
			
			/** 항목구분코드가 0002(환불)이고 환불 요청 일시에 값이 있으면 서린(FO)에서 환불 요청한 전문이다.
			 * 하나은행에서 전문 받고 처리 후 환불 요청 상태 코드를 성공으로 변경한다. **/
			if( StringUtils.equals(transferEntity.getBase13(), "0002") && StringUtils.isNotEmpty(refndRequstDt) ) {
				/** 환불 요청 송신 시 회원_환불 요청 이력을 업데이트 한다. 
				 *  [환불 요청 상태 코드, 환불 요청 처리 일시]
				 * **/
				ewalletMbRefndRequstHstVO.setEntrpsNo(StringUtils.trim(transferEntity.getBase29()));		// 업체번호
				ewalletMbRefndRequstHstVO.setRefndRequstDt(refndRequstDt);				// 환불 요청 일시
				ewalletMbRefndRequstHstVO.setRefndRequstMbyCode("01");					// 환불 요청 주체 코드 [01(서린)]
				if(StringUtils.isNotEmpty(transferEntity.getTransfer3()) && StringUtils.isNotEmpty(transferEntity.getTransfer1())) {
					// [전문]거래후 계좌잔액-거래금액, [DB] 환불 요청 시 잔액
					ewalletMbRefndRequstHstVO.setRefndRequstHourBlce(NumberUtils.toLong(transferEntity.getTransfer3()) - NumberUtils.toLong(transferEntity.getTransfer1()));
				}
				ewalletMapper.updateMbRefndRequstHst(ewalletMbRefndRequstHstVO);
			}
			
			// 0001(주문)이고, 성공했으며, 해당 주문의 결제 수단이 이월렛(증거금 아님)일 때 주문세금계산서 발행 api 호출
			if(StringUtils.equals(transferEntity.getBase13(), "0001")
					&& StringUtils.equals(transferEntity.getBase14(), "000") 
					&& StringUtils.equals(precdntAt, "N")) {
				
				// 24-03-19 변경사항 : 주문_주문 기본 테이블의 주문상태코드 및 주문완료일시를 업데이트해주는 로직 추가
				//						주문상태코드가 01(주문실패) 이거나, 10(결제완료) 이상이면 업데이트 하지 않음
				ewalletMapper.updateOrderSttusCodeToSuccess(orderNo);
				
				Map<String, String> keyValues = new HashMap<>();
				keyValues.put("ORDER_NO", orderNo);
				commonService.insertTableHistory("OR_ORDER_BAS", keyValues);
				
				log.debug("이월렛 단독 결제, 세금계산서 호출");
				try {
					Map<String, Object> paramVo = new HashMap<String, Object>();
					paramVo.put("canclExchngRtngudNo", null);
					paramVo.put("jobSe", "ORDER");
					paramVo.put("orderNo", orderNo);
					Map<String, Object> taxbillResMap = httpClientHelper.postCallApi(taxbillUrl, paramVo);
					log.debug("taxbill response = "+ String.valueOf(taxbillResMap));

					// 세금계산서 호출까지 완료된 건만 완료 처리
					if (null != taxbillResMap && StringUtils.equals(String.valueOf(taxbillResMap.get("responseCode")), "200")) {
						log.debug(">> 세금계산서 호출 성공");
					} else {
						log.error("[EwalletServiceImpl][ewalletResDoTransfer] 세금계산서 호출 실패");
					}
				} catch (Exception e) {
					log.error("[EwalletServiceImpl][ewalletResDoTransfer] 세금계산서 호출 실패");
				}
			}
			
		} else {
			/** 하나은행에서 먼저 들어온 전문 **/
			// 요청 일자 key (업데이트에 바로 사용하기 위해 리턴 받는다.)
			String requstDtKey = "";
			/** 하나은행에서 보내는 계좌번호를 기준으로 업체번호를 찾는다. **/
			String entrpsNo = "";
			
//			String testCodeBase17 = transferEntity.getBase17(); // 0099999일때 반응
//			log.debug(">> 거래일련번호 : "+ testCodeBase17);
			
			try {
				log.debug(">> 하나은행에서 먼저 들어온 전문");
				log.debug(transferEntity.toString());
				
				ewalletMapper.insertDoTransferRequest(transferEntity);
				EwalletAcnutDelngVO delngVo = new EwalletAcnutDelngVO();
				
				/** 0004, 즉 하나은행에서 해당 계좌에 환불요청을 보낸 전문 **/
				if(StringUtils.equals(transferEntity.getBase13(), "0004")) {
					// 하나은행 측 환불 요청
					delngVo.setEwalletAcnutNo(transfer11Process1ForTrim);
					delngVo.setRefndAcnutNo(transfer7Process1ForTrim);
					delngVo.setIemSeCode(StringUtils.trim(transferEntity.getBase13()));
					delngVo.setEwalletBlce(NumberUtils.toLong(transferEntity.getTransfer3()) - NumberUtils.toLong(transferEntity.getTransfer1()));
					delngVo.setEwalletExcclcTyCode("02"); // 이월렛 정산 유형 코드 [01-고객입금,02-고객환불,03-주문결제,04-중량정산,05-취소정산,06-교환정산,07-반품정산,08-비용정산]
				}else{
					/** 0004 이외의 건은 해당 가상계좌로 입금이 일어났을때 보낸 전문 **/
					// 하나은행 측 입금 발생

					// 거래일자(YYYYMMDD) + 거래일시(HHMMSS)
//					String ewalletDelngDt = transferEntity.getBase15() + transferEntity.getBase16();
					// 이월렛 거래 일시
//					ewalletDelngDt = dateFormatter(ewalletDelngDt, 0);
					
					delngVo.setEwalletAcnutNo(transfer7Process1ForTrim);
					delngVo.setEwalletBlce(NumberUtils.toLong(transferEntity.getTransfer3()));
					delngVo.setIemSeCode("0000");
					delngVo.setEwalletExcclcTyCode("01"); // 이월렛 정산 유형 코드 [01-고객입금,02-고객환불,03-주문결제,04-중량정산,05-취소정산,06-교환정산,07-반품정산,08-비용정산]
//					delngVo.setEwalletDelngDt(ewalletDelngDt);
				}
				
				/** 하나은행에서 보내는 계좌번호를 기준으로 업체번호를 찾는다. **/
				entrpsNo = StringUtils.trim(ewalletMapper.selectEntrpsOfAcnut(delngVo));
				
				/** 하나은행에서 해당 계좌에 환불요청을 보낸 전문 시 이력 처리 **/
				if(StringUtils.equals(transferEntity.getBase13(), "0004")) {
					/** 환불 요청 송신 시 회원_환불 요청 이력을 등록 한다. 
					 *  [환불 요청 상태 코드, 환불 요청 처리 일시]
					 * **/
					// 환불 요청 송신 시 회원_환불 요청 이력 등록 VO
					EwalletMbRefndRequstHstVO ewalletMbRefndRequstHstVO = new EwalletMbRefndRequstHstVO();
					ewalletMbRefndRequstHstVO.setEntrpsNo(entrpsNo);		                // 업체번호
					ewalletMbRefndRequstHstVO.setRefndRequstMbyCode("02");					// 환불 요청 주체 코드 [02(하나은행)]
					ewalletMbRefndRequstHstVO.setRefndRequstSttusCode("01");				// 환불 요청 상태 코드 [01(요청)]
					ewalletMbRefndRequstHstVO.setRefndRequstAmount(NumberUtils.toLong(transferEntity.getTransfer1()));       // 환불 요청 금액
					
					ewalletMapper.insertMbRefndRequstHst(ewalletMbRefndRequstHstVO);
					
					requstDtKey = ewalletMbRefndRequstHstVO.getRequstDtKey(); // 요청 일자 key (업데이트에 바로 사용하기 위해 리턴 받는다.)
					log.debug(">> ewalletResDoTransfer() requstDtKey : " + requstDtKey);
					
					try {
						/** 기업뱅킹 출금하기, 응답코드가 000일때 환불 요청 상태 코드 [03(성공)] 일 때, 이월렛 잔액 체크 후 필요시 지정가 주문 자동 취소한다, 20230609 추가 **/
						if(StringUtils.equals(transferEntity.getBase14(), "000")) {
							// 이월렛 최종 잔액 체크(with 예수금) 및 지정가 주문 자동 취소
							this.ewalletFinalBlceCheckAndAutoCancel(entrpsNo, "46", NumberUtils.toLong(transferEntity.getTransfer1()));
						}
					} catch(Exception e) {
						log.error("기업뱅킹 출금하기, 이월렛 잔액 체크 후 필요시 지정가 주문 자동 취소 실패[2] : " + e);
					}
				}
				
				
				/** 업체번호가 존재할때는 성공 (000) 코드를 보내면서 환불 및 입금처리는 한다. **/
				if(StringUtils.isNotEmpty(entrpsNo)) {
					delngVo.setEntrpsNo(entrpsNo);
					delngVo.setTrtmntInsttCode(StringUtils.trim(transferEntity.getBase7())); // 20211103 취급 기관 코드 추가
					delngVo.setEwalletDelngAmount(+NumberUtils.toLong(transferEntity.getTransfer1()));
					delngVo.setDelngSeqNo(StringUtils.trim(transferEntity.getBase17()));
					// 회원_업체 이월렛 상세 등록하기
					ewalletMapper.insertMbEntrpsEwalletDtl(delngVo);
					transferEntity.setBase14("000");
					
					try {
						// 입금인 경우 문자 발송
						if(StringUtils.equals(delngVo.getIemSeCode(), "0000")
								&& StringUtils.equals(delngVo.getEwalletExcclcTyCode(), "01")) {
							
							sendToAdmAccountRcpmnyMsg(delngVo, transferEntity, "S");
						}
					} catch (Exception e) {
						log.error("SMS SEND ERROR : " + e);
					}
				}else {
					// 에러 코드 정의 필요
					transferEntity.setBase14("400");
				}
			}catch (Exception e) {
				transferEntity.setBase14("500");
				log.debug("ewalletResDoTransfer() Error : " + e);
			}
			
			/** 서린상사에서 하나은행으로 응답이기때문에 값세팅을 다시한다. **/
			transferEntity.setBase6("5");
			transferEntity.setBase11("0210");
			
			log.debug(">> 체크 transferEntity.getTransfer11() : " + transferEntity.getTransfer11());
			
//			log.debug(">> 하나은행으로 응답 중 14891606710437 계좌("+StringUtils.trim(transferEntity.getTransfer7())+")는 오류 처리(하나은행 테스트 요청), 20211118");
//			if(StringUtils.equals(StringUtils.trim(transferEntity.getTransfer7()), "14891606710437") || StringUtils.equals(StringUtils.trim(transferEntity.getTransfer11()), "14891606710437")) {
//				// 오류 처리
//				log.debug(">> 오류 처리, 20211118");
//				transferEntity.setBase14("777");
//			}
			
			/** 입금 계좌 번호 복호화 **/
			String transfer7Process2 = transferEntity.getTransfer7();
			if(StringUtils.isNotEmpty(transfer7Process2)) {
				try {
					log.debug("입금 계좌 번호 복호화 전 ==================>" + transfer7Process2);
					transfer7Process2 = CryptoUtil.decryptAES256(transfer7Process2);
					log.debug("입금 계좌 번호 복호화 후 ==================>" + transfer7Process2);
					/** 입금 계좌 번호 셋팅 **/
					transferEntity.setTransfer7(transfer7Process2);
				} catch(Exception e) {
					log.error("EwalletServiceImpl ewalletResDoTransfer transfer7Process2 RCPMNY_ACNUT_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
			}
			
			/** 출금 계좌 번호 복호화 **/
			String transfer11Process2 = transferEntity.getTransfer11();
			if(StringUtils.isNotEmpty(transfer11Process2)) {
				try {
					log.debug("출금 계좌 번호 복호화 전 ==================>" + transfer11Process2);
					transfer11Process2 = CryptoUtil.decryptAES256(transfer11Process2);
					log.debug("출금 계좌 번호 복호화 후 ==================>" + transfer11Process2);
					/** 출금 계좌 번호 셋팅 **/
					transferEntity.setTransfer11(transfer11Process2);
				} catch(Exception e) {
					log.error("EwalletServiceImpl ewalletResDoTransfer transfer11Process2 DEFRAY_ACNUT_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
				}
			}
			
			byte[] sendByte = EwalletCommUtil.getByte(transferEntity, EwalletConstant.EWALLET_TCP_TRANSFER_LENGTH);
			
//			log.debug(">> 하나은행으로 응답 중 14891606711137 계좌("+StringUtils.trim(transferEntity.getTransfer7())+")는 응답을 보내지 않게 처리(하나은행 테스트 요청), 20211118");
//			
//			if(StringUtils.equals(StringUtils.trim(transferEntity.getTransfer7()), "14891606711137") || StringUtils.equals(StringUtils.trim(transferEntity.getTransfer11()), "14891606711137")) {
//				// 무응답 처리
//				log.debug(">> 무응답 처리, 20211118");
//			} else {
//			if(!testCodeBase17.equals("0099999")) { // 테스트코드제거대상20030822
				ewalletClientSocket.sendEwallt(sendByte, false);
//			}
//			}
			
			/** 하나은행에서 해당 계좌에 환불요청을 보낸 전문 시 이력 처리 **/
			if(StringUtils.equals(transferEntity.getBase13(), "0004")) {
				/** 환불 요청 수신 시 회원_환불 요청 이력을 업데이트 한다. 
				 *  [환불 요청 상태 코드, 환불 요청 처리 일시]
				 * **/
				// 환불 요청 수신 시 회원_환불 요청 이력 등록 VO
				EwalletMbRefndRequstHstVO ewalletMbRefndRequstHstVO = new EwalletMbRefndRequstHstVO();
				ewalletMbRefndRequstHstVO.setEntrpsNo(entrpsNo);						// 업체번호
				ewalletMbRefndRequstHstVO.setRefndRequstDt(requstDtKey);				// 환불 요청 일시
				ewalletMbRefndRequstHstVO.setRefndRequstMbyCode("02");					// 환불 요청 주체 코드 [01(하나은행)]
				
				/** 응답코드가 000일때 환불 요청 상태 코드 [03(성공)] **/
				if(StringUtils.equals(transferEntity.getBase14(), "000")) {
					ewalletMbRefndRequstHstVO.setRefndRequstSttusCode("03");				// 환불 요청 상태 코드 [03(성공)]
				} else {
					ewalletMbRefndRequstHstVO.setRefndRequstSttusCode("04");				// 환불 요청 상태 코드 [04(실패)]
				}
				if(StringUtils.isNotEmpty(transferEntity.getTransfer3()) && StringUtils.isNotEmpty(transferEntity.getTransfer1())) {
					// [전문]거래후 계좌잔액-거래금액, [DB] 환불 요청 시 잔액
					ewalletMbRefndRequstHstVO.setRefndRequstHourBlce(NumberUtils.toLong(transferEntity.getTransfer3()) - NumberUtils.toLong(transferEntity.getTransfer1()));
				}
				ewalletMapper.updateMbRefndRequstHst(ewalletMbRefndRequstHstVO);
			} else {
				// 입금 발생 시 (전자상거래보증 or 서린크레딧) 결제 예정 리스트((전자상거래보증 or 서린크레딧) 및 추가 금액 발생과 (이월렛 or 증거금)의 추가 금액 발생, 결제예정일(+1이상) 주문 결제 건)이 있을 경우, 입금 후 잔액으로 남은 주문 결제 건을 상환한다.
				// 입금에 의한 담보 보증 상환 처리 및 추가 금액 처리
				// 대상 : (전자상거래보증 or 서린크레딧) 결제 예정 리스트((전자상거래보증 or 서린크레딧) 및 추가 금액 발생과 (이월렛 or 증거금)의 추가 금액 발생, 결제예정일(+1이상) 주문 결제 건)
				try {
					this.mrtggGrntyRepyByRcpmny(entrpsNo);
				} catch(Exception e) {
					log.error("[EwalletServiceImpl][ewalletResDoTransfer] mrtggGrntyRepyByRcpmny 입금에 의한 담보 보증 상환 처리 또는 추가 금액 발생 처리 실패");
					log.error(e.getMessage(), e);
				}
			}
			
			/** 입금 계좌 번호 암호화 **/
			String transfer7Process3 = transferEntity.getTransfer7();
			if(StringUtils.isNotEmpty(transfer7Process3)) {
				try {
					log.debug("입금 계좌 번호 암호화 전 ==================>" + transfer7Process3);
					transfer7Process3 = CryptoUtil.encryptAES256(transfer7Process3);
					log.debug("입금 계좌 번호 암호화 후 ==================>" + transfer7Process3);
					/** 입금 계좌 번호 셋팅 **/
					transferEntity.setTransfer7(transfer7Process3);
				} catch(Exception e) {
					log.error("EwalletServiceImpl ewalletResDoTransfer transfer7Process3 RCPMNY_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
				}
			}
			
			/** 출금 계좌 번호 암호화 **/
			String transfer11Process3 = transferEntity.getTransfer11();
			if(StringUtils.isNotEmpty(transfer11Process3)) {
				try {
					log.debug("출금 계좌 번호 암호화 전 ==================>" + transfer11Process3);
					transfer11Process3 = CryptoUtil.encryptAES256(transfer11Process3);
					log.debug("출금 계좌 번호 암호화 후 ==================>" + transfer11Process3);
					/** 출금 계좌 번호 셋팅 **/
					transferEntity.setTransfer11(transfer11Process3);
				} catch(Exception e) {
					log.error("EwalletServiceImpl ewalletResDoTransfer transfer11Process3 DEFRAY_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
				}
			}
			
			ewalletMapper.insertDoTransferResponse(transferEntity);
		}
	}
	
	// 이월렛 최종 잔액 체크(with 예수금) 및 지정가 주문 자동 취소
	public void ewalletFinalBlceCheckAndAutoCancel(String entrpsNo, String limitOrderSttusCode, long delngAmount) {
		log.warn(">> ewalletFinalBlceCheckAndAutoCancel entrpsNo : " + entrpsNo);
		try {
			// 기업뱅킹 출금 처리 후 성공일 시 최종 잔액 체크(with 예수금)
			CommBlceInfoVO blceInfo = commFinalBlceCheckService.selectFinalBlceInfoBySetleMn(entrpsNo, "", "", delngAmount);
			if(!blceInfo.isDelngPossAt()) {
				// 거래 불가능일 경우 지정가 주문 자동 취소처리
				switch(limitOrderSttusCode) {
				case "45" : 
					// VA-미납 상환 전 최종 잔액 부족으로 지정가 주문 취소처리 실시
					log.debug("VA-입금 미납 상환 전 최종 잔액 부족으로 지정가 주문 취소처리 실시");
					break;
				case "46" : 
					// 지정가 주문 상태 코드: [46]주문취소(기업뱅킹 출금 자동 취소)
					log.debug("기업뱅킹 출금 처리 후 최종 잔액 부족으로 지정가 주문 취소처리 실시");
					break;
				}
				
				commLimitOrderService.limitOrderAutoCancel("VA", entrpsNo, limitOrderSttusCode, delngAmount); 
			}
		} catch(Exception e) {
			log.error("기업뱅킹 출금하기, 이월렛 잔액 체크 후 필요시 지정가 주문 자동 취소 실패[2] : " + e);
		}
	}
	
	/**
	 * 입금에 의한 담보 보증 상환 처리 및 추가 금액 처리
	 * 대상 : (전자상거래보증 or 서린크레딧) 결제 예정 리스트((전자상거래보증 or 서린크레딧) 및 추가 금액 발생과 (이월렛 or 증거금)의 추가 금액 발생, 결제예정일(+1이상) 주문 결제 건)
	 */
	@Override
	public void mrtggGrntyRepyByRcpmny(String entrpsNo) throws EwalletCustomException, Exception {
		log.warn(">> mrtggGrntyRepyByRcpmny entrpsNo : " + entrpsNo);
		
		// 업체 번호 체크
		if(StringUtils.equals("", Optional.ofNullable(entrpsNo).orElse(""))) throw new EwalletCustomException("업체 번호 미존재");
		
		EwalletAccountVO ewalletAccountVO = new EwalletAccountVO();
		ewalletAccountVO.setEntrpsNo(entrpsNo);
		
		// (전자상거래보증 or 서린크레딧) 결제 예정 리스트((전자상거래보증 or 서린크레딧) 및 추가 금액 발생과 (이월렛 or 증거금)의 추가 금액 발생, 결제예정일(+1이상) 주문 결제 건) 가져오기
		List<EwalletMrtggGrntySetlePrearngeVO> selectMrtggGrntySetlePrearngeList = ewalletMapper.selectMrtggGrntySetlePrearngeList(entrpsNo);
		
		if(selectMrtggGrntySetlePrearngeList.size() > 0) {
			
			for( int i=0; i<selectMrtggGrntySetlePrearngeList.size(); i++ ) {
				EwalletMrtggGrntySetlePrearngeVO ewalletMrtggGrntySetlePrearnge = (EwalletMrtggGrntySetlePrearngeVO) selectMrtggGrntySetlePrearngeList.get(i);
				log.warn(">> selectMrtggGrntySetlePrearngeList : " + String.valueOf(ewalletMrtggGrntySetlePrearnge));
				
				try {
					String orderNo = ewalletMrtggGrntySetlePrearnge.getOrderNo(); // 주문 번호
					String setleMthdCode = ewalletMrtggGrntySetlePrearnge.getSetleMthdCode(); // 결제 방식 코드
					String mrtggSttusCode = ewalletMrtggGrntySetlePrearnge.getMrtggSttusCode(); // 담보 상태 코드
					long unSetleAmount = Optional.ofNullable(ewalletMrtggGrntySetlePrearnge.getUnSetleAmount()).orElse(0L); // 미 결제 금액
					long mdstrmRepySn = ewalletMrtggGrntySetlePrearnge.getMdstrmRepySn(); // 중도 상환 순번
					
					// 이월렛 최종 잔액 체크(with 예수금) 및 지정가 주문 자동 취소
					this.ewalletFinalBlceCheckAndAutoCancel(entrpsNo, "45", unSetleAmount);
					
					Map<String, Object> resObj = null;
					Map<String, Object> reqMap = new HashMap<String, Object>();
					
					reqMap.put("mdstrmRepySn", mdstrmRepySn); // 중도 상환 순번
					
					/** 1. call ewallet
					 * 이월렛 처리 호출시 "상환구분코드"를 "03" 으로 호출하여 잔액 모두를 처리할 수 있도록 한다
					 * 23-11-23 변경사항 : 상환구분코드를 03 에서 10 으로 변경
					 */
					reqMap.put("orderNo", orderNo);
					reqMap.put("repySeCode", "10"); // 01:중량정산, 02:상환입금, 03:단가정산, 10:미납상환(이월렛잔고)
					resObj = httpClientHelper.postCallApi(apiCreditEwalletRepyUrl, reqMap);
					if( resObj == null || !StringUtils.equals(String.valueOf(resObj.get("rspnsCode")), "200")) {
						String rspnsMssage = null;
						if(resObj != null) rspnsMssage = String.valueOf(resObj.get("rspnsMssage"));
						
						log.error("[EwalletServiceImpl][mrtggGrntyRepyByRcpmny] 이월렛 상환 결제 처리 호출 실패(사유 : " + rspnsMssage + ")");
						throw new EwalletCustomException("이월렛 상환 결제 처리 호출 실패(사유 : " + rspnsMssage + ")");
					}
					
					/** 2. call mrtgg
					 * 전자상거래보증 미납 처리 호출시 "상환구분코드"를 "03" 으로 호출하여 잔액 모두를 처리할 수 있도록 한다
					 * 
					 * 2024-04-24: 전자상거래보증(20) or 서린크레딧(40)일 경우에만 호출, 상환완료 이후 추가결제건은 이월렛만 결제하므로 제외
					 */
					if(("20".equals(setleMthdCode) || "40".equals(setleMthdCode)) && !"50".equals(mrtggSttusCode)) {
						// 담보 처리 호출은 mrtggSttusCode 키 값 필요
						reqMap.put("mrtggSttusCode", "30"); // 담보 상태 코드 set [30: 부분상환]
						reqMap.put("mberId", "VA");
						
						// 담보 처리 호출
						resObj = httpClientHelper.postCallApi(apiCreditMrtggRepyUrl, reqMap);
						if( resObj == null || !StringUtils.equals(String.valueOf(resObj.get("rspnsCode")), "200")) {
							String rspnsMssage = null;
							if(resObj != null) rspnsMssage = String.valueOf(resObj.get("rspnsMssage"));
							
							log.error("[EwalletServiceImpl][mrtggGrntyRepyByRcpmny] 담보 처리 호출 실패(사유 : " + rspnsMssage + ")");
							throw new EwalletCustomException("담보 처리 호출 실패(사유 : " + rspnsMssage + ")");
						}
					}
				} catch(Exception e) {
					log.error(e.getMessage(), e);
					log.error("[EwalletServiceImpl][mrtggGrntyRepyByRcpmny] ewalletMrtggGrntySetlePrearnge : " + String.valueOf(ewalletMrtggGrntySetlePrearnge));
				}
			}
		}
		
		log.warn(">> [mrtggGrntyRepyByRcpmny] finish");
	}

	@Override
	public EwalletResultVO ewalletChkTransfer(EwalletResultVO ewalletResultVO) throws Exception {
		// 이체 처리 결과 전문 사용 안함, 암복호화 대상에서 제외
		
		EwalletResultVO resultVo = null;
		/** 거래 일련 번호 채번 **/
		ewalletResultVO.setDelngSeqNo(ewalletCommHelper.getEwalletAssign("5"));

		/** 하나은행 호출 **/
		EwalletResultEntity resultEntity = new EwalletResultEntity(ewalletResultVO);
		/** 객체를 BYTE[]배열로 변환 **/
		byte[] sendByte = EwalletCommUtil.getByte(resultEntity, EwalletConstant.EWALLET_TCP_RESULT_LENGTH);
		ewalletClientSocket.sendEwallt(sendByte, false);

		/** 인터페이스 테이블 저장 **/
		EwalletResultEntity resultModel = EwalletCommUtil.getObjForBytes(sendByte, EwalletResultEntity.class);
		ewalletMapper.insertChkTransferRequest(resultModel);

		/** 호출 응답 대기 **/
		int readCnt = 0 
		/** 처리결과를 응답 받기위해 타임아웃 설정까지 기달려서 DB를 확인한다. **/;
		while(true) {
			readCnt++;
			Thread.sleep(500);
			resultVo = ewalletMapper.selectTransferResult(ewalletResultVO);
			if(readCnt/2 >= resultWaitSecond  || resultVo != null) {
				break;
			}
		}

		return resultVo;

	}

	@Override
	public void ewalletResChkTransfer(byte[] receiveByte) throws Exception {
		// 이체 처리 결과 전문 사용 안함, 암복호화 대상에서 제외
		
		/** 이체처리결과 전문을 객체로 변환시킨다 **/
		EwalletResultEntity resultEntity = EwalletCommUtil.getObjForBytes(receiveByte, EwalletResultEntity.class);
		/** 인터페이스 테이블에 INSERT **/
		ewalletMapper.insertChkTransferResponse(resultEntity);
	}

	@Override
	public void ewalletResCancelTransfer(byte[] receiveByte) throws Exception {
		/** 하나은행에 먼저 보낸 요청 측 ewalletResDoTransfer() 함수에서 0200전문 으로 들어온 0004(환불), 그외 (입금)업무를 취소하는 로직은 요청받는다. **/
		EwalletTransferEntity cancelEntity = EwalletCommUtil.getObjForBytes(receiveByte, EwalletTransferEntity.class);
		
		/** 입금 계좌 번호 암호화 **/
		String transfer7Process1 = cancelEntity.getTransfer7();
		if(StringUtils.isNotEmpty(transfer7Process1)) {
			try {
				log.debug("입금 계좌 번호 암호화 전 ==================>" + transfer7Process1);
				transfer7Process1 = CryptoUtil.encryptAES256(transfer7Process1);
				log.debug("입금 계좌 번호 암호화 후 ==================>" + transfer7Process1);
				/** 입금 계좌 번호 셋팅 **/
				cancelEntity.setTransfer7(transfer7Process1);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletResCancelTransfer transfer7Process1 RCPMNY_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		
		/** 출금 계좌 번호 암호화 **/
		String transfer11Process1 = cancelEntity.getTransfer11();
		if(StringUtils.isNotEmpty(transfer11Process1)) {
			try {
				log.debug("출금 계좌 번호 암호화 전 ==================>" + transfer11Process1);
				transfer11Process1 = CryptoUtil.encryptAES256(transfer11Process1);
				log.debug("출금 계좌 번호 암호화 후 ==================>" + transfer11Process1);
				/** 출금 계좌 번호 셋팅 **/
				cancelEntity.setTransfer11(transfer11Process1);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletResCancelTransfer transfer11Process1 DEFRAY_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		
		try {
			ewalletMapper.insertDoTransferRequest(cancelEntity);
			EwalletAcnutDelngVO delngVo = new EwalletAcnutDelngVO();
			/** 환불요청에 대한 취소요청 **/
			if(StringUtils.equals(cancelEntity.getBase13(), "0004")) {
				delngVo.setEwalletAcnutNo(StringUtils.trim(cancelEntity.getTransfer11()));
				delngVo.setRefndAcnutNo(StringUtils.trim(cancelEntity.getTransfer7()));
				delngVo.setEwalletBlce(NumberUtils.toLong(cancelEntity.getTransfer3()));
				delngVo.setIemSeCode("4004");
			}else{
				/** 입금요청에 대한 취소요청 **/
				delngVo.setEwalletAcnutNo(StringUtils.trim(cancelEntity.getTransfer7()));
				delngVo.setEwalletBlce(NumberUtils.toLong(cancelEntity.getTransfer3()) - NumberUtils.toLong(cancelEntity.getTransfer1()));
				delngVo.setIemSeCode("4000");
			}
			
			/** 취소요청에대한 계좌번호를 통해 업체번호를 조회한다. **/
			String entrpsNo = StringUtils.trim(ewalletMapper.selectEntrpsOfAcnut(delngVo));

			/** 업체번호가 존재할때는 성공 (000) 코드를 보내면서 환불 및 입금처리는 한다. **/
			if(StringUtils.isNotEmpty(entrpsNo)) {
				delngVo.setEntrpsNo(entrpsNo);
				delngVo.setTrtmntInsttCode(StringUtils.trim(cancelEntity.getBase7())); // 20211103 취급 기관 코드 추가
				delngVo.setEwalletDelngAmount(NumberUtils.toLong(cancelEntity.getTransfer1()));
				delngVo.setDelngSeqNo(StringUtils.trim(cancelEntity.getBase17()));
				// 회원_업체 이월렛 상세 등록하기
				ewalletMapper.insertMbEntrpsEwalletDtl(delngVo);
				cancelEntity.setBase14("000");
			}else {
				// 에러 코드 정의 필요
				cancelEntity.setBase14("400");
			}
		}catch (Exception e) {
			// 에러 코드 정의 필요
			cancelEntity.setBase14("500");
		}
		/** 서린상사에서 하나은행으로 응답이기때문에 값세팅을 다시한다. **/
		cancelEntity.setBase6("5");
		cancelEntity.setBase11("0410");
		
		/** 입금 계좌 번호 복호화 **/
		String transfer7Process2 = cancelEntity.getTransfer7();
		if(StringUtils.isNotEmpty(transfer7Process2)) {
			try {
				log.debug("입금 계좌 번호 복호화 전 ==================>" + transfer7Process2);
				transfer7Process2 = CryptoUtil.decryptAES256(transfer7Process2);
				log.debug("입금 계좌 번호 복호화 후 ==================>" + transfer7Process2);
				/** 입금 계좌 번호 셋팅 **/
				cancelEntity.setTransfer7(transfer7Process2);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletResDoTransfer transfer7Process2 RCPMNY_ACNUT_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}
		
		/** 출금 계좌 번호 복호화 **/
		String transfer11Process2 = cancelEntity.getTransfer7();
		if(StringUtils.isNotEmpty(transfer11Process2)) {
			try {
				log.debug("출금 계좌 번호 복호화 전 ==================>" + transfer11Process2);
				transfer11Process2 = CryptoUtil.decryptAES256(transfer11Process2);
				log.debug("출금 계좌 번호 복호화 후 ==================>" + transfer11Process2);
				/** 출금 계좌 번호 셋팅 **/
				cancelEntity.setTransfer7(transfer11Process2);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletResDoTransfer transfer11Process2 DEFRAY_ACNUT_NO CryptoUtil.decryptAES256 ERROR " + e.getMessage());
			}
		}
		
		byte[] sendByte = EwalletCommUtil.getByte(cancelEntity, EwalletConstant.EWALLET_TCP_TRANSFER_LENGTH);
		ewalletClientSocket.sendEwallt(sendByte, false);
		
		/** 입금 계좌 번호 암호화 **/
		String transfer7Process3 = cancelEntity.getTransfer7();
		if(StringUtils.isNotEmpty(transfer7Process3)) {
			try {
				log.debug("입금 계좌 번호 암호화 전 ==================>" + transfer7Process3);
				transfer7Process3 = CryptoUtil.encryptAES256(transfer7Process3);
				log.debug("입금 계좌 번호 암호화 후 ==================>" + transfer7Process3);
				/** 입금 계좌 번호 셋팅 **/
				cancelEntity.setTransfer7(transfer7Process3);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletResCancelTransfer transfer7Process3 RCPMNY_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		
		/** 출금 계좌 번호 암호화 **/
		String transfer11Process3 = cancelEntity.getTransfer11();
		if(StringUtils.isNotEmpty(transfer11Process3)) {
			try {
				log.debug("출금 계좌 번호 암호화 전 ==================>" + transfer11Process3);
				transfer11Process3 = CryptoUtil.encryptAES256(transfer11Process3);
				log.debug("출금 계좌 번호 암호화 후 ==================>" + transfer11Process3);
				/** 출금 계좌 번호 셋팅 **/
				cancelEntity.setTransfer11(transfer11Process3);
			} catch(Exception e) {
				log.error("EwalletServiceImpl ewalletResCancelTransfer transfer11Process3 DEFRAY_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
			}
		}
		
		ewalletMapper.insertDoTransferResponse(cancelEntity);
	}
	
	/**
	 * <pre>
	 * 처리내용: 관리전문 이력을 등록한다.
	 * param1 : manageType (거래구분 코드 [2100:개시, 2400:종료, 2500:장애요청, 2600:장애해제])
	 * param2 : ewalletRequstSeCode (이월렛 요청 구분 코드 [10:접수, 20:요청])
	 * param3 : ewalletRequstInsttCode (이월렛 요청 기관 코드 [10:서린상사, 20:하나은행])
	 * param4 : ewalletCntcSttusSeCode (이월렛 연계 상태 구분 코드 [10:성공, 20:실패])
	 * </pre>
	 * @date 2021. 12. 13.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 13.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param manageType
	 */
	public void ewalletManageInsertFunc(String manageType, String ewalletRequstSeCode, String ewalletRequstInsttCode, String ewalletCntcSttusSeCode) throws Exception {
		String ewalletIntrfcSeCode = ""; // 이월렛 인터페이스 구분 코드 [10:개시, 20:종료, 30:장애요청, 40:장애해제]
		
		switch(manageType) {
			case "2100" : ewalletIntrfcSeCode = "10"; break;
			case "2400" : ewalletIntrfcSeCode = "20"; break;
			case "2500" : ewalletIntrfcSeCode = "30"; break;
			case "2600" : ewalletIntrfcSeCode = "40"; break;
		}
		
		EwalletCoEwalletManageSttusBasVO ewalletCoEwalletManageSttusBasVO = new EwalletCoEwalletManageSttusBasVO();
		ewalletCoEwalletManageSttusBasVO.setEwalletIntrfcSeCode(ewalletIntrfcSeCode); // 이월렛 인터페이스 구분 코드 [10:개시, 20:종료, 30:장애요청, 40:장애해제]
		ewalletCoEwalletManageSttusBasVO.setEwalletRequstSeCode(ewalletRequstSeCode); // 이월렛 요청 구분 코드 [10:접수, 20:요청]
		ewalletCoEwalletManageSttusBasVO.setEwalletRequstInsttCode(ewalletRequstInsttCode); // 이월렛 요청 기관 코드 [10:서린상사, 20:하나은행]
		ewalletCoEwalletManageSttusBasVO.setEwalletCntcSttusSeCode(ewalletCntcSttusSeCode); // 이월렛 연계 상태 구분 코드 [10:성공, 20:실패]
		
		// 관리전문 이력을 등록한다.
		ewalletMapper.insertCoEwalletManageSttusBas(ewalletCoEwalletManageSttusBasVO);
	}
	
	// 주문 이월렛 실패 시 SMS 추가 전송
	public void innerDepartmentSendSmsByEwallet(String orderNo) throws Exception {
		Map<String, String> smsMap = new HashMap<String, String>();
		smsMap.put("templateNum", "47");
		smsMap.put("commerceNtcnCn", "이월렛 처리 실패"); // 알림 메세지
		smsMap.put("orderNo", orderNo); // 주문번호
		
		// 주문 이월렛 실패 시 SMS 전송 수신자 추가 리스트 가져오기[SMS_SNDNG_GROUP_CODE:43]
		smsMap.put("commerceNtcnAt", "Y"); // 추가 수신사 커머스 알림 여부 따로 설정
		smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
		smsService.insertSMS(null, smsMap);
	}
	
	/**
	 *
	 */
	@Override
	public void ewalletManage(EwalletManageVO ewalletManageVO) throws Exception {
		log.debug(">> ewalletManage : " + ewalletManageVO.getManageType() + ", " + ewalletManageVO.getDelngSeqNo());
		/** 거래 일련 번호 채번 **/
		ewalletManageVO.setDelngSeqNo(ewalletCommHelper.getEwalletAssign("8"));
		EwalletManagerEntity startEntity = new EwalletManagerEntity(ewalletManageVO);
		byte[] sendByte = EwalletCommUtil.getByte(startEntity, EwalletConstant.EWALLET_TCP_MANAGE_LENGTH);
		
		String ewalletCntcSttusSeCode = ""; // 이월렛 연계 상태 구분 코드 [10:성공, 20:실패]
		try {
			/** 하나은행 호출 **/
			ewalletClientSocket.sendEwallt(sendByte, false);
			
			ewalletCntcSttusSeCode = "10"; // 이월렛 연계 상태 구분 코드 - [10:성공]
		} catch(Exception e) {
			ewalletCntcSttusSeCode = "20"; // 이월렛 연계 상태 구분 코드 - [20:실패]
			
			String stacktrace = ExceptionUtils.getStackTrace(e);
			log.error("[EwalletServiceImpl][ewalletManage] : " + stacktrace);
		}

		/** 인터페이스 테이블 INSERT **/
		EwalletManagerEntity startModel = EwalletCommUtil.getObjForBytes(sendByte, EwalletManagerEntity.class);
		ewalletMapper.insertManageBankRequest(startModel);
		
		// 관리전문 이력을 등록한다. (서린 -> 하나)
		this.ewalletManageInsertFunc(ewalletManageVO.getManageType(), "20", "10", ewalletCntcSttusSeCode);
	}
	
	@Override
	public void ewalletResStartBank(byte[] receiveByte) throws Exception {
		String ewalletCntcSttusSeCode = ""; // 이월렛 연계 상태 구분 코드 [10:성공, 20:실패]
		
		/** 하나은행 측에서 업무를 개시한다는 전문을 서린상사측에 보낸다. **/
		EwalletManagerEntity receiveEntity = EwalletCommUtil.getObjForBytes(receiveByte, EwalletManagerEntity.class);
		if(StringUtils.equals(receiveEntity.getBase11(), "0800")) {
			ewalletMapper.insertManageBankRequest(receiveEntity);
			
			// 관리전문 이력을 등록한다. (하나 -> 서린)
			this.ewalletManageInsertFunc(receiveEntity.getBase12(), "10", "20", "10");
			
			/** 서린상사에서 하나은행으로 응답이기때문에 값세팅을 다시한다. **/
			receiveEntity.setBase6("5");
			receiveEntity.setBase11("0810");
			receiveEntity.setBase14("000");
			byte[] sendByte = EwalletCommUtil.getByte(receiveEntity, EwalletConstant.EWALLET_TCP_MANAGE_LENGTH);
			
			try {
				ewalletClientSocket.sendEwallt(sendByte, false);
				
				ewalletCntcSttusSeCode = "10"; // 이월렛 연계 상태 구분 코드 - [10:성공]
			} catch(Exception e) {
				ewalletCntcSttusSeCode = "20"; // 이월렛 연계 상태 구분 코드 - [20:실패]
				
				String stacktrace = ExceptionUtils.getStackTrace(e);
				log.error("[EwalletServiceImpl][ewalletResStartBank] : " + stacktrace);
			}
		}
		ewalletMapper.insertManageBankResponse(receiveEntity);
		
		// 관리전문 이력을 등록한다. (서린 -> 하나)
		this.ewalletManageInsertFunc(receiveEntity.getBase12(), "10", "10", ewalletCntcSttusSeCode);
	}

	@Override
	public void ewalletResEndBank(byte[] receiveByte) throws Exception {
		String ewalletCntcSttusSeCode = ""; // 이월렛 연계 상태 구분 코드 [10:성공, 20:실패]
		
		/** 하나은행 측에서 업무를 종료한다는 전문을 서린상사측에 보낸다. **/
		EwalletManagerEntity receiveEntity = EwalletCommUtil.getObjForBytes(receiveByte, EwalletManagerEntity.class);
		if(StringUtils.equals(receiveEntity.getBase11(), "0800")) {
			ewalletMapper.insertManageBankRequest(receiveEntity);
			/** 서린상사에서 하나은행으로 응답이기때문에 값세팅을 다시한다. **/
			receiveEntity.setBase6("5");
			receiveEntity.setBase11("0810");
			receiveEntity.setBase14("000");
			byte[] sendByte = EwalletCommUtil.getByte(receiveEntity, EwalletConstant.EWALLET_TCP_MANAGE_LENGTH);
			
			try {
				ewalletClientSocket.sendEwallt(sendByte, false);
				
				ewalletCntcSttusSeCode = "10"; // 이월렛 연계 상태 구분 코드 - [10:성공]
			} catch(Exception e) {
				ewalletCntcSttusSeCode = "20"; // 이월렛 연계 상태 구분 코드 - [20:실패]
				
				String stacktrace = ExceptionUtils.getStackTrace(e);
				log.error("[EwalletServiceImpl][ewalletResEndBank] : " + stacktrace);
			}
		}
		ewalletMapper.insertManageBankResponse(receiveEntity);
		
		// 관리전문 이력을 등록한다. (서린 -> 하나)
		this.ewalletManageInsertFunc(receiveEntity.getBase12(), "10", "10", ewalletCntcSttusSeCode);
	}

	@Override
	public void ewalletResErrorBank(byte[] receiveByte) throws Exception {
		String ewalletCntcSttusSeCode = ""; // 이월렛 연계 상태 구분 코드 [10:성공, 20:실패]
		
		log.debug(">> ewalletResErrorBank in~~");
		/** 하나은행 측에서 장애가 발생했다는 전문을 서린상사측에 보낸다. **/
		EwalletManagerEntity receiveEntity = EwalletCommUtil.getObjForBytes(receiveByte, EwalletManagerEntity.class);
		log.debug(">> ewalletResErrorBank : " + receiveEntity.toString());
		if(StringUtils.equals(receiveEntity.getBase11(), "0800")) {
			ewalletMapper.insertManageBankRequest(receiveEntity);
			/** 서린상사에서 하나은행으로 응답이기때문에 값세팅을 다시한다. **/
			receiveEntity.setBase6("5");
			receiveEntity.setBase11("0810");
			receiveEntity.setBase14("000");
			byte[] sendByte = EwalletCommUtil.getByte(receiveEntity, EwalletConstant.EWALLET_TCP_MANAGE_LENGTH);
			
			try {
				ewalletClientSocket.sendEwallt(sendByte, false);
				
				ewalletCntcSttusSeCode = "10"; // 이월렛 연계 상태 구분 코드 - [10:성공]
			} catch(Exception e) {
				ewalletCntcSttusSeCode = "20"; // 이월렛 연계 상태 구분 코드 - [20:실패]
				
				String stacktrace = ExceptionUtils.getStackTrace(e);
				log.error("[EwalletServiceImpl][ewalletResEndBank] : " + stacktrace);
			}
		}
		ewalletMapper.insertManageBankResponse(receiveEntity);
		
		// 관리전문 이력을 등록한다. (서린 -> 하나)
		this.ewalletManageInsertFunc(receiveEntity.getBase12(), "10", "10", ewalletCntcSttusSeCode);
	}

	@Override
	public void ewalletResErrorCancelBank(byte[] receiveByte) throws Exception {
		String ewalletCntcSttusSeCode = ""; // 이월렛 연계 상태 구분 코드 [10:성공, 20:실패]
		
		log.debug(">> ewalletResErrorCancelBank in~~");
		/** 하나은행 측에서 장애를 해제한다는 전문을 서린상사측에 보낸다. **/
		EwalletManagerEntity receiveEntity = EwalletCommUtil.getObjForBytes(receiveByte, EwalletManagerEntity.class);
		log.debug(">> ewalletResErrorCancelBank : " + receiveEntity.toString());
		if(StringUtils.equals(receiveEntity.getBase11(), "0800")) {
			ewalletMapper.insertManageBankRequest(receiveEntity);
			/** 서린상사에서 하나은행으로 응답이기때문에 값세팅을 다시한다. **/
			receiveEntity.setBase6("5");
			receiveEntity.setBase11("0810");
			receiveEntity.setBase14("000");
			byte[] sendByte = EwalletCommUtil.getByte(receiveEntity, EwalletConstant.EWALLET_TCP_MANAGE_LENGTH);
			
			try {
				ewalletClientSocket.sendEwallt(sendByte, false);
				
				ewalletCntcSttusSeCode = "10"; // 이월렛 연계 상태 구분 코드 - [10:성공]
			} catch(Exception e) {
				ewalletCntcSttusSeCode = "20"; // 이월렛 연계 상태 구분 코드 - [20:실패]
				
				String stacktrace = ExceptionUtils.getStackTrace(e);
				log.error("[EwalletServiceImpl][ewalletResEndBank] : " + stacktrace);
			}
		}
		ewalletMapper.insertManageBankResponse(receiveEntity);
		
		// 관리전문 이력을 등록한다. (서린 -> 하나)
		this.ewalletManageInsertFunc(receiveEntity.getBase12(), "10", "10", ewalletCntcSttusSeCode);
	}

	@Override
	public byte[] ewalletPollingChk(byte[] receiveByte) throws Exception {
		/** 받은 전문의 HDR단어가 들어가있는지 체크하여 폴링체크를 진행한다. **/
		String receiceStr = new String(receiveByte, EwalletConstant.EWALLET_DEFAULT_ENCODING);
		receiceStr = receiceStr.replace(EwalletConstant.EWALLET_TCP_POLLING_REQ, EwalletConstant.EWALLET_TCP_POLLING_RES);
		return receiceStr.getBytes(EwalletConstant.EWALLET_DEFAULT_ENCODING);
	}

	@Override
	public void sendToAdmAccountRcpmnyMsg(EwalletAcnutDelngVO ewalletManageVO, EwalletBaseEntity ewalletEntity, String type) throws Exception {

		try {

			if(StringUtil.isBlank(type)	|| (!"E".equals(type) && !"S".equals(type))) {
				log.error("sendToAdmAccountRcpmnyMsg type error : " + type);
				return;
			}

			//2.업체 구매자 또는 업체 마스터 정보
			EntrpsInfoBasVO entrpsInfoBasvo = ewalletMapper.selectEntrpsInfoBas(ewalletManageVO.getEntrpsNo());

			if ("E".equals(type)) {
				log.warn("parameter \"type\"= E 로직 없음");
			}
			
			if ("S".equals(type)) {

				//3.서린 내부직원 휴대폰 리스트 조회 - 제거 20230105, 내부담당자 보내기는 공통 내부 로직에서 처리한다.
				//List<EntrpsInfoBasVO> emplList = ewalletMapper.selectEmplList("30");

				//4. 내부담당자 sms 보내기
				Map<String, String> smsMap = new HashMap<>();
				String moblphonNo = entrpsInfoBasvo.getMoblphonNo();
				String moblphonNoDec = "";

				if (moblphonNo != null && !"".equals(moblphonNo)) {
					try {
						//휴대폰번호 복호화
						moblphonNoDec = CryptoUtil.decryptAES256(moblphonNo);
					} catch(Exception e) {
						log.error("decryptAES256 ERROR : " + e.getMessage());
					}
				}

				//탬플릿번호
                smsMap.put("templateNum", "43");
                //입금일시
                smsMap.put("rcpmnyDt", dateFormatter(ewalletEntity.getBase15() + ewalletEntity.getBase16(), 1));
                //입금회사
                smsMap.put("rcpmnyCmpny", entrpsInfoBasvo.getEntrpsNm());
                //담당자명
                smsMap.put("chargerNm", entrpsInfoBasvo.getMberNm());
                //담당자 전화번호
                smsMap.put("chargerTlphonNo", StringUtil.formatPhone(moblphonNoDec));
                //입급금액
                smsMap.put("rcpmnyAmount", StringUtil.formatMoney(String.valueOf(ewalletManageVO.getEwalletDelngAmount())));

                /*
                //잔액
                smsMap.put("blce", StringUtil.formatMoney(String.valueOf(ewalletManageVO.getEwalletBlce())));
                //주문가능 톤수
                smsMap.put("orderPossTonCo", orderableTonnage + " MT");
                //구매횟수
                smsMap.put("purchsRtrvl", entrpsInfoBasvo.getOrderCnt());
                */
                /*
                입금일시 : {{rcpmnyDt}}
				입금회사 : {{rcpmnyCmpny}}
				담당자 : {{chargerNm}} ({{chargerTlphonNo}})
				입금금액 : {{rcpmnyAmount}}
                */
				//sms전송
                smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
                smsService.insertSMS(null, smsMap);
			}// end if 
			
		} catch (Exception e) {
			// 해당 메서드에서 장애가 발생해도 이후 로직은 상관없이 진행되어야 한다.
			log.error("sendToAdmAccountRcpmnyMsg error : " + e);
		}
	}
	
	@Override
	public PrSelVO getNewestPrSelRltm(String metalCode, Integer itemSn, String dstrcLclsfCode, String brandGroupCode,
			String brandCode, String occrrncDe) throws Exception {
		PrSelVO prSelVO = new PrSelVO();

		if((metalCode == null || "".equals(metalCode)) && (itemSn == null || itemSn == 0) && (dstrcLclsfCode == null || "".equals(dstrcLclsfCode))
				 && (brandGroupCode == null || "".equals(brandGroupCode)) && (brandCode == null || "".equals(brandCode)) && (occrrncDe == null || "".equals(occrrncDe))) {
			return null;
		}

		prSelVO.setMetalCode(metalCode);
		prSelVO.setItmSn(itemSn);
		prSelVO.setDstrctLclsfCode(dstrcLclsfCode);
		prSelVO.setBrandGroupCode(brandGroupCode);
		prSelVO.setBrandCode(brandCode);
		prSelVO.setOccrrncDe(occrrncDe);

		return pcInfoMapper.getPrSelRltm(prSelVO);
	}

	@Override
	public String dateFormatter(String dateFormat, int formatType) throws ParseException {
		SimpleDateFormat dtFormat = new SimpleDateFormat("yyyyMMddHHmmss");
 		//SimpleDateFormat newDtFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); // String 타입을 Date 타입으로 변환
 		SimpleDateFormat newDtFormat = null; // String 타입을 Date 타입으로 변환

 		if(formatType == 0) {
 			newDtFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
 		} else if(formatType == 1) {
 			newDtFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
 		} else if(formatType == 2) {
 			newDtFormat = new SimpleDateFormat("yyyy년 MM월 dd일 HH시 mm분");
 		}

 		Date formatDate = dtFormat.parse(dateFormat); // Date타입의 변수를 새롭게 지정한 포맷으로 변환
 		String strNewDtFormat = newDtFormat.format(formatDate);
		return strNewDtFormat;
	}
	
	public static void main(String[] args) {
		String aa;
		String bb;
		try {
			aa = CryptoUtil.decryptAES256("0NvOgdm4Neijub7KokjXIw==");
			System.out.println(aa);
			
			aa = CryptoUtil.decryptAES256("lzrCGQJ2qbmLH3X9xSx3dw==");
			System.out.println(aa);
			
			System.out.println(aa);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
