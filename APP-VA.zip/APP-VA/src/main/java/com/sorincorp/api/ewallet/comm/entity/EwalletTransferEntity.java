package com.sorincorp.api.ewallet.comm.entity;

import org.apache.commons.lang3.StringUtils;

import com.sorincorp.api.ewallet.comm.annotaion.ByteLimit;
import com.sorincorp.api.ewallet.comm.constant.EwalletConstant;
import com.sorincorp.api.ewallet.model.EwalletTransferVO;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * EwalletTransferVO.java
 * @version
 * @since 2021. 7. 6.
 * @author Sim sung bo
 * 이체수취조회/이체업무 전문
 */
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class EwalletTransferEntity extends EwalletBaseEntity{
	
	public EwalletTransferEntity(EwalletTransferVO ewalletTransferVO) {
		
		/* LENGTH */
		super.setBase1("0500");
		
		/* 전문구분코드(MSG TYPE) */
		super.setBase11("0200");
		
		/* 거래구분코드 */
		super.setBase12("5100");
		
		/* 항목구분코드 */
		super.setBase13(ewalletTransferVO.getIemSeCode());
		
		/* 거래일련번호 */
		super.setBase17(ewalletTransferVO.getDelngSeqNo());
		
		/* USER WORK AREA */
		super.setBase29(ewalletTransferVO.getEntrpsNo());
		
		/* 거래금액 */
		this.transfer1 = String.valueOf(ewalletTransferVO.getDelngAmount());
		
		
		String base28 	= StringUtils.EMPTY;
		String transfer5 = StringUtils.EMPTY;
		String transfer7 = StringUtils.EMPTY;
		String transfer9 = StringUtils.EMPTY;
		String transfer11= StringUtils.EMPTY;
		String transfer21= StringUtils.EMPTY;
		
		if(StringUtils.equals(ewalletTransferVO.getIemSeCode(), "0001")) {
			/** 구매 **/
			base28 	= "2";
			
			// 부분상환 여부: [Y : 부분입금 N : 전체입금], 값이 없을 때에는 N으로 처리
			String partRepyAt = StringUtils.equals("Y", ewalletTransferVO.getPartRepyAt()) ? "Y" : "N";
			
			// 이월렛 거래 구분 코드, 값이 없을 때는 00으로 의미 없는 값 부여
			// 추가결제일 때 값을 던져주는 경우, 
			// 현재는 쿼리에서 [이월렛 거래 구분 코드]를 상환완료 이 후 추가결제 발생할 때만 09(추가정산)을 넣도록 되어 있어서 
			// 필요 시 ewalletDelngSeCode 코드 값을 던져준다.
			String ewalletDelngSeCode = StringUtils.equals("09", ewalletTransferVO.getEwalletDelngSeCode()) ? ewalletTransferVO.getEwalletDelngSeCode() : "99";
			
			// ewalletExcclcTyCode(이월렛 정산 유형 코드) [01-고객입금,02-고객환불,03-주문결제,04-중량정산,05-취소정산,06-교환정산,07-반품정산,08-비용정산]
			// setleNo(결제번호)
			// orderNo(주문번호)
			// precdntAt(선수금 여부: [Y : 선수금 O, C : 부분상환, N : 선수금 X])
			// partRepyAt(부분상환 여부: [Y : 부분입금 N : 전체입금])
			// ewalletDelngSeCode(이월렛 거래 구분 코드)
			super.setBase30(ewalletTransferVO.getEwalletExcclcTyCode() + "|" + ewalletTransferVO.getSetleNo()  + "|" + ewalletTransferVO.getOrderNo() 
				+ "|" + ewalletTransferVO.getPrecdntAt() + "|" + partRepyAt + "|" + ewalletDelngSeCode);
			transfer5 = EwalletConstant.EWALLET_HANABANK_CODE;
			transfer7 = ewalletTransferVO.getSorinAcnutNo();
			transfer9 = EwalletConstant.EWALLET_SORIN_CODE;
			transfer11= ewalletTransferVO.getEwalletAcnutNo();
			transfer21= ewalletTransferVO.getBsnmRegistNo();
			
		}else if(StringUtils.equals(ewalletTransferVO.getIemSeCode(), "0002")) {
			/** 고객 환불 **/
			base28 	= "2";
			// ewalletExcclcTyCode(이월렛 정산 유형 코드) [01-고객입금,02-고객환불,03-주문결제,04-중량정산,05-취소정산,06-교환정산,07-반품정산,08-비용정산]
			// refndRequstDt(환불 요청 일시)
			super.setBase30(ewalletTransferVO.getEwalletExcclcTyCode() + "|" + ewalletTransferVO.getRefndRequstDt());
			transfer5 = EwalletConstant.EWALLET_HANABANK_CODE;
			transfer7 = ewalletTransferVO.getRefndAcnutNo();
			transfer9 = EwalletConstant.EWALLET_SORIN_CODE;
			transfer11= ewalletTransferVO.getEwalletAcnutNo();
			transfer21= ewalletTransferVO.getBsnmRegistNo();
			
		}else if(StringUtils.equals(ewalletTransferVO.getIemSeCode(), "0003")) {
			/** 이체 **/
			base28 	= "1";
			
			String precdntAt = StringUtils.isEmpty(ewalletTransferVO.getPrecdntAt()) ? "N" : ewalletTransferVO.getPrecdntAt(); // 선수금 여부, default N
			
			// ewalletExcclcTyCode(이월렛 정산 유형 코드) [01-고객입금,02-고객환불,03-주문결제,04-중량정산,05-취소정산,06-교환정산,07-반품정산,08-비용정산]
			// setleNo(결제번호)
			// precdntAt(선수금 여부: [Y : 선수금 O, C : 부분상환, N : 선수금 X])
			super.setBase30(ewalletTransferVO.getEwalletExcclcTyCode() + "|" + ewalletTransferVO.getSetleNo() + "|" + precdntAt);
			transfer5 = EwalletConstant.EWALLET_SORIN_CODE;
			transfer7 = ewalletTransferVO.getEwalletAcnutNo();
			transfer9 = EwalletConstant.EWALLET_HANABANK_CODE;
			transfer11= ewalletTransferVO.getSorinAcnutNo();
			transfer21= ewalletTransferVO.getBsnmRegistNo();
			
		}
		
		/* 이체거래시 입출기관구분 */
		super.setBase28(base28);
		
		/* 입금부 은행(제휴기관)코드 */
		this.transfer5 = transfer5;
		
		/* 입금부 계좌번호(가상) */
		this.transfer7 = transfer7;
		
		/* 출금부 은행(제휴기관)코드 */
		this.transfer9 = transfer9;
		
		/* 출금부 은행(제휴기관)코드 */
		this.transfer11 = transfer11;
		
		/* 출금부 은행(제휴기관)코드 */
		this.transfer21 = transfer21;
		
	}
	/* 인터페이스 번호 */
	private long intrfcSn;
	
	/* 업체번호 */
	private String entrpsNo;
	
	/* 결재기본 번호 */
	private String setleNo;
	
	/* 거래금액 */
	@ByteLimit(limit = 13, require = true, fill = true, fillStr = "0", fillLocation = true)
	private String transfer1;
	
	/* 양,음 구분표시 */
	@ByteLimit(limit = 1, example = " ")
	private String transfer2;

	/* 거래후 계좌잔액 */
	@ByteLimit(limit = 13, example = "0", repeat = true)
	private String transfer3;

	/* 미결제 타점권 금액 */
	@ByteLimit(limit = 13, example = "0", repeat = true)
	private String transfer4;

	/* 은행(제휴기관)코드 */
	@ByteLimit(limit = 8, require = true)
	private String transfer5;

	/* 입금계좌구분코드 */
	@ByteLimit(limit = 2, example = "00")
	private String transfer6;

	/* 계좌번호(가상) */
	@ByteLimit(limit = 16, require = true, fill = true, fillStr = " ")
	private String transfer7;

	/* 입금계좌성명 */
	@ByteLimit(limit = 20, example = " ", repeat = true)
	private String transfer8;

	/* 은행(제휴기관)코드 */
	@ByteLimit(limit = 8, require = true)
	private String transfer9;

	/* 출금계좌구분코드 */
	@ByteLimit(limit = 2, example = "00")
	private String transfer10;

	/* 계좌번호(가상) */
	@ByteLimit(limit = 16, require = true, fill = true, fillStr = " ")
	private String transfer11;

	/* 비밀번호 */
	@ByteLimit(limit = 8, example = " ", repeat = true)
	private String transfer12;

	/* 출금계좌성명 */
	@ByteLimit(limit = 20, example = " ", repeat = true)
	private String transfer13;

	/* 수수료금액 */
	@ByteLimit(limit = 5, example = "0", repeat = true)
	private String transfer14;

	/* 취급어음교환소코드 */
	@ByteLimit(limit = 2, example = "  ")
	private String transfer15;

	/* 개설어음교환소코드 */
	@ByteLimit(limit = 2, example = "  ")
	private String transfer16;

	/* 수취어음교환소코드 */
	@ByteLimit(limit = 2, example = "  ")
	private String transfer17;
	
	/* 취소 사유 */
	@ByteLimit(limit = 3, example = "   ")
	private String transfer18;

	/* 거래관리번호 */
	@ByteLimit(limit = 12, example = " " , repeat = true)
	private String transfer19;

	/* 배분수수료금액 */
	@ByteLimit(limit = 5, example = "0", repeat = true)
	private String transfer20;

	/* 주민번호 (사업자 등록 번호) */
	@ByteLimit(limit = 13, require = true, fill = true, fillStr = " ")
	private String transfer21;

	/* 원거래번호 */
	@ByteLimit(limit = 7, example = " ", repeat = true)
	private String transfer22;

	/* FILLER */
	@ByteLimit(limit = 9, example = " ", repeat = true)
	private String transfer23;
	
	
}
