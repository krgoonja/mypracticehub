package com.sorincorp.api.ewallet.comm.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.sorincorp.api.ewallet.comm.annotaion.ByteLimit;
import com.sorincorp.api.ewallet.comm.constant.EwalletConstant;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EwalletCommUtil {

	/**
	 * <pre>
	 * 처리내용: 상속 받은 클래스의 field를 찾음
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param fields
	 * @param type
	 */
	protected static void getSuperclassFields(List<Field> fields, Class<?> type) {
		if(type != null) {
			fields.addAll(0, Arrays.asList(type.getDeclaredFields()));
			getSuperclassFields(fields, type.getSuperclass());
		}
	}

	/**
	 * <pre>
	 * 처리내용: 해당 vo의 전문을 byte로 변환
	 * </pre>
	 * @date 2021. 7. 6.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 6.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public static byte[] getByte(Object obj, int totalLength) throws Exception {

		byte[] baseByte = new byte[totalLength];
		int startIndex = 0;
		List<Field> fields = new ArrayList<Field>();
		getSuperclassFields(fields, obj.getClass());

		for(Field field : fields) {
			if (field.isAnnotationPresent(ByteLimit.class)) {

				field.setAccessible(true);
				String fieldValue = StringUtils.EMPTY;
				ByteLimit byteLimit = field.getAnnotation(ByteLimit.class);
				int limit = byteLimit.limit();

//				fieldValue = (String) Optional.ofNullable(field.get(obj)).orElseGet(() -> {
//					if(byteLimit.require()) {
//						return StringUtils.EMPTY;
//					}else if(byteLimit.day()) {
//						return DateUtil.getNowDate();
//					}else if(byteLimit.time()) {
//						return DateUtil.getNowDateTime("HHmmss");
//					}else if(byteLimit.repeat()) {
//						return StringUtils.repeat(byteLimit.example(), limit);
//					}else {
//						return byteLimit.example();
//					}
//				});
				if(field.get(obj) == null) {
					if(byteLimit.require()) {
						fieldValue = StringUtils.EMPTY;
					}else if(byteLimit.day()) {
						fieldValue = DateUtil.getNowDate();
					}else if(byteLimit.time()) {
						fieldValue = DateUtil.getNowDateTime("HHmmss");
					}else if(byteLimit.repeat()) {
						fieldValue = StringUtils.repeat(byteLimit.example(), limit);
					}else {
						fieldValue = byteLimit.example();
					}
				}else {
					String fieldStr = String.valueOf(field.get(obj));
					if(byteLimit.fill() && !StringUtils.equals(byteLimit.fillStr(), StringUtils.EMPTY) && byteLimit.limit() > fieldStr.length()) {
						if(byteLimit.fillLocation()) {
							fieldValue = StringUtils.repeat(byteLimit.fillStr(), byteLimit.limit() - fieldStr.length()) + fieldStr;
						}else{
							fieldValue = fieldStr + StringUtils.repeat(byteLimit.fillStr(), byteLimit.limit() - fieldStr.length());
						}
					}else {
						fieldValue = fieldStr;
					}

				}

				/**
				 * 해당 field의 byte 길이와 설정한 길이가 맞는지 체크
				*/
				if(fieldValue.getBytes(EwalletConstant.EWALLET_DEFAULT_ENCODING).length != limit) {
					throw new Exception("변환된 Field의 Byte 길이가 제한된 길이와 다름 : " + field.getName());
				}else {
					for(int i = 0 ; i < limit; i++) {
						baseByte[startIndex] = fieldValue.getBytes(EwalletConstant.EWALLET_DEFAULT_ENCODING)[i];
						startIndex++;
					}

				}

			}

		}

		/**
		 * 설정한 총 전문길이와 만들어진 전문 byte길이가 맞는지 체크
		*/
		if(baseByte.length != startIndex) {
			throw new Exception("변환된 전문 총 길이가 제한된 길이와 다름");
		}

		return baseByte;
	}


	/**
	 * <pre>
	 * 처리내용: 전문 byte에서 선택 영역 추출
	 * </pre>
	 * @date 2021. 7. 8.
	 * @author Sim sung bo
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 8.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param receiveByte
	 * @return
	 */
	public static String getIndexStr(byte[] receiveByte, int index, int length) {

		String indexStr  = StringUtils.EMPTY;

		try {
			indexStr  = new String(Arrays.copyOfRange
					( receiveByte
					, index
					, index + length
					), EwalletConstant.EWALLET_DEFAULT_ENCODING);

		}catch(Exception e) {

			log.error(e.getMessage());

		}

		return indexStr;
	}

	/**
	 * <pre>
	 * 처리내용: Byte를 Object Filed에 맵핑시켜준다.
	 * Parameter로 보내주는 class의 Field가 순서대로 정렬되어 있어야 정확한 값이 맵핑된다.
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 26.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param <T>
	 * @param receiveByte
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public static <T> T getObjForBytes(byte[] receiveByte, Class<T> clazz) throws Exception {
		T obj = clazz.newInstance();
		List<Field> fields = new ArrayList<Field>();
		getSuperclassFields(fields, obj.getClass());
		int index = 0;

		for(Field field : fields) {
			if(field.isAnnotationPresent(ByteLimit.class)) {
				field.setAccessible(true);
				ByteLimit byteLimit = field.getAnnotation(ByteLimit.class);

				int limit = byteLimit.limit();
				field.set(obj, new String(Arrays.copyOfRange(receiveByte, index, index + limit), EwalletConstant.EWALLET_DEFAULT_ENCODING));
				index += limit;
			}
		}

		return obj;
	}




}
