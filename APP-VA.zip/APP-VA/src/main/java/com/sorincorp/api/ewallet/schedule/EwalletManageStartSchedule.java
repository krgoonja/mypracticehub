package com.sorincorp.api.ewallet.schedule;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.api.ewallet.model.EwalletManageVO;
import com.sorincorp.api.ewallet.service.EwalletService;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class EwalletManageStartSchedule {
	
	@Autowired
	private EwalletService ewalletService;
	
	/**  이월렛 관리 전문 메시지 타입 **/
	private static final String MANAGE_START_MSG_TYPE = "2100";
	
//	@Scheduled(cron = "${ewallet.manage.start.time}")
	public void startEwalletManage() {
		EwalletManageVO ewalletManageVO = new EwalletManageVO();
		ewalletManageVO.setManageType(MANAGE_START_MSG_TYPE);
		try {
			ewalletService.ewalletManage(ewalletManageVO);
		}catch (Exception e) {
			log.debug("startEwalletManage error : " + e);
		}
	}
	

	
}
