package com.sorincorp.api.ewallet.comm.annotaion;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.apache.commons.lang3.StringUtils;

@Inherited  							// 자식클래스에 상속할지 결정
@Documented								// Java doc에 문서화 여부를 결정
@Retention(RetentionPolicy.RUNTIME)		// 어노테이션의 지속 시간을 정함
@Target(ElementType.FIELD)				// 어노테이션을 작성할 곳
public @interface ByteLimit {
	
	String example() default StringUtils.EMPTY;
	
	/**
	 * 처리내용: Byte 변환 시 제한된 길이를 설정한다.
	 */
	int limit();
	
	/**
	 * 처리내용: 해당 필드의 필수 여부를 설정한다.
	 */
	boolean require() default false;
	
	/**
	 * 처리내용: day (yyyyMMdd) 로 자동 변환할지 설정한다.
	 */
	boolean day() default false;
	
	/**
	 * 처리내용: time (HHmmSS) 로 자동 변환할지 설정한다.
	 */
	boolean time() default false;
	
	/**
	 * 처리내용: example의 값을 limit값만큼 반복할지 설정한다.
	 */
	boolean repeat() default false;
	
	/**
	 * 처리내용: 해당 field의 값이 있을때 limit 만큼 여백을 채워 줄지 설정한다.
	 */
	boolean fill() default false;
	
	/**
	 * 처리내용: fill의 값이 true일떄 어떤 String으로 채워줄지 설정한다.
	 */
	String fillStr() default StringUtils.EMPTY;
	
	/**
	 * 처리내용: fill의 값이 true일떄 fillStr값을 어느방향으로 채울지 설정한다.
	 * true : 앞
	 * false: 뒤
	 */
	boolean fillLocation() default false;
	
}
