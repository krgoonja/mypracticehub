package com.sorincorp.api.ewallet.model;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class EwalletTransferVO {

	/** 주문 번호 **/
	private String orderNo;
	
	/** 업체번호 **/
	@NotEmpty(message = "업체 번호 미존재")
	private String entrpsNo;
	
	/** 사업자 등록 번호 **/
	private String bsnmRegistNo;
	
	/** Ewallet 가상 계좌 번호 **/
	private String ewalletAcnutNo;
	
	/** Ewallet 고객 환불 계좌 번호 **/
	private String refndAcnutNo;
	
	/** 이월렛 정산 유형 코드 **/
	private String ewalletExcclcTyCode;
	
	/** 서린상사 정산 계좌 **/
	private String sorinAcnutNo;
	
	/** 결재기본 번호 **/
	private String setleNo;
	
	/** 인터페이스 번호 **/
	private long intrfcSn;
	
	/** 항목구분코드 **/
	@NotEmpty(message = "항목구분코드 미존재")
	@Size(min=4, max=4, message = "항목구분코드 형식 불일치")
	private String iemSeCode;
	
	/** 거래금액  **/
	@DecimalMax(value = "9999999999999", message = "거래 금액 초과")
	@DecimalMin(value = "1", message = "거래 금액 없음")
	private long delngAmount;
	
	/** 거래 일련 번호 **/
	private String delngSeqNo;
	
	/** 환불 요청 일시 **/
	private String refndRequstDt;
	
	/** 선수금 여부: [Y : 선수금 O, C : 부분상환, N : 선수금 X] **/
	private String precdntAt;

	/** 부분상환 여부: [Y : 부분입금 N : 전체입금] **/
	private String partRepyAt;
	
	/** 이월렛 거래 구분 코드 **/
	private String ewalletDelngSeCode;
	
	private String testCode; // 테스트 완료 후 제거 20211115
}
