/**
 *
 */
package com.sorincorp.api.ewallet.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import lombok.Data;

/**
 * EwalletUseRegistConfmVO.java
 * @version
 * @since 2021. 8. 26.
 * @author srec0009
 */
@Data
public class EwalletUseRegistConfmVO {

	/**
	 * 업체 번호
	 */
	@NotEmpty(message = "업체 번호 미존재")
	@Size(min=5, max=5, message = "업체 번호 형식 불익치")
	private String entrpsNo;

	/**
	 * 가상계좌번호
	 */
	@NotEmpty(message = "계좌 번호 미존재")
	@Size(min=16, max=16, message = "계좌 번호 형식 불일치")
	private String virtlAcnutNo;

	/**
	 * 계좌 확인 여부
	 */
	@NotEmpty(message = "계좌 확인 여부 체크 불가")
	@Size(min=1, max=1, message = "계좌 확인 여부 형식 불일치")
	private String acnutCnfirmAt;

	/**
	 * 서비스 동의 여부
	 */
	@NotEmpty(message = "서비스 동의 여부 체크 불가")
	@Size(min=1, max=1, message = "서비스 동의 여부 형식 불일치")
	private String svcAgreAt;

	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;

	/**
	 * 최종 변경 일시
	 */
	private String lastChangerDt;

	/**
	 * 환불 계좌 정합성 여부
	 */
	private String refndAcnutRgrsynthAt;
	/**
	 * 환불 계좌 정합성 일시
	 */
	private String refndAcnutRgrsynthDt;

	private int intrfcSn;

}
