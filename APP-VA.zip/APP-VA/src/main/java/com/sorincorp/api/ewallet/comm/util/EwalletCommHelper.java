package com.sorincorp.api.ewallet.comm.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.util.DateUtil;


@Component
@ComponentScan({"com.sorincorp.comm.*"})
public class EwalletCommHelper {
	
	@Autowired
	private AssignService assignService;
	
	/**
	 * <pre>
	 * 처리내용: 거래일련번호를 거래구분코드에 따라 채번하여 가저온다.
	 * </pre>
	 * @date 2021. 8. 27.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 27.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param msgType
	 * @return
	 * @throws Exception
	 */
	public synchronized String getEwalletAssign(String msgType) throws Exception {
		return msgType + assignService.selectAssignValue("OR", "DELNG_SEQ_NO", DateUtil.getNowDate(), "system", 6);
	}

}
