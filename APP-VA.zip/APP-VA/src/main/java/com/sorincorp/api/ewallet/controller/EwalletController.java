package com.sorincorp.api.ewallet.controller;

import javax.validation.Valid;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.ewallet.comm.constant.EwalletConstant;
import com.sorincorp.api.ewallet.comm.exception.EwalletCustomException;
import com.sorincorp.api.ewallet.comm.response.EwalletCommResponse;
import com.sorincorp.api.ewallet.model.EwalletAccountVO;
import com.sorincorp.api.ewallet.model.EwalletManageVO;
import com.sorincorp.api.ewallet.model.EwalletResultVO;
import com.sorincorp.api.ewallet.model.EwalletTransferVO;
import com.sorincorp.api.ewallet.service.EwalletService;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@Api("Ewallet 전문 통신")
@RequestMapping("/api")
public class EwalletController {

	@Autowired
	private EwalletService ewalletService;
	
	@PostMapping("/ewallet/apiCallTest")
	public ResponseEntity<?> ewalletApiCallTest(@RequestBody @Valid EwalletAccountVO ewalletAccountVO, BindingResult bindingResult) throws Exception {
		
		if(bindingResult.hasErrors()) {
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(new EwalletCommResponse(EwalletConstant.ERROR_RESULT_CODE, bindingResult.getFieldError().getDefaultMessage()));
		}
		
		EwalletAccountVO accountVo = ewalletService.ewalletApiCallTest(ewalletAccountVO);
		
		return ResponseEntity.status(HttpStatus.OK).body(new EwalletCommResponse(EwalletConstant.SUCCESS_RESULT_CODE, EwalletConstant.SUCCESS_RESULT_MSG, accountVo));
	}
	
	/**
	 * <pre>
	 * 처리내용: 업체 번호 기준으로 하나은행 이월렛 잔액을 조회한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param ewalletAccountVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/ewallet/money")
	public ResponseEntity<?> ewalletAccountMoney(@RequestBody @Valid EwalletAccountVO ewalletAccountVO, BindingResult bindingResult) throws Exception {
		
		if(bindingResult.hasErrors()) {
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(new EwalletCommResponse(EwalletConstant.ERROR_RESULT_CODE, bindingResult.getFieldError().getDefaultMessage()));
		}
		
		EwalletAccountVO accountVo = ewalletService.ewalletAccountMoney(ewalletAccountVO);
		
		return ResponseEntity.status(HttpStatus.OK).body(new EwalletCommResponse(EwalletConstant.SUCCESS_RESULT_CODE, EwalletConstant.SUCCESS_RESULT_MSG, accountVo));
	}
	
	/**
	 * <pre>
	 * 처리내용: 하나은행 이월렛 거래를 진행한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param ewalletTransferVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/ewallet/transfer")
	public ResponseEntity<?> ewalletDoTransfer(@RequestBody @Valid EwalletTransferVO ewalletTransferVO, BindingResult bindingResult) throws Exception{
		
		if(bindingResult.hasErrors()) {
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(new EwalletCommResponse(EwalletConstant.ERROR_RESULT_CODE, bindingResult.getFieldError().getDefaultMessage()));
		}
		
		ewalletService.ewalletDoTransfer(ewalletTransferVO);
		
		return ResponseEntity.status(HttpStatus.OK).body(new EwalletCommResponse(EwalletConstant.SUCCESS_RESULT_CODE, EwalletConstant.SUCCESS_RESULT_MSG, ewalletTransferVO));
	}
	
	@PostMapping("/ewallet/vaEwalletTest")
	public ResponseEntity<?> vaEwalletTest(@RequestBody @Valid EwalletTransferVO ewalletTransferVO, BindingResult bindingResult) throws Exception {
		
		for(int a=0; a<Integer.parseInt(ewalletTransferVO.getTestCode()); a++) {
			ewalletService.vaEwalletTest(ewalletTransferVO, a);
		}
		
		return ResponseEntity.status(HttpStatus.OK).body(new EwalletCommResponse(EwalletConstant.SUCCESS_RESULT_CODE, EwalletConstant.SUCCESS_RESULT_MSG, ewalletTransferVO));
	}
	
	/**
	 * <pre>
	 * 처리내용: 거래에대한 처리 결과를 조회한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param ewalletResultVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/ewallet/result")
	public ResponseEntity<?> ewalletChkTransfer(@RequestBody @Valid EwalletResultVO ewalletResultVO, BindingResult bindingResult) throws Exception{
		
		if(bindingResult.hasErrors()) {
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(new EwalletCommResponse(EwalletConstant.ERROR_RESULT_CODE, bindingResult.getFieldError().getDefaultMessage()));
		}

		EwalletResultVO resultVo = ewalletService.ewalletChkTransfer(ewalletResultVO);
		
		return ResponseEntity.status(HttpStatus.OK).body(new EwalletCommResponse(EwalletConstant.SUCCESS_RESULT_CODE, EwalletConstant.SUCCESS_RESULT_MSG, resultVo));
	}
	
	/**
	 * <pre>
	 * 처리내용: 개시, 장애, 장애해제 등 관리전문을 호출한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param ewalletManageVO
	 * @param bindingResult
	 * @return
	 * @throws Exception
	 */
	@PostMapping("/ewallet/manage")
	public ResponseEntity<?> ewalletManage(@RequestBody @Valid EwalletManageVO ewalletManageVO, BindingResult bindingResult) throws Exception{
		
		if(bindingResult.hasErrors()) {
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(new EwalletCommResponse(EwalletConstant.ERROR_RESULT_CODE, bindingResult.getFieldError().getDefaultMessage()));
		}

		ewalletService.ewalletManage(ewalletManageVO);
		
		return ResponseEntity.status(HttpStatus.OK).body(new EwalletCommResponse(EwalletConstant.SUCCESS_RESULT_CODE, EwalletConstant.SUCCESS_RESULT_MSG, ewalletManageVO));
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 이월렛 관련 Exception을 처리한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param e
	 * @return
	 * @throws Exception
	 */
	@ExceptionHandler(EwalletCustomException.class)
	public ResponseEntity<?> ewalletException(Exception e) throws Exception{
		String resultMsg = e.getMessage();
		log.error("[EwalletCustomException][ex.getMessage()] : " + resultMsg);
		
		if(resultMsg.indexOf(e.getClass().getName()) > -1) {
			resultMsg = resultMsg.replace(e.getClass().getName(), "").replace(": ", "");
		}
		
		String stacktrace = ExceptionUtils.getStackTrace(e);
		log.error("[EwalletCustomException][stacktrace] : " + stacktrace);
		
		log.error("[EwalletCustomException][resultMsg] : " + resultMsg);
		
		return ResponseEntity.status(HttpStatus.OK).body(new EwalletCommResponse(EwalletConstant.ERROR_RESULT_CODE, resultMsg, null));
	} 
	
	/**
	 * <pre>
	 * 처리내용: 예기치 못한 Exception을 처리한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param e
	 * @return
	 * @throws Exception
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> ewalletCommException(Exception e) throws Exception{
		String resultMsg = e.getMessage();
		log.error("[Exception][e.getMessage()] : " + resultMsg);
		
		String stacktrace = ExceptionUtils.getStackTrace(e);
		log.error("[Exception][stacktrace] : " + stacktrace);
		
		return ResponseEntity.status(HttpStatus.OK).body(new EwalletCommResponse(EwalletConstant.ERROR_RESULT_CODE, resultMsg, null));
	} 
	
}
