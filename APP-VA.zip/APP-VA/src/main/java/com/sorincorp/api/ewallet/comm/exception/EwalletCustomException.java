package com.sorincorp.api.ewallet.comm.exception;

@SuppressWarnings("serial")
public class EwalletCustomException extends Exception{

	public EwalletCustomException() {};
	public EwalletCustomException(String message) {super(message);};
	
}
