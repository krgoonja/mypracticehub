package com.sorincorp.api.ewallet.server.socket;

import java.net.InetSocketAddress;

import javax.annotation.PreDestroy;

import org.springframework.stereotype.Component;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Component
public class EwalletServerSocket {
	
	private final ServerBootstrap serverBootstrap;
	
	private final InetSocketAddress tcpPort;
	
	private Channel serverChannel;
	
	public void start() {
		
		log.debug("serverChannel start()");
		
		try {
			// ChannelFuture: I/O operation의 결과나 상태를 제공하는 객체
            // 지정한 host, port로 소켓을 바인딩하고 incoming connections을 받도록 준비함
			ChannelFuture serverChannelFuture = serverBootstrap.bind(tcpPort).sync();
			
			// 서버 소켓이 닫힐 때까지 기다림
			serverChannel = serverChannelFuture.channel().closeFuture().sync().channel();
			
		} catch (InterruptedException e) {
			log.debug("start error : " + e.getMessage());
		}
		
	}
	
	// 서버 소켓이 제거 되기전에 실행할 메소드
	@PreDestroy
	public void stop() {
		
		log.debug("serverChannel stop()");
		
		if (serverChannel != null) {
            serverChannel.close();
            serverChannel.parent().closeFuture();
        }
	}
}
