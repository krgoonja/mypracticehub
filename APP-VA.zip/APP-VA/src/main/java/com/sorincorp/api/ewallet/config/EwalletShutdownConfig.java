package com.sorincorp.api.ewallet.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.stereotype.Component;

import com.sorincorp.api.ewallet.server.socket.EwalletServerSocket;

@Component
public class EwalletShutdownConfig implements ApplicationListener<ContextClosedEvent>{
	
	@Autowired
	private EwalletServerSocket ewalletServerSocket;
	
	@Override
	public void onApplicationEvent(ContextClosedEvent event) {
		ewalletServerSocket.stop();
	}

}
