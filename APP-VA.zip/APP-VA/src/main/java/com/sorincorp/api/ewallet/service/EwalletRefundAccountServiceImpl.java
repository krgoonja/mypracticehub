package com.sorincorp.api.ewallet.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.ewallet.client.socket.EwalletClientSocket;
import com.sorincorp.api.ewallet.comm.constant.EwalletConstant;
import com.sorincorp.api.ewallet.comm.entity.EwalletRefundAccountEntity;
import com.sorincorp.api.ewallet.comm.util.EwalletCommUtil;
import com.sorincorp.api.ewallet.mapper.EwalletRefundAccountMapper;
import com.sorincorp.api.ewallet.model.EwalletRefundAccountVO;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.mbLog.mapper.MbLogMapper;
import com.sorincorp.comm.util.CryptoUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EwalletRefundAccountServiceImpl implements EwalletRefundAccountService {

	@Autowired
	private EwalletClientSocket ewalletClientSocket;

	@Autowired
	AssignService assignService;

	@Autowired
	private EwalletRefundAccountMapper ewalletRefundMapper;

	@Autowired
	private MbLogMapper mbLogMapper;

	@Override
	public void ewalletRefundAccountConnet(EwalletRefundAccountVO ewalletRefundAccountVO) throws Exception {
		// TODO Auto-generated method stub

		EwalletRefundAccountEntity accountEntity = null;
		EwalletRefundAccountVO ewalletRefundAccountVO2 = null;
		byte[] sendByte = null;
		String refndAcnutSttusCode = "";
		String serialNo = "7";

		String ewalletAcnutNo = "";
		String refndAcnutNo = "";

		try {
			serialNo += assignService.selectAssignValue("MB", "EWALLET_REFUND", "EWALLET_REFUND", "EWALLET-VA", 6);
			accountEntity = new EwalletRefundAccountEntity(ewalletRefundAccountVO.getRefundAcnutNo(), ewalletRefundAccountVO.getEwalletAcnutNo(), ewalletRefundAccountVO.getBsnmRegistNo(), ewalletRefundAccountVO.getEntrpsNo(), serialNo, ewalletRefundAccountVO.getDelngSe());
			sendByte = EwalletCommUtil.getByte(accountEntity, EwalletConstant.EWALLET_TCP_REFUND_ACCOUNT_LENGTH);
			log.debug("sendByte : " + EwalletCommUtil.getIndexStr(sendByte, 0, 400));
			ewalletClientSocket.sendEwallt(sendByte, false);

			//거래구분 02(계좌해지)이면 환불계좌상태를 07(계좌해지)로 세팅
			if("2".equals(ewalletRefundAccountVO.getDelngSe())) {
				refndAcnutSttusCode = "07";
			}
		} catch (Exception e) {
			// TODO: handle exception
			log.error(e.toString());
			refndAcnutSttusCode = "02";

		} finally {

			if(!"02".equals(refndAcnutSttusCode) && !"07".equals(refndAcnutSttusCode)) {

				ewalletAcnutNo = accountEntity.getAccount1();
				refndAcnutNo = accountEntity.getAccount3();

				if(ewalletAcnutNo != null && !"".equals(ewalletAcnutNo)) {
					//가상계좌 암호화
					try {
						log.debug("가상계좌 암호화 전 =========> " + ewalletAcnutNo);
	                    ewalletAcnutNo = CryptoUtil.encryptAES256(ewalletAcnutNo);
	                    log.debug("가상계좌 암호화 후 =========> " + ewalletAcnutNo);
	                    accountEntity.setAccount1(ewalletAcnutNo);
					} catch (Exception e) {
						// TODO: handle exception
						log.error("ewalletRefundAccountConnet EWALLET_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
					}
				}

				if(refndAcnutNo != null && !"".equals(refndAcnutNo)) {
					//환불계좌 암호화
					try {
						log.debug("환불계좌 암호화 전 =========> " + refndAcnutNo);
						refndAcnutNo = CryptoUtil.encryptAES256(refndAcnutNo);
	                    log.debug("환불계좌 암호화 후 =========> " + refndAcnutNo);
	                    accountEntity.setAccount3(refndAcnutNo);
					} catch (Exception e) {
						// TODO: handle exception
						log.error("ewalletRefundAccountConnet REFND_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
					}
				}
				//인터페이스 이월렛 계좌등록 테이블 insert
				ewalletRefundMapper.insertIfEwalletAcnutRegistRequst(accountEntity);
				//인터페이스순번 세팅
				ewalletRefundAccountVO.setIntrfcSn(accountEntity.getIntrfcSn());
				log.debug("ewalletRefundAccountVO.getIntrfcSn() =============>" + ewalletRefundAccountVO.getIntrfcSn());

				ewalletAcnutNo = ewalletRefundAccountVO.getEwalletAcnutNo();

				if(ewalletAcnutNo != null && !"".equals(ewalletAcnutNo)) {
					//가상계좌 암호화 20220119 srec0030
					try {
						log.debug("가상계좌 암호화 전 ==================>" + ewalletAcnutNo);
						ewalletAcnutNo = CryptoUtil.encryptAES256(ewalletAcnutNo.trim());
						log.debug("가상계좌 암호화 후 ==================>" + ewalletAcnutNo);
						ewalletRefundAccountVO.setEwalletAcnutNo(ewalletAcnutNo);
					} catch (Exception e) {
						// TODO: handle exception
						log.error("ewalletRefundAccountConnet EWALLET_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
					}
				}

				if("0".equals(ewalletRefundAccountVO.getDelngSe())) {
					//거래구분 0(등록)
					ewalletRefundMapper.updateOpEwalletAcnutBas(ewalletRefundAccountVO);
					ewalletRefundMapper.insertOpEwalletAcnutBasHst(ewalletRefundAccountVO);

					ewalletRefundMapper.insertOpEwalletAcnutDtl(ewalletRefundAccountVO);
					ewalletRefundMapper.insertOpEwalletAcnutDtlHst(ewalletRefundAccountVO);
				} else if("1".equals(ewalletRefundAccountVO.getDelngSe())) {
					//거래구분 1(변경)
					ewalletRefundMapper.updateOpEwalletAcnutDtl(ewalletRefundAccountVO);
					ewalletRefundMapper.insertOpEwalletAcnutDtlHst(ewalletRefundAccountVO);
				}

				refndAcnutSttusCode = "01";
				ewalletRefundAccountVO2 = new EwalletRefundAccountVO();
				ewalletRefundAccountVO2.setEntrpsNo(ewalletRefundAccountVO.getEntrpsNo());
				ewalletRefundAccountVO2.setRefndAcnutSttusCode(refndAcnutSttusCode);
				ewalletRefundAccountVO2.setEwalletAcnutNo(ewalletRefundAccountVO.getEwalletAcnutNo());

				ewalletRefundMapper.updateRefndAcnutSttusCode(ewalletRefundAccountVO2);
//				ewalletRefundMapper.insertMbEntrpsInfoBasHst(ewalletRefundAccountVO2);
				mbLogMapper.insertMbEntrpsInfoBasHst(ewalletRefundAccountVO2.getEntrpsNo());

				//임시 테스트
				//reciveResponseData(sendByte);
			} else if("07".equals(refndAcnutSttusCode)) {
				//임시 테스트
				//reciveResponseData(sendByte);

				ewalletAcnutNo = accountEntity.getAccount1();
				refndAcnutNo = accountEntity.getAccount3();

				if(ewalletAcnutNo != null && !"".equals(ewalletAcnutNo)) {
					//가상계좌 암호화
					try {
						log.debug("가상계좌 암호화 전 =========> " + ewalletAcnutNo);
	                    ewalletAcnutNo = CryptoUtil.encryptAES256(ewalletAcnutNo);
	                    log.debug("가상계좌 암호화 후 =========> " + ewalletAcnutNo);
	                    accountEntity.setAccount1(ewalletAcnutNo);
					} catch (Exception e) {
						// TODO: handle exception
						log.error("ewalletRefundAccountConnet EWALLET_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
					}
				}

				if(refndAcnutNo != null && !"".equals(refndAcnutNo)) {
					//환불계좌 암호화
					try {
						log.debug("환불계좌 암호화 전 =========> " + refndAcnutNo);
						refndAcnutNo = CryptoUtil.encryptAES256(refndAcnutNo);
	                    log.debug("환불계좌 암호화 후 =========> " + refndAcnutNo);
	                    accountEntity.setAccount3(refndAcnutNo);
					} catch (Exception e) {
						// TODO: handle exception
						log.error("ewalletRefundAccountConnet REFND_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
					}
				}
				//인터페이스 이월렛 계좌등록 테이블 insert
				ewalletRefundMapper.insertIfEwalletAcnutRegistRequst(accountEntity);
			}
		}
	}

	@Override
	public void reciveResponseData(byte[] receiveByte) throws Exception {
		// TODO Auto-generated method stub
		if(receiveByte != null) {
			log.debug("receiveByte : " + EwalletCommUtil.getIndexStr(receiveByte, 0, 400));
			String entrpsNo = "";
			String resCode = "";
			String refndAcnutSttusCode = "";
			String ewalletAcnutNo = "";
			String ewalletAcnutNoTrim = "";
			String newRefndAcnutNo = "";
			String newRefndAcnutNoTrim = "";
			String refndAcnutNo = "";
			String refndAcnutNoTrim = "";
			String oldRefndAcnutNo = "";
			String oldRefndAcnutNoTrim = "";
			String delngSe = "";

			try {
				//응답코드
				resCode = EwalletCommUtil.getIndexStr(receiveByte, 51, 3);
				//업체번호
				entrpsNo = EwalletCommUtil.getIndexStr(receiveByte, 236, 5);
				//요청 환불계좌
				ewalletAcnutNo = EwalletCommUtil.getIndexStr(receiveByte, 300, 16);
				ewalletAcnutNoTrim = ewalletAcnutNo.trim();
				//요청 환불계좌
				refndAcnutNo = EwalletCommUtil.getIndexStr(receiveByte, 326, 16);
				refndAcnutNoTrim = refndAcnutNo.trim();
				//응답 환불계좌
				newRefndAcnutNo = EwalletCommUtil.getIndexStr(receiveByte, 343, 16);
				newRefndAcnutNoTrim = newRefndAcnutNo.trim();
				//부기 환불계좌(구계좌)
				oldRefndAcnutNo = EwalletCommUtil.getIndexStr(receiveByte, 359, 16);
				oldRefndAcnutNoTrim = oldRefndAcnutNo.trim();
				//거래구분코드 0:등록, 1:변경, 2:해지
				delngSe = EwalletCommUtil.getIndexStr(receiveByte, 342, 1).trim();

				if(ewalletAcnutNo != null && !"".equals(ewalletAcnutNo)) {
					try {
						log.debug("가상계좌번호 암호화 전 ===========>" + ewalletAcnutNo);
						ewalletAcnutNo = CryptoUtil.encryptAES256(ewalletAcnutNo);
						ewalletAcnutNoTrim = CryptoUtil.encryptAES256(ewalletAcnutNoTrim);
						log.debug("가상계좌번호 암호화 후 ===========>" + ewalletAcnutNo);
					} catch (Exception e) {
						// TODO: handle exception
						log.error("reciveResponseData VIRTL_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
					}
				}
				if(refndAcnutNo != null && !"".equals(refndAcnutNo)) {
					try {
						log.debug("요청환불계좌번호 암호화 전 ===========>" + refndAcnutNo);
						refndAcnutNo = CryptoUtil.encryptAES256(refndAcnutNo);
						refndAcnutNoTrim = CryptoUtil.encryptAES256(refndAcnutNoTrim);
						log.debug("요청환불계좌번호 암호화 후 ===========>" + refndAcnutNo);
					} catch (Exception e) {
						// TODO: handle exception
						log.error("reciveResponseData REQUST_REFND_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
					}
				}

				if(newRefndAcnutNo != null && !"".equals(newRefndAcnutNoTrim)) {
					try {
						log.debug("응답환불계좌번호 암호화 전 ===========>" + newRefndAcnutNo);
						newRefndAcnutNo = CryptoUtil.encryptAES256(newRefndAcnutNo);
						newRefndAcnutNoTrim = CryptoUtil.encryptAES256(newRefndAcnutNoTrim);
						log.debug("응답환불계좌번호 암호화 후 ===========>" + newRefndAcnutNo);
					} catch (Exception e) {
						// TODO: handle exception
						log.error("reciveResponseData RSPNS_REFND_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
					}
				}

				if(oldRefndAcnutNo != null && !"".equals(oldRefndAcnutNoTrim)) {
					try {
						log.debug("부기계좌번호 암호화 전 ===========>" + oldRefndAcnutNo);
						oldRefndAcnutNo = CryptoUtil.encryptAES256(oldRefndAcnutNo);
						oldRefndAcnutNoTrim = CryptoUtil.encryptAES256(oldRefndAcnutNoTrim);
						log.debug("부기계좌번호 암호화 후 ===========>" + oldRefndAcnutNo);
					} catch (Exception e) {
						// TODO: handle exception
						log.error("reciveResponseData BUKIP_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
					}
				}

//				log.debug("resCode ==============>" + resCode);
//				log.debug("entrpsNo ==============>" + entrpsNo);
//				log.debug("ewalletAcnutNo ==============>" + ewalletAcnutNo);
//				log.debug("newRefndAcnutNo ==============>" + newRefndAcnutNo);
//				log.debug("oldRefndAcnutNo ==============>" + oldRefndAcnutNo);
				if("000".equals(resCode)) {
					//응답코드 정상일때
					if("0".equals(delngSe) || "1".equals(delngSe)) {
						//등록, 변경
						refndAcnutSttusCode = "03";
					} else if("2".equals(delngSe)) {
						//해지
						refndAcnutSttusCode = "07";
					}
				} else {
					//응답코드 에러일때
					if("0".equals(delngSe) || "1".equals(delngSe)) {
						//등록, 변경
						refndAcnutSttusCode = "04";
					} else if("2".equals(delngSe)) {
						//해지
						refndAcnutSttusCode = "08";
					}
				}

				EwalletRefundAccountVO ifVO = new EwalletRefundAccountVO();
				//공통부 길이
				ifVO.setLt(EwalletCommUtil.getIndexStr(receiveByte, 0, 4));
				//공통부 cs번호
				ifVO.setCsNo(EwalletCommUtil.getIndexStr(receiveByte, 4, 4));
				//공통부 cs관리기관코드
				ifVO.setCsManageInsttCode(EwalletCommUtil.getIndexStr(receiveByte, 8, 8));
				//공통부 REACTION CODE
				ifVO.setReactCode(EwalletCommUtil.getIndexStr(receiveByte, 16, 1));
				//공통부 연속거래번호
				ifVO.setCtnuDelngNo(EwalletCommUtil.getIndexStr(receiveByte, 17, 3));
				//공통부 송수신 FLAG
				ifVO.setTrsmrcvAt(EwalletCommUtil.getIndexStr(receiveByte, 20, 1));
				//공통부 취급기관코드
				ifVO.setTrtmntInsttCode(EwalletCommUtil.getIndexStr(receiveByte, 21, 8));
				//공통부 취급영업점코드
				ifVO.setTrtmntBsnpointCode(EwalletCommUtil.getIndexStr(receiveByte, 29, 4));
				//공통부 취급단말코드
				ifVO.setTrtmntTrmnlCode(EwalletCommUtil.getIndexStr(receiveByte, 33, 5));
				//공통부 매체(발생)구분
				ifVO.setMediaOccrrncSe(EwalletCommUtil.getIndexStr(receiveByte, 38, 1));
				//공통부 전문구분코드(MSG TYPE)
				ifVO.setSpcltySeCode(EwalletCommUtil.getIndexStr(receiveByte, 39, 4));
				//공통부 거래구분코드
				ifVO.setDelngSeCode(EwalletCommUtil.getIndexStr(receiveByte, 43, 4));
				//공통부 항목구분코드
				ifVO.setIemSeCode(EwalletCommUtil.getIndexStr(receiveByte, 47, 4));
				//공통부 응답코드
				ifVO.setRspnsCode(EwalletCommUtil.getIndexStr(receiveByte, 51, 3));
				//공통부 거래일자
				ifVO.setDelngDe(EwalletCommUtil.getIndexStr(receiveByte, 54, 8));
				//공통부 거래시간
				ifVO.setDelngTime(EwalletCommUtil.getIndexStr(receiveByte, 62, 6));
				//공통부 거래일련번호
				ifVO.setDelngSeqNo(EwalletCommUtil.getIndexStr(receiveByte, 68, 7));
				//공통부 한글코드 구분
				ifVO.setKoreanCodeSe(EwalletCommUtil.getIndexStr(receiveByte, 75, 1));
				//공통부 마감후 구분
				ifVO.setAftcsSe(EwalletCommUtil.getIndexStr(receiveByte, 76, 1));
				//공통부 차액입금방법
				ifVO.setDfnntRcpmnyMth(EwalletCommUtil.getIndexStr(receiveByte, 77, 1));
				//공통부 개설기관코드
				ifVO.setEstblInsttCode(EwalletCommUtil.getIndexStr(receiveByte, 78, 8));
				//공통부 M/S TRACK번호
				ifVO.setTrackNo(EwalletCommUtil.getIndexStr(receiveByte, 86, 1));
				//공통부 M/S TRACK DATA
				ifVO.setTrackData(EwalletCommUtil.getIndexStr(receiveByte, 87, 141));
				//공통부 카드구분
				ifVO.setCardSe(EwalletCommUtil.getIndexStr(receiveByte, 228, 1));
				//공통부 카드일련번호
				ifVO.setCardSeqNo(EwalletCommUtil.getIndexStr(receiveByte, 229, 3));
				//공통부 ATM 거래가능 횟수
				ifVO.setAtmDelngPossCo(EwalletCommUtil.getIndexStr(receiveByte, 232, 2));
				//공통부 정형화된 조회 출력 구분
				ifVO.setInqireOutptSe(EwalletCommUtil.getIndexStr(receiveByte, 234, 1));
				//공통부 이체거래시 입출기관구분
				ifVO.setIppInsttSe(EwalletCommUtil.getIndexStr(receiveByte, 235, 1));
				//공통부 USER WORK AREA
				ifVO.setUserWorkArea(EwalletCommUtil.getIndexStr(receiveByte, 236, 14));
				//공통부 응답 MESSAGE
				ifVO.setRspnsMssage(EwalletCommUtil.getIndexStr(receiveByte, 250, 50));
				//개별부 가상계좌번호
				//ifVO.setVirtlAcnutNo(EwalletCommUtil.getIndexStr(receiveByte, 300, 16));
				ifVO.setVirtlAcnutNo(ewalletAcnutNo);
				//개별부 사업자번호
				ifVO.setBsnmNo(EwalletCommUtil.getIndexStr(receiveByte, 316, 10));
				//개별부 요청환불계좌번호
				//ifVO.setRefndAcnutNo(EwalletCommUtil.getIndexStr(receiveByte, 326, 16));
				ifVO.setRefndAcnutNo(refndAcnutNo);
				//개별부 거래구분
				ifVO.setDelngSe(EwalletCommUtil.getIndexStr(receiveByte, 342, 1));
				//개별부 응답환불계좌번호
				//ifVO.setNewRefndAcnutNo(EwalletCommUtil.getIndexStr(receiveByte, 343, 16));
				ifVO.setNewRefndAcnutNo(newRefndAcnutNo);
				//개별부 부기계좌번호
				//ifVO.setOldRefndAcnutNo(EwalletCommUtil.getIndexStr(receiveByte, 359, 16));
				ifVO.setOldRefndAcnutNo(oldRefndAcnutNo);
				//개별부 FILLER
				ifVO.setFil(EwalletCommUtil.getIndexStr(receiveByte, 375, 25));

				log.debug("ifVO ===================> " + ifVO.toString());
				//인터페이스 이월렛 계좌등록 응답 테이블 insert
				ewalletRefundMapper.insertIfEwalletAcnutRegistRspns(ifVO);
				//인터페이스 이월렛 계좌등록 요청 테이블 상태값 update
				ewalletRefundMapper.updateIfEwalletAcnutRegistRequst(ifVO);
			} catch (Exception e) {
				log.error(e.toString());
				refndAcnutSttusCode = "04";
			} finally {
				EwalletRefundAccountVO ewalletRefundAccountVO = new EwalletRefundAccountVO();
				ewalletRefundAccountVO.setEntrpsNo(entrpsNo);
				ewalletRefundAccountVO.setRefndAcnutSttusCode(refndAcnutSttusCode);
				//성공일 경우만 가상계좌 업데이트
				if("03".equals(refndAcnutSttusCode)) {
					ewalletRefundAccountVO.setEwalletAcnutNo(ewalletAcnutNoTrim);
					ewalletRefundAccountVO.setRefndAcnutNo(refndAcnutNoTrim);
					ewalletRefundAccountVO.setNewRefndAcnutNo(newRefndAcnutNoTrim);
					ewalletRefundAccountVO.setOldRefndAcnutNo(oldRefndAcnutNoTrim);
				} else if("07".equals(refndAcnutSttusCode)) {
					//계좌해지
					ewalletRefundAccountVO.setRefndAcnutSttusCode(refndAcnutSttusCode);
				} else {
					//등록, 변경 실패했을 경우 가상계좌번호 null로 업데이트, 해지일 경우에도 거래할수 없게 계좌정보 null로 업데이트
					ewalletRefundAccountVO.setEwalletAcnutNo(null);
					ewalletRefundAccountVO.setNewRefndAcnutNo(null);
					ewalletRefundAccountVO.setOldRefndAcnutNo(null);
				}

				ewalletRefundMapper.updateRefndAcnutSttusCode(ewalletRefundAccountVO);
//				ewalletRefundMapper.insertMbEntrpsInfoBasHst(ewalletRefundAccountVO);
				mbLogMapper.insertMbEntrpsInfoBasHst(ewalletRefundAccountVO.getEntrpsNo());
			}
		}
	}

}
