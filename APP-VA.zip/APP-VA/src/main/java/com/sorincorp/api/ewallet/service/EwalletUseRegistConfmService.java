/**
 *
 */
package com.sorincorp.api.ewallet.service;


/**
 * EwalletUseRegistConfmService.java
 * @version
 * @since 2021. 8. 26.
 * @author srec0009
 */
public interface EwalletUseRegistConfmService {

	void ewalletUseRegistConfm(byte[] receiveByte) throws Exception;

}
