package com.sorincorp.api.ewallet.comm.entity;

import com.sorincorp.api.ewallet.comm.annotaion.ByteLimit;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper = false)
@ToString(callSuper = true)
public class AccountRcpmnyEntity extends EwalletBaseEntity{

	public AccountRcpmnyEntity() {

		/* LENGTH */
		super.setBase1("0550");

		/* 취급기관코드 */
		super.setBase7("00000081");

		/* 전문구분코드(MSG TYPE) */
		super.setBase11("0200");

		/* 거래구분코드 */
		super.setBase12("1100");

		/* 항목구분코드 */
		super.setBase13("0000");

		/* 거래일련번호 */
		super.setBase17("0000000");

		/* 이체거래시 입출기관구분 */
		super.setBase28("0");

	}

	/* 거래금액  */
	@ByteLimit(limit = 13, example = "0", repeat = true)
	private String delngAmount;

	/* 양,음 구분표시 */
	@ByteLimit(limit = 1, example = " " )
	private String ngnoSeIndict;

	/* 거래후 계좌잔액 */
	@ByteLimit(limit = 13, example = "0", repeat = true)
	private String delngAfterAcnutBlce;

	/* 미결제 타점권 금액 */
	@ByteLimit(limit = 13, example = "0", repeat = true)
	private String unsetlOthrComAmount;

	/* 입금 계좌 은행 코드 */
	@ByteLimit(limit = 8, example = " " , repeat = true)
	private String rcpmnyAcnutBankCode;

	/* 입금계좌구분코드 */
	@ByteLimit(limit = 2, example = "00")
	private String rcpmnyAcnutSeCode;

	/* 계좌번호(가상) */
	@ByteLimit(limit = 16, example = " " , repeat = true)
	private String ewalletAcnutNo;

	/* 입금계좌성명 */
	@ByteLimit(limit = 20, example = " " , repeat = true)
	private String rcpmnyAcnutNm;

	/* 출금 계좌 은행 코드 */
	@ByteLimit(limit = 8, example = "00000081")
	private String defrayAcnutBankCode;

	/* 출금계좌구분코드 */
	@ByteLimit(limit = 2, example = "00")
	private String defrayAcnutSeCode;

	/* 계좌번호(가상) */
	@ByteLimit(limit = 16, example = "34123412341234", require = true)
	private String account11;

	/* (출금계좌)비밀번호 */
	@ByteLimit(limit = 8, example = " " , repeat = true)
	private String defrayAcnutSecretNo;

	/* 출금계좌성명 */
	@ByteLimit(limit = 20, example = " " , repeat = true)
	private String defrayAcnutNm;

	/* 수수료금액 */
	@ByteLimit(limit = 5, example = "0", repeat = true)
	private String indvdlzFeeAmount;

	/* 현금매수 */
	@ByteLimit(limit = 3, example = "0")
	private String indvdlzCashPrchas;

	/* 수표매수 */
	@ByteLimit(limit = 2, example = " " , repeat = true)
	private String indvdlzCheckPrchas;

	/* 수표번호 */
	@ByteLimit(limit = 8, example = "0", repeat = true)
	private String indvdlzCheckNo;

	/* 수표발행정보 */
	@ByteLimit(limit = 6, example = " " , repeat = true)
	private String indvdlzCheckIsuInfo;

	/* 수표권종 */
	@ByteLimit(limit = 2, example = "0", repeat = true)
	private String indvdlzCheckBndunt;

	/* 취소 사유 */
	@ByteLimit(limit = 3, example = " ", repeat = true)
	private String indvdlzCanclResn;

	/* 거래관리번호 */
	@ByteLimit(limit = 12, example = " " , repeat = true)
	private String indvdlzDelngManageNo;

	/* 배분수수료금액 */
	@ByteLimit(limit = 5, example = "0", repeat = true)
	private String indvdlzDstbFeeAmount;

	/* DUMMY */
	private String account23;

   /**
    * 인터페이스 순번
   */
   private long intrfcSn;
    /**
    * CS 번호
   */
   private String csNo;
    /**
    * CS 관리 기관 코드
   */
   private String csManageInsttCode;
    /**
    * 재활동 코드
   */
   private String reactCode;
    /**
    * 연속 거래 번호
   */
   private String ctnuDelngNo;
    /**
    * 송수신 플래그
   */
   private String trsmrcvAt;
    /**
    * 취급 영업점 코드
   */
   private String trtmntBsnpointCode;
    /**
    * 취급 단말 코드
   */
   private String trtmntTrmnlCode;
    /**
    * 매체 발생 구분
   */
   private String mediaOccrrncSe;
    /**
    * 응답 코드
   */
   private String rspnsCode;
    /**
    * 거래 일자
   */
   private String delngDe;
    /**
    * 거래 시간
   */
   private String delngTime;

    /**
    * 한글 코드 구분
   */
   private String koreanCodeSe;
    /**
    * 마감후 구분
   */
   private String aftcsSe;
    /**
    * 차액 입금 방법
   */
   private String dfnntRcpmnyMth;
    /**
    * 개설 기관 코드
   */
   private String estblInsttCode;
    /**
    * 트랙 번호
   */
   private String trackNo;
    /**
    * 트랙 데이터
   */
   private String trackData;
    /**
    * 카드 구분
   */
   private String cardSe;
    /**
    * 카드 일련 번호
   */
   private String cardSeqNo;
    /**
    * 자동화 거래 가능 횟수
   */
   private String atmDelngPossCo;
    /**
    * 조회 출력 구분
   */
   private String inqireOutptSe;
    /**
    * 입출 기관 구분
   */
   private String ippInsttSe;
    /**
    * 사용자 근무 지역
   */
   private String userWorkArea;
    /**
    * 응답 메시지
   */
   private String rspnsMssage;

    /**
    * 최초 등록자 아이디
   */
   private String frstRegisterId;
    /**
    * 최초 등록 일시
   */
   private String frstRegistDt;
    /**
    * 최종 변경자 아이디
   */
   private String lastChangerId;
    /**
    * 최종 변경 일시
   */
   private String lastChangeDt;
   /**
    * 입금 계좌 번호
    */
   private String rcpmnyAcnutNo;
   /**
    * 출금 계좌 번호
    */
   private String defrayAcnutNo;
   /**
   * 응답 상태
   * :초기 0 / 응답 1/ 원장테이블 업데이트 2
  */
  private int rspnsSttus;
}
