/**
 * 
 */
package com.sorincorp.api.ewallet.model;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import lombok.Data;

/**
 * EwalletMbRefndRequstHstVO.java
 * @version
 * @since 2021. 11. 4.
 * @author srec0049
 */
@Data
public class EwalletMbRefndRequstHstVO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5208711612812196286L;
	
	/******  JAVA VO CREATE : MB_REFND_REQUST_HST(회원_환불 요청 이력)                                                                   ******/
	/**
     * 업체 번호
    */
	@NotEmpty(message = "업체 번호는 필수값입니다.")
    private String entrpsNo;
    /**
     * 환불 요청 일시
    */
	@NotEmpty(message = "환불 요청 일시는 필수값입니다.")
    private String refndRequstDt;
    /**
     * 환불 요청 주체 코드
    */
	@NotEmpty(message = "환불 요청 주체 코드는 필수값입니다.")
    private String refndRequstMbyCode;
    /**
     * 환불 요청 금액
    */
    private long refndRequstAmount;
    /**
     * 환불 요청 상태 코드
    */
    private String refndRequstSttusCode;
    /**
     * 환불 요청 처리 일시
    */
    private String refndRequstProcessDt;
    /**
     * 환불 요청 시 잔액
    */
    private long refndRequstHourBlce;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
    /**
     * 요청 일자 key
    */
    private String requstDtKey;
}
