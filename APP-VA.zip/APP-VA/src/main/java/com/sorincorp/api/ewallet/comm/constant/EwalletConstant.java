package com.sorincorp.api.ewallet.comm.constant;

public class EwalletConstant {

	public static final int SUCCESS_RESULT_CODE = 200;

	public static final String SUCCESS_RESULT_MSG = "Success";

	public static final int ERROR_RESULT_CODE = 500;

	public static final String ERROR_RESULT_MSG = "Error";

	/** 하나은행 인코딩 디폴트 **/
	public static final String EWALLET_DEFAULT_ENCODING = "EUC_KR";

	/** 하나은행 인코딩 방식 1**/
	public static final String EWALLET_ENCODING_EUC_KR = "EUC_KR";
	/** 하나은행 인코딩 방식 2**/
	public static final String EWALLET_ENCODING_UTF_8 = "UTF-8";

	/** 하나은행 기관코드 **/
	public static final String EWALLET_HANABANK_CODE = "00000081";
	/** 서린상사 기관코드 **/
	public static final String EWALLET_SORIN_CODE = "20095025";

	/** 공통 전문 **/
	public static final String EWALLET_BASE_USERWORKAREA_SPLIT = ";";

	/** 공통 전문 길이 **/
	public static final int EWALLET_TCP_COMMON_LENGTH = 300;

	/** POLLING 구분 코드 **/
	public static final String EWALLET_TCP_POLLING = "HDR";
	/** POLLING REQUEST 구분 코드 **/
	public static final String EWALLET_TCP_POLLING_REQ = "REQPOLL";
	/** POLLING RESPONSE 구분 코드 **/
	public static final String EWALLET_TCP_POLLING_RES = "RESPOLL";
	/** 전문 POLLING INDEX 번호 **/
	public static final int EWALLET_TCP_POLLING_INDEX = 4;
	/** 전문 POLLING 구분 길이 **/
	public static final int EWALLET_TCP_POLLING_LENGTH = 3;

	/** 공통 전문 구분 코드 INDEX 번호 **/
	public static final int EWALLET_TCP_COMMON_MSG_TYPE_INDEX = 39;
	/** 공통 전문 구분 코드 길이 **/
	public static final int EWALLET_TCP_COMMON_MSG_TYPE_LENGTH = 4;

	/** 공통 거래 구분 코드 INDEX 번호 **/
	public static final int EWALLET_TCP_COMMON_API_TYPE_INDEX = 43;
	/** 공통 거래 구분 코드 길이 **/
	public static final int EWALLET_TCP_COMMON_API_TYPE_LENGTH = 4;

	/** 가상계좌 잔액조회 전문 잔액 INDEX **/
	public static final int EWALLET_TCP_ACCOUNT_MONEY_INDEX = 300;
	/** 가상계좌 잔액조회 전문 잔액길이 **/
	public static final int EWALLET_TCP_ACCOUNT_MONEY_LENGTH = 13;

	/** 이체수취조회/이체업무 전문 길이 **/
	public static final int EWALLET_TCP_TRANSFER_LENGTH = 500;
	/** 가상계좌 잔액조회 전문 길이 **/
	public static final int EWALLET_TCP_ACCOUNT_LENGTH = 500;
	/** 이체처리결과조회 전문 길이 **/
	public static final int EWALLET_TCP_RESULT_LENGTH = 500;
	/** 관리 전문 길이 **/
	public static final int EWALLET_TCP_MANAGE_LENGTH = 500;

	/** 환불계좌 등록 전문 INDEX **/
	public static final int EWALLET_TCP_REFUND_ACCOUNT_INDEX = 300;
	/** 환불계좌 등록 전문 길이 **/
	public static final int EWALLET_TCP_REFUND_ACCOUNT_LENGTH = 400;
	/**
	 * 가상계좌 사용등록 승인 통보
	 */

	/** 계좌 입금 전문 길이 **/
	public static final int EWALLET_TCP_ACCOUNT_RCPMNY_LENGTH = 550;

	/** 가상계좌 사용등록 승인 전문 길이*/
	public static final int EWALLET_ACUNT_CONFM_LENGTH = 350;



}
