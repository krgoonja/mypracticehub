package com.sorincorp.api.ewallet.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class EwalletResultVO{
	
	/** 기준 일자 **/
	@NotEmpty(message = "기준일자 정보 없음")
	@Size(min=8 ,max=8, message = "기준일자 형식 상이")
	private String stdrDe;
	
	/** 원 요구 전문 번호 **/
	@NotEmpty(message = "원 요구 전문번호 정보 없음")
	@Size(min=15 ,max=15, message = "원 요구 전문번호 형식 상이")
	private String wonDemandSpcltyNo;

	/** 거래 일련 번호 **/
	private String delngSeqNo;
	
	/** 정상 응답 코드 **/
	private String nrmltRspnsCode;

}
