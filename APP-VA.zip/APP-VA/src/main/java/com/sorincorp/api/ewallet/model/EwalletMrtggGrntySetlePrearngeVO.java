package com.sorincorp.api.ewallet.model;

import lombok.Data;

/**
 * EwalletMrtggGrntySetlePrearngeVO.java
 * 담보 보증 결제 예정 정보 VO 객체
 * @version
 * @since 2022. 8. 19.
 * @author srec0049
 */
@Data
public class EwalletMrtggGrntySetlePrearngeVO {
	/**
	 * 주문 번호
	 */
	private String orderNo;
	
    /**
     * 주문 일자
     */
    private String orderDe;
    
    /**
     * 주문 시각
     */
    private String orderTm;
    
	/**
	 * 결제 방식 코드
	 */
	private String setleMthdCode;
	
	/**
	 * 업체 번호
	 */
	private String entrpsNo;
	
	/**
	 * 미 결제 금액
	 */
	private long unSetleAmount;
	
	/**
	 * 담보 번호
	 */
	private String mrtggNo;
	
	/**
	 * 담보 상태 코드
	 */
	private String mrtggSttusCode;
	
	/**
	 * 결제 예정 일자
	 */
	private String setlePrearngeDe;
	
	/**
	 * 배송 완료 일자
	 */
	private String dlvyComptDe;
	
	/**
	 * 부분 출고 상환 여부
	 */
	private String partDlivyRepyAt;
	
	/**
	 * 중도 상환 순번
	 */
	private Long mdstrmRepySn;
}
