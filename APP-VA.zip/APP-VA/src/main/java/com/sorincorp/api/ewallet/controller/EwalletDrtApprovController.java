package com.sorincorp.api.ewallet.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.ewallet.comm.constant.EwalletConstant;
import com.sorincorp.api.ewallet.comm.response.EwalletCommResponse;
import com.sorincorp.api.ewallet.model.EwalletAccountVO;
import com.sorincorp.api.ewallet.model.EwalletTransferVO;
import com.sorincorp.api.ewallet.service.EwalletService;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@Api("Ewallet 전문 통신")
@RequestMapping("/api")
public class EwalletDrtApprovController {

	@Autowired
	private EwalletService ewalletService;

	@PostMapping("/ewallet/drtApprov")
	public ResponseEntity<?> ewalletDrtApprov(@RequestBody @Valid EwalletTransferVO ewalletTransferVO, BindingResult bindingResult) throws Exception{
		if(bindingResult.hasErrors()) {
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(new EwalletCommResponse(EwalletConstant.ERROR_RESULT_CODE, bindingResult.getFieldError().getDefaultMessage()));
		}

		log.debug("ewalletTransferVO ::" +ewalletTransferVO );
		// 1.잔액조회 - 성공 - 요청금액과 비교ok - 출금요청 - 성공 - return
		// 2.잔액조회 - 성공 - 요청금액 비교fail - return

		EwalletAccountVO ewalletAccountVO = new EwalletAccountVO();
		// test 용
		//ewalletAccountVO.setEntrpsNo("C0050");

		ewalletAccountVO.setEntrpsNo(ewalletTransferVO.getEntrpsNo());

		// 잔액 조회
		//EwalletAccountVO accountVo = ewalletService.ewalletAccountMoney(ewalletAccountVO);

		//log.debug("accountVo ::" +accountVo );
		//log.debug("이월렛잔액 ::" + accountVo.getDelngAmount());
		//log.debug("출금요청금액 ::" +ewalletTransferVO.getDelngAmount() );

		//if(Long.parseLong(accountVo.getDelngAmount()) > ewalletTransferVO.getDelngAmount()) {
		// 출금요청
		try {
			ewalletService.ewalletDoTransfer(ewalletTransferVO);
			return ResponseEntity.status(HttpStatus.OK).body(new EwalletCommResponse(EwalletConstant.SUCCESS_RESULT_CODE, EwalletConstant.SUCCESS_RESULT_MSG, ewalletTransferVO));

		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.OK).body(new EwalletCommResponse(EwalletConstant.ERROR_RESULT_CODE, EwalletConstant.ERROR_RESULT_MSG, ewalletTransferVO));
		}

	}



}
