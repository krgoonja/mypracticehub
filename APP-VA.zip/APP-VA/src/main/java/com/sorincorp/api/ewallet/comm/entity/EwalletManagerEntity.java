package com.sorincorp.api.ewallet.comm.entity;

import org.apache.commons.codec.binary.StringUtils;

import com.sorincorp.api.ewallet.comm.annotaion.ByteLimit;
import com.sorincorp.api.ewallet.model.EwalletManageVO;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class EwalletManagerEntity extends EwalletBaseEntity {
	
	public EwalletManagerEntity(EwalletManageVO ewalletManageVO) {
		/* LENGTH */
		super.setBase1("0500");
		
		/* 전문구분코드(MSG TYPE) */
		super.setBase11("0800");
		
		/* 항목구분코드 */
		super.setBase13("0000");
		
		/* 거래일련번호 */
		super.setBase17(ewalletManageVO.getDelngSeqNo());
		
		/* 이체거래시 입출기관구분 */
		super.setBase28("0");
		
		if(StringUtils.equals(ewalletManageVO.getManageType(), "2100")) {
			/* 개시 */
			super.setBase12("2100");
		}else if(StringUtils.equals(ewalletManageVO.getManageType(), "2400")) {
			/* 종료 */
			super.setBase12("2400");
		}else if(StringUtils.equals(ewalletManageVO.getManageType(), "2500")) {
			/* 장애 */
			super.setBase12("2500");
			this.manage5 = "3";
		}else if(StringUtils.equals(ewalletManageVO.getManageType(), "2600")) {
			/* 장애해제 */
			super.setBase12("2600");
			this.manage5 = "1";
		}
	}
	
	/* 기준일자 */
	@ByteLimit(limit = 8, example = "20210629", day = true)
	private String manage1;
	
	/* 마감전후구분 */
	@ByteLimit(limit = 1, example = "0")
	private String manage2;
	
	/* 휴일구분 */
	@ByteLimit(limit = 1, example = "0")
	private String manage3;
	
	/* 업무종류 */
	@ByteLimit(limit = 1, example = "0")
	private String manage4;
	
	/* 장애구분 */
	@ByteLimit(limit = 1, example = "1")
	private String manage5;
	
	/* HOST 시스템 개시상태(AMS) */
	@ByteLimit(limit = 1, example = "1")
	private String manage6;
	
	/* HOST 시스템 개시상태(타행환) */
	@ByteLimit(limit = 1, example = "1")
	private String manage7;
	
	/* HOST 시스템 개시상태(CD공동망) */
	@ByteLimit(limit = 1, example = "1")
	private String manage8;
	
	/* HOST 시스템 개시상태(자행 BC) */
	@ByteLimit(limit = 1, example = "1")
	private String manage9;
	
	/* HOST 시스템 개시상태(타행 BC) */
	@ByteLimit(limit = 1, example = "1")
	private String manage10;
	
	/* 예비정보 */
	@ByteLimit(limit = 3, example = " ", repeat = true)
	private String manage11;
	
	/* HOST SYSTEM NAME */
	@ByteLimit(limit = 2, example = " ", repeat = true)
	private String manage12;

	/* 장애은행상태 */
	@ByteLimit(limit = 100, example = "0", repeat = true)
	private String manage13;
	
	/* AMS SAF 건수 */
	@ByteLimit(limit = 5, example = "0", repeat = true)
	private String manage14;
	
	/* HOST 및 기관 SAF 건수 */
	@ByteLimit(limit = 5, example = "0", repeat = true)
	private String manage15;
	
	/* 전영업일자 */
	@ByteLimit(limit = 8, example = " ", repeat = true)
	private String manage16;
	
	/* 익영업일자 */
	@ByteLimit(limit = 8, example = " ", repeat = true)
	private String manage17;
	
	/* FILLER */
	@ByteLimit(limit = 52, example = " ", repeat = true)
	private String manage18;

}
