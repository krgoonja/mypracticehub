package com.sorincorp.api.ewallet.comm.entity;

import com.sorincorp.api.ewallet.comm.annotaion.ByteLimit;
import com.sorincorp.api.ewallet.comm.constant.EwalletConstant;
import com.sorincorp.comm.util.DateUtil;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class EwalletRefundAccountEntity extends EwalletBaseEntity {

	public EwalletRefundAccountEntity(String refundAcnutNo, String virtualAcnutNo, String bsnmRegistNo, String entrpsNo, String serialNo, String delngSe) {
		/* LENGTH */
		super.setBase1("0400");

		/* 취급기관코드 */
		//super.setBase7("00000081");
		super.setBase7(EwalletConstant.EWALLET_SORIN_CODE);

		/* 전문구분코드(MSG TYPE) */
		super.setBase11("0200");

		/* 거래구분코드 7350 환불계좌등록*/
		super.setBase12("7350");

		/* 항목구분코드 */
		super.setBase13("0000");

		/* 거래일자 */
		super.setBase15(DateUtil.getNowDate());

		/* 거래시간 */
		super.setBase16(DateUtil.getNowDateTime("HHmmss"));

		/* 거래일련번호 */
		super.setBase17(serialNo);

		/* 이체거래시 입출기관구분 */
		super.setBase28("0");

		for(int i=0;i<9;i++) {
			entrpsNo += " ";
		}
		/* USER WORK AREA 업체번호*/
		super.setBase29(entrpsNo);

		this.account1 = virtualAcnutNo;
		this.account2 = bsnmRegistNo;
		this.account3 = refundAcnutNo;
		this.account4 = delngSe;
	}


	/* 계좌번호(환불) */
	@ByteLimit(limit = 16, example = "1234123412341234", require = true)
	private String account1;

	/* 사업자번호 */
	@ByteLimit(limit = 10, example = "1234567890", require = true)
	private String account2;

	/* 계좌번호(가상) */
	@ByteLimit(limit = 16, example = "1234123412341234", require = true)
	private String account3;

	/* 개래구분코드 0:등록,1:변경*/
	@ByteLimit(limit = 1, example = "0", require = true)
	private String account4;

	/*응답 환불 계좌 번호*/
	@ByteLimit(limit = 16, example = " ", repeat = true)
	private String account5;

	/*부기 계좌 번호*/
	@ByteLimit(limit = 16, example = " ", repeat = true)
	private String account6;

	/* FILLER */
	@ByteLimit(limit = 25, example = " ", repeat = true)
	private String account7;

	private int intrfcSn;
}
