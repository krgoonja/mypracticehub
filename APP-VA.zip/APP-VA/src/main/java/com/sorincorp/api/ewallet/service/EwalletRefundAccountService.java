package com.sorincorp.api.ewallet.service;

import com.sorincorp.api.ewallet.model.EwalletRefundAccountVO;

public interface EwalletRefundAccountService {

	void ewalletRefundAccountConnet(EwalletRefundAccountVO ewalletRefundAccountVO) throws Exception;

	void reciveResponseData(byte[] receiveByte) throws Exception;


}
