/**
 *
 */
package com.sorincorp.api.ewallet.model;

import javax.validation.constraints.NotEmpty;

import lombok.Data;

/**
 * AccountRcpmnyVO.java
 * @version
 * @since 2021. 8. 26.
 * @author srec0009
 */
@Data
public class EwalletAcnutDelngVO {

    /******  JAVA VO CREATE : MB_ENTRPS_EWALLET_DTL(회원_업체 이월렛 상세)                                                                   ******/
    /**
     * 업체 번호
    */
	@NotEmpty(message = "업체 번호는 필수값입니다.")
    private String entrpsNo;
    /**
     * 이월렛 거래 일시
    */
	@NotEmpty(message = "이월렛 거래 일시는 필수값입니다.")
    private String ewalletDelngDt;
	/**
     * 이월렛 계좌번호
    */
    private String ewalletSumry;
    /**
     * 이월렛 계좌번호
    */
    private String ewalletAcnutNo;
    /**
     * 고객 환불 계좌번호
    */
    private String refndAcnutNo;
    /**
     * 이월렛 거래 금액
    */
    private long ewalletDelngAmount;
    /**
     * 이월렛 잔액
    */
    private long ewalletBlce;
    /**
     * 삭제 여부
    */
	@NotEmpty(message = "삭제 여부는 필수값입니다.")
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 최초 등록자 아이디
    */
	@NotEmpty(message = "최초 등록자 아이디는 필수값입니다.")
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
	@NotEmpty(message = "최초 등록 일시는 필수값입니다.")
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
	@NotEmpty(message = "최종 변경자 아이디는 필수값입니다.")
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
	@NotEmpty(message = "최종 변경 일시는 필수값입니다.")
    private String lastChangeDt;
    /**
     * 이월렛 거래 구분 코드
    */
	@NotEmpty(message = "이월렛 거래 구분 코드는 필수값입니다.")
    private String ewalletDelngSeCode;
    /**
     * 거래 일련 번호
    */
	@NotEmpty(message = "거래 일련 번호는 필수값입니다.")
    private String delngSeqNo;
    /**
     * 이월렛 정산 유형 코드
    */
    private String ewalletExcclcTyCode;
    /**
     * 주문 번호
    */
    private String orderNo;
    /**
     * 취소 교환 반품 번호
    */
    private String canclExchngRtngudNo;
    /**
     * 결제 번호
    */
    private String setleNo;
    /**
     * 취급 기관 코드
     */
    @NotEmpty(message = "취급 기관 코드는 필수값입니다.")
    private String trtmntInsttCode;
    
    /**
     * 선수금 여부
     */
    private String precdntAt;
    
    /**
     * 항목 구분 코드
     */
    private String iemSeCode;
    
    /**
     * 부분상환 여부: [Y : 부분입금 N : 전체입금]
     */
    private String partRepyAt;

}
