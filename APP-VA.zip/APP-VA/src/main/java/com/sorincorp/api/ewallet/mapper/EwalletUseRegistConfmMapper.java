/**
 *
 */
package com.sorincorp.api.ewallet.mapper;

import com.sorincorp.api.ewallet.comm.entity.AccountConfmEntity;
import com.sorincorp.api.ewallet.model.EwalletUseRegistConfmVO;

/**
 * EwalletUseRegistConfmMapper.java
 * @version
 * @since 2021. 8. 26.
 * @author srec0009
 */
public interface EwalletUseRegistConfmMapper {

	/**
	 * <pre>
	 * 처리내용: 가상계좌 사용등록 승인 통보 된 회원 이월렛 계좌 번호 업데이트
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 26.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	int updateEwalletAccountNo(EwalletUseRegistConfmVO vo);

	/**
	 * <pre>
	 * 처리내용: 이월렛 계좌 정합성 여부 업데이트
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 26.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	int updateEwalletAccountRgrsynthAt(EwalletUseRegistConfmVO vo);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 5.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 5.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param virtlAcnutNo
	 * @return
	 */
	String selectEntrpsNo(String virtlAcnutNo);
	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 5.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 5.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param vo
	 */
	void insertEwalletAccountNoHst(EwalletUseRegistConfmVO vo);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param accountConfmEntity
	 */
	void insertIfEwalletAcnutConfmRequst(AccountConfmEntity accountConfmEntity);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param accountConfmEntity
	 */
	void updateEwalletAcnutConfmRequst(AccountConfmEntity accountConfmEntity);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 6.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 6.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param accountConfmEntity
	 */
	void insertIfEwalletAcnutConfmRspns(AccountConfmEntity accountConfmEntity);

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	String selectEntrpsAcuntNo(EwalletUseRegistConfmVO vo);

	int updateOpEwalletAcnutDtl(EwalletUseRegistConfmVO vo);

}
