package com.sorincorp.api.ewallet.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.ewallet.comm.constant.EwalletConstant;
import com.sorincorp.api.ewallet.comm.response.EwalletCommResponse;
import com.sorincorp.api.ewallet.model.EwalletRefundAccountVO;
import com.sorincorp.api.ewallet.service.EwalletRefundAccountService;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@Api("Ewallet 환불계좌등록 전문 통신")
@RequestMapping("/api")
public class EwalletRefundAccountController {

	@Autowired
	private EwalletRefundAccountService ewalletRefundService;

	@PostMapping("/ewallet/refund")
	//public ResponseEntity<?> ewalletRefundConnet(@RequestBody EwalletRefundAccountVO ewalletRefundAccountVO, BindingResult bindingResult) throws Exception{
	public ResponseEntity<?> ewalletRefundConnet(@RequestBody LinkedMultiValueMap<String, String> parameters, BindingResult bindingResult) throws Exception{

		EwalletRefundAccountVO ewalletRefundAccountVO = new EwalletRefundAccountVO();
		Map<String,String> map = parameters.toSingleValueMap();
		ewalletRefundAccountVO.setEntrpsNo(map.get("entrpsNo"));
		ewalletRefundAccountVO.setRefundAcnutNo(map.get("refundAcnutNo"));
		ewalletRefundAccountVO.setEwalletAcnutNo(map.get("ewalletAcnutNo"));
		ewalletRefundAccountVO.setBsnmRegistNo(map.get("bsnmRegistNo"));
		ewalletRefundAccountVO.setDelngSe(map.get("delngSe"));


		log.debug("entrpsNo 			: " + ewalletRefundAccountVO.getEntrpsNo());
		log.debug("refundAcnutNo 	: " + ewalletRefundAccountVO.getRefundAcnutNo());
		log.debug("ewalletAcnutNo 	: " + ewalletRefundAccountVO.getEwalletAcnutNo());
		log.debug("bsnmRegistNo 		: " + ewalletRefundAccountVO.getBsnmRegistNo());
		log.debug("delngSe			: " + ewalletRefundAccountVO.getDelngSe());

		if(bindingResult.hasErrors()) {
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(new EwalletCommResponse(EwalletConstant.ERROR_RESULT_CODE, bindingResult.getFieldError().getDefaultMessage()));
		}

		ewalletRefundService.ewalletRefundAccountConnet(ewalletRefundAccountVO);

		return ResponseEntity.status(HttpStatus.OK).body(new EwalletCommResponse(EwalletConstant.SUCCESS_RESULT_CODE, EwalletConstant.SUCCESS_RESULT_MSG, ewalletRefundAccountVO));
	}

}
