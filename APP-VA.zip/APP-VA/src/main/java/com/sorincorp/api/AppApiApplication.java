package com.sorincorp.api;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.sorincorp.api.ewallet.server.socket.EwalletServerSocket;

@SpringBootApplication
@EnableScheduling
public class AppApiApplication extends SpringApplicationBuilder{
	
	@Autowired
	private EwalletServerSocket ewalletServerSocket;

	@Resource(name = "ewalletServerThreadPool")
	private ThreadPoolTaskExecutor taskExecutor;

	public static void main(String[] args) {
		SpringApplication.run(AppApiApplication.class, args);
	}

	@EventListener(ApplicationReadyEvent.class)
	public void init() {
		Runnable rn = () -> { ewalletServerSocket.start(); };
		taskExecutor.execute(rn);
	}
}
