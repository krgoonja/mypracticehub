package com.sorincorp.api.ewallet.comm.handler;

public interface ServiceCall {
	
	//public ByteBuf serviceCallByServer(byte[] byteBuf) throws Exception;

	public void serviceCallByClient(byte[] byteBuf) throws Exception;

	public boolean pollingChk(byte[] byteBuf) throws Exception;
}
