package com.sorincorp.api.ewallet.model;

import javax.validation.constraints.NotEmpty;

import lombok.Data;

@Data
public class EwalletManageVO {
	
	@NotEmpty(message = "관리전문 거래구분 코드 없음")
	private String manageType;

	/** 거래 일련 번호 **/
	private String delngSeqNo;
}
