package com.sorincorp.api.ewallet.server.handler;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sorincorp.api.ewallet.comm.constant.EwalletConstant;
import com.sorincorp.api.ewallet.comm.handler.ServiceCall;
import com.sorincorp.api.ewallet.service.EwalletService;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Sharable
@RequiredArgsConstructor
public class EwalletHandler extends ChannelInboundHandlerAdapter  {
	
	@Value("${ewallet.client.host.inbound}")
	private String inboundHost;
	
	@Autowired
	private ServiceCall serviceCall;
	
	@Autowired
    private EwalletService ewalletService;
	 
    private ByteBuf buff;
    
    private byte[] receiveByte;

    // 핸들러가 생성될 때 호출되는 메소드 ( ByteBuf 의 크기를 정함 )
    @Override
    public void handlerAdded(ChannelHandlerContext ctx) {
    	log.debug("handlerAdded : start");
    	buff = ctx.alloc().buffer();
    	log.debug("handlerAdded buff : " + buff);
    }

    // 클라이언트와 연결되어 트래픽을 생성할 준비가 되었을 때 호출되는 메소드
    @Override
    public void channelActive(ChannelHandlerContext ctx) {
        String remoteAddress = ctx.channel().remoteAddress().toString();
        log.debug("Remote Address: " + remoteAddress + ", inboundHost : " + inboundHost);
        if(remoteAddress.indexOf(inboundHost) > -1) {
        	log.debug("존재!");
        } else {
        	log.debug("부재!");
        	//ctx.disconnect();
        }
    }

    //클라이언트가 보내는 전문을 읽는 메소드 ( 위의 정해진 길이 만큼 오지 않으면 실행 안함 )
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg){
    	// 읽어들이는 모든 msg를 buff에 저장, 다 읽으면 바로 밑의 channelReadComplete 메소드 호출됨
    	buff.writeBytes((ByteBuf) msg);
    }
     
    // 클라이언트가 보내는 전문을 다읽은 후 호출되는 메소드
    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {
    	String remoteAddress = ctx.channel().remoteAddress().toString();
    	log.debug("channelReadComplete() remoteAddress : " + remoteAddress);
    	log.debug("Remote Address: " + remoteAddress + ", inboundHost : " + inboundHost);
    	log.debug("channelReadComplete() : start");
    	
    	if(remoteAddress.indexOf(inboundHost) > -1) {
        	log.debug("channelReadComplete() 존재!");
        	
        	// 읽을 수 있는 데이터가 없어질 때까지 반복
        	while(buff.isReadable()) {
        		// 전문 길이 get하고, 증가한 readerIndex를 0으로 초기화
        		int dataLength = Integer.parseInt((buff).readBytes(4).toString(StandardCharsets.UTF_8));
        		buff.readerIndex(0);
        		log.debug("dataLength : " + dataLength);
        		
        		// 전문 길이만큼 byte형 배열로 초기화
        		receiveByte = new byte[dataLength];
        		
        		buff.readBytes(receiveByte);	// receiveByte에 데이터 저장하고 readerIndex를 저장한 데이터의 byte 수 만큼 증가시킴
        		log.debug("channelRead :: getBytes : " + new String(receiveByte, EwalletConstant.EWALLET_DEFAULT_ENCODING));
        		
        		buff.discardReadBytes();	// *** readerIndex까지의 데이터를 버리고, readerIndex에서 writerIndex 사이의 데이터를 0번 index까지 옮김
        									//	ㄴ 읽은 데이터를 삭제하고, 다음 데이터가 있으면 버퍼 앞으로 당겨오는 행위
        		log.debug("readerIndex : " + (buff).readerIndex());
        		log.debug("writerIndexIndex : " + (buff).writerIndex());
        		
        		if( receiveByte == null ) {
        			log.debug("channelReadComplete() receiveByte null");
        		} else {
        			log.debug("channelReadComplete() receiveByte 존재");
        			
        			log.debug("TCP Server Receive : " + new String(receiveByte, EwalletConstant.EWALLET_DEFAULT_ENCODING));
        			
        			log.debug("길이 : " + new String(receiveByte, EwalletConstant.EWALLET_DEFAULT_ENCODING).length());
        			
        			boolean isPolling = serviceCall.pollingChk(receiveByte);
        			
        			if(isPolling) {
        				/** 하나은행과 연결 유지형을 유지하기위해 주기적으로 호출을 받는 영역 **/
        				log.debug("Polling Receive : " + new String(receiveByte, EwalletConstant.EWALLET_DEFAULT_ENCODING));
        				byte[] pollingRes = ewalletService.ewalletPollingChk(receiveByte);
        				ByteBuf pollingByte = Unpooled.buffer();
        				pollingByte.writeBytes(pollingRes);
        				ctx.writeAndFlush(pollingByte);
        				
        				receiveByte = null;
        				
        				/** 연결 유지형 이기 때문에 리스너에 close를 호출하지 않는다. **/
        				//ctx.writeAndFlush(pollingByte).addListener(ChannelFutureListener.CLOSE);
        				log.debug("Polling Send : " + new String(pollingRes, EwalletConstant.EWALLET_DEFAULT_ENCODING));
        			}else {
        				try {
        					serviceCall.serviceCallByClient(receiveByte);
        				}catch(Exception e) {
        					log.error("serviceCallByClient() Error : "  + e);
        				}
        				
        				ctx.writeAndFlush(Unpooled.EMPTY_BUFFER);
        				
        				receiveByte = null;
        				
        				/** 연결 유지형 이기 때문에 리스너에 close를 호출하지 않는다. **/
        				//ctx.writeAndFlush(Unpooled.EMPTY_BUFFER).addListener(ChannelFutureListener.CLOSE);
        			}
        		}
        	}
        } else {
        	log.debug("channelReadComplete() 부재!");
        	ctx.writeAndFlush(Unpooled.EMPTY_BUFFER);
        }
    }
     
    // 핸들러가 제거될 때 호출되는 메소드 ( ByteBuf 자원을 해제 )
    @Override
    public void handlerRemoved(ChannelHandlerContext ctx) {
    	log.debug("handlerRemoved() : start");
    	buff.release();
        buff = null;
    }

    // 예외 발생시 호출
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
    	log.debug("exceptionCaught() : start");
    	try {
			log.error("exceptionCaught() Error Receive : " + new String(receiveByte, EwalletConstant.EWALLET_DEFAULT_ENCODING));
		} catch (UnsupportedEncodingException e) {
			log.error("exceptionCaught() Error : " + e );
		}
    	log.error("exceptionCaught() Error : " + cause );
    }
}
