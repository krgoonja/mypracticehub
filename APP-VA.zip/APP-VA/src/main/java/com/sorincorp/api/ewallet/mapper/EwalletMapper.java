package com.sorincorp.api.ewallet.mapper;

import java.util.List;

import com.sorincorp.api.ewallet.comm.entity.EwalletAccountEntity;
import com.sorincorp.api.ewallet.comm.entity.EwalletManagerEntity;
import com.sorincorp.api.ewallet.comm.entity.EwalletResultEntity;
import com.sorincorp.api.ewallet.comm.entity.EwalletTransferEntity;
import com.sorincorp.api.ewallet.model.EntrpsInfoBasVO;
import com.sorincorp.api.ewallet.model.EwalletAccountVO;
import com.sorincorp.api.ewallet.model.EwalletAcnutDelngVO;
import com.sorincorp.api.ewallet.model.EwalletCoEwalletManageSttusBasVO;
import com.sorincorp.api.ewallet.model.EwalletEntrpsVO;
import com.sorincorp.api.ewallet.model.EwalletMbRefndRequstHstVO;
import com.sorincorp.api.ewallet.model.EwalletMrtggGrntySetlePrearngeVO;
import com.sorincorp.api.ewallet.model.EwalletResultVO;

public interface EwalletMapper {

	void insertAccoutMoneyRequest(EwalletAccountEntity accountModel) throws Exception;
	
	void insertAccoutMoneyResponse(EwalletAccountEntity accountEntity) throws Exception;

	void insertDoTransferRequest(EwalletTransferEntity transferModel) throws Exception;

	EwalletEntrpsVO selectEntrpsInfo(EwalletEntrpsVO entrpsNo) throws Exception;

	void insertDoTransferResponse(EwalletTransferEntity transferEntity) throws Exception;

	EwalletResultVO selectTransferResult(EwalletResultVO ewalletResultVO) throws Exception;

	void insertChkTransferRequest(EwalletResultEntity resultModel) throws Exception;

	void insertChkTransferResponse(EwalletResultEntity resultEntity) throws Exception;

	EwalletAccountVO selectAccountMoney(EwalletAccountVO ewalletAccountVO) throws Exception;

	void insertManageBankResponse(EwalletManagerEntity endEntity) throws Exception;

	void updateEwalletSetle(EwalletTransferEntity ewalletTransferEntity) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원_업체 이월렛 상세 등록하기
	 * </pre>
	 * @date 2022. 9. 23.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 23.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param delngVo
	 * @throws Exception
	 */
	void insertMbEntrpsEwalletDtl(EwalletAcnutDelngVO delngVo) throws Exception;

	void insertManageBankRequest(EwalletManagerEntity startEntity) throws Exception;

	String selectEntrpsOfAcnut(EwalletAcnutDelngVO delngVo) throws Exception;

	void insertEwalletSetleHist(EwalletTransferEntity transferEntity) throws Exception;
	
	void updateMbRefndRequstHst(EwalletMbRefndRequstHstVO ewalletMbRefndRequstHstVO) throws Exception;
	
	void insertMbRefndRequstHst(EwalletMbRefndRequstHstVO ewalletMbRefndRequstHstVO) throws Exception;
	
	void insertCoEwalletManageSttusBas(EwalletCoEwalletManageSttusBasVO ewalletCoEwalletManageSttusBasVO) throws Exception;

	EntrpsInfoBasVO selectEntrpsInfoBas(String entrpsNo);

	List<EntrpsInfoBasVO> selectEmplList(String smsSndngGroupCode);
	
	/**
	 * <pre>
	 * 처리내용: (전자상거래보증 or 서린크레딧) 결제 예정 리스트((전자상거래보증 or 서린크레딧) 및 추가 금액 발생과 (이월렛 or 증거금)의 추가 금액 발생, 결제예정일(+1이상) 주문 결제 건) 가져오기
	 * </pre>
	 * @date 2022. 8. 19.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 19.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	List<EwalletMrtggGrntySetlePrearngeVO> selectMrtggGrntySetlePrearngeList(String entrpsNo);

	/**
	 * <pre>
	 * 처리내용: 주문_주문 기본 테이블의 주문상태코드 및 주문완료일시를 업데이트 
	 * 			 이미 다른 로직에서 주문상태코드가 업데이트된 상황이면, 업데이트 하지 않음 
	 * </pre>
	 * @date 2024. 3. 19.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 3. 19.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	void updateOrderSttusCodeToSuccess(String orderNo) throws Exception;
}
