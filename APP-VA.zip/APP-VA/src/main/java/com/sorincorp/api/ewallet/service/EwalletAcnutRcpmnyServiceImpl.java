package com.sorincorp.api.ewallet.service;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.ewallet.client.socket.EwalletClientSocket;
import com.sorincorp.api.ewallet.comm.constant.EwalletConstant;
import com.sorincorp.api.ewallet.comm.entity.AccountRcpmnyEntity;
import com.sorincorp.api.ewallet.comm.entity.AccountRcpmnyRspnsEntity;
import com.sorincorp.api.ewallet.comm.util.EwalletCommUtil;
import com.sorincorp.api.ewallet.mapper.EwalletAcnutDelngMapper;
import com.sorincorp.api.ewallet.model.EwalletAcnutDelngVO;
import com.sorincorp.comm.util.CryptoUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * EwalletAcnutRcpmnyServiceImpl.java
 * @version
 * @since 2021. 9. 27.
 * @author srec0009
 */
@Slf4j
@Service
public class EwalletAcnutRcpmnyServiceImpl implements EwalletAcnutRcpmnyService {

    @Autowired
    private EwalletClientSocket ewalletClientSocket;
    @Autowired
    private EwalletAcnutDelngMapper ewalletAcnutDelngMapper;
    @Autowired
    private EwalletService ewalletService;

    public static String VA_API_ID = "EWALLET-VA";

    /**
     * 계좌 입금 업무
     * 요구 [0200/1100]
     * 응답 [0210/1100]
     */
    @Override
    public void insertAccountRcpmny(byte[] receiveByte) throws Exception {

        AccountRcpmnyEntity accountRcpmnyEntity = EwalletCommUtil.getObjForBytes(receiveByte, AccountRcpmnyEntity.class);
        // 응답 송신
        if(StringUtils.equals(accountRcpmnyEntity.getBase11(), "0200")) {
            log.debug("[ accountRcpmnyEntity ] :accountRcpmnyEntity =>" + accountRcpmnyEntity);

            // ewallet 가상 계좌 번호
            String ewalletAcnutNo = accountRcpmnyEntity.getEwalletAcnutNo().trim();
            String ewalletAcnutNoEnc = accountRcpmnyEntity.getEwalletAcnutNo();
            String ewalletAcnutNoTmp = accountRcpmnyEntity.getEwalletAcnutNo();

            if(ewalletAcnutNoTmp != null) {
                //가상계좌번호 전문 16자리 맞추기위해 공백 추가
                if(ewalletAcnutNoTmp.length() == 14) {
                    ewalletAcnutNoTmp = ewalletAcnutNoTmp + "  ";
                }
            }

            if(ewalletAcnutNo != null && !"".equals(ewalletAcnutNo)) {
                //가상계좌 암호화 20220119 srec0030
                try {
                    log.debug("14자리 가상계좌 암호화 전 ==================>" + ewalletAcnutNo);
                    ewalletAcnutNo = CryptoUtil.encryptAES256(ewalletAcnutNo);
                    log.debug("14자리 가상계좌 암호화 후 ==================>" + ewalletAcnutNo);
                } catch (Exception e) {
                    // TODO: handle exception
                    log.error("insertAccountRcpmny EWALLET_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
                }
            }

            if(ewalletAcnutNoEnc != null && !"".equals(ewalletAcnutNoEnc)) {
                //가상계좌 암호화 20220119 srec0030
                try {
                    log.debug("가상계좌 암호화 전 ==================>" + ewalletAcnutNoEnc);
                    ewalletAcnutNoEnc = CryptoUtil.encryptAES256(ewalletAcnutNoEnc);
                    log.debug("가상계좌 암호화 후 ==================>" + ewalletAcnutNoEnc);
                    //IF테이블에 insert 하기전에 가상계좌 암호화
                    accountRcpmnyEntity.setEwalletAcnutNo(ewalletAcnutNoEnc);
                    accountRcpmnyEntity.setRcpmnyAcnutNo(ewalletAcnutNoEnc);
                } catch (Exception e) {
                    // TODO: handle exception
                    log.error("insertAccountRcpmny EWALLET_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
                }
            }

            log.debug("ewalletAcnutNo :: " + ewalletAcnutNo);
            log.debug("ewalletAcnutNoEnc :: " + ewalletAcnutNoEnc);
            log.debug("ewalletAcnutNoTmp :: " + ewalletAcnutNoTmp);

            // 업체 번호
            String entrpsNo = ewalletAcnutDelngMapper.selectEntrpsNo(ewalletAcnutNo);
            // 거래일자(YYYYMMDD) + 거래일시(HHMMSS)
            String ewalletDelngDt = accountRcpmnyEntity.getBase15() + accountRcpmnyEntity.getBase16();
            // 이월렛 거래 일시
            ewalletDelngDt = ewalletService.dateFormatter(ewalletDelngDt, 0);
            //accountRcpmnyEntity.setRcpmnyAcnutNo(ewalletAcnutNo);
            accountRcpmnyEntity.setRspnsSttus(1);
            accountRcpmnyEntity.setFrstRegisterId(VA_API_ID);
            accountRcpmnyEntity.setLastChangerId(VA_API_ID);

            // IF REQUST 테이블 insert
            ewalletAcnutDelngMapper.insertIfEwalletDelngRequst(accountRcpmnyEntity);

            //전문에 다시 평문 16자리 가상계좌, 입금계좌 세팅
            accountRcpmnyEntity.setEwalletAcnutNo(ewalletAcnutNoTmp);
            accountRcpmnyEntity.setRcpmnyAcnutNo(ewalletAcnutNoTmp);

            AccountRcpmnyRspnsEntity respnsEntity =  EwalletCommUtil.getObjForBytes(receiveByte, AccountRcpmnyRspnsEntity.class);
            byte[] sendByte = EwalletCommUtil.getByte(respnsEntity, EwalletConstant.EWALLET_TCP_ACCOUNT_RCPMNY_LENGTH);
            // 해당 업체 미존재 시
            if(StringUtils.equals(entrpsNo, null) || StringUtils.equals(entrpsNo, "")) {
                //나중에 위로 올려야됨
                if("14891606710437".equals(ewalletAcnutNo.trim())) {
                    log.debug(">> 하나은행으로 응답 중 14891606710437 에러 응답을 보내게 처리(하나은행 테스트 요청), 2021/11/16");
                    respnsEntity.setBase6("5");
                    respnsEntity.setBase11("0210");
                    respnsEntity.setBase14("777");

                    sendByte = EwalletCommUtil.getByte(respnsEntity, EwalletConstant.EWALLET_TCP_ACCOUNT_RCPMNY_LENGTH);
                    ewalletClientSocket.sendEwallt(sendByte, false);
                } else if("14891606711137".equals(ewalletAcnutNo.trim())){
                    log.debug(">> 하나은행으로 응답 중 14891606711137 계좌는 응답을 보내지 않게 처리(하나은행 테스트 요청), 2021/11/17");
                } else {
                    respnsEntity.setBase6("5");
                    respnsEntity.setBase11("0210");
                    respnsEntity.setBase14("612");
                    respnsEntity.setEwalletAcnutNo(ewalletAcnutNoTmp);
                    sendByte = EwalletCommUtil.getByte(respnsEntity, EwalletConstant.EWALLET_TCP_ACCOUNT_RCPMNY_LENGTH);
                    ewalletClientSocket.sendEwallt(sendByte, false);
                }

                // 응답 송신
                //AccountRcpmnyRspnsEntity respnsEntity =  EwalletCommUtil.getObjForBytes(receiveByte, AccountRcpmnyRspnsEntity.class);
                //respnsEntity.setBase6("5");
                //respnsEntity.setBase11("0210");
                //respnsEntity.setBase14("612");

                //log.debug("0210/1100 센드바이트 ::" +sendByte);
                //ewalletClientSocket.sendEwallt(sendByte);

                // IF rspns 테이블 인서트
                accountRcpmnyEntity.setBase6("5");
                accountRcpmnyEntity.setBase11("0210");
                accountRcpmnyEntity.setBase14("612");
                //IF 테이블에 넣기전에 가상계좌, 입금계좌 암호화 세팅
                accountRcpmnyEntity.setEwalletAcnutNo(ewalletAcnutNoEnc);
                accountRcpmnyEntity.setRcpmnyAcnutNo(ewalletAcnutNoEnc);
                ewalletAcnutDelngMapper.insertIfEwalletDelngRspns(accountRcpmnyEntity);

            // 해당 업체 존재 시
            } else {
                //AccountRcpmnyRspnsEntity respnsEntity =  EwalletCommUtil.getObjForBytes(receiveByte, AccountRcpmnyRspnsEntity.class);
                try {
                    // rspnsStts Code update(1->2)
                    accountRcpmnyEntity.setRspnsSttus(2);
                    ewalletAcnutDelngMapper.updateIfEwalletDelngRequst(accountRcpmnyEntity);

                    // 정상 응답 코드값 세팅
                    //respnsEntity.setBase6("5");
                    //respnsEntity.setBase11("0210");
                    //respnsEntity.setBase14("000");


                    if("14891606710437".equals(ewalletAcnutNo.trim())) {
                        log.debug(">> 하나은행으로 응답 중 14891606710437 에러 응답을 보내게 처리(하나은행 테스트 요청), 2021/11/16");
                        respnsEntity.setBase6("5");
                        respnsEntity.setBase11("0210");
                        respnsEntity.setBase14("777");
                        sendByte = EwalletCommUtil.getByte(respnsEntity, EwalletConstant.EWALLET_TCP_ACCOUNT_RCPMNY_LENGTH);
                        ewalletClientSocket.sendEwallt(sendByte, false);
                    } else if("14891606711137".equals(ewalletAcnutNo.trim())){
                        respnsEntity.setBase14("557");
                        log.debug(">> 하나은행으로 응답 중 14891606711137 계좌는 응답을 보내지 않게 처리(하나은행 테스트 요청), 2021/11/17");
                    } else {
                        // 원장테이블 insert
                        // 업체 이월렛 상세 테이블 insert
                        EwalletAcnutDelngVO vo = new EwalletAcnutDelngVO();
                        vo.setEwalletDelngAmount(Long.parseLong(accountRcpmnyEntity.getDelngAmount()));
                        vo.setEwalletDelngSeCode("02");
                        vo.setEwalletBlce(Long.parseLong(accountRcpmnyEntity.getDelngAfterAcnutBlce()));
                        vo.setDelngSeqNo(accountRcpmnyEntity.getBase17());
                        vo.setEntrpsNo(entrpsNo);
                        vo.setEwalletDelngDt(ewalletDelngDt);
                        vo.setEwalletSumry("서린닷컴 입금");
                        vo.setFrstRegisterId(VA_API_ID);
                        vo.setLastChangerId(VA_API_ID);
                        vo.setTrtmntInsttCode(accountRcpmnyEntity.getBase7()); // 취급기관코드
                        vo.setEwalletExcclcTyCode("01"); // 이월렛 정산 유형 코드 [01-고객입금,02-고객환불,03-주문결제,04-중량정산,05-취소정산,06-교환정산,07-반품정산,08-비용정산]
                        ewalletAcnutDelngMapper.insertEwalletDelng(vo);
                        respnsEntity.setBase6("5");
                        respnsEntity.setBase11("0210");
                        respnsEntity.setBase14("000");
                        sendByte = EwalletCommUtil.getByte(respnsEntity, EwalletConstant.EWALLET_TCP_ACCOUNT_RCPMNY_LENGTH);
                        ewalletClientSocket.sendEwallt(sendByte, false);

                        //입금 후 담당자에게 sms보내기
                        try {
                            ewalletService.sendToAdmAccountRcpmnyMsg(vo, respnsEntity, "S");
                        } catch (Exception e) {
                            // TODO: handle exception
                            log.error("SMS SEND ERROR : " + e.getMessage());
                        }
                        
                        // 입금 발생 시 (전자상거래보증 or 서린크레딧) 결제 예정 리스트((전자상거래보증 or 서린크레딧) 및 추가 금액 발생과 (이월렛 or 증거금)의 추가 금액 발생, 결제예정일(+1이상) 주문 결제 건)이 있을 경우, 입금 후 잔액으로 남은 주문 결제 건을 상환한다.
        				// 입금에 의한 담보 보증 상환 처리 및 추가 금액 처리
        				// 대상 : (전자상거래보증 or 서린크레딧) 결제 예정 리스트((전자상거래보증 or 서린크레딧) 및 추가 금액 발생과 (이월렛 or 증거금)의 추가 금액 발생, 결제예정일(+1이상) 주문 결제 건)
        				try {
        					ewalletService.mrtggGrntyRepyByRcpmny(entrpsNo);
        				} catch(Exception e) {
        					log.error("[EwalletAcnutRcpmnyServiceImpl][insertAccountRcpmny] mrtggGrntyRepyByRcpmny 입금에 의한 담보 보증 상환 처리 또는 추가 금액 발생 처리 실패");
        					log.error(e.getMessage(), e);
        				}
                    }

                } catch (Exception e) {
                    log.debug("insertAccountRcpmny ::" + e.getMessage());
                    respnsEntity.setBase6("5");
                    respnsEntity.setBase11("0210");
                    respnsEntity.setBase14("777");
                    sendByte = EwalletCommUtil.getByte(respnsEntity, EwalletConstant.EWALLET_TCP_ACCOUNT_RCPMNY_LENGTH);
                    ewalletClientSocket.sendEwallt(sendByte, false);
                }

                log.debug("respnsEntity :: "+respnsEntity.toString());

                //byte[] sendByte = EwalletCommUtil.getByte(respnsEntity, EwalletConstant.EWALLET_TCP_ACCOUNT_RCPMNY_LENGTH);
                // 응답 송신
                //ewalletClientSocket.sendEwallt(sendByte);

                // 응답코드 세팅
                // IF rspns 테이블 인서트
                accountRcpmnyEntity.setBase6("5");
                accountRcpmnyEntity.setBase11("0210");
                accountRcpmnyEntity.setBase14(respnsEntity.getBase14());
                //IF 테이블에 넣기전에 가상계좌 암호화 세팅
                accountRcpmnyEntity.setEwalletAcnutNo(ewalletAcnutNoEnc);
                accountRcpmnyEntity.setRcpmnyAcnutNo(ewalletAcnutNoEnc);
                ewalletAcnutDelngMapper.insertIfEwalletDelngRspns(accountRcpmnyEntity);

            }

        }
    }


    /**
     * 입금 취소 [0400/1100]
     */
    @Override
    public void insertAcnutRcpmnyCancel(byte[] receiveByte) throws Exception {
        log.debug("[ receiveByte ] :insertAcnutRcpmnyCancel =>" + receiveByte);

        /** 수신 받은 전문에서 거래 구분코드(API_TYPE) 추출 **/
        AccountRcpmnyEntity rcpmnyCancelEntity = EwalletCommUtil.getObjForBytes(receiveByte, AccountRcpmnyEntity.class);
        if(StringUtils.equals(rcpmnyCancelEntity.getBase11(), "0400")) {

            String ewalletAcnutNo = rcpmnyCancelEntity.getEwalletAcnutNo().trim();
            String ewalletAcnutNoEnc = rcpmnyCancelEntity.getEwalletAcnutNo();
            String ewalletAcnutNoTmp = rcpmnyCancelEntity.getEwalletAcnutNo();

            if(ewalletAcnutNoTmp != null) {
                //전문 길이에 맞춰 평문계좌번호 14자리에 공백2자리 추가
                if(ewalletAcnutNoTmp.length() == 14) {
                    ewalletAcnutNoTmp = ewalletAcnutNoTmp + "  ";
                }
            }

            if(ewalletAcnutNo != null && !"".equals(ewalletAcnutNo)) {
                //가상계좌 암호화 20220119 srec0030
                try {
                    log.debug("14자리 가상계좌 암호화 전 ==================>" + ewalletAcnutNo);
                    ewalletAcnutNo = CryptoUtil.encryptAES256(ewalletAcnutNo);
                    log.debug("14자리 가상계좌 암호화 후 ==================>" + ewalletAcnutNo);
                } catch (Exception e) {
                    // TODO: handle exception
                    log.error("insertAcnutRcpmnyCancel EWALLET_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
                }
            }

            if(ewalletAcnutNoEnc != null && !"".equals(ewalletAcnutNoEnc)) {
                //가상계좌 암호화 20220119 srec0030
                try {
                    log.debug("16자리 가상계좌 암호화 전 ==================>" + ewalletAcnutNoEnc);
                    ewalletAcnutNoEnc = CryptoUtil.encryptAES256(ewalletAcnutNoEnc);
                    log.debug("16자리 가상계좌 암호화 후 ==================>" + ewalletAcnutNoEnc);
                } catch (Exception e) {
                    // TODO: handle exception
                    log.error("insertAcnutRcpmnyCancel EWALLET_ACNUT_NO CryptoUtil.encryptAES256 ERROR " + e.getMessage());
                }
            }

            // IF REQUST 테이블 인서트
            String entrpsNo = ewalletAcnutDelngMapper.selectEntrpsNo(ewalletAcnutNo);
            String ewalletDelngDt = rcpmnyCancelEntity.getBase15() + rcpmnyCancelEntity.getBase16();
            ewalletDelngDt = ewalletService.dateFormatter(ewalletDelngDt, 0);

            long reqstDelngAmount = Long.parseLong(rcpmnyCancelEntity.getDelngAmount());
            rcpmnyCancelEntity.setRcpmnyAcnutNo(rcpmnyCancelEntity.getEwalletAcnutNo().trim());
            rcpmnyCancelEntity.setFrstRegisterId(VA_API_ID);
            rcpmnyCancelEntity.setLastChangerId(VA_API_ID);
            rcpmnyCancelEntity.setRspnsSttus(1);
            //IF테이블에 넣기전에 가상계좌번호 암호화
            rcpmnyCancelEntity.setEwalletAcnutNo(ewalletAcnutNoEnc);
            rcpmnyCancelEntity.setRcpmnyAcnutNo(ewalletAcnutNoEnc);
            ewalletAcnutDelngMapper.insertIfEwalletDelngRequst(rcpmnyCancelEntity);

            //전문에 다시 평문 16자리 가상계좌번호 세팅
            rcpmnyCancelEntity.setEwalletAcnutNo(ewalletAcnutNoTmp);
            rcpmnyCancelEntity.setRcpmnyAcnutNo(ewalletAcnutNoTmp);

            log.debug("요청 환불 금액 ::"+reqstDelngAmount);
            log.debug("현재 이월렛 잔액 ::"+Long.parseLong(rcpmnyCancelEntity.getDelngAfterAcnutBlce()));
            long delngAfterAcnutBlce = Long.parseLong(rcpmnyCancelEntity.getDelngAfterAcnutBlce());
            Long ewalletBlce = delngAfterAcnutBlce - reqstDelngAmount;
            log.debug("원장테이블에 칠 잔액 ::"+ewalletBlce);

            // 응답 송신 entity
            AccountRcpmnyRspnsEntity respnsEntity =  EwalletCommUtil.getObjForBytes(receiveByte, AccountRcpmnyRspnsEntity.class);
            // 업체 번호 미존재
            if(StringUtils.equals(entrpsNo, null) || StringUtils.equals(entrpsNo, "")) {
                // 불능 전문 응답 송신
                //AccountRcpmnyRspnsEntity respnsEntity =  EwalletCommUtil.getObjForBytes(receiveByte, AccountRcpmnyRspnsEntity.class);
                respnsEntity.setBase6("5");
                respnsEntity.setBase11("0410");
                respnsEntity.setBase14("612");

                byte[] sendByte = EwalletCommUtil.getByte(respnsEntity, EwalletConstant.EWALLET_TCP_ACCOUNT_RCPMNY_LENGTH);
                ewalletClientSocket.sendEwallt(sendByte, false);
                log.debug("0410/1100 sendByte:: " + sendByte);

                //IF rspns 테이블 업데이트
                rcpmnyCancelEntity.setBase6("5");
                rcpmnyCancelEntity.setBase11("0410");
                rcpmnyCancelEntity.setBase14("612");

                //IF 테이블에 넣기전에 가상계좌번호 암호화
                rcpmnyCancelEntity.setEwalletAcnutNo(ewalletAcnutNoEnc);
                rcpmnyCancelEntity.setRcpmnyAcnutNo(ewalletAcnutNoEnc);
                // IF rsps 테이블 insert
                ewalletAcnutDelngMapper.insertIfEwalletDelngRspns(rcpmnyCancelEntity);
            // 가상 계좌 잔액 부족 -주문 시에 체크해서 할 필요 없음. 211013
            }
            else {
                try {
                //IF request rspnSttus 1 -> 2 업데이트
                rcpmnyCancelEntity.setRspnsSttus(2);
                ewalletAcnutDelngMapper.updateIfEwalletDelngRequst(rcpmnyCancelEntity);

                EwalletAcnutDelngVO vo = new EwalletAcnutDelngVO();
                vo.setEntrpsNo(entrpsNo);
                vo.setEwalletDelngDt(ewalletDelngDt);
                vo.setDelngSeqNo(rcpmnyCancelEntity.getBase17());
                vo.setEwalletDelngSeCode("07");
                vo.setEwalletDelngAmount(reqstDelngAmount);
                vo.setEwalletBlce(ewalletBlce);
                vo.setFrstRegisterId(VA_API_ID);
                vo.setLastChangerId(VA_API_ID);
                vo.setEwalletSumry("서린닷컴 입금 취소");
                vo.setFrstRegisterId(VA_API_ID);
                vo.setLastChangerId(VA_API_ID);
                vo.setTrtmntInsttCode(rcpmnyCancelEntity.getBase7()); // 취급기관코드

                // 업체 이월렛 상세 테이블 - 입금 취소 insert
                ewalletAcnutDelngMapper.insertEwalletDelng(vo);

                respnsEntity.setBase6("5");
                respnsEntity.setBase11("0410");
                respnsEntity.setBase14("000");

                //IF rspns 테이블 업데이트
                rcpmnyCancelEntity.setBase6("5");
                rcpmnyCancelEntity.setBase11("0410");
                rcpmnyCancelEntity.setBase14("000");

                } catch (Exception e) {
                    respnsEntity.setBase6("5");
                    respnsEntity.setBase11("0410");
                    respnsEntity.setBase14("777");
                }
                //응답 송신
                byte[] sendByte = EwalletCommUtil.getByte(respnsEntity, EwalletConstant.EWALLET_TCP_ACCOUNT_RCPMNY_LENGTH);
                ewalletClientSocket.sendEwallt(sendByte, false);
                log.debug("0410/1100 sendByte:: " + sendByte);

                //IF 테이블에 넣기전에 가상계좌번호 암호화
                rcpmnyCancelEntity.setEwalletAcnutNo(ewalletAcnutNoEnc);
                rcpmnyCancelEntity.setRcpmnyAcnutNo(ewalletAcnutNoEnc);
                // IF rsps 테이블 insert
                ewalletAcnutDelngMapper.insertIfEwalletDelngRspns(rcpmnyCancelEntity);
            }
        }

    }
}
