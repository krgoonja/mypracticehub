package com.sorincorp.api.ewallet.server.channel;

import org.springframework.stereotype.Component;

import com.sorincorp.api.ewallet.server.decoder.EwalletDecoder;
import com.sorincorp.api.ewallet.server.handler.EwalletHandler;

import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class EwalletChannelInitializer extends ChannelInitializer<SocketChannel>{
	
	private final EwalletHandler ewalletHandler;
	
	@Override
	protected void initChannel(SocketChannel ch) throws Exception {
		ChannelPipeline pipeline = ch.pipeline();
		
		pipeline.addLast(ewalletHandler);
	}

	
}
