package com.sorincorp.api.ewallet.server.decoder;

import java.nio.charset.StandardCharsets;
import java.util.List;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.ByteToMessageDecoder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public class EwalletDecoder extends ByteToMessageDecoder{

	private ByteBuf byteBuf;

	private int totalLengthIndex = 4;

	private int dataLength;

	// ByteBuf는 읽은 만큼 index가 증가하며, 쓴만큼 index가 증가
	// readIndex, writeIndex가 서로 다르게 작동
	// 데이터가 수신 될때 실행
	// 보낸 전문의 길이가 전문 상의 길이와 일치 할때만 데이터를 받음
    @Override
    protected void decode(ChannelHandlerContext ctx, ByteBuf in, List<Object> out) throws Exception {

    	log.debug("1. decode() readableBytes : " + in.readableBytes() + ", totalLengthIndex : " + totalLengthIndex + ", dataLength : " + dataLength);

    	/** 전문 총 길이 만큼 읽었는지 체크 **/
    	if (in.readableBytes() < totalLengthIndex) {
    		log.debug("0. decode() return..");
            return;
        }

    	if(dataLength == 0) {
    		/** 전문 총 길이 선언 **/
    		log.debug("reader index : " + in.readerIndex());
    		log.debug("readableBytes : " + in.readableBytes());
    		byteBuf = in.readBytes (totalLengthIndex);
    		log.debug("after reader index : " + in.readerIndex());
    		log.debug(byteBuf.toString(StandardCharsets.UTF_8));
    		dataLength = Integer.parseInt(byteBuf.toString(StandardCharsets.UTF_8));
    		log.debug("2. decode() readableBytes : " + in.readableBytes() + ", totalLengthIndex : " + totalLengthIndex + ", dataLength : " + dataLength);

    	}else if(in.readableBytes() + totalLengthIndex == dataLength){
    		/** 전문 총 길이 만큼 쓰고 다음 핸들러에 보낸다 **/
    		byteBuf.writeBytes(in.readBytes(dataLength - totalLengthIndex));
            out.add(byteBuf);
            dataLength = 0;
//            byteBuf.clear();
            byteBuf = null;
            log.debug("3. decode() readableBytes : " + in.readableBytes() + ", totalLengthIndex : " + totalLengthIndex + ", dataLength : " + dataLength);

    	} else {
    		log.debug("decode() nothing");
    		log.debug("4. decode() readableBytes : " + in.readableBytes() + ", totalLengthIndex : " + totalLengthIndex + ", dataLength : " + dataLength);
    	}

    	log.debug("5. decode() readableBytes : " + in.readableBytes() + ", totalLengthIndex : " + totalLengthIndex + ", dataLength : " + dataLength);
    }

}
