package com.sorincorp.api.samsung.ft.handler;

import java.util.ArrayList;

import com.sorincorp.api.samsung.ft.model.EcMssageHeaderVo;
import com.sorincorp.api.samsung.ft.model.FtrsOrderRspnsVo;
import com.sorincorp.api.samsung.ft.socket.FixCnncHandler;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FtrsBfeProcHandler extends Thread {
	private static FtrsBfeProcHandler INSTANCE;
	private boolean isRun;
	private ArrayList<Object> list;
	private FixCnncHandler tcpCnncMngr;

	private FtrsBfeProcHandler() {
		isRun = true;
		list = new ArrayList<Object>();
		setName("SORIN-FtrsBfeProcHandler");
		setDaemon(true);
	}

	public static synchronized FtrsBfeProcHandler getInstance() {
		if( INSTANCE == null )
			INSTANCE = new FtrsBfeProcHandler();
		return INSTANCE;
	}

	public void setTcpCnncMngr(FixCnncHandler mgr) {
		tcpCnncMngr = mgr;
	}

	public void add(Object obj) throws Exception{
		synchronized(list) {
			int size = list.size();
			if (size>3000){
				log.info("==> Buffer is OverFlow And Clear!!");
				throw new Exception("Order Buffer is OverFlow");
			}else{
				list.add(obj);
				list.notify();
			}
		}
	}

	public void stopThread(){
		try {
			setRun(false);
			interrupt();

			Thread.sleep(50L);
		} catch (InterruptedException e) {
		}

		if(this.INSTANCE != null){
			this.INSTANCE = null;
		}
	}

	public void setRun(boolean run){
		this.isRun = run;
	}

//	public void sendFixOrder(FtrsOrderRequstVo vo) {
//		boolean result = false;
//		byte[] bytes   = null;
//		try {
//
//			System.out.println("send time start =========[" + DateUtil.calDate("yyyyMMdd-HH:mm:ss.SSS") +"]") ;
//			bytes = fixDataOrderHandler.getFixSendByteData(vo);
//
//			if(bytes != null) {
//				result = tcpCnncMngr.sendToOrderData(bytes);
//			}
//			System.out.println("send time end =========[" + DateUtil.calDate("yyyyMMdd-HH:mm:ss.SSS") +"]") ;
//			log.info("############### sendFixOrder Result : [" + result +"]");
//
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
//
//	}

	public void sendFixRecevier(EcMssageHeaderVo vo) {
		try {
			byte[] bytes   = vo.getMssageHeaderByte();

			tcpCnncMngr.sendToReceiveData(bytes);

		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public final void run() {
		Object object = null;
		while( isRun ) {
			synchronized(list) {
				if( list.size() == 0 ) {
					try {
						list.wait();
					} catch(Exception e) {}
				} else {
					object = (Object) list.remove(0);
				}
			}

			try{
				if( object != null ){
//					if(object instanceof FtrsOrderRequstVo) {
//
//						sendFixOrder((FtrsOrderRequstVo)object);
//
//					}else
					if(object instanceof FtrsOrderRspnsVo) {
						sendFixRecevier((EcMssageHeaderVo)object);
					}else {
						log.error("FtrsOrderRspnsVo ########### 기타 데이타 ######## [{}]", object);
					}
				}

				object = null;
			} catch (Throwable t) {
				try {
					list.clear();
					sleep(60000L);
				} catch (InterruptedException e) {}
		    }
		}

		this.isRun = false;
		log.info("ExtrlCntcDataOpetr is Terminated!!!");
	}
}
