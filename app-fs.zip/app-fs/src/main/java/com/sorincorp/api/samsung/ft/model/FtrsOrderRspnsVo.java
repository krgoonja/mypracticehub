package com.sorincorp.api.samsung.ft.model;

import com.sorincorp.api.util.ApiCmmnUtil;
import com.sorincorp.api.util.FtrsConst;
import com.sorincorp.comm.util.StringUtil;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class FtrsOrderRspnsVo extends EcMssageHeaderVo{
	private static final long serialVersionUID = 4299257748638756015L;

	char msgType;				/*	char(1)	8= Execution Report								Tag: 35 */
								/*		9= Order Cancel Reject */
								/*		j= Business Reject */
								/*		3= Session Reject */
	String senderCompId;		/*	char(20)	SSF_UAT (개발)								Tag: 49 */
	String targetCompId;		/*	char(20)	SORIN_UAT (개발)								Tag: 56 */
	String onBehalfOfCompId;	/*	char(20)	현재는 사용하지 않음. (HUB 사용시 필요함)				Tag: 115 */
	/* String account;				char(10)												Tag: 1 */
	//선물사 다중화로 이베스트 증권 추가하여 1BYTE 증가
	String account;				/*	char(11)												Tag: 1 */
	String avgPx;				/*	char(15)	평균단가										Tag: 6 */
	String clOrdId;				/*	char(20)												Tag: 11 */
	String cumQty;				/*	char(15)	누적체결수량									Tag: 14 */
	String execId;				/*	char(20)	Unique identifier of execution message as assigned by sell-side.	Tag: 17 */
								/*		 ※ 체결 중복 확인 시 필요. (증권사별 관리) */
	String lastPx;				/*	char(15)	체결단가										Tag: 31 */
	String lastShares;			/*	char(15)	체결수량										Tag: 32 */
	String orderId;				/*	char(20)	삼성선물 주문번호									Tag: 37 */
	String orderQty;			/*	char(15)	주문수량										Tag: 38 */
	char ordStatus;			/*	char(1)	A= Pending New									Tag: 39 */
								/*		0= New */
								/*		1= Partially filled */
								/*		2= Filled */
								/*		4= Canceled */
								/*		5=Replaced */
								/*		6= Pending Cancel (e.g. result of Order Cancel Request) */
								/*		E= Pending Replace (e.g. result of Order Cancel/Replace Request) */
	char ordType;				/*	char(1)	2=Limit   4=Stop Limit 							Tag: 40 */
	/** 원주문번호(정정/취소 시 필요함) */
	String origClOrdId;			/*	char(20)												Tag: 41 */
	String price;				/*	char(15)	주문 단가										Tag: 44 */
	char side;				/*	char(1)	1= Buy  2= Sell  								Tag: 54 */
	String symbol;				/*	char(12)	종목코드 										Tag: 55 */
	String text;				/*	char(200)	거부 사유										Tag: 58 */
	String transactTime;		/*	char(21)	20200527-00:17:47.000 (KST)					Tag: 60 */
	String stopPx;				/*	char(15)												Tag: 99 */
	char execType;			/*	char(1)	A= Pending New									Tag: 150 */
								/*		0= New */
								/*		4= Canceled */
								/*		5= Replaced */
								/*		6= Pending Cancel (e.g. result of Order Cancel Request) */
								/*		8= Rejected */
								/*		C= Expired (like 수작업 취소) */
								/*		E= Pending Replace (e.g. result of Order Cancel/Replace Request) */
								/*		F= Trade */
	String leavesQty;			/*	char(15)	잔량 (취소 완료시=0)								Tag: 151 */
	String securityType;		/*	char(3)	FUT												Tag: 167 */
	String securityExchange;	/*	char(3)	LME												Tag: 207 */
	/** 만기일 **/
	String maturityDate;		/*	char(8)	Specifies date of maturity (a full date). Last Trading Day of Market.	Tag: 541 */
	String rspnsSpclty;         /* 응답전문 */

	/******************* 주문 취소 및 만기 조정
	/** 청산대상 포지션번호          */
	String positionID;         /*  char(20)	청산대상 포지션번호                           Tag: 508 */

	/** 만기포지션번호               */
	String expiredID; 			/*  char(20)	만기포지션번호                           Tag: 509 */
	String commition;			/*  char(15)    수수료 (필드 추가)                       Tag: 5010 */
	String commition2;			/*  char(15)    수수료2 (필드 추가)                      Tag: 5011 */
	String spread;				/*  char(15)    스프레드 가격 (필드 추가)                  Tag: 5012 */

	public void decodeResponseData(byte[] data) {
		int offset = 0;
		this.msgType = (char)data[0];
		offset += FtrsConst.RCV_MSG_TYPE_LEN;

		this.senderCompId= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_SENDER_COMPID_LEN));
		offset += FtrsConst.RCV_SENDER_COMPID_LEN;

		this.targetCompId= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_TARGET_COMPID_LEN));
		offset += FtrsConst.RCV_TARGET_COMPID_LEN;

		this.onBehalfOfCompId= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_ON_BEHALF_OF_COMPID_LEN));
		offset += FtrsConst.RCV_ON_BEHALF_OF_COMPID_LEN;

		this.account= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_ACCOUNT_LEN));
		offset += FtrsConst.RCV_ACCOUNT_LEN;

		this.avgPx= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_AVG_PX_LEN));
		offset += FtrsConst.RCV_AVG_PX_LEN;

		this.clOrdId= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_CL_ORDID_LEN));
		offset += FtrsConst.RCV_CL_ORDID_LEN;

		this.cumQty= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_CUM_QTY_LEN));
		offset += FtrsConst.RCV_CUM_QTY_LEN;

		this.execId= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_EXECID_LEN));
		offset += FtrsConst.RCV_EXECID_LEN;

		this.lastPx= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_LAST_PX_LEN));
		offset += FtrsConst.RCV_LAST_PX_LEN;

		this.lastShares= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_LAST_SHARES_LEN));
		offset += FtrsConst.RCV_LAST_SHARES_LEN;

		this.orderId= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_ORDERID_LEN));
		offset += FtrsConst.RCV_ORDERID_LEN;

		this.orderQty= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_ORDER_QTY_LEN));
		offset += FtrsConst.RCV_ORDER_QTY_LEN;

		this.ordStatus= (char)data[offset];
		offset += FtrsConst.RCV_ORD_STATUS_LEN;

		this.ordType= (char)data[offset];
		offset += FtrsConst.RCV_ORD_TYPE_LEN;

		this.origClOrdId= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_ORIG_CL_ORDID_LEN));
		offset += FtrsConst.RCV_ORIG_CL_ORDID_LEN;

		this.price= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_PRICE_LEN));
		offset += FtrsConst.RCV_PRICE_LEN;

		this.side= (char)data[offset];
		offset += FtrsConst.RCV_SIDE_LEN;

		this.symbol= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_SYMBOL_LEN));
		offset += FtrsConst.RCV_SYMBOL_LEN;

		this.text= ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_TEXT_LEN).trim();
		offset += FtrsConst.RCV_TEXT_LEN;

		this.transactTime= ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_TRANSACT_TIME_LEN).trim();
		offset += FtrsConst.RCV_TRANSACT_TIME_LEN;

		this.stopPx= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_STOP_PX_LEN));
		offset += FtrsConst.RCV_STOP_PX_LEN;

		this.execType= (char)data[offset];
		offset += FtrsConst.RCV_EXEC_TYPE_LEN;

		this.leavesQty= StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_LEAVES_QTY_LEN));
		offset += FtrsConst.RCV_LEAVES_QTY_LEN;

		this.securityType= ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_SECURITY_TYPE_LEN).trim();
		offset += FtrsConst.RCV_SECURITY_TYPE_LEN;

		this.securityExchange= ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_SECURITY_EXCHANGE_LEN).trim();
		offset += FtrsConst.RCV_SECURITY_EXCHANGE_LEN;

		this.maturityDate= ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_MATURITY_DATE_LEN).trim();
		offset += FtrsConst.RCV_MATURITY_DATE_LEN;

		this.positionID = ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_POSITION_NUM_LEN).trim();
		offset += FtrsConst.RCV_POSITION_NUM_LEN;

		this.expiredID = ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_EXPIRED_ID_LEN).trim();
		offset += FtrsConst.RCV_EXPIRED_ID_LEN;

		// 선물사 다증화로 Commition 추가, (삼성선물 체결 발생시 스페이스로 처리 됨)
		this.commition = StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_COMMITION_LEN));
		offset += FtrsConst.RCV_COMMITION_LEN;

		this.commition2 = StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_COMMITION2_LEN));
		offset += FtrsConst.RCV_COMMITION2_LEN;

		this.spread = StringUtil.trim(ApiCmmnUtil.bytes2String(data, offset, FtrsConst.RCV_SPREAD_LEN));

		this.rspnsSpclty= new String(data);
	}
}