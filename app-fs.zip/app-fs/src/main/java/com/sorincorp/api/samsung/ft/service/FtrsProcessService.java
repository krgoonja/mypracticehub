package com.sorincorp.api.samsung.ft.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.api.samsung.exception.FtrsBizException;
import com.sorincorp.api.samsung.ft.model.CommCodeVo;
import com.sorincorp.api.samsung.ft.model.FtrsOrderRequstVo;
import com.sorincorp.api.samsung.ft.model.OrOrderFtrsBasVo;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;

public interface FtrsProcessService {
	String getTestOrderNo() throws Exception;
	String getTestFtrsReqOrderNo() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 삼성선물 거래를 위해 DataLoad Fix Client와 세션 일련번호를 맞추기 위해 일련 번호를 조회한다.
	 * </pre>
	 * @date 2021. 9. 6.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 6.			srec0032			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	int selectIfFtrsOrderSeqNumber() throws Exception;

	/**
	 * <pre>
	 * 처리내용: Fix 주문 데이터를 인터페이스 테이블에 저장한다.
	 * </pre>
	 * @date 2021. 9. 14.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 14.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param dataInfo
	 * @return
	 * @throws Exception
	 */
	int insertIfFtrsOrderRequstData(FtrsOrderRequstVo dataInfo) throws Exception;

	 /**
	 * <pre>
	 * 처리내용: Fix 주문전 Validation 실행결과 실패시 상태 수정.
	 * </pre>
	 * @date 2021. 12. 6.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 6.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param reqVoList
	 * @throws Exception
	 */
	void saveFtrsOrderValidResult(List<OrOrderFtrsBasVo> reqVoList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문 전송시 데이터로드로부터 "DAOK" 수신시 원주문의 상태코드를 주문요청으로 변경한다.
	 * </pre>
	 * @date 2021. 9. 30.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 30.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	void updateFtrsOrderSendResult(List<FtrsOrderRequstVo> sendResultList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 삼성선물 주문 관련 전송 에러 내용을 로깅한다.
	 * </pre>
	 * @date 2021. 11. 16.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 16.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param sendResultList
	 */
	void printFtrsSendFailInfo(List<FtrsOrderRequstVo> sendResultList);

	/**
	 * 선물사로 주문 전에 데이터 validation 체크및 Fix 전문 데이터 생성을 한다.
	 * @param side - 1: 매수(Buy) 주문, 2:매도(Sell) 주문
	 * @param sendMsgTypeOr - D= New Order, F= Order Cancel Request
	 * @param commCodeList - 선물사 거래 item code 리스트
	 * @param ftrsBasData - 선물 주문 정보
	 * @return FtrsOrderRequstVo - Fix 전문 내용
	 * @exception Exception
	 */
	FtrsOrderRequstVo checkFtrsNewOrder(char side, char sendMsgTypeOr, List<CommCodeVo> commCodeList, OrOrderFtrsBasVo ftrsBasData) throws FtrsBizException;
}
