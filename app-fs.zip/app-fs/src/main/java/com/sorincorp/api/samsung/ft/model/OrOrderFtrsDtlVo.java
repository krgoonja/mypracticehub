package com.sorincorp.api.samsung.ft.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class OrOrderFtrsDtlVo {
	    /**
	     * 선물 요청 주문 번호
	    */
	    private String ftrsRequstOrderNo;
	    /**
	     * 선물 요청 상세 순번
	    */
	    private int ftrsRequstDetailSn;
	    /**
	     * 평균 단가
	    */
	    private String avrgUntpc;
	    /**
	     * 누적 체결 수량
	    */
	    private String accmltCnclsQy;
	    /**
	     * 실행 ID
	    */
	    private String executId;
	    /**
	     * 체결 단가
	    */
	    private String cnclsUntpc;
	    /**
	     * 체결 수량
	    */
	    private String cnclsQy;
	    /**
	     * 응답 선물 주문 번호
	    */
	    private String rspnsFtrsOrderNo;
	    /**
	     * 주문 수량
	    */
	    private String orderQy;
	    /**
	     * 주문 상태
	    */
	    private String orderSttus;
	    /**
	     * 주문 단가
	    */
	    private String orderUntpc;
	    /**
	     * 포지션
	    */
	    private String postn;
	    /**
	     * 종목 코드
	    */
	    private String itemCode;
	    /**
	     * 거부 사유
	    */
	    private String rejectResn;
	    /**
	     * 실행 타입
	    */
	    private String executTy;
	    /**
	     * 잔량
	    */
	    private String bnt;
	    /**
	     * 만기 일자
	    */
	    private String exprtnDe;
	    /**
	     * 만기 실행 ID
	    */
	    private String exprtnExecutId;
	    /**
	     * 삭제 일시
	    */
	    private java.sql.Timestamp deleteDt;
	    /**
	     * 삭제 여부
	    */
	    private String deleteAt;
	    /**
	     * 최초 등록자 아이디
	    */
	    private String frstRegisterId;
	    /**
	     * 최초 등록 일시
	    */
	    private java.sql.Timestamp frstRegistDt;
	    /**
	     * 최종 변경자 아이디
	    */
	    private String lastChangerId;
	    /**
	     * 최종 변경 일시
	    */
	    private java.sql.Timestamp lastChangeDt;
	    /**
	     * 청산 실행 ID
	    */
	    private String lqdExecutId;
}
