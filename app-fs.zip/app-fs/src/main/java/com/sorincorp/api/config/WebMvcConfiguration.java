package com.sorincorp.api.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

@Configuration
public class WebMvcConfiguration implements WebMvcConfigurer {
//	@Bean
//	ServletListenerRegistrationBean<ServletContextListener> servletListener() {
//		ServletListenerRegistrationBean<ServletContextListener> srb = new ServletListenerRegistrationBean<>();
//		srb.setListener(new DaemonListener());
//		return srb;
//	}

	@Bean
    MappingJackson2JsonView jsonView(){
        return new MappingJackson2JsonView();
    }
}
