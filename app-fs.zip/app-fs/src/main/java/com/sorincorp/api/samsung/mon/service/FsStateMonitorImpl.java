package com.sorincorp.api.samsung.mon.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.sorincorp.api.samsung.ft.handler.FixDataOrderExecutor;
import com.sorincorp.api.samsung.ft.model.FtrsOrderRequstVo;
import com.sorincorp.api.samsung.service.FtrsStateMonitorIsSaleTime;
import com.sorincorp.api.util.FtrsConst;
import com.sorincorp.comm.cntcsttus.model.CntcSttusVO;
import com.sorincorp.comm.cntcsttus.service.CntcSttusService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@ComponentScan({"com.sorincorp.comm.cntcsttus.*"})
public class FsStateMonitorImpl implements FsStateMonitorService{

	@Value("${fix.sender-compid}")
	private String FIX_SENDER_COMPID;            //SORIN_UAT

	@Autowired
	private FixDataOrderExecutor fixDataOrderExecutor;

	@Autowired
	private CntcSttusService cntcSttusService;

	@Autowired
	private FtrsStateMonitorIsSaleTime ftrsStateMonitorIsSaleTime;

	private final static String INTRFC_SE_CODE_FS = "30";


	@Override
	public List<FtrsOrderRequstVo> checkFsServerStatus(String targetCompID) throws Exception{
		/*
		인터페이스 구분 코드 : INTRFC_SE_CODE(30:	FS)
	   */

		FtrsOrderRequstVo fixOrder = new FtrsOrderRequstVo();
		String strOrdDataLen = StringUtil.padValue(String.valueOf(FtrsConst.DATAlOAD_ORDER_DATA_LEN), "0", 4, true);
		String transactTime = DateUtil.calDate(FtrsConst.FIX_DATE_FORMAT1);

        /* Message Header */
		/* origin: 46 + 242 byte = 288 */
		/* 이베스트증권 계좌 추가로 1byte 추가됨
		 * 46 + 243 byte = 289
		 * 2023-06-23
		 * */
		fixOrder.setDataLength(strOrdDataLen);
		fixOrder.setHeaderType(FtrsConst.DATALOAD_SESS_REQ);
		fixOrder.setTradeDate(ftrsStateMonitorIsSaleTime.getTradeDate());

		/* Message Body */
		fixOrder.setMsgType(FtrsConst.SEND_MSG_TYPE_TO);  	 		//D: New Order, T : 삼성선물 회선 검증
		fixOrder.setSenderCompId(FIX_SENDER_COMPID);           		//Tag : 49, 	SORIN_UAT (개발)
		fixOrder.setTargetCompId(targetCompID);           			//Tag : 56, 	SSF_UAT (개발, 삼성), EBEST_UAT (개발, 이베스트증권)
		fixOrder.setDeliverToCompId(StringUtils.EMPTY);		 		//Tag : 128, 	현재는 사용하지 않음. (HUB 사용시 필요함)
		fixOrder.setAccountNo(StringUtils.EMPTY);              		//Tag : 1
		fixOrder.setClOrdId(StringUtils.EMPTY);            	  		//Tag : 11
		fixOrder.setHandlInst(' ');	  								//Tag : 21, 1= DMA
		fixOrder.setOrderId(StringUtils.EMPTY);            	  		//Tag : 37         //삼성선물 주문번호 - 주문시 보내지 않는다.
		fixOrder.setOrderQty(StringUtils.EMPTY);               		//Tag : 38
		fixOrder.setOrdType(' ');  									//Tag : 40 ,      2=Limit   4=Stop Limit -- 케이지트레이딩에서는 2번만 사용
		fixOrder.setOrigClOrdId(StringUtils.EMPTY);  	  			//Tag : 41         //취소주문시에만 보낸다.
		fixOrder.setPrice(StringUtils.EMPTY);          		  		//Tag : 44
		fixOrder.setSide(' ');                                   	//Tag : 54
		fixOrder.setSymbol(StringUtils.EMPTY);  					//Tag : 55 - ALUMINUM(알루미늄): LAL, ZINC(아연): LZN, 상품코드 + 'M03', 케이지트레이딩에서는 알루미늄만 선물 거래함.
		fixOrder.setTransactTime(transactTime);              	  	//Tag : 60
		fixOrder.setStopPx(StringUtils.EMPTY);                 	  	//Tag : 99,  케이지트레이딩에서는 사용않함.
		fixOrder.setSecurityType(StringUtils.EMPTY);	 	  		//Fix Tag: 167 (문자열) - Future:선물
		fixOrder.setSecurityExchange(StringUtils.EMPTY);   			//Fix Tag: 207
		fixOrder.setCurrency(StringUtils.EMPTY);    				//Fix Tag: 15 (통화)
		fixOrder.setPositionEffect(' ');
		fixOrder.setPositionNum(StringUtils.EMPTY);

		List<FtrsOrderRequstVo> list = new ArrayList<FtrsOrderRequstVo>();
		list.add(fixOrder);

		return fixDataOrderExecutor.doSendData(list);
	}

	@Override
	public void checkFsWorkStatus(boolean result) {
		try {
			CntcSttusVO cntcSttusFailVO = new CntcSttusVO();
			cntcSttusFailVO.setCheckResult(result);
			cntcSttusFailVO.setIntrfcSeCode(INTRFC_SE_CODE_FS);
			cntcSttusFailVO.setLastChangerId("fssystem");

			cntcSttusService.updateCoCntcSttusBas(cntcSttusFailVO);
		}catch(Exception e) {
			log.error("checkFxWorkStatus Error.", e);
		}
	}

	@Override
	public void checkFsWorkStatus(CntcSttusVO cntcSttusVO) {
		try {
			cntcSttusVO.setIntrfcSeCode(INTRFC_SE_CODE_FS);
			cntcSttusVO.setLastChangerId("fssystem");

			cntcSttusService.updateCoCntcSttusBas(cntcSttusVO);
		}catch(Exception e) {
			log.error("checkFsWorkStatus Error.", e);
		}
	}
}
