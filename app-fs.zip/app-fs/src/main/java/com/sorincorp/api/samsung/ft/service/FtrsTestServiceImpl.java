package com.sorincorp.api.samsung.ft.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.samsung.exception.FtrsBizException;
import com.sorincorp.api.samsung.ft.handler.FixDataOrderExecutor;
import com.sorincorp.api.samsung.ft.mapper.FtrsMapper;
import com.sorincorp.api.samsung.ft.model.CommCodeVo;
import com.sorincorp.api.samsung.ft.model.FtrsOrderRequstVo;
import com.sorincorp.api.samsung.ft.model.OrOrderFtrsBasVo;
import com.sorincorp.api.samsung.ft.model.OrOrderFtrsDtlVo;
import com.sorincorp.api.util.FtrsConst;
import com.sorincorp.comm.order.constant.CommFtrsConstant;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 테스트 삼성선물 주문 서비스
 * @author srec0051
 *
 */
@Slf4j
@Service
public class FtrsTestServiceImpl implements FtrsTestService{
	@Autowired
	private FtrsMapper ftrsMapper;

	@Autowired
	private FixDataOrderExecutor fixDataOrderExecutor;

	@Autowired
	private FtrsProcessService procService;

	@Autowired
	private FtrsOrderService orderService;

	@Autowired
	private FtrsClaimOrderService claimOrderService;

	private final String REQUST_SAMSUNG_ACNUT_NO_TEST = "51900107";
	// 다른 부분은 계좌번호 운영과 같이 변경함, 여기는 테스트하는 곳인데 운영과 같으면 사용될 우려가 있어서 변경하지 않음, 2024-11-14
	private final String REQUST_EBEST_ACNUT_NO_TEST = "20529549504"; //다른 테스트 계좌 - 20529549505

	private String encryptAcnuntNo(String ftrsCmpnyTrgetCode) throws Exception {
		String encAcnuntNo = "";
		if(StringUtils.equals(CommFtrsConstant.FTRS_SAMSUNG_CMPNY_CODE, ftrsCmpnyTrgetCode)) { //삼성선물
			encAcnuntNo = CryptoUtil.encryptAES256(REQUST_SAMSUNG_ACNUT_NO_TEST);
			log.info("계좌번호 {} 암호화 {}", REQUST_SAMSUNG_ACNUT_NO_TEST, encAcnuntNo);
		}else {
			encAcnuntNo = CryptoUtil.encryptAES256(REQUST_EBEST_ACNUT_NO_TEST);
			log.info("계좌번호 {} 암호화 {}", REQUST_EBEST_ACNUT_NO_TEST, encAcnuntNo);
		}

		return encAcnuntNo;
	}

	@Override
	public void testFtrsNewOrder(OrOrderFtrsBasVo ordInfo) throws FtrsBizException, Exception {
		String orderTyCode = ordInfo.getRequstFtrsOrderTyCode();
		if(orderTyCode.equals("10")) {
			testOrder(ordInfo);
		}else if(orderTyCode.equals("20")) {
			testFtrOrdersCancle(ordInfo);
		}
	}

	/**
	 * 테스트 삼성선물 신규 주문 데이터 생성
	 */
	private void testOrder(OrOrderFtrsBasVo ordInfo) throws Exception {
		int orderQy = Integer.parseInt(ordInfo.getRequstOrderQy());

		String orderNo  = procService.getTestOrderNo();
		String ftrsCmpnyTrgetCode = ordInfo.getFtrsCmpnyTrgetCode();
		char side = ordInfo.getRequstPostn();
		String testType = ordInfo.getTestType();
		if(StringUtils.isEmpty(testType)) {             //25톤 단위 주문 생성
			testType = "A";
		}

		String requstAcnutNo = ordInfo.getRequstAcnutNo();
		String acnutNo = "";
		if(StringUtils.isNotEmpty(requstAcnutNo)) {
			acnutNo = CryptoUtil.encryptAES256(requstAcnutNo);
		}else {
			acnutNo = encryptAcnuntNo(ftrsCmpnyTrgetCode);
		}

		if(testType.equals("A")) {							//25톤 단위로 주문 생성
			for(int i=0; i<orderQy; i++) {
				ordInfo.setOrderNo(orderNo);

				String tmpMaxReqNo = procService.getTestFtrsReqOrderNo();
				ordInfo.setFtrsRequstOrderNo(tmpMaxReqNo);
				ordInfo.setOrderSn("00"+ (i+1));
				ordInfo.setCanclExchngRtngudNo("00000000-000000");				/* 취소 교환 반품 번호           */
				ordInfo.setCanclExchngRtngudSn("000");							/* 취소 교환 반품 순번           */
				ordInfo.setRequstAcnutNo(acnutNo);		/** 계좌번호*/
				ordInfo.setFrstFtrsRequstOrderNo(tmpMaxReqNo);		/* 최초 선물 요청 주문 번호 */
				ordInfo.setRequstOrderQy("1");
				ftrsMapper.insertTestDataFtrsNewOrder(ordInfo);
			}
		}else {                                                  // 테스트 요청 주문 중량으러 생성
			ordInfo.setOrderNo(orderNo);

			String tmpMaxReqNo = procService.getTestFtrsReqOrderNo();
			ordInfo.setFtrsRequstOrderNo(tmpMaxReqNo);
			ordInfo.setOrderSn("001");
			ordInfo.setCanclExchngRtngudNo("00000000-000000");				/* 취소 교환 반품 번호           */
			ordInfo.setCanclExchngRtngudSn("000");							/* 취소 교환 반품 순번           */
			ordInfo.setRequstAcnutNo(acnutNo);		/** 계좌번호*/
			ordInfo.setFrstFtrsRequstOrderNo(tmpMaxReqNo);		/* 최초 선물 요청 주문 번호 */

			ftrsMapper.insertTestDataFtrsNewOrder(ordInfo);
		}

		OrOrderFtrsBasVo param = new OrOrderFtrsBasVo();
		param.setOrderNo(orderNo);
		testExecuteFtrsNewOrder(side, param);

		int count = 0;
		int resultWaitSecond = 2;
		int rcvCnt = 0;
		boolean success = false;

		OrOrderFtrsBasVo param2 = new OrOrderFtrsBasVo();
		param2.setOrderNo(orderNo);
		param2.setRspnsFtrsSttusCode("30");  //완료건
		while (true) {
			count++;
			Thread.sleep(500L);

			List<OrOrderFtrsBasVo> list = ftrsMapper.selectTestOrOrderFtrsBasList(param2);
			rcvCnt = list.size();
			if(rcvCnt == orderQy) {
				success = true;
				break;
			}

			if(count/2 >= resultWaitSecond) {
				break;
			}

		}

		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		log.info(">>>>>>>>>>>>>>>>>>>> orderNo : " + orderNo    +">>>>>>>>>>>>>");
		log.info(">>>>>>>>>>>>>>>>>>>> msgType : D >>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		log.info(">>>>>>>>>>>>>>>>>>>> send result :" + success + ">>>>>>>>>>>>");
		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
	}

	/**
	 * 테스트 삼성선물 주문 취소 데이터 생성
	 * @param ordInfo
	 * @throws Exception
	 */
	private void testFtrOrdersCancle(OrOrderFtrsBasVo ordInfo) throws Exception {
		String orderNo = ordInfo.getOrderNo();
		OrOrderFtrsBasVo param = new OrOrderFtrsBasVo();
		param.setOrderNo(orderNo);
		param.setRspnsFtrsSttusCode("10");  //완료건
		List<OrOrderFtrsBasVo> cancelData = ftrsMapper.selectTestOrOrderFtrsBasList(param);

		int sendCnt = 0;
		for(OrOrderFtrsBasVo cancelVo : cancelData) {

			ordInfo.setFtrsRequstOrderNo(procService.getTestFtrsReqOrderNo());

			String requstOrderQy = cancelVo.getRequstOrderQy();
			String rspnsFtrsCnclsQy = cancelVo.getRspnsFtrsCnclsQy();
			if(rspnsFtrsCnclsQy==null || "".equals(rspnsFtrsCnclsQy.trim())){
				rspnsFtrsCnclsQy = "0";
			}

			String a = new BigDecimal(requstOrderQy).subtract(new BigDecimal(rspnsFtrsCnclsQy)).toString();

			ordInfo.setOrderNo(orderNo);
			ordInfo.setOrderSn("001");
			ordInfo.setRequstAcnutNo(cancelVo.getRequstAcnutNo());
			ordInfo.setRequstFtrsOrderTyCode("20");

			ordInfo.setRequstFtrsItemCode(cancelVo.getRequstFtrsItemCode());
			ordInfo.setRequstOrderUntpc(cancelVo.getRequstOrderUntpc());
			ordInfo.setRequstPostn(cancelVo.getRequstPostn());

			ordInfo.setRequstOrderQy(a);                                             // 요청 주문 수량
			ordInfo.setRequstWonOrderNo(cancelVo.getFtrsRequstOrderNo());            //요청 원 주문 번호

			ordInfo.setRequstCanclFtrsOrderNo(cancelVo.getRspnsFtrsOrderNo());		 //취소 선물 주문 번호
			ordInfo.setFtrsprofsSeCode(cancelVo.getRequstFtrsCmpnySeCode());         //요청 선물사 구분 코드(TCODE)
			ordInfo.setFtrsCmpnyTrgetCode(cancelVo.getRequstFtrsCmpnyTrgetCode());   //요청 선물사 대상 코드

			ftrsMapper.insertTestDataFtrsNewOrder(ordInfo);

			sendCnt++;
		}

		OrOrderFtrsBasVo param2 = new OrOrderFtrsBasVo();
		param2.setOrderNo(orderNo);
		orderService.saveFtrsCancelOrder(param2);

		int count = 0;
		int resultWaitSecond = 2;
		boolean success = false;

		OrOrderFtrsBasVo param3 = new OrOrderFtrsBasVo();
		param3.setOrderNo(orderNo);
		param3.setRequstFtrsOrderTyCode("10"); //주문건
		param3.setRspnsFtrsSttusCode("50");    //취소 완료건

		while (true) {
			count++;
			Thread.sleep(500L);
			List<OrOrderFtrsBasVo> list = ftrsMapper.selectTestOrOrderFtrsBasList(param3);
			if(list.size() == sendCnt) {
				success = true;
				break;
			}

			if(count/2 >= resultWaitSecond) {
				break;
			}
		}

		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		log.info(">>>>>>>>>>>>>>>>>>>> orderNo : " + orderNo    +">>>>>>>>>>>>>");
		log.info(">>>>>>>>>>>>>>>>>>>> msgType : F >>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		log.info(">>>>>>>>>>>>>>>>>>>> send result :" + success + ">>>>>>>>>>>>");
		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
	}

	/**
	 * 테스트 삼성선물 신규 주문
	 * @param ordInfo
	 * @throws Exception
	 */
	private void testExecuteFtrsNewOrder(char side, OrOrderFtrsBasVo ordInfo) throws Exception {

		ordInfo.setRequstFtrsOrderTyCode(FtrsConst.FIX_ORDER_NEW); /* 신규 주문 코드 등록 */

		List<OrOrderFtrsBasVo> resultList = ftrsMapper.selectOrderFtrsList(ordInfo);
		if (CollectionUtils.isEmpty(resultList)) {
			log.error("선물 신규 매수 주문 정보가 존재하지 않습니다. 주문 번호 :{}", ordInfo.getOrderNo());
			throw new Exception("선물 신규 매수 주문 정보가 존재하지 않습니다. [수신 주문번호 : " + ordInfo.getOrderNo() + "]");
		}

		try {
			List<FtrsOrderRequstVo> list = new ArrayList<FtrsOrderRequstVo>();

			/**
             * 선물 거래 금속 코드 목록 조회
             * 1. MAIN_CODE가 "REQUST_FTRS_ITEM_CODE"인 공통 코드
             * */
			CommCodeVo commCodeVo = new CommCodeVo();
			commCodeVo.setMainCode("REQUST_FTRS_ITEM_CODE");
			List<CommCodeVo> commCodeList = ftrsMapper.selectListCoCmmnCd(commCodeVo);

			for (OrOrderFtrsBasVo ftrsBasData : resultList) {
				String ftrsRequstOrderNo = ftrsBasData.getFtrsRequstOrderNo();
				String orderTpCode = ftrsBasData.getRequstFtrsOrderTyCode();  //요청 선물 주문 타입 코드: 10: 주문, 20: 취소

				if(!"10".equals(orderTpCode)) {
					log.error("선물 신규 매수 주문 대상이 아닙니다. 요청 선물 주문 타입 코드[{}], 선물 요청 주문 번호[{}]", orderTpCode, ftrsRequstOrderNo);
					continue;
				}

	            FtrsOrderRequstVo fixVo = procService.checkFtrsNewOrder(side, FtrsConst.SEND_MSG_TYPE_OR, commCodeList, ftrsBasData);
	            if(fixVo != null) {
	            	list.add(fixVo);
					log.debug("++++++++++++++++++++++++++++++++++++");
					log.debug("[" + fixVo + "]");
	            }
			}

			//삼성선물 전송
			if (!CollectionUtils.isEmpty(list)) {
				List<FtrsOrderRequstVo> sendResultList = fixDataOrderExecutor.doSendData(list);

				//실패시 상태코드 수정
				if(!CollectionUtils.isEmpty(sendResultList)) {
					procService.updateFtrsOrderSendResult(sendResultList);
				}else {
					procService.updateFtrsOrderSendResult(list);
				}
			}
		}catch(FtrsBizException fe) {
			log.error("FtrsBizException", fe);
		}catch(Exception e) {
			log.error("Exception", e);
			throw e;
		}
	}

	/**
	 * claim test
	 */
	@Override
	public void testFtrsNewClaim(OrOrderFtrsBasVo cncOrdInfo) throws FtrsBizException, Exception {
		String orderTyCode = cncOrdInfo.getRequstFtrsOrderTyCode();
		if(orderTyCode.equals("10")) {
			testClaimOrder(cncOrdInfo);
		}
		else if(orderTyCode.equals("20")) {
			testCancleClaimOrder(cncOrdInfo);
		}
	}

	private void testClaimOrder(OrOrderFtrsBasVo ordInfo) throws Exception {
		/*
		 * 주문성공한 선물 요청 주문 List 조회
		 */
		ordInfo.setRspnsFtrsSttusCode("30");
		List<OrOrderFtrsBasVo> ordlist = ftrsMapper.selectTestOrOrderFtrsBasList(ordInfo);

		if(ordlist.size() == 0) {
			log.error("주문 대상 미존재");
			return;
		}

		String canclExchngRtngudNo  = procService.getTestOrderNo();
		String ftrsCmpnyTrgetCode = ordInfo.getFtrsCmpnyTrgetCode();
		ordInfo.setOrderNo("00000000-000000");
		ordInfo.setOrderSn("000");
		ordInfo.setCanclExchngRtngudNo(canclExchngRtngudNo);
		ordInfo.setCanclExchngRtngudSn("001");

		int orderQy = 0;
		for (OrOrderFtrsBasVo data : ordlist) {

			String tmpMaxReqNo = procService.getTestFtrsReqOrderNo();
			ordInfo.setFtrsRequstOrderNo(tmpMaxReqNo); // 선물요청번호
			ordInfo.setFrstFtrsRequstOrderNo(tmpMaxReqNo); // 최초선물요청주문번호
			ordInfo.setRequstAcnutNo(encryptAcnuntNo(ftrsCmpnyTrgetCode)); // 계좌
			ordInfo.setRequstOrderQy("1"); // 주문수량
			ordInfo.setRequstFtrsItemCode(data.getRequstFtrsItemCode()); // 금속코드 설정
			ordInfo.setRspnsFtrsSttusCode(null);
			ordInfo.setRequstLqdOrderAt('O'); // 청산주문여부 (신규주문 'O', 청산주문'C', 미매도매수주문 ‘N’) 설정

			//Claim 주문을 위한 대상 청산 번호 청산 번호
			OrOrderFtrsDtlVo tpmSerchVo = new OrOrderFtrsDtlVo();
			tpmSerchVo.setFtrsRequstOrderNo(data.getFtrsRequstOrderNo());
			tpmSerchVo.setPostn("1");                   //매수 데이터
			tpmSerchVo.setExecutTy("F");                //Trade 데이터
			tpmSerchVo.setOrderSttus("2");              //Filled 데이터
			List<OrOrderFtrsDtlVo> orderDtlList = ftrsMapper.selectOrOrderFtrsDtlList(tpmSerchVo);

			if (CollectionUtils.isEmpty(orderDtlList)) {
				log.error("선물 주문 상세 데이터 미존재, 선물요청주문번호 : {}", data.getFtrsRequstOrderNo());
				continue;
			}

			// TODO 진입 주문 케이스 추가로 청산번호 컬럼에 만기일자 들어가는 경우로 분기가 필요한지 확인 중
			//청산번호 채우기
			if (orderDtlList.size() == 1) { // 만기조정전
				OrOrderFtrsDtlVo dtlVo = orderDtlList.get(0);
				String lqdExecutId = StringUtil.trim(dtlVo.getLqdExecutId()); //청산 실행 ID

				if (StringUtil.isBlank(lqdExecutId)) {
					log.error("청산 실행 ID 미존재, 선물요청주문번호 : {}", data.getFtrsRequstOrderNo());
					continue;
				}

				String executId = StringUtil.trim(dtlVo.getExecutId());
				ordInfo.setRequstLqdPostnNo(executId); // 요청청산포지션번호 설정

			} else { // 만기조정후
				List<OrOrderFtrsDtlVo> tmpList = orderDtlList.stream()
//						.filter(t-> !StringUtil.isEmpty(StringUtil.trim(t.getExprtnExecutId())))
						.filter(t -> !StringUtil.isEmpty(StringUtil.trim(t.getRejectResn()))
								&& StringUtils.equals("Adjustment", StringUtil.trim(t.getRejectResn())))
						.collect(Collectors.toList());

				if (CollectionUtils.isEmpty(tmpList) || tmpList.size() != 1) {
					log.error("만기 데이터 확인 필요, 선물요청주문번호 : {}", data.getFtrsRequstOrderNo());
					continue;
				}

				OrOrderFtrsDtlVo dtlVo = tmpList.get(0);
				String executId = StringUtil.trim(dtlVo.getExecutId());	//청산 실행 ID
				ordInfo.setRequstLqdPostnNo(executId); // 요청청산포지션번호 설정

				// 진입주문에 대한 만기조정 후 클레임은 청산주문'C' 으로 처리된다
				if (StringUtils.equals(String.valueOf(data.getRequstLqdOrderAt()), "N")) {
					ordInfo.setRequstLqdOrderAt('C');
				}
			}

			int retInstCnt = ftrsMapper.insertTestDataFtrsNewOrder(ordInfo);
			if (retInstCnt == 1) orderQy++;
		}

		if (orderQy < 1) {
			log.error("처리할 선물 주문 데이터 미존재");
			return;
		}

		/* Claim 주문 전송 */
		OrOrderFtrsBasVo param = new OrOrderFtrsBasVo();
		param.setCanclExchngRtngudNo(canclExchngRtngudNo);

		claimOrderService.saveFtrsClaimOrderNew(param);

		/* 결과 조회 */
		int count = 0;
		int resultWaitSecond = 2;
		int rcvCnt = 0;
		boolean success = false;

		OrOrderFtrsBasVo param2 = new OrOrderFtrsBasVo();
		param2.setCanclExchngRtngudNo(canclExchngRtngudNo);
		param2.setRspnsFtrsSttusCode("30");  //완료건
		while (true) {
			count++;
			Thread.sleep(500L);

			List<OrOrderFtrsBasVo> list = ftrsMapper.selectTestOrOrderFtrsBasList(param2);
			rcvCnt = list.size();
			if(rcvCnt == orderQy) {
				success = true;
				break;
			}

			if(count/2 >= resultWaitSecond) {
				break;
			}
		}

		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		log.info(">>>>>>>>>>>>>>>>>>>> canclExchngRtngudNo : {} >>>>>>>>>>>>>>>",  canclExchngRtngudNo);
		log.info(">>>>>>>>>>>>>>>>>>>> msgType : D >>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		log.info(">>>>>>>>>>>>>>>>>>>> send result :{} >>>>>>>>>>>>>>>>>>>>>>>>", success);

	}

	private void testCancleClaimOrder(OrOrderFtrsBasVo cncOrdInfo) throws Exception {
		String ftrsCmpnyTrgetCode = cncOrdInfo.getFtrsCmpnyTrgetCode();
		String canclExchngRtngudNo  = cncOrdInfo.getCanclExchngRtngudNo();
		String canclExchngRtngudSn  = "001";
		String orderNo  			= "00000000-000000";
		String orderSn 			    = "000";

		OrOrderFtrsBasVo param = new OrOrderFtrsBasVo();
		param.setCanclExchngRtngudNo(canclExchngRtngudNo);
		param.setRspnsFtrsSttusCode("10");  //신청건
		List<OrOrderFtrsBasVo> cancelData = ftrsMapper.selectTestOrOrderFtrsBasList(param);

		int sendCnt = 0;
		for(OrOrderFtrsBasVo cancelVo : cancelData) {
			cncOrdInfo.setCanclExchngRtngudNo(canclExchngRtngudNo);
			cncOrdInfo.setCanclExchngRtngudSn(canclExchngRtngudSn);
			cncOrdInfo.setOrderNo(orderNo);
			cncOrdInfo.setOrderSn(orderSn);

			String tmpMaxReqNo = procService.getTestFtrsReqOrderNo();
			cncOrdInfo.setFtrsRequstOrderNo(tmpMaxReqNo);

			cncOrdInfo.setRequstAcnutNo(encryptAcnuntNo(ftrsCmpnyTrgetCode));
			cncOrdInfo.setRequstFtrsOrderTyCode("20");

			String requstWonOrderNo = cancelVo.getFtrsRequstOrderNo();
			cncOrdInfo.setRequstWonOrderNo(requstWonOrderNo);

			String requstCanclFtrsOrderNo = cancelVo.getRspnsFtrsOrderNo();
			cncOrdInfo.setRequstCanclFtrsOrderNo(requstCanclFtrsOrderNo);

			ftrsMapper.insertTestDataFtrsNewOrder(cncOrdInfo);
			sendCnt++;
		}

		OrOrderFtrsBasVo param2 = new OrOrderFtrsBasVo();
		param2.setCanclExchngRtngudNo(canclExchngRtngudNo);
		claimOrderService.saveFtrsClaimOrderCancel(param2);

		int count = 0;
		int resultWaitSecond = 2;

		boolean success = false;

		OrOrderFtrsBasVo param3 = new OrOrderFtrsBasVo();
		param3.setCanclExchngRtngudNo(canclExchngRtngudNo);
		param3.setRequstFtrsOrderTyCode("10"); //주문건
		param3.setRspnsFtrsSttusCode("50");    //취소 완료건

		while (true) {
			count++;
			Thread.sleep(500L);
			List<OrOrderFtrsBasVo> list = ftrsMapper.selectTestOrOrderFtrsBasList(param3);
			if(list.size() == sendCnt) {
				success = true;
				break;
			}

			if(count/2 >= resultWaitSecond) {
				break;
			}

		}

		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		log.info(">>>>>>>>>>>>>>>>>>>> canclExchngRtngudNo : {} >>>>>>>>>>>>>>>",  canclExchngRtngudNo);
		log.info(">>>>>>>>>>>>>>>>>>>> msgType : D >>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		log.info(">>>>>>>>>>>>>>>>>>>> send result :{} >>>>>>>>>>>>>>>>>>>>>>>>", success);
	}
}
