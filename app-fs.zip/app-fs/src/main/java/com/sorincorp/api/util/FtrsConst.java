package com.sorincorp.api.util;

public class FtrsConst {
	public final static String FIX_ORDER_NEW    = "10";         //Fix 신규 주문
	public final static String FIX_ORDER_CANCEL = "20";         //Fix 주문 취소

	public final static String FIX_DATE_FORMAT1 = "yyyyMMdd-HH:mm:ss";         //데이터로드 요청으로 초까지만 전송
	//이베스트 계좌 추가로 전체 body data 1byte 증가함
	//header: 50byte, body:243byte, total 길이: 293byte, 첫번째 data길이 제외한 길이: 289byte
	//public final static int DATAlOAD_ORDER_TOTAL_LEN   	= 292;
	public final static int DATAlOAD_ORDER_TOTAL_LEN   	= 293;
	public final static int DATALOAD_HEADER_LEN 		= 50;		//header 길이

	public final static int DATAlOAD_COMM_LEN   		= 46;		//header 길이에서 첫번째 data길이 position 제외한 길이
	//public final static int DATAlOAD_ORDER_DATA_LEN    	= 288;
	public final static int DATAlOAD_ORDER_DATA_LEN    	= 289;		// 이베스트증권 계좌 추가로 인해 전체 1byte 추가(2023-06-23)

	public final static String DATALOAD_SERVER_ORDER  	= "ORDER";
	public final static String DATALOAD_SERVER_RES    	= "RESPONSE";
	public final static String DATALOAD_LINK_REQ 	  	= "LINK";
	public final static String DATALOAD_LINK_OK 		= "LIOK";
	public final static String DATALOAD_POLL_REQ 		= "POLL";
	public final static String DATALOAD_POLL_OK 		= "POOK";
	public final static String DATALOAD_SESS_REQ        = "SESS";
	public final static String DATALOAD_SESS_OK         = "SEOK";

	public final static String DATALOAD_DATA_REQ 		= "DATA";
	public final static String DATALOAD_DATA_OK 		= "DAOK";
	public final static String DATALOAD_EROR 			= "EROR";

	public final static String DATALOAD_DATA_0000 		= "0000"; //정상
	public final static String DATALOAD_EROR_BZ01 		= "BZ01"; //Fix Session Disconnect(주문전달불가)
	public final static String DATALOAD_EROR_BZ02 		= "BZ02"; //Fix Msg Type 오류
	public final static String DATALOAD_EROR_BZ03 		= "BZ03";

	public final static String DATALOAD_EROR_E001 		= "E001"; //사이즈 오류
	public final static String DATALOAD_EROR_E002 		= "E002"; //메시지 타입 오류
	public final static String DATALOAD_EROR_E003 		= "E003"; //응답코드 오류
	public final static String DATALOAD_EROR_E004 		= "E004"; //기준일자 오류
	public final static String DATALOAD_EROR_E005 		= "E005"; //일련번호 오류


	public final static int DATALOAD_MSG_LT_LEN			= 4;	//메세지길이
	public final static int DATALOAD_MSE_TY_LEN 		= 4;    //메세지타입
	public final static int DATALOAD_RES_CODE_LEN 		= 4;    //응답코드
	public final static int DATALOAD_STDR_DE_LEN 		= 8;    //기준일자
	public final static int DATALOAD_SESION_SEQNO_LEN 	= 8;    //세션일련번호
	public final static int DATALOAD_FILLER_LEN 		= 22;   //필러

	/*	Field Name			Data Size				Comments											Tag	*/
	/*	--------------------------------------------------------------------------------------------------- */
	/*	MsgType				char(1)					D= New Order										35	*/
	/*												F= Order Cancel Request0		*/
	/*												G= Order Cancel/Replace Request	*/
	/*	SenderCompID		char(20)				SORIN_UAT (개발)										49	*/
	/*	TargetCompID		char(20)				SSF_UAT (개발)										56	*/
	/*	DeliverToCompID		char(20)				현재는 사용하지 않음. (HUB 사용시 필요함)						128	*/
	/*	AccountNo			char(10)				계좌번호 												1	*/
	/*	ClOrdID				char(20)				주문번호 (예:YYMMDD-xxxxx)								11	*/
	/*	HandlInst			char(1)					1= DMA												21	*/
	/*	OrderID				char(20)				삼성선물 주문번호											37	*/
	/*	OrderQty			char(15)				주문수량 (수량정정 없음)									38	*/
	/*	OrdType				char(1)					2=Limit   4=Stop Limit								40	*/
	/*	OrigClOrdID			char(20)				원주문번호 (정정/취소 시 필요함)								41	*/
	/*	Price				char(15)				주문단가												44	*/
	/*	Side				char(1)					1= Buy   2= Sell									54	*/
	/*	Symbol				char(12)																	55	*/
	/*	TransactTime		char(21)				20200527-00:17:47.000 (KST)							60	*/
	/*	StopPx				char(15)																	99	*/
	/*	SecurityType		char(3)					FUT													167	*/
	/*	SecurityExchange	char(3)					LME													207	*/
	/*	Currency			char(3)					USD													15	*/

	public final static char SEND_MSG_TYPE_OR       	= 'D';  /* Order */
	public final static char SEND_MSG_TYPE_CR        	= 'F';  /* Order Cancel Request */
	public final static char SEND_MSG_TYPE_TO        	= 'T';  /* Test Order(회선 검증) */

	public final static char SEND_HANDLINST_DMA        = '1';
	public final static char SEND_ORDER_TYPE_LIMIT     = '2';
	public final static char SEND_ORDER_TYPE_STOP_LIMIT= '4';

//	public final static String SEND_SYMBOL_SAMSUNG_M03  = "M03"; --> CO_CMMN_CD 테이블에서 관리로 변경
//	public final static String SEND_SYMBOL_EBEST_L3M    = "L3M";

	public final static String SEND_SECURITY_TYPE		= "FUT";
	public final static String SEND_SECURITY_EXCHANGE	= "LME";
	public final static String SEND_CURRENCY			= "USD";

	public final static int SEND_MSG_TYPE_LEN 			=		1;
	public final static int SEND_SENDER_COMPID_LEN 		=		20;
	public final static int SEND_TARGET_COMPID_LEN 		=		20;
	public final static int SEND_DELIVER_TO_COMPID_LEN 	=		20;
	//public final static int SEND_ACCOUNT_NO_LEN 		=		10;
	public final static int SEND_ACCOUNT_NO_LEN 		=		11; // 이베스트증권 계좌 추가로 1byte 추가(2023-06-23)
	public final static int SEND_CL_ORDID_LEN 			=		20;
	public final static int SEND_HANDL_INST_LEN 		=		1;
	public final static int SEND_ORDER_ID_LEN 			=		20;
	public final static int SEND_ORDER_QTY_LEN 			=		15;
	public final static int SEND_ORD_TYPE_LEN 			=		1;
	public final static int SEND_ORIG_CL_ORDID_LEN 		=		20;
	public final static int SEND_PRICE_LEN 				=		15;
	public final static int SEND_SIDE_LEN 				=		1;
	public final static int SEND_SYMBOL_LEN 			=		12;
	public final static int SEND_TRANSACT_TIME_LEN 		=		21;
	public final static int SEND_STOP_PX_LEN 			=		15;
	public final static int SEND_SECURITY_TYPE_LEN 		=		3;
	public final static int SEND_SECURITY_EXCHANGE_LEN 	=		3;
	public final static int SEND_CURRENCY_LEN 			=		3;

	/* 청산 추가 */
	public final static int SEND_POSITION_EFFECT_LEN 	=		1;
	public final static int SEND_POSITION_NUM_LEN 		=		20;


	/* Fix Reponse */
	/*	Field Name			Data Size				Comments											Tag	*/
	/*	--------------------------------------------------------------------------------------------------- */
	/*	MsgType				char(1)					8= Execution Report									35	*/
	/*												9= Order Cancel Reject		*/
	/*												j= Business Reject			*/
	/*												3= Session Reject			*/
	/*	SenderCompID		char(20)				SSF_UAT (개발)										49	*/
	/*	TargetCompID		char(20)				SORIN_UAT (개발)										56	*/
	/*	OnBehalfOfCompID	char(20)				현재는 사용하지 않음. (HUB 사용시 필요함)						115	*/
	/*	Account				char(10)																	1	*/
	/*	AvgPx				char(15)				평균단가												6	*/
	/*	ClOrdID				char(20)																	11	*/
	/*	CumQty				char(15)				누적체결수량											14	*/
	/*	ExecID				char(20)				Unique identifier of execution message as assigned by sell-side.	17	*/
	/*			 									※ 체결 중복 확인 시 필요. (증권사별 관리)		*/
	/*	LastPx				char(15)				체결단가												31	*/
	/*	LastShares			char(15)				체결수량												32	*/
	/*	OrderID				char(20)				삼성선물 주문번호											37	*/
	/*	OrderQty			char(15)				주문수량												38	*/
	/*	OrdStatus			char(1)					A= Pending New										39	*/
	/*												0= New 		*/
	/*												1= Partially filled		*/
	/*												2= Filled		*/
	/*												4= Canceled		*/
	/*												5=Replaced		*/
	/*												6= Pending Cancel (e.g. result of Order Cancel Request)	*/
	/*												E= Pending Replace (e.g. result of Order Cancel/Replace Request)	*/
	/*	OrdType				char(1)					2=Limit   4=Stop Limit 	4							0	*/
	/*	OrigClOrdID			char(20)																	41	*/
	/*	Price				char(15)				주문 단가												44	*/
	/*	Side				char(1)	1= Buy  2= Sell  													54	*/
	/*	Symbol				char(12)				종목코드 												55	*/
	/*	Text				char(200)				거부 사유												58	*/
	/*	TransactTime		char(21)				20200527-00:17:47.000 (KST)							60	*/
	/*	StopPx				char(15)																	99	*/
	/*	ExecType			char(1)					A= Pending New										150	*/
	/*												0= New 		*/
	/*												4= Canceled		*/
	/*												5= Replaced		*/
	/*												6= Pending Cancel (e.g. result of Order Cancel Request)		*/
	/*												8= Rejected 		*/
	/*												C= Expired (like 수작업 취소)		*/
	/*												E= Pending Replace (e.g. result of Order Cancel/Replace Request)		*/
	/*												F= Trade 		*/
	/*	LeavesQty			char(15)				잔량 (취소 완료시=0)										151	*/
	/*	SecurityType		char(3)					FUT													167	*/
	/*	SecurityExchange	char(3)					LME													207	*/
	/*	MaturityDate	char(8)	Specifies date of maturity (a full date). Last Trading Day of Market.	541	*/

	public final static char RCV_MSG_TYPE_EXECUTION_REPORT			=		'8';
	public final static char RCV_MSG_TYPE_ORDER_CANCEL_REJECT 		=		'9';
	public final static char RCV_MSG_TYPE_BUSINESS_REJECT 			=		'j';
	public final static char RCV_MSG_TYPE_SESSION_REJECT 			=		'3';

	public final static char RCV_ORD_STATUS_PENDING_NEW 			=		'A';
	public final static char RCV_ORD_STATUS_NEW 					=		'0';
	public final static char RCV_ORD_STATUS_PARTIALLY_FILLED 		=		'1';
	public final static char RCV_ORD_STATUS_FILLED 					=		'2';
	public final static char RCV_ORD_STATUS_CANCELED 				=		'4';
	public final static char RCV_ORD_STATUS_REJECTED  				=		'8';
	public final static char RCV_ORD_STATUS_PENDING_CANCEL  		=		'6';
	public final static char RCV_ORD_STATUS_EXPIRED  				=		'C';

	public final static char RCV_EXEC_TYPE_PENDING_NEW 				=		'A';
	public final static char RCV_EXEC_TYPE_PENDING 					=		'0';
	public final static char RCV_EXEC_TYPE_CANCELED  				=		'4';
	public final static char RCV_EXEC_TYPE_PENDING_CANCELED			=		'6';
	public final static char RCV_EXEC_TYPE_REJECTED  				=		'8';
	public final static char RCV_EXEC_TYPE_EXPIRED					=		'C';
	public final static char RCV_EXEC_TYPE_TRADE					=		'F';

	public final static int RCV_MSG_TYPE_LEN 				=		 1;
	public final static int RCV_SENDER_COMPID_LEN 			=		20;
	public final static int RCV_TARGET_COMPID_LEN 			=		20;
	public final static int RCV_ON_BEHALF_OF_COMPID_LEN 	=		20;
//	public final static int RCV_ACCOUNT_LEN 				=		10;
	public final static int RCV_ACCOUNT_LEN 				=		11;	//선물사 다중화로 이베스트 증권 추가하여 1BYTE 증가
	public final static int RCV_AVG_PX_LEN 					=		15;
	public final static int RCV_CL_ORDID_LEN 				=		20;
	public final static int RCV_CUM_QTY_LEN 				=		15;
	public final static int RCV_EXECID_LEN 					=		20;
	public final static int RCV_LAST_PX_LEN 				=		15;
	public final static int RCV_LAST_SHARES_LEN 			=		15;
	public final static int RCV_ORDERID_LEN 				=		20;
	public final static int RCV_ORDER_QTY_LEN 				=		15;
	public final static int RCV_ORD_STATUS_LEN 				=		 1;
	public final static int RCV_ORD_TYPE_LEN 				=		 1;
	public final static int RCV_ORIG_CL_ORDID_LEN 			=		20;
	public final static int RCV_PRICE_LEN 					=		15;
	public final static int RCV_SIDE_LEN 					=		 1;
	public final static int RCV_SYMBOL_LEN 					=		12;
	public final static int RCV_TEXT_LEN 					=	   200;
	public final static int RCV_TRANSACT_TIME_LEN 			=		21;
	public final static int RCV_STOP_PX_LEN					= 		15;
	public final static int RCV_EXEC_TYPE_LEN				= 		 1;
	public final static int RCV_LEAVES_QTY_LEN				= 		15;
	public final static int RCV_SECURITY_TYPE_LEN			= 		 3;
	public final static int RCV_SECURITY_EXCHANGE_LEN		= 		 3;
	public final static int RCV_MATURITY_DATE_LEN	   		= 		 8;
	public final static int RCV_POSITION_NUM_LEN	   		= 	    20;
	public final static int RCV_EXPIRED_ID_LEN				= 	    20;

	public final static int RCV_COMMITION_LEN				= 	    15;	// 위탁 수수료
	public final static int RCV_COMMITION2_LEN				= 	    15; // LME Fee
	public final static int RCV_SPREAD_LEN					= 	    15;
}
