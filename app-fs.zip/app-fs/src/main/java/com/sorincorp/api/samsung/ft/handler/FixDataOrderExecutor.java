package com.sorincorp.api.samsung.ft.handler;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.api.samsung.ft.model.FtrsOrderRequstVo;
import com.sorincorp.api.samsung.ft.service.FtrsProcessService;
import com.sorincorp.api.samsung.ft.socket.FixCnncHandler;
import com.sorincorp.api.samsung.ft.socket.FtrsOrderSender;
import com.sorincorp.api.samsung.service.FtrsStateMonitorIsSaleTime;
import com.sorincorp.api.util.FtrsCmmnConst;
import com.sorincorp.api.util.FtrsConst;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class FixDataOrderExecutor {

	private static final AtomicInteger dailySendDataOkCount = new AtomicInteger(0);
	private static final String format = "%08d";
	private static final String SYSTEM_USER = "system";
	private FixCnncHandler fixCnncHandler;
	private FtrsStateMonitorIsSaleTime ftrsStateMonitorIsSaleTime;

	@Autowired
	private FtrsProcessService processService;

	public FixDataOrderExecutor(FtrsStateMonitorIsSaleTime ftrsStateMonitorIsSaleTime) {
		this.ftrsStateMonitorIsSaleTime = ftrsStateMonitorIsSaleTime;
	}

	/**
	 * <pre>
	 * 처리내용: DataLoad와 Sequence 맞추기 위해 매일 아침 또는 서버 Start시 초기화한다.
	 * </pre>
	 * @date 2021. 9. 13.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 13.			srec0032			최초작성
	 * ------------------------------------------------
	 */
	@PostConstruct
	public void initDailySendDataOkCount() {
		try {
			if(FtrsCmmnConst.isInitDailySendDataOkCount)
				return;

			log.info("Send-Seq-Number start sync job");

			int maxNumber    = processService.selectIfFtrsOrderSeqNumber();
			dailySendDataOkCount.set(maxNumber);

			FtrsCmmnConst.isInitDailySendDataOkCount = true;
			log.info("Send-Seq-Number end sync job(" + maxNumber + "번)");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Data Load와 Sequence 문제로 RollBack 되지 않고 실행되는 데로 저장 되게 합니다.
	 * Data Sequence 증가시키는 업무만 사용하는 메소드임.
	 */
	public synchronized List<FtrsOrderRequstVo> doSendData(List<FtrsOrderRequstVo> requestDataVoList) {
		if (fixCnncHandler == null) {
			fixCnncHandler = FixCnncHandler.getInstance();
		}

		List<FtrsOrderRequstVo> sendReultVoList = new ArrayList<>();
		FtrsOrderSender sender = fixCnncHandler.getSender();
		if (sender == null) {
			log.error("===> FixDataOrderExecutor sender is null!");
			return sendReultVoList;
		}

		for (FtrsOrderRequstVo requstData : requestDataVoList) {
			try {
				byte[] bytes = getFixSendByteData(requstData);
				FtrsOrderRequstVo rcvDataVo = sender.sendFixOrderData(bytes);

				if (rcvDataVo != null) {
					requstData.setResHeaderBodyLength(rcvDataVo.getResHeaderBodyLength());
					requstData.setResHeaderMessageType(rcvDataVo.getResHeaderMessageType ());
					requstData.setResHeaderResponseCode(rcvDataVo.getResHeaderResponseCode());
					requstData.setResHeaderTradeDate(rcvDataVo.getResHeaderTradeDate());
					requstData.setResHeaderSequenceNumber(rcvDataVo.getResHeaderSequenceNumber());
					requstData.setResHeaderFilter(rcvDataVo.getResHeaderFilter());

					/*  DATA LOAD와 연결 Seq Num 증가  */
					if (FtrsConst.DATALOAD_DATA_OK.equals(rcvDataVo.getResHeaderMessageType ())) {
						int curcnt = dailySendDataOkCount.incrementAndGet();
						log.info("Seq Num = {}", curcnt);
					}
				}
			} catch (Exception e) {
				log.error("FixDataOrderExecutor Message:", e);
			}

			try {
				/* 전송 및 응답 데이터 */
				String encAccountNo = CryptoUtil.encryptAES256(requstData.getAccountNo());	//계좌번호 암호화
				requstData.setAccountNo(encAccountNo);
				processService.insertIfFtrsOrderRequstData(requstData);
			} catch (Exception e) {
				log.error("FixDataOrderExecutor Insert Message:", e);
			}

			sendReultVoList.add(requstData);
		}

		return sendReultVoList;
	}

	private byte[] getFixSendByteData(FtrsOrderRequstVo fixOrder) throws Exception{
		int maxNumber = 0;
		try {
			fixOrder.setFrstRegisterId(SYSTEM_USER);
			fixOrder.setLastChangerId(SYSTEM_USER);
			fixOrder.setTransactTime(DateUtil.calDate(FtrsConst.FIX_DATE_FORMAT1)); // BZ03 오류로 거래시간을 전문 보내기 전 시간으로 설정 23.06.20

			maxNumber    = dailySendDataOkCount.get() + 1;
			String strNumber = String.format(format, maxNumber);
			fixOrder.setSequenceNumber(strNumber);

			/* 전송 하기전 요청 전문을 만든다. */
			fixOrder.makeRequstSpcltyTxt();

			return fixOrder.getOrderByte();
		}catch(Exception e) {
			log.error("GetFixSendByteData Error:", e);
			throw e;
		}
	}

	public FtrsOrderRequstVo getRequestLinkData(String headerType) {
		FtrsOrderRequstVo header = null;
		try {
			String strNumber     = String.format(format, dailySendDataOkCount.get());
			String strOrdBodyLen = StringUtil.padValue(String.valueOf(FtrsConst.DATAlOAD_COMM_LEN), "0", 4, true);

			header = new FtrsOrderRequstVo();
			header.setDataLength(strOrdBodyLen);
			header.setHeaderType(headerType);
			header.setTradeDate(ftrsStateMonitorIsSaleTime.getTradeDate());
			header.setFrstRegisterId(SYSTEM_USER);
			header.setLastChangerId(SYSTEM_USER);
			header.setSequenceNumber(strNumber);

		} catch (Exception e) {
			log.error("FixDataOrderExecutor Message:", e);
		}

		return header;
	}
}
