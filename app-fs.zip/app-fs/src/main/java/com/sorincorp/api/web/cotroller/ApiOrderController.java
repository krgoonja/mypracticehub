package com.sorincorp.api.web.cotroller;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jettison.json.JSONObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;


/**
 * ApiOrderController.java
 * @version
 * @since 2021. 6. 4.
 * @author srec0032
 */
@Slf4j
@RestController
@RequestMapping(value = "/order")
public class ApiOrderController {

	//아직 사용 방법이 결정 안됨. Client 요청이나 Server 자체적으로 환율 초기 정보를 설정할지????
	@GetMapping("/dealingEhgt/execute/{orderNo}")
	@ResponseBody
    public String executeDealingEhgt( @PathVariable String orderNo, HttpServletRequest request ) throws Exception {
		log.info("execute ######################" +  orderNo);
        JSONObject json = new JSONObject();
        json.put("success", true);
        json.put("data", 10);

        return json.toString(4);
    }
}
