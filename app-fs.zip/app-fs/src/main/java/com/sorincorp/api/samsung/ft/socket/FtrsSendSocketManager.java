package com.sorincorp.api.samsung.ft.socket;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.Iterator;

import com.sorincorp.api.util.BeanUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FtrsSendSocketManager extends Thread {
	private FixServiceIf service;
	private boolean run;
	private String address;
	private int port;
	private int initCount;
	private ArrayList socketList;
	private String name;

	public FtrsSendSocketManager(FixServiceIf _svcImpl) {
		this.service = _svcImpl;
		this.socketList = new ArrayList();
		this.initCount = 1;
		this.run = true;

		this.address = BeanUtils.getProperty("samsung.tcp.ip", "127.0.0.1");
		this.port 	 = Integer.valueOf(BeanUtils.getProperty("samsung.tcp.ftrs.send-port", "28091"));
		this.name = "SORIN-FtrsSendSocketManager@R=" + address + ":" + port;

		setName(this.name);
		setDaemon(true);

		log.info("[{}] start..", this.name);
	}

	public void setRun(boolean run) {
		this.run = run;
	}

	public void run() {
		Socket socket = null;
		while (this.run) {
			try {
				if (this.socketList.size() >= this.initCount) {
					Iterator _skItor = this.socketList.iterator();
					while (_skItor.hasNext()) {
						WeakReference _ref = (WeakReference) _skItor.next();
						if (_ref == null) {
							_skItor.remove();
						} else {
							Socket _sk = (Socket) _ref.get();
							if ((_sk == null) || (_sk.isClosed())) {
								_skItor.remove();
							}
						}
					}
				} else {
					try {
						SocketAddress socketAddress = new InetSocketAddress(this.address, this.port);
						socket = new Socket();
						socket.connect(socketAddress, 10000);

						this.service.startRequestService(socket);
						this.socketList.add(new WeakReference(socket));
					} catch (IOException e) {
						if (socket != null) try { socket.close(); } catch (IOException ea1) {}
						socket = null;
						log.error("[SendSocket Error]", e);
					}
				}

				sleep(5000L);
			} catch (InterruptedException e) {
				setRun(false);
				log.error("[{}] InterruptedException:{}", this.name, e.getMessage());
			} catch (Throwable t){
				log.error("[{}] Exception:{}", this.name, t.getMessage());
			}
		}

		this.cmdSocketListClose();
		log.info("[{}] is Terminated!!!", this.name);
	}

	public synchronized void cmdSocketListClose(){
		try{
			int sockets = this.socketList.size();
			if (sockets > 0) {
				Iterator _skItr = this.socketList.iterator();
				while (_skItr.hasNext()) {
					WeakReference _ref = (WeakReference) _skItr.next();
					if(_ref != null){
						Socket _sk = (Socket) _ref.get();
						if(_sk != null && !_sk.isClosed()) {
							try {
								_sk.close();
								_skItr.remove();
							} catch (Exception e) {}
						}
					}
				}
			}
			setRun(false);
		}catch(Exception e){}
	}
}