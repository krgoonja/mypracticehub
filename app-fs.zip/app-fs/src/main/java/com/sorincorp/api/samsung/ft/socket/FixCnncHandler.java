package com.sorincorp.api.samsung.ft.socket;

import java.lang.ref.WeakReference;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.sorincorp.api.samsung.ft.handler.FtrsReceptProcHandler;
import com.sorincorp.api.samsung.ft.model.FtrsOrderRspnsVo;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FixCnncHandler implements FixServiceIf {
	private static FixCnncHandler fixCnncHandler;
	private FtrsReceptProcHandler fixRcvProcess;
	private FtrsSendSocketManager senderSMaker = null;
	private ArrayList<WeakReference> senderList = null;

	private FtrsReceptSocketManager receiverRMaker = null;
	private ArrayList<WeakReference> receiverList = null;

	private boolean orderLink;

	private long receiveTime = 0l;

	public static synchronized FixCnncHandler getInstance() {
		if (fixCnncHandler == null){
			fixCnncHandler = new FixCnncHandler();
		}

		return fixCnncHandler;
	}

	private FixCnncHandler() {
		receiverList 	= new ArrayList();
		senderList 		= new ArrayList();

		if(fixRcvProcess == null) {
			fixRcvProcess = FtrsReceptProcHandler.getInstance();
			fixRcvProcess.start();
		}
	}

	public void addRcvData(FtrsOrderRspnsVo vo) {
		try {
			fixRcvProcess.add(vo);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void createFixSenderRequester() {
		if (senderSMaker == null || !senderSMaker.isAlive()) {
			if(senderSMaker != null && !senderSMaker.isAlive())
				senderSMaker.cmdSocketListClose();

			senderSMaker = new FtrsSendSocketManager(this);
			senderSMaker.start();
		}
	}

	public void createFixReceiverRequester() {
		try {
			if (receiverRMaker == null || !receiverRMaker.isAlive()) {
				if(receiverRMaker != null && !receiverRMaker.isAlive())
					receiverRMaker.cmdSocketListClose();

				receiverRMaker = new FtrsReceptSocketManager(this);
				receiverRMaker.start();
			}
		}catch(Exception e) {
			log.error("[FixCnncHandler createFixReceiverRequester]", e);
		}
	}

	public void startRequestService(Socket _socket) {
		FtrsOrderSender orderSender = null;
		try {
			FixSocketWrapper socketWrapper = new FixSocketWrapper(_socket, "utf-8", "utf-8");
			socketWrapper.setTimeOut(5000L);
			String name = socketWrapper.getSocketWrapName("SORIN-FtrsOrderSender@R=");

			orderSender = new FtrsOrderSender(this, name, socketWrapper);
			orderSender.start();

			Thread.sleep(100L);

			synchronized (this.senderList) {
				this.senderList.add(new WeakReference(orderSender));
			}

		} catch (Exception e) {
			log.error("[FixCnncHandler startOrderSenderService] {}", e.getMessage());
			if(orderSender != null) try { orderSender.close(); }catch(Exception e1) {}
		}
	}

	public void startResponseService(Socket _socket) {
		FtrsOrderReceiver orderReceiver  = null;

		try {
			FixSocketWrapper socketWrapper = new FixSocketWrapper(_socket, "utf-8", "utf-8");
			socketWrapper.setTimeOut(5000L);
			String name = socketWrapper.getSocketWrapName("SORIN-FtrsOrderReceiver@R=");

			orderReceiver = new FtrsOrderReceiver(this, name, socketWrapper);
			orderReceiver.start();

			synchronized (this.receiverList) {
				this.receiverList.add(new WeakReference(orderReceiver));
			}

			orderReceiver.sendResponseLinkData();
		} catch (Exception e) {
			log.error("[FixCnncHandler startOneWaySenderService] {}", e.getMessage());
			if(orderReceiver != null) try{ orderReceiver.close(); }catch(Exception ex) {}
		}
	}

	public void checkFixReceiverThreads() {
		try {
			synchronized (this.receiverList) {
				Iterator itr = this.receiverList.iterator();
				while (itr.hasNext()) {
					FtrsOrderReceiver receiver = (FtrsOrderReceiver) ((WeakReference) itr.next()).get();
					if ((receiver == null) || (!receiver.isAlive())) {
						if(receiver != null) receiver.close();

						receiver = null;
						itr.remove();
					} else {
						FixSocketWrapper comunicator = receiver.getTcpCommunicator();
						if( comunicator==null || comunicator.isCosed() ){
							receiver.setRun(false);
							receiver.interrupt();
							continue;
						}
					}
				}
			}
		}catch(Exception e) {
			log.error("[FixCnncHandler checkTwoWaySenderThreads] {}", e.getMessage());
		}
	}

	public void checkFixSenderThreads() {
		try{
			synchronized (this.senderList) {
				Iterator itr = this.senderList.iterator();
				while (itr.hasNext()) {
					FtrsOrderSender orderSender = (FtrsOrderSender) ((WeakReference) itr.next()).get();
					if ((orderSender == null) || (!orderSender.isAlive())) {
						if(orderSender != null)
							orderSender.close();

						orderSender = null;
						itr.remove();
					} else {
						FixSocketWrapper comunicator = orderSender.getTcpCommunicator();
						if( comunicator==null || comunicator.isCosed() ){
							orderSender.setRun(false);
							orderSender.interrupt();
							continue;
						}
					}
				}
			}
		}catch(Exception e){
			log.error("[FixCnncHandler checkTwoWaySenderThreads] {}", e.getMessage());
		}
	}

	public FtrsOrderSender getSender(){
		try{
			int senderCnt = senderList.size();
			if(senderCnt > 0){
				boolean result = false;
				for(int i=0; i<senderCnt; i++) {
					WeakReference ref 			= (WeakReference)senderList.get(i);
					FtrsOrderSender sender 	    = (FtrsOrderSender)ref.get();
					if(sender != null && sender.getTcpCommunicator() != null){
						return sender;
					}
				}
			}
		}catch(Exception e){
			log.error("[FixCnncHandler getSender]", e);
		}

		return null;
	}

	public void sendToReceiveData(byte[] bytes){
		try{
			if(receiverList.size() > 0){
				for(int i=0; i<receiverList.size(); i++) {
				WeakReference ref 			= (WeakReference)receiverList.get(i);
				FtrsOrderReceiver receiver 	= (FtrsOrderReceiver)ref.get();
					if(receiver != null && receiver.getTcpCommunicator() != null){
						receiver.sendData(bytes);
						break;
					}
				}
			}
		}catch(Exception e){
			log.error("[FtrsOrderSender sendToReceiveData]", e);
		}
	}

	public void closeSendWork(){
		try{
			if(senderSMaker != null && senderSMaker.isAlive()) {
				senderSMaker.cmdSocketListClose();
			}

			int sSize = senderList.size();
			if(sSize > 0){
				for(int i=0; i<sSize; i++) {
				WeakReference ref 			= (WeakReference)senderList.get(i);
				FtrsOrderSender sender 	    = (FtrsOrderSender)ref.get();
					if(sender != null && sender.getTcpCommunicator() != null){
						sender.close();
					}
				}
			}
		}catch(Exception e){
			log.error("[FixCnncHandler closeSendWork]", e);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 일정 시간 데이터로드쪽에서 수신 포트로 데이터가 없으면 소켓을 끊고 null 처리한다.
	 * </pre>
	 * @date 2021. 12. 9.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 9.			srec0032			최초작성
	 * ------------------------------------------------
	 */
	public void closeRecptnWork(){
		try{
			if(receiverRMaker != null && receiverRMaker.isAlive()) {
				receiverRMaker.cmdSocketListClose();
			}

			int rSize = receiverList.size();
			if(rSize > 0){
				for(int i=0; i<rSize; i++) {
				WeakReference ref 			= (WeakReference)receiverList.get(i);
				FtrsOrderReceiver receiver 	= (FtrsOrderReceiver)ref.get();
					if(receiver != null && receiver.getTcpCommunicator() != null){
						receiver.close();
					}
				}
			}
		}catch(Exception e){
			log.error("[FixCnncHandler closeRecptnWork]", e);
		}
	}

	@Override
	public void setOrderLink(boolean bo) {
		orderLink = bo;
	}

	@Override
	public boolean isOrderLink() {
		return orderLink;
	}

	@Override
	public void setReceiveLink(boolean bo) {
		if(!bo) {
			receiverRMaker.cmdSocketListClose();
			this.createFixReceiverRequester();
		}
	}

	@Override
	public void setReceiveTime() {
		receiveTime = System.currentTimeMillis();
	}

	public long getReceiveTime() {
		return receiveTime;
	}

	public FtrsReceptSocketManager getReceiverRMaker() {
		return this.receiverRMaker;
	}

	public List<WeakReference> getReceiverList() {
		return this.receiverList;
	}
}