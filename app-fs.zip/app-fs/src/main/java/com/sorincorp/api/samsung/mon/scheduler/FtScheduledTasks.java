package com.sorincorp.api.samsung.mon.scheduler;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.sorincorp.api.samsung.ft.model.FtrsOrderRequstVo;
import com.sorincorp.api.samsung.mon.service.FsStateMonitorService;
import com.sorincorp.api.util.FtrsCmmnConst;
import com.sorincorp.api.util.FtrsConst;
import com.sorincorp.comm.cntcsttus.model.CntcSttusVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class FtScheduledTasks {

	@Value("${fix.sender-compid}")
	private String FIX_SENDER_COMPID;            //SORIN_UAT
	@Value("${fix.target-enginid}")
	private String FIX_TARGET_ENGINID;

	@Value("${fix.target-compid.samsung}")       //SSF_UAT
	private String FIX_TARGET_COMPID_SAMSUNG;
	@Value("${fix.target-compid.ebest}")       	 //EBEST_UAT - ebest증권사 추가(2023-06-23)
	private String FIX_TARGET_COMPID_EBEST;

	@Autowired
	private FsStateMonitorService stateMonitorService;

	/**
	 * 신호등은 분리하지 않기로 함
	    - 둘중 하나라도 실패하면 빨강색
		- 둘중 하나라도 실패했다가 성공하면 황색
		- 둘다 성공이 되어야 초록색
	 */
	/**
	 * 해외 LME 장 시간 종료가 새벽 3시 (썸머 타임 종료시 4시)
	 */
	@Scheduled(cron = "${samsung.service.monitor-scedule-time}")
	@Scheduled(cron = "${samsung.service.monitor-scedule-time-dawn}")
    public void executeFixClientStateCheckJob(){
    	log.info("########## Samsung Service Check Job start. FIX_SENDER_COMPID:{}, FIX_TARGET_ENGINID:{}"
    			, FIX_SENDER_COMPID, FIX_TARGET_ENGINID);

		if (!FtrsCmmnConst.EXTRLCNTCMNGR_SERVICE_INITIALIZE) {
			log.info("##  FTRS 업무시간 종료. !!!");
			return;
		}


		boolean samSungresult = false;
    	try {

    		// 삼성선물 HelthCheck
    		List<FtrsOrderRequstVo> sendSamsungRsList = stateMonitorService.checkFsServerStatus(FIX_TARGET_COMPID_SAMSUNG);

			if (!CollectionUtils.isEmpty(sendSamsungRsList)) {
				FtrsOrderRequstVo resultVo  = sendSamsungRsList.get(0);
				String resHeaderMessageType = resultVo.getResHeaderMessageType();
				String responseCode         = resultVo.getResHeaderResponseCode();

				log.info("{} WireVrify resHeaderMessageType:{}, responseCode:{}", FIX_TARGET_COMPID_SAMSUNG, resHeaderMessageType, responseCode);

				if (FtrsConst.DATALOAD_SESS_OK.equals(resHeaderMessageType)
						&& FtrsConst.DATALOAD_DATA_0000.equals(responseCode)) {
					samSungresult = true;
				}
			}
    	}catch(Exception e) {
    		log.error("삼성선물 FtScheduledTasks Error.", e);
    	}

    	boolean eBestresult = false;
    	try {
    		// 1초후에 이베스트 증권의 HelthCheck 전송한다.
			Thread.sleep(10000L);

			// 이베스트증권 HelthCheck
			List<FtrsOrderRequstVo> sendEbestRsList = stateMonitorService.checkFsServerStatus(FIX_TARGET_COMPID_EBEST);

			if (!CollectionUtils.isEmpty(sendEbestRsList)) {
				FtrsOrderRequstVo resultVo  = sendEbestRsList.get(0);
				String resHeaderMessageType = resultVo.getResHeaderMessageType();
				String responseCode         = resultVo.getResHeaderResponseCode();

				log.info("{} WireVrify resHeaderMessageType:{}, responseCode:{}", FIX_TARGET_COMPID_EBEST, resHeaderMessageType, responseCode);

				if (FtrsConst.DATALOAD_SESS_OK.equals(resHeaderMessageType)
						&& FtrsConst.DATALOAD_DATA_0000.equals(responseCode)) {
					eBestresult = true;
				}
			}
    	}catch(Exception e) {
    		log.error("이베스트증권 FtScheduledTasks Error.", e);
    	}

    	CntcSttusVO cntcSttusVO = new CntcSttusVO();
    	cntcSttusVO.setCheckCommnLine(true);          /* 통신선 체크 작업 true */

    	if(samSungresult && eBestresult) {
    		cntcSttusVO.setOpertSuccesTy(0);
    	}else if(!samSungresult && !eBestresult) {
    		cntcSttusVO.setOpertSuccesTy(1);
    	}else {
    		cntcSttusVO.setOpertSuccesTy(2);
    	}

    	boolean result = cntcSttusVO.getOpertSuccesTy()==0 ? true:false;
		cntcSttusVO.setCheckResult(result);

		stateMonitorService.checkFsWorkStatus(cntcSttusVO);

    	log.info("#################### Samsung Service Check Job end............");
    }
}
