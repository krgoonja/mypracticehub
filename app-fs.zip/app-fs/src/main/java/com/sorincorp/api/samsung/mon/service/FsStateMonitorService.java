package com.sorincorp.api.samsung.mon.service;

import java.util.List;

import com.sorincorp.api.samsung.ft.model.FtrsOrderRequstVo;
import com.sorincorp.comm.cntcsttus.model.CntcSttusVO;

public interface FsStateMonitorService {

	/**
	 * <pre>
	 * 처리내용: 데이터 로드와 삼성선물까지의 회선점검을 위한 전문을 전송한다.
	 * </pre>
	 * @date 2021. 10. 26.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 26.			srec0032			최초작성
	 * 2023. 06. 27.			srec0070			return type 수정
	 * ------------------------------------------------
	 * @param targetCompID
	 * @return
	 * @throws Exception
	 */
	List<FtrsOrderRequstVo> checkFsServerStatus(String targetCompID) throws Exception;

	/**
	 * <pre>
	 * 처리내용: Fs 선물환 주문작업 내용 상태를 모니터링한다
	 * </pre>
	 * @date 2021. 11. 22.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 22.			srec0032			최초작성
	 * 2023. 06. 27.			srec0070			메소드명 수정
	 * ------------------------------------------------
	 */
	void checkFsWorkStatus(boolean result);

	/**
	 *
	 * <pre>
	 * 처리내용: Fs 선물환 주문작업 내용 상태를 모니터링하여 CO_CNTC_STTUS_BAS(공통_연계 상태 기본) 테이블을 업데이트 한다.
	 * </pre>
	 * @date 2023. 6. 27.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 27.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param cntcSttusVO
	 */
	void checkFsWorkStatus(CntcSttusVO cntcSttusVO);
}
