package com.sorincorp.api.samsung.ft.model;

import com.sorincorp.api.util.FtrsConst;
import com.sorincorp.comm.util.StringUtil;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class FtrsOrderRequstVo extends EcMssageHeaderVo{
	private static final long serialVersionUID = -3352720727920775690L;

	char msgType;				/*	char(1)		D= New Order							Tag: 35 */
			                    /*				F= Order Cancel Request0 */
			                    /*				G= Order Cancel/Replace Request */
	String senderCompId;		/*	char(20)	SORIN_UAT (개발)							Tag: 49 */
	String targetCompId;		/*	char(20)	SSF_UAT (개발)							Tag: 56 */
	String deliverToCompId;		/*	char(20)	현재는 사용하지 않음. (HUB 사용시 필요함)			Tag: 128 */
	String accountNo;			/*	char(11)	계좌번호 									Tag: 1 */
	String clOrdId;				/*	char(20)	주문번호 (예:YYMMDD-xxxxx)					Tag: 11 */
	char handlInst;				/*	char(1)		1= DMA									Tag: 21 */
	String orderId;				/*	char(20)	삼성선물 주문번호								Tag: 37 */
	String orderQty;			/*	char(15)	주문수량 (수량정정 없음)						Tag: 38 */
	char ordType;				/*	char(1)		2=Limit   4=Stop Limit					Tag: 40 */
	String origClOrdId;			/*	char(20)	원주문번호 (정정/취소 시 필요함)					Tag: 41 */
	String price;				/*	char(15)	주문단가									Tag: 44 */
	char side;					/*	char(1)		1= Buy   2= Sell						Tag: 54 */
	String symbol;				/*	char(12)											Tag: 55 */
	String transactTime;		/*	char(21)	20200527-00:17:47.000 (KST)				Tag: 60 */
	String stopPx;				/*	char(15)											Tag: 99 */
	String securityType;		/*	char(3)		FUT										Tag: 167 */
	String securityExchange;	/*	char(3)		LME										Tag: 207 */
	String currency;			/*	char(3)		USD										Tag: 15 */
	char positionEffect;      /*  char(1)		청산주문여부 (신규주문 'O', 청산주문'C')         Tag: 77 */
	String positionNum;         /*  char(20)	청산대상 포지션번호                           Tag: 508 */
	String requstSpclty;        /*  요청전문 */

	public void makeRequstSpcltyTxt () {
		StringBuffer buffer = new StringBuffer();
		buffer.append(StringUtil.padValue(String.valueOf(msgType), 			" ", FtrsConst.SEND_MSG_TYPE_LEN, false));
		buffer.append(StringUtil.padValue(senderCompId, 	" ", FtrsConst.SEND_SENDER_COMPID_LEN, false));
		buffer.append(StringUtil.padValue(targetCompId, 	" ", FtrsConst.SEND_TARGET_COMPID_LEN, false));
		buffer.append(StringUtil.padValue(deliverToCompId, 	" ", FtrsConst.SEND_DELIVER_TO_COMPID_LEN, false));
		buffer.append(StringUtil.padValue(accountNo, 		" ", FtrsConst.SEND_ACCOUNT_NO_LEN, false));
		buffer.append(StringUtil.padValue(clOrdId,	 		" ", FtrsConst.SEND_CL_ORDID_LEN, false));
		buffer.append(StringUtil.padValue(String.valueOf(handlInst), 		" ", FtrsConst.SEND_HANDL_INST_LEN, false));
		buffer.append(StringUtil.padValue(orderId, 			" ", FtrsConst.SEND_ORDER_ID_LEN, false));
		buffer.append(StringUtil.padValue(orderQty, 		" ", FtrsConst.SEND_ORDER_QTY_LEN, false));
		buffer.append(StringUtil.padValue(String.valueOf(ordType), 			" ", FtrsConst.SEND_ORD_TYPE_LEN, false));
		buffer.append(StringUtil.padValue(origClOrdId, 		" ", FtrsConst.SEND_ORIG_CL_ORDID_LEN, false));
		buffer.append(StringUtil.padValue(price, 			" ", FtrsConst.SEND_PRICE_LEN, false));
		buffer.append(StringUtil.padValue(String.valueOf(side), 			" ", FtrsConst.SEND_SIDE_LEN, false));
		buffer.append(StringUtil.padValue(symbol, 			" ", FtrsConst.SEND_SYMBOL_LEN, false));
		buffer.append(StringUtil.padValue(transactTime, 	" ", FtrsConst.SEND_TRANSACT_TIME_LEN, false));
		buffer.append(StringUtil.padValue(stopPx, 			" ", FtrsConst.SEND_STOP_PX_LEN, false));
		buffer.append(StringUtil.padValue(securityType, 	" ", FtrsConst.SEND_SECURITY_TYPE_LEN, false));
		buffer.append(StringUtil.padValue(securityExchange, " ", FtrsConst.SEND_SECURITY_EXCHANGE_LEN, false));
		buffer.append(StringUtil.padValue(currency, 		" ", FtrsConst.SEND_CURRENCY_LEN, false));

		/* 청산 추가 */
		buffer.append(StringUtil.padValue(String.valueOf(positionEffect), 	" ", FtrsConst.SEND_POSITION_EFFECT_LEN, false));
		buffer.append(StringUtil.padValue(positionNum, 		" ", FtrsConst.SEND_POSITION_NUM_LEN, false));

		this.requstSpclty = buffer.toString();
	}

	public byte[] getOrderByte() {
		byte header_byte[] = super.getMssageHeaderByte();

		byte order_byte[] = new byte[FtrsConst.DATAlOAD_ORDER_TOTAL_LEN];  //293 byte

		int offset = 0;
		System.arraycopy(header_byte, 		0, order_byte, offset, FtrsConst.DATALOAD_HEADER_LEN);
		offset += FtrsConst.DATALOAD_HEADER_LEN;

		byte[] byte_data = this.requstSpclty.getBytes();
		System.arraycopy(byte_data, 		0, order_byte, offset, byte_data.length);

		return order_byte;
	}
}
