package com.sorincorp.api.samsung.ft.service;

import com.sorincorp.api.samsung.ft.model.OrOrderFtrsBasVo;

public interface FtrsTestService {
	
	/**
	 * 테스트 신규 주문을 생성하고 삼성선물로 주문 낸다
	 * @param ordInfo
	 * @throws Exception
	 */
	void testFtrsNewOrder(OrOrderFtrsBasVo ordInfo) throws Exception;
	
	void testFtrsNewClaim(OrOrderFtrsBasVo orderInfo)  throws Exception;
}
