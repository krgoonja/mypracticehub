package com.sorincorp.api.samsung.ft.service;

import com.sorincorp.api.samsung.ft.model.OrOrderFtrsBasVo;

public interface FtrsOrderService {

	/**
	 * <pre>
	 * 처리내용: API로 주문정보를 받아 삼성선물 신규 주문 처리한다.
	 * </pre>
	 * @date 2021. 12. 7.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 7.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param ordInfo
	 * @throws Exception
	 */
	void saveFtrsNewOrder(OrOrderFtrsBasVo ordInfo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: API로 주문정보를 받아 삼성선물 주문 취소 처리한다.
	 * </pre>
	 * @date 2021. 6. 29.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 29.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param ordInfo
	 * @throws Exception
	 */
	void saveFtrsCancelOrder(OrOrderFtrsBasVo ordInfo) throws Exception;

}
