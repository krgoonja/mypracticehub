package com.sorincorp.api;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.Bean;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.sorincorp.api.samsung.ExtrlCntcMngr;
import com.sorincorp.comm.util.StringUtil;

@SpringBootApplication
public class AppApiApplication extends SpringApplicationBuilder{

	@Value("${spring.profiles.active}")
	private String FS_PROFILE;

	@Autowired
	private ExtrlCntcMngr extrlCntcMngr;

	@Resource(name="samsungFsThreadPool")
	private ThreadPoolTaskExecutor taskExecutor;

	public static void main(String[] args) {
		SpringApplication.run(AppApiApplication.class, args);
	}

	//TEST

	@EventListener(ApplicationReadyEvent.class)
	public void init() {
		System.out.println("########### New FS_PROFILE ##################[" + FS_PROFILE + "]");
		if(!StringUtil.isEmpty(FS_PROFILE)) {
			System.out.println("########### New Start ExtrlCntcMngr ##################");
			Runnable rn = () -> { extrlCntcMngr.start(); };
			taskExecutor.execute(rn);
		}
	}

	@Bean(destroyMethod =  "destroy")
    public ShutdownHookConfiguration shutdownHookConfiguration() {
		return new ShutdownHookConfiguration();
    }
}
