package com.sorincorp.api.samsung.ft.handler;

import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sorincorp.api.samsung.ft.model.FtrsOrderRspnsVo;
import com.sorincorp.api.samsung.ft.service.FtrsReceiveService;
import com.sorincorp.api.util.FtrsCmmnConst;
import com.sorincorp.api.util.FtrsConst;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class FixDataCnclsExecutor {
	private static final AtomicInteger dailyRcvDataCount = new AtomicInteger(0);

	@Autowired
	private FtrsReceiveService orderRcvService;

	@PostConstruct
	public void initDailyRcvDataCount() {
		try {
			if(FtrsCmmnConst.isInitDailyRcvDataCount)
				return;

			log.info("################################## Receive-Seq-Number start sync job #####################################");

			int maxNumber    = orderRcvService.selectIfFtrsRcvSeqNumber();
			dailyRcvDataCount.set(maxNumber);

			FtrsCmmnConst.isInitDailyRcvDataCount = true;
			log.info("################################## Receive-Seq-Number end sync job(" + maxNumber + "건)######################");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void sendResponseLinkData() {
		try {
			int curnUM = dailyRcvDataCount.get();
			orderRcvService.sendResponseLinkData(curnUM);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void insertFtrsReceiveHeader(FtrsOrderRspnsVo vo) {
		try {
			int curNum = dailyRcvDataCount.get();
			orderRcvService.insertFtrsReceiveHeader(vo, curNum);

			if(log.isInfoEnabled()) {
				printCntctRecvData(vo, false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void insertFtrsReceiveResponse(FtrsOrderRspnsVo vo) {
		try {
			if(log.isInfoEnabled()) {
				printCntctRecvData(vo, true);
			}

			String headerType = vo.getHeaderType();
			if(FtrsConst.DATALOAD_DATA_REQ.equals(headerType)) {
				int curNum = dailyRcvDataCount.incrementAndGet();  /* 응답받은 Message Type이 "Data" 인경우 Sequence 1증가 */
				log.debug("Receive Data Count:{}",  curNum);
			}

			orderRcvService.saveFtrsReceiveResponse(vo);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void printCntctSendData(byte[] bytes) {
		try {
			byte[] tmpByte = new byte[bytes.length];
			System.arraycopy(bytes, 0, tmpByte, 0, bytes.length);

			StringBuffer buffer = new StringBuffer();
			buffer.append("\n");
			buffer.append("<<< Receiver send DATA >>> \n");
			buffer.append("LENGTH :[" + bytes.length +"]\n");
			buffer.append("DATA :[" + new String(tmpByte)+"]\n");
			log.info(buffer.toString());
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void printCntctRecvData(FtrsOrderRspnsVo vo, boolean bodyprint) {
		try {
			StringBuilder builder = new StringBuilder();
			builder.append("\n");
			builder.append("<<< Receiver receive Header DATA >>> \n");
			builder.append("Body Length	   :[4]            [").append( vo.getDataLength() 		).append("]\n");
			builder.append("Message Type   :[4]            [").append( vo.getHeaderType() 		).append("]\n");
			builder.append("Response Code  :[4]            [").append( vo.getResponseCode()   	).append("]\n");
			builder.append("Trade Date     :[8]            [").append( vo.getTradeDate() 	  	).append("]\n");
			builder.append("Sequence Number:[8]            [").append( vo.getSequenceNumber() 	).append("]\n");
			builder.append("Filler         :[22]           [").append( vo.getFilter() 			).append("]");

			if(!bodyprint) {
				log.info(builder.toString());
				return;
			}

//			builder.delete(0, builder.length());
			builder.append("\n");
			builder.append("<<< Receiver receive Body DATA >>> \n");
			builder.append("MsgType(35)				:[1]		[").append( vo.getMsgType()			).append("]\n");
			builder.append("SenderCompID(49)		:[20]		[").append( vo.getSenderCompId()	).append("]\n");
			builder.append("TargetCompID(56)		:[20]		[").append( vo.getTargetCompId()	).append("]\n");
			builder.append("OnBehalfOfCompID(115)	:[20]		[").append( vo.getOnBehalfOfCompId()).append("]\n");
			builder.append("Account(1)				:[11]		[").append( vo.getAccount()			).append("]\n");
			builder.append("AvgPx(6)				:[15]		[").append( vo.getAvgPx()			).append("]\n");
			builder.append("ClOrdID(11)				:[20]		[").append( vo.getClOrdId()			).append("]\n");
			builder.append("CumQty(14)				:[15]		[").append( vo.getCumQty()			).append("]\n");
			builder.append("ExecID(17)				:[20]		[").append( vo.getExecId()			).append("]\n");
			builder.append("LastPx(31)				:[15]		[").append( vo.getLastPx()			).append("]\n");
			builder.append("LastShares(32)			:[15]		[").append( vo.getLastShares()		).append("]\n");
			builder.append("OrderID(37)				:[20]		[").append( vo.getOrderId()			).append("]\n");
			builder.append("OrderQty(38)			:[15]		[").append( vo.getOrderQty()		).append("]\n");
			builder.append("OrdStatus(39)			:[1]		[").append( vo.getOrdStatus()		).append("]\n");
			builder.append("OrdType(40)				:[1]		[").append( vo.getOrdType()			).append("]\n");
			builder.append("OrigClOrdID(41)			:[20]		[").append( vo.getOrigClOrdId()		).append("]\n");
			builder.append("Price(44)				:[15]		[").append( vo.getPrice()			).append("]\n");
			builder.append("Side(54)				:[1]		[").append( vo.getSide()			).append("]\n");
			builder.append("Symbol(55)				:[12]		[").append( vo.getSymbol()			).append("]\n");
			builder.append("Text(58)				:[200]		[").append( vo.getText().trim()		).append("]\n");
			builder.append("TransactTime(60)		:[21]		[").append( vo.getTransactTime()	).append("]\n");
			builder.append("StopPx(99)				:[15]		[").append( vo.getStopPx()			).append("]\n");
			builder.append("ExecType(150)			:[1]		[").append( vo.getExecType()		).append("]\n");
			builder.append("LeavesQty(151)			:[15]		[").append( vo.getLeavesQty()		).append("]\n");
			builder.append("SecurityType(167)		:[3]		[").append( vo.getSecurityType()	).append("]\n");
			builder.append("SecurityExchange(207)	:[3]		[").append( vo.getSecurityExchange()).append("]\n");
			builder.append("MaturityDate(541)		:[8]		[").append( vo.getMaturityDate()	).append("]\n");
			builder.append("PositionID(5008)		:[20]		[").append( vo.getPositionID()		).append("]\n");
			builder.append("ExpiredID(5009)			:[20]		[").append( vo.getExpiredID()		).append("]\n");
			builder.append("Commition(5010)			:[10]		[").append( vo.getCommition()		).append("]");

			log.info(builder.toString());
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
