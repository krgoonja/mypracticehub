package com.sorincorp.api.samsung;

import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.sorincorp.api.samsung.ft.handler.FtrsBfeProcHandler;
import com.sorincorp.api.samsung.ft.socket.FixCnncHandler;
import com.sorincorp.api.samsung.service.FtrsStateMonitorIsSaleTime;
import com.sorincorp.api.util.FtrsCmmnConst;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Lazy
public class ExtrlCntcMngr {

	@Value("${samsung.service.weekend-enable:true}")
	private boolean FS_SERVICE_WEEKEND_ENABLE;

	@Value("${samsung.service.recept-active-time:25}")
	private int FS_SERVICE_RECEPT_ACTIVE_TIME;

	@Value("${samsung.service.monitor-delay-time:5}")
	private int FS_SERVICE_DELAY_MONITOR_TIME;


	private FixCnncHandler fixCnncHandler;
	private FtrsBfeProcHandler fixBfeProcess;
	private FtrsStateMonitor ftrsStateMonitor;
	private FtrsStateMonitorIsSaleTime ftrsStateMonitorIsSaleTime;

	@Autowired
	public ExtrlCntcMngr(FtrsStateMonitorIsSaleTime ftrsStateMonitorIsSaleTime) {
		this.ftrsStateMonitorIsSaleTime = ftrsStateMonitorIsSaleTime;
	}

	public void start() {
		if(FtrsCmmnConst.EXTRLCNTCMNGR_SERVICE_INITIALIZE) {
			log.info("This ExtrlCntcMngr App has already started.!!");
			return;
		}
//		log.info("This ExtrlCntcMngr starts to initialize.!!");

		fixCnncHandler = FixCnncHandler.getInstance();
		this.ftrsStateMonitor = new FtrsStateMonitor(fixCnncHandler);
		ftrsStateMonitor.start();
		if(fixBfeProcess == null) {
			fixBfeProcess = FtrsBfeProcHandler.getInstance();
			fixBfeProcess.setTcpCnncMngr(fixCnncHandler);
			fixBfeProcess.start();
		}

		FtrsCmmnConst.EXTRLCNTCMNGR_SERVICE_INITIALIZE = true;
		log.info("This ExtrlCntcMngr ends initialization.  [" + FtrsCmmnConst.EXTRLCNTCMNGR_SERVICE_INITIALIZE + "]");
	}

	@PreDestroy
	public void stopFtrsDemon(){
		try {
			if(fixBfeProcess != null) {
				fixBfeProcess.interrupt();
				fixBfeProcess.setRun(false);
			}
			Thread.sleep(500L);

			stopFtrsDaemons();

			Thread.sleep(500L);
			if(ftrsStateMonitor != null) {
				ftrsStateMonitor.setRun(false);
			}
			Thread.sleep(500L);
		}catch (InterruptedException ie) {
			log.error(getClass().getName(), ie);
		}catch (Exception e) {
			log.error(getClass().getName(), e);
		}
	}

	public void stopFtrsDaemons(){
		try{
			if(fixCnncHandler != null) {
				fixCnncHandler.closeSendWork();
				Thread.sleep(50L);
				fixCnncHandler.closeRecptnWork();
			}
		}catch(Exception e){
			log.error(getClass().getName(), e);
		}
	}

	private class FtrsStateMonitor extends Thread {
		private boolean run;
		private FixCnncHandler fixCnncHandlerManager;

		public FtrsStateMonitor(FixCnncHandler _manager) {
			setName("SORIN-FtrsStateMonitor");
			setDaemon(true);
			this.run = true;
			this.fixCnncHandlerManager = _manager;
			log.info("FtrsStateMonitor start.!!");
		}

		public final void run() {
			boolean isInitState = true;
			boolean isNonServiceTime = false;
			long startTime = System.currentTimeMillis();

			while (this.run) {
				try {
					if (isInitState || (System.currentTimeMillis() - startTime) > 0x2BF20L) { // 3분 마다
						//log.info("::: System.currentTimeMillis {}, startTime {}, 0x2BF20L {}", System.currentTimeMillis(), startTime, 0x2BF20L);
						isNonServiceTime = ftrsStateMonitorIsSaleTime.isNonServiceTime();
						isInitState = false;
						startTime = System.currentTimeMillis();
						log.info("TcpStateMonitor Service State	: [" + isInitState + "][" + isNonServiceTime + "]");
					}

					// 서비스 시간이 아닐때 소켓 통신 종료
					if (isNonServiceTime) {
						fixCnncHandlerManager.closeSendWork();
						fixCnncHandlerManager.closeRecptnWork();

						FtrsCmmnConst.isInitDailySendDataOkCount 		= false;
						FtrsCmmnConst.isInitDailyRcvDataCount    		= false;
						FtrsCmmnConst.EXTRLCNTCMNGR_SERVICE_INITIALIZE 	= false;
						continue;
					} else {
						FtrsCmmnConst.EXTRLCNTCMNGR_SERVICE_INITIALIZE 	= true;
					}

					long rcvStartTime = System.currentTimeMillis();
					long receiveDataTime = fixCnncHandlerManager.getReceiveTime();
					long rcbGab = rcvStartTime - receiveDataTime;

					// SERVICE_RECEPT_ACTIVE_TIME(20)초 이상 데이터가 응답이 없는 경우 Close 처리
					if (rcbGab > FS_SERVICE_RECEPT_ACTIVE_TIME * 1000L) {
						log.info("########### CloseReceiveScoket: 시작[{}], 수신[{}], [{}] 초과",  rcvStartTime, receiveDataTime, rcbGab);
						fixCnncHandlerManager.closeRecptnWork();
					}

					fixCnncHandlerManager.checkFixReceiverThreads();
					sleep(500L);
					fixCnncHandlerManager.createFixReceiverRequester();
					sleep(500L);

					fixCnncHandlerManager.checkFixSenderThreads();
					sleep(500L);
					fixCnncHandlerManager.createFixSenderRequester();
					sleep(FS_SERVICE_DELAY_MONITOR_TIME * 1000L);

				} catch (InterruptedException ie) {
					log.error("[FtrsStateMonitor Run]", ie);
				}
			} // end while
			log.error( "FtrsStateMonitor is Terminated!!!");
		}

		public void setRun(boolean _run) {
			this.run = _run;
		}
	}
}