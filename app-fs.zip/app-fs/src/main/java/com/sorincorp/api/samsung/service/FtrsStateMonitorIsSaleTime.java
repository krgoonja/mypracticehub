package com.sorincorp.api.samsung.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FtrsStateMonitorIsSaleTime {

	@Value("${samsung.service.weekend-enable:true}")
	private boolean FS_SERVICE_WEEKEND_ENABLE;

	@Value("${samsung.non-service.start-time}")
	private String FS_NONE_SERVICE_START_TIME;

	@Value("${samsung.non-service.end-time}")
	private String FS_NONE_SERVICE_END_TIME;

	private String noneServiceStartHM;
	private String noneServiceEndHM;

	public FtrsStateMonitorIsSaleTime() {
	}

	/**
	 * 서비스 가동 시간을 체크하여 아닌 경우 true 리턴
	 * @return boolean
	 */
	public boolean isNonServiceTime() {
		/*
		 * 작업 스케쥴러 시간 계산
		 */
		this.noneServiceStartHM = FS_NONE_SERVICE_START_TIME.replace(":", "").trim();
		this.noneServiceEndHM = FS_NONE_SERVICE_END_TIME.replace(":", "").trim();
		log.info("## None Service Time [" + FS_NONE_SERVICE_START_TIME + "] ~ [" + FS_NONE_SERVICE_END_TIME + "] ##");

		boolean b = false;
		try {
			LocalDateTime now = LocalDateTime.now();
			if( !FS_SERVICE_WEEKEND_ENABLE ) {                      /* 주말 허용 여부 */
				int dayNum = now.getDayOfWeek().getValue();   		/* 주말 체크 */
				switch (dayNum) {
					case 7:
						b = true;
						break;
					default:
						break;
				}

				if (b) {
					return b;
				}
			}

			/* 업무 시간 체크
			 * 시분을 합쳐 숫자로 변환, 서비스 아닌 시각 사이 시간에 해당하는지 판별
			 * ex) 새벽 5시 13분 (513 >= 500 && 513 <= 805)
			 * */
			DateTimeFormatter format = DateTimeFormatter.ofPattern("HHmm");
	        int nowHM = Integer.valueOf(now.format(format));
	        int nonServiceStartHM = Integer.valueOf(noneServiceStartHM);
	        int nonServiceEndHM = Integer.valueOf(noneServiceEndHM);
	        log.info("########### check service time - nowHM : {}, nonServiceStartHM : {}, nonServiceEndHM : {}", nowHM, nonServiceStartHM, nonServiceEndHM);

	        if (nowHM >= nonServiceStartHM && nowHM <= nonServiceEndHM) {
	        	return true;
	        }

		} catch (Exception e) {
			log.error("isNonServiceTime : ", e);
		}

		return b;
	}

	/**
	 * 익일 새벽 장종료 시간 까지는 당일 날짜 데이터를 가져오기 위한 함수
	 * @return yyyyMMdd
	 */
	public String getTradeDate() {
		String nowDate = null;
		int nowHM = Integer.valueOf(DateUtil.getNowDateTime("HHmm"));
        int nonServiceEndHM = Integer.valueOf(noneServiceEndHM);
        log.info("########### check service time - nowHM : {}, nonServiceEndHM : {}", nowHM, nonServiceEndHM);

        if (nowHM >= nonServiceEndHM) {
        	nowDate = DateUtil.getNowDate();
        } else {
        	nowDate = DateUtil.getDateAgo(1).replace("-", "");
        }

		return nowDate;
	}
}