package com.sorincorp.api.samsung.ft.model;

import java.io.Serializable;

import com.sorincorp.api.util.ApiCmmnUtil;
import com.sorincorp.api.util.FtrsConst;
import com.sorincorp.comm.util.StringUtil;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class EcMssageHeaderVo implements Serializable{
	private static final long serialVersionUID = 1766440071351134235L;

	String trgtEngineId;            //Fix Engin Id
	String intrfcSn;                    //순번

	String dataLength; 			        // 0046
	String headerType; 		        // LINK
	String responseCode = "0000"; 		// 0000
	String tradeDate; 			        // 20210520
	String sequenceNumber; 		        // 00000000
	String filter;
	byte[] byteFiller = { 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20
			             , 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20
			             , 0x20, 0x20 }; // "" * 20

	String frstRegisterId;
	String frstRegistDt;
	String lastChangerId;
	String lastChangeDt;

	/**
	 * 응답 헤더 메시지 길이
	 */
	String resHeaderBodyLength;
	/**
	 * 응답 헤더 메시지 타입
	 */
	String resHeaderMessageType;
	/**
	 * 응답 헤더 응답 코드
	 */
	String resHeaderResponseCode;
	/**
	 * 응답 헤더 기준 일자
	 */
	String resHeaderTradeDate;
	/**
	 * 응답 헤더 세션 일련 번호
	 */
	String resHeaderSequenceNumber;
	/**
	 * 응답 헤더 필러
	 */
	String resHeaderFilter;

	public byte[] getMssageHeaderByte() {
		byte[] byte_message_type    = StringUtil.padValue(headerType, "0", FtrsConst.DATALOAD_MSE_TY_LEN, true).getBytes();

		byte[] byte_response_code   = StringUtil.padValue(responseCode, "0", FtrsConst.DATALOAD_RES_CODE_LEN, true).getBytes();

		byte[] byte_trade_date      = StringUtil.padValue(tradeDate, "0", FtrsConst.DATALOAD_STDR_DE_LEN, true).getBytes();

		byte[] byte_sequence_number = StringUtil.padValue(sequenceNumber, "0", FtrsConst.DATALOAD_SESION_SEQNO_LEN, true).getBytes();

		byte[] byte_data_lengh      = StringUtil.padValue(String.valueOf(dataLength), "0", FtrsConst.DATALOAD_MSG_LT_LEN, true).getBytes();

		byte[] rtndata = new byte[FtrsConst.DATALOAD_HEADER_LEN]; //50 byte
		int offset = 0;
		System.arraycopy(byte_data_lengh, 		0, rtndata, offset, FtrsConst.DATALOAD_MSG_LT_LEN);
		offset += FtrsConst.DATALOAD_MSG_LT_LEN;
		System.arraycopy(byte_message_type, 	0, rtndata, offset, FtrsConst.DATALOAD_MSE_TY_LEN);
		offset += FtrsConst.DATALOAD_MSE_TY_LEN;
		System.arraycopy(byte_response_code, 	0, rtndata, offset, FtrsConst.DATALOAD_RES_CODE_LEN);
		offset += FtrsConst.DATALOAD_RES_CODE_LEN;
		System.arraycopy(byte_trade_date, 		0, rtndata, offset, FtrsConst.DATALOAD_STDR_DE_LEN);
		offset += FtrsConst.DATALOAD_STDR_DE_LEN;
		System.arraycopy(byte_sequence_number, 	0, rtndata, offset, FtrsConst.DATALOAD_SESION_SEQNO_LEN);
		offset += FtrsConst.DATALOAD_SESION_SEQNO_LEN;
		System.arraycopy(byteFiller, 			0, rtndata, offset, FtrsConst.DATALOAD_FILLER_LEN);

		return rtndata;
	}

	public void decodeRequestRcvHeader(byte[] data) {
		int offset = 0;
		this.resHeaderBodyLength = ApiCmmnUtil.bytes2String(data, offset, FtrsConst.DATALOAD_MSG_LT_LEN);
		offset += FtrsConst.DATALOAD_MSG_LT_LEN;

		this.resHeaderMessageType = ApiCmmnUtil.bytes2String(data, offset, FtrsConst.DATALOAD_MSE_TY_LEN);
		offset += FtrsConst.DATALOAD_MSE_TY_LEN;

		this.resHeaderResponseCode = ApiCmmnUtil.bytes2String(data, offset, FtrsConst.DATALOAD_RES_CODE_LEN);
		offset += FtrsConst.DATALOAD_RES_CODE_LEN;

		this.resHeaderTradeDate = ApiCmmnUtil.bytes2String(data, offset, FtrsConst.DATALOAD_STDR_DE_LEN);
		offset += FtrsConst.DATALOAD_STDR_DE_LEN;

		this.resHeaderSequenceNumber = ApiCmmnUtil.bytes2String(data, offset, FtrsConst.DATALOAD_SESION_SEQNO_LEN);
		offset += FtrsConst.DATALOAD_SESION_SEQNO_LEN;

		this.resHeaderFilter         = ApiCmmnUtil.bytes2String(data, offset, FtrsConst.DATALOAD_FILLER_LEN);
	}

	public void decodeResponseRcvHeader(byte[] data, String dataLength, String headerType) {
		this.dataLength = dataLength;
		this.headerType = headerType;

		int offset = 0;
		this.responseCode = ApiCmmnUtil.bytes2String(data, offset, FtrsConst.DATALOAD_RES_CODE_LEN);
		offset += FtrsConst.DATALOAD_RES_CODE_LEN;

		this.tradeDate = ApiCmmnUtil.bytes2String(data, offset, FtrsConst.DATALOAD_STDR_DE_LEN);
		offset += FtrsConst.DATALOAD_STDR_DE_LEN;

		this.sequenceNumber = ApiCmmnUtil.bytes2String(data, offset, FtrsConst.DATALOAD_SESION_SEQNO_LEN);
		offset += FtrsConst.DATALOAD_SESION_SEQNO_LEN;

//		String rcv_filler	= ApiCmmnUtil.bytes2String(data, offset, FtrsConst.DATALOAD_FILLER_LEN);
	}
}