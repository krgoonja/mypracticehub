package com.sorincorp.api.samsung.ft.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.samsung.exception.FtrsBizException;
import com.sorincorp.api.samsung.ft.handler.FixDataOrderExecutor;
import com.sorincorp.api.samsung.ft.mapper.FtrsMapper;
import com.sorincorp.api.samsung.ft.model.CommCodeVo;
import com.sorincorp.api.samsung.ft.model.FtrsOrderRequstVo;
import com.sorincorp.api.samsung.ft.model.OrOrderFtrsBasVo;
import com.sorincorp.api.util.FtrsConst;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FtrsClaimOrderServiceImpl implements FtrsClaimOrderService{
	@Autowired
	private FtrsMapper ftrsMapper;

	@Autowired
	private FixDataOrderExecutor fixDataOrderExecutor;

	@Autowired
	private FtrsProcessService ftrsProcessService;


	/**
	 * 삼성선물 Calim에 대한 Sell 주문 처리한다.
	 * @param OrOrderFtrsBasVo - 신규 주문 정보 VO
	 * @return
	 * @exception Exception
	 */
	@Override
	public void saveFtrsClaimOrderNew(OrOrderFtrsBasVo claimOrder) throws Exception {
		/*
		 * 신규 주문을 위한 코드 등록
		 */
		claimOrder.setRequstFtrsOrderTyCode(FtrsConst.FIX_ORDER_NEW);

		List<OrOrderFtrsBasVo> resultList = ftrsMapper.selectClaimFtrsList(claimOrder);
		if(resultList.size() == 0) {
			log.error("Claim 매도 주문 정보가 존재하지 않습니다. 취소/교환/반품 번호 :{}", claimOrder.getCanclExchngRtngudNo());
			throw new Exception("Claim 매도 주문 정보가 존재하지 않습니다. [수신 취소/교환/반품 번호 : " + claimOrder.getCanclExchngRtngudNo() + "]");
		}

		try {
			List<FtrsOrderRequstVo> list = new ArrayList<FtrsOrderRequstVo>();

			/**
             * 선물 거래 금속 코드 목록 조회
             * 1. MAIN_CODE가 "REQUST_FTRS_ITEM_CODE"인 공통 코드
             * */
			CommCodeVo commCodeVo = new CommCodeVo();
			commCodeVo.setMainCode("REQUST_FTRS_ITEM_CODE");
			List<CommCodeVo> commCodeList = ftrsMapper.selectListCoCmmnCd(commCodeVo);

			for (OrOrderFtrsBasVo ftrsBasData : resultList) {
				/* 신규 Order :  D */
				FtrsOrderRequstVo fixVo = ftrsProcessService.checkFtrsNewOrder('2', FtrsConst.SEND_MSG_TYPE_OR, commCodeList, ftrsBasData);
            	list.add(fixVo);
			}

			//삼성선물 전송
			if (list.size() > 0) {
				List<FtrsOrderRequstVo> sendResultList = fixDataOrderExecutor.doSendData(list);

				//실패시 상태코드 수정
				if (sendResultList.size() > 0) {
					ftrsProcessService.updateFtrsOrderSendResult(sendResultList);
				} else {
					ftrsProcessService.updateFtrsOrderSendResult(list);
				}
			}
		}catch(Exception e) {
			ftrsProcessService.saveFtrsOrderValidResult(resultList);
			if (e instanceof FtrsBizException) {
				log.error("FtrsBizException", e);
				throw (FtrsBizException)e;
			} else {
				log.error("Exception", e);
				throw e;
			}
		}
	}

	/**
	 * 삼성선물 Calim에 대한 Sell 주문에 대해 취소 처리한다..
	 * @param OrOrderFtrsBasVo - 신규 주문 정보 VO
	 * @return
	 * @exception Exception
	 */
	@Override
	public void saveFtrsClaimOrderCancel(OrOrderFtrsBasVo claimOrder) throws Exception {
		/*
		 * 취소 주문 코드 등록
		 */
		claimOrder.setRequstFtrsOrderTyCode(FtrsConst.FIX_ORDER_CANCEL);

		List<OrOrderFtrsBasVo> resultList = ftrsMapper.selectClaimFtrsList(claimOrder);
		if(resultList.size() == 0) {
			log.error("Claim 취소 매도 주문 정보가 존재하지 않습니다. 취소/교환/반품 번호 :{}", claimOrder.getCanclExchngRtngudNo());
			throw new Exception("Claim 취소 매도 주문 정보가 존재하지 않습니다. [수신 취소/교환/반품 번호 : " + claimOrder.getCanclExchngRtngudNo() + "]");
		}

		try {
			/**
			 * 선물 거래 금속 코드 목록 조회
			 * 1. MAIN_CODE가 "REQUST_FTRS_ITEM_CODE"인 공통 코드
			 * */
			CommCodeVo commCodeVo = new CommCodeVo();
			commCodeVo.setMainCode("REQUST_FTRS_ITEM_CODE");
			List<CommCodeVo> commCodeList = ftrsMapper.selectListCoCmmnCd(commCodeVo);

			List<FtrsOrderRequstVo> list = new ArrayList<FtrsOrderRequstVo>();
			for (OrOrderFtrsBasVo cnclBasData : resultList) {
				String requstWonOrderNo   = cnclBasData.getRequstWonOrderNo();

				if (StringUtils.isBlank(requstWonOrderNo)) {
	            	throw new FtrsBizException("", "클레임 취소 요청을 위한 원주문번호가 존재하지 않습니다. requstWonOrderNo [" + requstWonOrderNo + "]");
	            }

				/* Order Cancel/Replace Request :  F */
	            FtrsOrderRequstVo fixVo = ftrsProcessService.checkFtrsNewOrder('2', FtrsConst.SEND_MSG_TYPE_CR, commCodeList, cnclBasData);
            	list.add(fixVo);
			}

			//삼성선물 전송
			if(list.size() > 0) {
				List<FtrsOrderRequstVo> sendResultList = fixDataOrderExecutor.doSendData(list);

				//실패시 상태코드 수정
				if(sendResultList.size() > 0) {
					ftrsProcessService.updateFtrsOrderSendResult(sendResultList);
				}else {
					ftrsProcessService.updateFtrsOrderSendResult(list);
				}
			}
		}catch(Exception e) {
			ftrsProcessService.saveFtrsOrderValidResult(resultList);
			if(e instanceof FtrsBizException) {
				log.error("FtrsBizException", e);
				throw (FtrsBizException)e;
			}else {
				log.error("Exception", e);
				throw e;
			}
		}
	}
}
