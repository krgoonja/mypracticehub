package com.sorincorp.api.samsung.ft.socket;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import com.sorincorp.api.samsung.ft.handler.FixDataOrderExecutor;
import com.sorincorp.api.samsung.ft.model.FtrsOrderRequstVo;
import com.sorincorp.api.samsung.ft.service.FtrsProcessService;
import com.sorincorp.api.util.BeanUtils;
import com.sorincorp.api.util.FtrsCmmnConst;
import com.sorincorp.api.util.FtrsConst;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FtrsOrderSender extends Thread {
	private boolean run;
	private FixSocketWrapper communicator = null;
	private String sender_nm;
	private FixServiceIf service;
	private FixDataOrderExecutor orderExecutor;
	private FtrsProcessService processService;

	private AtomicInteger atomic = null;

	public FtrsOrderSender(FixServiceIf svcIf, String name, FixSocketWrapper _communicator) throws Exception {
		super(name);
		setDaemon(true);

		if (_communicator == null)
			throw new Exception("FtrsOrderSender.socketWrapper is null");

		this.sender_nm = name;
		this.communicator = _communicator;
		this.run = true;
		this.service = svcIf;

		atomic = new AtomicInteger(1);

		orderExecutor = (FixDataOrderExecutor)BeanUtils.getBean(FixDataOrderExecutor.class);
		/* DataLoad와 Send Sequence 맞추기 위해 매일 아침 또는 Sender Start시 초기화한다. */
		if(!FtrsCmmnConst.isInitDailySendDataOkCount) {
			orderExecutor.initDailySendDataOkCount();
		}

		processService = (FtrsProcessService)BeanUtils.getBean(FtrsProcessService.class);

		log.info( "[{}] Start", this.sender_nm);
	}

	public final void run() {
		byte[] linkByte = null;
		FtrsOrderRequstVo linkInfo = null;
		FtrsOrderRequstVo rcvDataVo    = null;
		while (run) {
			try {
				int idx = atomic.getAndIncrement();

				if (!service.isOrderLink()) {
					linkInfo = Optional.ofNullable( orderExecutor.getRequestLinkData(FtrsConst.DATALOAD_LINK_REQ))
							.orElseThrow(() -> { return new Exception("LinkInfo is null"); });

				} else if (service.isOrderLink() && idx % 20 == 0) { // 20초에 1번 전송
					atomic.set(1);

					linkInfo = Optional.ofNullable( orderExecutor.getRequestLinkData(FtrsConst.DATALOAD_POLL_REQ))
					        .orElseThrow(() -> { return new Exception("PollInfo is null"); });
				} else {
					sleep(1000L);
					continue;
				}

				linkByte = linkInfo.getMssageHeaderByte();
				if (log.isInfoEnabled()) {
					printReqSendData(linkByte);
				}

				rcvDataVo = send(linkByte);

				if (rcvDataVo != null) {
					String resHeaderBodyLength = rcvDataVo.getResHeaderBodyLength();
					String resHeaderMessageType = rcvDataVo.getResHeaderMessageType();
					String resHeaderResponseCode = rcvDataVo.getResHeaderResponseCode();
					String resHeaderTradeDate = rcvDataVo.getResHeaderTradeDate();
					String resHeaderSequenceNumber = rcvDataVo.getResHeaderSequenceNumber();
					String resHeaderFilter = rcvDataVo.getResHeaderFilter();

					linkInfo.setResHeaderBodyLength(resHeaderBodyLength);
					linkInfo.setResHeaderMessageType(resHeaderMessageType);
					linkInfo.setResHeaderResponseCode(resHeaderResponseCode);
					linkInfo.setResHeaderTradeDate(resHeaderTradeDate);
					linkInfo.setResHeaderSequenceNumber(resHeaderSequenceNumber);
					linkInfo.setResHeaderFilter(resHeaderFilter);
				}

				processService.insertIfFtrsOrderRequstData(linkInfo);

				sleep(1000L);

			} catch(Exception e) {
				this.close();
				log.error(getName(), e);
			}
		}

		log.error("Terminated!!!");
	}

	protected FtrsOrderRequstVo send(byte[] data) throws Exception {
		FtrsOrderRequstVo dataVo = null;
		try {
			atomic.set(1);

			synchronized (communicator) {
				/* 주문 요청 전송 */
				this.communicator.write(data);

				/* 주문 요청 응답 수신 */
				BufferedInputStream bis = this.communicator.getInputStream();
				if (bis == null) {
					log.error("BufferedInputStream is null.!!!");
					return null;
				}

				byte[] rcvBytes = new byte[FtrsConst.DATALOAD_HEADER_LEN];
				int iReadSize = bis.read(rcvBytes, 0, rcvBytes.length);

				dataVo = new FtrsOrderRequstVo();
				dataVo.decodeRequestRcvHeader(rcvBytes);

				if(log.isInfoEnabled()) {
					printReqRecvData(dataVo);
				}

				String resHeaderMessageType   = dataVo.getResHeaderMessageType();

				if(iReadSize <= 0) {
					log.info("Receive HeaderType Empty. [" + iReadSize + "] [" + resHeaderMessageType + "]");
					return null;
				}else {
					if(FtrsConst.DATALOAD_LINK_OK.equals(resHeaderMessageType)) {
						this.service.setOrderLink(true);                 // Link OK 수신시 까지 계속 Link 연결
					}else if(FtrsConst.DATALOAD_EROR.equals(resHeaderMessageType)) {
						/* InitDailySendDataOkCount 초기화 */
						FtrsCmmnConst.isInitDailySendDataOkCount = false;

						this.service.setOrderLink(false);                // EROR 응답시 다시 Session LINK 요청을 보낸다.

						this.close();                                    // Session 거부로 Tcp 재접속(E001, E002, E003, E004, E005)
					}
				}

				return dataVo;
			}
		} catch (IOException ie) {
			try {
				this.close();
				log.error("[FtrsOrderSender IOException]", ie);
			} catch (Exception e) {}
			throw ie;
		} catch (Exception e) {
			try {
				this.close();
				log.error("[FtrsOrderSender sendData]", e);
			} catch (Exception e1) {}
		}

		return null;
	}

	public FtrsOrderRequstVo sendFixOrderData(byte data[]) throws Exception {
		if(log.isInfoEnabled()) {
			printReqSendData(data);
		}

		return send(data);
	}

	public void close() {
		try {
			setRun(false);
			if (this.communicator != null) {
				this.communicator.close();
				this.communicator = null;
			}
		} catch (Exception e) {
			log.error("FtrsOrderSender close", e);
		}
	}

	public void setRun(boolean run) {
		this.run = run;
	}

	protected FixSocketWrapper getTcpCommunicator() {
		return this.communicator;
	}

	private void printReqSendData(byte[] bytes) {
		try {
			int bLen = bytes.length;
			byte[] tmpByte = new byte[bLen];
			System.arraycopy(bytes, 0, tmpByte, 0, bLen);

			StringBuilder builder = new StringBuilder();
			builder.append("\n");
			builder.append("<<< Sender send DATA >>> \n");
			builder.append("LENGTH :[" + bytes.length +"]\n");
			builder.append("DATA :[" + new String(tmpByte)+"]\n");
			log.info(builder.toString());
		}catch(Exception e) {
			log.error("[FtrsOrderSender printReqSendData]", e);
		}
	}

	private void printReqRecvData(FtrsOrderRequstVo vo) {
		try {
			StringBuilder builder = new StringBuilder();
			builder.append("\n");
			builder.append("<<< Sender receive Header DATA >>> \n");
			builder.append("Rcv Body Length		:[4]	is  ["     + vo.getResHeaderBodyLength() + "]\n");
			builder.append("Rcv Message Type	:[4]	is  ["     + vo.getResHeaderMessageType() + "]\n");
			builder.append("Rcv Response Code	:[4]	is  ["     + vo.getResHeaderResponseCode() + "]\n");
			builder.append("Rcv Trade Date		:[8]	is  ["     + vo.getResHeaderTradeDate() + "]\n");
			builder.append("Rcv Sequence Number	:[8]	is  ["     + vo.getResHeaderSequenceNumber() + "]\n");
			builder.append("Rcv Filler			:[22]	is  ["     + vo.getResHeaderFilter() + "]\n");
			log.info(builder.toString());
		}catch(Exception e) {
			log.error("[FtrsOrderSender printReqRecvData]", e);
		}
	}
}