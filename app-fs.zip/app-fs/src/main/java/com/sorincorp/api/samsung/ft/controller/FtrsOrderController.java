package com.sorincorp.api.samsung.ft.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.samsung.exception.FtrsBizException;
import com.sorincorp.api.samsung.ft.model.OrOrderFtrsBasVo;
import com.sorincorp.api.samsung.ft.service.FtrsClaimOrderService;
import com.sorincorp.api.samsung.ft.service.FtrsOrderService;
import com.sorincorp.api.samsung.ft.service.FtrsTestService;
import com.sorincorp.api.util.APICmmnConst;
import com.sorincorp.api.util.HttpResponseVO;

import lombok.extern.slf4j.Slf4j;


/**
 * FtrsOrderController.java
 * @version
 * @since 2021. 6. 4.
 * @author srec0032
 */
@Slf4j
@RestController
@RequestMapping(value = "/samsung/ftrs")
public class FtrsOrderController {

	@Autowired
	private FtrsTestService testService;

	@Autowired
	private FtrsOrderService orderService;

	@Autowired
	private FtrsClaimOrderService claimService;

	/**
	 * <pre>
	 * 처리내용: Fs Server의 health 체크한다.
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 21.			srec0032			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/health", method = RequestMethod.GET)
	@ResponseBody
    public ResponseEntity<?> health() throws Exception {
		log.info("/samsung/ftrs/health ###################### OK..");
		HttpResponseVO resVo = new HttpResponseVO();
		resVo.setSuccess(true);
		resVo.setCode(APICmmnConst.SUCCESS_RESULT_CODE);
		resVo.setMessage(APICmmnConst.SUCCESS_RESULT_MSG);

        return ResponseEntity
				.status(HttpStatus.OK)
				.body(resVo);
    }

	/**
	 * <pre>
	 * 처리내용: 테스트 신규 주문을 생성하고 삼성선물로 주문 낸다.
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 21.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param orderInfo
	 * @return
	 * @throws FtrsBizException
	 * @throws Exception
	 */
	@RequestMapping(value = "/ordertest/new", method = RequestMethod.POST)
	@ResponseBody
    public ResponseEntity<?> testFtrsNewOrder( @RequestBody OrOrderFtrsBasVo orderInfo ) throws FtrsBizException, Exception {
		log.info("execute: /samsung/ftrs/ordertest/new {}", orderInfo);

		testService.testFtrsNewOrder(orderInfo);

		HttpResponseVO resVo = new HttpResponseVO();
		Map<String, Object> dataMap = new HashMap<String, Object>();
		dataMap.put("seq", 10);
		dataMap.put("orderNum", "111111111");
		resVo.setData(dataMap);

		return ResponseEntity.status(HttpStatus.OK).body(resVo);
    }
	
	@RequestMapping(value = "/claimtest/new", method = RequestMethod.POST)
	@ResponseBody
    public ResponseEntity<?> testFtrsNewClaimOrder( @RequestBody OrOrderFtrsBasVo orderInfo ) throws FtrsBizException, Exception {
		log.info("execute: /samsung/ftrs/claimtest/new {}", orderInfo);

		testService.testFtrsNewClaim(orderInfo);

		HttpResponseVO resVo = new HttpResponseVO();
		Map<String, Object> dataMap = new HashMap<String, Object>();
		dataMap.put("seq", 10);
		dataMap.put("orderNum", "111111111");
		resVo.setData(dataMap);

		return ResponseEntity.status(HttpStatus.OK).body(resVo);
    }
	/**
	 * <pre>
	 * 처리내용: 삼성선물과 선물 거래 - 신규 주문
	 * </pre>
	 * @date 2021. 6. 4.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 4.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/order/new", method = RequestMethod.POST)
	@ResponseBody
    public ResponseEntity<?> executeFtrsOrderNew( @RequestBody OrOrderFtrsBasVo  orderInfo) throws Exception {
		StringBuilder builder = new StringBuilder();
		builder.append("##########################################\n");
		builder.append("url :/samsung/ftrs/order/new \n");
		builder.append("orderNo :[" + orderInfo.getOrderNo() + "] \n");
		builder.append("canclExchngRtngudNo :" + orderInfo.getCanclExchngRtngudNo());
		log.info(builder.toString());

		/* rollback 제외시키키 위해 save prefix 사용 */
		orderService.saveFtrsNewOrder(orderInfo);

		HttpResponseVO resVo = new HttpResponseVO(); 
		resVo.setCode(APICmmnConst.SUCCESS_RESULT_CODE);
		resVo.setMessage(APICmmnConst.SUCCESS_RESULT_MSG);

		return ResponseEntity.status(HttpStatus.OK).body(resVo);
    }

	/**
	 * <pre>
	 * 처리내용: 신규 주문에 대한 잔량 취소주문을 처리한다.
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 21.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param orderInfo
	 * @return
	 * @throws FtrsBizException
	 * @throws Exception
	 */
	@RequestMapping(value = "/order/cancel", method = RequestMethod.POST)
	@ResponseBody
    public ResponseEntity<?> executeFtrsOrderCancel( @RequestBody OrOrderFtrsBasVo orderInfo ) throws Exception {
		StringBuilder builder = new StringBuilder();
		builder.append("##########################################\n");
		builder.append("url :/samsung/ftrs/order/cancel \n");
		builder.append("orderNo :[" + orderInfo.getOrderNo() + "] \n");
		builder.append("canclExchngRtngudNo :" + orderInfo.getCanclExchngRtngudNo());
		log.info(builder.toString());

		/* rollback 제외시키키 위해 save prefix 사용 */
		orderService.saveFtrsCancelOrder(orderInfo);

		HttpResponseVO resVo = new HttpResponseVO();
		resVo.setCode(APICmmnConst.SUCCESS_RESULT_CODE);
		resVo.setMessage(APICmmnConst.SUCCESS_RESULT_MSG);

        return ResponseEntity.status(HttpStatus.OK).body(resVo);
    }

	/**
	 * <pre>
	 * 처리내용: 삼성선물 체결 주문에 대해 취소, 반품 주문 처리를 진행한다.
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 21.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param orderInfo
	 * @return
	 * @throws FtrsBizException
	 * @throws Exception
	 */
	@RequestMapping(value = "/claim-order/new", method = RequestMethod.POST)
	@ResponseBody
    public ResponseEntity<?> executeFtrsClaimOrderNew( @RequestBody OrOrderFtrsBasVo  claimInfo) throws Exception {
		StringBuilder builder = new StringBuilder();
		builder.append("##########################################\n");
		builder.append("url :/samsung/ftrs/claim-order/new \n");
		builder.append("orderNo :[" + claimInfo.getOrderNo() + "] \n");
		builder.append("canclExchngRtngudNo :" + claimInfo.getCanclExchngRtngudNo());
		builder.append("ftrsRequstOrderNo :" + claimInfo.getFtrsRequstOrderNo());
		log.info(builder.toString());

		/* rollback 제외시키키 위해 save prefix 사용 */
		claimService.saveFtrsClaimOrderNew(claimInfo);

		HttpResponseVO resVo = new HttpResponseVO();
		resVo.setCode(APICmmnConst.SUCCESS_RESULT_CODE);
		resVo.setMessage(APICmmnConst.SUCCESS_RESULT_MSG);

		return ResponseEntity.status(HttpStatus.OK).body(resVo);
    }

/* Claim-order의 취소는 off 라인으로 결정함. */
//	@RequestMapping(value = "/claim-order/cancel", method = RequestMethod.POST)
//	@ResponseBody
//    public ResponseEntity<?> executeFtrsClaimOrderCancel( @RequestBody OrOrderFtrsBasVo claimInfo ) throws FtrsBizException, Exception {
//		StringBuilder builder = new StringBuilder();
//		builder.append("##########################################\n");
//		builder.append("url :/samsung/ftrs/claim-order/cancel \n");
//		builder.append("orderNo :[" + claimInfo.getOrderNo() + "] \n");
//		builder.append("canclExchngRtngudNo :" + claimInfo.getCanclExchngRtngudNo());
//		log.info(builder.toString());
//
//		claimService.executeFtrsClaimOrderCancel(claimInfo);
//
//		HttpResponseVO resVo = new HttpResponseVO();
//		resVo.setCode(APICmmnConst.SUCCESS_RESULT_CODE);
//		resVo.setMessage(APICmmnConst.SUCCESS_RESULT_MSG);
//
//        return ResponseEntity.status(HttpStatus.OK).body(resVo);
//    }

	@ExceptionHandler(FtrsBizException.class)
	public ResponseEntity<?> ftrsBizException(FtrsBizException e) throws Exception{
		log.error("FtrsOrderController.FtrsBizException ", e);

		HttpResponseVO resVo = new HttpResponseVO();
		resVo.setSuccess(false);
		resVo.setCode(APICmmnConst.ERROR_RESULT_CODE);
		resVo.setMessage(APICmmnConst.ERROR_RESULT_MSG);
		resVo.setError(e.getMessage());
		return ResponseEntity.status(HttpStatus.OK).body(resVo);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> ftrsCommException(Exception e) throws Exception{
		log.error("FtrsOrderController.Exception ", e);
		HttpResponseVO resVo = new HttpResponseVO();
		resVo.setSuccess(false);
		resVo.setCode(APICmmnConst.ERROR_RESULT_CODE);
		resVo.setMessage(APICmmnConst.ERROR_RESULT_MSG);
		resVo.setError(e.getMessage());
		return ResponseEntity.status(HttpStatus.OK).body(resVo);
	}
}
