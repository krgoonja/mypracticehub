package com.sorincorp.api.samsung.ft.handler;

import java.util.ArrayList;

import com.sorincorp.api.samsung.ft.model.FtrsOrderRspnsVo;
import com.sorincorp.api.util.BeanUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FtrsReceptProcHandler extends Thread {
	private static FtrsReceptProcHandler INSTANCE;

	private boolean isRun;
	private ArrayList<Object> list;
	private FixDataCnclsExecutor fixDataCnclsExecutor;

	private FtrsReceptProcHandler() {
		setName("SORIN-FtrsReceptProcHandler");
		setDaemon(true);

		isRun = true;
		list = new ArrayList<Object>();
		fixDataCnclsExecutor = (FixDataCnclsExecutor)BeanUtils.getBean(FixDataCnclsExecutor.class);
	}

	public static synchronized FtrsReceptProcHandler getInstance() {
		if( INSTANCE == null )
			INSTANCE = new FtrsReceptProcHandler();
		return INSTANCE;
	}

	public void add(FtrsOrderRspnsVo vo) throws Exception{
		synchronized(list) {
			int size = list.size();
			if (size>3000){
				log.info("==> FtrsReceptProcHandler Buffer is OverFlow And Clear!!");
				throw new Exception("FtrsReceptProcHandler Buffer is OverFlow");
			}else{
				list.add(vo);
				list.notify();
			}
		}
	}

	public void stopThread(){
		try {
			setRun(false);
			interrupt();

			Thread.sleep(50L);
		} catch (InterruptedException e) {
		}
	}

	public void setRun(boolean run){
		this.isRun = run;
	}

	public final void run() {
		FtrsOrderRspnsVo object = null;
		while( isRun ) {
			synchronized(list) {
				if( list.size() == 0 ) {
					try {
						list.wait();
					} catch(Exception e) {}
				} else {
					object = (FtrsOrderRspnsVo) list.remove(0);
				}
			}

			try{
				if( object != null ){
					executeRcvData(object);
				}

				object = null;
			} catch (Throwable t) {
				try {
					list.clear();
					sleep(60000L);
				} catch (InterruptedException e) {}
		    }
		}

		this.isRun = false;
		log.info("FtrsReceptProcHandler is Terminated!!!");
	}

	private void executeRcvData(FtrsOrderRspnsVo vo) {
		try {
			char msgType = vo.getMsgType();

			if(msgType == 0) {
				fixDataCnclsExecutor.insertFtrsReceiveHeader(vo);
			}else {
				fixDataCnclsExecutor.insertFtrsReceiveResponse(vo);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
