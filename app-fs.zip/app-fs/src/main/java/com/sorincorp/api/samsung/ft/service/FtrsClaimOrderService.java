package com.sorincorp.api.samsung.ft.service;

import com.sorincorp.api.samsung.ft.model.OrOrderFtrsBasVo;

public interface FtrsClaimOrderService {
	/**
	 * 삼성선물 Calim에 대한 Sell 주문 처리한다.
	 * @param OrOrderFtrsBasVo - 신규 주문 정보 VO
	 * @return
	 * @exception Exception
	 */
	void saveFtrsClaimOrderNew(OrOrderFtrsBasVo ordInfo) throws Exception;

	/**
	 * 삼성선물 Calim에 대한 Sell 주문에 대해 취소 처리한다..
	 * @param OrOrderFtrsBasVo - 신규 주문 정보 VO
	 * @return
	 * @exception Exception
	 */
	void saveFtrsClaimOrderCancel(OrOrderFtrsBasVo claimOrder) throws Exception;
}
