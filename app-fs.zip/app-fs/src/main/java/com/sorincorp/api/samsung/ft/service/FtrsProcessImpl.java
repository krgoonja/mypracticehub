package com.sorincorp.api.samsung.ft.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.sorincorp.api.samsung.exception.FtrsBizException;
import com.sorincorp.api.samsung.ft.mapper.FtrsMapper;
import com.sorincorp.api.samsung.ft.model.CommCodeVo;
import com.sorincorp.api.samsung.ft.model.FtrsOrderRequstVo;
import com.sorincorp.api.samsung.ft.model.OrOrderFtrsBasVo;
import com.sorincorp.api.samsung.mon.service.FsStateMonitorService;
import com.sorincorp.api.samsung.service.FtrsStateMonitorIsSaleTime;
import com.sorincorp.api.util.FtrsCmmnConst;
import com.sorincorp.api.util.FtrsConst;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.order.constant.CommFtrsConstant;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@ComponentScan({"com.sorincorp.comm.assign.*"})
public class FtrsProcessImpl implements FtrsProcessService {

	@Value("${fix.sender-compid}")
	private String FIX_SENDER_COMPID;            //SORIN_UAT
	@Value("${fix.target-compid.samsung}")       //SSF_UAT
	private String FIX_TARGET_COMPID_SAMSUNG;
	@Value("${fix.target-compid.ebest}")       	 //EBEST_UAT - ebest증권사 추가(2023-06-23)
	private String FIX_TARGET_COMPID_EBEST;

	@Value("${fix.target-enginid}")              //이중화 대비 작업 서버 구분자
	private String fix_target_enginid;

	@Autowired
	private FtrsMapper ftrsMapper;
	@Autowired
	private FsStateMonitorService stateMonitorService;
	@Autowired
	private AssignService assignService;
	@Autowired
	private FtrsStateMonitorIsSaleTime ftrsStateMonitorIsSaleTime;


	@Override
	public String getTestOrderNo() throws Exception{
		return DateUtil.getNowDate()+ "-S" + assignService.selectAssignValue("OR", "ORDER_NO", DateUtil.calDate("yyyy"), "fsSystem", 5);
	}

	@Override
	public String getTestFtrsReqOrderNo()  throws Exception{
		return DateUtil.getNowDate()+ "-" + "1" + assignService.selectAssignValue("OR", "FTRS_REQUST_ORDER_NO", DateUtil.getNowDate(), "fsSystem", 10);
	}

	@Override
	public int selectIfFtrsOrderSeqNumber() throws Exception{
		String fixEngingId = this.fix_target_enginid;  		/* Target Fix Engin Id */
		return ftrsMapper.selectIfFtrsOrderSeqNumber(fixEngingId);
	}

	/**
	 *  Fix 주문 데이터를 인터페이스 테이블에 저장한다.
	 */
	@Override
	public int insertIfFtrsOrderRequstData(FtrsOrderRequstVo dataInfo) throws Exception{
		String fixEngingId = this.fix_target_enginid;  		/* Target Fix Engin Id */
		dataInfo.setTrgtEngineId(fixEngingId);

		return ftrsMapper.insertIfFtrsOrderRequst(dataInfo);
	}

	/**
	 * Fix 주문전 Validation 실행결과 실패시 상태 수정.
	 */
	@Override
	public void saveFtrsOrderValidResult(List<OrOrderFtrsBasVo> reqVoList) throws Exception {
		try {
			StringBuilder builder = new StringBuilder();

			for (OrOrderFtrsBasVo reqVo : reqVoList) {
				String orderNo    			= reqVo.getOrderNo();
				String ftrsRequstOrderNo    = reqVo.getFtrsRequstOrderNo();

				OrOrderFtrsBasVo xOrgFtrsBasVo = new OrOrderFtrsBasVo();
				xOrgFtrsBasVo.setFtrsRequstOrderNo(ftrsRequstOrderNo);
				xOrgFtrsBasVo.setRspnsFtrsSttusCode(FtrsCmmnConst.RSPNS_FTRS_STTUS_CODE_FAIL);     //주문 상태
				int cnt = ftrsMapper.updateOrFtrsBasOrgOrderStatus(xOrgFtrsBasVo);

				builder.delete(0, builder.length());
				builder.append("\n <<< FTRS Valid Fail Info. >>> \n");
				builder.append("++++++++++++++++++++++++++++++++++++++++++\n");
				builder.append("COUNT:				[" + cnt +"]\n");
				builder.append("ORDER_NO:				[" + orderNo +"]\n");
				builder.append("FTRS_REQUST_ORDER_NO:	[" + ftrsRequstOrderNo +"]\n");
				builder.append("RSPNS_FTRS_STTUS_CODE:	[" + FtrsCmmnConst.RSPNS_FTRS_STTUS_CODE_FAIL +"]\n");
				log.error(builder.toString());
			}
		}catch(Exception e) {
			log.error("updateFtrsOrderValidResult Error", e);
		}
	}

	/**
	 * Fix 주문 실패시 상태코드 update.
	 */
	@Override
	public void updateFtrsOrderSendResult(List<FtrsOrderRequstVo> sendResultList) throws Exception {
		try {
			for (FtrsOrderRequstVo resultVo : sendResultList) {
				String resHeaderMessageType = resultVo.getResHeaderMessageType();
				String responseCode = resultVo.getResHeaderResponseCode();
				String clOrdId = resultVo.getClOrdId();

				if (resHeaderMessageType == null
						|| (FtrsConst.DATALOAD_EROR.equals(resHeaderMessageType))
						|| (FtrsConst.DATALOAD_DATA_OK.equals(resHeaderMessageType) && responseCode.startsWith("BZ"))
				) {
					OrOrderFtrsBasVo xOrgFtrsBasVo = new OrOrderFtrsBasVo();
					xOrgFtrsBasVo.setFtrsRequstOrderNo(clOrdId);
					xOrgFtrsBasVo.setRspnsFtrsSttusCode(FtrsCmmnConst.RSPNS_FTRS_STTUS_CODE_FAIL);		//주문 상태(응답 선물 상태 코드 - 실패)
					ftrsMapper.updateOrFtrsBasOrgOrderStatus(xOrgFtrsBasVo);

					stateMonitorService.checkFsWorkStatus(false);

					printFtrsSendFailInfo(sendResultList);
				}

				//응답 성공인 경우 OR_ORDER_FTRS_BAS "주문 접수 상태"로 수정
				if (resHeaderMessageType != null
						&& FtrsConst.DATALOAD_DATA_OK.equals(resHeaderMessageType)
						&& FtrsConst.DATALOAD_DATA_0000.equals(responseCode)
				) {
					OrOrderFtrsBasVo xOrgFtrsBasVo = new OrOrderFtrsBasVo();
					xOrgFtrsBasVo.setFtrsRequstOrderNo(clOrdId);
					xOrgFtrsBasVo.setRspnsFtrsSttusCode(FtrsCmmnConst.RSPNS_FTRS_STTUS_CODE_ORDER_REQUST);	//주문 상태(응답 선물 상태 코드 - 주문요청)
					ftrsMapper.updateOrFtrsBasOrgOrderStatus(xOrgFtrsBasVo);

					stateMonitorService.checkFsWorkStatus(true);
				}
			}
		} catch (Exception e) {
			log.error("UpdateOrFtrsBasOrgOrderStatus Error", e);
		}
	}

	@Override
	public void printFtrsSendFailInfo(List<FtrsOrderRequstVo> sendResultList) {
		try {
			StringBuilder builder = new StringBuilder();
			builder.append("\n <<< FTRS Send Fail Info. >>> \n");
			for (FtrsOrderRequstVo resultVo : sendResultList) {
				builder.append("++++++++++++++++++++++++\n");
				builder.append("MsgType:				[" + resultVo.getMsgType() +"]\n");
				builder.append("SequenceNumber: 		[" + resultVo.getSequenceNumber() +"]\n");
				builder.append("ClOrdId:				[" + resultVo.getClOrdId() +"]\n");
				builder.append("ResHeaderMessageType: 	[" + resultVo.getResHeaderMessageType() +"]\n");
				builder.append("RePponseCode: 			[" + resultVo.getResHeaderResponseCode() +"]");
			}

			log.error(builder.toString());

		} catch (Exception e) {
			log.error("PrintFtrsSendFailInfo Error", e);
		}
	}

	/**
	 * 삼성선물 주문을 위한 Fix 전문 데이터를 만든다.
	 * @param OrOrderFtrsBasVo - 신규 주문 정보 VO
	 * @return
	 * @exception Exception
	 */
	private FtrsOrderRequstVo getFixOrderData(OrOrderFtrsBasVo param) throws FtrsBizException{
		try {
			char msgType = param.getMsgType();             			//msgType:D, F
			if (!(msgType == 'D' || msgType == 'F')) {
				throw new Exception("Tag: 35(MsgType) Error :" + msgType);
			}

			String orderQty = StringUtils.defaultIfBlank(param.getRequstOrderQy(), StringUtils.EMPTY);	//orderQty: 1개로 고정
			String price = StringUtils.defaultIfBlank(param.getRequstOrderUntpc(), StringUtils.EMPTY);  //price: 2763.00

			char side = param.getRequstPostn();     				//side:1, 1= Buy   2= Sell
			if (!(side == '1' || side == '2')) {
				side = 0x20;
			}

            char positionEffect = param.getRequstLqdOrderAt();      		//청산주문여부 (신규주문:'O', 청산주문:'C', 신규주문:'N')
			if (!(positionEffect == 'O' || positionEffect == 'C' || positionEffect == 'N')) {
				log.info("=========> char positionEffect is [" + positionEffect +"]");
            	positionEffect = 0x20;
            }

			String clOrdId = param.getFtrsRequstOrderNo();	   			//clOrdId: 20210630-100000002
			String accountNo = CryptoUtil.decryptAES256(param.getRequstAcnutNo());	//계좌번호 복호화
			String orderId = StringUtils.defaultIfBlank(param.getRequstCanclFtrsOrderNo(), StringUtils.EMPTY);	//삼성선물 주문 번호: 202106307000010
			String origClOrdId = StringUtils.defaultIfBlank(param.getRequstWonOrderNo(), StringUtils.EMPTY);	//케이지트레이딩 원주문 번호: 20210630-100000002
            String positionNum = StringUtils.defaultIfBlank(param.getRequstLqdPostnNo(), StringUtils.EMPTY);	//청산대상포지션 번호

            // 선물사다중화 작업으로 이베스트증권 추가됨(2023-06-23)
            String fixTargetCompid = param.getFixTargetCompid();

            FtrsOrderRequstVo fixVo = new FtrsOrderRequstVo();
            String strOrdDataLen = StringUtil.padValue(String.valueOf(FtrsConst.DATAlOAD_ORDER_DATA_LEN), "0", 4, true);

	        /* Message Header */
			/* origin: 46 + 242 byte = 288 */
			/* 이베스트증권 계좌 추가로 1byte 추가됨
			 * 46 + 243 byte = 289
			 * 2023-06-23
			 * */
			fixVo.setDataLength(strOrdDataLen);
			fixVo.setHeaderType(FtrsConst.DATALOAD_DATA_REQ);
			fixVo.setTradeDate(ftrsStateMonitorIsSaleTime.getTradeDate());

			/* Message Body */
			fixVo.setMsgType(msgType);  						 	//D: New Order, T : 삼성선물 회선 검증
			fixVo.setSenderCompId(FIX_SENDER_COMPID);     		    //Tag : 49, 	SORIN_UAT (개발)
			fixVo.setTargetCompId(fixTargetCompid);          		//Tag : 56, 	SSF_UAT (삼성, 개발), SSF_UAT (이베스트증권, 개발)
			fixVo.setDeliverToCompId(StringUtils.EMPTY);	 		//Tag : 128, 	현재는 사용하지 않음. (HUB 사용시 필요함)
			fixVo.setAccountNo(accountNo);                    		//Tag : 1

			fixVo.setClOrdId(clOrdId);                        	  	//Tag : 11
			fixVo.setHandlInst(FtrsConst.SEND_HANDLINST_DMA);	  	//Tag : 21, 1= DMA
			fixVo.setOrderId(orderId);                          	//Tag : 37         //삼성선물 주문번호 - 주문시 보내지 않는다.
			fixVo.setOrderQty(orderQty);                           	//Tag : 38

			fixVo.setOrdType(FtrsConst.SEND_ORDER_TYPE_LIMIT);     	//Tag : 40 ,      2=Limit   4=Stop Limit -- 케이지트레이딩에서는 2번만 사용
			fixVo.setOrigClOrdId(origClOrdId);              		//Tag : 41         //취소주문시에만 보낸다.
			fixVo.setPrice(price);                        		  	//Tag : 44
			fixVo.setSide(side);                                   	//Tag : 54

			/*
			 * ************* Tag : 55 - 삼성증권 *************
			 * 상품코드 + 'M03' (ex : LALM03)
			 * Zinc(아연) : LZNM03
			 * Lead(납) : LPBM03
			 * Copper(구리) : LCUM03
			 * Aluminium(알루미늄) : LALM03
			 * Nickel(니켈) : LNIM03
			 * Tin(주석) : LSNM03
			 * ************* Tag : 55 - 이베스트 *************
			 * Aluminium(알루미늄) : L3MAL
			 * Copper(구리) 		: L3MCU
			 * Nickel(니켈) 		: L3MNI
			 * Lead(납)  		: L3MPB
			 * Tin(주석) 			: L3MSN
			 * Zinc(아연) 		: L3MZN
			 */
			String FIX_SYMBOL = param.getFixItemCode();
			fixVo.setSymbol(FIX_SYMBOL);

//			fixVo.setSymbol(param.getRequstFtrsItemCode()+ FtrsConst.SEND_SYMBOL_SAMSUNG_M03);
//			fixVo.setTransactTime(DateUtil.calDate(FtrsConst.FIX_DATE_FORMAT1));      //Tag : 60 //BZ03 오류로 거래시간을 전문 보내기 전 시간으로 설정 23.06.20

			fixVo.setStopPx(StringUtils.EMPTY);                	  	//Tag : 99,  케이지트레이딩에서는 사용않함.
			fixVo.setSecurityType(FtrsConst.SEND_SECURITY_TYPE);					  //Fix Tag: 167 (문자열) - Future:선물
			fixVo.setSecurityExchange(FtrsConst.SEND_SECURITY_EXCHANGE);              //Fix Tag: 207
			fixVo.setCurrency(FtrsConst.SEND_CURRENCY);                    	 	      //Fix Tag: 15 (통화)
			fixVo.setPositionEffect(positionEffect);				//Tag : 77
			fixVo.setPositionNum(positionNum);

			return fixVo;
		} catch (Exception e) {
			log.error(getClass().getName(), e);
			throw new FtrsBizException("", "GetFixOrderData Error", e);
		}
	}

	/**
	 * 선물사로 주문 전에 데이터 validation 체크및 Fix 전문 데이터 생성을 한다.
	 * @param side - 1: 매수(Buy) 주문, 2:매도(Sell) 주문
	 * @param sendMsgTypeOr - D= New Order, F= Order Cancel Request
	 * @param commCodeList - 선물사 거래 item code 리스트
	 * @param ftrsBasData - 선물 주문 정보
	 * @return FtrsOrderRequstVo - Fix 전문 내용
	 * @exception Exception
	 */
	@Override
	public FtrsOrderRequstVo checkFtrsNewOrder(
			  char side
			, char sendMsgTypeOr
			, List<CommCodeVo> commCodeList, OrOrderFtrsBasVo ftrsBasData) throws FtrsBizException
	{

		try {
			String itemCode = ftrsBasData.getRequstFtrsItemCode();
			if (StringUtils.isBlank(itemCode)) {
				throw new FtrsBizException("", "1. 요청 선물 주문타입 코드에 오류가 있습니다. iemCode [" + itemCode + "]");
			}

//            String orderQty = ftrsBasData.getRequstOrderQy();
//			if (StringUtils.isBlank(orderQty) || Integer.valueOf(orderQty) != 1) {
//				throw new FtrsBizException("", "2. 수량에 오류가 있습니다. orderQty [" + orderQty + "]");
//			}

			String price = ftrsBasData.getRequstOrderUntpc();
			if (StringUtils.isBlank(price)) {
				throw new FtrsBizException("", "2. 주문단가에 오류가 있습니다. price [" + price + "]");
			}

			if (side != ftrsBasData.getRequstPostn()) {
				throw new FtrsBizException("", "3. 요청 포지션에 오류가 있습니다. side [" + side + "][" + ftrsBasData.getRequstPostn() + "]");
			}

			String requstFtrsCmpnyTrgetCode = ftrsBasData.getRequstFtrsCmpnyTrgetCode();
			if (StringUtils.isBlank(requstFtrsCmpnyTrgetCode)) {
				throw new FtrsBizException("", "4. 요청선물사에 값이 없습니다. ");
			}

			String ftrsCmpnyTrgetCode = ftrsBasData.getRequstFtrsCmpnyTrgetCode();
			CommCodeVo commonCodeVo = commCodeList.stream().filter(h -> StringUtils.equals(h.getSubCode(), itemCode)).findFirst().orElse(null);
			if(commonCodeVo == null) {
				throw new FtrsBizException("", "5.요청 선물 주문타입 코드에 오류가 있습니다. iemCode [" + itemCode + "]");
			}

			String fixItemCode  = "";
			String fixTargetCompid = "";
			if(StringUtils.equals(CommFtrsConstant.FTRS_SAMSUNG_CMPNY_CODE, ftrsCmpnyTrgetCode)) { //삼성선물
				fixItemCode = commonCodeVo.getCodeChrctrRefrnone();
				fixTargetCompid = this.FIX_TARGET_COMPID_SAMSUNG;
			}else if(StringUtils.equals(CommFtrsConstant.FTRS_EBEST_CMPNY_CODE, ftrsCmpnyTrgetCode)) { //EBEST
				fixItemCode = commonCodeVo.getCodeChrctrRefrntwo();
				fixTargetCompid = this.FIX_TARGET_COMPID_EBEST;
			}else {
				throw new FtrsBizException("", "6.요청 선물사 타입 코드에 오류가 있습니다. FTRS_CMPNY_TRGET_CODE [" + ftrsCmpnyTrgetCode + "]");
			}

			if (StringUtils.isBlank(fixItemCode)) {
				throw new FtrsBizException("", "7. 선물사별 적용 iemCode가 존재하지 않습니다.");
			}

			ftrsBasData.setFixItemCode(fixItemCode);             /* 선물사별 적용 item code */
			ftrsBasData.setFixTargetCompid(fixTargetCompid);     /* fix target Id */
			ftrsBasData.setMsgType(sendMsgTypeOr); 	             /* 메세지 타입:  FtrsConst.SEND_MSG_TYPE_OR(주문), FtrsConst.SEND_MSG_TYPE_CR(취소)*/

			return this.getFixOrderData(ftrsBasData);

		} catch (Exception e) {
			log.error(getClass().getName(), e);
			throw new FtrsBizException("", "checkFtrsNewOrder Error", e);
		}
	}

}
