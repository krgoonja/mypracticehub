package com.sorincorp.api.samsung.ft.socket;

import java.net.Socket;

import com.sorincorp.api.samsung.ft.model.FtrsOrderRspnsVo;

public abstract interface FixServiceIf {
	public abstract void startRequestService(Socket paramSocket);
	public abstract void startResponseService(Socket paramSocket);
	public abstract void setOrderLink(boolean bo);
	public abstract boolean isOrderLink();

	public abstract void setReceiveLink(boolean bo);
//    public abstract boolean isReceiveLink();
    public abstract void setReceiveTime();

//	public void setTestTime(long l);
//	public long getTestTime();

	public void addRcvData(FtrsOrderRspnsVo vo);
}
