package com.sorincorp.api.util;

public class APICmmnConst {
	public static final String SUCCESS_RESULT_CODE = "200";

	public static final String ERROR_RESULT_CODE = "500";

	public static final String SUCCESS_RESULT_MSG = "Success";

	public static final String ERROR_RESULT_MSG = "Error";
}
