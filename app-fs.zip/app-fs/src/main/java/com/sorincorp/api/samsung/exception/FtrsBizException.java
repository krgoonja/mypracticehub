package com.sorincorp.api.samsung.exception;

/**
 * FtrsFxBizException.java
 * 삼성선물관의 Business Exception을 처리한다.
 * @version
 * @since 2021. 7. 7.
 * @author srec0032
 */
@SuppressWarnings("serial")
public class FtrsBizException extends RuntimeException{

	private String errorCode = "";
	private String bizMessage= "";

	public FtrsBizException(String errorCode) {
		super();
		this.errorCode = errorCode;
	}

	public FtrsBizException(String errorCode, String message) {
		super(message);
		this.errorCode = errorCode;
		this.bizMessage= message;
	}

	public FtrsBizException(String errorCode, Throwable cause) {
		super(cause);
		this.errorCode = errorCode;
	}

	public FtrsBizException(String errorCode, String message, Throwable cause) {
		super(message, cause);
		this.errorCode = errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public String getBizMessage() {
		return bizMessage;
	}
}
