package com.sorincorp.api.samsung.ft.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class CommCodeVo {

	/******  JAVA VO CREATE : CO_CMMN_CD(공통_공통 코드)                                                                                     ******/
    /**
     * 메인 코드
    */
    private String mainCode;
    /**
     * 서브 코드
    */
    private String subCode;
    /**
     * 코드 명
    */
    private String codeNm;
    /**
     * 코드 길이
    */
    private int codeLt;
    /**
     * 코드 순서
    */
    private int codeOrdr;
    /**
     * 코드 설명1
    */
    private String codeDcone;
    /**
     * 코드 설명2
    */
    private String codeDctwo;
    /**
     * 코드 참조1
    */
    private String codeRefrnone;
    /**
     * 코드 참조2
    */
    private String codeRefrntwo;
    /**
     * 코드 참조3
    */
    private String codeRefrnthree;
    /**
     * 코드 문자 참조1
    */
    private String codeChrctrRefrnone;
    /**
     * 코드 문자 참조2
    */
    private String codeChrctrRefrntwo;
    /**
     * 코드 문자 참조3
    */
    private String codeChrctrRefrnthree;
    /**
     * 코드 문자 참조4
    */
    private String codeChrctrRefrnfour;
    /**
     * 코드 문자 참조5
    */
    private String codeChrctrRefrnfive;
    /**
     * 코드 문자 참조6
    */
    private String codeChrctrRefrnsix;
    /**
     * 코드 숫자 참조1
    */
    private java.math.BigDecimal codeNumberRefrnone;
    /**
     * 코드 숫자 참조2
    */
    private java.math.BigDecimal codeNumberRefrntwo;
    /**
     * 코드 숫자 참조3
    */
    private java.math.BigDecimal codeNumberRefrnthree;
    /**
     * 코드 숫자 참조4
    */
    private java.math.BigDecimal codeNumberRefrnfour;
    /**
     * 시스템 여부
    */
    private String sysAt;
    /**
     * 외부 시스템 사용 여부
    */
    private String extrlSysUseAt;
    /**
     * 사용 여부
    */
    private String useAt;
    /**
     * 외부 시스템 연동 여부
    */
    private String extrlSysIntrlckAt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
    /**
     * 외부 시스템 메인 코드
    */
    private String extrlSysMainCode;

}
