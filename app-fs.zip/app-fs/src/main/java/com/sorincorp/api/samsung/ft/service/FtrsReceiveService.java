package com.sorincorp.api.samsung.ft.service;

import com.sorincorp.api.samsung.ft.model.FtrsOrderRspnsVo;

public interface FtrsReceiveService {

	void sendResponseLinkData(int curNum) throws Exception;

	void insertFtrsReceiveHeader(FtrsOrderRspnsVo vo, int curNum) throws Exception;

	void saveFtrsReceiveResponse(FtrsOrderRspnsVo vo) throws Exception;

	int selectIfFtrsRcvSeqNumber() throws Exception;

}
