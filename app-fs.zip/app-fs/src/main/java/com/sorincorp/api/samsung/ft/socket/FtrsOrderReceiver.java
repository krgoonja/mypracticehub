package com.sorincorp.api.samsung.ft.socket;

import java.io.BufferedInputStream;
import java.io.IOException;

import com.sorincorp.api.samsung.ft.handler.FixDataCnclsExecutor;
import com.sorincorp.api.samsung.ft.model.FtrsOrderRspnsVo;
import com.sorincorp.api.util.ApiCmmnUtil;
import com.sorincorp.api.util.BeanUtils;
import com.sorincorp.api.util.FtrsCmmnConst;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FtrsOrderReceiver extends Thread {
	private boolean run;
	private FixSocketWrapper socketWrapper = null;
	private String sender_nm;
	private FixDataCnclsExecutor cnclsExecutor;

	private FixServiceIf service;
	public FtrsOrderReceiver(FixServiceIf svcIf, String name, FixSocketWrapper s) throws Exception {
		super(name);
		setDaemon(true);

		if (s == null)
			throw new Exception("FtrsOrderReceiver.socket is null");

		this.sender_nm = name;
		this.socketWrapper = s;
		this.run = true;

		this.service = svcIf;
		cnclsExecutor = (FixDataCnclsExecutor)BeanUtils.getBean(FixDataCnclsExecutor.class);
		/* DataLoad와 Rcv Sequence 맞추기 위해 매일 아침 또는 서버 Start시 초기화한다. */
		if(!FtrsCmmnConst.isInitDailyRcvDataCount) {
			cnclsExecutor.initDailyRcvDataCount();
		}

		log.info( "[{}] Start", this.sender_nm);
	}

	public final void run() {
		/* 응답시간 설정 */
		service.setReceiveTime();

		int iRslt = 0;
		try{
			do {
				try {
					iRslt = readData();
				} catch (Exception e) {
					log.error( "FtrsOrderReceiver {}-{}", e.getClass().getName(), e.getMessage());
					iRslt = -1;
				}
				if (iRslt == -1) {
					break;
				} else if (iRslt == 999) {
					try {
						Thread.sleep(10);
					} catch(InterruptedException ie){
						break;
					} catch (Exception e) {}
				}
			} while (this.run);
		}catch(Exception e){
		}finally{
			close();
			log.error( "[{}] is Terminated!!! [{}]", this.sender_nm, this.run);
		}
	}

	private int readData() throws IOException {
		BufferedInputStream bis = socketWrapper.getInputStream();
		int size = bis.available();
		if (size <= 0) {
			if (size == 0) {
				return 999;
			} else {
				return -1;
			}
		}

		try {
			/* 응답시간 설정 */
			service.setReceiveTime();

			byte[] dataInfo     = new byte[8];
			bis.read(dataInfo, 0, 8);
			//Data 응답에 대해서 598 byte 수신
			//선물사 다중화로 BODY 부분이 46byte 증가 (562->608)
			String strBodyLength = ApiCmmnUtil.bytes2String(dataInfo, 0, 4);
			String headerType    = ApiCmmnUtil.bytes2String(dataInfo, 4, 4);

			int bodyLength       = Integer.parseInt(strBodyLength);
			int totLength        = (bodyLength+4);
			int iReadSize        = 0;
			FtrsOrderRspnsVo vo = new FtrsOrderRspnsVo();
			if(totLength==50) {
				byte headBuff[] = new byte[42];
				iReadSize = bis.read(headBuff);
				vo.decodeResponseRcvHeader(headBuff, strBodyLength, headerType);
				service.addRcvData(vo);
			}else if(totLength>50) {
				byte totBuff[] = new byte[totLength-8];
				iReadSize = bis.read(totBuff);

				byte headBuff[] = new byte[42];
				System.arraycopy(totBuff, 0, headBuff, 0, 42);

				int datalength  = (iReadSize - 42);
				byte bodyBuff[] = new byte[datalength];

				System.arraycopy(totBuff, 42, bodyBuff, 0, datalength);

				vo.decodeResponseRcvHeader(headBuff, strBodyLength, headerType);
				vo.decodeResponseData(bodyBuff);

				service.addRcvData(vo);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}

		return 0;
	}

	/* send link data */
	protected void sendResponseLinkData() throws IOException {
		this.cnclsExecutor.sendResponseLinkData();
	}

	protected void sendData(byte[] data) throws IOException {
		try {
			synchronized (socketWrapper) {
				if(log.isInfoEnabled())
					cnclsExecutor.printCntctSendData(data);

				this.socketWrapper.write(data);
			}
		} catch (IOException ie) {
			try{
				ie.printStackTrace();
				this.close();
			}catch(Exception e){}
			throw ie;
		} catch (Exception e) {
			try{
				this.close();
				log.error( "FtrsOrderReceiver.sendData Error :{}", e.getMessage());
			}catch(Exception e1){}
		}
	}

	protected FixSocketWrapper getTcpCommunicator() {
		return this.socketWrapper;
	}

	protected void close() {
		try {
			setRun(false);
			if (this.socketWrapper != null) {
				this.socketWrapper.close();
				this.socketWrapper = null;
			}
		} catch (Exception e) {}
	}

	public void setRun(boolean run) {
		this.run = run;
	}
}