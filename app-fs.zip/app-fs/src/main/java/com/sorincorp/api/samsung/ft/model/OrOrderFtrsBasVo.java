package com.sorincorp.api.samsung.ft.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class OrOrderFtrsBasVo {

	    /** 메세지 유형 */
		char msgType;				/*	char(1)		D= New Order							Tag: 35 */
    								/*				F= Order Cancel Request0 */
    								/*				G= Order Cancel/Replace Request */

	    /**
	     * 선물 요청 주문 번호
	    */
	    private String ftrsRequstOrderNo;
	    /**
	     * 주문 번호
	    */
	    private String orderNo;
	    /**
	     * 주문 순번
	    */
	    private String orderSn;
	    /**
	     * 취소 교환 반품 번호
	    */
	    private String canclExchngRtngudNo;
	    /**
	     * 취소 교환 반품 순번
	    */
	    private String canclExchngRtngudSn;
	    /**
	     * 요청 선물 주문 타입 코드
	     * 10: 주문
	     * 20: 정정
	     * 30: 취소
	    */
	    private String requstFtrsOrderTyCode;
		/**
	     * 요청 계좌 번호
	    */
	    private String requstAcnutNo;
	    /**
	     * 요청 주문 수량
	    */
	    private String requstOrderQy;

	    /**
	     *  요청 취소 선물 주문번호
	     */
	    private String requstCanclFtrsOrderNo;

	    /**
	     * 요청 원 주문 번호
	    */
	    private String requstWonOrderNo;
	    /**
	     * 요청 주문 단가
	    */
	    private String requstOrderUntpc;
	    /**
	     * 요청 포지션
	    */
	    private char requstPostn;
	    /**
	     * 요청 선물 종목 코드
	    */
	    private String requstFtrsItemCode;
	     /**
	     * 요청 청산 주문 여부
	     */
	    private char requstLqdOrderAt;
	     /**
	     * 요청 청산 포지션 번호
	     */
	    private String requstLqdPostnNo;

	    /**
	     * 응답 선물 주문 번호
	    */
	    private String rspnsFtrsOrderNo;
	    /**
	     * 응답 선물 상태 코드
	    */
	    private String rspnsFtrsSttusCode;
	    /**
	     * 응답 선물 체결 수량
	    */
	    private String rspnsFtrsCnclsQy;
	    /**
	     * 삭제 여부
	    */
	    private String deleteAt;
	    /**
	     * 삭제 일시
	    */
	    private java.sql.Timestamp deleteDt;
	    /**
	     * 최초 등록자 아이디
	    */
	    private String frstRegisterId;
	    /**
	     * 최초 등록 일시
	    */
	    private java.sql.Timestamp frstRegistDt;
	    /**
	     * 최종 변경자 아이디
	    */
	    private String lastChangerId;
	    /**
	     * 최종 변경 일시
	    */
	    private java.sql.Timestamp lastChangeDt;
	    /**
	     * 최초 선물 요청 주문 번호
	     */
	    private String frstFtrsRequstOrderNo;
	    /**
	     * 요청 선물사 구분 코드
	     */
	    private String requstFtrsCmpnySeCode;
	    /**
	     * 요청 선물사 대상 코드
	     */
	    private String requstFtrsCmpnyTrgetCode;
	    /*
	     * 요청 선물사 구분 코드(TCODE)
	     */
	    private String ftrsprofsSeCode;
	    /*
	     * 요청 선물사 대상 코드
	     */
	    private String ftrsCmpnyTrgetCode;
	    /**
	     * 선물사별 전용 종목 코드
	    */
	    private String fixItemCode;
	    /**
	     * FIX 타겟 ID
	     */
	    private String fixTargetCompid;

	    /*
	     * 단위 테스트 타입(A: 일반테스트-25톤 단위 생성, B: 부분체결 테스트 - 전체 중량으로 테스트, 100톤 등)
	     */
	    private String testType;
}
