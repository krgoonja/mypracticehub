package com.sorincorp.api.samsung.ft.mapper;

import java.util.List;

import com.sorincorp.api.samsung.ft.model.CommCodeVo;
import com.sorincorp.api.samsung.ft.model.FtrsOrderRequstVo;
import com.sorincorp.api.samsung.ft.model.FtrsOrderRspnsVo;
import com.sorincorp.api.samsung.ft.model.ItPurchsInfoBasVo;
import com.sorincorp.api.samsung.ft.model.OrOrderFtrsBasVo;
import com.sorincorp.api.samsung.ft.model.OrOrderFtrsDtlVo;

public interface FtrsMapper {

	/** 테스트 관련 쿼리 */
	int insertTestDataFtrsNewOrder(OrOrderFtrsBasVo vo) throws Exception;

	/** 테스트 관련 쿼리 */
	List<OrOrderFtrsBasVo> selectTestOrOrderFtrsBasList(OrOrderFtrsBasVo vo)  throws Exception;

	/* OR_ORDER_FTRS_BAS 테이블 */
	/**
	 * <pre>
	 * 처리내용: 응답 선물 상태 코드 리스트를 조회한다.
	 * </pre>
	 * @date 2021. 9. 14.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 14.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @return
	 * @throws Exception
	 */
	List<OrOrderFtrsBasVo> selectRspnsFtrsSttusCodeList(OrOrderFtrsBasVo searchVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: OR_ORDER_FTRS_BAS(주문_주문 선물 기본) 테이블의 데이터중 Order 데이터를 조회 한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<OrOrderFtrsBasVo> selectOrderFtrsList(OrOrderFtrsBasVo vo)  throws Exception;

	/**
	 * <pre>
	 * 처리내용: OR_ORDER_FTRS_BAS(주문_주문 선물 기본) 테이블의 데이터중 Claim 데이터를 조회 한다.
	 * </pre>
	 * @date 2021. 10. 26.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 26.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param claimOrder
	 * @return
	 */
	List<OrOrderFtrsBasVo> selectClaimFtrsList(OrOrderFtrsBasVo claimOrder);
	/**
	 * <pre>
	 * 처리내용: OR_ORDER_FTRS_DTL(주문_주문 선물 상세) 테이블을 조회한다.
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<OrOrderFtrsDtlVo> selectOrOrderFtrsDtlList(OrOrderFtrsDtlVo vo)  throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문시 삼성선물로 부터 받은 만기일, 상태등을 update한다.
	 * </pre>
	 * @date 2021. 9. 6.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 6.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int updateOrderFtrsBasWithRspnsVo(OrOrderFtrsBasVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: EBEST 만기 데이터 수신시 중복 데이터 발생 가능으로 UPDATE 쿼리 추가
	 * </pre>
	 * @date 2023. 10. 30.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 30.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int updateFtrsDtlWithEbestExprtnData(FtrsOrderRspnsVo vo) throws Exception;

	int insertOrderFtrsDtlWithRspnsVo(FtrsOrderRspnsVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 잔량 취소시 원주문의 상태 코드를 UPDATE한다.
	 * </pre>
	 * @date 2021. 9. 16.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 16.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param orgFtrsBasVo
	 * @return
	 */
	int updateOrFtrsBasOrgOrderStatus(OrOrderFtrsBasVo orgFtrsBasVo);


	/**
	 * <pre>
	 * 처리내용: 	IF_FTRS_ORDER_REQUST 테이블의 MAX ResHeaderSequenceNumber를 조회 한다.
	 * </pre>
	 * @date 2021. 11. 29.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 29.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param fixTargetEnginid
	 * @return
	 * @throws Exception
	 */
	int selectIfFtrsOrderSeqNumber(String fixTargetEnginid) throws Exception;

	/**
	 * <pre>
	 * 처리내용: IF_FTRS_ORDER_RSPNS 테이블의 Max HeaderSequenceNumber를 조회한다.
	 * </pre>
	 * @date 2021. 11. 29.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 29.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param fixTargetEnginid
	 * @return
	 * @throws Exception
	 */
	int selectIfFtrsRcvSeqNumber(String fixTargetEnginid) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 삼성선물에 전송하는 전문내용을 IF_FTRS_ORDER_REQUST 테이블에 저장한다.(LINK, POLL, DATA등)
	 * </pre>
	 * @date 2021. 11. 2.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 2.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int insertIfFtrsOrderRequst(FtrsOrderRequstVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 삼성선물 응답 데이터중 Link, POLL DATA를 인터페이스 테이블에 저장한다.
	 * </pre>
	 * @date 2021. 11. 29.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 29.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int insertIfFtrsOrderRspnHeader(FtrsOrderRspnsVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 삼성선물 응답 데이터를 인터페이스 테이블에 저장한다.
	 * </pre>
	 * @date 2021. 9. 6.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 6.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int insertIfFtrsOrderRspn(FtrsOrderRspnsVo vo) throws Exception;

	/**
	 * 공통코드 목록 조회
	 * @return
	 * @throws Exception
	 */
	List<CommCodeVo> selectListCoCmmnCd(CommCodeVo commCodeVo) throws Exception;

	/**
	 * <pre>
	 * 선물요청주문번호에 매핑되는 주문_주문 선물 기본 정보 조회
	 * </pre>
	 * @date 2023. 1. 9.
	 * @author srec0051
	 * @param ftrsBasVo
	 * @return
	 */
	OrOrderFtrsBasVo selecOrderFtrsBasInfo(OrOrderFtrsBasVo ftrsBasVo) throws Exception;

	/**
	 * <pre>
	 * 클레임 선물 주문 재처리를 위해 PO 테이블의 만기일 등을 조회한다.
	 * </pre>
	 * @date 2023. 1. 9.
	 * @author srec0051
	 * @param ftrsBasVo
	 * @return
	 */
	ItPurchsInfoBasVo selectClaimPurchsInfo(OrOrderFtrsBasVo ftrsBasVo) throws Exception;

	/**
	 * <pre>
	 * PO 테이블 선물 만기일자 수정
	 * </pre>
	 * @date 2023. 1. 9.
	 * @author srec0051
	 * @param itPurchsInfoBasVo
	 */
	int updateExprtndeItPurchsInfoBas(ItPurchsInfoBasVo itPurchsInfoBasVo) throws Exception;

	/**
	 * <pre>
	 * PO 테이블 히스토리 등록
	 * </pre>
	 * @date 2023. 1. 9.
	 * @author srec0051
	 * @param itPurchsInfoBasVo
	 * @return
	 */
	int insertItPurchsInfoBasHst(ItPurchsInfoBasVo itPurchsInfoBasVo) throws Exception;
}
