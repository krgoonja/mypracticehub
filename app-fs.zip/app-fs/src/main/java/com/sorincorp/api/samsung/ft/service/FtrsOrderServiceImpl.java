package com.sorincorp.api.samsung.ft.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.sorincorp.api.samsung.exception.FtrsBizException;
import com.sorincorp.api.samsung.ft.handler.FixDataOrderExecutor;
import com.sorincorp.api.samsung.ft.mapper.FtrsMapper;
import com.sorincorp.api.samsung.ft.model.CommCodeVo;
import com.sorincorp.api.samsung.ft.model.FtrsOrderRequstVo;
import com.sorincorp.api.samsung.ft.model.OrOrderFtrsBasVo;
import com.sorincorp.api.util.FtrsConst;
import com.sorincorp.comm.message.service.SMSService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ComponentScan({"com.sorincorp.comm."})
@Service("orderSendService")
public class FtrsOrderServiceImpl implements FtrsOrderService {

	@Autowired
	private FtrsMapper ftrsMapper;
	@Autowired
	private FixDataOrderExecutor fixDataOrderExecutor;
	@Autowired
	private FtrsProcessService procService;
	@Autowired
	SMSService smsService;


	/**
	 * 삼성선물 신규 주문 처리한다..
	 * @param OrOrderFtrsBasVo - 신규 주문 정보 VO
	 * @return
	 * @exception Exception
	 */
	@Override
	public void saveFtrsNewOrder(OrOrderFtrsBasVo ordInfo) throws Exception {

		ordInfo.setRequstFtrsOrderTyCode(FtrsConst.FIX_ORDER_NEW); /* 신규 주문 코드 등록 */

		/**
		 * ftrsRequstOrderNo 번호 존재시 개별 선물 재요청 조회
		 */
		List<OrOrderFtrsBasVo> resultList = ftrsMapper.selectOrderFtrsList(ordInfo);
		if (CollectionUtils.isEmpty(resultList)) {
			log.error("선물 신규 매수 주문 정보가 존재하지 않습니다. 주문 번호 :{}", ordInfo.getOrderNo());
			throw new Exception("선물 신규 매수 주문 정보가 존재하지 않습니다. [수신 주문번호 : " + ordInfo.getOrderNo() + "]");
		}

		try {
			List<FtrsOrderRequstVo> list = new ArrayList<FtrsOrderRequstVo>();

			/**
			 * 선물 거래 금속 코드 목록 조회
			 * 1. MAIN_CODE가 "REQUST_FTRS_ITEM_CODE"인 공통 코드
			 * */
			CommCodeVo commCodeVo = new CommCodeVo();
			commCodeVo.setMainCode("REQUST_FTRS_ITEM_CODE");
			List<CommCodeVo> commCodeList = ftrsMapper.selectListCoCmmnCd(commCodeVo);

			for (OrOrderFtrsBasVo ftrsBasData : resultList) {
				try {
					/* 신규 Order :  D */
					FtrsOrderRequstVo fixVo = procService.checkFtrsNewOrder('1', FtrsConst.SEND_MSG_TYPE_OR, commCodeList, ftrsBasData);
		            list.add(fixVo);

				} catch (Exception e) {
					innerDepartmentSendSms(ftrsBasData.getOrderNo(), ftrsBasData.getFtrsRequstOrderNo(), e.getMessage());
					throw new FtrsBizException("", e.getMessage());
				}
			} // end for

			//삼성선물 전송
			if (!CollectionUtils.isEmpty(list)) {
				List<FtrsOrderRequstVo> sendResultList = fixDataOrderExecutor.doSendData(list);

				//실패시 상태코드 수정
				if (!CollectionUtils.isEmpty(sendResultList)) {
					procService.updateFtrsOrderSendResult(sendResultList);

				} else {
					procService.updateFtrsOrderSendResult(list);
				}
			}

		} catch (Exception e) {
			procService.saveFtrsOrderValidResult(resultList);

			if (e instanceof FtrsBizException) {
				log.error("FtrsBizException", e);
				throw (FtrsBizException)e;
			} else {
				log.error("Exception", e);
				throw e;
			}
		}
	}

	/**
	 * 삼성선물 주문 취소 처리한다..
	 * @param OrOrderFtrsBasVo - 신규 주문 정보 VO
	 * @return
	 * @exception Exception
	 */
	@Override
	public void saveFtrsCancelOrder(OrOrderFtrsBasVo ordInfo) throws Exception {
		ordInfo.setRequstFtrsOrderTyCode(FtrsConst.FIX_ORDER_CANCEL); /* 취소 주문 코드 등록 */

		List<OrOrderFtrsBasVo> resultList = ftrsMapper.selectOrderFtrsList(ordInfo);

		if (CollectionUtils.isEmpty(resultList)) {
			log.error("선물 주문취소 존재하지 않습니다. 주문 번호 :{}", ordInfo.getOrderNo());
			throw new Exception("주문취소 데이터가 존재하지 않습니다. [수신 주문번호 : " + ordInfo.getOrderNo() + "]");
		}

		try {
			/**
			 * 선물 거래 금속 코드 목록 조회
			 * 1. MAIN_CODE가 "REQUST_FTRS_ITEM_CODE"인 공통 코드
			 * */
			CommCodeVo commCodeVo = new CommCodeVo();
			commCodeVo.setMainCode("REQUST_FTRS_ITEM_CODE");
			List<CommCodeVo> commCodeList = ftrsMapper.selectListCoCmmnCd(commCodeVo);

			List<FtrsOrderRequstVo> list = new ArrayList<FtrsOrderRequstVo>();
			for (OrOrderFtrsBasVo cnclBasData : resultList) {
				String requstWonOrderNo   = cnclBasData.getRequstWonOrderNo();

				if (StringUtils.isBlank(requstWonOrderNo)) {
	            	throw new FtrsBizException("", "취소 요청을 위한 원주문번호가 존재하지 않습니다. requstWonOrderNo [" + requstWonOrderNo + "]");
	            }

				/* Order Cancel/Replace Request :  F */
				FtrsOrderRequstVo fixVo = procService.checkFtrsNewOrder('1', FtrsConst.SEND_MSG_TYPE_CR, commCodeList, cnclBasData);
            	list.add(fixVo);
			}

			//삼성선물 전송
			if (!CollectionUtils.isEmpty(list)) {
				List<FtrsOrderRequstVo> sendResultList = fixDataOrderExecutor.doSendData(list);

				//실패시 상태코드 수정
				if (!CollectionUtils.isEmpty(sendResultList)) {
					procService.updateFtrsOrderSendResult(sendResultList);
				} else {
					procService.updateFtrsOrderSendResult(list);
				}
			}

		} catch (Exception e) {
			procService.saveFtrsOrderValidResult(resultList);

			if (e instanceof FtrsBizException) {
				log.error("FtrsBizException", e);
				throw (FtrsBizException)e;
			} else {
				log.error("Exception", e);
				throw e;
			}
		}
	}

	/**
	 * 실패 sms 추가 발송
	 */
	public void innerDepartmentSendSms(String orderNo, String returnMsg, String errMsg) {
		// templateNum : 45, smsSndngGroupCode : 41
		Map<String, String> smsMap = new HashMap<>();
		smsMap.put("templateNum", "45");
//		smsMap.put("smsSndngGroupCode", "41");
		smsMap.put("commerceNtcnCn", "선물 처리 실패"); // 커머스 알림 메시지
		smsMap.put("orderNo", orderNo);
		smsMap.put("returnMsg", returnMsg);
		smsMap.put("errMsg", errMsg);
		smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
		smsService.insertSMS(null, smsMap);
	}
}
