package com.sorincorp.api.config;

import java.util.concurrent.ThreadPoolExecutor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
public class ThreadPoolConfig {
	/** 스레드 사용 해제시간 **/
	@Value("${spring.thread.keepAliveSeconds}")
	public int keepAliveSeconds;

	/** 사용할 총 스레드 수 **/
	@Value("${spring.thread.corePoolSize}")
	public int corePoolSize;

	/** 스레드가 가득 차고 queue가 가득 찾을때 늘어나는 스레드 수 **/
	@Value("${spring.thread.maxPoolSize}")
	public int maxPoolSize;

	/** 스레드가 가득 찾을떄 대기하는 수 **/
	@Value("${spring.thread.queueCapacity}")
	public int queueCapacity;

	/** 스레드 명칭 **/
	@Value("${spring.thread.threadPrefix}")
	public String threadPrefix;

	/** 서버 강제 종료 시 대기 중인 스래드를 처리할 최대 시간 **/
	@Value("${spring.thread.terminationSeconds}")
	public int terminationSeconds;

	@Bean("samsungFsThreadPool")
	public ThreadPoolTaskExecutor excutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setAllowCoreThreadTimeOut(true);
		threadPoolTaskExecutor.setKeepAliveSeconds(keepAliveSeconds);
		threadPoolTaskExecutor.setCorePoolSize(corePoolSize);
		threadPoolTaskExecutor.setMaxPoolSize(maxPoolSize);
		threadPoolTaskExecutor.setQueueCapacity(queueCapacity);
		threadPoolTaskExecutor.setThreadNamePrefix(threadPrefix);

		/** 최대 스레드로 최대 queue 값 만큼 증가 됫을때 처리 방법 정의 **/
		threadPoolTaskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
		/** 서버 강제 종료 시 대기하고 있는 쓰레드를 처리할지 여부 **/
		threadPoolTaskExecutor.setWaitForTasksToCompleteOnShutdown(true);
		/** 서버 강제 종료 시 대기 중인 스래드를 처리할 최대 시간 **/
		threadPoolTaskExecutor.setAwaitTerminationSeconds(terminationSeconds);
		return threadPoolTaskExecutor;
	}
}
