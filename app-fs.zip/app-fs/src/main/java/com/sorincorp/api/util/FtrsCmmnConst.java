package com.sorincorp.api.util;

public class FtrsCmmnConst {
	public static boolean isInitDailySendDataOkCount;  /* 일별 DataLoad Send Sync Count 여부 */
	public static boolean isInitDailyRcvDataCount;     /* 일별 DataLoad Rcv Sync Count 여부 */

	/* 주문_주문 선물 기본 (OR_ORDER_FTRS_BAS) - 응답 선물 상태 코드 */
	public static final String RSPNS_FTRS_STTUS_CODE_ORDER_REQUST 		= "10"; 	/* 응답 선물 상태 코드 - 주문요청 */
	public static final String RSPNS_FTRS_STTUS_CODE_PART_CNCLS 		= "20";   /* 응답 선물 상태 코드 - 부분체결 */
	public static final String RSPNS_FTRS_STTUS_CODE_CANCL_REQUST 		= "21"; 	/* 응답 선물 상태 코드 - 부분 체결 후 취소 주문 요청 */
	public static final String RSPNS_FTRS_STTUS_CODE_PART_CNCLS_COMPT 	= "22"; 	/* 응답 선물 상태 코드 - 부분 체결 완료  */
	public static final String RSPNS_FTRS_STTUS_CODE_CNCLS_COMPT 		= "30";  	/* 응답 선물 상태 코드 - 체결완료 */
	public static final String RSPNS_FTRS_STTUS_CODE_UPDT_COMPT 		= "40";   /* 응답 선물 상태 코드 - 정정완료 */
	public static final String RSPNS_FTRS_STTUS_CODE_CANCL_COMPT 		= "50";  	/* 응답 선물 상태 코드 - 취소완료 */
	public static final String RSPNS_FTRS_STTUS_CODE_FAIL 				= "60";   /* 응답 선물 상태 코드 - 실패 */

	public static boolean EXTRLCNTCMNGR_SERVICE_INITIALIZE = false;
	public static boolean FTRS_RECEVIE_STATUS_OK = false;    /* FTRS 체결 응답 PROCESS 상태 */
	public static boolean FTRS_SEND_STATUS_OK = false;       /* FTRS 주문 요청 PROCESS 상태 */
}