package com.sorincorp.api.samsung.ft.socket;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;

public class FixSocketWrapper {
	private boolean closed;
	private Socket socket;
	private String readCharset;
	private String writeCharset;
	private String cmmunicatorNm;
	private BufferedInputStream bis;

	public FixSocketWrapper(Socket socket) throws IOException {
		this(socket, null, null);
	}

	public FixSocketWrapper(Socket _socket, String readCharset, String writeCharset) throws IOException {
		this.closed = false;
		this.socket = null;
		this.readCharset = null;
		this.writeCharset = null;

		if (_socket == null) {
			throw new IOException("Socket is null.");
		}
		this.readCharset = readCharset;
		this.writeCharset = writeCharset;
		this.socket = _socket;
		this.bis = new BufferedInputStream(_socket.getInputStream());

		this.cmmunicatorNm = "[FixSocketWrapper] Connecting [" + socket.getLocalPort() + "] TO [" + socket.getInetAddress() + ":" + socket.getPort() + "]";
		System.out.println(cmmunicatorNm);
	}

	public void setTimeOut(long milliTime) throws SocketException {
		setTimeOut((int) milliTime);
	}

	public void setTimeOut(int milliTime) throws SocketException {
		if (this.socket == null)
			throw new SocketException("Socket is null");
		try {
			this.socket.setSoTimeout(milliTime);
		} catch (SocketException se) {
			close();
			throw se;
		}
	}

	public synchronized boolean isCosed() {
		try{
			if (!this.closed && this.socket != null) {
				return this.socket.isClosed();
			}
		}catch(Exception e){}
		return this.closed;
	}

	public synchronized void close() {
		if (!(isCosed())) {
			destroy();
		}
		this.closed = true;
	}

	public synchronized void destroy() {
		this.closed = true;
		try {
			if (this.socket != null){
				this.socket.close();
			}
		} catch (IOException ie) {
		} catch(Exception e){
		}finally{
			if(this.bis != null) try{ this.bis.close(); }catch(Exception e){}
			if(this.socket != null) try {
				this.socket.close();
				this.socket = null;
			} catch (IOException e) {}
		}
	}

	public synchronized Socket getSocket() {
		return this.socket;
	}

	public BufferedInputStream getInputStream(){
		return this.bis;
	}

	public void write(byte[] data) throws IOException {
		try {
			BufferedOutputStream ostream = new BufferedOutputStream(this.socket.getOutputStream());
			if(ostream != null){
				ostream.write(data, 0, data.length);
				ostream.flush();
			}
		} catch (IOException ex) {
			close();
			throw ex;
		} catch(Exception e){
			e.printStackTrace();
		}
	}

	public void finalize() throws Throwable {
		close();
		super.finalize();
	}

	public String getReadCharset() {
		return this.readCharset;
	}

	public String getWriteCharset() {
		return this.writeCharset;
	}

	public String getSocketWrapName(String preFix) {
		String name = preFix;
		try {
			String str = this.socket.getInetAddress().getHostAddress();
			int port = this.socket.getPort();
			int localPort = this.socket.getLocalPort();
			name = preFix + str + ":" + port + " L=" + localPort;
		}catch(Exception e) {}
		return name;
	}
}