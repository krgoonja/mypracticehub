package com.sorincorp.api.samsung.ft.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.sorincorp.api.samsung.ft.handler.FtrsBfeProcHandler;
import com.sorincorp.api.samsung.ft.mapper.FtrsMapper;
import com.sorincorp.api.samsung.ft.model.FtrsOrderRspnsVo;
import com.sorincorp.api.samsung.ft.model.ItPurchsInfoBasVo;
import com.sorincorp.api.samsung.ft.model.OrOrderFtrsBasVo;
import com.sorincorp.api.samsung.mon.service.FsStateMonitorService;
import com.sorincorp.api.samsung.service.FtrsStateMonitorIsSaleTime;
import com.sorincorp.api.util.FtrsCmmnConst;
import com.sorincorp.api.util.FtrsConst;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@ComponentScan({"com.sorincorp.comm.*"})
public class FtrsReceiveServiceImpl implements FtrsReceiveService {

	private FtrsBfeProcHandler fixBfeProcess;

	@Value("${fix.target-compid.ebest}")       	 //EBEST_UAT - ebest증권사 추가(2023-06-23)
	private String FIX_TARGET_COMPID_EBEST;

	@Autowired
	private FtrsMapper ftrsMapper;

	@Autowired
	FsStateMonitorService monitorService;

	@Value("${fix.target-enginid}")
	private String fix_target_enginid;

	@Autowired
	private FtrsStateMonitorIsSaleTime ftrsStateMonitorIsSaleTime;

	@Autowired
	SMSService smsService;

	@Override
	public int selectIfFtrsRcvSeqNumber() throws Exception{
		String fixEngingId = this.fix_target_enginid;  		/* Target Fix Engin Id */
		return ftrsMapper.selectIfFtrsRcvSeqNumber(fixEngingId);
	}

	@Override
	public void sendResponseLinkData(int maxNumber) throws Exception{
		FtrsOrderRspnsVo header = null;
		try {
			String strNumber = StringUtil.padValue(String.valueOf(maxNumber), "0", 8, true);
			String strOrdBodyLen = StringUtil.padValue(String.valueOf(FtrsConst.DATAlOAD_COMM_LEN), "0", 4, true);

			header = new FtrsOrderRspnsVo();
			header.setTrgtEngineId(this.fix_target_enginid);	/* Target Fix Engin Id */
			header.setDataLength(strOrdBodyLen);
			header.setHeaderType(FtrsConst.DATALOAD_LINK_REQ);
			header.setTradeDate(ftrsStateMonitorIsSaleTime.getTradeDate());
			header.setFrstRegisterId("system");
			header.setLastChangerId("system");
			header.setSequenceNumber(strNumber);

			/*
			 * Step1. Fix 전달전 데이터 저장
			 */
			ftrsMapper.insertIfFtrsOrderRspnHeader(header);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if(fixBfeProcess == null) {
			fixBfeProcess = FtrsBfeProcHandler.getInstance();
		}

		fixBfeProcess.add(header);
	}

	@Override
	public void insertFtrsReceiveHeader(FtrsOrderRspnsVo vo, int okNumber) throws Exception {
		try {
			String fixEngingId = this.fix_target_enginid;  		/* Target Fix Engin Id */
			vo.setTrgtEngineId(fixEngingId);
			vo.setFrstRegisterId("system");
			vo.setLastChangerId("system");

			ftrsMapper.insertIfFtrsOrderRspnHeader(vo);

			String headerType 	= vo.getHeaderType();
			if(FtrsConst.DATALOAD_POLL_REQ.equals(headerType)) {
				int rcvSeqNum = Integer.parseInt(vo.getSequenceNumber());
				boolean isequal = true;
				if(rcvSeqNum != okNumber) {
					isequal = false;
				}

				sendReceiveDataLoadPoOk(vo, isequal, okNumber);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void saveFtrsReceiveResponse(FtrsOrderRspnsVo vo) throws Exception {
		/* 1. Target engin 설정 */
		vo.setTrgtEngineId(fix_target_enginid);
		// 계좌번호 암호화
		String account = vo.getAccount();
		try {
			vo.setAccount(CryptoUtil.encryptAES256(account));
		}catch(Exception e){
			vo.setAccount(account);
		}

		char msgType = vo.getMsgType();
		char ordStatus = vo.getOrdStatus();
		String origClOrdId = vo.getOrigClOrdId();
		String ftrsRequstOrderNo = vo.getClOrdId();
		String rspnsFtrsOrderNo = vo.getOrderId(); // 삼성선물 주문번호
		String rspnsFtrsCnclsQy = vo.getCumQty();  // 누적 체결수령

		/* 주문 성공 여부
		 * 주문 유형 - 신규주문, 취소주문
		 * 취소 주문시 원주문의 상태 코드도 변경
		 */
		log.info("1. Execute Data: MsgType[{}], Status[{}], OrgClOrdId[{}], FtrsRequstOrderNo[{}], RspnsFtrsOrderNo[{}], CnclsQy[{}]", msgType, ordStatus, origClOrdId, ftrsRequstOrderNo, rspnsFtrsOrderNo, rspnsFtrsCnclsQy);
		String rspnsFtrsSttusCode = this.getGspnsFtrsSttusCode(msgType, ordStatus);
		log.info("2. FtrsSttusCode:{}", rspnsFtrsSttusCode);

		OrOrderFtrsBasVo ftrsBasVo = new OrOrderFtrsBasVo();
		ftrsBasVo.setFtrsRequstOrderNo(ftrsRequstOrderNo);

		/**
		 * ftrsRequstOrderNo 대한 정보가 없을때 Null Exception 발생
		 * 이를 그대로 저장하게함.
		 */
		ftrsBasVo = ftrsMapper.selecOrderFtrsBasInfo(ftrsBasVo);
		if(ftrsBasVo == null) {
			ftrsBasVo = new OrOrderFtrsBasVo();
			ftrsBasVo.setFtrsRequstOrderNo(ftrsRequstOrderNo);

			log.error("관련된 선물 정보가 미존재. - {}", ftrsBasVo.toString());
		}
		/* 실패건 60 이면 실패 sms 발송
		 * 2022.09.21 특정 실패사유만 보냄 - [55704][USG] Original order not found
		 */
		if (StringUtils.equals(FtrsCmmnConst.RSPNS_FTRS_STTUS_CODE_FAIL, rspnsFtrsSttusCode)){
			String rejectResn = vo.getText()==null ? "null" : vo.getText().toLowerCase();
			if(rejectResn.indexOf("original order not found") > 0 ) {
				innerDepartmentSendSms(ftrsBasVo.getOrderNo(), ftrsRequstOrderNo, vo.getText());
			}
		}

		/*
		 * Step1. OR_ORDER_FTRS_BAS 테이블 update
		 * 2023-09-13 변경
		 * RSPNS_FTRS_STTUS_CODE_ORDER_REQUST : 10(주문 요청) 인 경우  OR_ORDER_FTRS_BAS 테이블의 상태를 업데이트 안한다.
		 * - EBEST에서는 응답데이터 순서가 역전이 되는 경우가 있어 "주문요청" 인 경우 상태 업데이트 안하기로 함.
		 * - EBEST에서는 순서에 대해 보정하기 위해서는 0.1~05초의 딜레이 예상하여 케이지트레이딩 소스만 변경하기로 함.
		 */
		ftrsBasVo.setRspnsFtrsOrderNo(rspnsFtrsOrderNo);
		ftrsBasVo.setRspnsFtrsSttusCode(rspnsFtrsSttusCode);
		ftrsBasVo.setRspnsFtrsCnclsQy(rspnsFtrsCnclsQy);

		log.info("===> Before update OR_ORDER_FTRS_BAS : {}", ftrsBasVo);
		int updRs = ftrsMapper.updateOrderFtrsBasWithRspnsVo(ftrsBasVo);
		log.info("3. update count:[{}]", updRs);

		/*
		 * Step2. IF_FTRS_ORDER_RSPNS 테이블 insert
		 */
		int insRs1 = ftrsMapper.insertIfFtrsOrderRspn(vo);
		log.info("4. insert count:[{}]", insRs1);

		/*
		 * step3. OR_ORDER_FTRS_DTL 테이블 insert
		 *        -> ebest 데이터 중 만기데이터에서 EXECUT_ID가 동일건에 대해서는 업데이트 한다.
		 */
		saveOrderFtrsDtlWithRspnsVo(vo);

		/* 취소 완료시 원주문의 주문 상태도 취소 완료로 변경.
		 * 2022.08.12 취소 성공시 SMS 발송 추가
		 */
		if (FtrsCmmnConst.RSPNS_FTRS_STTUS_CODE_CANCL_COMPT.equals(rspnsFtrsSttusCode)) {		//잔여 주문 취소 완료시(50)
			OrOrderFtrsBasVo xOrgFtrsBasVo = new OrOrderFtrsBasVo();
			xOrgFtrsBasVo.setFtrsRequstOrderNo(origClOrdId);
			xOrgFtrsBasVo.setRspnsFtrsSttusCode(FtrsCmmnConst.RSPNS_FTRS_STTUS_CODE_CANCL_COMPT);  //주문 취소 완료(50)
			int insRs3 = ftrsMapper.updateOrFtrsBasOrgOrderStatus(xOrgFtrsBasVo);
			log.info("6. insert count3:[" + insRs3 + "]");
			innerDepartmentSendSms(ftrsBasVo.getOrderNo(), origClOrdId, "선물 취소 완료");
		}

		// 2023.01.09 반대매매 주문 체결시 만기일이 PO 테이블과 다르면 PO 테이블 선물 만기일 update 처리
		// 체결 && 매도 && 주문 && 신규주문 (청산주문은 만기일자를 실어보내지 않는다)
		if (FtrsCmmnConst.RSPNS_FTRS_STTUS_CODE_CNCLS_COMPT.equals(rspnsFtrsSttusCode)
				&& StringUtils.equals(String.valueOf(ftrsBasVo.getRequstPostn()), "2")
				&& StringUtils.equals(ftrsBasVo.getRequstFtrsOrderTyCode(), "10")
				) {
			exprtndeCompareAndPoTbUpdate(ftrsBasVo);
		}

		/*
		 * 모니터링 상태 update
		 */
		saveFsWorkStatus(rspnsFtrsSttusCode);
	}

	/*
	 *  수신된 데이터로 OR_ORDER_FTRS_DTL 테이블 INSERT, UPDATE 한다.
	 *  EBEST 만기데이터는 중복될 수 있다는 가정으로 EBET 만기 데이터에 한해 UPDATE 수행
	 */
	private void saveOrderFtrsDtlWithRspnsVo(FtrsOrderRspnsVo rspnsVo) {
		try {
			int insRs2 = 0;
			String senderCompId = rspnsVo.getSenderCompId();
			char executTy = rspnsVo.getExecType();
			String lqdExecutId = StringUtils.trimToEmpty(rspnsVo.getPositionID());

			if(StringUtils.equals(senderCompId, FIX_TARGET_COMPID_EBEST)
					&& executTy== 'F' && StringUtils.isEmpty(lqdExecutId) ){

				insRs2 = ftrsMapper.updateFtrsDtlWithEbestExprtnData(rspnsVo);
				log.info("5-1. EBEST 만기 데이터, SENDER:{}:{}, insert or update count2:[{}]", senderCompId, FIX_TARGET_COMPID_EBEST, insRs2);
			}else {

				insRs2 = ftrsMapper.insertOrderFtrsDtlWithRspnsVo(rspnsVo);
				log.info("5-2. SENDER:{}, insert count2:[{}]", senderCompId, insRs2);
			}
		}catch(Exception e) {
			log.error("RCV DARA :[{}]", rspnsVo);
			log.error("saveOrderFtrsDtlWithRspnsVo", e);
		}
	}

	/**
	 * <pre>
	 * 매도주문 && 요청 만기일자가 PO 만기일자와 다르다면 PO 만기일자를 업데이트
	 * </pre>
	 * @date 2023. 1. 9.
	 * @author srec0051
	 * @param ftrsBasVo
	 */
	private void exprtndeCompareAndPoTbUpdate(OrOrderFtrsBasVo ftrsBasVo) {
		if (!StringUtils.equals(String.valueOf(ftrsBasVo.getRequstLqdOrderAt()), "N")) {
			log.error("PO 선물 만기일자 업데이트 불가 - 신규주문아님");
		} else {
		try {
			ItPurchsInfoBasVo itPurchsInfoBasVo = ftrsMapper.selectClaimPurchsInfo(ftrsBasVo);
			String requstExprtnde = ftrsBasVo.getRequstLqdPostnNo();
			String ftrsExprtnde = itPurchsInfoBasVo.getFtrsExprtnDe();

			if (!StringUtils.equals(requstExprtnde, ftrsExprtnde)) {
				itPurchsInfoBasVo.setFtrsExprtnDe(requstExprtnde);
				ftrsMapper.updateExprtndeItPurchsInfoBas(itPurchsInfoBasVo);
				ftrsMapper.insertItPurchsInfoBasHst(itPurchsInfoBasVo);
				log.info("PO 선물 만기일자 업데이트 - blNo:{}, 선물요청주문번호:{}", itPurchsInfoBasVo.getBlNo(), ftrsBasVo.getFtrsRequstOrderNo());
			}
		} catch (Exception e) {
			log.error("PO 선물 만기일자 업데이트 오류 - {}", e.getMessage());
		}
		}
	}

	private void saveFsWorkStatus(String rspnsFtrsSttusCode) {
		try {
			if ("30".equals(rspnsFtrsSttusCode)) {
				monitorService.checkFsWorkStatus(true);
			} else if ("60".equals(rspnsFtrsSttusCode)) {
				monitorService.checkFsWorkStatus(false);
			}
		}catch(Exception e) {
			log.error("updateFxWorkStatus:" + rspnsFtrsSttusCode, e);
		}
	}

	private void sendReceiveDataLoadPoOk(FtrsOrderRspnsVo rcvVo, boolean isequal, int okNumber) throws Exception{
		FtrsOrderRspnsVo header = null;
		try {
			String strNumber = StringUtil.padValue(String.valueOf(okNumber), "0", 8, true);
			String strOrdBodyLen = StringUtil.padValue(String.valueOf(FtrsConst.DATAlOAD_COMM_LEN), "0", 4, true);

			header = new FtrsOrderRspnsVo();
			header.setTrgtEngineId(this.fix_target_enginid);	/* Target Fix Engin Id */
			header.setTradeDate(rcvVo.getTradeDate());
			header.setFrstRegisterId(rcvVo.getFrstRegisterId());
			header.setLastChangerId(rcvVo.getLastChangerId());
			header.setSequenceNumber(strNumber);
			header.setDataLength(strOrdBodyLen);

			/* iseqal false일 경우 맞는 seq num 전송 필요 할것 */
			if(isequal) {
				header.setHeaderType(FtrsConst.DATALOAD_POLL_OK);
			}else {
				header.setHeaderType(FtrsConst.DATALOAD_EROR);
			}

			ftrsMapper.insertIfFtrsOrderRspnHeader(header);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Receive PoOk insert Error.", e);
		}

		if(fixBfeProcess == null) {
			fixBfeProcess = FtrsBfeProcHandler.getInstance();
		}

		if(header != null) {
			fixBfeProcess.add(header);
		}
	}

	/**
	 * <pre>
	 * 응답 선물 상태 코드
	 * </pre>
	 * @date 2023. 1. 9.
	 * @author srec0051
	 * @param msgType
	 * @param ordStatus
	 * @return
	 */
	private String getGspnsFtrsSttusCode(char msgType, char ordStatus) {
		/* 10. 주문 요청
			20. 부분 체결
			21. 부분 체결 후 취소 주문 요청
			30. 체결 완료
			40. 정정 완료
			50. 취소 완료
			60. 실패
		 */
		try {
			if(FtrsConst.RCV_MSG_TYPE_EXECUTION_REPORT == msgType){       		//8 = Execution Report
				//ExecType
				//신규 주문 A, 0, 8, F
				//취소 주문 6 -> 4, 8(REJECT)
				if(FtrsConst.RCV_ORD_STATUS_PENDING_NEW == ordStatus
						|| FtrsConst.RCV_ORD_STATUS_NEW == ordStatus
						|| FtrsConst.RCV_EXEC_TYPE_PENDING_CANCELED == ordStatus
						) {
					return FtrsCmmnConst.RSPNS_FTRS_STTUS_CODE_ORDER_REQUST;             //주문 요청(10)
				}else if(FtrsConst.RCV_ORD_STATUS_PARTIALLY_FILLED == ordStatus) {
					return FtrsCmmnConst.RSPNS_FTRS_STTUS_CODE_PART_CNCLS;               //부분 체결(20)
				}else if(FtrsConst.RCV_ORD_STATUS_FILLED == ordStatus) {
					return FtrsCmmnConst.RSPNS_FTRS_STTUS_CODE_CNCLS_COMPT;              //체결 완료(30)
				}else if(FtrsConst.RCV_ORD_STATUS_CANCELED == ordStatus
						|| FtrsConst.RCV_ORD_STATUS_EXPIRED == ordStatus ) {             //FtrsConst.RCV_ORD_STATUS_EXPIRED :장종료 후 이베스트에서는 'C' 로 넘어와 EC에서는 자동 취소 완료 처리 함.
					return FtrsCmmnConst.RSPNS_FTRS_STTUS_CODE_CANCL_COMPT;              //취소 완료(50)
				}else if(FtrsConst.RCV_ORD_STATUS_REJECTED == ordStatus) {
					return FtrsCmmnConst.RSPNS_FTRS_STTUS_CODE_FAIL;                     //실패(60)
				}else {
					return  "99";       //부분체결 후 취소주문요청은 어던 코드를 처리할지 미정
				}
			}else if(FtrsConst.RCV_MSG_TYPE_ORDER_CANCEL_REJECT == msgType
					|| FtrsConst.RCV_MSG_TYPE_BUSINESS_REJECT == msgType
					|| FtrsConst.RCV_MSG_TYPE_SESSION_REJECT == msgType
					) {
				//9 = Order Cancel Reject
				//j= Business Reject
				//3= Session Reject
				return FtrsCmmnConst.RSPNS_FTRS_STTUS_CODE_FAIL;
			}else {
				return "99";
			}
		}catch(Exception e) {
			log.error("getGspnsFtrsSttusCode:" + msgType + "," + ordStatus, e);
		}

		return "99";
	}


	/**
	 * 실패 sms 추가 발송
	 */
	private void innerDepartmentSendSms(String orderNo, String returnMsg, String errMsg) {
		try {
			Map<String, String> smsMap = new HashMap<>();
			smsMap.put("templateNum", "45");
			smsMap.put("commerceNtcnCn", "선물 처리 실패"); // 커머스 알림 메시지
			smsMap.put("orderNo", orderNo); // 주문번호
			smsMap.put("returnMsg", returnMsg); // 선물요청번호
			smsMap.put("errMsg", errMsg); // 실패사유 메세지
			smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
			smsService.insertSMS(null, smsMap);
		}catch(Exception e) {
			log.error("innerDepartmentSendSms", e);
		}
	}
}
