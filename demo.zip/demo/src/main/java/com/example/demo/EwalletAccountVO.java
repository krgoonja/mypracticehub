package com.example.demo;

import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EwalletAccountVO {
	
	/** 업체번호 **/
	@NotEmpty(message = "업체 번호 미존재")
	private String entrpsNo;
	
	/** Ewallet 가상 계좌 번호 **/
	private String ewalletAcnutNo;
	
	/** 거래 일자 **/
	private String delngDe;
	
	/** 거래 일련 번호 **/
	private String delngSeqNo;
	
	/** 거래 금액 ( 잔액 ) **/
	private String delngAmount;
	
	private String testCode; // 테스트 완료 후 제거 20211115
	
	public EwalletAccountVO(String entrpsNo) {
		this.entrpsNo = entrpsNo;
	}

}
