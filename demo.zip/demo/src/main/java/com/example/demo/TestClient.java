package com.example.demo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class TestClient {
	
	final static String SERVER_IP = "127.0.0.1"; 
	final static int SERVER_PORT = 45558;
	final static String MESSAGE_TO_SERVER = "050000092009502500006000000810970000009020051000004000202308221348590099999400200950256                                                                                                                                             000000 20970                                                            0001610000000 00001881080620000000000000000000810027591000859504                      200950250014891606926637                              00000                     00000                             ";
	
	//final static String MESSAGE_TO_SERVER = "         123456789012121234123112345612345678123456123412345678912345678901234512345678901123456789012345678901234512345678901231123456789012312345678901231234567890123123456789012311234567890123123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345";
	
	public static void main(String[] args) {
		
		Socket socket = null;
		
		try {
			/** 소켓통신 시작 */
			socket = new Socket(SERVER_IP,SERVER_PORT);
			System.out.println("socket 연결");
		
			/**	Client에서 Server로 보내기 위한 통로 */
			OutputStream os = socket.getOutputStream();
			/**	Server에서 보낸 값을 받기 위한 통로 */
			InputStream is = socket.getInputStream();
			
			os.write( MESSAGE_TO_SERVER.getBytes() );
			os.flush();
			
//			byte[] data = new byte[16];
//			int n = is.read(data);
//			final String resultFromServer = new String(data,0,n);
//			
//			System.out.println(resultFromServer);
			
			//socket.close();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}