package com.example.demo;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@ToString(callSuper = true)
public class EwalletAccountEntity extends EwalletBaseEntity{
	
	public EwalletAccountEntity(EwalletAccountVO ewalletAccountVO) {
		
		/* LENGTH */
		super.setBase1("0500");
		
		/* 전문구분코드(MSG TYPE) */
		super.setBase11("0200");
		
		/* 거래구분코드 */
		super.setBase12("2100");
		
		/* 항목구분코드 */
		super.setBase13("0000");
		
		/* 거래일련번호 */
		super.setBase17(ewalletAccountVO.getDelngSeqNo());
		
		/* 이체거래시 입출기관구분 */
		super.setBase28("0");
		
		/* 응답 메세지 */
		super.setBase29(ewalletAccountVO.getEntrpsNo());
		
		this.account11 = ewalletAccountVO.getEwalletAcnutNo();
	}
	
	/* 거래금액 */
	@ByteLimit(limit = 13, example = "0", repeat = true)
	private String account1;
	
	/* 양,음 구분표시 */
	@ByteLimit(limit = 1, example = " ")
	private String account2;

	/* 거래후 계좌잔액 */
	@ByteLimit(limit = 13, example = "0", repeat = true)
	private String account3;

	/* 미결제 타점권 금액 */
	@ByteLimit(limit = 13, example = "0", repeat = true)
	private String account4;

	/* 은행(제휴기관)코드 */
	@ByteLimit(limit = 8, example = " ", repeat = true)
	private String account5;

	/* 입금계좌구분코드 */
	@ByteLimit(limit = 2, example = "00")
	private String account6;

	/* 계좌번호(가상) */
	@ByteLimit(limit = 16, example = " ", repeat = true)
	private String account7;

	/* 입금계좌성명 */
	@ByteLimit(limit = 20, example = " ", repeat = true)
	private String account8;

	/* 은행(제휴기관)코드 */
	@ByteLimit(limit = 8, example = EwalletConstant.EWALLET_SORIN_CODE)
	private String account9;

	/* 출금계좌구분코드 */
	@ByteLimit(limit = 2, example = "00")
	private String account10;

	/* 계좌번호(가상) */
	@ByteLimit(limit = 16, require = true, fill = true, fillStr = " ")
	private String account11;

	/* 비밀번호 */
	@ByteLimit(limit = 8, example = " ", repeat = true)
	private String account12;

	/* 출금계좌성명 */
	@ByteLimit(limit = 20, example = " ", repeat = true)
	private String account13;

	/* 수수료금액 */
	@ByteLimit(limit = 5, example = "0", repeat = true)
	private String account14;

	/* 수표지급유무 */
	@ByteLimit(limit = 1, example = "0")
	private String account15;

	/* 수표시작번호 */
	@ByteLimit(limit = 8, example = " ", repeat = true)
	private String account16;

	/* 수표 매수 */
	@ByteLimit(limit = 3, example = "0", repeat = true)
	private String account17;
	
	/* 수표시작번호 */
	@ByteLimit(limit = 8, example = " ", repeat = true)
	private String account18;

	/* 수표 매수 */
	@ByteLimit(limit = 3, example = "0", repeat = true)
	private String account19;

	/* 취소 사유 */
	@ByteLimit(limit = 3, example = " ", repeat = true)
	private String account20;

	/* 거래관리번호 */
	@ByteLimit(limit = 12, example = " ", repeat = true)
	private String account21;

	/* 배분수수료금액 */
	@ByteLimit(limit = 5, example = "0", repeat = true)
	private String account22;

	/* FILLER */
	@ByteLimit(limit = 12, example = " ", repeat = true)
	private String account23;
}
