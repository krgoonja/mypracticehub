package com.example.demo;

import lombok.Data;

/**
 * EwalletBaseVO.java
 * @version
 * @since 2021. 7. 6.
 * @author Sim sung bo
 * 공통 헤더 전문
 */

@Data
public class EwalletBaseEntity {
	
	/* LENGTH */
	@ByteLimit(limit = 4, example = "0500", require = true)
	private String base1;
	
	/* CS번호 */
	@ByteLimit(limit = 4, example = "0009")
	private String base2;

	/* CS관리 기관코드 , 목적지 기관코드 */
	@ByteLimit(limit = 8, example = EwalletConstant.EWALLET_SORIN_CODE)
	private String base3;

	/* REACTION CODE */
	@ByteLimit(limit = 1, example = "0")
	private String base4;

	/* 연속거래번호 */
	@ByteLimit(limit = 3, example = "000")
	private String base5;

	/* 송수신 FLAG */
	@ByteLimit(limit = 1, example = "5")
	private String base6;

	/* 취급기관코드 */
	@ByteLimit(limit = 8, example = EwalletConstant.EWALLET_SORIN_CODE)
	private String base7;

	/* 취급영업점코드 */
	@ByteLimit(limit = 4, example = "    ")
	private String base8;

	/* 취급단말코드 */
	@ByteLimit(limit = 5, example = "00000")
	private String base9;

	/* 매체(발생)구분 */
	@ByteLimit(limit = 1, example = "7")
	private String base10;

	/* 전문구분코드(MSG TYPE) */
	@ByteLimit(limit = 4, example = "0200", require = true)
	private String base11;

	/* 거래구분코드 */
	@ByteLimit(limit = 4, example = "4100", require = true)
	private String base12;

	/* 항목구분코드 */
	@ByteLimit(limit = 4, example = "0000", require = true)
	private String base13;

	/* 응답코드 */
	@ByteLimit(limit = 3, example = "000")
	private String base14;

	/* 거래일자 */
	@ByteLimit(limit = 8, example = "20210629", day = true)
	private String base15;

	/* 거래시간 */
	@ByteLimit(limit = 6, example = "160722", time = true)
	private String base16;

	/* 거래일련번호 ( 7자리로 채번하여 생성 assignService 이용 )*/ 
	@ByteLimit(limit = 7, example = "0180970", require = true)
	private String base17;

	/* 한글코드 구분 */
	@ByteLimit(limit = 1, example = "4")
	private String base18;

	/* 마감후 구분 */
	@ByteLimit(limit = 1, example = "0")
	private String base19;

	/* 차액입금방법 */
	@ByteLimit(limit = 1, example = "0")
	private String base20;

	/* 개설기관코드 */ 
	@ByteLimit(limit = 8, example = EwalletConstant.EWALLET_SORIN_CODE)
	private String base21;

	/* M/S TRACK번호 */
	@ByteLimit(limit = 1, example = "0")
	private String base22;

	/* M/S TRACK DATA */
	@ByteLimit(limit = 141, example = " ", repeat = true)
	private String base23;

	/* 카드구분 */
	@ByteLimit(limit = 1, example = "0")
	private String base24;

	/* 카드일련번호 */
	@ByteLimit(limit = 3, example = "000")
	private String base25;
	
	/* ATM 거래가능 횟수 */
	@ByteLimit(limit = 2, example = "00")
	private String base26;
	
	/* 정형화된 조회 출력 구분 */
	@ByteLimit(limit = 1, example = " ")
	private String base27;
	
	/* 이체거래시 입출기관구분 */
	@ByteLimit(limit = 1, example = "1", require = true)
	private String base28;

	/* USER WORK AREA */
	@ByteLimit(limit = 14, example = " ", repeat = true, fill = true, fillStr = " ")
	private String base29;
	
	/* 응답 MESSAGE */
	@ByteLimit(limit = 50, example = " ", repeat = true, fill = true, fillStr = " ")
	private String base30;
	
	
}
