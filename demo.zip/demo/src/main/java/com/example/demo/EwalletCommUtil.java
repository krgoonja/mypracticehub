package com.example.demo;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EwalletCommUtil {

	/**
	 * <pre>
	 * 처리내용: 상속 받은 클래스의 field를 찾음
	 * </pre>
	 * @date 2021. 7. 7.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 7.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param fields
	 * @param type
	 */
	protected static void getSuperclassFields(List<Field> fields, Class<?> type) {
		if(type != null) {
			fields.addAll(0, Arrays.asList(type.getDeclaredFields()));
			getSuperclassFields(fields, type.getSuperclass());
		}
	}

	/**
	 * <pre>
	 * 처리내용: Byte를 Object Filed에 맵핑시켜준다.
	 * Parameter로 보내주는 class의 Field가 순서대로 정렬되어 있어야 정확한 값이 맵핑된다.
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 26.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param <T>
	 * @param receiveByte
	 * @param clazz
	 * @return
	 * @throws Exception
	 */
	public static <T> T getObjForBytes(byte[] receiveByte, Class<T> clazz) throws Exception {
		T obj = clazz.newInstance();
		List<Field> fields = new ArrayList<Field>();
		getSuperclassFields(fields, obj.getClass());
		int index = 0;

		for(Field field : fields) {
			if(field.isAnnotationPresent(ByteLimit.class)) {
				field.setAccessible(true);
				ByteLimit byteLimit = field.getAnnotation(ByteLimit.class);

				int limit = byteLimit.limit();
				field.set(obj, new String(Arrays.copyOfRange(receiveByte, index, index + limit), EwalletConstant.EWALLET_DEFAULT_ENCODING));
				index += limit;
			}
		}

		return obj;
	}




}
