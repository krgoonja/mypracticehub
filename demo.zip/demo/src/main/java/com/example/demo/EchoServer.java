package com.example.demo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


/**
 * EchoServer.java
 * @version
 * @since 2023. 6. 12.
 * @author srec0049
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class EchoServer {
	
	Socket socket = null;
	SocketAddress address = null;
	
	final static String SERVER_IP = "127.0.0.1"; 
	final static int SERVER_PORT = 45558;
	
	Socket socket2 = null;
	SocketAddress address2 = null;
	
	public void start() {
		log.debug(">> echoServer start");
		
		OutputStream os = null;
        DataOutputStream dos = null;
        InputStream is = null;
        int readMessage;
        ServerSocket serverSocket = null;
        
        try {
        	serverSocket = new ServerSocket();
            serverSocket.bind(new InetSocketAddress("localhost", 23461));
            
            while (true) {
            	log.debug("[ Waiting ... ]");
                socket = this.initSocket(serverSocket);
                
                byte[] bytes = null;
                String header = null;
                String message = null;
 
                is = socket.getInputStream();
                DataInputStream dis = new DataInputStream(is);
                byte[] header_bytes = new byte[4];
                int readHeader = dis.read(header_bytes);
                header = new String(header_bytes, 0, readHeader, "EUC_KR");
                log.debug("Data Length : " + header);
 
                int length = Integer.parseInt(header);
                bytes = new byte[length];
                readMessage = is.read(bytes);
                
                boolean isPolling = this.pollingChk(bytes);
            	if(isPolling) {
            		log.debug("polling : " + isPolling);
            		message = new String(bytes, 0, readMessage, "EUC_KR");
            		
            		log.debug("Data Received : " + message);
            		 
                    os = socket.getOutputStream();
                    dos = new DataOutputStream(os);
                    message = header + message;
                    bytes = message.getBytes("EUC_KR");
     
                    dos.write(bytes);
                    dos.flush();
     
                    log.debug("Data Send Success : " + message);
            	} else {
            		log.debug("not polling : " + isPolling);
            		
            		message = new String(bytes, 0, readMessage, "EUC_KR");
            		message = header + message;
            		
            		/** 인터페이스 테이블 저장 **/
            		EwalletAccountEntity accountModel = EwalletCommUtil.getObjForBytes(message.getBytes(), EwalletAccountEntity.class);
            		log.info(accountModel.getBase15());
            		log.info(accountModel.getBase16());
            		log.info(accountModel.getBase17());
            		
            		
            		
            		
            		log.debug("[ socket2 Waiting ... ]");
                    socket2 = this.initSocket2();
                    
                    /**	Client에서 Server로 보내기 위한 통로 */
        			OutputStream os2 = socket2.getOutputStream();
        			DataOutputStream dos2 = new DataOutputStream(os2);
        			
        			String message2 = "05000009200950250000620095025    000007021021000000000" + accountModel.getBase15() + accountModel.getBase16() + accountModel.getBase17() + "400200950250                                                                                                                                             000000 2C9004                                                           0000000000000 00000000000000000000000000        00                                    20095025001212121234                                  000000        000        000               00000            ";
        			log.debug("Data Received : " + message);
        			
        			dos2.write( message2.getBytes() );
        			dos2.flush();
        			
        			log.debug("Data Send Success : " + message);
            		
            		
            		// 20230614034516
            		// 2000001
            	}
            	
                
            }
 
        } catch (Exception e) {
        	log.error("sendReceiveEwallet Error : " + e);
			
			if(os != null) {
				try {
					os.close();
				} catch(Exception oe) {
					log.error("sendReceiveEwallet OutputStream Close Error : " + oe);
				}
			}
			
			if(is != null) {
				try {
					is.close();
				} catch(Exception ie) {
					log.error("sendReceiveEwallet InputStream Close Error : " + ie);
				}
			}
			
			if(socket != null) {
				try {
					socket.close();
				} catch(Exception se) {
					log.error("sendReceiveEwallet Socket Close Error : " + se);
				}
				
				socket = null;
			}
        }
	}
	
	public Socket initSocket(ServerSocket serverSocket) throws Exception {
		if(socket == null) {
			log.debug(">> socket is null");
		} else {
			log.debug(">> socket.isClosed() : " + socket.isClosed() + ", socket.isConnected() : " + socket.isConnected());
		}
		
		try {
			if(socket == null || !socket.isConnected()) {
				socket = serverSocket.accept();
//		        /** 연결 시간 타임아웃 **/
//		    	socket.connect(address, 5000);
//		    	/** 읽는 시간 타임아웃 **/
//		    	socket.setSoTimeout(5000);
		    	InetSocketAddress isa = (InetSocketAddress) socket.getRemoteSocketAddress();
                log.debug("\n[ Accept ... ] \n" + isa.getHostName() + ":" + isa.getPort());
			} else {
				log.debug(">> socket 연결 유지");
			}
		} catch(Exception e) {
			log.debug(">> socket 연결 실패 " + e.getMessage());
		}
        return socket;
	}
	
	public boolean pollingChk(byte[] receiveByte) throws Exception {
		 boolean isPolling = false;
       /** 전문 POLLING 케이스 **/
       String polling =  this.getIndexStr(receiveByte, 0, 3);
log.info(">> polling : " + polling);
       if(StringUtils.equals(polling, "HDR")) {
       	isPolling = true;
       }
       return isPolling;
	}
	
	public static String getIndexStr(byte[] receiveByte, int index, int length) {

		String indexStr  = StringUtils.EMPTY;

		try {
			indexStr  = new String(Arrays.copyOfRange
					( receiveByte
					, index
					, index + length
					), "EUC_KR");

		}catch(Exception e) {

			log.error(e.getMessage());

		}

		return indexStr;
	}
	
	
	public Socket initSocket2() throws Exception {
		if(socket2 == null) {
			log.debug(">> socket2 is null");
		} else {
			log.debug(">> socket2.isClosed() : " + socket2.isClosed() + ", socket2.isConnected() : " + socket2.isConnected());
		}
		
		try {
			if(socket2 == null || !socket2.isConnected()) {
				socket2 =  new Socket(SERVER_IP,SERVER_PORT);
//		        /** 연결 시간 타임아웃 **/
//		    	socket.connect(address, 5000);
//		    	/** 읽는 시간 타임아웃 **/
//		    	socket.setSoTimeout(5000);
		    	InetSocketAddress isa = (InetSocketAddress) socket2.getRemoteSocketAddress();
                log.debug("\n[ socket2 Accept ... ] \n" + isa.getHostName() + ":" + isa.getPort());
			} else {
				log.debug(">> socket2 연결 유지");
			}
		} catch(Exception e) {
			log.debug(">> socket2 연결 실패 " + e.getMessage());
		}
        return socket2;
	}
}
