package com.sorincorp.comm.order.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * OrderPurchsInclnGradeVO.java
 * @version
 * @since 2022. 7. 20.
 * @author srec0049
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class OrderPurchsInclnGradeVO {
	
	/**
     * 업체 구매성향등급
     */
    private String purchsInclnGrad;
    
    /**
     * 업체 구매성향등급 명
     */
    private String purchsInclnGradNm;
    
    /**
     * 증거금 권한 비율(소수점)
     */
    private java.math.BigDecimal wrtmAuthorRateDcmlpoint;
	
	/**
	 * 사용가능한 구매성향등급 여부
	 */
	private String selectableAt;
	
	/**
	 * 구매 성향 단계 범위 시작 비율
	 */
	private int beginStepRate;
	
	/**
	 * 구매 성향 단계 범위 종료 비율
	 */
	private int endStepRate;
	
	/**
	 * 구매 성향 단계 비율
	 */
	private int purchsInclnStepRate;
	
	/**
	 * 구매 성향 단계 금액
	 */
	private int purchsInclnStepAmount;
}
