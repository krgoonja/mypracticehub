package com.sorincorp.comm.order.model;

import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * CommLimitOrderSttusVO.java
 * 지정가 주문 상태 코드 변경 VO 객체
 *
 * @version
 * @since 2023. 5. 2.
 * @author srec0049
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CommLimitOrderSttusVO {

	/**
     * 지정가 주문 번호
     */
    private String limitOrderNo;

    /**
     * 지정가 주문 번호 리스트
     */
    private List<String> limitOrderNoList;

    /**
     * 지정가 주문 상태 코드
     */
    private String limitOrderSttusCode;

    /**
     * 주문 실패 사유
     */
    private String limitOrderFailrResn;

    /**
     * 최종 변경자 아이디
     */
    private String lastChangerId;
    
    /**
     * 주문 번호
     */
    private String orderNo;
    
    /**
     * 주문 중량
     */
    private Integer orderWt;
}
