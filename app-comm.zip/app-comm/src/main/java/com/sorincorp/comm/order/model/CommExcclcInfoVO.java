package com.sorincorp.comm.order.model;

import lombok.Data;

/**
 * CommExcclcInfoVO.java
 * 정산 관련 정보 공통 VO
 * @version
 * @since 2023. 11. 30.
 * @author srec0066
 */
@Data
public class CommExcclcInfoVO {

	/** 주문번호 **/
	private String orderNo;

	/** 판매 방식 코드 **/
	private String sleMthdCode;

	/** 판매 방식 상세 코드 **/
	private String sleMthdDetailCode;

	/** 결제 방식 코드 */
	private String setleMthdCode;

	/** 상품 단가 **/
	private long goodsUntpc;

	 /** 평균가 상품 단가 */
    private long avrgpcGoodsUntpc;

    /** 정산 금액 */
    private long excclcAmount;

    /**
     * 미 결제 금액
     */
    private long unSetleAmount;

    /**
     * 추가 금액
     */
    private long aditAmount;

    /** 중량 환불 금액 */
    private long wtRefndAmount;

    /** 단가 환불 금액 */
    private long pcRefndAmount;

    /** 중량 상환 금액 */
    private long wtRepyAmount;

    /** 단가 상환 금액*/
    private long pcRepyAmount;

}
