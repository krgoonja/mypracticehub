package com.sorincorp.comm.order.model;

import java.util.Date;

import javax.validation.constraints.NotEmpty;

import com.sorincorp.comm.model.CommonVO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CouponVO extends CommonVO {

    private static final long serialVersionUID = -1032006748916951512L;

    /**회원 번호*/
    private String mberNo;

    /**회원 아이디*/
    private String mberId;

    /** 업체 번호*/
    private String entrpsNo;

    /** 권한 구분 코드*/
    private String memberSecode;

    /** 쿠폰이벤트 번호  **/
    @NotEmpty(message = "쿠폰 이벤트번호 미존재")
    private int prcouponEventNo;

    /** 프로모션 번호   **/
    @NotEmpty(message = "프로모션 번호 미존재")
    private int promtnNo;

    /**  쿠폰 명        **/
    @NotEmpty(message = "쿠폰명 미존재")
    private String couponNm;

    /** 쿠폰 타입       **/
    @NotEmpty(message = "쿠폰타입 미존재")
    private String couponType;

    /** 쿠폰 구분 코드  **/
    @NotEmpty(message = "쿠폰 구분코드 미존재")
    private String couponSeCode;

    /** 쿠폰 구분 코드  **/
    private String couponSeCodeNm;

    /** 쿠폰 적용 브랜드 코드  **/
    private String couponApplcBrandCode;

    /** 쿠폰 할인 금액       **/
    private int couponDscntAmount;

    /** 쿠폰 할인율      **/
    private int couponDscntRt;

    /** 쿠폰 발급 제한 수량 여부      **/
    @NotEmpty
    private String couponIssuLmttQyAt;

    /** 쿠폰 발급 제한 수량       **/
    private int couponIssuLmttQy;

    /** 쿠폰 중복 사용 제한 수량     **/
    @NotEmpty
    private int couponDplctUseLmttQy;

    /** 쿠폰 적용 메탈 코드    **/
    private String couponApplcMetalCode;

    /** 할인 최대 금액 제한    **/
    private int dscntMxmmAmountLmtt;

    /** 배송비 쿠폰일 경우 적용차수    **/
    private int dlvrfCouponApplcOdr;

    /** 쿠폰의 중복가능 여부(배송비+상품)   **/
    @NotEmpty
    private String couponDplctUseLmttQyAt;

    /** 쿠폰 시작 날짜  **/
    @NotEmpty
    private String couponBeginDe;

    /** 쿠폰 종료 날짜  **/
    @NotEmpty
    private String couponEndDe;

    /** 최초 등록자 아이디  **/
    @NotEmpty
    private String frstRegisterId;

    /** 최초 등록 일시**/
    @NotEmpty
    private Date frstRegistDt;

    /** 최종 변경자 아이디 **/
    private String lastChangerId;

    /** 최종 변경 일시 **/
    private Date lastChangeDt;

    /** 프로모션 사용여부 **/
    @NotEmpty
    private String promtnCouponUseAt;

    /** 프로모션명 **/
    private String promtnNm;

    /** 프로모션코드 **/
    private String promtnSeCode;

    /** 쿠폰사용여부 **/
    private String couponUseAt;

    /** 쿠폰등록일시 **/
    private String registAt;

    /** 쿠폰난수 **/
    private String couponIsuRnno;

    /** 입력쿠폰난수 **/
    private String inputCouponIsuRnno;

    /** 쿠폰이벤트번호 **/
    private String couponEventNo;

    /** 조회 화면 ID **/
    private String searchPmgId;

    /** 조회 화면 ID **/
    private String dlvyMnCode;

    /** 쿠폰 일련 번호 **/
    private String couponSeqNo;

    private String orderNo;

    private int orderWt;

    private String couponSttusCode;

    private String couponApplcOrderNo;

    //CP_COUPON_INFO_BAS

    /** 쿠폰 번호 **/
    private String couponNo;

    /** 쿠폰 타입 코드 **/
    private String couponTyCode;

    /** 적용 쿠폰 타입 코드 **/
    private String orderTyCode;

    //CP_COUPON_INFO_BAS

    /** 톤수 **/
    private int mt;

    /** 금속 코드 **/
    private String metalCode;

    /** 쿠폰 상세 번호 **/
    private String couponDtlNo;

    /** 단가 할인 금액 **/
    private int untpcDscntAmount;

    /** 단가 쿠폰 총 할인 금액**/
    private int untpcCouponTotalAmount;

    //CP_COUPON_ISU_BAS

    /** 단가 쿠폰 총 할인 금액**/
    private String couponSn;

    //EV_COUPON_INFO_BAS

    /** 쿠폰 사용자 아이디  : 임시로 lastChangerID로 사용**/
    private String coupopnUseId;

    /** 쿠폰 사용 일시 : 임시로 lastChangeDt로 사용**/
    private String coupopnUseDt;

    /** 쿠폰 중복 여부**/
    private String dplctAt;

    /** 쿠폰 중복 여부 문장**/
    private String reDplctAt;

    /** 총 단가 할인 금액 **/
    private long pdDscntAmount;

    /** 총액 할인 금액 **/
    private long cpDscntAmount;
    
    /** 할인 배송비 **/
    private long expectDlvrf;
    
    /**
    * 쿠폰 확인 페이지
    */
    private String openPage;
    
    /**
     * 쿠폰 사용 일
     */
    private String orderDe;
    /**
     * 쿠폰 타입 명
     */
    private String couponTyCodeNm;
    /**
     * 금속 명
     */
    private String metalNm;
    /**
     * 브랜드명
     */
    private String brandNm;
    /**
     * 쿠폰 시작 일
     */
    private String couponBgnde;
    
    /**
     * 자동 재발행 여부(상시할인)
     */
    private String atmIsgnAt;
    
    /**
     * 자동 재발행 여부(상시할인)
     */
    private int couponDscntApplcAmount;
    
    
}
