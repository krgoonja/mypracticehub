package com.sorincorp.comm.sidecar.mapper;

import java.util.List;

import com.sorincorp.comm.sidecar.model.SidecarVO;

public interface SidecarOpMapper {
	List<SidecarVO> getSidecarOnList();
}
