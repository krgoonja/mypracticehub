package com.sorincorp.comm.limit.mapper;

import java.util.List;

import com.sorincorp.comm.order.model.CommLimitOrderRedisMsgVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderRedisMsgVO;

public interface LimitMapper {
	List<CommLimitOrderRedisMsgVO> loadInitialLimitData();

	List<CommPrvsnlLimitOrderRedisMsgVO> loadInitialPrvsnlLimitData();

	List<CommPrvsnlLimitOrderRedisMsgVO> loadInitialPrvsnlLimitFxData();
}
