package com.sorincorp.comm.itemprice.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.itemprice.mapper.ItemPriceMatchingMapper;
import com.sorincorp.comm.itemprice.model.ItemPriceGatheringInfoByBrandCodeVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlWrhousngVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingSelectVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingWeightCalculateValuesVO;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ItemPriceMatchingServiceImpl implements ItemPriceMatchingService{

	@Autowired
	private ItemPriceMatchingMapper itemPriceMatchingMapper;

	public List<ItemPriceMatchingBlInfoVO> selectListItemBl(ItemPriceMatchingSelectVO itemPriceMatchingSelectVO) {
		List<ItemPriceMatchingBlInfoVO> returnItemPriceMatchingBlInfoVO = new ArrayList<ItemPriceMatchingBlInfoVO>();

		if("02".equals(itemPriceMatchingSelectVO.getSellMethodCode())) {
			returnItemPriceMatchingBlInfoVO = itemPriceMatchingMapper.selectListItemBlByFixPrice(itemPriceMatchingSelectVO);
		} else {
			returnItemPriceMatchingBlInfoVO = itemPriceMatchingMapper.selectListItemBl(itemPriceMatchingSelectVO);
		}

		return returnItemPriceMatchingBlInfoVO;
	}

	@Override
	public List<ItemPriceMatchingBlInfoVO> itemBLWithMatchingList(ItemPriceMatchingSelectVO itemPriceMatchingSelectVO
																	, int minSearchBoundaryWeight
																	, int maxSearchBoundaryWeight
																	, int maxBlSearchCount
																	, int weightUnit) throws Exception {
		// BL 조건 처리 여부(blCndProcessAt) 추가, 20231117 적용, 기존과 같은 로직 수행, true 설정
		return itemBLWithMatchingListUnity(itemPriceMatchingSelectVO, minSearchBoundaryWeight, maxSearchBoundaryWeight, maxBlSearchCount, weightUnit, false, true);
	}

	/**
	 * 평균가 재고 할당 전용, 검색한 결과값에 맞는 BL리스트를 return 한다. (최적 할당 번들 중량을 구하기 용도)
	 */
	@Override
	public List<ItemPriceMatchingBlInfoVO> itemBLWithMatchingListByAsgn(ItemPriceMatchingSelectVO itemPriceMatchingSelectVO
																	, int minSearchBoundaryWeight
																	, int maxSearchBoundaryWeight
																	, int maxBlSearchCount
																	, int weightUnit) throws Exception {
		// BL 조건 처리 여부(blCndProcessAt) 추가, 20231117 적용
		// 평균가 할당 로직에서 BL번호를 조건으로 최적의 BL로직을 수행하기 위해 BL번호 조건에 의해 처리되는 부분 회피, false 설정
		return itemBLWithMatchingListUnity(itemPriceMatchingSelectVO, minSearchBoundaryWeight, maxSearchBoundaryWeight, maxBlSearchCount, weightUnit, false, false);
	}

	@Override
	public List<ItemPriceMatchingBlInfoVO> itemBLWithMatchingListLimits(ItemPriceMatchingSelectVO itemPriceMatchingSelectVO
																		, int minSearchBoundaryWeight
																		, int maxSearchBoundaryWeight
																		, int maxBlSearchCount
																		, int weightUnit) throws Exception {
		// BL 조건 처리 여부(blCndProcessAt) 추가, 20231117 적용, 기존과 같은 로직 수행, true 설정
		return itemBLWithMatchingListUnity(itemPriceMatchingSelectVO, minSearchBoundaryWeight, maxSearchBoundaryWeight, maxBlSearchCount, weightUnit, true, true);
	}

	/**
	 * BL 조건 처리 여부(blCndProcessAt) 추가, 20231117 적용
	 * 평균가 할당 로직에서 BL번호를 조건으로 최적의 BL로직을 수행하는 부분이 있는데 자투리 처리 시 BL 조건 들어가는 것과 분리하기 위해서 적용함
	 * 처리 회피는 false, 기존과 같은 로직 수행은 true 설정
	 */
	public List<ItemPriceMatchingBlInfoVO> itemBLWithMatchingListUnity(ItemPriceMatchingSelectVO paramItemPriceMatchingSelectVO
																		, int minSearchBoundaryWeight
																		, int maxSearchBoundaryWeight
																		, int maxBlSearchCount
																		, int weightUnit
																		, Boolean gatheringAt
																		, Boolean blCndProcessAt) throws Exception {

		List<ItemPriceMatchingBlInfoVO> returnList = new ArrayList<>(); // 결과값

		ItemPriceMatchingSelectVO itemPriceMatchingSelectVO = new ItemPriceMatchingSelectVO();
		BeanUtils.copyProperties(itemPriceMatchingSelectVO, paramItemPriceMatchingSelectVO);

		try {

			//List<String> specifyBrandCodeList = itemPriceMatchingMapper.selectEnterpriseSpecifyBrand(itemPriceMatchingSelectVO.getEnterpriseNo());

			//if(specifyBrandCodeList.size() > 0) {
			//	for(String brandCode : specifyBrandCodeList) {
			//		if(!specifyBrandCodeList.contains(brandCode)) {
			//			itemPriceMatchingSelectVO.getBrandCodeList().add(brandCode);
			//		}
			//	}
			//}
			//itemPriceMatchingSelectVO.setBlNo(null);

			// BL 조건 처리 여부(blCndProcessAt)가 true일 경우에만 처리한다. 20231117 적용
			if(blCndProcessAt) {
				if(StringUtil.isEmpty(itemPriceMatchingSelectVO.getBlNo()) && "0000000000".equals(itemPriceMatchingSelectVO.getBrandCode())) { //브랜드무관일때 브랜드별 BL중량조회(지정BL, 주문화면진입시 제외)
					List<ItemPriceMatchingBlInfoVO> itemBlByBrandList =itemPriceMatchingMapper.selectListItemBlByBrand(itemPriceMatchingSelectVO);
					List<String> itemBlbrandCodeList = new ArrayList<String>();

					if(itemBlByBrandList.size() > 0) { // 브랜드별 총중량 조회결과 없을경우 매칭실패처리
						itemPriceMatchingSelectVO.getBrandCodeList().clear();
						for(ItemPriceMatchingBlInfoVO itemBlByBrand : itemBlByBrandList) {
							if(itemBlByBrand.getSumSleInvntryUnsleBundleBnt().compareTo(itemPriceMatchingSelectVO.getOrderWeight()) >= 0) {
								itemBlbrandCodeList.add(itemBlByBrand.getBrandCode());
							}
						}

						itemPriceMatchingSelectVO.setBrandCodeList(itemBlbrandCodeList);
					} else {
						returnList.clear();
						return returnList;
					}
				}
			}

			// 2024-05-22: 소량 구매일 경우, 파라미터 재세팅
			if("Y".equals(itemPriceMatchingSelectVO.getSmlqyPurchsAt())) {
				minSearchBoundaryWeight = 1;
				maxSearchBoundaryWeight = itemPriceMatchingSelectVO.getOrderWeight().intValue();
				maxBlSearchCount = 1;
				weightUnit = 1;
			}

			itemPriceMatchingSelectVO.setWrhousngSeCode("1"); //실재고 선조회
			List<ItemPriceMatchingBlInfoVO> searchItemBLList = selectListItemBl(itemPriceMatchingSelectVO);
			int leftOverWeight = itemPriceMatchingSelectVO.getOrderWeight().intValue();

			if(searchItemBLList.size() > 0) {
				// BL 조건 처리 여부(blCndProcessAt) 조건 추가, 20231117 적용
				ItemPriceMatchingBlWrhousngVO itemPriceMatchingBlWrhousngVO = searchBLWithMatchingList(itemPriceMatchingSelectVO, minSearchBoundaryWeight, maxSearchBoundaryWeight, maxBlSearchCount, weightUnit, searchItemBLList, blCndProcessAt);
				returnList.addAll(itemPriceMatchingBlWrhousngVO.getItemPriceMatchingBlInfoVO());

				leftOverWeight = itemPriceMatchingBlWrhousngVO.getLeftOverWeight();
			}

			if( leftOverWeight > 0 || searchItemBLList.size() == 0) {
				itemPriceMatchingSelectVO.setWrhousngSeCode("4");	//가재고 조회
				List<ItemPriceMatchingBlInfoVO> searchStockItemBLList = selectListItemBl(itemPriceMatchingSelectVO);

				if(searchStockItemBLList.size() > 0) {

					if (leftOverWeight > 0) { //해당브랜드재고가 가재고만 있을때 실재고매칭후 잔여중량이 있을때만 업데이트함
						itemPriceMatchingSelectVO.setOrderWeight(new BigDecimal(leftOverWeight));
						maxSearchBoundaryWeight = leftOverWeight;
					}

					// BL 조건 처리 여부(blCndProcessAt) 조건 추가, 20231117 적용
					ItemPriceMatchingBlWrhousngVO itemPriceMatchingBlWrhousngStockVO = searchBLWithMatchingList(itemPriceMatchingSelectVO, minSearchBoundaryWeight, maxSearchBoundaryWeight, maxBlSearchCount, weightUnit, searchStockItemBLList, blCndProcessAt);
	 				returnList.addAll(itemPriceMatchingBlWrhousngStockVO.getItemPriceMatchingBlInfoVO());
	 				leftOverWeight = itemPriceMatchingBlWrhousngStockVO.getLeftOverWeight();
				}
			}

			if (leftOverWeight > 0 && !"N".equals(itemPriceMatchingSelectVO.getLeftOverWtRetrunBlEmptyYn())) {
				returnList.clear();
				ItemPriceMatchingBlInfoVO leftOverInfoVO = new ItemPriceMatchingBlInfoVO();
				leftOverInfoVO.setLeftOverWeight(new BigDecimal(leftOverWeight));
				leftOverInfoVO.setLeftOverExistYn(true);
				returnList.add(leftOverInfoVO);
			}

			//잔여수량이 있으면서 멀티BL 활성화 일 경우 리턴값 클리어 후 리턴
			if( leftOverWeight > 0 && !gatheringAt ) {
				returnList.clear();
			}

		} catch(Exception e){
			log.error(ExceptionUtils.getStackTrace(e));
		}

		return returnList;
	}

	/**
	 * BL 조건 처리 여부(blCndProcessAt) 추가, 20231117 적용
	 * 평균가 할당 로직에서 BL번호를 조건으로 최적의 BL로직을 수행하는 부분이 있는데 자투리 처리 시 BL 조건 들어가는 것과 분리하기 위해서 적용함
	 * 처리 회피는 false, 기존과 같은 로직 수행은 true 설정
	 *
	 * 소량구매의 경우, 로직 분기처기를 위해 파라미터 추가됨: 'Y'일 경우에만 소량구매
	 */
	public ItemPriceMatchingBlWrhousngVO searchBLWithMatchingList(ItemPriceMatchingSelectVO itemPriceMatchingSelectVO
																		, int minSearchBoundaryWeight
																		, int maxSearchBoundaryWeight
																		, int maxBlSearchCount
																		, int weightUnit
																		, List<ItemPriceMatchingBlInfoVO> searchItemBLList
																		, Boolean blCndProcessAt) throws Exception {

		ItemPriceMatchingBlWrhousngVO itemPriceMatchingBlWrhousngVO = new ItemPriceMatchingBlWrhousngVO();
		List<ItemPriceMatchingBlInfoVO> returnList = new ArrayList<>(); // 결과값
		List<ItemPriceMatchingBlInfoVO> matchingList = new ArrayList<>(); // 딱맞는 중량
		List<ItemPriceMatchingBlInfoVO> biggestList = new ArrayList<>(); // 제일 많은 중량
		List<ItemPriceMatchingBlInfoVO> gatheringList = new ArrayList<>(); // 작은 중량들 여러개

		try {

			BigDecimal selectTonWeight = itemPriceMatchingSelectVO.getOrderWeight();

			for(int i = 0; i < searchItemBLList.size(); i++) {

//			System.out.println("***********************************************");
//			System.out.println("getBrandGroupCode : " + searchItemBLList.get(i).getBrandGroupCode());
//			System.out.println("getBrandCode : " +searchItemBLList.get(i).getBrandCode());
//			System.out.println("getSleInvntryUnsleBnt : " +searchItemBLList.get(i).getSleInvntryUnsleBnt());
//			System.out.println("getSleInvntryUnsleBundleBnt : " +searchItemBLList.get(i).getSleInvntryUnsleBundleBnt());
//			System.out.println("getPriorRank : " +searchItemBLList.get(i).getPriorRank());
//			System.out.println("***********************************************");

				//각 주문 중량 당 번들 및 중량을 계산한다.
				Map<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO> mapMatchingWeightValueVo = setMathcingValuesMap(searchItemBLList.get(i)
																														, minSearchBoundaryWeight
																														, maxSearchBoundaryWeight
																														, weightUnit);

				// 2024-05-22: 소량 구매일 경우, 소량 판매 재고 미판매 번들 잔량을 조회
				if("Y".equals(itemPriceMatchingSelectVO.getSmlqyPurchsAt())) {
					// 번들 수 비교
					int smlqyInvntryCompare = BigDecimal.valueOf(searchItemBLList.get(i).getSmlqySleInvntryUnsleBundleBnt()).compareTo(selectTonWeight);
					// 소량판매 미판매 재고 >= 주문 수량
					if(smlqyInvntryCompare >= 0) {
						if(searchItemBLList.get(i).getSmlqySleInvntryUnsleBundleBnt() == selectTonWeight.intValue()) {
							// 소량판매 미판매 재고 = 주문 수량인 경우, 남은 재고 전체 소진
							searchItemBLList.get(i).setMatchedSleInvntryUnsleBundleBnt(BigDecimal.valueOf(searchItemBLList.get(i).getSmlqySleInvntryUnsleBundleBnt()));
							searchItemBLList.get(i).setMatchedSleInvntryUnsleBnt(searchItemBLList.get(i).getSmlqySleInvntryUnsleBnt());
						} else {
							// 소량판매 미판매 재고 != 주문 수량인 경우, 주문 번들 수/net 평균 중량 적용
							searchItemBLList.get(i).setMatchedSleInvntryUnsleBundleBnt(selectTonWeight);
							searchItemBLList.get(i).setMatchedSleInvntryUnsleBnt(searchItemBLList.get(i).getNetAvrgWt().multiply(selectTonWeight));
						}
						searchItemBLList.get(i).setMatchedOrderedBnt(selectTonWeight);
						searchItemBLList.get(i).setOrderWeight(selectTonWeight);

						//계산된 번들 및 중량을 BL에 설정
						searchItemBLList.get(i).setWeightMappingCalculateValues(mapMatchingWeightValueVo);
					}

					// 소량구매는 부분체결 없음: 구매하고자 하는 전체 수량이 없으면 빈값으로 리턴
					itemPriceMatchingBlWrhousngVO.setItemPriceMatchingBlInfoVO(searchItemBLList);
					itemPriceMatchingBlWrhousngVO.setLeftOverWeight(0);

					return itemPriceMatchingBlWrhousngVO;
				}

				int isTonWeight = selectTonWeight.compareTo(new BigDecimal(minSearchBoundaryWeight));

				// BL 조건 처리 여부(blCndProcessAt)가 true일 경우에만 처리한다. 20231117 적용
				if(blCndProcessAt) {
					// 자투리 처리 BL 부분
					if(!StringUtil.isEmpty(itemPriceMatchingSelectVO.getBlNo()) && isTonWeight == 0) {

						int minToleranceRate = searchItemBLList.get(i).getCtrtcBeginPermWtRate();
						float base = minSearchBoundaryWeight * (100 - minToleranceRate) / 100;
						BigDecimal baseStock = new BigDecimal(base);

						int compareResult = baseStock.compareTo(searchItemBLList.get(i).getTrmendInvntry());

						//if(compareResult > 0){
							//미판잔량이 해당BL최적번들수보다 작을 경우 "미판잔량번들,수량" 적용 / 같거나 클 경우는 "해당BL최적번들수, 최적수량" 적용
							searchItemBLList.get(i).setMatchedSleInvntryUnsleBundleBnt(BigDecimal.valueOf(searchItemBLList.get(i).getSleInvntryUnsleBundleBnt()).compareTo(mapMatchingWeightValueVo.get(selectTonWeight).getCollectBundle()) < 0 ? BigDecimal.valueOf(searchItemBLList.get(i).getSleInvntryUnsleBundleBnt()) : mapMatchingWeightValueVo.get(selectTonWeight).getCollectBundle());
							searchItemBLList.get(i).setMatchedSleInvntryUnsleBnt(BigDecimal.valueOf(searchItemBLList.get(i).getSleInvntryUnsleBundleBnt()).compareTo(mapMatchingWeightValueVo.get(selectTonWeight).getCollectBundle()) < 0 ? searchItemBLList.get(i).getSleInvntryUnsleBnt() : mapMatchingWeightValueVo.get(selectTonWeight).getCollectBundleLogicalWeight());
							searchItemBLList.get(i).setMatchedOrderedBnt(new BigDecimal(minSearchBoundaryWeight));
							searchItemBLList.get(i).setOrderWeight(BigDecimal.valueOf(searchItemBLList.get(i).getSleInvntryUnsleBundleBnt()).compareTo(mapMatchingWeightValueVo.get(selectTonWeight).getCollectBundle()) < 0 ? searchItemBLList.get(i).getSleInvntryUnsleBnt() : selectTonWeight);

							//계산된 번들 및 중량을 BL에 설정
							searchItemBLList.get(i).setWeightMappingCalculateValues(mapMatchingWeightValueVo);

							itemPriceMatchingBlWrhousngVO.setItemPriceMatchingBlInfoVO(searchItemBLList);
							itemPriceMatchingBlWrhousngVO.setLeftOverWeight(0);

							return itemPriceMatchingBlWrhousngVO;
						//}
					}
				}

				//bl의 재고 미판매 번들 잔량
				BigDecimal inventoryUnSelBundle = BigDecimal.valueOf(searchItemBLList.get(i).getSleInvntryUnsleBundleBnt());

				// 검색 값의 tolerance 범위 안에 맞는 값 저장
				if(inventoryUnSelBundle.compareTo(mapMatchingWeightValueVo.get(selectTonWeight).getMinBundle()) >= 0 &&
					inventoryUnSelBundle.compareTo(mapMatchingWeightValueVo.get(selectTonWeight).getMaxBundle()) <= 0) {

					//선택된 값을 선택하게된 기준 번들 값과 기준 중량을 설정
					searchItemBLList.get(i).setMatchedSleInvntryUnsleBundleBnt(inventoryUnSelBundle);
					searchItemBLList.get(i).setMatchedSleInvntryUnsleBnt(searchItemBLList.get(i).getSleInvntryUnsleBnt());
					searchItemBLList.get(i).setMatchedOrderedBnt(selectTonWeight);
					searchItemBLList.get(i).setOrderWeight(selectTonWeight);

					//계산된 번들 및 중량을 BL에 설정
					searchItemBLList.get(i).setWeightMappingCalculateValues(mapMatchingWeightValueVo);

					matchingList.add(searchItemBLList.get(i));
					break;
				}

				//검색 값 보다 큰 값 저장
				if(inventoryUnSelBundle.compareTo(mapMatchingWeightValueVo.get(selectTonWeight).getMaxBundle()) > 0) {

					//선택된 값을 선택하게된 기준 번들 값과 기준 중량을 설정
					searchItemBLList.get(i).setMatchedSleInvntryUnsleBundleBnt(mapMatchingWeightValueVo.get(selectTonWeight).getCollectBundle());
					searchItemBLList.get(i).setMatchedSleInvntryUnsleBnt(mapMatchingWeightValueVo.get(selectTonWeight).getCollectBundleLogicalWeight());
					searchItemBLList.get(i).setMatchedOrderedBnt(selectTonWeight);
					searchItemBLList.get(i).setOrderWeight(selectTonWeight);

					//계산된 번들 및 중량을 BL에 설정
					searchItemBLList.get(i).setWeightMappingCalculateValues(mapMatchingWeightValueVo);

					biggestList.add(searchItemBLList.get(i));
				}

				//검색 값보다 작은 값 저장
				if(inventoryUnSelBundle.compareTo(mapMatchingWeightValueVo.get(selectTonWeight).getMinBundle()) < 0) {

					//계산된 번들 및 중량을 BL에 설정
					searchItemBLList.get(i).setWeightMappingCalculateValues(mapMatchingWeightValueVo);
					gatheringList.add(searchItemBLList.get(i));
				}
			}

			//찾는 수량에 tolerance 범위 안에 맞는 재고 있음
			if(matchingList.size() > 0) {
				returnList.clear();

				//브랜드 무관을 선택했을 때 우선순위 최상위 값을 제외한 값 삭제
				if(itemPriceMatchingSelectVO.getBrandCode().equals("00000000")) {
					List<ItemPriceMatchingBlInfoVO> removeList = new ArrayList<>();
					String brandCode = matchingList.get(getTopPriorIndexFromSearchList(matchingList)).getBrandCode();
					for(ItemPriceMatchingBlInfoVO vo : matchingList) {
						if(!vo.getBrandCode().equals(brandCode)) {
							removeList.add(vo);
						}
					}
					matchingList.removeAll(removeList);
				}

				//주문 수량과 가장 같은 값을 뽑는다.
				returnList.add(matchingList.get(returnClosestMatchingVoIndex(selectTonWeight, selectTonWeight, matchingList)));

				itemPriceMatchingBlWrhousngVO.setItemPriceMatchingBlInfoVO(returnList);
				itemPriceMatchingBlWrhousngVO.setLeftOverWeight(0);

				//맞는 수량의 VO 하나 return
				return itemPriceMatchingBlWrhousngVO;
			}

			//찾는 수량보다 큰 재고 있음
			if(biggestList.size() > 0) {
				returnList.clear();

				//브랜드 무관을 선택했을 때 우선순위 최상위 값을 제외한 값 삭제
				if(itemPriceMatchingSelectVO.getBrandCode().equals("00000000")) {
					List<ItemPriceMatchingBlInfoVO> removeList = new ArrayList<>();
					String brandCode = biggestList.get(getTopPriorIndexFromSearchList(biggestList)).getBrandCode();
					for(ItemPriceMatchingBlInfoVO vo : biggestList) {
						if(!vo.getBrandCode().equals(brandCode)) {
							removeList.add(vo);
						}
					}
					biggestList.removeAll(removeList);
				}

				//주문 수량보다 큰 수중 가장 큰 수를 뽑는다.
				returnList.add(biggestList.get(returnBiggestVoIndex(selectTonWeight, biggestList)));

				itemPriceMatchingBlWrhousngVO.setItemPriceMatchingBlInfoVO(returnList);
				itemPriceMatchingBlWrhousngVO.setLeftOverWeight(0);

				//큰 수량의 VO 하나 return
				return itemPriceMatchingBlWrhousngVO;
			}

			/*
			// 지정가 부분체결 오류 발생으로 임시 활성화 - 20240404
			// 지정가 주문 임시로 사용
			// 찾는 수량보다 작은 재고중 미판잔량이 최소주문 수량의 조건을 충족하면서 가장 많은 재고
			if("03".equals(itemPriceMatchingSelectVO.getSellMethodCode())) {
				if(gatheringList.size() > 0) {
					returnList.clear();

					List<ItemPriceMatchingBlInfoVO> reOrderByGatheringList = new ArrayList<>(); //작은 중량들 여러개 > 재정렬 미판잔량 순으로
					reOrderByGatheringList = gatheringList.stream().sorted(Comparator.comparing(ItemPriceMatchingBlInfoVO::getSleInvntryUnsleBundleBnt).reversed()).collect(Collectors.toList());

					for ( ItemPriceMatchingBlInfoVO reOrderByGathering : reOrderByGatheringList ) {
						int reSleInvntryUnsleBundleBnt = reOrderByGathering.getSleInvntryUnsleBundleBnt();
						BigDecimal reMinBundle = reOrderByGathering.getWeightMappingCalculateValues().get(BigDecimal.valueOf(weightUnit)).getMinBundle(); //최소주문수량 기준 최소 번들 수
						if( reSleInvntryUnsleBundleBnt >= reMinBundle.intValue() ) {

							returnList.add(reOrderByGathering);

							itemPriceMatchingBlWrhousngVO.setLeftOverWeight(reOrderByGathering.getSleInvntryUnsleBundleBnt());
							itemPriceMatchingBlWrhousngVO.setItemPriceMatchingBlInfoVO(returnList);

							break;
						}
					}
				}
			}else {
			*/
			//임시로 다중 BL 제한
			//찾는 수량보다 작은 재고 있음
			if(gatheringList.size() > 0) {

				//창고별 BlList Map
				Map<Integer, List<ItemPriceMatchingBlInfoVO>> returnMatchingListMap = new HashMap();
				Map<Integer, List<ItemPriceMatchingBlInfoVO>> returnOverMatchingListMap = new HashMap();

				int maxBlChk = maxBlSearchCount;
				int maxOverBlChk = 0;

				returnList.clear();

				// 우선순위별 브랜드 코드 Map
				Map<Integer, String> brandCodeToPriorRank = new HashMap<>();
				// 브랜드코드 별 warehouseCount, sumWeight 형태의 ItemPriceSuWeightVO
				Map<String, ItemPriceGatheringInfoByBrandCodeVO> gatheringInfoByBrandCodeMap = new HashMap<>();
				int leftOverWeight = 0;

				for(int i = 0; i < gatheringList.size(); i++) {
					int priorRank = gatheringList.get(i).getPriorRank();
					String brandCode = gatheringList.get(i).getBrandCode();


					//brandCodeToPriorRank Map 초기화, 우선순위에 따른 브랜드코드 등록 -> 브랜드코드의 우선순위는 중복되지 않는다.
					if(!brandCodeToPriorRank.containsKey(priorRank)) {
						brandCodeToPriorRank.put(priorRank, brandCode);
					}

					//brandCodeSumWeightMap Map 초기화, 각 brandCode별 중량에 맞는
					if(!gatheringInfoByBrandCodeMap.containsKey(brandCode)) {
						ItemPriceGatheringInfoByBrandCodeVO itemPriceSumWeightVO = new ItemPriceGatheringInfoByBrandCodeVO();
						itemPriceSumWeightVO.setMatchedWeightMap(new HashMap<Integer, List<ItemPriceMatchingBlInfoVO>>());
						itemPriceSumWeightVO.setOveredWeightMap(new HashMap<Integer, List<ItemPriceMatchingBlInfoVO>>());

						gatheringInfoByBrandCodeMap.put(brandCode, itemPriceSumWeightVO);
					}

					//주문 수량보다 적은 수량중 25 단위로 작은 수에 tolerance 범위에 들어가는 수량
					for(int findWeight = selectTonWeight.intValue() - weightUnit; findWeight > 0; findWeight -= weightUnit) {

						ItemPriceGatheringInfoByBrandCodeVO infoByBrandCodeVO = gatheringInfoByBrandCodeMap.get(brandCode);
						BigDecimal inventoryUnSelBundle = BigDecimal.valueOf(gatheringList.get(i).getSleInvntryUnsleBundleBnt());
						ItemPriceMatchingWeightCalculateValuesVO matchingWeightValueVo = gatheringList.get(i).getWeightMappingCalculateValues().get(BigDecimal.valueOf(findWeight));

						if (leftOverWeight == 0 || leftOverWeight >= inventoryUnSelBundle.intValue()) {
							// tolerance 영역에 들어가는 딱 맞는 값
							if(inventoryUnSelBundle.compareTo(matchingWeightValueVo.getMinBundle()) >= 0 &&
									inventoryUnSelBundle.compareTo(matchingWeightValueVo.getMaxBundle()) <= 0) {

								// 각 수량에 대해 딱 맞는 값을 저장하는 Map에 해당 주문 수량 값에 대한 BL리스트를 저장한다.
								if(infoByBrandCodeVO.getMatchedWeightMap().containsKey(findWeight)) {
									//선택된 값을 선택하게된 기준 번들 값과 기준 중량을 설정
									gatheringList.get(i).setMatchedSleInvntryUnsleBundleBnt(inventoryUnSelBundle);
									gatheringList.get(i).setMatchedSleInvntryUnsleBnt(gatheringList.get(i).getSleInvntryUnsleBnt());
									gatheringList.get(i).setMatchedOrderedBnt(BigDecimal.valueOf(findWeight));
									gatheringList.get(i).setOrderWeight(BigDecimal.valueOf(findWeight));

									infoByBrandCodeVO.getMatchedWeightMap().get(findWeight).add(gatheringList.get(i));
								} else {
									infoByBrandCodeVO.getMatchedWeightMap().put(findWeight, new ArrayList<ItemPriceMatchingBlInfoVO>());

									//선택된 값을 선택하게된 기준 번들 값과 기준 중량을 설정
									gatheringList.get(i).setMatchedSleInvntryUnsleBundleBnt(inventoryUnSelBundle);
									gatheringList.get(i).setMatchedSleInvntryUnsleBnt(gatheringList.get(i).getSleInvntryUnsleBnt());
									gatheringList.get(i).setMatchedOrderedBnt(BigDecimal.valueOf(findWeight));
									gatheringList.get(i).setOrderWeight(BigDecimal.valueOf(findWeight));

									infoByBrandCodeVO.getMatchedWeightMap().get(findWeight).add(gatheringList.get(i));
								}

								leftOverWeight = selectTonWeight.intValue() - leftOverWeight - findWeight;
								break;
							} else if(inventoryUnSelBundle.compareTo(matchingWeightValueVo.getMaxBundle()) > 0) {	// tolerance 영역을 벗어나는 큰 값

								// 각 수량에 대해 더 큰 값을 저장하는 Map에 해당 주문 수량 값에 대한 BL리스트를 저장한다.
								if(infoByBrandCodeVO.getOveredWeightMap().containsKey(findWeight)) {
									BigDecimal collectBundle = matchingWeightValueVo.getCollectBundle();

									//선택된 값을 선택하게된 기준 번들 값과 기준 중량을 설정
									gatheringList.get(i).setMatchedSleInvntryUnsleBundleBnt(collectBundle);
									gatheringList.get(i).setMatchedSleInvntryUnsleBnt(matchingWeightValueVo.getCollectBundleLogicalWeight());
									gatheringList.get(i).setMatchedOrderedBnt(BigDecimal.valueOf(findWeight));
									gatheringList.get(i).setOrderWeight(BigDecimal.valueOf(findWeight));

									infoByBrandCodeVO.getOveredWeightMap().get(findWeight).add(gatheringList.get(i));
								} else {
									infoByBrandCodeVO.getOveredWeightMap().put(findWeight, new ArrayList<ItemPriceMatchingBlInfoVO>());

									BigDecimal collectBundle = matchingWeightValueVo.getCollectBundle();

									//선택된 값을 선택하게된 기준 번들 값과 기준 중량을 설정
									gatheringList.get(i).setMatchedSleInvntryUnsleBundleBnt(collectBundle);
									gatheringList.get(i).setMatchedSleInvntryUnsleBnt(matchingWeightValueVo.getCollectBundleLogicalWeight());
									gatheringList.get(i).setMatchedOrderedBnt(BigDecimal.valueOf(findWeight));
									gatheringList.get(i).setOrderWeight(BigDecimal.valueOf(findWeight));

									infoByBrandCodeVO.getOveredWeightMap().get(findWeight).add(gatheringList.get(i));
								}

								leftOverWeight = selectTonWeight.intValue() - leftOverWeight - findWeight;
								break;
							}
						} else {
							infoByBrandCodeVO.getOveredWeightMap().put(leftOverWeight, new ArrayList<ItemPriceMatchingBlInfoVO>());
							BigDecimal orderWeight = BigDecimal.ZERO;

							if(!"02".equals(itemPriceMatchingSelectVO.getSellMethodCode())) {	// 실재고가 잔여재고보다 큰데 실재고로 매칭되는문제로 잔여재고 기준으로 중량정보생성(라이브만)
								orderWeight = new BigDecimal(leftOverWeight);
							} else {
								BigDecimal inventoryUnSel = gatheringList.get(i).getSleInvntryUnsleBnt();
								int resultCompare = inventoryUnSelBundle.compareTo(new BigDecimal(leftOverWeight));

								if(resultCompare >= 0) { // 실재고가 잔여재고보다 작으면 매칭실패처리(케이지몰)
									orderWeight = inventoryUnSel;
								} else {
									break;
								}
							}
							//재 설정된 중량으로 번들, 이론 잔량 재조회
							ItemPriceMatchingWeightCalculateValuesVO reMatchingWeightValueVo = gatheringList.get(i).getWeightMappingCalculateValues().get(BigDecimal.valueOf(orderWeight.intValue()));
							
							//선택된 값을 선택하게된 기준 번들 값과 기준 중량을 설정
							gatheringList.get(i).setMatchedSleInvntryUnsleBundleBnt(reMatchingWeightValueVo.getCollectBundle());
							gatheringList.get(i).setMatchedSleInvntryUnsleBnt(reMatchingWeightValueVo.getCollectBundleLogicalWeight());
							gatheringList.get(i).setMatchedOrderedBnt(orderWeight);
							gatheringList.get(i).setOrderWeight(orderWeight);

							infoByBrandCodeVO.getOveredWeightMap().get(leftOverWeight).add(gatheringList.get(i));

							leftOverWeight = selectTonWeight.intValue() - leftOverWeight - orderWeight.intValue();
							break;
						}
					}
				}

				int lastPriorRankToBandCode = getLastPriorRankFromBandCodeMap(brandCodeToPriorRank);

				/*
				//우선순위 높은것 (낮은수) 부터 탐색
				for(int priorRank = 0; priorRank < lastPriorRankToBandCode + 1; priorRank++) {

					//우선순위 숫자가 있는 브랜드코드가 존재한다면
					if(brandCodeToPriorRank.containsKey(priorRank)) {
						String brandCode = brandCodeToPriorRank.get(priorRank);
						//원하는 주문량에 가능한 재고(합산재고)가 있는것만 탐색
						if(gatheringInfoByBrandCodeMap.containsKey(brandCode)) {

							ItemPriceGatheringInfoByBrandCodeVO gatheringInfoByBrandCodeVo = gatheringInfoByBrandCodeMap.get(brandCode);

							//맞는 수량을 찾아서 적용한 BL 값의 각 BL의 수량 값을 모두 더한 값
							int totalMatchedSum = 0;
							//주문 수량에서 25 단위를 뺀 초기값
							int nextMatcingWeight = selectTonWeight.intValue() - weightUnit;
							//모든 주문수량에 맞는 BL을 찾을 때 까지 반복, 최대 찾는 갯수 만큼 반복
							while(nextMatcingWeight > 0 && maxBlSearchCount > 0) {

								if(gatheringInfoByBrandCodeVo.getMatchedWeightMap().containsKey(nextMatcingWeight)
										&& !gatheringInfoByBrandCodeVo.getMatchedWeightMap().get(nextMatcingWeight).isEmpty()) {

									List<ItemPriceMatchingBlInfoVO> matchingBlInfoVoList = gatheringInfoByBrandCodeVo.getMatchedWeightMap().get(nextMatcingWeight);

									//해당 수량에 대한 BL list에 딱맞는 값의 index를 찾아서 return
									int index = returnClosestMatchingVoIndex(selectTonWeight, BigDecimal.valueOf(nextMatcingWeight), matchingBlInfoVoList);

									//딱맞는 BL 값을 결과 list에 저장
									returnList.add(matchingBlInfoVoList.get(index));

									//사용한 BL 값을 찾은 삭제한다.
									gatheringInfoByBrandCodeVo.getMatchedWeightMap().get(nextMatcingWeight).remove(index);
									//선택한 수량 값을 전체 수량에 더한다.
									totalMatchedSum += nextMatcingWeight;

									//다음에 맞는 수량이 남아 있지 않다면 다음 수량에 관한 while 문을 돌린다.
									if(!gatheringInfoByBrandCodeVo.getMatchedWeightMap().containsKey(selectTonWeight.intValue() - nextMatcingWeight)) {
										nextMatcingWeight = selectTonWeight.intValue() - nextMatcingWeight;
									}

									maxBlSearchCount--;

								} else {
									nextMatcingWeight -= weightUnit;
								}

								//선택 수량을 모두 더한 값이 주문 수량보다 많거나 같으면 탐색 끝
								if(totalMatchedSum >= selectTonWeight.intValue()) {
									//작은 중량 VO 여러개 return
									itemPriceMatchingBlWrhousngVO.setItemPriceMatchingBlInfoVO(returnList);
									itemPriceMatchingBlWrhousngVO.setLeftOverWeight(0);

									return itemPriceMatchingBlWrhousngVO;
								} else {
									if(nextMatcingWeight <= 0 || maxBlSearchCount <= 0) {
										itemPriceMatchingBlWrhousngVO.setItemPriceMatchingBlInfoVO(returnList);
										itemPriceMatchingBlWrhousngVO.setLeftOverWeight(selectTonWeight.intValue() - totalMatchedSum);
									}
								}
							}

							//더 많은 수량을 찾아서 적용한 BL 값의 주문 수를 모두 더한 값 -> 위의 딱 맞는 수를 제외한 나머지 수량을 기준으로 함
							int totalOveredSum = totalMatchedSum;
							//주문 수량에서 25 단위를 뺀 초기값
							int nextOverWeight = selectTonWeight.intValue() - weightUnit;
							//모든 주문수량에 맞는 BL을 찾을 때 까지 반복, 최대 찾는 갯수 만큼 반복
							while(nextOverWeight > 0 && maxBlSearchCount > 0) {

								if(gatheringInfoByBrandCodeVo.getOveredWeightMap().containsKey(nextOverWeight)
										&& !gatheringInfoByBrandCodeVo.getOveredWeightMap().get(nextOverWeight).isEmpty()) {

									List<ItemPriceMatchingBlInfoVO> matchingBlInfoVoList = gatheringInfoByBrandCodeVo.getOveredWeightMap().get(nextOverWeight);

									//해당 수량에 대한 BL list에 수량	보다 많은 값의 index를 찾아서 return
									int index = returnClosestMatchingVoIndex(selectTonWeight, BigDecimal.valueOf(nextOverWeight), matchingBlInfoVoList);

									//더 많은 BL 값을 결과 list에 저장
									returnList.add(matchingBlInfoVoList.get(index));

									//사용한 BL 값을 찾은 삭제한다.
									gatheringInfoByBrandCodeVo.getOveredWeightMap().get(nextOverWeight).remove(index);
									//선택한 수량 값을 전체 수량에 더한다.
									totalOveredSum += nextOverWeight;

									//다음에 맞는 수량이 남아 있지 않다면 다음 수량에 관한 while 문을 돌린다.
									if(!gatheringInfoByBrandCodeVo.getOveredWeightMap().containsKey(selectTonWeight.intValue() - nextOverWeight)) {
										nextOverWeight = selectTonWeight.intValue() - nextOverWeight;
									}

									maxBlSearchCount--;

								} else {
									nextOverWeight -= weightUnit;
								}

								if(totalOveredSum >= selectTonWeight.intValue()) {
									//작은 중량 VO 여러개 return
									itemPriceMatchingBlWrhousngVO.setItemPriceMatchingBlInfoVO(returnList);
									itemPriceMatchingBlWrhousngVO.setLeftOverWeight(0);

									return itemPriceMatchingBlWrhousngVO;
								} else {
									if(nextOverWeight <= 0 || maxBlSearchCount <= 0) {
										itemPriceMatchingBlWrhousngVO.setItemPriceMatchingBlInfoVO(returnList);
										itemPriceMatchingBlWrhousngVO.setLeftOverWeight(selectTonWeight.intValue() - totalMatchedSum);
									}
								}
							}
						}
					}
				}
				*/

				//우선순위 높은것 (낮은수) 부터 탐색
				for(int priorRank = 0; priorRank < lastPriorRankToBandCode + 1; priorRank++) {

					//우선순위 숫자가 있는 브랜드코드가 존재한다면
					if(brandCodeToPriorRank.containsKey(priorRank)) {
						String brandCode = brandCodeToPriorRank.get(priorRank);
						//원하는 주문량에 가능한 재고(합산재고)가 있는것만 탐색
						if(gatheringInfoByBrandCodeMap.containsKey(brandCode)) {

							// 1. 브랜드코드 기준 get ItemPriceGatheringInfoByBrandCodeVO
							ItemPriceGatheringInfoByBrandCodeVO gatheringInfoByBrandCodeVo = gatheringInfoByBrandCodeMap.get(brandCode);

							// 2. 	-1). get MatchedWeighMap from gatheringInfoByBrandCodeVo
							//		-2). get OverdWeightMap from gatheringInfoByBrandCodeVo
							Map<Integer, List<ItemPriceMatchingBlInfoVO>> allMatchedWeightMap = gatheringInfoByBrandCodeVo.getMatchedWeightMap();
							Map<Integer, List<ItemPriceMatchingBlInfoVO>> allOverdWeightMap = gatheringInfoByBrandCodeVo.getOveredWeightMap();

							// 3. 중량별로 리스트 적재 - 중량별로 적재 시 정렬 순서 창고코드asc, 창고일asc
							//		-1). find nextMatchedWeight : 주문 수량에서 최소 판매 단위를 뺀 다음 주문 수량값
							int nextMatchedWeight = selectTonWeight.intValue() - weightUnit;
							//		-2). 중량별로 뽑아낸 VO를 담기 위한 리스트 생성
							// MatchedWeightList+
							List<ItemPriceMatchingBlInfoVO> getMatchedWeightList = new ArrayList<ItemPriceMatchingBlInfoVO>();
							// OverdWeightList
							List<ItemPriceMatchingBlInfoVO> getOverdWeightList = new ArrayList<ItemPriceMatchingBlInfoVO>();
							//		-3). nextMatchedWeight가 0이 될 떄까지 반복하여 리스트에 적재 (AL : 75, 50, 25)
							for(int getMatched = nextMatchedWeight; nextMatchedWeight < 0; nextMatchedWeight -= weightUnit ) {
								getMatchedWeightList.clear();
								getOverdWeightList.clear();

								// >> MatchedWeightList 중량별로 리스트 담기
								// 창고 코드 별로 정렬
								getMatchedWeightList = returnWrhouseList(allMatchedWeightMap.get(getMatched));
								gatheringInfoByBrandCodeVo.getMatchedWeightMap().get(getMatched).clear();
								// 재 정렬된 리스트 적재
								gatheringInfoByBrandCodeVo.getMatchedWeightMap().get(getMatched).addAll(getMatchedWeightList);

								// >> OverdWeightList 중량별로 리스트 담기
								// 창고 코드 별로 정렬
								getOverdWeightList = returnWrhouseList(allOverdWeightMap.get(getMatched));
								gatheringInfoByBrandCodeVo.getOveredWeightMap().get(getMatched).clear();
								// 재 정렬된 리스트 적재
								gatheringInfoByBrandCodeVo.getOveredWeightMap().get(getMatched).addAll(getOverdWeightList);
							}

							// 우선순위별 브랜드 코드 Map
							Map<Integer, String> wrHouseCodeToPriorRank = new HashMap<>();

							/*
							 * matchingBlInfoVoList while문
							 */

							//맞는 수량을 찾아서 적용한 BL 값의 각 BL의 수량 값을 모두 더한 값
							int totalMatchedSum = 0;
							//주문 수량에서 25 단위를 뺀 초기값
							int nextMatcingWeight = selectTonWeight.intValue() - weightUnit;
							while(nextMatcingWeight > 0 && maxBlSearchCount > 0) {
								if(gatheringInfoByBrandCodeVo.getMatchedWeightMap().containsKey(nextMatcingWeight)
											&& !gatheringInfoByBrandCodeVo.getMatchedWeightMap().get(nextMatcingWeight).isEmpty()) {
									// 해당 브랜드에 부합하는 중량에 대한 matchingBlInfoVoList 조회
									List<ItemPriceMatchingBlInfoVO> matchingBlInfoVoList = new ArrayList<ItemPriceMatchingBlInfoVO>();
									List<ItemPriceMatchingBlInfoVO> matchingWrHouseBlInfoVoList = new ArrayList<ItemPriceMatchingBlInfoVO>();
									matchingBlInfoVoList.clear();
									matchingWrHouseBlInfoVoList.clear();
									matchingBlInfoVoList = gatheringInfoByBrandCodeVo.getMatchedWeightMap().get(nextMatcingWeight);

									//맵 초기화
									wrHouseCodeToPriorRank.clear();
									// matchingBlInfoVoList의 창고코드 MAP -> 브랜드, 창고코드 별로 BL 조회하기 위함
									for(int i = 0; i < matchingBlInfoVoList.size(); i++) {
										int priorwrhouseRank = matchingBlInfoVoList.get(i).getPriorRankForWrhousCode(); //창고코드 우선순위
										String wrHouseCode = matchingBlInfoVoList.get(i).getWrhousCode();				//창고코드

										//wrHouseCodeToPriorRank Map 초기화, 우선순위에 따른 창고코드 등록 -> 창고코드의 우선순위는 중복되지 않는다.
										if(!wrHouseCodeToPriorRank.containsKey(priorwrhouseRank)) {
											wrHouseCodeToPriorRank.put(priorwrhouseRank, wrHouseCode);
										}
									}

									//우선순위가 높은것 (낮은것)부터 탐색 - 창고
									int lastPriorRankToWrhouseCode = getTopPriorWrhouseIndexFromSearchList(wrHouseCodeToPriorRank);
									// matchingBlInfoVoList - 창고코드 별로 조회 후 matchingWrHouseBlInfoVoList 적재

									for(int priorWrhouseRank = 0; priorWrhouseRank < lastPriorRankToWrhouseCode + 1; priorWrhouseRank++) {
										// matchingWrHouseBlInfoVoList 초기화
										matchingWrHouseBlInfoVoList.clear();
										//우선순위 숫자가 있는 창고코드가 존재한다면
										if(wrHouseCodeToPriorRank.containsKey(priorWrhouseRank)) {
											// 동일한 창고코드 묶음
											for(ItemPriceMatchingBlInfoVO vo : matchingBlInfoVoList) {
												if(priorWrhouseRank == vo.getPriorRankForWrhousCode()){
													matchingWrHouseBlInfoVoList.add(vo);
												}
											}
										}
										// 창고코드 우선 번호)
										// 기본값 =>  matchingBlInfoVoList의 첫번째 BlList의 창고코드
										int priorRankForWrhousCode;

										// 브랜드, 창고코드, 중량 동일한 리스트 조회
										while(matchingWrHouseBlInfoVoList.size() > 0) {
											//해당 수량에 대한 BL list에 딱맞는 값의 index를 찾아서 return
											int index = returnClosestMatchingVoIndex(selectTonWeight, BigDecimal.valueOf(nextMatcingWeight), matchingWrHouseBlInfoVoList);
											priorRankForWrhousCode = matchingWrHouseBlInfoVoList.get(index).getPriorRankForWrhousCode();

											List<ItemPriceMatchingBlInfoVO> ItemPriceMatchingBlInfoVO = new  ArrayList<ItemPriceMatchingBlInfoVO>();
											ItemPriceMatchingBlInfoVO.clear();
											ItemPriceMatchingBlInfoVO.add(matchingWrHouseBlInfoVoList.get(index));

											// returnMatchingListMap에 해당 창고코드에 대한 이력이 없을 경우
											if(!returnMatchingListMap.containsKey(priorRankForWrhousCode)) {
												//returnListMap에 해당 bl 정보 적재
												returnMatchingListMap.put(priorRankForWrhousCode, ItemPriceMatchingBlInfoVO);
											// returnListMap에 해당 창고코드에 대한 이력이 이미 존재한다면
											}else {
												returnMatchingListMap.get(priorRankForWrhousCode).add(matchingWrHouseBlInfoVoList.get(index));
											}
											//사용한 BL 값은 삭제한다.
											matchingWrHouseBlInfoVoList.remove(index);
										}

										List<ItemPriceMatchingBlInfoVO> returnMatchingWrHouseBlInfoVoList = new ArrayList<ItemPriceMatchingBlInfoVO>();
										List<ItemPriceMatchingBlInfoVO> returnMatchingWrHouseBlInfoVoList2 = new ArrayList<ItemPriceMatchingBlInfoVO>();
										returnList.clear();
										returnMatchingWrHouseBlInfoVoList.clear();
										returnMatchingWrHouseBlInfoVoList2.clear();

										returnMatchingWrHouseBlInfoVoList = returnMatchingListMap.get(priorWrhouseRank);

										if(returnMatchingListMap.containsKey(priorWrhouseRank)) {
											for(ItemPriceMatchingBlInfoVO vo : returnMatchingWrHouseBlInfoVoList) {
												if(priorWrhouseRank == vo.getPriorRankForWrhousCode()) {
													returnMatchingWrHouseBlInfoVoList2.add(vo);
												}
											}
										}

										if(returnMatchingWrHouseBlInfoVoList2.size() > 0) {
											//초기화
											totalMatchedSum = 0;
											int chkWeight = 0;
											maxBlChk = maxBlSearchCount;
											for(ItemPriceMatchingBlInfoVO vo : returnMatchingWrHouseBlInfoVoList2) {
												chkWeight += vo.getMatchedOrderedBnt().intValue();
												totalMatchedSum = chkWeight;
											}

											if(totalMatchedSum != 0) {
												maxBlChk -= (totalMatchedSum/minSearchBoundaryWeight);
											}

											if(totalMatchedSum >= selectTonWeight.intValue()) {
												returnList.clear();
												returnList = returnMatchingWrHouseBlInfoVoList2;
												//작은 중량 VO 여러개 return
												itemPriceMatchingBlWrhousngVO.setItemPriceMatchingBlInfoVO(returnList);
												itemPriceMatchingBlWrhousngVO.setLeftOverWeight(0);
												maxBlSearchCount = maxBlChk;
												return itemPriceMatchingBlWrhousngVO;
											}
										}

										//가장 마지막 창고코드인 경우 중량 감소
										if(lastPriorRankToWrhouseCode == priorWrhouseRank) {
											nextMatcingWeight -= weightUnit;
										}
									}
								}else {
									nextMatcingWeight -= weightUnit;
								}
							}


							/*
							 * OverWeightgBlInfoVoList while문
							 */

							//맞는 수량을 찾아서 적용한 BL 값의 각 BL의 수량 값을 모두 더한 값
							int totalOverdSum = 0;
							//주문 수량에서 25 단위를 뺀 초기값
							int nextOverdWeight = selectTonWeight.intValue() - weightUnit;
							while(nextOverdWeight > 0 && maxBlSearchCount > 0) {
								if(gatheringInfoByBrandCodeVo.getOveredWeightMap().containsKey(nextOverdWeight)
										&& !gatheringInfoByBrandCodeVo.getOveredWeightMap().get(nextOverdWeight).isEmpty()) {

									// 해당 브랜드에 부합하는 중량에 대한 matchingBlInfoVoList 조회
									List<ItemPriceMatchingBlInfoVO> overMatchingBlInfoVoList = new ArrayList<ItemPriceMatchingBlInfoVO>();
									List<ItemPriceMatchingBlInfoVO> overMatchingWrHouseBlInfoVoList = new ArrayList<ItemPriceMatchingBlInfoVO>();
									overMatchingBlInfoVoList.clear();
									overMatchingWrHouseBlInfoVoList.clear();
									overMatchingBlInfoVoList = gatheringInfoByBrandCodeVo.getOveredWeightMap().get(nextOverdWeight);

									//맵 초기화
									wrHouseCodeToPriorRank.clear();
									// matchingBlInfoVoList의 창고코드 MAP -> 브랜드, 창고코드 별로 BL 조회하기 위함
									for(int i = 0; i < overMatchingBlInfoVoList.size(); i++) {
										int priorwrhouseRank = overMatchingBlInfoVoList.get(i).getPriorRankForWrhousCode(); //창고코드 우선순위
										String wrHouseCode = overMatchingBlInfoVoList.get(i).getWrhousCode();				//창고코드

										//wrHouseCodeToPriorRank Map 초기화, 우선순위에 따른 창고코드 등록 -> 창고코드의 우선순위는 중복되지 않는다.
										if(!wrHouseCodeToPriorRank.containsKey(priorwrhouseRank)) {
											wrHouseCodeToPriorRank.put(priorwrhouseRank, wrHouseCode);
										}
									}

									//우선순위가 높은것 (낮은것)부터 탐색 - 창고
									int lastPriorRankToWrhouseCode = getTopPriorWrhouseIndexFromSearchList(wrHouseCodeToPriorRank);
									// overMatchingBlInfoVoList - 창고코드 별로 조회 후 overMatchingWrHouseBlInfoVoList 적재

									for(int priorWrhouseRank = 0; priorWrhouseRank < lastPriorRankToWrhouseCode + 1; priorWrhouseRank++) {
										// matchingWrHouseBlInfoVoList 초기화
										overMatchingWrHouseBlInfoVoList.clear();
										//우선순위 숫자가 있는 창고코드가 존재한다면
										if(wrHouseCodeToPriorRank.containsKey(priorWrhouseRank)) {
											// 동일한 창고코드 묶음
											for(ItemPriceMatchingBlInfoVO vo : overMatchingBlInfoVoList) {
												if(priorWrhouseRank == vo.getPriorRankForWrhousCode()){
													overMatchingWrHouseBlInfoVoList.add(vo);
												}
											}
										}
										// 창고코드 우선 번호)
										// 기본값 =>  matchingBlInfoVoList의 첫번째 BlList의 창고코드
										int priorRankForWrhousCode;

										// 브랜드, 창고코드, 중량 동일한 리스트 조회
										while(overMatchingWrHouseBlInfoVoList.size() > 0) {
											//해당 수량에 대한 BL list에 딱맞는 값의 index를 찾아서 return
											int index = returnBiggestVoIndex(selectTonWeight, overMatchingWrHouseBlInfoVoList);
											priorRankForWrhousCode = overMatchingWrHouseBlInfoVoList.get(index).getPriorRankForWrhousCode();

											List<ItemPriceMatchingBlInfoVO> ItemPriceMatchingBlInfoVO = new  ArrayList<ItemPriceMatchingBlInfoVO>();
											ItemPriceMatchingBlInfoVO.clear();
											ItemPriceMatchingBlInfoVO.add(overMatchingWrHouseBlInfoVoList.get(index));

											// returnListMap에 해당 창고코드에 대한 이력이 없을 경우
											if(!returnOverMatchingListMap.containsKey(priorRankForWrhousCode)) {
												//returnListMap에 해당 bl 정보 적재
												returnOverMatchingListMap.put(priorRankForWrhousCode, ItemPriceMatchingBlInfoVO);
											// returnListMap에 해당 창고코드에 대한 이력이 이미 존재한다면
											}else {
												returnOverMatchingListMap.get(priorRankForWrhousCode).add(overMatchingWrHouseBlInfoVoList.get(index));
											}
											//사용한 BL 값을 찾은 삭제한다.
											overMatchingWrHouseBlInfoVoList.remove(index);
										}

										List<ItemPriceMatchingBlInfoVO> returnOverMatchingWrHouseBlInfoVoList = new ArrayList<ItemPriceMatchingBlInfoVO>();
										List<ItemPriceMatchingBlInfoVO> returnOverMatchingWrHouseBlInfoVoList2 = new ArrayList<ItemPriceMatchingBlInfoVO>();
										returnList.clear();
										returnOverMatchingWrHouseBlInfoVoList.clear();
										returnOverMatchingWrHouseBlInfoVoList2.clear();

										returnOverMatchingWrHouseBlInfoVoList = returnOverMatchingListMap.get(priorWrhouseRank);

										if(returnOverMatchingListMap.containsKey(priorWrhouseRank)) {
											for(ItemPriceMatchingBlInfoVO vo : returnOverMatchingWrHouseBlInfoVoList) {
												if(priorWrhouseRank == vo.getPriorRankForWrhousCode()) {
													returnOverMatchingWrHouseBlInfoVoList2.add(vo);
												}
											}
										}

										if(returnOverMatchingWrHouseBlInfoVoList2.size() > 0) {
											//초기화
											totalOverdSum = 0;
											int chkWeight = 0;
											maxOverBlChk = maxBlSearchCount;
											for(ItemPriceMatchingBlInfoVO vo : returnOverMatchingWrHouseBlInfoVoList2) {
												chkWeight += vo.getMatchedOrderedBnt().intValue();
												totalOverdSum = chkWeight;
											}

											if(totalOverdSum != 0) {
												maxOverBlChk -= (totalOverdSum/minSearchBoundaryWeight);
											}

											if(totalOverdSum >= selectTonWeight.intValue()) {
												returnList.clear();
												returnList = returnOverMatchingWrHouseBlInfoVoList2;
												//작은 중량 VO 여러개 return
												itemPriceMatchingBlWrhousngVO.setItemPriceMatchingBlInfoVO(returnList);
												itemPriceMatchingBlWrhousngVO.setLeftOverWeight(0);
												maxBlSearchCount = maxOverBlChk;


												return itemPriceMatchingBlWrhousngVO;
											}
										}
										//가장 마지막 창고코드인 경우 중량 감소
										if(lastPriorRankToWrhouseCode == priorWrhouseRank) {
											nextOverdWeight -= weightUnit;
										}
									}
								}else {
									nextOverdWeight -= weightUnit;
								}
							}

							int nextOtherWeight = selectTonWeight.intValue() - weightUnit;
							int maxOtherCount;
							Integer returnKey = 0;
							List<ItemPriceMatchingBlInfoVO> gara = new ArrayList<ItemPriceMatchingBlInfoVO>();
							// 주문중량보다 작은 (ex 100 > 75 의 톨로런스 범위에 맞는 bl)
							List<ItemPriceMatchingBlInfoVO> allMatchingList = new ArrayList<ItemPriceMatchingBlInfoVO>();
							// 주문중량보다 큰 (ex 75 >> 90 톨로런스 범위 이상의 bl)
							List<ItemPriceMatchingBlInfoVO> allOverMatchingList = new ArrayList<ItemPriceMatchingBlInfoVO>();
							List<ItemPriceMatchingBlInfoVO> allList = new ArrayList<ItemPriceMatchingBlInfoVO>();
							List<ItemPriceMatchingBlInfoVO> allReturnList = new ArrayList<ItemPriceMatchingBlInfoVO>();
							Map<Integer, List<ItemPriceMatchingBlInfoVO>> lastReturnMap = new HashMap<>();
							Map<Integer, List<ItemPriceMatchingBlInfoVO>> lastReturnMap2 = new HashMap<>();
							Map<Integer, Integer> chkListMap = new HashMap<>();
//							while(maxBlChk > 0 && maxOverBlChk > 0) {
							if(maxBlChk > 0 || maxOverBlChk > 0) {
								int chkWeight;
								if(!returnMatchingListMap.isEmpty() || !returnOverMatchingListMap.isEmpty()) {
									if(!returnMatchingListMap.isEmpty()) {
										// matchingBlInfoList 기준으로 창고코드 Map
										for(Integer key : returnMatchingListMap.keySet()){

											//matchingList
											if(returnMatchingListMap.containsKey(key)) {
												if(!lastReturnMap.containsKey(key)) {
													lastReturnMap.put(key, gara);
												}
												for(ItemPriceMatchingBlInfoVO vo : returnMatchingListMap.get(key)) {
													int chk = 0;
													for(ItemPriceMatchingBlInfoVO vo2 : allMatchingList) {
														if(vo2.getBlNo().equals(vo.getBlNo())) {
															chk++;
														}
													}
													if(chk==0) {
														allMatchingList.add(vo);
													}
												}
											}

											//overMatchingList
											if(!returnOverMatchingListMap.isEmpty()) {
												if(returnOverMatchingListMap.containsKey(key)) {
													if(!lastReturnMap.containsKey(key)) {
														lastReturnMap.put(key, gara);
													}
													for(ItemPriceMatchingBlInfoVO vo : returnOverMatchingListMap.get(key)) {
														int chk = 0;
														for(ItemPriceMatchingBlInfoVO vo2 : allOverMatchingList) {
															if(vo2.getBlNo().equals(vo.getBlNo())) {
																chk++;
															}
														}
														if(chk==0) {
															allOverMatchingList.add(vo);
														}
													}
												}
											}
										}
									}

									if(!returnOverMatchingListMap.isEmpty()) {
										// overMatchingList 기준으로 창고코드 Map
										for(Integer key : returnOverMatchingListMap.keySet()){

											//matchingList
											if(!returnMatchingListMap.isEmpty()) {
												if(returnMatchingListMap.containsKey(key)) {
													if(!lastReturnMap.containsKey(key)) {
														lastReturnMap.put(key, gara);
													}
													for(ItemPriceMatchingBlInfoVO vo : returnMatchingListMap.get(key)) {
														int chk = 0;
														for(ItemPriceMatchingBlInfoVO vo2 : allMatchingList) {
															if(vo2.getBlNo().equals(vo.getBlNo())) {
																chk++;
															}
														}
														if(chk==0) {
															allMatchingList.add(vo);
														}
													}
												}
											}

											//overMatchingList
											if(returnOverMatchingListMap.containsKey(key)) {
												if(!lastReturnMap.containsKey(key)) {
													lastReturnMap.put(key, gara);
												}
												for(ItemPriceMatchingBlInfoVO vo : returnOverMatchingListMap.get(key)) {
													int chk = 0;
													for(ItemPriceMatchingBlInfoVO vo2 : allOverMatchingList) {
														if(vo2.getBlNo().equals(vo.getBlNo())) {
															chk++;
														}
													}
													if(chk==0) {
														allOverMatchingList.add(vo);
													}
												}
											}
										}
									}
								}

								if(!lastReturnMap.isEmpty()) {
									for(Integer key : lastReturnMap.keySet()) {
										allList = new ArrayList<ItemPriceMatchingBlInfoVO>();
										for(ItemPriceMatchingBlInfoVO vo : allMatchingList) {
											int chk = 0;
											int wrhCode = vo.getPriorRankForWrhousCode();
//											if(vo.getPriorRankForWrhousCode() == key) {
											if(wrhCode == key.intValue()) {
												for(ItemPriceMatchingBlInfoVO vo2 : allList) {
													if(vo.getPriorRankForWrhousCode() == vo2.getPriorRankForWrhousCode()) {
														if(vo2.getBlNo().equals(vo.getBlNo())) {
															chk++;
														}
													}else {
														chk++;
													}
												}
												if(chk==0) {
													allList.add(vo);
												}
											}
										}
										for(ItemPriceMatchingBlInfoVO vo : allOverMatchingList) {
											//allList.clear();
											int chk2 = 0;
											int wrhCode2 = vo.getPriorRankForWrhousCode();
//											if(vo.getPriorRankForWrhousCode() == key) {
											if(wrhCode2 == key.intValue()) {
												for(ItemPriceMatchingBlInfoVO vo2 : allList) {
													if(vo.getPriorRankForWrhousCode() == vo2.getPriorRankForWrhousCode()) {
														if(vo2.getBlNo().equals(vo.getBlNo())) {
															chk2++;
														}
													}else {
														chk2++;
													}
												}
												if(chk2==0) {
													allList.add(vo);
												}
											}
										}

										if(!lastReturnMap2.containsKey(key)) {
											if(key == allList.get(0).getPriorRankForWrhousCode()) {
												lastReturnMap2.put(key, allList);
											}
										}

									}
								}
								if(!lastReturnMap2.isEmpty()) {
									for(Integer key : lastReturnMap2.keySet()){
										chkWeight = 0;
										maxOtherCount = maxBlSearchCount;
										allReturnList.clear();
										allReturnList.addAll(lastReturnMap2.get(key));
										returnList.clear();

										if(!chkListMap.containsKey(key)) {
											chkListMap.put(key, 0);
										}

										for(ItemPriceMatchingBlInfoVO vo3 : allReturnList) {
											chkWeight += vo3.getMatchedOrderedBnt().intValue();
											chkListMap.put(key, chkWeight);
											returnList.add(vo3);
											if(chkWeight != 0) {
												maxOtherCount -= (chkWeight/minSearchBoundaryWeight);
												nextOtherWeight = chkWeight;
											}
											if(chkWeight >= selectTonWeight.intValue()) {
												itemPriceMatchingBlWrhousngVO.setItemPriceMatchingBlInfoVO(returnList);
												itemPriceMatchingBlWrhousngVO.setLeftOverWeight(0);
												maxBlSearchCount = maxOtherCount;

												return itemPriceMatchingBlWrhousngVO;
											}
										}
									}

									returnList.clear();
									nextOtherWeight = selectTonWeight.intValue() - weightUnit;

									int chkWt = 0;
									//창고별 중량 비교
									for(Integer key : chkListMap.keySet()){
										if(chkWt < chkListMap.get(key)) {
											chkWt = chkListMap.get(key);
										}
									}

									for(Integer key : chkListMap.keySet()){
										if(chkListMap.get(key) == chkWt) {
											returnKey = key;
											break;
										}
									}

									chkWeight = 0;
									maxOtherCount = maxBlSearchCount;
									allReturnList.clear();
									allReturnList.addAll(lastReturnMap2.get(returnKey));

									for(ItemPriceMatchingBlInfoVO vo3 : allReturnList) {
										chkWeight += vo3.getMatchedOrderedBnt().intValue();
										returnList.add(vo3);
									}
									maxOtherCount -= (chkWeight/minSearchBoundaryWeight);
									maxBlSearchCount = maxOtherCount;
									itemPriceMatchingBlWrhousngVO.setItemPriceMatchingBlInfoVO(returnList);
									itemPriceMatchingBlWrhousngVO.setLeftOverWeight(selectTonWeight.intValue() - chkWeight);

									return itemPriceMatchingBlWrhousngVO;
								}
							}
						}
					}
				}
				//재고 없음
				itemPriceMatchingBlWrhousngVO.setItemPriceMatchingBlInfoVO(returnList);
			}
			//재고 없음
			itemPriceMatchingBlWrhousngVO.setItemPriceMatchingBlInfoVO(returnList);
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		}

		return itemPriceMatchingBlWrhousngVO;
	}

	/**
	 * <pre>
	 * 처리내용: 입고일이 가장 오래된 BL list return
	 * </pre>
	 * @date 2023. 11. 09.
	 * @author hyunjin0512
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 11. 09.	hyunjin0512 		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return list
	 */
	private List<ItemPriceMatchingBlInfoVO> returnMinWrhousngDeList(List<ItemPriceMatchingBlInfoVO> vo){

		List<ItemPriceMatchingBlInfoVO> wrhousngDeList = new ArrayList<ItemPriceMatchingBlInfoVO>();

		SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
		int wrhousngDe = 29991231;
		int newWrhousngDe = 0;

		for(ItemPriceMatchingBlInfoVO deVo : vo){
			newWrhousngDe = Integer.parseInt(format.format(deVo.getWrhousngDe()));
			//창고 입고일
			if(wrhousngDe > newWrhousngDe ){
				wrhousngDeList.clear();
				wrhousngDe = newWrhousngDe ;
				wrhousngDeList.add(deVo);
			}else if(wrhousngDe == newWrhousngDe){
				wrhousngDeList.add(deVo);
			}
		}
		return wrhousngDeList;
	}

	/**
	 * <pre>
	 * 처리내용: 기준값을 기준으로 BL List에서 가장 적합한 중량을 지닌 BL의 index를 return 한다.
	 * </pre>
	 * @date 2021. 9. 14.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 14.		Kwon sun hyung		최초작성
	 * 2023. 11. 08.	hyunjin0512 		입고날짜 우선 처리
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param selectTonWeight
	 * @param matchingValue
	 * @param vo
	 * @return int
	 */
	private int returnClosestMatchingVoIndex(BigDecimal selectTonWeight, BigDecimal matchingValue, List<ItemPriceMatchingBlInfoVO> vo) {
		//ItemPriceMatchingBlInfoVO returnVo = new ItemPriceMatchingBlInfoVO();

		List<ItemPriceMatchingBlInfoVO> wrhousngDeList = new ArrayList<ItemPriceMatchingBlInfoVO>();
		wrhousngDeList = returnMinWrhousngDeList(vo);

		int returnIndex = 0;
		int returnRealIndex = 0;
		BigDecimal abs = selectTonWeight.subtract(wrhousngDeList.get(0).getWeightMappingCalculateValues().get(matchingValue).getLogicalWeight()).abs();

		for(int z = 1; z < wrhousngDeList.size(); z++) {
			BigDecimal compareAbs = selectTonWeight.subtract(wrhousngDeList.get(z).getWeightMappingCalculateValues().get(matchingValue).getLogicalWeight()).abs();
			//System.out.println("compareAbs");
			//System.out.println(compareAbs);
			if(compareAbs.compareTo(abs) < 0) {
				abs = compareAbs;
				returnIndex = z;
			}
		}

		String wrhouseBlNo = wrhousngDeList.get(returnIndex).getBlNo();

		for(int y = 0; y < vo.size(); y++) {
			if(vo.get(y).getBlNo() == wrhouseBlNo) {
				returnRealIndex = y;
			}
		}

		return returnRealIndex;
	}

	/**
	 * <pre>
	 * 처리내용: 기준값을 기준으로 BL List에서 가장 큰 이론중량을 지닌 BL의 index를 return 한다.
	 * </pre>
	 * @date 2021. 9. 14.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 14.		Kwon sun hyung		최초작성
	 * 2023. 11. 08.	hyunjin0512 		입고날짜 우선 처리
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param selectTonWeight
	 * @param vo
	 * @return int
	 */
	private int returnBiggestVoIndex(BigDecimal selectTonWeight, List<ItemPriceMatchingBlInfoVO> vo) {
		//ItemPriceMatchingBlInfoVO returnVo = new ItemPriceMatchingBlInfoVO();

		List<ItemPriceMatchingBlInfoVO> wrhousngDeList = new ArrayList<ItemPriceMatchingBlInfoVO>();
		wrhousngDeList = returnMinWrhousngDeList(vo);

		int returnIndex = 0;
		int returnRealIndex = 0;
		BigDecimal selectBiggest = wrhousngDeList.get(0).getWeightMappingCalculateValues().get(selectTonWeight).getLogicalWeight();

		for(int i = 1; i < wrhousngDeList.size(); i++) {
			BigDecimal logicalWeight = wrhousngDeList.get(i).getWeightMappingCalculateValues().get(selectTonWeight).getLogicalWeight();
			//System.out.println("logicalWeight");
			//System.out.println(logicalWeight);
			//if(logicalWeight.compareTo(selectBiggest) > 0) { //큰것부터
			if(logicalWeight.compareTo(selectBiggest) < 0) { //작은것부터
				selectBiggest = logicalWeight;
				returnIndex = i;
			}
		}

		String wrhouseBlNo = wrhousngDeList.get(returnIndex).getBlNo();

		for(int y = 0; y < vo.size(); y++) {
			if(vo.get(y).getBlNo() == wrhouseBlNo) {
				returnRealIndex = y;
			}
		}

		return returnRealIndex;
	}


	/**
	 * <pre>
	 * 처리내용: 해당 BL 값에 최소 주문중량 값과 최대 주문중량 값을 기준으로 25 중량당 tolerance 범위 및 최소,최대,최적 번들 수 와 중량 계산
	 * </pre>
	 * @date 2021. 9. 14.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @param minWeight
	 * @param maxWeight
	 * @return Map<BigDecimal, ItemPriceMatchingWeightValuesVO>
	 */
	@Override
	public Map<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO> setMathcingValuesMap(ItemPriceMatchingBlInfoVO vo
																							, int minWeight
																							, int maxWeight
																							, int weightUnit) {

		Map<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO> map = new HashMap<>();

		double hundred = 100;
		//double bsisWrhousngInvntry = vo.getBsisWrhousngInvntry().doubleValue();
		//double bsisWrhousngBundleInvntry = vo.getBsisWrhousngBundleInvntry();
		double sleInvntryUnsleBundleBnt = vo.getSleInvntryUnsleBundleBnt();
		double ctrtcBeginPermWtRate = vo.getCtrtcBeginPermWtRate();
		double ctrtcEndPermWtRate = vo.getCtrtcEndPermWtRate();
		double avgNum = vo.getNetAvrgWt().doubleValue(); // Db field NET_AVRG_WT

		for(int i = minWeight; i <= maxWeight; i += weightUnit) {
			ItemPriceMatchingWeightCalculateValuesVO valueVo = new ItemPriceMatchingWeightCalculateValuesVO();

			//평균중량(평균값)
			//double avgNum = Math.round((bsisWrhousngInvntry / bsisWrhousngBundleInvntry) * 10000) / 10000.0;

			//이론중량
			double logicalWeight = Math.round((avgNum * sleInvntryUnsleBundleBnt) * 1000) / 1000.0;

			//이론중량
			double collectLogicalWeight = Math.round((avgNum * i) * 1000) / 1000.0;

			//tolerance 최소
			double minTolerance = i * (Math.round((ctrtcBeginPermWtRate / hundred) * 1000) / 1000.0) * -1;
			//tolerance 최대
			double maxTolerance = i * (Math.round((ctrtcEndPermWtRate / hundred) * 1000) / 1000.0);

			//최소중량
			double minTonWeight = minTolerance + i;
			//최대중량
			double maxTonWeight = maxTolerance + i;

			if(minTonWeight > maxTonWeight) {
				maxTonWeight = minTonWeight;
			}

			//주문 수량에 따른 최소 번들 수
			double minBundle = Math.round(minTonWeight / avgNum);
			//주문 수량에 따른 최대 번들 수
			double maxBundle = Math.floor(maxTonWeight / avgNum);
			//주문 수량에 따른 최적 번들 수
			double collectBundle = getCollectBundleCalculate(i, avgNum, minBundle, maxBundle);
			//최적 번들에 따른 이론중량
			double collectBundleLogicalWeight = Math.round((avgNum * collectBundle) * 1000) / 1000.0;

			valueVo.setAvgNum(BigDecimal.valueOf(avgNum));
			valueVo.setLogicalWeight(BigDecimal.valueOf(logicalWeight));
			valueVo.setCollectLogicalWeight(BigDecimal.valueOf(collectLogicalWeight));
			valueVo.setMinTonWeight(BigDecimal.valueOf(minTonWeight));
			valueVo.setMaxTonWeight(BigDecimal.valueOf(maxTonWeight));
			valueVo.setMinBundle(BigDecimal.valueOf(minBundle));
			valueVo.setMaxBundle(BigDecimal.valueOf(maxBundle));
			valueVo.setCollectBundle(BigDecimal.valueOf(collectBundle));
			valueVo.setCollectBundleLogicalWeight(BigDecimal.valueOf(collectBundleLogicalWeight));

			map.put(BigDecimal.valueOf(i), valueVo);
		}

		return map;
	}

	//최소, 최대 오차범위중량과 이론중량을 비교해서 최적중량이 오차에 벗어나지않게 자릿수 조절
	public double getCollectBundleCalculate(int index, double avgNum, double minBundle, double maxBundle) {
		double collectBundle = 0;
		double tonWeight = index / avgNum;

		if (tonWeight < minBundle) {
			collectBundle = Math.round(tonWeight);
		} else if (tonWeight > maxBundle) {
			collectBundle = Math.floor(tonWeight);
		} else if (tonWeight >= minBundle && tonWeight <= maxBundle) {
			collectBundle = Math.round(tonWeight);
		}

		return collectBundle;
	}


	/**
	 * <pre>
	 * 처리내용: 가장 우선순위가 높은 값의 List index를 return한다
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param list
	 * @return int
	 */
	private int getTopPriorIndexFromSearchList(List<ItemPriceMatchingBlInfoVO> list) {

		int returnIndex = 0;
		int priorRank = list.get(0).getPriorRank();

		for(int i = 1; i < list.size(); i++) {
			if(priorRank > list.get(i).getPriorRank()) {
				returnIndex = i;
				priorRank = list.get(i).getPriorRank();
			}
		}

		return returnIndex;
	}

	/**
	 * <pre>
	 * 처리내용: 가장 우선순위가 높은 값의 List index를 return한다 - 창고
	 * </pre>
	 * @date 2023. 11. 21
	 * @author hyunjin0512
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 11. 21		hyunjin0512		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param list
	 * @return int
	 */
	private int getTopPriorWrhouseIndexFromSearchList(Map<Integer, String> map) {

		int priorRank = 0;
		for(Map.Entry<Integer, String> mapEntry : map.entrySet()) {
			if(priorRank < mapEntry.getKey()) {
				priorRank = mapEntry.getKey();
			}
		}

		return priorRank;
	}

	/**
	 * <pre>
	 * 처리내용: 가장 마지막 우선 순위 값을 return 한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param map
	 * @return int
	 */
	private int getLastPriorRankFromBandCodeMap(Map<Integer, String> map) {

		int priorRank = 0;
		for(Map.Entry<Integer, String> mapEntry : map.entrySet()) {
			if(priorRank < mapEntry.getKey()) {
				priorRank = mapEntry.getKey();
			}
		}

		return priorRank;
	}

	/**
	 * <pre>
	 * 처리내용: BL List 재정렬, 창고 코드 기준
	 * </pre>
	 * @date 2023. 11. 21.
	 * @author hyunjin0512
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 11. 21.		hyunjin0512		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param ItemPriceMatchingBlInfoVO
	 * @return ItemPriceMatchingBlInfoVO
	 */
	private List<ItemPriceMatchingBlInfoVO> returnWrhouseList(List<ItemPriceMatchingBlInfoVO> paramList) {

		List<ItemPriceMatchingBlInfoVO> returnWrhouseList = new ArrayList<ItemPriceMatchingBlInfoVO>();
		int priorRankForWrhousCode = 9999;
		int rePriorRankForWrhousCode = 0;

		for(ItemPriceMatchingBlInfoVO vo : returnWrhouseList) {
			rePriorRankForWrhousCode = vo.getPriorRankForWrhousCode();
			if(priorRankForWrhousCode > rePriorRankForWrhousCode) {
				returnWrhouseList.clear();
				priorRankForWrhousCode = rePriorRankForWrhousCode;
				returnWrhouseList.add(vo);
			}else {
				returnWrhouseList.add(vo);
			}
		}
		return returnWrhouseList;
	}
}
