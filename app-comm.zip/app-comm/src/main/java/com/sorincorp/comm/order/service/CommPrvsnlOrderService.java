package com.sorincorp.comm.order.service;

import java.util.List;

import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.order.model.CommLimitGroupModel;
import com.sorincorp.comm.order.model.CommOrLimitOrderBasVO;
import com.sorincorp.comm.order.model.CommPrvsnlDcsnInfoVO;
import com.sorincorp.comm.order.model.CommPrvsnlOrderVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.comm.pcInfo.model.PrSelVO;

/**
 * commPrvsnlOrderService.java
 * 가단가 주문 공통 Service 인터페이스
 * @version
 * @since 2024. 9. 9.
 * @author srec0066
 */
public interface CommPrvsnlOrderService {

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 번호로 해당 가단가 주문 내역 가져오기 [단일]
	 * </pre>
	 * @date 2024. 9. 10.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 10.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public CommOrLimitOrderBasVO selectCommOrPrvsnlOrderBas(String limitOrderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 번호들로 해당 가단가 주문 내역 리스트 가져오기 [복수]
	 * </pre>
	 * @date 2024. 9. 10.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 10.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public List<CommOrLimitOrderBasVO> selectCommOrPrvsnlOrderBasList(List<String> limitOrderNoList) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문 번호에 대한 공통 가단가 확정 여부 정보 가져오기
	 *  1. untpcDcsnAt : 단가 확정 여부 (Y, N)
	 *  2. singlDcsnCd : 단일(단가) 확정 코드
	 *    - LIVE_DCSN (라이브 단일(단가) 확정)
	 *    - LIMIT_DCSN (지정가 단일(단가) 확정)
	 *    - LIMIT_WAIT (지정가 단일(단가) 확정 대기)
	 *  3. lmeDcsnCd : LME 분리 확정 코드
	 *    - LIVE_DCSM (라이브 LME 분리 확정)
	 *    - LIMIT_DCSM (지정가 LME 분리 확정)
	 *    - LIMIT_WAIT (지정가 LME 분리 확정 대기)
	 *  4. fxDcsnCd : FX 분리 확정 코드
	 *    - LIVE_DCSM (라이브 FX 분리 확정)
	 *    - LIMIT_DCSM (지정가 FX 분리 확정)
	 *    - LIMIT_WAIT (지정가 FX 분리 확정 대기)
	 * </pre>
	 * @date 2024. 9. 12.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 12.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	public CommPrvsnlDcsnInfoVO getPrvsnlDcsnAtInfo(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 확정 단가 계산
	 * </pre>
	 * @date 2024. 9. 27.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 27.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public void calculateUntpcDcsnInfo(OrderModel orderModel, CommPrvsnlOrderVO prvsnlOrder) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 단가 확정 및 정산 프로세스 실행
	 * </pre>
	 * @date 2024. 9. 27.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 27.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public void executeUntpcDcsnExcclcProcess(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 해당 가단가 지정가 주문 번호의 지정가 주문 상태 코드를 변경 [단일]
	 * [
	 *     10(미체결), 20(주문처리중), 30.체결, 31.부분 체결, 40(주문취소(본인)), 41(주문취소(관리자))
	 *   , 90(체결실패(선물 실패)), 91(체결실패(재고 부족)), 92(체결실패(잔액 부족)), 93(체결실패(당일 유효 시간 경과)), 94(체결실패(유효성 검사 실패)), 95(체결실패(기타))
	 * ]
	 * </pre>
	 * @date 2024. 9. 19.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 19.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param limitOrderNoList
	 * @param limitOrderSttusCode
	 * @param limitOrderFailrResn
	 * @param lastChangerId
	 * @return
	 * @throws Exception
	 */
	public int updateCommPrvsnlLimitOrderSttusCode(String limitOrderNo, String limitOrderSttusCode, String limitOrderFailrResn, String lastChangerId) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 해당 가단가 지정가 주문 번호 리스트의 지정가 주문 상태 코드를 변경 [복수]
	 * [
	 *     10(미체결), 20(주문처리중), 30.체결, 31.부분 체결, 40(주문취소(본인)), 41(주문취소(관리자))
	 *   , 90(체결실패(선물 실패)), 91(체결실패(재고 부족)), 92(체결실패(잔액 부족)), 93(체결실패(당일 유효 시간 경과)), 94(체결실패(유효성 검사 실패)), 95(체결실패(기타))
	 * ]
	 * </pre>
	 * @date 2024. 9. 19.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 19.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param limitOrderNoList
	 * @param limitOrderSttusCode
	 * @param limitOrderFailrResn
	 * @param lastChangerId
	 * @return
	 * @throws Exception
	 */
	public int updateCommPrvsnlLimitOrderSttusCode(List<String> limitOrderNoList, String limitOrderSttusCode, String limitOrderFailrResn, String lastChangerId) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 가단가 지정가 주문 큐 메시지 정보 업데이트
	 * </pre>
	 * @date 2024. 9. 27.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 27.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public int updateOrLimitOrderLmeBasQueueInfo(CommLimitGroupModel commLimitGroupModel) throws Exception;	 // LME
	public int updateOrLimitOrderEhgtBasQueueInfo(CommLimitGroupModel commLimitGroupModel) throws Exception; // FX
	public int updateOrLimitOrderKrwBasQueueInfo(CommLimitGroupModel commLimitGroupModel) throws Exception;	 // KRW
	public int updateOrOrderBasQueueInfo(CommLimitGroupModel commLimitGroupModel, String limitSeCode, String orderNo) throws Exception; // 주문_주문 기본

	/**
	 * <pre>
	 * 처리내용: 가단가 주문의 BL목록을 조회
	 * </pre>
	 * @date 2024. 9. 20.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 20.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param orderNo
	 * @return List<ItemPriceMatchingBlInfoVO>
	 * @throws Exception
	 */
	public List<ItemPriceMatchingBlInfoVO> selectPrvsnlOrderBlList(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 번호[단일] 가단가 지정가 주문 실패 시
	 * </pre>
	 * @date 2024. 9. 10.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 10.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param targetLimitOrderNo
	 * @param limitOrderSttusCode
	 * @param limitSection
	 * @param limitOrderFailrResn
	 * @param changeId
	 */
	public void prvsnlLimitOrderFail(String targetLimitOrderNo, String limitOrderSttusCode, String limitOrderFailrResn, String changeId);

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 번호[복수] 가단가 지정가 주문 실패 시
	 * </pre>
	 * @date 2024. 9. 27.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 27.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param targetLimitOrderNo
	 * @param limitOrderSttusCode
	 * @param limitSection
	 * @param limitOrderFailrResn
	 * @param changeId
	 */
	public void prvsnlLimitOrderFail(List<String> targetLimitOrderNoList, String limitOrderSttusCode, String limitOrderFailrResn, String changeId);

	/**
	 * <pre>
	 * 처리내용: 가단가 지정가 주문 체결 실패 SMS 발송 (템플릿 108)
	 * </pre>
	 * @date 2024. 10. 31.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 31.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param limitOrderNo
	 */
	public void prvsnlLimitOrderFailSendSms(String limitOrderNo);

	/**
	 * <pre>
	 * 처리내용: 가단가 지정가 주문 취소 SMS 발송 (템플릿 110 (주문 취소), 128 (주문 자동 취소))
	 * </pre>
	 * @date 2024. 10. 31.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 31.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param limitOrderNo
	 * @param batchType (Y:128 자동 주문 취소, N:110 주문 취소)
	 */
	public void prvsnlLimitOrderCancelSendSms(String limitOrderNo, String batchType);

	/**
	 * <pre>
	 * 처리내용: 가장 최근 가격정보 조회 (프리미엄 제외 endPc)
	 * </pre>
	 * @date 2024. 11. 4.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 11. 4.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public PrSelVO getPreRealEndPc(String metalCode, Integer itmSn, String dstrcLclsfCode, String brandGroupCode, String brandCode);

	/**
	 * <pre>
	 * 처리내용: 가격 변동금 기본 조회
	 * </pre>
	 * @date 2024. 11. 7.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 11. 7.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public CommPrvsnlOrderVO selectOrPcChangegldBas(String orderNo, int occrrncSn) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 입금에 따른 가격 변동금 정보 수정
	 * </pre>
	 * @date 2024. 11. 11.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 11.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @param occrrncSn
	 * @param setleNo
	 * @throws Exception
	 */
	public void updateOrPcOrPcChangegldBasByRcpmny(String orderNo, int occrrncSn, String setleNo, String mberId) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 출금에 따른 가격 변동금 정보 수정
	 * </pre>
	 * @date 2024. 11. 11.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 11.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @param occrrncSn
	 * @param setleNo
	 * @throws Exception
	 */
	public void updateOrPcOrPcChangegldBasByDefray(String orderNo, int occrrncSn, String setleNo, String mberId) throws Exception;
}
