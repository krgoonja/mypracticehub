package com.sorincorp.comm.pcInfo.service;

import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import com.sorincorp.comm.pcInfo.model.FixPrice2VO;
import com.sorincorp.comm.pcInfo.model.FixPriceVO;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.LmePcVO;
import com.sorincorp.comm.pcInfo.model.PcMntrngSelVO;
import com.sorincorp.comm.pcInfo.model.PrEhgtRltmVO;
import com.sorincorp.comm.pcInfo.model.PrEhgtStdrVO;
import com.sorincorp.comm.pcInfo.model.PrEhgtVO;
import com.sorincorp.comm.pcInfo.model.PrPremiumSelVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.model.PreminumSelInfoVO;
import com.sorincorp.comm.pcInfo.model.RvcmpnVO;

public interface PcInfoService {

	
	
	/**
	 * <pre>
	 * 일, 주, 월, 분기별 금속코드와 발생날짜를 입력해 LME 시세를 조회한다.(캐시 등록, 키값 조회)
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 19.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode (금속코드)
	 * @param occrrnc (발생날짜) (일 : yyyyMMdd(20210719), 주 : yyyyww(202109), 월 : yyyyMM(202107), 분기 : yyyyQU(202103))
	 * @param occrrncType (발생날짜 타입) (일 : DD, 주 : WW, 월 : MM, 분기 : QU)
	 * @return
	 * @throws Exception
	 */
	public LmePcVO getPrLme(String metalCode, String occrrnc ,String occrrncType) throws Exception;
	
	/**
	 * <pre>
	 * 일, 주, 월, 분기별 인조식별자 순번을 입력해 LME 시세를 조회한다.(캐시 등록, 순번 조회)
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 19.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode (금속 코드)
	 * @param lmePcSn (LME 가격 순번)
	 * @param occrrncType (발생날짜 타입) (일 : DD, 주 : WW, 월 : MM, 분기 : QU)
	 * @return
	 * @throws Exception
	 */
	public LmePcVO getPrLmeSn(String metalCode, String lmePcSn ,String occrrncType) throws Exception;
	
	/**
	 * <pre>
	 * 일일 금속코드와 발생날짜, 발생시간, 발생순번을 입력해 LME 시세를 조회한다.(캐시x)
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 19.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode (금속코드)
	 * @param occrrncDe (발생일자) (yyyyMMdd)
	 * @param occrrncTime (발생시간) (HHmmss)
	 * @param occrrncSn (발생순번)
	 * @return
	 * @throws Exception
	 */
	public LmePcVO getPrLmeRltm(String metalCode, String occrrncDe, String occrrncTime, String occrrncSn ) throws Exception;
	
	/**
	 * <pre>
	 * 실시간 순번을 입력해 LME 시세를 조회한다.(캐시x)
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 14.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode (금속코드)
	 * @param occrrncDe (발생날짜) (yyyymmdd)
	 * @return
	 * @throws Exception
	 */
	public LmePcVO getNewestPrLmeRltm(String metalCode, String occrrncDe) throws Exception;
	
	/**
	 * <pre>
	 * LME 실시간 시세를 순번으로 조회한다.(캐시x)
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 14.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode (금속 코드) 
	 * @param lmePcRltmSn (시세 순번)
	 * @return
	 * @throws Exception
	 */
	public LmePcVO getPrLmeRltmSn(String metalCode, String lmePcRltmSn) throws Exception;

	/**
	 * <pre>
	 * LME 전일 종가를 조회 한다.
	 * </pre>
	 * @date 2024. 10. 22.
	 * @author hamyoonsic
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 22.		hamyoonsic		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode (금속 코드)
	 * @return
	 * @throws Exception
	 */
	public LmePcVO getPrLmeAgo(String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 일, 주, 월, 분기별 금속코드, 아이템, 권역, 브랜드 그룹, 브랜드와 발생날짜를 입력해 판매가격 시세를 조회한다. (캐시 등록)
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 19.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode (금속코드)
	 * @param itmSn (아이템 순번)
	 * @param dstrctLclsfCode (권역 대분류 코드)
	 * @param brandGroupCode (브랜드 그룹 코드)
	 * @param brandCode (브랜드 그룹 코드)
	 * @param occrrnc (발생날짜) (일 : yyyyMMdd(20210719), 주 : yyyyww(202109), 월 : yyyyMM(202107), 분기 : yyyyQU(202103))
	 * @param occrrncType (발생 일자 타입) (일 : DD, 주 : WW, 월 : MM, 분기 : QU)
	 * @return
	 * @throws Exception
	 */
	public PrSelVO getPrSel(String metalCode, Integer itmSn ,String dstrctLclsfCode, String brandGroupCode, String brandCode, String occrrnc, String occrrncType) throws Exception;

	/**
	 * <pre>
	 * 일, 주, 월, 분기별 인조식별자 순번을 입력해 판매가격 시세를 조회한다.(캐시 등록)
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 19.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode (금속 코드) 
	 * @param sellPcSn (판매 가격 순번)
	 * @param occrrncType (발생 일자 타입) (일 : DD, 주 : WW, 월 : MM, 분기 : QU)
	 * @return
	 * @throws Exception
	 */
	public PrSelVO getPrSelSn(String metalCode, String sellPcSn, String occrrncType) throws Exception;
	
	/**
	 * <pre>
	 * 일일 금속코드, 아이템, 권역, 브랜드 그룹, 브랜드와 발생날짜, 발생시간, 발생순번을 입력해 판매가격 시세를 조회한다.(캐시x)
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 19.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode (금속 코드)
	 * @param itemSn (아이템 순번)
	 * @param dstrcLclsfCode (권역 대분류 코드)
	 * @param brandGroupCode (브랜드 그룹 코드)
	 * @param brandCode (브랜드 코드)
	 * @param occrrncDe (발생 일자 YYYYMMDD)
	 * @param occrrncTime (발생 시간 hhmmss)
	 * @param occrrncSn (발생 순번)
	 * @return
	 * @throws Exception
	 */
	public PrSelVO getPrSelRltm(String metalCode, Integer itemSn, String dstrcLclsfCode, String brandGroupCode
			, String brandCode, String occrrncDe, String occrrncTime, String occrrncSn) throws Exception;
	
	/**
	 * <pre>
	 * 일일 금속코드, 아이템, 권역, 브랜드 그룹, 브랜드와 발생날짜를 입력해 해당 날짜의 최신 판매가격 시세를 조회한다.(캐시x)
	 * </pre>
	 * @date 2021. 7. 22.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 22.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @param itemSn
	 * @param dstrcLclsfCode
	 * @param brandGroupCode
	 * @param brandCode
	 * @param occrrncDe
	 * @return
	 * @throws Exception
	 */
	public PrSelVO getNewestPrSelRltm(String metalCode, Integer itemSn, String dstrcLclsfCode, String brandGroupCode
			, String brandCode, String occrrncDe) throws Exception;
	
	/**
	 * <pre>
	 * 일일 금속코드, 아이템, 브랜드 그룹, 브랜드와 발생날짜를 입력해 해당 날짜의 최신 판매가격 시세를 조회한다.(캐시x)
	 * </pre>
	 * @date 2021. 10. 26.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 10. 26.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @param itemSn
	 * @param dstrcLclsfCode
	 * @param brandGroupCode
	 * @param brandCode
	 * @param occrrncDe
	 * @return
	 * @throws Exception
	 */
	public PrSelVO getNewestPrSelRltmNonStandard(String metalCode, Integer itemSn, String dstrcLclsfCode, String brandGroupCode
			, String brandCode, String occrrncDe) throws Exception;
	
	/**
	 * <pre>
	 * 판매 실시간 가격을 순번으로 조회한다. (캐시x)
	 * </pre>
	 * @date 2021. 7. 19.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 19.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode (금속 코드) 
	 * @param selPcRltmSn
	 * @return
	 * @throws Exception
	 */
	public PrSelVO getPrSelRltmSn(String metalCode, String slePcRltmSn) throws Exception;
	

	/**
	 * <pre>
	 * 금속코드, 아이탬번호, 지역코드, 브랜드그룹코드, 브랜드코드, 날짜를 보내 보낸 날짜보다 과거의 가장 최신 판매가격 데이터를 불러온다.
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 9.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @param itmSn
	 * @param dstrctLclsfCode
	 * @param brandGroupCode
	 * @param brandCode
	 * @param occrrnc
	 * @return
	 * @throws Exception
	 */
	public PrSelVO getNewestPrSelDe(String metalCode, Integer itmSn ,String dstrctLclsfCode, String brandGroupCode, String brandCode, String occrrncDe) throws Exception;
	
	/**
	 * <pre>
	 * 일, 주, 월, 분기별 통화와 발생날짜를 입력해 환율 시세를 조회한다.(캐시 등록, 키값 조회)
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ehgtDelngCrncyCode (통화) 
	 * @param occrrncValue (기간값) (일 : yyyyMMdd(20210719), 주 : yyyyww(202109), 월 : yyyyMM(202107), 분기 : yyyyQU(202103))
	 * @param occrrncType (발생 일자 타입) (일 : DD, 주 : WW, 월 : MM, 분기 : QU)
	 * @return
	 */
	public PrEhgtVO getPrEhgt(String ehgtDelngCrncyCode, String occrrncValue, String occrrncType) throws Exception;
	/**
	 * <pre>
	 * 일, 주, 월, 분기별 인조식별자 순번을 입력해 환율 시세를 조회한다.(캐시 등록, 순번 조회)
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ehgtDelngCrncyCode (환율 거래 통화 코드)
	 * @param occrrncSn (순번)
	 * @param occrrncType (발생 일자 타입) (일 : DD, 주 : WW, 월 : MM, 분기 : QU)
	 * @return
	 */
	public PrEhgtVO getPrEhgtSn(String ehgtDelngCrncyCode, String ehgtPcRltmSn, String occrrncType) throws Exception;
	/**
	 * <pre>
	 * 일일 금속코드와 발생날짜, 발생시간, 발생순번을 입력해 환율 시세를 조회한다.(캐시x)
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ehgtDelngCrncyCode (통화)
	 * @param occrrncDe (발생 일자 YYYYMMDD)
	 * @param occrrncTime (발생 시간 hhmmss)
	 * @param occrrncSn    (순번)
	 * @return
	 */
	public PrEhgtRltmVO getPrEhgtRltm(String ehgtDelngCrncyCode, String occrrncDe, String occrrncTime, String occrrncSn) throws Exception;
	/**
	 * <pre>
	 * 실시간 순번을 입력해 환율 시세를 조회한다.(캐시x)
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ehgtDelngCrncyCode (환율 거래 통화 코드)
	 * @param ehgtPcRltmSn (실시간 순번)
	 * @return
	 */
	public PrEhgtRltmVO getPrEhgtRltmSn(String ehgtDelngCrncyCode, String ehgtPcRltmSn) throws Exception;
		
	/**
	 * <pre>
	 * 현시간 환율 실시간 가격을 조회한다. (캐시x)
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 14.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param ehgtDelngCrncyCode (통화)
	 * @param occrrncDe          (발생일자)
	 * @return
	 * @throws Exception
	 */
	public PrEhgtStdrVO getPrEhgtStdr(String ehgtDelngCrncyCode, String occrrncDe) throws Exception;
	
	
//	사용하는 곳 없음 20230525
//	/**
//	 * <pre>
//	 * 금속코드, 아이템, 권역 , 브랜드 그룹, 브랜드, 일자 입력으로 LIVE 프리미엄 가격 조회
//	 * </pre>
//	 * @date 2021. 7. 14.
//	 * @author srec0031
//	 * @history 
//	 * ------------------------------------------------
//	 * 변경일					작성자				변경내용
//	 * ------------------------------------------------
//	 * 2021. 7. 14.			srec0031			최초작성
//	 * ------------------------------------------------
//	 * @param metalCode : 메탈코드
//	 * @param itmSn : 아이템 순번
//	 * @param dstrctLclsfCode : 권역 대분류 코드
//	 * @param brandGroupCode : 브랜드 그룹 코드
//	 * @param brandCode : 브랜드 코드
//	 * @param occrrncDe : 발생일자
//	 * @return
//	 */
//	public LivePremiumVO getLivePremium(String metalCode, Integer itmSn, String dstrctLclsfCode, String brandGroupCode, String brandCode, String occrrncDe) throws Exception;
	
//	getLivePremiumInfoList 통합으로 사용 안함 20230525
//	/**
//	 * <pre>
//	 * 프리미엄번호 입력으로 LIVE 프리미엄 가격 조회
//	 * </pre>
//	 * @date 2021. 7. 14.
//	 * @author srec0031
//	 * @history 
//	 * ------------------------------------------------
//	 * 변경일					작성자				변경내용
//	 * ------------------------------------------------
//	 * 2021. 7. 14.			srec0031			최초작성
//	 * ------------------------------------------------
//	 * @param premiumNo : 프리미엄 번호
//	 * @return
//	 */
//	public LivePremiumVO getLivePremiumNo(String premiumNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 프리미엄 아이디 및 관련 조건으로 시점 코드 [present: 현재 시점, past: 과거 시점]에 따른 프리미엄 가격 정보 리스트 가져오기
	 * </pre>
	 * @date 2023. 5. 25.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 25.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param timePointCode
	 * @param premiumId
	 * @param metalCode
	 * @param itmSn
	 * @param dstrctLclsfCode
	 * @param brandGroupCode
	 * @param brandCode
	 * @param limitOrderTmByFormat
	 * @return
	 * @throws Exception
	 */
	public List<LivePremiumVO> getLivePremiumInfoList(String timePointCode, String premiumId, String metalCode, Integer itmSn, String dstrctLclsfCode
			, String brandGroupCode, String brandCode, String limitOrderTmByFormat) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 프리미엄 아이디 및 관련 조건으로 시점 코드 [present: 현재 시점, past: 과거 시점]에 따른 프리미엄 가격 정보 가져오기
	 * </pre>
	 * @date 2023. 5. 25.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 25.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param timePointCode
	 * @param premiumId
	 * @param metalCode
	 * @param itmSn
	 * @param dstrctLclsfCode
	 * @param brandGroupCode
	 * @param brandCode
	 * @param limitOrderTmByFormat
	 * @return
	 * @throws Exception
	 */
	public LivePremiumVO getLivePremiumInfo(String timePointCode, String premiumId, String metalCode, Integer itmSn, String dstrctLclsfCode
			, String brandGroupCode, String brandCode, String limitOrderTmByFormat) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 프리미엄 번호 조건으로 시점 코드 [present: 현재 시점, past: 과거 시점]에 따른 프리미엄 가격 정보 가져오기
	 * </pre>
	 * @date 2023. 5. 25.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 25.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param timePointCode
	 * @param premiumNo
	 * @return
	 * @throws Exception
	 */
	public LivePremiumVO getLivePremiumInfo(String timePointCode, String premiumNo) throws Exception;
	
	/**
	 * <pre>
	 * 일/월별 금속코드, 아이템, 권역 , 브랜드 그룹, 브랜드 평균 LIVE 프리미엄 가격 조회
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param metalCode : 메탈코드
	 * @param itmSn : 아이템 순번
	 * @param dstrctLclsfCode : 권역 대분류 코드
	 * @param brandGroupCode : 브랜드 그룹 코드
	 * @param brandCode : 브랜드 코드
	 * @param termValue : 일 / 월 값
	 * @param termType : 일 / 월 구분 코드 (DD, MM)
	 * @return
	 */
	public LivePremiumVO getLivePremiumByTerm(String metalCode, Integer itmSn, String dstrctLclsfCode, String brandGroupCode, String brandCode, String termValue, String termType) throws Exception;
	
	/**
	 * <pre>
	 * 기준 매매가 일 평균 정보
	 * </pre>
	 * @date 2022. 7. 22.
	 * @author hyunjin05
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 7. 22.		hyunjin05	최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @param itemSn
	 * @param dstrcLclsfCode
	 * @param brandGroupCode
	 * @param brandCode
	 * @return
	 * @throws Exception
	 */
	public PrSelVO getAvgDeEndPrice(String metalCode, Integer itemSn, String dstrcLclsfCode, String brandGroupCode, String brandCode) throws Exception;
	
	/**
	 * <pre>
	 * 기준 매매가 일 평균 정보 목록
	 * </pre>
	 * @date 2023. 6. 23.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 7. 22.		hyunjin05	최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @param itemSn
	 * @param dstrcLclsfCode
	 * @param brandGroupCode
	 * @param brandCode
	 * @return
	 * @throws Exception
	 */
	public List<PrSelVO> getAvgDeEndPriceList(PrSelVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 금속코드, 아이템, 권역 , 브랜드 그룹, 브랜드, 일자, 업체등급번호 입력으로 고정가 판매가격 조회
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param metalCode : 메탈코드
	 * @param itmSn : 아이템 순번
	 * @param dstrctLclsfCode : 권역 대분류 코드
	 * @param brandGroupCode : 브랜드 그룹 코드
	 * @param brandCode : 브랜드 코드
	 * @param entrpsGradNo : 업체 등급번호
	 * @param occrrncDe : 발생일자
	 * @return
	 */
	public FixPriceVO getFixPrice(String metalCode, Integer itmSn, String dstrctLclsfCode, String brandGroupCode, String brandCode, Long entrpsGradNo, String occrrncDe) throws Exception;
	
	/**
	 * <pre>
	 * 금속코드, 아이템, 권역 , 브랜드 그룹, 브랜드, 일자, 업체등급번호 입력으로 고정가 판매가격 조회
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param metalCode : 메탈코드
	 * @param itmSn : 아이템 순번
	 * @param dstrctLclsfCode : 권역 대분류 코드
	 * @param brandGroupCode : 브랜드 그룹 코드
	 * @param brandCode : 브랜드 코드
	 * @param occrrncDe : 발생일자
	 * @return
	 */
	public FixPriceVO hasFixPriceData(String metalCode, Integer itmSn, String dstrctLclsfCode, String brandGroupCode, String brandCode, String occrrncDe) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 금속코드, 아이템순번, 권역, 브랜드그룹, 브랜드 코드, 업체번호, 적용년월로 고정가 판매가격 조회
	 * </pre>
	 * @date 2023. 3. 7.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 7.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @param itmSn
	 * @param dstrctLclsfCode
	 * @param brandGroupCode
	 * @param brandCode
	 * @param entrpsNo
	 * @param applcYm
	 * @return
	 * @throws Exception
	 */
	public FixPriceVO hasEntrpsFixPriceData(String metalCode, Integer itmSn, String dstrctLclsfCode, String brandGroupCode, String brandCode, String entrpsNo, String applcYm) throws Exception;
	
	public List<FixPriceVO> hasEntrpsFixPriceDataList(String metalCode, String metalClCode, Integer itmSn, String dstrctLclsfCode, String brandGroupCode, String brandCode, String entrpsNo, String applcYm) throws Exception;
		
	/**
	 * <pre>
	 * 프리미엄번호, 업체등급번호 입력으로 고정가 판매가격 조회
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param premiumNo : 프리미엄 번호
	 * @return
	 */
	public FixPriceVO getFixPriceNo(String premiumNo) throws Exception;
	/**
	 * <pre>
	 * 일/월별 금속코드, 아이템, 권역 , 브랜드 그룹, 브랜드 평균 고정가 판매가격 조회
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param metalCode : 메탈코드
	 * @param itmSn : 아이템 순번
	 * @param dstrctLclsfCode : 권역 대분류 코드
	 * @param brandGroupCode : 브랜드 그룹 코드
	 * @param brandCode : 브랜드 코드
	 * @param entrpsGradNo : 업체 등급번호
	 * @param termValue : 일 / 월 값
	 * @param termType : 일 / 월 구분 코드 (DD, MM)
	 * @return
	 */
	public FixPriceVO getFixPriceByTerm(String metalCode, Integer itmSn, String dstrctLclsfCode, String brandGroupCode, String brandCode, Long entrpsGradNo, String termValue, String termType) throws Exception;
	
	/**
	 * <pre>
	 * 메탈코드 입력으로 LIVE 프리미엄 기준아이템 가격 조회
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 9.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param metalCode : 메탈코드
	 * @return
	 */
	public LivePremiumVO getLivePremiumStdrByMetalCode(String metalCode) throws Exception;
	
	
	/**
	 * <pre>
	 * 적용일자, 브랜드그룹코드, 메탈코드 입력으로 경쟁사 가격을 조회
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 9.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param applcDe : 적용일자
	 * @param brandGroupCode : 브랜드그룹코드
	 * @param metalCode : 메탈코드
	 * @return
	 */
	public RvcmpnVO getRvcmpn(String applcDe, String brandGroupCode, String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 적용일자, 브랜드그룹코드, 메탈코드리스트 입력으로 경쟁사 가격목록을 조회
	 * </pre>
	 * @date 2023. 6. 23.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 23.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param RvcmpnVO
	 * @return
	 */
	public List<RvcmpnVO> getRvcmpnList(RvcmpnVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 적용일자, 메탈코드 입력으로 경쟁사 가격을 조회
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param applcDe : 적용일자
	 * @param metalCode : 메탈코드
	 * @return
	 */
	public List<RvcmpnVO> getRvcmpn(String applcDe, String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 통화를 입력해 최신 환율 시세를 조회한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ehgtDelngCrncyCode (통화)
	 * @return
	 */
	public PrEhgtRltmVO getNewestPrEhgtRltm(String ehgtDelngCrncyCode);
	
	/**
	 * <pre>
	 * 통화코드와 발생날짜를 입력해 오늘 날짜 이전의 일별 최종 환율 시세를 조회한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ehgtDelngCrncyCode (통화)
	 * @param occrrncDe (발생 일자 YYYYMMDD)
	 * @return
	 */
	public PrEhgtRltmVO getNewestPrEhgtRltmByDay(String ehgtDelngCrncyCode, String occrrncDe);

	/**
	 * <pre>
	 * 전일 거래용 환율 조회
	 * </pre>
	 * @date 2024. 10. 22.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 10. 22.		hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param
	 * @return
	 */
	public PrEhgtStdrVO getPrEhgtAgo() throws Exception;

	/**
	 * <pre>
	 * 프리미엄 기준아이템 브랜드 그룹 리스트 조회 
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param metalCode : 금속코드
	 * @param brandGroupCode : 브랜드그룹
	 * @return
	 */
	List<LivePremiumVO> getStdrPremiumList(String premiumId, String brandGroupCode) throws Exception;
	/**
	 * <pre>
	 * 금속코드, 아이템, 브랜드 그룹, 브랜드, 일자, 업체등급번호 입력으로 고정가 판매가격 조회
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param metalCode : 메탈코드
	 * @param itmSn : 아이템 순번
	 * @param brandGroupCode : 브랜드 그룹 코드
	 * @param brandCode : 브랜드 코드
	 * @param occrrncDe : 발생일자
	 * @return
	 */
	List<FixPriceVO> getFixPrice(String metalCode, Integer itmSn, String brandGroupCode, String brandCode, String occrrncDe) throws Exception;
	/**
	 * <pre>
	 * 금속코드, 적용년월로 고정가 정보 조회
	 * </pre>
	 * @date 2021. 11. 02.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 02.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param applcYm : 적용 년월
	 * @param metalCode : 메탈코드
	 * 
	 * @return
	 */
	List<FixPrice2VO> getFixPrice(String applcYm, String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 종목별 프리미엄 정보 조회
	 * </pre>
	 * @date 2023. 5. 9.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 9.			srec0061			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	Map<String, TreeSet<LivePremiumVO>> getPremiumInfoMap() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 메인차트 타이틀의 시가,고가,저가,종가 및 전날종가, 등락률 정보를 가져온다.
	 * </pre>
	 * @date 2023. 5. 15.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 15.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param prSelVO
	 * @return
	 */
	PrSelVO getChartTitleInfo(PrSelVO prSelVO);
	

	/**
	 * <pre>
	 * 처리내용: 임시
	 * </pre>
	 * @date 2023. 7. 6.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 7. 6.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param prSelVO
	 * @return
	 */
	List<PrSelVO> getBrandGroupPriceInfoList(PrSelVO prSelVO);
	
	/**
	 * <pre>
	 * 1분 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcMntrngSelVO> getPcMngtrngSel1MinList(PcMntrngSelVO pcMntrngSelVO) throws Exception;
	
	/**
	 * <pre>
	 * 30분 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcMntrngSelVO> getPcMngtrngSel30MinList(PcMntrngSelVO pcMntrngSelVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 60분 기준 실시간 가격 차트리스트 조회
	 * </pre>
	 * @date 2022. 1. 12.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 12.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 * @throws Exception
	 */
	List<PcMntrngSelVO> getPcMngtrngSel60MinList(PcMntrngSelVO pcMntrngSelVO) throws Exception;
	
	/**
	 * <pre>
	 * 일 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 26.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcMntrngSelVO> getPcMngtrngSelDeList(PcMntrngSelVO pcMntrngSelVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 월 기준 실시간 차트 리스트 조회
	 * </pre>
	 * @date 2022. 1. 12.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 12.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 * @throws Exception
	 */
	List<PcMntrngSelVO> getPcMngtrngSelMonthList(PcMntrngSelVO pcMntrngSelVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: json형식의 데이터를 \t으로 구분하여 로그를 출력한다.
	 * </pre>
	 * @date 2023. 6. 14.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 14.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param result
	 * @return
	 */
	String logJSONAsTable(String result);
	
	/**
	 * <pre>
	 * 전일 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2023. 7. 3.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 7. 3.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcMntrngSelVO> getEndPcAgoSelDeList(PcMntrngSelVO pcMntrngSelVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 메탈코드, 아이템코드, 권역코드, 브랜드그룹코드, 브랜드코드별 차트타이틀 리스트
	 * </pre>
	 * @date 2023. 7. 12.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 12.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	List<PrPremiumSelVO> getChartTitleInfoList(String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 차트타이틀가격정보 레디스조회
	 * </pre>
	 * @date 2023. 7. 14.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 14.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	Object getChartTitleInfoByRedisData(String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 프리미엄가격정보 레디스조회
	 * </pre>
	 * @date 2023. 7. 24.
	 * @author srec0067
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 24.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	List<PreminumSelInfoVO> getPremiumInfoListByRedisData() throws Exception;
	void setPremiumInfoListByRedisData() throws Exception;
}
