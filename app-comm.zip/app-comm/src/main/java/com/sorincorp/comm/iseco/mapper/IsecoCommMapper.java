package com.sorincorp.comm.iseco.mapper;

import java.util.List;

import com.sorincorp.comm.iseco.model.IsecoCommVO;

public interface IsecoCommMapper {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 11. 4.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 4.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	List<IsecoCommVO> selectMetalClCodeList(IsecoCommVO param) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 11. 4.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 4.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	List<IsecoCommVO> selectItmCodeList(IsecoCommVO param) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 11. 4.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 4.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	List<IsecoCommVO> selectDstrctLclsfCodeList(IsecoCommVO param) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 11. 4.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 4.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param param
	 * @return
	 */
	List<IsecoCommVO> selectBrandGroupCodeList(IsecoCommVO param) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 11. 4.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 4.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	List<IsecoCommVO> selectBrandCodeList(IsecoCommVO param) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * 
	 * @date 2022. 11. 25.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 25.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	int selectSleInvntryUnsleBundleBnt(IsecoCommVO param) throws Exception;

}
