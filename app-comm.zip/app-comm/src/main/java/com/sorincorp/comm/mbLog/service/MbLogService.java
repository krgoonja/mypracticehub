package com.sorincorp.comm.mbLog.service;

import com.sorincorp.comm.mbLog.model.MbLogVO;

public interface MbLogService {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 8. 8.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 8. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int insertMbEntrpsInfoBasHst(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 8. 8.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 8. 8.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int insertMbMberInfoBasHst(MbLogVO vo) throws Exception;
}
