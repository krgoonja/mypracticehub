package com.sorincorp.comm.util;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Component;

/**
 * Redis를 사용하기 위한 Utility Class
 * @version
 * @since 2021. 7. 9.
 * @author srec0012
 */
@Component
public class RedisUtil {
	@Autowired
	RedisTemplate<String, Object> redisTemplate;
	
	@Autowired
    RedisTemplate<String, Object> redisTemplateJson;	
	
	/**
	 * <pre>
	 * Redis에서 key에 해당하는 값을 가져온다.
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param key
	 * @return
	 */
	//@SuppressWarnings("unchecked")
	public Object getData(String key) {
		//return cacheUtil.getValue(key);
		ValueOperations<String, Object> valueOperations = redisTemplate.opsForValue();

		// Local Cache 역할로 사용예정이었으나 WAS가 하나가 아니므로 해당 내용으로 오히려 정보가 불일치 할수 있음
//		if (key.equals(CommonConstants.COMMON_CODE_CACHE_KEY)) {
//			if (null!=CommonConstants.commonCodeList) {
//				return CommonConstants.commonCodeList;
//			}
//			else {
//				//CommonConstants.commonCodeList =  (List<CommonCodeVO>)valueOperations.get(key);
//				CommonConstants.setCommonCodeList((List<CommonCodeVO>)valueOperations.get(key));
//				return CommonConstants.commonCodeList;
//			}
//		}
//		else {
			return valueOperations.get(key);
//		}
		
	}

	/**
	 * <pre>
	 * Redis에 정보를 저장한다.
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param key
	 * @param value
	 */
	//@SuppressWarnings("unchecked")
	public void setData(String key, Object value) {
	//	cacheUtil.put(key, value);
		ValueOperations<String, Object> valueOperations = redisTemplate.opsForValue();
		valueOperations.set(key, value);
		
//		if (key.equals(CommonConstants.COMMON_CODE_CACHE_KEY)) {
//			CommonConstants.setCommonCodeList((List<CommonCodeVO>)value);
//			CommonConstants.commonCodeList =  (List<CommonCodeVO>)value;
//		}
	}

	/**
	 * <pre>
	 * 만료기간을 가진 Data를 Redis에 저장한다.
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param key
	 * @param value
	 * @param duration
	 */
	public void setDataExpire(String key, Object value, long duration) {
		ValueOperations<String, Object> valueOperations = redisTemplate.opsForValue();
//		Duration expireDuration = Duration.ofSeconds(duration);
//		valueOperations.set(key, value, expireDuration);
		valueOperations.set(key, value, duration, TimeUnit.MILLISECONDS);
	}

	/**
	 * <pre>
	 * Redis에서 key에 해당하는 Data를 삭제한다. Logout 처리할 때 사용한다.
	 * </pre>
	 * @date 2021. 7. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param key
	 */
	public void deleteData(String key) {
		redisTemplate.delete(key);
	}
	
	/**
	 * <pre>
	 * Key에 해당하는 값이 있는지 확인
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param key
	 * @return
	 */
	public boolean hasKey(String key) {
		return redisTemplate.hasKey(key);
	}
	
	/**
     * <pre>
     * Redis에서 key에 해당하는 값을 가져온다.
     * </pre>
     * @date 2023. 7. 21.
     * @author srec0004
     * @history 
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 7. 21.          srec0004            최초작성
     * ------------------------------------------------
     * @param key
     * @return
     */
    public Object getDataJson(String key) {
        return redisTemplateJson.opsForValue().get(key); 
    }

    /**
     * <pre>
     * Redis에 정보를 저장한다.
     * </pre>
     * @date 2023. 7. 21.
     * @author srec0004
     * @history 
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 7. 21.          srec0004            최초작성
     * ------------------------------------------------
     * @param key
     * @param value
     */
    public void setDataJson(String key, Object value) {
        redisTemplateJson.opsForValue().set(key, value);
    }

    /**
     * <pre>
     * 만료기간을 가진 Data를 Redis에 저장한다.
     * </pre>
     * @date 2023. 7. 21.
     * @author srec0004
     * @history 
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 7. 21.          srec0004            최초작성
     * ------------------------------------------------
     * @param key
     * @param value
     * @param duration
     */
    public void setDataExpireJson(String key, Object value, long duration) {
        redisTemplateJson.opsForValue().set(key, value, duration, TimeUnit.MILLISECONDS);
    }

    /**
     * <pre>
     * Redis에서 key에 해당하는 Data를 삭제한다. Logout 처리할 때 사용한다.
     * </pre>
     * @date 2023. 7. 21.
     * @author srec0004
     * @history 
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023. 7. 21.          srec0004            최초작성
     * ------------------------------------------------
     * @param key
     * @param duration
     */
    public void deleteDataJson(String key) {
        redisTemplateJson.delete(key);
    }
    
    /**
     * <pre>
     * Key에 해당하는 값이 있는지 확인
     * </pre>
     * @date 2021. 7. 14.
     * @author srec0004
     * @history 
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 7. 14.         srec0004            최초작성
     * ------------------------------------------------
     * @param key
     * @return
     */
    public boolean hasKeyJson(String key) {
        return redisTemplateJson.hasKey(key);
    }
}
