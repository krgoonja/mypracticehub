package com.sorincorp.comm.message.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class SMSVO implements Serializable {
	private static final long serialVersionUID = -7673007123204581829L;

	/******  JAVA VO CREATE : SMS_MSG(메시지_SMS 발송)  ******/

	private String mssageSndngHistNo;
	
	private String mberKndSeCode;
	
	private String mberNo;
	
    private long msgKey;
    /**
     * 전송 시간
    */
    private String reqDate;
    /**
     * 
    */
    private int serialNum;
    /**
     * 발송 ID
    */
    private String id;
    /**
     * 발송 상태
    */
    private String status;
    /**
     * 발송 결과
    */
    private String rslt;
    /**
     * 문자 전송 형태
    */
    private String type;
    /**
     * 결과 수신 갯수
    */
    private int repCnt;
    /**
     * 수신 핸드폰 번호
    */
    private String phone;
    /**
     * 송신자 전화번호
    */
    private String callback;
    /**
     * 이통사 결과 통보 시간
    */
    private String rsltDate;
    /**
     * 결과 수신 시간
    */
    private String reportDate;
    /**
     * 전송 메시지
    */
    private String msg;
    /**
     * 이통사 코드
    */
    private String net;
    
    /**
     * 커머스 알림 여부
    */
    private String commerceNtcnAt;
    /**
     * 커머스 알림 내용
    */
    private String commerceNtcnCn;
    /**
     *	메세지 제목 
     */
    private String msgTitle;
    
    /**
     * 메세지 구분 코드
     */
    private String msgSeCode;
    
    // --- MMS ---
    private String sentDate;
    private String subject;
    private int fileCnt;
    private int fileCntReal;
    private String fileType1;
    private String filePath1;
    private String fileType2;
    private String filePath2;
    private String fileType3;
    private String filePath3;
    private String fileType4;
    private String filePath4;
    private String fileType5;
    private String filePath5;
    private String mmsFileName;
    private String barType;
    private int barMergeFile;
    private String barValue;
    private int barSizeWidth;
    private int barSizeHeight;
    private int barPositionX;
    private int barPositionY;
    private String barFileName;
    
    /****** JAVA VO CREATE : KKO_MSG() ******/
    /**
     * 알림톡 실패시 메시지결과
    */
    private String msgRslt;
    /**
     *  알림톡 템플릿 코드
    */
    private String templateCode;
    /**
     * 알림톡 강조표기 제목
    */
    private String templateTitle;
    /**
     * 알림톡 실패시 전송 메시지 타입 (SMS, LMS, MMS, NO)
    */
    private String failedType;
    /**
     * 알림톡 실패시 전송톡 제목
    */
    private String failedSubject;
    /**
     * 알림톡 실패시 전송 내용
    */
    private String failedMsg;
    /**
     * 알림톡 실패시 전송 이미지
    */
    private String failedImg;
    /**
     * 플러스친구 프로파일키
    */
    private String profileKey;
    /**
     * 알림톡 버튼타입 url
    */
    private String url;
    /**
     * 알림톡 버튼타입 text
    */
    private String urlButtonTxt;
    /**
     * 친구톡 이미지 경로
    */
    private String imgPath;
    /**
     * 친구톡 이미지 url
    */
    private String imgUrl;
    /**
     * 버튼그룹 데이터 json
    */
    private String buttonJson;
    /**
     * 친구톡 광고 표시여부
    */
    private String adFlag;
    /**
     * 친구톡 와이드 이미지 표시여부
    */
    private String wiFlag;
    /**
     * 알림톡 메시지내 포함된 가격
    */
    private String price;
    /**
     * 메시지내 가격의 통화단위
    */
    private String currencyType;
    
    /**
     * 기타 필드1
    */
    private String etc1;
    /**
     * sms redirect url
    */
    private String etc2;
    /**
     * 기타 필드3
    */
    private String etc3;
    /**
     * 기타 필드4
    */
    private String etc4;
    /**
     * 기타 필드5
    */
    private String etc5;
    /**
     * 기타 필드6
    */
    private String etc6;
	
    /**
     * SMS/알림톡 구분
     */
	private String smsKkoSe;
	/**
	 * 마케팅 수신동의 여부
	 */
	private String advrtsRecptnAgreAt;
	/**
	 * 회원 권한_참조1 : MBER_SE_CODE : CODE_REFRNONE
	 */
	private String codeRefrnone;
	
	/**
	 * 내부사용자 여부 : Y (내부사용자), N(내부사용자아님)
	 */
	private String mberAt;
}
