package com.sorincorp.comm.wrhouscode.service;

import java.util.List;

import com.sorincorp.comm.wrhouscode.model.WrhousCodeVO;

public interface WrhousCodeService {

	public void initWrhousCode() throws Exception;
	
	public List<WrhousCodeVO> getWrhousCode() throws Exception;
	
	public List<WrhousCodeVO> getDetailWrhousCode(String lclsfDlivyDstrctCode, String mlsfcDlivyDstrctCode) throws Exception;
	
	public String getWrhousCodeTaglibStr(List<WrhousCodeVO> wrhousCodeList) throws Exception;
}
