package com.sorincorp.comm.redis.config;

import java.lang.reflect.Method;

import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.interceptor.SimpleKeyGenerator;

/**
 * 메소드명을 Prefix로 넣어 캐쉬키를 생성하는 키생성자 클래스
 * <pre>사용예: 
 * &#064;Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
 * public LmePcVO getPrLmeSn(Long lmePcSn, String occrrncType) throws Exception
 * 
 * 키 생성 결과: PcInfo::getPrLmeSn.SimpleKey [99,WW]
 * </pre>
 * @version
 * @since 2021. 9. 10.
 * @author srec0004
 */
public class PrefixMethodNameKeyGenerator implements KeyGenerator{

	@Override
	public Object generate(Object target, Method method, Object... params) {
		//simplekey 앞에 prefix로 메소드명을 넣는다.
		//예) PcInfo::getPrLmeSn.SimpleKey [99,WW]
	    StringBuilder keyBuilder = new StringBuilder();
	    keyBuilder.append(method.getName()); 
	    keyBuilder.append(".");
	    keyBuilder.append(SimpleKeyGenerator.generateKey(params));
	    return keyBuilder.toString();
	}
}
