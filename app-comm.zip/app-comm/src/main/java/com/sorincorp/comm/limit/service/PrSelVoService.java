package com.sorincorp.comm.limit.service;

import java.util.Map;

import com.sorincorp.comm.pcInfo.model.PrSelVO;

public interface PrSelVoService {
	Map<String, PrSelVO> getPrSelVo();
	PrSelVO getPrSelVo(String metalCode);
}
