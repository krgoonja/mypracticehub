package com.sorincorp.comm.limit.service;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

import org.springframework.stereotype.Service;

import com.sorincorp.comm.order.model.CommLimitOrderRedisMsgVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderRedisMsgVO;
import com.sorincorp.comm.util.LimitDataUtil;

@Service
public class OrLimitOrderBasVoMapServiceImpl implements OrLimitOrderBasVoMapService {
	private Map<String, CommLimitOrderRedisMsgVO> limitOrderNoInputAmountMap;
	private Map<String, TreeSet<CommLimitOrderRedisMsgVO>> orderCommLimitOrderRedisMsgVoMap;

	/* 가단가 지정가용 */
	private Map<String, CommPrvsnlLimitOrderRedisMsgVO> prvsnlLimitOrderNoInputAmountMap;
	private Map<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> orderCommPrvsnlLimitOrderRedisMsgVoMap;  	// LME, KRW
	private Map<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> orderCommPrvsnlLimitOrderRedisMsgVoFxMap;  // FX

	private static final Comparator<String> COMM_LIMIT_ORDER_COMPARATOR = (key1, key2) -> {
	    if (key1.endsWith(LimitDataUtil.BRAND_UNRELATED) && !key2.endsWith(LimitDataUtil.BRAND_UNRELATED)) {
	        return -1;
	    } else if (!key1.endsWith(LimitDataUtil.BRAND_UNRELATED) && key2.endsWith(LimitDataUtil.BRAND_UNRELATED)) {
	        return 1;
	    } else {
	        return key1.compareTo(key2);
	    }
	};
	
	public OrLimitOrderBasVoMapServiceImpl() {
		if(limitOrderNoInputAmountMap == null) {
			this.limitOrderNoInputAmountMap = new HashMap<String, CommLimitOrderRedisMsgVO>();
		}
		
		if(orderCommLimitOrderRedisMsgVoMap == null) {
			/*
			 * key1이 브랜드 무관 코드라면, -1을 반환하여 key1을 더 작은 값으로 처리
			 * key2가 브랜드 무관 코드라면, 1을 반환하여 key2를 더 작은 값으로 처리
			 * key1과 key2가 모두 브랜드 무관 코드가 아닌 경우에는 key1과 key2를 비교하여 결과를 반환
			*/
			this.orderCommLimitOrderRedisMsgVoMap = new TreeMap<String, TreeSet<CommLimitOrderRedisMsgVO>>(COMM_LIMIT_ORDER_COMPARATOR);
		}

		/* 가단가 지정가 */
		if(prvsnlLimitOrderNoInputAmountMap == null) {
			this.prvsnlLimitOrderNoInputAmountMap = new HashMap<String, CommPrvsnlLimitOrderRedisMsgVO>();
		}

		// LME, KRW
		if(orderCommPrvsnlLimitOrderRedisMsgVoMap == null) {
			this.orderCommPrvsnlLimitOrderRedisMsgVoMap = new TreeMap<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>>();
		}

		// FX
		if(orderCommPrvsnlLimitOrderRedisMsgVoFxMap == null) {
			this.orderCommPrvsnlLimitOrderRedisMsgVoFxMap = new TreeMap<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>>();
		}

	}

	@Override
	public CommLimitOrderRedisMsgVO getLimitOrderNoInputAmountVo(String limitOrderNo) {
		if(!limitOrderNoInputAmountMap.containsKey(limitOrderNo)) {
			limitOrderNoInputAmountMap.put(limitOrderNo, new CommLimitOrderRedisMsgVO());
		}
		return limitOrderNoInputAmountMap.get(limitOrderNo);
	}
	
	@Override
	public void removeLimitOrderNoInputAmountVo(String limitOrderNo) {
		if(limitOrderNoInputAmountMap.containsKey(limitOrderNo)) {
			limitOrderNoInputAmountMap.remove(limitOrderNo);
		}
	}
	
	@Override
	public synchronized Map<String, TreeSet<CommLimitOrderRedisMsgVO>> getOrderCommLimitOrderRedisMsgVoMap() {
		return orderCommLimitOrderRedisMsgVoMap;
	}

	@Override
	public synchronized TreeSet<CommLimitOrderRedisMsgVO> getOrderCommLimitOrderRedisMsgVoMap(String groupCode) {
		if(!orderCommLimitOrderRedisMsgVoMap.containsKey(groupCode)) {
			orderCommLimitOrderRedisMsgVoMap.put(groupCode, new TreeSet<CommLimitOrderRedisMsgVO>());
		}
		
		return orderCommLimitOrderRedisMsgVoMap.get(groupCode);
	}
	
	@Override
	public void setOrderCommLimitOrderRedisMsgVoMap(Map<String, TreeSet<CommLimitOrderRedisMsgVO>> orderCommLimitOrderRedisMsgVoMap) {
		this.orderCommLimitOrderRedisMsgVoMap = new TreeMap<>(COMM_LIMIT_ORDER_COMPARATOR);
		for (Map.Entry<String, TreeSet<CommLimitOrderRedisMsgVO>> entry : orderCommLimitOrderRedisMsgVoMap.entrySet()) {
			String key = entry.getKey();
			TreeSet<CommLimitOrderRedisMsgVO> value = entry.getValue();
			this.orderCommLimitOrderRedisMsgVoMap.put(key, value);
		}
	}

	@Override
	public void clearOrderCommLimitOrderRedisMsgVoMap() {
		this.orderCommLimitOrderRedisMsgVoMap = new TreeMap<String, TreeSet<CommLimitOrderRedisMsgVO>>(COMM_LIMIT_ORDER_COMPARATOR);
	}

	@Override
	public Map<String, CommLimitOrderRedisMsgVO> getLimitOrderNoInputAmountVo() {
		return limitOrderNoInputAmountMap;
	}

	/* 하위부터는 가단가 지정가용 메소드 */
	@Override
	public Map<String, CommPrvsnlLimitOrderRedisMsgVO> getPrvsnlLimitOrderNoInputAmountVo() {
		return prvsnlLimitOrderNoInputAmountMap;
	}

	@Override
	public CommPrvsnlLimitOrderRedisMsgVO getPrvsnlLimitOrderNoInputAmountVo(String limitOrderNo) {
		if(!prvsnlLimitOrderNoInputAmountMap.containsKey(limitOrderNo)) {
			prvsnlLimitOrderNoInputAmountMap.put(limitOrderNo, new CommPrvsnlLimitOrderRedisMsgVO());
		}
		return prvsnlLimitOrderNoInputAmountMap.get(limitOrderNo);
	}

	@Override
	public void removePrvsnlLimitOrderNoInputAmountVo(String limitOrderNo) {
		if(prvsnlLimitOrderNoInputAmountMap.containsKey(limitOrderNo)) {
			prvsnlLimitOrderNoInputAmountMap.remove(limitOrderNo);
		}
	}

	// LME, KRW
	@Override
	public void setOrderCommPrvsnlLimitOrderRedisMsgVoMap(Map<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> orderCommPrvsnlLimitOrderRedisMsgVoMap) {
		this.orderCommPrvsnlLimitOrderRedisMsgVoMap = new TreeMap<>();
		for (Map.Entry<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> entry : orderCommPrvsnlLimitOrderRedisMsgVoMap.entrySet()) {
			String key = entry.getKey();
			TreeSet<CommPrvsnlLimitOrderRedisMsgVO> value = entry.getValue();
			this.orderCommPrvsnlLimitOrderRedisMsgVoMap.put(key, value);
		}
	}

	@Override
	public synchronized Map<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> getOrderCommPrvsnlLimitOrderRedisMsgVoMap() {
		return orderCommPrvsnlLimitOrderRedisMsgVoMap;
	}

	@Override
	public synchronized TreeSet<CommPrvsnlLimitOrderRedisMsgVO> getOrderCommPrvsnlLimitOrderRedisMsgVoMap(String metalCode) {
		if(!orderCommPrvsnlLimitOrderRedisMsgVoMap.containsKey(metalCode)) {
			orderCommPrvsnlLimitOrderRedisMsgVoMap.put(metalCode, new TreeSet<CommPrvsnlLimitOrderRedisMsgVO>());
		}

		return orderCommPrvsnlLimitOrderRedisMsgVoMap.get(metalCode);
	}

	@Override
	public void clearOrderCommPrvsnlLimitOrderRedisMsgVoMap() {
		this.orderCommPrvsnlLimitOrderRedisMsgVoMap = new TreeMap<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>>();
	}

	// FX
	@Override
	public void setOrderCommPrvsnlLimitOrderRedisMsgVoFxMap(Map<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> orderCommPrvsnlLimitOrderRedisMsgVoFxMap) {
		this.orderCommPrvsnlLimitOrderRedisMsgVoFxMap = new TreeMap<>();
		for (Map.Entry<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> entry : orderCommPrvsnlLimitOrderRedisMsgVoFxMap.entrySet()) {
			String key = entry.getKey();
			TreeSet<CommPrvsnlLimitOrderRedisMsgVO> value = entry.getValue();
			this.orderCommPrvsnlLimitOrderRedisMsgVoFxMap.put(key, value);
		}
	}

	@Override
	public synchronized Map<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap() {
		return orderCommPrvsnlLimitOrderRedisMsgVoFxMap;
	}

	@Override
	public synchronized TreeSet<CommPrvsnlLimitOrderRedisMsgVO> getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap(String metalCode) {
		if(!orderCommPrvsnlLimitOrderRedisMsgVoFxMap.containsKey(metalCode)) {
			orderCommPrvsnlLimitOrderRedisMsgVoFxMap.put(metalCode, new TreeSet<CommPrvsnlLimitOrderRedisMsgVO>());
		}

		return orderCommPrvsnlLimitOrderRedisMsgVoFxMap.get(metalCode);
	}

}
