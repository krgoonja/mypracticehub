package com.sorincorp.comm.util;

import java.lang.reflect.Field;

import org.apache.tomcat.util.codec.binary.Base64;

import lombok.extern.slf4j.Slf4j;

/** 
 * Codec 관련 함수를 제공한다.
 * 
 * CodecUtil.java
 * @version 1.0
 * @since 2021. 5. 17.
 * @author srec0012
 */

@Slf4j
public class CodecUtil {
	
	private CodecUtil() {
		log.debug(CodecUtil.class.getSimpleName());
	}
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 입력된 Key를 지정한 Charset으로 Encoding 한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 17.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param key
	 * @param charset
	 * @return
	 * @throws Exception
	 */
	public static String encoder(String key, String charset) throws Exception {
		String result = "";
		
		if ( key != null && !"".equals(key) ) {
			result = new String(Base64.encodeBase64(key.getBytes()), charset);
		}
		
		return result;
	}
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 입력한 Key를 UTF-8로 Encoding 한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 17.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static String encoderUTF8(String key) throws Exception {
		return encoder(key, "UTF-8");
	}
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 입력한 cipher 값을 지정한 Charset으로 Decoding 한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 17.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param cipher
	 * @param charset
	 * @return
	 * @throws Exception
	 */
	public static String decoder(String cipher, String charset) throws Exception {
		String result = "";
		
		if ( cipher != null && !"".equals(cipher) ) {
			result = new String(Base64.decodeBase64(cipher.getBytes()), charset);
		}
		
		return result;
	}
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 입력한 cipher 값을 UTF-8로 Decoding 한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 17.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param cipher
	 * @return
	 * @throws Exception
	 */
	public static String decoderUTF8(String cipher) throws Exception {
		return decoder(cipher, "UTF-8");
	}
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 입력한 Object의 모든 Filed를 UTF-8로 Encoding 한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 17.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public static Object encoderAll(Object obj) throws Exception {
		Class<? extends Object> cls = obj.getClass();
		
		Field[] fieldList = cls.getDeclaredFields();
		
		for ( Field field : fieldList ) {
			if ( field.get(obj) != null && !"".equals(field.get(obj)) ) {
				String fieldName = field.getName();
				String fieldValue = (String)field.get(obj);
				String newFieldValue = encoderUTF8(fieldValue);
				log.debug("fieldName = " + fieldName + ", Type=" + field.getType() + ", fieldValue=" + fieldValue 
						+ ", afterValue=" + newFieldValue);
				
				if ( field.getType() == String.class ) {
					field.set(obj,  newFieldValue);
				} else if ( field.getType() == Integer.class ) {
					field.set(obj, Integer.parseInt(newFieldValue));
				} else if ( field.getType() == Double.class ) {
					field.set(obj, Double.parseDouble(newFieldValue));
				} else if ( field.getType() == Long.class ) {
					field.set(obj, Long.parseLong(newFieldValue));
				} else if ( field.getType() == Byte.class ) {
					field.set(obj, Byte.parseByte(newFieldValue));
				} else if ( field.getType() == Float.class ) {
					field.set(obj, Float.parseFloat(newFieldValue));
				} else if ( field.getType() == Short.class ) {
					field.set(obj, Short.parseShort(newFieldValue));
				}
			}
		}
		
		return obj;
	}
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 입력한 Object의 모든 Field를 UTF-8로 Decoding 한다.
	 * </pre>
	 * @date 2021. 5. 17.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 17.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param obj
	 * @return
	 * @throws Exception
	 */
	public static Object decoderAll(Object obj) throws Exception {
		Class<? extends Object> cls = obj.getClass();
		
		Field[] fieldList = cls.getDeclaredFields();
		
		for ( Field field : fieldList ) {
			if ( field.get(obj) != null && !"".equals(field.get(obj)) ) {
				String fieldName = field.getName();
				String fieldValue = (String)field.get(obj);
				String newFieldValue = decoderUTF8(fieldValue);
				log.debug("fieldName = " + fieldName + ", Type=" + field.getType() + ", fieldValue=" + fieldValue 
						+ ", afterValue=" + newFieldValue);
				
				if ( field.getType() == String.class ) {
					field.set(obj,  newFieldValue);
				} else if ( field.getType() == Integer.class ) {
					field.set(obj, Integer.parseInt(newFieldValue));
				} else if ( field.getType() == Double.class ) {
					field.set(obj, Double.parseDouble(newFieldValue));
				} else if ( field.getType() == Long.class ) {
					field.set(obj, Long.parseLong(newFieldValue));
				} else if ( field.getType() == Byte.class ) {
					field.set(obj, Byte.parseByte(newFieldValue));
				} else if ( field.getType() == Float.class ) {
					field.set(obj, Float.parseFloat(newFieldValue));
				} else if ( field.getType() == Short.class ) {
					field.set(obj, Short.parseShort(newFieldValue));
				}
			}
		}
		
		return obj;
	}
}
