package com.sorincorp.comm.order.service;

import java.util.Map;

/**
 * CommFrontOrderWebsocketService.java
 * FO 웹소켓 Service 인터페이스
 * 
 * @version
 * @since 2024. 11. 6.
 * @author srec0051
 */
public interface CommFrontOrderWebsocketService {

    /**
     *
     * <pre>
     * 라이브 주문정보 websocket publish
     * </pre>
     * @date 2023. 5. 17.
     * @author srec0051
     * @param param
     * @param isApiCall 외부호출여부
     */
    public void publishLiveOrder(Map<String, Object> param, boolean isApiCall);

    /**
     * <pre>
     * 지정가 주문정보 websocket publish
     * </pre>
     * @date 2023. 5. 17.
     * @author srec0051
     * @param param
     * @param isApiCall 외부호출여부
     */
    public void publishLimitOrder(Map<String, Object> param, boolean isApiCall);
    
    /**
     * <pre>
     * 처리내용: 가단가 확정하기 정보 websocket publish, 가단가 자동 확정하기
     * </pre>
     * @date 2024. 9. 30.
     * @author srec0049
     * @history 
     * ------------------------------------------------
     * 변경일                 작성자          변경내용
     * ------------------------------------------------
     * 2024. 9. 30.          srec0049         최초작성
     * ------------------------------------------------
     * @param param
     * @param isApiCall 외부호출여부
     */
    public void publishPrvsnlDcsn(Map<String, Object> param);
    
    /**
     * <pre>
     * 처리내용: 가단가 확정하기 정보 websocket publish, FO에 해당 확정 여부 전파 전달 (SimpMessagingTemplate) [확정, 체결, 수정, 취소] 모두 대상
     * </pre>
     * @date 2024. 11. 13.
     * @author srec0049
     * @history 
     * ------------------------------------------------
     * 변경일                 작성자          변경내용
     * ------------------------------------------------
     * 2024. 11. 13.          srec0049         최초작성
     * ------------------------------------------------
     * @param param
     */
    public void publishPrvsnlDcsnSimpMsg(Map<String, Object> param);
}
