package com.sorincorp.comm.order.service;

import com.sorincorp.comm.order.model.CommAvrgPcInvntryVO;

/**
 * CommAvrgPcInvntryService.java
 * 평균가 재고 공통 Service 인터페이스
 * 
 * @version
 * @since 2023. 11. 21.
 * @author srec0049
 */
public interface CommAvrgPcInvntryService {
	
	/**
	 * <pre>
	 * 처리내용: 계약_계약 월 할당 재고 상세 이력 등록, 할당 해제 시 할당 중량, 할당 재고, 할당 번들 재고를 0으로 등록한다.
	 * </pre>
	 * @date 2023. 12. 7.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 12. 7.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commAvrgPcInvntryVO
	 * @return
	 * @throws Exception
	 */
	public int insertCnCntrctMtAsgnInvntryDtlHst(CommAvrgPcInvntryVO commAvrgPcInvntryVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 평균가 할당/발주/결제 재고 차감 증가 
	 *     평균가구분(avrgSe) : ASGN(할당), ORDER(발주), SETLE(결제)
	 *     처리구분(processSe) : DDCT(차감), INCRS(증가)
	 * </pre>
	 * @date 2023. 11. 21.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 11. 21.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commAvrgPcInvntryVO
	 * @return
	 * @throws Exception
	 */
	public boolean insertAndUpdateAvrgPcInvntryDdctIncrs(CommAvrgPcInvntryVO commAvrgPcInvntryVO) throws Exception;
	
}
