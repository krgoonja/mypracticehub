package com.sorincorp.comm.bsnInfo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class RltmEndTimeVO implements Serializable{

    /**
	 *
	 */
	private static final long serialVersionUID = -1155525891465672106L;

	private String rltmEndTimeValue;

	private String rltmBeginTimeValue;

	private String rltmEndTimeValue2;

    private String viewRltmEndTimeValue;

    private String viewRltmEndTime;

    private String rltmMidTime;

    private String rltmMidTimeValue;

    private int rltmMidTimeValue2;

    private String viewRltmMidTimeValue;

    private String viewRltmMidTime;

    private String subCode;

    private String rltmEndTime;

    private String rltmBeginTime;

    private String limitOrderValidDeValue;

}
