package com.sorincorp.comm.invntry.service;

import java.util.Map;

import com.sorincorp.comm.invntry.model.InvntrySttusVO;

/**
 * InvntrySttusService.java
 * 재고 현황 공통 Service 인터페이스
 * @version
 * @since 2023. 6. 27.
 * @author srec0066
 */
public interface InvntrySttusService {

	/**
	 * <pre>
	 * 처리내용: Redis에 재고 데이터 변경 메세지 발행하기
	 * </pre>
	 * @date 2023. 7. 7.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 7.			srec0066			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	public void invntrySttusMsgPublish() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 판매 중인 실시간 재고 데이터 조회
	 * 		  - 메탈코드/권역 대분류 코드/브랜드 그룹 코드/브랜드 코드를 KEY값으로 사용하여 구분
	 * </pre>
	 * @date 2023. 7. 7.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 7.			srec0066			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public Map<String, InvntrySttusVO> getInvntrySttusInfoMap(String metalCode) throws Exception;
	public Map<String, InvntrySttusVO> getInvntrySttusInfoMap(InvntrySttusVO param) throws Exception;

}
