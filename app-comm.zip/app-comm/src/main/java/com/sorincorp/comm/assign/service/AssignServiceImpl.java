package com.sorincorp.comm.assign.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.assign.mapper.AssignMapper;
import com.sorincorp.comm.assign.model.AssignVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AssignServiceImpl implements AssignService {
	
	@Autowired
	private AssignMapper assignMapper;
	
	public String selectAssignValue(String jobSe, String assgnNm, String assgnSe, String userId, int length) throws Exception {
		log.debug("채번 시작");

		AssignVO assVo = new AssignVO();
		assVo.setJobSe(jobSe.toUpperCase());
		assVo.setColumnNm(assgnNm.toUpperCase());
		assVo.setAssgnSe(assgnSe.toUpperCase());
		assVo.setUserId(userId);
		
		long assignNo = assignMapper.selectAssignNo(assVo);

		String format = "%0" + String.valueOf(length) + "d";
		String assignValue = String.format(format, assignNo);
		
		log.debug("채번 Value : " + assignValue);
		
		return assignValue;
	}
}