package com.sorincorp.comm.order.mapper;

import java.util.List;

import com.sorincorp.comm.order.model.CnCntrctOrderBasVO;
import com.sorincorp.comm.order.model.CommExcclcInfoVO;
import com.sorincorp.comm.order.model.OrOrderAvrgpcDtlVO;

import io.lettuce.core.dynamic.annotation.Param;

/**
 * CommAvrgpcOrderMapper.java
 * 평균가 주문 공통 Mapper 인터페이스
 * @version
 * @since 2023. 8. 28.
 * @author srec0066
 */
public interface CommAvrgpcOrderMapper {

	/**
	 * <pre>
	 * 처리내용: 계약_계약 발주 기본 조회
	 * </pre>
	 * @date 2023. 10. 27.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 27.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param cntrctOrderNo
	 * @return
	 * @throws Exception
	 */
	public CnCntrctOrderBasVO selectCnCntrctOrderBas(@Param("cntrctOrderNo") String cntrctOrderNo, @Param("orderNo") String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 누적 평균 가격 목록 조회
	 * </pre>
	 * @date 2023. 10. 27.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 27.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param cnCntrctOrderBasVO
	 * @return
	 * @throws Exception
	 */
	public List<OrOrderAvrgpcDtlVO> selectAccmltAvrgpcList(CnCntrctOrderBasVO cnCntrctOrderBasVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 평균 LME, 환율 데이터 조회
	 * </pre>
	 * @date 2023. 11. 14.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param cnCntrctOrderBasVO
	 * @return
	 * @throws Exception
	 */
	public OrOrderAvrgpcDtlVO selectPrevBsnDeAvrgpc(CnCntrctOrderBasVO cnCntrctOrderBasVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_주문 평균가 상세 등록
	 * </pre>
	 * @date 2023. 11. 14.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orOrderAvrgpcDtlVO
	 * @return
	 * @throws Exception
	 */
	public int insertOrOrderAvrgpcDtl(OrOrderAvrgpcDtlVO orOrderAvrgpcDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 정산 관련 데이터 조회
	 * </pre>
	 * @date 2023. 11. 29.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 29.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	public CommExcclcInfoVO selectOrderExcclcInfo(String orderNo);
}
