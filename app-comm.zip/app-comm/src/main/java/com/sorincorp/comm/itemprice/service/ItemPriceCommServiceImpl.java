package com.sorincorp.comm.itemprice.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.itemprice.mapper.ItemPriceCommMapper;
import com.sorincorp.comm.itemprice.model.ItemPriceCommVO;

@Service
public class ItemPriceCommServiceImpl implements ItemPriceCommService {

	@Autowired
	private ItemPriceCommMapper itemPriceMapper;
	
	@Override
	public void deleteOrderBasketForModifySellMetal(List<String> removeMetalCodes, String entrpsNo) throws Exception {
		ItemPriceCommVO vo = new ItemPriceCommVO();
		vo.setRemoveMetalCodes(removeMetalCodes);
		vo.setEntrpsNo(entrpsNo);
		
		itemPriceMapper.deleteOrderBasketForModifySellMetal(vo);
	}
	
	@Override
	public void deleteHopeAlramForModifySellMetal(List<String> removeMetalCodes, String entrpsNo) throws Exception {
		ItemPriceCommVO vo = new ItemPriceCommVO();
		vo.setRemoveMetalCodes(removeMetalCodes);
		vo.setEntrpsNo(entrpsNo);
		
		itemPriceMapper.deleteHopeAlramForModifySellMetal(vo);
	}
	

	@Override
	public void deleteInventoryAlramForModifySellMetal(List<String> removeMetalCodes, String entrpsNo) throws Exception {
		ItemPriceCommVO vo = new ItemPriceCommVO();
		vo.setRemoveMetalCodes(removeMetalCodes);
		vo.setEntrpsNo(entrpsNo);
		
		itemPriceMapper.deleteInventoryAlramForModifySellMetal(vo);
	}
	
	
}
