package com.sorincorp.comm.brandgroupcode.service;

import java.util.List;

import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;

public interface BrandGroupCodeService {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @throws Exception
	 */
	public void initBrandGroupCode() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	public List<BrandGroupCodeVO> getBrandGroupCodeList(String metalCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param brandGroupCodeList
	 * @return
	 * @throws Exception
	 */
	public String getBrandGroupCodeListStr(List<BrandGroupCodeVO> brandGroupCodeList, String val) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2023. 1. 20.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 1. 20.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param metalCode, sleMthdCode 판매방식코드(01:LIVE, 02:고정가, 03:GTC 지정가)
	 * @return
	 * @throws Exception
	 */
	public List<BrandGroupCodeVO> getBrandGroupSleMthdCodeList(String metalCode, String sleMthdCode) throws Exception;
}
