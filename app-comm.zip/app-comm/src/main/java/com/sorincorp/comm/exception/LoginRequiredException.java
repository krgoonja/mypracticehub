package com.sorincorp.comm.exception;

/**
 * 로그인 필요한 화면에 로그인이 안된 경우에 발생하는 사용자 정의 Exception
 * LoginRequiredException.java
 * @version
 * @since 2021. 6. 4.
 * @author srec0012
 */
public class LoginRequiredException extends RuntimeException {
	private static final long serialVersionUID = -4864171366510909367L;
	private String returnUrl;
	
	public LoginRequiredException(String returnUrl) {
		this.returnUrl = returnUrl;
	}
	
	public String getReturnUrl() {
		return returnUrl;
	}
}
