package com.sorincorp.comm.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class CommonVO implements Serializable {

	/**
	 *  serialVersion UID
	 */
	private static final long serialVersionUID = -858838578081269359L;

	/** 검색조건 */
	private String searchCondition = "";

	/** 검색Keyword */
	private String searchKeyword = "";

	/** 검색사용여부 */
	private String searchUseYn = "";

	
	
	/********* start paging *********/
	
	/** 현재페이지 */
	private int pageIndex = 1;
	
	/** 보여줄 최대 페이지 건 수 */
	private int pageSize = 10;

	/** 화면에 보여줄 레코드 건 수 */
	private int rowCountPerPage = 10;
	
	/** 전체 게시물 건 수 */
	private int totalRowCount = 0;

	/********* end paging *********/
	
	

	/********* start realgrid paging *********/
	
	/** firstIndex */
	private int firstIndex = 1;

	/** lastIndex */
	private int lastIndex = 1;

	/** recordCountPerPage */
	private int recordCountPerPage = 10;
	
	/********* end realgrid paging *********/
	
	
	
	/** validation 유무 */
	private boolean validation = false;
	
	/** Qbic Db Link */
	private String dblinkQbicName;
	
	/** Qbic Sts Link */
	private String dblinkStsName;

}
