package com.sorincorp.comm.expectbeginpr.mapper;

import java.util.List;

import com.sorincorp.comm.expectbeginpr.model.DcsnBeginPcVO;
import com.sorincorp.comm.expectbeginpr.model.ItBsnManageBasVO;
import com.sorincorp.comm.expectbeginpr.model.ItFtrsFshgManageDtlVo;
import com.sorincorp.comm.expectbeginpr.model.NdfEhgtPcVO;
import com.sorincorp.comm.expectbeginpr.model.PcSleExpectBeginPcBasVO;
import com.sorincorp.comm.expectbeginpr.model.PcSleExpectBeginPcEhgtInfoVO;
import com.sorincorp.comm.expectbeginpr.model.PcSleExpectBeginPcPremiumPcInfoVO;
import com.sorincorp.comm.expectbeginpr.model.PrLmePblntfPcBasVO;
import com.sorincorp.comm.expectbeginpr.model.PreminumInfoDto;
import com.sorincorp.comm.expectbeginpr.model.PreminumSelVO;
import com.sorincorp.comm.expectbeginpr.model.SelMetalVO;

public interface ExpectBeginPcMapper {

	String selectPreBsnDe();

	ItBsnManageBasVO selectBsnManageBas();

	SelMetalVO selectSelMetal();

	List<PreminumSelVO> getFnPreminumInfoList(DcsnBeginPcVO dcsnBeginPcVO);

	List<PreminumSelVO> getFnPreminumInfoListByMetal(PreminumInfoDto preminumInfoDto);

	PrLmePblntfPcBasVO getPrLmePblntfPc(PrLmePblntfPcBasVO prLmePblntfPcBasVO);

	ItFtrsFshgManageDtlVo selectTopItFtrsFshgManageDtl(ItFtrsFshgManageDtlVo itFtrsFshgManageDtlVo);

	void insertPcSleExpectBeginPcBas(PcSleExpectBeginPcBasVO pcSleExpectBeginPcBasVO);

	void insertPcSleExpectBeginPcBasHst(PcSleExpectBeginPcBasVO pcSleExpectBeginPcBasVO);

	PcSleExpectBeginPcEhgtInfoVO selectPcSleExpectBeginPcEhgtInfo(PcSleExpectBeginPcEhgtInfoVO pcSleExpectBeginPcEhgtInfoVO);

	PcSleExpectBeginPcBasVO selectPcSleExpectBeginPcBas(PcSleExpectBeginPcBasVO pcSleExpectBeginPcBasVO);

	String selectSarokDcsnRecentDate(PcSleExpectBeginPcBasVO pcSleExpectBeginPcBasVO);

	void insertPcSleExpectBeginPcPremiumPcInfo(PcSleExpectBeginPcPremiumPcInfoVO pcSleExpectBeginPcPremiumPcInfoVO);

	void insertPcSleExpectBeginPcPremiumPcInfoHst(PcSleExpectBeginPcPremiumPcInfoVO pcSleExpectBeginPcPremiumPcInfoVO);

	DcsnBeginPcVO selectDcsnBeginPc(DcsnBeginPcVO dcsnBeginPcVO);
	
	DcsnBeginPcVO selectLastThreemonthLmePc(DcsnBeginPcVO dcsnBeginPcVO);
	
	NdfEhgtPcVO selectNdfEhgtPc(NdfEhgtPcVO NdfEhgtPcVO);
	
	String selectPreSarokDate(String nowDate);

	int cnfirmExpectBiginPc(PcSleExpectBeginPcBasVO pcSleExpectBeginPcBasVO);

	int cnfirmSelPc(PcSleExpectBeginPcBasVO pcSleExpectBeginPcBasVO);
}
