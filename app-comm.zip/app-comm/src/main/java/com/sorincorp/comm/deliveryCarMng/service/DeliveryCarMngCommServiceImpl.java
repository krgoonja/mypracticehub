package com.sorincorp.comm.deliveryCarMng.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.deliveryCarMng.mapper.DeliveryCarMngCommMapper;
import com.sorincorp.comm.deliveryCarMng.model.DeliveryCarMngCommVO;
import com.sorincorp.comm.util.CryptoUtil;

@Service
public class DeliveryCarMngCommServiceImpl implements DeliveryCarMngCommService {

	@Autowired
	private DeliveryCarMngCommMapper deliveryCarMngCommMapper;

	/**
	 * <pre>
	 * 처리내용: 업체의 자량정보 리스트를 조회한다.
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<DeliveryCarMngCommVO> selectMbVhcleInfoBas(String entrpsNo) throws Exception {
		// TODO Auto-generated method stub
		return deliveryCarMngCommMapper.selectMbVhcleInfoBas(entrpsNo);
	}

	/**
	 * <pre>
	 * 처리내용: 업체의 기사정보 리스트를 조회한다.
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<DeliveryCarMngCommVO> selectMbDrvArticlInfoBas(String entrpsNo) throws Exception {
		// TODO Auto-generated method stub
		List<DeliveryCarMngCommVO> list = deliveryCarMngCommMapper.selectMbDrvArticlInfoBas(entrpsNo);
		DeliveryCarMngCommVO vo = null;
		String drverTlphonNoEnc = "";
		String regEx = "(\\d{3})(\\d{3,4})(\\d{4})";

		if (list.size() > 0) {
			for (int i = 0; i < list.size(); i++) {
				vo = list.get(i);

				drverTlphonNoEnc = vo.getDrverTlphonNo();

				if (drverTlphonNoEnc != "" && drverTlphonNoEnc != null) {
					vo.setDrverTlphonNo(CryptoUtil.decryptAES256(drverTlphonNoEnc).replaceAll(regEx, "$1-$2-$3"));
				}

				list.set(i, vo);
			}
		}

		return list;
	}

	/**
	 * <pre>
	 * 처리내용: 업체의 차량정보를 신규등록한다.
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryCarMngCommVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int insertDeliveryCar(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception {
		// TODO Auto-generated method stub
		int result = 0;
		String vhcleNo = deliveryCarMngCommVO.getVhcleNo();
		deliveryCarMngCommVO.setVhcleNo("");
		// 차량정보 총 카운트 조회
//		int cnt = deliveryCarMngCommMapper.selectMbVhcleInfoBasCnt(deliveryCarMngCommVO);
//
//		if (cnt < 5) {
//
//			deliveryCarMngCommVO.setVhcleNo(vhcleNo);
//			// 차량번호 중복 카운트 조회
//			cnt = deliveryCarMngCommMapper.selectMbVhcleInfoBasCnt(deliveryCarMngCommVO);
//
//			if (cnt < 1) {
//				result = deliveryCarMngCommMapper.insertDeliveryCar(deliveryCarMngCommVO);
//			} else {
//				// 차량정보가 중복일 경우 에러리턴
//				result = -98;
//			}
//		} else {
//			// 차량정보가 5개이상일 경우 에러리턴
//			result = -99;
//		}

		deliveryCarMngCommVO.setVhcleNo(vhcleNo);
		// 차량번호 중복 카운트 조회
		int cnt = deliveryCarMngCommMapper.selectMbVhcleInfoBasCnt(deliveryCarMngCommVO);

		if (cnt < 1) {
			result = deliveryCarMngCommMapper.insertDeliveryCar(deliveryCarMngCommVO);
		} else {
			// 차량정보가 중복일 경우 에러리턴
			result = -98;
		}

		if (result > 0) {
			// 차량정보 이력 등록
			deliveryCarMngCommMapper.insertDeliveryCarHst(deliveryCarMngCommVO);
		}

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 업체의 차량정보를 수정한다.
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryCarMngCommVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int updateDeliveryCar(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception {
		// TODO Auto-generated method stub
		int result = 0;
		// 차량번호 중복 카운트 조회
		int cnt = deliveryCarMngCommMapper.selectMbVhcleInfoBasCnt(deliveryCarMngCommVO);

		if (cnt < 1) {
			result = deliveryCarMngCommMapper.updateDeliveryCar(deliveryCarMngCommVO);
		} else {
			// 차량정보가 중복일 경우 에러리턴
			result = -98;
		}

		if (result > 0) {
			deliveryCarMngCommMapper.insertDeliveryCarHst(deliveryCarMngCommVO);
		}

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 업체의 기사정보를 삭제한다.
	 * </pre>
	 *
	 * @date 2023. 7. 18.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 18.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryCarMngCommVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int deleteDeliveryCar(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception {
		// TODO Auto-generated method stub
		int result = deliveryCarMngCommMapper.deleteDeliveryCar(deliveryCarMngCommVO);

		if (result > 0) {
			deliveryCarMngCommMapper.insertDeliveryCarHst(deliveryCarMngCommVO);
		}

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 업체의 기사정보를 등록한다.
	 * </pre>
	 *
	 * @date 2023. 7. 18.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 18.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryCarMngCommVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int insertDeliveryDriver(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception {
		// TODO Auto-generated method stub
		int result = 0;
		String drverTlphonNo = deliveryCarMngCommVO.getDrverTlphonNo().replaceAll("-", "");
		String drverTlphonNoEnc = "";

		if (drverTlphonNo != "" && drverTlphonNo != null) {
			drverTlphonNoEnc = CryptoUtil.encryptAES256(drverTlphonNo);
		}

//		deliveryCarMngCommVO.setDrverTlphonNo("");

		// 기사정보 총 카운트 조회
//		int cnt = deliveryCarMngCommMapper.selectMbDrvArticlInfoBasCnt(deliveryCarMngCommVO);
//
//		if (cnt < 5) {
//			// 전화번호 암호화하여 세팅
//			deliveryCarMngCommVO.setDrverTlphonNo(drverTlphonNoEnc);
//			// 중복 카운트 조회
//			cnt = deliveryCarMngCommMapper.selectMbDrvArticlInfoBasCnt(deliveryCarMngCommVO);
//
//			if (cnt < 1) {
//				result = deliveryCarMngCommMapper.insertDeliveryDriver(deliveryCarMngCommVO);
//
//				if (result > 0) {
//					deliveryCarMngCommMapper.insertDeliveryDriverHst(deliveryCarMngCommVO);
//				}
//			} else {
//				// 기사정보가 중복일 경우 에러리턴
//				result = -98;
//			}
//		} else {
//			// 차량정보 카운트가 5이상일 경우 에러리턴
//			result = -99;
//		}

		// 전화번호 암호화하여 세팅
		deliveryCarMngCommVO.setDrverTlphonNo(drverTlphonNoEnc);
		// 중복 카운트 조회
		int cnt = deliveryCarMngCommMapper.selectMbDrvArticlInfoBasCnt(deliveryCarMngCommVO);

		if (cnt < 1) {
			result = deliveryCarMngCommMapper.insertDeliveryDriver(deliveryCarMngCommVO);

			if (result > 0) {
				deliveryCarMngCommMapper.insertDeliveryDriverHst(deliveryCarMngCommVO);
			}
		} else {
			// 기사정보가 중복일 경우 에러리턴
			result = -98;
		}

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 업체의 기사정보를 수정한다.
	 * </pre>
	 *
	 * @date 2023. 7. 18.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 18.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryCarMngCommVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int updateDeliveryDriver(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception {
		// TODO Auto-generated method stub
		int result = 0;
		String drverTlphonNo = deliveryCarMngCommVO.getDrverTlphonNo().replaceAll("-", "");
		String drverTlphonNoEnc = "";

		if (drverTlphonNo != "" && drverTlphonNo != null) {
			drverTlphonNoEnc = CryptoUtil.encryptAES256(drverTlphonNo);
		}
		// 전화번호 암호화하여 세팅
		deliveryCarMngCommVO.setDrverTlphonNo(drverTlphonNoEnc);

		// 차량번호 중복 카운트 조회
		int cnt = deliveryCarMngCommMapper.selectMbDrvArticlInfoBasCnt(deliveryCarMngCommVO);

		if (cnt < 1) {
			// 기사정보 수정
			result = deliveryCarMngCommMapper.updateDeliveryDriver(deliveryCarMngCommVO);

			if (result > 0) {
				// 기사정보 이력 등록
				deliveryCarMngCommMapper.insertDeliveryDriverHst(deliveryCarMngCommVO);
			}

		} else {
			// 차량정보가 중복일 경우 에러리턴
			result = -98;
		}

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 업체의 기사정보를 삭제한다.
	 * </pre>
	 *
	 * @date 2023. 7. 18.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 18.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryCarMngCommVO
	 * @return
	 * @throws Exception
	 */
	@Override
	public int deleteDeliveryDriver(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception {
		// TODO Auto-generated method stub
		// 기사정보 삭제
		int result = deliveryCarMngCommMapper.deleteDeliveryDriver(deliveryCarMngCommVO);

		if (result > 0) {
			// 기사정보 이력 등록
			deliveryCarMngCommMapper.insertDeliveryDriverHst(deliveryCarMngCommVO);
		}

		return result;
	}

}
