package com.sorincorp.comm.itemcode.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.itemcode.mapper.ItemCodeMapper;
import com.sorincorp.comm.itemcode.model.ItemCodeVO;
import com.sorincorp.comm.util.CacheUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ItemCodeServiceImple implements ItemCodeService {

	@Autowired
	private CacheUtil cacheUtil;

	@Autowired
	private ItemCodeMapper itemCodeMapper;

	@PostConstruct
	public void init() {
		cacheUtil.getCodeCache();
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @throws Exception
	 */
	@Override
	public void initItemCode() throws Exception {
		// TODO Auto-generated method stub
		ItemCodeVO vo = new ItemCodeVO();
		List<ItemCodeVO> itemCodeList = itemCodeMapper.getItemCode(vo);
		cacheUtil.put("itemCodeList", itemCodeList);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@Cacheable(cacheNames = "Preminume_Info", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager = "localCacheManager")
	public List<ItemCodeVO> getItemCodeList(String metalCode) throws Exception {

		List<ItemCodeVO> itemCodeList = (List<ItemCodeVO>) cacheUtil.getValue("itemCodeList");
		List<ItemCodeVO> itemCodeList2 = new ArrayList<ItemCodeVO>();
		if (itemCodeList == null) {
			initItemCode();
			itemCodeList = (List<ItemCodeVO>) cacheUtil.getValue("itemCodeList");

			if (!"".equals(metalCode)) {
				for (ItemCodeVO code : itemCodeList) {

					if (metalCode.equals(code.getMetalCode())) {
						itemCodeList2.add(code);
					}
				}
			} else {
				itemCodeList2 = itemCodeList;
			}
		} else {

			if (!"".equals(metalCode)) {
				for (ItemCodeVO code : itemCodeList) {

					if (metalCode.equals(code.getMetalCode())) {
						itemCodeList2.add(code);
					}
				}
			} else {
				itemCodeList2 = itemCodeList;
			}
		}
		return itemCodeList2;
	}

	/**
	 * <pre>
	 * 처리내용: 업체가 설정한 판매금속으로 메탈코드 리스트를 조회한다
	 * </pre>
	 *
	 * @date 2022. 5. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 5. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	public List<ItemCodeVO> getEntrpsMetalCodeList(String entrpsNo) throws Exception {

		String sleMetalList = "";
		String sleMetal01 = "";
		String sleMetal02 = "";
		String sleMetal03 = "";
		String sleMetal04 = "";
		String sleMetal05 = "";
		String sleMetal06 = "";
		List<String> metalCodeArray = new ArrayList<String>();
		Map<String, Object> param = new HashMap<String, Object>();
		List<ItemCodeVO> metalCodeList = new ArrayList<ItemCodeVO>();

		if (entrpsNo != null && !"".equals(entrpsNo)) {
			sleMetalList = itemCodeMapper.getEntrpsSleMetalList(entrpsNo);
			// log.debug("sleMetalList ==========>" + sleMetalList);

			if (sleMetalList != null && !"".equals(sleMetalList)) {
				if (sleMetalList.length() != 6 && sleMetalList.length() < 6) {
					sleMetalList = StringUtil.padRight(sleMetalList, "0", 6);
				}

				sleMetal01 = sleMetalList.substring(0, 1);
				sleMetal02 = sleMetalList.substring(1, 2);
				sleMetal03 = sleMetalList.substring(2, 3);
				sleMetal04 = sleMetalList.substring(3, 4);
				sleMetal05 = sleMetalList.substring(4, 5);
				sleMetal06 = sleMetalList.substring(5, 6);

				if ("1".equals(sleMetal01)) {
					metalCodeArray.add("7");
				}
				if ("1".equals(sleMetal02)) {
					metalCodeArray.add("1");
				}
				if ("1".equals(sleMetal03)) {
					metalCodeArray.add("5");
				}
				if ("1".equals(sleMetal04)) {
					metalCodeArray.add("2");
				}
				if ("1".equals(sleMetal05)) {
					metalCodeArray.add("8");
				}
				if ("1".equals(sleMetal06)) {
					metalCodeArray.add("9");
				}

				param.put("metalCodeList", metalCodeArray);

				metalCodeList = itemCodeMapper.getEntrpsMetalCodeList(param);
			}
		} else {
			ItemCodeVO itemCodeVO = new ItemCodeVO();

			itemCodeVO.setMetalCode("7");

			metalCodeList.add(itemCodeVO);

		}
		return metalCodeList;
	}

	public List<ItemCodeVO> getMbEntrpsMetalAcctoAuthorSetupBasList(String entrpsNo) throws Exception {

		List<ItemCodeVO> metalCodeList = itemCodeMapper.selectMbEntrpsMetalAcctoAuthorSetupBasList(entrpsNo);

		return metalCodeList;
	}

	/**
	 * <pre>
	 * 업체코드와 메탈코드로 업체에 설정된 판매메탈코드를 조회하여 TRUE/FALSE를 반환한다.
	 * </pre>
	 *
	 * @date 2022. 5. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 5. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param entrpsNo
	 * @param metalCode
	 * @return entrpsAt
	 * @throws Exception
	 */
	public Boolean getEntrpsMetalCodeAt(String entrpsNo, String metalCode) throws Exception {

		Boolean entrpsMetalCodeAt = false;
		String sleMetalList = "";
		String sleMetal01 = "";
		String sleMetal02 = "";
		String sleMetal03 = "";
		String sleMetal04 = "";
		String sleMetal05 = "";
		String sleMetal06 = "";

		int metalCnt = itemCodeMapper.getMetalCount(metalCode);

		if (metalCnt > 0) {

			if (entrpsNo != null && !"".equals(entrpsNo)) {
				sleMetalList = itemCodeMapper.getEntrpsSleMetalList(entrpsNo);
				// log.debug("sleMetalList ==========>" + sleMetalList);

				if (sleMetalList != null && !"".equals(sleMetalList)) {
					if (sleMetalList.length() != 6 && sleMetalList.length() < 6) {
						sleMetalList = StringUtil.padRight(sleMetalList, "0", 6);
					}

					sleMetal01 = sleMetalList.substring(0, 1);
					sleMetal02 = sleMetalList.substring(1, 2);
					sleMetal03 = sleMetalList.substring(2, 3);
					sleMetal04 = sleMetalList.substring(3, 4);
					sleMetal05 = sleMetalList.substring(4, 5);
					sleMetal06 = sleMetalList.substring(5, 6);

					switch (metalCode) {
					case "7":
						// AL 알루미늄
						if ("1".equals(sleMetal01)) {
							entrpsMetalCodeAt = true;
						}
						break;
					case "1":
						// ZN 아연
						if ("1".equals(sleMetal02)) {
							entrpsMetalCodeAt = true;
						}
						break;
					case "5":
						// CU 구리
						if ("1".equals(sleMetal03)) {
							entrpsMetalCodeAt = true;
						}
						break;
					case "2":
						// PB 납
						if ("1".equals(sleMetal04)) {
							entrpsMetalCodeAt = true;
						}
						break;
					case "8":
						// NI 니켈
						if ("1".equals(sleMetal05)) {
							entrpsMetalCodeAt = true;
						}
						break;
					case "9":
						// SN 주석
						if ("1".equals(sleMetal06)) {
							entrpsMetalCodeAt = true;
						}
						break;
					default:
						entrpsMetalCodeAt = false;
						break;
					}
				}
			}
		}

		return entrpsMetalCodeAt;
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param itemCodeList
	 * @return
	 * @throws Exception
	 */
	public String getItemCodeListStr(List<ItemCodeVO> itemCodeList, String val) throws Exception {

		StringBuilder codeTaglibStr = new StringBuilder(StringUtils.EMPTY);

		codeTaglibStr.append("");
		codeTaglibStr.append(CommonConstants.COLONE);
		// codeTaglibStr.append("전체");
		codeTaglibStr.append(val);
		codeTaglibStr.append(CommonConstants.SEMI_COLONE);

		for (ItemCodeVO code : itemCodeList) {

			codeTaglibStr.append(code.getSubCode());
			codeTaglibStr.append(CommonConstants.COLONE);
			codeTaglibStr.append(code.getCodeNm());
			codeTaglibStr.append(CommonConstants.SEMI_COLONE);

		}

		return codeTaglibStr.toString();

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ItemCodeVO> getItemFtrsProcessAtCodeList(String metalCode, String ftrsProcessAt) throws Exception {
		// TODO Auto-generated method stub
		List<ItemCodeVO> itemCodeList = (List<ItemCodeVO>) cacheUtil.getValue("itemCodeList");
		List<ItemCodeVO> itemCodeList2 = new ArrayList<ItemCodeVO>();
		if (itemCodeList == null) {
			initItemCode();
			itemCodeList = (List<ItemCodeVO>) cacheUtil.getValue("itemCodeList");

			if (!"".equals(metalCode)) {
				for (ItemCodeVO code : itemCodeList) {

					if (metalCode.equals(code.getMetalCode())) {

						if (!"".equals(ftrsProcessAt) && ftrsProcessAt.equals(code.getFtrsProcessAt())) {
							itemCodeList2.add(code);
						} else {
							if ("".equals(ftrsProcessAt)) {
								itemCodeList2.add(code);
							}

						}
					}
				}
			} else {
				for (ItemCodeVO code : itemCodeList) {

					if (!"".equals(ftrsProcessAt) && ftrsProcessAt.equals(code.getFtrsProcessAt())) {
						itemCodeList2.add(code);
					} else {
						if ("".equals(ftrsProcessAt)) {
							itemCodeList2.add(code);
						}
					}
				}
				// itemCodeList2 = itemCodeList;
			}
		} else {

			if (!"".equals(metalCode)) {
				for (ItemCodeVO code : itemCodeList) {

					if (metalCode.equals(code.getMetalCode())) {

						if (!"".equals(ftrsProcessAt) && ftrsProcessAt.equals(code.getFtrsProcessAt())) {
							itemCodeList2.add(code);
						} else {
							if ("".equals(ftrsProcessAt)) {
								itemCodeList2.add(code);
							}

						}
					}
				}
			} else {
				for (ItemCodeVO code : itemCodeList) {

					if (!"".equals(ftrsProcessAt) && ftrsProcessAt.equals(code.getFtrsProcessAt())) {
						itemCodeList2.add(code);
					} else {
						if ("".equals(ftrsProcessAt)) {
							itemCodeList2.add(code);
						}
					}
				}
				// itemCodeList2 = itemCodeList;
			}
		}
		return itemCodeList2;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ItemCodeVO> getItemAvrgpcUseAtCodeList(String metalCode, String avrgpcUseAt) throws Exception {
		// TODO Auto-generated method stub
		List<ItemCodeVO> itemCodeList = (List<ItemCodeVO>) cacheUtil.getValue("itemCodeList");
		List<ItemCodeVO> itemCodeList2 = new ArrayList<ItemCodeVO>();
		if (itemCodeList == null) {
			initItemCode();
			itemCodeList = (List<ItemCodeVO>) cacheUtil.getValue("itemCodeList");

			if (!"".equals(metalCode)) {
				for (ItemCodeVO code : itemCodeList) {

					if (metalCode.equals(code.getMetalCode())) {

						if (!"".equals(avrgpcUseAt) && avrgpcUseAt.equals(code.getAvrgpcUseAt())) {
							itemCodeList2.add(code);
						} else {
							if ("".equals(avrgpcUseAt)) {
								itemCodeList2.add(code);
							}
						}
					}
				}
			} else {
				for (ItemCodeVO code : itemCodeList) {

					if (!"".equals(avrgpcUseAt) && avrgpcUseAt.equals(code.getAvrgpcUseAt())) {
						itemCodeList2.add(code);
					} else {
						if ("".equals(avrgpcUseAt)) {
							itemCodeList2.add(code);
						}
					}
				}
				// itemCodeList2 = itemCodeList;
			}
		} else {

			if (!"".equals(metalCode)) {
				for (ItemCodeVO code : itemCodeList) {

					if (metalCode.equals(code.getMetalCode())) {

						if (!"".equals(avrgpcUseAt) && avrgpcUseAt.equals(code.getAvrgpcUseAt())) {
							itemCodeList2.add(code);
						} else {
							if ("".equals(avrgpcUseAt)) {
								itemCodeList2.add(code);
							}

						}
					}
				}
			} else {
				for (ItemCodeVO code : itemCodeList) {

					if (!"".equals(avrgpcUseAt) && avrgpcUseAt.equals(code.getAvrgpcUseAt())) {
						itemCodeList2.add(code);
					} else {
						if ("".equals(avrgpcUseAt)) {
							itemCodeList2.add(code);
						}
					}
				}
				// itemCodeList2 = itemCodeList;
			}
		}
		return itemCodeList2;
	}

}
