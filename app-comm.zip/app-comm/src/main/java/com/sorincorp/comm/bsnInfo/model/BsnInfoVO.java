package com.sorincorp.comm.bsnInfo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class BsnInfoVO implements Serializable{
    
	private static final long serialVersionUID = 2849004139164064398L;

	/**
	 * 적용 일자 
	 */
	private String applcDe;
	/**
	 * 회사 코드
	 */
	private String cmpnyCode;
	/**
	 * LME 달력 유형 코드
	 */
	private String day;
	/**
	 * LME 휴무 유무
	 */
	private String lmeHolidayAt;
	/**
	 * 휴무 여부
	 */
	private String holidayAt;
	/**
	 * 휴무 시작 시간
	 */
	private String holidayBeginTime;
	/**
	 * 휴무 종료 시간
	 */
	private String holidayEndTime;
	/**
	 * 실시간 영업 여부
	 */
	private String rltmBsnAt;
	/**
	 * 고정가 영업 여부
	 */
	private String hghnetprcBsnAt;
	/**
	 * 실시간 시작 시간
	 */
	private String rltmBeginTime;
	/**
	 * 실시간 종료 시간
	 */
	private String rltmEndTime;
	/**
	 * 고정가 시작 시간
	 */
	private String hghnetprcBeginTime;
	/**
	 * 고정가 종료 시간
	 */
	private String hghnetprcEndTime;
    private String siteSatBsnAt;
    /**
     * 물류 일요일 영업 여부
    */
    private String lgistSunBsnAt;
    /**
     * 물류 월요일 영업 여부
    */
    private String lgistMonBsnAt;
    /**
     * 물류 화요일 영업 여부
    */
    private String lgistTuesBsnAt;
    /**
     * 물류 수요일 영업 여부
    */
    private String lgistWedBsnAt;
    /**
     * 물류 목요일 영업 여부
    */
    private String lgistThurBsnAt;
    /**
     * 물류 금요일 영업 여부
    */
    private String lgistFriBsnAt;
    /**
     * 물류 토요일 영업 여부
    */
    private String lgistSatBsnAt;
    /**
     * 선물 수수료 비용 비율
    */
    private java.math.BigDecimal ftrsFeeCtRate;
    /**
     * 이월렛 입금 수수료
    */
    private long ewalletRcpmnyFee;
    /**
     * 이월렛 출금 수수료
    */
    private long ewalletDefrayFee;
    /**
     * LME 조정 계수 금액
    */
//    private java.math.BigDecimal lmeMdatCffcntAmount;
    /**
     * 환율 조정 계수 금액
    */
//    private java.math.BigDecimal ehgtMdatCffcntAmount;
    /**
     * 적용 시작 시간
    */
    private String applcBeginTime;
    /**
     * 적용 종료 시간
    */
    private String applcEndTime;
    /**
     * 휴무 유형 코드
    */
    private String hvofTyCode;
    
}
