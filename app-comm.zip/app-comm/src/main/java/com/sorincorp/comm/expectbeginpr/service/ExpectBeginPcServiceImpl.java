package com.sorincorp.comm.expectbeginpr.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Optional;

import com.sorincorp.comm.bsnInfo.model.RltmEndTimeVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.comm.bsnInfo.model.RestTermVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.expectbeginpr.constants.ExpectBeginPcConstant.EHGT_SE_CODE;
import com.sorincorp.comm.expectbeginpr.constants.ExpectBeginPcConstant.PC_SE_CODE;
import com.sorincorp.comm.expectbeginpr.constants.ExpectBeginPcConstant.SITE_SE_CODE;
import com.sorincorp.comm.expectbeginpr.mapper.ExpectBeginPcMapper;
import com.sorincorp.comm.expectbeginpr.model.DcsnBeginPcVO;
import com.sorincorp.comm.expectbeginpr.model.ItBsnManageBasVO;
import com.sorincorp.comm.expectbeginpr.model.ItFtrsFshgManageDtlVo;
import com.sorincorp.comm.expectbeginpr.model.NdfEhgtPcVO;
import com.sorincorp.comm.expectbeginpr.model.PcSleExpectBeginPcBasVO;
import com.sorincorp.comm.expectbeginpr.model.PcSleExpectBeginPcEhgtInfoVO;
import com.sorincorp.comm.expectbeginpr.model.PcSleExpectBeginPcPremiumPcInfoVO;
import com.sorincorp.comm.expectbeginpr.model.PrLmePblntfPcBasVO;
import com.sorincorp.comm.expectbeginpr.model.PreminumInfoDto;
import com.sorincorp.comm.expectbeginpr.model.PreminumSelVO;
import com.sorincorp.comm.expectbeginpr.model.SelMetalVO;
import com.sorincorp.comm.pcInfo.model.RvcmpnVO;
import com.sorincorp.comm.pcInfo.service.PcInfoService;
import com.sorincorp.comm.util.CommonUtil;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ExpectBeginPcServiceImpl implements ExpectBeginPcService {

	@Autowired
	private PcInfoService pcInfoService;

	@Autowired
	private BsnInfoService bsnInfoService;

	@Autowired
	ExpectBeginPcMapper expectBeginPcMapper;
	
	@Autowired
	private CommonUtil commonUtil;

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void calculateExpectBeginPc() throws Exception {
		log.info("calculateExpectBeginPc start");
		
		List<RestTermVO> restDeLiveList = bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");
		//휴일 체크 휴일이면 종료
		Optional<RestTermVO> restDeLiveOp = restDeLiveList
													.stream()
													.filter(restDeLive -> "7".equals(restDeLive.getMetalCode()))
													.findFirst();
		if (restDeLiveOp.isPresent()) {
			if ("Y".equals(restDeLiveOp.get().getBaseRestdeAt())) {
	            log.info("calculateExpectBeginPc exit. 휴일");
				return;
			}
		}
		//운영시간 조회
		RltmEndTimeVO rltmEndTimeVO = bsnInfoService.getRltmEndTime();
		String rltmBeginTime = rltmEndTimeVO.getRltmBeginTimeValue();

		PcSleExpectBeginPcBasVO sorinExpectPcVo = new PcSleExpectBeginPcBasVO();

		String frstRegisterId = "EXPECT_BEGIN_PC_BATCH";
		String lastChangerId = "EXPECT_BEGIN_PC_BATCH";

		//기준 아이템 조회
		SelMetalVO selMetalVO = expectBeginPcMapper.selectSelMetal();
		//기준 아이템으로 전일 LME 평가,공시 가격 조회
		PrLmePblntfPcBasVO prLmePblntfPcBasVO = new PrLmePblntfPcBasVO();
		prLmePblntfPcBasVO.setMetalCode(selMetalVO.getMetalCode());
		PrLmePblntfPcBasVO lmePrice = expectBeginPcMapper.getPrLmePblntfPc(prLmePblntfPcBasVO);
		//스프레드 조회 (전일자 평가가격의 lme3M - cash)
		BigDecimal spread = lmePrice.getThreemonthEndPc().subtract(lmePrice.getEndPc());

		//확정된 시작가 조회 (최초 등록된 판매가격)
		DcsnBeginPcVO expectBeginPcVoParam = new DcsnBeginPcVO();
		expectBeginPcVoParam.setApplcDe(DateUtil.getNowDate()); // 오늘날짜
		expectBeginPcVoParam.setSleMthdCode(selMetalVO.getSleMthdCode());
		expectBeginPcVoParam.setMetalCode(selMetalVO.getMetalCode());
		expectBeginPcVoParam.setItmSn(Integer.parseInt(selMetalVO.getItmSn()));
		expectBeginPcVoParam.setDstrctLclsfCode(selMetalVO.getDstrctLclsfCode());
		expectBeginPcVoParam.setBrandGroupCode(selMetalVO.getBrandGroupCode());
		expectBeginPcVoParam.setBrandCode(selMetalVO.getBrandCode());
		expectBeginPcVoParam.setValidBeginDt(DateUtil.getNowDate()+rltmBeginTime);
		expectBeginPcVoParam.setValidEndDt(DateUtil.getNowDate()+rltmBeginTime);
		DcsnBeginPcVO expectBeginPcVO = expectBeginPcMapper.selectDcsnBeginPc(expectBeginPcVoParam);
		//NDF 환율 조회 > 디지타이드 연동 개발 필요.
		BigDecimal ehgtPc = new BigDecimal(1282.60);
		//시초가
		long beginWonAmount = 0L;
		//조정 계수 조회
		ItFtrsFshgManageDtlVo itFtrsFshgManageDtlVo = new ItFtrsFshgManageDtlVo();
		itFtrsFshgManageDtlVo.setMetalCode(selMetalVO.getMetalCode());
		ItFtrsFshgManageDtlVo itVo = expectBeginPcMapper.selectTopItFtrsFshgManageDtl(itFtrsFshgManageDtlVo);

		//프리미엄 가격(프리미엄 기준 가격 + 권역 변동금 + 브랜드 그룹 변동금 + 브랜드 변동금)
		long slePremiumAmount = 0L;
		long premiumStdrAmount = 0L;
		BigDecimal lmePc = new BigDecimal(0);
		BigDecimal threemonthLmePc = new BigDecimal(0);

		//판매가격 조회 (있으면 확정가 세팅 없으면 예상가 세팅 )
		if (expectBeginPcVO == null) {
			sorinExpectPcVo.setPcSeCode(PC_SE_CODE.EXPECT_PC.getCode());//예상가
			//STS NDF 환율 세팅
			NdfEhgtPcVO ndfEhgtPcVOParams = new NdfEhgtPcVO();
			ndfEhgtPcVOParams.setDblinkStsName(commonUtil.getDblinkStsName());
			NdfEhgtPcVO ndfEhgtPcVO = expectBeginPcMapper.selectNdfEhgtPc(ndfEhgtPcVOParams);
			if (ndfEhgtPcVO != null) {
				BigDecimal ndfEhgt = ndfEhgtPcVO.getAsk();
				String ndfDate = ndfEhgtPcVO.getDate();
				log.info("ndfEhgt : {} ",ndfEhgt.longValue());
				if (ndfEhgt.longValue() > 0L) {
					ehgtPc = ndfEhgt;
				}

				sorinExpectPcVo.setNdfDate(ndfDate);
			}
			//LME 가격 조회 (전일 실시간 가격)
			DcsnBeginPcVO lastThreemonthLmePcParams = new DcsnBeginPcVO();
			lastThreemonthLmePcParams.setApplcDe(DateUtil.getNowDate());
			lastThreemonthLmePcParams.setMetalCode(selMetalVO.getMetalCode());
			DcsnBeginPcVO lastThreemonthLmePc = expectBeginPcMapper.selectLastThreemonthLmePc(lastThreemonthLmePcParams);
			//3M END 가격
			threemonthLmePc = lastThreemonthLmePc.getThreemonthLmePc();
			lmePc = threemonthLmePc.subtract(spread);
			//조정계수를 더한 판매가
			beginWonAmount = (((lmePc.add(itVo.getLmeMdatCffcntAmount())
			) .multiply(ehgtPc.add(itVo.getEhgtMdatCffcntAmount()))
			).divide(new BigDecimal(1000)).setScale(0, RoundingMode.HALF_UP)).multiply(new BigDecimal(1000)).longValue();
			//시초가 프리미엄 조회
			expectBeginPcVoParam.setValidBeginDt(DateUtil.getNowDateTime("yyyyMMddHHmmss"));
			expectBeginPcVoParam.setValidEndDt(DateUtil.getNowDateTime("yyyyMMddHHmmss"));
			List<PreminumSelVO> stdrPreminumInfoList = expectBeginPcMapper.getFnPreminumInfoList(expectBeginPcVoParam);
			PreminumSelVO stdrPreminumInfo = stdrPreminumInfoList.get(0);
			premiumStdrAmount = stdrPreminumInfo.getPremiumStdrAmount();
			slePremiumAmount = stdrPreminumInfo.getSlePremiumAmount();
			beginWonAmount = beginWonAmount + slePremiumAmount;
		} else {
			sorinExpectPcVo.setPcSeCode(PC_SE_CODE.DCSN_PC.getCode());//확정가
			ehgtPc = expectBeginPcVO.getEhgtPc();
			lmePc = expectBeginPcVO.getLmePc();
			beginWonAmount = expectBeginPcVO.getBeginPc();
			threemonthLmePc = expectBeginPcVO.getThreemonthLmePc();
			slePremiumAmount = expectBeginPcVO.getPremiumPc();
			premiumStdrAmount = expectBeginPcVO.getPremiumStdrAmount();
			//확정가 프리미엄 조회
			/*List<PreminumSelVO> DcsnStdrPreminumInfoList = expectBeginPcMapper.getFnPreminumInfoList(expectBeginPcVoParam);
			PreminumSelVO DcsnStdrPreminum = DcsnStdrPreminumInfoList.get(0);
			//영업시간 기준 프리미엄
			slePremiumAmount = DcsnStdrPreminum.getSlePremiumAmount();
			premiumStdrAmount = DcsnStdrPreminum.getPremiumStdrAmount();*/
		}

		//환율 USD 변환
		BigDecimal mdatCffcntPremiumDallorAmount = lmePc.multiply(itVo.getEhgtMdatCffcntAmount()).divide(ehgtPc,2,BigDecimal.ROUND_HALF_UP);
		long mdatCffcntPremiumAmount = mdatCffcntPremiumDallorAmount.multiply(ehgtPc).longValue();
		//케이지 트레이딩예상 시초가 VO
		sorinExpectPcVo.setApplcDe(DateUtil.getNowDate());
		sorinExpectPcVo.setSiteSeCode(SITE_SE_CODE.SORIN.getCode());//사이트구분코드 케이지트레이딩
		sorinExpectPcVo.setDstrctLclsfCode(selMetalVO.getDstrctLclsfCode());
		sorinExpectPcVo.setBrandGroupCode(selMetalVO.getBrandGroupCode());
		sorinExpectPcVo.setEhgtPc(ehgtPc);
		sorinExpectPcVo.setMetalCode(selMetalVO.getMetalCode());
		//시작 원화 금액
		sorinExpectPcVo.setBeginWonAmount(beginWonAmount);
		//시작 달러 금액
		sorinExpectPcVo.setBeginDollarAmount(new BigDecimal(sorinExpectPcVo.getBeginWonAmount()).divide(ehgtPc,2,BigDecimal.ROUND_HALF_UP));

		sorinExpectPcVo.setSpread(spread);
		sorinExpectPcVo.setLmePc(lmePc);
		sorinExpectPcVo.setThreemonthLmePc(threemonthLmePc);
		//lme 조정계수
		sorinExpectPcVo.setLmeMdatCffcnt(itVo.getLmeMdatCffcntAmount());
		//환율 조정계수
		sorinExpectPcVo.setFxMdatCffcnt(itVo.getEhgtMdatCffcntAmount());
		//프리미엄 원화 금액, 달러 금액
		sorinExpectPcVo.setPremiumWonAmount(slePremiumAmount);
		sorinExpectPcVo.setPremiumDollarAmount(new BigDecimal(sorinExpectPcVo.getPremiumWonAmount()).divide(ehgtPc,2,BigDecimal.ROUND_HALF_UP));
		//프리미엄 기준 금액
		sorinExpectPcVo.setPremiumStdrAmount(premiumStdrAmount);
		//USD변환 원화
		sorinExpectPcVo.setMdatCffcntPremiumWonAmount(mdatCffcntPremiumAmount);
		sorinExpectPcVo.setMdatCffcntPremiumDollarAmount(mdatCffcntPremiumDallorAmount);
		//최종 프리미엄 원화 금액, 달러금액
		sorinExpectPcVo.setLastPremiumDollarAmount(sorinExpectPcVo.getPremiumDollarAmount()
				.add(sorinExpectPcVo.getLmeMdatCffcnt())
				.add(sorinExpectPcVo.getMdatCffcntPremiumDollarAmount()));
        sorinExpectPcVo.setLastPremiumWonAmount(sorinExpectPcVo.getLastPremiumDollarAmount().multiply(ehgtPc).longValue());

		//프리미엄 사용자 입력 원화 금액, 달러 금액
		sorinExpectPcVo.setLastPremiumUserInputDollarAmount(new BigDecimal(0));
		sorinExpectPcVo.setLastPremiumUserInputWonAmount(0);

		sorinExpectPcVo.setFrstRegisterId(frstRegisterId);
		sorinExpectPcVo.setLastChangerId(lastChangerId);

		log.info("calculateExpectBeginPc sorinExpectPcVo : {}", sorinExpectPcVo.toString());

		expectBeginPcMapper.insertPcSleExpectBeginPcBas(sorinExpectPcVo);
		expectBeginPcMapper.insertPcSleExpectBeginPcBasHst(sorinExpectPcVo);

		/*조달청 예상시초가 계산*/
		//매매기준율
		PcSleExpectBeginPcEhgtInfoVO pcSleExpectBeginPcEhgtInfoSeachVO = new PcSleExpectBeginPcEhgtInfoVO();
		pcSleExpectBeginPcEhgtInfoSeachVO.setApplcDe(DateUtil.getNowDate());
		pcSleExpectBeginPcEhgtInfoSeachVO.setEhgtSeCode(EHGT_SE_CODE.TRDE_STDRT.getCode());
		PcSleExpectBeginPcEhgtInfoVO pcSleExpectBeginPcEhgtInfoVO = expectBeginPcMapper.selectPcSleExpectBeginPcEhgtInfo(pcSleExpectBeginPcEhgtInfoSeachVO);

		BigDecimal sarokEhgtPc = new BigDecimal(0);

		if (pcSleExpectBeginPcEhgtInfoVO != null) {
			sarokEhgtPc = pcSleExpectBeginPcEhgtInfoVO.getEhgtPc();
		}

		//조달청 브랜드 그룹 리스트 조회
		List<RvcmpnVO> rvcmpnVOList = pcInfoService.getRvcmpn(DateUtil.getNowDate(), selMetalVO.getMetalCode());
		for (RvcmpnVO rvcmpnVO : rvcmpnVOList) {

			String sarokDstrctLclsfCode = selMetalVO.getDstrctLclsfCode();
			String sarokBrandGroupCode = rvcmpnVO.getBrandGroupCode();

			PcSleExpectBeginPcBasVO sarokPreminumParam = new PcSleExpectBeginPcBasVO();
			sarokPreminumParam.setApplcDe(DateUtil.getNowDate());
			sarokPreminumParam.setSiteSeCode(SITE_SE_CODE.SAROK.getCode());
			sarokPreminumParam.setDstrctLclsfCode(sarokDstrctLclsfCode);
			sarokPreminumParam.setBrandGroupCode(sarokBrandGroupCode);
			sarokPreminumParam.setPcSeCode(PC_SE_CODE.EXPECT_PC.getCode());
			PcSleExpectBeginPcBasVO sarokPreminumVo = expectBeginPcMapper.selectPcSleExpectBeginPcBas(sarokPreminumParam);

			//조달청 예상 시초가 VO
			PcSleExpectBeginPcBasVO sarokExpectPcVo = new PcSleExpectBeginPcBasVO();
			sarokExpectPcVo.setApplcDe(DateUtil.getNowDate());
			sarokExpectPcVo.setSiteSeCode(SITE_SE_CODE.SAROK.getCode());//사이트구분코드 조달청
			sarokExpectPcVo.setDstrctLclsfCode(sarokDstrctLclsfCode);
			sarokExpectPcVo.setBrandGroupCode(sarokBrandGroupCode);
			sarokExpectPcVo.setEhgtPc(sarokEhgtPc);
			sarokExpectPcVo.setMetalCode(selMetalVO.getMetalCode());

			long sarokBeginWonAmount = 0L;

			BigDecimal sarokLastPremiumDollarAmount = new BigDecimal(0);
			long sarokLastPremiumWonAmount = 0L;

			BigDecimal sarokLastPremiumUserInputDollarAmount = new BigDecimal(0);
			long sarokLastPremiumUserInputWonAmount = 0L;

			if (expectBeginPcVO != null) {
				sarokExpectPcVo.setPcSeCode(PC_SE_CODE.DCSN_PC.getCode());//확정가

				BigDecimal sarokPc = rvcmpnVO.getSarokPc();
				BigDecimal sarokPcExVat = sarokPc.divide(new BigDecimal("1.1"),0,RoundingMode.DOWN);
				BigDecimal sarokDollarPc = sarokPcExVat.divide(sarokEhgtPc,2,BigDecimal.ROUND_HALF_UP);
				BigDecimal sarokPremiumDollarPc = sarokDollarPc.subtract(lmePrice.getEndPc());

				sarokBeginWonAmount = sarokPcExVat.longValue();
				sarokLastPremiumDollarAmount = sarokPremiumDollarPc;
				sarokLastPremiumWonAmount = sarokPremiumDollarPc.multiply(sarokEhgtPc).longValue();

				sarokLastPremiumUserInputDollarAmount = sarokLastPremiumDollarAmount;
				sarokLastPremiumUserInputWonAmount = sarokLastPremiumWonAmount;
			} else {
				sarokExpectPcVo.setPcSeCode(PC_SE_CODE.EXPECT_PC.getCode());//예상가

				BigDecimal sarokDollar = lmePrice.getEndPc().add(sarokPreminumVo == null ? new BigDecimal(0) : sarokPreminumVo.getLastPremiumUserInputDollarAmount());
				BigDecimal sarokWon = sarokDollar.multiply(sarokEhgtPc).setScale(0, RoundingMode.HALF_UP);
				BigDecimal vatPercent = new BigDecimal(10);
				BigDecimal sarokWonVat = sarokWon.divide(vatPercent);

				long sarokWon2 = sarokWon.add(sarokWonVat).setScale(-4, RoundingMode.HALF_UP).longValue();
				long sarokWon3 = new BigDecimal(sarokWon2).divide(new BigDecimal("1.1"),0,RoundingMode.DOWN).longValue();

				sarokBeginWonAmount = sarokWon3;
				sarokLastPremiumDollarAmount = sarokPreminumVo == null ? new BigDecimal(0) :sarokPreminumVo.getLastPremiumUserInputDollarAmount();
				sarokLastPremiumWonAmount = sarokLastPremiumDollarAmount.multiply(sarokEhgtPc).longValue();
			}
			//시작 원화 금액
			sarokExpectPcVo.setBeginWonAmount(sarokBeginWonAmount);
			//시작 달러 금액
			sarokExpectPcVo.setBeginDollarAmount(new BigDecimal(sarokExpectPcVo.getBeginWonAmount()).divide(sarokEhgtPc,2,BigDecimal.ROUND_HALF_UP));

			sarokExpectPcVo.setSpread(new BigDecimal(0));
			sarokExpectPcVo.setLmePc(lmePrice.getEndPc());
			sarokExpectPcVo.setThreemonthLmePc(new BigDecimal(0));
			//lme 조정계수 0
			sarokExpectPcVo.setLmeMdatCffcnt(new BigDecimal(0));
			//환율 조정계수 0
			sarokExpectPcVo.setFxMdatCffcnt(new BigDecimal(0));
			//프리미엄 기준 금액
			sarokExpectPcVo.setPremiumStdrAmount(0);
			
			//프리미엄 원화 금액, 달러 금액
			sarokExpectPcVo.setPremiumWonAmount(0);
			sarokExpectPcVo.setPremiumDollarAmount(new BigDecimal(0));
			
			//조정계수 프리미엄 원화 금액, 달러금액
			sarokExpectPcVo.setMdatCffcntPremiumWonAmount(0);
			sarokExpectPcVo.setMdatCffcntPremiumDollarAmount(new BigDecimal(0));

			//최종 프리미엄 원화 금액, 달러금액
			sarokExpectPcVo.setLastPremiumDollarAmount(sarokLastPremiumDollarAmount);
			sarokExpectPcVo.setLastPremiumWonAmount(sarokLastPremiumWonAmount);

			//프리미엄 사용자 입력 원화 금액, 달러 금액
			sarokExpectPcVo.setLastPremiumUserInputDollarAmount(sarokLastPremiumUserInputDollarAmount);
			sarokExpectPcVo.setLastPremiumUserInputWonAmount(sarokLastPremiumUserInputWonAmount);

			sarokExpectPcVo.setFrstRegisterId(frstRegisterId);
			sarokExpectPcVo.setLastChangerId(lastChangerId);

			log.info("calculateExpectBeginPc sarokExpectPcVo : {}", sarokExpectPcVo.toString());

			expectBeginPcMapper.insertPcSleExpectBeginPcBas(sarokExpectPcVo);
			expectBeginPcMapper.insertPcSleExpectBeginPcBasHst(sarokExpectPcVo);
		}

		String pcScCode = "";

		if (expectBeginPcVO == null) {
			pcScCode = "01";
		} else {
			pcScCode = "02";
		}
		this.insertPcSleExpectBeginPcPremiumPcInfo(
				selMetalVO.getSleMthdCode()
				,selMetalVO.getMetalCode(), 
				Integer.parseInt(selMetalVO.getItmSn()),
				DateUtil.getNowDateTime(),
				DateUtil.getNowDateTime()
				,itVo.getLmeMdatCffcntAmount()
				,itVo.getEhgtMdatCffcntAmount()
				,ehgtPc
				,mdatCffcntPremiumAmount
				,mdatCffcntPremiumDallorAmount
				,pcScCode
				,frstRegisterId);

	}

	@Transactional(rollbackFor = Exception.class)
	public void insertPcSleExpectBeginPcPremiumPcInfo(String sleMthdCode,
													  String metalCode,
													  int itmSn,
													  String validBeginDt,
													  String validEndDt,
													  BigDecimal lmeMdatCffcntAmount,
													  BigDecimal ehgtMdatCffcntAmount,
													  BigDecimal ehgtPc,
													  long mdatCffcntPremiumAmount,
													  BigDecimal mdatCffcntPremiumDallorAmount, String pcSeCode,
													  String id) throws Exception {
		//프리미엄 정보 조회(브랜드 무관은 제외, 브랜드 변동금이 0 이상인것만.) > 정보용. 계산은 하지 않음.
		PreminumInfoDto preminumInfoDtoByMetal = new PreminumInfoDto();
		preminumInfoDtoByMetal.setStdDt(DateUtil.getNowDate()); // 오늘날짜
		preminumInfoDtoByMetal.setSleMthdCode(sleMthdCode);
		preminumInfoDtoByMetal.setMetalCode(metalCode);	 // 금속코드
		preminumInfoDtoByMetal.setItmSn(itmSn);
		preminumInfoDtoByMetal.setValidBeginDt(validBeginDt);
		preminumInfoDtoByMetal.setValidEndDt(validEndDt);
		List<PreminumSelVO> stdrPreminumInfoListByMetal = expectBeginPcMapper.getFnPreminumInfoListByMetal(preminumInfoDtoByMetal);

		for (PreminumSelVO preminumSelVO : stdrPreminumInfoListByMetal) {

			PcSleExpectBeginPcPremiumPcInfoVO pcSleExpectBeginPcPremiumPcInfoVO = new PcSleExpectBeginPcPremiumPcInfoVO();
			pcSleExpectBeginPcPremiumPcInfoVO.setApplcDe(DateUtil.getNowDate());
			pcSleExpectBeginPcPremiumPcInfoVO.setPcSeCode(pcSeCode);
			pcSleExpectBeginPcPremiumPcInfoVO.setDstrctLclsfCode(preminumSelVO.getDstrctLclsfCode());
			pcSleExpectBeginPcPremiumPcInfoVO.setBrandGroupCode(preminumSelVO.getBrandGroupCode());
			pcSleExpectBeginPcPremiumPcInfoVO.setBrandCode(preminumSelVO.getBrandCode());
			pcSleExpectBeginPcPremiumPcInfoVO.setMetalCode(preminumSelVO.getMetalCode());
			pcSleExpectBeginPcPremiumPcInfoVO.setItmSn(preminumSelVO.getItmSn());
			pcSleExpectBeginPcPremiumPcInfoVO.setSleMthdCode(preminumSelVO.getSleMthdCode());
			pcSleExpectBeginPcPremiumPcInfoVO.setPremiumId(preminumSelVO.getPremiumId());
			pcSleExpectBeginPcPremiumPcInfoVO.setDstrctChangeAmount(preminumSelVO.getDstrctChangeAmount());
			pcSleExpectBeginPcPremiumPcInfoVO.setBrandGroupChangeAmount(preminumSelVO.getBrandGroupChangeAmount());
			pcSleExpectBeginPcPremiumPcInfoVO.setBrandChangeAmount(preminumSelVO.getBrandChangeAmount());
			pcSleExpectBeginPcPremiumPcInfoVO.setPremiumWonAmount(preminumSelVO.getSlePremiumAmount());
			pcSleExpectBeginPcPremiumPcInfoVO.setPremiumDollarAmount(new BigDecimal(preminumSelVO.getSlePremiumAmount()).divide(ehgtPc,2,BigDecimal.ROUND_HALF_UP));
			pcSleExpectBeginPcPremiumPcInfoVO.setLmeMdatCffcnt(lmeMdatCffcntAmount);
			pcSleExpectBeginPcPremiumPcInfoVO.setFxMdatCffcnt(ehgtMdatCffcntAmount);
			pcSleExpectBeginPcPremiumPcInfoVO.setMdatCffcntPremiumWonAmount(mdatCffcntPremiumAmount);
			pcSleExpectBeginPcPremiumPcInfoVO.setMdatCffcntPremiumDollarAmount(mdatCffcntPremiumDallorAmount);
			pcSleExpectBeginPcPremiumPcInfoVO.setLastPremiumDollarAmount(
					pcSleExpectBeginPcPremiumPcInfoVO.getPremiumDollarAmount()
					.add(pcSleExpectBeginPcPremiumPcInfoVO.getMdatCffcntPremiumDollarAmount())
					.add(lmeMdatCffcntAmount));
			pcSleExpectBeginPcPremiumPcInfoVO.setLastPremiumWonAmount(
					pcSleExpectBeginPcPremiumPcInfoVO.getLastPremiumDollarAmount().multiply(ehgtPc).longValue()
					);
			pcSleExpectBeginPcPremiumPcInfoVO.setPremiumStdrAmount(preminumSelVO.getPremiumStdrAmount());
			pcSleExpectBeginPcPremiumPcInfoVO.setFrstRegisterId(id);
			pcSleExpectBeginPcPremiumPcInfoVO.setLastChangerId(id);

			expectBeginPcMapper.insertPcSleExpectBeginPcPremiumPcInfo(pcSleExpectBeginPcPremiumPcInfoVO);
			expectBeginPcMapper.insertPcSleExpectBeginPcPremiumPcInfoHst(pcSleExpectBeginPcPremiumPcInfoVO);
		}
	}
}