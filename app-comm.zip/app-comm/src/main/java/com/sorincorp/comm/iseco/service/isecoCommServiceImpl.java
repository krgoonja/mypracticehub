package com.sorincorp.comm.iseco.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.iseco.mapper.IsecoCommMapper;
import com.sorincorp.comm.iseco.model.IsecoCommVO;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class isecoCommServiceImpl implements IsecoCommService {

	@Autowired
	private IsecoCommMapper isecoCommMapper;

	@Override
	public List<IsecoCommVO> getIsEcoSearchList(IsecoCommVO param) throws Exception {
		// TODO Auto-generated method stub
		List<IsecoCommVO> isEcoSearchList = new ArrayList<IsecoCommVO>();
		String srhGubunCode = param.getSrhGubunCode();
		String sleMthdCode = param.getSleMthdCode();
		String metalClCode = param.getMetalClCode();
		String itmCode = param.getItmCode();
		String dstrctLclsfCode = param.getDstrctLclsfCode();
		String brandGroupCode = param.getBrandGroupCode();
		String entrpsNo = param.getEntrpsNo();

		if (!"01".equals(srhGubunCode) && !"02".equals(srhGubunCode) && !"03".equals(srhGubunCode) && !"04".equals(srhGubunCode) && !"05".equals(srhGubunCode)) {
			log.error("no match srhGubunCode");
			throw new IllegalArgumentException("no match srhGubunCode");
		}

		switch (srhGubunCode) {
		case "01":
			// 금속분류 조회
			if (StringUtil.isNotEmpty(sleMthdCode)) {
				isEcoSearchList = isecoCommMapper.selectMetalClCodeList(param);
			} else {
				log.error("sleMthdCode isEmpty");
				throw new IllegalArgumentException("selectMetalClCodeList sleMthdCode isEmpty");
			}
			break;
		case "02":
			// 아이템 조회
			if (StringUtil.isNotEmpty(sleMthdCode) && StringUtil.isNotEmpty(metalClCode)) {
				isEcoSearchList = isecoCommMapper.selectItmCodeList(param);
			} else {
				log.error("not enough parameter");
				throw new IllegalArgumentException("selectItmCodeList not enough parameter");
			}
			break;
		case "03":
			// 대분류권역 조회
			if (StringUtil.isNotEmpty(sleMthdCode) && StringUtil.isNotEmpty(metalClCode) && StringUtil.isNotEmpty(itmCode)) {
				isEcoSearchList = isecoCommMapper.selectDstrctLclsfCodeList(param);
			} else {
				log.error("not enough parameter");
				throw new IllegalArgumentException("selectDstrctLclsfCodeList not enough parameter");
			}
			break;
		case "04":
			// 브랜드그룹 조회
			if (StringUtil.isNotEmpty(sleMthdCode) && StringUtil.isNotEmpty(metalClCode) && StringUtil.isNotEmpty(itmCode) && StringUtil.isNotEmpty(dstrctLclsfCode)) {
				isEcoSearchList = isecoCommMapper.selectBrandGroupCodeList(param);
			} else {
				log.error("not enough parameter");
				throw new IllegalArgumentException("selectBrandGroupCodeList not enough parameter");
			}
			break;
		case "05":
			// 브랜드 조회
			if (StringUtil.isNotEmpty(sleMthdCode) && StringUtil.isNotEmpty(metalClCode) && StringUtil.isNotEmpty(itmCode) && StringUtil.isNotEmpty(dstrctLclsfCode)
					&& StringUtil.isNotEmpty(brandGroupCode) && StringUtil.isNotEmpty(entrpsNo)) {
				isEcoSearchList = isecoCommMapper.selectBrandCodeList(param);
			} else {
				log.error("not enough parameter");
				throw new IllegalArgumentException("selectBrandCodeList not enough parameter");
			}
			break;

		default:
			break;
		}

		return isEcoSearchList;
	}

	@Override
	public int getSleInvntryUnsleBundleBnt(IsecoCommVO param) throws Exception {

		String srhGubunCode = param.getSrhGubunCode();
		int itmSn = param.getItmSn();
		String metalCode = param.getMetalCode();
		String sleMthdCode = param.getSleMthdCode();
		String metalClCode = param.getMetalClCode();

		// 판매 재고 미판매 번들 잔량
		int sleInvntryUnsleBundleBnt = 0;

		if (!"01".equals(srhGubunCode) && !"02".equals(srhGubunCode)) {
			log.error("no match srhGubunCode");
			throw new IllegalArgumentException("no match srhGubunCode");
		}

		switch (srhGubunCode) {
		case "01":
			// 아이템순번으로 조회
			if (itmSn > 0) {
				sleInvntryUnsleBundleBnt = isecoCommMapper.selectSleInvntryUnsleBundleBnt(param);
			} else {
				log.error("itmSn isEmpty");
				throw new IllegalArgumentException("getSleInvntryUnsleBundleBnt itmSn isEmpty");
			}
			break;
		case "02":
			// 금속코드, 판매방식코드, 금속분류코드로 조회
			if (StringUtil.isNotEmpty(metalCode) && StringUtil.isNotEmpty(sleMthdCode) && StringUtil.isNotEmpty(metalClCode)) {
				if ("01".equals(sleMthdCode)) {
					// 판매방식 01 라이브가일때 선물처리여부 Y
					param.setFtrsProcessAt("Y");
				} else if ("02".equals(sleMthdCode)) {
					// 판매방식 02 고정가일때 선물처리여부 N
					param.setFtrsProcessAt("N");
				} else {
					log.error("invalid parameter");
					throw new IllegalArgumentException("getSleInvntryUnsleBundleBnt invalid sleMthdCode parameter");
				}
				sleInvntryUnsleBundleBnt = isecoCommMapper.selectSleInvntryUnsleBundleBnt(param);
			} else {
				log.error("not enough parameter");
				throw new IllegalArgumentException("getSleInvntryUnsleBundleBnt not enough parameter");
			}
			break;

		default:
			break;
		}

		return sleInvntryUnsleBundleBnt;
	}

}
