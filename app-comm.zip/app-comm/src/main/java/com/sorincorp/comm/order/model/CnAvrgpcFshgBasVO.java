package com.sorincorp.comm.order.model;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CnAvrgpcFshgBasVO.java
 * 계약_평균가 선물환 기본 VO 객체
 * 
 * @version
 * @since 2023. 11. 23.
 * @author srec0049
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class CnAvrgpcFshgBasVO {
	/**
	 * 평균가 선물환 요청 번호
	 */
	private String avrgpcFshgRequstNo;
	
    /**
     * 계약 번호
     */
	private String cntrctNo;
	
    /**
     * 계약 년월
     */
	private String cntrctYm;
	
    /**
     * 계약 년월 순번
     */
	private int cntrctYmSn;
	
    /**
     * BL 번호
     */
	private String blNo;
	
    /**
     * 체결 요청 상태 여부
     */
	private String cnclsRequstSttusAt;
	
	/**
	 * 금속 코드
	 */
	private String metalCode;
	
	/**
	 * 포지션
	 */
	private String postn;
	
    /**
     * 대상 금액
     */
	private java.math.BigDecimal trgetAmount;
	
    /**
     * 가격 옵션
     */
	private String pcOptn;
	
	/**
	 * 영업 일 (가격옵션에 따른) 목록
	 */
	private List<Map<String, String>> fshgBsnDayList;
	
	/**
     * 총 영업 일수
     */
    private int totBsnDaycnt;
    
    /**
     * 1차 영업 일수
     */
    private int firstBsnDaycnt;
    
    /**
     * 1차 1일 체결 금액
     */
    private java.math.BigDecimal firstOnedeCnclsAmount;
    
    /**
     * 1차 체결 금액
     */
    private java.math.BigDecimal firstCnclsAmount;
    
    /**
     * 1차 시작 일자
     */
    private String firstBeginDe;
    
    /**
     * 1차 종료 일자
     */
    private String firstEndDe;
    
    /**
     * 2차 영업 일수
     */
    private int scndBsnDaycnt;
    
    /**
     * 2차 1일 체결 금액
     */
    private java.math.BigDecimal scndOnedeCnclsAmount;
    
    /**
     * 2차 체결 금액
     */
    private java.math.BigDecimal scndCnclsAmount;
    
    /**
     * 2차 시작 일자
     */
    private String scndBeginDe;
    
    /**
     * 2차 종료 일자
     */
    private String scndEndDe;
    
    /**
     * 총 체결 금액
     */
    private java.math.BigDecimal totCnclsAmount;
	
	/**
	 * 평균 환율
	 */
	private java.math.BigDecimal avrgEhgt;
	
	/**
	 * SWAP POINT
	 */
	private java.math.BigDecimal swapPoint;
	
	/**
	 * 최종 환율
	 */
	private java.math.BigDecimal lastEhgt;
	
	/**
	 * 만기 일자
	 */
	private String exprtnDe;
	
	/**
	 * 삭제 일시
	 */
	private java.sql.Timestamp deleteDt;
	
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	
	/**
	 * 최초 등록 일시
	 */
	private java.sql.Timestamp frstRegistDt;
	
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	
	/**
	 * 최종 변경 일시
	 */
	private java.sql.Timestamp lastChangeDt;
	
	/**
	 * 할당 처리 구분 [DDCT(차감), INCRS(증가)]
	 */
	private String asgnProcessSe;
	
	/**
     * 할당 중량
     */
    private Integer asgnWt;
    
    /**
     * 할당 재고
     */
    private BigDecimal asgnInvntry;
    
    /**
     * 할당 번들 재고
     */
    private Integer asgnBundleInvntry;
    
    /**
     * 선물환 최초 중량
     */
    private Integer fshgDlryOrgWt;
    
    /**
     * 선물환 최초 체결 금액
     */
    private BigDecimal fshgDelngDollarOrgAmount;
    
    /**
     * DML 구분 (delete, update, insert)
     */
    private String dmlSe;
    
}
