package com.sorincorp.comm.order.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;

import lombok.Data;

/**
 * CommLimitOrderRedisMsgVO.java
 * 지정가 주문 Redis 메시지 공통 VO 객체
 * 
 * @version
 * @since 2023. 3. 24.
 * @author srec0049
 */
@Data
public class CommLimitOrderRedisMsgVO implements Comparable<CommLimitOrderRedisMsgVO> {

	/**
	 * 지정가 주문 번호
	 */
	private String limitOrderNo;
	
	/**
	 * 인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제]
	 */
	private String intrfcSttusCode;
	
	/**
	 * 지정가 주문일시
	 */
	private String limitOrderDt;
	
	/**
	 * 업체 번호
	 */
	private String entrpsNo;
	
	/**
	 * 금속 코드
	 */
	private String metalCode;
	
	/**
	 * 아이템 순번
	 */
	private int itmSn;
	
	/**
	 * 권역 대분류 코드
	 */
	private String dstrctLclsfCode;
	
	/**
	 * 브랜드 그룹 코드
	 */
	private String brandGroupCode;
	
	/**
	 * 브랜드 코드
	 */
	private String brandCode;
	
	/**
	 * 지정가 입력 금액
	 */
	private long limitInputAmount;
	
	/**
	 * 고객 주문 중량
	 */
	private int cstmrOrderWt;
	
	/**
	 * 기준 프리미엄 환산 금액
	 */
	private long stdrPremiumCnvrsnAmount;
	
	/**
	 * 지정가 프리미엄 제외 금액
	 */
	private long limitPremiumExclAmount;
	
	/**
	 * 지정가 프리미엄 기준 금액
	 */
	private long limitPremiumStdrAmount;
	
	/**
	 * 지정가 권역 변동 금액
	 */
	private long limitDstrctChangeAmount;
	
	/**
	 * 지정가 브랜드 그룹 변동 금액
	 */
	private long limitBrandGroupChangeAmount;
	
	/**
	 * 지정가 브랜드 변동 금액
	 */
	private long limitBrandChangeAmount;
	
	/**
	 * 유효 시작 일시
	 */
	private String validBeginDt;
	/**
	 * 유효 종료 일시
	*/
	private String validEndDt;
	
	@Override
	public int compareTo(CommLimitOrderRedisMsgVO other) {
		/* 1.  지정가 입력 금액으로 정렬
		 * 2. 지정가 주문 일시로 정렬
		 * 3. 고객 주문 중량으로 정렬
		 * 4. 업체 번호로 정렬
		 * 5. 유효 시작 일시로 정렬
		 * */
		
		Comparator<CommLimitOrderRedisMsgVO> comparator =
				Comparator.nullsFirst(Comparator.comparing(CommLimitOrderRedisMsgVO::getLimitInputAmount).reversed())
				.thenComparing(Comparator.nullsFirst(Comparator.comparing(
						(CommLimitOrderRedisMsgVO c) -> {
							String limitOrderDt = c.getLimitOrderDt();
							String formattedLimitOrderDt = limitOrderDt.replaceAll("(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2})(\\.\\d{1,3})?(S)?", "$1.000");
							return LocalDateTime.parse(formattedLimitOrderDt, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
						}).thenComparing(Comparator.comparing(CommLimitOrderRedisMsgVO::getLimitOrderDt))
					))
				.thenComparing(Comparator.nullsFirst(Comparator.comparing(CommLimitOrderRedisMsgVO::getCstmrOrderWt).reversed()))
				.thenComparing(Comparator.nullsFirst(Comparator.comparing(CommLimitOrderRedisMsgVO::getEntrpsNo)));
				/*.thenComparing(
						Comparator.nullsFirst(
							Comparator.comparing(CommLimitOrderRedisMsgVO::getValidBeginDt,
									Comparator.nullsFirst(Comparator.naturalOrder()) // null 값 처리
				)));*/
		int test = comparator.compare(this, other);
		return test;
	}

}
