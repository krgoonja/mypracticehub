package com.sorincorp.comm.redis.config;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.cache.CacheKeyPrefix;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Configuration
@EnableCaching
public class RedisCacheConfig {
	@Bean(name="cacheManager")
	@Primary
	public RedisCacheManager cacheManager(RedisConnectionFactory connectionFactory) {
		RedisCacheConfiguration configurtion = RedisCacheConfiguration.defaultCacheConfig()
//				.disableCachingNullValues()
				.entryTtl(Duration.ofMinutes(10))
				.computePrefixWith(CacheKeyPrefix.simple())
				.serializeKeysWith(RedisSerializationContext.SerializationPair.fromSerializer(new StringRedisSerializer()))
				.serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new GenericJackson2JsonRedisSerializer()));
		
		Map<String, RedisCacheConfiguration> cacheConfiguration = new HashMap<>();
		//cacheConfiguration.put("common", RedisCacheConfiguration.defaultCacheConfig());
		
		//이두원 추가
		cacheConfiguration.put("common", RedisCacheConfiguration.defaultCacheConfig().entryTtl(Duration.ofMinutes(10)));
		RedisCacheManager redisCacheManager = RedisCacheManager.RedisCacheManagerBuilder.fromConnectionFactory(connectionFactory).cacheDefaults(configurtion).withInitialCacheConfigurations(cacheConfiguration).build();
		
		return redisCacheManager;
	}
	
	/**
	 * <pre>
	 * 처리내용: 메소드명을 Prefix로 넣어 캐쉬키를 생성하는 키생성자 빈 등록 
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0004
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 10.		srec0004		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 */
	@Bean
	public KeyGenerator prefixMethodNameKeyGenerator() {
		return new PrefixMethodNameKeyGenerator();
	}
}

