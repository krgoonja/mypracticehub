package com.sorincorp.comm.entrpsgrade.service;

import java.util.List;

import com.sorincorp.comm.entrpsgrade.model.EntrpsGradeVO;

public interface EntrpsGradeService {

	/**
	 * <pre>
	 * 업체 등급 별 혜택을 리스트로 조회하여 반환한다
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return 메탈별 혜택 리스트
	 * @throws Exception
	 */
	public List<EntrpsGradeVO> getEntrpsGradeBnefInfoList(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 업체 별 평가 등급 정보를 VO로 조회하여 반환한다.
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	public EntrpsGradeVO getEntrpsEvlGradeInfo(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 구매성향등급 전체 정보를 조회하여 리스트로 반환한다.
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0030			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public List<EntrpsGradeVO> getEntrpsPurchsInclnGradeInfoAllList() throws Exception;

	/**
	 * <pre>
	 * 업체 별 구매성향 등급정보를 조회하여 VO로 반환한다.
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	public EntrpsGradeVO getEntrpsPurchsInclnGradeInfo(String entrpsNo) throws Exception;
}
