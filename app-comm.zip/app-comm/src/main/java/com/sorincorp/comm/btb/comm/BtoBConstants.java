package com.sorincorp.comm.btb.comm;

/**
 * <pre>
 * 처리내용: COMM - BTB 패키지의 공통 상수를 관리한다.
 * </pre>
 * BtoBConstants.java
 * @version
 * @since 2021. 6. 10.
 * @author Sim sung bo
 * @history 
 * ------------------------------------------------
 * 변경일					작성자				변경내용
 * ------------------------------------------------
 * 2021. 6. 10.			Sim sung bo			최초작성
 * ------------------------------------------------
 */
public final class BtoBConstants {
	
	public static final String BTOB_CNI_SUCCESS_CODE = "00";
	
	public static final String BTOB_HELPER_SUCCESS_CODE = "20200";
	public static final String BTOB_HELPER_ERROR_CODE = "40400";
	
	public static final String SUCCESS_MSG = "Success";
	public static final String ERROR_MSG = "Error";
	
	public static final String BTB_ENCODING_UTF_8 = "UTF-8";
	
	public static final String REQUEST_TOKEN_ID_KEY = "id";
	public static final String REQUEST_TOKEN_PWD_KEY = "pwd";
	
	public static final String RESPONSE_RESULT_DATA_KEY = "result_data";
	public static final String RESPONSE_TOKEN_JWT_KEY = "jwt";
	
	
	public static final String BTB_RESPONSE_ROOT = "response";
	
	public static final String BTB_EHR_SYSTEM = "EHR";

	public static final String BTB_RESPONSE_API_KEY = "YUPi-Key";
	public static final String BTB_REQUEST_API_KEY = "api_key";
	public static final String BTB_INTERFACE_ID = "interface_id";
	public static final String BTB_EHR_TOKEN_NAME = "X-AUTH-TOKEN";

}
