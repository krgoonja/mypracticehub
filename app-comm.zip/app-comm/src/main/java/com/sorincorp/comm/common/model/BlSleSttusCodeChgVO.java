package com.sorincorp.comm.common.model;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class BlSleSttusCodeChgVO extends CommonCodeVO {
	/**
	 *
	 */
	private static final long serialVersionUID = 3397175217485621184L;

	private String blNo;
	private String blExpiryYn;
	private String decimalYn;
	private int fshgManageNoCnt;
	private String fshgManageNo;
	private String ftrsThsexCntrctNo;
	private String sleSttusCode;
	private String lastChangerId;
	private String entrAt;
	private String sleImprtyResn;
	private String ftrsDelngLotOrgQy;
	private String fshgDlryOrgWt;
	private String fshgDelngDollarOrgAmount;
	private String poBlNo;
	private String ftrsExpiryYn;
	private String fshgExpiryYn;
	/**
	 * EC 할당 잔량 번들 재고
	 */
	private String ecAsgnBntBundleInvntry;
	private String sleInvntryUnsleBundleBnt;
	private String wrhousSleUnsetupBundleInvntry;
	/**
	 * 선물사 구분 코드
	 */
	private String ftrsprofsSeCode;
	
	private String metalCode;
	private String itmSn;
	private String dstrctLclsfCode;
	private String brandGroupCode;
	private String brandCode;
	private int sleUnitWt;
	private int onceSlePossWt;
	
	/* 소량 구매 */
	private int smlqySleInvntryUnsleBundleBnt;
	private String smlqySleFtrsAt;
	private int sleInvntryUnsleBnt;
	private int caculPermWtRate;
	private String ftrsProcessAt;
}
