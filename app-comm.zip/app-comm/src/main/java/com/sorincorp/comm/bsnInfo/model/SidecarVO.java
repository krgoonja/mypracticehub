package com.sorincorp.comm.bsnInfo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class SidecarVO implements Serializable{
    
	private static final long serialVersionUID = 2849004139164064398L;

    /**
     * 발동 여부
    */
    private String motnAt;
    /**
     * 전일 대비 비율
    */
    private java.math.BigDecimal bfrtVersusRate;
    /**
     * 지속 시간
    */
    private String cntncTime;
    /**
     * 가격 표시 불가 시간
    */
    private String pcIndictImprtyTime;
    
}
