package com.sorincorp.comm.message.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class MessageTemplateVO implements Serializable {
	private static final long serialVersionUID = 286186121787158947L;
	/******  JAVA VO CREATE : OP_MSSAGE_TMPLAT_BAS(운영_메시지 템플릿 기본)  ******/
    /**
     * 메시지 템플릿 번호
    */
    private int mssageTmplatNo;
    /**
     * 메시지 발송구분 코드
    */
    private String mssageSndngseCode;
    /**
     * 업무 구분 코드
    */
    private String jobSeCode;
    /**
     * 메시지 발신자 전화번호
    */
    private String mssageSntoTelno;
    /**
     * 메시지 템플릿 제목
    */
    private String mssageTmplatSj;
    /**
     * 템플릿 사용 여부
    */
    private String tmplatUseAt;
    /**
     * 앱푸시 사용 여부
    */
    private String pushUseAt;
    /**
     * 앱푸시 템플릿 내용
    */
    private String pushTmplatCn;
    /**
     * 앱푸시 반환 URL
    */
    private String pushReturnUrl;
    /**
     * 알림톡 사용 여부
    */
    private String alimUseAt;
    /**
     * 알림톡 템플릿 내용
    */
    private String alimTmplatCn;
    /**
     * 알림톡 카카오 템플릿 번호
    */
    private String alimKakaoTmplatNo;
    /**
     * 알림톡 버튼 명
    */
    private String alimButtonNm;
    /**
     * 알림톡 버튼 URL
    */
    private String alimButtonUrl;
    /**
     * SMS 사용 여부
    */
    private String smsUseAt;
    /**
     * SMS 템플릿 내용
    */
    private String smsTmplatCn;
    /**
     * SMS 반환 URL
    */
    private String smsReturnUrl;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private String deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;
	
    /**
     * 발송 그룹 코드 (내부사용자 SMS 발송 추가 여부)
     */
    private String sndngGroupCode;
/**
     * 광고 메세지 여부
     */
    private String advrtsMssageAt;
}
