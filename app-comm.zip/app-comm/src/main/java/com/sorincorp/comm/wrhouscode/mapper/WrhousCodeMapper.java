package com.sorincorp.comm.wrhouscode.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.wrhouscode.model.WrhousCodeVO;

public interface WrhousCodeMapper {

	List<WrhousCodeVO> getWrhousCode() throws Exception;

}
