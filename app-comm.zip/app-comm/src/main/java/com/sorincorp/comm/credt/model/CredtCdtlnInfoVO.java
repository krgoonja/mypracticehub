package com.sorincorp.comm.credt.model;

import lombok.Data;

/**
 * CredtCdtlnInfoVO.java
 * 여신 정보 VO 객체
 * @version
 * @since 2022. 8. 10.
 * @author srec0049
 */
@Data
public class CredtCdtlnInfoVO {
	
	/**
	 * 여신관리 패널티 연체 건수
	 */
	private int cdtlnManagePntArrrgCo;
	
	/**
	 * 여신관리 패널티 사고 건수
	 */
	private int cdtlnManagePntAcdntCo;
	
    /**
     * GTX_API_CDRATE(CD금리 인터페이스 테이블) - INT_RATE_SELL(매도)
     */
    private java.math.BigDecimal intRateSell;
    
    /**
     * CD금리
     */
    private java.math.BigDecimal cdInrst;
    
    /**
     * 케이지트레이딩 가산금리
     */
    private java.math.BigDecimal mrtggGrntySorinsuprrAddiInrst;
    
    /**
     * 연간뱅킹데이
     */
    private int mrtggGrntyFyerBankingDaycnt;
    
    /**
     * 전자상거래보증 증권발급 수수료 보상 비율
     */
    private java.math.BigDecimal mrtgggrntyScritsissuFeeCmpnstnRate;
    
    /**
     * 전자상거래보증 증권발급 수수료 보상 건당 인정 비율
     */
    private java.math.BigDecimal mrtgggrntyScritsissuFeeCmpnstnCsbyRate;
    
    /**
     * CD 금리 사용 여부
     */
    private String cdInrstUseAt;
    
    /**
     * 담보보증 무이자 일수
     */
    private int mrtggGrntyNintrDaycnt;
}
