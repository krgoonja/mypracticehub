package com.sorincorp.comm.order.model;

import java.math.BigDecimal;
import java.util.List;

import lombok.Data;

/**
 * CommLimitOrderQueueMsgVO.java
 * 지정가 주문 큐 메시지 공통 VO 객체
 * 
 * @version
 * @since 2023. 3. 24.
 * @author srec0049
 */
@Data
public class CommLimitOrderQueueMsgVO {
	
	/**
	 * 지정가 주문 요청 일시
	 */
	private String limitOrderRequestDt;
	
	/**
	 * 지정가 주문 요청 건수
	 */
	private int limitOrderRequestCo;
	
	/**
	 * 지정가 주문 기준 판매 가격
	 */
	private long limitOrderStdrSlePc;
	
	/**
	 * 지정가 주문 총 중량
	 */
	private int limitOrderTotWt;
	
	/**
	 * 금속 코드
	 */
	private String metalCode;
	
	/**
	 * 아이템 순번
	 */
	private int itmSn;
	
	/**
	 * 권역 대분류 코드
	 */
	private String dstrctLclsfCode;
	
	/**
	 * 브랜드 그룹 코드
	 */
	private String brandGroupCode;
	
	/**
	 * 브랜드 코드
	 */
	private String brandCode;
	
	/**
	 * 판매 가격 실시간 순번
	 */
	private String slePcRltmSn;
	
	/**
	 * LME 가격 실시간 순번
	 */
	private String lmePcRltmSn;
	
	/**
	 * LME 3M
	 */
	private BigDecimal lme3m;
	
	/**
	 * LME 현금
	 */
	private BigDecimal lmeCash;
	
	/**
	 * LME 조정 계수
	 */
	private BigDecimal lmeMdatCffcnt;
	
	/**
	 * 환율 가격 실시간 순번
	 */
	private String ehgtPcRltmSn;
	
	/**
	 * 현물환
	 */
	private BigDecimal spex;
	
	/**
	 * 현물환 조정 계수
	 */
	private BigDecimal spexMdatCffcnt;
	
	/**
	 * 지정가 주문 번호 LIST
	 */
	private List<String> limitOrderNoList;
}
