package com.sorincorp.comm.mbLog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.mbLog.mapper.MbLogMapper;
import com.sorincorp.comm.mbLog.model.MbLogVO;

@Service
public class MbLogServiceImpl implements MbLogService {

	@Autowired
	private MbLogMapper mbLogMapper;

	@Override
	public int insertMbEntrpsInfoBasHst(String entrpsNo) throws Exception {
		// TODO Auto-generated method stub
		return mbLogMapper.insertMbEntrpsInfoBasHst(entrpsNo);
	}

	@Override
	public int insertMbMberInfoBasHst(MbLogVO vo) throws Exception {
		// TODO Auto-generated method stub
		return mbLogMapper.insertMbMberInfoBasHst(vo);
	}
}
