package com.sorincorp.comm.entrpsdlvrg.service;

import java.util.List;

import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;
import com.sorincorp.comm.entrpsdlvrg.model.EntrpsDlvrgVO;

/**
 * EntrpsDlvrgService.java
 * @version
 * @since 2021. 7. 13.
 * @author srec0009
 */
public interface EntrpsDlvrgService {

	/**
	 * <pre>
	 * 처리내용: 회원 배송지 목록 조회
	 * </pre>
	 * @date 2021. 7. 13.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	public List<EntrpsDlvrgVO> getEntrpsDlvrgList(String entrpsNo)  throws Exception;

	/**
	 * <pre>
	 * 처리내용: 회원 배송지 목록 조회
	 * </pre>
	 * @date 2021. 7. 13.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsDlvrgList
	 * @return
	 * @throws Exception
	 */
	public String getEntrpsDlvrgListStr(List<EntrpsDlvrgVO> entrpsDlvrgList) throws Exception;
}
