package com.sorincorp.comm.redis.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.lettuce.core.pubsub.api.sync.RedisPubSubCommands;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class RedisPubSubService {
	
	private final RedisMessageListenerContainer redisMessageListenerContainer;
	
	private final RedisPublisher redisPublisher;
	
	private final RedisSubscriber redisSubscriber;
	
	private Map<String, ChannelTopic> channels = new HashMap<>();

	public boolean isExistChannel(String channelId) {
		return channels.keySet().contains(channelId);
	}
	
	public void createChannel(String channelId, MessageListener subScriber) {
		ChannelTopic channel = new ChannelTopic(channelId);
		redisMessageListenerContainer.addMessageListener(subScriber, channel);
		channels.put(channelId,channel);
	}
	
	public void publishMessage(String channelId, String name, Object obj) {
		ObjectMapper objMapper = new ObjectMapper();
		if (isExistChannel(channelId)) {
			ChannelTopic channel = channels.get(channelId);
			try {
				redisPublisher.publish(channel, RedisPubSubMessage.builder().channelId(channelId).name(name).message(objMapper.writeValueAsString(obj)).build());
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			createChannel(channelId,redisSubscriber);
			ChannelTopic channel = channels.get(channelId);
			try {
				redisPublisher.publish(channel, RedisPubSubMessage.builder().channelId(channelId).name(name).message(objMapper.writeValueAsString(obj)).build());
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void publishMessage(String channelId, String name, String message) {
		if (isExistChannel(channelId)) {
			ChannelTopic channel = channels.get(channelId);
			redisPublisher.publish(channel, RedisPubSubMessage.builder().channelId(channelId).name(name).message(message).build());
		}
		else {
			createChannel(channelId,redisSubscriber);
			ChannelTopic channel = channels.get(channelId);
			redisPublisher.publish(channel, RedisPubSubMessage.builder().channelId(channelId).name(name).message(message).build());
		}
	}
	
//	@Bean(initMethod="init")
//	public void CreateSorinChannel() {
//		createChannel("ExchangeRate");
////		createChannel("Test02");
//	}
//	public void  deleteChannel(String channelId) {
//		if (isExistChannel(channelId)) {
//			ChannelTopic channel = channels.get(channelId);
////			redisMessageListenerContainer.removeMessageListener(redisSubscriber,channel);
//			channels.remove(channelId);
//		}
//
//	}
	
}
