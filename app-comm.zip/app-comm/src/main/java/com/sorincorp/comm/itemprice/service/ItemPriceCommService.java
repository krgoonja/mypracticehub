package com.sorincorp.comm.itemprice.service;

import java.util.List;

public interface ItemPriceCommService {
	
	/**
	 * <pre>
	 * 처리내용: 기업회원 판매금속 수정할때 사용할 관심품목 삭제
	 * </pre>
	 * @date 2022. 5. 16.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 16.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @param entrpsNo
	 * @throws Exception
	 */
	void deleteOrderBasketForModifySellMetal(List<String> metalCodes, String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 기업회원 판매금속 수정할때 사용할 희망가 알림 삭제
	 * </pre>
	 * @date 2022. 5. 16.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 16.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @param entrpsNo
	 * @throws Exception
	 */
	void deleteHopeAlramForModifySellMetal(List<String> metalCodes, String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 기업회원 판매금속 수정할때 사용할 재고 삭제 추가
	 * </pre>
	 * @date 2022. 5. 16.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 5. 16.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @param entrpsNo
	 * @throws Exception
	 */
	void deleteInventoryAlramForModifySellMetal(List<String> metalCodes, String entrpsNo) throws Exception;
}
