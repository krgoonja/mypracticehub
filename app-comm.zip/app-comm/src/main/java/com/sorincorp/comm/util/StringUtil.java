package com.sorincorp.comm.util;

import java.util.UUID;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * 문자열 처리 유틸리티 클래스
 *
 * StringUtil.java
 *
 * @version
 * @since 2021. 5. 18.
 * @author srec0012
 */

@Slf4j
public class StringUtil {

	private StringUtil() {
		log.debug(StringUtil.class.getSimpleName());
	}

	/**
	 * <pre>
	 * strTarget이 null 이거나 화이트스페이스 일 경우 strDest을 반환한다.
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @param strDest
	 * @return strTarget이 null 이거나 화이트스페이스 일 경우 strDest 문자열로 반환
	 */
	public static String nvl(String strTarget, String strDest) {
		String retValue = null;

		if (strTarget == null || "".equals(strTarget)) {
			retValue = strDest;
		} else {
			retValue = strTarget;
		}

		return retValue;
	}

	/**
	 * <pre>
	 * strTarget이 null 이거나 화이트스페이스 일 경우 화이트스페이스로 반환한다.
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @return strTarget이 null 이거나 화이트스페이스 일 경우 화이트스페이스로 반환
	 */
	public static String nvl(String strTarget) {
		return nvl(strTarget, "");
	}

	/**
	 * <pre>
	 * 대상문자열이 null 인지 여부 확인하기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @return null 여부
	 */
	public static boolean isNull(String strTarget) {
		boolean retValue = false;

		if (strTarget == null)
			retValue = true;
		else
			retValue = false;

		return retValue;
	}

	/**
	 * <pre>
	 * 대상 문자열이 지정한 길이보다 길 경우 지정한 길이만큼 잘라낸 문자열 반환하기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @param nLimit
	 * @param bDot
	 * @return 대상 문자열이 지정한 길이보다 길 경우 지정한 길이만큼 잘라낸 문자열
	 */
	public static String cutText(String strTarget, int nLimit, boolean bDot) {
		if (strTarget == null || strTarget.equals("")) {
			return strTarget;
		}

		String retValue = null;

		int nLen = strTarget.length();
		int nTotal = 0;
		int nHex = 0;

		String strDot = "";

		if (bDot)
			strDot = "...";

		for (int i = 0; i < nLen; i++) {
			nHex = (int) strTarget.charAt(i);
			nTotal += Integer.toHexString(nHex).length() / 2;

			if (nTotal > nLimit) {
				retValue = strTarget.substring(0, i) + strDot;
				break;
			} else if (nTotal == nLimit) {
				if (i == (nLen - 1)) {
					retValue = strTarget.substring(0, i - 1) + strDot;
					break;
				}
				retValue = strTarget.substring(0, i + 1) + strDot;
				break;
			} else {
				retValue = strTarget;
			}
		}

		return retValue;
	}

	/**
	 * <pre>
	 * 대상문자열에 지정한 문자가 위치한 위치 값을 반환하기(대소문자 무시)
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @param strDest
	 * @param nPos
	 * @return 대상문자열에 지정한 문자가 위치한 위치 값을 반환
	 */
	public static int indexOfIgnore(String strTarget, String strDest, int nPos) {
		if (strTarget == null || strTarget.equals(""))
			return -1;

		strTarget = strTarget.toLowerCase();
		strDest = strDest.toLowerCase();

		return strTarget.indexOf(strDest, nPos);
	}

	/**
	 * <pre>
	 * 대상문자열에 지정한 문자가 위치한 위치 값을 반환하기(대소문자 무시)
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @param strDest
	 * @return 대상문자열에 지정한 문자가 위치한 위치 값을 반환
	 */
	public static int indexOfIgnore(String strTarget, String strDest) {
		return indexOfIgnore(strTarget, strDest, 0);
	}

	/**
	 * <pre>
	 * 대상 문자열 치환하기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @param strOld
	 * @param strNew
	 * @param bIgnoreCase
	 * @param bOnlyFirst
	 * @return 치환한 문자열
	 */
	public static String replace(String strTarget, String strOld, String strNew, boolean bIgnoreCase, boolean bOnlyFirst) {
		if (strTarget == null || strTarget.equals(""))
			return strTarget;

//        StringBuffer objDest = new StringBuffer("");
		StringBuilder objDest = new StringBuilder("");
		int nLen = strOld.length();
		int strTargetLen = strTarget.length();
		int nPos = 0;
		int nPosOld = 0;

		if (bIgnoreCase == true) { // 대소문자 구분하지 않을 경우
			while ((nPos = indexOfIgnore(strTarget, strOld, nPosOld)) >= 0) {
				objDest.append(strTarget.substring(nPosOld, nPos));
				objDest.append(strNew);
				nPosOld = nPos + nLen;
				if (bOnlyFirst == true) // 한번만 치환할시
					break;
			}
		} else { // 대소문자 구분하는 경우
			while ((nPos = strTarget.indexOf(strOld, nPosOld)) >= 0) {
				objDest.append(strTarget.substring(nPosOld, nPos));
				objDest.append(strNew);
				nPosOld = nPos + nLen;
				if (bOnlyFirst == true)
					break;
			}
		}

		if (nPosOld < strTargetLen)
			objDest.append(strTarget.substring(nPosOld, strTargetLen));

		return objDest.toString();
	}

	/**
	 * <pre>
	 * 대상 문자열 치환하기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @param strOld
	 * @param strNew
	 * @return 치환된 문자열
	 */
	public static String replaceAll(String strTarget, String strOld, String strNew) {
		return replace(strTarget, strOld, strNew, false, false);
	}

	/**
	 * <pre>
	 * 각종 구분자 제거하기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @return 구분자가 제거된 문자열
	 */
	public static String removeFormat(String strTarget) {
		if (strTarget == null) {
			return "";
		}
		return strTarget.replaceAll("[$|^|*|+|?|/|:|\\-|,|.|\\s]", "");
	}

	/**
	 * <pre>
	 * 콤마 제거하기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @return 콤마가 제거된 문자열
	 */
	public static String removeComma(String strTarget) {
		if (strTarget == null || strTarget.equals(""))
			return strTarget;

		return strTarget.replaceAll("[,|\\s]", "");
	}

	/**
	 * <pre>
	 * 값 채우기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @param strDest
	 * @param nSize
	 * @param bLeft
	 * @return 지정한 길이만큼 채워진 문자열
	 */
	public static String padValue(String strTarget, String strDest, int nSize, boolean bLeft) {
		if (strTarget == null)
			return strTarget;

		String retValue = null;

//        StringBuffer objSB = new StringBuffer();
		StringBuilder objSB = new StringBuilder();

		int nLen = strTarget.length();
		int nDiffLen = nSize - nLen;
		for (int i = 0; i < nDiffLen; i++) {
			objSB.append(strDest);
		}

		if (bLeft == true) // 채워질 문자열의 방향이 좌측일 경우
			retValue = objSB.toString() + strTarget;
		else // 채워질 문자열의 방향이 우측일 경우
			retValue = strTarget + objSB.toString();

		return retValue;
	}

	/**
	 * <pre>
	 * 좌측으로 값 채우기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @param strDest
	 * @param nSize
	 * @return 채워진 문자열
	 */
	public static String padLeft(String strTarget, String strDest, int nSize) {
		return padValue(strTarget, strDest, nSize, true);
	}

	/**
	 * <pre>
	 * 좌측에 공백 채우기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @param nSize
	 * @return 채워진 문자열
	 */
	public static String padLeft(String strTarget, int nSize) {
		return padValue(strTarget, " ", nSize, true);
	}

	/**
	 * <pre>
	 * 우측으로 값 채우기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @param strDest
	 * @param nSize
	 * @return 채워진 문자열
	 */
	public static String padRight(String strTarget, String strDest, int nSize) {
		return padValue(strTarget, strDest, nSize, false);
	}

	/**
	 * <pre>
	 * 우측으로 공백 채우기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @param nSize
	 * @return 채워진 문자열
	 */
	public static String padRight(String strTarget, int nSize) {
		return padValue(strTarget, " ", nSize, false);
	}

	/**
	 * <pre>
	 * 대상 문자열을 금액형 문자열로 변환하기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @return 금액형 문자열
	 */
	@SuppressWarnings("null")
	public static String formatMoney(String strTarget) {
		if (strTarget == null && strTarget.trim().length() == 0)
			return "0";

		strTarget = removeComma(strTarget);

		String strSign = strTarget.substring(0, 1);
		if (strSign.equals("+") || strSign.equals("-")) { // 부호가 존재할 경우
			strSign = strTarget.substring(0, 1);
			strTarget = strTarget.substring(1);
		} else {
			strSign = "";
		}

		String strDot = "";
		if (strTarget.indexOf('.') != -1) { // 소숫점이 존재할 경우
			int nPosDot = strTarget.indexOf('.');
			strDot = strTarget.substring(nPosDot, strTarget.length());
			strTarget = strTarget.substring(0, nPosDot);
		}

		StringBuilder objSB = new StringBuilder(strTarget);
		int nLen = strTarget.length();
		for (int i = nLen; 0 < i; i -= 3) { // Comma 단위
			objSB.insert(i, ",");
		}

		return strSign + objSB.substring(0, objSB.length() - 1) + strDot;
	}

	/**
	 * <pre>
	 * 대상문자열의 소숫점 설정하기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @param nDotSize
	 * @return
	 */
	public static String round(String strTarget, int nDotSize) {
		if (strTarget == null || strTarget.trim().length() == 0)
			return strTarget;

		String strDot = null; // 占쌀쇽옙a; 占쏙옙占쏙옙占쏙옙 占쌀쇽옙a占쏙옙占쏙옙 占쏙옙

		int nPosDot = strTarget.indexOf('.');
		if (nPosDot == -1) { // 소숫점이 존재하지 않을 경우
			strDot = (nDotSize == 0) ? padValue("", "0", nDotSize, false) : "." + padValue("", "0", nDotSize, false);
		} else { // 소숫점이 존재할 경우

			String strDotValue = strTarget.substring(nPosDot + 1); // 소숫점 이하 값
			strTarget = strTarget.substring(0, nPosDot); // 정수 값

			if (strDotValue.length() >= nDotSize) { // 실제 소숫점 길이가 지정한 길이보다 크다면 지정한 소숫점 길이 만큼 잘라내기
				if (nDotSize == 0) { // 지정한 소수점 길이가 0이면 정수만 리턴
					strDot = "";
				} else {
					strDot = "." + strDotValue.substring(0, nDotSize);
				}
			} else { // 실제 소숫점길이가 지정한 길이보다 작다면 지정한 길이만큼 채우기
				strDot = "." + padValue(strDotValue, "0", nDotSize, false);
			}
		}

		return strTarget + strDot;
	}

	/**
	 * <pre>
	 * 대상 문자열을 날짜 포멧형 문자열로 변환하기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @return 날짜 포멧 문자열
	 */
	public static String formatDate(String strTarget) {
		String strValue = removeFormat(strTarget);

		if (strValue.length() != 8)
			return strTarget;

		StringBuilder objSB = new StringBuilder(strValue);
		objSB.insert(4, "-");
		objSB.insert(7, "-");

		return objSB.toString();
	}

//    /**
//     * <pre>
//     * 대상 문자열을 주민등록번호 포멧 문자열로 변환하기
//     * </pre>
//     * @date 2021. 5. 18.
//     * @author srec0012
//     * @history
//     * ------------------------------------------------
//     * 변경일					작성자				변경내용
//     * ------------------------------------------------
//     * 2021. 5. 18.			srec0012			최초작성
//     * ------------------------------------------------
//     * @param strTarget
//     * @return 주민등록번호 포멧 문자열
//     */
//    public static String formatJuminID(String strTarget) {
//        String strValue = removeFormat(strTarget);
//
//        if (strValue.length() != 8) return strTarget;
//
//        StringBuffer objSB = new StringBuffer(strValue);
//        objSB.insert(4, "-");
//        objSB.insert(7, "-");
//
//        return objSB.toString();
//    }

	/**
	 * <pre>
	 * 대상 문자열을 전화번호 포멧 문자열로 변환하기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @return 전화번호 포멧 문자열
	 */
	public static String formatPhone(String strTarget) {
		String strValue = removeFormat(strTarget);
		int nLength = strValue.length();

		if (nLength < 9 || nLength > 12) // 9 ~ 12 占쏙옙' 占쏙옙占쏙옙 占쏙옙占�
			return strTarget;

		StringBuilder objSB = new StringBuilder(strValue);
//        StringBuffer objSB = new StringBuffer(strValue);

		if (strValue.startsWith("02") == true) { // 서울지역일 경우
			if (nLength == 9) {
				objSB.insert(2, "-");
				objSB.insert(6, "-");
			} else {
				objSB.insert(2, "-");
				objSB.insert(7, "-");
			}
		} else { // 서울외 지역 또는 휴대폰 일 경우
			if (nLength == 10) {
				objSB.insert(3, "-");
				objSB.insert(7, "-");
			} else { // 내선번호등과 같은 특수 번호일 경우
				objSB.insert(3, "-");
				objSB.insert(8, "-");
			}
		}

		return objSB.toString();
	}

	/**
	 * <pre>
	 * 대상 문자열을 은행계좌 포멧 문자열로 변환하여 반환
	 * </pre>
	 *
	 * @date 2023. 8. 25.
	 * @author srec0051
	 * @param strTarget
	 * @return
	 */
	public static String formatBankAccountNo(String strTarget) {
		String strValue = removeFormat(strTarget);
		String regEx = null;
		final String PATTERN = "$1-$2-$3";

		if (isBlank(strValue)) {
			return strValue;
		}

		if (strValue.length() == 11) {
			// xxx-xxxxx-xxx
			regEx = "(\\d{3})(\\d{5})(\\d{3})";
			strValue = strValue.replaceAll(regEx, PATTERN);
		}

		if (strValue.length() == 12) {
			// xxx-xxxxxx-xxx
			regEx = "(\\d{3})(\\d{6})(\\d{3})";
			strValue = strValue.replaceAll(regEx, PATTERN);
		}

		if (strValue.length() == 14) {
			// xxx-xxxxxx-xxxxx
			regEx = "(\\d{3})(\\d{6})(\\d{5})";
			strValue = strValue.replaceAll(regEx, PATTERN);
		}

		return strValue;
	}

	/**
	 * <pre>
	 * 문자열 Byte Length 구하기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param str
	 * @return
	 */
	public static int getByteLength(String str) {
		int strLength = 0;

		char tempChar[] = new char[str.length()];

		for (int i = 0; i < tempChar.length; i++) {
			tempChar[i] = str.charAt(i);

			if (tempChar[i] < 128) {
				strLength++;
			} else {
				strLength += 2;
			}
		}

		return strLength;
	}

	/**
	 * <pre>
	 * HTML 태그 제거하기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @return 태그가 제거된 문자열
	 */
	public static String removeHTML(String strTarget) {
		if (strTarget == null || strTarget.equals(""))
			return strTarget;

		return strTarget.replaceAll("<(/)?([a-zA-Z]*)(\\s[a-zA-Z]*=[^>]*)?(\\s)*(/)?>", "");
	}

	/**
	 * <pre>
	 * HTML을 캐리지 리턴 값으로 변환하기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @return HTML을 캐리지 리턴값으로 반환한 문자열
	 */
	public static String encodingHTML(String strTarget) {
		if (strTarget == null || strTarget.equals(""))
			return strTarget;

		strTarget = strTarget.replaceAll("<br>", "\r\n");
		strTarget = strTarget.replaceAll("<q>", "'");
		strTarget = strTarget.replaceAll("&quot;", "\"");
		strTarget = strTarget.replaceAll("&nbsp;", "\u00A0");
		strTarget = strTarget.replaceAll("&amp;", "&");
		strTarget = strTarget.replaceAll("&sdot;", "'");

		return strTarget;
	}

	/**
	 * <pre>
	 * 캐리지리턴값을 HTML 태그로 변환하기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @return 캐리지 리턴값을 HTML 태그로 변환한 문자열
	 */
	public static String decodingHTML(String strTarget) {
		if (strTarget == null || strTarget.equals(""))
			return strTarget;

		strTarget = strTarget.replaceAll("\r\n", "<br/>");
		strTarget = strTarget.replaceAll("\u0020", "&nbsp;");
		strTarget = strTarget.replaceAll("'", "<q>");
		strTarget = strTarget.replaceAll("\"", "&quot;");

		return strTarget;
	}

	/**
	 * <pre>
	 * 문자열(String)을 카멜표기법으로 표현한다.
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param str
	 * @return
	 */
	public static String toUnCamelCase(String str) {
		String regex = "([a-z])([A-Z])";
		String replacement = "$1_$2";
		String value = "";
		value = str.replaceAll(regex, replacement).toUpperCase();

		return value;
	}

	/**
	 * <pre>
	 * 문자열(String)을 카멜표기법으로 표현한다.
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param str
	 * @param firstCharacterUppercase
	 * @return 카멜표기법으로 표현환 문자열
	 */
	public static String toCamelCase(String str, boolean firstCharacterUppercase) {
		if (str == null) {
			return null;
		}

		StringBuilder sb = new StringBuilder();

		boolean nextUpperCase = false;
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);

			if (c == '_') {
				if (sb.length() > 0) {
					nextUpperCase = true;
				}
			} else {
				if (nextUpperCase) {
					sb.append(Character.toUpperCase(c));
					nextUpperCase = false;
				} else {
					sb.append(Character.toLowerCase(c));
				}
			}
		}

		if (firstCharacterUppercase) {
			sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
		}

		return sb.toString();
	}

	/**
	 * <pre>
	 * 문자열(String)을 카멜표기법으로 표현한다.
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param str
	 * @return 카멜표기법으로 표현환 문자열
	 */
	public static String toCamelCase(String str) {
		return toCamelCase(str, false);
	}

	/**
	 * <pre>
	 * 대상문자열이 null 인지 여부 확인하기
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param str
	 * @return null 여부
	 */
	public static boolean isEmpty(String str) {
		return StringUtils.isEmpty(str);
	}

	public static boolean isNotEmpty(String str) {
		return StringUtils.isNotEmpty(str);
	}

	public static boolean isBlank(String str) {
		return StringUtils.isBlank(str);
	}

	public static boolean isNotBlank(String str) {
		return StringUtils.isNotBlank(str);
	}

	public static boolean isNumeric(String str) {
		return StringUtils.isNumeric(str);
	}

	public static boolean isNumericSpace(String str) {
		return StringUtils.isNumericSpace(str);
	}

	public static String[] splitEnter(String str) {
		return StringUtils.split(str, "\r\n");
	}

	public static String[] split(String str, String separatorChars) {
		return StringUtils.split(str, separatorChars);
	}

	/**
	 * <pre>
	 * 입력받은 숫자 자리수만큼의 숫자를 리턴한다.
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param length
	 * @return 입력받은 파라메터 길이만큼 랜덤한 0-9까지의 문자열
	 */
	public static String randomNumeric(int length) {
		return RandomStringUtils.randomNumeric(length);
	}

	/**
	 * <pre>
	 * 128bit Random UiqueID를 생성한다.
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @return
	 */
	public static String getUniqueId() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}

	public static String phoneNumber(String s) {
		if (isEmpty(s)) {
			return "";
		} else {
			String result = "";
			if (s.length() == 9) {
				result = s.substring(0, 2) + "-" + s.substring(2, 5) + "-" + s.substring(5);
			} else if (s.length() == 10) {
				if ("02".equals(s.substring(0, 2))) {
					result = s.substring(0, 2) + "-" + s.substring(2, 6) + "-" + s.substring(6);
				} else {
					result = s.substring(0, 3) + "-" + s.substring(3, 6) + "-" + s.substring(6);
				}
			} else {
				result = s.substring(0, 3) + "-" + s.substring(3, 7) + "-" + s.substring(7);
			}

			return result;
		}
	}

	public static String bizNo(String s) {
		if (isEmpty(s)) {
			return "";
		} else {
			String result = "";
			if (s.length() == 10) {
				result = s.substring(0, 3) + "-" + s.substring(3, 5) + "-" + s.substring(5);
			}
			return result;
		}
	}

	/**
	 * <pre>
	 * 문자열(String- 클래스명등)의 첫자를 대문자로 변환
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param str
	 * @return 문자열(String- 클래스명등)의 첫자를 대문자로 변환한 문자열
	 */
	public static String firstCharUpperCase(String str) {
		if (str == null) {
			return null;
		}
		StringBuilder sb = new StringBuilder();
		sb.append(str);
		sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
		return sb.toString();
	}

	/**
	 * <pre>
	 * 문자열(String- 클래스명등)의 첫자를 소문자로 변환
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param str
	 * @return 문자열(String- 클래스명등)의 첫자를 소문자로 변환한 문자열
	 */
	public static String firstCharLowerCase(String str) {
		if (str == null) {
			return null;
		}

		StringBuilder sb = new StringBuilder();
		sb.append(str);
		sb.setCharAt(0, Character.toLowerCase(sb.charAt(0)));

		return sb.toString();
	}

	/**
	 * <pre>
	 * trim 처리 NullPointerException 없이 처리
	 * strTarget이 null 이거나 화이트스페이스 일 경우 strTarget을 반환한다.
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @return strTarget이 null 이거나 화이트스페이스 일 경우 strTarget 문자열을 그대로 반환
	 */
	public static String trim(String strTarget) {
		String retValue = null;

		if (strTarget == null || "".equals(strTarget)) {
			retValue = strTarget;
		} else {
			retValue = strTarget.trim();
		}

		return retValue;
	}

	/**
	 * <pre>
	 * 이름 마스킹(masking) 처리
	 * strTarget이 null 이거나 화이트스페이스 일 경우 strTarget을 반환한다.
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param strTarget
	 * @return 첫 문자를 제외한 나머지 문자를 *로 치환하여 반환한다.
	 */
	public static String maskingName(String strTarget) {
		String retValue = null;

		if (strTarget == null || "".equals(strTarget)) {
			retValue = strTarget;
		} else {
			retValue = strTarget.replaceAll("(?<=.{1}).", "*");
		}

		return retValue;
	}

	/**
	 * <pre>
	 * 전화번호 문자열을 배열형태로 변환하여 리턴한다.
	 * str 이 null이거나 자리수가 모자라도 size 값 만큼의 배열을 리턴한다.
	 * </pre>
	 *
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 5. 18.
	 *          srec0012 최초작성 ------------------------------------------------
	 * @param str
	 * @param size
	 * @return
	 */
	public static String[] splitPhone(String str, int size) {
		if (size < 1) {
			throw new IllegalArgumentException("배열선언 사이즈는 1보다 커야합니다.");
		}

		String strtemp = StringUtil.nvl(str);
		String strreturn[] = new String[size];
		String strtelformat = StringUtil.formatPhone(strtemp);
		String strsplit[] = StringUtil.split(strtelformat, "-");
		for (int i = 0; i < size; i++) {
			if (i < strsplit.length) {
				strreturn[i] = strsplit[i];
			} else {
				strreturn[i] = "";
			}
		}

		return strreturn;
	}
}
