package com.sorincorp.comm.order.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CnCntrctOrderBasVO.java
 * 계약_계약 발주 기본 VO 객체
 * @version
 * @since 2023. 10. 13.
 * @author srec0066
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class CnCntrctOrderBasVO {
   /**
    * 계약 발주 번호
   */
   private String cntrctOrderNo;
   /**
    * 계약 번호
   */
   private String cntrctNo;
   /**
   * 계약 년월
   */
   private String cntrctYm;
   /**
   * 계약 년월 순번
   */
   private int cntrctYmSn;
   /**
   * 회원 번호
   */
   private String mberNo;
   /**
   * 업체 번호
   */
   private String entrpsNo;
   /**
    * 발주 일시
   */
   private java.sql.Timestamp orderDt;
   /**
    * 판매 방식 코드
   */
   private String sleMthdCode;
   /**
    * 금속 코드
   */
   private String metalCode;
   /**
    * 금속
   */
   private String metalNm;
   /**
    * 아이템 순번
   */
   private int itmSn;
   /**
    * 권역 대분류 코드
   */
   private String dstrctLclsfCode;
   /**
    * 권역 중분류 코드
   */
   private String dstrctMlsfcCode;
   /**
    * 권역 대분류
   */
   private String dstrctLclsfNm;
   /**
    * 브랜드 그룹 코드
   */
   private String brandGroupCode;
   /**
    * 브랜드 그룹
   */
   private String brandGroupNm;
   /**
    * 브랜드 코드
   */
   private String brandCode;
   /**
    * 브랜드
   */
   private String brandNm;
   /**
    * 상품명
    */
	private String goodsNm;
	/**
	 *  국기 이미지 URL
	 */
	private String nationFlagImgUrl;
   /**
    * 주문 중량
   */
   private int orderWt;
   /**
    * 배송 수단 코드
   */
   private String dlvyMnCode;
   /**
    * 출고 요청 일자
   */
   private String dlivyRequstDe;
   /**
    * 배송지 번호
   */
   private String dlvrgNo;
   /**
    * 배송 요청 내용
   */
   private String dlvyRequstCn;
   /**
    * 단가 산식 코드
   */
   private String untpcMntnfrmlaCode;
   /**
    * 단가 산식 코드 명
   */
   private String untpcMntnfrmlaNm;
   /**
    * 통화 구분 코드
   */
   private String crncySeCode;
   /**
    * 통화 구분 코드 명
   */
   private String crncySeNm;
   /**
    * 프리미엄 가격
   */
   private Long premiumPc;
   /**
    * QP 코드
   */
   private String qpCode;
   /**
    * 단가 확정 일자
   */
   private String untpcDcsnDe;
   /**
   * 프라이싱 번호
   */
   private String pricingNo;
   /**
   * 장바구니 번호
   */
   private String bsktNo;
   /**
    * 주문 번호
   */
   private String orderNo;
   /**
    * 지정가 주문 번호
   */
   private String limitOrderNo;
   /**
    * 미결제 사유
   */
   private String unsetlResn;
   /**
    * 삭제 일시
   */
   private java.sql.Timestamp deleteDt;
   /**
    * 삭제 여부
   */
   private String deleteAt;
   /**
    * 최초 등록자 아이디
   */
   private String frstRegisterId;
   /**
    * 최초 등록 일시
   */
   private java.sql.Timestamp frstRegistDt;
   /**
    * 최종 변경자 아이디
   */
   private String lastChangerId;
   /**
    * 최종 변경 일시
   */
   private java.sql.Timestamp lastChangeDt;
   /**
    * 결제 수단 이월렛 사용 여부(평균가 견적)
   */
   private String setleMnEwalletUseAt;
   /**
    * 결제 수단 증거금 사용 여부(평균가 견적)
   */
   private String setleMnWrtmUseAt;
   /**
    * 결제 수단 여신 사용 여부(평균가 견적)
   */
   private String setleMnCdtlnUseAt;
   /**
    * 평균가 거래 금액 비율
    */
   private String avrgpcDelngAmountRate;
   /**
    * 평균가 확정 단가 여부 : [Y:확정가, N:가단가]
    */
   private String avrgpcDcsnUntpcAt;
   /**
    * 검색 대상 데이터 수
    */
   private int dataCnt;
   /**
    * 검색 대상 데이터 수 (지정)
    */
   private int customDataCnt;
   /**
    * 발생 월
    */
   private String occrrncMt;

}
