package com.sorincorp.comm.pcInfo.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.pcInfo.mapper.PcInfoMapper;
import com.sorincorp.comm.pcInfo.model.FixPrice2VO;
import com.sorincorp.comm.pcInfo.model.FixPriceVO;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.LmePcVO;
import com.sorincorp.comm.pcInfo.model.PcMntrngSelVO;
import com.sorincorp.comm.pcInfo.model.PrEhgtRltmVO;
import com.sorincorp.comm.pcInfo.model.PrEhgtStdrVO;
import com.sorincorp.comm.pcInfo.model.PrEhgtVO;
import com.sorincorp.comm.pcInfo.model.PrPremiumSelVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.model.PreminumSelInfoVO;
import com.sorincorp.comm.pcInfo.model.RvcmpnVO;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PcInfoServiceImpl implements PcInfoService {
	
	public final static String SEL_PC_ALL_LIST = "selpcAllList";	// 프리미엄 적용 판매가격 (레디스에 저장할 이름)
	public final static String PREMIUM_INFO_LIST = "premiumInfoList";	// 프리미엄 가격 (레디스에 저장할 이름)
	
	@Autowired
	PcInfoMapper pcInfoMapper;

	@Autowired
	private RedisUtil redisUtil;

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public LmePcVO getPrLme(String metalCode, String occrrnc, String occrrncType) throws Exception {
		LmePcVO returnLmePcVO = new LmePcVO();
		LmePcVO lmePcVO = new LmePcVO();

		if ((metalCode == null || "".equals(metalCode)) && (occrrncType == null || "".equals(occrrncType))
				&& (occrrnc == null || "".equals(occrrnc))) {
			return null;
		}

		if ("DD".equals(occrrncType)) {

			lmePcVO.setMetalCode(metalCode);
			lmePcVO.setOccrrncDe(occrrnc);
			returnLmePcVO = pcInfoMapper.getPrLmeDe(lmePcVO);

		} else if ("WW".equals(occrrncType)) {

			lmePcVO.setMetalCode(metalCode);
			lmePcVO.setOccrrncYyWeek(occrrnc);
			returnLmePcVO = pcInfoMapper.getPrLmeWeek(lmePcVO);

		} else if ("MM".equals(occrrncType)) {

			lmePcVO.setMetalCode(metalCode);
			lmePcVO.setOccrrncYyMt(occrrnc);
			returnLmePcVO = pcInfoMapper.getPrLmeMt(lmePcVO);

		} else if ("QU".equals(occrrncType)) {

			lmePcVO.setMetalCode(metalCode);
			lmePcVO.setOccrrncYyQu(occrrnc);
			returnLmePcVO = pcInfoMapper.getPrLmeQu(lmePcVO);

		}

		return returnLmePcVO;
	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public LmePcVO getPrLmeSn(String metalCode, String lmePcSn, String occrrncType) throws Exception {
		LmePcVO returnLmePcVO = new LmePcVO();
		LmePcVO lmePcVO = new LmePcVO();

		if(StringUtil.isEmpty(metalCode) || StringUtil.isEmpty(lmePcSn) || StringUtil.isEmpty(occrrncType)) {
			return null;
		}

		if ("DD".equals(occrrncType)) {

			lmePcVO.setMetalCode(metalCode);
			lmePcVO.setLmePcDeSn(lmePcSn);
			returnLmePcVO = pcInfoMapper.getPrLmeDe(lmePcVO);

		} else if ("WW".equals(occrrncType)) {

			lmePcVO.setMetalCode(metalCode);
			lmePcVO.setLmePcYyWeekSn(lmePcSn);
			returnLmePcVO = pcInfoMapper.getPrLmeWeek(lmePcVO);

		} else if ("MM".equals(occrrncType)) {

			lmePcVO.setMetalCode(metalCode);
			lmePcVO.setLmePcYyMtSn(lmePcSn);
			returnLmePcVO = pcInfoMapper.getPrLmeMt(lmePcVO);

		} else if ("QU".equals(occrrncType)) {

			lmePcVO.setMetalCode(metalCode);
			lmePcVO.setLmePcYyQuSn(lmePcSn);
			returnLmePcVO = pcInfoMapper.getPrLmeQu(lmePcVO);

		}

		return returnLmePcVO;
	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public LmePcVO getPrLmeRltm(String metalCode, String occrrncDe, String occrrncTime, String occrrncSn)
			throws Exception {
		LmePcVO lmePcVO = new LmePcVO();

		if ((metalCode == null || "".equals(metalCode)) && (occrrncDe == null || "".equals(occrrncDe))
				&& (occrrncTime == null || "".equals(occrrncTime)) && (occrrncSn == null || "".equals(occrrncSn))) {
			return null;
		}

		lmePcVO.setMetalCode(metalCode);
		lmePcVO.setOccrrncDe(occrrncDe);
		lmePcVO.setOccrrncTime(occrrncTime);
		lmePcVO.setOccrrncSn(occrrncSn);


		return pcInfoMapper.getPrLmeRltm(lmePcVO);
	}


	@Override
	public LmePcVO getNewestPrLmeRltm(String metalCode, String occrrncDe) throws Exception {
		LmePcVO lmePcVO = new LmePcVO();

		if( (metalCode == null || "".equals(metalCode)) && (occrrncDe == null || "".equals(occrrncDe))) {
			return null;
		}

		lmePcVO.setMetalCode(metalCode);
		lmePcVO.setOccrrncDe(occrrncDe);

		return pcInfoMapper.getPrLmeRltm(lmePcVO);
	}


	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public LmePcVO getPrLmeRltmSn(String metalCode, String lmePcRltmSn) throws Exception {

		LmePcVO lmePcVO = new LmePcVO();

		if(StringUtil.isEmpty(metalCode) || StringUtil.isEmpty(lmePcRltmSn)) {
			return null;
		}

		lmePcVO.setMetalCode(metalCode);
		lmePcVO.setLmePcRltmSn(lmePcRltmSn);

		return pcInfoMapper.getPrLmeRltm(lmePcVO);
	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public LmePcVO getPrLmeAgo(String metalCode) throws Exception {

		LmePcVO lmePcVO = new LmePcVO();

		if(StringUtil.isEmpty(metalCode)) {
			return null;
		}

		lmePcVO.setMetalCode(metalCode);

		return pcInfoMapper.getPrLmeAgo(lmePcVO);
	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public PrSelVO getPrSel(String metalCode, Integer itmSn, String dstrctLclsfCode, String brandGroupCode,
			String brandCode, String occrrncDe, String occrrncType) throws Exception {
		PrSelVO returnPrSelVO = new PrSelVO();
		PrSelVO prSelVO = new PrSelVO();

		if((metalCode == null || "".equals(metalCode)) && (itmSn == null || itmSn == 0) && (dstrctLclsfCode == null || "".equals(dstrctLclsfCode))
				&& (brandGroupCode == null || "".equals(brandGroupCode)) && (brandCode == null || "".equals(brandCode)) && (occrrncDe == null || "".equals(occrrncDe))
				&& (occrrncType == null || "".equals(occrrncType))) {
			return null;
		}

		if ("DD".equals(occrrncType)) {

			prSelVO.setMetalCode(metalCode);
			prSelVO.setItmSn(itmSn);
			prSelVO.setDstrctLclsfCode(dstrctLclsfCode);
			prSelVO.setBrandGroupCode(brandGroupCode);
			prSelVO.setBrandCode(brandCode);
			prSelVO.setOccrrncDe(occrrncDe);
			returnPrSelVO = pcInfoMapper.getPrSelDe(prSelVO);

		} else if ("WW".equals(occrrncType)) {

			prSelVO.setMetalCode(metalCode);
			prSelVO.setItmSn(itmSn);
			prSelVO.setDstrctLclsfCode(dstrctLclsfCode);
			prSelVO.setBrandGroupCode(brandGroupCode);
			prSelVO.setBrandCode(brandCode);
			prSelVO.setOccrrncYyweek(occrrncDe);
			returnPrSelVO = pcInfoMapper.getPrSelWeek(prSelVO);

		} else if ("MM".equals(occrrncType)) {

			prSelVO.setMetalCode(metalCode);
			prSelVO.setItmSn(itmSn);
			prSelVO.setDstrctLclsfCode(dstrctLclsfCode);
			prSelVO.setBrandGroupCode(brandGroupCode);
			prSelVO.setBrandCode(brandCode);
			prSelVO.setOccrrncYm(occrrncDe);
			returnPrSelVO = pcInfoMapper.getPrSelMt(prSelVO);

		} else if ("QU".equals(occrrncType)) {

			prSelVO.setMetalCode(metalCode);
			prSelVO.setItmSn(itmSn);
			prSelVO.setDstrctLclsfCode(dstrctLclsfCode);
			prSelVO.setBrandGroupCode(brandGroupCode);
			prSelVO.setBrandCode(brandCode);
			prSelVO.setOccrrncQu(occrrncDe);
			returnPrSelVO = pcInfoMapper.getPrSelQu(prSelVO);

		}

		return returnPrSelVO;

	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public PrSelVO getPrSelSn(String metalCode, String sellPcSn, String occrrncType) throws Exception {
		PrSelVO returnPrSelVO = new PrSelVO();
		PrSelVO prSelVO = new PrSelVO();

		if(StringUtil.isEmpty(metalCode) || StringUtil.isEmpty(sellPcSn) || StringUtil.isEmpty(occrrncType)) {
			return null;
		}

		if ("DD".equals(occrrncType)) {

			prSelVO.setMetalCode(metalCode);
			prSelVO.setSlePcDeSn(sellPcSn);
			returnPrSelVO = pcInfoMapper.getPrSelDe(prSelVO);

		} else if ("WW".equals(occrrncType)) {

			prSelVO.setMetalCode(metalCode);
			prSelVO.setSlePcYyWeekSn(sellPcSn);
			returnPrSelVO = pcInfoMapper.getPrSelWeek(prSelVO);

		} else if ("MM".equals(occrrncType)) {

			prSelVO.setMetalCode(metalCode);
			prSelVO.setSlePcYyMtSn(sellPcSn);
			returnPrSelVO = pcInfoMapper.getPrSelMt(prSelVO);

		} else if ("QU".equals(occrrncType)) {

			prSelVO.setMetalCode(metalCode);
			prSelVO.setSlePcYyQuSn(sellPcSn);
			returnPrSelVO = pcInfoMapper.getPrSelQu(prSelVO);

		}

		return returnPrSelVO;
	}



	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public PrSelVO getPrSelRltm(String metalCode, Integer itemSn, String dstrcLclsfCode,
			String brandGroupCode, String brandCode, String occrrncDe, String occrrncTime, String occrrncSn)
			throws Exception {

		PrSelVO prSelVO = new PrSelVO();

		if((metalCode == null || "".equals(metalCode)) && (itemSn == null || itemSn == 0) && (dstrcLclsfCode == null || "".equals(dstrcLclsfCode))
				 && (brandGroupCode == null || "".equals(brandGroupCode)) && (brandCode == null || "".equals(brandCode)) && (occrrncDe == null || "".equals(occrrncDe))
				 && (occrrncSn == null || "".equals(occrrncSn))) {
			return null;
		}

		prSelVO.setMetalCode(metalCode);
		prSelVO.setItmSn(itemSn);
		prSelVO.setDstrctLclsfCode(dstrcLclsfCode);
		prSelVO.setBrandGroupCode(brandGroupCode);
		prSelVO.setBrandCode(brandCode);
		prSelVO.setOccrrncDe(occrrncDe);
		prSelVO.setOccrrncTime(occrrncTime);
		prSelVO.setOccrrncSn(occrrncSn);

		return pcInfoMapper.getPrSelRltm(prSelVO);
	}


	@Override
	public PrSelVO getNewestPrSelRltm(String metalCode, Integer itemSn, String dstrcLclsfCode, String brandGroupCode,
			String brandCode, String occrrncDe) throws Exception {
		PrSelVO prSelVO = new PrSelVO();

		if((metalCode == null || "".equals(metalCode)) && (itemSn == null || itemSn == 0) && (dstrcLclsfCode == null || "".equals(dstrcLclsfCode))
				 && (brandGroupCode == null || "".equals(brandGroupCode)) && (brandCode == null || "".equals(brandCode)) && (occrrncDe == null || "".equals(occrrncDe))) {
			return null;
		}

		prSelVO.setMetalCode(metalCode);
		prSelVO.setItmSn(itemSn);
		prSelVO.setDstrctLclsfCode(dstrcLclsfCode);
		prSelVO.setBrandGroupCode(brandGroupCode);
		prSelVO.setBrandCode(brandCode);
		prSelVO.setOccrrncDe(occrrncDe);

		return pcInfoMapper.getPrSelRltm(prSelVO);
	}

	@Override
	@Cacheable(cacheNames = "Preminume_Info", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public PrSelVO getAvgDeEndPrice(String metalCode, Integer itemSn, String dstrcLclsfCode, String brandGroupCode
			, String brandCode) throws Exception{

		PrSelVO prSelVO = new PrSelVO();

		if((metalCode == null || "".equals(metalCode)) && (itemSn == null || itemSn == 0) && (dstrcLclsfCode == null || "".equals(dstrcLclsfCode))
				 && (brandGroupCode == null || "".equals(brandGroupCode)) && (brandCode == null || "".equals(brandCode))) {
			return null;
		}

		prSelVO.setMetalCode(metalCode);
		prSelVO.setItmSn(itemSn);
		prSelVO.setDstrctLclsfCode(dstrcLclsfCode);
		prSelVO.setBrandGroupCode(brandGroupCode);
		prSelVO.setBrandCode(brandCode);

		return pcInfoMapper.getAvgDeEndPrice(prSelVO);
	}
	
	@Override
	@Cacheable(cacheNames = "Preminume_Info", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public List<PrSelVO> getAvgDeEndPriceList(PrSelVO vo) throws Exception{
		return pcInfoMapper.getAvgDeEndPriceList(vo);
	}


	@Override
	public PrSelVO getNewestPrSelRltmNonStandard(String metalCode, Integer itemSn, String dstrcLclsfCode, String brandGroupCode,
			String brandCode, String occrrncDe) throws Exception {

		PrSelVO prSelVO = new PrSelVO();

		if((metalCode == null || "".equals(metalCode)) && (itemSn == null || itemSn == 0) && (brandGroupCode == null || "".equals(brandGroupCode))
				&& (brandCode == null || "".equals(brandCode)) && (occrrncDe == null || "".equals(occrrncDe))) {
			return null;
		}

		prSelVO.setMetalCode(metalCode);
		prSelVO.setItmSn(itemSn);
		prSelVO.setDstrctLclsfCode(dstrcLclsfCode);
		prSelVO.setBrandGroupCode(brandGroupCode);
		prSelVO.setBrandCode(brandCode);
		prSelVO.setOccrrncDe(occrrncDe);

		return pcInfoMapper.getPrSelRltm(prSelVO);
	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public PrSelVO getPrSelRltmSn(String metalCode, String slePcRltmSn) throws Exception {
		PrSelVO prSelVO = new PrSelVO();

		if(StringUtil.isEmpty(metalCode) || StringUtil.isEmpty(slePcRltmSn)) {
			return null;
		}

		prSelVO.setMetalCode(metalCode);
		prSelVO.setSlePcRltmSn(slePcRltmSn);

		return pcInfoMapper.getPrSelRltm(prSelVO);
	}


	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public PrSelVO getNewestPrSelDe(String metalCode, Integer itmSn, String dstrctLclsfCode, String brandGroupCode,
			String brandCode, String occrrncDe) throws Exception {

		if((metalCode == null || "".equals(metalCode)) && (itmSn == null || itmSn == 0) && (dstrctLclsfCode == null || "".equals(dstrctLclsfCode))
				&& (brandGroupCode == null || "".equals(brandGroupCode)) && (brandCode == null || "".equals(brandCode)) && (occrrncDe == null || "".equals(occrrncDe))
				) {
			return null;
		}
		PrSelVO prSelVO = new PrSelVO();

		prSelVO.setMetalCode(metalCode);
		prSelVO.setItmSn(itmSn);
		prSelVO.setDstrctLclsfCode(dstrctLclsfCode);
		prSelVO.setBrandGroupCode(brandGroupCode);
		prSelVO.setBrandCode(brandCode);
		prSelVO.setOccrrncDe(occrrncDe);

		return pcInfoMapper.getNewestPrSelDe(prSelVO);
	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public PrEhgtVO getPrEhgt(String ehgtDelngCrncyCode, String occrrncValue, String occrrncType) throws Exception {
		if((ehgtDelngCrncyCode == null || "".equals(ehgtDelngCrncyCode))
			  ||(occrrncValue == null || "".equals(occrrncValue))
			  ||(occrrncType == null || "".equals(occrrncType))) {
			return null;
		}

		PrEhgtVO vo = new PrEhgtVO();
		vo.setEhgtDelngCrncyCode(ehgtDelngCrncyCode);
		vo.setOccrrncType(occrrncType);
		vo.setOccrrncValue(occrrncValue);
		return pcInfoMapper.getPrEhgt(vo);
	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public PrEhgtVO getPrEhgtSn(String ehgtDelngCrncyCode, String ehgtPcRltmSn, String occrrncType) throws Exception {

		if(StringUtil.isEmpty(ehgtDelngCrncyCode) || StringUtil.isEmpty(ehgtPcRltmSn) || StringUtil.isEmpty(occrrncType)) {
			return null;
		}

		PrEhgtVO vo = new PrEhgtVO();
		vo.setEhgtDelngCrncyCode(ehgtDelngCrncyCode);
		vo.setEhgtPcRltmSn(ehgtPcRltmSn);
		vo.setOccrrncType(occrrncType);
		return pcInfoMapper.getPrEhgtSn(vo);
	}


	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public PrEhgtRltmVO getPrEhgtRltm(String ehgtDelngCrncyCode, String occrrncDe, String occrrncTime, String occrrncSn)
			throws Exception {
		if((ehgtDelngCrncyCode == null || "".equals(ehgtDelngCrncyCode))
				||(occrrncDe == null || "".equals(occrrncDe))
				||(occrrncTime == null || "".equals(occrrncTime))
				||(occrrncSn == null || "".equals(occrrncSn))) {
				return null;
			}

		PrEhgtRltmVO vo = new PrEhgtRltmVO();
		vo.setEhgtDelngCrncyCode(ehgtDelngCrncyCode);
		vo.setOccrrncDe(occrrncDe);
		vo.setOccrrncTime(occrrncTime);
		vo.setOccrrncSn(occrrncSn);
		return pcInfoMapper.getPrEhgtRltm(vo);
	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public PrEhgtRltmVO getPrEhgtRltmSn(String ehgtDelngCrncyCode, String ehgtPcRltmSn) throws Exception {

		if(StringUtil.isEmpty(ehgtDelngCrncyCode) || StringUtil.isEmpty(ehgtPcRltmSn)) {
			return null;
		}
		PrEhgtRltmVO vo = new PrEhgtRltmVO();
		vo.setEhgtDelngCrncyCode(ehgtDelngCrncyCode);
		vo.setEhgtPcRltmSn(ehgtPcRltmSn);
		return pcInfoMapper.getPrEhgtRltmSn(vo);
	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public PrEhgtStdrVO getPrEhgtStdr(String ehgtDelngCrncyCode, String occrrncDe) throws Exception {
		if((ehgtDelngCrncyCode == null || "".equals(ehgtDelngCrncyCode))
				||(occrrncDe == null || "".equals(occrrncDe))) {
				return null;
			}

		PrEhgtStdrVO vo = new PrEhgtStdrVO();
		vo.setEhgtDelngCrncyCode(ehgtDelngCrncyCode);
		vo.setOccrrncDe(occrrncDe);
		return pcInfoMapper.getPrEhgtStdr(vo);
	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public PrEhgtStdrVO getPrEhgtAgo() throws Exception {
		return pcInfoMapper.getPrEhgtAgo();
	}

//	사용하는 곳 없음 20230525
//	@Override
//	public LivePremiumVO getLivePremium(String metalCode, Integer itmSn, String dstrctLclsfCode, String brandGroupCode,
//			String brandCode, String occrrncDe) throws Exception {
//		if((metalCode == null || "".equals(metalCode))
//				||(itmSn < 0)
//				||(dstrctLclsfCode == null || "".equals(dstrctLclsfCode))
//				||(brandGroupCode == null || "".equals(brandGroupCode))
//				||(brandCode == null || "".equals(brandCode))
//				||(occrrncDe == null || "".equals(occrrncDe))) {
//				return null;
//			}
//
//		LivePremiumVO vo = new LivePremiumVO();
//		vo.setMetalCode(metalCode);
//		vo.setItmSn(itmSn);
//		vo.setDstrctLclsfCode(dstrctLclsfCode);
//		vo.setBrandGroupCode(brandGroupCode);
//		vo.setBrandCode(brandCode);
//		vo.setOccrrncDe(occrrncDe);
//		return pcInfoMapper.getLivePremium(vo);
//	}

//	getLivePremiumInfoList 통합으로 사용 안함 20230525
//	@Override
//	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
//	public LivePremiumVO getLivePremiumNo(String premiumNo) throws Exception {
//		if(premiumNo == null || "".equals(premiumNo)) {
//				return null;
//			}
//		LivePremiumVO vo = new LivePremiumVO();
//		vo.setPremiumNo(premiumNo);
//		return pcInfoMapper.getLivePremium(vo);
//	}

	/**
	 * 프리미엄 아이디 및 관련 조건으로 시점 코드 [present: 현재 시점, past: 과거 시점]에 따른 프리미엄 가격 정보 리스트 가져오기
	 */
	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public List<LivePremiumVO> getLivePremiumInfoList(String timePointCode, String premiumId, String metalCode, Integer itmSn, String dstrctLclsfCode
			, String brandGroupCode, String brandCode, String limitOrderTmByFormat) throws Exception {

		LivePremiumVO livePremiumVO = new LivePremiumVO();
		livePremiumVO.setPremiumNo(null); // 프리미엄 번호
		livePremiumVO.setTimePointCode(timePointCode); // 시점 코드 [present: 현재 시점, past: 과거 시점]
		livePremiumVO.setPremiumId(premiumId); // 프리미엄 아이디
		livePremiumVO.setMetalCode(metalCode); // 금속 코드
		livePremiumVO.setItmSn(itmSn); // 아이템 순번
		livePremiumVO.setDstrctLclsfCode(dstrctLclsfCode); // 권역 대분류 코드
		livePremiumVO.setBrandGroupCode(brandGroupCode); // 브랜드 그룹 코드
		livePremiumVO.setBrandCode(brandCode); // 브랜드 코드
		livePremiumVO.setOccrrncDe(limitOrderTmByFormat); // 지정가 주문 일시 (유효 일시 검색 조건)

		return pcInfoMapper.getLivePremiumInfoList(livePremiumVO);
	}

	/**
	 * 프리미엄 아이디 및 관련 조건으로 시점 코드 [present: 현재 시점, past: 과거 시점]에 따른 프리미엄 가격 정보 가져오기
	 */
	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public LivePremiumVO getLivePremiumInfo(String timePointCode, String premiumId, String metalCode, Integer itmSn, String dstrctLclsfCode
			, String brandGroupCode, String brandCode, String limitOrderTmByFormat) throws Exception {

		LivePremiumVO livePremiumVO = new LivePremiumVO();
		livePremiumVO.setPremiumNo(null); // 프리미엄 번호
		livePremiumVO.setTimePointCode(timePointCode); // 시점 코드 [present: 현재 시점, past: 과거 시점]
		livePremiumVO.setPremiumId(premiumId); // 프리미엄 아이디
		livePremiumVO.setMetalCode(metalCode); // 금속 코드
		livePremiumVO.setItmSn(itmSn); // 아이템 순번
		livePremiumVO.setDstrctLclsfCode(dstrctLclsfCode); // 권역 대분류 코드
		livePremiumVO.setBrandGroupCode(brandGroupCode); // 브랜드 그룹 코드
		livePremiumVO.setBrandCode(brandCode); // 브랜드 코드
		livePremiumVO.setOccrrncDe(limitOrderTmByFormat); // 지정가 주문 일시 (유효 일시 검색 조건)
		
		List<LivePremiumVO> livePremiumInfoList = pcInfoMapper.getLivePremiumInfoList(livePremiumVO);
		if(livePremiumInfoList != null && livePremiumInfoList.size() > 0) {
			return livePremiumInfoList.get(0);
		} else {
			return null;
		}
	}

	/**
	 * 프리미엄 번호 조건으로 시점 코드 [present: 현재 시점, past: 과거 시점]에 따른 프리미엄 가격 정보 가져오기
	 */
	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public LivePremiumVO getLivePremiumInfo(String timePointCode, String premiumNo) throws Exception {
		if(StringUtils.isBlank(premiumNo)) {
			return null;
		}

		LivePremiumVO livePremiumVO = new LivePremiumVO();
		livePremiumVO.setTimePointCode(timePointCode); // 시점 코드 [present: 현재 시점, past: 과거 시점]
		livePremiumVO.setPremiumNo(premiumNo); // 프리미엄 번호
		
		List<LivePremiumVO> livePremiumInfoList = pcInfoMapper.getLivePremiumInfoList(livePremiumVO);
		if(livePremiumInfoList != null && livePremiumInfoList.size() > 0) {
			return livePremiumInfoList.get(0);
		} else {
			return null;
		}
	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public LivePremiumVO getLivePremiumByTerm(String metalCode, Integer itmSn, String dstrctLclsfCode,
			String brandGroupCode, String brandCode, String termType, String termValue) throws Exception {
		if((metalCode == null || "".equals(metalCode))
				||(itmSn < 0)
				||(dstrctLclsfCode == null || "".equals(dstrctLclsfCode))
				||(brandGroupCode == null || "".equals(brandGroupCode))
				||(brandCode == null || "".equals(brandCode))
				||(termType == null || "".equals(termType))
				||(termValue == null || "".equals(termValue))) {
				return null;
			}

		LivePremiumVO vo = new LivePremiumVO();
		vo.setMetalCode(metalCode);
		vo.setItmSn(itmSn);
		vo.setDstrctLclsfCode(dstrctLclsfCode);
		vo.setBrandGroupCode(brandGroupCode);
		vo.setBrandCode(brandCode);
		vo.setTermType(termType);
		vo.setTermValue(termValue);
		return pcInfoMapper.getLivePremiumByTerm(vo);
	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public FixPriceVO getFixPrice(String metalCode, Integer itmSn, String dstrctLclsfCode, String brandGroupCode,
			String brandCode, Long entrpsGradNo, String occrrncDe) throws Exception {
		if((metalCode == null || "".equals(metalCode))
				||(itmSn < 0)
				||(dstrctLclsfCode == null || "".equals(dstrctLclsfCode))
				||(brandGroupCode == null || "".equals(brandGroupCode))
				||(brandCode == null || "".equals(brandCode))
				||(entrpsGradNo == null || entrpsGradNo == 0)
				||(occrrncDe == null || "".equals(occrrncDe))) {
				return null;
			}
		FixPriceVO vo = new FixPriceVO();
		vo.setMetalCode(metalCode);
		vo.setItmSn(itmSn);
		vo.setDstrctLclsfCode(dstrctLclsfCode);
		vo.setBrandGroupCode(brandGroupCode);
		vo.setBrandCode(brandCode);
		return pcInfoMapper.getFixPrice(vo);
	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public FixPriceVO getFixPriceNo(String premiumNo) throws Exception {
		if((premiumNo == null || "".equals(premiumNo))) {
				return null;
			}
		FixPriceVO vo = new FixPriceVO();
		vo.setPremiumNo(premiumNo);
		return pcInfoMapper.getFixPrice(vo);
	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public FixPriceVO getFixPriceByTerm(String metalCode, Integer itmSn, String dstrctLclsfCode, String brandGroupCode,
			String brandCode, Long entrpsGradNo, String termType, String termValue) throws Exception {
		if((metalCode == null || "".equals(metalCode))
				||(itmSn < 0)
				||(dstrctLclsfCode == null || "".equals(dstrctLclsfCode))
				||(brandGroupCode == null || "".equals(brandGroupCode))
				||(brandCode == null || "".equals(brandCode))
				||(entrpsGradNo < 0)
				||(termType == null || "".equals(termType))
				||(termValue == null || "".equals(termValue))) {
				return null;
			}

		FixPriceVO vo = new FixPriceVO();
		vo.setMetalCode(metalCode);
		vo.setItmSn(itmSn);
		vo.setDstrctLclsfCode(dstrctLclsfCode);
		vo.setBrandGroupCode(brandGroupCode);
		vo.setBrandCode(brandCode);
		vo.setTermType(termType);
		vo.setTermValue(termValue);
		return pcInfoMapper.getFixPriceByTerm(vo);
	}


	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public LivePremiumVO getLivePremiumStdrByMetalCode(String metalCode) throws Exception {
		if(metalCode == null || "".equals(metalCode)){
			return null;
		}
		LivePremiumVO vo = new LivePremiumVO();
		vo.setMetalCode(metalCode);
		return pcInfoMapper.getLivePremiumStdrByMetalCode(vo);
	}

	@Override
	public RvcmpnVO getRvcmpn(String applcDe, String brandGroupCode, String metalCode) throws Exception {
		if((applcDe == null || "".equals(applcDe))
				|| (brandGroupCode == null || "".equals(brandGroupCode))
				|| (metalCode == null || "".equals(metalCode))){
			return null;
		}
		RvcmpnVO vo = new RvcmpnVO();
		vo.setApplcDe(applcDe);
		vo.setBrandGroupCode(brandGroupCode);
		vo.setMetalCode(metalCode);
		return pcInfoMapper.getRvcmpn(vo);
	}

	@Override
	public PrEhgtRltmVO getNewestPrEhgtRltm(String ehgtDelngCrncyCode) {
		if(ehgtDelngCrncyCode == null || "".equals(ehgtDelngCrncyCode)){
			return null;
		}
		PrEhgtRltmVO vo = new PrEhgtRltmVO();
		vo.setEhgtDelngCrncyCode(ehgtDelngCrncyCode);
		return pcInfoMapper.getNewestPrEhgtRltm(vo);
	}

	@Override
	@Cacheable(value = "PcInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public PrEhgtRltmVO getNewestPrEhgtRltmByDay(String ehgtDelngCrncyCode, String occrrncDe) {
		if((ehgtDelngCrncyCode == null || "".equals(ehgtDelngCrncyCode))
				|| occrrncDe == null || "".equals(occrrncDe)){
			return null;
		}
        if (DateUtil.compareToCalerdar(DateUtil.getNowDate(), occrrncDe) < 0) {
    	    return null;
        }

		PrEhgtRltmVO vo = new PrEhgtRltmVO();
		vo.setEhgtDelngCrncyCode(ehgtDelngCrncyCode);
		vo.setOccrrncDe(occrrncDe);
		return pcInfoMapper.getNewestPrEhgtRltmByDay(vo);
	}

	@Override
	public FixPriceVO hasFixPriceData(String metalCode, Integer itmSn, String dstrctLclsfCode, String brandGroupCode,
			String brandCode, String occrrncDe) throws Exception {
		FixPriceVO vo = new FixPriceVO();
		vo.setMetalCode(metalCode);
		vo.setItmSn(itmSn);
		vo.setDstrctLclsfCode(dstrctLclsfCode);
		vo.setBrandGroupCode(brandGroupCode);
		vo.setBrandCode(brandCode);
		vo.setOccrrncDe(occrrncDe);
		return pcInfoMapper.hasFixPriceData(vo);
	}

	@Override
	public FixPriceVO hasEntrpsFixPriceData(String metalCode, Integer itmSn, String dstrctLclsfCode, String brandGroupCode,
			String brandCode, String entrpsNo, String applcYm) throws Exception {
		FixPriceVO vo = new FixPriceVO();

		vo.setMetalCode(metalCode);
		vo.setItmSn(itmSn);
		vo.setDstrctLclsfCode(dstrctLclsfCode);
		vo.setBrandGroupCode(brandGroupCode);
		vo.setBrandCode(brandCode);
		vo.setEntrpsNo(entrpsNo);
		vo.setApplcYm(applcYm);

		List<FixPriceVO> hasEntrpsFixPriceDataList = pcInfoMapper.hasEntrpsFixPriceData(vo);

		FixPriceVO hasEntrpsFixPriceData = null;

		if(hasEntrpsFixPriceDataList != null) {
			if(hasEntrpsFixPriceDataList.size() > 0 ) {
				hasEntrpsFixPriceData = hasEntrpsFixPriceDataList.size() > 0 ? hasEntrpsFixPriceDataList.get(0) : new FixPriceVO();
			}
		}

		return hasEntrpsFixPriceData;
	}

	@Override
	public List<FixPriceVO> hasEntrpsFixPriceDataList(String metalCode, String metalClCode, Integer itmSn, String dstrctLclsfCode, String brandGroupCode,
			String brandCode, String entrpsNo, String applcYm) throws Exception {
		FixPriceVO vo = new FixPriceVO();

		vo.setMetalCode(metalCode);
		vo.setMetalClCode(metalClCode);
		vo.setItmSn(itmSn);
		vo.setDstrctLclsfCode(dstrctLclsfCode);
		vo.setBrandGroupCode(brandGroupCode);
		vo.setBrandCode(brandCode);
		vo.setEntrpsNo(entrpsNo);
		vo.setApplcYm(applcYm);

		return pcInfoMapper.hasEntrpsFixPriceData(vo);
	}

	@Override
	public List<FixPriceVO> getFixPrice(String metalCode, Integer itmSn, String brandGroupCode,
			String brandCode, String occrrncDe) throws Exception {
		if((metalCode == null || "".equals(metalCode))
				||(itmSn < 0)
				||(brandGroupCode == null || "".equals(brandGroupCode))
				||(brandCode == null || "".equals(brandCode))
				||(occrrncDe == null || "".equals(occrrncDe))) {
				return null;
			}
		FixPriceVO vo = new FixPriceVO();
		vo.setMetalCode(metalCode);
		vo.setItmSn(itmSn);
		vo.setBrandGroupCode(brandGroupCode);
		vo.setBrandCode(brandCode);
		vo.setOccrrncDe(occrrncDe);
		List<FixPriceVO> list = new ArrayList<FixPriceVO>();
		list = pcInfoMapper.getFixPrice3(vo);
		return list;
	}

	@Override
	public List<FixPrice2VO> getFixPrice(String applcYm, String metalCode) throws Exception {
		if((applcYm == null || "".equals(applcYm))
				||(metalCode == null || "".equals(metalCode))) {
				return null;
			}
		FixPrice2VO vo = new FixPrice2VO();
		vo.setMetalCode(metalCode);
		vo.setApplcYm(applcYm);

		List<FixPrice2VO> list = new ArrayList<FixPrice2VO>();
		list = pcInfoMapper.getFixPrice4(vo);
		return list;
	}

	@Override
	public List<RvcmpnVO> getRvcmpn(String applcDe, String metalCode) throws Exception {
		if((applcDe == null || "".equals(applcDe))
				|| (metalCode == null || "".equals(metalCode))){
			return null;
		}
		RvcmpnVO vo = new RvcmpnVO();
		vo.setApplcDe(applcDe);
		vo.setMetalCode(metalCode);
		return pcInfoMapper.getRvcmpn2(vo);
	}
	
	@Override
	public List<RvcmpnVO> getRvcmpnList(RvcmpnVO vo) throws Exception {
		return pcInfoMapper.getRvcmpnList(vo);
	}

	@Override
	public List<LivePremiumVO> getStdrPremiumList(String premiumId, String brandGroupCode) throws Exception {
		if((premiumId == null || "".equals(premiumId))
				||(brandGroupCode == null || "".equals(brandGroupCode))) {
				return null;
			}

		LivePremiumVO vo = new LivePremiumVO();
		vo.setPremiumId(brandGroupCode);
		vo.setBrandGroupCode(brandGroupCode);

		return pcInfoMapper.getStdrPremiumList(vo);
	}

	/**
	 * 종목별로 현재 적용중인 프리미엄 정보 및 당일 전체 시간에 해당하는 프리미엄 데이터를 불러온다
	 */
	@Override
	public Map<String, TreeSet<LivePremiumVO>> getPremiumInfoMap() throws Exception {
	    List<LivePremiumVO> premiumInfoList = pcInfoMapper.getPremiumInfoMap();
	    Map<String, TreeSet<LivePremiumVO>> premiumInfoMap = new ConcurrentHashMap<>();

	    for (LivePremiumVO premiumVO : premiumInfoList) {
	        String key = generateKey(premiumVO); // key 값 생성

	        // 이미 해당 키가 premiumInfoMap에 존재하는 경우
	        if (premiumInfoMap.containsKey(key)) {
	            TreeSet<LivePremiumVO> value = premiumInfoMap.get(key); // 기존 value 값 가져오기
	            value.add(premiumVO); // 기존 value에 현재 premiumVO를 추가
	        }
	        // 해당 키가 premiumInfoMap에 존재하지 않는 경우
	        else {
	            TreeSet<LivePremiumVO> value = new TreeSet<>(); // TreeSet으로 변경
	            value.add(premiumVO); // 새로운 LivePremiumVO 객체를 리스트에 추가
	            premiumInfoMap.put(key, value); // ConcurrentHashMap에 key와 value 쌍을 추가
	        }
	    }

	    return premiumInfoMap;
	}
	// key 값을 생성하는 메소드
	private String generateKey(LivePremiumVO premiumVO) {
	    String key = premiumVO.getMetalCode() + "_" +
	            premiumVO.getItmSn() + "_" +
	            premiumVO.getDstrctLclsfCode() + "_" +
	            premiumVO.getBrandGroupCode() + "_" +
	            premiumVO.getBrandCode();
	    return key;
	}

	@Override
	public PrSelVO getChartTitleInfo(PrSelVO prSelVO) {
		return pcInfoMapper.getChartTitleInfo(prSelVO);
	}
	
	@Override
	public List<PrSelVO> getBrandGroupPriceInfoList(PrSelVO prSelVO) {
		return pcInfoMapper.getBrandGroupPriceInfoList(prSelVO);
	}
	
	@Override
	@Cacheable(cacheNames = "Chart_All", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public List<PcMntrngSelVO> getPcMngtrngSel1MinList(PcMntrngSelVO pcMntrngSelVO) {
		return pcInfoMapper.getPcMngtrngSel1MinList(pcMntrngSelVO);
	}

	@Override
	@Cacheable(cacheNames = "Chart_All", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public List<PcMntrngSelVO> getPcMngtrngSel30MinList(PcMntrngSelVO pcMntrngSelVO) throws Exception {
		return pcInfoMapper.getPcMngtrngSel30MinList(pcMntrngSelVO);
	}

	@Override
	@Cacheable(cacheNames = "Chart_All", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public List<PcMntrngSelVO> getPcMngtrngSel60MinList(PcMntrngSelVO pcMntrngSelVO) throws Exception {
		return pcInfoMapper.getPcMngtrngSel60MinList(pcMntrngSelVO);
	}
	
	@Override
	@Cacheable(cacheNames = "Chart_All", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public List<PcMntrngSelVO> getPcMngtrngSelDeList(PcMntrngSelVO pcMntrngSelVO) {
		return pcInfoMapper.getPcMngtrngSelDeList(pcMntrngSelVO);
	}

	@Override
	@Cacheable(cacheNames = "Chart_All", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public List<PcMntrngSelVO> getPcMngtrngSelMonthList(PcMntrngSelVO pcMntrngSelVO) throws Exception {
		return pcInfoMapper.getPcMngtrngSelMonthList(pcMntrngSelVO);
	}
	
	/**
	 * json형식의 데이터를 \t으로 구분하여 로그를 출력한다.
	 */
	@Override
	public String logJSONAsTable(String result) {
	    try {
	        JSONParser parser = new JSONParser();
	        Object parsedObject = parser.parse(result);

	        StringBuilder sb = new StringBuilder();

	        if (parsedObject instanceof JSONArray) {
	            JSONArray jsonArray = (JSONArray) parsedObject;

	            if (jsonArray.isEmpty()) {
	                // JSONArray가 비어있는 경우 빈 문자열 반환
	                return sb.toString();
	            }

	            // 테이블 헤더 작성
	            JSONObject firstObject = (JSONObject) jsonArray.get(0);
	            for (Object key : firstObject.keySet()) {
	                sb.append(key).append("\t");
	            }
	            sb.append("\n");

	            // JSON 배열의 각 객체를 테이블 형태로 작성
	            int count = 1;
	            for (Object object : jsonArray) {
	                JSONObject jsonObject = (JSONObject) object;
	                logJSONObjectAsTableRow(jsonObject, sb);
	                count++;
	            }

	            sb.append("----------------------------------------------------\n");
	        } else if (parsedObject instanceof JSONObject) {
	            JSONObject jsonObject = (JSONObject) parsedObject;
	            logJSONObjectAsTableRow(jsonObject, sb);
	        }

	        return sb.toString();
	    } catch (ParseException | ClassCastException e) {
	        e.printStackTrace();
	    }

	    return null;
	}

	private void logJSONObjectAsTableRow(JSONObject jsonObject, StringBuilder sb) {
	    for (Object value : jsonObject.values()) {
	        if (value instanceof JSONObject) {
	            // 중첩된 JSON 객체인 경우 재귀 호출
	            logJSONObjectAsTableRow((JSONObject) value, sb);
	        } else if (value instanceof JSONArray) {
	            // JSON 배열인 경우 처리
	            JSONArray jsonArray = (JSONArray) value;
	            for (Object arrayValue : jsonArray) {
	                if (arrayValue instanceof JSONObject) {
	                    logJSONObjectAsTableRow((JSONObject) arrayValue, sb);
	                } else {
	                    sb.append(arrayValue).append("\t");
	                }
	            }
	        } else {
	            sb.append(value).append("\t");
	        }
	    }
	    sb.append("\n");
	}
	
	@Override
	@Cacheable(cacheNames = "Chart_All", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public List<PcMntrngSelVO> getEndPcAgoSelDeList(PcMntrngSelVO pcMntrngSelVO) {
		return pcInfoMapper.getEndPcAgoSelDeList(pcMntrngSelVO);
	}

	@Override
	public List<PrPremiumSelVO> getChartTitleInfoList(String metalCode) throws Exception {
		return pcInfoMapper.getChartTitleInfoList(metalCode);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<PrPremiumSelVO> getChartTitleInfoByRedisData(String metalCode) throws Exception {
		List<PrPremiumSelVO> chartTitleInfoByRedisDataList;
		try {
			chartTitleInfoByRedisDataList = (List<PrPremiumSelVO>) redisUtil.getDataJson(SEL_PC_ALL_LIST + metalCode);
			
			if(chartTitleInfoByRedisDataList.isEmpty()) {
				chartTitleInfoByRedisDataList = pcInfoMapper.getChartTitleInfoList(metalCode);
			}
			
		}catch(Exception e){
			chartTitleInfoByRedisDataList = pcInfoMapper.getChartTitleInfoList(metalCode);
		}
		return chartTitleInfoByRedisDataList;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<PreminumSelInfoVO> getPremiumInfoListByRedisData() throws Exception {
		List<LivePremiumVO> premiumInfoList;
		
		try {
			premiumInfoList = (List<LivePremiumVO>) redisUtil.getDataJson(PREMIUM_INFO_LIST);
			
			if(premiumInfoList.isEmpty()) {
				premiumInfoList = pcInfoMapper.getPremiumInfoMap();
			}
			
		}catch(Exception e){
			premiumInfoList = pcInfoMapper.getPremiumInfoMap();
		}
		
		Date currentDate = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
		List<PreminumSelInfoVO> premiumInfoListByRedisData = new ArrayList<PreminumSelInfoVO>();
		
		for(LivePremiumVO livePremiumVO : premiumInfoList) {
			Date startTime = formatter.parse(livePremiumVO.getValidBeginDt());
			Date endTime = formatter.parse(livePremiumVO.getValidEndDt());
			
			if (startTime != null && endTime != null) {
				if (startTime.before(currentDate) && endTime.after(currentDate)) {
					PreminumSelInfoVO preminumSelInfoVO = new PreminumSelInfoVO();
					preminumSelInfoVO.setSlePremiumAmount(livePremiumVO.getSlePremiumAmount());
					preminumSelInfoVO.setMetalCode(livePremiumVO.getMetalCode());
					preminumSelInfoVO.setItmSn(livePremiumVO.getItmSn());
					preminumSelInfoVO.setDstrctLclsfCode(livePremiumVO.getDstrctLclsfCode());
					preminumSelInfoVO.setBrandGroupCode(livePremiumVO.getBrandGroupCode());
					preminumSelInfoVO.setBrandCode(livePremiumVO.getBrandCode());
					premiumInfoListByRedisData.add(preminumSelInfoVO);
				}
			}
		}
		
		return premiumInfoListByRedisData;
	} 
	@Override
	public void setPremiumInfoListByRedisData() throws Exception {
		List<LivePremiumVO> premiumInfoMap = pcInfoMapper.getPremiumInfoMap();
	
		redisUtil.setDataJson(PREMIUM_INFO_LIST , premiumInfoMap);
		
	}
}
