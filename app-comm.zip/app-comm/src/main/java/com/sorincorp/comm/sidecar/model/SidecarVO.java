package com.sorincorp.comm.sidecar.model;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Data;

@Data
public class SidecarVO implements Serializable{
    
	private static final long serialVersionUID = 2849004139164064398L;
	
	/**
     * 금속 코드
    */
    private String metalCode;
	/**
     * 발동일자
    */
    private String motnDe;
    /**
     * 지속 시간
    */
    private String cntncTime;
    /**
     * 가격 표시 불가 시간
    */
    private String pcindictimprtytime;
    /**
     * 발동 시작 일시
    */
    private java.sql.Timestamp motnBeginDt;
    /**
     * 발동 종료 일시
    */
    private java.sql.Timestamp motnEndDt;
    /**
     * 전일 대비 비율
    */
    private BigDecimal bfrtVersusRate;
    /**
     * 발동 유효 시간
    */
    private int validMin;
    /*
     * 발동 유무
     * */
    private String motnAt;
}
