package com.sorincorp.comm.order.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CommFtrsFshgMngVO.java
 * 선물 선물환 관리 VO 객체
 *
 * @version
 * @since 2022. 6. 8.
 * @author srec0049
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class CommFtrsFshgMngVO {
	/**
     * 적용 일자
    */
    private String applcDe;
    /**
     * 포지션 코드
    */
    private String postnCode;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 선물 스킵 미만 여부
    */
    private String ftrsSkipBeloAt;
    /**
     * 선물 스킵 미만 금액
    */
    private java.math.BigDecimal ftrsSkipBeloAmount;
    /**
     * 선물 스킵 초과 여부
    */
    private String ftrsSkipExcessAt;
    /**
     * 선물 스킵 초과 금액
    */
    private java.math.BigDecimal ftrsSkipExcessAmount;
    /**
     * 선물 live 틱
    */
    private int ftrsTick;
    /**
     * 선물 지정가 틱
    */
    private int ftrsLimitTick;
    /**
     * LME 조정 계수 금액
    */
    private java.math.BigDecimal lmeMdatCffcntAmount;
    /**
     * 환율 조정 계수 금액
    */
    private java.math.BigDecimal ehgtMdatCffcntAmount;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;

    /**
     * 스킵 여부
    */
    private String skipAt;

    /**
     * 삼성선물 호가 단위
     */
    private double quoteUnit;
}
