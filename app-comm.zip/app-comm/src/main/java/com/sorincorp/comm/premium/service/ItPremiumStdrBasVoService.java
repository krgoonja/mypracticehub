package com.sorincorp.comm.premium.service;

import java.util.Map;
import java.util.TreeSet;

import com.sorincorp.comm.pcInfo.model.LivePremiumVO;

public interface ItPremiumStdrBasVoService {
	Map<String, TreeSet<LivePremiumVO>> getItPremiumStdrBasVo();
	
	TreeSet<LivePremiumVO> getItPremiumStdrBasVo(String groupKey);
	
	void setItPremiumStdrBasVo(Map<String, TreeSet<LivePremiumVO>> itPremiumStdrBasVo);
}
