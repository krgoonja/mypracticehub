package com.sorincorp.comm.itemprice.mapper;

import java.util.List;

import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingSelectVO;

public interface ItemPriceMatchingMapper {

	/**
	 * <pre>
	 * 처리내용: 조건에 맞는 ItemBL 값을 가져온다. (Live)
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 25.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itemPriceVO
	 * @return List<ItemPriceBlInfoVO>
	 */
	List<ItemPriceMatchingBlInfoVO> selectListItemBl(ItemPriceMatchingSelectVO itemPriceVO);
	
	/**
	 * <pre>
	 * 처리내용: 조건에 맞는 ItemBL 값을 가져온다. (케이지몰)
	 * </pre>
	 * @date 2023. 3. 16.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일				작성자	변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 3. 16.	  srec0067	최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itemPriceVO
	 * @return List<ItemPriceBlInfoVO>
	 */
	List<ItemPriceMatchingBlInfoVO> selectListItemBlByFixPrice(ItemPriceMatchingSelectVO itemPriceVO);
	
	/**
	 * <pre>
	 * 처리내용: 특정한 회사에 정해진 브랜드코드가 있는지 찾는다
	 * </pre>
	 * @date 2022. 3. 24.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 3. 24.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @return
	 */
	List<String> selectEnterpriseSpecifyBrand(String enterpriseNo);

	
	/**
	 * <pre>
	 * 처리내용: 조건에 맞는 Brand별 중량합계를 조회한다.
	 * </pre>
	 * @date 2023. 3. 30.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일				작성자	변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 3. 30.	  srec0067	최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itemPriceVO
	 * @return List<ItemPriceBlInfoVO>
	 */
	List<ItemPriceMatchingBlInfoVO> selectListItemBlByBrand(ItemPriceMatchingSelectVO itemPriceVO);
}
