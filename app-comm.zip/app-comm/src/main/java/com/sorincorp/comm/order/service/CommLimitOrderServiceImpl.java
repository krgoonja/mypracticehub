package com.sorincorp.comm.order.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.mapper.CommLimitOrderMapper;
import com.sorincorp.comm.order.model.CommBlceInfoVO;
import com.sorincorp.comm.order.model.CommLimitOrderSttusVO;
import com.sorincorp.comm.order.model.CommOrLimitOrderBasVO;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.comm.order.model.MbDlvrgBasVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * CommLimitOrderServiceImpl.java
 * 지정가 주문 공통 Service 구현체 클래스
 *
 * @version
 * @since 2023. 4. 26.
 * @author srec0049
 */
@Slf4j
@Service
public class CommLimitOrderServiceImpl implements CommLimitOrderService {

	/**
	 * 지정가 주문 Mapper
	 */
	@Autowired
	CommLimitOrderMapper commLimitOrderMapper;

	/** 메세지 Service */
	@Autowired
	private SMSService smsService;

	/** 주문 Service */
	@Autowired
	private CommOrderService commOrderService;

	/** 최종 잔액 조회 서비스 */
	@Autowired
	private CommFinalBlceCheckService commFinalBlceCheckService;

	/** Redis 수정 내역 전송을 위한 서비스 */
    @Autowired
    private CommLimitOrderRedisPubService commLimitOrderRedisPubService;
    /** websocket FO 수정 내역 전송을 위한 서비스 */
	@Autowired
	private CommFrontOrderWebsocketService commFrontOrderWebsocketService;
	/** websocket BO 수정 내역 전송을 위한 서비스 */
	@Autowired
	private CommDashboardWebsocketService commDashboardWebsocketService;

	/** Hst 적재를 위한 서비스 */
	@Autowired
	private CommonService commonService;


	/**
	 * 지정가 주문 번호로 해당 지정가 주문 내역 가져오기 [단일]
	 */
	@Override
	public CommOrLimitOrderBasVO selectCommOrLimitOrderBas(String limitOrderNo) throws Exception {
		// 지정가 주문 번호로 해당 지정가 주문 내역 가져오기 [단일]
		return commLimitOrderMapper.selectCommOrLimitOrderBas(limitOrderNo);
	}

	/**
	 * 지정가 주문 번호들로 해당 지정가 주문 내역 리스트 가져오기 [복수]
	 */
	@Override
	public List<CommOrLimitOrderBasVO> selectCommOrLimitOrderBasList(List<String> limitOrderNoList) throws Exception {
		return commLimitOrderMapper.selectCommOrLimitOrderBasList(limitOrderNoList);
	}

	/**
	 * 가격 도달 후 지정가 주문 시 부족한 멤버 정보 가져오기
	 */
	@Override
	public MbDlvrgBasVO selectOrMbEntrpsInfoByLimitOrder(String mberNo) throws Exception {
		// 가격 도달 후 지정가 주문 시 부족한 멤버 정보 가져오기
		return commLimitOrderMapper.selectOrMbEntrpsInfoByLimitOrder(mberNo);
	}

	/**
	 * 해당 지정가 주문 번호의 지정가 주문 상태 코드를 변경 [단일]
	 * [
	 *     10(미체결), 20(주문처리중), 30.체결, 31.부분 체결, 40(주문취소(본인)), 41(주문취소(관리자))
	 *   , 90(체결실패(선물 실패)), 91(체결실패(재고 부족)), 92(체결실패(잔액 부족)), 93(체결실패(당일 유효 시간 경과)), 94(체결실패(유효성 검사 실패)), 95(체결실패(기타))
	 * ]
	 */
	@Override
	public int updateCommLimitOrderSttusCode(String limitOrderNo, String limitOrderSttusCode,
			String limitOrderFailrResn, String lastChangerId, String orderNo, Integer orderWt) throws Exception {
		// 해당 지정가 주문 번호의 지정가 주문 상태 코드를 변경 [단일]
		return commLimitOrderMapper.updateCommLimitOrderSttusCode(
			CommLimitOrderSttusVO.builder()
				.limitOrderNo(limitOrderNo)
				.limitOrderSttusCode(limitOrderSttusCode)
				.limitOrderFailrResn(limitOrderFailrResn)
				.lastChangerId(lastChangerId)
				.orderNo(orderNo)
				.orderWt(orderWt)
				.build()
		);
	}

	/**
	 * 해당 지정가 주문 번호 리스트의 지정가 주문 상태 코드를 변경 [복수]
	 * [
	 *     10(미체결), 20(주문처리중), 30.체결, 31.부분 체결, 40(주문취소(본인)), 41(주문취소(관리자))
	 *   , 90(체결실패(선물 실패)), 91(체결실패(재고 부족)), 92(체결실패(잔액 부족)), 93(체결실패(당일 유효 시간 경과)), 94(체결실패(유효성 검사 실패)), 95(체결실패(기타))
	 * ]
	 */
	@Override
	public int updateCommLimitOrderSttusCode(List<String> limitOrderNoList, String limitOrderSttusCode,
			String limitOrderFailrResn, String lastChangerId, String orderNo, Integer orderWt) throws Exception {
		// 해당 지정가 주문 번호 리스트의 지정가 주문 상태 코드를 변경 [복수]
		return commLimitOrderMapper.updateCommLimitOrderSttusCode(
				CommLimitOrderSttusVO.builder()
				.limitOrderNoList(limitOrderNoList)
				.limitOrderSttusCode(limitOrderSttusCode)
				.limitOrderFailrResn(limitOrderFailrResn)
				.lastChangerId(lastChangerId)
				.orderNo(orderNo)
				.orderWt(orderWt)
				.build()
			);
	}

	/**
	 * 주문(O), 취소(C) 타입 전용 지정가 주문 정보 소켓 통신(송신), 수정에서는 해당 메소드 사용 하면 안됨
	 */
	@Override
	public void publishLimitOrder(String limitOrderNo, String publishType, boolean isApiFoCall, boolean isApiBoCall) {
		Map<String, Object> sendTarget = new HashMap<>();

		try {
			// publish 대상 data setting
			sendTarget.put("type", publishType);	// type : 주문 - O, 취소 (제거요청) - C
			sendTarget.put("limitOrderNo", limitOrderNo);

			// FO 구독
			commFrontOrderWebsocketService.publishLimitOrder(sendTarget, isApiFoCall);
			// BO dashboard 구독
			commDashboardWebsocketService.publishLimitOrder(limitOrderNo, isApiBoCall);
		} catch (Exception e) {
			log.error("[publishLimitOrder] " + ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 실패 상태 처리 이후 후처리
	 *  1) 지정가 주문 실패 sms 발송
	 *  2) FO, BO의 해당 지정가 주문 번호를 호가창에서 제거 요청
	 *  3) 주문_지정가 주문 기본 이력 정보 등록하기
	 * </pre>
	 * @date 2023. 5. 26.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 26.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param targetLimitOrderNo
	 * @param smsSendYn
	 * @param isApiFoCall
	 * @param isApiBoCall
	 * @throws Exception
	 */
	public void afterProcLimitOrderFail(String targetLimitOrderNo, String smsSendYn, boolean isApiFoCall,
			boolean isApiBoCall) throws Exception {
		if(smsSendYn != null && StringUtils.equals("Y", smsSendYn)) {
			// 지정가 주문 실패 sms 발송
			this.limitOrderFailSendSms(targetLimitOrderNo);
		}

		// FO, BO의 해당 지정가 주문 번호를 호가창에서 제거 요청 (취소: C) [지정가 주문 정보 소켓 통신(송신)]
		this.publishLimitOrder(targetLimitOrderNo, "C", true, true); // 취소 (제거요청)

		//쿠폰 리셋처리
		this.limitOrderCouponUpdate(targetLimitOrderNo, "LIMIT_SYSTEM");

		// 주문_지정가 주문 기본 이력 정보 등록하기
		this.insertOrLimitOrderBasHst(targetLimitOrderNo);

	}

	/**
	 * 지정가 주문 번호[단일] 지정가 주문 실패 시
	 */
	@Override
	public void limitOrderFail(String targetLimitOrderNo, String limitOrderSttusCode, String limitOrderFailrResn
			, String changeId, String orderNo, Integer orderWt
			, String smsSendYn, boolean isApiFoCall, boolean isApiBoCall) {
		try {
			// 해당 지정가 주문 번호의 지정가 주문 상태 코드를 변경 [단일]
			// [
			//  10(미체결), 20(주문처리중), 30.체결, 31.부분 체결, 40(주문취소(본인)), 41(주문취소(관리자))
			//  , 90(체결실패(선물 실패)), 91(체결실패(재고 부족)), 92(체결실패(잔액 부족)), 93(체결실패(당일 유효 시간 경과)), 94(체결실패(유효성 검사 실패)), 95(체결실패(기타))
			// ]
			int updateLimitOrderSttusCode = this.updateCommLimitOrderSttusCode(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn, changeId, orderNo, orderWt);
			log.warn("[limitOrderFail][단일] updateLimitOrderSttusCode : " + updateLimitOrderSttusCode);

			// 지정가 주문 실패 상태 처리 이후 후처리
			//  1) 지정가 주문 실패 sms 발송
			//  2) FO, BO의 해당 지정가 주문 번호를 호가창에서 제거 요청
			//  3) 주문_지정가 주문 기본 이력 정보 등록하기
			this.afterProcLimitOrderFail(targetLimitOrderNo, smsSendYn, isApiFoCall, isApiBoCall);
		} catch(Exception e) {
			String stacktrace = ExceptionUtils.getStackTrace(e);
			log.error("[limitOrderFail][단일] : " + stacktrace);
		}
	}

	/**
	 * 지정가 주문 번호[복수] 지정가 주문 실패 시
	 */
	@Override
	public void limitOrderFail(List<String> targetLimitOrderNoList, String limitOrderSttusCode,
			String limitOrderFailrResn, String changeId, String smsSendYn, boolean isApiFoCall, boolean isApiBoCall) {
		try {
			// 해당 지정가 주문 번호의 지정가 주문 상태 코드를 변경 [복수]
			// [
			//  10(미체결), 20(주문처리중), 30.체결, 31.부분 체결, 40(주문취소(본인)), 41(주문취소(관리자))
			//  , 90(체결실패(선물 실패)), 91(체결실패(재고 부족)), 92(체결실패(잔액 부족)), 93(체결실패(당일 유효 시간 경과)), 94(체결실패(유효성 검사 실패)), 95(체결실패(기타))
			// ]
			int updateLimitOrderSttusCode = this.updateCommLimitOrderSttusCode(targetLimitOrderNoList, limitOrderSttusCode, limitOrderFailrResn, changeId, null, null);
			log.warn("[limitOrderFail][복수] updateLimitOrderSttusCode : " + updateLimitOrderSttusCode);

			for(String targetLimitOrderNo : targetLimitOrderNoList) {
				// 지정가 주문 실패 상태 처리 이후 후처리
				//  1) 지정가 주문 실패 sms 발송
				//  2) FO, BO의 해당 지정가 주문 번호를 호가창에서 제거 요청
				//  3) 주문_지정가 주문 기본 이력 정보 등록하기
				this.afterProcLimitOrderFail(targetLimitOrderNo, smsSendYn, isApiFoCall, isApiBoCall);
			}
		} catch(Exception e) {
			String stacktrace = ExceptionUtils.getStackTrace(e);
			log.error("[limitOrderFail][복수] : " + stacktrace);
		}
	}

	/**
	 * 지정가 주문 실패 sms 발송 (템플릿 108)
	 */
	@Override
	public void limitOrderFailSendSms(String limitOrderNo) {
		try {
			// sms 데이터 조회
			Map<String, String> smsMap = commLimitOrderMapper.selectLimitOrderFailSmsInfo(limitOrderNo);
			if (null == smsMap) {
				throw new Exception("지정가 주문 데이터 조회 실패 : 지정가번호 "+ limitOrderNo);
			}

			SMSVO smsVO = new SMSVO();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));

			String encPhon = String.valueOf(smsMap.get("ordrrMoblphonNo"));
			if (StringUtils.isNotBlank(encPhon) && !encPhon.equals("null")) {
				log.debug("휴대전화 번호 복호화 전 ==================>" + encPhon);
				String decPhone = CryptoUtil.decryptAES256(encPhon);
				log.debug("휴대전화 번호 복호화 후 ==================>" + decPhone);
				/** 휴대전화 번호 셋팅 **/
				smsVO.setPhone(decPhone);
			}

//			smsVO.setPhone("test phon number");
			smsVO.setMberNo(smsMap.get("mberNo"));
			smsVO.setCommerceNtcnAt("Y"); // 커머스 알림 여부

			smsMap.put("templateNum", "108");
			smsMap.put("commerceNtcnCn", "지정가 주문 체결 실패"); // 커머스 알림 메시지
			smsMap.put("excpSndngOptnAt", ""); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다. (빈 값일 때 고객, 내부 모두 발송)

			smsService.insertSMS(smsVO, smsMap);

		} catch (Exception e) {
			log.error("지정가 주문 체결 실패 SMS 전송 실패 : "+ e.getMessage());
		}
	}

	/**
	 * 지정가 주문 취소 sms 발송 (템플릿 110 (주문 취소),128 (17:00,22:00 주문 자동 취소))
	 */
	@Override
	public void limitOrderCancelSendSms(String limitOrderNo, String batchType) {
		try {
			// sms 데이터 조회
			Map<String, String> smsMap = commLimitOrderMapper.selectLimitOrderCancelSmsInfo(limitOrderNo);
			if (null == smsMap) {
				throw new Exception("지정가 주문 데이터 조회 실패 : 지정가번호 "+ limitOrderNo);
			}

			SMSVO smsVO = new SMSVO();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));

			String encPhon = String.valueOf(smsMap.get("ordrrMoblphonNo"));
			if (StringUtils.isNotBlank(encPhon) && !encPhon.equals("null")) {
				log.debug("휴대전화 번호 복호화 전 ==================>" + encPhon);
				String decPhone = CryptoUtil.decryptAES256(encPhon);
				log.debug("휴대전화 번호 복호화 후 ==================>" + decPhone);
				/** 휴대전화 번호 셋팅 **/
				smsVO.setPhone(decPhone);
			}

//			smsVO.setPhone("test phon number");
			smsVO.setMberNo(smsMap.get("mberNo"));
			smsVO.setCommerceNtcnAt("Y"); // 커머스 알림 여부

			if(batchType.equals("Y")){
				smsMap.put("templateNum", "128");
				smsMap.put("commerceNtcnCn", "지정가 자동 주문 취소"); // 커머스 알림 메시지
			}else {
				smsMap.put("templateNum", "110");
				smsMap.put("commerceNtcnCn", "지정가 주문 취소"); // 커머스 알림 메시지
			}
			smsMap.put("excpSndngOptnAt", ""); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다. (빈 값일 때 고객, 내부 모두 발송)

			smsService.insertSMS(smsVO, smsMap);

		} catch (Exception e) {
			log.error("지정가 주문 체결 실패 SMS 전송 실패 : "+ e.getMessage());
		}
	}

	/**
	 * 지정가 주문 자동 취소
	 */
	@Override
	public List<String> limitOrderAutoCancel(String mberId, String entrpsNo, String limitOrderSttusCode, long cncAmt) {
		log.info("limitOrderAutoCancel ::: IN ");
		// 취소될 지정가 주문번호
		List<String> cancelLimitOrderNoList = new LinkedList<>();

		try {
			// 1. 대상 지정가 목록을 가져온다 (가장 최근 주문 기준으로 - 역순)
			List<CommOrLimitOrderBasVO> limitOrderList = commLimitOrderMapper.selectListLimitOrderAutoCancel(entrpsNo);

			if (CollectionUtils.isEmpty(limitOrderList)) {
				throw new Exception("미체결 지정가 주문이 존재하지 않습니다.");
			}

			// 해당 업체의 최종 잔고
			CommBlceInfoVO blceInfoVo = commFinalBlceCheckService.selectFinalBlceInfoBySetleMn(entrpsNo, "", "", cncAmt);
			long finalBlce = blceInfoVo.getFinalBlce();
			log.info("업체 : {}, 최초 잔고 : {}", entrpsNo, finalBlce);

			// 2. 상환 또는 출금하는 금액 만큼 지정가 주문을 취소 처리
			for (CommOrLimitOrderBasVO order : limitOrderList) {
				long advrcvAmount = order.getAdvrcvAmount(); // 예수금 (결제금액)
				if (advrcvAmount < 1) {
					log.error("취소 불가 지정가주문번호 : {}, 예수금 : {}", order.getLimitOrderNo(), advrcvAmount);
					continue;
				}

				// 취소 대상
				cancelLimitOrderNoList.add(order.getLimitOrderNo());

				// 취소한 금액 만큼 최종 잔고 증가
				finalBlce += advrcvAmount;

				// 목표 금액(출금, 상환)에 도달 했는지 체크
				if (finalBlce >= cncAmt) {
					break;
				}
			}// end for

			// 취소할 대상이 없으면 end
			if (CollectionUtils.isEmpty(cancelLimitOrderNoList)) {
				return cancelLimitOrderNoList;
			}

			// 취소 실행
			int totalCancelCnt = cancelLimitOrderNoList.size();
			int cnt = this.updateCommLimitOrderSttusCode(cancelLimitOrderNoList, limitOrderSttusCode, "자동취소", mberId, "", 0);
			if (cnt != totalCancelCnt) {
				log.warn("취소 예정 개수 : {}, 취소 주문 개수 : {}", totalCancelCnt, cnt);
			}

			// 취소된 지정가 주문 건별 후처리
			for (String cancelLimitOrderNo : cancelLimitOrderNoList) {
				for (CommOrLimitOrderBasVO order : limitOrderList) {
					if (!cancelLimitOrderNo.equals(order.getLimitOrderNo())) {
						continue;
					}

					// 취소 이력
					commLimitOrderMapper.insertOrLimitOrderBasHst(order.getLimitOrderNo());

					// 3. SMS 취소 문자 발송 (지정가 주문 건별)
					this.limitOrderCancelSendSms(cancelLimitOrderNo, "N");

					// 4. call redisPubService
					commLimitOrderRedisPubService.limitOrderMsgPublish(cancelLimitOrderNo, "D");

					// 5. call bo dashboard 호출 (외부호출용 메소드로)
					// 6. call fo dashboard 호출 (외부호출용 메소드로)
					this.publishLimitOrder(cancelLimitOrderNo, "C", true, true);
				}
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		log.info("limitOrderAutoCancel ::: OUT ");
		return cancelLimitOrderNoList;
	}

	/**
	 * 주문_지정가 주문 기본 이력 테이블 insert
	 */
	@Override
	public void insertOrLimitOrderBasHst(String limitOrderNo) throws Exception {
		commLimitOrderMapper.insertOrLimitOrderBasHst(limitOrderNo);
	}

	/**
	 * 지정가 주문취소시 사용된 쿠폰 리셋처리
	 */
	public boolean limitOrderCouponUpdate(String limitOrderNo, String lastChangId) throws Exception {

		boolean returnVal = false;
		Integer selectLimtOrderUsedUntPcCoupon = 0;
		Integer selectLimtOrderUsedDlvyCoupon = 0;
		List<CouponVO> selectLimtOrderUsedUntPcCouponList = new ArrayList<CouponVO>();
		List<CouponVO> selectLimtOrderUsedDlvyCouponList = new ArrayList<CouponVO>();

		try {
			//지정가 주문시 사용된 쿠폰 유무 확인 (단가, 배송비)
			selectLimtOrderUsedUntPcCoupon = commLimitOrderMapper.selectLimtOrderUsedUntPcCoupon(limitOrderNo);
			selectLimtOrderUsedDlvyCoupon = commLimitOrderMapper.selectLimtOrderUsedDlvyCoupon(limitOrderNo);

			//존재 시
			if(selectLimtOrderUsedUntPcCoupon > 0) {
				//지정가 주문번호로 사용된 쿠폰 리스트 조회 (20203.08.02 - 현재 단가할인만 조회)
				selectLimtOrderUsedUntPcCouponList = commLimitOrderMapper.selectLimtOrderUsedUntPcCouponList(limitOrderNo);
				//사용 쿠폰 리셋 및 HST 적재
				for(CouponVO couponVo : selectLimtOrderUsedUntPcCouponList ) {
					couponVo.setLastChangerId(lastChangId);
					commLimitOrderMapper.limtOrderUntPcCouponUpdate(couponVo);
					returnVal = commonService.insertTableHistory("CP_COUPON_ISU_BAS", couponVo);
				}
			}else if(selectLimtOrderUsedDlvyCoupon > 0){

				//지정가 주문번호로 사용된 쿠폰 리스트 조회 (20203.08.02 - 현재 배송비 할인만 조회)
				selectLimtOrderUsedDlvyCouponList = commLimitOrderMapper.selectLimtOrderUsedDlvyCouponList(limitOrderNo);

				for(CouponVO couponVo : selectLimtOrderUsedDlvyCouponList ) {
					couponVo.setCoupopnUseId(lastChangId);
//					couponVo.setcouponuse(lastChangId);
					commLimitOrderMapper.limtOrderDlvyCouponUpdate(couponVo);
					commLimitOrderMapper.insertEvCouponIsuHst(couponVo);
				}
			}else {	//미존재시
				returnVal = true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			log.error("CommLimitOrderServiceImpl limitOrderCouponUpdate Error : "+ e.getMessage());
			returnVal = false;
		}
		return returnVal;
	}


	/**
	 * 지정가 체결시 사용한 쿠폰정보 불러오기
	 */
	@Override
	public List<CouponVO> selectUsedCouponInfo(String limitOrderNo) throws Exception {
		List<CouponVO> vo = new ArrayList<>();
		int usedUntPcCouponCount = 0;
		int usedDlvyCouponCount = 0;

		try {
			//지정가 주문시 사용된 쿠폰 유무 확인 (단가, 배송비)
			usedUntPcCouponCount = commLimitOrderMapper.selectLimtOrderUsedUntPcCoupon(limitOrderNo);
			usedDlvyCouponCount = commLimitOrderMapper.selectLimtOrderUsedDlvyCoupon(limitOrderNo);

			//단가쿠폰 사용
			if(usedUntPcCouponCount > 0) {
				vo = commLimitOrderMapper.selectUsedUntPcCouponInfo(limitOrderNo);
			//배송비쿠폰사용
			} else if(usedDlvyCouponCount > 0){
				vo = commLimitOrderMapper.selectUsedDlvyCouponInfo(limitOrderNo);
			} else {
				return vo;
			}

		} catch (Exception e) {
			// TODO: handle exception
			log.error("CommLimitOrderServiceImpl selectUsedCouponInfo Error : "+ e.getMessage());
		}

		return vo;
	}

	/**
	 * 브랜드 재고 확인 후, 해당 브랜드의 지정가 주문건 취소 처리
	 */
	@Override
	public void getBlInvtry(String metalCode, String dstrctLclsfCode, int itmSn, String brandGroupCode
			, String brandCode, String sleMthdCode, int orderWt, int sleUnitWt, int onceSlePossWt
			, String reMainBlNo, String leftOverWtRetrunBlEmptyYn) throws Exception{

		OrderModel orderModel = new OrderModel();

		orderModel.setMetalCode(metalCode);
		orderModel.setItmSn(itmSn);
		orderModel.setDstrctLclsfCode(dstrctLclsfCode);
		orderModel.setBrandGroupCode(brandGroupCode);
		orderModel.setBrandCode(brandCode);
		orderModel.setSleMthdCode(sleMthdCode);
		orderModel.setOrderWt(orderWt);
		orderModel.setSleUnitWt(sleUnitWt);
		orderModel.setOnceSlePossWt(onceSlePossWt);
		orderModel.setReMainBlNo(reMainBlNo);
		// 소량구매일 경우, BL번호 넘겨 받도록 함
		if(StringUtils.isNotEmpty(orderModel.getReMainBlNo())) {
			orderModel.setSmlqyPurchsAt("Y");
		}

		List<OrderModel> sendingSMSList = new ArrayList<OrderModel>();

		if(StringUtils.equals("Y", orderModel.getSmlqyPurchsAt())) {
			// [소량구매] CASE
			// 주문된 BL의 소량 판매 재고 체크
			List<ItemPriceMatchingBlInfoVO> smlqyBlList = commOrderService.getOptimalBlList(orderModel.getEntrpsNo(), orderModel.getMetalCode(), orderModel.getItmSn(), orderModel.getDstrctLclsfCode()
					, orderModel.getBrandGroupCode(), orderModel.getBrandCode(), orderModel.getSleMthdCode(), orderModel.getOrderWt()
					, orderModel.getSleUnitWt(), orderModel.getOnceSlePossWt(), orderModel.getReMainBlNo(), "N", null, null, orderModel.getSmlqyPurchsAt());

			// 해당 BL 재고 소진 시, 모든 소량구매 지정가 주문건 취소처리
			if(smlqyBlList.size() == 0) {
				sendingSMSList.addAll(commLimitOrderMapper.getLimitOrderList(orderModel));
			}

		} else {
			// [일반구매] CASE
			//체결 전 지정가 주문 리스트 조회(판매된 브랜드, 브랜드 무관)
			List<OrderModel> getLimitOrderList = commLimitOrderMapper.getLimitOrderList(orderModel);

			//지정가 주문 업체번호로 최적 BL 탐색
			for(OrderModel vo : getLimitOrderList) {

				//판매된 브랜드 최적 BL 탐색
				List<ItemPriceMatchingBlInfoVO> chkBlList = commOrderService.getOptimalBlList(vo.getEntrpsNo(), orderModel.getMetalCode(), orderModel.getItmSn(), orderModel.getDstrctLclsfCode()
						, orderModel.getBrandGroupCode(), orderModel.getBrandCode(), orderModel.getSleMthdCode(), orderModel.getOrderWt()
						, orderModel.getSleUnitWt(), orderModel.getOnceSlePossWt(), null, "N", null, null, orderModel.getSmlqyPurchsAt());

				if(chkBlList.size() == 0 ) {

					if (vo.getBrandCode().equals(orderModel.getBrandCode())) {
						sendingSMSList.add(vo);
						continue;
					}
				}

				//브랜드 무관 최적 BL 탐색
				List<ItemPriceMatchingBlInfoVO> chkNoBrandBlList = commOrderService.getOptimalBlList(vo.getEntrpsNo(), orderModel.getMetalCode(), orderModel.getItmSn(), orderModel.getDstrctLclsfCode()
						, orderModel.getBrandGroupCode(), "0000000000", orderModel.getSleMthdCode(), orderModel.getOrderWt()
						, orderModel.getSleUnitWt(), orderModel.getOnceSlePossWt(), null, "N", null, null, orderModel.getSmlqyPurchsAt());

				//브랜드 무관 최적 BL 판매 가능 잔량 존재
				if(chkNoBrandBlList.size() == 0) {
					//브랜드 무관 지정가 주문건 취소처리
					if(vo.getBrandCode().equals("0000000000")) {
						sendingSMSList.add(vo);
					}
				}
			}
		}

		//지정가 주문 취소건 존재시
		if(sendingSMSList.size() > 0) {
			for(OrderModel vo : sendingSMSList ) {
				//지정가 주문 취소
				this.updateCommLimitOrderSttusCode(vo.getLimitOrderNo(), "91", "재고소진", "LIMIT_SYSTEM", null, vo.getOrderWt());
				//FO. BO 호가창 제거 요청
				//사용 쿠폰 리셋 처리
				//주문_지정가 주문 기본 이력 등록
				this.afterProcLimitOrderFail(vo.getLimitOrderNo(), "N", true, true);
				//지정가 주문 재고 소진 알림 문자 전송
				this.procSms(vo,"129");
			}
		}
	}

	/**
	 * <pre>
	 * 처리내용: 템플릿에 따라 SMS 전송을 처리한다.
	 * </pre>
	 * @date 2023. 10. 26.
	 * @author hyunjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 26.		hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 */
	private void procSms(OrderModel orderModel, String templateNum) throws Exception{
		try {
			SMSVO smsVO = new SMSVO();
			Map<String, String> smsMap = null;

			switch(templateNum) {
				case "129" :
					smsMap = new HashMap<>();
					smsMap = commLimitOrderMapper.selectLimitOrderNoStockSmsInfo(orderModel.getLimitOrderNo());
				default:
					log.error("Not found templateNum");
					break;
			}

			if(null == smsMap) {
				throw new Exception("지정가 주문 데이터 조회 실패 : 지정가번호 "+ orderModel.getLimitOrderNo());
			}else if(smsMap != null) {
				smsMap.put("templateNum", templateNum);

				if(StringUtils.equals(templateNum, "129")) {
					smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));

					String encPhon = String.valueOf(smsMap.get("ordrrMoblphonNo"));
					if (StringUtils.isNotBlank(encPhon) && !encPhon.equals("null")) {
						log.debug("휴대전화 번호 복호화 전 ==================>" + encPhon);
						String decPhone = CryptoUtil.decryptAES256(encPhon);
						log.debug("휴대전화 번호 복호화 후 ==================>" + decPhone);
						/** 휴대전화 번호 셋팅 **/
						smsVO.setPhone(decPhone);
					}
					smsMap.put("excpSndngOptnAt", ""); // 예외 발송 옵션 여부, N일 경우 SMS 수신자만 발송한다. (빈 값일 때 고객, 내부 모두 발송)
					smsService.insertSMS(smsVO, smsMap);
				}
			}

		} catch (Exception e) {
			log.error("[CommLimitOrderServiceImpl][procSms] : "+ e.getMessage());
		}
	}
}
