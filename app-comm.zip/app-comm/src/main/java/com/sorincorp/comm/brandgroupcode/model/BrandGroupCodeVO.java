package com.sorincorp.comm.brandgroupcode.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class BrandGroupCodeVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 6392598007002286052L;
	/**
	 * 메탈코드
	 */
	private String metalCode;
	/**
	 * 서브코드(브랜드코드)
	 */
	private String subCode;
	/**
	 * 코드명
	 */
	private String codeNm;
	/**
	 * 코드 상세명
	 */
	private String codeDetailNm;
	/**
	 * 코드 순서
	 */
	private int codeOrdr;

	/**
	 * 판매방식코드(01:LIVE, 02:고정가, 03:GTC 지정가)
	 */
	private String sleMthdCode;
}
