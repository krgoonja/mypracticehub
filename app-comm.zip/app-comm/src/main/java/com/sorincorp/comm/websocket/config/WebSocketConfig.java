package com.sorincorp.comm.websocket.config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.simp.stomp.StompSessionHandlerAdapter;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.messaging.SessionConnectedEvent;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

//@Configuration
//@EnableWebSocket	
//public class WebSocketConfig implements WebSocketConfigurer{
//	
//	@Override
//	public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
//		registry.addHandler(new WebSocketHandlerServiceImpl(),"/webSocketHandler")
//				//.addInterceptors(new HttpSessionHandshakeInterceptor())
//				.setAllowedOrigins("/*").withSockJS();
//	}
//	
//	public WebSocketContainerFactoryBean createWebSocketContainer() {
//		WebSocketContainerFactoryBean container = new WebSocketContainerFactoryBean();
//		container.setMaxTextMessageBufferSize(8192);
//		container.setMaxBinaryMessageBufferSize(8192);
//		return container;
//		
//	}
//	
//}

@Configuration
@EnableWebSocketMessageBroker	
public class WebSocketConfig extends StompSessionHandlerAdapter implements WebSocketMessageBrokerConfigurer{

	public List<StompHeaderAccessor> sessionHeaderList = Collections.synchronizedList(new ArrayList<>());
	
	@Override
	public void registerStompEndpoints(StompEndpointRegistry registry) {
		registry.addEndpoint("/websocket").setAllowedOriginPatterns("*").withSockJS();
	}
	
	@Override
	public void configureMessageBroker(MessageBrokerRegistry config) {
		//config.enableSimpleBroker("/");
		config.setApplicationDestinationPrefixes("/messageMapping");
	}
	
//	@EventListener
//	public void connectListener(SessionConnectedEvent event) {
//		StompHeaderAccessor headerAccessor = StompHeaderAccessor.wrap(event.getMessage());
//		sessionHeaderList.add(headerAccessor);
//	}
//	
//    @EventListener
//    public void disConnectListener(SessionDisconnectEvent event) {
//        StompHeaderAccessor headerAccessor = StompHeaderAccessor.wrap(event.getMessage());
//        sessionHeaderList.remove(headerAccessor);
//    }
}