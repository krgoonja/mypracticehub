package com.sorincorp.comm.order.model;

import java.util.List;

import lombok.Data;

/**
 * OrderEntrpsSetleMnVO.java
 * @version
 * @since 2022. 7. 1.
 * @author srec0049
 */
@Data
public class OrderEntrpsSetleMnVO {

	/**
	 * 증거금 총 사용 여부(증거금 신청 여부, 증거금 사용 여부, 증거금 해지 여부 체크)
	 */
	private String wrtmTotUseAt;

    /**
     * 전자상거래보증 또는 케이지크레딧 총 사용 여부(담보 보증 신청 여부, 담보 보증 사용 여부, 담보 보증 승인 여부 , 담보 보증 해지 여부 체크)
     */
    private String mrtggGrntyTotUseAt;

    /**
     * 증거금 신청 여부(화면단 별도 체크)
     */
    private String wrtmReqstAt;

    /**
     * 담보 보증 신청 여부(화면단 별도 체크)
     */
    private String mrtggGrntyReqstAt;

    /**
     * 연체 건수
     */
    private int arrrgCo;

    /**
     * 사고 건수
     */
    private int acdntCo;

    /**
     * 판매 단위 중량 (주문 가능 MIN 중량 및 주문 단위)
     */
    private int sleUnitWt;

    /**
     * 1회 구매 중량 한도 (주문 가능 MAX 중량)
     */
    private int oncePurchsWtLmt;

    /**
     * 1일 구매 중량 한도
     */
    private int onedePurchsWtLmt;

    /**
	 * 여신관리 패널티 연체 건수
	 */
	private int cdtlnManagePntArrrgCo;

	/**
	 * 여신관리 패널티 사고 건수
	 */
	private int cdtlnManagePntAcdntCo;

    /**
     * CD금리
     */
    private java.math.BigDecimal cdInrst;

    /**
     * CD 금리 사용 여부
     */
    private String cdInrstUseAt;

    /**
     * 담보보증 무이자 일수
     */
    private int mrtggGrntyNintrDaycnt;

    /**
     * 케이지트레이딩 가산금리
     */
    private java.math.BigDecimal mrtggGrntySorinsuprrAddiInrst;

    /**
     * 연간뱅킹데이
     */
    private int mrtggGrntyFyerBankingDaycnt;

    /**
     * 여신 구간
     */
    private int cdtlnSctn;

    /**
     * 담보 보증 허용 시작 기간
     */
    private int mrtggGrntyPermBeginPd;

    /**
     * 담보 보증 허용 상환 기간
     */
    private int mrtggGrntyPermRepyPd;

    /**
     * 업체 구매성향등급
     */
    private String purchsInclnGrad;

    /**
     * 업체 구매성향등급 명
     */
    private String purchsInclnGradNm;

    /**
     * 증거금 권한 비율(소수점)
     */
    private java.math.BigDecimal wrtmAuthorRateDcmlpoint;

    /**
     * 구매성향등급 전체 정보 리스트
     */
    private List<OrderPurchsInclnGradeVO> entrpsPurchsInclnGradeInfoAllList;

    /**
	 * LME 전일 종가
	 */
	private int endPcAgo;

	/**
	 * 구간 시작 금액
	 */
	private int sctnBeginAmount;

	/**
	 * 구간 종료 금액
	 */
	private int sctnEndAmount;

	/**
	 * 구간 평균 금액
	 */
	private int sctnAvrgAmount;

	/**
	 * 증거금 최소 결제 예정일 조건
	 */
	private int wrtmMummSetlePrarndeCnd;

	/**
     * 전자상거래보증 증권발급 수수료 보상 비율(소수점)
     */
    private java.math.BigDecimal mrtgggrntyScritsissuFeeCmpnstnRate;

    /**
     * 전자상거래보증 증권발급 수수료 보상 건당 인정 비율(소수점)
     */
    private java.math.BigDecimal mrtgggrntyScritsissuFeeCmpnstnCsbyRate;

    /**
     * 담보 보증 보험 요율(소수점)
     */
    private java.math.BigDecimal mrtggGrntyInsrncTariffDcmlpoint;

    /**
     * 여신 서비스 구분 코드
     */
    private String cdtlnSvcSeCode;

    /**
     * 여신 서비스 구분 코드(화면탭명용)
     */
    private String viewCdtlnSvcSeCode;

    /**
     * 여신 서비스 구분 명(화면탭명용)
     */
    private String viewCdtlnSvcSeNm;

    /**
     * 여신 서비스 구분 css class keyword
     */
    private String cdtlnSvcSeKeyForCss;

    /**
     * 총 여신 금리 퍼센트
     */
    private java.math.BigDecimal totCdtlnInrstPt;

    /**
	 * 보증 번호
	 */
	private String grntyNo;

	/**
	 * 업체 담보 계약 순번
	 */
	private int entrpsMrtggCntrctSn;

	/**
	 * 담보 보증 수수료 부담 주체 여부
	 */
	private String mrtggGrntyFeeBndMbyAt;

	/**
	 * 보증 기한 시작 일자
	 */
	private String grntyTmlmtBeginDe;

	/**
	 * 보증 기한 종료 일자
	 */
	private String grntyTmlmtEndDe;

	/**
     * 케이지크레딧 사용 여부(KZ CREDIT ON/OFF)
     */
   private String sorinCredtUseAt;

    /**
     * 여신 계약 번호(케이지크레딧에서 사용)
     */
   private String cdtlnCntrctNo;

   /**
    * 결제 수단 이월렛 사용 여부(평균가 견적)
   */
   private String setleMnEwalletUseAt;

   /**
    * 결제 수단 증거금 사용 여부(평균가 견적)
   */
   private String setleMnWrtmUseAt;

   /**
    * 결제 수단 여신 사용 여부(평균가 견적)
   */
   private String setleMnCdtlnUseAt;
   /**
    * 평균가 거래 금액 비율 코드
   */
   private String avrgpcDelngAmountRateCode;
   /**
    * 평균가 거래 금액 비율
   */
   private double avrgpcDelngAmountRate;
   /**
    * 세금 계산서 발행 시점 코드
   */
   private String avrgpcTaxBillIsuPnttmCode;

   /**
    *  부분 출고 상환 여부
    */
   private String partDlivyRepyAt;
}
