package com.sorincorp.comm.itemweight.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class ItemWeightVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 7700628763298894601L;
	private int itmSn;
	private int sleUnitWt;
	private int onceSlePossWt;
	private String sleUnitNm;
	private String subCode;
	private String codeNm;
	private String codeDetailNm;

}
