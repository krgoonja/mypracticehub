package com.sorincorp.comm.brandcode.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import com.sorincorp.comm.util.StringUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.brandcode.mapper.BrandCodeMapper;
import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.CacheUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BrandCodeServiceImple implements BrandCodeService {

	@Autowired
	private CacheUtil cacheUtil;

	@Autowired
	private BrandCodeMapper brandCodeMapper;

	@PostConstruct
	public void init(){
		cacheUtil.getCodeCache();
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 12.			srec0030			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	@Override
	public void initBrandCode() throws Exception {
		// TODO Auto-generated method stub
		BrandCodeVO vo = new BrandCodeVO();
		List<BrandCodeVO> brandCodeList = brandCodeMapper.getBrandCode(vo);
		cacheUtil.put("brandCodeList", brandCodeList);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 12.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandGroupCode
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<BrandCodeVO> getBrandCodeList(String brandGroupCode) throws Exception {
		return getBrandCodeListCmmn(brandGroupCode, false);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BrandCodeVO> getBrandCodeList(String brandGroupCode, boolean clickAt) throws Exception {
		return getBrandCodeListCmmn(brandGroupCode, clickAt);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BrandCodeVO> getBrandCodeList(String brandGroupCode, String entrpsNo) throws Exception {
		return getBrandCodeListCmmn(brandGroupCode, entrpsNo, false);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BrandCodeVO> getBrandCodeList(String brandGroupCode, String entrpsNo, boolean clickAt) throws Exception {
		return getBrandCodeListCmmn(brandGroupCode, entrpsNo, clickAt);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BrandCodeVO> getBrandCodeList(String metalCode, String brandGroupCode, String entrpsNo) throws Exception {
		return getBrandCodeListCmmn(metalCode, brandGroupCode, entrpsNo, false);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<BrandCodeVO> getBrandCodeList(String metalCode, String brandGroupCode, String entrpsNo, boolean clickAt) throws Exception {
		return getBrandCodeListCmmn(metalCode, brandGroupCode, entrpsNo, clickAt);
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<BrandCodeVO> getBrandOthersCodeList(String brandGroupCode) throws Exception {
		BrandCodeVO vo = new BrandCodeVO();
		vo.setBrandGroupCode(brandGroupCode);
		return brandCodeMapper.getBrandOthersCode(vo);
	}

	@Override
	public List<BrandCodeVO> getTopPriorRankBrandCodeList(String brandGroupCode) throws Exception {
		// TODO Auto-generated method stub
		List<BrandCodeVO> brandCodeList = (List<BrandCodeVO>)cacheUtil.getValue("brandCodeList");
		List<BrandCodeVO> brandCodeList2 = new ArrayList<BrandCodeVO>();

		if(brandCodeList == null) {
			initBrandCode();
			brandCodeList = (List<BrandCodeVO>)cacheUtil.getValue("brandCodeList");

			if(!"".equals(brandGroupCode)) {
				for(BrandCodeVO code : brandCodeList) {

					if(brandGroupCode.equals(code.getBrandGroupCode()) && brandCodeList2.isEmpty()) {
						//if(brandCodeList2.isEmpty()) {
						brandCodeList2.add(code);
						//}
					}
				}
			} else {
				//brandCodeList2 = brandCodeList;
				BrandCodeVO code = brandCodeList.get(0);
				brandCodeList2.add(code);
			}
		} else {

			if(!"".equals(brandGroupCode)) {
				for(BrandCodeVO code : brandCodeList) {

					if(brandGroupCode.equals(code.getBrandGroupCode()) && brandCodeList2.isEmpty()) {
						//if(brandCodeList2.isEmpty()) {
						brandCodeList2.add(code);
						//}
					}
				}
			} else {
				//brandCodeList2 = brandCodeList;
				BrandCodeVO code = brandCodeList.get(0);
				brandCodeList2.add(code);
			}
		}
		return brandCodeList2;
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 12.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandCodeList
	 * @return
	 * @throws Exception
	 */
	@Override
	public String getBrandCodeListStr(List<BrandCodeVO> brandCodeList, String val) throws Exception {
		// TODO Auto-generated method stub
		StringBuilder codeTaglibStr = new StringBuilder(StringUtils.EMPTY);

		codeTaglibStr.append("");
		codeTaglibStr.append(CommonConstants.COLONE);
//		codeTaglibStr.append("전체");
		codeTaglibStr.append(val);
		codeTaglibStr.append(CommonConstants.SEMI_COLONE);

		for(BrandCodeVO code : brandCodeList) {

			codeTaglibStr.append(code.getSubCode());
			codeTaglibStr.append(CommonConstants.COLONE);
			codeTaglibStr.append(code.getCodeNm());
			codeTaglibStr.append(CommonConstants.SEMI_COLONE);

		}

		return codeTaglibStr.toString();
	}
	
	/**
	 * <pre>
	 * 처리내용: getBrandCodeList 공통화
	 * </pre>
	 * @date 2024. 01. 12
	 * @author hyunjin0512
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 01. 12			hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param brandCodeList
	 * @return
	 * @throws Exception
	 */
	private List<BrandCodeVO> getBrandCodeListCmmn(String brandGroupCode, boolean clickAt ) throws Exception {
		List<BrandCodeVO> brandCodeList = (List<BrandCodeVO>)cacheUtil.getValue("brandCodeList");
		List<BrandCodeVO> brandCodeList2 = new ArrayList<BrandCodeVO>();

		if(brandCodeList == null) {
			initBrandCode();
			brandCodeList = (List<BrandCodeVO>)cacheUtil.getValue("brandCodeList");

			if(!StringUtil.isEmpty(brandGroupCode)) {
				for(BrandCodeVO code : brandCodeList) {

					if(brandGroupCode.equals(code.getBrandGroupCode())) {
						brandCodeList2.add(code);
					}
				}
			} else {
				brandCodeList2 = brandCodeList;
			}
		} else {

			if(!StringUtil.isEmpty(brandGroupCode)) {
				for(BrandCodeVO code : brandCodeList) {

					if(brandGroupCode.equals(code.getBrandGroupCode())) {
						brandCodeList2.add(code);
					}
				}
			} else {
				brandCodeList2 = brandCodeList;
			}
		}
		return brandCodeList2;
	}
	
	private List<BrandCodeVO> getBrandCodeListCmmn(String brandGroupCode, String entrpsNo, boolean clickAt ) throws Exception {
		List<BrandCodeVO> brandCodeList = (List<BrandCodeVO>)cacheUtil.getValue("brandCodeList");
		List<BrandCodeVO> brandCodeList2 = new ArrayList<BrandCodeVO>();
		Map<String, Object> params = new HashMap<String, Object>();

		if(entrpsNo != null && !"".equals(entrpsNo)) {
			params.put("brandGroupCode", brandGroupCode);
			params.put("entrpsNo", entrpsNo);
			if(clickAt) {
				params.put("clickbutton", 'Y');
			}else {
				params.put("clickbutton", 'N');
			}
			brandCodeList2 = brandCodeMapper.selectMbEntrpsSpcifyBrandRls(params);
		} else {
			if(brandCodeList == null) {
				initBrandCode();
				brandCodeList = (List<BrandCodeVO>)cacheUtil.getValue("brandCodeList");

				if(!"".equals(brandGroupCode)) {
					for(BrandCodeVO code : brandCodeList) {

						if(brandGroupCode.equals(code.getBrandGroupCode())) {
							brandCodeList2.add(code);
						}
					}
				} else {
					brandCodeList2 = brandCodeList;
				}
			} else {

				if(!"".equals(brandGroupCode)) {
					for(BrandCodeVO code : brandCodeList) {

						if(brandGroupCode.equals(code.getBrandGroupCode())) {
							brandCodeList2.add(code);
						}
					}
				} else {
					brandCodeList2 = brandCodeList;
				}
			}
		}

		return brandCodeList2;
	}
	
	private List<BrandCodeVO> getBrandCodeListCmmn(String metalCode, String brandGroupCode, String entrpsNo, boolean clickAt ) throws Exception {
		// TODO Auto-generated method stub
		List<BrandCodeVO> brandCodeList = (List<BrandCodeVO>)cacheUtil.getValue("brandCodeList");
		List<BrandCodeVO> brandCodeList2 = new ArrayList<BrandCodeVO>();
		Map<String, Object> params = new HashMap<String, Object>();

		if(entrpsNo != null && !"".equals(entrpsNo)) {
			params.put("metalCode", metalCode);
			params.put("brandGroupCode", brandGroupCode);
			params.put("entrpsNo", entrpsNo);
			if(clickAt) {
				params.put("clickbutton", 'Y');
			}else {
				params.put("clickbutton", 'N');
			}
			brandCodeList2 = brandCodeMapper.selectMbEntrpsSpcifyBrandRls(params);
		} else {
			if(brandCodeList == null) {
				initBrandCode();
				brandCodeList = (List<BrandCodeVO>)cacheUtil.getValue("brandCodeList");

				if(!"".equals(brandGroupCode)) {
					for(BrandCodeVO code : brandCodeList) {

						if(brandGroupCode.equals(code.getBrandGroupCode())) {
							brandCodeList2.add(code);
						}
					}
				} else {
					brandCodeList2 = brandCodeList;
				}
			} else {

				if(!"".equals(brandGroupCode)) {
					for(BrandCodeVO code : brandCodeList) {

						if(brandGroupCode.equals(code.getBrandGroupCode())) {
							brandCodeList2.add(code);
						}
					}
				} else {
					brandCodeList2 = brandCodeList;
				}
			}
		}

		return brandCodeList2;
	}
	

}
