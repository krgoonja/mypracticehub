package com.sorincorp.comm.order.service;

import java.util.List;

import com.sorincorp.comm.order.model.CommOrLimitOrderBasVO;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.comm.order.model.MbDlvrgBasVO;

/**
 * CommLimitOrderService.java
 * 지정가 주문 공통 Service 인터페이스
 *
 * @version
 * @since 2023. 4. 26.
 * @author srec0049
 */
public interface CommLimitOrderService {

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 번호로 해당 지정가 주문 내역 가져오기 [단일]
	 * </pre>
	 * @date 2023. 4. 26.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 4. 26.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param limitOrderNo
	 * @return
	 * @throws Exception
	 */
	public CommOrLimitOrderBasVO selectCommOrLimitOrderBas(String limitOrderNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 지정가 주문 번호들로 해당 지정가 주문 내역 리스트 가져오기 [복수]
	 * </pre>
	 * @date 2023. 5. 22.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 22.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param limitOrderNoList
	 * @return
	 * @throws Exception
	 */
	public List<CommOrLimitOrderBasVO> selectCommOrLimitOrderBasList(List<String> limitOrderNoList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 가격 도달 후 지정가 주문 시 부족한 멤버 정보 가져오기
	 * </pre>
	 * @date 2023. 5. 10.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @return
	 * @throws Exception
	 */
	public MbDlvrgBasVO selectOrMbEntrpsInfoByLimitOrder(String mberNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 해당 지정가 주문 번호의 지정가 주문 상태 코드를 변경 [단일]
	 * [
	 *     10(미체결), 20(주문처리중), 30.체결, 31.부분 체결, 40(주문취소(본인)), 41(주문취소(관리자))
	 *   , 90(체결실패(선물 실패)), 91(체결실패(재고 부족)), 92(체결실패(잔액 부족)), 93(체결실패(당일 유효 시간 경과)), 94(체결실패(유효성 검사 실패)), 95(체결실패(기타))
	 * ]
	 * </pre>
	 * @date 2023. 5. 2.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 2.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param limitOrderNo
	 * @param limitOrderSttusCode
	 * @param limitOrderFailrResn
	 * @param lastChangerId
	 * @param orderNo (30(체결),31(부분체결) 시에만 사용)
	 * @param orderWt (30(체결),31(부분체결) 시에만 사용)
	 * @return
	 * @throws Exception
	 */
	public int updateCommLimitOrderSttusCode(String limitOrderNo, String limitOrderSttusCode, String limitOrderFailrResn, String lastChangerId, String orderNo, Integer orderWt) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 해당 지정가 주문 번호 리스트의 지정가 주문 상태 코드를 변경 [복수]
	 * [
	 *     10(미체결), 20(주문처리중), 30.체결, 31.부분 체결, 40(주문취소(본인)), 41(주문취소(관리자))
	 *   , 90(체결실패(선물 실패)), 91(체결실패(재고 부족)), 92(체결실패(잔액 부족)), 93(체결실패(당일 유효 시간 경과)), 94(체결실패(유효성 검사 실패)), 95(체결실패(기타))
	 * ]
	 * </pre>
	 * @date 2023. 5. 2.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 2.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param limitOrderNoList
	 * @param limitOrderSttusCode
	 * @param limitOrderFailrResn
	 * @param lastChangerId
	 * @param orderNo (30(체결),31(부분체결) 시에만 사용)
	 * @param orderWt (30(체결),31(부분체결) 시에만 사용)
	 * @return
	 * @throws Exception
	 */
	public int updateCommLimitOrderSttusCode(List<String> limitOrderNoList, String limitOrderSttusCode, String limitOrderFailrResn, String lastChangerId, String orderNo, Integer orderWt) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문(O), 취소(C) 타입 전용 지정가 주문 정보 소켓 통신(송신), 수정에서는 해당 메소드 사용 하면 안됨
	 * </pre>
	 * @date 2023. 5. 3.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일				작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 3.			srec0053			최초작성
	 * 2023. 5. 26          srec0049            FO에서 COMM으로 위치 변경
	 * ------------------------------------------------
	 * @param limitOrderNo
	 * @param publishType
	 * @param isApiFoCall
	 * @param isApiBoCall
	 */
	public void publishLimitOrder(String limitOrderNo, String publishType, boolean isApiFoCall, boolean isApiBoCall);
	
	/**
	 * <pre>
	 * 처리내용: 지정가 주문 번호[단일] 지정가 주문 실패 시
	 * </pre>
	 * @date 2023. 5. 26.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 26.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param targetLimitOrderNo
	 * @param limitOrderSttusCode
	 * @param limitOrderFailrResn
	 * @param changeId
	 * @param orderNo
	 * @param orderWt
	 * @param smsSendYn
	 * @param isApiFoCall
	 * @param isApiBoCall
	 */
	public void limitOrderFail(String targetLimitOrderNo, String limitOrderSttusCode, String limitOrderFailrResn
			, String changeId, String orderNo, Integer orderWt
			, String smsSendYn, boolean isApiFoCall, boolean isApiBoCall);
	
	/**
	 * <pre>
	 * 처리내용: 지정가 주문 번호[복수] 지정가 주문 실패 시
	 * </pre>
	 * @date 2023. 5. 3.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 3.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param targetLimitOrderNoList
	 * @param limitOrderSttusCode
	 * @param limitOrderFailrResn
	 * @param changeId
	 * @param smsSendYn
	 * @param isApiFoCall
	 * @param isApiBoCall
	 */
	public void limitOrderFail(List<String> targetLimitOrderNoList, String limitOrderSttusCode, String limitOrderFailrResn, String changeId, String smsSendYn, boolean isApiFoCall, boolean isApiBoCall);

	/**
	 * <pre>
	 * 지정가 주문 실패 sms 발송
	 * </pre>
	 * @date 2023. 5. 2.
	 * @author srec0051
	 * @param limitOrderNo
	 * @throws Exception
	 */
	public void limitOrderFailSendSms(String limitOrderNo);

	/**
	 * <pre>
	 * 지정가 주문 취소 sms 발송
	 * 지정가 주문 자동 취소 (17:00,22:00) sms 발송 추가 (2023. 10. 18)
	 * </pre>
	 * @date 2023. 5. 18. 2023. 10. 18
	 * @author srec0051 	sein
	 * @param limitOrderNo
	 * @param batchType (Y:128 자동 주문 취소, N:110 주문 취소)
	 */
	public void limitOrderCancelSendSms(String limitOrderNo , String batchType);

	/**
	 * <pre>
	 * 지정가 주문 자동 취소
	 * </pre>
	 * @date 2023. 5. 11.
	 * @author srec0051
	 *@param mberId 취소요청자d
	 * @param entrpsNo 업체번호
	 * @param limitOrderSttusCode 호출 주체 (지정가주문상태코드 참조)
	 * @param cancelAmt 취소금액
	 * @return 취소되는 지정가 주문 번호
	 */
	public List<String> limitOrderAutoCancel(String mberId, String entrpsNo, String limitOrderSttusCode, long cancelAmt);
	
	/**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 기본 이력 테이블 insert
	 * </pre>
	 * @date 2023. 5. 26.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 26.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param limitOrderNo
	 * @throws Exception
	 */
	public void insertOrLimitOrderBasHst(String limitOrderNo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 지정가 주문취소시 사용된 쿠폰 리셋처리
	 * </pre>
	 * @date 2023. 8. 2.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 2.				hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param limitOrderNo
	 * @return
	 * @throws Exception
	 */
	public boolean limitOrderCouponUpdate(String limitOrderNo, String lastChangId) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 지정가 체결시 사용한 쿠폰정보 불러오기
	 * </pre>
	 * @date 2023. 8. 10.
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 10.				sumin			최초작성
	 * ------------------------------------------------
	 * @param String limitOrderNo
	 * @return
	 * @throws Exception
	 */
	public List<CouponVO> selectUsedCouponInfo (String limitOrderNo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 브랜드 재고 확인 후, 해당 브랜드의 지정가 주문건 취소 처리
	 * </pre>
	 * @date 2023. 10. 26.
	 * @author hyunjin0512
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 26.		hyunjin0512			최초작성
	 * ------------------------------------------------
	 * @param metalCode 금속 코드
	 * @param dstrctLclsfCode 권역 대분류 코드
	 * @param itmSn 아이템 순번
	 * @param brandGroupCode 브랜드 그룹 코드
	 * @param brandCode 브랜드 코드
	 * @param sleMthdCode 판매 방식 코드
	 * @param orderWt 주문 중량
	 * @param sleUnitWt 판매 단위 중량
	 * @param onceSlePossWt 1회 판매 가능 중량
	 * @param reMainBlNo 지정 BL 번호
	 * @param leftOverWtRetrunBlEmptyYn
	 * @return
	 * @throws Exception
	 */
	public void getBlInvtry(String metalCode, String dstrctLclsfCode, int itmSn, String brandGroupCode
							, String brandCode, String sleMthdCode, int orderWt, int sleUnitWt, int onceSlePossWt
							, String reMainBlNo, String leftOverWtRetrunBlEmptyYn) throws Exception;
}
