package com.sorincorp.comm.bsnInfo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class CdtlnInfoVO implements Serializable{
    
	private static final long serialVersionUID = 2849004139164064398L;

	/**
     * 적용 일자
     */
    private String applcDe; 
    /**
     * 전자상거래보증 증권발급 수수료 보상 비율
     */
    private double mrtgggrntyScritsissuFeeCmpnstnRate; 
    /**
     * 전자상거래보증 증권발급 수수료 보상 건당 인정 비율
     */
    private double mrtgggrntyScritsissuFeeCmpnstnCsbyRate; 
    /**
     * 전자상거래보증 케이지트레이딩 가산 금리
     */
    private double mrtgggrntySorinsuprrAddiInrst; 
    /**
     * 전자상거래보증 적용 일수
     */
    private int mrtgggrntyApplcDaycnt; 
    /**
     * 전자상거래보증 연간 뱅킹 일수
     */
    private int mrtgggrntyFyerBankingDaycnt; 
    /**
     * 전자상거래보증 MP수수료 비율
     */
    private double mrtgggrntyMpfeeRate; 
    /**
     * 대출보증 MP수수료 비율
     */
    private double longrntyMpfeeRate; 
    /**
     * 전자상거래보증 연체 이자 비율
     */
    private double mrtgggrntyArrgIntrRate; 
    /**
     * 여신관리 패널티 연체 건수
     */
    private int cdtlnManagePntArrrgCo; 
    /**
     * 여신관리 패널티 사고 건수
     */
    private int cdtlnManagePntAcdntCo; 
    /**
     * 삭제 일시
     */
    private String deleteDt; 
    /**
     * 삭제 여부
     */
    private String deleteAt; 
    /**
     * 최초 등록자 아이디
     */
    private String frstRegisterId; 
    /**
     * 최초 등록 일시
     */
    private String frstRegistDt; 
    /**
     * 최종 변경자 아이디
     */
    private String lastChangerId; 
    /**
     * 최종 변경 일시
     */
    private String lastChangeDt; 
    /**
     * 담보보증 무이자 일수
     */
    private int mrtgggrntyNintrDaycnt; 
    
}
