package com.sorincorp.comm.brandcode.mapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sorincorp.comm.brandcode.model.BrandCodeVO;

public interface BrandCodeMapper {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 12.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<BrandCodeVO> getBrandCode(BrandCodeVO vo) throws Exception;

	List<BrandCodeVO> getBrandOthersCode(BrandCodeVO vo) throws Exception;
	
	List<BrandCodeVO> selectMbEntrpsSpcifyBrandRls(Map<String, Object> params) throws Exception;

}
