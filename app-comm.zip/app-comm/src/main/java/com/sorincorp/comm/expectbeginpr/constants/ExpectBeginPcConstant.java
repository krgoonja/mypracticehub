package com.sorincorp.comm.expectbeginpr.constants;

public class ExpectBeginPcConstant {

	/** 사이트 구분 코드 */
	public enum SITE_SE_CODE {
		/** 케이지트레이딩 */
		SORIN("01")
		/** 조달청 */
		,SAROK("02");

		private String code;
		private SITE_SE_CODE(String code){
			this.code = code;
		}
		public String getCode() {
			return code;
		}
	}
	/** 가격 구분 코드 */
	public enum PC_SE_CODE {
		/** 예상가 */
		EXPECT_PC("01")
		/** 확정가 */
		,DCSN_PC("02");

		private String code;
		private PC_SE_CODE(String code){
			this.code = code;
		}
		public String getCode() {
			return code;
		}
	}
	/** 환율 구분 코드 */
	public enum EHGT_SE_CODE {
		/** 매매기준율 */
		TRDE_STDRT("01");

		private String code;
		private EHGT_SE_CODE(String code){
			this.code = code;
		}
		public String getCode() {
			return code;
		}
	}
}
