package com.sorincorp.comm.swagger.config;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sorincorp.comm.btb.comm.BtoBConstants;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@ConditionalOnExpression(value = "${swagger.enable:false}")
@Configuration
@EnableSwagger2
public class SwaggerConfig {
	
	/* B2BCNI 응답 APIKEY */
	@Value("${btb.comm.response.apiKey}")
	private String btbResApiKey;
	
	@Bean
	public Docket commDocket() {
		String groupName = "comm";
		return new Docket(DocumentationType.SWAGGER_2) 
					.select() 
					.apis(RequestHandlerSelectors.basePackage("com.sorincorp.comm")) 
					.paths(PathSelectors.ant("/comm/**"))
					.build() 
					.groupName(groupName) 
					.apiInfo(apiInfo());

	}
	
	@Bean
	public Docket apiDocket() {
		String groupName = "api";
		return new Docket(DocumentationType.SWAGGER_2) 
					.globalOperationParameters(parameterInfo())
					.select() 
					.apis(RequestHandlerSelectors.basePackage("com.sorincorp.api")) 
					.paths(PathSelectors.ant("/api/**"))
					.build() 
					.groupName(groupName) 
					.apiInfo(apiInfo());

	}
	
	@Bean
	public Docket batchDocket() {
		
		String groupName = "batch";
		return new Docket(DocumentationType.SWAGGER_2)
					.globalOperationParameters(parameterInfo())
					.select() 
					.apis(RequestHandlerSelectors.basePackage("com.sorincorp.batch")) 
					.paths(PathSelectors.ant("/batch/**"))
					.build() 
					.groupName(groupName) 
					.apiInfo(apiInfo());

	}
	
	@Bean
	public Docket boDocket() {
		String groupName = "bo";
		return new Docket(DocumentationType.SWAGGER_2) 
					.select() 
					.apis(RequestHandlerSelectors.basePackage("com.sorincorp.bo")) 
					.paths(PathSelectors.ant("/bo/**"))
					.build() 
					.groupName(groupName) 
					.apiInfo(apiInfo());

	}
	
	@Bean
	public Docket foDocket() {
		String groupName = "fo";
		return new Docket(DocumentationType.SWAGGER_2) 
					.select() 
					.apis(RequestHandlerSelectors.basePackage("com.sorincorp.fo")) 
					.paths(PathSelectors.ant("/fo/**"))
					.build() 
					.groupName(groupName) 
					.apiInfo(apiInfo());

	}
	
	@Bean
	public Docket moDocket() {
		String groupName = "mo";
		return new Docket(DocumentationType.SWAGGER_2) 
					.select() 
					.apis(RequestHandlerSelectors.basePackage("com.sorincorp.mo")) 
					.paths(PathSelectors.ant("/mo/**"))
					.build() 
					.groupName(groupName) 
					.apiInfo(apiInfo());

	}
	
	private ApiInfo apiInfo() { 
		
		return new ApiInfoBuilder() 
				.title("Sorincorp Application Api") 
				.description("Sorincorp project Web Application Api") 
				.version("1.0.0") 
				.license("Copyright Sorincorp") 
				.build(); 
		
	}
	
	private List<Parameter> parameterInfo(){
		
		Parameter parameterBuilder = new ParameterBuilder()
		        .name(BtoBConstants.BTB_RESPONSE_API_KEY)
		        .description("BTB CNI APIKEY")
		        .modelRef(new ModelRef("string"))
		        .defaultValue(new String(Base64.getEncoder().encode(btbResApiKey.getBytes())))
		        .parameterType("header")
		        .required(false)
		        .build();

        List<Parameter> globalParamters = new ArrayList<>();
        globalParamters.add(parameterBuilder);
        
        return globalParamters;
		        
	}

}
