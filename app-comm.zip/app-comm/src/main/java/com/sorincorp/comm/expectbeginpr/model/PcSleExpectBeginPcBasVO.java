package com.sorincorp.comm.expectbeginpr.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
@ToString
@EqualsAndHashCode(callSuper=false)
public class PcSleExpectBeginPcBasVO {

    /**
     * 적용 일자
    */
    private String applcDe;
    /**
     * 적용 시작 일시
     */
    private String validBeginDt;
    /**
     * 적용 종료 일시
     */
    private String validEndDt;
    /**
     * 금속코드
    */
    private String metalCode;
    /**
     * 판매 방식 코드
     */
    private String sleMthdCode;
    /**
     * 아이템 순번
     */
    private int itmSn;
    /**
     * 사이트 구분 코드
    */
    private String siteSeCode;
    /**
     * 가격 구분 코드
    */
    private String pcSeCode;
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 코드
     */
    private String brandCode;
    /**
     * 환율 가격
    */
    private BigDecimal ehgtPc;
    /**
     * 시작 원화 금액
    */
    private long beginWonAmount;
    /**
     * 시작 달러 금액
    */
    private BigDecimal beginDollarAmount;
    /**
     * 스프레드
    */
    private BigDecimal spread;
    /**
     * LME 가격
    */
    private BigDecimal lmePc;
    /**
     * 3개월 LME 가격
    */
    private BigDecimal threemonthLmePc;
    /**
     * 프리미엄 원화 금액
    */
    private long premiumWonAmount;
    /**
     * 프리미엄 달러 금액
    */
    private BigDecimal premiumDollarAmount;
    
    private long premiumStdrAmount;
    
    private long lastPremiumWonAmount;
    
    private BigDecimal lastPremiumDollarAmount;
    /**
     * LME 조정 계수
    */
    private BigDecimal lmeMdatCffcnt;
    /**
     * FX 조정 계수
    */
    private BigDecimal fxMdatCffcnt;
    /**
     * 조정 계수 프리미엄 원화 금액
    */
    private long mdatCffcntPremiumWonAmount;
    /**
     * 조정 계수 프리미엄 달러 금액
    */
    private BigDecimal mdatCffcntPremiumDollarAmount;
    
    /**
     * 프리미엄 사용자 입력 원화 금액
    */
    private long lastPremiumUserInputWonAmount;
    /**
     * 프리미엄 사용자 입력 달러 금액
    */
    private BigDecimal lastPremiumUserInputDollarAmount;
    /**
     * 삭제 일시
    */
    private Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private Timestamp lastChangeDt;
    /**
     * NDF 환율 일자
     */
    private String ndfDate;

}
