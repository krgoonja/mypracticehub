package com.sorincorp.comm.util;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Component;

/**
 * MessageUtil.java
 * @version
 * @since 2021. 5. 18.
 * @author srec0012
 */

@Component
public class MessageUtil {
    //private static MessageSourceAccessor message;
    private MessageSourceAccessor message;

    @Resource(name = "getMessageSourceAccessor")
    private MessageSourceAccessor messageSourceAccessor;

    @PostConstruct
    public void init() {
        //MessageUtil.message = messageSourceAccessor;
        this.message = messageSourceAccessor;
    }
	
	/**
	 * <pre>
	 * 코드에 해당하는 메시지를 반환한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param code
	 * @return 메시지 문자열
	 */
	public String getMessage(String code) {
		try {
			return message.getMessage(code);
		} catch (Exception e) {
			return e.toString();
		}
	}
	
	/**
	 * <pre>
	 * 코드에 해당하는 메시지를 반환한다. 없으면 defaultMessage를 반환한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param code
	 * @param defaultMessage
	 * @return
	 */
	public String getMessage(String code, String defaultMessage) {
		return message.getMessage(code, defaultMessage);
	}
	
	/**
	 * <pre>
	 * 코드에 해당하는 메시지에 인자를 매핑하여 반환한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param code
	 * @param args
	 * @return
	 */
	public String getMessage(String code, Object[] args) {
		return message.getMessage(code, args);
	}
	
	/**
	 * <pre>
	 * 코드에 해당하는 메시지에 인자를 매핑하여 반환한다. 없으면 defaultMessage를 반환한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param code
	 * @param args
	 * @param defaultMessage
	 * @return
	 */
	public String getMessage(String code, Object[] args, String defaultMessage) {
		return message.getMessage(code, args, defaultMessage);
	}
}
