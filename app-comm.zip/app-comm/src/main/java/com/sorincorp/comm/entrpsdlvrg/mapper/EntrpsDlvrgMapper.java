package com.sorincorp.comm.entrpsdlvrg.mapper;

import java.util.List;

import com.sorincorp.comm.entrpsdlvrg.model.EntrpsDlvrgVO;

public interface EntrpsDlvrgMapper {
	 /**
	 * <pre>
	 * 처리내용: 업체번호로 배송지 목록을 조회한다.
	 * </pre>
	 * @date 2021. 7. 13.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 13.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 */
	List<EntrpsDlvrgVO> getEntrpsDlvrgList(String entrpsNo);

}
