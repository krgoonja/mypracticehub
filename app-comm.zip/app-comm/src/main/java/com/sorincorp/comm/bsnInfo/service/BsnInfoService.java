package com.sorincorp.comm.bsnInfo.service;

import java.util.List;

import com.sorincorp.comm.bsnInfo.model.BsnInfoDetailVO;
import com.sorincorp.comm.bsnInfo.model.BsnInfoVO;
import com.sorincorp.comm.bsnInfo.model.CdtlnInfoVO;
import com.sorincorp.comm.bsnInfo.model.RestTermVO;
import com.sorincorp.comm.bsnInfo.model.RestdeFxLmeVO;
import com.sorincorp.comm.bsnInfo.model.RestdeVO;
import com.sorincorp.comm.bsnInfo.model.RltmEndTimeVO;
import com.sorincorp.comm.bsnInfo.model.WrtmStdrAmoutInfoVO;

public interface BsnInfoService {

	/**
	 * <pre>
	 * 현재일자 기준으로 영업관리 기본정보를 조회 한다.(LME 달력정보, 휴일관리, 이벤트 휴일, 영업관리 정보)
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param occrrncDe : 발생 일자 (yyyymmdd)
	 * @throws Exception
	 */
	public BsnInfoVO getBsnInfo(String occrrncDe) throws Exception;

	/**
	 * <pre>
	 * 현재일자 기준으로 금속코드를 입력하여 금속코드별 배송시간 및 사이드카 설정을 조회한다.
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode : 금속 코드
	 * @param occrrncDe : 발생 일자(yyyymmdd)
	 * @throws Exception
	 */
	public BsnInfoDetailVO getBsnInfoDetail(String occrrncDe, String metalCode) throws Exception;

	/**
	 * <pre>
	 * 당일의 휴일 유무를 조회한다 (실시간가)
	 * </pre>
	 * @date 2021. 11. 18.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 18.			srec0051			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public boolean isRestDeLive() throws Exception;

	/**
	 * <pre>
	 * 당일의 휴일 유무를 조회한다 (고정가)
	 * </pre>
	 * @date 2021. 11. 18.
	 * @author srec0051
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 18.			srec0051			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public boolean isRestDeFixed() throws Exception;
	
	/**
	 * <pre>
	 * 영업 이후의 실시간 영업 대기시간에 대한 정보를 조회
	 * </pre>
	 * @date 2021. 12. 14.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 14.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param nowDate
	 * @return
	 * @throws Exception
	 */
	public List<RestTermVO> getRestTermInfo(String nowDate) throws Exception;
	
	public List<RestTermVO> getRestTermInfoBySleMthd(String nowDate, String sleMthdCode) throws Exception;
	
	/**
	 * <pre>
	 * 조회 날짜의 FX, LME 휴일 여부를 조회한다.
	 * </pre>
	 * @date 2022. 1. 3.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 3.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param appleDe
	 * @return
	 * @throws Exception
	 */
	public RestdeFxLmeVO getRestdeFxLmeInfo(String appleDe) throws Exception;
	
	/**
	 * <pre>
	 * 입력한 날짜의 휴일 정보를 가져온다. (휴무시간 제외)
	 * </pre>
	 * @date 2022. 06. 16.
	 * @author srec0008
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 06. 16.		srec0064		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param nowDate
	 * @return
	 * @throws Exception
	 */
	public RestdeVO getRestdeInfoWithoutHvofTime(String nowDate) throws Exception;
	
	/**
	 * <pre>
	 * 현재일자 기준으로 여신관리 기본정보를 조회 한다.
	 * </pre>
	 * @date 2022. 7. 8.
	 * @author srec0061
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 7. 8.		srec0061		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param occrrncDe : 발생 일자 (yyyymmdd)
	 * @throws Exception
	 */
	public CdtlnInfoVO getCdtlnInfo(String occrrncDe) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 계약금(증거금) 기준 금액 정보를 조회한다
	 * </pre>
	 * @date 2022. 7. 22.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 22.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param occrrncDe
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	public WrtmStdrAmoutInfoVO getWrtmStdrAmoutMangeInfo(String occrrncDe, String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 메탈별 라이브, 고정가 운영여부 조회
	 * </pre>
	 * @date 2023. 8. 18.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 18.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	public boolean isRestDeByMetal(String metalCode, String sleMthdCode) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 영업종료 시간 조회
	 * </pre>
	 * @date 2023. 9. 26.
	 * @author srec0081
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 26.			srec0081			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public RltmEndTimeVO getRltmEndTime() throws Exception;

	public List<RltmEndTimeVO> getLiveOperTimeAll() throws Exception;
	
	/**
	 * <pre>
	  * 최근 휴무시간 조회
	  * </pre>
	  * @date 2023. 12. 15.
	  * @author bok3117
	  * @history 
	  * <pre>
	  * -------------------------------------------------------------------------
	  * 변경일				작성자			변경내용
	  * -------------------------------------------------------------------------
	  * 2023. 12. 15.		bok3117			최초작성
	  * -------------------------------------------------------------------------
	  * </pre>
	  * @return
	  * @throws Exception
	  */
	public RestdeVO getTodayTodayHvofTime() throws Exception;
}
