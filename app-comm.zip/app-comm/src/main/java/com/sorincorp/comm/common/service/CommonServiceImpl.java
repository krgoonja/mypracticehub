package com.sorincorp.comm.common.service;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.sorincorp.comm.common.mapper.CommonMapper;
import com.sorincorp.comm.common.model.BlSleSttusCodeChgVO;
import com.sorincorp.comm.invntry.service.InvntrySttusService;
import com.sorincorp.comm.order.service.CommLimitOrderService;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CommonServiceImpl implements CommonService {

	@Autowired
	CommLimitOrderService commLimitOrderService;
	
	@Autowired
	CommonMapper commonMapper;

	@Autowired
	InvntrySttusService invntrySttusService;

	private static final String[] IP_HEADER_CANDIDATES = { "X-Forwarded-For", "Proxy-Client-IP", "WL-Proxy-Client-IP", "HTTP_X_FORWARDED_FOR", "HTTP_X_FORWARDED", "HTTP_X_CLUSTER_CLIENT_IP",
			"HTTP_CLIENT_IP", "HTTP_FORWARDED_FOR", "HTTP_FORWARDED", "HTTP_VIA", "REMOTE_ADDR" };

	/**
	 * <pre>
	 * 처리내용: 컬럼 리스트를 가져온다.
	 * </pre>
	 *
	 * @date 2022. 6. 28.
	 * @author jdrttl
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 6. 28. jdrttl
	 *          최초작성 ------------------------------------------------
	 * @param objectName(TableName)
	 * @return
	 * @throws Exception
	 */
	public List<Map<String, String>> selectColumnList(String objectName) throws Exception {

		List<Map<String, String>> columnList = commonMapper.selectColumnList(objectName);

		return columnList;
	}

	/**
	 * <pre>
	 * 처리내용: 쿼리 실행
	 * </pre>
	 *
	 * @date 2022. 6. 28.
	 * @author jdrttl
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 6. 28. jdrttl
	 *          최초작성 ------------------------------------------------
	 * @param query
	 * @return
	 * @throws Exception
	 */
	public int customQueryExecute(String query) throws Exception {
		int result = 0;

		result = commonMapper.customQueryExecute(query);

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: HST 테이블 저장
	 * </pre>
	 *
	 * @date 2022. 6. 28.
	 * @author jdrttl
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 6. 28. jdrttl
	 *          최초작성 ------------------------------------------------
	 * @param String objectName Map<String,String> keyValues : 키:값 예 )
	 *               "ENTRPS_NO":"C0222"
	 * @return boolean
	 * @throws Exception
	 */
	public boolean insertTableHistory(String objectName, Map<String, String> keyValues) throws Exception {

		boolean returnVal = false;

		// PK키 파라메타 존재여부
		if (keyValues.size() == 0) {
			log.debug("PK 파라메타가 비어있습니다.");
			return returnVal;
		}

		// 테이블 존재 여부 확인
		int selectTableExist = commonMapper.selectTableExist(objectName);
		if (selectTableExist == 0) {
			log.debug("테이블이 존재 하지 않습니다 [" + objectName + "]");
			return returnVal;
		}

		// 컬럼 비교
		int selectTableEqual = commonMapper.selectTableEqual(objectName);
		if (selectTableEqual > 0) {
			log.debug("HST테이블에 컬럼이 없어 INSERT가 불가능 합니다 [" + objectName + "]");
			return returnVal;
		}

		List<Map<String, String>> selectColumnList = commonMapper.selectColumnList(objectName);

		String query = "INSERT INTO " + objectName + "_HST" + "\n" + "(" + "\n";

		String delim = "";
		for (Map<String, String> selectColumn : selectColumnList) {
			query += delim + selectColumn.get("COLUMN_NAME") + "\n";
			delim = ",";
		}

		query += ")" + "\n";
		query += "SELECT" + "\n";

		delim = "";
		List<String> primaryKeyList = new ArrayList<>();

		for (Map<String, String> selectColumn : selectColumnList) {
			query += delim + selectColumn.get("COLUMN_NAME") + "\n";
			delim = ",";
			if (selectColumn.get("PRIMARY_KEY").equals("Y")) {
				primaryKeyList.add(selectColumn.get("COLUMN_NAME"));
			}
		}

		if (primaryKeyList.size() == 0) {
			log.debug("[" + objectName + "] 해당 테이블에 선언된 PK가 없습니다.");
			return returnVal;
		}

		query += "FROM " + objectName + "\n";
		query += "WHERE 1 = 1 \n";
		int andQuery = 0;

		for (String primaryKey : primaryKeyList) {
			query += "AND " + primaryKey + " = '" + keyValues.get(primaryKey) + "' \n";
			andQuery++;
		}

		if (andQuery == 0) {
			log.debug("WHERE 절에 맞는 PK 조건이 없습니다.");
			return returnVal;
		}

		int cnt = commonMapper.customQueryExecute(query);

		if (cnt > 0) {
			returnVal = true;
		}

		return returnVal;

	}

	/**
	 * <pre>
	 * 처리내용: HST 테이블 저장
	 * </pre>
	 *
	 * @date 2022. 6. 28.
	 * @author jdrttl
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 6. 28. jdrttl
	 *          최초작성 ------------------------------------------------
	 * @param String objectName Object obj
	 * @return boolean
	 * @throws Exception
	 */
	public boolean insertTableHistory(String objectName, Object obj) throws Exception {

		boolean returnVal = false;

		// 테이블 존재 여부 확인
		int selectTableExist = commonMapper.selectTableExist(objectName);
		if (selectTableExist == 0) {
			log.debug("테이블이 존재 하지 않습니다 [" + objectName + "]");
			return returnVal;
		}

		// 컬럼 비교
		int selectTableEqual = commonMapper.selectTableEqual(objectName);
		if (selectTableEqual > 0) {
			log.debug("HST테이블에 컬럼이 없어 INSERT가 불가능 합니다 [" + objectName + "]");
			return returnVal;
		}

		List<Map<String, String>> selectColumnList = commonMapper.selectColumnList(objectName);

		String query = "INSERT INTO " + objectName + "_HST" + "\n" + "(" + "\n";

		String delim = "";
		for (Map<String, String> selectColumn : selectColumnList) {
			query += delim + selectColumn.get("COLUMN_NAME") + "\n";
			delim = ",";
		}

		query += ")" + "\n";
		query += "SELECT" + "\n";

		delim = "";
		List<String> primaryKeyList = new ArrayList<>();

		for (Map<String, String> selectColumn : selectColumnList) {
			query += delim + selectColumn.get("COLUMN_NAME") + "\n";
			delim = ",";
			if (selectColumn.get("PRIMARY_KEY").equals("Y")) {
				primaryKeyList.add(selectColumn.get("COLUMN_NAME"));
			} 
		}

		if (primaryKeyList.size() == 0) {
			return returnVal;
		}

		query += "FROM " + objectName + "\n";
		query += "WHERE 1 = 1 \n";
		int andQuery = 0;

		for (String primaryKey : primaryKeyList) {
			if (!StringUtil.isNull(getFieldValue(obj, UnderStrTocamel(primaryKey)))) {
				query += "AND " + primaryKey + " = '" + getFieldValue(obj, UnderStrTocamel(primaryKey)) + "' \n";
				andQuery++;
			}
		}

		if (andQuery == 0) {
			log.debug("WHERE 절에 맞는 PK 조건이 없습니다.");
			return returnVal;
		}

		int cnt = commonMapper.customQueryExecute(query);

		if (cnt > 0) {
			returnVal = true;
		}

		return returnVal;

	}

	/**
	 * <pre>
	 * 처리내용: HST 테이블 저장(PK 리스트를 커스텀으로 지정)
	 * </pre>
	 *
	 * @date 2022. 6. 28.
	 * @author jdrttl
	 * @history --------------------------------------------------- 변경일 작성자 변경내용
	 *          ---------------------------------------------------- 2023. 05. 19.
	 *          jdrttl 최초작성 ----------------------------------------------------
	 * @param String objectName : 테이블명 Map<String,String> keyValues : 키:값 예 )
	 *               "ENTRPS_NO":"C0222" List<String> primaryKeyList : 키리스트
	 * @return boolean
	 * @throws Exception
	 */
	public boolean insertTableHistory(String objectName, Map<String, String> keyValues, List<String> primaryKeyList) throws Exception {

		boolean returnVal = false;

		// PK키 파라메타 존재여부
		if (keyValues.size() == 0) {
			log.debug("PK 파라메타가 비어있습니다.");
			return returnVal;
		}

		// 테이블 존재 여부 확인
		int selectTableExist = commonMapper.selectTableExist(objectName);
		if (selectTableExist == 0) {
			log.debug("테이블이 존재 하지 않습니다 [" + objectName + "]");
			return returnVal;
		}

		// 컬럼 비교
		int selectTableEqual = commonMapper.selectTableEqual(objectName);
		if (selectTableEqual > 0) {
			log.debug("HST테이블에 컬럼이 없어 INSERT가 불가능 합니다 [" + objectName + "]");
			return returnVal;
		}

		List<Map<String, String>> selectColumnList = commonMapper.selectColumnList(objectName);

		String query = "INSERT INTO " + objectName + "_HST" + "\n" + "(" + "\n";

		String delim = "";
		for (Map<String, String> selectColumn : selectColumnList) {
			query += delim + selectColumn.get("COLUMN_NAME") + "\n";
			delim = ",";
		}

		query += ")" + "\n";
		query += "SELECT" + "\n";

		delim = "";

		for (Map<String, String> selectColumn : selectColumnList) {
			query += delim + selectColumn.get("COLUMN_NAME") + "\n";
			delim = ",";
		}

		if (primaryKeyList.size() == 0) {
			log.debug("[" + objectName + "] PK LIST 내용이 없습니다.");
			return returnVal;
		}

		query += "FROM " + objectName + "\n";
		query += "WHERE 1 = 1 \n";
		int andQuery = 0;

		for (String primaryKey : primaryKeyList) {
			query += "AND " + primaryKey + " = '" + keyValues.get(primaryKey) + "' \n";
			andQuery++;
		}

		if (andQuery == 0) {
			log.debug("WHERE 절에 맞는 PK 조건이 없습니다.");
			return returnVal;
		}

		int cnt = commonMapper.customQueryExecute(query);

		if (cnt > 0) {
			returnVal = true;
		}

		return returnVal;
	}

	/**
	 * <pre>
	 * 처리내용: HST 테이블 저장
	 * </pre>
	 *
	 * @date 2022. 6. 28.
	 * @author jdrttl
	 * @history --------------------------------------------------- 변경일 작성자 변경내용
	 *          ---------------------------------------------------- 2023. 05. 19.
	 *          jdrttl 최초작성 ----------------------------------------------------
	 * @param String objectName Object obj List<String> primaryKeyList : 키리스트
	 * @return boolean
	 * @throws Exception
	 */
	public boolean insertTableHistory(String objectName, Object obj, List<String> primaryKeyList) throws Exception {

		boolean returnVal = false;

		// 테이블 존재 여부 확인
		int selectTableExist = commonMapper.selectTableExist(objectName);
		if (selectTableExist == 0) {
			log.debug("테이블이 존재 하지 않습니다 [" + objectName + "]");
			return returnVal;
		}

		// 컬럼 비교
		int selectTableEqual = commonMapper.selectTableEqual(objectName);
		if (selectTableEqual > 0) {
			log.debug("HST테이블에 컬럼이 없어 INSERT가 불가능 합니다 [" + objectName + "]");
			return returnVal;
		}

		List<Map<String, String>> selectColumnList = commonMapper.selectColumnList(objectName);

		String query = "INSERT INTO " + objectName + "_HST" + "\n" + "(" + "\n";

		String delim = "";
		for (Map<String, String> selectColumn : selectColumnList) {
			query += delim + selectColumn.get("COLUMN_NAME") + "\n";
			delim = ",";
		}

		query += ")" + "\n";
		query += "SELECT" + "\n";

		delim = "";
		for (Map<String, String> selectColumn : selectColumnList) {
			query += delim + selectColumn.get("COLUMN_NAME") + "\n";
			delim = ",";
		}

		if (primaryKeyList.size() == 0) {
			return returnVal;
		}

		query += "FROM " + objectName + "\n";
		query += "WHERE 1 = 1 \n";
		int andQuery = 0;

		for (String primaryKey : primaryKeyList) {
			if (!StringUtil.isNull(getFieldValue(obj, UnderStrTocamel(primaryKey)))) {
				query += "AND " + primaryKey + " = '" + getFieldValue(obj, UnderStrTocamel(primaryKey)) + "' \n";
				andQuery++;
			}
		}

		if (andQuery == 0) {
			log.debug("WHERE 절에 맞는 PK 조건이 없습니다.");
			return returnVal;
		}

		int cnt = commonMapper.customQueryExecute(query);

		if (cnt > 0) {
			returnVal = true;
		}

		return returnVal;

	}

	/**
	 * Camel To Using Underscore orderNo > ORDER_NO
	 *
	 * @param str
	 * @return value
	 */
	public static String camelToUnderStr(String str) {
		String regex = "([a-z])([A-Z])";
		String replacement = "$1_$2";
		String value = "";

		value = str.replaceAll(regex, replacement).toUpperCase();
		return value;
	}

	/**
	 * Using Underscore To Camel ORDER_NO > orderNo
	 *
	 * @param str
	 * @return value
	 */
	public static String UnderStrTocamel(String str) {
		return JdbcUtils.convertUnderscoreNameToPropertyName(str);
	}

	/* 상위클래스 모두 조회 */
	@SuppressWarnings("unchecked")
	public <T> T getFieldValue(Object obj, String fieldName) {
		Objects.requireNonNull(obj);

		try {
			Field field = getFieldByName(obj, fieldName); // 4. 해당 필드 조회 후
			return (T) field.get(obj).toString(); // 5. get 을 이용하여 field value 획득
		} catch (IllegalAccessException e) {
			return null;
		}
	}

	public static <T> Field getFieldByName(T t, String fieldName) {
		Objects.requireNonNull(t);

		Field field = null;
		for (Field f : getAllFields(t)) {
			if (f.getName().equals(fieldName)) {
				field = f; // 2. 모든 필드들로부터 fieldName이 일치하는 필드 추출
				break;
			}
		}
		if (field != null) {
			field.setAccessible(true); // 3. 접근 제어자가 private 일 경우
		}
		return field;
	}

	public static <T> List<Field> getAllFields(T t) {
		Objects.requireNonNull(t);

		Class<?> clazz = t.getClass();
		List<Field> fields = new ArrayList<>();
		while (clazz != null) { // 1. 상위 클래스가 null 이 아닐때까지 모든 필드를 list 에 담는다.
			fields.addAll(Arrays.asList(clazz.getDeclaredFields()));
			clazz = clazz.getSuperclass();
		}
		return fields;
	}

	/**
	 * <pre>
	 * 처리내용: bl 판매상태변경
	 * </pre>
	 *
	 * @date 2022. 9. 02.
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 9. 02.
	 *          hyunjin05 최초작성 2022.10. 12. hyunjin05 blno, userid 2023.04. 20.
	 *          hyunjin05 sleInvntryUnsleBundleBnt , 판매 재고 미판매 번들 잔량 = 0 -> 판매완료 처리
	 *          hanjook blSleSttusCodeChgChoice (검증로직) 분리 및 return 값 으로 배치 실행 구조 2024.06.28
	 *          ------------------------------------------------
	 * @param query
	 * @return
	 * @throws Exception
	 */
	@Override
	public void blSleSttusCodeChg(String blNo, String userId) throws Exception {

		BlSleSttusCodeChgVO blSleSttusCodeChgVO;

		blSleSttusCodeChgVO = commonMapper.selectBlSleSttusCodeChgData(blNo);

		if (blSleSttusCodeChgVO != null && !"".equals(blSleSttusCodeChgVO.getBlNo())) {
//			if (blSleSttusCodeChgVO.getSmlqySleInvntryUnsleBundleBnt() > 0 
//					blSleSttusCodeChgVO);&& blSleSttusCodeChgVO.getSmlqySleFtrsAt().equals("N")
//					&& blSleSttusCodeChgVO.getSleInvntryUnsleBnt() < blSleSttusCodeChgVO.getCaculPermWtRate()) {
//				// 소량판매 재고 존재 & 소량판매 선물 x & 미판잔량 x (자투리 제외) --> bl 상태값 변경 스킵. 2024-06-26 hanjook
//			} else {
//				blSleSttusCodeChgVO.setLastChangerId(userId);
//				blSleSttusCodeChgChoice(
//			}			
			blSleSttusCodeChgVO.setLastChangerId(userId);
			
			blSleSttusCodeChgVO = blSleSttusCodeChgChoice(blSleSttusCodeChgVO);			
			
			//BL 판매상태(판매중)이 아닐 경우 지정가 주문 취소 처리 - 2023-10-26
			//소량판매 지정가 취소 예외 2024-06-26 
			if(!blSleSttusCodeChgVO.getSleSttusCode().equals("02") && !blSleSttusCodeChgVO.getSleSttusCode().equals("06")) {
				commonMapper.updateItBlSleSttus(blSleSttusCodeChgVO);
				commonMapper.insertItBlInfoBasHst(blSleSttusCodeChgVO.getBlNo());
				// 실시간 재고잔량 체크 메소드 호출
				invntrySttusService.invntrySttusMsgPublish();
				BlSleSttusCodeChgVO vo = new BlSleSttusCodeChgVO();
				//blNo로 정보 조회
				vo = commonMapper.selectItemInvntrySetupInfo(blSleSttusCodeChgVO);
				//최적BL 탐색 후 지정가 주문 취소처리
				commLimitOrderService.getBlInvtry(vo.getMetalCode(), vo.getDstrctLclsfCode(), Integer.parseInt(vo.getItmSn()), vo.getBrandGroupCode()
											, vo.getBrandCode(), "01", vo.getSleUnitWt()/1000, vo.getSleUnitWt()/1000, vo.getOnceSlePossWt()
											, "", "Y");
			}
			
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: bl 판매상태변경 (BO -> 재고 설정 -> 판매중 전용)
	 * </pre>
	 *
	 * @date 2024. 06. 28
	 * @author hanjook
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------
	 *          ------------------------------------------------
	 * @param query
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<String> blSleSttusCodeChgSel(List<String> blNoList, String sleSttusCode, String userId) throws Exception {
		
		BlSleSttusCodeChgVO blSleSttusCodeChgVO;
		
		List<String> updateList = new ArrayList<>(); 

		String blNo = "";
		
		for (int i = 0; i < blNoList.size(); i++) {			 
			blNo = blNoList.get(i);
			blSleSttusCodeChgVO = commonMapper.selectBlSleSttusCodeChgData(blNo);
			
			if (blSleSttusCodeChgVO != null && !"".equals(blSleSttusCodeChgVO.getBlNo())) {
//				if (blSleSttusCodeChgVO.getSmlqySleInvntryUnsleBundleBnt() > 0 
//						&& blSleSttusCodeChgVO.getSmlqySleFtrsAt().equals("N")
//						&& blSleSttusCodeChgVO.getSleInvntryUnsleBnt() < blSleSttusCodeChgVO.getCaculPermWtRate()) {
//					// 소량판매 재고 존재 & 소량판매 선물 x & 미판잔량 x (자투리 제외) --> bl 상태값 변경 스킵. 2024-06-26 hanjook
//				} else {
//					blSleSttusCodeChgVO.setLastChangerId(userId);
//					blSleSttusCodeChgChoice(blSleSttusCodeChgVO);
//				}			
				blSleSttusCodeChgVO.setLastChangerId(userId);
				
				// 판매중지, 판매완료인 경우 검증로직 x
				if (sleSttusCode.equals("03") || sleSttusCode.equals("05")) {
					blSleSttusCodeChgVO.setSleSttusCode(sleSttusCode);
					updateList.add(blSleSttusCodeChgVO.getBlNo());
				} else {
					// 검증로직
					blSleSttusCodeChgVO = blSleSttusCodeChgChoice(blSleSttusCodeChgVO);
					
					// 검증 결과 판매대기 일 시, 판매중으로 변경. (추가 ++ 판매중지 일 시 판매중으로 변경 가능)
					if (blSleSttusCodeChgVO.getSleSttusCode().equals("01") || blSleSttusCodeChgVO.getSleSttusCode().equals("02") || blSleSttusCodeChgVO.getSleSttusCode().equals("03")) {
						if (sleSttusCode.equals("02")) {
							blSleSttusCodeChgVO.setSleSttusCode("02");
							updateList.add(blSleSttusCodeChgVO.getBlNo());
						} 
					}
					
					if (blSleSttusCodeChgVO.getSleSttusCode().equals("06") || blSleSttusCodeChgVO.getSleSttusCode().equals("05")) {
						updateList.add(blSleSttusCodeChgVO.getBlNo());
					}
				}
				
				commonMapper.updateItBlSleSttus(blSleSttusCodeChgVO);
				commonMapper.insertItBlInfoBasHst(blSleSttusCodeChgVO.getBlNo());
				// 실시간 재고잔량 체크 메소드 호출
				invntrySttusService.invntrySttusMsgPublish();
				
				//BL 판매상태(판매중)이 아닐 경우 지정가 주문 취소 처리 - 2023-10-26
				//소량판매 지정가 취소 예외 2024-06-26 
				if(!blSleSttusCodeChgVO.getSleSttusCode().equals("02") || !blSleSttusCodeChgVO.getSleSttusCode().equals("06")) {
					BlSleSttusCodeChgVO vo = new BlSleSttusCodeChgVO();
					//blNo로 정보 조회
					vo = commonMapper.selectItemInvntrySetupInfo(blSleSttusCodeChgVO);
					//최적BL 탐색 후 지정가 주문 취소처리
					commLimitOrderService.getBlInvtry(vo.getMetalCode(), vo.getDstrctLclsfCode(), Integer.parseInt(vo.getItmSn()), vo.getBrandGroupCode()
												, vo.getBrandCode(), "01", vo.getSleUnitWt()/1000, vo.getSleUnitWt()/1000, vo.getOnceSlePossWt()
												, "", "Y");
				}				
			}			
		}		
		return updateList;		
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2023. 7. 10.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 09. 10.
	 *          jdrttl 최초작성 2023. 07. 10. srec0030 bl판매상태 변경 시 실시간재고잔량 공통메소드 호출 추가
	 *          ------------------------------------------------
	 * @param blSleSttusCodeChgVO
	 * @throws Exception
	 */
	public BlSleSttusCodeChgVO blSleSttusCodeChgChoice(BlSleSttusCodeChgVO blSleSttusCodeChgVO) throws Exception {

		// BL번호
		String blNo = blSleSttusCodeChgVO.getBlNo();
		// BL만기경과여부
		String blExpiryYn = blSleSttusCodeChgVO.getBlExpiryYn();
		// 소수점여부
		String decimalYn = blSleSttusCodeChgVO.getDecimalYn();
		// 선물환 관리번호
		String fshgManageNo = blSleSttusCodeChgVO.getFshgManageNo();
		// 판매상태코드
		String sleSttusCode = blSleSttusCodeChgVO.getSleSttusCode();
		// 선물환 관리번호 카운트
		int fshgManageNoCnt = blSleSttusCodeChgVO.getFshgManageNoCnt();
		// 통관여부
		String entrAt = blSleSttusCodeChgVO.getEntrAt();
		// 판매불가 사유코드
		String sleImprtyResn = "";
		// 선물 최초 수량
		String ftrsDelngLotOrgQy = blSleSttusCodeChgVO.getFtrsDelngLotOrgQy();
		// 선물환 최초 중량
		String fshgDlryOrgWt = blSleSttusCodeChgVO.getFshgDlryOrgWt();
		// 선물환 최초 체결 금액
		String fshgDelngDollarOrgAmount = blSleSttusCodeChgVO.getFshgDelngDollarOrgAmount();
		// po BL번호
		String poBlNo = blSleSttusCodeChgVO.getPoBlNo();
		// 선물 만기 -1 여부
		String ftrsExpiryYn = blSleSttusCodeChgVO.getFtrsExpiryYn();
		// 선물환 만기일-2 여부
		String fshgExpiryYn = blSleSttusCodeChgVO.getFshgExpiryYn();

		// EC 할당 잔량 번들 재고
		String ecAsgnBntBundleInvntry = blSleSttusCodeChgVO.getEcAsgnBntBundleInvntry();
		log.warn(">> ecAsgnBntBundleInvntry : " + ecAsgnBntBundleInvntry);
		
		// 판매 재고 미판매 번들 잔량
		String sleInvntryUnsleBundleBnt = blSleSttusCodeChgVO.getSleInvntryUnsleBundleBnt();
		// 창고 판매 미설정 번들 재고
		String wrhousSleUnsetupBundleInvntry = blSleSttusCodeChgVO.getWrhousSleUnsetupBundleInvntry();
		// 선물사 구분 코드(TCODE)
		String ftrsprofsSeCode = blSleSttusCodeChgVO.getFtrsprofsSeCode();
		// 선물처리여부 
		String ftrsProcessAt = blSleSttusCodeChgVO.getFtrsProcessAt();

		if (poBlNo == null || "".equals(poBlNo)) {
			// PO 정보 없을 경우 판매불가
			sleImprtyResn = "매입정보 미존재";

			blSleSttusCodeChgVO.setSleSttusCode("04");
			blSleSttusCodeChgVO.setSleImprtyResn(sleImprtyResn);

//			commonMapper.updateItBlSleSttus(blSleSttusCodeChgVO);
//			commonMapper.insertItBlInfoBasHst(blSleSttusCodeChgVO.getBlNo());
			
			// 실시간 재고잔량 체크 메소드 호출
//			invntrySttusService.invntrySttusMsgPublish();
			
//			return blSleSttusCodeChgVO;

			
		} else {

			// BL 판매상태코드 04(만기경과)로 업데이트
			if ("Y".equals(blExpiryYn) || "Y".equals(decimalYn) || !"Y".equals(entrAt) || ftrsDelngLotOrgQy == null || fshgDlryOrgWt == null || fshgDelngDollarOrgAmount == null
					|| (ftrsprofsSeCode == null || "".equals(ftrsprofsSeCode))) {
				if ("Y".equals(ftrsProcessAt)) {
					// 만기경과(판매중지) 상태가 아닌 BL만 업데이트
					if (!"04".equals(sleSttusCode) || ("04".equals(sleSttusCode) && "매입정보 미존재".equals(blSleSttusCodeChgVO.getSleImprtyResn()))) {
						log.debug("=========================STOP========================================");
						log.debug("BL_NO                 :" + blNo);
						log.debug("BL_SEL_STOP_YN        :" + blExpiryYn);
						log.debug("DECIMAL_YN            :" + decimalYn);
						log.debug("FSHG_MANAGE_NO        :" + fshgManageNo);
						log.debug("FSHG_MANAGE_NO_CNT    :" + fshgManageNoCnt);
						log.debug("ENTR_AT               :" + entrAt);
						log.debug("SLE_STTUS_CODE        :" + sleSttusCode);
						log.debug("SLE_IMPRTY_RESN_CODE  :" + sleImprtyResn);
						log.debug("FTRS_DELNG_LOT_ORG_QY :" + ftrsDelngLotOrgQy);
						log.debug("FSHG_DLRY_ORG_WT      :" + fshgDlryOrgWt);
						log.debug("FSHG_DELNG_DOLLAR_ORG_AMOUNT :" + fshgDelngDollarOrgAmount);
						log.debug("FTRS_SEL_STOP_YN      :" + ftrsExpiryYn);
						log.debug("FSHG_SEL_STOP_YN      :" + fshgExpiryYn);
						log.debug("FTRSPROFS_SE_CODE     :" + ftrsprofsSeCode);
						log.debug("=================================================================");
	
						if ("Y".equals(fshgExpiryYn) && "N".equals(ftrsExpiryYn)) {
							sleImprtyResn += "선물환 만기 도래예정";
						} else if ("N".equals(fshgExpiryYn) && "Y".equals(ftrsExpiryYn)) {
							sleImprtyResn += "선물 만기 도래예정";
						} else if ("Y".equals(ftrsExpiryYn) && "Y".equals(fshgExpiryYn)) {
							sleImprtyResn += "선물 선물환 만기 도래예정";
						} else if (ftrsprofsSeCode == null || "".equals(ftrsprofsSeCode)) {
							sleImprtyResn += "선물사 구분코드 미존재";
						} else {
							sleImprtyResn += "강제청산"; // 만기경과
						}
	
						if (!"Y".equals(entrAt)) {
							// 미통관
							if (!"".equals(sleImprtyResn)) {
								sleImprtyResn += ",";
							}
							sleImprtyResn += "미통관";
						}
	
	//					if ("".equals(fshgManageNo) || fshgManageNo == null || fshgManageNoCnt < 1) {
	//						if (!"".equals(sleImprtyResn)) {
	//							sleImprtyResn += ",";
	//						}
	//						// 선물환관리번호 불일치
	//						sleImprtyResn += "선물환관리번호 불일치";
	//					}
	
	//					if("".equals(ftrsThsexCntrctNo) || ftrsThsexCntrctNo == null) {
	//						if(!"".equals(sleImprtyResn)) {
	//							sleImprtyResn += ",";
	//						}
	//						//삼성선물계약번호 미존재
	//						sleImprtyResn += "삼성선물계약번호 미존재";
	//					}
	
						if ("Y".equals(decimalYn)) {
							if (!"".equals(sleImprtyResn)) {
								sleImprtyResn += ",";
							}
							// 선물환달러금액/선물환배부중량 나머지 소수점
							sleImprtyResn += "선물환달러금액/선물환배부중량 나머지 소수점";
						}
	
						if ("".equals(ftrsDelngLotOrgQy) || ftrsDelngLotOrgQy == null) {
							if (!"".equals(sleImprtyResn)) {
								sleImprtyResn += ",";
							}
							sleImprtyResn += "선물 최초 수량정보 미존재";
						}
	
						if ("".equals(fshgDlryOrgWt) || fshgDlryOrgWt == null) {
							if (!"".equals(sleImprtyResn)) {
								sleImprtyResn += ",";
							}
							sleImprtyResn += "선물 최초 중량정보 미존재";
						}
	
						if ("".equals(fshgDelngDollarOrgAmount) || fshgDelngDollarOrgAmount == null) {
							if (!"".equals(sleImprtyResn)) {
								sleImprtyResn += ",";
							}
							sleImprtyResn += "선물환 최초 체결 금액정보 미존재";
						}
						
						if (blSleSttusCodeChgVO.getSmlqySleInvntryUnsleBundleBnt() > 0 
								&& blSleSttusCodeChgVO.getSmlqySleFtrsAt().equals("N")) {
							// 소량판매 잔량 존재 시 && 소량판매 선물 없을 시, 미통관 BL 제외는 상태 -> 소량판매중
							if (!sleImprtyResn.contains("미통관")) {
								blSleSttusCodeChgVO.setSleSttusCode("06");
								blSleSttusCodeChgVO.setSleImprtyResn(sleImprtyResn);
							} else {
								blSleSttusCodeChgVO.setSleSttusCode("04");
								blSleSttusCodeChgVO.setSleImprtyResn(sleImprtyResn);
							}
						} else {
							blSleSttusCodeChgVO.setSleSttusCode("04");
							blSleSttusCodeChgVO.setSleImprtyResn(sleImprtyResn);
						}
						
	//					commonMapper.updateItBlSleSttus(blSleSttusCodeChgVO);
	//					commonMapper.insertItBlInfoBasHst(blSleSttusCodeChgVO.getBlNo());
	
						// 실시간 재고잔량 체크 메소드 호출
	//					invntrySttusService.invntrySttusMsgPublish();
						
					}
//				return blSleSttusCodeChgVO;
				}
			}

			// BL 판매상태코드 01(판매대기)로 업데이트
			if ("N".equals(blExpiryYn) && "N".equals(decimalYn) && "Y".equals(entrAt) && ftrsDelngLotOrgQy != null && fshgDlryOrgWt != null && fshgDelngDollarOrgAmount != null
					&& (ftrsprofsSeCode != null && !"".equals(ftrsprofsSeCode))) {
				// 만기경과(판매중지) 상태인 BL만 업데이트
				if ("04".equals(sleSttusCode)) {
					log.debug("=========================READY========================================");
					log.debug("BL_NO                 :" + blNo);
					log.debug("BL_EXPIRY_YN          :" + blExpiryYn);
					log.debug("DECIMAL_YN            :" + decimalYn);
					log.debug("FSHG_MANAGE_NO        :" + fshgManageNo);
					log.debug("FSHG_MANAGE_NO_CNT    :" + fshgManageNoCnt);
					log.debug("ENTR_AT               :" + entrAt);
					log.debug("SLE_STTUS_CODE        :" + sleSttusCode);
					log.debug("FTRSPROFS_SE_CODE     :" + ftrsprofsSeCode);
					log.debug("=================================================================");

					blSleSttusCodeChgVO.setSleSttusCode("01");
					blSleSttusCodeChgVO.setSleImprtyResn("");

//					commonMapper.updateItBlSleSttus(blSleSttusCodeChgVO);
//					commonMapper.insertItBlInfoBasHst(blSleSttusCodeChgVO.getBlNo());
//
//					// 실시간 재고잔량 체크 메소드 호출
//					invntrySttusService.invntrySttusMsgPublish();
					
//					return blSleSttusCodeChgVO;
				}
			}

			// BL 판매 상태 코드 02(판매 중) or BL 판매 상태 코드 04(판매불가)
			if ("02".equals(sleSttusCode) || "04".equals(sleSttusCode)) {
				// BL 판매상태 코드 05(판매완료)로 업데이트 : 판매 재고 미판매 번들 잔량 = 0 && 창고 판매 미설정 번들 재고 = 0
				if ("0".equals(ecAsgnBntBundleInvntry) && "0".equals(sleInvntryUnsleBundleBnt) && "0".equals(wrhousSleUnsetupBundleInvntry)) {
					blSleSttusCodeChgVO.setSleSttusCode("05");
//					commonMapper.updateItBlSleSttus(blSleSttusCodeChgVO);
//					commonMapper.insertItBlInfoBasHst(blSleSttusCodeChgVO.getBlNo());
//
//					// 실시간 재고잔량 체크 메소드 호출
//					invntrySttusService.invntrySttusMsgPublish();
					
//					return blSleSttusCodeChgVO;
				}
			}
			
			//BL 판매상태(판매중)이 아닐 경우 지정가 주문 취소 처리 - 2023-10-26
			//소량판매 지정가 취소 예외 2024-06-26 
//			if(!blSleSttusCodeChgVO.getSleSttusCode().equals("02") || !blSleSttusCodeChgVO.getSleSttusCode().equals("06")) {
//				BlSleSttusCodeChgVO vo = new BlSleSttusCodeChgVO();
//				//blNo로 정보 조회
//				vo = commonMapper.selectItemInvntrySetupInfo(blSleSttusCodeChgVO);
//				//최적BL 탐색 후 지정가 주문 취소처리
//				commLimitOrderService.getBlInvtry(vo.getMetalCode(), vo.getDstrctLclsfCode(), Integer.parseInt(vo.getItmSn()), vo.getBrandGroupCode()
//											, vo.getBrandCode(), "01", vo.getSleUnitWt()/1000, vo.getSleUnitWt()/1000, vo.getOnceSlePossWt()
//											, "", "Y");
//			}
		}

		return blSleSttusCodeChgVO;
	}

	// 최초 IP GET, ex)X-Forwared-For: <client>, <proxy 1>, <proxy 2>, proxy 유무에 따른
	// header ip 값 추출
	public String getClientIpAddressIfServletRequestExist() throws Exception {
		if (Objects.isNull(RequestContextHolder.getRequestAttributes())) {
			return "0.0.0.0";
		}

		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		for (String header : IP_HEADER_CANDIDATES) {
			String ipFromHeader = request.getHeader(header);
			if (Objects.nonNull(ipFromHeader) && ipFromHeader.length() != 0 && !"unknown".equalsIgnoreCase(ipFromHeader)) {
				String ip = ipFromHeader.split(",")[0];
				return ip;
			}
		}
		return request.getRemoteAddr();
	}
	
	/**
	 * <pre>
	 * 처리내용: 테이블 복사 
	 * </pre>
	 * @date 2024. 4. 08.
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 4. 08.				sumin				최초작성
	 * ------------------------------------------------
	 * @param query
	 * @return
	 * @throws Exception
	 */
	public boolean insertTableCopy(String objectName, List<String> chgKeyList,  List<String> oldValueList,  List<String> newValueList) throws Exception {

		boolean returnVal = false;
		
		// PK키 파라메타 존재여부
		if (chgKeyList.size() == 0) {
			log.debug("PK 파라메타가 비어있습니다.");
			return returnVal;
		}
		
		// PK키 파라메타 존재여부
		if (oldValueList.size() == 0 || newValueList.size() == 0) {
			log.debug("변경할 파라테가 없습니다.");
			return returnVal;
		}
		
		// 테이블 존재 여부 확인
		int selectTableExist = commonMapper.selectTableExist(objectName);
		
		if (selectTableExist == 0) {
			log.debug("테이블이 존재 하지 않습니다 [" + objectName + "]");
			return returnVal;
		}
		
		List<Map<String, String>> selectColumnList = commonMapper.selectColumnList(objectName);

		String query = "INSERT INTO " + objectName + "\n" + "(" + "\n";

		String delim = "";
		for (Map<String, String> selectColumn : selectColumnList) {
			if(selectColumn.get("IDNTY").equals("N")) {
				query += delim + selectColumn.get("COLUMN_NAME") + "\n";
				delim = ",";
			}
		}

		query += ")" + "\n";
		query += "SELECT" + "\n";
		delim = "";
		
		int andQuery = 0;
		
		delim = "";
		
		for(Map<String, String>  selectColumn : selectColumnList) {
			for (int i=0 ; i<chgKeyList.size(); i++) {
			//for(String chgCloumn : chgKeyList) {
				if(selectColumn.get("IDNTY").equals("N")) {		//Identity 컬럼 제외
					if(chgKeyList.get(i).equals(selectColumn.get("COLUMN_NAME"))) {
						query +=  delim + "\'"  + newValueList.get(i) + "\' AS "+ chgKeyList.get(i) + "\n";
						delim = ",";	
					} else {
						query += delim + selectColumn.get("COLUMN_NAME") + "\n";
						delim = ",";
					}
				}
			}
		}
		

		if (selectColumnList.size() == 0) {
			log.debug("[" + objectName + "] 변경할 값이 없습니다.");
			return returnVal;
		}

		query += "FROM " + objectName + "\n";
		query += "WHERE 1 = 1 \n";

		for (int j=0 ; j<oldValueList.size(); j++) {
			query += "AND " + chgKeyList.get(j) + " = '" + oldValueList.get(j) + "' \n";
			andQuery++;
		}

		if (andQuery == 0) {
			log.debug("WHERE 절에 맞는 조건이 없습니다.");
			return returnVal;
		}

		int cnt = commonMapper.customQueryExecute(query);

		if (cnt > 0) {
			returnVal = true;
		}

		return returnVal;

	}
}
