package com.sorincorp.comm.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.constants.ExceptionConstants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class FileUtil {
	
	private FileUtil() {
		log.debug(FileUtil.class.getSimpleName());
	}
	
	/**
	 * <pre>
	 * 파일을 이동한다.
	 * </pre>
	 * @date 2021. 6. 11.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 11.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param orgFile
	 * @param targetFile
	 * @throws Exception
	 */
	public static void move(File orgFile, File targetFile) throws Exception {
		if ( targetFile.isFile() ) {
			Files.delete(targetFile.toPath());
		}
		copy(orgFile, targetFile);
		Files.delete(orgFile.toPath());
	}
	
	/**
	 * <pre>
	 * 파일을 복사한다.
	 * </pre>
	 * @date 2021. 6. 11.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 11.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param orgFile
	 * @param targetFile
	 * @throws Exception
	 */
	public static void copy(File orgFile, File targetFile) throws Exception {
		if ( !targetFile.getParentFile().exists() ) {
			targetFile.getParentFile().mkdirs();
		}
		
		try ( FileInputStream inputStream = new FileInputStream(orgFile);
				FileOutputStream outputStream = new FileOutputStream(targetFile);
				FileChannel fcin = inputStream.getChannel();
				FileChannel fcout = outputStream.getChannel()) {
			long size = fcin.size();
			fcin.transferTo(0, size, fcout);
		} catch ( Exception e ) {
			log.error("파일 복사 오류", e);
			throw e;
		}
	}
	
	/**
	 * <pre>
	 * 파일을 삭제한다.
	 * </pre>
	 * @date 2021. 6. 11.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 11.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param targetFile
	 * @throws Exception
	 */
	public static void delete(File targetFile) throws Exception {
		Files.delete(targetFile.toPath());
	}
	
	/**
	 * <pre>
	 * 파일다운로드를 위해 파일을 읽어 HttpServletResponse 에 쓴다
	 * </pre>
	 * @date 2021. 6. 11.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 11.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param response
	 * @param file
	 */
	public static void writeFileToResponse(HttpServletResponse response, File file) {
		if ( !file.exists() ) {
			log.warn("파일 {} 이 존재하지 않음", file);
			return;
		}
		
		try ( OutputStream out = response.getOutputStream() ) {
			Path path = file.toPath();
			Files.copy(path, out);
			out.flush();
		} catch ( IOException e ) {
			log.error("writeFileToResponse 에러", e);
		}
	}
	
	/**
	 * <pre>
	 * 리퀘스트에서 이름에 해당하는 엑셀파일을 반환한다.
	 * </pre>
	 * @date 2021. 6. 11.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 11.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param mRequest
	 * @param name
	 * @return
	 * @throws Exception 
	 */
	public static MultipartFile getExcel(MultipartHttpServletRequest mRequest, String name) throws Exception {
		MultipartFile mFile = mRequest.getFile(name);
		String fileOrgName = mFile.getOriginalFilename();
		String ext = FilenameUtils.getExtension(fileOrgName);
		
		String[] fileFilter = { "xls", "xlsx" };
		Long fileSize = (long) (2 * 1024 * 1024);
		
		Boolean checkExe = true;
		for ( String ex : fileFilter ) {
			if ( ex.equalsIgnoreCase(ext) ) {
				checkExe = false;
			}
		}
		
		if ( checkExe ) {
			throw new Exception(ExceptionConstants.BAD_EXE_FILE_EXCEPTION);
		}
		
		if ( mFile.getSize() > fileSize ) {
			throw new Exception(ExceptionConstants.BAD_SIZE_FILE_EXCEPTION);
		}
		
		return mFile;
	}
	
	/**
	 * <pre>
	 * 사이트 업로드 루트 경로에 추가 경로 정보를 더한 경로를 반환한다.
	 * </pre>
	 * @date 2021. 6. 11.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 11.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param directories
	 * @return
	 */
	public static String getPath(String... directories) {
		StringBuilder path = new StringBuilder(CommonConstants.UPLOAD_PATH);
		path.append(getCombinedPath(directories));
		
		return path.toString();
	}
	
	/**
	 * <pre>
	 * 사이트 업로드 루트 경로에 업무구분과 추가 경로를 더한 임시 경로를 반환한다.
	 * </pre>
	 * @date 2021. 6. 11.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 11.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param directories
	 * @return
	 */
	public static String getTempPath(String... directories) {
		StringBuilder path = new StringBuilder(CommonConstants.UPLOAD_PATH);
		path.append(File.separator).append(CommonConstants.TEMP_PATH);
		path.append(getCombinedPath(directories));
		
		return path.toString();
	}
	
	/**
	 * <pre>
	 * 경로 정보를 받아 디렉토리 구분자를 더한 경로 문자열을 반환한다.
	 * gtCombinedPath("temp", "img", "common") -> "/temp/img/common"
	 * </pre>
	 * @date 2021. 6. 11.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 11.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param str
	 * @return
	 */
	public static String getCombinedPath(String... str) {
		StringBuilder path = new StringBuilder();
		for ( String d : str ) {
			path.append(File.separator).append(FileUtil.getAllowedFilePath(d));
		}
		
		return path.toString();
	}
	
	/**
	 * <pre>
	 * 폴더 내역 삭제. 안의 파일 정보까지 모든걸 삭제하는 로직 처리
	 * </pre>
	 * @date 2021. 6. 11.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 11.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param parentPath
	 * @throws IOException 
	 */
	public static void deleteFolder(String parentPath) throws IOException {
		File file = new File(parentPath);
		String childPath;
		File f;
		
		if (file.exists() ) {
			for ( String fileName : file.list() ) {
				childPath = parentPath + File.separator + fileName;
				f = new File(childPath);
				if ( !f.isDirectory() ) {
					Files.delete(f.toPath());
				} else {
					deleteFolder(childPath);
				}
			}
			file = new File(parentPath);
			Files.delete(file.toPath());
		}
	}
	
	/**
	 * <pre>
	 * 파일 읽어 문자열로 반환
	 * </pre>
	 * @date 2021. 6. 11.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 11.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public static String readFile(File file) throws IOException {
		StringBuilder sb = new StringBuilder();
		String line;
		
		if ( !file.exists() ) throw new FileNotFoundException();
		
		try (FileReader fr = new FileReader(file); BufferedReader br = new BufferedReader(fr);) {
			while ( (line = br.readLine()) != null ) {
				sb.append(line).append(System.lineSeparator());
			}
		} catch (Exception e) {
			log.error("파일 읽기 중 에러", e);
			throw e;
		}
		
		return sb.toString();
	}
	
	/**
	 * <pre>
	 * 파일이나 폴더 저장시 특수문자 경로 문자열 제거
	 * </pre>
	 * @date 2021. 6. 11.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 11.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param str
	 * @return
	 */
	public static String replaceFileNm(String str) {
		String reStr = str;
		reStr = reStr.replaceAll("&", "");
		reStr = reStr.replaceAll("!", "");
		reStr = reStr.replaceAll("#", "");
		reStr = reStr.replaceAll("$", "");
		reStr = reStr.replaceAll("%", "");
		reStr = reStr.replaceAll("^", "");
		reStr = reStr.replaceAll("~", "");
		reStr = reStr.replaceAll("`", "");
		reStr = reStr.replaceAll("'", "");
		reStr = reStr.replaceAll(";", "");
		
		return reStr;
	}
	
	/**
	 * <pre>
	 * 파일 결로명에서 허용하지 않은 문자열을 제거 하여 반환
	 * </pre>
	 * @date 2021. 6. 11.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 11.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param filePath
	 * @return
	 */
	public static String getAllowedFilePath(String filePath) {
		filePath = StringUtil.replaceAll(filePath, "../", "");
		filePath = StringUtil.replaceAll(filePath, "\\uc0", "");
		
		return filePath;
	}
}