package com.sorincorp.comm.it.service;

import com.sorincorp.comm.it.model.ItBsnManageBasVo;

public interface ItBsnManageBasVoService {
	
	ItBsnManageBasVo getItBsnManageBasVo();
}