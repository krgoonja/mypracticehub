package com.sorincorp.comm.message.model;

import java.io.Serializable;

import lombok.Data;

/** 알림톡 vo
 * KkoMsgVO.java
 * @version
 * @since 2021. 6. 21.
 * @author srec0041
 */
@Data
public class KkoMsgVO implements Serializable {
	/****** JAVA VO CREATE : KKO_MSG() ******/
    
	private String mberKndSeCode;
	
	private String mberNo;
	
	/**
     * 메시지 고유번호
    */
    private long msgKey;
    /**
     * 고객이 발급한 번호
    */
    private int serialNum;
    /**
     * 고객이 발급한 서브id
    */
    private String id;
    /**
     * 발송상태
    */
    private String status;
    /**
     * 수신할 핸드폰 번호
    */
    private String phone;
    /**
     * 송신자 전화번호
    */
    private String callback;
    /**
     * 메시지 전송시간 (미래시간 설정시 예약발송)
    */
    private String reqDate;
    /**
     * 송신 완료 시간
    */
    private String sentDate;
    /**
     * 이통사로부터 결과를 받은시간
    */
    private String rsltDate;
    /**
     * 결과 수신 받은 시간
    */
    private String reportDate;
    /**
     * 알림톡 결과수신 값
    */
    private String rslt;
    /**
     * 알림톡 실패시 메시지결과
    */
    private String msgRslt;
    /**
     * 전송완료후 최종 이통사정보
    */
    private String net;
    /**
     * 전송 메시지
    */
    private String msg;
    /**
     *  알림톡 템플릿 코드
    */
    private String templateCode;
    /**
     * 알림톡 강조표기 제목
    */
    private String templateTitle;
    /**
     * 알림톡 실패시 전송 메시지 타입 (SMS, LMS, MMS, NO)
    */
    private String failedType;
    /**
     * 알림톡 실패시 전송톡 제목
    */
    private String failedSubject;
    /**
     * 알림톡 실패시 전송 내용
    */
    private String failedMsg;
    /**
     * 알림톡 실패시 전송 이미지
    */
    private String failedImg;
    /**
     * 플러스친구 프로파일키
    */
    private String profileKey;
    /**
     * 알림톡 버튼타입 url
    */
    private String url;
    /**
     * 알림톡 버튼타입 text
    */
    private String urlButtonTxt;
    /**
     * 친구톡 이미지 경로
    */
    private String imgPath;
    /**
     * 친구톡 이미지 url
    */
    private String imgUrl;
    /**
     * 버튼그룹 데이터 json
    */
    private String buttonJson;
    /**
     * 친구톡 광고 표시여부
    */
    private String adFlag;
    /**
     * 친구톡 와이드 이미지 표시여부
    */
    private String wiFlag;
    /**
     * 알림톡 메시지내 포함된 가격
    */
    private String price;
    /**
     * 메시지내 가격의 통화단위
    */
    private String currencyType;
    /**
     * 
    */
    private String etc1;
    /**
     * 
    */
    private String etc2;
    /**
     * 
    */
    private String etc3;
    /**
     * 
    */
    private String etc4;
    /**
     * 
    */
    private String etc5;
    /**
     * 
    */
    private String etc6;
    
    /**
     *	메세지 제목
     */
    private String msgTitle;
}
