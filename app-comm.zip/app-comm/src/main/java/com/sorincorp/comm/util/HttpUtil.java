package com.sorincorp.comm.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import lombok.extern.slf4j.Slf4j;

/**
 * Http 요청/응답에 관한 유틸리티 Class
 * HttpUtil.java
 * @version
 * @since 2021. 5. 18.
 * @author srec0012
 */

@Slf4j
public class HttpUtil {

	private HttpUtil() {
		log.debug(HttpUtil.class.getSimpleName());
	}

    private static RequestAttributes getRequestAttribute() {
        return RequestContextHolder.getRequestAttributes();
    }

    /**
     *
     * <pre>
     * 처리내용: HttpServletRequest 객체를 반환한다.
     *         경우에 따라 컨트롤러나 서비스가 아니면 못가져오는 경우도 있으므로 사용을 지양할것
     * </pre>
     * @date 2021. 5. 18.
     * @author srec0012
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2021. 5. 18.			srec0012			최초작성
     * ------------------------------------------------
     * @return
     */
    public static HttpServletRequest getHttpServletRequest() {
        RequestAttributes requestAttributes = getRequestAttribute();

        if (requestAttributes != null) {
            return ((ServletRequestAttributes) requestAttributes).getRequest();
        } else {
            return null;
        }
    }

    /**
     *
     * <pre>
     * 처리내용: HttpServletResponse 객체를 반환한다.
     *         경우에 따라 컨트롤러나 서비스가 아니면 못가져오는 경우도 있으므로 사용을 지양할것
     * </pre>
     * @date 2021. 5. 18.
     * @author srec0012
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2021. 5. 18.			srec0012			최초작성
     * ------------------------------------------------
     * @return
     */
    public static HttpServletResponse getHttpServletResponse() {
        RequestAttributes requestAttributes = getRequestAttribute();

        if (requestAttributes != null) {
            return ((ServletRequestAttributes) requestAttributes).getResponse();
        } else {
            return null;
        }
    }

    /**
     *
     * <pre>
     * 처리내용: ajax 요청인지 반환
     * </pre>
     * @date 2021. 5. 18.
     * @author srec0012
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2021. 5. 18.			srec0012			최초작성
     * ------------------------------------------------
     * @param request
     * @return
     */
    public static boolean isAjax(HttpServletRequest request) {

        if ("XMLHttpRequest".equals(request.getHeader("x-requested-with"))) {
            return true;
        }

        return false;
    }

    /**
     *
     * <pre>
     * 처리내용: 클라이언트의 IP 반환
     * </pre>
     * @date 2021. 5. 18.
     * @author srec0012
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2021. 5. 18.			srec0012			최초작성
     * 2022. 5. 25.			jdrttl				변경
     * ------------------------------------------------
     * @param request
     * @return 아이피 문자열
     */
    public static String getClientIp(HttpServletRequest request) {
    	String ip = request.getHeader("X-Forwarded-For");

    	if (ip == null) ip = request.getHeader("Proxy-Client-IP");

    	if (ip == null) ip = request.getHeader("WL-Proxy-Client-IP");

    	if (ip == null) ip = request.getHeader("HTTP_CLIENT_IP");

    	if (ip == null) ip = request.getHeader("HTTP_X_FORWARDED_FOR");

    	if (ip == null) ip = request.getRemoteAddr();

    	return ip;
    }

    /**
     *
     * <pre>
     * 처리내용: 관리자 페이지 요청 여부를 반환
     * </pre>
     * @date 2021. 5. 18.
     * @author srec0012
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2021. 5. 18.			srec0012			최초작성
     * ------------------------------------------------
     * @param request
     * @return
     */
    public static boolean isAdminPage(HttpServletRequest request) {
        if (request.getRequestURI().startsWith("/admin/")) {
            return true;
        } else {
            return false;
        }
    }

    /**
     *
     * <pre>
     * 처리내용: 메소드 처리 내용을 기술한다.
     * </pre>
     * @date 2021. 5. 18.
     * @author srec0012
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2021. 5. 18.			srec0012			최초작성
     * ------------------------------------------------
     * @param url
     * @return
     */
    public static String getJsonByRestTemplate(String url) {
        RestTemplate template = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        MediaType mediaType = MediaType.APPLICATION_FORM_URLENCODED;
        headers.setContentType(mediaType);

        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
        ResponseEntity<String> responseEntity = template.exchange(url, HttpMethod.GET, entity, String.class);
        String result = responseEntity.getBody();

        return result;
    }

    /**
     *
     * <pre>
     * 처리내용: 스프링 RestTemplate를 이용하여 원격지의 XML를 읽어 반환한다.
     * </pre>
     * @date 2021. 5. 18.
     * @author srec0012
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2021. 5. 18.			srec0012			최초작성
     * ------------------------------------------------
     * @param url
     * @return
     */
    public static String getXmlByRestTemplate(String url) {
        RestTemplate template = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        MediaType mediaType = MediaType.APPLICATION_XML;
        headers.setContentType(mediaType);

        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
        ResponseEntity<String> responseEntity = template.exchange(url, HttpMethod.GET, entity, String.class);
        String result = responseEntity.getBody();

        return result;
    }

    /**
     *
     * <pre>
     * 처리내용: 스프링 RestTemplate를 이용하여 원격지의 XML를 charset으로 읽어 반환한다.
     * </pre>
     * @date 2021. 5. 18.
     * @author srec0012
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2021. 5. 18.			srec0012			최초작성
     * ------------------------------------------------
     * @param url
     * @param charset
     * @return
     */
    public static String getXmlByRestTemplate(String url, Charset charset) {
        RestTemplate template = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        MediaType mediaType = new MediaType("application", "xml", charset);
        headers.setContentType(mediaType);
        List<Charset> charsetList = new ArrayList<>();
        charsetList.add(charset);
        headers.setAcceptCharset(charsetList);

        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
        template.getMessageConverters().add(0, new StringHttpMessageConverter(charset));
        ResponseEntity<String> responseEntity = template.exchange(url, HttpMethod.GET, entity, String.class);
        String result = responseEntity.getBody();

        return result;
    }

    /**
     * <pre>
     * 처리내용: 스프링 RestTemplate를 이용하여 원격지의 text를 읽어 반환한다.
     * </pre>
     * @date 2021. 5. 18.
     * @author srec0012
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2021. 5. 18.			srec0012			최초작성
     * ------------------------------------------------
     * @param url
     * @return
     */
    public static String getTextByRestTemplate(String url) {
        RestTemplate template = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        MediaType mediaType = MediaType.TEXT_XML;
        headers.setContentType(mediaType);

        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
        ResponseEntity<String> responseEntity = template.exchange(url, HttpMethod.GET, entity, String.class);
        String result = responseEntity.getBody();

        return result;
    }

    /**
     * <pre>
     * 처리내용: 스프링 RestTemplate를 이용하여 원격지의 텍스트를 charset으로 읽어 반환한다.
     * </pre>
     * @date 2021. 5. 18.
     * @author srec0012
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2021. 5. 18.			srec0012			최초작성
     * ------------------------------------------------
     * @param url
     * @param charset
     * @return
     */
    public static String getTextByRestTemplate(String url, Charset charset) {
        RestTemplate template = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        MediaType mediaType = new MediaType("text", "xml", charset);
        headers.setContentType(mediaType);
        List<Charset> charsetList = new ArrayList<>();
        charsetList.add(charset);
        headers.setAcceptCharset(charsetList);

        HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
        template.getMessageConverters().add(0, new StringHttpMessageConverter(charset));
        ResponseEntity<String> responseEntity = template.exchange(url, HttpMethod.GET, entity, String.class);
        String result = responseEntity.getBody();

        return result;
    }

    private static final String [] LOCAL_IP =
        { "192.168.18.109",
          "192.168.18.110"
        };

    public static boolean isLocalServer() {
        boolean flag = false;
        String Ip = getServerIp();
        if(StringUtil.isEmpty(Ip)) {
            return flag;
        }

        for (String s : LOCAL_IP) {
            if (Ip.equals(s)) {
                flag = true;
            }
        }

        log.debug("현재 서버 IP address : " + Ip + "는 로컬 서버" + ((flag)?"입니다." : "가 아닙니다." ));
        return flag;
    }

    public static String getServerIp() {
        InetAddress ip;
        String ipAddr = "";
        try {
          ip = InetAddress.getLocalHost();
          ipAddr = ip.getHostAddress();
        } catch (UnknownHostException e) {
            log.error("서버IP를 알수 없는 예외가 발생하였습니다.");
        }
        return ipAddr;
    }

    /**
     *
     * <pre>
     * 처리내용: Exception StackTrace 메지시를 Request에 attributeName으로 attribute로 등록한다
     * </pre>
     * @date 2021. 9. 15.
     * @author srec0012
     * @history
     * ------------------------------------------------
     * 변경일					작성자				변경내용
     * ------------------------------------------------
     * 2021. 9. 15.			srec0012			최초작성
     * ------------------------------------------------
     * @param e
     */
    public static void setErrorMsgToRequestAttribute(String attributeName, Exception e) {
    	StringWriter errWriter = new StringWriter();
		e.printStackTrace(new PrintWriter(errWriter));
		getRequestAttribute().setAttribute(attributeName,errWriter.toString(), RequestAttributes.SCOPE_REQUEST);
    }

}
