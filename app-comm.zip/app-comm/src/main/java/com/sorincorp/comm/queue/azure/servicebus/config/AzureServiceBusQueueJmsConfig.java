package com.sorincorp.comm.queue.azure.servicebus.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.support.converter.MappingJackson2MessageConverter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.MessageType;

/**
 * AzureServiceBusQueueJmsConfig.java
 * Azure Service Bus Queue JMS 설정
 * 
 * @version
 * @since 2023. 4. 20.
 * @author srec0049
 */
@Configuration
public class AzureServiceBusQueueJmsConfig {
	
	/**
	 * <pre>
	 * 처리내용: 메시지를 json 형태로 변경한다, 보내고 받는 부분에 모두 사용
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0049			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@Bean
	@ConditionalOnMissingBean
	public MessageConverter jacksonJmsMsgConverter() {
		MappingJackson2MessageConverter converter = new MappingJackson2MessageConverter();
		converter.setTargetType(MessageType.TEXT);
		converter.setTypeIdPropertyName("_type");
		
		return converter;
	}
}
