package com.sorincorp.comm.bsnInfo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class BsnDlvyManageVO implements Serializable{
    
	private static final long serialVersionUID = 2849004139164064398L;

    /**
     * 자차 출고 요청 시작 일
    */
    private int manatmbDlivyRequstBeginDe;
    /**
     * 자차 출고 요청 종료 일
    */
    private int manatmbDlivyRequstEndDe;
    /**
     * 자차 당일 출고 마감 시간
    */
    private String manatmbTodayDlivyClosTime;
    /**
     * 케이지트레이딩 출고 요청 시작 일
    */
    private int sorinDlivyRequstBeginDe;
    /**
     * 케이지트레이딩 출고 요청 종료 일
    */
    private int sorinDlivyRequstEndDe;
    /**
     * 케이지트레이딩 당일 출고 마감 시간
    */
    private String sorinTodayDlivyClosTime;
    
}
