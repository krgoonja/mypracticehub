package com.sorincorp.comm.btb.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BtoBResEntity {


	/* 결과 코드 */
	private String resultcode;

	/* 결과 메세지 */
	private String message;

	/* 결과 데이터 */
	private Object response;

	/* 인터페이스 번호 */
	private int  intrfcNo;

	public BtoBResEntity(String resultcode, String message, Object response) {
		this.resultcode = resultcode;
		this.message = message;
		this.response = response;
	}



}
