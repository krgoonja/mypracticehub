package com.sorincorp.comm.itemweight.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.itemweight.mapper.ItemWeightMapper;
import com.sorincorp.comm.itemweight.model.ItemWeightVO;
import com.sorincorp.comm.util.CacheUtil;
import com.sorincorp.comm.util.StringUtil;

@Service
public class ItemWeightServiceImple implements ItemWeightService {

	@Autowired
	private CacheUtil cacheUtil;

	@Autowired
	private ItemWeightMapper itemWeightMapper;

	@PostConstruct
	public void init(){
		cacheUtil.getCodeCache();
	}

	@Override
	public void initItemWeightCode() throws Exception {
		// TODO Auto-generated method stub
		ItemWeightVO vo = new ItemWeightVO();
		List<ItemWeightVO> itemWeightCodeList = itemWeightMapper.getItemWeightCode(vo);
		cacheUtil.put("itemWeightCodeList", itemWeightCodeList);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ItemWeightVO> getItemWeightList(int itmSn) throws Exception {
		// TODO Auto-generated method stub
		List<ItemWeightVO> itemWeightCodeList = (List<ItemWeightVO>)cacheUtil.getValue("itemWeightCodeList");
		List<ItemWeightVO> itemWeightCodeList2 = new ArrayList<ItemWeightVO>();

		int sleUnitWt = 0;
		int onceSlePossWt = 0;
		int cnt = 0;
		int idx = 0;
		int weigth = 0;

		ItemWeightVO vo;

		if(itemWeightCodeList == null) {
			initItemWeightCode();
			itemWeightCodeList = (List<ItemWeightVO>)cacheUtil.getValue("itemWeightCodeList");

			if(itmSn != 0) {
				for(ItemWeightVO code : itemWeightCodeList) {

					if(itmSn == code.getItmSn()) {
						sleUnitWt = code.getSleUnitWt();
						onceSlePossWt = code.getOnceSlePossWt();

						if(onceSlePossWt > 0 && sleUnitWt > 0) {
							cnt = onceSlePossWt/sleUnitWt;

							for(int i=0;i<cnt;i++) {
								idx = i+1;

								weigth = idx * sleUnitWt;
								vo = new ItemWeightVO();
								vo.setSubCode(StringUtil.formatMoney(Integer.toString(weigth)));
								vo.setCodeNm(StringUtil.formatMoney(Integer.toString(weigth)));
								vo.setCodeDetailNm(StringUtil.formatMoney(Integer.toString(weigth)) + " " + code.getSleUnitNm());

								itemWeightCodeList2.add(i, vo);
							}
						}
					}
				}
			}
		} else {
			if(itmSn != 0) {
				for(ItemWeightVO code : itemWeightCodeList) {

					if(itmSn == code.getItmSn()) {
						sleUnitWt = code.getSleUnitWt();
						onceSlePossWt = code.getOnceSlePossWt();

						if(onceSlePossWt > 0 && sleUnitWt > 0) {
							cnt = onceSlePossWt/sleUnitWt;

							for(int i=0;i<cnt;i++) {
								idx = i+1;

								weigth = idx * sleUnitWt;
								vo = new ItemWeightVO();
								vo.setSubCode(StringUtil.formatMoney(Integer.toString(weigth)));
								vo.setCodeNm(StringUtil.formatMoney(Integer.toString(weigth)));
								vo.setCodeDetailNm(StringUtil.formatMoney(Integer.toString(weigth)) + " " + code.getSleUnitNm());

								itemWeightCodeList2.add(i, vo);
							}
						}
					}
				}
			}
		}
		return itemWeightCodeList2;
	}

	@Override
	public String getItemWeightListStr(List<ItemWeightVO> itemWeightList, String val) throws Exception {
		// TODO Auto-generated method stub
		StringBuilder codeTaglibStr = new StringBuilder(StringUtils.EMPTY);

		codeTaglibStr.append("");
		codeTaglibStr.append(CommonConstants.COLONE);
		//codeTaglibStr.append("선택");
		codeTaglibStr.append(val);
		codeTaglibStr.append(CommonConstants.SEMI_COLONE);

		for(ItemWeightVO code : itemWeightList) {

			codeTaglibStr.append(code.getSubCode());
			codeTaglibStr.append(CommonConstants.COLONE);
			codeTaglibStr.append(code.getCodeNm());
//			codeTaglibStr.append(code.getCodeDetailNm());
			codeTaglibStr.append(CommonConstants.SEMI_COLONE);

		}

		return codeTaglibStr.toString();
	}

	/**
	 * <pre>
	 * 처리내용: 아이템의 허용 중량 비율을 가져 온다.
	 * </pre>
	 * @date 2022. 12. 9.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 9.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 * @throws Exception
	 */
	public int getItmMinToleranceRate(int itmSn) throws Exception {
		return itemWeightMapper.getItmMinToleranceRate(itmSn);
	}	

}
