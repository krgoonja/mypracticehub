package com.sorincorp.comm.bsnInfo.model;

import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.PositiveOrZero;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class WrtmStdrAmoutInfoVO extends CommonVO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6008130426504686626L;
	
	/**
	 * 증거금 기준 순번
	 */
	private String wrtmStdrSn;
	
	/**
	 * 금속 코드
	 */
	private String metalCode;
	
	/**
	 * 금속 코드명
	 */
	private String metalNm;
	
	/**
	 * 적용 일자
	 */
	private String applcDe;
	
	/**
	 * 구간 기준 시작 금액
	 */
	private int sctnStdrBeginAmount;
	
	/**
	 * 구간 기준 종료 금액
	 */
	private int sctnStdrEndAmount;
	
	/**
	 * 구간 기준 증가 금액 (구간갭)
	 */
	private int sctnStdrIncrsAmount; 
	
	/**
	 * 구매 성향 1단계 비율
	 */
	private String purchsIncln1StepRate;
	
	/**
	 * 구매 성향 2단계 비율
	 */
	private String purchsIncln2StepRate;
	
	/**
	 * 구매 성향 3단계 비율
	 */
	private String purchsIncln3StepRate;
	
	/**
	 * 구매 성향 4단계 비율
	 */
	private String purchsIncln4StepRate;
	
	/**
	 * 비고
	 */
	private String rm;
	
	/**
	 * 구간 시작 금액
	 */
	private int sctnBeginAmount;
	
	/**
	 * 구간 종료 금액
	 */
	private int sctnEndAmount;
	
	/**
	 * 구간 평균 금액
	 */
	private int sctnAvrgAmount;
	
	/**
	 * 구매 성향 1단계 금액
	 */
	private int purchsIncln1StepAmount;
	
	/**
	 * 구매 성향 2단계 금액
	 */
	private int purchsIncln2StepAmount;
	
	/**
	 * 구매 성향 3단계 금액
	 */
	private int purchsIncln3StepAmount;
	
	/**
	 * 구매 성향 4단계 금액
	 */
	@Digits(integer=9, fraction = 0, message="구간 성향 4단계 금액 최대 입력값은 9자리 입니다.")
	@PositiveOrZero
	private int purchsIncln4StepAmount;
	
	/**
	 * 구매 성향 1단계 시작 비율
	 */
	private int purchsIncln1StepStartRate;
	
	/**
	 * 구매 성향 1단계 종료 비율
	 */
	private int purchsIncln1StepEndRate;
	
	/**
	 * 구매 성향 2단계 시작 비율
	 */
	private int purchsIncln2StepStartRate;
	
	/**
	 * 구매 성향 2단계 종료 비율
	 */
	private int purchsIncln2StepEndRate;
	
	/**
	 * 구매 성향 3단계 시작 비율
	 */
	private int purchsIncln3StepStartRate;
	
	/**
	 * 구매 성향 3단계 종료 비율
	 */
	private int purchsIncln3StepEndRate;
	
	/**
	 * 구매 성향 4단계 시작 비율
	 */
	private int purchsIncln4StepStartRate;
	
	/**
	 * 구매 성향 4단계 종료 비율
	 */
	private int purchsIncln4StepEndRate;
	
	/**
	 * 삭제 일시
	 */
	private String deleteDt;
	
	/**
	 * 삭제 여부
	 */
	private String deleteAt;
	
	/**
	 * 최초 등록자 아이디
	 */
	private String frstRegisterId;
	
	/**
	 * 최초 등록 일시
	 */
	private String frstRegistDt;
	
	/**
	 * 최종 변경자 아이디
	 */
	private String lastChangerId;
	
	/**
	 * 최종 변경자 이름
	 */
	private String lastChangerNm;
	
	/**
	 * 최종 변경 일시
	 */
	private String lastChangeDt;
	
	/**
	 * 상태값
	 */
	private String status;
	
	/**
	 * 수정여부 (그리드)
	 */
	private boolean editAt = false;
	
	/**
	 * 그리드값
	 */
	private List<WrtmStdrAmoutInfoVO> gridList;

}
