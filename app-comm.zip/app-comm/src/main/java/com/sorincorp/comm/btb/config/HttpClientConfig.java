package com.sorincorp.comm.btb.config;

import org.apache.http.Header;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * HttpClientConfig.java
 * @version
 * @since 2021. 6. 10.
 * @author Sim sung bo
 */
@Configuration
@PropertySource(value = "classpath:/config/btb/btb-${spring.profiles.active}.properties", ignoreResourceNotFound = true)
public class HttpClientConfig {
	
	@Value("${btb.comm.timeout}")
	private Integer timeoutSec;
	
	@Value("${btb.comm.maxTotalConnections}")
	private int maxTotalConnections; // 최대 전체 연결 수
	
	@Value("${btb.comm.maxConnectionsPerRoute}")
	private int maxConnectionsPerRoute; // 라우트 당 최대 연결 수
	
	/**
	 * <pre>
	 * 처리내용: HttpClient를 초기화한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	@Bean
	public HttpClient httpClient() {
		PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
		connectionManager.setMaxTotal(maxTotalConnections);
		connectionManager.setDefaultMaxPerRoute(maxConnectionsPerRoute);

		HttpClient client = HttpClientBuilder.create()
		        .setConnectionManager(connectionManager)
		        .build();
		
//		HttpClient client = HttpClientBuilder.create().build();
		return client;
	}
	
	/**
	 * <pre>
	 * 처리내용: 요청 header를 세팅한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public Header[] header() {
		Header[] headers = {
			    new BasicHeader("Content-type", "application/json;charset=utf-8")
			    };
		return headers;
		
	}
	
	/**
	 * <pre>
	 * 처리내용: timeout 시간은 설정한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public RequestConfig requestConfig() {
		
		return RequestConfig.custom()
			    .setConnectionRequestTimeout(timeoutSec * 1000)
			    .setConnectTimeout(timeoutSec * 1000)
			    .setSocketTimeout(timeoutSec * 1000)
			    .build();
	}
	
	/**
	 * <pre>
	 * 처리내용: HttpPost를 초기화 한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public HttpPost httpPost() {
		HttpPost httpPost = new HttpPost();
		httpPost.setConfig(requestConfig());
		httpPost.setHeaders(header());
		return httpPost;
	}
	
	public HttpGet httpGet() {
		HttpGet httpGet  = new HttpGet();
		httpGet.setConfig(requestConfig());
		httpGet.setHeaders(header());
		return httpGet;
	}
	
	public HttpDelete httpDelete() {
		HttpDelete httpDelete = new HttpDelete();
		httpDelete.setConfig(requestConfig());
		httpDelete.setHeaders(header());
		return httpDelete;
	}
	
	public HttpPut httpPut() {
		HttpPut httpPut = new HttpPut();
		httpPut.setConfig(requestConfig());
		httpPut.setHeaders(header());
		return httpPut;
	}
	
}
