package com.sorincorp.comm.message.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class AppPushQueueVO implements Serializable {
	
	private static final long serialVersionUID = -4002751280030008832L;

	/******  JAVA VO CREATE : AGPUSH_QUEUE()  ******/
	
	private String mberNo;
	
    /**
     * Queue 인덱스
    */
    private long queueidx;
    /**
     * 앱 Key
    */
    private String appKey;
    /**
     * 앱 Secret Key
    */
    private String appSecret;
    /**
     * 메시지 제목
    */
    private String msgTitle;
    /**
     * 발송 일시
    */
    private String sendDate;
    /**
     * 발송 완료 일시
    */
    private String resultDate;
    /**
     * 피드백 일시
    */
    private String feedbackDate;
    /**
     * 메시지 내용
    */
    private String msgContents;
    /**
     * 식별자
    */
    private String identify;
    /**
     * 발송 상태
    */
    private String step;
    /**
     * 발송 모드
    */
    private String pMode;
    /**
     * 첨부 이미지 경로
    */
    private String fName;
    /**
     * 발송 구분
    */
    private String sendStat;
    /**
     * 안드로이드 사운드
    */
    private String androidSound;
    /**
     * 안드로이드 배지
    */
    private int androidBadge;
    /**
     * iOS 사운드
    */
    private String iosSound;
    /**
     * iOS 배지
    */
    private int iosBadge;
    /**
     * 외부 링크
    */
    private String pLink;
    /**
     * 추가 변수 Key1
    */
    private String customKey1;
    /**
     * 추가 변수 값1
    */
    private String customValue1;
    /**
     * 추가 변수 Key2
    */
    private String customKey2;
    /**
     * 추가 변수 값2
    */
    private String customValue2;
    /**
     * 추가 변수 Key3
    */
    private String customKey3;
    /**
     * 추가 변수 값3
    */
    private String customValue3;
    /**
     * 작성일
    */
    private String wDate;
    /**
     * 수정일
    */
    private String uDate;
    /**
     * 라벨 코드
    */
    private String labelCode;
    /**
     * 알림영역 배경색
    */
    private String bgColor;
    /**
     * 알림영역 폰트색
    */
    private String fontColor;
    /**
     * 
    */
    private String andPriority;
    /**
     * 에티켓 적용 여부
    */
    private String isEtiquette;
    /**
     * 에티켓 적용 시간 오늘
    */
    private int etiquetteStime;
    /**
     * 
    */
    private int etiquetteEtime;
    /**
     * 오픈 처리 제한 시간
    */
    private String ofbTime;
    /**
     * 광고 동의 상태
    */
    private String optAgree;
    /**
     * 롱 텍스트 메시지
    */
    private String lngtMessage;
    /**
     * 태그 문자열
    */
    private String pTag;
    /**
     * 태그 조건
    */
    private String beschMode;
    /**
     * 문자 발송 번호
    */
    private String phone;
    /**
     * 문자 수신 번호
    */
    private String callback;
    /**
     * 사용자 컬럼 문자형1
    */
    private String etc1;
    /**
     * 사용자 컬럼 문자형2
    */
    private String etc2;
    /**
     * 푸시 실패시 전환 Flag
    */
    private String failedtype;
    /**
     * 카카오 메시지
    */
    private String kkoMsg;
    /**
     * 알림톡 버튼 URL
    */
    private String kkoUrl;
    /**
     * 알림톡 버튼 타입
    */
    private String kkoUrlButtonTxt;
    /**
     * 버튼 그룹 데이터 JSON
    */
    private String kkoButtonJson;
    /**
     * 알림톡 유형 템플릿 코드
    */
    private String kkoTemplateCode;
    /**
     * 플러스 친구 프로파일 Key
    */
    private String kkoProfiledKey;
    /**
     * 채널 전환 메시지 타이틀
    */
    private String kkoFailedSubject;
    /**
     * 채널 전환 메시지 내용
    */
    private String kkoFailedMsg;
    /**
     * 알림톡 실패후 MMS 이미지
    */
    private String kkoFailedImg;
    /**
     * 알림톡 실패후 전환 Flag
    */
    private String kkoFailedType;
    /**
     * 친구톡 이미지 경로
    */
    private String kkfImgPath;
    /**
     * 친구톡 이미지 URL
    */
    private String kkfImgUrl;
    /**
     * 친구톡 광고 동의자만 수신 여부
    */
    private String kkoAdFlag;
    /**
     * 
    */
    private long serialnum;
    /**
     * 와이드 알림톡 여부
    */
    private String kkoWideYn;
    /**
     * jsondata 타입
     */
    private String type;
    /**
     * jsondata url
     */
    private String url;
    
    
}
