package com.sorincorp.comm.brandgroupcode.mapper;

import java.util.List;

import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;

public interface BrandGroupCodeMapper {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 12.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	List<BrandGroupCodeVO> getBrandGroupCode(BrandGroupCodeVO vo) throws Exception;

}
