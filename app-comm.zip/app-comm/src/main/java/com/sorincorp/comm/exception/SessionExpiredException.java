package com.sorincorp.comm.exception;

/**
 * 세션이 만료되었을 때 발생하는 사용자 정의 Exception
 * SessionExpiredException.java
 * @version
 * @since 2021. 6. 4.
 * @author srec0012
 */
public class SessionExpiredException extends RuntimeException {
	private static final long serialVersionUID = -8483830949020616524L;
	
	public SessionExpiredException(String msg) {
		super(msg);
	}
	
	public SessionExpiredException(String msg, Throwable t) {
		super(msg, t);
	}
}