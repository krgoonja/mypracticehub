package com.sorincorp.comm.bsnInfo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class BsnInfoDetailVO implements Serializable{
    
	private static final long serialVersionUID = 2849004139164064398L;

    /**
     * 적용 일자
    */
    private String applcDe;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 자차 출고 요청 시작 일
    */
    private int manatmbDlivyRequstBeginDe;
    /**
     * 자차 출고 요청 종료 일
    */
    private int manatmbDlivyRequstEndDe;
    /**
     * 자차 당일 출고 마감 시간
    */
    private String manatmbTodayDlivyClosTime;
    /**
     * 케이지트레이딩 출고 요청 시작 일
    */
    private int sorinDlivyRequstBeginDe;
    /**
     * 케이지트레이딩 출고 요청 종료 일
    */
    private int sorinDlivyRequstEndDe;
    /**
     * 케이지트레이딩 당일 출고 마감 시간
    */
    private String sorinTodayDlivyClosTime;
    /**
     * 발동 여부
    */
    private String motnAt;
    /**
     * 전일 대비 비율
    */
    private java.math.BigDecimal bfrtVersusRate;
    /**
     * 지속 시간
    */
    private String cntncTime;
    /**
     * 가격 표시 불가 시간
    */
    private String pcIndictImprtyTime;
}
