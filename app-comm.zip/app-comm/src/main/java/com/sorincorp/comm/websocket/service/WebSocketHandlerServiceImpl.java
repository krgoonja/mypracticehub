package com.sorincorp.comm.websocket.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.websocket.model.SocketDataVO;

public class WebSocketHandlerServiceImpl extends TextWebSocketHandler implements WebSocketHandlerService{
	
	ObjectMapper objectMapper = new ObjectMapper();
    List<WebSocketSession> sessionList = Collections.synchronizedList(new ArrayList<>());
	
	/**
	 * sockJS 를 사용한 기본 Socket 통신 connect
	 */
	@Override
	public void afterConnectionEstablished(WebSocketSession session) throws Exception {
		sessionList.add(session);
		
		SocketDataVO socketData = new SocketDataVO();
        socketData.setId(session.getId());
        socketData.setMessage(null);
        
		sendMessageByAll(socketData);
	}
	
	/**
	 * sockJS 를 사용한 기본 Socket 통신에서 message handler
	 */
	@Override
	protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception{
        SocketDataVO revceiveData = objectMapper.readValue(message.getPayload(), SocketDataVO.class);

        SocketDataVO socketData = new SocketDataVO();
        socketData.setId(revceiveData.getId());
        socketData.setMessage(revceiveData.getMessage());
        
        sendMessageByAll(socketData);
	}
	
	
	/**
	 * ㅍsockJS 를 사용한 기본 Socket 통신 disconnect
	 */
	@Override
	public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
		sessionList.remove(session);
		
		SocketDataVO socketData = new SocketDataVO();
        socketData.setId(session.getId());
        socketData.setMessage("접속종료.");
		sendMessageByAll(socketData);
		
        session.close();
	}
	
	/**
	 * 동일한 socket에 접속한 하나의 session ID에 메시지 보내기
	 */
	public void sendMessageByOne(SocketDataVO socketData) throws Exception {
        String json = objectMapper.writeValueAsString(socketData);
        
        for(WebSocketSession wss : sessionList){
        	if(wss.getId() == socketData.getId()) {
	        	synchronized (wss) {
	        		wss.sendMessage(new TextMessage(json));
	        		break;
				}
        	}
        }
	}
	
	/**
	 * 동일한 socket에 접속한 모든 session ID에 메시지 보내기
	 */
	public void sendMessageByAll(SocketDataVO socketData) throws Exception {
        String json = objectMapper.writeValueAsString(socketData);
        
        for(WebSocketSession wss : sessionList){
        	synchronized (wss) {
        		wss.sendMessage(new TextMessage(json));
			}
        }
	}
}
