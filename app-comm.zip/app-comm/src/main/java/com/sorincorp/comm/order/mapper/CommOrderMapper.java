package com.sorincorp.comm.order.mapper;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.order.model.CommItmWtInfoVO;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.comm.order.model.OrderEntrpsSetleMnVO;
import com.sorincorp.comm.order.model.OrderModel;

/**
 * CommOrderMapper.java
 * 주문 공통 Mapper 인터페이스
 *
 * @version
 * @since 2023. 5. 2.
 * @author srec0049
 */
public interface CommOrderMapper {

	/**
	 * <pre>
	 * 처리내용: 판매 단위 중량(상품별) 및 1회 판매 가능 중량(상품별), 최대 구매 가능 중량(상품별) 가져오기
	 * </pre>
	 * @date 2023. 5. 2.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 2.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param itmSn
	 * @return
	 * @throws Exception
	 */
	public CommItmWtInfoVO selectItmWtInfo(int itmSn) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문 중량에 대한 재고 차감
	 * </pre>
	 * @date 2023. 5. 8.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 8.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	public void updateMinusInvntryBlInfoBas(OrderModel orderModel) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 할당재고 BL 리스트 가져오기 (평균가)
	 * </pre>
	 * @date 2023. 11. 2.
	 * @author srec0066
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 2.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param cntrctOrderNo
	 * @return
	 * @throws Exception
	 */
	public List<ItemPriceMatchingBlInfoVO> selectAvrgpcBlList(String cntrctOrderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 임시
	 * </pre>
	 * @date 2023. 5. 8.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 8.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param itmSn
	 * @return
	 * @throws Exception
	 */
	public String selectMetalCode(int itmSn) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 케이지몰 할증요율 가져오기
	 * </pre>
	 * @date 2023. 1. 26.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023.  1. 26.			srec0049			최초작성
	 * 2023. 11. 20.			srec0053			프로젝트 이관
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	BigDecimal selectTotAmtTariff(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 등급별 할인금액 조회
	 * </pre>
	 * @date 2023. 9. 15.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023.  9. 15.			sumin				최초작성
	 * 2023. 11. 20.			srec0053			프로젝트 이관
	 * ------------------------------------------------
	 * @param String
	 */
	long getGradeDscAmount(String entrpsNo, String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 배송 요율 조회
	 * </pre>
	 * @date 2023. 11. 20.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 20.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectDlvyTariffInfo(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: ITM_SN(아이템 순번)에 해당되는 IT_ITM_INFO_BAS(상품_아이템 기본)의 WT_CHANGE(중량 변동) 값을 가져온다.
	 * </pre>
	 * @date 2022. 1. 13.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022.  1. 13.			srec0049			최초작성
	 * 2023. 11. 20.			srec0053			프로젝트 이관
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	BigDecimal selectWtChange(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문 시 케이지배송 할인 여부 조회
	 * </pre>
	 * @date 2023. 11. 20.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 20.			srec0053			프로젝트 이관
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	String selectDlvrfDscntAt (String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 선택한 배송비 쿠폰 내역을 가져온다. (임시)
	 * </pre>
	 * @date 2023.07.31
	 * @auther sumin
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 14.			sumin				최초작성
	 * 2023. 11. 20.			srec0053			프로젝트 이관
	 * -----------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	List<CouponVO> selectDlvyCouponSeqNo(String[] couponSeqNoArray, String couponDplctUseLmttQyAt, String entrpsNo, String dscntExpectDlvrf, int orderWt) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 사용 단가 쿠폰 내역을 가져온다. (임시)
	 * </pre>
	 * @date 2023.07.31
	 * @auther sumin
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 14.			sumin				최초작성
	 * 2023. 11. 20.			srec0053			프로젝트 이관
	 * -----------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	List<CouponVO> selectUntpcCouponSeqNo(String[] couponSeqNoArray, String couponDplctUseLmttQyAt, String entrpsNo, int orderWt) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 평균가 거래 금액 가져오기
	 * </pre>
	 * @date 2023. 11. 20.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 20.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	String getAvrgpcDelngAmountRateCodeNm(String entrpsNo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 가격 정보 계산에 필요한 업체 결제수단 정보(담보보증) 조회
	 * </pre>
	 * @date 2023. 11. 20.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 20.			srec0053			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	OrderEntrpsSetleMnVO getRequiredEntrpsSetleMnInfo() throws Exception;
}
