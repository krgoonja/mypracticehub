package com.sorincorp.comm.deliveryCarMng.mapper;

import java.util.List;

import com.sorincorp.comm.deliveryCarMng.model.DeliveryCarMngCommVO;

public interface DeliveryCarMngCommMapper {

	/**
	 * <pre>
	 * 처리내용: 업체의 자량정보 리스트를 조회한다.
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	List<DeliveryCarMngCommVO> selectMbVhcleInfoBas(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 기사정보 리스트를 조회한다.
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	List<DeliveryCarMngCommVO> selectMbDrvArticlInfoBas(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 차량정보 카운트를 조회한다
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryCarMngCommVO
	 * @return
	 * @throws Exception
	 */
	int selectMbVhcleInfoBasCnt(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 차량정보를 신규등록한다.
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @param deliveryCarMngCommVO
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	int insertDeliveryCar(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 차량정보를 수정한다.
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	int updateDeliveryCar(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 차량정보를 삭제한다.
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryCarMngCommVO
	 * @return
	 * @throws Exception
	 */
	int deleteDeliveryCar(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 차량정보 이력을 등록한다.
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @param deliveryCarMngCommVO
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @throws Exception
	 */
	void insertDeliveryCarHst(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 기사정보를 신규등록한다.
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryCarMngCommVO
	 * @return
	 * @throws Exception
	 */
	int insertDeliveryDriver(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 기사정보 카운트롤 조회한다.
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryCarMngCommVO
	 * @return
	 * @throws Exception
	 */
	int selectMbDrvArticlInfoBasCnt(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 기사정보를 수정한다.
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryCarMngCommVO
	 * @return
	 * @throws Exception
	 */
	int updateDeliveryDriver(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 기사정보를 삭제한다.
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryCarMngCommVO
	 * @return
	 * @throws Exception
	 */
	int deleteDeliveryDriver(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 업체의 기사정보 이력을 등록한다.
	 * </pre>
	 *
	 * @date 2023. 7. 17.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 7. 17.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param deliveryCarMngCommVO
	 * @throws Exception
	 */
	void insertDeliveryDriverHst(DeliveryCarMngCommVO deliveryCarMngCommVO) throws Exception;

}
