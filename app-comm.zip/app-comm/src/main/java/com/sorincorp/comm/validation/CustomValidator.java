package com.sorincorp.comm.validation;

import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;

import javax.validation.Validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.validation.beanvalidation.SpringValidatorAdapter;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class CustomValidator implements Validator, WebMvcConfigurer {

	@Autowired
    private SpringValidatorAdapter validatorAdapter;
    
    @Autowired
    private LocalValidatorFactoryBean localValidation;
    
    @Autowired
    private MessageSource messageSource;
    
    public CustomValidator() {
        this.validatorAdapter = new SpringValidatorAdapter(
                Validation.buildDefaultValidatorFactory().getValidator()
        );
    }

    @Override
    public boolean supports(Class clazz) {
        return true;
    }

    @Override
    public void validate(Object target, Errors errors) {
        if(target instanceof Collection){
            Collection collection = (Collection) target;

            for (Object object : collection) {
            	validatorAdapter.validate(object, errors);
            }
        } else if(target instanceof Map){
        	Map<Object, Object> map = (Map<Object, Object>) target;
        	
        	for (Entry<Object, Object> entry : map.entrySet()) {
        	    validatorAdapter.validate(entry.getValue(), errors);
            }
        } else {
        	validatorAdapter.validate(target, errors);
        }
    }
    
    public void validate(Object target, Errors errors, Object... groups) {
        if(target instanceof Collection){
            Collection collection = (Collection) target;

            for (Object object : collection) {
            	validatorAdapter.validate(object, errors, groups);
            }
        } else if(target instanceof Map){
        	Map<Object, Object> map = (Map<Object, Object>) target;
        	
        	for (Entry<Object, Object> entry : map.entrySet()) {
        	    validatorAdapter.validate(entry.getValue(), errors, groups);
            }
        } else {
        	validatorAdapter.validate(target, errors, groups);
        }
    }
        
    @Override
    public LocalValidatorFactoryBean getValidator() {
    	localValidation.setValidationMessageSource(messageSource);
        return localValidation;
    }
}
