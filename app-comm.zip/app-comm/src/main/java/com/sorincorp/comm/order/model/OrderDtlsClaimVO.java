package com.sorincorp.comm.order.model;

import lombok.Data;

@Data
public class OrderDtlsClaimVO {

	private String canclExchngRtngudNo; // 취소 교환 반품 번호
	private String orderNo; // 주문 번호

	private String canclExchngRtngudTyCode;
	private String canclExchngRtngudTyNm; // 클레임구분
	private String canclExchngRtngudSttusCode;
	private String canclExchngRtngudSttusNm; //클레임상태
	private String canclExchngRtngudResnCode;
	private String canclExchngRtngudResnNm; // 귀책사유
	private String canclExchngRtngudResnDc; // 요청사유

	private double totBundleQy; //주문수량
	private double totCanclExchngRtngudBundleQy; //클레임수량
	private double exchngBundleQy; //교환대체수량

	private double totOrderWt;	//주문중량
	private double totCanclExchngRtngudWt; //클레임중량
	private double totCanclExchngRtngudDcsnWt; //클레임확정중량
	private double exchngWt;	//교환대체중량

	private long goodsUntpcOrder; //주문단가
	private long goodsUntpcClaim; //클레임단가 (현재단가)
	private long goodsUntpc;
	private long orderPc; //주문가격 (클레임단가 * 중량)

	private long wtChangegld; //중량변동금
	private long realDlvyCt; //케이지배송비
	private long lgistPc; //물류비
	private long penltyAmount; //패널티 (수수료)

	private String mberId;
	private String mberNo;
	private String entrpsNo;
	private String rtngudExchngRtrvlPrearngeDe; //회수예정일 //RTNGUD_EXCHNG_RTRVL_PREARNGE_DE

    private long splpc; //공급가
    private long vat; //부가세
    private long slepc; //판매가

    private long canclUntpcDfnnt; //취소단가차액

    private long excclcGoodsUntpc;	//정산상품단가
    private long excclcGoodsAmount;	//정산상품금액
    private long excclcWtChangegld;	//정산중량변동금
    private long excclcSorinDlvrf; //정산케이지배송비
    private long excclcPenltyAmount; //정산패널티
    private long excclcSplpc; //정산공급가
    private long excclcVat; //정산부가세
    private long excclcSlepc; //정산판매가

    private long premiumDfnlosAmount; //프리미엄차손금액
    private String rspnsFtrsSttusCode;	// 응답 선물 상태 코드
	private String docNo;

	private String canclPossTime;	// 취소가능일시
	private long canclPossYn;		// 취소가능여부
	private String ntcnChargerMoblphonNo;	// 담당자연락처
	private String sleMthdCode;		//판매방식코드 (01:라이브, 02:고정)

	private long realTimePrice;	// 실시간 단가
	private long realTimePremiumPrice;	// 실시간 프리미엄 가격
	private String cstmrSlePcRltmSn; // 고객 판매 가격 실시간 순번
	private String cstmrLmePcRltmSn; // 고객 LME 가격 실시간 순번
	private String cstmrPremiumNo; // 고객 프리미엄 번호
	private String cstmrEhgtPcRltmSn; // 고객 환율 가격 실시간 순번
	
	/** 지급확인서 */
	private String setleComptDt; // 지급일시
	private String orderEntrpsNm; // 업체명(수취인)
	private long refndAmount; // 환불금액
	private String goodsNm; // 주문 상품
	private long frstSetleAmount; // 최초결제금액
	private long cancelPc; // 취소시 금액(취소시점단가 * 수량)
	private long pcDiff; // 취소차액 = (취소시금액 - 주문시금액)
	private String repSeler; // 대표 판매자
	private String repSelerBsnmRegistNo; // 대표 사업자등록번호 
	private String repSelerRprsntvNm; // 대표 이사명
	private String today; // 오늘 날짜
	private String expsAt; // 노출여부: 케이지트레이딩이익N 케이지트레이딩손해Y - 케이지트레이딩이익시에는 화면에 노출하지 않는다
	
	/* 지급확인서 상세 */
	private long orderPcClaim;	// 취소 시 상품단가
	private long excclcDfnnt;		// 정산 차액
}
