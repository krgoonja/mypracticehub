package com.sorincorp.comm.order.model;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * CommAvrgPcInvntryVO.java
 * 평균가 재고 차감 및 증가 공통 VO 객체
 * 
 * @version
 * @since 2023. 11. 21.
 * @author srec0049
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CommAvrgPcInvntryVO  implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1694131586339785695L;

	/**
	 * 평균가구분(avrgSe) [ASGN(할당), ORDER(발주), SETLE(결제)]
	 */
	private String avrgSe;
	
	/**
	 * 처리구분(processSe) [DDCT(차감), INCRS(증가)]
	 */
	private String processSe;
	
	/**
	 * 계약 번호
	 */
	private String cntrctNo;
	
	/**
	 * 계약 년월
	 */
	private String cntrctYm;
	
	/**
	 * 계약 년월 순번
	 */
	private int cntrctYmSn;
	
	/**
     * BL 번호
     */
    private String blNo;
	
	/**
	 * 재고 할당 구분 코드
	 */
	private String invntryAsgnSeCode;
	
	/**
     * 계산 중량
     */
    private Integer calcWt;
    
    /**
     * 계산 재고
     */
    private BigDecimal calcInvntry;
    
    /**
     * 계산 번들 재고
     */
    private Integer calcBundleInvntry;
    
    /**
     * 최종 변경자 아이디
     */
    private String lastChangerId;
    
    /**
     * BL 이력 이벤트 유형 코드
     */
    private String blHistEventTyCode;
    
    /**
     * 이벤트 발행 번호
     */
    private String eventIsuNo;
    
    /**
     * 주문 번호
     */
    private String orderNo;
    
    /**
     * DML 구분 (delete, update, insert)
     */
    private String dmlSe;
    
    /**
     * 재고 할당 번호
     */
    private String invntryAsgnNo;
    
    /**
     * 할당 이벤트 유형 코드
     */
    private String asgnEventTyCode;
    
    /**
     * 할당 이벤트 중량
     */
    private Integer asgnEventWt;
}
