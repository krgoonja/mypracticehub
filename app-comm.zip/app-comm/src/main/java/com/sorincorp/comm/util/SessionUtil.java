package com.sorincorp.comm.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import lombok.extern.slf4j.Slf4j;

/**
 * SessionUtil.java
 * @version
 * @since 2021. 5. 18.
 * @author srec0012
 */
@Slf4j
public class SessionUtil {
	
	private SessionUtil() {
		log.debug(SessionUtil.class.getSimpleName());
	}
	
	/**
	 * <pre>
	 * 세션에서 이름에 해당하는 속성을 반환한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param name
	 * @return
	 */
	public static Object getAttribute(String name) {
		return (Object) RequestContextHolder.getRequestAttributes().getAttribute(name, RequestAttributes.SCOPE_SESSION);
	}
	
	/**
	 * <pre>
	 * 세션에 이름에 해당하는 속성값을 등록한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param name
	 * @param object
	 */
	public static void setAttribute(String name, Object object) {
		RequestContextHolder.getRequestAttributes().setAttribute(name, object, RequestAttributes.SCOPE_SESSION);
	}
	
	/**
	 * <pre>
	 * 세션에서 이름에 해당하는 속성값을 삭제한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param name
	 */
	public static void removeAttribute(String name) {
		RequestContextHolder.getRequestAttributes().removeAttribute(name, RequestAttributes.SCOPE_SESSION);
	}
	
	/**
	 * <pre>
	 * 세션 ID를 반환한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	public static String getSessionId() {
		return RequestContextHolder.getRequestAttributes().getSessionId();
	}
	
	/**
	 * <pre>
	 * HttpSession에 주어진 키 값으로 세션 객체를 생성한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param keyStr
	 * @param obj
	 */
	public static void setSessionAttribute(HttpServletRequest request, String keyStr, Object obj) {
		HttpSession session = request.getSession();
		session.setAttribute(keyStr, obj);
	}
	
	/**
	 * <pre>
	 * HttpSession에 존재하는 주어진 키 값에 해당하는 세션 값을 반환한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param keyStr
	 * @return
	 */
	public static Object getSessionAttribute(HttpServletRequest request, String keyStr) {
		HttpSession session = request.getSession();
		return session.getAttribute(keyStr);
	}
	
	/**
	 * <pre>
	 * HttpSession에 존재하는 세션을 주어진 키 값으로 삭제한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param keyStr
	 */
	public static void removeSessionAttribute(HttpServletRequest request, String keyStr) {
		HttpSession session = request.getSession();
		session.removeAttribute(keyStr);
	}
	
	/**
	 * <pre>
	 * 주어진 키 값에 해당하는 HttpSession이 존재하는지 여부를 반환한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param keyStr
	 * @return
	 */
	public static boolean isSessionAttribute(HttpServletRequest request, String keyStr) {
		Object result = getSessionAttribute(request, keyStr);
		
		if ( result != null ) {
			return true;
		} else {
			return false;
		}
	}
}
