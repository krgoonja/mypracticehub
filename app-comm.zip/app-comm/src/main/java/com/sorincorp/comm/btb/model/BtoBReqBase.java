package com.sorincorp.comm.btb.model;

import java.util.Collections;
import java.util.Map;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BtoBReqBase {

	/* 헤더 정보 */
	private Map<String,String> header;
	
	/* 요청 전문 */
	private Object request;

	public BtoBReqBase(Map<String, String> header, Object request) {
		this.header = header;
		if(request == null) {
			this.request = Collections.emptyMap();
		}else {
			this.request = request;
		}
	}

}
