package com.sorincorp.comm.it.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.sorincorp.comm.it.model.ItFtrsFshgManageDtlVo;

@Service
public class ItFtrsFshgManageDtlVoServiceImpl implements ItFtrsFshgManageDtlVoService {
	
	private Map<String, ItFtrsFshgManageDtlVo> itFtrsFshgManageDtlVo;
	
	public ItFtrsFshgManageDtlVoServiceImpl() {
		if(itFtrsFshgManageDtlVo == null) {
			this.itFtrsFshgManageDtlVo = new HashMap<String, ItFtrsFshgManageDtlVo>();
		}
	}

	@Override
	public ItFtrsFshgManageDtlVo getItFtrsFshgManageDtlVo(String metalCodeByProperties) {
		if(!itFtrsFshgManageDtlVo.containsKey(metalCodeByProperties)) {
			itFtrsFshgManageDtlVo.put(metalCodeByProperties, new ItFtrsFshgManageDtlVo());
		} 
		
		return itFtrsFshgManageDtlVo.get(metalCodeByProperties);
	}

}
