package com.sorincorp.comm.btb.mapper;

import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;

/**
 * BtoBApiMapper.java
 * @version
 * @since 2021. 6. 10.
 * @author Sim sung bo
 */
public interface BtoBApiMapper {

	/**
	 * <pre>
	 * 처리내용: BtoB 통신의 대한 로그 테이블 INSERT
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param btbLogVo
	 */
	void insertBtbLog(BtoBInrecfcLogVO btbLogVo);

	/**
	 * <pre>
	 * 처리내용: BtoB 통신의 대한 로그 테이블 UPDATE
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author Sim sung bo
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			Sim sung bo			최초작성
	 * ------------------------------------------------
	 * @param btbLogVo
	 */
	void updateBtbLog(BtoBInrecfcLogVO btbLogVo);

}
