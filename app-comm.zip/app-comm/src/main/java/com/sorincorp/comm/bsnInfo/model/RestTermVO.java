package com.sorincorp.comm.bsnInfo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class RestTermVO implements Serializable{
    
	private static final long serialVersionUID = 2849004139164064398L;
	
	/**
	 * 차트 상단 첫 문구
	 */
	private String chartStTitle;
	/**
	 * 차트 상단 마지막 문구
	 */
	private String chartEdTitle;
	/**
	 * 검색날짜
	 */
	private String baseDe;
	/**
	 * 검색날짜의 현재 시간
	 */
	private String baseTime;
	/**
	 * 다음 영업일
	 */
	private String applcDe;
	/**
	 * 휴일 영업 시작시간
	 */
	private String applcBeginTime;
	/**
	 * 휴일 영업 종료시간
	 */
	private String applcEndTime;
	/**
	 * 종료 간격(초)
	 */
	private String waitTerm;
	/**
	 * 영업 메세지
	 */
	private String waitNm;
	/**
	 * 남은 날짜(일)
	 */
	private String waitDay;
	/**
	 * 남은 날짜(시간)
	 */
	private String waitHour;
	/**
	 * 남은 날짜(분)
	 */
	private String waitMinute;
	/**
	 * 남은 날짜(초)
	 */
	private String waitSecond;
	/**
	 * 개장시간 범위 코드
	 */
	private String openTimeCode;
	/**
	 * 금속코드 
	 */
	private String metalCode;
	/**
	 * top 종료 간격 (초)
	 */
	private String topWaitTerm;
	/**
	 * top 영업 메세지
	 */
	private String topWaitNm;
	/**
	 * top 남은 날짜(일)
	 */
	private String topWaitDay;
	/**
	 * top 남은 날짜(시간)
	 */
	private String topWaitHour;
	/**
	 * top 남은 날짜(분)
	 */
	private String topWaitMinute;
	/**
	 * top 남은 날짜(초)
	 */
	private String topWaitSecond;
	/**
	 * 판매방식코드
	 */
	private String sleMthdCode;
	/**
	 * 휴일 여부
	 */
	private String restdeAt;
	
	/**
	 * 기준일자 휴일 여부
	 */
	private String baseRestdeAt;
}
