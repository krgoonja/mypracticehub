package com.sorincorp.comm.expectbeginpr.model;

import java.math.BigDecimal;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class NdfEhgtPcVO {
	
	private BigDecimal ask;

	private String date;

	private String dblinkStsName;
     
}
