package com.sorincorp.comm.order.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.common.service.CommonService;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.order.mapper.CommPrvsnlOrderMapper;
import com.sorincorp.comm.order.model.CommLimitGroupModel;
import com.sorincorp.comm.order.model.CommLimitOrderSttusVO;
import com.sorincorp.comm.order.model.CommOrLimitOrderBasVO;
import com.sorincorp.comm.order.model.CommPrvsnlDcsnInfoVO;
import com.sorincorp.comm.order.model.CommPrvsnlOrderVO;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.comm.order.model.OrSetleBasVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * commPrvsnlOrderServiceImpl.java
 * 가단가 주문 공통 Service 구현체 클래스
 * @version
 * @since 2024. 9. 9.
 * @author srec0066
 */
@Slf4j
@Service
@PropertySource(value = "classpath:/config/order/order-${spring.profiles.active}.properties", ignoreResourceNotFound = true)
public class CommPrvsnlOrderServiceImpl implements CommPrvsnlOrderService {

	/** 가단가 주문 Mapper */
	@Autowired
	private CommPrvsnlOrderMapper commPrvsnlOrderMapper;

	@Autowired
	private CommOrderService commOrderService;

	@Autowired
	private CommLimitOrderService commLimitOrderService;

	/** 공통 서비스 */
    @Autowired
    private CommonService commonService;

	@Autowired
    private AssignService assignService;

	/** 메세지 Service */
	@Autowired
	private SMSService smsService;

	@Autowired
    private HttpClientHelper httpClientHelper;

    /** ewallet 주문 url **/
	@Value("${api.ewallet.order.url}")
	private String ewalletOrderUrl;

	@Value("${api.ewallet.timeout}")
	private int ewalletTimeoutsec;

	/** 세금계산서 url **/
	@Value("${api.taxbill.url}")
	private String taxbillUrl;

	/** 담보 상환 url **/
	@Value("${credit.mrtgg.repy.url}")
	private String repyMrtggUrl;

	/**
	 * 지정가 주문 번호로 해당 가단가 주문 내역 가져오기 [단일]
	 */
	@Override
	public CommOrLimitOrderBasVO selectCommOrPrvsnlOrderBas(String limitOrderNo) throws Exception {
		return commPrvsnlOrderMapper.selectCommOrPrvsnlOrderBas(limitOrderNo);
	}

	/**
	 * 지정가 주문 번호들로 해당 가단가 주문 내역 리스트 가져오기 [복수]
	 */
	@Override
	public List<CommOrLimitOrderBasVO> selectCommOrPrvsnlOrderBasList(List<String> limitOrderNoList) throws Exception {
		return commPrvsnlOrderMapper.selectCommOrPrvsnlOrderBasList(limitOrderNoList);
	}
	
	/**
	 * 주문 번호에 대한 공통 가단가 확정 여부 정보 가져오기
	 */
	@Override
	public CommPrvsnlDcsnInfoVO getPrvsnlDcsnAtInfo(String orderNo) throws Exception {
		// 주문 번호에 대한 공통 가단가 확정 정보 가져오기
		CommPrvsnlDcsnInfoVO getPrvsnlDcsnInfo = commPrvsnlOrderMapper.getPrvsnlDcsnAtInfo(orderNo);
		
		return getPrvsnlDcsnInfo;
	}

    /**
     *  단가 확정 및 정산 프로세스 실행
     */
    @Override
    public void executeUntpcDcsnExcclcProcess(OrderModel orderModel) throws Exception {

    	String untpcDcsnProcAt = this.getPrvsnlDcsnAtInfo(orderModel.getOrderNo()).getUntpcDcsnProcAt();
    	log.info("[executeUntpcDcsnExcclcProcess] untpcDcsnProcAt : " + untpcDcsnProcAt);

    	// 단가확정 대상건만 진행
    	if(StringUtils.equals("Y", untpcDcsnProcAt)) {
	    	// 1. 단가확정 및 정산 진행을 위한 데이터 조회
	    	CommPrvsnlOrderVO prvsnlOrder = commPrvsnlOrderMapper.selectDcsnExcclcInfo(orderModel.getOrderNo());

	    	// 2. 확정 단가 계산 및 세팅
	    	this.calculateUntpcDcsnInfo(orderModel, prvsnlOrder);

	    	// 3. 정산 데이터 계산 및 환불여부 체크
	    	this.calculateExcclcRefndInfo(orderModel, prvsnlOrder);

    	 	// 4. 주문_주문 기본 tbl 가격, 정산 관련정보 update
    		this.updateOrOrderBasPriceInfo(orderModel, prvsnlOrder);

        	// 5. 이월렛 모듈 호출 - SKIP&거래정보 상세 데이터 생성 및 대상건 환불 진행
    		if(prvsnlOrder.isEwalletRefndYn()) {
    			callEwalletAPI(prvsnlOrder);
    		}

    		// 6. 수정 세금계산서 발행
    		if(prvsnlOrder.isTaxbillIssueYn()) {
    			callTaxbillAPI(orderModel.getOrderNo());
    		}

    		// 7. 담보 모듈 호출
    		if(prvsnlOrder.isMrtggCallYn()) {
    			callMrtggAPI(orderModel.getOrderNo());
    		}
    		
    		// 8. 가격변동금 입금 or 출금 요청대상건 있을경우 삭제처리
		    int res = commPrvsnlOrderMapper.deleteOrPcChangegldBasRequestInfo(prvsnlOrder);
		    if(res > 0) {
	    		commonService.insertTableHistory("OR_PC_CHANGEGLD_BAS", prvsnlOrder);
	    	}
    	}
    }

	/**
	 *	확정 단가 및 가격 정보 계산
	 */
	@Override
	public void calculateUntpcDcsnInfo(OrderModel orderModel, CommPrvsnlOrderVO prvsnlOrder) throws Exception {
		// 파라미터 없을 경우, 재조회
		if(prvsnlOrder == null) {
			// 단가확정 및 정산 진행을 위한 데이터 조회
			prvsnlOrder = commPrvsnlOrderMapper.selectDcsnExcclcInfo(orderModel.getOrderNo());
		}

		long goodsUntpc = 0; 	  // 상품 단가
        long wtChangePc = 0; 	  // 중량 변동금
        long orderPc = 0;		  // 주문 가격
		long splpc = 0;		 	  // 공급가
        long vat = 0;		 	  // 부가세
        long slepc = 0;		 	  // 판매가

        long pdDscntAmount = 0;   // 단가 할인금액
        long cpDscntAmount = 0;   // 총액 할인금액
        long gradeDscAmount = orderModel.getGradApplcAmount();  // 등급 할인금액
        long expectDlvrf = 0; 	  // 예상 배송비

        int orderWt = orderModel.getOrderWt(); // 주문 중량

        // 확정 상품단가 조회 (지정가 or 라이브)
        goodsUntpc = prvsnlOrder.getDcsnGoodsPc();
        log.info("[calculateUntpcDcsnInfo] dcsnGoodsPc : " + goodsUntpc);

        // 확정 상품단가 데이터 없는 경우, 확정 LME/환율/주문프리미엄으로 단가 계산
        if(goodsUntpc <= 0) {
        	goodsUntpc = (long) ((prvsnlOrder.getDcsnLmePc().multiply(prvsnlOrder.getDcsnEhgtPc())).add(orderModel.getPremiumPc()))
		  			.divide(new BigDecimal(1000)).setScale(0, RoundingMode.DOWN).longValue() * 1000;
        }
        log.info("[calculateUntpcDcsnInfo] lmePc: " + prvsnlOrder.getDcsnLmePc() + ", ehgtPc: " + prvsnlOrder.getDcsnEhgtPc() + ", premiumPc: " + orderModel.getPremiumPc() +", goodsUntpc: " + goodsUntpc);

        // 원 상품 단가 (등급할인, 쿠폰 적용 전)
        orderModel.setOrgGoodsUntpc(goodsUntpc);

        // 사용쿠폰 리스트 조회
        if(StringUtils.equals("Y", orderModel.getCouponApplcAt())) {
        	orderModel.setCouponList(commPrvsnlOrderMapper.selectCouponList(orderModel.getOrderNo()));
        	orderModel.setCouponDplctUseLmttQyAt("N");
        } else {
        	orderModel.setCouponList(new ArrayList<CouponVO>());
        }
        // 쿠폰 적용 후 금액 조회
        CouponVO couponvo = commOrderService.couponUse(orderModel, orderWt, false);
        pdDscntAmount = couponvo.getPdDscntAmount();
        cpDscntAmount = couponvo.getCpDscntAmount();
        expectDlvrf = prvsnlOrder.getExpectDlvrf();

        // 최종 상품 단가 계산 및 가격관련 정보 세팅
        goodsUntpc = goodsUntpc - gradeDscAmount - pdDscntAmount;  						 // 상품 단가 (등급할인, 쿠폰 적용 후)
        orderPc = goodsUntpc * orderWt;        											 // 주문 가격
        wtChangePc = Double.valueOf(goodsUntpc * orderModel.getWtChange()).longValue();  // 중량 변동금

        orderModel.setGoodsUntpc(goodsUntpc);
        orderModel.setOrderPc(orderPc);
        orderModel.setWtChangegld(wtChangePc);

        splpc = ( orderModel.getGoodsUntpc() * orderWt ) + orderModel.getWtChangegld() + expectDlvrf - cpDscntAmount;  // 공급가
        vat = (long) (splpc * 0.1);	    // 부가세
        slepc = splpc + vat; 			// 판매가

        orderModel.setSplpc(splpc);
        orderModel.setVat(vat);
        orderModel.setSlepc(slepc);

        log.info("[calculateUntpcDcsnInfo] orderModel : " + String.valueOf(orderModel));
	}

	/**
	 * <pre>
	 * 처리내용: 정산, 확정 데이터 계산 및 환불여부 체크
	 * </pre>
	 * @date 2024. 10. 18.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 18.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws Exception
	 * @throws
	 */
	private void calculateExcclcRefndInfo(OrderModel orderModel, CommPrvsnlOrderVO prvsnlOrder) throws Exception {
		boolean ewalletRefndYn = false;  // 이월렛 환불 여부
		boolean taxbillIssueYn = false;  // 세금계산서 발행 여부
		boolean mrtggCallYn = false;     // 담보 api 호출 여부

		long goodsUntpc = orderModel.getGoodsUntpc();			    // 확정단가
		long avrgpcGoodsUntpc = prvsnlOrder.getAvrgpcGoodsUntpc();  // 가단가

    	long untpcExcclcAmount = 0;		// 단가 정산 금액
		long excclcSplpc = 0;			// 정산 공급가
		long excclcVat = 0;				// 정산 부가세
    	long excclcAmount = 0;  		// 정산 금액
    	long finalExcclcAmount = 0; 	// 최종 정산 금액(실제 환불대상)

    	// 최초 가격변동금 (환불대상-부가세 포함해서 계산)
    	long pcChangegld = (long) (prvsnlOrder.getPcChangegld() * -1.1);

		if(StringUtils.equals("30", prvsnlOrder.getOrderSttusCode())) {
			/**
			 * [CASE1] 주문 -> 출고 -> 단가확정(현재)

			     1) SKIP 데이터 생성
			     2) 거래 정보 상세 데이터 생성
			     3) 가격, 정산관련 데이터 UPDATE
			     4) 가격 변동금 요청내역 삭제 처리
			     5) 대상건 환불 진행
			**/

			if(prvsnlOrder.getTotDcsnWt().compareTo(new BigDecimal(0)) < 1) {
				throw new Exception(prvsnlOrder.getOrderNo() + ": 확정중량 미존재");
			}

			// 단가 정산 금액 = 단가확정 시점 가격(확정가, 확정중량) - 중량정산 시점 가격(가단가, 확정중량)
			untpcExcclcAmount = Math.abs(BigDecimal.valueOf(avrgpcGoodsUntpc - goodsUntpc).multiply(prvsnlOrder.getTotDcsnWt()).longValue()); // 절대값으로 금액계산 후 부호처리
			untpcExcclcAmount = Math.round(untpcExcclcAmount * 1.1) * (avrgpcGoodsUntpc > goodsUntpc ? -1 : 1); // 부가세 10% * 부호처리
			prvsnlOrder.setPcRefndAmount(untpcExcclcAmount + pcChangegld); // 최초변동금은 단가확정 시점에 함께 정산

			// 정산 및 확정 관련 데이터 계산
    		long orderPc = prvsnlOrder.getTotOrderWt().multiply(BigDecimal.valueOf(avrgpcGoodsUntpc)).longValue() + prvsnlOrder.getPcChangegld(); // 최초 주문 가격 (가단가, 가중량, 최초변동금)
			long dcsnOrderPc = prvsnlOrder.getTotDcsnWt().multiply(BigDecimal.valueOf(goodsUntpc)).longValue();	   // 확정 주문 가격 (확정단가, 확정중량)
			long totDcsnSplpc = dcsnOrderPc + prvsnlOrder.getExpectDlvrf(); 		   							   // 확정 공급가

			// 부호 세팅
	    	int sign = -1;
	    	if(dcsnOrderPc - orderPc >= 0) {
	    		// 돌려줄 금액이 없는 경우(고객이 추가입금 필요)
	    		sign = 1;
	    	}

			excclcSplpc = Math.abs(dcsnOrderPc - orderPc); // 정산 공급가 (절대값으로 금액계산 후 부호처리)
			excclcVat = Math.round(excclcSplpc * 0.1);	   // 정산 부가세
	    	excclcAmount = Math.round(excclcSplpc * 1.1);  // 정산 금액

	    	// 업데이트 대상 데이터 세팅
	    	prvsnlOrder.setTotDcsnOrderPc(dcsnOrderPc);
	    	prvsnlOrder.setTotDcsnSplpc(totDcsnSplpc);
	    	prvsnlOrder.setExcclcSplpc(excclcSplpc * sign);
	    	prvsnlOrder.setExcclcVat(excclcVat * sign);
	    	prvsnlOrder.setExcclcAmount(excclcAmount * sign);

	    	// 기납입 변동금액 (환불대상)
	    	long aditRcpmnyAmount = prvsnlOrder.getAditRcpmnyAmount() * -1;
	    	prvsnlOrder.setAditRcpmnyAmount(aditRcpmnyAmount);

	    	// 최종 정산금액 = 정산금액 & 입금된 변동금액의 차액으로 최종 요청 금액 계산
	    	finalExcclcAmount = prvsnlOrder.getExcclcAmount() + aditRcpmnyAmount;
    		prvsnlOrder.setFinalExcclcAmount(finalExcclcAmount);

			// 각 모듈 호출여부 체크
			if(StringUtils.equals("20", prvsnlOrder.getSetleMthdCode()) || StringUtils.equals("40", prvsnlOrder.getSetleMthdCode())) {
				// 여신 주문건
				taxbillIssueYn = true; // 최종 정산 진행건이므로, 수정 세금계산서 발행
				mrtggCallYn = true;    // 담보 모듈 호출
				
				// 24-11-14 변경사항 : 상환 완료(50)된 여신 주문의 경우, SKIP 처리 및 정산금액에 대한 환불 처리를 위해 ewallet 모듈도 호출하도록 조건문 추가
				if(StringUtils.equals("50", prvsnlOrder.getMrtggSttusCode())) {
					ewalletRefndYn = true;
				}
			} else {
				// 여신 이외(이월렛) 주문건
				ewalletRefndYn= true;  // 단가, 중량 모두 확정되었으므로 이월렛 환불 진행
				taxbillIssueYn = true; // 최종 정산 진행건이므로, 수정 세금계산서 발행
			}
        } else {
        	/**
        	 * [CASE2] 주문 -> 단가확정(현재) -> 출고(예정)

			     1) SKIP 데이터 생성
			     2) 가격관련 데이터 UPDATE
			**/
			// 단가 정산 금액 = 단가확정 시점 가격(확정단가, 가중량) - 주문 시점 가격(가단가, 가중량)
			untpcExcclcAmount = Math.abs(BigDecimal.valueOf(avrgpcGoodsUntpc - goodsUntpc).multiply(prvsnlOrder.getTotOrderWt()).longValue()); // 절대값으로 금액계산 후 부호처리
			untpcExcclcAmount = Math.round(untpcExcclcAmount * 1.1) * (avrgpcGoodsUntpc > goodsUntpc ? -1 : 1); // 부가세 10% * 부호처리
			prvsnlOrder.setPcRefndAmount(untpcExcclcAmount + pcChangegld); // 최초변동금은 단가확정 시점에 함께 정산

        	if(StringUtils.equals("20", prvsnlOrder.getSetleMthdCode()) || StringUtils.equals("40", prvsnlOrder.getSetleMthdCode())) {
				// 여신 주문건
        		mrtggCallYn = true;	// 담보 모듈 호출하여 SKIP 데이터 생성
			} else {
				// 여신 이외(이월렛) 주문건
				ewalletRefndYn = true; // 결제 tbl에 SKIP 데이터 생성
			}
        }

    	prvsnlOrder.setMberId(orderModel.getMberId());
    	prvsnlOrder.setMberNo(orderModel.getMberNo());
		prvsnlOrder.setEwalletRefndYn(ewalletRefndYn);
		prvsnlOrder.setTaxbillIssueYn(taxbillIssueYn);
		prvsnlOrder.setMrtggCallYn(mrtggCallYn);

		log.info("[calculateExcclcRefndInfo] prvsnlOrder : " + String.valueOf(prvsnlOrder));
	}

	/**
	 * <pre>
	 * 처리내용: 주문_주문 기본 - 가격, 정산 관련 데이터 update
	 * </pre>
	 * @date 2024. 10. 18.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 18.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	private void updateOrOrderBasPriceInfo(OrderModel orderModel, CommPrvsnlOrderVO prvsnlOrder) throws Exception {
		Map<String, Object> priceParams= new HashMap<>();
		priceParams.put("orderModel", orderModel);
		priceParams.put("excclcInfo", prvsnlOrder);

		int res = commPrvsnlOrderMapper.updateOrOrderBasPriceInfo(priceParams);
		if(res > 0) {
    		commonService.insertTableHistory("OR_ORDER_BAS", orderModel);
    	}
	}

	/**
	 * <pre>
	 * 처리내용: 이월렛 api 호출
	 * </pre>
	 * @date 2024. 10. 18.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 18.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	private void callEwalletAPI(CommPrvsnlOrderVO excclcInfo) {
		try {

			// 1. 단가정산에 대한 SKIP 데이터 생성 (공통)
			excclcInfo.setRefndSeCode("02");	  	 // 환불 구분 코드 - [02: 단가환불]
		    excclcInfo.setSetleSttusCode("99");   	 // 결제 상태 코드 - [99: SKIP]
		    insertEwalletSetle(excclcInfo);

		    // 2. 거래 정보 상세 데이터 생성(공통) - 최종 정산금액 나온 경우에만 등록
		    // 24-11-14 변경사항 : 상환 완료(50) 된 여신 주문건에 대해서는 데이터를 등록하지 않도록 조건 추가
		    if(excclcInfo.getExcclcAmount() != null && !StringUtils.equals("50", excclcInfo.getMrtggSttusCode())) {
		    	// 정산내역
		    	if(excclcInfo.getExcclcAmount() != 0) {
			    	excclcInfo.setDelngAmount(excclcInfo.getExcclcAmount());
			    	excclcInfo.setDelngDetailSeCode("10");  // 거래 상세 구분 코드 - [10: 정산]
			    	int res = commPrvsnlOrderMapper.insertOrDelngInfoDtl(excclcInfo);
			    	if(res > 0) {
			    		commonService.insertTableHistory("OR_DELNG_INFO_DTL", excclcInfo);
			    	}
		    	}

		    	// 변동금 입금 내역
		    	if(excclcInfo.getAditRcpmnyAmount() != 0) {
			    	excclcInfo.setDelngAmount(excclcInfo.getAditRcpmnyAmount());
			    	excclcInfo.setDelngDetailSeCode("20");  // 거래 상세 구분 코드 - [20: 변동금]
			    	int res = commPrvsnlOrderMapper.insertOrDelngInfoDtl(excclcInfo);
			    	if(res > 0) {
			    		commonService.insertTableHistory("OR_DELNG_INFO_DTL", excclcInfo);
			    	}
		    	}
		    }

		    // 환불 금액 존재하는 경우
		    if(excclcInfo.getFinalExcclcAmount() < 0) {

				// 2. 최종 정산 데이터 생성
				excclcInfo.setRefndSeCode("03");	 // 환불 구분 코드 - [03: 중량/단가환불]
			    excclcInfo.setSetleSttusCode("01");  // 결제 상태 코드 - [01: 요청]
			    OrSetleBasVO setleInfo = insertEwalletSetle(excclcInfo);

			    // 3. 이월렛 환불 진행
			    Map<String, Object> ewalletMap = new HashMap<String, Object>();
                ewalletMap.put("entrpsNo", excclcInfo.getEntrpsNo());
                ewalletMap.put("iemSeCode", "0003");
                ewalletMap.put("ewalletExcclcTyCode", "04"); // E-Wallet 정산 유형 코드 04 : 중량정산
                ewalletMap.put("setleNo", setleInfo.getSetleNo());
                ewalletMap.put("delngAmount", (-1) * excclcInfo.getFinalExcclcAmount());
                Map<String, Object> ewalletResMap = httpClientHelper.postCallApi(ewalletOrderUrl, ewalletMap);
                log.debug(ewalletResMap.toString()); // log

                // 이월렛 서버에서 결재테이블 정상 성공으로 업데이트 되었는지 체크, 실패일 시 세금계산서 처리를 안 함
                if (null != ewalletResMap && StringUtils.equals("200", ewalletResMap.get("resultCode").toString())
                        && ewalletResMap.get("data") != null) {
                    boolean isSuccess = false;
                    Map<String, Object> resultData = (Map<String, Object>) ewalletResMap.get("data");
                    String delngSeqNo = String.valueOf(resultData.get("delngSeqNo"));

                    for (int i = 0; i < ewalletTimeoutsec * 2; i++) {
                        Thread.sleep(500);
                        // 호출 건 응답 코드 확인
                        String rspnsCode = commPrvsnlOrderMapper.selectEwalletRspnCode(delngSeqNo);
                        log.debug(">> rspnsCode : " + rspnsCode);
                        if (!StringUtils.isEmpty(rspnsCode)) {
                            // 응답 코드가 000 일때 거래 완료 -> 전문설계서 응답코드 확인
                            if (StringUtils.equals(rspnsCode, "000")) {
                                isSuccess = true;
                            }
                            log.debug(">> rspnsCode : " + rspnsCode + ", isSuccess : " + isSuccess);
                            break;
                        }
                    } // end for
                    log.debug(">> finally isSuccess : " + isSuccess);

                    if (!isSuccess) {
                        throw new Exception("이월렛 주문 실패");
                    }
                } else {
                    throw new Exception("이월렛 호출 실패");
                }
			} else {
				// 환불진행대상 아님
				log.debug("이월렛 환불처리 PASS(추가결제 or 정산금액 없음) - 주문번호 : {}, 정산금액 : {}", excclcInfo.getOrderNo(), excclcInfo.getFinalExcclcAmount());
			}
		} catch (Exception e) {
			log.info("[executeUntpcDcsnExcclcProcess] callEwalletAPI ERROR : ", e.getMessage());
		}
	}

    /**
     * <pre>
     * 처리내용: 주문_결제 기본 등록
     * </pre>
     * @date 2024. 10. 18.
     * @author srec0066
     * @history
     * -------------------------------------------------------------------------
     * 변경일			작성자			변경내용
     * -------------------------------------------------------------------------
     * 2024. 10. 18.		srec0066		최초작성
     * -------------------------------------------------------------------------
     * @param
     * @return
     * @throws
     */
    private OrSetleBasVO insertEwalletSetle(CommPrvsnlOrderVO excclcInfoVO) throws Exception {
        String nowDate = DateUtil.getNowDate();
        String setleNo = nowDate + "-" + assignService.selectAssignValue("OR", "SETLE_NO", nowDate, excclcInfoVO.getMberNo(), 5);
        excclcInfoVO.setSetleNo(setleNo);

        // 중량변동 정산 금액이 존재할 경우, 가단가 주문이므로
        // 이월렛 결제상태코드가 99(SKIP)일 경우, 가단가 주문-중량정산 CASE이므로 중량정산에 대한 이력성 데이터를 등록한다.
        long delngAmount = 0;
    	if(StringUtils.equals(excclcInfoVO.getSetleSttusCode(), "99")) {
        	delngAmount = excclcInfoVO.getPcRefndAmount();
        } else {
        	delngAmount = excclcInfoVO.getFinalExcclcAmount();
    	}

        OrSetleBasVO orSetleBasVo = new OrSetleBasVO();
        orSetleBasVo.setSetleNo(setleNo);
        orSetleBasVo.setOrderNo(excclcInfoVO.getOrderNo());
        orSetleBasVo.setCanclExchngRtngudNo(excclcInfoVO.getCanclExchngRtngudNo());
        orSetleBasVo.setSetleSeCode("10"); // 결제 구분 코드 - 값 10 : 주문
        orSetleBasVo.setSetleTyCode("20"); // 결제 유형 코드 - 값 20 : 환불(케이지트레이딩계좌 ==> 가상계좌)
        orSetleBasVo.setSetleSttusCode(excclcInfoVO.getSetleSttusCode()); // 결제 상태 코드 - [01: 요청, 04: 실패(거래금액 음수), 99: SKIP]
        orSetleBasVo.setRefndSeCode(excclcInfoVO.getRefndSeCode()); // 환불 구분 코드 - [02: 단가환불, 03 : 중량/단가환불]
        orSetleBasVo.setDelngAmount(Long.toString((-1) * delngAmount)); // 정산(환불) 금액이 음수로 표기되므로, 양수 표기를 위해 -1을 곱해줌
        orSetleBasVo.setFrstRegisterId(excclcInfoVO.getMberId());
        orSetleBasVo.setLastChangerId(excclcInfoVO.getMberId());

        int res = commPrvsnlOrderMapper.insertEwalletSetle(orSetleBasVo);
        if(res > 0) {
        	commonService.insertTableHistory("OR_SETLE_BAS", orSetleBasVo);
        }

        return orSetleBasVo;
	}

	/**
	 * <pre>
	 * 처리내용: 수정 세금계산서 발행
	 * </pre>
	 * @date 2024. 10. 18.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 18.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	private void callTaxbillAPI(String orderNo) throws Exception {
		try {
			Map<String, Object> paramMap = new HashMap<>();
			paramMap.put("orderNo", orderNo);
			paramMap.put("canclExchngRtngudNo", null);
			paramMap.put("jobSe", "WT");

			Map<String, Object> resObj = httpClientHelper.postCallApi(taxbillUrl, paramMap);
			if (resObj != null && resObj.get("responseCode") != null && StringUtils.equals(resObj.get("responseCode").toString(), "200")) {
				log.debug("수정세금계산서 발행 성공");
			} else {
            	throw new Exception("수정세금계산서 발행 실패 - resObj : " + String.valueOf(resObj));
            }
		} catch (Exception e) {
			log.info("[executeUntpcDcsnExcclcProcess] callTaxbillAPI ERROR : ", e.getMessage());
		}
	}

	/**
	 * <pre>
	 * 처리내용: 담보 상환 api 호출
	 * </pre>
	 * @date 2024. 10. 18.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 18.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	private void callMrtggAPI(String orderNo) throws Exception {
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("mrtggSttusCode", "30"); // 담보 상태 코드 : 30-부분상환
			paramMap.put("repySeCode", "03"); // 상환 구분 코드 : 03-단가정산
			paramMap.put("orderNo", orderNo); // 주문 번호

			Map<String, Object> resObj = httpClientHelper.postCallApi(repyMrtggUrl, paramMap);
			if (resObj != null && resObj.get("rspnsCode") != null && StringUtils.equals(resObj.get("rspnsCode").toString(), "200")) {
				log.debug("담보 상환 처리 성공");
			} else {
	        	throw new Exception("담보 상환 처리 실패 - resObj : " + String.valueOf(resObj));
	        }
		} catch (Exception e) {
			log.info("[executeUntpcDcsnExcclcProcess] callMrtggAPI ERROR : ", e.getMessage());
		}
	}

	/**
	 * 해당 가단가 지정가 주문 번호의 지정가 주문 상태 코드를 변경 [단일]
	 */
	@Override
	public int updateCommPrvsnlLimitOrderSttusCode(String limitOrderNo, String limitOrderSttusCode, String limitOrderFailrResn, String lastChangerId) throws Exception {
		int res = 0;

		// 지정가 구분 코드
		String limitSeCode = limitOrderNo.substring(9, 10);

		// 파라미터
		CommLimitOrderSttusVO paramVo = CommLimitOrderSttusVO.builder()
				.limitOrderNo(limitOrderNo)
				.limitOrderSttusCode(limitOrderSttusCode)
				.limitOrderFailrResn(limitOrderFailrResn)
				.lastChangerId(lastChangerId)
				.build();

		if("F".equals(limitSeCode)) {
			// LME
			res = commPrvsnlOrderMapper.updateLmeLimitOrderSttusCode(paramVo);
		} else if("X".equals(limitSeCode)) {
			// 환율
			res = commPrvsnlOrderMapper.updateEhgtLimitOrderSttusCode(paramVo);
		} else if("R".equals(limitSeCode)) {
			// KRW
			res = commPrvsnlOrderMapper.updateKrwLimitOrderSttusCode(paramVo);
		}

		return res;
	}

	/**
	 * 해당 가단가 지정가 주문 번호 리스트의 지정가 주문 상태 코드를 변경 [복수]
	 */
	@Override
	public int updateCommPrvsnlLimitOrderSttusCode(List<String> limitOrderNoList, String limitOrderSttusCode, String limitOrderFailrResn, String lastChangerId) throws Exception {
		int res = 0;

		// 파라미터
		CommLimitOrderSttusVO paramVo = CommLimitOrderSttusVO.builder()
				.limitOrderSttusCode(limitOrderSttusCode)
				.limitOrderFailrResn(limitOrderFailrResn)
				.lastChangerId(lastChangerId)
				.build();

		for (String limitOrderNo : limitOrderNoList) {
			// 지정가 주문번호 세팅
			paramVo.setLimitOrderNo(limitOrderNo);

			// 지정가 구분 코드
			String limitSeCode = limitOrderNo.substring(9, 10);

			if("F".equals(limitSeCode)) {
				// LME
				res = commPrvsnlOrderMapper.updateLmeLimitOrderSttusCode(paramVo);
			} else if("X".equals(limitSeCode)) {
				// 환율
				res = commPrvsnlOrderMapper.updateEhgtLimitOrderSttusCode(paramVo);
			} else if("R".equals(limitSeCode)) {
				// KRW
				res = commPrvsnlOrderMapper.updateKrwLimitOrderSttusCode(paramVo);
			}
		}
		return res;
	}

	/**
	 * 가단가 지정가 주문 큐 메시지 정보 업데이트 (LME)
	 */
	@Override
	public int updateOrLimitOrderLmeBasQueueInfo(CommLimitGroupModel commLimitGroupModel) throws Exception {
		return commPrvsnlOrderMapper.updateOrLimitOrderLmeBasQueueInfo(commLimitGroupModel);
	}

	/**
	 * 가단가 지정가 주문 큐 메시지 정보 업데이트 (FX)
	 */
	@Override
	public int updateOrLimitOrderEhgtBasQueueInfo(CommLimitGroupModel commLimitGroupModel) throws Exception {
		return commPrvsnlOrderMapper.updateOrLimitOrderEhgtBasQueueInfo(commLimitGroupModel);
	}

	/**
	 * 가단가 지정가 주문 큐 메시지 정보 업데이트 (KRW)
	 */
	@Override
	public int updateOrLimitOrderKrwBasQueueInfo(CommLimitGroupModel commLimitGroupModel) throws Exception {
		return commPrvsnlOrderMapper.updateOrLimitOrderKrwBasQueueInfo(commLimitGroupModel);
	}

	/**
	 * 가단가 주문 큐 메시지 정보 업데이트 (주문_주문 기본)
	 */
	@Override
	public int updateOrOrderBasQueueInfo(CommLimitGroupModel commLimitGroupModel, String limitSeCode, String orderNo) throws Exception {
		Map<String, Object> params= new HashMap<>();
		params.put("commLimitGroupModel", commLimitGroupModel);
		params.put("limitSeCode", limitSeCode);
		params.put("orderNo", orderNo);

		return commPrvsnlOrderMapper.updateOrOrderBasQueueInfo(params);
	}

	/**
	 * 가단가 주문의 BL목록을 조회
	 */
	@Override
	public List<ItemPriceMatchingBlInfoVO> selectPrvsnlOrderBlList(String orderNo) throws Exception {
		return commPrvsnlOrderMapper.selectPrvsnlOrderBlList(orderNo);
	}

	/**
	 * 지정가 주문 번호[단일] 가단가 지정가 주문 실패 시
	 */
	@Override
	public void prvsnlLimitOrderFail(String targetLimitOrderNo, String limitOrderSttusCode, String limitOrderFailrResn, String changeId) {
		try {
			// 해당 지정가 주문 번호의 지정가 주문 상태 코드를 변경 [단일]
			// [
			//  10(미체결), 20(주문처리중), 30.체결, 31.부분 체결, 40(주문취소(본인)), 41(주문취소(관리자))
			//  , 90(체결실패(선물 실패)), 91(체결실패(재고 부족)), 92(체결실패(잔액 부족)), 93(체결실패(당일 유효 시간 경과)), 94(체결실패(유효성 검사 실패)), 95(체결실패(기타))
			// ]
			int updateLimitOrderSttusCode = this.updateCommPrvsnlLimitOrderSttusCode(targetLimitOrderNo, limitOrderSttusCode, limitOrderFailrResn, changeId);
			log.warn("[prvsnlLimitOrderFail][단일] updateCommPrvsnlLimitOrderSttusCode : " + updateLimitOrderSttusCode);

			// 지정가 주문 실패 상태 처리 이후 후처리
			//  1) 지정가 주문 체결 실패 SMS 발송
			//  2) 사용된 쿠폰 리셋
			//  3) 관련 테이블 이력 정보 등록하기
			this.afterProcPrvsnlLimitOrderFail(targetLimitOrderNo);
		} catch(Exception e) {
			String stacktrace = ExceptionUtils.getStackTrace(e);
			log.error("[prvsnlLimitOrderFail][단일] : " + stacktrace);
		}
	}

	/**
	 * 지정가 주문 번호[복수] 가단가 지정가 주문 실패 시
	 */
	@Override
	public void prvsnlLimitOrderFail(List<String> targetLimitOrderNoList, String limitOrderSttusCode, String limitOrderFailrResn, String changeId) {
		try {
			// 해당 지정가 주문 번호의 지정가 주문 상태 코드를 변경 [복수]
			// [
			//  10(미체결), 20(주문처리중), 30.체결, 31.부분 체결, 40(주문취소(본인)), 41(주문취소(관리자))
			//  , 90(체결실패(선물 실패)), 91(체결실패(재고 부족)), 92(체결실패(잔액 부족)), 93(체결실패(당일 유효 시간 경과)), 94(체결실패(유효성 검사 실패)), 95(체결실패(기타))
			// ]
			int updateLimitOrderSttusCode = this.updateCommPrvsnlLimitOrderSttusCode(targetLimitOrderNoList, limitOrderSttusCode, limitOrderFailrResn, changeId);
			log.warn("[prvsnlLimitOrderFail][복수] updateLimitOrderSttusCode : " + updateLimitOrderSttusCode);

			for(String targetLimitOrderNo : targetLimitOrderNoList) {
				// 지정가 주문 실패 상태 처리 이후 후처리
				//  1) 지정가 주문 체결 실패 SMS 발송
				//  2) 사용된 쿠폰 리셋
				//  3) 관련 테이블 이력 정보 등록하기
				this.afterProcPrvsnlLimitOrderFail(targetLimitOrderNo);
			}
		} catch(Exception e) {
			String stacktrace = ExceptionUtils.getStackTrace(e);
			log.error("[limitOrderFail][복수] : " + stacktrace);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 가단가 지정가 주문 실패 상태 처리 이후 후처리
	 *  1) 지정가 주문 실패 SMS 발송
	 *  2) 쿠폰 사용 원복
	 *  3) 관련 지정가 테이블 이력 정보 등록
	 * </pre>
	 * @date 2024. 10. 31.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 31.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public void afterProcPrvsnlLimitOrderFail(String limitOrderNo) throws Exception  {

		// 1. 지정가 주문 체결 실패 SMS 발송
		this.prvsnlLimitOrderFailSendSms(limitOrderNo);

		// 2. 쿠폰 사용 원복
		commLimitOrderService.limitOrderCouponUpdate(limitOrderNo, "LIMIT_SYSTEM");

		// 3. 관련 지정가 테이블 이력 정보 등록
		String limitSeCode = limitOrderNo.substring(9, 10); // 지정가 구분 코드
		Map<String, String> keyValues = Collections.singletonMap("LIMIT_ORDER_NO", limitOrderNo);
		if("F".equals(limitSeCode)) {
			commonService.insertTableHistory("OR_LIMIT_ORDER_LME_BAS", keyValues);  // LME
		} else if("X".equals(limitSeCode)) {
			commonService.insertTableHistory("OR_LIMIT_ORDER_EHGT_BAS", keyValues); // 환율
		} else if("R".equals(limitSeCode)) {
			commonService.insertTableHistory("OR_LIMIT_ORDER_KRW_BAS", keyValues);  // KRW
		}
	}

	/**
	 * 가단가 지정가 주문 체결 실패 SMS 발송 (템플릿 108)
	 */
	@Override
	public void prvsnlLimitOrderFailSendSms(String limitOrderNo) {
		try {
			// sms 데이터 조회
			Map<String, String> params = Collections.singletonMap("limitOrderNo", limitOrderNo);
			Map<String, String> smsMap = commPrvsnlOrderMapper.selectPrvsnlLimitOrderCancelSmsInfo(params);
			if (null == smsMap) {
				throw new Exception("지정가 주문 데이터 조회 실패 : 지정가번호 "+ limitOrderNo);
			}

			SMSVO smsVO = new SMSVO();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));

			String encPhon = String.valueOf(smsMap.get("ordrrMoblphonNo"));
			if (StringUtils.isNotBlank(encPhon) && !encPhon.equals("null")) {
				log.debug("휴대전화 번호 복호화 전 ==================>" + encPhon);
				String decPhone = CryptoUtil.decryptAES256(encPhon);
				log.debug("휴대전화 번호 복호화 후 ==================>" + decPhone);
				/** 휴대전화 번호 셋팅 **/
				smsVO.setPhone(decPhone);
			}

//			smsVO.setPhone("test phon number");
			smsVO.setMberNo(smsMap.get("mberNo"));
			smsVO.setCommerceNtcnAt("Y"); // 커머스 알림 여부

			smsMap.put("templateNum", "108");
			smsMap.put("commerceNtcnCn", "지정가 주문 체결 실패"); // 커머스 알림 메시지
			smsMap.put("excpSndngOptnAt", ""); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다. (빈 값일 때 고객, 내부 모두 발송)

			smsService.insertSMS(smsVO, smsMap);

		} catch (Exception e) {
			log.error("지정가 주문 체결 실패 SMS 전송 실패 : "+ e.getMessage());
		}
	}

	/**
	 *  가단가 지정가 주문 취소 SMS 발송 (템플릿 110 (주문 취소), 128 (주문 자동 취소))
	 */
	@Override
	public void prvsnlLimitOrderCancelSendSms(String limitOrderNo, String batchType) {
		try {
			// sms 데이터 조회
			Map<String, String> params = new HashMap<>();
			params.put("limitOrderNo", limitOrderNo);
			params.put("codeSe", "Y");
			Map<String, String> smsMap = commPrvsnlOrderMapper.selectPrvsnlLimitOrderCancelSmsInfo(params);
			if (null == smsMap) {
				throw new Exception("가단가 지정가 주문 데이터 조회 실패 : 지정가번호 "+ limitOrderNo);
			}

			SMSVO smsVO = new SMSVO();
			smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));

			String encPhon = String.valueOf(smsMap.get("ordrrMoblphonNo"));
			if (StringUtils.isNotBlank(encPhon) && !encPhon.equals("null")) {
				log.debug("휴대전화 번호 복호화 전 ==================>" + encPhon);
				String decPhone = CryptoUtil.decryptAES256(encPhon);
				log.debug("휴대전화 번호 복호화 후 ==================>" + decPhone);
				/** 휴대전화 번호 셋팅 **/
				smsVO.setPhone(decPhone);
			}

//			smsVO.setPhone("test phon number");
			smsVO.setMberNo(smsMap.get("mberNo"));
			smsVO.setCommerceNtcnAt("Y"); // 커머스 알림 여부

			if(batchType.equals("Y")){
				smsMap.put("templateNum", "128");
				smsMap.put("commerceNtcnCn", "지정가 자동 주문 취소"); // 커머스 알림 메시지
			}else {
				smsMap.put("templateNum", "110");
				smsMap.put("commerceNtcnCn", "지정가 주문 취소"); // 커머스 알림 메시지
			}
			smsMap.put("excpSndngOptnAt", ""); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다. (빈 값일 때 고객, 내부 모두 발송)

			smsService.insertSMS(smsVO, smsMap);

		} catch (Exception e) {
			log.error("지정가 주문 체결 실패 SMS 전송 실패 : "+ e.getMessage());
		}
	}

	/**
	 * <pre>
	 * 처리내용: 가장 최근 가격정보 조회 (프리미엄 제외 endPc)
	 * </pre>
	 * @date 2024. 11. 4.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 11. 4.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	@Override
	public PrSelVO getPreRealEndPc(String metalCode, Integer itmSn, String dstrcLclsfCode, String brandGroupCode, String brandCode) {
		PrSelVO prSelVO = new PrSelVO();

		if((metalCode == null || "".equals(metalCode)) && (itmSn == null || itmSn == 0) && (dstrcLclsfCode == null || "".equals(dstrcLclsfCode))
				 && (brandGroupCode == null || "".equals(brandGroupCode)) && (brandCode == null || "".equals(brandCode))) {
			return null;
		}

		prSelVO.setMetalCode(metalCode);
		prSelVO.setItmSn(itmSn);
		prSelVO.setDstrctLclsfCode(dstrcLclsfCode);
		prSelVO.setBrandGroupCode(brandGroupCode);
		prSelVO.setBrandCode(brandCode);

		return commPrvsnlOrderMapper.getPreRealEndPc(prSelVO);
	}

	/**
	 *  가격 변동금 기본 조회
	 */
	@Override
	public CommPrvsnlOrderVO selectOrPcChangegldBas(String orderNo, int occrrncSn) throws Exception {
		// 파라미터
		CommPrvsnlOrderVO param = new CommPrvsnlOrderVO();
		param.setOrderNo(orderNo);
		param.setOccrrncSn(occrrncSn);

		return commPrvsnlOrderMapper.selectOrPcChangegldBas(param);
	}
	
	/**
	 * 입금에 따른 가격 변동금 정보 수정
	 */
	@Override
	public void updateOrPcOrPcChangegldBasByRcpmny(String orderNo, int occrrncSn, String setleNo, String mberId) throws Exception {
		CommPrvsnlOrderVO commPrvsnlOrderVO = new CommPrvsnlOrderVO();
		commPrvsnlOrderVO.setOrderNo(orderNo);
		commPrvsnlOrderVO.setOccrrncSn(occrrncSn);
		commPrvsnlOrderVO.setSetleNo(setleNo);
		commPrvsnlOrderVO.setMberId(mberId);
		
		commPrvsnlOrderMapper.updateOrPcOrPcChangegldBasByRcpmny(commPrvsnlOrderVO);
		
		// OR_PC_CHANGEGLD_BAS(주문_가격 변동금 기본) 이력 등록
		commonService.insertTableHistory("OR_PC_CHANGEGLD_BAS", commPrvsnlOrderVO);
	}
	
	/**
	 * 출금에 따른 가격 변동금 정보 수정
	 */
	@Override
	public void updateOrPcOrPcChangegldBasByDefray(String orderNo, int occrrncSn, String setleNo, String mberId) throws Exception {
		CommPrvsnlOrderVO commPrvsnlOrderVO = new CommPrvsnlOrderVO();
		commPrvsnlOrderVO.setOrderNo(orderNo);
		commPrvsnlOrderVO.setOccrrncSn(occrrncSn);
		commPrvsnlOrderVO.setSetleNo(setleNo);
		commPrvsnlOrderVO.setMberId(mberId);
		
		commPrvsnlOrderMapper.updateOrPcOrPcChangegldBasByDefray(commPrvsnlOrderVO);
		
		// OR_PC_CHANGEGLD_BAS(주문_가격 변동금 기본) 이력 등록
		commonService.insertTableHistory("OR_PC_CHANGEGLD_BAS", commPrvsnlOrderVO);
	}
}
