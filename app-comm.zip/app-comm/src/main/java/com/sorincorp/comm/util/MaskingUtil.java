package com.sorincorp.comm.util;

import org.apache.commons.lang3.StringUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * 마스킹이 필요한 필드에 마스킹 및 마스킹 해제처리를 위한 Util
 * MaskingUtil.java
 * @version
 * @since 2021. 8. 9.
 * @author srec0012
 */
@Slf4j
public class MaskingUtil {

	private MaskingUtil() {
		log.debug(MaskingUtil.class.getSimpleName());
	}
	
	/**
	 * 
	 * <pre>
	 * 단방향 암호화
	 * </pre>
	 * @date 2021. 8. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param pass
	 * @return
	 * @throws Exception
	 */
	public static String maskEncrypt(String pass) throws Exception  {
		return CryptoUtil.encryptSHA256(pass);
	}
	
	/**
	 * 
	 * <pre>
	 * 이메일 Masking (Sample)
	 * </pre>
	 * @date 2021. 8. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param email
	 * @return
	 */
	public static String maskEmail(String email) {
		if (StringUtils.isBlank(email)) {
			return "";
		}
		int index = StringUtils.indexOf(email, "@");
		if (index <= 1)
			return email;
		else
			return StringUtils.rightPad(StringUtils.left(email, 1), index, "*")
					.concat(StringUtils.mid(email, index, StringUtils.length(email)));
	}

}
