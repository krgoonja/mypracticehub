package com.sorincorp.comm.invntry.model;

import javax.validation.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * InvntrySttusVO.java
 * 재고 현황 공통 VO 객체
 * @version
 * @since 2023. 6. 27.
 * @author srec0066
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InvntrySttusVO {

	/** 금속 코드 */
	private String metalCode;

	/** 아이템 순번 */
	private int itmSn;

	/** 권역 대분류 코드 */
	private String dstrctLclsfCode;

	/** 브랜드 그룹 코드 */
	private String brandGroupCode;

	/** 브랜드 코드 */
	private String brandCode;

	/** BL 번호 */
	private String blNo;

	/** 판매 재고 미판매 번들 잔량 */
	private long sleInvntryUnsleBundleBnt;

	/** 판매 재고 미판매 번들 총 잔량 */
	private long totSleInvntryUnsleBundleBnt;

	/** 소량 구매 여부 */
	private String smlqyPurchsAt;

	/** 선물 잔량 */
	private int remainQy;

	/** 소량 판매 선물 여부 */
	private String smlqySleFtrsAt;
}
