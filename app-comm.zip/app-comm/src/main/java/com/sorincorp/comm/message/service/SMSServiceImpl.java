package com.sorincorp.comm.message.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.sorincorp.comm.message.mapper.SMSMapper;
import com.sorincorp.comm.message.model.AppPushQueueVO;
import com.sorincorp.comm.message.model.KkoMsgVO;
import com.sorincorp.comm.message.model.MessageTemplateVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@PropertySource(value = "classpath:/config/sms/sms-${spring.profiles.active}.properties", ignoreResourceNotFound = true)
public class SMSServiceImpl implements SMSService {
	private static final String TEMPLATE_NUM = "templateNum";
	private static final String SNDNG_GROUP_CODE = "sndngGroupCode"; // 발송 그룹 코드
	private static final String EXCP_SNDNG_OPTN_AT = "excpSndngOptnAt"; // 예외 발송 옵션 여부

	/** 카카오 프로필키 **/
	@Value("${kkoMsg.profileKey}")
	private String profileKey;

	@Autowired
	private SMSMapper mapper;

	@Value("${spring.profiles.active}")
	private String profiles;


	/**
	 * 메시지 템플릿에 저장된 템플릿정보 조회
	 */
	public MessageTemplateVO selectMessageTemplate(String templateNum) {
		return mapper.selectMessageTemplate(templateNum);
	}

	/**
	 * <pre>
	 * 처리내용: SMS 또는 LMS 발송 및 알림톡 발송 및 sms 발송 히스토리 입력 공통 메소드
	 * </pre>
	 * @date 2023. 1. 3.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 1. 3.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param smsVO
	 * @param map
	 */
	public void insertSMSSendComm(SMSVO smsVO, Map<String, String> map) {
		SMSVO dataVo = new SMSVO();
		try {
			// 휴대전화 번호가 없으면 발송하지 않는다.
			if(StringUtil.isEmpty(smsVO.getPhone())) {
				log.debug(">> [SMSServiceImpl][insertSMS] 휴대전화 번호가 존재하지 않음");
			} else {
				dataVo = mapper.selectMberNoAndSmsKkoSe(CryptoUtil.encryptAES256(smsVO.getPhone()));
				String tempNum = map.get(TEMPLATE_NUM);
				MessageTemplateVO messageVO = selectMessageTemplate(tempNum);
				boolean returnresult = false;
				
				// OP_MSSAGE_TMPLAT_BAS광고 메세지 여부(ADVRTS_MSSAGE_AT), MB_MBER_INFO_INFO,MB_SIMPL_MBER_INFO_BAS 마케팅 동의 여부(ADVRTS_RECPTN_AGRE_AT)
				// ADVRTS_MSSAGE_AT : Y ,ADVRTS_RECPTN_AGRE_AT: Y 보내기O
				// ADVRTS_MSSAGE_AT : Y ,ADVRTS_RECPTN_AGRE_AT: N 보내기X
				// ADVRTS_MSSAGE_AT : N ,ADVRTS_RECPTN_AGRE_AT: Y 보내기O
				// ADVRTS_MSSAGE_AT : N ,ADVRTS_RECPTN_AGRE_AT: N 보내기O
				
				// MBER_SE_CODE : 05 : 차량담당자 추가로 인한 메일, SMS 수신 제외 기능 추가
				// MBER_SE_CODE : 05 > CODE_REFRNONE : N : 차량담당자 : 메일, SMS 수신 안함
				// MBER_AT : 내부사용자 여부 > 내부사용자 : 광고 무관 전부 수신 
				
				// 내부사용자 아님
				if(!dataVo.getMberAt().equals("Y")) {
					// 멤버 권한에 따른 SMS 수신 여부 확인
					if(!dataVo.getCodeRefrnone().equals("N")) {
						//광고, 마케팅 동의 여부 확인 
						if(!(messageVO.getAdvrtsMssageAt().equals("Y") && dataVo.getAdvrtsRecptnAgreAt().equals("N"))) {
							returnresult = true;
						}else {
							returnresult = false;
						}
					}else {
						returnresult = false;
					}
				//내부사용자 : 광고 여부 상관 없이 모든 SMS 수신
				}else {
					returnresult = true;
				}
				
				if(returnresult) {
					if(!StringUtil.isBlank(dataVo.getSmsKkoSe())) {
						smsVO.setSmsKkoSe(dataVo.getSmsKkoSe()); //SMS/알림톡 구분
					}
					insertSMSComm(smsVO, map); // SMS 또는 LMS 발송 및 알림톡 발송
					
					if(StringUtil.isBlank(smsVO.getMsgTitle())) { // 제목이 null, "", " " 인 경우
						smsVO.setMsgTitle(messageVO.getMssageTmplatSj()); // 메시지 제목 셋팅
					}
					smsVO.setPhone(CryptoUtil.encryptAES256(smsVO.getPhone()));
					smsVO.setMberNo(dataVo.getMberNo()); //멤버번호 추가
					
					mapper.insertSMSHistory(smsVO); // sms 발송 히스토리 입력
				}
			}
		} catch (Exception e) {
			log.error(ExceptionUtils.getStackTrace(e));
		}
	}

	/*
	 map
	1.
	 mssageTmplatNo 조회할 템플릿 번호
	 mssageTmplateNo : 1
 	2.
	 템플릿의 바꿀내용 작성
	 {{ITEM_NAME}} : 아이템이름임
	 {{DELIVERY_FEE}} : 2500

     smsVO
	 smsVO.phone : 받을 전화번호
	 smsVO.reqDate : 전송시간(예약시)
	 smsVO.mberNo : 회원번호 (SMSHistory 에서 사용 / 내부사용자에게만 전송시 회원번호 "00000" 고정)
	 smsVO.mberKndSeCode : 회원종류 구분코드

	 -------------------- 커머스 알림 발송 시 --------------------
	 smsVO.commerceNtcnAt : 커머스 알림 여부 (insertSMSHistory)
	 smsVO.commerceNtcnCn : 커머스 알림 내용 (insertSMSHistory)
	 * */
	/**
	 * SMS 또는 LMS 발송 및 알림톡 발송, sms 발송 히스토리 입력
	 *   예외 발송 옵션 여부(excpSndngOptnAt)가 Y이면 SMS 수신자는 보내지 않는다
	 *   예외 발송 옵션 여부(excpSndngOptnAt)가 N이면 내부사용자는 보내지 않는다
	 *   예외 발송 옵션 여부(excpSndngOptnAt)가 null이거나 값이 존재하지 않으면 SMS 수신자, 내부사용자 모두 보낸다.
	 */
	@Override
	public void insertSMS(SMSVO smsVO, Map<String, String> map) {
		if(null == map || StringUtil.isEmpty(map.get(TEMPLATE_NUM)) || StringUtils.equals(map.get(TEMPLATE_NUM), "null")) {
			// 템플릿 번호가 없으면 발송하지 않는다.
			log.debug(">> [SMSServiceImpl][insertSMS] 템플릿 번호가 존재하지 않음");
		} else if(null == smsVO && StringUtil.isEmpty(map.get(EXCP_SNDNG_OPTN_AT))) {
			// SMS정보가 없으면 발송하지 않는다.
			log.debug(">> [SMSServiceImpl][insertSMS] SMS 전송정보가 존재하지 않음");
		} else {
			String tempNum = String.valueOf(map.get(TEMPLATE_NUM));
			String excpSndngOptnAt = String.valueOf(map.get(EXCP_SNDNG_OPTN_AT)); // 예외 발송 옵션 여부
			log.debug(">> [SMSServiceImpl][insertSMS] tempNum : " + tempNum + ", excpSndngOptnAt : " + excpSndngOptnAt);
		
			if(!StringUtils.equals(excpSndngOptnAt, "Y")) {
				// 예외 발송 옵션 여부가 Y가 아닐때 발송, Y이면 SMS 수신자는 보내지 않는다
				insertSMSSendComm(smsVO, map); // SMS 또는 LMS 발송 및 알림톡 발송 및 sms 발송 히스토리 입력 공통 메소드
			} else {
				// 예외 발송 옵션 여부가 Y일 때, Y이면 SMS 내부사용자 발송
				MessageTemplateVO messageVO = selectMessageTemplate(tempNum);
				map.put(SNDNG_GROUP_CODE, messageVO.getSndngGroupCode()); // 발송 그룹 코드 set
			}
 
			String sndngGroupCode = String.valueOf(map.get(SNDNG_GROUP_CODE)); // 발송 그룹 코드
			log.debug(">> [SMSServiceImpl][insertSMS] sndngGroupCode : " + sndngGroupCode);

			// 예외 발송 옵션 여부가 N이 아닐때 발송, N이면 내부사용자는 보내지 않는다
			if(!StringUtils.equals(excpSndngOptnAt, "N")) {
				if(StringUtils.isEmpty(sndngGroupCode) || StringUtils.equals(sndngGroupCode, "null")) {
					log.debug(">> [SMSServiceImpl][insertSMS] 내부사용자 SMS 발송 사용안함");
				} else {
					// 발송그룹코드가 있을 경우 해당 내부사용자들에 SMS 또는 LMS 발송 및 알림톡 발송 및 sms 발송 히스토리 입력
					innerDepartmentSendSms(map);
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void insertKkoMsg(KkoMsgVO kkoVO, Map<String, String> map) throws Exception {
		if(null == kkoVO) {
			// 알림톡정보가 없으면 발송하지 않는다.
			log.debug(">> [SMSServiceImpl][insertSMS] 알림톡 전송정보가 존재하지 않음");
		} else if(null == map || StringUtil.isEmpty(map.get(TEMPLATE_NUM)) || StringUtils.equals(map.get(TEMPLATE_NUM), "null")) {
			// 템플릿 번호가 없으면 발송하지 않는다.
			log.debug(">> [SMSServiceImpl][insertSMS] 템플릿 번호가 존재하지 않음");
		} else {
			MessageTemplateVO messageVO = selectMessageTemplate(map.get(TEMPLATE_NUM));
			String kkoMsg = translateContents(messageVO.getAlimTmplatCn(), map);
			String smsMsg = translateContents(messageVO.getSmsTmplatCn(), map);
			String phone = CryptoUtil.encryptAES256(kkoVO.getPhone());
			
			// 휴대전화 번호가 없으면 발송하지 않는다.
			if(StringUtil.isEmpty(phone) || StringUtils.equals(phone, "null")) {
				log.debug(">> [SMSServiceImpl][insertKkoMsg] 휴대전화 번호가 존재하지 않음");
			}
	
			SMSVO dataVo = new SMSVO();
	
			try {
				dataVo = mapper.selectMberNoAndSmsKkoSe(CryptoUtil.encryptAES256(kkoVO.getPhone()));
				boolean returnresult = false;
				
				// OP_MSSAGE_TMPLAT_BAS광고 메세지 여부(ADVRTS_MSSAGE_AT), MB_MBER_INFO_INFO,MB_SIMPL_MBER_INFO_BAS 마케팅 동의 여부(ADVRTS_RECPTN_AGRE_AT)
				// ADVRTS_MSSAGE_AT : Y ,ADVRTS_RECPTN_AGRE_AT: Y 보내기O
				// ADVRTS_MSSAGE_AT : Y ,ADVRTS_RECPTN_AGRE_AT: N 보내기X
				// ADVRTS_MSSAGE_AT : N ,ADVRTS_RECPTN_AGRE_AT: Y 보내기O
				// ADVRTS_MSSAGE_AT : N ,ADVRTS_RECPTN_AGRE_AT: N 보내기O

				// MBER_SE_CODE : 05 : 차량담당자 추가로 인한 메일, SMS 수신 제외 기능 추가
				// MBER_SE_CODE : 05 > CODE_REFRNONE : N : 차량담당자 : 메일, SMS 수신 안함
				// MBER_AT : 내부사용자 여부 > 내부사용자 : 광고 무관 전부 수신 
				
				if(!dataVo.getMberAt().equals("Y")) {
					// 멤버 권한에 따른 SMS 수신 여부 확인
					if(!dataVo.getCodeRefrnone().equals("N")) {
						//광고, 마케팅 동의 여부 확인 
						if(!(messageVO.getAdvrtsMssageAt().equals("Y") && dataVo.getAdvrtsRecptnAgreAt().equals("N"))) {
							returnresult = true;
						}else {
							returnresult = false;
						}
					}else {
						returnresult = false;
					}
				//내부사용자 : 광고 여부 상관 없이 모든 SMS 수신
				}else {
					returnresult = true;
				}
				
				if(returnresult) {
					//알림톡발송 기본Column구성
					kkoVO.setCallback(messageVO.getMssageSntoTelno());
					kkoVO.setMsg(kkoMsg);
					kkoVO.setTemplateCode(messageVO.getAlimKakaoTmplatNo());
		
					if(kkoVO.getMsg().getBytes().length <= 90) { //90바이트 넘으면 LMS
						kkoVO.setFailedType("SMS");
					} else {
						kkoVO.setFailedType("LMS");
					}
		
					kkoVO.setFailedSubject(messageVO.getMssageTmplatSj());
					kkoVO.setFailedMsg(smsMsg);
					kkoVO.setProfileKey(profileKey);
		
					if(map.get("urlMobile") != null) {
						Map<String, Object> btnJsonMap = new HashMap<>();
						btnJsonMap.put("name", map.get("urlName"));
						btnJsonMap.put("type", "WL");
						btnJsonMap.put("url_pc", map.get("urlPc"));
						btnJsonMap.put("url_mobile", map.get("urlMobile"));
		
						List<Map<String, Object>> btnJsonMapList= new ArrayList<>();
						btnJsonMapList.add(btnJsonMap);
		
						Map<String, Object> btnJson = new JSONObject();
						btnJson.put("button", btnJsonMapList);
						kkoVO.setButtonJson(btnJson.toString());
					}
		
					mapper.insertKkoMsg(kkoVO);
		
					kkoVO.setMsgTitle(messageVO.getMssageTmplatSj()); // 템플릿에 등록되어있는 제목 셋팅
					kkoVO.setPhone(CryptoUtil.encryptAES256(kkoVO.getPhone()));
					kkoVO.setMberNo(dataVo.getMberNo()); //멤버번호 추가
					mapper.insertKkoMsgHistory(kkoVO);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// 예약발송하려면 sendDate 변경 setSendDate("yyyy-MM-dd HH:mm:ss")
	// 광고 동의한사람한테 보낼꺼면 optAgree == 1000 일때
	// labelCode 라벨코드
	// bgColor 알림영역 배경색
	// fontColor 폰트색
	// msgTitle 제목
	// customKey1 추가적인 변수키 3개 (2,3)
	// customValue1 추가적인 변수값 3개 (2,3)
	@Override
	public void insertAppPush(AppPushQueueVO appVO, Map<String, String> map) {

	//주석 사유 : (운영관리  - 메시지 발송내역 (apppush 관리가 안되고 있음)) - 2023/03/02 - 박세인
	/*
		MessageTemplateVO messageVO = selectMessageTemplate(map.get(TEMPLATE_NUM));
		appVO.setAppKey(CommonConstants.APP_PUSH_KEY); // 앱키 설정
		appVO.setAppSecret(CommonConstants.APP_PUSH_SECRET_KEY);
		appVO.setMsgContents(translateContents(messageVO.getPushTmplatCn(), map));
		appVO.setEtc2(messageVO.getPushReturnUrl());
		appVO.setPMode("STOS");
		appVO.setCustomKey1("jsondata");
		appVO.setCustomValue1("{type: " + appVO.getType() + ", url: \"" + appVO.getUrl() +"\"}");
		appVO.setCustomKey3(String.valueOf(messageVO.getMssageTmplatNo())); // 메시지 템플릿 번호

		//appVO.setIdentify("sorincorp");
		appVO.setIdentify(appVO.getIdentify());

		//임시로 appPush 막음 2022-02-08 권순형
//		if(profiles.equals("local") || profiles.equals("dev")) {
			mapper.insertAppPush(appVO);

			try {
				appVO.setCallback(CryptoUtil.encryptAES256(appVO.getCallback()));
				mapper.insertAppPushHistory(appVO);
			} catch (Exception e) {
				log.error("insertAppPush Error ====> {}", ExceptionUtils.getStackTrace(e));
			}
//		}
	*/
		log.debug(">> [SMSServiceImpl][insertAppPush] AppPush기능 관리가 안되기 때문에 막음");
	}

	// 문자열 변환
	public String translateContents(String contents, Map<String, String> map) {
		//		return contents.replace("{ITEM_NAME}", map.get("itemName") != null ? map.get("itemName") : "")
		//					   .replace("{DELIVERY_FEE}", map.get("deliveryFee") != null ? map.get("deliveryFee") : "")
		//					   .replace("{NUMBER}", map.get("authNum") != null ? map.get("authNum") : "");
		for(Map.Entry<String, String> entry : map.entrySet()) {
			contents = contents.replace("{{"+ entry.getKey()+"}}", StringUtil.nvl(entry.getValue(), ""));
		}

		return contents;
	}

	/**
	 * <pre>
	 * 처리내용: 발송그룹코드가 있을 경우 해당 내부사용자들에 SMS 또는 LMS 발송 및 알림톡 발송 및 sms 발송 히스토리 입력
	 * </pre>
	 * @date 2023. 1. 3.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 1. 3.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param map
	 */
	public void innerDepartmentSendSms(Map<String, String> map) {
		SMSVO smsVO = new SMSVO();
		smsVO.setReqDate(DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss"));
		smsVO.setMberNo("00000");
		smsVO.setCommerceNtcnAt("N"); // 커머스 알림 여부 (2022.07.22 알림내역 비노출, 내부사용자에게 발송하는 메세지는 'N' 설정)

		if(!StringUtil.isBlank(map.get("msg"))) { // Msg가 Null일 경우에는 템플릿 세팅
			smsVO.setMsg(map.get("msg"));
		}
		
		List<Map<String, String>> selectReceiverList = mapper.selectReceiverList(map.get(SNDNG_GROUP_CODE)); // 추가 수신자 그룹 조회
		if (!CollectionUtils.isEmpty(selectReceiverList)) {
			for (Map<String, String> receiverMap : selectReceiverList) {
				String cryalTlphonNo = receiverMap.get("CRYAL_TLPHON_NO"); // 휴대 전화 번호
				// CRYAL_TLPHON_NO(휴대 전화 번호) 복호화
				if (StringUtil.isNotBlank(cryalTlphonNo)) {
					try {
						cryalTlphonNo = CryptoUtil.decryptAES256(cryalTlphonNo);
						smsVO.setPhone(cryalTlphonNo); // 수신 핸드폰 번호
					} catch (Exception e) {
						ExceptionUtils.getStackTrace(e);
					}
				}
				insertSMSSendComm(smsVO, map); // SMS 또는 LMS 발송 및 알림톡 발송 및 sms 발송 히스토리 입력 공통 메소드
			}
		}
	}

	/**
	 * SMS 또는 LMS 발송 및 알림톡 발송, sms 발송 히스토리 입력 후 mssageSndngHistNo 리턴
	 *   예외 발송 옵션 여부(excpSndngOptnAt)가 Y이면 SMS 수신자는 보내지 않는다
	 *   예외 발송 옵션 여부(excpSndngOptnAt)가 N이면 내부사용자는 보내지 않는다
	 *   예외 발송 옵션 여부(excpSndngOptnAt)가 null이거나 값이 존재하지 않으면 SMS 수신자, 내부사용자 모두 보낸다.
	 */
	@Override
	public String insertSMSByReturnMssageSndngHistNo(SMSVO smsVO, Map<String, String> map) {
		String tempNum = String.valueOf(map.get(TEMPLATE_NUM));
		String excpSndngOptnAt = String.valueOf(map.get(EXCP_SNDNG_OPTN_AT)); // 예외 발송 옵션 여부
		log.debug(">> [SMSServiceImpl][insertSMSByReturnMssageSndngHistNo] tempNum : " + tempNum + ", excpSndngOptnAt : " + excpSndngOptnAt);

		MessageTemplateVO messageVO = selectMessageTemplate(tempNum);

		String mssageSndngHistNo = "";

		// 템플릿 번호가 없으면 발송하지 않는다.
		if(null == map || StringUtil.isEmpty(tempNum) || StringUtils.equals(tempNum, "null")) {
			log.debug(">> [SMSServiceImpl][insertSMSByReturnMssageSndngHistNo] 템플릿 번호가 존재하지 않음");
		} else {
			SMSVO dataVo = new SMSVO();
			try {
				dataVo = mapper.selectMberNoAndSmsKkoSe(CryptoUtil.encryptAES256(smsVO.getPhone()));
				boolean returnresult = false;
				
				// OP_MSSAGE_TMPLAT_BAS광고 메세지 여부(ADVRTS_MSSAGE_AT), MB_MBER_INFO_INFO,MB_SIMPL_MBER_INFO_BAS 마케팅 동의 여부(ADVRTS_RECPTN_AGRE_AT)
				// ADVRTS_MSSAGE_AT : Y ,ADVRTS_RECPTN_AGRE_AT: Y 보내기O
				// ADVRTS_MSSAGE_AT : Y ,ADVRTS_RECPTN_AGRE_AT: N 보내기X
				// ADVRTS_MSSAGE_AT : N ,ADVRTS_RECPTN_AGRE_AT: Y 보내기O
				// ADVRTS_MSSAGE_AT : N ,ADVRTS_RECPTN_AGRE_AT: N 보내기O
				
				// MBER_SE_CODE : 05 : 차량담당자 추가로 인한 메일, SMS 수신 제외 기능 추가
				// MBER_SE_CODE : 05 > CODE_REFRNONE : N : 차량담당자 : 메일, SMS 수신 안함
				// MBER_AT : 내부사용자 여부 > 내부사용자 : 광고 무관 전부 수신 

				// 내부사용자 아님
				if(!dataVo.getMberAt().equals("Y")) {
					// 멤버 권한에 따른 SMS 수신 여부 확인
					if(!dataVo.getCodeRefrnone().equals("N")) {
						//광고, 마케팅 동의 여부 확인 
						if(!(messageVO.getAdvrtsMssageAt().equals("Y") && dataVo.getAdvrtsRecptnAgreAt().equals("N"))) {
							returnresult = true;
						}else {
							returnresult = false;
						}
					}else {
						returnresult = false;
					}
				//내부사용자 : 광고 여부 상관 없이 모든 SMS 수신
				}else {
					returnresult = true;
				}
				
				if(returnresult) {
					if(!StringUtil.isBlank(dataVo.getSmsKkoSe())) {
						smsVO.setSmsKkoSe(dataVo.getSmsKkoSe()); //SMS/알림톡 구분
					}
	
					if(!StringUtils.equals(excpSndngOptnAt, "Y")) {
						// 예외 발송 옵션 여부가 Y가 아닐때 발송, Y이면 SMS 수신자는 보내지 않는다
						smsVO = insertSMSComm(smsVO, map); // SMS 또는 LMS 발송 및 알림톡 발송
					} else {
						// 예외 발송 옵션 여부가 Y일 때, Y이면 SMS 내부사용자 발송
						// MessageTemplateVO messageVO = selectMessageTemplate(tempNum);
						map.put("sndngGroupCode", messageVO.getSndngGroupCode()); // 발송 그룹 코드 set
					}
					smsVO.setPhone(CryptoUtil.encryptAES256(smsVO.getPhone()));
					smsVO.setMberNo(dataVo.getMberNo()); //멤버번호 추가
					if(StringUtil.isBlank(smsVO.getMsgTitle())) { // 제목이 null, "", " " 인 경우
						smsVO.setMsgTitle(messageVO.getMssageTmplatSj()); // 메시지 제목 셋팅
					}
					mapper.insertSMSHistoryByReturnMssageSndngHistNo(smsVO); // sms 발송 히스토리 입력 후 mssageSndngHistNo 리턴
					mssageSndngHistNo = smsVO.getMssageSndngHistNo();
				}
			} catch (Exception e) {
				log.error(ExceptionUtils.getStackTrace(e));
			}

			String sndngGroupCode = String.valueOf(map.get(SNDNG_GROUP_CODE)); // 발송 그룹 코드
			log.debug(">> [SMSServiceImpl][insertSMSByReturnMssageSndngHistNo] sndngGroupCode : " + sndngGroupCode);

			// 예외 발송 옵션 여부가 N이 아닐때 발송, N이면 내부사용자는 보내지 않는다
			if(!StringUtils.equals(excpSndngOptnAt, "N")) {
				if(StringUtils.isEmpty(sndngGroupCode) || StringUtils.equals(sndngGroupCode, "null")) {
					log.debug(">> [SMSServiceImpl][insertSMSByReturnMssageSndngHistNo] 내부사용자 SMS 발송 사용안함");
				} else {
					map.put("msgTitle", messageVO.getMssageTmplatSj()); // 메세지 제목 셋팅

					// 발송그룹코드가 있을 경우 해당 내부사용자들에 SMS 또는 LMS 발송 및 알림톡 발송 및 sms 발송 히스토리 입력
					innerDepartmentSendSms(map);
				}
			}
		}

		return mssageSndngHistNo;
	}

	/**
	 * <pre>
	 * 처리내용: SMS 또는 LMS 발송 및 알림톡 발송
	 * </pre>
	 * @date 2023. 1. 3.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 1. 3.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param smsVO
	 * @param map
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public SMSVO insertSMSComm(SMSVO smsVO, Map<String, String> map) {
		String tempNum = map.get(TEMPLATE_NUM);
		MessageTemplateVO messageVO = selectMessageTemplate(tempNum);
		map.put("sndngGroupCode", messageVO.getSndngGroupCode()); // 발송 그룹 코드 set

		smsVO.setCallback(messageVO.getMssageSntoTelno());
		smsVO.setEtc1(String.valueOf(messageVO.getMssageTmplatNo())); // 메시지 템플릿 번호

		String alimUseAt = messageVO.getAlimUseAt() != null ? messageVO.getAlimUseAt() : "";
		String smsUseAt = messageVO.getSmsUseAt() != null? messageVO.getSmsUseAt() : "";

		//템플릿이 문자일 경우만 템플릿 설정값으로 적용하고 나머지는 사용자 설정값값
		if ("Y".equals(alimUseAt)) { //알림톡 전송시
			if( smsVO.getSmsKkoSe().equals("SMS") ) {
				smsUseAt = "Y";
				alimUseAt = "N";
			}else if( smsVO.getSmsKkoSe().equals("KKO") ) {
				smsUseAt = "N";
				alimUseAt = "Y";
			}else { //기본 카카오
				smsUseAt = "N";
				alimUseAt = "Y";
			}
		}


		if(StringUtil.isBlank(smsVO.getMsgTitle())) { // 제목이 null, "", " " 인 경우
			smsVO.setMsgTitle(messageVO.getMssageTmplatSj()); // 메시지 제목 셋팅
		}

		if ("Y".equals(smsUseAt) && "N".equals(alimUseAt)) { //문자전송시
			if(StringUtil.isBlank(smsVO.getMsg())) { // Msg가 Null일 경우에는 템플릿 세팅
				smsVO.setMsg(translateContents(messageVO.getSmsTmplatCn(), map));
			}

			smsVO.setType("0");

			if(smsVO.getMsg().getBytes().length <= 90) { //90바이트 넘으면 LMS
				smsVO.setMsgSeCode("03");
				mapper.insertSMS(smsVO);
			} else {
				smsVO.setMsgSeCode("04");
				mapper.insertLMS(smsVO);
			}
		} else if ("Y".equals(alimUseAt)) { //알림톡전송시
			String kkoMsg = translateContents(messageVO.getAlimTmplatCn(), map);
			String smsMsg = translateContents(messageVO.getSmsTmplatCn(), map);

			//알림톡발송 기본Column구성
			smsVO.setCallback(messageVO.getMssageSntoTelno());
			smsVO.setMsg(kkoMsg);
			smsVO.setTemplateCode(messageVO.getAlimKakaoTmplatNo());
			smsVO.setMsgSeCode("02");

			if(smsVO.getMsg().getBytes().length <= 90) { //90바이트 넘으면 LMS
				smsVO.setFailedType("SMS");
			} else {
				smsVO.setFailedType("LMS");
			}

			//전송실패시 SMS메시지구성
			smsVO.setFailedSubject(messageVO.getMssageTmplatSj());
			smsVO.setFailedMsg(smsMsg);
			smsVO.setProfileKey(profileKey);

			//웹링크URL설정
			if(map.get("urlMobile") != null && map.get("urlName") != null) {
				Map<String, Object> btnJsonMap = new HashMap<>();
				btnJsonMap.put("name", map.get("urlName"));
				btnJsonMap.put("type", "WL");
				btnJsonMap.put("url_pc", map.get("urlPc"));
				btnJsonMap.put("url_mobile", map.get("urlMobile"));

				List<Map<String, Object>> btnJsonMapList= new ArrayList<>();
				btnJsonMapList.add(btnJsonMap);

				Map<String, Object> btnJson = new JSONObject();
				btnJson.put("button", btnJsonMapList);
				smsVO.setButtonJson(btnJson.toString());
			} else {
				if (!"4".equals(tempNum) && !"28".equals(tempNum)) {	//인증번호요청,비밀번호초기화 템플릿 웹링크제외
					Map<String, Object> btnJsonMap = new HashMap<>();
					btnJsonMap.put("name", "케이지트레이딩");
					btnJsonMap.put("type", "WL");
					btnJsonMap.put("url_pc", "https://www.kztraders.com/");
					btnJsonMap.put("url_mobile", "https://m.kztraders.com/");

					List<Map<String, Object>> btnJsonMapList= new ArrayList<>();
					btnJsonMapList.add(btnJsonMap);

					Map<String, Object> btnJson = new JSONObject();
					btnJson.put("button", btnJsonMapList);
					smsVO.setButtonJson(btnJson.toString());
				}
			}

			mapper.insertKkoMsgbySms(smsVO);
		}

		//커머스 알림 발송
		if("Y".equals(smsVO.getCommerceNtcnAt())) {
			smsVO.setMsgTitle(messageVO.getMssageTmplatSj());
			smsVO.setCommerceNtcnCn(map.get("commerceNtcnCn")); //커머스 알립 내용
		}
		return smsVO;
	}
}
