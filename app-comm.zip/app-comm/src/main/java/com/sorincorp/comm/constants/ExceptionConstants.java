package com.sorincorp.comm.constants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ExceptionConstants {
	
	
	private ExceptionConstants() {
		log.debug(ExceptionConstants.class.getSimpleName());
	}
	
    public static final String COMMON_EXCEPTION = "co.exception.";
    public static final String GOODS_EXCEPTION = "gd.exception.";
    public static final String MEMBER_EXCEPTION = "mb.exception.";
    public static final String ORDER_EXCEPTION = "or.exception.";

    // =======================================================
    // 공통 : CO
    // =======================================================
    /** 오류가 발생하였습니다. 관리자에게 문의하시기 바랍니다. */
    public static final String ERROR_CODE_DEFAULT = "co.exception.error";
    /** 지원하지 않는 서비스입니다. */
    public static final String NOT_SUPPORT_SERVICE = "co.exception.not.support.service";
    /** 업로드 하실수 없는 파일입니다. */
    public static final String BAD_EXE_FILE_EXCEPTION = "co.exception.file.not.support.extension";
    /** 제한된 용량을 초과하였습니다. */
    public static final String BAD_SIZE_FILE_EXCEPTION = "co.exception.file.big.size";
    /** 파일명 길이를 확인해주시기 바랍니다. **/
    public static final String BAD_LENGTH_FILE_NM_EXCEPTION = "co.exception.file.name.length";
    /** 캐시 생성중 오류가 발생하였습니다. */
    public static final String ERROR_CACHE = "co.exception.cache.creation.error";
    /** 로그인이 필요합니다. */
    public static final String ERROR_CODE_LOGIN_REQUIRED = "co.exception.login.required";
    /** 세션이 종료 되었습니다. */
    public static final String ERROR_CODE_LOGIN_SESSION = "co.exception.session.expired";
    /** 사용자 아이디, 패스워드 를 확인해 주세요. */
    public static final String ERROR_CODE_LOGIN_FAIL = "co.exception.login.information.error";
    /** 사용자 상태가 올바르지 않습니다. 관리자에게 문의바랍니다. */
    public static final String ERROR_CODE_LOGIN_STATUS_FAIL = "co.exception.user.status.error";
}
