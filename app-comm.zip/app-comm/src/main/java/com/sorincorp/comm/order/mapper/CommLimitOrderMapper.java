package com.sorincorp.comm.order.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.order.model.CommLimitOrderSttusVO;
import com.sorincorp.comm.order.model.CommOrLimitOrderBasVO;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.comm.order.model.MbDlvrgBasVO;
import com.sorincorp.comm.order.model.OrderModel;

/**
 * CommLimitOrderMapper.java
 * 지정가 주문 공통 Mapper 인터페이스
 *
 * @version
 * @since 2023. 4. 26.
 * @author srec0049
 */
public interface CommLimitOrderMapper {

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 번호로 해당 지정가 주문 내역 가져오기 [단일]
	 * </pre>
	 * @date 2023. 4. 26.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 4. 26.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param limitOrderNo
	 * @return
	 * @throws Exception
	 */
	public CommOrLimitOrderBasVO selectCommOrLimitOrderBas(String limitOrderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 번호들로 해당 지정가 주문 내역 리스트 가져오기 [복수]
	 * </pre>
	 * @date 2023. 5. 2.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 2.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param limitOrderNoList
	 * @return
	 * @throws Exception
	 */
	public List<CommOrLimitOrderBasVO> selectCommOrLimitOrderBasList(List<String> limitOrderNoList) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 가격 도달 후 지정가 주문 시 부족한 멤버 정보 가져오기
	 * </pre>
	 * @date 2023. 5. 10.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param mberNo
	 * @return
	 * @throws Exception
	 */
	public MbDlvrgBasVO selectOrMbEntrpsInfoByLimitOrder(String mberNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 해당 지정가 주문 번호의 지정가 주문 상태 코드를 변경 [단일, 복수]
	 * [
	 *     10(미체결), 20(주문처리중), 30.체결, 31.부분 체결, 40(주문취소(본인)), 41(주문취소(관리자))
	 *   , 90(체결실패(선물 실패)), 91(체결실패(재고 부족)), 92(체결실패(잔액 부족)), 93(체결실패(당일 유효 시간 경과)), 94(체결실패(유효성 검사 실패)), 95(체결실패(기타))
	 * ]
	 * </pre>
	 * @date 2023. 5. 1.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 1.          srec0049         최초작성
	 * 2023. 8. 3.          hyunjin05		 쿠폰 적용 여부 추가
	 * ------------------------------------------------
	 * @param commLimitOrderSttusVO
	 * @return
	 * @throws Exception
	 */
	public int updateCommLimitOrderSttusCode(CommLimitOrderSttusVO commLimitOrderSttusVO) throws Exception;

	/**
	 * <pre>
	 * 지정가 주문 실패 sms 발송 (템플릿 108)
	 * </pre>
	 * @date 2023. 5. 3.
	 * @author srec0051
	 * @param limitOrderNo
	 * @return
	 */
	public Map<String, String> selectLimitOrderFailSmsInfo(String limitOrderNo) throws Exception;

	/**
	 * <pre>
	 * 지정가 주문 취소 sms 발송 (템플릿 110)
	 * </pre>
	 * @date 2023. 5. 3.
	 * @author srec0051
	 * @param limitOrderNo
	 * @return
	 */
	public Map<String, String> selectLimitOrderCancelSmsInfo(String limitOrderNo) throws Exception;

	/**
	 * <pre>
	 * 기준 프리미엄 환산 금액 조회
	 * </pre>
	 * @date 2023. 5. 15.
	 * @author srec0066
	 * @param limitOrderNo
	 * @return
	 */
	public long selectStdrPremiumCnvrsnAmount(String limitOrderNo) throws Exception;

	/**
	 * <pre>
	 * 아이템의 판매 단위 중량을 조회한다.
	 * </pre>
	 * @date 2023. 5. 3.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 3.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param itmSn
	 * @return
	 * @throws Exception
	 */
	public int getSleUnitWt(String string) throws Exception;

	/**
	 * <pre>
	 * 지정가 주문 자동 취소 대상
	 * </pre>
	 * @date 2023. 5. 17.
	 * @author srec0051
	 * @param entrpsNo
	 * @return
	 */
	public List<CommOrLimitOrderBasVO> selectListLimitOrderAutoCancel(String entrpsNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 호가 영역 렌더링을 위한 지정가 주문 정보를 가져온다.
	 * </pre>
	 * @date 2023. 5. 23.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 23.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param limitOrderNo
	 * @return
	 * @throws Exception
	 */
	public CommOrLimitOrderBasVO selectLimitOrderForRendering(String limitOrderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 기본 이력 테이블 insert
	 * </pre>
	 * @date 2023. 5. 16.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일				작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 16.			srec0053			최초작성
	 * 2023. 5. 26.         srec0049   파라미터 변경, FO에서 COMM으로 위치 변경
	 * ------------------------------------------------
	 * @param limitOrderNo
	 * @throws Exception
	 */
	public void insertOrLimitOrderBasHst(String limitOrderNo) throws Exception;

	/**
	 * <pre>
	 * 주문_지정가 주문 기본 이력 테이블 insert list
	 * </pre>
	 * @date 2023. 8. 22.
	 * @author srec0051
	 * @param limitOrderNoList
	 * @throws Exception
	 */
	public void insertOrLimitOrderBasHstList(List<String> limitOrderNoList) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 지정가 주문에 사용된 쿠폰 유무 판단 (단가, 배송비)
	 * </pre>
	 * @date 2023. 8. 2.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 2.				hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param limitOrderNo
	 * @return
	 * @throws Exception
	 */
	Integer selectLimtOrderUsedUntPcCoupon(String limitOrderNo) throws Exception;
	Integer selectLimtOrderUsedDlvyCoupon(String limitOrderNo) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 지정가 주문에 사용된 쿠폰 리스트 조회 (단가, 배송비)
	 * </pre>
	 * @date 2023. 8. 2.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 2.				hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param limitOrderNo
	 * @return
	 * @throws Exception
	 */
	public List<CouponVO> selectLimtOrderUsedUntPcCouponList(String limitOrderNo) throws Exception;
	public List<CouponVO> selectLimtOrderUsedDlvyCouponList(String limitOrderNo) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 지정가 주문취소시 사용된 쿠폰 리셋처리 (단가, 배송비)
	 * </pre>
	 * @date 2023. 8. 2.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 2.				hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param couponVo
	 * @return
	 * @throws Exception
	 */
	public Integer limtOrderUntPcCouponUpdate(CouponVO couponVo) throws Exception;
	public Integer limtOrderDlvyCouponUpdate(CouponVO couponVo) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 지정가 주문취소시 사용된 쿠폰 히스토리 적재 (배송비)
	 * </pre>
	 * @date 2023. 8. 2.
	 * @author hyunjin05
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 2.				hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param couponVo
	 * @return
	 * @throws Exception
	 */
	public void insertEvCouponIsuHst(CouponVO couponVO) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 지정가 주문시 사용한 단가쿠폰정보 불러오기
	 * </pre>
	 * @date 2023. 8. 10.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 10.				sumin				최초작성
	 * ------------------------------------------------
	 * @param String limitOrderNo
	 * @return List<CouponVO>
	 * @throws Exception
	 */
	public List<CouponVO> selectUsedUntPcCouponInfo(String limitOrderNo) throws Exception;

	/**
	 *
	 * <pre>
	 * 처리내용: 지정가 주문시 사용한 배송비 쿠폰정보 불러오기 (배송비쿠폰 개발 후 통합 예정)
	 * </pre>
	 * @date 2023. 8. 10.
	 * @author sumin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 8. 10.				sumin				최초작성
	 * ------------------------------------------------
	 * @param String limitOrderNo
	 * @return List<CouponVO>
	 * @throws Exception
	 */
	public List<CouponVO> selectUsedDlvyCouponInfo(String limitOrderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 현재 체결 전 상태인 지정가 주문건 조회
	 * </pre>
	 * @date 2023. 10. 25.
	 * @author hyunjin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 20.		hyunjin0512				최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 */
	public List<OrderModel> getLimitOrderList(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 지정가 주문 재고 소진 알림 SMS 정보 조회 (템플릿 129)
	 * </pre>
	 * @date 2023. 10. 26.
	 * @author hyunjin
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 26.		hyunjin0512				최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 */
	public Map<String, String> selectLimitOrderNoStockSmsInfo(String limitOrderNo) throws Exception;
	
	
}
