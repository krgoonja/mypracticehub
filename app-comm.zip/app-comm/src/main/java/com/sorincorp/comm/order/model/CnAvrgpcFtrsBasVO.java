package com.sorincorp.comm.order.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CnAvrgpcFtrsBasVO.java
 * 계약_평균가 선물 기본 VO
 * @version
 * @since 2023. 11. 15.
 * @author srec0066
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class CnAvrgpcFtrsBasVO {
   /**
    * 평균가 선물 요청 번호
   */
   private String avrgpcFtrsRequstNo;
   /**
    * 계약 번호
   */
   private String cntrctNo;
   /**
    * 계약 년월
   */
   private String cntrctYm;
   /**
    * 계약 년월 순번
   */
   private int cntrctYmSn;
   /**
    * BL 번호
   */
   private String blNo;
   /**
    * 체결 요청 상태 여부
   */
   private String cnclsRequstSttusAt;
   /**
    * 금속 코드
   */
   private String metalCode;
   /**
    * 포지션
   */
   private String postn;
   /**
    * 선물사 구분 코드
   */
   private String ftrsprofsSeCode;
   /**
    * 선물사 대상 코드
    */
   private String ftrsCmpnyTrgetCode;
   /**
    * 가격 옵션
   */
   private String pcOptn;
   /**
    * 시작 일자
   */
   private String beginDe;
   /**
    * 종료 일자
   */
   private String endDe;
   /**
    * 수량
   */
   private int qy;
   /**
    * LOT 수량
   */
   private int lotQy;
   /**
    * LME
   */
   private java.math.BigDecimal lme;
   /**
    * 스프레드
   */
   private java.math.BigDecimal spread;
   /**
    * 최종 가격
   */
   private java.math.BigDecimal finalPc;
   /**
    * 만기 일자
   */
   private String exprtnDe;
   /**
    * 주문 요청자
   */
   private String orderRqester;
   /**
    * 할당 재고
   */
   private java.math.BigDecimal asgnInvntry;
   /**
    * 할당 번들 재고
   */
   private int asgnBundleInvntry;
   /**
    * 체결 선물사 구분 코드
   */
   private String cnclsFtrsprofsSeCode;
   /**
    * 삭제 일시
   */
   private java.sql.Timestamp deleteDt;
   /**
    * 삭제 여부
   */
   private String deleteAt;
   /**
    * 최초 등록자 아이디
   */
   private String frstRegisterId;
   /**
    * 최초 등록 일시
   */
   private java.sql.Timestamp frstRegistDt;
   /**
    * 최종 변경자 아이디
   */
   private String lastChangerId;
   /**
    * 최종 변경 일시
   */
   private java.sql.Timestamp lastChangeDt;
   /**
    * 실행 아이디
   */
   private String executId;
   /**
	* 종목 코드
   */
   private String itemCode;
   /**
	* 인덱스 (체결, 만기 구분용)
   */
   private int index;
   /**
	* 할당 처리 구분 [DDCT(차감), INCRS(증가)]
   */
   private String asgnProcessSe;  
   /**
    * DML 구분 (delete, update, insert)
   */
   private String dmlSe;
}
