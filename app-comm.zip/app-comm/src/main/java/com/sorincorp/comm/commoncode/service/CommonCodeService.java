package com.sorincorp.comm.commoncode.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;

public interface CommonCodeService {
	/**
	 * <pre>
	 * 공통코드를 가져와서 공통 코드 Cache(codeCache)에 넣는다.
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 15.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public void initCommonCodeList() throws Exception;

	/**
	 * <pre>
	 * 공통코드를 MainCode 별로 가져와서 공통 코드 Cache(codeCache)에 넣는다.
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 15.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @return
	 * @throws Exception
	 */
	public void initCommonCodeByMainCode(String mainCode) throws Exception;

	/**
	 * <pre>
	 * 공통에서 메인코드 목록을 반환한다.(Redis에서 읽어 옴)
	 * </pre>
	 * @date 2021. 6. 16.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 16.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getMainCodes() throws Exception;

	/**
	 * <pre>
	 * 처리내용: String 반환의 getMainCodes를 CommonCodeVO 반환으로 변경한 메소드
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0049			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public Map<String, CommonCodeVO> getMainCodesRetVo() throws Exception;

	/**
	 * <pre>
	 * 공통에서 입력한 메인코드에 맞는 서브코드 목록을 반환한다.(Redis에서 읽어 옴)
	 * </pre>
	 * @date 2021. 6. 16.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 16.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getSubCodes(String mainCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: String 반환의 getSubCodes를 CommonCodeVO 반환으로 변경한 메소드
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @return
	 * @throws Exception
	 */
	public Map<String, CommonCodeVO> getSubCodesRetVo(String mainCode) throws Exception;
	public Map<String, CommonCodeVO> getSubCodesRetVo(String mainCode, String subCode) throws Exception;

	/**
	 * <pre>
	 * Redis에 있는 공통코드 목록 중 해당 조건으로 Filtering해서 반환한다
	 * mainCode 는 필수값 *
	 * </pre>
	 * @date 2021. 8. 12.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 12.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @param subCode
	 * @param columKey
	 * @param columnValue
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getFilterCode(String mainCode, String subCode, String columKey, String columnValue) throws Exception;

	/**
	 * <pre>
	 * 처리내용: String 반환의 getFilterCode를 CommonCodeVO 반환으로 변경한 메소드
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @param subCode
	 * @param columKey
	 * @param columnValue
	 * @return
	 * @throws Exception
	 */
	public Map<String, CommonCodeVO> getFilterCodeRetVo(String mainCode, String subCode, String columKey, String columnValue) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메인코드와 서브코드, 조회할 컬럼명, 컬럼값, 시작 인덱스, 종료 인덱스로 구성된 가변인자로 공통코드를 필터하여 CommonCodeVO 값을 가진 맵으로 반환한다.
	 * </pre>
	 * @date 2022. 3. 4.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 3. 4.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param mainCode 메인코드
	 * @param subCode 서브코드
	 * @param columnInfo 조회할 컬럼명, 컬럼값, 시작 인덱스, 종료 인덱스로 구성된 가변인자
	 * @return
	 * @throws Exception
	 */
	public Map<String, CommonCodeVO> getMultiFilterCodeRetVo(String mainCode, String subCode, String... columnInfo) throws Exception;

	/**
	 * <pre>
	 * 입력한 메인코드/서브코드에 해당하는 코드 값을 반환한다.(Ehcache에서 읽어 옴)
	 * </pre>
	 * @date 2021. 6. 16.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 16.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @param subCode
	 * @return
	 * @throws Exception
	 */
	public String getCodeValue(String mainCode, String subCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: String 반환의 getCodeValue를 CommonCodeVO 반환으로 변경한 메소드
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @param subCode
	 * @return
	 * @throws Exception
	 */
	public CommonCodeVO getCodeValueRetVo(String mainCode, String subCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: CommonCodeVO 를  구분자 :, ; 를 넣어서 String 으로 변환
	 * </pre>
	 * @date 2022. 8. 5.
	 * @author jhcha
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 5.			jhcha				최초작성
	 * ------------------------------------------------
	 * @param commonCode
	 * @param addCode
	 * @return String
	 * @throws Exception
	 */
	public String getCmmnCodeListStr(List<CommonCodeVO> commonCode, Map<String, String> addCode) throws Exception;


	/** SubCodes를 조회한뒤 CommonCodeVO 로 바로 리턴하는 메소드
	 * <pre>
	 * 처리내용:
	 * </pre>
	 * @date 2022. 8. 9.
	 * @author jhcha
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 8.			jhcha				최초작성
	 * ------------------------------------------------
	 * @param commonCode
	 * @param addCode
	 * @return String
	 * @throws Exception
	 */
	public List<CommonCodeVO> getSubCodesToCommonCode(String string) throws Exception;


}
