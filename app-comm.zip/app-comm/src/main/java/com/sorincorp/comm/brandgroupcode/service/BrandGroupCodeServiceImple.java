package com.sorincorp.comm.brandgroupcode.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.brandgroupcode.mapper.BrandGroupCodeMapper;
import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.CacheUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BrandGroupCodeServiceImple implements BrandGroupCodeService {

	@Autowired
	private CacheUtil cacheUtil;

	@Autowired
	private BrandGroupCodeMapper brandGroupCodeMapper;

	@PostConstruct
	public void init() {
		cacheUtil.getCodeCache();
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @throws Exception
	 */
	@Override
	public void initBrandGroupCode() throws Exception {
		// TODO Auto-generated method stub
		BrandGroupCodeVO vo = new BrandGroupCodeVO();
		List<BrandGroupCodeVO> brandGroupCodeList = brandGroupCodeMapper.getBrandGroupCode(vo);
		cacheUtil.put("brandGroupCodeList", brandGroupCodeList);
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<BrandGroupCodeVO> getBrandGroupCodeList(String metalCode) throws Exception {
		// TODO Auto-generated method stub
		List<BrandGroupCodeVO> brandGroupCodeList = (List<BrandGroupCodeVO>) cacheUtil.getValue("brandGroupCodeList");
		List<BrandGroupCodeVO> brandGroupCodeList2 = new ArrayList<BrandGroupCodeVO>();

		if (brandGroupCodeList == null) {
			initBrandGroupCode();
			brandGroupCodeList = (List<BrandGroupCodeVO>) cacheUtil.getValue("brandGroupCodeList");

			if (!"".equals(metalCode)) {
				for (BrandGroupCodeVO code : brandGroupCodeList) {

					if (metalCode.equals(code.getMetalCode())) {
						brandGroupCodeList2.add(code);
					}
				}
			} else {
				brandGroupCodeList2 = brandGroupCodeList;
			}
		} else {

			if (!"".equals(metalCode)) {
				for (BrandGroupCodeVO code : brandGroupCodeList) {

					if (metalCode.equals(code.getMetalCode())) {
						brandGroupCodeList2.add(code);
					}
				}
			} else {
				brandGroupCodeList2 = brandGroupCodeList;
			}
		}

		return brandGroupCodeList2;
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2023. 1. 20.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2023. 1. 20.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param metalCode 메탈코드, sleMthdCode 판매방식코드(01:LIVE, 02:고정가, 03:GTC 지정가)
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<BrandGroupCodeVO> getBrandGroupSleMthdCodeList(String metalCode, String sleMthdCode) throws Exception {
		// TODO Auto-generated method stub
		List<BrandGroupCodeVO> brandGroupCodeList = (List<BrandGroupCodeVO>) cacheUtil.getValue("brandGroupCodeList");
		List<BrandGroupCodeVO> brandGroupCodeList2 = new ArrayList<BrandGroupCodeVO>();

		if (brandGroupCodeList == null) {
			initBrandGroupCode();
			brandGroupCodeList = (List<BrandGroupCodeVO>) cacheUtil.getValue("brandGroupCodeList");
		}

		if (!"".equals(metalCode)) {
			for (BrandGroupCodeVO code : brandGroupCodeList) {
				if (metalCode.equals(code.getMetalCode())) {
					if (!"".equals(sleMthdCode)) {
						if (sleMthdCode.equals(code.getSleMthdCode())) {
							brandGroupCodeList2.add(code);
						}
					} else {
						brandGroupCodeList2.add(code);
					}
				}
			}
		} else {
//			for (BrandGroupCodeVO code : brandGroupCodeList) {
//				if (!"".equals(sleMthdCode)) {
//					if (sleMthdCode.equals(code.getSleMthdCode())) {
//						brandGroupCodeList2.add(code);
//					}
//				} else {
//					brandGroupCodeList2.add(code);
//				}
//			}
			brandGroupCodeList2 = brandGroupCodeList;
		}

		return brandGroupCodeList2;
	}

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param brandGroupCodeList
	 * @return
	 * @throws Exception
	 */
	@Override
	public String getBrandGroupCodeListStr(List<BrandGroupCodeVO> brandGroupCodeList, String val) throws Exception {
		// TODO Auto-generated method stub
		StringBuilder codeTaglibStr = new StringBuilder(StringUtils.EMPTY);

		codeTaglibStr.append("");
		codeTaglibStr.append(CommonConstants.COLONE);
		// codeTaglibStr.append("전체");
		codeTaglibStr.append(val);
		codeTaglibStr.append(CommonConstants.SEMI_COLONE);

		for (BrandGroupCodeVO code : brandGroupCodeList) {

			codeTaglibStr.append(code.getSubCode());
			codeTaglibStr.append(CommonConstants.COLONE);
			codeTaglibStr.append(code.getCodeNm());
			codeTaglibStr.append(CommonConstants.SEMI_COLONE);

		}

		return codeTaglibStr.toString();
	}

}
