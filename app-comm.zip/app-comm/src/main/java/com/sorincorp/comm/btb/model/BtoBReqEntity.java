package com.sorincorp.comm.btb.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
@AllArgsConstructor
public class BtoBReqEntity extends BtoBReqBase{
	
	/* 호출 TARGET SYSTEM */
	private String targetSys;
	
	/* 호출 인터페이스 ID */
	private String interfaceId;
	
	public BtoBReqEntity(String interfaceId) {
		this.interfaceId = interfaceId;
	}
	

}
