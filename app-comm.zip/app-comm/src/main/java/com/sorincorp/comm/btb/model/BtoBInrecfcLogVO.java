package com.sorincorp.comm.btb.model;

import lombok.Data;

@Data
public class BtoBInrecfcLogVO {
	
	/* 인터페이스 번호 */
	private int  intrfcNo;
	
	/* API 번호 */
	private String intrfcCode;
	
	/* 인터페이스 실행 시작일시 */
	private String intrfcExecutBgndehour;
	
	/* 인터페이스 실행 종료일시 */
	private String intrfcExecutEnddehour;
	
	/* 인터페이스 송신 전문 */
	private String intrfcTrnsmitSpclty;
	
	/* 인터페이스 응답 코드 */
	private String intrfcRspnsCode;
	
	/* 인터페이스 응답 내용 */
	private String intrfcRspnsCn;
	
	/*최초 등록자 아이디*/
	private String frstRegisterId;
	
	/*최초 등록 일시*/
	private String frstRegistDt;
	
	/*최종 변경자 아이디*/
	private String lastChangerId;
	
	/* 최종 변경 일시 */
	private String lastChangeDt;

}
