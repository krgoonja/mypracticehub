package com.sorincorp.comm.order.model;

import lombok.Data;

@Data
public class OrSetleBasVO {
	/**
	 * 결제 번호
	*/
	private String setleNo;
	/**
	 * 주문 번호
	*/
	private String orderNo;
	/**
	 * 취소 교환 반품 번호
	*/
	private String canclExchngRtngudNo;
	private String canclExchngRtngudTyCode;
	/**
	 * 결제 구분 코드
	*/
	private String setleSeCode;
	/**
	 * 결제 유형 코드
	*/
	private String setleTyCode;
	/**
	 * 결제 상태 코드
	*/
	private String setleSttusCode;
	/**
	 * 결제 요청 일시
	*/
	private java.sql.Timestamp setleRequstDt;
	/**
	 * 결제 완료 일시
	*/
	private java.sql.Timestamp setleComptDt;
	/**
	 * 이월렛 출금 이체 인터페이스 순번
	*/
	private long ewalletDefrayTransfrIntrfcSn;
	/**
	 * SMS 발송 여부
	*/
	private String smsSndngAt;
	/**
	 * 거래 일련 번호
	*/
	private String delngSeqNo;
	/**
	 * 거래 금액
	*/
	private String delngAmount;
	/**
	 * 음수 구분 표시
	*/
	private String ngnoSeIndict;
	/**
	 * 거래 후 계좌 잔액
	*/
	private String delngAfterAcnutBlce;
	/**
	 * 미결제 타사 금액
	*/
	private String unsetlOthrComAmount;
	/**
	 * 입금 계좌 은행 코드
	*/
	private String rcpmnyAcnutBankCode;
	/**
	 * 입금 계좌 구분 코드
	*/
	private String rcpmnyAcnutSeCode;
	/**
	 * 입금 계좌 번호
	*/
	private String rcpmnyAcnutNo;
	/**
	 * 입금 계좌 성명
	*/
	private String rcpmnyAcnutNm;
	/**
	 * 출금 계좌 은행 코드
	*/
	private String defrayAcnutBankCode;
	/**
	 * 출금 계좌 구분 코드
	*/
	private String defrayAcnutSeCode;
	/**
	 * 출금 계좌 번호
	*/
	private String defrayAcnutNo;
	/**
	 * 출금 계좌 비밀 번호
	*/
	private String defrayAcnutSecretNo;
	/**
	 * 출금 계좌 성명
	*/
	private String defrayAcnutNm;
	/**
	 * 수수료
	*/
	private long fee;
	/**
	 * 정산 조정 금액
	*/
	private long excclcMdatAmount;
	/**
	 * 정산 조정 사유
	*/
	private String excclcMdatResn;
	/**
	 * 정산 확정 금액
	*/
	private long excclcDcsnAmount;
	/**
	 * 정산 처리 여부
	*/
	private String excclcProcessAt;
	/**
	 * 정산 처리 일시
	*/
	private java.sql.Timestamp excclcProcessDt;
	/**
	 * 삭제 일시
	*/
	private java.sql.Timestamp deleteDt;
	/**
	 * 삭제 여부
	*/
	private String deleteAt;
	/**
	 * 최초 등록자 아이디
	*/
	private String frstRegisterId;
	/**
	 * 최초 등록 일시
	*/
	private java.sql.Timestamp frstRegistDt;
	/**
	 * 최종 변경자 아이디
	*/
	private String lastChangerId;
	/**
	 * 최종 변경 일시
	*/
	private java.sql.Timestamp lastChangeDt;
	/**
	 * 환불 구분 코드
	*/
	private String refndSeCode;
}
