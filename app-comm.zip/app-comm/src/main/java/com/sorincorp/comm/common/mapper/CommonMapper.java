package com.sorincorp.comm.common.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.common.model.BlSleSttusCodeChgVO;

public interface CommonMapper {

	/**
	 * <pre>
	 * 처리내용: 테이블 존재 여부
	 * </pre>
	 * 
	 * @date 2022. 7. 12.
	 * @author jdrttl
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 12. jdrttl
	 *          최초작성 ------------------------------------------------
	 * @param objectName(TableName)
	 * @return
	 * @throws Exception
	 */
	int selectTableExist(String objectName) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 테이블 컬럼 비교
	 * </pre>
	 * 
	 * @date 2022. 7. 12.
	 * @author jdrttl
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 7. 12. jdrttl
	 *          최초작성 ------------------------------------------------
	 * @param objectName(TableName)
	 * @return
	 * @throws Exception
	 */
	int selectTableEqual(String objectName) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 컬럼 리스트를 가져온다.
	 * </pre>
	 * 
	 * @date 2022. 6. 28.
	 * @author jdrttl
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 6. 28. jdrttl
	 *          최초작성 ------------------------------------------------
	 * @param objectName(TableName)
	 * @return
	 * @throws Exception
	 */
	List<Map<String, String>> selectColumnList(String objectName) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 쿼리 실행
	 * </pre>
	 * 
	 * @date 2022. 6. 28.
	 * @author jdrttl
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 6. 28. jdrttl
	 *          최초작성 ------------------------------------------------
	 * @param query
	 * @return
	 * @throws Exception
	 */
	int customQueryExecute(String customQuery) throws Exception;

	/**
	 * <pre>
	 * 처리내용: bl 판매상태변경
	 * </pre>
	 * 
	 * @date 2022. 9. 02.
	 * @author hyunjin05
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 9. 02.
	 *          hyunjin05 최초작성 ------------------------------------------------
	 * @param query
	 * @return
	 * @throws Exception
	 */
	BlSleSttusCodeChgVO selectBlSleSttusCodeChgData(String blNo) throws Exception;

	List<BlSleSttusCodeChgVO> selectBlSleSttusCodeChgList() throws Exception;

	void updateItBlSleSttus(BlSleSttusCodeChgVO vo) throws Exception;

	int insertItBlInfoBasHst(String blNo) throws Exception;

	int insertItPurchsInfoBasHst(String blNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: BL 정보 조회
	 * </pre>
	 * @date 2023. 10. 26.
	 * @auther hyunjin0512
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 10. 26.		hyunjin0512			최초작성
	 * -----------------------------------------------
	 * @param BlSleSttusCodeChgVO
	 * @return
	 * @throws Exception
	 */
	BlSleSttusCodeChgVO selectItemInvntrySetupInfo(BlSleSttusCodeChgVO blSleSttusCodeChgVO) throws Exception;

	
}
