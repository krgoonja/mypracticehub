package com.sorincorp.comm.constants;

import java.util.List;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CommonConstants {
	
	private CommonConstants() {
		log.debug(CommonConstants.class.getSimpleName());
	}
	
    /* Result */
    public static final String RESULT_CODE = "resultCode";
    public static final String RESULT_MSG = "resultMsg";
    public static final String RESULT_CODE_SUCCESS = "S";
    public static final String RESULT_CODE_FAIL = "F";

    /* Page */
    public static final int RECORD_COUNT_PAGE = 10;

    /* Exception */
    public static final String EXCEPTION_VIEW_NAME = "/exception/error";
    public static final String EXCEPTION_MESSAGE_COMMON = "co.exception.";

    /* Date */
    public static final String GRID_DATE_FORMAT = "Y-m-d H:i:s A";
    public static final String COMMON_END_DATE = "9999-12-31 23:59:59";
    public static final String DATE_TIMEZONE = "Asia/Seoul";
    public static final String DATE_LOCALE = "ko";
    public static final String DATE_YYYYMMDD = "yyyy-MM-dd";
    public static final String DATE_YYYYMMDDHHMMSS = "yyyy-MM-dd HH:mm:ss";

    /* Y, N */
    public static final String YN_Y = "Y";
    public static final String YN_N = "N";

    /** 기호 **/
    public static final String COLONE = ":";
    public static final String SEMI_COLONE = ";";
    public static final String UNDER_BAR = "_";

    /** 모바일 OS 코드 */
    public static final String MOBILE_OS_ANDROID = "01";
    public static final String MOBILE_OS_IOS = "02";

    /** File Upload */
    public static final String UPLOAD_PATH = "upload_files";		// 업로드 파일 경로
    public static final String ATTACH_PATH = "attach";				// 첨부파일 경로
    public static final String IMAGE_PATH = "image";				// 첨부 이미지 경로
    public static final String PRODUCT_PATH = "product";			// 상품 이미지 경로
    public static final String TEMP_PATH = "temp";					// 임시 파일 경로
    public static final Long MAX_UPLOAD_SIZE = 10485760L;			// 최대 업로드 사이즈. 10MB

    /** 카카오 로그인 관련 */
    public static final String KAKAO_REST_API_KEY = "1ba650c2dc00d0a52455cd68d8c4f310";		// 카카오 REST API Key
//    public String getKAKAO_REST_API_KEY() {
//    	return KAKAO_REST_API_KEY;
//    }

    //실행 Server 구분
//    public static ServerType ExcuterServer = ServerType.DEV;
    public static final String KAKAO_REDIRECT_URL = null;//ExcuterServer.getKakaoRedirectUrl();	// 카카오 Redirect URI
//    public static final String KAKAO_REDIRECT_URL_LOCAL = "http://localhost:28085/account/kakaoLogin";	// 카카오 Redirect URI
//    public static final String KAKAO_REDIRECT_URL_DEV = "http://10.202.0.4:28085/account/kakaoLogin";	// 카카오 Redirect URI
//    public static final String KAKAO_REDIRECT_URL_PRD = "http://localhost:28085/kakaoLogin";	// 카카오 Redirect URI

    public static String SERVER_DOMAIN = "10.202.0.4"; // =  ExcuterServer.getServerDomain();

//    public static final String SERVER_DOMAIN_LOCAL = "localhost";
//    public static final String SERVER_DOMAIN_DEV = "10.202.0.4";
//    public static final String SERVER_DOMAIN_PRD = "localhost";

//    public String getKAKAO_REDIRECT_URL() {
//    	return KAKAO_REDIRECT_URL;
//    }

    /** JWT 로그인 관련 */
    public static final String JWT_SECRET_KEY = "서린이커머스프론트웹사이트";						// Secret Key(한글 11자, 영문 42자 이상)
    public static final String JWT_BD_SECRET_KEY = "서린구매입찰웹사이트";                        // Secret Key(한글 11자, 영문 42자 이상)
    
    public static final long ACCESS_TOKEN_VALIDATION_SECOND = 1000L * 60 * 10;				// Access Token 유효기간
    public static final long REFRESH_TOKEN_VALIDATION_SECOND = 1000L * 60 * 60 * 12;		// Refresh Token 유효기간
    public static final long SESSION_VALIDATION_SECOND = 60 * 60 * 10;					// Session 유효기간
    public static final long SMS_TOKEN_VALIDATION_SECOND = 1000L * 60 * 5;					// 문자인증 유효기간
    
    public static final String ACCESS_TOKEN_NAME = "accessToken";							// Access Token 이름
    public static final String REFRESH_TOKEN_NAME = "refreshToken";							// Refresh Token 이름

    public static final String BID_ACCESS_TOKEN_NAME = "bidAccessToken";                            // 입찰 Access Token 이름
    public static final String BID_REFRESH_TOKEN_NAME = "bidRefreshToken";                          // 입찰 Refresh Token 이름
    
    public static final String MO_ACCESS_TOKEN_NAME = "moAccessToken";							// Access Token 이름
    public static final String MO_REFRESH_TOKEN_NAME = "moRefreshToken";						// Refresh Token 이름

    public static final String BO_ACCESS_TOKEN_NAME = "boAccessToken";							// Access Token 이름
    public static final String BO_REFRESH_TOKEN_NAME = "boRefreshToken";						// Refresh Token 이름
    
    public static final String MFO_ACCESS_TOKEN_NAME = "mfoAccessToken";						// Access Token 이름
    public static final String MFO_REFRESH_TOKEN_NAME = "mfoRefreshToken";						// Refresh Token 이름

    
    // 암호화 키
    public static final String CRYPTO_AES_KEY = "sorinscretkeycryptoaeskey";
    public static final String CRYPTO_IV_KEY = "sorinscretkeycry";
    public static final String CRYPTO_AES256_KEY = "sO2#*ri$nSc^rE@tk!$ey&cRyp%toDes";
    public static final String CRYPTO_IV256_KEY = "cJr@#Vcjid7#fk&k";
    public static final String CRYPTO_DES_KEY = "sorinscretkeycryptodeskey";
    public static final String CRYPTO_DESEDS_KEY = "sorinscretkeycryptodesedskey";

    public static final String REDIS_KEY_BO_MENULIST = "boMenuList";
    public static final String REDIS_KEY_BO_MENU_URL_PREFIX = "bomenukey:bo:";
    
    public static final String REDIS_KEY_FO_ACCESS = "fo:access:";
    public static final String REDIS_KEY_FO_REFRESH = "fo:refresh:";
    public static final String REDIS_KEY_MO_ACCESS = "mo:access:";
    public static final String REDIS_KEY_MO_REFRESH = "mo:refresh:";
    public static final String REDIS_KEY_BID_ACCESS = "bid:access:";
    public static final String REDIS_KEY_BID_REFRESH = "bid:refresh:";
    public static final String REDIS_KEY_MFO_ACCESS = "mfo:access:";
    public static final String REDIS_KEY_MFO_REFRESH = "mfo:refresh:";
    
    public static final String BO_ACCESS_PATH = "boAccessPath";
    
    public static final String FO_LOGIN_NEED_PAGE_COMMON_CD = "LOGIN_NEED_PAGE_CODE";
    public static final String FO_LOGIN_NEED_PAGE_CODE = "FO_LOGIN_NEED_PAGE_CODE";
    public static final String MO_LOGIN_NEED_PAGE_CODE = "MO_LOGIN_NEED_PAGE_CODE";
    public static final String FO_BID_LOGIN_NEED_PAGE_CODE = "FO_BID_LOGIN_NEED_PAGE_CODE";
    public static final String MFO_LOGIN_NEED_PAGE_CODE = "MFO_LOGIN_NEED_PAGE_CODE";

    //Blob Storage 연결 정보
	public static final String STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;"
			+ "AccountName=sorincorp;"
			+ "AccountKey=ZPmyuSf3Xws49EQjtSyFRs7K6AJ6VMtDTtOCzYw3Drcg+oF8rNCZx84OjtVtEirX0phwTsVObi73FZD0zNr1Bg==;"
			+ "EndpointSuffix=core.windows.net";

	public static final String BLOB_STORAGE_ROOT_PATH = "https://sorincorp.blob.core.windows.net/";
	
	public static final String MAIN_SALES_PAGE_URL = "https://www.kztraders.com/";
	
//	public static final String BLOB_STORAGE_EC_CONTAINER_PATH = "secs";
//	public static final String BLOB_STORAGE_PUBLIC_EC_CONTAINER_PATH = "secs-pu/";
	
	
	public static final String APP_PUSH_KEY = "E8FT16VZA6V0";
	public static final String APP_PUSH_SECRET_KEY = "HmEblkJeAXA4TDDho0QNmmsyVc3dK2aQ";
	
	public static final String COMMON_CODE_CACHE_KEY = "commonCodeList";
	
	public static List<CommonCodeVO> commonCodeList; 
	
	//판매방식코드
	public static final String LIVE_SLE_MTHD_CODE = "01";
	public static final String HGHNETPRC_SLE_MTHD_CODE = "02";
	public static final String LIMITS_SLE_MTHD_CODE = "03";
	public static final String AVRGPC_SLE_MTHD_CODE = "04";
	public static final String PRVSNL_UNTPC_SLE_MTHD_CODE = "05";	// 잠정 단가 (=가단가)
	
    //Server 구분
//     public static enum ServerType{
// 		LOCAL("Local",KAKAO_REDIRECT_URL_LOCAL,SERVER_DOMAIN_LOCAL),
// 		DEV("Dev",KAKAO_REDIRECT_URL_DEV,SERVER_DOMAIN_DEV),
// 		PRD("Prd",KAKAO_REDIRECT_URL_PRD,SERVER_DOMAIN_PRD);
//
//    	 final private String name;
//    	 final private String kakaoRedirectUrl;
//    	 final private String serverDomain;
//
//    	 ServerType(String name, String kakaoRedirectUrl,String serverDomain) {
//    	        this.name = name;
//    	        this.kakaoRedirectUrl = kakaoRedirectUrl;
//    	        this.serverDomain = serverDomain;
//    	 }
//
//    	 public String getName() { return name; }
//    	 public String getKakaoRedirectUrl() { return kakaoRedirectUrl; }
//    	 public String getServerDomain() { return serverDomain; }
// 	}
	public synchronized static  void setCommonCodeList(List<CommonCodeVO> list) {
		commonCodeList = list;
	}

}