package com.sorincorp.comm.itemprice.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.sorincorp.comm.itemprice.mapper.ItemPriceMatchingMapper;
import com.sorincorp.comm.itemprice.model.ItemPriceGatheringInfoByBrandCodeVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingSelectVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingWeightCalculateValuesVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
//@Service
public class ItemPriceMatchingServiceImpl_bak {//implements ItemPriceMatchingService{
	
	@Autowired
	private ItemPriceMatchingMapper itemPriceMatchingMapper;
	
	public List<ItemPriceMatchingBlInfoVO> itemBLWithMatchingList(ItemPriceMatchingSelectVO itemPriceMatchingSelectVO, int orderMinWeight, int orderMaxWeight, int blCount) throws Exception { 
		
		List<ItemPriceMatchingBlInfoVO> searchItemBLList = itemPriceMatchingMapper.selectListItemBl(itemPriceMatchingSelectVO);
		
		List<ItemPriceMatchingBlInfoVO> matchingList = new ArrayList<>(); // 딱맞는 중량
		List<ItemPriceMatchingBlInfoVO> biggestList = new ArrayList<>(); // 제일 많은 중량
		List<ItemPriceMatchingBlInfoVO> gatheringList = new ArrayList<>(); // 작은 중량들 여러개
		
		List<ItemPriceMatchingBlInfoVO> returnList = new ArrayList<>(); // 결과값
		
		if(searchItemBLList.size() > 0) {

			//BigDecimal selectTonWeight = itemPriceMatchingSelectVO.getOrderWeight().divide(BigDecimal.valueOf(1000));
			BigDecimal selectTonWeight = BigDecimal.valueOf(175);
			//BigDecimal selectTonWeight = itemPriceVO.getOrderWeight().divide(BigDecimal.valueOf(1000));
			//BigDecimal biggestWeight = searchItemBLList.get(0).getSleInvntryUnsleBnt();
			
			for(int i = 0; i < searchItemBLList.size(); i++) {
				
//				System.out.println("***********************************************");
//				System.out.println("getBrandGroupCode : " + searchItemBLList.get(i).getBrandGroupCode());
//				System.out.println("getBrandCode : " +searchItemBLList.get(i).getBrandCode());
//				System.out.println("getSleInvntryUnsleBnt : " +searchItemBLList.get(i).getSleInvntryUnsleBnt());
//				System.out.println("getSleInvntryUnsleBundleBnt : " +searchItemBLList.get(i).getSleInvntryUnsleBundleBnt());
//				System.out.println("getPriorRank : " +searchItemBLList.get(i).getPriorRank());
//				System.out.println("***********************************************");

				//각 주문 중량 당 번들 및 중량을 계산한다.
				Map<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO> mapMatchingWeightValueVo = setMathcingValuesMap(searchItemBLList.get(i), orderMinWeight, orderMaxWeight);
				
				//bl의 재고 미판매 번들 잔량
				BigDecimal inventoryUnSelBundle = BigDecimal.valueOf(searchItemBLList.get(i).getSleInvntryUnsleBundleBnt());
				
				// 검색 값의 tolerance 범위 안에 맞는 값 저장
				if(inventoryUnSelBundle.compareTo(mapMatchingWeightValueVo.get(selectTonWeight).getMinBundle()) >= 0 &&
						inventoryUnSelBundle.compareTo(mapMatchingWeightValueVo.get(selectTonWeight).getMaxBundle()) <= 0) {
					
					//선택된 값을 선택하게된 기준 번들 값과 기준 중량을 설정
					searchItemBLList.get(i).setMatchedSleInvntryUnsleBundleBnt(inventoryUnSelBundle);
					searchItemBLList.get(i).setMatchedSleInvntryUnsleBnt(searchItemBLList.get(i).getSleInvntryUnsleBnt());
					//계산된 번들 및 중량을 BL에 설정
					searchItemBLList.get(i).setWeightMappingCalculateValues(mapMatchingWeightValueVo);
					
					matchingList.add(searchItemBLList.get(i));
				}
				
				//검색 값 보다 큰 값 저장
				if(inventoryUnSelBundle.compareTo(mapMatchingWeightValueVo.get(selectTonWeight).getMaxBundle()) > 0) {
					
					//선택된 값을 선택하게된 기준 번들 값과 기준 중량을 설정
					searchItemBLList.get(i).setMatchedSleInvntryUnsleBundleBnt(mapMatchingWeightValueVo.get(selectTonWeight).getCollectBundle());
					searchItemBLList.get(i).setMatchedSleInvntryUnsleBnt(mapMatchingWeightValueVo.get(selectTonWeight).getLogicalWeight());
					//계산된 번들 및 중량을 BL에 설정
					searchItemBLList.get(i).setWeightMappingCalculateValues(mapMatchingWeightValueVo);
					
					biggestList.add(searchItemBLList.get(i));
				}
				
				//검색 값보다 작은 값 저장
				if(inventoryUnSelBundle.compareTo(mapMatchingWeightValueVo.get(selectTonWeight).getMinBundle()) < 0) {
					
					//계산된 번들 및 중량을 BL에 설정
					searchItemBLList.get(i).setWeightMappingCalculateValues(mapMatchingWeightValueVo);
					gatheringList.add(searchItemBLList.get(i));
				}
			}
			
			//찾는 수량에 tolerance 범위 안에 맞는 재고 있음
			if(matchingList.size() > 0) {
				returnList.clear();
				
				//브랜드 무관을 선택했을 때 우선순위 최상위 값을 제외한 값 삭제
				if(itemPriceMatchingSelectVO.getBrandCode().equals("00000000")) {
					List<ItemPriceMatchingBlInfoVO> removeList = new ArrayList<>();
					String brandCode = matchingList.get(getTopPriorIndexFromSearchList(matchingList)).getBrandCode();
					for(ItemPriceMatchingBlInfoVO vo : matchingList) {
						if(!vo.getBrandCode().equals(brandCode)) {
							removeList.add(vo);
						}
					}
					matchingList.removeAll(removeList);
				} 
				
				//주문 수량과 가장 같은 값을 뽑는다.
				returnList.add(matchingList.get(returnClosestMatchingVoIndex(selectTonWeight, selectTonWeight, matchingList)));
				//맞는 수량의 VO 하나 return
				return returnList;
			}
			
			//찾는 수량보다 큰 재고 있음
			if(biggestList.size() > 0) {
				returnList.clear();
				
				//브랜드 무관을 선택했을 때 우선순위 최상위 값을 제외한 값 삭제
				if(itemPriceMatchingSelectVO.getBrandCode().equals("00000000")) {
					List<ItemPriceMatchingBlInfoVO> removeList = new ArrayList<>();
					String brandCode = biggestList.get(getTopPriorIndexFromSearchList(biggestList)).getBrandCode();
					for(ItemPriceMatchingBlInfoVO vo : biggestList) {
						if(!vo.getBrandCode().equals(brandCode)) {
							removeList.add(vo);
						}
					}
					biggestList.removeAll(removeList);
				} 
				
				//주문 수량보다 큰 수중 가장 큰 수를 뽑는다.
				returnList.add(biggestList.get(returnBiggestVoIndex(selectTonWeight, biggestList)));
				//큰 수량의 VO 하나 return
				return returnList;
			}
			
			//찾는 수량보다 작은 재고 있음
			if(gatheringList.size() > 0) {
				returnList.clear();
				
				//Map<Integer, List<ItemPriceMatchingBlInfoVO>> matchedWeightMap = new HashMap<>();
				//Map<Integer, List<ItemPriceMatchingBlInfoVO>> overedWeightMap = new HashMap<>();
				
				// 우선순위별 브랜드 코드 Map
				Map<Integer, String> brandCodeToPriorRank = new HashMap<>();
				// 브랜드코드 별 warehouseCount, sumWeight 형태의 ItemPriceSuWeightVO 
				Map<String, ItemPriceGatheringInfoByBrandCodeVO> gatheringInfoByBrandCodeMap = new HashMap<>();
				
				for(int i = 0; i < gatheringList.size(); i++) {
					int priorRank = gatheringList.get(i).getPriorRank();
					String brandCode = gatheringList.get(i).getBrandCode();
					
					//brandCodeToPriorRank Map 초기화, 우선순위에 따른 브랜드코드 등록 -> 브랜드코드의 우선순위는 중복되지 않는다.
					if(!brandCodeToPriorRank.containsKey(priorRank)) {
						brandCodeToPriorRank.put(priorRank, brandCode);
					}
					
					//brandCodeSumWeightMap Map 초기화, 각 brandCode별 중량에 맞는 
					if(!gatheringInfoByBrandCodeMap.containsKey(brandCode)) {
						ItemPriceGatheringInfoByBrandCodeVO itemPriceSumWeightVO = new ItemPriceGatheringInfoByBrandCodeVO();
						//itemPriceSumWeightVO.setSumWeight(BigDecimal.ZERO);
						//itemPriceSumWeightVO.setWarehouseCount(0);
						itemPriceSumWeightVO.setMatchedWeightMap(new HashMap<Integer, List<ItemPriceMatchingBlInfoVO>>());
						itemPriceSumWeightVO.setOveredWeightMap(new HashMap<Integer, List<ItemPriceMatchingBlInfoVO>>());
						
						gatheringInfoByBrandCodeMap.put(brandCode, itemPriceSumWeightVO);
					}
					
					//주문 수량보다 적은 수량중 25 단위로 작은 수에 tolerance 범위에 들어가는 수량 
					for(int findWeight = selectTonWeight.intValue() - 25; findWeight > 0; findWeight -= 25) {
						//Map<Integer, List<ItemPriceMatchingBlInfoVO>> matchedWeightVo = new HashMap<Integer, List<ItemPriceMatchingBlInfoVO>>();
						//Map<Integer, List<ItemPriceMatchingBlInfoVO>> overedWeightVo = new HashMap<Integer, List<ItemPriceMatchingBlInfoVO>>();
						
						//BigDecimal weight = gatheringList.get(j).getSleInvntryUnsleBnt();
						
						ItemPriceGatheringInfoByBrandCodeVO infoByBrandCodeVO = gatheringInfoByBrandCodeMap.get(brandCode);
						//if(vo.getWarehouseCount() < 4) {
						BigDecimal inventoryUnSelBundle = BigDecimal.valueOf(gatheringList.get(i).getSleInvntryUnsleBundleBnt());
						ItemPriceMatchingWeightCalculateValuesVO matchingWeightValueVo = gatheringList.get(i).getWeightMappingCalculateValues().get(BigDecimal.valueOf(findWeight));
						
						// tolerance 영역에 들어가는 딱 맞는 값
						if(inventoryUnSelBundle.compareTo(matchingWeightValueVo.getMinBundle()) >= 0 &&
								inventoryUnSelBundle.compareTo(matchingWeightValueVo.getMaxBundle()) <= 0) {
							
							// 각 수량에 대해 딱 맞는 값을 저장하는 Map에 해당 주문 수량 값에 대한 BL리스트를 저장한다.
							if(infoByBrandCodeVO.getMatchedWeightMap().containsKey(findWeight)) {
								//선택된 값을 선택하게된 기준 번들 값과 기준 중량을 설정
								gatheringList.get(i).setMatchedSleInvntryUnsleBundleBnt(inventoryUnSelBundle);
								gatheringList.get(i).setMatchedSleInvntryUnsleBnt(gatheringList.get(i).getSleInvntryUnsleBnt());
								
								infoByBrandCodeVO.getMatchedWeightMap().get(findWeight).add(gatheringList.get(i));
							} else {
								infoByBrandCodeVO.getMatchedWeightMap().put(findWeight, new ArrayList<ItemPriceMatchingBlInfoVO>());
								
								//선택된 값을 선택하게된 기준 번들 값과 기준 중량을 설정
								gatheringList.get(i).setMatchedSleInvntryUnsleBundleBnt(inventoryUnSelBundle);
								gatheringList.get(i).setMatchedSleInvntryUnsleBnt(gatheringList.get(i).getSleInvntryUnsleBnt());
								
								infoByBrandCodeVO.getMatchedWeightMap().get(findWeight).add(gatheringList.get(i));
							}
							
							break;
							//gatheringList.remove(j);
							
							//Map<Integer, List<ItemPriceMatchingBlInfoVO>> matchedWeightVo = brandCodeSumWeightMap.get(brandCode).getMatchedWeightMap();
							//matchedWeightVo.put(i, gatheringList.get(j));
							
							//vo.getMatchedWeightMap().get(i).add(gatheringList.get(j));
							
							//int warehouseCount = vo.getWarehouseCount();
							//vo.setWarehouseCount(warehouseCount + 1);
							
							//BigDecimal sumWeight = vo.getSumWeight();
							//vo.setSumWeight(weight.add(sumWeight));
							
						}
						// tolerance 영역을 벗어나는 큰 값
						else if(inventoryUnSelBundle.compareTo(matchingWeightValueVo.getMaxBundle()) > 0) {
							
							// 각 수량에 대해 더 큰 값을 저장하는 Map에 해당 주문 수량 값에 대한 BL리스트를 저장한다.
							if(infoByBrandCodeVO.getOveredWeightMap().containsKey(findWeight)) {
								//선택된 값을 선택하게된 기준 번들 값과 기준 중량을 설정
								gatheringList.get(i).setMatchedSleInvntryUnsleBundleBnt(matchingWeightValueVo.getCollectBundle());
								gatheringList.get(i).setMatchedSleInvntryUnsleBnt(matchingWeightValueVo.getLogicalWeight());
								
								infoByBrandCodeVO.getOveredWeightMap().get(findWeight).add(gatheringList.get(i));
							} else {
								infoByBrandCodeVO.getOveredWeightMap().put(findWeight, new ArrayList<ItemPriceMatchingBlInfoVO>());
								
								//선택된 값을 선택하게된 기준 번들 값과 기준 중량을 설정
								gatheringList.get(i).setMatchedSleInvntryUnsleBundleBnt(matchingWeightValueVo.getCollectBundle());
								gatheringList.get(i).setMatchedSleInvntryUnsleBnt(matchingWeightValueVo.getLogicalWeight());
								
								infoByBrandCodeVO.getOveredWeightMap().get(findWeight).add(gatheringList.get(i));
							}
							
							break;
							//gatheringList.remove(j);
							
							//vo.getOveredWeightMap().get(i).add(gatheringList.get(j));
							
							//int warehouseCount = vo.getWarehouseCount();
							//vo.setWarehouseCount(warehouseCount + 1);
							
							//BigDecimal sumWeight = vo.getSumWeight();
							//vo.setSumWeight(weight.add(sumWeight));
						}
					}
				}
				
				
				// 우선순위별 브랜드 코드 Map
				//Map<Integer, String> brandCodeToPriorRank = new HashMap<>();
				// 브랜드코드 별 warehouseCount, sumWeight 형태의 ItemPriceSuWeightVO 
				//Map<String, ItemPriceSumWeightVO> brandCodeSumWeightMap = new HashMap<>();
				// 각 무게에 맞는 정보가 있는지 확인
				//List<Integer> weightExistList = new ArrayList<>();
				
//				for(int i = 0; i < gatheringList.size(); i++) {
//					
//					int priorRank = gatheringList.get(i).getPriorRank();
//					String brandCode = gatheringList.get(i).getBrandCode();
//					BigDecimal weight = gatheringList.get(i).getSleInvntryUnsleBnt();
//					
//					//brandCodeToPriorRank Map 초기화, 우선순위에 따른 브랜드코드 등록 -> 브랜드코드의 우선순위는 중복되지 않는다.
//					if(!brandCodeToPriorRank.containsKey(priorRank)) {
//						brandCodeToPriorRank.put(priorRank, brandCode);
//					}
//					
//					//brandCodeSumWeightMap Map 초기화, 각 브랜드코드의 warehouse 카운트에 따른 재고량
//					if(!brandCodeSumWeightMap.containsKey(brandCode)) {
//						ItemPriceSumWeightVO itemPriceSumWeightVO = new ItemPriceSumWeightVO();
//						itemPriceSumWeightVO.setSumWeight(BigDecimal.ZERO);
//						itemPriceSumWeightVO.setWarehouseCount(0);
//						
//						brandCodeSumWeightMap.put(brandCode, itemPriceSumWeightVO);
//					}
//					
//					//warehouseCount가 3 이하이고 브랜드코드별 합계 재고량이 원하는 재고량보다 적다면 warehouseCount +1, sumWeight 증가
//					//query값이 재고량이 큰 수 내림차수로 order by 하기 때문에 재고량이 큰 수부터 3개 이하까지만 더한다. -> 큰수가 아니라 맞는 수 부터 한다, 처음 찾는 방법과 같음
//					if(brandCodeSumWeightMap.get(brandCode).getWarehouseCount() < 4 && 
//							brandCodeSumWeightMap.get(brandCode).getSumWeight().compareTo(selectTonWeight) < 0) {
//						
//						int warehouseCount = brandCodeSumWeightMap.get(brandCode).getWarehouseCount();
//						brandCodeSumWeightMap.get(brandCode).setWarehouseCount(warehouseCount + 1);
//						
//						BigDecimal sumWeight = brandCodeSumWeightMap.get(brandCode).getSumWeight();
//						brandCodeSumWeightMap.get(brandCode).setSumWeight(weight.add(sumWeight));
//					}
//					
//				}
				
				
				
				//더한 재고량 중 찾고자 하는 재고량에 못미치는 brandCode들은 삭제
				//brandCodeSumWeightMap.entrySet().removeIf(e -> e.getValue().getSumWeight().compareTo(selectTonWeight) < 0);
				
				int lastPriorRankToBandCode = getLastPriorRankFromBandCodeMap(brandCodeToPriorRank);
				
				//우선순위 높은것 (낮은수) 부터 탐색
				for(int priorRank = 0; priorRank < lastPriorRankToBandCode + 1; priorRank++) {
					
					//우선순위 숫자가 있는 브랜드코드가 존재한다면
					if(brandCodeToPriorRank.containsKey(priorRank)) {
						String brandCode = brandCodeToPriorRank.get(priorRank);
						//원하는 주문량에 가능한 재고(합산재고)가 있는것만 탐색
						if(gatheringInfoByBrandCodeMap.containsKey(brandCode)) {
							
							ItemPriceGatheringInfoByBrandCodeVO gatheringInfoByBrandCodeVo = gatheringInfoByBrandCodeMap.get(brandCode);
							
							//맞는 수량을 찾아서 적용한 BL 값의 각 BL의 수량 값을 모두 더한 값
							int totalMatchedSum = 0;
							//주문 수량에서 25 단위를 뺀 초기값
							int nextMatcingWeight = selectTonWeight.intValue() - 25;
							//모든 주문수량에 맞는 BL을 찾을 때 까지 반복, 최대 찾는 갯수 만큼 반복
							while(nextMatcingWeight > 0 && blCount > 0) {
								
								if(gatheringInfoByBrandCodeVo.getMatchedWeightMap().containsKey(nextMatcingWeight)
										&& !gatheringInfoByBrandCodeVo.getMatchedWeightMap().get(nextMatcingWeight).isEmpty()) {
									
									List<ItemPriceMatchingBlInfoVO> matchingBlInfoVoList = gatheringInfoByBrandCodeVo.getMatchedWeightMap().get(nextMatcingWeight);
									
									//해당 수량에 대한 BL list에 딱맞는 값의 index를 찾아서 return
									int index = returnClosestMatchingVoIndex(selectTonWeight, BigDecimal.valueOf(nextMatcingWeight), matchingBlInfoVoList);
									
									//딱맞는 BL 값을 결과 list에 저장
									returnList.add(matchingBlInfoVoList.get(index));
									//사용한 BL 값을 찾은 삭제한다.
									gatheringInfoByBrandCodeVo.getMatchedWeightMap().get(nextMatcingWeight).remove(index);
									//선택한 수량 값을 전체 수량에 더한다.
									totalMatchedSum += nextMatcingWeight;
									
									//다음에 맞는 수량이 남아 있지 않다면 다음 수량에 관한 while 문을 돌린다.
									if(!gatheringInfoByBrandCodeVo.getMatchedWeightMap().containsKey(selectTonWeight.intValue() - nextMatcingWeight)) {
										nextMatcingWeight = selectTonWeight.intValue() - nextMatcingWeight;
									}
									
									blCount--;
									
								} else {
									nextMatcingWeight -= 25;
								}
								
								//선택 수량을 모두 더한 값이 주문 수량보다 많거나 같으면 탐색 끝
								if(totalMatchedSum >= selectTonWeight.intValue()) {
									//작은 중량 VO 여러개 return
									return returnList;
								}
							}
							
							//더 많은 수량을 찾아서 적용한 BL 값의 주문 수를 모두 더한 값 -> 위의 딱 맞는 수를 제외한 나머지 수량을 기준으로 함
							int totalOveredSum = totalMatchedSum;
							//주문 수량에서 25 단위를 뺀 초기값
							int nextOverWeight = selectTonWeight.intValue() - 25;
							//모든 주문수량에 맞는 BL을 찾을 때 까지 반복, 최대 찾는 갯수 만큼 반복
							while(nextOverWeight > 0 && blCount > 0) {
								
								if(gatheringInfoByBrandCodeVo.getOveredWeightMap().containsKey(nextOverWeight)
										&& !gatheringInfoByBrandCodeVo.getOveredWeightMap().get(nextOverWeight).isEmpty()) {
									
									List<ItemPriceMatchingBlInfoVO> matchingBlInfoVoList = gatheringInfoByBrandCodeVo.getOveredWeightMap().get(nextOverWeight);
									
									//해당 수량에 대한 BL list에 수량	보다 많은 값의 index를 찾아서 return
									int index = returnClosestMatchingVoIndex(selectTonWeight, BigDecimal.valueOf(nextOverWeight), matchingBlInfoVoList);
									returnList.add(matchingBlInfoVoList.get(index));
									gatheringInfoByBrandCodeVo.getOveredWeightMap().get(nextOverWeight).remove(index);
									
									totalOveredSum += nextOverWeight;
									
									if(!gatheringInfoByBrandCodeVo.getOveredWeightMap().containsKey(selectTonWeight.intValue() - nextOverWeight)) {
										nextOverWeight = selectTonWeight.intValue() - nextOverWeight;
									}
									
									blCount--;

								} else {
									nextOverWeight -= 25;
								}
								
								if(totalOveredSum >= selectTonWeight.intValue()) {
									//작은 중량 VO 여러개 return
									return returnList;
								}
							}
							
							//해당 브랜드의 가능한 재고에 대한 warehouse 갯수 만큼만 반복
							//int warehouseCount = 0;
							
							
//							for(int j = 0; j < gatheringList.size(); j++) {
//								if(gatheringList.get(j).getBrandCode().equals(brandCode)
//										&& warehouseCount < brandCodeSumWeightMap.get(brandCode).getWarehouseCount()) {
//									
//									BigDecimal inventoryUnSelBundle = BigDecimal.valueOf(gatheringList.get(j).getSleInvntryUnsleBundleBnt());
//									
//									for(int z = selectTonWeight.intValue() - 25; z > 0; z -= 25) {
//										ItemPriceMatchingWeightValuesVO matchingWeightValueVo = gatheringList.get(j).getWeightMappingCalculateValues().get(BigDecimal.valueOf(z));
//										
//										if(inventoryUnSelBundle.compareTo(matchingWeightValueVo.getMinBundle()) >= 0 &&
//												inventoryUnSelBundle.compareTo(matchingWeightValueVo.getMaxBundle()) <= 0) {
//											returnList.add(gatheringList.get(j));
//											warehouseCount++;
//											
//											break;
//										}
										
//										if(weightExistList.contains(z)) {
//											if(inventoryUnSelBundle.compareTo(matchingWeightValueVo.getMinBundle()) >= 0 &&
//													inventoryUnSelBundle.compareTo(matchingWeightValueVo.getMaxBundle()) <= 0) {
//												returnList.add(gatheringList.get(j));
//												warehouseCount++;
//												
//												break;
//											}
//										}
//										} else {
//											if(inventoryUnSelBundle.compareTo(matchingWeightValueVo.getMaxBundle()) > 0) {
//												returnList.add(gatheringList.get(j));
//												warehouseCount++;
//											}
//										}
//									}
//									
//								}
//							}
//							
//							if(returnList.size() > 0) {
//								//작은 중량 VO 여러개 return
//								return returnList;
//							}
						}
					}
				}

				//재고 없음
				returnList.clear();
				return returnList;						
			}
			//재고 없음
			returnList.clear();
			return returnList;
						
		} else {
			//재고 없음
			returnList.clear();
			return returnList;
		}
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 기준값을 기준으로 BL List에서 가장 적합한 중량을 지닌 BL의 index를 return 한다.
	 * </pre>
	 * @date 2021. 9. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param selectTonWeight
	 * @param matchingValue
	 * @param vo
	 * @return int
	 */
	private int returnClosestMatchingVoIndex(BigDecimal selectTonWeight, BigDecimal matchingValue, List<ItemPriceMatchingBlInfoVO> vo) {
		//ItemPriceMatchingBlInfoVO returnVo = new ItemPriceMatchingBlInfoVO();
		int returnIndex = 0;
		BigDecimal abs = selectTonWeight.subtract(vo.get(0).getWeightMappingCalculateValues().get(matchingValue).getLogicalWeight()).abs();
		
		for(int z = 1; z < vo.size(); z++) {
			BigDecimal compareAbs = selectTonWeight.subtract(vo.get(z).getWeightMappingCalculateValues().get(matchingValue).getLogicalWeight()).abs();
			if(compareAbs.compareTo(abs) < 0) {
				abs = compareAbs;
				returnIndex = z;
			}
		}
		
		return returnIndex;
	}
	
	/**
	 * <pre>
	 * 처리내용: 기준값을 기준으로 BL List에서 가장 큰 이론중량을 지닌 BL의 index를 return 한다.
	 * </pre>
	 * @date 2021. 9. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param selectTonWeight
	 * @param vo
	 * @return int
	 */
	private int returnBiggestVoIndex(BigDecimal selectTonWeight, List<ItemPriceMatchingBlInfoVO> vo) {
		//ItemPriceMatchingBlInfoVO returnVo = new ItemPriceMatchingBlInfoVO();
		int returnIndex = 0;
		BigDecimal selectBiggest = vo.get(0).getWeightMappingCalculateValues().get(selectTonWeight).getLogicalWeight();

		for(int i = 1; i < vo.size(); i++) {
			BigDecimal logicalWeight = vo.get(i).getWeightMappingCalculateValues().get(selectTonWeight).getLogicalWeight();
			if(logicalWeight.compareTo(selectBiggest) > 0) {
				selectBiggest = logicalWeight;
				returnIndex = i;
			}
		}
		
		return returnIndex;
	}
	
	
	/**
	 * <pre>
	 * 처리내용: 해당 BL 값에 최소 주문중량 값과 최대 주문중량 값을 기준으로 25 중량당 tolerance 범위 및 최소,최대,최적 번들 수 와 중량 계산
	 * </pre>
	 * @date 2021. 9. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @param minWeight
	 * @param maxWeight
	 * @return Map<BigDecimal, ItemPriceMatchingWeightValuesVO>
	 */
	private Map<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO> setMathcingValuesMap(ItemPriceMatchingBlInfoVO vo, int minWeight, int maxWeight) {
		
		Map<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO> map = new HashMap<>();
		
		double hundred = 100;
		double bsisWrhousngInvntry = vo.getBsisWrhousngInvntry().doubleValue();
		double bsisWrhousngBundleInvntry = vo.getBsisWrhousngBundleInvntry();
		double sleInvntryUnsleBundleBnt = vo.getSleInvntryUnsleBundleBnt();
		double ctrtcBeginPermWtRate = vo.getCtrtcBeginPermWtRate();
		double ctrtcEndPermWtRate = vo.getCtrtcEndPermWtRate();
		
		for(int i = minWeight; i <= maxWeight; i += minWeight) {
			ItemPriceMatchingWeightCalculateValuesVO valueVo = new ItemPriceMatchingWeightCalculateValuesVO();
			
			//평균중량(평균값)
			double avgNum = Math.round((bsisWrhousngInvntry / bsisWrhousngBundleInvntry) * 10000) / 10000.0;
			//이론중량
			double logicalWeight = Math.round((avgNum * sleInvntryUnsleBundleBnt) * 1000) / 1000.0;
			
			//tolerance 최소
			double minTolerance = i * (Math.round((ctrtcBeginPermWtRate / hundred) * 1000) / 1000.0) * -1;
			//tolerance 최대
			double maxTolerance = i * (Math.round((ctrtcEndPermWtRate / hundred) * 1000) / 1000.0);
			
			//최소중량
			double minTonWeight = minTolerance + i;
			//최대중량
			double maxTonWeight = maxTolerance + i;
			
			if(minTonWeight > maxTonWeight) {
				maxTonWeight = minTonWeight;
			}
			
			//주문 수량에 따른 최소 번들 수
			double minBundle = Math.ceil(minTonWeight / avgNum);
			//주문 수량에 따른 최대 번들 수
			double maxBundle = Math.floor(maxTonWeight / avgNum);
			//주문 수량에 따른 최적 번들 수
			double collectBundle = Math.ceil((minBundle + maxBundle) / 2);
			
			valueVo.setAvgNum(BigDecimal.valueOf(avgNum));
			valueVo.setLogicalWeight(BigDecimal.valueOf(logicalWeight));
			valueVo.setMinTonWeight(BigDecimal.valueOf(minTonWeight));
			valueVo.setMaxTonWeight(BigDecimal.valueOf(maxTonWeight));
			valueVo.setMinBundle(BigDecimal.valueOf(minBundle));
			valueVo.setMaxBundle(BigDecimal.valueOf(maxBundle));
			valueVo.setCollectBundle(BigDecimal.valueOf(collectBundle));
			
			map.put(BigDecimal.valueOf(i), valueVo);
		}
		
		return map;
	}
	
	/**
	 * <pre>
	 * 처리내용: 가장 우선순위가 높은 값의 List index를 return한다
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param list
	 * @return int
	 */
	private int getTopPriorIndexFromSearchList(List<ItemPriceMatchingBlInfoVO> list) {
		
		int returnIndex = 0;
		int priorRank = list.get(0).getPriorRank();
		
		for(int i = 1; i < list.size(); i++) {
			if(priorRank > list.get(i).getPriorRank()) {
				returnIndex = i;
				priorRank = list.get(i).getPriorRank();
			}
		}
		
		return returnIndex;
	}
	
	/**
	 * <pre>
	 * 처리내용: 가장 마지막 우선 순위 값을 return 한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 23.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param map
	 * @return int
	 */
	private int getLastPriorRankFromBandCodeMap(Map<Integer, String> map) {
		
		int priorRank = 0;
		for(Map.Entry<Integer, String> mapEntry : map.entrySet()) {
			if(priorRank < mapEntry.getKey()) {
				priorRank = mapEntry.getKey();
			}
		}
		
		return priorRank;
	}
}
