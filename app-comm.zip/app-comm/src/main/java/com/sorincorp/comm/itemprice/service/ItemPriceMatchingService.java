package com.sorincorp.comm.itemprice.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingSelectVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingWeightCalculateValuesVO;

public interface ItemPriceMatchingService {
	
	/**
	 * <pre>
	 * 처리내용: 검색한 결과값에 맞는 BL리스트를 return 한다.
	 * </pre>
	 * @date 2021. 7. 23.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 5.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param itemPriceVO
	 * @param minSearchBoundaryWeight
	 * @param maxSearchBoundaryWeight
	 * @param maxBlSearchCount
	 * @param weightUnit
	 * @return List<ItemPriceMatchingBlInfoVO>
	 * @throws Exception
	 */
	List<ItemPriceMatchingBlInfoVO> itemBLWithMatchingList(ItemPriceMatchingSelectVO itemPriceMatchingSelectVO
																, int minSearchBoundaryWeight
																, int maxSearchBoundaryWeight
																, int maxBlSearchCount
																, int weightUnit) throws Exception;

	List<ItemPriceMatchingBlInfoVO> itemBLWithMatchingListLimits(ItemPriceMatchingSelectVO itemPriceMatchingSelectVO
																, int minSearchBoundaryWeight
																, int maxSearchBoundaryWeight
																, int maxBlSearchCount
																, int weightUnit) throws Exception;


	/**
	 * <pre>
	 * 처리내용: 해당 BL 값에 최소 주문중량 값과 최대 주문중량 값을 기준으로 25 중량당 tolerance 범위 및 최소,최대,최적 번들 수 와 중량 계산
	 * </pre>
	 * @date 2021. 9. 14.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 14.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @param minWeight
	 * @param maxWeight
	 * @return Map<BigDecimal, ItemPriceMatchingWeightValuesVO>
	 */
	Map<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO> setMathcingValuesMap(
			ItemPriceMatchingBlInfoVO vo
			, int minWeight
			, int maxWeight
			, int weightUnit);
	
	
	
	
	
	/**
	 * <pre>
	 * 처리내용: 평균가 재고 할당 전용, 검색한 결과값에 맞는 BL리스트를 return 한다. (최적 할당 번들 중량을 구하기 용도)
	 * </pre>
	 * @date 2023. 11. 17.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 11. 17.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param itemPriceMatchingSelectVO
	 * @param minSearchBoundaryWeight
	 * @param maxSearchBoundaryWeight
	 * @param maxBlSearchCount
	 * @param weightUnit
	 * @return
	 * @throws Exception
	 */
	List<ItemPriceMatchingBlInfoVO> itemBLWithMatchingListByAsgn(ItemPriceMatchingSelectVO itemPriceMatchingSelectVO
			, int minSearchBoundaryWeight
			, int maxSearchBoundaryWeight
			, int maxBlSearchCount
			, int weightUnit) throws Exception;
}
