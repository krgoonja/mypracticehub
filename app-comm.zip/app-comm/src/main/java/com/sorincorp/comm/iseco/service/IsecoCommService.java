package com.sorincorp.comm.iseco.service;

import java.util.List;

import com.sorincorp.comm.iseco.model.IsecoCommVO;

public interface IsecoCommService {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 *
	 * @date 2022. 11. 4.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 4.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public List<IsecoCommVO> getIsEcoSearchList(IsecoCommVO param) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * 
	 * @date 2022. 11. 25.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2022. 11. 25.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	int getSleInvntryUnsleBundleBnt(IsecoCommVO param) throws Exception;
}
