package com.sorincorp.comm.expectbeginpr.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode(callSuper=false)
public class PcSleExpectBeginPcPremiumPcInfoVO {
    /**
     * 적용 일자
    */
    private String applcDe;
    /**
     * 가격 구분 코드
    */
    private String pcSeCode;
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 판매 방식 코드
    */
    private String sleMthdCode;
    /**
     * 프리미엄 아이디
    */
    private String premiumId;
    /**
     * 권역 변동 금액
    */
    private long dstrctChangeAmount;
    /**
     * 브랜드 그룹 변동 금액
    */
    private long brandGroupChangeAmount;
    /**
     * 브랜드 변동 금액
    */
    private long brandChangeAmount;
    /**
     * 프리미엄 원화 금액
    */
    private long premiumWonAmount;
    /**
     * 프리미엄 달러 금액
    */
    private java.math.BigDecimal premiumDollarAmount;
    /**
     * LME 조정 계수
    */
    private java.math.BigDecimal lmeMdatCffcnt;
    /**
     * FX 조정 계수
    */
    private java.math.BigDecimal fxMdatCffcnt;
    /**
     * 조정 계수 프리미엄 원화 금액
    */
    private long mdatCffcntPremiumWonAmount;
    /**
     * 조정 계수 프리미엄 달러 금액
    */
    private java.math.BigDecimal mdatCffcntPremiumDollarAmount;
    /**
     * 최종 프리미엄 원화 금액
    */
    private long lastPremiumWonAmount;
    /**
     * 최종 프리미엄 달러 금액
    */
    private java.math.BigDecimal lastPremiumDollarAmount;
    /**
     * 프리미엄 기준 금액
    */
    private long premiumStdrAmount;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;


}
