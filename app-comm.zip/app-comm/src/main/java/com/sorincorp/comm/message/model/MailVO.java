package com.sorincorp.comm.message.model;

import org.springframework.validation.annotation.Validated;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * MailVO.java
 * @version
 * @since 2021. 6. 21.
 * @author srec0042
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Validated
public class MailVO extends CommonVO{
	
	/**
	 *  serialVersion UID
	 */
	private static final long serialVersionUID = -2273214040078257428L;

	/**
     * 뉴스레터 제목
    */
    private String nsltSj;
    
    /**
     * 뉴스레터 내용
    */
    private String nsltCn;
	
    /**
     * 핸드폰 번호
    */
    private String rcverTelno; 
    
    /**
     * 이름
    */
	private String name; 
	
	/**
     * 이메일
    */
	private String email; 
	
	/**
     * 핸드폰 번호
    */
	private String phoneNum;
    
	/**
     * 뉴스레터 발송 일시
    */
	private int nsltSndngDt;
	
	/**
     * 메일 번호
    */
	private int mailNo; 
	
	/**
     * 총 메일 발송 건수
    */
	private int mailSendCnt; 
	
	/**
     * 템플릿 번호
    */
	private int mailTmptSeq; 
	
	/** 업무 구분 코드 */
	private String jobSeCode;

	/** 발신자 이메일 */
	private String sntoEmail;
	
	/**
     * 치환 데이터
    */
    private String mailReceiverReplaceJson;
    
	/**
     * 발신자 아이디
    */
    private String mailSendUserId;
    
	/**
     *  발신자 이메일 주소
    */
    private String mailSendEmail;
    
	/**
     *  뉴스레터 첨부파일 번호1
    */
    private String nsltAtchmnflNoOne;
    
	/**
     *  뉴스레터 첨부파일 번호2
    */
    private String nsltAtchmnflNoTwo;
    
	/**
     *  뉴스레터 첨부파일 번호3
    */
    private String nsltAtchmnflNoThree;
     
	/**
     *   회원 번호
    */
     private String memberNo;

 	/**
      *   이메일 수신자 번호
     */
    private int mailReceiverNo;
    
    
    private String MberKndSeCode;
    
    private int msgKey;
    
	/**
	 * 업체 번호
	 */
	private String entrpsNo;
 
	/**
     * 이메일 템플릿 반복
    */
    private String nsltRe;
    
    /**
     * 발송 그룹 코드 (내부사용자 메일 발송 추가 여부)
     */
    private String sndngGroupCode;
    
    /**
     * 예외 발송 옵션 여부
     */
    private String excpSndngOptnAt;
    
    /**
     * 웹마스터 전송 여부
     */
    private String webmasterTrnsmisAt;
    
    /**
     * 추가 담당자 전송 여부
     */
    private String aditChargerTrnsmisAt;
    
	/**
	 * 회원 권한_참조1 : MBER_SE_CODE 
	 */
	private String mberSeCode;
    
}
