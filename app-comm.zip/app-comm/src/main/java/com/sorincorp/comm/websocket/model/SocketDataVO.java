package com.sorincorp.comm.websocket.model;

import lombok.Data;

@Data
public class SocketDataVO {
	/** id */
	private String id;

	/** message */
	private String message;
}
