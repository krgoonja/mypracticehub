package com.sorincorp.comm.premium.service;

import java.util.Map;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

import com.sorincorp.comm.pcInfo.model.LivePremiumVO;

@Service
public class ItPremiumStdrBasVoServiceImpl implements ItPremiumStdrBasVoService {

	Map<String, TreeSet<LivePremiumVO>> itPremiumStdrBasVo;

	public ItPremiumStdrBasVoServiceImpl() {
		if (itPremiumStdrBasVo == null)
			this.itPremiumStdrBasVo = new ConcurrentHashMap<String, TreeSet<LivePremiumVO>>();
	}

	@Override
	public Map<String, TreeSet<LivePremiumVO>> getItPremiumStdrBasVo() {
		return itPremiumStdrBasVo;
	}

	/**
	 * ItPremiumStdrBasVo 값 가져오기
	 */
	@Override
	public TreeSet<LivePremiumVO> getItPremiumStdrBasVo(String groupKey) {
		if (!itPremiumStdrBasVo.containsKey(groupKey)) {
			itPremiumStdrBasVo.put(groupKey, new TreeSet<LivePremiumVO>());
		}

		return itPremiumStdrBasVo.get(groupKey);
	}

	/**
	 * ItPremiumStdrBasVo 값 저장
	 */
	@Override
	public void setItPremiumStdrBasVo(Map<String, TreeSet<LivePremiumVO>> itPremiumStdrBasVo) {
		this.itPremiumStdrBasVo = itPremiumStdrBasVo;
	}

}
