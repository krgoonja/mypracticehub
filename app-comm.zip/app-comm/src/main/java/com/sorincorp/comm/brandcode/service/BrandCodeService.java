package com.sorincorp.comm.brandcode.service;

import java.util.List;

import com.sorincorp.comm.brandcode.model.BrandCodeVO;

public interface BrandCodeService {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 12.			srec0030			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	public void initBrandCode() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 12.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	public List<BrandCodeVO> getBrandCodeList(String brandGroupCode) throws Exception;
	public List<BrandCodeVO> getBrandCodeList(String brandGroupCode, boolean clickAt) throws Exception;

	public List<BrandCodeVO> getBrandCodeList(String brandGroupCode, String entrpsNo) throws Exception;
	public List<BrandCodeVO> getBrandCodeList(String brandGroupCode, String entrpsNo, boolean clickAt) throws Exception;
	
	public List<BrandCodeVO> getBrandCodeList(String metalCode, String brandGroupCode, String entrpsNo) throws Exception;
	public List<BrandCodeVO> getBrandCodeList(String metalCode, String brandGroupCode, String entrpsNo, boolean clickAt) throws Exception;
	
	public List<BrandCodeVO> getBrandOthersCodeList(String brandGroupCode) throws Exception;

	public List<BrandCodeVO> getTopPriorRankBrandCodeList(String brandGroupCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 12.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param brandCodeList
	 * @return
	 * @throws Exception
	 */
	public String getBrandCodeListStr(List<BrandCodeVO> brandCodeList, String val) throws Exception;
}
