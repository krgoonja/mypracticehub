package com.sorincorp.comm.bsnInfo.mapper;

import java.util.List;

import org.springframework.cache.annotation.Cacheable;

import com.sorincorp.comm.bsnInfo.model.BsnDlvyManageVO;
import com.sorincorp.comm.bsnInfo.model.BsnManageVO;
import com.sorincorp.comm.bsnInfo.model.CdtlnInfoVO;
import com.sorincorp.comm.bsnInfo.model.HvofTimeVO;
import com.sorincorp.comm.bsnInfo.model.LmeClndrVO;
import com.sorincorp.comm.bsnInfo.model.RestTermVO;
import com.sorincorp.comm.bsnInfo.model.RestdeFxLmeVO;
import com.sorincorp.comm.bsnInfo.model.RestdeVO;
import com.sorincorp.comm.bsnInfo.model.RltmEndTimeVO;
import com.sorincorp.comm.bsnInfo.model.SidecarVO;
import com.sorincorp.comm.bsnInfo.model.WrtmStdrAmoutInfoVO;

public interface BsnInfoMapper {

	/**
	 * <pre>
	 * 조회 날짜의 최신 영업관리 정보를 가져온다.
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param occrrncDe 조회 날짜
	 * @return
	 * @throws Exception
	 */
	BsnManageVO getBsnManageInfo(String occrrncDe) throws Exception;
	
	/**
	 * <pre>
	 * 오늘날짜의 영업 배송 관리 정보를 금속 코드별로 가져온다.
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	BsnDlvyManageVO getBsnDlvyManageInfo(String occrrncDe, String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 조회한 날짜의 LME 휴일 정보를 가져온다.
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param occrrncDe 조회 날짜
	 * @return
	 * @throws Exception
	 */
	LmeClndrVO getLmeClndrInfo(String occrrncDe) throws Exception;
	
	/**
	 * <pre>
	 * 조회한 날짜의 휴무 시간 관리 정보를 가져온다.
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param occrrncDe 조회 날짜
	 * @return
	 * @throws Exception
	 */
	HvofTimeVO getHvofTimeManageInfo(String occrrncDe) throws Exception;
	
	/**
	 * <pre>
	 * 조회한 날짜의 이벤트 휴일 개수를 조회한다
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param occrrncDe 조회 날짜
	 * @return
	 * @throws Exception
	 */
	int getEventRestdeManageInfo(String occrrncDe) throws Exception;
	
	/**
	 * <pre>
	 * 오늘날짜에 해당하는 사이드카 정보를 금속 코드별로 가져온다.
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	SidecarVO getSidecarManageInfo(String occrrncDe, String metalCode) throws Exception;
	
	/**
	 * <pre>
	 * 영업 이후의 영업 대기시간에 대한 정보를 조회
	 * </pre>
	 * @date 2021. 12. 14.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 14.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param nowDate
	 * @return
	 * @throws Exception
	 */
	@Cacheable(cacheNames = "Second_Time", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	List<RestTermVO> getRestTermInfo(String nowDate, String sleMthdCode) throws Exception;
	
	/**
	 * <pre>
	 * 조회 날짜의 FX, LME 휴일 여부를 조회한다.
	 * </pre>
	 * @date 2022. 1. 3.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 3.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param applcDe
	 * @return
	 * @throws Exception
	 */
	RestdeFxLmeVO getRestdeFxLmeInfo(String applcDe) throws Exception;
	
	/**
	 * <pre>
	 * 입력된 날짜에 해당하는 휴일 정보를 가져온다.
	 * </pre>
	 * @date 2022. 06. 16.
	 * @author srec0064
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 06. 16.		srec0064		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param nowDate
	 * @return
	 * @throws Exception
	 */
	@Cacheable(cacheNames = "Second_Time", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	RestdeVO getRestdeInfoWithoutHvofTime(String nowDate) throws Exception;

	/**
	 * <pre>
	 * 조회 날짜의 최신 여신관리 정보를 가져온다.
	 * </pre>
	 * @date 2022. 7. 8.
	 * @author srec0061
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 8.		srec0061		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param occrrncDe 조회 날짜
	 * @return
	 * @throws Exception
	 */
	CdtlnInfoVO getCdtlnInfo(String occrrncDe) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 계약금(증거금) 기준 금액 관리 기본 정보를 조회한다
	 * </pre>
	 * @date 2022. 7. 22.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 22.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param applcDe
	 * @param metalCode
	 * @return
	 */
	WrtmStdrAmoutInfoVO getItWrtmStdrAmoutMangeBas(String applcDe, String metalCode);
	
	/**
	 * <pre>
	 * 처리내용: 계약금(증거금) 기준 금액 관리 상세 정보를 조회한다
	 * </pre>
	 * @date 2022. 7. 22.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 22.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	List<WrtmStdrAmoutInfoVO> getItWrtmStdrAmoutMangeDtlList(WrtmStdrAmoutInfoVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 영업 종료 시간 조회
	 * </pre>
	 * @date 2023. 9. 26.
	 * @author srec0081
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 9. 26.			srec0081			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	RltmEndTimeVO selectRltmEndTime();
	
	List<RltmEndTimeVO> selectLiveOperTimeAll();
	
	/**
	 * <pre>
	  * 최근 휴무시간 조회
	  * </pre>
	  * @date 2023. 12. 15.
	  * @author bok3117
	  * @history 
	  * <pre>
	  * -------------------------------------------------------------------------
	  * 변경일				작성자			변경내용
	  * -------------------------------------------------------------------------
	  * 2023. 12. 15.		bok3117			최초작성
	  * -------------------------------------------------------------------------
	  * </pre>
	  * @return
	  * @throws Exception
	  */
	RestdeVO getTodayTodayHvofTime() throws Exception;
}
