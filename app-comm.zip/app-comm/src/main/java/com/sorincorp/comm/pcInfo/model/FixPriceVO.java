package com.sorincorp.comm.pcInfo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class FixPriceVO implements Serializable {
	private static final long serialVersionUID = -6535040633706593106L;
	/**
	 * 프리미엄 아이디
	 */
	private String premiumId;
	/**
	 * 고정가 평균 구매 원가
	 */
	private java.math.BigDecimal hghnetprcAvrgPurchsPrmpc;
	/**
	 * 고정가 권역 변동 금액
	 */
	private java.math.BigDecimal hghnetprcDstrctChangeAmount;
	/**
	 * 고정가 브랜드 그룹 변동 금액
	 */
	private java.math.BigDecimal hghnetprcBrandGroupChangeAmount;
	/**
	 * 고정가 브랜드 변동 금액
	 */
	private java.math.BigDecimal hghnetprcBrandChangeAmount;
	/**
	 *등급 변동 금액
	 */
	private java.math.BigDecimal gradChangeAmount;
	/**
	 * 평균 이익 금액
	 */
	private java.math.BigDecimal avrgProfitAmount;     
	/**
	 * 판매 가격
	 */
	private java.math.BigDecimal slePc;
	
	/**
	 * 고정가 판매 금액
	 */
	private java.math.BigDecimal hghnetprcSleAmount;
	
	/**
	 * 프리미엄 번호
	 */
	private String premiumNo;
	/**
	 * 금속 코드
	 */
	private String metalCode;
	/**
	 * 아이템 순번
	 */
	private int itmSn;
	/**
	 * 권역 대분류 코드
	 */
	private String dstrctLclsfCode;
	/**
	 * 권역명
	 */
	private String dstrctLclsFName;
	/**
	 * 브랜드 그룹 코드
	 */
	private String brandGroupCode;
	/**
	 * 브랜드 코드
	 */
	private String brandCode;
	/**
	 * 업체 번호
	 */
	private String entrpsNo;
	/**
	 * 업체 등급 번호
	 */
	private long entrpsGradNo;
	/**
	 * 고정가 매입가격
	 */
	private java.math.BigDecimal puchasPc;
	
	private String occrrncDe;
	
	private String termType;
	private String termValue;
	
	/**
	 * 케이지몰 단위 기간 코드
	 */
	private String sorinmallUnitPdCode;
	
	/**
	 * 제한 중량
	 */
	private String lmttWt;
	
	/**
	 * 고시 금액
	 */
	private String ntfcAmount;
	
	/**
	 * 대운송비 금액
	 */
	private String lrgetrnsprtctAmount;
	
	/**
	 * 마진 금액
	 */
	private String marginAmount;
	
	/**
	 * 아이템 코드
	 */
	private String itmCode;
	
	/**
	 * 상품명
	 */
	private String goodsNm;
	
	/**
	 * 전시 상품명
	 */
	private String dspyGoodsNm;
	
	/**
	 * 권역 대분류 명
	 */
	private String dstrctLclsfNm;
	
	/**
	 * 브랜드 그룹명
	 */
	private String brandGroupNm;
	
	/**
	 * 브랜드 명
	 */
	private String brandNm;
	/**
	 * 적용년월
	 */
	private String applcYm;
	
	/**
	 * 금속분류코드
	 */
	private String metalClCode;
	
	/**
	 * 주문 선택 중량
	 */
	private int orderWeight;
}
