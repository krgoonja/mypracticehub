package com.sorincorp.comm.order.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.order.mapper.CommFinalBlceCheckMapper;
import com.sorincorp.comm.order.model.CommBlceInfoVO;

import lombok.extern.slf4j.Slf4j;

/**
 * CommFinalBlceCheckServiceImpl.java
 * 최종 잔액 체크 Service 구현체 클래스
 * @version
 * @since 2023. 5. 11.
 * @author srec0066
 */
@Slf4j
@Service
public class CommFinalBlceCheckServiceImpl implements CommFinalBlceCheckService {

	@Autowired
	private CommFinalBlceCheckMapper commFinalBlceCheckMapper;

	/**
	 *	특정업체의 해당 결제수단에 따른
	 *
	 * 	1.거래 가능 여부(boolean)
	 * 	  최종 잔액 >= 거래 예상 금액: 거래 가능(true)
	 *    최종 잔액 <  거래 예상 금액: 거래 불가능(false)
	 *
	 * 	2.최종 잔액 정보를 리턴
	 * 	조회되는 잔액 정보는 [주문] [상환/출금]의 경우에 따라 달라짐
	 *
	 * 	[주문]
	 * 	 	한도 잔액 조회   : 전자상거래보증 or 케이지크레딧
	 * 		이월렛 잔액 조회  : 이월렛(증거금 포함)
	 *
	 * 	[상환/출금]
	 * 		이월렛 잔액 조회  : 전자상거래보증 or 케이지크레딧 or 이월렛(증거금 포함)
	 */
	@Override
	public CommBlceInfoVO selectFinalBlceInfoBySetleMn(String entrpsNo, String setleMthdCode, String orderEventAt, long delngExpectAmount) throws Exception {
		log.info("[CommFinalBlceCheckServiceImpl] IN 최종 잔액 정보 조회 :: entrpsNo=" + entrpsNo + ", setleMthdCode=" + setleMthdCode + ", orderEventAt="+ orderEventAt);

		/** 최종 잔액 정보 조회 */
		CommBlceInfoVO blceInfo = commFinalBlceCheckMapper.selectFinalBlceInfoBySetleMn(entrpsNo, setleMthdCode, orderEventAt);
		log.info("[CommFinalBlceCheckServiceImpl] 잔액 정보 조회 결과 :: " + blceInfo);
		Optional.ofNullable(blceInfo).orElseThrow(() -> { return new CommCustomException("최종 잔액 정보 미존재.");});

		/** 거래 가능 여부: '최종 잔액 >= 거래 예상 금액' 인 경우만 거래 가능 */
		if(blceInfo.getFinalBlce() >= delngExpectAmount) {
			blceInfo.setDelngPossAt(true);
		}

		log.info("[CommFinalBlceCheckServiceImpl] 최종 잔액: " + blceInfo.getFinalBlce() + ", 총 예수금액 합: " + blceInfo.getTotAdvrcvAmount() + ", 거래 예상 금액: " + delngExpectAmount + " >> 최종 거래 가능 여부: " + blceInfo.isDelngPossAt());

		return blceInfo;
	}

}
