package com.sorincorp.comm.util;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;

import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class TimerUtil {
	private final long offset;

	private static long calculateOffset() {
		final long nano = System.nanoTime();
		final long nanoFromMilli = System.currentTimeMillis() * 1_000_000;
		return nanoFromMilli - nano;
	}

	public TimerUtil() {
		final int count = 1000;
		BigDecimal offsetSum = BigDecimal.ZERO;
		for (int i = 0; i < count; i++) {
			offsetSum = offsetSum.add(BigDecimal.valueOf(calculateOffset()));
		}
		offset = (offsetSum.divide(BigDecimal.valueOf(count))).longValue();
	}

	public long nowNano() {
		return offset + System.nanoTime();
	}

	public long nowMicro() {
		return (offset + System.nanoTime()) / 1000;
	}

	public long nowMilli() {
		return (offset + System.nanoTime()) / 1000000;
	}
	
	public String nowNanoStr() {
		long now = nowNano();
		String dateTime = new SimpleDateFormat("yyyyMMddHHmmss").format(now / 1000000);
		String subTime = String.format("%09d", now % 1000000000);
		return dateTime + subTime;
	}

	public String nowMicroStr() {
		long now = nowMicro();
		String dateTime = new SimpleDateFormat("yyyyMMddHHmmss").format(now / 1000);
		String subTime = String.format("%06d", now % 1000000);
		return dateTime + subTime;
	}

	public String nowMilliStr() {
		long now = nowMilli();
		String dateTime = new SimpleDateFormat("yyyyMMddHHmmss").format(now);
		String subTime = String.format("%03d", now % 1000);
		return dateTime + subTime;
	}
}
