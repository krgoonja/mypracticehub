package com.sorincorp.comm.itemcode.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class ItemCodeVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 2601944606186564957L;
	/**
	 *
	 */
	private String metalCode;
	private String metalCodeNm;
	private String metalClCode;
	/**
	 *
	 */
	private String subCode;
	/**
	 *
	 */
	private String codeNm;
	/**
	 *
	 */
	private String codeDetailNm;

	private String goodsNm;
	private String ftrsProcessAt;
	private String itmCode;
	private String dspyGoodsNm;

	/**
	 * 고정가 여부
	 */
	private String fixingPcAt;
	/**
	 * 라이브가 여부
	 */
	private String livePcAt;
	/**
	 * 지정가여부
	 */
	private String appnPcAt;
    /**
     * 평균 가 여부
    */
    private String avrgPcAt;
	/**
	 * 고객 여부
	 */
	private String cstmrAt;
	/**
	 * 벤더 여부
	 */
	private String vendorAt;
	
	/**
	 * 판매단위중량
	 */
	private int sleUnitWt;

	/**
	 * 평균가 사용 여부
	 */
	private String avrgpcUseAt;

}
