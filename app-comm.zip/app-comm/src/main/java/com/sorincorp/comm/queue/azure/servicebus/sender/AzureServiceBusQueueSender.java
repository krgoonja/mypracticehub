package com.sorincorp.comm.queue.azure.servicebus.sender;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.sorincorp.comm.order.model.CommLimitOrderQueueMsgVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderQueueMsgVO;

import lombok.extern.slf4j.Slf4j;

/**
 * AzureServiceBusQueueSender.java
 * Azure Service Bus Queue Sender
 * 
 * @version
 * @since 2023. 4. 20.
 * @author srec0049
 */
@Component
@Slf4j
@PropertySource(value = "classpath:/config/azure/azure-${spring.profiles.active}.properties", ignoreResourceNotFound = true)
public class AzureServiceBusQueueSender {
	
	/**
	 * 템플릿 기반 메시지 전송 클래스
	 */
	@Autowired
	private JmsTemplate jmsTemplate;
	
	/**
	 * Test 테스트 Queue 이름
	 */
	@Value("${spring.jms.servicebus.destination.test}")
	private String testQueue;
	
	/**
	 * 지정가 Queue 이름
	 */
	@Value("${spring.jms.servicebus.destination.limitOrder}")
	private String limitOrderQueue;
	
	/**
	 * 잠정 Test 테스트 Queue 이름
	 */
	@Value("${spring.jms.servicebus.destination.prvsnlTest}")
	private String prvsnlTestQueue;
	
	/**
	 * 잠정 지정가 Queue 이름
	 */
	@Value("${spring.jms.servicebus.destination.prvsnlLimitOrder}")
	private String prvsnlLimitOrderQueue;
	
	
	/**
	 * <pre>
	 * 처리내용: jmsTemplate을 통해 Test Queue로 메시지 보내기
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param commLimitOrderQueueMsgVO
	 */
	public void testQueueSend(CommLimitOrderQueueMsgVO commLimitOrderQueueMsgVO) {
		log.info(">> AzureServiceBusQueueSender testQueueSend in~~");
		log.info(">> AzureServiceBusQueueSender testQueueSend testQueue : " + testQueue);
		
		// Queue로 메시지(CommLimitOrderQueueMsgVO 객체) 보내기
		jmsTemplate.convertAndSend(testQueue, commLimitOrderQueueMsgVO);
	}
	
	/**
	 * <pre>
	 * 처리내용: jmsTemplate을 통해 Queue로 메시지 보내기
	 * </pre>
	 * @date 2023. 4. 20.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 20.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param commLimitOrderQueueMsgVO
	 */
	public void send(CommLimitOrderQueueMsgVO commLimitOrderQueueMsgVO) {
		log.info(">> AzureServiceBusQueueSender send in~~");
		log.info(">> AzureServiceBusQueueSender send limitOrderQueue : " + limitOrderQueue);
		
		// Queue로 메시지(CommLimitOrderQueueMsgVO 객체) 보내기
		jmsTemplate.convertAndSend(limitOrderQueue, commLimitOrderQueueMsgVO);
	}
	
	/**
	 * <pre>
	 * 처리내용: jmsTemplate을 통해 잠정 Test Queue로 메시지 보내기
	 * </pre>
	 * @date 2024. 8. 27.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 8. 27.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commPrvsnlLimitOrderQueueMsgVO
	 */
	public void prvsnlTestQueueSend(CommPrvsnlLimitOrderQueueMsgVO commPrvsnlLimitOrderQueueMsgVO) {
		log.info(">> AzureServiceBusQueueSender prvsnlTestQueueSend in~~");
		log.info(">> AzureServiceBusQueueSender prvsnlTestQueueSend prvsnlTestQueue : " + prvsnlTestQueue);
		
		// Queue로 메시지(CommLimitOrderQueueMsgVO 객체) 보내기
		jmsTemplate.convertAndSend(prvsnlTestQueue, commPrvsnlLimitOrderQueueMsgVO);
	}
	
	/**
	 * <pre>
	 * 처리내용: jmsTemplate을 통해 잠정 Queue로 메시지 보내기
	 * </pre>
	 * @date 2024. 8. 27.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 8. 27.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commPrvsnlLimitOrderQueueMsgVO
	 */
	public void prvsnlSend(CommPrvsnlLimitOrderQueueMsgVO commPrvsnlLimitOrderQueueMsgVO) {
		log.info(">> AzureServiceBusQueueSender prvsnlSend in~~");
		log.info(">> AzureServiceBusQueueSender prvsnlSend prvsnlLimitOrderQueue : " + prvsnlLimitOrderQueue);
		
		// Queue로 메시지(CommLimitOrderQueueMsgVO 객체) 보내기
		jmsTemplate.convertAndSend(prvsnlLimitOrderQueue, commPrvsnlLimitOrderQueueMsgVO);
	}
	
}
