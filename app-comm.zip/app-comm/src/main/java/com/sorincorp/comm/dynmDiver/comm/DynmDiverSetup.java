package com.sorincorp.comm.dynmDiver.comm;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.dynmDiver.mapper.DynmDiverMapper;
import com.sorincorp.comm.dynmDiver.model.DynmDiverCommVO;
import com.sorincorp.comm.dynmDiver.model.DynmDiverPremiumBrandVO;
import com.sorincorp.comm.dynmDiver.model.DynmDiverPremiumStdrVO;
import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.order.service.CommDashboardWebsocketService;
import com.sorincorp.comm.pcInfo.mapper.PcInfoMapper;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.RedisUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * <pre>
 * 처리내용: 다이버 COMM
 * </pre>
 * @date 2024. 1. 16.
 * @author hamyoonsic
 * @history
 * ------------------------------------------------
 * 변경일					작성자				변경내용
 * ------------------------------------------------
 * 2024. 1. 16.			hamyoonsic			    최초작성
 * ------------------------------------------------
 * @return
 */
@Slf4j
@Component
public class DynmDiverSetup {

    @Autowired
    private DynmDiverMapper dynmDiverMapper;

    @Autowired
    private AssignService assignService;

    @Autowired
    private RedisPubSubService redisPubSubService;

    @Autowired
    PcInfoMapper pcInfoMapper;

    /** 다이버 작동여부 BO 구독 웹소켓 서비스 */
    @Autowired
    private CommDashboardWebsocketService commDashboardWebsocketService;

    @Autowired
    private RedisUtil redisUtil;

    private String diverOption = DiverOption.OFF.value;    //다이버 ON/OFF 설정 값

    private int diverStatusCode = 0;    //다이버 상태 값

    private int diverScopekrw = 0;    //다이버 프리미엄 조정 최대값 (KRW)

    private BigDecimal diverScopeUsd = BigDecimal.ZERO;    //다이버 프리미엄 조정 최대값 (USD)

    private int diverTime = 0;    //다이버 발동 시간 범위 (초)

    private int diverMt = 0;    //다이버 발동 톤수

    private BigDecimal diverMdatVal = BigDecimal.ZERO;    //다이버 분봉 조정 값

    private long nowPc = 0;    //실시간 판매 가격

    private BigDecimal diverSpex = BigDecimal.ZERO;    //환율 (매매기준율)

    private BigDecimal diveKrw = BigDecimal.ZERO;  //프리미엄 인하 가격
    private BigDecimal surfaceKrw = BigDecimal.ZERO;  //프리미엄 인상 가격

    public enum RequestCode {
        INIT("I"), UPDATE("U"), DELETE("D");
        public final String value;

        RequestCode(String value) {
            this.value = value;
        }
    }
    public enum DiverOption {
        ON("Y"), OFF("N");
        public final String value;
        DiverOption(String value) {
            this.value = value;
        }
    }
    public enum DiverStatusCode {
        WAIT(0), UP(1), DOWN(2);
        public final int value;
        DiverStatusCode(int value) {
            this.value = value;
        }
    }

    public void initialize() {

        //초기화
        try {
            DynmDiverCommVO premiumDiverInfo = dynmDiverMapper.selectPremiumDiverInfo();

            Optional.ofNullable(premiumDiverInfo).orElse((new DynmDiverCommVO()));

            int diverMotnTon = Integer.parseInt(Optional.ofNullable(premiumDiverInfo.getDiverMotnTon()).orElse("0"));
            int diverMotnTimeScope = Integer.parseInt(Optional.ofNullable(premiumDiverInfo.getDiverMotnTimeScope()).orElse("0"));
            String diverAt = Optional.ofNullable(premiumDiverInfo.getDiverAt()).orElse(DiverOption.OFF.value);
            int diverMotnKrwScope = Optional.ofNullable(premiumDiverInfo.getDiverMotnKrwScope()).orElse(0);
            int diverMotnKrw = Optional.ofNullable(premiumDiverInfo.getDiverMdatVal()).orElse(0);
            BigDecimal spex = Optional.ofNullable(premiumDiverInfo.getSpex()).orElse(BigDecimal.ZERO);

            log.info("premiumDiverInfo : {}",premiumDiverInfo.toString());

            diverOption = diverAt;
            diverTime = diverMotnTimeScope;
            diverMt = diverMotnTon;
            diverScopekrw = diverMotnKrwScope;
            diverSpex = spex;
            diverMdatVal = new BigDecimal(diverMotnKrw);

            log.info("================ DynmDiverSetup initialize starts ================");
            log.info("DynmDiverSetup initialize diverOption: " + diverOption);
            log.info("DynmDiverSetup initialize diverScopekrw: " + diverScopekrw);
            log.info("DynmDiverSetup initialize diverTime: " + diverTime);
            log.info("DynmDiverSetup initialize diverMt: " + diverMt);
            log.info("DynmDiverSetup initialize diverMdatVal: " + diverMdatVal);
            log.info("DynmDiverSetup initialize diverSpex: " + diverSpex);
            log.info("DynmDiverSetup initialize diverStatusCode: " + diverStatusCode);
            log.info("=============================================================");
        } catch (Exception e){
            log.error("DynmDiverSetup initialize -> message : " + e.getMessage());
        }
    }

    public DynmDiverCommVO diverMotnCndCnfirm() throws Exception {
        log.info("diverMotnCndCnfirm start");
        DynmDiverCommVO diverMotnCndVO = new DynmDiverCommVO();
        try {
            diverMotnCndVO.setDiverAt(diverOption);
            diverMotnCndVO.setDiverStatusCode(diverStatusCode);

            log.info("diverMotnCndCnfirm power switch {}", diverOption);
            if(diverOption.equals(DiverOption.ON.value)) {
                if(diverStatusCode == DiverStatusCode.UP.value || diverStatusCode == DiverStatusCode.DOWN.value) {
                    log.info("diverMotnCndCnfirm [ Activating ] diverStatusCode {}", diverStatusCode);
                } else {
                    log.info("diverMotnCndCnfirm diverStatusCode {}", diverStatusCode);

                    nowPc = Optional.ofNullable(dynmDiverMapper.selectNowPc()).orElseThrow(() -> {
                        log.info("diverMotnCndCnfirm selectNowPc ERROR ");
                        return new CommCustomException("rltmSlePc null");
                    });

                    long goalPc = nowPc - diverScopekrw;
                    diverMotnCndVO.setNowPc(nowPc);
                    diverMotnCndVO.setGoalPc(goalPc);

                    //지정가 주문 조회
                    DynmDiverCommVO limitOrderInfoVO = dynmDiverMapper.selectDiverLimitOrderList(diverMotnCndVO);
                    int limitOrderWtSum =  limitOrderInfoVO.getLimitOrderWtSum();
                    long limitOrderMinPc =  limitOrderInfoVO.getLimitOrderMinPc();

                    diverMotnCndVO.setLimitOrderMinPc(limitOrderMinPc);
                    diverMotnCndVO.setLimitOrderWtSum(limitOrderWtSum);

                    log.info("diverMotnCndCnfirm limitOrderWtSum : {}", limitOrderWtSum);
                    log.info("diverMotnCndCnfirm limitOrderMinPc : {}", limitOrderMinPc);
                    log.info("diverMotnCndCnfirm diverMt : {} ",diverMt);
                    log.info("diverMotnCndCnfirm diverTime : {}",diverTime);
                }
            } else {
                commDashboardWebsocketService.publishDiverRunning(false, true);
            }
        } catch(Exception e) {
            log.error("diverMotnCndCnfirm" + e.toString() + " -> message : " + e.getMessage());
        } finally {
            log.info("diverMotnCndCnfirm end");
            return diverMotnCndVO;
        }
    }

    public void executeDiver() throws Exception {
        //다이버 발동 조건 확인
        DynmDiverCommVO diverMotnCndVO = Optional.ofNullable(diverMotnCndCnfirm()).orElseThrow(() -> {
            log.info("executeDiver selectNowPc ERROR diverMotnCndVO null");
            return new CommCustomException("diverMotnCndVO null");
        });

        int limitMt = Optional.ofNullable(diverMotnCndVO.getLimitOrderWtSum()).orElseThrow(() -> {
            log.info("executeDiver selectNowPc ERROR limitMt null");
            return new CommCustomException("limitOrderWtSum null");
        });

        long limitOrderMinPc = Optional.ofNullable(diverMotnCndVO.getLimitOrderMinPc()).orElseThrow(() -> {
            log.info("executeDiver selectNowPc ERROR limitOrderMinPc null");
            return new CommCustomException("limitOrderMinPc null");
        });

        if(DiverOption.ON.value.equals(diverOption)) {
            if (limitMt >= diverMt) {

                //다이버 발동 상태 변경
                try {
                    log.debug("executeDiver start");
                    diverStatusCode = DiverStatusCode.DOWN.value;

                    log.info("executeDiver nowPc : " + nowPc);
                    log.info("executeDiver limitOrderMinPc : " + limitOrderMinPc);

                    //다이버 하강 (프리미엄 인하)
                    while(diverStatusCode == DiverStatusCode.DOWN.value){
                        //다이버 ON/OFF 체크
                        if(DiverOption.ON.value.equals(diverOption)){
                            //프리미엄 변경
                            diverRun(DiverStatusCode.DOWN.value);
                            //레디스 다이버 상태 전송
                            commDashboardWebsocketService.publishDiverRunning(true, true);

                            Thread.sleep(diverTime * 1000);
                            diveKrw = diveKrw.add(diverMdatVal);

                            //발동 범위 최저가 도달 or 지정가 주문 목록 중 최저가 도달
                            if (diverScopekrw <= diveKrw.intValue() ||(nowPc -  diveKrw.longValue()) <= limitOrderMinPc) {
                                log.info("executeDiver Dive Completed diveKrw : {}",diveKrw);
                                diverStatusCode = DiverStatusCode.UP.value;
                                break;
                            }
                        } else {
                            //강제종료
                            log.info("executeDiver Force quit");
                            diveKrw = BigDecimal.ZERO;
                            diverStatusCode = DiverStatusCode.WAIT.value;
                            commDashboardWebsocketService.publishDiverRunning(false, true);
                            break;
                        }
                    }
                    //다이버 상승 (프리미엄 인상)
                    while(diverStatusCode == DiverStatusCode.UP.value){
                        //다이버 ON/OFF 체크
                        if(DiverOption.ON.value.equals(diverOption)){
                            //프리미엄 변경
                            diverRun(DiverStatusCode.UP.value);
                            //레디스 다이버 상태 전송
                            commDashboardWebsocketService.publishDiverRunning(true, true);

                            surfaceKrw = surfaceKrw.add(diverMdatVal);

                            if (diverScopekrw <= surfaceKrw.intValue() || surfaceKrw.intValue() >= diveKrw.intValue()) {
                                log.info("executeDiver Surface Completed surfaceKrw : {}", surfaceKrw);
                                diverStatusCode = DiverStatusCode.UP.value;
                                commDashboardWebsocketService.publishDiverRunning(false, true);
                                break;
                            }
                            Thread.sleep(diverTime * 1000);
                        } else {
                            //강제종료
                            log.info("executeDiver Force quit");
                            surfaceKrw = BigDecimal.ZERO;
                            diverStatusCode = DiverStatusCode.WAIT.value;
                            commDashboardWebsocketService.publishDiverRunning(false, true);
                            break;
                        }
                    }
                } catch (Exception e) {
                    log.error("executeDiver ERROR -> message : " + e.getMessage());
                } finally {
                    diveKrw = BigDecimal.ZERO;
                    surfaceKrw = BigDecimal.ZERO;
                    diverStatusCode = DiverStatusCode.WAIT.value;
                    commDashboardWebsocketService.publishDiverRunning(false, true);
                    log.info("executeDiver end diverStatusCode : {}", diverStatusCode);
                }
            }
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public void diverRun(int statusCode) throws Exception {
        DynmDiverPremiumStdrVO livePremiumVO = dynmDiverMapper.getSelectedPremium();

        String nowPremiumId = livePremiumVO.getPremiumId(); //현재 프리미엄 ID
        BigDecimal changePremiumStdrAmount = BigDecimal.ZERO;

        BigDecimal premiumStdrAmount = BigDecimal.valueOf(livePremiumVO.getPremiumStdrAmount());

        //변경 프리미엄 (현재프리미엄 +- 분봉 조정값)
        if(DiverStatusCode.UP.value == statusCode  ) { //다이버 상승 (프리미엄 인상)
            changePremiumStdrAmount = premiumStdrAmount.add(diverMdatVal);
        } else if (DiverStatusCode.DOWN.value == statusCode) { //다이버 하강 (프리미엄 인하)
            changePremiumStdrAmount = premiumStdrAmount.subtract(diverMdatVal);
        }

        //현재프리미엄 - 변경프리미엄 차액
        BigDecimal dfnntPremiumStdrAmount = changePremiumStdrAmount.subtract(premiumStdrAmount);

        DynmDiverPremiumStdrVO newPremiumVo = new DynmDiverPremiumStdrVO();

        //현재 프리미엄 ID 세팅
        newPremiumVo.setNowPremiumId(nowPremiumId);
        newPremiumVo.setFrstRegisterId("DIVER_SYSTEM");

        newPremiumVo.setPremiumStdrAmount(changePremiumStdrAmount.longValue());

        //프리미엄 ID채번
        String metal = String.format("%02d", 7);
        String premiumId =  "PI" + metal + assignService.selectAssignValue("IT", "PREMIUM", "999999", "premiumNo", 6);
        newPremiumVo.setPremiumId(premiumId);
        newPremiumVo.setStdrEhgtPc(diverSpex);

        //현재 적용되고 있는 프리미엄 기준 테이블 복사
        dynmDiverMapper.insertSelectDiverPremiumStrd(newPremiumVo);
        //현재 적용되고 있는 프리미엄 기준으로 권역,브랜드그룹,브랜드 테이블 복사
        dynmDiverMapper.insertSelectDiverPremiumDstrct(newPremiumVo);
        dynmDiverMapper.insertSelectDiverPremiumBrandGroup(newPremiumVo);

        //프리미엄 번호 : PN + 메탈코드 + 오늘날짜 + 순번(6자리)
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Calendar c1 = Calendar.getInstance();
        String strToday = sdf.format(c1.getTime());

        //현재 적용되고 있는 프리미엄 브랜드 테이블 조회
        List<DynmDiverPremiumBrandVO> PremiumBrandList = dynmDiverMapper.getSelectedDiverPremiumBrand(newPremiumVo);

        for( DynmDiverPremiumBrandVO PremiumBrandVo : PremiumBrandList ) {
            String premiumNo = "PN" + metal + strToday + assignService.selectAssignValue("IT", "PREMIUMNO", "999999", "premiumNo", 6);
            newPremiumVo.setPremiumNo(premiumNo);
            newPremiumVo.setNowPremiumNo(PremiumBrandVo.getPremiumNo());
            newPremiumVo.setDfnntPremiumStdrAmount(PremiumBrandVo.getSlePremiumAmount().add(dfnntPremiumStdrAmount));

            dynmDiverMapper.insertSelectDiverPremiumBrand(newPremiumVo);
        }

        //현재 적용되고 있는 프리미엄 종료일자 수정
        dynmDiverMapper.updateEndDtDiverPremiumStrd(newPremiumVo);
        //레디스 호출
        redisPubSubService.publishMessage(CommDynmDiverConstant.SUBSCRIBER_URL_PREMIUM, CommDynmDiverConstant.SUBSCRIBER_URL_PREMIUM, "U");
        List<LivePremiumVO> premiumInfoMap = pcInfoMapper.getPremiumInfoMap();
        redisUtil.setDataJson("premiumInfoList" , premiumInfoMap);

        log.info("executeDiver changePremiumStdrAmount : {}, ",changePremiumStdrAmount);
    }
}
