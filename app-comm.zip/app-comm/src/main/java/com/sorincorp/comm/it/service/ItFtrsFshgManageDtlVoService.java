package com.sorincorp.comm.it.service;

import com.sorincorp.comm.it.model.ItFtrsFshgManageDtlVo;

public interface ItFtrsFshgManageDtlVoService {

	ItFtrsFshgManageDtlVo getItFtrsFshgManageDtlVo(String metalCodeByProperties);
}
