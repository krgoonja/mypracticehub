package com.sorincorp.comm.order.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.order.model.CommLimitGroupModel;
import com.sorincorp.comm.order.model.CommLimitOrderSttusVO;
import com.sorincorp.comm.order.model.CommOrLimitOrderBasVO;
import com.sorincorp.comm.order.model.CommPrvsnlDcsnInfoVO;
import com.sorincorp.comm.order.model.CommPrvsnlOrderVO;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.comm.order.model.OrSetleBasVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;

/**
 * CommPrvsnlOrderMapper.java
 * 가단가 주문 공통 Mapper 인터페이스
 *
 * @version
 * @since 2024. 9. 9.
 * @author srec0066
 */
public interface CommPrvsnlOrderMapper {

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 번호로 해당 가단가 주문 내역 가져오기 [단일]
	 * </pre>
	 * @date 2024. 9. 10.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 10.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public CommOrLimitOrderBasVO selectCommOrPrvsnlOrderBas(String limitOrderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 번호들로 해당 가단가 주문 내역 리스트 가져오기 [복수]
	 * </pre>
	 * @date 2024. 9. 10.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 10.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public List<CommOrLimitOrderBasVO> selectCommOrPrvsnlOrderBasList(List<String> limitOrderNoList) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 주문 번호에 대한 공통 가단가 확정 여부 정보 가져오기
	 * </pre>
	 * @date 2024. 9. 12.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 9. 12.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	public CommPrvsnlDcsnInfoVO getPrvsnlDcsnAtInfo(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 가단가 지정가 주문 상태 코드 업데이트
	 * </pre>
	 * @date 2024. 9. 27.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 27.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public int updateLmeLimitOrderSttusCode(CommLimitOrderSttusVO commLimitOrderSttusVO) throws Exception;  // LME
	public int updateEhgtLimitOrderSttusCode(CommLimitOrderSttusVO commLimitOrderSttusVO) throws Exception; // FX
	public int updateKrwLimitOrderSttusCode(CommLimitOrderSttusVO commLimitOrderSttusVO) throws Exception;  // KRW

	/**
	 * <pre>
	 * 처리내용: 가단가 지정가 주문 큐 메시지 정보 업데이트
	 * </pre>
	 * @date 2024. 9. 27.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 27.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public int updateOrLimitOrderLmeBasQueueInfo(CommLimitGroupModel commLimitGroupModel) throws Exception;  // LME
	public int updateOrLimitOrderEhgtBasQueueInfo(CommLimitGroupModel commLimitGroupModel) throws Exception; // FX
	public int updateOrLimitOrderKrwBasQueueInfo(CommLimitGroupModel commLimitGroupModel) throws Exception;  // KRW
	public int updateOrOrderBasQueueInfo(Map<String, Object> params) throws Exception; // 주문_주문 기본

	/**
	 * <pre>
	 * 처리내용: 가단가 주문의 bl 목록 조회
	 * </pre>
	 * @date 2024. 9. 20.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 20.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param orderNo
	 * @return List<ItemPriceMatchingBlInfoVO>
	 * @throws Exception
	 */
	public List<ItemPriceMatchingBlInfoVO> selectPrvsnlOrderBlList(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 가단가 주문의 확정 및 정산 프로세스 실행을 위한 데이터 조회
	 * </pre>
	 * @date 2024. 9. 27.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 27.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public CommPrvsnlOrderVO selectDcsnExcclcInfo(String orderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 해당 주문에서 사용된 쿠폰 리스트 조회
	 * </pre>
	 * @date 2024. 9. 30.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 30.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public List<CouponVO> selectCouponList(String orderNo);

	/**
	 * <pre>
	 * 처리내용: 주문_주문 기본_가격 및 정산관련 정보 업데이트
	 * </pre>
	 * @date 2024. 9. 27.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 27.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public int updateOrOrderBasPriceInfo(Map<String, Object> params) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_결제 기본 등록
	 * </pre>
	 * @date 2024. 9. 27.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 27.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public int insertEwalletSetle(OrSetleBasVO orSetleBasVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 이월렛 호출 API 응답코드 확인
	 * </pre>
	 * @date 2024. 9. 27.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 27.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public String selectEwalletRspnCode(String delngSeqNo);

	/**
	 * <pre>
	 * 처리내용: 주문_거래 정보 상세 등록
	 * </pre>
	 * @date 2024. 10. 17.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 17.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public int insertOrDelngInfoDtl(CommPrvsnlOrderVO order) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_가격 변동금 기본 tbl의 입금 요망/출금 대상 데이터 삭제처리
	 * </pre>
	 * @date 2024. 10. 17.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 17.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public int deleteOrPcChangegldBasRequestInfo(CommPrvsnlOrderVO order) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 가단가 지정가 체결실패, 주문취소 SMS 발송대상 데이터 조회
	 * </pre>
	 * @date 2024. 10. 31.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 31.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public Map<String, String> selectPrvsnlLimitOrderCancelSmsInfo(Map<String, String> parameters);

	/**
	 * <pre>
	 * 처리내용: 가장 최근 가격정보 조회 (프리미엄 제외 endPc)
	 * </pre>
	 * @date 2024. 11. 4.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 11. 4.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public PrSelVO getPreRealEndPc(PrSelVO prSelVO);

	/**
	 * <pre>
	 * 처리내용: 가격 변동금 기본 조회
	 * </pre>
	 * @date 2024. 11. 7.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 11. 7.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	public CommPrvsnlOrderVO selectOrPcChangegldBas(CommPrvsnlOrderVO params) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 입금에 따른 가격 변동금 정보 수정
	 * </pre>
	 * @date 2024. 11. 11.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 11.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commPrvsnlOrderVO
	 * @throws Exception
	 */
	public void updateOrPcOrPcChangegldBasByRcpmny(CommPrvsnlOrderVO commPrvsnlOrderVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 출금에 따른 가격 변동금 정보 수정
	 * </pre>
	 * @date 2024. 11. 11.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 11. 11.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commPrvsnlOrderVO
	 * @throws Exception
	 */
	public void updateOrPcOrPcChangegldBasByDefray(CommPrvsnlOrderVO commPrvsnlOrderVO) throws Exception;
}
