package com.sorincorp.comm.it.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.it.mapper.ItMapper;
import com.sorincorp.comm.it.model.ItBsnManageBasVo;
import com.sorincorp.comm.it.model.ItFtrsFshgManageDtlVo;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ItServiceImpl implements ItService {

	@Autowired
	private ItMapper itMapper;

	private ItBsnManageBasVoService itBsnManageBasVoService;

	private final ItFtrsFshgManageDtlVoService itFtrsFshgManageDtlVoService;

	@Autowired
	public ItServiceImpl(ItFtrsFshgManageDtlVoService itFtrsFshgManageDtlVoService) {
		this.itFtrsFshgManageDtlVoService = itFtrsFshgManageDtlVoService;
	}

	@Override
	public void selectTopItBsnManageBas() throws Exception {
		ItBsnManageBasVo vo = itMapper.selectTopItBsnManageBas();
		BeanUtils.copyProperties(vo, itBsnManageBasVoService.getItBsnManageBasVo());
	}

	@Override
	public void selectTopItFtrsFshgManageDtl() throws Exception {
		List<ItFtrsFshgManageDtlVo> vo = itMapper.selectTopItFtrsFshgManageDtl();
		for(ItFtrsFshgManageDtlVo data : vo) {
			BeanUtils.copyProperties(data, itFtrsFshgManageDtlVoService.getItFtrsFshgManageDtlVo(data.getMetalCode()));
		}

	}
}