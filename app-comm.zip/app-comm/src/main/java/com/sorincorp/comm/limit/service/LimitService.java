package com.sorincorp.comm.limit.service;

import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import com.sorincorp.comm.order.model.CommLimitOrderQueueMsgVO;
import com.sorincorp.comm.order.model.CommLimitOrderRedisMsgVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderQueueMsgVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderRedisMsgVO;

public interface LimitService {
	void loadTest(List<CommLimitOrderRedisMsgVO> commLimitOrderRedisMsgVO) throws Exception;
	
	void settingLimitQueueData(TreeSet<CommLimitOrderRedisMsgVO> commLimitOrderRedisMsgTreeSet, CommLimitOrderQueueMsgVO queueVo);
	
	void sendLimitQueueData(CommLimitOrderQueueMsgVO commLimitOrderQueueMsgVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 초기 지정가 데이터를 불러온다.
	 * </pre>
	 * @date 2023. 5. 18.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 18.			srec0064			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	Map<String, TreeSet<CommLimitOrderRedisMsgVO>> loadInitialLimitData() throws Exception;
	
	String generateKey(CommLimitOrderRedisMsgVO redisVo);

	/**
	 * <pre>
	 * 처리내용: 초기 가단가 지정가 데이터를 불러온다.
	 * </pre>
	 * @date 2024. 8. 28.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 8. 28.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @throws Exception
	 */
	Map<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> loadInitialPrvsnlLimitData() throws Exception;   // LME, KRW
	Map<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> loadInitialPrvsnlLimitFxData() throws Exception; // FX

	/**
	 * <pre>
	 * 처리내용: 종목별로 가단가용 큐에 넘겨줄 최종 데이터를 저장한다
	 * </pre>
	 * @date 2024. 9. 26.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 26.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	void settingPrvsnlLimitQueueData(TreeSet<CommPrvsnlLimitOrderRedisMsgVO> commPrvsnlLimitOrderRedisMsgTreeSet, CommPrvsnlLimitOrderQueueMsgVO queueVo);

	/**
	 * <pre>
	 * 처리내용: 가단가용 큐에 데이터 전송
	 * </pre>
	 * @date 2024. 9. 26.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 26.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	void sendPrvsnlLimitQueueData(CommPrvsnlLimitOrderQueueMsgVO commPrvsnlLimitOrderQueueMsgVO) throws Exception;
}
