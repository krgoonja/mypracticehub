package com.sorincorp.comm.credt.service;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.credt.mapper.CommMrtggMapper;
import com.sorincorp.comm.credt.model.CredtCdtlnInfoVO;

import lombok.extern.slf4j.Slf4j;

/**
 * CommMrtggServiceImpl.java
 * B2B 담보 보증 Service 구현체 클래스
 * @version
 * @since 2022. 8. 8.
 * @author srec0049
 */
@Slf4j
@Service
public class CommMrtggServiceImpl implements CommMrtggService {
	/**
	 * B2B 담보 보증 Mapper
	 */
	@Autowired
	private CommMrtggMapper commMrtggMapper;
	
	/**
	 * 여신 정보(금리 정보, 패널티 정보, 여신 증권 발급 수수료 정보) 가져오기
	 * : 여신 금리 정보(CD금리, 케이지트레이딩 가산금리, 연간뱅킹데이, CD 금리 사용 여부, 담보보증 무이자 일수)
	 * : CD금리는 CD 금리 사용 여부에 따라 미사용(N)일 경우 0으로 반환한다
	 * : 여신 패널티 정보(여신관리 패널티 연체 건수, 여신관리 패널티 사고 건수)
	 * : 여신 증권 발급 수수료 정보(전자상거래보증 증권발급 수수료 보상 비율, 전자상거래보증 증권발급 수수료 보상 건당 인정 비율)
	 * CD금리, 케이지트레이딩 가산금리, 연간뱅킹데이는 값이 0이 아닌 최근 적용일자의 데이터로 가져온다, 그래도 값이 없으면 0
	 * 여신관리 패널티 연체 건수, 여신관리 패널티 사고 건수, 전자상거래보증 증권발급 수수료 보상 비율, 전자상거래보증 증권발급 수수료 보상 건당 인정 비율는 값이 없으면 0
	 * CD금리, 케이지트레이딩 가산금리는 0값 허용, 연간뱅킹데이는 0인 경우를 체크해야한다.
	 */
	public CredtCdtlnInfoVO getCredtCdtlnInfo() throws Exception {
		// 여신 패널티 정보(여신관리 패널티 연체 건수, 여신관리 패널티 사고 건수) 가져오기
		CredtCdtlnInfoVO cdtlnPntInfo = Optional.ofNullable(commMrtggMapper.getCdtlnPntInfo()).orElse(new CredtCdtlnInfoVO());
		
		// 여신 증권 발급 수수료 정보(전자상거래보증 증권발급 수수료 보상 비율, 전자상거래보증 증권발급 수수료 보상 건당 인정 비율) 가져오기
		CredtCdtlnInfoVO cdtlnScritsIssuFee = Optional.ofNullable(commMrtggMapper.getCdtlnScritsIssuFee()).orElse(new CredtCdtlnInfoVO());
		
		// 여신 금리 정보(CD금리, 케이지트레이딩 가산금리, 연간뱅킹데이, CD 금리 사용 여부, 담보보증 무이자 일수) 가져오기
		// CD금리는 CD 금리 사용 여부에 따라 미사용(N)일 경우 0으로 반환한다
		CredtCdtlnInfoVO credtCdtlnInfo = Optional.ofNullable(commMrtggMapper.getCdtlnInrstInfo()).orElse(new CredtCdtlnInfoVO());
		
		credtCdtlnInfo.setCdtlnManagePntArrrgCo(Optional.ofNullable(cdtlnPntInfo.getCdtlnManagePntArrrgCo()).orElse(0)); // 여신관리 패널티 연체 건수, 값이 없으면 0으로 리턴 
		credtCdtlnInfo.setCdtlnManagePntAcdntCo(Optional.ofNullable(cdtlnPntInfo.getCdtlnManagePntAcdntCo()).orElse(0)); // 여신관리 패널티 사고 건수, 값이 없으면 0으로 리턴
		credtCdtlnInfo.setCdInrst(Optional.ofNullable(credtCdtlnInfo.getIntRateSell()).orElse(BigDecimal.ZERO)); // CD금리, 값이 없으면 0으로 리턴
		credtCdtlnInfo.setCdInrstUseAt(credtCdtlnInfo.getCdInrstUseAt()); // CD 금리 사용 여부
		credtCdtlnInfo.setMrtggGrntyNintrDaycnt(credtCdtlnInfo.getMrtggGrntyNintrDaycnt()); // 담보보증 무이자 일수
		credtCdtlnInfo.setMrtggGrntySorinsuprrAddiInrst(Optional.ofNullable(credtCdtlnInfo.getMrtggGrntySorinsuprrAddiInrst()).orElse(BigDecimal.ZERO)); // 케이지트레이딩 가산금리, 값이 없으면 0으로 리턴
		credtCdtlnInfo.setMrtggGrntyFyerBankingDaycnt(Optional.ofNullable(credtCdtlnInfo.getMrtggGrntyFyerBankingDaycnt()).orElse(0)); // 연간뱅킹데이, 값이 없으면 0으로 리턴
		credtCdtlnInfo.setMrtgggrntyScritsissuFeeCmpnstnRate(Optional.ofNullable(cdtlnScritsIssuFee.getMrtgggrntyScritsissuFeeCmpnstnRate()).orElse(BigDecimal.ZERO)); // 전자상거래보증 증권발급 수수료 보상 비율, 값이 없으면 0으로 리턴
		credtCdtlnInfo.setMrtgggrntyScritsissuFeeCmpnstnCsbyRate(Optional.ofNullable(cdtlnScritsIssuFee.getMrtgggrntyScritsissuFeeCmpnstnCsbyRate()).orElse(BigDecimal.ZERO)); // 전자상거래보증 증권발급 수수료 보상 건당 인정 비율, 값이 없으면 0으로 리턴
		
		log.warn("[공통][CommMrtggServiceImpl][getCdtlnInrstInfo] credtCdtlnInfo : " + String.valueOf(credtCdtlnInfo));
		
		return credtCdtlnInfo;
	}
}
