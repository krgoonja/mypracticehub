package com.sorincorp.comm.dynmDiver.comm;
/*
*
* 다이나믹 다이버 CommDynmDiverConstant
*
* */
public class CommDynmDiverConstant {
    /*
     * 레디스 프리미엄 수정 url
     */
    public static final  String SUBSCRIBER_URL_PREMIUM = "/premium";
}

