package com.sorincorp.comm.order.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;

import lombok.Data;

/**
 * CommPrvsnlLimitOrderRedisMsgVO.java
 * 가단가 지정가 주문 Redis 메시지 공통 VO 객체
 * @version
 * @since 2024. 8. 27.
 * @author srec0066
 */
@Data
public class CommPrvsnlLimitOrderRedisMsgVO implements Comparable<CommPrvsnlLimitOrderRedisMsgVO> {

	/**
	 * 지정가 주문 번호
	 */
	private String limitOrderNo;

	/**
	 * 인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제]
	 */
	private String intrfcSttusCode;

	/**
	 * 지정가 주문일시
	 */
	private String limitOrderDt;

	/**
	 * 지정가 입력 금액
	 */
	private long limitInputAmount;

	/**
	 * 프리미엄 가격
	 */
	private long premiumPc;

	/**
	 * 금속 코드
	 */
	private String metalCode;

	@Override
	public int compareTo(CommPrvsnlLimitOrderRedisMsgVO other) {
		/* 1.  지정가 입력 금액으로 정렬
		 * 2. 지정가 주문 일시로 정렬
		 * */
		Comparator<CommPrvsnlLimitOrderRedisMsgVO> comparator =
				Comparator.nullsFirst(Comparator.comparing(CommPrvsnlLimitOrderRedisMsgVO::getLimitInputAmount).reversed())
				.thenComparing(Comparator.nullsFirst(Comparator.comparing(
						(CommPrvsnlLimitOrderRedisMsgVO c) -> {
							String limitOrderDt = c.getLimitOrderDt();
							String formattedLimitOrderDt = limitOrderDt.replaceAll("(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2})(\\.\\d{1,3})?(S)?", "$1.000");
							return LocalDateTime.parse(formattedLimitOrderDt, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
						}).thenComparing(Comparator.comparing(CommPrvsnlLimitOrderRedisMsgVO::getLimitOrderDt))
					));

		int result = comparator.compare(this, other);
		return result;
	}
}
