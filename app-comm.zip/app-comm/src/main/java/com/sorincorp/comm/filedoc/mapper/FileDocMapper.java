package com.sorincorp.comm.filedoc.mapper;

import com.sorincorp.comm.filedoc.model.FileDocVO;

public interface FileDocMapper {
	/**
	 * <pre>
	 * 업로드한 문서의 정보를 DB에 저장한다.
	 * 저장된 문서의 ID 값을 VO로 리턴 받는다.
	 * </pre>
	 * @date 2021. 6. 14.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 14.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param vo - 저장할 문서 정보가 들어있는 CommonDocVO
	 * @throws Exception
	 */
	void insertCommonDoc(FileDocVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 문서 번호로 문서 정보를 조회한다.
	 * </pre>
	 * @date 2021. 6. 14.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 14.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param docNo - 조회할 문서 번호
	 * @return - 문서 정보
	 * @throws Exception
	 */
	FileDocVO selectDocInfo(int docNo) throws Exception;
	
	/**
	 * <pre>
	 * 입력한 번호의 문서를 삭제처리 한다.
	 * </pre>
	 * @date 2021. 6. 29.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 29.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void deleteCommonDoc(FileDocVO vo) throws Exception;
}
