package com.sorincorp.comm.deliveryCarMng.model;

import java.io.Serializable;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class DeliveryCarMngCommVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1650951373897601207L;

	/**
	 * InsertAndUpdate</br>
	 * validation groups를 지정하기 위한 빈 interface
	 */
	public interface InsertAndUpdate {
	};

	public interface Insert {
	};

	public interface Update {
	};

	public interface Delete {
	};

	public interface Insert2 {
	};

	public interface Update2 {
	};

	public interface Delete2 {
	};

	/**
	 * 업체번호
	 */
	@NotEmpty(groups = { Insert.class, Insert2.class }, message = "업체번호는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = { Update.class, Update2.class }, message = "업체번호는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = { Delete.class, Delete2.class }, message = "업체번호는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String entrpsNo;
	/**
	 * 차량정보 순번
	 */
	@Min(groups = Update.class, value = 1, message = "차량정보 순번은 필수 입력입니다.")
	@Min(groups = Delete.class, value = 1, message = "차량정보 순번은 필수 입력입니다.")
	private int vhcleinfoSn;
	/**
	 * 차량번호
	 */
	@NotEmpty(groups = Insert.class, message = "차량번호는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Update.class, message = "차량번호는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String vhcleNo;
	/**
	 * 기사정보 순번
	 */
	@Min(groups = Update2.class, value = 1, message = "기사정보 순번은 필수 입력입니다.")
	@Min(groups = Delete2.class, value = 1, message = "기사정보 순번은 필수 입력입니다.")
	private int drvarticlSn;
	/**
	 * 운전자 명
	 */
	@NotEmpty(groups = Insert2.class, message = "운전자명은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Update2.class, message = "운전자명은 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String drverNm;
	/**
	 * 운전자 전화 번호
	 */
	@NotEmpty(groups = Insert2.class, message = "운전자 전화번호는 필수 입력입니다.") // /message/validation.properties 에 등록된 메시지
	@NotEmpty(groups = Update2.class, message = "운전자 전화번호는 입력입니다.") // /message/validation.properties 에 등록된 메시지
	private String drverTlphonNo;
	/**
	 * 삭제여부
	 */
	private String deleteDt;
	/**
	 * 삭제일시
	 */
	private String deleteAt;
	/**
	 * 최초등록자ID
	 */
	private String frstRegisterId;
	/**
	 * 최초등록일시
	 */
	private String frstRegistDt;
	/**
	 * 최종변경자ID
	 */
	private String lastChangerId;
	/**
	 * 최종변경일시
	 */
	private String lastChangeDt;
}
