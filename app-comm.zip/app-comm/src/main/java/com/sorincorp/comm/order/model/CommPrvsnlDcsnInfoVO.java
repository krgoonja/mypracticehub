package com.sorincorp.comm.order.model;

import lombok.Data;

/**
 * CommPrvsnlDcsnInfoVO.java
 * 공통 가단가 확정 여부 정보 VO 객체
 * 
 * @version
 * @since 2024. 9. 12.
 * @author srec0049
 */
@Data
public class CommPrvsnlDcsnInfoVO {

	/**
	 * 주문 번호
	 */
	private String orderNo;
	
	/**
	 * 단가 확정 진행 여부
	 */
	private String untpcDcsnProcAt;
	
	/**
	 * 단가 확정 여부
	 */
	private String untpcDcsnAt;
	
	/**
	 * 단일(단가) 확정 코드
	 *  - LIVE_DCSN (라이브 단일(단가) 확정)
	 *  - LIMIT_DCSN (지정가 단일(단가) 확정)
	 *  - LIMIT_WAIT (지정가 단일(단가) 확정 대기)
	 */
	private String singlDcsnCd;
	
	/**
	 * LME 분리 확정 코드
	 *  - LIVE_DCSN (라이브 LME 분리 확정)
	 *  - LIMIT_DCSN (지정가 LME 분리 확정)
	 *  - LIMIT_WAIT (지정가 LME 분리 확정 대기)
	 */
	private String lmeDcsnCd;
	
	/**
	 * FX 분리 확정 코드
	 *  - LIVE_DCSN (라이브 FX 분리 확정)
	 *  - LIMIT_DCSN (지정가 FX 분리 확정)
	 *  - LIMIT_WAIT (지정가 FX 분리 확정 대기)
	 */
	private String fxDcsnCd;
}
