package com.sorincorp.comm.order.service;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.order.constant.CommLimitOrderConstant;
import com.sorincorp.comm.order.mapper.CommLimitOrderMapper;
import com.sorincorp.comm.order.model.CommOrLimitOrderBasVO;
import com.sorincorp.comm.util.CommonUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * CommFrontOrderWebsocketServiceImpl.java
 * FO 웹소켓 Service 구현체 클래스
 * 
 * @version
 * @since 2024. 11. 6.
 * @author srec0051
 */
@Slf4j
@Service
@PropertySource(value = "classpath:/config/order/order-${spring.profiles.active}.properties", ignoreResourceNotFound = true)
public class CommFrontOrderWebsocketServiceImpl implements CommFrontOrderWebsocketService {

	@Autowired
    private SimpMessagingTemplate simpMessagingTemplate;

	@Autowired
	private CommLimitOrderMapper commLimitOrderMapper;

	/** 외부 연계 api 호출 모듈 */
	@Autowired
	private HttpClientHelper httpClientHelper;

	@Value("${order.limit.websocket.pub.api.fo}")
	private String pubFoLimitOrderUrl;	// /fo/pub/limitOrder
	
	/**
	 * 단가확정하기 모달창 화면 갱신 웹소켓 호출 URL [FO 가단가 확정, BATCH 강제 단가 확정]
	 */
	@Value("${order.prvsnlDcsn.websocket.pub.api.fo}")
	private String pubFoPrvsnlDcsnUrl; // /fo/pub/prvsnlDcsn

	@Value("")
	private String pubFoOrderUrl;

	private static final String SUBSCRIBER_URL_LIVE="/subscriber/liveOrder";
	private static final String SUBSCRIBER_URL_LIMIT="/subscriber/limitOrder";
	private static final String SUBSCRIBER_URL_PRVSNL_DCSN = "/subscriber/prvsnlDcsn"; // 가단가 확정하기 정보 보내기/받기 URI

	/**
	 * 주문정보 파라미터 검증
	 */
	private void validParam(Map<String, Object> param) throws Exception {
        boolean limitOrderNo = CommonUtil.isEmpty(param.get(CommLimitOrderConstant.LIMIT_ORDER_NO));	/* 지정가 주문 번호 */
        boolean type = CommonUtil.isEmpty(param.get(CommLimitOrderConstant.TYPE));						/* 주문 타입 */

        boolean oriAmount = CommonUtil.isEmpty(param.get(CommLimitOrderConstant.ORI_AMOUNT));	/* 변경 전 지정가 입력 금액 */
        boolean oriWt = CommonUtil.isEmpty(param.get(CommLimitOrderConstant.ORI_WT));			/* 변경 전 지정가 주문 중량 */

        if (limitOrderNo || type) {
            throw new IllegalArgumentException("Check the parameters");
        }

        // 수정일 때 필요한 값 체크 (CommLimitOrderConstant parameter list 2 참조)
        if (StringUtils.equals("U", param.get(CommLimitOrderConstant.TYPE).toString())
        		&& oriAmount && oriWt) {
            throw new IllegalArgumentException("Check the parameters");
        }
    }

	/** 라이브 주문 구독 URL */
	private String getLiveDestinationUrl(Map<String, Object> param) throws Exception {
		// 브랜드까지 동일한 주문 건에 대해서만 Client에 전송
		StringBuilder destinationStr = new StringBuilder(SUBSCRIBER_URL_LIVE);
		destinationStr.append("/" + param.get(CommLimitOrderConstant.METAL_CODE).toString());
		destinationStr.append("/" + param.get(CommLimitOrderConstant.ITM_SN).toString());
		destinationStr.append("/" + param.get(CommLimitOrderConstant.DSTRCT_LCLSF_CODE).toString());
		destinationStr.append("/" + param.get(CommLimitOrderConstant.BRAND_GROUP_CODE).toString());
		destinationStr.append("/" + param.get(CommLimitOrderConstant.BRAND_CODE).toString());
		return destinationStr.toString();
	}

	/** 지정가 주문 구독 URL */
	private String getLimitDestinationUrl(Map<String, Object> param) throws Exception {
		// 브랜드까지 동일한 주문 건에 대해서만 Client에 전송
		StringBuilder destinationStr = new StringBuilder(SUBSCRIBER_URL_LIMIT);
		destinationStr.append("/" + param.get(CommLimitOrderConstant.METAL_CODE).toString());
		destinationStr.append("/" + param.get(CommLimitOrderConstant.ITM_SN).toString());
		destinationStr.append("/" + param.get(CommLimitOrderConstant.DSTRCT_LCLSF_CODE).toString());
		destinationStr.append("/" + param.get(CommLimitOrderConstant.BRAND_GROUP_CODE).toString());
		destinationStr.append("/" + param.get(CommLimitOrderConstant.BRAND_CODE).toString());
		return destinationStr.toString();
	}
	
	/** 가단가 확정하기 정보 구독 URL */
	private String getPrvsnlDcsnDestinationUrl(Map<String, Object> param) throws Exception {
		// 필요 시 더 추가될 수 있음(현재는 없음)
		StringBuilder destinationStr = new StringBuilder(SUBSCRIBER_URL_PRVSNL_DCSN);
		destinationStr.append("/" + param.get("orderNo").toString());
		return destinationStr.toString();
	}

	/**
	 * 라이브 주문정보 websocket publish TODO: 외부호출 라이브 사용시 보완 필요
	 * 23-05-23 변경사항 : 주석 처리
	 */
	@Override
    public void publishLiveOrder(Map<String, Object> param, boolean isApiCall) {
        log.info("[CommFrontOrderWebsocketServiceImpl][publishLiveOrder] IN");
        try {
        	String destinationStr = getLiveDestinationUrl(param);

        	// 해당 URL을 구독하는 Client에 주문 성공 정보 전송
        	if (isApiCall) {
        		httpClientHelper.getCallApi(pubFoOrderUrl+ "/"+ param.get(""));
        	} else {
        		simpMessagingTemplate.convertAndSend(destinationStr, param);
        	}

        } catch (Exception e) {
            log.error("[CommFrontOrderWebsocketServiceImpl][publishLiveOrder] ", e);
        }
    }

	/**
     * 지정가 주문 호가창 렌더링을 위해 주문 중량을 판매 단위 중량으로 나눠서 표현
     * 23-05-23 변경사항 : 주석 처리
     */
//	private void setLimitOrderSleUnitWt(Map<String, Object> param) throws Exception {
//		// 1. 판매 단위 중량 get
//		int sleUnitWt = commLimitOrderMapper.getSleUnitWt(param.get(CommLimitOrderConstant.ITM_SN).toString());
//
//		// 2. 중량 데이터 계산 및 세팅
//		if(sleUnitWt == 0) {
//			log.error("[CommFrontOrderWebsocketServiceImpl][publishLimitOrder] 판매 단위 중량 조회 결과 : 0");
//		} else {
//			param.put(CommLimitOrderConstant.LIMIT_ORDER_WT_CNT, Integer.parseInt(param.get(CommLimitOrderConstant.LIMIT_ORDER_WT).toString())/sleUnitWt);
//			// 수정이거나 취소인 경우 수정 전 지정가 주문 중량도 계산
//			if (StringUtils.equals("U", param.get(CommLimitOrderConstant.TYPE).toString())) {
////            			|| StringUtils.equals("C", param.get(CommLimitOrderConstant.TYPE).toString())) {
//				param.put(CommLimitOrderConstant.ORI_WT_CNT, Integer.parseInt(param.get(CommLimitOrderConstant.ORI_WT).toString())/sleUnitWt);
//			}
//		}
//	}

	/*
	 * 지정가 주문 호가창 렌더링을 위해 필요한 데이터를 세팅한다.
	 */
	private void setRenderingData(Map<String, Object> param) throws Exception {
		String limitOrderNo = param.get(CommLimitOrderConstant.LIMIT_ORDER_NO).toString();

		CommOrLimitOrderBasVO commOrLimitOrderBasVO = commLimitOrderMapper.selectLimitOrderForRendering(limitOrderNo);

		if(commOrLimitOrderBasVO == null) {
			log.error("[CommFrontOrderWebsocketServiceImpl][setRenderingData] 지정가 주문 조회 결과 없음");
			throw new Exception("지정가 주문 조회 결과 없음");
		}

		param.put(CommLimitOrderConstant.METAL_CODE, commOrLimitOrderBasVO.getMetalCode());
		param.put(CommLimitOrderConstant.ITM_SN, commOrLimitOrderBasVO.getItmSn());
		param.put(CommLimitOrderConstant.DSTRCT_LCLSF_CODE, commOrLimitOrderBasVO.getDstrctLclsfCode());
		param.put(CommLimitOrderConstant.BRAND_GROUP_CODE, commOrLimitOrderBasVO.getBrandGroupCode());
		param.put(CommLimitOrderConstant.BRAND_CODE, commOrLimitOrderBasVO.getBrandCode());

		param.put(CommLimitOrderConstant.LIMIT_INPUT_AMOUNT, commOrLimitOrderBasVO.getLimitInputAmount());
		param.put(CommLimitOrderConstant.ENTRPS_NO, commOrLimitOrderBasVO.getEntrpsNo());
		param.put(CommLimitOrderConstant.LIMIT_ORDER_WT, commOrLimitOrderBasVO.getLimitOrderWt());
		param.put(CommLimitOrderConstant.LIMIT_ORDER_WT_CNT, commOrLimitOrderBasVO.getLimitOrderWtCnt());

		if (StringUtils.equals("U", param.get(CommLimitOrderConstant.TYPE).toString())) {
			int sleUnitWt = commOrLimitOrderBasVO.getSleUnitWt();

			if(sleUnitWt == 0) {
				log.error("[CommFrontOrderWebsocketServiceImpl][setRenderingData] 판매 단위 중량 조회 결과 : 0");
				throw new Exception("판매 단위 중량 조회 결과 : 0");
			} else {
				param.put(CommLimitOrderConstant.ORI_WT_CNT, Integer.parseInt(param.get(CommLimitOrderConstant.ORI_WT).toString())/sleUnitWt);
			}
		}
	}

    /**
	 * 지정가 주문정보 websocket publish
	 */
    @Override
    public void publishLimitOrder(Map<String, Object> param, boolean isApiCall) {
        log.info("[CommFrontOrderWebsocketServiceImpl][publishLimitOrder] IN");
        try {
        	validParam(param);
        	setRenderingData(param);
            String destinationStr = getLimitDestinationUrl(param);

            // 해당 URL을 구독하는 Client에 주문 성공 정보 전송
            if (isApiCall) {
            	httpClientHelper.postCallApi( pubFoLimitOrderUrl, param);
            } else {
	            simpMessagingTemplate.convertAndSend(destinationStr, param);
            }

        } catch (Exception e) {
            log.error("[CommFrontOrderWebsocketServiceImpl][publishLimitOrder] ", e);
        }
        log.info("[CommFrontOrderWebsocketServiceImpl][publishLimitOrder] OUT");
    }
    
    /**
	 * 가단가 확정하기 정보 websocket publish, 가단가 자동 확정하기
	 */
    @Override
    public void publishPrvsnlDcsn(Map<String, Object> param) {
        log.info("[CommFrontOrderWebsocketServiceImpl][publishPrvsnlDcsn] IN");
        try {
            String destinationStr = getPrvsnlDcsnDestinationUrl(param);
            
            // 해당 URL을 구독하는 Client에 가단가 자동 확정하기 요청
            httpClientHelper.postCallApi(pubFoPrvsnlDcsnUrl, param);
        } catch (Exception e) {
            log.error("[CommFrontOrderWebsocketServiceImpl][publishPrvsnlDcsn] ", e);
        }
        log.info("[CommFrontOrderWebsocketServiceImpl][publishPrvsnlDcsn] OUT");
    }
    
    /**
     * 가단가 확정하기 정보 websocket publish, FO에 해당 확정 여부 전파 전달 (SimpMessagingTemplate) [확정, 체결, 수정, 취소] 모두 대상
     */
    @Override
    public void publishPrvsnlDcsnSimpMsg(Map<String, Object> param) {
        log.info("[CommFrontOrderWebsocketServiceImpl][publishPrvsnlDcsnSimpMsg] IN");
        try {
            String destinationStr = getPrvsnlDcsnDestinationUrl(param);
            
            // 해당 URL을 구독하는 Client에 가단가 확정하기 정보 전송
            simpMessagingTemplate.convertAndSend(destinationStr, param);
        } catch (Exception e) {
            log.error("[CommFrontOrderWebsocketServiceImpl][publishPrvsnlDcsnSimpMsg] ", e);
        }
        log.info("[CommFrontOrderWebsocketServiceImpl][publishPrvsnlDcsnSimpMsg] OUT");
    }

}
