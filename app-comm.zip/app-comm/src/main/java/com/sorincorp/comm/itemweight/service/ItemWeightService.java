package com.sorincorp.comm.itemweight.service;

import java.util.List;

import com.sorincorp.comm.itemweight.model.ItemWeightVO;

public interface ItemWeightService {

	public void initItemWeightCode() throws Exception;

	public List<ItemWeightVO> getItemWeightList(int itmSn) throws Exception;

	public String getItemWeightListStr(List<ItemWeightVO> itemWeightList, String val) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 아이템의 허용 중량 비율을 가져온다.
	 * </pre>
	 * @date 2022. 12. 9.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 9.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param itemPriceSelectVo
	 * @return
	 * @throws Exception
	 */
	public int getItmMinToleranceRate(int itmSn) throws Exception;
}
