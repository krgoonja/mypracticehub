package com.sorincorp.comm.itemcode.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.itemcode.model.ItemCodeVO;

public interface ItemCodeMapper {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 12.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param itemCodeVO
	 * @return
	 * @throws Exception
	 */
	List<ItemCodeVO> getItemCode(ItemCodeVO itemCodeVO) throws Exception;

	String getEntrpsSleMetalList(String entrpsNo) throws Exception;

	int getMetalCount(String metalCode) throws Exception;

	List<ItemCodeVO> getEntrpsMetalCodeList(Map<String, Object> param) throws Exception;

	List<ItemCodeVO> selectMbEntrpsMetalAcctoAuthorSetupBasList(String entrpsNo) throws Exception;


}
