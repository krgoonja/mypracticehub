package com.sorincorp.comm.expectbeginpr.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class PrLmePblntfPcBasVO {

    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 발생 일자
    */
    private String occrrncDe;
    /**
     * 종목코드(삼성선물)
     */
    private String gicName;
    /**
     * LME 공시 가격 순번
    */
    private String lmePblntfPcSn;
    /**
     * 전 영업 일자
    */
    private String bfeBsnDe;
    /**
     * 전일 종가
     */
    private java.math.BigDecimal endPc;
    /**
     * 3개월 종가
     */
    private java.math.BigDecimal threemonthEndPc;
    /**
     * 현물 공시 매도 가격
    */
    private java.math.BigDecimal acthngPblntfSalePc;
    /**
     * 선물 공시 매도 가격
    */
    private java.math.BigDecimal ftrsPblntfSalePc;

}
