package com.sorincorp.comm.message.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.message.model.MailVO;

public interface MailService {
	/**
	 * <pre>
	 * 처리내용: 이메일 단건 발송
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 06. 21.			srec0042			최초작성
	 * 2022. 12. 19.			srec0049			내부사용자 발송 추가 및 공통 리팩토링
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public int insertMailSend(MailVO param,Map<String,String> map) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 이메일(내용 반복) 단건 발송
	 * </pre>
	 * @date 2022. 6. 22.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 06. 22.			hyunjin05			최초작성
	 * 2022. 12. 19.			srec0049			내부사용자 발송 추가 및 공통 리팩토링
	 * 2022. 12. 26.		jdrttl				2개이상의 리스트를 사용할 경우를 위해 수정
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public int insertMailRepitSend(MailVO param, List<List<Map<String,String>>> ListListMap) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 사용자정의 리스트 만큼 이메일 일괄 발송
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 06. 21.			srec0042			최초작성
	 * 2022. 12. 19.			srec0049			내부사용자 발송 추가 및 공통 리팩토링
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public int insertMailListSend(List<MailVO> param, Map<String,String> map) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 이메일 리스트 발송 후 mailNo 리턴
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0068
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 07. 13.			srec0068			최초작성
	 * 2022. 12. 19.			srec0049			내부사용자 발송 추가 및 공통 리팩토링
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	public int insertMailSendByReturnMailNo(MailVO param, Map<String,String> map) throws Exception;
	
}
