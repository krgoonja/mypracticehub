package com.sorincorp.comm.bsnInfo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class RestdeVO implements Serializable{
    
	private static final long serialVersionUID = 2849004139164064398L;
	
	/**
	 * 날짜
	 */
	private String nowDe;
	/**
	 * 실시간 휴일 여부
	 */
	private String rltmRestdeAt;
	/**
	 * 실시간 휴일 시작시간
	 */
	private String rltmBeginTime;
	/**
	 * 실시간 휴일 종료시간
	 */
	private String rltmEndTime;
	/**
	 * 고정가 휴일 여부
	 */
	private String hghnetprcRestdenAt;
	/**
	 * 고정가 휴일 시작시간
	 */
	private String hghnetprcBeginTime;
	/**
	 * 고정가 휴일 종료 시간
	 */
	private String hghnetprcEndTime;
	/**
	 * 일 별 휴무 시간
	 */
	private String deAcctoRestdeAt;
	/**
	 * 시간 별 휴무 여부
	 */
	private String timeAcctoRestdeAt;
	/**
	 * 시간 별 휴무 시간 시작
	 */
	private String timeAcctoRestdeBeginTime;
	/**
	 * 시간 별 휴무 종료 시간
	 */
	private String timeAcctoRestdeEndTime;
	/**
	 * 휴무 적용 날짜
	 */
	private String hvofApplcDe;
	/**
	 * 휴무 시작 시간
	 */
	private String applcBeginTime;
	/**
	 * 휴무 종료 시간
	 */
	private String applcEndTime;
	
}
