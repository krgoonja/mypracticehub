package com.sorincorp.comm.it.mapper;

import java.util.List;

import com.sorincorp.comm.it.model.ItBsnManageBasVo;
import com.sorincorp.comm.it.model.ItFtrsFshgManageDtlVo;

public interface ItMapper {

	/**
	 * <pre>
	 * 처리내용: 상품 영업관리 기본 테이블(IT_BSN_MANAGE_BAS) 에서 제일 최신 정보를 가져온다.
	 * </pre>
	 * @date 2021. 11. 7.
	 * @author Kwon sun hyung
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 7.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	ItBsnManageBasVo selectTopItBsnManageBas() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 상품 선물 선물환 관리 상세 테이블(IT_FTRS_FSHG_MANAGE_DTL) 에서 메탈별 제일 최신 정보를 가져온다.
	 * </pre>
	 * @date 2022. 6. 30.
	 * @author srec0064
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 6. 8.		srec0064		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @throws Exception
	 */
	List<ItFtrsFshgManageDtlVo> selectTopItFtrsFshgManageDtl() throws Exception;

}
