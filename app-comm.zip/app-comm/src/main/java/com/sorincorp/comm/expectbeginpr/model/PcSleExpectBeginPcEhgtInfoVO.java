package com.sorincorp.comm.expectbeginpr.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class PcSleExpectBeginPcEhgtInfoVO {

    /**
     * 적용 일자
    */
    private String applcDe;
    /**
     * 기준 일자
    */
    private String stdrDe;
    /**
     * 환율 구분 코드
    */
    private String ehgtSeCode;
    /**
     * 환율 가격
    */
    private java.math.BigDecimal ehgtPc;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;

}