package com.sorincorp.comm.order.service;

/**
 * BO 지정가 주문정보 웹소켓 서비스
 * @author srec0051
 *
 */
public interface CommDashboardWebsocketService {

	/**
	 * <pre>
	 * 라이브 주문정보 websocket publish
	 * </pre>
	 * @date 2023. 5. 17.
	 * @author srec0051
	 * @param orderNo
	 * @param isApiCall 외부호출여부
	 */
	public void publishLiveOrder(String orderNo, boolean isApiCall);

	/**
	 * <pre>
	 * 기준 프리미엄 환산 금액 조회
	 * </pre>
	 * @date 2023. 5. 15.
	 * @author srec0051
	 * @param limitOrderNo
	 * @return
	 * @throws Exception
	 */
	public long selectStdrPremiumCnvrsnAmount(String limitOrderNo) throws Exception;

	/**
	 * <pre>
	 * 지정가 주문정보 websocket publish
	 * </pre>
	 * @date 2023. 5. 17.
	 * @author srec0051
	 * @param limitOrderNo
	 * @param isApiCall    외부호출여부
	 */
	public void publishLimitOrder(String limitOrderNo, boolean isApiCall);
	
	/**
	 * <pre>
	 * 다이버 작동 websocket publish
	 * </pre>
	 */
	public void publishDiverRunning(boolean runningAt, boolean isApiCall);

	/**
	 * <pre>
	 * 처리내용: 가격 변동금 입금관련 이벤트 websocket publish
	 * </pre>
	 * @date 2024. 10. 30.
	 * @author srec0066
	 * @param imitOrderNo
	 * @param isApiCall    외부호출여부
	 */
	public void publishRcpmnyEvent(String orderNo, boolean isApiCall);
}
