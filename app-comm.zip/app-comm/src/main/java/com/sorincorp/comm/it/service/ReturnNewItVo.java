package com.sorincorp.comm.it.service;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.sorincorp.comm.it.model.ItBsnManageBasVo;
import com.sorincorp.comm.it.model.ItFtrsFshgManageDtlVo;

@Component
public class ReturnNewItVo {

    public ItBsnManageBasVo process_CopyNewVo2 (ItBsnManageBasVo vo) throws Exception {
    	ItBsnManageBasVo returnVo = new ItBsnManageBasVo();
		BeanUtils.copyProperties(vo, returnVo);

		return returnVo;
    }

    public ItFtrsFshgManageDtlVo process_CopyNewVo (ItFtrsFshgManageDtlVo vo) throws Exception {
    	ItFtrsFshgManageDtlVo returnVo = new ItFtrsFshgManageDtlVo();
		BeanUtils.copyProperties(vo, returnVo);

		return returnVo;
    }

}
