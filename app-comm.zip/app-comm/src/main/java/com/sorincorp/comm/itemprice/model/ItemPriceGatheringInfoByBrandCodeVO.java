package com.sorincorp.comm.itemprice.model;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ItemPriceGatheringInfoByBrandCodeVO extends CommonVO {

	private static final long serialVersionUID = 6882956165304862133L;

	/** 창고 카운트*/
	private int warehouseCount;
	
	/** 주문 중량 합계*/
	private BigDecimal sumWeight;
	
	/** 각 주문중량 별 tolerance 의 범위 안에 있는 수량*/
	private Map<Integer, List<ItemPriceMatchingBlInfoVO>> matchedWeightMap;
	
	/** 각 주문중량 별 tolerance 의 범위 이상의 수량*/
	private Map<Integer, List<ItemPriceMatchingBlInfoVO>> overedWeightMap;

}