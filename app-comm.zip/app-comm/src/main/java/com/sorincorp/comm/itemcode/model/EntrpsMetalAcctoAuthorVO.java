package com.sorincorp.comm.itemcode.model;


import java.io.Serializable;

import lombok.Data;

@Data
public class EntrpsMetalAcctoAuthorVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4381812432082601332L;
	/**
	 * 업체 번호
	 */
	private String entrpsNo;
	/**
	 * 금속코드
	 */
	private String metalCode;
	/**
	 * 고정 가 여부
	 */
	private String fixingPcAt;
	/**
	 * 라이브 가 여부
	 */
	private String livePcAt;
	/**
	 * 지정 가 여부
	 */
	private String appnPcAt;

}
