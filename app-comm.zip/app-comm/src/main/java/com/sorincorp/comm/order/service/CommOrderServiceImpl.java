package com.sorincorp.comm.order.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.brandcode.model.BrandCodeVO;
import com.sorincorp.comm.brandcode.service.BrandCodeService;
import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingSelectVO;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingWeightCalculateValuesVO;
import com.sorincorp.comm.itemprice.service.ItemPriceMatchingService;
import com.sorincorp.comm.order.constant.CommOrderConstant;
import com.sorincorp.comm.order.mapper.CommOrderMapper;
import com.sorincorp.comm.order.model.CommFtrsFshgMngVO;
import com.sorincorp.comm.order.model.CommItmWtInfoVO;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.comm.order.model.OrOrderAvrgpcDtlVO;
import com.sorincorp.comm.order.model.OrderEntrpsSetleMnVO;
import com.sorincorp.comm.order.model.OrderModel;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * CommOrderServiceImpl.java
 * 주문 공통 Service 구현체 클래스
 *
 * @version
 * @since 2023. 5. 2.
 * @author srec0049
 */
@Slf4j
@Service
public class CommOrderServiceImpl implements CommOrderService {

    /**
     * BL Service
     */
    @Autowired
    private ItemPriceMatchingService itemPriceService;

    /**
     * 브랜드코드 Service
     */
    @Autowired
    private BrandCodeService brandCodeService;

    /**
     * 선물 선물환 관리 서비스
     */
    @Autowired
    private CommFtrsFshgMngService commFtrsFshgMngService;

    /**
     * 평균가 주문 서비스
     */
    @Autowired
    private CommAvrgpcOrderService commAvrgpcOrderService;

    /**
     * 주문 Mapper
     */
    @Autowired
    private CommOrderMapper commOrderMapper;

    /**
     * 판매 단위 중량(상품별) 및 1회 판매 가능 중량(상품별), 최대 구매 가능 중량(상품별) 가져오기
     */
    @Override
    public CommItmWtInfoVO selectItmWtInfo(int itmSn) throws Exception {
        return commOrderMapper.selectItmWtInfo(itmSn);
    }

    /**
     * 최적의 BL 리스트를 가져온다
     */
    @Override
    public List<ItemPriceMatchingBlInfoVO> getOptimalBlList(String entrpsNo, String metalCode, int itmSn, String dstrctLclsfCode, String brandGroupCode
            , String brandCode, String sleMthdCode, int orderWt, int sleUnitWt, int onceSlePossWt
            , String reMainBlNo, String leftOverWtRetrunBlEmptyYn, String sleMthdDetilCode, String cntrctOrderNo, String smlqyPurchsAt) throws Exception {

        if(StringUtils.equals(sleMthdCode, "04") || StringUtils.isNotEmpty(sleMthdDetilCode)) {
            // 평균가 or 평균가-라이브 주문인 경우, 할당된 재고 목록을 리턴
            List<ItemPriceMatchingBlInfoVO> blList = commOrderMapper.selectAvrgpcBlList(cntrctOrderNo);

            // 평균가-라이브 주문인 경우, 선물 체결 실패로 주문취소 실행시 사용할 데이터를 별도로 세팅한다.
            Map<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO> mapMatchingWeightValueMap = new HashMap<>();
            for (ItemPriceMatchingBlInfoVO bl : blList) {
                // 각 주문 중량 당 번들 및 중량을 계산한다.
                // onceSlePossWt - 평균가 주문은 최대 구매 가능 중량 체크를 제외하므로, 여기서 임의로 세팅
                mapMatchingWeightValueMap = itemPriceService.setMathcingValuesMap(bl, sleUnitWt, 100, sleUnitWt);

                bl.setWeightMappingCalculateValues(mapMatchingWeightValueMap);
            }

            return blList;
        } else {

            ItemPriceMatchingSelectVO itemVo = new ItemPriceMatchingSelectVO();
            itemVo.setDistrictLargeCode(dstrctLclsfCode);
            itemVo.setMetalCode(metalCode);
            itemVo.setItemSn(itmSn);
            itemVo.setBrandGroupCode(brandGroupCode);
            //itemVo.setBrandCode(orderModel.getBrandCode()); // 20211123 제거
            itemVo.setBrandCode(brandCode); // 브랜드 무관 코드일 경우 브랜드 무관 코드로 넣어 준다. 20211123
            itemVo.setOrderWeight(BigDecimal.valueOf(orderWt));
            itemVo.setSellMethodCode(sleMthdCode);

            /**
             * 재고없음처리 리턴여부 (잔여 재고량을 받으려면 Y, 받지 않으려면 N)
             *  1) N일 경우 list가 비었는지로 재고 체크
             *  2) Y일 경우 list 0번째의 leftOverWeight 값으로 재고 체크
             * **/
            itemVo.setLeftOverWtRetrunBlEmptyYn(leftOverWtRetrunBlEmptyYn);

            // 지정 BL 관련
            if(StringUtils.isNotEmpty(reMainBlNo)) {
                itemVo.setBlNo(reMainBlNo);
            }

            // 소량구매일 경우
            if(StringUtils.isNotEmpty(smlqyPurchsAt)) {
            	itemVo.setSmlqyPurchsAt(smlqyPurchsAt);
            }

            log.warn(">> [getOptimalBlList] entrpsNo : " + entrpsNo);

            //브랜드 무관일 경우
            if(brandCode.equals("0000000000")) {
                List<String> brandCodeList = new ArrayList<>();
                List<BrandCodeVO> brandCodeVoList = brandCodeService.getBrandCodeList(brandGroupCode, entrpsNo, false);

                for(BrandCodeVO brandCodeVo : brandCodeVoList) {
                    brandCodeList.add(brandCodeVo.getSubCode());
                }

                itemVo.setBrandCodeList(brandCodeList);
            }

            log.warn(">> [getOptimalBlList] ItemPriceMatchingSelectVO : " + String.valueOf(itemVo));

            // 잔여 재고량을 받을 경우
            if(StringUtils.equals("Y", leftOverWtRetrunBlEmptyYn)) {
                return itemPriceService.itemBLWithMatchingListLimits(itemVo, sleUnitWt, onceSlePossWt, 4, sleUnitWt); // 다중bl처리 문제로 임시로 지정가용 메소드 따로 사용, 2023-06-28
            } else {
                return itemPriceService.itemBLWithMatchingList(itemVo, sleUnitWt, onceSlePossWt, 4, sleUnitWt);
            }
        }
    }

    /**
     * 주문 중량에 대한 재고 차감
     */
    @Override
    public void updateMinusInvntryBlInfoBas(OrderModel orderModel) throws Exception {
        // 주문 중량에 대한 재고 차감
        commOrderMapper.updateMinusInvntryBlInfoBas(orderModel);
    }

    /**
     *  평균가 주문의 단가 계산
     */
    public long getAvrgpcGoodsUntpc(OrderModel orderModel) throws CommCustomException, Exception {
        long calcAvrgpcGoodsUntpc = 0;                                                               // 평균 단가

        String crncySeCode = orderModel.getCntrctOrderBasInfo().getCrncySeCode();                    // 통화 구분 코드
        String untpcMntnfrmlaCode = orderModel.getCntrctOrderBasInfo().getUntpcMntnfrmlaCode();      // 단가 산식 코드
        long avrgpcPremiumPc = orderModel.getCntrctOrderBasInfo().getPremiumPc();                    // 평균가 프리미엄
        double avrgpcDelngAmountRate = 1.0;                                                          // 평균가 거래 금액 비율

        log.info(">> getAvrgpcGoodsUntpc:: CntrctOrderBasInfo = " + orderModel.getCntrctOrderBasInfo().toString());

        // 조정계수 데이터 조회
        CommFtrsFshgMngVO ftrsFshgMngVO = Optional.ofNullable(commFtrsFshgMngService.commFtrsFshgManageDtlListByToday("B").stream()
                                                  .filter(data -> ( StringUtils.equals(data.getMetalCode(), orderModel.getMetalCode()))).collect(Collectors.toList()).get(0))
                                                  .orElseThrow(() -> {return new CommCustomException("LME, 환율 조정계수 정보 미존재");});

        BigDecimal lme = new BigDecimal(0);
        BigDecimal ehgt = new BigDecimal(0);

        if(StringUtils.equals("04", orderModel.getSleMthdCode())) {
            // 평균 LME, 환율
            // 이전 영업일의 평균 데이터 조회 (5일 or 한달 - 평균가 확정 단가 여부에 따라 달라짐)
            OrOrderAvrgpcDtlVO prevAvrgpcInfo = Optional.ofNullable(commAvrgpcOrderService.selectPrevBsnDeAvrgpc(orderModel.getCntrctOrderBasInfo()))
                                                        .orElseThrow(() -> {return new CommCustomException("이전 영업일 평균 가격 데이터 미존재");});

            if(prevAvrgpcInfo.getLmeAvrg().compareTo(BigDecimal.ZERO) == 0 || prevAvrgpcInfo.getEhgtAvrg().compareTo(BigDecimal.ZERO) == 0) {
            	throw new CommCustomException("평균가 주문이 불가능합니다,\n관리자에게 문의 바랍니다.");
            }
            orderModel.setAvrgpcDtlInfo(prevAvrgpcInfo);

            lme = prevAvrgpcInfo.getLmeAvrg();
            ehgt = prevAvrgpcInfo.getEhgtAvrg();

            // 확정가일 경우, 평균가 거래 금액 비율 사용안함
        	if(!StringUtils.equals(orderModel.getAvrgpcDcsnUntpcAt(), "Y")) {
        		 // 평균가 거래 금액 비율 (평균가일 경우만 사용): 업체 결제 수단 정보가 null 일 시, 평균가 거래 금액 비율 세팅
	            if(orderModel.getEntrpsSetleMnInfo() == null || orderModel.getEntrpsSetleMnInfo().getAvrgpcDelngAmountRate() == 0) {
	                String avrgpcDelngAmountRateCodeNm = Optional.ofNullable(commOrderMapper.getAvrgpcDelngAmountRateCodeNm(orderModel.getEntrpsNo()))
	                                                             .orElseThrow(() -> {return new CommCustomException("계약 관리 설정 값 미존재");});
	                avrgpcDelngAmountRate = Integer.parseInt(avrgpcDelngAmountRateCodeNm.replace("%", "")) / 100.0;
	            } else {
	                avrgpcDelngAmountRate= orderModel.getEntrpsSetleMnInfo().getAvrgpcDelngAmountRate();
	            }
        	}
        } else {
            // 실시간 LME, 환율
            lme = orderModel.getPrSelVO().getLmePc().add(ftrsFshgMngVO.getLmeMdatCffcntAmount()); // 평균가-라이브 주문일 경우, LME 조정계수 포함하여 계산
            ehgt = orderModel.getPrSelVO().getEhgtPc();

            orderModel.getPrSelVO().setLmeMdatCffcnt(ftrsFshgMngVO.getLmeMdatCffcntAmount()); // 사용한 LME 조정 계수 세팅
        }
        log.info(">> getAvrgpcGoodsUntpc:: lme = " + lme + ", ehgt = " + ehgt + ", premiumPc = " + avrgpcPremiumPc + ", avrgpcDelngAmountRate = " + avrgpcDelngAmountRate);

        // 통화 구분 코드에 따라 계산, 100원 단위 절삭
        if(StringUtils.equals(crncySeCode, CommOrderConstant.KRW)) {
            /** [KRW] **/
        	if(StringUtils.equals(untpcMntnfrmlaCode, "10")) {
        		// 10. (LME x 환율) + 프리미엄(KRW) x 구매비율%
        		calcAvrgpcGoodsUntpc = (long)(lme.multiply(ehgt).add(BigDecimal.valueOf(avrgpcPremiumPc))).multiply(BigDecimal.valueOf(avrgpcDelngAmountRate))
        				.divide(new BigDecimal(1000)).setScale(0, RoundingMode.DOWN).longValue() * 1000;
        	} else if (StringUtils.equals(untpcMntnfrmlaCode, "40")) {
        		// 40. (LME x (환율+환율조정)) + 프리미엄(KRW) x 구매비율%
        		calcAvrgpcGoodsUntpc = (long)(lme.multiply(ehgt.add(ftrsFshgMngVO.getEhgtMdatCffcntAmount())).add(BigDecimal.valueOf(avrgpcPremiumPc))).multiply(BigDecimal.valueOf(avrgpcDelngAmountRate))
        				.divide(new BigDecimal(1000)).setScale(0, RoundingMode.DOWN).longValue() * 1000;

        		orderModel.getPrSelVO().setFxMdatCffcnt(ftrsFshgMngVO.getEhgtMdatCffcntAmount()); // 사용한 환율 조정 계수 세팅
        	}
        } else if(StringUtils.equals(crncySeCode, CommOrderConstant.USD)) {
            /** [USD] **/
            if(StringUtils.equals(untpcMntnfrmlaCode, "20")) {
                // 20. (LME + 프리미엄[USD]) x 환율 x 구매비율%
                calcAvrgpcGoodsUntpc = (long)(lme.add(BigDecimal.valueOf(avrgpcPremiumPc))).multiply(ehgt).multiply(BigDecimal.valueOf(avrgpcDelngAmountRate))
                                      .divide(new BigDecimal(1000)).setScale(0, RoundingMode.DOWN).longValue() * 1000;

            } else if (StringUtils.equals(untpcMntnfrmlaCode, "30")) {
                // 30. (LME + 프리미엄[USD]) x (환율+환율조정) x 구매비율%
                calcAvrgpcGoodsUntpc = (long)(lme.add(BigDecimal.valueOf(avrgpcPremiumPc))).multiply(ehgt.add(ftrsFshgMngVO.getEhgtMdatCffcntAmount())).multiply(BigDecimal.valueOf(avrgpcDelngAmountRate))
                                      .divide(new BigDecimal(1000)).setScale(0, RoundingMode.DOWN).longValue() * 1000;

                orderModel.getPrSelVO().setFxMdatCffcnt(ftrsFshgMngVO.getEhgtMdatCffcntAmount()); // 사용한 환율 조정 계수 세팅
            }
        }

        orderModel.setAvrgpcGoodsUntpc(calcAvrgpcGoodsUntpc);
        return calcAvrgpcGoodsUntpc;
    }

    /**
     *  현재 단가와 주문 중량을 기준으로 가격 정보를 세팅한다.
     */
    public void setPriceInfo(OrderModel orderModel, long calcGoodsUntpc, int orderWt) throws CommCustomException, Exception {
        log.warn(">> calcGoodsUntpc : " + calcGoodsUntpc + ", orderWt : " + orderWt + ", orderModel : " + String.valueOf(orderModel));

        /** 상품 단가 **/
        long goodsUntpc = 0;

        // 23-05-18 변경사항 : 지정가 주문일 경우, LIVE와 동일한 로직을 수행하도록 조건 추가(판매방식 코드가 03일 경우)
        // 24-09-12 변경사항 : 로직 간소화 (고정가 주문(02)과 고정가 주문이 아닌 주문(01, 03, 04, 05)으로 분기 처리)
        if(!StringUtils.equals(orderModel.getSleMthdCode(), "02")) {
            /** LME 와 맞춤 (round 에서 floor 변경) */
            goodsUntpc = (long) (Math.floor(calcGoodsUntpc / 1000.0) * 1000);

        } else {
            // 고정가는 할증요율을 불러와서 계산
            BigDecimal totAmtTariff = Optional.ofNullable(commOrderMapper.selectTotAmtTariff(orderModel)).orElse(BigDecimal.ZERO);
            log.warn(">> totAmtTariff : " + totAmtTariff + ", totAmtTariff.intValue() : " + totAmtTariff.intValue());
            orderModel.setTotAmtTariff(totAmtTariff);
            // 고정가 할증요율은 1000단위 반올림 절삭을 하지 않는 것으로 변경, 20230126
            //goodsUntpc = Math.round( ( calcGoodsUntpc + ( calcGoodsUntpc * (totAmtTariff.doubleValue() / 100) ) ) / 1000.0 ) * 1000;
            long addAmtTariff = 0L;
            double tempAddAmtTariff = ( calcGoodsUntpc * (totAmtTariff.doubleValue() / 100) );
            log.warn(">> tempAddAmtTariff : " + tempAddAmtTariff);

            /** LME 와 맞춤 (round 에서 floor 변경) */
            if ((tempAddAmtTariff == Math.floor(tempAddAmtTariff)) && !Double.isInfinite(tempAddAmtTariff)) {
                addAmtTariff = Double.valueOf(tempAddAmtTariff).longValue();
            } else {
                addAmtTariff = Double.valueOf(Math.floor(tempAddAmtTariff)).longValue(); // 소수점 발생하면 버림, 정수로 와야함
            }

            goodsUntpc = calcGoodsUntpc + addAmtTariff;
        }

        log.warn(">> calc goodsUntpc : " + goodsUntpc);

        // 주문 모달창에 선택된 결제 수단 값이 (전자상거래보증 or 케이지크레딧)일 때
        if(StringUtils.equals(orderModel.getPaymentMn(), "mrtggGrnty")) {
            // 업체 결제 수단 정보가 null 일 시, 계산에 필요한 항목만 조회해서 세팅
            if(orderModel.getEntrpsSetleMnInfo() == null) {
                String entrpsNo = orderModel.getEntrpsNo();
                // 계산에 필요한 항목 : 담보보증 무이자 일수(mrtggGrntyNintrDaycnt), CD금리(cdInrst), 케이지트레이딩 가산금리(mrtggGrntySorinsuprrAddiInrst), 연간뱅킹데이(mrtggGrntyFyerBankingDaycnt)
                OrderEntrpsSetleMnVO entrpsSetleMnInfo = commOrderMapper.getRequiredEntrpsSetleMnInfo();
                entrpsSetleMnInfo.setCdInrst(Optional.ofNullable(entrpsSetleMnInfo.getCdInrst()).orElse(BigDecimal.ZERO)); // CD금리, 값이 없으면 0으로 리턴

                // 임시 하드코딩 (20230131, 특정 업체(C0277[삼보산업(주)])만 무이자 없음)
                // 20240124: C0254[린노알미늄(주)] => 15일(무이자)/30일/45일
                // 참조 : OrderServiceImpl.getEntrpsSetleMnInfo
                if(StringUtils.equals("C0277", entrpsNo)) {
                    entrpsSetleMnInfo.setMrtggGrntyNintrDaycnt(0); // 담보보증 무이자 일수 0
                } else if(StringUtils.equals("C0254", entrpsNo)) {
                	entrpsSetleMnInfo.setMrtggGrntyNintrDaycnt(15); // 담보보증 무이자 일수 15
                }

                orderModel.setEntrpsSetleMnInfo(entrpsSetleMnInfo);
            }

            // (전자상거래보증 or 케이지크레딧) 이자율 [((현재단가*주문중량)*(CD금리+케이지트레이딩 가산금리)*((전자상거래보증 or 케이지크레딧)허용상환기간-담보보증 무이자 일수))/연간뱅킹데이]

            int calcMrtggGrntyRepyPd = orderModel.getMrtggGrntyRepyPd() - orderModel.getEntrpsSetleMnInfo().getMrtggGrntyNintrDaycnt(); // 계산된 (전자상거래보증 or 케이지크레딧)허용상환기간[(전자상거래보증 or 케이지크레딧)허용상환기간-담보보증 무이자 일수]
            log.warn(">> 전자상거래보증허용상환기간["+orderModel.getMrtggGrntyRepyPd()+"]-담보보증 무이자 일수["+orderModel.getEntrpsSetleMnInfo().getMrtggGrntyNintrDaycnt()+"]="+calcMrtggGrntyRepyPd);

            // 계산된 (전자상거래보증 or 케이지크레딧)허용상환기간이 0이거나 0보다 작으면 이자는 0으로 계산된다.
            if(calcMrtggGrntyRepyPd <= 0) {
                orderModel.setIntrt(0d); // (전자상거래보증 or 케이지크레딧) 이자율 set
                orderModel.setUntpcIncrse(0L); // (전자상거래보증 or 케이지크레딧) 단가 인상 금액 set
            } else {
                double mrtggGrntyIntr = ( (goodsUntpc * orderWt) * (orderModel.getEntrpsSetleMnInfo().getCdInrst().add(orderModel.getEntrpsSetleMnInfo().getMrtggGrntySorinsuprrAddiInrst()).doubleValue()) * calcMrtggGrntyRepyPd ) / orderModel.getEntrpsSetleMnInfo().getMrtggGrntyFyerBankingDaycnt();
                log.warn(">> mrtggGrntyIntr : " + mrtggGrntyIntr);
                orderModel.setIntrt((mrtggGrntyIntr*100000)/100000); // (전자상거래보증 or 케이지크레딧) 이자율 set, 소수점 5자리 아래 버림

                Double tempUntpcIncrse = Math.floor((mrtggGrntyIntr / orderWt) * 0.001) * 1000; // 천원 아래 버림
                long untpcIncrse = tempUntpcIncrse.longValue(); // 단가 인상 금액
                log.warn(">> untpcIncrse : " + untpcIncrse);
                orderModel.setUntpcIncrse(untpcIncrse); // (전자상거래보증 or 케이지크레딧) 단가 인상 금액 set
            }

            goodsUntpc = goodsUntpc + orderModel.getUntpcIncrse(); // (전자상거래보증 or 케이지크레딧)일 경우 단가에 단가 인상 금액을 더해준다
        }

        /** 주문 가격 **/
        long orderPc = goodsUntpc * orderWt;

        /** 중량변동금 **/
        long wtChangegld = 0L;
        // 케이지몰일 때, 중량변동이 0이면 중량변동금 계산에서 제외한다
        if(StringUtils.equals(orderModel.getSleMthdCode(), "02") && orderModel.getWtChange() == 0) {
            wtChangegld = 0L;
        } else {
            wtChangegld = Double.valueOf(goodsUntpc * orderModel.getWtChange()).longValue();
        }
        log.warn(">> wtChangegld : " + wtChangegld);

        orderModel.setGoodsUntpc(goodsUntpc);
        orderModel.setOrderPc(orderPc);
        orderModel.setWtChangegld(wtChangegld);

        orderModel.setOrgGoodsUntpc(goodsUntpc);        // 원 상품단가 : 쿠폰 할인 전 단가
    }

    /**
     *  배송비 할인과 쿠폰을 반영한 주문 가격 정보들의 계산 및 세팅
     *  대상 가격 정보
     *  예상 배송비      expectDlvrf
     *  상품단가        goodsUntpc  (배송비 및 쿠폰 할인 적용)
     *  중량 변동금      wtChangePc
     *  주문 가격       orderPc
     *  공급가         splpc
     *  부가세         vat
     *  판매가         slepc
     */
    @Override
    public void setOrderPcWithDlvrfAndCoupon(OrderModel orderModel, int orderWt, boolean newGetBlListUseStatus)
            throws Exception, CommCustomException, NumberFormatException {
        CouponVO couponvo = new CouponVO();

        long splpc = 0;
        long vat = 0;
        long slepc = 0;
        long wtChangePc = 0;
        long orderPc = 0;

        long dsCntGoodsUntPc = 0;           //할인 후 단가
        long pdDscntAmount = 0;             //단가 할인금액
        long cpDscntAmount = 0;             //총액 할인금액
        long gradeDscAmount = 0;            //등급 할인금액
        long rmndrDscnt = orderModel.getRmndrDscnt();  //자투리 할인금액

        //쿠폰 사용 지정가 주문건 - EWALLET 비교시 차감된 금액으로 비교하기 위함
        long reSplpc = 0;
        long reVat = 0;
        long reSlepc = 0;
        long reWtChangePc = 0;
        long reOrderPc = 0;

        long reDsCntGoodsUntPc = 0;             //할인 후 단가
        long rePdDscntAmount = 0;               //단가 할인금액
        long reCpDscntAmount = 0;               //총액 할인금액
        long reGradeDscAmount = 0;              //등급 할인금액
        long reExpectDlvrf = 0;             	//배송비 할인금액
        long reRmndrDscnt = 0;					//자투리 할인금액

        // 등급 할인금액 조회 (케이지몰 제외)
        // 24-06-05 변경사항 : 평균가 주문인 경우, 주문 시점의 등급 할인 금액을 사용하도록 로직 분기 처리 추가
        // 소량구매일 경우, 자투리 할인만 적용하므로 등급할인은 제외
        if(!StringUtils.equals(orderModel.getSmlqyPurchsAt(), "Y")) {
	        if(StringUtils.equals(orderModel.getSleMthdCode(), "04")	// 해당 주문이 평균가 주문(04)이고,
	        		&& orderModel.getGradApplcAmount() != 0) {	 		// 미리 세팅된 등급 할인 금액이 존재한다면 (== 값이 0이 아니라면)
	        	gradeDscAmount = orderModel.getGradApplcAmount();		// orderModel 객체에 미리 세팅된 등급 할인 금액으로 세팅, 해당 값은 주문 시점에서 설정된 등급 할인 금액임
	        } else if(!StringUtils.equals(orderModel.getSleMthdCode(), "02")) {
	            gradeDscAmount = Optional.ofNullable(commOrderMapper.getGradeDscAmount(orderModel.getEntrpsNo(), orderModel.getMetalCode())).orElse(0L);
	        }
        }
        orderModel.setGradApplcAmount(gradeDscAmount);

        //배송 할인 프로모션
        Map<String, Object> expectDlvrfMap = getCheckDataDlvyTariff(orderModel, orderModel.getOrderWt(), newGetBlListUseStatus);
        long expectDlvrf = Long.parseLong(Optional.ofNullable(String.valueOf(expectDlvrfMap.get("expectDlvrf"))).orElse("0")); //배송비

        if (StringUtils.equals(orderModel.getSleMthdCode(), "03")) { // 지정가 주문
            //쿠폰 사용하지 않은 경우 or 쿠폰 사용했으나 touch 시점 아닌경우 쿠폰 계산 로직 수행 안함
            if (("N").equals(orderModel.getCouponApplcAt())) {
                //지정가 주문 - 쿠폰 사용 안함
                //orderModel.setExpectDlvrf(expectDlvrf);
                if (!StringUtils.equals("touch", orderModel.getLimitSection())) {
                    reGradeDscAmount = gradeDscAmount;
                    gradeDscAmount = 0;
                    reExpectDlvrf = expectDlvrf;
                } //할인 전 금액으로 지정가 체결 요청{};
                //splpc =  (orderModel.getGoodsUntpc() * orderWt ) + orderModel.getWtChangegld() + orderModel.getExpectDlvrf();

            } else if (("Y").equals(orderModel.getCouponApplcAt()) && !StringUtils.equals("touch", orderModel.getLimitSection())) {
                //지정가 주문 - 쿠폰 사용 함  : 실제 할인은 지정가 터치 후 실 주문 테이블 insert시 적용
                //orderModel.setExpectDlvrf(expectDlvrf);   //배송비 : 할인 이전 배송비로 적용
                this.couponSelectList(orderModel, orderWt);
                reGradeDscAmount = gradeDscAmount;
                gradeDscAmount = 0;     //할인 전 금액으로 지정가 체결 요청
                //splpc =  (orderModel.getGoodsUntpc() * orderWt ) + orderModel.getWtChangegld() + orderModel.getExpectDlvrf();

                //쿠폰 사용 지정가 주문건 - EWALLET 비교시 차감된 금액으로 비교하기 위함
                couponvo = this.couponUse(orderModel, orderWt, newGetBlListUseStatus);
                rePdDscntAmount = couponvo.getPdDscntAmount();
                reCpDscntAmount = couponvo.getCpDscntAmount();
                reExpectDlvrf = couponvo.getExpectDlvrf();

            } else {
                //지정가 주문 - 터치 후 쿠폰 할인 금액 적용
                couponvo = this.couponUse(orderModel, orderWt, newGetBlListUseStatus);
                pdDscntAmount = couponvo.getPdDscntAmount();
                cpDscntAmount = couponvo.getCpDscntAmount();
                expectDlvrf = couponvo.getExpectDlvrf();
                //splpc = couponUse(orderModel, orderWt, newGetBlListUseStatus);
            }

            // 소량구매는 자투리 할인만 있으므로, 쿠폰 로직과 별도로 세팅 : touch 시점 아닐때만 (예수금 계산을 위함)
            if(!StringUtils.equals("touch", orderModel.getLimitSection())) {
            	reRmndrDscnt = rmndrDscnt;
            	rmndrDscnt = 0;
            }
        } else if(StringUtils.equals(orderModel.getSleMthdCode(), "04")
        			&& ("Y").equals(orderModel.getCouponApplcAt())
        			&& orderModel.getCouponList() != null
        			&& !orderModel.getCouponList().isEmpty() ) {
        	// 24-01-26 변경사항 : 평균가 특수 case(단가 확정) 추가
        	// 1. 평균가 주문	(sleMthdCode : 04)
        	// 2. 쿠폰 사용		(couponApplcAt : Y)
        	// 3. 쿠폰 리스트(couponList) 존재(not null, not empty)
            couponvo = this.couponUse(orderModel, orderWt, newGetBlListUseStatus);
            pdDscntAmount = couponvo.getPdDscntAmount();
            cpDscntAmount = couponvo.getCpDscntAmount();
            expectDlvrf = couponvo.getExpectDlvrf();
        } else { //지정가, 평균가 특수 case 외 주문
            if (("N").equals(orderModel.getCouponApplcAt())) {
                //지정가 외 주문 - 쿠폰 사용 안함
                orderModel.setExpectDlvrf(expectDlvrf);
                //splpc =  (orderModel.getGoodsUntpc() * orderWt ) + orderModel.getWtChangegld() + orderModel.getExpectDlvrf();

            } else {
                this.couponSelectList(orderModel, orderWt);
                couponvo = this.couponUse(orderModel, orderWt, newGetBlListUseStatus);
                pdDscntAmount = couponvo.getPdDscntAmount();
                cpDscntAmount = couponvo.getCpDscntAmount();
                expectDlvrf = couponvo.getExpectDlvrf();
                //splpc = couponUse(orderModel, orderWt, newGetBlListUseStatus);
            }
        }

        dsCntGoodsUntPc = orderModel.getGoodsUntpc() - pdDscntAmount - gradeDscAmount - rmndrDscnt; // 상품단가 - 단가할인금액 - 등급할인금액 - 자투리 할인금액
        wtChangePc = Double.valueOf(dsCntGoodsUntPc * orderModel.getWtChange()).longValue();
        orderPc = dsCntGoodsUntPc * orderWt;

        if(StringUtils.equals("0304", orderModel.getSleMthdDetailCode())) {
        	// 계약구매-지정가일 경우, '계약 구매 최종 상품 단가' 기준으로 예수금 계산
        	reDsCntGoodsUntPc = orderModel.getCntrctPurchsLastGoodsUntpc() - rePdDscntAmount - reGradeDscAmount - reRmndrDscnt;
        } else {
        	reDsCntGoodsUntPc = orderModel.getGoodsUntpc() - rePdDscntAmount - reGradeDscAmount - reRmndrDscnt;
        }

        reWtChangePc = Double.valueOf(reDsCntGoodsUntPc * orderModel.getWtChange()).longValue();
        reOrderPc = reDsCntGoodsUntPc * orderWt;

        orderModel.setExpectDlvrf(expectDlvrf);

        orderModel.setGoodsUntpc(dsCntGoodsUntPc);
        orderModel.setWtChangegld(wtChangePc);
        orderModel.setOrderPc(orderPc);

        /** 공급가 **/
        splpc =  ( orderModel.getGoodsUntpc() * orderWt ) + orderModel.getWtChangegld() + expectDlvrf - cpDscntAmount;
        reSplpc = ( reDsCntGoodsUntPc * orderWt ) + reWtChangePc + reExpectDlvrf - reCpDscntAmount;

        /** 부가세 **/
        vat = (long) (splpc * 0.1);
        reVat = (long) (reSplpc * 0.1);

        /** 판매가 **/
        slepc = splpc + vat;
        reSlepc = reSplpc + reVat;

        orderModel.setSplpc(splpc);
        orderModel.setVat(vat);
        orderModel.setSlepc(slepc);

        orderModel.setReSplpc(reSplpc);
        orderModel.setReVat(reVat);
        orderModel.setReSlepc(reSlepc);
    }

    @Override
    public HashMap<String, Object> getCheckDataDlvyTariff(OrderModel orderModel, int orderWt, boolean newGetBlListUseStatus) throws CommCustomException, Exception {
        // 배송비 계산을 최적의 BL 단위로 계산하여 더한다. 20211112 추가

        List<ItemPriceMatchingBlInfoVO> blList = null;

        if(newGetBlListUseStatus) {
            // 새로 최적의 BL 가져오기 사용
            blList = getOptimalBlList(orderModel.getEntrpsNo(), orderModel.getMetalCode(), orderModel.getItmSn(), orderModel.getDstrctLclsfCode()
                    , orderModel.getBrandGroupCode(), orderModel.getRealBrandCode(), orderModel.getSleMthdCode(), orderModel.getOrderWt()
                    , orderModel.getSleUnitWt(), orderModel.getOnceSlePossWt(), orderModel.getReMainBlNo(), "N", orderModel.getSleMthdDetailCode()
                    , orderModel.getCntrctOrderBasInfo().getCntrctOrderNo(), orderModel.getSmlqyPurchsAt());
        } else {
            // 주문 시 가져왔던 최적의 BL 재활용
            blList = orderModel.getBlList();
        }

        if(blList.isEmpty()) {
            log.warn(">> getCheckDataDlvyTariff : 배송비 구하기 실패");
        }

        // 배송비 계산을 최적의 BL 단위로 계산하여 더한다. 20211112 추가
        long expectDlvrf = 0;
        String lastSvcSeCode = ""; // 서비스 구분 코드 [00:정상, 01:배송불가, 02:서비스가능지역아님]
        String dstrctMlsfcNm = ""; // 권역 중분류 코드명
        long sectionPrice = 0; // 구간금액

        // 당일 배송인지 아닌지 체크, 배송 요율 금액 순으로 order by 기준이 된다
        String dlivyRequstDe = orderModel.getDlivyRequstDe().replaceAll("-", ""); // 배송요청일
        String getNowDate = DateUtil.getNowDate(); // 현재날짜
        log.warn(">> getNowDate : " + getNowDate + ", dlivyRequstDe : " + dlivyRequstDe);
        if(StringUtils.equals(getNowDate, dlivyRequstDe)) {
            orderModel.setSameDayDeliveryAt("Y"); // 당일배송
        } else {
            orderModel.setSameDayDeliveryAt("N"); // 당일배송 아님
        }

        // 배송 요율 조회를 위한 기본조건 설정
        setDlvyTariffBaseInfo(orderModel);

        // 최적의 BL에서 준 리스트에서 BL별로 재고 파악 및 재고 차감
        for(ItemPriceMatchingBlInfoVO  bl : blList) {
            log.warn(">> getCheckDataDlvyTariff dstrctMlsfcCode : " + bl.getDstrctMlsfcCode());

            orderModel.setDstrctMlsfcCode(bl.getDstrctMlsfcCode()); // 권역 중분류 코드
            if(StringUtils.equals(orderModel.getDlvyMnCode(), "01")) {
                long dlvyPrice = 0L;

                Map<String, String> selectDlvyTariffInfo = selectDlvyTariffInfo(orderModel);
                log.warn(">> getCheckDataDlvyTariff selectDlvyTariffInfo : " + selectDlvyTariffInfo);
                if(selectDlvyTariffInfo != null) {
                    dlvyPrice = Long.parseLong(Optional.ofNullable(String.valueOf(selectDlvyTariffInfo.get("DLVY_TARIFF"))).orElse("0"));
                    lastSvcSeCode = String.valueOf(selectDlvyTariffInfo.get("SVC_SE_CODE")); // 서비스 구분 코드
                    dstrctMlsfcNm = String.valueOf(selectDlvyTariffInfo.get("DSTRCT_MLSFC_NM")); // 권역 중분류 코드명
                    sectionPrice = dlvyPrice; // 구간금액
                }

                if(StringUtils.equals(orderModel.getMetalCode(), CommOrderConstant.METAL_NI) || StringUtils.equals(orderModel.getMetalCode(), CommOrderConstant.METAL_SN)) {
                    // 예상 배송비 계산
                    expectDlvrf = dlvyPrice;
                    break;
                } else {
                    // 예상 배송비 계산
                    //long calcDlvrf = dlvyPrice * ( orderModel.getOrderWt() / 25 );
                    //long calcDlvrf = dlvyPrice * ( orderWt / 25 );
                    long calcDlvrf = dlvyPrice * ( bl.getMatchedOrderedBnt().intValue() / orderModel.getSleUnitWt() );

                    expectDlvrf += calcDlvrf;
                }
            }
        }

        log.warn(">> expectDlvrf : " + expectDlvrf + ", lastSvcSeCode : " + lastSvcSeCode + ", dstrctMlsfcNm : " + dstrctMlsfcNm + ", sectionPrice : " + sectionPrice);

        double wtChange = this.getWtChange(orderModel);
        log.warn(">> wtChange : " + wtChange);

        // 2022-08-16 jhcha
        // 기존 배송비 계산 부분 삭제

        ////무료 배송 프로모션
        ////배송비 여부
        String dlvrfDscntAt = commOrderMapper.selectDlvrfDscntAt(orderModel.getEntrpsNo());
        long dscntExpectDlvrf = 0; //할인된 배송비

        //if( dlvrfDscntAt.equals("N") ){
        if(StringUtils.equals(orderModel.getMetalCode(), CommOrderConstant.METAL_NI) || StringUtils.equals(orderModel.getMetalCode(), CommOrderConstant.METAL_SN)) {
            double calc_1 = 1;
            dscntExpectDlvrf = (long) (expectDlvrf * calc_1);
        }else {
            double calc_1 = 1 / ( (double)orderWt / orderModel.getSleUnitWt() );
            dscntExpectDlvrf = (long) (expectDlvrf * calc_1);
        }
        //}

        HashMap<String, Object> returnMap = new HashMap<String, Object>();
        returnMap.put("expectDlvrf", Optional.ofNullable(expectDlvrf).orElse(0L));
        returnMap.put("lastSvcSeCode", lastSvcSeCode);
        returnMap.put("dstrctMlsfcNm", dstrctMlsfcNm);
        returnMap.put("sectionPrice", Optional.ofNullable(sectionPrice).orElse(0L));
        returnMap.put("wtChange", wtChange);
        returnMap.put("dscntExpectDlvrf", dscntExpectDlvrf); //할인금액
        returnMap.put("dlvrfDscntAt", dlvrfDscntAt); //할인여부 ( N 일경우 할인 전 )

        return returnMap;
    }

    /**
     * <pre>
     * 처리내용: 사용쿠폰 리스트 조회
     * </pre>
     * @date 2023. 08. 02.
     * @auther sumin
     * @history
     * -----------------------------------------------
     * 변경일                  작성자             변경내용
     * -----------------------------------------------
     * 2023. 08. 02.            sumin               최초작성
     * 2023. 11. 20.            srec0053            프로젝트 이관
     * -----------------------------------------------
     * @param orderModel
     * @param orderWt
     * @throws CommCustomException
     * @throws Exception
     */
    @Override
    public void couponSelectList(OrderModel orderModel, int orderWt) throws CommCustomException, Exception {

        // 쿠폰 사용가능 여부 추가
        List<CouponVO> resultList = new ArrayList<CouponVO>();
        String[] couponSeqNoArray = {};

        /******* 분기 필요 없어지므로 합침 *******/
        couponSeqNoArray = orderModel.getCouponSeqNo().split(",");      //단가쿠폰, 배송비 1차수 할인 쿠폰
        resultList = commOrderMapper.selectUntpcCouponSeqNo(couponSeqNoArray, orderModel.getCouponDplctUseLmttQyAt(), orderModel.getEntrpsNo(), orderWt);

        // 중복사용제한 이 없으면(N) 이면 제한되지 않은 놈들만
        if (couponSeqNoArray.length > 1) {
            orderModel.setCouponDplctUseLmttQyAt("N");
        }

        orderModel.setCouponList(resultList);

        if (resultList.size() < 1) {
            throw new CommCustomException("해당 쿠폰은 다른 사용자가 이미 사용했습니다.");
        }
    }


    /**
     * <pre>
     * 처리내용: 쿠폰 사용여부, 타입에 따라 금액 계산 로직 수행
     * </pre>
     * @date 2023. 08. 02.
     * @auther sumin
     * @history
     * -----------------------------------------------
     * 변경일                  작성자             변경내용
     * -----------------------------------------------
     * 2022. 12. 27.            chajeeman           최초작성
     * 2023. 08. 02.            sumin               수정
     * 2023. 11. 20.            srec0053            프로젝트 이관
     * -----------------------------------------------
     * @param orderModel
     * @param orderWt
     * @throws CommCustomException
     * @throws Exception
     */
    @Override
    public CouponVO couponUse(OrderModel orderModel, int orderWt, boolean newGetBlListUseStatus) throws CommCustomException, Exception {

        long dscntAmout = 0;            // 쿠폰할인 금액
        long dscntExpectDlvrf = 0;      // 배송비 할인 금액 (배송비 할인 배송비 -)
        long pdDscntAmount = 0;         // 상품할인 금액 (단가 할인 상품-)
        long cpDscntAmount = 0;         // 공급가 할인 금액 (금액권 총액-)

        CouponVO couponvo = new CouponVO();

        //배송 할인 프로모션
        Map<String, Object> expectDlvrfMap = getCheckDataDlvyTariff(orderModel, orderModel.getOrderWt(), newGetBlListUseStatus);
        long expectDlvrf = Long.parseLong(Optional.ofNullable(String.valueOf(expectDlvrfMap.get("expectDlvrf"))).orElse("0")); //배송비

        if (orderModel.getCouponList().size() == 0) {

            dscntExpectDlvrf = 0;

        } else {
            for(CouponVO couponVo : orderModel.getCouponList()) {
                switch(couponVo.getCouponTyCode()) {
                    // 배송비 쿠폰
                    case "03" :
                        // 2022-08-17 jhcha  할인금액 쿠폰할인금액으로 변경   기존 로직을 최대한 활용
                        dscntExpectDlvrf += Long.parseLong(Optional.ofNullable(String.valueOf(expectDlvrfMap.get("dscntExpectDlvrf"))).orElse("0")); //배송비할인금액
                        break;

                    // 단가 할인 쿠폰 OR 총액 쿠폰
                    case "01" :
                    case "04" :
                        pdDscntAmount += Long.parseLong(Optional.ofNullable(String.valueOf(couponVo.getCouponDscntAmount())).orElse("0")); //단가할인금액
                        break;
                }
            }
        }

        //쿠폰 사용 총 금액
        dscntAmout = ( pdDscntAmount * orderWt ) + cpDscntAmount + dscntExpectDlvrf;
        orderModel.setRealDscntApplcAmount(String.valueOf(dscntAmout));     //실제 할인 적용 금액

        //expectDlvrf 요율 조회
        expectDlvrf = expectDlvrf - dscntExpectDlvrf ;

        if(expectDlvrf < 0) {
            throw new CommCustomException("당일배송 여부가 N이거나 당일배송 요율 값이 null 또는 0입니다.");
        }

        couponvo.setExpectDlvrf(expectDlvrf);           //총 배송비할인금액;
        couponvo.setPdDscntAmount(pdDscntAmount);       //총 단가할인금액
        couponvo.setCpDscntAmount(cpDscntAmount);       //총 총액 할인금액

        return couponvo;
    }


    /**
     *  배송비 계산을 위한 차량정보 세팅
     */
    @Override
    public void setDlvyTariffBaseInfo(OrderModel orderModel) throws Exception {
        int arrIndex = -1;
        String metalCode = orderModel.getMetalCode(); // 금속 코드

        if(StringUtils.equals(metalCode, CommOrderConstant.METAL_NI) || StringUtils.equals(metalCode, CommOrderConstant.METAL_SN)) {

            // 판매단위중량(상품별) 및 최대구매가능중량(상품별) 가져오기
            CommItmWtInfoVO sleWtInfo = Optional.ofNullable(this.selectItmWtInfo(orderModel.getItmSn())).orElseThrow(() -> {
                log.info(" setDlvyTariffBaseInfo line-4720 vo.toString() >> " + orderModel.toString());
                return new CommCustomException("해당 상품_아이템 정보가 없습니다.");});

            int sleUnitWt = Optional.ofNullable(sleWtInfo.getSleUnitWt().intValue() / 1000).orElse(0); // 판매 단위 중량
            if (sleUnitWt == 0) {
                log.info(" setDlvyTariffBaseInfo line-4725 vo.toString() >> " + orderModel.toString());
                throw new CommCustomException("판매 단위 중량이 null이거나 0입니다.");
            }

            arrIndex = (orderModel.getOrderWt()/sleUnitWt)-1;
            log.info(" setDlvyTariffInfo line-4768 arrIndex : " + arrIndex + ", sleUnitWt : " + sleUnitWt + ", orderWt : " + orderModel.getOrderWt());

            if (arrIndex < 0 || arrIndex > CommOrderConstant.VHCLE_TON_CODE_ARR.length-1) {
                throw new CommCustomException("배송요율 조회대상 차량 톤 코드가 존재하지 않습니다.");
            }
            /* NI(니켈), SN(주석) 주문인 경우만 해당 */
            orderModel.setVhcleTonCode(CommOrderConstant.VHCLE_TON_CODE_ARR[arrIndex]);

        } else {
            /* NI(니켈), SN(주석) 주문이 아닌 경우 */
            orderModel.setVhcleTonCode(CommOrderConstant.VHCLE_TON_CODE_DEFAULT);
        }

        log.info(" setDlvyTariffInfo line-4780 vo.toString() >> " + orderModel.toString());
    }

    /**
     *  배송 요율 조회
     */
    public Map<String, String> selectDlvyTariffInfo(OrderModel orderModel) throws Exception {
        return commOrderMapper.selectDlvyTariffInfo(orderModel);
    }

    /**
     * ITM_SN(아이템 순번)에 해당되는 IT_ITM_INFO_BAS(상품_아이템 기본)의 WT_CHANGE(중량 변동) 값을 가져온다.
     */
    @Override
    public double getWtChange(OrderModel orderModel) throws CommCustomException, Exception {
        BigDecimal wtChange = Optional.ofNullable(commOrderMapper.selectWtChange(orderModel)).orElse(new BigDecimal("-1")); // null일때 음수로 반환, 음수일때는 후처리로 넘김

        return wtChange.doubleValue();
    }
}
