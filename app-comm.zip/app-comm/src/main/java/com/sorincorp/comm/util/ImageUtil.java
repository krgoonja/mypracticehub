package com.sorincorp.comm.util;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

import lombok.extern.slf4j.Slf4j;

/**
 * ImageUtil.java
 * @version
 * @since 2021. 5. 18.
 * @author srec0012
 */

@Slf4j
public class ImageUtil {
	
	private ImageUtil() {
		log.debug(ImageUtil.class.getSimpleName());
	}
	
	/**
	 * <pre>
	 * 이미지 리사이징
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param imageFile
	 * @param imageType
	 * @param width
	 * @param height
	 * @throws Exception
	 */
	public static void resizeImage(File imageFile, String imageType, int width, int height) throws Exception {
		BufferedImage orgImg = ImageIO.read(imageFile);
		BufferedImage resizeImage = createResized(orgImg, width, height, true);
		ImageIO.write(resizeImage, imageType, imageFile);
	}
	
	/**
	 * <pre>
	 * 리사이징 한 이미지 생성
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param org_img
	 * @param width
	 * @param height
	 * @param alpha
	 * @return
	 * @throws Exception
	 */
	public static BufferedImage createResized(Image org_img, int width, int height, boolean alpha) throws Exception {
		int imgType = alpha ? BufferedImage.TYPE_INT_RGB : BufferedImage.TYPE_INT_ARGB;
		BufferedImage scale = new BufferedImage(width, height, imgType);
		Graphics2D g = scale.createGraphics();
		
		if ( alpha ) {
			g.setComposite(AlphaComposite.Src);
		}
		
		g.drawImage(org_img, 0, 0, width, height, null);
		g.dispose();
		
		return scale;
	}
}
