package com.sorincorp.comm.itemprice.mapper;

import com.sorincorp.comm.itemprice.model.ItemPriceCommVO;

public interface ItemPriceCommMapper {

	void deleteOrderBasketForModifySellMetal(ItemPriceCommVO itemPriceVO) throws Exception;
	
	void deleteHopeAlramForModifySellMetal(ItemPriceCommVO itemPriceVO) throws Exception;
	
	void deleteInventoryAlramForModifySellMetal(ItemPriceCommVO itemPriceVO) throws Exception;

}
