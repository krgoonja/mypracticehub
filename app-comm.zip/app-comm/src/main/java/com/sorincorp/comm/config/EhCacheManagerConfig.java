package com.sorincorp.comm.config;

// import org.springframework.cache.ehcache.EhCacheCacheManager;
// import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
// import org.springframework.context.annotation.Bean;
// import org.springframework.core.io.ClassPathResource;

// @Configuration
public class EhCacheManagerConfig {

	/** Ehcache에서 사숑할 Bean **/
//    @Bean
//    public EhCacheManagerFactoryBean ehCacheManagerFactoryBean() {
//        EhCacheManagerFactoryBean ehCacheManagerFactoryBean = new EhCacheManagerFactoryBean();
//        ehCacheManagerFactoryBean.setConfigLocation(new ClassPathResource("config/ehcache/ehcache.xml"));
//        ehCacheManagerFactoryBean.setShared(true);
//        return ehCacheManagerFactoryBean;
//    }
//
//    @Bean
//    public EhCacheCacheManager ehCacheCacheManager(EhCacheManagerFactoryBean ehCacheManagerFactoryBean) {
//        EhCacheCacheManager ehCacheCacheManager = new EhCacheCacheManager();
//        ehCacheCacheManager.setCacheManager(ehCacheManagerFactoryBean.getObject());
//        return ehCacheCacheManager;
//    }
}