package com.sorincorp.comm.brandcode.model;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Data;

@Data
public class BrandCodeVO implements Serializable {

    private static final long serialVersionUID = 2470820259130490055L;

    private String brandGroupCode;

    private String subCode;

    /**
     * 브랜드이름
     */
    private String codeNm;
    
    /**
     * 브랜드상세이름
     */
    private String codeDetailNm;

    private int codeOrdr;

    private int priorRank;

    private String metalCode;

    private String nationCode;

    private String nationFlagUrl;
    
    // 브랜드 무관 조회 여부
    private String brandInrrelevantInqireAt;

    /** 자투리 여부 */
    private String blRemain;
    private String blRemain2;
    
    private String remainBlNo;

    private int blRemainCnt;
    
    private int sleInvntryUnsleBundleBnt;
    
    private String dstrctLclsfCode;
    
    private String itmSn;
    
    private String dspyGoodsNm;
    
    private String dstrctLclsfNm;
    
    private String brandGroupNm;
    
    private String nationNm;
    
    private String itmNm;
    
    /**
     * 관심상품 등록여부
     */
    private String existBsktYn;
    
    /**
     * 관심상품번호
     */
    private String bsktNo;
    
    /**
     * 판매단위중량
     */
    private int sleUnitWt;
    
    /**
     * 판매단위중량(톤) * (1 - 계약서 시작 허용 중량 비율 * 0.01)
     */
    private BigDecimal caculPermWtRate;
    
    /**
     * 판매 재고 미판매 잔량
     */
    private int sleInvntryUnsleBnt;

    private double sleInvntryUnsleBntStock;

    /**
     * BL 번호
     */
    private String blNo;
    /**
     * 자투리 할인
     */
    private BigDecimal rmndrDscnt;
    /**
     * 선물 잔량
     */
    private int remainQy;
    /**
     * 소량 판매 선물 여부
     */
    private String smlqySleFtrsAt;
    /**
     * 성적서 파일 경로
     */
    private String screofeFileCours;
    /**
     * 창고 코드
     */
    private String wrhousCode;
    /**
     * 물류 센터(창고 명)
     */
    private String wrhousNm;
    /**
     * 창고 도로명 주소
     */
    private String wrhousRnAdres;
    /**
     * 권역 중분류 코드
     */
    private String dstrctMlsfcCode;
    /**
     * 권역 중분류 코드 명
     */
    private String dstrctMlsfcNm;
}