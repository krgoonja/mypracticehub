package com.sorincorp.comm.entrpsgrade.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class EntrpsGradeVO implements Serializable {

	private static final long serialVersionUID = 3593744237082640130L;

	/**
	 * 업체번호
	 */
	private String entrpsNo;
	/* 업체등급별 혜택 */
	/**
	 * 업체등급 코드
	 */
	private String entrpsGrad;
	/**
	 * 업체등급 코드명
	 */
	private String entrpsGradNm;
	/**
	 * 메탈코드
	 */
	private String metalCode;
	/**
	 * 시행 일자
	 */
	private String opertnDe;
	/**
	 * 재고 표시 여부
	 */
	private String invntryIndictAt;
	/**
	 * 전문가용 메일링 서비스 여부
	 */
	private String spcltyusefulEmailringSvcAt;
	/**
	 * 1일 구매 중량 한도
	 */
	private int onedePurchsWtLmt;
	/**
	 * 1회 구매 중량 한도
	 */
	private int oncePurchsWtLmt;
	/**
	 * 적립마일리지
	 */
	private int accmlMlg;

	/* 업체 평가등급 */
	/**
	 * 업체 평가 등급코드
	 */
	private String entrpsEvlGrad;
	/**
	 * 업체 평가 등급코드명
	 */
	private String entrpsEvlGradNm;
	/**
	 * 시작 신용 등급
	 */
	private String beginCredtGrad;
	private String beginCredtGradNm;
	/**
	 * 종료 신용 등급
	 */
	private String endCredtGrad;
	private String endCredtGradNm;
	/**
	 * 여신 구간
	 */
	private int cdtlnSctn;
	/**
	 * 담보 보증 하용 상환 기간 시작일
	 */
	private int mrtggGrntyPermBeginPd;
	/**
	 * 담보 보증 하용 상환 기간 종료일
	 */
	private int mrtggGrntyPermRepyPd;

	/* 업체구매성향 등급 */
	/**
	 * 구매성향등급
	 */
	private String purchsInclnGrad;
	private String purchsInclnGradNm;
	/**
	 * 증거금 권한 비율
	 */
	private double wrtmAuthorRate;
	private double wrtmAuthorRateDcmlpoint;

}
