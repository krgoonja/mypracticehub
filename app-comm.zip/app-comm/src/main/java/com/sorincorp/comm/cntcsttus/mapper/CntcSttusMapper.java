package com.sorincorp.comm.cntcsttus.mapper;

import com.sorincorp.comm.cntcsttus.model.CntcSttusVO;

/**
 * CntcSttusMapper.java
 * @version
 * @since 2021. 11. 5.
 * @author srec0032
 */
public interface CntcSttusMapper {

	/**
	 * <pre>
	 * 처리내용: 공통_연계 상태 기본 테이블의 상태를 조회 한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param dataVo
	 * @return
	 */
	int updateCoCntcSttusBas(CntcSttusVO dataVo);

	CntcSttusVO selectCoCntcSttusBas(String intrfcSeCode);

}
