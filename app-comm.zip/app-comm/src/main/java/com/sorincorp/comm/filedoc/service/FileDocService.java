package com.sorincorp.comm.filedoc.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.sorincorp.comm.filedoc.model.FileDocVO;

public interface FileDocService {
	/**
	 * <pre>
	 * 일반 첨부파일(이미지 제외)을 Upload하고 문서기본 Table에 등록된 문서 ID 배열을 반환한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param jobSe - 업무 구분
	 * @param mrequest - Upload할 파일의 MultipartServletRequest
	 * @return - 문서기본 Table의 문서 ID 배열
	 * @throws Exception 
	 */
	public int[] uploadAttachFiles(String jobSe, MultipartHttpServletRequest mrequest) throws Exception;
	
	
	/**
	 * <pre>
	 * 일반 첨부파일(이미지 제외)을 Upload하고 문서기본 Table에 등록된 문서 FileDocVO 리스트를 반환한다.
	 * </pre>
	 * @date 2021. 8. 13.
	 * @author srec0042
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 13.			srec0042			최초작성
	 * ------------------------------------------------
	 * @param jobSe
	 * @param mrequest
	 * @return 문서기본 Table에 등록된 문서 FileDocVO 리스트
	 * @throws Exception
	 */
	public List<FileDocVO> uploadAttachFilesVoList(String jobSe, MultipartHttpServletRequest mrequest) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: BLOB 삭제처리
	 * </pre>
	 * @date 2022. 12. 27.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 27.		chajeeman			최초작성
	 * -----------------------------------------------
	 * @param jobSe
	 * @param floderNm
	 * @param mrequest
	 * @return
	 * @throws Exception
	 */
	public void deleteAttachFilesVo(Map<String, Object> deleteMap) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: BLOB 삭제처리
	 * </pre>
	 * @date 2024. 07. 04.
	 * @auther hyunjin05
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2024. 07. 04.		hyunjin05			최초작성
	 * -----------------------------------------------
	 * @param jobSe
	 * @param floderNm
	 * @param mrequest
	 * @return
	 * @throws Exception
	 */
	public void deleteBlobFilesVo(Map<String, Object> deleteMap) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 폴더명 구분 추가, PDF 파일만.
	 * </pre>
	 * @date 2022. 12. 23.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 23.		chajeeman			최초작성
	 * -----------------------------------------------
	 * @param jobSe
	 * @param floderNm
	 * @param mrequest
	 * @return
	 * @throws Exception
	 */
	public List<FileDocVO> uploadAttachFilesVoList(String jobSe, String floderNm, MultipartHttpServletRequest mrequest) throws Exception;
	
	/**
	 * <pre>
	 * Public Blob Storage에 첨ㅂ 파일을 등록한다.
	 * </pre>
	 * @date 2021. 9. 30.
	 * @author srec0055
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 30.			srec0055			최초작성
	 * ------------------------------------------------
	 * @param jobSe
	 * @param mrequest
	 * @return 문서기본 Table에 등록된 문서 FileDocVO 리스트
	 * @throws Exception
	 */
	public List<FileDocVO> uploadPublicAttachFilesVoList(String jobSe, MultipartHttpServletRequest mrequest) throws Exception;
	
	/**
	 * <pre>
	 * 일반 첨부 이미지를 Upload하고 문서기본 Table에 등록된 문서 ID 배열을 반환한다.
	 * </pre>
	 * @date 2021. 6. 14.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 14.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param jobSe - 업무 구분
	 * @param mRequest - Upload할 파일의 MultipartServletRequest
	 * @return - 문서기본 Table의 문서 ID 배열
	 * @throws Exception
	 */
	public int[] uploadAttachImages(String jobSe, MultipartHttpServletRequest mRequest) throws Exception;
	
	/**
	 * <pre>
	 * 상품 이미지를 Upload하고 문서기본 Table에 등록된 문서 ID 배열을 반환한다.
	 * </pre>
	 * @date 2021. 6. 14.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 14.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param itemCode - 이미지를 등록할 상품의 ITEM Code
	 * @param mRequest - Upload할 파일의 MultipartServletRequest
	 * @return - 문서기본 Table의 문서 ID 배열
	 * @throws Exception
	 */
	public int[] uploadProductImages(String itemCode, MultipartHttpServletRequest mRequest) throws Exception;
	
	/**
	 * <pre>
	 * 문서번호로 문서 정보를 조회한다.
	 * </pre>
	 * @date 2021. 6. 14.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 14.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param docNo - 조회할 문서번호
	 * @return - 문서 정보
	 * @throws Exception
	 */
	public FileDocVO selectDocInfo(int docNo) throws Exception;
	
	/**
	 * <pre>
	 * 문서번호로 문서 이름을 조회한다.
	 * </pre>
	 * @date 2021. 6. 14.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 14.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param docNo - 조회할 문서 번호
	 * @return - 문서 이름
	 * @throws Exception
	 */
	public String selectDocName(int docNo) throws Exception;
	
	/**
	 * <pre>
	 * 문서번호로 문서의 상대경로를 조회한다.
	 * </pre>
	 * @date 2021. 6. 14.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 14.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param docNo - 조죄할 문서 번로
	 * @return - 문서의 상대경로
	 * @throws Exception
	 */
	public String selectDocPath(int docNo) throws Exception;
	
	/**
	 * <pre>
	 * 문서번호로 문서의 절대경로를 조회한다.
	 * </pre>
	 * @date 2021. 6. 14.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 14.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param docNo - 조죄할 문서 번로
	 * @return - 문서의 절대경로
	 * @throws Exception
	 */
	public String selectDocRealPath(int docNo) throws Exception;
	
	/**
	 * <pre>
	 * 문서 번호의 문서를 삭제처리 한다.
	 * </pre>
	 * @date 2021. 6. 29.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 29.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param docNo
	 * @throws Exception
	 */
	public void deleteCommonDoc(int docNo) throws Exception;
	
	/**
	 * 
	 * <pre>
	 * 처리내용: BlobStorage 의 파일을 다운로드 한다.
	 * </pre>
	 * @date 2021. 9. 3.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 3.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @param response
	 * @param vo
	 * @throws Exception
	 */
	public void fileDocDownload(HttpServletRequest request,HttpServletResponse response,FileDocVO vo) throws Exception;
}
