package com.sorincorp.comm.bsnInfo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class RestdeFxLmeVO implements Serializable{
    
	private static final long serialVersionUID = 2849004139164064398L;

    /**
     * 적용 일자
    */
    private String applcDe;
    /**
     * 하나은행 휴일 여부
    */
    private String eventRestdeFxAt;
    /**
     * LME 휴일 여부
    */
    private String lmeRestdeAt;
  
}
