package com.sorincorp.comm.order.service;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.order.mapper.CommFtrsFshgMngMapper;
import com.sorincorp.comm.order.model.CommFtrsFshgMngVO;

import lombok.extern.slf4j.Slf4j;

/**
 * CommFtrsFshgMngServiceImpl.java
 * 선물 선물환 관리 Service 구현체 클래스
 *
 * @version
 * @since 2022. 6. 7.
 * @author srec0049
 */
@Slf4j
@Service
public class CommFtrsFshgMngServiceImpl implements CommFtrsFshgMngService {

	@Autowired
	private CommonCodeService commonCodeService;

	@Autowired
	CommFtrsFshgMngMapper commFtrsFshgMngMapper;

	/**
	 * 오늘 날짜 기준의 적용 일자에 해당하는 상품_선물 선물환 관리 상세 리스트를 조회한다.
	 */
	@Override
	public List<CommFtrsFshgMngVO> commFtrsFshgManageDtlListByToday(String postnCode) throws Exception {
		List<CommFtrsFshgMngVO> commFtrsFshgManageDtlListByToday = commFtrsFshgMngMapper.commFtrsFshgManageDtlListByToday(postnCode);

		return commFtrsFshgManageDtlListByToday;
	}

	/**
	 * 금속 코드, 포지션 코드를 조건으로 필터하고, 3개월 LME 가격(3M 가격)으로 SKIP 대상인지 판별 후 CommFtrsFshgMngVO 값을 리턴한다.
	 */
	@Override
	public CommFtrsFshgMngVO getFtrsFshgMngRetVo(String metalCode, String postnCode, BigDecimal threemonthLmePc) throws Exception {
		// 지정된 메탈코드에 따른 공통메탈코드 정보 중 호가단위를 가져온다.
		CommonCodeVO metalCodeInfo = Optional.ofNullable(commonCodeService.getCodeValueRetVo("METAL_CODE", metalCode)).orElse(new CommonCodeVO());
		String quoteUnitStr = Optional.ofNullable(metalCodeInfo.getCodeChrctrRefrnfive()).orElse("0");
		double quoteUnit = Double.parseDouble(quoteUnitStr);
		log.warn(">> 호가단위 : " + quoteUnit);

		List<CommFtrsFshgMngVO> tempList = Optional.ofNullable(this.commFtrsFshgManageDtlListByToday(postnCode)).orElseGet(Collections::emptyList).stream()
				.filter(data -> ( StringUtils.equals(data.getMetalCode(), metalCode) ))
				.map(data -> {
					double getThreemonthLmePc = threemonthLmePc.doubleValue();

					String skipAt = "N";
					double ftrsSkipBeloAmount = 0d; // 선물 스킵 미만 금액
					double ftrsSkipExcessAmount = 0d; // 선물 스킵 초과 금액
					if(StringUtils.equals(data.getFtrsSkipBeloAt(), "Y")) ftrsSkipBeloAmount = Double.parseDouble(String.valueOf(data.getFtrsSkipBeloAmount()));
					if(StringUtils.equals(data.getFtrsSkipExcessAt(), "Y")) ftrsSkipExcessAmount = Double.parseDouble(String.valueOf(data.getFtrsSkipExcessAmount()));

					if(StringUtils.equals(data.getFtrsSkipBeloAt(), "Y") && StringUtils.equals(data.getFtrsSkipExcessAt(), "Y")) {
						if(getThreemonthLmePc < ftrsSkipBeloAmount || getThreemonthLmePc > ftrsSkipExcessAmount) {
							// 3M 가격이 선물 스킵 미만 금액보다 작거나 선물 스킵 초과 금액보다 클 경우
							skipAt = "Y";
							log.warn(">> 3M 가격이 선물 스킵 미만 금액보다 작거나 선물 스킵 초과 금액보다 클 경우");
						}
					} else if(StringUtils.equals(data.getFtrsSkipBeloAt(), "Y") && StringUtils.equals(data.getFtrsSkipExcessAt(), "N")) {
						if(getThreemonthLmePc < ftrsSkipBeloAmount) {
							// 3M 가격이 선물 스킵 미만 금액보다 작을 경우
							skipAt = "Y";
							log.warn(">> 3M 가격이 선물 스킵 미만 금액보다 작을 경우");
						}
					} else if(StringUtils.equals(data.getFtrsSkipBeloAt(), "N") && StringUtils.equals(data.getFtrsSkipExcessAt(), "Y")) {
						if(getThreemonthLmePc > ftrsSkipExcessAmount) {
							// 3M 가격이 선물 스킵 초과 금액보다 클 경우
							skipAt = "Y";
							log.warn(">> 3M 가격이 선물 스킵 초과 금액보다 클 경우");
						}
					} else {
						// 스킵 사용 없음
						skipAt = "N";
						log.warn(">> 스킵 사용 없음");
					}

					data.setSkipAt(skipAt);

					// 삼성선물 틱 호가 단위 설정
					data.setQuoteUnit(quoteUnit);

					return data;
				})
				.collect(Collectors.toList());

		CommFtrsFshgMngVO commFtrsFshgMngVO = null;

		if(tempList.size() > 0) {
			commFtrsFshgMngVO = tempList.get(0);
		}

		return commFtrsFshgMngVO;
	}
}
