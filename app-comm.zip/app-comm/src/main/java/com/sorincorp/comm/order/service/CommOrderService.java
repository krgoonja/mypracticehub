package com.sorincorp.comm.order.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.order.model.CommItmWtInfoVO;
import com.sorincorp.comm.order.model.CouponVO;
import com.sorincorp.comm.order.model.OrderModel;

/**
 * CommOrderService.java
 * 주문 공통 Service 인터페이스
 *
 * @version
 * @since 2023. 5. 2.
 * @author srec0049
 */
public interface CommOrderService {

	/**
	 * <pre>
	 * 처리내용: 판매 단위 중량(상품별) 및 1회 판매 가능 중량(상품별), 최대 구매 가능 중량(상품별) 가져오기
	 * </pre>
	 * @date 2023. 5. 2.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 2.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param itmSn
	 * @return
	 * @throws Exception
	 */
	public CommItmWtInfoVO selectItmWtInfo(int itmSn) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 최적의 BL 리스트를 가져온다
	 * </pre>
	 * @date 2023. 5. 2.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 2.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param entrpsNo 업체 번호
	 * @param metalCode 금속 코드
	 * @param itmSn 아이템 순번
	 * @param dstrctLclsfCode 권역 대분류 코드
	 * @param brandGroupCode 브랜드 그룹 코드
	 * @param brandCode 브랜드 코드
	 * @param sleMthdCode 판매 방식 코드
	 * @param orderWt 주문 중량
	 * @param sleUnitWt 판매 단위 중량
	 * @param onceSlePossWt 1회 판매 가능 중량
	 * @param reMainBlNo 지정 BL 번호
	 * @param leftOverWtRetrunBlEmptyYn 재고없음처리 리턴여부 (잔여 재고량을 받으려면 Y, 받지 않으려면 N)
		 *  1) N일 경우 list가 비었는지로 재고 체크
		 *  2) Y일 경우 list 0번째의 leftOverWeight 값으로 재고 체크
	 * @return
	 * @throws Exception
	 */
	public List<ItemPriceMatchingBlInfoVO> getOptimalBlList(String entrpsNo, String metalCode, int itmSn, String dstrctLclsfCode, String brandGroupCode
			, String brandCode, String sleMthdCode, int orderWt, int sleUnitWt, int onceSlePossWt
			, String reMainBlNo, String leftOverWtRetrunBlEmptyYn, String sleMthdDetilCode, String cntrctOrderNo, String smlqyPurchsAt) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문 중량에 대한 재고 차감
	 * </pre>
	 * @date 2023. 5. 10.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 10.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderModel
	 * @throws Exception
	 */
	public void updateMinusInvntryBlInfoBas(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 평균가 단가(확정 단가) 계산
	 * </pre>
	 * @date 2023. 11. 20.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11.  2.			srec0066			최초작성
	 * 2023. 11. 20.			srec0053			프로젝트 이관
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws CommCustomException
	 * @throws Exception
	 */
	public long getAvrgpcGoodsUntpc(OrderModel orderModel) throws CommCustomException, Exception;

	/**
	 * <pre>
     * 처리내용: 현재 단가와 주문 중량을 기준으로 가격 정보를 세팅한다.
     * </pre>
     * @date 2021. 10. 25.
     * @author srec0043
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.            srec0043            최초작성
	 * 2023. 11. 20.			srec0053			프로젝트 이관
	 * ------------------------------------------------
	 * @param orderModel
	 * @param calcGoodsUntpc
	 * @param orderWt
	 * @throws CommCustomException
	 * @throws Exception
	 */
	public void setPriceInfo(OrderModel orderModel, long calcGoodsUntpc, int orderWt) throws CommCustomException, Exception;
	
	/**
	 * <pre>
	 * 처리내용: 배송비와 쿠폰을 반영한 주문 가격 정보들의 계산 및 세팅
	 * </pre>
	 * @date 2023. 11. 20.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 20.			srec0053			최초작성(Extracted Method)
	 * ------------------------------------------------
	 * @param orderModel
	 * @param orderWt
	 * @param newGetBlListUseStatus
	 * @return
	 * @throws Exception
	 * @throws CommCustomException
	 * @throws NumberFormatException
	 */
	public void setOrderPcWithDlvrfAndCoupon(OrderModel orderModel, int orderWt, boolean newGetBlListUseStatus)
			throws Exception, CommCustomException, NumberFormatException;
	
	/**
     * <pre>
     * 처리내용: 권역 중분류로 조회된 배송 요율에 따른 배송비 값과 마지막 서비스 구분 코드를 반환한다.
     * </pre>
     * @date 2021. 11. 12.
     * @author srec0049
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2021. 11. 12.            srec0049            최초작성
     * 2023. 11. 20.			srec0053			프로젝트 이관
     * ------------------------------------------------
     * @param orderModel
     * @return
     * @throws Exception
     */
	public HashMap<String, Object> getCheckDataDlvyTariff(OrderModel orderModel, int orderWt, boolean newGetBlListUseStatus) throws CommCustomException, Exception;
	
	/**
     *  배송 요율 조회를 위한 기본조건 설정
     *  주문 금속 코드에 따라 VHCLE_TON_CODE(차량 톤 코드)를 상이하게 지정해줘야 함
     *
     *  1. NI(니켈), SN(주석) 주문인 경우
     *     NI(니켈): 6[5MT-05000]/12[11MT-11000]/18[18MT-18000]/24[25MT-25000]
     *
     *  2. 그 외 금속
     *     기본값: 25[25MT-25000]
     * </pre>
     * @date 2023. 7. 31.
     * @author srec0066
     * @history
     * ------------------------------------------------
     * 변경일                  작성자             변경내용
     * ------------------------------------------------
     * 2023.  8. 10.			srec0066			최초작성
     * 2023. 11. 20.			srec0053			프로젝트 이관
     * ------------------------------------------------
     * @param orderModel
     * @throws Exception
     */
	public void setDlvyTariffBaseInfo(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 배송 요율 조회
	 * </pre>
	 * @date 2023. 11. 20.
	 * @author srec0053
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 20.			srec0053			프로젝트 이관
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> selectDlvyTariffInfo(OrderModel orderModel) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 중량 변동 가져오기
	 * </pre>
	 * @date 2022. 1. 14.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022.  1. 14.			srec0049			최초작성
	 * 2023. 11. 20.			srec0053			프로젝트 이관
	 * ------------------------------------------------
	 * @param orderModel
	 * @return
	 * @throws Exception
	 */
	double getWtChange(OrderModel orderModel) throws CommCustomException, Exception;

	/**
	 /**
     * <pre>
     * 처리내용: 쿠폰 사용여부, 타입에 따라 금액 계산 로직 수행
     * </pre>
     * @date 2023. 08. 02.
     * @auther sumin
     * @history
     * -----------------------------------------------
     * 변경일                  작성자             변경내용
     * -----------------------------------------------
     * 2022. 12. 27.            chajeeman           최초작성
     * 2023. 08. 02.            sumin               수정
     * 2023. 11. 20.            srec0053            프로젝트 이관
     * -----------------------------------------------
     * @param orderModel
     * @param orderWt
     * @throws CommCustomException
     * @throws Exception
     */
	public CouponVO couponUse(OrderModel orderModel, int orderWt, boolean newGetBlListUseStatus) throws CommCustomException, Exception;

	/**
     * <pre>
     * 처리내용: 사용쿠폰 리스트 조회
     * </pre>
     * @date 2023. 08. 02.
     * @auther sumin
     * @history
     * -----------------------------------------------
     * 변경일                  작성자             변경내용
     * -----------------------------------------------
     * 2023. 08. 02.            sumin               최초작성
     * 2023. 11. 20.            srec0053            프로젝트 이관
     * -----------------------------------------------
     * @param orderModel
     * @param orderWt
     * @throws CommCustomException
     * @throws Exception
     */
	public void couponSelectList(OrderModel orderModel, int orderWt) throws CommCustomException, Exception;
}
