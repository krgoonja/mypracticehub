package com.sorincorp.comm.iseco.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class IsecoCommVO implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = -3090712728135697427L;

	/**
	 *
	 */
	private int isecoSleClSn;
	/**
	 * 판매방식코드
	 */
	private String sleMthdCode;
	/**
	 * 판매방식코드명
	 */
	private String sleMthdCodeNm;
	/**
	 * 금속분류코드
	 */
	private String metalClCode;
	/**
	 * 금속분류코드명
	 */
	private String metalClCodeNm;
	/**
	 * 아이템코드
	 */
	private String itmCode;
	/**
	 * 상품명
	 */
	private String goodsNm;
	/**
	 * 전시상품명
	 */
	private String dspyGoodsNm;
	/**
	 * 아이템 순번
	 */
	private int itmSn;
	/**
	 * 대분류권역코드
	 */
	private String dstrctLclsfCode;
	/**
	 * 대분류권역코드명
	 */
	private String dstrctLclsfCodeNm;
	/**
	 * 브랜드그룹코드
	 */
	private String brandGroupCode;
	/**
	 * 브랜드그룹코드명
	 */
	private String brandGroupCodeNm;
	/**
	 * 브랜드코드
	 */
	private String brandCode;
	/**
	 * 브랜드코드명
	 */
	private String brandNm;
	/**
	 * 금속코드
	 */
	private String metalCode;
	/**
	 * 금속코드명
	 */
	private String metalCodeNm;
	/**
	 * 조회구분코드 01:금속분류, 02:아이템, 03:대분류권역, 04:브랜드그룹, 05:브랜드
	 */
	private String srhGubunCode;

	/**
	 * 업체번호
	 */
	private String entrpsNo;

	/**
	 * 선물처리여부
	 */
	private String ftrsProcessAt;

}
