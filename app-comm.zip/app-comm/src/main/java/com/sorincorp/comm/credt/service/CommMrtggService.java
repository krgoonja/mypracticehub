package com.sorincorp.comm.credt.service;

import com.sorincorp.comm.credt.model.CredtCdtlnInfoVO;

/**
 * CommMrtggService.java
 * B2B 담보 보증 Service 인터페이스
 * @version
 * @since 2022. 8. 8.
 * @author srec0049
 */
public interface CommMrtggService {
	/**
	 * <pre>
	 * 여신 정보(금리 정보, 패널티 정보, 여신 증권 발급 수수료 정보) 가져오기
	 * : 여신 금리 정보(CD금리, 케이지트레이딩 가산금리, 연간뱅킹데이, CD 금리 사용 여부, 담보보증 무이자 일수)
	 * : CD금리는 CD 금리 사용 여부에 따라 미사용(N)일 경우 0으로 반환한다
	 * : 여신 패널티 정보(여신관리 패널티 연체 건수, 여신관리 패널티 사고 건수)
	 * : 여신 증권 발급 수수료 정보(전자상거래보증 증권발급 수수료 보상 비율, 전자상거래보증 증권발급 수수료 보상 건당 인정 비율)
	 * CD금리, 케이지트레이딩 가산금리, 연간뱅킹데이는 값이 0이 아닌 최근 적용일자의 데이터로 가져온다, 그래도 값이 없으면 0
	 * 여신관리 패널티 연체 건수, 여신관리 패널티 사고 건수, 전자상거래보증 증권발급 수수료 보상 비율, 전자상거래보증 증권발급 수수료 보상 건당 인정 비율는 값이 없으면 0
	 * CD금리, 케이지트레이딩 가산금리는 0값 허용, 연간뱅킹데이는 0인 경우를 체크해야한다.
	 * </pre>
	 * @date 2022. 8. 8.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 8.			srec0049			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public CredtCdtlnInfoVO getCredtCdtlnInfo() throws Exception;
}
