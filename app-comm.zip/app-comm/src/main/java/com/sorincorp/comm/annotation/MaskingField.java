package com.sorincorp.comm.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 
 * MaskingField.java
 * @version
 * @since 2021. 8. 6.
 * @author srec0012
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface MaskingField {
	public MaskingType value() default MaskingType.NONE;
	
	enum MaskingType{
		ENCRYPT,
		EMAIL,
		NONE;
	}
	
}
