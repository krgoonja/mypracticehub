package com.sorincorp.comm.pcInfo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class PrPremiumSelVO implements Serializable {

	private static final long serialVersionUID = 2299162866199346113L;
	
	/**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 판매 가격 실시간 순번
    */
    private String slePcRltmSn;
    /**
     * 시작 가격
    */
    private long beginPc;
    /**
     * 종료 가격
    */
    private long endPc;
    /**
     * 최고 가격
    */
    private long topPc;
    /**
     * 최저 가격
    */
    private long lwetPc;
    /**
     * 전일 종가
     */
    private long pastEndPc;
    /**
     * 대비 가격
    */
    private long versusPc;
    /**
     * 대비 비율
    */
    private java.math.BigDecimal versusRate;
    /**
     * LME 가격 실시간 순번
    */
    private String lmePcRltmSn;
    /**
     * 환율 가격 실시간 순번
    */
    private String ehgtPcRltmSn;
    /**
     * 실제 종료 가격(프리미엄 제외)
    */
    private long realEndPc;
   
}
