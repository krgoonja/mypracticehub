package com.sorincorp.comm.message.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.message.model.MailVO;

/**
 * MailMapper.java
 * @version
 * @since 2021. 6. 21.
 * @author srec0042
 */
public interface MailMapper {
	public int selectMailHistoryTable(Map<String, Object> mailVO) throws Exception;

	//mailNo 시퀀스 조회
	public int selectMailNoSeq() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: mailReceiverNoSeq 시퀀스 조회
	 * </pre>
	 * @date 2022. 12. 15.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 15.			srec0049			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public int selectMailReceiverNoSeq() throws Exception;
	
	//템플릿 조회
	public MailVO selectMailTmpt(int mailTmptSeq) throws Exception;
	
//	//이메일(내용 반복) 템플릿 조회, 20220622 추가, 20221219 제거(필요없음)
//	public MailVO selectMailRepitTmpt(int mailTmptSeq) throws Exception;

	//회원_업체 정보 기본 테이블의 구매담당자 이메일 조회, 20220120 추가
	public String selectPurchschargerEmail(MailVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 공통_SMS 발송 그룹 기본 테이블의 발송그룹코드에 해당하는 내부사용자 회사 이메일 리스트 조회
	 * </pre>
	 * @date 2022. 12. 19.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 19.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param sndngGroupCode
	 * @return
	 * @throws Exception
	 */
	public List<String> selectMailReceiverList(MailVO vo) throws Exception;
	
	//메일 전송(Receiver), 뉴스레터 수신자(OP_NSLT_RCVER) 
	public int insertMail(MailVO vo) throws Exception;
	
	//메일 전송(History), 뉴스레터 발신자(OP_NSLT_SNDNG)
	public int insertHistory(MailVO vo) throws Exception;
	
	//운영 - 메일 히스토리 저장
	public int insertOpMailSendHistory(MailVO vo) throws Exception; 

//	//이메일 수신자 번호 조회
//	public int selectMailReceiverNo(MailVO vo) throws Exception;
	
	// 회원 권한_참조1 : MBER_SE_CODE 
	public String selectMailReceiveAt(MailVO vo) throws Exception; 

}
