package com.sorincorp.comm.btb.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.btb.mapper.BtoBApiMapper;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BtoBApiServiceImpl implements BtoBApiService{
	
	@Autowired
	private BtoBApiMapper btoBApiMapper;

	@Override
	public void insertBtbLog(BtoBInrecfcLogVO btbLogVo) throws Exception {
		btoBApiMapper.insertBtbLog(btbLogVo);
	}

	@Override
	public void updateBtbLog(BtoBInrecfcLogVO btbLogVo) throws Exception {
		btoBApiMapper.updateBtbLog(btbLogVo);
	}



}
