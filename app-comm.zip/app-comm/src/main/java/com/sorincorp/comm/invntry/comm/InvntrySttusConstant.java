package com.sorincorp.comm.invntry.comm;

/**
 * InvntrySttusConstant.java
 * 재고 현황 공통 상수 클래스
 * @version
 * @since 2023. 7. 10.
 * @author srec0066
 */
public class InvntrySttusConstant {

	/** 실시간 재고 갱신 Redis Publish 채널 URL*/
	public static final String INVNTRY_URI = "/invntry";

	/** 실시간 재고 조회 대상 금속 리스트 */
	public static final String[] METAL_CODE_LIST = {"1", "2", "5", "7", "8", "9"};

	/** 브랜드 무관 코드 */
	public static final String NO_BRAND = "0000000000";
}
