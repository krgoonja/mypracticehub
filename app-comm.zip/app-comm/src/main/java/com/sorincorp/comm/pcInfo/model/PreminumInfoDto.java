package com.sorincorp.comm.pcInfo.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * PreminumSelVO.java
 * @version
 * @since 2021. 11. 15.
 * @author srec0008
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class PreminumInfoDto extends CommonVO {

	private static final long serialVersionUID = 1L;

	/**
	 * 현재영업 시작일시
	 */
	private String stdDt;
	/**
	 * 금속코드
	 */
	private String metalCode;
	/**
	 * 금속분류코드
	 */
	private String metalClCode;
	/**
	 * 아이탬 순번
	 */
	private int itmSn;
	/**
	 * 권역 대분류 코드
	 */
	private String dstrctLclsfCode;
	/**
	 * 브랜드 그룹 코드
	 */
	private String brandGroupCode;
	/**
	 * 브랜드 코드
	 */
	private String brandCode;
	private long versusPc;
	private java.math.BigDecimal versusRate;
	/**
	 * 적용 시작 시간
	 */
	private String validBeginDt;
	/**
	 * 적용 종료 시간
	 */
	private String validEndDt;
	/**
	 * 판매방식 
	 */
	private String sleMthdCode;
}
