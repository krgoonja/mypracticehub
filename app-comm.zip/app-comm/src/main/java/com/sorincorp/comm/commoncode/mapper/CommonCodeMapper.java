package com.sorincorp.comm.commoncode.mapper;

import java.util.List;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;

public interface CommonCodeMapper {
	/**
	 * <pre>
	 * 공통 코드 Cache(codeCache)에 넣기 위해 모든 공통코드를 가져온다.
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 15.			srec0012			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	List<CommonCodeVO> selectAllCommonCodes() throws Exception;
	
	/**
	 * <pre>
	 * 공통 코드 Cache(codeCache)에 넣기 위해 모든 공통코드를 가져온다.
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 15.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @return
	 * @throws Exception
	 */
	List<CommonCodeVO> selectCommonCodesByMain(String mainCode) throws Exception;
}
