package com.sorincorp.comm.pcInfo.model;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class PrSelVO implements Serializable{
    
	private static final long serialVersionUID = 2849004139164064398L;

    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 권역 대분류 코드
    */
    private String dstrctLclsfCode;
    /**
     * 권역 대분류 이름
     */
    private String dstrctLclsfName;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 코드
    */
    private String brandCode;
    /**
     * 발생 일자
    */
    private String occrrncDe;
    /**
     * 발생 시간
    */
    private String occrrncTime;
    /**
     * 발생 순번
    */
    private String occrrncSn;
    /**
     * 판매 가격 실시간 순번
    */
    private String slePcRltmSn;
    /**
     * 판매 가격 일 순번
    */
    private String slePcDeSn;
    /**
     * 발생 년주
    */
    private String occrrncYyweek;
    /**
     * 판매 가격 년 주 순번
    */
    private String slePcYyWeekSn;
    /**
     * 발생 년월
    */
    private String occrrncYm;
    /**
     * 판매 가격 년 월 순번
    */
    private String slePcYyMtSn;
    /**
     * 발생 분기
    */
    private String occrrncQu;
    /**
     * 판매 가격 년 분기 순번
    */
    private String slePcYyQuSn;
    /**
     * 시작 가격
    */
    private long beginPc;
    /**
     * 종료 가격
    */
    private long endPc;
    /**
     * 최고 가격
    */
    private long topPc;
    /**
     * 최저 가격
    */
    private long lwetPc;
    /**
     * 시작 가격(프리미엄x)
     */
    private long nonPremiumBeginPc;
    /**
     * 종료 가격(프리미엄x)
     */
    private long nonPremiumEndPc;
    /**
     * 최고 가격(프리미엄x)
     */
    private long nonPremiumTopPc;
    /**
     * 최저 가격(프리미엄x)
     */
    private long nonPremiumLwetPc;
    /**
     * 3개월 LME 가격
    */
    private java.math.BigDecimal threemonthLmePc;
    /**
     * LME 가격
    */
    private java.math.BigDecimal lmePc;
    /**
     * LME 정산 가격
    */
    private java.math.BigDecimal lmeExcclcPc;
    /**
     * 환율 가격
    */
    private java.math.BigDecimal ehgtPc;
    /**
     * 프리미엄 가격
    */
    private long premiumPc;
    /**
     * LME 가격 실시간 순번
    */
    private String lmePcRltmSn;
    /**
     * 환율 가격 실시간 순번
    */
    private String ehgtPcRltmSn;
    /**
     * 프리미엄 아이디
    */
    private String premiumId;
    /**
     * 프리미엄 번호
    */
    private String premiumNo;
    /**
     * LME 조정 계수
    */
    private java.math.BigDecimal lmeMdatCffcnt;
    /**
     * FX 조정 계수
    */
    private java.math.BigDecimal fxMdatCffcnt;
    /**
     * 거래 수량
    */
    private long delngQy;
    /**
     * 누적 거래 수량
    */
    private long accmltDelngQy;
    /**
     * 전일 종가
     */
    private long pastEndPc;
    /**
     * 대비 가격
    */
    private long versusPc;
    /**
     * 대비 비율
    */
    private java.math.BigDecimal versusRate;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
    /**
     * 월 누적 평균 가격
    */
    private String avgSelPc;
    /**
     * LME(CSP) 누적 평균 가격
     */
    private String accmltLmeCsp;
    /**
     * 환율(최초매매) 누적 가격
     */
    private String accmltUsdCvtrate;
    
    /** 금속 코드 리스트*/
	private List<CommSelMetalVO> selMetalCodeList;
}
