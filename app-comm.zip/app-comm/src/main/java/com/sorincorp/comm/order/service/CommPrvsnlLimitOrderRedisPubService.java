package com.sorincorp.comm.order.service;

/**
 * CommPrvsnlLimitOrderRedisPubService.java
 * 가단가 지정가 주문 Redis Publish 공통 Service 인터페이스
 *
 * @version
 * @since 2024. 9. 11.
 * @author srec0066
 */
public interface CommPrvsnlLimitOrderRedisPubService {

	/**
	 * <pre>
	 * 처리내용: LME/KRW - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
	 * </pre>
	 * @date 2024. 9. 11.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 11.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param limitOrderNo
	 * @param intrfcSttusCode : 인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제]
	 * @throws Exception
	 */
	public void prvsnlLimitOrderMsgLmePublish(String limitOrderNo, String intrfcSttusCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: FX - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
	 * </pre>
	 * @date 2024. 9. 11.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 11.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param limitOrderNo
	 * @param intrfcSttusCode : 인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제]
	 * @throws Exception
	 */
	public void prvsnlLimitOrderMsgFxPublish(String limitOrderNo, String intrfcSttusCode) throws Exception;

}
