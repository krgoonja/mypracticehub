package com.sorincorp.comm.mbLog.mapper;

import com.sorincorp.comm.mbLog.model.MbLogVO;

public interface MbLogMapper {

	int insertMbEntrpsInfoBasHst(String entrpsNo) throws Exception;

	int insertMbMberInfoBasHst(MbLogVO vo) throws Exception;

}
