package com.sorincorp.comm.order.service;

import java.util.List;

import com.sorincorp.comm.order.model.CnCntrctOrderBasVO;
import com.sorincorp.comm.order.model.OrOrderAvrgpcDtlVO;

/**
 * CommAvrgpcService.java
 * 평균가 주문 공통 Service 인터페이스
 * @version
 * @since 2023. 8. 28.
 * @author srec0066
 */
public interface CommAvrgpcOrderService {

	/**
	 * <pre>
	 * 처리내용: 계약_계약 발주 기본 조회
	 * </pre>
	 * @date 2023. 10. 27.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 27.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param cntrctOrderNo
	 * @return
	 * @throws Exception
	 */
	public CnCntrctOrderBasVO selectCnCntrctOrderBas(String cntrctOrderNo) throws Exception;

	/**
	 * <pre>
	 * 누적 평균 가격 목록 조회 (이전 월 부터 지정한 개수 만큼)
	 * </pre>
	 * @date 2023. 10. 27.
	 * @author srec0066
	 * @param cntrctOrderNo
	 * @param cnt
	 * @return
	 * @throws Exception
	 */
	List<OrOrderAvrgpcDtlVO> selectAccmltAvrgpcListTopCnt(String cntrctOrderNo, int cnt) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 누적 평균 가격 목록 조회
	 * </pre>
	 * @date 2023. 10. 27.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 10. 27.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param cnCntrctOrderBasVO
	 * @return
	 * @throws Exception
	 */
	public List<OrOrderAvrgpcDtlVO> selectAccmltAvrgpcList(String cntrctOrderNo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 평균 LME, 환율 데이터 조회
	 * </pre>
	 * @date 2023. 11. 14.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param cnCntrctOrderBasVO
	 * @return
	 * @throws Exception
	 */
	public OrOrderAvrgpcDtlVO selectPrevBsnDeAvrgpc(CnCntrctOrderBasVO cnCntrctOrderBasVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 주문_주문 평균가 상세 등록
	 * </pre>
	 * @date 2023. 11. 14.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 14.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orOrderAvrgpcDtlVO
	 * @throws Exception
	 */
	public void insertOrOrderAvrgpcDtl(OrOrderAvrgpcDtlVO orOrderAvrgpcDtlVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 평균가 확정 단가 여부 세팅: [Y:확정가, N:가단가]
	 * </pre>
	 * @date 2023. 11. 10.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 10.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param cntrctInfo
	 */
	public void setAvrgpcDcsnUntpcAt(CnCntrctOrderBasVO cnCntrctOrderBasVO) throws Exception;

	/**
	 * <pre>
	 * LME CSP 가격 평균 값 구하기
	 * </pre>
	 * @date 2023. 10. 30.
	 * @author srec0051
	 * @param list
	 * @return
	 */
	public double getAveragingLmeCsp(List<OrOrderAvrgpcDtlVO> list);

	/**
	 * <pre>
	 * 달러환산률 평균 값 구하기
	 * </pre>
	 * @date 2023. 10. 30.
	 * @author srec0051
	 * @param list
	 * @return
	 */
	public double getAveragingUsdCvtrate(List<OrOrderAvrgpcDtlVO> list);

	/**
	 * <pre>
	 * 처리내용: 평균가 주문일 경우, 주문번호/계약정보 리턴
	 * </pre>
	 * @date 2023. 11. 29.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 29.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	public String getOrderInfoString(String orderNo, String cntrctOrderNo);

	/**
	 * <pre>
	 * 처리내용: 평균가 주문일 경우, 중량정산/단가정산 정보를 리턴
	 * </pre>
	 * @date 2023. 11. 29.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 29.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	public String getExcclcInfoString(String orderNo);

}