package com.sorincorp.comm.bsnInfo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class BsnManageVO implements Serializable{
    
	private static final long serialVersionUID = 2849004139164064398L;

    /**
     * 적용 일자
    */
    private String applcDe;
    /**
     * 실시간 영업 여부
    */
    private String rltmBsnAt;
    /**
     * 고정가 영업 여부
    */
    private String hghnetprcBsnAt;
    /**
     * 실시간 시작 시간
    */
    private String rltmBeginTime;
    /**
     * 실시간 종료 시간
    */
    private String rltmEndTime;
    /**
     * 고정가 시작 시간
    */
    private String hghnetprcBeginTime;
    /**
     * 고정가 종료 시간
    */
    private String hghnetprcEndTime;
    /**
     * 사이트 일요일 영업 여부
    */
    private String siteSunBsnAt;
    /**
     * 사이트 월요일 영업 여부
    */
    private String siteMonBsnAt;
    /**
     * 사이트 화요일 영업 여부
    */
    private String siteTuesBsnAt;
    /**
     * 사이트 수요일 영업 여부
    */
    private String siteWedBsnAt;
    /**
     * 사이트 목요일 영업 여부
    */
    private String siteThurBsnAt;
    /**
     * 사이트 금요일 영업 여부
    */
    private String siteFriBsnAt;
    /**
     * 사이트 토요일 영업 여부
    */
    private String siteSatBsnAt;
    /**
     * 물류 일요일 영업 여부
    */
    private String lgistSunBsnAt;
    /**
     * 물류 월요일 영업 여부
    */
    private String lgistMonBsnAt;
    /**
     * 물류 화요일 영업 여부
    */
    private String lgistTuesBsnAt;
    /**
     * 물류 수요일 영업 여부
    */
    private String lgistWedBsnAt;
    /**
     * 물류 목요일 영업 여부
    */
    private String lgistThurBsnAt;
    /**
     * 물류 금요일 영업 여부
    */
    private String lgistFriBsnAt;
    /**
     * 물류 토요일 영업 여부
    */
    private String lgistSatBsnAt;
    /**
     * 선물 수수료 비용 비율
    */
    private java.math.BigDecimal ftrsFeeCtRate;
    /**
     * 이월렛 입금 수수료
    */
    private long ewalletRcpmnyFee;
    /**
     * 이월렛 출금 수수료
    */
    private long ewalletDefrayFee;
    /**
     * LME 조정 계수 금액
    */
    //private java.math.BigDecimal lmeMdatCffcntAmount;
    /**
     * 환율 조정 계수 금액
    */
    //private java.math.BigDecimal ehgtMdatCffcntAmount;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
    
}
