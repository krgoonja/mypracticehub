package com.sorincorp.comm.itemprice.model;

import java.math.BigDecimal;
import java.util.Map;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ItemPriceMatchingBlInfoVO extends CommonVO {

	private static final long serialVersionUID = 6882956165304862133L;

	/******  JAVA VO CREATE : IT_BL_INFO_BAS(상품_BL 정보 기본)                                                                              ******/
    /**       * BL 번호      */      private String blNo;
    /**       * 창고 코드      */      private String wrhousCode;
    /**       * 권역 대분류 코드      */      private String dstrctLclsfCode;
    /**       * 권역 중분류 코드      */      private String dstrctMlsfcCode;
    /**       * 창고 CELL 위치      */      private String wrhousCellLc;
    /**       * 금속 코드      */      private String metalCode;
    /**       * 아이템 코드      */      private String itmCode;
    /**       * 브랜드 코드      */      private String brandCode;
    /**       * 제품 명      */      private String prductNm;
    /**       * 보관료      */      private java.math.BigDecimal chcy;
    /**       * 보관 일 수      */      private int cstdyDeCo;
    /**       * 기초 입고 재고      */      private java.math.BigDecimal bsisWrhousngInvntry;
    /**       * 기초 입고 번들 재고      */      private int bsisWrhousngBundleInvntry;
    /**       * 기초 악성 불량 재고      */      private java.math.BigDecimal bsisMaliciousBadnInvntry;
    /**       * 기초 악성 불량 번들 재고      */      private int bsisMaliciousBadnBundleInvntry;
    /**       * 기초 악성 반출 재고            private java.math.BigDecimal bsisMaliciousTkoutInvntry;*/
    /**       * 기초 악성 반출 번들 재고            private int bsisMaliciousTkoutBundleInvntry;*/
    /**       * 기초 재고      */      private java.math.BigDecimal bsisInvntry;
    /**       * 기초 번들 재고      */      private int bsisBundleInvntry;
    /**       * 판매 설정 번들 수      */      private int sleSetupBundleCo;
    /**       * 판매 설정 중량      */      private java.math.BigDecimal sleSetupWt;
    /**       * 판매 재고 미판매 잔량      */      private java.math.BigDecimal sleInvntryUnsleBnt;
    /**       * 판매 재고 미판매 번들 잔량      */      private int sleInvntryUnsleBundleBnt;
    /**       * EC 판매 완료 재고      */      private java.math.BigDecimal ecSleComptInvntry;
    /**       * EC 판매 완료 번들 재고      */      private int ecSleComptBundleInvntry;
    /**       * EC 교환 주문 재고      */      private java.math.BigDecimal ecExchngOrderInvntry;
    /**       * EC 교환 주문 번들 재고      */      private int ecExchngOrderBundleInvntry;
    /**       * EC 출고 재고      */      private java.math.BigDecimal ecDlivyInvntry;
    /**       * EC 출고 번들 재고      */      private int ecDlivyBundleInvntry;
    /**       * EC 미출고 재고      */      private java.math.BigDecimal ecNootgInvntry;
    /**       * EC 미출고 번들 재고      */      private int ecNootgBundleInvntry;
    /**       * 창고 미출고 재고      */      private java.math.BigDecimal wrhousNootgInvntry;
    /**       * 창고 미출고 번들 재고      */      private int wrhousNootgBundleInvntry;
    /**       * 창고 판매 미설정 재고      */      private java.math.BigDecimal wrhousSleUnsetupInvntry;
    /**       * 창고 판매 미설정 번들 재고      */      private int wrhousSleUnsetupBundleInvntry;
    /**       * 기말 재고      */      private java.math.BigDecimal trmendInvntry;
    /**       * 기말 번들 재고      */      private int trmendBundleInvntry;
    /**       * 입고 일자      */      private java.sql.Date wrhousngDe;
    /**       * 통관 일자      */      private java.sql.Date entrDe;
    /**       * 도착 예정 일시      */      private java.sql.Timestamp arvlPrearngeDt;
    /**       * NET 중량      */      private java.math.BigDecimal netWt;
    /**       * GROSS 중량      */      private java.math.BigDecimal grossWt;
    /**       * NET 평균 중량    */        private java.math.BigDecimal netAvrgWt;
    /**       * LOT 수량      */      private int lotQy;
    /**       * 판매 상태 코드      */      private String sleSttusCode;
    /**       * 구매 주문 번호      */      private String purchsOrderNo;
    /**       * 구매 라인 번호      */      private String purchsLineNo;
    /**       * 화물 관리 번호      */      private String frghtManageNo;
    /**       * 입고 구분 코드      */      private String wrhousngSeCode;
    /**       * 삭제 여부      */      private String deleteAt;
    /**       * 삭제 일시      */      private java.sql.Timestamp deleteDt;
    /**       * 최초 등록자 아이디      */      private String frstRegisterId;
    /**       * 최초 등록 일시      */      private java.sql.Timestamp frstRegistDt;
    /**       * 최종 변경자 아이디      */      private String lastChangerId;
    /**       * 최종 변경 일시      */      private java.sql.Timestamp lastChangeDt;
    /**       * 입고 예정 재고 여부      */      private String wrhousngPrearngeInvntryAt;
    /**       * 상품명      */      private String goodsNm;
    /**       * 판매단위코드      */      private String sleUnitCode;
    /**       * 아이템명      */       private String itmPrdlstKorean;
    /**       * 브랜드그룹코드      */      private String brandGroupCode;
    /**       * 브랜드명      */      private String brandNm;
    /**       * 우선순위 IT_BRAND_INFO_BAS */  	private int itmSn;
    /**       * 우선순위 IT_BRAND_INFO_BAS */ 		private int priorRank;
    /**       * 계약서 시작 허용 중량 비율 */		private int ctrtcBeginPermWtRate;
    /**       * 계약서 종료 혀용 중량 비율 */		private int ctrtcEndPermWtRate;

    /**       * 각 중량에 맞는 계산값들 */ private Map<BigDecimal, ItemPriceMatchingWeightCalculateValuesVO> weightMappingCalculateValues;

    /**       * 찾은 기준 중량 */							private BigDecimal matchedOrderedBnt;
    /**       * 중량에 이론중량이 계산되어 찾는 기준 중량 */		private BigDecimal matchedSleInvntryUnsleBnt;
    /**       * 중량에 이론중량이 계산되어 찾는 기준 번들 */		private BigDecimal matchedSleInvntryUnsleBundleBnt;

    /**       * 실제 찾은 기준 중량 */						private BigDecimal realMatchedOrderedBnt;
    /**       * 실제 중량에 이론중량이 계산되어 찾는 기준 중량 */	private BigDecimal realMatchedSleInvntryUnsleBnt;
    /**       * 실제 중량에 이론중량이 계산되어 찾는 기준 번들 */	private BigDecimal realMatchedSleInvntryUnsleBundleBnt;
    /**       * 실제 재고 변경 확인 */	private boolean isInvntryUdt;
    /**       * 최적BL 실재고중량      */      	private BigDecimal orderWeight = BigDecimal.ZERO;
    /**       * 판매 가능일 			   */	private String slePossde;
 	/**       * 브랜드별 중량합계 (실재고/가재고 포함) */		private BigDecimal sumSleInvntryUnsleBundleBnt;
 	/** 	  * 선물잔량 */		private int remainQy;
 	/**       * 최적BL재고 탐색후 잔여중량		*/	private BigDecimal leftOverWeight = BigDecimal.ZERO;
 	/**       * 최적BL재고 탐색후 잔여중량 유무구분		*/	private Boolean leftOverExistYn = false;
 	/**       * 재고 할당 번호 			   */	private String invntryAsgnNo;
 	/**       * 배송 요청일 조정 일자		*/	private String dlvyRqestdeAdjust;

 	/**       * 추가 할인   */    				   private long rmndrDscnt;
 	/**       * 소량 판매 설정 중량    */    		   private BigDecimal smlqySleSetupWt;
 	/**       * 소량 판매 설정 번들 수    */    	   private int smlqySleSetupBundleCo;
 	/**       * 소량 EC 판매 완료 재고    */   	   private BigDecimal smlqyEcSleComptInvntry;
 	/**       * 소량 EC 판매 완료 번들 재고    */     private int smlqyEcSleComptBundleInvntry;
 	/**       * 소량 판매 재고 미판매 잔량    */       private BigDecimal smlqySleInvntryUnsleBnt;
 	/**       * 소량 판매 재고 미판매 번들 잔량    */    private int smlqySleInvntryUnsleBundleBnt;
 	/**       * 소량 판매 선물 여부      */      private String smlqySleFtrsAt;

 	/**	 	  * 창고 명(물류 센터)		 */ 		private String wrhousNm;

	/** 창고 우선순위 */
	int priorRankForWrhousCode;
}