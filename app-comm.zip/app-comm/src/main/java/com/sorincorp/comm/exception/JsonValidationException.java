package com.sorincorp.comm.exception;

import org.springframework.validation.Errors;

/**
 * Json Validation 오류 시 발생하는 사용자 정의 Exception
 * JsonValidationException.java
 * @version
 * @since 2021. 6. 4.
 * @author srec0012
 */
public class JsonValidationException extends RuntimeException{
	private static final long serialVersionUID = 7358544551499693866L;
	private Errors errors;
	
	public JsonValidationException(Errors errors) {
		super();
		this.errors = errors;
	}
	
	public JsonValidationException(String message, Errors errors) {
		super(message);
		this.errors = errors;
	}
	
	public Errors getErros() {
		return errors;
	}
}
