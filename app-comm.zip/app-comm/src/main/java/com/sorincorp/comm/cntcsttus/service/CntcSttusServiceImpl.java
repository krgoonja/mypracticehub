package com.sorincorp.comm.cntcsttus.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.cntcsttus.mapper.CntcSttusMapper;
import com.sorincorp.comm.cntcsttus.model.CntcSttusVO;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CntcSttusServiceImpl implements CntcSttusService{
	@Autowired
	private CntcSttusMapper cntcSttusMapper;

	/**
	 * 공통_연계 상태 기본 테이블의 상태를 update 한다.
	 */
	@Override
	public void updateCoCntcSttusBas(CntcSttusVO dataVo){
		/*
		인터페이스 구분 코드 : INTRFC_SE_CODE
		10:LME, 20:환율, 30:FS, 40:FX, 50:V/A
	   */
		try {
			String intrfcSeCode = dataVo.getIntrfcSeCode();
			if (StringUtil.isEmpty(intrfcSeCode)) {
				return;
			}

			/* 서비스 모니터링 결과 반영*/
			boolean checkResult = dataVo.isCheckResult();
			boolean checkLine = dataVo.isCheckCommnLine();
			String cntcSttusCode = "";

			if (intrfcSeCode.equals("20")) {
				cntcSttusCode = getCoCntcSttus(checkResult);
			} else if (intrfcSeCode.equals("30")) {					//선물 거래 서버(FS)
				cntcSttusCode = getCurrenFSCntcSttus(intrfcSeCode, checkResult, checkLine, dataVo.getOpertSuccesTy());
			} else if (intrfcSeCode.equals("40")) {					//선물환 거래 서버(FX)
				cntcSttusCode = getCurrenFXCntcSttus(intrfcSeCode, checkResult, checkLine);
			} else {
				cntcSttusCode = getCoCntcSttus(checkResult);
			}

			dataVo.setCntcSttusCode(cntcSttusCode);
			cntcSttusMapper.updateCoCntcSttusBas(dataVo);

		} catch (Exception e) {
			log.error("updateCoCntcSttusBas Error.", e);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 이전 연계상태 참고하여 현재 연계상태를 반환한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0032			최초작성
	 * 2023. 06. 27.		srec0070			메소드명 변경
	 * ------------------------------------------------
	 * @param preSttus
	 * @param checkResult
	 * @return
	 */
	private String getCurrenFXCntcSttus(String intrfcSeCode, boolean checkResult, boolean checkCommnLine) {
		log.debug("::: getCurrenFXCntcSttus 연계상태값 - checkResult:{}, checkCommnLine:{}, opertSuccesTy:{}", checkResult, checkCommnLine);

       /*
        * 연계상태 코드 : CNTC_STTUS_COD
        * 0	정상
		  1	실패
          2	실패 후 정상
          - 통신선 점검 작업 여부에 따라 통신선 작업인 경우 성공인 경우 2번 상태(주황) 값 유지함.
        */
		CntcSttusVO vo  = cntcSttusMapper.selectCoCntcSttusBas(intrfcSeCode);
		String preCntcSttusCode = Optional.ofNullable(vo).orElseGet(CntcSttusVO :: new).getCntcSttusCode();

		if(StringUtil.isEmpty(preCntcSttusCode)) {
			if(checkResult) {
				return "0";
			}else {
				return "1";
			}
		}else {
			if(checkResult) {
				if(preCntcSttusCode.equals("1")) {
					return "2";
				}else if(preCntcSttusCode.equals("2")) {
					if(checkCommnLine) {
						log.debug("유지...");
						return "2";
					}else {
						log.debug("성공...");
						return "0";
					}
				}else {
					return "0";
				}
			}else {
				return "1";
			}
		}
	}

	/**
	 * <pre>
	 * 처리내용: 이전 연계상태 참고하여 현재 연계상태를 반환한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0032			최초작성
	 * 2023. 06. 27.		srec0070			메소드명 변경
	 * ------------------------------------------------
	 * @param preSttus
	 * @param checkResult
	 * @return
	 */
	private String getCurrenFSCntcSttus(String intrfcSeCode, boolean checkResult , boolean checkCommnLine, int opertSuccesTy) {

		log.debug("::: getCurrenFSCntcSttus 연계상태값 - checkResult:{}, checkCommnLine:{}, opertSuccesTy:{}", checkResult, checkCommnLine, opertSuccesTy);

       /*
        * 연계상태 코드 : CNTC_STTUS_COD
        * 0	정상
		  1	실패
          2	실패 후 정상
          - 통신선 점검 작업 여부에 따라 통신선 작업인 경우 성공인 경우 2번 상태(주황) 값 유지함.
        */
		CntcSttusVO vo  = cntcSttusMapper.selectCoCntcSttusBas(intrfcSeCode);
		String preCntcSttusCode = Optional.ofNullable(vo).orElseGet(CntcSttusVO :: new).getCntcSttusCode();

		if(StringUtil.isEmpty(preCntcSttusCode)) {
			if(checkResult) {
				return "0";
			}else {
				return "1";
			}
		}else {
			if(!checkCommnLine) {
				if(checkResult) {
					if("1".equals(preCntcSttusCode)) return "2";     	  // 실패(빨강색) -> 실패후 정상(황색)
					else if("2".equals(preCntcSttusCode)) return "0";     // 실패후 정상(황색)  -> 정상(초록색)
					else return "0";     								  // 정상(초록색)  -> 정상(초록색)
				}else {
					return "1";											  // 실패(빨강색)
				}
			}else {
				if(checkResult) {
					if("1".equals(preCntcSttusCode)) return "2";     	  // 실패(빨강색) -> 실패후 정상(황색)
					else if("2".equals(preCntcSttusCode)) return "0";     // 실패후 정상(황색)  -> 정상(초록색)
					else return "0";     								  // 정상(초록색)  -> 정상(초록색)
				}else {
					if(opertSuccesTy==2) {								  // 부분성공
						if("0".equals(preCntcSttusCode))
							return "1";     	  						  // 정상(초록색) -> 실패(빨강색)
						else
							return "2";     	  						  // 실패(빨강색) -> 실패후 정상(황색)
					}else {
						return "1";										  // 실패(빨강색)
					}
				}
			}
		}
	}

	/**
	 * <pre>
	 * 처리내용: 연계상태를 반환한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param checkResult
	 * @return
	 */
	private String getCoCntcSttus(boolean checkResult) {
	       /*
	        * 연계상태 코드 : CNTC_STTUS_COD
	        * 0	정상
			  1	실패
	          2	실패 후 정상
	        */
		if(checkResult) {
			return "0";
		}else {
			return "1";
		}
	}
}
