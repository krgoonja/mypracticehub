package com.sorincorp.comm.invntry.service;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.invntry.comm.InvntrySttusConstant;
import com.sorincorp.comm.invntry.mapper.InvntrySttusMapper;
import com.sorincorp.comm.invntry.model.InvntrySttusVO;
import com.sorincorp.comm.redis.config.RedisPubSubService;

import lombok.extern.slf4j.Slf4j;

/**
 * InvntrySttusServiceImpl.java
 * 재고 현황 공통 Service 구현체 클래스
 * @version
 * @since 2023. 6. 27.
 * @author srec0066
 */
@Slf4j
@Service
public class InvntrySttusServiceImpl implements InvntrySttusService {

	/** Redis PubSub 공통 Service */
	@Autowired
	private RedisPubSubService redisPubSubService;

	/** 재고 현황 매퍼 */
	@Autowired
	private InvntrySttusMapper invntrySttusMapper;

	/** 실시간 재고 조회 대상 금속 리스트 */
	private String[] metalCodeList = InvntrySttusConstant.METAL_CODE_LIST;

	/** 실시간 재고 갱신 Redis Publish 채널 URL*/
	private String invntryUri = InvntrySttusConstant.INVNTRY_URI;

	/**
	 *	Redis에 재고 데이터 변경 메세지 발행하기
	 *
	 * - 재고 데이터에 대한 변경(CUD)이 발생하는 곳에서 해당 메소드를 호출
	 * - 메시지는 각 메탈코드별로 발행함
	 * 	 (즉, 한 화면에서 여러 메탈코드에 대한 메세지를 수신해야 한다면, 메탈코드별로 uri를 구독)
	 * - 해당 uri를 구독한 화면에서는 필요한 데이터만 추출하여 사용
	 */
	@Override
	public void invntrySttusMsgPublish() throws Exception {
		log.info(">> [invntrySttusMsgPublish] in");

		try {
			for (int i = 0; i < metalCodeList.length; i++) {
				Map<String, InvntrySttusVO> invntryData = getInvntrySttusInfoMap(metalCodeList[i]);
				log.info(">> [invntrySttusMsgPublish] invntryData : " + invntryData);

				redisPubSubService.publishMessage(invntryUri + "/" + metalCodeList[i], invntryUri + "/" + metalCodeList[i], invntryData);
			}
		} catch (Exception e) {
			log.info(">> [invntrySttusMsgPublish][redis msg publish fail] : " + ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 *	판매 중인 실시간 재고 데이터 조회(메탈코드로 조회)
	 */
	@Override
	public Map<String, InvntrySttusVO> getInvntrySttusInfoMap(String metalCode) throws Exception {
		InvntrySttusVO param = InvntrySttusVO.builder().metalCode(metalCode).build();
		return getInvntrySttusInfoMap(param);
	}

	/**
	 *	판매 중인 실시간 재고 데이터 조회
	 */
	@Override
	public Map<String, InvntrySttusVO> getInvntrySttusInfoMap(InvntrySttusVO param) throws Exception {

		Map<String, InvntrySttusVO> invntrySttusInfoMap = new HashedMap<>();

		try {
			// 1. 일반구매: BL 리스트 조회
			List<InvntrySttusVO> blList = invntrySttusMapper.selectBlInfoList(param);
			log.info(">> [InvntrySttusService][selectBlInfoList size] : " + blList.size());

			// 2. 각 그룹별 총 재고잔량 구하기
			for (InvntrySttusVO blInfo : blList) {

				// 3. 각 브랜드별 데이터 저장
				String eachBrandKey = generateKey(blInfo, null);
				InvntrySttusVO invntryVO = generateInvntrySttusVO(blInfo, null, null);

				// 3-1. 이미 해당 브랜드 KEY가 존재하는 경우
				if(invntrySttusInfoMap.containsKey(eachBrandKey)) {
					invntryVO.setTotSleInvntryUnsleBundleBnt(invntrySttusInfoMap.get(eachBrandKey).getTotSleInvntryUnsleBundleBnt() + blInfo.getSleInvntryUnsleBundleBnt());
					invntrySttusInfoMap.replace(eachBrandKey, invntryVO);
				}
				// 3-2. 해당 브랜드 KEY가 존재 하지 않는 경우
				else {
					invntryVO.setTotSleInvntryUnsleBundleBnt(blInfo.getSleInvntryUnsleBundleBnt());
					invntrySttusInfoMap.put(eachBrandKey, invntryVO);
				}

				// 4. 브랜드 무관 데이터 저장
				String noBrandKey = generateKey(blInfo, "N");
				String realNoBrandKey = noBrandKey + "_" + InvntrySttusConstant.NO_BRAND;
				InvntrySttusVO invntryVO2 = generateInvntrySttusVO(blInfo, "N", null);

				if(eachBrandKey.startsWith(noBrandKey)) {
					// 4-1. 이미 브랜드 무관 KEY가 존재하는 경우
					if(invntrySttusInfoMap.containsKey(realNoBrandKey)) {
						invntryVO2.setTotSleInvntryUnsleBundleBnt(invntrySttusInfoMap.get(realNoBrandKey).getTotSleInvntryUnsleBundleBnt() + blInfo.getSleInvntryUnsleBundleBnt());
						invntrySttusInfoMap.replace(realNoBrandKey, invntryVO2);
					}
					// 4-2. 브랜드 무관 KEY가 존재 하지 않는 경우
					else {
						invntryVO2.setTotSleInvntryUnsleBundleBnt(blInfo.getSleInvntryUnsleBundleBnt());
						invntrySttusInfoMap.put(realNoBrandKey, invntryVO2);
					}
				}
			}

			// 1-2. 소량구매: BL 리스트 조회
			List<InvntrySttusVO> smlqyPurchsBlList = invntrySttusMapper.selectSmlqyPurchsBlInfoList(param);
			log.info(">> [InvntrySttusService][selectSmlqyPurchsBlInfoList size] : " + smlqyPurchsBlList.size());

			for (InvntrySttusVO smlqyBl : smlqyPurchsBlList) {
				// BL 번호 포함한 KEY 생성 후 저장
				String blKey = generateKey(smlqyBl, null);
				smlqyBl.setTotSleInvntryUnsleBundleBnt(smlqyBl.getSleInvntryUnsleBundleBnt());
				invntrySttusInfoMap.put(blKey, smlqyBl);
			}
		} catch (Exception e) {
			log.info(">> [InvntrySttusService][getInvntrySttusInfoMap error] : " + ExceptionUtils.getStackTrace(e));
		}
		return invntrySttusInfoMap;
	}

	/**
	 *	데이터를 담을 InvntrySttusVO 생성
	 */
	private InvntrySttusVO generateInvntrySttusVO(InvntrySttusVO param, String brandYn, String blNo) {
		InvntrySttusVO returnVo = InvntrySttusVO.builder()
								.metalCode(param.getMetalCode())
								.itmSn(param.getItmSn())
								.dstrctLclsfCode(param.getDstrctLclsfCode())
								.brandGroupCode(param.getBrandGroupCode())
								.brandCode("N".equals(brandYn) ? InvntrySttusConstant.NO_BRAND : param.getBrandCode())
								.blNo(StringUtils.isNotEmpty(blNo) ? param.getBlNo() : "")
								.build();

		return returnVo;
	}

	/**
	 *	유니크한 KEY값 생성
	 */
	private String generateKey(InvntrySttusVO blInfo, String brandYn) {
		String key = blInfo.getMetalCode()
			 + "_" + blInfo.getItmSn()
			 + "_" + blInfo.getDstrctLclsfCode()
			 + "_" + blInfo.getBrandGroupCode()
			 + ("N".equals(brandYn) ? "" : "_" + blInfo.getBrandCode())
			 + (!"N".equals(brandYn) && StringUtils.equals("Y", blInfo.getSmlqyPurchsAt()) ? "_" + blInfo.getBlNo() : "");

		return key;
	}

}
