package com.sorincorp.comm.redis.config;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Service
public class RedisSubscriber implements MessageListener {	// RedisPubSubListener<String, Object>

	@Override
	public void onMessage(Message message, byte[] pattern) {
		// TODO Auto-generated method stub
		byte[] messageBody = message.getBody();
		ByteArrayInputStream in = new ByteArrayInputStream(messageBody);
		ObjectInputStream is =null;
		RedisPubSubMessage pubSubMsg = null;
		//String msgBody = (String) redisTemplate.getStringSerializer().deserialize(message.getBody()); //value에 serialize를 붙이지 않아 byte[]로 처리됨 
		try {
			is = new ObjectInputStream(in);
			pubSubMsg = (RedisPubSubMessage) is.readObject();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.error(message.toString());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			log.error(message.toString());
		}
	}

//	@Override
//	public void message(String channel, Object message) {
//		// TODO Auto-generated method stub
//		log.debug("message:"+channel);
//		log.debug(message.toString());
//	}
//
//	@Override
//	public void message(String pattern, String channel, Object message) {
//		// TODO Auto-generated method stub
//		log.debug("message pattern:"+pattern);
//	}
//
//	@Override
//	public void subscribed(String channel, long count) {
//		// TODO Auto-generated method stub
//		log.debug("subscribed:"+channel);
//	}
//
//	@Override
//	public void psubscribed(String pattern, long count) {
//		// TODO Auto-generated method stub
//		log.debug("psubscribed:"+pattern);
//	}
//
//	@Override
//	public void unsubscribed(String channel, long count) {
//		// TODO Auto-generated method stub
//		log.debug("unsubscribed:"+channel);
//	}
//
//	@Override
//	public void punsubscribed(String pattern, long count) {
//		// TODO Auto-generated method stub
//		log.debug("punsubscribed:"+pattern);
//	}
}
