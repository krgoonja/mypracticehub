package com.sorincorp.comm.kakao.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.constants.CommonConstants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class KakaoServiceImpl implements KakaoService {
//	public String getAccessToken (String authorizeCode, String redirectUrl) {
//		String access_Token = "";
//		String refresh_Token = "";
//		String reqURL = "https://kauth.kakao.com/oauth/token";
//		
//		try {
//			if ( authorizeCode != null ) {
//				URL url = new URL(reqURL);
//				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//				
//				// POST 요청을 위해 기본값이 false인 setDoOutput을 true로
//				conn.setRequestMethod("POST");
//				conn.setDoOutput(true);
//				
//				// POST 요청에 필요로 요구하는 파라미터 스트림을 통해 전송
//				BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
//				StringBuilder sb = new StringBuilder();
//				sb.append("grant_type=authorization_code");
//				sb.append("&client_id=" + CommonConstants.KAKAO_REST_API_KEY);			// 케이지트레이딩에서 발급받은 key
//				sb.append("&redirect_uri=" + redirectUrl);								// 로그인 처리 후 Redirect 경로
//				sb.append("&code=" + authorizeCode);
//				bw.write(sb.toString());
//				bw.flush();
//				
//				// 요청을 통해 얻은 JSON타입의 Response 메세지 읽어오기
//				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//				String line = "";
//				String result = "";
//				
//				while ( (line = br.readLine()) != null ) {
//					result += line;
//				}
//				
//				JSONParser parser = new JSONParser();
//				JSONObject object = (JSONObject)parser.parse(result);
//				
//				access_Token = object.get("access_token").toString();
//				refresh_Token = object.get("refresh_token").toString();
//				
//				log.debug("access_token : " + access_Token);
//				log.debug("refresh_token : " + refresh_Token);
//				
//				br.close();
//				bw.close();
//			}
//		} catch (IOException e) {
//			e.printStackTrace();
//		} catch (ParseException e) {
//			e.printStackTrace();
//		}
//		
//		return access_Token;
//    }
//	
//	public HashMap<String, Object> getUserInfo (String access_Token) throws Exception {
//		// 요청하는 클라이언트마다 가진 정보가 다를 수 있기에 HashMap타입으로 선언
//		HashMap<String, Object> userInfo = new HashMap<>();
//		String reqURL = "https://kapi.kakao.com/v2/user/me";
//		
//		try {
//			if ( access_Token != null ) {
//				URL url = new URL(reqURL);
//				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//				conn.setRequestMethod("GET");
//				
//				// 요청에 필요한 Header에 포함될 내용
//				conn.setRequestProperty("Authorization", "Bearer " + access_Token);
//				
//				int responseCode = conn.getResponseCode();
//				log.debug("responseCode : " + responseCode);
//				
//				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//				
//				String line = "";
//				String result = "";
//				
//				while ( (line = br.readLine()) != null ) {
//					result += line;
//				}
//				log.debug("response body : " + result);
//				
//				JSONParser parser = new JSONParser();
//				JSONObject object = (JSONObject)parser.parse(result);
//				
//				JSONObject properties = (JSONObject)object.get("properties");
//				JSONObject kakao_account = (JSONObject)object.get("kakao_account");
//				
//				String nickname = null;
//				if ( properties.get("nickname") != null ) {
//					nickname = properties.get("nickname").toString(); 
//				}
//				String email = null;
//				if ( kakao_account.get("email") != null ) {
//					email = kakao_account.get("email").toString();
//				}
//				String phone_number = null;
//				if ( kakao_account.get("phone_number") != null ) {
//					phone_number = kakao_account.get("phone_number").toString();
//					// +82 없애고 '10-****'를 '010-****'로 수정
//					phone_number = "0" + phone_number.substring(4);
//				}
//				
//				userInfo.put("nickname", nickname);
//				userInfo.put("email", email);
//				userInfo.put("phone_number", phone_number);
//			}
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		
//		return userInfo;
//	}
}
