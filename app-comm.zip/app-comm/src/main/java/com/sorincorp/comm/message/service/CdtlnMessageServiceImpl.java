package com.sorincorp.comm.message.service;

import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.commoncode.service.CommonCodeService;
import com.sorincorp.comm.message.mapper.CdtlnMessageMapper;
import com.sorincorp.comm.message.model.MailVO;
import com.sorincorp.comm.message.model.OrderInfoVO;
import com.sorincorp.comm.message.model.SMSVO;
import com.sorincorp.comm.order.service.CommAvrgpcOrderService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * CdtlnMessageServiceImpl.java : 여신 메세지/이메일 발송 공통서비스
 *     출고중지 및 출고중지 해제 SMS 전송 공통 서비스 추가, 2024.07.19 srec0049
 * 
 * @version
 * @since 2022. 8. 16.
 * @author srec0053
 */
@Slf4j
@Service
public class CdtlnMessageServiceImpl implements CdtlnMessageService {

	@Autowired
	private CdtlnMessageMapper cdtlnMessageMapper;

	@Autowired
	private SMSService smsService;

	@Autowired
	private MailService mailService;

	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired
	private CommAvrgpcOrderService commAvrgpcOrderService;

	/**
	 * 여신 관련 SMS 전송 공통 메소드(메세지번호 리턴)
	 * mdstrmRepySn(중도 상환 순번)이 없으면 -1 값으로 세팅
	 */
	@Override
	public int insertCdtlnSmsReturnMssageNo(String orderNo, Long mdstrmRepySn, String templateNum, String userId) {

		String mssageSndngHistNo = null;

		int result = 0;

		try {
			//여신 관련 데이터 get
			List<Map<String, String>> cdtlnDataList = getCdtlnData(orderNo, mdstrmRepySn, templateNum);

			for(Map<String, String> cdtlnData : cdtlnDataList) {
				//치환 데이터 순서를 보장하기위한 LinkedHashMap 객체 선언
				LinkedHashMap<String, String> templateData = new LinkedHashMap<>();

				//동적 템플릿 작성 및 템플릿 데이터로 세팅
				templateData.put("setleInfo", getSetleInfoDynamicTemplate(templateNum, cdtlnData));

				//동적 템플릿 세팅 이후에 나머지 데이터 세팅 (순서 중요)
				templateData.putAll(cdtlnData);
				
				//평균가 주문일 경우, 주문 정보에 계약번호 추가
				templateData.put("orderNo", commAvrgpcOrderService.getOrderInfoString(cdtlnData.get("orderNo"), null));
				// 22-10-05 : 미납대상자 송신 sms 문구 동적 할당 (증거금 일 때만)
				if(StringUtils.equals(templateNum, "67")) {	//템플릿 번호 67 : 결제 미납
					if(StringUtils.equals(cdtlnData.get("setleMthdCode"), "90")) {	//결제방식코드 90 : 증거금
						templateData.put("guidanceWords", "잔금 미변제시(5영업일 이내) 반대매매 비용 및 취소 수수료 금액을 제한 나머지금액을 반환하거나 손실금에 대한 추가 청구를 할수 있습니다.");
					} else {
						templateData.put("guidanceWords", "30일 이상의 장기간 미납 시 법적인 조치를 취할 수 있습니다. 이점 양해 부탁드립니다.");
					}
				}

				// 23-03-16 : 결제완료 sms 문구 동적 할당 (케이지크레딧)
				if(StringUtils.equals(templateNum, "68")) {	//템플릿 번호 68 : 결제 완료 처리
					if(StringUtils.equals(cdtlnData.get("setleMthdCode"), "40")) {	//40 : 여신(4010-케이지크레딧)
						templateData.put("setleWords", "결제가 완료되었습니다.");
					} else {
						templateData.put("setleWords", "잔금 결제가 완료되었습니다.");
					}
				}

				//smsvo 세팅
				SMSVO smsVo = new SMSVO();

				smsVo.setPhone(templateData.get("moblphonNo"));
				smsVo.setMberNo(templateData.get("mberNo"));
				smsVo.setMberKndSeCode(templateData.get("mberSeCode"));

				//커머스 알림 관련 세팅
				String commerceNtcnCn = null;

				switch (templateNum) {
				case "67":
					commerceNtcnCn = "[케이지트레이딩] 잔금 미납 안내";
					break;
				case "68":
					if(StringUtils.equals(cdtlnData.get("setleMthdCode"), "40")) {	//40 : 여신(4010-케이지크레딧)
						commerceNtcnCn = "[케이지트레이딩] 결제 완료 안내";
					} else {
						commerceNtcnCn = "[케이지트레이딩] 잔금 결제 완료 안내";
					}
					break;
				default:
					commerceNtcnCn = "[케이지트레이딩] 잔금 결제 안내";
					break;
				}
				smsVo.setCommerceNtcnAt("Y");
				templateData.put("commerceNtcnCn", commerceNtcnCn);

				mssageSndngHistNo = smsService.insertSMSByReturnMssageSndngHistNo(smsVo, templateData);
				result += Integer.parseInt(mssageSndngHistNo);

				//주문_미납 주문 관리 기본 Insert
				if(!StringUtils.equals("68", templateNum)) {	//템플릿 번호 68 : 결제 완료
					//userId 값이 있으면 해당값 설정, 없으면 "SYSTEM" 할당
					if(userId != null) {
						cdtlnData.put("userId", userId);
					} else {
						cdtlnData.put("userId", "SYSTEM");
					}
					cdtlnData.put("mssageSndngHistNo", mssageSndngHistNo);
					cdtlnData.put("npyProcessTyCode", "30");      /* 미납 처리 유형 코드 30: SMS */
					cdtlnData.put("processCn", "결제완료 처리 안내");

					insertNpyOrderManage(cdtlnData);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	/**
	 * <pre>
	 * 처리내용: 주문_미납 주문 관리 기본 Insert
	 * </pre>
	 * @date 2022. 9. 20.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 20.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param cdtlnData
	 * @throws Exception
	 */
	@Override
	public void insertNpyOrderManage(Map<String, String> cdtlnData) throws Exception {
		String moblphonNo = cdtlnData.get("moblphonNo");

		if (StringUtils.isNotBlank(moblphonNo)) {
			cdtlnData.put("moblphonNo",CryptoUtil.encryptAES256(moblphonNo)); // 암호화
        }

		cdtlnMessageMapper.insertNpyOrderManage(cdtlnData);
		cdtlnMessageMapper.insertNpyOrderManageHst(cdtlnData);
	}

	private List<Map<String, String>> getCdtlnData(String orderNo, Long mdstrmRepySn, String templateNum) throws Exception {
		//템플릿 데이터 select
		List<Map<String, String>> templateDataList = cdtlnMessageMapper.selectCdtlnMessageData(orderNo, mdstrmRepySn);
		for(Map<String, String> templateData : templateDataList) {
			//휴대전화번호 복호화 및 하이픈 기호 제거
			String moblphonNo = null;

			try {
				moblphonNo = StringUtil.removeFormat(CryptoUtil.decryptAES256(templateData.get("moblphonNo")));
			} catch (Exception e) {
				throw new Exception("회원 핸드폰 번호 복호화 Error");
			}

			templateData.put("moblphonNo", moblphonNo);
			templateData.put("Servicedomain", "https://m.kztraders.com");
			templateData.put("templateNum", templateNum);

			//null 데이터 빈 값으로 처리
			templateData.forEach((key, value) -> {
				if (StringUtils.isEmpty(value) || StringUtils.equals("0", value)) {
					templateData.replace(key, "");
				}
			});
		}
		return templateDataList;
	}

	private String getSetleInfoDynamicTemplate(String templateNum, Map<String, String> cdtlnData) throws Exception {
		StringBuilder sb = new StringBuilder();
		
		boolean partDlivySttus = false; // 부분 출고 상태 (true : 부분 출고중, false : 전량 출고)
		String partDlivyRepyAt = String.valueOf(cdtlnData.get("partDlivyRepyAt")); // 부분 출고 상환 여부
		
		// 전자상거래보증 또는 케이지크레딧일 경우
		// 주문 상태가 배송완료(30)가 아니고, 부분 출고 상환 여부가 Y인 주문 건은 부분 출고중
		// 부분 출고 상환 여부가 Y인데 주문 상태가 배송완료(30)이면 전량 출고
		if((StringUtils.equals("20", cdtlnData.get("setleMthdCode")) || StringUtils.equals("40", cdtlnData.get("setleMthdCode"))) 
				&& StringUtils.equals("Y", partDlivyRepyAt)) {
			partDlivySttus = true; // 부분 출고중
		}

		//기준 무관 공통으로 들어가는 결제 정보
		sb.append("결제방법 : {{payMethod}}\r\n");
		sb.append("결제단가 : {{setleUntpc}}")
		  .append((StringUtils.equals(cdtlnData.get("avrgpcDcsnUntpcAt"), "N")) ? "(가단가)": "")
		  .append(System.lineSeparator());
		sb.append("주문금액 : {{orderAmount}}\r\n");

		// 분기 기준 1. 템플릿 번호
		if(StringUtils.equals(templateNum, "68")) {	//템플릿 번호 68 : 결제 완료
			//분기 기준 2. 결제 방식 코드
			if(StringUtils.equals(cdtlnData.get("setleMthdCode"), "90")) {	// 90 : 증거금 + [증거금 || 구매자금 대출보증]
				sb.append("결제금액(1차) : {{firstSetleAmount}}\r\n");
				sb.append("결제금액(2차) : {{secondSetleAmount}}\r\n");
			} else {	 // 20 : 전자상거래보증, 40 : 여신
				// 평균가 주문인 경우
				// 24-02-19 변경사항 : 평균가 - 지정가 (0304) 주문일 경우에도 해당 로직 수행하도록 조건 변경
				// 24-09-25 변경사항 : 가단가(05) 주문일 경우에도 해당 로직 수행하도록 조건 변경
				if(StringUtils.equals("04", cdtlnData.get("sleMthdCode")) 
						|| StringUtils.equals("0104", cdtlnData.get("sleMthdDetailCode"))
						|| StringUtils.equals("0304", cdtlnData.get("sleMthdDetailCode"))
						|| StringUtils.equals("05", cdtlnData.get("sleMthdCode"))) {
					// 전자상거래보증 또는 케이지크레딧에서 부분 출고 상태가 전량 출고일 경우에만 정산 금액 보이기
					if(!partDlivySttus) {
						sb.append(commAvrgpcOrderService.getExcclcInfoString(cdtlnData.get("orderNo")) + "\r\n");
					}
				}else {
					if(StringUtils.equals("20", cdtlnData.get("setleMthdCode")) || StringUtils.equals("40", cdtlnData.get("setleMthdCode"))) {
						// 전자상거래보증 또는 케이지크레딧에서 부분 출고 상태가 전량 출고일 경우에만 정산 금액 보이기
						if(!partDlivySttus) {
							// 추가 금액이 존재할 경우
						    if(!StringUtils.equals("", cdtlnData.get("aditAmount"))) {
						    	sb.append("정산금액 : 0 (추가결제금액 : {{aditAmount}})\r\n");
						    } else {
						    	sb.append("정산금액 : {{excclcAmount}}\r\n");
						    }
						}
					} else {
						sb.append("정산금액 : {{excclcAmount}}\r\n");
					}
				}
				sb.append("결제금액 : {{firstSetleAmount}}\r\n");
			}
			
			
		} else {	//나머지 템플릿 번호 : 65, 66, 67
			// 분기 기준 2. 결제 방식 코드
			if(StringUtils.equals(cdtlnData.get("setleMthdCode"), "90")) {	// 90 : 증거금 + [증거금 || 구매자금 대출보증]
				sb.append("결제금액(1차) : {{firstSetleAmount}}\r\n");
				
				// 미 결제 금액이 존재하고 추가 금액이 존재할 경우
			    if(!StringUtils.equals("", cdtlnData.get("payAmount")) && !StringUtils.equals("", cdtlnData.get("aditAmount"))) {
			    	sb.append("결제금액(2차) : {{secondSetleAmount}}\r\n");
			    	sb.append("정산금액 : 0 (추가결제금액 : {{aditAmount}})\r\n");
			    }
			} else {	// 20 : 전자상거래보증, 40 : 여신
				// 평균가 주문인 경우
				// 24-02-19 변경사항 : 평균가 - 지정가 (0304) 주문일 경우에도 해당 로직 수행하도록 조건 변경
				// 24-09-25 변경사항 : 가단가(05) 주문일 경우에도 해당 로직 수행하도록 조건 변경
				if(StringUtils.equals("04", cdtlnData.get("sleMthdCode")) 
						|| StringUtils.equals("0104", cdtlnData.get("sleMthdDetailCode"))
						|| StringUtils.equals("0304", cdtlnData.get("sleMthdDetailCode"))
						|| StringUtils.equals("05", cdtlnData.get("sleMthdCode"))) {
					// 전자상거래보증 또는 케이지크레딧에서 부분 출고 상태가 전량 출고일 경우에만 정산 금액 보이기
					if(!partDlivySttus) {
						sb.append(commAvrgpcOrderService.getExcclcInfoString(cdtlnData.get("orderNo"))+ "\r\n");
					}
				}else {
					if(StringUtils.equals("10", cdtlnData.get("setleMthdCode")) || StringUtils.equals("20", cdtlnData.get("setleMthdCode")) 
							|| StringUtils.equals("40", cdtlnData.get("setleMthdCode"))) {
						// 전자상거래보증 또는 케이지크레딧에서 부분 출고 상태가 전량 출고일 경우에만 정산 금액 보이기
						if(!partDlivySttus) {
							// 미 결제 금액이 존재하고 추가 금액이 존재할 경우
						    if(!StringUtils.equals("", cdtlnData.get("payAmount")) && !StringUtils.equals("", cdtlnData.get("aditAmount"))) {
						    	sb.append("정산금액 : 0 (추가결제금액 : {{aditAmount}})\r\n");
						    } else {
						    	sb.append("정산금액 : {{excclcAmount}}\r\n");
						    }
						}
					} else {
						sb.append("정산금액 : {{excclcAmount}}\r\n");
					}
				}
			}

			if(StringUtils.equals(templateNum, "67")) {	//템플릿 번호 67 : 결제 미납
				sb.append("미납금액 : {{payAmount}}\r\n");
				sb.append("미납 결제예정일 : {{payDate}}\r\n");
			} else {
				sb.append("결제예정금액 : {{payAmount}}\r\n");
				sb.append("결제예정일 : {{payDate}}\r\n");
			}
		}
		
		return sb.toString();
	}

	/**
	 * 여신 관련 Mail 전송 공통 메소드(메일번호 리턴)
	 */
	@Override
	public int insertCdtlnMailSendReturnMailNo(String orderNo, String templateNum) {
		int resultMailNo = 0;
		Map<String, String> sleMthdInfo = cdtlnMessageMapper.selectSleMthdInfo(orderNo);
		// 평균가 주문인 경우, 이메일 발송 제외
		// 24-09-23 변경사항 : 가단가 주문(05)도 이메일 발송 제외되도록 조건문 수정
		if(!StringUtils.equals("04", sleMthdInfo.get("sleMthdCode")) 
				&& !StringUtils.equals("05", sleMthdInfo.get("sleMthdCode"))) {
			
			OrderInfoVO orderInfo = new OrderInfoVO();
	
	//		String sendGroup=""; //발송 대상이 일반고객인지 운영팀인지 구별한다. =>공통에서 가져오기
			String titleMsg="";  //발송 대상이 어느그룹이냐에 따라 발송 타이틀이 변경됨.
	
			List<OrderInfoVO> selectSorinCredtList = null;
	
			/*테스트용 데이터*/
			//templateNum="57";
			//orderNo ="20221207-S01250"; // 40이 아닌경우
			//orderNo ="20221221-S01340"; //40인 경우
	
			try {
				switch (templateNum) {
				case "57": //잔금 결제 완료
					orderInfo = cdtlnMessageMapper.selectCdtlnEmailData(orderNo);
					break;
	
				case "58":
				case "59":
				case "60":
					break;
	
				default:
					break;
				}
	
				MailVO mailVO = new MailVO();
				mailVO.setEmail(orderInfo.getOrdrrEmail()); 			  //수신자이메일
				mailVO.setMemberNo(orderInfo.getMberNo());				  //회원번호
				mailVO.setMailTmptSeq(Integer.parseInt(templateNum));	  //템플릿번호
				mailVO.setMailSendUserId("system");					  	  //발신아이디
				mailVO.setMailSendEmail("webmasters@kztraders.com");	  //발신이메일
				mailVO.setMailTmptSeq(Integer.parseInt(templateNum)); 	  //템플릿번호
	
				Map<String,String> orderInfoMap = new HashMap<>();
	//			Map<String,Object> orderInfoMap2 = new HashMap<>();
				Map<String, CommonCodeVO> csTelNo = commonCodeService.getSubCodesRetVo("SORIN_SETUP_CODE", "CS_TEL");
				orderInfoMap.put("csTelNo", csTelNo.get("CS_TEL").getCodeDcone()); //고객센터번호
				orderInfoMap.put("payAmount", orderInfo.getSetleMthdCode().equals("90") ? orderInfo.getUnSetleAmount() : orderInfo.getTotDcsnOrderPc());
				orderInfoMap.put("payDate", orderInfo.getPayDate());
				orderInfoMap.put("orderNo", orderInfo.getOrderNo());
				orderInfoMap.put("orderEntrpsNm", orderInfo.getOrderEntrpsNm());
				orderInfoMap.put("orderDe", orderInfo.getOrderDe());
				orderInfoMap.put("servicedomain", "https://www.kztraders.com");
				String replacedOdrDtlsInfo = getOdrDtlsInfoMap(orderInfo, templateNum); //결제수단에 따른 동적 데이터
				orderInfoMap.put("odrDtlsInfo", replacedOdrDtlsInfo);
	
				String orderEntrpsNm = orderInfo.getOrderEntrpsNm(); // 주문업체명
				String orderDe = orderInfo.getOrderDe(); // 주문일자
	
				/*고객을 위한 이메일 타이틀 내용 : 내부사용자를 향한 메세지는 공통메소드에서 다시 설정할 예정*/
				if("57".equals(templateNum)) {
	                titleMsg = orderEntrpsNm+"회원님, <span style=\"color: #1D5FD0;\">"+orderDe+" 주문의 잔금 결제가 완료</span>";
	            }
	
	            orderInfoMap.put("titleMsg", titleMsg);
	            orderInfoMap.put("sorinCreditTableInfo", "");
	
	            OrderInfoVO pramInfo = new OrderInfoVO();
	        	log.debug(" ***** mail 발송 orderNo : "+orderNo);
	            pramInfo.setOrderNo(orderNo);
	            OrderInfoVO ovo = cdtlnMessageMapper.selectMemberInfo(pramInfo);
	
	            String setleMthdCode = orderInfo.getSetleMthdCode(); //결제 방식 코드가 케이지크레딧(40)이라면
	
				if ("40".equals(setleMthdCode) && "57".equals(templateNum)) {
	            	log.info("001"+ ovo.getEntrpsNo()+ "**** "+ovo.getGrntyNo());
	                selectSorinCredtList = cdtlnMessageMapper.selectSorinCredtInfo(ovo); //케이지크레딧 거래정보를 가져온다.
	
					if (selectSorinCredtList != null) {
	            		log.info("002 - {} ***** {}", ovo.getEntrpsNo(), ovo.getGrntyNo());
	            		//사용 가능액 가져오기
	            		long totalMrtggBlce = Optional.ofNullable(cdtlnMessageMapper.selectTotalMrtggBlce(ovo)).orElse(0L);
	            		log.debug(" *****  mail 발송 totalMrtggBlce : "+totalMrtggBlce);
	
		                // 케이지크레딧 테이블 정보 동적 출력
		                String sorinCreditTableInfo = getSorinCreditTableInfo(selectSorinCredtList,totalMrtggBlce);
		                orderInfoMap.put("sorinCreditTableInfo", sorinCreditTableInfo);
					}
				}
	
				orderInfoMap.forEach((key, value) -> {
					if (StringUtils.isEmpty(value) || StringUtils.equals("0", value)) {
						orderInfoMap.replace(key, "");
					}
				});
	
				/**회원의 이메일로 메일 전송*/
				// 예외 발송 옵션 여부, N일 경우 메일 수신자, 웹마스터, 추가 담당자만 발송한다.
				// 내부사용자만 타이틀을 달리 보내고 싶은 특수한 경우에 발송 여부를 조절하여 사용됨
				mailVO.setExcpSndngOptnAt("N");
				resultMailNo = mailService.insertMailSendByReturnMailNo(mailVO, orderInfoMap);
	
				if ("40".equals(setleMthdCode) && "57".equals(templateNum)) {
					/**내부 사용자에게 이메일 발송하기*/
					titleMsg = orderEntrpsNm+" 업체의 <span style=\"color: #1D5FD0;\">케이지크레딧 상환이 완료</span>";
					orderInfoMap.put("titleMsg", titleMsg);
					// 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
					// 내부사용자만 타이틀을 달리 보내고 싶은 특수한 경우에 발송 여부를 조절하여 사용됨
					mailVO.setExcpSndngOptnAt("Y");
					mailService.insertMailSend(mailVO, orderInfoMap);
				}
	
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return resultMailNo;
	}

	private String getOdrDtlsInfoMap(OrderInfoVO orderInfo, String templateNum) throws Exception {
		//결제수단에 따른 동적 html 세팅
		String targetHtml = getOdrDtlsHtml(orderInfo.getSetleMthdCode(), templateNum, Long.parseLong(orderInfo.getExcclcAmount().replaceAll(",", "")));

		Field[] fields = OrderInfoVO.class.getDeclaredFields();
		for(Field field : fields) {
			field.setAccessible(true);

			Object tmpValue = field.get(orderInfo);
			String key = field.getName();
			String value = "";

			if(tmpValue != null) {
				value = tmpValue.toString();
			}
			targetHtml = targetHtml.replace(key, value); //데이터 치환
		}

		return targetHtml;
	}

	private String getOdrDtlsHtml(String setleMthdCode, String templateNum, long excclcAmount) {
		StringBuilder sb = new StringBuilder();

		switch (templateNum) {
		case "57":
			//결제완료 템플릿
			if ("20".equals(setleMthdCode) || "40".equals(setleMthdCode)) { /* 전자상거래보증 or 케이지크레딧 */
				sb.append("					<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"border-collapse:collapse;\" width=\"100%\">");
				sb.append("						<tbody>");
				sb.append("						<tr>");
				sb.append("							<td style=\"border-top: 1.5px solid #000; background: #fff; padding-bottom: 60px;\">");
				sb.append("								<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"border-collapse:collapse; \" width=\"100%\">");
				sb.append("									<thead>");
				sb.append("									<tr style=\"height: 36px;\">");
				sb.append("										<th align=\"center\" style=\"background: #F1F1F1; border: #666; color: #666; font-size: 12px; font-weight: normal;\">구분</th>");
				sb.append("										<th align=\"center\" style=\"background: #F1F1F1; border: #666; color: #666; font-size: 12px; font-weight: normal;\">항목</th>");
				sb.append("										<th align=\"center\" style=\"background: #F1F1F1; border: #666; color: #666; font-size: 12px; font-weight: normal;\">주문</th>");
				sb.append("                                     <th align=\"center\" style=\"background: #F1F1F1; border: #666; color: #666; font-size: 12px; font-weight: normal;\">출고</th>");
				sb.append("                                     <th align=\"center\" style=\"background: #F1F1F1; border: #666; color: #666; font-size: 12px; font-weight: normal;\">정산금액(출고-주문)</th>");
				sb.append("										<th align=\"center\" style=\"background: #F1F1F1; border: #666; color: #666; font-size: 12px; font-weight: normal;\">결제(잔액결제)</th>");
				sb.append("									</tr>");
				sb.append("									</thead>");
				sb.append("									<tbody>");
				sb.append("									<tr> ");
				sb.append("										<td align=\"center\" rowspan=\"2\" style=\"padding: 4px 0; border-bottom: 1px solid #DEDEDE; border-top: 1px solid #DEDEDE; color: #666; font-size: 12px; line-height: 24px; background-color: #F1F1F1; \">주문 정보</td>");
				sb.append("										<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">수량</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">totRealOrderWt</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">totDcsnWt</td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcWt</span></td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("									</tr>");
				sb.append("									<tr>");
				sb.append("										<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">상품단가</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">goodsUntpc</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">goodsUntpc</td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">-</span></td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("									</tr>");
				sb.append("									<tr>");
				sb.append("										<td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0; border-bottom: 1px solid #DEDEDE; border-top: 1px solid #DEDEDE; color: #666; font-size: 12px; line-height: 24px; background-color: #F1F1F1;\">주문금액</td>");
				sb.append("										<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">①상품금액</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">goodsPc</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">goodsPc</td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">totDcsnOrderPc</span></td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("									</tr>");
				sb.append("									<tr>");
				sb.append("										<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">②중량변동금</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">wtChangegld</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">wtChangegld</span></td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("									</tr>");
				sb.append("									<tr>");
				sb.append("										<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">③배송비</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">expectDlvrf</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">expectDlvrf</td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcDlvyCt</span></td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("									</tr>");
				sb.append("									<tr>");
				sb.append("										<td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0;border-bottom: 1px solid #DEDEDE; border-top: 1px solid #DEDEDE; color: #666; font-size: 12px; line-height: 24px; background-color: #F1F1F1;\" >결제요청금액</td>");
				sb.append("										<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">공급가액(①+②+③)</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">splpc</td>");
				sb.append("										<td align=\"right\" rowspan=\"3\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">계산서 발행 없음</td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcSplpc</span></td>");
				sb.append("                                     <td align=\"right\" rowspan=\"3\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">계산서 발행 없음</td>");
				sb.append("									</tr>");
				sb.append("									<tr>");
				sb.append("										<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">VAT</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">vat</td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcVat</span></td>");
				sb.append("									</tr>");
				sb.append("									<tr>");
				sb.append("										<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">결제 요청금액</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">slepc</td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcAmount</span></td>");
				sb.append("									</tr>");
				sb.append("                                 <tr>");
				sb.append("										<td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0; border-bottom: 1px solid #DEDEDE; border-top: 1px solid #DEDEDE; color: #666; font-size: 12px; line-height: 24px; background-color: #F1F1F1;\">결제금액</td>");
				sb.append("										<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">결제금액(1차)</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">-</span></td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">totDcsnOrderPc</td>");
				sb.append("									</tr>");
				sb.append("									<tr>");
				sb.append("										<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">결제금액(2차)</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">-</span></td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("									</tr>");
				sb.append("									<tr>");

				//중량정산 +/- 여부에 따라 분기
				if (excclcAmount > 0) {
	            	sb.append("									<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px; color: red;\">추가정산예정금액</td>");
	            } else {
	            	sb.append("									<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">정산금액</td>");
	            }

				sb.append("										<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("									    <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");

				//중량정산 +/- 여부에 따라 분기
				if (excclcAmount > 0) {
	            	sb.append("                                 <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: red; font-weight: bold;\">excclcAmount</span></td>");
	            } else {
	            	sb.append("                                 <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">excclcAmount</span></td>");
	            }

				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("									</tr>");
				sb.append("                                 <tr>");
				sb.append("                                      <td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0; border-bottom: 1px solid #DEDEDE; border-top: 1px solid #DEDEDE; color: #666; font-size: 12px; line-height: 24px; background-color: #F1F1F1;\">결제예정금액</td>");
				sb.append("                                      <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">결제예정일</td>");
				sb.append("                                      <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">frstSetlePrearngeDe</td>");
				sb.append("                                      <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("                                      <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">setlePrearngeDe</span></td>");
				sb.append("                                      <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("                                 </tr>");
				sb.append("                                 <tr>");
				sb.append("                                     <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">결제예정금액</td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">slepc</td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #e9e9e9; color: #333333; font-size: 12px; line-height: 24px;\"><span style=\"color: #fa5e38; font-weight: bold;\">totDcsnOrderPc</span></td>");
				sb.append("                                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("                                 </tr>");
				sb.append("									</tbody>");
				sb.append("								</table>");
				sb.append("							</td>");
				sb.append("						</tr>");
				sb.append("						</tbody>");
				sb.append("					</table>");

			} else if ("90".equals(setleMthdCode)) {	/* 증거금 */
				sb.append("<tale border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"border-collapse:collapse;\" width=\"100%\">");
				sb.append("		<tbody>");
				sb.append("		<tr>");
				sb.append("			<td style=\"border-top: 1.5px solid #000; background: #fff; padding-bottom: 60px;\">");
				sb.append("				<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"border-collapse:collapse; \" width=\"100%\">");
				sb.append("					<thead>");
				sb.append("					<tr style=\"height: 36px;\">");
				sb.append("						<th align=\"center\" style=\"background: #F1F1F1; border: #666; color: #666; font-size: 12px; font-weight: normal;\">구분</th>");
				sb.append("						<th align=\"center\" style=\"background: #F1F1F1; border: #666; color: #666; font-size: 12px; font-weight: normal;\">항목</th>");
				sb.append("						<th align=\"center\" style=\"background: #F1F1F1; border: #666; color: #666; font-size: 12px; font-weight: normal;\">주문</th>");
				sb.append("						<th align=\"center\" style=\"background: #F1F1F1; border: #666; color: #666; font-size: 12px; font-weight: normal;\">결제(잔액결제)</th>");
				sb.append("					</tr>");
				sb.append("					</thead>");
				sb.append("					<tbody>");
				sb.append("					<tr> ");
				sb.append("						<td align=\"center\" rowspan=\"2\" style=\"padding: 4px 0; border-bottom: 1px solid #DEDEDE; border-top: 1px solid #DEDEDE; color: #666; font-size: 12px; line-height: 24px; background-color: #F1F1F1; \">주문 정보</td>");
				sb.append("						<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">수량</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">totRealOrderWt</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">totRealOrderWt</td>");
				sb.append("					</tr>");
				sb.append("					<tr>");
				sb.append("						<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">상품단가</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">goodsUntpc</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">goodsUntpc</td>");
				sb.append("					</tr>");
				sb.append("					<tr>");
				sb.append("						<td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0; border-bottom: 1px solid #DEDEDE; border-top: 1px solid #DEDEDE; color: #666; font-size: 12px; line-height: 24px; background-color: #F1F1F1;\">주문금액</td>");
				sb.append("						<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">①상품금액</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">goodsPc</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">goodsPc</td>");
				sb.append("					</tr>");
				sb.append("					<tr>");
				sb.append("						<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">②중량변동금</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">wtChangegld</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">wtChangegld</td>");
				sb.append("					</tr>");
				sb.append("					<tr>");
				sb.append("						<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">③배송비</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">expectDlvrf</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">expectDlvrf</td>");
				sb.append("					</tr>");
				sb.append("					<tr>");
				sb.append("						<td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0;border-bottom: 1px solid #DEDEDE; border-top: 1px solid #DEDEDE; color: #666; font-size: 12px; line-height: 24px; background-color: #F1F1F1;\" >결제요청금액</td>");
				sb.append("						<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">공급가액(①+②+③)</td>");
				sb.append("						<td align=\"right\" rowspan=\"3\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">계산서 발행 없음</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">splpc</td>");
				sb.append("					</tr>");
				sb.append("					<tr>");
				sb.append("						<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">VAT</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">vat</td>");
				sb.append("					</tr>");
				sb.append("					<tr>");
				sb.append("						<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">결제 요청금액</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">slepc</td>");
				sb.append("					</tr>");
				sb.append("                 <tr>");
				sb.append("						<td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0; border-bottom: 1px solid #DEDEDE; border-top: 1px solid #DEDEDE; color: #666; font-size: 12px; line-height: 24px; background-color: #F1F1F1;\">결제금액</td>");
				sb.append("						<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">결제금액(1차)</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">frstSetleAmount</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">frstSetleAmount</td>");
				sb.append("					</tr>");
				sb.append("					<tr>");
				sb.append("						<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">결제금액(2차)</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">unSetleAmount</td>");
				sb.append("					</tr>");
				sb.append("					<tr>");
				sb.append("						<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">정산금액</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("						<td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("					</tr>");
				sb.append("                 <tr>");
				sb.append("                     <td align=\"center\" rowspan=\"3\" style=\"padding: 4px 0; border-bottom: 1px solid #DEDEDE; border-top: 1px solid #DEDEDE; color: #666; font-size: 12px; line-height: 24px; background-color: #F1F1F1;\">결제예정금액</td>");
				sb.append("                     <td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">결제예정일</td>");
				sb.append("                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">setlePrearngeDe</td>");
				sb.append("                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("                 </tr>");
				sb.append("                 <tr>");
				sb.append("                 	<td align=\"center\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">결제예정금액</td>");
				sb.append("                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">unSetleAmount</td>");
				sb.append("                     <td align=\"right\" style=\"padding: 4px 0; border: 1px solid #DEDEDE; color: #333333; font-size: 12px; line-height: 24px;\">-</td>");
				sb.append("                 </tr>");
				sb.append("					</tbody>");
				sb.append("				</table>");
				sb.append("			</td>");
				sb.append("		</tr>");
				sb.append("		</tbody>");
				sb.append("</tble>");
			}

			break;
		}

		return sb.toString();
	}


	/**
	 * 케이지크레딧 테이블 정보 동적 출력
	 */
	@Override
	public String getSorinCreditTableInfo(List<OrderInfoVO> selectSorinCredtList, Long totalMrtggBlce) {

		DecimalFormat decFormat = new DecimalFormat("###,###");
		StringBuilder sorinTable= new StringBuilder();

		String mrtggBlce = decFormat.format(totalMrtggBlce);

		sorinTable.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"border-collapse:collapse;\" width=\"100%\">");
		sorinTable.append("	<tbody>");
		sorinTable.append("<tr>");
		sorinTable.append( "	<td style=\"margin: 0; padding-bottom: 8px; color: #333333; font-size:16px; line-height:28px; font-weight: bold; font-family: 맑은고딕, Malgun Gothic, dotum, gulim, sans-serif;\">케이지 크레딧 거래 정보</td>");
		sorinTable.append( "</tr>");
		sorinTable.append( "<tr>");
		sorinTable.append( "		<td style=\"border-top: 1px solid #000;\">");
		sorinTable.append( "		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"border-collapse:collapse; \" width=\"100%\">");
		sorinTable.append( "			<colgroup>");
		sorinTable.append( "				<col width=\"250px\" />");
		sorinTable.append( "				<col width=\"250px\" />");
		sorinTable.append( "				<col width=\"110px\" />");
		sorinTable.append( "				<col width=\"110px\" />");
		sorinTable.append( "				<col width=\"140px\" />");
		sorinTable.append( "				<col width=\"200px\" />");
		sorinTable.append( "			</colgroup>");
		sorinTable.append("			<thead>");
		sorinTable.append( "			<tr style=\"height: 36px;\">");
		sorinTable.append( "				<th colspan=\"6\" align=\"right\" style=\"background: #fff; font-family: 맑은고딕, Malgun Gothic, dotum, gulim, sans-serif; color: #red; font-size: 16px; line-height: 35px; color:red\"><div style=\"background: #F1F1F1; border-bottom: 1px solid #DEDEDE; padding-right:10px;\">사용 가능액 : "+mrtggBlce+" 원</div></th>");
		sorinTable.append("			    </tr>");
		sorinTable.append( "			<tr style=\"height: 36px;\">");
		sorinTable.append( "				<th align=\"center\"  style=\"background: #fff; font-family: 맑은고딕, Malgun Gothic, dotum, gulim, sans-serif; color: #666; font-size: 12px; line-height: 35px;\"><div style=\"background: #F1F1F1; border-bottom: 1px solid #DEDEDE; border-right: 1px solid #DEDEDE;\">거래일시</div></th>");
		sorinTable.append( "				<th align=\"center\"  style=\"background: #fff; font-family: 맑은고딕, Malgun Gothic, dotum, gulim, sans-serif; color: #666; font-size: 12px; line-height: 35px;\"><div style=\"background: #F1F1F1; border-bottom: 1px solid #DEDEDE;  border-right: 1px solid #DEDEDE;\">주문번호</div></th>");
		sorinTable.append( "				<th align=\"center\"  style=\"background: #fff; font-family: 맑은고딕, Malgun Gothic, dotum, gulim, sans-serif; color: #666; font-size: 12px; line-height: 35px;\"><div style=\"background: #F1F1F1; border-bottom: 1px solid #DEDEDE; border-right: 1px solid #DEDEDE;\">사용</div></th>");
		sorinTable.append( "				<th align=\"center\"  style=\"background: #fff; font-family: 맑은고딕, Malgun Gothic, dotum, gulim, sans-serif; color: #666; font-size: 12px; line-height: 35px;\"><div style=\"background: #F1F1F1; border-bottom: 1px solid #DEDEDE; border-right: 1px solid #DEDEDE;\">상환</div></th>");
		sorinTable.append( "				<th align=\"center\"  style=\"background: #fff; font-family: 맑은고딕, Malgun Gothic, dotum, gulim, sans-serif; color: #666; font-size: 12px; line-height: 35px;\"><div style=\"background: #F1F1F1; border-bottom: 1px solid #DEDEDE; border-right: 1px solid #DEDEDE;\">결제 예정액</div></th>");
		sorinTable.append( "				<th align=\"center\"  style=\"background: #fff; font-family: 맑은고딕, Malgun Gothic, dotum, gulim, sans-serif; color: #666; font-size: 12px; line-height: 35px;\"><div style=\"background: #F1F1F1; border-bottom: 1px solid #DEDEDE;\">결제 예정일</div></th>");
		sorinTable.append("				</tr>");
		sorinTable.append("			</thead>");
		sorinTable.append("			<tbody>");


		for(OrderInfoVO list : selectSorinCredtList) {
			sorinTable.append( "			<tr>");
			sorinTable.append( "				<td align=\"center\" style=\"padding: 5px; border: 1px solid #e9e9e9; color: ##333333; font-size: 11px; line-height: 35px; valign=\"center\"\">"+ list.getMrtggDelngDt()  +"</td>");
			sorinTable.append( "				<td align=\"center\" style=\"border: 1px solid #e9e9e9; color: ##333333; font-size: 11px; line-height: 24px; \">"+list.getOrderNo()+"</td>");
			sorinTable.append( "				<td align=\"center\" style=\"border: 1px solid #e9e9e9; color: ##333333; font-size: 11px; line-height: 24px; text-align:right; padding-right:10px; \">"+decFormat.format(Long.parseLong(list.getUseAmt()))+"</td>");
			sorinTable.append( "				<td align=\"center\" style=\"border: 1px solid #e9e9e9; color: ##333333; font-size: 11px; line-height: 24px; text-align:right; padding-right:10px; \">"+decFormat.format(list.getTotSetleAmount())+"</td>");
			sorinTable.append( "				<td align=\"center\" style=\"border: 1px solid #e9e9e9; color: ##333333; font-size: 11px; line-height: 24px; text-align:right; padding-right:10px;\">"+list.getUnSetleAmount()+"</td>");
			sorinTable.append( "				<td align=\"center\" style=\"border: 1px solid #e9e9e9; color: ##333333; font-size: 11px; line-height: 24px; \">"+list.getSetlePrearngeDe()+"</td>");
			sorinTable.append("			</tr>");
		}

		sorinTable.append( "			</tbody>");
		sorinTable.append( "		</table>");
		sorinTable.append( "		</td>");
		sorinTable.append( "</tr>");
		sorinTable.append("	</tbody>");
		sorinTable.append("</table>");


		return sorinTable.toString();
	}
	
	/**
	 * 출고중지 및 출고중지 해제 SMS 전송 공통 서비스
	 *     dlivyStpgeCode[출고 중지 코드] : stpge(중지), relis(해제)
	 *     outptAmount [출력 금액] : stpge(중지) 시 미납금액, relis(해제) 시 결제금액
	 */
	@Override
	public void sendDlivyStpgeRelisSms(String dlivyStpgeCode, String orderNo, Long outptAmount, int templateNum) throws Exception {
		// 출고중지 및 출고중지 해제 SMS 정보 가져오기
		Map<String, String> smsMap = cdtlnMessageMapper.selectDlivyStpgeRelisSmsInfo(orderNo, outptAmount);
		
		SMSVO smsVo = new SMSVO();
		
		// OR_ORDER_BAS(주문_주문 기본)-ORDRR_MOBLPHON_NO(주문자 휴대폰 번호) 복호화
        String ordrrMoblphonNo = String.valueOf(smsMap.get("ordrrMoblphonNo")); // 주문자 휴대폰 번호
        if (StringUtils.isNotEmpty(ordrrMoblphonNo)) {
            try {
                log.debug("주문자 휴대폰 번호 복호화 전 ==================>" + ordrrMoblphonNo);
                ordrrMoblphonNo = CryptoUtil.decryptAES256(ordrrMoblphonNo);
                log.debug("주문자 휴대폰 번호 복호화 후 ==================>" + ordrrMoblphonNo);
                /** 주문자 휴대폰 번호 셋팅 **/
                ordrrMoblphonNo = StringUtil.formatPhone(ordrrMoblphonNo);
            } catch (Exception e) {
                log.error("LoServiceImpl sendMessageToCustomer ORDRR_MOBLPHON_NO CryptoUtil.decryptAES256 ERROR "
                        + e.getMessage());
            }
        }

        smsVo.setPhone(ordrrMoblphonNo.replace("-", "")); // 주문자 휴대폰 번호
        smsVo.setMberNo(String.valueOf(smsMap.get("mberNo"))); // 회원 번호
        smsVo.setCommerceNtcnAt("N");
        
        smsMap.put("templateNum", String.valueOf(templateNum));
        smsMap.put("Servicedomain", "https://m.metalsorin.com");
        
        CommonCodeVO csTelInfo = Optional.ofNullable(commonCodeService.getCodeValueRetVo("SORIN_SETUP_CODE", "CS_TEL")).orElse(new CommonCodeVO());
        String csTel = csTelInfo.getCodeDcone();
        smsMap.put("csTel", csTel);
        
        String dlivyStpgeCn = ""; // 출고중지문구, 출고 중지 시 [미납발생으로 출고중지 예정입니다], 출고 중지 해제 시 [미납결제로 출고중지 취소되었습니다]
        switch(dlivyStpgeCode) {
	        case "stpge" : 
	        	dlivyStpgeCn = "미납발생으로 출고중지 예정입니다.";
	        	break;
	        case "relis" : 
	        	dlivyStpgeCn = "미납결제로 출고중지 취소되었습니다";
	        	break;
        }
        smsMap.put("dlivyStpgeCn", dlivyStpgeCn); // 출고중지문구
        
        // 결제수단에 따른 결제정보 치환
        String replacedOdrSetleInfo = getOdrSetleInfoData(dlivyStpgeCode, smsMap);
        smsMap.put("odrSetleInfo", replacedOdrSetleInfo);
        
        // SMS 또는 LMS 발송 및 알림톡 발송
        smsService.insertSMSByReturnMssageSndngHistNo(smsVo, smsMap);
	}
	
	/**
	 * <pre>
	 * 처리내용: 결제수단에 따른 결제정보 치환
	 *     dlivyStpgeCode[출고 중지 코드] : stpge(중지), relis(해제)
	 * </pre>
	 * @date 2024. 7. 19.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 7. 19.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param dlivyStpgeCode [출고 중지 코드] : stpge(중지), relis(해제)
	 * @param smsMap
	 * @return
	 * @throws Exception
	 */
	private String getOdrSetleInfoData(String dlivyStpgeCode, Map<String, String> smsMap) throws Exception {
		StringBuilder targetTmplat = new StringBuilder();
		
		String setleMthCode = String.valueOf(smsMap.get("setleMthCode")); // 결제 방식 코드
        String sleMthdCode = String.valueOf(smsMap.get("sleMthdCode")); // 판매 방식 코드
        String sleMthdDetailCode = String.valueOf(smsMap.get("sleMthdDetailCode")); // 판매 방식 상세 코드
        String goodsUntpc = String.valueOf(smsMap.get("goodsUntpc")); // 결제단가
        String slepc = String.valueOf(smsMap.get("slepc")); // 주문금액
        String setleMthdNm = String.valueOf(smsMap.get("setleMthdNm")); // 결제방법
        String outptAmount = String.valueOf(smsMap.get("outptAmount")); // 미납금액 or 결제금액

        // 2023-12-06 변경사항 : 평균가 판매방식 추가에 따른 메세지 포멧 변경
        // 1. 기본 문구 세팅
        String setleMthdNmStr = "결제 방법 : " + setleMthdNm;
        String goodsUntPcStr = "결제단가 : " + goodsUntpc;
        String slepcStr = "주문금액 : " + slepc;
        String npyAmountStr = "미납금액 : " + outptAmount;
        String remndrSetleAmountStr = "결제금액 : " + outptAmount;
        
        // 평균가(04)는 부분상환이 없어서 이 로직을 탈 일은 현재는 없음, 20240719
        // 2. 평균가(04) 또는 평균가-LIVE(0104) 주문일 경우, 세팅된 문구 추가 또는 바꿔치기
        // 24-02-19 변경사항 : 평균가-지정가(0304) 주문도 해당 로직 수행하도록 조건 추가
        if( StringUtils.equals("04", sleMthdCode) || StringUtils.equals("0104", sleMthdDetailCode) || StringUtils.equals("0304", sleMthdDetailCode) ) {
        	String avrgpcGoodsUntpc = String.valueOf(smsMap.get("avrgpcGoodsUntpc")); // 평균가 결제단가
        	
        	if(StringUtils.isNotEmpty(avrgpcGoodsUntpc) && !StringUtils.equals("0", avrgpcGoodsUntpc)) {
        		if(StringUtils.isNotEmpty(goodsUntpc) && !StringUtils.equals("0", goodsUntpc)) {
        			goodsUntPcStr +=  " (가단가 : " + avrgpcGoodsUntpc + ")";
        		} else {
        			goodsUntPcStr = "결제단가 : " + avrgpcGoodsUntpc + "(가단가)";
        		}
        		
        		String avrgpcSlepc = String.valueOf(smsMap.get("avrgpcSlepc")); // 평균가 주문금액
        		slepcStr = "주문금액 : " + avrgpcSlepc;
        	}
        }

        /** 결제 수단에 따른 SMS 템플릿 설정 */
        /* 전자상거래보증 or 케이지크레딧 */
        if ("20".equals(setleMthCode) || "40".equals(setleMthCode)) {
        	targetTmplat.append(setleMthdNmStr).append("\r\n")
        		.append(goodsUntPcStr).append("\r\n")
        		.append(slepcStr).append("\r\n").append("\r\n");
        	
        	switch(dlivyStpgeCode) {
		        case "stpge" : 
		        	targetTmplat.append(npyAmountStr);
		        	break;
		        case "relis" : 
		        	targetTmplat.append(remndrSetleAmountStr);
		        	break;
	        }
        }
        
        return targetTmplat.toString();
    }

}
