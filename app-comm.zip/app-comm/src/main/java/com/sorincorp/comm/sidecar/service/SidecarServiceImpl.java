package com.sorincorp.comm.sidecar.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.sidecar.mapper.SidecarOpMapper;
import com.sorincorp.comm.sidecar.model.SidecarVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SidecarServiceImpl implements SidecarService {

	@Autowired
	SidecarOpMapper sidecarMapper;
	
	@Override
	public List<SidecarVO> getSidecarOnList() {
		return sidecarMapper.getSidecarOnList();
	}

}
