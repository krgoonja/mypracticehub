package com.sorincorp.comm.util;

import java.lang.reflect.Field;
import java.net.URLDecoder;
import java.net.URLEncoder;

import lombok.extern.slf4j.Slf4j;

/**
 * UrlUtil.java
 * @version
 * @since 2021. 5. 18.
 * @author srec0012
 */

@Slf4j
public class UrlUtil {
	
	private UrlUtil() {
		log.debug(UrlUtil.class.getSimpleName());
	}
	
	/**
	 * <pre>
	 * 단위 객체를 Encoding 한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @param encodingType
	 * @return
	 * @throws Exception
	 */
	public static String encoder(String param, String encodingType) throws Exception {
		return URLEncoder.encode(param, encodingType);
	}
	
	/**
	 * <pre>
	 * Obejct 객체를 Encoding 한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param obj
	 * @param encodingType
	 * @return
	 * @throws Exception
	 */
	public static Object encoderAll(Object obj, String encodingType) throws Exception {
		Class<? extends Object> cls = obj.getClass();
		Field[] fieldList = cls.getDeclaredFields();
		
		for ( Field field : fieldList ) {
			field.setAccessible(true);
			if ( field.get(obj) != null && !"".equals(field.get(obj)) && field.getType() == String.class ) {
				String fieldValue = (String)field.get(obj);
				String newFieldValue = URLEncoder.encode(fieldValue, encodingType);
				field.set(obj, newFieldValue);
			}
		}
		
		return obj;
	}
	
	/**
	 * <pre>
	 * 단위 객체를 Decoding 한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @param decodingType
	 * @return
	 * @throws Exception
	 */
	public static String decoder(String param, String decodingType) throws Exception {
		return URLDecoder.decode(param, decodingType);
	}
	
	/**
	 * <pre>
	 * Object 객체를 Decoding 한다.
	 * </pre>
	 * @date 2021. 5. 18.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 5. 18.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param obj
	 * @param decodingType
	 * @return
	 * @throws Exception
	 */
	public static Object decoderAll(Object obj, String decodingType) throws Exception {
		Class<? extends Object> cls = obj.getClass();
		Field[] fieldList = cls.getDeclaredFields();
		
		for ( Field field : fieldList ) {
			field.setAccessible(true);
			if ( field.get(obj) != null && !"".equals(field.get(obj)) && field.getType() == String.class ) {
				String fieldValue = (String)field.get(obj);
				String newFieldValue = URLDecoder.decode(fieldValue, decodingType);
				field.set(obj, newFieldValue);
			}
		}
		
		return obj;
	}
}
