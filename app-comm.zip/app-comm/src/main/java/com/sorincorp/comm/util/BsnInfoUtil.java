package com.sorincorp.comm.util;

import java.util.Arrays;
import java.util.List;

public class BsnInfoUtil {
	
	public enum OperateSttusCode {
		OPERATE_AT(Arrays.asList("20", "21", "23"));
		
		private final List<String> values;
		
		OperateSttusCode(List<String> values) {
			this.values = values;
		}

		public List<String> getValues() {
			return values;
		}
	}
}
