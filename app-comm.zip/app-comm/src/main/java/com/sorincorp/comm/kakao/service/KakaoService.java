package com.sorincorp.comm.kakao.service;

import java.util.HashMap;

public interface KakaoService {
	/**
	 * <pre>
	 * 카카오 authorize_code로 가카오 정보를 가져오기 위한 Access Token을 가져온다.
	 * </pre>
	 * @date 2021. 6. 17.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 17.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param authorizeCode
	 * @param redirectUrl
	 * @return
	 * @throws Exception
	 */
	//public String getAccessToken(String authorizeCode, String redirectUrl) throws Exception;
	
	/**
	 * <pre>
	 * 카카오 Access Token으로 카카오 사용자 정보를 가져온다.
	 * </pre>
	 * @date 2021. 6. 16.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 16.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param access_Token
	 * @return
	 * @throws Exception
	 */
	//public HashMap<String, Object> getUserInfo (String access_Token) throws Exception;
}
