package com.sorincorp.comm.entrpsdlvrg.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.brandgroupcode.model.BrandGroupCodeVO;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.entrpsdlvrg.mapper.EntrpsDlvrgMapper;
import com.sorincorp.comm.entrpsdlvrg.model.EntrpsDlvrgVO;
import com.sorincorp.comm.util.CacheUtil;
import com.sorincorp.comm.wrhouscode.model.WrhousCodeVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EntrpsDlvrgServiceImpl implements EntrpsDlvrgService {

	@Autowired
	private EntrpsDlvrgMapper entrpsDlvrgMapper;

	/**
	 * <pre>
	 * 처리내용: 회원 배송지 목록 조회
	 * </pre>
	 * @date 2021. 7. 13.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<EntrpsDlvrgVO> getEntrpsDlvrgList(String entrpsNo) throws Exception {
		List<EntrpsDlvrgVO> entrpsDlvrgList = entrpsDlvrgMapper.getEntrpsDlvrgList(entrpsNo);
		return entrpsDlvrgList;
	}
	/**
	 * <pre>
	 * 처리내용: 회원 배송지 목록 조회
	 * </pre>
	 * @date 2021. 7. 13.
	 * @author srec0009
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			srec0009			최초작성
	 * ------------------------------------------------
	 * @param entrpsDlvrgList
	 * @return
	 * @throws Exception
	 */
	@Override
	public String getEntrpsDlvrgListStr(List<EntrpsDlvrgVO> entrpsDlvrgList) throws Exception {
		StringBuilder codeTaglibStr = new StringBuilder(StringUtils.EMPTY);
		for(EntrpsDlvrgVO address : entrpsDlvrgList) {
			// 배송지 구분명
			codeTaglibStr.append(address.getDlvrgSeNm());
			codeTaglibStr.append(CommonConstants.COLONE);
			// 도로명 주소
			codeTaglibStr.append(address.getRnAdres());
			// 우편 번호
			codeTaglibStr.append(address.getPostNo());
			codeTaglibStr.append(CommonConstants.SEMI_COLONE);
		}
		return codeTaglibStr.toString();
	}



}
