package com.sorincorp.comm.common.service;

import java.util.List;
import java.util.Map;

public interface CommonService {
	
	/**
	 * <pre>
	 * 처리내용: 컬럼 리스트를 가져온다. 
	 * </pre>
	 * @date 2022. 6. 28.
	 * @author jdrttl
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 28.			jdrttl				최초작성
	 * ------------------------------------------------
	 * @param objectName(TableName)
	 * @return
	 * @throws Exception
	 */
	List<Map<String,String>> selectColumnList(String objectName) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 쿼리 실행 
	 * </pre>
	 * @date 2022. 6. 28.
	 * @author jdrttl
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 28.			jdrttl				최초작성
	 * ------------------------------------------------
	 * @param query
	 * @return
	 * @throws Exception
	 */
	public int customQueryExecute(String query) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: HST 테이블 저장
	 * </pre>
	 * @date 2022. 6. 28.
	 * @author jdrttl
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 28.			jdrttl				최초작성
	 * ------------------------------------------------
	 * @param query
	 * @return
	 * @throws Exception
	 */
	public boolean insertTableHistory(String objectName, Map<String,String> keyValue) throws Exception;
	public boolean insertTableHistory(String objectName, Object obj) throws Exception;
	public boolean insertTableHistory(String objectName, Map<String,String> keyValue, List<String> primaryKeyList) throws Exception;
	public boolean insertTableHistory(String objectName, Object obj, List<String> primaryKeyList) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: bl 판매상태변경
	 * </pre>
	 * @date 2022. 9. 02.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 02.			hyunjin05			최초작성
	 * 2022.10. 12.			hyunjin05			blno, userid
	 * ------------------------------------------------
	 * @param query
	 * @return
	 * @throws Exception
	 */
	void blSleSttusCodeChg(String blNo, String userId) throws Exception;
	
	
	/**
	 * <pre>
	 * 처리내용: 해당 필드 조회 후 return value
	 * </pre>
	 * @date 2022. 9. 02.
	 * @author hyunjin05
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 21.			hyunjin05			최초작성
	 * ------------------------------------------------
	 * @param Object
	 * @return 
	 * @return
	 * @throws Exception
	 */
	public <T> T getFieldValue(Object obj, String fieldName) throws Exception;
	
	public String getClientIpAddressIfServletRequestExist() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 테이블 복사 
	 * </pre>
	 * @date 2024. 4. 08.
	 * @author sumin
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 4. 08.				sumin				최초작성
	 * ------------------------------------------------
	 * @param query
	 * @return
	 * @throws Exception
	 */
	public boolean insertTableCopy(String objectName, List<String> primaryKeyList, List<String> oldValueList, List<String> ValueList)  throws Exception;

	/**
	 * <pre>
	 * 처리내용: bl 판매상태변경 (BO -> 판매중 변경 한정)
	 * </pre>
	 *
	 * @date 2024. 06. 28
	 * @author hanjook
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------
	 *          ------------------------------------------------
	 * @param query
	 * @return
	 * @throws Exception
	 */
	List<String> blSleSttusCodeChgSel(List<String> blNoList, String sleSttusCode, String userId) throws Exception;
	
}
