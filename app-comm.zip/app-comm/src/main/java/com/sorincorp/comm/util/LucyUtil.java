package com.sorincorp.comm.util;

import java.lang.reflect.Field;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.stereotype.Component;

import com.navercorp.lucy.security.xss.servletfilter.XssEscapeFilter;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class LucyUtil {
	/**
	 * <pre>
	 * 네이버 LUCY 필터를 이용하여 입력받은 URL과 객체로 객체의 String 객체를 필터링
	 * </pre>
	 * @date 2021. 6. 9.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 9.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param url
	 * @param object
	 */
	public void filter(String url, Object object) {
		XssEscapeFilter filter = XssEscapeFilter.getInstance();
		Class<? extends Object> cls = object.getClass();
		String filteredValue;
		
		for ( Field field : cls.getDeclaredFields() ) {
			try {
				field.setAccessible(true);
				if ( field.get(object) instanceof String ) {
					filteredValue = filter.doFilter(url, field.getName(), (String) field.get(object));
					filteredValue = StringUtil.replaceAll(filteredValue, "&amp;lt;", "&lt;");
					filteredValue = StringUtil.replaceAll(filteredValue, "&amp;gt;", "&gt;");
					field.set(object, filteredValue);
				}
			} catch (Exception e) {
				log.error("루시 필터 적용 오류", e);
			}
		}
		
		log.debug("Filtered Object : {}", ToStringBuilder.reflectionToString(object, ToStringStyle.MULTI_LINE_STYLE));
	}
}