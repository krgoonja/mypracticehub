package com.sorincorp.comm.pcInfo.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * PreminumSelInfoVO.java
 * @version
 * @since 2023. 07. 24.
 * @author srec0067
 */
@Data
@EqualsAndHashCode(callSuper=false)
public class PreminumSelInfoVO {

	/**
	 * 프리미엄 가격
	 */
	private long slePremiumAmount;
	/**
	 * 금속코드
	 */
	private String metalCode;
	/**
	 * 금속코드
	 */
	private String metalClCode;
	/**
	 * 아이템 코드
	 */
	private int itmSn;
	/**
	 * 프리미엄 기준 지역코드
	 */
	private String premiumStdrDstrctLclsfCode;
	/**
	 * 프리미엄 기준 브랜드 그룹 코드
	 */
	private String premiumStdrBrandGroupCode;
	/**
	 * 지역코드
	 */
	private String dstrctLclsfCode;
	/**
	 * 그룹 코드
	 */
	private String brandGroupCode;
	/**
	 * 브랜드 코드
	 */
	private String brandCode;
	/**
	 * 종가
	 */
	private long endPc;
	/**
	 * 전일자 종가
	 */
	private long agoEndPc;
	/**
	 * 대비가격
	 */
	private long versusPc;
	/**
	 * 대비 비율
	 */
	private float versusRate;
	/**
	 * 상품명
	 */
	private String goodsNm;
	/**
	 * 전시상품명
	 */
	private String dspyGoodsNm;
	/**
	 * 권역명 한글
	 */
	private String dstrctLclsfNm;
	/**
	 * 브랜드 그룹명 한글
	 */
	private String brandGroupNm;
	/**
	 * 판매방식코드
	 */
	private String sleMthdCode;
	
	/**
	 * 고정가 가격
	 */
	private long hghnetprcSleAmount;
	
	/**
	 * 브랜드 변동금
	 */
	private long brandChangeAmount;
	
	/**
	 * 유효 시작일시
	 */
	private String validBeginDt;
	
	/**
	 * 유효 종료일시
	 */
	private String validEndDt;

	/**
	* 실제 종가 (프리미업 제외 순수 판매가)
	*/
	private long realEndPc;
}
