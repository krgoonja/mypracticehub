package com.sorincorp.comm.order.model;

import lombok.Data;

/**
 * CommOrLimitOrderBasVO.java
 * 주문_지정가 주문 기본 공통 VO 객체
 * 
 * @version
 * @since 2023. 4. 25.
 * @author srec0049
 */
@Data
public class CommOrLimitOrderBasVO {
    
	/**
     * 지정가 주문 번호
     */
    private String limitOrderNo;
    
    /**
     * 지정가 주문 일자
     */
    private String limitOrderDe;
    
    /**
     * 지정가 주문 시각
     */
    private java.sql.Timestamp limitOrderTm;
    
    /**
     * 지정가 주문 상태 코드
     */
    private String limitOrderSttusCode;
    
    /**
     * 회원 번호
     */
    private String mberNo;
    
    /**
     * 업체 번호
     */
    private String entrpsNo;
    
    /**
     * 접수 매체 구분 코드
     */
    private String rceptMediaSeCode;
    
    /**
     * 지정가 주문 중량
     */
    private int limitOrderWt;
    
    /**
     * 판매 단위 중량
     */
    private int sleUnitWt;
    
    /**
     * 호가 표현 갯수 = 지정가 주문 중량 / 판매 단위 중량
     */
    private int limitOrderWtCnt;
    
    /**
     * 지정가 입력 금액
     */
    private long limitInputAmount;
    
	/**
     * 결제 방식 코드
     */
    private String setleMthdCode;
    
    /**
     * 결제 방식 상세 코드
     */
    private String setleMthdDetailCode;
    
    /**
     * 권역 중분류 코드
     */
    private String dstrctMlsfcCode;
    
    /**
     * 프라이싱 번호
     */
    private String pricingNo;
    
    /**
     * 장바구니 번호
     */
    private String bsktNo;
    
    /**
     * 주문자 명
     */
    private String ordrrNm;
    
    /**
     * 주문자 휴대폰 번호
     */
    private String ordrrMoblphonNo;
    
    /**
     * 주문자 이메일
     */
    private String ordrrEmail;
    
    /**
     * 주문 업체 명
     */
    private String orderEntrpsNm;
    
    /**
     * 주문 업체 전화번호
     */
    private String orderEntrpsTelno;
    
    /**
     * 주문 업체 우편번호
     */
    private String orderEntrpsZip;
    
    /**
     * 주문 업체 주소
     */
    private String orderEntrpsAdres;
    
    /**
     * 주문 업체 상세 주소
     */
    private String orderEntrpsDetailAdres;
    
    /**
     * 주문 업체 도로명 주소
     */
    private String orderEntrpsRnAdres;
    
    /**
     * 주문 업체 도로명 상세 주소
     */
    private String orderEntrpsRnDetailAdres;
    
    /**
     * 배송 수단 코드
     */
    private String dlvyMnCode;
    
    /**
     * 출고 요청 일자
     */
    private String dlivyRequstDe;
    
    /**
     * 판매 단위 코드
     */
    private String sleUnitCode;
    
    /**
     * 최대 브랜드 변동 금액
     */
    private long mxmmBrandChangeAmount;
    
    /**
     * 프리미엄 아이디
     */
    private String premiumId;
    
    /**
     * 최종 상품 단가
     */
    private long lastGoodsUntpc;
    
    /**
     * 주문 가격
     */
    private long orderPc;
    
    /**
     * 중량 변동금
     */
    private long wtChangegld;
    
    /**
     * 공급가
     */
    private long splpc;
    
    /**
     * 부가세
     */
    private long vat;
    
    /**
     * 판매가
     */
    private long slepc;
    
    /**
     * 상환 기간
     */
    private int repyPd;
    
    /**
     * 증거금 최소 증거금 비율
     */
    private java.math.BigDecimal wrtmMummWrtmRate;
    
    /**
     * 예상 배송비
     */
    private java.math.BigDecimal expectDlvrf;
    
    /**
     * 배송지 명
     */
    private String dlvrgNm;
    
    /**
     * 수취 업체 명
     */
    private String receptEntrpsNm;
    
    /**
     * 수취 업체 우편 번호
     */
    private String receptEntrpsPostNo;
    
    /**
     * 수취 업체 주소
     */
    private String receptEntrpsAdres;
    
    /**
     * 수취 업체 상세 주소
     */
    private String receptEntrpsDetailAdres;
    
    /**
     * 수취 업체 도로명 주소
     */
    private String receptEntrpsRnAdres;
    
    /**
     * 수취 업체 도로명 상세 주소
     */
    private String receptEntrpsRnDetailAdres;
    
    /**
     * 수취 업체 법정동 코드
     */
    private String receptEntrpsLegaldongCode;
    
    /**
     * 수취 업체 휴대폰 번호
     */
    private String receptEntrpsMoblphonNo;
    
    /**
     * 수취 업체 담당자 명
     */
    private String receptEntrpsChargerNm;
    
    /**
     * 수취 업체 담당자 이메일
     */
    private String receptEntrpsChargerEmail;
    
    /**
     * 배송 요청 내용
     */
    private String dlvyRequstCn;
    
    /**
     * 중량 변동
     */
    private java.math.BigDecimal wtChange;
    
    /**
     * 금속 코드
     */
    private String metalCode;
    
    /**
     * 아이템 순번
     */
    private int itmSn;
    
    /**
     * 권역 대분류 코드
     */
    private String dstrctLclsfCode;
    
    /**
     * 브랜드 그룹 코드
     */
    private String brandGroupCode;
    
    /**
     * 브랜드 코드
     */
    private String brandCode;
    
    /**
     * 예수 금액
     */
    private long advrcvAmount;
    
	/**
	 * 지정가 프리미엄 기준 금액
	 */
	private long limitPremiumStdrAmount;
	
	/**
	 * 지정가 권역 변동 금액
	 */
	private long limitDstrctChangeAmount;
	
	/**
	 * 지정가 브랜드 그룹 변동 금액
	 */
	private long limitBrandGroupChangeAmount;
	
	/**
	 * 지정가 브랜드 변동 금액
	 */
	private long limitBrandChangeAmount;
    
    /**
	 * 지정가 프리미엄 제외 금액
	 */
	private long limitPremiumExclAmount;
    
    /**
     * 지정가 주문 로그 순번
     */
    private long limitOrderLogSn;
    
    /**
     * 지정가 주문 요청 일시
     */
    private java.sql.Timestamp limitOrderRequstDt;
    
    /**
     * 지정가 주문 기준 판매 가격
     */
    private java.math.BigDecimal limitOrderStdrSlePc;
    
    /**
     * 판매 가격 실시간 순번
     */
    private String slePcRltmSn;
    
    /**
     * LME 가격 실시간 순번
     */
    private String lmePcRltmSn;
    
    /**
     * LME 3M
     */
    private java.math.BigDecimal lme3m;
    
    /**
     * LME 현금
     */
    private java.math.BigDecimal lmeCash;
    
    /**
     * LME 조정 계수
     */
    private java.math.BigDecimal lmeMdatCffcnt;
    
    /**
     * 환율 가격 실시간 순번
     */
    private String ehgtPcRltmSn;
    
    /**
     * 현물환
     */
    private java.math.BigDecimal spex;
    
    /**
     * 현물환 조정 계수
     */
    private java.math.BigDecimal spexMdatCffcnt;
    
    /**
     * 프리미엄 번호
     */
    private String premiumNo;
    
    /**
     * 프리미엄 기준 금액
     */
    private long premiumStdrAmount;
    
    /**
     * 권역 변동 금액
     */
    private long dstrctChangeAmount;
    
    /**
     * 브랜드 그룹 변동 금액
     */
    private long brandGroupChangeAmount;
    
    /**
     * 브랜드 변동 금액
     */
    private long brandChangeAmount;
    
    /**
     * 프리미엄 가격
     */
    private java.math.BigDecimal premiumPc;
    
    /**
     * 재고 체크 중량
     */
    private int invntryCeckWt;
    
    /**
     * 주문 번호
     */
    private String orderNo;
    
    /**
     * 실제 체결 중량
     */
    private int realCnclsWt;
    
    /**
     * 주문 실패 사유
     */
    private String orderFailrResn;
    
    /**
     * 허수 주문 여부
     */
    private String imaginaryOrderAt;
    
    /**
     * 지정가 취소 시각
     */
    private java.sql.Timestamp limitCanclTm;
    
    /**
     * 삭제 일시
     */
    private java.sql.Timestamp deleteDt;
    
    /**
     * 삭제 여부
     */
    private String deleteAt;
    
    /**
     * 최초 등록자 아이디
     */
    private String frstRegisterId;
    
    /**
     * 최초 등록 일시
     */
    private java.sql.Timestamp frstRegistDt;
    
    /**
     * 최종 변경자 아이디
     */
    private String lastChangerId;
    
    /**
     * 최종 변경 일시
     */
    private java.sql.Timestamp lastChangeDt;
    
    /**
     * 쿠폰 적용 여부
     */
    private String couponApplcAt;
    
    /**
     * 지정가 주문 유효 시간
     */
    private String limitOrderValidTime;
    
    /**
     * 지정가 주문 유효 일자
     */
    private String limitOrderValidDe;
    /**
     * 계약 구매 최종 상품 단가
     */
    private long cntrctPurchsLastGoodsUntpc;
    /**
     * 계약 발주 번호
     */
    private String cntrctOrderNo;
    
    /**
     * 소량 구매 여부
     */
	private String smlqyPurchsAt;

	/**
     * BL 번호
     */
    private String blNo;

    /**
     * 자투리 할인(추가할인)
     */
	private long rmndrDscnt;
    
	/**
	 *  부분 출고 상환 여부
	 */
	private String partDlivyRepyAt;

	/**
	 *	지정가 구분 코드 - 가단가용 [F: LME/X: 환율/R: KRW]
	 */
	private String limitSeCode;

	/**
     * 등급 할인 금액
     */
	private long gradApplcAmount;
	
    /**
	 * <pre>
	 * 처리내용: 주문_지정가 주문 기본 정보 조회 데이터로 지정가 주문 Redis 메시지 공통 VO 객체 만들기
	 * </pre>
	 * @date 2023. 4. 26.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 4. 26.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param intrfcSttusCode
	 * @return
	 */
	public CommLimitOrderRedisMsgVO getCommLimitOrderRedisMsgVO(String intrfcSttusCode) {
    	
		// 지정가 주문 Redis 메시지 공통 VO 객체
		CommLimitOrderRedisMsgVO commLimitOrderRedisMsgVO = new CommLimitOrderRedisMsgVO();
		commLimitOrderRedisMsgVO.setLimitOrderNo(this.limitOrderNo);								// 지정가 주문 번호
		commLimitOrderRedisMsgVO.setIntrfcSttusCode(intrfcSttusCode);								// 인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제]
		commLimitOrderRedisMsgVO.setLimitOrderDt(String.valueOf(this.limitOrderTm));				// 지정가 주문일시 (ex. 2021-09-06 13:00:15.527)
		commLimitOrderRedisMsgVO.setEntrpsNo(this.entrpsNo);										// 업체 번호
		commLimitOrderRedisMsgVO.setMetalCode(this.metalCode);										// 금속 코드
		commLimitOrderRedisMsgVO.setItmSn(this.itmSn);												// 아이템 순번
		commLimitOrderRedisMsgVO.setDstrctLclsfCode(this.dstrctLclsfCode);							// 권역 대분류 코드
		commLimitOrderRedisMsgVO.setBrandGroupCode(this.brandGroupCode);							// 브랜드 그룹 코드
		commLimitOrderRedisMsgVO.setBrandCode(this.brandCode);										// 브랜드 코드
		commLimitOrderRedisMsgVO.setLimitInputAmount(this.limitInputAmount);						// 지정가 입력 금액
		commLimitOrderRedisMsgVO.setCstmrOrderWt(this.limitOrderWt);								// 고객 주문 중량 (지정가 주문 중량)
		commLimitOrderRedisMsgVO.setLimitPremiumExclAmount(this.limitPremiumExclAmount);			// 지정가 프리미엄 제외 금액
		commLimitOrderRedisMsgVO.setLimitPremiumStdrAmount(this.limitPremiumStdrAmount);			// 프리미엄 기준 금액
		commLimitOrderRedisMsgVO.setLimitDstrctChangeAmount(this.limitDstrctChangeAmount);			// 권역 변동 금액
		commLimitOrderRedisMsgVO.setLimitBrandGroupChangeAmount(this.limitBrandGroupChangeAmount);	// 브랜드 그룹 변동 금액
		commLimitOrderRedisMsgVO.setLimitBrandChangeAmount(this.limitBrandChangeAmount);			// 브랜드 변동 금액
		
    	return commLimitOrderRedisMsgVO;
    }

	/**
	 * <pre>
	 * 처리내용: 주문_가단가 지정가 주문 데이터로 가단가 지정가 주문 Redis 메시지 공통 VO 객체 만들기
	 * </pre>
	 * @date 2024. 9. 11.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 11.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param intrfcSttusCode
	 * @return CommLimitOrderRedisMsgVO
	 */
	public CommPrvsnlLimitOrderRedisMsgVO getCommPrvsnlLimitOrderRedisMsgVO(String intrfcSttusCode) {

		// 가단가 지정가 주문 Redis 메시지 공통 VO 객체
		CommPrvsnlLimitOrderRedisMsgVO commPrvsnlLimitOrderRedisMsgVO = new CommPrvsnlLimitOrderRedisMsgVO();
		commPrvsnlLimitOrderRedisMsgVO.setLimitOrderNo(this.limitOrderNo);								// 지정가 주문 번호
		commPrvsnlLimitOrderRedisMsgVO.setIntrfcSttusCode(intrfcSttusCode);								// 인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제]
		commPrvsnlLimitOrderRedisMsgVO.setLimitOrderDt(String.valueOf(this.limitOrderTm));				// 지정가 주문일시 (ex. 2021-09-06 13:00:15.527)
		commPrvsnlLimitOrderRedisMsgVO.setMetalCode(this.metalCode);									// 금속 코드
		commPrvsnlLimitOrderRedisMsgVO.setLimitInputAmount(this.limitInputAmount);						// 지정가 입력 금액
		commPrvsnlLimitOrderRedisMsgVO.setPremiumPc(this.premiumPc.longValue());						// 프리미엄 가격

    	return commPrvsnlLimitOrderRedisMsgVO;
    }
}
