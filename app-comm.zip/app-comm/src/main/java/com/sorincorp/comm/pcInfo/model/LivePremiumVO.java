package com.sorincorp.comm.pcInfo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class LivePremiumVO implements Serializable, Comparable<LivePremiumVO> {
	private static final long serialVersionUID = -1500071179488318976L;
	
	/******  JAVA VO CREATE : IT_PREMIUM_STDR_BAS(상품_프리미엄 기준 기본)                                                                   ******/
    /**
     * 프리미엄 아이디
    */
    private String premiumId;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 유효 시작 일시
    */
    private String validBeginDt;
    /**
     * 유효 종료 일시
    */
    private String validEndDt;
    /**
     * 판매 방식 코드
    */
    private String sleMthdCode;
    /**
     * 프리미엄 기준 금액
    */
    private java.math.BigDecimal premiumStdrAmount;
    /**
     * 기준 아이템 여부
    */
    private String stdrItmAt;
    /**
     * 프리미엄 기준 권역 대분류 코드
    */
    private String premiumStdrDstrctLclsfCode;
    /**
     * 프리미엄 기준 브랜드 그룹 코드
    */
    private String premiumStdrBrandGroupCode;
    /**
     * 고정가 평균 구매 원가
    */
    private long hghnetprcAvrgPurchsPrmpc;
    /**
     * 브랜드 그룹 코드
    */
    private String brandGroupCode;
    /**
     * 브랜드 그룹 변동 금액
    */
    private java.math.BigDecimal brandGroupChangeAmount;
    
   /**
    * 브랜드 코드
   */
   private String brandCode;
   
   /**
	* 브랜드 이름
   */
   private String brandNm;
   
   /**
    * 브랜드 변동 금액
   */
   private java.math.BigDecimal brandChangeAmount;
   /**
    * 고정가 판매 금액
   */
   private long hghnetprcSleAmount;
   
   /**
    * 판매 프리미엄 금액
   */
   private long slePremiumAmount;
   
   private String dstrctLclsfCode;
   
   private java.math.BigDecimal dstrctChangeAmount;
   
   private String occrrncDe;
   
   private String premiumNo;
   
   private String termType;
   
   private String termValue;
   
   /**
   * 종목코드(메탈코드_아이템순번_권역 대분류 코드_브랜드 그룹 코드_브랜드 코드)
   */
   private String groupKey;
   
   /**
    * 실시간 판매가격과 프리미엄가격을 더한 판매가격
    */
   private long newSelPrice;
   
   /**
    * 시점 코드 [present: 현재 시점, past: 과거 시점]
    */
   private String timePointCode;

   @Override
   public int compareTo(LivePremiumVO other) {
	   
   	// premiumId를 기준으로 오름차순 정렬
   	return this.premiumId.compareTo(other.getPremiumId());
   }
}
