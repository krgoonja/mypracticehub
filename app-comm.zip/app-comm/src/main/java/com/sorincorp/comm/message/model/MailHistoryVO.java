package com.sorincorp.comm.message.model;

import org.springframework.validation.annotation.Validated;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * MailHistoryVO.java
 * @version
 * @since 2021. 7. 2.
 * @author srec0042
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Validated
public class MailHistoryVO extends MailVO{
	
	/**
	 *  serialVersion UID
	 */
	private static final long serialVersionUID = -8662716398760258801L;

	/**
     *  삭제 여부
    */
    private String deleteAt;
     
	/**
     *  삭제 일시
    */
    private String deleteDt;
    
    
	/**
     *   수신자 이메일
    */
    private String receiverEmail;
    
	/**
     *   수신 일자
    */
    private String receiveDt;
    
}
