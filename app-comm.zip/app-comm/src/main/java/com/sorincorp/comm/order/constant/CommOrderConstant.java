package com.sorincorp.comm.order.constant;

public class CommOrderConstant {
	/** 금속 코드 */
	public static final String METAL_NI = "8";  // 니켈
	public static final String METAL_SN = "9";  // 주석

	/** 차량 톤 코드 */
	public static final String VHCLE_TON_CODE_DEFAULT = "25000";
	public static final String[] VHCLE_TON_CODE_ARR = {"05000", "11000", "25000", "25000"};
	
	/** 통화 구분 코드 */
	public static final String KRW = "10";
	public static final String USD = "20";

	/** 단가 구분 코드 */
	public static final String AVRG_PC = "10"; // 가단가
	public static final String DCSN_PC = "20"; // 확정단가
}
