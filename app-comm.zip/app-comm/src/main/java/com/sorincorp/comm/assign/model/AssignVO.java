package com.sorincorp.comm.assign.model;

import lombok.Data;

@Data
public class AssignVO {
    /**
     * 업무 구분
    */
    private String jobSe;
    /**
     * 컬럼 명
    */
    private String columnNm;
    /**
     * 채번 구분
    */
    private String assgnSe;
    /**
     * 채번 값
    */
    private long assgnVal;
    /**
     * 사용자 ID
     */
    private String userId;
}
