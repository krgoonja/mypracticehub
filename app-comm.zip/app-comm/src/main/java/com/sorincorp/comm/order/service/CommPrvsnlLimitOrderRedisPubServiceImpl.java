package com.sorincorp.comm.order.service;

import java.util.Optional;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.order.constant.CommLimitOrderConstant;
import com.sorincorp.comm.order.model.CommOrLimitOrderBasVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderRedisMsgVO;
import com.sorincorp.comm.redis.config.RedisPubSubService;

import lombok.extern.slf4j.Slf4j;

/**
 * CommPrvsnlLimitOrderRedisPubServiceImpl.java
 * 가단가 지정가 주문 Redis Publish 공통 Service 구현체 클래스
 *
 * @version
 * @since 2024. 9. 11.
 * @author srec0066
 */
@Slf4j
@Service
public class CommPrvsnlLimitOrderRedisPubServiceImpl implements CommPrvsnlLimitOrderRedisPubService {

	/** Redis PubSub 공통 Service */
	@Autowired
	private RedisPubSubService redisPubSubService;

	/** 가단가 주문 Service */
	@Autowired
	private CommPrvsnlOrderService commPrvsnlOrderService;

	/** 가단가 지정가 주문 Redis Publish - LME 채널 URL */
	private String lmeChannel = CommLimitOrderConstant.REDISPUPSUB_URL_LME_LIMITORDER;

	/** 가단가 지정가 주문 Redis Publish - FX 채널 URL */
	private String fxChannel = CommLimitOrderConstant.REDISPUPSUB_URL_FX_LIMITORDER;

	/**
	 * LME/KRW - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
	 */
	@Override
	public void prvsnlLimitOrderMsgLmePublish(String limitOrderNo, String intrfcSttusCode) throws Exception {

		try {
			/**
			 * 1. Redis 메시지 전용 지정가 주문 번호로 해당 지정가 주문 내역 가져오기 [단일]
			 * 2. Redis에 [지정가 주문 Redis 메시지] 발행
			 * **/

			log.info(">> [prvsnlLimitOrderMsgLmePublish] in");
			log.info(">> [prvsnlLimitOrderMsgLmePublish] limitOrderNo : " + limitOrderNo + ", intrfcSttusCode : " + intrfcSttusCode);

			/**
			 * 1. Redis 메시지 전용 지정가 주문 번호로 해당 지정가 주문 내역 가져오기 [단일]
			 * **/
			CommOrLimitOrderBasVO selectCommOrLimitOrderBas = commPrvsnlOrderService.selectCommOrPrvsnlOrderBas(limitOrderNo);
			log.info(">> [prvsnlLimitOrderMsgLmePublish] selectCommOrLimitOrderBas : " + String.valueOf(selectCommOrLimitOrderBas));
			Optional.ofNullable(selectCommOrLimitOrderBas).orElseThrow(() -> {return new CommCustomException("[1]가단가 지정가 주문 내역 미존재.");});

			/**
			 * 2. Redis에 [지정가 주문 Redis 메시지] 발행
			 *  1) 주문_지정가 주문 기본 정보 조회 데이터로 지정가 주문 Redis 메시지 공통 VO 객체 만들기
			 *  2) 지정가 주문 Redis 메시지 Redis로 발행하기
			 *  3) 실패 시 알림 보내기
			 * **/
			// 주문_지정가 주문 기본 정보 조회 데이터로 지정가 주문 Redis 메시지 공통 VO 객체 만들기
			CommPrvsnlLimitOrderRedisMsgVO commOrLimitOrderBasVO = selectCommOrLimitOrderBas.getCommPrvsnlLimitOrderRedisMsgVO(intrfcSttusCode);
			log.info(">> [prvsnlLimitOrderMsgLmePublish] commOrLimitOrderBasVO : " + String.valueOf(commOrLimitOrderBasVO));
			Optional.ofNullable(commOrLimitOrderBasVO).orElseThrow(() -> {return new CommCustomException("[1]가단가 지정가 주문 Redis 메시지 미존재.");});

			// 지정가 주문 Redis 메시지 Redis로 발행하기
			redisPubSubService.publishMessage(lmeChannel, lmeChannel, commOrLimitOrderBasVO);

		} catch(Exception e) {
			String stacktrace = ExceptionUtils.getStackTrace(e);
			log.error("[prvsnlLimitOrderMsgLmePublish][redis msg publish fail] : " + stacktrace);

			// exception 던져주기
			throw new CommCustomException(e);
		}
	}

	/**
	 * FX - 가단가 지정가 주문 Redis에 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
	 */
	@Override
	public void prvsnlLimitOrderMsgFxPublish(String limitOrderNo, String intrfcSttusCode) throws Exception {

		try {
			/**
			 * 1. Redis 메시지 전용 지정가 주문 번호로 해당 지정가 주문 내역 가져오기 [단일]
			 * 2. Redis에 [지정가 주문 Redis 메시지] 발행
			 * **/

			log.info(">> [prvsnlLimitOrderMsgLmePublish] in");
			log.info(">> [prvsnlLimitOrderMsgLmePublish] limitOrderNo : " + limitOrderNo + ", intrfcSttusCode : " + intrfcSttusCode);

			/**
			 * 1. Redis 메시지 전용 지정가 주문 번호로 해당 지정가 주문 내역 가져오기 [단일]
			 * **/
			CommOrLimitOrderBasVO selectCommOrLimitOrderBas = commPrvsnlOrderService.selectCommOrPrvsnlOrderBas(limitOrderNo);
			log.info(">> [prvsnlLimitOrderMsgLmePublish] selectCommOrLimitOrderBas : " + String.valueOf(selectCommOrLimitOrderBas));
			Optional.ofNullable(selectCommOrLimitOrderBas).orElseThrow(() -> {return new CommCustomException("[2]가단가 지정가 주문 내역 미존재.");});

			/**
			 * 2. Redis에 [지정가 주문 Redis 메시지] 발행
			 *  1) 주문_지정가 주문 기본 정보 조회 데이터로 지정가 주문 Redis 메시지 공통 VO 객체 만들기
			 *  2) 지정가 주문 Redis 메시지 Redis로 발행하기
			 *  3) 실패 시 알림 보내기
			 * **/
			// 주문_지정가 주문 기본 정보 조회 데이터로 지정가 주문 Redis 메시지 공통 VO 객체 만들기
			CommPrvsnlLimitOrderRedisMsgVO commOrLimitOrderBasVO = selectCommOrLimitOrderBas.getCommPrvsnlLimitOrderRedisMsgVO(intrfcSttusCode);
			log.info(">> [prvsnlLimitOrderMsgLmePublish] commOrLimitOrderBasVO : " + String.valueOf(commOrLimitOrderBasVO));
			Optional.ofNullable(commOrLimitOrderBasVO).orElseThrow(() -> {return new CommCustomException("[2]가단가 지정가 주문 Redis 메시지 미존재.");});

			// 지정가 주문 Redis 메시지 Redis로 발행하기
			redisPubSubService.publishMessage(fxChannel, fxChannel, commOrLimitOrderBasVO);

		} catch(Exception e) {
			String stacktrace = ExceptionUtils.getStackTrace(e);
			log.error("[prvsnlLimitOrderMsgFxPublish][redis msg publish fail] : " + stacktrace);

			// exception 던져주기
			throw new CommCustomException(e);
		}
	}

}
