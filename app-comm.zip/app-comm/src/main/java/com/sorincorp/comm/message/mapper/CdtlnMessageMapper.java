package com.sorincorp.comm.message.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sorincorp.comm.message.model.OrderInfoVO;

/**
 * CdtlnMessageMapper.java : 여신 메세지/이메일 발송 공통서비스
 * @version
 * @since 2022. 8. 18.
 * @author srec0066
 */
public interface CdtlnMessageMapper {

	/**
	 * <pre>
	 * 처리내용: SMS 발송대상 데이터를 조회한다.
	 * </pre>
	 * @date 2022. 8. 18.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 18.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	List<Map<String, String>> selectCdtlnMessageData(@Param("orderNo") String orderNo, @Param("mdstrmRepySn") Long mdstrmRepySn);

	/**
	 * <pre>
	 * 처리내용: 메일 발송대상 데이터를 조회한다.
	 * </pre>
	 * @date 2022. 8. 19.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 19.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	OrderInfoVO selectCdtlnEmailData(String orderNo);

	/**
	 * <pre>
	 * 처리내용: 주문_미납 주문 관리 기본 Insert
	 * </pre>
	 * @date 2022. 9. 20.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 20.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param param
	 */
	void insertNpyOrderManage(Map<String, String> param);

	/**
	 * <pre>
	 * 처리내용: 주문_미납 주문 관리 기본 이력 관리
	 * </pre>
	 * @date 2022. 9. 20.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 20.			srec0053			최초작성
	 * 2022. 12.01.			srec0070			이력테이블 등록 파라미터 수정
	 * ------------------------------------------------
	 * @param param
	 */
	void insertNpyOrderManageHst(Map<String, String> param);

	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 거래정보를 가져온다.
	 * </pre>
	 * @date 2022. 12. 9.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 9.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param orderInfo
	 * @return
	 */
	List<OrderInfoVO> selectSorinCredtInfo(OrderInfoVO orderNo);
	
	
	/**
	 * <pre>
	 * 처리내용: 해당 주문번호의 보증번호와 업체번호 정보를 가져온다.
	 * </pre>
	 * @date 2022. 12. 26.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 26.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	OrderInfoVO selectMemberInfo(OrderInfoVO orderNo);
	
	
	/**
	 * <pre>
	 * 처리내용: 총 사용 가능액을 조회한다.
	 * </pre>
	 * @date 2023. 1. 11.
	 * @author srec0072
	 * @history 
	 * ------------------------------------------------
	 * 변경일 					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 1. 11.			srec0072			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	Long selectTotalMrtggBlce(OrderInfoVO orderNo);
	
	/**
	 * 
	 * <pre>
	 * 처리내용: 해당 주문번호의 판매방식정보를 가져온다.
	 * </pre>
	 * @date 2023. 12. 4.
	 * @author srec0083
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 12. 4.			srec0083			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 */
	Map<String, String> selectSleMthdInfo(String orderNo);
	
	/**
	 * <pre>
	 * 처리내용: 출고중지 및 출고중지 해제 SMS 정보 가져오기
	 * </pre>
	 * @date 2024. 7. 19.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 7. 19.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectDlivyStpgeRelisSmsInfo(@Param("orderNo") String orderNo, @Param("outptAmount") Long outptAmount) throws Exception;

}
