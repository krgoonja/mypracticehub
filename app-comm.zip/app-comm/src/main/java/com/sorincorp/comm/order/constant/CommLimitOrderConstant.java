package com.sorincorp.comm.order.constant;


/**
 * CommLimitOrderConstant.java
 *
 *
 * @version
 * @since 2023. 4. 26.
 * @author srec0049
 */
public class CommLimitOrderConstant {

	private CommLimitOrderConstant() {
		throw new IllegalStateException("");
	}

	/**
	 * [임시] 지정가 주문 Redis Publish 채널 URL
	 */
	public static final String REDISPUPSUB_URL_LIMITORDER = "/limit/orderManager";

	/**
	 *  가단가 지정가 주문 Redis Publish 채널 URL - LME/FX
	 */
	public static final String REDISPUPSUB_URL_LME_LIMITORDER = "/prvsnlLimit/lme";
	public static final String REDISPUPSUB_URL_FX_LIMITORDER = "/prvsnlLimit/fx";

	/* parameter list 1 */
	public static final  String LIMIT_ORDER_NO = "limitOrderNo";
	public static final  String TYPE = "type";

	/* parameter list 2 - Required For Update */
	public static final  String ORI_AMOUNT = "oriAmount";
	public static final  String ORI_WT = "oriWt";
	
    /* data list 1 - For publish URI*/
	public static final  String METAL_CODE = "metalCode";
	public static final  String ITM_SN = "itmSn";
	public static final  String DSTRCT_LCLSF_CODE = "dstrctLclsfCode";
	public static final  String BRAND_GROUP_CODE = "brandGroupCode";
	public static final  String BRAND_CODE = "brandCode";
	
	/* data list 2 - For rendering */
	public static final  String LIMIT_INPUT_AMOUNT = "limitInputAmount";
	public static final  String ENTRPS_NO = "entrpsNo";
	public static final  String LIMIT_ORDER_WT = "limitOrderWt";
	public static final  String LIMIT_ORDER_WT_CNT = "limitOrderWtCnt";
	public static final  String ORI_WT_CNT = "oriWtCnt";
}
