package com.sorincorp.comm.order.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * OrOrderAvrgpcDtlVO.java
 * 주문_주문 평균가 상세 VO 객체
 * @version
 * @since 2023. 10. 13.
 * @author srec0066
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class OrOrderAvrgpcDtlVO {
   /**
    * 주문 번호
   */
   private String orderNo;
   /**
    * 단가 구분 코드
   */
   private String untpcSeCode;
   /**
    * 발생 일자
   */
   private String occrrncDe;
   /**
    * 금속 코드
   */
   private String metalCode;
   /**
    * 아이템 순번
   */
   private int itmSn;
   /**
    * 권역 대분류 코드
   */
   private String dstrctLclsfCode;
   /**
    * 브랜드 그룹 코드
   */
   private String brandGroupCode;
   /**
    * 브랜드 코드
   */
   private String brandCode;
   /**
    * LME CSP 가격
   */
   private java.math.BigDecimal lmeCsp;
   /**
    * 달러환산률
   */
   private java.math.BigDecimal usdCvtrate;
   /**
    * LME 조정 계수
   */
   private java.math.BigDecimal lmeMdatCffcnt;
   /**
    * FX 조정 계수
   */
   private java.math.BigDecimal fxMdatCffcnt;
   /**
    * 삭제 일시
   */
   private java.sql.Timestamp deleteDt;
   /**
    * 삭제 여부
   */
   private String deleteAt;
   /**
    * 최초 등록 일시
   */
   private java.sql.Timestamp frstRegistDt;
   /**
    * 최종 변경 일시
   */
   private java.sql.Timestamp lastChangeDt;
   /**
    * LME 평균
    */
   private java.math.BigDecimal lmeAvrg;
   /**
    * 환율 평균
    */
   private java.math.BigDecimal ehgtAvrg;
   /**
    * 회원 아이디
   */
   private String mberId;
}
