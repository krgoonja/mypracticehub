package com.sorincorp.comm.pcInfo.mapper;

import java.util.List;

import com.sorincorp.comm.pcInfo.model.FixPrice2VO;
import com.sorincorp.comm.pcInfo.model.FixPriceVO;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.LmePcVO;
import com.sorincorp.comm.pcInfo.model.PcMntrngSelVO;
import com.sorincorp.comm.pcInfo.model.PrEhgtRltmVO;
import com.sorincorp.comm.pcInfo.model.PrEhgtStdrVO;
import com.sorincorp.comm.pcInfo.model.PrEhgtVO;
import com.sorincorp.comm.pcInfo.model.PrPremiumSelVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.pcInfo.model.PreminumInfoDto;
import com.sorincorp.comm.pcInfo.model.PreminumSelInfoVO;
import com.sorincorp.comm.pcInfo.model.RvcmpnVO;

public interface PcInfoMapper {


	/**
	 * <pre>
	 * LME 실시간 가격정보
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 14.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return vo
	 * @throws Exception
	 */
	LmePcVO getPrLmeRltm(LmePcVO vo) throws Exception;

	/**
	 * <pre>
	 * LME 전일 종가
	 * </pre>
	 * @date 2024. 10. 22.
	 * @author hamyoonsic
	 * @history
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 10. 22.		hamyoonsic		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return vo
	 * @throws Exception
	 */
	LmePcVO getPrLmeAgo(LmePcVO vo) throws Exception;
	
	/**
	 * <pre>
	 * LME 기준 가격정보
	 * </pre>
	 * @date 2021. 7. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return vo
	 * @throws Exception
	 */
	LmePcVO getPrLmeStdr(LmePcVO vo) throws Exception;
	
	/**
	 * <pre>
	 * LME 일 가격정보
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	LmePcVO getPrLmeDe(LmePcVO vo) throws Exception;
	
	/**
	 * <pre>
	 * LME 주 가격정보
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	LmePcVO getPrLmeWeek(LmePcVO vo) throws Exception;
	
	/**
	 * <pre>
	 * LME 월 가격정보
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	LmePcVO getPrLmeMt(LmePcVO vo) throws Exception;
	
	/**
	 * <pre>
	 * LME 분기 가격정보
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	LmePcVO getPrLmeQu(LmePcVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 판매 실시간 가격 정보
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	PrSelVO getPrSelRltm(PrSelVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 기준 매매가 일 평균 정보
	 * </pre>
	 * @date 2022. 7. 20.
	 * @author hyunjin05
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 7. 20.		hyunjin05		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	PrSelVO getAvgDeEndPrice(PrSelVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 기준 매매가 일 평균 정보 목록
	 * </pre>
	 * @date 2022. 7. 20.
	 * @author hyunjin05
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 6. 23.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<PrSelVO> getAvgDeEndPriceList(PrSelVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 등록일자보다 과거의 가장 최근의 판매 가격 정보를 가져온다.
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 9.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	PrSelVO getNewestPrSelDe(PrSelVO vo)throws Exception;
	
	/**
	 * <pre>
	 * 판매 가격 기준
	 * </pre>
	 * @date 2021. 7. 21.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 21.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	PrSelVO getPrSelStdr(PrSelVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 판매 일 가격정보
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	PrSelVO getPrSelDe(PrSelVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 판매 주 가격정보
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	PrSelVO getPrSelWeek(PrSelVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 판매 월 가격정보
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	PrSelVO getPrSelMt(PrSelVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 판매 분기 가격 정보
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 7. 20.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	PrSelVO getPrSelQu(PrSelVO vo) throws Exception;
	
	
	
	/**
	 * <pre>
	 * 기간별 환율 정보 조회
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ehgtDelngCrncyCode :통화, 
	 *        occrrncType : 기간별 구분 코드(DD : 일별, WEEK : 주별, MT : 달별, QU : 분기별) 
	 *        occrrncValue : 기간값
	 * @return
	 */
	PrEhgtVO getPrEhgtSn(PrEhgtVO vo) throws Exception;
	/**
	 * <pre>
	 * 기간별 순번으로 환율 정보 조회
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param occrrncSn : 순번
	 *        occrrncType : 기간별 구분 코드(DD : 일별, WEEK : 주별, MT : 달별, QU : 분기별) 
	 *        occrrncValue : 기간값
	 * @return
	 */
	PrEhgtRltmVO getPrEhgtRltm(PrEhgtRltmVO vo) throws Exception;
	/**
	 * <pre>
	 * 통화 발생일자, 발생시간, 순번으로 실시간 환율 조회
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ehgtDelngCrncyCode : 통화
	 *        occrrncDe          : 발생일자
	 *        occrrncTime        : 발생시간
	 *        occrrncSn          : 순번
	 * @return
	 */
	PrEhgtRltmVO getPrEhgtRltmSn(PrEhgtRltmVO vo) throws Exception;
	/**
	 * <pre>
	 * 현시간 환율 실시간 가격을 조회한다
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ehgtDelngCrncyCode : 통화
	 *        occrrncDe          : 발생일자
	 * @return
	 */
	PrEhgtStdrVO getPrEhgtStdr(PrEhgtStdrVO vo) throws Exception;

	/**
	 * <pre>
	 * 전일 거래용 환율 조회
	 * </pre>
	 * @date 2024. 10. 22.
	 * @author hamyoonsic
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2024. 10. 22.			hamyoonsic			최초작성
	 * ------------------------------------------------
	 * @param
	 * @return
	 */
	PrEhgtStdrVO getPrEhgtAgo() throws Exception;
	
//	사용하는 곳 없음 20230525
//	/**
//	 * <pre>
//	 * LIVE 프리미엄 가격 조회
//	 * </pre>
//	 * @date 2021. 7. 14.
//	 * @author srec0031
//	 * @history 
//	 * ------------------------------------------------
//	 * 변경일					작성자				변경내용
//	 * ------------------------------------------------
//	 * 2021. 7. 14.			srec0031			최초작성
//	 * ------------------------------------------------
//	 * @param metalCode : 메탈코드
//	 *        itmSn : 아이템 순번
//	 *        dstrctLclsfCode : 권역 대분류 코드
//	 *        brandGroupCode : 브랜드 그룹 코드
//	 *        brandCode : 브랜드 코드
//	 * @return
//	 */
//	LivePremiumVO getLivePremium(LivePremiumVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 시점 코드 [present: 현재 시점, past: 과거 시점]에 따른 프리미엄 가격 정보 리스트 가져오기
	 * </pre>
	 * @date 2023. 5. 25.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 25.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param livePremiumVO
	 * @return
	 * @throws Exception
	 */
	public List<LivePremiumVO> getLivePremiumInfoList(LivePremiumVO livePremiumVO) throws Exception;
	
	/**
	 * <pre>
	 * 일/월별 LIVE 평균 프리미엄 가격 조회
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param metalCode : 메탈코드
	 *        itmSn : 아이템 순번
	 *        dstrctLclsfCode : 권역 대분류 코드
	 *        brandGroupCode : 브랜드 그룹 코드
	 *        brandCode : 브랜드 코드
	 *        termType : 일 / 월 구분 코드 (DD, MM)
	 *        termValue : 일 / 월 값
	 * @return
	 */
	LivePremiumVO getLivePremiumByTerm(LivePremiumVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 고정가 판매 가격 조회
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param metalCode : 메탈코드
	 *        itmSn : 아이템 순번
	 *        dstrctLclsfCode : 권역 대분류 코드
	 *        brandGroupCode : 브랜드 그룹 코드
	 *        brandCode : 브랜드 코드
	 *        entrpsGradNo : 업체 등급번호
	 * @return
	 */
	FixPriceVO getFixPrice(FixPriceVO vo) throws Exception;
	/**
	 * <pre>
	 * 고정가 판매 가격 데이터가 있는지 여부 조회
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param metalCode : 메탈코드
	 *        itmSn : 아이템 순번
	 *        dstrctLclsfCode : 권역 대분류 코드
	 *        brandGroupCode : 브랜드 그룹 코드
	 *        brandCode : 브랜드 코드
	 * @return
	 */
	FixPriceVO hasFixPriceData(FixPriceVO vo);
	
	/**
	 * <pre>
	 * 처리내용: 케이지몰 상품아이템/업체별 가격정보 조회
	 * </pre>
	 * @date 2023. 3. 7.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 7.			srec0061			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	List<FixPriceVO> hasEntrpsFixPriceData(FixPriceVO vo);
	/**
	 * <pre>
	 * 고정가 판매 가격 조회
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param metalCode : 메탈코드
	 *        itmSn : 아이템 순번
	 *        brandGroupCode : 브랜드 그룹 코드
	 *        brandCode : 브랜드 코드
	 *        occrrncDe : 발생일자
	 * @return
	 */
	List<FixPriceVO> getFixPrice3(FixPriceVO vo);
	
	/**
	 * <pre>
	 * 일/월별 고정가 평균 판매가격 조회
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param metalCode : 메탈코드
	 *        itmSn : 아이템 순번
	 *        dstrctLclsfCode : 권역 대분류 코드
	 *        brandGroupCode : 브랜드 그룹 코드
	 *        brandCode : 브랜드 코드
	 *        entrpsGradNo : 업체 등급번호
	 *        termType : 일 / 월 구분 코드 (DD, MM)
	 *        termValue : 일 / 월 값
	 * @return
	 */
	FixPriceVO getFixPriceByTerm(FixPriceVO vo) throws Exception;

	/**
	 * <pre>
	 * 일, 주, 월, 분기별 인조식별자 순번을 입력해 환율 시세를 조회한다.(캐시 등록, 순번 조회)
	 * </pre>
	 * @date 2021. 7. 14.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 14.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param occrrncSn : 순번
	 * @param occrrncType : 기간별 구분 코드(DD : 일별, WW : 주별, MM : 달별, QU : 분기별) 
	 * @return
	 */
	PrEhgtVO getPrEhgt(PrEhgtVO vo) throws Exception;

	/**
	 * <pre>
	 * 메탈코드 입력으로 LIVE 프리미엄 기준아이템 가격 조회
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 9.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param metalCode : 메탈코드
	 * @return
	 */
	LivePremiumVO getLivePremiumStdrByMetalCode(LivePremiumVO vo);
	/**
	 * <pre>
	 * 적용일자, 브랜드코드, 메탈코드 입력으로 경쟁사 가격을 조회
	 * </pre>
	 * @date 2021. 9. 9.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 9.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param applcDe : 적용일자
	 * @param brandGroupCode : 브랜드그룹코드
	 * @param metalCode : 메탈코드
	 * @return
	 */
	RvcmpnVO getRvcmpn(RvcmpnVO vo);
	
	/**
	 * <pre>
	 * 적용일자, 브랜드코드, 메탈코드 입력으로 경쟁사 가격을 조회
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param applcDe : 적용일자
	 * @param metalCode : 메탈코드
	 * @return
	 */
	List<RvcmpnVO> getRvcmpn2(RvcmpnVO vo);
	
	/**
	 * <pre>
	 * 적용일자, 브랜드코드, 메탈코드 입력으로 경쟁사 가격을 조회
	 * </pre>
	 * @date 2021. 10. 25.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 25.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param applcDe : 적용일자
	 * @param metalCode : 메탈코드
	 * @return
	 */
	List<RvcmpnVO> getRvcmpnList(RvcmpnVO vo);
	
	/**
	 * <pre>
	 * 통화를 입력해 최신 환율 시세를 조회한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ehgtDelngCrncyCode (통화)
	 * @return
	 */
	PrEhgtRltmVO getNewestPrEhgtRltm(PrEhgtRltmVO vo);
	
	/**
	 * <pre>
	 * 통화와 발생날짜를 입력해 오늘 날짜 이전의 일별 가장 마지막 환율 시세를 조회한다.
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param ehgtDelngCrncyCode (통화)
	 * @param occrrncDe (발생 일자 YYYYMMDD)
	 * @return
	 */
	PrEhgtRltmVO getNewestPrEhgtRltmByDay(PrEhgtRltmVO vo);
	/**
	 * <pre>
	 * 프리미엄 기준아이템 브랜드 그룹 조회 
	 * </pre>
	 * @date 2021. 9. 10.
	 * @author srec0031
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 10.			srec0031			최초작성
	 * ------------------------------------------------
	 * @param metalCode : 금속코드
	 * @param brandGroupCode : 브랜드그룹
	 * @return
	 */
	List<LivePremiumVO> getStdrPremiumList(LivePremiumVO vo);

	List<FixPrice2VO> getFixPrice4(FixPrice2VO vo);
	
	/**
	 * <pre>
	 * 처리내용: 종목별 프리미엄 정보 조회
	 * </pre>
	 * @date 2023. 5. 9.
	 * @author srec0061
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 9.			srec0061			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	List<LivePremiumVO> getPremiumInfoMap();

	/**
	 * <pre>
	 * 처리내용: 메인차트 타이틀의 시가,고가,저가,종가 및 전날종가, 등락률 정보를 가져온다.
	 * </pre>
	 * @date 2023. 5. 15.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 15.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param prSelVO
	 * @return
	 */
	PrSelVO getChartTitleInfo(PrSelVO prSelVO);
	
	/**
	 * <pre>
	 * 처리내용: 임시
	 * </pre>
	 * @date 2023. 7. 6.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2023. 7. 6.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param prSelVO
	 * @return
	 */
	List<PrSelVO> getBrandGroupPriceInfoList(PrSelVO prSelVO);

	/**
	 * <pre>
	 * 1분 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcMntrngSelVO> getPcMngtrngSel1MinList(PcMntrngSelVO pcMntrngSelVO);
	
	/**
	 * <pre>
	 * 30분 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 8. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcMntrngSelVO> getPcMngtrngSel30MinList(PcMntrngSelVO pcMntrngSelVO);
	
	/**
	 * <pre>
	 * 60분 단위 판매가격 리스트
	 * </pre>
	 * @date 2021. 11. 25.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 11. 25.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcMntrngSelVO> getPcMngtrngSel60MinList(PcMntrngSelVO pcMntrngSelVO);
	
	/**
	 * <pre>
	 * 일 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 26.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcMntrngSelVO> getPcMngtrngSelDeList(PcMntrngSelVO pcMntrngSelVO);
	
	/**
	 * <pre>
	 * 월 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2021. 8. 26.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 8. 26.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcMntrngSelVO> getPcMngtrngSelMonthList(PcMntrngSelVO pcMntrngSelVO);
	
	/**
	 * <pre>
	 * 전일 기준 가격 차트 데이터를 가져온다.
	 * </pre>
	 * @date 2023. 7. 3.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 7. 3.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param pcMntrngSelVO
	 * @return
	 */
	List<PcMntrngSelVO> getEndPcAgoSelDeList(PcMntrngSelVO pcMntrngSelVO);
	
	/**
	 * <pre>
	 * 처리내용: 메탈코드, 아이템코드, 권역코드, 브랜드그룹코드, 브랜드코드별 차트타이틀 리스트
	 * </pre>
	 * @date 2023. 7. 12.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 12.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param prPremiumSelVO
	 * @return
	 */
	List<PrPremiumSelVO> getChartTitleInfoList(String metalCode);
	
	/**
	 * <pre>
	 * 프리미엄 가격 리스트
	 * </pre>
	 * @date 2023. 07. 24.
	 * @author srec0067
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2023. 07. 24.		srec0067		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param preminumInfoDto
	 * @return
	 */
	List<PreminumSelInfoVO> getFnPreminumInfoList(PreminumInfoDto preminumInfoDto);
}
