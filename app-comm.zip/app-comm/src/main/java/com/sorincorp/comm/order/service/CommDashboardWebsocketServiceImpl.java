package com.sorincorp.comm.order.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.btb.comm.HttpClientHelper;
import com.sorincorp.comm.order.mapper.CommLimitOrderMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@PropertySource(value = "classpath:/config/order/order-${spring.profiles.active}.properties", ignoreResourceNotFound = true)
public class CommDashboardWebsocketServiceImpl implements CommDashboardWebsocketService {

	@Autowired
	private SimpMessagingTemplate simpMessagingTemplate;

	@Autowired
	private CommLimitOrderMapper commLimitOrderMapper;

	/** 외부 연계 api 호출 모듈 */
	@Autowired
	private HttpClientHelper httpClientHelper;

	@Value("${order.limit.websocket.pub.api.bo}")
	private String pubBoLimitOrderUrl;	// /bo/ma/dashboard/limitOrder

	@Value("${order.live.websocket.pub.api.bo}")
	private String pubBoOrderUrl;
	
	@Value("${order.diverRunning.websocket.pub.api.bo}")
	private String pubBoDiverRunningUrl;

	@Value("${order.rcpmny.websocket.pub.api.bo}")
	private String pubBoRcpmnyUrl;


	private static final String SUBSCRIBER_URL_LIVE="/subscriber/dashboard/order";
	private static final String SUBSCRIBER_URL_LIMIT="/subscriber/dashboard/limitOrder";
	private static final String SUBSCRIBER_URL_DIVERRUNNING="/subscriber/dashboard/diverRunning";
	private static final String SUBSCRIBER_URL_RCPMNY="/subscriber/dashboard/rcpmny";


	/**
	 *	라이브 주문정보 websocket publish TODO: 라이브 사용시 보완 필요
	 */
	@Override
	public void publishLiveOrder(String orderNo, boolean isApiCall) {
		log.info("[CommDashboardWebsocketServiceImpl] publishLiveOrder IN");
		try {
			if (isApiCall) {
				httpClientHelper.getCallApi(pubBoOrderUrl+ "/"+ orderNo);
			} else {
				simpMessagingTemplate.convertAndSend(SUBSCRIBER_URL_LIVE, orderNo);
			}
		} catch (Exception e) {
			log.error("[CommDashboardWebsocketServiceImpl] publishLiveOrder ERROR :: {}", e);
		}
	}



	/**
	 *	기준 프리미엄 환산 금액 조회
	 */
	@Override
	public long selectStdrPremiumCnvrsnAmount(String limitOrderNo) throws Exception {
		return commLimitOrderMapper.selectStdrPremiumCnvrsnAmount(limitOrderNo);
	}



	/**
	 *	지정가 주문정보 websocket publish
	 */
	@Override
	public void publishLimitOrder(String limitOrderNo, boolean isApiCall) {
		log.debug("[CommDashboardWebsocketServiceImpl] publishLimitOrder IN");
		try {

			long stdrPremiumCnvrsnAmount = selectStdrPremiumCnvrsnAmount(limitOrderNo);
			log.debug("[CommDashboardWebsocketServiceImpl] stdrPremiumCnvrsnAmount :: {}", stdrPremiumCnvrsnAmount);

			if (isApiCall) {
				httpClientHelper.getCallApi(pubBoLimitOrderUrl+ "/"+ limitOrderNo);
			} else {
				simpMessagingTemplate.convertAndSend(SUBSCRIBER_URL_LIMIT, stdrPremiumCnvrsnAmount);
			}

		} catch (Exception e) {
			log.error("[CommDashboardWebsocketServiceImpl] publishLimitOrder ERROR :: ", e);
		}
	}
	

	/**
	 *	다이버 작동 websocket publish
	 */
	@Override
	public void publishDiverRunning(boolean runningAt, boolean isApiCall) {
		log.info("[CommDashboardWebsocketServiceImpl] publishDiverRunning IN");
		try {
			if (isApiCall) {
				httpClientHelper.getCallApi(pubBoDiverRunningUrl+ "/"+ String.valueOf(runningAt));
			} else {
				simpMessagingTemplate.convertAndSend(SUBSCRIBER_URL_DIVERRUNNING, String.valueOf(runningAt));
			}
		} catch (Exception e) {
			log.error("[CommDashboardWebsocketServiceImpl] publishDiverRunning ERROR :: {}", e);
		}
	}

	/**
	 *	가격 변동금 입금관련 이벤트 발생 websocket publish
	 */
	@Override
	public void publishRcpmnyEvent(String orderNo, boolean isApiCall) {
		log.debug("[CommDashboardWebsocketServiceImpl] publishRcpmnyEvent IN");
		try {
			if (isApiCall) {
				httpClientHelper.getCallApi(pubBoRcpmnyUrl+ "/"+ orderNo);
			} else {
				simpMessagingTemplate.convertAndSend(SUBSCRIBER_URL_RCPMNY, orderNo);
			}

		} catch (Exception e) {
			log.error("[CommDashboardWebsocketServiceImpl] publishRcpmnyEvent ERROR :: ", e);
		}
	}

}
