package com.sorincorp.comm.message.service;

import java.util.Map;

import com.sorincorp.comm.message.model.AppPushQueueVO;
import com.sorincorp.comm.message.model.KkoMsgVO;
import com.sorincorp.comm.message.model.MessageTemplateVO;
import com.sorincorp.comm.message.model.SMSVO;


/**
 * SMSService.java
 * @version
 * @since 2021. 6. 21.
 * @author srec0041
 */
public interface SMSService {

	/**
	 * <pre>
	 * 메시지 템플릿에 저장된 템플릿정보 조회
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 21.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param templateNum
	 * @return
	 */
	public abstract MessageTemplateVO selectMessageTemplate(String templateNum);

	/**
	 * <pre>
	 * SMS 또는 LMS 발송 및 알림톡 발송, sms 발송 히스토리 입력
	 *   예외 발송 옵션 여부(excpSndngOptnAt)가 Y이면 SMS 수신자는 보내지 않는다
	 *   예외 발송 옵션 여부(excpSndngOptnAt)가 N이면 내부사용자는 보내지 않는다
	 *   예외 발송 옵션 여부(excpSndngOptnAt)가 null이거나 값이 존재하지 않으면 SMS 수신자, 내부사용자 모두 보낸다.
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 21.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param smsVO
	 * @param map
	 */
	public abstract void insertSMS(SMSVO smsVO, Map<String, String> map);

	/**
	 * <pre>
	 * 알림톡 보내기 위한 정보입력
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 21.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param kkoVO
	 * @param map
	 * @throws Exception 
	 */
	public abstract void insertKkoMsg(KkoMsgVO kkoVO, Map<String, String> map) throws Exception;

	// 광고동의한 사람한테 보내기 appVO.setOptagree("1000")
	/**
	 * <pre>
	 * 앱푸쉬 발송
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param appVO
	 * @param map
	 */
	public abstract void insertAppPush(AppPushQueueVO appVO, Map<String, String> map);

	/**
	 * <pre>
	 * SMS 또는 LMS 발송 및 알림톡 발송, sms 발송 히스토리 입력 후 mssageSndngHistNo 리턴
	 *   예외 발송 옵션 여부(excpSndngOptnAt)가 Y이면 SMS 수신자는 보내지 않는다
	 *   예외 발송 옵션 여부(excpSndngOptnAt)가 N이면 내부사용자는 보내지 않는다
	 *   예외 발송 옵션 여부(excpSndngOptnAt)가 null이거나 값이 존재하지 않으면 SMS 수신자, 내부사용자 모두 보낸다.
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0068
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0068			최초작성
	 * ------------------------------------------------
	 * @param smsVO
	 * @param map
	 */
	public abstract String insertSMSByReturnMssageSndngHistNo(SMSVO smsVO, Map<String, String> map);

}
