package com.sorincorp.comm.order.model;

import lombok.Data;

/**
 * CommPrvsnlOrderVO.java
 * 가단가 주문 공통 VO 객체
 * @version
 * @since 2024. 10. 2.
 * @author srec0066
 */
@Data
public class CommPrvsnlOrderVO {

	/** 주문번호 **/
	private String orderNo;

	/** 판매 방식 코드 **/
	private String sleMthdCode;

	/** 판매 방식 상세 코드 **/
	private String sleMthdDetailCode;

	/** 결제 방식 코드 */
	private String setleMthdCode;

	/** 상품 단가 **/
	private long goodsUntpc;

	 /** 평균가 상품 단가 */
    private long avrgpcGoodsUntpc;

    /** 정산 금액 */
    private Long excclcAmount;

    /** 최종 정산 금액 */
    private long finalExcclcAmount;

    /** 기존 미 결제 금액 */
    private long orgUnSetleAmount;

    /** 미 결제 금액 */
    private Long unSetleAmount;

    /** 단가 환불 금액 */
    private long pcRefndAmount;

    /** 추가 금액 */
    private Long aditAmount;

	/** 취소 교환 반품 번호 */
	private String canclExchngRtngudNo;

    /** 담보 상태 코드 */
    private String mrtggSttusCode;

    /** 총 주문 중량 */
    private java.math.BigDecimal totOrderWt;

    /** 총 확정 중량 */
    private java.math.BigDecimal totDcsnWt;

    /** 정산 공급가 */
    private Long excclcSplpc;

    /** 정산 부가세 */
    private Long excclcVat;

    /** 중량 정산 금액 */
    private Long wtExcclcAmount;

    /** 총 확정 주문 가격 */
    private Long totDcsnOrderPc;

    /** 총 확정 공급가 */
    private Long totDcsnSplpc;

    /** 예상 배송비 */
    private long expectDlvrf;

    /** 회원 아이디 */
    private String mberId;

    /** 회원 번호 */
    private String mberNo;

    /** 업체 번호 */
    private String entrpsNo;

    /** 확정 상품 단가 (지정가 or 라이브) */
    private long dcsnGoodsPc;

    /** 확정 LME (지정가 or 라이브) */
    private java.math.BigDecimal dcsnLmePc;

    /** 확정 환율 (지정가 or 라이브) */
    private java.math.BigDecimal dcsnEhgtPc;
    
    /** 가격 변동금 */
    private long pcChangegld;

    /** 추가 입금 금액 */
    private long aditRcpmnyAmount;

    /** 환불 구분 코드 */
    private String refndSeCode;

    /** 결제 상태 코드 */
    private String setleSttusCode;

    // 주문_거래 정보 상세 관련 필드
    /** 거래 상세 순번 */
    private long delngDetailSn;

    /** 거래 상세 구분 코드			*/
    private String delngDetailSeCode;

    /** 결제 번호 */
    private String setleNo;

    /** 담보 번호 */
    private String mrtggNo;

    /** 담보 상세 순번 */
    private Long mrtggDetailSn;

    /** 거래 금액 */
    private long delngAmount;

    /** 이월렛 환불 여부 */
    private boolean ewalletRefndYn;

    /** 세금계산서 발행 여부 */
    private boolean taxbillIssueYn;

    /** 담보모듈 호출 여부 */
    private boolean mrtggCallYn;

    /** 변동금 발생 순번 */
    private int occrrncSn;

    /** 주문 상태 코드 **/
    private String orderSttusCode;
}
