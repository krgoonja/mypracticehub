package com.sorincorp.comm.itemprice.model;

import java.util.List;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ItemPriceMatchingBlWrhousngVO extends CommonVO {

	private static final long serialVersionUID = 6882956165304862133L;

	/** 최적BL매칭목록 */
	List<ItemPriceMatchingBlInfoVO> itemPriceMatchingBlInfoVO;
	
	/** 매칭된중량 */
	int matchingOverWeight;
	
	/** 잔여필요중량 */
	int leftOverWeight;
    
}