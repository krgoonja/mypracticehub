package com.sorincorp.comm.order.model;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
import com.sorincorp.comm.pcInfo.model.FixPriceVO;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;

import lombok.Data;

/**
 * OrderModel.java
 * 주문 공통 VO 객체
 *
 * @version
 * @since 2023. 5. 4.
 * @author srec0049
 */
@Data
public class OrderModel {

    /** 장바구니 번호 **/
    private String bsktNo;

    /** 프라이싱 번호 **/
    @NotEmpty(message = "프라이싱 번호 미존재")
    private String pricingNo;

    /** 판매 가격 실시간 순번 **/
    private String slePcRltmSn;

    /** 프리미엄 번호 **/
    private String premiumNo;

    /** 프리미엄 가격 **/
    private BigDecimal premiumPc;

    /** 금속코드 **/
    @NotEmpty(message = "금속코드 미존재")
    private String metalCode;

    /** 아이템 순번 **/
    @NotNull(message = "아이템 순번 미존재")
    private Integer itmSn;

    /** 권역 대분류 코드 **/
    @NotEmpty(message = "권역 대분류 코드 미존재")
    private String dstrctLclsfCode;

    /** 권역 중분류 코드 **/
    private String dstrctMlsfcCode;

    /** 차량 톤 코드 **/
    private String vhcleTonCode;

    /** 브랜드 그룹 코드 **/
    @NotEmpty(message = "브랜드 그룹 코드 미존재")
    private String brandGroupCode;

    /** 브랜드 코드 **/
    @NotEmpty(message = "브랜드 코드 미존재")
    private String brandCode;

    /** 브랜드 코드 **/
    @NotEmpty(message = "실제 브랜드 코드 미존재")
    private String realBrandCode;

    /** 주문 중량 **/
    @Min(value = 1,  message = "최소 주문 중량 확인 필요")
    private int orderWt;

    /** 판매 단위 중량 **/
    private int sleUnitWt;

    /** 1회 판매 가능 중량 **/
    private int onceSlePossWt;

    /** 최대 구매 가능 중량 **/
    private int mxmmPurchsPossWt;

    /** 삼성선물 주문 단위 중량 **/
    private int samsungOrderWt;

    /** 요청 선물 종목 코드 **/
    private String samsungStockCode;

    /** 배송지 번호 **/
    private String dlvrgNo;

    /** 접수 매체 구분 코드 **/
    @NotEmpty(message = "접수 매체 구분 코드 미존재")
    private String rceptMediaSeCode;

    /** 판매 방식 코드 **/
    @NotEmpty(message = "판매 방식 코드 미존재")
    private String sleMthdCode;

    /** 판매 방식 상세 코드 **/
    private String sleMthdDetailCode;

    /** 배송 수단 코드 **/
    @NotEmpty(message = "배송 수단 코드 미존재")
    private String dlvyMnCode;

    /** 출고 요청 일자 **/
    @NotEmpty(message = "배송 요청일 미존재")
    private String dlivyRequstDe;

    /** 배송 요청 사항 **/
    private String dlvyRequstCn;

    /** 주문번호 **/
    private String orderNo;

    /** 주문 상세 번호 **/
    private String orderSn;

    /** 주문번호 **/
    private String setleNo;

    /** OMS 접수 번호 **/
    private String omsRceptNo;

    /** 주문 상태 코드 **/
    private String orderSttusCode;

    /** 조건에 사용될 주문 상태 코드 **/
    private int condOrderSttusCode;

    /** 주문 실패 사유 **/
    private String orderFailrResn;

    /** 취소교환 반품번호 **/
    private String canclExchngRtngudNo;

    /** 선물 요청 주문 번호 **/
    private String ftrsRequstOrderNo;

    /** 응답 선물 주문 번호 **/
    private String rspnsFtrsOrderNo;

    /** 선물 만기 실행ID */
    private String executId;

    /** 선물 원 요청 주문 번호 **/
    private String requstWonOrderNo;

    /** 선물환 요청 주문 번호 **/
    private String fshgRequstOrderNo;

    /** Ewallet 가상 계좌 번호 **/
    private String ewalletAcnutNo;

    /** 로그인 유저 No **/
    private String mberNo;

    /** 로그인 유저 업체 No **/
    private String entrpsNo;

    /** 로그인 업체 등급 번호 **/
    private String  entrpsGradNo;

    /** 로그인 유저 ID **/
    private String mberId;

    /** 로그인 유저 이메일 **/
    private String mberEmail;

    /** 총 번들 수량 **/
    private int totBundleQy;

    /** 총 고객 주문 중량 **/
    private int totCstmrOrderWt;

    /** 총 실제 주문 중량 **/
    private int totRealOrderWt;

    /** 할증 요율 **/
    private BigDecimal totAmtTariff;

    /** 상품 단가 **/
    private long goodsUntpc;

    /** 주문 가격 **/
    private long orderPc;

    /** 중량 변동 **/
    private double wtChange;

    /** 중량 변동금 **/
    private long wtChangegld;

    /** 공급가 **/
    private long splpc;
    private long reSplpc;

    /** 부가세 **/
    private long vat;
    private long reVat;

    /** 판매가 **/
    private long slepc;
    private long reSlepc;

    /** 예상배송비 **/
    private long expectDlvrf;

    /** 삼성성물 계좌번호 **/
    private String requstAcnutNo;

    /** 요청 주문 단가 **/
    private String requstOrderUntpc;

    /** BL QY 수량 **/
    private int requstOrderQy;

    /** BL PO 테이블 **/
    private ItPurchsInfoBas itPurchsInfoBas;

    /** 평균가 선물 테이블 **/
    private CnAvrgpcFtrsBasVO cnAvrgpcFtrsBas;

    /** 평균가 선물환 테이블 **/
    private CnAvrgpcFshgBasVO cnAvrgpcFshgBas;

    /** 실시간 판매가격 정보 **/
    private PrSelVO prSelVO = new PrSelVO();

    /** 고정가 판매가격 정보 **/
    private FixPriceVO fixSelVO = new FixPriceVO();

    /** 프라이싱 기본 **/
    private OrPricingBasVO orPricingBas;

    /** 라이브 프리미엄 가격 정보 **/
    private LivePremiumVO livePremiumVO = new LivePremiumVO();

    /** 고정가 프리미엄 가격 정보 **/
    private FixPriceVO fixPriceVO = new FixPriceVO();

    /** 배송지 및 회원 기본 **/
    private MbDlvrgBasVO mbDlvrgBas;

    /** 최적의 BL 리스트 **/
    private List<ItemPriceMatchingBlInfoVO> blList;

    /** 최적의 BL 상세 **/
    private ItemPriceMatchingBlInfoVO blDetail;

    /** 고객 주문 수량 **/
    private int cstmrOrderWt;

    /** 실제 주문 수량 **/
    private int realOrderWt;

    /** 번들 수량 **/
    private int bundleQy;

    /** 삼성선물 키 값 리스트 **/
    private List<String> ftrnNoList;

    /** 삼성선물 취소 키 값 리스트 **/
    private List<String> cancelFtrnNoList;

    /** 삼성선물 실패 리스트 **/
    private List<CommOrOrderFtrsBasVO> samsungFailList;

    /** 삼성선물 실패 건들의 원주문번호 키 값 리스트 **/
    private List<String> requstWonOrderNoListByCancel;

    /** 재고 BL No **/
    private String orderInvntryBlNo;

    /** 재고 실제 번들 이론 중량 **/
    private double orderInvntry;

    /** 재고 실제 번들 수량 **/
    private int orderBundleInvntry;

    /** 거래 일련 번호 **/
    private String delngSeqNo;

    /** 원주문 BL 목록 */
    private List<OrOrderDtlVO> orderBlList;

    /** 원주문 BL 상세 */
    private OrOrderDtlVO orderBlDetail;

    /** 클레임 정보 **/
    private OrderDtlsClaimVO claimDetail;

    /** 새로 채번 프라이싱 번호 **/
    private String newPricingNo;

    /** 적용 일시 **/
    private String applcDt;

    /** 프라이싱 단계 코드 **/
    private String pricingStepCode;

    /**
     * 고객 판매 가격 실시간 순번
     */
    private String cstmrSlePcRltmSn;

    /**
     * 고객 LME 가격 실시간 순번
     */
    private String cstmrLmePcRltmSn;

    /**
     * 고객 프리미엄 번호
     */
    private String cstmrPremiumNo;

    /**
     * 고객 환율 가격 실시간 순번
     */
    private String cstmrEhgtPcRltmSn;

    /**
     * 세금계산서 보기 URL
     */
    private String documentViewDomain;  //  20220401 이현진 세금계산서 url추가

    /**
     * 도메인
     */
    private String domain;

    /**
     * 당일 배송 체크 상태 값
     */
    private boolean sameDayDeliveryStatus;

    /**
     * 당일 배송 여부(동일날짜인지만 체크)
     */
    private String sameDayDeliveryAt;

    /**
     * 당일 배송 여부(가능 여부)
     */
    private String todayDlvyAt;

    /**
     * 삼성선물 주문 타입
     */
    private String samsungOrdertype;

    /**
     * 주문건 배송비 할인 적용 여부
     */
    private String dlvrfDscntAt;

    /**
     * 쿠폰 일련번호
     */
    private String couponSeqNo;

    /**
     * 쿠폰 할인 금액
     */
    private String couponDscntPrice;

    /**
     * 쿠폰 중복 사용 제한
     */
    private String couponDplctUseLmttQyAt;

    /**
     * 쿠폰 번호
     */
    private String couponIsuRnno;

    /**
     * 선물 선물환 관리
     */
    private CommFtrsFshgMngVO commFtrsFshgMngVO;

    /**
     * 주문 모달창에 선택된 결제 수단 값, 결제수단 (e-Wallet: ewallet, 증거금: wrtm, B2B 전자상거래보증: mrtggGrnty)
     */
    private String paymentMn;

    /**
     * 증거금 비율 선택 값 (구매 성향 단계 비율)
     */
    private int purchsInclnStepRate;

    /**
     * 구매 성향 단계 금액
     */
    private int purchsInclnStepAmount;

    /**
     * B2B 전자상거래보증 상환기간 선택 값
     */
    private int mrtggGrntyRepyPd;

    /**
     * 업체 결제 수단 정보
     */
    private OrderEntrpsSetleMnVO entrpsSetleMnInfo;

    /**
     * 주문 홀딩 사용 여부
     */
    private String orderHoldingUseAt;

    /**
     * 최소 결제 금액 (증거금 사용하기 선택 시)
     */
    private long mummSetleAmount;

    /**
     * 보증 금액
     */
    private String grntyAmount;

    /**
     * 담보 잔액
     */
    private String mrtggBlce;

    /**
     * 보증 번호
     */
    private String grntyNo;

    /**
     * 업체 담보 계약 순번
     */
    private int entrpsMrtggCntrctSn;

    /**
     * 담보 보증 수수료 부담 주체 여부
     */
    private String mrtggGrntyFeeBndMbyAt;

    /**
     * 보증 기한 시작 일자
     */
    private String grntyTmlmtBeginDe;

    /**
     * 보증 기한 종료 일자
     */
    private String grntyTmlmtEndDe;

    /**
     * 담보 보증 이자율
     */
    private double intrt;

    /**
     * 담보 보증 단가 인상 금액
     */
    private long untpcIncrse;

    /**
     * 회원_업체 담보 한도 상세 테이블 등록 후 업체 담보 순번 리턴 값
     */
    private int entrpsMrtggSn;

    /**
     * 담보 번호
     */
    private String mrtggNo;

    /**
     * 회원_업체 마일리지 내역 상세
     */
    private OrderMbEntrpsMlgInfoDtlVO orderMbEntrpsMlgInfoDtlVO;

    /**
     * 매출 달성율
     */
    private BigDecimal selngAchivrt;

    /**
     * 마일리지 순번(등록 후 리턴 받을 용도)
    */
    private long mlgSn;

    /**
     * 주문 CAPA 관리 여부
     */
    private String orderCapaManageAt;

    /**
     * 쿠폰 리스트
     */
    private List<CouponVO> couponList;

    /**
     * 당일 총 실제 주문 중량 가져오는 조건(전체: all, 업체별메탈코드별: entrpsMetal, 업체 단위 케이지크레딧: entrpsSorincredt)
     */
    private String todayTotRealOrderWtCnd;

    /**
     * 여신 서비스 구분 코드
     */
    private String cdtlnSvcSeCode;

    /**
     * 지정 BL (자투리)
     */
    private String reMainBlNo;

    /**
     * 입고 예정 재고 여부에 의한 주문 홀딩 여부, 주문 홀딩 여부 중에서 우선순위 최상위
     */
    private String orderHoldingByWrhousngPrearngeInvntryUseAt;

    /**
     * lme 수집 시간 간격 값
     */
    private int lmeColctTimeIntrvlVal;

    /**
     * 환율 수집 시간 간격 값
     */
    private int ehgColctTimeIntrvlVal;

    /**
     * 프리미엄 가격을 위한 브랜드코드 (가격정보 가져올때 사용)
     */
    private String brandCodeByPremium;

    /**
     * 지정가 주문 번호
     */
    private String limitOrderNo;

    /**
     * 지정가 구분 [가격 도달 시 진행되는 주문: touch, 그 외: null]
     */
    private String limitSection;

    /**
     * 지정가 구분 코드 - 가단가용 [F: LME/X: 환율/R: KRW]
     */
    private String limitSeCode;

    /**
     * 배송지 우편 번호
     */
    private String dlvrgPostNo;

    /**
     * 지정가 주문 상태 코드
     */
    private String limitOrderSttusCode;

    /**
     * 재고 부분 체결 여부
     */
    private String invntryPartCnclsAt;

    /**
     * 지정가 주문 기준 판매 가격
     */
    private java.math.BigDecimal limitOrderStdrSlePc;

    private int afterSleInvntryUnsleBnt;

    /**
     * 지정가 주문 시각(yyyyMMddHHmmss)
     */
    private String limitOrderTmByFormat;

    /**
     * 지정가 입력 금액
     */
    private long limitInputAmount;

    /**
     * 지정가 주문 유효 시간
     */
    private String limitOrderValidTime;
    
    /**
     * 계약 구매 최종 상품 단가
     */
    private Long cntrctPurchsLastGoodsUntpc;

    /**
     * 주문 시점 잔여 한도 금액
     */
    private long orderPnttmRemndrLmtAmount;

    /**
     * 요청 선물사 구분 코드(TCODE)
     */
    private String requstFtrsCmpnySeCode;
    /**
     * 요청 선물사 대상 코드
     */
    private String requstFtrsCmpnyTrgetCode;

    /**
     * 쿠폰 적용여부
     */
    private String couponApplcAt;

    /**
     * 쿠폰 타입코드
     */
    private String couponTyCode;

    /**
     * 원 상품단가
     */
    private long OrgGoodsUntpc;

    /**
     * 쿠폰 총 할인 금액
     */
    private long totalCouponDscntAmount;

    /**
     * 실제 할인 적용 금액
     */
    private String realDscntApplcAmount;

    /**
     * 등급 할인 금액
     */
    private long gradApplcAmount;

    /**
     * 지정가 예수금
     */
    private long advrcvAmount;

    // 주문_주문 정보 기본(평균가)
    /** 계약 발주 번호 */
    private String cntrctOrderNo;

    /** 단가 산식 코드 */
    private String untpcMntnfrmlaCode;

    /** 단가 산식 코드 명 */
    private String untpcMntnfrmlaNm;

    /** 통화 구분 코드 */
    private String crncySeCode;

    /** 통화 구분 코드 명 */
    private String crncySeNm;

    /** LME 평균 */
    private java.math.BigDecimal lmeAvrg;

    /** 환율 평균 */
    private java.math.BigDecimal ehgtAvrg;

    /** 평균가 상품 단가 */
    private long avrgpcGoodsUntpc;

    /** 평균가 확정 단가 여부: [Y:확정가, N:가단가] */
    private String avrgpcDcsnUntpcAt;

    /** 계약_계약 발주 기본 VO */
    private CnCntrctOrderBasVO cntrctOrderBasInfo;

    /** 주문_주문 평균가 상세 VO */
    private OrOrderAvrgpcDtlVO avrgpcDtlInfo;

    /** 누적 평균 가격 목록(평균단가 계산 시점의 가격 근거 데이터 리스트) */
    private List<OrOrderAvrgpcDtlVO> accmltAvrgpcList;

    /** 단가 구분 코드 [10: 가단가, 20: 확정단가] */
    private String untpcSeCode;
    
    /*	MARKUP 사용여부 */
    private String lmeMarkUpAt;
    
    /* MARKUP GAIN VALUE */
    private java.math.BigDecimal gainValue;
    
    /* MARK UP SN 순번 되받을 용도 */
    private int markUpSn;

    /** 소량 구매 여부 */
	private String smlqyPurchsAt;

	/** 자투리 할인(추가할인) */
	private long rmndrDscnt;

	/** 선물 체결 수량: 소량구매일 경우 선물/선물환 스킵여부 파악하기 위함 **/
    private int orderQy;
    
    // 주문_주문 정보 기본(가단가)
    /**
     * 단가 분리 확정 여부
    */
    private String untpcSepratDcsnAt;
    /**
     * 단가 확정 최대 기간 코드
    */
    private String untpcDcsnMxmmPdCode;
    /**
     * 단가 확정 최대 일자
     */
    private String untpcDcsnMxmmDe;
    /**
     * 가격 변동금
     */
    private long pcChangegld;
    /**
     * 유지 변동 금액
    */
    private long mntncChangeAmount;
    /**
     * 최초 가격 변동 금액
    */
    private long frstPcChangeAmount;
    /**
     * 거래 불가 여부
     */
    private String delngImprtyAt;
    
    /**
     * 가단가 확정 - 구분 [lme: LME 분리확정, fx: FX 분리확정, smtm: 동시확정, singl: 단일(단가)확정]
     */
    private String dcsnSection;
    
    /**
     * 가단가 확정 - 판매 방식 [live: 라이브, limit: 지정가]
     */
    private String dcsnSelMthd;
    
    /**
     * 지정가 LME 주문 번호
     */
    private String limitLmeOrderNo;
    
    /**
     * 지정가 환율 주문 번호
     */
    private String limitEhgtOrderNo;
    
    /**
     * 지정가 KRW 주문 번호
     */
    private String limitKrwOrderNo;
    
    /**
     * 지정가 LME 입력 금액
     */
    private double limitLmeInputAmount;
    
    /**
     * 지정가 환율 입력 금액
     */
    private double limitEhgtInputAmount;
    
    /**
     * 지정가 KRW 입력 금액
     */
    private long limitKrwInputAmount;
    
    /**
     * 지정가 LME 주문 유효 일자
     */
    private String limitLmeOrderValidDe;
    
    /**
     * 지정가 환율 주문 유효 일자
     */
    private String limitEhgtOrderValidDe;
    
    /**
     * 지정가 KRW 주문 유효 일자
     */
    private String limitKrwOrderValidDe;
    
    /**
     * 단가 할인 금액
     */
    private long pdDscntAmount;
    
    /**
     * 휴일 영업 종료 시간
     */
    private String applcEndTime;
}
