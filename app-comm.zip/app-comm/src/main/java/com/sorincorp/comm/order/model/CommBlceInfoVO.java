package com.sorincorp.comm.order.model;

import lombok.Data;

/**
 * CommBlceInfoVO.java
 * 최종 잔액 체크 공통 VO 객체
 * @version
 * @since 2023. 5. 11.
 * @author srec0066
 */
@Data
public class CommBlceInfoVO {

	/** 최종 잔액 */
	private long finalBlce;
	/** 거래 가능 여부  */
	private boolean delngPossAt;
	/** 총 예수금 합계  */
	private long totAdvrcvAmount;
}
