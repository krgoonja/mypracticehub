package com.sorincorp.comm.config;

import lombok.Getter;

@Getter
public enum CacheType {

  /* enum 형태로 cacheName 별 설정을 관리한다.
    enum명(캐시명, 유효시간초, 최대저장건수)
  */
  SECOND_TIME("Second_Time", 5, 2000),
  CHART_ALL("Chart_All", 10, 2000),
  CHART_01("Chart_01Min", 1 * 30, 2000), 
  CHART_30("Chart_30Min", 10 * 30, 2000),
  CHART_60("Chart_60Min", 10 * 30, 2000),
  CHART_DAY("Chart_Day", 10 * 60, 2000),
  CHART_WEEK("Chart_Week", 10 * 60, 2000),
  CHART_MONTH("Chart_Month", 10 * 60, 2000),
  CHART_QUARTER("Chart_Quarter", 10 * 60, 2000),
  CHART_HALFYEAR("Chart_HalfYear", 10 * 60, 2000),
  CHART_YEAR("Chart_Year", 10 * 60, 2000),
  COMM_CODE("Comm_Code", 10 * 60, 2000),
  PREMINUME_INFO("Preminume_Info", 10 * 60, 2000),
  LME_INFO("Lme_info", 10 * 60, 2000),
  NEWS_INFO("News_Info", 10 * 60, 2000);

  CacheType(String cacheName, int expiredAfterWrite, int maximumSize) {
    this.cacheName = cacheName;
    this.expiredAfterWrite = expiredAfterWrite;
    this.maximumSize = maximumSize;
  }

  private String cacheName;
  private int expiredAfterWrite;
  private int maximumSize;

}