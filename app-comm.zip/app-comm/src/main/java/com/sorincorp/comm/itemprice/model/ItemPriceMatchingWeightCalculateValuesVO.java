package com.sorincorp.comm.itemprice.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ItemPriceMatchingWeightCalculateValuesVO extends CommonVO {

	private static final long serialVersionUID = -6452058512928119170L;

    /**		  * 평균중량(평균값) */				private java.math.BigDecimal avgNum;
    /**		  * 이론중량 */					private java.math.BigDecimal logicalWeight;
    /**		  * 해당 중량에 따른 이론중량 */		private java.math.BigDecimal collectLogicalWeight;
    /**		  * 중량에 따른 최소중량 */			private java.math.BigDecimal minTonWeight;
    /**		  * 중량에 따른 최대중량 */			private java.math.BigDecimal maxTonWeight;
    /**		  * 중량에 따른 최소 번들 수 */		private java.math.BigDecimal minBundle;
    /**		  * 중량에 따른 최대 번들 수 */		private java.math.BigDecimal maxBundle;
    /**		  * 중량에 따른 최적 번들 수 */		private java.math.BigDecimal collectBundle;
    /**		  * 최적 번들 수에 따른 이론 중량 */	private java.math.BigDecimal collectBundleLogicalWeight;

}