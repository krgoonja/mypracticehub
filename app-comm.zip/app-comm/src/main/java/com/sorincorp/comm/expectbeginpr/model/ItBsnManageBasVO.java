package com.sorincorp.comm.expectbeginpr.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ItBsnManageBasVO {

    /**
     * 적용 일자
    */
    private String applcDe;
    /**
     * 실시간 시작 시간
    */
    private String rltmBeginTime;

}