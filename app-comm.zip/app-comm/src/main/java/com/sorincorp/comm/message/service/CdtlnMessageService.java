package com.sorincorp.comm.message.service;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.message.model.OrderInfoVO;

/**
 * CdtlnMessageService.java : 여신 메세지/이메일 발송 공통서비스
 * @version
 * @since 2022. 8. 16.
 * @author srec0053
 */
public interface CdtlnMessageService {

	/**
	 * <pre>
	 * 처리내용: 여신 관련 SMS 전송 공통 메소드(메세지번호 리턴)
	 *     mdstrmRepySn(중도 상환 순번)이 없으면 -1 값으로 세팅
	 * </pre>
	 * @date 2022. 8. 19.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 19.			srec0066			최초작성
	 * 2024. 7. 26.         srec0049            mdstrmRepySn(중도 상환 순번)이 없으면 -1 값으로 세팅 추가
	 * ------------------------------------------------
	 * @param orderNo
	 * @param templateNum
	 * @param userId TODO
	 * @return
	 * @throws Exception
	 */
	int insertCdtlnSmsReturnMssageNo(String orderNo, Long mdstrmRepySn, String templateNum, String userId);

	/**
	 * <pre>
	 * 처리내용: 여신 관련 Mail 전송 공통 메소드(메일번호 리턴)
	 * </pre>
	 * @date 2022. 8. 16.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 16.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @param templateNum
	 */
	int insertCdtlnMailSendReturnMailNo(String orderNo, String templateNum);

	/**
	 * <pre>
	 * 처리내용: 주문_미납 주문 관리 기본 Insert
	 * </pre>
	 * @date 2022. 9. 20.
	 * @author srec0053
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 9. 20.			srec0053			최초작성
	 * ------------------------------------------------
	 * @param cdtlnData
	 * @throws Exception
	 */
	void insertNpyOrderManage(Map<String, String> cdtlnData) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 케이지크레딧 테이블 정보 동적 출력
	 * </pre>
	 * @date 2023. 5. 22.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 22.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param selectSorinCredtList
	 * @param totalMrtggBlce
	 * @return
	 */
	public String getSorinCreditTableInfo(List<OrderInfoVO> selectSorinCredtList, Long totalMrtggBlce);
	
	/**
	 * <pre>
	 * 처리내용: 출고중지 및 출고중지 해제 SMS 전송 공통 서비스
	 *     dlivyStpgeCode[출고 중지 코드] : stpge(중지), relis(해제)
	 * 
	 * </pre>
	 * @date 2024. 7. 19.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 7. 19.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param dlivyStpgeCode [출고 중지 코드] : stpge(중지), relis(해제)
	 * @param orderNo
	 * @param templateNum
	 * @throws Exception
	 */
	/**
	 * <pre>
	 * 처리내용: 출고중지 및 출고중지 해제 SMS 전송 공통 서비스
	 *     dlivyStpgeCode[출고 중지 코드] : stpge(중지), relis(해제)
	 *     outptAmount [출력 금액] : stpge(중지) 시 미납금액, relis(해제) 시 결제금액
	 * </pre>
	 * @date 2024. 7. 24.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2024. 7. 24.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param dlivyStpgeCode [출고 중지 코드] : stpge(중지), relis(해제)
	 * @param orderNo
	 * @param outptAmount [출력 금액] : stpge(중지) 시 미납금액, relis(해제) 시 결제금액
	 * @param templateNum
	 * @throws Exception
	 */
	public void sendDlivyStpgeRelisSms(String dlivyStpgeCode, String orderNo, Long outptAmount, int templateNum) throws Exception;
}
