package com.sorincorp.comm.exception;

import java.text.NumberFormat;

/**
 * 파일 업로드시 디스크 사용량 없을때 발생하는 사용자 정의 Exception
 * DiskFullException.java
 * @version
 * @since 2021. 6. 4.
 * @author srec0012
 */
public class DiskFullException extends RuntimeException {
	private static final long serialVersionUID = 6763926588446351283L;

	public DiskFullException(String msg) {
		super(msg);
	}
	
	public DiskFullException(Long size) {
		super("디스크에 " + getByte(size)  + "바이트의 파일을 업로드할 빈공간이 없습니다.");
	}
	
	public DiskFullException(Long size, Throwable t) {
		super("디스크에 " + getByte(size) + "바이트의 파일을 업로드할 빈공간이 없습니다.", t);
	}
	
	private static String getByte(Long size) {
		NumberFormat nf = NumberFormat.getInstance();
		return nf.format(size);
	}
}