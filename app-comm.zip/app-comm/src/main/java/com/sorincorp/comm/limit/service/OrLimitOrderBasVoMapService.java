package com.sorincorp.comm.limit.service;

import java.util.Map;
import java.util.TreeSet;

import com.sorincorp.comm.order.model.CommLimitOrderRedisMsgVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderRedisMsgVO;

public interface OrLimitOrderBasVoMapService {
	/**
	 * <pre>
	 * 처리내용: 지정가 주문 번호, 지정가 입력 금액 map
	 * </pre>
	 * @date 2023. 3. 24.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 24.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param limitOrderNo
	 * @return
	 */
	CommLimitOrderRedisMsgVO getLimitOrderNoInputAmountVo(String limitOrderNo);
	
	/**
	 * <pre>
	 * 처리내용: 주문번호-지정가입력금액 map에서 삭제
	 * </pre>
	 * @date 2023. 4. 5.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 5.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param limitOrderNo
	 */
	void removeLimitOrderNoInputAmountVo(String limitOrderNo);
	
	/**
	 * <pre>
	 * 처리내용: 전체 지정가 주문 리스트
	 * </pre>
	 * @date 2023. 4. 5.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 5.			srec0064			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	Map<String, TreeSet<CommLimitOrderRedisMsgVO>> getOrderCommLimitOrderRedisMsgVoMap();
	
	/**
	 * <pre>
	 * 처리내용: 종목코드(금속코드, 아이템순번, 권역대분류코드, 브랜드그룹코드, 브랜드코드) 기준으로 ordering한 지정가 주문 리스트
	 * </pre>
	 * @date 2023. 3. 24.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 24.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param groupCode
	 * @return
	 */
	TreeSet<CommLimitOrderRedisMsgVO> getOrderCommLimitOrderRedisMsgVoMap(String groupCode);
	
	/**
	 * <pre>
	 * 처리내용: 전체 지정가 주문 리스트 저장
	 * </pre>
	 * @date 2023. 5. 8.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 8.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param orderCommLimitOrderRedisMsgVoMap
	 */
	void setOrderCommLimitOrderRedisMsgVoMap(Map<String, TreeSet<CommLimitOrderRedisMsgVO>> orderCommLimitOrderRedisMsgVoMap);
	
	/**
	 * <pre>
	 * 처리내용: OrderCommLimitOrderRedisMsgVoMap 초기화
	 * </pre>
	 * @date 2023. 6. 15.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 6. 15.			srec0064			최초작성
	 * ------------------------------------------------
	 */
	void clearOrderCommLimitOrderRedisMsgVoMap();
	
	/**
	 * <pre>
	 * 처리내용: 전체 지정가 주문 번호, 지정가 입력 금액 map
	 * </pre>
	 * @date 2023. 7. 3.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 3.			srec0064			최초작성
	 * ------------------------------------------------
	 * @return
	 */
	Map<String, CommLimitOrderRedisMsgVO> getLimitOrderNoInputAmountVo();

	/**
	 * <pre>
	 * 처리내용: 가단가 지정가 주문 번호, 지정가 입력 금액 map
	 * </pre>
	 * @date 2024. 9. 26.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 26.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	CommPrvsnlLimitOrderRedisMsgVO getPrvsnlLimitOrderNoInputAmountVo(String limitOrderNo);

	/**
	 * <pre>
	 * 처리내용: 가단가 주문번호-지정가입력금액 map에서 삭제
	 * </pre>
	 * @date 2024. 9. 26.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 26.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	void removePrvsnlLimitOrderNoInputAmountVo(String limitOrderNo);

	/**
	 * <pre>
	 * 처리내용: 전체 가단가 지정가 주문 리스트 (LME, KRW)
	 * </pre>
	 * @date 2024. 9. 26.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 26.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	Map<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> getOrderCommPrvsnlLimitOrderRedisMsgVoMap();

	/**
	 * <pre>
	 * 처리내용: 금속코드 기준으로 ordering한 가단가 지정가 주문 리스트 (LME, KRW)
	 * </pre>
	 * @date 2024. 9. 9.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 9.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param groupCode
	 * @return
	 */
	TreeSet<CommPrvsnlLimitOrderRedisMsgVO> getOrderCommPrvsnlLimitOrderRedisMsgVoMap(String metalCode);

	/**
	 * <pre>
	 * 처리내용: 전체 가단가 지정가 주문 리스트 저장 (LME, KRW)
	 * </pre>
	 * @date 2024. 8. 28.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 8. 28.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param orderCommPrvsnlLimitOrderRedisMsgVoMap
	 */
	void setOrderCommPrvsnlLimitOrderRedisMsgVoMap(Map<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> orderCommPrvsnlLimitOrderRedisMsgVoMap);

	/**
	 * <pre>
	 * 처리내용: OrderCommPrvsnlLimitOrderRedisMsgVoMap 초기화
	 * </pre>
	 * @date 2024. 9. 26.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 26.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	void clearOrderCommPrvsnlLimitOrderRedisMsgVoMap();

	/**
	 * <pre>
	 * 처리내용: 전체 가단가 지정가 주문 번호, 지정가 입력 금액 map
	 * </pre>
	 * @date 2024. 9. 9.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 9.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @return
	 */
	Map<String, CommPrvsnlLimitOrderRedisMsgVO> getPrvsnlLimitOrderNoInputAmountVo();

	// FX
	/**
	 * <pre>
	 * 처리내용: 전체 가단가 지정가 주문 리스트 저장 (FX)
	 * </pre>
	 * @date 2024. 9. 26.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 26.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	void setOrderCommPrvsnlLimitOrderRedisMsgVoFxMap(Map<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> orderCommPrvsnlLimitOrderRedisMsgVoFxMap);

	/**
	 * <pre>
	 * 처리내용: 전체 가단가 지정가 주문 리스트 (FX)
	 * </pre>
	 * @date 2024. 9. 26.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 26.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	Map<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap();

	/**
	 * <pre>
	 * 처리내용: 속코드 기준으로 ordering한 가단가 지정가 주문 리스트 (FX)
	 * </pre>
	 * @date 2024. 9. 26.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 26.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	TreeSet<CommPrvsnlLimitOrderRedisMsgVO> getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap(String metalCode);
}
