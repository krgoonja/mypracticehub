package com.sorincorp.comm.config;

import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import lombok.extern.slf4j.Slf4j;

/**
 * 비동기 처리 설정 <br> 
 * 메소드에 annotation &#064;Async를 사용해 비동기 처리 가능하게 할 설정<br>
 * 사용법 <br>
 * &#064;Async("asyncTaskexecutor")
 * public void asyncTask() throws Exception ....
 * @version
 * @since 2021. 9. 17.
 * @author srec0004
 */
@Slf4j
@Configuration
@EnableAsync
public class AsyncConfig {
	/**
	 * <pre>
	 * 비동기 처리 Executor 빈 설정
	 * 설정예) 
	 * setCorePoolSize(1) (미설정 시 1), setMaxPoolSize(5)(미설정시 Integer.MAX_VALUE), setQueueCapacity(5) (미설정시 Integer.MAX_VALUE) 일 경우
	 * 10개의 task 요청을 실행할 경우 
	 * 01. corePoolSize: 1, poolSize: 1, activeSize: 1, queueSize: 0
	 * 02. corePoolSize: 1, poolSize: 1, activeSize: 1, queueSize: 1
	 * 03. corePoolSize: 1, poolSize: 1, activeSize: 1, queueSize: 2
	 * 04. corePoolSize: 1, poolSize: 1, activeSize: 1, queueSize: 3
	 * 05. corePoolSize: 1, poolSize: 1, activeSize: 1, queueSize: 4
	 * 06. corePoolSize: 1, poolSize: 1, activeSize: 1, queueSize: 5
	 * 07. corePoolSize: 1, poolSize: 2, activeSize: 2, queueSize: 5
	 * 08. corePoolSize: 1, poolSize: 3, activeSize: 3, queueSize: 5
	 * 09. corePoolSize: 1, poolSize: 4, activeSize: 4, queueSize: 5
	 * 10. corePoolSize: 1, poolSize: 5, activeSize: 5, queueSize: 5
	 * 
	 * 01번은 corePool 배정, 02번~06 queue에 배정, 07~10 queue 용량이 모자라 새로은 thread 추가로 생성(maxPoolSize 까지)
	 * 이때 maxPoolSize까지 pool이 증가해도 모자라는 경우 TaskRejectedException 오류가 발생함
	 * 
	 * 비동기 병렬 처리를 해야 하는 경우는 위 설정값의 용량을 잘 예측해 설정해야 함
	 * </pre>
	 * 
	 * @date 2021. 9. 17.
	 * @author srec0004
	 * @history
	 * 
	 *          <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 9. 17.		srec0004		최초작성
	 * -------------------------------------------------------------------------
	 *          </pre>
	 * 
	 * @return
	 */
	@Bean(name = "asyncTaskexecutor", destroyMethod = "destroy")
	public AsyncTaskExecutor secThreadPoolTaskExecutor() {
		ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskExecutor.setThreadNamePrefix("Executor-");
		taskExecutor.initialize();
		return new SecHandlingExecutor(taskExecutor); // HandlingExecutor로 wrapping 합니다.
	}

	/**
	 * ThreadPoolTaskExecutor 처리시 Handler 클래스
	 * 
	 * @version
	 * @since 2021. 9. 17.
	 * @author srec0004
	 */
	public class SecHandlingExecutor implements AsyncTaskExecutor {
		private AsyncTaskExecutor executor;

		public SecHandlingExecutor(AsyncTaskExecutor executor) {
			this.executor = executor;
		}

		@Override
		public void execute(Runnable task) {
			executor.execute(createWrappedRunnable(task));
		}

		@Override
		public void execute(Runnable task, long startTimeout) {
			executor.execute(createWrappedRunnable(task), startTimeout);
		}

		@Override
		public Future<?> submit(Runnable task) {
			return executor.submit(createWrappedRunnable(task));
		}

		@Override
		public <T> Future<T> submit(final Callable<T> task) {
			return executor.submit(createCallable(task));
		}

		private <T> Callable<T> createCallable(final Callable<T> task) {
			return new Callable<T>() {
				@Override
				public T call() throws Exception {
					try {
						return task.call();
					} catch (Exception ex) {
						handle(ex);
						throw ex;
					}
				}
			};
		}

		private Runnable createWrappedRunnable(final Runnable task) {
			return new Runnable() {
				@Override
				public void run() {
					try {
						task.run();
					} catch (Exception ex) {
						handle(ex);
					}
				}
			};
		}

		private void handle(Exception ex) {
			log.debug("Failed to execute task. : {}", ex.getMessage());
			log.error("Failed to execute task. ", ex);
		}

		public void destroy() {
			if (executor instanceof ThreadPoolTaskExecutor) {
				((ThreadPoolTaskExecutor) executor).shutdown();
			}
		}
	}
}
