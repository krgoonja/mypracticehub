package com.sorincorp.comm.expectbeginpr.service;

public interface ExpectBeginPcService {
	void calculateExpectBeginPc() throws Exception;
	
	/*void calculateDcsnBeginPc(String time) throws Exception;*/
}
