package com.sorincorp.comm.credt.mapper;

import com.sorincorp.comm.credt.model.CredtCdtlnInfoVO;

/**
 * CommMrtggMapper.java
 * B2B 담보 보증 Mapper 인터페이스
 * @version
 * @since 2022. 8. 8.
 * @author srec0049
 */
public interface CommMrtggMapper {
	/**
	 * <pre>
	 * 처리내용: 여신 패널티 정보(여신관리 패널티 연체 건수, 여신관리 패널티 사고 건수) 가져오기
	 * </pre>
	 * @date 2022. 8. 10.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 10.			srec0049			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	CredtCdtlnInfoVO getCdtlnPntInfo() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 여신 금리 정보(CD금리, 케이지트레이딩 가산금리, 연간뱅킹데이, CD 금리 사용 여부) 가져오기
	 * CD금리는 CD 금리 사용 여부에 따라 미사용(N)일 경우 0으로 반환한다
	 * </pre>
	 * @date 2022. 8. 8.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 8.			srec0049			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	CredtCdtlnInfoVO getCdtlnInrstInfo() throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 여신 증권 발급 수수료 정보(전자상거래보증 증권발급 수수료 보상 비율, 전자상거래보증 증권발급 수수료 보상 건당 인정 비율) 가져오기
	 * </pre>
	 * @date 2022. 8. 25.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 8. 25.			srec0049			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	CredtCdtlnInfoVO getCdtlnScritsIssuFee() throws Exception;
}
