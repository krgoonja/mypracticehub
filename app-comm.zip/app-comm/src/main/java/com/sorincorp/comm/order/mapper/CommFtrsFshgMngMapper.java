/**
 * 
 */
package com.sorincorp.comm.order.mapper;

import java.util.List;

import com.sorincorp.comm.order.model.CommFtrsFshgMngVO;

/**
 * CommFtrsFshgMngMapper.java
 * 선물 선물환 관리 Mapper 인터페이스
 * 
 * @version
 * @since 2022. 6. 8.
 * @author srec0049
 */
public interface CommFtrsFshgMngMapper {

	/**
	 * <pre>
	 * 처리내용: 오늘 날짜 기준의 적용 일자에 해당하는 상품_선물 선물환 관리 상세 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 6. 16.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 16.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param postnCode
	 * @return
	 * @throws Exception
	 */
	public List<CommFtrsFshgMngVO> commFtrsFshgManageDtlListByToday(String postnCode) throws Exception;
}
