package com.sorincorp.comm.order.mapper;

import com.sorincorp.comm.order.model.CommAvrgPcInvntryVO;

/**
 * CommAvrgPcInvntryMapper.java
 * 평균가 재고 공통 Mapper 인터페이스
 * 
 * @version
 * @since 2023. 11. 21.
 * @author srec0049
 */
public interface CommAvrgPcInvntryMapper {
	
	/**
	 * <pre>
	 * 처리내용: 계약_계약 월 할당 재고 상세 이력 등록, 할당 해제 시 할당 중량, 할당 재고, 할당 번들 재고를 0으로 등록한다.
	 * </pre>
	 * @date 2023. 11. 21.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 11. 21.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commAvrgPcInvntryVO
	 * @return
	 * @throws Exception
	 */
	public int insertCnCntrctMtAsgnInvntryDtlHst(CommAvrgPcInvntryVO commAvrgPcInvntryVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 계약_계약 월 할당 재고 상세에 해당 데이터 중 할당 중량 값을 반환
	 * </pre>
	 * @date 2023. 11. 30.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 11. 30.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commAvrgPcInvntryVO
	 * @return
	 * @throws Exception
	 */
	public Integer getAsgnWtCnCntrctMtAsgnInvntryDtl(CommAvrgPcInvntryVO commAvrgPcInvntryVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 할당해제, 계약_계약 월 할당 재고 상세에 해당 데이터 삭제 (DELETE_AT(삭제 여부) 수정 처리가 아니라 데이터 삭제)
	 * </pre>
	 * @date 2023. 11. 21.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 11. 21.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commAvrgPcInvntryVO
	 * @return
	 * @throws Exception
	 */
	public int deleteCnCntrctMtAsgnInvntryDtl(CommAvrgPcInvntryVO commAvrgPcInvntryVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 계약_계약 월 할당 재고 상세에 해당 데이터 등록 (할당 용도)
	 * </pre>
	 * @date 2023. 11. 21.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 11. 21.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commAvrgPcInvntryVO
	 * @return
	 * @throws Exception
	 */
	public int insertCnCntrctMtAsgnInvntryDtl(CommAvrgPcInvntryVO commAvrgPcInvntryVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 계약_계약 월 할당 재고 상세에 해당 데이터 수정 (할당, 발주, 결제 용도)
	 * </pre>
	 * @date 2023. 11. 27.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 11. 27.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commAvrgPcInvntryVO
	 * @return
	 * @throws Exception
	 */
	public int updateCnCntrctMtAsgnInvntryDtl(CommAvrgPcInvntryVO commAvrgPcInvntryVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 할당, 결제의 차감, 증가에 따른 상품_BL 정보 기본 정보를 수정한다. [IT_BL_INFO_BAS(상품_BL 정보 기본)] (할당, 결제 용도)
	 * </pre>
	 * @date 2023. 11. 23.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 11. 23.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commAvrgPcInvntryVO
	 * @return
	 * @throws Exception
	 */
	public int updateItBlInfoBasByAvrgInvntry(CommAvrgPcInvntryVO commAvrgPcInvntryVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 할당에 따른 상품_BL 정보 기본 정보를 수정한다. [IT_BL_INFO_BAS(상품_BL 정보 기본)]
	 * </pre>
	 * @date 2023. 11. 23.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 11. 23.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commAvrgPcInvntryVO
	 * @return
	 * @throws Exception
	 */
	public int updateItBlInfoBasByInvntryAsgn(CommAvrgPcInvntryVO commAvrgPcInvntryVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 할당로직에 따른 상품_BL 정보 이력 상세를 등록한다. [IT_BL_INFO_HIST_DTL(상품_BL 정보 이력 상세)]
	 * </pre>
	 * @date 2023. 11. 23.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 11. 23.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commAvrgPcInvntryVO
	 * @return
	 * @throws Exception
	 */
	public int insertItBlInfoHistDtlByInvntryAsgn(CommAvrgPcInvntryVO commAvrgPcInvntryVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 할당로직에 따른 상품_BL 정보 기본 이력을 등록한다. [IT_BL_INFO_BAS_HST(상품_BL 정보 기본 이력)]
	 * </pre>
	 * @date 2023. 11. 23.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 11. 23.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param commAvrgPcInvntryVO
	 * @return
	 * @throws Exception
	 */
	public int insertItBlInfoBasHstByInvntryAsgn(CommAvrgPcInvntryVO commAvrgPcInvntryVO) throws Exception;
}
