package com.sorincorp.comm.redis.config;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class RedisPubSubMessage implements Serializable{

	private static final long serialVersionUID = 2187367321298347L;
	private String channelId;
	private String name;
	private String message;
}
