package com.sorincorp.comm.websocket.service;

import com.sorincorp.comm.websocket.model.SocketDataVO;

/**
 * BtoBApiService.java
 * @version
 * @since 2021. 6. 30.
 * @author Kwon sun hyung
 */
public interface WebSocketHandlerService {

	/**
	 * <pre>
	 * 처리내용: 접속된 특정 id에 message를 보낸다.
	 * </pre>
	 * @date 2021. 6. 30.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 30.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param socketDataVO
	 * @throws Exception
	 */
	void sendMessageByOne(SocketDataVO socketDataVO) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 접속된 모든 id에 message를 보낸다.
	 * </pre>
	 * @date 2021. 6. 30.
	 * @author Kwon sun hyung
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 6. 30.		Kwon sun hyung		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param socketDataVO
	 * @throws Exception
	 */
	 void sendMessageByAll(SocketDataVO socketDataVO) throws Exception;

}
