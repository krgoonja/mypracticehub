package com.sorincorp.comm.it.service;

import org.springframework.stereotype.Service;

import com.sorincorp.comm.it.model.ItBsnManageBasVo;

@Service
public class ItBsnManageBasVoServiceImpl implements ItBsnManageBasVoService{
	
	private ItBsnManageBasVo itBsnManageBasVo;
	
	public ItBsnManageBasVoServiceImpl() {
		if(itBsnManageBasVo == null) {
			this.itBsnManageBasVo = new ItBsnManageBasVo();
		}
	}
	
	public ItBsnManageBasVo getItBsnManageBasVo() {
		return itBsnManageBasVo;
	}
	
}