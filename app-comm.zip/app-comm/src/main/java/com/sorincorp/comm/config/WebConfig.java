package com.sorincorp.comm.config;

import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.resource.ResourceUrlEncodingFilter;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
public class WebConfig implements WebMvcConfigurer {

	@Override
	public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		// TODO Auto-generated method stub
		WebMvcConfigurer.super.configureMessageConverters(converters);
		converters.add(escapeConverter());
	}
	
	@Bean
	public HttpMessageConverter escapeConverter() {
		ObjectMapper objMapper = new ObjectMapper();
		objMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES); //BO 메뉴 그리드 쪽 Unknown properties 존재
		objMapper.getFactory().setCharacterEscapes(new HTMLCharacterEscapes());
		
		MappingJackson2HttpMessageConverter escapeConverter = new MappingJackson2HttpMessageConverter();
		escapeConverter.setObjectMapper(objMapper);
		
		return escapeConverter;
	}
	
    //JSP에 버저닝을 할 수 있게 만드는 빈 생성
    @Bean
    public ResourceUrlEncodingFilter resourceUrlEncodingFilter() {
        return new ResourceUrlEncodingFilter();
    } 
}
