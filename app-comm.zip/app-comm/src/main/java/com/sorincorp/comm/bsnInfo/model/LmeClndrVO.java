package com.sorincorp.comm.bsnInfo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class LmeClndrVO implements Serializable{
    
	private static final long serialVersionUID = 2849004139164064398L;

    /**
     * 회사 코드
    */
    private String cmpnyCode;
    /**
     * 적용 일자
    */
    private String applcDe;
    /**
     * 요일
    */
    private String day;
    /**
     * LME 달력 유형 코드
    */
    private String lmeCldrTyCode;
    /**
     * 휴뮤일 여부
     */
    private String lmeHolidayAt;
    /**
     * 비고
    */
    private String rm;
    
}
