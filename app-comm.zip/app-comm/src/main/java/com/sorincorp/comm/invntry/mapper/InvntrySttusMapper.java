package com.sorincorp.comm.invntry.mapper;

import java.util.List;

import com.sorincorp.comm.invntry.model.InvntrySttusVO;

/**
 * InvntrySttusMapper.java
 * 재고 현황 조회 Mapper 인터페이스
 * @version
 * @since 2023. 6. 27.
 * @author srec0066
 */
public interface InvntrySttusMapper {

	 /**
	 * <pre>
	 * 처리내용: BL 리스트 조회
	 * </pre>
	 * @date 2023. 7. 6.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 7. 6.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @return
	 * @throws Exception
	 */
	List<InvntrySttusVO> selectBlInfoList(InvntrySttusVO param) throws Exception;

	/**
	 * <pre>
	 * 처리내용: BL 리스트 조회 (소량구매 대상)
	 * </pre>
	 * @date 2024. 5. 27.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 5. 27.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param
	 * @return
	 * @throws
	 */
	List<InvntrySttusVO> selectSmlqyPurchsBlInfoList(InvntrySttusVO param) throws Exception;
}
