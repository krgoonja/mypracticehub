package com.sorincorp.comm.filedoc.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.OperationContext;
import com.microsoft.azure.storage.blob.BlobContainerPublicAccessType;
import com.microsoft.azure.storage.blob.BlobRequestOptions;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.microsoft.sqlserver.jdbc.StringUtils;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.constants.ExceptionConstants;
import com.sorincorp.comm.filedoc.mapper.FileDocMapper;
import com.sorincorp.comm.filedoc.model.FileDocVO;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.MessageUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FileDocServiceImpl implements FileDocService {

	@Autowired
	private FileDocMapper fileDocMapper;

	@Autowired
	MessageUtil message;

	@Autowired
	Environment env;

	@Value("${spring.servlet.multipart.location}")
	private String location;

	public int[] uploadAttachFiles(String jobSe, MultipartHttpServletRequest mRequest) throws Exception {
		Iterator<String> fileIter = mRequest.getFileNames();

		FileDocVO docVo = new FileDocVO();
		int[] returnIDs = null;
		jobSe = jobSe.toLowerCase();

		try {
			String fileOrgName;
			String extension;
			String fileName;
			File file;
			String path;
			String[] fileFilter = { "pptx", "ppt", "xls", "xlsx", "doc", "docx", "hwp", "pdf", "gif", "png", "jpg", "jpeg", "txt" };
			Boolean checkExe;
			List<MultipartFile> files;

			while ( fileIter.hasNext() ) {
				files = mRequest.getMultiFileMap().get(fileIter.next());
				returnIDs = new int[files.size()];

				int fileNo = 0;
				for ( MultipartFile mFile : files ) {
					fileOrgName = mFile.getOriginalFilename();
					extension = FilenameUtils.getExtension(fileOrgName);
					checkExe = true;

					for ( String ex : fileFilter ) {
						if ( ex.equalsIgnoreCase(extension) ) {
							checkExe = false;
						}
					}

					if ( checkExe ) {
						throw new Exception(message.getMessage(ExceptionConstants.BAD_EXE_FILE_EXCEPTION));
					}

					if ( mFile.getSize() > CommonConstants.MAX_UPLOAD_SIZE ) {
						throw new Exception(message.getMessage(ExceptionConstants.BAD_SIZE_FILE_EXCEPTION,"("+CommonConstants.MAX_UPLOAD_SIZE/(1024*1024)+"MB"+")"));
					}

					//String root_path = mRequest.getSession().getServletContext().getRealPath("/");
					fileName = System.currentTimeMillis() + "." + extension;
					//path = CommonConstants.UPLOAD_PATH + File.separator + CommonConstants.ATTACH_PATH + File.separator + jobSe + File.separator + DateUtil.getNowDate().substring(0, 6);
					path = location + jobSe + File.separator + DateUtil.getNowDate().substring(0, 6);
					file = new File(path, fileName);

					if ( !file.getParentFile().exists() ) {
						file.getParentFile().mkdirs();
					}

//					log.debug("원본파일 : {}", mFile);
//					log.debug("대상파일 : {}", file);
//					log.debug("경로 : {}", path);
//
//					log.debug("대상파일 경로 : {}", file.getPath());

					mFile.transferTo(file);

					docVo.setJobSeCode(jobSe);
					docVo.setDocFileNm(fileOrgName);
					docVo.setDocFileCours(path);
					docVo.setDocFileRealCours(file.getPath());
					docVo.setDeleteAt("N");
					docVo.setDeleteDt(null);
					docVo.setFrstRegisterId("SYSTEM");
					docVo.setLastChangerId("SYSTEM");

					fileDocMapper.insertCommonDoc(docVo);

					returnIDs[fileNo] = docVo.getDocNo();
					fileNo++;
				}
			}
		} catch ( IllegalStateException e ) {
			log.error("{}", e);
			throw new Exception(ExceptionConstants.ERROR_CODE_DEFAULT);
		} catch ( Exception e ) {
			log.error("{}", e);
			throw new Exception(ExceptionConstants.ERROR_CODE_DEFAULT);
		}

		return returnIDs;
	}

	public List<FileDocVO> uploadAttachFilesVoList(String jobSe, MultipartHttpServletRequest mRequest) throws Exception {
		Iterator<String> fileIter = mRequest.getFileNames();
		List<FileDocVO> fileList = new ArrayList<FileDocVO>();
		int[] returnIDs = null;
		jobSe = jobSe.toLowerCase();

		CloudStorageAccount storageAccount;
		CloudBlobClient blobClient = null;
		CloudBlobContainer container=null;

		String[] nowProfiles = env.getActiveProfiles();
		String nowProfile = nowProfiles[0];

		try {
			storageAccount = CloudStorageAccount.parse(CommonConstants.STORAGE_CONNECTION_STRING);
			blobClient = storageAccount.createCloudBlobClient();

			if (!("local".equals(nowProfile) || "dev".equals(nowProfile))) {
				container = blobClient.getContainerReference("secs-pr");
			}
			else {
				container = blobClient.getContainerReference("secs-pr-t");
			}

//			System.out.println("Creating container: " + container.getName());
			container.createIfNotExists(BlobContainerPublicAccessType.CONTAINER, new BlobRequestOptions(), new OperationContext());

			String fileOrgName;
			String extension;
			String fileName;
			File file;
			long fileSize;
			String path;
			String[] fileFilter = { "pptx", "ppt", "xls", "xlsx", "doc", "docx", "hwp", "pdf", "gif", "png", "jpg", "jpeg", "txt" };
			Boolean checkExe;
			List<MultipartFile> files;

			while ( fileIter.hasNext() ) {
				files = mRequest.getMultiFileMap().get(fileIter.next());
				returnIDs = new int[files.size()];

				int fileNo = 0;
				for ( MultipartFile mFile : files ) {
					
					fileOrgName = mFile.getOriginalFilename();
					
					//공백이 들어가면 %20이 공백 부분으로 들어가므로 파일 업로드할 때 오류 수정 
					if(fileOrgName.contains(" ")) {
						fileOrgName = fileOrgName.replaceAll(" ", "");
					}
					
					extension = FilenameUtils.getExtension(fileOrgName);
					checkExe = true;

					for ( String ex : fileFilter ) {
						if ( ex.equalsIgnoreCase(extension) ) {
							checkExe = false;
						}
					}

					if ( checkExe ) {
						throw new Exception(message.getMessage(ExceptionConstants.BAD_EXE_FILE_EXCEPTION));
					}

					if ( mFile.getSize() > CommonConstants.MAX_UPLOAD_SIZE ) {
						throw new Exception(message.getMessage(ExceptionConstants.BAD_SIZE_FILE_EXCEPTION));
					}

					//String root_path = mRequest.getSession().getServletContext().getRealPath("/");
					fileName = FilenameUtils.removeExtension(fileOrgName)+"_"+System.currentTimeMillis() + "." + extension;
					//path = CommonConstants.UPLOAD_PATH + File.separator + CommonConstants.ATTACH_PATH + File.separator + jobSe + File.separator + DateUtil.getNowDate().substring(0, 6);
					path = location + jobSe + File.separator + DateUtil.getNowDate().substring(0, 6);
					file = new File(path, fileName);

					if ( !file.getParentFile().exists() ) {
						file.getParentFile().mkdirs();
					}

					mFile.transferTo(file);

					//업로드할 파일의 reference
					CloudBlockBlob blob = container.getBlockBlobReference(jobSe+"/"+file.getName());
					//업로드할 파일의 Content-Type 설정
					blob.getProperties().setContentType(mFile.getContentType());
					//CloudBlockBlob blob = container.getBlockBlobReference(file.getName());
					blob.uploadFromFile(file.getAbsolutePath());

					Files.delete(file.toPath());

					fileSize = Math.round((mFile.getSize()/1024));

					FileDocVO vo = new FileDocVO();

					vo.setJobSeCode(jobSe);
					vo.setDocFileNm(blob.getName().split("/")[1]);
					vo.setDocFileCours(blob.getUri().toString());
					vo.setDocFileRealCours(blob.getUri().toString());
					vo.setDocFileMg(fileSize);
					vo.setDeleteAt("N");
					vo.setDeleteDt(null);
					vo.setFrstRegisterId("SYSTEM");
					vo.setLastChangerId("SYSTEM");

					try {
						fileDocMapper.insertCommonDoc(vo);
					}
					catch (Exception e) {
						throw new Exception(message.getMessage(ExceptionConstants.BAD_LENGTH_FILE_NM_EXCEPTION));
					}
					returnIDs[fileNo] = vo.getDocNo();

					fileList.add(vo);
					fileNo++;

				}

			}

		} catch ( IllegalStateException e ) {
			log.error("{}", e);
			throw new Exception(ExceptionConstants.ERROR_CODE_DEFAULT);
		} catch ( Exception e ) {
			log.error("{}", e);
			throw new Exception(e.getMessage());
		}
		return fileList;
	}
	
	/**
	 * <pre>
	 * 처리내용: 폴더명 구분 추가, PDF 파일만.
	 * </pre>
	 * @date 2022. 12. 23.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 23.		chajeeman			최초작성
	 * -----------------------------------------------
	 * @param jobSe
	 * @param floderNm
	 * @param mrequest
	 * @return
	 * @throws Exception
	 */
	public List<FileDocVO> uploadAttachFilesVoList(String jobSe, String floderNm, MultipartHttpServletRequest mRequest) throws Exception {
		Iterator<String> fileIter = mRequest.getFileNames();
		List<FileDocVO> fileList = new ArrayList<FileDocVO>();
		int[] returnIDs = null;
		jobSe = jobSe.toLowerCase();

		CloudStorageAccount storageAccount;
		CloudBlobClient blobClient = null;
		CloudBlobContainer container=null;

		String[] nowProfiles = env.getActiveProfiles();
		String nowProfile = nowProfiles[0];

		try {
			storageAccount = CloudStorageAccount.parse(CommonConstants.STORAGE_CONNECTION_STRING);
			blobClient = storageAccount.createCloudBlobClient();

			if (!("local".equals(nowProfile) || "dev".equals(nowProfile))) {
				container = blobClient.getContainerReference("secs/");
			}
			else {
				container = blobClient.getContainerReference("secs-t/");
			}

//			System.out.println("Creating container: " + container.getName());
			container.createIfNotExists(BlobContainerPublicAccessType.CONTAINER, new BlobRequestOptions(), new OperationContext());

			String fileOrgName;
			String extension;
			String fileName;
			File file;
			long fileSize;
			String path;
			String[] fileFilter = { "pptx", "ppt", "xls", "xlsx", "doc", "docx", "hwp", "pdf", "gif", "png", "jpg", "jpeg", "txt", "zip" };
			Boolean checkExe;
			List<MultipartFile> files;

			while ( fileIter.hasNext() ) {
				files = mRequest.getMultiFileMap().get(fileIter.next());
				returnIDs = new int[files.size()];

				int fileNo = 0;
				for ( MultipartFile mFile : files ) {
					fileOrgName = mFile.getOriginalFilename();
					extension = FilenameUtils.getExtension(fileOrgName);
					checkExe = true;

					for ( String ex : fileFilter ) {
						if ( ex.equalsIgnoreCase(extension) ) {
							checkExe = false;
						}
					}

					if ( checkExe ) {
						throw new Exception(message.getMessage(ExceptionConstants.BAD_EXE_FILE_EXCEPTION));
					}

					if ( mFile.getSize() > CommonConstants.MAX_UPLOAD_SIZE ) {
						throw new Exception(message.getMessage(ExceptionConstants.BAD_SIZE_FILE_EXCEPTION));
					}

					//String root_path = mRequest.getSession().getServletContext().getRealPath("/");
					fileName = FilenameUtils.removeExtension(fileOrgName)+"_"+System.currentTimeMillis() + "." + extension;
					//path = CommonConstants.UPLOAD_PATH + File.separator + CommonConstants.ATTACH_PATH + File.separator + jobSe + File.separator + DateUtil.getNowDate().substring(0, 6);
					path = location + jobSe + File.separator + DateUtil.getNowDate().substring(0, 6);
					file = new File(path, fileName);

					if ( !file.getParentFile().exists() ) {
						file.getParentFile().mkdirs();
					}

					mFile.transferTo(file);
					
					//업로드할 파일의 reference
					CloudBlockBlob blob = container.getBlockBlobReference(jobSe+"/"+floderNm+"/"+file.getName());
					//업로드할 파일의 Content-Type 설정
					blob.getProperties().setContentType(mFile.getContentType());
					//CloudBlockBlob blob = container.getBlockBlobReference(file.getName());
					blob.uploadFromFile(file.getAbsolutePath());

					Files.delete(file.toPath());

					fileSize = Math.round((mFile.getSize()/1024));

					FileDocVO vo = new FileDocVO();

					vo.setJobSeCode(jobSe);
					vo.setDocFileNm(blob.getName().split("/")[2]);
					vo.setDocFileCours(blob.getUri().toString());
					vo.setDocFileRealCours(blob.getUri().toString());
					vo.setDocFileMg(fileSize);
					vo.setDeleteAt("N");
					vo.setDeleteDt(null);
					vo.setFrstRegisterId("SYSTEM");
					vo.setLastChangerId("SYSTEM");

					try {
						fileDocMapper.insertCommonDoc(vo);
					}
					catch (Exception e) {
						throw new Exception(message.getMessage(ExceptionConstants.BAD_LENGTH_FILE_NM_EXCEPTION));
					}
					returnIDs[fileNo] = vo.getDocNo();

					fileList.add(vo);
					fileNo++;

				}

			}

		} catch ( IllegalStateException e ) {
			log.error("{}", e);
			throw new Exception(ExceptionConstants.ERROR_CODE_DEFAULT);
		} catch ( Exception e ) {
			log.error("{}", e);
			throw new Exception(e.getMessage());
		}
		return fileList;
	}


	@Override
	public List<FileDocVO> uploadPublicAttachFilesVoList(String jobSe, MultipartHttpServletRequest mRequest) throws Exception{
		Iterator<String> fileIter = mRequest.getFileNames();
		List<FileDocVO> fileList = new ArrayList<FileDocVO>();
		int[] returnIDs = null;
		jobSe = jobSe.toLowerCase();

		CloudStorageAccount storageAccount;
		CloudBlobClient blobClient = null;
		CloudBlobContainer container=null;

		String[] nowProfiles = env.getActiveProfiles();
		String nowProfile = nowProfiles[0];

		try {
			storageAccount = CloudStorageAccount.parse(CommonConstants.STORAGE_CONNECTION_STRING);
			blobClient = storageAccount.createCloudBlobClient();
//			container = blobClient.getContainerReference(CommonConstants.BLOB_STORAGE_PUBLIC_EC_CONTAINER_PATH);

			if (!("local".equals(nowProfile) || "dev".equals(nowProfile))) {
				container = blobClient.getContainerReference("secs/");
			}
			else {
				container = blobClient.getContainerReference("secs-t/");
			}

//			System.out.println("Creating container: " + container.getName());
			container.createIfNotExists(BlobContainerPublicAccessType.CONTAINER, new BlobRequestOptions(), new OperationContext());

			String fileOrgName;
			String extension;
			String fileName;
			File file;
			long fileSize;
			String path;
			String[] fileFilter = { "pptx", "ppt", "xls", "xlsx", "doc", "docx", "hwp", "pdf", "gif", "png", "jpg", "jpeg", "txt" };
			Boolean checkExe;
			List<MultipartFile> files;

			while ( fileIter.hasNext() ) {
				files = mRequest.getMultiFileMap().get(fileIter.next());
				returnIDs = new int[files.size()];

				int fileNo = 0;
				for ( MultipartFile mFile : files ) {
					fileOrgName = mFile.getOriginalFilename();
					extension = FilenameUtils.getExtension(fileOrgName);
					checkExe = true;

					for ( String ex : fileFilter ) {
						if ( ex.equalsIgnoreCase(extension) ) {
							checkExe = false;
						}
					}

					if ( checkExe ) {
						throw new Exception(message.getMessage(ExceptionConstants.BAD_EXE_FILE_EXCEPTION));
					}

					if ( mFile.getSize() > CommonConstants.MAX_UPLOAD_SIZE ) {
						throw new Exception(message.getMessage(ExceptionConstants.BAD_SIZE_FILE_EXCEPTION));
					}

					//String root_path = mRequest.getSession().getServletContext().getRealPath("/");
					fileName = FilenameUtils.removeExtension(fileOrgName)+"_"+System.currentTimeMillis() + "." + extension;
					//path = CommonConstants.UPLOAD_PATH + File.separator + CommonConstants.ATTACH_PATH + File.separator + jobSe + File.separator + DateUtil.getNowDate().substring(0, 6);
					path = location + jobSe + File.separator + DateUtil.getNowDate().substring(0, 6);
					file = new File(path, fileName);

					if ( !file.getParentFile().exists() ) {
						file.getParentFile().mkdirs();
					}

					mFile.transferTo(file);

					//업로드할 파일의 reference
					CloudBlockBlob blob = container.getBlockBlobReference(jobSe+"/"+file.getName());
					//업로드할 파일의 Content-Type 설정
					blob.getProperties().setContentType(mFile.getContentType());
					blob.uploadFromFile(file.getAbsolutePath());

					Files.delete(file.toPath());

					fileSize = Math.round((mFile.getSize()/1024));

					FileDocVO vo = new FileDocVO();

					vo.setJobSeCode(jobSe);
					vo.setDocFileNm(blob.getName().split("/")[1]);
					vo.setDocFileCours(blob.getUri().toString());
					vo.setDocFileRealCours(blob.getUri().toString());
					vo.setDocFileMg(fileSize);
					vo.setDeleteAt("N");
					vo.setDeleteDt(null);
					vo.setFrstRegisterId("SYSTEM");
					vo.setLastChangerId("SYSTEM");

					try {
						fileDocMapper.insertCommonDoc(vo);
					}
					catch (Exception e) {
						throw new Exception(message.getMessage(ExceptionConstants.BAD_LENGTH_FILE_NM_EXCEPTION));
					}
					returnIDs[fileNo] = vo.getDocNo();

					fileList.add(vo);
					fileNo++;

				}

			}

		} catch ( IllegalStateException e ) {
			log.error("{}", e);
			throw new Exception(ExceptionConstants.ERROR_CODE_DEFAULT);
		} catch ( Exception e ) {
			log.error("{}", e);
			throw new Exception(e.getMessage());
		}
		return fileList;
	}

	public int[] uploadAttachImages(String jobSe, MultipartHttpServletRequest mRequest) throws Exception {
		Iterator<String> fileIter = mRequest.getFileNames();

		FileDocVO docVo = new FileDocVO();
		int[] returnIDs = null;
		jobSe = jobSe.toLowerCase();

		try {
			String fileOrgName;
			String extension;
			String fileName;
			File file;
			String path;
			String[] fileFilter = { "jpg", "jpeg", "png", "gif", "bmp" };
			Boolean checkExe;
			List<MultipartFile> files;

			while ( fileIter.hasNext() ) {
				files = mRequest.getMultiFileMap().get(fileIter.next());
				returnIDs = new int[files.size()];

				int fileNo = 0;
				for ( MultipartFile mFile : files ) {
					fileOrgName = mFile.getOriginalFilename();
					extension = FilenameUtils.getExtension(fileOrgName);
					checkExe = true;

					for ( String ex : fileFilter ) {
						if ( ex.equalsIgnoreCase(extension) ) {
							checkExe = false;
						}
					}

					if ( checkExe ) {
						throw new Exception(message.getMessage(ExceptionConstants.BAD_EXE_FILE_EXCEPTION));
					}

					if ( mFile.getSize() > CommonConstants.MAX_UPLOAD_SIZE ) {
						throw new Exception(message.getMessage(ExceptionConstants.BAD_SIZE_FILE_EXCEPTION));
					}

					//String root_path = mRequest.getSession().getServletContext().getRealPath("/");
					fileName = System.currentTimeMillis() + "." + extension;
					//path = CommonConstants.UPLOAD_PATH + File.separator + CommonConstants.IMAGE_PATH + File.separator + jobSe + File.separator + DateUtil.getNowDate().substring(0, 6);
					path = location + CommonConstants.IMAGE_PATH + File.separator + jobSe + File.separator + DateUtil.getNowDate().substring(0, 6);
					file = new File(path, fileName);

					if ( !file.getParentFile().exists() ) {
						file.getParentFile().mkdirs();
					}

//					log.debug("원본파일 : {}", mFile);
//					log.debug("대상파일 : {}", file);

					mFile.transferTo(file);

					docVo.setJobSeCode(jobSe);
					docVo.setDocFileNm(fileOrgName);
					docVo.setDocFileCours(path);
					docVo.setDocFileRealCours("");
					docVo.setDeleteAt("N");
					docVo.setDeleteDt(null);
					docVo.setFrstRegisterId("SYSTEM");
					docVo.setLastChangerId("SYSTEM");

					fileDocMapper.insertCommonDoc(docVo);

					returnIDs[fileNo] = docVo.getDocNo();
					fileNo++;
				}
			}
		} catch ( IllegalStateException e ) {
			log.error("{}", e);
			throw new Exception(ExceptionConstants.ERROR_CODE_DEFAULT);
		} catch ( Exception e ) {
			log.error("{}", e);
			throw new Exception(ExceptionConstants.ERROR_CODE_DEFAULT);
		}

		return returnIDs;
	}

	public int[] uploadProductImages(String itemCode, MultipartHttpServletRequest mRequest) throws Exception {
		Iterator<String> fileIter = mRequest.getFileNames();

		FileDocVO docVo = new FileDocVO();
		int[] returnIDs = null;

		try {
			String fileOrgName;
			String extension;
			String fileName;
			File file;
			String path;
			String[] fileFilter = { "jpg", "jpeg", "png", "gif", "bmp" };
			Boolean checkExe;
			List<MultipartFile> files;

			while ( fileIter.hasNext() ) {
				files = mRequest.getMultiFileMap().get(fileIter.next());
				returnIDs = new int[files.size()];

				int fileNo = 0;
				for ( MultipartFile mFile : files ) {
					fileOrgName = mFile.getOriginalFilename();
					extension = FilenameUtils.getExtension(fileOrgName);
					checkExe = true;

					for ( String ex : fileFilter ) {
						if ( ex.equalsIgnoreCase(extension) ) {
							checkExe = false;
						}
					}

					if ( checkExe ) {
						throw new Exception(message.getMessage(ExceptionConstants.BAD_EXE_FILE_EXCEPTION));
					}

					if ( mFile.getSize() > CommonConstants.MAX_UPLOAD_SIZE ) {
						throw new Exception(message.getMessage(ExceptionConstants.BAD_SIZE_FILE_EXCEPTION));
					}

					//String root_path = mRequest.getSession().getServletContext().getRealPath("/");
					fileName = System.currentTimeMillis() + "." + extension;
					//path = CommonConstants.UPLOAD_PATH + File.separator + CommonConstants.PRODUCT_PATH + File.separator + itemCode + File.separator + DateUtil.getNowDate().substring(0, 6);
					path = location + CommonConstants.PRODUCT_PATH + File.separator + itemCode + File.separator + DateUtil.getNowDate().substring(0, 6);
					file = new File(path, fileName);

					if ( !file.getParentFile().exists() ) {
						file.getParentFile().mkdirs();
					}

//					log.debug("원본파일 : {}", mFile);
//					log.debug("대상파일 : {}", file);
					mFile.transferTo(file);

					docVo.setJobSeCode("IT");
					docVo.setDocFileNm(fileOrgName);
					docVo.setDocFileCours(path);
					docVo.setDocFileRealCours(path);
					docVo.setDeleteAt("N");
					docVo.setDeleteDt(null);
					docVo.setFrstRegisterId("SYSTEM");
					docVo.setLastChangerId("SYSTEM");

					fileDocMapper.insertCommonDoc(docVo);

					returnIDs[fileNo] = docVo.getDocNo();
					fileNo++;
				}
			}
		} catch ( IllegalStateException e ) {
			log.error("{}", e);
			throw new Exception(ExceptionConstants.ERROR_CODE_DEFAULT);
		} catch ( Exception e ) {
			log.error("{}", e);
			throw new Exception(ExceptionConstants.ERROR_CODE_DEFAULT);
		}

		return returnIDs;
	}

	public FileDocVO selectDocInfo(int docNo) throws Exception {
//		FileDocVO docVo = new FileDocVO();
		FileDocVO docVo = fileDocMapper.selectDocInfo(docNo);

		return docVo;
	}

	public String selectDocName(int docNo) throws Exception {
		FileDocVO docVo = selectDocInfo(docNo);
		if ( docVo != null ) {
			return docVo.getDocFileNm();
		} else {
			return null;
		}
	}

	public String selectDocPath(int docNo) throws Exception {
		FileDocVO docVo = selectDocInfo(docNo);
		if ( docVo != null ) {
			return docVo.getDocFileCours();
		} else {
			return null;
		}
	}

	public String selectDocRealPath(int docNo) throws Exception {
		FileDocVO docVo = selectDocInfo(docNo);
		if ( docVo != null ) {
			return docVo.getDocFileRealCours();
		} else {
			return null;
		}
	}

	public void deleteCommonDoc(int docNo) throws Exception {
		FileDocVO vo = new FileDocVO();
		Map<String, Object> deleteMap = new HashMap<>();
		vo = fileDocMapper.selectDocInfo(docNo);
		if(vo != null) {
			vo.setLastChangerId("SYSTEM");
			//Blob파일 삭제 공통
			deleteMap.put("jobSeCode", vo.getJobSeCode());
			deleteMap.put("fileUri", vo.getDocFileRealCours());
			deleteBlobFilesVo(deleteMap);
			//CO_DOC_BAS파일 삭제
			fileDocMapper.deleteCommonDoc(vo);
		}
	}

//	, String filePath
//	, String realFilNm
	public void fileDocDownload(HttpServletRequest request,HttpServletResponse response, FileDocVO vo) throws Exception {

		CloudStorageAccount storageAccount;
		CloudBlobClient blobClient = null;
		CloudBlobContainer container=null;

		String[] nowProfiles = env.getActiveProfiles();
		String nowProfile = nowProfiles[0];

		try {
			storageAccount = CloudStorageAccount.parse(CommonConstants.STORAGE_CONNECTION_STRING);
			blobClient = storageAccount.createCloudBlobClient();
//			if (!("local".equals(nowProfile) || "dev".equals(nowProfile))) {
//				container = blobClient.getContainerReference("secs-pr");
//			}
//			else {
//				container = blobClient.getContainerReference("secs-pr-t");
//			}
//
//
////			System.out.println("Creating container: " + container.getName());
//			//container.createIfNotExists(BlobContainerPublicAccessType.CONTAINER, new BlobRequestOptions(), new OperationContext());
//			String fileName;
//			if (!("local".equals(nowProfile) || "dev".equals(nowProfile))) {
//				fileName = vo.getDocFileRealCours().replace(CommonConstants.BLOB_STORAGE_ROOT_PATH, "").replace("secs-pr"+"/", "");
//			}
//			else {
//				fileName = vo.getDocFileRealCours().replace(CommonConstants.BLOB_STORAGE_ROOT_PATH, "").replace("secs-pr-t"+"/", "");
//			}
//
//			String root_path = request.getSession().getServletContext().getRealPath("/");
//			String filePath = root_path + CommonConstants.UPLOAD_PATH + File.separator + CommonConstants.ATTACH_PATH + File.separator + vo.getJobSeCode() + File.separator + DateUtil.getNowDate().substring(0, 6);
//

            String[] uriInfo = vo.getDocFileRealCours().replace(CommonConstants.BLOB_STORAGE_ROOT_PATH, "").split("/");

            if(uriInfo.length < 2) {
            	throw new Exception("URL정보가 잘못되어 있습니다.");
            }

            String containerName = uriInfo[0];

            String[] fileSplit = vo.getDocFileRealCours().split("/");
            String fileName = fileSplit[fileSplit.length - 1];
            container = blobClient.getContainerReference(containerName+"/");

            //String root_path = request.getSession().getServletContext().getRealPath("/");
            //tring filePath = root_path + CommonConstants.UPLOAD_PATH + File.separator + CommonConstants.ATTACH_PATH + File.separator + vo.getJobSeCode() + File.separator + DateUtil.getNowDate().substring(0, 6);
            String filePath = location + vo.getJobSeCode() + File.separator + DateUtil.getNowDate().substring(0, 6);

//			File file = new File(filePath);

            CloudBlockBlob blob;
            if(uriInfo.length > 3) {
            	blob = container.getBlockBlobReference(uriInfo[1] + "/" + uriInfo[2] + "/" + fileName);
            } else {
            	blob = container.getBlockBlobReference(vo.getJobSeCode() + "/" + fileName);
            }

			//fileName = fileName.split("/")[1];
			File fileDir = new File(filePath);

			if (!fileDir.exists()) {
				fileDir.mkdirs();
			}
			File file = new File(filePath, fileName);

			blob.downloadToFile(file.getAbsolutePath());

			if (file.exists() && file.isFile()) {
				response.setContentType("application/octet-stream; charset=utf-8");
				response.setContentLength((int) file.length());
				String browser = getBrowser(request);
				String disposition = getDisposition(fileName, browser, vo.getDownFileNm());
				response.setHeader("Content-Disposition", disposition);
				response.setHeader("Content-Transfer-Encoding", "binary");
				OutputStream out = response.getOutputStream();
				FileInputStream fis = null;
				fis = new FileInputStream(file);
				FileCopyUtils.copy(fis, out);
//				if (fis != null)
					fis.close();
				out.flush();
				out.close();

//				file.delete(); //was 파일 삭제
				Files.delete(file.toPath()); //was 파일 삭제
			}
			else {
				//file DownLoad Fail
			}
		} catch ( IllegalStateException e ) {
			log.error("{}", e);
			throw new Exception(ExceptionConstants.ERROR_CODE_DEFAULT);
		} catch ( Exception e ) {
			log.error("{}", e);
			throw new Exception(ExceptionConstants.ERROR_CODE_DEFAULT);
		}
	}
	
	public void deleteAttachFilesVo(Map<String, Object> deleteMap) throws Exception {

		CloudStorageAccount storageAccount;
		CloudBlobClient blobClient = null;
		CloudBlobContainer container = null;

		String[] nowProfiles = env.getActiveProfiles();
		String nowProfile = nowProfiles[0];

		try {
			storageAccount = CloudStorageAccount.parse(CommonConstants.STORAGE_CONNECTION_STRING);  
			blobClient = storageAccount.createCloudBlobClient(); 		
			
            if (!("local".equals(nowProfile) || "dev".equals(nowProfile))) {
				container = blobClient.getContainerReference("secs/");
			}
			else {
				container = blobClient.getContainerReference("secs-t/");
			}
            
            String uriInfo = ((String) deleteMap.get("fileUri")).replace(CommonConstants.BLOB_STORAGE_ROOT_PATH+container.getName(), "");

            //System.out.println((String) deleteMap.get("fileUri"));
            //System.out.println(uriInfo);
            
            //업로드할 파일의 reference
			CloudBlockBlob blob = container.getBlockBlobReference(uriInfo);
			
			blob.deleteIfExists();
            
		} catch ( IllegalStateException e ) {
			log.error("{}", e);
			throw new Exception(ExceptionConstants.ERROR_CODE_DEFAULT);
		} catch ( Exception e ) {
			log.error("{}", e);
			throw new Exception(ExceptionConstants.ERROR_CODE_DEFAULT);
		}
	}

	/**
	 *
	 * <pre>
	 * 처리내용: Request로 브라우저 체크
	 * </pre>
	 * @date 2021. 9. 3.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 3.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @return
	 */
	private String getBrowser(HttpServletRequest request) {
		String header = request.getHeader("User-Agent");
		if (header.indexOf("MSIE") > -1 || header.indexOf("Trident") > -1)
			return "MSIE";
		else if (header.indexOf("Chrome") > -1)
			return "Chrome";
		else if (header.indexOf("Opera") > -1)
			return "Opera";
		return "Firefox";
	}

	/**
	 *
	 * <pre>
	 * 처리내용: 파일 다운로드시 헤더 정보 설정
	 * </pre>
	 * @date 2021. 9. 3.
	 * @author srec0012
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 9. 3.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param filename
	 * @param browser
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	private String getDisposition(String filename, String browser, String downFileNm)
			throws UnsupportedEncodingException {
		String dispositionPrefix = "attachment;filename=";
	
		if(!StringUtils.isEmpty(downFileNm)) {
			filename = downFileNm;
		}
		
		String encodedFilename = null;
		if (browser.equals("MSIE")) {
			encodedFilename = URLEncoder.encode(filename, "UTF-8").replaceAll(
					"\\+", "%20");
		} else if (browser.equals("Firefox")) {
			encodedFilename = "\""
					+ new String(filename.getBytes("UTF-8"), "8859_1") + "\"";
		} else if (browser.equals("Opera")) {
			encodedFilename = "\""
					+ new String(filename.getBytes("UTF-8"), "8859_1") + "\"";
		} else if (browser.equals("Chrome")) {
			StringBuilder sb = new StringBuilder();			
			for (int i = 0; i < filename.length(); i++) {
				char c = filename.charAt(i);
				if (c > '~') {
					sb.append(URLEncoder.encode("" + c, "UTF-8"));
				} else {
					sb.append(c);
				}
			}
			encodedFilename = sb.toString();
		}			
		return dispositionPrefix + encodedFilename;
	}

	// BLOB 삭제처리
	@Override
	public void deleteBlobFilesVo(Map<String, Object> deleteMap) throws Exception {

		CloudStorageAccount storageAccount;
		CloudBlobClient blobClient = null;
		CloudBlobContainer container = null;

		String[] nowProfiles = env.getActiveProfiles();
		String nowProfile = nowProfiles[0];

		try {
			// 2024.07.04 - blob 파일 삭제 호출 url (파일 다운로드 형식과 동일하게 수정)
			storageAccount = CloudStorageAccount.parse(CommonConstants.STORAGE_CONNECTION_STRING);  
			blobClient = storageAccount.createCloudBlobClient();
			
			String[] uriInfo = ((String) deleteMap.get("fileUri")).replace(CommonConstants.BLOB_STORAGE_ROOT_PATH, "").split("/");
			
			if(uriInfo.length < 2) {
					throw new Exception("URL정보가 잘못되어 있습니다.");
			}
				
			String containerName = uriInfo[0];
			String[] fileSplit =  ((String) deleteMap.get("fileUri")).split("/");
			String fileName = fileSplit[fileSplit.length - 1];
			container = blobClient.getContainerReference(containerName+"/");
            
            String uriInfo1 = ((String) deleteMap.get("fileUri")).replace(CommonConstants.BLOB_STORAGE_ROOT_PATH+container.getName(), "");
            //업로드할 파일의 reference
			CloudBlockBlob blob = container.getBlockBlobReference(uriInfo1);
			
			blob.deleteIfExists();
			
		} catch ( IllegalStateException e ) {
			log.error("{}", e);
			throw new Exception(ExceptionConstants.ERROR_CODE_DEFAULT);
		} catch ( Exception e ) {
			log.error("{}", e);
			throw new Exception(ExceptionConstants.ERROR_CODE_DEFAULT);
		}
	}


}