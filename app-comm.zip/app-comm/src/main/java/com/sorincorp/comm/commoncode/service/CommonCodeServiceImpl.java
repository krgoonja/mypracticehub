package com.sorincorp.comm.commoncode.service;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.commoncode.mapper.CommonCodeMapper;
import com.sorincorp.comm.commoncode.model.CommonCodeVO;
import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CommonCodeServiceImpl implements CommonCodeService {
	@Autowired
	CommonCodeMapper codeMapper;

	@Autowired
	private RedisUtil redisUtil;

	public void initCommonCodeList() throws Exception {
		List<CommonCodeVO> codeList = codeMapper.selectAllCommonCodes();
		redisUtil.setData("commonCodeList", codeList);
//		if(codeList != null && codeList.size() > 0 ) {
//			String mainCodeKey = "";
//			List<CommonCodeVO> tempCodeList = new ArrayList<CommonCodeVO>();
//			for (CommonCodeVO commonCodeVO : codeList) {
//				if(!mainCodeKey.equals(commonCodeVO.getMainCode())) {
//					if(tempCodeList.size() > 0) {
//						redisUtil.setData("commonCode:" + mainCodeKey, codeList);
//						tempCodeList.clear();
//					}
//					mainCodeKey =  commonCodeVO.getMainCode();
//				}
//				tempCodeList.add(commonCodeVO);
//			}
//		}
	}

	@Cacheable(cacheNames = "Comm_Code", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public void initCommonCodeByMainCode(String mainCode) throws Exception {
		List<CommonCodeVO> codeList = codeMapper.selectCommonCodesByMain(mainCode);
		redisUtil.setData("commonCode:" + mainCode, codeList);
	}

	@SuppressWarnings("unchecked")
	@Cacheable(cacheNames = "Comm_Code", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public Map<String, String> getMainCodes() throws Exception {
		List<CommonCodeVO> codeList = (List<CommonCodeVO>)redisUtil.getData("commonCodeList");

		if ( codeList == null ) {
			initCommonCodeList();
			codeList = (List<CommonCodeVO>)redisUtil.getData("commonCodeList");
		}
		return	codeList.stream()
					.filter(data -> StringUtils.equals(data.getSubCode(), "@"))
					.sorted((o1, o2) -> o1.getCodeOrdr() - o2.getCodeOrdr())
					.collect(Collectors.toMap(CommonCodeVO::getMainCode, CommonCodeVO::getCodeNm, (o1, o2) -> o1, LinkedHashMap::new));

	}

	/**
	 * <pre>
	 * 처리내용: String 반환의 getMainCodes를 CommonCodeVO 반환으로 변경한 메소드
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0049			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@Cacheable(cacheNames = "Comm_Code", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public Map<String, CommonCodeVO> getMainCodesRetVo() throws Exception {
		List<CommonCodeVO> codeList = (List<CommonCodeVO>)redisUtil.getData("commonCodeList");

		if ( codeList == null ) {
			initCommonCodeList();
			codeList = (List<CommonCodeVO>)redisUtil.getData("commonCodeList");
		}
		return	codeList.stream()
					.filter(data -> StringUtils.equals(data.getSubCode(), "@"))
					.sorted((o1, o2) -> o1.getCodeOrdr() - o2.getCodeOrdr())
					.collect(Collectors.toMap(CommonCodeVO::getMainCode,  Function.identity(), (o1, o2) -> o1, LinkedHashMap::new));

	}

	@SuppressWarnings("unchecked")
	@Cacheable(cacheNames = "Comm_Code", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public Map<String, String> getSubCodes(String mainCode) throws Exception {
		List<CommonCodeVO> codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);

		if ( codeList == null ) {
			initCommonCodeByMainCode(mainCode);
			codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);
		}

		return	codeList.stream()
					.filter(data -> (!StringUtils.equals(data.getSubCode(), "@") && StringUtils.equals(data.getMainCode(), mainCode)))
					.sorted((o1, o2) -> o1.getCodeOrdr() - o2.getCodeOrdr())
					.collect(Collectors.toMap(CommonCodeVO::getSubCode, CommonCodeVO::getCodeNm, (o1, o2) -> o1, LinkedHashMap::new));

	}

	/**
	 * <pre>
	 * 처리내용: String 반환의 getSubCodes를 CommonCodeVO 반환으로 변경한 메소드
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@Cacheable(cacheNames = "Comm_Code", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public Map<String, CommonCodeVO> getSubCodesRetVo(String mainCode) throws Exception {
		List<CommonCodeVO> codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);

		if ( codeList == null ) {
			initCommonCodeByMainCode(mainCode);
			codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);
		}

		return	codeList.stream()
					.filter(data -> (!StringUtils.equals(data.getSubCode(), "@") && StringUtils.equals(data.getMainCode(), mainCode)))
					.sorted((o1, o2) -> o1.getCodeOrdr() - o2.getCodeOrdr())
					.collect(Collectors.toMap(CommonCodeVO::getSubCode, Function.identity(), (o1, o2) -> o1, LinkedHashMap::new));

	}

	@SuppressWarnings("unchecked")
	@Cacheable(cacheNames = "Comm_Code", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public Map<String, CommonCodeVO> getSubCodesRetVo(String mainCode, String subCode) throws Exception {

		if (StringUtil.isBlank(subCode)) {
			return getSubCodesRetVo(mainCode);
		}

		List<CommonCodeVO> codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);

		if ( codeList == null ) {
			initCommonCodeByMainCode(mainCode);
			codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);
		}

		return	codeList.stream()
					.filter(data -> (!StringUtils.equals(data.getSubCode(), "@") && StringUtils.equals(data.getMainCode(), mainCode)))
					.filter(data -> (StringUtils.equals(data.getSubCode(), subCode)))
					.sorted((o1, o2) -> o1.getCodeOrdr() - o2.getCodeOrdr())
					.collect(Collectors.toMap(CommonCodeVO::getSubCode, Function.identity(), (o1, o2) -> o1, LinkedHashMap::new));

	}

	@SuppressWarnings("unchecked")
	@Cacheable(cacheNames = "Comm_Code", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public Map<String, String> getFilterCode(String mainCode, String subCode, String columKey, String columnValue) throws Exception {

		if(StringUtils.isEmpty(mainCode)) {
			return null;
		}

		List<CommonCodeVO> codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);

		if ( codeList == null ) {
			initCommonCodeByMainCode(mainCode);
			codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);
		}


		Map<String, String> resultMap = codeList.stream()
											.filter(data ->
												{
													boolean chk = true;
													if(!StringUtils.isEmpty(mainCode) && !StringUtils.equals(data.getMainCode(), mainCode)) {
														chk = false;
													}
													return chk;

												}
											)
											.filter(data ->
												{
													boolean chk = true;
													if((!StringUtils.isEmpty(subCode) && !StringUtils.equals(data.getSubCode(), subCode)) || StringUtils.equals(data.getSubCode(), "@")) {
														chk = false;
													}
													return chk;

												}
											)
											.filter(data ->
												{
													log.debug("data => {}", data);
													boolean chk = true;
													if(!StringUtils.isEmpty(columKey) && !StringUtils.isEmpty(columnValue)) {
														String fieldValue = StringUtils.EMPTY;
														String colunm = JdbcUtils.convertUnderscoreNameToPropertyName(columKey);
														try {
															Field field = data.getClass().getDeclaredField(colunm);
															field.setAccessible(true);
															fieldValue = field.get(data) != null ? field.get(data).toString() : "";
														} catch (Exception e) {
															chk = false;
															log.error(ExceptionUtils.getStackTrace(e));
														}

														if(!StringUtils.equals(fieldValue, columnValue)) {
															chk = false;
														}
													}
													return chk;
												}
											)
											.sorted((o1, o2) -> o1.getCodeOrdr() - o2.getCodeOrdr())
											.collect(Collectors.toMap(CommonCodeVO::getSubCode, CommonCodeVO::getCodeNm, (o1, o2) -> o1, LinkedHashMap::new));

		return resultMap;
	}

	/**
	 * <pre>
	 * 처리내용: String 반환의 getFilterCode를 CommonCodeVO 반환으로 변경한 메소드
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @param subCode
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@Cacheable(cacheNames = "Comm_Code", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public Map<String, CommonCodeVO> getFilterCodeRetVo(String mainCode, String subCode, String columKey, String columnValue) throws Exception {

		if(StringUtils.isEmpty(mainCode)) {
			return null;
		}

		List<CommonCodeVO> codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);

		if ( codeList == null ) {
			initCommonCodeByMainCode(mainCode);
			codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);
		}


		Map<String, CommonCodeVO> resultMap = codeList.stream()
											.filter(data ->
												{
													boolean chk = true;
													if(!StringUtils.isEmpty(mainCode) && !StringUtils.equals(data.getMainCode(), mainCode)) {
														chk = false;
													}
													return chk;

												}
											)
											.filter(data ->
												{
													boolean chk = true;
													if((!StringUtils.isEmpty(subCode) && !StringUtils.equals(data.getSubCode(), subCode)) || StringUtils.equals(data.getSubCode(), "@")) {
														chk = false;
													}
													return chk;

												}
											)
											.filter(data ->
												{
													boolean chk = true;
													if(!StringUtils.isEmpty(columKey) && !StringUtils.isEmpty(columnValue)) {
														String fieldValue = StringUtils.EMPTY;
														String colunm = JdbcUtils.convertUnderscoreNameToPropertyName(columKey);
														try {
															Field field = data.getClass().getDeclaredField(colunm);
															field.setAccessible(true);
															fieldValue = field.get(data).toString();
														} catch (Exception e) {
															chk = false;
															log.error(e.getMessage());
														}

														if(!StringUtils.equals(fieldValue, columnValue)) {
															chk = false;
														}
													}
													return chk;
												}
											)
											.sorted((o1, o2) -> o1.getCodeOrdr() - o2.getCodeOrdr())
											.collect(Collectors.toMap(CommonCodeVO::getSubCode, Function.identity(), (o1, o2) -> o1, LinkedHashMap::new));

		return resultMap;
	}

	/**
	 * <pre>
	 * 처리내용: 메인코드와 서브코드, 조회할 컬럼명, 컬럼값, 시작 인덱스, 종료 인덱스로 구성된 가변인자로 공통코드를 필터하여 CommonCodeVO 값을 가진 맵으로 반환한다.
	 * </pre>
	 * @date 2022. 3. 4.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 3. 4.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param mainCode 메인코드
	 * @param subCode 서브코드
	 * @param columnInfo 조회할 컬럼명, 컬럼값, 시작 인덱스, 종료 인덱스로 구성된 가변인자
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@Cacheable(cacheNames = "Comm_Code", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public Map<String, CommonCodeVO> getMultiFilterCodeRetVo(String mainCode, String subCode, String... columnInfo) throws Exception {

		if(StringUtils.isEmpty(mainCode)) {
			return null;
		}

		int position = 4; // columnInfo의 그룹 갯수, 4개씩 그룹
		int columnInfoLength = columnInfo.length;

		if(columnInfoLength == 0 || (columnInfoLength % position ) != 0 ) {
			return null;
		}

		// columnInfo의 그룹 단위로 다시 리스트에 담는다.
		List<String[]> detailConditionList = new ArrayList<String[]>();
		for(int idx=0; idx<Math.floorDiv(columnInfoLength, position); idx++) {
			detailConditionList.add(Arrays.copyOfRange(columnInfo, idx*position, idx*position+position));
		}

//		detailConditionList.stream().forEach(e -> log.debug(">> detailCondition check : " + Arrays.toString(e)));

		List<CommonCodeVO> codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);

		if ( codeList == null ) {
			initCommonCodeByMainCode(mainCode);
			codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);
		}

		Map<String, CommonCodeVO> resultMap = codeList.stream()
											.filter(data ->
												{
													boolean chk = true;
													if(!StringUtils.isEmpty(mainCode) && !StringUtils.equals(data.getMainCode(), mainCode)) {
														chk = false;
													}
													return chk;

												}
											)
											.filter(data ->
												{
													boolean chk = true;
													if((!StringUtils.isEmpty(subCode) && !StringUtils.equals(data.getSubCode(), subCode)) || StringUtils.equals(data.getSubCode(), "@")) {
														chk = false;
													}
													return chk;

												}
											)
											.filter(data ->
												{
													boolean chk = true;

													for(int i=0; i<detailConditionList.size(); i++) {
														String[] detailCondition = detailConditionList.get(i);
														String columnKey = detailCondition[0]; // 컬럼명
														String columnValue = detailCondition[1]; // 컬럼값
														String startIndex = detailCondition[2]; // 컬럼값에서 자를 시작 인덱스
														String endIndex = detailCondition[3]; // 컬럼값에서 자를 종료 인덱스

														if(!StringUtils.isEmpty(columnKey) && !StringUtils.isEmpty(columnValue)) {
															String fieldValue = StringUtils.EMPTY;
															String colunm = JdbcUtils.convertUnderscoreNameToPropertyName(columnKey);
															try {
																Field field = data.getClass().getDeclaredField(colunm);
																field.setAccessible(true);
																fieldValue = field.get(data).toString();
															} catch (Exception e) {
																chk = false;
																log.error(e.getMessage());
															}

															// startIndex와 endIndex가 null이 아닐 때
															if(!StringUtils.isEmpty(startIndex) && !StringUtils.isEmpty(endIndex)) {
																if(!StringUtils.isEmpty(fieldValue)) {
																	String fieldValueSubStr = fieldValue.substring(Integer.parseInt(startIndex), Integer.parseInt(endIndex));
																	if(!StringUtils.equals(fieldValueSubStr, columnValue)) {
																		chk = false;
																	}
																} else {
																	// 빈 값이면 false
																	chk = false;
																}
															} else {
																if(!StringUtils.equals(fieldValue, columnValue)) {
																	chk = false;
																}
															}
														}
													}

													return chk;
												}
											)
											.sorted((o1, o2) -> o1.getCodeOrdr() - o2.getCodeOrdr())
											.collect(Collectors.toMap(CommonCodeVO::getSubCode, Function.identity(), (o1, o2) -> o1, LinkedHashMap::new));

		return resultMap;
	}

	@SuppressWarnings("unchecked")
	@Cacheable(cacheNames = "Comm_Code", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public String getCodeValue(String mainCode, String subCode) throws Exception {
		List<CommonCodeVO> codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);

		if ( codeList == null ) {
			initCommonCodeByMainCode(mainCode);
			codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);
		}
		List<CommonCodeVO> codeDetail = codeList.stream().filter(data -> (StringUtils.equals(data.getMainCode(), mainCode) && StringUtils.equals(data.getSubCode(), subCode))).collect(Collectors.toList());

		String codeValue = StringUtils.EMPTY;

		if(codeDetail.size() > 0) {
			codeValue = codeDetail.get(0).getCodeNm();
		}

		return codeValue;
	}

	/**
	 * <pre>
	 * 처리내용: String 반환의 getCodeValue를 CommonCodeVO 반환으로 변경한 메소드
	 * </pre>
	 * @date 2021. 8. 18.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 18.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param mainCode
	 * @param subCode
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@Cacheable(cacheNames = "Comm_Code", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public CommonCodeVO getCodeValueRetVo(String mainCode, String subCode) throws Exception {
		List<CommonCodeVO> codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);

		if ( codeList == null ) {
			initCommonCodeByMainCode(mainCode);
			codeList = (List<CommonCodeVO>)redisUtil.getData("commonCode:" + mainCode);
		}
		List<CommonCodeVO> codeDetail = codeList.stream().filter(data -> (StringUtils.equals(data.getMainCode(), mainCode) && StringUtils.equals(data.getSubCode(), subCode))).collect(Collectors.toList());

		CommonCodeVO codeValueRetVo = null;

		if(codeDetail.size() > 0) {
			codeValueRetVo = codeDetail.get(0);
		}

		return codeValueRetVo;
	}

	/** SubCodes를 조회한뒤 CommonCodeVO 로 바로 리턴하는 메소드
	 * <pre>
	 * 처리내용:
	 * </pre>
	 * @date 2022. 8. 9.
	 * @author jhcha
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 8.			jhcha				최초작성
	 * ------------------------------------------------
	 * @param commonCode
	 * @param addCode
	 * @return String
	 * @throws Exception
	 */
	@Cacheable(cacheNames = "Comm_Code", keyGenerator = "prefixMethodNameKeyGenerator", cacheManager="localCacheManager")
	public List<CommonCodeVO> getSubCodesToCommonCode(String mainCode) throws Exception {

		List<CommonCodeVO> codeList = codeMapper.selectCommonCodesByMain(mainCode);

		return codeList.stream()
					.filter(data -> (!StringUtils.equals(data.getSubCode(), "@")
										&& !StringUtils.equals(data.getDeleteAt(), "Y")
										&& StringUtils.equals(data.getMainCode(), mainCode)
										))
					.sorted((o1, o2) -> o1.getCodeOrdr() - o2.getCodeOrdr())
					.collect(Collectors.toList());
	}

	/**
	 * <pre>
	 * 처리내용: CommonCodeVO 를  구분자 :, ; 를 넣어서 String 으로 변환
	 * </pre>
	 * @date 2022. 8. 5.
	 * @author jhcha
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 5.			jhcha				최초작성
	 * ------------------------------------------------
	 * @param commonCode
	 * @param addCode
	 * @return String
	 * @throws Exception
	 */
	public String getCmmnCodeListStr(List<CommonCodeVO> commonCode, Map<String, String> addCode) throws Exception {
		StringBuilder codeTaglibStr = new StringBuilder(StringUtils.EMPTY);

		if(addCode.size() > 0) {
			for( String code : addCode.keySet() ) {
				codeTaglibStr.append(code);
				codeTaglibStr.append(CommonConstants.COLONE);
				codeTaglibStr.append(addCode.get(code));
				codeTaglibStr.append(CommonConstants.SEMI_COLONE);
			}
		}

		for( CommonCodeVO resultMap : commonCode ) {
			codeTaglibStr.append(resultMap.getSubCode());
			codeTaglibStr.append(CommonConstants.COLONE);
			codeTaglibStr.append(resultMap.getCodeNm());
			codeTaglibStr.append(CommonConstants.SEMI_COLONE);
		}

		return codeTaglibStr.toString();
	}
}
