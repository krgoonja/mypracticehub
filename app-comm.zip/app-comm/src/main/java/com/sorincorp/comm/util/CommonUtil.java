package com.sorincorp.comm.util;

import java.lang.reflect.Array;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value = "classpath:/config/dblink/dblink-${spring.profiles.active}.properties", ignoreResourceNotFound = true)
public class CommonUtil {
	
	public static String dblinkStsName;
	
	public static String dblinkQbicName;
	
	@Value("${dblinkConfig.sts.name}")
	public void setDblinkStsName(String value) {
		dblinkStsName = value;
	}
	
	@Value("${dblinkConfig.qbic.name}")
	public void setDblinkQbicName(String value) {
		dblinkQbicName = value;
	}
	
	/** 
	 * Object type 변수가 비어있는지 체크
	 * @param obj 
	 * @return Boolean : true / false
	 */
	public static Boolean isEmpty(Object obj) {
		
		if (obj instanceof String){
		
			return obj == null || "".equals(obj.toString().trim());
		
		}else if (obj instanceof List) {
		
			return obj == null || ((List<?>) obj).isEmpty();
		
		}else if (obj instanceof Map){
		
			return obj == null || ((Map<?, ?>) obj).isEmpty();
		
		}else if (obj instanceof Object[]){
			
			return obj == null || Array.getLength(obj) == 0;
		
		}else {
		
			return obj == null;
		} 
	}
		
	/** 
	 * Object type 변수가 비어있지 않은지 체크 
	 * @param obj
	 * @return Boolean : true / false
	 */
	public static Boolean isNotEmpty(Object obj) {    
		return !isEmpty(obj);
	}
	
	/**
	 * yml 파일에서 STS시스템 DB_LINK 값을 가져온다
	 * @return String
	 */
	public static String getDblinkStsName() {
		return dblinkStsName;
	}
	
	/**
	 * yml 파일에서 QBIC시스템 DB_LINK 값을 가져온다
	 * @return String
	 */
	public static String getDblinkQbicName() {
		return dblinkQbicName;
	}
}	
	
