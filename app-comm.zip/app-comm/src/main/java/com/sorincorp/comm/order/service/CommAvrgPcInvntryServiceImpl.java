package com.sorincorp.comm.order.service;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.order.mapper.CommAvrgPcInvntryMapper;
import com.sorincorp.comm.order.model.CommAvrgPcInvntryVO;

import lombok.extern.slf4j.Slf4j;

/**
 * CommAvrgPcInvntryServiceImpl.java
 * 평균가 재고 공통 Service 구현체 클래스
 * 
 * @version
 * @since 2023. 11. 21.
 * @author srec0049
 */
@Slf4j
@Service
public class CommAvrgPcInvntryServiceImpl implements CommAvrgPcInvntryService {
	
	/**
	 * 평균가 재고 공통 Mapper 인터페이스
	 */
	@Autowired
	CommAvrgPcInvntryMapper commAvrgPcInvntryMapper;
	
	
	/**
	 * 계약_계약 월 할당 재고 상세 이력 등록, 할당 해제 시 할당 중량, 할당 재고, 할당 번들 재고를 0으로 등록한다.
	 */
	@Override
	public int insertCnCntrctMtAsgnInvntryDtlHst(CommAvrgPcInvntryVO commAvrgPcInvntryVO) throws Exception {
		int insertCnCntrctMtAsgnInvntryDtlHst = commAvrgPcInvntryMapper.insertCnCntrctMtAsgnInvntryDtlHst(commAvrgPcInvntryVO);
		
		return insertCnCntrctMtAsgnInvntryDtlHst;
	}
	
	/**
	 * 평균가 할당/발주/결제 재고 차감 증가 
	 *     평균가구분(avrgSe) : ASGN(할당), ORDER(발주), SETLE(결제)
	 *     처리구분(processSe) : DDCT(차감), INCRS(증가)
	 */
	@Override
	public boolean insertAndUpdateAvrgPcInvntryDdctIncrs(CommAvrgPcInvntryVO commAvrgPcInvntryVO) throws Exception {
		log.warn(">> insertAndUpdateAvrgPcInvntryDdctIncrs commAvrgPcInvntryVO : " + String.valueOf(commAvrgPcInvntryVO));
		
		boolean ddctResultStatus = true;
		
		String avrgSe = commAvrgPcInvntryVO.getAvrgSe(); // 평균가구분(avrgSe) [ASGN(할당), ORDER(발주), SETLE(결제)]
		String processSe = commAvrgPcInvntryVO.getProcessSe(); // 처리구분(processSe) [DDCT(차감), INCRS(증가)]
		
		// 평균가구분(avrgSe)과 처리구분(processSe)에 따른 할당 이벤트 유형 코드 가져오기
		commAvrgPcInvntryVO.setAsgnEventTyCode(this.getAsgnEventTyCode(avrgSe, processSe));
		// 처리구분(processSe)에 따른 할당 이벤트 중량 가져오기
		commAvrgPcInvntryVO.setAsgnEventWt(this.getAsgnEventWt(processSe, commAvrgPcInvntryVO.getCalcWt()));
		
		// 평균가구분(avrgSe) [ASGN(할당), ORDER(발주), SETLE(결제)]에 따른 계약_계약 월 할당 재고 상세 분기 처리
		switch(avrgSe) {
			case "ASGN" : // 할당
				// 계약_계약 월 할당 재고 상세에 해당 데이터 중 할당 중량 값을 반환
				Integer asgnWt = commAvrgPcInvntryMapper.getAsgnWtCnCntrctMtAsgnInvntryDtl(commAvrgPcInvntryVO);
				log.warn(">> insertAndUpdateAvrgPcInvntryDdctIncrs ASGN asgnWt : " + asgnWt);
				
				// 처리구분(processSe) [DDCT(차감), INCRS(증가)]에 따른 계약_계약 월 할당 재고 상세 분기 처리
				switch(processSe) {
					case "DDCT" : // 차감 (할당해제)
						if(asgnWt == null) {
							// 해제불가 - 실패
							throw new Exception(commAvrgPcInvntryVO.getBlNo() + " BL번호의 재고 해제 가능한 데이터가 존재하지 않습니다.");
						} else {
							int chkAsgnWt = asgnWt - commAvrgPcInvntryVO.getCalcWt(); // 해제 가능한 수량에 해제 대상 수량 뺀 값
							
							// 삭제인지 수정인지 판단
							if(chkAsgnWt == 0) {
								commAvrgPcInvntryVO.setDmlSe("delete"); // DML 구분 (delete, update, insert)
								
								log.warn(">> insertAndUpdateAvrgPcInvntryDdctIncrs ASGN DDCT 할당 차감 (삭제) commAvrgPcInvntryVO : " + String.valueOf(commAvrgPcInvntryVO));
								
								// 계약_계약 월 할당 재고 상세 이력 등록, 할당 해제 시 할당 중량, 할당 재고, 할당 번들 재고를 0으로 등록한다.
								commAvrgPcInvntryMapper.insertCnCntrctMtAsgnInvntryDtlHst(commAvrgPcInvntryVO);
								// 할당해제, 계약_계약 월 할당 재고 상세에 해당 데이터 삭제 (DELETE_AT(삭제 여부) 수정 처리가 아니라 데이터 삭제)
								commAvrgPcInvntryMapper.deleteCnCntrctMtAsgnInvntryDtl(commAvrgPcInvntryVO);
							} else if(chkAsgnWt > 0) {
								log.warn(">> insertAndUpdateAvrgPcInvntryDdctIncrs ASGN DDCT 할당 차감 (수정) commAvrgPcInvntryVO : " + String.valueOf(commAvrgPcInvntryVO));
								
								// 계약_계약 월 할당 재고 상세에 해당 데이터 수정 (할당, 발주, 결제 용도)
								commAvrgPcInvntryMapper.updateCnCntrctMtAsgnInvntryDtl(commAvrgPcInvntryVO);
								// 계약_계약 월 할당 재고 상세 이력 등록, 할당 해제 시 할당 중량, 할당 재고, 할당 번들 재고를 0으로 등록한다.
								commAvrgPcInvntryMapper.insertCnCntrctMtAsgnInvntryDtlHst(commAvrgPcInvntryVO);
							} else {
								// 해제불가 - 실패
								throw new Exception(commAvrgPcInvntryVO.getBlNo() + " BL번호의 재고 해제 수량이 부족합니다.[" + asgnWt + ", " + commAvrgPcInvntryVO.getCalcWt() + "]");
							}
						}
						
						break;
					case "INCRS" : // 증가 (할당)
						if(asgnWt == null) {
							log.warn(">> insertAndUpdateAvrgPcInvntryDdctIncrs ASGN INCRS 할당 증가 (등록) commAvrgPcInvntryVO : " + String.valueOf(commAvrgPcInvntryVO));
							
							// 계약_계약 월 할당 재고 상세에 해당 데이터 등록 (할당 용도)
							commAvrgPcInvntryMapper.insertCnCntrctMtAsgnInvntryDtl(commAvrgPcInvntryVO);
							// 계약_계약 월 할당 재고 상세 이력 등록
							commAvrgPcInvntryMapper.insertCnCntrctMtAsgnInvntryDtlHst(commAvrgPcInvntryVO);
						} else {
							log.warn(">> insertAndUpdateAvrgPcInvntryDdctIncrs ASGN INCRS 할당 증가 (수정) commAvrgPcInvntryVO : " + String.valueOf(commAvrgPcInvntryVO));
							
							// 계약_계약 월 할당 재고 상세에 해당 데이터 수정 (할당, 발주, 결제 용도)
							commAvrgPcInvntryMapper.updateCnCntrctMtAsgnInvntryDtl(commAvrgPcInvntryVO);
							// 계약_계약 월 할당 재고 상세 이력 등록
							commAvrgPcInvntryMapper.insertCnCntrctMtAsgnInvntryDtlHst(commAvrgPcInvntryVO);
						}
						
						break;
				}
				
				break;
			case "ORDER" : // 발주
			case "SETLE" : // 결제
				// 처리구분(processSe) [DDCT(차감), INCRS(증가)] 동일 로직
				log.warn(">> insertAndUpdateAvrgPcInvntryDdctIncrs " + avrgSe + " " + processSe + " 수정 commAvrgPcInvntryVO : " + String.valueOf(commAvrgPcInvntryVO));
				
				// 계약_계약 월 할당 재고 상세에 해당 데이터 수정 (할당, 발주, 결제 용도)
				commAvrgPcInvntryMapper.updateCnCntrctMtAsgnInvntryDtl(commAvrgPcInvntryVO);
				// 계약_계약 월 할당 재고 상세 이력 등록
				commAvrgPcInvntryMapper.insertCnCntrctMtAsgnInvntryDtlHst(commAvrgPcInvntryVO);
				
				break;
		}
		
		// 평균가구분(avrgSe) [ASGN(할당), ORDER(발주), SETLE(결제)]에 따른 상품_BL 정보 분기 처리, 처리구분(processSe) [DDCT(차감), INCRS(증가)] 동일 로직
		switch(avrgSe) {
			case "ASGN" : // 할당
				// 처리구분(processSe) [DDCT(차감), INCRS(증가)]에 따른 상품_BL 정보 분기 처리
				switch(processSe) {
					case "DDCT" : // 차감 (할당해제)
						// IT_BL_INFO_HIST_DTL(상품_BL 정보 이력 상세)에서 사용, BL 이력 이벤트 유형 코드, 17(할당해제)
						commAvrgPcInvntryVO.setBlHistEventTyCode("17"); 
						break;
					case "INCRS" : // 증가 (할당)
						// IT_BL_INFO_HIST_DTL(상품_BL 정보 이력 상세)에서 사용, BL 이력 이벤트 유형 코드, 16(할당)
						commAvrgPcInvntryVO.setBlHistEventTyCode("16");
						break;
				}
				
				StringBuilder eventIsuNo = new StringBuilder(); // 이벤트 발행 번호 문자열
				// 이벤트 발행 번호 [계약번호_계약년월_계약년월순번_재고할당구분코드]
				commAvrgPcInvntryVO.setEventIsuNo(
					eventIsuNo.append(commAvrgPcInvntryVO.getCntrctNo()).append("_").append(commAvrgPcInvntryVO.getCntrctYm()).append("_").append(commAvrgPcInvntryVO.getCntrctYmSn())
						.append("_").append(commAvrgPcInvntryVO.getInvntryAsgnSeCode()).toString()
				); 
				eventIsuNo = null; // StringBuilder 메모리 해제 유도
				
				break;
			case "SETLE" : // 결제
				// 처리구분(processSe) [DDCT(차감), INCRS(증가)]에 따른 상품_BL 정보 분기 처리
				switch(processSe) {
					case "DDCT" : // 차감 (결제취소)
						// IT_BL_INFO_HIST_DTL(상품_BL 정보 이력 상세)에서 사용, BL 이력 이벤트 유형 코드, 04(주문취소)
						commAvrgPcInvntryVO.setBlHistEventTyCode("04"); 
						break;
					case "INCRS" : // 증가 (결제)
						// IT_BL_INFO_HIST_DTL(상품_BL 정보 이력 상세)에서 사용, BL 이력 이벤트 유형 코드, 03(주문)
						commAvrgPcInvntryVO.setBlHistEventTyCode("03");
						break;
				}
				
				// 이벤트 발행 번호 [주문번호]
				commAvrgPcInvntryVO.setEventIsuNo(commAvrgPcInvntryVO.getOrderNo());
				
				break;
		}
		
		// 발주가 아닐 경우
		if(!StringUtils.equals("ORDER", avrgSe)) {
			log.warn(">> insertAndUpdateAvrgPcInvntryDdctIncrs " + avrgSe + " " + processSe + " 상품_BL 정보 관련 수정 commAvrgPcInvntryVO : " + String.valueOf(commAvrgPcInvntryVO));
			
			// 할당, 결제의 차감, 증가에 따른 상품_BL 정보 기본 정보를 수정한다. [IT_BL_INFO_BAS(상품_BL 정보 기본)] (할당, 결제 용도)
			commAvrgPcInvntryMapper.updateItBlInfoBasByAvrgInvntry(commAvrgPcInvntryVO);
			
			// 할당, 결제의 차감, 증가에 따른 상품_BL 정보 이력 상세를 등록한다. [IT_BL_INFO_HIST_DTL(상품_BL 정보 이력 상세)] (할당, 결제 용도)
			commAvrgPcInvntryMapper.insertItBlInfoHistDtlByInvntryAsgn(commAvrgPcInvntryVO);
			
			// 할당, 결제의 차감, 증가에 따른 상품_BL 정보 기본 이력을 등록한다. [IT_BL_INFO_BAS_HST(상품_BL 정보 기본 이력)] (할당, 결제 용도)
			commAvrgPcInvntryMapper.insertItBlInfoBasHstByInvntryAsgn(commAvrgPcInvntryVO);
		}
		
		return ddctResultStatus;
	}
	
	/**
	 * <pre>
	 * 처리내용: 평균가구분(avrgSe)과 처리구분(processSe)에 따른 할당 이벤트 유형 코드 가져오기
	 *   : 평균가구분(avrgSe) [ASGN(할당), ORDER(발주), SETLE(결제)]
	 *   : 처리구분(processSe) [DDCT(차감), INCRS(증가)]
	 * </pre>
	 * @date 2023. 12. 19.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 12. 19.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param avrgSe
	 * @param processSe
	 * @return
	 */
	public String getAsgnEventTyCode(String avrgSe, String processSe) {
		String asgnEventTyCode = ""; // 할당 이벤트 유형 코드
		
		switch(avrgSe) {
			case "ASGN" : // 할당
				switch(processSe) {
					case "DDCT" : // 차감 (할당해제)
						asgnEventTyCode = "20"; // 할당 이벤트 유형 코드 : 할당해제 (20)
						
						break;
					case "INCRS" : // 증가 (할당)
						asgnEventTyCode = "10"; // 할당 이벤트 유형 코드 : 할당 (10)
						break;
				}
				
				break;
			case "ORDER" : // 발주
				switch(processSe) {
					case "DDCT" : // 차감 (발주취소)
						asgnEventTyCode = "40"; // 할당 이벤트 유형 코드 : 발주취소 (40)
						
						break;
					case "INCRS" : // 증가 (발주)
						asgnEventTyCode = "30"; // 할당 이벤트 유형 코드 : 발주 (30)
						break;
				}
				
				break;
			case "SETLE" : // 결제
				switch(processSe) {
					case "INCRS" : // 증가 (결제)
						asgnEventTyCode = "50"; // 할당 이벤트 유형 코드 : 결제 (50)
						break;
				}
				
				break;
		}
		
		return asgnEventTyCode;
	}
	
	/**
	 * <pre>
	 * 처리내용: 처리구분(processSe)에 따른 할당 이벤트 중량 가져오기
	 * </pre>
	 * @date 2023. 12. 19.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 12. 19.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param processSe
	 * @param calcWt
	 * @return
	 */
	public int getAsgnEventWt(String processSe, int calcWt) {
		int asgnEventWt = 0; // 할당 이벤트 중량
		
		switch(processSe) {
			case "DDCT" : // 차감 (할당해제, 발주취소)
				asgnEventWt = calcWt * -1;
				
				break;
			case "INCRS" : // 증가 (할당, 발주, 결제)
				asgnEventWt = calcWt;
				break;
		}
		
		return asgnEventWt;
	}
}
