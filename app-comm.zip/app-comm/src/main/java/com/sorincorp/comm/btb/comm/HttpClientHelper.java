package com.sorincorp.comm.btb.comm;

import java.net.URI;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.btb.config.HttpClientConfig;
import com.sorincorp.comm.btb.model.BtoBInrecfcLogVO;
import com.sorincorp.comm.btb.model.BtoBReqBase;
import com.sorincorp.comm.btb.model.BtoBReqEntity;
import com.sorincorp.comm.btb.model.BtoBResEntity;
import com.sorincorp.comm.btb.service.BtoBApiService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * <pre>
 * 처리내용: BTOB CNI 통신에 필요한 모듈을 제공한다.
 * </pre>
 * HttpClientHelper.java
 * @version
 * @since 2021. 6. 10.
 * @author srec0043
 * @history
 * ------------------------------------------------
 * 변경일					작성자				변경내용
 * ------------------------------------------------
 * 2021. 6. 10.			srec0043			최초작성
 * ------------------------------------------------
 */
@Slf4j
@Component
@PropertySource(value = "classpath:/config/btb/btb-${spring.profiles.active}.properties", ignoreResourceNotFound = true)
public class HttpClientHelper {

	@Autowired
	private HttpClientConfig httpClientConfig;

	@Autowired
	private HttpClient httpClient;

	@Autowired
	private BtoBApiService btoBApiService;

	/* B2BCNI 호출 URL */
	@Value("${btb.comm.url}")
	private String btbBaseUrl;

	/* B2BCNI 호출 APIKEY */
	@Value("${btb.comm.request.apiKey}")
	private String btbReqApiKey;

	/* B2BCNI 응답 APIKEY */
	@Value("${btb.comm.response.apiKey}")
	private String btbResApiKey;

	/* EHR 토큰 발급 URL */
	@Value("${btb.ehr.token.url}")
    private String tokenUrl;

	/* EHR 토큰 발급 ID */
	@Value("${btb.ehr.token.id}")
    private String tokenId;

	/* EHR 토큰 발급 PWD */
	@Value("${btb.ehr.token.pwd}")
    private String tokenPwd;

//	/* 로그 객체 */
//	private BtoBInrecfcLogVO btbLogVo;

	/* 재활용 ObjectMapper */
	private ObjectMapper objMapper;

	/**
	 * 초기값 설정
	 */
	public HttpClientHelper() {
		objMapper = new ObjectMapper();
	}

	/**
	 * <pre>
	 * EHR 호출시 Token 값을 받아온다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0043			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	public String getToken() throws Exception{

		URI uri;
		String resultJson = StringUtils.EMPTY;
		HttpPost httpPost = httpClientConfig.httpPost();
		uri = new URIBuilder(tokenUrl)
			    .addParameter(BtoBConstants.REQUEST_TOKEN_ID_KEY, tokenId)
			    .addParameter(BtoBConstants.REQUEST_TOKEN_PWD_KEY, tokenPwd)
			    .build();

		log.debug(uri.toString());

		httpPost.setURI(uri);
		HttpResponse httpResponse = httpClient.execute(httpPost);
		resultJson = EntityUtils.toString(httpResponse.getEntity());
		JSONObject obj  = new JSONObject(new JSONObject(resultJson).getString(BtoBConstants.RESPONSE_RESULT_DATA_KEY));
		resultJson = obj.getString(BtoBConstants.RESPONSE_TOKEN_JWT_KEY);

		return resultJson;
	}

	/**
	 * <pre>
	 * 호출 URI를 설정한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param req
	 * @return
	 * @throws Exception
	 */
	public URI setURI(BtoBReqEntity req) throws Exception{
		URI uri = new URIBuilder(btbBaseUrl).build();
		return uri;
	}

	/**
	 * <pre>
	 * 호출 Header를 설정한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param req
	 * @throws Exception
	 */
	public void setHeader(BtoBReqEntity req) throws Exception{
		Map<String,String> header = new HashMap<String, String>();
		header.put(BtoBConstants.BTB_REQUEST_API_KEY, btbReqApiKey);
		header.put(BtoBConstants.BTB_INTERFACE_ID, req.getInterfaceId());
		if(StringUtils.equals(req.getTargetSys(), BtoBConstants.BTB_EHR_SYSTEM)) {
			header.put(BtoBConstants.BTB_EHR_TOKEN_NAME, getToken());
		}
		req.setHeader(header);
	}

	/**
	 * <pre>
	 * 처리내용: 호출 reqeust를 설정 시 jsonEntity 생성을 따로 분리한다, 20230619 추가
	 * </pre>
	 * @date 2023. 6. 19.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 6. 19.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param req
	 * @return
	 * @throws Exception
	 */
	public String setJsonEntity(BtoBReqEntity req) throws Exception {
		String jsonEntity = StringUtils.EMPTY;
		jsonEntity = objMapper.writeValueAsString(new BtoBReqBase(req.getHeader(), req.getRequest()));
		
		return jsonEntity;
	}
	
	/**
	 * <pre>
	 * 호출 reqeust를 설정한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param req
	 * @return
	 * @throws Exception
	 */
	public StringEntity setEntity(BtoBReqEntity req, String jsonEntity) throws Exception {

		StringEntity strEntity = null;
		strEntity =  new StringEntity(jsonEntity, BtoBConstants.BTB_ENCODING_UTF_8);
		
		return strEntity;
	}
	
	/**
	 * <pre>
	 * 처리내용: response을 원하는 class로 변환 시 entityStr 생성
	 * </pre>
	 * @date 2023. 6. 19.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 6. 19.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param httpResponse
	 * @return
	 * @throws Exception
	 */
	public String entityStr(HttpResponse httpResponse) throws Exception {
		String entityStr = EntityUtils.toString(httpResponse.getEntity());
		
		return entityStr;
	}

	/**
	 * <pre>
	 * 응답 response을 원하는 class로 변환시킨다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param <T>
	 * @param httpResponse
	 * @param t
	 * @return
	 * @throws Exception
	 */
	public <T> T getEntityObj(HttpResponse httpResponse, Class<T> t, String entityStr) throws Exception {

		T entityObj =	null;

		entityObj = objMapper.readValue(entityStr, t);
		
		return entityObj;

	}

//	/**
//	 * <pre>
//	 * 응답 response을 json string 형식으로 변환한다. 사용처가 없음, 20230619 제거
//	 * </pre>
//	 * @date 2021. 6. 10.
//	 * @author srec0043
//	 * @history
//	 * ------------------------------------------------
//	 * 변경일					작성자				변경내용
//	 * ------------------------------------------------
//	 * 2021. 6. 10.			srec0043			최초작성
//	 * ------------------------------------------------
//	 * @param httpResponse
//	 * @return
//	 * @throws Exception
//	 */
//	public String getEntityStr(HttpResponse httpResponse) throws Exception{
//
//		String entityStr = StringUtils.EMPTY;
//		entityStr = EntityUtils.toString(httpResponse.getEntity());
//		/* 응답 전문 로그 */
//		this.btbLogVo.setIntrfcRspnsCn(entityStr);
//		return entityStr;
//	}

	/**
	 * <pre>
	 * B2BCNI로 호출 한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param httpPost
	 * @return
	 * @throws Exception
	 */
	public HttpResponse excute(HttpPost httpPost) throws Exception{
		
		HttpResponse response = httpClient.execute(httpPost);
		
		return response;
	}

	/**
	 * <pre>
	 * 호출 및 응답 전문을 IF_LOG 테이블에 INSERT한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param btbLogVo
	 */
	public void insertBtbLog(BtoBInrecfcLogVO btbLogVo){
		try {
			btoBApiService.insertBtbLog(btbLogVo);
		} catch (Exception e) {
			log.error("insertBtbLog error : " + e);
		}
	}

	/**
	 * <pre>
	 * 호출 및 응답 전문을 IF_LOG 테이블에 INSERT
	 * </pre>
	 * @date 2022. 7. 28.
	 * @author srec0051
	 * @param intrfcCode
	 * @param obj
	 * @return
	 */
	public BtoBInrecfcLogVO insertBtbLog(String intrfcCode, Object obj) {
		BtoBInrecfcLogVO btbLogVo = new BtoBInrecfcLogVO();
		btbLogVo.setIntrfcCode(intrfcCode);
		btbLogVo.setFrstRegisterId(intrfcCode);
		btbLogVo.setLastChangerId(intrfcCode);
		btbLogVo.setIntrfcExecutBgndehour(DateUtil.getNowDateTime());

		try {
			if (null != obj) {
				btbLogVo.setIntrfcTrnsmitSpclty(objMapper.writeValueAsString(obj));
			}
			btoBApiService.insertBtbLog(btbLogVo);

		} catch (Exception e) {
			log.error("insertBtbLog error : " + e);
		}

		return btbLogVo;
	}

	/**
	 * <pre>
	 * 호출 및 응답 전문을 IF_LOG 테이블에 Update한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param btbLogVo
	 */
	public void updateBtbLog(BtoBInrecfcLogVO btbLogVo) {
		try {
			btbLogVo.setIntrfcExecutEnddehour(DateUtil.getNowDateTime());
			btoBApiService.updateBtbLog(btbLogVo);

		} catch (Exception e) {
			log.error("insertBtbLog error : " + e);
		}
	}



	/**
	 * <pre>
	 * B2BCNI로 호출한다.
	 * BtoBReqEntity 객체의 interfaceId (인터페이스 ID)는 필수로 셋팅 되어야한다.
	 * B2BCNI로 호출 시 보낼 parameter 정보는 BtoBReqEntity 객체의 request에 셋팅 한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 10.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param req
	 * @return
	 */
	public BtoBResEntity callApi(BtoBReqEntity req) {

		BtoBResEntity resEntity = new BtoBResEntity();
		BtoBInrecfcLogVO btbLogVo = new BtoBInrecfcLogVO(); // 20230619 변경
		HttpPost httpPost = httpClientConfig.httpPost();
		try {
			setHeader(req);
			httpPost.setURI(setURI(req));
			
			String jsonEntity = this.setJsonEntity(req); // 20230619 추가
			
			httpPost.setEntity(this.setEntity(req, jsonEntity)); // 20230619 변경
			
			/* 송신 전문 로그 */
			btbLogVo.setIntrfcCode(req.getInterfaceId()); // 20230619 추가
			btbLogVo.setIntrfcTrnsmitSpclty(jsonEntity); // 20230619 추가
			
			/* 인터페이스 실행 시작일시 로그 */
			btbLogVo.setIntrfcExecutBgndehour(DateUtil.getNowDateTime()); // 20230619 추가
			HttpResponse httpResponse = excute(httpPost); // 20230619 추가
			/* 인터페이스 실행 종료일시 로그 */
			btbLogVo.setIntrfcExecutEnddehour(DateUtil.getNowDateTime()); // 20230619 추가
			
			String entityStr = this.entityStr(httpResponse); // 20230619 추가
			
			resEntity = getEntityObj(httpResponse, BtoBResEntity.class, entityStr); // 20230619 변경
			
			/* 응답 전문 로그 */
			btbLogVo.setIntrfcRspnsCn(entityStr);
		} catch (Exception e) {
			resEntity = new BtoBResEntity(BtoBConstants.BTOB_HELPER_ERROR_CODE, ExceptionUtils.getStackTrace(e), e);
			log.error("callApi error : " + e);
		} finally {
			if(!resEntity.getResultcode().isEmpty()) btbLogVo.setIntrfcRspnsCode(resEntity.getResultcode());
			/** 로그 테이블 Insert **/
			insertBtbLog(btbLogVo);
			resEntity.setIntrfcNo(btbLogVo.getIntrfcNo());
		}

		return resEntity;
	}

	/**
	 * <pre>
	 * BTB CNI에 응답 시 REQUEST 스펙체크를 한다.
	 * TRUE  : 인증 성공
	 * FALSE : 인증 실패
	 * </pre>
	 * @date 2021. 6. 22.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 22.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param request
	 * @return
	 */
	public Boolean specCheck(HttpServletRequest request) {

		Boolean specBool = false;
		String resApiKey = request.getHeader(BtoBConstants.BTB_RESPONSE_API_KEY);
		if(!StringUtils.isEmpty(resApiKey)) {
			try {
				byte[] decodeByte = Base64.getDecoder().decode(resApiKey.getBytes());
				if(StringUtils.equals(new String(decodeByte), btbResApiKey)) specBool = true;

			}catch(Exception e) {
				log.error(e.getMessage());
			}
		}

		return specBool;
	}

	/**
	 * <pre>
	 * 처리내용: Post 방식으로 외부 Url과 통신
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 20.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param url
	 * @param requestMap
	 * @return
	 */
	public Map<String, Object> postCallApi(String url, Object requestEntity) {

		Map<String, Object> responseMap = null;
		try {
			HttpPost httpPost = httpClientConfig.httpPost();
			httpPost.setURI(new URI(url));
			httpPost.setEntity(new StringEntity(objMapper.writeValueAsString(requestEntity), BtoBConstants.BTB_ENCODING_UTF_8));
			HttpResponse response = httpClient.execute(httpPost);
			log.debug("HttpResponse : " + response);
			responseMap = objMapper.readValue(EntityUtils.toString(response.getEntity()), new TypeReference<Map<String, Object>>(){});
		}catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		return responseMap;
	}

	/**
	 * <pre>
	 * 처리내용: Get 방식으로 외부 Url과 통신
	 * </pre>
	 * @date 2021. 7. 20.
	 * @author srec0043
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 20.			srec0043			최초작성
	 * ------------------------------------------------
	 * @param url
	 * @return
	 */
	public Map<String, Object> getCallApi(String url) {

		Map<String, Object> responseMap = null;
		try {
			HttpGet httpGet = httpClientConfig.httpGet();
			httpGet.setURI(new URI(url));
			HttpResponse response = httpClient.execute(httpGet);
			log.debug("HttpResponse : " + response);
			responseMap = objMapper.readValue(EntityUtils.toString(response.getEntity()), new TypeReference<Map<String, Object>>(){});
		}catch (Exception e) {
			log.error(e.getMessage());
		}

		return responseMap;
	}


}
