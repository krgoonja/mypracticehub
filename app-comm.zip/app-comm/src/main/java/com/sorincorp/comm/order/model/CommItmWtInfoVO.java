package com.sorincorp.comm.order.model;

import lombok.Data;

/**
 * CommItmWtInfoVO.java
 * 상품별 중량 정보 공통 VO 객체
 * 
 * @version
 * @since 2023. 5. 2.
 * @author srec0049
 */
@Data
public class CommItmWtInfoVO {
	
	/**
     * 판매 단위 중량
     */
    private java.math.BigDecimal sleUnitWt;
    
    /**
     * 1회 판매 가능 중량
     */
    private java.math.BigDecimal onceSlePossWt;
    
    /**
     * 최대 구매 가능 중량
     */
    private java.math.BigDecimal mxmmPurchsPossWt;
}
