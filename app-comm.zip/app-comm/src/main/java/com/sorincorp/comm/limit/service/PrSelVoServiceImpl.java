package com.sorincorp.comm.limit.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.sorincorp.comm.pcInfo.model.PrSelVO;

@Service
public class PrSelVoServiceImpl implements PrSelVoService {
	private Map<String, PrSelVO> prSelVo;
	
	public PrSelVoServiceImpl() {
		if(prSelVo == null) {
			this.prSelVo = new HashMap<String, PrSelVO>();
		}
	}
	
	@Override
	public Map<String, PrSelVO> getPrSelVo() {
		return prSelVo;
	}

	@Override
	public PrSelVO getPrSelVo(String metalCode) {
		if(!prSelVo.containsKey(metalCode)) {
			prSelVo.put(metalCode, new PrSelVO());
		} 
		
		return prSelVo.get(metalCode);
	}
}
 