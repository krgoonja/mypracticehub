package com.sorincorp.comm.itemprice.model;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ItemPriceMatchingSelectVO extends CommonVO {

	private static final long serialVersionUID = 6882956165304862133L;

	/** 판매 방식 코드 */
	private String sellMethodCode;
	
	/** 메탈 코드 */
	private String metalCode;
	
	/** 배송지 번호 */
	private String deliveryGroundNo;
	
	/** 회사 코드 */
	private String enterpriseNo;
	
	/** 배송구분 코드 */
	private String deliveryManageCode;
	
	/** 배송구분명 */
	private String deliveryManageNm;

	/** 출고권역 대분류 코드*/
	private String districtLargeCode;
	
	/** 출고권역 대분류 */
	private String districtLargeNm;
	
	/** 출고요청일 */
	private String releaseDate;

	/** 브랜드 그룹 코드*/
	private String brandGroupCode;

	/** 브랜드 그룹명*/
	private String brandGroupName;
	
	/** 브랜드 코드 */
	private String brandCode;
	
	/** 브랜드 코드 리스트*/
	private List<String> brandCodeList;
	
	/** 브랜드명 */
	private String brandName;

	/** 아이템 순서*/
	@NotNull
	private int itemSn;
	
	/** 아이템명*/
	private String itemNm;
	
	/** 상품명*/
	private String goodsNm;

	/** 주문 중량 */
	private BigDecimal orderWeight;

	/** 프라이싱 번호 */
	private String pricingNo;
	
	/** 장바구니 번호 */
	private String bsktNo;
	
    /** 최종 변경자 아이디 */      
	private String lastChangerId;
	
	/** 판매 단위 중량 **/
 	private int sleUnitWt;
  
 	/** 1회 판매 가능 중량 **/
 	private int onceSlePossWt;
 	
 	/** 최대 구매 가능 중량 **/
 	private int mxmmPurchsPossWt;
 
 	/** 지정 BL 명 */
 	private String blNo;
 	
 	/** 입고 구분 코드 */      
 	private String wrhousngSeCode;
 	
 	/** 재고없음처리 리턴여부 */      
 	private String leftOverWtRetrunBlEmptyYn;
 	
 	/** 상품검색페이지 검색조건 구분코드 - 브랜드 무관 시 RUSAL 제외**/
	private String clickbutton;

	/** 평균가 최적 B/L 탐색 로직 옵션, Y : "판매완료" 제외한 전체 재고 검색 **/
	private String avrgPcSearchCnd;
	
	/** 소량 구매 여부 - Y일 경우, 소량 판매 재고 미판매 번들 검색 */
	private String smlqyPurchsAt;
}