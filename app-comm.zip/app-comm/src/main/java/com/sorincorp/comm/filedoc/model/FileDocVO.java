package com.sorincorp.comm.filedoc.model;

import lombok.Data;

@Data
public class FileDocVO {
    /**
     * 문서 번호
    */
    private int docNo;
    /**
     * 업무 구분 코드
    */
    private String jobSeCode;
    /**
     * 문서 파일 명
    */
    private String docFileNm;
    /**
     * 문서 파일 경로
    */
    private String docFileCours;
    /**
     * 문서 파일 실제 경로
    */
    private String docFileRealCours;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
    /**
     * 문서 파일 크기
    */
    private long docFileMg;
    /**
     * 다운로드 파일 명
    */
    private String downFileNm;
}
