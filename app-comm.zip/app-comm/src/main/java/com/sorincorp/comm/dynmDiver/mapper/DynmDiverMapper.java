package com.sorincorp.comm.dynmDiver.mapper;

import java.math.BigDecimal;
import java.util.List;

import com.sorincorp.comm.dynmDiver.model.DynmDiverCommVO;
import com.sorincorp.comm.dynmDiver.model.DynmDiverPremiumBrandVO;
import com.sorincorp.comm.dynmDiver.model.DynmDiverPremiumStdrVO;

public interface DynmDiverMapper {

	DynmDiverCommVO selectPremiumDiverInfo() throws Exception;

	DynmDiverCommVO selectDiverLimitOrderList(DynmDiverCommVO dynmDiverCommVO) throws Exception;

	Long selectNowPc() throws Exception;

	DynmDiverPremiumStdrVO getSelectedPremium() throws Exception;

	BigDecimal selectSpex() throws Exception;

	void insertSelectDiverPremiumStrd(DynmDiverPremiumStdrVO newPremiumVo) throws Exception;

	void insertSelectDiverPremiumDstrct(DynmDiverPremiumStdrVO newPremiumVo) throws Exception;

	void insertSelectDiverPremiumBrandGroup(DynmDiverPremiumStdrVO newPremiumVo) throws Exception;

	List<DynmDiverPremiumBrandVO> getSelectedDiverPremiumBrand(DynmDiverPremiumStdrVO newPremiumVo) throws Exception;

	void insertSelectDiverPremiumBrand(DynmDiverPremiumStdrVO newPremiumVo) throws Exception;

	void updateEndDtDiverPremiumStrd(DynmDiverPremiumStdrVO newPremiumVo) throws Exception;
}

