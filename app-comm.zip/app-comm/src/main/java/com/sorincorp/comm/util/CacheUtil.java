//package com.sorincorp.comm.util;
//
//import javax.annotation.PostConstruct;
//import javax.annotation.Resource;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cache.ehcache.EhCacheCacheManager;
//import org.springframework.stereotype.Component;
//
//import com.sorincorp.comm.constants.ExceptionConstants;
//
//import lombok.extern.slf4j.Slf4j;
//import net.sf.ehcache.CacheManager;
//import net.sf.ehcache.Ehcache;
//import net.sf.ehcache.Element;
//
//@Slf4j
//@Component
//public class CacheUtil {
//	
//	@Autowired
//	private CacheManager cacheManager;
//	
//	@Resource(name = "ehCacheManagerFactoryBean")
//	private EhCacheCacheManager ehCacheManager;
//	
//	@PostConstruct
//	public void init() {
//		this.cacheManager = ehCacheManager.getCacheManager();
//	}
//
//	private Ehcache cache;
//	
//	/**
//	 * <pre>
//	 * 입력한 이름에 해당하는 Ehcache를 가져온다.
//	 * </pre>
//	 * @date 2021. 6. 8.
//	 * @author srec0012
//	 * @history 
//	 * ------------------------------------------------
//	 * 변경일					작성자				변경내용
//	 * ------------------------------------------------
//	 * 2021. 6. 8.			srec0012			최초작성
//	 * ------------------------------------------------
//	 * @param cacheName
//	 */
//	public void getCache(String cacheName) {
//		try {
//			cache = cacheManager.getCache(cacheName);
//		} catch (Exception e) {
//			log.error(ExceptionConstants.ERROR_CACHE);
//		}
//	}
//	
//	/**
//	 * <pre>
//	 * 공통 Ehcache(CommonCache)를 가져온다.
//	 * </pre>
//	 * @date 2021. 6. 8.
//	 * @author srec0012
//	 * @history 
//	 * ------------------------------------------------
//	 * 변경일					작성자				변경내용
//	 * ------------------------------------------------
//	 * 2021. 6. 8.			srec0012			최초작성
//	 * ------------------------------------------------
//	 */
//	public void getCommonCache() {
//		getCache("commonCache");
//	}
//	
//	/**
//	 * <pre>
//	 * 공통 코드 Ehcache(codeCache)를 가져온다.
//	 * </pre>
//	 * @date 2021. 6. 15.
//	 * @author srec0012
//	 * @history 
//	 * ------------------------------------------------
//	 * 변경일					작성자				변경내용
//	 * ------------------------------------------------
//	 * 2021. 6. 15.			srec0012			최초작성
//	 * ------------------------------------------------
//	 */
//	public void getCodeCache() {
//		getCache("codeCache");
//	}
//	
//	/**
//	 * <pre>
//	 * 지정한 Ehcache에 지정한 값으로 Element를 생성한다.
//	 * </pre>
//	 * @date 2021. 6. 8.
//	 * @author srec0012
//	 * @history 
//	 * ------------------------------------------------
//	 * 변경일					작성자				변경내용
//	 * ------------------------------------------------
//	 * 2021. 6. 8.			srec0012			최초작성
//	 * ------------------------------------------------
//	 * @param cache
//	 * @param key
//	 * @param value
//	 * @return
//	 */
//	public boolean put(String key, Object value) {
//		Element element = new Element(key, value);
//		
//		try {
//			cache.put(element);
//		} catch (Exception e) {
//			log.error(ExceptionConstants.ERROR_CACHE);
//			log.error(e.toString());
//			return false;
//		}
//		
//		return true;
//	}
//	
//	/**
//	 * <pre>
//	 * 지정한 Ehcache에서 지정한 key의 Element를 가져온다.
//	 * </pre>
//	 * @date 2021. 6. 8.
//	 * @author srec0012
//	 * @history 
//	 * ------------------------------------------------
//	 * 변경일					작성자				변경내용
//	 * ------------------------------------------------
//	 * 2021. 6. 8.			srec0012			최초작성
//	 * ------------------------------------------------
//	 * @param cache
//	 * @param key
//	 * @return
//	 */
//	public Element getElement(String key) {
//		return cache.get(key);
//	}
//	
//	/**
//	 * <pre>
//	 * 지정한 Ehcache에서 지정한 key의 Element의 Value를 가져온다.
//	 * </pre>
//	 * @date 2021. 6. 8.
//	 * @author srec0012
//	 * @history 
//	 * ------------------------------------------------
//	 * 변경일					작성자				변경내용
//	 * ------------------------------------------------
//	 * 2021. 6. 8.			srec0012			최초작성
//	 * ------------------------------------------------
//	 * @param cache
//	 * @param key
//	 * @return
//	 */
//	public Object getValue(String key) {
//		Element element = cache.get(key);
//		
//		if ( element == null ) return null;
//		
//		return element.getObjectValue();
//	}
//	
//	/**
//	 * <pre>
//	 * 지정한 Ehcache에서 지정한 key의 Element를 교체한다.
//	 * </pre>
//	 * @date 2021. 6. 8.
//	 * @author srec0012
//	 * @history 
//	 * ------------------------------------------------
//	 * 변경일					작성자				변경내용
//	 * ------------------------------------------------
//	 * 2021. 6. 8.			srec0012			최초작성
//	 * ------------------------------------------------
//	 * @param cache
//	 * @param key
//	 * @param value
//	 * @return
//	 */
//	public boolean replace(String key, Object value) {
//		Element element = new Element(key, value);
//		
//		try {
//			cache.replace(element);
//		} catch (Exception e) {
//			log.error(ExceptionConstants.ERROR_CACHE);
//			return false;
//		}
//		
//		return true;
//	}
//	
//	/**
//	 * <pre>
//	 * 지정한 Ehcache에서 지정한 key의 Element를 제거한다.
//	 * </pre>
//	 * @date 2021. 6. 8.
//	 * @author srec0012
//	 * @history 
//	 * ------------------------------------------------
//	 * 변경일					작성자				변경내용
//	 * ------------------------------------------------
//	 * 2021. 6. 8.			srec0012			최초작성
//	 * ------------------------------------------------
//	 * @param cache
//	 * @param key
//	 * @return
//	 */
//	public boolean remove(String key) {
//		try {
//			cache.remove(key);
//		} catch (Exception e) {
//			log.error(ExceptionConstants.ERROR_CACHE);
//			return false;
//		}
//		
//		return true;
//	}
//}

package com.sorincorp.comm.util;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;

import org.springframework.cache.Cache;
import com.sorincorp.comm.constants.ExceptionConstants;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Component
public class CacheUtil {
	
	@Autowired
	private CacheManager cacheManager;

	@Autowired
	private	RedisUtil redisUtil;
	
//	@PostConstruct
//	public void init() {
//
//	}

	private Cache cache;
	
	/**
	 * <pre>
	 * 입력한 이름에 해당하는 Ehcache를 가져온다.
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param cacheName
	 */
	public void getCache(String cacheName) {
		try {
			cache = cacheManager.getCache(cacheName);
		} catch (Exception e) {
			log.error(ExceptionConstants.ERROR_CACHE);
		}
	}
	
	/**
	 * <pre>
	 * 공통 Ehcache(CommonCache)를 가져온다.
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			srec0012			최초작성
	 * ------------------------------------------------
	 */
	public void getCommonCache() {
		getCache("commonCache");
	}
	
	/**
	 * <pre>
	 * 공통 코드 Ehcache(codeCache)를 가져온다.
	 * </pre>
	 * @date 2021. 6. 15.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 15.			srec0012			최초작성
	 * ------------------------------------------------
	 */
	public void getCodeCache() {
		getCache("codeCache");
	}
	
	/**
	 * <pre>
	 * 지정한 Ehcache에 지정한 값으로 Element를 생성한다.
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param cache
	 * @param key
	 * @param value
	 * @return
	 */
	public boolean put(String key, Object value) {
		try {
//			cache.put(key,value);
			redisUtil.setData(key, value);
		} catch (Exception e) {
			log.error(ExceptionConstants.ERROR_CACHE);
			log.error(e.toString());
			return false;
		}
		
		return true;
	}
	
	/**
	 * <pre>
	 * 지정한 Ehcache에서 지정한 key의 Element를 가져온다.
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param cache
	 * @param key
	 * @return
	 */
//	public Element getElement(String key) {
//		return cache.get(key);
//	}
	
	/**
	 * <pre>
	 * 지정한 Ehcache에서 지정한 key의 Element의 Value를 가져온다.
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param cache
	 * @param key
	 * @return
	 */
	public Object getValue(String key) {
//		Element element = cache.get(key);
//		
//		if ( element == null ) return null;
//		
//		return element.getObjectValue();
//		return cache.get(key).get();
		return redisUtil.getData(key);
	}
	
	/**
	 * <pre>
	 * 지정한 Ehcache에서 지정한 key의 Element를 교체한다.
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param cache
	 * @param key
	 * @param value
	 * @return
	 */
//	public boolean replace(String key, Object value) {
//		Element element = new Element(key, value);
//		
//		try {
//			cache.replace(element);
//		} catch (Exception e) {
//			log.error(ExceptionConstants.ERROR_CACHE);
//			return false;
//		}
//		
//		return true;
//	}
	
	/**
	 * <pre>
	 * 지정한 Ehcache에서 지정한 key의 Element를 제거한다.
	 * </pre>
	 * @date 2021. 6. 8.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 8.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param cache
	 * @param key
	 * @return
	 */
//	public boolean remove(String key) {
//		try {
//			cache.evict(key);
//		} catch (Exception e) {
//			log.error(ExceptionConstants.ERROR_CACHE);
//			return false;
//		}
//		
//		return true;
//	}
}
