package com.sorincorp.comm.config;

import javax.servlet.Filter;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.navercorp.lucy.security.xss.servletfilter.XssEscapeServletFilter;

@Configuration
public class LucyFilterConfig {
	/** Lucy Filter에서 사숑할 Bean **/
    @SuppressWarnings({ "rawtypes", "unchecked" })
	@Bean
    public FilterRegistrationBean xssEscapeServletFilterRegistration() {
    	FilterRegistrationBean registration = new FilterRegistrationBean();
    	registration.setFilter(xssEscapeServletFilter());
    	registration.addUrlPatterns("/*");
    	registration.setName("xssEscapeServletFilter");
    	
    	return registration;
    }
    
    public Filter xssEscapeServletFilter() {
    	return new XssEscapeServletFilter();
    }
}
