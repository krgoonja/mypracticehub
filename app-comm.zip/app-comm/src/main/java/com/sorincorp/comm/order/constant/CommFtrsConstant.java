package com.sorincorp.comm.order.constant;

/**
 * CommFtrsConstant.java
 *
 *
 * @version
 * @since 2023. 10. 03.
 * @author srec0070
 */
public class CommFtrsConstant {
	/*
	 * 선물사 코드
	 */
	public static final  String FTRS_SAMSUNG_CMPNY_CODE = "SSF";
	public static final  String FTRS_EBEST_CMPNY_CODE = "EBEST";
}
