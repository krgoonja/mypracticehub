package com.sorincorp.comm.assign.mapper;

import com.sorincorp.comm.assign.model.AssignVO;

public interface AssignMapper {
	/**
	 * <pre>
	 * 채번한 일련번호를 리턴한다.
	 * </pre>
	 * @date 2021. 6. 14.
	 * @author srec0012
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 14.			srec0012			최초작성
	 * ------------------------------------------------
	 * @param vo - 채번할 조건이 정보가 담긴 AssignVO
	 * @return 채번한 일련번호
	 * @throws Exception
	 */
	long selectAssignNo(AssignVO vo) throws Exception;
}
