package com.sorincorp.comm.entrpsgrade.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.entrpsgrade.mapper.EntrpsGradeMapper;
import com.sorincorp.comm.entrpsgrade.model.EntrpsGradeVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EntrpsGradeServiceImpl implements EntrpsGradeService {

	@Autowired
	private EntrpsGradeMapper entrpsGradeMapper;

	/**
	 * <pre>
	 * 업체 등급 별 혜택을 리스트로 조회하여 반환한다
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<EntrpsGradeVO> getEntrpsGradeBnefInfoList(String entrpsNo) throws Exception {
		// TODO Auto-generated method stub
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("entrpsNo", entrpsNo);
//		params.put("metalCode", metalCode);

		return entrpsGradeMapper.getEntrpsGradeBnefInfoList(params);
	}

	/**
	 * <pre>
	 * 업체 별 평가 등급 정보를 VO로 조회하여 반환한다.
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	@Override
	public EntrpsGradeVO getEntrpsEvlGradeInfo(String entrpsNo) throws Exception {
		// TODO Auto-generated method stub
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("entrpsNo", entrpsNo);
		return entrpsGradeMapper.getEntrpsEvlGradeInfo(params);
	}

	/**
	 * <pre>
	 * 구매성향등급 전체 정보를 조회하여 리스트로 반환한다.
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0030			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<EntrpsGradeVO> getEntrpsPurchsInclnGradeInfoAllList() throws Exception {
		// TODO Auto-generated method stub
		return entrpsGradeMapper.getEntrpsPurchsInclnGradeInfoAllList();
	}

	/**
	 * <pre>
	 * 업체 별 구매성향 등급정보를 조회하여 VO로 반환한다.
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0030
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0030			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @return
	 * @throws Exception
	 */
	@Override
	public EntrpsGradeVO getEntrpsPurchsInclnGradeInfo(String entrpsNo) throws Exception {
		// TODO Auto-generated method stub
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("entrpsNo", entrpsNo);
		return entrpsGradeMapper.getEntrpsPurchsInclnGradeInfo(params);
	}


}
