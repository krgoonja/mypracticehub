package com.sorincorp.comm.order.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

/**
 * CommLimitGroupModel.java
 * 지정가 그룹 공통 VO 객체
 * 
 * @version
 * @since 2023. 5. 3.
 * @author srec0049
 */
@Data
public class CommLimitGroupModel {
	
	/**
	 * 시스템 아이디
	 */
	private String systemId;
	
	/**
	 * 지정가 주문 로그 순번
	 */
	private long limitOrderLogSn;
	
	/**
	 * 지정가 주문 큐 메시지 공통 VO 객체
	 */
	private CommLimitOrderQueueMsgVO commLimitOrderQueueMsgVO;
	
	/**
	 * 타겟 지정가 주문 번호 리스트
	 */
	private List<String> targetLimitOrderNoList = new ArrayList<String>();
	
	/**
	 * 각 지정가 주문에 대한 정보 맵
	 * key : 지정가 주문 번호
	 */
	private Map<String, CommLimitOrderModel> limitOrderModelMap = new HashMap<String, CommLimitOrderModel>();
	
	/**
	 * 지정가 주문 상태 코드
	 */
	private String limitOrderSttusCode;
	
	/**
	 * 주문 실패 사유
	 */
	private String limitOrderFailrResn;
	
	/**
	 * 임시 지정가 주문 번호 (각 지정가 주문 업데이트 용도)
	 */
	private String tempTargetLimitOrderNo;
	
	/**
	 * 임시 재고 체크 중량 (각 지정가 주문 업데이트 용도)
	 */
	private int tempInvntryCeckWt;

	/* 다음은 가단가 구매 관련 항목들  */
	/**
	 * 타겟 주문 번호 리스트
	 */
	private List<String> targetOrderNoList = new ArrayList<String>();

	/**
	 * 가단가 지정가 주문 큐 메시지 공통 VO 객체
	 */
	private CommPrvsnlLimitOrderQueueMsgVO commPrvsnlLimitOrderQueueMsgVO;
}
