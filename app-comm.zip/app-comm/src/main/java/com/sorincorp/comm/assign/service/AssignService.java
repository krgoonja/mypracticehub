package com.sorincorp.comm.assign.service;

public interface AssignService {
	/**
	 * <pre>
	 * 채번한 일련번호를 리턴한다.
	 * </pre>
	 * @date 2021. 6. 10.
	 * @author srec0012
	 * @history 
	 * <pre>
	 * ------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * ------------------------------------------------------
	 * 2021. 6. 10.		srec0012		최초작성
	 * 2021. 6. 14.		Kwon sun hyung		pakage refactory
	 * ------------------------------------------------------
	 * </pre>
	 * @param jobSe - 작업구분
	 * @param assgnNm - 채번 이름
	 * @param assgnSe - 채번 구분
	 * @param userId - 등록자/변경자 ID
	 * @param length - 채번값 전체 길이
	 * @return 채번한 일련번호
	 * @throws Exception
	 */
	public String selectAssignValue(String jobSe, String assgnNm, String assgnSe, String userId, int length) throws Exception;
}
