package com.sorincorp.comm.entrpsgrade.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.comm.entrpsgrade.model.EntrpsGradeVO;

public interface EntrpsGradeMapper {

	List<EntrpsGradeVO> getEntrpsGradeBnefInfoList(Map<String, Object> params) throws Exception;

	EntrpsGradeVO getEntrpsEvlGradeInfo(Map<String, Object> params) throws Exception;

	EntrpsGradeVO getEntrpsPurchsInclnGradeInfo(Map<String, Object> params) throws Exception;

	List<EntrpsGradeVO> getEntrpsPurchsInclnGradeInfoAllList() throws Exception;


}
