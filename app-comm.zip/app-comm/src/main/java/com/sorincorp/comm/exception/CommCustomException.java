package com.sorincorp.comm.exception;

/**
 * CommCustomException.java
 * 공통 사용자 정의 Exception
 * 
 * @version
 * @since 2023. 4. 26.
 * @author srec0049
 */
@SuppressWarnings("serial")
public class CommCustomException extends Exception {
	
	public CommCustomException() {}
	
	/**
	 * 사용자 정의된 오류 메시지 Exception
	 * @param message
	 */
	public CommCustomException(String message) {
		super(message);
	}
	
	/**
	 * 사용자 정의된 오류 Exception
	 * @param e
	 */
	public CommCustomException(Exception e) {
		super(e);
	}

}
