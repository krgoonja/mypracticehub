package com.sorincorp.comm.limit.service;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.limit.mapper.LimitMapper;
import com.sorincorp.comm.order.constant.CommLimitOrderConstant;
import com.sorincorp.comm.order.model.CommLimitOrderQueueMsgVO;
import com.sorincorp.comm.order.model.CommLimitOrderRedisMsgVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderQueueMsgVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderRedisMsgVO;
import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;
import com.sorincorp.comm.premium.service.ItPremiumStdrBasVoService;
import com.sorincorp.comm.queue.azure.servicebus.sender.AzureServiceBusQueueSender;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.LimitDataUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class LimitServiceImpl implements LimitService {
	
	@Autowired
	private PrSelVoService prSelVoService;
	
	private final OrLimitOrderBasVoMapService orLimitOrderBasVoMapService;
	
	@Autowired
	private ItPremiumStdrBasVoService itPremiumStdrBasVoService;
	
	@Autowired
	private LimitMapper limitMapper;
	
	@Autowired
	AzureServiceBusQueueSender azureServiceBusQueueSender;
	
	@Autowired
	private RedisPubSubService redisPubSubService;
	
	@Autowired
	public LimitServiceImpl(OrLimitOrderBasVoMapService orLimitOrderBasVoMapService) {
		this.orLimitOrderBasVoMapService = orLimitOrderBasVoMapService;
	}
	
	private static final Comparator<String> COMM_LIMIT_ORDER_COMPARATOR = (key1, key2) -> {
		if (key1.endsWith(com.sorincorp.comm.util.LimitDataUtil.BRAND_UNRELATED) && !key2.endsWith(com.sorincorp.comm.util.LimitDataUtil.BRAND_UNRELATED)) {
			return -1;
		} else if (!key1.endsWith(com.sorincorp.comm.util.LimitDataUtil.BRAND_UNRELATED) && key2.endsWith(com.sorincorp.comm.util.LimitDataUtil.BRAND_UNRELATED)) {
			return 1;
		} else {
			return key1.compareTo(key2);
		}
	};
	
	/*@PostConstruct
	public void init() throws Exception {
		// 프리미엄 가격 초기값 세팅 
		Map<String, TreeSet<LivePremiumVO>> originalMap = pcInfoService.getPremiumInfoMap();
		itPremiumStdrBasVoService.setItPremiumStdrBasVo(originalMap);
		
		log.debug("0) init premiumMap Setting");
	}*/

	/*
	 * 지정가 일괄처리 부하테스트
	 * 
	 * 1. List<CommLimitOrderRedisMsgVO>로 받은 데이터 TreeSet<CommLimitOrderRedisMsgVO>으로 정렬
	 * 2. 수신 받은 판매 가격 정보의 key(metalCode) 기준으로 for문을 돌면서, queue에 넘겨줄 데이터 저장
	 */
	@Override
	public void loadTest(List<CommLimitOrderRedisMsgVO> commLimitOrderRedisMsgVOList) throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();	// TODO [pje] 테스트용 - 삭제예정
		// 1. List<CommLimitOrderRedisMsgVO>로 받은 데이터 TreeSet<CommLimitOrderRedisMsgVO>으로 정렬
		orderLimitOrderRedisDataList(commLimitOrderRedisMsgVOList);
		
		// 수신받은 판매가격 정보
		Map<String, PrSelVO> prSelVoMap = prSelVoService.getPrSelVo();
		
		String result = objectMapper.writeValueAsString(prSelVoMap);
		log.debug("1-3) prSelVoMap: " + result);		// TODO [pje] 테스트용 - 삭제예정
		
		// 2. 수신 받은 판매 가격 정보의 key(metalCode) 기준으로 for문을 돌면서, queue에 넘겨줄 데이터 저장
		log.debug("2-1) prSelVoMap.keySet: " + prSelVoMap.keySet());	
		
		for (String key : prSelVoMap.keySet()) {
			PrSelVO prSelVo = prSelVoMap.get(key);
			
			String result3 = objectMapper.writeValueAsString(prSelVo);	// TODO [pje] 테스트용 - 삭제예정
			log.debug("2-2) prSelVo: " + result3);
			queueVoSave(prSelVo, commLimitOrderRedisMsgVOList);
		}
	}

	/**
	 * <pre>
	 * 처리내용: CommLimitOrderRedisMsgVO 리스트를 정렬하여 저장한다
	 * </pre>
	 * @date 2023. 4. 25.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 25.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param commLimitOrderRedisMsgVOList
	 * @throws JsonProcessingException 
	 */
	private void orderLimitOrderRedisDataList(List<CommLimitOrderRedisMsgVO> commLimitOrderRedisMsgVOList) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();	// TODO [pje] 테스트용 - 삭제예정
		String result2 = objectMapper.writeValueAsString(commLimitOrderRedisMsgVOList);	// TODO [pje] 테스트용 - 삭제예정
		log.info("1-0) orderLimitOrderRedisDataList: " + result2);
		TreeSet<CommLimitOrderRedisMsgVO> orderLimitList = new TreeSet<>();
		Map<String, TreeSet<CommLimitOrderRedisMsgVO>> orderCommLimitOrderRedisMsgVoMap = new HashMap<String, TreeSet<CommLimitOrderRedisMsgVO>>();
		
		// map clear 후 사용
		orLimitOrderBasVoMapService.clearOrderCommLimitOrderRedisMsgVoMap();
		
		log.debug("1-1) clear map: " + orLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());
		
		// 정렬
		for(CommLimitOrderRedisMsgVO redisVo : commLimitOrderRedisMsgVOList) {
			String groupKey = generateKey(redisVo);
					
			log.debug("1-1-1) groupKey: " + groupKey);
			
			orderLimitList = orLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(groupKey);
			
			log.debug("1-1-2) orderLimitList: " + orderLimitList);
			log.debug("1-2-3) redisVo: " + redisVo);

			orderLimitList.add(redisVo);
			
			orderCommLimitOrderRedisMsgVoMap.put(groupKey, orderLimitList);
		}
		
		orLimitOrderBasVoMapService.setOrderCommLimitOrderRedisMsgVoMap(orderCommLimitOrderRedisMsgVoMap);

		/*Map<String, TreeSet<CommLimitOrderRedisMsgVO>> orderCommLimitOrderRedisMsgVoMapCopy = new TreeMap<>(COMM_LIMIT_ORDER_COMPARATOR);
		orderCommLimitOrderRedisMsgVoMapCopy.putAll(orLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());
		*/
		try {
			String result = objectMapper.writeValueAsString(orLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());	// TODO [pje] 테스트용 - 삭제예정
			log.info("1-2) " + result);
		} catch(Exception e) {
			log.error("[orderLimitOrderRedisDataList Error] {}", ExceptionUtils.getStackTrace(e));
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: queue에 넘겨줄 데이터를 저장한다
	 * </pre>
	 * @date 2023. 4. 25.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 25.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param newPriceMap
	 * @param prSelVo
	 * @throws Exception 
	 */
	private void queueVoSave(PrSelVO prSelVo, List<CommLimitOrderRedisMsgVO> commLimitOrderRedisMsgVOList) throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();	// TODO [pje] 테스트용 - 삭제예정
		log.debug("3-1) queueVoSave");
		
		CommLimitOrderQueueMsgVO queueVo = new CommLimitOrderQueueMsgVO();
		queueVo.setLimitOrderRequestDt("" + prSelVo.getOccrrncDe() + prSelVo.getOccrrncTime());	// 지정가 주문 요청 일시
		queueVo.setSlePcRltmSn(prSelVo.getSlePcRltmSn());										// 판매 가격 실시간 순번
		queueVo.setLmePcRltmSn(prSelVo.getLmePcRltmSn());										// LME 가격 실시간 순번
		queueVo.setLme3m(prSelVo.getThreemonthLmePc());											// LME 3M
		queueVo.setLmeCash(prSelVo.getLmePc());													// LME 현금
		queueVo.setLmeMdatCffcnt(prSelVo.getLmeMdatCffcnt());									// LME 조정계수
		queueVo.setEhgtPcRltmSn(prSelVo.getEhgtPcRltmSn());										// 환율 가격 실시간 순번
		queueVo.setSpex(prSelVo.getEhgtPc());													// 환율 가격
		queueVo.setSpexMdatCffcnt(prSelVo.getFxMdatCffcnt());									// 환율 조정계수
		
		if(orLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap().isEmpty())
			return;
		
		String result = objectMapper.writeValueAsString(orLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap());	// TODO [pje] 테스트용 - 삭제예정
		log.debug("3-1-1) " + result);
		
		// 종목별로 loop를 돌며 queue 값 세팅
		for (String key : orLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap().keySet()) {
			log.debug("containsKey(" + key + "): " + itPremiumStdrBasVoService.getItPremiumStdrBasVo().containsKey(key));
			
			if (itPremiumStdrBasVoService.getItPremiumStdrBasVo().containsKey(key)) {
				TreeSet<LivePremiumVO> value = itPremiumStdrBasVoService.getItPremiumStdrBasVo().get(key);

				Optional<LivePremiumVO> optionalLivePremiumVO = value.stream()
						.filter(vo -> {
							return prSelVo != null && vo.getValidBeginDt().compareTo(prSelVo.getOccrrncDe() + prSelVo.getOccrrncTime()) <= 0
									&& vo.getValidEndDt().compareTo(prSelVo.getOccrrncDe() + prSelVo.getOccrrncTime()) >= 0
									&& vo.getMetalCode().equals(prSelVo.getMetalCode());
						})
						.findFirst();

				log.debug("3-2) optionalLivePremiumVO.isPresent(): " + optionalLivePremiumVO.isPresent());
				
				if (optionalLivePremiumVO.isPresent()) {
					
					log.debug("3-3) key: " + key);
					
					TreeSet<CommLimitOrderRedisMsgVO> originalSet = orLimitOrderBasVoMapService.getOrderCommLimitOrderRedisMsgVoMap(key);
					TreeSet<CommLimitOrderRedisMsgVO> commLimitOrderRedisMsgVOTreeSet = new TreeSet<>(originalSet);
					
					queueVo.setLimitOrderStdrSlePc(prSelVo.getEndPc());
					
					String result2 = objectMapper.writeValueAsString(queueVo);	// TODO [pje] 테스트용 - 삭제예정
					log.debug("3-4) queueVo: " + result2);
					
					settingLimitQueueData(commLimitOrderRedisMsgVOTreeSet, queueVo);
					
					for (CommLimitOrderRedisMsgVO vo : commLimitOrderRedisMsgVOList) {
						vo.setIntrfcSttusCode(LimitDataUtil.LimitOrderSttusCode.DELETE.value);
					}
					
					for (CommLimitOrderRedisMsgVO vo : commLimitOrderRedisMsgVOList) {
						redisPubSubService.publishMessage(CommLimitOrderConstant.REDISPUPSUB_URL_LIMITORDER, CommLimitOrderConstant.REDISPUPSUB_URL_LIMITORDER, vo);
					}
				}
			}
			
		}
		
	}
	
	/**
	 * <pre>
	 * 처리내용: 종목별로 큐에 넘겨줄 최종 데이터를 저장한다
	 * </pre>
	 * @date 2023. 4. 25.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 25.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param commLimitOrderRedisMsgTreeSet, commLimitOrderRedisMsgTreeSet
	 */
	@Override
	public synchronized void settingLimitQueueData(TreeSet<CommLimitOrderRedisMsgVO> commLimitOrderRedisMsgTreeSet, CommLimitOrderQueueMsgVO queueVo) {
		CommLimitOrderQueueMsgVO returnVo = new CommLimitOrderQueueMsgVO();
		
		try {
			returnVo.setLimitOrderRequestDt(queueVo.getLimitOrderRequestDt());																// 지정가 주문 일시
			returnVo.setLimitOrderRequestCo(commLimitOrderRedisMsgTreeSet.size());															// 지정가 주문 요청 건수
			returnVo.setLimitOrderStdrSlePc(queueVo.getLimitOrderStdrSlePc());																// 지정가 주문 기준 판매 가격
			returnVo.setLimitOrderTotWt(commLimitOrderRedisMsgTreeSet.stream().mapToInt(CommLimitOrderRedisMsgVO::getCstmrOrderWt).sum());	// 지정가 주문 요청 총 중량
			returnVo.setMetalCode(commLimitOrderRedisMsgTreeSet.first().getMetalCode());													// 금속 코드
			returnVo.setItmSn(commLimitOrderRedisMsgTreeSet.first().getItmSn());															// 아이템 순번
			returnVo.setDstrctLclsfCode(commLimitOrderRedisMsgTreeSet.first().getDstrctLclsfCode());										// 권역 대분류 코드
			returnVo.setBrandGroupCode(commLimitOrderRedisMsgTreeSet.first().getBrandGroupCode());											// 브랜드 그룹 코드
			returnVo.setBrandCode(LimitDataUtil.BRAND_UNRELATED);																			// 브랜드 코드
			returnVo.setSlePcRltmSn(queueVo.getSlePcRltmSn());																				// 판매 가격 실시간 순번
			returnVo.setLmePcRltmSn(queueVo.getLmePcRltmSn());																				// LME 가격 실시간 순번
			returnVo.setLme3m(queueVo.getLme3m());																							// LME 3M
			returnVo.setLmeCash(queueVo.getLmeCash());																						// LME 현금
			returnVo.setLmeMdatCffcnt(queueVo.getLmeMdatCffcnt());																			// LME 조정계수
			returnVo.setEhgtPcRltmSn(queueVo.getEhgtPcRltmSn());																			// 환율 가격 실시간 순번
			returnVo.setSpex(queueVo.getSpex());																							// 환율 가격
			returnVo.setSpexMdatCffcnt(queueVo.getSpexMdatCffcnt());																		// 환율 조정계수
			returnVo.setLimitOrderNoList(commLimitOrderRedisMsgTreeSet.stream()
					.map(CommLimitOrderRedisMsgVO::getLimitOrderNo)
					.collect(Collectors.toList()));																							// 지정가 주문번호 LIST TODO [pje] TreeSet에서 설정한 순서가 유지되는지 확인
			
			ObjectMapper objectMapper = new ObjectMapper();	// TODO [pje] 테스트용 - 삭제예정
			String result = objectMapper.writeValueAsString(returnVo);	// TODO [pje] 테스트용 - 삭제예정
			log.info("4-1) Setting Limit Queue Data: " + result);
			
			sendLimitQueueData(returnVo);
		} catch(Exception e) {
			log.error("[settingLimitQueueData Error] {}", ExceptionUtils.getStackTrace(e));
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 큐에 데이터 전송
	 * </pre>
	 * @date 2023. 4. 25.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 25.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param commLimitOrderQueueMsgVO
	 */
	@Override
	public void sendLimitQueueData(CommLimitOrderQueueMsgVO commLimitOrderQueueMsgVO) throws Exception {
		log.info("5-1) sendLimitQueueData");
		azureServiceBusQueueSender.send(commLimitOrderQueueMsgVO);
	}

	@Override
	public Map<String, TreeSet<CommLimitOrderRedisMsgVO>> loadInitialLimitData() throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();	// TODO [pje] 테스트용 - 삭제예정
		List<CommLimitOrderRedisMsgVO> initLimitDataList = limitMapper.loadInitialLimitData();
		
		String result = objectMapper.writeValueAsString(initLimitDataList);	// TODO [pje] 테스트용 - 삭제예정
		log.debug("initLimitDataList: " + result);
		
		return initLimitDataList.stream()
				.collect(Collectors.groupingBy(this::generateKey, Collectors.toCollection(TreeSet::new)));
	}
	
	// key 값을 생성하는 메소드
	@Override
	public String generateKey(CommLimitOrderRedisMsgVO redisVo) {
		return String.join("_", redisVo.getMetalCode(), Integer.toString(redisVo.getItmSn()),
				redisVo.getDstrctLclsfCode(), redisVo.getBrandGroupCode(), LimitDataUtil.BRAND_UNRELATED);
	}
	
	/**
	 * <pre>
	 * 처리내용: 현재 endPc와 프리미엄 가격을 더하여 저장한다
	 * </pre>
	 * @date 2023. 4. 25.
	 * @author srec0064
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 4. 25.			srec0064			최초작성
	 * ------------------------------------------------
	 * @param prSelVo
	 * @return
	 * @throws Exception
	 */
	public Map<String, LivePremiumVO> calculateNewPriceWithPremiumList(PrSelVO prSelVo) throws Exception {
		log.debug("2-3) calculateNewPriceWithPremiumList");
		Map<String, LivePremiumVO> newPremiumMap = new HashMap<>();
		
		for (Map.Entry<String, TreeSet<LivePremiumVO>> entry : itPremiumStdrBasVoService.getItPremiumStdrBasVo().entrySet()) {
			String key = entry.getKey();
			TreeSet<LivePremiumVO> value = entry.getValue();
			
			Optional<LivePremiumVO> optionalLivePremiumVO = value.stream()
					.filter(vo -> {
						return prSelVo != null && vo.getValidBeginDt().compareTo(prSelVo.getOccrrncDe() + prSelVo.getOccrrncTime()) <= 0
								&& vo.getValidEndDt().compareTo(prSelVo.getOccrrncDe() + prSelVo.getOccrrncTime()) >= 0
								&& vo.getMetalCode().equals(prSelVo.getMetalCode());
					})
					.findFirst();
			
			if (optionalLivePremiumVO.isPresent()) {
				LivePremiumVO livePremiumVO = optionalLivePremiumVO.get();
				long sum = livePremiumVO.getSlePremiumAmount() + prSelVo.getEndPc();
				LivePremiumVO newPremiumVO = new LivePremiumVO();
				BeanUtils.copyProperties(livePremiumVO, newPremiumVO);
				newPremiumVO.setNewSelPrice(sum);
				newPremiumMap.put(key, newPremiumVO);
			}
		}
		
		log.debug("2-4) newPremiumMap: " + newPremiumMap);

		return newPremiumMap;
	}

	/**
	 *  초기 가단가 지정가 데이터를 불러온다. (LME, KRW)
	 */
	@Override
	public Map<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> loadInitialPrvsnlLimitData() throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();
		List<CommPrvsnlLimitOrderRedisMsgVO> initPrvsnlLimitDataList = limitMapper.loadInitialPrvsnlLimitData();

		String result = objectMapper.writeValueAsString(initPrvsnlLimitDataList);
		log.debug("initPrvsnlLimitDataList: " + result);

		return initPrvsnlLimitDataList.stream()
				.collect(Collectors.groupingBy(CommPrvsnlLimitOrderRedisMsgVO::getMetalCode, Collectors.toCollection(TreeSet::new)));
	}

	/**
	 *  초기 가단가 지정가 데이터를 불러온다. (FX)
	 */
	@Override
	public Map<String, TreeSet<CommPrvsnlLimitOrderRedisMsgVO>> loadInitialPrvsnlLimitFxData() throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();
		List<CommPrvsnlLimitOrderRedisMsgVO> initPrvsnlLimitDataList = limitMapper.loadInitialPrvsnlLimitFxData();

		String result = objectMapper.writeValueAsString(initPrvsnlLimitDataList);
		log.debug("initPrvsnlLimitDataList: " + result);

		return initPrvsnlLimitDataList.stream()
				.collect(Collectors.groupingBy(CommPrvsnlLimitOrderRedisMsgVO::getMetalCode, Collectors.toCollection(TreeSet::new)));
	}

	/**
	 *  종목별로 가단가용 큐에 넘겨줄 최종 데이터를 저장한다
	 */
	@Override
	public synchronized void settingPrvsnlLimitQueueData(TreeSet<CommPrvsnlLimitOrderRedisMsgVO> commPrvsnlLimitOrderRedisMsgTreeSet, CommPrvsnlLimitOrderQueueMsgVO queueVo) {
		CommPrvsnlLimitOrderQueueMsgVO returnVo =  new CommPrvsnlLimitOrderQueueMsgVO();

		try {
			returnVo.setLimitOrderRequestDt(queueVo.getLimitOrderRequestDt());																// 지정가 주문 일시
			returnVo.setLimitOrderRequestCo(commPrvsnlLimitOrderRedisMsgTreeSet.size());													// 지정가 주문 요청 건수
			returnVo.setLimitOrderStdrSlePc(queueVo.getLimitOrderStdrSlePc());																// 지정가 주문 기준 판매 가격
			returnVo.setMetalCode(commPrvsnlLimitOrderRedisMsgTreeSet.first().getMetalCode());												// 금속 코드
			returnVo.setSlePcRltmSn(queueVo.getSlePcRltmSn());																				// 판매 가격 실시간 순번
			returnVo.setLmePcRltmSn(queueVo.getLmePcRltmSn());																				// LME 가격 실시간 순번
			returnVo.setLme3m(queueVo.getLme3m());																							// LME 3M
			returnVo.setLmeCash(queueVo.getLmeCash());																						// LME 현금
			returnVo.setLmeMdatCffcnt(queueVo.getLmeMdatCffcnt());																			// LME 조정계수
			returnVo.setEhgtPcRltmSn(queueVo.getEhgtPcRltmSn());																			// 환율 가격 실시간 순번
			returnVo.setSpex(queueVo.getSpex());																							// 환율 가격
			returnVo.setSpexMdatCffcnt(queueVo.getSpexMdatCffcnt());																		// 환율 조정계수
			returnVo.setLimitOrderNoList(commPrvsnlLimitOrderRedisMsgTreeSet.stream()
					.map(CommPrvsnlLimitOrderRedisMsgVO::getLimitOrderNo)
					.collect(Collectors.toList()));																							// 지정가 주문번호 LIST TODO [pje] TreeSet에서 설정한 순서가 유지되는지 확인

			ObjectMapper objectMapper = new ObjectMapper();	// TODO [pje] 테스트용 - 삭제예정
			String result = objectMapper.writeValueAsString(returnVo);	// TODO [pje] 테스트용 - 삭제예정
			log.info("4-1) Setting Prvsnl Limit Queue Data: " + result);

			sendPrvsnlLimitQueueData(returnVo);
		} catch(Exception e) {
			log.error("[settingPrvsnlLimitQueueData Error] {}", ExceptionUtils.getStackTrace(e));
		}
	}

	/**
	 *  가단가용 큐에 데이터 전송
	 */
	@Override
	public void sendPrvsnlLimitQueueData(CommPrvsnlLimitOrderQueueMsgVO commPrvsnlLimitOrderQueueMsgVO) throws Exception {
		log.info("5-1) sendPrvsnlLimitQueueData");
		azureServiceBusQueueSender.prvsnlSend(commPrvsnlLimitOrderQueueMsgVO);
	}
	
}
