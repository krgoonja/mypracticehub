package com.sorincorp.comm.dynmDiver.model;

import com.sorincorp.comm.model.CommonVO;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

import java.math.BigDecimal;

@Data
@Validated
public class DynmDiverCommVO extends CommonVO {
    
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
     * 순번
    */
    private String rowNum;
    /**
     * 프리미엄 아이디
    */
    private String premiumId;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 아이템 순번
    */
    private int itmSn;
    /**
     * 아이템 코드
     */
    private String itmCode;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private String frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private String lastChangeDt;

    /**
     * 실시간 판매 가격 발생일자
     */
    private String occrrncDeTime;

    /**
     * 다이버_ON/OFF
     */
    private String diverAt;

    /**
     * 다이버 마진
     */
    private String diverMarginMin;

    /**
     * 다이버 발동 톤수(MT)
     */
    private String diverMotnTon;

    /**
     * 다이버 발동 시간 범위(초)
     */
    private String diverMotnTimeScope;

    /**
     * 재고 평균 마진
     */
    private String invntryAvgMargin;

    /**
     * 환율
     */
    private BigDecimal spex;

    /**
     * 지정가 주문 톤수 합
     */
    private int limitOrderWtSum;

    /**
     * 현재 가격
     */
    private long nowPc;

    /**
     * 다이버 발동 범위 (KRW)
     */
    private int diverScopekrw;

    /**
     * 목표 가격
     */
    private long goalPc;
    
    /**
     * 다이버 발동 범위 KRW
     */
    private int diverMotnKrwScope;

    /**
     * 다이버 상태 코드
     */
    private int diverStatusCode;

    /**
     * 다이버 분봉 조정 값
     */
    private int diverMdatVal;

    /**
     * 다이버 발동 지정가 MIN 값
     */
    private long limitOrderMinPc;


}