package com.sorincorp.comm.order.service;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.exception.CommCustomException;
import com.sorincorp.comm.order.mapper.CommAvrgpcOrderMapper;
import com.sorincorp.comm.order.model.CnCntrctOrderBasVO;
import com.sorincorp.comm.order.model.CommExcclcInfoVO;
import com.sorincorp.comm.order.model.OrOrderAvrgpcDtlVO;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * CommAvrgpcServiceImpl.java
 * 평균가 주문 공통 Service 구현체 클래스
 * @version
 * @since 2023. 8. 28.
 * @author srec0066
 */
@Slf4j
@Service
public class CommAvrgpcOrderServiceImpl implements CommAvrgpcOrderService {

	@Autowired
	private CommAvrgpcOrderMapper commAvrgpcOrderMapper;

	/**
	 *	계약_계약 발주 기본 조회
	 */
	@Override
	public CnCntrctOrderBasVO selectCnCntrctOrderBas(String cntrctOrderNo) throws Exception {
		return Optional.ofNullable(commAvrgpcOrderMapper.selectCnCntrctOrderBas(cntrctOrderNo, null))
				.orElseThrow(() -> {
					log.error("계약 발주 기본 정보 미존재");
					return new CommCustomException("계약 발주 기본 정보 미존재");
				});
	}

	/**
	 * 누적 평균 가격 목록 조회 조회(이전 월 부터 지정한 개수 만큼)
	 */
	@Override
	public List<OrOrderAvrgpcDtlVO> selectAccmltAvrgpcListTopCnt(String cntrctOrderNo, int cnt) throws Exception {
		CnCntrctOrderBasVO cntrctInfo = this.selectCnCntrctOrderBas(cntrctOrderNo);
		cntrctInfo.setCustomDataCnt(cnt);

		return commAvrgpcOrderMapper.selectAccmltAvrgpcList(cntrctInfo);
	}

	/**
	 *	누적 평균 가격 목록 조회
	 */
	@Override
	public List<OrOrderAvrgpcDtlVO> selectAccmltAvrgpcList(String cntrctOrderNo) throws Exception {

		// 1. 계약_발주 기본 데이터 조회
		CnCntrctOrderBasVO cntrctInfo = this.selectCnCntrctOrderBas(cntrctOrderNo);

		// 2. 평균가 확정단가여부 세팅
		this.setAvrgpcDcsnUntpcAt(cntrctInfo);

		// 3. 누적 평균 가격 목록 조회
		List<OrOrderAvrgpcDtlVO> returnList = commAvrgpcOrderMapper.selectAccmltAvrgpcList(cntrctInfo);

		// 4. 최소 조회대상 데이터수 5개 (조회일 기준 누적 평균 가격 목록이 5개 미만이라면 이전월 데이터 포함하여 조회)
		if (returnList.size() < 5) {
			cntrctInfo.setDataCnt(5);
			returnList = commAvrgpcOrderMapper.selectAccmltAvrgpcList(cntrctInfo);
		}

		log.info(">> [CommAvrgpcServiceImpl] [selectAccmltAvrgpcList] cntrctInfo : " + cntrctInfo.toString());

		return returnList;
	}

	/**
	 *	평균가 확정 단가 여부 세팅: [Y:확정가, N:가단가]
	 */
	@Override
	public void setAvrgpcDcsnUntpcAt(CnCntrctOrderBasVO cntrctInfo) throws Exception {
		String avrgpcDcsnUntpcAt = ""; 				  	  // 평균가 확정 단가 여부
		String getNowDate = DateUtil.getNowDate(); 		  // 현재날짜
		String untpcDcsnDe = cntrctInfo.getUntpcDcsnDe(); // 단가 확정 일자

		if(StringUtils.equals(cntrctInfo.getSleMthdCode(), "04")) {
			if (DateUtil.compareToCalerdar(getNowDate, untpcDcsnDe) > 0) {
				// [확정가]: 현재 > 단가확정일
				avrgpcDcsnUntpcAt = "Y";
				cntrctInfo.setOccrrncMt(untpcDcsnDe); // 확정가일 경우, 조회대상 월 세팅
			} else {
				// [가단가]: 현재 <= 단가확정일
				avrgpcDcsnUntpcAt = "N";
			}
		} else {
			// [확정가]: 평균가-라이브 주문은 Y로 기본값 세팅
			avrgpcDcsnUntpcAt = "Y";
		}

		log.info(">> [CommAvrgpcServiceImpl][setAvrgpcDcsnUntpcAt] getNowDate : " + getNowDate + ", untpcDcsnDe : " + untpcDcsnDe + ", avrgpcDcsnUntpcAt : " + avrgpcDcsnUntpcAt);
		cntrctInfo.setAvrgpcDcsnUntpcAt(avrgpcDcsnUntpcAt);
	}

	/**
	 *	평균 LME, 환율 데이터 조회
	 */
	@Override
	public OrOrderAvrgpcDtlVO selectPrevBsnDeAvrgpc(CnCntrctOrderBasVO cnCntrctOrderBasVO) throws Exception {
		// 평균가 확정단가여부 세팅
		// 24-01-26 변경사항 : 확정단가여부가 기존에 Y로 세팅되어 있으면 세팅 로직 스킵
		if(!StringUtils.equals(cnCntrctOrderBasVO.getAvrgpcDcsnUntpcAt(), "Y")) {
			this.setAvrgpcDcsnUntpcAt(cnCntrctOrderBasVO);
		}

		return commAvrgpcOrderMapper.selectPrevBsnDeAvrgpc(cnCntrctOrderBasVO);
	}

	/**
	 *	주문_주문 평균가 상세 등록
	 */
	@Override
	public void insertOrOrderAvrgpcDtl(OrOrderAvrgpcDtlVO orOrderAvrgpcDtlVO) throws Exception {
		commAvrgpcOrderMapper.insertOrOrderAvrgpcDtl(orOrderAvrgpcDtlVO);
	}

	/**
	 * LME CSP 가격 평균 값 구하기
	 */
	@Override
	public double getAveragingLmeCsp(List<OrOrderAvrgpcDtlVO> list) {

		if (list.isEmpty()) return 0;

		List<Double> listLmeCsp = list.stream()
				.filter(h -> h.getLmeCsp().doubleValue() > 0)
				.map(vo -> vo.getLmeCsp().doubleValue())
				.collect(Collectors.toList());

		return listLmeCsp.stream()
				.collect(Collectors.averagingDouble(Double::doubleValue));
	}

	/**
	 *	달러환산률 평균 값 구하기
	 */
	@Override
	public double getAveragingUsdCvtrate(List<OrOrderAvrgpcDtlVO> list) {

		if (list.isEmpty()) return 0;

		List<Double> listUsdCvtrate = list.stream()
				.filter(h -> h.getUsdCvtrate().doubleValue() > 0)
				.map(vo -> vo.getUsdCvtrate().doubleValue())
				.collect(Collectors.toList());

		return listUsdCvtrate.stream()
				.collect(Collectors.averagingDouble(Double::doubleValue));
	}

	/**
	 *	평균가 주문일 경우, 주문번호/계약정보 리턴
	 */
	@Override
	public String getOrderInfoString(String orderNo, String cntrctOrderNo) {
		StringBuilder result = new StringBuilder();
		try {
			CnCntrctOrderBasVO cntrct = Optional.ofNullable(commAvrgpcOrderMapper.selectCnCntrctOrderBas(cntrctOrderNo, orderNo))
													.orElseThrow(() -> {return new CommCustomException("평균가 주문 아님(계약 발주 기본 정보 미존재)");});

			result.append(orderNo).append(System.lineSeparator())
				  .append("계약번호 : ").append(cntrct.getCntrctNo()).append("(계약년월 : ").append(cntrct.getCntrctYm()).append(")");

		} catch (Exception e) {
			log.info(">> [CommAvrgpcServiceImpl] getOrderInfoString error :: " + e.getMessage());
			// 평균가 주문이 아니므로, 기존 주문번호 리턴
			result.append(orderNo);
		}

		return result.toString();
	}

	/**
	 *	평균가 주문일 경우, 중량정산/단가정산 정보를 리턴
	 */
	@Override
	public String getExcclcInfoString(String orderNo) {

		StringBuilder result = new StringBuilder();
		try {
			DecimalFormat formatter = new DecimalFormat("###,###");

			CommExcclcInfoVO order = commAvrgpcOrderMapper.selectOrderExcclcInfo(orderNo);

			long wtExcclcAmount = 0; // 중량 정산 금액
			long pcExcclcAmount = 0; // 단가 정산 금액

			if(order.getAvrgpcGoodsUntpc() > 0) {
				// [가단가] 주문 : 중량정산, 단가정산 분리

				if(StringUtils.equals(order.getSetleMthdCode(), "10")) {
					// 이월렛
					wtExcclcAmount = order.getWtRefndAmount() * -1;
					pcExcclcAmount = order.getPcRefndAmount() * -1;
				} else if(StringUtils.equals(order.getSetleMthdCode(), "20") || StringUtils.equals(order.getSetleMthdCode(), "40")) {
					// 여신
					wtExcclcAmount = order.getWtRepyAmount() * -1;
					pcExcclcAmount = order.getPcRepyAmount() * -1;
				}
				
		    	result.append("중량정산금액 : ").append(wtExcclcAmount == 0 ? "중량 확정 시 정산 될 예정입니다." : formatter.format(wtExcclcAmount))
					.append((wtExcclcAmount != 0 && pcExcclcAmount == 0) ? "(최종 확정 후 정산 됩니다.)" : "")
					.append(System.lineSeparator());
		    	result.append("단가정산금액 : ").append(pcExcclcAmount == 0 ? "단가 확정 시 정산 될 예정입니다." : formatter.format(pcExcclcAmount))
					.append((pcExcclcAmount != 0 && wtExcclcAmount == 0) ? "(최종 확정 후 정산 됩니다.)" : "");
			    
				// 미 결제 금액이 존재하고 추가 금액이 존재할 경우
			    if(wtExcclcAmount != 0 && pcExcclcAmount != 0 && order.getUnSetleAmount() > 0 && order.getAditAmount() > 0) {
			    	result.append(System.lineSeparator()).append("추가결제금액 : ").append(formatter.format(order.getAditAmount()));
			    }
			} else {
				// [확정가] 주문 : 기존 형식 그대로 유지
				// 확정가 or 증거금 주문의 경우, 정산은 중량에 대해 1번만 일어나므로 기존 형식 그대로 리턴
				wtExcclcAmount = order.getExcclcAmount();
				
				// 미 결제 금액이 존재하고 추가 금액이 존재할 경우
			    if(order.getUnSetleAmount() > 0 && order.getAditAmount() > 0) {
			    	result.append("정산금액 : ").append("0").append(" (추가결제금액 : ").append(formatter.format(order.getAditAmount())).append(")");
			    } else {
			    	result.append("정산금액 : ").append(formatter.format(wtExcclcAmount));
			    }
			}

		} catch (Exception e) {
			log.info(">> [CommAvrgpcServiceImpl] getOrderInfoString error :: " + e.getMessage());
			// 오류 발생시 빈값으로 리턴
			result.append("정산금액 : - ");
		}

		return result.toString();
	}
}
