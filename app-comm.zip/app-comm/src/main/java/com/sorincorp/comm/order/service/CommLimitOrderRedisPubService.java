package com.sorincorp.comm.order.service;

/**
 * CommLimitOrderRedisPubService.java
 * 지정가 주문 Redis Publish 공통 Service 인터페이스
 * 
 * @version
 * @since 2023. 4. 25.
 * @author srec0049
 */
public interface CommLimitOrderRedisPubService {
	
	/**
	 * <pre>
	 * 처리내용: Redis에 지정가 주문 메시지 발행하기 (인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제])
	 * </pre>
	 * @date 2023. 4. 25.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 4. 25.          srec0049         최초작성
	 * ------------------------------------------------
	 * @param limitOrderNo
	 * @param intrfcSttusCode : 인터페이스 상태 코드[I: 등록, U: 수정, D: 삭제]
	 * @throws Exception
	 */
	public void limitOrderMsgPublish(String limitOrderNo, String intrfcSttusCode) throws Exception;
}
