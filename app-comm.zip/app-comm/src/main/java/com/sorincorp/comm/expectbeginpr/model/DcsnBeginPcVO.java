package com.sorincorp.comm.expectbeginpr.model;

import java.math.BigDecimal;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class DcsnBeginPcVO {
	/**
     * 적용 일자
    */
	private String applcDe;
	/**
     * 적용 시작 일시
    */
	private String validBeginDt;
	/**
     * 적용 종료 일시
    */
	private String validEndDt;
	/**
     * 판매 방식 코드
    */
	private String sleMthdCode;
    /**
     * 금속 코드
    */
	private String metalCode;
    /**
     * 아이템 순번
    */
	private int itmSn;
    /**
     * 권역 대분류 코드
    */
	private String dstrctLclsfCode;
    /**
     * 브랜드 그룹 코드
    */
	private String brandGroupCode;
    /**
     * 브랜드 코드
    */
	private String brandCode;
    /**
     * 발생 일자
    */
	private String occrrncDe;
	/**
     * 발생 시간
    */
	private String occrrncTime;
	/**
     * 발생 일자 시간
    */
	private String occrrncDeTime;
    /**
     * 발생 순번
    */
	private String occrrncSn;
    /**
     * 판매 가격 실시간 순번
    */
	private String slePcRltmSn;
    /**
     * 시작 가격
    */
	private long beginPc;
    /**
     * 종료 가격
    */
	private long endPc;
    /**
     * 최고 가격
    */
	private long topPc;
    /**
     * 최저 가격
    */
	private long lwetPc;
    /**
     * 3개월 LME 가격
    */
	private java.math.BigDecimal threemonthLmePc;
    /**
     * LME 가격
    */
	private java.math.BigDecimal lmePc;
	/**
     * 판매 LME
    */
    private java.math.BigDecimal lmeTotal;
    /**
     * LME 정산 가격
    */
	private java.math.BigDecimal lmeExcclcPc;
    /**
     * 프리미엄 가격
    */
    private long premiumPc;
    /**
     * 환율 가격
    */
    private java.math.BigDecimal ehgtPc;
    /**
     * LME 가격 실시간 순번
    */
    private String lmePcRltmSn;
    /**
     * 프리미엄 번호
    */
    private String premiumNo;
    /**
     * 환율 가격 실시간 순번
    */
    private String ehgtPcRltmSn;
    /**
     * LME 조정 계수
    */
    private java.math.BigDecimal lmeMdatCffcnt;
    /**
     * FX 조정 계수
    */
    private java.math.BigDecimal fxMdatCffcnt;
    /**
     * 판매 환율
    */
    private java.math.BigDecimal ehgtPcct;
    /**
     * 대비 가격
    */
    private long versusPc;
    /**
     * 대비 등락 코드
    */
    private String versusFlctsCode;

    /**
     * 대비 등락 코드
    */
    private String versusRate;

    /**
     * 삭제 일시
    */
    private java.sql.Timestamp deleteDt;
    /**
     * 삭제 여부
    */
    private String deleteAt;
    /**
     * 최초 등록자 아이디
    */
    private String frstRegisterId;
    /**
     * 최초 등록 일시
    */
    private java.sql.Timestamp frstRegistDt;
    /**
     * 최종 변경자 아이디
    */
    private String lastChangerId;
    /**
     * 최종 변경 일시
    */
    private java.sql.Timestamp lastChangeDt;
    /**
     * 대비 가격
    */
    private long mountSale;
    /**
     * 거래량
     */
    private long delngQy;

    /**
     * 프리미엄 기준금액
    */
    private long premiumStdrAmount;
    /**
     * 권역 변동금
    */
     private long dstrctChangeAmount;
    /**
     * 브랜드그룹 변동금
    */
     private long brandGroupChangeamount;
    /**
     * 브랜드 변동금
    */
     private long brandChangeAmount;
     /**
      * 브랜드 변동금
     */
     private long stdrPrice;
     
     private BigDecimal spread;
     
}
