package com.sorincorp.comm.mbLog.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class MbLogVO implements Serializable {
	/**
	 *
	 */
	private static final long serialVersionUID = 5651971757569512166L;

	/**
	 *
	 */
	private String entrpsNo;
	/**
	 *
	 */
	private String mberNo;
	/**
	 *
	 */
	private String mberId;
	/**
	 *
	 */
	private String bsnmRegistNo;

}
