package com.sorincorp.comm.cntcsttus.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class CntcSttusVO implements Serializable {

	private static final long serialVersionUID = -714093248640024305L;
   /**
    * 인터페이스 구분 코드
   */
   private String intrfcSeCode;
    /**
    * 연계 상태 코드
   */
   private String cntcSttusCode;
    /**
    * 최종 변경자 아이디
   */
   private String lastChangerId;
    /**
    * 최종 변경 일시
   */
   private java.sql.Timestamp lastChangeDt;

   /**
    * 거래 및 상태 모니터링 결과
    */
   private boolean checkResult;

   /*
    * 통신선 체크 결과
    * 성공시 이전 상태가 "2"인 경우  1(초록)으로 가지 않고 주황색 유지(status: 2)
    */
   private boolean checkCommnLine;

   /**
    * 작업성공 타입(0: ALL성공, 1: ALL실패, 2:부분성공)
    */
   private int opertSuccesTy;

}