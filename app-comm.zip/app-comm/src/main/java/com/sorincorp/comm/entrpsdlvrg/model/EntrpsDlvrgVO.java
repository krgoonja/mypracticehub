package com.sorincorp.comm.entrpsdlvrg.model;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;

@Data
public class EntrpsDlvrgVO extends CommonVO{

	/**
	 *
	 */
	private static final long serialVersionUID = 1150759119591190468L;
	/**
	 * 배송지 번호
	 */
	private int dlvrgNo;
	/**
	 * 회사 번호
	 */
	private String entrpsNo;
   /**
     * 기본 배송지 여부
     */
	private String bassDlvrgAt;
	/**
	 * 배송지 구분
	 */
	private String dlvrgSeNm;
	/**
	 * 배송지 명
	 */
	private String dlvrgNm;

	/**
	 * 도로명 주소
	 */
	private String rnAdres;
	/**
	 * 주소
	 */
	private String adres;
	/**
	 * 우편번호
	 */
	private String postNo;
	/**
	 * 배송 담당자명
	 */
	private String dlvrgCharger;
    /**
     *  배송 담당자 연락처
     */
	private String dlvrgChargerCttpc;



}
