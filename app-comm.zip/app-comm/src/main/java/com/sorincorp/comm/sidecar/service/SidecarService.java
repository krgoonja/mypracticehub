package com.sorincorp.comm.sidecar.service;

import java.util.List;

import com.sorincorp.comm.sidecar.model.SidecarVO;

public interface SidecarService {
	/**
	 * <pre>
	 * 현재 시점 발동중인 사이드카 조회
	 * </pre>
	 * @date 2021. 12. 7.
	 * @author srec0031
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2021. 12. 7.		srec0031		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param 
	 * @return
	 * @throws Exception
	 */
	public List<SidecarVO> getSidecarOnList();
}
