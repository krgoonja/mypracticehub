package com.sorincorp.comm.message.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sorincorp.comm.message.model.AppPushQueueVO;
import com.sorincorp.comm.message.model.KkoMsgVO;
import com.sorincorp.comm.message.model.MessageTemplateVO;
import com.sorincorp.comm.message.model.SMSVO;

/**
 * SMSMapper.java
 * @version
 * @since 2021. 6. 21.
 * @author srec0041
 */
@Mapper
public interface SMSMapper {

	/**
	 * <pre>
	 * 메시지 템플릿에 저장된 템플릿정보 조회
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 21.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param templateNum
	 * @return
	 */
	public abstract MessageTemplateVO selectMessageTemplate(String templateNum);
	
	/**
	 * <pre>
	 * 휴대폰번호로 mberNo 및 smsKkoSe 조회 
	 * </pre>
	 * @date 2023. 3. 7.
	 * @author tpdls7080
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 3. 7.			tpdls7080			최초작성
	 * 2023. 3. 29.			jdrttl				리턴값 SMSVO로 수정 및 SMS/알림톡 구분 추가 리턴
	 * ------------------------------------------------
	 * @param moblphonNo
	 * @return SMSVO
	 */
	public abstract SMSVO selectMberNoAndSmsKkoSe(String moblphonNo);

	/**
	 * <pre>
	 * sms 보내기 위한 정보입력
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 21.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param smsVO
	 */
	public abstract int insertSMS(SMSVO smsVO);

	/**
	 * <pre>
	 * lms 보내기 위한 정보입력
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 21.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param smsVO
	 */
	public abstract void insertLMS(SMSVO smsVO);

	/**
	 * <pre>
	 * 알림톡 보내기 위한 정보입력
	 * </pre>
	 * @date 2021. 6. 21.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 21.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param kkoVO
	 */
	public abstract void insertKkoMsg(KkoMsgVO kkoVO);

	/**
	 * <pre>
	 * 앱푸쉬 발송 입력
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param appVO
	 */
	public abstract int insertAppPush(AppPushQueueVO appVO);

	/**
	 * <pre>
	 * sms 발송 히스토리 입력
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param smsVO
	 */
	public abstract void insertSMSHistory(SMSVO smsVO);

	/**
	 * <pre>
	 * 알림톡 발송 히스토리 입력
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param kkoVO
	 */
	public abstract void insertKkoMsgHistory(KkoMsgVO kkoVO);

	/**
	 * <pre>
	 * 앱푸쉬 발송 히스토리 입력
	 * </pre>
	 * @date 2021. 7. 2.
	 * @author srec0041
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 7. 2.			srec0041			최초작성
	 * ------------------------------------------------
	 * @param appVO
	 */
	public abstract void insertAppPushHistory(AppPushQueueVO appVO);

	/**
	 * 추가 수신자 그룹 조회
	 * @param smsSndngGroupCode (20 or 40)
	 * @return
	 */
	public abstract List<Map<String, String>> selectReceiverList(String smsSndngGroupCode);
	

	/**
	 * <pre>
	 * sms 발송 히스토리 입력 후 mssageSndngHistNo 리턴
	 * </pre>
	 * @date 2022. 7. 13.
	 * @author srec0068
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 13.			srec0068			최초작성
	 * ------------------------------------------------
	 * @param smsVO
	 */
	public abstract void insertSMSHistoryByReturnMssageSndngHistNo(SMSVO smsVO);

	/**
	 * <pre>
	 * 알림톡 등록(문자전송 통합)
	 * </pre>
	 * @date 2022. 10. 26.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 2.  		srec0067			최초작성
	 * ------------------------------------------------
	 * @param kkoVO
	 */
	public abstract void insertKkoMsgbySms(SMSVO smsVO);
	
	/**
	 * <pre>
	 * 알림톡 히스토리(문자전송 통합)
	 * </pre>
	 * @date 2021. 10. 26.
	 * @author srec0067
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 7. 2.			srec0067			최초작성
	 * ------------------------------------------------
	 * @param kkoVO
	 */
	public abstract void insertKkoMsgbySmsHistory(SMSVO smsVO);
}
