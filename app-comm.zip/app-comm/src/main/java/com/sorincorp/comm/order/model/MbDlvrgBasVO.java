package com.sorincorp.comm.order.model;

import lombok.Data;

/**
 * MbDlvrgBasVO.java
 * 배송지 및 기본 정보 VO 객체
 * @version
 * @since 2022. 9. 15.
 * @author srec0049
 */
@Data
public class MbDlvrgBasVO {
	
	/**
	 * 회원 번호
	 */
	private String mberNo;
	
	/**
	 * 업체 번호
	 */
	private String entrpsNo;
	
	/**
	 * 회원 아이디
	 */
	private String mberId;
	
	/**
	 * 회원 이름
	 */
	private String mberNm;
	
	/**
	 * 휴대폰 번호(회원)
	 */
	private String moblphonNo;
	
	/**
	 * 회원 이메일
	 */
	private String mberEmail;
	
	/**
	 * 회원 메일 수신 동의 여부
	 */
	private String mberEmailRecptnAgreAt;
	
	/**
	 * 회원 문자 수신 동의 여부
	 */
	private String mberChrctrRecptnAgreAt;
	
	/**
	 * 업체명 한글
	 */
	private String entrpsnmKorean;
	
	/**
	 * 업체명 영문
	 */
	private String entrpsnmEng;
	
	/**
	 * 회사 전화 번호
	 */
	private String cmpnyTlphonNo;
	
	/**
	 * 우편 번호(업체)
	 */
	private String postNo;
	
	/**
	 * 주소(업체)
	 */
	private String adres;
	
	/**
	 * 상세 주소(업체)
	 */
	private String detailAdres;
	
	/**
	 * 도로명 주소(업체)
	 */
	private String rnAdres;
	
	/**
	 * 도로명 상세 주소(업체)
	 */
	private String rnDetailAdres;
	
	/**
	 * 환불 계좌 번호(업체)
	 */
	private String refndAcnutNo;
	
	/**
	 * 이월렛 계좌 번호(업체)
	 */
	private String ewalletAcnutNo;
	
	/**
	 * 업체 등급 번호
	 */
	private String entrpsGradNo;
	
	/**
	 * 배송지명
	 */
	private String dlvrgNm;
	
	/**
	 * 우편 번호(배송지)
	 */
	private String receptPostNo;
	
	/**
	 * 주소(배송지)
	 */
	private String receptAdres;
	
	/**
	 * 상세 주소(배송지)
	 */
	private String receptDetailAdres;
	
	/**
	 * 도로명 주소(배송지)
	 */
	private String receptRnAdresas;
	
	/**
	 * 도로명 상세 주소(배송지)
	 */
	private String receptRnDetailAdres;
	
	/**
	 * 법정동 코드(배송지)
	 */
	private String legaldongCode;
	
	/**
	 * 배송지 담당자
	 */
	private String dlvrgCharger;
	
	/**
	 * 배송지 담당자 연락처
	 */
	private String dlvrgChargerCttpc;
	
	/**
	 * 배송지 담당자 이메일
	 */
	private String dlvrgChargerEmail;
	
	/**
	 * 일일 여신 구매 중량 한도
	 */
	private int dailCdtlnPurchsWtLmt;

	/**
	 *  부분 출고 상환 여부
	 */
	private String partDlivyRepyAt;
}
