package com.sorincorp.comm.exception;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.dao.CannotSerializeTransactionException;
import org.springframework.dao.CleanupFailureDataAccessException;
import org.springframework.dao.ConcurrencyFailureException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.dao.DeadlockLoserDataAccessException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.dao.IncorrectUpdateSemanticsDataAccessException;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.dao.InvalidDataAccessResourceUsageException;
import org.springframework.dao.NonTransientDataAccessException;
import org.springframework.dao.NonTransientDataAccessResourceException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.dao.PermissionDeniedDataAccessException;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.dao.RecoverableDataAccessException;
import org.springframework.dao.TransientDataAccessException;
import org.springframework.dao.TransientDataAccessResourceException;
import org.springframework.dao.TypeMismatchDataAccessException;
import org.springframework.dao.UncategorizedDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.sorincorp.comm.constants.ExceptionConstants;
import com.sorincorp.comm.util.MessageUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ControllerAdvice
@RestControllerAdvice
public class ControllerDBExceptionAdvice {

	@Autowired
	MessageUtil messageUtil;

	@ExceptionHandler(DuplicateKeyException.class)
	public ResponseEntity<Object> duplicateKeyException(Exception e) {
		log.error("Exception duplicateKeyException ---- :" + e);
		return new ResponseEntity<>("키 값 중 이미 존재하는 값이 있습니다.", HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(CannotAcquireLockException.class)
	public ResponseEntity<Object> cannotAcquireLockException(Exception e) {
		log.error("Exception cannotAcquireLockException ---- :" + e);
		return new ResponseEntity<>("CannotAcquireLockException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(CannotSerializeTransactionException.class)
	public ResponseEntity<Object> cannotSerializeTransactionException(Exception e) {
		log.error("Exception cannotSerializeTransactionException ---- :" + e);
		return new ResponseEntity<>("CannotSerializeTransactionException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(DeadlockLoserDataAccessException.class)
	public ResponseEntity<Object> deadlockLoserDataAccessException(Exception e) {
		log.error("Exception deadlockLoserDataAccessException ---- :" + e);
		return new ResponseEntity<>("DeadlockLoserDataAccessException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(OptimisticLockingFailureException.class)
	public ResponseEntity<Object> optimisticLockingFailureException(Exception e) {
		log.error("Exception optimisticLockingFailureException ---- :" + e);
		return new ResponseEntity<>("OptimisticLockingFailureException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(PessimisticLockingFailureException.class)
	public ResponseEntity<Object> pessimisticLockingFailureException(Exception e) {
		log.error("Exception pessimisticLockingFailureException ---- :" + e);
		return new ResponseEntity<>("pessimisticLockingFailureException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(ConcurrencyFailureException.class)
	public ResponseEntity<Object> concurrencyFailureException(Exception e) {
		log.error("Exception concurrencyFailureException ---- :" + e);
		return new ResponseEntity<>("ConcurrencyFailureException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(DataAccessResourceFailureException.class)
	public ResponseEntity<Object> dataAccessResourceFailureException(Exception e) {
		log.error("Exception dataAccessResourceFailureException ---- :" + e);
		return new ResponseEntity<>("DataAccessResourceFailureException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(EmptyResultDataAccessException.class)
	public ResponseEntity<Object> emptyResultDataAccessException(Exception e) {
		log.error("Exception emptyResultDataAccessException ---- :" + e);
		return new ResponseEntity<>("EmptyResultDataAccessException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(IncorrectResultSizeDataAccessException.class)
	public ResponseEntity<Object> incorrectResultSizeDataAccessException(Exception e) {
		log.error("Exception incorrectResultSizeDataAccessException ---- :" + e);
		return new ResponseEntity<>("IncorrectResultSizeDataAccessException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(TypeMismatchDataAccessException.class)
	public ResponseEntity<Object> typeMismatchDataAccessException(Exception e) {
		log.error("Exception typeMismatchDataAccessException ---- :" + e);
		return new ResponseEntity<>("TypeMismatchDataAccessException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(IncorrectUpdateSemanticsDataAccessException.class)
	public ResponseEntity<Object> incorrectUpdateSemanticsDataAccessException(Exception e) {
		log.error("Exception incorrectUpdateSemanticsDataAccessException ---- :" + e);
		return new ResponseEntity<>("IncorrectUpdateSemanticsDataAccessException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(InvalidDataAccessResourceUsageException.class)
	public ResponseEntity<Object> invalidDataAccessResourceUsageException(Exception e) {
		log.error("Exception invalidDataAccessResourceUsageException ---- :" + e);
		return new ResponseEntity<>("잘못된 DataBase의 데이터를 사용하려고 하였습니다.", HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(PermissionDeniedDataAccessException.class)
	public ResponseEntity<Object> permissionDeniedDataAccessException(Exception e) {
		log.error("Exception permissionDeniedDataAccessException ---- :" + e);
		return new ResponseEntity<>("PermissionDeniedDataAccessException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(RecoverableDataAccessException.class)
	public ResponseEntity<Object> recoverableDataAccessException(Exception e) {
		log.error("Exception recoverableDataAccessException ---- :" + e);
		return new ResponseEntity<>("RecoverableDataAccessException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(CleanupFailureDataAccessException.class)
	public ResponseEntity<Object> cleanupFailureDataAccessException(Exception e) {
		log.error("Exception cleanupFailureDataAccessException ---- :" + e);
		return new ResponseEntity<>("CleanupFailureDataAccessException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(DataRetrievalFailureException.class)
	public ResponseEntity<Object> dataRetrievalFailureException(Exception e) {
		log.error("Exception dataRetrievalFailureException ---- :" + e);
		return new ResponseEntity<>("DataRetrievalFailureException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(InvalidDataAccessApiUsageException.class)
	public ResponseEntity<Object> invalidDataAccessApiUsageException(Exception e) {
		log.error("Exception invalidDataAccessApiUsageException ---- :" + e);
		return new ResponseEntity<>("InvalidDataAccessApiUsageException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(UncategorizedDataAccessException.class)
	public ResponseEntity<Object> uncategorizedDataAccessException(Exception e) {
		log.error("Exception uncategorizedDataAccessException ---- :" + e);
		return new ResponseEntity<>("UncategorizedDataAccessException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(DataIntegrityViolationException.class)
	public ResponseEntity<Object> dataIntegrityViolationException(Exception e) {
		log.error("Exception dataIntegrityViolationException ---- :" + e);
		return new ResponseEntity<>("잘못된 값이 삽입 됐습니다(Empty, Null, 잘못된 형식의 값 등).", HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(NonTransientDataAccessResourceException.class)
	public ResponseEntity<Object> nonTransientDataAccessResourceException(Exception e) {
		log.error("Exception nonTransientDataAccessResourceException ---- :" + e);
		return new ResponseEntity<>("NonTransientDataAccessResourceException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(NonTransientDataAccessException.class)
	public ResponseEntity<Object> nonTransientDataAccessException(Exception e) {
		log.error("Exception nonTransientDataAccessException ---- :" + e);
		return new ResponseEntity<>("NonTransientDataAccessException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(QueryTimeoutException.class)
	public ResponseEntity<Object> queryTimeoutException(Exception e) {
		log.error("Exception queryTimeoutException ---- :" + e);
		return new ResponseEntity<>("QueryTimeoutException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(TransientDataAccessResourceException.class)
	public ResponseEntity<Object> transientDataAccessResourceException(Exception e) {
		log.error("Exception transientDataAccessResourceException ---- :" + e);
		return new ResponseEntity<>("TransientDataAccessResourceException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(TransientDataAccessException.class)
	public ResponseEntity<Object> transientDataAccessException(Exception e) {
		log.error("Exception transientDataAccessException ---- :" + e);
		return new ResponseEntity<>("TransientDataAccessException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(DataAccessException.class)
	public ResponseEntity<Object> dataAccessException(Exception e) {
		log.error("Exception dataAccessException ---- :" + e);
		return new ResponseEntity<>("dataAccessException" + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	public Object HttpMessageNotReadableException(Exception e, HttpServletRequest request) throws Exception {
		log.error("Exception HttpMessageNotReadableException ---- :" + e);

		/*
		 * 22-12-13 변경사항 : 새로고침 또는 Redirect 에 대응하는 오류 처리 방식 추가
		 * XHR이 아니면 FoErrorController에서 처리되도록 예외 처리
		 */
		if(request.getHeader("X-Requested-With") == null || request.getHeader("X-Requested-With").equals("XMLHttpRequest")) {
			log.error("XHR 방식이 아닌 요청임으로, 400 Error Page Return");
			request.setAttribute(RequestDispatcher.ERROR_STATUS_CODE, HttpStatus.BAD_REQUEST);
			throw e;
		}

		if (null==(e.getCause())) {
			return new ResponseEntity<>("HttpMessageNotReadableException : " + e.getMessage(), HttpStatus.BAD_REQUEST);
		}

		if(e.getCause().getClass() == InvalidFormatException.class) {
			return new ResponseEntity<>("잘못된 형태의 값이 입력되었습니다.", HttpStatus.BAD_REQUEST);
		} else {
			return new ResponseEntity<>("HttpMessageNotReadableException : " + e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	@ExceptionHandler(MaxUploadSizeExceededException.class)
	public ResponseEntity<Object> MaxUploadSizeExceededException(Exception e) {
		log.error("Exception MaxUploadSizeExceededException ---- :" + e);
		return new ResponseEntity<>(messageUtil.getMessage(ExceptionConstants.BAD_SIZE_FILE_EXCEPTION), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> exception(Exception e) {
		log.error("Exception exception ---- :", e);
		return new ResponseEntity<>("Exception : " + e.getMessage(), HttpStatus.BAD_REQUEST);
	}

}
