package com.sorincorp.comm.itemweight.mapper;

import java.util.List;

import com.sorincorp.comm.itemweight.model.ItemWeightVO;

public interface ItemWeightMapper {

	List<ItemWeightVO> getItemWeightCode(ItemWeightVO vo) throws Exception;
	
	/**
	 * <pre>
	 * 처리내용: 아이템의 허용 중량 비율을 가져 온다. 
	 * </pre>
	 * @date 2022. 12. 9.
	 * @auther chajeeman
	 * @history
	 * -----------------------------------------------
	 * 변경일					작성자				변경내용
	 * -----------------------------------------------
	 * 2022. 12. 9.			chajeeman			최초작성
	 * -----------------------------------------------
	 * @param itmSn
	 * @return
	 * @throws Exception
	 */
	public int getItmMinToleranceRate(int itmSn) throws Exception;
}
