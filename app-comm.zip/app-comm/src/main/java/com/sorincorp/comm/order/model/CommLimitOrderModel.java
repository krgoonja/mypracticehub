package com.sorincorp.comm.order.model;

//import java.math.BigDecimal;
//import java.math.RoundingMode;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.sorincorp.comm.itemprice.model.ItemPriceMatchingBlInfoVO;
//import com.sorincorp.comm.pcInfo.model.LivePremiumVO;
import com.sorincorp.comm.pcInfo.model.PrSelVO;

import lombok.Data;

/**
 * CommLimitOrderModel.java
 * 지정가 주문 공통 VO 객체
 * 
 * @version
 * @since 2023. 4. 30.
 * @author srec0049
 */
@Data
public class CommLimitOrderModel {
	
	/**
	 * 업체 번호
	 */
	private String entrpsNo;
	
	/**
	 * 금속 코드
	 */
	private String metalCode;
	
	/**
	 * 판매 단위 중량
	 */
	private int sleUnitWt;
	
	/**
	 * 1회 판매 가능 중량
	 */
	private int onceSlePossWt;
	
	/**
	 * 판매 방식 코드
	 */
	private String sleMthdCode;
	
	/**
	 * 판매 방식 상세 코드
	 */
	private String sleMthdDetailCode;
	
	/**
     * 아이템 순번
     */
    private int itmSn;
    
    /**
     * 권역 대분류 코드
     */
    private String dstrctLclsfCode;
    
    /**
     * 브랜드 그룹 코드
     */
    private String brandGroupCode;
    
    /**
     * 브랜드 코드
     */
    private String brandCode;
	
	/**
	 * 타겟 지정가 주문 중량 (개별)
	 */
	private int targetLimitOrderWt;
	
	/**
	 * 프리미엄 가격을 위한 브랜드코드 (가격정보 가져올때 사용)
	 */
	private String brandCodeByPremium;
	
	/**
	 * 최적의 BL 리스트
	 */
	private List<ItemPriceMatchingBlInfoVO> blList;
	
	/**
	 * 총 번들 수량
	 */
	private int totBundleQy;
	
	/**
	 * 재고 부분 체결 여부
	 */
	private String invntryPartCnclsAt;
	
	/**
     * 계약 발주 번호
     */
    private String cntrctOrderNo;

    /**
     * 소량 구매 여부
     */
	private String smlqyPurchsAt;

	/**
     * BL 번호
     */
    private String blNo;

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 번호에 해당하는 지정가 주문 내역으로 주문 VO 객체를 재구성한다
	 * </pre>
	 * @date 2023. 5. 9.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일                 작성자          변경내용
	 * ------------------------------------------------
	 * 2023. 5. 9.          srec0049         최초작성
	 * 2024. 2. 20.			srec0053		 계약구매 - 지정가 주문 반영을 위한 세팅 항목 추가
	 * ------------------------------------------------
	 * @param commOrLimitOrderBasVO
	 * @return
	 */
	public OrderModel getOrderModel(CommOrLimitOrderBasVO commOrLimitOrderBasVO) {
		OrderModel orderModel = new OrderModel();
		
		orderModel.setLimitOrderStdrSlePc(commOrLimitOrderBasVO.getLimitOrderStdrSlePc()); // 지정가 주문 기준 판매 가격
		orderModel.setLimitInputAmount(commOrLimitOrderBasVO.getLimitInputAmount()); // 지정가 입력 금액
		orderModel.setEntrpsNo(commOrLimitOrderBasVO.getEntrpsNo()); // 업체 번호
		orderModel.setMberNo(commOrLimitOrderBasVO.getMberNo()); // 회원 번호
		orderModel.setLimitOrderNo(commOrLimitOrderBasVO.getLimitOrderNo()); // 지정가 주문 번호
		orderModel.setPricingNo(commOrLimitOrderBasVO.getPricingNo()); // 프라이싱 번호
		orderModel.setMetalCode(commOrLimitOrderBasVO.getMetalCode()); // 금속 코드
		orderModel.setItmSn(commOrLimitOrderBasVO.getItmSn()); // 아이템 순번
		orderModel.setDstrctLclsfCode(commOrLimitOrderBasVO.getDstrctLclsfCode()); // 권역 대분류 코드
		orderModel.setDstrctMlsfcCode(commOrLimitOrderBasVO.getDstrctMlsfcCode()); // 권역 중분류 코드
		orderModel.setBrandGroupCode(commOrLimitOrderBasVO.getBrandGroupCode()); // 브랜드 그룹 코드
		orderModel.setRealBrandCode(commOrLimitOrderBasVO.getBrandCode()); // 브랜드 코드
		orderModel.setBrandCodeByPremium(this.brandCodeByPremium); // 프리미엄 가격을 위한 브랜드코드 (가격정보 가져올때 사용)
		orderModel.setOrderWt(commOrLimitOrderBasVO.getInvntryCeckWt()); // 주문 중량 (재고 체크 중량)
		orderModel.setDlvyMnCode(commOrLimitOrderBasVO.getDlvyMnCode()); // 배송 수단 코드
		orderModel.setDlvrgNo(null); // 배송지 번호, null일 경우의 로직 따로
		orderModel.setDlivyRequstDe(commOrLimitOrderBasVO.getDlivyRequstDe()); // 출고 요청 일자
		orderModel.setDlvyRequstCn(commOrLimitOrderBasVO.getDlvyRequstCn()); // 배송 요청 사항
		orderModel.setSleMthdCode(this.sleMthdCode); // 판매 방식 코드
		orderModel.setSleMthdDetailCode(commOrLimitOrderBasVO.getCntrctOrderNo() != null ? "0304" : null); // 판매 방식 상세 코드 [0304: 지정가(계약구매)]
		orderModel.setBsktNo(commOrLimitOrderBasVO.getBsktNo()); // 장바구니 번호
		orderModel.setRceptMediaSeCode(commOrLimitOrderBasVO.getRceptMediaSeCode()); // 접수 매체 구분 코드
		orderModel.setTotBundleQy(this.totBundleQy); // 총 번들 수량
		orderModel.setInvntryPartCnclsAt(this.invntryPartCnclsAt); // 재고 부분 체결 여부
		orderModel.setCntrctOrderNo(commOrLimitOrderBasVO.getCntrctOrderNo()); // 계약 발주 번호
		orderModel.setCntrctPurchsLastGoodsUntpc(commOrLimitOrderBasVO.getCntrctPurchsLastGoodsUntpc()); // 계약 구매 최종 상품 단가
		orderModel.setSmlqyPurchsAt(commOrLimitOrderBasVO.getSmlqyPurchsAt()); // 소량 구매 여부
		// 소량구매일 경우, 관련 데이터 세팅
		if(StringUtils.equals("Y", orderModel.getSmlqyPurchsAt())) {
			orderModel.setReMainBlNo(commOrLimitOrderBasVO.getBlNo()); 		 // BL 번호
			orderModel.setRmndrDscnt(commOrLimitOrderBasVO.getRmndrDscnt()); // 자투리 할인(추가할인)
		}
		
//		couponDscntPrice
//		couponSeqNo
		
		String paymentMn = null; // 결제수단 (e-Wallet: ewallet, 증거금: wrtm, (B2B 전자상거래보증, 케이지크레딧): mrtggGrnty)
		String setleMthdCode = commOrLimitOrderBasVO.getSetleMthdCode(); // 결제 방식 코드
		String setleMthdDetailCode = commOrLimitOrderBasVO.getSetleMthdDetailCode(); // 결제 방식 상세 코드 [4010: 케이지크레딧]
		switch(setleMthdCode) {
		case "10" : 
			paymentMn = "ewallet"; // e-Wallet
			break;
		case "20" : 
			paymentMn = "mrtggGrnty"; // B2B 전자상거래보증
			break;
		case "40" : 
			if(StringUtils.equals("4010", setleMthdDetailCode)) {
				paymentMn = "mrtggGrnty"; // 케이지크레딧
				orderModel.setCdtlnSvcSeCode("02"); // 여신 서비스 구분 코드 [02: 케이지크레딧]
			}
			break;
		case "90" : 
			paymentMn = "wrtm"; // 증거금
			break;
		}
		orderModel.setPaymentMn(paymentMn); // 결제수단 (e-Wallet: ewallet, 증거금: wrtm, (B2B 전자상거래보증, 케이지크레딧): mrtggGrnty)
		
		switch(orderModel.getPaymentMn()) {
			case "wrtm" : 
				orderModel.setPurchsInclnStepRate(commOrLimitOrderBasVO.getWrtmMummWrtmRate().intValue()); // 증거금 비율 선택 값 (구매 성향 단계 비율)
				break;
			case "mrtggGrnty" : 
				orderModel.setMrtggGrntyRepyPd(commOrLimitOrderBasVO.getRepyPd()); // B2B 전자상거래보증 상환기간 선택 값
				break;
		}
		
		// 배송지 및 회원 기본
		MbDlvrgBasVO mbDlvrgBasVO = new MbDlvrgBasVO();
		mbDlvrgBasVO.setMberEmail(commOrLimitOrderBasVO.getOrdrrEmail()); // 회원 이메일
		mbDlvrgBasVO.setMoblphonNo(commOrLimitOrderBasVO.getOrdrrMoblphonNo()); // 휴대폰 번호(회원)
		mbDlvrgBasVO.setMberNo(commOrLimitOrderBasVO.getMberNo()); // 회원 번호
		mbDlvrgBasVO.setMberNm(commOrLimitOrderBasVO.getOrdrrNm()); // 주문자 명
		mbDlvrgBasVO.setMoblphonNo(commOrLimitOrderBasVO.getOrdrrMoblphonNo()); // 주문자 휴대폰 번호
		mbDlvrgBasVO.setMberEmail(commOrLimitOrderBasVO.getOrdrrEmail()); // 주문자 이메일
		mbDlvrgBasVO.setEntrpsnmKorean(commOrLimitOrderBasVO.getOrderEntrpsNm()); // 주문 업체 명
	    mbDlvrgBasVO.setCmpnyTlphonNo(commOrLimitOrderBasVO.getOrderEntrpsTelno()); // 주문 업체 전화번호
	    mbDlvrgBasVO.setPostNo(commOrLimitOrderBasVO.getOrderEntrpsZip()); // 주문 업체 우편번호
	    mbDlvrgBasVO.setAdres(commOrLimitOrderBasVO.getOrderEntrpsAdres()); // 주문 업체 주소
	    mbDlvrgBasVO.setDetailAdres(commOrLimitOrderBasVO.getOrderEntrpsDetailAdres()); // 주문 업체 상세 주소
	    mbDlvrgBasVO.setRnAdres(commOrLimitOrderBasVO.getOrderEntrpsRnAdres()); // 주문 업체 도로명 주소
	    mbDlvrgBasVO.setRnDetailAdres(commOrLimitOrderBasVO.getOrderEntrpsRnDetailAdres()); // 주문 업체 도로명 상세 주소
	    mbDlvrgBasVO.setPartDlivyRepyAt(commOrLimitOrderBasVO.getPartDlivyRepyAt()); // 부분 출고 상환 여부
	    // 자차배송이 아닐 경우 
	    if(!StringUtils.equals("02", orderModel.getDlvyMnCode())) {
	    	mbDlvrgBasVO.setDlvrgNm(commOrLimitOrderBasVO.getDlvrgNm()); // 배송지 명
	    	mbDlvrgBasVO.setEntrpsnmKorean(commOrLimitOrderBasVO.getReceptEntrpsNm()); // 수취 업체 명
	    	mbDlvrgBasVO.setReceptPostNo(commOrLimitOrderBasVO.getReceptEntrpsPostNo()); // 수취 업체 우편 번호
	    	mbDlvrgBasVO.setReceptAdres(commOrLimitOrderBasVO.getReceptEntrpsAdres()); // 수취 업체 주소
	    	mbDlvrgBasVO.setReceptDetailAdres(commOrLimitOrderBasVO.getReceptEntrpsDetailAdres()); // 수취 업체 상세 주소
	    	mbDlvrgBasVO.setReceptRnAdresas(commOrLimitOrderBasVO.getReceptEntrpsRnAdres()); // 수취 업체 도로명 주소
	    	mbDlvrgBasVO.setReceptRnDetailAdres(commOrLimitOrderBasVO.getReceptEntrpsRnDetailAdres()); // 수취 업체 도로명 상세 주소
	    	mbDlvrgBasVO.setLegaldongCode(commOrLimitOrderBasVO.getReceptEntrpsLegaldongCode()); // 수취 업체 법정동 코드
	    	mbDlvrgBasVO.setDlvrgChargerCttpc(commOrLimitOrderBasVO.getReceptEntrpsMoblphonNo()); // 수취 업체 휴대폰 번호
	    	mbDlvrgBasVO.setDlvrgCharger(commOrLimitOrderBasVO.getReceptEntrpsChargerNm()); // 수취 업체 담당자 명
	    	mbDlvrgBasVO.setDlvrgChargerEmail(commOrLimitOrderBasVO.getReceptEntrpsChargerEmail()); // 수취 업체 담당자 이메일
	    }
		orderModel.setMbDlvrgBas(mbDlvrgBasVO);
		orderModel.setDlvrgPostNo(commOrLimitOrderBasVO.getReceptEntrpsPostNo()); // 배송지 우편 번호
		
		// 실시간 판매 가격 정보
		PrSelVO prSelVO = new PrSelVO();
//		prSelVO.setPremiumNo(commOrLimitOrderBasVO.getPremiumNo()); // 프리미엄 번호, 20230518 프리미엄 번호 대신 프리미엄 ID가 필요(지정가 주문 시점의 프리미엄이 필요함)
		prSelVO.setPremiumId(commOrLimitOrderBasVO.getPremiumId()); // 프리미엄 아이디
		prSelVO.setSlePcRltmSn(commOrLimitOrderBasVO.getSlePcRltmSn()); // 판매 가격 실시간 순번
		prSelVO.setLmePcRltmSn(commOrLimitOrderBasVO.getLmePcRltmSn()); // LME 가격 실시간 순번
		prSelVO.setEhgtPcRltmSn(commOrLimitOrderBasVO.getEhgtPcRltmSn()); // 환율 가격 실시간 순번
		prSelVO.setThreemonthLmePc(commOrLimitOrderBasVO.getLme3m()); // LME 3M
		prSelVO.setLmePc(commOrLimitOrderBasVO.getLmeCash()); // LME 현금
		prSelVO.setLmeMdatCffcnt(commOrLimitOrderBasVO.getLmeMdatCffcnt()); // LME 조정 계수
		prSelVO.setEhgtPc(commOrLimitOrderBasVO.getSpex()); // 현물환
		prSelVO.setFxMdatCffcnt(commOrLimitOrderBasVO.getSpexMdatCffcnt()); // 현물환 조정 계수
		
//		// (지정가 입력 금액 - 프리미엄 가격), 프리미엄을 제외한 종료 가격
//		//  1) 지정가 주문의 브랜드무관일 경우 브랜드 변동 금액은 포함되지 않음? MAX?
//		prSelVO.setNonPremiumEndPc(commOrLimitOrderBasVO.getLimitInputAmount() - commOrLimitOrderBasVO.getPremiumPc().longValue());
		
		orderModel.setPrSelVO(prSelVO);
		
		//쿠폰정보
		orderModel.setCouponApplcAt(commOrLimitOrderBasVO.getCouponApplcAt());
		
//		// 프리미엄 가격 정보
//		LivePremiumVO livePremiumVO = new LivePremiumVO();
//		livePremiumVO.setPremiumStdrAmount(new BigDecimal(String.valueOf(commOrLimitOrderBasVO.getPremiumStdrAmount()))); // 프리미엄 기준 금액
//		livePremiumVO.setDstrctChangeAmount(new BigDecimal(String.valueOf(commOrLimitOrderBasVO.getDstrctChangeAmount()))); // 권역 변동 금액
//		livePremiumVO.setBrandGroupChangeAmount(new BigDecimal(String.valueOf(commOrLimitOrderBasVO.getBrandGroupChangeAmount()))); // 브랜드 그룹 변동 금액
//		livePremiumVO.setBrandChangeAmount(new BigDecimal(String.valueOf(commOrLimitOrderBasVO.getBrandChangeAmount()))); // 브랜드 변동 금액
//		livePremiumVO.setSlePremiumAmount(commOrLimitOrderBasVO.getPremiumPc().longValue()); // 프리미엄 가격, 판매 프리미엄 금액(slePremiumAmount)
//		orderModel.setLivePremiumVO(livePremiumVO);
		
		return orderModel;
	}

	/**
	 * <pre>
	 * 처리내용: 지정가 주문 번호에 해당하는 가단가 지정가 주문 내역으로 주문 VO 객체를 재구성한다
	 * </pre>
	 * @date 2024. 9. 10.
	 * @author srec0066
	 * @history
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2024. 9. 10.		srec0066		최초작성
	 * -------------------------------------------------------------------------
	 * @param commOrLimitOrderBasVO
	 * @return orderModel
	 */
	public OrderModel getPrvsnlOrderModel(CommOrLimitOrderBasVO commOrLimitOrderBasVO) {
		OrderModel orderModel = new OrderModel();

		orderModel.setOrderNo(commOrLimitOrderBasVO.getOrderNo()); 					 // 주문 번호
		orderModel.setLimitOrderNo(commOrLimitOrderBasVO.getLimitOrderNo()); 		 // 지정가 주문 번호
		orderModel.setEntrpsNo(commOrLimitOrderBasVO.getEntrpsNo()); 				 // 업체 번호
		orderModel.setMetalCode(commOrLimitOrderBasVO.getMetalCode()); 				 // 금속 코드
		orderModel.setItmSn(commOrLimitOrderBasVO.getItmSn()); 						 // 아이템 순번
		orderModel.setDstrctLclsfCode(commOrLimitOrderBasVO.getDstrctLclsfCode());   // 권역 대분류 코드
		orderModel.setBrandGroupCode(commOrLimitOrderBasVO.getBrandGroupCode()); 	 // 브랜드 그룹 코드
		orderModel.setRealBrandCode(commOrLimitOrderBasVO.getBrandCode()); 			 // 브랜드 코드
		orderModel.setSleMthdCode(this.sleMthdCode);								 // 판매 방식 코드
		orderModel.setOrderWt(commOrLimitOrderBasVO.getInvntryCeckWt()); 			 // 주문 중량 (총 실제 주문 중량)
		orderModel.setWtChange(commOrLimitOrderBasVO.getWtChange().doubleValue());	 // 중량 변동
		orderModel.setGradApplcAmount(commOrLimitOrderBasVO.getGradApplcAmount());	 // 등급 할인 금액
		orderModel.setCouponApplcAt(commOrLimitOrderBasVO.getCouponApplcAt());		 // 쿠폰 적용 여부
		orderModel.setLimitSeCode(commOrLimitOrderBasVO.getLimitSeCode());			 // 지정가 구분 코드 [F: LME/X: 환율/R: KRW]
		orderModel.setDlivyRequstDe(commOrLimitOrderBasVO.getDlivyRequstDe());       // 출고 요청 일자
		orderModel.setPremiumPc(commOrLimitOrderBasVO.getPremiumPc());   			 // 프리미엄 가격

		// 실시간 판매 가격 정보
		PrSelVO prSelVO = new PrSelVO();
		prSelVO.setSlePcRltmSn(commOrLimitOrderBasVO.getSlePcRltmSn()); 			// 판매 가격 실시간 순번
		prSelVO.setLmePcRltmSn(commOrLimitOrderBasVO.getLmePcRltmSn()); 			// LME 가격 실시간 순번
		prSelVO.setEhgtPcRltmSn(commOrLimitOrderBasVO.getEhgtPcRltmSn()); 			// 환율 가격 실시간 순번
		prSelVO.setThreemonthLmePc(commOrLimitOrderBasVO.getLme3m()); 				// LME 3M
		prSelVO.setLmePc(commOrLimitOrderBasVO.getLmeCash()); 						// LME 현금
		prSelVO.setLmeMdatCffcnt(commOrLimitOrderBasVO.getLmeMdatCffcnt()); 		// LME 조정 계수
		prSelVO.setEhgtPc(commOrLimitOrderBasVO.getSpex()); 						// 현물환
		prSelVO.setFxMdatCffcnt(commOrLimitOrderBasVO.getSpexMdatCffcnt()); 		// 현물환 조정 계수
		prSelVO.setPremiumPc(commOrLimitOrderBasVO.getPremiumPc().longValue());     // 프리미엄 가격

		orderModel.setPrSelVO(prSelVO);

		return orderModel;
	}
}
