package com.sorincorp.comm.bsnInfo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class HvofTimeVO implements Serializable{
    
	private static final long serialVersionUID = 2849004139164064398L;

    /**
     * 적용 일자
    */
    private String applcDe;
    /**
     * 적용 시작 시간
    */
    private String applcBeginTime;
    /**
     * 적용 종료 시간
    */
    private String applcEndTime;
    /**
     * 휴무 유형 코드
    */
    private String hvofTyCode;
    /**
     * 비고
    */
    private String rm;
    
}
