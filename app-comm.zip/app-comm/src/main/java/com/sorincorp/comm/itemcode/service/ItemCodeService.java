package com.sorincorp.comm.itemcode.service;

import java.util.List;

import com.sorincorp.comm.itemcode.model.ItemCodeVO;

public interface ItemCodeService {
	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * 
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @throws Exception
	 */
	public void initItemCode() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * 
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param metalCode
	 * @return
	 * @throws Exception
	 */
	public List<ItemCodeVO> getItemCodeList(String metalCode) throws Exception;

	public List<ItemCodeVO> getItemFtrsProcessAtCodeList(String metalCode, String ftrsProcessAt) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * 
	 * @date 2021. 7. 12.
	 * @author srec0030
	 * @history ------------------------------------------------ 변경일 작성자 변경내용
	 *          ------------------------------------------------ 2021. 7. 12.
	 *          srec0030 최초작성 ------------------------------------------------
	 * @param itemCodeList
	 * @return
	 * @throws Exception
	 */
	public String getItemCodeListStr(List<ItemCodeVO> itemCodeList, String val) throws Exception;

	public Boolean getEntrpsMetalCodeAt(String entrpsNo, String metalCode) throws Exception;

	public List<ItemCodeVO> getEntrpsMetalCodeList(String entrpsNo) throws Exception;

	public List<ItemCodeVO> getMbEntrpsMetalAcctoAuthorSetupBasList(String entrpsNo) throws Exception;

	List<ItemCodeVO> getItemAvrgpcUseAtCodeList(String metalCode, String avrgpcUseAt) throws Exception;
}
