package com.sorincorp.comm.message.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.comm.message.mapper.MailMapper;
import com.sorincorp.comm.message.model.MailVO;

import lombok.extern.slf4j.Slf4j;


/**
 * MailServiceImpl.java
 * @version
 * @since 2021. 6. 21.
 * @author srec0042
 */
@Slf4j
@Service
@PropertySource(value = "classpath:/config/sms/sms-${spring.profiles.active}.properties", ignoreResourceNotFound = true)
public class MailServiceImpl implements MailService {

	@Autowired
	private MailMapper mailMapper;
	
	@Value("${email.ec.receiver}")
    private String emailEcReceiver;

//	public int insertMailSend(MailVO param, Map<String,String> map) throws Exception {
//		int mailTmptSeq = param.getMailTmptSeq();
//		
//		log.debug(">> [MailServiceImpl][insertMailSend] emailEcReceiver : " + emailEcReceiver + ", " + mailTmptSeq);
//		
//		param = insertMailSendComm(param, map, mailTmptSeq);
//		
//		int result = mailMapper.insertHistory(param);
//		
//		return result;
//	}
	
//	/**
//	 * <pre>
//	 * 처리내용: 이메일(내용 반복) 단건 발송
//	 * </pre>
//	 * @date 2022. 6. 22.
//	 * @author hyunjin05
//	 * @history 
//	 * ------------------------------------------------
//	 * 변경일					작성자				변경내용
//	 * ------------------------------------------------
//	 * 2022. 6. 22.			hyunjin05			최초작성
//	 * ------------------------------------------------
//	 * @param param
//	 * @return
//	 * @throws Exception
//	 */
//	public int insertMailRepitSend(MailVO param, List<Map<String,String>> listMap) throws Exception {
//		int mailTmptSeq = param.getMailTmptSeq();
//		
//		log.debug(">> [MailServiceImpl][insertMailRepitSend] emailEcReceiver : " + emailEcReceiver + ", " + mailTmptSeq);
//		
//		List<String> receiverList = new  ArrayList<String>(); // 수신자 중복 체크용, 20220120 추가
//		receiverList.add(param.getEmail()); // 첫번째 수신자 리스트 업
//		
//		ObjectMapper mapper = new ObjectMapper();
//		
//		/* 이메일 템플릿 설정 */
//		MailVO mailVo = mailMapper.selectMailRepitTmpt(mailTmptSeq); //템플릿 제목, 내용, 발신자 이메일
//		translateContents(mailVo); // 이메일 치환데이터 정규식
//		param.setMailNo(mailMapper.selectMailNoSeq());
//		param.setJobSeCode(mailVo.getJobSeCode());
//		param.setSntoEmail(mailVo.getSntoEmail());
//		param.setNsltCn(mailVo.getNsltCn());
//		param.setNsltSj(mailVo.getNsltSj());
//		//param.setNsltRe(mailVo.getNsltRe()); //이메일 탬플릿 내용 반복 구절
//		
//		//메일 템플릿 반복 구현, EMAIL_TMPLAT_LOOP 컬럼에 반복되는 템플릿을 넣어두고 사용 
//		String nsltRe = mailVo.getNsltRe();
//		String nsltReConcat = "";
//		
//		for(Map<String, String> map : listMap) {
//			for (Map.Entry<String, String> entry : map.entrySet()) {
//				nsltRe = nsltRe.replace("{{"+entry.getKey()+"}}", entry.getValue());
//			}
//			nsltReConcat += nsltRe;
//			nsltRe = mailVo.getNsltRe();
//		}
//		
//		Map<String, String> tempMap = new HashMap<>();
//		
//		tempMap.put("EMAIL_TMPLAT_LOOP", nsltReConcat);
//
//		/* 치환 데이터 본문, 제목에 치환데이터가 있을 시 #{KEY}로 명시 */
//		param.setMailReceiverReplaceJson(mapper.writeValueAsString(tempMap));
//		
//		// 메일 정보 등록 및 히스토리 등록 공통 메소드
//		this.insertMailComm(param, null);
//		
//		// 해당 템플릿의 경우 추가로 메일을 전송한다. 20220106 추가
//		// 회원가입완료(기업) : 27, 회원탈퇴완료(마스터) : 7, 회원탈퇴완료(기업) : 42, 주문완료 : 15, 배차완료 : 17, 배송완료 : 19
//		if(mailTmptSeq == 7 || mailTmptSeq == 15 || mailTmptSeq == 17 || mailTmptSeq == 19 || mailTmptSeq == 27
//				|| mailTmptSeq == 42 || mailTmptSeq == 47 || mailTmptSeq == 48 || mailTmptSeq == 49 || mailTmptSeq == 56) {
//			// 추가 수신자가 없거나 중복되면 보내지 않는다.
//			if(StringUtils.isEmpty(emailEcReceiver) || Collections.frequency(receiverList, emailEcReceiver) > 0) {
//				log.debug("[MailServiceImpl][insertMailRepitSend]>> emailEcReceiver duplication");
//			} else {
//				// 메일 정보 등록 및 히스토리 등록 공통 메소드
//				this.insertMailComm(param, emailEcReceiver);
//			}
//			
//			receiverList.add(emailEcReceiver); // 두번째 수신자 리스트 업
//		}
//		
//		log.debug(">> param.getPurchschargerAddMailAt() : " + param.getPurchschargerAddMailAt());
//		// 추가 구매담당자 이메일이 있을 경우 메일을 한번 더 보낸다. 20220120 추가
//		if(StringUtils.equals(param.getPurchschargerAddMailAt(), "Y")) {
//			String purchschargerEmail = mailMapper.selectPurchschargerEmail(param);
//			log.debug(">> purchschargerEmail : " + purchschargerEmail);
//			
//			// 추가 수신자가 없거나 중복되면 보내지 않는다.
//			if(StringUtils.isEmpty(purchschargerEmail) || Collections.frequency(receiverList, purchschargerEmail) > 0) {
//				log.debug("[MailServiceImpl][insertMailRepitSend]>> purchschargerEmail duplication");
//			} else {
//				// 메일 정보 등록 및 히스토리 등록 공통 메소드
//				this.insertMailComm(param, purchschargerEmail);
//			}
//			
//			receiverList.add(emailEcReceiver); // 세번째 수신자 리스트 업
//		}
//		
//		int result = mailMapper.insertHistory(param);
//		
//		return result;
//	}
	
//	/**
//	 * <pre>
//	 * 처리내용: 메일 정보 등록 및 히스토리 등록 공통 메소드
//	 * </pre>
//	 * @date 2022. 1. 19.
//	 * @author srec0049
//	 * @history 
//	 * ------------------------------------------------
//	 * 변경일					작성자				변경내용
//	 * ------------------------------------------------
//	 * 2022. 1. 19.			srec0049			최초작성
//	 * ------------------------------------------------
//	 * @param param
//	 * @param receiverMail
//	 */
//	public void insertMailComm(MailVO param, String receiverMail) throws Exception {
//		int mailSendCnt = Optional.ofNullable(param.getMailSendCnt()).orElse(0) + 1;
//		/* insert history */
//		param.setMailSendCnt(mailSendCnt); // 발송 개수
//		
//		if(!StringUtils.isEmpty(receiverMail)) {
//			param.setEmail(receiverMail);
//		}
//		
//		/* insert receiver*/
//		mailMapper.insertMail(param);
//		
//		/* OP_EMAIL_SNDNG_HST - MailReceiverNo */
//		int mailReceiverNo = mailMapper.selectMailReceiverNo(param);
//		param.setMailReceiverNo(String.valueOf(mailReceiverNo));
//		
//		/* insert */
//		mailMapper.insertOpMailSendHistory(param);
//		
//	}

//	@Override
//	public int insertMailListSend(List<MailVO> param, Map<String,String> map) throws Exception {
//		
//		MailVO historyParam = new MailVO();
//
//		int mailNoSeq = 0;
//		int mailSendCnt = 0;
//		int mailReceiverNo = 0;
//		ObjectMapper mapper = new ObjectMapper();
//
//
//		/* 이메일 정렬 번호 설정 */
//		mailNoSeq = mailMapper.selectMailNoSeq();
//		/* 이메일 템플릿 설정 */
//		MailVO mailVo = mailMapper.selectMailTmpt(param.get(0).getMailTmptSeq()); // 템플릿 제목, 내용, 발신자 이메일
//		translateContents(mailVo, map); // 이메일 치환데이터 정규식
//
//		for(int i=0; i<param.size(); i++) {
//
//			param.get(i).setMailNo(mailNoSeq);
//			param.get(i).setJobSeCode(mailVo.getJobSeCode());
//			param.get(i).setSntoEmail(mailVo.getSntoEmail());
//			param.get(i).setNsltCn(mailVo.getNsltCn());
//			param.get(i).setNsltSj(mailVo.getNsltSj());
//
//			/*  치환 데이터 본문, 제목에 치환데이터가 있을 시 #{KEY}로 명시 */
//			param.get(i).setMailReceiverReplaceJson(mapper.writeValueAsString(map));
//			mailMapper.insertMail(param.get(i));
//
//			/* OP_EMAIL_SNDNG_HST - MailReceiverNo */
//			mailReceiverNo = mailMapper.selectMailReceiverNo(param.get(i));
//			param.get(i).setMailReceiverNo(String.valueOf(mailReceiverNo));
//
//			/* insert */
//			mailMapper.insertOpMailSendHistory(param.get(i));
//		}
//
//		mailSendCnt = param.size();	//발송 개수
//		historyParam.setMailSendCnt(mailSendCnt);
//
//		historyParam.setMailNo(mailNoSeq);
//		historyParam.setNsltSj(param.get(0).getNsltSj());
//		historyParam.setNsltCn(param.get(0).getNsltCn());
//		historyParam.setNsltSndngDt(param.get(0).getNsltSndngDt());
//		historyParam.setMailTmptSeq(param.get(0).getMailTmptSeq());
//		historyParam.setMailSendUserId(param.get(0).getMailSendUserId());
//		historyParam.setMailSendEmail(param.get(0).getMailSendEmail());
//
//		/* insertHistory */
//		int result = mailMapper.insertHistory(historyParam);
//		return result;
//	}
	
//	// 이메일 치환데이터 정규식
//	// {{}} -> #{}
//	private MailVO translateContents(MailVO mailVO, Map<String, String> map) {	
//		String nsltSj = mailVO.getNsltSj(); 
//		String nsltCn = mailVO.getNsltCn(); 
//		
//		for(Map.Entry<String, String> entry : map.entrySet()) {
//			nsltSj = nsltSj.replace("{{"+ entry.getKey()+"}}", entry.getValue());
//		}
//		
//		for(Map.Entry<String, String> entry : map.entrySet()) {
//			nsltCn = nsltCn.replace("{{"+ entry.getKey()+"}}", entry.getValue());
//		}
//		
//		mailVO.setNsltSj(nsltSj);
//		mailVO.setNsltCn(nsltCn);
//		return mailVO;
//	}
	
//	private MailVO translateContents(MailVO mailVO) {
//		mailVO.setNsltSj(Optional.ofNullable(mailVO.getNsltSj()).map(str -> str.replaceAll("[{][{](.*?)[}][}]", "#{$1}")).orElse(""));
//		mailVO.setNsltCn(Optional.ofNullable(mailVO.getNsltCn()).map(str -> str.replaceAll("[{][{](.*?)[}][}]", "#{$1}")).orElse(""));
//		return mailVO;
//	}

//	@Override
//	public int insertMailSendByReturnMailNo(MailVO param, Map<String,String> map) throws Exception {
//		MailVO historyParam = new MailVO();
//		int mailTmptSeq = param.getMailTmptSeq();
//		int mailNoSeq =  mailMapper.selectMailNoSeq();
//		
//		param = insertMailSendComm(param, map, mailTmptSeq);
//		
//		historyParam.setMailNo(mailNoSeq);
//		historyParam.setNsltSj(param.getNsltSj());
//		historyParam.setNsltCn(param.getNsltCn());
//		historyParam.setNsltSndngDt(param.getNsltSndngDt());
//		historyParam.setMailTmptSeq(param.getMailTmptSeq());
//		historyParam.setMailSendUserId(param.getMailSendUserId());
//		historyParam.setMailSendEmail(param.getMailSendEmail());
//		
//		//테스트
////		int mailNoSeq = mailMapper.selectMailNoSeq();
////		
////		historyParam.setMailNo(mailNoSeq);
////		historyParam.setMailSendCnt(0);
////		historyParam.setNsltSj("test");
////		historyParam.setNsltCn("테스트입니다");
////		historyParam.setMailSendUserId("test");
////		historyParam.setMailSendEmail("test");
////		historyParam.setMailTmptSeq(15);
//		
//		/* insertHistory */
//		mailMapper.insertHistory(historyParam);
//		return mailNoSeq;
//	}
	
	
	
	// AS-IS END
	/////////////////////////////////////////////////////////
	// TO-BE START
	
	
	
	// 이메일 치환데이터 정규식
	// {{}} -> #{}
	private void translateContents(MailVO mailVO, Map<String, String> map) {	
		String nsltSj = mailVO.getNsltSj(); 
		String nsltCn = mailVO.getNsltCn(); 
		
		for(Map.Entry<String, String> entry : map.entrySet()) {
			nsltSj = nsltSj.replace("{{"+ String.valueOf(entry.getKey())+"}}", String.valueOf(entry.getValue()));
		}
		
		for(Map.Entry<String, String> entry : map.entrySet()) {
			nsltCn = nsltCn.replace("{{"+ String.valueOf(entry.getKey())+"}}", String.valueOf(entry.getValue()));
		}
		
		mailVO.setNsltSj(nsltSj);
		mailVO.setNsltCn(nsltCn);
	}
	
	private void translateContents(MailVO mailVO) {
		mailVO.setNsltSj(Optional.ofNullable(mailVO.getNsltSj()).map(str -> str.replaceAll("[{][{](.*?)[}][}]", "#{$1}")).orElse(""));
		mailVO.setNsltCn(Optional.ofNullable(mailVO.getNsltCn()).map(str -> str.replaceAll("[{][{](.*?)[}][}]", "#{$1}")).orElse(""));
	}
	
	/**
	 * <pre>
	 * 처리내용: 이메일 템플릿을 이용하여 치환 데이터(내용 단일)를 생성 및 템플릿 데이터 세팅
	 * </pre>
	 * @date 2022. 12. 19.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 19.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @param map
	 * @throws Exception
	 */
	private void emailTmptDataSetting(MailVO param, Map<String,String> map) throws Exception {
		log.debug(">> [MailServiceImpl][emailTmptDataSetting][내용 단일] mailTmptSeq : " + param.getMailTmptSeq());
		
		ObjectMapper mapper = new ObjectMapper();
		
		/* 이메일 템플릿 설정 */
		MailVO mailVo = mailMapper.selectMailTmpt(param.getMailTmptSeq()); //템플릿 제목, 내용, 발신자 이메일
		translateContents(mailVo, map); // 이메일 치환데이터 정규식
		param.setMailNo(mailMapper.selectMailNoSeq()); // mailNo 시퀀스 조회
		param.setJobSeCode(mailVo.getJobSeCode());
		param.setSntoEmail(mailVo.getSntoEmail());
		param.setNsltCn(mailVo.getNsltCn());
		param.setNsltSj(mailVo.getNsltSj());
		param.setSndngGroupCode(mailVo.getSndngGroupCode()); // 템플릿에 설정된 발송 그룹 코드
		param.setWebmasterTrnsmisAt(mailVo.getWebmasterTrnsmisAt()); // 템플릿에 설정된 웹마스터 전송 여부
		param.setAditChargerTrnsmisAt(mailVo.getAditChargerTrnsmisAt()); // 템플릿에 설정된 추가 담당자 전송 여부
		
		/*  치환 데이터 본문, 제목에 치환데이터가 있을 시 #{KEY}로 명시 */
		param.setMailReceiverReplaceJson(mapper.writeValueAsString(map));
	}
	
	/**
	 * <pre>
	 * 처리내용: 이메일 템플릿을 이용하여 치환 데이터(내용 반복)를 생성 및 템플릿 데이터 세팅
	 * </pre>
	 * @date 2022. 12. 19.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 19.		srec0049			최초작성
	 * 2022. 12. 26.		jdrttl				2개이상의 리스트를 사용할 경우를 위해 수정
	 * ------------------------------------------------
	 * @param param
	 * @param map
	 * @throws Exception
	 */
	private void emailTmptDataSetting(MailVO param, List<List<Map<String,String>>> ListListMap) throws Exception {
		log.debug(">> [MailServiceImpl][emailTmptDataSetting][내용 반복] mailTmptSeq : " + param.getMailTmptSeq());
		
		ObjectMapper mapper = new ObjectMapper();
		
		/* 이메일 템플릿 설정 */
		MailVO mailVo = mailMapper.selectMailTmpt(param.getMailTmptSeq()); //템플릿 제목, 내용, 발신자 이메일
//		translateContents(mailVo); // 이메일 치환데이터 정규식
		translateContents(mailVo, ListListMap.get(0).get(0)); // 이메일 치환데이터 정규식
		param.setMailNo(mailMapper.selectMailNoSeq()); // mailNo 시퀀스 조회
		param.setJobSeCode(mailVo.getJobSeCode());
		param.setSntoEmail(mailVo.getSntoEmail());
		param.setNsltCn(mailVo.getNsltCn());
		param.setNsltSj(mailVo.getNsltSj());
		param.setSndngGroupCode(mailVo.getSndngGroupCode()); // 템플릿에 설정된 발송 그룹 코드
		param.setWebmasterTrnsmisAt(mailVo.getWebmasterTrnsmisAt()); // 템플릿에 설정된 웹마스터 전송 여부
		param.setAditChargerTrnsmisAt(mailVo.getAditChargerTrnsmisAt()); // 템플릿에 설정된 추가 담당자 전송 여부
		
		int mailTmptSeq = param.getMailTmptSeq();
		
		List<String> receiverList = new  ArrayList<String>(); // 수신자 중복 체크용, 20220120 추가
		List<Map<String,String>> listMap = new  ArrayList<Map<String,String>>();
		receiverList.add(param.getEmail()); // 첫번째 수신자 리스트 업
		
		//메일 템플릿 반복 구현, EMAIL_TMPLAT_LOOP 컬럼에 반복되는 템플릿을 넣어두고 사용
		//#%&을 구분자로 사용
		String nsltRes = mailVo.getNsltRe();
		String nsltReConcat = "";
		
		String nsltReArr[] = nsltRes.split("#%&");
		
		Map<String, String> tempMap = new HashMap<>();
		
		int forIdx = 1;
		for(String nsltRe : nsltReArr ) {
			listMap = ListListMap.get(forIdx);
			nsltReConcat = "";
			for(Map<String, String> map : listMap) {
				for (Map.Entry<String, String> entry : map.entrySet()) {
					nsltRe = nsltRe.replace("{{"+entry.getKey()+"}}", entry.getValue());
				}
				nsltReConcat += nsltRe;
			}
			//리스트 수만큼 EMAIL_TMPLAT_LOOP를 만든다 예) EMAIL_TMPLAT_LOOP0, EMAIL_TMPLAT_LOOP1, EMAIL_TMPLAT_LOOP2
			tempMap.put("EMAIL_TMPLAT_LOOP"+(forIdx-1), nsltReConcat);
			forIdx++;
		}
		
		/* 치환 데이터 본문, 제목에 치환데이터가 있을 시 #{KEY}로 명시 */
		param.setMailReceiverReplaceJson(mapper.writeValueAsString(tempMap));
	}
	
	/**
	 * <pre>
	 * 처리내용: 이메일 템플릿을 이용하여 치환 데이터(사용자정의 리스트)를 생성 및 템플릿 데이터 세팅
	 * </pre>
	 * @date 2022. 12. 19.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 19.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @param map
	 * @throws Exception
	 */
	private void emailTmptDataSetting(List<MailVO> param, Map<String,String> map) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		
		/* 이메일 정렬 번호 설정 */
		int mailNoSeq = mailMapper.selectMailNoSeq(); // mailNo 시퀀스 조회
		
		for(int i=0; i<param.size(); i++) {
			log.debug(">> [MailServiceImpl][emailTmptDataSetting][사용자정의 리스트]["+i+"]번째 mailTmptSeq : " + param.get(i).getMailTmptSeq());
			
			/* 이메일 템플릿 설정 */
			MailVO mailVo = mailMapper.selectMailTmpt(param.get(i).getMailTmptSeq()); // 템플릿 제목, 내용, 발신자 이메일
			translateContents(mailVo, map); // 이메일 치환데이터 정규식

			param.get(i).setMailNo(mailNoSeq);
			param.get(i).setJobSeCode(mailVo.getJobSeCode());
			param.get(i).setSntoEmail(mailVo.getSntoEmail());
			param.get(i).setNsltCn(mailVo.getNsltCn());
			param.get(i).setNsltSj(mailVo.getNsltSj());
			param.get(i).setSndngGroupCode(mailVo.getSndngGroupCode()); // 템플릿에 설정된 발송 그룹 코드
			param.get(i).setWebmasterTrnsmisAt(mailVo.getWebmasterTrnsmisAt()); // 템플릿에 설정된 웹마스터 전송 여부
			param.get(i).setAditChargerTrnsmisAt(mailVo.getAditChargerTrnsmisAt()); // 템플릿에 설정된 추가 담당자 전송 여부

			/*  치환 데이터 본문, 제목에 치환데이터가 있을 시 #{KEY}로 명시 */
			param.get(i).setMailReceiverReplaceJson(mapper.writeValueAsString(map));
		}
	}
	
	/**
	 * <pre>
	 * 처리내용: 메시지_이메일 수신자 등록 및 운영_이메일 발송 이력 등록 공통 메소드
	 *   mailReceiverNoSeq 시퀀스 조회
	 *   누적 발송 개수 set, insertHistory[메시지_이메일 발송 이력(MAIL_HISTORY) 등록]에 사용
	 *   receiverMail 파라미터가 있을 시 수신 이메일 변경
	 * </pre>
	 * @date 2022. 1. 19.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 01. 19.			srec0049			최초작성
	 * 2022. 12. 16.			srec0049			mailReceiverNo를 가져오기 위한 selectMailReceiverNo 제거하고 mailReceiverNo 시퀀스를 미리 가져와서 활용한다
	 * ------------------------------------------------
	 * @param param
	 * @param receiverMail
	 */
	private void insertMailComm(MailVO param, String receiverMail) throws Exception {
		int mailSendCnt = Optional.ofNullable(param.getMailSendCnt()).orElse(0) + 1;
		param.setMailSendCnt(mailSendCnt); // 누적 발송 개수, insertMailComm 호출마다 누적
		log.warn(">> mailSendCnt : " + param.getMailSendCnt());
		
		// receiverMail 파라미터가 있을 시 수신 이메일 값 변경, 수신자 이메일 변경해서 발송하기 위함
		if(!StringUtils.isEmpty(receiverMail)) {
			param.setEmail(receiverMail);
		}
		
		// mailReceiverNoSeq 시퀀스 조회하여 param의 mailReceiverNo에 set 
		// 메시지_이메일 수신자(MAIL_RECEIVER)와 운영_이메일 발송 이력(OP_EMAIL_SNDNG_HST)의 수신자 번호(MAIL_RECEIVER_NO) 값으로 사용한다
		param.setMailReceiverNo(mailMapper.selectMailReceiverNoSeq());
		log.warn(">> insertMailComm getMailReceiverNo : " + param.getMailReceiverNo());
		
		// 메일 전송(Receiver), 뉴스레터 수신자(OP_NSLT_RCVER)
		// 메시지_이메일 수신자(MAIL_RECEIVER) 등록
		mailMapper.insertMail(param);
		
		// 운영 - 메일 히스토리 저장
		// 운영_이메일 발송 이력(OP_EMAIL_SNDNG_HST) 등록
		mailMapper.insertOpMailSendHistory(param);
		
	}
	
	/**
	 * <pre>
	 * 처리내용: 추가 메일 대상자와 함께 메시지_이메일 수신자 등록 및 운영_이메일 발송 이력 등록
	 *   수신자 중복 체크, 중복되면 보내지 않는다
	 *   예외 발송 옵션 여부(excpSndngOptnAt)가 Y이면 메일 수신자, 웹마스터, 추가 담당자는 보내지 않는다
	 *   예외 발송 옵션 여부(excpSndngOptnAt)가 N이면 내부사용자는 보내지 않는다
	 *   예외 발송 옵션 여부(excpSndngOptnAt)가 null이거나 값이 존재하지 않으면 메일 수신자, 웹마스터, 추가 담당자, 내부사용자 모두 보낸다.
	 *   추가 메일 대상자
	 *     - 웹마스터
	 *     - 추가담당자
	 *     - 내부사용자
	 * </pre>
	 * @date 2022. 12. 23.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 12. 23.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param param
	 * @throws Exception
	 */
	private void insertMailSendComm(MailVO param) throws Exception {
		List<String> receiverList = new  ArrayList<String>(); // 수신자 중복 체크용, 20220120 추가
		
		log.debug(">> param.getSpclSndngOptnAt() : " + param.getExcpSndngOptnAt());
		
		String selectMailReceiveAt = "";
		selectMailReceiveAt = mailMapper.selectMailReceiveAt(param);
		
		// 예외 발송 옵션 여부가 Y가 아닐때 발송, Y이면 메일 수신자, 웹마스터, 추가 담당자는 보내지 않는다
		if(!StringUtils.equals(param.getExcpSndngOptnAt(), "Y")) {
			// 메일 수신자, 메시지_이메일 수신자 등록 및 운영_이메일 발송 이력 등록 공통 메소드
			if(param.getEmail() == null || StringUtils.isEmpty(param.getEmail())) {
				log.warn(">> param.getEmail() is null, pass");
			} else {
				// 멤버 권한에 따른 메시지 수신 여부
				// MEBER_SE_CODE : 참조 1 : N 이면 Mail보내지 않는다 --2024.02 차량담당자 추가로 인한 메일, 메시지 수신권한 추가
				if(selectMailReceiveAt.equals("N")){
					log.warn(">> param.getEmail() is null, pass");
				}else{
					insertMailComm(param, null);
					receiverList.add(param.getEmail()); // 첫번째 수신자 리스트 업
				}
			}
			
			// 해당 템플릿의 경우 추가로 메일(webmasters)을 발송한다. 20220106 추가
			// 회원가입완료(기업) : 27, 회원탈퇴완료(마스터) : 7, 회원탈퇴완료(기업) : 42, 주문완료 : 15, 배차완료 : 17, 배송완료 : 19
	//		if(param.getMailTmptSeq() == 7 || param.getMailTmptSeq() == 15 || param.getMailTmptSeq() == 17 || param.getMailTmptSeq() == 19 || param.getMailTmptSeq() == 27
	//				|| param.getMailTmptSeq() == 42 || param.getMailTmptSeq() == 47 || param.getMailTmptSeq() == 48 || param.getMailTmptSeq() == 49) {
			
			log.debug(">> param.getWebmasterTrnsmisAt() : " + param.getWebmasterTrnsmisAt());
			// 웹마스터 전송 여부에 따라 추가 수신자가 있을 경우 메일(webmasters)을 한번 더 발송한다. 20220106 추가
			if(StringUtils.equals(param.getWebmasterTrnsmisAt(), "Y")) {
				// 추가 수신자가 없거나 중복되면 보내지 않는다.
				if(StringUtils.isEmpty(emailEcReceiver) || Collections.frequency(receiverList, emailEcReceiver) > 0) {
					log.debug("[MailServiceImpl][insertMailSendComm]>> emailEcReceiver duplication");
				} else {
					// 메시지_이메일 수신자 등록 및 운영_이메일 발송 이력 등록 공통 메소드
					insertMailComm(param, emailEcReceiver);
					
					receiverList.add(emailEcReceiver); // 두번째 수신자 리스트 업
				}
			}
			
			log.debug(">> param.getAditChargerTrnsmisAt() : " + param.getAditChargerTrnsmisAt());
			// 추가 담당자 전송 여부에 따라 추가 담당자 이메일이 있을 경우 메일을 한번 더 보낸다. 20220120 추가
			if(StringUtils.equals(param.getAditChargerTrnsmisAt(), "Y")) {
				String purchschargerEmail = mailMapper.selectPurchschargerEmail(param); // 회원_업체 정보 기본 테이블의 구매담당자 이메일 조회
				log.debug(">> purchschargerEmail : " + purchschargerEmail);
				
				// 추가 수신자가 없거나 중복되면 보내지 않는다.
				if(StringUtils.isEmpty(purchschargerEmail) || Collections.frequency(receiverList, purchschargerEmail) > 0) {
					log.debug("[MailServiceImpl][insertMailSendComm]>> purchschargerEmail duplication");
				} else {
					// 메시지_이메일 수신자 등록 및 운영_이메일 발송 이력 등록 공통 메소드
					insertMailComm(param, purchschargerEmail);
					
					receiverList.add(purchschargerEmail); // 세번째 수신자 리스트 업
				}
			}
		}
		
		// 예외 발송 옵션 여부가 N이 아닐때 발송, N이면 내부사용자는 보내지 않는다
		if(!StringUtils.equals(param.getExcpSndngOptnAt(), "N")) {
			// 발송그룹코드가 있을 경우 해당 내부사용자들에게 메일을 한번 더 보낸다. 20221219 추가
			if(StringUtils.isEmpty(param.getSndngGroupCode()) || StringUtils.equals(param.getSndngGroupCode(), "null")) {
				log.debug(">> [MailServiceImpl][insertMailSendComm] 내부사용자 메일 발송 사용안함");
			} else {
				List<String> innerUserEmailList = mailMapper.selectMailReceiverList(param); // 공통_SMS 발송 그룹 기본 테이블의 발송그룹코드에 해당하는 내부사용자 회사 이메일 리스트 조회
				if(!CollectionUtils.isEmpty(innerUserEmailList)) {
					for(String innerUserEmail : innerUserEmailList) {
						log.debug(">> [MailServiceImpl][insertMailSendComm] innerUserEmail : " + innerUserEmail);
						
						// 추가 수신자가 없거나 중복되면 보내지 않는다.
						if(StringUtils.isEmpty(innerUserEmail) || Collections.frequency(receiverList, innerUserEmail) > 0) {
							log.debug("[MailServiceImpl][insertMailSendComm]>> innerUserEmail duplication");
						} else {
							// 메시지_이메일 수신자 등록 및 운영_이메일 발송 이력 등록 공통 메소드
							insertMailComm(param, innerUserEmail);
							
							receiverList.add(innerUserEmail); // 네번째 수신자 리스트 업
						}
					}
				}
			}
		}
	}
	
	/**
	 * 단건 이메일 발송
	 */
	@Override
	public int insertMailSend(MailVO param, Map<String,String> map) throws Exception {
		log.debug(">> [MailServiceImpl][insertMailSend] in");
		
		// 발송 함수 호출 시 총 메일 발송 건수는 초기화한다.
		param.setMailSendCnt(0); // 총 메일 발송 건수
		
		// 이메일 템플릿을 이용하여 치환 데이터(내용 단일)를 생성 및 템플릿 데이터 세팅
		emailTmptDataSetting(param, map);
		
		// 추가 메일 대상자와 함께 메시지_이메일 수신자 등록 및 운영_이메일 발송 이력 등록
		insertMailSendComm(param); // return param 제거, mailTmptSeq 파라미터 제거
		
		// 메일 전송(History), 뉴스레터 발신자(OP_NSLT_SNDNG)
		// 메시지_이메일 발송 이력(MAIL_HISTORY) 등록
		int result = mailMapper.insertHistory(param);
		
		return result;
	}
	
	/**
	 * 이메일(내용 반복) 단건 발송
	 */
	@Override
	public int insertMailRepitSend(MailVO param, List<List<Map<String,String>>> ListListMap) throws Exception {
		log.debug(">> [MailServiceImpl][insertMailRepitSend] in");
		
		// 발송 함수 호출 시 총 메일 발송 건수는 초기화한다.
		param.setMailSendCnt(0); // 총 메일 발송 건수
		
		// 이메일 템플릿을 이용하여 치환 데이터(내용 반복)를 생성 및 템플릿 데이터 세팅
		emailTmptDataSetting(param, ListListMap);
		
		// 추가 메일 대상자와 함께 메시지_이메일 수신자 등록 및 운영_이메일 발송 이력 등록
		insertMailSendComm(param); // return param 제거, mailTmptSeq 파라미터 제거
		
		// 메일 전송(History), 뉴스레터 발신자(OP_NSLT_SNDNG)
		// 메시지_이메일 발송 이력(MAIL_HISTORY) 등록
		int result = mailMapper.insertHistory(param);
		
		return result;
	}
	
	/**
	 * 사용자정의 리스트만큼 이메일 일괄 발송
	 */
	@Override
	public int insertMailListSend(List<MailVO> param, Map<String,String> map) throws Exception {
		log.debug(">> [MailServiceImpl][insertMailListSend] in");
		
		// 이메일 템플릿을 이용하여 치환 데이터(사용자정의 리스트)를 생성 및 템플릿 데이터 세팅
		emailTmptDataSetting(param, map);
		
		for(int i=0; i<param.size(); i++) {
			// 추가 메일 대상자와 함께 메시지_이메일 수신자 등록 및 운영_이메일 발송 이력 등록
			insertMailSendComm(param.get(i)); // return param 제거, mailTmptSeq 파라미터 제거
		}
		
		// 첫번째 param 내용으로 히스토리 테이블에 등록???
		MailVO historyParam = new MailVO();
		historyParam.setMailSendCnt(param.get(0).getMailSendCnt());
		historyParam.setMailNo(param.get(0).getMailNo());
		historyParam.setNsltSj(param.get(0).getNsltSj());
		historyParam.setNsltCn(param.get(0).getNsltCn());
		historyParam.setNsltSndngDt(param.get(0).getNsltSndngDt());
		historyParam.setMailTmptSeq(param.get(0).getMailTmptSeq());
		historyParam.setMailSendUserId(param.get(0).getMailSendUserId());
		historyParam.setMailSendEmail(param.get(0).getMailSendEmail());

		// 메일 전송(History), 뉴스레터 발신자(OP_NSLT_SNDNG)
		// 메시지_이메일 발송 이력(MAIL_HISTORY) 등록
		int result = mailMapper.insertHistory(historyParam);
		return result;
	}
	
	/**
	 * 이메일 리스트 발송 후 mailNo 리턴
	 */
	@Override
	public int insertMailSendByReturnMailNo(MailVO param, Map<String,String> map) throws Exception {
		log.debug(">> [MailServiceImpl][insertMailSendByReturnMailNo] in");

		// 발송 함수 호출 시 총 메일 발송 건수는 초기화한다.
		param.setMailSendCnt(0); // 총 메일 발송 건수
		
		// 이메일 템플릿을 이용하여 치환 데이터(내용 단일)를 생성 및 템플릿 데이터 세팅
		emailTmptDataSetting(param, map);
		
		// 추가 메일 대상자와 함께 메시지_이메일 수신자 등록 및 운영_이메일 발송 이력 등록
		insertMailSendComm(param); // return param 제거, mailTmptSeq 파라미터 제거
		
		// 메일 전송(History), 뉴스레터 발신자(OP_NSLT_SNDNG)
		// 메시지_이메일 발송 이력(MAIL_HISTORY) 등록
		mailMapper.insertHistory(param);
		
		return param.getMailNo();
	}
}
