package com.sorincorp.comm.bsnInfo.service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.bsnInfo.mapper.BsnInfoMapper;
import com.sorincorp.comm.bsnInfo.model.BsnDlvyManageVO;
import com.sorincorp.comm.bsnInfo.model.BsnInfoDetailVO;
import com.sorincorp.comm.bsnInfo.model.BsnInfoVO;
import com.sorincorp.comm.bsnInfo.model.BsnManageVO;
import com.sorincorp.comm.bsnInfo.model.CdtlnInfoVO;
import com.sorincorp.comm.bsnInfo.model.HvofTimeVO;
import com.sorincorp.comm.bsnInfo.model.LmeClndrVO;
import com.sorincorp.comm.bsnInfo.model.RestTermVO;
import com.sorincorp.comm.bsnInfo.model.RestdeFxLmeVO;
import com.sorincorp.comm.bsnInfo.model.RestdeVO;
import com.sorincorp.comm.bsnInfo.model.RltmEndTimeVO;
import com.sorincorp.comm.bsnInfo.model.SidecarVO;
import com.sorincorp.comm.bsnInfo.model.WrtmStdrAmoutInfoVO;
import com.sorincorp.comm.invntry.service.InvntrySttusServiceImpl;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.BsnInfoUtil;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BsnInfoServiceImpl implements BsnInfoService {
	@Autowired
	BsnInfoMapper bsnInfoMapper;

	@Override
	@SuppressWarnings("unchecked")
	@Cacheable(value = "BsnInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public BsnInfoVO getBsnInfo(String occrrncDe) throws Exception {

		BsnInfoVO returnBsnInfoVo = new BsnInfoVO();
		returnBsnInfoVo.setApplcDe(occrrncDe);

		// LME 휴일
		LmeClndrVO resultLmeClndr = bsnInfoMapper.getLmeClndrInfo(occrrncDe);

		// 이벤트 휴일
		int resultEventRestdeManage = bsnInfoMapper.getEventRestdeManageInfo(occrrncDe);

		// 휴무시간
		HvofTimeVO resultHovfTimeManage = bsnInfoMapper.getHvofTimeManageInfo(occrrncDe);

		// 상품 영업 관리
		BsnManageVO resultBsnManage = bsnInfoMapper.getBsnManageInfo(occrrncDe);
		if(resultBsnManage != null) {
			returnBsnInfoVo.setRltmBsnAt(resultBsnManage.getRltmBsnAt());
			returnBsnInfoVo.setHghnetprcBsnAt(resultBsnManage.getHghnetprcBsnAt());
			returnBsnInfoVo.setRltmBeginTime(resultBsnManage.getRltmBeginTime());
			returnBsnInfoVo.setRltmEndTime(resultBsnManage.getRltmEndTime());
			returnBsnInfoVo.setHghnetprcBeginTime(resultBsnManage.getHghnetprcBeginTime());
			returnBsnInfoVo.setHghnetprcEndTime(resultBsnManage.getHghnetprcEndTime());
			returnBsnInfoVo.setLgistSunBsnAt(resultBsnManage.getLgistSunBsnAt());
			returnBsnInfoVo.setLgistMonBsnAt(resultBsnManage.getLgistMonBsnAt());
			returnBsnInfoVo.setLgistTuesBsnAt(resultBsnManage.getLgistTuesBsnAt());
			returnBsnInfoVo.setLgistWedBsnAt(resultBsnManage.getLgistWedBsnAt());
			returnBsnInfoVo.setLgistFriBsnAt(resultBsnManage.getLgistFriBsnAt());
			returnBsnInfoVo.setLgistSatBsnAt(resultBsnManage.getLgistSatBsnAt());
			//returnBsnInfoVo.setLmeMdatCffcntAmount(resultBsnManage.getLmeMdatCffcntAmount());
			//returnBsnInfoVo.setEhgtMdatCffcntAmount(resultBsnManage.getEhgtMdatCffcntAmount());
		}


		// LME 휴일 비교
		if((resultLmeClndr != null && "N".equals(resultLmeClndr.getLmeHolidayAt())) || resultLmeClndr == null) {

			// 이벤트 휴일 비교
			if(resultEventRestdeManage <= 0) {

				//휴무시간 관리
				if(resultHovfTimeManage == null) {

					//상품 영업 관리
					if(resultBsnManage != null) {
						String holidayYn = "N";
						switch (DateUtil.getDate(occrrncDe)) {
						case 1:
							holidayYn = resultBsnManage.getSiteSunBsnAt();
							break;
						case 2:
							holidayYn = resultBsnManage.getSiteMonBsnAt();
							break;
						case 3:
							holidayYn = resultBsnManage.getSiteThurBsnAt();
							break;
						case 4:
							holidayYn = resultBsnManage.getSiteWedBsnAt();
							break;
						case 5:
							holidayYn = resultBsnManage.getSiteThurBsnAt();
							break;
						case 6:
							holidayYn = resultBsnManage.getSiteFriBsnAt();
							break;
						case 7:
							holidayYn = resultBsnManage.getSiteSatBsnAt();
							break;
						default:
							holidayYn = "N";
							break;
						}
						if("N".equals(holidayYn)) {
							returnBsnInfoVo.setHolidayAt("Y");
						} else if("Y".equals(holidayYn)) {
							returnBsnInfoVo.setHolidayAt("N");
						}
					} else {//상품 영업 관리
						returnBsnInfoVo.setHolidayAt("N");
					}

				} else { //휴무시간 관리
					returnBsnInfoVo.setHolidayAt("Y");
					returnBsnInfoVo.setHolidayBeginTime(resultHovfTimeManage.getApplcBeginTime());
					returnBsnInfoVo.setHolidayEndTime(resultHovfTimeManage.getApplcEndTime());
				}

			} else { // 이벤트 휴일 비교
				returnBsnInfoVo.setHolidayAt("Y");
				returnBsnInfoVo.setHolidayBeginTime("000000");
				returnBsnInfoVo.setHolidayEndTime("235959");
			}

		} else { //LME 휴일 비교
			returnBsnInfoVo.setHolidayAt("Y");
			returnBsnInfoVo.setHolidayBeginTime("000000");
			returnBsnInfoVo.setHolidayEndTime("235959");
		}

		return returnBsnInfoVo;
	}


	@Override
	@SuppressWarnings("unchecked")
	@Cacheable(value = "BsnInfo", keyGenerator = "prefixMethodNameKeyGenerator")
	public BsnInfoDetailVO getBsnInfoDetail(String occrrncDe, String metalCode) throws Exception {
		BsnInfoDetailVO returnBsnInfoDetailVo = new BsnInfoDetailVO();

		if( (occrrncDe == null || "".equals(occrrncDe)) && (metalCode == null || "".equals(metalCode))) {
			return null;
		}

		returnBsnInfoDetailVo.setApplcDe(occrrncDe);
		returnBsnInfoDetailVo.setMetalCode(metalCode);

		// 영업 배송 관리
		BsnDlvyManageVO returnBsnDlvy = bsnInfoMapper.getBsnDlvyManageInfo(occrrncDe, metalCode);
		returnBsnInfoDetailVo.setManatmbDlivyRequstBeginDe(returnBsnDlvy.getManatmbDlivyRequstBeginDe());
		returnBsnInfoDetailVo.setManatmbDlivyRequstEndDe(returnBsnDlvy.getManatmbDlivyRequstEndDe());
		returnBsnInfoDetailVo.setManatmbTodayDlivyClosTime(returnBsnDlvy.getManatmbTodayDlivyClosTime());
		returnBsnInfoDetailVo.setSorinDlivyRequstBeginDe(returnBsnDlvy.getSorinDlivyRequstBeginDe());
		returnBsnInfoDetailVo.setSorinDlivyRequstEndDe(returnBsnDlvy.getSorinDlivyRequstEndDe());
		returnBsnInfoDetailVo.setSorinTodayDlivyClosTime(returnBsnDlvy.getSorinTodayDlivyClosTime());

		// 사이드카 관리
		SidecarVO returnSideCar = bsnInfoMapper.getSidecarManageInfo(occrrncDe, metalCode);
		returnBsnInfoDetailVo.setMotnAt(returnSideCar.getMotnAt());
		returnBsnInfoDetailVo.setBfrtVersusRate(returnSideCar.getBfrtVersusRate());
		returnBsnInfoDetailVo.setCntncTime(returnSideCar.getCntncTime());
		returnBsnInfoDetailVo.setPcIndictImprtyTime(returnSideCar.getPcIndictImprtyTime());

		return returnBsnInfoDetailVo;
	}

	@Override
	public boolean isRestDeLive() throws Exception {
		List<RestTermVO> restTermListVO = getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");
		
		for (int i = 0; i < restTermListVO.size(); i++) {
			if ("N".equals(restTermListVO.get(i).getRestdeAt()) && "7".equals(restTermListVO.get(i).getMetalCode())) {
				return true;
			}
		}
		
		return false;
	}


	@Override
	public boolean isRestDeFixed() throws Exception {
		List<RestTermVO> restTermListVO = getRestTermInfoBySleMthd(DateUtil.getNowDate(), "02");
		
		for (int i = 0; i < restTermListVO.size(); i++) {
			if ("N".equals(restTermListVO.get(i).getRestdeAt()) && "1".equals(restTermListVO.get(i).getMetalCode())) {
				return true;
			}
		}

		return false;
	}


	@Override
	public List<RestTermVO> getRestTermInfo(String nowDate) throws Exception {
		return bsnInfoMapper.getRestTermInfo(nowDate, null);
	}
	
	@Override
	public List<RestTermVO> getRestTermInfoBySleMthd(String nowDate, String sleMthdCode) throws Exception {
		return bsnInfoMapper.getRestTermInfo(nowDate, sleMthdCode);
	}

	@Override
	public RestdeFxLmeVO getRestdeFxLmeInfo(String appleDe) throws Exception {
		// TODO Auto-generated method stub
		return bsnInfoMapper.getRestdeFxLmeInfo(appleDe);
	}


	@Override
	public RestdeVO getRestdeInfoWithoutHvofTime(String nowDate) throws Exception {
		return bsnInfoMapper.getRestdeInfoWithoutHvofTime(nowDate);
	}


	@Override
	public CdtlnInfoVO getCdtlnInfo(String occrrncDe) throws Exception {
		// 여신 관리
		CdtlnInfoVO resultCdtlnManage = bsnInfoMapper.getCdtlnInfo(occrrncDe);
		return resultCdtlnManage;
	}


	@Override
	public WrtmStdrAmoutInfoVO getWrtmStdrAmoutMangeInfo(String occrrncDe, String metalCode) throws Exception {
		WrtmStdrAmoutInfoVO vo = bsnInfoMapper.getItWrtmStdrAmoutMangeBas(occrrncDe, metalCode);
		vo.setGridList(bsnInfoMapper.getItWrtmStdrAmoutMangeDtlList(vo));
		return vo;
	}


	/*
	  1 휴일 여부가 "N"
	  2. 금속 코드가 일치
	  3. 운영 상태코드가 (20, 21, 23) 값 중 하나에 속하는지 확인
	  1,2,3 모든 조건을 만족하는 첫번 째 요소를 찾는다.
	  값이 존재하면 true 반환, 존재하지 않으면 false 반환
	 */
	@Override
	public boolean isRestDeByMetal(String metalCode, String sleMthdCode) throws Exception {
		List<RestTermVO> restTermListVO = getRestTermInfoBySleMthd(DateUtil.getNowDate(), sleMthdCode);

		return Optional.ofNullable(restTermListVO)
						.orElse(Collections.emptyList())
						.stream()
						.filter(restTerm -> "N".equals(restTerm.getRestdeAt())
								&& metalCode.equals(restTerm.getMetalCode())
								&& BsnInfoUtil.OperateSttusCode.OPERATE_AT.getValues().contains(restTerm.getOpenTimeCode()))
						.findFirst()
						.isPresent();
	}


	@Override
	public RltmEndTimeVO getRltmEndTime() throws Exception {
		return bsnInfoMapper.selectRltmEndTime();
	}
	
	@Override
	public List<RltmEndTimeVO> getLiveOperTimeAll() throws Exception {
		return bsnInfoMapper.selectLiveOperTimeAll();
	}
	
	/**
	 * 최근 휴무시간 조회
	 * @return
	 * @exception Exception
	 */
	@Override
	public RestdeVO getTodayTodayHvofTime() throws Exception {
		return bsnInfoMapper.getTodayTodayHvofTime();
	}
	
}
