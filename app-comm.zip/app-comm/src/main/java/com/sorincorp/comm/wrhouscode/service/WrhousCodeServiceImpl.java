package com.sorincorp.comm.wrhouscode.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.comm.constants.CommonConstants;
import com.sorincorp.comm.util.RedisUtil;
import com.sorincorp.comm.wrhouscode.mapper.WrhousCodeMapper;
import com.sorincorp.comm.wrhouscode.model.WrhousCodeVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class WrhousCodeServiceImpl implements WrhousCodeService{

	@Autowired
	private WrhousCodeMapper wrhousCodeMapper;

	@Autowired
	private RedisUtil redisUtil;


	public void initWrhousCode() throws Exception{
		List<WrhousCodeVO> wrhousCodeList = wrhousCodeMapper.getWrhousCode();
		redisUtil.setData("wrhousCode", wrhousCodeList);
	}

	@SuppressWarnings("unchecked")
	public List<WrhousCodeVO> getWrhousCode() throws Exception{

		List<WrhousCodeVO> wrhousCodeList = (List<WrhousCodeVO>)redisUtil.getData("wrhousCode");

		if(wrhousCodeList == null) {
			initWrhousCode();
			wrhousCodeList = (List<WrhousCodeVO>)redisUtil.getData("wrhousCode");
		}


		return wrhousCodeList;
	}

	@SuppressWarnings("unchecked")
	public List<WrhousCodeVO> getDetailWrhousCode(String lclsfDlivyDstrctCode, String mlsfcDlivyDstrctCode) throws Exception{

		List<WrhousCodeVO> detailWrhousCodeList = new ArrayList<WrhousCodeVO>();

		List<WrhousCodeVO> wrhousCodeList = (List<WrhousCodeVO>)redisUtil.getData("wrhousCode");

		if(wrhousCodeList == null) {
			initWrhousCode();
			wrhousCodeList = (List<WrhousCodeVO>)redisUtil.getData("wrhousCode");
		}

		for(WrhousCodeVO code : wrhousCodeList) {

			if(!StringUtils.isEmpty(lclsfDlivyDstrctCode) && StringUtils.isEmpty(mlsfcDlivyDstrctCode)) {
				if(StringUtils.equals(code.getLclsfDlivyDstrctCode(), lclsfDlivyDstrctCode)) {
					detailWrhousCodeList.add(code);
				}
			}

			if(!StringUtils.isEmpty(lclsfDlivyDstrctCode) && !StringUtils.isEmpty(mlsfcDlivyDstrctCode)) {
				if(StringUtils.equals(code.getLclsfDlivyDstrctCode(), lclsfDlivyDstrctCode) &&
						StringUtils.equals(code.getMlsfcDlivyDstrctCode(), mlsfcDlivyDstrctCode)) {
					detailWrhousCodeList.add(code);

				}
			}

		}


		return detailWrhousCodeList;
	}

	@SuppressWarnings("unchecked")
	public String getWrhousCodeTaglibStr(List<WrhousCodeVO> wrhousCodeList) throws Exception{

		StringBuilder codeTaglibStr = new StringBuilder(StringUtils.EMPTY);

		for(WrhousCodeVO code : wrhousCodeList) {

			codeTaglibStr.append(code.getWrhousCode());
			codeTaglibStr.append(CommonConstants.COLONE);
			codeTaglibStr.append(code.getWrhousNm());
			codeTaglibStr.append(CommonConstants.SEMI_COLONE);

		}

		return codeTaglibStr.toString();

	}






}
