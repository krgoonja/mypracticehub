package com.sorincorp.comm.itemprice.model;

import java.util.List;

import com.sorincorp.comm.model.CommonVO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ItemPriceCommVO extends CommonVO {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3905245147801383801L;
	
	private List<String> removeMetalCodes;
	
	private String entrpsNo;
}
