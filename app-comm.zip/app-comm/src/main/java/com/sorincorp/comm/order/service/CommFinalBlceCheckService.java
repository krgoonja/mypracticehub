package com.sorincorp.comm.order.service;

import com.sorincorp.comm.order.model.CommBlceInfoVO;

/**
 * CommFinalBlceCheckService.java
 * 결제 수단 별 최종 잔액 체크 Service 인터페이스
 * @version
 * @since 2023. 5. 11.
 * @author srec0066
 */
public interface CommFinalBlceCheckService {

	/**
	 * <pre>
	 * 처리내용: 특정업체의 해당 결제수단에 따른
	 * 		   1.거래 가능 여부(boolean)
	 * 		   2.최종 잔액 정보를 리턴
	 * 		   조회되는 잔액 정보는 [주문] [상환/출금]의 경우에 따라 달라짐
	 *
	 * 		  [주문]
	 * 			   한도 잔액 조회   : 전자상거래보증 or 케이지크레딧
	 * 			   이월렛 잔액 조회  : 이월렛(증거금 포함)
	 *
	 * 		  [상환/출금]
	 * 			   이월렛 잔액 조회  : 전자상거래보증 or 케이지크레딧 or 이월렛(증거금 포함)
	 * </pre>
	 * @date 2023. 5. 11.
	 * @author srec0066
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 5. 11.			srec0066			최초작성
	 * ------------------------------------------------
	 * @param entrpsNo
	 * @param setleMthdCode
	 * @return
	 * @throws Exception
	 */
	public CommBlceInfoVO selectFinalBlceInfoBySetleMn(String entrpsNo, String setleMthdCode, String orderEventAt, long delngExpectAmount) throws Exception;

}
