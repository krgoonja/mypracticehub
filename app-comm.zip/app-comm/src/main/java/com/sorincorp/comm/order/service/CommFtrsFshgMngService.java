package com.sorincorp.comm.order.service;

import java.math.BigDecimal;
import java.util.List;

import com.sorincorp.comm.order.model.CommFtrsFshgMngVO;

/**
 * CommFtrsFshgMngService.java
 * 선물 선물환 관리 Service 인터페이스
 *
 * @version
 * @since 2022. 6. 7.
 * @author srec0049
 */
public interface CommFtrsFshgMngService {

	/**
	 * <pre>
	 * 처리내용: 오늘 날짜 기준의 적용 일자에 해당하는 상품_선물 선물환 관리 상세 리스트를 조회한다.
	 * </pre>
	 * @date 2022. 6. 16.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 16.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param postnCode
	 * @return
	 * @throws Exception
	 */
	public List<CommFtrsFshgMngVO> commFtrsFshgManageDtlListByToday(String postnCode) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 금속 코드, 포지션 코드를 조건으로 필터하고, 3개월 LME 가격(3M 가격)으로 SKIP 대상인지 판별 후 CommFtrsFshgMngVO 값을 리턴한다.
	 * </pre>
	 * @date 2022. 6. 9.
	 * @author srec0049
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 6. 9.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param metalCode
	 * @param postnCode
	 * @param threemonthLmePc
	 * @return
	 * @throws Exception
	 */
	public CommFtrsFshgMngVO getFtrsFshgMngRetVo(String metalCode, String postnCode, BigDecimal threemonthLmePc) throws Exception;
}
