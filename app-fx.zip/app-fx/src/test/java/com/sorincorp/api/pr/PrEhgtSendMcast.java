package com.sorincorp.api.pr;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

import com.digitide.xcube.XCPBMsg;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;

public class PrEhgtSendMcast extends Thread{
	int sequence;
	public static void main(String args[]) throws Exception {
		PrEhgtSendMcast mCaster = new PrEhgtSendMcast();
		mCaster.start();
	}


	public void run() {

		while(true) {
			try {
				sendData();
				sleep(5000L);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public void sendData(){
		try {
			sequence++;

			/* Java Multicast Send Example */
			String msgType = "U";
			String msgSvc =  "FR";
			String msgCode = "DZZSPTUSD/KRW";

			XCPBMsg pbMsg = new XCPBMsg();

			/* pbMsg Set Header */
			pbMsg.type(msgType);
			pbMsg.svc(msgSvc);
			pbMsg.seq1(0);
			pbMsg.seq2(0);
			pbMsg.code(msgCode);

			//String sampleData1 = "DZZSPTUSD/KRW";
			// key ��
			String sampleData1 = "DZZSPTUSD/TST";
			String sampleData2 = DateUtil.getNowDate();
			String sampleData3 = DateUtil.calDate("HHmmss");
			//String sampleData3 = DateUtil.calDate("113815");
			String sampleData4 = StringUtil.padValue(String.valueOf(sequence), "0", 9, true);

			String tmp = String.format("%.4f", Math.random() + 1080);
			
			String sampleData5 = tmp;
			String sampleData6 = "2";

			String sampleData7 = tmp;
			String sampleData8 = tmp;
			String sampleData9 = tmp;
			String sampleData10 = tmp;

			/* pbMsg Set Body */
			pbMsg.add_value(sampleData1, sampleData1.length());
			pbMsg.add_value(sampleData2, sampleData2.length());
			pbMsg.add_value(sampleData3, sampleData3.length());
			pbMsg.add_value(sampleData4, sampleData4.length());
			pbMsg.add_value(sampleData5, sampleData5.length());
			pbMsg.add_value(sampleData6, sampleData6.length());
			pbMsg.add_value(sampleData7, sampleData7.length());
			pbMsg.add_value(sampleData8, sampleData8.length());
			pbMsg.add_value(sampleData9, sampleData9.length());
			pbMsg.add_value(sampleData10, sampleData10.length());


			pbMsg.dump("########## Sample Chart Send DATA ###################");

			/* Java Multicast Send Example */
			String mcastIp = "224.10.10.80";
			int mcastPort = 9811;

			MulticastSocket socket = new MulticastSocket();
			InetAddress address = InetAddress.getByName(mcastIp);
			socket.joinGroup(address);
			DatagramPacket packet = new DatagramPacket(pbMsg.data().getBytes(), pbMsg.length(), address, mcastPort);

			socket.send(packet);
		}catch(Exception e) {
			e.printStackTrace();
		}

	}
}