package com.sorincorp.api;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class RequestMappingUrlsTests {
	@Autowired
	private RequestMappingHandlerMapping handlerMapping;

	@Test
	public void getRequestMappingUrls() {
		log.info("###############################################");
		Map<RequestMappingInfo, HandlerMethod> mappings = handlerMapping.getHandlerMethods();
		Set<RequestMappingInfo> keys = mappings.keySet();
		Iterator<RequestMappingInfo> iterator = keys.iterator();

		List<String> urlList = new ArrayList<String>();
		while (iterator.hasNext()) {
			RequestMappingInfo key = iterator.next();
			HandlerMethod value = mappings.get(key);
			urlList.add(key.getPatternsCondition().toString());

			//logger.info(key.getPatternsCondition() + "[" + key.getMethodsCondition() + "] : " + value);
			log.info("\t" + "fx" + "\t" +  key.getPatternsCondition()+"");
		}
		log.info("###############################################");
	}

}
