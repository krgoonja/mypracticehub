package com.sorincorp.api.hopeAlarm.scheduler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.codehaus.plexus.util.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.sorincorp.api.hopeAlarm.model.HopeAlarmVO;
import com.sorincorp.api.hopeAlarm.service.HopeAlarmService;
import com.sorincorp.comm.bsnInfo.model.RestTermVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.message.model.AppPushQueueVO;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.CryptoUtil;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@EnableScheduling
public class HopeAlramScheduler {
	@Autowired
	HopeAlarmService hopeAlramService;
	
	@Autowired
	SMSService smsService;
	
	@Autowired
	BsnInfoService bsnInfoService;
	
	@Autowired
	private RedisPubSubService redisPubSubService;
	
	@Value("${redisPubsub.uri.wishAlram}")
	private String wishAlramUri;
	
	@Value("${appPush.domain}")
	private String hopeAlarmDomain;	
	
	@Value("${metalCode.list}")
	private List<String> metalCodeList;	
	
	/*
	 * 1. 금속별 (7개 고정) 
	 *    : 고정가, 실시간 각 금속별 계산법 다름
	 *    => 배치가 7개 (현재는 2개)
	 * 
	 * */
	
	
	//알루미늄 희망가 알람 배치
	@Scheduled(cron = "0 0/1 * * * *")
	public void HopeAlramAlScheduler() {

		try {
			List<RestTermVO> restTermListVO = bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");
			
			String nowData = DateUtil.calDate("yyyyMMddHHmmss");
			
			for(RestTermVO restTermVO : restTermListVO) {
				//희망가 알림 리스트 조회
				HopeAlarmVO vo = new HopeAlarmVO();
				vo.setNowData(nowData);
				vo.setMetalCode(restTermVO.getMetalCode());
				
				// 희망가 알림 등록은 하였으나, 발송기본 테이블에 없는 데이터 INSERT
				hopeAlramService.insertHopePcNtcnSndngBasList(vo);
				
				List<HopeAlarmVO> list = hopeAlramService.getHopePcNtcnSndngBas(vo);
				
				List<HopeAlarmVO> webAlramList = new ArrayList<HopeAlarmVO>();
				List<HopeAlarmVO> pushAlramList = new ArrayList<HopeAlarmVO>();
				
				for (int i = 0; i < list.size(); i++) {
					if("N".equals(list.get(i).getPushAt())) {
						webAlramList.add(list.get(i));
					} else if("Y".equals(list.get(i).getPushAt())) {
						pushAlramList.add(list.get(i));
					}
				}
				
				// 웹 알람
				redisPubSubService.publishMessage(wishAlramUri, "HopepcNm", webAlramList);
				//log.info("WebHopeAlram Member Total Count : {}", webAlramList.size());
				
				// 앱 푸쉬
				if(pushAlramList.size() > 0) {
					insertAppPushBySmsService(pushAlramList);	
				}
			}
		} catch (Exception e) {
			log.debug(ExceptionUtils.getStackTrace(e));
		}

	}
	
	
	//아연 희망가 알람 배치
	//@Scheduled(cron = "0 0/1 * * * *")
	public void HopeAlramZnScheduler() {
		//희망가 알림 리스트 조회
//		HopeAlarmVO vo = new HopeAlarmVO();
//		vo.setMetalCode("1");   //아연 금속코드
//		List<HopeAlarmVO> list = hopeAlramService.getHopePcZnNtcnSetupBas(vo);
//		int hopeAlramSize = list.size();
//		
//		if(hopeAlramSize > 0) {
//			//희망가 알림 등록은 하였으나, 발송기본 테이블에 없는 데이터 INSERT
//			hopeAlramService.insertHopePcZnNtcnSndngBasList(vo);
//			list = hopeAlramService.getHopePcZnNtcnSndngBas(vo);
//			redisPubSubService.publishMessage(znWishAlramUri, "HopepcNm", list);
//			log.info("HopeAlram Member Total Count : {}", list.size());
//		} else {
//			log.debug("HopeAlram Member No Count");
//			return;
//		}
		
	}
	
	
	
	/**
	 * <pre>
	 * 처리내용: AppPush를 발송한다.
	 * </pre>
	 * @date 2022. 2. 7.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 2. 7.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param vo
	 */
	private void insertAppPushBySmsService(List<HopeAlarmVO> pushAlramVoList) {
		try {
			
			for (int i = 0; i < pushAlramVoList.size(); i++) {
				
				//메세지 세팅
				Map<String, String> map = new HashedMap<>();
				map.put("templateNum", "24"); 																			//템플릿번호
				map.put("prdName", pushAlramVoList.get(i).getItmPrdlstEng()); 													//상품명
				map.put("livePrice", String.format("%,d", Math.round(Float.parseFloat(pushAlramVoList.get(i).getHopepc())))); 														//희망가
				map.put("callbackURL", "/pd/itemPriceSearch?metalCode=" + pushAlramVoList.get(i).getMetalCode() + "&sleMthdCode=01"); //callbackURL
				
				//회원 디바이스 정보 및 핸드폰 번호 조회
				List<HopeAlarmVO> deviceIdList = hopeAlramService.selectAppPushMember(pushAlramVoList.get(i));
				for (HopeAlarmVO hopeAlarmVO : deviceIdList) {
					AppPushQueueVO push = new AppPushQueueVO();
					push.setMsgTitle("희망가 도달 알림");
					push.setCallback(CryptoUtil.decryptAES256(hopeAlarmVO.getMoblphonNo()));
					push.setMberNo(hopeAlarmVO.getMberNo());
					push.setIdentify(hopeAlarmVO.getDeviceId());
					push.setType("0");
					push.setUrl(hopeAlarmDomain + "/pd/itemPriceSearch?metalCode=" + pushAlramVoList.get(i).getMetalCode() + "&sleMthdCode=01");
					smsService.insertAppPush(push, map);
					//hopeAlramService.updateHopePushAlarmReturn(pushAlramVoList.get(i));
				}
			}
			log.info("AppHopeAlram Member Total Count : {}", pushAlramVoList.toString());
			log.info("AppHopeAlram Member Total Count : {}", pushAlramVoList.size());
		} catch (Exception e) {
			log.info("재고알림배치 insertAppPush error :: " + e.getMessage());
		}
		
	}
}
