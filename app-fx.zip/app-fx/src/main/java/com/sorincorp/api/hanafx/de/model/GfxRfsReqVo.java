package com.sorincorp.api.hanafx.de.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class GfxRfsReqVo {
		/******  GFX_RFS_REQ(거래용 환율 RFS I/F)           ******/

	    /**
	     * 상품코드
	    */
	    private String prodCd;
	    /**
	     * 거래 통화 코드
	    */
	    private String pairId;
	    /**
	     * 거래 통화
	    */
	    private String currCd;
	    /**
	     * Near 결제일
	    */
	    private String valDt;
	    /**
	     * Far 결제일
	    */
	    private String matDt;
	    /**
	     * 요청 금액
	    */
	    private String amt1;
	    /**
	     * 환율 요청 ID
	    */
	    private String mdReqId;
	    /**
	     * 환율 요청 구분
	    */
	    private String mdReqTp;
	    /**
	     * 고객 딜러 ID
	    */
	    private String userId;
	    /**
	     * 이전 요청 연월일
	    */
	    private String reqTm;
	    /**
	     * 환율 상태
	    */
	    private String status;
}
