package com.sorincorp.api.limit.service;

import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.api.hanafx.pr.model.PrEhgtRltmBassVo;
import com.sorincorp.api.util.RestDateTime;
import com.sorincorp.comm.it.model.ItFtrsFshgManageDtlVo;
import com.sorincorp.comm.it.service.ItFtrsFshgManageDtlVoService;
import com.sorincorp.comm.it.service.ReturnNewItVo;
import com.sorincorp.comm.limit.service.LimitService;
import com.sorincorp.comm.limit.service.OrLimitOrderBasVoMapService;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderQueueMsgVO;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderRedisMsgVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class FindMatchingLimitFxPriceThreadServiceImpl implements FindMatchingLimitFxPriceThreadService {

	@Autowired
	private LimitService limitService;

	@Autowired
	private ReturnNewItVo returnNewItVo;

	private ItFtrsFshgManageDtlVo returnItVo;

	@Autowired
	private RestDateTime restDateTime;

	@Autowired
	private ItFtrsFshgManageDtlVoService itFtrsFshgManageDtlVoService;

	@Autowired
	private OrLimitOrderBasVoMapService orderLimitOrderBasVoMapService;

	@Override
	public void findMatchingLimitFxPriceThread(PrEhgtRltmBassVo prEhgtRltmBassVo) throws Exception {
		try {
			checkPrvsnlLimitData(prEhgtRltmBassVo);
		} catch(Exception e) {
			log.error("findMatchingLimitFxPriceThread function error : " + ExceptionUtils.getStackTrace(e));
		}
	}

	// 가단가 지정가 주문 체크
	private synchronized void checkPrvsnlLimitData(PrEhgtRltmBassVo prEhgtRltmBassVo) throws Exception {
		if(restDateTime.isSorinRltmWorkTime()) {
			// 1) 큐 레이아웃에 맞는 데이터 설정
			CommPrvsnlLimitOrderQueueMsgVO queueVo = new CommPrvsnlLimitOrderQueueMsgVO();
			queueVo.setLimitOrderRequestDt("" + prEhgtRltmBassVo.getOccrrncDe() + prEhgtRltmBassVo.getOccrrncTime());  // 지정가 주문 요청 일시
			queueVo.setEhgtPcRltmSn(prEhgtRltmBassVo.getEhgtPcRltmSn());											   // 환율 가격 실시간 순번
			queueVo.setSpex(prEhgtRltmBassVo.getEndPc());															   // 환율 가격

			log.debug("3-0) check orderLimit Map: " + orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap());

			if(orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap().isEmpty())
				return;

			orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap().entrySet().stream().forEach(entry -> {
				String key = entry.getKey();

				// 가단가 지정가 가격 리스트
				TreeSet<CommPrvsnlLimitOrderRedisMsgVO> orderLimitList = orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap(key);
				// 선물, 선물환 관리 상세(조정계수)
				try {
					returnItVo = returnNewItVo.process_CopyNewVo(itFtrsFshgManageDtlVoService.getItFtrsFshgManageDtlVo(key));

					//log.debug("3-0) Matching metalCode: " + key + ", Matching ItFtrsFshgManageDtlVo:" +returnItVo);
				} catch (Exception e1) {

				}

				// 환율 조정계수
				queueVo.setSpexMdatCffcnt(returnItVo.getEhgtMdatCffcntAmount());

				/*
				 * 2) 지정가와 실시간 가격 비교하여 일치하는 데이터 amountGroupedMap에 저장
				 *
				 * 시간대별 지정가 가격 리스트에서 수신 받은 판매 데이터의 메탈 코드와 일치하고,
				 *
				 * 환율 -> 지정가 입력금액이 (실시간 환율 + 조정계수) 보다 크거나 같음
				 *
				 * 해당 케이스로 리스트 필터링
				 */
				TreeSet<CommPrvsnlLimitOrderRedisMsgVO> amountGroupedSet = orderLimitList.stream()
						.filter(order -> order.getLimitInputAmount() >= prEhgtRltmBassVo.getEndPc().add(returnItVo.getEhgtMdatCffcntAmount()).longValue())
						.collect(Collectors.toCollection(TreeSet::new));

				if(amountGroupedSet.isEmpty())
					return;

				ObjectMapper objectMapper = new ObjectMapper();	// TODO [pje] 테스트용 - 삭제예정
				try {
					String result = objectMapper.writeValueAsString(amountGroupedSet);			// TODO [pje] 테스트용 - 삭제예정

					log.debug("3-1) Matching metalCode: " + key + ", Matching amount map:" +result);
				} catch(Exception e) {

				}

				// amountGroupedSet에 있는 주문번호 리스트
				List<String> limitOrderNoList = amountGroupedSet.stream()
						.map(CommPrvsnlLimitOrderRedisMsgVO::getLimitOrderNo)
						.collect(Collectors.toList());

				///////////////////////////////////////////////////////////////////////
				log.debug("3-4) key: " + key + ", queueVo:" + queueVo);


				try {
					// 3) 종목별로 큐에 넘겨줄 최종 데이터를 세팅 후 큐에 전송
					limitService.settingPrvsnlLimitQueueData(amountGroupedSet, queueVo);

					// 4) 전송된 데이터 메모리에서 제거
					orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap(key).removeIf(item -> limitOrderNoList.contains(item.getLimitOrderNo()));
					orderLimitOrderBasVoMapService.getPrvsnlLimitOrderNoInputAmountVo().keySet().removeIf(item -> limitOrderNoList.contains(item));

					String result = objectMapper.writeValueAsString(orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap());			// TODO [pje] 테스트용 - 삭제예정
					String result2 = objectMapper.writeValueAsString(orderLimitOrderBasVoMapService.getPrvsnlLimitOrderNoInputAmountVo());
					log.info("6-1) After Sending Data to the Queue: " + result);
					log.info("6-2) After Sending Data to the Queue: " + result2);
				} catch (Exception e) {
					log.error("[amountGroupedMap Error] {}", ExceptionUtils.getStackTrace(e));
				}
			});
		}
	}
}
