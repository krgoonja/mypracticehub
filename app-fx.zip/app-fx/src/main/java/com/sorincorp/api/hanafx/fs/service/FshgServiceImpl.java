package com.sorincorp.api.hanafx.fs.service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.digitide.xcube.XCPBMsg;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.api.hanafx.fs.mapper.FshgMapper;
import com.sorincorp.api.hanafx.fs.model.ApiIntDatReqVo;
import com.sorincorp.api.hanafx.fs.model.ApiIntDatResVo;
import com.sorincorp.api.hanafx.fs.model.ApiIntDatVo;
import com.sorincorp.api.hanafx.fs.model.ApiIntSeqVo;
import com.sorincorp.api.hanafx.fs.model.ItPurchsInfoBasVo;
import com.sorincorp.api.hanafx.fs.model.OrOrderFshgBasVo;
import com.sorincorp.api.hanafx.mo.service.FxStateMonitorService;
import com.sorincorp.api.util.FshgConst;
import com.sorincorp.comm.assign.service.AssignService;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("fshgService")
@ComponentScan({"com.sorincorp.comm.assign.*"})
public class FshgServiceImpl implements FshgService{
	@Autowired
	private FshgMapper fshgMapper;

	@Autowired
	private AssignService assignService;

	@Autowired
	private FxStateMonitorService fxStateMonitorService;

	@Autowired
	SMSService smsService;

	@Override
	public String getFshgReqOrderNo()  throws Exception{
		String reqOrdNo = DateUtil.getNowDate() + "-2";
		String tmpReqOrdNo = assignService.selectAssignValue("OR", "FSHG_REQUST_ORDER_NO", DateUtil.getNowDate(), "fxSystem", 10);
		return reqOrdNo + tmpReqOrdNo;
	}

	@Override
	public void insertTestFshData(OrOrderFshgBasVo fshgBasVo) throws Exception {
		String fshgOrderNo = getFshgReqOrderNo();
		fshgBasVo.setFshgRequstOrderNo(fshgOrderNo);

		fshgMapper.insertTestOrOrderFshgBas(fshgBasVo);
	}

	@Override
	public int executeApiIntId(OrOrderFshgBasVo reqVo) throws Exception{
		String user = "system";
		/*
		 * Step1. API_INT_SEQ 테이블에 REQ SEQ 등록
		 */
		ApiIntSeqVo param = new ApiIntSeqVo();
		param.setIntId(FshgConst.SEND_INT_ID);
		int seq = fshgMapper.selectMaxKeyApiIntSeq(param);
		param.setReqSeq(seq);
		fshgMapper.updateApiIntSeq(param);            //API_INT_SEQ은 업데이트만 존재한다.

		/*
		 * Step2. 조회해온 최신 환율 데이터를 update OR_ORDERFSHG_BAS
		 *
		 */
		reqVo.setLastChangerId(user);
		fshgMapper.updateOrOrderFshgBasReqData(reqVo);

		return seq;
	}

	@Override
	public ApiIntDatReqVo executeMakeApiIntData(int seq, OrOrderFshgBasVo reqVo) throws Exception {
		String user = "system";
		String cliOrdNo 	= reqVo.getFshgRequstOrderNo();				//20210707-20000000001
		String prodCd 		= reqVo.getRequstFshgGoodsCode();			//FWD
		String pairId 		= reqVo.getRequstFshgDelngCrncyCode();		//USD/KRW
		String valDt 		= reqVo.getRequstExprtnde();				//20210730
		String matDt 		= "00000000";							    //00000000 케이지트레이딩에서는 사용 않함.  주의)db칼럼없음
		String currCd 		= "USD";						            //USD, 						주의)db칼럼없음
		String nearAmt	    = reqVo.getRequstOrderAmount();				//1000000
		String bsTp 		= reqVo.getRequstPostn();					//S
		String condTp 		= reqVo.getRequstOrderCnd();				//M

		String strFarAmt    = "0";                         				 //Swap only
		String tif          = FshgConst.SEND_NEW_TIF;
		String enterTm 		= DateUtil.calDate("yyyyMMddHHmmssSSS");	 //요청시간	YYYYMMDDHHMMSSMS	2021031212101012

		String limPx 		= reqVo.getRequstOrderPc();                  //요청 주문 가격
		String qtIdx 		= reqVo.getRequstEhgtIndx();                 //요청 환율 인덱스

		String requstLqdNo  = StringUtils.defaultIfBlank(reqVo.getRequstLqdNo(), "");

        /* 파라미터 설정 */
		String parama01     = FshgConst.SEND_NEW_MSG_TP;
		String parama02     = StringUtil.padValue(cliOrdNo, " "				, FshgConst.SEND_NEW_CLI_ORD_NO_LEN, false);
	    String parama03     = StringUtil.padValue(prodCd, " "				, FshgConst.SEND_NEW_PROD_CD_LEN, false);
	    String parama04     = StringUtil.padValue(pairId, " "				, FshgConst.SEND_NEW_PAIR_ID_LEN, false);
	    String parama05     = StringUtil.padValue(valDt, " "				, FshgConst.SEND_NEW_VAL_DT_LEN, false);
	    String parama06     = StringUtil.padValue(matDt, " "				, FshgConst.SEND_NEW_MAT_DT_LEN, false);
	    String parama07     = StringUtil.padValue(currCd, " "				, FshgConst.SEND_NEW_CURR_CD_LEN, false);
	    String parama08     = StringUtil.padValue(nearAmt.toString(), " "	, FshgConst.SEND_NEW_NEAR_AMT_LEN, false);
	    String parama09     = StringUtil.padValue(strFarAmt, " "			, FshgConst.SEND_NEW_FAR_AMT_LEN, false);
	    String parama10     = StringUtil.padValue(bsTp, " "					, FshgConst.SEND_NEW_BS_TP_LEN, false);
	    String parama11     = StringUtil.padValue(condTp, " "				, FshgConst.SEND_NEW_COND_TP_LEN, false);
	    String parama12     = tif;
	    String parama13     = StringUtil.padValue(limPx, " "				, FshgConst.SEND_NEW_LIM_PX_LEN, false);
	    String parama14     = StringUtil.padValue(qtIdx, " "				, FshgConst.QT_IDX_LEN, false)	;
	    String parama15     = StringUtil.padValue(enterTm, " "				, FshgConst.SEND_NEW_ENTER_TM_LEN, false);
	    String parama16     = StringUtil.padValue(requstLqdNo, " "			, FshgConst.SEND_NEW_CLI_ORD_NO_LEN, false);

		XCPBMsg pbMsg = new XCPBMsg();
		/* pbMsg Set Header */
		String msgType 	= FshgConst.MSG_TYPE;
		String msgSvc 	= FshgConst.SEND_MSG_SVC;
		String intId 	= FshgConst.SEND_INT_ID;
		String reqSeq 	= String.valueOf(seq);
		String msgCode  = intId + reqSeq;
		pbMsg.type(msgType);
		pbMsg.svc(msgSvc);
		pbMsg.seq1(0);
		pbMsg.seq2(0);
		pbMsg.code(msgCode);

		/* pbMsg Set Body */
		pbMsg.add_value(parama01, FshgConst.SEND_NEW_MSG_TP_LEN); 		/* MSG_TP */
		pbMsg.add_value(parama02, FshgConst.SEND_NEW_CLI_ORD_NO_LEN); 	/* CLI_ORD_NO */
		pbMsg.add_value(parama03, FshgConst.SEND_NEW_PROD_CD_LEN); 		/* PROD_CD */
		pbMsg.add_value(parama04, FshgConst.SEND_NEW_PAIR_ID_LEN); 		/* PAIR_ID */
		pbMsg.add_value(parama05, FshgConst.SEND_NEW_VAL_DT_LEN); 		/* VAL_DT */
		pbMsg.add_value(parama06, FshgConst.SEND_NEW_MAT_DT_LEN); 		/* MAT_DT */
		pbMsg.add_value(parama07, FshgConst.SEND_NEW_CURR_CD_LEN); 		/* CURR_CD */
		pbMsg.add_value(parama08, FshgConst.SEND_NEW_NEAR_AMT_LEN); 	/* NEAR_AMT */
		pbMsg.add_value(parama09, FshgConst.SEND_NEW_FAR_AMT_LEN); 		/* FAR_AMT */
		pbMsg.add_value(parama10, FshgConst.SEND_NEW_BS_TP_LEN); 		/* BS_TP */
		pbMsg.add_value(parama11, FshgConst.SEND_NEW_COND_TP_LEN); 		/* COND_TP */
		pbMsg.add_value(parama12, FshgConst.SEND_NEW_TIF_LEN); 			/* TIF */
		pbMsg.add_value(parama13, FshgConst.SEND_NEW_LIM_PX_LEN); 		/* LIM_PX */
		pbMsg.add_value(parama14, FshgConst.QT_IDX_LEN); 				/* QT_IDX */
		pbMsg.add_value(parama15, FshgConst.SEND_NEW_ENTER_TM_LEN); 	/* ENTER_TM */
		pbMsg.add_value(parama16, FshgConst.SEND_NEW_CLI_ORD_NO_LEN); 	/* ORG_CLI_ORD_NO */

	    ApiIntDatReqVo apiIntDatReqVo = new ApiIntDatReqVo();
	    apiIntDatReqVo.setIntId(intId);
	    apiIntDatReqVo.setReqSeq(seq);
	    apiIntDatReqVo.setMsgTp(parama01);
	    apiIntDatReqVo.setCliOrdNo(parama02);
	    apiIntDatReqVo.setProdCd(parama03);
	    apiIntDatReqVo.setPairId(parama04);
		apiIntDatReqVo.setValDt(parama05);
		apiIntDatReqVo.setMatDt(parama06);
		apiIntDatReqVo.setCurrCd(parama07);
		apiIntDatReqVo.setNearAmt(new BigDecimal(nearAmt));
		apiIntDatReqVo.setFarAmt(new BigDecimal(strFarAmt));
		apiIntDatReqVo.setBsTp(parama10);
		apiIntDatReqVo.setCondTp(parama11);
		apiIntDatReqVo.setTif(parama12);
		apiIntDatReqVo.setLimPx(parama13);
		apiIntDatReqVo.setQtIdx(parama14);
		apiIntDatReqVo.setEnterTm(parama15);
		apiIntDatReqVo.setFrstRegisterId(user);
		apiIntDatReqVo.setOrgCliOrdNo(parama16);

		apiIntDatReqVo.setXcpbMsg(pbMsg);

		return apiIntDatReqVo;
	}

	@Override
	public void insertApiIntDatWithXCPBMsg(int seq, XCPBMsg msg, ApiIntDatReqVo apiIntDatReqVo) throws Exception {
		StringBuffer buffer = new StringBuffer();
		XCPBMsg copyMsg = new XCPBMsg();
		copyMsg.read(msg.msg(), msg.length());
		int data_col_len = copyMsg.col_cnt();
		for(int i=0; i<data_col_len; i++) {
			buffer.append(copyMsg.get_value(i));
		}

		ApiIntDatVo param2 = new ApiIntDatVo();
		param2.setIntId(FshgConst.SEND_INT_ID);
		param2.setReqSeq(seq);

		// 22.06.21 PO 테이블에 "선물환관리번호" 존재유무에 따라 "청산(TO)" 또는 "신규(NO)" 주문
		if (StringUtil.isNotBlank(apiIntDatReqVo.getOrgCliOrdNo())) {
			param2.setReqTp(FshgConst.REQ_TP_LQD_ORDER);
		} else {
			param2.setReqTp(FshgConst.REQ_TP_NEW_ORDER);
		}

		param2.setStatTp(FshgConst.STAT_TP_UNPROCESSED);	// 상태: 미처리 1
		param2.setReqDat(buffer.toString());

		String currentDate = DateUtil.calDate(FshgConst.HANAFX_DATE_FORMAT1);	// yyyyMMdd
		String currentTime = DateUtil.calDate(FshgConst.HANAFX_DATE_FORMAT2);	// HHmmss
		param2.setReqDt(currentDate);
		param2.setReqTm(currentTime);
		param2.setPrcDt(currentDate);
		param2.setPrcTm(currentTime);

		try {
			apiIntDatReqVo.setRequstSpclty(new ObjectMapper().writeValueAsString(apiIntDatReqVo));
		} catch (Exception e) {
			apiIntDatReqVo.setRequstSpclty("응답 전문 Parsing Error.");
		}

		/* 1. API_INT_DAT(환율 API 주문 요청) 저장 */
		fshgMapper.insertApiIntDat(param2);

		/* 2. API_INT_DAT_REQ( 환율 주문 요청 ) 테이블 저장 */
		fshgMapper.insertApiIntDatReq(apiIntDatReqVo);

		if(log.isInfoEnabled()) {
			String tmpStr = buffer.toString();
			StringBuilder logStr = new StringBuilder();
			logStr.append("Fshg Order Send Data (length: " + tmpStr.length() + ")\n");
			logStr.append(tmpStr.trim() + "\n");
			logStr.append("API_TRD_SND : REQ_SEQ[" + seq + "]\n");
			logStr.append(apiIntDatReqVo.print());

			log.info(logStr.toString());
		}
	}

	/**
	 * 하나 fx 수신데이터 저장시 데이터 보관을 위해 exception 발셍시 roll-back에서 제외시킴.
	 */
	@Override
	public void saveRecvFutureExchange(ApiIntDatVo vo1, ApiIntDatResVo apiIntDatResVo) throws Exception {
		log.info("::: saveRecvFutureExchange 하나FX수신데이터저장");
		/*
		 * Step1. API_INT_SEQ 테이블에 PRC SEQ 등록
		 */
		ApiIntSeqVo param = new ApiIntSeqVo();
		param.setIntId(FshgConst.RECV_INT_ID);
		int nextSeq = fshgMapper.selectMaxKeyApiIntSeq(param);
		param.setPrcSeq(nextSeq);
		fshgMapper.updateApiIntSeq(param);            //API_INT_SEQ은 업데이트만 존재한다.

		/*
		 * Step2. API_INT_DAT STAT_TP 변경
		 */
		int recvReq = vo1.getReqSeq();
		String serviceNm = vo1.getIntId();
		String currentDate = DateUtil.calDate(FshgConst.HANAFX_DATE_FORMAT1);
		String currentTime = DateUtil.calDate(FshgConst.HANAFX_DATE_FORMAT2);
		vo1.setStatTp(FshgConst.STAT_TP_PROCESS_COMPT);                            //STAT_TP 상태 변경(처리완료)
		vo1.setPrcDt(currentDate);
		vo1.setPrcTm(currentTime);
		fshgMapper.updateApiIntDat(vo1);

		if(apiIntDatResVo != null) {
			/*
			 * 3. API_INT_DAT_RES 테이블에 전문 내용 등록
			 *   전문 내용을 DB에서 읽어와 변환하는것으로 바꿈.
			 */
			apiIntDatResVo.setIntId(serviceNm);
			apiIntDatResVo.setReqSeq(recvReq);
			apiIntDatResVo.setFrstRegisterId("system");

			try {
				String rspnsSpclty = new ObjectMapper().writeValueAsString(apiIntDatResVo);
				apiIntDatResVo.setRspnsSpclty(rspnsSpclty);
			}catch(Exception e) {
				apiIntDatResVo.setRspnsSpclty("응답 전문 Parsing Error.");
			}

			String cliPrderNo = apiIntDatResVo.getCliOrdNo();
			if (StringUtils.isNotBlank(cliPrderNo) && cliPrderNo.indexOf("SRN") > -1) {
				log.info("::: saveEfxHttsOrder");
				saveEfxHttsOrder(apiIntDatResVo);
			} else {
				log.info("::: saveLqdOrder");
				saveLqdOrder(apiIntDatResVo);
			}
		}
	}

	/**
	 * <pre>
	 * 처리내용:  최초 Efx Htts 주문 수신 내용을 저장한다.
	 * </pre>
	 * @date 2021. 12. 1.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 1.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param apiIntDatResVo
	 */
	private void saveEfxHttsOrder(ApiIntDatResVo apiIntDatResVo) {
		try {
			fshgMapper.insertLqdIntDatRes(apiIntDatResVo);
		}catch(Exception e) {
			log.error(apiIntDatResVo.toString());
			log.error("Efx Htts 주문 오류", e);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 청산 주문 수신 내용을 저장한다.
	 * </pre>
	 * @date 2021. 12. 1.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * <br>2021. 12. 1.		srec0032		최초작성
	 * <br>2023. 1. 6.		srec0051		만기일자 수정된 매도주문시 PO 테이블 업데이트 로직 추가
	 * @param apiIntDatResVo
	 */
	private void saveLqdOrder(ApiIntDatResVo apiIntDatResVo) {
		try {

			String scptTp = apiIntDatResVo.getAcptTp();  //접수상태

			/* 응답 선물환 상태 코드         */
			String rspnsFshgSttusCode = "";
			if(FshgConst.RECV_ACPT_TP_ACPT.equals(scptTp)) {   		                                              //0: 주문 접수 -> (케이지트레이딩)주문요청
				rspnsFshgSttusCode = "1";
			}else if(FshgConst.RECV_ACPT_TP_OK.equals(scptTp) || FshgConst.RECV_ACPT_TP_CNCL.equals(scptTp)) {    //2: 주문 체결, 4: 주문 취소 -> (케이지트레이딩)주문 체결
				rspnsFshgSttusCode = "2";
			}else {
				rspnsFshgSttusCode = "8";                                                                          //8=주문 거부 -> (케이지트레이딩) 실패
			}

			String fshgRequstOrderNo    = apiIntDatResVo.getCliOrdNo();
			String rspnsFshgOrderNo 	= apiIntDatResVo.getOrdNo();                        		   /* 응답 선물환 주문 번호         */
		    String rspnsCnclsAmount 	= apiIntDatResVo.getTktAmt() !=null ? apiIntDatResVo.getTktAmt().toString() : "";                       /* 응답 체결 금액                */
		    String rspnsUncnclsAmount 	= apiIntDatResVo.getRemAmt() !=null ? apiIntDatResVo.getRemAmt().toString() : "";                       /* 응답 미체결 금액              */
		    String rspnsCnclsNo 		= apiIntDatResVo.getTktNo();                            	   /* 응답 체결 번호                */
		    String rspnsDelngEhgt 		= apiIntDatResVo.getNearRate() != null ? apiIntDatResVo.getNearRate().toString() : "";                     /* 응답 거래 환율                */
		    String rspnsDelngAmount 	= apiIntDatResVo.getNearAmt() != null ? apiIntDatResVo.getNearAmt().toString() : "";                      /* 응답 거래 금액                */
		    String rspnsMssage 			= apiIntDatResVo.getRetText();                             	   /* 응답 메시지                   */

			OrOrderFshgBasVo fshgBasVo = new OrOrderFshgBasVo();
			fshgBasVo.setRspnsFshgOrderNo(rspnsFshgOrderNo);
			fshgBasVo.setRspnsCnclsAmount(rspnsCnclsAmount);
			fshgBasVo.setRspnsUncnclsAmount(rspnsUncnclsAmount);
			fshgBasVo.setRspnsFshgSttusCode(rspnsFshgSttusCode);
			fshgBasVo.setRspnsCnclsNo(rspnsCnclsNo);
			fshgBasVo.setRspnsDelngEhgt(rspnsDelngEhgt);
			fshgBasVo.setRspnsDelngAmount(rspnsDelngAmount);
			fshgBasVo.setRspnsMssage(rspnsMssage);
			fshgBasVo.setLastChangerId("system");
			fshgBasVo.setFshgRequstOrderNo(fshgRequstOrderNo);

			/* API_INT_DAT_RES 등록 */
			fshgMapper.insertApiIntDatRes(apiIntDatResVo);

			/* OR_ORDER_FSHG_BAS 상태 변경 */
			fshgMapper.updateOrOrderFshgBasResData(fshgBasVo);

			/* 실패 sms 추가 발송 */
			if (StringUtils.equals(rspnsFshgSttusCode, "8")) {
				String orderNo = fshgMapper.getOrderNo(fshgRequstOrderNo);
				String errMsg = StringUtil.isNotBlank(rspnsMssage) ? rspnsMssage : "하나fx 응답 실패";
				// templateNum : 46, smsSndngGroupCode : 42
				Map<String, String> smsMap = new HashMap<>();
				smsMap.put("templateNum", "46");
				smsMap.put("commerceNtcnCn", "선물환 처리 실패"); // 커머스 알림 메시지
				smsMap.put("orderNo", orderNo);
				smsMap.put("returnMsg", fshgRequstOrderNo);
				smsMap.put("errMsg", errMsg);
				smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
				smsService.insertSMS(null, smsMap);
			}

			/* 신호등 테이블 update */
			boolean checkFxWorkStatus = rspnsFshgSttusCode.equals("8") ? false:true;
			fxStateMonitorService.checkFxWorkStatus(checkFxWorkStatus);

			/* 만기일자 수정된 매도주문 성공시 PO 테이블 업데이트 로직 추가 */
			if (StringUtils.equals(rspnsFshgSttusCode, "2")) {
				exprtndeCompareAndPoTbUpdate(fshgBasVo);
			}

		}catch(Exception e) {
			log.error(apiIntDatResVo.toString());
			log.error("청산 주문 오류", e);
		}

	}

	/**
	 * <pre>
	 * 매도주문 && 요청 만기일자가 PO 만기일자와 다르다면 PO 만기일자를 업데이트
	 * </pre>
	 * @date 2023. 1. 6.
	 * @author srec0051
	 * @param fshgBasVo
	 * @throws Exception
	 */
	private void exprtndeCompareAndPoTbUpdate(OrOrderFshgBasVo fshgBasVo) {
		try {
			fshgBasVo = fshgMapper.selectOrderFshgBasInfo(fshgBasVo);
			String requstPostn = fshgBasVo.getRequstPostn();
			String requstExprtnde = fshgBasVo.getRequstExprtnde();

			if (StringUtils.equals("S", requstPostn)) {
				ItPurchsInfoBasVo itPurchsInfoBasVo = fshgMapper.selectClaimPurchsInfo(fshgBasVo);
				String fshgExprtnde = itPurchsInfoBasVo.getFshgExprtnDe();

				if (!StringUtils.equals(requstExprtnde, fshgExprtnde)) {
					itPurchsInfoBasVo.setFshgExprtnDe(requstExprtnde);
					fshgMapper.updateExprtndeItPurchsInfoBas(itPurchsInfoBasVo);
					fshgMapper.insertItPurchsInfoBasHst(itPurchsInfoBasVo);
					log.info("PO 선물환 만기일자 업데이트 - blNo:{}, 선물환요청주문번호:{}", itPurchsInfoBasVo.getBlNo(), fshgBasVo.getFshgRequstOrderNo());
				}
			}
		} catch (Exception e) {
			log.error("PO 선물환 만기일자 업데이트 오류 - {}", e.getMessage());
		}
	}

	@Override
	public ApiIntDatVo selectApiIntDat(ApiIntDatVo vo) throws Exception {
		return fshgMapper.selectApiIntDat(vo);
	}
}
