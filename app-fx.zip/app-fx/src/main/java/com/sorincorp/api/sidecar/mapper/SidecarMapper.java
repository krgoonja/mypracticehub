package com.sorincorp.api.sidecar.mapper;

import java.util.List;

import com.sorincorp.api.sidecar.model.SidecarVO;
import com.sorincorp.api.sidecar.model.SidecarValidateVO;

public interface SidecarMapper {


	List<SidecarValidateVO> getSidecarOpertionList(SidecarVO vo);

	void insertSidecarMotnDtl(List<SidecarValidateVO> sidecarValidateVoList);

	/**
	 * <pre>
	 * 사이드카 발동 시 테이블 저장
	 * </pre>
	 * @date 2022. 1. 29.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 1. 29.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param nowDate
	 */
	void insertItSidecarMotnDtl(String nowDate);
	
	/**
	 * <pre>
	 * 처리내용: 환율 사이드카 발동 시 테이블 저장
	 * </pre>
	 * @date 2022. 2. 11.
	 * @author srec0049
	 * @history 
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 2. 11.			srec0049			최초작성
	 * ------------------------------------------------
	 * @param nowDate
	 */
	void insertItFxSidecarMotnDtl(String nowDate);
	
	/**
	 * <pre>
	 * 사이드카 발송 대상 리스트 조회
	 * </pre>
	 * @date 2022. 2. 4.
	 * @author srec0008
	 * @history 
	 * <pre>
	 * -------------------------------------------------------------------------
	 * 변경일			작성자			변경내용
	 * -------------------------------------------------------------------------
	 * 2022. 2. 4.		srec0008		최초작성
	 * -------------------------------------------------------------------------
	 * </pre>
	 * @param nowDate
	 * @return
	 */
	List<SidecarVO> getSidecarOnList(String nowDate, String type);

}
