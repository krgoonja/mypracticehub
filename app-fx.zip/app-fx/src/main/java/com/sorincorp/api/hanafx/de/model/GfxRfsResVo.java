package com.sorincorp.api.hanafx.de.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class GfxRfsResVo {
		/******  GFX_RFS_RES(거래용 환율 응답 I/F)                                                                              ******/

	   /**
	     * 인터페이스 순번
	    */
	    private long intrfcSn;
	    /**
	     * 환율 요청 ID
	    */
	    private String mdReqId;
	    /**
	     * 환율 제공 상태
	    */
	    private String qtStatus;
	    /**
	     * 환율 건별 INDEX
	    */
	    private String qtIdx;
	    /**
	     * 상품코드
	    */
	    private String prodCd;
	    /**
	     * 거래 통화 코드
	    */
	    private String pairId;
	    /**
	     * 거래 통화
	    */
	    private String currCd;
	    /**
	     * NEAR 결제일
	    */
	    private String valDt;
	    /**
	     * FAR 결제일
	    */
	    private String matDt;
	    /**
	     * 요청 금액
	    */
	    private java.math.BigDecimal amt1;
	    /**
	     * 고객 딜러 ID
	    */
	    private String userId;
	    /**
	     * 환율 유효 시간
	    */
	    private String validTime;
	    /**
	     * 현물환 매도 환율
	    */
	    private java.math.BigDecimal spotBid;
	    /**
	     * 현물환 매수 환율
	    */
	    private java.math.BigDecimal spotAsk;
	    /**
	     * 선물환 매도 환율
	    */
	    private java.math.BigDecimal nearBid;
	    /**
	     * 선물환 매수 환율
	    */
	    private java.math.BigDecimal nearAsk;
	    /**
	     * SWAP 매도 환율
	    */
	    private java.math.BigDecimal farBid;
	    /**
	     * SWAP 매수 환율
	    */
	    private java.math.BigDecimal farAsk;
	    /**
	     * 최초 등록자 아이디
	    */
	    private String frstRegisterId;
	    /**
	     * 최초 등록 일시
	    */
	    private java.sql.Timestamp frstRegistDt;

		/** 검색조건 */
		private String searchCondition = "";

		/** 검색Keyword */
		private String searchKeyword = "";
}
