package com.sorincorp.api.hanafx.fs.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ApiIntDatVo {

   /**
    * 서비스 명
   */
   private String intId;

   /**
    * 최종 요청 순번
   */
   private int reqSeq;

   /**
    * 요청 메시지 TP
   */
   private String reqTp;

   /**
    * 처리 상태
   */
   private String statTp;

   /**
    * 요청 DATA
   */
   private String reqDat;

   /**
    * 최종 요청 일
   */
   private String reqDt;

   /**
    * 최종 요청 시
   */
   private String reqTm;
    /**
    * 최종 처리 일
   */

   private String prcDt;
    /**
    * 최종 처리 시
   */
   private String prcTm;
}
