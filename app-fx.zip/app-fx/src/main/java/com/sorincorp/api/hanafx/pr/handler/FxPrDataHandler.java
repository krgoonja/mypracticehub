package com.sorincorp.api.hanafx.pr.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.digitide.xcube.XCPBMsg;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.api.config.ConfigurationHanaFxBeanFactory;
import com.sorincorp.api.hanafx.pr.model.PrEhgtRltmBassVo;
import com.sorincorp.api.hanafx.pr.service.PrEhgtRltmService;
import com.sorincorp.api.hanafx.socket.MessageCast;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;
import com.sorincorp.comm.util.TimerUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class FxPrDataHandler extends Thread {

	@Autowired
	private PrEhgtRltmService rltmRecvService;

	@Autowired
	private TimerUtil timerUtils;

	private boolean isRun;
	private List<Object> list;
	private String[] prEhgtKeys = {
		"ehgtDelngCrncyCode",   /* 환율 거래 통화 코드 */
		"occrrncDe",            /* 발생 일자           */
		"occrrncTime",          /* 발생 시간           */
		"occrrncSn",            /* 발생 순번           */
		"endPc",                /* ASK 환율            */
		"versusFlctsCode",      /* 대비 등록 코드      */
		"versusPc",             /* 대비 가격           */
		"beginPc",              /* 시작 가격           */
		"topPc",                /* 최고 가격           */
		"lwetPc",               /* 최저 가격           */
	};

	@PostConstruct
	public void init(){
		list = new ArrayList<Object>();
		isRun = true;
		log.info("Hana FxPrDataHandler Init OK");
	}

	public void add(Object obj) throws Exception{
		synchronized(list) {
			int size = list.size();
			if (size>3000){
				log.info("==> FxPrDataHandler Buffer is OverFlow And Clear!!");
				throw new Exception("FxPrDataHandler Buffer is OverFlow");
			}else{
				list.add(obj);
				list.notify();
			}
		}
	}

	public void setRun(boolean run){
		this.isRun = run;
	}

	public void executePrEhgtRltmData(XCPBMsg pbMsg){
		/* pbMsg Parsing */
		PrEhgtRltmBassVo resVo = null;
		
		try {
//			if(log.isInfoEnabled()) {
				String dumpMsg = MessageCast.msgDump("############ 차트용 환율 수신 DUMP PBMSG", pbMsg);
				log.info(dumpMsg);
//			}

			/* API_INT_DAT_RES 테이블 데이타 */
			String value = null;
			Map<String, Object> map = new HashMap<>();
			int idx = 0;
			for(String key : prEhgtKeys) {
				value = StringUtil.trim(pbMsg.get_value(idx++));
				map.put(key, value);
			}

			ObjectMapper mapper = new ObjectMapper();
			resVo = mapper.convertValue(map, PrEhgtRltmBassVo.class);
			String sybol = resVo.getEhgtDelngCrncyCode();                     //SYBOL 13자리로 수신되고 있으며 디지타이드와 협의하여 고정값인 앞자리 3자리를 날린다.
			resVo.setEhgtDelngCrncyCode(sybol.substring(3).trim());
			log.info("executePrEhgtRltmService call before : "+ DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss.SSS"));

			//환율 가격 실시간 순번, 발생순번 마이크로 시간으로 변경
			String microTime = timerUtils.nowMicroStr();
			resVo.setEhgtPcRltmSn(microTime);
			//년월일시분초 이후 마이크로 시간으로 발생순번 생성 ( 동일 시간에 환율 데이터가 들어올경우 대비)
			resVo.setOccrrncSn(microTime.substring(14, microTime.length()));
			
			//Beans 업데이트
			ApplicationContext context = new AnnotationConfigApplicationContext(ConfigurationHanaFxBeanFactory.class);
			BeanUtils.copyProperties(resVo, (PrEhgtRltmBassVo)context.getBean("hanaFxRltm"));

			rltmRecvService.executePrEhgtRltmService(resVo);

		} catch (Exception e) {
			log.error(getClass().getName(), e);
			
			log.debug(">> executePrEhgtRltmData resVo : " + resVo);
		}
	}


	public final void run() {
		log.info("Hana FxPrDataHandler Start OK");
		Object object = null;
		while( isRun ) {
			try {
				synchronized(list) {
					if( list.size() == 0 ) {
						try {
							list.wait();
						} catch(Exception e) {}
					} else {
						object = (Object) list.remove(0);
					}
				}

				if( object != null ){
					executePrEhgtRltmData((XCPBMsg)object);
				}

				object = null;

			}catch(Exception e) {
				log.error("FxPrDataHandler error:", e);
			}
		}

		this.isRun = false;
		log.info("FxPrDataHandler is Terminated!!!");
	}

	@PreDestroy
	public void stopThread(){
		try {
			setRun(false);
			interrupt();

			Thread.sleep(50L);
		} catch (InterruptedException e) {
		}
	}
}
