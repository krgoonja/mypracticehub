package com.sorincorp.api.hanafx.pr.scheduler;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.sorincorp.api.hanafx.pr.mapper.PrEhgtRltmMapper;
import com.sorincorp.api.hanafx.pr.model.PrEhgtRltmBassVo;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.TimerUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class PrEhgtRltmScheduler {
	@Autowired
	private PrEhgtRltmMapper prEhgtRltmMapper;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltm;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltm01Min;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltm30Min;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltm60Min;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmDay;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmWeek;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmMon;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmQuarter;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmYear;

	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltm01MinComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltm30MinComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltm60MinComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmDayComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmWeekComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmMonComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmQuarterComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmYearComp;

	@Value("${redisPubsub.crncyCode.KRW}")
	private String fxpcKRW;

	//1분
	@Scheduled(cron = "0 0/1 * * * *")
	public void hanaFxRltm01MinScheduler() throws Exception {

		if("Y".equals(hanaFxRltm01Min.getDataValideRltm())) {
			hanaFxRltm01Min.setDataValideRltm("N");
			hanaFxRltm01Min.setOccrrncTime(hanaFxRltm01Min.getOccrrncTime().substring(0, 4) + "00");

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmm");
			LocalDateTime localDateTime = LocalDateTime.now();
			LocalDateTime oneMinuteBefore = localDateTime.minusMinutes(1);

			Map<String, String> map = new HashMap<>();
			map.put("stDate", oneMinuteBefore.format(formatter) + "00");
			map.put("edDate", oneMinuteBefore.format(formatter) + "59");
			map.put("crncyCode", hanaFxRltm01Min.getEhgtDelngCrncyCode());

			prEhgtRltmMapper.insertPrEhgtPc01MinBasForProcedure(map);


			//returnSelStdrBasVo.setOccrrncDe(DateUtil.getNowDateTime("yyyyMMdd"));
			//returnSelStdrBasVo.setOccrrncTime(DateUtil.getNowDateTime("HHmm") + "00");
//			prEhgtRltmMapper.hanaFxRltm01MinSchedulerMapper(hanaFxRltm01Min);   //DB inert (vo)

			//1분후 다시 실시간 데이터와 비교하기 위해, 바로전 1분 END_PC로 초기화
			//시가, 종가, 고가, 저가의 새로 시작
			hanaFxRltm01MinComp.setBeginPc(hanaFxRltm01Min.getEndPc());
			hanaFxRltm01MinComp.setEndPc(hanaFxRltm01Min.getEndPc());
			hanaFxRltm01MinComp.setTopPc(hanaFxRltm01Min.getEndPc());
			hanaFxRltm01MinComp.setLwetPc(hanaFxRltm01Min.getEndPc());
		}
	}

	//30분
	@Scheduled(cron = "0 0/30 * * * *")
	public void hanaFxRltm30MinScheduler() throws Exception {
		if("Y".equals(hanaFxRltm30Min.getDataValideRltm())) {
			hanaFxRltm30Min.setDataValideRltm("N");
			String curTime = DateUtil.calDate("HHmmss");
			if(Integer.parseInt(curTime.substring(2, 4)) > 29 ) {
				String hour = curTime.substring(0, 2);
				hanaFxRltm30Min.setOccrrncTime(hour + "3000");
			} else {
				String hour = curTime.substring(0, 2);
//				int previousHour = Integer.parseInt(hour) - 1;
//				hour = String.format("%02d", previousHour);
				hanaFxRltm30Min.setOccrrncTime(curTime.substring(0, 2) + "0000");
			}

			// 2023-07-19 15:00:00 -> 14:30:00 ~ 14:59:59
			// 2023-07-19 15:30:00 -> 15:00:00 ~ 15:29:59
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHH");
			LocalDateTime localDateTime = LocalDateTime.now();
			LocalDateTime oneHourBefore = localDateTime.minusHours(1);

			String yyyyMMddHH = "";
			String stMinutes = "";
			String edMinutes = "";

			String currentMintes = DateUtil.getNowDateTime("mm");
			if(currentMintes.equals("26") || currentMintes.equals("27") || currentMintes.equals("28") || currentMintes.equals("29") ||
				currentMintes.equals("30") || currentMintes.equals("31") || currentMintes.equals("32") || currentMintes.equals("33") || currentMintes.equals("34")) {
				yyyyMMddHH = DateUtil.getNowDateTime("yyyyMMddHH");
				stMinutes = "00";
				edMinutes = "29";
			} else if(currentMintes.equals("00") || currentMintes.equals("01") || currentMintes.equals("02") ||
					currentMintes.equals("03") || currentMintes.equals("04")) {
				yyyyMMddHH = oneHourBefore.format(formatter);
				stMinutes = "30";
				edMinutes = "59";
			} else if(currentMintes.equals("56") || currentMintes.equals("57") || currentMintes.equals("58") || currentMintes.equals("59")) {
				yyyyMMddHH = DateUtil.getNowDateTime("yyyyMMddHH");
				stMinutes = "30";
				edMinutes = "59";
			}

			if(stMinutes.equals("") || edMinutes.equals("")) {
				log.info("30minutes return");
				return;
			}
			Map<String, String> map = new HashMap<>();
			map.put("stDate", yyyyMMddHH + stMinutes + "00");
			map.put("edDate", yyyyMMddHH + edMinutes + "59");
			map.put("crncyCode", hanaFxRltm01Min.getEhgtDelngCrncyCode());

			prEhgtRltmMapper.insertPrEhgtPc30MinBasForProcedure(map);
//			prEhgtRltmMapper.hanaFxRltm30MinSchedulerMapper(hanaFxRltm30Min);
//			BeanUtils.copyProperties(new PrEhgtRltmBassVo(), hanaFxRltm30Min);
			hanaFxRltm30MinComp.setBeginPc(hanaFxRltm.getEndPc());
			hanaFxRltm30MinComp.setEndPc(hanaFxRltm.getEndPc());
			hanaFxRltm30MinComp.setTopPc(hanaFxRltm.getEndPc());
			hanaFxRltm30MinComp.setLwetPc(hanaFxRltm.getEndPc());
		}
	}

	//60분
	@Scheduled(cron = "0 0 0/1 * * *")
	public void hanaFxRltm60MinScheduler() throws Exception {
		if("Y".equals(hanaFxRltm60Min.getDataValideRltm())) {
			hanaFxRltm60Min.setDataValideRltm("N");
			String curTime = DateUtil.calDate("HHmmss");
			hanaFxRltm60Min.setOccrrncTime(curTime.substring(0, 2) + "0000");

			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHH");
			LocalDateTime localDateTime = LocalDateTime.now();
			LocalDateTime oneHourBefore = localDateTime.minusHours(1);

			String stDate = oneHourBefore.format(formatter) + "0000";
			String edDate = oneHourBefore.format(formatter) + "5959";

			Map<String, String> map = new HashMap<>();
			map.put("stDate", stDate);
			map.put("edDate", edDate);
			map.put("crncyCode", hanaFxRltm01Min.getEhgtDelngCrncyCode());

			prEhgtRltmMapper.insertPrEhgtPc60MinBasForProcedure(map);

			//prEhgtRltmMapper.hanaFxRltm60MinSchedulerMapper(hanaFxRltm60Min);
//			BeanUtils.copyProperties(new PrEhgtRltmBassVo(), hanaFxRltm60Min);
			hanaFxRltm60MinComp.setBeginPc(hanaFxRltm.getEndPc());
			hanaFxRltm60MinComp.setEndPc(hanaFxRltm.getEndPc());
			hanaFxRltm60MinComp.setTopPc(hanaFxRltm.getEndPc());
			hanaFxRltm60MinComp.setLwetPc(hanaFxRltm.getEndPc());
		}
	}

	//1일 : 월 ~ 토 매일 8시
	//환율 오후 8시까지만 업데이트
	@Scheduled(cron = "0 0 0 * * TUE-SAT")
	public void hanaFxRltmDay() {
		//오늘 날짜 INSERT
		prEhgtRltmMapper.hanaFxRltmDaySchedulerMapper(hanaFxRltmDay);
		//초기화 전 VO에 값 복사
		PrEhgtRltmBassVo tmpVo = new PrEhgtRltmBassVo();
		BeanUtils.copyProperties(hanaFxRltmDay, tmpVo);
		//초기화
//		BeanUtils.copyProperties(new PrEhgtRltmBassVo(), hanaFxRltmDay);
		hanaFxRltmDayComp.setBeginPc(hanaFxRltm.getEndPc());
		hanaFxRltmDayComp.setEndPc(hanaFxRltm.getEndPc());
		hanaFxRltmDayComp.setTopPc(hanaFxRltm.getEndPc());
		hanaFxRltmDayComp.setLwetPc(hanaFxRltm.getEndPc());

		//초기화 전 복사해놓은 VO(tmpVO)를 주, 월, 분기, 년 BEAN복사
		BeanUtils.copyProperties(tmpVo, hanaFxRltmWeek);
		BeanUtils.copyProperties(tmpVo, hanaFxRltmMon);
		BeanUtils.copyProperties(tmpVo, hanaFxRltmQuarter);
		BeanUtils.copyProperties(tmpVo, hanaFxRltmYear);

		//주, 월, 분기, 년에 대한 데이터를 매일 MERGE
		prEhgtRltmMapper.hanaFxRltmWeekSchedulerMapper(hanaFxRltmWeek);
		prEhgtRltmMapper.hanaFxRltmMonSchedulerMapper(hanaFxRltmMon);
		prEhgtRltmMapper.hanaFxRltmQuarterSchedulerMapper(hanaFxRltmQuarter);
		prEhgtRltmMapper.hanaFxRltmYearSchedulerMapper(hanaFxRltmYear);

		//하루 마감 후 실시간 차트용환율 초기화
		//BeanUtils.copyProperties(hanaFxRltm, hanaFxRltmComp);
		BeanUtils.copyProperties(new PrEhgtRltmBassVo(), hanaFxRltm);
		BeanUtils.copyProperties(new PrEhgtRltmBassVo(), hanaFxRltmComp);
	}
	//주 일요일 4시 주간 데이터 조기화
	@Scheduled(cron = "0 0 4 * * SUN")
	public void hanaFxRltmWeek() {
//		BeanUtils.copyProperties(new PrEhgtRltmBassVo(), hanaFxRltmWeek);
		hanaFxRltmWeekComp.setBeginPc(hanaFxRltm.getEndPc());
		hanaFxRltmWeekComp.setEndPc(hanaFxRltm.getEndPc());
		hanaFxRltmWeekComp.setTopPc(hanaFxRltm.getEndPc());
		hanaFxRltmWeekComp.setLwetPc(hanaFxRltm.getEndPc());
	}

	//달 매월1일 4시
	//매월 1일 4시
	@Scheduled(cron = "0 0 4 1 * *")
	public void hanaFxRltmMon() {
//		BeanUtils.copyProperties(new PrEhgtRltmBassVo(), hanaFxRltmMon);
		hanaFxRltmMonComp.setBeginPc(hanaFxRltm.getEndPc());
		hanaFxRltmMonComp.setEndPc(hanaFxRltm.getEndPc());
		hanaFxRltmMonComp.setTopPc(hanaFxRltm.getEndPc());
		hanaFxRltmMonComp.setLwetPc(hanaFxRltm.getEndPc());
	}

	//분기
	//3월 6월 9월 12월 말일의 데이터를 다음날짜에 초기화
	//1월 4월 7월 10월 4시
	@Scheduled(cron = "0 0 4 1 1,4,7,10 *")
	public void hanaFxRltmQuarter() {
//		BeanUtils.copyProperties(new PrEhgtRltmBassVo(), hanaFxRltmQuarter);
		hanaFxRltmQuarterComp.setBeginPc(hanaFxRltm.getEndPc());
		hanaFxRltmQuarterComp.setEndPc(hanaFxRltm.getEndPc());
		hanaFxRltmQuarterComp.setTopPc(hanaFxRltm.getEndPc());
		hanaFxRltmQuarterComp.setLwetPc(hanaFxRltm.getEndPc());
	}

	//년
	//매년 1월 1일 4시
	@Scheduled(cron = "0 0 4 1 1 *")
	public void hanaFxRltmYear() {
//		BeanUtils.copyProperties(new PrEhgtRltmBassVo(), hanaFxRltmYear);
		hanaFxRltmYearComp.setBeginPc(hanaFxRltm.getEndPc());
		hanaFxRltmYearComp.setEndPc(hanaFxRltm.getEndPc());
		hanaFxRltmYearComp.setTopPc(hanaFxRltm.getEndPc());
		hanaFxRltmYearComp.setLwetPc(hanaFxRltm.getEndPc());
	}

	@Scheduled(cron = "0 40 8 * * *")
	public void hanaFxStartInit() {
		if(hanaFxRltmComp.getEndPc() == null) {
			log.info("hanaFxRltmComp.getEndPc() == null");
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			//오늘 이전 데이터가 있는지 확인
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltm(compVo);
			//오늘 이전데이터가 없을때 : 이전 환율을 실시간 환율로 설정 (최초시작으로 최초설정)
			// 참고 : 실시간 가격도 동일하게 설정(종가를 시가, 저가, 고가, 저가로 설정)
			log.info("prEhgtRltmMapper.selectHanaFxRltm end");
			if(hanaFxVo != null && hanaFxRltmComp.getEhgtDelngCrncyCode() == null) {
				log.info("prEhgtRltmMapper.selectHanaFxRltmCur begin");
				//오늘날짜의 데이터가 있는지 확인
				PrEhgtRltmBassVo hanaFxVo2  = prEhgtRltmMapper.selectHanaFxRltmCur(compVo);
				log.info("prEhgtRltmMapper.selectHanaFxRltmCur end");
				//오늘 날짜의 데이터가 없을때 (배치 작업 후 날짜 변경 등)
				if(hanaFxVo2 == null) {
					log.info("prEhgtRltmMapper.selectHanaFxRltmPast begin");
					//오늘 이전 데이터 조회
					hanaFxVo2  = prEhgtRltmMapper.selectHanaFxRltmPast(compVo);
					log.info("prEhgtRltmMapper.selectHanaFxRltmPast end");
					//시가는 오늘 이전의 종가로 초기화
					hanaFxRltmComp.setBeginPc(hanaFxVo2.getEndPc());

					//날짜 변경시 실시간 환율은 일일 기준으로 새로 시작(영업일 기준 이전날짜의 마지막 종가로 설정)
					//실시간 환율 데이터와 비교를 위한 설정
					hanaFxRltmComp.setLwetPc(hanaFxVo2.getEndPc());
					hanaFxRltmComp.setTopPc(hanaFxVo2.getEndPc());
					hanaFxRltmComp.setEndPc(hanaFxVo2.getEndPc());

					log.info("hanaFxVo2 == null end");
				} else { //오늘 날짜의 데이터가 존재 할때 (서버 재기동 등)
					//오늘 날짜의 마지막 데이터를 비교를 위한 이전데이터로 저장
					log.info("else: copy");
					BeanUtils.copyProperties(  hanaFxVo2,      hanaFxRltmComp    );
				}
			}
		}

		//서버 시작시 null
		//실시간 데이터와 비교를 위해
		if(hanaFxRltm01MinComp.getEndPc() == null) {
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			//가장 최신의 1분 데이터 조회
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltm01Min(compVo);

			if(hanaFxVo != null) {
				hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
				BeanUtils.copyProperties(  hanaFxVo,  hanaFxRltm01MinComp  );
			}
		}
		if(hanaFxRltm30MinComp.getEndPc() == null) {
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltm30Min(compVo);

			if(hanaFxVo != null) {
				hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
				BeanUtils.copyProperties(  hanaFxVo,  hanaFxRltm30MinComp  );
			}

		}
		if(hanaFxRltm60MinComp.getEndPc() == null) {
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltm60Min(compVo);

			if(hanaFxVo != null) {
				hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
				BeanUtils.copyProperties(  hanaFxVo ,  hanaFxRltm60MinComp  );
			}
		}

		if(hanaFxRltmDayComp.getEndPc() == null) {
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltmDay(compVo);

			if(hanaFxVo != null) {
				hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
				BeanUtils.copyProperties(  hanaFxVo,      hanaFxRltmDayComp    );
			}
		}
		if(hanaFxRltmWeekComp.getEndPc() == null) {
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltmWeek(compVo);

			if(hanaFxVo != null) {
				hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
				BeanUtils.copyProperties(  hanaFxVo,  hanaFxRltmWeekComp  );
			}
		}
		if(hanaFxRltmMonComp.getEndPc() == null) {
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltmWeek(compVo);

			if(hanaFxVo != null) {
				hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
				BeanUtils.copyProperties(  hanaFxVo,  hanaFxRltmMonComp  );
			}
		}
		if(hanaFxRltmQuarterComp.getEndPc() == null) {
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltmQuarter(compVo);

			if(hanaFxVo != null) {
				hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
				BeanUtils.copyProperties( hanaFxVo ,  hanaFxRltmQuarterComp  );
			}
		}
		if(hanaFxRltmYearComp.getEndPc() == null) {
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltmYear(compVo);

			if(hanaFxVo != null) {
				hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
				BeanUtils.copyProperties(  hanaFxVo,  hanaFxRltmYearComp );
			}
		}
	}
}
