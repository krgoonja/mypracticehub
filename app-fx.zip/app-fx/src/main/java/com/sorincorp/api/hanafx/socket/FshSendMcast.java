package com.sorincorp.api.hanafx.socket;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

import com.digitide.xcube.XCPBMsg;
import com.sorincorp.api.util.BeanUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FshSendMcast {
	private static FshSendMcast fshSendMcast;

	MulticastSocket socket;
	int port;
	InetAddress address;

	public static synchronized FshSendMcast getInstance() {
		if (fshSendMcast == null) {
			fshSendMcast = new FshSendMcast();
		}

		return fshSendMcast;
	}

	private FshSendMcast() {
		init();
	}

	@SuppressWarnings("deprecation")
	private void init() {
		String hanafxIp = null;
		try {
			hanafxIp = "224.10.10.80";

			hanafxIp = BeanUtils.getProperty("hanafx.udp.ip", hanafxIp);
			port = Integer.valueOf(BeanUtils.getProperty("hanafx.udp.fshg.send-port", "9814"));
			socket = new MulticastSocket();
			address = InetAddress.getByName(hanafxIp);
			socket.joinGroup(address);
		} catch (IOException e) {
			log.error(this.getClass().getName(), e);
		}
		log.info("Hana FshSendMcast Socket OK");
		log.info("hanafxIp :{}", hanafxIp);
		log.info("hanafxPort :{}", port);
	}

	public synchronized void sendUdpData(XCPBMsg pbMsg) {
		try {
			String send_data = pbMsg.data();
			DatagramPacket packet = new DatagramPacket(send_data.getBytes(), pbMsg.length(), this.address, this.port);
			socket.send(packet);
		}catch(Exception e) {
			log.error("SendUdpData 에러:", e);
		}
		//pbMsg.clean();
	}
}
