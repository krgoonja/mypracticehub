package com.sorincorp.api.hanafx.de.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class GtxApiFxTenorVo {

	    /**
	     * 상품코드
	    */
	    private String prodCd;
	    /**
	     * 거래통화 코드
	    */
	    private String pairId;
	    /**
	     * 기간 코드
	    */
	    private String tenorCd;
	    /**
	     * 유효 상태
	    */
	    private String activeYn;
	    /**
	     * 수신 상태
	    */
	    private String statCd;
	    /**
	     * 결제일
	    */
	    private String valDt;
	    /**
	     * 추가 정보
	    */
	    private String comments;
	    /**
	     * 수정 일자
	    */
	    private String updDt;
	    /**
	     * 수정 시간
	    */
	    private String updTm;
}
