package com.sorincorp.api.util;

public class DelngEhgtConst {
	public final static String HANAFX_DATE_FORMAT1 = "yyyyMMdd";
	public final static String HANAFX_DATE_FORMAT2 = "yyyyMMddHHmmss";

	/* 거래용 환율 실시간 요청  */
	public final static String SEND_MAT_DT              = "00000000";
	public final static String SEND_AMT1                = "1000000";      //백만 달러
	public final static String SEND_MD_REQ_TP_OPEN 		= "O";
	public final static String SEND_MD_REQ_TP_CLOSE 	= "C";
	public final static String SEND_PROD_CD_SPT 		= "SPT";
	public final static String SEND_PROD_CD_FWD 		= "FWD";
	public final static String SEND_PAIR_ID_USD_KRW 	= "USD/KRW";
	public final static String SEND_CURR_CD_USD     	= "USD";
	public final static String SEND_STATUS_W        	= "W";

	public final static int SEND_MD_REQ_ID_LEN = 30;		/*	환율 요청 ID	S	30	환율 요청시 KEY 를 채번하여  환율 요청 시 사용		MDReqID	*/
															/*				모든 MD_REQ_ID 는 unique 해야함			*/
	public final static int SEND_MD_REQ_TP_LEN = 1;			/*	환율 요청 구분	S	1	O= open C= close		SubscriptionRequestType	*/
	public final static int SEND_PROD_CD_LEN = 3;			/*	상품코드	S	3	상품 코드 	SPT,FWD,FFF, FXS	SecurityDesc	*/
															/*				(현물환, 선물환  /  자유만기 선물환, FX 스왑 )			*/
	public final static int SEND_PAIR_ID_LEN = 7;			/*	거래 통화 코드	S	7	USD/KRW, EUR/KRW 등의 거래통화 코드	USD/JPY	Symbol	*/
	public final static int SEND_CURR_CD_LEN = 3;			/*	거래 통화	S	3	거래 기준 통화  CUR1 또는 CUR2	USD    KRW  EUR ..	Currency	*/
	public final static int SEND_VAL_DT_LEN = 8;			/*	Near 결제일	S	8	결제일 1	202100	SettlDate	*/
	public final static int SEND_MAT_DT_LEN = 8;			/*	Far   결제일 	S	8	결제일 2  , prod_cd 가 FXS 가 아니면 항상 000000 으로 사용	0	SettlDate2	*/
	public final static int SEND_AMT1_LEN  = 15;				/*	요청 금액	S	15	금액은 double 값이나  14.5 의 string 으로 covert 하여 사용	1.23457E+13	RequestedSize	*/
	public final static int SEND_USER_ID_LEN = 10;			/*	고객 딜러 ID	S	10	 환율 요청시 고객측에서 딜러 등 구분 코드를 사용	ZZZZZZ	NOT USE	*/
															/*				 (현재 버전은  FIX 요청시 사용하지 않음) 			*/
	public final static int SEND_REQ_TM_LEN = 14;			/*	이전 요청 연월일	S	14	YYYYMMDDHHMMSS	2.02105E+13	Table 용 field	*/
	public final static int SEND_STATUS_LEN = 1;			/*	환율 상태	S	1	W= 최초 요청후 1번 data 수신 이전, U=수신, D=거부 			*/



	/* 환율 실시간 응답  */
	public final static int RECV_MD_REQ_ID_LEN = 30;		/*	환율 요청 ID	S	30	환율 요청시 사용된 REQ_ID 		MDReqID	*/
	public final static int RECV_QT_STATUS_LEN = 1;			/*	환율 제공 상태	S	1	U =  up , D= down	U  D		*/
	public final static int RECV_QT_IDX_LEN = 60;			/*	환율 건별  index	S	60	실시간 제공 환율 의 건별 INDEX	SPTEUR/USDXXX_202112312312312321311	QuoteID	*/
	public final static int RECV_PROD_CD_LEN = 3;			/*	상품코드	S	3	상품 코드 	SPT,FWD,FFF, FXS	SecurityDesc	*/
															/*				(현물환, 선물환  /  자유만기 선물환, FX 스왑 )			*/
	public final static int RECV_PAIR_ID_LEN = 7;			/*	거래 통화 코드	S	7	USD/KRW, EUR/KRW 등의 거래통화 코드		Symbol	*/
	public final static int RECV_CURR_CD_LEN = 3;			/*	거래 통화	S	3	거래 기준 통화  CUR1 또는 CUR2	USD    KRW  EUR ..	Currency	*/
	public final static int RECV_VAL_DT_LEN = 8;			/*	Near 결제일		8	Spot / fwd 결제일	20210312	SettlDate	*/
	public final static int RECV_MAT_DT_LEN = 8;			/*	Far   결제일 		8	Swap far 결제일	20210320	SettlDate2	*/
	public final static int RECV_AMT1_LEN = 20;				/*	요청  금액	N	20	환율요청금액		RequestedSize	*/
	public final static int RECV_USER_ID_LEN = 10;			/*	고객 딜러 ID	S	10	 환율 요청시 고객측에서 딜러 등 구분 코드를 사용 		NOT USE	*/
	public final static int RECV_VALID_TIME_LEN = 6;		/*	 환율 유효 시간	S	6	시/분/초 의 환율 유효 시간	151210	ExpireTime	*/
	public final static int RECV_SPOT_BID_LEN = 10;			/*	현물환 매도 환율	N	10	거래가능한 현물환 매도 환율	1210.12	0.MDSpotRate	*/
	public final static int RECV_SPOT_ASK_LEN = 10;			/*	현물환 매수 환율	N	10	거래가능한 현물환 매수 환율	1210.15	1.MDSpotRate	*/
	public final static int RECV_NEAR_BID_LEN = 10;			/*	선물환 매도 환율	N	10	거래가능한 선물환 매도 환율	1210.1	0.MDNearRate	*/
	public final static int RECV_NEAR_ASK_LEN = 10;			/*	선물환 매수 환율	N	10	거래가능한 선물환 매수 환율	1210.16	1.MDNearRate	*/
	public final static int RECV_FAR_BID_LEN = 10;			/*	swap  매도 환율	N	10	거래가능한 swap  매도 환율	1210.1	0.MDFarRate	*/
	public final static int RECV_FAR_ASK_LEN = 10;			/*	Swap  매수 환율	N	10	거래가능한 swap 매수 환율	1210.16	1.MDFarRate	*/

}
