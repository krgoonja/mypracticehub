package com.sorincorp.api.hanafx.socket;

import com.digitide.xcube.XCPBMsg;

public class MessageCast {

	public static String msgDump(String title, XCPBMsg pbMsg) {
		StringBuffer buffer = new StringBuffer();
		buffer.append(String.format("XCPBMsg:: (%s)\n", new Object[] { title }));

		 byte[] byte_msg 	= pbMsg.msg();
		 int byte_msg_len 	= pbMsg.msg_len();

		 if (byte_msg != null && byte_msg_len > 29) {

			 int col_cnt    	= pbMsg.col_cnt();
			 buffer.append(String.format("col cnt [%d] msg_len %d [%s %s %s] \n", new Object[] {
					   Integer.valueOf(col_cnt)
					 , Integer.valueOf(byte_msg_len)
					 , pbMsg.type()
					 , pbMsg.svc()
					 , pbMsg.code() }));

		   StringBuffer stringBuffer = new StringBuffer();
		   int[] arrayOfInt = { 0 };
		   for (byte b = 0; b < col_cnt; b++) {

		     stringBuffer.setLength(0);
		     arrayOfInt[0] = 0;
		     if (pbMsg.get_value(b, stringBuffer, arrayOfInt) == 0) {
		    	 buffer.append(String.format("idx[" + Integer.toString(b) + "] [" + stringBuffer.toString() + "] len [" + Integer.toString(arrayOfInt[0]) + "]\n", new Object[0]));
		     } else {
		    	 buffer.append(String.format("idx[%d] is no data \n", new Object[] { Integer.valueOf(b) }));
		     }
		   }
		 } else {
		   buffer.append(String.format("msg too short : len (%d) < header (%d)\n", new Object[] { Integer.valueOf(byte_msg_len), Integer.valueOf(29) }));
		 }

		 buffer.append(String.format("XCPBMsg:: (%s) END\n", new Object[] { title }));

		 return buffer.toString();
	}
}
