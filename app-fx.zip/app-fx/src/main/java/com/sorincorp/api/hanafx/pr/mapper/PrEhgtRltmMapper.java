package com.sorincorp.api.hanafx.pr.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.api.hanafx.pr.model.PrEhgtRltmBassVo;

public interface PrEhgtRltmMapper {

	/* PR_EHGT_PC_RLTM_BAS 테이블*/
	int insertPrEhgtRltmBass(PrEhgtRltmBassVo vo) throws Exception;

	/* 아래 메소드는 미사용중임 */
	void updatePrEhgtRltmBass(PrEhgtRltmBassVo vo) throws Exception;

	PrEhgtRltmBassVo selectPrEhgtRltmBass(PrEhgtRltmBassVo vo) throws Exception;

	List<PrEhgtRltmBassVo> selectPrEhgtRltmBassList(PrEhgtRltmBassVo vo) throws Exception;

	void hanaFxRltm01MinSchedulerMapper(PrEhgtRltmBassVo vo);

	void hanaFxRltm30MinSchedulerMapper(PrEhgtRltmBassVo vo);

	void hanaFxRltm60MinSchedulerMapper(PrEhgtRltmBassVo vo);

	void hanaFxRltmDaySchedulerMapper(PrEhgtRltmBassVo hanaFxRltm);

	void hanaFxRltmWeekSchedulerMapper(PrEhgtRltmBassVo hanaFxRltmDay);

	void hanaFxRltmMonSchedulerMapper(PrEhgtRltmBassVo hanaFxRltmDay);

	void hanaFxRltmQuarterSchedulerMapper(PrEhgtRltmBassVo hanaFxRltmDay);

	void hanaFxRltmYearSchedulerMapper(PrEhgtRltmBassVo hanaFxRltmDay);

	PrEhgtRltmBassVo selectHanaFxRltm01Min(PrEhgtRltmBassVo vo);

	PrEhgtRltmBassVo selectHanaFxRltm30Min(PrEhgtRltmBassVo vo);
	
	PrEhgtRltmBassVo selectHanaFxRltm60Min(PrEhgtRltmBassVo compVo);
	
	PrEhgtRltmBassVo selectHanaFxRltmDay(PrEhgtRltmBassVo vo);
	
	PrEhgtRltmBassVo selectHanaFxRltmWeek(PrEhgtRltmBassVo vo);
	
	PrEhgtRltmBassVo selectHanaFxRltmMon(PrEhgtRltmBassVo compVo);

	PrEhgtRltmBassVo selectHanaFxRltmQuarter(PrEhgtRltmBassVo compVo);

	PrEhgtRltmBassVo selectHanaFxRltmYear(PrEhgtRltmBassVo compVo);

	PrEhgtRltmBassVo selectHanaFxRltm(PrEhgtRltmBassVo compVo);

	PrEhgtRltmBassVo selectHanaFxRltmCur(PrEhgtRltmBassVo compVo);

	PrEhgtRltmBassVo selectHanaFxRltmPast(PrEhgtRltmBassVo compVo);

	void insertPrEhgtStdrBass(PrEhgtRltmBassVo hanaFxRltm);
	
	void insertPrEhgtPc01MinBasForProcedure(Map<String, String> map) throws Exception;
	
	void insertPrEhgtPc30MinBasForProcedure(Map<String, String> map) throws Exception;
	
	void insertPrEhgtPc60MinBasForProcedure(Map<String, String> map) throws Exception;
	
}
