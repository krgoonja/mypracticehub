package com.sorincorp.api.hanafx.fs.service;

import com.digitide.xcube.XCPBMsg;
import com.sorincorp.api.hanafx.exception.FshgBizException;
import com.sorincorp.api.hanafx.fs.model.ApiIntDatReqVo;
import com.sorincorp.api.hanafx.fs.model.ApiIntDatResVo;
import com.sorincorp.api.hanafx.fs.model.ApiIntDatVo;
import com.sorincorp.api.hanafx.fs.model.OrOrderFshgBasVo;

public interface FshgService {

	void insertTestFshData(OrOrderFshgBasVo fshgBasVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 하나 fx 수신 데이터 파싱을 위해 디지타이드에서 저장해준 API_INT_DAT 테이블 조회한다.
	 * </pre>
	 * @date 2021. 12. 3.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 3.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	ApiIntDatVo selectApiIntDat(ApiIntDatVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 하나 fx 수신데이터를 파싱하여 API_INT_DAT_RES, LQD_INT_DAT_RES 테이블에 저장한다.
	 * </pre>
	 * @date 2021. 12. 3.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 3.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo1
	 * @param vo2
	 * @throws Exception
	 */
	void saveRecvFutureExchange(ApiIntDatVo vo1, ApiIntDatResVo vo2) throws Exception;

	/**
	 * <pre>
	 * 처리내용: UDP 전송을 위한 데이터 생성 및 테이블에 등록한다.
	 * </pre>
	 * @date 2021. 10. 26.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 26.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param reqVo
	 * @return
	 * @throws FshgBizException
	 * @throws Exception
	 */
	int executeApiIntId(OrOrderFshgBasVo reqVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 신규 선물환 요청 주문번호를 채번한다.
	 * </pre>
	 * @date 2021. 10. 20.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 20.			srec0032			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	String getFshgReqOrderNo() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 하나 fx 전송을 위해 XCPBMsg 데이타를 생성한다.
	 * </pre>
	 * @date 2021. 12. 3.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 3.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param seq
	 * @param reqVo
	 * @return
	 * @throws Exception
	 */
	ApiIntDatReqVo executeMakeApiIntData(int seq, OrOrderFshgBasVo reqVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 하나 fx 전송 데이터를 ApiIntDat, ApiIntDatReq 테디블에 저장한다.
	 * </pre>
	 * @date 2021. 12. 3.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 3.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param seq
	 * @param msg
	 * @param apiIntDatReqVo
	 * @throws Exception
	 */
	void insertApiIntDatWithXCPBMsg(int seq, XCPBMsg msg, ApiIntDatReqVo apiIntDatReqVo) throws Exception;
}
