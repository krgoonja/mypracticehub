package com.sorincorp.api.hanafx.mo.scheduler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.sorincorp.api.hanafx.de.service.DealingEhgtService;
import com.sorincorp.api.hanafx.mo.service.FxStateMonitorService;
import com.sorincorp.api.hanafx.socket.DelngEhgtSendMcast;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class FxScheduledTasks {

    @Autowired
    private DealingEhgtService sendService;

    @Autowired
    private DelngEhgtSendMcast delngEhgtSendMcast;

    @Autowired
    private FxStateMonitorService fxStateMonitorService;

    /**
     * 매일 새벽 시간에 1번 실행하게함.
     */
	@Scheduled(cron = "${hanafx.schedul.delngEhgt-init}")
    public void executeDelngEhgtInitJob(){
    	log.info("HanaFx DelngEhgt Init Job start. Thread-name:[" + Thread.currentThread().getName() + "]");
    	int result = 0;
    	try {
    		/*
    		 * schedule작업 의해 DB 초기화 후 새로운 현물환, 선물환의 요청을 등록한다.
    		 */
    		result = sendService.deleteGfxRfsReqWithSchedule();

    		delngEhgtSendMcast.execute();

    	}catch(Exception e) {
    		log.error("FxScheduledTasks Error1", e);
    	}
    	log.info("HanaFx Dayily Job end. delete Count:{}", result);
    }

	@Scheduled(cron = "${hanafx.schedul.fixclient-check-state}")
    public void executeFixClientStateCheckJob(){
    	log.info("HanaFx FixClient Check Job start. Thread-name:[" + Thread.currentThread().getName() + "]");
    	try {
    		fxStateMonitorService.checkFxServerStatus();
    	}catch(Exception e) {
    		log.error("FxScheduledTasks Error2", e);
    	}
    	log.info("HanaFx FixClient Check Job end.");
    }
}
