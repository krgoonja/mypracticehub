package com.sorincorp.api.hanafx.socket;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.digitide.xcube.XCPBMsg;
import com.sorincorp.api.hanafx.ExtrlCntcMngr;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component

public class DelngEhgtRecvMcast extends Thread {

	@Autowired
	private ExtrlCntcMngr extrlCntcMngr;

	@Value("${hanafx.udp.ip}")
	String hanafxIp;

	@Value("${hanafx.udp.delngEhgt.rcv-port}")
	int hanafxPort;

	private boolean isRun;

	MulticastSocket socket;

	InetAddress address;

	DatagramPacket packet;

	@PostConstruct
	public void init(){
		try {
			isRun = true;

			socket = new MulticastSocket(hanafxPort);
			address = InetAddress.getByName(hanafxIp);
			socket.joinGroup(address);
			byte[] buf = new byte[2048];
			packet = new DatagramPacket(buf, buf.length);
		}catch(Exception e) {
			log.error(this.getClass().getName(), e);
		}
		log.info("Hana DelngEhgtRecvMcast Socket OK");
		log.info("hanafx delngEhgt.rcv.Ip :{}", hanafxIp);
		log.info("hanafx delngEhgt.rcv.port :{}", hanafxPort);
	}

	public void close() {
		try {
			if(this.socket != null)
				this.socket.close();
		}catch(Exception e) {}
	}

	public void setRun(boolean runYn) {
		this.isRun = runYn;
	}

	public final void run() {
		log.info("FX-DelngEhgtRecvMcast Thread run.");
		while( isRun ) {
			try {
				socket.receive(packet);
				String msg = new String(packet.getData(), 0, packet.getLength());

				log.info("거래용 환율 Original Packet : \n[" + msg + "]");

				XCPBMsg pbMsg = new XCPBMsg();
				pbMsg.read(msg, msg.length());

				String svc   = pbMsg.svc();

				if("DQ".equals(svc)) {
					extrlCntcMngr.addDelngEhgtData(pbMsg);
				}else if("FR".equals(svc)) {
					extrlCntcMngr.addPrEhgtRltmData(pbMsg);
				}
			}catch(Exception e) {
				log.error(getClass().getName(), e);
			}
		}

		this.isRun = false;
		log.info("DelngEhgtRecvMcast is Terminated!!!");
	}

	@PreDestroy
	public void stopThread(){
		try {
			setRun(false);
			close();
			interrupt();

			Thread.sleep(50L);
		} catch (InterruptedException e) {
		}
	}
}
