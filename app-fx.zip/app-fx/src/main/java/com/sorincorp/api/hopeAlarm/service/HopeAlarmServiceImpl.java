package com.sorincorp.api.hopeAlarm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.hopeAlarm.mapper.HopeAlarmMapper;
import com.sorincorp.api.hopeAlarm.model.HopeAlarmVO;

@Service
public class HopeAlarmServiceImpl implements HopeAlarmService{

	@Autowired
	HopeAlarmMapper hopeAlramMapper;

	@Override
	public void insertHopePcNtcnSndngBasList(HopeAlarmVO vo) {
		hopeAlramMapper.insertHopePcNtcnSndngBasList(vo);
	}
	@Override
	public List<HopeAlarmVO> getHopePcNtcnSndngBas(HopeAlarmVO vo) {
		return hopeAlramMapper.getHopePcNtcnSndngBas(vo);
	}
	@Override
	public List<HopeAlarmVO> getHopePcZnNtcnSetupBas(HopeAlarmVO vo) {
		return hopeAlramMapper.getHopePcZnNtcnSetupBas(vo);
	}
	@Override
	public void insertHopePcZnNtcnSndngBasList(HopeAlarmVO vo) {
		hopeAlramMapper.insertHopePcZnNtcnSndngBasList(vo);
	}
	@Override
	public List<HopeAlarmVO> getHopePcZnNtcnSndngBas(HopeAlarmVO vo) {
		return hopeAlramMapper.getHopePcZnNtcnSndngBas(vo);
	}
	@Override
	public List<HopeAlarmVO> selectAppPushMember(HopeAlarmVO vo) {
		return hopeAlramMapper.selectAppPushMember(vo);
	}
	@Override
	public void updateHopePushAlarmReturn(HopeAlarmVO vo) {
		hopeAlramMapper.updateHopePushAlarmReturn(vo);
	}
	
}
