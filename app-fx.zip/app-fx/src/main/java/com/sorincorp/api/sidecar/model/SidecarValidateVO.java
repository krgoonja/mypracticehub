package com.sorincorp.api.sidecar.model;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Data;

@Data
public class SidecarValidateVO implements Serializable{
    
	private static final long serialVersionUID = 2849004139164064398L;
	
    /**
     * 발동 일자
    */
    private String motnDe;
    /**
     * 금속 코드
    */
    private String metalCode;
    /**
     * 발동 시작 일시
    */
    private java.sql.Timestamp motnBeginDt;
    /**
     * 발동 종료 일시
    */
    private java.sql.Timestamp motnEndDt;
    /**
     * 전일 가격
    */
    private java.math.BigDecimal bfrtPc;
    /**
     * 당일 가격
    */
    private java.math.BigDecimal todayPc;
    /**
     * 전일 대비 비율
    */
    private java.math.BigDecimal bfrtVersusRate;
    /**
     * 지속 시간
    */
    private String cntncTime;
    /**
     * 가격 표시 불가 시간
    */
    private String pcIndictImprtyTime;
    /**
     * 사이드카 발동여부 N.미발동, Y.발동, OP.유효기간 지남
     */
    private String motnAt;
}
