package com.sorincorp.api.util;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class HttpResponseVO implements Serializable{
	private static final long serialVersionUID = 2945924710279420277L;
	private boolean success = true;
	private String message;
	private String error;
	private String code;
	private Object data;
}
