package com.sorincorp.api.hanafx.fs.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties({"intrfcSn", "intId", "reqSeq", "rspnsSpclty", "frstRegisterId"})
public class ApiIntDatResVo {

   /**
    * 인터페이스 순번
   */
   private long intrfcSn;

   /**
    * 서비스 명
    */
   private String intId;

   /**
    * 최종 요청 순번
    */
   private int reqSeq;
    /**
    * MSG 유형
   */
   private String msgTp;
    /**
    * 고객사 주문번호
   */
   private String cliOrdNo;
    /**
    * 고객사 원주문번호
   */
   private String cliOrgOrdNo;
    /**
    * 은행  주문 번호
   */
   private String ordNo;

    /**
    * 주문 구분
   */
   private String ordTp;
    /**
    * 상품코드
   */
   private String prodCd;
    /**
    * 거래 통화 코드
   */
   private String pairId;
    /**
    * NEAR 결제일
   */
   private String valDt;
    /**
    * FAR 결제일
   */
   private String matDt;
    /**
    * 거래통화
   */
   private String currCd;
    /**
    * 고객사 딜러 ID
   */
   private String custId;
    /**
    * 매수/매도 구분
   */
   private String bsTp;
    /**
    * 주문 조건
   */
   private String condTp;
    /**
    * 주문 가격
   */
   private String limPx;
    /**
    * 주문 보조 조건
   */
   private String tif;
    /**
    * 주문 금액
   */
   private java.math.BigDecimal ordAmt;
    /**
    * 체결 금액
   */
   private java.math.BigDecimal tktAmt;
    /**
    * 미체결 금액
   */
   private java.math.BigDecimal remAmt;
    /**
    * 접수 상태
   */
   private String acptTp;
    /**
    * TICKET 번호
   */
   private String tktNo;
    /**
    * NEAR 환율
   */
   private java.math.BigDecimal nearRate;
    /**
    * NEAR 금액
   */
   private java.math.BigDecimal nearAmt;
    /**
    * FAR 환율
   */
   private java.math.BigDecimal farRate;
    /**
    * FAR 금액
   */
   private java.math.BigDecimal farAmt;
    /**
    * 응답 MSG
   */
   private String retText;

   /**
    * 응답 전문
    */
   private String rspnsSpclty;

    /**
    * 최초 등록자 아이디
   */
   private String frstRegisterId;
   /**
    * 최초 매매 기준 환율
    */
   private java.math.BigDecimal frstTrdeStdrEhgt;
   /**
    * 달러환산율
    */
   private java.math.BigDecimal usdCvtrate;

   public String print() {
	   StringBuilder builder = new StringBuilder();
	   	 builder.append("\n");
	     builder.append("INT_ID : [" +          intId 		+ "]\n");
	     builder.append("REQ_SEQ :[" +          reqSeq 		+ "]\n");
	     builder.append("MSG_TP :[" +           msgTp 		+ "]\n");
	     builder.append("CLI_ORD_NO :[" +       cliOrdNo 	+ "]\n");
	     builder.append("CLI_ORG_ORD_NO :[" +   cliOrgOrdNo + "]\n");
	     builder.append("ORD_NO :[" +           ordNo 		+ "]\n");
	     builder.append("ORD_TP :[" +           ordTp 		+ "]\n");
	     builder.append("PROD_CD :[" +          prodCd 		+ "]\n");
	     builder.append("PAIR_ID :[" +          pairId 		+ "]\n");
	     builder.append("VAL_DT :[" +           valDt 		+ "]\n");
	     builder.append("MAT_DT :[" +           matDt 		+ "]\n");
	     builder.append("CURR_CD :[" +          currCd 		+ "]\n");
	     builder.append("CUST_ID :[" +          custId 		+ "]\n");
	     builder.append("BS_TP :[" +            bsTp 		+ "]\n");
	     builder.append("COND_TP :[" +          condTp 		+ "]\n");
	     builder.append("LIM_PX :[" +           limPx 		+ "]\n");
	     builder.append("TIF :[" +              tif 		+ "]\n");
	     builder.append("ORD_AMT :[" +          ordAmt 		+ "]\n");
	     builder.append("TKT_AMT :[" +          tktAmt 		+ "]\n");
	     builder.append("REM_AMT :[" +          remAmt 		+ "]\n");
	     builder.append("ACPT_TP :[" +          acptTp 		+ "]\n");
	     builder.append("TKT_NO :[" +           tktNo 		+ "]\n");
	     builder.append("NEAR_RATE :[" +        nearRate 	+ "]\n");
	     builder.append("NEAR_AMT :[" +         nearAmt		+ "]\n");
	     builder.append("FAR_RATE :[" +         farRate 	+ "]\n");
	     builder.append("FAR_AMT :[" +          farAmt 		+ "]\n");
	     builder.append("RET_TEXT :[" +         retText 	+ "]");
	   return builder.toString();
   }
}
