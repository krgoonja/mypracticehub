package com.sorincorp.api.hanafx.pr.service;

import com.sorincorp.api.hanafx.pr.model.PrEhgtRltmBassVo;

public interface PrEhgtRltmService {
	void executePrEhgtRltmService(PrEhgtRltmBassVo vo) throws Exception;
}
