package com.sorincorp.api.hopeAlarm.model;

import lombok.Data;

@Data
public class HopeAlarmVO {
	/**
	    * 회원 번호
	   */
	private String mberNo;     
    /**
    * 금속 코드
   */
	private String metalCode;     
    /**
    * 아이템 순번
   */
	private int itmSn;             
    /**
    * 권역 대분류 코드
   */
	private String dstrctLclsfCode;   
    /**
    * 브랜드 그룹 코드
   */
	private String brandGroupCode;    
    /**
    * 브랜드 코드
   */
	private String brandCode;        
    /**
    * 희망가격
   */
	private String hopepc;            
    /**
    * 푸쉬 동의
   */
	private String pushAt;        
    /**
    * 푸쉬 알림 등록일
   */
	private String ntcnSndngRgsde;
    /**
    * 푸쉬 알림 발송일
   */
	private String ntcnSndngComptde;  
    /**
    * 업체 번호
   */
	private String entrpsNo;
    /**
    * 메세지 제목
   */
	private String msgtitle;      
    /**
    * 메세지
   */     
	private String msgcontents;  
    /**
    * 사용 여부
   */
	private String useAt;    
    /**
    * 삭제 일시
   */
	private java.sql.Timestamp deleteDt;      
    /**
    * 삭제 여부
   */
	private String deleteAt; 
    /**
    * 최초 등록자 아이디
   */
	private String frstRegisterId;    
    /**
    * 최초 등록 일시
   */
	private java.sql.Timestamp frstRegistDt; 
	/**
    * 최종 변경자 아이디
   */
	private String lastChangerId;    
    /**
    * 최종 변경 일시
   */
	private java.sql.Timestamp lastChangeDt;      
	
	/**
	 * 금속 영문 이름
	*/
	private String itmPrdlstEng;
	
	/**
	 * 조회시간
	 */
	private String nowData;
	
	/**
	 * 기기 고유번호
	 */
	private String deviceId;
	
	/**
	 * 휴대폰 번호
	 */
	private String moblphonNo;
}
