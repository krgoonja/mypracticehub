package com.sorincorp.api.hanafx.de.mapper;

import java.math.BigDecimal;
import java.util.List;

import com.sorincorp.api.hanafx.de.model.GfxRfsReqVo;
import com.sorincorp.api.hanafx.de.model.GfxRfsResVo;
import com.sorincorp.api.hanafx.de.model.GtxApiFxTenorVo;
import com.sorincorp.api.hanafx.de.model.OrFshgDdtmanBasVo;

public interface DealingEhgtMapper {

	/**
	 * <pre>
	 * 거래용 환율 RFS I/F
	 * </pre>
	 * @date 2023. 3. 2.
	 * @author srec0051
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int selectRegistRfsReqCount(GfxRfsReqVo vo) throws Exception;

	/**
	 * <pre>
	 * 주문_선물환 거래 일자 기본 테이블 조회
	 * </pre>
	 * @date 2023. 3. 2.
	 * @author srec0051
	 * @param exprtnMt
	 * @return
	 * @throws Exception
	 */
	String selectOrFshgDdtmanBasApplcDe(String exprtnMt) throws Exception;

	/**
	 * <pre>
	 * 거래용 환율 RFS I/F MAX ID 조회
	 * </pre>
	 * @date 2023. 3. 2.
	 * @author srec0051
	 * @return
	 * @throws Exception
	 */
	BigDecimal selectMaxMdReqId() throws Exception;

	/**
	 * <pre>
	 * GFX_RFS_REQ 테이블
	 * </pre>
	 * @date 2023. 3. 2.
	 * @author srec0051
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int insertGfxRfsReq(GfxRfsReqVo vo) throws Exception;

	/**
	 * <pre>
	 * 거래용 환율 RFS I/F 테이블 삭제
	 * </pre>
	 * @date 2023. 3. 2.
	 * @author srec0051
	 * @return
	 * @throws Exception
	 */
	int deleteGfxRfsReqWithSchedule() throws Exception;

	/**
	 * <pre>
	 * 거래용 환율 응답 I/F 테이블 등록
	 * </pre>
	 * @date 2023. 3. 2.
	 * @author srec0032
	 * @param vo
	 * @throws Exception
	 */
	void insertGfxRfsRes(GfxRfsResVo vo) throws Exception;

	/**
	 * <pre>
	 * 만기일 기준 최신 환율 조회
	 * </pre>
	 * @date 2023. 3. 2.
	 * @author srec0032
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	GfxRfsResVo selectRecentDataWithGfxRfsRes(GfxRfsResVo vo) throws Exception;

	/**
	 * <pre>
	 * 디지타이드에서 보내주는 유효한 상품 거래일을 조회한다.
	 * </pre>
	 * @date 2021. 12. 15.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 15.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	GtxApiFxTenorVo selectValidProdValDt(GtxApiFxTenorVo vo) throws Exception;

	/**
	 * <pre>
	 * 현물환 날짜(SPT) 기준으로 유효한 6개월치 선물환(FWD)날짜를 조회한다.
	 * </pre>
	 * @date 2021. 12. 15.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 15.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<OrFshgDdtmanBasVo> selectValidApplcDeList(OrFshgDdtmanBasVo vo) throws Exception;

}
