package com.sorincorp.api;

import org.slf4j.LoggerFactory;
import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import ch.qos.logback.classic.LoggerContext;

public class ShutdownHookConfiguration {
	public void destroy() {
		try {
			WebApplicationContext contex = ContextLoader.getCurrentWebApplicationContext();
			if(contex != null) {
				EhCacheManagerFactoryBean bean = (EhCacheManagerFactoryBean)contex.getBean(EhCacheManagerFactoryBean.class);
				bean.destroy();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}

		try {
			LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
			loggerContext.stop();
		}catch(Exception e) {
			e.printStackTrace();
		}
    }
}
