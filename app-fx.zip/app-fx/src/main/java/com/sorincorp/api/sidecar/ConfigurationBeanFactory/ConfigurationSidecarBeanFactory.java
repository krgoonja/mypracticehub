package com.sorincorp.api.sidecar.ConfigurationBeanFactory;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sorincorp.api.hanafx.pr.model.PrEhgtRltmBassVo;
import com.sorincorp.api.sidecar.model.SidecarVO;

@Configuration
public class ConfigurationSidecarBeanFactory {

	@Bean(name="sidecarVoList")
	public List<SidecarVO> sidecarVoList () {
		return new ArrayList<SidecarVO>();
	}
}
