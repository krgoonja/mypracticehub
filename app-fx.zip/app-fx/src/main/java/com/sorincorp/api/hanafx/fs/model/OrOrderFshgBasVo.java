package com.sorincorp.api.hanafx.fs.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class OrOrderFshgBasVo {
	    /**
	     * 사용자
	    */
	    private String userId;

	    /**
	     * 선물환 요청 주문 번호
	    */
	    private String fshgRequstOrderNo;

	    /**
	     * 신규 선물환 요청 주문 번호
	    */
	    private String newFshgRequstOrderNo;

	    /**
	     * 주문 번호
	    */
	    private String orderNo;
	    /**
	     * 주문 순번
	    */
	    private String orderSn;
	    /**
	     * 취소 교환 반품 번호
	    */
	    private String canclExchngRtngudNo;
	    /**
	     * 취소 교환 반품 순번
	    */
	    private String canclExchngRtngudSn;
	    /**
	     * 요청 선물환 상품 코드
	    */
	    private String requstFshgGoodsCode;
	    /**
	     * 요청 만기일자
	    */
	    private String requstExprtnde;
	    /**
	     * 요청 선물환 거래 통화 코드
	    */
	    private String requstFshgDelngCrncyCode;
	    /**
	     * 요청 주문 금액
	    */
	    private String requstOrderAmount;
	    /**
	     * 요청 포지션
	    */
	    private String requstPostn;
	    /**
	     * 요청 주문 조건
	    */
	    private String requstOrderCnd;
	    /**
	     * 요청 주문 가격
	    */
	    private String requstOrderPc;
	    /**
	     * 요청 환율 인덱스
	    */
	    private String requstEhgtIndx;
	    /**
	     * 응답 선물환 주문 번호
	    */
	    private String rspnsFshgOrderNo;
	    /**
	     * 응답 선물환 상태 코드
	    */
	    private String rspnsFshgSttusCode;
	    /**
	     * 응답 체결 금액
	    */
	    private String rspnsCnclsAmount;
	    /**
	     * 응답 미체결 금액
	    */
	    private String rspnsUncnclsAmount;
	    /**
	     * 응답 체결 번호
	    */
	    private String rspnsCnclsNo;
	    /**
	     * 응답 거래 환율
	    */
	    private String rspnsDelngEhgt;
	    /**
	     * 응답 거래 금액
	    */
	    private String rspnsDelngAmount;
	    /**
	     * 응답 메시지
	    */
	    private String rspnsMssage;

	    /**
	     *  재처리 여부
	     */
	    private String rehndlAt;
	    /**
	     * 삭제 일시
	    */
	    private java.sql.Timestamp deleteDt;
	    /**
	     * 삭제 여부
	    */
	    private String deleteAt;
	    /**
	     * 최초 등록자 아이디
	    */
	    private String frstRegisterId;
	    /**
	     * 최초 등록 일시
	    */
	    private java.sql.Timestamp frstRegistDt;
	    /**
	     * 최종 변경자 아이디
	    */
	    private String lastChangerId;
	    /**
	     * 최종 변경 일시
	    */
	    private java.sql.Timestamp lastChangeDt;

	    /** 최초 만기일자 */
	    private String frstExprtnde;
	    /** 요청 청산 번호 */
	    private String requstLqdNo;
	    /** 요청 메시지 구분 (청산:TO, 신규:NO, 취소:CO) */
	    private String requstMssageSe;

	    public String toPrint() {
	    	StringBuilder builder = new StringBuilder();
	    	builder.append("fshgRequstOrderNo=" 		+ fshgRequstOrderNo + "\n");
	    	builder.append("newFshgRequstOrderNo=" 		+ newFshgRequstOrderNo + "\n");
	    	builder.append("orderNo=" 					+ orderNo + "\n");
	    	builder.append("orderSn=" 					+ orderSn +  "\n");
	    	builder.append("canclExchngRtngudNo=" 		+ canclExchngRtngudNo + "\n");
	    	builder.append("canclExchngRtngudSn=" 		+ canclExchngRtngudSn  + "\n");
	    	builder.append("requstFshgGoodsCode=" 		+ requstFshgGoodsCode  + "\n");
	    	builder.append("requstExprtnde=" 			+ requstExprtnde + "\n");
	    	builder.append("requstFshgDelngCrncyCode=" 	+ requstFshgDelngCrncyCode + "\n");
	    	builder.append("requstOrderAmount=" 		+ requstOrderAmount+ "\n");
	    	builder.append("requstPostn="				+ requstPostn+ "\n");
	    	builder.append("requstOrderCnd=" 			+ requstOrderCnd+ "\n");
	    	builder.append("requstOrderPc=" 			+ requstOrderPc+ "\n");
	    	builder.append("requstEhgtIndx=" 			+ requstEhgtIndx+ "\n");
	    	builder.append("rspnsFshgOrderNo=" 			+ rspnsFshgOrderNo+ "\n");
			builder.append("rspnsFshgSttusCode=" 		+ rspnsFshgSttusCode + "\n");
			builder.append("rspnsCnclsAmount=" 			+ rspnsCnclsAmount+ "\n");
			builder.append("rspnsUncnclsAmount=" 		+ rspnsUncnclsAmount + "\n");
			builder.append("rspnsCnclsNo=" 				+ rspnsCnclsNo+ "\n");
			builder.append("rspnsDelngEhgt=" 			+ rspnsDelngEhgt + "\n");
			builder.append("rspnsDelngAmount=" 			+ rspnsDelngAmount+ "\n");
			builder.append("rspnsMssage="				+ rspnsMssage + "\n");
			builder.append("rehndlAt=" 					+ rehndlAt + "\n");
			builder.append("deleteAt=" 					+ deleteAt+ "\n");
			builder.append("requstLqdNo=" 				+ requstLqdNo+ "\n");
			builder.append("requstMssageSe=" 			+ requstMssageSe+ "\n");
			builder.append("frstRegisterId=" 			+ frstRegisterId+ "\n");
			builder.append("lastChangerId=" 			+ lastChangerId);

	    	return builder.toString();
	    }
}
