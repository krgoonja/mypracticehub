package com.sorincorp.api.hanafx.pr.service;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.api.hanafx.pr.mapper.PrEhgtRltmMapper;
import com.sorincorp.api.hanafx.pr.model.PrEhgtRltmBassVo;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.RedisUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("prEhgtRltmService")
@ComponentScan({"com.sorincorp.comm.*"})
public class PrEhgtRltmServiceImpl implements PrEhgtRltmService {
	@Autowired
	private PrEhgtRltmMapper prEhgtRltmMapper;
	@Autowired
	private RedisPubSubService redisPubSubService;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltm;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltm01Min;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltm30Min;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltm60Min;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmDay;
//	@Autowired
//	private PrEhgtRltmBassVo hanaFxRltmWeek;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmMon;
//	@Autowired
//	private PrEhgtRltmBassVo hanaFxRltmQuarter;
//	@Autowired
//	private PrEhgtRltmBassVo hanaFxRltmYear;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltm01MinComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltm30MinComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltm60MinComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmDayComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmWeekComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmMonComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmQuarterComp;
	@Autowired
	private PrEhgtRltmBassVo hanaFxRltmYearComp;
	
	@Autowired
	private RedisUtil redisUtil;


	@Value("${redisPubsub.crncyCode.KRW}")
	private String fxpcKRW;

	@Value("${redisPubsub.uri.fx}")
	private String fxUri;
	
	private String LAST_DATA_FXPC = "lastDataFxpc";	// 레디스로 발행한 마지막 실시간 환율 정보 이름(레디스에 저장할 이름)

	/**
	 ************************************************************************************************************
	 * ConfigurationHanaFxBeanFactory.java  : bean에 대한 정보 확인
	 * PrEhgtRltmScheduler.java : 스케쥴러 설정 및 정보 확인
	 * PrEhgtSendMcast.java : 테스트용 데이터 생성을 위한 클래스
	 * FxPrDataHandler.java : 데이터 수신 후 맵핑을 위한 클래스
	 *
	 * Comp는 실시간 대비 과거 가격 (실시간 직전의 가격)
	 *   (hanaFxRltm01MinComp, hanaFxRltm30MinComp, hanaFxRltm60MinComp, hanaFxRltmDayComp, hanaFxRltmWeekComp
	 *    hanaFxRltmMonComp, hanaFxRltmQuarterComp, hanaFxRltmYearComp)
	 * 실제 DB에 저장될 값들
	 *    (hanaFxRltm, hanaFxRltm01Min, hanaFxRltm30Min, hanaFxRltm60MinComp, hanaFxRltmDayComp, hanaFxRltmWeek
	 *     hanaFxRltmMon, hanaFxRltmQuarter, hanaFxRltmYear)
	 * PrEhgtRltmBassVo compareVo(PrEhgtRltmBassVo compVO, PrEhgtRltmBassVo socketVO)     : 가격 비교
	 * PrEhgtRltmBassVo compareVersus(PrEhgtRltmBassVo compVO, PrEhgtRltmBassVo socketVO) : 대비가격, 대비 비율 비교
	 *************************************************************************************************************
	 *
	 * 소켓 데이터가 들어왔을때 동작
	 * 1. 실시간데이터 유효성 체크
	 *     : 유효하지 않은 데이터가 들어왔을때 대비
	 * 2. REDIS 실시간 PUB
	 *     : END_PC만 필요 하기 때문에, 데이터가 유효할때 고가,저가 업데이트 하지 않고 PUB
	 * 3. 현재데이터, 이전데이터 초기화
	 *    (실시간, 01분, 30분, 60분, 일, 주, 월, 분기, 년 데이터 초기화)
	 *     : 최초수행, 서버 재기동 되었을때
	 * 4. 최신 전달 받은 데이터를 PrEhgtRltmBassVo hanaFxRltm에 설정
	 * 5. 실시간 차트용 환율 데이터 설정
	 *     : 시가, 고가, 저가가격 설정은 바로 직전 데이터와 비교, 종가는 최신 종가로 설정
	 *     : 대비가격은 영업일 기준으로 1일 전 데이터와 비교
	 * 6. 1분, 30분, 60분, 일 데이터 설정
	 *     : 시가, 고가, 저가가격 설정은 바로 직전 데이터와 비교, 종가는 최신 종가로 설정
	 *     : 대비가격은 실시간데이터 바로 직전 데이터와 비교
	 * 7. REDIS PUB
	 *     : 실시간 데이터와 비교후 설정된 1분, 30분, 60분, 일, 월 데이터 REDIS PUB
	 */

	@Override
	public void executePrEhgtRltmService(PrEhgtRltmBassVo vo) throws Exception {
		//유효하지 않은 데이터가 들어왔을때를 대비해 유효성 초기화 변경
		if(vo.getEhgtDelngCrncyCode() == null) {
			log.info("vo.getEhgtDelngCrncyCode() :: NULL");
			hanaFxRltm01Min.setDataValideRltm("N");
			hanaFxRltm30Min.setDataValideRltm("N");
			hanaFxRltm60Min.setDataValideRltm("N");

			return;
		}
		log.info("executePrEhgtRltmService in : ");
		//실시간 환율
		//redisPubSubService.publishMessage(fxUri + "/" + fxpcKRW, "ExchangeRateNM", vo);

		/********************************** 현재데이터, 이전데이터 초기화 : S **********************************/
		/*
		 * 오늘 이전 날짜의 데이터가 없을시에 최초 시작으로 간주함
		 *     : 비교를 위한 이전 데이터 'hanaFxRltmComp' 를 실시간 데이터로 설정 (이전가격이 없는 최초 상태로 이전가격과 실시간가격을 실시간 가격 설정)
		 * 오늘 이전 날짜의 데이터가 있고, 오늘 데이터가 없을때 (배치 등 의 작업 후 초기화된 상태)
		 *     : 비교를 위한 이전 데이터 'hanaFxRltmComp'의 시가, 고가, 종가, 저가 를 영업일기준 이전날짜 환율의 종가 설정
		 *       => 실시간 기본 환율은 일일 기준으로 매일 첫환율을 받았을때 이전날짜의 종가를 기준으로 비교 해야함
		 * 오늘 이전 날짜의 데이터가 있고, 오늘 데이터가 있을때 (서버 재기동)
		 *     : 오늘 날짜의 저장된 최신 환율로 설정, hanaFxRltmComp의 시가는 hanaFxRltmComp의 종가로 변경 ( 일일 기준으로 처음 시가를 맞춰 주기 위해)
		 *        => 현재 hanaFxRltm의 시가, 종가, 고가, 저가는 모두 종가로 들어오기때문에 일일 기준 시작가격을 설정해 갖고 있어야 함
		 *           가격 비교를 위한 compareVo() 메서드에서도 hanaFxRltm의 시가를 hanaFxRltmComp의 시가로 지속적으로 변경 설정해줌
		 * */
		if(hanaFxRltmComp.getEndPc() == null) {
			log.info("==> Start hanaFxRltmComp selectHanaFxRltm : "+ DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss.SSS"));
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			//오늘 이전 데이터가 있는지 확인
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltm(compVo);
			//오늘 이전데이터가 없을때 : 이전 환율을 실시간 환율로 설정 (최초시작으로 최초설정)
			// 참고 : 실시간 가격도 동일하게 설정(종가를 시가, 저가, 고가, 저가로 설정)
			log.info("<== End hanaFxRltmComp selectHanaFxRltm : "+ DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss.SSS"));
			if(hanaFxVo == null) {
				vo.setBeginPc(vo.getEndPc());
				vo.setLwetPc(vo.getEndPc());
				vo.setTopPc(vo.getEndPc());
				vo.setEndPc(vo.getEndPc());
				BeanUtils.copyProperties(  vo,      hanaFxRltmComp    );
			} else {  //오늘 이전의 데이터가 있을때
				if(hanaFxRltmComp.getEhgtDelngCrncyCode() == null) {
					//오늘날짜의 데이터가 있는지 확인
					log.info("==> Start hanaFxRltmComp selectHanaFxRltmCur : "+ DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss.SSS"));
					PrEhgtRltmBassVo hanaFxVo2  = prEhgtRltmMapper.selectHanaFxRltmCur(compVo);
					log.info("<== End hanaFxRltmComp selectHanaFxRltmCur : "+ DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss.SSS"));
					//오늘 날짜의 데이터가 없을때 (배치 작업 후 날짜 변경 등)
					if(hanaFxVo2 == null) {
						//오늘 이전 데이터 조회
						log.info("==> Start hanaFxRltmComp selectHanaFxRltmPast : "+ DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss.SSS"));
						hanaFxVo2  = prEhgtRltmMapper.selectHanaFxRltmPast(compVo);
						log.info("<== End hanaFxRltmComp selectHanaFxRltmPast : "+ DateUtil.getNowDateTime("yyyy-MM-dd HH:mm:ss.SSS"));
						//시가는 오늘 이전의 종가로 초기화
						hanaFxRltmComp.setBeginPc(hanaFxVo2.getEndPc());

						//날짜 변경시 실시간 환율은 일일 기준으로 새로 시작(영업일 기준 이전날짜의 마지막 종가로 설정)
						//실시간 환율 데이터와 비교를 위한 설정
						hanaFxRltmComp.setLwetPc(hanaFxVo2.getEndPc());
						hanaFxRltmComp.setTopPc(hanaFxVo2.getEndPc());
						hanaFxRltmComp.setEndPc(hanaFxVo2.getEndPc());

						//실시간 시가는 오늘이전의 종가( 영업일 기준 이전날짜의 마지막 종가는 오늘 첫환율의 시가)
						vo.setBeginPc(hanaFxVo2.getEndPc());
					} else { //오늘 날짜의 데이터가 존재 할때 (서버 재기동 등)
						//오늘 날짜의 마지막 데이터를 비교를 위한 이전데이터로 저장
						BeanUtils.copyProperties(  hanaFxVo2,      hanaFxRltmComp    );
						//시가를 이전 데이터의 시가로 설정
						vo.setBeginPc(hanaFxVo2.getBeginPc());
					}
				}
			}
		} else {
			//정상 데이터 수신시 직전의 시가로 실시간 시가 초기화
			if(hanaFxRltm.getBeginPc() != null)
				vo.setBeginPc(hanaFxRltm.getBeginPc());
			//vo.setBeginPc(hanaFxRltmComp.getBeginPc());
		}

		//서버 시작시 null
		//실시간 데이터와 비교를 위해
		if(hanaFxRltm01MinComp.getEndPc() == null) {
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			//가장 최신의 1분 데이터 조회
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltm01Min(compVo);
			if(hanaFxVo == null) {  //가장 최근 1분 데이터 없을때 (최초 설정)
				//실시간데이터 => 이전데이터 복사
				BeanUtils.copyProperties(  vo,      hanaFxRltm01MinComp    );
				//시가 초기화
				hanaFxRltm01MinComp.setBeginPc(vo.getBeginPc());
			} else { //서버 재기동
				//이전데이터 종가 => 이전데이터 시가 (1분 데이터 비교시 hanaFxRltm01Min의 시가를 설정해 주기 위함)
				//참고 : 스케쥴러에서 hanaFxRltm01Min.endPc => hanaFxRltm01MinComp.endPc 로 초기화
				hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
				BeanUtils.copyProperties(  hanaFxVo,  hanaFxRltm01MinComp  );
			}
			//실시간 데이터 => 1분 데이터 저장
			BeanUtils.copyProperties(  vo,  hanaFxRltm01Min  );
		}
		if(hanaFxRltm30MinComp.getEndPc() == null) {
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltm30Min(compVo);
			if(hanaFxVo == null) {
				BeanUtils.copyProperties(  vo,      hanaFxRltm30MinComp    );
				hanaFxRltm30MinComp.setBeginPc(vo.getBeginPc());
			} else {
				hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
				BeanUtils.copyProperties(  hanaFxVo,  hanaFxRltm30MinComp  );
			}
		}
		if(hanaFxRltm60MinComp.getEndPc() == null) {
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltm60Min(compVo);
			if(hanaFxVo == null) {
				BeanUtils.copyProperties(  vo,       hanaFxRltm60MinComp    );
				//시가 초기화
				hanaFxRltm60MinComp.setBeginPc(vo.getBeginPc());
			} else {
				hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
				BeanUtils.copyProperties(  hanaFxVo ,  hanaFxRltm60MinComp  );
			}
		}
		if(hanaFxRltmDayComp.getEndPc() == null) {			
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltmDay(compVo);
			if(hanaFxVo == null) {
				hanaFxVo = prEhgtRltmMapper.selectHanaFxRltm(compVo);
				if(hanaFxVo == null) {
					BeanUtils.copyProperties(  vo,      hanaFxRltmDayComp    );
				} else {
					hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
					BeanUtils.copyProperties(  hanaFxVo,      hanaFxRltmDayComp    );
				}

			} else {
				BeanUtils.copyProperties(  hanaFxVo,  hanaFxRltmDayComp  );
			}			
		}
		if(hanaFxRltmWeekComp.getEndPc() == null) {
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltmWeek(compVo);
			if(hanaFxVo == null) {
				BeanUtils.copyProperties(  vo,      hanaFxRltmWeekComp    );
			} else {
				hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
				BeanUtils.copyProperties(  hanaFxVo,  hanaFxRltmWeekComp  );
			}
			//시가 초기화
			hanaFxRltmWeekComp.setBeginPc(vo.getBeginPc());
		}
		if(hanaFxRltmMonComp.getEndPc() == null) {
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltmWeek(compVo);
			if(hanaFxVo == null) {
				BeanUtils.copyProperties(  vo,      hanaFxRltmMonComp    );
			} else {
				hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
				BeanUtils.copyProperties(  hanaFxVo,  hanaFxRltmMonComp  );
			}
			hanaFxRltmMonComp.setBeginPc(vo.getBeginPc());
		}
		if(hanaFxRltmQuarterComp.getEndPc() == null) {
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltmQuarter(compVo);
			if(hanaFxVo == null) {
				BeanUtils.copyProperties( vo,       hanaFxRltmQuarterComp    );
			} else {
				hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
				BeanUtils.copyProperties( hanaFxVo ,  hanaFxRltmQuarterComp  );
			}
			//시가 초기화
			hanaFxRltmQuarterComp.setBeginPc(vo.getBeginPc());
		}
		if(hanaFxRltmYearComp.getEndPc() == null) {
			PrEhgtRltmBassVo compVo = new PrEhgtRltmBassVo();
			compVo.setEhgtDelngCrncyCode(fxpcKRW);
			PrEhgtRltmBassVo hanaFxVo = prEhgtRltmMapper.selectHanaFxRltmYear(compVo);
			if(hanaFxVo == null) {
				BeanUtils.copyProperties(  vo,      hanaFxRltmYearComp   );
			} else {
				hanaFxVo.setBeginPc(hanaFxVo.getEndPc());
				BeanUtils.copyProperties(  hanaFxVo,  hanaFxRltmYearComp );
			}
			//시가 초기화
			hanaFxRltmYearComp.setBeginPc(vo.getBeginPc());
		}
		/********************************** 현재데이터, 이전데이터 초기화 : S **********************************/
		log.info("REDIS PUB : Pre");
		//실시간 데이터 초기화
		BeanUtils.copyProperties(vo, hanaFxRltm);
		
		
		log.info("hanaFxRltm : " + hanaFxRltm);
		
		log.info("hanaFxRltmDayComp : " + hanaFxRltmDayComp);
		log.info("hanaFxRltmComp : " + hanaFxRltmComp);

		/********************************** 실시간 차트용 환율 데이터 설정 : S **********************************/
	    //대비가격 : 실시간 환율 종가 - 이전 환율 종가
		BigDecimal versusFlctsPc = hanaFxRltm.getEndPc().subtract(hanaFxRltmDayComp.getEndPc());
		hanaFxRltm.setVersusPc(versusFlctsPc);
		//대비등락코드 2: 상승 , 3: 보합, 4:하락
		String versusFlctsCd = versusFlctsPc.compareTo(new BigDecimal("0")) > 0 ? "2" : versusFlctsPc.compareTo(new BigDecimal("0")) == 0 ? "3" : "4";
		hanaFxRltm.setVersusFlctsCode(versusFlctsCd);
	    //대비비율 : 전일대비비율 * 100 / 실시간 종가
		//hanaFxRltm.setVersusRate(hanaFxRltm.getEndPc().equals(new BigDecimal("0")) ?  new BigDecimal("0") : hanaFxRltmDayComp.getVersusPc().multiply(new BigDecimal("100")).divide(hanaFxRltm.getEndPc(), 6, BigDecimal.ROUND_CEILING));
		hanaFxRltm.setVersusRate(hanaFxRltm.getEndPc().equals(new BigDecimal("0")) ?  new BigDecimal("0") : (versusFlctsPc.divide(hanaFxRltmDayComp.getEndPc(), 6, RoundingMode.HALF_EVEN)).multiply(new BigDecimal("100")));
		//최고 가격 : 실시간종가, 이전 탑가 비교 후 높은 가격
		hanaFxRltm.setTopPc ( hanaFxRltm.getEndPc().compareTo( hanaFxRltmComp.getTopPc()  ) > 0 ? hanaFxRltm.getEndPc()      : hanaFxRltmComp.getTopPc()    );
		//최고 가격 : 실시간종가, 이전 저가 비교 후 낮은 가격
		hanaFxRltm.setLwetPc( hanaFxRltm.getEndPc().compareTo( hanaFxRltmComp.getLwetPc() ) > 0 ? hanaFxRltmComp.getLwetPc() : hanaFxRltm.getEndPc()        );

		// 실시간 데이터 발행하기 전에 레디스에 한번 저장하기 (key-value 형태), 레디스로 발행한 마지막 실시간 환율 정보
		ObjectMapper mapper = new ObjectMapper(); 
		String hanaFxRltmJsonString = mapper.writeValueAsString(hanaFxRltm);
		redisUtil.setDataJson(LAST_DATA_FXPC, hanaFxRltmJsonString);
		
		redisPubSubService.publishMessage(fxUri + "/" + fxpcKRW, "ExchangeRateNM", hanaFxRltm);
		//실시간데이터 DB INSERT
		prEhgtRltmMapper.insertPrEhgtStdrBass(hanaFxRltm);
		prEhgtRltmMapper.insertPrEhgtRltmBass(hanaFxRltm);

		log.info("REDIS PUB : Pre");
		//DB INSERT 후 다음번 실시간 데이터와 비교 하기의해 hanaFxRltm 를 hanaFxRltmComp에 복사
		BeanUtils.copyProperties(hanaFxRltm, hanaFxRltmComp);
		/********************************** 실시간 차트용 환율 데이터 설정 : E **********************************/

		/************************************** 1분, 30분, 60분, 일 데이터 설정 : S *************************************/
		//hanaFxRltm01MinComp 에 대한 정보를 잃지 않기 위해 임시 변수 선언 후 임시변수에 복사
		PrEhgtRltmBassVo tempVO = new PrEhgtRltmBassVo();
		BeanUtils.copyProperties(hanaFxRltm01MinComp, tempVO);
		//대비가격,  대비 비율 설정
		BeanUtils.copyProperties(  compareVersus ( tempVO,   hanaFxRltm ),  tempVO  );
		//가격 설정 (시가, 고가, 저가, 종가)
		BeanUtils.copyProperties(  compareVo  ( tempVO,   hanaFxRltm ),  tempVO  );
		//배치 작업에서 INSERT 될 VO(hanaFxRltm01Min) 에 복사
		BeanUtils.copyProperties(  tempVO,  hanaFxRltm01Min );
		BeanUtils.copyProperties(  hanaFxRltm01Min,  hanaFxRltm01MinComp );

		tempVO = new PrEhgtRltmBassVo();
		BeanUtils.copyProperties(hanaFxRltm30MinComp, tempVO);
		BeanUtils.copyProperties(  compareVersus ( tempVO,   hanaFxRltm ),  tempVO  );
		BeanUtils.copyProperties(  compareVo  ( tempVO,   hanaFxRltm ),  tempVO  );
		BeanUtils.copyProperties(  tempVO,  hanaFxRltm30Min );
		BeanUtils.copyProperties(  hanaFxRltm30Min,  hanaFxRltm30MinComp );

		tempVO = new PrEhgtRltmBassVo();
		BeanUtils.copyProperties(hanaFxRltm60MinComp, tempVO);
		BeanUtils.copyProperties(  compareVersus ( tempVO,   hanaFxRltm ),  tempVO  );
		BeanUtils.copyProperties(  compareVo  ( tempVO,   hanaFxRltm ),  tempVO  );
		BeanUtils.copyProperties(  tempVO,  hanaFxRltm60Min );
		BeanUtils.copyProperties(  hanaFxRltm60Min,  hanaFxRltm60MinComp );

		tempVO = new PrEhgtRltmBassVo();
		BeanUtils.copyProperties(hanaFxRltmDayComp, tempVO);
		BeanUtils.copyProperties(  compareVersus ( tempVO,   hanaFxRltm ),  tempVO  );
		BeanUtils.copyProperties(  compareVo  ( tempVO,   hanaFxRltm ),  tempVO  );
		BeanUtils.copyProperties(  tempVO,  hanaFxRltmDay );
		/************************************** 1분, 30분, 60분, 일 데이터 설정 : E *************************************/


		//1분, 30분, 60분 유효성 초기화 (환율이 들어오지 않을시에 배치가 돌지 않게 하기 위해 선언)
		hanaFxRltm01Min.setDataValideRltm("Y");
		hanaFxRltm30Min.setDataValideRltm("Y");
		hanaFxRltm60Min.setDataValideRltm("Y");

		/************************************** REDIS PUB : S *************************************/
		//1분 REDIS PUB
		//서버 시간 기준으로 저장하기 위해 선언
		String curTime = DateUtil.calDate("HHmmss");
		//시분을 제외한 초를 '00'으로 변환 (HHmmss => HHmm + '00')
		hanaFxRltm01Min.setOccrrncTime(curTime.substring(0, 4) + "00");
		redisPubSubService.publishMessage(fxUri + "/" + fxpcKRW + "/01", "ExchangeRateNM", hanaFxRltm01Min);

		//30분 REDIS
		//서버 시간이 59분일때
		if(Integer.parseInt(hanaFxRltm30Min.getOccrrncTime().substring(2, 4)) > 29 ) {
			String hour = curTime.substring(0, 2);
//			int previousHour = Integer.parseInt(hour) - 1;
//			hour = String.format("%02d", previousHour);
			hanaFxRltm30Min.setOccrrncTime(hour + "3000");
		} else { //서버 시간이 29분일때
			hanaFxRltm30Min.setOccrrncTime(curTime.substring(0, 2) + "0000");
		}
		redisPubSubService.publishMessage(fxUri + "/" + fxpcKRW + "/30", "ExchangeRateNM", hanaFxRltm30Min);

		//60분 REDIS PUB
		hanaFxRltm60Min.setOccrrncTime(curTime.substring(0, 2) + "0000");
		redisPubSubService.publishMessage(fxUri + "/" + fxpcKRW + "/60", "ExchangeRateNM", hanaFxRltm60Min);

		//일 REDIS PUB
		redisPubSubService.publishMessage(fxUri + "/" + fxpcKRW + "/DE", "ExchangeRateNM", hanaFxRltmDay);

		//월 REDIS PUB
		redisPubSubService.publishMessage(fxUri + "/" + fxpcKRW + "/MT", "ExchangeRateNM", hanaFxRltmMon);
		/************************************** REDIS PUB : E *************************************/
		log.info("REDIS PUB : E");
	}
	//시가, 고가, 종가 설정
	//compVO 현재 바로 이전 값, socketVO 실시간 값
	public PrEhgtRltmBassVo compareVo(PrEhgtRltmBassVo compVO, PrEhgtRltmBassVo socketVO) {
		if(compVO.equals(socketVO) == false) {
			PrEhgtRltmBassVo vo = new PrEhgtRltmBassVo();
			BeanUtils.copyProperties( compVO,  vo );

			vo.setEhgtDelngCrncyCode(socketVO.getEhgtDelngCrncyCode());
			vo.setOccrrncDe(socketVO.getOccrrncDe());
			vo.setOccrrncTime(socketVO.getOccrrncTime());
			vo.setEhgtPcRltmSn(socketVO.getEhgtPcRltmSn());
			vo.setEndPc(socketVO.getEndPc());
			vo.setBeginPc(compVO.getBeginPc());

			vo.setTopPc( compVO.getTopPc().compareTo( socketVO.getEndPc() ) > 0 ? compVO.getTopPc() : socketVO.getEndPc() );
			vo.setLwetPc( compVO.getLwetPc().compareTo( socketVO.getEndPc() ) > 0 ? socketVO.getEndPc() : compVO.getLwetPc() );


//			System.out.println(compVO.getTopPc());
//			System.out.println(socketVO.getEndPc());
//			System.out.println(vo.getTopPc());
			return vo;
		} else {
			return compVO;
		}
	}

	//대비가격, 대비 비율 비교
	//compVO 현재 바로 이전 값, socketVO 실시간 값
	public PrEhgtRltmBassVo compareVersus(PrEhgtRltmBassVo compVO, PrEhgtRltmBassVo socketVO) {
		if(compVO.equals(socketVO) == false) {
			PrEhgtRltmBassVo vo = new PrEhgtRltmBassVo();
			BeanUtils.copyProperties( compVO,  vo );

			vo.setVersusPc(socketVO.getEndPc().subtract(compVO.getEndPc()));   //최신(socket) 종가 - 과거(compVO) 종가
			vo.setVersusRate(  compVO.getEndPc().equals(new BigDecimal("0")) ?  new BigDecimal("0") : socketVO.getVersusPc().multiply(new BigDecimal("100")).divide(compVO.getEndPc(), 6, BigDecimal.ROUND_CEILING));
			return vo;
		} else {
			return compVO;
		}
	}
}