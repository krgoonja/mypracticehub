package com.sorincorp.api.hanafx.exception;

/**
 * FshgBizException.java
 * 하나fx 선물환과의 Business Exception을 처리한다.
 * @version
 * @since 2021. 7. 7.
 * @author srec0032
 */
@SuppressWarnings("serial")
public class FshgBizException extends RuntimeException{

	private String errorCode = "";

	public FshgBizException(String errorCode) {
		super();
		this.errorCode = errorCode;
	}

	public FshgBizException(String errorCode, String message) {
		super(message);
		this.errorCode = errorCode;
	}

	public FshgBizException(String errorCode, Throwable cause) {
		super(cause);
		this.errorCode = errorCode;
	}

	public FshgBizException(String errorCode, String message, Throwable cause) {
		super(message, cause);
		this.errorCode = errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}
}
