package com.sorincorp.api.hanafx.socket;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sorincorp.api.hanafx.fs.handler.FxFsDataHandler;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class FshRecvMcast extends Thread {

	@Autowired
	private FxFsDataHandler dataHandler;

	@Value("${hanafx.udp.ip}")
	private String hanafxIp;

	@Value("${hanafx.udp.fshg.rcv-port}")
	int hanafxPort;

	private boolean isRun;
	private MulticastSocket socket;
	private InetAddress address;
	private DatagramPacket packet;

	@PostConstruct
	public void init(){
		try {
			isRun = true;
			socket = new MulticastSocket(hanafxPort);
			address = InetAddress.getByName(hanafxIp);
			socket.joinGroup(address);
			byte[] buf = new byte[2048];
			packet = new DatagramPacket(buf, buf.length);
		}catch(Exception e) {
			e.printStackTrace();
		}
		log.info("Hana FshRecvdMcast Socket OK");
		log.info("hanafxIp :" + hanafxIp);
		log.info("port :" + hanafxPort);
	}


	public void close() {
		try {
			if(this.socket != null)
				this.socket.close();
		}catch(Exception e) {}
	}

	public void setRun(boolean runYn) {
		this.isRun = runYn;
	}

	public final void run() {
		log.info("FX-FshRecvMcast Thread run.");

		while( isRun ) {
			try {
				socket.receive(packet);
				/* 한글 인코딩 해야 하는지 */
				String msg = new String(packet.getData(), 0, packet.getLength());
				/* pbMsg Parsing */
				log.info("Original Packet : [{}]", msg);

				dataHandler.recvFshNewOrder(msg);
			}catch(Exception e) {
				log.error(this.getClass().getName(), e);
			}
		}

		this.isRun = false;
		log.info("FshRecvMcast is Terminated!!!");
	}

	@PreDestroy
	public void stopThread(){
		try {
			setRun(false);
			close();
			interrupt();

			Thread.sleep(50L);
		} catch (InterruptedException e) {
		}
	}
}
