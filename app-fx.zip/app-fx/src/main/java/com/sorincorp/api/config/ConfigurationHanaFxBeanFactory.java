package com.sorincorp.api.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sorincorp.api.hanafx.pr.model.PrEhgtRltmBassVo;

@Configuration
public class ConfigurationHanaFxBeanFactory {

	@Bean(name="hanaFxRltm")
	public PrEhgtRltmBassVo hanaFxRltm () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltm01Min")
	public PrEhgtRltmBassVo hanaFxRltm01Min () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltm30Min")
	public PrEhgtRltmBassVo hanaFxRltm30Min () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltm60Min")
	public PrEhgtRltmBassVo hanaFxRltm60Min () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltmDay")
	public PrEhgtRltmBassVo hanaFxRltmDay () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltmWeek")
	public PrEhgtRltmBassVo hanaFxRltmWeek () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltmMon")
	public PrEhgtRltmBassVo hanaFxRltmMon () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltmQuarter")
	public PrEhgtRltmBassVo hanaFxRltmQuarter () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltmYear")
	public PrEhgtRltmBassVo hanaFxRltmYear () {
		return new PrEhgtRltmBassVo();
	}
	
	
	@Bean(name="hanaFxRltmComp")
	public PrEhgtRltmBassVo hanaFxRltmComp () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltm01MinComp")
	public PrEhgtRltmBassVo hanaFxRltm01MinComp () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltm30MinComp")
	public PrEhgtRltmBassVo hanaFxRltm30MinComp () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltm60MinComp")
	public PrEhgtRltmBassVo hanaFxRltm60MinComp () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltmDayComp")
	public PrEhgtRltmBassVo hanaFxRltmDayComp () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltmWeekComp")
	public PrEhgtRltmBassVo hanaFxRltmWeekComp () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltmMonComp")
	public PrEhgtRltmBassVo hanaFxRltmMonComp () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltmQuarterComp")
	public PrEhgtRltmBassVo hanaFxRltmQuarterComp () {
		return new PrEhgtRltmBassVo();
	}
	@Bean(name="hanaFxRltmYearComp")
	public PrEhgtRltmBassVo hanaFxRltmYearComp () {
		return new PrEhgtRltmBassVo();
	}
	
}
