package com.sorincorp.api.hanafx.mo.mapper;

import java.util.List;

import com.sorincorp.api.hanafx.mo.model.FwSvcMonVo;

public interface FwSvcMonMapper {
	List<FwSvcMonVo> selectFxServerStateList() throws Exception;

	FwSvcMonVo selectFxServerState(FwSvcMonVo vo) throws Exception;
}