package com.sorincorp.api.hanafx.fs.model;

import java.io.Serializable;

import com.digitide.xcube.XCPBMsg;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
@JsonIgnoreProperties({"intrfcSn", "intId", "reqSeq", "requstSpclty", "frstRegisterId", "xcpbMsg"})
public class ApiIntDatReqVo implements Serializable{

	private static final long serialVersionUID = -8117855887583680534L;

	private XCPBMsg xcpbMsg;

    /**
    * MSG 유형
   */
   private String msgTp;
    /**
    * 고객사 주문번호
   */
   private String cliOrdNo;
    /**
    * 상품코드
   */
   private String prodCd;
    /**
    * 거래 통화 코드
   */
   private String pairId;
    /**
    * NEAR 결제일
   */
   private String valDt;
    /**
    * FAR 결제일
   */
   private String matDt;
    /**
    * 거래통화
   */
   private String currCd;
    /**
    * NEAR 금액
   */
   private java.math.BigDecimal nearAmt;
    /**
    * FAR 금액
   */
   private java.math.BigDecimal farAmt;
    /**
    * 매수/매도 구분
   */
   private String bsTp;
    /**
    * 주문 조건
   */
   private String condTp;
    /**
    * 주문 보조 조건
   */
   private String tif;
    /**
    * 주문 가격
   */
   private String limPx;
    /**
    * 환율 INDEX
   */
   private String qtIdx;
    /**
    * 요청 시간
   */
   private String enterTm;

/*********************************************************************/
   /**
    * 인터페이스 순번
   */
   private long intrfcSn;
    /**
    * 서비스 명
   */
   private String intId;
    /**
    * 최종 요청 순번
   */
   private int reqSeq;

    /**
    * 요청 전문
   */
   private String requstSpclty;
    /**
    * 최초 등록자 아이디
   */
   private String frstRegisterId;

  /**
   * 요청 청산 번호
  */
  private String orgCliOrdNo;

   public String print() {
	   StringBuilder builder = new StringBuilder();
		builder.append("INT_ID : [" 		+ intId + "]\n");
		builder.append("REQ_SEQ : [" 		+ reqSeq + "]\n");
		builder.append("MSG_TP : [" 		+ msgTp + "]\n");
		builder.append("CLI_ORD_NO : [" 	+ cliOrdNo + "]\n");
		builder.append("ORG_CLI_ORD_NO : [" 	+ orgCliOrdNo + "]\n");
		builder.append("PROD_CD : [" 		+ prodCd + "]\n");
		builder.append("PAIR_ID : [" 		+ pairId + "]\n");
		builder.append("VAL_DT : [" 		+ valDt + "]\n");
		builder.append("MAT_DT : [" 		+ matDt + "]\n");
		builder.append("CURR_CD : [" 		+ currCd + "]\n");
		builder.append("NEAR_AMT : [" 		+ nearAmt + "]\n");
		builder.append("FAR_AMT : [" 		+ farAmt + "]\n");
		builder.append("BS_TP : [" 			+ bsTp + "]\n");
		builder.append("COND_TP : [" 		+ condTp + "]\n");
		builder.append("TIF : [" 			+ tif + "]\n");
		builder.append("LIM_PX : [" 		+ limPx + "]\n");
		builder.append("QT_IDX : [" 		+ qtIdx + "]\n");
		builder.append("ENTER_TM : [" 		+ enterTm +"]");

		return builder.toString();
   }
}
