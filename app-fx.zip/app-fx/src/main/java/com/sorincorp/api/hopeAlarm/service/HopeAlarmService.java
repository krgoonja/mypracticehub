package com.sorincorp.api.hopeAlarm.service;

import java.util.List;

import com.sorincorp.api.hopeAlarm.model.HopeAlarmVO;

public interface HopeAlarmService {
	public void insertHopePcNtcnSndngBasList(HopeAlarmVO vo);
	
	public List<HopeAlarmVO> getHopePcNtcnSndngBas(HopeAlarmVO vo);
	
	public List<HopeAlarmVO> getHopePcZnNtcnSetupBas(HopeAlarmVO vo);

	public void insertHopePcZnNtcnSndngBasList(HopeAlarmVO vo);
	
	public List<HopeAlarmVO> getHopePcZnNtcnSndngBas(HopeAlarmVO vo);
	
	public List<HopeAlarmVO> selectAppPushMember(HopeAlarmVO vo);
	
	public void updateHopePushAlarmReturn(HopeAlarmVO vo);
}
