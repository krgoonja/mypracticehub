package com.sorincorp.api.hanafx.fs.model;

import lombok.Data;

@Data
public class ItPurchsInfoBasVo {

   /**
    * BL 번호
   */
   private String blNo;
    /**
    * 구매 주문 번호
   */
   private String purchsOrderNo;
    /**
    * 구매 라인 번호
   */
   private String purchsLineNo;
    /**
    * 구매 사업자
   */
   private String purchsBsnm;
    /**
    * 구매 무역 조건
   */
   private String purchsCmmrcCnd;
    /**
    * 구매 위치 명
   */
   private String purchsLcNm;
    /**
    * 구매 수량
   */
   private java.math.BigDecimal purchsQy;
    /**
    * 구매 LME 달러 가격
   */
   private java.math.BigDecimal purchsLmeDollarPc;
    /**
    * 구매 프리미엄 달러 금액
   */
   private java.math.BigDecimal purchsPremiumDollarAmount;
    /**
    * 구매 단위 달러 가격
   */
   private java.math.BigDecimal purchsUnitDollarPc;
    /**
    * 구매 달러 총액
   */
   private java.math.BigDecimal purchsDollarAmount;
    /**
    * 구매 원화 총액
   */
   private java.math.BigDecimal purchsWonAmount;
    /**
    * 선물 계약 번호
   */
   private String ftrsCntrctNo;
    /**
    * 선물 삼성 계약 번호
   */
   private String ftrsThsexCntrctNo;
    /**
    * 선물 거래 일시
   */
   private String ftrsDelngDt;
    /**
    * 선물 거래 LOT 수량
   */
   private int ftrsDelngLotQy;
    /**
    * 선물 거래 중량
   */
   private java.math.BigDecimal ftrsDelngWt;
    /**
    * 선물 거래 옵션
   */
   private String ftrsDelngOptn;
    /**
    * 선물 거래 시작 일자
   */
   private java.sql.Date ftrsDelngBeginDe;
    /**
    * 선물 거래 종료 일자
   */
   private java.sql.Date ftrsDelngEndDe;
    /**
    * 선물 LME 달러 가격
   */
   private java.math.BigDecimal ftrsLmeDollarPc;
    /**
    * 선물 스프레드 달러 가격
   */
   private java.math.BigDecimal ftrsSpreadDollarPc;
    /**
    * 선물 종료 달러 가격
   */
   private java.math.BigDecimal ftrsEndDollarPc;
    /**
    * 선물 달러 수수료
   */
   private java.math.BigDecimal ftrsDollarFee;
    /**
    * 선물 만기 일자
   */
   private String ftrsExprtnDe;
    /**
    * 선물환 계약 번호
   */
   private String fshgCntrctNo;
    /**
    * 선물환 거래 일시
   */
   private String fshgDelngDt;
    /**
    * 선물환 배부 중량
   */
   private int fshgDlryWt;
    /**
    * 선물환 거래 통화
   */
   private String fshgDelngCrncy;
    /**
    * 선물환 거래 달러 금액
   */
   private java.math.BigDecimal fshgDelngDollarAmount;
    /**
    * 선물환 원화 환율
   */
   private java.math.BigDecimal fshgWonEhgt;
    /**
    * 선물환 원화 스프레드
   */
   private java.math.BigDecimal fshgWonSpread;
    /**
    * 선물환 종료 원화 가격
   */
   private java.math.BigDecimal fshgEndWonPc;
    /**
    * 선물환 매수 원화 가격
   */
   private java.math.BigDecimal fshgPrchasWonPc;
    /**
    * 선물환 만기 일자
   */
   private String fshgExprtnDe;
   /**
    * 선물환 관리 번호
    */
   private String fshgManageNo;
    /**
    * 물류 터미널 사용 원화 비용
   */
   private long lgistTrminlUseWonCt;
    /**
    * 물류 해상 운송 원화 비용
   */
   private long lgistSeaTrnsprtWonCt;
    /**
    * 물류 내륙 운송 원화 비용
   */
   private long lgistLandTrnsprtWonCt;
    /**
    * 물류 하역 원화 비용
   */
   private long lgistLnlWonCt;
    /**
    * 물류 보관 원화 비용
   */
   private long lgistCstdyWonCt;
    /**
    * 물류 기타 원화 비용
   */
   private long lgistEtcWonCt;
    /**
    * 물류 합계 원화 비용
   */
   private long lgistSmWonCt;
    /**
    * 통관 관세 원화 비용
   */
   private long entrCstmsWonCt;
    /**
    * 통관 수수료 원화 비용
   */
   private long entrFeeWonCt;
    /**
    * 금융 이자 원화 비용
   */
   private long fnncIntrWonCt;
    /**
    * 금융 기타 원화 비용
   */
   private long fnncEtcWonCt;
    /**
    * 비용 합계 원화 비용
   */
   private long ctSmWonCt;
    /**
    * 선적 일자
   */
   private java.sql.Date shipngDe;
    /**
    * 선적항 명
   */
   private String prloadNm;
    /**
    * 도착항 명
   */
   private String arvlhangNm;
    /**
    * 성적서 파일 경로
   */
   private String screofeFileCours;
    /**
    * 포장 리스트 파일 경로
   */
   private String packngListFileCours;
    /**
    * 입고 일자
   */
   private java.sql.Date wrhousngDe;
    /**
    * 요율 값
   */
   private int tariffVal;
    /**
    * 프리 타임
   */
   private int freeTime;
    /**
    * NET 중량
   */
   private java.math.BigDecimal netWt;
    /**
    * GROSS 중량
   */
   private java.math.BigDecimal grossWt;
    /**
    * LOT 수량
   */
   private int lotQy;
    /**
    * 삭제 여부
   */
   private String deleteAt;
    /**
    * 삭제 일시
   */
   private java.sql.Timestamp deleteDt;
    /**
    * 최초 등록자 아이디
   */
   private String frstRegisterId;
    /**
    * 최초 등록 일시
   */
   private java.sql.Timestamp frstRegistDt;
    /**
    * 최종 변경자 아이디
   */
   private String lastChangerId;
    /**
    * 최종 변경 일시
   */
   private java.sql.Timestamp lastChangeDt;

}