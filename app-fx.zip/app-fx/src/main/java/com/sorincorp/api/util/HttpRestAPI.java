package com.sorincorp.api.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.http.HttpException;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.stereotype.Component;

import com.sorincorp.comm.util.JsonUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class HttpRestAPI {
    private static final String DEFAULT_ENCODING = "euc-kr";
//    private static final Logger log = LoggerFactory.getLogger(HttpRestAPI.class);

    public HttpRestAPI() {

    }

    public String processTextHTTP(Map<String, String> params , String url )
    {

        int statusCode = 0;

        try {
        	CloseableHttpClient httpclient = HttpClientBuilder.create().build();
            HttpPost httpPost 				= new HttpPost(url);
        	List<NameValuePair> nvps 		= makeParams(params);

            httpPost.setHeader("Content-Type", "application/x-www-form-urlencoded; text/html; charset=euc-kr");
        	httpPost.setHeader("Cache-Control", "no-cache");

            // 한글 인코딩을 위하여 인코딩 정보를 설정한다.
            httpPost.setEntity(new UrlEncodedFormEntity(nvps, DEFAULT_ENCODING));

            CloseableHttpResponse response = httpclient.execute(httpPost);
            statusCode = response.getStatusLine().getStatusCode();

            log.debug("\nSending 'POST' request to URL : " + httpPost.getURI());
            log.debug("Post parameters : " + httpPost.getEntity().toString());
            log.debug("Response Code : " + statusCode );

            if( statusCode == 200){
                // 정상인 경우 메시지를 읽어 들여 그 결과를 리턴한다.
                BufferedReader rd = new BufferedReader( new InputStreamReader(response.getEntity().getContent()));
                StringBuffer result = new StringBuffer();
                String line = "";
                while ((line = rd.readLine()) != null) {
                    result.append(line);
                }

                return result.toString();
            }else {
            	throw new HttpException((new StringBuilder("오류가 발생하였습니다.")).append(statusCode).toString());
            }

        } catch (HttpException e) {
        	log.error(e.getMessage(), e);
        } catch (Throwable e) {
        	log.error((new StringBuilder("오류가 발생하였습니다.")).append(statusCode).toString(), e);
        }

        return null;

    }

    public Map<String, Object> processJsonHTTP(Map<String, Object> params , String url )
    {
    	int statusCode = 0;
    	Map<String, Object> resultMap = null;
        try {

        	//https://www.hyoyoung.net/103 - 코드 수정시 참고
// config 설정
	        int timeout = 5;
	        RequestConfig config = RequestConfig.custom().
	                setConnectTimeout(timeout * 1000)
	                .setConnectionRequestTimeout(timeout * 1000)
	                .setSocketTimeout(timeout * 1000).build();
	        CloseableHttpClient httpclient  = HttpClientBuilder.create().setDefaultRequestConfig(config).build();

	        HttpPost httpPost 				= new HttpPost(url);

        	httpPost.setHeader("Content-Type", "application/json; charset=utf-8");
            httpPost.setHeader("Cache-Control", "no-cache");

            // 한글 인코딩을 위하여 인코딩 정보를 설정한다.
            JSONObject argument = JsonUtil.getJsonStringFromMap(params);
            StringEntity postingString = new StringEntity(argument.toString());
            httpPost.setEntity(postingString);

            CloseableHttpResponse response = httpclient.execute(httpPost);
            statusCode = response.getStatusLine().getStatusCode();

            log.debug("\nSending 'POST' request to URL : " + httpPost.getURI());
            log.debug("Post parameters : " + httpPost.getEntity().toString());
            log.debug("Response Code : " + statusCode );

            if( statusCode == 200){
                // 정상인 경우 메시지를 읽어 들여 그 결과를 리턴한다.
                BufferedReader rd = new BufferedReader( new InputStreamReader(response.getEntity().getContent()));
                StringBuffer result = new StringBuffer();
                String line = "";
                while ((line = rd.readLine()) != null) {
                    result.append(line);
                }

                JSONObject jo = new JSONObject(result.toString());
                resultMap = JsonUtil.getMapFromJsonObject(jo);

                return resultMap;
            }else {
                throw new HttpException((new StringBuilder("오류가 발생하였습니다.")).append(statusCode).toString());
            }

        } catch (HttpException e) {
        	resultMap = new HashedMap<>();
        	resultMap.put("success", "false");
        	resultMap.put("message", e.getMessage());
        	log.error((new StringBuilder("오류가 발생하였습니다.")).append(statusCode).toString(), e);
        } catch (Throwable e) {
        	resultMap = new HashedMap<>();
        	resultMap.put("success", "false");
        	resultMap.put("message", e.getMessage());
        	log.error((new StringBuilder("오류가 발생하였습니다.")).append(statusCode).toString(), e);
        }

        return resultMap;

    }

//    public Map<String, Object> processJsonHTTP(Map<String, Object> params , String url ) throws Exception
//    {
//    	int statusCode = 0;
//
//        try {
//
//// config 설정
//	        int timeout = 5;
//	        RequestConfig config = RequestConfig.custom().
//	                setConnectTimeout(timeout * 1000)
//	                .setConnectionRequestTimeout(timeout * 1000)
//	                .setSocketTimeout(timeout * 1000).build();
//	        CloseableHttpClient httpclient  = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
////	        CloseableHttpClient httpclient  = HttpClientBuilder.create().build();
//	        HttpPost httpPost 				= new HttpPost(url);
//
//        	httpPost.setHeader("Content-Type", "application/json; charset=utf-8");
//            httpPost.setHeader("Cache-Control", "no-cache");
//
//            // 한글 인코딩을 위하여 인코딩 정보를 설정한다.
//            JSONObject argument = JsonUtil.getJsonStringFromMap(params);
//            StringEntity postingString = new StringEntity(argument.toString());
//            httpPost.setEntity(postingString);
//
//            CloseableHttpResponse response = httpclient.execute(httpPost);
//            statusCode = response.getStatusLine().getStatusCode();
//
//            log.debug("\nSending 'POST' request to URL : " + httpPost.getURI());
//            log.debug("Post parameters : " + httpPost.getEntity().toString());
//            log.debug("Response Code : " + statusCode );
//
//            if( statusCode == 200){
//                // 정상인 경우 메시지를 읽어 들여 그 결과를 리턴한다.
//                BufferedReader rd = new BufferedReader( new InputStreamReader(response.getEntity().getContent()));
//                StringBuffer result = new StringBuffer();
//                String line = "";
//                while ((line = rd.readLine()) != null) {
//                    result.append(line);
//                }
//
//                JSONObject jo = new JSONObject(result.toString());
//                Map<String, Object> resultMap = JsonUtil.getMapFromJsonObject(jo);
//
//                return resultMap;
//            }else {
//                throw new HttpException((new StringBuilder("오류가 발생하였습니다.")).append(statusCode).toString());
//            }
//
//        } catch (Throwable e) {
//            throw new HttpException((new StringBuilder("오류가 발생하였습니다.")).append(statusCode).toString());
//        }
//
//    }

    public List<NameValuePair> makeParams(Map<String, String> params) throws Exception {
        int hashSize = params.size();
        Iterator keyset = params.keySet().iterator();
        List <NameValuePair> nvps = new ArrayList <NameValuePair>();
        for (int i = 0; i < hashSize; i++) {
            String key = (String) keyset.next();
            nvps.add(new BasicNameValuePair(key, params.get(key)));
        }

        return nvps;
    }

    public static void main(String[] args) {
    	Map<String, Object> params = new HashedMap<>();
//    	params.put("cliOrdNo", 		"20210621-20000000019");
//    	params.put("prodCd"	, 		"FWD");
//    	params.put("pairId", 		"USD/KRW");
//    	params.put("valDt", 		"20210730");
//    	params.put("matDt", 		"00000000");
//    	params.put("currCd", 		"USD");
//    	params.put("nearAmt", 		"1000000");
//    	params.put("farAmt", "0");
//    	params.put("bsTp", "S");
//    	params.put("condTp", "M");

//    	params.put("fshgRequstOrderNo", 		"20210713-20000000001");
    	params.put("orderNo", 					"0000000001");
//    	params.put("orderSn", 					"1");
//    	params.put("requstFshgGoodsCode", 		"FWD");
//    	params.put("requstExprtnde", 			"20210730");
//    	params.put("requstFshgDelngCrncyCode", 	"USD/KRW");
//    	params.put("requstOrderAmount", 		"1000000");
//    	params.put("requstPostn", 				"S");
//    	params.put("requstOrderCnd", 			"M");

    	//String url = "http://127.0.0.1:8080/app-api/hanafx/fshg/order/new";
    	String url = "http://172.20.89.152:8080/app-api/hanafx/fshg/order/new";
    	HttpRestAPI http = new HttpRestAPI();
    	try {
			Map<String, Object> resultMap = http.processJsonHTTP(params, url);
			System.out.println("resultMap : [" + resultMap + "]");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
