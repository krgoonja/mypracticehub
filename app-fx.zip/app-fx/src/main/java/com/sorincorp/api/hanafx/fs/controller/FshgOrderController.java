package com.sorincorp.api.hanafx.fs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.hanafx.exception.FshgBizException;
import com.sorincorp.api.hanafx.fs.model.OrOrderFshgBasVo;
import com.sorincorp.api.hanafx.fs.service.FshgNewOrderService;
import com.sorincorp.api.hanafx.fs.service.FshgService;
import com.sorincorp.api.util.APICmmnConst;
import com.sorincorp.api.util.ApiCmmUtil;
import com.sorincorp.api.util.HttpResponseVO;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/hanafx/fshg")
public class FshgOrderController {

	@Autowired
	private FshgService hanaFxfshgService;

	@Autowired
	private FshgNewOrderService orderService;



	/**
	 * <pre>
	 * 처리내용: Fx Server의 health 체크한다.
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 21.			srec0032			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/health", method = RequestMethod.GET)
	@ResponseBody
    public ResponseEntity<?> health() throws Exception {
    	log.info("/hanafx/fshg/health ###################### OK..");

		HttpResponseVO resVo = new HttpResponseVO();
		resVo.setSuccess(true);
		resVo.setCode(APICmmnConst.SUCCESS_RESULT_CODE);
		resVo.setMessage(APICmmnConst.SUCCESS_RESULT_MSG);

        return ResponseEntity
				.status(HttpStatus.OK)
				.body(resVo);
    }

	/**
	 * <pre>
	 * 처리내용: 단위 테스트 신규 주문을 생성하고 하나 은행으로 주문 낸다.
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 21.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param orderInfo
	 * @return
	 * @throws FshgBizException
	 * @throws Exception
	 */
	@RequestMapping(value = "/ordertest/new", method = RequestMethod.POST)
	@ResponseBody
    public ResponseEntity<?> executeApiTestHanaFxFshgNewOrder(@RequestBody OrOrderFshgBasVo orderInfo)
    		throws FshgBizException, Exception {
		log.info("execute: /hanafx/fshg/ordertest/new {}", orderInfo);

		/* 테스트 데이터 등록 */
		hanaFxfshgService.insertTestFshData(orderInfo);

		/* 하나fx 주문 테스트 */
		OrOrderFshgBasVo result = orderService.executeFshgNewOrder(orderInfo);

		HttpResponseVO resVo = new HttpResponseVO();
		resVo.setCode(APICmmnConst.SUCCESS_RESULT_CODE);
		resVo.setMessage(APICmmnConst.SUCCESS_RESULT_MSG);
		resVo.setData(result);

        return ResponseEntity.status(HttpStatus.OK).body(resVo);
    }

	/**
	 * <pre>
	 * 처리내용: 하나은행과 선물환 거래 - 신규 주문
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 21.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param orderInfo
	 * @return
	 * @throws FshgBizException
	 * @throws Exception
	 */
	@RequestMapping(value = "/order/new", method = RequestMethod.POST)
	@ResponseBody
    public ResponseEntity<?> executeHanaFxFshgNewOrder(@RequestBody OrOrderFshgBasVo orderInfo) throws FshgBizException, Exception {
		try {
			log.info("<<<<< execute [/order/new] (orderNo:{}, fshgRequstOrderNo:{})", orderInfo.getOrderNo(), orderInfo.getFshgRequstOrderNo());

			if(StringUtil.isEmpty(orderInfo.getOrderNo())) {
				throw new Exception("주문번호는 필수 입니다.");
			}

			if(!StringUtil.isEmpty(orderInfo.getCanclExchngRtngudNo())) {
				throw new Exception("잘못된 URL입니다.");
			}

			OrOrderFshgBasVo result = orderService.executeFshgNewOrder(orderInfo);

			HttpResponseVO resVo = new HttpResponseVO();
			resVo.setData(result);
			resVo.setCode(APICmmnConst.SUCCESS_RESULT_CODE);
			resVo.setMessage(APICmmnConst.SUCCESS_RESULT_MSG);

			return ResponseEntity.status(HttpStatus.OK).body(resVo);
		}catch (FshgBizException fe) {
			orderInfo.setRspnsMssage(ApiCmmUtil.getFxErrorMessage(fe, 50));
			orderService.updateOrderFailSttusCode(orderInfo);
			throw fe;
		}catch (Exception e) {
			orderInfo.setRspnsMssage(ApiCmmUtil.getFxErrorMessage(e, 50));
			orderService.updateOrderFailSttusCode(orderInfo);
			throw e;
		}
    }
	/**
	 * <pre>
	 * 처리내용: 하나은행으로 기존 주문에 대해 매도(취소, 반품시) 주문을 실행한다.
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 21.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param orderInfo
	 * @return
	 * @throws FshgBizException
	 * @throws Exception
	 */
	@RequestMapping(value = "/claim-order/new", method = RequestMethod.POST)
	@ResponseBody
   public ResponseEntity<?> executeHanaFxFshgSellOrder(@RequestBody OrOrderFshgBasVo orderInfo) throws FshgBizException, Exception {

		try {
			String userId = orderInfo.getUserId();
			String canclExchngRtngudNo = orderInfo.getCanclExchngRtngudNo();
			String orderNo = orderInfo.getOrderNo();
			log.info("execute: /hanafx/fshg/claim-order/new userId:{}, orderNo:{}, canclExchngRtngudNo:{}", userId, orderNo, canclExchngRtngudNo);

			if(StringUtil.isEmpty(userId)) {
				throw new Exception("사용자 ID는 데이터(userId)는 필수입니다.");
			}

			if(StringUtil.isEmpty(orderNo)) {
				throw new Exception("주문번호는 필수 입니다.");
			}

			if(StringUtil.isEmpty(canclExchngRtngudNo)) {
				throw new Exception("취소 교환 반품 번호는 필수입니다.");
			}

			OrOrderFshgBasVo result = orderService.executeFshgNewSellOrder(orderInfo);

			HttpResponseVO resVo = new HttpResponseVO();
			resVo.setData(result);
			resVo.setCode(APICmmnConst.SUCCESS_RESULT_CODE);
			resVo.setMessage(APICmmnConst.SUCCESS_RESULT_MSG);

			return ResponseEntity.status(HttpStatus.OK).body(resVo);
		}catch (FshgBizException fe) {
			//RollBack 방지위해 메소드명을
			orderService.updateOrderFailSttusCode(orderInfo);
			throw fe;
		}catch (Exception e) {
			orderService.updateOrderFailSttusCode(orderInfo);
			throw e;
		}
   }

	/**
	 * <pre>
	 * 처리내용: 하나은행 신규 메수주문 실패건에 대해 주문 재처리를 진행한다.
	 * </pre>
	 * @date 2021. 8. 23.
	 * @author srec0032
	 * @history
	 * 2023. 1. 5.			srec0051			매수,매도 통합
	 * @param orderInfo
	 * @return
	 */
	@RequestMapping(value = "/order/rehndl/{userId}/{orderNo}/{fshgRequstOrderNo}/{canclExchngRtngudNo}", method = RequestMethod.GET)
	@ResponseBody
    public ResponseEntity<?> executeFshgRehndlOrder(@PathVariable String userId
    		                                      , @PathVariable String orderNo
    											  , @PathVariable String fshgRequstOrderNo
    											  , @PathVariable String canclExchngRtngudNo) throws FshgBizException, Exception {

		log.info("<<<<< execute [/order/rehndl/{}/{}/{}/{}]", userId, orderNo, fshgRequstOrderNo, canclExchngRtngudNo);

		OrOrderFshgBasVo orderInfo = new OrOrderFshgBasVo();
		orderInfo.setOrderNo(orderNo);
		orderInfo.setFshgRequstOrderNo(fshgRequstOrderNo);
		orderInfo.setUserId(userId);
		orderInfo.setFrstRegisterId(userId);
		orderInfo.setLastChangerId(userId);
		orderInfo.setCanclExchngRtngudNo(StringUtil.nvl(canclExchngRtngudNo));

		OrOrderFshgBasVo result = orderService.executeFshgRehndlNewOrder(orderInfo);

		HttpResponseVO resVo = new HttpResponseVO();
		resVo.setData(result);
		resVo.setCode(APICmmnConst.SUCCESS_RESULT_CODE);
		resVo.setMessage(APICmmnConst.SUCCESS_RESULT_MSG);

		return ResponseEntity.status(HttpStatus.OK).body(resVo);
    }

	@ExceptionHandler(FshgBizException.class)
	public ResponseEntity<?> fshgBizException(FshgBizException e) throws Exception{
		log.error("fx FshgBizException ", e);

		HttpResponseVO resVo = new HttpResponseVO();
		resVo.setSuccess(false);
		resVo.setCode(APICmmnConst.ERROR_RESULT_CODE);
		resVo.setMessage(APICmmnConst.ERROR_RESULT_MSG);
		resVo.setError(e.getMessage());
		return ResponseEntity.status(HttpStatus.OK).body(resVo);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> fshgCommException(Exception e) throws Exception{
		log.error("fx Exception ", e);

		HttpResponseVO resVo = new HttpResponseVO();
		resVo.setSuccess(false);
		resVo.setCode(APICmmnConst.ERROR_RESULT_CODE);
		resVo.setMessage(APICmmnConst.ERROR_RESULT_MSG);
		resVo.setError(e.getMessage());
		return ResponseEntity.status(HttpStatus.OK).body(resVo);
	}
}
