package com.sorincorp.api.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.sorincorp.api.limit.service.RedisSubscriberFx;
import com.sorincorp.comm.redis.config.RedisPubSubService;

@Configuration
@ComponentScan("com.sorincorp.comm.*")
public class RedisPubSubConfig {

	@Autowired
	RedisPubSubService redisPubSubService;

	@Autowired
	RedisSubscriberFx redisSubscriberFx;

	@Value("${redisPubsub.uri.fx}")
	private String fxpcUri;

	@Value("${redisPubsub.crncyCode.KRW}")
	private String fxpcKRW;

	@Value("${redisPubsub.uri.prvsnlLimit.fx}")
	private String prvsnlLimitFxUri;

	@Bean(initMethod="init")
	public void InitSettings() throws Exception{
		// 실시간 환율
		redisPubSubService.createChannel(fxpcUri + "/" + fxpcKRW, redisSubscriberFx);
		// FX 지정가
		redisPubSubService.createChannel(prvsnlLimitFxUri, redisSubscriberFx);
	}
}
