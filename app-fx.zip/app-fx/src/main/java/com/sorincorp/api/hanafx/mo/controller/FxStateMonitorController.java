package com.sorincorp.api.hanafx.mo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.hanafx.fs.service.FshgService;
import com.sorincorp.api.util.APICmmnConst;
import com.sorincorp.api.util.HttpResponseVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/hanafx/mon")
public class FxStateMonitorController {

	@Autowired
	private FshgService hanaFxfshgService;

	/**
	 * <pre>
	 * 처리내용: Fx Server의 health 체크한다.
	 * </pre>
	 * @date 2021. 10. 21.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 21.			srec0032			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/health", method = RequestMethod.GET)
	@ResponseBody
    public ResponseEntity<?> health() throws Exception {
    	log.info("/hanafx/mon/health ###################### OK..");
		HttpResponseVO resVo = new HttpResponseVO();
		resVo.setSuccess(true);
		resVo.setCode(APICmmnConst.SUCCESS_RESULT_CODE);
		resVo.setMessage(APICmmnConst.SUCCESS_RESULT_MSG);

        return ResponseEntity
				.status(HttpStatus.OK)
				.body(resVo);
    }
}
