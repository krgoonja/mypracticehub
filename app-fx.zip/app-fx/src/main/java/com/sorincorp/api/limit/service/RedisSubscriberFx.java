package com.sorincorp.api.limit.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.api.hanafx.pr.model.PrEhgtRltmBassVo;
import com.sorincorp.comm.limit.service.OrLimitOrderBasVoMapService;
import com.sorincorp.comm.order.model.CommPrvsnlLimitOrderRedisMsgVO;
import com.sorincorp.comm.redis.config.RedisPubSubMessage;
import com.sorincorp.comm.util.LimitDataUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class RedisSubscriberFx implements MessageListener {

	@Autowired
	private OrLimitOrderBasVoMapService orLimitOrderBasVoMapService;

	@Autowired
	private FindMatchingLimitFxPriceThreadService findMatchingLimitFxPriceThreadService;

	@Value("${redisPubsub.crncyCode.KRW}")
	private String fxpcKRW;

	@Value("${redisPubsub.uri.fx}")
	private String fxUri;

	@Value("${redisPubsub.uri.prvsnlLimit.fx}")
	private String prvsnlLimitFxUri;

	@Override
	public void onMessage(Message message, byte[] pattern) {
		byte[] messageBody = message.getBody();
		ByteArrayInputStream in = new ByteArrayInputStream(messageBody);
		ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ObjectInputStream is =null;
		RedisPubSubMessage pubSubMsg = null;
		try {
			is = new ObjectInputStream(in);
			pubSubMsg = (RedisPubSubMessage) is.readObject();
			String channel = pubSubMsg.getChannelId();

			if(channel.equals(fxUri + "/" + fxpcKRW)) {
				// 실시간 환율 수신
				log.info("Receive FX URI");
				PrEhgtRltmBassVo vo = new PrEhgtRltmBassVo();
				vo = objMapper.readValue(pubSubMsg.getMessage().toString(), PrEhgtRltmBassVo.class);

				// FX 지정가 체크 스레드
				findMatchingLimitFxPriceThreadService.findMatchingLimitFxPriceThread(vo);

			} else if(channel.equals(prvsnlLimitFxUri)) {
				// FX 지정가 주문 수신
				log.info("Receive PrvsnlLimitFx URI");
				CommPrvsnlLimitOrderRedisMsgVO vo = new CommPrvsnlLimitOrderRedisMsgVO();
				vo = objMapper.readValue(pubSubMsg.getMessage().toString(), CommPrvsnlLimitOrderRedisMsgVO.class);

				// FX 지정가 주문 save
				savePrvsnlLimitData(vo);
			}

		} catch (IOException e) {
			log.error("IOException : " + e.toString() + " -> message : " + message.toString());
		} catch (ClassNotFoundException e) {
			log.error("ClassNotFoundException : " + e.toString() + " -> message : " + message.toString());
		} catch (Exception e) {
			log.error("Exception : " + e.toString() + " -> message : " + message.toString());
		}
	}

	/* ### 수신받은 가단가 FX 지정가 데이터 저장 로직 ###
	 *
	 * 1. 저장된 지정가 주문번호가 없는 경우 insert 되지 않은 상태이므로, 저장하는 로직만 타고 return
	 * 2. 이미 저장된 지정가 주문번호가 있는 경우
	 * 		2-1. Update인 경우
	 * 			- 지정가 주문 리스트에서 해당 주문번호 데이터 삭제 후, 다시 insert
	 * 			- 지정가 주문 map update
	 * 		2-2. Delete인 경우
	 * 			- 지정가 주문 리스트와 지정가 주문 map에서 삭제
	 */
	private synchronized void savePrvsnlLimitData(CommPrvsnlLimitOrderRedisMsgVO redisVo) {
		try {
			log.info("1-0) receive redisVo: " + redisVo);

			// 1. 그룹키 생성
			String groupKey = redisVo.getMetalCode();

			// 2. 지정가주문번호-지정가입력금액 map 및 종목별 지정가 주문 리스트 세팅
			// 최초에는 new new CommPrvsnlLimitOrderRedisMsgVO();
			CommPrvsnlLimitOrderRedisMsgVO prvsnlLimitOrderNoInputAmountVo = orLimitOrderBasVoMapService.getPrvsnlLimitOrderNoInputAmountVo(redisVo.getLimitOrderNo());	// 지정가주문번호-지정가입력금액 map

			// 1. 저장된 지정가 주문번호가 없는 경우 - insert 되지 않은 상태이므로, 저장하는 로직만 타고 return
			if(prvsnlLimitOrderNoInputAmountVo.getLimitInputAmount() == 0 &&
					redisVo.getIntrfcSttusCode().equals(LimitDataUtil.LimitOrderSttusCode.INSERT.value)) {

				orLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap(groupKey).add(redisVo);
				prvsnlLimitOrderNoInputAmountVo.setLimitInputAmount(redisVo.getLimitInputAmount());

				log.info("1-1) prvsnl limit data insert: " + orLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap());

				return;
			}

			/* 2-1. Update인 경우
			 * 		- 지정가 주문 리스트에서 해당 주문번호 데이터 삭제 후, 다시 insert
			 * 		- 지정가 주문 map update
			*/
			if(redisVo.getIntrfcSttusCode().equals(LimitDataUtil.LimitOrderSttusCode.UPDATE.value)) {
				CommPrvsnlLimitOrderRedisMsgVO oldVo = orLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap(groupKey)
						.stream()
						.filter(vo -> vo.getLimitOrderNo().equals(redisVo.getLimitOrderNo()))
						.findFirst()
						.orElse(null);

				orLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap(groupKey).remove(oldVo); 	// 기존에 존재하는 주문번호 VO를 List에서 삭제
				orLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap(groupKey).add(redisVo);		// 레디스에서 받은 새로운 가격을 key로 하는 List에서 레디스에서 받은 VO 값 add
				prvsnlLimitOrderNoInputAmountVo.setLimitInputAmount(redisVo.getLimitInputAmount());

				log.info("1-2) prvsnl limit data update: " + orLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap());

				return;
			}

			/*
			 * 2-2. Delete인 경우
			 * 	   - 지정가 주문 리스트와 지정가 주문 map에서 삭제
			 */
			if(redisVo.getIntrfcSttusCode().equals(LimitDataUtil.LimitOrderSttusCode.DELETE.value)) {
				String limitOrderNoToRemove = redisVo.getLimitOrderNo(); // 삭제하려는 지정가 주문 번호
				orLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap(groupKey).removeIf(item -> item.getLimitOrderNo().equals(limitOrderNoToRemove));

//				orLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoMap(groupKey).remove(redisVo); // 기존에 존재하는 주문번호 VO를 List에서 삭제
				orLimitOrderBasVoMapService.removePrvsnlLimitOrderNoInputAmountVo(redisVo.getLimitOrderNo());

				log.info("1-3) prvsnl limit data delete!: " + orLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap());
			}
		} catch(Exception e) {
			log.error("[savePrvsnlLimitOrder Error] {}", ExceptionUtils.getStackTrace(e));
		}
	}

}
