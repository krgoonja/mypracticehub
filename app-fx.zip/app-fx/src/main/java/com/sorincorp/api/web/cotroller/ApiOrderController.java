package com.sorincorp.api.web.cotroller;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.sorincorp.api.hanafx.fs.model.ApiIntDatReqVo;
import com.sorincorp.api.hanafx.fs.service.FshgService;
import lombok.extern.slf4j.Slf4j;


/**
 * ApiOrderController.java
 * @version
 * @since 2021. 6. 4.
 * @author srec0032
 */
@Slf4j
@RestController
@RequestMapping(value = "/order")
public class ApiOrderController {

	@Autowired
	private FshgService hanaFxfshgService;

	@RequestMapping(value = "/ftrs/test", method = RequestMethod.GET)
	@ResponseBody
    public String rcvTest( @RequestBody ApiIntDatReqVo orderInfo ) throws Exception {
		System.out.println("test ######################" +  orderInfo);
		JSONObject json = new JSONObject();
        json.put("success", true);
        json.put("data", 10);
        //json.put(null, 10);

        return json.toString(4);
    }

//	@GetMapping("/ftrs/execute/new/{orderNo}")
//	@ResponseBody
//    public String executeSamsungFtrsNewOrder( @PathVariable String orderNo, HttpServletRequest request ) throws Exception {
//		log.info("execute ######################" +  orderNo);
//		samsungFtrsService.executeFtrsNewOrder(orderNo);
//
//        JSONObject json = new JSONObject();
//        json.put("success", true);
//        json.put("data", 10);
//        //json.put(null, 10);
//
//        return json.toString(4);
//    }

	/**
	 * <pre>
	 * 처리내용: 하나은행 F/X 선물환거래 테스트 - 주문
	 * </pre>
	 * @date 2021. 6. 4.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 6. 4.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param orderNo
	 * @param request
	 * @return
	 * @throws Exception
	 */
//	@GetMapping("/fshg/execute/new/{orderNo}")
//	@ResponseBody
//    public String executeHanaFxFshgNewOrder( @PathVariable String orderNo, HttpServletRequest request ) throws Exception {
//		log.info("executeFshg execute ######################" +  orderNo);
//		ApiIntDatReqVo vo = new ApiIntDatReqVo();
//		hanaFxfshgService.executeFshgNewOrder(vo);
//
//        JSONObject json = new JSONObject();
//        json.put("success", true);
//        json.put("data", "1234567890");
//
//        return json.toString(4);
//    }
//
//	@RequestMapping(value = "/fshg/execute/new", method = RequestMethod.POST)
//	@ResponseBody
//    public String executeHanaFxFshgNewOrder(@RequestBody ApiIntDatReqVo orderInfo  ) throws Exception {
//		hanaFxfshgService.executeFshgNewOrder(orderInfo);
//
//        JSONObject json = new JSONObject();
//        json.put("success", true);
//        json.put("data", "1234567890");
//
//        return json.toString(4);
//    }

	//아직 사용 방법이 결정 안됨. Client 요청이나 Server 자체적으로 환율 초기 정보를 설정할지????
	@GetMapping("/dealingEhgt/execute/{orderNo}")
	@ResponseBody
    public String executeDealingEhgt( @PathVariable String orderNo, HttpServletRequest request ) throws Exception {
		log.info("execute ######################" +  orderNo);
        JSONObject json = new JSONObject();
        json.put("success", true);
        json.put("data", 10);

        return json.toString(4);
    }
}
