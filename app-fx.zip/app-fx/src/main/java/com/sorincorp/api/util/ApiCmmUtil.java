package com.sorincorp.api.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.lang3.StringUtils;

import com.sorincorp.comm.util.StringUtil;

public class ApiCmmUtil {

	public static String bytes2String(byte abyte0[], int i, int j) {
		String s = new String(abyte0, i, j);
		int k = s.indexOf('\0');
		if (k == -1) {
			return s;
		} else {
			s = s.substring(0, k);
			return s;
		}
	}

	public static String bytes2StringNew(byte abyte0[], int i, int j) {
		try {
			String s = new String(abyte0, i, j);
			int k = s.indexOf('\0');
			if (k == -1) {
				return s;
			} else {
				s = s.substring(0, k);
				return s;
			}
		}catch(java.lang.StringIndexOutOfBoundsException e) {
			System.err.println("==> StringIndexOutOfBoundsException (bytes2StringNew): " + e.getMessage());

			int bytelen = abyte0.length;
			int remainLen = bytelen-i;
			if(remainLen > -1) {
				System.out.println("==> bytelen:[" + bytelen +"], remainLen:[" + remainLen + "], startPos:[" + i +"], strSize:[" + j + "]" );
				String str = new String(abyte0, i, remainLen);
				return str;
			}else {
				return null;
			}
		}
	}

	public static String getMdReqId(String reqId) {
		String mdReqId = "REQ";
		String subId = reqId;
		subId = StringUtil.padValue(subId, "0", 27, true);

		mdReqId += subId;
		return mdReqId;
	}

	public static String getWeekDay(Calendar cal) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String lastdate = sdf.format(cal.getTime());

		int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
		boolean isWeekday = ((dayOfWeek >= Calendar.MONDAY) && (dayOfWeek <= Calendar.FRIDAY)); // 주말은 제외
		if (!isWeekday) {
			cal.add(Calendar.DATE, -1);
			return getWeekDay(cal);
		} else {
			return lastdate;
		}
	}

	public static String[] getMaturityDay() {
		String mtds[] = new String[6];
		Calendar preCal = Calendar.getInstance();
		preCal.add(Calendar.DATE, 2);                //2영업일 초과하는 특정일
		int month = 0;
		for (int i = 0; i <= 5; ++i) {
			// 마지막일로 설정
			preCal.set(Calendar.DATE, preCal.getActualMaximum(Calendar.DAY_OF_MONTH));
			month = preCal.get(Calendar.MONTH) + 1;

			String maturityDay = getWeekDay(preCal);
			mtds[i] = maturityDay;
			preCal.add(Calendar.MONTH, +1);
			month = preCal.get(Calendar.MONTH);
		}
		return mtds;
	}

	public static String getFxErrorMessage(Throwable t, int limit) {
		try {
			if(t == null) return null;

			String message = t.getMessage();
			if(StringUtils.isNotEmpty(message) && message.length() > limit) {
				message = message.substring(0, limit) + "...";
			}
			return message;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
