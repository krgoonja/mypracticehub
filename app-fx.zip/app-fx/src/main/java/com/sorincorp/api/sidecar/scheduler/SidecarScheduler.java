package com.sorincorp.api.sidecar.scheduler;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.sorincorp.api.sidecar.model.SidecarVO;
import com.sorincorp.api.sidecar.service.SidecarFxService;
import com.sorincorp.comm.bsnInfo.model.RestTermVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.redis.config.RedisPubSubService;
import com.sorincorp.comm.util.BsnInfoUtil;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@EnableScheduling
@Component
public class SidecarScheduler {
	@Autowired
	private RedisPubSubService redisPubSubService;
	@Autowired
	SidecarFxService sidecarService;
	
	@Autowired
	BsnInfoService bsnInfoService;
	
	@Value("${redisPubsub.uri.sidecar}")
	private String sidecarUri;
	
	//LME 사이드카 - 1분 단위 실행
	@Scheduled(cron = "0 0/1 * * * *")
	public void sidecarScheduler() throws Exception {
		//motnAt : N  (미발동)
		//motnAt : Y  (발동)
		//motnAt : OP (오늘중 발동했는지 체크)
		//현재 날짜 가져오기
		List<RestTermVO> restTermListVO = bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");
		String nowDate = DateUtil.calDate("yyyyMMddHHmmss");
		log.info("LME 사이드카 - 1분 단위 실행시작(" + nowDate + ")");
		sidecarService.insertItSidecarMotnDtl(nowDate);
		List<SidecarVO> sidecarVoList = sidecarService.getSidecarOnList(nowDate, "LME");
		List<SidecarVO> returnSidecarVoList = new ArrayList<SidecarVO>();
		
		if(restTermListVO.size() > 0) {
			for(RestTermVO restTermVO : restTermListVO) {
				if(sidecarVoList.size() > 0) {
					for(SidecarVO sidecarVO : sidecarVoList) {
						if("N".equals(restTermVO.getRestdeAt())
							&& sidecarVO.getMetalCode().equals(restTermVO.getMetalCode())
							&& BsnInfoUtil.OperateSttusCode.OPERATE_AT.getValues().contains(restTermVO.getOpenTimeCode())) {
							returnSidecarVoList.add(sidecarVO);
						}
					}
				}
			}
		}
		
		if(returnSidecarVoList.size() > 0) {
			//사이드카 REDIS PUB
			//사이드카 발동 리스트 (MOTN_AT 의 값으로 발동유무 체크)
			redisPubSubService.publishMessage(sidecarUri, "SidecarNM", returnSidecarVoList);
		}
	}
	
	// 환율 사이드카 - 1분 단위 실행
	@Scheduled(cron = "0 0/1 * * * *")
	public void fxSidecarScheduler() throws Exception {
		//motnAt : N  (미발동)
		//motnAt : Y  (발동)
		//motnAt : OP (오늘중 발동했는지 체크)
		//현재 날짜 가져오기
		List<RestTermVO> restTermListVO = bsnInfoService.getRestTermInfoBySleMthd(DateUtil.getNowDate(), "01");
		String nowDate = DateUtil.calDate("yyyyMMddHHmmss");
		log.info("환율 사이드카 - 1분 단위 실행시작(" + nowDate + ")");
		sidecarService.insertItFxSidecarMotnDtl(nowDate);
		List<SidecarVO> sidecarVoList = sidecarService.getSidecarOnList(nowDate, "FX");
		
		if(sidecarVoList.size() > 0 && restTermListVO.size() > 0) {
			for(SidecarVO sidecarVO : sidecarVoList) {
				if("N".equals(restTermListVO.get(0).getRestdeAt())
					&& sidecarVO.getMetalCode().equals(restTermListVO.get(0).getMetalCode())
					&& BsnInfoUtil.OperateSttusCode.OPERATE_AT.getValues().contains(restTermListVO.get(0).getOpenTimeCode())) {
					//사이드카 REDIS PUB
					//사이드카 발동 리스트 (MOTN_AT 의 값으로 발동유무 체크)
					redisPubSubService.publishMessage(sidecarUri, "SidecarNM", sidecarVoList);
				}
			}
		}
	}
	
}
