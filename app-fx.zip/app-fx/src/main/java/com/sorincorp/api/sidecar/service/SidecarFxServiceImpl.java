package com.sorincorp.api.sidecar.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.sidecar.mapper.SidecarMapper;
import com.sorincorp.api.sidecar.model.SidecarVO;
import com.sorincorp.api.sidecar.model.SidecarValidateVO;

@Service
public class SidecarFxServiceImpl implements SidecarFxService {

	@Autowired
	SidecarMapper sidecarMapper;
	
	@Override
	public List<SidecarValidateVO> getSidecarOpertionList(SidecarVO vo) {
		return sidecarMapper.getSidecarOpertionList(vo);
	}

	@Override
	public void insertSidecarMotnDtl(List<SidecarValidateVO> sidecarValidateVoList) {
		sidecarMapper.insertSidecarMotnDtl(sidecarValidateVoList);
	}

	
	@Override
	public void insertItSidecarMotnDtl(String nowDate) {
		sidecarMapper.insertItSidecarMotnDtl(nowDate);
	}
	
	/**
	 * 환율 사이드카 발동 시 테이블 저장
	 */
	@Override
	public void insertItFxSidecarMotnDtl(String nowDate) {
		sidecarMapper.insertItFxSidecarMotnDtl(nowDate);
	}

	@Override
	public List<SidecarVO> getSidecarOnList(String nowDate, String type) {
		return sidecarMapper.getSidecarOnList(nowDate, type);
	}

}
