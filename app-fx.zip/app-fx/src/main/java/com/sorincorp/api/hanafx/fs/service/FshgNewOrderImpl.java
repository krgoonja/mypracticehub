package com.sorincorp.api.hanafx.fs.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.digitide.xcube.XCPBMsg;
import com.sorincorp.api.hanafx.de.mapper.DealingEhgtMapper;
import com.sorincorp.api.hanafx.de.model.GfxRfsResVo;
import com.sorincorp.api.hanafx.exception.FshgBizException;
import com.sorincorp.api.hanafx.fs.mapper.FshgMapper;
import com.sorincorp.api.hanafx.fs.model.ApiIntDatReqVo;
import com.sorincorp.api.hanafx.fs.model.ItPurchsInfoBasVo;
import com.sorincorp.api.hanafx.fs.model.OrOrderFshgBasVo;
import com.sorincorp.api.hanafx.mo.service.FxStateMonitorService;
import com.sorincorp.api.hanafx.socket.FshSendMcast;
import com.sorincorp.comm.message.service.SMSService;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@ComponentScan({"com.sorincorp.comm.*"})
public class FshgNewOrderImpl implements FshgNewOrderService{

	@Autowired
	private FshgService fshgService;
	@Autowired
	FxStateMonitorService fxStateMonitorService;
	@Autowired
	SMSService smsService;
	@Autowired
	FshgNewOrderService fshgNewOrderService;

	@Autowired
	private FshgMapper fshgMapper;
	@Autowired
	private DealingEhgtMapper dealingEhgtMapper;

	private FshSendMcast fshSendMcast;


	/**
	 * <pre>
	 * 처리내용
	 * </pre>
	 * @date 2023. 3. 2.
	 * @author srec0051
	 * @param searchVo
	 * @param requstPostn
	 * @return
	 * @throws FshgBizException
	 * @throws Exception
	 */
	private GfxRfsResVo validRecentDataWithGfxRfxRes(GfxRfsResVo searchVo, String requstPostn) throws FshgBizException, Exception {
		String valDt = searchVo.getValDt();
		if(StringUtils.isEmpty(valDt)) {
			throw new FshgBizException("", "만기일이 존재하지 않아 하나fx 전송을 중지합니다.");
		}

		log.info("requstPostnL[{}], searchVo :[{}]", requstPostn, searchVo.toString());

		GfxRfsResVo result = dealingEhgtMapper.selectRecentDataWithGfxRfsRes(searchVo);

		if (result == null) {
			throw new FshgBizException("", "최신 환율 데이터가 존재하지 않아 하나fx 전송을 중지합니다.");
		}

		log.info("Result QtStatus:{}, NearAsk:{}, QtIdx:{}, ValDt:{}"
				, result.getQtStatus(), result.getNearAsk(), result.getQtIdx(), result.getValDt());

		if (!"U".equals(result.getQtStatus())) {
			throw new FshgBizException("", "거래용 환율 데이터가 데이터 수신 상태[" +  result.getQtStatus() + "]가 정상적이지 않아 하나fx 전송을 중지합니다.");
		}

		if (StringUtils.equals(requstPostn, "B") && result.getNearAsk() == null) {
			throw new FshgBizException("", "거래용 환율 데이터중 선물환 매수 환율 주문가격이 [null]이여서 하나fx 전송을 중지합니다.");
		}
		if (StringUtils.equals(requstPostn, "S") && result.getNearBid() == null) {
			throw new FshgBizException("", "거래용 환율 데이터중 선물환 매도 환율 주문가격이 [null]이여서 하나fx 전송을 중지합니다.");
		}

		if (result.getQtIdx() == null) {
			throw new FshgBizException("", "거래용 환율 데이터중 환율 index가 [null]이여서 하나fx 전송을 중지합니다.");
		}

		return result;
	}


	@Override
	public OrOrderFshgBasVo executeFshgNewOrder(OrOrderFshgBasVo param) throws FshgBizException, Exception {
		/*
		 * Step1. 주문_주문 선물환 기본 정보 조회 (OR_ORDER_FSHG_BAS)
		 */
		List<OrOrderFshgBasVo> fshgBasList = fshgMapper.selectOrOrderFshgBasList(param);

		if (CollectionUtils.isEmpty(fshgBasList)) {
			throw new FshgBizException("", "관련 하나fx 데이터가 존재하지 않아 하나fx 전송을 중지합니다.");
		}

		GfxRfsResVo searchVo = new GfxRfsResVo();
		String searchDate = DateUtil.calDate("yyyyMMdd");  // 기준일 - 오늘날짜
		searchVo.setSearchKeyword(searchDate);

		List<OrOrderFshgBasVo> orderDataList = new ArrayList<>();
		for (OrOrderFshgBasVo dataVo : fshgBasList) {
			try {
				/*
				 * Step2. 요청 만기일자를 이용하여 거래용 환율 정보를 조회한다
				 *        GFX_RFS_RES(거래용 환율 응답 I/F) - 선물환 만기일별 최신 데이타
				 *        하나 FX쪽 장애로 최신 데이터 안들어 올때 시간 차이를 계산해 장애 판단 로직이 있어야 할듯함.
				 *        - 일정 시간 체크 필요. ( ex)30초 이내의 데이터 )
				 */

				//매수 이면서 청산 번호 없는 경우
				String requstPostn = StringUtil.trim(dataVo.getRequstPostn());
				String requstLqdNo = dataVo.getRequstLqdNo();	// 요청 청산 번호
				String requstMsgSe = dataVo.getRequstMssageSe();	// 요청 메시지 구분

				// 22.06.21 PO 테이블에 "선물환관리번호" 존재유무에 따라 "청산(TO)" 또는 "신규(NO)" 주문 이므로 청산 주문일때만 체크
				if ("B".equals(requstPostn) && "TO".equals(requstMsgSe.toUpperCase()) && StringUtil.isEmpty(requstLqdNo)) {
					throw new FshgBizException("", "요청 청산 번호가 존재 하지 않습니다. : REQUST_LQD_NO" );
				}

				String valDt = dataVo.getRequstExprtnde();	//요청 만기일자
				searchVo.setValDt(valDt);
				GfxRfsResVo result = validRecentDataWithGfxRfxRes(searchVo, requstPostn);

				String limPx = result.getNearAsk().toString();	/* 선물환 매수 환율 */
				String qtIdx = result.getQtIdx();	/* 환율 건별 INDEX */
				dataVo.setRequstOrderPc(limPx);
				dataVo.setRequstEhgtIndx(qtIdx);
				orderDataList.add(dataVo);

			} catch (FshgBizException e) {
				// 실패건 sms 추가 발송
				fshgNewOrderService.innerDepartmentSendSms(dataVo.getOrderNo(), dataVo.getFshgRequstOrderNo(), e.getMessage());
				throw new FshgBizException("", e.getMessage());
			}
		}// end for

		if (orderDataList.size() > 0) {
			for (OrOrderFshgBasVo ordData : orderDataList) {
				boolean bo = sendNewOrder(ordData);
				// 하나fx 주문시 실패건 처리 + sms 추가 발송
				if (!bo && ordData.getFshgRequstOrderNo() != null) {
					fshgNewOrderService.innerDepartmentSendSms(ordData.getOrderNo(), ordData.getFshgRequstOrderNo(), "하나fx 전송 실패");
					updateOrderFailSttusCode(ordData);
				}
			}
		}

		return param;
	}

	/**
	 * 증거금 취소주문등 Sell position에 해당하는 주문 처리를 한다.
	 */
	@Override
	public OrOrderFshgBasVo executeFshgNewSellOrder(OrOrderFshgBasVo param) throws FshgBizException, Exception {
		/*
		 * Step1. 주문_주문 선물환 기본 정보 조회 (OR_ORDER_FSHG_BAS)
		 */
		List<OrOrderFshgBasVo> fshgBasList = fshgMapper.selectOrOrderFshgBasList(param);

		if (CollectionUtils.isEmpty(fshgBasList)) {
			throw new FshgBizException("", "관련 하나fx 데이터가 존재하지 않아 하나fx 전송을 중지합니다.");
		}

		GfxRfsResVo searchVo = new GfxRfsResVo();
		String searchDate = DateUtil.calDate("yyyyMMdd");  // 기준일 - 오늘날짜
		searchVo.setSearchKeyword(searchDate);

		List<OrOrderFshgBasVo> orderDataList = new ArrayList<>();
		for (OrOrderFshgBasVo dataVo : fshgBasList) {
			try {
				/*
				 * Step2. 요청 만기일자를 이용하여 거래용 환율 정보를 조회한다
				 *        GFX_RFS_RES(거래용 환율 응답 I/F) - 선물환 만기일별 최신 데이타
				 *        하나 FX쪽 장애로 최신 데이터 안들어 올때 시간 차이를 계산해 장애 판단 로직이 있어야 할듯함.
				 *        - 일정 시간 체크 필요. ( ex)30초 이내의 데이터 )
				 */

				//매수 이면서 청산 번호 없는 경우
				String requstPostn = StringUtil.trim(dataVo.getRequstPostn());
				String requstLqdNo = dataVo.getRequstLqdNo();	// 요청 청산 번호
				String requstMsgSe = dataVo.getRequstMssageSe();	// 요청 메시지 구분

				// 22.06.21 PO 테이블에 "선물환관리번호" 존재유무에 따라 "청산(TO)" 또는 "신규(NO)" 주문 이므로 청산 주문일때만 체크
				if ("S".equals(requstPostn) && "TO".equals(requstMsgSe.toUpperCase()) && StringUtil.isEmpty(requstLqdNo)) {
					throw new FshgBizException("", "요청 청산 번호가 존재 하지 않습니다. : REQUST_LQD_NO" );
				}

				String valDt = dataVo.getRequstExprtnde();	//요청 만기일자
				searchVo.setValDt(valDt);
				GfxRfsResVo result = validRecentDataWithGfxRfxRes(searchVo, requstPostn);

				String limPx = result.getNearBid().toString();	/* 선물환 매도 환율 */
				String qtIdx = result.getQtIdx();			    /* 환율 건별 INDEX */
				dataVo.setRequstOrderPc(limPx);
				dataVo.setRequstEhgtIndx(qtIdx);

				orderDataList.add(dataVo);

			} catch (FshgBizException e) {
				// 실패건 sms 추가 발송
				fshgNewOrderService.innerDepartmentSendSms(dataVo.getOrderNo(), dataVo.getFshgRequstOrderNo(), e.getMessage());
				throw new FshgBizException("", e.getMessage());
			}
		}// end for

		if (!orderDataList.isEmpty()) {
			for (OrOrderFshgBasVo ordData : orderDataList) {
				boolean bo = sendNewOrder(ordData);
				// 하나fx 주문시 실패건 처리 + sms 추가 발송
				if (!bo && ordData.getFshgRequstOrderNo() != null) {
					fshgNewOrderService.innerDepartmentSendSms(ordData.getOrderNo(), ordData.getFshgRequstOrderNo(), "하나fx 전송 실패");
					updateOrderFailSttusCode(ordData);
				}
			}
		}

		return param;
	}

	@Override
	public synchronized boolean sendNewOrder(OrOrderFshgBasVo reqVo) {
		try {
			/* Step1.*/
			int seq = fshgService.executeApiIntId(reqVo);
			ApiIntDatReqVo apiIntDatReqVo = fshgService.executeMakeApiIntData(seq, reqVo);
			XCPBMsg xMsg = apiIntDatReqVo.getXcpbMsg();

			/* Step2.*/
			fshgService.insertApiIntDatWithXCPBMsg(seq, xMsg, apiIntDatReqVo);

			/*
			 * Step1 ~ Step2 까지 Exception 발생시 디지타이드에 Data 전송이 되지 않아 RollBack이 되게 함.
			 * Step3. 하나 Fx Message 전송
			 */
			if (fshSendMcast == null) {
				fshSendMcast = FshSendMcast.getInstance();
			}

			fshSendMcast.sendUdpData(xMsg);
			return true;

		} catch (Exception e) {
			log.error("SendOrder Error:", e);
		}

		return false;
	}

	/**
	 * 하나fx 재처리 버튼 재처리
	 * 하나fx 주문 에러시 Bo에서 재처리 버튼을 실행시켜 하나fx 주문을 실행한다.
	 * 재처리시 OR_ORDER_FSHG_BAS의 신규 데이터생성 후 주문을 내야 함.
	 * 잘못하면 OR_ORDER_FSHG_BAS의 모든 row를 주문 낼수 있어 쿼리 조건절 다시 한번 검토바람.
	 */
	@Override
	public OrOrderFshgBasVo executeFshgRehndlNewOrder(OrOrderFshgBasVo reqOrderInfo) throws FshgBizException, Exception {
		String userId = reqOrderInfo.getUserId();
		String orderNo = reqOrderInfo.getOrderNo();
		String fshgRequstOrderNo = reqOrderInfo.getFshgRequstOrderNo();
		boolean isClaim = false;

		/** Step1. 재처리 생성을 위한 원주문 조회 */
		OrOrderFshgBasVo oldOrderInfo = Optional.ofNullable(fshgMapper.selectFailOrderFshgBasInfo(reqOrderInfo))
				.orElseThrow(() -> {
					return new FshgBizException("", "기존 선물환 주문 정보가 없습니다. userId:"
							+ userId +", orderNo:" + orderNo +", fshgRequstOrderNo:" + fshgRequstOrderNo);
				});

		// 매도에 대한 재처리 구분 값 설정
		if ("S".equals(oldOrderInfo.getRequstPostn())) {
			if (StringUtil.isNotBlank(oldOrderInfo.getCanclExchngRtngudNo())
					&& !"00000000-000000".equals(StringUtil.nvl(oldOrderInfo.getCanclExchngRtngudNo()))) {
				isClaim = true;
				log.debug("반대매매(SELL) 재처리 대상");
			}

			// 반대매매시 취소교환반품번호 검증 - 방어로직 추가
			if (StringUtil.isBlank(oldOrderInfo.getCanclExchngRtngudNo())
					|| "00000000-000000".equals(oldOrderInfo.getCanclExchngRtngudNo())) {
				throw new FshgBizException("", "재처리 클레임 번호를 확인할 수 없습니다. CanclExchngRtngudNo: "+ oldOrderInfo.getCanclExchngRtngudNo());
			}
		}

		/** Step2. 재처리시 만기일을 상품 PO 테이블에서 재조회한다. */
		ItPurchsInfoBasVo itPurchsInfoBasVo;
		if (!"S".equals(oldOrderInfo.getRequstPostn())) {
			itPurchsInfoBasVo = fshgMapper.selectNewOrderPurchsInfo(oldOrderInfo);
		} else {
			itPurchsInfoBasVo = fshgMapper.selectClaimPurchsInfo(oldOrderInfo);
		}

		if (null == itPurchsInfoBasVo || StringUtil.isBlank(itPurchsInfoBasVo.getFshgExprtnDe())) {
			throw new FshgBizException("", "상품_PO 정보 기본 테이블에 주문 대상 또는 만기일이 없습니다. userId:"
					+ userId +", orderNo:"+ orderNo +", fshgRequstOrderNo:" + fshgRequstOrderNo);
		}

		String requstExprtnde = itPurchsInfoBasVo.getFshgExprtnDe();

		/** Step3. 기존 주문의 REHNDL_AT - 재처리 여부 = 'Y'처리 */
		oldOrderInfo.setLastChangerId(userId);
		int updCnt = fshgMapper.updateOrderFshgBasRehndlAt(oldOrderInfo);  /* 기존 주문 재처리 여부 체크 */
		if (updCnt != 1) {
			throw new FshgBizException("", "기존 주문 재처리 상태 수정 실패. userId:"
					+ userId +", orderNo:"+ orderNo +", fshgRequstOrderNo:" + fshgRequstOrderNo);
		}

		/** Step4. 신규 주문_주문 선물환 기본 생성 후 FX 주문 처리한다. */
		String newFshgRequstOrderNo = fshgService.getFshgReqOrderNo();
		String oldOrderNo = oldOrderInfo.getOrderNo();
		String oldFshgRequstOrderNo = oldOrderInfo.getFshgRequstOrderNo();

		// 반대매매 PO 만기일 검증 (다음달 선물환 만기일 적용)
		if (isClaim) {
			String toDay = DateUtil.getNowDate();
			int intervalDay = DateUtil.intervalDay(toDay, requstExprtnde); // 금일, 선물환 만기일
			log.info("ORDER_NO [{}] - 금일: {}, 선물환 만기일: {}, 날짜 차이: {}", orderNo, toDay, requstExprtnde, intervalDay);

			// 선물환 만기일자 영업일-3일 까지 주문 가능 (ex: 주문일 1/9, 만기일 1/12)
			if (intervalDay < 3) {
				// 다음달 선물, 선물환 만기일 조회
				Map<String, String> nextExprtnDeMap = fshgMapper.selectNextMonthExprtnDate();
				log.info("다음달 선물환 만기일 : {}", nextExprtnDeMap);
				if (nextExprtnDeMap.isEmpty()
						|| StringUtil.isBlank(String.valueOf(nextExprtnDeMap.get("NEXT_FSHG_EXPRTN_DE")))) {
					throw new FshgBizException("", "다음달 선물환 만기일 미존재");
				}
				requstExprtnde = String.valueOf(nextExprtnDeMap.get("NEXT_FSHG_EXPRTN_DE"));
			}
		}

		OrOrderFshgBasVo insNewFshgInfo = new OrOrderFshgBasVo();
		insNewFshgInfo.setOrderNo(oldOrderNo);
		insNewFshgInfo.setFshgRequstOrderNo(oldFshgRequstOrderNo);
		insNewFshgInfo.setNewFshgRequstOrderNo(newFshgRequstOrderNo);
		insNewFshgInfo.setRequstExprtnde(requstExprtnde);
		insNewFshgInfo.setFrstRegisterId(userId);
		insNewFshgInfo.setLastChangerId(userId);

		// 22.06.21 PO 테이블에 "선물환관리번호" 존재유무에 따라 "청산(TO)" 또는 "신규(NO)" 주문
		// TODO 쿼리에서 이전 데이터로 들어가나 필요시 해당 필드 값 사용할 것
		if (StringUtil.isNotBlank(itPurchsInfoBasVo.getFshgManageNo())) {
			insNewFshgInfo.setRequstMssageSe("TO");
		} else {
			insNewFshgInfo.setRequstMssageSe("NO");
		}

		int insCnt = fshgMapper.insertNewOrOrderFshgBas(insNewFshgInfo);
		if (insCnt != 1) {
			throw new FshgBizException("", "신규 선물환 정보 등록 실패");
		}
		log.info("신규 선물환 정보>> {}", insNewFshgInfo);

		/*
		 * Step4. FX 주문요청
		 */
		OrOrderFshgBasVo newOrderInfo = new OrOrderFshgBasVo();
		newOrderInfo.setOrderNo(oldOrderNo);
		newOrderInfo.setFshgRequstOrderNo(newFshgRequstOrderNo);

		return executeFshgNewOrder(newOrderInfo);
	}


	@Override
	public void updateOrderFailSttusCode(OrOrderFshgBasVo orderInfo) {
		try {
			if(StringUtil.isEmpty(orderInfo.getOrderNo())) {
				throw new Exception("주문번호가 존재하지 않습니다.");
			}

			String orderNo 				= orderInfo.getOrderNo();
			String fshgRequstOrderNo 	= orderInfo.getFshgRequstOrderNo();
			String canclExchngRtngudNo 	= orderInfo.getCanclExchngRtngudNo();
			String rspnsMssage			= orderInfo.getRspnsMssage();

			List<OrOrderFshgBasVo> failList = fshgMapper.selectFshgBasOrderFailList(orderInfo);

			StringBuilder builder = new StringBuilder();
			builder.append("\n <<< FshgNewOrderImpl.updateOrderFailSttusCode >>> ");
			if(failList.size() == 0) {
				builder.append("\n failList size: 0");
				builder.append("\n ORDER_NO : " + orderNo);
				builder.append("\n FSHG_REQUST_ORDER_NO : " + fshgRequstOrderNo);
				builder.append("\n CANCL_EXCHNG_RTNGUD_NO : " + canclExchngRtngudNo);
				builder.append("\n RSPNS_MSSAGE : " + rspnsMssage);
				log.error(builder.toString());
				return;
			}

			builder.append("\n failList size: " + failList.size());
			for(OrOrderFshgBasVo dataVo : failList) {
				dataVo.setRspnsMssage(rspnsMssage);

				int result = fshgMapper.updateFshgBasOrderFail(dataVo);

				builder.append("\n ++++++++++++++++++++++++++++++++++++++++++ ");
				builder.append("\n ORDER_NO : " + dataVo.getOrderNo());
				builder.append("\n FSHG_REQUST_ORDER_NO : " + dataVo.getFshgRequstOrderNo());
				builder.append("\n CANCL_EXCHNG_RTNGUD_NO : " + dataVo.getCanclExchngRtngudNo());
				builder.append("\n RESULT COUNT : " + result);
			}

			log.error(builder.toString());
			/*
			 * 선물환 주문 실패시 신호등 테이블에 실패를 update 한다.
			 */
			fxStateMonitorService.checkFxWorkStatus(false);
		}catch (Exception e) {
			log.error("OrOrderFshgBas update 실패", e);
		}
	}

	/**
	 * 실패 sms 추가 발송 (내부사용자)
	 */
	public void innerDepartmentSendSms(String orderNo, String returnMsg, String errMsg) {
		// templateNum : 46, smsSndngGroupCode : 42
		Map<String, String> smsMap = new HashMap<>();
		smsMap.put("templateNum", "46");
		smsMap.put("commerceNtcnCn", "선물환 처리 실패"); // 커머스 알림 메시지
		smsMap.put("orderNo", orderNo);
		smsMap.put("returnMsg", returnMsg);
		smsMap.put("errMsg", errMsg);
		smsMap.put("excpSndngOptnAt", "Y"); // 예외 발송 옵션 여부, Y일 경우 내부사용자만 발송한다.
		smsService.insertSMS(null, smsMap);
	}
}
