package com.sorincorp.api.hanafx.mo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.sorincorp.api.hanafx.de.mapper.DealingEhgtMapper;
import com.sorincorp.api.hanafx.de.model.GfxRfsResVo;
import com.sorincorp.api.hanafx.mo.mapper.FwSvcMonMapper;
import com.sorincorp.api.hanafx.mo.model.FwSvcMonVo;
import com.sorincorp.comm.cntcsttus.model.CntcSttusVO;
import com.sorincorp.comm.cntcsttus.service.CntcSttusService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@ComponentScan({"com.sorincorp.comm.*"})
public class FxStateMonitorImpl implements FxStateMonitorService{

	@Value("${hanafx.fixid.trd-snd}")
	private String HANAFX_FIXID_TRD_SND;

	@Value("${hanafx.fixid.trd-rcv}")
	private String HANAFX_FIXID_TRD_RCV;

	@Value("${hanafx.fixid.fxq-srn}")
	private String HANAFX_FIXID_FXQ_SRN;

	@Autowired
	private FwSvcMonMapper fwSvcMonMapper;

	@Autowired
	private DealingEhgtMapper ehgtMapper;

	@Autowired
	private CntcSttusService cntcSttusService;

	private final static String INTRFC_SE_CODE_XQ = "20";
	private final static String INTRFC_SE_CODE_FX = "40";

	@Override
	public void checkFxServerStatus(){
		try {
			/*
			인터페이스 구분 코드 : INTRFC_SE_CODE (20	환율, 40	FX)
		   */

			/* API_TRD_SND : 주문 FIX 클라이언트
			   API_FXQ_SRN : 환율 FIX 클라이언트
				둘은 R, S, U, D 상태를 가질 수 있고 'U' 상태가 정상인 상태 */

			/* API_TRD_RCV : 주문 수신 클라이언트
			해당 서비스는 R, S 상태를 가질 수 있고 'R' 상태가 정상인 상태 */
			List<FwSvcMonVo> list = fwSvcMonMapper.selectFxServerStateList();

			Map<String, String> map  = Optional.ofNullable(list).orElseGet(ArrayList<FwSvcMonVo>::new)
					.stream()
					.collect(
							Collectors.toMap(FwSvcMonVo::getSvcId, FwSvcMonVo::getSvcStatus, (oldId, newId) -> newId));

			/* 환율 */
			boolean result = map.containsKey(HANAFX_FIXID_FXQ_SRN) && map.get(HANAFX_FIXID_FXQ_SRN).equals("U");
			if(result) {
				GfxRfsResVo searchVo 	= new GfxRfsResVo();
				String searchDate 		= DateUtil.calDate("yyyyMMdd");  //기준일 - 오늘날짜
				searchVo.setSearchKeyword(searchDate);
				/* 30초 이전 최신 환율이 존재하는지 체크 */
				GfxRfsResVo resVo = ehgtMapper.selectRecentDataWithGfxRfsRes(searchVo);
				if(resVo==null) {
					result = false;
				}
			}
			CntcSttusVO cntcSttusVO = new CntcSttusVO();
			cntcSttusVO.setIntrfcSeCode(INTRFC_SE_CODE_XQ);
			cntcSttusVO.setCheckResult(result);
			cntcSttusVO.setLastChangerId("fxsystem");
			cntcSttusService.updateCoCntcSttusBas(cntcSttusVO);

			/* 주문 전송 */
			boolean result2 = map.containsKey(HANAFX_FIXID_TRD_SND) && map.get(HANAFX_FIXID_TRD_SND).equals("U");
			boolean result3 = map.containsKey(HANAFX_FIXID_TRD_RCV) && map.get(HANAFX_FIXID_TRD_RCV).equals("R");

			cntcSttusVO.setCheckCommnLine(true);                 /* 통신선 체크 작업 true */
			cntcSttusVO.setIntrfcSeCode(INTRFC_SE_CODE_FX);
			cntcSttusVO.setCheckResult(result2&result3);
			cntcSttusService.updateCoCntcSttusBas(cntcSttusVO);
		}catch(Exception e) {
			log.error("checkFxServerStatus", e);
		}
	}

	@Override
	public void checkFxWorkStatus(boolean result) {
		try {
			/*
			 * 선물환 주문 실패시 신호등 테이블에 실패를 update 한다.
			 * 인터페이스 구분 코드 : INTRFC_SE_CODE(40	FX)
			 */
			CntcSttusVO cntcSttusVO = new CntcSttusVO();
			cntcSttusVO.setLastChangerId("fxsystem");
			cntcSttusVO.setIntrfcSeCode(INTRFC_SE_CODE_FX);
			cntcSttusVO.setCheckResult(result);
			cntcSttusService.updateCoCntcSttusBas(cntcSttusVO);
		}catch(Exception e) {
			log.error("checkFxServerStatus", e);
		}
	}
}
