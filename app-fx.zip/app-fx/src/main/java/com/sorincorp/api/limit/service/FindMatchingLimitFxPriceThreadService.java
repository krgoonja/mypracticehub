package com.sorincorp.api.limit.service;

import com.sorincorp.api.hanafx.pr.model.PrEhgtRltmBassVo;

public interface FindMatchingLimitFxPriceThreadService {
	void findMatchingLimitFxPriceThread(PrEhgtRltmBassVo prEhgtRltmBassVo) throws Exception;
}
