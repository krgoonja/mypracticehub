package com.sorincorp.api.hanafx.fs.service;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sorincorp.api.hanafx.exception.FshgBizException;
import com.sorincorp.api.hanafx.fs.model.OrOrderFshgBasVo;

public interface FshgNewOrderService {
	/**
	 * <pre>
	 * 처리내용: Api input 데이터로 하나fx 신규 주문을 실행한다..
	 * </pre>
	 * @date 2021. 10. 20.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 20.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	OrOrderFshgBasVo executeFshgNewOrder(OrOrderFshgBasVo vo) throws FshgBizException, Exception;

	/**
	 * <pre>
	 * 처리내용: 주문실패건에 대한 재처리를 실행한다.
	 * </pre>
	 * @date 2021. 10. 20.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 20.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param orderInfo
	 * @return
	 * @throws FshgBizException
	 * @throws Exception
	 */
	OrOrderFshgBasVo executeFshgRehndlNewOrder(OrOrderFshgBasVo orderInfo) throws FshgBizException, Exception;

	/**
	 * <pre>
	 * 처리내용: 하나fx 주문시 실패건에 대해 "실패" 처리를 수행한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param orderInfo 주문정보
	 */
	void updateOrderFailSttusCode(OrOrderFshgBasVo orderInfo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 전문을 생성하여 디지타이드 호출을 통해 하나은행FX에 주문을 전송한다.
	 * </pre>
	 * @date 2021. 12. 16.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 16.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param reqVo
	 * @return
	 */
	boolean sendNewOrder(OrOrderFshgBasVo reqVo);

	/**
	 * <pre>
	 * 실패 sms 추가 발송 (내부사용자)
	 * </pre>
	 * @date 2022. 9. 20.
	 * @author srec0051
	 * @param orderNo
	 * @param returnMsg
	 * @param errMsg
	 */
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	void innerDepartmentSendSms(String orderNo, String returnMsg, String errMsg);

	/**
	 *
	 * <pre>
	 * 처리내용: 증거금 취소주문등 Sell position 주문 처리를 한다.
	 * </pre>
	 * @date 2022. 10. 6.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2022. 10. 6.			srec0070			최초작성
	 * ------------------------------------------------
	 * @param orderInfo
	 * @return
	 * @throws FshgBizException
	 * @throws Exception
	 */
	OrOrderFshgBasVo executeFshgNewSellOrder(OrOrderFshgBasVo orderInfo) throws FshgBizException, Exception;
}
