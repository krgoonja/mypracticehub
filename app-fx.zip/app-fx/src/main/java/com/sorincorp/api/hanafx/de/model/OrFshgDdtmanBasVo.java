package com.sorincorp.api.hanafx.de.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class OrFshgDdtmanBasVo {
	    /**
	     * 적용 일자
	    */
	    private String applcDe;
	    /**
	     * 삭제 일시
	    */
	    private java.sql.Timestamp deleteDt;
	    /**
	     * 삭제 여부
	    */
	    private String deleteAt;
	    /**
	     * 최초 등록자 아이디
	    */
	    private String frstRegisterId;
	    /**
	     * 최초 등록 일시
	    */
	    private java.sql.Timestamp frstRegistDt;
	    /**
	     * 최종 변경자 아이디
	    */
	    private String lastChangerId;
	    /**
	     * 최종 변경 일시
	    */
	    private java.sql.Timestamp lastChangeDt;
}
