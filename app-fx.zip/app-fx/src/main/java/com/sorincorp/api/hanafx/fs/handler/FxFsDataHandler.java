package com.sorincorp.api.hanafx.fs.handler;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.digitide.xcube.XCPBMsg;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.api.hanafx.fs.model.ApiIntDatResVo;
import com.sorincorp.api.hanafx.fs.model.ApiIntDatVo;
import com.sorincorp.api.hanafx.fs.service.FshgService;
import com.sorincorp.api.hanafx.socket.MessageCast;
import com.sorincorp.api.util.ApiCmmUtil;
import com.sorincorp.api.util.FshgConst;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class FxFsDataHandler extends MessageCast{
	@Autowired
	private FshgService fshgService;

    private String[] resVoKesy = {
    		"msgTp", "cliOrdNo", "cliOrgOrdNo", "ordNo", "ordTp", "prodCd", "pairId", "valDt", "matDt", "currCd",
    		"custId", "bsTp", "condTp", "limPx", "tif", "ordAmt", "tktAmt", "remAmt", "acptTp", "tktNo",
    		"nearRate", "nearAmt", "farRate", "farAmt", "retText"
    };

    private int[] resLength = {
    		FshgConst.RECV_MSG_TP_LEN,
    		FshgConst.RECV_CLI_ORD_NO_LEN,
    		FshgConst.RECV_CLI_ORG_ORD_NO_LEN,
    		FshgConst.RECV_ORD_NO_LEN,
    		FshgConst.RECV_ORD_TP_LEN,
    		FshgConst.RECV_PROD_CD_LEN,
    		FshgConst.RECV_PAIR_ID_LEN,
    		FshgConst.RECV_VAL_DT_LEN,
    		FshgConst.RECV_MAT_DT_LEN,
    		FshgConst.RECV_CURR_CD_LEN,
    		FshgConst.RECV_CUST_ID_LEN,
    		FshgConst.RECV_BS_TP_LEN,
    		FshgConst.RECV_COND_TP_LEN,
    		FshgConst.RECV_LIM_PX_LEN,
    		FshgConst.RECV_TIF_LEN,
    		FshgConst.RECV_ORD_AMT_LEN,
    		FshgConst.RECV_TKT_AMT_LEN,
    		FshgConst.RECV_REM_AMT_LEN,
    		FshgConst.RECV_ACPT_TP_LEN,
    		FshgConst.RECV_TKT_NO_LEN,
    		FshgConst.RECV_NEAR_RATE_LEN,
    		FshgConst.RECV_NEAR_AMT_LEN,
    		FshgConst.RECV_FAR_RATE_LEN,
    		FshgConst.RECV_FAR_AMT_LEN,
    		FshgConst.RECV_RET_TEXT_LEN
    };

	public void recvFshNewOrder(String msg) {
		try {
			XCPBMsg pbMsg = new XCPBMsg();
			pbMsg.read(msg, msg.length());

			String type  = pbMsg.type();
			String svc   = pbMsg.svc();
			int seq1 	 = pbMsg.seq1();         //digitide 담당자와(김동현)과 seq1에 reqseq를 넣어 주기로 함.
			int seq2 	 = pbMsg.seq2();
			String code  = pbMsg.code();
			String code1 = "API_TRD_RCV";

			if(log.isInfoEnabled()) {
				log.info("Rcv Result : [type:[{}], svc:[{}], seq1[{}], seq2[{}], code:[{}]]", type, svc, seq1, seq2, code);
				String dumpMsg = msgDump("환율 주문 응답 DUMP PBMSG", pbMsg);
				log.info(dumpMsg);
			}

			/* API_INT_DAT 테이블 데이타 */
			ApiIntDatVo appiIntDatVo = new ApiIntDatVo();
			appiIntDatVo.setIntId(code1);
			appiIntDatVo.setReqSeq(seq1);
			String rcvData = pbMsg.data();
			appiIntDatVo.setReqDat(rcvData);


			/* API_INT_DAT_RES 테이블 데이타 */
			ApiIntDatResVo apiIntDatResVo = parseRcvData(appiIntDatVo);

			fshgService.saveRecvFutureExchange(appiIntDatVo, apiIntDatResVo);
		} catch (Exception e) {
			log.error(this.getClass().getName(), e);
		}
	}

	private ApiIntDatResVo parseRcvData(ApiIntDatVo appiIntDatVo) {
		ApiIntDatResVo resVo = null;
		try {

			ApiIntDatVo resultVo = fshgService.selectApiIntDat(appiIntDatVo);
			if(resultVo==null) {
				log.error("Fx Data is null. [{}] [{}] [{}]", appiIntDatVo.getIntId(), appiIntDatVo.getReqSeq(), appiIntDatVo.getReqDat());
				return null;
			}

			String tmpReqData = resultVo.getReqDat();
			byte[] bytes = tmpReqData.getBytes();

			int offset = 0;
			Map<String, Object> map = new HashMap<>();
			String value = "";
			int keylen = resVoKesy.length;
			for(int i=0; i<keylen; i++) {
				String key     = resVoKesy[i];
				int val_length = resLength[i];
				value = ApiCmmUtil.bytes2StringNew(bytes, offset, val_length);
				offset += val_length;

				map.put(key, StringUtil.trim(value));
			}

			ObjectMapper mapper = new ObjectMapper();
			resVo = mapper.convertValue(map, ApiIntDatResVo.class);

			if(log.isInfoEnabled()) {
				String printStr = "Fshg Order RCV Data (length:" + tmpReqData.getBytes().length + ")\n";
				printStr += resVo.print();
				log.info(printStr);
			}

			return resVo;
		}catch(Exception e) {
			log.error(this.getClass().getName(), e);
		}

		return null;
	}
}
