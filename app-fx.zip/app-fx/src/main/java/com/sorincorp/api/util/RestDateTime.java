package com.sorincorp.api.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import com.sorincorp.comm.bsnInfo.model.RestdeFxLmeVO;
import com.sorincorp.comm.bsnInfo.model.RestdeVO;
import com.sorincorp.comm.bsnInfo.service.BsnInfoService;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@ComponentScan("com.sorincorp.comm.*")
public class RestDateTime {

	public enum Operator {
		PLUS, MINUS
	}

	@Autowired
	private BsnInfoService bsnInfoService;

	private static boolean isLmeRestDay = false;

	private static boolean isRestDay = false;
	private static boolean isRestTime = false;
	private static String restBeginTime = "";
	private static String restEndTime = "";
	private static boolean isRealTimeSellRestDay = false;
	private static String realSellBeginTime = "";
	private static String realSellEndTime = "";

	public void initialize() throws Exception {
		RestdeVO restdeVO = bsnInfoService.getRestdeInfoWithoutHvofTime(DateUtil.getNowDateTime("yyyyMMdd"));	//[pje]수정
		RestdeFxLmeVO restdeFxLmeVO = bsnInfoService.getRestdeFxLmeInfo(DateUtil.getNowDateTime("yyyyMMdd"));

		isLmeRestDay = "Y".equals(restdeFxLmeVO.getLmeRestdeAt()) ? true : false;

		isRestDay = "Y".equals(restdeVO.getDeAcctoRestdeAt()) ? true : false;

		isRestTime = "Y".equals(restdeVO.getTimeAcctoRestdeAt()) ? true : false;
		restBeginTime = restdeVO.getTimeAcctoRestdeBeginTime();
		restEndTime = restdeVO.getTimeAcctoRestdeEndTime();

		isRealTimeSellRestDay = "Y".equals(restdeVO.getRltmRestdeAt()) ? true : false;
		realSellBeginTime = restdeVO.getRltmBeginTime();
		realSellEndTime = restdeVO.getRltmEndTime();

		log.info("============================[FX] RestDate============================");
		log.info(" restdeVO : " + restdeVO);
		log.info(" restdeFxLmeVO : " + restdeFxLmeVO);
		log.info(" isLmeRestDay : " + isLmeRestDay);
		log.info(" isRestDay : " + isRestDay);
		log.info(" isRestTime : " + isRestTime);
		log.info(" restBeginTime : " + restBeginTime + " / restEndTime : " + restEndTime);
		log.info(" isRealTimeSellRestDay : " + isRealTimeSellRestDay);
		log.info(" realSellBeginTime : " + realSellBeginTime + " / realSellEndTime : " + realSellEndTime);
		log.info("================================================================");
	}

	public boolean isSorinRltmWorkTime() throws Exception {
		if(!isRestDay) {
			if(isRestTime) {
				if(!"".equals(restBeginTime) && !"".equals(restEndTime)) {
					int nowTime = Integer.parseInt(DateUtil.getNowDateTime("HHmmss"));
					if(Integer.parseInt(restBeginTime) <= nowTime && nowTime <= Integer.parseInt(restEndTime)) {
						return false;
					}
				}
			}

			return isRealRltmSellTime();
		}

		return false;
	}

	public boolean isRealRltmSellTime() throws Exception {
		if(!isRealTimeSellRestDay) {
			if(!"".equals(realSellBeginTime) && !"".equals(realSellEndTime)) {
				int nowTime = Integer.parseInt(DateUtil.getNowDateTime("HHmmss"));
				int beginTime = Integer.parseInt(realSellBeginTime);
				int endTime = Integer.parseInt(realSellEndTime);

				if(beginTime <= nowTime && nowTime <= endTime) {
					return true;
				}
			}
		}

		return false;
	}

}
