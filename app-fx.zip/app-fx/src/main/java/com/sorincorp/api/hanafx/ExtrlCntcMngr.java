package com.sorincorp.api.hanafx;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.digitide.xcube.XCPBMsg;
import com.sorincorp.api.hanafx.de.handler.FxDeDataHandler;
import com.sorincorp.api.hanafx.pr.handler.FxPrDataHandler;
import com.sorincorp.api.hanafx.socket.DelngEhgtRecvMcast;
import com.sorincorp.api.hanafx.socket.DelngEhgtSendMcast;
import com.sorincorp.api.hanafx.socket.FshRecvMcast;
import com.sorincorp.api.util.RestDateTime;
import com.sorincorp.comm.it.service.ItService;
import com.sorincorp.comm.limit.service.LimitService;
import com.sorincorp.comm.limit.service.OrLimitOrderBasVoMapService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Lazy
public class ExtrlCntcMngr {
	public static boolean EXTRLCNTCMNGR_ENABLE = false;

	@Autowired
	private FshRecvMcast fshRecvMcast;

	@Autowired
	private DelngEhgtRecvMcast delngEhgtRecvMcast;

	@Autowired
	private DelngEhgtSendMcast delngEhgtSendMcast;

	@Autowired
	private FxDeDataHandler deDataHandler;

	@Autowired
	private FxPrDataHandler prDataHandler;

	@Autowired
	private ItService itService;

	@Autowired
	private LimitService limitService;

	@Autowired
	private RestDateTime restDateTime;

	@Autowired
	private OrLimitOrderBasVoMapService orderLimitOrderBasVoMapService;

	public void start() {
		if(EXTRLCNTCMNGR_ENABLE) {
			log.info("This ExtrlCntcMngr App has already started.");
			return;
		}

		log.info("This ExtrlCntcMngr starts to initialize");

		 try {
			/* 선물 선물환 관리 상세 조회 */
			itService.selectTopItFtrsFshgManageDtl();
			/* 운영시간 조회 */
			restDateTime.initialize();
		} catch (Exception e) {
			log.info("0.FX-start() error :{}" , e.getMessage());
		}

		log.info("1.FX-DeDataHandler.isAlive() :{}" , deDataHandler.isAlive());
		if( !deDataHandler.isAlive() ) {
			deDataHandler.setName("FX-DeDataHandler");
			deDataHandler.setDaemon(true);
			deDataHandler.start();
		}
		log.info("1.FX-DeDataHandler.isAlive() :{}" , deDataHandler.isAlive());

		log.info("2.FX-PrDataHandler.isAlive() :{}" , prDataHandler.isAlive());
		if( !prDataHandler.isAlive() ) {
			prDataHandler.setName("FX-PrDataHandler");
			prDataHandler.setDaemon(true);
			prDataHandler.start();
		}
		log.info("2.FX-PrDataHandler.isAlive() :{}" , prDataHandler.isAlive());

		log.info("3.FshRecvMcast.isAlive() :{}" , fshRecvMcast.isAlive());
		if(!fshRecvMcast.isAlive()) {
			fshRecvMcast.setName("FX-FshRecvMcast");
			fshRecvMcast.setDaemon(true);
			fshRecvMcast.start();
		}
		log.info("3.FshRecvMcast.isAlive() :{}" , fshRecvMcast.isAlive());


		/*  실시간 거래용 환율 수신 및 차트용 환율 수신 서버 */
		log.info("4.DelngEhgtRecvMcast.isAlive() :{}" , delngEhgtRecvMcast.isAlive());

		if(!delngEhgtRecvMcast.isAlive()) {
			delngEhgtRecvMcast.setName("FX-DelngEhgtRecvMcast");
			delngEhgtRecvMcast.setDaemon(true);
			delngEhgtRecvMcast.start();
		}
		log.info("4.DelngEhgtRecvMcast.isAlive() :{}" , delngEhgtRecvMcast.isAlive());


		/* 거래용 환율 실시간 요청 초기화 */
		delngEhgtSendMcast.execute();

		/* 가단가 FX 지정가 주문 초기화 */
		try {
			orderLimitOrderBasVoMapService.setOrderCommPrvsnlLimitOrderRedisMsgVoFxMap(limitService.loadInitialPrvsnlLimitFxData());
			orderLimitOrderBasVoMapService.getOrderCommPrvsnlLimitOrderRedisMsgVoFxMap().values().stream()
				.flatMap(Set::stream)
				.forEach(msgVO -> orderLimitOrderBasVoMapService.getPrvsnlLimitOrderNoInputAmountVo(msgVO.getLimitOrderNo()).setLimitInputAmount(msgVO.getLimitInputAmount()));

		} catch (Exception e) {
			log.info("5.FX-loadInitialPrvsnlLimitFxData error :{}" , e.getMessage());
		}

		EXTRLCNTCMNGR_ENABLE = true;
		log.info("This ExtrlCntcMngr ends initialization.");
	}

	/**
	 * <pre>
	 * 처리내용: 거래용 환율 데이터를 처리한다.
	 * </pre>
	 * @date 2021. 11. 16.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 16.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param pbMsg
	 */
	public void addDelngEhgtData(XCPBMsg pbMsg) {
		try {
			if(deDataHandler != null)
				deDataHandler.add(pbMsg);
		} catch (Exception e) {
			log.error("addDeData", e);
		}
	}

	/**
	 * <pre>
	 * 처리내용: 차트용 환율 데이터를 처리한다.
	 * </pre>
	 * @date 2021. 11. 16.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 16.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param pbMsg
	 */
	public void addPrEhgtRltmData(XCPBMsg pbMsg) {
		try {
			if(prDataHandler != null)
				prDataHandler.add(pbMsg);
		} catch (Exception e) {
			log.error("addPrData", e);
		}
	}
}