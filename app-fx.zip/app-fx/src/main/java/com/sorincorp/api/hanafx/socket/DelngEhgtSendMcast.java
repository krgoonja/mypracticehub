package com.sorincorp.api.hanafx.socket;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.Calendar;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.digitide.xcube.XCPBMsg;
import com.sorincorp.api.hanafx.de.model.GfxRfsReqVo;
import com.sorincorp.api.hanafx.de.model.GtxApiFxTenorVo;
import com.sorincorp.api.hanafx.de.model.OrFshgDdtmanBasVo;
import com.sorincorp.api.hanafx.de.service.DealingEhgtService;
import com.sorincorp.api.util.DelngEhgtConst;
import com.sorincorp.comm.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class DelngEhgtSendMcast extends MessageCast{

	@Value("${hanafx.udp.ip}")
	private String hanafxIp;

	@Value("${hanafx.udp.delngEhgt.send-port}")
	private int port;

	@Autowired
	private DealingEhgtService sendService;

	private MulticastSocket socket;
	private InetAddress address;

	@PostConstruct
	public void init() {
		try {
			socket = new MulticastSocket();
			address = InetAddress.getByName(hanafxIp);
			socket.joinGroup(address);
		} catch (IOException e) {
			log.error(getClass().getName(), e);
		}
		log.info("Hana DelngEhgtSendMcast Socket OK");
		log.info("hanafxIp :{}", hanafxIp);
		log.info("port :{}", port);
	}

	public void execute_20211215_BAK(){
		try {
			/* 현물환 정보 요청 */
			GfxRfsReqVo sptVo = sendService.executeSPTEhgtService();
			if(sptVo == null) {
				log.info("기존 거래용 현물환 요청 정보가 등록 되어 있습니다.");
			}

	        /*
	         * 1. insert GFX_RFS_REQ table
	         * -- FWD는 휴일 제외하고 2영업일 이후 날자 지정 가능
	         * 만기일 선물환 6개, 현물환 1개 테스트
	         * 최근일 기준으로 6개월 만기일자 구하기
	         */
			String nowDe 		= DateUtil.calDate(DelngEhgtConst.HANAFX_DATE_FORMAT1); //현재일
			int businessDays = 0;
			String threeBusinessDay = null;
			for(int i=1; i<14; i++) {
				String nowDe2 = DateUtil.addDays(nowDe, i).replace("-", "");
				if(checkBusinessDays(nowDe2)) {
					businessDays++;
				}

				if(businessDays==3) {
					threeBusinessDay = nowDe2;
					break;
				}
			}

			String nowExprtnMt 	= threeBusinessDay.substring(0, 6);                		//2영업일 초과한 기준 현재 만기월
			String tmpExprtnDe  = nowExprtnMt + "01";                                   //ex)20211101

			for(int i=0; i<7; i++) {  //6개월 까지의 만기일자
				String nextTmpDt = DateUtil.addMonths(tmpExprtnDe, i).replace("-", "");
				String nextExprtnMt = nextTmpDt.substring(0, 6);                         //ex)202112, 202201..

				GfxRfsReqVo nextFwdVo = sendService.executeFWDEhgtService(nextExprtnMt);
				if(nextFwdVo == null) {
					log.info("{} 거래용 선물환 환율 요청 정보가 등록 되어 있습니다.", nextExprtnMt);
				}
			}

		}catch(Exception e) {
			log.error(getClass().getName(), e);
		}
	}

	public void execute(){
		try {
			/* 현물환 정보 요청 */
			GfxRfsReqVo sptVo = sendService.executeSPTEhgtService();
			if(sptVo == null) {
				log.info("기존 거래용 현물환 요청 정보가 등록 되어 있습니다.");
			}

			/*
			 *  1. GTX_API_FX_TENOR(환율 기간) 조회하여 오늘 날짜 기준으로 SPT 영업일 조회
			 *  2. 결과가 없으면 자체적으로 SPT 영업일 계산
			 *  3. 계산된 영업일 기준으로 OR_FSHG_DDTMAN_BAS 테이블 조회
			 */
			String nowDe 		= DateUtil.calDate(DelngEhgtConst.HANAFX_DATE_FORMAT1); //현재일
			GtxApiFxTenorVo tenorVo = new GtxApiFxTenorVo();
			tenorVo.setProdCd("SPT");
			tenorVo.setPairId("USD/KRW");
			tenorVo.setTenorCd("SPT");
			tenorVo.setActiveYn("Y");
			tenorVo.setUpdDt(nowDe);

			GtxApiFxTenorVo rsTenorVo = sendService.executeValidProdValDt(tenorVo);
			String twoBusinessDay = null;
			if(rsTenorVo != null) {
				twoBusinessDay = rsTenorVo.getValDt().trim();   /* 현물환 주문 가능일자 - 오늘 기준 2영업일 까지 */
				log.info("######## SPT DATE :[" + twoBusinessDay + "] ########");
			}

			if(twoBusinessDay==null || "".equals(twoBusinessDay)) {
				int businessDays = 0;
				for(int i=1; i<14; i++) {
					String nowDe2 = DateUtil.addDays(nowDe, i).replace("-", "");
					if(checkBusinessDays(nowDe2)) {
						businessDays++;
					}

					if(businessDays==2) {                      /* 현물환 주문 가능일자 - 오늘 기준 주말기준 2영업일 까지 */
						twoBusinessDay = nowDe2;
						break;
					}
				}
			}

			OrFshgDdtmanBasVo basVo = new OrFshgDdtmanBasVo();
			basVo.setApplcDe(twoBusinessDay);
			List<OrFshgDdtmanBasVo> rsBasVoList = sendService.executeValidApplcDeList(basVo);
			for(OrFshgDdtmanBasVo resvO : rsBasVoList) {
				String nextExprtnMt = resvO.getApplcDe().trim();
				GfxRfsReqVo nextFwdVo = sendService.executeFWDEhgtService(nextExprtnMt);
				if(nextFwdVo == null) {
					log.info("{} 거래용 선물환 환율 요청 정보가 등록 되어 있습니다.", nextExprtnMt);
				}
			}
		}catch(Exception e) {
			log.error(getClass().getName(), e);
		}
	}

	private boolean checkBusinessDays(String currDay) {
		boolean isBusinessDay = true;
		Calendar c    = DateUtil.getCalendar(currDay);
		int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
		//1.휴일 체크
		switch (dayOfWeek) {
		 	//일요일(1), 토요일(7)
			case Calendar.SUNDAY: case Calendar.SATURDAY:
				isBusinessDay = false;
				break;
			default:
				break;
		}

		return isBusinessDay;
	}

	private synchronized void send(GfxRfsReqVo reqVo) throws IOException {
		String prodCd 	= reqVo.getProdCd();
	    String pairId 	= reqVo.getPairId();
	    String currCd 	= reqVo.getCurrCd();
	    String valDt 	= reqVo.getValDt();
	    String matDt 	= reqVo.getMatDt();
	    String amt1 	= reqVo.getAmt1();
	    String msgCode = prodCd + pairId + currCd + valDt + matDt + amt1;

		/*
		 * 1.XCPBMsg 생성
		 */
		String msgType = "I";
		String msgSvc  = "DQ";
		XCPBMsg pbMsg  = new XCPBMsg();

		/* pbMsg Set Header */
		pbMsg.type(msgType);
		pbMsg.svc(msgSvc);
		pbMsg.seq1(0);
		pbMsg.seq2(0);
		/* Set Message Code */
		pbMsg.code(msgCode);

		/* pbMsg Set Body */
		pbMsg.add_value(reqVo.getMdReqId(), 	DelngEhgtConst.SEND_MD_REQ_ID_LEN); /* MD_REQ_ID */
		pbMsg.add_value(reqVo.getMdReqTp(), 	DelngEhgtConst.SEND_MD_REQ_TP_LEN); /* MD_REQ_TP */
		pbMsg.add_value(prodCd, 				DelngEhgtConst.SEND_PROD_CD_LEN); /* PROD_CD */
		pbMsg.add_value(pairId, 				DelngEhgtConst.SEND_PAIR_ID_LEN); /* PAIR_ID */
		pbMsg.add_value(currCd, 				DelngEhgtConst.SEND_CURR_CD_LEN); /* CURR_CD */
		pbMsg.add_value(valDt, 					DelngEhgtConst.SEND_VAL_DT_LEN); /* VAL_DT */
		pbMsg.add_value(matDt, 					DelngEhgtConst.SEND_MAT_DT_LEN); /* MAT_DT */
		pbMsg.add_value(amt1, 					DelngEhgtConst.SEND_AMT1_LEN); /* AMT1 */
		pbMsg.add_value(reqVo.getUserId(), 		DelngEhgtConst.SEND_USER_ID_LEN); /* USER_ID */
		pbMsg.add_value(reqVo.getReqTm(), 		DelngEhgtConst.SEND_REQ_TM_LEN); /* REQ_TM */
		pbMsg.add_value(reqVo.getStatus(), 		DelngEhgtConst.SEND_STATUS_LEN); /* STATUS */

		DatagramPacket packet = new DatagramPacket(pbMsg.data().getBytes(), pbMsg.length(), this.address, this.port);
		socket.send(packet);
	}
}