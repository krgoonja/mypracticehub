package com.sorincorp.api.hanafx.fs.mapper;

import java.util.List;
import java.util.Map;

import com.sorincorp.api.hanafx.fs.model.ApiIntDatReqVo;
import com.sorincorp.api.hanafx.fs.model.ApiIntDatResVo;
import com.sorincorp.api.hanafx.fs.model.ApiIntDatVo;
import com.sorincorp.api.hanafx.fs.model.ApiIntSeqVo;
import com.sorincorp.api.hanafx.fs.model.ItPurchsInfoBasVo;
import com.sorincorp.api.hanafx.fs.model.OrOrderFshgBasVo;

public interface FshgMapper {

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	int selectMaxKeyApiIntSeq(ApiIntSeqVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void updateApiIntSeq(ApiIntSeqVo vo) throws Exception;

	/* API_INT_DAT 테이블*/
	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertApiIntDat(ApiIntDatVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void updateApiIntDat(ApiIntDatVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	ApiIntDatVo selectApiIntDat(ApiIntDatVo vo) throws Exception;

	/* API_INT_DAT_REQ 테이블*/
	/**
	 * <pre>
	 * 처리내용: 메소드 처리 내용을 기술한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertApiIntDatReq(ApiIntDatReqVo vo)  throws Exception;

	/**
	 * <pre>
	 * 처리내용: 하나은행으로 부터 수신된 청산 주문 체결 내용을 파싱하여 저장한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertApiIntDatRes(ApiIntDatResVo vo) throws Exception;

	/**
	 * <pre>
	 * 처리내용:  하나은행으로 부터 수신된 최초 EFX HTTS 신규 주문 체결 내용을 파싱하여 저장한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @throws Exception
	 */
	void insertLqdIntDatRes(ApiIntDatResVo vo) throws Exception;

	/**
	 * 주문번호에 매핑되는 주문_주문 선물환 기본 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 주문_주문 선물환 기본 목록
	 * @exception Exception
	 */
	List<OrOrderFshgBasVo> selectOrOrderFshgBasList(OrOrderFshgBasVo searchVO) throws Exception;

	/**
	 * 주문번호에 매핑되는 주문_주문 선물환 기본 정보를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 주문_주문 선물환 기본 목록
	 * @exception Exception
	 */
	OrOrderFshgBasVo selectFailOrderFshgBasInfo(OrOrderFshgBasVo searchVO) throws Exception;

	/**
	 * <pre>
	 * 선물환요청주문번호에 매핑되는 주문_주문 선물환 기본 정보 조회
	 * </pre>
	 * @date 2023. 1. 6.
	 * @author srec0051
	 * @param searchVO
	 * @return
	 * @throws Exception
	 */
	OrOrderFshgBasVo selectOrderFshgBasInfo(OrOrderFshgBasVo searchVO) throws Exception;

	/**
	 * 선물환 주문전 거래 환율중 최신 데이터를 저장한다.
	 * @param updateVO - update 정보가 담긴 VO
	 * @return update 결과값
	 * @exception Exception
	 */
	int updateOrOrderFshgBasReqData(OrOrderFshgBasVo updateVO) throws Exception;

	/**
	 * 하나FX 선물환 주문후 응답데이더를 저장한다.
     * @param updateVO - update 정보가 담긴 VO
	 * @return update 결과값
	 * @exception Exception
	 */
	int updateOrOrderFshgBasResData(OrOrderFshgBasVo updateVO) throws Exception;

	int insertTestOrOrderFshgBas(OrOrderFshgBasVo insterVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 기존 주문_주문 선물환 기본 테이블의 재처리 여부 상태를 update 처리한다.
	 * </pre>
	 * @date 2021. 8. 23.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 23.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param orderInfo
	 * @return
	 * @throws Exception
	 */
	int updateOrderFshgBasRehndlAt(OrOrderFshgBasVo orderInfo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 선물환 재처리를 위해 신규 선물환 기본 정보를 생성한다.
	 * </pre>
	 * @date 2021. 8. 23.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 8. 23.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param orderInfo
	 * @return
	 * @throws Exception
	 */
	int insertNewOrOrderFshgBas(OrOrderFshgBasVo orderInfo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 하나fx 주문 에러목록을 조회한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param searchVO
	 * @return
	 * @throws Exception
	 */
	List<OrOrderFshgBasVo> selectFshgBasOrderFailList(OrOrderFshgBasVo searchVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 하나fx 주문 에러건을 실패처리한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param uodateVO
	 * @return
	 * @throws Exception
	 */
	int updateFshgBasOrderFail(OrOrderFshgBasVo uodateVO) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 선물환 재처리를 위해 "상품_PO 정보 기본" 테이블에서 PO정보를 조회한다.
	 * </pre>
	 * @date 2021. 10. 19.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 10. 19.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param orderInfo
	 * @return
	 * @throws Exception
	 */
	ItPurchsInfoBasVo selectNewOrderPurchsInfo(OrOrderFshgBasVo orderInfo) throws Exception;


	/**
	 * <pre>
	 * 클레임 선물환 주문 재처리를 위해 PO 테이블의 만기일 등을 조회한다.
	 * </pre>
	 * @date 2021. 11. 11.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 11.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param orgClaimInfo
	 * @return
	 */
	ItPurchsInfoBasVo selectClaimPurchsInfo(OrOrderFshgBasVo orgClaimInfo) throws Exception;

	/**
	 * 선물환 요청번호로 주문번호 조회
	 * @param fshgRequstOrderNo
	 * @return
	 */
	String getOrderNo(String fshgRequstOrderNo) throws Exception;

	/**
	 * <pre>
	 * 다음달 선물, 선물환 만기일을 조회
	 * </pre>
	 * @date 2023. 1. 5.
	 * @author srec0051
	 * @return
	 * @throws Exception
	 */
	Map<String, String> selectNextMonthExprtnDate() throws Exception;

	/**
	 * <pre>
	 * PO 테이블 선물환 만기일자 수정
	 * </pre>
	 * @date 2023. 1. 6.
	 * @author srec0051
	 * @param itPurchsInfoBasVo
	 * @return
	 */
	int updateExprtndeItPurchsInfoBas(ItPurchsInfoBasVo itPurchsInfoBasVo) throws Exception;

	/**
	 * <pre>
	 * PO 테이블 히스토리 등록
	 * </pre>
	 * @date 2023. 1. 6.
	 * @author srec0051
	 * @param itPurchsInfoBasVo
	 */
	void insertItPurchsInfoBasHst(ItPurchsInfoBasVo itPurchsInfoBasVo) throws Exception;

	/**
	 * <pre>
	 * 처리내용: 현재일(고시일자)의 하나은행이 등록한 달러 환산율을 조회한다.
	 * </pre>
	 * @date 2023. 11. 22.
	 * @author srec0070
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2023. 11. 22.			srec0070			최초작성
	 * ------------------------------------------------
	 * @return
	 * @throws Exception
	 */
	java.math.BigDecimal selectValueDeGtxApiFxrate() throws Exception;
}
