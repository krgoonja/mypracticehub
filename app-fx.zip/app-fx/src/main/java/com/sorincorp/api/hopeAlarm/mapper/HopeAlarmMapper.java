package com.sorincorp.api.hopeAlarm.mapper;

import java.util.List;

import com.sorincorp.api.hopeAlarm.model.HopeAlarmVO;

public interface HopeAlarmMapper {

	public void insertHopePcNtcnSndngBasList(HopeAlarmVO vo);
	
	public List<HopeAlarmVO> getHopePcNtcnSndngBas(HopeAlarmVO vo);
	
	public List<HopeAlarmVO> getHopePcZnNtcnSetupBas(HopeAlarmVO vo);

	public void insertHopePcZnNtcnSndngBasList(HopeAlarmVO vo);
	
	public List<HopeAlarmVO> getHopePcZnNtcnSndngBas(HopeAlarmVO vo);
	
	public List<HopeAlarmVO> selectAppPushMember(HopeAlarmVO vo);

	public void updateHopePushAlarmReturn(HopeAlarmVO vo);
}
