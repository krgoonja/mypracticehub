package com.sorincorp.api.hanafx.de.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sorincorp.api.hanafx.de.mapper.DealingEhgtMapper;
import com.sorincorp.api.hanafx.de.model.GfxRfsReqVo;
import com.sorincorp.api.hanafx.de.model.GfxRfsResVo;
import com.sorincorp.api.hanafx.de.model.GtxApiFxTenorVo;
import com.sorincorp.api.hanafx.de.model.OrFshgDdtmanBasVo;
import com.sorincorp.api.util.ApiCmmUtil;
import com.sorincorp.api.util.DelngEhgtConst;
import com.sorincorp.comm.util.DateUtil;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("dealingEhgtService")
public class DealingEhgtServiceImpl implements DealingEhgtService{

	@Autowired
	private DealingEhgtMapper dealingEhgt;

	/**
	 * 일별 크론 작업에 의해 전날 등록된 환율 요청 데이터를 GFX_RFS_REQ 테이블에서 초기화 한다.
	 */
	@Override
	public int deleteGfxRfsReqWithSchedule() throws Exception {
//		dealingEhgt.insertGfxRfsReqHisWithSchedule();
		return dealingEhgt.deleteGfxRfsReqWithSchedule();
	}

	@Override
	public void executeRecvEhgtService(GfxRfsResVo vo) throws Exception {
		/*
		 * Step1. 수신 받은 환율 정보를 GFX_RFS_RES(거래용 환율 응답 I/F) 테이블에 등록한다.
		 */
		dealingEhgt.insertGfxRfsRes(vo);
	}

	@Override
	public GfxRfsReqVo executeSPTEhgtService() throws Exception {
		GfxRfsReqVo reqVo = new GfxRfsReqVo();
		reqVo.setMdReqTp(DelngEhgtConst.SEND_MD_REQ_TP_OPEN);    		/*	환율 요청 구분: O= open C= close							        				SubscriptionRequestType	*/
//		reqVo.setProdCd(DelngEhgtConst.SEND_PROD_CD_SPT);        		/*	상품코드: 상품 코드 	SPT,FWD,FFF, FXS						        				SecurityDesc	*/
															 			/*	(현물환, 선물환/자유만기 선물환, FX 스왑 )			*/
		reqVo.setPairId(DelngEhgtConst.SEND_PAIR_ID_USD_KRW);			/*	거래 통화 코드: USD/KRW, EUR/KRW 등의 거래통화 코드				        				 USD/JPY	Symbol	*/
		reqVo.setCurrCd(DelngEhgtConst.SEND_CURR_CD_USD);               /*	거래 통화:	거래 기준 통화  CUR1 또는 CUR2	USD    KRW  EUR ..	        				 Currency	*/
		String valDt = DateUtil.calDate(DelngEhgtConst.HANAFX_DATE_FORMAT1);  //현물환은 오늘 날짜로 보내준다.
		reqVo.setValDt(valDt);                               			/*	Near 결제일: 결제일 1	202100								        				 SettlDate	*/

		reqVo.setMatDt(DelngEhgtConst.SEND_MAT_DT);     				/*	Far 결제일: 결제일 2  , prod_cd 가 FXS 가 아니면 항상 000000 으로 사용	0					 SettlDate2	*/
		reqVo.setAmt1(DelngEhgtConst.SEND_AMT1);      					/* 기본 100만달러 */     /*	요청 금액: 금액은 double 값이나  14.5 의 string 으로 covert 하여 사용	12345678901234.12345 RequestedSize	*/
		reqVo.setUserId("system");                      				/*	고객 딜러 ID: 환율 요청시 고객측에서 딜러 등 구분 코드를 사용	ZZZZZZ	NOT USE	*/
															 			/*	(현재 버전은  FIX 요청시 사용하지 않음)	*/
		String reqTm = DateUtil.calDate(DelngEhgtConst.HANAFX_DATE_FORMAT2);
		reqVo.setReqTm(reqTm);                    			 			/*	이전 요청 연월일: YYYYMMDDHHMMSS		20210501121210	Table 용 field	*/
		reqVo.setStatus(DelngEhgtConst.SEND_STATUS_W);                                /* 환율 상태: W= 최초 요청후 1번 data 수신 이전, U=수신, D=거부 */

		int registCount = dealingEhgt.selectRegistRfsReqCount(reqVo);
		if(registCount > 0) {
			return null;                                     			//기존에 등록 되어 있으면 신규 등록을 하지 않는다.
		}

		BigDecimal maxMdReqId = dealingEhgt.selectMaxMdReqId();
		if(maxMdReqId == null) {
			maxMdReqId = new BigDecimal("1");
		}

		String mdReqId = ApiCmmUtil.getMdReqId(maxMdReqId.toString());
		reqVo.setMdReqId(mdReqId);  									/*	환율 요청 ID: 환율 요청시 KEY 를 채번하여 환율 요청 시 사용		MDReqID	*/

		int result = dealingEhgt.insertGfxRfsReq(reqVo);
		if(result==1) {
			return reqVo;
		}

		return null;
	}

	@Override
	public GfxRfsReqVo executeFWDEhgtService(String maturityMonth) throws Exception {
		String maturityDay = "";
		if(maturityMonth.length() == 6) {
			String exprtnDe = dealingEhgt.selectOrFshgDdtmanBasApplcDe(maturityMonth);   //해당월의 만기일자
			if(StringUtil.isEmpty(exprtnDe)) {
				return null;
			}else {
				maturityDay = exprtnDe;
			}
		}else {
			maturityDay = maturityMonth;
		}

		/*
		 * Step1. MD_REQ_ID 값 생성 예) REQ001
		 */
		GfxRfsReqVo reqVo = new GfxRfsReqVo();
		reqVo.setMdReqTp(DelngEhgtConst.SEND_MD_REQ_TP_OPEN); /*	환율 요청 구분: O= open C= close							        				SubscriptionRequestType	*/
//		reqVo.setProdCd(DelngEhgtConst.SEND_PROD_CD_FWD);     /*	상품코드: 상품 코드 	SPT,FWD,FFF, FXS						        				SecurityDesc	*/
															 /*	(현물환, 선물환/자유만기 선물환, FX 스왑 )			*/
		reqVo.setPairId(DelngEhgtConst.SEND_PAIR_ID_USD_KRW);							 /*	거래 통화 코드: USD/KRW, EUR/KRW 등의 거래통화 코드				        				 USD/JPY	Symbol	*/
		reqVo.setCurrCd(DelngEhgtConst.SEND_CURR_CD_USD);                              /*	거래 통화:	거래 기준 통화  CUR1 또는 CUR2	USD    KRW  EUR ..	        				 Currency	*/
		reqVo.setValDt(maturityDay);                          /*	Near 결제일: 결제일 1	202100								        				 SettlDate	*/
		reqVo.setMatDt(DelngEhgtConst.SEND_MAT_DT);           /*	Far 결제일: 결제일 2  , prod_cd 가 FXS 가 아니면 항상 000000 으로 사용	0					 SettlDate2	*/
		reqVo.setAmt1(DelngEhgtConst.SEND_AMT1);              /*	요청 금액: 금액은 double 값이나  14.5 의 string 으로 covert 하여 사용	12345678901234.12345 RequestedSize	*/
		reqVo.setUserId("system");                             /*	고객 딜러 ID: 환율 요청시 고객측에서 딜러 등 구분 코드를 사용	ZZZZZZ	NOT USE	*/
															 /*	(현재 버전은  FIX 요청시 사용하지 않음)	*/
		String reqTm = DateUtil.calDate(DelngEhgtConst.HANAFX_DATE_FORMAT2);
		reqVo.setReqTm(reqTm);                    			 /*	이전 요청 연월일: YYYYMMDDHHMMSS		20210501121210	Table 용 field	*/
		reqVo.setStatus(DelngEhgtConst.SEND_STATUS_W);       /* 환율 상태: W= 최초 요청후 1번 data 수신 이전, U=수신, D=거부 */

		int registCount = dealingEhgt.selectRegistRfsReqCount(reqVo);
		if(registCount > 0) {
			return null;                                     //기존에 등록 되어 있으면 신규 등록을 하지 않는다.
		}

		BigDecimal maxMdReqId = dealingEhgt.selectMaxMdReqId();
		if(maxMdReqId == null) {
			maxMdReqId = new BigDecimal("1");
		}

		String mdReqId = ApiCmmUtil.getMdReqId(maxMdReqId.toString());
		reqVo.setMdReqId(mdReqId);  /*	환율 요청 ID: 환율 요청시 KEY 를 채번하여 환율 요청 시 사용 			        				MDReqID	*/

		int result = dealingEhgt.insertGfxRfsReq(reqVo);
		if(result==1) {
			return reqVo;
		}

		return null;
	}

	@Override
	public GtxApiFxTenorVo executeValidProdValDt(GtxApiFxTenorVo vo){
		try {
			return dealingEhgt.selectValidProdValDt(vo);
		}catch(Exception e) {
			log.error("DealingEhgtService executeValidProdValDt", e);
		}
		return null;
	}

	@Override
	public List<OrFshgDdtmanBasVo> executeValidApplcDeList(OrFshgDdtmanBasVo vo){
		try {
			return dealingEhgt.selectValidApplcDeList(vo);
		}catch(Exception e) {
			log.error("DealingEhgtService executeValidApplcDeList", e);
		}

		return new ArrayList<OrFshgDdtmanBasVo>();
	}
}
