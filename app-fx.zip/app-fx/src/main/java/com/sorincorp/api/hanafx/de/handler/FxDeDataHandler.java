package com.sorincorp.api.hanafx.de.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.digitide.xcube.XCPBMsg;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sorincorp.api.hanafx.de.model.GfxRfsResVo;
import com.sorincorp.api.hanafx.de.service.DealingEhgtService;
import com.sorincorp.api.hanafx.socket.MessageCast;
import com.sorincorp.comm.util.StringUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class FxDeDataHandler extends Thread {

	@Autowired
	private DealingEhgtService dealRecvService;

	private boolean isRun;
	private List<Object> list;
	private String[] gfxRfsResKeys = {
			"mdReqId", "qtStatus", "qtIdx", "prodCd", "pairId", "currCd", "valDt", "matDt", "amt1", "userId",
			"validTime", "spotBid", "spotAsk", "nearBid", "nearAsk", "farBid", "farAsk"
		};

	@PostConstruct
	public void init(){
		list = new ArrayList<Object>();
		isRun = true;
		log.info("Hana FxDeDataHandler Init OK");
	}

	public void add(Object obj) throws Exception{
		synchronized(list) {
			int size = list.size();
			if (size>3000){
				log.info("==> FxPrDataHandler Buffer is OverFlow And Clear!!");
				throw new Exception("FxPrDataHandler Buffer is OverFlow");
			}else{
				list.add(obj);
				list.notify();
			}
		}
	}

	public void setRun(boolean run){
		this.isRun = run;
	}

	public void executeDelngEhgtData(XCPBMsg pbMsg){
		try {
			/* pbMsg Parsing */
			if(log.isDebugEnabled()) {
				String dumpMsg = MessageCast.msgDump("거래용 환율 수신 DUMP PBMSG", pbMsg);
				log.debug(dumpMsg);
			}

			/* API_INT_DAT_RES 테이블 데이타 */
			String value = null;
			Map<String, Object> map = new HashMap<>();
			int idx = 0;
			for(String key : gfxRfsResKeys) {
				value = StringUtil.trim(pbMsg.get_value(idx++));
				map.put(key, value);
			}

			ObjectMapper mapper = new ObjectMapper();
			GfxRfsResVo resVo = mapper.convertValue(map, GfxRfsResVo.class);

			dealRecvService.executeRecvEhgtService(resVo);
		} catch (Exception e) {
			log.error(getClass().getName(), e);
		}
	}

	public final void run() {
		Object object = null;
		log.info("Hana FxDeDataHandler Start OK");
		while( isRun ) {
			try {
				synchronized(list) {
					if( list.size() == 0 ) {
						try {
							list.wait();
						} catch(Exception e) {}
					} else {
						object = (Object) list.remove(0);
					}
				}

				if( object != null ){
					executeDelngEhgtData((XCPBMsg)object);
				}

				object = null;
			}catch(Exception e) {
				log.error("FxDeDataHandler error:", e);
			}
		}

		this.isRun = false;
		log.info("!!! FxDeDataHandler is Terminated!!!");
	}

	@PreDestroy
	public void stopThread(){
		try {
			setRun(false);
			interrupt();

			Thread.sleep(50L);
		} catch (InterruptedException e) {
		}
	}
}
