package com.sorincorp.api.hanafx.mo.service;

public interface FxStateMonitorService {

	/**
	 * <pre>
	 * 처리내용: Fx client 서비스 상태를 모니터링한다.
	 * </pre>
	 * @date 2021. 11. 5.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 5.			srec0032			최초작성
	 * ------------------------------------------------
	 * @throws Exception
	 */
	void checkFxServerStatus();

	/**
	 * <pre>
	 * 처리내용: Fx client 작업 내용 상태를 모니터링한다
	 * </pre>
	 * @date 2021. 11. 22.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 11. 22.			srec0032			최초작성
	 * ------------------------------------------------
	 */
	void checkFxWorkStatus(boolean result);
}