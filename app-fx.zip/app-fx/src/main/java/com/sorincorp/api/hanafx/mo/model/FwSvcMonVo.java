package com.sorincorp.api.hanafx.mo.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class FwSvcMonVo {
   /**
    *
   */
   private String svcId;
    /**
    *
   */
   private String svcStatus;
    /**
    *
   */
   private String startDt;
    /**
    *
   */
   private String startTm;
    /**
    *
   */
   private String stopDt;
    /**
    *
   */
   private String stopTm;
}
