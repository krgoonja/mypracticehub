package com.sorincorp.api.hanafx.fs.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=false)
public class ApiIntSeqVo {
   /**
    * 서비스 명
   */
   private String intId;

    /**
    * 최종 요청 순번
    */
   private int reqSeq;

    /**
    * 최종 처리 순번
    */
   private int prcSeq;
}
