package com.sorincorp.api.hanafx.de.service;

import java.util.List;

import com.sorincorp.api.hanafx.de.model.GfxRfsReqVo;
import com.sorincorp.api.hanafx.de.model.GfxRfsResVo;
import com.sorincorp.api.hanafx.de.model.GtxApiFxTenorVo;
import com.sorincorp.api.hanafx.de.model.OrFshgDdtmanBasVo;

public interface DealingEhgtService {
	void executeRecvEhgtService(GfxRfsResVo vo) throws Exception;

	GfxRfsReqVo executeSPTEhgtService() throws Exception;

	GfxRfsReqVo executeFWDEhgtService(String maturityDay) throws Exception;

	int deleteGfxRfsReqWithSchedule() throws Exception;

	/**
	 * <pre>
	 * 처리내용: 디지타이드에서 보내주는 유효한 상품 거래일을 조회한다.
	 * </pre>
	 * @date 2021. 12. 15.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 15.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 */
	GtxApiFxTenorVo executeValidProdValDt(GtxApiFxTenorVo vo);

	/**
	 * <pre>
	 * 처리내용: 현물환 날짜(SPT) 기준으로 유효한 6개월치 선물환(FWD)날짜를 조회한다.
	 * </pre>
	 * @date 2021. 12. 15.
	 * @author srec0032
	 * @history
	 * ------------------------------------------------
	 * 변경일					작성자				변경내용
	 * ------------------------------------------------
	 * 2021. 12. 15.			srec0032			최초작성
	 * ------------------------------------------------
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	List<OrFshgDdtmanBasVo> executeValidApplcDeList(OrFshgDdtmanBasVo vo);
}
