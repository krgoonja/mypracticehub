/* 가격_판매 가격 USD 년 기본 */
CREATE TABLE [dbo].[PR_SEL_PC_USD_YY_BAS] (
	[METAL_CODE] [NVARCHAR](2) NOT NULL,  /* 금속 코드 */
	[ITM_SN] [INT] NOT NULL,  /* 아이템 순번 */
	[DSTRCT_LCLSF_CODE] [NVARCHAR](2) NOT NULL,  /* 권역 대분류 코드 */
	[BRAND_GROUP_CODE] [NVARCHAR](2) NOT NULL,  /* 브랜드 그룹 코드 */
	[BRAND_CODE] [NVARCHAR](10) NOT NULL,  /* 브랜드 코드 */
	[OCCRRNC_YY] [NVARCHAR](4) NOT NULL,  /* 발생 년 */
	[SLE_PC_YY_SN] [NVARCHAR](20) NOT NULL,  /* 판매 가격 년 순번 */
	[BEGIN_PC] [DECIMAL](15,6) NOT NULL,  /* 시작 가격 */
	[END_PC] [DECIMAL](15,6) NOT NULL,  /* 종료 가격 */
	[TOP_PC] [DECIMAL](15,6) NOT NULL,  /* 최고 가격 */
	[LWET_PC] [DECIMAL](15,6) NOT NULL,  /* 최저 가격 */
	[VERSUS_PC] [DECIMAL](15,6) NOT NULL,  /* 대비 가격 */
	[VERSUS_RATE] [DECIMAL](15,6) NOT NULL,  /* 대비 비율 */
	[DELNG_QY] [BIGINT],  /* 거래 수량 */
	[DELETE_DT] [DATETIME],  /* 삭제 일시 */
	[DELETE_AT] [NVARCHAR](1) NOT NULL,  /* 삭제 여부 */
	[FRST_REGISTER_ID] [NVARCHAR](30) NOT NULL,  /* 최초 등록자 아이디 */
	[FRST_REGIST_DT] [DATETIME] NOT NULL,  /* 최초 등록 일시 */
	[LAST_CHANGER_ID] [NVARCHAR](30) NOT NULL,  /* 최종 변경자 아이디 */
	[LAST_CHANGE_DT] [DATETIME] NOT NULL /* 최종 변경 일시 */
)
GO

/* 가격_판매 가격 USD 년 기본 기본키 */
ALTER TABLE [dbo].[PR_SEL_PC_USD_YY_BAS]
	ADD
		CONSTRAINT [PK_PR_SEL_PC_USD_YY_BAS]
		PRIMARY KEY NONCLUSTERED (
			[METAL_CODE] ASC, 
			[ITM_SN] ASC, 
			[DSTRCT_LCLSF_CODE] ASC, 
			[BRAND_GROUP_CODE] ASC, 
			[BRAND_CODE] ASC, 
			[OCCRRNC_YY] ASC
		)
GO

/* 가격_판매 가격 USD 년 기본 유니크 제약 */
ALTER TABLE [dbo].[PR_SEL_PC_USD_YY_BAS]
	ADD
		CONSTRAINT [UK_PR_SEL_PC_USD_YY_BAS]
		UNIQUE NONCLUSTERED (
			[METAL_CODE] ASC, 
			[SLE_PC_YY_SN] ASC
		)
GO

/* 가격_판매 가격 USD 년 기본 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'가격_판매 가격 USD 년 기본', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS'
GO

/* 금속 코드 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'금속 코드', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'METAL_CODE'
GO

/* 아이템 순번 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'아이템 순번', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'ITM_SN'
GO

/* 권역 대분류 코드 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'권역 대분류 코드', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'DSTRCT_LCLSF_CODE'
GO

/* 브랜드 그룹 코드 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'브랜드 그룹 코드', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'BRAND_GROUP_CODE'
GO

/* 브랜드 코드 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'브랜드 코드', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'BRAND_CODE'
GO

/* 발생 년 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'발생 년', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'OCCRRNC_YY'
GO

/* 판매 가격 년 순번 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'판매 가격 년 순번', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'SLE_PC_YY_SN'
GO

/* 시작 가격 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'시작 가격', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'BEGIN_PC'
GO

/* 종료 가격 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'종료 가격', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'END_PC'
GO

/* 최고 가격 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최고 가격', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'TOP_PC'
GO

/* 최저 가격 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최저 가격', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'LWET_PC'
GO

/* 대비 가격 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'대비 가격', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'VERSUS_PC'
GO

/* 대비 비율 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'대비 비율', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'VERSUS_RATE'
GO

/* 거래 수량 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'거래 수량', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'DELNG_QY'
GO

/* 삭제 일시 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'삭제 일시', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'DELETE_DT'
GO

/* 삭제 여부 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'삭제 여부', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'DELETE_AT'
GO

/* 최초 등록자 아이디 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최초 등록자 아이디', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'FRST_REGISTER_ID'
GO

/* 최초 등록 일시 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최초 등록 일시', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'FRST_REGIST_DT'
GO

/* 최종 변경자 아이디 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최종 변경자 아이디', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'LAST_CHANGER_ID'
GO

/* 최종 변경 일시 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최종 변경 일시', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'COLUMN', @level2name=N'LAST_CHANGE_DT'
GO

/* 가격_판매 가격 USD 년 기본 기본키 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'가격_판매 가격 USD 년 기본 기본키', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'CONSTRAINT', @level2name=N'PK_PR_SEL_PC_USD_YY_BAS'
GO

/* 가격_판매 가격 USD 년 기본 유니크 제약 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'가격_판매 가격 USD 년 기본 유니크 제약', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'CONSTRAINT', @level2name=N'UK_PR_SEL_PC_USD_YY_BAS'
GO

/* 가격_판매 가격 USD 년 기본 기본키 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'가격_판매 가격 USD 년 기본 기본키', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'INDEX', @level2name=N'PK_PR_SEL_PC_USD_YY_BAS'
GO

/* 가격_판매 가격 USD 년 기본 유니크 인덱스 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'가격_판매 가격 USD 년 기본 유니크 인덱스', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'PR_SEL_PC_USD_YY_BAS', 
	@level2type=N'INDEX', @level2name=N'UK_PR_SEL_PC_USD_YY_BAS'
GO