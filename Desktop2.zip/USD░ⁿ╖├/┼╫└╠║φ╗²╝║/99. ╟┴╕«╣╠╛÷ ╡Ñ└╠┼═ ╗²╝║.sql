

SELECT * FROM IT_PREMIUM_STDR_BAS WHERE PREMIUM_ID = 'PI07002459' ORDER BY FRST_REGIST_DT DESC

-- 프리미엄 아이디 일련번호 생성
DECLARE @ASSGN_VAL VARCHAR(20)
EXEC sp_get_assgn_val 'IT', 'PREMIUM', '999999', 'premiumNo', @ASSGN_VAL OUTPUT
SELECT @ASSGN_VAL AS ASSGN_VAL

-- PI + 07 + 일련번호 (002460) = PI07002460

SELECT * FROM IT_PREMIUM_BRAND_BAS WHERE PREMIUM_ID = 'PI07002459' ORDER BY FRST_REGIST_DT DESC
-- 57개

-- 프리미엄 번호 일련번호 생성
DECLARE @ASSGN_VAL VARCHAR(20)
EXEC sp_get_assgn_val 'IT', 'PREMIUMNO', '999999', 'premiumNo', @ASSGN_VAL OUTPUT
SELECT @ASSGN_VAL AS ASSGN_VAL

-- PN + 07 + 20240306 + 일련번호
PN0720240306108630
PN0720240306108631
PN0720240306108632
PN0720240306108633
PN0720240306108634
PN0720240306108635
PN0720240306108636
PN0720240306108637
PN0720240306108638
PN0720240306108639

PN0720240306108640
PN0720240306108641
PN0720240306108642
PN0720240306108643
PN0720240306108644
PN0720240306108645
PN0720240306108646
PN0720240306108647
PN0720240306108648
PN0720240306108649

PN0720240306108650
PN0720240306108651
PN0720240306108652
PN0720240306108653
PN0720240306108654
PN0720240306108655
PN0720240306108656
PN0720240306108657
PN0720240306108658
PN0720240306108659

PN0720240306108660
PN0720240306108661
PN0720240306108662
PN0720240306108663
PN0720240306108664
PN0720240306108665
PN0720240306108666
PN0720240306108667
PN0720240306108668
PN0720240306108669

PN0720240306108670
PN0720240306108671
PN0720240306108672
PN0720240306108673
PN0720240306108674
PN0720240306108675
PN0720240306108676
PN0720240306108677
PN0720240306108678
PN0720240306108679

PN0720240306108680
PN0720240306108681
PN0720240306108682
PN0720240306108683
PN0720240306108684
PN0720240306108685
PN0720240306108686

-- 상품_프리미엄 USD 기준 기본 데이터 생성
INSERT INTO dbo.IT_PREMIUM_USD_STDR_BAS                                                              /* 상품_프리미엄 USD 기준 기본   */
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , METAL_CODE                                                                                    /* 금속 코드                     */
     , ITM_SN                                                                                        /* 아이템 순번                   */
     , VALID_BEGIN_DT                                                                                /* 유효 시작 일시                */
     , VALID_END_DT                                                                                  /* 유효 종료 일시                */
     , SLE_MTHD_CODE                                                                                 /* 판매 방식 코드                */
     , PREMIUM_USD_STDR_AMOUNT                                                                       /* 프리미엄 USD 기준 금액        */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
VALUES
     (
       'PI07002460'                                                                                  /* 프리미엄 아이디               */
     , '7'                                                                                           /* 금속 코드                     */
     , 434                                                                                           /* 아이템 순번                   */
     , '20240306130000'                                                                              /* 유효 시작 일시                */
     , '99991231235958'                                                                              /* 유효 종료 일시                */
     , '01'                                                                                          /* 판매 방식 코드                */
     , 127.00                                                                                        /* 프리미엄 USD 기준 금액        */
     , NULL                                                                                          /* 삭제 일시                     */
     , 'N'                                                                                           /* 삭제 여부                     */
     , 'test01'                                                                                      /* 최초 등록자 아이디            */
     , GETDATE()                                                                                     /* 최초 등록 일시                */
     , 'test01'                                                                                      /* 최종 변경자 아이디            */
     , GETDATE()                                                                                     /* 최종 변경 일시                */
     )
;

-- 상품_프리미엄 USD 기준 기본 이력 데이터 생성
INSERT INTO dbo.IT_PREMIUM_USD_STDR_BAS_HST                                                              /* 상품_프리미엄 USD 기준 기본 이력  */
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , METAL_CODE                                                                                    /* 금속 코드                     */
     , ITM_SN                                                                                        /* 아이템 순번                   */
     , VALID_BEGIN_DT                                                                                /* 유효 시작 일시                */
     , VALID_END_DT                                                                                  /* 유효 종료 일시                */
     , SLE_MTHD_CODE                                                                                 /* 판매 방식 코드                */
     , PREMIUM_USD_STDR_AMOUNT                                                                       /* 프리미엄 USD 기준 금액        */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
SELECT
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , METAL_CODE                                                                                    /* 금속 코드                     */
     , ITM_SN                                                                                        /* 아이템 순번                   */
     , VALID_BEGIN_DT                                                                                /* 유효 시작 일시                */
     , VALID_END_DT                                                                                  /* 유효 종료 일시                */
     , SLE_MTHD_CODE                                                                                 /* 판매 방식 코드                */
     , PREMIUM_USD_STDR_AMOUNT                                                                       /* 프리미엄 USD 기준 금액        */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시               */ 
FROM dbo.IT_PREMIUM_USD_STDR_BAS                                                                     /* 상품_프리미엄 USD 기준 기본   */
WHERE PREMIUM_ID = 'PI07002460'                                                                      /* 프리미엄 아이디               */
;

-----------------------

SELECT * FROM IT_PREMIUM_DSTRCT_BAS WHERE PREMIUM_ID = 'PI07002459' ORDER BY FRST_REGIST_DT DESC

-- 상품_프리미엄 USD 권역 기본 데이터 생성 10
INSERT INTO dbo.IT_PREMIUM_USD_DSTRCT_BAS                                                            /* 상품_프리미엄 USD 권역 기본   */
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , DSTRCT_USD_CHANGE_AMOUNT                                                                      /* 권역 USD 변동 금액            */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
VALUES
     (
       'PI07002460'                                                                                  /* 프리미엄 아이디               */
     , '10'                                                                                          /* 권역 대분류 코드              */
     , 5.00                                                                                             /* 권역 USD 변동 금액            */
     , NULL                                                                                          /* 삭제 일시                     */
     , 'N'                                                                                           /* 삭제 여부                     */
     , 'test01'                                                                                      /* 최초 등록자 아이디            */
     , GETDATE()                                                                                     /* 최초 등록 일시                */
     , 'test01'                                                                                      /* 최종 변경자 아이디            */
     , GETDATE()                                                                                     /* 최종 변경 일시                */
     )
;

-- 상품_프리미엄 USD 권역 기본 이력 데이터 생성 10
INSERT INTO dbo.IT_PREMIUM_USD_DSTRCT_BAS_HST                                                        /* 상품_프리미엄 USD 권역 기본 이력*/
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , DSTRCT_USD_CHANGE_AMOUNT                                                                      /* 권역 USD 변동 금액            */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
SELECT
       IPUDB.PREMIUM_ID                                                                              /* 프리미엄 아이디               */
     , IPUDB.DSTRCT_LCLSF_CODE                                                                       /* 권역 대분류 코드              */
     , IPUDB.DSTRCT_USD_CHANGE_AMOUNT                                                                /* 권역 USD 변동 금액            */
     , IPUDB.DELETE_DT                                                                               /* 삭제 일시                     */
     , IPUDB.DELETE_AT                                                                               /* 삭제 여부                     */
     , IPUDB.FRST_REGISTER_ID                                                                        /* 최초 등록자 아이디            */
     , IPUDB.FRST_REGIST_DT                                                                          /* 최초 등록 일시                */
     , IPUDB.LAST_CHANGER_ID                                                                         /* 최종 변경자 아이디            */
     , IPUDB.LAST_CHANGE_DT                                                                          /* 최종 변경 일시                */
FROM dbo.IT_PREMIUM_USD_DSTRCT_BAS AS IPUDB                                                          /* 상품_프리미엄 USD 권역 기본   */
WHERE PREMIUM_ID = 'PI07002460'                                                                      /* 프리미엄 아이디               */
AND DSTRCT_LCLSF_CODE = '10'                                                                         /* 권역 대분류 코드              */
;

-- 상품_프리미엄 USD 권역 기본 데이터 생성 20
INSERT INTO dbo.IT_PREMIUM_USD_DSTRCT_BAS                                                            /* 상품_프리미엄 USD 권역 기본   */
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , DSTRCT_USD_CHANGE_AMOUNT                                                                      /* 권역 USD 변동 금액            */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
VALUES
     (
       'PI07002460'                                                                                  /* 프리미엄 아이디               */
     , '20'                                                                                          /* 권역 대분류 코드              */
     , 0                                                                                             /* 권역 USD 변동 금액            */
     , NULL                                                                                          /* 삭제 일시                     */
     , 'N'                                                                                           /* 삭제 여부                     */
     , 'test01'                                                                                      /* 최초 등록자 아이디            */
     , GETDATE()                                                                                     /* 최초 등록 일시                */
     , 'test01'                                                                                      /* 최종 변경자 아이디            */
     , GETDATE()                                                                                     /* 최종 변경 일시                */
     )
;

-- 상품_프리미엄 USD 권역 기본 이력 데이터 생성 20
INSERT INTO dbo.IT_PREMIUM_USD_DSTRCT_BAS_HST                                                        /* 상품_프리미엄 USD 권역 기본 이력*/
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , DSTRCT_USD_CHANGE_AMOUNT                                                                      /* 권역 USD 변동 금액            */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
SELECT
       IPUDB.PREMIUM_ID                                                                              /* 프리미엄 아이디               */
     , IPUDB.DSTRCT_LCLSF_CODE                                                                       /* 권역 대분류 코드              */
     , IPUDB.DSTRCT_USD_CHANGE_AMOUNT                                                                /* 권역 USD 변동 금액            */
     , IPUDB.DELETE_DT                                                                               /* 삭제 일시                     */
     , IPUDB.DELETE_AT                                                                               /* 삭제 여부                     */
     , IPUDB.FRST_REGISTER_ID                                                                        /* 최초 등록자 아이디            */
     , IPUDB.FRST_REGIST_DT                                                                          /* 최초 등록 일시                */
     , IPUDB.LAST_CHANGER_ID                                                                         /* 최종 변경자 아이디            */
     , IPUDB.LAST_CHANGE_DT                                                                          /* 최종 변경 일시                */
FROM dbo.IT_PREMIUM_USD_DSTRCT_BAS AS IPUDB                                                          /* 상품_프리미엄 USD 권역 기본   */
WHERE PREMIUM_ID = 'PI07002460'                                                                      /* 프리미엄 아이디               */
AND DSTRCT_LCLSF_CODE = '20'                                                                         /* 권역 대분류 코드              */
;

-- 상품_프리미엄 USD 권역 기본 데이터 생성 50
INSERT INTO dbo.IT_PREMIUM_USD_DSTRCT_BAS                                                            /* 상품_프리미엄 USD 권역 기본   */
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , DSTRCT_USD_CHANGE_AMOUNT                                                                      /* 권역 USD 변동 금액            */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
VALUES
     (
       'PI07002460'                                                                                  /* 프리미엄 아이디               */
     , '50'                                                                                          /* 권역 대분류 코드              */
     , 0                                                                                             /* 권역 USD 변동 금액            */
     , NULL                                                                                          /* 삭제 일시                     */
     , 'N'                                                                                           /* 삭제 여부                     */
     , 'test01'                                                                                      /* 최초 등록자 아이디            */
     , GETDATE()                                                                                     /* 최초 등록 일시                */
     , 'test01'                                                                                      /* 최종 변경자 아이디            */
     , GETDATE()                                                                                     /* 최종 변경 일시                */
     )
;

-- 상품_프리미엄 USD 권역 기본 이력 데이터 생성 50
INSERT INTO dbo.IT_PREMIUM_USD_DSTRCT_BAS_HST                                                        /* 상품_프리미엄 USD 권역 기본 이력*/
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , DSTRCT_USD_CHANGE_AMOUNT                                                                      /* 권역 USD 변동 금액            */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
SELECT
       IPUDB.PREMIUM_ID                                                                              /* 프리미엄 아이디               */
     , IPUDB.DSTRCT_LCLSF_CODE                                                                       /* 권역 대분류 코드              */
     , IPUDB.DSTRCT_USD_CHANGE_AMOUNT                                                                /* 권역 USD 변동 금액            */
     , IPUDB.DELETE_DT                                                                               /* 삭제 일시                     */
     , IPUDB.DELETE_AT                                                                               /* 삭제 여부                     */
     , IPUDB.FRST_REGISTER_ID                                                                        /* 최초 등록자 아이디            */
     , IPUDB.FRST_REGIST_DT                                                                          /* 최초 등록 일시                */
     , IPUDB.LAST_CHANGER_ID                                                                         /* 최종 변경자 아이디            */
     , IPUDB.LAST_CHANGE_DT                                                                          /* 최종 변경 일시                */
FROM dbo.IT_PREMIUM_USD_DSTRCT_BAS AS IPUDB                                                          /* 상품_프리미엄 USD 권역 기본   */
WHERE PREMIUM_ID = 'PI07002460'                                                                      /* 프리미엄 아이디               */
AND DSTRCT_LCLSF_CODE = '50'                                                                         /* 권역 대분류 코드              */
;

-----------------------

SELECT * FROM IT_PREMIUM_BRAND_GROUP_BAS WHERE PREMIUM_ID = 'PI07002459' ORDER BY FRST_REGIST_DT DESC

-- 상품_프리미엄 USD 브랜드 그룹 기본 데이터 생성 10 01
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS                                                       /* 상품_프리미엄 USD 브랜드 그룹 기본*/
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , BRAND_GROUP_CODE                                                                              /* 브랜드 그룹 코드              */
     , BRAND_GROUP_USD_CHANGE_AMOUNT                                                                 /* 브랜드 그룹 USD 변동 금액     */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
VALUES
     (
       'PI07002460'                                                                                  /* 프리미엄 아이디               */
     , '10'                                                                            /* 권역 대분류 코드              */
     , '01'                                                                             /* 브랜드 그룹 코드              */
     , 0.00                                                                  /* 브랜드 그룹 USD 변동 금액     */
     , NULL                                                                                   /* 삭제 일시                     */
     , 'N'                                                                                   /* 삭제 여부                     */
     , 'test01'                                                                             /* 최초 등록자 아이디            */
     , GETDATE()                                                                               /* 최초 등록 일시                */
     , 'test01'                                                                              /* 최종 변경자 아이디            */
     , GETDATE()                                                                               /* 최종 변경 일시                */
     )
;

-- 상품_프리미엄 USD 브랜드 그룹 기본 이력 데이터 생성 10 01
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS_HST                                                   /* 상품_프리미엄 USD 브랜드 그룹 기본 이력*/
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , BRAND_GROUP_CODE                                                                              /* 브랜드 그룹 코드              */
     , BRAND_GROUP_USD_CHANGE_AMOUNT                                                                 /* 브랜드 그룹 USD 변동 금액     */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
SELECT
       IPUBGB.PREMIUM_ID                                                                             /* 프리미엄 아이디               */
     , IPUBGB.DSTRCT_LCLSF_CODE                                                                      /* 권역 대분류 코드              */
     , IPUBGB.BRAND_GROUP_CODE                                                                       /* 브랜드 그룹 코드              */
     , IPUBGB.BRAND_GROUP_USD_CHANGE_AMOUNT                                                          /* 브랜드 그룹 USD 변동 금액     */
     , IPUBGB.DELETE_DT                                                                              /* 삭제 일시                     */
     , IPUBGB.DELETE_AT                                                                              /* 삭제 여부                     */
     , IPUBGB.FRST_REGISTER_ID                                                                       /* 최초 등록자 아이디            */
     , IPUBGB.FRST_REGIST_DT                                                                         /* 최초 등록 일시                */
     , IPUBGB.LAST_CHANGER_ID                                                                        /* 최종 변경자 아이디            */
     , IPUBGB.LAST_CHANGE_DT                                                                         /* 최종 변경 일시                */
FROM dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS AS IPUBGB                                                    /* 상품_프리미엄 USD 브랜드 그룹 기본*/
WHERE PREMIUM_ID = 'PI07002460'                                                                      /* 프리미엄 아이디               */
AND DSTRCT_LCLSF_CODE = '10'                                                                         /* 권역 대분류 코드              */
AND BRAND_GROUP_CODE = '01'                                                                          /* 브랜드 그룹 코드              */
;

-- 상품_프리미엄 USD 브랜드 그룹 기본 데이터 생성 10 02
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS                                                       /* 상품_프리미엄 USD 브랜드 그룹 기본*/
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , BRAND_GROUP_CODE                                                                              /* 브랜드 그룹 코드              */
     , BRAND_GROUP_USD_CHANGE_AMOUNT                                                                 /* 브랜드 그룹 USD 변동 금액     */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
VALUES
     (
       'PI07002460'                                                                                  /* 프리미엄 아이디               */
     , '10'                                                                            /* 권역 대분류 코드              */
     , '02'                                                                             /* 브랜드 그룹 코드              */
     , 0.00                                                                  /* 브랜드 그룹 USD 변동 금액     */
     , NULL                                                                                   /* 삭제 일시                     */
     , 'N'                                                                                   /* 삭제 여부                     */
     , 'test01'                                                                             /* 최초 등록자 아이디            */
     , GETDATE()                                                                               /* 최초 등록 일시                */
     , 'test01'                                                                              /* 최종 변경자 아이디            */
     , GETDATE()                                                                               /* 최종 변경 일시                */
     )
;

-- 상품_프리미엄 USD 브랜드 그룹 기본 이력 데이터 생성 10 02
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS_HST                                                   /* 상품_프리미엄 USD 브랜드 그룹 기본 이력*/
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , BRAND_GROUP_CODE                                                                              /* 브랜드 그룹 코드              */
     , BRAND_GROUP_USD_CHANGE_AMOUNT                                                                 /* 브랜드 그룹 USD 변동 금액     */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
SELECT
       IPUBGB.PREMIUM_ID                                                                             /* 프리미엄 아이디               */
     , IPUBGB.DSTRCT_LCLSF_CODE                                                                      /* 권역 대분류 코드              */
     , IPUBGB.BRAND_GROUP_CODE                                                                       /* 브랜드 그룹 코드              */
     , IPUBGB.BRAND_GROUP_USD_CHANGE_AMOUNT                                                          /* 브랜드 그룹 USD 변동 금액     */
     , IPUBGB.DELETE_DT                                                                              /* 삭제 일시                     */
     , IPUBGB.DELETE_AT                                                                              /* 삭제 여부                     */
     , IPUBGB.FRST_REGISTER_ID                                                                       /* 최초 등록자 아이디            */
     , IPUBGB.FRST_REGIST_DT                                                                         /* 최초 등록 일시                */
     , IPUBGB.LAST_CHANGER_ID                                                                        /* 최종 변경자 아이디            */
     , IPUBGB.LAST_CHANGE_DT                                                                         /* 최종 변경 일시                */
FROM dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS AS IPUBGB                                                    /* 상품_프리미엄 USD 브랜드 그룹 기본*/
WHERE PREMIUM_ID = 'PI07002460'                                                                      /* 프리미엄 아이디               */
AND DSTRCT_LCLSF_CODE = '10'                                                                         /* 권역 대분류 코드              */
AND BRAND_GROUP_CODE = '02'                                                                          /* 브랜드 그룹 코드              */
;

-- 상품_프리미엄 USD 브랜드 그룹 기본 데이터 생성 20 01
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS                                                       /* 상품_프리미엄 USD 브랜드 그룹 기본*/
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , BRAND_GROUP_CODE                                                                              /* 브랜드 그룹 코드              */
     , BRAND_GROUP_USD_CHANGE_AMOUNT                                                                 /* 브랜드 그룹 USD 변동 금액     */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
VALUES
     (
       'PI07002460'                                                                                  /* 프리미엄 아이디               */
     , '20'                                                                            /* 권역 대분류 코드              */
     , '01'                                                                             /* 브랜드 그룹 코드              */
     , 0.00                                                                  /* 브랜드 그룹 USD 변동 금액     */
     , NULL                                                                                   /* 삭제 일시                     */
     , 'N'                                                                                   /* 삭제 여부                     */
     , 'test01'                                                                             /* 최초 등록자 아이디            */
     , GETDATE()                                                                               /* 최초 등록 일시                */
     , 'test01'                                                                              /* 최종 변경자 아이디            */
     , GETDATE()                                                                               /* 최종 변경 일시                */
     )
;

-- 상품_프리미엄 USD 브랜드 그룹 기본 이력 데이터 생성 20 01
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS_HST                                                   /* 상품_프리미엄 USD 브랜드 그룹 기본 이력*/
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , BRAND_GROUP_CODE                                                                              /* 브랜드 그룹 코드              */
     , BRAND_GROUP_USD_CHANGE_AMOUNT                                                                 /* 브랜드 그룹 USD 변동 금액     */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
SELECT
       IPUBGB.PREMIUM_ID                                                                             /* 프리미엄 아이디               */
     , IPUBGB.DSTRCT_LCLSF_CODE                                                                      /* 권역 대분류 코드              */
     , IPUBGB.BRAND_GROUP_CODE                                                                       /* 브랜드 그룹 코드              */
     , IPUBGB.BRAND_GROUP_USD_CHANGE_AMOUNT                                                          /* 브랜드 그룹 USD 변동 금액     */
     , IPUBGB.DELETE_DT                                                                              /* 삭제 일시                     */
     , IPUBGB.DELETE_AT                                                                              /* 삭제 여부                     */
     , IPUBGB.FRST_REGISTER_ID                                                                       /* 최초 등록자 아이디            */
     , IPUBGB.FRST_REGIST_DT                                                                         /* 최초 등록 일시                */
     , IPUBGB.LAST_CHANGER_ID                                                                        /* 최종 변경자 아이디            */
     , IPUBGB.LAST_CHANGE_DT                                                                         /* 최종 변경 일시                */
FROM dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS AS IPUBGB                                                    /* 상품_프리미엄 USD 브랜드 그룹 기본*/
WHERE PREMIUM_ID = 'PI07002460'                                                                      /* 프리미엄 아이디               */
AND DSTRCT_LCLSF_CODE = '20'                                                                         /* 권역 대분류 코드              */
AND BRAND_GROUP_CODE = '01'                                                                          /* 브랜드 그룹 코드              */
;

-- 상품_프리미엄 USD 브랜드 그룹 기본 데이터 생성 20 02
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS                                                       /* 상품_프리미엄 USD 브랜드 그룹 기본*/
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , BRAND_GROUP_CODE                                                                              /* 브랜드 그룹 코드              */
     , BRAND_GROUP_USD_CHANGE_AMOUNT                                                                 /* 브랜드 그룹 USD 변동 금액     */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
VALUES
     (
       'PI07002460'                                                                                  /* 프리미엄 아이디               */
     , '20'                                                                            /* 권역 대분류 코드              */
     , '02'                                                                             /* 브랜드 그룹 코드              */
     , 0.00                                                                  /* 브랜드 그룹 USD 변동 금액     */
     , NULL                                                                                   /* 삭제 일시                     */
     , 'N'                                                                                   /* 삭제 여부                     */
     , 'test01'                                                                             /* 최초 등록자 아이디            */
     , GETDATE()                                                                               /* 최초 등록 일시                */
     , 'test01'                                                                              /* 최종 변경자 아이디            */
     , GETDATE()                                                                               /* 최종 변경 일시                */
     )
;

-- 상품_프리미엄 USD 브랜드 그룹 기본 이력 데이터 생성 20 02
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS_HST                                                   /* 상품_프리미엄 USD 브랜드 그룹 기본 이력*/
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , BRAND_GROUP_CODE                                                                              /* 브랜드 그룹 코드              */
     , BRAND_GROUP_USD_CHANGE_AMOUNT                                                                 /* 브랜드 그룹 USD 변동 금액     */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
SELECT
       IPUBGB.PREMIUM_ID                                                                             /* 프리미엄 아이디               */
     , IPUBGB.DSTRCT_LCLSF_CODE                                                                      /* 권역 대분류 코드              */
     , IPUBGB.BRAND_GROUP_CODE                                                                       /* 브랜드 그룹 코드              */
     , IPUBGB.BRAND_GROUP_USD_CHANGE_AMOUNT                                                          /* 브랜드 그룹 USD 변동 금액     */
     , IPUBGB.DELETE_DT                                                                              /* 삭제 일시                     */
     , IPUBGB.DELETE_AT                                                                              /* 삭제 여부                     */
     , IPUBGB.FRST_REGISTER_ID                                                                       /* 최초 등록자 아이디            */
     , IPUBGB.FRST_REGIST_DT                                                                         /* 최초 등록 일시                */
     , IPUBGB.LAST_CHANGER_ID                                                                        /* 최종 변경자 아이디            */
     , IPUBGB.LAST_CHANGE_DT                                                                         /* 최종 변경 일시                */
FROM dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS AS IPUBGB                                                    /* 상품_프리미엄 USD 브랜드 그룹 기본*/
WHERE PREMIUM_ID = 'PI07002460'                                                                      /* 프리미엄 아이디               */
AND DSTRCT_LCLSF_CODE = '20'                                                                         /* 권역 대분류 코드              */
AND BRAND_GROUP_CODE = '02'                                                                          /* 브랜드 그룹 코드              */
;

-- 상품_프리미엄 USD 브랜드 그룹 기본 데이터 생성 50 01
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS                                                       /* 상품_프리미엄 USD 브랜드 그룹 기본*/
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , BRAND_GROUP_CODE                                                                              /* 브랜드 그룹 코드              */
     , BRAND_GROUP_USD_CHANGE_AMOUNT                                                                 /* 브랜드 그룹 USD 변동 금액     */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
VALUES
     (
       'PI07002460'                                                                                  /* 프리미엄 아이디               */
     , '50'                                                                            /* 권역 대분류 코드              */
     , '01'                                                                             /* 브랜드 그룹 코드              */
     , 0.00                                                                  /* 브랜드 그룹 USD 변동 금액     */
     , NULL                                                                                   /* 삭제 일시                     */
     , 'N'                                                                                   /* 삭제 여부                     */
     , 'test01'                                                                             /* 최초 등록자 아이디            */
     , GETDATE()                                                                               /* 최초 등록 일시                */
     , 'test01'                                                                              /* 최종 변경자 아이디            */
     , GETDATE()                                                                               /* 최종 변경 일시                */
     )
;

-- 상품_프리미엄 USD 브랜드 그룹 기본 이력 데이터 생성 50 01
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS_HST                                                   /* 상품_프리미엄 USD 브랜드 그룹 기본 이력*/
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , BRAND_GROUP_CODE                                                                              /* 브랜드 그룹 코드              */
     , BRAND_GROUP_USD_CHANGE_AMOUNT                                                                 /* 브랜드 그룹 USD 변동 금액     */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
SELECT
       IPUBGB.PREMIUM_ID                                                                             /* 프리미엄 아이디               */
     , IPUBGB.DSTRCT_LCLSF_CODE                                                                      /* 권역 대분류 코드              */
     , IPUBGB.BRAND_GROUP_CODE                                                                       /* 브랜드 그룹 코드              */
     , IPUBGB.BRAND_GROUP_USD_CHANGE_AMOUNT                                                          /* 브랜드 그룹 USD 변동 금액     */
     , IPUBGB.DELETE_DT                                                                              /* 삭제 일시                     */
     , IPUBGB.DELETE_AT                                                                              /* 삭제 여부                     */
     , IPUBGB.FRST_REGISTER_ID                                                                       /* 최초 등록자 아이디            */
     , IPUBGB.FRST_REGIST_DT                                                                         /* 최초 등록 일시                */
     , IPUBGB.LAST_CHANGER_ID                                                                        /* 최종 변경자 아이디            */
     , IPUBGB.LAST_CHANGE_DT                                                                         /* 최종 변경 일시                */
FROM dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS AS IPUBGB                                                    /* 상품_프리미엄 USD 브랜드 그룹 기본*/
WHERE PREMIUM_ID = 'PI07002460'                                                                      /* 프리미엄 아이디               */
AND DSTRCT_LCLSF_CODE = '50'                                                                         /* 권역 대분류 코드              */
AND BRAND_GROUP_CODE = '01'                                                                          /* 브랜드 그룹 코드              */
;

-- 상품_프리미엄 USD 브랜드 그룹 기본 데이터 생성 50 02
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS                                                       /* 상품_프리미엄 USD 브랜드 그룹 기본*/
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , BRAND_GROUP_CODE                                                                              /* 브랜드 그룹 코드              */
     , BRAND_GROUP_USD_CHANGE_AMOUNT                                                                 /* 브랜드 그룹 USD 변동 금액     */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
VALUES
     (
       'PI07002460'                                                                                  /* 프리미엄 아이디               */
     , '50'                                                                            /* 권역 대분류 코드              */
     , '02'                                                                             /* 브랜드 그룹 코드              */
     , 0.00                                                                  /* 브랜드 그룹 USD 변동 금액     */
     , NULL                                                                                   /* 삭제 일시                     */
     , 'N'                                                                                   /* 삭제 여부                     */
     , 'test01'                                                                             /* 최초 등록자 아이디            */
     , GETDATE()                                                                               /* 최초 등록 일시                */
     , 'test01'                                                                              /* 최종 변경자 아이디            */
     , GETDATE()                                                                               /* 최종 변경 일시                */
     )
;

-- 상품_프리미엄 USD 브랜드 그룹 기본 이력 데이터 생성 50 02
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS_HST                                                   /* 상품_프리미엄 USD 브랜드 그룹 기본 이력*/
     (
       PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , BRAND_GROUP_CODE                                                                              /* 브랜드 그룹 코드              */
     , BRAND_GROUP_USD_CHANGE_AMOUNT                                                                 /* 브랜드 그룹 USD 변동 금액     */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
SELECT
       IPUBGB.PREMIUM_ID                                                                             /* 프리미엄 아이디               */
     , IPUBGB.DSTRCT_LCLSF_CODE                                                                      /* 권역 대분류 코드              */
     , IPUBGB.BRAND_GROUP_CODE                                                                       /* 브랜드 그룹 코드              */
     , IPUBGB.BRAND_GROUP_USD_CHANGE_AMOUNT                                                          /* 브랜드 그룹 USD 변동 금액     */
     , IPUBGB.DELETE_DT                                                                              /* 삭제 일시                     */
     , IPUBGB.DELETE_AT                                                                              /* 삭제 여부                     */
     , IPUBGB.FRST_REGISTER_ID                                                                       /* 최초 등록자 아이디            */
     , IPUBGB.FRST_REGIST_DT                                                                         /* 최초 등록 일시                */
     , IPUBGB.LAST_CHANGER_ID                                                                        /* 최종 변경자 아이디            */
     , IPUBGB.LAST_CHANGE_DT                                                                         /* 최종 변경 일시                */
FROM dbo.IT_PREMIUM_USD_BRAND_GROUP_BAS AS IPUBGB                                                    /* 상품_프리미엄 USD 브랜드 그룹 기본*/
WHERE PREMIUM_ID = 'PI07002460'                                                                      /* 프리미엄 아이디               */
AND DSTRCT_LCLSF_CODE = '50'                                                                         /* 권역 대분류 코드              */
AND BRAND_GROUP_CODE = '02'                                                                          /* 브랜드 그룹 코드              */
;

-----------------------

SELECT * FROM IT_PREMIUM_BRAND_BAS WHERE PREMIUM_ID = 'PI07002459' ORDER BY FRST_REGIST_DT ASC

INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108630', 'PI07002460', '10', '01', 'BBY', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108631', 'PI07002460', '10', '01', 'BSL', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108632', 'PI07002460', '10', '01', 'NZAS', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108633', 'PI07002460', '10', '01', 'PMB', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108634', 'PI07002460', '10', '01', 'PORTLA', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108635', 'PI07002460', '10', '01', 'SOHAR', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108636', 'PI07002460', '10', '01', 'TOMAGO', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108637', 'PI07002460', '10', '02', 'AAR', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108638', 'PI07002460', '10', '02', 'BHAR', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108639', 'PI07002460', '10', '02', 'HINDAD', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108640', 'PI07002460', '10', '02', 'HINDAL', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108641', 'PI07002460', '10', '02', 'HINDMH', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108642', 'PI07002460', '10', '02', 'HINHK', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108643', 'PI07002460', '10', '02', 'RUSAL', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108644', 'PI07002460', '10', '02', 'RUSALB', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108645', 'PI07002460', '10', '02', 'VEDAL', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108646', 'PI07002460', '10', '02', 'VEDANT', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108647', 'PI07002460', '20', '01', 'BBY', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108648', 'PI07002460', '20', '01', 'BSL', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108649', 'PI07002460', '20', '01', 'NZAS', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108650', 'PI07002460', '20', '01', 'PMB', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108651', 'PI07002460', '20', '01', 'PORTLA', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108652', 'PI07002460', '20', '01', 'SOHAR', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108653', 'PI07002460', '20', '01', 'TOMAGO', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108654', 'PI07002460', '20', '02', 'AAR', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108655', 'PI07002460', '20', '02', 'BHAR', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108656', 'PI07002460', '20', '02', 'HINDAD', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108657', 'PI07002460', '20', '02', 'HINDAL', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108658', 'PI07002460', '20', '02', 'HINDMH', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108659', 'PI07002460', '20', '02', 'HINHK', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108660', 'PI07002460', '20', '02', 'RUSAL', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108661', 'PI07002460', '20', '02', 'RUSALB', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108662', 'PI07002460', '20', '02', 'VEDAL', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108663', 'PI07002460', '20', '02', 'VEDANT', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108664', 'PI07002460', '50', '01', 'BBY', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108665', 'PI07002460', '50', '01', 'BSL', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108666', 'PI07002460', '50', '01', 'NZAS', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108667', 'PI07002460', '50', '01', 'PMB', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108668', 'PI07002460', '50', '01', 'PORTLA', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108669', 'PI07002460', '50', '01', 'SOHAR', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108670', 'PI07002460', '50', '01', 'TOMAGO', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108671', 'PI07002460', '50', '02', 'AAR', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108672', 'PI07002460', '50', '02', 'BHAR', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108673', 'PI07002460', '50', '02', 'HINDAD', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108674', 'PI07002460', '50', '02', 'HINDAL', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108675', 'PI07002460', '50', '02', 'HINDMH', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108676', 'PI07002460', '50', '02', 'HINHK', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108677', 'PI07002460', '50', '02', 'RUSAL', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108678', 'PI07002460', '50', '02', 'RUSALB', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108679', 'PI07002460', '50', '02', 'VEDAL', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108680', 'PI07002460', '50', '02', 'VEDANT', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108681', 'PI07002460', '10', '01', '0000000000', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108682', 'PI07002460', '10', '02', '0000000000', 0, 132.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108683', 'PI07002460', '20', '01', '0000000000', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108684', 'PI07002460', '20', '02', '0000000000', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108685', 'PI07002460', '50', '01', '0000000000', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );
INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS( PREMIUM_NO, PREMIUM_ID, DSTRCT_LCLSF_CODE, BRAND_GROUP_CODE, BRAND_CODE, BRAND_USD_CHANGE_AMOUNT, SLE_PREMIUM_USD_AMOUNT, DELETE_DT, DELETE_AT, FRST_REGISTER_ID, FRST_REGIST_DT, LAST_CHANGER_ID, LAST_CHANGE_DT ) VALUES ('PN0720240306108686', 'PI07002460', '50', '02', '0000000000', 0, 127.00, NULL, 'N', 'test01', GETDATE(), 'test01', GETDATE() );

INSERT INTO dbo.IT_PREMIUM_USD_BRAND_BAS_HST                                                         /* 상품_프리미엄 USD 브랜드 기본 이력*/
     (
       PREMIUM_NO                                                                                    /* 프리미엄 번호                 */
     , PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , BRAND_GROUP_CODE                                                                              /* 브랜드 그룹 코드              */
     , BRAND_CODE                                                                                    /* 브랜드 코드                   */
     , BRAND_USD_CHANGE_AMOUNT                                                                       /* 브랜드 USD 변동 금액          */
     , SLE_PREMIUM_USD_AMOUNT                                                                        /* 판매 프리미엄 USD 금액        */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
SELECT 
	   PREMIUM_NO                                                                                    /* 프리미엄 번호                 */
     , PREMIUM_ID                                                                                    /* 프리미엄 아이디               */
     , DSTRCT_LCLSF_CODE                                                                             /* 권역 대분류 코드              */
     , BRAND_GROUP_CODE                                                                              /* 브랜드 그룹 코드              */
     , BRAND_CODE                                                                                    /* 브랜드 코드                   */
     , BRAND_USD_CHANGE_AMOUNT                                                                       /* 브랜드 USD 변동 금액          */
     , SLE_PREMIUM_USD_AMOUNT                                                                        /* 판매 프리미엄 USD 금액        */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
FROM IT_PREMIUM_USD_BRAND_BAS 
WHERE PREMIUM_ID = 'PI07002460' 
ORDER BY PREMIUM_NO ASC

-----------------------
SELECT PREMIUM_NO FROM IT_PREMIUM_BRAND_BAS WHERE PREMIUM_ID = 'PI07002459' ORDER BY PREMIUM_NO ASC
SELECT * FROM IT_PREMIUM_BRAND_DTL WHERE PREMIUM_NO IN (SELECT PREMIUM_NO FROM IT_PREMIUM_BRAND_BAS WHERE PREMIUM_ID = 'PI07002459') ORDER BY PREMIUM_NO ASC

SELECT PREMIUM_NO FROM IT_PREMIUM_USD_BRAND_BAS WHERE PREMIUM_ID = 'PI07002460' ORDER BY PREMIUM_NO ASC

INSERT INTO dbo.IT_PREMIUM_USD_BRAND_DTL                                                             /* 상품_프리미엄 USD 브랜드 상세 */
     (
       PREMIUM_NO                                                                                    /* 프리미엄 번호                 */
     , BRAND_BATCH_SN                                                                                /* 브랜드 배치 순번              */
     , APPLC_DT                                                                                      /* 적용 일시                     */
     , BSIS_WRHOUSNG_INVNTRY                                                                         /* 기초 입고 재고                */
     , SLE_SETUP_BL_QY                                                                               /* 판매 설정 BL 수량             */
     , SLE_SETUP_BUNDLE_CO                                                                           /* 판매 설정 번들 수             */
     , SLE_SETUP_WT                                                                                  /* 판매 설정 중량                */
     , SLE_INVNTRY_UNSLE_BNT                                                                         /* 판매 재고 미판매 잔량         */
     , WRHOUS_SLE_UNSETUP_INVNTRY                                                                    /* 창고 판매 미설정 재고         */
     , SLE_LME_DOLLAR_AMOUNT                                                                         /* 판매 LME 달러 금액            */
     , SLE_PREMIUM_WON_AMOUNT                                                                        /* 판매 프리미엄 원화 금액       */
     , SLE_PREMIUM_DOLLAR_AMOUNT                                                                     /* 판매 프리미엄 달러 금액       */
     , SLE_UNTPC_DOLLAR_AMOUNT                                                                       /* 판매 단가 달러 금액           */
     , SLE_MARGIN_DOLLAR_AMOUNT                                                                      /* 판매 마진 달러 금액           */
     , SLE_MARGINRT                                                                                  /* 판매 마진율                   */
     , PURCHS_PREMIUM_DOLLAR_AMOUNT                                                                  /* 구매 프리미엄 달러 금액       */
     , PURCHS_TOT_CT_DOLLAR_AMOUNT                                                                   /* 구매 총 비용 달러 금액        */
     , PURCHS_PUCHAS_PRMPC                                                                           /* 구매 매입 원가                */
     , FTRS_SLE_SPREAD_DOLLAR_AMOUNT                                                                 /* 선물 판매 스프레드 달러 금액  */
     , FTRS_PURCHS_SPREAD_DOLLAR_AMOUNT                                                              /* 선물 구매 스프레드 달러 금액  */
     , FSHG_SLE_SPREAD_DOLLAR_AMOUNT                                                                 /* 선물환 판매 스프레드 달러 금액*/
     , FSHG_SLE_SPREAD_WON_AMOUNT                                                                    /* 선물환 판매 스프레드 원화 금액*/
     , FSHG_PURCHS_SPREAD_DOLLAR_AMOUNT                                                              /* 선물환 구매 스프레드 달러 금액*/
     , FSHG_PURCHS_SPREAD_WON_AMOUNT                                                                 /* 선물환 구매 스프레드 원화 금액*/
     , LGIST_TRMINL_USE_DOLLAR_CT                                                                    /* 물류 터미널 사용 달러 비용    */
     , LGIST_TRMINL_USE_WON_CT                                                                       /* 물류 터미널 사용 원화 비용    */
     , LGIST_TRNSPRT_DOLLAR_CT                                                                       /* 물류 운송 달러 비용           */
     , LGIST_TRNSPRT_WON_CT                                                                          /* 물류 운송 원화 비용           */
     , LGIST_LNL_DOLLAR_CT                                                                           /* 물류 하역 달러 비용           */
     , LGIST_LNL_WON_CT                                                                              /* 물류 하역 원화 비용           */
     , LGIST_CSTDY_DOLLAR_CT                                                                         /* 물류 보관 달러 비용           */
     , LGIST_CSTDY_WON_CT                                                                            /* 물류 보관 원화 비용           */
     , LGIST_LAND_TRNSPRT_DOLLAR_CT                                                                  /* 물류 육지 운송 달러 비용      */
     , LGIST_LAND_TRNSPRT_WON_CT                                                                     /* 물류 육지 운송 원화 비용      */
     , LGIST_ETC_DOLLAR_CT                                                                           /* 물류 기타 달러 비용           */
     , LGIST_ETC_WON_CT                                                                              /* 물류 기타 원화 비용           */
     , ENTR_FEE_DOLLAR_CT                                                                            /* 통관 수수료 달러 비용         */
     , ENTR_FEE_WON_CT                                                                               /* 통관 수수료 원화 비용         */
     , FNNC_INTR_DOLLAR_CT                                                                           /* 금융 이자 달러 비용           */
     , FNNC_INTR_WON_CT                                                                              /* 금융 이자 원화 비용           */
     , FNNC_ETC_DOLLAR_CT                                                                            /* 금융 기타 달러 비용           */
     , FNNC_ETC_WON_CT                                                                               /* 금융 기타 원화 비용           */
     , FNNC_SALE_FTRS_FEE_DOLLAR                                                                     /* 금융 매도 선물 수수료 달러    */
     , FNNC_PRCHAS_FTRS_FEE_DOLLAR                                                                   /* 금융 매수 선물 수수료 달러    */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
SELECT
	  CONCAT('PN0720240306', SUBSTRING(IPBD.PREMIUM_NO, 13, 6)+57) AS NEW_PN
     , BRAND_BATCH_SN                                                                                /* 브랜드 배치 순번              */
     , APPLC_DT                                                                                      /* 적용 일시                     */
     , BSIS_WRHOUSNG_INVNTRY                                                                         /* 기초 입고 재고                */
     , SLE_SETUP_BL_QY                                                                               /* 판매 설정 BL 수량             */
     , SLE_SETUP_BUNDLE_CO                                                                           /* 판매 설정 번들 수             */
     , SLE_SETUP_WT                                                                                  /* 판매 설정 중량                */
     , SLE_INVNTRY_UNSLE_BNT                                                                         /* 판매 재고 미판매 잔량         */
     , WRHOUS_SLE_UNSETUP_INVNTRY                                                                    /* 창고 판매 미설정 재고         */
     , SLE_LME_DOLLAR_AMOUNT                                                                         /* 판매 LME 달러 금액            */
     , SLE_PREMIUM_WON_AMOUNT                                                                        /* 판매 프리미엄 원화 금액       */
     , SLE_PREMIUM_DOLLAR_AMOUNT                                                                     /* 판매 프리미엄 달러 금액       */
     , SLE_UNTPC_DOLLAR_AMOUNT                                                                       /* 판매 단가 달러 금액           */
     , SLE_MARGIN_DOLLAR_AMOUNT                                                                      /* 판매 마진 달러 금액           */
     , SLE_MARGINRT                                                                                  /* 판매 마진율                   */
     , PURCHS_PREMIUM_DOLLAR_AMOUNT                                                                  /* 구매 프리미엄 달러 금액       */
     , PURCHS_TOT_CT_DOLLAR_AMOUNT                                                                   /* 구매 총 비용 달러 금액        */
     , PURCHS_PUCHAS_PRMPC                                                                           /* 구매 매입 원가                */
     , FTRS_SLE_SPREAD_DOLLAR_AMOUNT                                                                 /* 선물 판매 스프레드 달러 금액  */
     , FTRS_PURCHS_SPREAD_DOLLAR_AMOUNT                                                              /* 선물 구매 스프레드 달러 금액  */
     , FSHG_SLE_SPREAD_DOLLAR_AMOUNT                                                                 /* 선물환 판매 스프레드 달러 금액*/
     , FSHG_SLE_SPREAD_WON_AMOUNT                                                                    /* 선물환 판매 스프레드 원화 금액*/
     , FSHG_PURCHS_SPREAD_DOLLAR_AMOUNT                                                              /* 선물환 구매 스프레드 달러 금액*/
     , FSHG_PURCHS_SPREAD_WON_AMOUNT                                                                 /* 선물환 구매 스프레드 원화 금액*/
     , LGIST_TRMINL_USE_DOLLAR_CT                                                                    /* 물류 터미널 사용 달러 비용    */
     , LGIST_TRMINL_USE_WON_CT                                                                       /* 물류 터미널 사용 원화 비용    */
     , LGIST_TRNSPRT_DOLLAR_CT                                                                       /* 물류 운송 달러 비용           */
     , LGIST_TRNSPRT_WON_CT                                                                          /* 물류 운송 원화 비용           */
     , LGIST_LNL_DOLLAR_CT                                                                           /* 물류 하역 달러 비용           */
     , LGIST_LNL_WON_CT                                                                              /* 물류 하역 원화 비용           */
     , LGIST_CSTDY_DOLLAR_CT                                                                         /* 물류 보관 달러 비용           */
     , LGIST_CSTDY_WON_CT                                                                            /* 물류 보관 원화 비용           */
     , LGIST_LAND_TRNSPRT_DOLLAR_CT                                                                  /* 물류 육지 운송 달러 비용      */
     , LGIST_LAND_TRNSPRT_WON_CT                                                                     /* 물류 육지 운송 원화 비용      */
     , LGIST_ETC_DOLLAR_CT                                                                           /* 물류 기타 달러 비용           */
     , LGIST_ETC_WON_CT                                                                              /* 물류 기타 원화 비용           */
     , ENTR_FEE_DOLLAR_CT                                                                            /* 통관 수수료 달러 비용         */
     , ENTR_FEE_WON_CT                                                                               /* 통관 수수료 원화 비용         */
     , FNNC_INTR_DOLLAR_CT                                                                           /* 금융 이자 달러 비용           */
     , FNNC_INTR_WON_CT                                                                              /* 금융 이자 원화 비용           */
     , FNNC_ETC_DOLLAR_CT                                                                            /* 금융 기타 달러 비용           */
     , FNNC_ETC_WON_CT                                                                               /* 금융 기타 원화 비용           */
     , FNNC_SALE_FTRS_FEE_DOLLAR                                                                     /* 금융 매도 선물 수수료 달러    */
     , FNNC_PRCHAS_FTRS_FEE_DOLLAR                                                                   /* 금융 매수 선물 수수료 달러    */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
FROM IT_PREMIUM_BRAND_DTL IPBD WHERE PREMIUM_NO IN (SELECT PREMIUM_NO FROM IT_PREMIUM_BRAND_BAS WHERE PREMIUM_ID = 'PI07002459') ORDER BY PREMIUM_NO ASC


INSERT INTO dbo.IT_PREMIUM_USD_BRAND_DTL_HST                                                         /* 상품_프리미엄 USD 브랜드 상세 이력*/
     (
       PREMIUM_NO                                                                                    /* 프리미엄 번호                 */
     , BRAND_BATCH_SN                                                                                /* 브랜드 배치 순번              */
     , APPLC_DT                                                                                      /* 적용 일시                     */
     , BSIS_WRHOUSNG_INVNTRY                                                                         /* 기초 입고 재고                */
     , SLE_SETUP_BL_QY                                                                               /* 판매 설정 BL 수량             */
     , SLE_SETUP_BUNDLE_CO                                                                           /* 판매 설정 번들 수             */
     , SLE_SETUP_WT                                                                                  /* 판매 설정 중량                */
     , SLE_INVNTRY_UNSLE_BNT                                                                         /* 판매 재고 미판매 잔량         */
     , WRHOUS_SLE_UNSETUP_INVNTRY                                                                    /* 창고 판매 미설정 재고         */
     , SLE_LME_DOLLAR_AMOUNT                                                                         /* 판매 LME 달러 금액            */
     , SLE_PREMIUM_WON_AMOUNT                                                                        /* 판매 프리미엄 원화 금액       */
     , SLE_PREMIUM_DOLLAR_AMOUNT                                                                     /* 판매 프리미엄 달러 금액       */
     , SLE_UNTPC_DOLLAR_AMOUNT                                                                       /* 판매 단가 달러 금액           */
     , SLE_MARGIN_DOLLAR_AMOUNT                                                                      /* 판매 마진 달러 금액           */
     , SLE_MARGINRT                                                                                  /* 판매 마진율                   */
     , PURCHS_PREMIUM_DOLLAR_AMOUNT                                                                  /* 구매 프리미엄 달러 금액       */
     , PURCHS_TOT_CT_DOLLAR_AMOUNT                                                                   /* 구매 총 비용 달러 금액        */
     , PURCHS_PUCHAS_PRMPC                                                                           /* 구매 매입 원가                */
     , FTRS_SLE_SPREAD_DOLLAR_AMOUNT                                                                 /* 선물 판매 스프레드 달러 금액  */
     , FTRS_PURCHS_SPREAD_DOLLAR_AMOUNT                                                              /* 선물 구매 스프레드 달러 금액  */
     , FSHG_SLE_SPREAD_DOLLAR_AMOUNT                                                                 /* 선물환 판매 스프레드 달러 금액*/
     , FSHG_SLE_SPREAD_WON_AMOUNT                                                                    /* 선물환 판매 스프레드 원화 금액*/
     , FSHG_PURCHS_SPREAD_DOLLAR_AMOUNT                                                              /* 선물환 구매 스프레드 달러 금액*/
     , FSHG_PURCHS_SPREAD_WON_AMOUNT                                                                 /* 선물환 구매 스프레드 원화 금액*/
     , LGIST_TRMINL_USE_DOLLAR_CT                                                                    /* 물류 터미널 사용 달러 비용    */
     , LGIST_TRMINL_USE_WON_CT                                                                       /* 물류 터미널 사용 원화 비용    */
     , LGIST_TRNSPRT_DOLLAR_CT                                                                       /* 물류 운송 달러 비용           */
     , LGIST_TRNSPRT_WON_CT                                                                          /* 물류 운송 원화 비용           */
     , LGIST_LNL_DOLLAR_CT                                                                           /* 물류 하역 달러 비용           */
     , LGIST_LNL_WON_CT                                                                              /* 물류 하역 원화 비용           */
     , LGIST_CSTDY_DOLLAR_CT                                                                         /* 물류 보관 달러 비용           */
     , LGIST_CSTDY_WON_CT                                                                            /* 물류 보관 원화 비용           */
     , LGIST_LAND_TRNSPRT_DOLLAR_CT                                                                  /* 물류 육지 운송 달러 비용      */
     , LGIST_LAND_TRNSPRT_WON_CT                                                                     /* 물류 육지 운송 원화 비용      */
     , LGIST_ETC_DOLLAR_CT                                                                           /* 물류 기타 달러 비용           */
     , LGIST_ETC_WON_CT                                                                              /* 물류 기타 원화 비용           */
     , ENTR_FEE_DOLLAR_CT                                                                            /* 통관 수수료 달러 비용         */
     , ENTR_FEE_WON_CT                                                                               /* 통관 수수료 원화 비용         */
     , FNNC_INTR_DOLLAR_CT                                                                           /* 금융 이자 달러 비용           */
     , FNNC_INTR_WON_CT                                                                              /* 금융 이자 원화 비용           */
     , FNNC_ETC_DOLLAR_CT                                                                            /* 금융 기타 달러 비용           */
     , FNNC_ETC_WON_CT                                                                               /* 금융 기타 원화 비용           */
     , FNNC_SALE_FTRS_FEE_DOLLAR                                                                     /* 금융 매도 선물 수수료 달러    */
     , FNNC_PRCHAS_FTRS_FEE_DOLLAR                                                                   /* 금융 매수 선물 수수료 달러    */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
     )
SELECT 
	   PREMIUM_NO                                                                                    /* 프리미엄 번호                 */
     , BRAND_BATCH_SN                                                                                /* 브랜드 배치 순번              */
     , APPLC_DT                                                                                      /* 적용 일시                     */
     , BSIS_WRHOUSNG_INVNTRY                                                                         /* 기초 입고 재고                */
     , SLE_SETUP_BL_QY                                                                               /* 판매 설정 BL 수량             */
     , SLE_SETUP_BUNDLE_CO                                                                           /* 판매 설정 번들 수             */
     , SLE_SETUP_WT                                                                                  /* 판매 설정 중량                */
     , SLE_INVNTRY_UNSLE_BNT                                                                         /* 판매 재고 미판매 잔량         */
     , WRHOUS_SLE_UNSETUP_INVNTRY                                                                    /* 창고 판매 미설정 재고         */
     , SLE_LME_DOLLAR_AMOUNT                                                                         /* 판매 LME 달러 금액            */
     , SLE_PREMIUM_WON_AMOUNT                                                                        /* 판매 프리미엄 원화 금액       */
     , SLE_PREMIUM_DOLLAR_AMOUNT                                                                     /* 판매 프리미엄 달러 금액       */
     , SLE_UNTPC_DOLLAR_AMOUNT                                                                       /* 판매 단가 달러 금액           */
     , SLE_MARGIN_DOLLAR_AMOUNT                                                                      /* 판매 마진 달러 금액           */
     , SLE_MARGINRT                                                                                  /* 판매 마진율                   */
     , PURCHS_PREMIUM_DOLLAR_AMOUNT                                                                  /* 구매 프리미엄 달러 금액       */
     , PURCHS_TOT_CT_DOLLAR_AMOUNT                                                                   /* 구매 총 비용 달러 금액        */
     , PURCHS_PUCHAS_PRMPC                                                                           /* 구매 매입 원가                */
     , FTRS_SLE_SPREAD_DOLLAR_AMOUNT                                                                 /* 선물 판매 스프레드 달러 금액  */
     , FTRS_PURCHS_SPREAD_DOLLAR_AMOUNT                                                              /* 선물 구매 스프레드 달러 금액  */
     , FSHG_SLE_SPREAD_DOLLAR_AMOUNT                                                                 /* 선물환 판매 스프레드 달러 금액*/
     , FSHG_SLE_SPREAD_WON_AMOUNT                                                                    /* 선물환 판매 스프레드 원화 금액*/
     , FSHG_PURCHS_SPREAD_DOLLAR_AMOUNT                                                              /* 선물환 구매 스프레드 달러 금액*/
     , FSHG_PURCHS_SPREAD_WON_AMOUNT                                                                 /* 선물환 구매 스프레드 원화 금액*/
     , LGIST_TRMINL_USE_DOLLAR_CT                                                                    /* 물류 터미널 사용 달러 비용    */
     , LGIST_TRMINL_USE_WON_CT                                                                       /* 물류 터미널 사용 원화 비용    */
     , LGIST_TRNSPRT_DOLLAR_CT                                                                       /* 물류 운송 달러 비용           */
     , LGIST_TRNSPRT_WON_CT                                                                          /* 물류 운송 원화 비용           */
     , LGIST_LNL_DOLLAR_CT                                                                           /* 물류 하역 달러 비용           */
     , LGIST_LNL_WON_CT                                                                              /* 물류 하역 원화 비용           */
     , LGIST_CSTDY_DOLLAR_CT                                                                         /* 물류 보관 달러 비용           */
     , LGIST_CSTDY_WON_CT                                                                            /* 물류 보관 원화 비용           */
     , LGIST_LAND_TRNSPRT_DOLLAR_CT                                                                  /* 물류 육지 운송 달러 비용      */
     , LGIST_LAND_TRNSPRT_WON_CT                                                                     /* 물류 육지 운송 원화 비용      */
     , LGIST_ETC_DOLLAR_CT                                                                           /* 물류 기타 달러 비용           */
     , LGIST_ETC_WON_CT                                                                              /* 물류 기타 원화 비용           */
     , ENTR_FEE_DOLLAR_CT                                                                            /* 통관 수수료 달러 비용         */
     , ENTR_FEE_WON_CT                                                                               /* 통관 수수료 원화 비용         */
     , FNNC_INTR_DOLLAR_CT                                                                           /* 금융 이자 달러 비용           */
     , FNNC_INTR_WON_CT                                                                              /* 금융 이자 원화 비용           */
     , FNNC_ETC_DOLLAR_CT                                                                            /* 금융 기타 달러 비용           */
     , FNNC_ETC_WON_CT                                                                               /* 금융 기타 원화 비용           */
     , FNNC_SALE_FTRS_FEE_DOLLAR                                                                     /* 금융 매도 선물 수수료 달러    */
     , FNNC_PRCHAS_FTRS_FEE_DOLLAR                                                                   /* 금융 매수 선물 수수료 달러    */
     , DELETE_DT                                                                                     /* 삭제 일시                     */
     , DELETE_AT                                                                                     /* 삭제 여부                     */
     , FRST_REGISTER_ID                                                                              /* 최초 등록자 아이디            */
     , FRST_REGIST_DT                                                                                /* 최초 등록 일시                */
     , LAST_CHANGER_ID                                                                               /* 최종 변경자 아이디            */
     , LAST_CHANGE_DT                                                                                /* 최종 변경 일시                */
FROM IT_PREMIUM_USD_BRAND_DTL
WHERE PREMIUM_NO IN (SELECT PREMIUM_NO FROM IT_PREMIUM_USD_BRAND_BAS WHERE PREMIUM_ID = 'PI07002460')
ORDER BY PREMIUM_NO ASC



