/* 상품_프리미엄 USD 기준 기본 */
CREATE TABLE [dbo].[IT_PREMIUM_USD_STDR_BAS] (
	[PREMIUM_ID] [NVARCHAR](18) NOT NULL,  /* 프리미엄 아이디 */
	[METAL_CODE] [NVARCHAR](2) NOT NULL,  /* 금속 코드 */
	[ITM_SN] [INT] NOT NULL,  /* 아이템 순번 */
	[VALID_BEGIN_DT] [NVARCHAR](14) NOT NULL,  /* 유효 시작 일시 */
	[VALID_END_DT] [NVARCHAR](14) NOT NULL,  /* 유효 종료 일시 */
	[SLE_MTHD_CODE] [NVARCHAR](2) NOT NULL,  /* 판매 방식 코드 */
	[PREMIUM_USD_STDR_AMOUNT] [DECIMAL](15,6) NOT NULL,  /* 프리미엄 USD 기준 금액 */
	[DELETE_DT] [DATETIME],  /* 삭제 일시 */
	[DELETE_AT] [NVARCHAR](1) NOT NULL,  /* 삭제 여부 */
	[FRST_REGISTER_ID] [NVARCHAR](30) NOT NULL,  /* 최초 등록자 아이디 */
	[FRST_REGIST_DT] [DATETIME] NOT NULL,  /* 최초 등록 일시 */
	[LAST_CHANGER_ID] [NVARCHAR](30) NOT NULL,  /* 최종 변경자 아이디 */
	[LAST_CHANGE_DT] [DATETIME] NOT NULL /* 최종 변경 일시 */
)
GO

/* 상품_프리미엄 USD 기준 기본 기본키 */
ALTER TABLE [dbo].[IT_PREMIUM_USD_STDR_BAS]
	ADD
		CONSTRAINT [PK_IT_PREMIUM_USD_STDR_BAS]
		PRIMARY KEY NONCLUSTERED (
			[PREMIUM_ID] ASC
		)
GO

/* 상품_프리미엄 USD 기준 기본 인덱스 */
CREATE NONCLUSTERED INDEX [IX_IT_PREMIUM_USD_STDR_BAS] ON [dbo].[IT_PREMIUM_USD_STDR_BAS] (
	[METAL_CODE] ASC, 
	[VALID_BEGIN_DT] ASC, 
	[VALID_END_DT] ASC, 
	[ITM_SN] ASC
)
GO

/* 상품_프리미엄 USD 기준 기본 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'상품_프리미엄 USD 기준 기본', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS'
GO

/* 프리미엄 아이디 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'프리미엄 아이디', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'COLUMN', @level2name=N'PREMIUM_ID'
GO

/* 금속 코드 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'금속 코드', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'COLUMN', @level2name=N'METAL_CODE'
GO

/* 아이템 순번 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'아이템 순번', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'COLUMN', @level2name=N'ITM_SN'
GO

/* 유효 시작 일시 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'유효 시작 일시', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'COLUMN', @level2name=N'VALID_BEGIN_DT'
GO

/* 유효 종료 일시 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'유효 종료 일시', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'COLUMN', @level2name=N'VALID_END_DT'
GO

/* 판매 방식 코드 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'판매 방식 코드', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'COLUMN', @level2name=N'SLE_MTHD_CODE'
GO

/* 프리미엄 USD 기준 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'프리미엄 USD 기준 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'COLUMN', @level2name=N'PREMIUM_USD_STDR_AMOUNT'
GO

/* 삭제 일시 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'삭제 일시', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'COLUMN', @level2name=N'DELETE_DT'
GO

/* 삭제 여부 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'삭제 여부', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'COLUMN', @level2name=N'DELETE_AT'
GO

/* 최초 등록자 아이디 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최초 등록자 아이디', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'COLUMN', @level2name=N'FRST_REGISTER_ID'
GO

/* 최초 등록 일시 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최초 등록 일시', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'COLUMN', @level2name=N'FRST_REGIST_DT'
GO

/* 최종 변경자 아이디 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최종 변경자 아이디', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'COLUMN', @level2name=N'LAST_CHANGER_ID'
GO

/* 최종 변경 일시 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최종 변경 일시', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'COLUMN', @level2name=N'LAST_CHANGE_DT'
GO

/* 상품_프리미엄 USD 기준 기본 기본키 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'상품_프리미엄 USD 기준 기본 기본키', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'CONSTRAINT', @level2name=N'PK_IT_PREMIUM_USD_STDR_BAS'
GO

/* 상품_프리미엄 USD 기준 기본 기본키 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'상품_프리미엄 USD 기준 기본 기본키', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'INDEX', @level2name=N'PK_IT_PREMIUM_USD_STDR_BAS'
GO

/* 상품_프리미엄 USD 기준 기본 인덱스 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'상품_프리미엄 USD 기준 기본 인덱스', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_STDR_BAS', 
	@level2type=N'INDEX', @level2name=N'IX_IT_PREMIUM_USD_STDR_BAS'
GO