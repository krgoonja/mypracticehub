/* 상품_프리미엄 USD 브랜드 기본 이력 */
CREATE TABLE [dbo].[IT_PREMIUM_USD_BRAND_BAS_HST] (
	[HIST_SN] [BIGINT] NOT NULL IDENTITY (1,  1),  /* 이력 순번 */
	[PREMIUM_NO] [NVARCHAR](18) NOT NULL,  /* 프리미엄 번호 */
	[PREMIUM_ID] [NVARCHAR](18) NOT NULL,  /* 프리미엄 아이디 */
	[DSTRCT_LCLSF_CODE] [NVARCHAR](2) NOT NULL,  /* 권역 대분류 코드 */
	[BRAND_GROUP_CODE] [NVARCHAR](2) NOT NULL,  /* 브랜드 그룹 코드 */
	[BRAND_CODE] [NVARCHAR](10) NOT NULL,  /* 브랜드 코드 */
	[BRAND_USD_CHANGE_AMOUNT] [DECIMAL](15,6) NOT NULL,  /* 브랜드 USD 변동 금액 */
	[SLE_PREMIUM_USD_AMOUNT] [DECIMAL](15,6) NOT NULL,  /* 판매 프리미엄 USD 금액 */
	[DELETE_DT] [DATETIME],  /* 삭제 일시 */
	[DELETE_AT] [NVARCHAR](1) NOT NULL,  /* 삭제 여부 */
	[FRST_REGISTER_ID] [NVARCHAR](30) NOT NULL,  /* 최초 등록자 아이디 */
	[FRST_REGIST_DT] [DATETIME] NOT NULL,  /* 최초 등록 일시 */
	[LAST_CHANGER_ID] [NVARCHAR](30) NOT NULL,  /* 최종 변경자 아이디 */
	[LAST_CHANGE_DT] [DATETIME] NOT NULL /* 최종 변경 일시 */
)
GO

/* 상품_프리미엄 USD 브랜드 기본 이력 기본키 */
ALTER TABLE [dbo].[IT_PREMIUM_USD_BRAND_BAS_HST]
	ADD
		CONSTRAINT [PK_IT_PREMIUM_USD_BRAND_BAS_HST]
		PRIMARY KEY NONCLUSTERED (
			[HIST_SN] ASC, 
			[PREMIUM_NO] ASC
		)
GO

/* 상품_프리미엄 USD 브랜드 기본 이력 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'상품_프리미엄 USD 브랜드 기본 이력', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST'
GO

/* 이력 순번 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'이력 순번', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'COLUMN', @level2name=N'HIST_SN'
GO

/* 프리미엄 번호 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'프리미엄 번호', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'COLUMN', @level2name=N'PREMIUM_NO'
GO

/* 프리미엄 아이디 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'프리미엄 아이디', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'COLUMN', @level2name=N'PREMIUM_ID'
GO

/* 권역 대분류 코드 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'권역 대분류 코드', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'COLUMN', @level2name=N'DSTRCT_LCLSF_CODE'
GO

/* 브랜드 그룹 코드 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'브랜드 그룹 코드', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'COLUMN', @level2name=N'BRAND_GROUP_CODE'
GO

/* 브랜드 코드 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'브랜드 코드', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'COLUMN', @level2name=N'BRAND_CODE'
GO

/* 브랜드 USD 변동 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'브랜드 USD 변동 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'COLUMN', @level2name=N'BRAND_USD_CHANGE_AMOUNT'
GO

/* 판매 프리미엄 USD 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'판매 프리미엄 USD 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'COLUMN', @level2name=N'SLE_PREMIUM_USD_AMOUNT'
GO

/* 삭제 일시 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'삭제 일시', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'COLUMN', @level2name=N'DELETE_DT'
GO

/* 삭제 여부 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'삭제 여부', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'COLUMN', @level2name=N'DELETE_AT'
GO

/* 최초 등록자 아이디 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최초 등록자 아이디', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'COLUMN', @level2name=N'FRST_REGISTER_ID'
GO

/* 최초 등록 일시 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최초 등록 일시', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'COLUMN', @level2name=N'FRST_REGIST_DT'
GO

/* 최종 변경자 아이디 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최종 변경자 아이디', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'COLUMN', @level2name=N'LAST_CHANGER_ID'
GO

/* 최종 변경 일시 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최종 변경 일시', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'COLUMN', @level2name=N'LAST_CHANGE_DT'
GO

/* 상품_프리미엄 USD 브랜드 기본 이력 기본키 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'상품_프리미엄 USD 브랜드 기본 이력 기본키', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'CONSTRAINT', @level2name=N'PK_IT_PREMIUM_USD_BRAND_BAS_HST'
GO

/* 상품_프리미엄 USD 브랜드 기본 이력 기본키 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'상품_프리미엄 USD 브랜드 기본 이력 기본키', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_BAS_HST', 
	@level2type=N'INDEX', @level2name=N'PK_IT_PREMIUM_USD_BRAND_BAS_HST'
GO