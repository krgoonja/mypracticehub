/* 상품_프리미엄 USD 브랜드 상세 이력 */
CREATE TABLE [dbo].[IT_PREMIUM_USD_BRAND_DTL_HST] (
	[HIST_SN] [BIGINT] NOT NULL IDENTITY (1,  1),  /* 이력 순번 */
	[PREMIUM_NO] [NVARCHAR](18) NOT NULL,  /* 프리미엄 번호 */
	[BRAND_BATCH_SN] [INT] NOT NULL,  /* 브랜드 배치 순번 */
	[APPLC_DT] [NVARCHAR](14) NOT NULL,  /* 적용 일시 */
	[BSIS_WRHOUSNG_INVNTRY] [DECIMAL](10,3) NOT NULL,  /* 기초 입고 재고 */
	[SLE_SETUP_BL_QY] [INT] NOT NULL,  /* 판매 설정 BL 수량 */
	[SLE_SETUP_BUNDLE_CO] [INT],  /* 판매 설정 번들 수 */
	[SLE_SETUP_WT] [DECIMAL](10,3),  /* 판매 설정 중량 */
	[SLE_INVNTRY_UNSLE_BNT] [DECIMAL](10,3),  /* 판매 재고 미판매 잔량 */
	[WRHOUS_SLE_UNSETUP_INVNTRY] [DECIMAL](10,3),  /* 창고 판매 미설정 재고 */
	[SLE_LME_DOLLAR_AMOUNT] [DECIMAL](15,6),  /* 판매 LME 달러 금액 */
	[SLE_PREMIUM_WON_AMOUNT] [BIGINT],  /* 판매 프리미엄 원화 금액 */
	[SLE_PREMIUM_DOLLAR_AMOUNT] [DECIMAL](15,6),  /* 판매 프리미엄 달러 금액 */
	[SLE_UNTPC_DOLLAR_AMOUNT] [DECIMAL](15,6),  /* 판매 단가 달러 금액 */
	[SLE_MARGIN_DOLLAR_AMOUNT] [DECIMAL](15,6),  /* 판매 마진 달러 금액 */
	[SLE_MARGINRT] [DECIMAL](5,2),  /* 판매 마진율 */
	[PURCHS_PREMIUM_DOLLAR_AMOUNT] [DECIMAL](15,6),  /* 구매 프리미엄 달러 금액 */
	[PURCHS_TOT_CT_DOLLAR_AMOUNT] [DECIMAL](15,6),  /* 구매 총 비용 달러 금액 */
	[PURCHS_PUCHAS_PRMPC] [BIGINT],  /* 구매 매입 원가 */
	[FTRS_SLE_SPREAD_DOLLAR_AMOUNT] [DECIMAL](15,6),  /* 선물 판매 스프레드 달러 금액 */
	[FTRS_PURCHS_SPREAD_DOLLAR_AMOUNT] [DECIMAL](15,6),  /* 선물 구매 스프레드 달러 금액 */
	[FSHG_SLE_SPREAD_DOLLAR_AMOUNT] [DECIMAL](15,6),  /* 선물환 판매 스프레드 달러 금액 */
	[FSHG_SLE_SPREAD_WON_AMOUNT] [DECIMAL](15,6),  /* 선물환 판매 스프레드 원화 금액 */
	[FSHG_PURCHS_SPREAD_DOLLAR_AMOUNT] [DECIMAL](15,6),  /* 선물환 구매 스프레드 달러 금액 */
	[FSHG_PURCHS_SPREAD_WON_AMOUNT] [DECIMAL](15,6),  /* 선물환 구매 스프레드 원화 금액 */
	[LGIST_TRMINL_USE_DOLLAR_CT] [DECIMAL](15,6),  /* 물류 터미널 사용 달러 비용 */
	[LGIST_TRMINL_USE_WON_CT] [BIGINT],  /* 물류 터미널 사용 원화 비용 */
	[LGIST_TRNSPRT_DOLLAR_CT] [DECIMAL](15,6),  /* 물류 운송 달러 비용 */
	[LGIST_TRNSPRT_WON_CT] [BIGINT],  /* 물류 운송 원화 비용 */
	[LGIST_LNL_DOLLAR_CT] [DECIMAL](15,6),  /* 물류 하역 달러 비용 */
	[LGIST_LNL_WON_CT] [BIGINT],  /* 물류 하역 원화 비용 */
	[LGIST_CSTDY_DOLLAR_CT] [DECIMAL](15,6),  /* 물류 보관 달러 비용 */
	[LGIST_CSTDY_WON_CT] [BIGINT],  /* 물류 보관 원화 비용 */
	[LGIST_LAND_TRNSPRT_DOLLAR_CT] [DECIMAL](15,6),  /* 물류 육지 운송 달러 비용 */
	[LGIST_LAND_TRNSPRT_WON_CT] [BIGINT],  /* 물류 육지 운송 원화 비용 */
	[LGIST_ETC_DOLLAR_CT] [DECIMAL](15,6),  /* 물류 기타 달러 비용 */
	[LGIST_ETC_WON_CT] [BIGINT],  /* 물류 기타 원화 비용 */
	[ENTR_FEE_DOLLAR_CT] [DECIMAL](15,6),  /* 통관 수수료 달러 비용 */
	[ENTR_FEE_WON_CT] [BIGINT],  /* 통관 수수료 원화 비용 */
	[FNNC_INTR_DOLLAR_CT] [DECIMAL](15,6),  /* 금융 이자 달러 비용 */
	[FNNC_INTR_WON_CT] [BIGINT],  /* 금융 이자 원화 비용 */
	[FNNC_ETC_DOLLAR_CT] [DECIMAL](15,6),  /* 금융 기타 달러 비용 */
	[FNNC_ETC_WON_CT] [BIGINT],  /* 금융 기타 원화 비용 */
	[FNNC_SALE_FTRS_FEE_DOLLAR] [DECIMAL](15,6),  /* 금융 매도 선물 수수료 달러 */
	[FNNC_PRCHAS_FTRS_FEE_DOLLAR] [DECIMAL](15,6),  /* 금융 매수 선물 수수료 달러 */
	[DELETE_DT] [DATETIME],  /* 삭제 일시 */
	[DELETE_AT] [NVARCHAR](1) NOT NULL,  /* 삭제 여부 */
	[FRST_REGISTER_ID] [NVARCHAR](30) NOT NULL,  /* 최초 등록자 아이디 */
	[FRST_REGIST_DT] [DATETIME] NOT NULL,  /* 최초 등록 일시 */
	[LAST_CHANGER_ID] [NVARCHAR](30) NOT NULL,  /* 최종 변경자 아이디 */
	[LAST_CHANGE_DT] [DATETIME] NOT NULL /* 최종 변경 일시 */
)
GO

/* 상품_프리미엄 USD 브랜드 상세 이력 기본키 */
ALTER TABLE [dbo].[IT_PREMIUM_USD_BRAND_DTL_HST]
	ADD
		CONSTRAINT [PK_IT_PREMIUM_USD_BRAND_DTL_HST]
		PRIMARY KEY NONCLUSTERED (
			[HIST_SN] ASC, 
			[PREMIUM_NO] ASC, 
			[BRAND_BATCH_SN] ASC
		)
GO

/* 상품_프리미엄 USD 브랜드 상세 이력 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'상품_프리미엄 USD 브랜드 상세 이력', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST'
GO

/* 이력 순번 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'이력 순번', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'HIST_SN'
GO

/* 프리미엄 번호 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'프리미엄 번호', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'PREMIUM_NO'
GO

/* 브랜드 배치 순번 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'브랜드 배치 순번', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'BRAND_BATCH_SN'
GO

/* 적용 일시 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'적용 일시', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'APPLC_DT'
GO

/* 기초 입고 재고 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'기초 입고 재고', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'BSIS_WRHOUSNG_INVNTRY'
GO

/* 판매 설정 BL 수량 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'판매 설정 BL 수량', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'SLE_SETUP_BL_QY'
GO

/* 판매 설정 번들 수 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'판매 설정 번들 수', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'SLE_SETUP_BUNDLE_CO'
GO

/* 판매 설정 중량 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'판매 설정 중량', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'SLE_SETUP_WT'
GO

/* 판매 재고 미판매 잔량 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'판매 재고 미판매 잔량', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'SLE_INVNTRY_UNSLE_BNT'
GO

/* 창고 판매 미설정 재고 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'창고 판매 미설정 재고', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'WRHOUS_SLE_UNSETUP_INVNTRY'
GO

/* 판매 LME 달러 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'판매 LME 달러 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'SLE_LME_DOLLAR_AMOUNT'
GO

/* 판매 프리미엄 원화 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'판매 프리미엄 원화 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'SLE_PREMIUM_WON_AMOUNT'
GO

/* 판매 프리미엄 달러 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'판매 프리미엄 달러 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'SLE_PREMIUM_DOLLAR_AMOUNT'
GO

/* 판매 단가 달러 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'판매 단가 달러 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'SLE_UNTPC_DOLLAR_AMOUNT'
GO

/* 판매 마진 달러 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'판매 마진 달러 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'SLE_MARGIN_DOLLAR_AMOUNT'
GO

/* 판매 마진율 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'판매 마진율', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'SLE_MARGINRT'
GO

/* 구매 프리미엄 달러 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'구매 프리미엄 달러 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'PURCHS_PREMIUM_DOLLAR_AMOUNT'
GO

/* 구매 총 비용 달러 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'구매 총 비용 달러 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'PURCHS_TOT_CT_DOLLAR_AMOUNT'
GO

/* 구매 매입 원가 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'구매 매입 원가', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'PURCHS_PUCHAS_PRMPC'
GO

/* 선물 판매 스프레드 달러 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'선물 판매 스프레드 달러 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'FTRS_SLE_SPREAD_DOLLAR_AMOUNT'
GO

/* 선물 구매 스프레드 달러 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'선물 구매 스프레드 달러 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'FTRS_PURCHS_SPREAD_DOLLAR_AMOUNT'
GO

/* 선물환 판매 스프레드 달러 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'선물환 판매 스프레드 달러 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'FSHG_SLE_SPREAD_DOLLAR_AMOUNT'
GO

/* 선물환 판매 스프레드 원화 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'선물환 판매 스프레드 원화 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'FSHG_SLE_SPREAD_WON_AMOUNT'
GO

/* 선물환 구매 스프레드 달러 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'선물환 구매 스프레드 달러 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'FSHG_PURCHS_SPREAD_DOLLAR_AMOUNT'
GO

/* 선물환 구매 스프레드 원화 금액 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'선물환 구매 스프레드 원화 금액', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'FSHG_PURCHS_SPREAD_WON_AMOUNT'
GO

/* 물류 터미널 사용 달러 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'물류 터미널 사용 달러 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'LGIST_TRMINL_USE_DOLLAR_CT'
GO

/* 물류 터미널 사용 원화 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'물류 터미널 사용 원화 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'LGIST_TRMINL_USE_WON_CT'
GO

/* 물류 운송 달러 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'물류 운송 달러 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'LGIST_TRNSPRT_DOLLAR_CT'
GO

/* 물류 운송 원화 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'물류 운송 원화 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'LGIST_TRNSPRT_WON_CT'
GO

/* 물류 하역 달러 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'물류 하역 달러 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'LGIST_LNL_DOLLAR_CT'
GO

/* 물류 하역 원화 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'물류 하역 원화 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'LGIST_LNL_WON_CT'
GO

/* 물류 보관 달러 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'물류 보관 달러 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'LGIST_CSTDY_DOLLAR_CT'
GO

/* 물류 보관 원화 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'물류 보관 원화 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'LGIST_CSTDY_WON_CT'
GO

/* 물류 육지 운송 달러 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'물류 육지 운송 달러 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'LGIST_LAND_TRNSPRT_DOLLAR_CT'
GO

/* 물류 육지 운송 원화 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'물류 육지 운송 원화 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'LGIST_LAND_TRNSPRT_WON_CT'
GO

/* 물류 기타 달러 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'물류 기타 달러 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'LGIST_ETC_DOLLAR_CT'
GO

/* 물류 기타 원화 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'물류 기타 원화 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'LGIST_ETC_WON_CT'
GO

/* 통관 수수료 달러 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'통관 수수료 달러 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'ENTR_FEE_DOLLAR_CT'
GO

/* 통관 수수료 원화 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'통관 수수료 원화 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'ENTR_FEE_WON_CT'
GO

/* 금융 이자 달러 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'금융 이자 달러 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'FNNC_INTR_DOLLAR_CT'
GO

/* 금융 이자 원화 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'금융 이자 원화 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'FNNC_INTR_WON_CT'
GO

/* 금융 기타 달러 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'금융 기타 달러 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'FNNC_ETC_DOLLAR_CT'
GO

/* 금융 기타 원화 비용 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'금융 기타 원화 비용', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'FNNC_ETC_WON_CT'
GO

/* 금융 매도 선물 수수료 달러 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'금융 매도 선물 수수료 달러', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'FNNC_SALE_FTRS_FEE_DOLLAR'
GO

/* 금융 매수 선물 수수료 달러 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'금융 매수 선물 수수료 달러', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'FNNC_PRCHAS_FTRS_FEE_DOLLAR'
GO

/* 삭제 일시 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'삭제 일시', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'DELETE_DT'
GO

/* 삭제 여부 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'삭제 여부', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'DELETE_AT'
GO

/* 최초 등록자 아이디 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최초 등록자 아이디', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'FRST_REGISTER_ID'
GO

/* 최초 등록 일시 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최초 등록 일시', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'FRST_REGIST_DT'
GO

/* 최종 변경자 아이디 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최종 변경자 아이디', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'LAST_CHANGER_ID'
GO

/* 최종 변경 일시 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'최종 변경 일시', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'COLUMN', @level2name=N'LAST_CHANGE_DT'
GO

/* 상품_프리미엄 USD 브랜드 상세 이력 기본키 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'상품_프리미엄 USD 브랜드 상세 이력 기본키', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'CONSTRAINT', @level2name=N'PK_IT_PREMIUM_USD_BRAND_DTL_HST'
GO

/* 상품_프리미엄 USD 브랜드 상세 이력 기본키 */
EXEC sp_addextendedproperty 
	@name=N'MS_Description', @value=N'상품_프리미엄 USD 브랜드 상세 이력 기본키', 
	@level0type=N'SCHEMA', @level0name=N'dbo', 
	@level1type=N'TABLE', @level1name=N'IT_PREMIUM_USD_BRAND_DTL_HST', 
	@level2type=N'INDEX', @level2name=N'PK_IT_PREMIUM_USD_BRAND_DTL_HST'
GO